try {
  var dv_win = window._dv_win || window.parent._dv_win;
  dv_win["dvCallback_1795262935582842"](
    $dv,
    window,
    "cbcd801d4f094f3b8ada6ae132ffd071",
    "maestro-ue1.tps.dv.tech",
    {
      rtn: {
        rtnEvents: [
          {
            eventName: "ImpressionServed",
            actions: [
              {
                url: "[RTSURL]86&adgrpid=[C2]&supvend=[C3]&DVP_PP_IMP_ID=[AUEVENT]",
                actionType: "image",
              },
            ],
          },
          {
            eventName: "GroupMV3StandardPassedImpression",
            actions: [
              {
                url: "[RTSURL]75&adgrpid=[C2]&supvend=[C3]&DVP_PP_IMP_ID=[AUEVENT]",
                actionType: "image",
              },
            ],
          },
          {
            eventName: "PMXStandardMeasuredImpression",
            actions: [
              {
                url: "[RTSURL]92&adgrpid=[C2]&supvend=[C3]&DVP_PP_IMP_ID=[AUEVENT]",
                actionType: "image",
              },
            ],
          },
          {
            eventName: "IABAdViewable10Seconds",
            actions: [
              {
                url: "[RTSURL]83&adgrpid=[C2]&supvend=[C3]&DVP_PP_IMP_ID=[AUEVENT]",
                actionType: "image",
              },
            ],
          },
          {
            eventName: "GroupMMeasuredImpression",
            actions: [
              {
                url: "[RTSURL]74&adgrpid=[C2]&supvend=[C3]&DVP_PP_IMP_ID=[AUEVENT]",
                actionType: "image",
              },
            ],
          },
          {
            eventName: "IABViewableImpression",
            actions: [
              {
                url: "[RTSURL]78&adgrpid=[C2]&supvend=[C3]&DVP_PP_IMP_ID=[AUEVENT]",
                actionType: "image",
              },
            ],
          },
          {
            eventName: "GroupMV4StandardPassedImpression",
            actions: [
              {
                url: "[RTSURL]94&adgrpid=[C2]&supvend=[C3]&DVP_PP_IMP_ID=[AUEVENT]",
                actionType: "image",
              },
            ],
          },
          {
            eventName: "IABAdViewable15Seconds",
            actions: [
              {
                url: "[RTSURL]84&adgrpid=[C2]&supvend=[C3]&DVP_PP_IMP_ID=[AUEVENT]",
                actionType: "image",
              },
            ],
          },
          {
            eventName: "CustomViewabilityViewable",
            actions: [
              {
                url: "[RTSURL]76&adgrpid=[C2]&supvend=[C3]&DVP_PP_IMP_ID=[AUEVENT]",
                actionType: "image",
              },
            ],
          },
          {
            eventName: "PMXStandardPassedImpression",
            actions: [
              {
                url: "[RTSURL]93&adgrpid=[C2]&supvend=[C3]&DVP_PP_IMP_ID=[AUEVENT]",
                actionType: "image",
              },
            ],
          },
          {
            eventName: "IABMeasuredImpression",
            actions: [
              {
                url: "[RTSURL]77&adgrpid=[C2]&supvend=[C3]&DVP_PP_IMP_ID=[AUEVENT]",
                actionType: "image",
              },
            ],
          },
          {
            eventName: "IABAdViewable5Seconds",
            actions: [
              {
                url: "[RTSURL]85&adgrpid=[C2]&supvend=[C3]&DVP_PP_IMP_ID=[AUEVENT]",
                actionType: "image",
              },
            ],
          },
        ],
        cdc: { z3pQ: 0, f7kR: 1, "8xJ1": 1, "5tG9": 1, p2Qz: 1 },
      },
      fd: {
        researchCollection: {
          adid: "2710108543176062008",
          d9: "3658259561767602418,-5488740230212662710",
          d13: "20261121",
          icat: "false",
          d12: "false",
          exti: "2848296441",
          d2: "0.05",
          crad: "false",
          tapt: "1",
          d14: "",
          d1: "10",
          impi: "cbcd801d4f094f3b8ada6ae132ffd071",
          dety: "1",
          d3: "rc20260909",
          urti: "1284",
          doha: "-5767225446047257874",
          d6: "",
        },
        isBsAllow: false,
      },
      ce: { ddt: 1, dt: 1 },
    }
  );
} catch (e) {
  try {
    var image = window.document.createElement("img");
    image.src =
      ("https://tps.doubleverify.com/visit.jpg" ||
        window.location.protocol + "//tps30.doubleverify.com/visit.jpg") +
      "?ctx=818052&cmp=1619415&dvtagver=6.1.src&dvp_cbError=" +
      encodeURIComponent(e.message);
  } catch (e) {}
}
try {
  $dv.pubSub.publish("ImpressionServed", $uid);
  $dv.pubSub.publish("ImpressionServed", $frmId);
} catch (e) {}
