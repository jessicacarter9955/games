/*! v11365 3b834c84 */
var __dv_global_script_start_time__ =
    "undefined" != typeof performance && "function" == typeof performance.now
      ? performance.now()
      : void 0,
  $dv,
  dvWindow,
  __webpack_modules__ = {
    2328: (t, e) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.DATA_NODE_KEY =
          e.MONITORING_TAG_ON_TOP_LEVEL_KEY =
          e.TRACKING_RATE_KEY =
          e.TRACKING_EVENT_CATEGORY =
          e.MAX_WINDOW_DEPTH =
            void 0),
        (e.MAX_WINDOW_DEPTH = 20),
        (e.TRACKING_EVENT_CATEGORY = "data-transparency"),
        (e.TRACKING_RATE_KEY = "dv-data-transparency-tracking-rate"),
        (e.MONITORING_TAG_ON_TOP_LEVEL_KEY =
          "dv-data-transparency-top-level-monitoring"),
        (e.DATA_NODE_KEY = "dv-data-transparency-data-node");
    },
    9522: (t, e) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.Container = void 0);
      var i = (function () {
        function t() {
          this.container = {};
        }
        return (
          Object.defineProperty(t.prototype, "size", {
            get: function () {
              return Object.keys(this.container).length;
            },
            enumerable: !1,
            configurable: !0,
          }),
          (t.prototype.isEmpty = function () {
            return 0 === this.size;
          }),
          (t.prototype.clear = function () {
            this.container = {};
          }),
          (t.prototype.get = function (t) {
            if (void 0 === this.container[t])
              throw new Error("undefined container item: " + t);
            return this.container[t];
          }),
          (t.prototype.set = function (t, e) {
            if (void 0 === e)
              throw new Error("cannot store undefined in container: " + t);
            this.container[t] = e;
          }),
          t
        );
      })();
      e.Container = i;
    },
    443: (t, e) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.coverageToBitFlag = void 0);
      e.coverageToBitFlag = function (t) {
        return (
          (t.sellerPageTag ? 1 : 0) |
          (t.sellerMonitoringTag ? 2 : 0) |
          (t.buyerMonitoringTag ? 4 : 0)
        );
      };
    },
    1064: (t, e, i) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.getAncestorWindows = void 0);
      var n = i(2328),
        s = function (t, e, i, n) {
          if (!(i >= n || t === t.top)) {
            var r = t.parent;
            r !== t && (e.unshift(r), s(r, e, i + 1, n));
          }
        };
      e.getAncestorWindows = function (t, e) {
        void 0 === e && (e = n.MAX_WINDOW_DEPTH);
        var i = [];
        try {
          s(t, i, 0, e);
        } catch (t) {}
        return i;
      };
    },
    1665: (t, e, i) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.getCorrespondentWindow = void 0);
      var n = i(1064);
      e.getCorrespondentWindow = function (t, e) {
        var i = (0, n.getAncestorWindows)(t);
        return i.length === e ? t : i.length > e ? i[e] : null;
      };
    },
    6172: (t, e) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.getCurrentTimestamp = void 0);
      e.getCurrentTimestamp = function () {
        var t, e;
        try {
          return null !==
            (e =
              null ===
                (t = null === Date || void 0 === Date ? void 0 : Date.now) ||
              void 0 === t
                ? void 0
                : t.call(Date)) && void 0 !== e
            ? e
            : 0;
        } catch (t) {}
        return 0;
      };
    },
    8839: (t, e, i) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.getDescendantWindows = void 0);
      var n = i(2328),
        s = function (t, e, i, n) {
          if (!(i >= n))
            for (var r = 0; r < t.length; r++) {
              var o = t[r];
              e.push(o), s(o, e, i + 1, n);
            }
        };
      e.getDescendantWindows = function (t, e) {
        void 0 === e && (e = n.MAX_WINDOW_DEPTH);
        var i = [];
        try {
          s(t, i, 0, e);
        } catch (t) {}
        return i;
      };
    },
    135: function (t, e, i) {
      "use strict";
      var n =
          (this && this.__createBinding) ||
          (Object.create
            ? function (t, e, i, n) {
                void 0 === n && (n = i),
                  Object.defineProperty(t, n, {
                    enumerable: !0,
                    get: function () {
                      return e[i];
                    },
                  });
              }
            : function (t, e, i, n) {
                void 0 === n && (n = i), (t[n] = e[i]);
              }),
        s =
          (this && this.__exportStar) ||
          function (t, e) {
            for (var i in t)
              "default" === i ||
                Object.prototype.hasOwnProperty.call(e, i) ||
                n(e, t, i);
          };
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.validateWindow =
          e.getDescendantWindows =
          e.getCurrentTimestamp =
          e.getCorrespondentWindow =
          e.getAncestorWindows =
          e.coverageToBitFlag =
          e.Container =
            void 0),
        s(i(2328), e);
      var r = i(9522);
      Object.defineProperty(e, "Container", {
        enumerable: !0,
        get: function () {
          return r.Container;
        },
      });
      var o = i(443);
      Object.defineProperty(e, "coverageToBitFlag", {
        enumerable: !0,
        get: function () {
          return o.coverageToBitFlag;
        },
      });
      var a = i(1064);
      Object.defineProperty(e, "getAncestorWindows", {
        enumerable: !0,
        get: function () {
          return a.getAncestorWindows;
        },
      });
      var d = i(1665);
      Object.defineProperty(e, "getCorrespondentWindow", {
        enumerable: !0,
        get: function () {
          return d.getCorrespondentWindow;
        },
      });
      var c = i(6172);
      Object.defineProperty(e, "getCurrentTimestamp", {
        enumerable: !0,
        get: function () {
          return c.getCurrentTimestamp;
        },
      });
      var l = i(8839);
      Object.defineProperty(e, "getDescendantWindows", {
        enumerable: !0,
        get: function () {
          return l.getDescendantWindows;
        },
      });
      var u = i(7924);
      Object.defineProperty(e, "validateWindow", {
        enumerable: !0,
        get: function () {
          return u.validateWindow;
        },
      });
    },
    7924: (t, e) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.validateWindow = void 0);
      e.validateWindow = function (t) {
        try {
          return (
            null != t &&
            null != t.top &&
            null != t.parent &&
            null != t.length &&
            t.window === t &&
            "function" == typeof t.postMessage
          );
        } catch (t) {
          return !1;
        }
      };
    },
    6777: function (t, e, i) {
      "use strict";
      var n =
          (this && this.__values) ||
          function (t) {
            var e = "function" == typeof Symbol && Symbol.iterator,
              i = e && t[e],
              n = 0;
            if (i) return i.call(t);
            if (t && "number" == typeof t.length)
              return {
                next: function () {
                  return (
                    t && n >= t.length && (t = void 0),
                    { value: t && t[n++], done: !t }
                  );
                },
              };
            throw new TypeError(
              e ? "Object is not iterable." : "Symbol.iterator is not defined."
            );
          },
        s =
          (this && this.__read) ||
          function (t, e) {
            var i = "function" == typeof Symbol && t[Symbol.iterator];
            if (!i) return t;
            var n,
              s,
              r = i.call(t),
              o = [];
            try {
              for (; (void 0 === e || e-- > 0) && !(n = r.next()).done; )
                o.push(n.value);
            } catch (t) {
              s = { error: t };
            } finally {
              try {
                n && !n.done && (i = r.return) && i.call(r);
              } finally {
                if (s) throw s.error;
              }
            }
            return o;
          },
        r =
          (this && this.__spreadArray) ||
          function (t, e, i) {
            if (i || 2 === arguments.length)
              for (var n, s = 0, r = e.length; s < r; s++)
                (!n && s in e) ||
                  (n || (n = Array.prototype.slice.call(e, 0, s)),
                  (n[s] = e[s]));
            return t.concat(n || Array.prototype.slice.call(e));
          };
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.DataNode = void 0);
      var o = i(135),
        a = i(6240),
        d = i(2749),
        c = i(4419),
        l = (function () {
          function t(t, e) {
            void 0 === e && (e = !1),
              (this.sharedState = (0, c.getEmptyState)()),
              (this.correspondents = []),
              (this.localTagSubscriptions = []),
              (this.dispatchMessageListeners = []),
              (this.hostWindow = t),
              (this.hostWindowDepth = (0, o.getAncestorWindows)(
                this.hostWindow
              ).length),
              (this.hubWindow = this.hostWindow),
              (this.hubWindowDepth = this.hostWindowDepth),
              (this.broadcastingDisabled = e);
          }
          return (
            Object.defineProperty(t.prototype, "depth", {
              get: function () {
                return this.hostWindowDepth;
              },
              enumerable: !1,
              configurable: !0,
            }),
            Object.defineProperty(t.prototype, "onDispatchMessage", {
              set: function (t) {
                this.dispatchMessageListeners.push(t);
              },
              enumerable: !1,
              configurable: !0,
            }),
            (t.prototype.isHub = function () {
              return this.hubWindow === this.hostWindow;
            }),
            (t.prototype.isAllowedToCorrespond = function () {
              return this.localTagSubscriptions.length > 0;
            }),
            (t.prototype.mergeState = function (t) {
              var e = (0, a.updateSharedState)(this.sharedState, t),
                i = e.newState,
                n = e.stateWasUpdated,
                s = e.inputWasIncomplete;
              return (
                (this.sharedState = i),
                { stateWasUpdated: n, inputWasIncomplete: s }
              );
            }),
            (t.prototype.composeMessage = function (t) {
              return (
                void 0 === t && (t = !1),
                {
                  sharedState: (0, d.copyState)(this.sharedState),
                  source: {
                    windowDepth: this.hostWindowDepth,
                    canBecomeHub: !0,
                    responseRequired: t,
                  },
                }
              );
            }),
            (t.prototype.registerCorrespondent = function (t, e, i) {
              t === this.hostWindow ||
                this.correspondents.includes(t) ||
                (this.correspondents.push(t),
                i &&
                  (null == this.hubWindow || e < this.hubWindowDepth) &&
                  ((this.hubWindow = t), (this.hubWindowDepth = e)));
            }),
            (t.prototype.dispatchMessage = function (t, e) {
              var i, s, r, a;
              if (0 !== e.length) {
                var d = {
                  command: "data-transparency-update",
                  payload: t,
                  timestamp: (0, o.getCurrentTimestamp)(),
                };
                try {
                  for (var c = n(e), l = c.next(); !l.done; l = c.next()) {
                    var u = l.value;
                    try {
                      u.postMessage(d, "*");
                    } catch (t) {}
                  }
                } catch (t) {
                  i = { error: t };
                } finally {
                  try {
                    l && !l.done && (s = c.return) && s.call(c);
                  } finally {
                    if (i) throw i.error;
                  }
                }
                try {
                  for (
                    var h = n(this.dispatchMessageListeners), v = h.next();
                    !v.done;
                    v = h.next()
                  ) {
                    (0, v.value)(d, e);
                  }
                } catch (t) {
                  r = { error: t };
                } finally {
                  try {
                    v && !v.done && (a = h.return) && a.call(h);
                  } finally {
                    if (r) throw r.error;
                  }
                }
              }
            }),
            (t.prototype.notifyLocalTags = function () {
              var t, e;
              try {
                for (
                  var i = n(this.localTagSubscriptions), s = i.next();
                  !s.done;
                  s = i.next()
                ) {
                  (0, s.value)(this.sharedState);
                }
              } catch (e) {
                t = { error: e };
              } finally {
                try {
                  s && !s.done && (e = i.return) && e.call(i);
                } finally {
                  if (t) throw t.error;
                }
              }
            }),
            (t.prototype.notifyAllowedCorrespondents = function (t) {
              if (this.isAllowedToCorrespond()) {
                var e = [];
                this.isHub()
                  ? e.push.apply(
                      e,
                      r(
                        [],
                        s(
                          this.correspondents.filter(function (e) {
                            return e !== t;
                          })
                        ),
                        !1
                      )
                    )
                  : this.hubWindow !== t && e.push(this.hubWindow),
                  this.dispatchMessage(this.composeMessage(), e);
              }
            }),
            (t.prototype.notifyCorrespondent = function (t) {
              this.isAllowedToCorrespond() &&
                this.dispatchMessage(this.composeMessage(), [t]);
            }),
            (t.prototype.broadCastState = function () {
              var t = this;
              if (!this.broadcastingDisabled && this.isAllowedToCorrespond())
                if ((this.notifyAllowedCorrespondents(), this.isHub()))
                  this.dispatchMessage(
                    this.composeMessage(!0),
                    r(
                      r([], s((0, o.getAncestorWindows)(this.hostWindow)), !1),
                      s((0, o.getDescendantWindows)(this.hostWindow)),
                      !1
                    ).filter(function (e) {
                      return !t.correspondents.includes(e);
                    })
                  );
                else {
                  var e = (0, o.getAncestorWindows)(this.hubWindow);
                  e.length > 0 &&
                    this.dispatchMessage(this.composeMessage(!0), e);
                }
            }),
            (t.prototype.ingestMessageFromCorrespondent = function (t, e) {
              var i = t.sharedState,
                n = t.source,
                s = (0, o.getCorrespondentWindow)(e, n.windowDepth);
              if (null != s) {
                this.registerCorrespondent(s, n.windowDepth, n.canBecomeHub);
                var r = this.mergeState(i),
                  a = r.stateWasUpdated,
                  d = r.inputWasIncomplete;
                a &&
                  (this.notifyLocalTags(),
                  this.isHub() && this.notifyAllowedCorrespondents(s));
                var c = this.isHub() && d,
                  l = this.isHub() && n.responseRequired,
                  u = s === this.hubWindow && n.responseRequired;
                (c || l || u) && this.notifyCorrespondent(s);
              }
            }),
            (t.prototype.registerLocalTagAndSubscribe = function (t, e) {
              void 0 === e && (e = function () {});
              var i = this.mergeState(t).stateWasUpdated,
                n = 0 === this.localTagSubscriptions.length;
              this.localTagSubscriptions.includes(e) ||
                this.localTagSubscriptions.push(e),
                i ? this.notifyLocalTags() : e(this.sharedState),
                n
                  ? this.broadCastState()
                  : i && this.notifyAllowedCorrespondents();
            }),
            t
          );
        })();
      e.DataNode = l;
    },
    4614: function (t, e, i) {
      "use strict";
      var n =
          (this && this.__createBinding) ||
          (Object.create
            ? function (t, e, i, n) {
                void 0 === n && (n = i),
                  Object.defineProperty(t, n, {
                    enumerable: !0,
                    get: function () {
                      return e[i];
                    },
                  });
              }
            : function (t, e, i, n) {
                void 0 === n && (n = i), (t[n] = e[i]);
              }),
        s =
          (this && this.__exportStar) ||
          function (t, e) {
            for (var i in t)
              "default" === i ||
                Object.prototype.hasOwnProperty.call(e, i) ||
                n(e, t, i);
          };
      Object.defineProperty(e, "__esModule", { value: !0 }),
        s(i(6777), e),
        s(i(8119), e),
        s(i(6240), e),
        s(i(3665), e);
    },
    8119: (t, e) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 });
    },
    457: (t, e) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.compareLinkingPriority = void 0);
      e.compareLinkingPriority = function (t, e) {
        return t.sharedId === e.sharedId
          ? 0
          : null == t.sharedId
          ? 2
          : null == e.sharedId
          ? 1
          : t.depth > e.depth
          ? 2
          : t.depth < e.depth
          ? 1
          : t.sharedId > e.sharedId
          ? 2
          : 1;
      };
    },
    5208: function (t, e) {
      "use strict";
      var i =
        (this && this.__read) ||
        function (t, e) {
          var i = "function" == typeof Symbol && t[Symbol.iterator];
          if (!i) return t;
          var n,
            s,
            r = i.call(t),
            o = [];
          try {
            for (; (void 0 === e || e-- > 0) && !(n = r.next()).done; )
              o.push(n.value);
          } catch (t) {
            s = { error: t };
          } finally {
            try {
              n && !n.done && (i = r.return) && i.call(r);
            } finally {
              if (s) throw s.error;
            }
          }
          return o;
        };
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.compareRecordPriority = void 0);
      e.compareRecordPriority = function (t, e, n) {
        return null != t && null != e
          ? (function (t, e) {
              return Object.entries(t).every(function (t) {
                var n = i(t, 2),
                  s = n[0],
                  r = n[1];
                return e[s] === r;
              });
            })(t, e)
            ? 0
            : n
          : null == t && null == e
          ? 0
          : null == e
          ? 1
          : 2;
      };
    },
    6240: (t, e, i) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.updateSharedState = void 0);
      var n = i(9276);
      Object.defineProperty(e, "updateSharedState", {
        enumerable: !0,
        get: function () {
          return n.updateSharedState;
        },
      });
    },
    9276: function (t, e, i) {
      "use strict";
      var n =
          (this && this.__assign) ||
          function () {
            return (
              (n =
                Object.assign ||
                function (t) {
                  for (var e, i = 1, n = arguments.length; i < n; i++)
                    for (var s in (e = arguments[i]))
                      Object.prototype.hasOwnProperty.call(e, s) &&
                        (t[s] = e[s]);
                  return t;
                }),
              n.apply(this, arguments)
            );
          },
        s =
          (this && this.__values) ||
          function (t) {
            var e = "function" == typeof Symbol && Symbol.iterator,
              i = e && t[e],
              n = 0;
            if (i) return i.call(t);
            if (t && "number" == typeof t.length)
              return {
                next: function () {
                  return (
                    t && n >= t.length && (t = void 0),
                    { value: t && t[n++], done: !t }
                  );
                },
              };
            throw new TypeError(
              e ? "Object is not iterable." : "Symbol.iterator is not defined."
            );
          };
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.updateSharedState = void 0);
      var r = i(2749),
        o = i(457),
        a = i(5208);
      e.updateSharedState = function (t, e) {
        var i,
          d,
          c = {
            newState: (0, r.copyState)(t),
            stateWasUpdated: !1,
            inputWasIncomplete: !1,
          },
          l = (0, o.compareLinkingPriority)(t.linking, e.linking);
        2 === l
          ? ((c.stateWasUpdated = !0), (c.newState.linking = n({}, e.linking)))
          : 1 === l && (c.inputWasIncomplete = !0);
        try {
          for (
            var u = s(Object.keys(t.coverage)), h = u.next();
            !h.done;
            h = u.next()
          ) {
            var v = h.value;
            e.coverage[v]
              ? t.coverage[v] ||
                ((c.stateWasUpdated = !0), (c.newState.coverage[v] = !0))
              : t.coverage[v] && (c.inputWasIncomplete = !0);
          }
        } catch (t) {
          i = { error: t };
        } finally {
          try {
            h && !h.done && (d = u.return) && d.call(u);
          } finally {
            if (i) throw i.error;
          }
        }
        var p = (0, a.compareRecordPriority)(t.visit, e.visit, l);
        2 === p
          ? ((c.stateWasUpdated = !0), (c.newState.visit = n({}, e.visit)))
          : 1 === p && (c.inputWasIncomplete = !0);
        var m = (0, a.compareRecordPriority)(
          t.sellerDimensions,
          e.sellerDimensions,
          l
        );
        return (
          2 === m
            ? ((c.stateWasUpdated = !0),
              (c.newState.sellerDimensions = n({}, e.sellerDimensions)))
            : 1 === m && (c.inputWasIncomplete = !0),
          c
        );
      };
    },
    2749: function (t, e) {
      "use strict";
      var i =
        (this && this.__assign) ||
        function () {
          return (
            (i =
              Object.assign ||
              function (t) {
                for (var e, i = 1, n = arguments.length; i < n; i++)
                  for (var s in (e = arguments[i]))
                    Object.prototype.hasOwnProperty.call(e, s) && (t[s] = e[s]);
                return t;
              }),
            i.apply(this, arguments)
          );
        };
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.copyState = void 0);
      e.copyState = function (t) {
        var e = { linking: i({}, t.linking), coverage: i({}, t.coverage) };
        return (
          null != t.visit && (e.visit = i({}, t.visit)),
          null != t.sellerDimensions &&
            (e.sellerDimensions = i({}, t.sellerDimensions)),
          e
        );
      };
    },
    4419: (t, e, i) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.getEmptyState = void 0);
      var n = i(135);
      e.getEmptyState = function () {
        return {
          linking: {
            sharedId: null,
            depth: 0,
            timestamp: (0, n.getCurrentTimestamp)(),
          },
          coverage: {
            sellerPageTag: !1,
            sellerMonitoringTag: !1,
            buyerMonitoringTag: !1,
          },
        };
      };
    },
    3665: (t, e, i) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.validateSharedState = e.validateMessageData = void 0);
      var n = i(5571);
      Object.defineProperty(e, "validateMessageData", {
        enumerable: !0,
        get: function () {
          return n.validateMessageData;
        },
      });
      var s = i(1149);
      Object.defineProperty(e, "validateSharedState", {
        enumerable: !0,
        get: function () {
          return s.validateSharedState;
        },
      });
    },
    5571: (t, e, i) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.validateMessageData = void 0);
      var n = i(1149);
      e.validateMessageData = function (t) {
        var e = t.command,
          i = t.payload,
          s = t.timestamp;
        if (
          "data-transparency-update" !== e ||
          null == i ||
          "number" != typeof s
        )
          return !1;
        var r = i.sharedState,
          o = i.source;
        return (
          null != r &&
          (0, n.validateSharedState)(r) &&
          (null == o ||
            ("number" == typeof o.windowDepth &&
              "boolean" == typeof o.responseRequired))
        );
      };
    },
    1149: (t, e) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.validateSharedState = void 0);
      e.validateSharedState = function (t) {
        return (
          null != t.linking &&
          (null == t.linking.sharedId ||
            "string" == typeof t.linking.sharedId) &&
          "number" == typeof t.linking.depth &&
          "number" == typeof t.linking.timestamp &&
          null != t.coverage &&
          "boolean" == typeof t.coverage.sellerPageTag &&
          "boolean" == typeof t.coverage.sellerMonitoringTag &&
          "boolean" == typeof t.coverage.buyerMonitoringTag &&
          (null == t.visit ||
            ("string" == typeof t.visit.pageUrl &&
              "string" == typeof t.visit.userAgent)) &&
          (null == t.sellerDimensions ||
            Object.values(t.sellerDimensions).every(function (t) {
              return "string" == typeof t;
            }))
        );
      };
    },
    659: (t, e, i) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.subscribe = e.initialize = e.coverageToBitFlag = void 0);
      var n = i(135),
        s = i(4614),
        r = i(422),
        o = i(135);
      Object.defineProperty(e, "coverageToBitFlag", {
        enumerable: !0,
        get: function () {
          return o.coverageToBitFlag;
        },
      });
      e.initialize = function (t) {
        try {
          (0, r.maybeInitializeDataNode)(t);
        } catch (t) {}
      };
      e.subscribe = function (t, e, i) {
        var o;
        try {
          o = (0, r.maybeInitializeDataNode)(t);
        } catch (t) {
          return;
        }
        if (null != o) {
          var a = {
            linking: {
              sharedId: i.impressionId,
              depth: o.depth,
              timestamp: (0, n.getCurrentTimestamp)(),
            },
            coverage: {
              sellerPageTag: !1,
              sellerMonitoringTag: i.isSellerTag,
              buyerMonitoringTag: !i.isSellerTag,
            },
            sellerDimensions: i.sellerDimensions,
          };
          try {
            (0, s.validateSharedState)(a) &&
              o.registerLocalTagAndSubscribe(a, e);
          } catch (t) {}
        }
      };
    },
    422: (t, e, i) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.maybeInitializeDataNode = void 0);
      var n,
        s = i(135),
        r = i(4614),
        o = i(8266),
        a =
          ((n = !1),
          function (t) {
            if (!n) {
              n = !0;
              try {
                var e = t[s.MONITORING_TAG_ON_TOP_LEVEL_KEY];
                null != e && e();
              } catch (t) {}
            }
          });
      e.maybeInitializeDataNode = function (t) {
        if (!(0, s.validateWindow)(t)) return null;
        if (t === t.top) return a(t), null;
        var e = t[s.DATA_NODE_KEY];
        return (
          null == e &&
            ((e = new r.DataNode(t)),
            (0, o.setMessageListener)(t, e),
            (t[s.DATA_NODE_KEY] = e)),
          e
        );
      };
    },
    8266: (t, e, i) => {
      "use strict";
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.setMessageListener = void 0);
      var n = i(135),
        s = i(4614);
      e.setMessageListener = function (t, e) {
        try {
          t.addEventListener("message", function (t) {
            (0, n.validateWindow)(t.source) &&
              (0, s.validateMessageData)(t.data) &&
              e.ingestMessageFromCorrespondent(t.data.payload, t.source);
          });
        } catch (t) {}
      };
    },
    4980: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BlockingClientErrorType = void 0),
        (e.BlockingClientErrorType = {
          DisplayGenXBlockingCallbackError: {
            id: 16384,
            message: "DisplayGenXBlockingCallbackError",
            isLostImpression: !1,
          },
        });
    },
    9090: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ErrorHandler = void 0);
      const n = i(1906);
      e.ErrorHandler = (t, e, i) => ({
        createErrorRequestParamsObject: (t, n = "") =>
          Object.assign(
            {
              flvr: "1",
              ee_dp_ctx: e.getClientCode() || "",
              ee_dp_cmp: e.getAdServerCampaignCode(),
              ee_dp_plc: e.getPlacementId() || "",
              ee_dp_sid: e.getAdServerSiteCode() || "",
              ctx: "818052",
              cmp: "1619415",
              dvp_isLostImp: "1",
              ssl: "1",
              gdpr: e.getGDPR() || "",
              gdpr_consent: e.getGDPRConsent() || "",
              ver: i.getDvtpScriptVersion(),
              cerrt: t.toString(),
            },
            n && { cemsg: n }
          ),
        generateErrorQueryString: (t) =>
          n.Utilities.serializeObjectToQueryString(t, !1),
        reportError(e, i = "") {
          const n = this.createErrorRequestParamsObject(e, i),
            s = `https://rtb0.doubleverify.com/verify.js?${this.generateErrorQueryString(
              n
            )}`;
          t.sendBeacon(s, !0);
        },
      });
    },
    794: (t, e, i) => {
      e.MG = void 0;
      var n = i(5262);
      Object.defineProperty(e, "MG", {
        enumerable: !0,
        get: function () {
          return n.BlockingHandler;
        },
      });
      var s = i(9090);
      var r = i(8359);
      var o = i(7736);
      var a = i(1753);
    },
    5262: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BlockingHandler = void 0);
      const n = i(4980),
        s = i(9090),
        r = i(8359);
      e.BlockingHandler = (t, e, i, o, a, d, c = {}) => ({
        displayGenXBlockingCallback(t) {
          var e, i;
          const s = this.getPartnerBlockingCallbackFunctionName();
          if (!s) return;
          const r = this.resolvePartnerBlockingCallback(s);
          if ("function" == typeof r)
            null === (e = c.utils) ||
              void 0 === e ||
              e.setSafeTimeout(() => {
                var e, i, o;
                try {
                  r({ block: t });
                } catch (t) {
                  null === (e = c.sendError) ||
                    void 0 === e ||
                    e.call(
                      c,
                      n.BlockingClientErrorType
                        .DisplayGenXBlockingCallbackError,
                      null !==
                        (o =
                          null === (i = c.utils) || void 0 === i
                            ? void 0
                            : i.toError(t)) && void 0 !== o
                        ? o
                        : new Error("Unknown error"),
                      `invocationError ${s}`
                    );
                }
              }, 0);
          else {
            const t = `Failed to resolve callback: ${r} is not a function.`;
            null === (i = c.sendError) ||
              void 0 === i ||
              i.call(
                c,
                n.BlockingClientErrorType.DisplayGenXBlockingCallbackError,
                new Error(t),
                `callbackResolutionError ${s}`
              );
          }
        },
        partnerVideoBlockingCallback(t) {
          var e, i, n;
          if (t)
            try {
              const t = a.getVideoBlockingCallbackUrl();
              if (t && "string" == typeof t) {
                const e = decodeURIComponent(t);
                navigator.sendBeacon(e);
              }
            } catch (t) {
              this.errorHandler().reportError(
                4096,
                null !==
                  (n =
                    null ===
                      (i =
                        null === (e = c.utils) || void 0 === e
                          ? void 0
                          : e.toError(t)) || void 0 === i
                      ? void 0
                      : i.message) && void 0 !== n
                  ? n
                  : String(t)
              );
            }
        },
        blockingDecisionCallback(i) {
          var n;
          const s = [1, 5].includes(i),
            r = this.resolveExecutionMode(),
            o = [2, 0].includes(r);
          if (
            (null === (n = c.sendMessage) ||
              void 0 === n ||
              n.call(c, { blkmode: r }),
            o)
          ) {
            if (1 === a.getTagType())
              return void this.partnerVideoBlockingCallback(s);
            2 === r && this.displayGenXBlockingCallback(s);
          }
          if (!s && 4 !== i)
            if (a.getIsMonitoringEnabled()) e(t);
            else if (2 === r) {
              const t = this.resolvePartnerCreativeContainer();
              try {
                t && (t.style.visibility = "");
              } catch (t) {}
            }
        },
        initDvbsGlobalObject() {
          var t;
          if (window.$dvbs) return;
          window.$dvbs = window.$dv;
          const e = null === (t = c.o) || void 0 === t ? void 0 : t.call(c);
          !window.$dvbs.pubSub && e && (window.$dvbs.pubSub = e);
        },
        resolvePartnerCreativeContainer() {
          const t = a.getPartnerContainerId();
          return t ? document.getElementById(t) : null;
        },
        getPartnerBlockingCallbackFunctionName: () =>
          a.getPartnerBlockingCallbackFnName(),
        resolvePartnerBlockingCallback: (t) => window[t],
        errorHandler: () => (0, s.ErrorHandler)(i, a, o),
        resolveExecutionMode: () =>
          1 === a.getTagType() ? 0 : a.isDisplayGenXEnabled() ? 2 : 1,
        extractComponent: (t) =>
          t.innerHTML.replace(/<\/scr\+ipt>/g, "</script>").trim(),
        extractDisplayLegacyTagComponents(t) {
          var e;
          const i = (t) => {
              var e;
              return (
                "text/adtag" ===
                (null === (e = null == t ? void 0 : t.getAttribute("type")) ||
                void 0 === e
                  ? void 0
                  : e.toLowerCase())
              );
            },
            n = (t) => {
              var e;
              return (
                "text/passback" ===
                (null === (e = null == t ? void 0 : t.getAttribute("type")) ||
                void 0 === e
                  ? void 0
                  : e.toLowerCase())
              );
            },
            s = [
              null == t ? void 0 : t.previousElementSibling,
              null === (e = null == t ? void 0 : t.previousElementSibling) ||
              void 0 === e
                ? void 0
                : e.previousElementSibling,
            ].filter(
              (t) =>
                !!t &&
                "script" === t.tagName.toLowerCase() &&
                ((t) => t.innerHTML.trim())(t) &&
                (i(t) || n(t))
            );
          if (1 === s.length) {
            const [t] = s;
            if (i(t))
              return {
                isBadImplementation: !1,
                passback: null,
                adTag: this.extractComponent(t),
              };
          } else if (2 === s.length) {
            const [t, e] = s;
            if (n(t) && i(e))
              return {
                isBadImplementation: !1,
                passback: this.extractComponent(t),
                adTag: this.extractComponent(e),
              };
          }
          return { isBadImplementation: !0, passback: null, adTag: null };
        },
        buildBlockingContext() {
          const t = this.resolveExecutionMode();
          switch (t) {
            case 2:
              return {
                executionMode: t,
                creativeContainer: this.resolvePartnerCreativeContainer(),
              };
            case 1:
              return Object.assign(
                { executionMode: t },
                this.extractDisplayLegacyTagComponents(o.getTagScriptElem())
              );
            case 0:
              return { executionMode: t };
          }
        },
        execute() {
          var n, s, l, u, h, v;
          try {
            this.initDvbsGlobalObject();
            const u = this.buildBlockingContext(),
              h = (0, r.VerifyHandler)(
                t,
                d,
                i,
                a,
                o,
                u,
                this.blockingDecisionCallback.bind(this),
                this.errorHandler(),
                e,
                c
              );
            try {
              h.doVerifyRequest();
            } catch (t) {
              this.errorHandler().reportError(
                1024,
                "Send verify request failed. " +
                  (null !==
                    (l =
                      null ===
                        (s =
                          null === (n = c.utils) || void 0 === n
                            ? void 0
                            : n.toError(t)) || void 0 === s
                        ? void 0
                        : s.message) && void 0 !== l
                    ? l
                    : String(t))
              );
            }
          } catch (t) {
            this.errorHandler().reportError(
              8192,
              null !==
                (v =
                  null ===
                    (h =
                      null === (u = c.utils) || void 0 === u
                        ? void 0
                        : u.toError(t)) || void 0 === h
                    ? void 0
                    : h.message) && void 0 !== v
                ? v
                : String(t)
            );
          }
        },
      });
    },
    1753: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.requiredTpsParams =
          e.optionalTpsParams =
          e.collectedTpsParams =
            void 0),
        (e.collectedTpsParams = [
          "additionalUrlDepth",
          "browserId",
          "browserIdUserAgent",
          "browserVersion",
          "cookieLength",
          "documentElementCount",
          "domainLookupTime",
          "historyLength",
          "idcResults",
          "idcVersion",
          "iframeCount",
          "innerHeight",
          "innerWidth",
          "isChrome",
          "numberOfCores",
          "outerHeight",
          "outerWidth",
          "postMessageSupported",
          "referrerDepth",
          "referrerUrlExtractedFromSafeFrame",
          "screenHeight",
          "screenWidth",
          "jsver",
          "uid",
          "widgetCount",
          "windowDepth",
          "timeToFirstReportMs",
        ]),
        (e.optionalTpsParams = ["eparams", "referrerUrl", "vastWrapperUrl"]),
        (e.requiredTpsParams = [
          "adid",
          "adsrv",
          "advid",
          "app",
          "cmp",
          "crt",
          "ctx",
          "dup",
          "gmnpo",
          "isdvvid",
          "plc",
          "sid",
          "supplySource",
          "tagtype",
          "unit",
        ]);
    },
    8359: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VerifyHandler = void 0);
      const n = i(4112),
        s = i(1906),
        r = i(1753),
        o = i(7736);
      e.VerifyHandler = (t, e, i, a, d, c, l, u, h, v = {}) => ({
        impressionId: "",
        isJSONPCalled: !1,
        serverPublicDns: "",
        appendTpsParam: (e, i) =>
          Object.assign(e, { [n.TPSDataMapping[i]]: t[i] }),
        assertRequiredParams(t) {
          const e = Object.assign({}, t);
          return (
            r.requiredTpsParams.forEach((i) => {
              i in t || (e[i] = "");
            }),
            e
          );
        },
        buildRequestUrl(t, e) {
          let i = `https://rtb0.doubleverify.com/verify.js?${s.Utilities.serializeObjectToQueryString(
              t,
              !1
            )}`,
            n = !1;
          return (
            Object.keys(e)
              .filter(
                (t) => Object.prototype.hasOwnProperty.call(e, t) && !!e[t]
              )
              .forEach((t) => {
                const r = e[t],
                  o = s.Utilities.serializeObjectToQueryString({ [t]: r }, !1),
                  a = i.length + o.length + 1;
                s.Utilities.isExceedingMaxUrlLength(a)
                  ? (n = !0)
                  : (i += "&" + o);
              }),
            n && (i += "&dvf=3"),
            i
          );
        },
        buildVerifyRequestObj() {
          var e, i;
          const s = a.getLowerCaseParams(),
            o = this.assertRequiredParams(s),
            l = r.collectedTpsParams.reduce(
              (t, e) => this.appendTpsParam(t, e),
              {}
            ),
            u = Object.assign(
              Object.assign(
                Object.assign(
                  Object.assign(
                    Object.assign(
                      Object.assign(
                        Object.assign(
                          Object.assign(
                            Object.assign(
                              Object.assign(
                                {
                                  num: 6,
                                  dvp_isOnHead:
                                    "HEAD" ===
                                    (null ===
                                      (i =
                                        null === (e = d.getTagScriptElem()) ||
                                        void 0 === e
                                          ? void 0
                                          : e.parentElement) || void 0 === i
                                      ? void 0
                                      : i.tagName)
                                      ? 1
                                      : 0,
                                  flvr: "1",
                                  ver: 11365,
                                  jsCallback: this.generateVerifyCallbackName(),
                                  jsTagObjCallback:
                                    this.generateTagCallbackName(),
                                  ssl: 1,
                                },
                                1 === c.executionMode &&
                                  c.isBadImplementation && { isbadimp: 1 }
                              ),
                              t.isMraid && { [n.TPSDataMapping.isMraid]: 1 }
                            ),
                            t.isPreRender && { prndr: 1 }
                          ),
                          t.dvpParamsFlags && { dvf: t.dvpParamsFlags }
                        ),
                        t.safeFrameExists && { sfe: 1 }
                      ),
                      t.hijackedDeviceSignatureBits > 0 && {
                        hdsig: t.hijackedDeviceSignatureBits,
                      }
                    ),
                    t.idcError && { dvp_idcerr: t.idcError }
                  ),
                  t.browserFeatures && { m1: t.browserFeatures }
                ),
                t.browserSignatureBits &&
                  t.browserSignatureFamilyBits && {
                    bsig: t.browserSignatureFamilyBits,
                    usig: t.browserSignatureBits,
                  }
              ),
              { blkmode: c.executionMode, ee_dp_rdystreq: document.readyState }
            ),
            h = r.optionalTpsParams.reduce(
              (t, e) => this.appendTpsParam(t, e),
              {}
            );
          Object.keys(h).forEach((t) => {
            try {
              delete o[t];
            } catch (t) {}
          });
          const v = Object.assign({}, o, l, u, t.additionalParams);
          return {
            params: this.filterRequestObject(v),
            lowPriorityParams: this.filterRequestObject(h),
          };
        },
        doVerifyRequest() {
          this.initPerformanceMetrics();
          const { params: t, lowPriorityParams: e } =
              this.buildVerifyRequestObj(),
            i = this.buildRequestUrl(t, e),
            n = this.generateScriptId(),
            r = this.generateOnErrorCallback(),
            o = this.generateOnLoadCallback(),
            a = this.generateTagCallbackName(),
            c = this.generateVerifyCallbackName();
          this.injectTagObjectCallback(a),
            this.injectVerifyCallback(c),
            this.injectVerifyTag(i, n, r, o),
            d.setVerifyInjectedMS(s.Utilities.getCurrentTime());
        },
        filterRequestObject(t) {
          const e = Object.keys(t).filter((e) => {
            const i = t[e];
            return (
              !(null == i) &&
              (!!(
                "number" == typeof i ||
                "string" == typeof i ||
                "boolean" == typeof i
              ) ||
                (Array.isArray(i) ? i.length > 0 : Object.keys(i).length > 0))
            );
          });
          return s.Utilities.pick(t, e);
        },
        injectTagObjectCallback(i) {
          const n = e.currentWindow(),
            s = this;
          n[i] = (e) => {
            var i, n;
            const r = d.u(),
              o = e.ImpressionID;
            (s.impressionId = o),
              (t.bsimpid = o),
              (s.serverPublicDns = e.ServerPublicDns),
              r.tagData || (r.tagData = {}),
              r.tags || (r.tags = {}),
              (r.tags[o] = this.buildTagObject(e)),
              null === (i = v.onImpressionIdAssigned) ||
                void 0 === i ||
                i.call(v, o);
            const c = d.u();
            (null === (n = c.pubSub) || void 0 === n
              ? void 0
              : n.excludeFrameId) && c.pubSub.excludeFrameId(e.ImpressionID),
              a.setBlockingServerPrefix(`https://${e.ServerPublicDns}/`);
          };
        },
        generateDefaultPassback: (t, e) =>
          decodeURIComponent(
            "%3Cdiv%20style%3D%22display%3A%20flex%3B%20align-items%3A%20center%3B%20justify-content%3A%20center%3B%20width%3A%20" +
              t +
              "px%3B%20height%3A%20" +
              e +
              "px%3B%20outline-offset%3A%20-1px%3B%20background%3A%20url('data%3Aimage%2Fpng%3Bbase64%2CiVBORw0KGgoAAAANSUhEUgAAADoAAAA6CAYAAAGWvHq%2BAAAABmJLR0QA%2FwD%2FAP%2BgvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH5AQBECEbFuFN7gAAAB1pVFh0Q29tbWVudAAAAAAAQ3JlYXRlZCB3aXRoIEdJTVBkLmUHAAAFBklEQVRo3uUby3arOEzxAbxIyKLt%2F%2F9gIQtIF4aFZ5ERVxhJyIbcnjmjTZLast4vQ%2BG762OMMX53fQzTFIfxGenfKvgXvj4%2FoOsfy3eECgBgmmcYhnFZ6PoHeO%2F%2FbBiGEQAAxufPghlC%2BLOBYqa%2FHezAJcYYOUz87QAA7vd2g4lMAsrLfQJ%2BQeUM43PZsMJEwN8L58gMfgIAAMVKv6syX4bxGVF9qTiuvV2Byouf7e0Kl%2B%2Buj6kJU8aktV07aFClTkThfm9hGMbNGu53dCNd%2FPr8gBCm5TsnAivz%2BPwBqkHvPaDiVvpAW6Nh0FBhmpagSdfQV0Q7oVySPrz3LyO3t%2BvCKrJIHTtdG58%2FvLycZk%2Bzr1uFkgFWuYHKZHHNEMIr4lMb0pO5v7e3qyyj983KATYydv1jswFZneZ5wzaKVaEMVnNgjsw2B8pcbMdLmKbY1PVG5dTl0rVpnsGlSDReOcfo%2Bgc0df3SagrTPC8m4aDrH1ClaR4AgHKRmgN%2FL9HBbeI4wdKVitXUtYpLGXPSgpUg1lBaPzWCWW6wJ4lkB9aFUL1pQkXOvW9WBDltULNM8wwhTEtIcQn88t31kdpEU7FmOwsemqiiqtPsQvufXMCmCulUSKy9XaG9XYGrLhbv1iSlWU0NGdyQqlPKBHQfh0vxVkQ1abSQybX3oQ7nUPWUpEQ1oaokLVAnSfG4cy8xxpjrEFyVtuCJNt3rETDgu%2F6xiT9zRqKSci0DxzHdZ5E0zXabjGTtwSxr9FyqjazSJkmTi%2Bckb01BS5HaGnems%2BZWzdb62qQTfQdwDDl2Wj0RuKnYpX1sDrJljcvHTqow4%2FNn5SBNXYuzPD0Y8agDsRlpr3NIg1vyYGnSS%2BPUURVIcRhC2A0ZyYPxTKqNyuo8IYRlpMSGLYRJDRdOYyEEqEpDIIfY5qYhhLBrL0s%2BLS7imqq995tijYVdCxlx0EMnaW9XlvD93m4aZ0s4cZ3gqspYOjppRKcMcXipGZyU7Ju63iXIhVOKx53trCWqtMpwZzor8n%2BqynBnnlJlNGa5M51VSmlksBSDlOHlKk%2FzUq0KcVVEYgidytz3coS19lPrFh1y2fUP1Xu1HKsRxHWakao9hLNglZHeESaal3vvocKx3zKP7BXnLJtaxgNkjKY1Wp1y7inYUVG7Akg79vSeKefKwHJ1kEtTikBxJrYkmpIBr1TgPdgbrZ1WkPbuz84UEiNZG1ZLhdydE0sqeqlytGG2pEt4%2B0Ccc9H8zs4kS1Br0542F0fqR0lesOCwyehoIioZq86gqcWq6XbZwrTGqMSAhmOhKWVpjp74PObIsLt3R3g0g1oETs8R32woFbLEHUuEs9CiZa6SslZJmpcuf%2F4GcNc0tDf9lYcxvwGVrI3mkDVeY0NjbumOui9XCtkYlZJIbjt3pF8tzQ0czZTvTXnJSdlHSstRXAlPUpQ4vRy1TK4nnNEwaDTd2ZNE6fQSQiieevBiprjXLamjpco5Mv1YSuH%2Fpry4o%2BMPN70cgZI4tYyG7h3J4evzI1tJ%2BIynBLTHMdnlpXQKsTQCkoAaPakZEctL%2BpbK0Y7FMkloCnrXHMsKileMpS0ZR3zvveez2kDJG6szRiSuJqaulfbOaQJ5KfcYH5wnLK82v2uMCmHaPDz%2BDVj%2BfSNNBGdZmIu9v6EIKWbVZHTmVYrl9clSRVsS0urOKDdlW1J%2B6SubFoH3SiF13X8A3uobUgsAG3MAAAAASUVORK5CYII%3D')%20repeat%3B%20outline%3A%20solid%201px%20%23969696%3B%22%3E%3C%2Fdiv%3E"
          ),
        generateEmptyPassback: (t, e) =>
          decodeURIComponent(
            "%3Cstyle%3E%0A.dvbs_container%20%7B%0A%09border%3A%201px%20solid%20%233b599e%3B%0A%09overflow%3A%20hidden%3B%0A%09filter%3A%20progid%3ADXImageTransform.Microsoft.gradient(startColorstr%3D%27%23315d8c%27%2C%20endColorstr%3D%27%2384aace%27)%3B%0A%7D%0A%3C%2Fstyle%3E%0A%3Cdiv%20class%3D%22dvbs_container%22%20style%3D%22width%3A%20" +
              t +
              "px%3B%20height%3A%20" +
              e +
              "px%3B%22%3E%09%0A%3C%2Fdiv%3E"
          ),
        exposeContainer(t) {
          t.style.visibility = "";
        },
        generateIframeElement(t, e = null, i = null) {
          const n = `\n      <html style="margin:0; padding:0; overflow:hidden;">\n        <head></head>\n        <body style="margin:0; padding:0; overflow:hidden;">\n          ${t}\n        </body>\n      </html>`,
            s = document.createElement("iframe");
          return (
            (s.style.border = "0"),
            (s.style.height = i ? `${i}px` : "100%"),
            (s.style.width = e ? `${e}px` : "100%"),
            (s.style.overflow = "hidden"),
            (s.srcdoc = n),
            s
          );
        },
        getInjectionTarget() {
          var t;
          const i = d.getTagScriptElem(),
            n = null == i ? void 0 : i.parentElement;
          if (n && "HEAD" !== n.tagName)
            return { parent: n, anchor: i.nextSibling, isHeadFallback: !1 };
          const s = e.currentDocument();
          return {
            parent:
              null !== (t = s.body) && void 0 !== t
                ? t
                : s.documentElement.appendChild(s.createElement("body")),
            anchor: null,
            isHeadFallback: !0,
          };
        },
        injectPassbackContent(t, e = null, i = null) {
          const n = this.generateIframeElement(t, e, i);
          try {
            if (1 === c.executionMode) {
              const {
                parent: s,
                anchor: r,
                isHeadFallback: o,
              } = this.getInjectionTarget();
              e && i
                ? s.insertBefore(n, r)
                : o
                ? s.insertAdjacentHTML("beforeend", t)
                : d.getTagScriptElem().insertAdjacentHTML("afterend", t);
            } else if (2 === c.executionMode) {
              const t = c.creativeContainer;
              (t.innerHTML = ""), t.appendChild(n);
            }
          } catch (t) {}
        },
        injectVerifyCallback(n) {
          const s = e.currentWindow(),
            r = this;
          s[n] = (n) => {
            var s, d, l, u, p, m, f, g, b, w;
            (this.isJSONPCalled = !0),
              r.shouldInvokeVpaidCallback() &&
                (null === (s = v.utils) ||
                  void 0 === s ||
                  s.setSafeTimeout(() => {
                    (0, o.VpaidHandler)(
                      n,
                      i,
                      t,
                      r.impressionId,
                      a.getBlockingServerPrefix(),
                      a.getAdID(),
                      a.getBlockingPartnerCallbackName(),
                      h,
                      v.utils
                    ).execute();
                  }, 0));
            const _ = a.getAdSize(),
              y = _ ? _.width : null,
              S = _ ? _.height : null,
              M =
                null ===
                  (l =
                    null === (d = n.ServerContext) || void 0 === d
                      ? void 0
                      : d.ce) || void 0 === l
                  ? void 0
                  : l.ddt;
            switch (n.ResultID) {
              case 1: {
                let t;
                1 === c.executionMode && c.passback
                  ? (t = c.passback)
                  : n.Passback
                  ? (t = decodeURIComponent(n.Passback))
                  : y && S && (t = this.generateDefaultPassback(y, S)),
                  t &&
                    (this.injectPassbackContent(t, y, S),
                    2 === c.executionMode &&
                      this.exposeContainer(c.creativeContainer));
                break;
              }
              case 2:
              case 3:
                if (1 === c.executionMode) {
                  const t = document.readyState,
                    {
                      parent: i,
                      anchor: n,
                      isHeadFallback: s,
                    } = this.getInjectionTarget();
                  if ("loading" === document.readyState)
                    if (y && S) {
                      const e = this.generateIframeElement(c.adTag, y, S);
                      i.insertBefore(e, n),
                        null === (u = v.registerEventCall) ||
                          void 0 === u ||
                          u.call(v, this.impressionId, {
                            ee_dp_rdystres: t,
                            ee_dp_injm: 1,
                            ee_dp_ddtvres: null != M ? M : -1,
                            ee_dp_tsinhd: s ? 1 : 0,
                          });
                    } else {
                      let i;
                      e.currentDocument().write(c.adTag);
                      try {
                        const t = c.adTag.trim().substring(0, 10),
                          e = document.querySelector(
                            'script[src*="verify.js"][src*="plc=' +
                              a.getPlacementId() +
                              '"]'
                          ),
                          n =
                            null ===
                              (p = null == e ? void 0 : e.nextElementSibling) ||
                            void 0 === p
                              ? void 0
                              : p.outerHTML.trim().substring(0, 10);
                        i = t == n ? 1 : 0;
                      } catch (t) {
                        i = -1;
                      }
                      null === (m = v.registerEventCall) ||
                        void 0 === m ||
                        m.call(
                          v,
                          this.impressionId,
                          {
                            ee_dp_rdystres: t,
                            ee_dp_atcatd: i,
                            ee_dp_injm: 2,
                            ee_dp_ddtvres: null != M ? M : -1,
                          },
                          !1
                        );
                    }
                  else if (y && S) {
                    null === (f = v.registerEventCall) ||
                      void 0 === f ||
                      f.call(v, this.impressionId, {
                        ee_dp_plip: 2,
                        ee_dp_tsinhd: s ? 1 : 0,
                      });
                    const t = this.generateIframeElement(c.adTag, y, S);
                    i.insertBefore(t, n);
                  } else {
                    null === (g = v.registerEventCall) ||
                      void 0 === g ||
                      g.call(v, this.impressionId, {
                        ee_dp_plip: 3,
                        ee_dp_tsinhd: s ? 1 : 0,
                      });
                    const t = document
                      .createRange()
                      .createContextualFragment(c.adTag);
                    i.appendChild(t);
                  }
                }
                break;
              case 4:
                if (y && S) {
                  const t = this.generateEmptyPassback(y, S);
                  this.injectPassbackContent(t),
                    2 === c.executionMode &&
                      this.exposeContainer(c.creativeContainer);
                }
                null === (b = v.registerEventCall) ||
                  void 0 === b ||
                  b.call(v, this.impressionId, {
                    ee_dp_blkprmv: a.getParamValue("blk"),
                  });
            }
            null === (w = v.executeTagExtensions) ||
              void 0 === w ||
              w.call(v, r.impressionId, n.ServerContext || {}),
              this.reportPerformanceMetrics(),
              this.reportBlockDecision(n.ResultID);
          };
        },
        generateOnErrorCallback() {
          return () => {
            this.reportError(2), this.renderAdFromError("VFTL");
          };
        },
        generateOnLoadCallback() {
          return () => {
            this.isJSONPCalled ||
              (this.reportError(1), this.renderAdFromError("VCF"));
          };
        },
        generateScriptId: () => `verify-call-${d.getTagUniqueKey()}`,
        generateTagCallbackName: () => `__tagObject_callback_${t.uid}`,
        generateVerifyCallbackName: () => `__verify_callback_${t.uid}`,
        initPerformanceMetrics() {
          e.isPerformanceAPISupported() &&
            e.workingWindow().performance.mark("dv_create_req_start");
          const i = d.getTagLoadedMS(),
            n = s.Utilities.getCurrentTime();
          t.timeToFirstReportMs = n - i;
        },
        injectVerifyTag(t, n, s, r) {
          const o = e.currentDocument(),
            a = e.getCurrentScript() || o.body;
          1 !== c.executionMode || "loading" !== document.readyState
            ? i.addScriptAsync(t.toString(), a, n, s, r)
            : i.addScriptSync(t.toString(), o);
        },
        renderAdFromError(t = "") {
          let e = "AdRenderedUponVerifyFailure__" + t;
          try {
            2 === c.executionMode && this.exposeContainer(c.creativeContainer);
          } catch (t) {
            e += "__RenderingMethodFailed";
          }
          this.reportError(512, e);
        },
        reportBlockDecision(t) {
          try {
            l(t);
          } catch (t) {}
        },
        reportPerformanceMetrics() {
          var t;
          try {
            const i = e.currentWindow(),
              n = e.monitorScriptsPerformance(i, {
                verify: ["duration", "transferSize"],
                dvbm: ["duration"],
              });
            null === (t = v.registerEventCall) ||
              void 0 === t ||
              t.call(v, this.impressionId, {
                tgdur: n.dvbm_duration,
                vfdur: n.verify_duration,
                vfsz: n.verify_transferSize,
                tuveims: d.getVerifyInjectedMS() - d.getTagLoadedMS(),
                tuveems: s.Utilities.getCurrentTime() - d.getTagLoadedMS(),
              });
          } catch (t) {}
        },
        reportError(t, e) {
          u.reportError(t, null != e ? e : "");
        },
        buildTagObject(e) {
          const i = { dv_protocol: "https:" };
          return (
            (i.ServerPublicDns = e.ServerPublicDns),
            (i.tagElement = d.getTagScriptElem()),
            (i.type = "blocking"),
            (i.uid = t.uid),
            i
          );
        },
        shouldInvokeVpaidCallback() {
          const t = a.getAdID();
          return 1 === a.getTagType() && t.length > 0;
        },
      });
    },
    7736: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VpaidHandler = void 0);
      const n = i(1906);
      e.VpaidHandler = (t, e, i, s, r, o, a, d, c) => ({
        wasMonitoringInjected: !1,
        execute() {
          this.reportBsEvent({ ee_dp_vfinit: 1 }),
            this.injectResponseReceivedCallback(),
            this.bindVideoEvents();
        },
        bindOrReportVideoEvent(t, e) {
          const i = this.getPreviousVpaidEvents(),
            n = this;
          if (i.indexOf(t) > -1) n.reportVideoTimingEvent(e);
          else {
            const i = () => {
              n.reportVideoTimingEvent(e);
            };
            this.getVpaidWrapper().subscribe(i, t);
          }
        },
        bindVideoEvents() {
          try {
            const t = this.getVpaidWrapper();
            if (
              (null == t ? void 0 : t.getPreviousEvents) &&
              "function" == typeof t.getPreviousEvents
            ) {
              if (t.getPreviousEvents().includes("AdStarted"))
                this.initiateMonitoring("ad_started_triggered");
              else {
                const e = this.initiateMonitoring.bind(this);
                t.subscribe(() => {
                  e("ad_started_subscribe");
                }, "AdStarted");
              }
              this.bindOrReportVideoEvent("AdError", "ee_dp_ader"),
                this.bindOrReportVideoEvent("AdStopped", "ee_dp_adstp"),
                this.bindOrReportVideoEvent("AdVideoStart", "ee_dp_avse"),
                this.bindOrReportVideoEvent("AdImpression", "ee_dp_aie");
            } else
              this.reportBsEvent({
                cerrt: 16,
                cemsg: "vpaidWrapper.getPreviousEvents not a function",
              });
          } catch (t) {
            this.reportBsEvent({
              cerrt: 8,
              cemsg: t.message,
              ee_dp_vwn: o,
              ee_dp_vwt: typeof window[o],
            });
          }
        },
        buildEventUrl(t) {
          return `${this.generateBsEventBaseUrl()}&${n.Utilities.serializeObjectToQueryString(
            t,
            !0
          )}`;
        },
        generateBsEventBaseUrl() {
          const t = "impid=" + encodeURIComponent(s);
          return `${r}bsevent.gif?${t}`;
        },
        generateResponseReceivedCallbackName: () => `responseReceived_${s}`,
        generateTimestamp() {
          try {
            return Date.now();
          } catch (t) {
            return new Date().getTime();
          }
        },
        getEventParams(t) {
          const e = this.resolveOriginalResultId();
          let i,
            n = e;
          if (!t)
            switch (((n = 2), e)) {
              case 1:
                i = 21;
                break;
              case 2:
                i = 20;
                break;
              case 3:
                i = 22;
                break;
              case 4:
                i = 23;
            }
          const s = t ? "1" : "0";
          return Object.assign({ bres: n, ee_dp_bdu: s }, i && { breason: i });
        },
        getPreviousVpaidEvents() {
          return this.getVpaidWrapper().getPreviousEvents();
        },
        getVpaidWrapper: () => window[o](),
        initiateMonitoring(t) {
          this.wasMonitoringInjected ||
            ((this.wasMonitoringInjected = !0),
            this.reportBsEvent({ ee_dp_moninit: 1, ee_dp_dvm_inj: t }),
            ("undefined" != typeof process && void 0 !== process.env) || d(i));
        },
        injectResponseReceivedCallback() {
          const t = this.resolveOriginalResultId(),
            e = this.generateResponseReceivedCallbackName();
          if ("function" == typeof window[a]) {
            let i = !1;
            const n = this;
            c.setSafeTimeout(() => {
              n.reportBsEvent({ ee_dp_wcb: i });
            }, 1e3),
              (window[e] = function (t, e, s, r, o, a, d) {
                i = !0;
                try {
                  if (d) n.reportBsEvent({ ee_dp_cbst: d });
                  else {
                    const i = n.generateTimestamp();
                    n.reportBsEvent({ ee_dp_pcbc: i });
                    const a = n.getEventParams(e);
                    n.reportBsEvent(
                      Object.assign(Object.assign({}, a), {
                        ee_dp_cst: s,
                        ee_dp_cet: r,
                        ee_dp_drt: o,
                        ee_dp_wap: t,
                      })
                    ),
                      t && n.initiateMonitoring("adplayed");
                  }
                } catch (t) {
                  n.reportBsEvent({ cerrt: 4, cemsg: t.message });
                }
              });
            try {
              const i = this.generateTimestamp();
              n.reportBsEvent({ ee_dp_vcbc: i }), window[a](t, e);
            } catch (t) {
              this.reportBsEvent({ cerrt: 32, cemsg: t.message });
            }
          } else
            this.reportBsEvent({
              cerrt: 64,
              ee_dp_pcbn: a,
              ee_dp_pcbt: typeof window[a],
            });
        },
        reportBsEvent(t) {
          const i = this.buildEventUrl(t);
          e.sendBeacon(i, !0);
        },
        reportVideoTimingEvent(t) {
          const e = {};
          (e[t] = this.generateTimestamp()), this.reportBsEvent(e);
        },
        resolveOriginalResultId() {
          let e;
          switch (t.ResultID) {
            case 5:
              e = 1;
              break;
            case 6:
              e = 2;
              break;
            default:
              e = t.ResultID;
          }
          return e;
        },
      });
    },
    4179: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.getWorkingWindow = e.getCurrentWindow = e.getTagUniqueKey = void 0);
      const n = i(1906);
      dvWindow = ("undefined" != typeof window && window) || dvWindow;
      let s = "";
      function r() {
        return ((void 0 !== $dv && $dv) || {}).isDomlessEnvironment
          ? {}
          : dvWindow;
      }
      (e.getTagUniqueKey = function () {
        if ("" === s) {
          const t = (void 0 !== $dv && $dv) || {};
          if (!Object.prototype.hasOwnProperty.call(t, "tagData"))
            throw new Error("dv object missing tagData property");
          if (!t.tagData || "object" != typeof t.tagData)
            throw new Error("tagData is not an object");
          const e = Object.keys(t.tagData).filter(
            (e) =>
              Object.prototype.hasOwnProperty.call(
                t.tagData[e],
                "tagScriptElem"
              ) &&
              "1" == t.tagData[e].flvr &&
              !t.tagData[e].isVisited
          );
          if (!e.length) throw new Error("all tags data visited");
          const i = n.Utilities.getVersion(),
            r = e.filter(
              (e) =>
                t.tagData[e].dvtpScriptVersion === i && "1" == t.tagData[e].flvr
            );
          (s = r.length ? r[0] : e[0]), (t.tagData[s].isVisited = !0);
        }
        return s;
      }),
        (e.getCurrentWindow = r),
        (e.getWorkingWindow = function () {
          const t = (void 0 !== $dv && $dv) || {},
            e = r();
          let i = e;
          try {
            i = t.restrictedAccess ? e : e.parent;
          } catch (t) {
            i = e;
          }
          return i;
        });
    },
    7483: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e._ = e.S = e.M = void 0);
      const n = i(7065),
        s = i(713),
        r = i(7826),
        o = i(1326),
        a = i(5171),
        d = i(4112),
        c = i(3998),
        l = i(1080),
        u = i(1906),
        h = i(3629),
        v = i(3301);
      class p {
        constructor() {
          (this.eventListenersList = []),
            (this.visibilityPropertyPrefixes = {
              hidden: "",
              webkitHidden: "webkit",
              mozHidden: "moz",
              msHidden: "ms",
            }),
            (this.isSameOriginIframe = (t) => {
              var e;
              try {
                return (
                  null !=
                  ((null === (e = t.contentWindow) || void 0 === e
                    ? void 0
                    : e.document) || t.contentDocument)
                );
              } catch (t) {
                return !1;
              }
            }),
            this.updateVisibilityProperties(),
            this.createPrerenderedImages();
        }
        sendBeaconIsSupported() {
          return (
            v.O.getNavigator() &&
            !!v.O.getNavigator().sendBeacon &&
            s.BrowserDetector.getBrowserId() != d.Browser.Safari &&
            s.BrowserDetector.getBrowserId() != d.Browser.SafariWebView
          );
        }
        createPrerenderedImages() {
          (this.prerenderedImages = []),
            (this.sendBeaconSupported = this.sendBeaconIsSupported()),
            this.sendBeaconSupported ||
              u.Utilities.times(20, () =>
                this.prerenderedImages.push(new Image())
              );
        }
        getVisibilityProperty() {
          for (const t of Object.keys(this.visibilityPropertyPrefixes))
            if (null != v.O.workingDocument()[t]) return t;
        }
        updateVisibilityProperties() {
          (this.visibilityProperty = this.getVisibilityProperty()),
            (this.visibilityPrefix =
              this.visibilityPropertyPrefixes[this.visibilityProperty]);
        }
        getVisibilityPrefix() {
          return this.visibilityPrefix;
        }
        isVisibilityChangeEventSupported() {
          return !!this.visibilityProperty;
        }
        hasFocus() {
          return (
            !(
              this.isVisibilityChangeEventSupported() &&
              !c.omidAdapter.isSupported()
            ) || !v.O.workingDocument()[this.visibilityProperty]
          );
        }
        isStrictFocusSupported() {
          var t;
          return (
            (null === (t = v.O.documentTop) || void 0 === t
              ? void 0
              : t.call(v.O).hasFocus) && !c.omidAdapter.isSupported()
          );
        }
        hasStrictFocus() {
          try {
            return (
              !this.isStrictFocusSupported() || v.O.documentTop().hasFocus()
            );
          } catch (t) {
            return !0;
          }
        }
        addEventListener(t, e, i, n = !1) {
          return (
            !!(t && e && i) &&
            ((null == i ? void 0 : i.addEventListener)
              ? (i.addEventListener(t, e, n),
                this.eventListenersList.push({
                  eventName: t,
                  cb: e,
                  element: i,
                  capture: n,
                }))
              : ((i["on" + t] = e),
                this.eventListenersList.push({
                  eventName: t,
                  cb: e,
                  element: i,
                  capture: n,
                  directAssignment: !0,
                })),
            !0)
          );
        }
        clearAllEventsListeners() {
          this.eventListenersList.forEach((t) => {
            this.removeEventListener(t.eventName, t.cb, t.element, t.capture);
          });
        }
        removeEventListener(t, e, i, n = !1) {
          if (!t || !e || !i) return;
          const s = this.eventListenersList.filter(
            (s) =>
              s.eventName === t &&
              s.cb === e &&
              s.element === i &&
              s.capture === n
          );
          s.forEach((e) => {
            e.directAssignment
              ? i["on" + t] && (i["on" + t] = null)
              : i.removeEventListener &&
                i.removeEventListener(t, e.cb, e.capture);
          }),
            (this.eventListenersList = this.eventListenersList.filter(
              (t) => !s.includes(t)
            ));
        }
        getTaskManager() {
          return v.O.currentWindow();
        }
        getPerformanceTimeNow() {
          return (
            null == this.timeFunction &&
              ((0, h.isPerformanceApiSupported)()
                ? (this.timeFunction = () =>
                    v.O.currentWindow().performance.now())
                : (this.timeFunction = () => Date.now())),
            this.timeFunction()
          );
        }
        registerScriptEvent(t, e, i) {
          this.addEventListener("error", null == e ? void 0 : e.bind(null), t),
            this.addEventListener("load", null == i ? void 0 : i.bind(null), t);
        }
        addScriptAsync(t, e, i, n, s) {
          e ||
            (e =
              v.O.workingBody() ||
              v.O.workingDocument().head ||
              v.O.workingDocumentElement());
          const r = (0, a.createElement)("script", e.ownerDocument);
          (r.type = "text/javascript"),
            (r.src = t),
            this.registerScriptEvent(r, n, s),
            i && (r.id = i),
            (0, a.insertBefore)(e, r, e.firstChild);
        }
        addScriptSync(t, e) {
          e.write('<script type="text/javascript" src="' + t + '"></script>');
        }
        isFetchJSONAPISupported() {
          return "function" == typeof fetch;
        }
        async fetchJSON(t) {
          if (!this.isFetchJSONAPISupported())
            throw new Error("VisitJSON: window.fetch is not supported");
          const e = await fetch(t);
          if (200 !== e.status)
            throw new Error(`VisitJSON: unexpected ${e.status} status code`);
          return e.json();
        }
        createIframe(t) {
          const e = (0, a.createElement)("iframe");
          return (
            (e.name = e.id = "iframe_" + l.RandomUtils.getRandom16()),
            (e.width = "0"),
            (e.height = "0"),
            (e.style.display = "none"),
            (e.src = t),
            e
          );
        }
        getNestedDocuments(t, e) {
          return this.getNestedSameOriginIframes(t, e)
            .map((t) => {
              var e;
              return null === (e = null == t ? void 0 : t.contentDocument) ||
                void 0 === e
                ? void 0
                : e.documentElement;
            })
            .filter((t) => null != t);
        }
        getNestedSameOriginIframes(t, e) {
          const i = [],
            n = (t, s) => {
              var r;
              if (s >= e) return;
              const d = (0, o.isHTMLIFrameElement)(t)
                ? [t]
                : (0, a.getElementsByTagNameFromDomElement)(t, "iframe").filter(
                    o.isHTMLIFrameElement
                  );
              for (const t of d)
                try {
                  this.isSameOriginIframe(t) &&
                    (i.push(t),
                    n(
                      null === (r = t.contentDocument) || void 0 === r
                        ? void 0
                        : r.documentElement,
                      s + 1
                    ));
                } catch (t) {}
            };
          return n(t, 0), i;
        }
        getAvailableScreenSize(t = !0) {
          var e;
          let i = t ? 0 : null,
            n = t ? 0 : null;
          const s =
            null === (e = v.O.workingWindow) || void 0 === e
              ? void 0
              : e.call(v.O).screen;
          return (
            s && ((i = s.availHeight), (n = s.availWidth)),
            { height: i, width: n }
          );
        }
        getScreenSize() {
          var t;
          try {
            const e =
              null === (t = v.O.workingWindow()) || void 0 === t
                ? void 0
                : t.screen;
            if (e) return { height: e.height, width: e.width };
          } catch (t) {}
          return { height: 0, width: 0 };
        }
        getDevicePixelRatio() {
          try {
            return v.O.workingWindow().devicePixelRatio;
          } catch (t) {}
        }
        getInnerViewport(t = !0) {
          let e = t ? 0 : null,
            i = t ? 0 : null;
          try {
            const t = v.O.windowTop(),
              n = v.O.workingWindow();
            t
              ? ((e = t.innerHeight), (i = t.innerWidth))
              : n && ((e = n.innerHeight), (i = n.innerWidth));
          } catch (t) {}
          return { height: e, width: i };
        }
        getOuterViewport(t = v.O.workingWindow(), e = !0) {
          let i = e ? 0 : null,
            n = e ? 0 : null;
          try {
            t && ((i = t.outerHeight), (n = t.outerWidth));
          } catch (t) {}
          return { height: i, width: n };
        }
        getViewportAssetsRelativeToScreen(t) {
          let e = 0,
            i = 0;
          try {
            t && ((e = t.screenY), (i = t.screenX));
          } catch (t) {}
          return { top: e, left: i };
        }
        getIframeAssetsRelativeToScreen(t = v.O.workingWindow()) {
          let e = 0,
            i = 0;
          try {
            t &&
              ((e = t.mozInnerScreenY || t.screenTop),
              (i = t.mozInnerScreenX || t.screenLeft));
          } catch (t) {}
          return { top: e, left: i };
        }
        getScrollData(t = v.O.workingBody()) {
          let e = 0,
            i = 0;
          return (
            t && ((e = t.scrollLeft), (i = t.scrollTop)), { left: i, top: e }
          );
        }
        getNavigationStartTime() {
          var t;
          if (
            null === (t = v.O.workingWindow().performance) || void 0 === t
              ? void 0
              : t.timing
          )
            return v.O.workingWindow().performance.timing.navigationStart;
        }
        sendBeacon(t, e = !1) {
          var i;
          if (!n.TcfClientStop.shouldSuppressUrl(t)) {
            if (c.omidAdapter.isSupported()) c.omidAdapter.sendUrl(t);
            else if (!e && this.sendBeaconSupported)
              v.O.getNavigator().sendBeacon(t);
            else if (
              "object" == typeof window &&
              "function" ==
                typeof (null === window || void 0 === window
                  ? void 0
                  : window.fetch)
            )
              fetch(t, { method: "GET", keepalive: !0, mode: "no-cors" }).catch(
                (t) => {
                  0;
                }
              );
            else {
              let e;
              (e = (
                null === (i = this.prerenderedImages) || void 0 === i
                  ? void 0
                  : i.length
              )
                ? this.prerenderedImages.pop()
                : (0, a.createImage)()),
                (e.src = t);
            }
            (0, h.logDvSignal)(t);
          }
        }
        isElementAttachedToDocument(t) {
          try {
            return "IFRAME" == t.nodeName
              ? !!v.O.getIframeWindow(t)
              : v.O.workingDocument().contains(t);
          } catch (t) {}
        }
        convertOrientationType(t) {
          switch (null == t ? void 0 : t.toString()) {
            case "landscape-primary":
            case "landscape-secondary":
              return 2;
            case "portrait-primary":
            case "portrait-secondary":
              return 1;
            default:
              return 0;
          }
        }
        getScreenOrientationType() {
          var t;
          const e =
            null === (t = this.getScreenOrientation()) || void 0 === t
              ? void 0
              : t.type;
          return this.convertOrientationType(e);
        }
        getScreenOrientation() {
          var t, e;
          return null ===
            (e =
              null === (t = v.O.currentWindow()) || void 0 === t
                ? void 0
                : t.screen) || void 0 === e
            ? void 0
            : e.orientation;
        }
        getMetaTagAttributes(t, e) {
          const i = {};
          if (t)
            for (const n of u.Utilities.arrayLikeToArray(
              t.getElementsByTagName("meta")
            ))
              if (n.getAttribute("name") === e && n.getAttribute("content")) {
                n.getAttribute("content")
                  .split(",")
                  .forEach((t) => {
                    const e = t.split("=");
                    e.length > 1 && (i[e[0].trim()] = e[1].trim());
                  });
                break;
              }
          return i;
        }
      }
      (e.M = p),
        (e.S = (0, u.uninitializedServiceGuard)("BrowserAdaptor")),
        (e._ = function () {
          return (
            (e.S = v.O.isDomlessEnvironment()
              ? new r.BrowserOmidAdaptorClass()
              : new p()),
            e.S
          );
        });
    },
    713: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.createBrowserDetector =
          e.BrowserDetector =
          e.BrowserDetectorClass =
            void 0);
      const n = i(4112),
        s = i(3301),
        r = i(8464),
        o = i(1906);
      class a {
        constructor() {
          (this.browsersList = [
            {
              id: n.Browser.Selenium,
              browserDetectionRuleType: 2,
              propertiesRuleFunc: () =>
                s.O.workingDocumentElement().hasAttribute("webdriver") ||
                s.O.workingDocumentElement().hasAttribute("fxdriver") ||
                s.O.workingDocumentElement().hasAttribute(
                  "__webdriver_unwrapped"
                ) ||
                s.O.workingDocumentElement().hasAttribute(
                  "__webdriver_script_fn"
                ) ||
                s.O.workingDocumentElement().hasAttribute(
                  "__webdriver_evaluate"
                ) ||
                s.O.workingDocumentElement().hasAttribute(
                  "__fxdriver_evaluate"
                ) ||
                s.O.workingDocumentElement().hasAttribute(
                  "__fxdriver_unwrapped"
                ) ||
                s.O.workingDocumentElement().hasAttribute(
                  "__fxdriver_script_fn"
                ) ||
                this.workingWindow.webdriver ||
                this.workingWindow.domAutomation ||
                this.workingWindow.domAutomationController ||
                this.workingWindow._WEBDRIVER_ELEM_CACHE ||
                this.hasSeleniumProps(),
            },
            {
              id: n.Browser.Playwright,
              browserDetectionRuleType: 2,
              propertiesRuleFunc: () =>
                this.workingWindow.__pwInitScripts ||
                this.workingWindow.__playwright__binding__,
            },
            {
              id: n.Browser.PuppeteerVanilla,
              browserDetectionRuleType: 2,
              propertiesRuleFunc: () => {
                var t;
                return null === (t = this.workingWindow.navigator) ||
                  void 0 === t
                  ? void 0
                  : t.webdriver;
              },
            },
            {
              id: n.Browser.PuppeteerExtraStealth,
              browserDetectionRuleType: 2,
              propertiesRuleFunc: () => this.getIsExtraStealthBrowser(),
            },
            {
              id: n.Browser.ChromeWebView,
              browserDetectionRuleType: 1,
              userAgentRegex:
                "(?:wv(.*?))version/[0-9]+(?:.[0-9]+)* chrome/[0-9]+(?:.[0-9]+)* mobile|version/[0-9]+(?:.[0-9]+)* chrome/[0-9]+(?:.[0-9]+)* mobile|(?:wv(.*?))version\\/[0-9]+(?:.[0-9]+)* chrome\\/[0-9]+(?:.[0-9]+)*",
              versionRegex: "chrome/",
            },
            {
              id: n.Browser.SafariWebView,
              browserDetectionRuleType: 3,
              userAgentRegex:
                "(?=.*(iphone|ipod|ipad))(?=^(?:(?!safari).)*$).*$",
              propertiesRuleFunc: () =>
                !this.workingWindow.navigator.standalone,
            },
            {
              id: n.Browser.IE,
              browserDetectionRuleType: 1,
              userAgentRegex:
                "msie|trident/7.*rv:11|rv:11.*trident/7|edge/|edg/",
              versionRegex: "(msie |rv:| edge/|edg/)",
            },
            {
              id: n.Browser.Firefox,
              browserDetectionRuleType: 2,
              userAgentRegex: "firefox",
              versionRegex: "firefox/",
              propertiesRuleFunc: () => {
                var t;
                return (
                  "number" == typeof this.workingWindow.mozInnerScreenY &&
                  "number" == typeof this.workingWindow.mozPaintCount &&
                  (null === (t = this.workingWindow.InstallTrigger) ||
                  void 0 === t
                    ? void 0
                    : t.install)
                );
              },
            },
            {
              id: n.Browser.Opera,
              browserDetectionRuleType: 1,
              userAgentRegex: "opr|opera",
              versionRegex: "(opr/|version/)",
            },
            {
              id: n.Browser.Chrome,
              browserDetectionRuleType: 2,
              userAgentRegex: "chrome",
              versionRegex: "chrome/",
              propertiesRuleFunc: () =>
                this.workingWindow.chrome &&
                "function" == typeof this.workingWindow.chrome.csi &&
                "function" == typeof this.workingWindow.chrome.loadTimes &&
                "boolean" == typeof this.workingDocument.webkitHidden,
            },
            {
              id: n.Browser.Chrome,
              browserDetectionRuleType: 1,
              userAgentRegex: "crios",
              versionRegex: "crios/",
            },
            {
              id: n.Browser.Safari,
              browserDetectionRuleType: 2,
              userAgentRegex: "safari|(os |os x )[0-9].*applewebkit",
              versionRegex: "version/",
              propertiesRuleFunc: () => {
                var t, e;
                const i =
                  null ===
                    (e =
                      null === (t = s.O.workingDocument()) || void 0 === t
                        ? void 0
                        : t.createElement) || void 0 === e
                    ? void 0
                    : e.call(t, "p");
                if (i)
                  return (
                    (i.innerText = "."),
                    i.setAttribute(
                      "style",
                      "color:red; border: 1px solid blue;"
                    ),
                    (Object.prototype.toString
                      .call(this.workingWindow.HTMLElement)
                      .indexOf("Constructor") > 0 ||
                      (this.workingWindow.webkitAudioPannerNode &&
                        this.workingWindow.webkitConvertPointFromNodeToPage)) &&
                      null != this.workingWindow.innerWidth &&
                      null != this.workingWindow.innerHeight &&
                      null != i.style.textShadow
                  );
              },
            },
            {
              id: n.Browser.Unknown,
              browserDetectionRuleType: 1,
              userAgentRegex:
                "mozilla.*android.*applewebkit(?!.*chrome.*)|linux.*android.*applewebkit.* version/.*chrome",
            },
            {
              id: n.Browser.Unknown,
              browserDetectionRuleType: 1,
              userAgentRegex:
                "aol/.*aolbuild/|aolbuild/.*aol/|puffin|maxthon|valve|silk|playstation|playstation|nintendo|wosbrowser",
            },
          ]),
            s.O.isDomlessEnvironment() ||
              ((this.workingWindow = s.O.workingWindow()),
              (this.workingDocument = s.O.workingDocument()),
              (this.currentUserAgent = (
                (null === r.A || void 0 === r.A
                  ? void 0
                  : r.A.getUserAgent()) ||
                s.O.getUserAgent() ||
                ""
              ).toLowerCase()),
              (this.browserData = this.determineBrowserType()));
        }
        getBrowserId() {
          var t;
          return null === (t = this.browserData) || void 0 === t
            ? void 0
            : t.browserId;
        }
        getBrowserVersion() {
          var t;
          return null === (t = this.browserData) || void 0 === t
            ? void 0
            : t.browserVersion;
        }
        getBrowserIdUserAgent() {
          var t;
          return null === (t = this.browserData) || void 0 === t
            ? void 0
            : t.browserIdUserAgent;
        }
        determineBrowserType() {
          let t, e, i;
          for (const i of this.browsersList) {
            switch (i.browserDetectionRuleType) {
              case 3:
                this.validateBrowserTypeByUserAgent(i) &&
                  this.validateBrowserTypeByPropertiesRule(i) &&
                  (t = e = i);
                break;
              case 1:
                this.validateBrowserTypeByUserAgent(i) && (t = e = i);
                break;
              case 2:
                !t &&
                  i.userAgentRegex &&
                  this.validateBrowserTypeByUserAgent(i) &&
                  (t = i),
                  !e && this.validateBrowserTypeByPropertiesRule(i) && (e = i);
            }
            if (t && e) break;
          }
          return (
            t == e &&
              (null == t ? void 0 : t.versionRegex) &&
              (i = this.determineBrowserVersion(t.versionRegex)),
            {
              browserId: null == e ? void 0 : e.id,
              browserVersion: i || "",
              browserIdUserAgent: null == t ? void 0 : t.id,
            }
          );
        }
        validateBrowserTypeByUserAgent(t) {
          return new RegExp(t.userAgentRegex).test(this.currentUserAgent);
        }
        validateBrowserTypeByPropertiesRule(t) {
          return t.propertiesRuleFunc();
        }
        getTrustedInstanceId(t) {
          var e, i, n, r;
          const o =
              null === (e = s.O.currentWindow()) || void 0 === e
                ? void 0
                : e.trustedTypes,
            a =
              null === (i = null == o ? void 0 : o.createPolicy) || void 0 === i
                ? void 0
                : i.call(o, void 0, {
                    createHTML: (t) =>
                      /^[a-z][a-z0-9]{7}$/.test(t) ? t : o.emptyHTML,
                  });
          return null !==
            (r =
              null === (n = null == a ? void 0 : a.createHTML) || void 0 === n
                ? void 0
                : n.call(a, t)) && void 0 !== r
            ? r
            : t;
        }
        getIsExtraStealthBrowser() {
          let t = !1;
          try {
            const e = String.fromCharCode(26 * Math.random() + 97),
              i = e + Math.random().toString(36).slice(-7),
              n = this.workingDocument.createElement("iframe");
            n.srcdoc = i;
            const s = !!n.contentWindow,
              r = "ontouchstart" in this.workingWindow;
            t = s && !r;
          } catch (t) {}
          return t;
        }
        hasSeleniumProps() {
          try {
            const t = ["Array", "Object", "Promise", "Proxy", "Symbol", "JSON"],
              e = ["$wdc_", "$cdc_", "cdc_", "wdc_"];
            for (const i in this.workingWindow) {
              let n = !1;
              for (const t of e)
                if (i.startsWith(t)) {
                  n = !0;
                  break;
                }
              if (n) for (const e of t) if (i.endsWith(e)) return !0;
            }
          } catch (t) {}
          return !1;
        }
        determineBrowserVersion(t) {
          const e = new RegExp(t + "[0-9]+(?:.[0-9]+)*"),
            i = this.currentUserAgent.match(e);
          if (i)
            return i[0].replace(
              new RegExp(t).exec(this.currentUserAgent)[0],
              ""
            );
        }
      }
      (e.BrowserDetectorClass = a),
        (e.BrowserDetector = (0, o.uninitializedServiceGuard)(
          "BrowserDetector"
        )),
        (e.createBrowserDetector = function () {
          return (e.BrowserDetector = new a()), e.BrowserDetector;
        });
    },
    7826: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BrowserOmidAdaptorClass = void 0);
      const n = i(7065),
        s = i(3998);
      e.BrowserOmidAdaptorClass = class {
        constructor() {
          this.isSameOriginIframe = (t) => null;
        }
        clearAllEventsListeners() {}
        updateVisibilityProperties() {}
        getDevicePixelRatio() {}
        getVisibilityPrefix() {
          return "";
        }
        isVisibilityChangeEventSupported() {
          return !1;
        }
        hasFocus() {
          return !0;
        }
        hasStrictFocus() {
          return !0;
        }
        addEventListener(t, e, i, n = !1) {
          return s.omidAdapter.addEventListener(t, e), !(!t || !e);
        }
        removeEventListener() {}
        getTaskManager() {
          return s.omidAdapter;
        }
        getPerformanceTimeNow() {
          return Date.now();
        }
        getAvailableScreenSize(t = !0) {
          return { height: 0, width: 0 };
        }
        getScreenSize() {
          return { height: 0, width: 0 };
        }
        getInnerViewport(t = !0) {
          return { height: 0, width: 0 };
        }
        getOuterViewport(t, e = !0) {
          return { height: 0, width: 0 };
        }
        getViewportAssetsRelativeToScreen(t) {
          return { top: 0, left: 0 };
        }
        getIframeAssetsRelativeToScreen(t) {
          return { top: 0, left: 0 };
        }
        getScrollData(t) {
          return { left: 0, top: 0 };
        }
        getNavigationStartTime() {}
        sendBeacon(t, e) {
          n.TcfClientStop.shouldSuppressUrl(t) || s.omidAdapter.sendUrl(t);
        }
        isStrictFocusSupported() {
          return !1;
        }
        addScriptAsync(t, e, i, n, r) {
          s.omidAdapter.injectJavaScriptResource(
            t,
            null == r ? void 0 : r.bind(null),
            null == n ? void 0 : n.bind(null)
          );
        }
        addScriptSync(t, e) {
          s.omidAdapter.injectJavaScriptResource(t);
        }
        isFetchJSONAPISupported() {
          return (
            "object" == typeof omidNative &&
            "function" == typeof omidNative.downloadJavaScriptResource
          );
        }
        async fetchJSON(t) {
          return new Promise((e, i) => {
            if (!this.isFetchJSONAPISupported())
              return void i(
                new Error(
                  "VisitJSON: omidNative.downloadJavaScriptResource is not supported"
                )
              );
            const n = (t) => {
              i(new Error(`VisitJSON: ${t}`));
            };
            omidNative.downloadJavaScriptResource(
              t,
              (t) => {
                if ("string" != typeof t)
                  n("Response content type is " + typeof t);
                else
                  try {
                    const i = JSON.parse(t);
                    e(i);
                  } catch (t) {
                    n("Failed to parse response");
                  }
              },
              () => {
                n("Failed to download");
              }
            );
          });
        }
        createIframe(t) {
          throw new Error("createIframe failed");
        }
        isElementAttachedToDocument(t) {
          return !0;
        }
        getScreenOrientation() {}
        getScreenOrientationType() {}
        getMetaTagAttributes(t, e) {
          return {};
        }
        getNestedSameOriginIframes(t, e) {
          return [];
        }
        getNestedDocuments(t, e) {
          return [];
        }
      };
    },
    1326: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.isHTMLIFrameElement = void 0);
      e.isHTMLIFrameElement = (t) =>
        "IFRAME" === (null == t ? void 0 : t.tagName);
    },
    99: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.T = e.I = void 0);
      const n = i(4179),
        s = i(6410),
        r = i(1906);
      class o {
        constructor() {
          this.visitFlowType = 0;
        }
        setDvGetOmidVerificationClient(t) {
          this.dvGetOmidVerificationClient = t;
        }
        getDvGetOmidVerificationClient() {
          return this.dvGetOmidVerificationClient;
        }
        setVisitFlowType(t) {
          this.visitFlowType = t;
        }
        getVisitFlowType() {
          return this.visitFlowType;
        }
        u() {
          if (void 0 !== $dv) return $dv;
          const t = (0, n.getCurrentWindow)();
          if (null == t ? void 0 : t.$dv) return t.$dv;
          const e = (0, n.getWorkingWindow)();
          return (null == e ? void 0 : e.$dv) ? e.$dv : {};
        }
        getTagUniqueKey() {
          return (0, n.getTagUniqueKey)();
        }
        getTagCounter() {
          return this.u().tagsCounter;
        }
        getSharedUniqueKey() {
          return this.u().sharedUniqueKey;
        }
        getTagScriptElem() {
          return this.getTagData().tagScriptElem;
        }
        getOmidInjectionId() {
          return this.getTagData().omidInjectionId;
        }
        hasTagData() {
          return !!this.u().tagData;
        }
        getTagData() {
          const t = this.u(),
            e = this.getTagUniqueKey(),
            i = t.tagData[e];
          if (!i) throw new Error(`tagData not found for tuk = ${e}`);
          return i;
        }
        getTagParams() {
          return this.getTagData().tagParams;
        }
        getDvtpScriptVersion() {
          return this.getTagData().dvtpScriptVersion;
        }
        getIsBlockingEnabled() {
          var t;
          return (
            "0" !==
            (null === (t = this.getTagParams()) || void 0 === t
              ? void 0
              : t.blk)
          );
        }
        getTagHasVendorKey() {
          var t;
          return !!(null === (t = this.getTagParams()) || void 0 === t
            ? void 0
            : t.vendor_key);
        }
        isRestrictedAccess() {
          return !!this.u().restrictedAccess;
        }
        getScriptInjectionMode() {
          var t;
          return this.hasTagData() &&
            null !== (t = this.getTagData().scriptInjectionMode) &&
            void 0 !== t
            ? t
            : "unknown";
        }
        isOmidForWeb() {
          return !!this.getTagData().isOmidForWeb;
        }
        getOmidWebHopCounter() {
          return this.getTagData().omidWebHopCounter;
        }
        isOmid3p() {
          return !!this.getTagData().isOmid3p;
        }
        getOmid3pHopCounter() {
          return this.getTagData().omid3pHopCounter;
        }
        getDvtpScriptUrl() {
          return this.getTagData().dvtpScriptUrl || "";
        }
        getTagLoadedMS() {
          return this.getTagData().tagLoadedMS || 0;
        }
        getTagReadyState() {
          return this.getTagData().tagReadyState || "loading";
        }
        getVisitReadyState() {
          return this.getTagData().visitReadyState || "loading";
        }
        setVisitReadyState(t = "loading") {
          this.getTagData().visitReadyState = t;
        }
        getVisitInjectedMS() {
          return this.getTagData().visitInjectedMS || 0;
        }
        setVisitInjectedMS(t = 0) {
          this.getTagData().visitInjectedMS = t;
        }
        getVerifyInjectedMS() {
          return this.getTagData().verifyInjectedMS || 0;
        }
        setVerifyInjectedMS(t = 0) {
          this.getTagData().verifyInjectedMS = t;
        }
        getTagExecTimeMs() {
          return this.getTagData().tagExecTimeMs || 0;
        }
        setImpressionIdOnTagData(t) {
          this.getTagData().$uid = t;
        }
        setImpressionId(t) {
          (this.impressionId = t), this.setImpressionIdOnTagData(t);
        }
        getImpressionIdFromTagData() {
          return this.getTagData().$uid;
        }
        getSavedImpressionId() {
          return this.impressionId;
        }
        getImpressionId(t) {
          return this.getImpressionIdFromTagData();
        }
        getFrameIdFromTagData() {
          return this.getTagData().$frmId;
        }
        getFrameId(t) {
          return this.getFrameIdFromTagData();
        }
        getScriptUrl() {
          return this.getTagData().dvtpScriptUrl;
        }
        getProtocol() {
          return 0 === (this.getScriptUrl() || "").indexOf("http:")
            ? "http:"
            : "https:";
        }
        getJSVersion() {
          return this.getTagData().dvtpScriptVersion;
        }
        publishPubSubEvent(t, e = this.impressionId, i = {}) {
          var n;
          (null === (n = this.u()) || void 0 === n ? void 0 : n.pubSub) &&
            t &&
            e &&
            this.u().pubSub.publish(t, e, i);
        }
        getCustomAdvertiserViewabilitySettings() {
          var t, e;
          const i = this.u();
          if (
            !(null == i ? void 0 : i.tags) ||
            !this.impressionId ||
            null ==
              (null ===
                (e =
                  null === (t = $dv.tags[this.impressionId]) || void 0 === t
                    ? void 0
                    : t.cavs) || void 0 === e
                ? void 0
                : e.standardType)
          )
            return;
          const {
            cavs: { regularAd: n, largeAd: s, standardType: r },
          } = $dv.tags[this.impressionId];
          return { standardType: r, conditions: { regularAd: n, largeAd: s } };
        }
        isMobileWeb() {
          return 2 === this.getDetectedDeliveryType();
        }
        isMobileApp() {
          return 3 === this.getDetectedDeliveryType();
        }
        isCTV() {
          return 4 === this.getDetectedDeliveryType();
        }
        isMobile() {
          return this.isMobileWeb() || this.isMobileApp();
        }
        getDetectedDeliveryType() {
          try {
            if (this.detectedDeliveryType || !this.impressionId)
              return this.detectedDeliveryType;
            const t = s.ServerContext.getDetectedDeliveryType();
            if (r.Utilities.isNumeric(t))
              return (this.detectedDeliveryType = t), this.detectedDeliveryType;
          } catch (t) {}
        }
        getAllowRBViewability() {
          var t;
          return (
            !(
              !(null === (t = this.u()) || void 0 === t ? void 0 : t.tags) ||
              !this.impressionId
            ) && this.u().tags[this.impressionId].allowRB
          );
        }
        getFireOnlyImportantEvents() {
          var t;
          let e = !1;
          return (
            (null === (t = this.u()) || void 0 === t ? void 0 : t.tags) &&
              this.impressionId &&
              (e = this.u().tags[this.impressionId].foie),
            e
          );
        }
        getDoubleTagImpressionID() {
          const t = this.getAdTagData();
          if ((null == t ? void 0 : t.dup) && "null" != t.dup) return t.dup;
        }
        getAdTagData() {
          var t;
          let e;
          const { impressionId: i } = this;
          return (
            (null === (t = this.u().tags) || void 0 === t ? void 0 : t[i]) &&
              (e = this.u().tags[i]),
            e
          );
        }
      }
      (e.I = o), (e.T = new o());
    },
    8464: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.A = e.C = void 0);
      const n = i(3301),
        s = i(4112),
        r = i(1906),
        o = i(3998),
        a = i(99),
        d = i(1360),
        c = i(5171);
      let l;
      class u {
        constructor() {
          (this.D = {}),
            (this.paramsCaseSensitive = {}),
            (this.paramUrlExtractionMethod = 0),
            (this.serverPrefix = "https://tps.doubleverify.com/"),
            (this.defaultInitType = "js"),
            (this.initJsPath = "visit.js"),
            (this.initJsonPath = "visit.json"),
            (this.errorPath = "visit.jpg"),
            (this.eventPath = "event.png"),
            (this.blockingServerPrefix = "https://rtb0.doubleverify.com/"),
            (this.blockingInitPath = "verify.js"),
            (this.blockingErrorPath = "verify.js"),
            (this.blockingEventPath = "bsevent.gif"),
            (this.DIAGNOSTIC_PARAM_CTX = (0, d.getDiagnosticQueryParamName)(
              d.DiagnosticParams.adIdentityClientCode
            )),
            (this.DIAGNOSTIC_PARAM_CMP = (0, d.getDiagnosticQueryParamName)(
              d.DiagnosticParams.adIdentityAdServerCampaignCode
            )),
            (this.DIAGNOSTIC_PARAM_ADSRV = (0, d.getDiagnosticQueryParamName)(
              d.DiagnosticParams.adIdentityAdServer
            )),
            (this.DIAGNOSTIC_PARAM_PLC = (0, d.getDiagnosticQueryParamName)(
              d.DiagnosticParams.adIdentityPlacementId
            )),
            (this.DIAGNOSTIC_PARAM_SID = (0, d.getDiagnosticQueryParamName)(
              d.DiagnosticParams.adIdentityAdServerSiteCode
            )),
            (this.DIAGNOSTIC_PARAM_DUP = (0, d.getDiagnosticQueryParamName)(
              d.DiagnosticParams.adIdentityDedupingId
            )),
            (this.CTX = "ctx"),
            (this.CMP = "cmp"),
            (this.ADSRV = "adsrv"),
            (this.SID = "sid"),
            (this.PLC = "plc"),
            (this.DUP = "dup"),
            (this.DIAGNOSTIC_REPORTED_PARAMS = [
              [
                d.DiagnosticParams.btregOptimizationValue,
                this.getBtreg.bind(this),
              ],
              [d.DiagnosticParams.btadsrvValue, this.getBtadsrv.bind(this)],
              [d.DiagnosticParams.findClassValue, () => this.D.findclass],
            ]);
        }
        getScriptElementExtractionMethod() {
          return this.scriptElementExtractionMethod;
        }
        getParamUrlExtractionMethod() {
          return this.paramUrlExtractionMethod;
        }
        getDVScriptUrl() {
          return this.dvtpScriptUrl;
        }
        getDVScript() {
          return this.scriptElement;
        }
        getCaseSensitiveParams() {
          return this.paramsCaseSensitive;
        }
        getLowerCaseParams() {
          return this.D;
        }
        getParamValue(t) {
          return this.D[t] ? this.D[t] : null;
        }
        getTagType() {
          var t;
          const e =
            null === (t = this.D.tagtype) || void 0 === t
              ? void 0
              : t.toLowerCase();
          return "video" === e || "1" === e
            ? 1
            : "audio" === e || "2" === e
            ? 2
            : 0;
        }
        isVideoOrAudio() {
          const t = this.getTagType();
          return 1 === t || 2 === t;
        }
        getTagVersion() {
          return this.getParamValue(s.TPSDataMapping.tagVersion) || "6.1.src";
        }
        getTagFormat() {
          return this.D.tagformat;
        }
        isTagTypeValid() {
          return (
            !this.D.tagtype ||
            ["display", "0", "video", "1", "audio", "2"].includes(
              this.D.tagtype.toLowerCase()
            )
          );
        }
        getClientCode() {
          return this.D[this.CTX];
        }
        getPlacementId() {
          return this.D[this.PLC];
        }
        getAdServerSiteCode() {
          return this.D[this.SID];
        }
        getDvApi() {
          return this.D.dvapi;
        }
        getAdServerCampaignCode() {
          return this.D[this.CMP];
        }
        getBlockingPartnerCallbackName() {
          return this.D.dvp_dcb;
        }
        getIsIplessSideBySideInjection() {
          return "1" == this.D.ilsbsi;
        }
        getGDPR() {
          return this.D.gdpr;
        }
        getGDPRConsent() {
          return this.D.gdpr_consent;
        }
        getGDPRAndGDPRConsentQueryStringPart() {
          const t = this.getGDPR(),
            e = this.getGDPRConsent();
          return (
            [
              [s.TPSDataMapping.gdpr, t],
              [s.TPSDataMapping.gdpr_consent, e],
            ]
              .map(([t, e]) => `${t}=${encodeURIComponent(e || "")}`)
              .join("&") + "&"
          );
        }
        getClientData() {
          return {
            ctx: this.getClientCode() || 818052,
            cmp: this.getAdServerCampaignCode() || 1619415,
            sid: this.getAdServerSiteCode() || 0,
            plc: this.getPlacementId() || 0,
          };
        }
        getAdID() {
          return this.D.dvp_gvacb || this.D.adid;
        }
        getBtreg() {
          return this.D.btreg;
        }
        getUserAgent() {
          return this.D.useragent;
        }
        getFindClass() {
          return "1" === this.D.findclass;
        }
        getIsVisitJsonFlowEnabled() {
          const t = this.D.vjf;
          return "1" === t || ("0" !== t && null);
        }
        getIsBlockingEnabled() {
          return "0" !== this.D.blk;
        }
        getIsMonitoringEnabled() {
          return "0" !== this.D.mon;
        }
        getVideoBlockingCallbackUrl() {
          return this.D.blkntf;
        }
        getPartnerContainerId() {
          return this.getValueOfTagAttribute("data-doubleverify-container");
        }
        getPartnerBlockingCallbackFnName() {
          return this.getValueOfTagAttribute("data-doubleverify-callback");
        }
        isDisplayGenXEnabled() {
          return (
            null != this.getValueOfTagAttribute("data-doubleverify-parameters")
          );
        }
        getMeasurementApi() {
          return this.D.msrapi;
        }
        getAdServerId() {
          return this.D[this.ADSRV];
        }
        getBtregOptimizationExperiment() {
          return this.D.btroe;
        }
        getBtadsrv() {
          return this.D.btadsrv;
        }
        getCustomTags() {
          return this.getArrayedParams("bttag", "|");
        }
        getCustomAttributes() {
          return this.getArrayedParams("btattb", "|");
        }
        isSellerTag() {
          return "1" === this.D.seltag;
        }
        j() {
          return this.D.seltagmals;
        }
        getSupplySource() {
          return this.D.sup;
        }
        getVastUrl() {
          return this.D.wrapperurl;
        }
        getSellerAdSize() {
          const t = { width: 0, height: 0 },
            e = this.D.unit;
          if (e) {
            const i = e.toLowerCase().split("x");
            if (i[0] && i[1])
              try {
                const e = parseInt(i[0]),
                  n = parseInt(i[1]);
                isNaN(e) || isNaN(n) || ((t.width = e), (t.height = n));
              } catch (t) {}
          }
          return t;
        }
        extractParamString() {
          const t = this.getValueOfTagAttribute("data-doubleverify-parameters");
          if (this.isDisplayGenXEnabled() && t) return t;
          const e = this.getDVScriptUrl(),
            i = /[?#&](.*)$/gi.exec(e);
          return void 0 !== (null == i ? void 0 : i[1]) ? i[1] : "";
        }
        saveExtractedParams(t) {
          for (const e in t) {
            const i = e.toLowerCase(),
              n = t[e];
            (this.D[i] = r.Utilities.isNullOrEmpty(this.D[i]) ? n : this.D[i]),
              (this.paramsCaseSensitive[e] = r.Utilities.isNullOrEmpty(
                this.paramsCaseSensitive[e]
              )
                ? n
                : this.paramsCaseSensitive[e]);
          }
        }
        setDVParam() {
          const t = this.extractParamString(),
            e = this.extractParamsToObjFromStr(t);
          this.saveExtractedParams(e),
            this.disableMonitoringForListedCampaigns();
        }
        disableMonitoringForListedCampaigns() {
          var t;
          0 === this.getTagType() &&
            "1" === this.D.advwf &&
            (null ===
              (t = (null != l ||
                (l = new Map([
                  [
                    "909916",
                    [
                      "33812416",
                      "33878423",
                      "35397430",
                      "35415820",
                      "35494547",
                      "35577993",
                      "35613652",
                      "35738130",
                      "35739045",
                      "35757720",
                      "36015681",
                      "36994100",
                      "37066586",
                    ],
                  ],
                  [
                    "1069526",
                    [
                      "290278",
                      "332652",
                      "332831",
                      "333019",
                      "33234034",
                      "33943367",
                      "34740185",
                      "34827410",
                      "34827413",
                      "34879833",
                      "34902819",
                      "34945995",
                      "35000601",
                      "35036710",
                      "35124355",
                      "35206860",
                      "35260284",
                      "35428517",
                      "35451905",
                      "35452019",
                      "35454686",
                      "36457573",
                      "36535694",
                      "36536450",
                      "36582787",
                      "36907777",
                      "36961654",
                      "36981576",
                      "37061065",
                      "37114959",
                      "37139889",
                      "37186881",
                      "DV2308998",
                      "DV2309001",
                      "DV2309005",
                      "DV2377028",
                    ],
                  ],
                  [
                    "2646482",
                    [
                      "36982990",
                      "37070420",
                      "37081556",
                      "37114952",
                      "37168164",
                    ],
                  ],
                  [
                    "2719918",
                    [
                      "36262791",
                      "36578910",
                      "36918381",
                      "36929398",
                      "36962025",
                      "37065076",
                    ],
                  ],
                  [
                    "2736101",
                    ["316916", "316922", "324500", "324501", "324502"],
                  ],
                  ["2821955", ["34851756"]],
                  ["2991178", ["34736823"]],
                  ["2998368", ["34924908"]],
                  ["3696283", ["34635632"]],
                  [
                    "3800571",
                    [
                      "35358210",
                      "35360835",
                      "36718163",
                      "36780000",
                      "36815572",
                      "36819295",
                      "36863921",
                      "36970237",
                      "37077658",
                      "37124484",
                      "37220400",
                    ],
                  ],
                  [
                    "3804285",
                    [
                      "33352298",
                      "35437480",
                      "35437486",
                      "35854853",
                      "35957563",
                      "36237315",
                      "36392820",
                      "36461933",
                      "36816841",
                      "37026852",
                      "37104120",
                    ],
                  ],
                  ["10534652", ["34124304", "34705661", "34780119"]],
                  [
                    "10625676",
                    [
                      "34687256",
                      "34756138",
                      "34871572",
                      "35012157",
                      "35472428",
                    ],
                  ],
                  ["12589735", ["35709506"]],
                  ["13042668", ["35013396"]],
                  ["13168899", ["34954192", "DV2319269"]],
                  [
                    "14734522",
                    [
                      "34730029",
                      "34754155",
                      "34754437",
                      "34756432",
                      "34803200",
                      "34926663",
                      "35100075",
                      "35123838",
                      "35314514",
                      "35329679",
                      "35377905",
                      "35669503",
                    ],
                  ],
                  [
                    "14969816",
                    [
                      "34645571",
                      "34739052",
                      "34819569",
                      "35016149",
                      "36081481",
                      "36222713",
                      "36222773",
                      "36271370",
                      "36626233",
                      "36861432",
                      "36872845",
                      "37027242",
                      "37135155",
                    ],
                  ],
                  ["15233968", ["35769929", "36997742"]],
                  ["16221336", ["36958220"]],
                  [
                    "16440093",
                    [
                      "35428669",
                      "35552581",
                      "35684833",
                      "35764265",
                      "35867715",
                      "35888369",
                      "DV2113175",
                    ],
                  ],
                  [
                    "17520798",
                    [
                      "311342",
                      "316237",
                      "34727683",
                      "34798472",
                      "34895733",
                      "35011937",
                      "35098593",
                    ],
                  ],
                  ["19425357", ["33206154"]],
                  ["19719108", ["34778479", "34949334"]],
                  ["20406092", ["34984855", "35150286", "35153538"]],
                  [
                    "21771101",
                    ["34708334", "34721864", "34819611", "DV2000132"],
                  ],
                  ["22332712", ["34946942"]],
                  ["24094150", ["34811381"]],
                  [
                    "24187524",
                    [
                      "34949564",
                      "34949567",
                      "34950662",
                      "34952177",
                      "35026902",
                    ],
                  ],
                  ["24190626", ["34866115", "34866391", "35025393"]],
                  ["24190628", ["34870999", "34871962"]],
                  [
                    "25283296",
                    [
                      "34724045",
                      "34845383",
                      "34858649",
                      "34946768",
                      "34949346",
                      "34952198",
                      "35023933",
                      "35025600",
                    ],
                  ],
                  [
                    "25343542",
                    [
                      "331330",
                      "35888981",
                      "36604105",
                      "36606236",
                      "36684807",
                      "36844906",
                      "36929068",
                      "36962076",
                      "DV2364684",
                    ],
                  ],
                  ["25808737", ["243752", "32197535"]],
                  ["26607323", ["36107141", "36881096", "36895934"]],
                  [
                    "26652352",
                    [
                      "33485061",
                      "33493667",
                      "33970059",
                      "34006514",
                      "34413320",
                      "34545661",
                      "34596236",
                      "34684450",
                      "36929141",
                    ],
                  ],
                  ["27169567", ["34673812", "34821828"]],
                  ["27269298", ["34664902"]],
                  ["27316179", ["34905409", "34937749"]],
                  ["27964912", ["35588926"]],
                  ["28032909", ["35711271"]],
                  [
                    "30106817",
                    [
                      "34684313",
                      "35065469",
                      "35127747",
                      "35149027",
                      "35207540",
                      "35211524",
                      "35235092",
                      "35265392",
                      "35309283",
                      "35325726",
                      "35718271",
                      "36189457",
                      "36771425",
                      "CP38C6Q",
                      "DV2110259",
                      "DV2110260",
                    ],
                  ],
                  [
                    "30300533",
                    [
                      "34673746",
                      "34673749",
                      "34673761",
                      "34740398",
                      "34747238",
                      "34834017",
                      "34931055",
                      "35830952",
                      "36025090",
                    ],
                  ],
                  ["31180752", ["34835065", "34940346"]],
                  ["31263374", ["35007297"]],
                  [
                    "31482209",
                    [
                      "35516920",
                      "35517240",
                      "36685154",
                      "36771251",
                      "36771775",
                      "36875499",
                      "36877475",
                      "36919090",
                    ],
                  ],
                  [
                    "32009269",
                    [
                      "278341",
                      "280243",
                      "280644",
                      "280753",
                      "316617",
                      "316641",
                      "316643",
                      "316655",
                      "316656",
                      "316657",
                      "316658",
                      "316659",
                      "316660",
                      "316661",
                      "316662",
                      "316663",
                      "316664",
                      "316665",
                      "316666",
                      "316792",
                      "316798",
                      "316801",
                      "316923",
                      "317056",
                      "324234",
                      "325091",
                      "330362",
                    ],
                  ],
                  [
                    "32057347",
                    [
                      "36372081",
                      "36849367",
                      "36849532",
                      "36996334",
                      "37064009",
                      "37123154",
                      "37137956",
                      "37146428",
                    ],
                  ],
                  [
                    "33915986",
                    [
                      "35158447",
                      "35326377",
                      "35467980",
                      "35470812",
                      "35752375",
                      "35752393",
                    ],
                  ],
                  ["34052522", ["34866139", "35025507"]],
                  ["34101148", ["35025396"]],
                  ["34101149", ["34949600", "34950680"]],
                  [
                    "34106406",
                    [
                      "34841773",
                      "34841965",
                      "34842556",
                      "34843141",
                      "34917821",
                      "34918040",
                      "34918043",
                      "35000697",
                      "35000700",
                    ],
                  ],
                  [
                    "34114296",
                    [
                      "35141059",
                      "35234738",
                      "35235008",
                      "35289288",
                      "35769840",
                    ],
                  ],
                  ["34114309", ["34917428", "35000616"]],
                  [
                    "34148293",
                    ["34682473", "35867023", "36003269", "36487920"],
                  ],
                  [
                    "35373492",
                    [
                      "34625431",
                      "34656037",
                      "34721492",
                      "34721588",
                      "34814841",
                      "34816911",
                      "35040332",
                      "35176919",
                      "35702627",
                      "36608588",
                      "36633123",
                    ],
                  ],
                  [
                    "35642395",
                    [
                      "35049400",
                      "35139251",
                      "35219331",
                      "35564111",
                      "35840959",
                      "35960376",
                      "35994337",
                      "36035574",
                      "36120075",
                      "36173496",
                    ],
                  ],
                  ["37409008", ["34562405", "35235110"]],
                  [
                    "38353524",
                    [
                      "329896",
                      "35503214",
                      "36997970",
                      "37143980",
                      "37187694",
                      "CP2ZQFZ",
                    ],
                  ],
                  ["38403583", ["33806367"]],
                  ["38851652", ["36916140"]],
                  [
                    "38971981",
                    [
                      "35487430",
                      "35683688",
                      "36336305",
                      "36544760",
                      "36706655",
                      "36722002",
                      "36771613",
                      "36843618",
                    ],
                  ],
                  ["40234630", ["37011262"]],
                  [
                    "40284160",
                    [
                      "34584666",
                      "34693477",
                      "34740164",
                      "34835799",
                      "34858875",
                      "35114974",
                      "35274048",
                      "36056683",
                    ],
                  ],
                  [
                    "41025174",
                    [
                      "239115",
                      "35454619",
                      "35601786",
                      "35628075",
                      "35706611",
                      "35773642",
                      "35876417",
                      "35945463",
                      "36155718",
                      "36357442",
                      "36374353",
                      "37139943",
                    ],
                  ],
                  ["41186947", ["35589163"]],
                  ["41547228", ["36144839", "36176320"]],
                  ["42228505", ["35331439"]],
                  ["42252503", ["DV2309009"]],
                  [
                    "42538055",
                    [
                      "35621827",
                      "35723397",
                      "35761229",
                      "35789817",
                      "35808966",
                      "35898701",
                      "36165282",
                      "36403541",
                      "36434862",
                      "36466818",
                      "36541010",
                      "36555226",
                      "36603949",
                      "36749892",
                      "37067772",
                      "37128441",
                    ],
                  ],
                  ["43702558", ["36503694"]],
                  ["44005255", ["36751107", "37165046"]],
                ])),
              l).get(this.D.ctx)) || void 0 === t
              ? void 0
              : t.includes(this.D.cmp)) &&
            (this.D.mon = "0");
        }
        getDiagnosticReportedParams() {
          return this.DIAGNOSTIC_REPORTED_PARAMS;
        }
        getArrayedParams(t, e) {
          const i = this.D[t];
          return (null == i ? void 0 : i.length) ? i.split(e) : [];
        }
        getBlockingInitPath() {
          return this.blockingInitPath;
        }
        getBlockingErrorPath() {
          return this.blockingErrorPath;
        }
        getBlockingEventPath() {
          return this.blockingEventPath;
        }
        getBlockingServerPrefix() {
          return this.blockingServerPrefix;
        }
        getServerPrefix() {
          return this.serverPrefix;
        }
        setBlockingServerPrefix(t) {
          this.blockingServerPrefix = t;
        }
        setServerPrefix(t) {
          this.serverPrefix = t;
        }
        getInitPath() {
          return "js" === this.getDefaultInitType()
            ? this.initJsPath
            : this.initJsonPath;
        }
        getDefaultInitType() {
          return this.defaultInitType;
        }
        getInitJsPath() {
          return this.initJsPath;
        }
        getInitJsonPath() {
          return this.initJsonPath;
        }
        getErrorPath() {
          return this.errorPath;
        }
        getEventPath() {
          return this.eventPath;
        }
        getValueOfTagAttribute(t) {
          return (0, c.safeGetAttribute)(this.scriptElement, t);
        }
        resolveEventUrlPrefix(t) {
          var e, i;
          const n =
            "blocking" ===
            (null ===
              (i =
                null === (e = a.T.u().tags) || void 0 === e ? void 0 : e[t]) ||
            void 0 === i
              ? void 0
              : i.type);
          return `${
            n ? this.getBlockingServerPrefix() : this.getServerPrefix()
          }${n ? this.getBlockingEventPath() : this.getEventPath()}`;
        }
        setDvScriptUrl() {
          var t;
          try {
            const e = n.O.currentWindow().dvSrc ? "dvtp_src_omid" : "dvbm";
            if (
              o.omidAdapter.isSupported() &&
              o.omidAdapter.getVerificationParameters()
            )
              return (
                this.setOmidScript(e), void (this.paramUrlExtractionMethod = 1)
              );
            const i = a.T.getDvtpScriptUrl();
            if (i)
              return (
                (this.dvtpScriptUrl = i),
                void (this.paramUrlExtractionMethod = 2)
              );
            (null === (t = this.scriptElement) || void 0 === t
              ? void 0
              : t.src) &&
              ((this.dvtpScriptUrl = this.scriptElement.src),
              (this.paramUrlExtractionMethod = 3));
          } catch (t) {
            this.paramUrlExtractionMethod = 4;
          }
        }
        missingScriptSessionDiagnostics() {
          var t, e, i, n, s, r, a, c, l, u;
          const h = o.omidAdapter.getSessionData();
          if (
            "sessionStart" !== (null == h ? void 0 : h.type) ||
            null == h.data
          )
            return {};
          const v = h.data,
            p = v.context,
            m = {},
            f = (t, e) => {
              e && (m[(0, d.getDiagnosticQueryParamName)(t)] = e);
            };
          f(
            d.DiagnosticParams.omidJsServiceVersion,
            null === (t = null == p ? void 0 : p.omidJsInfo) || void 0 === t
              ? void 0
              : t.serviceVersion
          ),
            f(d.DiagnosticParams.omidMediaType, v.mediaType),
            f(
              d.DiagnosticParams.omidEnvironment,
              null == p ? void 0 : p.environment
            ),
            f(
              d.DiagnosticParams.omidAdSessionType,
              null == p ? void 0 : p.adSessionType
            ),
            f(
              d.DiagnosticParams.omidAccessMode,
              null == p ? void 0 : p.accessMode
            ),
            f(d.DiagnosticParams.omidSessionCreativeType, v.creativeType),
            f(
              d.DiagnosticParams.omidSessionClientVersion,
              null === (e = null == p ? void 0 : p.omidJsInfo) || void 0 === e
                ? void 0
                : e.sessionClientVersion
            ),
            f(
              d.DiagnosticParams.omidJSPartnerName,
              null === (i = null == p ? void 0 : p.omidJsInfo) || void 0 === i
                ? void 0
                : i.partnerName
            ),
            f(
              d.DiagnosticParams.omidJSPartnerVersion,
              null === (n = null == p ? void 0 : p.omidJsInfo) || void 0 === n
                ? void 0
                : n.partnerVersion
            ),
            f(
              d.DiagnosticParams.omidPartnerName,
              null === (s = null == p ? void 0 : p.omidNativeInfo) ||
                void 0 === s
                ? void 0
                : s.partnerName
            ),
            f(
              d.DiagnosticParams.omidPartnerVersion,
              null === (r = null == p ? void 0 : p.omidNativeInfo) ||
                void 0 === r
                ? void 0
                : r.partnerVersion
            ),
            f(
              d.DiagnosticParams.omidLibraryVersion,
              null === (a = null == p ? void 0 : p.app) || void 0 === a
                ? void 0
                : a.libraryVersion
            ),
            f(
              d.DiagnosticParams.omidDeviceOs,
              null === (c = null == p ? void 0 : p.deviceInfo) || void 0 === c
                ? void 0
                : c.os
            ),
            f(
              d.DiagnosticParams.omidDeviceOsVersion,
              null === (l = null == p ? void 0 : p.deviceInfo) || void 0 === l
                ? void 0
                : l.osVersion
            ),
            f(
              d.DiagnosticParams.omidDeviceType,
              null === (u = null == p ? void 0 : p.deviceInfo) || void 0 === u
                ? void 0
                : u.deviceType
            );
          const g = v.verificationParameters;
          let b = "present";
          return (
            null == g ? (b = "absent") : "" === g && (b = "empty"),
            f(d.DiagnosticParams.omidVerificationParametersState, b),
            m
          );
        }
        setDvScript() {
          try {
            if (
              o.omidAdapter.isSupported() &&
              o.omidAdapter.getVerificationParameters()
            )
              return (
                (this.scriptElementExtractionMethod =
                  u.ScriptElementExtractionMethodState.Omid),
                void (this.scriptElement = {})
              );
            let t = a.T.getTagScriptElem();
            if (
              ((this.scriptElementExtractionMethod =
                u.ScriptElementExtractionMethodState.ExtractFromTagData),
              !t)
            ) {
              const e = `https://cdn.doubleverify.com/${
                  n.O.currentWindow().dvSrc ? "dvtp_src_omid" : "dvbm"
                }.js?`,
                i = (0, c.getElementsByTagNameFromDocument)("script")
                  .filter((t) => 0 === t.src.indexOf(e))
                  .filter((t) => 1 != t.dvvisit);
              if (!i.length) {
                this.scriptElementExtractionMethod =
                  u.ScriptElementExtractionMethodState.NotFound;
                const t = new Error("scriptElement did not find"),
                  e = "string" == typeof t.stack && Math.random() <= 0.1,
                  i = Object.assign(
                    Object.assign(
                      {
                        ee_dp_isom: o.omidAdapter.isSupported() ? "1" : "0",
                        ee_dp_omvpdef: o.omidAdapter.getVerificationParameters()
                          ? "1"
                          : "0",
                        ee_dp_rvkexp: o.omidAdapter.isVendorKeySuffixEnabled()
                          ? "1"
                          : "0",
                      },
                      this.missingScriptSessionDiagnostics()
                    ),
                    {
                      ee_dp_snf_tp: r.Utilities.serializeObjectToQueryString(
                        a.T.getTagParams(),
                        !0
                      ),
                      ee_dp_snf_tu: a.T.getScriptUrl(),
                    }
                  ),
                  n =
                    e && null != t.stack
                      ? { ee_dp_errstk: encodeURIComponent(t.stack) }
                      : {};
                return {
                  clientErrorType: s.ClientErrorType.UnexpectedLostImpError,
                  error: t,
                  messagePrefix: "",
                  extraQueryParams: Object.assign(Object.assign({}, i), n),
                };
              }
              (t = i[0]),
                (this.scriptElementExtractionMethod =
                  u.ScriptElementExtractionMethodState.FoundInDom);
            }
            (this.scriptElement = t), (this.scriptElement.dvvisit = 1);
          } catch (t) {
            const e = (0, r.toError)(t);
            return (
              (e.message = `missing element ${e.message}`),
              {
                clientErrorType: s.ClientErrorType.DvTagArrangementError,
                error: e,
              }
            );
          }
        }
        handleOmidForWebVerificationParams() {
          let t = o.omidAdapter.getVerificationParameters(),
            e = this.extractParamsToObjFromStr(t);
          return (
            (e = this.manipulateOmidForWebParams(e)),
            (t = r.Utilities.serializeObjectToQueryString(e, !0)),
            t
          );
        }
        extractParamsToObjFromStr(t) {
          const e = {},
            i = /([^&#?]*)=([^&#?]*)/gi;
          let n = i.exec(t);
          for (; null != n; ) {
            if (
              !r.Utilities.isNullOrEmpty(n[1]) &&
              !r.Utilities.isNullOrEmpty(n[2])
            ) {
              const t = n[1].trim(),
                i = n[2].trim();
              t && i && (e[t] = i);
            }
            n = i.exec(t);
          }
          return e;
        }
        manipulateOmidForWebParams(t) {
          const e = {};
          Object.keys(t).forEach((i) => {
            e[i.toLowerCase()] = t[i];
          });
          const { ctx: i, cmp: n, plc: s, adsrv: r, sid: o } = e;
          return (
            (e[this.DIAGNOSTIC_PARAM_CTX] = i),
            (e[this.DIAGNOSTIC_PARAM_CMP] = n),
            (e[this.DIAGNOSTIC_PARAM_PLC] = s),
            (e[this.DIAGNOSTIC_PARAM_ADSRV] = r),
            (e[this.DIAGNOSTIC_PARAM_SID] = o),
            (e[this.CTX] = "818052"),
            (e[this.CMP] = "DV517581"),
            (e[this.PLC] = "20210517001"),
            (e[this.ADSRV] = "0"),
            (e[this.SID] = "OMIDWeb"),
            Object.prototype.hasOwnProperty.call(e, this.DUP) &&
              ((e[this.DIAGNOSTIC_PARAM_DUP] = e[this.DUP]),
              delete e[this.DUP]),
            e
          );
        }
        isParamManipulationRequired() {
          const t = "web" === o.omidAdapter.getOmidScenarioType(),
            e = a.T.isOmid3p();
          return t && e;
        }
        setOmidScript(t) {
          const e = this.isParamManipulationRequired()
            ? this.handleOmidForWebVerificationParams()
            : o.omidAdapter.getVerificationParameters();
          (this.dvtpScriptUrl = `https://cdn.doubleverify.com/${t}.js#${e}`),
            (this.scriptElement.src = this.dvtpScriptUrl);
        }
        getAdSize() {
          const { unit: t } = this.D;
          if (!t) return null;
          const [e, i] = t.toLowerCase().split("x");
          if (!e || !i) return null;
          try {
            const t = parseInt(e),
              n = parseInt(i);
            if (!isNaN(t) && !isNaN(n)) return { width: t, height: n };
          } catch (t) {}
          return null;
        }
      }
      (e.C = u),
        (u.ScriptElementExtractionMethodState = {
          Omid: 1,
          ExtractFromTagData: 2,
          FoundInDom: 3,
          NotFound: 4,
        }),
        (e.A = new u());
    },
    5171: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.getAdElementHiddenStatus =
          e.isAdElementHidden =
          e.getElementsDistance =
          e.checkIfElementHasBtreg =
          e.formatElementSize =
          e.getElementOffsetFromScreen =
          e.getElementVisiblePercentage =
          e.isVideoElement =
          e.isLargeAd =
          e.getElementParent =
          e.getElementStaticSize =
          e.getElementSize =
          e.smartInstanceof =
          e.getElementChildren =
          e.getSiblingsNodes =
          e.getObjectSize =
          e.getBoundingClientRect =
          e.extractElementType =
          e.getElementType =
          e.getElementsByTagNameFromDomElement =
          e.querySelectorAll =
          e.querySelectorDeep =
          e.getElementsByClassNameDeep =
          e.getElementByIdDeep =
          e.getElementById =
          e.insertBefore =
          e.createElement =
          e.createImage =
          e.querySelector =
          e.getElementsByClassName =
          e.getCustomElementsByTagName =
          e.getElementsByTagNameFromDocument =
          e.safeSetElementStyle =
          e.hasAttributeValueInclude =
          e.safeGetAttribute =
            void 0);
      const n = i(1906),
        s = i(3301);
      e.safeGetAttribute = (t, e) => {
        let i;
        if (t && e)
          try {
            i = t[e] || t.getAttribute(e);
          } catch (t) {}
        return i;
      };
      e.hasAttributeValueInclude = (t, e) => {
        var i, n;
        const s =
          null !==
            (n =
              null === (i = null == t ? void 0 : t.attributes) || void 0 === i
                ? void 0
                : i.length) && void 0 !== n
            ? n
            : 0;
        for (let i = 0; i < s; i++) {
          const { value: n } = t.attributes[i];
          if (n.includes(e)) return !0;
        }
        return !1;
      };
      e.safeSetElementStyle = (t, e, i) => {
        try {
          t.style.setProperty(e, i);
        } catch (t) {}
      };
      e.getElementsByTagNameFromDocument = (t, e = s.O.workingDocument()) => {
        if (e && t && e.getElementsByTagName) {
          const i = e.getElementsByTagName(t);
          if (i) return n.Utilities.arrayLikeToArray(i);
        }
        return [];
      };
      e.getCustomElementsByTagName = (t, e) => {
        const i = [];
        return (
          (function e(n) {
            n.localName === t && i.push(n),
              n.shadowRoot && e(n.shadowRoot),
              n.childNodes.forEach(e);
          })(e),
          i
        );
      };
      e.getElementsByClassName = (t, e = s.O.workingDocument()) => {
        let i = [];
        if (e && t) {
          let s;
          e.getElementsByClassName
            ? (s = e.getElementsByClassName(t))
            : e.querySelectorAll && (s = e.querySelectorAll("." + t)),
            s && (i = n.Utilities.arrayLikeToArray(s));
        }
        return i;
      };
      e.querySelector = (t, e = s.O.workingDocument()) => {
        try {
          return e.querySelector(t);
        } catch (t) {}
      };
      e.createImage = () => new Image();
      e.createElement = (t, e = s.O.workingDocument()) => {
        if (t) return e.createElement(t);
      };
      e.insertBefore = (t, e, i) => t && t.insertBefore(e, i);
      e.getElementById = (t, e = s.O.workingDocument()) => {
        if (t) return e.getElementById(t);
      };
      e.getElementByIdDeep = (t, e) =>
        (function e(i) {
          if (!i.querySelectorAll) return null;
          const n = i.querySelector(`#${CSS.escape(t)}`);
          if (n) return n;
          const s = i.querySelector(`[id*="${CSS.escape(t)}"]`);
          if (s) return s;
          const r = Array.from(i.querySelectorAll("*"));
          for (const t of r)
            if (t.shadowRoot) {
              const i = e(t.shadowRoot);
              if (i) return i;
            }
          return null;
        })(e);
      e.getElementsByClassNameDeep = (t, e) => {
        const i = [];
        return (
          (function e(n) {
            if (!n.querySelectorAll) return;
            const s = n.querySelectorAll(`.${CSS.escape(t)}`);
            for (const t of Array.from(s)) i.push(t);
            const r = Array.from(n.querySelectorAll("*"));
            for (const t of r) t.shadowRoot && e(t.shadowRoot);
          })(e),
          i
        );
      };
      e.querySelectorDeep = (t, e) =>
        (function e(i) {
          if (!i.querySelectorAll) return null;
          try {
            const e = i.querySelector(t);
            if (e) return e;
          } catch (t) {}
          const n = Array.from(i.querySelectorAll("*"));
          for (const t of n)
            if (t.shadowRoot) {
              const i = e(t.shadowRoot);
              if (i) return i;
            }
          return null;
        })(e);
      e.querySelectorAll = (t, e) => {
        try {
          return t.querySelectorAll(e);
        } catch (t) {}
      };
      e.getElementsByTagNameFromDomElement = (t, e) => {
        if (t && e && t.getElementsByTagName) {
          const i = t.getElementsByTagName(e);
          if (i) return n.Utilities.arrayLikeToArray(i);
        }
        return [];
      };
      e.getElementType = (t) => {
        if (t) return t.nodeName.toLowerCase();
      };
      e.extractElementType = (t) => {
        var e;
        switch (
          null === (e = null == t ? void 0 : t.tagName) || void 0 === e
            ? void 0
            : e.toUpperCase()
        ) {
          case "IFRAME":
            return 1;
          case "SPAN":
            return 2;
          case "DIV":
            return 3;
          case "HTML":
            return 4;
          case "VIDEO":
            return 5;
          case "CANVAS":
            return 7;
          case "SVG":
            return 8;
          case "VIDEO-CANVAS":
            return 9;
          case "IMG":
            return 6;
          default:
            return 0;
        }
      };
      e.getBoundingClientRect = (t) => {
        let e = { left: 0, right: 0, top: 0, bottom: 0, width: 0, height: 0 };
        return (
          (null == t ? void 0 : t.getBoundingClientRect) &&
            (e = t.getBoundingClientRect()),
          e
        );
      };
      e.getObjectSize = (t) => {
        const i = { width: 0, height: 0 };
        if ("object" == (0, e.getElementType)(t)) {
          let s = (0, e.safeGetAttribute)(t, "height"),
            r = (0, e.safeGetAttribute)(t, "width");
          (n.Utilities.isNullOrEmpty(r) && n.Utilities.isNullOrEmpty(s)) ||
            ((r = t.clientWidth), (s = t.clientHeight));
          try {
            (i.height = Number(s)), (i.width = Number(r));
          } catch (t) {}
        }
        return i;
      };
      e.getSiblingsNodes = (t) => {
        const e = [];
        let i = null;
        for (
          (null == t ? void 0 : t.parentNode) && (i = t.parentNode.firstChild);
          i;

        )
          1 === i.nodeType && i !== t && e.push(i),
            (i = i.nextElementSibling || i.nextSibling);
        return e;
      };
      e.getElementChildren = (t) => {
        const e = [];
        if (t.hasChildNodes())
          for (const i of Array.from(t.childNodes))
            (null == i ? void 0 : i.nodeType) === Node.ELEMENT_NODE &&
              e.push(i);
        return e;
      };
      e.smartInstanceof = (t, i, n) => {
        try {
          return (
            t instanceof n[i] ||
            (n.parent != n && (0, e.smartInstanceof)(t, i, n.parent))
          );
        } catch (t) {
          return !1;
        }
      };
      e.getElementSize = (t) => {
        let i = { width: 0, height: 0 };
        try {
          if ("object" != (0, e.getElementType)(t)) {
            const n = (0, e.getBoundingClientRect)(t);
            (i.height = n.height), (i.width = n.width);
          } else i = (0, e.getObjectSize)(t);
        } catch (t) {}
        return i;
      };
      e.getElementStaticSize = (t) => ({
        width: t.innerWidth || t.clientWidth,
        height: t.innerHeight || t.clientHeight,
      });
      e.getElementParent = (t) => {
        if (t) return t.parentNode;
      };
      e.isLargeAd = (t, e, i) => !(!t || i) && t.height * t.width >= e;
      e.isVideoElement = (t) => {
        var e;
        return (
          "video" ==
          (null === (e = null == t ? void 0 : t.nodeName) || void 0 === e
            ? void 0
            : e.toLocaleLowerCase())
        );
      };
      e.getElementVisiblePercentage = (t, e) => {
        if (!t || null == (null == e ? void 0 : e.height) || null == e.width)
          return;
        if (
          ((t, e) =>
            t.bottom <= 0 ||
            t.bottom <= 0 ||
            t.right <= 0 ||
            t.top >= e.height ||
            t.left >= e.width)(t, e) ||
          t.width <= 0 ||
          t.height <= 0
        )
          return 0;
        const i = ((t, e) => {
            let i = t.width;
            return (
              t.left < 0
                ? (i = t.width + t.left)
                : t.left + t.width > e.width && (i = e.width - t.left),
              Math.min(i, e.width)
            );
          })(t, e),
          n = ((t, e) => {
            let i = t.height;
            return (
              t.top < 0
                ? (i = t.height + t.top)
                : t.top + t.height > e.height && (i = e.height - t.top),
              Math.min(i, e.height)
            );
          })(t, e);
        return Math.round(((i * n) / (t.width * t.height)) * 100);
      };
      e.getElementOffsetFromScreen = (t) => {
        let e = 0,
          i = 0;
        try {
          if (t.getBoundingClientRect()) {
            const n = t.getBoundingClientRect();
            (e = n.left), (i = n.top);
          }
          for (t = t.parentElement; t; ) {
            if (
              t.tagName &&
              "iframe" === t.tagName.toLowerCase() &&
              t.getBoundingClientRect()
            ) {
              const n = t.getBoundingClientRect();
              (e += n.left), (i += n.top);
            }
            t = t.parentElement;
          }
        } catch (t) {
          (e = -1), (i = -1);
        }
        return { top: i, left: e };
      };
      e.formatElementSize = (t) => `${t.width}x${t.height}`;
      e.checkIfElementHasBtreg = (t, e) => {
        for (let i = 0; i < t.attributes.length; i++) {
          const n = t.attributes.item(i);
          if (n && n.value == e) return !0;
        }
        return !1;
      };
      const r = (t) => {
        const i = [];
        if (t) {
          let n = (0, e.getElementParent)(t);
          for (; n; ) i.unshift(n), (n = (0, e.getElementParent)(n));
        }
        return i;
      };
      e.getElementsDistance = (t, e) => {
        let i = -1;
        if (t && e)
          if (t == e) i = 0;
          else {
            const n = r(t),
              s = r(e);
            if (n[0] != s[0]) i = -1;
            else {
              for (; n.length > 0 && s.length > 0 && n[0] == s[0]; )
                n.shift(), s.shift();
              i = n.length + s.length;
            }
          }
        else i = -1;
        return i;
      };
      e.isAdElementHidden = (t) => {
        const i = t.ownerDocument
          ? t.ownerDocument.defaultView || t.ownerDocument.parentWindow
          : null;
        if (i) return (0, e.getAdElementHiddenStatus)(t, i);
      };
      e.getAdElementHiddenStatus = (t, i) => {
        let r,
          o = i,
          a = t;
        try {
          if (!s.O.isTop(i)) {
            if (!i.frameElement) return;
            (a = i.frameElement), (o = s.O.getWindowParent(i));
          }
        } catch (t) {}
        let d = 0;
        const c = n.Utilities.getCurrentTime(),
          l = (0, e.getElementOffsetFromScreen)(a),
          u = l.left,
          h = l.top;
        let v, p;
        try {
          v = getComputedStyle(a);
        } catch (t) {
          v = a.style;
        }
        if (a.getBoundingClientRect) {
          const t = a.getBoundingClientRect();
          p = [u + t.width / 2, h + t.height / 2];
        } else p = [u + parseInt(v.width) / 2, h + parseInt(v.height) / 2];
        try {
          "none" === v.display && (d |= 4),
            (r = null == o ? void 0 : o.document.body.querySelectorAll("*"));
          let t = !1;
          [].forEach.call(r, function (i) {
            if (t && i !== a && !i.contains(a) && !a.contains(i))
              try {
                const t = i.getBoundingClientRect(),
                  n = (0, e.getElementOffsetFromScreen)(i);
                n.left + t.width >= p[0] &&
                  n.left <= p[0] &&
                  n.top <= p[1] &&
                  n.top + t.height >= p[1] &&
                  (d |= 1);
              } catch (t) {}
            i === a && (t = !0);
          });
          let i = a;
          for (; i; ) {
            try {
              v = getComputedStyle(i);
            } catch (t) {
              v = i.style;
            }
            v && "none" === v.display && (d |= 4),
              v &&
                ("hidden" === v.visibility ||
                  ("" !== v.opacity && v.opacity < 0.8)) &&
                (d |= 2);
            try {
              if (i.getBoundingClientRect) {
                const t = i.getBoundingClientRect();
                t.width * t.height < 100 && (d |= 8);
              }
            } catch (t) {}
            i =
              i.document && i == i.document.body
                ? i.window.frameElement
                  ? i.window.frameElement
                  : null
                : i.parentElement;
          }
        } catch (t) {
          d = -1;
        }
        return (
          d < 0
            ? (d = -1e3 * (n.Utilities.getCurrentTime() - c))
            : (d += 1e3 * (n.Utilities.getCurrentTime() - c)),
          d
        );
      };
    },
    8844: function (t, e, i) {
      var n =
          (this && this.__createBinding) ||
          (Object.create
            ? function (t, e, i, n) {
                void 0 === n && (n = i);
                var s = Object.getOwnPropertyDescriptor(e, i);
                (s &&
                  !("get" in s
                    ? !e.__esModule
                    : s.writable || s.configurable)) ||
                  (s = {
                    enumerable: !0,
                    get: function () {
                      return e[i];
                    },
                  }),
                  Object.defineProperty(t, n, s);
              }
            : function (t, e, i, n) {
                void 0 === n && (n = i), (t[n] = e[i]);
              }),
        s =
          (this && this.__exportStar) ||
          function (t, e) {
            for (var i in t)
              "default" === i ||
                Object.prototype.hasOwnProperty.call(e, i) ||
                n(e, t, i);
          };
      Object.defineProperty(e, "__esModule", { value: !0 }),
        s(i(4179), e),
        s(i(7483), e),
        s(i(713), e),
        s(i(7826), e),
        s(i(1326), e),
        s(i(99), e),
        s(i(8464), e),
        s(i(5171), e),
        s(i(3998), e),
        s(i(1080), e),
        s(i(6410), e),
        s(i(3301), e),
        s(i(15), e),
        s(i(3629), e);
    },
    3998: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.omidAdapter = e.OmidAdapter = void 0);
      const n = i(4112);
      class s {
        constructor() {
          (this.omidDefaultVendorKey = "doubleverify.com-omid"),
            (this.vendorKeySuffixEnabled = !1);
        }
        init(t, e, i, n) {
          (this.omidJsClient = t),
            (this.omidSessionData = e),
            (this.omidVendorKey = i || this.omidDefaultVendorKey),
            (this.isOmidEnabled = n);
        }
        setVendorKeySuffixEnabled(t) {
          this.vendorKeySuffixEnabled = t;
        }
        isVendorKeySuffixEnabled() {
          return this.vendorKeySuffixEnabled;
        }
        isSupported() {
          var t;
          return (
            (null === (t = this.omidJsClient) || void 0 === t
              ? void 0
              : t.isSupported()) && this.isOmidEnabled
          );
        }
        getIntegrationType() {
          var t;
          const e = this.getOmidContext();
          return "web" ===
            (null === (t = null == e ? void 0 : e.environment) || void 0 === t
              ? void 0
              : t.toLowerCase())
            ? 8
            : 4;
        }
        getSessionData() {
          return this.omidSessionData;
        }
        addEventListener(t, e) {
          this.omidJsClient && this.omidJsClient.addEventListener(t, e);
        }
        registerSessionObserver(t) {
          this.omidJsClient &&
            this.omidJsClient.registerSessionObserver(t, this.omidVendorKey);
        }
        setTimeout(t, e) {
          if (this.omidJsClient) return this.omidJsClient.setTimeout(t, e);
        }
        clearTimeout(t) {
          var e, i;
          null ===
            (i =
              null === (e = this.omidJsClient) || void 0 === e
                ? void 0
                : e.clearTimeout) ||
            void 0 === i ||
            i.call(e, t);
        }
        setInterval(t, e) {
          if (this.omidJsClient) return this.omidJsClient.setInterval(t, e);
        }
        clearInterval(t) {
          var e, i;
          null ===
            (i =
              null === (e = this.omidJsClient) || void 0 === e
                ? void 0
                : e.clearInterval) ||
            void 0 === i ||
            i.call(e, t);
        }
        getVerificationParameters() {
          let t;
          const e = this.getSessionData();
          return (
            (null == e ? void 0 : e.data) &&
              (t = e.data.verificationParameters),
            t
          );
        }
        sendUrl(t) {
          var e, i;
          null ===
            (i =
              null === (e = this.omidJsClient) || void 0 === e
                ? void 0
                : e.sendUrl) ||
            void 0 === i ||
            i.call(e, t);
        }
        injectJavaScriptResource(t, e = () => {}, i = () => {}) {
          this.omidJsClient &&
            this.omidJsClient.injectJavaScriptResource(t, e, i);
        }
        getOmidNativePartnerName() {
          var t;
          let e;
          const i = this.getOmidContext();
          return (
            (null === (t = null == i ? void 0 : i.omidNativeInfo) ||
            void 0 === t
              ? void 0
              : t.partnerName) && (e = i.omidNativeInfo.partnerName),
            e
          );
        }
        getOmidJSPartnerName() {
          var t, e;
          return null ===
            (e =
              null === (t = this.getOmidContext()) || void 0 === t
                ? void 0
                : t.omidJsInfo) || void 0 === e
            ? void 0
            : e.partnerName;
        }
        getOmidVendorKeyIndex(t) {
          if (t) return t.replace(this.omidDefaultVendorKey, "") || "0";
        }
        getOmidContext() {
          const t = this.getSessionData() && this.getSessionData().data;
          let e;
          return (null == t ? void 0 : t.context) && (e = t.context), e;
        }
        getOmidScenarioType() {
          const t = this.getOmidContext();
          return null == t ? void 0 : t.environment;
        }
        getOmidAccessMode() {
          var t, e;
          return null !==
            (e =
              null === (t = this.getOmidContext()) || void 0 === t
                ? void 0
                : t.accessMode) && void 0 !== e
            ? e
            : null;
        }
        getOmidAccessModeNumber(t) {
          return new Map([
            [n.OmidAccessModeString.FULL, 1],
            [n.OmidAccessModeString.DOMAIN, 2],
            [n.OmidAccessModeString.LIMITED, 3],
          ]).get(t);
        }
      }
      (e.OmidAdapter = s), (e.omidAdapter = new s());
    },
    1080: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.RandomUtils = e.RandomUtilsClass = void 0);
      const n = i(3301),
        s = i(1906);
      class r {
        getRandom16() {
          return (
            s.Utilities.getCurrentTime() +
            "" +
            Math.floor(1e6 * Math.random())
          ).substr(0, 16);
        }
        getRandom32() {
          return (
            s.Utilities.getCurrentTime().toString(36) +
            (this.getRandom24ByCrypto() || this.getRandom24())
          );
        }
        getRandom24ByCrypto() {
          if (n.O.isCryptoSupported()) {
            const t = new Uint32Array(4);
            return (
              crypto.getRandomValues(t),
              s.Utilities.arrayLikeToArray(t)
                .map((t) => ("00000000" + t.toString(36)).substr(-6))
                .join("")
            );
          }
        }
        getRandom24() {
          return (
            (Math.random().toString(36) + "000000000000").substr(2, 12) +
            (Math.random().toString(36) + "000000000000").substr(2, 12)
          );
        }
      }
      (e.RandomUtilsClass = r), (e.RandomUtils = new r());
    },
    6410: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ServerContext = e.ServerContextClass = void 0);
      class i {
        getDetectedDeliveryType() {
          var t, e;
          return null ===
            (e = null === (t = this.data) || void 0 === t ? void 0 : t.ce) ||
            void 0 === e
            ? void 0
            : e.ddt;
        }
        getDeviceType() {
          var t, e;
          return null ===
            (e = null === (t = this.data) || void 0 === t ? void 0 : t.ce) ||
            void 0 === e
            ? void 0
            : e.dt;
        }
        isGroupMV4VideoNativeImpression() {
          var t;
          const e = null === (t = this.data) || void 0 === t ? void 0 : t.rtn;
          return !!(null == e ? void 0 : e.gmv4ntv);
        }
        setData(t) {
          this.data = t;
        }
      }
      (e.ServerContextClass = i), (e.ServerContext = new i());
    },
    3301: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.V = e.O = e.R = void 0);
      const n = i(15),
        s = i(99),
        r = i(1906);
      class o {
        constructor() {
          (this.topWinAvailable = !0),
            (this.maxIterations = 1e3),
            (this.trafficScenarioType = 0);
        }
        currentWindow() {
          return dvWindow;
        }
        currentDocument() {
          return document;
        }
        workingWindow() {
          return 3 == this.getScriptInjectionMode()
            ? this.currentWindow().parent
            : this.currentWindow();
        }
        workingDocument(t = this.workingWindow()) {
          return t ? t.document : void 0;
        }
        workingBody(t = this.workingDocument()) {
          return t ? t.body : void 0;
        }
        workingDocumentElement() {
          let t;
          const e = this.workingDocument();
          return e && (t = e.documentElement), t;
        }
        windowTop(t = !1) {
          if (this.topWinAvailable || t)
            try {
              if (t) return this.currentWindow().top;
              if (this.currentWindow().top.document)
                return this.currentWindow().top;
            } catch (t) {
              this.topWinAvailable = !1;
            }
        }
        isTop(t) {
          return t == this.windowTop(!0);
        }
        documentTop() {
          let t;
          const e = this.windowTop();
          return e && (t = e.document), t;
        }
        getWindowParent(t, e) {
          try {
            if (e) return t.parent;
            if (t.parent.document) return t.parent;
          } catch (t) {}
        }
        windowName() {
          return (
            this.currentWindow().name ||
            (this.currentWindow().frameElement
              ? this.currentWindow().frameElement.id
              : "")
          );
        }
        getFrameElement(t) {
          var e;
          try {
            return t !== this.currentWindow() &&
              128 == (128 & this.getScenarioType())
              ? null
              : null !== (e = null == t ? void 0 : t.frameElement) &&
                void 0 !== e
              ? e
              : null;
          } catch (t) {}
        }
        getIframeWindow(t) {
          if (t) return t.contentWindow;
        }
        getDefaultWindow(t) {
          try {
            if (!(null == t ? void 0 : t.ownerDocument)) return;
            return t.ownerDocument.defaultView;
          } catch (t) {}
        }
        getElementWindowDimensions(t) {
          try {
            const e = this.getDefaultWindow(t);
            return e
              ? (({ innerHeight: t, innerWidth: e }) => ({
                  height: t,
                  width: e,
                }))(e)
              : null;
          } catch (t) {}
        }
        isDomlessEnvironment() {
          return !1;
        }
        isIOS() {
          try {
            const { navigator: t } = this.workingWindow();
            return (
              (/iPhone|iPad|iPod|\(Apple TV|iOS|Coremedia|CFNetwork\/.*Darwin/i.test(
                t.userAgent
              ) ||
                (t.vendor && "apple, inc." === t.vendor.toLowerCase())) &&
              !this.workingWindow().MSStream
            );
          } catch (t) {}
        }
        getWindowProtocol() {
          return "https:";
        }
        setTopAccessibleWindow() {
          let t = this.workingWindow();
          try {
            let e = 0;
            for (; !this.isTop(t) && e < this.maxIterations; ) {
              const i = this.getWindowParent(t, !0);
              if (!i.document) break;
              (t = i), e++;
            }
          } catch (t) {}
          this.topAccessibleWindow = t;
        }
        getTopAccessibleWindow() {
          return (
            this.topAccessibleWindow || this.setTopAccessibleWindow(),
            this.topAccessibleWindow
          );
        }
        setScenarioType() {
          this.isTop(this.workingWindow())
            ? (this.trafficScenarioType = 1)
            : this.isTop(this.getTopAccessibleWindow())
            ? (this.trafficScenarioType = 2)
            : (this.trafficScenarioType = 128),
            s.T.isRestrictedAccess() && (this.trafficScenarioType |= 8);
        }
        getScenarioType() {
          return (
            this.trafficScenarioType || this.setScenarioType(),
            this.trafficScenarioType
          );
        }
        getScriptInjectionMode() {
          return (
            this.scriptInjectionMode || this.setScriptInjectionMode(),
            this.scriptInjectionMode
          );
        }
        setScriptInjectionMode() {
          this.scriptInjectionMode = 1;
        }
        objectLookup(t, e, i) {
          try {
            const n = t[e];
            if (n) return n;
            if (!this.isTop(t) && i > 0)
              return this.objectLookup(this.getWindowParent(t, !0), e, i - 1);
          } catch (t) {}
        }
        getUserAgent() {
          var t;
          return null === (t = this.workingWindow().navigator) || void 0 === t
            ? void 0
            : t.userAgent;
        }
        getBaseFileNameFromURL(t) {
          var e, i, n, s;
          const r =
            null ===
              (s =
                null ===
                  (n =
                    null ===
                      (i =
                        null === (e = t.pathname) || void 0 === e
                          ? void 0
                          : e.split("/")) || void 0 === i
                      ? void 0
                      : i.pop()) || void 0 === n
                  ? void 0
                  : n.split(".")) || void 0 === s
              ? void 0
              : s.shift();
          return null == r ? void 0 : r.replace(/\d+$/, "");
        }
        monitorScriptsPerformance(t, e) {
          var i;
          const n = {};
          try {
            if (
              !(null === (i = t.performance) || void 0 === i
                ? void 0
                : i.getEntries)
            )
              return n;
            const s = Object.keys(e),
              r = t.performance
                .getEntries()
                .filter((t) => "resource" === t.entryType.toLocaleLowerCase())
                .filter((t) => s.some((e) => t.name.includes(`/${e}`)));
            for (const t of r) {
              const i = new URL(t.name),
                s = this.getBaseFileNameFromURL(i),
                r = e[s];
              if (null == r ? void 0 : r.length)
                for (const e of r) n[`${s}_${e}`] = Math.round(t[e]);
            }
          } catch (t) {}
          return n;
        }
        getVisibilityState() {
          try {
            return this.workingDocument().visibilityState;
          } catch (t) {}
        }
        getNavigator() {
          return this.currentWindow().navigator;
        }
        isCryptoSupported() {
          return "undefined" != typeof crypto;
        }
        isMessageChannelSupported() {
          return "undefined" != typeof MessageChannel;
        }
        isPostMessageSupported(t = this.workingWindow()) {
          return t && "function" == typeof t.postMessage;
        }
        isNodeSupported() {
          return "undefined" != typeof Node;
        }
        getCurrentScript() {
          return this.currentDocument().currentScript;
        }
        isPerformanceAPISupported() {
          const t = this.currentWindow();
          return !(
            !t.performance ||
            "function" != typeof t.performance.mark ||
            "function" != typeof t.performance.measure ||
            "function" != typeof t.performance.getEntriesByName
          );
        }
        getNumberOfCores() {
          if (this.getNavigator())
            return this.getNavigator().hardwareConcurrency;
        }
        setGlobalVariable(t, e) {
          window[t] = e;
        }
      }
      (e.R = o),
        (e.O = (0, r.uninitializedServiceGuard)("WindowAdaptor")),
        (e.V = function () {
          const t = s.T.u();
          return (
            (e.O = (null == t ? void 0 : t.isDomlessEnvironment)
              ? new n.WindowOmidAdaptorClass()
              : new o()),
            e.O
          );
        });
    },
    15: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.WindowOmidAdaptorClass = e.WindowMock = void 0);
      e.WindowMock = class {
        getWindowMockInstance() {
          return {
            location: { protocol: "https:" },
            document: {
              body: { insertBefore(t, e) {} },
              getElementById(t) {},
              createElement(t) {},
              querySelectorAll(t) {},
            },
          };
        }
      };
      e.WindowOmidAdaptorClass = class {
        constructor() {
          this.windowMock = dvWindow;
        }
        currentWindow() {
          return this.windowMock;
        }
        currentDocument() {
          return this.currentWindow().document;
        }
        workingWindow() {
          return this.currentWindow();
        }
        workingBody() {
          return this.currentWindow().document.body;
        }
        workingDocument() {
          return this.currentDocument();
        }
        workingDocumentElement() {}
        windowTop(t) {
          return this.currentWindow();
        }
        isTop(t) {
          return !0;
        }
        documentTop() {
          return this.currentDocument();
        }
        getWindowParent(t, e) {}
        windowName() {
          return "";
        }
        getIframeWindow(t) {}
        getFrameElement(t) {}
        getDefaultWindow(t) {}
        isDomlessEnvironment() {
          return !0;
        }
        isIOS() {
          return !0;
        }
        getWindowProtocol() {
          return "https:";
        }
        getTopAccessibleWindow() {
          return this.workingWindow();
        }
        getScenarioType() {
          return 4;
        }
        getScriptInjectionMode() {
          return 0;
        }
        objectLookup(t, e, i) {}
        getUserAgent() {}
        monitorScriptsPerformance(t, e) {
          return {};
        }
        getVisibilityState() {}
        getNavigator() {}
        isCryptoSupported() {
          return "undefined" != typeof crypto;
        }
        isMessageChannelSupported() {
          return !1;
        }
        isPostMessageSupported() {
          return !1;
        }
        isNodeSupported() {
          return "undefined" != typeof Node;
        }
        getCurrentScript() {}
        isPerformanceAPISupported() {
          return !1;
        }
        getNumberOfCores() {}
        setGlobalVariable(t, e) {
          globalThis[t] = e;
        }
      };
    },
    3629: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.isPerformanceTimingAllowed =
          e.isPerformanceApiSupported =
          e.logDvSignal =
            void 0);
      const n = i(1906),
        s = i(3301);
      e.logDvSignal = (t) => {
        try {
          const { $logDvSignal: e } = s.O.workingWindow();
          "function" == typeof e && e(t);
        } catch (t) {}
      };
      let r;
      e.isPerformanceApiSupported = () =>
        void 0 !== s.O.currentWindow().performance &&
        "function" == typeof s.O.currentWindow().performance.now;
      e.isPerformanceTimingAllowed = () => (
        void 0 === r &&
          (r =
            !s.O.isDomlessEnvironment() &&
            (0, e.isPerformanceApiSupported)() &&
            n.Utilities.isPercentageCriteriaPassed(10)),
        r
      );
    },
    2330: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.P = void 0);
      const n = i(7102),
        s = i(3283),
        r = i(1805),
        o = i(4112),
        a = i(5051),
        d = i(8844),
        c = i(3692);
      e.P = class {
        constructor() {
          (this.timeoutReference = null),
            (this.shouldRetry = !0),
            (this.numberOfRetries = 0),
            (this.retryInterval = 0);
        }
        get shortName() {
          return `al${this.bit}`;
        }
        start() {
          n.k.addEventListener(
            n.DvEvents.adSelected,
            this.clearTimeoutReference.bind(this)
          ),
            this.findAdCandidate();
        }
        retry(t, e = 0) {
          this.timeoutReference = (0, a.scheduleTask)(
            () => {
              t(
                e,
                this.reportCandidate.bind(this),
                this.reportError.bind(this)
              );
              const i = e + 1;
              this.shouldRetry && i < this.numberOfRetries
                ? this.retry(t, i)
                : (this.shouldRetry = !1);
            },
            0 === e ? 0 : this.retryInterval
          );
        }
        reportCandidate(t, e = !1) {
          (this.shouldRetry = !1),
            this.clearTimeoutReference(),
            (t.N = this.bit),
            (t.windowElement =
              d.O.getDefaultWindow(t.domElement) || d.O.workingWindow()),
            e ||
              n.k.dispatchEvent(
                n.DvEvents.adCandidateLocated,
                new s.AdCandidateEventData(t)
              );
        }
        reportError(t, e = !0) {
          (this.shouldRetry = e),
            r.L.sendError(o.ClientErrorType.AdLocationError, t);
        }
        onClearTimeoutReference() {}
        clearTimeoutReference() {
          this.onClearTimeoutReference(),
            null != this.timeoutReference &&
              ((0, c.clearSafeTimeout)(this.timeoutReference),
              (this.timeoutReference = null));
        }
      };
    },
    2388: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.F = void 0);
      const n = i(8844),
        s = i(2125),
        r = i(4112),
        o = i(7102),
        a = i(1906),
        d = i(3044),
        c = i(5318),
        l = i(2330),
        u = i(5373);
      class h extends l.P {
        constructor() {
          super(),
            (this.numberOfRetries = 10),
            (this.retryInterval = 500),
            (this.diagnosticData = new u.U(this)),
            (this.containerAttribute = n.A.getPartnerContainerId());
        }
        get bit() {
          return s.B.DisplayGenX;
        }
        findAdCandidate() {
          o.k.dispatchEvent(
            o.DvEvents.W,
            new c.q(this.diagnosticData, this.bit)
          ),
            this.retry((t, e, i) => {
              try {
                const i = (0, n.getElementById)(this.containerAttribute);
                if (null != i) {
                  this.diagnosticData.addSuccessAttempt(t, i);
                  const n = new d.AdCandidateData(i);
                  (n.supportedDeliveryType = r.MOBILE_APP_DELIVERY_TYPES), e(n);
                  const s = new d.AdCandidateData(i);
                  (s.supportedDeliveryType = r.STANDARD_WEB_DELIVERY_TYPES),
                    e(s);
                } else
                  this.diagnosticData.addFailureAttempt(
                    t,
                    "No ad candidate found"
                  );
              } catch (e) {
                this.diagnosticData.addFailureAttempt(t, e),
                  i((0, a.toError)(e));
              }
            });
        }
      }
      e.F = h;
    },
    5373: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.U = e.$ = void 0);
      const n = i(9656),
        s = i(8844),
        r = i(1906);
      class o {
        constructor(t, e, i) {
          (this.attempt = t),
            null != e &&
              ((this.candidateDistanceToDvScript = (0, s.getElementsDistance)(
                e,
                s.A.getDVScript()
              )),
              (this.candidateTagName = e.tagName),
              (this.candidateSize = (0, s.formatElementSize)(
                (0, s.getElementSize)(e)
              ))),
            null != i && (this.errorMessage = r.Utilities.errorToJSONString(i));
        }
        toJSON() {
          return {
            d: this.candidateDistanceToDvScript,
            t: this.candidateTagName,
            s: this.candidateSize,
            e: this.errorMessage,
          };
        }
      }
      e.$ = o;
      class a extends n.H {
        constructor(t) {
          super(),
            (this.G = t),
            (this.attempts = []),
            (this.successAttempt = null);
        }
        get J() {
          return this.G;
        }
        addFailureAttempt(t, e) {
          this.attempts[t] = new o(t, null, e);
        }
        addSuccessAttempt(t, e) {
          (this.successAttempt = new o(t, e, null)),
            (this.attempts[t] = this.successAttempt);
        }
        toJSON() {
          const t = {
            r: this.J.numberOfRetries,
            i: this.J.retryInterval,
            a: this.attempts.map((t) => t.toJSON()),
          };
          if (this.successAttempt) {
            const e = {
              n: this.successAttempt.attempt,
              d: this.successAttempt.candidateDistanceToDvScript,
              t: this.successAttempt.candidateTagName,
              s: this.successAttempt.candidateSize,
            };
            t.c = e;
          }
          return t;
        }
      }
      e.U = a;
    },
    7345: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.K = void 0);
      const n = i(3044),
        s = i(2125),
        r = i(4112),
        o = i(7102),
        a = i(2330),
        d = i(4938),
        c = i(8844),
        l = i(5318),
        u = "google_ads_iframe";
      class h extends a.P {
        constructor() {
          super(),
            (this.numberOfRetries = 10),
            (this.retryInterval = 500),
            (this.diagnosticData = new d.Z(this));
        }
        get bit() {
          return s.B.GAM;
        }
        checkIfElementIsGAM(t) {
          var e, i;
          return (
            null !==
              (i =
                null === (e = t.getAttribute("id")) || void 0 === e
                  ? void 0
                  : e.startsWith(u)) &&
            void 0 !== i &&
            i
          );
        }
        findAdCandidate() {
          o.k.dispatchEvent(
            o.DvEvents.W,
            new l.q(this.diagnosticData, this.bit)
          ),
            this.retry((t, e, i) => {
              var s, o;
              try {
                const i = c.O.getFrameElement(c.O.workingWindow());
                if (
                  "iframe" === (null == i ? void 0 : i.tagName.toLowerCase()) &&
                  this.checkIfElementIsGAM(i)
                ) {
                  let o = i;
                  c.S.isSameOriginIframe(i) &&
                    "div" ===
                      (null === (s = i.parentElement) || void 0 === s
                        ? void 0
                        : s.tagName.toLowerCase()) &&
                    this.checkIfElementIsGAM(i.parentElement) &&
                    (o = i.parentElement),
                    this.diagnosticData.addSuccessAttempt(
                      t,
                      o,
                      "advertiser-served",
                      null
                    );
                  const a = new n.AdCandidateData(o);
                  return (
                    (a.supportedDeliveryType = r.STANDARD_WEB_DELIVERY_TYPES),
                    void e(a)
                  );
                }
                const a = c.A.getDVScript(),
                  { parentElement: d } = a;
                if (!d)
                  return void this.diagnosticData.addFailureAttempt(
                    t,
                    "Cannot find parent"
                  );
                if (
                  null === (o = d.getAttribute("id")) || void 0 === o
                    ? void 0
                    : o.startsWith(u)
                ) {
                  this.diagnosticData.addSuccessAttempt(
                    t,
                    d,
                    "site-served",
                    !0
                  );
                  const i = new n.AdCandidateData(d);
                  return (
                    (i.supportedDeliveryType = r.STANDARD_WEB_DELIVERY_TYPES),
                    void e(i)
                  );
                }
                const l = d.querySelector(`[id^=${u}]`);
                if (null !== l) {
                  this.diagnosticData.addSuccessAttempt(
                    t,
                    l,
                    "site-served",
                    !1
                  );
                  const i = new n.AdCandidateData(l);
                  (i.supportedDeliveryType = r.STANDARD_WEB_DELIVERY_TYPES),
                    e(i);
                }
              } catch (e) {
                this.diagnosticData.addFailureAttempt(t, e), i(e);
              }
            });
        }
      }
      e.K = h;
    },
    4938: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.Z = e.tt = void 0);
      const n = i(9656),
        s = i(8844),
        r = i(1906);
      class o {
        constructor(t, e, i, n, o) {
          (this.attempt = t),
            null != e &&
              ((this.candidateDistanceToDvScript = (0, s.getElementsDistance)(
                e,
                s.A.getDVScript()
              )),
              (this.candidateTagName = e.tagName),
              (this.candidateSize = (0, s.formatElementSize)(
                (0, s.getElementSize)(e)
              )),
              (this.candidateAdType = null != n ? n : void 0),
              (this.candidateCameThroughParent = null != o ? o : void 0),
              (this.candidateBtregPresent = (0, s.checkIfElementHasBtreg)(
                e,
                s.A.getBtreg()
              ))),
            null != i && (this.errorMessage = r.Utilities.errorToJSONString(i));
        }
        toJSON() {
          return {
            d: this.candidateDistanceToDvScript,
            t: this.candidateTagName,
            s: this.candidateSize,
            e: this.errorMessage,
            b: this.candidateBtregPresent,
            a: this.candidateAdType,
            p: this.candidateCameThroughParent,
          };
        }
      }
      e.tt = o;
      class a extends n.H {
        constructor(t) {
          super(),
            (this.G = t),
            (this.attempts = []),
            (this.successAttempt = null);
        }
        get J() {
          return this.G;
        }
        addFailureAttempt(t, e) {
          this.attempts[t] = new o(t, null, e, null, null);
        }
        addSuccessAttempt(t, e, i, n) {
          (this.successAttempt = new o(t, e, null, i, n)),
            (this.attempts[t] = this.successAttempt);
        }
        toJSON() {
          const t = {
            r: this.J.numberOfRetries,
            i: this.J.retryInterval,
            a: this.attempts.map((t) => t.toJSON()),
          };
          if (this.successAttempt) {
            const e = {
              n: this.successAttempt.attempt,
              d: this.successAttempt.candidateDistanceToDvScript,
              t: this.successAttempt.candidateTagName,
              s: this.successAttempt.candidateSize,
              b: this.successAttempt.candidateBtregPresent,
              a: this.successAttempt.candidateAdType,
              p: this.successAttempt.candidateCameThroughParent,
            };
            t.c = e;
          }
          return t;
        }
      }
      e.Z = a;
    },
    4380: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.et = void 0);
      const n = i(2125),
        s = i(4112),
        r = i(2330),
        o = i(7102),
        a = i(5318),
        d = i(3044),
        c = i(8085),
        l = i(9453),
        u = i(5382);
      class h extends r.P {
        constructor() {
          super(),
            (this.abortController = new AbortController()),
            (this.adFormatId = u.AdFormatId.CELTRA),
            (this.diagnosticData = new c.it(this));
        }
        get bit() {
          return n.B.CUSTOM;
        }
        findAdCandidate() {
          o.k.dispatchEvent(
            o.DvEvents.W,
            new a.q(this.diagnosticData, this.bit)
          ),
            this.retry(this.locateCeltraElement.bind(this));
        }
        async locateCeltraElement(t, e, i) {
          try {
            const i =
              await l.AdLocationModuleWrapper.getInstance().locateCeltraElement(
                this.abortController.signal
              );
            if (null != i) {
              this.diagnosticData.addSuccessAttempt(t, i);
              const n = new d.AdCandidateData(i);
              (n.supportedDeliveryType = s.MOBILE_APP_DELIVERY_TYPES), e(n);
              const r = new d.AdCandidateData(i);
              (r.supportedDeliveryType = s.STANDARD_WEB_DELIVERY_TYPES), e(r);
            } else
              this.diagnosticData.addFailureAttempt(t, "No ad candidate found");
          } catch (e) {
            this.diagnosticData.addFailureAttempt(t, e), i(e);
          }
        }
        onClearTimeoutReference() {
          this.abortController.abort();
        }
      }
      e.et = h;
    },
    8085: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.it = e.nt = void 0);
      const n = i(9656),
        s = i(8844),
        r = i(1906);
      class o {
        constructor(t, e, i) {
          (this.attempt = t),
            null != e &&
              ((this.candidateDistanceToDvScript = (0, s.getElementsDistance)(
                e,
                s.A.getDVScript()
              )),
              (this.candidateTagName = e.tagName),
              (this.candidateSize = (0, s.formatElementSize)(
                (0, s.getElementSize)(e)
              ))),
            null != i && (this.errorMessage = r.Utilities.errorToJSONString(i));
        }
        toJSON() {
          return {
            d: this.candidateDistanceToDvScript,
            t: this.candidateTagName,
            s: this.candidateSize,
            e: this.errorMessage,
          };
        }
      }
      e.nt = o;
      class a extends n.H {
        constructor(t) {
          super(),
            (this.G = t),
            (this.attempts = []),
            (this.successAttempt = null),
            (this.detectedAdFormat = t.adFormatId);
        }
        get J() {
          return this.G;
        }
        addFailureAttempt(t, e) {
          this.attempts[t] = new o(t, null, e);
        }
        addSuccessAttempt(t, e) {
          (this.successAttempt = new o(t, e, null)),
            (this.attempts[t] = this.successAttempt);
        }
        toJSON() {
          const t = {
            r: this.J.numberOfRetries,
            i: this.J.retryInterval,
            e: { m: this.detectedAdFormat },
            a: this.attempts.map((t) => t.toJSON()),
          };
          return (
            this.successAttempt &&
              (t.c = {
                n: this.successAttempt.attempt,
                d: this.successAttempt.candidateDistanceToDvScript,
                t: this.successAttempt.candidateTagName,
                s: this.successAttempt.candidateSize,
              }),
            t
          );
        }
      }
      e.it = a;
    },
    9453: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdLocationModuleWrapper = void 0);
      const n = i(5382),
        s = i(8844);
      class r {
        constructor() {
          (this.celtraElementDetectionInitiated = !1),
            (this.celtraElementLocatorFn = null);
        }
        static getInstance() {
          return (
            null == this.instance && (this.instance = new r()), this.instance
          );
        }
        detectCeltraElement(t = s.O.workingWindow().document.body) {
          this.celtraElementDetectionInitiated = !0;
          try {
            const e = n.celtraAdFormat.detect(t);
            this.celtraElementLocatorFn =
              e.type === n.FormatDetectionOutcome.DETECTED ? e.locate : null;
          } catch (t) {
            this.celtraElementLocatorFn = null;
          }
          return null != this.celtraElementLocatorFn;
        }
        async locateCeltraElement(t) {
          var e;
          if (!this.celtraElementDetectionInitiated)
            throw new Error(
              "Must detect Celtra element before trying to locate"
            );
          if (null == this.celtraElementLocatorFn) return null;
          const i = await this.celtraElementLocatorFn(t);
          return i.type !== n.AdLocationOutcome.AD_LOCATED
            ? null
            : null !== (e = i.adNode) && void 0 !== e
            ? e
            : null;
        }
      }
      e.AdLocationModuleWrapper = r;
    },
    4633: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.st = e.DEFAULT_TAGS_TO_SCAN = void 0);
      const n = i(2125),
        s = i(4112),
        r = i(7102),
        o = i(8844),
        a = i(3044),
        d = i(5318),
        c = i(2330),
        l = i(8563);
      e.DEFAULT_TAGS_TO_SCAN = [
        "div",
        "span",
        "iframe",
        "img",
        "a",
        "embed",
        "object",
        "image",
        "canvas",
        "svg",
      ];
      class u extends c.P {
        constructor() {
          super(),
            (this.numberOfRetries = 10),
            (this.retryInterval = 500),
            (this.diagnosticData = new l.rt(this));
        }
        get bit() {
          return n.B.DFA;
        }
        findAdCandidate() {
          r.k.dispatchEvent(
            r.DvEvents.W,
            new d.q(this.diagnosticData, this.bit)
          ),
            this.retry((t, i) => {
              const n = o.O.workingDocument(),
                r = Array.from(
                  n.querySelectorAll(e.DEFAULT_TAGS_TO_SCAN.join(","))
                );
              for (const e of r)
                for (const n of Array.from(e.attributes))
                  if (n.value.includes("DfaVisibilityIdentifier")) {
                    this.diagnosticData.addAttempt(t, e, n.name, n.value);
                    const r = new a.AdCandidateData(e);
                    return (
                      (r.supportedDeliveryType = s.STANDARD_WEB_DELIVERY_TYPES),
                      void i(r)
                    );
                  }
            });
        }
      }
      e.st = u;
    },
    8563: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.rt = e.ot = void 0);
      const n = i(9656),
        s = i(8844);
      class r {
        constructor(t, e, i, n) {
          (this.attempt = t),
            (this.candidateTagName = e.tagName),
            (this.candidateSize = (0, s.formatElementSize)(
              (0, s.getElementSize)(e)
            )),
            (this.attributeName = i),
            (this.attributeValue = n);
        }
        toJSON() {
          return {
            t: this.candidateTagName,
            s: this.candidateSize,
            a: this.attributeName,
            v: this.attributeValue,
          };
        }
      }
      e.ot = r;
      class o extends n.H {
        constructor(t) {
          super(),
            (this.G = t),
            (this.attempts = []),
            (this.successAttempt = null);
        }
        get J() {
          return this.G;
        }
        addAttempt(t, e, i, n) {
          const s = new r(t, e, i, n);
          (this.attempts[t] = s), (this.successAttempt = s);
        }
        toJSON() {
          const t = {
            r: this.J.numberOfRetries,
            i: this.J.retryInterval,
            a: this.attempts.map((t) => (null == t ? void 0 : t.toJSON())),
          };
          if (this.successAttempt) {
            const e = {
              n: this.successAttempt.attempt,
              t: this.successAttempt.candidateTagName,
              s: this.successAttempt.candidateSize,
              a: this.successAttempt.attributeName,
              v: this.successAttempt.attributeValue,
            };
            t.c = e;
          }
          return t;
        }
      }
      e.rt = o;
    },
    9165: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.validateMinimumAdSize = e.MIN_AD_HEIGHT = e.MIN_AD_WIDTH = void 0);
      const n = i(8844);
      (e.MIN_AD_WIDTH = 20), (e.MIN_AD_HEIGHT = 20);
      e.validateMinimumAdSize = (t) => {
        if (null == t) return !1;
        const i = (0, n.getElementSize)(t);
        return (
          null != i && i.height > e.MIN_AD_WIDTH && i.width > e.MIN_AD_HEIGHT
        );
      };
    },
    6605: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ValidateByAdSize = void 0);
      const n = i(8844),
        s = i(5466);
      e.ValidateByAdSize = class {
        getAdSize(t) {
          return (0, n.getElementSize)(t);
        }
        isStandardAdSize(t, e) {
          return s.StandardSizes.isStandardAdSize(t, e, 15);
        }
      };
    },
    3537: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ValidateByAdTypeAndSize = void 0);
      const n = i(8844),
        s = i(6605);
      class r extends s.ValidateByAdSize {
        constructor() {
          super(...arguments),
            (this.standardAdTypes = [
              "object",
              "embed",
              "img",
              "iframe",
              "svg",
              "canvas",
            ]);
        }
        validate(t) {
          return (
            this.isStandardAdType(t) &&
            this.isStandardAdSize(this.getAdSize(t), 0)
          );
        }
        isStandardAdType(t) {
          let e = !1;
          if (t) {
            const i = (0, n.getElementType)(t);
            e = this.standardAdTypes.includes(i);
          }
          return e;
        }
      }
      e.ValidateByAdTypeAndSize = r;
    },
    7031: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.ct = void 0);
      const n = i(8844),
        s = i(2125),
        r = i(4112),
        o = i(3044),
        a = i(2330);
      class d extends a.P {
        get bit() {
          return s.B.DISPLAY_IFRAME_FALLBACK;
        }
        findAdCandidate() {
          var t;
          if (0 === n.A.getTagType() && n.O.workingWindow() !== n.O.windowTop())
            try {
              const e =
                null !== (t = n.O.getFrameElement(n.O.workingWindow())) &&
                void 0 !== t
                  ? t
                  : n.O.workingDocumentElement();
              if (null != e) {
                const t = new o.AdCandidateData(e);
                (t.supportedDeliveryType = r.STANDARD_WEB_DELIVERY_TYPES),
                  this.reportCandidate(t);
              }
            } catch (t) {
              this.reportError(t);
            }
        }
      }
      e.ct = d;
    },
    991: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.lt = void 0);
      const n = i(2125),
        s = i(4112),
        r = i(8844),
        o = i(3044),
        a = i(2330);
      class d extends a.P {
        get bit() {
          return n.B.IN_APP_DEFAULT;
        }
        findAdCandidate() {
          try {
            const t = r.O.workingDocumentElement();
            if (null == t) return;
            const e = new o.AdCandidateData(t);
            (e.supportedDeliveryType = s.MOBILE_APP_DELIVERY_TYPES),
              this.reportCandidate(e);
          } catch (t) {
            this.reportError(t);
          }
        }
      }
      e.lt = d;
    },
    4165: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.ut = void 0);
      const n = i(2125),
        s = i(4112),
        r = i(7102),
        o = i(3044),
        a = i(5318),
        d = i(2330),
        c = i(8569),
        l = i(8844);
      class u extends d.P {
        constructor() {
          super(), (this.diagnosticData = new c.ht(this));
        }
        get bit() {
          return n.B.BY_REFERENCE;
        }
        findAdCandidate() {
          r.k.dispatchEvent(
            r.DvEvents.W,
            new a.q(this.diagnosticData, this.bit)
          );
          try {
            const t = l.T.getTagScriptElem().dvAdElement;
            if (null == t)
              return void this.diagnosticData.setElementReferenceFound(!1);
            if (
              (this.diagnosticData.setElementReferenceFound(!0),
              t.nodeType === Node.ELEMENT_NODE)
            ) {
              this.diagnosticData.setValidDomNode(!0);
              const e = new o.AdCandidateData(t);
              (e.supportedDeliveryType = s.MOBILE_APP_DELIVERY_TYPES),
                this.reportCandidate(e);
              const i = new o.AdCandidateData(t);
              (i.supportedDeliveryType = s.STANDARD_WEB_DELIVERY_TYPES),
                this.reportCandidate(i);
            } else this.diagnosticData.setValidDomNode(!1);
          } catch (t) {
            this.reportError(t, !1);
          }
        }
      }
      e.ut = u;
    },
    8569: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.ht = void 0);
      const n = i(9656);
      class s extends n.H {
        constructor(t) {
          super(),
            (this.G = t),
            (this.hasElementReference = !1),
            (this.isValidDomNode = !1);
        }
        get J() {
          return this.G;
        }
        setElementReferenceFound(t) {
          this.hasElementReference = t;
        }
        setValidDomNode(t) {
          this.isValidDomNode = t;
        }
        toJSON() {
          return { f: this.hasElementReference, v: this.isValidDomNode };
        }
      }
      e.ht = s;
    },
    783: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.vt = void 0);
      const n = i(2125),
        s = i(7102),
        r = i(5318),
        o = i(2330),
        a = i(8844),
        d = i(6151),
        c = i(172),
        l = i(9165),
        u = i(8406);
      class h extends o.P {
        constructor(t = 7, e = l.validateMinimumAdSize) {
          super(),
            (this.maxParentWindowDepth = t),
            (this.adSizeValidator = e),
            (this.numberOfRetries = 10),
            (this.retryInterval = 500),
            (this.diagnosticData = new d.ft(this));
        }
        get bit() {
          return n.B.MARKED;
        }
        findAdCandidate() {
          s.k.dispatchEvent(
            s.DvEvents.W,
            new r.q(this.diagnosticData, this.bit)
          );
          const t = this.getBtregValues();
          if (null == t) return;
          const e = {
            btreg: t,
            tagsToScan: this.getTagsToScan(),
            attributesToScan: this.getAttributesToScan(),
            canSearchInParentWindow: this.canSearchInParentWindow(),
            adSizeValidator: this.adSizeValidator,
          };
          this.diagnosticData.setExecutionData(e),
            this.retry((t, i, n) => {
              const s = new d.gt(t, this.diagnosticData);
              this.diagnosticData.attempts[t] = s;
              c.bt.create(this, s).findAdCandidate(e, i, n);
            });
        }
        getBtregValues() {
          const t = a.A.getBtreg();
          if (null == t || t.length < 5) return;
          const e = this.sanitizeBtreg(t);
          return {
            raw: t,
            sanitized: e,
            sanitizedAndCssEscaped: this.cssEscapeBtreg(e),
          };
        }
        sanitizeBtreg(t) {
          let e = t;
          return (
            e.startsWith("^") && (e = e.slice(1)),
            e.endsWith("$") && (e = e.slice(0, -1)),
            e
          );
        }
        cssEscapeBtreg(t) {
          const e =
              "function" ==
              typeof (null === CSS || void 0 === CSS ? void 0 : CSS.escape),
            i = /^\d+.*/.test(t);
          return e && !i ? CSS.escape(t) : t;
        }
        getTagsToScan() {
          const t = a.A.getCustomTags();
          return t.length > 0
            ? Array.from(
                new Set([...t, ...u.MARKED_AD_LOCATOR_DEFAULT_TAGS_TO_SCAN])
              )
            : u.MARKED_AD_LOCATOR_DEFAULT_TAGS_TO_SCAN;
        }
        getAttributesToScan() {
          const t = a.A.getCustomAttributes();
          return t.length > 0
            ? t
            : u.MARKED_AD_LOCATOR_DEFAULT_ATTRIBUTES_TO_SCAN;
        }
        canSearchInParentWindow() {
          return 2 == (2 & a.O.getScenarioType());
        }
      }
      e.vt = h;
    },
    172: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.bt = void 0);
      const n = i(8844),
        s = i(7363),
        r = i(9110),
        o = i(5449);
      e.bt = class {
        static create(t, e) {
          return new this(t, e);
        }
        constructor(t, e) {
          (this.wt = t), (this.diagnostics = e);
        }
        get maxParentWindowDepth() {
          return this.wt.maxParentWindowDepth;
        }
        findCandidateWithMethod(t, e) {
          const i = o.elementLocators[e],
            { candidate: n, attribute: a } = i(this.currentWindow, t);
          if (null == n) return;
          if (
            (this.diagnostics.setCandidateForDepth(this.windowDepth, n, e, a),
            t.adSizeValidator(n))
          )
            return (
              this.diagnostics.setSelectedAdCandidate(
                n,
                this.windowDepth,
                e,
                a
              ),
              (0, s.toAdCandidates)(n, this.currentWindow)
            );
          const d = (0, r.maybeExtractAdFromCandidates)(t, n);
          return null != d
            ? (this.diagnostics.setChildCandidateForDepth(d, e),
              t.adSizeValidator(d)
                ? (this.diagnostics.setSelectedAdCandidate(
                    d,
                    this.windowDepth,
                    e,
                    a
                  ),
                  (0, s.toAdCandidates)(d, this.currentWindow))
                : void 0)
            : void 0;
        }
        findAdCandidate(t, e, i) {
          (this.currentWindow = n.O.workingWindow()), (this.windowDepth = 0);
          try {
            for (; null != this.currentWindow; ) {
              for (const i of ["id", "class", "frame", "tag"]) {
                const n = this.findCandidateWithMethod(t, i);
                if (null != n) {
                  for (const t of n) e(t);
                  return;
                }
              }
              this.maybeMoveToParentWindow(t.canSearchInParentWindow);
            }
          } catch (t) {
            i(t);
          }
        }
        maybeMoveToParentWindow(t) {
          if (!t) return void (this.currentWindow = null);
          if (this.windowDepth >= this.maxParentWindowDepth - 1)
            return void (this.currentWindow = null);
          const e = n.O.getWindowParent(this.currentWindow);
          if (e !== this.currentWindow)
            return (this.windowDepth += 1), void (this.currentWindow = e);
          this.currentWindow = null;
        }
      };
    },
    8406: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.MARKED_AD_LOCATOR_DEFAULT_ATTRIBUTES_TO_SCAN =
          e.MARKED_AD_LOCATOR_DEFAULT_TAGS_TO_SCAN =
            void 0),
        (e.MARKED_AD_LOCATOR_DEFAULT_TAGS_TO_SCAN = [
          "div",
          "span",
          "iframe",
          "img",
          "a",
          "embed",
          "object",
          "image",
          "canvas",
          "svg",
        ]),
        (e.MARKED_AD_LOCATOR_DEFAULT_ATTRIBUTES_TO_SCAN = [
          "src",
          "href",
          "name",
        ]);
    },
    6151: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ft = e.gt = void 0);
      const n = i(9656),
        s = i(8844),
        r = i(9165),
        o = i(8406);
      e.gt = class {
        constructor(t, e, i = r.validateMinimumAdSize) {
          (this.attempt = t),
            (this.parent = e),
            (this.adSizeValidator = i),
            (this.candidates = {
              id: void 0,
              class: void 0,
              frame: void 0,
              tag: void 0,
            });
        }
        setSelectedAdCandidate(t, e, i, n) {
          this.parent.setSelectedAdCandidate(t, this.attempt, e, n, i);
        }
        assignCandidateObject(t, e) {
          this.candidates[t] = e;
        }
        getCandidateObject(t) {
          return this.candidates[t];
        }
        setCandidateForDepth(t, e, i, n = void 0) {
          this.windowDepth = t;
          const r = {
            candidateDistance: (0, s.getElementsDistance)(e, s.A.getDVScript()),
            candidateTag: e.tagName,
            candidateSize: (0, s.formatElementSize)((0, s.getElementSize)(e)),
            candidateSizeValid: this.adSizeValidator(e),
            candidateBtregAttribute: n,
          };
          this.assignCandidateObject(i, r);
        }
        setChildCandidateForDepth(t, e) {
          null == this.candidates[e] && (this.candidates[e] = {}),
            (this.candidates[e].childCandidate = {
              distance: (0, s.getElementsDistance)(t, s.A.getDVScript()),
              tag: t.tagName,
              size: (0, s.formatElementSize)((0, s.getElementSize)(t)),
              sizeValid: this.adSizeValidator(t),
            });
        }
        toJSON() {
          if (null == this.windowDepth) return;
          const t = { w: this.windowDepth };
          for (const e of Object.keys(this.candidates)) {
            const i = this.candidates[e];
            null != i && (t[e[0]] = this.adCandidateDiagnosticsToJSON(i));
          }
          return t;
        }
        adCandidateDiagnosticsToJSON(t) {
          const e = {
            d: t.candidateDistance,
            t: t.candidateTag,
            s: t.candidateSize,
            v: t.candidateSizeValid ? 1 : 0,
          };
          return (
            null != t.candidateBtregAttribute &&
              (e.a = t.candidateBtregAttribute),
            null != t.childCandidate &&
              (e.c = {
                d: t.childCandidate.distance,
                t: t.childCandidate.tag,
                s: t.childCandidate.size,
                v: t.childCandidate.sizeValid ? 1 : 0,
              }),
            e
          );
        }
      };
      class a extends n.H {
        constructor(t) {
          super(), (this.G = t), (this.attempts = []);
        }
        get J() {
          return this.G;
        }
        setExecutionData(t) {
          this._t = t;
        }
        setSelectedAdCandidate(t, e, i, n, s) {
          null == this.selectedAdCandidate &&
            (this.selectedAdCandidate = {
              candidate: t,
              attempt: e,
              windowDepth: i,
              attribute: n,
              method: s,
            });
        }
        toJSON() {
          return Object.assign(this.yt(), {
            a: this.attempts.map((t) => t.toJSON()),
            e: this.St(),
            c: this.getSelectedCandidateJSON(),
          });
        }
        St() {
          if (null != this._t)
            return {
              sb: this._t.btreg.sanitized,
              seb: this._t.btreg.sanitizedAndCssEscaped,
              t:
                this._t.tagsToScan === o.MARKED_AD_LOCATOR_DEFAULT_TAGS_TO_SCAN
                  ? void 0
                  : this._t.tagsToScan,
              a:
                this._t.attributesToScan ===
                o.MARKED_AD_LOCATOR_DEFAULT_ATTRIBUTES_TO_SCAN
                  ? void 0
                  : this._t.attributesToScan,
              p: this._t.canSearchInParentWindow ? 1 : 0,
            };
        }
        getSelectedCandidateJSON() {
          if (null == this.selectedAdCandidate) return;
          const {
            candidate: t,
            attempt: e,
            method: i,
            windowDepth: n,
            attribute: r,
          } = this.selectedAdCandidate;
          return {
            m: i[0],
            n: e,
            w: n,
            d: (0, s.getElementsDistance)(t, s.A.getDVScript()),
            t: t.tagName,
            s: (0, s.formatElementSize)((0, s.getElementSize)(t)),
            a: r,
          };
        }
      }
      e.ft = a;
    },
    9110: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.adExtractors =
          e.maybeExtractAdFromCandidates =
          e.extractBiggestNestedChildElement =
          e.extractBiggestNestedElement =
          e.extractAdFromAnchor =
            void 0);
      const n = i(1906),
        s = i(8844);
      e.extractAdFromAnchor = (t, e) => {
        const i = (0, s.getElementsByTagNameFromDomElement)(e, "img");
        return null == i || 0 === i.length ? null : i[0];
      };
      const r = [
          "embed",
          "iframe",
          "object",
          "img",
          "span",
          "div",
          "svg",
          "canvas",
        ],
        o = (t) => r.indexOf((0, s.getElementType)(t));
      e.extractBiggestNestedElement = (t, e) => {
        const i = n.Utilities.arrayLikeToArray(
          e.querySelectorAll(r.join(","))
        ).filter(t.adSizeValidator);
        let a = null,
          d = -1;
        for (const t of i) {
          const e = (0, s.getElementSize)(t),
            i = e.width * e.height;
          (i > d || (i === d && o(t) > o(a))) && ((a = t), (d = i));
        }
        return a;
      };
      e.extractBiggestNestedChildElement = (t, i) =>
        (0, e.extractBiggestNestedElement)(t, i);
      (e.maybeExtractAdFromCandidates = (t, i) => {
        const n = (0, s.getElementType)(i),
          r = e.adExtractors[n];
        return null == r ? null : r(t, i);
      }),
        (e.adExtractors = {
          a: e.extractAdFromAnchor,
          div: e.extractBiggestNestedChildElement,
          object: e.extractBiggestNestedChildElement,
          span: e.extractBiggestNestedChildElement,
        });
    },
    5449: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.elementLocators =
          e.locateElementByTag =
          e.locateElementByFrame =
          e.locateElementByClass =
          e.locateElementById =
            void 0);
      const n = i(8844);
      e.locateElementById = (t, e) => {
        var i, s, r;
        return {
          candidate:
            null !==
              (r =
                null !==
                  (s =
                    null !==
                      (i = (0, n.getElementById)(
                        e.btreg.sanitized,
                        t.document
                      )) && void 0 !== i
                      ? i
                      : (0, n.querySelector)(
                          `[id*="${e.btreg.sanitizedAndCssEscaped}"]`,
                          t.document
                        )) && void 0 !== s
                  ? s
                  : (0, n.getElementByIdDeep)(e.btreg.sanitized, t.document)) &&
            void 0 !== r
              ? r
              : void 0,
          attribute: "id",
        };
      };
      e.locateElementByClass = (t, e) => {
        let i = (0, n.getElementsByClassName)(
          e.btreg.sanitizedAndCssEscaped,
          t.document
        );
        0 === i.length &&
          (i = (0, n.getElementsByClassNameDeep)(
            e.btreg.sanitizedAndCssEscaped,
            t.document
          ));
        return { candidate: i.shift(), attribute: "class" };
      };
      e.locateElementByFrame = (t, e) => {
        const i = n.O.getFrameElement(t);
        if (null == i) return { candidate: void 0, attribute: void 0 };
        const s = e.attributesToScan.find((t) => {
          var n;
          return (
            i.getAttribute(t) === e.btreg.sanitized ||
            (null === (n = i.getAttribute(t)) || void 0 === n
              ? void 0
              : n.includes(e.btreg.sanitized))
          );
        });
        return { candidate: void 0 === s ? void 0 : i, attribute: s };
      };
      e.locateElementByTag = (t, e) => {
        var i;
        const r = n.A.getCustomTags();
        for (const o of e.tagsToScan)
          if (r.includes(o)) {
            const i = s(t, e, o);
            if (null != i.candidate) return i;
          } else
            for (const s of e.attributesToScan) {
              const r = `${o}[${s}*="${e.btreg.sanitizedAndCssEscaped}"]`,
                a =
                  null !== (i = (0, n.querySelector)(r, t.document)) &&
                  void 0 !== i
                    ? i
                    : (0, n.querySelectorDeep)(r, t.document);
              if (null != a) return { candidate: a, attribute: s };
            }
        return { candidate: void 0, attribute: void 0 };
      };
      const s = (t, e, i) => {
        const s = Array.from(new Set(["id", "class", ...e.attributesToScan])),
          r = (0, n.getCustomElementsByTagName)(i, t.document);
        for (const t of r) {
          const i = s.find((i) => {
            const s = (0, n.safeGetAttribute)(t, i);
            return "string" == typeof s && s.includes(e.btreg.sanitized);
          });
          if (null != i) return { candidate: t, attribute: i };
        }
        return { candidate: void 0, attribute: void 0 };
      };
      e.elementLocators = {
        id: e.locateElementById,
        class: e.locateElementByClass,
        frame: e.locateElementByFrame,
        tag: e.locateElementByTag,
      };
    },
    7363: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.toAdCandidates = void 0);
      const n = i(4112),
        s = i(3044);
      e.toAdCandidates = (t, e) => {
        const i = new s.AdCandidateData(t);
        (i.windowElement = e),
          (i.supportedDeliveryType = n.MOBILE_APP_DELIVERY_TYPES);
        const r = new s.AdCandidateData(t);
        return (
          (r.windowElement = e),
          (r.supportedDeliveryType = n.STANDARD_WEB_DELIVERY_TYPES),
          [i, r]
        );
      };
    },
    8356: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.Mt = void 0);
      const n = i(2125),
        s = i(4112),
        r = i(7102),
        o = i(3044),
        a = i(5318),
        d = i(2330),
        c = i(3537),
        l = i(5265),
        u = i(8844);
      class h extends d.P {
        constructor() {
          super(),
            (this.numberOfRetries = 10),
            (this.retryInterval = 500),
            (this.maxDistance = 20),
            (this.validator = new c.ValidateByAdTypeAndSize()),
            (this.diagnosticData = new l.Ot(this));
        }
        get bit() {
          return n.B.NEAREST_AD;
        }
        searchNearestAd() {
          const t = u.A.getDVScript();
          if (!t) return null;
          const e = new WeakSet(),
            i = [t];
          e.add(t);
          let n = 0,
            s = 1,
            r = 0;
          for (; i.length > 0 && n < this.maxDistance; ) {
            const t = i.shift();
            if (this.validator.validate(t)) return t;
            const o = t.parentElement;
            o && !e.has(o) && (e.add(o), i.push(o), r++);
            const a = Array.from(t.children);
            for (const t of a) e.has(t) || (e.add(t), i.push(t), r++);
            s--, 0 === s && (n++, (s = r), (r = 0));
          }
          return null;
        }
        findAdCandidate() {
          r.k.dispatchEvent(
            r.DvEvents.W,
            new a.q(this.diagnosticData, this.bit)
          ),
            this.retry((t, e, i) => {
              try {
                const i = this.searchNearestAd();
                if (null != i) {
                  this.diagnosticData.addSuccessAttempt(t, i);
                  const n = new o.AdCandidateData(i);
                  (n.supportedDeliveryType = s.STANDARD_WEB_DELIVERY_TYPES),
                    e(n);
                }
              } catch (e) {
                this.diagnosticData.addFailureAttempt(t, e), i(e);
              }
            });
        }
      }
      e.Mt = h;
    },
    5265: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.Ot = e.Et = void 0);
      const n = i(9656),
        s = i(8844),
        r = i(1906);
      class o {
        constructor(t, e, i) {
          (this.attempt = t),
            null != e &&
              ((this.candidateDistanceToDvScript = (0, s.getElementsDistance)(
                e,
                s.A.getDVScript()
              )),
              (this.candidateTagName = e.tagName),
              (this.candidateSize = (0, s.formatElementSize)(
                (0, s.getElementSize)(e)
              ))),
            null != i && (this.errorMessage = r.Utilities.errorToJSONString(i));
        }
        toJSON() {
          return {
            d: this.candidateDistanceToDvScript,
            t: this.candidateTagName,
            s: this.candidateSize,
            e: this.errorMessage,
          };
        }
      }
      e.Et = o;
      class a extends n.H {
        constructor(t) {
          super(),
            (this.G = t),
            (this.attempts = []),
            (this.successAttempt = null);
        }
        get J() {
          return this.G;
        }
        addFailureAttempt(t, e) {
          this.attempts[t] = new o(t, null, e);
        }
        addSuccessAttempt(t, e) {
          (this.successAttempt = new o(t, e, null)),
            (this.attempts[t] = this.successAttempt);
        }
        toJSON() {
          const t = {
            r: this.J.numberOfRetries,
            i: this.J.retryInterval,
            a: this.attempts.map((t) => t.toJSON()),
          };
          if (this.successAttempt) {
            const e = {
              n: this.successAttempt.attempt,
              d: this.successAttempt.candidateDistanceToDvScript,
              t: this.successAttempt.candidateTagName,
              s: this.successAttempt.candidateSize,
            };
            t.c = e;
          }
          return t;
        }
      }
      e.Ot = a;
    },
    3047: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.At = void 0);
      const n = i(2125),
        s = i(4112),
        r = i(3044),
        o = i(2330);
      class a extends o.P {
        get bit() {
          return n.B.OMID;
        }
        findAdCandidate() {
          const t = new r.AdCandidateData(null);
          (t.omidMeasuredElementType = 0),
            (t.supportedDeliveryType = s.ALL_DELIVERY_TYPES),
            this.reportCandidate(t);
        }
      }
      e.At = a;
    },
    7934: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.Tt = void 0);
      const n = i(2125),
        s = i(4112),
        r = i(3044),
        o = i(2330),
        a = i(2237),
        d = i(4642),
        c = i(7102),
        l = i(5318);
      class u extends o.P {
        constructor() {
          super(), (this.diagnosticData = new a.It(this));
        }
        get bit() {
          return n.B.VPAID;
        }
        findAdCandidate() {
          var t;
          c.k.dispatchEvent(
            c.DvEvents.W,
            new l.q(this.diagnosticData, this.bit)
          );
          const e = d.VpaidWrapper.getDvVpaid();
          if (
            null !=
            (null === (t = null == e ? void 0 : e.asset) || void 0 === t
              ? void 0
              : t.player)
          ) {
            const t = new r.AdCandidateData(e.asset.player);
            t.supportedDeliveryType = s.MOBILE_APP_DELIVERY_TYPES;
            const i = new r.AdCandidateData(e.asset.player);
            (i.supportedDeliveryType = s.STANDARD_WEB_DELIVERY_TYPES),
              this.diagnosticData.setVpaidPlayerFound(!0),
              this.reportCandidate(t),
              this.reportCandidate(i);
          } else this.diagnosticData.setVpaidPlayerFound(!1);
        }
      }
      e.Tt = u;
    },
    2237: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.It = void 0);
      const n = i(9656);
      class s extends n.H {
        constructor(t) {
          super(), (this.G = t), (this.vpaidPlayerFound = !1);
        }
        get J() {
          return this.G;
        }
        setVpaidPlayerFound(t) {
          this.vpaidPlayerFound = t;
        }
        toJSON() {
          return { f: this.vpaidPlayerFound };
        }
      }
      e.It = s;
    },
    7093: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.blockingHooks = void 0);
      const n = i(7102),
        s = i(1805),
        r = i(1293),
        o = i(1906),
        a = i(3692),
        d = i(7065);
      e.blockingHooks = {
        onImpressionIdAssigned: (t) => {
          d.TcfClientStop.assignVerifyImpressionId(t);
        },
        sendMessage: (t) => {
          s.L.sendMessage(t);
        },
        sendError: (t, e, i) => {
          s.L.sendError(t, e, i);
        },
        registerEventCall: (t, e, i) => {
          void 0 === i
            ? s.L.registerEventCall(t, e)
            : s.L.registerEventCall(t, e, i);
        },
        executeTagExtensions: (t, e) => {
          d.TcfClientStop.isExecutionStopped() ||
            (0, r.TagExtensionsHandler)(t, e, 2).execute();
        },
        o: () => n.Ct,
        utils: { setSafeTimeout: a.setSafeTimeout, toError: o.toError },
      };
    },
    5782: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdDomElementObserverBL = void 0);
      const n = i(7102),
        s = i(5007),
        r = i(9198);
      class o extends s.BaseAdBL {
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.adSelected]: this.startObservingDomElement.bind(this),
          };
        }
        startObservingDomElement(t) {
          var e, i;
          const n =
              null === (e = null == t ? void 0 : t.adCandidate) || void 0 === e
                ? void 0
                : e.domElement,
            s =
              null === (i = null == t ? void 0 : t.adCandidate) || void 0 === i
                ? void 0
                : i.windowElement;
          if (n && s) {
            r.ScriptDynamicFlags.getInstance().turnOn(4);
            const t = new MutationObserver(
                function (e) {
                  this.handleDomElementRemoval(t, n, s);
                }.bind(this)
              ),
              e = { subtree: !0, childList: !0 };
            t.observe(s.document, e);
          }
        }
        handleDomElementRemoval(t, e, i) {
          i.document.contains(e) ||
            (r.ScriptDynamicFlags.getInstance().turnOn(8), t.disconnect());
        }
        init() {}
      }
      e.AdDomElementObserverBL = o;
    },
    8909: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdElementInfoExtractorBL = void 0);
      const n = i(7102),
        s = i(5007),
        r = i(1906),
        o = i(8844),
        a = i(3537);
      class d extends s.BaseAdBL {
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return { [n.DvEvents.adSelected]: this.adSelected.bind(this) };
        }
        adSelected(t) {
          let e = this.extractAdElementType(t);
          (e = this.logAdDimensionDataPoints(t) || e),
            e && n.k.dispatchEvent(n.DvEvents.reportData, t);
        }
        extractAdElementType(t) {
          var e;
          return (
            !!(null === (e = null == t ? void 0 : t.adCandidate) || void 0 === e
              ? void 0
              : e.domElement) &&
            ((t.adCandidate.adElementType = (0, o.extractElementType)(
              t.adCandidate.domElement
            )),
            !0)
          );
        }
        logAdDimensionDataPoints(t) {
          var e;
          try {
            const i =
              null === (e = null == t ? void 0 : t.adCandidate) || void 0 === e
                ? void 0
                : e.domElement;
            if (!r.Utilities.isNullOrEmpty(i)) {
              const { tagName: e } = i;
              if ("IFRAME" === (null == e ? void 0 : e.toUpperCase())) {
                const e = this.getIframeDocument(i);
                if (void 0 !== e) {
                  const i = this.getBiggestChildElement(e);
                  if (void 0 !== i) {
                    const { scrollHeight: e, scrollWidth: n } = i;
                    return (
                      (t.adCandidate.largestChildElementHeight = e),
                      (t.adCandidate.largestChildElementWidth = n),
                      !0
                    );
                  }
                }
              }
            }
            return !1;
          } catch (t) {
            return !1;
          }
        }
        getIframeDocument(t) {
          try {
            return t.contentDocument || t.contentWindow.document;
          } catch (t) {
            return;
          }
        }
        getBiggestChildElement(t) {
          try {
            const e = this.getPotentialAdChildren(t);
            return this.findBiggestChild(e);
          } catch (t) {}
        }
        findBiggestChild(t) {
          const e = new a.ValidateByAdTypeAndSize();
          return t
            .filter((t) => e.validate(t))
            .reduce((t, e) =>
              t.scrollHeight * t.scrollWidth >= e.scrollHeight * e.scrollWidth
                ? t
                : e
            );
        }
        getPotentialAdChildren(t) {
          const e = t.querySelectorAll(
            ["object", "embed", "img", "iframe", "svg", "canvas"].join(",")
          );
          return Array.prototype.slice.call(e);
        }
        init() {}
      }
      e.AdElementInfoExtractorBL = d;
    },
    9656: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdLocationDiagnosticsLogger = e.H = void 0);
      const n = i(7102),
        s = i(1805),
        r = i(1360),
        o = i(7614),
        a = i(5007),
        d = i(1906),
        c = i(8844);
      e.H = class {
        yt() {
          return { r: this.J.numberOfRetries, i: this.J.retryInterval };
        }
      };
      class l extends a.BaseAdBL {
        constructor() {
          super(...arguments), (this.didLogDiagnosticData = !1);
        }
        getActionName() {
          return "AdLocationDiagnosticsLogger";
        }
        isSupported() {
          return !0;
        }
        init() {}
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.adSelected]: this.logDiagnosticData.bind(this),
            [n.DvEvents.unloadData]: this.logDiagnosticData.bind(this),
          };
        }
        logDiagnosticData() {
          if (this.didLogDiagnosticData) return;
          this.didLogDiagnosticData = !0;
          const t = c.A.getPartnerContainerId();
          s.L.sendMessage({
            [(0, r.getDiagnosticQueryParamName)(
              r.DiagnosticParams.timeTillAdSelected
            )]: d.Utilities.getTimeDiff(),
            adlmid: o.adLocationSelectionDiagnostics.adLocatingModeId,
            adfnd: o.adLocationSelectionDiagnostics.adFoundIndicator,
            slctype: o.adLocationSelectionDiagnostics.selectedElementType,
            genxp: c.A.isDisplayGenXEnabled() ? 1 : 0,
            genxc: null != t && "" !== t ? 1 : 0,
          });
        }
      }
      e.AdLocationDiagnosticsLogger = l;
    },
    7614: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.adLocationSelectionDiagnostics = e.AdLocationSelectionDiagnostics =
          void 0);
      class i {
        constructor() {
          this.adFoundIndicator = 0;
        }
        recordAdFoundIndicator(t) {
          this.adFoundIndicator |= t;
        }
        recordSelectedElement(t) {
          this.selectedElementType = null == t ? void 0 : t.tagName;
        }
        recordAdLocatingMode(t) {
          this.adLocatingModeId = t;
        }
      }
      (e.AdLocationSelectionDiagnostics = i),
        (e.adLocationSelectionDiagnostics = new i());
    },
    5587: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdSelector = e.SELECTION_TIMEOUT = void 0);
      const n = i(8844),
        s = i(7102),
        r = i(1805),
        o = i(3692),
        a = i(8969),
        d = i(7614),
        c = i(5007);
      e.SELECTION_TIMEOUT = 2100;
      class l extends c.BaseAdBL {
        constructor(t) {
          super(),
            (this.Dt = t),
            (this.adCandidatesPerLocator = {}),
            (this.wasImpressionServed = !1),
            (this.adSelected = !1),
            (this.timeoutOccurred = !1),
            (this.dataUnloaded = !1),
            (this.didSendNotMeasuredMessage = !1),
            (this.adSelectionTimeoutId = null);
        }
        init() {}
        getActionName() {
          return "AdSelector";
        }
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [s.DvEvents.adCandidateLocated]:
              this.onAdCandidateLocated.bind(this),
            [s.DvEvents.impressionServed]: this.onImpressionServed.bind(this),
            [s.DvEvents.unloadData]: this.onUnloadData.bind(this),
          };
        }
        onAdCandidateLocated(t) {
          var e, i, n;
          const r = t.adCandidate;
          null != r &&
            (d.adLocationSelectionDiagnostics.recordAdFoundIndicator(r.N),
            (null !== (e = (i = this.adCandidatesPerLocator)[(n = r.N)]) &&
              void 0 !== e) ||
              (i[n] = []),
            this.adCandidatesPerLocator[r.N].push(t),
            s.k.dispatchEvent(
              s.DvEvents.adCandidateApproved,
              new a.AdCandidateEventData(r)
            ),
            this.tryToSelectAd());
        }
        onImpressionServed() {
          this.wasImpressionServed = !0;
          const t =
            n.A.isVideoOrAudio() || 3 === n.T.getDetectedDeliveryType()
              ? 0
              : e.SELECTION_TIMEOUT;
          (this.adSelectionTimeoutId = (0, o.setSafeTimeout)(
            this.onAdSelectionTimeout.bind(this),
            t
          )),
            this.tryToSelectAd();
        }
        onAdSelectionTimeout() {
          (this.timeoutOccurred = !0), this.tryToSelectAd();
        }
        onUnloadData(t) {
          if (((this.dataUnloaded = !0), !this.wasImpressionServed)) return;
          const e = t.relevantData;
          this.tryToSelectAd(),
            this.adSelected ||
              this.didSendNotMeasuredMessage ||
              ((this.didSendNotMeasuredMessage = !0),
              r.L.sendMessage({ isnmms: e.updateTime }));
        }
        tryToSelectMainAdCandidate(t) {
          if (null === t) return null;
          const e = this.adCandidatesPerLocator[t];
          if (null == e || 0 === e.length) return null;
          const i = e.find((t) =>
            t.adCandidate.supportedDeliveryType.includes(
              n.T.getDetectedDeliveryType()
            )
          );
          return null != i ? i : null;
        }
        tryToSelectFallbackByDeliveryType(t) {
          const e = n.T.getDetectedDeliveryType();
          for (const i of t) {
            const t = this.adCandidatesPerLocator[i];
            if (null == t || 0 === t.length) continue;
            const n = t.find((t) =>
              t.adCandidate.supportedDeliveryType.includes(e)
            );
            if (null != n) return { bit: i, candidate: n };
          }
          return null;
        }
        selectFallbackCandidate(t) {
          var e;
          (null === (e = t.candidate.adCandidate) || void 0 === e
            ? void 0
            : e.domElement) &&
            d.adLocationSelectionDiagnostics.recordSelectedElement(
              t.candidate.adCandidate.domElement
            ),
            (this.adSelected = !0),
            this.reportSelectedAd(t.candidate);
        }
        tryToSelectAd() {
          var t;
          if (this.adSelected) return;
          if (!this.wasImpressionServed) return;
          const { mainBit: e, fallbackBits: i } = this.Dt(),
            n = this.tryToSelectMainAdCandidate(e);
          if (null != n)
            return (
              (null === (t = n.adCandidate) || void 0 === t
                ? void 0
                : t.domElement) &&
                d.adLocationSelectionDiagnostics.recordSelectedElement(
                  n.adCandidate.domElement
                ),
              (this.adSelected = !0),
              void this.reportSelectedAd(n)
            );
          if (this.timeoutOccurred || this.dataUnloaded) {
            const t = this.tryToSelectFallbackByDeliveryType(i);
            null != t && this.selectFallbackCandidate(t);
          }
        }
        reportSelectedAd(t) {
          (t.adCandidate.state = 2),
            s.k.dispatchEvent(s.DvEvents.adSelected, t),
            null != this.adSelectionTimeoutId &&
              ((0, o.clearSafeTimeout)(this.adSelectionTimeoutId),
              (this.adSelectionTimeoutId = null)),
            this.setDestroySelectedAdTimeout(t),
            this.destroyAds();
        }
        setDestroySelectedAdTimeout(t) {
          (0, o.setSafeTimeout)(() => {
            s.k.dispatchEvent(s.DvEvents.adDestroy, t);
          }, 12e5);
        }
        destroyAds() {
          Object.entries(this.adCandidatesPerLocator).forEach(([t, e]) => {
            e.forEach((t) => {
              1 == t.adCandidate.state &&
                ((t.adCandidate.state = 3),
                s.k.dispatchEvent(s.DvEvents.adDestroy, t));
            });
          });
        }
      }
      e.AdSelector = l;
    },
    2681: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdSizeBL = void 0);
      const n = i(5007),
        s = i(7102),
        r = i(3283),
        o = i(8844),
        a = i(1360);
      class d extends n.BaseAdBL {
        init() {}
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [s.DvEvents.exposureData]: this.handleAdSizeData.bind(this),
            [s.DvEvents.adSelected]: this.handleSelectedAd.bind(this),
          };
        }
        handleAdSizeData(t) {
          const e = 2 == t.adCandidate.state,
            i = t.adCandidate,
            n = t.relevantData;
          if (
            (o.A.isVideoOrAudio() && !n.adIsPlaying) ||
            (i.adWidth && i.adHeight) ||
            !n.adSize
          )
            return;
          const a = i.adWidth,
            d = i.adHeight;
          if (
            ((i.adWidth = n.adSize.width ? n.adSize.width : i.adWidth),
            (i.adHeight = n.adSize.height ? n.adSize.height : i.adHeight),
            a != i.adWidth || d != i.adHeight)
          ) {
            const t = new r.AdCandidateEventData(i);
            s.k.dispatchEvent(s.DvEvents.adSizeChangedData, t),
              s.k.dispatchEvent(s.DvEvents.reportData, t),
              e && this.reportAdSizeDiagnostics(i.adWidth, i.adHeight);
          }
        }
        handleSelectedAd(t) {
          const e = null == t ? void 0 : t.adCandidate,
            i = null == e ? void 0 : e.adWidth,
            n = null == e ? void 0 : e.adHeight;
          this.reportAdSizeDiagnostics(i, n);
        }
        reportAdSizeDiagnostics(t, e) {
          a.DiagnosticParamsReporterSingleton.report(
            a.DiagnosticParams.selectedAdWidth,
            t
          ),
            a.DiagnosticParamsReporterSingleton.report(
              a.DiagnosticParams.selectedAdHeight,
              e
            );
        }
      }
      e.AdSizeBL = d;
    },
    9236: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdWrapperSizeBL = void 0);
      const n = i(5007),
        s = i(7102),
        r = i(4112),
        o = i(1906),
        a = i(8844),
        d = i(1805);
      class c extends n.BaseAdBL {
        init() {}
        isSupported() {
          return !(1 & a.O.getScenarioType() || 4 & a.O.getScenarioType());
        }
        getEventsAndCallbacksToRegister() {
          return {
            [s.DvEvents.exposureData]: this.handleWrapperAdSizeData.bind(this),
          };
        }
        handleWrapperAdSizeData(t) {
          var e, i;
          try {
            const n = t.relevantData,
              r =
                null === (e = null == t ? void 0 : t.adCandidate) ||
                void 0 === e
                  ? void 0
                  : e.adWrapperHeight,
              a =
                null === (i = null == t ? void 0 : t.adCandidate) ||
                void 0 === i
                  ? void 0
                  : i.adWrapperWidth,
              { wrapperSize: { height: d, width: c } = {} } = n;
            if (
              !o.Utilities.isNullOrEmpty(d) &&
              !o.Utilities.isNullOrEmpty(c)
            ) {
              const e = Math.round(d),
                i = Math.round(c);
              (t.adCandidate.adWrapperHeight = e),
                (t.adCandidate.adWrapperWidth = i),
                (e === r && i === a) ||
                  s.k.dispatchEvent(s.DvEvents.reportData, t);
            }
          } catch (t) {
            d.L.sendError(
              r.ClientErrorType.MeasurementError,
              t,
              "couldn't extract wrapper Size"
            );
          }
        }
      }
      e.AdWrapperSizeBL = c;
    },
    5007: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BaseAdBL = void 0);
      const n = i(7102);
      e.BaseAdBL = class {
        constructor() {
          this.isSupported() &&
            (this.init(),
            n.k.addEventsListener(
              this.getEventsAndCallbacksToRegister(),
              this.getActionName()
            ));
        }
        getActionName() {
          return "BaseAdBL";
        }
      };
    },
    1794: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BaseAdDataLoggerBL = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(3283),
        o = i(1906);
      e.BaseAdDataLoggerBL = class {
        constructor() {
          this.isSupported() &&
            o.Utilities.isPercentageCriteriaPassed(
              this.getTrafficPercentage()
            ) &&
            this.init();
        }
        init() {
          n.k.addEventListener(n.DvEvents.impressionServed, () => {
            this.isSupportedDetectedDeliveryType() &&
              n.k.addEventsListener(
                this.getEventsAndCallbacksToRegister(),
                this.getActionName()
              );
          });
        }
        report(t) {
          n.k.dispatchEvent(
            n.DvEvents.reportData,
            new r.AdCandidateEventData(t)
          );
        }
        isSupportedDetectedDeliveryType() {
          return this.getSupportedDetectedDeliveryType().some(
            (t) => t == s.T.getDetectedDeliveryType()
          );
        }
      };
    },
    6284: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.CdnDomainBL = void 0);
      const n = i(8844),
        s = i(7102),
        r = i(1360),
        o = i(5007);
      class a extends o.BaseAdBL {
        constructor() {
          super(...arguments),
            (this.DOT_COM_URL_PREFIX = "https://cdn.doubleverify.com"),
            (this.DOT_TECH_URL_PREFIX = "https://cdn.dv.tech");
        }
        isSupported() {
          return !n.O.isDomlessEnvironment() && !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [s.DvEvents.impressionServed]: this.reportCdnDomain.bind(this),
          };
        }
        reportCdnDomain() {
          const t = this.getCdnDomain();
          r.DiagnosticParamsReporterSingleton.reportOnce(
            r.DiagnosticParams.cdnDomain,
            t
          );
        }
        getCdnDomain() {
          const t = this.getScriptTagUrl();
          return (null == t ? void 0 : t.length)
            ? t.startsWith(this.DOT_COM_URL_PREFIX)
              ? 1
              : t.startsWith(this.DOT_TECH_URL_PREFIX)
              ? 2
              : 0
            : 0;
        }
        getScriptTagUrl() {
          var t, e;
          switch (n.A.getParamUrlExtractionMethod()) {
            case 0:
            case 4:
              return "";
            case 1:
              return null !==
                (e =
                  null ===
                    (t =
                      null === n.T || void 0 === n.T
                        ? void 0
                        : n.T.getTagScriptElem()) || void 0 === t
                    ? void 0
                    : t.src) && void 0 !== e
                ? e
                : "";
            default:
              return n.A.getDVScriptUrl();
          }
        }
        init() {}
        getActionName() {
          return "CdnDomainBL";
        }
      }
      e.CdnDomainBL = a;
    },
    48: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.CreativeVsContainerBL = void 0);
      const n = i(7102),
        s = i(5007),
        r = i(3283),
        o = i(4330),
        a = i(7346),
        d = i(1360),
        c = i(1906);
      class l extends s.BaseAdBL {
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.adSelected]: this.processMeasuredElementData.bind(this),
          };
        }
        processMeasuredElementData(t) {
          const e = t.adCandidate,
            i = this.extractMeasuredElementType(e);
          c.Utilities.isNullOrEmpty(i) ||
            this.sendUpdatedMeasuredElementData(i);
        }
        extractMeasuredElementType(t) {
          const e = [
            o.OmidMeasuredElementExtractor,
            a.DefaultMeasuredElementExtractor,
          ];
          for (const i of e) {
            const e = new i(t);
            if (e.isSupported())
              return (
                (t.measuredElementExtractorId =
                  e.getMeasuredElementExtractorId()),
                (t.measuredElementType = e.extract()),
                t
              );
          }
          return null;
        }
        sendUpdatedMeasuredElementData(t) {
          d.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
            d.DiagnosticParams.cvcMethodId,
            t.measuredElementExtractorId
          ),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new r.AdCandidateEventData(t)
            );
        }
        init() {}
      }
      e.CreativeVsContainerBL = l;
    },
    540: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.DataTransparencyBL = void 0);
      const n = i(659),
        s = i(8844),
        r = i(7102),
        o = i(1805),
        a = i(5007),
        d = ["sadv", "ord", "litm", "scrt", "invs", "splc", "adu", "spos"];
      class c extends a.BaseAdBL {
        constructor() {
          super(...arguments), (this.timesMessageSent = 0);
        }
        getActionName() {
          return "DataTransparency";
        }
        init() {
          (0, n.initialize)(s.O.workingWindow());
        }
        isSupported() {
          return !s.O.isDomlessEnvironment() && s.O.isPostMessageSupported();
        }
        getEventsAndCallbacksToRegister() {
          return { [r.DvEvents.impressionServed]: this.subscribe.bind(this) };
        }
        getSellerDimensionsFromTag() {
          const t = s.A.getLowerCaseParams(),
            e = {};
          for (const i of d) null != t[i] && (e[i] = t[i]);
          return e;
        }
        getSellerDimensionsFromState(t) {
          return s.A.isSellerTag() || null == t.sellerDimensions
            ? {}
            : t.sellerDimensions;
        }
        onSharedStateUpdated(t) {
          if (this.timesMessageSent >= 5) return;
          this.timesMessageSent++;
          const e = (0, n.coverageToBitFlag)(t.coverage);
          if (
            t.coverage.buyerMonitoringTag &&
            (t.coverage.sellerMonitoringTag || t.coverage.sellerPageTag)
          ) {
            const i = t.linking.sharedId,
              n = this.getSellerDimensionsFromState(t);
            o.L.sendMessage(Object.assign({ mascid: i, dvp_dtcov: e }, n));
          } else o.L.sendMessage({ dvp_dtcov: e });
        }
        subscribe() {
          const t = s.T.getImpressionId(s.O.currentWindow()),
            e = s.A.isSellerTag(),
            i = { impressionId: t, isSellerTag: e };
          e && (i.sellerDimensions = this.getSellerDimensionsFromTag()),
            (0, n.subscribe)(
              s.O.workingWindow(),
              this.onSharedStateUpdated.bind(this),
              i
            );
        }
      }
      e.DataTransparencyBL = c;
    },
    3555: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.DisplayGenXLogger = void 0);
      const n = i(5007),
        s = i(8844),
        r = i(7102),
        o = i(1805);
      class a extends n.BaseAdBL {
        constructor(t) {
          super(), (this.adContainerInspector = t.createAdContainerInspector());
        }
        getEventsAndCallbacksToRegister() {
          return {
            [r.DvEvents.impressionServed]:
              this.reportAdContainerData.bind(this),
          };
        }
        reportAdContainerData() {
          var t, e, i, n, s, r;
          const a = {};
          (a.dvp_ime =
            null === (t = this.adContainerInspector) || void 0 === t
              ? void 0
              : t.getDescendants(["img"]).length),
            (a.dvp_dcime =
              null === (e = this.adContainerInspector) || void 0 === e
                ? void 0
                : e.getDirectChildren(["img"]).length),
            (a.dvp_dcife =
              null === (i = this.adContainerInspector) || void 0 === i
                ? void 0
                : i.getDirectChildren(["iframe"]).length),
            (a.dvp_dcde =
              null === (n = this.adContainerInspector) || void 0 === n
                ? void 0
                : n.getDirectChildren(["div"]).length),
            (a.dvp_dcoe =
              null === (s = this.adContainerInspector) || void 0 === s
                ? void 0
                : s.getDirectChildren([], ["img", "iframe", "div"]).length);
          const d =
            null === (r = this.adContainerInspector) || void 0 === r
              ? void 0
              : r.getMostPopularDirectChildElement(["img", "iframe", "div"]);
          d && (a.dvp_mpdce = d), o.L.sendMessage(a);
        }
        init() {}
        isSupported() {
          return s.A.isDisplayGenXEnabled() && 0 == s.A.getTagType();
        }
      }
      e.DisplayGenXLogger = a;
    },
    8649: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdLocatedBL = void 0);
      const n = i(7102),
        s = i(5007),
        r = i(3283);
      class o extends s.BaseAdBL {
        init() {}
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.adCandidateApproved]: this.handleEvent.bind(this),
          };
        }
        handleEvent(t) {
          const e = t.adCandidate;
          (e.timeMsUntilAdLocated = t.updateTime),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new r.AdCandidateEventData(e)
            );
        }
      }
      e.AdLocatedBL = o;
    },
    2448: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BaseInteractionBL = void 0);
      const n = i(7102),
        s = i(3283),
        r = i(5007);
      class o extends r.BaseAdBL {
        isSupported() {
          return !0;
        }
        init() {}
        getEventsAndCallbacksToRegister() {
          return {
            [this.getInteractionEventName()]: this.handleEvent.bind(this),
          };
        }
        handleEvent(t) {
          if (this.allowReport(t.adCandidate)) {
            1 == this.update(t.adCandidate, t.relevantData) &&
              n.k.dispatchEvent(
                n.DvEvents.reportData,
                new s.AdCandidateEventData(t.adCandidate)
              );
          }
        }
        allowReport(t) {
          return !t.wasAdStopped;
        }
      }
      e.BaseInteractionBL = o;
    },
    4683: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.EngagementReportRtsBL = void 0);
      const n = i(5007),
        s = i(7102),
        r = i(3283);
      class o extends n.BaseAdBL {
        init() {}
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [s.DvEvents.orientationchangeLandscapeData]:
              this.TrySendEngagementInteraction.bind(this),
            [s.DvEvents.orientationChangePortraitData]:
              this.TrySendEngagementInteraction.bind(this),
            [s.DvEvents.mouseMoveData]:
              this.TrySendEngagementInteraction.bind(this),
            [s.DvEvents.keyPressData]:
              this.TrySendEngagementInteraction.bind(this),
            [s.DvEvents.firstTouchData]:
              this.TrySendEngagementInteraction.bind(this),
            [s.DvEvents.firstHoverData]:
              this.TrySendEngagementInteraction.bind(this),
            [s.DvEvents.focusData]:
              this.TrySendEngagementInteraction.bind(this),
            [s.DvEvents.firstClickOnAdElementData]:
              this.TrySendEngagementInteraction.bind(this),
            [s.DvEvents.firstFocusIntoAdElementData]:
              this.TrySendEngagementInteraction.bind(this),
            [s.DvEvents.omidClickData]:
              this.TrySendEngagementInteraction.bind(this),
            [s.DvEvents.abandonData]:
              this.TrySendEngagementInteraction.bind(this),
            [s.DvEvents.skipData]: this.TrySendEngagementInteraction.bind(this),
            [s.DvEvents.pauseData]:
              this.TrySendEngagementInteraction.bind(this),
            [s.DvEvents.adSizeData]:
              this.TrySendEngagementInteraction.bind(this),
            [s.DvEvents.resumeData]:
              this.TrySendEngagementInteraction.bind(this),
            [s.DvEvents.volumeData]:
              this.TrySendEngagementInteraction.bind(this),
            [s.DvEvents.unloadData]: this.TrySendEngagementUnload.bind(this),
          };
        }
        TrySendEngagementInteraction(t) {
          const e = t.adCandidate,
            i = this.adEngagementReported(e),
            n = this.pageEngagementReported(e);
          (i == e.adEngagement && n == e.pageEngagement) ||
            ((e.adEngagement = i),
            (e.pageEngagement = n),
            s.k.dispatchEvent(
              s.DvEvents.reportData,
              new r.AdCandidateEventData(e)
            ));
        }
        TrySendEngagementUnload(t) {
          this.TrySendEngagementInteraction(t);
          const e = t.adCandidate;
          e.adEngagement ||
            e.pageEngagement ||
            ((e.noEngagement = !0),
            s.k.dispatchEvent(
              s.DvEvents.reportData,
              new r.AdCandidateEventData(e)
            ));
        }
        adEngagementReported(t) {
          if (
            t.timeMsUntilAbandon ||
            t.timeMsUntilSkip ||
            t.timeMsUntilPause ||
            t.timeMsUntilClick ||
            t.timeMsUntilAdSizeIncrease ||
            t.timeMsUntilResume ||
            t.timeMsUntilTouch ||
            t.timeMsUntilHover ||
            t.timeMsUntilAdSizeDecrease ||
            t.timeMsUntilVolumeIncrease ||
            t.timeMsUntilVolumeDecrease ||
            t.timeMsUntilVolumeUnMute ||
            t.lastTimeMsVolumeMute
          )
            return !0;
        }
        pageEngagementReported(t) {
          if (
            t.timeMsUntilFocusOut ||
            t.timeMsUntilFocusIn ||
            t.timeMsUntilMouseMove ||
            t.timeMsUntilKeyPress ||
            t.timeMsUntilScroll ||
            t.timeMsUntilOrientationChangeToLandscape ||
            t.timeMsUntilOrientationChangeToPortrait
          )
            return !0;
        }
      }
      e.EngagementReportRtsBL = o;
    },
    7373: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.InteractionAdSizeBL = void 0);
      const n = i(7102),
        s = i(2448),
        r = i(3283),
        o = i(1360);
      class a extends s.BaseInteractionBL {
        getInteractionEventName() {
          return n.DvEvents.adSizeData;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.adSizeMeasured]: (t) => {
              this.handleAdSizeMeasured(t.adCandidate);
            },
            [n.DvEvents.adSizeData]: (t) => {
              this.handleAdSizeEvent(t, 1);
            },
            [n.DvEvents.omidAdSizeData]: (t) => {
              this.handleAdSizeEvent(t, 2);
            },
          };
        }
        handleAdSizeEvent(t, e) {
          o.DiagnosticParamsReporterSingleton.reportOnce(
            o.DiagnosticParams.adSizeMeasurementMethod,
            e
          ),
            (t.adCandidate.adSizeMeasurementMethod = e),
            super.handleEvent(t);
        }
        handleAdSizeMeasured(t) {
          void 0 === t.isAdSizeChangeMeasured &&
            ((t.isAdSizeChangeMeasured = 1),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new r.AdCandidateEventData(t)
            ));
        }
        update(t, e) {
          return this.updateAdSize(t, e);
        }
        updateAdSize(t, e) {
          if (t.isPaused) return 2;
          const i = this.getAdSizeState(t.lastAdSize, e.adSize);
          let n = 2;
          return (
            2 !== i ||
              t.timeMsUntilAdSizeIncrease ||
              ((t.timeMsUntilAdSizeIncrease = e.updateTime), (n = 1)),
            1 !== i ||
              t.timeMsUntilAdSizeDecrease ||
              ((t.timeMsUntilAdSizeDecrease = e.updateTime), (n = 1)),
            3 === i ||
              t.timeMsUntilAdSizeChange ||
              ((t.timeMsUntilAdSizeChange = e.updateTime), (n = 1)),
            (t.lastAdSize = e.adSize),
            n
          );
        }
        getAdSizeState(t, e) {
          const i = this.getSurface(t),
            n = this.getSurface(e);
          return i && n && i != n ? (n > i ? 2 : 1) : 3;
        }
        getSurface(t) {
          return (null == t ? void 0 : t.width) &&
            (null == t ? void 0 : t.height)
            ? t.width * t.height
            : 0;
        }
      }
      e.InteractionAdSizeBL = a;
    },
    2967: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.InteractionClickBL = void 0);
      const n = i(7102),
        s = i(2448),
        r = i(9198),
        o = i(3283),
        a = i(8844),
        d = i(1360);
      class c extends s.BaseInteractionBL {
        init() {
          this.isFocusIntoAdElementLogicApplicable() &&
            r.ScriptDynamicFlags.getInstance().turnOn(67108864);
        }
        getInteractionEventName() {
          return n.DvEvents.firstClickOnAdElementData;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.firstClickOnAdElementData]: (t) => {
              this.handleClickEvent(t, 1);
            },
            [n.DvEvents.omidClickData]: (t) => {
              this.handleClickEvent(t, 2);
            },
            [n.DvEvents.firstFocusIntoAdElementData]: (t) => {
              this.handleFocusIntoAdElementEvent(t, 4);
            },
            [n.DvEvents.clickMeasured]: (t) => {
              this.handleClickMeasured(t.adCandidate);
            },
            [n.DvEvents.firstClickOnDescendantIframe]: (t) => {
              this.handleClickEvent(t, 8);
            },
            [n.DvEvents.firstClickOnDeepDescendantIframe]: (t) => {
              this.handleClickEvent(t, 16);
            },
            [n.DvEvents.omidInvitationAcceptData]: (t) => {
              this.handleOmidInvitationAccept();
            },
            [n.DvEvents.omidCustomInteractionData]: (t) => {
              this.handleOmidCustomInteraction(t);
            },
          };
        }
        handleClickEvent(t, e) {
          if (
            ((t.adCandidate.clickMeasurementMethod |= e),
            super.allowReport(t.adCandidate))
          ) {
            const i = t.adCandidate,
              n = t.relevantData;
            16 == e
              ? this.updateClickDeepDescendantIframe(i, n)
              : this.update(i, n);
          }
          n.k.dispatchEvent(
            n.DvEvents.reportData,
            new o.AdCandidateEventData(t.adCandidate)
          );
        }
        handleFocusIntoAdElementEvent(t, e) {
          this.isFocusIntoAdElementLogicApplicable() &&
            this.handleClickEvent(t, e);
        }
        reportClickIsMeasured(t) {
          void 0 === t.isClickMeasured &&
            ((t.isClickMeasured = 1),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            ));
        }
        handleClickMeasured(t) {
          const e = t;
          e.wasAdStopped ||
            (e.isPaused
              ? n.k.addEventListener(n.DvEvents.resumeData, () => {
                  this.reportClickIsMeasured(t);
                })
              : this.reportClickIsMeasured(t));
        }
        isFocusIntoAdElementLogicApplicable() {
          return 0 == a.A.getTagType();
        }
        update(t, e) {
          let i = 2;
          return (
            t.isPaused ||
              t.timeMsUntilClick ||
              ((t.timeMsUntilClick = e.updateTime), (i = 1)),
            i
          );
        }
        updateClickDeepDescendantIframe(t, e) {
          t.isPaused ||
            t.timeMsUntilClickDeepDescendantIframe ||
            (t.timeMsUntilClickDeepDescendantIframe = e.updateTime);
        }
        handleOmidInvitationAccept() {
          d.DiagnosticParamsReporterSingleton.reportOnce(
            d.DiagnosticParams.omidInteractionInvitationAccept,
            1
          );
        }
        handleOmidCustomInteraction(t) {
          var e;
          const i =
              null === (e = null == t ? void 0 : t.relevantData) || void 0 === e
                ? void 0
                : e.customInteraction,
            n = t.adCandidate.customInteractions;
          i &&
            !n.includes(i) &&
            (n.push(i),
            d.DiagnosticParamsReporterSingleton.report(
              d.DiagnosticParams.omidCustomInteractions,
              n.join(",")
            ));
        }
      }
      e.InteractionClickBL = c;
    },
    2783: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.InteractionFocusBL = void 0);
      const n = i(7102),
        s = i(2448);
      class r extends s.BaseInteractionBL {
        getInteractionEventName() {
          return n.DvEvents.focusData;
        }
        update(t, e) {
          let i = 2;
          const { updateTime: n } = e;
          if (t.isPaused) return i;
          switch (this.getFocusState(t.lastFocus, e.focus)) {
            case 3:
              break;
            case 1:
              if (t.timeMsUntilFocusIn) break;
              (t.timeMsUntilFocusIn = n), (i = 1);
              break;
            case 2:
              if (t.timeMsUntilFocusOut) break;
              (t.timeMsUntilFocusOut = n), (i = 1);
          }
          return (t.lastFocus = e.focus), i;
        }
        getFocusState(t, e) {
          let i;
          return (
            null == t || null == e || t == e
              ? (i = 3)
              : 0 == t && 1 == e
              ? (i = 1)
              : 1 == t && 0 == e && (i = 2),
            i
          );
        }
      }
      e.InteractionFocusBL = r;
    },
    1016: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.InteractionHoverBL = void 0);
      const n = i(7102),
        s = i(2448);
      class r extends s.BaseInteractionBL {
        getInteractionEventName() {
          return n.DvEvents.firstHoverData;
        }
        update(t, e) {
          let i = 2;
          return (
            t.isPaused ||
              t.timeMsUntilHover ||
              ((t.timeMsUntilHover = e.updateTime), (i = 1)),
            i
          );
        }
      }
      e.InteractionHoverBL = r;
    },
    4748: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.InteractionTouchBL = void 0);
      const n = i(7102),
        s = i(2448),
        r = i(3283);
      class o extends s.BaseInteractionBL {
        getInteractionEventName() {
          return n.DvEvents.firstTouchData;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.firstTouchData]: (t) => {
              this.handleEvent(t);
            },
            [n.DvEvents.firstTouchOnDescendantIframe]: (t) => {
              this.handleEvent(t);
            },
            [n.DvEvents.firstTouchOnDeepDescendantIframe]: (t) => {
              this.handleTouchOnDeepDescendantIframe(t);
            },
          };
        }
        update(t, e) {
          let i = 2;
          return (
            t.isPaused ||
              t.timeMsUntilTouch ||
              ((t.timeMsUntilTouch = e.updateTime), (i = 1)),
            i
          );
        }
        handleTouchOnDeepDescendantIframe(t) {
          const { adCandidate: e, relevantData: i } = t;
          !super.allowReport(e) ||
            e.isPaused ||
            e.timeMsUntilTouchDeepDescendantIframe ||
            ((e.timeMsUntilTouchDeepDescendantIframe = i.updateTime),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new r.AdCandidateEventData(e)
            ));
        }
      }
      e.InteractionTouchBL = o;
    },
    9862: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PageInteractionKeyPressBL = void 0);
      const n = i(2448),
        s = i(7102);
      class r extends n.BaseInteractionBL {
        getInteractionEventName() {
          return s.DvEvents.keyPressData;
        }
        update(t, e) {
          let i = 2;
          return (
            t.timeMsUntilKeyPress ||
              ((t.timeMsUntilKeyPress = e.updateTime), (i = 1)),
            i
          );
        }
      }
      e.PageInteractionKeyPressBL = r;
    },
    4661: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PageInteractionMouseMoveBL = void 0);
      const n = i(2448),
        s = i(7102);
      class r extends n.BaseInteractionBL {
        getInteractionEventName() {
          return s.DvEvents.mouseMoveData;
        }
        update(t, e) {
          let i = 2;
          return (
            t.timeMsUntilMouseMove ||
              ((t.timeMsUntilMouseMove = e.updateTime), (i = 1)),
            i
          );
        }
      }
      e.PageInteractionMouseMoveBL = r;
    },
    567: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PageInteractionOrientationChangeLandscapeBL = void 0);
      const n = i(2448),
        s = i(7102);
      class r extends n.BaseInteractionBL {
        getInteractionEventName() {
          return s.DvEvents.orientationchangeLandscapeData;
        }
        update(t, e) {
          let i = 2;
          return (
            t.timeMsUntilOrientationChangeToLandscape ||
              ((t.timeMsUntilOrientationChangeToLandscape = e.updateTime),
              (i = 1)),
            i
          );
        }
      }
      e.PageInteractionOrientationChangeLandscapeBL = r;
    },
    1041: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PageInteractionOrientationChangePortraitBL = void 0);
      const n = i(2448),
        s = i(7102);
      class r extends n.BaseInteractionBL {
        getInteractionEventName() {
          return s.DvEvents.orientationChangePortraitData;
        }
        update(t, e) {
          let i = 2;
          return (
            t.timeMsUntilOrientationChangeToPortrait ||
              ((t.timeMsUntilOrientationChangeToPortrait = e.updateTime),
              (i = 1)),
            i
          );
        }
      }
      e.PageInteractionOrientationChangePortraitBL = r;
    },
    3965: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PageInteractionScrollBL = void 0);
      const n = i(2448),
        s = i(7102),
        r = i(3283);
      class o extends n.BaseInteractionBL {
        getInteractionEventName() {
          return "";
        }
        getEventsAndCallbacksToRegister() {
          return {
            [s.DvEvents.viewabilityIntervalData]:
              this.handleViewabilityIntervalDataEvent.bind(this),
          };
        }
        handleViewabilityIntervalDataEvent(t) {
          const e = t.relevantData;
          if (!e.adGeometric) return;
          this.reportScrollIsMeasured(t.adCandidate);
          const i = this.adGeometric;
          (this.adGeometric = e.adGeometric),
            i &&
              this.isPositionChanged(i, this.adGeometric) &&
              this.handleScrollEvent(t),
            this.scrollInteractionVerificationV2(e.adGeometric, t);
        }
        scrollInteractionVerificationV2(t, e) {
          const i = e.adCandidate.position,
            n = { width: t.width, height: t.height },
            s = e.adCandidate.mutableAdSize;
          (e.adCandidate.position = t),
            i &&
              this.isPositionChanged(i, t) &&
              (this.reportScrollIsInteractedV2(e),
              this.reportScrollIsInteractedWithAdSizeLimit(e, s, n)),
            (e.adCandidate.mutableAdSize = n);
        }
        isPositionChanged(t, e) {
          return t.y != e.y || t.x != e.x;
        }
        reportScrollIsMeasured(t) {
          void 0 === t.isScrollMeasured &&
            ((t.isScrollMeasured = 1),
            s.k.dispatchEvent(
              s.DvEvents.reportData,
              new r.AdCandidateEventData(t)
            ));
        }
        handleScrollEvent(t) {
          if (this.allowReport(t.adCandidate)) {
            1 == this.update(t.adCandidate, t.relevantData) &&
              s.k.dispatchEvent(
                s.DvEvents.reportData,
                new r.AdCandidateEventData(t.adCandidate)
              );
          }
        }
        update(t, e) {
          let i = 2;
          return (
            t.timeMsUntilScroll ||
              ((t.timeMsUntilScroll = e.updateTime), (i = 1)),
            i
          );
        }
        reportScrollIsInteractedV2(t) {
          this.allowReport(t.adCandidate) &&
            (t.adCandidate.timeMsUntilScrollV2 ||
              ((t.adCandidate.timeMsUntilScrollV2 = t.updateTime),
              s.k.dispatchEvent(
                s.DvEvents.reportData,
                new r.AdCandidateEventData(t.adCandidate)
              )));
        }
        reportScrollIsInteractedWithAdSizeLimit(t, e, i) {
          this.allowReport(t.adCandidate) &&
            (!e ||
              this.isAdSizeChanged(e, i) ||
              t.adCandidate.timeMsUntilScrollV3 ||
              ((t.adCandidate.timeMsUntilScrollV3 = t.updateTime),
              s.k.dispatchEvent(
                s.DvEvents.reportData,
                new r.AdCandidateEventData(t.adCandidate)
              )));
        }
        isAdSizeChanged(t, e) {
          return t.width !== e.width || t.height !== e.height;
        }
      }
      e.PageInteractionScrollBL = o;
    },
    4080: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.UserPresenceBL = void 0);
      const n = i(5007),
        s = i(7102),
        r = i(1805),
        o = i(4126),
        a = i(1360);
      class d extends n.BaseAdBL {
        init() {
          this.reportedMeasuredInteractions = [];
        }
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [s.DvEvents.keyPressMeasured]: this.reportIsMeasured.bind(
              this,
              o.AdDataMappingToReport.isKeyPressMeasured
            ),
            [s.DvEvents.mouseMoveMeasured]: this.reportIsMeasured.bind(
              this,
              o.AdDataMappingToReport.isMouseMoveMeasured
            ),
            [s.DvEvents.orientationChangeMeasured]: this.reportIsMeasured.bind(
              this,
              o.AdDataMappingToReport.isOrientationChangeMeasured
            ),
            [s.DvEvents.tempFirstKeyPressData]:
              this.reportInteractionDiagnostic.bind(
                this,
                a.DiagnosticParams.isKeyPressed
              ),
            [s.DvEvents.tempFirstMouseMoveData]:
              this.reportInteractionDiagnostic.bind(
                this,
                a.DiagnosticParams.isMouseMoved
              ),
            [s.DvEvents.tempOrientationChangePortraitData]:
              this.reportInteractionDiagnostic.bind(
                this,
                a.DiagnosticParams.isOrientationChangedToPortrait
              ),
            [s.DvEvents.tempOrientationChangeLandscapeData]:
              this.reportInteractionDiagnostic.bind(
                this,
                a.DiagnosticParams.isOrientationChangedToLandscape
              ),
          };
        }
        reportIsMeasured(t) {
          this.reportedMeasuredInteractions.includes(t) ||
            (r.L.sendMessage({ [t]: 1 }),
            this.reportedMeasuredInteractions.push(t));
        }
        reportInteractionDiagnostic(t) {
          a.DiagnosticParamsReporterSingleton.reportOnce(t, 1);
        }
      }
      e.UserPresenceBL = d;
    },
    2917: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.InteractionAbandonBL = void 0);
      const n = i(7102),
        s = i(2448),
        r = i(8844);
      class o extends s.BaseInteractionBL {
        init() {}
        getInteractionEventName() {
          return n.DvEvents.abandonData;
        }
        update(t, e) {
          let i = 2;
          return (
            !r.A.isVideoOrAudio() ||
              t.timeMsUntilSkip ||
              t.timeMsUntilAbandon ||
              ((t.timeMsUntilAbandon = e.updateTime), (i = 1)),
            i
          );
        }
      }
      e.InteractionAbandonBL = o;
    },
    2839: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.InteractionPauseBL = void 0);
      const n = i(7102),
        s = i(2448);
      class r extends s.BaseInteractionBL {
        getInteractionEventName() {
          return n.DvEvents.pauseData;
        }
        update(t, e) {
          let i = 2;
          return (
            t.isPaused ||
              (t.timeMsUntilPause ||
                ((t.timeMsUntilPause = e.updateTime), (i = 1)),
              (t.isPaused = !0)),
            i
          );
        }
      }
      e.InteractionPauseBL = r;
    },
    750: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.InteractionResumeBL = void 0);
      const n = i(7102),
        s = i(2448);
      class r extends s.BaseInteractionBL {
        getInteractionEventName() {
          return n.DvEvents.resumeData;
        }
        update(t, e) {
          let i = 2;
          return (
            t.timeMsUntilResume ||
              1 != t.isPaused ||
              ((t.isPaused = !1),
              (t.timeMsUntilResume = e.updateTime),
              (i = 1)),
            i
          );
        }
      }
      e.InteractionResumeBL = r;
    },
    7759: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.InteractionSkipBL = void 0);
      const n = i(7102),
        s = i(2448);
      class r extends s.BaseInteractionBL {
        getInteractionEventName() {
          return n.DvEvents.skipData;
        }
        update(t, e) {
          let i = 2;
          return (
            t.timeMsUntilSkip ||
              ((t.timeMsUntilSkip = t.adSkippedTime = e.updateTime),
              t.adSkippableMs || (t.adSkippableMs = e.updateTime),
              (i = 1)),
            i
          );
        }
      }
      e.InteractionSkipBL = r;
    },
    3867: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.InteractionVolumeBL = void 0);
      const n = i(7102),
        s = i(2448),
        r = i(6431),
        o = i(1360);
      class a extends s.BaseInteractionBL {
        getActionName() {
          return "InteractionVolumeBL";
        }
        getInteractionEventName() {
          return n.DvEvents.volumeData;
        }
        update(t, e) {
          let i = 2;
          const { updateTime: n } = e;
          switch (this.getVolumeState(t.lastVideoVolume, e.volume)) {
            case 5:
              break;
            case 3:
              if (t.timeMsUntilVolumeMute) break;
              (t.timeMsUntilVolumeMute = n), (i = 1);
              break;
            case 1:
              if (t.timeMsUntilVolumeDecrease) break;
              (t.timeMsUntilVolumeDecrease = n), (i = 1);
              break;
            case 4:
              if (t.timeMsUntilVolumeUnMute) break;
              (t.timeMsUntilVolumeUnMute = n), (i = 1);
              break;
            case 2:
              if (t.timeMsUntilVolumeIncrease) break;
              (t.timeMsUntilVolumeIncrease = n), (i = 1);
          }
          return (
            !t.timeMsUntilVolumeChange &&
              this.isVolumeChange(t.lastVideoVolume, e.volume) &&
              ((t.timeMsUntilVolumeChange = n),
              this.reportVolumeChangeTransitionDiagnostics(
                t.lastVideoVolume,
                e.volume,
                t.lastVideoVolumeUpdateTime,
                n
              ),
              (i = 1)),
            t.lastVideoVolume !== e.volume && (t.lastVideoVolumeUpdateTime = n),
            (t.lastVideoVolume = e.volume),
            i
          );
        }
        reportVolumeChangeTransitionDiagnostics(t, e, i, n) {
          o.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
            o.DiagnosticParams.engvlchmsFromState,
            t
          ),
            o.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              o.DiagnosticParams.engvlchmsToState,
              e
            ),
            o.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              o.DiagnosticParams.engvlchmsFromStateTimeMs,
              i
            ),
            o.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              o.DiagnosticParams.engvlchmsToStateTimeMs,
              n
            );
        }
        getVolumeState(t, e) {
          return r.default.isVolumeLevelSupported(t) &&
            r.default.isVolumeLevelSupported(e) &&
            t !== e
            ? r.default.isVolumeLevelMuted(e) &&
              !r.default.isVolumeLevelMuted(t)
              ? 3
              : e < t
              ? 1
              : r.default.isVolumeLevelMuted(t) &&
                !r.default.isVolumeLevelMuted(e)
              ? 4
              : e > t
              ? 2
              : void 0
            : 5;
        }
        isVolumeChange(t, e) {
          return (
            !!r.default.isVolumeLevelSupported(e) &&
            (!!r.default.isVolumeLevelUnsupported(t) ||
              (!!r.default.isVolumeLevelSupported(t) && t !== e))
          );
        }
      }
      e.InteractionVolumeBL = a;
    },
    4e3: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.QuartileBucketsVolumeBL = void 0);
      const n = i(7102),
        s = i(3283),
        r = i(8844),
        o = i(5007);
      class a extends o.BaseAdBL {
        init() {}
        isSupported() {
          return r.A.isVideoOrAudio();
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.exposureData]: this.handleVolumeData.bind(this),
            [n.DvEvents.adVideoFirstQuartileData]: this.handleQuartileData.bind(
              this,
              1
            ),
            [n.DvEvents.adVideoMidpointData]: this.handleQuartileData.bind(
              this,
              2
            ),
            [n.DvEvents.adVideoThirdQuartileData]: this.handleQuartileData.bind(
              this,
              3
            ),
            [n.DvEvents.adVideoCompleteData]: this.handleQuartileData.bind(
              this,
              4
            ),
          };
        }
        handleVolumeData(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          if (!i.adIsPlaying) return;
          if (null == i.volume || i.volume < 0) return;
          const n = i.volume ? i.intervalDuration : 0,
            s = "q" + e.volumeDurationQuartileId + "ad";
          (e[s] = e[s] ? e[s] + n : n),
            i.volume && e.markAdQuartile(2, e.volumeDurationQuartileId);
        }
        handleQuartileData(t, e) {
          const i = e.adCandidate;
          (i.volumeDurationQuartileId = t + 1),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new s.AdCandidateEventData(i)
            );
        }
      }
      e.QuartileBucketsVolumeBL = a;
    },
    9468: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VideoCompleteBL = void 0);
      const n = i(7102),
        s = i(2448);
      class r extends s.BaseInteractionBL {
        getInteractionEventName() {
          return n.DvEvents.adVideoCompleteData;
        }
        update(t, e) {
          return (t.wasAdStopped = !0), 2;
        }
      }
      e.VideoCompleteBL = r;
    },
    3634: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VideoLengthBL = void 0);
      const n = i(7102),
        s = i(3283),
        r = i(8844),
        o = i(5007);
      class a extends o.BaseAdBL {
        init() {}
        isSupported() {
          return r.A.isVideoOrAudio();
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.adVideoFirstQuartileData]:
              this.calculateVideoLengthDueToFirstQuartile.bind(this),
            [n.DvEvents.adVideoMidpointData]:
              this.calculateVideoLengthDueToSecondQuartile.bind(this),
            [n.DvEvents.adVideoCompleteData]:
              this.calculateVideoLengthDueToAdComplete.bind(this),
          };
        }
        calculateVideoLengthDueToFirstQuartile(t) {
          const e = t.adCandidate;
          e.adVideoTimeLine &&
            5 !== e.adDurationCalculationType &&
            (this.setAdDuration(e, 4), (e.adDurationCalculationType = 2));
        }
        calculateVideoLengthDueToSecondQuartile(t) {
          const e = t.adCandidate;
          e.adVideoTimeLine && (e.videoLength = 2 * e.adVideoTimeLine),
            e.adVideoTimeLine &&
              5 !== e.adDurationCalculationType &&
              (this.setAdDuration(e, 2), (e.adDurationCalculationType = 3));
        }
        calculateVideoLengthDueToAdComplete(t) {
          const e = t.adCandidate;
          e.adVideoTimeLine &&
            5 !== e.adDurationCalculationType &&
            (this.setAdDuration(e),
            (e.adDurationCalculationType = 4),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new s.AdCandidateEventData(e)
            ));
        }
        setAdDuration(t, e = 1) {
          t.adDuration = Math.round(t.adVideoTimeLine * e);
        }
      }
      e.VideoLengthBL = a;
    },
    2422: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VideoMarkImpressionAsRenderedBL = void 0);
      const n = i(5007),
        s = i(8844),
        r = i(7102),
        o = i(3283),
        a = i(7652);
      class d extends n.BaseAdBL {
        getActionName() {
          return "VideoMarkImpressionAsRenderedBL";
        }
        init() {}
        isSupported() {
          return s.A.isVideoOrAudio();
        }
        getEventsAndCallbacksToRegister() {
          return {
            [r.DvEvents.impressionServed]: this.impressionServed.bind(this),
          };
        }
        impressionServed() {
          a.ExposureBL.getEventsAdIsPlayingTrue().forEach((t) => {
            r.k.addEventListener(t, this.videoRenderedCallback.bind(this));
          });
        }
        videoRenderedCallback(t) {
          const e = t.adCandidate;
          null == e.isVideoPreRendered &&
            ((e.isVideoPreRendered = 0),
            (e.videoStartTime = t.updateTime),
            (e.timeMsUntilVideoPlayed = t.updateTime),
            r.k.dispatchEvent(
              r.DvEvents.videoStartPlaying,
              new o.AdCandidateEventData(e)
            ),
            r.k.dispatchEvent(
              r.DvEvents.reportData,
              new o.AdCandidateEventData(e)
            ),
            r.k.dispatchEvent(
              r.DvEvents.beginToPlay,
              new o.AdCandidateEventData(e)
            ));
        }
      }
      e.VideoMarkImpressionAsRenderedBL = d;
    },
    8035: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VideoSkippableBL = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(5007);
      class o extends r.BaseAdBL {
        init() {}
        isSupported() {
          return s.A.isVideoOrAudio();
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.skippableData]: this.handleSkippableData.bind(this),
          };
        }
        handleSkippableData(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          i.adSkippable && (e.adSkippableMs = i.updateTime);
        }
      }
      e.VideoSkippableBL = o;
    },
    9471: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VideoStoppedBL = void 0);
      const n = i(7102),
        s = i(2448);
      class r extends s.BaseInteractionBL {
        getInteractionEventName() {
          return n.DvEvents.stopData;
        }
        update(t, e) {
          return (t.wasAdStopped = !0), 2;
        }
      }
      e.VideoStoppedBL = r;
    },
    3144: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VolumeBL = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(5007),
        o = i(6431);
      class a extends r.BaseAdBL {
        init() {}
        isSupported() {
          return s.A.isVideoOrAudio();
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.exposureData]: this.handleVolumeData.bind(this),
          };
        }
        handleVolumeData(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          i.adIsPlaying && this.trySetVolumeValues(e, i);
        }
        trySetVolumeValues(t, e) {
          let i = e.volume;
          o.default.isVolumeLevelSupported(i) &&
            (t.timeMsUntilVolumeMeasured ||
              (t.timeMsUntilVolumeMeasured = e.updateTime),
            (i = Math.max(Math.min(Math.ceil(100 * i), 100), 0)),
            o.default.isVolumeLevelMuted(i) &&
              null == t.lastTimeMsVolumeMute &&
              (t.lastTimeMsVolumeMute = e.updateTime),
            (t.minVideoVolume =
              null == t.minVideoVolume || t.minVideoVolume > i
                ? i
                : t.minVideoVolume),
            (t.maxVideoVolume =
              null == t.maxVideoVolume || t.maxVideoVolume < i
                ? i
                : t.maxVideoVolume));
        }
      }
      e.VolumeBL = a;
    },
    7652: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ExposureBL = void 0);
      const n = i(7102),
        s = i(3283),
        r = i(5007),
        o = i(1906),
        a = i(8844);
      class d extends r.BaseAdBL {
        static getEventsAdIsPlayingTrue() {
          return a.omidAdapter.isSupported()
            ? [n.DvEvents.adVideoStartData, n.DvEvents.resumeData]
            : [
                n.DvEvents.adImpressionData,
                n.DvEvents.adVideoStartData,
                n.DvEvents.resumeData,
              ];
        }
        static getEventsAdIsPlayingFalse() {
          return [
            n.DvEvents.pauseData,
            n.DvEvents.abandonData,
            n.DvEvents.skipData,
            n.DvEvents.unloadData,
            n.DvEvents.adVideoCompleteData,
          ];
        }
        init() {}
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.focusData]: this.collectFocusData.bind(this),
            [n.DvEvents.strictFocusData]:
              this.collectStrictFocusData.bind(this),
            [n.DvEvents.viewabilityIntervalData]:
              this.collectViewabilityData.bind(this),
            [n.DvEvents.secondaryViewabilityIntervalData]:
              this.collectExperimentViewabilityData(
                n.DvEvents.secondaryExposureData
              ).bind(this),
            [n.DvEvents.boundariesViewabilityIntervalData]:
              this.collectBoundariesViewabilityData.bind(this),
            [n.DvEvents.adImpressionData]: this.collectAdIsPlayingData.bind(
              this,
              n.DvEvents.adImpressionData
            ),
            [n.DvEvents.adVideoStartData]: this.collectAdIsPlayingData.bind(
              this,
              n.DvEvents.adVideoStartData
            ),
            [n.DvEvents.pauseData]: this.collectAdIsPlayingData.bind(
              this,
              n.DvEvents.pauseData
            ),
            [n.DvEvents.resumeData]: this.collectAdIsPlayingData.bind(
              this,
              n.DvEvents.resumeData
            ),
            [n.DvEvents.abandonData]: this.collectAdIsPlayingData.bind(
              this,
              n.DvEvents.abandonData
            ),
            [n.DvEvents.skipData]: this.collectAdIsPlayingData.bind(
              this,
              n.DvEvents.skipData
            ),
            [n.DvEvents.unloadData]: this.collectAdIsPlayingData.bind(
              this,
              n.DvEvents.unloadData
            ),
            [n.DvEvents.adVideoCompleteData]: this.collectAdIsPlayingData.bind(
              this,
              n.DvEvents.adVideoCompleteData
            ),
            [n.DvEvents.volumeData]: this.collectAdVolumeData.bind(this),
            [n.DvEvents.videoLoadedData]: this.collectAdVolumeData.bind(this),
          };
        }
        collectViewabilityData(t) {
          const e = this.getCandidateExposureData(t),
            i = this.getCandidateViewabilityData(t);
          e.lastExposureTimeEvent || (e.lastExposureTimeEvent = i.updateTime);
          const r = this.getIntervalDuration(i, e);
          e.viewabilityAdIsPlaying &&
            (e.adVideoTimeLine = e.adVideoTimeLine ? e.adVideoTimeLine + r : r),
            n.k.dispatchEvent(
              n.DvEvents.exposureData,
              new s.AdCandidateEventData(e, {
                adSize: i.adGeometric,
                viewportSize: i.viewportSize,
                wrapperSize: i.wrapperSize,
                screenSize: i.screenSize,
                percentage: o.Utilities.isNumber(i.percentage)
                  ? Math.round(i.percentage)
                  : void 0,
                offScreenPercentage: i.offScreenPercentage,
                viewabilityCalculationType: i.viewabilityCalculationType,
                focus: e.viewabilityFocus,
                strictFocus: e.viewabilityStrictFocus && e.viewabilityFocus,
                adIsPlaying: e.viewabilityAdIsPlaying,
                intervalDuration: r,
                adVideoTimeLine: e.adVideoTimeLine,
                volume: e.currentVideoVolume,
                boundariesViewability: e.boundariesViewability,
                adHasPlayed: e.adHasPlayed,
              })
            ),
            (e.lastExposureTimeEvent = i.updateTime);
        }
        getIntervalDuration(t, e) {
          return Math.max(t.updateTime - e.lastExposureTimeEvent, 100);
        }
        getCandidateExposureData(t) {
          return t.adCandidate;
        }
        getCandidateViewabilityData(t) {
          return t.relevantData;
        }
        collectExperimentViewabilityData(t) {
          return (e) => {
            const i = this.getCandidateExposureData(e),
              r = this.getCandidateViewabilityData(e),
              a = this.getIntervalDuration(r, i);
            n.k.dispatchEvent(
              t,
              new s.AdCandidateEventData(i, {
                adSize: r.adGeometric,
                viewportSize: r.viewportSize,
                wrapperSize: r.wrapperSize,
                screenSize: r.screenSize,
                percentage: o.Utilities.isNumber(r.percentage)
                  ? Math.round(r.percentage)
                  : void 0,
                offScreenPercentage: r.offScreenPercentage,
                viewabilityCalculationType: r.viewabilityCalculationType,
                focus: i.viewabilityFocus,
                strictFocus: i.viewabilityStrictFocus && i.viewabilityFocus,
                adIsPlaying: i.viewabilityAdIsPlaying,
                intervalDuration: a,
                adVideoTimeLine: i.adVideoTimeLine,
                volume: i.currentVideoVolume,
                boundariesViewability: i.boundariesViewability,
                adHasPlayed: i.adHasPlayed,
              })
            );
          };
        }
        collectBoundariesViewabilityData(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          e.boundariesViewability = i.boundariesViewability;
        }
        collectFocusData(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          e.viewabilityFocus = i.focus;
        }
        collectStrictFocusData(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          e.viewabilityStrictFocus = i.focus;
        }
        collectAdIsPlayingData(t, e) {
          const i = d.getEventsAdIsPlayingTrue(),
            n = d.getEventsAdIsPlayingFalse(),
            s = e.adCandidate;
          i.includes(t)
            ? ((s.viewabilityAdIsPlaying = !0), (s.adHasPlayed = !0))
            : n.includes(t) && (s.viewabilityAdIsPlaying = !1),
            this.collectAdVolumeData(e);
        }
        collectAdVolumeData(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          o.Utilities.isNullOrEmpty(i.volume) ||
            (e.currentVideoVolume = i.volume);
        }
      }
      e.ExposureBL = d;
    },
    688: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ExposureCompatibilityIndicator = void 0);
      const n = i(8844),
        s = i(5473),
        r = i(5007),
        o = i(7102),
        a = i(4642),
        d = i(1805);
      class c extends r.BaseAdBL {
        getActionName() {
          return "ExposureCompatibilityIndicator";
        }
        init() {}
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return { [o.DvEvents.impressionServed]: this.start.bind(this) };
        }
        start() {
          const t = n.T.getDetectedDeliveryType(),
            e = this.determineViewabilityIntegrationType(t) || 0;
          this.report({ vit: e });
        }
        report(t) {
          d.L.sendMessage(t);
        }
        determineViewabilityIntegrationType(t) {
          if (null == t || !n.A.isTagTypeValid()) return null;
          if (n.T.isMobileApp() || n.T.isCTV())
            return n.omidAdapter.isSupported()
              ? 6
              : s.MraidWrapper.isSupported()
              ? 5
              : null;
          if (n.A.isVideoOrAudio()) {
            const t = a.VpaidWrapper.getDvVpaid();
            return (null == t ? void 0 : t.viewabilityIntegrationType) || null;
          }
          return 2;
        }
      }
      e.ExposureCompatibilityIndicator = c;
    },
    5034: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.GandalfTheWhiteBL = e.GANDALF_THE_WHITE_AD_ID_DATA_ATTRIBUTE =
          void 0);
      const n = i(5007),
        s = i(7102),
        r = i(1360),
        o = i(8844);
      e.GANDALF_THE_WHITE_AD_ID_DATA_ATTRIBUTE = "data-gtwadid";
      class a extends n.BaseAdBL {
        init() {}
        isSupported() {
          return null != o.A.getParamValue("dvp_gandalf_internal_ad_id");
        }
        getEventsAndCallbacksToRegister() {
          return { [s.DvEvents.adSelected]: this.handleSelectedAd.bind(this) };
        }
        getActionName() {
          return "GandalfTheWhiteBL";
        }
        handleSelectedAd(t) {
          const i = t.adCandidate.domElement,
            n =
              null == i
                ? void 0
                : i.getAttribute(e.GANDALF_THE_WHITE_AD_ID_DATA_ATTRIBUTE);
          if (null != n)
            return void r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              r.DiagnosticParams.gandalfTheWhiteAdId,
              n
            );
          if (!i)
            return void r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              r.DiagnosticParams.gandalfTheWhiteAdId,
              "NO_DOM_ELEMENT"
            );
          const s = i.getAttribute("id");
          null == s
            ? r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
                r.DiagnosticParams.gandalfTheWhiteAdId,
                i.outerHTML.substring(0, 50)
              )
            : r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
                r.DiagnosticParams.gandalfTheWhiteAdId,
                s
              );
        }
      }
      e.GandalfTheWhiteBL = a;
    },
    1897: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AbstractMeasuredElementExtractor = void 0);
      e.AbstractMeasuredElementExtractor = class {
        constructor(t) {
          this.measuredElementData = t;
        }
      };
    },
    7346: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.DefaultMeasuredElementExtractor = void 0);
      const n = i(1897),
        s = i(8844);
      class r extends n.AbstractMeasuredElementExtractor {
        isSupported() {
          var t;
          return !!(null === (t = this.measuredElementData) || void 0 === t
            ? void 0
            : t.domElement);
        }
        extract() {
          var t;
          return 1 ===
            (0, s.extractElementType)(
              null === (t = this.measuredElementData) || void 0 === t
                ? void 0
                : t.domElement
            )
            ? 2
            : 1;
        }
        getMeasuredElementExtractorId() {
          return 1;
        }
      }
      e.DefaultMeasuredElementExtractor = r;
    },
    4330: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.OmidMeasuredElementExtractor = void 0);
      const n = i(1897),
        s = i(1906);
      class r extends n.AbstractMeasuredElementExtractor {
        isSupported() {
          var t;
          return !s.Utilities.isNullOrEmpty(
            null === (t = this.measuredElementData) || void 0 === t
              ? void 0
              : t.omidMeasuredElementType
          );
        }
        extract() {
          var t;
          return null === (t = this.measuredElementData) || void 0 === t
            ? void 0
            : t.omidMeasuredElementType;
        }
        getMeasuredElementExtractorId() {
          return 2;
        }
      }
      e.OmidMeasuredElementExtractor = r;
    },
    1204: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.MobileOrientationBL = void 0);
      const n = i(5007),
        s = i(7102),
        r = i(8844);
      class o extends n.BaseAdBL {
        getActionName() {
          return "MobileOrientationBL";
        }
        init() {}
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [s.DvEvents.impressionServed]: this.impressionServed.bind(this),
          };
        }
        impressionServed() {
          r.T.isMobile() &&
            s.k.addEventListener(
              s.DvEvents.exposureData,
              this.handleViewabilityData.bind(this)
            );
        }
        handleViewabilityData(t) {
          var e, i;
          const n = t.adCandidate,
            s = t.relevantData;
          (null === (e = s.viewportSize) || void 0 === e ? void 0 : e.height) &&
          (null === (i = s.viewportSize) || void 0 === i ? void 0 : i.width)
            ? this.setOrientationData(n, s)
            : n.initialOrientationType || (n.initialOrientationType = 0);
        }
        setOrientationData(t, e) {
          let i = 0;
          e.viewportSize.width > e.viewportSize.height
            ? ((i = 2),
              (t.accumulativeTimeOrientationLandscape =
                t.accumulativeTimeOrientationLandscape
                  ? t.accumulativeTimeOrientationLandscape + e.intervalDuration
                  : e.intervalDuration))
            : ((i = 1),
              (t.accumulativeTimeOrientationPortrait =
                t.accumulativeTimeOrientationPortrait
                  ? t.accumulativeTimeOrientationPortrait + e.intervalDuration
                  : e.intervalDuration)),
            t.initialOrientationType || (t.initialOrientationType = i);
        }
      }
      e.MobileOrientationBL = o;
    },
    7651: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.MrcImpressionBL = void 0);
      const n = i(5007),
        s = i(7102),
        r = i(3283),
        o = i(8844),
        a = i(3044),
        d = i(1360);
      class c extends n.BaseAdBL {
        init() {
          (this.beginToRender = !1),
            (this.beginToPlay = !1),
            (this.isImpressionServed = !1),
            (this.isMrcImpressionSent = !1),
            (this.adCandidateData = new a.AdCandidateData(null));
        }
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [s.DvEvents.beginToRender]: this.handleBeginToRender.bind(this),
            [s.DvEvents.beginToPlay]: this.handleBeginToPlay.bind(this),
            [s.DvEvents.impressionServed]:
              this.handleImpressionServed.bind(this),
          };
        }
        handleImpressionServed() {
          (this.isImpressionServed = !0), this.trySendMrcImpression();
        }
        handleBeginToRender() {
          (this.beginToRender = !0), this.trySendMrcImpression();
        }
        handleBeginToPlay(t) {
          (this.beginToPlay = !0), this.trySendMrcImpression(t.adCandidate);
        }
        trySendMrcImpression(t = this.adCandidateData) {
          !this.isMrcImpressionSent &&
            this.isImpressionServed &&
            this.beginToRender &&
            (0 === o.A.getTagType() || this.beginToPlay) &&
            ((t.isMrcImpression = !0),
            s.k.dispatchEvent(
              s.DvEvents.reportData,
              new r.AdCandidateEventData(t, { reportType: 2, forceRTS: !0 })
            ),
            d.DiagnosticParamsReporterSingleton.report(
              d.DiagnosticParams.isMrcImpression,
              1
            ),
            (this.isMrcImpressionSent = !0));
        }
      }
      e.MrcImpressionBL = c;
    },
    8650: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.NormalizedAdSizeBL = void 0);
      const n = i(5007),
        s = i(7102),
        r = i(3283),
        o = i(8844),
        a = i(5466);
      class d extends n.BaseAdBL {
        init() {}
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [s.DvEvents.adSizeChangedData]:
              this.handleAdSizeChangedData.bind(this),
          };
        }
        handleAdSizeChangedData(t) {
          const e = t.adCandidate;
          if (!e.adWidth || !e.adHeight) return;
          const i = { width: e.adWidth, height: e.adHeight },
            n = a.StandardSizes.getNearestAdSize(
              i,
              o.A.getTagType(),
              o.A.isVideoOrAudio() ? 20 : 5
            );
          n &&
            ((e.normalizedAdWidth = n.width),
            (e.normalizedAdHeight = n.height),
            s.k.dispatchEvent(
              s.DvEvents.reportData,
              new r.AdCandidateEventData(e)
            ));
        }
      }
      e.NormalizedAdSizeBL = d;
    },
    3772: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.OmidImpressionEventInfoBL = void 0);
      const n = i(8844),
        s = i(5007),
        r = i(7102),
        o = i(214);
      class a extends s.BaseAdBL {
        isSupported() {
          return n.omidAdapter.isSupported();
        }
        getEventsAndCallbacksToRegister() {
          return {
            [r.DvEvents.adCandidateApproved]: (t) => {
              this.adCandidateApproved(t);
            },
          };
        }
        init() {}
        adCandidateApproved(t) {
          n.omidAdapter.addEventListener("impression", (e) => {
            this.handleImpressionEvent(e, t);
          });
        }
        handleImpressionEvent(t, e) {
          var i, n;
          (null === (i = null == t ? void 0 : t.data) || void 0 === i
            ? void 0
            : i.impressionType) &&
            (o.omidImpressionTypeMapping[t.data.impressionType]
              ? (e.adCandidate.omidImpressionType =
                  o.omidImpressionTypeMapping[t.data.impressionType])
              : ((e.adCandidate.omidImpressionType =
                  o.omidImpressionTypeMapping.unknown),
                (e.adCandidate.omidUnknownImpressionType =
                  t.data.impressionType)));
          const s =
            null === (n = null == t ? void 0 : t.data) || void 0 === n
              ? void 0
              : n.creativeType;
          s &&
            (o.omidCreativeTypeMapping[s]
              ? (e.adCandidate.omidCreativeType = o.omidCreativeTypeMapping[s])
              : ((e.adCandidate.omidCreativeType =
                  o.omidCreativeTypeMapping.unknown),
                (e.adCandidate.omidUnknownCreativeType = s)));
        }
      }
      e.OmidImpressionEventInfoBL = a;
    },
    6370: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PageEventsLoggerBL = void 0);
      const n = i(7102),
        s = i(5007),
        r = i(9198),
        o = i(8844),
        a = i(1906),
        d = i(1805),
        c = i(4126),
        l = i(3692);
      class u extends s.BaseAdBL {
        constructor() {
          super(), (this.isPageHideNonPersistedFired = !1);
        }
        isSupported() {
          return !o.O.isDomlessEnvironment();
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.pageHideEventPersisted]:
              this.turnOnScriptDynamicFlag(16).bind(this),
            [n.DvEvents.pageHideEventNonPersisted]:
              this.logPageHideEventNonPersisted.bind(this),
          };
        }
        turnOnScriptDynamicFlag(t) {
          return () => {
            r.ScriptDynamicFlags.getInstance().turnOn(t);
          };
        }
        logPageHideEventNonPersisted() {
          this.isPageHideNonPersistedFired ||
            ((this.isPageHideNonPersistedFired = !0),
            d.L.sendMessage({
              [c.AdDataMappingToReport.timeUntilPageHideEventNonPersistedMs]:
                a.Utilities.getTimeDiff(),
            })),
            this.turnOnScriptDynamicFlag(32)();
          const t = this.turnOnScriptDynamicFlag(64).bind(this);
          (0, l.setSafeTimeout)(t, 20);
        }
        init() {}
      }
      e.PageEventsLoggerBL = u;
    },
    317: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PerformanceApiBL = void 0);
      const n = i(5007),
        s = i(3283),
        r = i(7102),
        o = i(8844);
      class a extends n.BaseAdBL {
        getEventsAndCallbacksToRegister() {
          return {
            [r.DvEvents.performanceData]:
              this.aggregatePerformanceApiData.bind(this),
          };
        }
        aggregatePerformanceApiData({ performanceData: t, adData: e }) {
          isNaN(null == t ? void 0 : t.visitResponseSize) ||
            ((e.visitResponseSize = null == t ? void 0 : t.visitResponseSize),
            r.k.dispatchEvent(
              r.DvEvents.reportData,
              new s.AdCandidateEventData(e)
            ));
        }
        init() {}
        isSupported() {
          return !o.O.isDomlessEnvironment();
        }
      }
      e.PerformanceApiBL = a;
    },
    1448: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PerformanceLongTasksBL = void 0);
      const n = i(5007),
        s = i(7102),
        r = i(7788),
        o = i(1805);
      class a extends n.BaseAdBL {
        constructor() {
          super(...arguments),
            (this.totalLongTaskDuration = 0),
            (this.totalLongTaskAmount = 0);
        }
        getEventsAndCallbacksToRegister() {
          return (
            this.reportLongTaskMeasured(),
            {
              [s.DvEvents.performanceLongTasks]:
                this.handleLongTasks.bind(this),
            }
          );
        }
        reportLongTaskMeasured() {
          o.L.sendMessage({ pltm: 1 });
        }
        handleLongTasks(t) {
          const { longTasks: e = [] } = t;
          e.length &&
            ((this.totalLongTaskAmount += e.length),
            (this.totalLongTaskDuration += e.reduce(
              (t, { duration: e }) => t + e,
              0
            )),
            o.L.sendMessage({
              pltn: this.totalLongTaskAmount,
              pltd: Math.floor(this.totalLongTaskDuration),
            }));
        }
        init() {}
        isSupported() {
          return r.PerformanceLongTasksDataCollector.isPerformanceLongTasksSupported();
        }
      }
      e.PerformanceLongTasksBL = a;
    },
    3759: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PerformanceTaskTimingBL = void 0);
      const n = i(7102),
        s = i(5051),
        r = i(8844),
        o = i(1360),
        a = i(5007);
      class d extends a.BaseAdBL {
        init() {
          (this.timings = []), (this.scheduledTaskRef = null);
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.adSelected]: this.reportTaskTiming.bind(this),
            [n.DvEvents.globalUnloadData]: this.reportTaskTiming.bind(this),
            [n.DvEvents.performanceTaskTiming]:
              this.handleTaskTiming.bind(this),
          };
        }
        isSupported() {
          return (0, r.isPerformanceApiSupported)();
        }
        handleTaskTiming(t) {
          const { taskTimings: e = [] } = t;
          e.length &&
            (this.timings.push(
              ...e.map(({ name: t, startTime: e, duration: i }) => ({
                duration: Math.round(i),
                name: t,
                startTime: Math.round(e),
              }))
            ),
            this.scheduleTrackingIfNecessary());
        }
        scheduleTrackingIfNecessary() {
          null === this.scheduledTaskRef &&
            (this.scheduledTaskRef = (0, s.scheduleTask)(() => {
              this.reportTaskTiming();
            }));
        }
        reportTaskTiming() {
          null != this.scheduledTaskRef &&
            ((this.scheduledTaskRef = null),
            o.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              o.DiagnosticParams.taskTiming,
              this.getSerializedTaskTiming()
            ));
        }
        getSerializedTaskTiming() {
          return this.timings
            .map(({ name: t, startTime: e, duration: i }) => `${t},${e},${i}`)
            .join(";");
        }
      }
      e.PerformanceTaskTimingBL = d;
    },
    1307: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PerformanceMetricsBL = void 0);
      const n = i(5007),
        s = i(7102),
        r = i(1906),
        o = i(8844),
        a = i(1805),
        d = {
          tag: { loading: 1, interactive: 2, complete: 4 },
          measurement: { loading: 8, interactive: 16, complete: 32 },
          visit: { loading: 64, interactive: 128, complete: 256 },
        };
      class c extends n.BaseAdBL {
        getScriptExecIndicator(t, e) {
          if (!e) {
            e = o.O.currentDocument().readyState;
          }
          return (d[t] || {})[e] || {} || 0;
        }
        init() {
          this.measurementScriptExecIndicator =
            this.getScriptExecIndicator("measurement");
        }
        isSupported() {
          return !o.O.isDomlessEnvironment();
        }
        getEventsAndCallbacksToRegister() {
          return {
            [s.DvEvents.impressionServed]: this.onImpressionServed.bind(this),
          };
        }
        getScriptDuration(t, e) {
          return (
            o.O.monitorScriptsPerformance(e, { [t]: ["duration"] })[
              `${t}_duration`
            ] || 0
          );
        }
        reportTagLoadTimeMs() {
          return { tltms: this.getScriptDuration("dvbm", o.O.workingWindow()) };
        }
        reportTagExecTimeMs() {
          return { tetms: o.T.getTagExecTimeMs() };
        }
        getActionName() {
          return "PerformanceMetricsBL";
        }
        reportMeasurementScriptLoadTimeMs() {
          return {
            msltms: this.getScriptDuration(
              "dv-measurements",
              o.O.currentWindow()
            ),
          };
        }
        reportVisitLoadTimeMs() {
          return {
            vltms: this.getScriptDuration("visit", o.O.currentWindow()),
          };
        }
        reportVisitExecTimeMs() {
          const t = this.getScriptDuration("visit", o.O.currentWindow());
          return {
            vetms: r.Utilities.getCurrentTime() - o.T.getVisitInjectedMS() - t,
          };
        }
        reportScriptExecIndicator() {
          const t = this.getScriptExecIndicator(
            "visit",
            o.T.getVisitReadyState()
          );
          return {
            sei:
              this.getScriptExecIndicator("tag", o.T.getTagReadyState()) |
              this.measurementScriptExecIndicator |
              t,
          };
        }
        reportTimeUntilVisitInjectedMs() {
          return { tuviims: o.T.getVisitInjectedMS() - o.T.getTagLoadedMS() };
        }
        reportTimeUntilVisitExecutedMs() {
          return {
            tuviems: r.Utilities.getCurrentTime() - o.T.getTagLoadedMS(),
          };
        }
        onImpressionServed() {
          const t = this.reportTagLoadTimeMs();
          r.Utilities.extend(this.reportTagExecTimeMs(), t),
            r.Utilities.extend(this.reportMeasurementScriptLoadTimeMs(), t),
            r.Utilities.extend(this.reportVisitLoadTimeMs(), t),
            r.Utilities.extend(this.reportScriptExecIndicator(), t),
            r.Utilities.extend(this.reportVisitExecTimeMs(), t),
            r.Utilities.extend(this.reportTimeUntilVisitInjectedMs(), t),
            r.Utilities.extend(this.reportTimeUntilVisitExecutedMs(), t),
            a.L.sendMessage(t);
        }
      }
      e.PerformanceMetricsBL = c;
    },
    1942: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.RenderingMethodLogger = void 0);
      const n = i(5007),
        s = i(7102),
        r = i(1805),
        o = i(1003);
      class a extends n.BaseAdBL {
        getEventsAndCallbacksToRegister() {
          return {
            [s.DvEvents.impressionServed]:
              this.reportRenderingMethodIndicator.bind(this),
          };
        }
        reportRenderingMethodIndicator() {
          r.L.sendMessage({
            rmi: o.RenderLogicFactory.getRenderLogic().getRenderingMethodIndicator(),
          });
        }
        init() {}
        isSupported() {
          return !0;
        }
      }
      e.RenderingMethodLogger = a;
    },
    6065: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ReportAdManagerRTS = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(5007),
        o = i(3283),
        a = i(1906),
        d = i(8334);
      class c extends r.BaseAdBL {
        init() {}
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.reportData]: this.report.bind(this),
            [n.DvEvents.adSelected]: this.report.bind(this),
          };
        }
        report(t) {
          const e = t.adCandidate,
            { reportType: i = 2, forceRTS: n = !1 } = t.relevantData;
          if (!(0 === i || 2 === i) || (2 != e.state && !n)) return;
          const s = a.Utilities.mapData(e, d.RTSDataMapping, !0),
            r = Object.keys(s);
          r.length && this.sendRtsEvents(r, e);
        }
        sendRtsEvents(t, e) {
          for (const i of t)
            s.T.publishPubSubEvent(i),
              n.k.dispatchEvent(
                n.DvEvents.rtsEventData,
                new o.AdCandidateEventData(e, { eventName: i })
              );
        }
      }
      e.ReportAdManagerRTS = c;
    },
    3115: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ReportAdManagerTPS = void 0);
      const n = i(7102),
        s = i(4126),
        r = i(5007),
        o = i(1906),
        a = i(1805);
      class d extends r.BaseAdBL {
        constructor() {
          super(...arguments), (this.cachedAdDataToReport = {});
        }
        init() {}
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.reportData]: this.report.bind(this),
            [n.DvEvents.adSelected]: this.report.bind(this),
          };
        }
        report(t) {
          const e = t.adCandidate,
            i = t.relevantData,
            n = null == i.reportType || 0 == i.reportType || 1 == i.reportType;
          if (2 != e.state || !n) return;
          const r = o.Utilities.mapData(e, s.AdDataMappingToReport, !1);
          o.Utilities.removeDuplicateValues(r, this.cachedAdDataToReport),
            o.Utilities.extend(r, this.cachedAdDataToReport);
          const { isImportantMessage: d, noConsolidation: c } = t.relevantData;
          if (!o.Utilities.isEmpty(r)) {
            const t = { isImportantMessage: d, noConsolidation: c };
            a.L.sendMessage(r, t);
          }
        }
      }
      e.ReportAdManagerTPS = d;
    },
    6851: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.S2SPartnerTelemetryBL = void 0);
      const n = i(5007),
        s = i(8844),
        r = i(7102),
        o = i(1360);
      class a extends n.BaseAdBL {
        constructor() {
          super(...arguments),
            (this.receivedIabViewable = !1),
            (this.receivedMrcImpression = !1),
            (this.receivedAdSelected = !1),
            (this.eventQueue = []);
        }
        init() {}
        isSupported() {
          return s.O.isPostMessageSupported();
        }
        getEventsAndCallbacksToRegister() {
          return { [r.DvEvents.reportData]: this.onReportData.bind(this) };
        }
        getActionName() {
          return "S2SPartnerTelemetryBL";
        }
        onReportData(t) {
          var e, i, n;
          this.receivedAdSelected ||
            2 !==
              (null === (e = null == t ? void 0 : t.adCandidate) || void 0 === e
                ? void 0
                : e.state) ||
            (this.receivedAdSelected = !0),
            !this.receivedMrcImpression &&
              (null === (i = null == t ? void 0 : t.adCandidate) || void 0 === i
                ? void 0
                : i.isMrcImpression) &&
              ((this.receivedMrcImpression = !0),
              this.eventQueue.push({ type: "MRCImpression" })),
            !this.receivedIabViewable &&
              (null === (n = null == t ? void 0 : t.adCandidate) || void 0 === n
                ? void 0
                : n.timeMsUntilAdViewed) &&
              ((this.receivedIabViewable = !0),
              this.eventQueue.push({ type: "IABViewableImpression" })),
            this.sendingPendingEvents();
        }
        sendingPendingEvents() {
          if (this.receivedAdSelected)
            for (; this.eventQueue.length; ) {
              const t = this.eventQueue.shift();
              (0, o.sendS2SPartnerTelemetryEvent)(t);
            }
        }
      }
      e.S2SPartnerTelemetryBL = a;
    },
    7986: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ScriptInjectionModeBL = void 0);
      const n = i(5007),
        s = i(8844),
        r = i(1805),
        o = i(7102);
      class a extends n.BaseAdBL {
        getEventsAndCallbacksToRegister() {
          return {
            [o.DvEvents.impressionServed]: this.onImpressionServed.bind(this),
          };
        }
        init() {}
        onImpressionServed() {
          r.L.sendMessage({ sim: s.O.getScriptInjectionMode() });
        }
        isSupported() {
          return !0;
        }
        getActionName() {
          return "ScriptInjectionModeBL";
        }
      }
      e.ScriptInjectionModeBL = a;
    },
    859: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ShareOfScreenResearchBL = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(1794);
      class o extends r.BaseAdDataLoggerBL {
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.exposureData]: this.handleViewabilityData.bind(this),
          };
        }
        isSupported() {
          return !0;
        }
        handleViewabilityData(t) {
          const e = t.adCandidate,
            i = t.relevantData,
            n = s.O.workingDocument(s.O.windowTop() || null);
          let r = !1;
          const { screenSize: o } = i,
            a = e.ShareOfScreenLastScreenSize || o,
            d = e.screenSizeChanged,
            { adSize: c } = i,
            l = e.shareOfScreenLastAdSize || c,
            { adSizeChanged: u } = e,
            h = s.S.getDevicePixelRatio(),
            { devicePixelRatioReported: v } = e,
            p = e.shareOfScreenLastDevicePixelRatio || h,
            { devicePixelRatioChanged: m } = e;
          if (
            2 === s.T.getDetectedDeliveryType() &&
            (2 == (2 & s.O.getScenarioType()) ||
              1 == (1 & s.O.getScenarioType()))
          ) {
            const t = i.viewportSize;
            if (t && t.width > 0 && t.height > 0) {
              const {
                minVpHeight: i,
                minVpWidth: n,
                maxVpHeight: s,
                maxVpWidth: o,
              } = this.getMinAndMaxViewport(e, t);
              this.isViewportChanged(e, i, n, s, o) &&
                ((r = !0),
                (e.minViewportHeight = i),
                (e.minViewportWidth = n),
                (e.maxViewportHeight = s),
                (e.maxViewportWidth = o));
            }
          }
          if (
            (!d &&
              this.validateScreenSize(o) &&
              ((e.screenSizeChanged =
                a.height !== o.height || a.width !== o.width ? 1 : void 0),
              (e.ShareOfScreenLastScreenSize = o),
              e.screenSizeChanged && (r = !0)),
            !u &&
              this.validateAdSize(c) &&
              ((e.adSizeChanged =
                l.height != c.height || l.width != c.width ? 1 : void 0),
              (e.shareOfScreenLastAdSize = c),
              e.adSizeChanged && (r = !0)),
            !m &&
              h &&
              ((e.devicePixelRatioChanged = p !== h ? 1 : void 0),
              (e.shareOfScreenLastDevicePixelRatio = h),
              e.devicePixelRatioChanged && (r = !0)),
            v || ((r = !0), (e.devicePixelRatioReported = !0)),
            n && !this.isMetaReported(e))
          ) {
            const t = s.S.getMetaTagAttributes(n, "viewport");
            for (const i of Object.keys(t)) {
              const n = t[i];
              switch (i.trim()) {
                case "width":
                  e.viewPortMetaTagWidth = n;
                  break;
                case "height":
                  e.viewPortMetaTagHeight = n;
                  break;
                case "initial-scale":
                  e.viewPortMetaTagInitialScale = n;
                  break;
                case "user-scalable":
                  e.viewPortMetaTagScalable = "yes" === n ? 1 : 0;
              }
            }
            r = this.isMetaReported(e);
          }
          r && this.report(e);
        }
        isViewportChanged(t, e, i, n, s) {
          return (
            t.minViewportHeight != e ||
            t.minViewportWidth != i ||
            t.maxViewportHeight != n ||
            t.maxViewportWidth != s
          );
        }
        getMinAndMaxViewport(t, e) {
          return {
            minVpHeight: Math.min(t.minViewportHeight || e.height, e.height),
            minVpWidth: Math.min(t.minViewportWidth || e.width, e.width),
            maxVpHeight: Math.max(t.maxViewportHeight || e.height, e.height),
            maxVpWidth: Math.max(t.maxViewportWidth || e.width, e.width),
          };
        }
        isMetaReported(t) {
          return !!(
            t.viewPortMetaTagWidth ||
            t.viewPortMetaTagHeight ||
            t.viewPortMetaTagInitialScale ||
            t.viewPortMetaTagScalable
          );
        }
        validateScreenSize(t) {
          return !(
            !(null == t ? void 0 : t.width) || !(null == t ? void 0 : t.height)
          );
        }
        validateAdSize(t) {
          return !(
            !(null == t ? void 0 : t.width) || !(null == t ? void 0 : t.height)
          );
        }
        getTrafficPercentage() {
          return 100;
        }
        getSupportedDetectedDeliveryType() {
          return [3, 2, 1];
        }
        getActionName() {
          return "ShareOfScreen";
        }
      }
      e.ShareOfScreenResearchBL = o;
    },
    3774: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BaseViewabilityBL = void 0);
      const n = i(7102),
        s = i(5007);
      class r extends s.BaseAdBL {
        getActionName() {
          return "BaseViewabilityBL";
        }
        getExposureEvent() {
          return n.DvEvents.exposureData;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.impressionServed]: this.impressionServed.bind(this),
          };
        }
        impressionServed() {
          this.shouldRegisterToExposureEvents() &&
            n.k.addEventListener(
              this.getExposureEvent(),
              this.handleViewabilityData.bind(this)
            );
        }
        handleViewabilityData(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          if (this.needToCheckViewability(e, i)) {
            this.reportViewabilityMeasured(e, i);
            const t = this.isViewabilityConditionPassed(i);
            this.shouldReportViewability(t, i.intervalDuration, e, i) &&
              this.reportViewabilityPassed(e, i.updateTime);
          }
        }
      }
      e.BaseViewabilityBL = r;
    },
    1134: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BucketsDisplayViewabilityBL = void 0);
      const n = i(8844),
        s = i(7102),
        r = i(5007),
        o = i(1906);
      class a extends r.BaseAdBL {
        init() {}
        isSupported() {
          return 0 == n.A.getTagType();
        }
        getEventsAndCallbacksToRegister() {
          return {
            [s.DvEvents.exposureData]:
              this.calculateCumulativeBuckets.bind(this),
          };
        }
        calculateCumulativeBuckets(t) {
          const e = t.adCandidate,
            i = t.relevantData,
            n = i.intervalDuration,
            s = this.getBucketNumber(i.percentage, i.focus),
            r = "b" + s;
          null != s
            ? (e[r] || (e[r] = 0),
              (e[r] += n),
              (e.viewabilityDisplayBucketsUnloadTime = i.updateTime))
            : (e.napt || (e.napt = 0), (e.napt += n));
        }
        getBucketNumber(t, e) {
          return o.Utilities.isNullOrEmpty(t)
            ? null
            : 0 != t && e
            ? Math.floor(t / 10) + 1
            : 0;
        }
      }
      e.BucketsDisplayViewabilityBL = a;
    },
    4545: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BucketsVideoViewabilityBL = void 0);
      const n = i(8844),
        s = i(7102),
        r = i(3283),
        o = i(5007);
      class a extends o.BaseAdBL {
        init() {}
        isSupported() {
          return n.A.isVideoOrAudio();
        }
        getEventsAndCallbacksToRegister() {
          return {
            [s.DvEvents.exposureData]:
              this.calculateCumulativeBuckets.bind(this),
            [s.DvEvents.adVideoFirstQuartileData]: this.handleQuartileData.bind(
              this,
              1
            ),
            [s.DvEvents.adVideoMidpointData]: this.handleQuartileData.bind(
              this,
              2
            ),
            [s.DvEvents.adVideoThirdQuartileData]: this.handleQuartileData.bind(
              this,
              3
            ),
            [s.DvEvents.adVideoCompleteData]:
              this.handleLastQuartileData.bind(this),
          };
        }
        handleLastQuartileData(t) {
          const e = this.updateQuartileTimestamp(t);
          s.k.dispatchEvent(
            s.DvEvents.reportData,
            new r.AdCandidateEventData(e, {
              isImportantMessage: !1,
              noConsolidation: !0,
            })
          );
        }
        handleQuartileData(t, e) {
          const i = this.updateQuartileTimestamp(e);
          s.k.dispatchEvent(
            s.DvEvents.reportData,
            new r.AdCandidateEventData(i)
          ),
            (i.videoBucketsQuartileId = t + 1);
        }
        updateQuartileTimestamp(t) {
          const e = t.relevantData,
            i = t.adCandidate;
          return (
            (i[`isq${i.videoBucketsQuartileId}ms`] = e.updateTime),
            i.markAdQuartile(4, i.videoBucketsQuartileId),
            i
          );
        }
        calculateCumulativeBuckets(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          if (!i.adIsPlaying) return;
          const n = i.intervalDuration,
            s = this.getBucketNumber(i.percentage, i.focus);
          if (null != s) {
            const t = "q" + e.videoBucketsQuartileId + "b" + s;
            (e[t] = e[t] ? e[t] + n : n), (e.isVideoInViewBucketsMeasured = !0);
          } else {
            const t = "q" + e.videoBucketsQuartileId + "napt";
            e[t] = e[t] ? e[t] + n : n;
          }
        }
        getBucketNumber(t, e) {
          return null == t ? null : 0 != t && e ? Math.floor(t / 25) + 1 : 0;
        }
      }
      e.BucketsVideoViewabilityBL = a;
    },
    821: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ContinuousInViewBL = void 0);
      const n = i(5007),
        s = i(8844),
        r = i(7102);
      class o extends n.BaseAdBL {
        init() {}
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [r.DvEvents.exposureData]:
              this.calculateContinuousInViewTime.bind(this),
          };
        }
        calculateContinuousInViewTime(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          if (s.A.isVideoOrAudio() && !i.adIsPlaying)
            return void (e.current50PctAdContinuousInViewTimeMs = 0);
          if (e.max50PctAdContinuousInViewTimeMs >= 6e3) return;
          const n = i.intervalDuration;
          e.current50PctAdContinuousInViewTimeMs ||
            (e.current50PctAdContinuousInViewTimeMs = 0),
            i.percentage >= 50 && i.focus
              ? (e.current50PctAdContinuousInViewTimeMs += n)
              : (e.current50PctAdContinuousInViewTimeMs = 0),
            (!e.max50PctAdContinuousInViewTimeMs ||
              e.current50PctAdContinuousInViewTimeMs >
                e.max50PctAdContinuousInViewTimeMs) &&
              (e.max50PctAdContinuousInViewTimeMs =
                e.current50PctAdContinuousInViewTimeMs);
        }
      }
      e.ContinuousInViewBL = o;
    },
    3783: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ContinuousInViewNoPauseResetBL = void 0);
      const n = i(5007),
        s = i(8844),
        r = i(7102);
      class o extends n.BaseAdBL {
        init() {}
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [r.DvEvents.exposureData]:
              this.calculateContinuousInViewTimeNoPauseReset.bind(this),
          };
        }
        calculateContinuousInViewTimeNoPauseReset(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          if (s.A.isVideoOrAudio() && !i.adIsPlaying) return;
          if (e.max50PctAdContinuousInViewTimeMsNoPauseReset >= 6e3) return;
          const n = i.intervalDuration;
          e.current50PctAdContinuousInViewTimeMsNoPauseReset ||
            (e.current50PctAdContinuousInViewTimeMsNoPauseReset = 0),
            i.percentage >= 50 && i.focus
              ? (e.current50PctAdContinuousInViewTimeMsNoPauseReset += n)
              : (e.current50PctAdContinuousInViewTimeMsNoPauseReset = 0),
            (!e.max50PctAdContinuousInViewTimeMsNoPauseReset ||
              e.current50PctAdContinuousInViewTimeMsNoPauseReset >
                e.max50PctAdContinuousInViewTimeMsNoPauseReset) &&
              (e.max50PctAdContinuousInViewTimeMsNoPauseReset =
                e.current50PctAdContinuousInViewTimeMsNoPauseReset);
        }
      }
      e.ContinuousInViewNoPauseResetBL = o;
    },
    4602: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.EndQuartileViewabilityBL = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(3283),
        o = i(5007);
      class a extends o.BaseAdBL {
        init() {}
        isSupported() {
          return s.A.isVideoOrAudio();
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.exposureData]: this.handleViewabilityData.bind(this),
            [n.DvEvents.adVideoFirstQuartileData]: this.handleQuartileData.bind(
              this,
              1
            ),
            [n.DvEvents.adVideoMidpointData]: this.handleQuartileData.bind(
              this,
              2
            ),
            [n.DvEvents.adVideoThirdQuartileData]: this.handleQuartileData.bind(
              this,
              3
            ),
            [n.DvEvents.adVideoCompleteData]:
              this.handleVideoCompleteData.bind(this),
          };
        }
        handleViewabilityData(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          i.adIsPlaying &&
            null != i.percentage &&
            ((e.endQuartileCurrentViewability = i.focus ? i.percentage : 0),
            (e.endQuartileCurrentVolume = i.volume),
            i.adSize && (e.adQuartileWidth = i.adSize.width));
        }
        handleQuartileData(t, e) {
          const i = e.adCandidate;
          (i["q" + t + "vpend"] = i.endQuartileCurrentViewability),
            (i["q" + t + "ps"] = this.getPlayerSize(i.adQuartileWidth)),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new r.AdCandidateEventData(i)
            );
        }
        getPlayerSize(t) {
          let e = 0;
          return (
            t > 0 && t <= 300
              ? (e = 1)
              : t > 300 && t <= 399
              ? (e = 2)
              : t > 399 && t <= 639
              ? (e = 3)
              : t > 639 && (e = 4),
            e
          );
        }
        handleVideoCompleteData(t) {
          const e = t.relevantData,
            i = t.adCandidate;
          0 != i.endQuartileCurrentVolume &&
            ((i.timeUntilAudibleOnCompleteMs = e.updateTime),
            i.endQuartileCurrentViewability >= 50 &&
              (i.timeMsUntilAdAudibleAndViewableOnCompletionMs = e.updateTime)),
            this.handleQuartileData(4, t);
        }
      }
      e.EndQuartileViewabilityBL = a;
    },
    3758: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.FocusBucketsBL = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(5007);
      class o extends r.BaseAdBL {
        init() {}
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.exposureData]: this.handleViewabilityData.bind(this),
          };
        }
        handleViewabilityData(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          (s.A.isVideoOrAudio() && !i.adIsPlaying) ||
            (i.focus
              ? (e.looseFocusTrueBucket = e.looseFocusTrueBucket
                  ? e.looseFocusTrueBucket + i.intervalDuration
                  : i.intervalDuration)
              : null != i.focus &&
                (e.looseFocusFalseBucket = e.looseFocusFalseBucket
                  ? e.looseFocusFalseBucket + i.intervalDuration
                  : i.intervalDuration),
            i.strictFocus
              ? (e.strictFocusTrueBucket = e.strictFocusTrueBucket
                  ? e.strictFocusTrueBucket + i.intervalDuration
                  : i.intervalDuration)
              : null != i.strictFocus &&
                (e.strictFocusFalseBucket = e.strictFocusFalseBucket
                  ? e.strictFocusFalseBucket + i.intervalDuration
                  : i.intervalDuration));
        }
      }
      e.FocusBucketsBL = o;
    },
    824: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.GroupMDisplayViewabilityBL = void 0);
      const n = i(8844),
        s = i(7102),
        r = i(3774),
        o = i(3283),
        a = i(4112);
      class d extends r.BaseViewabilityBL {
        init() {}
        isSupported() {
          return 0 == n.A.getTagType();
        }
        shouldRegisterToExposureEvents() {
          return !0;
        }
        isViewabilityConditionPassed(t) {
          return (
            !(null == t.percentage || !t.focus) &&
            (!!(0, n.isLargeAd)(
              t.adSize,
              a.ViewabilityConstants.GroupM.DisplayMinimalLargeAdArea
            ) ||
              t.percentage >=
                a.ViewabilityConstants.GroupM
                  .MinimalAdAreaPercentageForStandardSize)
          );
        }
        needToCheckViewability(t, e) {
          return null == t.groupMTimeMsUntilAdViewed && null != e.percentage;
        }
        shouldReportViewability(t, e, i, n) {
          return t;
        }
        reportViewabilityMeasured(t, e) {
          t.groupMTimeMsUntilAdMeasured ||
            ((t.groupMTimeMsUntilAdMeasured = e.updateTime),
            (t.groupMTimeMsUntilAdMeasuredRTS = e.updateTime),
            s.k.dispatchEvent(
              s.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            ));
        }
        reportViewabilityPassed(t, e) {
          t.groupMTimeMsUntilAdMeasured++,
            t.groupMTimeMsUntilAdMeasuredRTS++,
            (t.groupMTimeMsUntilAdViewed = e),
            (t.groupMTimeMsUntilAdViewedRTS = e),
            (t.groupMV3TimeMsUntilAdViewedRTS = e),
            s.k.dispatchEvent(
              s.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            );
        }
      }
      e.GroupMDisplayViewabilityBL = d;
    },
    8528: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.GroupMV4MobileDisplayViewabilityBL = void 0);
      const n = i(8844),
        s = i(7102),
        r = i(3774),
        o = i(3283);
      class a extends r.BaseViewabilityBL {
        init() {
          (this.minimalAdAreaPercentage = 0),
            (this.minimalAdAreaPercentageWhenAdAreaLowerThanViewport = 98),
            (this.minimalDuration = 1e3);
        }
        isSupported() {
          return 0 == n.A.getTagType();
        }
        shouldRegisterToExposureEvents() {
          return n.T.isMobileWeb();
        }
        isViewabilityConditionPassed(t) {
          return t.percentage > this.minimalAdAreaPercentage;
        }
        needToCheckViewability(t, e) {
          return (
            null == t.groupMV4DisplayTimeMsUntilAdViewed && null != e.percentage
          );
        }
        shouldReportViewability(t, e, i, n) {
          return (
            (i.groupMV4DisplayViewedTime = t
              ? i.groupMV4DisplayViewedTime + n.intervalDuration
              : 0),
            i.groupMV4TimeCriteriaPassed ||
              (i.groupMV4TimeCriteriaPassed =
                i.groupMV4DisplayViewedTime >= this.minimalDuration),
            i.isAllBoundariesPassed ||
              (i.isAllBoundariesPassed = this.isAllBoundariesPassed(i, n)),
            i.groupMV4TimeCriteriaPassed && i.isAllBoundariesPassed
          );
        }
        reportViewabilityMeasured(t, e) {
          t.groupMV4TimeMsUntilAdMeasured ||
            (this.isAdSizeLargerThanViewPortSize(e) &&
              !e.boundariesViewability) ||
            ((t.groupMV4TimeMsUntilAdMeasured = e.updateTime),
            s.k.dispatchEvent(
              s.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            ));
        }
        reportViewabilityPassed(t, e) {
          t.groupMV4TimeMsUntilAdMeasured++,
            (t.groupMV4DisplayTimeMsUntilAdViewed = e),
            (t.groupMV4DisplayTimeMsUntilAdViewedRTS = e),
            (t.groupMV4TimeMsUntilAdViewedRTS = e),
            s.k.dispatchEvent(
              s.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            );
        }
        getArea(t) {
          if ((null == t ? void 0 : t.width) && (null == t ? void 0 : t.height))
            return t.width * t.height;
        }
        isAdSizeLargerThanViewPortSize(t) {
          const e = this.getArea(t.adSize),
            i = this.getArea(t.viewportSize);
          return e && i && e > i;
        }
        isAllBoundariesPassed(t, e) {
          if (this.isAdSizeLargerThanViewPortSize(e)) {
            if (e.boundariesViewability) {
              const i = t.boundariesViewed;
              return (
                i.topLeft || (i.topLeft = e.boundariesViewability.topLeft),
                i.topRight || (i.topRight = e.boundariesViewability.topRight),
                i.bottomLeft ||
                  (i.bottomLeft = e.boundariesViewability.bottomLeft),
                i.bottomRight ||
                  (i.bottomRight = e.boundariesViewability.bottomRight),
                i.topLeft && i.topRight && i.bottomLeft && i.bottomRight
              );
            }
            return !1;
          }
          return (
            e.percentage >
            this.minimalAdAreaPercentageWhenAdAreaLowerThanViewport
          );
        }
      }
      e.GroupMV4MobileDisplayViewabilityBL = a;
    },
    3543: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.GroupMV4NonMobileDisplayViewabilityBL = void 0);
      const n = i(8844),
        s = i(7102),
        r = i(3774),
        o = i(3283),
        a = i(4112);
      class d extends r.BaseViewabilityBL {
        init() {}
        isSupported() {
          return 0 == n.A.getTagType();
        }
        shouldRegisterToExposureEvents() {
          return !n.T.isMobileWeb();
        }
        isViewabilityConditionPassed(t) {
          const e = (0, n.isLargeAd)(
            t.adSize,
            a.ViewabilityConstants.GroupMV4.DisplayMinimalLargeAdArea
          );
          return (
            !(null == t.percentage || !t.focus) &&
            (!!(
              e &&
              t.percentage >=
                a.ViewabilityConstants.GroupMV4
                  .DisplayMinimalAdAreaPercentageForLargeSize
            ) ||
              (!e &&
                t.percentage >=
                  a.ViewabilityConstants.GroupMV4
                    .MinimalAdAreaPercentageForStandardSize))
          );
        }
        needToCheckViewability(t, e) {
          return (
            null == t.groupMV4DisplayTimeMsUntilAdViewed && null != e.percentage
          );
        }
        shouldReportViewability(t, e, i, n) {
          return (
            (i.groupMV4DisplayViewedTime = t
              ? i.groupMV4DisplayViewedTime + n.intervalDuration
              : 0),
            i.groupMV4DisplayViewedTime >=
              a.ViewabilityConstants.GroupMV4.DisplayMinimalDuration
          );
        }
        reportViewabilityMeasured(t, e) {
          t.groupMV4TimeMsUntilAdMeasured ||
            ((t.groupMV4TimeMsUntilAdMeasured = e.updateTime),
            s.k.dispatchEvent(
              s.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            ));
        }
        reportViewabilityPassed(t, e) {
          t.groupMV4TimeMsUntilAdMeasured++,
            (t.groupMV4DisplayTimeMsUntilAdViewed = e),
            (t.groupMV4DisplayTimeMsUntilAdViewedRTS = e),
            (t.groupMV4TimeMsUntilAdViewedRTS = e),
            s.k.dispatchEvent(
              s.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            );
        }
      }
      e.GroupMV4NonMobileDisplayViewabilityBL = d;
    },
    5681: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.GroupMV4VideoNativeViewabilityBL = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(3774),
        o = i(3283),
        a = i(4112);
      class d extends r.BaseViewabilityBL {
        init() {}
        isSupported() {
          return s.A.isVideoOrAudio();
        }
        shouldRegisterToExposureEvents() {
          return !0;
        }
        isViewabilityConditionPassed(t) {
          const e =
            !s.T.isMobileApp() &&
            !s.T.isMobileWeb() &&
            (0, s.isLargeAd)(
              t.adSize,
              a.ViewabilityConstants.GroupMV4.VideoMinimalLargeAdArea
            );
          return (
            !(!t.percentage || !t.focus) &&
            (!!(
              e &&
              t.percentage >=
                a.ViewabilityConstants.GroupMV4
                  .VideoMinimalAdAreaPercentageForLargeSize
            ) ||
              (!e &&
                t.percentage >=
                  a.ViewabilityConstants.GroupMV4
                    .MinimalAdAreaPercentageForStandardSize))
          );
        }
        needToCheckViewability(t, e) {
          return (
            null == t.groupMV4VideoNativeTimeMsUntilAdViewed &&
            null != e.percentage &&
            e.adIsPlaying
          );
        }
        shouldReportViewability(t, e, i, n) {
          i.groupMV4VideoNativeViewedTime = t
            ? i.groupMV4VideoNativeViewedTime + n.intervalDuration
            : i.groupMV4VideoNativeViewedTime;
          const s = i.videoLength
            ? Math.min(
                a.ViewabilityConstants.GroupMV4.VideoMinimalDuration,
                i.videoLength *
                  (a.ViewabilityConstants.GroupMV4
                    .VideoMinimalDurationPercentage /
                    100)
              )
            : a.ViewabilityConstants.GroupMV4.VideoMinimalDuration;
          return i.groupMV4VideoNativeViewedTime >= s;
        }
        reportViewabilityMeasured(t, e) {
          null == t.groupMV4TimeMsUntilAdMeasured &&
            ((t.groupMV4TimeMsUntilAdMeasured = e.updateTime),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            ));
        }
        reportViewabilityPassed(t, e) {
          t.groupMV4TimeMsUntilAdMeasured++,
            (t.groupMV4VideoNativeTimeMsUntilAdViewed = e),
            (t.groupMV4VideoNativeTimeMsUntilAdViewedRTS = e),
            s.ServerContext.isGroupMV4VideoNativeImpression() &&
              (t.groupMV4TimeMsUntilAdViewedRTS = e),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            );
        }
      }
      e.GroupMV4VideoNativeViewabilityBL = d;
    },
    1240: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.GroupMV4VideoReachExtensionViewabilityBL = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(3774),
        o = i(3283),
        a = i(4112);
      class d extends r.BaseViewabilityBL {
        init() {}
        isSupported() {
          return s.A.isVideoOrAudio();
        }
        shouldRegisterToExposureEvents() {
          return !0;
        }
        isViewabilityConditionPassed(t) {
          const e =
            !s.T.isMobileApp() &&
            !s.T.isMobileWeb() &&
            (0, s.isLargeAd)(
              t.adSize,
              a.ViewabilityConstants.GroupMV4.VideoMinimalLargeAdArea
            );
          return (
            !(!t.percentage || !t.focus) &&
            0 != t.volume &&
            (!!(
              e &&
              t.percentage >=
                a.ViewabilityConstants.GroupMV4
                  .VideoMinimalAdAreaPercentageForLargeSize
            ) ||
              (!e &&
                t.percentage >=
                  a.ViewabilityConstants.GroupMV4
                    .MinimalAdAreaPercentageForStandardSize))
          );
        }
        needToCheckViewability(t, e) {
          return (
            null == t.groupMV4VideoReachExtensionTimeMsUntilAdViewed &&
            null != e.percentage &&
            e.adIsPlaying
          );
        }
        shouldReportViewability(t, e, i, n) {
          i.groupMV4VideoReachExtensionViewedTime = t
            ? i.groupMV4VideoReachExtensionViewedTime + n.intervalDuration
            : i.groupMV4VideoReachExtensionViewedTime;
          const s = i.videoLength
            ? Math.min(
                a.ViewabilityConstants.GroupMV4.VideoMinimalDuration,
                i.videoLength *
                  (a.ViewabilityConstants.GroupMV4
                    .VideoMinimalDurationPercentage /
                    100)
              )
            : a.ViewabilityConstants.GroupMV4.VideoMinimalDuration;
          return i.groupMV4VideoReachExtensionViewedTime >= s;
        }
        reportViewabilityMeasured(t, e) {
          null == t.groupMV4TimeMsUntilAdMeasured &&
            ((t.groupMV4TimeMsUntilAdMeasured = e.updateTime),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            ));
        }
        reportViewabilityPassed(t, e) {
          t.groupMV4TimeMsUntilAdMeasured++,
            (t.groupMV4VideoReachExtensionTimeMsUntilAdViewed = e),
            (t.groupMV4VideoReachExtensionTimeMsUntilAdViewedRTS = e),
            s.ServerContext.isGroupMV4VideoNativeImpression() ||
              (t.groupMV4TimeMsUntilAdViewedRTS = e),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            );
        }
      }
      e.GroupMV4VideoReachExtensionViewabilityBL = d;
    },
    2090: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.GroupMVideoViewabilityBL = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(3774),
        o = i(3283),
        a = i(4112);
      class d extends r.BaseViewabilityBL {
        init() {}
        isSupported() {
          return s.A.isVideoOrAudio();
        }
        shouldRegisterToExposureEvents() {
          return !0;
        }
        isViewabilityConditionPassed(t) {
          const e = (0, s.isLargeAd)(
            t.adSize,
            a.ViewabilityConstants.GroupM.VideoMinimalLargeAdArea
          );
          return (
            !(!t.percentage || !t.focus) &&
            0 != t.volume &&
            (!!(
              e &&
              t.percentage >=
                a.ViewabilityConstants.GroupM
                  .VideoMinimalAdAreaPercentageForLargeSize
            ) ||
              (!e &&
                t.percentage >=
                  a.ViewabilityConstants.GroupM
                    .MinimalAdAreaPercentageForStandardSize))
          );
        }
        needToCheckViewability(t, e) {
          return (
            null == t.groupMTimeMsUntilAdViewed &&
            null != e.percentage &&
            e.adIsPlaying
          );
        }
        shouldReportViewability(t, e, i, n) {
          i.groupMViewedTime = t
            ? i.groupMViewedTime + n.intervalDuration
            : i.groupMViewedTime;
          const s = i.videoLength
            ? Math.min(
                a.ViewabilityConstants.GroupM.VideoMinimalDuration,
                i.videoLength *
                  (a.ViewabilityConstants.GroupM
                    .VideoMinimalDurationPercentage /
                    100)
              )
            : a.ViewabilityConstants.GroupM.VideoMinimalDuration;
          return i.groupMViewedTime >= s;
        }
        reportViewabilityMeasured(t, e) {
          t.groupMTimeMsUntilAdMeasured ||
            ((t.groupMTimeMsUntilAdMeasured = e.updateTime),
            (t.groupMTimeMsUntilAdMeasuredRTS = e.updateTime),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            ));
        }
        reportViewabilityPassed(t, e) {
          t.groupMTimeMsUntilAdMeasured++,
            t.groupMTimeMsUntilAdMeasuredRTS++,
            (t.groupMTimeMsUntilAdViewed = e),
            (t.groupMTimeMsUntilAdViewedRTS = e),
            (t.groupMV3TimeMsUntilAdViewedRTS = e),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            );
        }
      }
      e.GroupMVideoViewabilityBL = d;
    },
    2911: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.IabDisplayViewabilityBL = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(3774),
        o = i(4112),
        a = i(1906),
        d = i(3283),
        c = i(9491);
      class l extends r.BaseViewabilityBL {
        init() {}
        shouldRegisterToExposureEvents() {
          return !0;
        }
        isSupported() {
          return 0 == s.A.getTagType();
        }
        needToCheckViewability(t, e) {
          return (
            null == t.timeMsUntilAdViewed &&
            null != (0, c.getIabVisiblePercentage)(e)
          );
        }
        isViewabilityConditionPassed(t) {
          const e = (0, s.isLargeAd)(
              t.adSize,
              o.ViewabilityConstants.IAB.DisplayMinimalLargeAdArea,
              s.T.isMobile()
            ),
            i = (0, c.isIabPageInFocus)(t),
            n = (0, c.getIabVisiblePercentage)(t);
          return (
            !(!n || !i) &&
            (!!(
              e &&
              n >=
                o.ViewabilityConstants.IAB
                  .DisplayMinimalAdAreaPercentageForLargeSize
            ) ||
              (!e &&
                n >=
                  o.ViewabilityConstants.IAB
                    .MinimalAdAreaPercentageForStandardSize))
          );
        }
        shouldReportViewability(t, e, i) {
          return (
            (i.iabViewedTime = t ? i.iabViewedTime + e : 0),
            i.iabViewedTime >= o.ViewabilityConstants.IAB.DisplayMinimalDuration
          );
        }
        reportViewabilityMeasured(t, e) {
          if (t.timeMsUntilAdMeasured) return;
          e.viewportSize &&
            (a.Utilities.isNumeric(e.viewportSize.height) &&
              (t.viewportHeight = Math.ceil(e.viewportSize.height)),
            a.Utilities.isNumeric(e.viewportSize.width) &&
              (t.viewportWidth = Math.ceil(e.viewportSize.width)));
          const i = s.S.getScreenSize();
          (null == i ? void 0 : i.width) &&
            (null == i ? void 0 : i.height) &&
            ((t.screenHeight = Math.ceil(i.height)),
            (t.screenWidth = Math.ceil(i.width))),
            (t.timeMsUntilAdMeasured = e.updateTime),
            (t.unadjustedTimeMsUntilAdMeasured = e.updateTime),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new d.AdCandidateEventData(t)
            );
        }
        reportViewabilityPassed(t, e) {
          (t.timeMsUntilAdViewed = e),
            (t.unadjustedTimeMsUntilAdViewed = e),
            t.timeMsUntilAdMeasured++,
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new d.AdCandidateEventData(t)
            );
        }
      }
      e.IabDisplayViewabilityBL = l;
    },
    200: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.IabDisplayViewabilityForXSecondsBL = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(3774),
        o = i(3283),
        a = i(4112),
        d = i(9491);
      class c extends r.BaseViewabilityBL {
        init() {}
        shouldRegisterToExposureEvents() {
          return !0;
        }
        isSupported() {
          return 0 == s.A.getTagType();
        }
        needToCheckViewability(t, e) {
          return (
            t.iabViewablitiyTimeToCheck.length > 0 &&
            null != this.getPercentage(e)
          );
        }
        isViewabilityConditionPassed(t) {
          const e = (0, s.isLargeAd)(
              t.adSize,
              a.ViewabilityConstants.IAB.DisplayMinimalLargeAdArea,
              s.T.isMobile()
            ),
            i = (0, d.isIabPageInFocus)(t);
          return (
            !(!this.getPercentage(t) || !i) &&
            (!!(
              e &&
              this.getPercentage(t) >=
                a.ViewabilityConstants.IAB
                  .DisplayMinimalAdAreaPercentageForLargeSize
            ) ||
              (!e &&
                this.getPercentage(t) >=
                  a.ViewabilityConstants.IAB
                    .MinimalAdAreaPercentageForStandardSize))
          );
        }
        shouldReportViewability(t, e, i) {
          return (
            (i.IABAdViewableForXSecondsViewedTime = t
              ? i.IABAdViewableForXSecondsViewedTime + e
              : 0),
            i.IABAdViewableForXSecondsViewedTime >=
              i.IABAdViewableForXSecondsdurationRequirement
          );
        }
        reportViewabilityMeasured() {}
        reportViewabilityPassed(t, e) {
          const i = t.iabViewablitiyTimeToCheck.shift();
          (t["iabv" + i] = e),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new o.AdCandidateEventData(t, { reportType: 0 })
            ),
            t.iabViewablitiyTimeToCheck.length > 0 &&
              (t.IABAdViewableForXSecondsdurationRequirement =
                1e3 * t.iabViewablitiyTimeToCheck[0]);
        }
        getPercentage(t) {
          return (0, d.getIabVisiblePercentage)(t);
        }
      }
      e.IabDisplayViewabilityForXSecondsBL = c;
    },
    9491: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.isIabPageInFocus = e.getIabVisiblePercentage = void 0);
      e.getIabVisiblePercentage = (t) => t.percentage;
      e.isIabPageInFocus = (t) => t.focus;
    },
    4710: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.IabNotViewReasonsViewabilityBL = void 0);
      const n = i(7102),
        s = i(5007),
        r = i(8844),
        o = i(4112),
        a = i(9491);
      class d extends s.BaseAdBL {
        getActionName() {
          return "IabNotViewReasonsViewabilityBL";
        }
        init() {
          (this.isVideoOrAudioTag = r.A.isVideoOrAudio()),
            (this.viewTimeThreshold = this.isVideoOrAudioTag
              ? o.ViewabilityConstants.IAB.VideoMinimalDuration
              : o.ViewabilityConstants.IAB.DisplayMinimalDuration);
        }
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return { [n.DvEvents.impressionServed]: this.start.bind(this) };
        }
        start() {
          n.k.addEventsListener({
            [n.DvEvents.exposureData]: this.handleViewabilityData.bind(this),
          });
        }
        handleViewabilityData(t) {
          const e = t.adCandidate,
            i = t.relevantData,
            n = (0, a.getIabVisiblePercentage)(i),
            s = (0, a.isIabPageInFocus)(i);
          if (!e.notViewableReasonWasViewed && null != n) {
            if (
              !this.isVideoOrAudioTag ||
              (this.isVideoOrAudioTag && i.adIsPlaying)
            )
              if (((e.notViewableReasonVideoPlayed = !0), s))
                if (((e.notViewableReasonWasInFocus = !0), n > 0)) {
                  e.notViewableReasonWasInViewPort = !0;
                  n >=
                  (!this.isVideoOrAudioTag &&
                  (0, r.isLargeAd)(
                    i.adSize,
                    o.ViewabilityConstants.IAB.DisplayMinimalLargeAdArea,
                    r.T.isMobile()
                  )
                    ? o.ViewabilityConstants.IAB
                        .DisplayMinimalAdAreaPercentageForLargeSize
                    : o.ViewabilityConstants.IAB
                        .MinimalAdAreaPercentageForStandardSize)
                    ? ((e.notViewableReasonCumulativeViewTime +=
                        i.intervalDuration),
                      (e.notViewableReasonConsecutiveViewTime +=
                        i.intervalDuration),
                      e.notViewableReasonConsecutiveViewTime >=
                        this.viewTimeThreshold &&
                        (e.notViewableReasonWasViewed = !0))
                    : (e.notViewableReasonConsecutiveViewTime = 0);
                } else e.notViewableReasonConsecutiveViewTime = 0;
              else e.notViewableReasonConsecutiveViewTime = 0;
            e.notViewableReason =
              this.getNotViewReason(e) || e.notViewableReason;
          }
        }
        getNotViewReason(t) {
          return this.isVideoOrAudioTag && !t.notViewableReasonVideoPlayed
            ? 7
            : t.notViewableReasonWasViewed
            ? 6
            : t.notViewableReasonWasInFocus
            ? t.notViewableReasonWasInViewPort
              ? 0 == t.notViewableReasonCumulativeViewTime
                ? 3
                : t.notViewableReasonCumulativeViewTime < this.viewTimeThreshold
                ? 4
                : t.notViewableReasonConsecutiveViewTime <
                  this.viewTimeThreshold
                ? 5
                : void 0
              : 2
            : 1;
        }
      }
      e.IabNotViewReasonsViewabilityBL = d;
    },
    6444: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.IabVideoQuartileViewabilityBL = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(3283),
        o = i(5007);
      class a extends o.BaseAdBL {
        init() {
          (this.iabMinimalDuration = 2e3),
            (this.iabMinimalAdAreaPercentageForStandardSize = 50);
        }
        isSupported() {
          return s.A.isVideoOrAudio();
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.exposureData]: this.handleViewabilityData.bind(this),
            [n.DvEvents.adVideoFirstQuartileData]: this.handleQuartileData.bind(
              this,
              1
            ),
            [n.DvEvents.adVideoMidpointData]: this.handleQuartileData.bind(
              this,
              2
            ),
            [n.DvEvents.adVideoThirdQuartileData]: this.handleQuartileData.bind(
              this,
              3
            ),
            [n.DvEvents.adVideoCompleteData]: this.handleQuartileData.bind(
              this,
              4
            ),
          };
        }
        handleViewabilityData(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          i.adIsPlaying &&
            (e["q" + e.iabVideoQuartileId + "iabvms"] ||
              this.tryReportViewed(e, i));
        }
        handleQuartileData(t, e) {
          const i = e.adCandidate;
          (i.iabVideoQuartileViewed = 0), (i.iabVideoQuartileId = t + 1);
        }
        tryReportViewed(t, e) {
          this.IsIabCriteriaPassed(e)
            ? ((t.iabVideoQuartileViewed += e.intervalDuration),
              t.iabVideoQuartileViewed >= this.iabMinimalDuration &&
                this.reportViewedImpression(t, e.updateTime))
            : (t.iabVideoQuartileViewed = 0);
        }
        IsIabCriteriaPassed(t) {
          return (
            !(!t.percentage || !t.focus) &&
            t.percentage >= this.iabMinimalAdAreaPercentageForStandardSize
          );
        }
        reportViewedImpression(t, e) {
          (t["q" + t.iabVideoQuartileId + "iabvms"] = e),
            t.markAdQuartile(1, t.iabVideoQuartileId),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new r.AdCandidateEventData(t)
            );
        }
      }
      e.IabVideoQuartileViewabilityBL = a;
    },
    8086: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.IabVideoViewabilityBL = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(3774),
        o = i(3283),
        a = i(4112),
        d = i(1906),
        c = i(9491);
      class l extends r.BaseViewabilityBL {
        init() {
          (this.iabMinimalDuration =
            a.ViewabilityConstants.IAB.VideoMinimalDuration),
            (this.iabMinimalAdAreaPercentageForStandardSize =
              a.ViewabilityConstants.IAB.MinimalAdAreaPercentageForStandardSize);
        }
        isSupported() {
          return s.A.isVideoOrAudio();
        }
        shouldRegisterToExposureEvents() {
          return !0;
        }
        needToCheckViewability(t, e) {
          return (
            null == t.timeMsUntilAdViewed &&
            null != this.getPercentage(e) &&
            1 == e.adHasPlayed
          );
        }
        isViewabilityConditionPassed(t) {
          const e = (0, c.isIabPageInFocus)(t);
          return (
            !(!this.getPercentage(t) || !e) &&
            this.getPercentage(t) >=
              this.iabMinimalAdAreaPercentageForStandardSize
          );
        }
        shouldReportViewability(t, e, i, n) {
          return (
            !!n.adIsPlaying &&
            ((i.iabViewedTime = t ? i.iabViewedTime + e : 0),
            i.iabViewedTime >= this.iabMinimalDuration)
          );
        }
        reportViewabilityMeasured(t, e) {
          if (t.timeMsUntilAdMeasured) return;
          e.viewportSize &&
            (d.Utilities.isNumeric(e.viewportSize.height) &&
              (t.viewportHeight = Math.ceil(e.viewportSize.height)),
            d.Utilities.isNumeric(e.viewportSize.width) &&
              (t.viewportWidth = Math.ceil(e.viewportSize.width)));
          const i = s.S.getScreenSize();
          (null == i ? void 0 : i.width) &&
            (null == i ? void 0 : i.height) &&
            ((t.screenHeight = Math.ceil(i.height)),
            (t.screenWidth = Math.ceil(i.width))),
            (t.timeMsUntilAdMeasured = e.updateTime),
            (t.unadjustedTimeMsUntilAdMeasured = e.updateTime),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            );
        }
        reportViewabilityPassed(t, e) {
          (t.timeMsUntilAdViewed = e),
            (t.unadjustedTimeMsUntilAdViewed = e),
            t.timeMsUntilAdMeasured++,
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            );
        }
        getPercentage(t) {
          return (0, c.getIabVisiblePercentage)(t);
        }
      }
      e.IabVideoViewabilityBL = l;
    },
    2790: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.IabVideoViewabilityForXSecondsBL = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(3774),
        o = i(3283),
        a = i(9491);
      class d extends r.BaseViewabilityBL {
        init() {
          (this.iabMinimalDuration = 2e3),
            (this.iabMinimalAdAreaPercentageForStandardSize = 50);
        }
        shouldRegisterToExposureEvents() {
          return !0;
        }
        isSupported() {
          return s.A.isVideoOrAudio();
        }
        needToCheckViewability(t, e) {
          return (
            t.iabViewablitiyTimeToCheck.length > 0 &&
            null != this.getPercentage(e) &&
            e.adIsPlaying
          );
        }
        isViewabilityConditionPassed(t) {
          const e = (0, a.isIabPageInFocus)(t);
          return (
            !(!this.getPercentage(t) || !e) &&
            this.getPercentage(t) >=
              this.iabMinimalAdAreaPercentageForStandardSize
          );
        }
        shouldReportViewability(t, e, i) {
          return (
            (i.IABAdViewableForXSecondsViewedTime = t
              ? i.IABAdViewableForXSecondsViewedTime + e
              : 0),
            i.IABAdViewableForXSecondsViewedTime >=
              i.IABAdViewableForXSecondsdurationRequirement
          );
        }
        reportViewabilityMeasured() {}
        reportViewabilityPassed(t, e) {
          const i = t.iabViewablitiyTimeToCheck.shift();
          (t["iabv" + i] = e),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new o.AdCandidateEventData(t, { reportType: 0 })
            ),
            t.iabViewablitiyTimeToCheck.length > 0 &&
              (t.IABAdViewableForXSecondsdurationRequirement =
                1e3 * t.iabViewablitiyTimeToCheck[0]);
        }
        getPercentage(t) {
          return (0, a.getIabVisiblePercentage)(t);
        }
      }
      e.IabVideoViewabilityForXSecondsBL = d;
    },
    8160: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.InViewShareOfScreenBL = void 0);
      const n = i(3283),
        s = i(5007),
        r = i(7102),
        o = i(1906),
        a = i(8844),
        d = i(9491);
      class c extends s.BaseAdBL {
        constructor() {
          super(...arguments),
            (this.MIN_VAL = 0),
            (this.MAX_VAL = 100),
            (this.MAX_EVENTS = 4),
            (this.MIN_PERCENTAGE_CHANGE = 10);
        }
        init() {}
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [r.DvEvents.impressionServed]:
              this.handleImpressionServed.bind(this),
          };
        }
        handleImpressionServed() {
          r.k.addEventsListener({
            [r.DvEvents.exposureData]: this.handleInViewData.bind(this),
            [r.DvEvents.adVideoCompleteData]:
              this.handleVideoCompleteOrUnload.bind(this),
            [r.DvEvents.unloadData]:
              this.handleVideoCompleteOrUnload.bind(this),
          });
        }
        updateInViewShareOfScreenData(t, e, i) {
          const n = void 0 === t.avgInViewShareOfScreen && e > 0;
          (t.avgInViewShareOfScreen = e),
            a.O.isIOS() && this.isApplicableForInstantIosReport(t, i)
              ? ((t.inViewShareOfScreenLastIosReportedPercentage = i),
                this.report(t))
              : n && this.report(t);
        }
        determineIsInViewMeasured(t, e) {
          const i =
            (null == t ? void 0 : t.height) && (null == t ? void 0 : t.width);
          if (
            (null == e ? void 0 : e.height) &&
            (null == e ? void 0 : e.width) &&
            i
          )
            return 1;
        }
        handleInViewData(t) {
          const {
            inViewShareOfScreenData: e,
            screenSize: i,
            visiblePercentage: n,
            adSize: s,
            adIsPlaying: r,
            isInFocus: a,
          } = this.prepareValues(t);
          if (
            (void 0 === e.inViewShareOfScreenMeasured &&
              (e.inViewShareOfScreenMeasured = this.determineIsInViewMeasured(
                i,
                s
              )),
            !this.isInViewConditionPassed(s, i, r, a, n))
          )
            return;
          const d = (s.height * s.width * n) / (i.width * i.height);
          (e.sumInViewShareOfScreen += d),
            (e.inViewIntervalCount = e.inViewIntervalCount + 1);
          const c = o.Utilities.getValBetweenMinAndMax(
            Math.round(e.sumInViewShareOfScreen / e.inViewIntervalCount),
            this.MIN_VAL,
            this.MAX_VAL
          );
          this.updateInViewShareOfScreenData(e, c, n);
        }
        prepareValues(t) {
          const e = t.relevantData,
            i = t.adCandidate;
          i.sumInViewShareOfScreen || (i.sumInViewShareOfScreen = 0),
            i.inViewIntervalCount || (i.inViewIntervalCount = 0);
          const {
            screenSize: n,
            visiblePercentage: s,
            adSize: r,
            adIsPlaying: o,
            isInFocus: a,
          } = this.collectCurrentShareOfScreenData(e, i);
          return {
            inViewShareOfScreenData: i,
            screenSize: n,
            visiblePercentage: s,
            adSize: r,
            adIsPlaying: o,
            isInFocus: a,
          };
        }
        report(t) {
          r.k.dispatchEvent(
            r.DvEvents.reportData,
            new n.AdCandidateEventData(t)
          );
        }
        calculateMaxEventsNumber(t) {
          return void 0 === t ? this.MAX_EVENTS : t;
        }
        isApplicableForInstantIosReport(t, e) {
          t.inViewShareOfScreenEventsLeftToReport =
            this.calculateMaxEventsNumber(
              t.inViewShareOfScreenEventsLeftToReport
            );
          const i =
            !t.inViewShareOfScreenLastIosReportedPercentage ||
            (t.inViewShareOfScreenEventsLeftToReport > 0 &&
              t.inViewShareOfScreenLastIosReportedPercentage != e &&
              t.inViewShareOfScreenLastIosReportedPercentage +
                this.MIN_PERCENTAGE_CHANGE <=
                100 &&
              Math.abs(t.inViewShareOfScreenLastIosReportedPercentage - e) >=
                this.MIN_PERCENTAGE_CHANGE);
          return (
            i &&
              (t.inViewShareOfScreenEventsLeftToReport =
                0 === t.inViewShareOfScreenEventsLeftToReport
                  ? 0
                  : t.inViewShareOfScreenEventsLeftToReport - 1),
            i
          );
        }
        collectCurrentShareOfScreenData(t, e) {
          const i = (0, d.isIabPageInFocus)(t),
            n = this.getComparableScreenSize(t, e),
            s = t.percentage,
            { adSize: r } = t;
          return {
            screenSize: n,
            visiblePercentage: s,
            adSize: r,
            adIsPlaying: !a.A.isVideoOrAudio() || t.adIsPlaying,
            isInFocus: i,
          };
        }
        getComparableScreenSize(t, e) {
          e.inViewShareOfScreenReadFromViewport ||
            (e.inViewShareOfScreenReadFromViewport =
              this.isApplicableForViewportMeasurement() &&
              this.reportReadFromViewport(e));
          let { screenSize: i } = t;
          if (
            e.inViewShareOfScreenReadFromViewport &&
            i &&
            i.width > 0 &&
            i.height
          ) {
            const e = a.S.getInnerViewport();
            e.width > 0 &&
              e.height > 0 &&
              (i = {
                width: e.width,
                height: t.screenSize.height * (e.width / t.screenSize.width),
              });
          }
          return i;
        }
        isApplicableForViewportMeasurement() {
          if (
            2 === a.T.getDetectedDeliveryType() &&
            (2 == (2 & a.O.getScenarioType()) ||
              1 == (1 & a.O.getScenarioType()))
          ) {
            const t = a.S.getMetaTagAttributes(
              a.O.workingDocument(a.O.windowTop()),
              "viewport"
            );
            return !this.isWebPageResponsive(t);
          }
          return !1;
        }
        isWebPageResponsive(t) {
          const e = t.width,
            i = t["initial-scale"];
          return (
            !o.Utilities.isEmptyObject(t) &&
            (1 === Number(i) || "device-width" === e)
          );
        }
        reportReadFromViewport(t) {
          return (t.inViewShareOfScreenReadFromViewportReport = 1), !0;
        }
        handleVideoCompleteOrUnload(t) {
          const e = t.adCandidate;
          this.report(e);
        }
        isInViewConditionPassed(t, e, i, n, s) {
          return i && n && this.validateScreenAndAdSize(t, e) && s > 0;
        }
        validateScreenAndAdSize(t, e) {
          const i =
              (null == t ? void 0 : t.width) && (null == t ? void 0 : t.height),
            n =
              (null == e ? void 0 : e.width) && (null == e ? void 0 : e.height);
          return i && n;
        }
        getActionName() {
          return "InViewShareOfScreenBL";
        }
      }
      e.InViewShareOfScreenBL = c;
    },
    4234: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PMXDisplayViewabilityBL = void 0);
      const n = i(8844),
        s = i(7102),
        r = i(3774),
        o = i(3283),
        a = i(4112);
      class d extends r.BaseViewabilityBL {
        init() {}
        isSupported() {
          return 0 == n.A.getTagType();
        }
        shouldRegisterToExposureEvents() {
          return !0;
        }
        isViewabilityConditionPassed(t) {
          const e = (0, n.isLargeAd)(
            t.adSize,
            a.ViewabilityConstants.PMX.DisplayMinimalLargeAdArea
          );
          return (
            !(!t.percentage || !t.focus) &&
            (!!(
              e &&
              t.percentage >=
                a.ViewabilityConstants.PMX
                  .DisplayMinimalAdAreaPercentageForLargeSize
            ) ||
              (!e &&
                t.percentage >=
                  a.ViewabilityConstants.PMX
                    .MinimalAdAreaPercentageForStandardSize))
          );
        }
        needToCheckViewability(t, e) {
          return null == t.pmxTimeMsUntilAdViewed && null != e.percentage;
        }
        shouldReportViewability(t, e, i, n) {
          return (
            (i.pmxViewedTime = t ? i.pmxViewedTime + e : 0),
            i.pmxViewedTime >= a.ViewabilityConstants.PMX.DisplayMinimalDuration
          );
        }
        reportViewabilityMeasured(t, e) {
          t.pmxTimeMsUntilAdMeasured ||
            (t.pmxTimeMsUntilAdMeasured = e.updateTime);
        }
        reportViewabilityPassed(t, e) {
          (t.pmxTimeMsUntilAdViewed = e),
            s.k.dispatchEvent(
              s.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            );
        }
      }
      e.PMXDisplayViewabilityBL = d;
    },
    9855: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PMXVideoViewabilityBL = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(3774),
        o = i(3283),
        a = i(4112);
      class d extends r.BaseViewabilityBL {
        init() {}
        isSupported() {
          return s.A.isVideoOrAudio();
        }
        shouldRegisterToExposureEvents() {
          return !0;
        }
        isViewabilityConditionPassed(t) {
          const e = (0, s.isLargeAd)(
            t.adSize,
            a.ViewabilityConstants.PMX.VideoMinimalLargeAdArea
          );
          return (
            !(!t.percentage || !t.focus) &&
            (!!(
              e &&
              t.percentage >=
                a.ViewabilityConstants.PMX
                  .VideoMinimalAdAreaPercentageForLargeSize
            ) ||
              (!e &&
                t.percentage >=
                  a.ViewabilityConstants.PMX
                    .MinimalAdAreaPercentageForStandardSize))
          );
        }
        needToCheckViewability(t, e) {
          return (
            null == t.pmxTimeMsUntilAdViewed &&
            null != e.percentage &&
            e.adIsPlaying
          );
        }
        shouldReportViewability(t, e, i, n) {
          return (
            (i.pmxViewedTime = t ? i.pmxViewedTime + e : 0),
            i.pmxViewedTime >= a.ViewabilityConstants.PMX.VideoMinimalDuration
          );
        }
        reportViewabilityMeasured(t, e) {
          t.pmxTimeMsUntilAdMeasured ||
            (t.pmxTimeMsUntilAdMeasured = e.updateTime);
        }
        reportViewabilityPassed(t, e) {
          (t.pmxTimeMsUntilAdViewed = e),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            );
        }
      }
      e.PMXVideoViewabilityBL = d;
    },
    5589: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.RbViewabilityBL = void 0);
      const n = i(7102),
        s = i(3283),
        r = i(8844),
        o = i(5007),
        a = i(4112);
      class d extends o.BaseAdBL {
        getActionName() {
          return "RbViewabilityBL";
        }
        init() {}
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.impressionServed]: this.impressionServed.bind(this),
          };
        }
        impressionServed() {
          r.T.getAllowRBViewability() &&
            n.k.addEventListener(
              n.DvEvents.exposureData,
              this.handleViewabilityData.bind(this)
            );
        }
        handleViewabilityData(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          (r.A.isVideoOrAudio() && !i.adIsPlaying) ||
            e.rBV1PassedMs ||
            this.tryReportViewed(e, i);
        }
        tryReportViewed(t, e) {
          e.percentage &&
            e.focus &&
            e.percentage >=
              a.ViewabilityConstants.RB
                .MinimalAdAreaPercentageForStandardSize &&
            this.reportViewedImpression(t, e.updateTime);
        }
        reportViewedImpression(t, e) {
          (t.rBV1PassedMs = e),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new s.AdCandidateEventData(t)
            );
        }
      }
      e.RbViewabilityBL = d;
    },
    6502: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.SecondaryBaseViewabilityBL = void 0);
      const n = i(7102),
        s = i(5007);
      class r extends s.BaseAdBL {
        getActionName() {
          return "SecondaryBaseViewabilityBL";
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.impressionServed]: this.impressionServed.bind(this),
          };
        }
        impressionServed() {
          this.shouldRegisterToExposureEvents() &&
            n.k.addEventListener(
              n.DvEvents.secondaryExposureData,
              this.handleViewabilityData.bind(this)
            );
        }
        handleViewabilityData(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          if (this.needToCheckViewability(e, i)) {
            this.reportViewabilityMeasured(e, i);
            const t = this.isViewabilityConditionPassed(i);
            this.shouldReportViewability(t, i.intervalDuration, e, i) &&
              this.reportViewabilityPassed(e, i.updateTime);
          }
        }
      }
      e.SecondaryBaseViewabilityBL = r;
    },
    2105: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.SecondaryIabDisplayViewabilityBL = void 0);
      const n = i(8844),
        s = i(4112),
        r = i(6502),
        o = i(3283),
        a = i(7102),
        d = i(9491);
      class c extends r.SecondaryBaseViewabilityBL {
        init() {}
        shouldRegisterToExposureEvents() {
          return !0;
        }
        isSupported() {
          return 0 == n.A.getTagType();
        }
        needToCheckViewability(t, e) {
          return (
            null == t.timeMsUntilAdViewedSecondary &&
            null != (0, d.getIabVisiblePercentage)(e)
          );
        }
        isViewabilityConditionPassed(t) {
          const e = (0, n.isLargeAd)(
              t.adSize,
              s.ViewabilityConstants.IAB.DisplayMinimalLargeAdArea,
              n.T.isMobile()
            ),
            i = (0, d.isIabPageInFocus)(t),
            r = (0, d.getIabVisiblePercentage)(t);
          return (
            !(!r || !i) &&
            (!!(
              e &&
              r >=
                s.ViewabilityConstants.IAB
                  .DisplayMinimalAdAreaPercentageForLargeSize
            ) ||
              (!e &&
                r >=
                  s.ViewabilityConstants.IAB
                    .MinimalAdAreaPercentageForStandardSize))
          );
        }
        shouldReportViewability(t, e, i) {
          return (
            (i.iabViewedTimeSecondary = t ? i.iabViewedTimeSecondary + e : 0),
            i.iabViewedTimeSecondary >=
              s.ViewabilityConstants.IAB.DisplayMinimalDuration
          );
        }
        reportViewabilityMeasured(t, e) {
          t.timeMsUntilAdMeasuredSecondary ||
            ((t.timeMsUntilAdMeasuredSecondary = e.updateTime),
            (t.unadjustedTimeMsUntilAdMeasuredSecondary = e.updateTime),
            a.k.dispatchEvent(
              a.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            ));
        }
        reportViewabilityPassed(t, e) {
          (t.timeMsUntilAdViewedSecondary = e),
            (t.unadjustedTimeMsUntilAdViewedSecondary = e),
            t.timeMsUntilAdMeasuredSecondary++,
            a.k.dispatchEvent(
              a.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            );
        }
      }
      e.SecondaryIabDisplayViewabilityBL = c;
    },
    3680: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.SecondaryIabVideoViewabilityBL = void 0);
      const n = i(8844),
        s = i(4112),
        r = i(6502),
        o = i(3283),
        a = i(7102),
        d = i(9491);
      class c extends r.SecondaryBaseViewabilityBL {
        init() {
          (this.iabMinimalDuration =
            s.ViewabilityConstants.IAB.VideoMinimalDuration),
            (this.iabMinimalAdAreaPercentageForStandardSize =
              s.ViewabilityConstants.IAB.MinimalAdAreaPercentageForStandardSize);
        }
        isSupported() {
          return n.A.isVideoOrAudio();
        }
        shouldRegisterToExposureEvents() {
          return !0;
        }
        needToCheckViewability(t, e) {
          return (
            null == t.timeMsUntilAdViewedSecondary &&
            null != this.getPercentage(e) &&
            e.adIsPlaying
          );
        }
        isViewabilityConditionPassed(t) {
          const e = (0, d.isIabPageInFocus)(t);
          return (
            !(!this.getPercentage(t) || !e) &&
            this.getPercentage(t) >=
              this.iabMinimalAdAreaPercentageForStandardSize
          );
        }
        shouldReportViewability(t, e, i) {
          return (
            (i.iabViewedTimeSecondary = t ? i.iabViewedTimeSecondary + e : 0),
            i.iabViewedTimeSecondary >= this.iabMinimalDuration
          );
        }
        reportViewabilityMeasured(t, e) {
          t.timeMsUntilAdMeasuredSecondary ||
            ((t.timeMsUntilAdMeasuredSecondary = e.updateTime),
            (t.unadjustedTimeMsUntilAdMeasuredSecondary = e.updateTime),
            a.k.dispatchEvent(
              a.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            ));
        }
        reportViewabilityPassed(t, e) {
          (t.timeMsUntilAdViewedSecondary = e),
            (t.unadjustedTimeMsUntilAdViewedSecondary = e),
            t.timeMsUntilAdMeasuredSecondary++,
            a.k.dispatchEvent(
              a.DvEvents.reportData,
              new o.AdCandidateEventData(t)
            );
        }
        getPercentage(t) {
          return (0, d.getIabVisiblePercentage)(t);
        }
      }
      e.SecondaryIabVideoViewabilityBL = c;
    },
    3907: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VideoFullQuartileAudibleBL = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(3283),
        o = i(5007);
      class a extends o.BaseAdBL {
        init() {
          this.minimalAdAreaPercentageForStandardSize = 98;
        }
        isSupported() {
          return s.A.isVideoOrAudio();
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.exposureData]: this.handleAudibleData.bind(this),
            [n.DvEvents.adVideoFirstQuartileData]: this.handleQuartileData.bind(
              this,
              1
            ),
            [n.DvEvents.adVideoMidpointData]: this.handleQuartileData.bind(
              this,
              2
            ),
            [n.DvEvents.adVideoThirdQuartileData]: this.handleQuartileData.bind(
              this,
              3
            ),
            [n.DvEvents.adVideoCompleteData]: this.handleQuartileData.bind(
              this,
              4
            ),
          };
        }
        handleAudibleData(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          i.adIsPlaying &&
            (0 != e.isVideoFullQuartileAudible &&
            this.isCriteriaPassed(i.volume)
              ? (e.isVideoFullQuartileAudible = !0)
              : (e.isVideoFullQuartileAudible = !1));
        }
        handleQuartileData(t, e) {
          const i = e.adCandidate;
          this.reportViewedImpression(i),
            (i.videoFullQuartileAudibleId = t + 1),
            (i.isVideoFullQuartileAudible = null);
        }
        isCriteriaPassed(t) {
          return null != t && -1 != t && 0 != t;
        }
        reportViewedImpression(t) {
          t.isVideoFullQuartileAudible &&
            (t.markAdQuartile(8, t.videoFullQuartileAudibleId),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new r.AdCandidateEventData(t)
            ));
        }
      }
      e.VideoFullQuartileAudibleBL = a;
    },
    9137: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VideoInViewAndAudibleBL = void 0);
      const n = i(8844),
        s = i(7102),
        r = i(5007),
        o = i(1906);
      class a extends r.BaseAdBL {
        init() {}
        isSupported() {
          return n.A.isVideoOrAudio();
        }
        getEventsAndCallbacksToRegister() {
          return {
            [s.DvEvents.exposureData]:
              this.handleInViewAndAudibleData.bind(this),
          };
        }
        handleInViewAndAudibleData(t) {
          var e, i;
          const n = t.adCandidate,
            s = t.relevantData;
          if (!s.adIsPlaying) return;
          const r = s.intervalDuration,
            o = this.getBucketNumber(s.percentage, s.focus);
          if (null != o && this.isAudible(s.volume)) {
            const t = "ivab" + o;
            n[t] = r + (null !== (e = n[t]) && void 0 !== e ? e : 0);
          } else
            n.ivanapt =
              r +
              (null !== (i = null == n ? void 0 : n.ivanapt) && void 0 !== i
                ? i
                : 0);
        }
        getBucketNumber(t, e) {
          return o.Utilities.isNullOrEmpty(t)
            ? null
            : 0 != t && e
            ? Math.floor(t / 10) + 1
            : 0;
        }
        isAudible(t) {
          return t > 0;
        }
      }
      e.VideoInViewAndAudibleBL = a;
    },
    6873: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VideoQuartileFullOnScreenBL = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(3283),
        o = i(5007);
      class a extends o.BaseAdBL {
        init() {
          this.minimalAdAreaPercentageForStandardSize = 98;
        }
        isSupported() {
          return s.A.isVideoOrAudio();
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.exposureData]: this.handleViewabilityData.bind(this),
            [n.DvEvents.adVideoFirstQuartileData]: this.handleQuartileData.bind(
              this,
              1
            ),
            [n.DvEvents.adVideoMidpointData]: this.handleQuartileData.bind(
              this,
              2
            ),
            [n.DvEvents.adVideoThirdQuartileData]: this.handleQuartileData.bind(
              this,
              3
            ),
            [n.DvEvents.adVideoCompleteData]: this.handleQuartileData.bind(
              this,
              4
            ),
          };
        }
        handleViewabilityData(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          i.adIsPlaying &&
            (0 != e.isVideoFullQuartileViewed && this.isCriteriaPassed(i)
              ? (e.isVideoFullQuartileViewed = !0)
              : (e.isVideoFullQuartileViewed = !1));
        }
        handleQuartileData(t, e) {
          const i = e.adCandidate;
          this.reportViewedImpression(i),
            (i.videoFullQuartileViewabilityId = t + 1),
            (i.isVideoFullQuartileViewed = null);
        }
        isCriteriaPassed(t) {
          return (
            !(!t.percentage || !t.focus) &&
            t.percentage >= this.minimalAdAreaPercentageForStandardSize
          );
        }
        reportViewedImpression(t) {
          t.isVideoFullQuartileViewed &&
            (t.markAdQuartile(16, t.videoFullQuartileViewabilityId),
            n.k.dispatchEvent(
              n.DvEvents.reportData,
              new r.AdCandidateEventData(t)
            ));
        }
      }
      e.VideoQuartileFullOnScreenBL = a;
    },
    7781: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ViewabilityMeasurementBL = void 0);
      const n = i(7102),
        s = i(3283),
        r = i(8844),
        o = i(5007),
        a = i(3133);
      class d extends o.BaseAdBL {
        constructor(t = a.ViewabilityStandardRegistrySingleton) {
          super(), (this.registry = t);
        }
        init() {}
        getActionName() {
          return "ViewabilityMeasurementBL";
        }
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.impressionServed]:
              this.scheduleIntervalBasedMeasurement.bind(this),
          };
        }
        scheduleIntervalBasedMeasurement() {
          this.shouldRegisterToExposureEvents() &&
            n.k.addEventListener(
              n.DvEvents.exposureData,
              this.onViewabilityInterval.bind(this)
            );
        }
        onViewabilityInterval(t) {
          var e;
          const i = t.adCandidate,
            n = t.relevantData;
          null === (e = this.registry.getRegisteredStandards()) ||
            void 0 === e ||
            e.forEach((t) => {
              const e = this.getMeasurementByStandard(
                t.standardId,
                i,
                t.inEvaluation
              );
              if (this.needToCheckViewability(e, n)) {
                this.reportViewabilityMeasured(
                  e,
                  i,
                  n.updateTime,
                  t.onMeasured
                );
                const s =
                    null != t.settings.minimalLargeAdArea &&
                    (0, r.isLargeAd)(n.adSize, t.settings.minimalLargeAdArea),
                  o = this.getConditions(t.settings, s),
                  a = this.isViewabilityConditionPassed(o, n);
                this.shouldReportViewability(o, a, e, i, n.intervalDuration) &&
                  this.reportViewabilityPassed(e, i, n.updateTime, t.onPassed);
              }
            });
        }
        getMeasurementByStandard(t, e, i = !1) {
          var n;
          return (
            (n = e.activeViewabilityMeasurements)[t] ||
            (n[t] = {
              standardId: t,
              inEvaluation: i,
              timeInView: 0,
              timeUntilMeasured: null,
              timeUntilPassed: null,
            })
          );
        }
        needToCheckViewability(t, e) {
          return (
            !this.isViewabilityAlreadyDetermined(t) &&
            !(r.A.isVideoOrAudio() && !e.adIsPlaying) &&
            null != e.percentage
          );
        }
        isViewabilityAlreadyDetermined(t) {
          return !!t.timeUntilPassed;
        }
        reportViewabilityMeasured(t, e, i, n) {
          t.timeUntilMeasured ||
            ((t.timeUntilMeasured = i), n(new s.AdCandidateEventData(e)));
        }
        isViewabilityConditionPassed(t, e) {
          return (
            !(t.onFocus && !e.focus) &&
            !(null != t.adPercentage && e.percentage < t.adPercentage) &&
            (!r.A.isVideoOrAudio() || !t.isVolumeRequired || 0 != e.volume)
          );
        }
        getConditions(t, e) {
          return e ? t.largeAd : t.regularAd;
        }
        shouldRegisterToExposureEvents() {
          return !0;
        }
        shouldReportViewability(t, e, i, n, s) {
          const { isConsecutive: r, durationCap: o, durationPercentage: a } = t;
          if (null == o && null == a) return e;
          i.timeInView = e ? i.timeInView + s : r ? 0 : i.timeInView;
          const { videoLength: d } = n,
            c = o,
            l = null != d && null != a ? d * (a / 100) : null,
            u = null != c && i.timeInView >= c,
            h = null != l && i.timeInView >= l;
          return u || h;
        }
        reportViewabilityPassed(t, e, i, n) {
          (t.timeUntilPassed = i), n(new s.AdCandidateEventData(e));
        }
      }
      e.ViewabilityMeasurementBL = d;
    },
    3133: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ViewabilityStandardRegistrySingleton =
          e.ViewabilityStandardRegistry =
            void 0);
      class i {
        constructor() {
          this.registeredStandards = {};
        }
        register(t) {
          if (this.registeredStandards[t.standardId])
            throw new Error(
              `ViewabilityStandardRegistry standardId '${t.standardId}' already exists`
            );
          this.registeredStandards[t.standardId] = t;
        }
        getRegisteredStandards() {
          return Object.values(this.registeredStandards);
        }
      }
      (e.ViewabilityStandardRegistry = i),
        (e.ViewabilityStandardRegistrySingleton = new i());
    },
    7331: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ViewabilityStartPercentageBL = void 0);
      const n = i(7102),
        s = i(3283),
        r = i(8844),
        o = i(5007);
      class a extends o.BaseAdBL {
        init() {
          this.visiblePercentage = 50;
        }
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [n.DvEvents.exposureData]: this.handleViewabilityData.bind(this),
          };
        }
        handleViewabilityData(t) {
          const e = t.adCandidate,
            i = t.relevantData;
          (r.A.isVideoOrAudio() && !i.adIsPlaying) ||
            (null == e.startPercentage &&
              null != i.percentage &&
              ((e.startPercentage = i.percentage),
              (e.adVisibleOnload = i.percentage >= this.visiblePercentage),
              n.k.dispatchEvent(
                n.DvEvents.reportData,
                new s.AdCandidateEventData(e)
              )));
        }
      }
      e.ViewabilityStartPercentageBL = a;
    },
    4770: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ViewableShareOfScreenBL = void 0);
      const n = i(3283),
        s = i(5007),
        r = i(7102),
        o = i(1906),
        a = i(4112),
        d = i(8844),
        c = i(9491);
      class l extends s.BaseAdBL {
        constructor() {
          super(...arguments),
            (this.MIN_VAL = 0),
            (this.MAX_VAL = 100),
            (this.MAX_EVENTS = 4),
            (this.MIN_PERCENTAGE_CHANGE = 10);
        }
        init() {}
        isSupported() {
          return !0;
        }
        getEventsAndCallbacksToRegister() {
          return {
            [r.DvEvents.impressionServed]:
              this.handleImpressionServed.bind(this),
          };
        }
        handleImpressionServed() {
          r.k.addEventsListener({
            [r.DvEvents.exposureData]: this.handleViewabilityData.bind(this),
            [r.DvEvents.adVideoCompleteData]:
              this.handleVideoCompleteOrUnload.bind(this),
            [r.DvEvents.unloadData]:
              this.handleVideoCompleteOrUnload.bind(this),
          });
        }
        handleViewabilityData(t) {
          const {
            viewableShareOfScreenData: e,
            screenSize: i,
            viewablePercentage: n,
            adSize: s,
            adIsPlaying: r,
            isInFocus: a,
            isIabViewed: c,
          } = this.prepareValues(t);
          if (this.isViewabilityConditionPassed(s, i, r, a, n)) {
            const t = (s.height * s.width * n) / (i.width * i.height);
            if (
              ((e.sumViewableShareOfScreen += t),
              (e.viewableIntervalCount = e.viewableIntervalCount + 1),
              c)
            ) {
              const { shareOfScreenNotMeasuredReason: t } = e;
              e.shareOfScreenNotMeasuredReason = 16;
              const i = o.Utilities.getValBetweenMinAndMax(
                Math.round(
                  e.sumViewableShareOfScreen / e.viewableIntervalCount
                ),
                this.MIN_VAL,
                this.MAX_VAL
              );
              (e.avgViewableShareOfScreen = i),
                d.O.isIOS() && this.isApplicableForInstantIosReport(e, n)
                  ? ((e.shareOfScreenLastIosReportedPercentage = n),
                    this.report(e))
                  : this.shouldReportFirstTimeViewableShareOfScreenIsMeasured(
                      t
                    ) && this.report(e);
            }
          }
          e.shareOfScreenNotMeasuredReason = this.getValidationReasonBits(
            i,
            s,
            c,
            e
          );
        }
        shouldReportFirstTimeViewableShareOfScreenIsMeasured(t) {
          return !!t && 16 !== t;
        }
        prepareValues(t) {
          const e = t.relevantData,
            i = t.adCandidate;
          i.sumViewableShareOfScreen || (i.sumViewableShareOfScreen = 0),
            i.viewableIntervalCount || (i.viewableIntervalCount = 0);
          const {
            screenSize: n,
            viewablePercentage: s,
            adSize: r,
            adIsPlaying: o,
            isInFocus: a,
          } = this.collectCurrentShareOfScreenData(e, i);
          return {
            viewableShareOfScreenData: i,
            screenSize: n,
            viewablePercentage: s,
            adSize: r,
            adIsPlaying: o,
            isInFocus: a,
            isIabViewed: !!i.timeMsUntilAdViewed,
          };
        }
        report(t) {
          r.k.dispatchEvent(
            r.DvEvents.reportData,
            new n.AdCandidateEventData(t)
          );
        }
        calculateMaxEventsNumber(t) {
          return void 0 === t ? this.MAX_EVENTS : t;
        }
        isApplicableForInstantIosReport(t, e) {
          t.shareOfScreenEventsLeftToReport = this.calculateMaxEventsNumber(
            t.shareOfScreenEventsLeftToReport
          );
          const i =
            !t.shareOfScreenLastIosReportedPercentage ||
            (t.shareOfScreenEventsLeftToReport > 0 &&
              t.shareOfScreenLastIosReportedPercentage != e &&
              t.shareOfScreenLastIosReportedPercentage +
                this.MIN_PERCENTAGE_CHANGE <=
                100 &&
              Math.abs(t.shareOfScreenLastIosReportedPercentage - e) >=
                this.MIN_PERCENTAGE_CHANGE);
          return (
            i &&
              (t.shareOfScreenEventsLeftToReport =
                0 === t.shareOfScreenEventsLeftToReport
                  ? 0
                  : t.shareOfScreenEventsLeftToReport - 1),
            i
          );
        }
        collectCurrentShareOfScreenData(t, e) {
          const i = (0, c.isIabPageInFocus)(t),
            n = this.getComparableScreenSize(t, e),
            s = t.percentage,
            { adSize: r } = t;
          return {
            screenSize: n,
            viewablePercentage: s,
            adSize: r,
            adIsPlaying: !d.A.isVideoOrAudio() || t.adIsPlaying,
            isInFocus: i,
          };
        }
        getComparableScreenSize(t, e) {
          e.shareOfScreenReadFromViewport ||
            (e.shareOfScreenReadFromViewport =
              this.isApplicableForViewportMeasurement() &&
              this.reportReadFromViewport(e));
          let { screenSize: i } = t;
          if (e.shareOfScreenReadFromViewport && i && i.width > 0 && i.height) {
            const e = d.S.getInnerViewport();
            e.width > 0 &&
              e.height > 0 &&
              (i = {
                width: e.width,
                height: t.screenSize.height * (e.width / t.screenSize.width),
              });
          }
          return i;
        }
        isApplicableForViewportMeasurement() {
          if (
            2 === d.T.getDetectedDeliveryType() &&
            (2 == (2 & d.O.getScenarioType()) ||
              1 == (1 & d.O.getScenarioType()))
          ) {
            const t = d.S.getMetaTagAttributes(
              d.O.workingDocument(d.O.windowTop()),
              "viewport"
            );
            return !this.isWebPageResponsive(t);
          }
          return !1;
        }
        isWebPageResponsive(t) {
          const e = t.width,
            i = t["initial-scale"];
          return (
            !o.Utilities.isEmptyObject(t) &&
            (1 === Number(i) || "device-width" === e)
          );
        }
        reportReadFromViewport(t) {
          return (t.shareOfScreenReadFromViewportReport = 1), !0;
        }
        handleVideoCompleteOrUnload(t) {
          const e = t.adCandidate;
          this.report(e);
        }
        isViewabilityConditionPassed(t, e, i, n, s) {
          return (
            i &&
            n &&
            this.validateScreenAndAdSize(t, e) &&
            this.isAdPercentageCriteriaPassed(t, s)
          );
        }
        validateScreenAndAdSize(t, e) {
          const i =
              (null == t ? void 0 : t.width) && (null == t ? void 0 : t.height),
            n =
              (null == e ? void 0 : e.width) && (null == e ? void 0 : e.height);
          return i && n;
        }
        getValidationReasonBits(t, e, i, n) {
          let s = 16 === n.shareOfScreenNotMeasuredReason ? 16 : 0;
          return (
            s ||
              (((null == t ? void 0 : t.height) &&
                (null == t ? void 0 : t.width)) ||
                (s |= 4),
              ((null == e ? void 0 : e.height) &&
                (null == e ? void 0 : e.width)) ||
                (s |= 2),
              i || (s |= 1)),
            s
          );
        }
        isAdPercentageCriteriaPassed(t, e) {
          return (0, d.isLargeAd)(
            t,
            a.ViewabilityConstants.IAB.DisplayMinimalLargeAdArea,
            d.T.isMobile()
          )
            ? e >=
                a.ViewabilityConstants.IAB
                  .DisplayMinimalAdAreaPercentageForLargeSize
            : e >=
                a.ViewabilityConstants.IAB
                  .MinimalAdAreaPercentageForStandardSize;
        }
        getActionName() {
          return "ViewableShareOfScreenBL";
        }
      }
      e.ViewableShareOfScreenBL = l;
    },
    5196: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdAsset = void 0);
      e.AdAsset = class {
        constructor(t, e, i, n, s) {
          (this.id = t),
            (this.player = e),
            (this.adDuration = i),
            (this.executeDVClientCallback = s),
            (this.adSkippable = n);
        }
      };
    },
    6128: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.getSupportedIntegrationsBitwise = void 0);
      const n = i(4642),
        s = i(8844),
        r = i(882);
      e.getSupportedIntegrationsBitwise = (
        t = [n.VpaidWrapper, r.MraidObject, s.omidAdapter]
      ) => {
        let e = 0;
        return (
          t.forEach((t) => {
            t.isSupported() && (e |= Number(t.getIntegrationType()));
          }),
          e
        );
      };
    },
    8260: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdContainerInspector = void 0);
      const n = i(1906);
      e.AdContainerInspector = class {
        constructor(t) {
          this.container = t;
        }
        getContainer() {
          var t;
          return null !== (t = this.container) && void 0 !== t ? t : null;
        }
        getContainerId() {
          var t;
          return null === (t = this.container) || void 0 === t ? void 0 : t.id;
        }
        getDescendants(t = [], e = []) {
          return n.Utilities.convertToArray(
            this.getDescendantsAsCollection(t)
          ).filter((t) => !e.includes(t.tagName.toLowerCase()));
        }
        getDescendantsAsCollection(t) {
          var e, i;
          if ((null == t ? void 0 : t.length) > 0 && this.getContainerId()) {
            const i = t.join();
            return null === (e = this.container) || void 0 === e
              ? void 0
              : e.querySelectorAll(`#${this.getContainerId()} ${i}`);
          }
          return null === (i = this.container) || void 0 === i
            ? void 0
            : i.getElementsByTagName("*");
        }
        getDirectChildren(t = [], e = []) {
          return n.Utilities.convertToArray(
            this.getDirectChildrenAsCollection(t)
          ).filter((t) => !e.includes(t.tagName.toLowerCase()));
        }
        getDirectChildrenAsCollection(t) {
          var e;
          if ((null == t ? void 0 : t.length) > 0 && this.getContainerId()) {
            const e = t.join();
            return this.container.querySelectorAll(
              `#${this.getContainerId()} > ${e}`
            );
          }
          return null === (e = this.container) || void 0 === e
            ? void 0
            : e.children;
        }
        getMostPopularDirectChildElement(t = []) {
          const e = this.createDirectChildrenTable(t);
          return n.Utilities.getKeyWithHighestValue(e);
        }
        createDirectChildrenTable(t = []) {
          const e = this.getDirectChildren([], t).map((t) =>
            t.tagName.toLowerCase()
          );
          return n.Utilities.countBy(e);
        }
      };
    },
    3213: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdContainerInspectorFactory = void 0);
      const n = i(8260),
        s = i(8844);
      e.AdContainerInspectorFactory = class {
        constructor(t) {
          this.containerId = t;
        }
        createAdContainerInspector() {
          return new n.AdContainerInspector(this.getContainer());
        }
        getContainer() {
          return this.containerId
            ? (0, s.getElementById)(this.containerId)
            : null;
        }
      };
    },
    7149: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.DvBackwardCompatibilityClass = void 0);
      const n = i(1805),
        s = i(8844),
        r = i(1906),
        o = i(5473),
        a = i(7102),
        d = i(7065);
      e.DvBackwardCompatibilityClass = class {
        constructor() {
          (this.dvObjType = "dv"),
            (this.messages = {
              registerMsg(t, e) {
                n.L.sendMessage(e);
              },
              startSendingEvents(t, e) {},
            }),
            (this.domUtilities = {
              outer: this,
              addImage(t, e, i, n) {
                var o;
                const a = r.Utilities.getParamValue(t, "impid");
                if (
                  null != a &&
                  (null === (o = this.outer.tags) || void 0 === o
                    ? void 0
                    : o[a]) &&
                  "object" == typeof this.outer.tags[a].eventIdGenerator &&
                  "function" ==
                    typeof this.outer.tags[a].eventIdGenerator.getNext
                ) {
                  t += "&eoid=" + this.outer.tags[a].eventIdGenerator.getNext();
                }
                s.S.sendBeacon(t, i);
              },
              addScriptResource(t, e) {
                d.TcfClientStop.shouldSuppressUrl(t) ||
                  s.S.addScriptAsync(t, e);
              },
            }),
            (this.pubSub = a.Ct),
            (this.CommonData = {
              Scenario: s.O.getScenarioType(),
              BrowserId: s.BrowserDetector.getBrowserId(),
              BrowserIdFromUserAgent: s.BrowserDetector.getBrowserIdUserAgent(),
              BrowserVersion: s.BrowserDetector.getBrowserVersion(),
            }),
            (this.tags = {}),
            (this.sendBeacon = () => {});
        }
        resolveMacros(t, e) {
          return r.Utilities.resolveMacros(t, e);
        }
        registerEventCall(t, e, i, s) {
          (e.tagsrv = 1), n.L.registerEventCall(t, e, s, i);
        }
        createEventCallUrl(t, e, i = !1) {
          return n.L.createEventCallUrl(
            t,
            Object.assign(Object.assign({}, e), { tagsrv: 1 }),
            i
          );
        }
        getWorkingWindow() {
          return s.O.workingWindow();
        }
        getMraid() {
          return o.MraidWrapper.getMraid();
        }
      };
    },
    4298: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BeaconsAdaptor = void 0);
      const n = i(8844);
      e.BeaconsAdaptor = new (class {
        positionBeacons(t, e, i) {
          const s = n.O.getDefaultWindow(t).document,
            r = n.O.workingBody(s),
            o = n.S.getScrollData(r).left,
            a = n.S.getScrollData(r).top,
            {
              width: d,
              height: c,
              left: l,
              top: u,
            } = (0, n.getBoundingClientRect)(t),
            h = d / 2.414213562373095,
            v = c / 2.414213562373095,
            p = d / 1.4142135623730951,
            m = c / 1.4142135623730951;
          for (let t = 0; t < e.length; t++) {
            const n = Math.round(5 * Math.random()),
              s = e[t];
            switch (((s.left = l + o), (s.top = u + a), t)) {
              case 0:
                (s.left = -1e5), (s.top = -1e5);
                break;
              case 1:
                (s.left += n), (s.top += n);
                break;
              case 2:
                (s.left += d - i - n), (s.top += n);
                break;
              case 3:
                (s.left += n), (s.top += c - i - n);
                break;
              case 4:
                (s.left += d - i - n), (s.top += c - i - n);
                break;
              case 5:
                (s.left += d / 2 + n), (s.top += c / 2 + n);
                break;
              case 6:
                (s.left += (d - p) / 2 + n), (s.top += (c - m) / 2 + n);
                break;
              case 7:
                (s.left += (d - p) / 2 + p), (s.top += (c - m) / 2);
                break;
              case 8:
                (s.left += (d - p) / 2), (s.top += (c - m) / 2 + m + n);
                break;
              case 9:
                (s.left += (d - p) / 2 + p - n), (s.top += (c - m) / 2 + m - n);
                break;
              case 10:
                (s.left += (d - h) / 2 + n), (s.top += (c - v) / 2 + n);
                break;
              case 11:
                (s.left += (d - h) / 2 + h - n), (s.top += (c - v) / 2 + n);
                break;
              case 12:
                (s.left += (d - h) / 2 + n), (s.top += (c - v) / 2 + v - n);
                break;
              case 13:
                (s.left += (d - h) / 2 + h - n), (s.top += (c - v) / 2 + v - n);
            }
            t >= 5 && ((s.left -= i / 2), (s.top -= i / 2)),
              (s.style.left = s.left + "px"),
              (s.style.top = s.top + "px");
          }
        }
        getElementVisiblePercentageWithBeacons(t, e) {
          let i = 0,
            n = 0,
            s = 0,
            r = 0;
          for (let o = 1; o < t.length; o++) {
            if (e(t[o]))
              switch (o) {
                case 5:
                  r++;
                  break;
                case 1:
                case 2:
                case 3:
                case 4:
                  i++;
                  break;
                case 6:
                case 7:
                case 8:
                case 9:
                  n++;
                  break;
                case 10:
                case 11:
                case 12:
                case 13:
                  s++;
              }
          }
          return r || 2 != i || 2 != s
            ? r
              ? 4 == i
                ? 100
                : i >= 2 || 4 == n || (4 == s && i >= 1)
                ? 50
                : 4 == s && n >= 1
                ? 30
                : 0
              : 0
            : 30;
        }
      })();
    },
    214: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.omidCreativeTypeMapping =
          e.omidImpressionTypeMapping =
          e.OmidGeometryReasonLog =
          e.OmidEvents =
          e.dvIframeAttribute =
          e.CallbackPrefix =
            void 0);
      const n = i(4112);
      (e.CallbackPrefix = "dvCallback_"),
        (e.dvIframeAttribute = "data-dv-frm"),
        (e.OmidEvents = {
          [n.OmidAdEventType.SESSION_START]: 1,
          [n.OmidAdEventType.SESSION_ERROR]: 2,
          [n.OmidAdEventType.SESSION_FINISH]: 4,
          [n.OmidAdEventType.IMPRESSION]: 8,
          [n.OmidAdEventType.GEOMETRY_CHANGE]: 16,
          [n.OmidAdEventType.LOADED]: 32,
          [n.OmidAdEventType.START]: 64,
          [n.OmidAdEventType.FIRST_QUARTILE]: 128,
          [n.OmidAdEventType.MIDPOINT]: 256,
          [n.OmidAdEventType.THIRD_QUARTILE]: 512,
          [n.OmidAdEventType.COMPLETE]: 1024,
          [n.OmidAdEventType.PAUSE]: 2048,
          [n.OmidAdEventType.RESUME]: 4096,
          [n.OmidAdEventType.BUFFER_START]: 8192,
          [n.OmidAdEventType.SKIPPED]: 16384,
          [n.OmidAdEventType.VOLUME_CHANGE]: 32768,
          [n.OmidAdEventType.PLAYER_STATE_CHANGE]: 65536,
          [n.OmidAdEventType.AD_USER_INTERACTION]: 1 << 17,
        }),
        (e.OmidGeometryReasonLog = {
          [n.OmidReason.NOT_FOUND]: 1,
          [n.OmidReason.HIDDEN]: 2,
          [n.OmidReason.BACKGROUNDED]: 4,
          [n.OmidReason.OBSTRUCTED]: 8,
          [n.OmidReason.CLIPPED]: 16,
          [n.OmidReason.NO_OUTPUT_DEVICE]: 32,
          [n.OmidReason.VIEWPORT]: 64,
          [n.OmidReason.NO_WINDOW_FOCUS]: 128,
          [n.OmidReason.UNMEASURABLE]: 256,
          [n.OmidReason.PICTURE_IN_PICTURE]: 512,
          [n.OmidReason.DEVICE_LOCKED]: 1024,
        }),
        (e.omidImpressionTypeMapping = {
          [n.OmidImpressionType.UNKNOWN]: 0,
          [n.OmidImpressionType.UNSPECIFIED]: 1,
          [n.OmidImpressionType.LOADED]: 2,
          [n.OmidImpressionType.BEGIN_TO_RENDER]: 3,
          [n.OmidImpressionType.ONE_PIXEL]: 4,
          [n.OmidImpressionType.VIEWABLE]: 5,
          [n.OmidImpressionType.AUDIBLE]: 6,
          [n.OmidImpressionType.OTHER]: 7,
        }),
        (e.omidCreativeTypeMapping = {
          [n.OmidCreativeType.UNKNOWN]: 0,
          [n.OmidCreativeType.NATIVE_DISPLAY]: 1,
          [n.OmidCreativeType.HTML_DISPLAY]: 2,
          [n.OmidCreativeType.VIDEO]: 3,
          [n.OmidCreativeType.AUDIO]: 4,
        });
    },
    694: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.configureCoreDiagnosticsTransport = void 0);
      const n = i(1360),
        s = i(1805);
      e.configureCoreDiagnosticsTransport = () => {
        (0, n.configureDiagnosticsTransport)((t) => {
          s.L.sendMessage(t);
        });
      };
    },
    7533: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.DisplayGenXAdContainerInspectorFactory = void 0);
      const n = i(8844),
        s = i(3213);
      class r extends s.AdContainerInspectorFactory {
        constructor(t) {
          super(r.getContainerId(t));
        }
        static getContainerId(t) {
          return t ? n.A.getValueOfTagAttribute(t) : null;
        }
      }
      e.DisplayGenXAdContainerInspectorFactory = r;
    },
    2193: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.initializeDvDefinedProperties =
          e.dvDefineProperty =
          e.getTagUniqueKeyFromVisitScriptElement =
            void 0);
      const n = i(8844);
      function s() {
        var t;
        let e = "";
        if (!n.O.isDomlessEnvironment()) {
          const i = n.O.getCurrentScript();
          (null == i ? void 0 : i.id) &&
            (null === (t = null == i ? void 0 : i.src) || void 0 === t
              ? void 0
              : t.indexOf(n.A.getInitJsPath())) > -1 &&
            ([, e] = i.id.split("_"));
        }
        return e;
      }
      function r(t, e) {
        t.dvDefinedProps || (t.dvDefinedProps = {}),
          t.dvDefinedProps[e] ||
            ((t.dvDefinedProps[e] = !0),
            Object.defineProperty(t, e, {
              set(t) {
                this.value = t;
              },
              get() {
                const t = s();
                if (!t) return;
                const i = n.T.u().tagData[t];
                return null == i ? void 0 : i[e];
              },
            }));
      }
      (e.getTagUniqueKeyFromVisitScriptElement = s),
        (e.dvDefineProperty = r),
        (e.initializeDvDefinedProperties = function () {
          if (n.T.isRestrictedAccess() && n.O.getCurrentScript()) {
            const t = n.O.currentWindow();
            ["$frmId", "$uid"].forEach((e) => {
              r(t, e);
            });
          }
        });
    },
    6463: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.initialize = void 0);
      const n = i(1360),
        s = i(4112),
        r = i(1805),
        o = i(1906);
      e.initialize = (t) => {
        const e = t.setDvScript();
        null != e &&
          r.L.sendError(
            e.clientErrorType,
            e.error,
            e.messagePrefix,
            e.extraQueryParams
          ),
          t.setDvScriptUrl(),
          t.getDVScriptUrl() ||
            r.L.sendError(
              s.ClientErrorType.DvTagArrangementError,
              new Error("url is missing")
            ),
          ((t) => {
            try {
              t.setDVParam();
            } catch (t) {
              r.L.sendError(
                s.ClientErrorType.DvTagArrangementError,
                (0, o.toError)(t)
              );
            }
          })(t),
          ((t) => {
            t.getDiagnosticReportedParams().forEach(([t, e]) => {
              const i = e();
              null != i && n.DiagnosticParamsReporterSingleton.reportOnce(t, i);
            });
          })(t);
      };
    },
    9268: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.Encoding = e.EncodingClass = void 0);
      class i {
        ROT47(t) {
          return this.ROTn(
            t,
            "!\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"
          );
        }
        sha1hash(t) {
          if (!t) return "";
          const e = [1518500249, 1859775393, 2400959708, 3395469782],
            i = (t += String.fromCharCode(128)).length / 4 + 2,
            n = Math.ceil(i / 16),
            s = new Array(n),
            r = new Array(80);
          let o,
            a,
            d,
            c,
            l,
            u = 1732584193,
            h = 4023233417,
            v = 2562383102,
            p = 271733878,
            m = 3285377520;
          for (let e = 0; e < n; e++) {
            s[e] = new Array(16);
            for (let i = 0; i < 16; i++)
              s[e][i] =
                (t.charCodeAt(64 * e + 4 * i) << 24) |
                (t.charCodeAt(64 * e + 4 * i + 1) << 16) |
                (t.charCodeAt(64 * e + 4 * i + 2) << 8) |
                t.charCodeAt(64 * e + 4 * i + 3);
          }
          (s[n - 1][14] = (8 * (t.length - 1)) / Math.pow(2, 32)),
            (s[n - 1][14] = Math.floor(s[n - 1][14])),
            (s[n - 1][15] = (8 * (t.length - 1)) & 4294967295);
          for (let t = 0; t < n; t++) {
            for (let e = 0; e < 16; e++) r[e] = s[t][e];
            for (let t = 16; t < 80; t++)
              r[t] = this.ROTL(r[t - 3] ^ r[t - 8] ^ r[t - 14] ^ r[t - 16], 1);
            (o = u), (a = h), (d = v), (c = p), (l = m);
            for (let t = 0; t < 80; t++) {
              const i = Math.floor(t / 20),
                n =
                  (this.ROTL(o, 5) + this.f(i, a, d, c) + l + e[i] + r[t]) &
                  4294967295;
              (l = c), (c = d), (d = this.ROTL(a, 30)), (a = o), (o = n);
            }
            (u = (u + o) & 4294967295),
              (h = (h + a) & 4294967295),
              (v = (v + d) & 4294967295),
              (p = (p + c) & 4294967295),
              (m = (m + l) & 4294967295);
          }
          return (
            this.toHexStr(u) +
            this.toHexStr(h) +
            this.toHexStr(v) +
            this.toHexStr(p) +
            this.toHexStr(m)
          );
        }
        f(t, e, i, n) {
          switch (t) {
            case 0:
              return (e & i) ^ (~e & n);
            case 1:
            case 3:
              return e ^ i ^ n;
            case 2:
              return (e & i) ^ (e & n) ^ (i & n);
          }
        }
        ROTn(t, e) {
          let i,
            n,
            s,
            r = String();
          const o = e.length;
          for (i = 0; i < t.length; i++)
            (s = t.charAt(i)),
              (n = e.indexOf(s)),
              n >= 0 && (s = e.charAt((n + o / 2) % o)),
              (r += s);
          return r;
        }
        ROTL(t, e) {
          return (t << e) | (t >>> (32 - e));
        }
        toHexStr(t) {
          let e,
            i = "";
          for (let n = 7; n >= 0; n--)
            (e = (t >>> (4 * n)) & 15), (i += e.toString(16));
          return i;
        }
      }
      (e.EncodingClass = i), (e.Encoding = new i());
    },
    2125: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.B = void 0),
        (e.B = {
          UNKNOWN: 0,
          CUSTOM: 1,
          DFA: 2,
          IN_APP_DEFAULT: 4,
          MARKED: 8,
          NEAREST_AD: 16,
          DISPLAY_IFRAME_FALLBACK: 32,
          VPAID: 64,
          OMID: 128,
          DisplayGenX: 256,
          BY_REFERENCE: 512,
          GAM: 1024,
        });
    },
    7102: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.jt = e.Ct = e.k = e.Vt = e.DvEvents = void 0);
      const n = i(1906),
        s = i(8844),
        r = i(1805),
        o = i(4112);
      e.DvEvents = {
        impressionServed: "ImpressionServed",
        adSelected: "0",
        adDestroy: "1",
        adCandidateApproved: "2",
        W: "4",
        reportData: "5",
        viewabilityIntervalData: "6",
        boundariesViewabilityIntervalData: "7",
        exposureData: "8",
        adCandidateLocated: "10",
        omidClickData: "11",
        focusData: "12",
        strictFocusData: "13",
        abandonData: "14",
        unloadData: "15",
        adSizeData: "16",
        firstClickOnAdElementData: "17",
        firstHoverData: "18",
        pauseData: "19",
        resumeData: "20",
        skipData: "21",
        firstTouchData: "22",
        volumeData: "23",
        stopData: "24",
        firstFocusIntoAdElementData: "25",
        adImpressionData: "26",
        adVideoMidpointData: "27",
        adVideoStartData: "28",
        adVideoFirstQuartileData: "29",
        adVideoThirdQuartileData: "30",
        adVideoCompleteData: "31",
        rtsEventData: "33",
        omidAdSizeData: "34",
        videoLoadedData: "35",
        videoStartPlaying: "36",
        mraidDefaultStateData: "37",
        adRenderedData: "39",
        globalUnloadData: "40",
        globalKeyPressData: "42",
        globalMouseMoveData: "43",
        globalOrientationChangeData: "45",
        keyPressData: "46",
        mouseMoveData: "47",
        orientationChangePortraitData: "49",
        orientationchangeLandscapeData: "50",
        skippableData: "51",
        adSizeChangedData: "52",
        pageHideEventPersisted: "53",
        pageHideEventNonPersisted: "54",
        performanceData: "55",
        performanceLongTasks: "56",
        performanceTaskTiming: "57",
        tempFirstKeyPressData: "59",
        keyPressMeasured: "60",
        tempFirstMouseMoveData: "61",
        mouseMoveMeasured: "62",
        tempOrientationChangePortraitData: "63",
        tempOrientationChangeLandscapeData: "64",
        orientationChangeMeasured: "65",
        adSizeMeasured: "66",
        clickMeasured: "68",
        beginToRender: "70",
        beginToPlay: "71",
        omidInvitationAcceptData: "73",
        omidCustomInteractionData: "74",
        firstClickOnDescendantIframe: "75",
        firstTouchOnDescendantIframe: "76",
        firstClickOnDeepDescendantIframe: "77",
        firstTouchOnDeepDescendantIframe: "78",
        secondaryViewabilityIntervalData: "79",
        secondaryExposureData: "80",
      };
      const a = new Set([
          e.DvEvents.impressionServed,
          e.DvEvents.adSelected,
          e.DvEvents.adCandidateApproved,
          e.DvEvents.adCandidateLocated,
          e.DvEvents.adDestroy,
          e.DvEvents.adRenderedData,
          e.DvEvents.adImpressionData,
          e.DvEvents.beginToRender,
          e.DvEvents.beginToPlay,
          e.DvEvents.adVideoStartData,
          e.DvEvents.adVideoFirstQuartileData,
          e.DvEvents.adVideoMidpointData,
          e.DvEvents.adVideoThirdQuartileData,
          e.DvEvents.adVideoCompleteData,
          e.DvEvents.videoLoadedData,
          e.DvEvents.videoStartPlaying,
          e.DvEvents.reportData,
          e.DvEvents.rtsEventData,
          e.DvEvents.firstClickOnAdElementData,
          e.DvEvents.firstTouchData,
          e.DvEvents.firstHoverData,
          e.DvEvents.firstFocusIntoAdElementData,
          e.DvEvents.firstClickOnDescendantIframe,
          e.DvEvents.firstTouchOnDescendantIframe,
          e.DvEvents.firstClickOnDeepDescendantIframe,
          e.DvEvents.firstTouchOnDeepDescendantIframe,
          e.DvEvents.viewabilityIntervalData,
          e.DvEvents.boundariesViewabilityIntervalData,
          e.DvEvents.exposureData,
          e.DvEvents.secondaryViewabilityIntervalData,
          e.DvEvents.secondaryExposureData,
        ]),
        d = new Map([
          [e.DvEvents.viewabilityIntervalData, 20],
          [e.DvEvents.boundariesViewabilityIntervalData, 20],
          [e.DvEvents.exposureData, 20],
          [e.DvEvents.secondaryViewabilityIntervalData, 20],
          [e.DvEvents.secondaryExposureData, 20],
        ]);
      class c {
        constructor() {
          (this.renderedImpressions = {}),
            (this.markRenderedImpressions = {}),
            (this.frameIds = {}),
            (this.subscribersCallbacks = {}),
            (this.previousEvents = {}),
            (this.preRenderEvents = {}),
            (this.subscriptionId = 1),
            (this.dispatchedCount = {}),
            (this.eventStatusTable = {}),
            Object.values(e.DvEvents).forEach((t) => {
              this.eventStatusTable[t] = 0;
            }),
            (this.frameId = s.T.getFrameId(s.O.currentWindow())),
            (this.previousEventsCapacity = 1e3),
            this.excludeFrameId(this.frameId);
        }
        excludeFrameId(t) {
          this.frameIds[t] ||
            ((this.frameIds[t] = !0),
            this.addEventListener(
              e.DvEvents.adRenderedData,
              this.updateRenderedAd.bind(this),
              "excludeFrame",
              t
            ));
        }
        addEventListener(t, e, i = "", n = this.frameId) {
          const s = this.addEventsListener({ [t]: e }, i, n);
          if (s && s.length > 0) return s[0];
        }
        addEventsListener(t, e = "", i = this.frameId) {
          const n = this.toWrappedHandlers(t);
          return (
            this.fireMultiplePreviousEvents(n, i),
            Object.keys(n).map((t) => this.subscribe(t, i, e, n[t]))
          );
        }
        removeEventListener(t, e = this.frameId) {
          this.subscribersCallbacks[e] &&
            Object.keys(this.subscribersCallbacks[e]).forEach((i) => {
              this.subscribersCallbacks[e][i] = this.subscribersCallbacks[e][
                i
              ].filter((e) => e.subscriptionId != t);
            });
        }
        removeEventsListener(t, e = this.frameId) {
          t.forEach((t) => {
            this.removeEventListener(t, e);
          });
        }
        dispatchEvent(t, e) {
          0 == this.eventStatusTable[t] && (this.eventStatusTable[t] = 1),
            2 == this.eventStatusTable[t] && (this.eventStatusTable[t] = 3),
            (this.dispatchedCount[t] = this.dispatchedCount[t]
              ? this.dispatchedCount[t] + 1
              : 1),
            this.publishEvents(this.frameId, t, e);
        }
        subscribe(t, e, i, n) {
          var s, r;
          if ("function" == typeof n && void 0 !== t && "" != t)
            return (
              0 == this.eventStatusTable[t] && (this.eventStatusTable[t] = 2),
              1 == this.eventStatusTable[t] && (this.eventStatusTable[t] = 3),
              this.subscriptionId++,
              (s = this.subscribersCallbacks)[e] || (s[e] = {}),
              (r = this.subscribersCallbacks[e])[t] || (r[t] = []),
              this.subscribersCallbacks[e][t].push({
                func: n,
                subscriptionId: this.subscriptionId,
                actionName: i,
              }),
              this.subscriptionId
            );
        }
        publish(t, e, i) {
          t &&
            e &&
            (this.frameIds[e] || this.renderedImpressions[e]
              ? (this.renderedImpressions[e] &&
                  !this.markRenderedImpressions[e] &&
                  (this.markRenderedImpressions[e] = !0),
                this.publishHistoryRtnEvent(e),
                this.publishEvents(e, t, i))
              : this.storeToPreRenderEvent(e, t, i));
        }
        publishHistoryRtnEvent(t) {
          const e = this.preRenderEvents[t];
          e &&
            Object.keys(e).forEach((i) => {
              e[i].forEach((e) => {
                this.publishEvents(t, i, e);
              });
            }),
            (this.preRenderEvents[t] = {});
        }
        getTopDispatchedEvents(t = Object.keys(this.dispatchedCount).length) {
          return Object.entries(this.dispatchedCount)
            .sort((t, e) => e[1] - t[1])
            .slice(0, t);
        }
        getDispatchedByStatus(t) {
          return Object.entries(this.eventStatusTable)
            .filter(([e, i]) => i == t)
            .map(([t, e]) => t);
        }
        updateRenderedAd(t) {
          const { uid: e } = t;
          e &&
            ((this.renderedImpressions[e] = !0),
            this.publishHistoryRtnEvent(e));
        }
        publishEvents(t, e, i) {
          var n;
          this.storeToPreviousEvents(t, e, i),
            (null === (n = this.subscribersCallbacks[t]) || void 0 === n
              ? void 0
              : n[e]) &&
              this.subscribersCallbacks[t][e].forEach((n) => {
                this.runSafely(n.func, i, t, e, n.actionName);
              });
        }
        toWrappedHandlers(t) {
          const e = {};
          return (
            Object.keys(t).forEach((i) => {
              const n = t[i];
              i &&
                "function" == typeof n &&
                (e[i] = (t, e) => {
                  n(e);
                });
            }),
            e
          );
        }
        storeToPreRenderEvent(t, e, i) {
          var n, s;
          (n = this.preRenderEvents)[t] || (n[t] = {}),
            (s = this.preRenderEvents[t])[e] || (s[e] = []),
            this.preRenderEvents[t][e].push(i);
        }
        storeToPreviousEvents(t, e, i) {
          var n, s, r;
          if (!a.has(e)) return;
          if (!this.frameIds[t]) return;
          (s = this.previousEvents)[t] || (s[t] = {});
          const o = (r = this.previousEvents[t])[e] || (r[e] = []),
            c =
              null !== (n = d.get(e)) && void 0 !== n
                ? n
                : this.previousEventsCapacity;
          o.length >= c && o.shift(), o.push(i);
        }
        fireMultiplePreviousEvents(t, e) {
          if (!this.previousEvents[e]) return;
          const i = Object.keys(t)
            .reduce((i, n) => {
              const s = t[n];
              return (
                (this.previousEvents[e][n] || []).forEach((t) =>
                  i.push({ callback: s, data: t })
                ),
                i
              );
            }, [])
            .sort((t, e) => t.data.updateTime - e.data.updateTime);
          for (const t of i) this.runSafely(t.callback, t.data, e);
        }
        runSafely(t, e, i, n = "", s = "") {
          try {
            t(i, e);
          } catch (t) {
            r.L.sendError(
              o.ClientErrorType.MeasurementError,
              t,
              `EBus ${n} ${s}`
            );
          }
        }
      }
      (e.Vt = c),
        (e.k = (0, n.uninitializedServiceGuard)("EventBus")),
        (e.Ct = (0, n.uninitializedServiceGuard)("EventBusGlobal")),
        (e.jt = function () {
          (e.k = new c()), (e.Ct = $dv.pubSub ? $dv.pubSub : new c());
        });
    },
    1008: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.experiments =
          e.tcfClientStopExperiment =
          e.TcfClientStopExperiment =
          e.omidConstructTimeParamMismatchPayloadExperiment =
          e.OmidConstructTimeParamMismatchPayloadExperiment =
          e.randomizeOmidVendorKeyExperiment =
          e.RandomizeOmidVendorKeyExperiment =
          e.tagObservabilityTelemetryExperiment =
          e.TagObservabilityTelemetryExperiment =
          e.cm360DedupDiagnosticExperiment =
          e.descendantIframeClickHandlersExperiment =
          e.DescendantIframeClickHandlersExperiment =
          e.experimentHooks =
            void 0);
      const n = i(1360),
        s = i(8844),
        r = i(1805),
        o = i(4112),
        a = i(1882);
      e.experimentHooks = {
        reportError: (t) => {
          r.L.sendError(o.ClientErrorType.UnexpectedError, t);
        },
      };
      class d extends a.BooleanFeatureFlag {
        constructor() {
          super(
            "DescendantIframeClickHandlers",
            [
              {
                percentage: 100,
                optionName: a.BooleanFeatureOptionId.DISABLED,
              },
            ],
            n.DiagnosticParams.descendantIframeClickHandlers,
            () =>
              s.A.getParamValue(
                n.DiagnosticParams.descendantIframeClickHandlers
              ),
            e.experimentHooks
          );
        }
      }
      (e.DescendantIframeClickHandlersExperiment = d),
        (e.descendantIframeClickHandlersExperiment = new d());
      class c extends a.BooleanFeatureFlag {
        constructor() {
          super(
            "Cm360DedupDiagnostic",
            [
              { percentage: 10, optionName: a.BooleanFeatureOptionId.ENABLED },
              { percentage: 90, optionName: a.BooleanFeatureOptionId.DISABLED },
            ],
            n.DiagnosticParams.cm360DedupDiagnosticExperiment,
            () => s.A.getParamValue("ee_cmdd"),
            e.experimentHooks
          );
        }
      }
      e.cm360DedupDiagnosticExperiment = new c();
      class l extends a.BooleanFeatureFlag {
        constructor() {
          super(
            "TagObservabilityTelemetry",
            [
              {
                percentage: 0.01,
                optionName: a.BooleanFeatureOptionId.ENABLED,
              },
              {
                percentage: 99.99,
                optionName: a.BooleanFeatureOptionId.DISABLED,
              },
            ],
            n.DiagnosticParams.tagObservabilityTelemetryExperiment,
            () =>
              s.A.getParamValue(
                n.DiagnosticParams.tagObservabilityTelemetryExperiment
              ),
            e.experimentHooks
          );
        }
      }
      (e.TagObservabilityTelemetryExperiment = l),
        (e.tagObservabilityTelemetryExperiment = new l());
      class u extends a.BooleanFeatureFlag {
        constructor() {
          super(
            "RandomizeOmidVendorKey",
            [
              { percentage: 10, optionName: a.BooleanFeatureOptionId.ENABLED },
              { percentage: 90, optionName: a.BooleanFeatureOptionId.DISABLED },
            ],
            n.DiagnosticParams.randomizeOmidVendorKeyExperiment,
            () =>
              s.A.getParamValue(
                n.DiagnosticParams.randomizeOmidVendorKeyExperiment
              ),
            e.experimentHooks
          );
        }
      }
      (e.RandomizeOmidVendorKeyExperiment = u),
        (e.randomizeOmidVendorKeyExperiment = new u());
      class h extends a.BooleanFeatureFlag {
        constructor() {
          super(
            "OmidConstructTimeParamMismatchPayload",
            [
              { percentage: 0.1, optionName: a.BooleanFeatureOptionId.ENABLED },
              {
                percentage: 99.9,
                optionName: a.BooleanFeatureOptionId.DISABLED,
              },
            ],
            n.DiagnosticParams.omidConstructTimeParamMismatchPayloadExperiment,
            () =>
              s.A.getParamValue(
                n.DiagnosticParams
                  .omidConstructTimeParamMismatchPayloadExperiment
              ),
            e.experimentHooks
          );
        }
        reportDiagnosticParam() {}
      }
      (e.OmidConstructTimeParamMismatchPayloadExperiment = h),
        (e.omidConstructTimeParamMismatchPayloadExperiment = new h());
      class v extends a.BooleanFeatureFlag {
        constructor() {
          super(
            "TcfClientStop",
            [
              { percentage: 0, optionName: a.BooleanFeatureOptionId.ENABLED },
              {
                percentage: 100,
                optionName: a.BooleanFeatureOptionId.DISABLED,
              },
            ],
            void 0,
            () => null,
            e.experimentHooks
          );
        }
        getRolloutPercentage() {
          return this.distribution[0].percentage;
        }
      }
      (e.TcfClientStopExperiment = v),
        (e.tcfClientStopExperiment = new v()),
        (e.experiments = [
          e.descendantIframeClickHandlersExperiment,
          e.cm360DedupDiagnosticExperiment,
          e.tagObservabilityTelemetryExperiment,
          e.randomizeOmidVendorKeyExperiment,
          e.omidConstructTimeParamMismatchPayloadExperiment,
          e.tcfClientStopExperiment,
        ]);
    },
    5069: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.initializeExperiments = void 0);
      const n = i(1008);
      let s = !1;
      e.initializeExperiments = (t = !1) => {
        (s && !t) ||
          ((s = !0),
          n.experiments.forEach((t) => {
            t.init();
          }));
      };
    },
    7982: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.detectImpressionIdMisalignment = void 0);
      const n = i(8844),
        s = i(1805),
        r = i(4112),
        o = i(1360);
      e.detectImpressionIdMisalignment = function (t) {
        const e = n.T.getSavedImpressionId();
        ((t, e) => !!t && t !== e)(e, t) &&
          s.L.sendError(r.ClientErrorType.ImpressionIdMisalignment, null, "", {
            [(0, o.getDiagnosticQueryParamName)(o.DiagnosticParams.Rt)]: e,
            [(0, o.getDiagnosticQueryParamName)(
              o.DiagnosticParams.misalignmentImpressionId
            )]: t,
          });
      };
    },
    3046: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.InmobiWrapper = e.InmobiWrapperClass = void 0);
      const n = i(8844);
      class s {
        isSupported() {
          if (
            void 0 !== n.O.workingWindow().inmobi &&
            void 0 !== n.O.workingWindow().inmobi.InMobiVideoEventsBuffer
          )
            return (this.inmobiApiObj = n.O.workingWindow().inmobi), !0;
        }
        addEventListenerWithHistory(t) {
          this.isSupported() &&
            this.inmobiApiObj.InMobiVideoEventsBuffer.addVideoEventListener(t);
        }
      }
      (e.InmobiWrapperClass = s), (e.InmobiWrapper = new s());
    },
    1805: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.L = e.xt = e.DEFAULT_EVENT_CONSOLIDATION_TIMEOUT = void 0);
      const n = i(8844),
        s = i(4112),
        r = i(1906),
        o = i(4112),
        a = i(1360),
        d = i(5944),
        c = i(6128),
        l = i(7065);
      e.DEFAULT_EVENT_CONSOLIDATION_TIMEOUT = 3e3;
      class u {
        constructor() {
          (this.waitingMessages = {}),
            (this.reportedErrors = {}),
            (this.messageDataObject = {}),
            (this.START_INTERVAL_INITIAL_VALUE = 10),
            (this.isFirstEventFired = !1),
            (this.isOmidSupported = () => !1);
        }
        setOmidSupportCheck(t) {
          this.isOmidSupported = t;
        }
        sendMessage(t, e = { isImportantMessage: !1, noConsolidation: !1 }) {
          if (l.TcfClientStop.isExecutionStopped()) return;
          const i = {
            isImportantMessage:
              "boolean" == typeof e ? e : e.isImportantMessage,
            noConsolidation: "boolean" != typeof e && e.noConsolidation,
          };
          this.impressionId ||
            (this.impressionId = n.T.getImpressionId(n.O.currentWindow())),
            r.Utilities.extend(t, this.waitingMessages),
            this.isImportantMessage ||
              (this.isImportantMessage = i.isImportantMessage),
            i.noConsolidation
              ? this.sendWaitingMessages(!1)
              : this.sendWaitingMessages();
        }
        appendTagUniqueKey(t) {
          const e = n.T.getTagUniqueKey();
          e && (t.dvp_tukv = e);
        }
        sendMeasurementError(t, e, i = null) {
          const s = {
            ishems: r.Utilities.getTimeDiff(),
            napr: e,
            cerrt: t.id,
            jsver: r.Utilities.getVersion(),
            tgjsver: n.T.getDvtpScriptVersion(),
          };
          r.Utilities.extend(i, s), this.sendMessage(s);
        }
        appendIsOmid(t) {
          this.isOmidSupported() && (t.dvp_iomd = 1);
        }
        sendErrorSignal(t, e, i = null) {
          const o = n.A.getServerPrefix(),
            d = n.A.getErrorPath(),
            l = {
              ctx: 818052,
              cmp: 1619415,
              jsver: r.Utilities.getVersion(),
              tgjsver: n.T.getDvtpScriptVersion(),
              napr: e,
              cerrt: t.id,
            };
          t.isLostImpression && (l.dvp_isLostImp = 1);
          try {
            (l[s.TPSDataMapping.trafficScenarioType] = n.O.getScenarioType()),
              (l[s.TPSDataMapping.tagtype] = n.A.getTagType()),
              (l[s.TPSDataMapping.tagVersion] = n.A.getTagVersion()),
              (l[s.TPSDataMapping.supportedIntegrations] = (0,
              c.getSupportedIntegrationsBitwise)()),
              (l[
                (0, a.getDiagnosticQueryParamName)(
                  a.DiagnosticParams.adIdentityAdServer
                )
              ] = n.A.getAdServerId());
          } catch (t) {}
          (l[s.TPSDataMapping.flavor] = "1"),
            this.appendIsOmid(l),
            this.appendTagUniqueKey(l),
            r.Utilities.extend(this.getClientDataString(), l),
            r.Utilities.extend(this.getExperimentIndicators(), l),
            r.Utilities.extend(i, l);
          const u = `${o}${d}?${n.A.getGDPRAndGDPRConsentQueryStringPart()}${r.Utilities.serializeObjectToQueryString(
            l,
            !1
          )}`;
          n.S.sendBeacon(u.trim(), !0),
            (0, a.sendS2SPartnerTelemetryEvent)({ type: "RuntimeError" });
        }
        getClientDataString() {
          const t = n.A.getClientData();
          return {
            ee_dp_ctx: t.ctx,
            ee_dp_cmp: t.cmp,
            ee_dp_sid: t.sid,
            ee_dp_plc: t.plc,
          };
        }
        getExperimentIndicators() {
          const t = n.T.getVisitFlowType();
          return {
            [(0, a.getDiagnosticQueryParamName)(
              a.DiagnosticParams.visitJsonExperimentGroup
            )]: t,
          };
        }
        sendError(t, e = null, i = "", n = {}) {
          if (
            !l.TcfClientStop.isExecutionStopped() &&
            !Object.prototype.hasOwnProperty.call(this.reportedErrors, t.id)
          ) {
            this.reportedErrors[t.id] = 1;
            const s =
                t.isLostImpression ||
                r.Utilities.isPercentageCriteriaPassed(10),
              a = this.getJsErrorString(t, e, i, s);
            t.isLostImpression || t == o.ClientErrorType.FailedToSendEvent
              ? this.sendErrorSignal(t, a, n)
              : this.sendMeasurementError(t, a, n);
          }
        }
        registerEventCall(t, e, i = !0, s) {
          l.TcfClientStop.shouldSuppress(t) ||
            r.Utilities.getTimeDiff() > 12e5 ||
            ((s = this.getEventConsolidationTimeout(s)),
            (e.eoid = d.EventIdGeneratorAdaptor.getNext()),
            this.consolidateMessageData(t, e),
            this.afterUnload || !i || isNaN(s)
              ? this.sendDataToServer(t)
              : n.S.getTaskManager().setTimeout(() => {
                  this.sendDataToServer(t);
                }, s));
        }
        getEventConsolidationTimeout(t) {
          const i = t || e.DEFAULT_EVENT_CONSOLIDATION_TIMEOUT;
          return this.restrictTimeoutMax
            ? Math.min(i, this.restrictTimeoutMax)
            : i;
        }
        sendWaitingMessages(t = !0, e) {
          r.Utilities.isEmpty(this.waitingMessages) ||
            (this.impressionId
              ? ((!this.isImportantMessage &&
                  n.T.getFireOnlyImportantEvents()) ||
                  this.registerEventCall(
                    this.impressionId,
                    this.waitingMessages,
                    t,
                    e
                  ),
                (this.isImportantMessage = !1),
                (this.waitingMessages = {}))
              : r.Utilities.getVisitTimeDiff() > 4e3 &&
                this.sendError(
                  o.ClientErrorType.FailedToSendEvent,
                  void 0,
                  "ImpressionID is missing"
                ));
        }
        discardQueuedData() {
          (this.waitingMessages = {}),
            (this.messageDataObject = {}),
            (this.isImportantMessage = !1);
        }
        firePreviousEvents() {
          this.impressionId = n.T.getImpressionId(n.O.currentWindow());
          const t = this.getIntervalAndSetMaxTimeout();
          this.sendWaitingMessages(!0, t);
        }
        getIntervalAndSetMaxTimeout(t = this.START_INTERVAL_INITIAL_VALUE) {
          return (
            !n.T.isMobile() ||
              (n.BrowserDetector.getBrowserId() != o.Browser.Safari &&
                n.BrowserDetector.getBrowserId() != o.Browser.SafariWebView) ||
              (this.restrictTimeoutMax = t = 1e3),
            this.isOmidSupported() && (this.restrictTimeoutMax = 500),
            t
          );
        }
        consolidateMessageData(t, e) {
          var i;
          (i = this.messageDataObject)[t] || (i[t] = {}),
            r.Utilities.extend(e, this.messageDataObject[t]);
        }
        createEventCallUrl(t, e, i = !1) {
          void 0 === this.doubleTagImp &&
            (this.doubleTagImp = n.T.getDoubleTagImpressionID() || "");
          const s = this.doubleTagImp ? "dup=" + this.doubleTagImp + "&" : "";
          return (
            n.A.resolveEventUrlPrefix(t) +
            `?impid=${t}&` +
            s +
            "flavor=1&" +
            n.A.getGDPRAndGDPRConsentQueryStringPart() +
            r.Utilities.serializeObjectToQueryString(e, i)
          );
        }
        sendDataToServer(t) {
          try {
            const e = this.messageDataObject[t];
            if (!r.Utilities.isEmpty(e)) {
              let e = this.createEventCallUrl(t, this.messageDataObject[t], !0);
              this.isFirstEventFired ||
                ((e += `&${s.TPSDataMapping.timeToFirstUpdateReportMs}=${
                  r.Utilities.getCurrentTime() - r.Utilities.getScriptLoadedMS()
                }`),
                (this.isFirstEventFired = !0)),
                this.afterUnload &&
                  (e += `&${s.TPSDataMapping.totalMeasurementExecTime}=${
                    r.Utilities.getCurrentTime() -
                    r.Utilities.getScriptLoadedMS()
                  }`),
                n.S.sendBeacon(e),
                (this.messageDataObject[t] = null);
            }
          } catch (t) {}
        }
        getJsErrorString(t, e = null, i = "", n = !1) {
          let s;
          let r = t.message + "__";
          i && i.length > 0 && (r += i + "__"),
            e &&
              ((r += ": " + (e.message || "")),
              n &&
                e.stack &&
                (r += e.stack
                  .split("\n")
                  .map((t) => t.replace(/\(.*\)/, ""))
                  .join(""))),
            (r = r
              .replace(/\n/g, "")
              .replace(/\r/g, "")
              .replace(/\t/g, "")
              .replace(/\|/g, ""));
          try {
            (r = r.slice(0, 400)), (s = encodeURIComponent(r));
          } catch (t) {}
          return s;
        }
        handleUnload() {
          (this.afterUnload = !0),
            Object.keys(this.messageDataObject).forEach((t, e) => {
              this.sendDataToServer(t);
            });
        }
      }
      (e.xt = u), (e.L = new u());
    },
    8624: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.initialize = void 0);
      const n = i(7102),
        s = i(8844);
      e.initialize = (t) => {
        t.setOmidSupportCheck(() => s.omidAdapter.isSupported()),
          n.k.addEventListener(
            n.DvEvents.impressionServed,
            () => {
              t.firePreviousEvents();
            },
            "MessageHandler"
          ),
          n.k.addEventListener(
            n.DvEvents.globalUnloadData,
            t.handleUnload.bind(t)
          );
      };
    },
    882: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.MraidObject = void 0);
      e.MraidObject = new (class {
        isSupported() {
          return !!this.mraidObject;
        }
        get() {
          return this.mraidObject;
        }
        set(t) {
          this.mraidObject = t;
        }
        getIntegrationType() {
          return 2;
        }
      })();
    },
    5473: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.createMraidWrapper = e.MraidWrapper = e.MraidWrapperClass = void 0);
      const n = i(8844),
        s = i(1805),
        r = i(7102),
        o = i(3283),
        a = i(1906),
        d = i(882);
      class c {
        constructor() {
          (this.isMraidReady = !1),
            (this.readyState = !1),
            (this.maxIterations = 20),
            (this.errorReported = !1);
          const t = n.O.workingWindow();
          this.setMraid(t), d.MraidObject.get() && this.readyCheck();
        }
        getReadyState() {
          return this.readyState;
        }
        isOperaMedia() {
          return "AdMarvel" == this.runMraidFunctionSafely("getVendor");
        }
        isAdColony() {
          const t = this.runMraidFunctionSafely("getVendor");
          return t && "string" == typeof t && "adcolony" == t.toLowerCase();
        }
        getIsMraidReady() {
          return this.isMraidReady || this.updateIsMraidReady();
        }
        isSupported() {
          return !!d.MraidObject.isSupported();
        }
        runMraidFunctionSafely(t) {
          try {
            return d.MraidObject.get()[t]();
          } catch (t) {}
        }
        runMraidRegisterSafely(t, e) {
          try {
            (e.toString = () => "func" + n.RandomUtils.getRandom16()),
              d.MraidObject.get().addEventListener(t, e);
          } catch (t) {}
        }
        setMraid(t) {
          d.MraidObject.set(n.O.objectLookup(t, "mraid", this.maxIterations));
        }
        reportMraidLookup(t) {
          n.O.isDomlessEnvironment() ||
            (s.L.sendMessage({ dvp_mrdms: a.Utilities.getCurrentTime() }),
            d.MraidObject.get() ||
              null == n.O.workingDocument().readyState ||
              "complete" == n.O.workingDocument().readyState ||
              n.S.addEventListener(
                "load",
                (e) => {
                  n.O.objectLookup(t, "mraid", this.maxIterations) &&
                    s.L.sendMessage({ dvp_mrdfnd: 1 });
                },
                t
              ));
        }
        getMraid() {
          return d.MraidObject.get();
        }
        reportEnvironmentDetails() {
          this.mraidEnvObjectCache ||
            (this.mraidEnvObjectCache = n.O.objectLookup(
              n.O.currentWindow(),
              "MRAID_ENV",
              this.maxIterations
            )),
            this.mraidEnvObjectCache &&
              s.L.sendMessage({
                dvp_mrdsdk: this.mraidEnvObjectCache.sdk,
                dvp_mrdsdkv: this.mraidEnvObjectCache.sdkVersion,
                dvp_mrdv: this.mraidEnvObjectCache.version,
                dvp_mrdapid: this.mraidEnvObjectCache.appId,
              });
        }
        getAdViewablePercentage() {
          const t = this.runMraidFunctionSafely("isViewable");
          return null == t ? null : t ? 100 : 0;
        }
        readyCheck() {
          "loading" == this.runMraidFunctionSafely("getState")
            ? this.runMraidRegisterSafely(
                "ready",
                this.readyCallback.bind(this)
              )
            : this.readyCallback(),
            this.runMraidRegisterSafely(
              "stateChange",
              this.updateIsMraidReady.bind(this)
            );
        }
        setReadyState() {
          (this.readyState = !0),
            r.k.dispatchEvent(
              r.DvEvents.mraidDefaultStateData,
              new o.EventData()
            ),
            s.L.sendMessage({ dvp_mrstt: 1 });
        }
        readyCallback() {
          this.setReadyState(),
            this.updateIsMraidReady(),
            this.registerToMraidErrorEvent();
        }
        updateIsMraidReady() {
          if (this.isMraidReady) return this.isMraidReady;
          const t = this.runMraidFunctionSafely("isViewable");
          return (
            ("default" == this.runMraidFunctionSafely("getState") || t) &&
              ((this.isMraidReady = !0),
              this.readyState || this.setReadyState()),
            this.isMraidReady
          );
        }
        registerToMraidErrorEvent() {
          this.runMraidRegisterSafely("error", (t, e) => {
            this.errorReported ||
              (s.L.sendMessage({
                dvp_mrwer: "MraidWrapper:" + e + ":" + t.substring(0, 60),
              }),
              (this.errorReported = !0));
          });
        }
      }
      (e.MraidWrapperClass = c),
        (e.MraidWrapper = (0, a.uninitializedServiceGuard)("MraidWrapper")),
        (e.createMraidWrapper = function () {
          return (e.MraidWrapper = new c()), e.MraidWrapper;
        });
    },
    1676: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.possiblyReportOmidConstructTimeParamMismatch =
          e.getOmidConstructTimeCtxCmpMismatchMask =
          e.getOmidConstructTimeParamMismatchMask =
            void 0);
      const n = i(8844),
        s = i(1360),
        r = i(1882),
        o = i(1008),
        a = 500,
        d = { ctx: 1, plc: 2, cmp: 4 },
        c = { ctx: 1, cmp: 2 };
      function l(t, e) {
        return t.startsWith(e) ? t.slice(e.length) : t;
      }
      function u(t) {
        if (!t) return {};
        const e = {};
        return (
          (function (t) {
            try {
              const e = new URL(t);
              return e.search.length > 1
                ? e.searchParams
                : new URLSearchParams(l(e.hash, "#"));
            } catch (e) {
              return new URLSearchParams(l(l(t, "#"), "?"));
            }
          })(t).forEach((t, i) => {
            const n = i.trim().toLowerCase(),
              s = t.trim();
            n && s && (e[n] = s);
          }),
          e
        );
      }
      function h(t, e) {
        return e.every((e) => Boolean(t[e]));
      }
      function v(t, e, i, n) {
        if (!h(t, i) || !h(e, i)) return 0;
        let s = 0;
        return (
          i.forEach((i) => {
            var r, o;
            (null !== (r = t[i]) && void 0 !== r ? r : "") !==
              (null !== (o = e[i]) && void 0 !== o ? o : "") && (s |= n[i]);
          }),
          s
        );
      }
      function p(t, e) {
        return v(u(t), u(e), Object.keys(d), d);
      }
      function m(t, e) {
        return v(u(t), u(e), Object.keys(c), c);
      }
      (e.getOmidConstructTimeParamMismatchMask = p),
        (e.getOmidConstructTimeCtxCmpMismatchMask = m),
        (e.possiblyReportOmidConstructTimeParamMismatch = function (t) {
          try {
            const e = (function () {
              var t;
              const e =
                null !== (t = n.T.getTagScriptElem()) && void 0 !== t
                  ? t
                  : n.O.getCurrentScript();
              return (
                (function (t) {
                  var e, i, n;
                  if (!t) return null;
                  return (
                    (null === (e = t.dataset) || void 0 === e
                      ? void 0
                      : e.doubleverifyParameters) ||
                    (null !==
                      (n =
                        null === (i = t.getAttribute) || void 0 === i
                          ? void 0
                          : i.call(t, "data-doubleverify-parameters")) &&
                    void 0 !== n
                      ? n
                      : null)
                  );
                })(e) ||
                n.T.getDvtpScriptUrl() ||
                (null == e ? void 0 : e.src) ||
                ""
              );
            })();
            if (!e || !t) return;
            const i = p(t, e),
              d = m(t, e);
            0 !== i &&
              s.DiagnosticParamsReporterSingleton.reportOnce(
                s.DiagnosticParams.omidConstructTimeParamMismatch,
                i
              ),
              0 !== d &&
                s.DiagnosticParamsReporterSingleton.reportOnce(
                  s.DiagnosticParams.omidConstructTimeCtxCmpMismatch,
                  d
                ),
              (0 === i && 0 === d) ||
                (function (t, e) {
                  o.omidConstructTimeParamMismatchPayloadExperiment.init(),
                    o.omidConstructTimeParamMismatchPayloadExperiment.isEnabled() &&
                      (s.DiagnosticParamsReporterSingleton.reportOnce(
                        s.DiagnosticParams
                          .omidConstructTimeParamMismatchPayloadExperiment,
                        r.BooleanFeatureOptionId.ENABLED
                      ),
                      s.DiagnosticParamsReporterSingleton.reportOnce(
                        s.DiagnosticParams.omidConstructTimeOmParams,
                        t.slice(0, a)
                      ),
                      s.DiagnosticParamsReporterSingleton.reportOnce(
                        s.DiagnosticParams.omidConstructTimeUrlParams,
                        e.slice(0, a)
                      ));
                })(t, e);
          } catch (t) {}
        });
    },
    1706: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.OmidVerificationClientWrapper = void 0);
      const n = i(8844),
        s = i(4112),
        r = i(1805),
        o = i(9511),
        a = i(1906),
        d = i(1360),
        c = i(214),
        l = i(1676),
        u = i(3692),
        h = i(1008);
      class v {
        constructor(t) {
          (this.isOmidEnabled = !0),
            (this.onSessionEvent = (t) => {
              switch (t.type) {
                case "sessionStart":
                  this.onSessionStart(t);
                  break;
                case "sessionFinish":
                  this.onSessionFinish(t);
                  break;
                case "sessionError":
                  this.onSessionError(t);
              }
            }),
            (this.isReady = !1),
            this.init(t),
            this.isSupported() &&
              ((this.sessionStartTimeout = (0, u.setSafeTimeout)(() => {
                this.noSessionStartId = a.Utilities.generateUUID();
                const t = {
                  [(0, d.getDiagnosticQueryParamName)(
                    d.DiagnosticParams.isOmid3p
                  )]: n.T.isOmid3p() ? "1" : "0",
                  [(0, d.getDiagnosticQueryParamName)(
                    d.DiagnosticParams.omidEnvironment
                  )]: this.getEnvironment(),
                  [(0, d.getDiagnosticQueryParamName)(
                    d.DiagnosticParams.omidNoSessionStartId
                  )]: this.noSessionStartId,
                };
                r.L.sendError(
                  s.ClientErrorType.OmidNoSessionStart,
                  new Error("omid SessionStart not fired"),
                  "omid SessionStart not fired",
                  t
                );
              }, v.sessionStartTimeoutInterval)),
              this.registerSessionObserver());
        }
        ready(t) {
          this.isReady ? t() : (this.readyCB = t);
        }
        onSessionStart(t) {
          var e, i;
          (this.isReady = !0),
            (0, u.clearSafeTimeout)(this.sessionStartTimeout),
            t || (t = {});
          const r = t.data;
          (0, l.possiblyReportOmidConstructTimeParamMismatch)(
            null == r ? void 0 : r.verificationParameters
          );
          const h = (0, o.processTikTokSessionStart)(r);
          h && (t.data = h),
            (this.omidSessionData = t),
            n.omidAdapter.init(
              this.omidVCInstance,
              this.omidSessionData,
              this.vendorKey,
              this.isOmidEnabled
            ),
            d.DiagnosticParamsReporterSingleton.reportOnce(
              d.DiagnosticParams.omidTimeMsUntilStartSession,
              a.Utilities.getTimeDiffNoAbs(new Date().getTime())
            ),
            d.DiagnosticParamsReporterSingleton.reportOnce(
              d.DiagnosticParams.omidAdSessionId,
              this.omidSessionData.adSessionId
            ),
            this.isLateSessionStart() &&
              d.DiagnosticParamsReporterSingleton.reportOnce(
                d.DiagnosticParams.omidNoSessionStartId,
                this.noSessionStartId
              );
          const v =
            null === (e = this.omidSessionData.data) || void 0 === e
              ? void 0
              : e.creativeType;
          d.DiagnosticParamsReporterSingleton.reportOnce(
            d.DiagnosticParams.omidCreativeType,
            void 0 !== v
              ? null !== (i = c.omidCreativeTypeMapping[v]) && void 0 !== i
                ? i
                : c.omidCreativeTypeMapping[s.OmidCreativeType.UNKNOWN]
              : -1
          ),
            "function" == typeof this.readyCB && this.readyCB();
        }
        onSessionFinish(t) {
          this.isReady = !1;
        }
        onSessionError(t) {
          (this.isReady = !1), t || (t = {});
          const e = t.data || {},
            i = e.message || "onSessionError_Error",
            n = this.isInvalidInjection(e)
              ? s.ClientErrorType.OmidInvalidInjection
              : s.ClientErrorType.OmidSessionError;
          (0, u.clearSafeTimeout)(this.sessionStartTimeout),
            r.L.sendError(n, { message: i }, "", {
              [(0, d.getDiagnosticQueryParamName)(
                d.DiagnosticParams.omidEnvironment
              )]: this.getEnvironment(),
            });
        }
        getEnvironment() {
          var t;
          return null === (t = this.omidVCInstance) || void 0 === t
            ? void 0
            : t.getEnvironment();
        }
        isLateSessionStart() {
          return !!this.noSessionStartId;
        }
        isInvalidInjection(t) {
          return (
            "generic" === t.errorType &&
            t.message.includes("injected by the OM-SDK service itself")
          );
        }
        registerSessionObserver() {
          this.omidVCInstance &&
            this.omidVCInstance.registerSessionObserver(
              this.onSessionEvent,
              this.vendorKey
            );
        }
        isSupported() {
          if (void 0 === this.omidVCIsSupported)
            try {
              this.omidVCIsSupported = this.omidVCInstance.isSupported();
            } catch (t) {
              this.omidVCIsSupported = !1;
            }
          return this.omidVCIsSupported && this.isOmidEnabled;
        }
        setVendorKey(t) {
          const e = this.vendorKeyFromScriptUrl(t);
          (this.vendorKey = e || this.defaultVendorKey()),
            d.DiagnosticParamsReporterSingleton.reportOnce(
              d.DiagnosticParams.omidVendorKey,
              this.vendorKey
            );
        }
        vendorKeyFromScriptUrl(t) {
          if (!t) return null;
          try {
            return a.Utilities.getParamValue(t, "vendor_key") || null;
          } catch (t) {
            return null;
          }
        }
        defaultVendorKey() {
          const t = v.DefaultVendorKey;
          return h.randomizeOmidVendorKeyExperiment.isEnabled()
            ? `${t}${v.randomVendorKeySuffix()}`
            : t;
        }
        static randomVendorKeySuffix() {
          return Math.floor(9999 * Math.random()) + 1;
        }
        setOmidConfig(t) {
          (this.isOmidEnabled = "0" != a.Utilities.getParamValue(t, "omid")),
            d.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              d.DiagnosticParams.isOmidEnabled,
              this.isOmidEnabled ? 1 : 0
            );
        }
        getGlobalOmidInjectionId() {
          var t;
          try {
            return "object" == typeof omidVerificationProperties &&
              null !== (t = omidVerificationProperties.injectionId) &&
              void 0 !== t
              ? t
              : null;
          } catch (t) {
            return null;
          }
        }
        getScriptOmidInjectionId() {
          var t, e;
          if (n.O.isDomlessEnvironment()) return null;
          try {
            const i = n.O.getCurrentScript();
            return null !==
              (e =
                null === (t = null == i ? void 0 : i.getAttribute) ||
                void 0 === t
                  ? void 0
                  : t.call(i, "data-injection-id")) && void 0 !== e
              ? e
              : null;
          } catch (t) {
            return null;
          }
        }
        getDvtpOmidInjectionId() {
          return null;
        }
        reportOmidInjectionId() {
          var t;
          const e =
              null !== (t = this.getGlobalOmidInjectionId()) && void 0 !== t
                ? t
                : this.getScriptOmidInjectionId(),
            i = this.getDvtpOmidInjectionId();
          null != e &&
            d.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              d.DiagnosticParams.omidInjectionId,
              e
            ),
            i &&
              i !== e &&
              d.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
                d.DiagnosticParams.dvtpOmidInjectionId,
                i
              );
        }
        setDomlessInjectionId() {
          if (!n.O.isDomlessEnvironment()) return;
          const t = n.T.getOmidInjectionId();
          n.T.getOmidInjectionId() &&
            "object" == typeof omidVerificationProperties &&
            (omidVerificationProperties.injectionId = t);
        }
        init(t) {
          if (t) {
            const e = n.T.getDvtpScriptUrl();
            this.setVendorKey(e),
              n.omidAdapter.setVendorKeySuffixEnabled(
                h.randomizeOmidVendorKeyExperiment.isEnabled()
              ),
              this.setOmidConfig(e),
              this.setDomlessInjectionId(),
              this.reportOmidInjectionId();
            try {
              this.omidVCInstance = new t();
            } catch (t) {}
          }
        }
      }
      (e.OmidVerificationClientWrapper = v),
        (v.VerificationClientVersion = "1.2.6-iab634"),
        (v.DefaultVendorKey = "doubleverify.com-omid"),
        (v.sessionStartTimeoutInterval = 5200);
    },
    6384: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 });
      let i = null,
        n = null,
        s = null,
        r = null,
        o = null,
        a = null,
        d = null,
        c = null,
        l = null,
        u = null,
        h = null,
        v = null,
        p = null;
      const m = {
        setIndexExecutionStartTime() {
          o = this.currentTime();
        },
        setInitFireVisitImportsStartTime(t) {
          i = t;
        },
        setInitFireVisitImportsEndTime() {
          n = this.currentTime();
        },
        setTotalSyncTimeStartTime(t) {
          s = t;
        },
        setTotalSyncTimeEndTime() {
          r = this.currentTime();
        },
        setFireVerifyExecutionStartTime() {
          a = this.currentTime();
        },
        setFireVerifyExecutionEndTime() {
          d = this.currentTime();
        },
        setFireVisitExecutionStartTime() {
          c = this.currentTime();
        },
        setFireVisitExecutionEndTime() {
          l = this.currentTime();
        },
        setInitMainExecutionStartTime() {
          u = this.currentTime();
        },
        setInitMainExecutionEndTime() {
          h = this.currentTime();
        },
        setInitMeasurementExecutionStartTime() {
          v = this.currentTime();
        },
        setInitMeasurementExecutionEndTime() {
          p = this.currentTime();
        },
        getBenchmarks: () =>
          [
            {
              name: "tsetms",
              startTime: s,
              endTime: r,
              condition: Boolean(s && r),
            },
            {
              name: "ipvietms",
              startTime: i,
              endTime: n,
              condition: Boolean(i && n),
            },
            {
              name: "prvietms",
              startTime: s,
              endTime: c,
              condition: Boolean(s && c),
            },
            {
              name: "fvietms",
              startTime: c,
              endTime: l,
              condition: Boolean(c && l),
            },
            {
              name: "povietms",
              startTime: l,
              endTime: r,
              condition: Boolean(l && r),
            },
            {
              name: "prveetms",
              startTime: s,
              endTime: a,
              condition: Boolean(s && a),
            },
            {
              name: "fveetms",
              startTime: a,
              endTime: d,
              condition: Boolean(a && d),
            },
            {
              name: "poveetms",
              startTime: d,
              endTime: r,
              condition: Boolean(d && r),
            },
            {
              name: "imaetms",
              startTime: u,
              endTime: h,
              condition: Boolean(u && h),
            },
            {
              name: "iesuimestms",
              startTime: o,
              endTime: u,
              condition: Boolean(o && u),
            },
            {
              name: "imeetms",
              startTime: v,
              endTime: p,
              condition: Boolean(v && p),
            },
          ]
            .filter((t) => t.condition)
            .map(({ name: t, startTime: e, endTime: i }) => ({
              taskDetails: { name: t },
              startTime: e,
              endTime: i,
            })),
        currentTime: () =>
          "undefined" != typeof performance &&
          "function" == typeof performance.now
            ? performance.now()
            : void 0,
      };
      e.default = m;
    },
    1167: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.initFireVisitImportsStartTime = void 0),
        (e.initFireVisitImportsStartTime =
          "undefined" != typeof performance &&
          "function" == typeof performance.now
            ? performance.now()
            : void 0);
    },
    203: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AbstractRenderLogic = void 0);
      const n = i(8844),
        s = i(7102),
        r = i(3283),
        o = i(1805);
      e.AbstractRenderLogic = class {
        constructor() {
          this.wasAdRenderedCalled = !1;
        }
        publishAdRenderedDataAfterImpressionServed() {
          var t;
          (null === (t = n.T.u().pubSub) || void 0 === t
            ? void 0
            : t.excludeFrameId) &&
            s.k.addEventListener(
              s.DvEvents.impressionServed,
              () => {
                n.T.publishPubSubEvent(
                  s.DvEvents.adRenderedData,
                  n.T.getFrameId(n.O.currentWindow()),
                  new r.AdRenderedEventData(
                    n.T.getImpressionId(n.O.currentWindow())
                  )
                );
              },
              "PreRenderLogic"
            );
        }
        isAdRendered() {
          return this.wasAdRenderedCalled;
        }
        adRendered() {
          (this.wasAdRenderedCalled = !0),
            this.publishAdRenderedDataAfterImpressionServed(),
            s.k.dispatchEvent(s.DvEvents.beginToRender, new r.EventData());
        }
        static fireRenderedEvent() {
          o.L.sendMessage({ prndr: 0 }, !0);
        }
      };
    },
    7015: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ContainerRenderLogic = void 0);
      const n = i(203),
        s = i(8844),
        r = i(1360);
      class o extends n.AbstractRenderLogic {
        constructor(t) {
          super(),
            (this.waitingForWindowLoadEvent = !1),
            (this.activeListeners = new Map()),
            (this.lateInjectionListeners = new Map()),
            (this.lateInjectionObserver = null),
            (this.lateInjectionContainer = null),
            (this.renderLogicStartTimeMs = null),
            (this.renderedSynchronously = !1),
            (this.adContainerInspector = t.createAdContainerInspector());
        }
        start() {
          var t, e, i, n;
          this.renderLogicStartTimeMs = Date.now();
          const s =
              null === (t = this.adContainerInspector) || void 0 === t
                ? void 0
                : t.getContainer(),
            r =
              null !==
                (i =
                  null === (e = this.adContainerInspector) || void 0 === e
                    ? void 0
                    : e.getDirectChildren()) && void 0 !== i
                ? i
                : [],
            o =
              null === (n = this.adContainerInspector) || void 0 === n
                ? void 0
                : n.getDirectChildren(["img", "iframe"]),
            a = this.findALoadedChild(o),
            d = this.buildStartSnapshot(r, o, a);
          let c;
          s
            ? 0 === r.length
              ? ((c = 1),
                this.reportPreRenderReason("nochild"),
                this.determineAdNotRendered(4))
              : 0 === o.length
              ? ((this.renderedSynchronously = !0),
                this.waitForWindowToLoad()
                  ? (c = 4)
                  : ((this.renderedSynchronously = !1),
                    (c = 2),
                    this.reportPreRenderReason("waitwin"),
                    this.startLateInjectionObserver(s)))
              : a
              ? ((c = 4),
                (this.renderedSynchronously = !0),
                this.reportAdRenderedByLoadedChild(a))
              : ((c = 3),
                this.reportPreRenderReason("waitchild"),
                this.waitForTheFirstLoadableChildToLoad(o),
                this.startLateInjectionObserver(s))
            : ((c = 0),
              this.reportPreRenderReason("nocont"),
              this.determineAdNotRendered(2)),
            this.reportStartDiagnostics(c, d);
        }
        getNumberOfActiveListeners() {
          return this.activeListeners.size;
        }
        buildStartSnapshot(t, e, i) {
          const n = e.filter((t) => "img" === this.getElementType(t)),
            s = e.filter((t) => "iframe" === this.getElementType(t));
          return {
            directChildrenCount: t.length,
            loadableChildrenCount: e.length,
            directImgCount: n.length,
            directIframeCount: s.length,
            nonLoadableChildrenCount: t.length - e.length,
            loadedChildCount: i ? 1 : 0,
            imgNotCompleteCount: n.filter((t) => !t.complete).length,
            imgZeroHeightCount: n.filter((t) => 0 === t.naturalHeight).length,
            imgNotLoadedCount: n.filter((t) => !this.isImageLoaded(t)).length,
            iframeNotLoadedCount: s.filter((t) => !this.isIframeLoaded(t))
              .length,
          };
        }
        reportStartDiagnostics(t, e) {
          r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
            r.DiagnosticParams.containerRenderLogicFlowStep,
            t
          ),
            r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              r.DiagnosticParams.containerRenderLogicDirectChildrenCount,
              e.directChildrenCount
            ),
            r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              r.DiagnosticParams.containerRenderLogicLoadableChildrenCount,
              e.loadableChildrenCount
            ),
            r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              r.DiagnosticParams.containerRenderLogicDirectImgCount,
              e.directImgCount
            ),
            r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              r.DiagnosticParams.containerRenderLogicDirectIframeCount,
              e.directIframeCount
            ),
            r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              r.DiagnosticParams.containerRenderLogicNonLoadableChildrenCount,
              e.nonLoadableChildrenCount
            ),
            r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              r.DiagnosticParams.containerRenderLogicLoadedChildCount,
              e.loadedChildCount
            ),
            r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              r.DiagnosticParams.containerRenderLogicImgNotCompleteCount,
              e.imgNotCompleteCount
            ),
            r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              r.DiagnosticParams.containerRenderLogicImgZeroHeightCount,
              e.imgZeroHeightCount
            ),
            r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              r.DiagnosticParams.containerRenderLogicImgNotLoadedCount,
              e.imgNotLoadedCount
            ),
            r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              r.DiagnosticParams.containerRenderLogicIframeNotLoadedCount,
              e.iframeNotLoadedCount
            ),
            r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              r.DiagnosticParams.containerRenderLogicSyncRendered,
              this.renderedSynchronously ? 1 : 0
            ),
            r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              r.DiagnosticParams.containerRenderLogicActiveListenersCount,
              this.activeListeners.size
            );
        }
        reportAsyncRenderDiagnostics() {
          this.renderedSynchronously ||
            null == this.renderLogicStartTimeMs ||
            (r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              r.DiagnosticParams.containerRenderLogicAsyncRendered,
              1
            ),
            r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              r.DiagnosticParams.containerRenderLogicRenderDelayMs,
              Date.now() - this.renderLogicStartTimeMs
            ));
        }
        reportAdRenderedByLoadedChild(t) {
          const e = this.getReasonForRendered(t);
          this.determineAdRendered(e, t);
        }
        waitForWindowToLoad() {
          const t = s.O.workingWindow(),
            e = s.O.workingDocument(t),
            i = (null == e ? void 0 : e.readyState) || "unknown";
          return (
            r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              r.DiagnosticParams.containerRenderLogicWindowLoadState,
              i
            ),
            "complete" === i
              ? (this.determineAdRendered(4), !0)
              : ((this.waitingForWindowLoadEvent = !0),
                (this.windowLoadFallbackCb = () => {
                  this.determineAdRendered(4);
                }),
                this.activeListeners.set(t, this.windowLoadFallbackCb),
                s.S.addEventListener("load", this.windowLoadFallbackCb, t),
                !1)
          );
        }
        reportPreRenderReason(t) {
          r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
            r.DiagnosticParams.containerRenderLogicPreRenderReason,
            t
          );
        }
        determineAdNotRendered(t) {
          this.removeLoadEventListener();
        }
        determineAdRendered(t, e = null) {
          this.isAdRendered() ||
            (this.reportAdRendered(t, e), this.removeLoadEventListener());
        }
        reportAdRendered(t, e = null) {
          this.reportAsyncRenderDiagnostics(),
            super.adRendered(),
            n.AbstractRenderLogic.fireRenderedEvent(),
            this.reportRenderCompletionDiagnostics(t, e);
        }
        reportRenderCompletionDiagnostics(t, e) {
          r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
            r.DiagnosticParams.containerRenderLogicRenderSource,
            t
          ),
            (1 !== t && 8 !== t) ||
              !e ||
              (r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
                r.DiagnosticParams.containerRenderLogicContainerImageWidth,
                e.width
              ),
              r.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
                r.DiagnosticParams.containerRenderLogicContainerImageHeight,
                e.height
              ));
        }
        removeLoadEventListener() {
          this.removeElemLoadEventListener(),
            this.waitingForWindowLoadEvent &&
              this.removeWindowLoadEventListener(),
            this.stopLateInjectionObserver();
        }
        removeElemLoadEventListener() {
          this.activeListeners.forEach((t, e) => {
            s.S.removeEventListener("load", t, e),
              this.activeListeners.delete(e);
          });
        }
        removeWindowLoadEventListener() {
          const t = s.O.workingWindow();
          s.S.removeEventListener("load", this.windowLoadFallbackCb, t),
            this.activeListeners.delete(t);
        }
        getElementType(t) {
          return t.tagName.toLowerCase();
        }
        getReasonForRendered(t) {
          const e = this.getElementType(t);
          return "img" === e ? 1 : "iframe" === e ? 2 : null;
        }
        getLateInjectionReasonForRendered(t) {
          const e = this.getElementType(t);
          return "img" === e ? 8 : "iframe" === e ? 16 : null;
        }
        waitForTheFirstLoadableChildToLoad(t) {
          t
            .filter((t) => "img" === this.getElementType(t))
            .forEach((t) => {
              this.addLoadEventListener(t, 1);
            }),
            t
              .filter((t) => "iframe" === this.getElementType(t))
              .forEach((t) => {
                this.addLoadEventListener(t, 2);
              });
        }
        findALoadedChild(t) {
          return t.find((t) => {
            const e = this.getElementType(t);
            return "img" === e
              ? this.isImageLoaded(t)
              : "iframe" === e && this.isIframeLoaded(t);
          });
        }
        isImageLoaded(t) {
          return t.complete && 0 !== t.naturalHeight;
        }
        isIframeLoaded(t) {
          try {
            const e = s.O.getIframeWindow(t),
              i = s.O.workingDocument(e),
              n = t.contentDocument || i;
            return "complete" === (null == n ? void 0 : n.readyState);
          } catch (t) {
            return !1;
          }
        }
        addLoadEventListener(t, e) {
          const i = () => {
            this.determineAdRendered(e, t);
          };
          this.activeListeners.set(t, i), s.S.addEventListener("load", i, t);
        }
        startLateInjectionObserver(t) {
          var e, i, n;
          if ("function" != typeof MutationObserver || this.isAdRendered())
            return;
          try {
            const i =
              null === (e = this.adContainerInspector) || void 0 === e
                ? void 0
                : e.getContainer();
            if (!i || i !== t) return;
            (this.lateInjectionContainer = i),
              (this.lateInjectionObserver = new MutationObserver((t) => {
                this.handleLateInjectionMutations(t);
              })),
              this.lateInjectionObserver.observe(i, {
                childList: !0,
                subtree: !0,
              });
          } catch (t) {
            return void this.stopLateInjectionObserver();
          }
          let s = [];
          try {
            s =
              null !==
                (n =
                  null === (i = this.adContainerInspector) || void 0 === i
                    ? void 0
                    : i.getDescendants(["img", "iframe"])) && void 0 !== n
                ? n
                : [];
          } catch (t) {}
          this.evaluateLateInjectionElements(s);
        }
        handleLateInjectionMutations(t) {
          if (this.isAdRendered()) return void this.stopLateInjectionObserver();
          let e;
          try {
            e = this.extractLoadableElementsFromMutations(t);
          } catch (t) {
            return void this.stopLateInjectionObserver();
          }
          0 !== e.length && this.evaluateLateInjectionElements(e);
        }
        extractLoadableElementsFromMutations(t) {
          const e = [],
            i = new Set();
          return (
            t.forEach((t) => {
              this.isMutationWithinObservedContainer(t) &&
                t.addedNodes.forEach((t) => {
                  this.collectLoadableElementsFromNode(t, e, i);
                });
            }),
            e
          );
        }
        isMutationWithinObservedContainer(t) {
          return (
            null != this.lateInjectionContainer &&
            (this.lateInjectionContainer === t.target ||
              this.lateInjectionContainer.contains(t.target))
          );
        }
        collectLoadableElementsFromNode(t, e, i) {
          var n;
          if (
            !(
              t instanceof Element &&
              (null === (n = this.lateInjectionContainer) || void 0 === n
                ? void 0
                : n.contains(t))
            )
          )
            return;
          const s = this.getElementType(t);
          ("img" !== s && "iframe" !== s) || i.has(t) || (i.add(t), e.push(t)),
            t.querySelectorAll("img,iframe").forEach((t) => {
              var n;
              (null === (n = this.lateInjectionContainer) || void 0 === n
                ? void 0
                : n.contains(t)) &&
                !i.has(t) &&
                (i.add(t), e.push(t));
            });
        }
        evaluateLateInjectionElements(t) {
          const e = this.findALoadedChild(t);
          if (e)
            return void this.determineAdRendered(
              this.getLateInjectionReasonForRendered(e),
              e
            );
          const i = t.filter(
            (t) =>
              !this.activeListeners.has(t) &&
              !this.lateInjectionListeners.has(t)
          );
          i.length > 0 && this.waitForLateInjectionElementLoad(i);
        }
        waitForLateInjectionElementLoad(t) {
          t.forEach((t) => {
            const e = () => {
              var e;
              try {
                if (
                  this.isAdRendered() ||
                  !(null === (e = this.lateInjectionContainer) || void 0 === e
                    ? void 0
                    : e.contains(t))
                )
                  return;
              } catch (t) {
                return void this.stopLateInjectionObserver();
              }
              this.determineAdRendered(
                this.getLateInjectionReasonForRendered(t),
                t
              );
            };
            this.lateInjectionListeners.set(t, e),
              s.S.addEventListener("load", e, t);
          });
        }
        stopLateInjectionObserver() {
          var t;
          try {
            null === (t = this.lateInjectionObserver) ||
              void 0 === t ||
              t.disconnect();
          } catch (t) {}
          (this.lateInjectionObserver = null),
            (this.lateInjectionContainer = null),
            this.lateInjectionListeners.forEach((t, e) => {
              try {
                s.S.removeEventListener("load", t, e);
              } catch (t) {}
              this.lateInjectionListeners.delete(e);
            });
        }
      }
      e.ContainerRenderLogic = o;
    },
    415: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.DefaultRenderLogic = void 0);
      const n = i(203);
      class s extends n.AbstractRenderLogic {
        start() {
          super.adRendered();
        }
        isSupported(t) {
          return !0;
        }
        getRenderingMethodIndicator() {
          return 32;
        }
      }
      e.DefaultRenderLogic = s;
    },
    1890: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.DisplayGenXContainerRenderLogic = void 0);
      const n = i(7533),
        s = i(8844),
        r = i(7015);
      class o extends r.ContainerRenderLogic {
        constructor() {
          super(
            new n.DisplayGenXAdContainerInspectorFactory(o.tagAttributeName)
          );
        }
        isSupported(t) {
          return s.A.isDisplayGenXEnabled() && 0 === t;
        }
        getRenderingMethodIndicator() {
          return 8;
        }
      }
      (e.DisplayGenXContainerRenderLogic = o),
        (o.tagAttributeName = "data-doubleverify-container");
    },
    9520: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.MraidInMobiRenderLogic = void 0);
      const n = i(5473),
        s = i(203),
        r = i(8844);
      class o extends s.AbstractRenderLogic {
        constructor() {
          super(...arguments),
            (this.wasViewable = !1),
            (this.maxIterations = 20);
        }
        start() {
          n.MraidWrapper.getAdViewablePercentage()
            ? super.adRendered()
            : n.MraidWrapper.runMraidRegisterSafely(
                "viewableChange",
                this.mraidViewableChangeUpdate.bind(this)
              );
        }
        mraidViewableChangeUpdate(t) {
          t &&
            !this.wasViewable &&
            ((this.wasViewable = !0),
            super.adRendered(),
            s.AbstractRenderLogic.fireRenderedEvent());
        }
        isSupported(t) {
          return (
            0 == t &&
            n.MraidWrapper.isSupported() &&
            r.O.objectLookup(
              r.O.currentWindow(),
              "imraid",
              this.maxIterations
            ) &&
            r.O.objectLookup(r.O.currentWindow(), "inmobi", this.maxIterations)
          );
        }
        getRenderingMethodIndicator() {
          return 2;
        }
      }
      e.MraidInMobiRenderLogic = o;
    },
    5558: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.MraidRenderLogic = void 0);
      const n = i(7102),
        s = i(5473),
        r = i(203),
        o = i(8844);
      class a extends r.AbstractRenderLogic {
        constructor() {
          super(...arguments),
            (this.isMraidRendered = !1),
            (this.isPageVisibilityRendered = !1),
            (this.isPageVisibilitySupported = !1);
        }
        start() {
          (this.isPageVisibilitySupported =
            o.S.isVisibilityChangeEventSupported()),
            this.checkMraidRender(),
            this.isPageVisibilitySupported && this.checkPageVisibilityRender(),
            this.checkOverallRendered(!1);
        }
        checkMraidRender() {
          s.MraidWrapper.getReadyState()
            ? (this.isMraidRendered = !0)
            : (this.mraidDefaultStateDataEventHandler = n.k.addEventListener(
                n.DvEvents.mraidDefaultStateData,
                this.mraidDefaultStateCallback.bind(this)
              ));
        }
        mraidDefaultStateCallback() {
          (this.isMraidRendered = !0),
            this.mraidDefaultStateDataEventHandler &&
              n.k.removeEventListener(this.mraidDefaultStateDataEventHandler),
            this.checkOverallRendered(!0);
        }
        checkPageVisibilityRender() {
          if ("prerender" != o.O.getVisibilityState())
            this.isPageVisibilityRendered = !0;
          else {
            const t = o.S.getVisibilityPrefix() + "visibilitychange";
            o.S.addEventListener(
              t,
              this.visibilityChangeCallback.bind(this),
              o.O.workingDocument()
            );
          }
        }
        visibilityChangeCallback() {
          this.isPageVisibilityRendered ||
            ("prerender" != o.O.getVisibilityState() &&
              ((this.isPageVisibilityRendered = !0),
              this.checkOverallRendered(!0)));
        }
        checkOverallRendered(t) {
          ((!this.isPageVisibilitySupported && this.isMraidRendered) ||
            (this.isPageVisibilitySupported &&
              this.isPageVisibilityRendered &&
              this.isMraidRendered)) &&
            (super.adRendered(),
            t && r.AbstractRenderLogic.fireRenderedEvent());
        }
        isSupported(t) {
          return s.MraidWrapper.isSupported();
        }
        getRenderingMethodIndicator() {
          return 4;
        }
      }
      e.MraidRenderLogic = a;
    },
    7646: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.OmidRenderLogic = void 0);
      const n = i(203),
        s = i(4112),
        r = i(8844),
        o = i(1360);
      class a extends n.AbstractRenderLogic {
        constructor() {
          super(...arguments), (this.wasRendered = !1);
        }
        isSupported(t) {
          return r.omidAdapter.isSupported();
        }
        getRenderingMethodIndicator() {
          return 64;
        }
        start() {
          r.omidAdapter.addEventListener("impression", (t) => {
            this.handleImpressionEvent(t);
          }),
            r.omidAdapter.addEventListener("geometryChange", (t) => {
              this.handleGeometryChangeEvent(t);
            });
        }
        handleImpressionEvent(t) {
          ((!this.wasRendered &&
            this.checkIfImpressionTypeIndicatesRendered(t)) ||
            this.checkIfPercentageInViewLargerThanZero(t)) &&
            (o.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              o.DiagnosticParams.omidRenderedFromImpressionEvent,
              1
            ),
            this.updateThatAdIsRendered());
        }
        handleGeometryChangeEvent(t) {
          !this.wasRendered &&
            this.checkIfPercentageInViewLargerThanZero(t) &&
            (o.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              o.DiagnosticParams.omidRenderedFromGeomChangePercLargerThanZero,
              1
            ),
            this.updateThatAdIsRendered());
        }
        checkIfImpressionTypeIndicatesRendered(t) {
          var e;
          const i =
            null === (e = null == t ? void 0 : t.data) || void 0 === e
              ? void 0
              : e.impressionType;
          return !(
            !i ||
            (i !== s.OmidImpressionType.BEGIN_TO_RENDER &&
              i !== s.OmidImpressionType.ONE_PIXEL &&
              i !== s.OmidImpressionType.VIEWABLE)
          );
        }
        checkIfPercentageInViewLargerThanZero(t) {
          var e, i;
          return (
            (null ===
              (i =
                null === (e = null == t ? void 0 : t.data) || void 0 === e
                  ? void 0
                  : e.adView) || void 0 === i
              ? void 0
              : i.percentageInView) > 0
          );
        }
        updateThatAdIsRendered() {
          (this.wasRendered = !0),
            super.adRendered(),
            n.AbstractRenderLogic.fireRenderedEvent();
        }
      }
      e.OmidRenderLogic = a;
    },
    4387: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PageVisibilityRenderLogic = void 0);
      const n = i(8844),
        s = i(203);
      class r extends s.AbstractRenderLogic {
        constructor() {
          super(...arguments), (this.wasRendered = !1);
        }
        start() {
          if ("prerender" != n.O.getVisibilityState()) super.adRendered();
          else {
            const t = n.S.getVisibilityPrefix() + "visibilitychange";
            n.S.addEventListener(
              t,
              this.visibilitychangeCallback.bind(this),
              n.O.workingDocument()
            );
          }
        }
        visibilitychangeCallback() {
          this.wasRendered ||
            ("prerender" != n.O.getVisibilityState() &&
              ((this.wasRendered = !0),
              super.adRendered(),
              s.AbstractRenderLogic.fireRenderedEvent()));
        }
        isSupported(t) {
          return n.S.isVisibilityChangeEventSupported();
        }
        getRenderingMethodIndicator() {
          return 16;
        }
      }
      e.PageVisibilityRenderLogic = r;
    },
    1003: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.RenderLogicFactory = e.RenderLogicFactoryClass = void 0);
      const n = i(9520),
        s = i(5558),
        r = i(4387),
        o = i(415),
        a = i(8844),
        d = i(1890),
        c = i(7646);
      class l {
        getRenderLogic() {
          return (
            this.selectedRenderLogic ||
              (this.selectedRenderLogic = this.selectSupportedRenderLogic()),
            this.selectedRenderLogic
          );
        }
        prioritizedRenderLogicImplementations() {
          return [
            c.OmidRenderLogic,
            n.MraidInMobiRenderLogic,
            s.MraidRenderLogic,
            d.DisplayGenXContainerRenderLogic,
            r.PageVisibilityRenderLogic,
            o.DefaultRenderLogic,
          ];
        }
        selectSupportedRenderLogic() {
          try {
            for (const t of this.prioritizedRenderLogicImplementations()) {
              const e = new t(),
                i = a.A.getTagType();
              if (e.isSupported(i)) return e;
            }
          } catch (t) {}
          return new o.DefaultRenderLogic();
        }
      }
      (e.RenderLogicFactoryClass = l), (e.RenderLogicFactory = new l());
    },
    9579: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.initializeRuntimeDependencies = void 0);
      const n = i(8844),
        s = i(2193),
        r = i(7102),
        o = i(5473);
      let a = !1;
      e.initializeRuntimeDependencies = function () {
        a ||
          ((0, n.V)(),
          (0, n.createBrowserDetector)(),
          (0, n._)(),
          (0, r.jt)(),
          (0, o.createMraidWrapper)(),
          (0, s.initializeDvDefinedProperties)(),
          (a = !0));
      };
    },
    5898: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.SafeFrameObject = e.SafeFrameObjectClass = void 0);
      class i {
        isGeometricSupported(t) {
          var e, i, n, s;
          const r =
            null ===
              (s =
                null ===
                  (n =
                    null ===
                      (i =
                        null === (e = t.$sf) || void 0 === e
                          ? void 0
                          : e.ext) || void 0 === i
                      ? void 0
                      : i.geom) || void 0 === n
                  ? void 0
                  : n.call(i)) || void 0 === s
              ? void 0
              : s.win;
          return (
            (null == r ? void 0 : r.h) > 0 && (null == r ? void 0 : r.w) > 0
          );
        }
        isInviewSupported(t) {
          return !!t.$sf && !!t.$sf.ext && !!t.$sf.ext.inViewPercentage;
        }
        getViewport(t) {
          if (this.isGeometricSupported(t)) {
            const e = t.$sf.ext.geom();
            return { height: Math.floor(e.win.h), width: Math.floor(e.win.w) };
          }
        }
        getInViewPercentage(t) {
          if (this.isInviewSupported(t)) return t.$sf.ext.inViewPercentage();
        }
        getAssetVisibleDimension(t) {
          const e = {
              width: 0,
              height: 0,
              left: 0,
              right: 0,
              top: 0,
              bottom: 0,
            },
            i = t.$sf.ext.geom();
          return (
            (e.width = parseInt(i.self.w)),
            (e.height = parseInt(i.self.h)),
            i.par &&
              ((e.top = parseInt(i.self.t) - parseInt(i.par.t)),
              (e.bottom = e.top + e.height),
              (e.left = parseInt(i.self.l) - parseInt(i.par.l)),
              (e.right = e.left + e.width)),
            e
          );
        }
        isSafeFrameExists(t) {
          try {
            return !!t.$sf;
          } catch (t) {}
        }
        getUrlReferrer(t) {
          var e, i, n;
          try {
            return null ===
              (n =
                null ===
                  (i = null === (e = t.$sf) || void 0 === e ? void 0 : e.ext) ||
                void 0 === i
                  ? void 0
                  : i.hostURL) || void 0 === n
              ? void 0
              : n.call(i);
          } catch (t) {}
        }
      }
      (e.SafeFrameObjectClass = i), (e.SafeFrameObject = new i());
    },
    9198: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ScriptDynamicFlags = void 0);
      const n = i(1805),
        s = i(4112),
        r = i(7102);
      class o {
        constructor() {
          (this.impServed = !1),
            r.k.addEventListener(
              r.DvEvents.impressionServed,
              this.handleImpressionServed.bind(this)
            );
        }
        static getInstance() {
          return o.instance || (o.instance = new o()), o.instance;
        }
        getFlags() {
          return this.flags;
        }
        turnOn(t) {
          const e = this.flags;
          (this.flags |= t),
            this.flags !== e &&
              this.impServed &&
              n.L.sendMessage({
                [s.TPSDataMapping.scriptDynamicFlags]: this.flags,
              });
        }
        handleImpressionServed() {
          (this.impServed = !0),
            n.L.sendMessage({
              [s.TPSDataMapping.scriptDynamicFlags]: this.flags,
            });
        }
      }
      e.ScriptDynamicFlags = o;
    },
    5944: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.EventIdGeneratorAdaptor = e.SequenceIdGeneratorClass = void 0);
      class i {
        constructor() {
          this.sequenceId = 1;
        }
        getNext() {
          return this.sequenceId++;
        }
      }
      (e.SequenceIdGeneratorClass = i), (e.EventIdGeneratorAdaptor = new i());
    },
    5466: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.StandardSizes = e.StandardSizesClass = void 0);
      class i {
        constructor() {
          (this.DisplayStandardSizes = [
            { width: 88, height: [31] },
            { width: 100, height: [150] },
            { width: 120, height: [20, 60, 90, 240, 600, 800] },
            { width: 125, height: [125] },
            { width: 160, height: [600, 800] },
            { width: 168, height: [28] },
            { width: 180, height: [150, 160, 600] },
            { width: 184, height: [90] },
            { width: 200, height: [90, 112, 200, 446] },
            { width: 215, height: [125] },
            { width: 216, height: [36] },
            { width: 220, height: [90] },
            { width: 234, height: [60] },
            { width: 240, height: [133, 400] },
            { width: 250, height: [60, 250, 300, 360, 600] },
            { width: 270, height: [202, 460] },
            { width: 272, height: [220] },
            { width: 275, height: [300] },
            { width: 292, height: [30] },
            {
              width: 300,
              height: [
                31, 50, 90, 100, 200, 225, 250, 268, 413, 600, 618, 850, 1050,
              ],
            },
            { width: 310, height: [175] },
            { width: 315, height: [300] },
            { width: 320, height: [20, 50, 75, 100, 320, 360, 480] },
            { width: 336, height: [280, 600, 850] },
            { width: 350, height: [50, 200] },
            { width: 375, height: [20, 60, 150] },
            { width: 400, height: [225] },
            { width: 405, height: [303] },
            { width: 415, height: [20] },
            { width: 440, height: [225, 300] },
            { width: 468, height: [60] },
            { width: 550, height: [310, 480] },
            { width: 580, height: [400] },
            { width: 600, height: [400] },
            { width: 610, height: [100] },
            { width: 613, height: [460] },
            { width: 640, height: [90, 360, 480] },
            { width: 700, height: [400, 500] },
            { width: 728, height: [90, 120] },
            { width: 745, height: [90] },
            { width: 750, height: [30, 100, 200] },
            { width: 800, height: [600] },
            { width: 900, height: [240] },
            { width: 930, height: [180, 600] },
            { width: 950, height: [90] },
            { width: 954, height: [60] },
            { width: 960, height: [90] },
            { width: 970, height: [30, 66, 90, 250, 415, 550] },
            { width: 980, height: [90, 120] },
            { width: 1e3, height: [125] },
            { width: 1008, height: [150] },
            { width: 1140, height: [200] },
            { width: 1250, height: [155] },
            { width: 1280, height: [100] },
            { width: 1680, height: [900] },
          ]),
            (this.sizeCompare = (t, e) =>
              t.width > e.width ? 1 : t.width < e.width ? -1 : 0),
            (this.VideoStandardSizes = [
              { width: 150, height: [90] },
              { width: 270, height: [150] },
              { width: 300, height: [150, 340] },
              { width: 320, height: [570] },
              { width: 360, height: [100, 640] },
              { width: 375, height: [210, 670] },
              { width: 415, height: [740] },
              { width: 420, height: [240] },
              { width: 450, height: [250] },
              { width: 480, height: [270] },
              { width: 510, height: [290] },
              { width: 580, height: [330] },
              { width: 610, height: [340] },
              { width: 670, height: [380] },
              { width: 740, height: [410] },
              { width: 770, height: [1020] },
              { width: 780, height: [440] },
              { width: 800, height: [450] },
              { width: 900, height: [500] },
              { width: 1020, height: [580, 770] },
              { width: 1280, height: [720, 800] },
              { width: 1330, height: [660] },
              { width: 1370, height: [770] },
              { width: 1440, height: [900] },
              { width: 1540, height: [860] },
              { width: 1920, height: [1080] },
            ]
              .concat(this.DisplayStandardSizes)
              .sort(this.sizeCompare));
        }
        getSizesTable(t) {
          switch (t) {
            case 1:
            case 2:
              return this.VideoStandardSizes;
            case 0:
              return this.DisplayStandardSizes;
          }
        }
        getNearestAdSize(t, e, i) {
          const n = this.getSizesTable(e);
          switch (i) {
            case 5:
              return this.getNearestStandardAdSize(t, 5, n);
            case 20:
              return this.getNearestStandardAdSize(t, 20, n);
            default:
              return this.getNearestStandardAdSize(t, 15, n);
          }
        }
        isStandardAdSize(t, e, i) {
          return null != this.getNearestAdSize(t, e, i);
        }
        getNearestStandardAdSize(t, e, i) {
          let n = null;
          if (
            (null == t ? void 0 : t.width) &&
            (null == t ? void 0 : t.height)
          ) {
            const { width: s, height: r } = t,
              o = i.length;
            let a = 0,
              d = 0,
              c = Number.MAX_VALUE,
              l = Number.MAX_VALUE;
            for (; d < o && s + e >= i[d].width; ) {
              const t = Math.abs(s - i[d].width);
              if (t <= e) {
                a = i[d].height.length;
                let s = 0;
                for (; s < a && r + e >= i[d].height[s]; ) {
                  const o = Math.abs(r - i[d].height[s]);
                  if (o <= e)
                    if (t + o < c)
                      (l = i[d].width * i[d].height[s]),
                        (c = t + o),
                        (n = { width: i[d].width, height: i[d].height[s] });
                    else if (t + o == c) {
                      const t = i[d].width * i[d].height[s];
                      t < l &&
                        ((l = t),
                        (n = { width: i[d].width, height: i[d].height[s] }));
                    }
                  s++;
                }
              }
              d++;
            }
          }
          return n;
        }
      }
      (e.StandardSizesClass = i), (e.StandardSizes = new i());
    },
    9511: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.processTikTokSessionStart = void 0);
      const n = i(1360),
        s = i(9135),
        r = i(4112),
        o = /(?:^|[?#&])adsrv=([^&#?]*)/i,
        a = /(^|[?#&])tagtype=[^&#?]*/i,
        d = /(?:^|[?#&])mpt_si_ttdup=([^&#?]*)/i,
        c = /(?:^|[?#&])mpt_si_tttpl=([^&#?]*)/i,
        l = "__mrc_impression_id__";
      function u(t, e) {
        let i = 0;
        for (let e = 0; e < t.length; e++) i = (31 * i + t.charCodeAt(e)) | 0;
        return (i >>> 0) % 100 < e;
      }
      e.processTikTokSessionStart = function (t) {
        var e, i, h;
        if (!t.verificationParameters) return null;
        if (
          (null === (e = o.exec(t.verificationParameters)) || void 0 === e
            ? void 0
            : e[1]) !== s.TIKTOK_AD_SERVER_ID
        )
          return null;
        const v =
          null ===
            (h =
              null === (i = c.exec(t.verificationParameters)) || void 0 === i
                ? void 0
                : i[1]) || void 0 === h
            ? void 0
            : h.trim();
        v &&
          n.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
            n.DiagnosticParams.tiktokTemplateMarker,
            v
          );
        const p = (function (t) {
          var e, i;
          const n =
            null ===
              (i = null === (e = d.exec(t)) || void 0 === e ? void 0 : e[1]) ||
            void 0 === i
              ? void 0
              : i.trim();
          if (!n) return null;
          const s = n.toLowerCase();
          if (s === l) return null;
          return s;
        })(t.verificationParameters);
        if (!p) return null;
        if (
          (u(p, 5) &&
            n.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              n.DiagnosticParams.tiktokMrcImpressionId,
              p
            ),
          ((m = t.creativeType) !== r.OmidCreativeType.HTML_DISPLAY &&
            m !== r.OmidCreativeType.NATIVE_DISPLAY) ||
            !u(p, 100))
        )
          return null;
        var m;
        const f = t.verificationParameters.replace(a, "$1tagtype=display");
        return f === t.verificationParameters
          ? null
          : (n.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              n.DiagnosticParams.tiktokTagTypeOverride,
              "1"
            ),
            Object.assign(Object.assign({}, t), { verificationParameters: f }));
      };
    },
    5051: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.cancelScheduledTask =
          e.reportTaskTiming =
          e.trackPerformanceWhenExecuted =
          e.invokeWithPerformanceMeasures =
          e.scheduleTask =
          e.isBrowserSupported =
            void 0);
      const n = i(3283),
        s = i(8844),
        r = i(7102),
        o = i(3692);
      e.isBrowserSupported = () => {
        const t = [];
        return "function" == typeof t.filter && "function" == typeof t.forEach;
      };
      e.scheduleTask = (t, e = 0) => (0, o.setSafeTimeout)(t, e);
      e.invokeWithPerformanceMeasures = (t, i) => {
        const n = s.S.getPerformanceTimeNow(),
          r = i(),
          o = s.S.getPerformanceTimeNow();
        return (0, e.reportTaskTiming)(t, n, o), r;
      };
      e.trackPerformanceWhenExecuted = (t, i) => () =>
        (0, e.invokeWithPerformanceMeasures)(t, i);
      e.reportTaskTiming = ({ name: t }, i, s) => {
        (0, e.scheduleTask)(() => {
          r.k.dispatchEvent(
            r.DvEvents.performanceTaskTiming,
            new n.TaskTimingEventData([
              { name: t, startTime: i, duration: s - i },
            ])
          );
        });
      };
      e.cancelScheduledTask = (t) => {
        (0, o.clearSafeTimeout)(t);
      };
    },
    7535: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.createNormalisedGeometry = void 0),
        (e.createNormalisedGeometry = function (t) {
          if (t)
            return Object.assign(Object.assign({}, t), {
              width: "number" == typeof t.width ? Math.ceil(t.width) : t.width,
              height:
                "number" == typeof t.height ? Math.ceil(t.height) : t.height,
            });
        });
    },
    3692: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.clearSafeInterval =
          e.setSafeInterval =
          e.clearSafeTimeout =
          e.setSafeTimeout =
          e.runSafelyWhenInvoked =
            void 0);
      const n = i(8844),
        s = i(4112),
        r = i(1805),
        o = i(1906);
      e.runSafelyWhenInvoked = (t, e) => () => {
        try {
          t();
        } catch (i) {
          r.L.sendError(e, (0, o.toError)(i), null == t ? void 0 : t.name);
        }
      };
      e.setSafeTimeout = (t, i) =>
        n.S.getTaskManager().setTimeout(
          (0, e.runSafelyWhenInvoked)(
            t,
            s.ClientErrorType.AsynchronousTaskError
          ),
          i
        );
      e.clearSafeTimeout = (t) => {
        n.S.getTaskManager().clearTimeout(t);
      };
      e.setSafeInterval = (t, i) =>
        n.S.getTaskManager().setInterval(
          (0, e.runSafelyWhenInvoked)(
            t,
            s.ClientErrorType.AsynchronousTaskError
          ),
          i
        );
      e.clearSafeInterval = (t) => {
        n.S.getTaskManager().clearInterval(t);
      };
    },
    6431: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VOLUME_MUTE_LEVEL = e.VOLUME_UNSUPPORTED = void 0),
        (e.VOLUME_UNSUPPORTED = -1),
        (e.VOLUME_MUTE_LEVEL = 0);
      const i = new (class {
        getVolumeLevel(t, i) {
          return i
            ? e.VOLUME_MUTE_LEVEL
            : this.isVolumeLevelSupported(t)
            ? t
            : e.VOLUME_UNSUPPORTED;
        }
        isVolumeLevelSupported(t) {
          return "number" == typeof t && !isNaN(t) && t >= e.VOLUME_MUTE_LEVEL;
        }
        isVolumeLevelUnsupported(t) {
          return t === e.VOLUME_UNSUPPORTED;
        }
        isVolumeLevelMuted(t) {
          return t === e.VOLUME_MUTE_LEVEL;
        }
      })();
      e.default = i;
    },
    3187: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VideoPlaybackAdaptor = e.VideoPlaybackAdaptorClass = void 0);
      const n = i(8844);
      class s {
        getADCObject() {
          return n.O.workingWindow().ADCAdUnitEventManager;
        }
      }
      (e.VideoPlaybackAdaptorClass = s), (e.VideoPlaybackAdaptor = new s());
    },
    6669: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.DvVideoWrapper = void 0);
      e.DvVideoWrapper = class {
        constructor() {
          (this.subscriptionId = 1),
            (this.subscribers = {}),
            (this.previousEvents = {});
        }
        subscribe(t, e, i) {
          const n = [];
          if (this.previousEvents[e])
            for (const n of this.previousEvents[e])
              t.some((t) => t == n.eventName) && i(e, n);
          for (const s of t)
            this.subscribers[s + e] || (this.subscribers[s + e] = []),
              this.subscriptionId++,
              this.subscribers[s + e].push({
                func: i,
                subscriptionId: this.subscriptionId,
              }),
              n.push(this.subscriptionId);
          return n;
        }
        unsubscribe(t) {
          t.forEach((t) => {
            Object.keys(this.subscribers).forEach((e) => {
              this.subscribers[e] = this.subscribers[e].filter(
                (e) => e.subscriptionId != t
              );
            });
          });
        }
        publish(t, e, i) {
          if (
            (this.previousEvents[e] || (this.previousEvents[e] = []),
            this.previousEvents[e].push(i),
            t && e && this.subscribers[t + e] instanceof Array)
          )
            for (const n of this.subscribers[t + e]) {
              const t = n.func;
              t && "function" == typeof t && t(e, i);
            }
        }
      };
    },
    4642: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VpaidWrapper = e.VpaidWrapperClass = void 0);
      const n = i(8844),
        s = i(5196),
        r = i(6669),
        o = i(4112);
      class a {
        constructor() {
          this.initialized = !1;
        }
        init() {
          this.initialized ||
            ((this.currentWindow = n.O.currentWindow()),
            (this.adid = n.A.getAdID()),
            (this.initialized = !0));
        }
        start() {
          try {
            const t = { name: "VpaidWrapper", message: void 0 };
            if (1 !== n.A.getTagType()) return;
            if (
              (this.init(),
              this.adid
                ? ((this.dvVpaid = new r.DvVideoWrapper()),
                  (this.vpaidWrapper = this.getVpaidWrapper()),
                  this.vpaidWrapper
                    ? this.createAdAsset(this.adid)
                      ? this.subscribeToVpaidEvents(
                          this.vpaidEventHandler.bind(this)
                        )
                        ? this.handlePreviousEvents()
                        : (t.message = "Failed to subscribe vpaid events")
                      : (t.message = "Failed to create ad asset")
                    : (t.message = "Failed to get vpaid wrapper"))
                : (t.message = "Failed to get adid"),
              t.message)
            )
              return (
                (this.dvVpaid = void 0), { message: { dvp_vperr: t.message } }
              );
          } catch (t) {
            return (
              (this.dvVpaid = void 0),
              {
                error: {
                  clientErrorType: o.ClientErrorType.MeasurementError,
                  error: t,
                  messagePrefix: "VPaidWrapper",
                },
              }
            );
          }
        }
        getDvVpaid() {
          return this.dvVpaid;
        }
        isSupported() {
          try {
            return (
              this.init(),
              "function" == typeof n.O.workingWindow().getVPAIDAd ||
                (this.adid &&
                  "function" == typeof n.O.workingWindow()[this.adid])
            );
          } catch (t) {
            return !1;
          }
        }
        getIntegrationType() {
          return 1;
        }
        getVpaidWrapper() {
          try {
            if ("function" == typeof n.O.workingWindow()[this.adid]) {
              const t = n.O.workingWindow()[this.adid]();
              return (t.viewabilityIntegrationType = 2), t;
            }
          } catch (t) {
            return;
          }
        }
        getPrevEvents() {
          return this.vpaidWrapper.getPreviousEvents
            ? "function" == typeof this.vpaidWrapper.getPreviousEvents
              ? this.vpaidWrapper.getPreviousEvents()
              : this.vpaidWrapper.getPreviousEvents
            : [];
        }
        handlePreviousEvents() {
          const t = this.getPrevEvents();
          for (const e of t) this.vpaidEventHandler(e);
        }
        getAdVolume() {
          return this.vpaidWrapper.getAdVolume();
        }
        getAdMute() {
          const t = this.getPlayer();
          if (t) {
            const { muted: e } = t;
            if (void 0 === e) return 0;
            if ("boolean" == typeof e) return Number(e);
          }
          return o.NOT_FOUND_OR_ERROR;
        }
        vpaidEventHandler(t) {
          if (this.dvVpaid) {
            const e = {
              eventName: t,
              eventTime: void 0,
              viewabilityResult: {
                volume: this.getAdVolume(),
                muted: this.getAdMute(),
                adSkippableState: this.getAdSkippableState(),
              },
            };
            this.dvVpaid.publish(t, this.adid, e);
          }
        }
        subscribeToVpaidEvents(t) {
          try {
            return (
              this.vpaidWrapper.subscribe(function () {
                t("AdLoaded");
              }, "AdLoaded"),
              this.vpaidWrapper.subscribe(function () {
                t("AdImpression");
              }, "AdImpression"),
              this.vpaidWrapper.subscribe(function () {
                t("AdStopped");
              }, "AdStopped"),
              this.vpaidWrapper.subscribe(function () {
                t("AdError");
              }, "AdError"),
              this.vpaidWrapper.subscribe(function () {
                t("AdStarted");
              }, "AdStarted"),
              this.vpaidWrapper.subscribe(function () {
                t("AdSkipped");
              }, "AdSkipped"),
              this.vpaidWrapper.subscribe(function () {
                t("AdPaused");
              }, "AdPaused"),
              this.vpaidWrapper.subscribe(function () {
                t("AdSizeChange");
              }, "AdSizeChange"),
              this.vpaidWrapper.subscribe(function () {
                t("AdPlaying");
              }, "AdPlaying"),
              this.vpaidWrapper.subscribe(function () {
                t("AdExpandedChange");
              }, "AdExpandedChange"),
              this.vpaidWrapper.subscribe(function () {
                t("AdSkippableStateChange");
              }, "AdSkippableStateChange"),
              this.vpaidWrapper.subscribe(function () {
                t("AdLinearChange");
              }, "AdLinearChange"),
              this.vpaidWrapper.subscribe(function () {
                t("AdVideoStart");
              }, "AdVideoStart"),
              this.vpaidWrapper.subscribe(function () {
                t("AdUserAcceptInvitation");
              }, "AdUserAcceptInvitation"),
              this.vpaidWrapper.subscribe(function () {
                t("AdUserClose");
              }, "AdUserClose"),
              this.vpaidWrapper.subscribe(function () {
                t("AdUserMinimize");
              }, "AdUserMinimize"),
              this.vpaidWrapper.subscribe(function () {
                t("AdClickThru");
              }, "AdClickThru"),
              this.vpaidWrapper.subscribe(function () {
                t("AdInteraction");
              }, "AdInteraction"),
              this.vpaidWrapper.subscribe(function () {
                t("AdDurationChange");
              }, "AdDurationChange"),
              this.vpaidWrapper.subscribe(function () {
                t("AdRemainingTimeChange");
              }, "AdRemainingTimeChange"),
              this.vpaidWrapper.subscribe(function () {
                t("AdVolumeChange");
              }, "AdVolumeChange"),
              this.vpaidWrapper.subscribe(function () {
                t("AdVideoFirstQuartile");
              }, "AdVideoFirstQuartile"),
              this.vpaidWrapper.subscribe(function () {
                t("AdVideoMidpoint");
              }, "AdVideoMidpoint"),
              this.vpaidWrapper.subscribe(function () {
                t("AdVideoThirdQuartile");
              }, "AdVideoThirdQuartile"),
              this.vpaidWrapper.subscribe(function () {
                t("AdVideoComplete");
              }, "AdVideoComplete"),
              !0
            );
          } catch (t) {
            return !1;
          }
        }
        getPlayer() {
          let t;
          try {
            (t =
              "function" == typeof this.vpaidWrapper.getPlayer
                ? this.vpaidWrapper.getPlayer()
                : this.vpaidWrapper.getPlayer),
              (0, n.smartInstanceof)(t, "HTMLElement", this.currentWindow) ||
                (t = this.vpaidWrapper.getSlot());
          } catch (e) {
            t = void 0;
          }
          return t;
        }
        getAdSkippableState() {
          let t;
          try {
            t =
              "function" == typeof this.vpaidWrapper.getAdSkippableState
                ? this.vpaidWrapper.getAdSkippableState()
                : this.vpaidWrapper.adSkippableState;
          } catch (t) {}
          return t;
        }
        getAdDuration() {
          try {
            return "function" == typeof this.vpaidWrapper.getAdDuration
              ? this.vpaidWrapper.getAdDuration()
              : this.vpaidWrapper.adDuration;
          } catch (t) {}
        }
        getExecuteDVClientCallback() {
          if ("function" == typeof this.vpaidWrapper.executeDVClientCallback)
            return this.vpaidWrapper.executeDVClientCallback;
        }
        createAdAsset(t) {
          const e = this.getPlayer(),
            i = this.getAdDuration(),
            n = this.getAdSkippableState();
          if (e) {
            const r = this.getExecuteDVClientCallback(),
              o = new s.AdAsset(t, e, i, n, r);
            return (
              (this.dvVpaid.asset = o),
              (this.dvVpaid.viewabilityIntegrationType =
                this.vpaidWrapper.viewabilityIntegrationType),
              !0
            );
          }
          return !1;
        }
      }
      (e.VpaidWrapperClass = a), (e.VpaidWrapper = new a());
    },
    251: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.initialize = void 0);
      const n = i(1805);
      e.initialize = (t) => {
        const e = t.start();
        null != (null == e ? void 0 : e.error)
          ? n.L.sendError(
              e.error.clientErrorType,
              e.error.error,
              e.error.messagePrefix,
              e.error.extraQueryParams
            )
          : null != (null == e ? void 0 : e.message) &&
            n.L.sendMessage(e.message);
      };
    },
    9135: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.TIKTOK_AD_SERVER_ID =
          e.CELTRA_AD_SERVER_ID =
          e.DFA_AD_SERVER_ID =
            void 0),
        (e.DFA_AD_SERVER_ID = "1"),
        (e.CELTRA_AD_SERVER_ID = "179"),
        (e.TIKTOK_AD_SERVER_ID = "198");
    },
    4054: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdColonyMethod = e.AdColonyMethodClass = void 0);
      const n = i(7535),
        s = i(4112),
        r = i(5473),
        o = i(8844);
      class a {
        constructor() {
          this.exposureChangeRegistered = !1;
        }
        isSupported(t) {
          let e, i, n, s, o;
          try {
            if (!r.MraidWrapper.isSupported()) return !1;
            o = r.MraidWrapper.runMraidFunctionSafely("getSDKVersion");
            const t = o.split(".");
            ([e, i] = t),
              (n = e > 3 || (3 == e && i >= 4)),
              (s = r.MraidWrapper.isAdColony());
          } catch (t) {}
          return !(!n || !s) && ((t.mraidVersion = o.toString()), !0);
        }
        registerExposureChange() {
          this.exposureChangeRegistered ||
            (r.MraidWrapper.runMraidRegisterSafely(
              "exposureChange",
              this.handleExposureChangeEvent.bind(this)
            ),
            (this.exposureChangeRegistered = !0));
        }
        getAdCandidateAssets(t) {
          if (r.MraidWrapper.getIsMraidReady())
            return (
              this.registerExposureChange(),
              {
                viewportSize: this.getViewportSize(),
                screenSize: this.getScreenSize(),
                adGeometric: (0, n.createNormalisedGeometry)(
                  r.MraidWrapper.runMraidFunctionSafely("getDefaultPosition")
                ),
                percentage: this.viewabilityPercentage,
                viewabilityCalculationType: this.getMethodId(),
              }
            );
        }
        getViewportSize() {
          return r.MraidWrapper.runMraidFunctionSafely("getScreenSize");
        }
        getScreenSize() {
          let t, e;
          const i = this.getViewportSize();
          return (
            ({ height: t, width: e } = i || o.S.getScreenSize()),
            { height: t, width: e }
          );
        }
        getMethodId() {
          return s.ViewabilityCalculationTypes.AdColonyMraid;
        }
        destroyAdCandidateMethod() {}
        handleExposureChangeEvent(t) {
          this.viewabilityPercentage = t;
        }
      }
      (e.AdColonyMethodClass = a), (e.AdColonyMethod = new a());
    },
    2285: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AllScenarioIntersectionObserverMethod =
          e.AllScenarioIntersectionObserverMethodClass =
            void 0);
      const n = i(7535),
        s = i(8844),
        r = i(4112),
        o = i(2654);
      class a extends o.WebCalculationMethodBase {
        constructor() {
          super(...arguments),
            (this.threshold = [
              0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1,
            ]);
        }
        isSupported(t) {
          return this.isIntersectionObserverSupported(t.windowElement);
        }
        isIntersectionObserverSupported(t) {
          return (
            !!t &&
            "IntersectionObserver" in t &&
            "IntersectionObserverEntry" in t &&
            "intersectionRatio" in t.IntersectionObserverEntry.prototype
          );
        }
        getAdCandidateAssets(t) {
          const e = t.domElement,
            i = this.getWrapperSize(t);
          this.init(t);
          const r = (0, s.getBoundingClientRect)(e),
            o = this.getAdViewablePercentage(t),
            a = this.getAdPosition(t);
          return {
            viewportSize: this.getViewportSize(t.windowElement),
            wrapperSize: i,
            screenSize: this.getScreenSize(),
            adGeometric: (0, n.createNormalisedGeometry)({
              x: a.left,
              y: a.top,
              width: r.width,
              height: r.height,
            }),
            percentage: o,
            viewabilityCalculationType: this.getMethodId(),
          };
        }
        getViewportSize(t) {
          return s.S.getOuterViewport(t);
        }
        getMethodId() {
          return r.ViewabilityCalculationTypes.AllScenarioIntersectionObserver;
        }
        destroyAdCandidateMethod(t) {
          t.intersectionObserverObj &&
            t.intersectionObserverObj.unobserve(t.domElement);
        }
        getAdViewablePercentage(t) {
          var e;
          return (
            null === (e = t.intersectionObserverData) || void 0 === e
              ? void 0
              : e.intersectionRatio
          )
            ? 100 * t.intersectionObserverData.intersectionRatio
            : 0;
        }
        getAdPosition(t) {
          var e;
          let i = { top: 0, left: 0 };
          return (
            (null === (e = t.intersectionObserverData) || void 0 === e
              ? void 0
              : e.intersectionRect) &&
              (i = {
                top: t.intersectionObserverData.intersectionRect.top,
                left: t.intersectionObserverData.intersectionRect.left,
              }),
            i
          );
        }
        init(t) {
          if (t.intersectionObserverObj) return;
          const e = t.domElement,
            i = this.visibilityChangeCallback.bind(this, t);
          (t.intersectionObserverObj = new t.windowElement.IntersectionObserver(
            i,
            { threshold: this.threshold }
          )),
            t.intersectionObserverObj.observe(e);
        }
        visibilityChangeCallback(t, e) {
          e.forEach((e) => (t.intersectionObserverData = e));
        }
      }
      (e.AllScenarioIntersectionObserverMethodClass = a),
        (e.AllScenarioIntersectionObserverMethod = new a());
    },
    2202: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AmpIntersectionObserverMethod =
          e.AmpIntersectionObserverMethodClass =
            void 0);
      const n = i(7535),
        s = i(8844),
        r = i(4112),
        o = i(2654);
      class a extends o.WebCalculationMethodBase {
        isSupported(t) {
          var e;
          const i = t.windowElement,
            n =
              s.BrowserDetector.getBrowserId() != r.Browser.IE ||
              parseInt(s.BrowserDetector.getBrowserVersion()) > 11,
            o = 128 == (128 & s.O.getScenarioType());
          return (
            n &&
            o &&
            !!(null === (e = i.context) || void 0 === e
              ? void 0
              : e.observeIntersection)
          );
        }
        getAdCandidateAssets(t) {
          const e = t.domElement,
            i = this.getWrapperSize(t);
          this.init(t);
          const r = (0, s.getBoundingClientRect)(e),
            o = this.getAdViewablePercentage(t),
            a = this.getAdPosition(t);
          return {
            viewportSize: this.getViewportSize(t.windowElement),
            wrapperSize: i,
            screenSize: this.getScreenSize(),
            adGeometric: (0, n.createNormalisedGeometry)({
              x: a.left,
              y: a.top,
              width: r.width,
              height: r.height,
            }),
            percentage: o,
            viewabilityCalculationType: this.getMethodId(),
          };
        }
        getViewportSize(t) {
          return s.S.getOuterViewport(t);
        }
        getMethodId() {
          return r.ViewabilityCalculationTypes.AmpIntersectionObserver;
        }
        destroyAdCandidateMethod(t) {
          t.ampIntersectionObserverStopFunction &&
            t.ampIntersectionObserverStopFunction();
        }
        getAdViewablePercentage(t) {
          return t.intersectionObserverData
            ? 100 * t.intersectionObserverData.intersectionRatio
            : 0;
        }
        getAdPosition(t) {
          if (!t.intersectionObserverData) return { top: 0, left: 0 };
          const e = t.intersectionObserverData.boundingClientRect;
          return { top: e.top, left: e.left };
        }
        init(t) {
          if (t.ampIntersectionObserverStopFunction) return;
          const e = t.windowElement,
            i = this.visibilityChangeCallback.bind(this, t);
          t.ampIntersectionObserverStopFunction =
            e.context.observeIntersection(i);
        }
        visibilityChangeCallback(t, e) {
          e.forEach((e) => (t.intersectionObserverData = e));
        }
      }
      (e.AmpIntersectionObserverMethodClass = a),
        (e.AmpIntersectionObserverMethod = new a());
    },
    5240: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = () => {
          (window.isReady = !1), (window.animateFrameRate = 0);
          let t = 0,
            e = 0;
          const i = function (e) {
            t++, requestAnimationFrame(i);
          };
          requestAnimationFrame(i),
            setInterval(() => {
              t < 10 && requestAnimationFrame(i),
                (window.animateFrameRate = t - e),
                (e = t);
            }, 100),
            setTimeout(() => {
              window.isReady = !0;
            }, 250);
        });
    },
    5708: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.GeometricMethod = e.GeometricMethodClass = void 0);
      const n = i(7535),
        s = i(8844),
        r = i(4112),
        o = i(1805),
        a = i(2654);
      class d extends a.WebCalculationMethodBase {
        isSupported() {
          return (3 & s.O.getScenarioType()) > 0;
        }
        getAdCandidateAssets(t) {
          const e = t.domElement,
            i = t.windowElement,
            r = this.getAssetVisibleDimension(e, i),
            o = this.getAssetPercentageInViewRelativeToDirectParent(e, i),
            a = this.getViewportSize(),
            d = this.getWrapperSize(t),
            c = this.getOffScreenAssetVisibleDimension(r, i),
            l = this.getOffScreenViewportSize(i);
          let u = (0, s.getElementVisiblePercentage)(r, a);
          u && o && (u *= o);
          const h = (0, s.getElementVisiblePercentage)(c, l);
          return {
            viewportSize: a,
            wrapperSize: d,
            screenSize: this.getScreenSize(),
            adGeometric: (0, n.createNormalisedGeometry)({
              y: r.top,
              x: r.left,
              width: r.width,
              height: r.height,
            }),
            percentage: u,
            offScreenPercentage: h,
            viewabilityCalculationType: this.getMethodId(),
          };
        }
        getViewportSize() {
          return s.S.getInnerViewport();
        }
        getMethodId() {
          return r.ViewabilityCalculationTypes.Geometric;
        }
        getBoundariesViewability(t) {
          const e = t.domElement,
            i = this.getAssetVisibleDimension(e, t.windowElement),
            n = this.getViewportSize(),
            s = { topLeft: !0, topRight: !0, bottomLeft: !0, bottomRight: !0 };
          return (
            (i.top < 0 || i.top > n.height) && (s.topLeft = s.topRight = !1),
            (i.bottom < 0 || i.bottom > n.height) &&
              (s.bottomLeft = s.bottomRight = !1),
            (i.left < 0 || i.left > n.width) && (s.bottomLeft = s.topLeft = !1),
            (i.right < 0 || i.right > n.width) &&
              (s.bottomRight = s.topRight = !1),
            s
          );
        }
        getOffScreenViewportSize(t) {
          const e = {
              width: this.getViewportSize().width,
              height: this.getViewportSize().height,
            },
            i = s.S.getViewportAssetsRelativeToScreen(t),
            n = s.S.getOuterViewport(t).height - e.height,
            r = i.top + n,
            o = s.S.getScreenSize();
          return (
            i.left < 0
              ? (e.width += i.left)
              : i.left > 0 &&
                i.left + e.width > o.width &&
                (e.width = o.width - i.left),
            r > 0 && r + e.height > o.height && (e.height = o.height - r),
            e
          );
        }
        getAssetVisibleDimension(t, e) {
          let i = { width: 0, height: 0, left: 0, right: 0, top: 0, bottom: 0 };
          const n = s.O.getWindowParent(e);
          try {
            if (
              t &&
              ((i = this.getElementPositionRelativeToViewport(t, e)), e != n)
            ) {
              const t = this.getAssetVisibleDimension(e.frameElement, n);
              (i.bottom = Math.min(i.bottom, t.bottom)),
                (i.top = Math.max(i.top, t.top)),
                (i.right = Math.min(i.right, t.right)),
                (i.left = Math.max(i.left, t.left)),
                (i.width = i.right - i.left),
                (i.height = i.bottom - i.top);
            }
          } catch (t) {}
          return i;
        }
        getAssetPercentageInViewRelativeToDirectParent(t, e) {
          try {
            const i = this.getAssetVisibleDimension(t, e);
            if (t) {
              const e = (0, s.getBoundingClientRect)(t),
                n = e.right - e.left,
                r = (e.bottom - e.top) * n;
              if (r <= 0) return;
              return (i.height * i.width) / r;
            }
          } catch (t) {
            o.L.sendError(
              r.ClientErrorType.MeasurementError,
              t,
              "percentage_in_view_geometric_calculation_err"
            );
          }
        }
        getOffScreenAssetVisibleDimension(t, e) {
          const i = s.S.getViewportAssetsRelativeToScreen(e).left,
            n = {
              left: t.left,
              right: t.right,
              top: t.top,
              bottom: t.bottom,
              height: t.height,
              width: t.width,
            };
          return i < 0 && ((n.left += i), (n.right += i)), n;
        }
        getElementPositionRelativeToViewport(t, e) {
          let i = { left: 0, right: 0, top: 0, bottom: 0, width: 0, height: 0 };
          const n = s.O.getWindowParent(e),
            r = (0, s.getBoundingClientRect)(t);
          return (
            e != n &&
              (i = this.getElementPositionRelativeToViewport(
                e.frameElement,
                n
              )),
            (i = {
              left: r.left + i.left,
              right: r.right + i.left,
              top: r.top + i.top,
              bottom: r.bottom + i.top,
              width: Math.ceil(r.width),
              height: Math.ceil(r.height),
            }),
            i
          );
        }
      }
      (e.GeometricMethodClass = d), (e.GeometricMethod = new d());
    },
    776: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.IntersectionObserverMethod = e.IntersectionObserverMethodClass =
          void 0);
      const n = i(7535),
        s = i(8844),
        r = i(4112),
        o = i(2654);
      class a extends o.WebCalculationMethodBase {
        constructor() {
          super(...arguments),
            (this.threshold = [
              0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1,
            ]);
        }
        isSupported(t) {
          return (
            (128 & s.O.getScenarioType()) > 0 &&
            this.isIntersectionObserverSupported(t.windowElement)
          );
        }
        isIntersectionObserverSupported(t) {
          return (
            "IntersectionObserver" in t &&
            "IntersectionObserverEntry" in t &&
            "intersectionRatio" in t.IntersectionObserverEntry.prototype
          );
        }
        getAdCandidateAssets(t) {
          const e = t.domElement,
            i = this.getWrapperSize(t);
          this.init(t);
          const r = (0, s.getBoundingClientRect)(e),
            o = this.getAdViewablePercentage(t),
            a = this.getAdPosition(t);
          return {
            viewportSize: this.getViewportSize(t.windowElement),
            wrapperSize: i,
            screenSize: this.getScreenSize(),
            adGeometric: (0, n.createNormalisedGeometry)({
              x: a.left,
              y: a.top,
              width: r.width,
              height: r.height,
            }),
            percentage: o,
            viewabilityCalculationType: this.getMethodId(),
          };
        }
        getViewportSize(t) {
          return s.S.getOuterViewport(t);
        }
        getMethodId() {
          return r.ViewabilityCalculationTypes.IntersectionObserver;
        }
        destroyAdCandidateMethod(t) {
          t.intersectionObserverObj &&
            t.intersectionObserverObj.unobserve(t.domElement);
        }
        getAdViewablePercentage(t) {
          var e;
          return (
            null === (e = t.intersectionObserverData) || void 0 === e
              ? void 0
              : e.intersectionRatio
          )
            ? 100 * t.intersectionObserverData.intersectionRatio
            : 0;
        }
        getAdPosition(t) {
          var e;
          let i = { top: 0, left: 0 };
          return (
            (null === (e = t.intersectionObserverData) || void 0 === e
              ? void 0
              : e.intersectionRect) &&
              (i = {
                top: t.intersectionObserverData.intersectionRect.top,
                left: t.intersectionObserverData.intersectionRect.left,
              }),
            i
          );
        }
        init(t) {
          if (t.intersectionObserverObj) return;
          const e = t.domElement,
            i = this.visibilityChangeCallback.bind(this, t);
          (t.intersectionObserverObj = new t.windowElement.IntersectionObserver(
            i,
            { threshold: this.threshold }
          )),
            t.intersectionObserverObj.observe(e);
        }
        visibilityChangeCallback(t, e) {
          e.forEach((e) => (t.intersectionObserverData = e));
        }
      }
      (e.IntersectionObserverMethodClass = a),
        (e.IntersectionObserverMethod = new a());
    },
    7662: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.Mraid3Method = e.Mraid3MethodClass = void 0);
      const n = i(7535),
        s = i(4112),
        r = i(5473),
        o = i(8844);
      class a {
        constructor() {
          this.exposureChangeRegistered = !1;
        }
        isSupported(t) {
          let e, i;
          try {
            (i = r.MraidWrapper.runMraidFunctionSafely("getVersion")),
              ([e] = i.split("."));
          } catch (t) {}
          return (
            !(!r.MraidWrapper.isSupported() || "3" != e) &&
            ((t.mraidVersion = i), !0)
          );
        }
        registerExposureChange() {
          this.exposureChangeRegistered ||
            (r.MraidWrapper.runMraidRegisterSafely(
              "exposureChange",
              this.handleExposureChangeEvent.bind(this)
            ),
            (this.exposureChangeRegistered = !0));
        }
        handleExposureChangeEvent(t) {
          this.viewabilityPercentage = t.exposedPercentage;
        }
        getAdCandidateAssets(t) {
          if (r.MraidWrapper.getIsMraidReady())
            return (
              this.registerExposureChange(),
              {
                viewportSize: this.getViewportSize(),
                screenSize: this.getScreenSize(),
                adGeometric: (0, n.createNormalisedGeometry)(
                  r.MraidWrapper.runMraidFunctionSafely("getDefaultPosition")
                ),
                percentage:
                  null != this.viewabilityPercentage
                    ? this.viewabilityPercentage
                    : r.MraidWrapper.getAdViewablePercentage(),
                viewabilityCalculationType: this.getMethodId(),
              }
            );
        }
        getViewportSize() {
          return r.MraidWrapper.runMraidFunctionSafely("getScreenSize");
        }
        getScreenSize() {
          let t, e;
          const i = this.getViewportSize();
          return (
            ({ height: t, width: e } = i || o.S.getScreenSize()),
            { height: t, width: e }
          );
        }
        getMethodId() {
          return s.ViewabilityCalculationTypes.Mraid3;
        }
        destroyAdCandidateMethod() {}
      }
      (e.Mraid3MethodClass = a), (e.Mraid3Method = new a());
    },
    7854: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.MraidMethod = e.MraidMethodClass = void 0);
      const n = i(7535),
        s = i(4112),
        r = i(5473),
        o = i(8844);
      class a {
        isSupported(t) {
          return (
            !!r.MraidWrapper.isSupported() &&
            ((t.mraidVersion =
              r.MraidWrapper.runMraidFunctionSafely("getVersion")),
            !0)
          );
        }
        getAdCandidateAssets(t) {
          if (r.MraidWrapper.getIsMraidReady()) {
            const t = (0, n.createNormalisedGeometry)(
                r.MraidWrapper.runMraidFunctionSafely("getDefaultPosition")
              ),
              e = {
                width: null == t ? void 0 : t.width,
                height: null == t ? void 0 : t.height,
              };
            return {
              viewportSize: this.getViewportSize(),
              wrapperSize: e,
              screenSize: this.getScreenSize(),
              adGeometric: t,
              percentage: r.MraidWrapper.getAdViewablePercentage(),
              viewabilityCalculationType: this.getMethodId(),
            };
          }
        }
        getViewportSize() {
          return r.MraidWrapper.runMraidFunctionSafely("getScreenSize");
        }
        getScreenSize() {
          let t, e;
          const i = this.getViewportSize();
          return (
            ({ height: t, width: e } = i || o.S.getScreenSize()),
            { height: t, width: e }
          );
        }
        getMethodId() {
          return s.ViewabilityCalculationTypes.Mraid;
        }
        destroyAdCandidateMethod() {}
      }
      (e.MraidMethodClass = a), (e.MraidMethod = new a());
    },
    9021: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.OmidMethod = e.OmidMethodClass = void 0);
      const n = i(7535),
        s = i(4112),
        r = i(8844),
        o = i(214),
        a = i(7102),
        d = i(3283),
        c = i(1906),
        l = i(1360);
      class u {
        isSupported(t) {
          return r.omidAdapter.isSupported();
        }
        getAdCandidateAssets(t) {
          this.init(t);
          const e = t.omidViewport,
            i = t.omidWrapperSize;
          let n,
            s,
            r,
            c = 0;
          if (
            (t.omidAdView &&
              ((n = t.omidAdView.percentageInView),
              (s = t.omidAdView.geometry),
              (r = t.omidAdView.reasons)),
            Array.isArray(r) && r.length)
          ) {
            r.forEach((t) => (c |= o.OmidGeometryReasonLog[t]));
            const e = t.omidGeometryReasonsBitWise | c;
            c &&
              e != t.omidGeometryReasonsBitWise &&
              ((t.omidGeometryReasonsBitWise = e),
              a.k.dispatchEvent(
                a.DvEvents.reportData,
                new d.AdCandidateEventData(t)
              ));
          }
          return {
            viewportSize: e,
            screenSize: this.getScreenSize(null, t),
            adGeometric: s,
            percentage: n,
            viewabilityCalculationType: this.getMethodId(),
            wrapperSize: i,
          };
        }
        getViewportSize(t, e) {
          return e.omidViewport;
        }
        getScreenSize(t, e) {
          let i, n;
          const s = this.getViewportSize(null, e);
          return (
            ({ height: i, width: n } = s || r.S.getScreenSize()),
            { height: i, width: n }
          );
        }
        getMethodId() {
          return s.ViewabilityCalculationTypes.Omid;
        }
        destroyAdCandidateMethod() {}
        init(t) {
          t.omidInitialized ||
            ((t.omidInitialized = !0),
            ["geometryChange", "impression"].forEach((e) => {
              r.omidAdapter.addEventListener(
                e,
                this.geometryChangeCallback.bind(this, t, e)
              );
            }));
        }
        geometryChangeCallback(t, e, i) {
          if (null == i ? void 0 : i.data) {
            const { data: s } = i;
            if (s.adView) {
              const r = (0, n.createNormalisedGeometry)(s.adView.geometry);
              (t.omidAdView = Object.assign(Object.assign({}, s.adView), {
                geometry: r,
              })),
                "geometryChange" === e &&
                  !t.omidFirstAdSizeFromGeometryMs &&
                  s.adView.geometry &&
                  s.adView.geometry.width > 0 &&
                  s.adView.geometry.height > 0 &&
                  ((t.omidFirstAdSizeFromGeometryMs =
                    c.Utilities.getTimeDiff()),
                  (t.omidMeasuredElementType = this.extractMeasuredElementType(
                    s.adView
                  )),
                  (t.omidWrapperSize = this.extractWrapperSize(i)),
                  l.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
                    l.DiagnosticParams.omidFirstAdSizeFromGeometryMs,
                    t.omidFirstAdSizeFromGeometryMs
                  ));
            }
            s.viewport && (t.omidViewport = s.viewport);
          }
        }
        extractWrapperSize(t) {
          var e;
          try {
            const i =
                null === (e = null == t ? void 0 : t.data) || void 0 === e
                  ? void 0
                  : e.adView,
              n = null == i ? void 0 : i.measuringElement,
              s = ({ height: t, width: e } = {}) => ({ height: t, width: e });
            if (n) return s(i.containerGeometry);
            const r = null == i ? void 0 : i.geometry;
            if (r) return s(r);
          } catch (t) {}
        }
        extractMeasuredElementType(t) {
          try {
            return !0 === (null == t ? void 0 : t.measuringElement) ? 1 : 2;
          } catch (t) {
            return 0;
          }
        }
      }
      (e.OmidMethodClass = u), (e.OmidMethod = new u());
    },
    3928: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ResourceBased = e.ResourceBasedClass = void 0);
      const n = i(7535),
        s = i(8844),
        r = i(1906),
        o = i(4112),
        a = i(4298),
        d = i(5240),
        c = i(2654),
        l = i(1360);
      class u extends c.WebCalculationMethodBase {
        isSupported() {
          var t;
          const e =
            ((s.BrowserDetector.getBrowserId() == o.Browser.Safari ||
              s.BrowserDetector.getBrowserId() == o.Browser.SafariWebView) &&
              !/^[3-8]/.test(s.BrowserDetector.getBrowserVersion())) ||
            ((s.BrowserDetector.getBrowserId() == o.Browser.Chrome ||
              s.BrowserDetector.getBrowserId() == o.Browser.ChromeWebView) &&
              parseInt(s.BrowserDetector.getBrowserVersion()) >= 50);
          if (128 != (128 & s.O.getScenarioType()) || !e) return !1;
          const i = s.O.workingWindow(),
            n = s.O.workingDocument(i),
            r = s.O.workingBody(n);
          if (!i || !n || !r) return !1;
          let a = null,
            d = !1;
          try {
            (a = (0, s.createElement)("iframe")),
              (a.style.position = "absolute"),
              (a.style.visibility = "hidden"),
              (a.style.width = "0px"),
              (a.style.height = "0px"),
              r.appendChild(a),
              a.contentDocument && (d = !0);
          } catch (t) {
            d = !1;
          } finally {
            null === (t = null == a ? void 0 : a.parentElement) ||
              void 0 === t ||
              t.removeChild(a);
          }
          return d;
        }
        getAdCandidateAssets(t) {
          t.resourceBasedBeacons || this.createFrameBeacons(t);
          const e = this.getWrapperSize(t),
            i = t.domElement,
            r = (0, s.getBoundingClientRect)(i);
          let o;
          if (this.checkBeaconsMechanism(t)) {
            const e = t.resourceBasedBeacons[0];
            o = a.BeaconsAdaptor.getElementVisiblePercentageWithBeacons(
              t.resourceBasedBeacons,
              this.isBeaconViewable.bind(this, e)
            );
          }
          return {
            viewportSize: this.getViewportSize(t.windowElement),
            wrapperSize: e,
            screenSize: this.getScreenSize(),
            adGeometric: (0, n.createNormalisedGeometry)({
              x: 0,
              y: 0,
              width: null == r ? void 0 : r.width,
              height: null == r ? void 0 : r.height,
            }),
            percentage: o,
            viewabilityCalculationType: this.getMethodId(),
          };
        }
        getViewportSize(t) {
          return s.S.getOuterViewport(t);
        }
        getMethodId() {
          return o.ViewabilityCalculationTypes.ResourceBased;
        }
        destroyAdCandidateMethod(t) {
          if (!t.resourceBasedBeacons) return;
          const e = t.resourceBasedBeacons[0].parentElement,
            i = s.O.workingDocument(t.windowElement);
          s.O.workingBody(i).removeChild(e), (t.resourceBasedBeacons = null);
        }
        getBoundariesViewability(t) {
          t.resourceBasedBeacons || this.createFrameBeacons(t);
          const e = {
            topLeft: !1,
            topRight: !1,
            bottomLeft: !1,
            bottomRight: !1,
          };
          if (!this.checkBeaconsMechanism(t)) return e;
          const i = t.resourceBasedBeacons[0];
          for (let n = 1; n <= 4; n++) {
            const s = t.resourceBasedBeacons[n];
            if (this.isBeaconViewable(i, s))
              switch (n) {
                case 1:
                  e.topLeft = !0;
                  break;
                case 2:
                  e.topRight = !0;
                  break;
                case 3:
                  e.bottomLeft = !0;
                  break;
                case 4:
                  e.bottomRight = !0;
              }
          }
          return e;
        }
        isBeaconViewable(t, e) {
          const i = s.O.getIframeWindow(t).animateFrameRate;
          return s.O.getIframeWindow(e).animateFrameRate - i > 5;
        }
        createFrameBeacons(t) {
          try {
            t.resourceBasedBeacons = [];
            const e = s.O.workingDocument(t.windowElement),
              i = (0, s.createElement)("div");
            s.O.workingBody(e).appendChild(i);
            const n = [];
            r.Utilities.times(14, () => {
              const t = (0, s.createElement)("iframe");
              (t.width = (8).toString()),
                (t.height = (8).toString()),
                (t.style.position = "absolute"),
                (t.frameBorder = "0"),
                (t.style.visibility = "hidden"),
                i.appendChild(t);
              const e = t.contentDocument.createElement("script");
              (e.innerHTML = `(${d.default.toString()})()`),
                t.contentDocument.body.appendChild(e),
                n.push(t);
            }),
              (t.resourceBasedBeacons = n),
              a.BeaconsAdaptor.positionBeacons(t.domElement, n, 8);
          } catch (t) {
            throw (
              (Math.random() <= 0.1 &&
                l.DiagnosticParamsReporterSingleton.reportOnce(
                  l.DiagnosticParams.errorStackTrace,
                  t.stack
                ),
              t)
            );
          }
        }
        checkBeaconsMechanism(t) {
          if (!t.resourceBasedBeacons || 0 == t.resourceBasedBeacons.length)
            return !1;
          const e = t.resourceBasedBeacons[0],
            i = s.O.getIframeWindow(e),
            n = null == i ? void 0 : i.animateFrameRate;
          return (null == i ? void 0 : i.isReady) && n < 7;
        }
      }
      (e.ResourceBasedClass = u), (e.ResourceBased = new u());
    },
    5163: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ScreenGeometricMethod = e.ScreenGeometricMethodClass = void 0);
      const n = i(7535),
        s = i(8844),
        r = i(4112),
        o = i(2654);
      class a extends o.WebCalculationMethodBase {
        isSupported(t) {
          const e = t.windowElement,
            i = 128 == (128 & s.O.getScenarioType()),
            n =
              s.BrowserDetector.getBrowserId() == r.Browser.IE &&
              null != e.screenTop &&
              null != e.screenLeft,
            o =
              s.BrowserDetector.getBrowserId() == r.Browser.Firefox &&
              null != e.mozInnerScreenX &&
              null != e.mozInnerScreenY;
          return i && (n || o);
        }
        getAdCandidateAssets(t) {
          const e = t.domElement,
            i = this.getViewportSize(t.windowElement),
            r = this.getWrapperSize(t),
            o = { width: 0, height: 0, left: 0, right: 0, top: 0, bottom: 0 },
            a = s.S.getViewportAssetsRelativeToScreen(t.windowElement),
            d = s.S.getIframeAssetsRelativeToScreen(t.windowElement),
            c = d.left - a.left,
            l = d.top - a.top,
            u = (0, s.getBoundingClientRect)(e);
          (o.left = c + u.left),
            (o.right = c + u.right),
            (o.top = l + u.top),
            (o.bottom = l + u.bottom),
            (o.width = Math.ceil(u.width)),
            (o.height = Math.ceil(u.height));
          const h = (0, s.getElementVisiblePercentage)(o, i);
          return {
            viewportSize: this.getViewportSize(t.windowElement),
            wrapperSize: r,
            screenSize: this.getScreenSize(),
            adGeometric: (0, n.createNormalisedGeometry)({
              x: o.left,
              y: o.top,
              width: o.width,
              height: o.height,
            }),
            percentage: h,
            viewabilityCalculationType: this.getMethodId(),
          };
        }
        getViewportSize(t) {
          return s.S.getOuterViewport(t);
        }
        getMethodId() {
          return r.ViewabilityCalculationTypes.ScreenGeometric;
        }
      }
      (e.ScreenGeometricMethodClass = a), (e.ScreenGeometricMethod = new a());
    },
    2654: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.WebCalculationMethodBase = void 0);
      const n = i(8844);
      e.WebCalculationMethodBase = class {
        getWrapperSize(t) {
          try {
            return n.O.getElementWindowDimensions(t.domElement);
          } catch (t) {}
        }
        getScreenSize() {
          return n.S.getScreenSize();
        }
        destroyAdCandidateMethod(t) {}
      };
    },
    4143: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.HiddenAdsDataCollector = void 0);
      const n = i(6975),
        s = i(8844),
        r = i(1906);
      class o extends n.BaseAdDataCollector {
        isSupported() {
          return !(
            s.O.isDomlessEnvironment() || 128 == (128 & s.O.getScenarioType())
          );
        }
        startCollectData(t) {
          let e = 0;
          try {
            const i = s.A.isSellerTag(),
              n = r.Utilities.isPercentageCriteriaPassed(5),
              o =
                s.T.isCTV() ||
                s.T.isMobileApp() ||
                t.supportedDeliveryType.some((t) => 3 == t || 4 == t);
            e =
              !n || i || o || !t.domElement
                ? 0
                : (0, s.isAdElementHidden)(t.domElement);
          } catch (t) {
            e = -1;
          }
          t.hiddenAdsIndicator = e;
        }
        stopCollectData() {}
      }
      e.HiddenAdsDataCollector = o;
    },
    2280: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AutoplayDataCollector = void 0);
      const n = i(6975),
        s = i(8844),
        r = i(7682),
        o = i(7102),
        a = i(3386),
        d = i(8424);
      class c extends n.BaseAdDataCollector {
        isSupported() {
          return s.A.isVideoOrAudio();
        }
        startCollectData(t) {
          const e = o.k.addEventListener(
            o.DvEvents.videoStartPlaying,
            this.checkIsAutoplay.bind(this)
          );
          t.autoplayEventSubscriptionIds.push(e);
        }
        stopCollectData(t) {
          o.k.removeEventListener(t.autoplayEventSubscriptionIds[0]);
        }
        getSupportedAutoplayMethods(t) {
          return [
            r.DetectAutoplayByAutoplayAttribute,
            a.DetectAutoplayByTime,
            d.DetectAutoplayByJWPlayer,
          ].filter((e) => e.isSupported(t));
        }
        checkIsAutoplay(t) {
          const { adCandidate: e } = t;
          if (void 0 === e.autoplayDetectionMethod) {
            const t = e,
              i = this.getSupportedAutoplayMethods(e);
            (t.autoplayDetectionMethod = 0),
              i.forEach(function (i) {
                i.isAutoplayed(e) &&
                  (t.autoplayDetectionMethod =
                    t.autoplayDetectionMethod | i.getMethodId());
              });
          }
        }
      }
      e.AutoplayDataCollector = c;
    },
    7682: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.DetectAutoplayByAutoplayAttribute =
          e.DetectAutoplayByAutoplayAttributeClass =
            void 0);
      const n = i(8844);
      class s {
        isSupported(t) {
          return t && (0, n.isVideoElement)(t.domElement);
        }
        getMethodId() {
          return 1;
        }
        isAutoplayed(t) {
          return (0, n.safeGetAttribute)(t.domElement, "autoplay") || !1;
        }
      }
      (e.DetectAutoplayByAutoplayAttributeClass = s),
        (e.DetectAutoplayByAutoplayAttribute = new s());
    },
    8424: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.DetectAutoplayByJWPlayer = e.DetectAutoplayByJWPlayerClass = void 0);
      const n = i(8844);
      class s {
        isSupported() {
          return "function" == typeof n.O.workingWindow().jwplayer;
        }
        getMethodId() {
          return 2;
        }
        isAutoplayed() {
          var t;
          let e = !1;
          const i = n.O.workingWindow().jwplayer(),
            s =
              null === (t = null == i ? void 0 : i.getConfig) || void 0 === t
                ? void 0
                : t.call(i);
          return s && (e = s.autostart), e;
        }
      }
      (e.DetectAutoplayByJWPlayerClass = s),
        (e.DetectAutoplayByJWPlayer = new s());
    },
    3386: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.DetectAutoplayByTime = e.DetectAutoplayByTimeClass = void 0);
      const n = i(1906),
        s = i(8844);
      class r {
        constructor() {
          this.isAutoplayedTimeThreshold = 1e3;
        }
        isSupported() {
          return !0;
        }
        getMethodId() {
          return 4;
        }
        isAutoplayed(t) {
          const e = s.S.getNavigationStartTime();
          let i = !1;
          return (
            e &&
              (i =
                t.videoStartTime - n.Utilities.getTimeDiff(e) <=
                this.isAutoplayedTimeThreshold),
            i
          );
        }
      }
      (e.DetectAutoplayByTimeClass = r), (e.DetectAutoplayByTime = new r());
    },
    6975: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BaseAdDataCollector = void 0);
      const n = i(7102);
      e.BaseAdDataCollector = class {
        constructor() {
          this.isSupported() &&
            n.k.addEventsListener({
              [n.DvEvents.adCandidateApproved]:
                this.startCollectDataWrapper.bind(this),
              [n.DvEvents.adDestroy]: this.stopCollectDataWrapper.bind(this),
            });
        }
        startCollectDataWrapper(t) {
          this.startCollectData(t.adCandidate);
        }
        stopCollectDataWrapper(t) {
          this.stopCollectData(t.adCandidate);
        }
      };
    },
    5988: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BaseDataCollector = void 0);
      e.BaseDataCollector = class {
        constructor() {
          this.isSupported() && this.startCollectData();
        }
      };
    },
    7727: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BaseGlobalDataCollector = void 0);
      const n = i(7102);
      e.BaseGlobalDataCollector = class {
        constructor() {
          this.isSupported() &&
            (this.startCollectData(),
            n.k.addEventsListener({
              [n.DvEvents.adCandidateApproved]:
                this.registerToGlobalEvent.bind(this),
            }));
        }
        processAdDataWrapper(t) {
          this.processAdData(t.adCandidate);
        }
        registerToGlobalEvent(t) {
          n.k.addEventListener(
            this.getGlobalEventName(),
            this.processAdDataWrapper.bind(this, t)
          );
        }
      };
    },
    6244: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BoundariesViewabilityDataCollector = void 0);
      const n = i(3928),
        s = i(5708),
        r = i(7102),
        o = i(3283),
        a = i(6975),
        d = i(8844);
      class c extends a.BaseAdDataCollector {
        isSupported() {
          return !d.omidAdapter.isSupported();
        }
        startCollectData(t) {
          if (t.supportedDeliveryType.some((t) => 2 == t)) {
            const e = this.getSupportedMethod(t);
            if (!e) return;
            r.k.addEventListener(
              r.DvEvents.viewabilityIntervalData,
              this.handleViewabilityData.bind(this, e)
            );
          }
        }
        stopCollectData(t) {
          n.ResourceBased.destroyAdCandidateMethod(t);
        }
        getArea(t) {
          if ((null == t ? void 0 : t.width) && (null == t ? void 0 : t.height))
            return t.width * t.height;
        }
        handleViewabilityData(t, e) {
          const i = e.adCandidate,
            n = e.relevantData,
            s = this.getArea(n.adGeometric),
            r = this.getArea(n.viewportSize);
          (s && r && s < r) || this.publishAdBoundariesViewabilityData(t, i);
        }
        getSupportedMethod(t) {
          return [s.GeometricMethod, n.ResourceBased].find((e) =>
            e.isSupported(t)
          );
        }
        publishAdBoundariesViewabilityData(t, e) {
          const i = t.getBoundariesViewability(e);
          r.k.dispatchEvent(
            r.DvEvents.boundariesViewabilityIntervalData,
            new o.AdCandidateEventData(e, { boundariesViewability: i })
          );
        }
      }
      e.BoundariesViewabilityDataCollector = c;
    },
    2612: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdInteractionEventDataCollector = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(6975),
        o = i(3283),
        a = i(1008),
        d = i(3692);
      class c extends r.BaseAdDataCollector {
        constructor() {
          super(...arguments),
            (this.enhancedDeepIframeEngagement = [
              {
                domEventName: "click",
                dvEventToDispatch: n.DvEvents.firstClickOnDeepDescendantIframe,
                elementToListenTo: "deepDescendantIframe",
                measuredDvEventToDispatch: n.DvEvents.clickMeasured,
                eventReferenceSymbol: Symbol(
                  "First click on deep descendant iframe event"
                ),
              },
              {
                domEventName: "touchstart",
                dvEventToDispatch: n.DvEvents.firstTouchOnDeepDescendantIframe,
                elementToListenTo: "deepDescendantIframe",
                measuredParam: "isTouchMeasured",
                eventReferenceSymbol: Symbol(
                  "First touch on deep descendant iframe event"
                ),
              },
            ]),
            (this.enhancedIframeTouch = {
              domEventName: "touchstart",
              dvEventToDispatch: n.DvEvents.firstTouchOnDescendantIframe,
              elementToListenTo: "descendantIframes",
              measuredParam: "isTouchMeasured",
              eventReferenceSymbol: Symbol(
                "First touch on descendant iframe event"
              ),
            }),
            (this.enhancedIframeClick = {
              domEventName: "click",
              dvEventToDispatch: n.DvEvents.firstClickOnDescendantIframe,
              elementToListenTo: "descendantIframes",
              measuredDvEventToDispatch: n.DvEvents.clickMeasured,
              eventReferenceSymbol: Symbol(
                "First click on descendant iframe event"
              ),
            }),
            (this.interactionEventSubscriptions = [
              {
                domEventName: "click",
                dvEventToDispatch: n.DvEvents.firstClickOnAdElementData,
                elementToListenTo: "adCandidate",
                measuredDvEventToDispatch: n.DvEvents.clickMeasured,
                eventReferenceSymbol: Symbol(
                  "First click on ad candidate event"
                ),
              },
              {
                domEventName: "mouseover",
                dvEventToDispatch: n.DvEvents.firstHoverData,
                elementToListenTo: "adCandidate",
                measuredParam: "isHoverMeasured",
                eventReferenceSymbol: Symbol(
                  "First hover on ad candidate event"
                ),
              },
              {
                domEventName: "touchstart",
                dvEventToDispatch: n.DvEvents.firstTouchData,
                elementToListenTo: "adCandidate",
                measuredParam: "isTouchMeasured",
                eventReferenceSymbol: Symbol(
                  "First touch on ad candidate event"
                ),
              },
              {
                domEventName: "blur",
                dvEventToDispatch: n.DvEvents.firstFocusIntoAdElementData,
                elementToListenTo: "topAccessibleWindow",
                condition: (t) => {
                  var e;
                  return (
                    t.domElement ===
                    (null === (e = s.O.workingDocument()) || void 0 === e
                      ? void 0
                      : e.activeElement)
                  );
                },
                eventReferenceSymbol: Symbol(
                  "First focus onto ad candidate event"
                ),
              },
              {
                domEventName: "adSizeChange",
                dvEventToDispatch: n.DvEvents.adSizeData,
                elementToListenTo: "adCandidate",
                dataCollectionOverride: new u(),
                measuredDvEventToDispatch: n.DvEvents.adSizeMeasured,
                eventReferenceSymbol: Symbol(
                  "First size change on ad candidate event"
                ),
              },
              ...this.enhancedDeepIframeEngagement,
              this.enhancedIframeTouch,
              ...(a.descendantIframeClickHandlersExperiment.isEnabled()
                ? [this.enhancedIframeClick]
                : []),
            ]);
        }
        isSupported() {
          return !s.omidAdapter.isSupported();
        }
        addInteractionEventListeners(t, e) {
          const { domEventName: i } = t,
            n = this.getElementsToListenTo(t, e),
            r = this.handleElementEvent.bind(this, e, t);
          (e.domEvents[t.eventReferenceSymbol] = r),
            "descendantIframes" === t.elementToListenTo &&
              ((e.descendantIframeHandlerCount = n.length),
              (e.descendantIframeScanDepth = 1)),
            "deepDescendantIframe" === t.elementToListenTo &&
              ((e.deepDescendantIframeHandlerCount = n.length),
              (e.deepDescendantIframeScanDepth = 5));
          return n
            .map((t) => s.S.addEventListener(i, r, t))
            .some((t) => !0 === t);
        }
        startCollectData(t) {
          this.interactionEventSubscriptions.forEach((e) => {
            var i;
            ((
              null === (i = null == e ? void 0 : e.dataCollectionOverride) ||
              void 0 === i
                ? void 0
                : i.startCollectData
            )
              ? e.dataCollectionOverride.startCollectData(t)
              : this.addInteractionEventListeners(e, t)) &&
              this.updateIsMeasured(e, t);
          }),
            this.reattachTouchListenersOnIframeLoad(t);
        }
        reattachTouchListenersOnIframeLoad(t) {
          const e = t.domElement;
          if (!(0, s.isHTMLIFrameElement)(e)) return;
          let i = !1;
          s.S.addEventListener(
            "load",
            () => {
              if (i) return;
              i = !0;
              this.interactionEventSubscriptions
                .filter(
                  (t) =>
                    "touchstart" === t.domEventName &&
                    ("descendantIframes" === t.elementToListenTo ||
                      "deepDescendantIframe" === t.elementToListenTo)
                )
                .forEach((e) => {
                  this.addInteractionEventListeners(e, t) &&
                    this.updateIsMeasured(e, t);
                });
            },
            e
          );
        }
        updateIsMeasured(t, e) {
          const i = t.measuredDvEventToDispatch,
            s = t.measuredParam;
          s && (e[s] = 1),
            i && n.k.dispatchEvent(i, new o.AdCandidateEventData(e));
        }
        getElementsToListenTo(t, e) {
          switch (t.elementToListenTo) {
            case "topAccessibleWindow":
              return [s.O.getTopAccessibleWindow()];
            case "descendantIframes":
              return e.domElement
                ? s.S.getNestedDocuments(e.domElement, 1)
                : [];
            case "deepDescendantIframe":
              return e.domElement
                ? s.S.getNestedDocuments(e.domElement, 5)
                : [];
            default:
              return [e.domElement];
          }
        }
        handleElementEvent(t, e) {
          const { condition: i } = e;
          ("function" != typeof i || i(t)) &&
            (n.k.dispatchEvent(
              e.dvEventToDispatch,
              new o.AdCandidateEventData(t)
            ),
            this.removeEventListeners(e, t));
        }
        stopCollectData(t) {
          this.interactionEventSubscriptions.forEach((e) => {
            e.dataCollectionOverride
              ? e.dataCollectionOverride.stopCollectData(t)
              : this.removeEventListeners(e, t);
          });
        }
        removeEventListeners(t, e) {
          const i = this.getElementsToListenTo(t, e),
            { domEventName: n } = t,
            r = e.domEvents[t.eventReferenceSymbol];
          i.forEach((t) => {
            s.S.removeEventListener(n, r, t);
          });
        }
      }
      e.AdInteractionEventDataCollector = c;
      class l {}
      class u extends l {
        constructor() {
          super(...arguments),
            (this.interval = 100),
            (this.startCollectData = (t) => this.collectAdSizeData(t)),
            (this.stopCollectData = (t) => {
              (0, d.clearSafeInterval)(t.adSizeIntervalId);
            });
        }
        collectAdSizeData(t) {
          t.adSizeIntervalId = (0, d.setSafeInterval)(() => {
            try {
              this.handleAdSize(t);
            } catch (t) {}
          }, this.interval);
          try {
            const e = {
              width: t.domElement.clientWidth,
              height: t.domElement.clientHeight,
            };
            return !(!e.width || !e.height);
          } catch (t) {
            return !1;
          }
        }
        handleAdSize(t) {
          const { domElement: e } = t,
            i = { width: e.clientWidth, height: e.clientHeight };
          i.width &&
            i.height &&
            (n.k.dispatchEvent(
              n.DvEvents.adSizeMeasured,
              new o.AdCandidateEventData(t)
            ),
            n.k.dispatchEvent(
              n.DvEvents.adSizeData,
              new o.AdCandidateEventData(t, { adSize: i })
            ));
        }
      }
    },
    3546: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.InteractionUnloadDataCollector = void 0);
      const n = i(8844),
        s = i(7102),
        r = i(1906),
        o = i(3283),
        a = i(7727),
        d = i(3692);
      class c extends a.BaseGlobalDataCollector {
        startCollectData() {
          this.registerToDomEnvironment(),
            this.registerToOmidEnvironment(),
            (this.timeoutId = (0, d.setSafeTimeout)(
              this.reportDueToTimeout.bind(this),
              84e4
            ));
        }
        getGlobalEventName() {
          return s.DvEvents.globalUnloadData;
        }
        processAdData(t) {
          t.timeUntilUnloadMs = r.Utilities.getTimeDiff();
          const e = new o.AdCandidateEventData(t, {
            reportType: 0,
            forceRTS: !0,
          });
          s.k.dispatchEvent(s.DvEvents.unloadData, e),
            s.k.dispatchEvent(s.DvEvents.reportData, e),
            (t.wasAdStopped = !0),
            n.S.clearAllEventsListeners();
        }
        isSupported() {
          return !0;
        }
        getSubscribedEvents() {
          return ["beforeunload", "pagehide"];
        }
        registerToDomEnvironment() {
          (this.domEvents = {}),
            s.k.addEventListener(
              s.DvEvents.impressionServed,
              this.registerToVisibilityChange.bind(this),
              "InteractionUnloadDataCollector"
            ),
            this.getSubscribedEvents().forEach(
              this.registerUnloadEvent.bind(this)
            );
        }
        registerUnloadEvent(t) {
          const e = this.handleUnload.bind(this);
          (this.domEvents[t] = e),
            [n.O.workingWindow(), n.O.currentWindow()].forEach((i) => {
              n.S.addEventListener(t, e, i);
            });
        }
        registerToOmidEnvironment() {
          n.omidAdapter.isSupported() &&
            n.omidAdapter.registerSessionObserver(
              this.handleOmidUnload.bind(this)
            );
        }
        reportDueToTimeout() {
          this.timeMsUntilUnload || this.handleUnload();
        }
        registerToVisibilityChange() {
          const t = this.handleUnloadForVisibilityChange.bind(this);
          if (n.T.isMobile() && n.S.isVisibilityChangeEventSupported()) {
            this.lastVisibilityState = n.O.currentDocument().visibilityState;
            const e = n.S.getVisibilityPrefix() + "visibilitychange";
            n.S.addEventListener(e, t, n.O.workingDocument()),
              (this.domEvents[e] = t);
          }
        }
        handleUnloadForVisibilityChange() {
          const t = n.O.currentDocument().visibilityState;
          this.lastVisibilityState != t &&
            "hidden" === t &&
            this.handleUnload(),
            (this.lastVisibilityState = t);
        }
        isMaxTimePassed() {
          const t = r.Utilities.getTimeDiff();
          return (
            !(!this.timeMsUntilUnload && t < 12e5) ||
            ((this.timeMsUntilUnload = t), !1)
          );
        }
        handleUnload() {
          this.isMaxTimePassed() ||
            this.unloadFired ||
            (s.k.dispatchEvent(this.getGlobalEventName(), new o.EventData()),
            (this.unloadFired = !0));
        }
        handleOmidUnload(t) {
          "sessionFinish" === t.type && this.handleUnload();
        }
      }
      e.InteractionUnloadDataCollector = c;
    },
    6813: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.OmidInteractionDataCollector = void 0);
      const n = i(7102),
        s = i(6975),
        r = i(3283),
        o = i(8844),
        a = i(214);
      class d extends s.BaseAdDataCollector {
        isSupported() {
          return o.omidAdapter.isSupported();
        }
        startCollectData(t) {
          Object.keys(a.OmidEvents).forEach((e) => {
            o.omidAdapter.addEventListener(
              e,
              this.handleOmidEvent.bind(this, e, t)
            );
          }),
            n.k.dispatchEvent(
              n.DvEvents.clickMeasured,
              new r.AdCandidateEventData(t)
            ),
            n.k.dispatchEvent(
              n.DvEvents.adSizeMeasured,
              new r.AdCandidateEventData(t)
            );
        }
        handleOmidEvent(t, e, i) {
          var s, o, a, d, c, l;
          switch (t) {
            case "adUserInteraction":
              "click" ===
              (null === (s = null == i ? void 0 : i.data) || void 0 === s
                ? void 0
                : s.interactionType)
                ? n.k.dispatchEvent(
                    n.DvEvents.omidClickData,
                    new r.AdCandidateEventData(e)
                  )
                : "invitationAccept" ===
                  (null === (o = null == i ? void 0 : i.data) || void 0 === o
                    ? void 0
                    : o.interactionType)
                ? n.k.dispatchEvent(
                    n.DvEvents.omidInvitationAcceptData,
                    new r.AdCandidateEventData(e)
                  )
                : (null === (a = null == i ? void 0 : i.data) || void 0 === a
                    ? void 0
                    : a.interactionType) &&
                  n.k.dispatchEvent(
                    n.DvEvents.omidCustomInteractionData,
                    new r.AdCandidateEventData(e, {
                      customInteraction:
                        null === (d = null == i ? void 0 : i.data) ||
                        void 0 === d
                          ? void 0
                          : d.interactionType,
                    })
                  );
              break;
            case "geometryChange": {
              const t =
                  null ===
                    (l =
                      null === (c = null == i ? void 0 : i.data) || void 0 === c
                        ? void 0
                        : c.adView) || void 0 === l
                    ? void 0
                    : l.geometry,
                s = {
                  width: null == t ? void 0 : t.width,
                  height: null == t ? void 0 : t.height,
                };
              s.width &&
                s.height &&
                n.k.dispatchEvent(
                  n.DvEvents.omidAdSizeData,
                  new r.AdCandidateEventData(e, { adSize: s })
                );
              break;
            }
          }
        }
        stopCollectData(t) {}
      }
      e.OmidInteractionDataCollector = d;
    },
    1288: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PageInteractionKeyPressDataCollector = void 0);
      const n = i(7727),
        s = i(7102),
        r = i(8844),
        o = i(3283);
      class a extends n.BaseGlobalDataCollector {
        isSupported() {
          return !0;
        }
        getGlobalEventName() {
          return s.DvEvents.globalKeyPressData;
        }
        startCollectData() {
          const t = r.O.workingWindow(),
            e = r.O.getTopAccessibleWindow();
          r.S.addEventListener(
            "keypress",
            this.handleKeyPressEvent.bind(this),
            t
          ),
            e != t &&
              r.S.addEventListener(
                "keypress",
                this.handleKeyPressEvent.bind(this),
                e
              );
        }
        handleKeyPressEvent() {
          s.k.dispatchEvent(this.getGlobalEventName(), new o.EventData());
        }
        processAdData(t) {
          s.k.dispatchEvent(
            s.DvEvents.keyPressData,
            new o.AdCandidateEventData(t)
          );
        }
      }
      e.PageInteractionKeyPressDataCollector = a;
    },
    2635: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PageInteractionMouseMoveDataCollector = void 0);
      const n = i(7727),
        s = i(7102),
        r = i(8844),
        o = i(3283);
      class a extends n.BaseGlobalDataCollector {
        isSupported() {
          return !0;
        }
        getGlobalEventName() {
          return s.DvEvents.globalMouseMoveData;
        }
        startCollectData() {
          const t = r.O.workingWindow(),
            e = r.O.getTopAccessibleWindow();
          this.addListeners(t), e != t && this.addListeners(e);
        }
        addListeners(t) {
          ["mousemove", "touchmove"].forEach((e) => {
            r.S.addEventListener(e, this.handleMouseMoveEvent.bind(this), t);
          });
        }
        handleMouseMoveEvent() {
          s.k.dispatchEvent(this.getGlobalEventName(), new o.EventData());
        }
        processAdData(t) {
          s.k.dispatchEvent(
            s.DvEvents.mouseMoveData,
            new o.AdCandidateEventData(t)
          );
        }
      }
      e.PageInteractionMouseMoveDataCollector = a;
    },
    101: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PageInteractionOrientationChangedDataCollector = void 0);
      const n = i(7727),
        s = i(7102),
        r = i(3283),
        o = i(8844),
        a = i(1360);
      class d extends n.BaseGlobalDataCollector {
        isSupported() {
          return void 0 !== o.S.getScreenOrientation();
        }
        getGlobalEventName() {
          return s.DvEvents.globalOrientationChangeData;
        }
        startCollectData() {
          o.S.addEventListener(
            "change",
            this.handleOrientationChangeEvent.bind(this),
            o.S.getScreenOrientation()
          ),
            s.k.dispatchEvent(
              s.DvEvents.orientationChangeMeasured,
              new r.EventData()
            );
        }
        handleOrientationChangeEvent() {
          s.k.dispatchEvent(this.getGlobalEventName(), new r.EventData());
        }
        processAdData(t) {
          this.onOrientationChange(t);
        }
        onOrientationChange(t) {
          var e;
          const i = o.S.getScreenOrientationType();
          if (1 === i)
            s.k.dispatchEvent(
              s.DvEvents.orientationChangePortraitData,
              new r.AdCandidateEventData(t)
            );
          else if (2 === i)
            s.k.dispatchEvent(
              s.DvEvents.orientationchangeLandscapeData,
              new r.AdCandidateEventData(t)
            );
          else if (0 === i) {
            const t =
              null === (e = o.S.getScreenOrientation().type) || void 0 === e
                ? void 0
                : e.toString();
            t &&
              a.DiagnosticParamsReporterSingleton.reportOnce(
                a.DiagnosticParams.unknownScreenOrientationType,
                t
              );
          }
        }
      }
      e.PageInteractionOrientationChangedDataCollector = d;
    },
    6938: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.UserPresenceDataCollector = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(3283),
        o = i(1360);
      e.UserPresenceDataCollector = class {
        constructor() {
          (this.interactionSubscriptions = [
            {
              eventName: "keypress",
              eventToDispatchOnMeasure: n.DvEvents.keyPressMeasured,
              eventToDispatchOnInteract: n.DvEvents.tempFirstKeyPressData,
              elementToListenTo: s.O.workingWindow(),
            },
            {
              eventName: "keypress",
              isSupported: s.O.workingWindow() !== s.O.getTopAccessibleWindow(),
              eventToDispatchOnMeasure: n.DvEvents.keyPressMeasured,
              eventToDispatchOnInteract: n.DvEvents.tempFirstKeyPressData,
              elementToListenTo: s.O.getTopAccessibleWindow(),
            },
            {
              eventName: "mousemove",
              eventToDispatchOnMeasure: n.DvEvents.mouseMoveMeasured,
              eventToDispatchOnInteract: n.DvEvents.tempFirstMouseMoveData,
              elementToListenTo: s.O.workingWindow(),
            },
            {
              eventName: "touchmove",
              eventToDispatchOnMeasure: n.DvEvents.mouseMoveMeasured,
              eventToDispatchOnInteract: n.DvEvents.tempFirstMouseMoveData,
              elementToListenTo: s.O.workingWindow(),
            },
            {
              eventName: "mousemove",
              isSupported: s.O.workingWindow() !== s.O.getTopAccessibleWindow(),
              eventToDispatchOnMeasure: n.DvEvents.mouseMoveMeasured,
              eventToDispatchOnInteract: n.DvEvents.tempFirstMouseMoveData,
              elementToListenTo: s.O.getTopAccessibleWindow(),
            },
            {
              eventName: "touchmove",
              isSupported: s.O.workingWindow() !== s.O.getTopAccessibleWindow(),
              eventToDispatchOnMeasure: n.DvEvents.mouseMoveMeasured,
              eventToDispatchOnInteract: n.DvEvents.tempFirstMouseMoveData,
              elementToListenTo: s.O.getTopAccessibleWindow(),
            },
            {
              eventName: "change",
              isSupported: void 0 !== s.S.getScreenOrientation(),
              eventToDispatchOnMeasure: n.DvEvents.orientationChangeMeasured,
              elementToListenTo: s.S.getScreenOrientation(),
            },
          ]),
            this.startCollectData();
        }
        startCollectData() {
          this.interactionSubscriptions.forEach((t) => {
            if (null == t.isSupported || t.isSupported) {
              const e = this.getCallback(t);
              s.S.addEventListener(t.eventName, e, t.elementToListenTo) &&
                n.k.dispatchEvent(
                  t.eventToDispatchOnMeasure,
                  new r.EventData()
                );
            }
          });
        }
        getCallback(t) {
          return "change" === t.eventName
            ? this.reportOrientationChangeEventData.bind(this)
            : this.reportInteractionEventData.bind(
                this,
                t.eventToDispatchOnInteract
              );
        }
        reportInteractionEventData(t) {
          n.k.dispatchEvent(t, new r.EventData());
        }
        reportOrientationChangeEventData() {
          var t;
          const e = s.S.getScreenOrientationType();
          if (1 === e)
            this.reportInteractionEventData(
              n.DvEvents.tempOrientationChangePortraitData
            );
          else if (2 === e)
            this.reportInteractionEventData(
              n.DvEvents.tempOrientationChangeLandscapeData
            );
          else if (0 === e) {
            const e =
              null === (t = s.S.getScreenOrientation().type) || void 0 === t
                ? void 0
                : t.toString();
            e &&
              o.DiagnosticParamsReporterSingleton.reportOnce(
                o.DiagnosticParams.unknownScreenOrientationType,
                e
              );
          }
        }
      };
    },
    9413: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.FocusDataCollector = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(6975),
        o = i(3283);
      class a extends r.BaseAdDataCollector {
        isSupported() {
          return !0;
        }
        startCollectData(t) {
          const e = t.domEvents,
            i = this.handleFocus.bind(this, t);
          if ((this.handleFocus(t), s.S.isVisibilityChangeEventSupported())) {
            const n = s.S.getVisibilityPrefix() + "visibilitychange";
            s.S.addEventListener(n, i, s.O.workingDocument(t.windowElement)),
              (e[n] = i);
          }
        }
        handleFocus(t) {
          try {
            const e = s.S.hasFocus();
            n.k.dispatchEvent(
              n.DvEvents.focusData,
              new o.AdCandidateEventData(t, { focus: e })
            );
          } catch (t) {}
        }
        stopCollectData(t) {
          if (s.S.isVisibilityChangeEventSupported()) {
            const e = s.S.getVisibilityPrefix() + "visibilitychange";
            s.S.removeEventListener(
              e,
              t.domEvents[e],
              s.O.workingDocument(t.windowElement)
            );
          }
        }
      }
      e.FocusDataCollector = a;
    },
    1513: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PageEventsDataCollector = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(5988),
        o = i(3283);
      class a extends r.BaseDataCollector {
        isSupported() {
          return !s.O.isDomlessEnvironment();
        }
        startCollectData() {
          s.S.addEventListener(
            "pagehide",
            this.handlePersistedEvent(
              n.DvEvents.pageHideEventPersisted,
              n.DvEvents.pageHideEventNonPersisted
            ).bind(this),
            s.O.workingWindow()
          );
        }
        handlePersistedEvent(t, e) {
          return (i) => {
            const s = (null == i ? void 0 : i.persisted) ? t : e;
            n.k.dispatchEvent(s, new o.EventData());
          };
        }
      }
      e.PageEventsDataCollector = a;
    },
    7357: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PerformanceApiDataCollector = void 0);
      const n = i(6975),
        s = i(7102),
        r = i(3283),
        o = i(8844);
      class a extends n.BaseAdDataCollector {
        constructor() {
          super(...arguments), (this.subscriptionIds = []);
        }
        isSupported() {
          return !o.O.isDomlessEnvironment();
        }
        getEntries(t) {
          const e = o.O.monitorScriptsPerformance(o.O.currentWindow(), {
              visit: ["transferSize"],
            }),
            i = {
              visitResponseSize: null == e ? void 0 : e.visit_transferSize,
            };
          Object.keys(i).length &&
            s.k.dispatchEvent(
              s.DvEvents.performanceData,
              new r.PerformanceEventData(i, t)
            );
        }
        startCollectData(t) {
          this.isSupported() &&
            (this.subscriptionIds = s.k.addEventsListener({
              [s.DvEvents.impressionServed]: this.getEntries.bind(this, t),
            }));
        }
        stopCollectData(t) {
          this.subscriptionIds.length &&
            (s.k.removeEventsListener(this.subscriptionIds),
            (this.subscriptionIds = []));
        }
      }
      e.PerformanceApiDataCollector = a;
    },
    7788: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PerformanceLongTasksDataCollector = e.LONG_TASK_TYPE = void 0);
      const n = i(8844),
        s = i(7102),
        r = i(3283),
        o = i(5988),
        a = i(4112),
        d = i(1805);
      e.LONG_TASK_TYPE = "longtask";
      class c extends o.BaseDataCollector {
        isSupported() {
          return c.isPerformanceLongTasksSupported();
        }
        startCollectData() {
          if (!this.observer)
            try {
              (this.observer = new PerformanceObserver(
                this.handleLongTasksEntries.bind(this)
              )),
                this.observer.observe({ type: e.LONG_TASK_TYPE, buffered: !0 });
            } catch (t) {
              d.L.sendError(a.ClientErrorType.FailObserverLongTasks, t);
            }
        }
        handleLongTasksEntries(t) {
          const e = t
            .getEntries()
            .filter((t) => {
              var e;
              return null === (e = t.attribution) || void 0 === e
                ? void 0
                : e.length;
            })
            .filter(({ attribution: t }) => t[0].containerId === c.getFrameId())
            .map(this.convertLongTaskEntryToLongTask.bind(this));
          s.k.dispatchEvent(
            s.DvEvents.performanceLongTasks,
            new r.LongTaskEventData(e)
          );
        }
        convertLongTaskEntryToLongTask(t) {
          return {
            startTime: t.startTime,
            duration: t.duration,
            frameId: c.getFrameId(),
          };
        }
        static getFrameId() {
          var t;
          return (
            this._frameId ||
              (this._frameId =
                null === (t = n.O.getFrameElement(n.O.currentWindow())) ||
                void 0 === t
                  ? void 0
                  : t.id),
            this._frameId
          );
        }
        static isPerformanceLongTasksSupported() {
          var t;
          return (
            "undefined" != typeof PerformanceObserver &&
            3 === n.O.getScriptInjectionMode() &&
            !!this.getFrameId() &&
            !!(null ===
              (t =
                null === PerformanceObserver || void 0 === PerformanceObserver
                  ? void 0
                  : PerformanceObserver.supportedEntryTypes) || void 0 === t
              ? void 0
              : t.some((t) => t === e.LONG_TASK_TYPE))
          );
        }
      }
      e.PerformanceLongTasksDataCollector = c;
    },
    9025: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.StrictFocusDataCollector = void 0);
      const n = i(7102),
        s = i(8844),
        r = i(6975),
        o = i(3283),
        a = i(3692);
      class d extends r.BaseAdDataCollector {
        isSupported() {
          return !0;
        }
        startCollectData(t) {
          this.handleFocus(t),
            s.O.windowTop() &&
              s.S.isStrictFocusSupported() &&
              (t.strictFocusInterval = (0, a.setSafeInterval)(
                this.handleFocus.bind(this, t),
                200
              ));
        }
        handleFocus(t) {
          try {
            const e = null == s.S.hasStrictFocus() || s.S.hasStrictFocus();
            n.k.dispatchEvent(
              n.DvEvents.strictFocusData,
              new o.AdCandidateEventData(t, { focus: e })
            );
          } catch (t) {}
        }
        stopCollectData(t) {
          (0, a.clearSafeInterval)(t.strictFocusInterval);
        }
      }
      e.StrictFocusDataCollector = d;
    },
    2515: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VideoPlaybackDataCollector = void 0);
      const n = i(6975),
        s = i(7971),
        r = i(2549),
        o = i(1342),
        a = i(9907),
        d = i(8844),
        c = i(7102),
        l = i(3283),
        u = i(5962);
      class h extends n.BaseAdDataCollector {
        isSupported() {
          return d.A.isVideoOrAudio();
        }
        startCollectData(t) {
          (t.videoPlaybackIndicator = t.videoPlaybackIndicatorDvp = 0),
            (t.videoPlayback = this.getSupportedVideoPlayback(t)),
            t.videoPlayback &&
              (t.videoPlayback.startCollectData(t),
              (t.videoPlaybackIndicator = t.videoPlaybackIndicatorDvp =
                t.videoPlayback.getIndicator()),
              c.k.dispatchEvent(
                c.DvEvents.reportData,
                new l.AdCandidateEventData(t)
              ));
        }
        stopCollectData(t) {
          t.videoPlayback && t.videoPlayback.stopCollectData(t);
        }
        getSupportedVideoPlayback(t) {
          return [
            r.VideoPlaybackByOmid,
            a.VideoPlaybackByAdColonyVpaid,
            o.VideoPlaybackByVpaid,
            u.VideoPlaybackByInmobi,
            s.VideoPlaybackByHtml5,
          ].find((e) => e.isSupported(t));
        }
      }
      e.VideoPlaybackDataCollector = h;
    },
    9907: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VideoPlaybackByAdColonyVpaid = e.VideoPlaybackByAdColonyVpaidClass =
          void 0);
      const n = i(3187),
        s = i(7102),
        r = i(3283),
        o = i(6431);
      class a {
        constructor() {
          this.vpaidEventMapping = {
            AdImpression: [s.DvEvents.adImpressionData],
            AdVideoFirstQuartile: [s.DvEvents.adVideoFirstQuartileData],
            AdVideoMidpoint: [s.DvEvents.adVideoMidpointData],
            AdVideoThirdQuartile: [s.DvEvents.adVideoThirdQuartileData],
            AdVideoComplete: [s.DvEvents.adVideoCompleteData],
            AdVideoStart: [s.DvEvents.adVideoStartData, s.DvEvents.volumeData],
            AdPaused: [s.DvEvents.pauseData],
            AdPlaying: [s.DvEvents.resumeData],
            AdVolumeChange: [s.DvEvents.volumeData],
          };
        }
        isSupported() {
          return (this.adc = n.VideoPlaybackAdaptor.getADCObject()), !!this.adc;
        }
        getIndicator() {
          return 4;
        }
        startCollectData(t) {
          Object.keys(this.vpaidEventMapping).forEach((e) => {
            this.adc.subscribe(e, this.handleVpaidEvent.bind(this, e, t));
          });
        }
        stopCollectData(t) {}
        extractDvEventArgs(t, e) {
          var i;
          if ("AdVolumeChange" !== t && "AdVideoStart" !== t) return;
          const n = o.default.getVolumeLevel(
            null !== (i = null == e ? void 0 : e.deviceVolume) && void 0 !== i
              ? i
              : null == e
              ? void 0
              : e.volume
          );
          return o.default.isVolumeLevelSupported(n) ? { volume: n } : void 0;
        }
        handleVpaidEvent(t, e, i) {
          const n = this.vpaidEventMapping[t];
          if (!(null == n ? void 0 : n.length)) return;
          const o = this.extractDvEventArgs(t, i),
            a = new r.AdCandidateEventData(e, o);
          n.forEach((t) => {
            s.k.dispatchEvent(t, a);
          });
        }
      }
      (e.VideoPlaybackByAdColonyVpaidClass = a),
        (e.VideoPlaybackByAdColonyVpaid = new a());
    },
    7971: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VideoPlaybackByHtml5 = e.VideoPlaybackByHtml5Class = void 0);
      const n = i(7102),
        s = i(3283),
        r = i(8844),
        o = i(6431),
        a = i(4112);
      class d {
        constructor() {
          (this.html5EventMapping = {
            playing: n.DvEvents.adVideoStartData,
            pause: n.DvEvents.pauseData,
            play: n.DvEvents.resumeData,
            volumechange: n.DvEvents.volumeData,
            ended: n.DvEvents.adVideoCompleteData,
          }),
            (this.quartileEvents = [
              n.DvEvents.adVideoFirstQuartileData,
              n.DvEvents.adVideoMidpointData,
              n.DvEvents.adVideoThirdQuartileData,
              n.DvEvents.adVideoCompleteData,
            ]),
            (this.eventsToReportOnlyOnce = [
              n.DvEvents.adVideoCompleteData,
              n.DvEvents.adVideoStartData,
              ...this.quartileEvents,
            ]);
        }
        isSupported(t) {
          return (
            (0, a.isInAppSupported)(t.supportedDeliveryType) &&
            (0, r.isVideoElement)(t.domElement)
          );
        }
        getIndicator() {
          return 2;
        }
        startCollectData(t) {
          const e = this.updateAdPlaybackTime.bind(this, t);
          r.S.addEventListener("timeupdate", e, t.domElement),
            (t.domEvents.timeupdate = e),
            Object.keys(this.html5EventMapping).forEach((e) => {
              const i = this.handleHtml5Event.bind(
                this,
                t,
                this.html5EventMapping[e]
              );
              r.S.addEventListener(e, i, t.domElement), (t.domEvents[e] = i);
            });
        }
        stopCollectData(t) {
          [...Object.keys(this.html5EventMapping), "timeupdate"].forEach(
            (e) => {
              r.S.removeEventListener(e, t.domEvents[e], t.domElement);
            }
          );
        }
        updateAdPlaybackTime(t) {
          const e = t.domElement;
          if (!e.duration) return;
          e.currentTime &&
            !t.videoPlaybackHtml5AdPlaybackTimeInitialized &&
            ((t.videoPlaybackHtml5AdPlaybackTimeInitialized = !0),
            this.publishEvents(n.DvEvents.resumeData, t));
          const i = e.duration / 4;
          if (e.currentTime >= t.videoPlaybackHtml5QuartileId * i) {
            const e = this.quartileEvents[t.videoPlaybackHtml5QuartileId - 1];
            this.publishEvents(e, t), t.videoPlaybackHtml5QuartileId++;
          }
        }
        extractDvEventArgs(t, e) {
          if (e !== n.DvEvents.volumeData && e !== n.DvEvents.adVideoStartData)
            return;
          return {
            volume: o.default.getVolumeLevel(null == t ? void 0 : t.volume),
          };
        }
        handleHtml5Event(t, e) {
          const i = t.domElement,
            n = this.extractDvEventArgs(i, e);
          this.publishEvents(e, t, n);
        }
        publishEvents(t, e, i) {
          if (
            this.eventsToReportOnlyOnce.some((e) => e == t) &&
            e.videoPlaybackHtml5Events.some((e) => e == t)
          )
            return;
          t == n.DvEvents.adVideoCompleteData && this.stopCollectData(e),
            e.videoPlaybackHtml5Events.push(t);
          const r = new s.AdCandidateEventData(e, i);
          n.k.dispatchEvent(t, r),
            t === n.DvEvents.adVideoStartData &&
              "volume" in i &&
              n.k.dispatchEvent(n.DvEvents.volumeData, r);
        }
      }
      (e.VideoPlaybackByHtml5Class = d), (e.VideoPlaybackByHtml5 = new d());
    },
    5962: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VideoPlaybackByInmobi = e.VideoPlaybackByInmobiClass = void 0);
      const n = i(7102),
        s = i(3283),
        r = i(3046),
        o = i(6431);
      class a {
        constructor() {
          this.inmobiEventMapping = {
            AdLoaded: [n.DvEvents.videoLoadedData],
            AdVideoFirstQuartile: [n.DvEvents.adVideoFirstQuartileData],
            AdVideoMidpoint: [n.DvEvents.adVideoMidpointData],
            AdVideoThirdQuartile: [n.DvEvents.adVideoThirdQuartileData],
            AdVideoComplete: [n.DvEvents.adVideoCompleteData],
            AdVideoStart: [n.DvEvents.adVideoStartData, n.DvEvents.volumeData],
            AdPaused: [n.DvEvents.pauseData],
            AdPlaying: [n.DvEvents.resumeData],
            AdVolumeChange: [n.DvEvents.volumeData],
          };
        }
        isSupported() {
          return r.InmobiWrapper.isSupported();
        }
        getIndicator() {
          return 5;
        }
        startCollectData(t) {
          r.InmobiWrapper.addEventListenerWithHistory(
            this.handleInmobiEvent.bind(this, t)
          );
        }
        stopCollectData() {}
        extractDvEventArgs(t) {
          var e;
          const i = t.type;
          if (!i || !(null == t ? void 0 : t.detail)) return;
          if (
            "AdVolumeChange" !== i &&
            "AdVideoStart" !== i &&
            "AdLoaded" !== i
          )
            return;
          return {
            volume: o.default.getVolumeLevel(
              null !== (e = t.detail.adVolume) && void 0 !== e
                ? e
                : t.detail.volume
            ),
          };
        }
        updateAdDuration(t, e) {
          var i;
          "AdLoaded" === e.type &&
            (null === (i = null == e ? void 0 : e.detail) || void 0 === i
              ? void 0
              : i.duration) > 0 &&
            (t.adDuration = Math.round(e.detail.duration));
        }
        handleInmobiEvent(t, e) {
          const i =
            (null == e ? void 0 : e.type) && this.inmobiEventMapping[e.type];
          if (!(null == i ? void 0 : i.length)) return;
          this.updateAdDuration(t, e);
          const r = this.extractDvEventArgs(e),
            o = new s.AdCandidateEventData(t, r);
          i.forEach((t) => {
            n.k.dispatchEvent(t, o);
          });
        }
      }
      (e.VideoPlaybackByInmobiClass = a), (e.VideoPlaybackByInmobi = new a());
    },
    2549: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VideoPlaybackByOmid = e.VideoPlaybackByOmidClass = void 0);
      const n = i(7102),
        s = i(3283),
        r = i(8844),
        o = i(4112),
        a = i(1360),
        d = i(1906),
        c = i(6431),
        l = i(9135);
      class u {
        constructor() {
          this.omidEventMapping = {
            [o.OmidAdEventType.IMPRESSION]: [n.DvEvents.adImpressionData],
            [o.OmidAdEventType.COMPLETE]: [n.DvEvents.adVideoCompleteData],
            [o.OmidAdEventType.FIRST_QUARTILE]: [
              n.DvEvents.adVideoFirstQuartileData,
            ],
            [o.OmidAdEventType.MIDPOINT]: [n.DvEvents.adVideoMidpointData],
            [o.OmidAdEventType.START]: [
              n.DvEvents.adVideoStartData,
              n.DvEvents.volumeData,
            ],
            [o.OmidAdEventType.THIRD_QUARTILE]: [
              n.DvEvents.adVideoThirdQuartileData,
            ],
            [o.OmidAdEventType.PAUSE]: [n.DvEvents.pauseData],
            [o.OmidAdEventType.RESUME]: [n.DvEvents.resumeData],
            [o.OmidAdEventType.SKIPPED]: [n.DvEvents.skipData],
            [o.OmidAdEventType.VOLUME_CHANGE]: [n.DvEvents.volumeData],
            [o.OmidAdEventType.LOADED]: [],
          };
        }
        isSupported() {
          return r.omidAdapter.isSupported();
        }
        getIndicator() {
          return 3;
        }
        startCollectData(t) {
          a.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
            a.DiagnosticParams.timeUntilOmidListenMs,
            d.Utilities.getTimeDiff()
          ),
            Object.keys(this.omidEventMapping).forEach((e) => {
              r.omidAdapter.addEventListener(
                e,
                this.omidEventCallback.bind(this, t, e)
              );
            });
        }
        stopCollectData(t) {}
        getOmidVolume(t) {
          if (!(null == t ? void 0 : t.data)) return c.VOLUME_UNSUPPORTED;
          const e = c.default.getVolumeLevel(t.data.videoPlayerVolume),
            i = c.default.getVolumeLevel(t.data.deviceVolume),
            n = c.default.isVolumeLevelSupported(e),
            s = c.default.isVolumeLevelSupported(i);
          return n && s ? e * i : n ? e : s ? i : c.VOLUME_UNSUPPORTED;
        }
        extractDvEventArgs(t, e) {
          if (
            t === o.OmidAdEventType.VOLUME_CHANGE ||
            t === o.OmidAdEventType.START
          )
            return { volume: this.getOmidVolume(e) };
        }
        updateAdCandidate(t, e, i) {
          var n;
          if (
            e === o.OmidAdEventType.START &&
            (null === (n = null == i ? void 0 : i.data) || void 0 === n
              ? void 0
              : n.duration) &&
            "number" == typeof i.data.duration &&
            Number.isFinite(i.data.duration) &&
            r.A.getAdServerId() === l.TIKTOK_AD_SERVER_ID
          ) {
            const e = this.getOmidDurationMS(i.data.duration);
            (t.adDuration = e), (t.adDurationCalculationType = 5);
          }
          null == t.omidPlaybackStartIndicator &&
            (t.omidPlaybackStartIndicator = -1),
            e === o.OmidAdEventType.LOADED &&
              (t.omidPlaybackStartIndicator =
                this.getOmidPlaybackStartIndicator(i));
        }
        getOmidDurationMS(t) {
          if (t < 0) return 0;
          const e = t < 1e3,
            i = Math.round(t);
          return e ? 1e3 * i : i;
        }
        omidEventCallback(t, e, i) {
          this.updateAdCandidate(t, e, i);
          const r = this.omidEventMapping[e];
          if (!(null == r ? void 0 : r.length)) return;
          const o = this.extractDvEventArgs(e, i),
            a = new s.AdCandidateEventData(t, o);
          r.forEach((t) => {
            n.k.dispatchEvent(t, a);
          });
        }
        getOmidPlaybackStartIndicator(t) {
          var e;
          return null !=
            (null === (e = null == t ? void 0 : t.data) || void 0 === e
              ? void 0
              : e.autoPlay)
            ? t.data.autoPlay
              ? 1
              : 2
            : 0;
        }
      }
      (e.VideoPlaybackByOmidClass = u), (e.VideoPlaybackByOmid = new u());
    },
    1342: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VideoPlaybackByVpaid = e.VideoPlaybackByVpaidClass = void 0);
      const n = i(8844),
        s = i(7102),
        r = i(3283),
        o = i(4642),
        a = i(1906),
        d = i(6431);
      class c {
        constructor() {
          this.vpaidEventMapping = {
            AdImpression: [s.DvEvents.adImpressionData],
            AdLoaded: [s.DvEvents.videoLoadedData],
            AdVideoStart: [s.DvEvents.adVideoStartData, s.DvEvents.volumeData],
            AdVideoFirstQuartile: [s.DvEvents.adVideoFirstQuartileData],
            AdVideoMidpoint: [s.DvEvents.adVideoMidpointData],
            AdVideoThirdQuartile: [s.DvEvents.adVideoThirdQuartileData],
            AdVideoComplete: [s.DvEvents.adVideoCompleteData],
            AdUserClose: [s.DvEvents.abandonData],
            AdPaused: [s.DvEvents.pauseData],
            AdPlaying: [s.DvEvents.resumeData],
            AdSkipped: [s.DvEvents.skipData],
            AdStopped: [s.DvEvents.stopData],
            AdVolumeChange: [s.DvEvents.volumeData],
            AdSkippableStateChange: [s.DvEvents.skippableData],
          };
        }
        isSupported() {
          return (
            (this.adID = n.A.getAdID()),
            (this.vpaid = o.VpaidWrapper.getDvVpaid()),
            !!this.adID && !!this.vpaid && o.VpaidWrapper.isSupported()
          );
        }
        getIndicator() {
          return 1;
        }
        startCollectData(t) {
          t.videoPlaybackByVpaidEventSubscriptionIds = this.vpaid.subscribe(
            Object.keys(this.vpaidEventMapping),
            this.adID,
            this.handleVpaidEvent.bind(this, t)
          );
          const { asset: e = {} } = this.vpaid,
            { adDuration: i = 0, adSkippable: n } = e;
          i > 0 &&
            i < 180 &&
            ((t.adDuration = Math.round(1e3 * i)),
            (t.adDurationCalculationType = 1)),
            n && (t.adSkippableMs = a.Utilities.getTimeDiff());
        }
        stopCollectData(t) {
          this.vpaid.unsubscribe(t.videoPlaybackByVpaidEventSubscriptionIds);
        }
        extractDvEventArgs(t, e) {
          if (!e) return;
          if ("AdSkippableStateChange" === t) {
            const t = this.getAdSkippable(e);
            if (null !== t) return { adSkippable: t };
          }
          const i = d.default.getVolumeLevel(e.volume, Boolean(e.muted));
          return "AdVolumeChange" === t || "AdVideoStart" === t
            ? { volume: i }
            : void 0;
        }
        handleVpaidEvent(t, e, i) {
          const n = i.eventName;
          if (!n) return;
          const o = this.vpaidEventMapping[n];
          if (!(null == o ? void 0 : o.length)) return;
          const a = this.extractDvEventArgs(
              n,
              null == i ? void 0 : i.viewabilityResult
            ),
            d = new r.AdCandidateEventData(t, a);
          o.forEach((t) => {
            s.k.dispatchEvent(t, d);
          });
        }
        getAdSkippable(t) {
          const e = null == t ? void 0 : t.adSkippableState;
          return a.Utilities.isNullOrEmpty(e) ? null : !!e;
        }
      }
      (e.VideoPlaybackByVpaidClass = c), (e.VideoPlaybackByVpaid = new c());
    },
    6306: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ViewabilityDataCollector = void 0);
      const n = i(3928),
        s = i(5708),
        r = i(776),
        o = i(2285),
        a = i(5163),
        d = i(7102),
        c = i(3283),
        l = i(2202),
        u = i(7854),
        h = i(6975),
        v = i(9021),
        p = i(1906),
        m = i(8844),
        f = i(4054),
        g = i(1805),
        b = i(7662),
        w = i(1360),
        _ = i(3692),
        y = i(4112);
      class S extends h.BaseAdDataCollector {
        isSupported() {
          return !0;
        }
        getPrimaryViewabilityMethod(t) {
          const e = t.viewabilityMethods;
          if (null == e ? void 0 : e.primary) return e.primary;
          const i = this.getSupportedMethod(t);
          if (!i) return;
          const n = {
            calculationMethod: i,
            intervalDvEvent: d.DvEvents.viewabilityIntervalData,
          };
          return (
            (t.viewabilityMethods = { primary: n, experiments: [] }),
            (t.viewabilityCalculationType = i.getMethodId()),
            n
          );
        }
        startCollectorInterval(t) {
          (this.viewabilityInterval = m.A.isVideoOrAudio() ? 200 : 100),
            this.publishAdViewabilityData(t),
            (t.viewabilityIntervalId = (0, _.setSafeInterval)(
              this.publishAdViewabilityData.bind(this, t),
              this.viewabilityInterval
            ));
        }
        setupExperimentViewabilityMethod(t) {
          const e = this.getExperimentViewabilityMethods().filter(
            ({ condition: e = () => !0 }) => e(t)
          );
          t.viewabilityMethods.experiments.push(...e);
        }
        startCollectData(t) {
          this.getPrimaryViewabilityMethod(t) &&
            (d.k.addEventListener(
              d.DvEvents.adVideoCompleteData,
              this.adVideoComplete.bind(this)
            ),
            this.setupExperimentViewabilityMethod(t),
            this.startCollectorInterval(t));
        }
        getExperimentViewabilityMethods() {
          return [
            {
              calculationMethod: o.AllScenarioIntersectionObserverMethod,
              intervalDvEvent: d.DvEvents.secondaryViewabilityIntervalData,
              condition: (t) =>
                t.viewabilityCalculationType ===
                  y.ViewabilityCalculationTypes.Geometric &&
                o.AllScenarioIntersectionObserverMethod.isSupported(t),
            },
          ];
        }
        stopCollectData(t) {
          this.stopViewabilityInterval(t);
        }
        adVideoComplete(t) {
          this.stopViewabilityInterval(t.adCandidate);
        }
        destroyAllViewabilityMethods(t) {
          const e = this.getAllViewabilityMethods(t);
          for (; e.length; ) {
            const { calculationMethod: i } = e.pop();
            i.destroyAdCandidateMethod(t);
          }
          (t.viewabilityMethods.primary = void 0),
            (t.viewabilityMethods.experiments = []);
        }
        stopViewabilityInterval(t) {
          t.viewabilityIntervalId &&
            ((0, _.clearSafeInterval)(t.viewabilityIntervalId),
            (t.viewabilityIntervalId = void 0),
            this.destroyAllViewabilityMethods(t));
        }
        getSupportedMethod(t) {
          let e;
          const i = [v.OmidMethod],
            o = (0, y.isInAppSupported)(t.supportedDeliveryType);
          return (
            this.reportIntersectionObserverSupportDiagnostics(t),
            (e = o
              ? [f.AdColonyMethod, b.Mraid3Method, u.MraidMethod]
              : [
                  s.GeometricMethod,
                  r.IntersectionObserverMethod,
                  l.AmpIntersectionObserverMethod,
                  n.ResourceBased,
                  a.ScreenGeometricMethod,
                ]),
            (e = [...i, ...e]),
            e.find((e) => e.isSupported(t))
          );
        }
        reportIntersectionObserverSupportDiagnostics(t) {
          var e, i;
          const n =
              t.windowElement &&
              "IntersectionObserver" in t.windowElement &&
              "IntersectionObserverEntry" in t.windowElement &&
              "intersectionRatio" in
                t.windowElement.IntersectionObserverEntry.prototype,
            s = !!(null ===
              (i =
                null === (e = null == t ? void 0 : t.windowElement) ||
                void 0 === e
                  ? void 0
                  : e.context) || void 0 === i
              ? void 0
              : i.observeIntersection);
          w.DiagnosticParamsReporterSingleton.reportOnce(
            w.DiagnosticParams.intersectionObserverMethodSupported,
            n ? 1 : 0
          ),
            w.DiagnosticParamsReporterSingleton.reportOnce(
              w.DiagnosticParams.ampIntersectionObserverMethodSupported,
              s ? 1 : 0
            );
        }
        getAllViewabilityMethods(t) {
          const { viewabilityMethods: e } = t;
          return [e.primary, ...e.experiments];
        }
        publishAdViewabilityData(t) {
          try {
            this.getAllViewabilityMethods(t).forEach((e) => {
              this.publishViewabilityMethodData(t, e);
            }),
              this.checkIfElementAttachedToDocument(t);
          } catch (t) {
            g.L.sendError(y.ClientErrorType.MeasurementError, t);
          }
        }
        publishViewabilityMethodData(t, e) {
          const { calculationMethod: i, intervalDvEvent: n } = e,
            s = i.getAdCandidateAssets(t);
          s && d.k.dispatchEvent(n, new c.AdCandidateEventData(t, s));
        }
        checkIfElementAttachedToDocument(t) {
          t.timeMsUntilAdNotAttached ||
            m.S.isElementAttachedToDocument(t.domElement) ||
            ((t.timeMsUntilAdNotAttached = p.Utilities.getTimeDiff()),
            d.k.dispatchEvent(
              d.DvEvents.reportData,
              new c.AdCandidateEventData(t)
            ));
        }
      }
      e.ViewabilityDataCollector = S;
    },
    3044: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdCandidateData = void 0);
      const n = i(8844),
        s = i(1906);
      e.AdCandidateData = class {
        constructor(t) {
          (this.state = 1),
            (this.supportedDeliveryType = []),
            (this.domEvents = {}),
            (this.customInteractions = []),
            (this.wasAdStopped = !1),
            (this.isPaused = !1),
            (this.videoPlaybackHtml5QuartileId = 1),
            (this.videoPlaybackHtml5Events = []),
            (this.volumeDurationQuartileId = 1),
            (this.IABAdViewableForXSecondsViewedTime = 0),
            (this.iabViewablitiyTimeToCheck = [5, 10, 15]),
            (this.IABAdViewableForXSecondsdurationRequirement = 5e3),
            (this.boundariesViewed = {
              topLeft: !1,
              topRight: !1,
              bottomLeft: !1,
              bottomRight: !1,
            }),
            (this.adHasPlayed = !1),
            (this.activeViewabilityMeasurements = {}),
            (this.iabViewedTime = 0),
            (this.iabViewedTimeSecondary = 0),
            (this.iabVideoQuartileId = 1),
            (this.iabVideoQuartileViewed = 0),
            (this.videoFullQuartileViewabilityId = 1),
            (this.videoFullQuartileAudibleId = 1),
            (this.notViewableReasonWasInFocus = !1),
            (this.notViewableReasonWasInViewPort = !1),
            (this.notViewableReasonConsecutiveViewTime = 0),
            (this.notViewableReasonCumulativeViewTime = 0),
            (this.notViewableReasonWasViewed = !1),
            (this.notViewableReasonVideoPlayed = !1),
            (this.groupMViewedTime = 0),
            (this.groupMV4DisplayViewedTime = 0),
            (this.groupMV4VideoReachExtensionViewedTime = 0),
            (this.groupMV4VideoNativeViewedTime = 0),
            (this.groupMV4DisplayViewedTimeLog = 0),
            (this.pmxViewedTime = 0),
            (this.videoBucketsQuartileId = 1),
            (this.isVideoInViewBucketsMeasured = !1),
            (this.viewabilityIntervalDataCalled = !1),
            (this.autoplayEventSubscriptionIds = []),
            (this.videoPlaybackByVpaidEventSubscriptionIds = []),
            (this.position = null),
            (this.current50PctAdContinuousInViewTimeMs = 0),
            (this.current50PctAdContinuousInViewTimeMsNoPauseReset = 0),
            (this.domElement = t);
        }
        markAdQuartile(t, e) {
          switch (e) {
            case 1:
              this.exposureFirstQuartileBitwise =
                this.exposureFirstQuartileBitwise | t;
              break;
            case 2:
              this.exposureSecondQuartileBitwise =
                this.exposureSecondQuartileBitwise | t;
              break;
            case 3:
              this.exposureThirdQuartileBitwise =
                this.exposureThirdQuartileBitwise | t;
              break;
            case 4:
              this.exposureFourthQuartileBitwise =
                this.exposureFourthQuartileBitwise | t;
          }
        }
        isInViewBucketsMeasured() {
          return !!(0 == n.A.getTagType()
            ? this.viewabilityDisplayBucketsUnloadTime > 0
            : this.isVideoInViewBucketsMeasured);
        }
        getAtLeast50PercentInViewDurationInMs() {
          if (!this.isInViewBucketsMeasured()) return null;
          const t = [this.b6, this.b7, this.b8, this.b9, this.b10, this.b11],
            e = [
              this.q1b3,
              this.q1b4,
              this.q1b5,
              this.q2b3,
              this.q2b4,
              this.q2b5,
              this.q3b3,
              this.q3b4,
              this.q3b5,
              this.q4b3,
              this.q4b4,
              this.q4b5,
            ];
          return 0 == n.A.getTagType()
            ? Math.min(s.Utilities.sumBuckets(t) || 0, 6e4)
            : s.Utilities.sumBuckets(e);
        }
        get100PercentInViewDurationInMs() {
          if (!this.isInViewBucketsMeasured()) return null;
          const t = [this.q1b5, this.q2b5, this.q3b5, this.q4b5];
          return 0 == n.A.getTagType()
            ? Math.min(this.b11 || 0, 6e4)
            : s.Utilities.sumBuckets(t);
        }
      };
    },
    4126: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdDataMappingToReport = void 0);
      const n = i(1360);
      e.AdDataMappingToReport = {
        timeMsUntilAdMeasured: "ismms",
        unadjustedTimeMsUntilAdMeasured: "isumms",
        isViewabilityEligible: "isvelg",
        notViewableReason: "nvr",
        groupMTimeMsUntilAdMeasured: "isgmmims",
        groupMV4TimeMsUntilAdMeasured: "isgmv4mims",
        adElementType: "elmtp",
        measuredElementType: "metp",
        measuredElementExtractorId: "meeid",
        largestChildElementHeight: "lceh",
        largestChildElementWidth: "lcew",
        viewabilityDisplayBucketsUnloadTime: "isbxdms",
        b0: "b0",
        b1: "b1",
        b2: "b2",
        b3: "b3",
        b4: "b4",
        b5: "b5",
        b6: "b6",
        b7: "b7",
        b8: "b8",
        b9: "b9",
        b10: "b10",
        b11: "b11",
        napt: "napt",
        isq1ms: "isq1ms",
        q1b0: "q1b0",
        q1b1: "q1b1",
        q1b2: "q1b2",
        q1b3: "q1b3",
        q1b4: "q1b4",
        q1b5: "q1b5",
        q1napt: "q1napt",
        isq2ms: "isq2ms",
        q2b0: "q2b0",
        q2b1: "q2b1",
        q2b2: "q2b2",
        q2b3: "q2b3",
        q2b4: "q2b4",
        q2b5: "q2b5",
        q2napt: "q2napt",
        isq3ms: "isq3ms",
        q3b0: "q3b0",
        q3b1: "q3b1",
        q3b2: "q3b2",
        q3b3: "q3b3",
        q3b4: "q3b4",
        q3b5: "q3b5",
        q3napt: "q3napt",
        isq4ms: "isq4ms",
        q4b0: "q4b0",
        q4b1: "q4b1",
        q4b2: "q4b2",
        q4b3: "q4b3",
        q4b4: "q4b4",
        q4b5: "q4b5",
        q4napt: "q4napt",
        q1ad: "q1ad",
        q2ad: "q2ad",
        q3ad: "q3ad",
        q4ad: "q4ad",
        iabv5: "iabv5",
        iabv10: "iabv10",
        iabv15: "iabv15",
        maxVideoVolume: "avmax",
        minVideoVolume: "avmin",
        ivab0: "ivab0",
        ivab1: "ivab1",
        ivab2: "ivab2",
        ivab3: "ivab3",
        ivab4: "ivab4",
        ivab5: "ivab5",
        ivab6: "ivab6",
        ivab7: "ivab7",
        ivab8: "ivab8",
        ivab9: "ivab9",
        ivab10: "ivab10",
        ivab11: "ivab11",
        ivanapt: "ivanapt",
        adHeight: "adhgt",
        adWidth: "adwdth",
        normalizedAdWidth: "norwdth",
        normalizedAdHeight: "norhgt",
        accumulativeTimeOrientationLandscape: "tmsl",
        accumulativeTimeOrientationPortrait: "tmsp",
        avgViewableShareOfScreen: "vsos",
        avgInViewShareOfScreen: "ivsos",
        shareOfScreenNotMeasuredReason: "dvp_vsosnmr",
        inViewShareOfScreenMeasured: "ivsosm",
        shareOfScreenReadFromViewportReport: "dvp_vsosrfvp",
        viewPortMetaTagWidth: "dvp_mvpw",
        viewPortMetaTagHeight: "dvp_mvph",
        viewPortMetaTagInitialScale: "dvp_mvpis",
        viewPortMetaTagScalable: "dvp_mvpiss",
        minViewportWidth: "dvp_minvpw",
        minViewportHeight: "dvp_minvph",
        maxViewportWidth: "dvp_maxvpw",
        maxViewportHeight: "dvp_maxvph",
        accumulativeTimeInFocus: "attif",
        looseFocusFalseBucket: "lffb",
        looseFocusTrueBucket: "lftb",
        strictFocusFalseBucket: "sffb",
        strictFocusTrueBucket: "sftb",
        adDuration: "vad",
        adDurationCalculationType: "vadct",
        omidPlaybackStartIndicator: "omap",
        adVideoTimeLine: "vattp",
        timeUntilUnloadMs: "tuums",
        depth: "msrdp",
        N: "naral",
        viewabilityCalculationType: "vct",
        viewportHeight: "vphgt",
        viewportWidth: "vpwdth",
        adWrapperHeight: "chgt",
        adWrapperWidth: "cwdth",
        screenHeight: "scrhgt",
        screenWidth: "scrwdth",
        startPercentage: "strp",
        adVisibleOnload: "advisonl",
        rBV1PassedMs: "isrbpms",
        timeMsUntilAdViewed: "isiabvms",
        unadjustedTimeMsUntilAdViewed: "isuiabvms",
        groupMTimeMsUntilAdViewed: "isgmpims",
        groupMV4DisplayTimeMsUntilAdViewed: "isgmv4dpims",
        groupMV4DisplayTimeMsUntilAdViewedLog: "dvp_gmv4p",
        pmxTimeMsUntilAdViewed: "ispmxpms",
        timeUntilCustomViewabilityMeasuredMs: "iscvmeas",
        timeUntilCustomViewabilityPassedMs: "iscvmvms",
        videoPlaybackIndicatorDvp: "dvp_vpb",
        videoPlaybackIndicator: "vpm",
        isVideoPreRendered: "prplyd",
        timeMsUntilVideoPlayed: "dvp_plydms",
        groupMV4VideoReachExtensionTimeMsUntilAdViewed: "isgmv4vrpims",
        groupMV4VideoNativeTimeMsUntilAdViewed: "isgmv4vnpims",
        timeUntilAudibleOnCompleteMs: "tuaudcompms",
        timeMsUntilAdAudibleAndViewableOnCompletionMs: "qcmpiabva",
        lastTimeMsVolumeMute: "admutems",
        timeMsUntilVolumeMeasured: "isavmms",
        q1vpend: "q1vpend",
        q2vpend: "q2vpend",
        q3vpend: "q3vpend",
        q4vpend: "q4vpend",
        q1ps: "q1ps",
        q2ps: "q2ps",
        q3ps: "q3ps",
        q4ps: "q4ps",
        q1iabvms: "q1iabvms",
        q2iabvms: "q2iabvms",
        q3iabvms: "q3iabvms",
        q4iabvms: "q4iabvms",
        exposureFirstQuartileBitwise: "q1ei",
        exposureSecondQuartileBitwise: "q2ei",
        exposureThirdQuartileBitwise: "q3ei",
        exposureFourthQuartileBitwise: "q4ei",
        adSkippedTime: "isadskippedms",
        adSkippableMs: "adskippblems",
        initialOrientationType: "inor",
        timeMsUntilTouch: "engtchms",
        timeMsUntilTouchDeepDescendantIframe: "tddims",
        isHoverMeasured: "ishvm",
        isTouchMeasured: "istchm",
        isKeyPressMeasured: "iskpm",
        isMouseMoveMeasured: "ismmm",
        isOrientationChangeMeasured: "isocm",
        isAdSizeChangeMeasured: "isascm",
        isClickMeasured: "isaclkm",
        isScrollMeasured: "isscrlm",
        timeMsUntilHover: "enghvms",
        timeMsUntilClick: "engclkms",
        timeMsUntilClickDeepDescendantIframe: "clkddms",
        timeMsUntilAdSizeIncrease: "engsincms",
        timeMsUntilAdSizeDecrease: "engsdcms",
        timeMsUntilAdSizeChange: "engsccms",
        timeMsUntilAdLocated: "engalms",
        timeMsUntilFocusIn: "engifcsms",
        timeMsUntilFocusOut: "engofcsms",
        clickMeasurementMethod: "dvp_ces",
        timeMsUntilMouseMove: "engmsmvms",
        timeMsUntilKeyPress: "engkpssms",
        timeMsUntilScroll: "engscrlms",
        timeMsUntilScrollV2: "engscrlmsv2",
        timeMsUntilScrollV3: "engscrlmsv3",
        timeMsUntilOrientationChangeToPortrait: "engocptms",
        timeMsUntilOrientationChangeToLandscape: "engoclpms",
        timeMsUntilVolumeIncrease: "engvlincms",
        timeMsUntilVolumeDecrease: "engvldcms",
        timeMsUntilVolumeUnMute: "engvlumms",
        timeMsUntilVolumeMute: "engvlmtms",
        timeMsUntilVolumeChange: "engvlchms",
        timeMsUntilPause: "engvpsdms",
        timeMsUntilResume: "engvrsmms",
        timeMsUntilSkip: "engvskpms",
        timeMsUntilAbandon: "engvabnms",
        engagementAudienceDisengaged: "dvp_engaud",
        engagementAudienceEngaged: "dvp_engaud",
        engagementAudienceNoEngagement: "dvp_engaud",
        engagementAudienceInterested: "dvp_engaud",
        videoViewabilityIntervalDataAdSizeMethod: "dvp_vvasm",
        videoViewabilityIntervalDataAdSize: "dvp_vvas",
        preVideoAdLoaded: "dvp_in1",
        preVideoAdStarted: "dvp_in2",
        preVideoAdImpression: "dvp_in3",
        preVideoAdStopped: "dvp_in4",
        autoplayDetectionMethod: "dvp_autpm",
        mraidVersion: "dvp_mraidver",
        hiddenAdsIndicator: "dvp_hdnAd",
        adEngagement: "dvp_adEng",
        pageEngagement: "dvp_pageEng",
        noEngagement: "dvp_noEng",
        omidEvents: "omev",
        omidGeometryReasonsBitWise: "omgr",
        omidContainerGeometryHeight: "dvp_ocgh",
        omidContainerGeometryWidth: "dvp_ocgw",
        omidCreativeVsContainerIndicator: "dvp_omcvc",
        omidImpressionType: "omit",
        omidUnknownImpressionType: "dvp_omuit",
        omidCreativeType: "omct",
        omidUnknownCreativeType: "dvp_omuct",
        omidRenderLogicLog: "dvp_orll",
        omidPageUrl: "ompurl",
        omidDeviceOS: "omdos",
        omidDeviceOSVersion: "omdosv",
        omidDeviceType: "omdt",
        omidImpressionEventTimestamp: "omiet",
        omidAdSessionType: "omdsessiontype",
        omidJSServiceVersion: "omjssv",
        shareOfScreenLastDevicePixelRatio: "dvp_dpr",
        devicePixelRatioChanged: "dvp_sosdprc",
        screenSizeChanged: "dvp_sosssc",
        adSizeChanged: "dvp_sosadc",
        timeMsUntilAdNotAttached: "dvp_anatd",
        timeUntilPageHideEventNonPersistedMs: "yld_phnpms",
        visitResponseSize: "vstsz",
        max50PctAdContinuousInViewTimeMs: "m50invms",
        max50PctAdContinuousInViewTimeMsNoPauseReset: (0,
        n.getDiagnosticQueryParamName)(
          n.DiagnosticParams.max50PctAdContinuousInViewTimeMsNoPauseReset
        ),
        timeMsUntilAdMeasuredSecondary: (0, n.getDiagnosticQueryParamName)(
          n.DiagnosticParams.secondaryIabViewabilityMeasured
        ),
        timeMsUntilAdViewedSecondary: (0, n.getDiagnosticQueryParamName)(
          n.DiagnosticParams.secondaryIabViewable
        ),
      };
    },
    8334: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.RTSEventNames = e.RTSDataMapping = void 0),
        (e.RTSDataMapping = {
          timeMsUntilAdMeasured: "IABMeasuredImpression",
          timeMsUntilAdViewed: "IABViewableImpression",
          groupMTimeMsUntilAdMeasuredRTS: "GroupMMeasuredImpression",
          groupMTimeMsUntilAdViewedRTS: "GroupMPassedImpression",
          groupMV3TimeMsUntilAdViewedRTS: "GroupMV3StandardPassedImpression",
          groupMV4TimeMsUntilAdViewedRTS: "GroupMV4StandardPassedImpression",
          groupMV4DisplayTimeMsUntilAdViewedRTS:
            "GroupMV4DisplayStandardPassedImpression",
          groupMV4VideoReachExtensionTimeMsUntilAdViewedRTS:
            "GroupMV4VideoReachExtensionStandardPassedImpression",
          groupMV4VideoNativeTimeMsUntilAdViewedRTS:
            "GroupMV4VideoNativeStandardPassedImpression",
          timeUntilCustomViewabilityPassedMs: "CustomViewabilityViewable",
          q1iabvms: "VideoQuartile1ViewableIAB",
          q2iabvms: "VideoQuartile2ViewableIAB",
          q3iabvms: "VideoQuartile3ViewableIAB",
          q4iabvms: "VideoQuartile4ViewableIAB",
          iabv5: "IABAdViewable5Seconds",
          iabv10: "IABAdViewable10Seconds",
          iabv15: "IABAdViewable15Seconds",
          pmxTimeMsUntilAdMeasured: "PMXStandardMeasuredImpression",
          pmxTimeMsUntilAdViewed: "PMXStandardPassedImpression",
          engagementAudienceDisengaged: "EngagementAudienceDisengaged",
          engagementAudienceEngaged: "EngagementAudienceEngaged",
          engagementAudienceNoEngagement: "EngagementAudienceNoEngagement",
          engagementAudienceInterested: "EngagementAudienceInterested",
          adEngagement: "AdInteraction",
          pageEngagement: "DeviceInteraction",
          noEngagement: "NoInteraction",
          isMrcImpression: "MRCImpression",
        }),
        (e.RTSEventNames = [
          "ImpressionServed",
          "SessionEnd",
          "IABNotMeasuredImpression",
          ...Object.values(e.RTSDataMapping),
        ]);
    },
    8969: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdCandidateEventData = void 0);
      const n = i(1206);
      class s extends n.EventData {
        constructor(t, e = {}) {
          super(e.updateTime),
            (this.adCandidate = t),
            (this.relevantData = e),
            (this.updateTime = e.updateTime || this.updateTime),
            (e.updateTime = this.updateTime);
        }
      }
      e.AdCandidateEventData = s;
    },
    5318: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.q = void 0);
      const n = i(1206);
      class s extends n.EventData {
        constructor(t, e) {
          super(), (this.diagnosticData = t), (this.N = e);
        }
      }
      e.q = s;
    },
    1563: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdRenderedEventData = void 0);
      const n = i(1206);
      class s extends n.EventData {
        constructor(t) {
          super(), (this.uid = t);
        }
      }
      e.AdRenderedEventData = s;
    },
    1206: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.EventData = void 0);
      const n = i(1906);
      e.EventData = class {
        constructor(t) {
          this.updateTime = t || n.Utilities.getTimeDiff();
        }
      };
    },
    8882: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.LongTaskEventData = void 0);
      const n = i(1206);
      class s extends n.EventData {
        constructor(t) {
          super(), (this.longTasks = t);
        }
      }
      e.LongTaskEventData = s;
    },
    405: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PerformanceEventData = void 0);
      const n = i(1206);
      class s extends n.EventData {
        constructor(t, e) {
          super(), (this.performanceData = t), (this.adData = e);
        }
      }
      e.PerformanceEventData = s;
    },
    5602: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.TaskTimingEventData = void 0);
      const n = i(1206);
      class s extends n.EventData {
        constructor(t) {
          super(), (this.taskTimings = t);
        }
      }
      e.TaskTimingEventData = s;
    },
    3283: function (t, e, i) {
      var n =
          (this && this.__createBinding) ||
          (Object.create
            ? function (t, e, i, n) {
                void 0 === n && (n = i);
                var s = Object.getOwnPropertyDescriptor(e, i);
                (s &&
                  !("get" in s
                    ? !e.__esModule
                    : s.writable || s.configurable)) ||
                  (s = {
                    enumerable: !0,
                    get: function () {
                      return e[i];
                    },
                  }),
                  Object.defineProperty(t, n, s);
              }
            : function (t, e, i, n) {
                void 0 === n && (n = i), (t[n] = e[i]);
              }),
        s =
          (this && this.__exportStar) ||
          function (t, e) {
            for (var i in t)
              "default" === i ||
                Object.prototype.hasOwnProperty.call(e, i) ||
                n(e, t, i);
          };
      Object.defineProperty(e, "__esModule", { value: !0 }),
        s(i(8969), e),
        s(i(1563), e),
        s(i(1206), e),
        s(i(8882), e),
        s(i(405), e),
        s(i(5602), e);
    },
    8595: (t, e) => {
      var i;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.Pt = void 0),
        (function (t) {
          (t[(t.omid = 1)] = "omid"),
            (t[(t.vpaid = 2)] = "vpaid"),
            (t[(t.custom = 3)] = "custom"),
            (t[(t.adsrv = 4)] = "adsrv"),
            (t[(t.marked = 5)] = "marked"),
            (t[(t.auto = 6)] = "auto"),
            (t[(t.manual = 7)] = "manual");
        })(i || (e.Pt = i = {}));
    },
    9765: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.isBtregDetected =
          e.isCeltraDetected =
          e.isDfaDetected =
          e.isDisplayGenXDetected =
          e.isMraidDetected =
          e.isVpaidDetected =
          e.isOmidDetected =
          e.isDisplayDetected =
            void 0);
      const n = i(8844),
        s = i(5473),
        r = i(4642),
        o = i(9135);
      e.isDisplayDetected = () => 0 === n.A.getTagType();
      e.isOmidDetected = () => {
        var t;
        return null !== (t = n.omidAdapter.isSupported()) && void 0 !== t && t;
      };
      e.isVpaidDetected = () => {
        var t;
        return null !== (t = r.VpaidWrapper.isSupported()) && void 0 !== t && t;
      };
      e.isMraidDetected = () => {
        var t;
        return null !== (t = s.MraidWrapper.isSupported()) && void 0 !== t && t;
      };
      e.isDisplayGenXDetected = () => {
        const t = n.A.isDisplayGenXEnabled(),
          e = n.A.getPartnerContainerId();
        return t && null != e && "" !== e;
      };
      e.isDfaDetected = () => n.A.getAdServerId() === o.DFA_AD_SERVER_ID;
      e.isCeltraDetected = () => n.A.getAdServerId() === o.CELTRA_AD_SERVER_ID;
      e.isBtregDetected = () => null != n.A.getBtreg();
    },
    4810: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.kt = void 0);
      const n = i(8844),
        s = i(8595),
        r = i(9765);
      e.kt = () => {
        const t = ((t) => {
          if ("string" != typeof t) return;
          const e = s.Pt[t];
          return "number" == typeof e ? e : void 0;
        })(n.A.getLowerCaseParams().alm);
        return null != t
          ? t
          : (0, r.isOmidDetected)()
          ? s.Pt.omid
          : (0, r.isVpaidDetected)()
          ? s.Pt.vpaid
          : (0, r.isDisplayGenXDetected)()
          ? s.Pt.adsrv
          : (0, r.isBtregDetected)() && (0, r.isDisplayDetected)()
          ? s.Pt.marked
          : s.Pt.auto;
      };
    },
    8114: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.Nt = void 0);
      const n = i(8595),
        s = i(783),
        r = i(4380),
        o = i(3047),
        a = i(7934),
        d = i(2388),
        c = i(4165),
        l = i(9453),
        u = i(7345),
        h = i(8356),
        v = i(4633),
        p = i(7031),
        m = i(9765),
        f = i(991),
        g = () => {
          const t = [],
            e = [];
          if (l.AdLocationModuleWrapper.getInstance().detectCeltraElement()) {
            const i = new r.et();
            t.push(i.bit), e.push(i);
          }
          if ((0, m.isMraidDetected)()) {
            const i = new f.lt();
            t.push(i.bit), e.push(i);
          }
          const i = new v.st();
          t.push(i.bit), e.push(i);
          const n = new h.Mt();
          t.push(n.bit), e.push(n);
          const s = new p.ct();
          t.push(s.bit), e.push(s);
          const o = new u.K();
          return t.push(o.bit), e.push(o), { Lt: t, Ft: e };
        };
      e.Nt = (t) => {
        switch (t) {
          case n.Pt.manual: {
            const t = new c.ut();
            return {
              Ut: { mainBit: t.bit, fallbackBits: [] },
              Bt: () => {
                t.start();
              },
            };
          }
          case n.Pt.omid: {
            const t = new o.At();
            return {
              Ut: { mainBit: t.bit, fallbackBits: [] },
              Bt: () => {
                t.start();
              },
            };
          }
          case n.Pt.vpaid: {
            const t = new a.Tt();
            return {
              Ut: { mainBit: t.bit, fallbackBits: [] },
              Bt: () => {
                t.start();
              },
            };
          }
          case n.Pt.adsrv: {
            const t = new d.F(),
              { Lt: e, Ft: i } = g();
            return {
              Ut: { mainBit: t.bit, fallbackBits: e },
              Bt: () => {
                t.start(),
                  i.forEach((t) => {
                    t.start();
                  });
              },
            };
          }
          case n.Pt.marked: {
            const t = new s.vt(),
              { Lt: e, Ft: i } = g();
            return {
              Ut: { mainBit: t.bit, fallbackBits: e },
              Bt: () => {
                t.start(),
                  i.forEach((t) => {
                    t.start();
                  });
              },
            };
          }
          case n.Pt.custom: {
            const t = new r.et();
            return {
              Ut: { mainBit: t.bit, fallbackBits: [] },
              Bt: () => {
                t.start();
              },
            };
          }
          default: {
            const { Lt: t, Ft: e } = g();
            return {
              Ut: { mainBit: null, fallbackBits: t },
              Bt: () => {
                e.forEach((t) => {
                  t.start();
                });
              },
            };
          }
        }
      };
    },
    1081: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }), (e.zt = void 0);
      const n = i(4642),
        s = i(251),
        r = i(4810),
        o = i(8114),
        a = i(7614);
      e.zt = () => {
        let t = { mainBit: null, fallbackBits: [] };
        return {
          Bt: () => {
            var e, i, d, c;
            (0, s.initialize)(n.VpaidWrapper);
            const l = (0, r.kt)();
            a.adLocationSelectionDiagnostics.recordAdLocatingMode(l);
            const u = (0, o.Nt)(l);
            (t = {
              mainBit:
                null !==
                  (i =
                    null === (e = u.Ut) || void 0 === e ? void 0 : e.mainBit) &&
                void 0 !== i
                  ? i
                  : null,
              fallbackBits:
                null !==
                  (c =
                    null === (d = u.Ut) || void 0 === d
                      ? void 0
                      : d.fallbackBits) && void 0 !== c
                  ? c
                  : [],
            }),
              u.Bt();
          },
          Dt: () => t,
        };
      };
    },
    8261: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 });
      const n = i(1167),
        s = i(8395),
        r = i(1706),
        o = i(8844),
        a = i(1805),
        d = i(7102),
        c = i(6463),
        l = i(3283),
        u = i(1906),
        h = i(9579),
        v = i(1225),
        p = i(2181),
        m = i(3782),
        f = i(8633),
        g = i(7943),
        b = i(7394),
        w = i(2903),
        _ = i(1383),
        y = i(5963),
        S = i(5349),
        M = i(7898),
        O = i(8082),
        E = i(6725),
        A = i(3906),
        T = i(3079),
        I = i(7970),
        C = i(704),
        D = i(4692),
        j = i(8175),
        V = i(7194),
        R = i(7703),
        x = i(9911),
        P = i(3073),
        k = i(8362),
        N = i(7797),
        L = i(8360),
        F = i(8960),
        U = i(9829),
        B = i(1816),
        z = i(9155),
        W = i(670),
        q = i(8392),
        $ = i(1003),
        H = i(7093),
        G = i(6384),
        J = i(4112),
        K = i(5051),
        Q = i(5069),
        Y = i(1008),
        X = i(4444),
        Z = i(5450),
        tt = i(7982),
        et = i(8624),
        it = i(7065),
        nt = i(1360);
      G.default.setInitFireVisitImportsEndTime(),
        G.default.setInitFireVisitImportsStartTime(
          n.initFireVisitImportsStartTime
        );
      const st = i(794).MG;
      e.default = async () =>
        new Promise((t) => {
          !(function (t) {
            function e() {
              const {
                omidJsClient: t,
                omidSessionData: e,
                isDomlessEnvironment: i,
                isFrameSupported: n,
                tags: s,
                tagsCounter: r,
                omidSessionStartTime: o,
                omidVendorKey: a,
                tagData: d,
                restrictedAccess: c,
                pubSub: l,
                isPubSubEval: u,
                sharedUniqueKey: h,
                dvGetOmidVerificationClient: v,
              } = $dv;
              $dv = {
                dvGetOmidVerificationClient: v,
                omidJsClient: t,
                omidSessionData: e,
                isDomlessEnvironment: i,
                isFrameSupported: n,
                tags: s,
                tagsCounter: r,
                omidSessionStartTime: o,
                omidVendorKey: a,
                tagData: d,
                restrictedAccess: c,
                pubSub: l,
                isPubSubEval: u,
                sharedUniqueKey: h,
              };
            }
            function i() {
              if (it.TcfClientStop.isExecutionStopped()) return;
              const t = o.O.currentWindow(),
                e = o.T.getImpressionId(t);
              (0, tt.detectImpressionIdMisalignment)(e),
                a.L.firePreviousEvents(),
                a.L.sendMessage({ msrjs: u.Utilities.getVersion() }),
                d.k.dispatchEvent(
                  d.DvEvents.impressionServed,
                  new l.EventData()
                );
            }
            function n() {
              const t = o.O.currentWindow(),
                e = o.T.getFrameId(t),
                n = o.T.getImpressionId(t),
                s = o.T.u();
              s.isPubSubEval || n || ((s.pubSub = d.Ct), (s.isPubSubEval = !0)),
                s.pubSub.excludeFrameId && s.pubSub.excludeFrameId(e),
                s.pubSub.subscribe(
                  d.DvEvents.impressionServed,
                  e,
                  "DVM_impressionServed",
                  i
                );
            }
            function rt() {
              return [
                new p.DvParamsCollector(),
                new V.ParamUrlExtractionMethodCollector(),
                new m.BrowserCollector(),
                new f.TrafficScenarioCollector(),
                new v.PreRenderCollector(),
                new I.MraidCollector(),
                new x.OmidContextCollector(),
                new R.TpsApiTypeCollector(),
                new T.SslCollector(),
                new C.SupplySourceCollector(),
                new P.ReferrerCollector(),
                new _.WindowPropertiesCollector(),
                new g.StrCollector(),
                new b.VideoParamsCollector(),
                new w.IOSMapleCollector(),
                new y.DomScriptCollector(),
                new S.ScriptsPerformanceCollector(),
                new M.UserCollector(),
                new O.BrowserSignatureCollector(),
                new D.InjectionDetectionCodeCollector(),
                new j.HijackedDeviceSignatureCollector(),
                new E.BrowserFeaturesCollector(),
                new A.AttributeCollector(),
                new k.VastUrlCollector(),
                new N.HardwareFeaturesCollector(),
                new L.SupportedIntegrationsCollector(),
                new F.Cm360DedupDiagnosticCollector(),
              ];
            }
            function ot(t) {
              return [
                new U.TPSDataCollector(t),
                new z.MeasureGdpr(),
                new W.MeasureGdprV2(),
                new B.GlobalVariablesInjection(),
              ];
            }
            (0, h.initializeRuntimeDependencies)();
            let at = 0;
            function dt() {
              const t = new J.TPSData();
              (0, c.initialize)(o.A), Y.tcfClientStopExperiment.init();
              const e = it.TcfClientStop.initialize(
                o.A.getLowerCaseParams(),
                o.A.getCaseSensitiveParams(),
                Y.tcfClientStopExperiment.isEnabled()
              );
              it.TcfClientStop.isExecutionStopped() && a.L.discardQueuedData(),
                (0, Z.setupIplessSideBySideInjection)(t),
                $.RenderLogicFactory.getRenderLogic().start();
              const i = ot(rt());
              return (
                (at = X.VisitJsonFlow.shouldUse({
                  experimentEnabled: u.Utilities.isPercentageCriteriaPassed(1),
                })),
                o.T.setVisitFlowType(at),
                i.forEach((e) => {
                  try {
                    e.isSupported(t) && e.executePhase(t, at);
                  } catch (t) {
                    a.L.sendError(
                      J.ClientErrorType.VisitLogicError,
                      t,
                      e.toString()
                    );
                  }
                }),
                (t.additionalParams[
                  (0, nt.getDiagnosticQueryParamName)(
                    nt.DiagnosticParams.tcfDvDisclosure
                  )
                ] = e),
                (t.additionalParams[
                  (0, nt.getDiagnosticQueryParamName)(
                    nt.DiagnosticParams.tcfRolloutPercentage
                  )
                ] = Y.tcfClientStopExperiment.getRolloutPercentage()),
                t
              );
            }
            function ct() {
              return (
                !o.O.isDomlessEnvironment() &&
                o.A.getIsBlockingEnabled() &&
                o.T.getIsBlockingEnabled() &&
                !o.T.getTagHasVendorKey() &&
                (0 === o.A.getTagType() ||
                  (1 === o.A.getTagType() &&
                    "jsVpaid" === o.A.getMeasurementApi()))
              );
            }
            function lt(t, e) {
              G.default.setFireVerifyExecutionStartTime();
              st(t, e, o.S, o.T, o.A, o.O, H.blockingHooks).execute(),
                G.default.setFireVerifyExecutionEndTime();
            }
            function ut() {
              if (!o.A.isDisplayGenXEnabled() || 0 !== o.A.getTagType()) return;
              const t = o.A.getPartnerContainerId(),
                e = (0, o.getElementById)(t);
              e && (0, o.safeSetElementStyle)(e, "visibility", "");
            }
            function ht(t) {
              G.default.setFireVisitExecutionStartTime();
              const e = new q.ScriptsInjection();
              e.isSupported() && e.executePhase(t, at),
                (ft = !0),
                G.default.setFireVisitExecutionEndTime();
            }
            function vt(e) {
              ut(), ht(e), t();
            }
            function pt() {
              if (
                (G.default.setInitMainExecutionStartTime(),
                e(),
                n(),
                !(0, K.isBrowserSupported)())
              )
                return;
              (0, et.initialize)(a.L);
              const t = (0, K.invokeWithPerformanceMeasures)(
                { name: "ctdetms" },
                dt
              );
              (0, Q.initializeExperiments)(),
                ct() ? lt(t, vt) : o.A.getIsMonitoringEnabled() ? vt(t) : ut(),
                G.default.setInitMainExecutionEndTime();
            }
            function mt() {
              if (!(0, o.isPerformanceTimingAllowed)()) return;
              const t = G.default.getBenchmarks();
              (0, K.scheduleTask)(() => {
                [
                  ...t,
                  {
                    taskDetails: { name: "srbf" },
                    startTime: 0,
                    endTime: ct() ? 2 : 1,
                  },
                ].forEach(({ taskDetails: t, startTime: e, endTime: i }) => {
                  (0, K.reportTaskTiming)(t, e, i);
                });
              });
            }
            let ft = !1;
            try {
              o.T.setDvGetOmidVerificationClient(s),
                Y.randomizeOmidVendorKeyExperiment.init(),
                Y.omidConstructTimeParamMismatchPayloadExperiment.init();
              const t = new r.OmidVerificationClientWrapper(s());
              t.isSupported() ? t.ready(pt) : pt(),
                G.default.setTotalSyncTimeEndTime(),
                mt();
            } catch (t) {
              ft
                ? a.L.sendError(
                    J.ClientErrorType.PostMeasuredGlobalMainError,
                    t
                  )
                : a.L.sendError(
                    J.ClientErrorType.PreMeasuredGlobalMainError,
                    t
                  );
            }
          })(t);
        });
    },
    2881: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.initAdDataLoggerBL = e.initAdBL = void 0);
      const n = i(6370),
        s = i(9653),
        r = i(3772),
        o = i(688),
        a = i(8909),
        d = i(48),
        c = i(5782),
        l = i(7652),
        u = i(2681),
        h = i(9236),
        v = i(4234),
        p = i(9855),
        m = i(4710),
        f = i(2911),
        g = i(8086),
        b = i(6444),
        w = i(6873),
        _ = i(3907),
        y = i(200),
        S = i(2790),
        M = i(824),
        O = i(2090),
        E = i(3543),
        A = i(8528),
        T = i(5681),
        I = i(1240),
        C = i(1134),
        D = i(4545),
        j = i(9137),
        V = i(4602),
        R = i(5589),
        x = i(7331),
        P = i(4e3),
        k = i(6065),
        N = i(1204),
        L = i(3758),
        F = i(7651),
        U = i(3555),
        B = i(7533),
        z = i(1942),
        W = i(1307),
        q = i(4770),
        $ = i(8160),
        H = i(8649),
        G = i(2422),
        J = i(9471),
        K = i(8035),
        Q = i(9468),
        Y = i(3634),
        X = i(3144),
        Z = i(1016),
        tt = i(4748),
        et = i(2967),
        it = i(3867),
        nt = i(2839),
        st = i(750),
        rt = i(7759),
        ot = i(2917),
        at = i(2783),
        dt = i(7373),
        ct = i(9862),
        lt = i(4661),
        ut = i(3965),
        ht = i(567),
        vt = i(1041),
        pt = i(4683),
        mt = i(3115),
        ft = i(540),
        gt = i(317),
        bt = i(1448),
        wt = i(7986),
        _t = i(8844),
        yt = i(3759),
        St = i(7781),
        Mt = i(4080),
        Ot = i(8650),
        Et = i(859),
        At = (i(6851), i(9656)),
        Tt = i(5587),
        It = i(5034),
        Ct = i(2105),
        Dt = i(3680),
        jt = i(821),
        Vt = i(3783),
        Rt = i(6284);
      e.initAdBL = (t) => () => {
        new n.PageEventsLoggerBL(),
          new s.OmidLoggerBL(),
          new r.OmidImpressionEventInfoBL(),
          new o.ExposureCompatibilityIndicator(),
          new a.AdElementInfoExtractorBL(),
          new d.CreativeVsContainerBL(),
          new c.AdDomElementObserverBL(),
          new l.ExposureBL(),
          new u.AdSizeBL(),
          new h.AdWrapperSizeBL(),
          new v.PMXDisplayViewabilityBL(),
          new p.PMXVideoViewabilityBL(),
          new m.IabNotViewReasonsViewabilityBL(),
          new f.IabDisplayViewabilityBL(),
          new Ct.SecondaryIabDisplayViewabilityBL(),
          new g.IabVideoViewabilityBL(),
          new Dt.SecondaryIabVideoViewabilityBL(),
          new b.IabVideoQuartileViewabilityBL(),
          new w.VideoQuartileFullOnScreenBL(),
          new _.VideoFullQuartileAudibleBL(),
          new y.IabDisplayViewabilityForXSecondsBL(),
          new S.IabVideoViewabilityForXSecondsBL(),
          new M.GroupMDisplayViewabilityBL(),
          new O.GroupMVideoViewabilityBL(),
          new E.GroupMV4NonMobileDisplayViewabilityBL(),
          new A.GroupMV4MobileDisplayViewabilityBL(),
          new T.GroupMV4VideoNativeViewabilityBL(),
          new I.GroupMV4VideoReachExtensionViewabilityBL(),
          new C.BucketsDisplayViewabilityBL(),
          new D.BucketsVideoViewabilityBL(),
          new j.VideoInViewAndAudibleBL(),
          new jt.ContinuousInViewBL(),
          new Vt.ContinuousInViewNoPauseResetBL(),
          new V.EndQuartileViewabilityBL(),
          new R.RbViewabilityBL(),
          new x.ViewabilityStartPercentageBL(),
          new P.QuartileBucketsVolumeBL(),
          new k.ReportAdManagerRTS(),
          new N.MobileOrientationBL(),
          new L.FocusBucketsBL(),
          new F.MrcImpressionBL(),
          new U.DisplayGenXLogger(
            new B.DisplayGenXAdContainerInspectorFactory(
              "data-doubleverify-container"
            )
          ),
          new z.RenderingMethodLogger(),
          new At.AdLocationDiagnosticsLogger(),
          new It.GandalfTheWhiteBL(),
          ((t) => {
            new W.PerformanceMetricsBL(),
              new q.ViewableShareOfScreenBL(),
              new $.InViewShareOfScreenBL(),
              new Tt.AdSelector(t),
              new H.AdLocatedBL(),
              new G.VideoMarkImpressionAsRenderedBL(),
              new J.VideoStoppedBL(),
              new K.VideoSkippableBL(),
              new Q.VideoCompleteBL(),
              new Y.VideoLengthBL(),
              new X.VolumeBL(),
              new Z.InteractionHoverBL(),
              new tt.InteractionTouchBL(),
              new et.InteractionClickBL(),
              new it.InteractionVolumeBL(),
              new nt.InteractionPauseBL(),
              new st.InteractionResumeBL(),
              new rt.InteractionSkipBL(),
              new ot.InteractionAbandonBL(),
              new at.InteractionFocusBL(),
              new dt.InteractionAdSizeBL(),
              new ct.PageInteractionKeyPressBL(),
              new lt.PageInteractionMouseMoveBL(),
              new ut.PageInteractionScrollBL(),
              new ht.PageInteractionOrientationChangeLandscapeBL(),
              new vt.PageInteractionOrientationChangePortraitBL(),
              new pt.EngagementReportRtsBL(),
              new mt.ReportAdManagerTPS(),
              new ft.DataTransparencyBL(),
              new gt.PerformanceApiBL(),
              new bt.PerformanceLongTasksBL(),
              new wt.ScriptInjectionModeBL(),
              (0, _t.isPerformanceTimingAllowed)() &&
                new yt.PerformanceTaskTimingBL(),
              new St.ViewabilityMeasurementBL(),
              new Mt.UserPresenceBL(),
              new Rt.CdnDomainBL();
          })(t),
          new Ot.NormalizedAdSizeBL();
      };
      e.initAdDataLoggerBL = () => {
        new Et.ShareOfScreenResearchBL();
      };
    },
    5609: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.initAdDataCollector = void 0);
      const n = i(9413),
        s = i(9025),
        r = i(6306),
        o = i(6244),
        a = i(2612),
        d = i(6813),
        c = i(2515),
        l = i(4143),
        u = i(2280),
        h = i(1513),
        v = i(7357),
        p = i(7788),
        m = i(6938),
        f = i(3546),
        g = i(2635),
        b = i(1288),
        w = i(101);
      e.initAdDataCollector = () => {
        new n.FocusDataCollector(),
          new s.StrictFocusDataCollector(),
          new r.ViewabilityDataCollector(),
          new o.BoundariesViewabilityDataCollector(),
          new a.AdInteractionEventDataCollector(),
          new d.OmidInteractionDataCollector(),
          new c.VideoPlaybackDataCollector(),
          new l.HiddenAdsDataCollector(),
          new u.AutoplayDataCollector(),
          new h.PageEventsDataCollector(),
          new v.PerformanceApiDataCollector(),
          new p.PerformanceLongTasksDataCollector(),
          new m.UserPresenceDataCollector(),
          new f.InteractionUnloadDataCollector(),
          new g.PageInteractionMouseMoveDataCollector(),
          new b.PageInteractionKeyPressDataCollector(),
          new w.PageInteractionOrientationChangedDataCollector();
      };
    },
    9464: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 });
      const n = i(8844),
        s = i(6634),
        r = i(6384),
        o = i(5051),
        a = i(4112),
        d = i(1805),
        c = i(1008),
        l = i(2881),
        u = i(5609),
        h = i(1081);
      e.default = () => {
        try {
          r.default.setInitMeasurementExecutionStartTime(),
            c.tagObservabilityTelemetryExperiment.isEnabled() &&
              (0, s.collectOmidSessionEvents)(n.omidAdapter);
          const { Bt: t, Dt: e } = (0, h.zt)();
          [
            (0, o.trackPerformanceWhenExecuted)(
              { name: "iabletms" },
              (0, l.initAdBL)(e)
            ),
            (0, o.trackPerformanceWhenExecuted)(
              { name: "iadletms" },
              l.initAdDataLoggerBL
            ),
            (0, o.trackPerformanceWhenExecuted)(
              { name: "iadcetms" },
              u.initAdDataCollector
            ),
            (0, o.trackPerformanceWhenExecuted)({ name: "saleetms" }, t),
          ].forEach((t) => {
            t();
          }),
            r.default.setInitMeasurementExecutionEndTime();
        } catch (t) {
          d.L.sendError(
            a.ClientErrorType.PostMeasuredGlobalMainError,
            t,
            "initMeasurements"
          );
        }
      };
    },
    5450: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.shouldInjectIplessSideBySideScript =
          e.setupIplessSideBySideInjection =
            void 0);
      const n = i(8844),
        s = i(1360),
        r = i(7065),
        o = "s2sru";
      function a() {
        const t = n.A.getIsIplessSideBySideInjection(),
          e = n.O.isDomlessEnvironment();
        return t && !e;
      }
      (e.setupIplessSideBySideInjection = function (t) {
        var e;
        const i = n.A.getLowerCaseParams();
        if (o in i || !a()) return;
        const d =
          null === (e = n.T.getTagScriptElem()) || void 0 === e
            ? void 0
            : e.parentElement;
        if (!d)
          return void s.DiagnosticParamsReporterSingleton.report(
            s.DiagnosticParams.iplessSideBySideInjectionFailed,
            1
          );
        const c = crypto.randomUUID();
        t.additionalParams[o] = c;
        const l = (function (t, e) {
          const i = new URLSearchParams(t);
          i.append(o, e),
            i.delete("ctx"),
            i.delete("cmp"),
            i.append("ctx", "818052");
          return `https://assets.msn.com/staticsb/statics/latest/js/thirdparty/doubleverify/msftdvbm.js?${i.toString()}`;
        })(i, c);
        r.TcfClientStop.isExecutionStopped() || n.S.addScriptAsync(l, d);
      }),
        (e.shouldInjectIplessSideBySideScript = a);
    },
    3354: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.initScript = e.isDomlessEnvironment = void 0);
      const i = { id: 19, message: "TagNotFoundError" },
        n = { id: 128, message: "UnexpectedError" },
        s =
          ("object" == typeof omidVerificationProperties &&
            omidVerificationProperties.injectionId) ||
          null,
        r = () => {};
      e.isDomlessEnvironment = () =>
        "undefined" == typeof window ||
        ("object" == typeof window &&
          null !== window &&
          "function" != typeof window.addEventListener);
      function o() {
        try {
          return new Date().getTime();
        } catch (t) {
          return 0;
        }
      }
      const a = () => {
        if ((0, e.isDomlessEnvironment)()) return !1;
        try {
          const e = ((t) => {
            const e = Math.floor(1e12 * Math.random()) + "";
            return Object.assign(document.createElement("iframe"), {
              id: `iframe_${e}`,
              height: "0",
              width: "0",
              style: { display: "none" },
              src: t,
              "data-dv-frm": e,
            });
          })("about:blank");
          ((t) => {
            if (document.currentScript) {
              const e = document.currentScript.parentNode;
              e && "function" == typeof e.insertBefore
                ? e.insertBefore(t, document.currentScript)
                : document.currentScript.appendChild(t);
            } else if (
              document.body &&
              "function" == typeof document.body.insertBefore
            )
              document.body.firstChild
                ? document.body.insertBefore(t, document.body.firstChild)
                : document.body.appendChild(t);
            else {
              const [e] = Array.from(document.getElementsByTagName("head"));
              e &&
              "function" == typeof document.body.insertBefore &&
              e.firstChild
                ? e.insertBefore(t, e.firstChild)
                : document.documentElement.appendChild(t);
            }
          })(e);
          const s = !(
            (t = e) &&
            (t.contentDocument ||
              (null === (i = t.contentWindow) || void 0 === i
                ? void 0
                : i.document) ||
              (null ===
                (n =
                  null === frames || void 0 === frames
                    ? void 0
                    : frames[t.name]) || void 0 === n
                ? void 0
                : n.document))
          );
          try {
            e.remove();
          } catch (i) {}
          return s;
        } catch (t) {
          return !0;
        }
        var t, i, n;
      };
      function d(t, e, i, n, s, r, o, a) {
        const d = (function (t, e, i, n, s, r, o) {
            const a = [
              e,
              "ctx=818052&cmp=1619415&dvtagver=6.1.src",
              "&napr=",
              (null == s ? void 0 : s.message) || "error undefined",
              "&cerrt=",
              r.id,
              "&tgjsver=",
              i,
              "&jsver=",
              i,
            ];
            o && a.push("&dvp_isLostImp=1");
            let d = 0;
            return (
              t && (d |= 4),
              n && (d |= 8),
              d > 0 && a.push("&tstype=" + d),
              a.join("")
            );
          })(t, e, i, n, s, r, o),
          c = encodeURI(d);
        a && a.fire(c);
      }
      function c() {
        return (
          o() *
          (function () {
            let t = 1;
            const e = Math.floor(10 * Math.random()) + 1;
            for (let i = 0; i < e; ++i) t *= Math.random();
            return t;
          })()
        ).toString(10);
      }
      e.initScript = () => {
        var t;
        const l = o();
        let u, h;
        const v = "https://tps.doubleverify.com/",
          p = v + "visit.jpg?",
          m = c(),
          f = (0, e.isDomlessEnvironment)(),
          g = a(),
          { omidWebHopCounter: b, isOmidForWeb: w } = (() => {
            let t = -1;
            try {
              if ((0, e.isDomlessEnvironment)())
                return { isOmidForWeb: !1, omidWebHopCounter: t };
              if (
                "object" == typeof window.omidVerificationProperties &&
                "web" === window.omidVerificationProperties.injectionSource
              )
                return { isOmidForWeb: !0, omidWebHopCounter: t };
              let i = !1,
                n = window;
              for (; !i && n; )
                (i =
                  null !== n.document.querySelector("script[src*=omweb-v1]")),
                  (n = n === window.top ? null : n.parent),
                  t++;
              return { isOmidForWeb: i, omidWebHopCounter: t };
            } catch (e) {
              return { isOmidForWeb: !1, omidWebHopCounter: t };
            }
          })(),
          { isOmid3p: _, omid3pHopCounter: y } = ((t) => {
            let i = -1;
            try {
              if ((0, e.isDomlessEnvironment)() || t)
                return { isOmid3p: !1, omid3pHopCounter: i };
              let s = !1,
                r = window;
              for (; !s && r; )
                (s =
                  (n = r.omid3p) &&
                  "function" == typeof n.registerSessionObserver &&
                  "function" == typeof n.addEventListener),
                  (r = r === window.top ? null : r.parent),
                  i++;
              return { isOmid3p: s, omid3pHopCounter: i };
            } catch (t) {
              return { isOmid3p: !1, omid3pHopCounter: i };
            }
            var n;
          })(w);
        let S;
        const M = 11365;
        try {
          if (
            !f &&
            (null === document || void 0 === document
              ? void 0
              : document.currentScript)
          ) {
            const t = document.currentScript;
            (t.dvvisit = 1), (S = t);
          }
        } catch (t) {
          const e = t instanceof Error ? t : new Error(`${t}`);
          d(f, p, M, g, e, i, !1);
        }
        const O = !f && (null == S ? void 0 : S.src),
          E = O
            ? O.substr(0, O.indexOf("/dvbm.js") + 1)
            : "https://cdn.doubleverify.com/",
          A = f
            ? {
                fire(t, e, i) {
                  e || (e = r),
                    i || (i = r),
                    "object" == typeof omidNative &&
                      "function" == typeof omidNative.sendUrl &&
                      omidNative.sendUrl(t, e, i);
                },
              }
            : {
                fire(t, e, i) {
                  const n = new Image(1, 1);
                  (n.onerror = i || r), (n.onload = e || r), (n.src = t);
                },
              };
        try {
          (h = ((t) => {
            var e, i;
            let n,
              s = {},
              r = {};
            return (
              t &&
                ((n = (
                  null === (e = t.dataset) || void 0 === e
                    ? void 0
                    : e.doubleverifyParameters
                )
                  ? null === (i = t.dataset) || void 0 === i
                    ? void 0
                    : i.doubleverifyParameters
                  : (function (t) {
                      const e = t.indexOf("#"),
                        i = t.indexOf("?");
                      let n = "";
                      n =
                        e > -1 && i > -1
                          ? i < e
                            ? "?"
                            : "#"
                          : -1 == i
                          ? "#"
                          : "?";
                      const s = t.trim().split(n);
                      return 2 === s.length ? s[1] : "";
                    })(t.src)),
                n &&
                  ((s = (function (t) {
                    const e = {};
                    return (
                      t.split(/[&?#]+/).forEach(function (t) {
                        const i = t.trim().split("=");
                        2 === i.length && (e[i[0].trim()] = i[1].trim());
                      }),
                      e
                    );
                  })(n)),
                  (r = (function (t) {
                    const e = {};
                    return (
                      ["cmp", "ctx", "sid", "plc"].forEach(function (i) {
                        Object.prototype.hasOwnProperty.call(t, i) &&
                          (e["dvp_" + i] = t[i]);
                      }),
                      e
                    );
                  })(s)))),
              {
                toQueryString: function (t) {
                  let e = "";
                  for (const i in t)
                    Object.prototype.hasOwnProperty.call(t, i) &&
                      (e && (e += "&"),
                      (e = [e, i, "=", JSON.stringify(t[i])].join("")));
                  return e;
                },
                getQueryStringParams: function () {
                  return s;
                },
                getQueryStringClientParams: function () {
                  return r;
                },
              }
            );
          })(f ? null : S)),
            (u = (function () {
              let t = "";
              const e = "__ERR_MSG_PLACEHOLDR__",
                i = "__CLIENT_ERROR_TYPE_PLACEHOLDR__",
                n = {
                  ctx: 818052,
                  cmp: 1619415,
                  dvtagver: "6.1.src",
                  tgjsver: M,
                  jsver: M,
                  napr: e,
                  cerrt: i,
                };
              let s = 0;
              function r(n, s, r) {
                var o;
                s &&
                  (s =
                    null == (o = s)
                      ? void 0
                      : o.trim().replace(/(\t|\n|\r|\|)/g, "")),
                  (s = (s && encodeURIComponent(s)) || "");
                let a = t.replace(
                  new RegExp(e, "g"),
                  [n.message, s].join("__")
                );
                return (
                  (a = a.replace(new RegExp(i, "g"), n.id.toString())),
                  r && (a += "&dvp_isLostImp=1"),
                  a
                );
              }
              return (
                f && (s |= 4),
                g && (s |= 8),
                s > 0 && (n.tstype = s),
                (function () {
                  const e = [
                    h.toQueryString(n),
                    h.toQueryString(h.getQueryStringClientParams()),
                  ].join("&");
                  t = [p, e].join("");
                })(),
                {
                  report: function (t, e, i) {
                    A.fire(r(t, e, i));
                  },
                  getReportUrl: r,
                }
              );
            })());
        } catch (t) {
          const e = t instanceof Error ? t : new Error(`${t}`);
          d(f, p, M, g, e, n, !1, A);
        }
        try {
          $dv = (void 0 !== $dv && $dv) || {
            tags: {},
            tagsCounter: 0,
            registerEventCall: r,
            createEventCallUrl: () => "",
            getWorkingWindow: () => window,
            sendBeacon: r,
            resolveMacros: () => "",
            getMraid: () => ({}),
          };
          const e = c();
          f || (window.$frmId = e),
            ($dv.tagsCounter = $dv.tagsCounter ? $dv.tagsCounter + 1 : 1),
            ($dv.isDomlessEnvironment = f),
            $dv.sharedUniqueKey || ($dv.sharedUniqueKey = c()),
            ($dv.restrictedAccess = g);
          const i =
            null !== (t = null == h ? void 0 : h.getQueryStringParams()) &&
            void 0 !== t
              ? t
              : {};
          return (
            f
              ? ((dvWindow = (function (t) {
                  const e = { location: { protocol: "https:" } },
                    i = {
                      getElementById: r,
                      createElement: r,
                      body: { insertBefore: r },
                      querySelectorAll: () => [],
                    };
                  return (
                    (e.$dv = t),
                    (e.parent = e),
                    (e.top = e),
                    (e.document = i),
                    e
                  );
                })($dv)),
                (globalThis.dvWindow = dvWindow))
              : ((dvWindow = window), (window.dvWindow = dvWindow)),
            (function (t, e, i, n, r, a, d) {
              t.tagData || (t.tagData = {}),
                (e = (function (t, e) {
                  let i = 5;
                  for (; t[e] && --i; ) e = c();
                  if (t[e]) throw new Error("failed to create tagUniqueKey");
                  return e;
                })(t.tagData, e));
              const u = {};
              return (
                (u.dvtpScriptVersion = i),
                (u.dvtpScriptUrl = n),
                (u.restrictedAccess = r),
                (u.$frmId = a),
                (u.tagScriptElem = S),
                (u.tagLoadedMS = l),
                (u.isOmidForWeb = w),
                (u.isOmid3p = _),
                (u.omidWebHopCounter = b),
                (u.omid3pHopCounter = y),
                (u.tagExecTimeMs = o() - l),
                (u.flvr = "1"),
                f || (u.tagReadyState = document.readyState),
                (u.staticPrefix = E),
                (u.serverPrefix = v),
                (u.tagParams = d),
                (u.omidInjectionId = s),
                (t.tagData[e] = u),
                u
              );
            })($dv, m, M, O, g, e, i)
          );
        } catch (t) {
          const e = n,
            i = t instanceof Error ? t : new Error(`${t}`);
          u ? u.report(e, i.message, !0) : d(f, p, M, g, i, e, !0, A);
        }
      };
    },
    8620: (t, e, i) => {
      const n = i(694),
        s = i(9464),
        r = i(8261),
        o = i(7065);
      (0, n.configureCoreDiagnosticsTransport)(),
        (t.exports = async () => {
          await (0, r.default)(),
            o.TcfClientStop.isExecutionStopped() || (0, s.default)();
        });
    },
    9653: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.OmidLoggerBL = void 0);
      const n = i(8844),
        s = i(5007),
        r = i(7102),
        o = i(1906),
        a = i(214),
        d = i(4112),
        c = i(1360);
      class l extends s.BaseAdBL {
        constructor() {
          super(...arguments),
            (this.renderEventTypes = {
              IMPRESSION_EVENT: 1,
              GEOMETRY_CHANGE_AD_DIM: 2,
              GEOMETRY_CHANGE_PCT_IN_VIEW: 4,
              IMPRESSION_EVENT_PCT_IN_VIEW: 8,
            });
        }
        isSupported() {
          return n.omidAdapter.isSupported();
        }
        getEventsAndCallbacksToRegister() {
          return {
            [r.DvEvents.adCandidateApproved]: (t) => {
              this.adCandidateApproved(t);
            },
          };
        }
        init() {}
        adCandidateApproved(t) {
          const e = n.T.u();
          e.tagsCounter > 1 &&
            c.DiagnosticParamsReporterSingleton.reportOnce(
              c.DiagnosticParams.tagCounterOmidSupported,
              e.tagsCounter
            ),
            n.omidAdapter.registerSessionObserver((e) => {
              this.omidSessionEventHandler(t, e);
            }),
            o.Utilities.objectValues(d.OmidAdEventType)
              .filter(
                (t) =>
                  t !== d.OmidAdEventType.MEDIA && t !== d.OmidAdEventType.VIDEO
              )
              .forEach((e) => {
                n.omidAdapter.addEventListener(e, (e) => {
                  this.omidEventHandler(e, t);
                });
              });
        }
        omidEventHandler(t, e) {
          try {
            switch (t.type) {
              case d.OmidAdEventType.IMPRESSION:
                this.handleImpressionEvent(t, e);
                break;
              case d.OmidAdEventType.GEOMETRY_CHANGE:
                this.handleGeometricChangeEvent(t, e);
                break;
              case d.OmidAdEventType.START:
                this.handleStartEvent();
                break;
              case d.OmidAdEventType.COMPLETE:
                this.handleCompleteEvent();
            }
            this.onTriggeredOmidEvent(e, t.type);
          } catch (t) {}
        }
        handleImpressionEvent(t, e) {
          var i, n;
          let s = 0;
          if (
            ((s |= this.renderEventTypes.IMPRESSION_EVENT),
            (null == t ? void 0 : t.timestamp) &&
              (e.adCandidate.omidImpressionEventTimestamp = t.timestamp),
            null ===
              (n =
                null === (i = null == t ? void 0 : t.data) || void 0 === i
                  ? void 0
                  : i.adView) || void 0 === n
              ? void 0
              : n.percentageInView)
          ) {
            s |=
              t.data.adView.percentageInView > 0
                ? this.renderEventTypes.IMPRESSION_EVENT_PCT_IN_VIEW
                : 0;
          }
          e.adCandidate.omidRenderLogicLog |= s;
        }
        handleStartEvent() {
          c.DiagnosticParamsReporterSingleton.reportOnce(
            c.DiagnosticParams.omidTimeMsUntilStartVideo,
            o.Utilities.getTimeDiff()
          );
        }
        handleCompleteEvent() {
          c.DiagnosticParamsReporterSingleton.reportOnce(
            c.DiagnosticParams.omidTimeMsUntilEndVideo,
            o.Utilities.getTimeDiff()
          );
        }
        geometricChangeRenderTrigger(t) {
          var e, i;
          let n = 0;
          if (
            null ===
              (i =
                null === (e = null == t ? void 0 : t.data) || void 0 === e
                  ? void 0
                  : e.adView) || void 0 === i
              ? void 0
              : i.geometry
          ) {
            const e =
                t.data.adView.geometry.width > 0 &&
                t.data.adView.geometry.height > 0,
              i = t.data.adView.percentageInView > 0;
            (i || e) &&
              ((n |= e ? this.renderEventTypes.GEOMETRY_CHANGE_AD_DIM : 0),
              (n |= i ? this.renderEventTypes.GEOMETRY_CHANGE_PCT_IN_VIEW : 0));
          }
          return n;
        }
        reportOmidMaxPercentageInView(t, e) {
          var i, n;
          const s =
            null ===
              (n =
                null === (i = null == t ? void 0 : t.data) || void 0 === i
                  ? void 0
                  : i.adView) || void 0 === n
              ? void 0
              : n.percentageInView;
          if (s >= 0) {
            const t = e.adCandidate.omidMaxPercentageInView,
              i = Math.floor(t / 10),
              n = Math.floor(s / 10);
            (null == t || n > i) &&
              ((e.adCandidate.omidMaxPercentageInView = s),
              c.DiagnosticParamsReporterSingleton.report(
                c.DiagnosticParams.omidMaxPercentageInView,
                s
              ));
          }
        }
        handleGeometricChangeEvent(t, e) {
          (e.adCandidate.omidRenderLogicLog |=
            this.geometricChangeRenderTrigger(t)),
            this.extractAdViewabilityInfo(t, e),
            this.reportOmidMaxPercentageInView(t, e);
        }
        extractAdViewabilityInfo(t, e) {
          var i;
          const { containerGeometry: n, measuringElement: s } =
            (null === (i = null == t ? void 0 : t.data) || void 0 === i
              ? void 0
              : i.adView) || {};
          if (n) {
            const { height: t, width: i } = n;
            (e.adCandidate.omidContainerGeometryHeight = t),
              (e.adCandidate.omidContainerGeometryWidth = i);
          }
          c.DiagnosticParamsReporterSingleton.reportOnce(
            c.DiagnosticParams.omidMeasuringElement,
            this.mapOmidMeasuringElement(s)
          ),
            (e.adCandidate.omidCreativeVsContainerIndicator =
              this.getCreativeVsContainerIndicator(n));
        }
        getCreativeVsContainerIndicator(t) {
          return o.Utilities.isNullOrEmpty(t) ? 2 : 1;
        }
        mapOmidMeasuringElement(t) {
          return o.Utilities.isNullOrEmpty(t) ? 0 : t ? 1 : 2;
        }
        omidSessionEventHandler(t, e) {
          if (null == e ? void 0 : e.type) {
            switch (e.type) {
              case d.OmidAdEventType.SESSION_START:
                this.omidSessionStartEventHandler(t, e);
              case d.OmidAdEventType.SESSION_ERROR:
              case d.OmidAdEventType.SESSION_FINISH:
            }
            this.onTriggeredOmidEvent(t, e.type);
          }
        }
        omidSessionStartEventHandler(t, e) {
          var i, n, s, r, o, a, d, l, u;
          const h = e.data;
          if (
            (null == h ? void 0 : h.context) &&
            (c.DiagnosticParamsReporterSingleton.reportOnce(
              c.DiagnosticParams.omidJSPartnerName,
              null === (i = h.context.omidJsInfo) || void 0 === i
                ? void 0
                : i.partnerName
            ),
            c.DiagnosticParamsReporterSingleton.reportOnce(
              c.DiagnosticParams.omidJSPartnerVersion,
              null === (n = h.context.omidJsInfo) || void 0 === n
                ? void 0
                : n.partnerVersion
            ),
            c.DiagnosticParamsReporterSingleton.reportOnce(
              c.DiagnosticParams.omidPartnerName,
              null === (s = h.context.omidNativeInfo) || void 0 === s
                ? void 0
                : s.partnerName
            ),
            c.DiagnosticParamsReporterSingleton.reportOnce(
              c.DiagnosticParams.omidPartnerVersion,
              null === (r = h.context.omidNativeInfo) || void 0 === r
                ? void 0
                : r.partnerVersion
            ),
            c.DiagnosticParamsReporterSingleton.reportOnce(
              c.DiagnosticParams.omidDeviceCategory,
              h.context.deviceCategory
            ),
            (t.adCandidate.omidDeviceType =
              null === (o = h.context.deviceInfo) || void 0 === o
                ? void 0
                : o.deviceType),
            (t.adCandidate.omidJSServiceVersion =
              null === (a = h.context.omidJsInfo) || void 0 === a
                ? void 0
                : a.serviceVersion),
            (t.adCandidate.omidDeviceOSVersion =
              null === (d = h.context.deviceInfo) || void 0 === d
                ? void 0
                : d.osVersion),
            (null === (l = null == h ? void 0 : h.context.deviceInfo) ||
            void 0 === l
              ? void 0
              : l.os) &&
              (t.adCandidate.omidDeviceOS = this.getOmidDeviceOS(
                h.context.deviceInfo.os
              )),
            null === (u = null == h ? void 0 : h.context.app) || void 0 === u
              ? void 0
              : u.libraryVersion)
          ) {
            const t = this.getOmidLibraryVersion(h.context.app.libraryVersion);
            t &&
              c.DiagnosticParamsReporterSingleton.reportOnce(
                c.DiagnosticParams.omidLibraryVersion,
                t
              );
          }
          (null == h ? void 0 : h.pageUrl) &&
            (t.adCandidate.omidPageUrl = h.pageUrl);
        }
        getOmidDeviceOS(t) {
          return { iOS: 6, Android: 5 }[t] || null;
        }
        getOmidLibraryVersion(t) {
          var e;
          return null === (e = t.split("-")) || void 0 === e ? void 0 : e[0];
        }
        onTriggeredOmidEvent(t, e) {
          (t.adCandidate.omidEvents & a.OmidEvents[e]) != a.OmidEvents[e] &&
            ((t.adCandidate.omidEvents |= a.OmidEvents[e]), this.reportData(t));
        }
        reportData(t) {
          r.k.dispatchEvent(r.DvEvents.reportData, t);
        }
      }
      e.OmidLoggerBL = l;
    },
    847: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.TagExtensionRegistry = void 0);
      e.TagExtensionRegistry = () => ({
        tagExtensions: [],
        register(t, e) {
          this.tagExtensions.push([t, e]);
        },
        getTagExtensions() {
          return this.tagExtensions;
        },
      });
    },
    3691: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.Context = void 0);
      e.Context = (t, e, i, n, s, r, o, a, d) => ({
        getImpressionId: () => t,
        getTagObject() {
          return e.u().tags[this.getImpressionId()];
        },
        Wt: i,
        qt: n,
        $t: s,
        sendBeacon: r.sendBeacon.bind(r),
        addScriptAsync: r.addScriptAsync.bind(r),
        addEventListener: r.addEventListener.bind(r),
        utils: o,
        Ht: a,
        Gt: d,
      });
    },
    5203: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AdvertiserViewabilityStandard = void 0);
      const n = i(8844),
        s = i(7102),
        r = i(4112),
        o = i(3133),
        a = [1];
      e.AdvertiserViewabilityStandard = (
        t,
        e,
        i = o.ViewabilityStandardRegistrySingleton
      ) => {
        const d = {
            standardType: 1,
            regularAd: {
              adPercentage: 98,
              onFocus: !0,
              isConsecutive: !0,
              durationCap: 1e3,
            },
            largeAd: {
              adPercentage: 80,
              onFocus: !0,
              isConsecutive: !0,
              durationCap: 1e3,
            },
          },
          c = {
            standardType: 1,
            regularAd: {
              adPercentage: 98,
              onFocus: !0,
              isConsecutive: !1,
              durationCap: 15e3,
              durationPercentage: 50,
            },
            largeAd: {
              adPercentage: 80,
              onFocus: !0,
              isConsecutive: !1,
              durationCap: 15e3,
              durationPercentage: 50,
            },
          },
          l = () => {
            if (t.avs) return 1 === t.avs.avsid ? 1 : 0;
          },
          u = () => {
            if (1 === l()) return 0 == n.A.getTagType() ? d : c;
          },
          h = () => {
            const t = u();
            if (t) {
              e.Wt.sendMessage({ avstu: t.standardType });
              const { DisplayMinimalLargeAdArea: s } =
                  r.ViewabilityConstants.CustomAdvertiserViewabilityStandard,
                { VideoMinimalLargeAdArea: o } =
                  r.ViewabilityConstants.CustomAdvertiserViewabilityStandard,
                a = 0 == n.A.getTagType() ? s : o;
              i.register({
                standardId: "avs-hulu",
                settings: {
                  regularAd: t.regularAd,
                  largeAd: t.largeAd,
                  minimalLargeAdArea: a,
                },
                onMeasured: v,
                onPassed: p,
              });
            }
          },
          v = (t) => {
            e.Wt.sendMessage({ tuavsmms: t.updateTime });
          },
          p = (t) => {
            e.Wt.sendMessage({ tuavspms: t.updateTime });
          };
        return {
          getId: () => 4,
          getTrafficType: () => 1,
          isSupported: () => {
            const t = l();
            return !!t && a.includes(t);
          },
          execute() {
            e.qt.addEventListener(s.DvEvents.impressionServed, h);
          },
        };
      };
    },
    1602: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.CustomViewabilityTagExtension = void 0);
      const n = i(3619),
        s = i(3133),
        r = i(7102);
      e.CustomViewabilityTagExtension = (
        t,
        e,
        i = s.ViewabilityStandardRegistrySingleton
      ) => {
        const o = ((t, e) => {
            const i = t.cvs;
            return e.isEmpty(i)
              ? null
              : {
                  adSize: i.size,
                  adDuration: i.dur,
                  consecutiveMode: i.cons,
                  hasVolume: i.vol,
                };
          })(t, e.utils),
          a = () => {
            const t = {
              adPercentage: o.adSize,
              onFocus: !0,
              durationCap: o.adDuration,
              isConsecutive: 1 === o.consecutiveMode,
              isVolumeRequired: o.hasVolume,
            };
            i.register({
              standardId: "custom",
              settings: { regularAd: t, largeAd: t, minimalLargeAdArea: null },
              onMeasured: d,
              onPassed: c,
            });
          },
          d = (t) => {
            (t.adCandidate.timeUntilCustomViewabilityMeasuredMs = t.updateTime),
              r.k.dispatchEvent(r.DvEvents.reportData, t);
          },
          c = (t) => {
            (t.adCandidate.timeUntilCustomViewabilityPassedMs = t.updateTime),
              r.k.dispatchEvent(r.DvEvents.reportData, t);
          };
        return {
          getId: () => 2,
          getTrafficType: () => 1,
          isSupported: () =>
            null !== o &&
            ((t, e) =>
              (t.Ht.isVideoOrAudio()
                ? "boolean" == typeof e.hasVolume
                : null == e.hasVolume) &&
              e.adSize >= n.MIN_AD_SIZE_PERCENT &&
              e.adSize <= n.MAX_AD_SIZE_PERCENT &&
              e.adDuration > n.MIN_AD_DURATION_MS &&
              e.consecutiveMode >= n.MIN_CONSECUTIVE_MODE)(e, o),
          execute() {
            e.qt.addEventListener(r.DvEvents.impressionServed, a);
          },
        };
      };
    },
    3619: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.MIN_CONSECUTIVE_MODE =
          e.MIN_AD_DURATION_MS =
          e.MAX_AD_SIZE_PERCENT =
          e.MIN_AD_SIZE_PERCENT =
            void 0),
        (e.MIN_AD_SIZE_PERCENT = 50),
        (e.MAX_AD_SIZE_PERCENT = 100),
        (e.MIN_AD_DURATION_MS = 0),
        (e.MIN_CONSECUTIVE_MODE = 0);
    },
    7426: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.FraudBotNotification = void 0);
      const n = i(4112),
        s = i(5219);
      e.FraudBotNotification = (t, e) => {
        return {
          getId: () => 16,
          getTrafficType: () => 3,
          isSupported() {
            var e, i;
            return (
              ("false" ===
                (null === (e = t.common) || void 0 === e
                  ? void 0
                  : e.isBsAllow) ||
                !1 === t.isBsAllow) &&
              null !=
                (null === (i = t.fraudBotNotification) || void 0 === i
                  ? void 0
                  : i.i9j0)
            );
          },
          execute() {
            !(function (t, s) {
              const r = t.g7h8 ? t.s9t0 : t.o5p6;
              let o = "",
                a = "";
              const d = null != t.u1v2;
              d &&
                ((a += e.Wt.createEventCallUrl(s, { dvpx_gfbc: 1 }, !0)),
                (o = t.u1v2));
              const c = t.q7r8,
                l = Object.assign(Object.assign({}, e.getTagObject()), {
                  GDPR: e.Ht.getGDPR(),
                  GDPR_CONSENT: e.Ht.getGDPRConsent(),
                });
              if (d)
                try {
                  let n = decodeURIComponent(o);
                  if (
                    ((n = n.replace(
                      "[ENCODED_REDIRECT_URL]",
                      encodeURIComponent(a)
                    )),
                    (n = e.utils.resolveMacros(n, l)),
                    (n = i(n, c)),
                    t.c3d4)
                  )
                    e.sendBeacon(n, !0);
                  else if (t.e5f6) {
                    const t = document.createElement("img");
                    (t.width = 0),
                      (t.height = 0),
                      (t.style.display = "none"),
                      (t.src = n),
                      document.body.insertBefore(t, document.body.firstChild);
                  }
                } catch (t) {
                  e.Wt.sendError(
                    n.ClientErrorType.TagExtensionExecutionError,
                    t,
                    "new_template"
                  );
                }
              else
                try {
                  let n = decodeURIComponent(r);
                  if (
                    ((n = e.utils.resolveMacros(n, l)),
                    (n = n + "&dvp_impid=" + s),
                    (n = i(n, c)),
                    t.c3d4)
                  )
                    e.sendBeacon(n, !0);
                  else if (t.e5f6) {
                    const t = document.createElement("img");
                    (t.width = 0),
                      (t.height = 0),
                      (t.style.display = "none"),
                      (t.src = n),
                      document.body.insertBefore(t, document.body.firstChild);
                  }
                } catch (t) {
                  e.Wt.sendError(
                    n.ClientErrorType.TagExtensionExecutionError,
                    t,
                    "old_template"
                  );
                }
            })(
              (function (t) {
                const e = {
                  i9j0: s.identity,
                  m3n4: s.identity,
                  o5p6: s.identity,
                  s9t0: s.identity,
                  u1v2: s.identity,
                  k1l2: s.parseNumber,
                  q7r8: s.parseBoolean,
                  c3d4: s.parseBoolean,
                  e5f6: s.parseBoolean,
                  a1b2: s.parseBoolean,
                  g7h8: s.parseBoolean,
                };
                return Object.entries(e).reduce((e, [i, n]) => {
                  const r = i;
                  if ((0, s.isNoneEmptyString)(t[r])) {
                    const s = n(t[r]);
                    null !== s && (e[i] = s);
                  }
                  return e;
                }, {});
              })(t.fraudBotNotification),
              e.getImpressionId()
            );
          },
        };
        function i(t, e) {
          var i;
          return e &&
            (null === (i = null == t ? void 0 : t.startsWith) || void 0 === i
              ? void 0
              : i.call(t, "http")) &&
            !t.startsWith("https")
            ? `${t}&cbust=${(
                new Date().getTime() +
                "" +
                Math.floor(1e6 * Math.random())
              ).substring(0, 16)}`
            : t;
        }
      };
    },
    6434: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.FraudUrlResponseRedirector = void 0);
      e.FraudUrlResponseRedirector = (t, e) => ({
        getId: () => 64,
        getTrafficType: () => 3,
        isSupported() {
          var e;
          return !!(null === (e = t.fraudUrlResponseRedirector) || void 0 === e
            ? void 0
            : e.rurl);
        },
        execute() {
          !(function (t) {
            const i = t.rurl;
            e.sendBeacon(i, !0);
          })(t.fraudUrlResponseRedirector);
        },
      });
    },
    9758: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ResearchCollection = void 0);
      const n = i(5219),
        s = i(9032),
        r = i(3692),
        o = i(8844),
        a = i(6384),
        d = i(1360),
        c = {},
        l = {
          totalClicksXAccumulated: 0,
          totalClicksYAccumulated: 0,
          totalClickCounter: 0,
          outOfViewportClicks: 0,
          XClicksStdDev: 0,
          YClicksStdDev: 0,
        },
        u = [];
      function h(t) {
        let e = 0;
        for (let i = 0; i < t.length; i++) t[i] && (e += Math.pow(2, i));
        return e;
      }
      const v = Array(s.BITS_ARRAY_LENGTH).fill(!1);
      function p(t, e) {
        (v[t] = !!e), (c.bsigr = h(v).toString());
      }
      e.ResearchCollection = (t, e) => {
        return {
          getId: () => 32,
          getTrafficType: () => 3,
          isSupported() {
            var i;
            return (
              null !=
                (null === (i = t.researchCollection) || void 0 === i
                  ? void 0
                  : i.d1) && !e.Gt.isDomlessEnvironment()
            );
          },
          execute() {
            const l = (function (t) {
              const e = {
                adid: n.parseNumber,
                icat: n.parseBoolean,
                crad: n.parseBoolean,
                buni: n.identity,
                doha: n.parseNumber,
                napl: n.identity,
                dmon: n.identity,
                exti: n.parseNumber,
                tapt: n.identity,
                impi: n.identity,
                urti: n.identity,
                dety: n.identity,
                d1: n.parseNumber,
                d2: n.parseNumber,
                d3: n.identity,
                d4: n.identity,
                d5: n.identity,
                d6: n.identity,
                d7: n.identity,
                d8: n.identity,
                d9: n.identity,
                d10: n.identity,
                d11: n.identity,
                d12: n.parseBoolean,
                d13: n.identity,
                d14: n.identity,
              };
              return Object.entries(e).reduce((e, [i, s]) => {
                const r = i;
                if ((0, n.isNoneEmptyString)(t[r])) {
                  const n = s(t[r]);
                  null !== n && (e[i] = n);
                }
                return e;
              }, {});
            })(t.researchCollection);
            (function (t, e) {
              var l, u;
              try {
                c.dvp_rc_version = s.RC_VERSION;
                const b = t.Gt.getTopAccessibleWindow(),
                  _ = b.document,
                  y = navigator;
                p(0, b === b.top);
                try {
                  !(function (t, e, n) {
                    const s = [
                      {
                        name: "visibilityState",
                        instance: e,
                        proto: Document.prototype,
                        dvpf_name: "",
                        bit: 12,
                      },
                      {
                        name: "hidden",
                        instance: e,
                        proto: Document.prototype,
                        dvpf_name: "",
                        bit: 14,
                      },
                      {
                        name: "deviceMemory",
                        instance: n,
                        proto: Navigator.prototype,
                        dvpf_name: "dvpf_devmem",
                        bit: 15,
                      },
                      {
                        name: "platform",
                        instance: n,
                        proto: Navigator.prototype,
                        dvpf_name: "dvpf_navp",
                        bit: 16,
                      },
                      {
                        name: "maxTouchPoints",
                        instance: n,
                        proto: Navigator.prototype,
                        dvpf_name: "dvpf_maxtp",
                        bit: 17,
                      },
                      {
                        name: "width",
                        instance: t.screen,
                        proto: Screen.prototype,
                        dvpf_name: "dvpf_scrw",
                        bit: 24,
                      },
                      {
                        name: "height",
                        instance: t.screen,
                        proto: Screen.prototype,
                        dvpf_name: "dvpf_scrh",
                        bit: 24,
                      },
                      {
                        name: "availWidth",
                        instance: t.screen,
                        proto: Screen.prototype,
                        dvpf_name: "dvpf_scraw",
                        bit: 26,
                      },
                      {
                        name: "availHeight",
                        instance: t.screen,
                        proto: Screen.prototype,
                        dvpf_name: "dvpf_scrah",
                        bit: 26,
                      },
                      {
                        name: "webdriver",
                        instance: t,
                        proto: Window.prototype,
                        dvpf_name: "",
                        bit: 35,
                      },
                      {
                        name: "webdriver",
                        instance: n,
                        proto: Navigator.prototype,
                        dvpf_name: "",
                        bit: 36,
                      },
                      {
                        name: "webdriver",
                        instance: t,
                        proto: Document.prototype,
                        dvpf_name: "",
                        bit: 37,
                      },
                    ];
                    for (const t of s)
                      try {
                        i(t);
                      } catch (t) {}
                  })(b, _, y);
                } catch (t) {}
                try {
                  !(function (t, e) {
                    var i, n, r;
                    if (
                      !(null ===
                        (n =
                          null === (i = t.performance) || void 0 === i
                            ? void 0
                            : i.memory) || void 0 === n
                        ? void 0
                        : n.jsHeapSizeLimit)
                    )
                      return;
                    const o =
                      (2 * t.performance.memory.jsHeapSizeLimit) /
                      s.MB_IN_BYTES;
                    if (
                      !(null ===
                        (r = null == e ? void 0 : e.webkitTemporaryStorage) ||
                      void 0 === r
                        ? void 0
                        : r.queryUsageAndQuota)
                    )
                      return;
                    e.webkitTemporaryStorage.queryUsageAndQuota(
                      (t, e) => {
                        e / s.MB_IN_BYTES < o && p(20, !0);
                      },
                      (t) => {}
                    );
                  })(b, y);
                } catch (t) {}
                p(8, void 0 !== b.NavigatorUAData),
                  p(9, !!b && !!b.jtjb),
                  p(11, "ontouchstart" in window),
                  p(
                    21,
                    null === (l = null == y ? void 0 : y.userActivation) ||
                      void 0 === l
                      ? void 0
                      : l.hasBeenActive
                  ),
                  p(
                    22,
                    null === (u = null == y ? void 0 : y.userActivation) ||
                      void 0 === u
                      ? void 0
                      : u.isActive
                  ),
                  p(28, void 0 !== (null == y ? void 0 : y.bluetooth)),
                  void 0 !== _.hasFocus && p(25, _.hasFocus()),
                  (function (t) {
                    if (!o.omidAdapter.isSupported()) return;
                    o.omidAdapter.registerSessionObserver((e) => {
                      if ("sessionStart" !== e.type) return;
                      const i = e.data,
                        n =
                          null == i ? void 0 : i.supportedAttestationMechanisms;
                      (null == n ? void 0 : n.length) &&
                        ((c.dvpf_da = JSON.stringify(n)), t.Wt.sendMessage(c));
                    });
                  })(t);
                const [S, M, O] = (function (t) {
                  let e = [],
                    i = "",
                    s = 0,
                    r = 0;
                  try {
                    const o = Array.from(
                        null == t
                          ? void 0
                          : t.querySelectorAll('iframe[id*="google_ads"]')
                      ),
                      a = Array.from(
                        null == t
                          ? void 0
                          : t.querySelectorAll(
                              'iframe[id*="google_decrypt_frame"]'
                            )
                      ),
                      d = Array.from(
                        null == t
                          ? void 0
                          : t.querySelectorAll('iframe[id*="div-gpt-ad"]')
                      ),
                      c = [...o, ...a, ...d];
                    (s = c.length),
                      (e = c.map((t) =>
                        [
                          t.offsetWidth,
                          t.offsetHeight,
                          t.offsetTop,
                          t.offsetLeft,
                        ].join(",")
                      ));
                    const l = (0, n.countValues)(e);
                    r = l.size;
                    const u = Array.from(l.entries()).sort(
                      (t, e) => e[1] - t[1]
                    );
                    i = u
                      .slice(0, 9)
                      .map(([t, e]) => `${t}:${e}`)
                      .join("|");
                  } catch (t) {}
                  return [i, s, r];
                })(_);
                M > 0 && (c.dvpf_gic = M.toString()),
                  O > 0 && (c.dvpf_giuc = O.toString()),
                  S && (c.dvpf_gidim = S),
                  g(_, b),
                  (0, r.setSafeTimeout)(() => {
                    f(), t.Wt.sendMessage(c);
                  }, s.REPORT_INTERACTION_COUNTS_TINEOUT_INTERVAL),
                  _ &&
                    (_.getElementById("common_15click_overlay") ||
                      _.getElementById("common_15click_anchor")) &&
                    p(34, !0),
                  p(39, !b.chrome);
                try {
                  m(b, y);
                } catch (t) {}
                c.bsigr = h(v).toString();
                const E = a.default.currentTime();
                w(e.buni, y.userAgent);
                const A = a.default.currentTime();
                if (null != E && null != A) {
                  const t = Math.round(A - E);
                  d.DiagnosticParamsReporterSingleton.reportOnce(
                    d.DiagnosticParams.rcPerfResourcesMs,
                    t
                  );
                }
                try {
                  !(function (t) {
                    var e, i, n;
                    const s =
                      null !==
                        (n =
                          null ===
                            (i =
                              null ===
                                (e = null == t ? void 0 : t.querySelectorAll) ||
                              void 0 === e
                                ? void 0
                                : e.call(t, "[toolname]")) || void 0 === i
                            ? void 0
                            : i.length) && void 0 !== n
                        ? n
                        : 0;
                    s > 0 && (c.dvpf_wmhec = s.toString());
                  })(_);
                } catch (t) {}
                try {
                  !(function (t, e) {
                    const i = null == e ? void 0 : e.modelContext;
                    if ("function" != typeof (null == i ? void 0 : i.getTools))
                      return;
                    const n = i.getTools();
                    if (!(null == n ? void 0 : n.then)) return;
                    n.then(
                      (t) => {
                        Array.isArray(t) && (c.dvpf_wmtc = t.length.toString());
                      },
                      () => {}
                    );
                  })(0, _);
                } catch (t) {}
                t.Wt.sendMessage(c),
                  (function (t) {
                    if (!t.matchMedia) return;
                    const e = t.matchMedia("(prefers-color-scheme: dark)");
                    e.matches && p(38, !0);
                  })(b),
                  (function (t, e, i = "", s = !1) {
                    var r, o;
                    const a = e.d12;
                    if (!s && !a) return;
                    const d = e.d2,
                      c = Math.random();
                    if (!s && c > d) return;
                    const l = t.Gt.currentWindow(),
                      u = "";
                    let h =
                      null === (r = null == l ? void 0 : l.location) ||
                      void 0 === r
                        ? void 0
                        : r.hostname;
                    const m = e.buni,
                      f = parseInt(e.dety),
                      g = parseInt(e.urti),
                      b = e.d3,
                      w = e.adid,
                      _ = e.impi,
                      y = e.d13;
                    3 === f &&
                      m &&
                      m.length > 0 &&
                      (h =
                        0 != (2 & g) && (null == l ? void 0 : l.location)
                          ? l.location.hostname + "/" + m
                          : m);
                    let S = i + u;
                    0 === S.length && (S = "default");
                    const M =
                      (0, n.convertBitValuesObjToArrayString)(v) || "default";
                    function O(t, e) {
                      var i, n;
                      if (!XMLHttpRequest) return;
                      const s = new XMLHttpRequest(),
                        r = new FormData();
                      r.append(
                        "key",
                        b +
                          "/" +
                          y +
                          "/" +
                          S +
                          "/" +
                          h +
                          "/" +
                          M +
                          "_" +
                          w +
                          "_" +
                          _ +
                          "_" +
                          e +
                          ".html"
                      ),
                        r.append(
                          "file",
                          null ===
                            (n =
                              null === (i = null == t ? void 0 : t.document) ||
                              void 0 === i
                                ? void 0
                                : i.documentElement) || void 0 === n
                            ? void 0
                            : n.outerHTML
                        ),
                        s.open(
                          "POST",
                          "https://storage.googleapis.com/gp-ms-us-gcs-fraud",
                          !0
                        ),
                        s.send(r);
                    }
                    O(l, "top"), l != window && O(window, "iframe_tag");
                    l != window.parent && O(window.parent, "iframe_tag_parent");
                    l != window.parent.parent &&
                      O(window.parent.parent, "iframe_tag_parent_parent");
                    const E =
                      null === (o = null == l ? void 0 : l.document) ||
                      void 0 === o
                        ? void 0
                        : o.getElementById("adloaderframe");
                    E && O(E.contentWindow, "iframe_top_child");
                    p(3, !0);
                  })(t, e);
              } catch (e) {
                t.Wt.sendMessage({
                  dvp_rce: String.prototype.substring
                    ? String(e).substring(0, s.MAX_ERROR_STR_LENGTH)
                    : String.prototype.slice
                    ? String(e).slice(0, s.MAX_ERROR_STR_LENGTH)
                    : "String Error.",
                });
              }
            })(e, l);
          },
        };
        function i(t) {
          const e = t.name,
            i = t.instance,
            n = t.proto,
            s = t.dvpf_name,
            r = t.bit,
            o = i[e],
            a = Object.getOwnPropertyDescriptor(n, e);
          if (null == a) return;
          try {
            const t = a.get.apply(i);
            o != t && (p(r, !0), s && (c[s] = t));
          } catch (t) {}
          const d = a.get.toString();
          d &&
            (d.includes("function () {") || d.includes("ProxyObject")) &&
            p(r, !0);
        }
        function m(t, i) {
          var n;
          if (
            !(null === (n = null == i ? void 0 : i.userAgentData) ||
            void 0 === n
              ? void 0
              : n.getHighEntropyValues)
          )
            return;
          const r = i.userAgentData.getHighEntropyValues([
            "fullVersionList",
            "model",
            "platformVersion",
            "platform",
          ]);
          (null == r ? void 0 : r.then) &&
            r.then(function (t) {
              var i;
              if (!(null == t ? void 0 : t.fullVersionList)) return;
              t.model && (c.dvpf_chm = t.model.slice(0, s.MAX_CH_VALUE_LENGTH)),
                t.platform &&
                  (c.dvpf_chp = t.platform.slice(0, s.MAX_CH_VALUE_LENGTH)),
                (c.dvpf_chpv = t.platformVersion
                  .toString()
                  .slice(0, s.MAX_CH_VALUE_LENGTH));
              for (const e of t.fullVersionList)
                if (
                  (null === (i = null == e ? void 0 : e.brand) || void 0 === i
                    ? void 0
                    : i.indexOf("Chromium")) > -1
                ) {
                  const t = e.version.toString();
                  c.dvpf_chfv = t
                    .replaceAll(" ", "")
                    .slice(0, s.MAX_CH_VALUE_LENGTH);
                }
              const n = t.fullVersionList.map((t) => t.brand);
              n.length > 0 && (c.dvpf_chb = n.join(";")), e.Wt.sendMessage(c);
            });
        }
        function f() {
          (c.dvpf_cc = l.totalClickCounter.toString()),
            (c.dvpf_acxp =
              u.length > 0
                ? (l.totalClicksXAccumulated / u.length).toString()
                : "0"),
            (c.dvpf_acyp =
              u.length > 0
                ? (l.totalClicksYAccumulated / u.length).toString()
                : "0"),
            (c.dvpf_xcsd = l.XClicksStdDev.toString()),
            (c.dvpf_ycsd = l.YClicksStdDev.toString()),
            l.outOfViewportClicks > 0 &&
              (c.dvpf_ovc = l.outOfViewportClicks.toString());
        }
        function g(t, i) {
          (null == t ? void 0 : t.addEventListener) &&
            e.addEventListener(
              "click",
              function (t) {
                t.isTrusted || p(27, !0), l.totalClickCounter++;
                const n = t.target;
                n &&
                  "function" == typeof n.getBoundingClientRect &&
                  (function (t, e, i) {
                    const n = e.getBoundingClientRect();
                    if (
                      (function (t, e) {
                        const i = t.bottom <= 0,
                          n = t.top >= e.innerHeight,
                          s = t.right <= 0,
                          r = t.left >= e.innerWidth;
                        return i || n || s || r;
                      })(n, i)
                    )
                      return void l.outOfViewportClicks++;
                    if (n.width > 0 && n.height > 0) {
                      const e = (function (t, e, i, n) {
                        const s = Math.max(i.left, 0),
                          r = Math.max(i.top, 0),
                          o = Math.min(i.right, n.innerWidth),
                          a = Math.min(i.bottom, n.innerHeight),
                          d = o - s,
                          c = a - r;
                        if (d <= 0 || c <= 0) return null;
                        const l = t - s,
                          u = e - r,
                          h = Math.max(0, Math.min(1, l / d)),
                          v = Math.max(0, Math.min(1, u / c));
                        return { x: h, y: v };
                      })(t.clientX, t.clientY, n, i);
                      if (null === e) return;
                      (l.totalClicksXAccumulated += e.x),
                        (l.totalClicksYAccumulated += e.y),
                        u.push(e);
                      const s = u.map((t) => t.x),
                        r = u.map((t) => t.y);
                      (l.XClicksStdDev = b(s)), (l.YClicksStdDev = b(r));
                    }
                  })(t, n, i),
                  f(),
                  e.Wt.sendMessage(c);
              },
              t
            );
        }
        function b(t) {
          if (0 === t.length) return 0;
          const e = t.reduce((t, e) => t + e, 0) / t.length,
            i = t.reduce((t, i) => t + Math.pow(i - e, 2), 0) / t.length;
          return Math.sqrt(i);
        }
        function w(t, i) {
          const n = new Set([
            "script",
            "img",
            "iframe",
            "beacon",
            "xmlhttprequest",
            "fetch",
          ]);
          function s(t) {
            try {
              return !!t.document;
            } catch (t) {
              return !1;
            }
          }
          function r(t, e) {
            var i, s;
            return (
              (null ===
                (s =
                  null === (i = t.performance) || void 0 === i
                    ? void 0
                    : i.getEntriesByType) || void 0 === s
                ? void 0
                : s.call(i, "resource")) || []
            )
              .filter((t) => n.has(t.initiatorType))
              .map((t) => ({ type: t.initiatorType, url: t.name, source: e }));
          }
          const o =
              /[?&](appPackageId|_package_name|supplyBundleId|appBundleId|packageExclude|ntv_bundleid|package_name|packagename|packageName|p_app\.bundle|cad\[app_bundle\]|app_bundle|bundle-id|pkg_name|appbundle|appBundle|omdappid|packageId|bundleId|_package|ns_ap_bi|pkg_id|a_pkg|omida|pkgName|msid|pkgn|pkg)=([^&#]+)/g,
            a =
              /[?&](device_user_agent|DVPX_PP_AUCTION_UA|user_agent|userAgent|User-Agent|cad\[agent\]|device_ua|deviceUA|deviceUa|useragent|userUA|af_ua|navUa|kv27|oua|ua)=([^&#]+)/g;
          function d(t) {
            try {
              return new URL(t).hostname;
            } catch (t) {
              return "";
            }
          }
          function l(t) {
            return /iPhone|iPad|iPod/i.test(t)
              ? "ios"
              : /FireTV|AFT[A-Z]\w*/i.test(t)
              ? "firetv"
              : /Android/i.test(t)
              ? "android"
              : /Windows Phone/i.test(t)
              ? "windows_phone"
              : /Windows NT/i.test(t)
              ? "windows"
              : /Macintosh|Mac OS X/i.test(t)
              ? "mac"
              : /Apple\s?TV/i.test(t)
              ? "appletv"
              : /Roku/i.test(t)
              ? "roku"
              : /VIZIO|SmartCast/i.test(t)
              ? "vizio"
              : /Web0S|webOS/i.test(t)
              ? "webos"
              : /Tizen/i.test(t)
              ? "tizen"
              : /CrKey/i.test(t)
              ? "chromecast"
              : /Xbox/i.test(t)
              ? "xbox"
              : /PlayStation/i.test(t)
              ? "playstation"
              : /CrOS/i.test(t)
              ? "chromeos"
              : /BlackBerry|BB10|PlayBook/i.test(t)
              ? "blackberry"
              : /Linux/i.test(t)
              ? "linux"
              : null;
          }
          function u(t) {
            if (0 === t.length) return "";
            const e = t[Math.floor(Math.random() * t.length)];
            return e.domain + "|" + e.param + "|" + e.value;
          }
          try {
            const n = e.Gt.currentWindow(),
              h = (function (t) {
                const e = r(t, "self");
                let i = t,
                  n = 1;
                for (; i !== i.parent && n <= 10; )
                  (i = i.parent), s(i) && e.push(...r(i, `parent+${n}`)), n++;
                return e;
              })(n),
              v = (function t(e, i = "top", n = 0) {
                var o;
                if (n > 10) return [];
                if (!s(e)) return [];
                const a = r(e, i),
                  d =
                    (null === (o = e.frames) || void 0 === o
                      ? void 0
                      : o.length) || 0;
                for (let s = 0; s < d; s++)
                  a.push(...t(e.frames[s], `${i}>frame[${s}]`, n + 1));
                return a;
              })(n),
              p = [...h, ...v],
              m = (function (t) {
                const e = [];
                let i;
                for (const n of t)
                  for (o.lastIndex = 0; null !== (i = o.exec(n.url)); ) {
                    let t;
                    try {
                      t = decodeURIComponent(i[2]);
                    } catch (e) {
                      t = i[2];
                    }
                    e.push({ domain: d(n.url), param: i[1], value: t });
                  }
                return e;
              })(p),
              f = t
                ? m.filter(
                    (e) =>
                      !(function (t, e) {
                        const i = t.toLowerCase(),
                          n = e.toLowerCase();
                        if (n.includes(i)) return !0;
                        const s = i.split(".");
                        for (let t = s.length - 1; t >= 2; t--)
                          if (n.includes(s.slice(0, t).join("."))) return !0;
                        return !1;
                      })(t, e.value)
                  )
                : [],
              g = t ? [] : m,
              b = i ? l(i) : null,
              w = (function (t) {
                const e = [];
                let i;
                for (const n of t)
                  for (a.lastIndex = 0; null !== (i = a.exec(n.url)); ) {
                    let t;
                    try {
                      t = decodeURIComponent(i[2].replace(/\+/g, " "));
                    } catch (e) {
                      t = i[2];
                    }
                    const s = l(t);
                    s &&
                      e.push({
                        domain: d(n.url),
                        param: i[1],
                        value: t,
                        family: s,
                      });
                  }
                return e;
              })(p),
              _ = b ? w.filter((t) => t.family !== b) : [],
              y = u(f),
              S = u(g),
              M = u(_);
            y && (c.dvpf_bimm = y),
              S && (c.dvpf_biue = S),
              M && (c.dvpf_uamm = M);
          } catch (t) {
            throw new Error(
              `collectPerformenceResourcesIndicators failed: ${t}`
            );
          }
        }
      };
    },
    9032: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.REPORT_INTERACTION_COUNTS_TINEOUT_INTERVAL =
          e.MAX_CH_VALUE_LENGTH =
          e.MAX_ERROR_STR_LENGTH =
          e.MB_IN_BYTES =
          e.BITS_ARRAY_LENGTH =
          e.RC_VERSION =
            void 0),
        (e.RC_VERSION = "0839"),
        (e.BITS_ARRAY_LENGTH = 64),
        (e.MB_IN_BYTES = 1048576),
        (e.MAX_ERROR_STR_LENGTH = 150),
        (e.MAX_CH_VALUE_LENGTH = 32),
        (e.REPORT_INTERACTION_COUNTS_TINEOUT_INTERVAL = 5e3);
    },
    628: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ResearchIPv6FromCdn = void 0);
      e.ResearchIPv6FromCdn = (t, e) => ({
        getId: () => 128,
        getTrafficType: () => 3,
        isSupported() {
          var e;
          return !!(null === (e = t.researchIPv6FromCdn) || void 0 === e
            ? void 0
            : e.rurl);
        },
        execute() {
          !(function (t) {
            const i = t.rurl;
            e.sendBeacon(i, !0);
          })(t.researchIPv6FromCdn);
        },
      });
    },
    5219: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.countValues =
          e.convertBitValuesObjToArrayString =
          e.isNoneEmptyString =
          e.identity =
          e.parseBoolean =
          e.parseNumber =
            void 0),
        (e.parseNumber = function (t) {
          const e = parseFloat(t),
            i = parseInt(t, 10),
            n = e == i ? i : e;
          return isNaN(n) ? null : n;
        }),
        (e.parseBoolean = function (t) {
          switch (t.toLowerCase()) {
            case "true":
              return !0;
            case "false":
              return !1;
            default:
              return null;
          }
        }),
        (e.identity = function (t) {
          return t;
        }),
        (e.isNoneEmptyString = function (t) {
          return "string" == typeof t && !!t;
        }),
        (e.convertBitValuesObjToArrayString = function (t) {
          if (!t) return "";
          const e = [];
          for (let i = 0; i < t.length; i++) t[i] && e.push(i);
          return e.join("_");
        }),
        (e.countValues = function (t) {
          const e = new Map();
          if (!t) return e;
          for (const i of t) e.set(i, (e.get(i) || 0) + 1);
          return e;
        });
    },
    1293: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.TagExtensionsHandler = void 0);
      const n = i(847),
        s = i(5994),
        r = i(8116),
        o = i(5203),
        a = i(1602),
        d = i(7426),
        c = i(6434),
        l = i(9758),
        u = i(628);
      e.TagExtensionsHandler = (t, e, i) => ({
        execute() {
          const h = (0, n.TagExtensionRegistry)();
          h.register(s.RealTimeNotifications, "rtn"),
            h.register(o.AdvertiserViewabilityStandard, "ee"),
            h.register(a.CustomViewabilityTagExtension, "ee"),
            h.register(d.FraudBotNotification, "fd"),
            h.register(l.ResearchCollection, "fd"),
            h.register(u.ResearchIPv6FromCdn, "fd"),
            h.register(c.FraudUrlResponseRedirector, "fd");
          (0, r.TagExtensionOrchestrator)(h, t, e, i).execute();
        },
      });
    },
    5994: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.RealTimeNotifications =
          e.fireEvent =
          e.resolveNotification =
            void 0);
      const n = i(4112),
        s = i(7102),
        r = i(8334),
        o = i(1360);
      function a(
        { tagObject: t, Ht: e, selectedAdCandidateRef: i, utils: n },
        s
      ) {
        var r, o, a, d, c, l;
        const { current: u } = i,
          h = decodeURIComponent(s.url),
          v = Object.assign(Object.assign({}, t), {
            GDPR: e.getGDPR(),
            GDPR_CONSENT: e.getGDPRConsent(),
            "50PCT_IN_VIEW_TIME_MS":
              null !==
                (o =
                  null ===
                    (r =
                      null == u
                        ? void 0
                        : u.getAtLeast50PercentInViewDurationInMs) ||
                  void 0 === r
                    ? void 0
                    : r.call(u)) && void 0 !== o
                ? o
                : "",
            "100PCT_IN_VIEW_TIME_MS":
              null !==
                (d =
                  null ===
                    (a =
                      null == u ? void 0 : u.get100PercentInViewDurationInMs) ||
                  void 0 === a
                    ? void 0
                    : a.call(u)) && void 0 !== d
                ? d
                : "",
            AD_HEIGHT:
              null !== (c = null == u ? void 0 : u.adHeight) && void 0 !== c
                ? c
                : "",
            AD_WIDTH:
              null !== (l = null == u ? void 0 : u.adWidth) && void 0 !== l
                ? l
                : "",
            LOAD_TIMESTAMP_UNIX_S: Math.round(n.getScriptLoadedMS() / 1e3),
          });
        return n.resolveMacros(h, v);
      }
      function d(t, e, i, s, r) {
        const d = a(
          {
            tagObject: t.getTagObject(),
            Ht: t.Ht,
            selectedAdCandidateRef: i,
            utils: t.utils,
          },
          r
        );
        if ("image" !== r.actionType && "javascript" !== r.actionType)
          return void t.Wt.sendError(
            n.ClientErrorType.TagExtensionExecutionError,
            new Error("Rtn error: invalid action name"),
            "",
            { te_id: e().toString() }
          );
        const c = o.DiagnosticParams[s];
        if (
          (c && o.DiagnosticParamsReporterSingleton.reportDiagnosticParam(c, 1),
          "image" === r.actionType)
        )
          t.sendBeacon(d, !0);
        else if ("javascript" === r.actionType) {
          const e = t.getTagObject().tagElement.parentElement || document.body;
          t.addScriptAsync(d, e);
        }
      }
      (e.resolveNotification = a), (e.fireEvent = d);
      e.RealTimeNotifications = (t, e) => {
        const i = { current: null };
        function o(t, e) {
          const i = new Set(t);
          return (
            e.toLowerCase().startsWith("groupm") && i.add("2wD8").add("T4sJ"),
            Array.from(i)
          );
        }
        return (
          e.qt.addEventListener(
            s.DvEvents.adSelected,
            ({ adCandidate: t }) => (i.current = t)
          ),
          {
            getId: () => 1,
            getTrafficType: () => 3,
            isSupported: () =>
              Array.isArray(t.rtnEvents) &&
              t.rtnEvents.length > 0 &&
              "object" == typeof t.rtnEvents[0],
            execute() {
              var a, c, l, u, h;
              if (t.rtnEvents)
                for (const v of t.rtnEvents) {
                  const { eventName: p } = v;
                  if (((h = p), Object.values(r.RTSEventNames).includes(h)))
                    for (const n of v.actions) {
                      const r = o(
                        null !== (a = n.conditions) && void 0 !== a ? a : [],
                        p
                      );
                      if (
                        ((l = r),
                        (u = null !== (c = t.cdc) && void 0 !== c ? c : {}),
                        !(
                          (l.includes("7rQp") &&
                            !(null == u ? void 0 : u.f7kR) &&
                            !l.includes("L8bC")) ||
                          ((l.includes("f6Zx") || l.includes("G3vR")) &&
                            (null == u ? void 0 : u.f7kR) &&
                            0 === (null == u ? void 0 : u.z3pQ)) ||
                          (l.includes("L8bC") &&
                            (null == u ? void 0 : u.f7kR) &&
                            !l.includes("7rQp")) ||
                          (l.includes("6hNp") &&
                            !(null == u ? void 0 : u["8xJ1"])) ||
                          (l.includes("d9Xc") &&
                            !(null == u ? void 0 : u["5tG9"])) ||
                          ((l.includes("T4sJ") || l.includes("2wD8")) &&
                            !(null == u ? void 0 : u.f7kR)) ||
                          (l.includes("V5k2") &&
                            !(null == u ? void 0 : u.p2Qz)) ||
                          (!(
                            l.includes("f6Zx") ||
                            l.includes("G3vR") ||
                            l.includes("q1Lz")
                          ) &&
                            (null == u ? void 0 : u.z3pQ) &&
                            (null == u ? void 0 : u.z3pQ) > 0)
                        ))
                      ) {
                        if ("IABNotMeasuredImpression" === p) {
                          const t = e.qt.addEventListener(
                            s.DvEvents.unloadData,
                            () => {
                              var s;
                              e.qt.removeEventListener(t),
                                (null === (s = i.current) || void 0 === s
                                  ? void 0
                                  : s.timeMsUntilAdMeasured) > 0 ||
                                  d(
                                    e,
                                    this.getId.bind(this),
                                    i,
                                    "IABNotMeasuredImpression",
                                    n
                                  );
                            }
                          );
                        }
                        if ("SessionEnd" === p) {
                          const t = e.qt.addEventListener(
                            s.DvEvents.unloadData,
                            () => {
                              e.qt.removeEventListener(t),
                                d(e, this.getId.bind(this), i, "SessionEnd", n);
                            }
                          );
                        }
                        e.$t.subscribe(
                          p,
                          e.getImpressionId(),
                          `RTN_${p}`,
                          d.bind(this, e, this.getId.bind(this), i, p, n)
                        ),
                          e.Wt.sendMessage({ rtn_exec: p });
                      }
                    }
                  else
                    e.Wt.sendError(
                      n.ClientErrorType.TagExtensionExecutionError,
                      new Error(`Rtn error: ${p} invalid event name`),
                      "",
                      { te_id: this.getId().toString() }
                    );
                }
            },
          }
        );
      };
    },
    8116: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.TagExtensionOrchestrator = void 0);
      const n = i(1805),
        s = i(4112),
        r = i(3691),
        o = i(8844),
        a = i(7102),
        d = i(1906),
        c = i(1360);
      e.TagExtensionOrchestrator = (t, e, i, l = 3) => ({
        execute() {
          c.TagExtensionsExecutionParamsSingleton.reportTagExtensionsExecutionParams(
            c.TagExtensionsExecutionParams.tagExtensionOrchestratorStarted,
            1
          );
          const u = t.getTagExtensions(),
            h = (0, r.Context)(
              e,
              o.T,
              n.L,
              a.k,
              a.Ct,
              o.S,
              d.Utilities,
              o.A,
              o.O
            ),
            {
              tagExtensionsInitialized: v,
              tagExtensionsSupported: p,
              tagExtensionsActivated: m,
            } = u.reduce(
              (
                {
                  tagExtensionsInitialized: t,
                  tagExtensionsSupported: e,
                  tagExtensionsActivated: r,
                },
                [o, a]
              ) => {
                var d;
                const c = o(
                  null !== (d = null == i ? void 0 : i[a]) && void 0 !== d
                    ? d
                    : {},
                  h
                );
                t |= c.getId();
                try {
                  (c.getTrafficType() & l) > 0 &&
                    c.isSupported() &&
                    ((e |= c.getId()), c.execute(), (r |= c.getId()));
                } catch (t) {
                  n.L.sendError(
                    s.ClientErrorType.TagExtensionExecutionError,
                    t,
                    "",
                    { te_id: c.getId().toString() }
                  );
                }
                return {
                  tagExtensionsInitialized: t,
                  tagExtensionsSupported: e,
                  tagExtensionsActivated: r,
                };
              },
              {
                tagExtensionsInitialized: 0,
                tagExtensionsSupported: 0,
                tagExtensionsActivated: 0,
              }
            );
          c.TagExtensionsExecutionParamsSingleton.reportTagExtensionsExecutionParams(
            c.TagExtensionsExecutionParams.tagExtensionsInitialized,
            v
          ),
            c.TagExtensionsExecutionParamsSingleton.reportTagExtensionsExecutionParams(
              c.TagExtensionsExecutionParams.tagExtensionsSupported,
              p
            ),
            c.TagExtensionsExecutionParamsSingleton.reportTagExtensionsExecutionParams(
              c.TagExtensionsExecutionParams.tagExtensionsExecuted,
              m
            );
        },
      });
    },
    1816: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.GlobalVariablesInjection = void 0);
      const n = i(7149),
        s = i(8844),
        r = i(1906),
        o = i(1805),
        a = i(5944),
        d = i(4112),
        c = i(1293),
        l = i(7982),
        u = i(7065);
      e.GlobalVariablesInjection = class {
        isSupported() {
          return !0;
        }
        executePhase(t, e) {
          const i = s.T.u(),
            r = new n.DvBackwardCompatibilityClass();
          i.dvObjType || (i.dvObjType = r.dvObjType),
            i.resolveMacros || (i.resolveMacros = r.resolveMacros),
            i.registerEventCall || (i.registerEventCall = r.registerEventCall),
            i.createEventCallUrl ||
              (i.createEventCallUrl = r.createEventCallUrl),
            i.getWorkingWindow || (i.getWorkingWindow = r.getWorkingWindow),
            i.getMraid || (i.getMraid = r.getMraid),
            i.messages || (i.messages = r.messages),
            i.domUtilities || (i.domUtilities = r.domUtilities),
            i.pubSub || (i.pubSub = r.pubSub),
            i.CommonData || (i.CommonData = r.CommonData),
            i.tags || (i.tags = r.tags),
            (i.sendBeacon = s.S.sendBeacon.bind(s.S)),
            "undefined" != typeof window ||
              e ||
              s.O.setGlobalVariable("window", dvWindow);
          const o = s.O.workingWindow(),
            d = s.O.currentWindow();
          (o._dv_win = o), (d._dv_win = o);
          const c = a.EventIdGeneratorAdaptor;
          o[t.callbackName] = (e, i, n, s, r = {}) => {
            this.generateCallback(t, e, i, n, s, c, r);
          };
        }
        toString() {
          return "GlobalInjection";
        }
        extractHostname(t) {
          const e = t.indexOf("//") + 2,
            i = t.indexOf("/", e);
          return t.substring(e, i);
        }
        generateCallback(t, e, i, n, a, h, v) {
          try {
            if (
              (u.TcfClientStop.assignVisitImpressionId(n),
              !s.O.isDomlessEnvironment())
            ) {
              const t = s.O.currentDocument();
              s.T.setVisitReadyState(t.readyState);
            }
            (e.tags[n] = {}),
              (e.tags[n].type = "monitoring"),
              (e.tags[n].beginVisitCallbackTS = r.Utilities.getCurrentTime()),
              (e.tags[n].eventIdGenerator = h),
              (e.tags[n].set = (t) => {
                r.Utilities.extend(t, e.tags[n]);
              }),
              (e.tags[n].getTimeDiff = () =>
                r.Utilities.getCurrentTime() -
                s.T.u().tags[n].beginVisitCallbackTS),
              (e.tags[n].tagElement = s.A.getDVScript()),
              (e.tags[n].ServerPublicDns = this.extractHostname(
                s.A.getServerPrefix()
              )),
              s.A.setServerPrefix(`https://${a}/`),
              (e.tags[n].ServerPublicDns = a),
              (0, l.detectImpressionIdMisalignment)(n),
              s.T.setImpressionId(n),
              s.O.setGlobalVariable("$uid", n);
            {
              const t = s.T.getFrameId(s.O.currentWindow());
              s.O.setGlobalVariable("$frmId", t);
            }
            const p = s.A.getCaseSensitiveParams();
            e.tags[n].set(p);
            const m = r.Utilities.mapData(t, d.TPSDataMapping);
            if (
              (r.Utilities.extend(t.additionalParams, m),
              e.tags[n].set(m),
              (e.tags[n].uid = n),
              (e.tags[n].dv_protocol = "https:"),
              u.TcfClientStop.isExecutionStopped())
            )
              return;
            const f = s.O.monitorScriptsPerformance(i, { visit: ["duration"] });
            f.visit_duration && o.L.sendMessage({ vdur: f.visit_duration }),
              s.ServerContext.setData(v);
            (0, c.TagExtensionsHandler)(n, v, 1).execute();
          } catch (t) {
            o.L.sendError(d.ClientErrorType.TagCommunicationError, t);
          }
        }
      };
    },
    9155: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.MeasureGdpr = void 0);
      const n = i(8844),
        s = i(1805);
      e.MeasureGdpr = class {
        constructor() {
          (this.cmpCallbacks = {}),
            (this.getConsentDataCallback = (t, e) => {
              try {
                const t = n.O.currentWindow(),
                  i = n.O.workingDocument();
                t.performance.mark("dv_gdpr_end"),
                  t.performance.measure(
                    "dv_gdpr",
                    "dv_gdpr_start",
                    "dv_gdpr_end"
                  );
                const r = t.performance.getEntriesByName("dv_gdpr");
                if (r.length > 0) {
                  const [t] = r;
                  isNaN(t.duration) ||
                    s.L.sendMessage(
                      {
                        dvp_gdDur: Math.round(t.duration),
                        dvp_gdDome: "complete" == i.readyState ? "1" : "0",
                        dvp_gdDoms: this.gdprIsDocumentCompleted,
                        dvp_gdSucc: e ? "1" : "0",
                      },
                      !0
                    );
                }
              } catch (t) {
                this.sendGdprError("9");
              }
            }),
            (this.handleCmpReturn = (t) => {
              try {
                const e =
                  "string" == typeof t.data ? JSON.parse(t.data) : t.data;
                if (e.__cmpReturn) {
                  const t = e.__cmpReturn,
                    i = this.cmpCallbacks[t.callId];
                  i
                    ? (i(t.returnValue, t.success),
                      delete this.cmpCallbacks[t.callId])
                    : this.sendGdprError("6");
                }
              } catch (t) {}
            });
        }
        isSupported() {
          return !n.O.isDomlessEnvironment() && n.O.isPerformanceAPISupported();
        }
        executePhase(t) {
          (this.gdprIsDocumentCompleted =
            "complete" == n.O.workingDocument().readyState ? "1" : "0"),
            this.gdprPerformanceMark();
          const e = this.locateCmpApi();
          if (e && "1" != e) this.sendGdprError(e);
          else if (this.cmpFrame)
            if (this.cmpIsFunctionCall)
              this.invokeCmpCommandByFunction(
                "getConsentData",
                null,
                this.getConsentDataCallback
              );
            else {
              if (!n.O.isPostMessageSupported())
                return void this.sendGdprError("2");
              this.addEventListenerForCmpResponses(),
                this.invokeCmpCommandByPostMessage(
                  "getConsentData",
                  null,
                  this.getConsentDataCallback
                );
            }
        }
        toString() {
          return "MesasureGdpr";
        }
        locateCmpApi() {
          let t,
            e = n.O.currentWindow();
          for (; !this.cmpFrame; ) {
            try {
              (this.cmpIsFunctionCall = "function" == typeof e.__cmp),
                (this.cmpIsFunctionCall || e.frames.__cmpLocator) &&
                  ((this.cmpFrame = e), (t = "1"));
            } catch (e) {
              t = "3";
            }
            try {
              if (n.O.isTop(e)) break;
              e = n.O.getWindowParent(e, !0);
            } catch (e) {
              t = "8";
              break;
            }
          }
          return t;
        }
        addEventListenerForCmpResponses() {
          n.S.addEventListener(
            "message",
            this.handleCmpReturn,
            n.O.currentWindow()
          );
        }
        invokeCmpCommandByFunction(t, e, i) {
          try {
            this.cmpFrame.__cmp(t, e, i);
          } catch (t) {
            this.sendGdprError("4");
          }
        }
        invokeCmpCommandByPostMessage(t, e, i) {
          const n = Math.random().toString(),
            s = { __cmpCall: { command: t, parameter: e, callId: n } };
          this.cmpCallbacks[n] = i;
          try {
            this.cmpFrame.postMessage(s, "*");
          } catch (t) {
            this.sendGdprError("5");
          }
        }
        gdprPerformanceMark() {
          n.O.currentWindow().performance.mark("dv_gdpr_start");
        }
        sendGdprError(t) {
          s.L.sendMessage({ dvp_gdpr_Error: t }, !0);
        }
      };
    },
    670: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.MeasureGdprV2 = void 0);
      const n = i(8844),
        s = i(1805);
      e.MeasureGdprV2 = class {
        constructor() {
          (this.DV_VENDOR_ID = 126),
            (this.tcfCallbacks = {}),
            (this.getConsentDataCallback = (t, e) => {
              try {
                const i = n.O.currentWindow(),
                  r = n.O.workingDocument();
                i.performance.mark("dv_gdpr_v2_end"),
                  i.performance.measure(
                    "dv_gdpr_v2",
                    "dv_gdpr_v2_start",
                    "dv_gdpr_v2_end"
                  );
                const [o] = i.performance.getEntriesByName("dv_gdpr_v2");
                (null == o ? void 0 : o.duration) &&
                  s.L.sendMessage(
                    {
                      dvp_gdv2_Func: this.tcfapiIsFunctionCall ? "1" : "0",
                      dvp_gdv2_Applies:
                        void 0 !== (null == t ? void 0 : t.gdprApplies)
                          ? t.gdprApplies
                            ? "1"
                            : "0"
                          : "-1",
                      dvp_gdv2_Succ: e ? "1" : "0",
                      dvp_gdv2_Dur: Math.round(o.duration),
                      dvp_gdv2_Doms: this.gdprIsDocumentCompletedStart,
                      dvp_gdv2_Dome: "complete" == r.readyState ? "1" : "0",
                    },
                    !0
                  );
              } catch (t) {
                this.sendGdprV2Error("9");
              }
            }),
            (this.handleTcfMessage = (t) => {
              try {
                const e = (
                  "string" == typeof t.data ? JSON.parse(t.data) : t.data
                ).__tcfapiReturn;
                if (e) {
                  const t = this.tcfCallbacks[e.callId];
                  t
                    ? (t(e.returnValue, e.success),
                      delete this.tcfCallbacks[e.callId])
                    : this.sendGdprV2Error("6");
                }
              } catch (t) {}
            });
        }
        isSupported() {
          return !n.O.isDomlessEnvironment() && n.O.isPerformanceAPISupported();
        }
        executePhase(t) {
          (this.gdprIsDocumentCompletedStart =
            "complete" == n.O.workingDocument().readyState ? "1" : "0"),
            this.gdprV2PerformanceMark();
          const e = this.locateTcfFrame();
          if (e && "1" != e) this.sendGdprV2Error(e);
          else if (this.tcfFrame)
            if (this.tcfapiIsFunctionCall)
              this.invokeTcfCommandByFunction(
                "addEventListener",
                [this.DV_VENDOR_ID],
                this.getConsentDataCallback
              );
            else {
              if (!n.O.isPostMessageSupported())
                return void this.sendGdprV2Error("2");
              this.addEventListenerForTcfResponses(),
                this.invokeTcfCommandByPostMessage(
                  "addEventListener",
                  [this.DV_VENDOR_ID],
                  this.getConsentDataCallback
                );
            }
        }
        toString() {
          return "MesasureGdprV2";
        }
        locateTcfFrame() {
          let t,
            e = n.O.currentWindow();
          for (; !this.tcfFrame; ) {
            try {
              (this.tcfapiIsFunctionCall = "function" == typeof e.__tcfapi),
                (this.tcfapiIsFunctionCall || e.frames.__tcfapiLocator) &&
                  ((this.tcfFrame = e), (t = "1"));
            } catch (e) {
              t = "3";
            }
            try {
              if (n.O.isTop(e)) break;
              e = n.O.getWindowParent(e, !0);
            } catch (e) {
              t = "8";
              break;
            }
          }
          return t;
        }
        addEventListenerForTcfResponses() {
          n.S.addEventListener(
            "message",
            this.handleTcfMessage,
            n.O.currentWindow()
          );
        }
        invokeTcfCommandByFunction(t, e, i) {
          try {
            this.tcfFrame.__tcfapi(t, 2, i, e);
          } catch (t) {
            this.sendGdprV2Error("4");
          }
        }
        invokeTcfCommandByPostMessage(t, e, i) {
          const n = Math.random().toString(),
            s = {
              __tcfapiCall: { command: t, parameter: e, version: 2, callId: n },
            };
          this.tcfCallbacks[n] = i;
          try {
            this.tcfFrame.postMessage(s, "*");
          } catch (t) {
            this.sendGdprV2Error("5");
          }
        }
        gdprV2PerformanceMark() {
          n.O.currentWindow().performance.mark("dv_gdpr_v2_start");
        }
        sendGdprV2Error(t) {
          s.L.sendMessage({ dvp_gdv2_Error: t }, !0);
        }
      };
    },
    8392: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ScriptsInjection = void 0);
      const n = i(1906),
        s = i(4112),
        r = i(8844),
        o = i(1805),
        a = i(9198),
        d = i(4444),
        c = i(1360);
      e.ScriptsInjection = class {
        constructor() {
          this.onLoad = () => {
            n.Utilities.setLoadVisitTime(),
              r.T.getImpressionId(null) ||
                o.L.sendError(s.ClientErrorType.InvalidVisitResponseError);
          };
        }
        isSupported() {
          return !0;
        }
        addPerformanceMetrics(t) {
          const e = r.T.getTagLoadedMS(),
            i = n.Utilities.getScriptLoadedMS(),
            s = n.Utilities.getCurrentTime();
          (t.timeToMeasureMs = i - e),
            t.timeToFirstReportMs || (t.timeToFirstReportMs = s - i);
        }
        addScriptDynamicFlags(t) {
          const e = a.ScriptDynamicFlags.getInstance().getFlags();
          e && e > 0 && (t.scriptDynamicFlags = e);
        }
        getReleventServerPrefix(t) {
          var e;
          const i =
            null === (e = r.A.getParamValue("vidreg")) || void 0 === e
              ? void 0
              : e.toLowerCase();
          return i && { ue: !0, uw: !0, eu: !0, as: !0 }[i]
            ? `https://tpsc-video-${i}.doubleverify.com/`
            : r.A.getServerPrefix();
        }
        buildTpsQueryString(t) {
          let e = n.Utilities.getQueryString(
            t,
            t.additionalParams,
            t.dvpParamsFlags,
            s.TPSDataMapping
          );
          const i = ["gdpr", "gdpr_consent"].filter((e) => !t[e]);
          if (i.length) {
            e = `${i.map((t) => `${t}=`).join("&")}&${e}`;
          }
          return e;
        }
        executePhase(t, e) {
          if (t.abortVisitRequest) return;
          const i = Math.floor(Date.now() * Math.random());
          t.additionalParams || (t.additionalParams = {}),
            (t.additionalParams.dvp_tuid = i),
            (t.flavor = "1");
          const s = this.getReleventServerPrefix(t);
          (t.errorURL = s + r.A.getErrorPath()),
            this.addScriptDynamicFlags(t),
            this.addPerformanceMetrics(t),
            this.addVisitJsonDiagnostics(t, e);
          const o = this.buildTpsQueryString(t),
            a = `${s}${r.A.getInitJsPath()}?${o}`,
            c = `${s}${r.A.getInitJsonPath()}?${o}`,
            l = r.O.currentDocument(),
            u = r.O.getCurrentScript() || l.body,
            { cmp: h, ctx: v, sid: p, plc: m } = t,
            f = {
              tuid: i,
              cmp: h,
              ctx: v,
              sid: p,
              plc: m,
              vurll: a.length,
              protocol: r.T.getProtocol(),
            },
            g = this.errorFunction.bind(this, f);
          let b = "TPSCall";
          r.T.isRestrictedAccess() && (b += `_${r.T.getTagUniqueKey()}`),
            r.T.setVisitInjectedMS(n.Utilities.getCurrentTime()),
            0 !== e
              ? (d.VisitJsonFlow.execute(c, t)
                  .then(this.onLoad.bind(this))
                  .catch((t) => {
                    this.handleVisitJsonError(t, c, e);
                  }),
                (0, r.logDvSignal)(c))
              : (r.S.addScriptAsync(a, u, b, g, this.onLoad.bind(this)),
                (0, r.logDvSignal)(a));
        }
        addVisitJsonDiagnostics(t, e) {
          const i = (e, i) =>
            (t.additionalParams[(0, c.getDiagnosticQueryParamName)(e)] = i);
          i(c.DiagnosticParams.visitJsonExperimentGroup, String(e)),
            0 !== e &&
              i(
                c.DiagnosticParams.isOmidInjectionIdExtractable,
                r.T.getOmidInjectionId() ? "1" : "0"
              );
        }
        handleVisitJsonError(t, e, i) {
          const a = {},
            d = (t, e) => (a[(0, c.getDiagnosticQueryParamName)(t)] = e);
          d(c.DiagnosticParams.visitJsonExperimentGroup, String(i)),
            d(
              c.DiagnosticParams.isOmidInjectionIdExtractable,
              r.T.getOmidInjectionId() ? "1" : "0"
            );
          const l = n.Utilities.isExceedingMaxUrlLength(e.length)
            ? s.ClientErrorType.VisitRequestError
            : s.ClientErrorType.VisitResponseError;
          o.L.sendError(l, t, "", a);
        }
        toString() {
          return "ScriptsInjection";
        }
        errorFunction(t) {
          const { vurll: e, protocol: i } = t,
            r = n.Utilities.isExceedingMaxUrlLength(e)
              ? s.ClientErrorType.VisitRequestError
              : s.ClientErrorType.VisitResponseError;
          o.L.sendError(r, null, "", { dvp_vurll: e, dvp_protocol: i });
        }
      };
    },
    8360: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.SupportedIntegrationsCollector = void 0);
      const n = i(6128);
      e.SupportedIntegrationsCollector = class {
        isSupported() {
          return !0;
        }
        collectData(t) {
          const e = (0, n.getSupportedIntegrationsBitwise)();
          (t.supportedIntegrations = e),
            0 != e && (t.additionalParams.dvp_mib = e);
        }
        toString() {
          return "SupportedIntegrations";
        }
      };
    },
    3782: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BrowserCollector = void 0);
      const n = i(8844);
      e.BrowserCollector = class {
        isSupported() {
          return !n.O.isDomlessEnvironment();
        }
        collectData(t) {
          const e = n.BrowserDetector.getBrowserId();
          null != e && (t.browserDetectionSource = 1),
            (t.browserId = e),
            (t.browserVersion = n.BrowserDetector.getBrowserVersion()),
            (t.browserIdUserAgent = n.BrowserDetector.getBrowserIdUserAgent());
        }
        toString() {
          return "Browser";
        }
      };
    },
    8960: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.Cm360DedupDiagnosticCollector = void 0);
      const n = i(1360),
        s = i(8844),
        r = i(1906),
        o = i(1008),
        a = "__dv_cm360_diag",
        d = "__dv_cm360_nonce",
        c = "dv_cm360_dedup_diag";
      e.Cm360DedupDiagnosticCollector = class {
        isSupported() {
          return o.cm360DedupDiagnosticExperiment.isEnabled();
        }
        collectData(t) {
          const e = this.identifyCm360CampaignAutomator(t);
          this.detectCm360Environment(t);
          const i =
            t.additionalParams[
              (0, n.getDiagnosticQueryParamName)(
                n.DiagnosticParams.cm360Detected
              )
            ];
          (e || 0 !== i) &&
            (this.extractCm360DcAdk(t),
            this.collectRefireCounter(t),
            this.collectSessionToken(t));
        }
        identifyCm360CampaignAutomator(t) {
          const e = "1" === s.A.getParamValue("adsrv"),
            i = "crtwrp" === s.A.getParamValue("cawf");
          return e && i;
        }
        detectCm360Environment(t) {
          var e;
          let i = 0;
          try {
            const t = s.O.workingDocument();
            if (t) {
              const n = t.querySelectorAll("ins, div, iframe, script, span");
              for (const t of n) {
                for (const e of t.attributes)
                  if (e.value.includes("DfaVisibilityIdentifier")) {
                    i |= 1;
                    break;
                  }
                if (1 & i) break;
              }
              const s = t.querySelectorAll("script[src]");
              for (const t of s) {
                const e = t.src;
                if (null == e ? void 0 : e.includes("dcmads")) {
                  i |= 2;
                  break;
                }
              }
              const r = t.querySelectorAll("ins");
              for (const t of r)
                if (
                  null === (e = t.className) || void 0 === e
                    ? void 0
                    : e.includes("dcmads")
                ) {
                  i |= 4;
                  break;
                }
            }
          } catch (t) {}
          try {
            const t = s.O.getTopAccessibleWindow();
            (t._dcmads || t.dcmads) && (i |= 8);
          } catch (t) {}
          t.additionalParams[
            (0, n.getDiagnosticQueryParamName)(n.DiagnosticParams.cm360Detected)
          ] = i;
        }
        extractCm360DcAdk(t) {
          let e = 0,
            i = null;
          try {
            const t = s.O.getTopAccessibleWindow(),
              n = t._dcmads || t.dcmads;
            n && ((e |= 2), (i = n.dc_adk || null));
          } catch (t) {
            e |= 8;
          }
          try {
            const t = s.O.workingDocument();
            if (t) {
              const n = t.querySelectorAll("ins[data-dcm-placement]");
              if (n.length > 0) {
                e |= 4;
                const t = n[0].getAttribute("data-dcm-placement");
                t && !i && (i = t);
              }
            }
          } catch (t) {
            e |= 8;
          }
          (t.additionalParams[
            (0, n.getDiagnosticQueryParamName)(
              n.DiagnosticParams.cm360AccessResult
            )
          ] = e),
            i &&
              (t.additionalParams[
                (0, n.getDiagnosticQueryParamName)(
                  n.DiagnosticParams.cm360DcAdk
                )
              ] = encodeURIComponent(i));
        }
        getPlacementKey(t) {
          const e = t.ctx || "",
            i = t.cmp || "",
            n = t.plc || "";
          return e || i || n ? `${e}|${i}|${n}` : "unknown";
        }
        collectRefireCounter(t) {
          const e = this.getPlacementKey(t);
          let i = 0;
          try {
            const { store: t, method: n } = this.getOrCreateStore();
            t &&
              ((i = t.refireCounters[e] || 0),
              (t.refireCounters[e] = i + 1),
              this.persistStore(t, n));
          } catch (t) {}
          t.additionalParams[
            (0, n.getDiagnosticQueryParamName)(
              n.DiagnosticParams.dvRefireCounter
            )
          ] = i;
        }
        collectSessionToken(t) {
          const e = this.getPlacementKey(t);
          let i,
            s = 0;
          try {
            const t = this.getOrCreateStore(),
              n = t.store;
            (s = t.method),
              n
                ? (n.sessionTokens[e] ||
                    ((n.sessionTokens[e] = r.Utilities.generateUUID()),
                    this.persistStore(n, s)),
                  (i = n.sessionTokens[e]))
                : (i = r.Utilities.generateUUID());
          } catch (t) {
            i = r.Utilities.generateUUID();
          }
          (t.additionalParams[
            (0, n.getDiagnosticQueryParamName)(
              n.DiagnosticParams.dvSessionToken
            )
          ] = i),
            (t.additionalParams[
              (0, n.getDiagnosticQueryParamName)(
                n.DiagnosticParams.dvDedupStorageMethod
              )
            ] = s);
        }
        getPageLoadNonce() {
          try {
            const t = s.O.getTopAccessibleWindow();
            return t[d] || (t[d] = r.Utilities.generateUUID()), t[d];
          } catch (t) {
            return null;
          }
        }
        getOrCreateStore() {
          const t = this.getPageLoadNonce();
          if (t) {
            const e = this.readFromSessionStorage();
            if (e) {
              if (e.pageLoadNonce === t) return { store: e, method: 2 };
              this.clearSessionStorage();
            }
            if (this.isSessionStorageAvailable()) {
              const e = this.createFreshStore(t);
              return this.writeToSessionStorage(e), { store: e, method: 2 };
            }
          }
          try {
            const e = s.O.getTopAccessibleWindow();
            return (
              e[a] || (e[a] = this.createFreshStore(t || "")),
              { store: e[a], method: 1 }
            );
          } catch (t) {}
          return { store: null, method: 0 };
        }
        createFreshStore(t) {
          return { sessionTokens: {}, refireCounters: {}, pageLoadNonce: t };
        }
        persistStore(t, e) {
          2 === e && this.writeToSessionStorage(t);
        }
        readFromSessionStorage() {
          try {
            const t = sessionStorage.getItem(c);
            return t ? JSON.parse(t) : null;
          } catch (t) {
            return null;
          }
        }
        writeToSessionStorage(t) {
          try {
            sessionStorage.setItem(c, JSON.stringify(t));
          } catch (t) {}
        }
        clearSessionStorage() {
          try {
            sessionStorage.removeItem(c);
          } catch (t) {}
        }
        isSessionStorageAvailable() {
          try {
            const t = "__dv_ss_test";
            return (
              sessionStorage.setItem(t, "1"), sessionStorage.removeItem(t), !0
            );
          } catch (t) {
            return !1;
          }
        }
        toString() {
          return "Cm360DedupDiagnostic";
        }
      };
    },
    5963: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.DomScriptCollector = void 0);
      const n = i(8844);
      e.DomScriptCollector = class {
        isSupported() {
          return !n.O.isDomlessEnvironment();
        }
        collectData(t) {
          this.isScriptInHeadPosition() && (t.isScriptInHeadLocation = 1);
        }
        toString() {
          return "DomScript";
        }
        isScriptInHeadPosition() {
          var t;
          const e = n.A.getDVScript();
          return (
            "HEAD" ==
            (null === (t = null == e ? void 0 : e.parentElement) || void 0 === t
              ? void 0
              : t.tagName)
          );
        }
      };
    },
    2181: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.DvParamsCollector = void 0);
      const n = i(8844),
        s = i(1906);
      e.DvParamsCollector = class {
        constructor() {
          (this.tpsParams = [
            "ctx",
            "cmp",
            "ipos",
            "sid",
            "plc",
            "adid",
            "crt",
            "btreg",
            "btadsrv",
            "adsrv",
            "advid",
            "num",
            "pid",
            "crtname",
            "unit",
            "chnl",
            "uid",
            "scusrid",
            "tagtype",
            "sr",
            "dt",
            "dup",
            "app",
            "dvvidver",
            "turl",
            "icall",
            "dv_callback",
            "useragent",
            "xff",
            "timecheck",
            "seltag",
            "sadv",
            "ord",
            "litm",
            "scrt",
            "invs",
            "splc",
            "adu",
            "spos",
            "c1",
            "c2",
            "c3",
            "c4",
            "c5",
            "c6",
            "c7",
            "c8",
            "c9",
            "c10",
            "c11",
            "c12",
            "c13",
            "c14",
            "c15",
            "native",
            "gmnpo",
            "isdvvid",
            "msrapi",
            "bsimpid",
            "prr",
            "iframe",
            "gdpr",
            "gdpr_consent",
            "tvcp",
            "vssd",
            "apifw",
            "vstvr",
            "paonlytag",
            "auprice",
            "ppid",
            "audeal",
            "auevent",
            "auadv",
            "aucmp",
            "aucrtv",
            "auorder",
            "ausite",
            "auplc",
            "auxch",
            "audvc",
            "aulitem",
            "auadid",
            "pltfrm",
            "aufilter1",
            "aufilter2",
            "autt",
            "auip",
            "aubndl",
            "jsver",
          ]),
            (this.aspParams = [
              "auctionid",
              "vermemid",
              "source",
              "buymemid",
              "anadvid",
              "ioid",
              "cpgid",
              "cpid",
              "sellerid",
              "pubid",
              "advcode",
              "iocode",
              "cpgcode",
              "cpcode",
              "pubcode",
              "prcpaid",
              "auip",
              "auua",
            ]);
        }
        isSupported() {
          return !0;
        }
        collectData(t) {
          const e = n.T.getDvtpScriptVersion();
          (t.dvtpScriptVersion = e),
            (t.collectDataStartTime = s.Utilities.getCurrentTime());
          const i = n.A.getCaseSensitiveParams();
          if (s.Utilities.isEmpty(i)) return;
          const r = n.A.getLowerCaseParams();
          this.tpsParams.forEach((e) => {
            !s.Utilities.isNullOrEmpty(r[e]) &&
              s.Utilities.isNullOrEmpty(t[e]) &&
              (t[e] = r[e]);
          }),
            this.aspParams.forEach((e) => {
              s.Utilities.isNullOrEmpty(i[e]) ||
                ((t[e] = i[e]), (t.additionalParams["dvp_" + e] = i[e]));
            });
          const o = [...this.tpsParams, ...this.aspParams];
          Object.keys(i)
            .filter((t) => !s.Utilities.isNullOrEmpty(i[t]) && !o.includes(t))
            .forEach((e) => {
              let n = i[e];
              s.Utilities.startsWith(e, "dvpx_", !0) &&
                (n = encodeURIComponent(n)),
                (t.additionalParams[e] = n);
            });
        }
        toString() {
          return "DvParams";
        }
      };
    },
    4692: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.InjectionDetectionCodeCollector = void 0);
      const n = i(8844);
      e.InjectionDetectionCodeCollector = class {
        constructor() {
          this.results = [];
        }
        isSupported() {
          return !n.O.isDomlessEnvironment();
        }
        collectData(t) {
          try {
            this.ancestorsInjectionDetection(),
              (t.idcResults = this.results.join(","));
          } catch (e) {
            (t.idcResults = "-999"), (t.idcError = e.message || "unknown");
          }
          t.idcVersion = 28;
        }
        toString() {
          return "InjectionDetectionCodeCollector";
        }
        ancestorsInjectionDetection() {
          let t = n.O.workingWindow();
          for (
            let e = 0;
            e < 10 &&
            (this.detectInjections(t), !n.O.isTop(t)) &&
            ((t = n.O.getWindowParent(t)), t);
            e++
          );
        }
        detectInjections(t) {
          var e, i, n, s;
          this.addInjector(t, null != t.AZSD, 9),
            this.addInjector(
              t,
              t.location.hostname != t.encodeURIComponent(t.location.hostname),
              10
            ),
            this.addInjector(t, null != t.cascadeWindowInfo, 11),
            this.addInjector(t, null != t._rvz, 32),
            this.addInjector(t, null != t.FO_DOMAIN, 34),
            this.addInjector(t, null != t.va_subid, 36),
            this.addInjector(
              t,
              null === (e = t._GPL) || void 0 === e ? void 0 : e.baseCDN,
              40
            ),
            this.addInjector(
              t,
              this.evaluateProperty(t, "__twb__") &&
                this.evaluateProperty(t, "__twb_cb_"),
              43
            ),
            this.addInjector(
              t,
              null != t.landingUrl &&
                null != t.seList &&
                null != t.parkingPPCTitleElements &&
                null != t.allocation,
              45
            ),
            this.addInjector(
              t,
              this.evaluateProperty(t, "_rvz", function (t) {
                return null != t.publisher_subid;
              }),
              46
            ),
            this.addInjector(
              t,
              null != t.cacildsFunc && null != t.n_storesFromFs,
              47
            ),
            this.addInjector(
              t,
              null === (i = t._pcg) || void 0 === i ? void 0 : i.GN_UniqueId,
              54
            ),
            this.addInjector(
              t,
              this.evaluateProperty(t, "__ad_rns_") &&
                this.evaluateProperty(t, "_$_"),
              64
            ),
            this.addInjector(t, null != t.APP_LABEL_NAME_FULL_UC, 71),
            this.addInjector(t, null != t._priam_adblock, 81),
            this.addInjector(
              t,
              t.supp_ads_host && t.supp_ads_host_overridden,
              82
            ),
            this.addInjector(
              t,
              null === (n = t.uti_xdmsg_manager) || void 0 === n
                ? void 0
                : n.cb,
              87
            ),
            this.addInjector(t, t.LogBundleData && t.addIframe, 91),
            this.addInjector(t, t.xAdsXMLHelperId || t.xYKAffSubIdTag, 95),
            this.addInjector(
              t,
              null === (s = t.__pmetag) || void 0 === s ? void 0 : s.uid,
              98
            ),
            this.addInjector(
              t,
              t.CustomWLAdServer &&
                /(n\d{1,4}adserv)|(1ads|cccpmo|epommarket|epmads|adshost1)/.test(
                  t.supp_ads_host_overridden
                ),
              100
            );
        }
        evaluateProperty(t, e, i) {
          for (const n in t) if (n.includes(e) && (!i || i(t[n]))) return !0;
          return !1;
        }
        addInjector(t, e, i) {
          e &&
            !this.results.includes(i) &&
            this.results.push((n.O.isTop(t) ? -1 : 1) * i);
        }
      };
    },
    3906: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.AttributeCollector = void 0);
      const n = i(8844);
      e.AttributeCollector = class {
        isSupported() {
          return !n.O.isDomlessEnvironment();
        }
        collectData(t) {
          var e, i, s, r;
          try {
            if (128 != (128 & n.O.getScenarioType())) {
              const o = n.O.getTopAccessibleWindow(),
                a = n.O.workingDocument(o);
              t.widgetCount =
                (o.FB ? 1 : 0) +
                (o.twttr ? 2 : 0) +
                (o.outbrain ? 4 : 0) +
                (o._taboola ? 8 : 0);
              try {
                a.cookie && (t.cookieLength = a.cookie.length);
              } catch (t) {}
              (null ===
                (i =
                  null === (e = o.performance) || void 0 === e
                    ? void 0
                    : e.timing) || void 0 === i
                ? void 0
                : i.domainLookupStart) > 0 &&
                (null ===
                  (r =
                    null === (s = o.performance) || void 0 === s
                      ? void 0
                      : s.timing) || void 0 === r
                  ? void 0
                  : r.domainLookupEnd) > 0 &&
                (t.domainLookupTime =
                  o.performance.timing.domainLookupEnd -
                  o.performance.timing.domainLookupStart),
                a.querySelectorAll &&
                  (t.documentElementCount = a.querySelectorAll("*").length);
            }
            const o = n.O.workingWindow();
            (t.iframeCount = o.top.length),
              o.history && (t.historyLength = o.history.length);
          } catch (t) {}
        }
        toString() {
          return "AttributeCollector";
        }
      };
    },
    6725: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BrowserFeaturesCollector = void 0);
      const n = i(8844);
      e.BrowserFeaturesCollector = class {
        constructor() {
          this.featureBits = 0;
        }
        enableBit(t) {
          t < 32 && (this.featureBits = (this.featureBits | (1 << t)) >>> 0);
        }
        isCDP() {
          let t = !1;
          try {
            const e = new Proxy({}, { ownKeys: () => ((t = !0), []) }),
              i = Object.create(e);
            console.groupEnd(i);
          } catch (t) {}
          return t;
        }
        isSupported() {
          return !n.O.isDomlessEnvironment();
        }
        collectData(t) {
          t.browserFeatures = this.getBrowserFeatures();
        }
        toString() {
          return "BrowserFeaturesCollector";
        }
        getBrowserFeatures() {
          try {
            return (
              void 0 !== n.O.workingWindow().NavigatorUAData &&
                this.enableBit(5),
              void 0 !== n.O.workingWindow().chrome && this.enableBit(6),
              this.isCDP() && this.enableBit(7),
              this.featureBits
            );
          } catch (t) {
            return 0;
          }
        }
      };
    },
    8082: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BrowserSignatureCollector = void 0);
      const n = i(8844);
      e.BrowserSignatureCollector = class {
        constructor() {
          (this.familyBits = 0),
            (this.sigBits = 0),
            (this.Jt = [
              120, 104, 119, 110, 117, 121, 96, 120, 119, 104, 47, 66, 39, 117,
              113, 102, 126, 106, 119, 52, 117, 113, 102, 126, 106, 119, 51,
              111, 120, 68, 117, 66, 39, 98,
            ]),
            (this.Kt = [
              120, 104, 119, 110, 117, 121, 96, 110, 105, 66, 39, 102, 115, 110,
              123, 110, 106, 124, 79, 88, 39, 98,
            ]),
            (this.Qt = [
              51, 100, 100, 104, 106, 105, 102, 121, 116, 100, 119, 116, 116,
              121, 100, 104, 116, 115, 121, 102, 110, 115, 106, 119,
            ]);
        }
        isSupported() {
          return !n.O.isDomlessEnvironment();
        }
        deobStr(t) {
          let e = "";
          for (const i of t) e += String.fromCharCode(i - 5);
          return e;
        }
        collectData(t) {
          const e = this.getBrowserSignature();
          e &&
            ((t.browserSignatureFamilyBits = e.familyBits),
            (t.browserSignatureBits = e.sigBits));
        }
        toString() {
          return "BrowserSignatureCollector";
        }
        enableBit(t, e, i) {
          i &&
            ((this.familyBits |= Math.pow(2, t)),
            (this.sigBits |= Math.pow(2, e)));
        }
        Yt(t, e, i, s) {
          if (!t || !e) return;
          const r = n.O.workingDocument(t).querySelectorAll(e);
          r && r.length > 0 && this.enableBit(i, s, !0);
        }
        Xt() {
          let t = 0,
            e = n.O.currentWindow();
          for (
            ;
            t < 16 &&
            (this.Yt(e, this.deobStr(this.Qt), 16, 3),
            this.Yt(e, this.deobStr(this.Jt), 14, 1),
            this.Yt(e, this.deobStr(this.Kt), 15, 2),
            !n.O.isTop(e));

          ) {
            (e = n.O.getWindowParent(e, !0)), t++;
          }
        }
        getBrowserSignature() {
          try {
            const t = n.O.getTopAccessibleWindow();
            this.enableBit(17, 4, !!t.jtjb);
          } catch (t) {}
          try {
            this.Xt();
          } catch (t) {}
          return this.familyBits > 0
            ? { familyBits: this.familyBits, sigBits: this.sigBits }
            : null;
        }
      };
    },
    7797: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.HardwareFeaturesCollector = void 0);
      const n = i(8844);
      e.HardwareFeaturesCollector = class {
        isSupported() {
          return !0;
        }
        collectData(t) {
          (t.numberOfCores = n.O.getNumberOfCores()),
            this.getTouchSupport() && (t.hasTouchPad = 1),
            (t.navigatorPlatform = this.getPlatform());
        }
        toString() {
          return "HardwareDataCollector";
        }
        getTouchSupport() {
          var t, e;
          return (
            5 ===
            (null ===
              (e =
                null ===
                  (t =
                    null === n.O || void 0 === n.O
                      ? void 0
                      : n.O.workingWindow()) || void 0 === t
                  ? void 0
                  : t.navigator) || void 0 === e
              ? void 0
              : e.maxTouchPoints)
          );
        }
        getPlatform() {
          var t, e;
          return null ===
            (e =
              null ===
                (t =
                  null === n.O || void 0 === n.O
                    ? void 0
                    : n.O.workingWindow()) || void 0 === t
                ? void 0
                : t.navigator) || void 0 === e
            ? void 0
            : e.platform;
        }
      };
    },
    8175: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.HijackedDeviceSignatureCollector = void 0);
      const n = i(8844);
      e.HijackedDeviceSignatureCollector = class {
        isSupported() {
          return !n.O.isDomlessEnvironment();
        }
        collectData(t) {
          const e = this.getSignature();
          e && (t.hijackedDeviceSignatureBits = e);
        }
        toString() {
          return "HijackedDeviceSignatureCollector";
        }
        getSignature() {
          let t = 0;
          try {
            const e = function (e, i) {
                i && (t += Math.pow(2, e));
              },
              i = n.O.getTopAccessibleWindow(),
              s = n.O.workingDocument(i);
            if (
              (e(
                6,
                n.O.isTop(i) &&
                  "" == s.title &&
                  null == s.querySelector("meta[charset]") &&
                  null !=
                    s.querySelector('div[style*="background-image: url("]') &&
                  (null != s.querySelector('script[src*="j.pubcdn.net"]') ||
                    null != s.querySelector('span[class="ad-close"]'))
              ),
              t > 0)
            )
              return t;
          } catch (t) {}
          return null;
        }
      };
    },
    2903: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.IOSMapleCollector = void 0);
      const n = i(8844);
      e.IOSMapleCollector = class {
        constructor() {
          this.maxIterations = 10;
        }
        isSupported() {
          return !n.O.isDomlessEnvironment();
        }
        collectData(t) {
          const e = n.O.isIOS(),
            i = n.O.objectLookup(
              n.O.workingWindow(),
              "maple",
              this.maxIterations
            );
          e && t.dvpParamsFlags.push(0), i && t.dvpParamsFlags.push(1);
        }
        toString() {
          return "IOSMaple";
        }
      };
    },
    7970: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.MraidCollector = void 0);
      const n = i(5473);
      e.MraidCollector = class {
        isSupported() {
          return n.MraidWrapper.isSupported();
        }
        collectData(t) {
          t.isMraid = 1;
        }
        toString() {
          return "MraidCollector";
        }
      };
    },
    9911: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.OmidContextCollector = void 0);
      const n = i(8844),
        s = i(9198);
      e.OmidContextCollector = class {
        isSupported(t) {
          return n.omidAdapter.isSupported();
        }
        collectData(t) {
          var e;
          const i = n.omidAdapter.getOmidContext();
          i &&
            ((t.omidEnvironment = i.environment),
            (t.omidAdSessionType = i.adSessionType),
            (t.omidAppId =
              null === (e = i.app) || void 0 === e ? void 0 : e.appId),
            this.extractOmidContentUrl(t));
          const r = n.omidAdapter.getSessionData();
          if (r) {
            const e = (r.data || {}).context || {};
            e.accessMode &&
              (t.omidAccessMode = n.omidAdapter.getOmidAccessModeNumber(
                e.accessMode
              )),
              e.underEvaluation && s.ScriptDynamicFlags.getInstance().turnOn(1);
          }
        }
        extractOmidContentUrl(t) {
          var e;
          try {
            const i =
              null === (e = n.omidAdapter.getSessionData()) || void 0 === e
                ? void 0
                : e.data;
            if (i) {
              const e = 500,
                { contentUrl: n } = i;
              if (n) {
                const i = n.substring(0, e);
                t.omidContentUrl = encodeURIComponent(i);
              }
            }
          } catch (t) {}
        }
        toString() {
          return "OmidContext";
        }
      };
    },
    7194: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ParamUrlExtractionMethodCollector = void 0);
      const n = i(8844),
        s = i(1906),
        r = i(1360);
      e.ParamUrlExtractionMethodCollector = class {
        isSupported() {
          return !0;
        }
        collectData(t) {
          const e = n.A.getParamUrlExtractionMethod();
          e && (t.additionalParams.dvp_rcp = e),
            this.appendUrlHashTagLogger(t),
            this.appendScriptElementExtractionMethod(t),
            this.appendIsCurrentScriptNotSupported(t),
            this.appendIsOmid(t),
            this.appendHasTagUniqueKey(t),
            this.appendTagCounter(t),
            this.appendSharedUniqueKey(t),
            this.appendTagUniqueKey(t);
        }
        appendUrlHashTagLogger(t) {
          let e = 0;
          const i = n.A.getDVScriptUrl();
          if (!s.Utilities.isNullOrEmpty(i)) {
            const n = /[?]([^&#?]*)=([^&#?]*)/gi;
            /[#]([^&#?]*)=([^&#?]*)/gi.test(i) && (e |= 1),
              n.test(i) && (e |= 2),
              e && (t.additionalParams.dvp_htec = e);
          }
        }
        appendTagUniqueKey(t) {
          const e = n.T.getTagUniqueKey();
          if (e) {
            t.additionalParams.dvp_tukv = e;
            const i = (0, r.getDiagnosticQueryParamName)(
              r.DiagnosticParams.tagUniqueKey
            );
            t.additionalParams[i] = e;
          }
        }
        appendSharedUniqueKey(t) {
          const e = n.T.getSharedUniqueKey();
          if (e) {
            t.additionalParams.dvp_sukv = e;
            const i = (0, r.getDiagnosticQueryParamName)(
              r.DiagnosticParams.sharedTagUniqueKey
            );
            t.additionalParams[i] = e;
          }
        }
        appendScriptElementExtractionMethod(t) {
          const e = n.A.getScriptElementExtractionMethod();
          e && (t.additionalParams.dvp_seem = e);
        }
        appendIsCurrentScriptNotSupported(t) {
          !n.O.getCurrentScript() && (t.additionalParams.dvp_nscs = 1);
        }
        appendIsOmid(t) {
          var e;
          try {
            let i = 0;
            const r = n.O.workingWindow();
            n.omidAdapter.isSupported() && (i = 1),
              n.T.isOmidForWeb() && (i |= 8),
              n.T.isOmid3p() && (i |= 16);
            try {
              if (!n.T.isRestrictedAccess() && !n.O.isDomlessEnvironment()) {
                const t = n.O.getWindowParent(r),
                  o = n.O.getWindowParent(t);
                (void 0 === r.omidVerificationProperties &&
                  void 0 === t.omidVerificationProperties &&
                  void 0 === r.omid &&
                  void 0 === t.omid &&
                  void 0 === o.omid) ||
                  (i |= 2);
                const a =
                  null !== (e = r.omidVerificationProperties) && void 0 !== e
                    ? e
                    : t.omidVerificationProperties;
                s.Utilities.isNullOrEmpty(a) ||
                  ("web" === (null == a ? void 0 : a.injectionSource) &&
                    (i |= 4));
              }
            } catch (t) {}
            i > 0 && (t.additionalParams.dvp_iomd = i);
          } catch (t) {}
        }
        appendHasTagUniqueKey(t) {
          n.T.getTagUniqueKey() && (t.additionalParams.dvp_tuk = 1);
        }
        appendTagCounter(t) {
          const e = n.T.getTagCounter();
          if (e > 1) {
            const i = (0, r.getDiagnosticQueryParamName)(
              r.DiagnosticParams.tagCounter
            );
            t.additionalParams[i] = e;
          }
        }
        toString() {
          return "ParamUrlExtractionMethod";
        }
      };
    },
    1225: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.PreRenderCollector = void 0);
      const n = i(1003);
      e.PreRenderCollector = class {
        isSupported() {
          return !0;
        }
        collectData(t) {
          n.RenderLogicFactory.getRenderLogic().isAdRendered() ||
            (t.isPreRender = 1);
        }
        toString() {
          return "PreRender";
        }
      };
    },
    3073: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ReferrerCollector = void 0);
      const n = i(8844),
        s = i(1906),
        r = i(4112);
      e.ReferrerCollector = class {
        isSupported(t) {
          const e = (n.O.getUserAgent() || "").toLowerCase();
          return (
            !n.O.isDomlessEnvironment() &&
            (e.includes("webkit") || e.includes("chrome"))
          );
        }
        collectData(t) {
          const e = encodeURIComponent(n.O.workingWindow().location.toString());
          s.Utilities.isQueryLengthBelowBrowserLimit(
            t,
            t.additionalParams,
            t.dvpParamsFlags,
            r.TPSDataMapping,
            e
          ) && (t.referrerUrl = e);
        }
        toString() {
          return "Referrer";
        }
      };
    },
    5349: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ScriptsPerformanceCollector = void 0);
      const n = i(8844);
      e.ScriptsPerformanceCollector = class {
        isSupported() {
          return !n.O.isDomlessEnvironment();
        }
        collectData(t) {
          const e = n.O.monitorScriptsPerformance(n.O.workingWindow(), {
            dvbm: ["fetchStart", "duration"],
          });
          (t.dvtp_src_fetchStart = e.dvbm_fetchStart),
            (t.dvtp_src_duration = e.dvbm_duration);
        }
        toString() {
          return "ScriptsPerformance";
        }
      };
    },
    3079: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.SslCollector = void 0);
      const n = i(8844);
      e.SslCollector = class {
        isSupported() {
          return !0;
        }
        collectData(t) {
          const e = n.A.getDVScriptUrl(),
            { location: i } = n.O.workingWindow();
          e &&
            i &&
            /^http:/.exec(e) &&
            /^https/.exec(i.toString()) &&
            (t.diffSsl = 1),
            (t.isSsl = n.T.getProtocol());
        }
        toString() {
          return "Ssl";
        }
      };
    },
    7943: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.StrCollector = void 0);
      const n = i(8844),
        s = i(9268),
        r = i(1906),
        o = i(4112),
        a = i(5898);
      e.StrCollector = class {
        constructor() {
          (this.parentIsPermitted = !1),
            (this.ancestorChain = ""),
            (this.additionalUrl = ""),
            (this.htmlUrl = ""),
            (this.canonicalUrl = ""),
            (this.referrerOffset = 0),
            (this.insertEparam = function (t, e) {
              const i = t + "=" + encodeURIComponent(e);
              this.eparams = this.eparams ? this.eparams + "&" + i : i;
            });
        }
        isSupported() {
          return !n.O.isDomlessEnvironment();
        }
        getSTR(t) {
          return (
            (this.workingWindow = n.O.workingWindow()),
            this.findHighestAvailableWindow(),
            this.processDVurl(),
            (t.referrerUrlExtractedFromSafeFrame =
              this.referrerUrlExtractedFromSafeFrame),
            (t.safeFrameExists = this.safeFrameExists),
            this.extractAncestorChain(),
            this.calculateWindowDepth(),
            this.updateWindowDepth(),
            this.extractUrlFromHtml(t),
            this.htmlUrl || this.findAdditionalURLs(),
            this.setEparams(t),
            {
              ep1: encodeURIComponent(this.dvURL),
              ep2: encodeURIComponent(this.ancestorChain),
              ep3: encodeURIComponent(this.additionalUrl),
              ep4: encodeURIComponent(this.htmlUrl),
              ep5: encodeURIComponent(this.canonicalUrl),
            }
          );
        }
        collectData(t) {
          this.getSTR(t);
          const e = encodeURIComponent(this.eparams);
          r.Utilities.isQueryLengthBelowBrowserLimit(
            t,
            t.additionalParams,
            t.dvpParamsFlags,
            o.TPSDataMapping,
            e
          )
            ? (t.eparams = e)
            : t.dvpParamsFlags.push(3),
            (t.eparamsLength = null == e ? void 0 : e.length),
            (t.referrerDepth = this.referrerDepth),
            (t.windowDepth = this.windowDepth),
            (t.additionalUrlDepth = this.htmlUrl
              ? -1
              : this.additionalUrlDepth);
        }
        toString() {
          return "Str";
        }
        findHighestAvailableWindow() {
          try {
            this.highestAvailableWindow = this.workingWindow;
            for (let t = 0; t <= 10; t++) {
              const e = n.O.getWindowParent(this.highestAvailableWindow, !0);
              if (!e || this.highestAvailableWindow == e) {
                0 == t && (this.parentIsPermitted = !0);
                break;
              }
              {
                const t = e.location.toString();
                if (!(t.length > 0)) {
                  this.parentIsPermitted = !1;
                  break;
                }
                (this.highestAvailableWindow = e),
                  this.referrerOffset++,
                  (this.parentIsPermitted = !0);
              }
            }
          } catch (t) {
            this.parentIsPermitted = !1;
          }
        }
        processDVurl() {
          var t;
          const e = n.O.workingDocument(this.highestAvailableWindow),
            { referrer: i } = e,
            s =
              null === (t = this.workingWindow.location) || void 0 === t
                ? void 0
                : t.ancestorOrigins,
            r = null == s ? void 0 : s[s.length - 1];
          if (
            (a.SafeFrameObject.isSafeFrameExists(this.highestAvailableWindow) &&
              (this.safeFrameExists = 1),
            0 == i.length)
          )
            this.dvURL = this.highestAvailableWindow.location.toString();
          else if (this.parentIsPermitted)
            this.dvURL = this.highestAvailableWindow.location.toString();
          else {
            this.dvURL = i;
            const t = a.SafeFrameObject.getUrlReferrer(
              this.highestAvailableWindow
            );
            !t ||
              (s && 0 != t.indexOf(r)) ||
              ((this.dvURL = t),
              (this.referrerUrlExtractedFromSafeFrame = "sf")),
              (this.dvMinus = !0);
          }
        }
        extractAncestorChain() {
          const t = this.getAncestorOrigins(),
            { location: e } = this.workingWindow;
          t &&
            t.length > 0 &&
            e &&
            (t.unshift(e.protocol + "//" + e.hostname),
            (this.ancestorChain = t.reverse().join(",")));
        }
        getAncestorOrigins() {
          return r.Utilities.DOMStringListToArray(
            this.workingWindow[s.Encoding.ROT47("=@42E:@?")][
              s.Encoding.ROT47("2?46DE@C~C:8:?D")
            ]
          );
        }
        calculateWindowDepth() {
          let t = 0,
            e = this.highestAvailableWindow;
          for (; t < 10 && !n.O.isTop(e); )
            t++, (e = n.O.getWindowParent(e, !0));
          this.windowDepth = t;
        }
        findAdditionalURLs() {
          try {
            if (
              ((this.additionalUrl = ""),
              (this.additionalUrlDepth = 0),
              this.windowDepth <= 1)
            )
              return;
            const t = [];
            let e, i, s;
            t.push({ win: n.O.windowTop(!0), depth: 0 });
            let r = 1,
              o = 0;
            for (; r > 0 && o < 100; ) {
              try {
                o++, (e = t.shift()), (i = e.win), (s = e.depth), r--;
                const a = i.location.toString();
                if (a.length > 0 && i != this.highestAvailableWindow) {
                  const t = n.O.workingDocument(i),
                    { referrer: e } = t;
                  return 0 == e.length || 0 == s
                    ? ((this.additionalUrl = a),
                      void (this.additionalUrlDepth = s))
                    : ((this.additionalUrl = e),
                      void (this.additionalUrlDepth = s - 1));
                }
              } catch (t) {}
              const a = i.frames.length;
              for (let e = 0; e < a; e++)
                t.push({ win: i.frames[e], depth: s + 1 }), r++;
            }
          } catch (t) {}
        }
        updateWindowDepth() {
          (this.referrerDepth = this.windowDepth + this.referrerOffset),
            this.dvMinus && this.windowDepth && this.windowDepth--;
        }
        setEparams(t) {
          this.insertEparam("srcurl", this.dvURL),
            this.ancestorChain &&
              this.insertEparam("ancChain", this.ancestorChain);
          const e = this.htmlUrl || this.additionalUrl;
          e &&
            r.Utilities.isQueryLengthBelowBrowserLimit(
              t,
              t.additionalParams,
              t.dvpParamsFlags,
              o.TPSDataMapping,
              e
            ) &&
            this.insertEparam("aUrl", e),
            this.canonicalUrl && this.insertEparam("canurl", this.canonicalUrl),
            (this.eparams = s.Encoding.ROT47(this.eparams));
        }
        extractUrlFromHtml(t) {
          try {
            if (
              ((this.canonicalUrl = this.extractCanonicalUrl()),
              t.browserId == o.Browser.IE || 128 != t.trafficScenarioType)
            )
              return;
            if (
              (n.O.isPerformanceAPISupported() &&
                n.O.currentWindow().performance.mark("dv_str_html_start"),
              this.dvURL)
            ) {
              const t = /^(?:https?:\/\/)?[\w\-.]+\/[a-zA-Z0-9]/gi,
                e = this.dvURL.match(t);
              if (e && e.length > 0) return;
            }
            const e = n.O.workingDocument(this.highestAvailableWindow);
            if (null == e ? void 0 : e.referrer) {
              const i = e.referrer.replace(/\//g, "\\/").replace(/\./g, "\\."),
                n = new RegExp(`(?:w{0,4}=")?${i}[^&"; %,'\\$\\\\\\|]+`, "gi"),
                s = /banner|adprefs|safeframe|sandbox|sf\.html/gi,
                r = /^\w{0,4}="/gi;
              (this.htmlUrl = this.getUrlFromHtml(e, n, s, r)),
                this.measureExtraction(t);
            }
          } catch (t) {}
        }
        extractCanonicalUrl() {
          const t = n.O.workingDocument(this.highestAvailableWindow),
            e = (0, n.querySelector)("link[rel=canonical]", t);
          return null == e ? void 0 : e.href;
        }
        getUrlFromHtml(t, e, i, n) {
          let s = this.findUrlByTag(t, "script", "src", e, i, n);
          return (
            s ||
              ((s = this.extractFromScriptHtml(t, e, i, n)),
              s || (s = this.findUrlByTag(t, "a", "href", e, i, n))),
            s
          );
        }
        findLongestMatch(t, e, i) {
          let n = "";
          if (t && t.length > 0)
            for (const s of t) {
              const t = s;
              t.length > n.length &&
                null == t.match(e) &&
                0 != t.indexOf('src="') &&
                0 != t.indexOf('turl="') &&
                (n = t.replace(i, ""));
            }
          return n;
        }
        findUrlByTag(t, e, i, s, r, o) {
          const a = `${e}[${i}*="${t.referrer}"]`,
            d = (0, n.querySelectorAll)(t, a);
          let c = "";
          if (d) {
            let t = 0;
            for (; !c && t < d.length; ) {
              const e = d[t][i].match(s);
              (c = this.findLongestMatch(e, r, o)), t++;
            }
          }
          return c;
        }
        extractFromScriptHtml(t, e, i, s) {
          const { referrer: r } = t;
          let o = "";
          const a = (0, n.getElementsByTagNameFromDocument)("script", t);
          if (a) {
            let t = 0;
            for (; !o && t < a.length; ) {
              const n = a[t].innerHTML;
              if (null == n ? void 0 : n.includes(r)) {
                const t = n.match(e);
                o = this.findLongestMatch(t, i, s);
              }
              t++;
            }
          }
          return o;
        }
        measureExtraction(t) {
          if (n.O.isPerformanceAPISupported()) {
            const e = n.O.currentWindow();
            e.performance.mark("dv_str_html_end"),
              e.performance.measure(
                "dv_str_html",
                "dv_str_html_start",
                "dv_str_html_end"
              );
            const [i] = e.performance.getEntriesByName("dv_str_html");
            (null == i ? void 0 : i.duration) &&
              ((t.additionalParams.dvp_strhd = i.duration),
              (t.additionalParams.dvpx_strhd = i.duration));
          }
        }
      };
    },
    704: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.SupplySourceCollector = void 0);
      const n = i(8844),
        s = i(5473),
        r = i(1906),
        o = i(3046);
      e.SupplySourceCollector = class {
        constructor() {
          this.maxIterations = 20;
        }
        isSupported() {
          return !0;
        }
        collectData(t) {
          let e = n.A.getSupplySource();
          this.isMillenialMediaSupported()
            ? (e = "mm")
            : o.InmobiWrapper.isSupported()
            ? (e = "inm_vid")
            : this.isInmobiDisplaySupported()
            ? (e = "inm_dis")
            : s.MraidWrapper.isSupported() &&
              (s.MraidWrapper.isOperaMedia()
                ? (e = "opm")
                : s.MraidWrapper.isAdColony() && (e = "ac")),
            (t.supplySource =
              n.omidAdapter.getOmidNativePartnerName() ||
              n.omidAdapter.getOmidJSPartnerName() ||
              e),
            r.Utilities.isNullOrEmpty(t.supplySource) ||
              (t.supplySource = t.supplySource
                .split("|")
                .join("")
                .split("%7C")
                .join(""));
        }
        toString() {
          return "SupplySource";
        }
        isMillenialMediaSupported() {
          var t;
          const { mmJsBridge: e } = n.O.workingWindow(),
            i =
              null !==
                (t = (0, n.getElementById)(
                  "aolVideoContainer",
                  n.O.workingDocument()
                )) && void 0 !== t
                ? t
                : null == e
                ? void 0
                : e.vpaid,
            s = n.O.workingWindow().mmSdkVersion;
          return !!i || !!s;
        }
        isInmobiDisplaySupported() {
          return (
            0 == n.A.getTagType() &&
            s.MraidWrapper.isSupported() &&
            n.O.objectLookup(
              n.O.currentWindow(),
              "imraid",
              this.maxIterations
            ) &&
            n.O.objectLookup(n.O.currentWindow(), "inmobi", this.maxIterations)
          );
        }
      };
    },
    7703: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.TpsApiTypeCollector = void 0);
      const n = i(8844);
      e.TpsApiTypeCollector = class {
        isSupported() {
          return !0;
        }
        collectData(t) {
          switch (n.A.getDvApi()) {
            case "1":
              t.tpsApiType = "dvvisit";
              break;
            case "5":
              t.tpsApiType = "query";
              break;
            default:
              t.tpsApiType = "visit";
          }
        }
        toString() {
          return "TpsApiType";
        }
      };
    },
    8633: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.TrafficScenarioCollector = void 0);
      const n = i(8844);
      e.TrafficScenarioCollector = class {
        isSupported() {
          return !0;
        }
        collectData(t) {
          t.trafficScenarioType = n.O.getScenarioType();
        }
        toString() {
          return "TrafficScenario";
        }
      };
    },
    7898: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.UserCollector = void 0);
      const n = i(214),
        s = i(8844);
      e.UserCollector = class {
        isSupported() {
          return !0;
        }
        collectData(t) {
          (t.uid = s.RandomUtils.getRandom16()),
            (t.callbackName = n.CallbackPrefix + s.RandomUtils.getRandom16());
        }
        toString() {
          return "UserId";
        }
      };
    },
    8362: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VastUrlCollector = void 0);
      const n = i(8844),
        s = i(1906),
        r = i(4112);
      e.VastUrlCollector = class {
        isSupported(t) {
          return (
            (this.vastWrapperUrl = n.A.getVastUrl()),
            this.vastWrapperUrl &&
              this.vastWrapperUrl.length <= 1e3 &&
              s.Utilities.isQueryLengthBelowBrowserLimit(
                t,
                t.additionalParams,
                t.dvpParamsFlags,
                r.TPSDataMapping,
                this.vastWrapperUrl
              )
          );
        }
        collectData(t) {
          t.vastWrapperUrl = this.vastWrapperUrl;
        }
        toString() {
          return "vastUrl";
        }
      };
    },
    7394: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VideoParamsCollector = void 0);
      const n = i(8844);
      e.VideoParamsCollector = class {
        isSupported() {
          return n.A.isVideoOrAudio();
        }
        collectData(t) {
          (t.isdvvid = 1), (t.prePlayed = 1);
        }
        toString() {
          return "VideoParams";
        }
      };
    },
    1383: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.WindowPropertiesCollector = void 0);
      const n = i(8844),
        s = i(4112),
        r = i(1906);
      e.WindowPropertiesCollector = class {
        isSupported() {
          return !n.O.isDomlessEnvironment();
        }
        collectData(t) {
          var e, i, o;
          const a = n.O.workingWindow();
          try {
            (t.queuePageID =
              null === (e = a.external) || void 0 === e
                ? void 0
                : e.QueuePageID),
              (t.crawlerUrl =
                (null === (i = a.external) || void 0 === i
                  ? void 0
                  : i.CrawlerUrl) &&
                encodeURIComponent(
                  null === (o = a.external) || void 0 === o
                    ? void 0
                    : o.CrawlerUrl
                ));
          } catch (t) {}
          (t.postMessageSupported = Number(n.O.isPostMessageSupported())),
            (t.isChrome = a.chrome ? 1 : 0),
            (t.historySize = a.history ? a.history.length : 0),
            (t.innerHeight = n.S.getInnerViewport(!1).height),
            (t.innerWidth = n.S.getInnerViewport(!1).width),
            (t.outerHeight = n.S.getOuterViewport(
              n.O.workingWindow(),
              !1
            ).height),
            (t.outerWidth = n.S.getOuterViewport(
              n.O.workingWindow(),
              !1
            ).width),
            (t.screenHeight = n.S.getAvailableScreenSize(!1).height),
            (t.screenWidth = n.S.getAvailableScreenSize(!1).width);
          {
            const e = n.O.getUserAgent(),
              i = e ? encodeURIComponent(e) : e;
            r.Utilities.isQueryLengthBelowBrowserLimit(
              t,
              t.additionalParams,
              t.dvpParamsFlags,
              s.TPSDataMapping,
              i
            ) && (t.nativeUserAgent = i);
          }
        }
        toString() {
          return "WindowProperties";
        }
      };
    },
    9829: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.TPSDataCollector = void 0);
      const n = i(1805),
        s = i(4112);
      e.TPSDataCollector = class {
        isSupported() {
          return !0;
        }
        constructor(t) {
          this.tpsCollectors = t;
        }
        executePhase(t) {
          this.tpsCollectors.forEach((e) => {
            try {
              e.isSupported(t) && e.collectData(t);
            } catch (t) {
              n.L.sendError(
                s.ClientErrorType.TPSDataCollectorError,
                t,
                e.toString()
              );
            }
          });
        }
        toString() {
          return "TPSData";
        }
      };
    },
    4444: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.VisitJsonFlow = void 0);
      const n = i(8844),
        s = i(7102);
      function r(t) {
        var e, i, n;
        if (!("object" == typeof t && null !== t))
          throw new Error("VisitJSON: expected object response");
        if (
          !(
            32 ===
            (null === (e = t.impressionId) || void 0 === e ? void 0 : e.length)
          )
        )
          throw new Error("VisitJSON: invalid impression id");
        if (!("object" == typeof t.serverContext && null !== t.serverContext))
          throw new Error("VisitJSON: expected server context");
        if (
          !(
            "number" ==
            typeof (null ===
              (n =
                null === (i = t.serverContext) || void 0 === i
                  ? void 0
                  : i.ce) || void 0 === n
              ? void 0
              : n.ddt)
          )
        )
          throw new Error("VisitJSON: invalid DDT");
        const s = t.serverContext.ce;
        if ("dt" in s && "number" != typeof s.dt)
          throw new Error("VisitJSON: invalid DT");
        return t;
      }
      e.VisitJsonFlow = {
        execute: async function (t, e) {
          const i = r(await n.S.fetchJSON(t));
          !(function (t, e) {
            var i;
            const s = n.T.u(),
              r = n.O.currentWindow(),
              { impressionId: o } = e,
              { serverContext: a } = e,
              d = null !== (i = e.serverPublicDns) && void 0 !== i ? i : null;
            n.O.workingWindow()[t](s, r, o, d, a);
          })(e.callbackName, i),
            (function () {
              const t = n.T.u(),
                e = n.O.currentWindow(),
                i = n.T.getImpressionId(e),
                r = n.T.getFrameId(e);
              t.pubSub.publish(s.DvEvents.impressionServed, i),
                t.pubSub.publish(s.DvEvents.impressionServed, r);
            })();
        },
        validate: r,
        shouldUse: function ({ experimentEnabled: t }) {
          const e = n.S.isFetchJSONAPISupported(),
            i = !!n.A.getInitJsonPath();
          if (!e || !i) return 0;
          const s = n.A.getIsVisitJsonFlowEnabled();
          return null !== s
            ? s
              ? 3
              : 0
            : "json" === n.A.getDefaultInitType()
            ? 4
            : n.O.isDomlessEnvironment()
            ? 2
            : t
            ? 1
            : 0;
        },
      };
    },
    9374: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.NOT_FOUND_OR_ERROR = void 0),
        (e.NOT_FOUND_OR_ERROR = -1);
    },
    953: (t, e) => {
      var i;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ALL_DELIVERY_TYPES =
          e.MOBILE_APP_DELIVERY_TYPES =
          e.STANDARD_WEB_DELIVERY_TYPES =
          e.Browser =
            void 0),
        (function (t) {
          (t[(t.IE = 1)] = "IE"),
            (t[(t.Firefox = 2)] = "Firefox"),
            (t[(t.Chrome = 3)] = "Chrome"),
            (t[(t.Opera = 4)] = "Opera"),
            (t[(t.Safari = 5)] = "Safari"),
            (t[(t.ChromeWebView = 6)] = "ChromeWebView"),
            (t[(t.SafariWebView = 7)] = "SafariWebView"),
            (t[(t.PuppeteerExtraStealth = 96)] = "PuppeteerExtraStealth"),
            (t[(t.PuppeteerVanilla = 97)] = "PuppeteerVanilla"),
            (t[(t.Selenium = 98)] = "Selenium"),
            (t[(t.Playwright = 99)] = "Playwright"),
            (t[(t.Unknown = 0)] = "Unknown");
        })(i || (e.Browser = i = {})),
        (e.STANDARD_WEB_DELIVERY_TYPES = [1, 2, 0]),
        (e.MOBILE_APP_DELIVERY_TYPES = [3]),
        (e.ALL_DELIVERY_TYPES = [3, 0, 1, 2, 4]);
    },
    2892: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.isCtvSupported = e.isInAppSupported = void 0);
      e.isInAppSupported = (t) => (null == t ? void 0 : t.some((t) => 3 == t));
      e.isCtvSupported = (t) => (null == t ? void 0 : t.some((t) => 4 == t));
    },
    5480: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ClientErrorType = void 0),
        (e.ClientErrorType = {
          InjectTagError: {
            id: 1,
            message: "InjectTagError",
            isLostImpression: !0,
          },
          LoadTagError: {
            id: 2,
            message: "LoadTagError",
            isLostImpression: !0,
          },
          UnexpectedLostImpError: {
            id: 4,
            message: "UnexpectedLostImpError",
            isLostImpression: !0,
          },
          OmidSessionError: {
            id: 8,
            message: "OmidSessionError",
            isLostImpression: !0,
          },
          OmidUnexpectedLostImpError: {
            id: 16,
            message: "OmidUnexpectedLostImpError",
            isLostImpression: !0,
          },
          OmidLoadTagError: {
            id: 32,
            message: "OmidLoadTagError",
            isLostImpression: !0,
          },
          OmidInjectTagError: {
            id: 64,
            message: "OmidInjectTagError",
            isLostImpression: !0,
          },
          UnexpectedError: {
            id: 128,
            message: "UnexpectedError",
            isLostImpression: !1,
          },
          OmidUnexpectedError: {
            id: 256,
            message: "OmidUnexpectedError",
            isLostImpression: !1,
          },
          AsynchronousTaskError: {
            id: 512,
            message: "AsynchronousTaskError",
            isLostImpression: !1,
          },
          VisitLogicError: {
            id: 1024,
            message: "VisitLogicError",
            isLostImpression: !0,
          },
          VisitResponseError: {
            id: 2048,
            message: "VisitResponseError",
            isLostImpression: !0,
          },
          VisitRequestError: {
            id: 4096,
            message: "VisitRequestError",
            isLostImpression: !0,
          },
          DomlessEnvError: {
            id: 8192,
            message: "DomlessEnvError",
            isLostImpression: !0,
          },
          DisplayGenXBlockingCallbackError: {
            id: 16384,
            message: "DisplayGenXBlockingCallbackError",
            isLostImpression: !1,
          },
          InvalidVisitResponseError: {
            id: 32768,
            message: "InvalidVisitResponseError",
            isLostImpression: !0,
          },
          TagExtensionExecutionError: {
            id: 65536,
            message: "TagExtensionError",
            isLostImpression: !1,
          },
          ImpressionIdMisalignment: {
            id: 1 << 17,
            message: "ImpressionIdMisalignment",
            isLostImpression: !1,
          },
          SecondaryScriptUnavailableError: {
            id: 1 << 18,
            message: "SecondaryScriptUnavailableError",
            isLostImpression: !0,
          },
          FailedToSendEvent: {
            id: 1 << 19,
            message: "FailedToSendEvent",
            isLostImpression: !1,
          },
          DvTagArrangementError: {
            id: 1 << 20,
            message: "DvTagArrangementError",
            isLostImpression: !1,
          },
          AdLocationError: {
            id: 1 << 21,
            message: "AdLocationError",
            isLostImpression: !1,
          },
          MeasurementError: {
            id: 1 << 22,
            message: "MeasurementError",
            isLostImpression: !1,
          },
          TPSDataCollectorError: {
            id: 1 << 23,
            message: "TPSDataCollectorError",
            isLostImpression: !1,
          },
          PostMeasuredGlobalMainError: {
            id: 1 << 24,
            message: "PostMeasuredGlobalMainError",
            isLostImpression: !1,
          },
          TagCommunicationError: {
            id: 1 << 25,
            message: "TagCommunicationError",
            isLostImpression: !1,
          },
          PreMeasuredGlobalMainError: {
            id: 1 << 26,
            message: "PreMeasuredGlobalMainError",
            isLostImpression: !0,
          },
          OmidNoSessionStart: {
            id: 1 << 27,
            message: "OmidNoSessionStart",
            isLostImpression: !0,
          },
          FailObserverLongTasks: {
            id: 1 << 28,
            message: "FailObserveLongTasks",
            isLostImpression: !1,
          },
          OmidInvalidInjection: {
            id: 1 << 29,
            message: "OmidInvalidInjection",
            isLostImpression: !0,
          },
          TagServiceError: {
            id: 1 << 30,
            message: "TagServiceError",
            isLostImpression: !1,
          },
        });
    },
    4112: function (t, e, i) {
      var n =
          (this && this.__createBinding) ||
          (Object.create
            ? function (t, e, i, n) {
                void 0 === n && (n = i);
                var s = Object.getOwnPropertyDescriptor(e, i);
                (s &&
                  !("get" in s
                    ? !e.__esModule
                    : s.writable || s.configurable)) ||
                  (s = {
                    enumerable: !0,
                    get: function () {
                      return e[i];
                    },
                  }),
                  Object.defineProperty(t, n, s);
              }
            : function (t, e, i, n) {
                void 0 === n && (n = i), (t[n] = e[i]);
              }),
        s =
          (this && this.__exportStar) ||
          function (t, e) {
            for (var i in t)
              "default" === i ||
                Object.prototype.hasOwnProperty.call(e, i) ||
                n(e, t, i);
          };
      Object.defineProperty(e, "__esModule", { value: !0 }),
        s(i(9374), e),
        s(i(953), e),
        s(i(2892), e),
        s(i(5480), e),
        s(i(2580), e),
        s(i(9793), e),
        s(i(8140), e),
        s(i(5502), e),
        s(i(9479), e),
        s(i(8313), e),
        s(i(3186), e),
        s(i(6945), e);
    },
    2580: function (t, e, i) {
      var n =
          (this && this.__createBinding) ||
          (Object.create
            ? function (t, e, i, n) {
                void 0 === n && (n = i);
                var s = Object.getOwnPropertyDescriptor(e, i);
                (s &&
                  !("get" in s
                    ? !e.__esModule
                    : s.writable || s.configurable)) ||
                  (s = {
                    enumerable: !0,
                    get: function () {
                      return e[i];
                    },
                  }),
                  Object.defineProperty(t, n, s);
              }
            : function (t, e, i, n) {
                void 0 === n && (n = i), (t[n] = e[i]);
              }),
        s =
          (this && this.__exportStar) ||
          function (t, e) {
            for (var i in t)
              "default" === i ||
                Object.prototype.hasOwnProperty.call(e, i) ||
                n(e, t, i);
          };
      Object.defineProperty(e, "__esModule", { value: !0 }), s(i(9443), e);
    },
    9443: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.OmidAdEventType =
          e.OmidSupportedFeature =
          e.OmidReason =
          e.OmidVideoPlayerState =
          e.OmidVideoPosition =
          e.OmidInteractionType =
          e.OmidDeviceCategory =
          e.OmidSessionOwner =
          e.OmidAdSessionType =
          e.OmidErrorType =
          e.OmidImpressionType =
          e.OmidMediaType =
          e.OmidCreativeType =
          e.OmidAccessModeString =
            void 0),
        (e.OmidAccessModeString = {
          FULL: "full",
          DOMAIN: "domain",
          LIMITED: "limited",
        }),
        (e.OmidCreativeType = {
          DEFINED_BY_JAVASCRIPT: "definedByJavaScript",
          HTML_DISPLAY: "htmlDisplay",
          NATIVE_DISPLAY: "nativeDisplay",
          VIDEO: "video",
          AUDIO: "audio",
          UNKNOWN: "unknown",
        }),
        (e.OmidMediaType = { DISPLAY: "display", VIDEO: "video" }),
        (e.OmidImpressionType = {
          DEFINED_BY_JAVASCRIPT: "definedByJavaScript",
          UNSPECIFIED: "unspecified",
          LOADED: "loaded",
          BEGIN_TO_RENDER: "beginToRender",
          ONE_PIXEL: "onePixel",
          VIEWABLE: "viewable",
          AUDIBLE: "audible",
          OTHER: "other",
          UNKNOWN: "unknown",
        }),
        (e.OmidErrorType = {
          GENERIC: "generic",
          VIDEO: "video",
          MEDIA: "media",
        }),
        (e.OmidAdSessionType = {
          NATIVE: "native",
          HTML: "html",
          JAVASCRIPT: "javascript",
        }),
        (e.OmidSessionOwner = { NATIVE: "native", JAVASCRIPT: "javascript" }),
        (e.OmidDeviceCategory = {
          CTV: "ctv",
          DESKTOP: "desktop",
          MOBILE: "mobile",
          OTHER: "other",
        }),
        (e.OmidInteractionType = {
          CLICK: "click",
          INVITATION_ACCEPT: "invitationAccept",
        }),
        (e.OmidVideoPosition = {
          PREROLL: "preroll",
          MIDROLL: "midroll",
          POSTROLL: "postroll",
          STANDALONE: "standalone",
        }),
        (e.OmidVideoPlayerState = {
          MINIMIZED: "minimized",
          COLLAPSED: "collapsed",
          NORMAL: "normal",
          EXPANDED: "expanded",
          FULLSCREEN: "fullscreen",
        }),
        (e.OmidReason = {
          NOT_FOUND: "notFound",
          HIDDEN: "hidden",
          BACKGROUNDED: "backgrounded",
          VIEWPORT: "viewport",
          OBSTRUCTED: "obstructed",
          CLIPPED: "clipped",
          UNMEASURABLE: "unmeasurable",
          NO_WINDOW_FOCUS: "noWindowFocus",
          NO_OUTPUT_DEVICE: "noOutputDevice",
          PICTURE_IN_PICTURE: "pictureInPicture",
          DEVICE_LOCKED: "deviceLocked",
        }),
        (e.OmidSupportedFeature = { CONTAINER: "clid", VIDEO: "vlid" }),
        (e.OmidAdEventType = {
          IMPRESSION: "impression",
          LOADED: "loaded",
          GEOMETRY_CHANGE: "geometryChange",
          SESSION_START: "sessionStart",
          SESSION_ERROR: "sessionError",
          SESSION_FINISH: "sessionFinish",
          MEDIA: "media",
          VIDEO: "video",
          START: "start",
          FIRST_QUARTILE: "firstQuartile",
          MIDPOINT: "midpoint",
          THIRD_QUARTILE: "thirdQuartile",
          COMPLETE: "complete",
          PAUSE: "pause",
          RESUME: "resume",
          BUFFER_START: "bufferStart",
          BUFFER_FINISH: "bufferFinish",
          SKIPPED: "skipped",
          VOLUME_CHANGE: "volumeChange",
          PLAYER_STATE_CHANGE: "playerStateChange",
          AD_USER_INTERACTION: "adUserInteraction",
        });
    },
    9793: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 });
    },
    8140: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 });
    },
    5502: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 });
    },
    9479: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 });
    },
    8313: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.TPSData = void 0);
      const n = i(1906);
      e.TPSData = class {
        constructor() {
          (this.tagVersion = "6.1.src"),
            (this.jsver = n.Utilities.getVersion()),
            (this.trafficScenarioType = 0),
            (this.additionalParams = {}),
            (this.dvpParamsFlags = []);
        }
      };
    },
    3186: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.TPSDataMapping = void 0),
        (e.TPSDataMapping = {
          flavor: "flvr",
          timeToMeasureMs: "ttmms",
          timeToFirstReportMs: "ttfrms",
          timeToFirstUpdateReportMs: "ttfurm",
          totalMeasurementExecTime: "tmet",
          browserId: "brid",
          browserVersion: "brver",
          browserIdUserAgent: "bridua",
          browserDetectionSource: "bds",
          trafficScenarioType: "tstype",
          isPreRender: "prndr",
          eparams: "eparams",
          windowDepth: "srcurlD",
          additionalUrlDepth: "aUrlD",
          isSsl: "ssl",
          diffSsl: "dvp_diffSSL",
          isMraid: "ismraid",
          prePlayed: "prplyd",
          supplySource: "sup",
          dvtp_src_fetchStart: "dfs",
          dvtp_src_duration: "ddur",
          uid: "uid",
          callbackName: "jsCallback",
          tagVersion: "dvtagver",
          nativeUserAgent: "navUa",
          postMessageSupported: "htmlmsging",
          isChrome: "chro",
          historySize: "hist",
          innerHeight: "winh",
          innerWidth: "winw",
          outerHeight: "wouh",
          outerWidth: "wouw",
          screenHeight: "scah",
          screenWidth: "scaw",
          queuePageID: "qpgid",
          crawlerUrl: "curl",
          isScriptInHeadLocation: "dvp_isOnHead",
          dvtpScriptVersion: "tgjsver",
          idcResults: "vavbkt",
          idcError: "dvp_idcerr",
          idcVersion: "lvvn",
          browserSignatureFamilyBits: "bsig",
          browserSignatureBits: "usig",
          hijackedDeviceSignatureBits: "hdsig",
          browserFeatures: "m1",
          referrerDepth: "refD",
          referrerUrl: "referrer",
          referrerUrlExtractedFromSafeFrame: "urlsrc",
          safeFrameExists: "sfe",
          widgetCount: "fwc",
          cookieLength: "fcl",
          domainLookupTime: "flt",
          documentElementCount: "fec",
          iframeCount: "fcifrms",
          historyLength: "brh",
          omidEnvironment: "omdenv",
          omidAdSessionType: "omdsessiontype",
          omidAppId: "omdappid",
          omidContentUrl: "omcurl",
          omidAccessMode: "omacm",
          scriptDynamicFlags: "sdf",
          eparamsLength: "dvp_epl",
          vastWrapperUrl: "wrapperurl",
          numberOfCores: "noc",
          hasTouchPad: "touch",
          navigatorPlatform: "nav_pltfrm",
          ctx: "ctx",
          cmp: "cmp",
          ipos: "ipos",
          sid: "sid",
          plc: "plc",
          adid: "adid",
          crt: "crt",
          btreg: "btreg",
          btadsrv: "btadsrv",
          adsrv: "adsrv",
          advid: "advid",
          num: "num",
          jsver: "jsver",
          pid: "pid",
          crtname: "crtname",
          unit: "unit",
          chnl: "chnl",
          scusrid: "scusrid",
          tagtype: "tagtype",
          sr: "sr",
          dt: "dt",
          dup: "dup",
          app: "app",
          dvvidver: "dvvidver",
          turl: "turl",
          icall: "icall",
          dv_callback: "dv_callback",
          useragent: "useragent",
          xff: "xff",
          timecheck: "timecheck",
          tvcp: "tvcp",
          vssd: "vssd",
          apifw: "apifw",
          vstvr: "vstvr",
          paonlytag: "paonlytag",
          iplessSideBySideInjection: "ilsbsi",
          seltag: "seltag",
          sadv: "sadv",
          ord: "ord",
          litm: "litm",
          scrt: "scrt",
          invs: "invs",
          splc: "splc",
          adu: "adu",
          spos: "spos",
          c1: "c1",
          c2: "c2",
          c3: "c3",
          c4: "c4",
          c5: "c5",
          c6: "c6",
          c7: "c7",
          c8: "c8",
          c9: "c9",
          c10: "c10",
          c11: "c11",
          c12: "c12",
          c13: "c13",
          c14: "c14",
          c15: "c15",
          native: "native",
          gmnpo: "gmnpo",
          isdvvid: "isdvvid",
          msrapi: "msrapi",
          bsimpid: "bsimpid",
          auctionid: "auctionid",
          vermemid: "vermemid",
          source: "source",
          buymemid: "buymemid",
          anadvid: "anadvid",
          ioid: "ioid",
          cpgid: "cpgid",
          cpid: "cpid",
          sellerid: "sellerid",
          pubid: "pubid",
          advcode: "advcode",
          iocode: "iocode",
          cpgcode: "cpgcode",
          cpcode: "cpcode",
          pubcode: "pubcode",
          prcpaid: "prcpaid",
          auip: "auip",
          auua: "auua",
          prr: "prr",
          iframe: "iframe",
          gdpr: "gdpr",
          gdpr_consent: "gdpr_consent",
          errorURL: "errorURL",
          auprice: "auprice",
          ppid: "ppid",
          audeal: "audeal",
          auevent: "auevent",
          auadv: "auadv",
          aucmp: "aucmp",
          aucrtv: "aucrtv",
          auorder: "auorder",
          ausite: "ausite",
          auplc: "auplc",
          auxch: "auxch",
          audvc: "audvc",
          aulitem: "aulitem",
          auadid: "auadid",
          pltfrm: "pltfrm",
          aufilter1: "aufilter1",
          aufilter2: "aufilter2",
          autt: "autt",
          aubndl: "aubndl",
          supportedIntegrations: "mib",
          abortVisitRequest: "avr",
        });
    },
    6945: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.ViewabilityCalculationTypes = e.ViewabilityConstants = void 0),
        (e.ViewabilityConstants = {
          IAB: {
            DisplayMinimalDuration: 1e3,
            VideoMinimalDuration: 2e3,
            DisplayMinimalLargeAdArea: 242500,
            MinimalAdAreaPercentageForStandardSize: 50,
            DisplayMinimalAdAreaPercentageForLargeSize: 30,
          },
          GroupM: {
            DisplayMinimalDuration: 100,
            VideoMinimalDuration: 15e3,
            VideoMinimalDurationPercentage: 50,
            DisplayMinimalLargeAdArea: 242500,
            VideoMinimalLargeAdArea: 3e5,
            MinimalAdAreaPercentageForStandardSize: 98,
            DisplayMinimalAdAreaPercentageForLargeSize: 0,
            VideoMinimalAdAreaPercentageForLargeSize: 80,
          },
          GroupMV4: {
            DisplayMinimalDuration: 1e3,
            VideoMinimalDuration: 15e3,
            VideoMinimalDurationPercentage: 50,
            DisplayMinimalLargeAdArea: 242500,
            VideoMinimalLargeAdArea: 3e5,
            MinimalAdAreaPercentageForStandardSize: 98,
            DisplayMinimalAdAreaPercentageForLargeSize: 50,
            VideoMinimalAdAreaPercentageForLargeSize: 80,
          },
          PMX: {
            DisplayMinimalDuration: 1e3,
            VideoMinimalDuration: 2e3,
            DisplayMinimalLargeAdArea: 242500,
            VideoMinimalLargeAdArea: 3e5,
            MinimalAdAreaPercentageForStandardSize: 98,
            DisplayMinimalAdAreaPercentageForLargeSize: 30,
            VideoMinimalAdAreaPercentageForLargeSize: 50,
          },
          CustomAdvertiserViewabilityStandard: {
            DisplayMinimalLargeAdArea: 242500,
            VideoMinimalLargeAdArea: 3e5,
          },
          RB: { MinimalAdAreaPercentageForStandardSize: 50 },
        }),
        (e.ViewabilityCalculationTypes = {
          Unknown: 0,
          Geometric: 1,
          ResourceBased: 2,
          SafeFrameGeometric: 8,
          SafeFramePercentage: 16,
          AmpIntersectionObserver: 32,
          ScreenGeometric: 64,
          Mraid: 128,
          IntersectionObserver: 512,
          Omid: 1024,
          AdColonyMraid: 2048,
          Mraid3: 4096,
          AllScenarioIntersectionObserver: 8192,
        });
    },
    3741: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.BooleanFeatureFlag = e.BooleanFeatureOptionId = void 0);
      const n = i(1360),
        s = i(1954);
      var r;
      !(function (t) {
        (t.ENABLED = "1"), (t.DISABLED = "0");
      })(r || (e.BooleanFeatureOptionId = r = {}));
      class o extends s.FeatureFlag {
        constructor(t, e, i, n = () => null, s = {}) {
          super(t, e, i, n, s);
        }
        isEnabled() {
          return this.status === r.ENABLED;
        }
        reportDiagnosticParam() {
          this.isEnabled() &&
            null != this.diagnosticParamName &&
            null != this.status &&
            n.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              this.diagnosticParamName,
              this.status
            );
        }
        parseOverride(t) {
          return t === r.ENABLED
            ? r.ENABLED
            : t === r.DISABLED
            ? r.DISABLED
            : null;
        }
      }
      e.BooleanFeatureFlag = o;
    },
    1954: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.FeatureFlag = void 0);
      const n = i(8811);
      e.FeatureFlag = class {
        constructor(t, e, i, n = () => null, s = {}) {
          (this.name = t),
            (this.distribution = e),
            (this.diagnosticParamName = i),
            (this.statusOverride = n),
            (this.hooks = s),
            (this.isStatusAssigned = !1),
            (this.status = null);
        }
        init() {
          var t, e;
          this.isStatusAssigned ||
            ((0, n.isValidDistribution)(this.distribution)
              ? (this.decideStatus(),
                (this.isStatusAssigned = !0),
                this.reportDiagnosticParam())
              : null === (e = (t = this.hooks).reportError) ||
                void 0 === e ||
                e.call(
                  t,
                  new Error(
                    `Invalid distribution for the ${this.name} experiment`
                  )
                ));
        }
        decideStatus() {
          const t = this.statusOverride(),
            e = this.parseOverride(t);
          this.status =
            null != e
              ? e
              : (0, n.randomlySelectFromDistribution)(this.distribution);
        }
        getStatus() {
          return this.status;
        }
      };
    },
    1882: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.MultiOptionFeatureFlag =
          e.BooleanFeatureOptionId =
          e.BooleanFeatureFlag =
          e.FeatureFlag =
          e.randomlySelectFromDistribution =
          e.isValidDistribution =
            void 0);
      var n = i(8811);
      Object.defineProperty(e, "isValidDistribution", {
        enumerable: !0,
        get: function () {
          return n.isValidDistribution;
        },
      }),
        Object.defineProperty(e, "randomlySelectFromDistribution", {
          enumerable: !0,
          get: function () {
            return n.randomlySelectFromDistribution;
          },
        });
      var s = i(1954);
      Object.defineProperty(e, "FeatureFlag", {
        enumerable: !0,
        get: function () {
          return s.FeatureFlag;
        },
      });
      var r = i(3741);
      Object.defineProperty(e, "BooleanFeatureFlag", {
        enumerable: !0,
        get: function () {
          return r.BooleanFeatureFlag;
        },
      }),
        Object.defineProperty(e, "BooleanFeatureOptionId", {
          enumerable: !0,
          get: function () {
            return r.BooleanFeatureOptionId;
          },
        });
      var o = i(4456);
      Object.defineProperty(e, "MultiOptionFeatureFlag", {
        enumerable: !0,
        get: function () {
          return o.MultiOptionFeatureFlag;
        },
      });
    },
    4456: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.MultiOptionFeatureFlag = void 0);
      const n = i(1360),
        s = i(1954);
      class r extends s.FeatureFlag {
        constructor(t, e, i, n = () => null, s = {}) {
          super(t, e, i, n, s);
        }
        reportDiagnosticParam() {
          null != this.diagnosticParamName &&
            null != this.status &&
            n.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
              this.diagnosticParamName,
              this.status
            );
        }
        parseOverride(t) {
          var e, i;
          return null !==
            (i =
              null ===
                (e = this.distribution.find((e) => t === e.optionName)) ||
              void 0 === e
                ? void 0
                : e.optionName) && void 0 !== i
            ? i
            : null;
        }
      }
      e.MultiOptionFeatureFlag = r;
    },
    8811: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.randomlySelectFromDistribution = e.isValidDistribution = void 0);
      e.isValidDistribution = (t) => {
        if (null == t || 0 === t.length) return !1;
        return (
          !t.some(
            ({ percentage: t }) => "number" != typeof t || t < 0 || t > 100
          ) && 100 == t.reduce((t, { percentage: e }) => t + e, 0)
        );
      };
      e.randomlySelectFromDistribution = (t) => {
        const e = 100 * Math.random();
        let i = 0;
        for (const n of t) {
          const t = i + n.percentage;
          if (e >= i && e < t) return n.optionName;
          i = t;
        }
        return null;
      };
    },
    428: (t, e) => {
      var i;
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.getDiagnosticQueryParamName = e.DiagnosticParams = void 0),
        (function (t) {
          (t.tcfDvDisclosure = "tcfds"),
            (t.tcfRolloutPercentage = "tcfrp"),
            (t.unitTest = "ut"),
            (t.omidRenderedFromImpressionEvent = "omrie"),
            (t.omidRenderedFromGeomChangePercLargerThanZero = "omrge"),
            (t.cvcMethodId = "cvcmeeid"),
            (t.adIdentityClientCode = "ctx"),
            (t.adIdentityAdServerCampaignCode = "cmp"),
            (t.adIdentityAdServerSiteCode = "sid"),
            (t.adIdentityPlacementId = "plc"),
            (t.adIdentityAdServer = "adsrv"),
            (t.adIdentityDedupingId = "dup"),
            (t.timeUntilOmidListenMs = "omlms"),
            (t.errorStackTrace = "errstk"),
            (t.timeTillAdSelected = "tmads"),
            (t.taskTiming = "tskt"),
            (t.isOmid3p = "isom3p"),
            (t.adSizeMeasurementMethod = "asmm"),
            (t.omidEnvironment = "omenv"),
            (t.btregOptimizationValue = "btreg"),
            (t.btadsrvValue = "btadsrv"),
            (t.findClassValue = "findclass"),
            (t.tagUniqueKey = "tukv"),
            (t.sharedTagUniqueKey = "sukv"),
            (t.ddtExtractionSource = "ddtes"),
            (t.unknownScreenOrientationType = "usot"),
            (t.isOmidEnabled = "isom"),
            (t.tagCounterOmidSupported = "tgcoom"),
            (t.omidPartnerName = "omnpn"),
            (t.omidPartnerVersion = "omnpv"),
            (t.omidJSPartnerName = "omjspn"),
            (t.omidJSPartnerVersion = "omjspv"),
            (t.omidFirstAdSizeFromGeometryMs = "omfadsfgms"),
            (t.omidTimeMsUntilStartSession = "omstsms"),
            (t.omidTimeMsUntilStartVideo = "omstms"),
            (t.omidTimeMsUntilEndVideo = "omensms"),
            (t.omidVendorKey = "omvk"),
            (t.omidMeasuringElement = "ome"),
            (t.omidDeviceCategory = "omdevcat"),
            (t.omidVersionComparison = "omverc"),
            (t.omidAdSessionId = "omasid"),
            (t.omidLibraryVersion = "omlibv"),
            (t.omidCreativeType = "omct"),
            (t.isKeyPressed = "iskp"),
            (t.isMouseMoved = "ismm"),
            (t.isOrientationChangedToPortrait = "isoctp"),
            (t.isOrientationChangedToLandscape = "isoctl"),
            (t.isMrcImpression = "mrci"),
            (t.selectedAdWidth = "saw"),
            (t.selectedAdHeight = "sah"),
            (t.ImpressionServed = "rtnevis"),
            (t.IABMeasuredImpression = "rtneviabmi"),
            (t.IABNotMeasuredImpression = "rtneviabnmi"),
            (t.IABViewableImpression = "rtneviabvi"),
            (t.GroupMMeasuredImpression = "rtnevgmmmi"),
            (t.GroupMPassedImpression = "rtnevgmmpi"),
            (t.GroupMV3StandardPassedImpression = "rtnevgmv3spi"),
            (t.GroupMV4StandardPassedImpression = "rtnevgmv4spi"),
            (t.GroupMV4DisplayStandardPassedImpression = "rtnevgmv4dspi"),
            (t.GroupMV4VideoReachExtensionStandardPassedImpression =
              "rtnevgmv4vrespi"),
            (t.GroupMV4VideoNativeStandardPassedImpression = "rtnevgmv4vnspi"),
            (t.CustomViewabilityViewable = "rtnevcvv"),
            (t.VideoQuartile1ViewableIAB = "rtnevvq1vi"),
            (t.VideoQuartile2ViewableIAB = "rtnevvq2vi"),
            (t.VideoQuartile3ViewableIAB = "rtnevvq3vi"),
            (t.VideoQuartile4ViewableIAB = "rtnevvq4vi"),
            (t.IABAdViewable5Seconds = "rtneviabv5s"),
            (t.IABAdViewable10Seconds = "rtneviabv10s"),
            (t.IABAdViewable15Seconds = "rtneviabv15s"),
            (t.PMXStandardMeasuredImpression = "rtnevpmxmi"),
            (t.PMXStandardPassedImpression = "rtnevpmxpi"),
            (t.EngagementAudienceDisengaged = "rtnevead"),
            (t.EngagementAudienceEngaged = "rtneveae"),
            (t.EngagementAudienceNoEngagement = "rtneveane"),
            (t.EngagementAudienceInterested = "rtneveai"),
            (t.AdInteraction = "rtnevai"),
            (t.DeviceInteraction = "rtnevdi"),
            (t.NoInteraction = "rtnevni"),
            (t.MRCImpression = "rtnevmrci"),
            (t.SessionEnd = "rtnevse"),
            (t.timeMsUntilAdMeasured = "tmuam"),
            (t.omidInteractionInvitationAccept = "omiia"),
            (t.omidCustomInteractions = "omci"),
            (t.omidIsVerificationPropsDefined = "omvpdef"),
            (t.descendantIframeClickHandlers = "dich"),
            (t.visitJsonExperimentGroup = "vjeg"),
            (t.gandalfTheWhiteAdId = "gtwadid"),
            (t.iplessSideBySideInjectionFailed = "ilsbsif"),
            (t.intersectionObserverMethodSupported = "isioms"),
            (t.ampIntersectionObserverMethodSupported = "isaioms"),
            (t.isOmidInjectionIdExtractable = "isomijid"),
            (t.omidInjectionId = "omijid"),
            (t.dvtpOmidInjectionId = "dvtpomijid"),
            (t.secondaryIabViewabilityMeasured = "issiabvm"),
            (t.secondaryIabViewable = "issiabvv"),
            (t.omidVideoDuration = "omvd"),
            (t.tagCounter = "tcnt"),
            (t.omidMaxPercentageInView = "ompiv"),
            (t.omidNoSessionStartId = "omnssid"),
            (t.Rt = "impdvobj"),
            (t.misalignmentImpressionId = "impmis"),
            (t.containerRenderLogicWindowLoadState = "crlwls"),
            (t.containerRenderLogicPreRenderReason = "crlprr"),
            (t.containerRenderLogicFlowStep = "crlfst"),
            (t.containerRenderLogicDirectChildrenCount = "crlfdc"),
            (t.containerRenderLogicLoadableChildrenCount = "crlflc"),
            (t.containerRenderLogicDirectImgCount = "crlimg"),
            (t.containerRenderLogicDirectIframeCount = "crlifr"),
            (t.containerRenderLogicNonLoadableChildrenCount = "crlnlc"),
            (t.containerRenderLogicLoadedChildCount = "crllic"),
            (t.containerRenderLogicSyncRendered = "crlsyn"),
            (t.containerRenderLogicActiveListenersCount = "crlalc"),
            (t.containerRenderLogicImgNotCompleteCount = "crlinc"),
            (t.containerRenderLogicImgZeroHeightCount = "crlinh"),
            (t.containerRenderLogicImgNotLoadedCount = "crlimnl"),
            (t.containerRenderLogicIframeNotLoadedCount = "crlifc"),
            (t.containerRenderLogicRenderDelayMs = "crlrdms"),
            (t.containerRenderLogicAsyncRendered = "crlasy"),
            (t.containerRenderLogicRenderSource = "crlrrs"),
            (t.containerRenderLogicContainerImageWidth = "crlciw"),
            (t.containerRenderLogicContainerImageHeight = "crlcih"),
            (t.cdnDomain = "cdndmn"),
            (t.max50PctAdContinuousInViewTimeMsNoPauseReset = "m50invnprms"),
            (t.engvlchmsFromState = "evchfs"),
            (t.engvlchmsToState = "evchts"),
            (t.engvlchmsFromStateTimeMs = "evchfsms"),
            (t.engvlchmsToStateTimeMs = "evchtsms"),
            (t.tiktokTagTypeOverride = "tttovrd"),
            (t.tiktokMrcImpressionId = "ttmrcid"),
            (t.tiktokTemplateMarker = "tttplmrk"),
            (t.cm360Detected = "cmdet"),
            (t.cm360DcAdk = "cmdcadk"),
            (t.cm360AccessResult = "cmacr"),
            (t.dvRefireCounter = "dvrfc"),
            (t.dvSessionToken = "dvstk"),
            (t.dvDedupStorageMethod = "dvsm"),
            (t.cm360DedupDiagnosticExperiment = "cmddexp"),
            (t.rcPerfResourcesMs = "rcprms"),
            (t.tagObservabilityTelemetryExperiment = "tote"),
            (t.randomizeOmidVendorKeyExperiment = "rvkexp"),
            (t.omidConstructTimeParamMismatch = "omctmm"),
            (t.omidConstructTimeCtxCmpMismatch = "omctcm"),
            (t.omidConstructTimeParamMismatchPayloadExperiment = "omctpexp"),
            (t.omidConstructTimeOmParams = "omctom"),
            (t.omidConstructTimeUrlParams = "omcturl"),
            (t.telemetryOmidEvents = "tlome"),
            (t.omidJsServiceVersion = "omjssv"),
            (t.omidMediaType = "ommt"),
            (t.omidAdSessionType = "omast"),
            (t.omidAccessMode = "omam"),
            (t.omidSessionCreativeType = "omsct"),
            (t.omidSessionClientVersion = "omsclv"),
            (t.omidDeviceOs = "omdos"),
            (t.omidDeviceOsVersion = "omdosv"),
            (t.omidDeviceType = "omdevt"),
            (t.omidVerificationParametersState = "omvpst");
        })(i || (e.DiagnosticParams = i = {}));
      e.getDiagnosticQueryParamName = (t) => `ee_dp_${t}`;
    },
    1814: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.DiagnosticParamsReporterSingleton = void 0);
      const n = i(9899),
        s = i(428);
      e.DiagnosticParamsReporterSingleton = new (class {
        constructor() {
          this.lastValueReported = {};
        }
        reportDiagnosticParam(t, e) {
          const i = (0, s.getDiagnosticQueryParamName)(t);
          (0, n.emitDiagnostic)({ [i]: e });
        }
        report(t, e) {
          if (this.lastValueReported[t] !== e) {
            this.lastValueReported[t] = e;
            const i = (0, s.getDiagnosticQueryParamName)(t);
            (0, n.emitDiagnostic)({ [i]: e });
          }
        }
        reportOnce(t, e) {
          if (!(t in this.lastValueReported)) {
            this.lastValueReported[t] = e;
            const i = (0, s.getDiagnosticQueryParamName)(t);
            (0, n.emitDiagnostic)({ [i]: e });
          }
        }
      })();
    },
    1360: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.TagExtensionsExecutionParamsSingleton =
          e.TagExtensionsExecutionParamsUtils =
          e.TagExtensionsExecutionParams =
          e.sendS2SPartnerTelemetryEvent =
          e.configureDiagnosticsTransport =
          e.DiagnosticParamsReporterSingleton =
          e.getDiagnosticQueryParamName =
          e.DiagnosticParams =
            void 0);
      var n = i(428);
      Object.defineProperty(e, "DiagnosticParams", {
        enumerable: !0,
        get: function () {
          return n.DiagnosticParams;
        },
      }),
        Object.defineProperty(e, "getDiagnosticQueryParamName", {
          enumerable: !0,
          get: function () {
            return n.getDiagnosticQueryParamName;
          },
        });
      var s = i(1814);
      Object.defineProperty(e, "DiagnosticParamsReporterSingleton", {
        enumerable: !0,
        get: function () {
          return s.DiagnosticParamsReporterSingleton;
        },
      });
      var r = i(9899);
      Object.defineProperty(e, "configureDiagnosticsTransport", {
        enumerable: !0,
        get: function () {
          return r.configureDiagnosticsTransport;
        },
      });
      var o = i(6341);
      Object.defineProperty(e, "sendS2SPartnerTelemetryEvent", {
        enumerable: !0,
        get: function () {
          return o.sendS2SPartnerTelemetryEvent;
        },
      });
      var a = i(9178);
      Object.defineProperty(e, "TagExtensionsExecutionParams", {
        enumerable: !0,
        get: function () {
          return a.TagExtensionsExecutionParams;
        },
      }),
        Object.defineProperty(e, "TagExtensionsExecutionParamsUtils", {
          enumerable: !0,
          get: function () {
            return a.TagExtensionsExecutionParamsUtils;
          },
        }),
        Object.defineProperty(e, "TagExtensionsExecutionParamsSingleton", {
          enumerable: !0,
          get: function () {
            return a.TagExtensionsExecutionParamsSingleton;
          },
        });
    },
    6341: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.sendS2SPartnerTelemetryEvent = void 0);
      e.sendS2SPartnerTelemetryEvent = (t) => {};
    },
    9178: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.TagExtensionsExecutionParamsSingleton =
          e.TagExtensionsExecutionParamsUtils =
          e.TagExtensionsExecutionParams =
            void 0);
      const n = i(9899);
      var s;
      !(function (t) {
        (t.tagExtensionOrchestratorStarted = "strt"),
          (t.tagExtensionsInitialized = "init"),
          (t.tagExtensionsSupported = "sup"),
          (t.tagExtensionsExecuted = "exec");
      })(s || (e.TagExtensionsExecutionParams = s = {}));
      class r {
        getQueryParamName(t) {
          return `te_${t}`;
        }
        reportTagExtensionsExecutionParams(t, e) {
          const i = this.getQueryParamName(t);
          (0, n.emitDiagnostic)({ [i]: e });
        }
      }
      (e.TagExtensionsExecutionParamsUtils = r),
        (e.TagExtensionsExecutionParamsSingleton = new r());
    },
    9899: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.emitDiagnostic = e.configureDiagnosticsTransport = void 0);
      let i = () => {};
      e.configureDiagnosticsTransport = (t) => {
        i = t;
      };
      e.emitDiagnostic = (t) => {
        i(t);
      };
    },
    4084: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.readDvDisclosure = void 0);
      const n = i(5649),
        s = 1,
        r = 2,
        o = 3;
      function a(t, e) {
        if (t.includes("1", e)) throw new Error("Nonzero TC padding");
      }
      e.readDvDisclosure = function (t) {
        try {
          const [e, ...i] = t.split("."),
            d = (0, n.decodeBase64Url)(e);
          a(d, (0, n.decodeCoreSegmentBitLength)(d));
          let c = 3;
          for (const t of i) {
            const e = (0, n.decodeBase64Url)(t),
              i = (0, n.decodeInt)(
                e.slice(0, n.BitLength.segmentType),
                n.BitLength.segmentType
              ),
              d = e.slice(n.BitLength.segmentType);
            if (i === s && 3 === c) {
              const {
                maxId: t,
                ranges: e,
                bitLength: i,
              } = (0, n.decodeVendorVector)(d);
              if (e.some(([e, i]) => e > i || i > t)) return 3;
              a(d, i), (c = e.some(([t, e]) => t <= 126 && 126 <= e) ? 1 : 2);
            } else if (i === r) a(d, (0, n.decodeVendorVector)(d).bitLength);
            else {
              if (i !== o) return 3;
              a(d, (0, n.decodePublisherTcBitLength)(d));
            }
          }
          return c;
        } catch (t) {
          return 3;
        }
      };
    },
    5649: (t, e) => {
      /*! @license Apache-2.0 https://www.apache.org/licenses/LICENSE-2.0
       * TC string decoding forked from @iabtechlabtcf/core 1.5.22, Copyright 2019 IAB Technology Laboratory, Inc. */
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.decodePublisherTcBitLength =
          e.decodeCoreSegmentBitLength =
          e.decodePurposeRestrictionVectorBitLength =
          e.decodeVendorVector =
          e.decodeInt =
          e.decodeBase64Url =
          e.BitLength =
            void 0),
        (e.BitLength = {
          segmentType: 3,
          maxId: 16,
          encodingType: 1,
          numEntries: 12,
          singleOrRange: 1,
          vendorId: 16,
          numRestrictions: 12,
          purposeId: 6,
          restrictionType: 2,
          anyBoolean: 1,
          publisherConsents: 24,
          publisherLegitimateInterests: 24,
          numCustomPurposes: 6,
        });
      const i = {
          version: 6,
          created: 36,
          lastUpdated: 36,
          cmpId: 12,
          cmpVersion: 12,
          consentScreen: 6,
          consentLanguage: 12,
          vendorListVersion: 12,
          policyVersion: 6,
          isServiceSpecific: 1,
          useNonStandardTexts: 1,
          specialFeatureOptins: 12,
          purposeConsents: 24,
          purposeLegitimateInterests: 24,
          purposeOneTreatment: 1,
          publisherCountryCode: 12,
        },
        n = 1,
        s = [0, 1, 2];
      function r(t, e) {
        if (e !== t.length) throw new Error("invalid bit length");
        return parseInt(t, 2);
      }
      (e.decodeBase64Url = function (t) {
        if (!/^[A-Za-z0-9\-_]+$/.test(t))
          throw new Error("Invalidly encoded Base64URL string");
        let e = "";
        for (const i of t) {
          const t =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
              .indexOf(i)
              .toString(2);
          e += "0".repeat(6 - t.length) + t;
        }
        return e;
      }),
        (e.decodeInt = r);
      const o = (t) => "1" === t;
      function a(t, e) {
        if (t.length !== e)
          throw new Error("bitfield encoding length mismatch");
      }
      function d(t) {
        let i = 0;
        const s = r(t.slice(i, i + e.BitLength.maxId), e.BitLength.maxId);
        i += e.BitLength.maxId;
        const d = r(t.charAt(i), e.BitLength.encodingType);
        i += e.BitLength.encodingType;
        const c = [];
        if (d === n) {
          const n = r(
            t.slice(i, i + e.BitLength.numEntries),
            e.BitLength.numEntries
          );
          i += e.BitLength.numEntries;
          for (let s = 0; s < n; s++) {
            const n = o(t.charAt(i));
            i += e.BitLength.singleOrRange;
            const s = r(
              t.slice(i, i + e.BitLength.vendorId),
              e.BitLength.vendorId
            );
            i += e.BitLength.vendorId;
            let a = s;
            if (
              (n &&
                ((a = r(
                  t.slice(i, i + e.BitLength.vendorId),
                  e.BitLength.vendorId
                )),
                (i += e.BitLength.vendorId)),
              0 === s)
            )
              throw new Error("invalid value 0 passed for set()");
            c.push([s, a]);
          }
        } else {
          const e = t.slice(i, i + s);
          (i += s), a(e, s);
          for (let t = 1; t <= s; t++) o(e[t - 1]) && c.push([t, t]);
        }
        return { maxId: s, ranges: c, bitLength: i };
      }
      function c(t) {
        let i = 0;
        const n = r(
          t.slice(i, i + e.BitLength.numRestrictions),
          e.BitLength.numRestrictions
        );
        i += e.BitLength.numRestrictions;
        for (let a = 0; a < n; a++) {
          const n = r(
            t.slice(i, i + e.BitLength.purposeId),
            e.BitLength.purposeId
          );
          i += e.BitLength.purposeId;
          const a = r(
            t.slice(i, i + e.BitLength.restrictionType),
            e.BitLength.restrictionType
          );
          i += e.BitLength.restrictionType;
          const d = r(
            t.slice(i, i + e.BitLength.numEntries),
            e.BitLength.numEntries
          );
          i += e.BitLength.numEntries;
          for (let c = 0; c < d; c++) {
            const d = o(t.slice(i, i + e.BitLength.anyBoolean));
            i += e.BitLength.anyBoolean;
            const c = r(
              t.slice(i, i + e.BitLength.vendorId),
              e.BitLength.vendorId
            );
            if (((i += e.BitLength.vendorId), d)) {
              const n = r(
                t.slice(i, i + e.BitLength.vendorId),
                e.BitLength.vendorId
              );
              if (((i += e.BitLength.vendorId), n < c))
                throw new Error(
                  `Invalid RangeEntry: endVendorId ${n} is less than ${c}`
                );
            }
            if (n < 1 || !s.includes(a))
              throw new Error("cannot hash invalid PurposeRestriction");
          }
        }
        return i;
      }
      (e.decodeVendorVector = d),
        (e.decodePurposeRestrictionVectorBitLength = c),
        (e.decodeCoreSegmentBitLength = function (t) {
          let e = 0;
          const n = {};
          for (const [s, o] of Object.entries(i))
            (n[s] = r(t.slice(e, e + o), o)), (e += o);
          if (2 !== n.version)
            throw new Error(`Unable to decode version: ${n.version}`);
          if (n.cmpId <= 1) throw new Error("invalid value passed for cmpId");
          const s = 2 ** (i.publisherCountryCode / 2),
            o = String.fromCharCode(
              65 + Math.floor(n.publisherCountryCode / s),
              65 + (n.publisherCountryCode % s)
            );
          if (!/^([A-z]){2}$/.test(o))
            throw new Error("invalid value passed for publisherCountryCode");
          return (
            (e += d(t.slice(e)).bitLength),
            (e += d(t.slice(e)).bitLength),
            (e += c(t.slice(e))),
            e
          );
        }),
        (e.decodePublisherTcBitLength = function (t) {
          let i = 0;
          a(
            t.slice(i, i + e.BitLength.publisherConsents),
            e.BitLength.publisherConsents
          ),
            (i += e.BitLength.publisherConsents),
            a(
              t.slice(i, i + e.BitLength.publisherLegitimateInterests),
              e.BitLength.publisherLegitimateInterests
            ),
            (i += e.BitLength.publisherLegitimateInterests);
          const n = r(
            t.slice(i, i + e.BitLength.numCustomPurposes),
            e.BitLength.numCustomPurposes
          );
          i += e.BitLength.numCustomPurposes;
          for (let e = 0; e < 2; e++) a(t.slice(i, i + n), n), (i += n);
          return i;
        });
    },
    7065: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.TcfClientStop = e.TcfClientStopClass = e.readDvDisclosure = void 0);
      var n = i(4084);
      Object.defineProperty(e, "readDvDisclosure", {
        enumerable: !0,
        get: function () {
          return n.readDvDisclosure;
        },
      });
      var s = i(9695);
      Object.defineProperty(e, "TcfClientStopClass", {
        enumerable: !0,
        get: function () {
          return s.TcfClientStopClass;
        },
      }),
        Object.defineProperty(e, "TcfClientStop", {
          enumerable: !0,
          get: function () {
            return s.TcfClientStop;
          },
        });
    },
    9695: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.TcfClientStop = e.TcfClientStopClass = void 0);
      const n = i(4084),
        s = ["gdpr", "gdpr_ca", "gdpr_cc", "gdpr_consent"];
      class r {
        constructor() {
          (this.verifyImpressionId = ""),
            (this.visitImpressionId = ""),
            (this.stopped = !1);
        }
        initialize(t, e, i) {
          if (
            Object.keys(e).some(
              (t) => t !== t.toLowerCase() && s.includes(t.toLowerCase())
            )
          )
            return 3;
          if ("1" !== t.gdpr && "1" !== t.gdpr_ca) return 0;
          const r = (0, n.readDvDisclosure)(t.gdpr_cc || t.gdpr_consent || "");
          return (this.stopped = 2 === r && i), this.stopped ? 4 : r;
        }
        assignVerifyImpressionId(t) {
          this.stopped && (this.verifyImpressionId = t.toLowerCase());
        }
        assignVisitImpressionId(t) {
          this.stopped && (this.visitImpressionId = t.toLowerCase());
        }
        isExecutionStopped() {
          return this.stopped;
        }
        shouldSuppress(t) {
          if (!t) return this.stopped;
          const e = t.toLowerCase();
          return e === this.verifyImpressionId || e === this.visitImpressionId;
        }
        shouldSuppressUrl(t) {
          var e;
          return (
            this.stopped &&
            this.shouldSuppress(
              null === (e = /[?#&]impid=([^&#?]*)/i.exec(t)) || void 0 === e
                ? void 0
                : e[1]
            )
          );
        }
      }
      (e.TcfClientStopClass = r), (e.TcfClientStop = new r());
    },
    6634: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.collectOmidSessionEvents = void 0);
      var n = i(3592);
      Object.defineProperty(e, "collectOmidSessionEvents", {
        enumerable: !0,
        get: function () {
          return n.collectOmidSessionEvents;
        },
      });
    },
    8747: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.collectOmidSessionEvents = void 0);
      const n = i(4112),
        s = i(1360),
        r = i(6783),
        o = i(8480);
      e.collectOmidSessionEvents = (t) => {
        if (!t.isSupported()) return;
        const e = [];
        let i = !1;
        const a = (t) => {
          i ||
            (e.push(t),
            t.type === n.OmidAdEventType.SESSION_FINISH &&
              ((i = !0),
              ((t) => {
                try {
                  const e = (0, r.serializeOmidEvents)(t);
                  if ("" === e) return;
                  s.DiagnosticParamsReporterSingleton.reportDiagnosticParam(
                    s.DiagnosticParams.telemetryOmidEvents,
                    e
                  );
                } catch (t) {}
              })(e)));
        };
        t.registerSessionObserver(a);
        for (const e of Object.values(n.OmidAdEventType)) {
          if (
            e === n.OmidAdEventType.MEDIA ||
            e === n.OmidAdEventType.VIDEO ||
            e === n.OmidAdEventType.SESSION_START ||
            e === n.OmidAdEventType.SESSION_ERROR ||
            e === n.OmidAdEventType.SESSION_FINISH
          )
            continue;
          const i =
            e === n.OmidAdEventType.GEOMETRY_CHANGE
              ? (0, o.throttleGeometryChange)(a)
              : a;
          t.addEventListener(e, i);
        }
      };
    },
    8480: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.throttleGeometryChange = void 0);
      e.throttleGeometryChange = (t) => {
        let e;
        const i = (i) => {
          (e = i.timestamp), t(i);
        };
        return (t) => {
          if (void 0 === e) return void i(t);
          t.timestamp - e >= 100 && i(t);
        };
      };
    },
    3592: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.collectOmidSessionEvents = void 0);
      var n = i(8747);
      Object.defineProperty(e, "collectOmidSessionEvents", {
        enumerable: !0,
        get: function () {
          return n.collectOmidSessionEvents;
        },
      });
    },
    9619: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.serializeOmidAdUserInteractionEvent = void 0);
      const n = i(8944),
        s = i(7879),
        r = [
          (t) =>
            String(
              (0, s.serializeEnumNumber)(
                n.omidInteractionTypeCode,
                t.interactionType
              )
            ),
        ];
      e.serializeOmidAdUserInteractionEvent = (t) =>
        [
          (0, s.serializeEventMetadata)(t.timestamp, t.type),
          (0, s.joinFields)(t.data, r, s.FIELD_DELIMITER),
        ].join(s.FIELD_DELIMITER);
    },
    3716: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.serializeOmidGeometryChangeEvent = void 0);
      const n = i(8944),
        s = i(7879),
        r = (t) => [t.x, t.y, t.width, t.height].join(","),
        o = (t, e) => {
          if (null == t) return s.MISSING_VALUE;
          const i = r(t);
          if (null == e) return `{${i}}`;
          return `{${i},[${e.map((t) => `{${r(t)}}`).join(",")}]}`;
        },
        a = [
          (t) => {
            return `(${(e = t.viewport).width},${e.height})`;
            var e;
          },
          (t) => String(t.adView.percentageInView),
          (t) => {
            return "number" != typeof (e = t.adView.pixelsInView)
              ? s.MISSING_VALUE
              : String(Math.round(100 * e) / 100);
            var e;
          },
          (t) =>
            ((t) => {
              if (null == t) return s.MISSING_VALUE;
              const e = t.reduce(
                (t, e) => (e in n.omidReasonBit ? t | n.omidReasonBit[e] : t),
                0
              );
              return String(e);
            })(t.adView.reasons),
          (t) => o(t.adView.geometry),
          (t) => {
            var e;
            return o(
              t.adView.onScreenGeometry,
              null === (e = t.adView.onScreenGeometry) || void 0 === e
                ? void 0
                : e.obstructions
            );
          },
          (t) => {
            return null == (e = t.adView.onScreenContainerGeometry)
              ? s.MISSING_VALUE
              : `(${r(e)})`;
            var e;
          },
          (t) => (0, s.serializeBoolean)(t.adView.measuringElement),
          (t) => {
            return "number" == typeof (e = t.declaredFriendlyObstructions)
              ? String(e)
              : s.MISSING_VALUE;
            var e;
          },
        ];
      e.serializeOmidGeometryChangeEvent = (t) =>
        [
          (0, s.serializeEventMetadata)(t.timestamp, t.type),
          (0, s.joinFields)(t.data, a, s.FIELD_DELIMITER),
        ].join(s.FIELD_DELIMITER);
    },
    7362: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.serializeOmidImpressionEvent = void 0);
      const n = i(8944),
        s = i(7879),
        r = [
          (t) =>
            String(
              (0, s.serializeEnumNumber)(n.omidMediaTypeCode, t.mediaType)
            ),
          (t) =>
            String(
              (0, s.serializeEnumNumber)(n.omidCreativeTypeCode, t.creativeType)
            ),
          (t) =>
            String(
              (0, s.serializeEnumNumber)(
                n.omidImpressionTypeCode,
                t.impressionType
              )
            ),
          (t) =>
            String(
              (0, s.serializeEnumNumber)(
                n.omidVideoEventAdaptorTypeCode,
                t.videoEventAdaptorType
              )
            ),
        ];
      e.serializeOmidImpressionEvent = (t) =>
        [
          (0, s.serializeEventMetadata)(t.timestamp, t.type),
          (0, s.joinFields)(t.data, r, s.FIELD_DELIMITER),
        ].join(s.FIELD_DELIMITER);
    },
    2132: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.serializeOmidLoadedEvent = void 0);
      const n = i(8944),
        s = i(7879),
        r = [
          (t) => (0, s.serializeBoolean)(t.skippable),
          (t) => (0, s.serializeNumber)(t.skipOffset),
          (t) => (0, s.serializeBoolean)(t.autoPlay),
          (t) =>
            String(
              (0, s.serializeEnumNumber)(n.omidVideoPositionCode, t.position)
            ),
          (t) =>
            String(
              (0, s.serializeEnumNumber)(n.omidMediaTypeCode, t.mediaType)
            ),
          (t) =>
            String(
              (0, s.serializeEnumNumber)(n.omidCreativeTypeCode, t.creativeType)
            ),
          (t) =>
            String(
              (0, s.serializeEnumNumber)(
                n.omidImpressionTypeCode,
                t.impressionType
              )
            ),
        ];
      e.serializeOmidLoadedEvent = (t) =>
        [
          (0, s.serializeEventMetadata)(t.timestamp, t.type),
          (0, s.joinFields)(t.data, r, s.FIELD_DELIMITER),
        ].join(s.FIELD_DELIMITER);
    },
    1432: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.serializeOmidMarkerEvent = void 0);
      const n = i(7879);
      e.serializeOmidMarkerEvent = (t) =>
        (0, n.serializeEventMetadata)(t.timestamp, t.type);
    },
    5030: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.serializeOmidPlayerStateChangeEvent = void 0);
      const n = i(8944),
        s = i(7879),
        r = [
          (t) =>
            String(
              (0, s.serializeEnumNumber)(n.omidVideoPlayerStateCode, t.state)
            ),
        ];
      e.serializeOmidPlayerStateChangeEvent = (t) =>
        [
          (0, s.serializeEventMetadata)(t.timestamp, t.type),
          (0, s.joinFields)(t.data, r, s.FIELD_DELIMITER),
        ].join(s.FIELD_DELIMITER);
    },
    376: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.serializeOmidStartEvent = void 0);
      const n = i(7879),
        s = (t) => ("number" == typeof t ? String(t) : n.MISSING_VALUE),
        r = [
          (t) => String(t.duration),
          (t) => s(t.mediaPlayerVolume),
          (t) => s(t.videoPlayerVolume),
          (t) => s(t.deviceVolume),
        ];
      e.serializeOmidStartEvent = (t) =>
        [
          (0, n.serializeEventMetadata)(t.timestamp, t.type),
          (0, n.joinFields)(t.data, r, n.FIELD_DELIMITER),
        ].join(n.FIELD_DELIMITER);
    },
    2984: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.serializeOmidVolumeChangeEvent = void 0);
      const n = i(7879),
        s = (t) => ("number" == typeof t ? String(t) : n.MISSING_VALUE),
        r = [
          (t) => s(t.mediaPlayerVolume),
          (t) => s(t.videoPlayerVolume),
          (t) => s(t.deviceVolume),
        ];
      e.serializeOmidVolumeChangeEvent = (t) =>
        [
          (0, n.serializeEventMetadata)(t.timestamp, t.type),
          (0, n.joinFields)(t.data, r, n.FIELD_DELIMITER),
        ].join(n.FIELD_DELIMITER);
    },
    8944: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.omidEventCode =
          e.omidReasonBit =
          e.omidVideoPlayerStateCode =
          e.omidSessionOwnerCode =
          e.omidDeviceCategoryCode =
          e.omidAdSessionTypeCode =
          e.omidEnvironmentCode =
          e.omidAccessModeCode =
          e.omidVideoEventAdaptorTypeCode =
          e.omidVideoPositionCode =
          e.omidInteractionTypeCode =
          e.omidErrorTypeCode =
          e.omidImpressionTypeCode =
          e.omidCreativeTypeCode =
          e.omidMediaTypeCode =
            void 0);
      const n = i(4112);
      (e.omidMediaTypeCode = {
        [n.OmidMediaType.DISPLAY]: 0,
        [n.OmidMediaType.VIDEO]: 1,
      }),
        (e.omidCreativeTypeCode = {
          [n.OmidCreativeType.HTML_DISPLAY]: 1,
          [n.OmidCreativeType.NATIVE_DISPLAY]: 2,
          [n.OmidCreativeType.VIDEO]: 3,
          [n.OmidCreativeType.AUDIO]: 4,
        }),
        (e.omidImpressionTypeCode = {
          [n.OmidImpressionType.UNSPECIFIED]: 0,
          [n.OmidImpressionType.LOADED]: 1,
          [n.OmidImpressionType.BEGIN_TO_RENDER]: 2,
          [n.OmidImpressionType.ONE_PIXEL]: 3,
          [n.OmidImpressionType.VIEWABLE]: 4,
          [n.OmidImpressionType.AUDIBLE]: 5,
          [n.OmidImpressionType.OTHER]: 6,
        }),
        (e.omidErrorTypeCode = {
          [n.OmidErrorType.VIDEO]: 1,
          [n.OmidErrorType.GENERIC]: 2,
        }),
        (e.omidInteractionTypeCode = {
          [n.OmidInteractionType.CLICK]: 1,
          [n.OmidInteractionType.INVITATION_ACCEPT]: 2,
        }),
        (e.omidVideoPositionCode = {
          [n.OmidVideoPosition.PREROLL]: 1,
          [n.OmidVideoPosition.MIDROLL]: 2,
          [n.OmidVideoPosition.POSTROLL]: 3,
          [n.OmidVideoPosition.STANDALONE]: 4,
        }),
        (e.omidVideoEventAdaptorTypeCode = { jsCustom: 1, nativeCustom: 2 }),
        (e.omidAccessModeCode = {
          [n.OmidAccessModeString.FULL]: 1,
          [n.OmidAccessModeString.DOMAIN]: 2,
          [n.OmidAccessModeString.LIMITED]: 3,
        }),
        (e.omidEnvironmentCode = { app: 1, web: 2 }),
        (e.omidAdSessionTypeCode = {
          [n.OmidAdSessionType.NATIVE]: 1,
          [n.OmidAdSessionType.HTML]: 2,
          [n.OmidAdSessionType.JAVASCRIPT]: 3,
        }),
        (e.omidDeviceCategoryCode = {
          [n.OmidDeviceCategory.DESKTOP]: 1,
          [n.OmidDeviceCategory.MOBILE]: 2,
          [n.OmidDeviceCategory.CTV]: 3,
          [n.OmidDeviceCategory.OTHER]: 9,
        }),
        (e.omidSessionOwnerCode = {
          [n.OmidSessionOwner.NATIVE]: 1,
          [n.OmidSessionOwner.JAVASCRIPT]: 2,
        }),
        (e.omidVideoPlayerStateCode = {
          [n.OmidVideoPlayerState.MINIMIZED]: 1,
          [n.OmidVideoPlayerState.COLLAPSED]: 2,
          [n.OmidVideoPlayerState.NORMAL]: 3,
          [n.OmidVideoPlayerState.EXPANDED]: 4,
          [n.OmidVideoPlayerState.FULLSCREEN]: 5,
        }),
        (e.omidReasonBit = {
          [n.OmidReason.NOT_FOUND]: 1,
          [n.OmidReason.HIDDEN]: 2,
          [n.OmidReason.BACKGROUNDED]: 4,
          [n.OmidReason.VIEWPORT]: 8,
          [n.OmidReason.OBSTRUCTED]: 16,
          [n.OmidReason.CLIPPED]: 32,
          [n.OmidReason.NO_WINDOW_FOCUS]: 64,
          [n.OmidReason.NO_OUTPUT_DEVICE]: 128,
          [n.OmidReason.UNMEASURABLE]: 256,
          [n.OmidReason.PICTURE_IN_PICTURE]: 512,
          [n.OmidReason.DEVICE_LOCKED]: 1024,
        }),
        (e.omidEventCode = {
          [n.OmidAdEventType.SESSION_START]: "S",
          [n.OmidAdEventType.SESSION_ERROR]: "E",
          [n.OmidAdEventType.SESSION_FINISH]: "F",
          [n.OmidAdEventType.IMPRESSION]: "I",
          [n.OmidAdEventType.LOADED]: "L",
          [n.OmidAdEventType.AD_USER_INTERACTION]: "C",
          [n.OmidAdEventType.GEOMETRY_CHANGE]: "G",
          [n.OmidAdEventType.START]: "T",
          [n.OmidAdEventType.VOLUME_CHANGE]: "V",
          [n.OmidAdEventType.PLAYER_STATE_CHANGE]: "P",
          [n.OmidAdEventType.FIRST_QUARTILE]: "1",
          [n.OmidAdEventType.MIDPOINT]: "2",
          [n.OmidAdEventType.THIRD_QUARTILE]: "3",
          [n.OmidAdEventType.COMPLETE]: "4",
          [n.OmidAdEventType.PAUSE]: "H",
          [n.OmidAdEventType.RESUME]: "R",
          [n.OmidAdEventType.BUFFER_START]: "B",
          [n.OmidAdEventType.BUFFER_FINISH]: "N",
          [n.OmidAdEventType.SKIPPED]: "K",
        });
    },
    6783: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.serializeOmidEvents = e.serializeOmidEvent = void 0);
      const n = i(9619),
        s = i(3716),
        r = i(7362),
        o = i(2132),
        a = i(1432),
        d = i(5030),
        c = i(376),
        l = i(2984),
        u = i(8944),
        h = i(8979),
        v = i(9449),
        p = i(2338),
        m = i(7879);
      e.serializeOmidEvent = (t) =>
        ((t) => new Set(Object.keys(u.omidEventCode)).has(t.type))(t)
          ? ((t) =>
              "sessionStart" === t.type
                ? (0, p.serializeOmidSessionStartEvent)(t)
                : "sessionError" === t.type
                ? (0, h.serializeOmidSessionErrorEvent)(t)
                : "sessionFinish" === t.type
                ? (0, v.serializeOmidSessionFinishEvent)(t)
                : "impression" === t.type
                ? (0, r.serializeOmidImpressionEvent)(t)
                : "loaded" === t.type
                ? (0, o.serializeOmidLoadedEvent)(t)
                : "adUserInteraction" === t.type
                ? (0, n.serializeOmidAdUserInteractionEvent)(t)
                : "geometryChange" === t.type
                ? (0, s.serializeOmidGeometryChangeEvent)(t)
                : "start" === t.type
                ? (0, c.serializeOmidStartEvent)(t)
                : "volumeChange" === t.type
                ? (0, l.serializeOmidVolumeChangeEvent)(t)
                : "playerStateChange" === t.type
                ? (0, d.serializeOmidPlayerStateChangeEvent)(t)
                : (0, a.serializeOmidMarkerEvent)(t))(t)
          : [String(t.timestamp), m.MISSING_VALUE].join(m.FIELD_DELIMITER);
      e.serializeOmidEvents = (t) =>
        t.map(e.serializeOmidEvent).join(m.EVENT_DELIMITER);
    },
    8979: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.serializeOmidSessionErrorEvent = void 0);
      const n = i(8944),
        s = i(7879),
        r = [
          (t) =>
            String(
              (0, s.serializeEnumNumber)(n.omidErrorTypeCode, t.errorType)
            ),
          (t) => (0, s.serializeLongString)(t.message),
        ];
      e.serializeOmidSessionErrorEvent = (t) =>
        [
          (0, s.serializeEventMetadata)(t.timestamp, t.type),
          (0, s.joinFields)(t.data, r, s.FIELD_DELIMITER),
        ].join(s.FIELD_DELIMITER);
    },
    9449: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.serializeOmidSessionFinishEvent = void 0);
      const n = i(7879);
      e.serializeOmidSessionFinishEvent = (t) =>
        (0, n.serializeEventMetadata)(t.timestamp, t.type);
    },
    2338: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.serializeOmidSessionStartEvent = e.serializeSessionStartContext =
          void 0);
      const n = i(8944),
        s = i(7879),
        r = [
          (t) =>
            String(
              (0, s.serializeEnumNumber)(n.omidAccessModeCode, t.accessMode)
            ),
          (t) =>
            String(
              (0, s.serializeEnumNumber)(n.omidEnvironmentCode, t.environment)
            ),
          (t) =>
            String(
              (0, s.serializeEnumNumber)(
                n.omidAdSessionTypeCode,
                t.adSessionType
              )
            ),
          (t) => (0, s.serializeBoolean)(t.friendlyToTop),
          (t) =>
            String(
              (0, s.serializeEnumNumber)(
                n.omidDeviceCategoryCode,
                t.deviceCategory
              )
            ),
          (t) =>
            String(
              (0, s.serializeEnumNumber)(n.omidSessionOwnerCode, t.sessionOwner)
            ),
        ],
        o = [
          (t) => (0, s.serializeLongString)(t.verificationParameters),
          (t) => (0, e.serializeSessionStartContext)(t.context),
          (t) => (0, s.serializeLongString)(t.pageUrl),
          (t) => (0, s.serializeLongString)(t.contentUrl),
          (t) =>
            String(
              (0, s.serializeEnumNumber)(
                n.omidImpressionTypeCode,
                t.impressionType
              )
            ),
          (t) =>
            String(
              (0, s.serializeEnumNumber)(n.omidMediaTypeCode, t.mediaType)
            ),
          (t) =>
            String(
              (0, s.serializeEnumNumber)(n.omidCreativeTypeCode, t.creativeType)
            ),
        ];
      e.serializeSessionStartContext = (t) =>
        (0, s.joinFields)(t, r, s.CONTEXT_DELIMITER);
      e.serializeOmidSessionStartEvent = (t) =>
        [
          (0, s.serializeEventMetadata)(t.timestamp, t.type),
          (0, s.joinFields)(t.data, o, s.FIELD_DELIMITER),
        ].join(s.FIELD_DELIMITER);
    },
    7879: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.serializeLongString =
          e.serializeEventMetadata =
          e.serializeNumber =
          e.serializeEnumString =
          e.serializeEnumNumber =
          e.serializeBoolean =
          e.joinFields =
          e.CONTEXT_DELIMITER =
          e.FIELD_DELIMITER =
          e.EVENT_DELIMITER =
          e.MAX_LENGTH_LONG_STRING =
          e.MISSING_VALUE =
            void 0);
      const n = i(8944);
      (e.MISSING_VALUE = "_"), (e.MAX_LENGTH_LONG_STRING = 150);
      (e.EVENT_DELIMITER = "|"),
        (e.FIELD_DELIMITER = ":"),
        (e.CONTEXT_DELIMITER = ";");
      e.joinFields = (t, e, i) => e.map((e) => e(t)).join(i);
      e.serializeBoolean = (t) => (null == t ? e.MISSING_VALUE : t ? "1" : "0");
      e.serializeEnumNumber = (t, i) => {
        var n;
        return null == i
          ? e.MISSING_VALUE
          : null !== (n = t[i]) && void 0 !== n
          ? n
          : e.MISSING_VALUE;
      };
      e.serializeEnumString = (t, i) => {
        var n;
        return null == i
          ? e.MISSING_VALUE
          : null !== (n = t[i]) && void 0 !== n
          ? n
          : e.MISSING_VALUE;
      };
      e.serializeNumber = (t) => ("number" == typeof t ? String(t) : "");
      e.serializeEventMetadata = (t, i) =>
        [t.toString(), (0, e.serializeEnumString)(n.omidEventCode, i)].join(
          e.FIELD_DELIMITER
        );
      e.serializeLongString = (t) =>
        null == t
          ? e.MISSING_VALUE
          : t.length <= e.MAX_LENGTH_LONG_STRING
          ? encodeURIComponent(t)
          : encodeURIComponent(`${t.slice(0, e.MAX_LENGTH_LONG_STRING)}...`);
    },
    4056: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.toError = void 0);
      e.toError = (t) => {
        if (t instanceof Error) return t;
        switch (typeof t) {
          case "string":
            return new Error(t);
          case "number":
          case "bigint":
          case "boolean":
          case "symbol":
          case "undefined":
            return new Error(String(t));
          case "function":
            return new Error("Function thrown");
          case "object":
            if (null === t) return new Error("null");
            if (
              "undefined" == typeof JSON ||
              "function" != typeof JSON.stringify
            )
              return new Error("Object thrown (JSON unavailable)");
            try {
              return new Error(JSON.stringify(t));
            } catch (t) {
              return new Error("An un-stringifiable object was thrown");
            }
        }
      };
    },
    1906: (t, e, i) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.uninitializedServiceGuard =
          e.toError =
          e.UtilitiesClass =
          e.Utilities =
            void 0);
      var n = i(4443);
      Object.defineProperty(e, "Utilities", {
        enumerable: !0,
        get: function () {
          return n.Utilities;
        },
      }),
        Object.defineProperty(e, "UtilitiesClass", {
          enumerable: !0,
          get: function () {
            return n.UtilitiesClass;
          },
        });
      var s = i(4056);
      Object.defineProperty(e, "toError", {
        enumerable: !0,
        get: function () {
          return s.toError;
        },
      });
      var r = i(2709);
      Object.defineProperty(e, "uninitializedServiceGuard", {
        enumerable: !0,
        get: function () {
          return r.uninitializedServiceGuard;
        },
      });
    },
    2709: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.uninitializedServiceGuard = void 0),
        (e.uninitializedServiceGuard = function (t) {
          return new Proxy(
            {},
            {
              get() {
                throw new Error(
                  `${t} was used before creation. Call initializeRuntimeDependencies() first.`
                );
              },
            }
          );
        });
    },
    4443: (t, e) => {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.Utilities = e.UtilitiesClass = void 0);
      class i {
        constructor() {
          (this.loadTime = this.getCurrentTime()),
            (this.MAX_GET_URL_LENGTH = 8040),
            (this.errorToJSONString = (t) =>
              t instanceof Error
                ? t.message
                : "string" == typeof t
                ? t
                : JSON.stringify(t));
        }
        isExceedingMaxUrlLength(t) {
          return t > this.MAX_GET_URL_LENGTH;
        }
        getScriptLoadedMS() {
          return this.loadTime;
        }
        setLoadVisitTime() {
          this.loadVisitTime = this.getCurrentTime();
        }
        getVersion() {
          return 11365;
        }
        getCurrentTime() {
          return (Date.now || new Date().getTime)();
        }
        getTimeDiff(t) {
          return t || (t = this.getCurrentTime()), Math.abs(t - this.loadTime);
        }
        getVisitTimeDiff() {
          const t = this.getCurrentTime();
          return Math.abs(t - (this.loadVisitTime || t));
        }
        getTimeDiffNoAbs(t) {
          return t || (t = this.getCurrentTime()), t - this.loadTime;
        }
        merge(t, e) {
          if (t && e) return t.concat(e).filter((t, e, i) => i.indexOf(t) == e);
        }
        isEmpty(t) {
          return !t || 0 == Object.keys(t).length;
        }
        isNullOrEmpty(t) {
          return null == t || "" === t;
        }
        extend(t, e) {
          t &&
            !this.isEmpty(t) &&
            e &&
            Object.keys(t).forEach((i) => (e[i] = t[i]));
        }
        times(t, e) {
          t > 0 && (e(), this.times(t - 1, e));
        }
        mapData(t, e, i = !1) {
          return Object.keys(e).reduce((n, s) => {
            const r = e[s];
            return (
              r &&
                !this.isNullOrEmpty(t[s]) &&
                ((n[r] = t[s]), i && delete e[s]),
              n
            );
          }, {});
        }
        startsWith(t, e, i = !1) {
          return (
            (t = i ? t.toLowerCase() : t),
            (e = i ? e.toLowerCase() : e),
            0 == t.indexOf(e, 0)
          );
        }
        deepComparison(t, e, i) {
          let n = 0;
          return t && e
            ? (Object.keys(i)
                .filter((i) => !this.equal(t[i], e[i], !0))
                .forEach((t) => {
                  n |= i[t];
                }),
              n)
            : -1;
        }
        removeDuplicateValues(t, e) {
          t &&
            e &&
            Object.keys(t)
              .filter((i) => this.isNullOrEmpty(t[i]) || t[i] == e[i])
              .forEach((e) => delete t[e]);
        }
        equal(t, e, i = !1) {
          return (
            (t =
              (i && (null == t ? void 0 : t.toString().toLowerCase())) || t) ==
              (e =
                (i && (null == e ? void 0 : e.toString().toLowerCase())) ||
                e) ||
            (this.isNullOrEmpty(t) && this.isNullOrEmpty(e))
          );
        }
        resolveMacros(t, e) {
          const i = Object.keys(e).reduce(
            (t, i) => ((t[i.toUpperCase()] = e[i]), t),
            {}
          );
          return this.resolveConsentMacros(t, i.GDPR, i.GDPR_CONSENT)
            .replace("[DV_PROTOCOL]", i.DV_PROTOCOL)
            .replace("[PROTOCOL]", i.PROTOCOL)
            .replace(/\[(.*?)\]/g, (t, e) => {
              let n = i[e];
              return e.indexOf("URL") > -1 && n
                ? decodeURIComponent(n)
                : (null == n && (n = "[" + e + "]"), encodeURIComponent(n));
            });
        }
        resolveConsentMacros(t, e, i) {
          return t
            .replace(/\$\{GDPR\}/g, encodeURIComponent(null != e ? e : ""))
            .replace(
              /\$\{GDPR_CONSENT_[1-9]\d*\}/g,
              encodeURIComponent(null != i ? i : "")
            );
        }
        updateDynamicParamsFlags(t, e) {
          t && t.length > 0 && e && (e.dvf = t.filter((t) => !!t).join(","));
        }
        getQueryString(t, i, n, s) {
          const r = e.Utilities.mapData(t, s);
          return (
            e.Utilities.extend(i, r),
            this.updateDynamicParamsFlags(n, r),
            this.serializeObjectToQueryString(r, !1)
          );
        }
        serializeObjectToQueryString(t, e) {
          return Object.keys(t)
            .filter((e) => void 0 !== t[e])
            .map((i) => `${i}=${e ? encodeURIComponent(t[i]) : t[i]}`)
            .join("&")
            .trim();
        }
        isQueryLengthBelowBrowserLimit(t, e, i, n, s) {
          let r = !0;
          try {
            r = this.getQueryString(t, e, i, n).length + s.length <= 7e3;
          } catch (t) {}
          return r;
        }
        arrayLikeToArray(t) {
          if (t) return Array.prototype.slice.call(t);
        }
        DOMStringListToArray(t) {
          let e = [];
          return t && (e = Array.prototype.slice.call(t)), e;
        }
        isHostTypeURL(t) {
          try {
            const e = new URL(t);
            return this.isNullOrEmpty(e.pathname) || "/" == e.pathname;
          } catch (t) {}
        }
        isPercentageCriteriaPassed(t) {
          return !(null == t || t > 100 || t < 0) && 100 * Math.random() <= t;
        }
        getValBetweenMinAndMax(t, e, i) {
          return t > e ? (t < i ? t : i) : e;
        }
        isEmptyObject(t) {
          return 0 === Object.keys(t).length;
        }
        objectValues(t) {
          return Object.keys(t).map((e) => t[e]);
        }
        getParamValue(t, e) {
          if (null != t) {
            const i = new RegExp("[\\?#&](" + e + ")=([^&#?]*)", "gi").exec(t);
            if (null != (null == i ? void 0 : i[2])) return i[2];
          }
          return null;
        }
        checkIfObjIsPartiallyInArray(t, e) {
          return e.filter((e) => {
            let i = !0;
            return (
              Object.keys(t).forEach((n) => {
                i && (i = e[n] === t[n]);
              }),
              i
            );
          }).length > 0
            ? t
            : {};
        }
        getRandom() {
          let t = 1;
          const e = Math.floor(10 * Math.random()) + 1;
          for (let i = 0; i < e; ++i) t *= Math.random();
          return t;
        }
        generateGuid() {
          return new Date().getTime() * this.getRandom() + "";
        }
        isNumber(t) {
          return "number" == typeof t && isFinite(t);
        }
        isNumeric(t) {
          return !isNaN(Number(t));
        }
        convertToArray(t) {
          return t && t.length > 0 ? Array.prototype.slice.call(t) : [];
        }
        countBy(t) {
          const e = {};
          return (
            t.forEach((t) => {
              e[t] = e[t] ? e[t] + 1 : 1;
            }),
            e
          );
        }
        getKeyWithHighestValue(t) {
          return Object.keys(t).length > 0
            ? Object.keys(t).reduce((e, i) => (t[e] > t[i] ? e : i))
            : null;
        }
        pick(t, e) {
          const i = {};
          return (
            e.forEach((e) => {
              i[e] = t[e];
            }),
            i
          );
        }
        sumBuckets(t) {
          return t.reduce((t, e) => t + (null != e ? e : 0), 0);
        }
        generateUUID() {
          if (
            "object" == typeof crypto &&
            "function" == typeof crypto.randomUUID
          )
            return crypto.randomUUID();
          let t = new Date().getTime(),
            e =
              "undefined" != typeof performance &&
              "function" == typeof performance.now
                ? 1e3 * performance.now()
                : 0;
          return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
            /[xy]/g,
            function (i) {
              let n = 16 * Math.random();
              return (
                t > 0
                  ? ((n = (t + n) % 16 | 0), (t = Math.floor(t / 16)))
                  : ((n = (e + n) % 16 | 0), (e = Math.floor(e / 16))),
                ("x" === i ? n : (3 & n) | 8).toString(16)
              );
            }
          );
        }
      }
      (e.UtilitiesClass = i), (e.Utilities = new i());
    },
    8395: function (t, e, i) {
      !(function (t, e, i) {
        if ("object" == typeof i && "string" != typeof i.nodeName) e(t, i);
        else {
          i = {};
          var n = ["1.6.3-iab357"];
          function s(t) {
            for (var e in t) t.hasOwnProperty(e) && (t[e] = s(t[e]));
            return Object.freeze(t);
          }
          for (var r in (e(t, i), i))
            i.hasOwnProperty(r) &&
              (null == Object.getOwnPropertyDescriptor(t, r) &&
                Object.defineProperty(t, r, { value: {} }),
              n.forEach(function (e) {
                if (null == Object.getOwnPropertyDescriptor(t[r], e)) {
                  var n = s(i[r]);
                  Object.defineProperty(t[r], e, {
                    get: function () {
                      return n;
                    },
                    enumerable: !0,
                  });
                }
              }));
        }
      })(
        void 0 === i.g ? this : i.g,
        function (t, e) {
          var n = n || {};
          (n.scope = {}),
            (n.createTemplateTagFirstArg = function (t) {
              return (t.raw = t);
            }),
            (n.createTemplateTagFirstArgWithRaw = function (t, e) {
              return (t.raw = e), t;
            }),
            (n.arrayIteratorImpl = function (t) {
              var e = 0;
              return function () {
                return e < t.length
                  ? { done: !1, value: t[e++] }
                  : { done: !0 };
              };
            }),
            (n.arrayIterator = function (t) {
              return { next: n.arrayIteratorImpl(t) };
            }),
            (n.makeIterator = function (t) {
              var e =
                "undefined" != typeof Symbol &&
                Symbol.iterator &&
                t[Symbol.iterator];
              if (e) return e.call(t);
              if ("number" == typeof t.length) return n.arrayIterator(t);
              throw Error(String(t) + " is not an iterable or ArrayLike");
            }),
            (n.arrayFromIterator = function (t) {
              for (var e, i = []; !(e = t.next()).done; ) i.push(e.value);
              return i;
            }),
            (n.arrayFromIterable = function (t) {
              return t instanceof Array
                ? t
                : n.arrayFromIterator(n.makeIterator(t));
            }),
            (n.ASSUME_ES5 = !1),
            (n.ASSUME_NO_NATIVE_MAP = !1),
            (n.ASSUME_NO_NATIVE_SET = !1),
            (n.SIMPLE_FROUND_POLYFILL = !1),
            (n.ISOLATE_POLYFILLS = !1),
            (n.FORCE_POLYFILL_PROMISE = !1),
            (n.FORCE_POLYFILL_PROMISE_WHEN_NO_UNHANDLED_REJECTION = !1),
            (n.objectCreate =
              n.ASSUME_ES5 || "function" == typeof Object.create
                ? Object.create
                : function (t) {
                    var e = function () {};
                    return (e.prototype = t), new e();
                  }),
            (n.defineProperty =
              n.ASSUME_ES5 || "function" == typeof Object.defineProperties
                ? Object.defineProperty
                : function (t, e, i) {
                    return (
                      t == Array.prototype ||
                        t == Object.prototype ||
                        (t[e] = i.value),
                      t
                    );
                  }),
            (n.getGlobal = function (t) {
              t = [
                "object" == typeof globalThis && globalThis,
                t,
                "object" == typeof window && window,
                "object" == typeof self && self,
                "object" == typeof i.g && i.g,
              ];
              for (var e = 0; e < t.length; ++e) {
                var n = t[e];
                if (n && n.Math == Math) return n;
              }
              throw Error("Cannot find global object");
            }),
            (n.global = n.getGlobal(this)),
            (n.IS_SYMBOL_NATIVE =
              "function" == typeof Symbol && "symbol" == typeof Symbol("x")),
            (n.TRUST_ES6_POLYFILLS =
              !n.ISOLATE_POLYFILLS || n.IS_SYMBOL_NATIVE),
            (n.polyfills = {}),
            (n.propertyToPolyfillSymbol = {}),
            (n.POLYFILL_PREFIX = "$jscp$");
          var s = function (t, e, i) {
            if (!i || null != t)
              return null == (i = n.propertyToPolyfillSymbol[e])
                ? t[e]
                : void 0 !== (i = t[i])
                ? i
                : t[e];
          };
          (n.polyfill = function (t, e, i, s) {
            e &&
              (n.ISOLATE_POLYFILLS
                ? n.polyfillIsolated(t, e, i, s)
                : n.polyfillUnisolated(t, e, i, s));
          }),
            (n.polyfillUnisolated = function (t, e, i, s) {
              for (
                i = n.global, t = t.split("."), s = 0;
                s < t.length - 1;
                s++
              ) {
                var r = t[s];
                if (!(r in i)) return;
                i = i[r];
              }
              (e = e((s = i[(t = t[t.length - 1])]))) != s &&
                null != e &&
                n.defineProperty(i, t, {
                  configurable: !0,
                  writable: !0,
                  value: e,
                });
            }),
            (n.polyfillIsolated = function (t, e, i, s) {
              var r = t.split(".");
              (t = 1 === r.length),
                (s = r[0]),
                (s = !t && s in n.polyfills ? n.polyfills : n.global);
              for (var o = 0; o < r.length - 1; o++) {
                var a = r[o];
                if (!(a in s)) return;
                s = s[a];
              }
              (r = r[r.length - 1]),
                null !=
                  (e = e(
                    (i = n.IS_SYMBOL_NATIVE && "es6" === i ? s[r] : null)
                  )) &&
                  (t
                    ? n.defineProperty(n.polyfills, r, {
                        configurable: !0,
                        writable: !0,
                        value: e,
                      })
                    : e !== i &&
                      (void 0 === n.propertyToPolyfillSymbol[r] &&
                        ((i = (1e9 * Math.random()) >>> 0),
                        (n.propertyToPolyfillSymbol[r] = n.IS_SYMBOL_NATIVE
                          ? n.global.Symbol(r)
                          : n.POLYFILL_PREFIX + i + "$" + r)),
                      n.defineProperty(s, n.propertyToPolyfillSymbol[r], {
                        configurable: !0,
                        writable: !0,
                        value: e,
                      })));
            }),
            (n.getConstructImplementation = function () {
              if (
                n.TRUST_ES6_POLYFILLS &&
                "undefined" != typeof Reflect &&
                Reflect.construct
              ) {
                if (
                  (function () {
                    function t() {}
                    return (
                      new t(),
                      Reflect.construct(t, [], function () {}),
                      new t() instanceof t
                    );
                  })()
                )
                  return Reflect.construct;
                var t = Reflect.construct;
                return function (e, i, n) {
                  return (
                    (e = t(e, i)),
                    n && Reflect.setPrototypeOf(e, n.prototype),
                    e
                  );
                };
              }
              return function (t, e, i) {
                return (
                  void 0 === i && (i = t),
                  (i = n.objectCreate(i.prototype || Object.prototype)),
                  Function.prototype.apply.call(t, i, e) || i
                );
              };
            }),
            (n.construct = n.getConstructImplementation()),
            (n.underscoreProtoCanBeSet = function () {
              var t = {};
              try {
                return (t.__proto__ = { a: !0 }), t.a;
              } catch (t) {}
              return !1;
            }),
            (n.setPrototypeOf =
              n.TRUST_ES6_POLYFILLS &&
              "function" == typeof Object.setPrototypeOf
                ? Object.setPrototypeOf
                : n.underscoreProtoCanBeSet()
                ? function (t, e) {
                    if (((t.__proto__ = e), t.__proto__ !== e))
                      throw new TypeError(t + " is not extensible");
                    return t;
                  }
                : null),
            (n.inherits = function (t, e) {
              if (
                ((t.prototype = n.objectCreate(e.prototype)),
                (t.prototype.constructor = t),
                n.setPrototypeOf)
              ) {
                var i = n.setPrototypeOf;
                i(t, e);
              } else
                for (i in e)
                  if ("prototype" != i)
                    if (Object.defineProperties) {
                      var s = Object.getOwnPropertyDescriptor(e, i);
                      s && Object.defineProperty(t, i, s);
                    } else t[i] = e[i];
              t.superClass_ = e.prototype;
            }),
            (n.getRestArguments = function () {
              for (
                var t = Number(this), e = [], i = t;
                i < arguments.length;
                i++
              )
                e[i - t] = arguments[i];
              return e;
            }),
            n.polyfill(
              "Reflect",
              function (t) {
                return t || {};
              },
              "es6",
              "es3"
            ),
            n.polyfill(
              "Reflect.construct",
              function (t) {
                return n.construct;
              },
              "es6",
              "es3"
            ),
            n.polyfill(
              "Reflect.setPrototypeOf",
              function (t) {
                if (t) return t;
                if (n.setPrototypeOf) {
                  var e = n.setPrototypeOf;
                  return function (t, i) {
                    try {
                      return e(t, i), !0;
                    } catch (t) {
                      return !1;
                    }
                  };
                }
                return null;
              },
              "es6",
              "es5"
            ),
            (n.checkStringArgs = function (t, e, i) {
              if (null == t)
                throw new TypeError(
                  "The 'this' value for String.prototype." +
                    i +
                    " must not be null or undefined"
                );
              if (e instanceof RegExp)
                throw new TypeError(
                  "First argument to String.prototype." +
                    i +
                    " must not be a regular expression"
                );
              return t + "";
            }),
            n.polyfill(
              "String.prototype.repeat",
              function (t) {
                return (
                  t ||
                  function (t) {
                    var e = n.checkStringArgs(this, null, "repeat");
                    if (0 > t || 1342177279 < t)
                      throw new RangeError("Invalid count value");
                    t |= 0;
                    for (var i = ""; t; )
                      1 & t && (i += e), (t >>>= 1) && (e += e);
                    return i;
                  }
                );
              },
              "es6",
              "es3"
            ),
            (n.stringPadding = function (t, e) {
              return (
                (t = void 0 !== t ? String(t) : " "),
                0 < e && t
                  ? t.repeat(Math.ceil(e / t.length)).substring(0, e)
                  : ""
              );
            }),
            n.polyfill(
              "String.prototype.padStart",
              function (t) {
                return (
                  t ||
                  function (t, e) {
                    var i = n.checkStringArgs(this, null, "padStart");
                    return n.stringPadding(e, t - i.length) + i;
                  }
                );
              },
              "es8",
              "es3"
            ),
            (n.owns = function (t, e) {
              return Object.prototype.hasOwnProperty.call(t, e);
            }),
            n.polyfill(
              "Object.values",
              function (t) {
                return (
                  t ||
                  function (t) {
                    var e,
                      i = [];
                    for (e in t) n.owns(t, e) && i.push(t[e]);
                    return i;
                  }
                );
              },
              "es8",
              "es3"
            );
          var r = "omid_message_guid",
            o = "omid_message_method",
            a = "omid_message_version",
            d = "omid_message_args",
            c = function (t, e, i, n) {
              (this.guid = t),
                (this.method = e),
                (this.version = i),
                (this.args = n);
            };
          (c.isValidSerializedMessage = function (t) {
            return (
              !!t &&
              void 0 !== t[r] &&
              void 0 !== t[o] &&
              void 0 !== t[a] &&
              "string" == typeof t[r] &&
              "string" == typeof t[o] &&
              "string" == typeof t[a] &&
              (void 0 === t[d] || void 0 !== t[d])
            );
          }),
            (c.deserialize = function (t) {
              return new c(t[r], t[o], t[a], t[d]);
            }),
            (c.prototype.serialize = function () {
              var t = {};
              return (
                (t[r] = this.guid),
                (t[o] = this.method),
                (t[a] = this.version),
                void 0 !== this.args && (t[d] = this.args),
                t
              );
            });
          var l = {
              AdEventType: {
                IMPRESSION: "impression",
                LOADED: "loaded",
                GEOMETRY_CHANGE: "geometryChange",
                SESSION_START: "sessionStart",
                SESSION_ERROR: "sessionError",
                SESSION_FINISH: "sessionFinish",
                MEDIA: "media",
                VIDEO: "video",
                START: "start",
                FIRST_QUARTILE: "firstQuartile",
                MIDPOINT: "midpoint",
                THIRD_QUARTILE: "thirdQuartile",
                COMPLETE: "complete",
                PAUSE: "pause",
                RESUME: "resume",
                BUFFER_START: "bufferStart",
                BUFFER_FINISH: "bufferFinish",
                SKIPPED: "skipped",
                VOLUME_CHANGE: "volumeChange",
                PLAYER_STATE_CHANGE: "playerStateChange",
                AD_USER_INTERACTION: "adUserInteraction",
                STATE_CHANGE: "stateChange",
              },
              MediaEventType: {
                LOADED: "loaded",
                START: "start",
                FIRST_QUARTILE: "firstQuartile",
                MIDPOINT: "midpoint",
                THIRD_QUARTILE: "thirdQuartile",
                COMPLETE: "complete",
                PAUSE: "pause",
                RESUME: "resume",
                BUFFER_START: "bufferStart",
                BUFFER_FINISH: "bufferFinish",
                SKIPPED: "skipped",
                VOLUME_CHANGE: "volumeChange",
                PLAYER_STATE_CHANGE: "playerStateChange",
                AD_USER_INTERACTION: "adUserInteraction",
              },
              ImpressionType: {
                DEFINED_BY_JAVASCRIPT: "definedByJavaScript",
                UNSPECIFIED: "unspecified",
                LOADED: "loaded",
                BEGIN_TO_RENDER: "beginToRender",
                ONE_PIXEL: "onePixel",
                VIEWABLE: "viewable",
                AUDIBLE: "audible",
                OTHER: "other",
              },
              ErrorType: { GENERIC: "generic", VIDEO: "video", MEDIA: "media" },
              AdSessionType: {
                NATIVE: "native",
                HTML: "html",
                JAVASCRIPT: "javascript",
              },
              EventOwner: {
                NATIVE: "native",
                JAVASCRIPT: "javascript",
                NONE: "none",
              },
              SessionOwner: { JAVASCRIPT: "javascript", NATIVE: "native" },
              AccessMode: {
                FULL: "full",
                DOMAIN: "domain",
                LIMITED: "limited",
              },
              AppState: {
                BACKGROUNDED: "backgrounded",
                FOREGROUNDED: "foregrounded",
              },
              DeviceLockState: { LOCKED: "locked", UNLOCKED: "unlocked" },
              Environment: { APP: "app", WEB: "web" },
              DeviceCategory: {
                CTV: "ctv",
                DESKTOP: "desktop",
                MOBILE: "mobile",
                OTHER: "other",
              },
              InteractionType: {
                CLICK: "click",
                INVITATION_ACCEPT: "invitationAccept",
              },
              CreativeType: {
                DEFINED_BY_JAVASCRIPT: "definedByJavaScript",
                HTML_DISPLAY: "htmlDisplay",
                NATIVE_DISPLAY: "nativeDisplay",
                VIDEO: "video",
                AUDIO: "audio",
              },
              MediaType: { DISPLAY: "display", VIDEO: "video" },
              Reason: {
                NOT_FOUND: "notFound",
                HIDDEN: "hidden",
                BACKGROUNDED: "backgrounded",
                PICTURE_IN_PICTURE: "pictureInPicture",
                DEVICE_LOCKED: "deviceLocked",
                VIEWPORT: "viewport",
                OBSTRUCTED: "obstructed",
                CLIPPED: "clipped",
                UNMEASURABLE: "unmeasurable",
                NO_WINDOW_FOCUS: "noWindowFocus",
                NO_OUTPUT_DEVICE: "noOutputDevice",
              },
              SupportedFeatures: { CONTAINER: "clid", VIDEO: "vlid" },
              VideoPosition: {
                PREROLL: "preroll",
                MIDROLL: "midroll",
                POSTROLL: "postroll",
                STANDALONE: "standalone",
              },
              VideoPlayerState: {
                MINIMIZED: "minimized",
                COLLAPSED: "collapsed",
                NORMAL: "normal",
                EXPANDED: "expanded",
                FULLSCREEN: "fullscreen",
              },
              NativeViewKeys: {
                X: "x",
                LEFT: "left",
                Y: "y",
                TOP: "top",
                WIDTH: "width",
                HEIGHT: "height",
                AD_SESSION_ID: "adSessionId",
                IS_FRIENDLY_OBSTRUCTION_FOR: "isFriendlyObstructionFor",
                CLIPS_TO_BOUNDS: "clipsToBounds",
                CHILD_VIEWS: "childViews",
                END_X: "endX",
                END_Y: "endY",
                OBSTRUCTIONS: "obstructions",
                OBSTRUCTION_CLASS: "obstructionClass",
                OBSTRUCTION_PURPOSE: "obstructionPurpose",
                OBSTRUCTION_REASON: "obstructionReason",
                PIXELS: "pixels",
                HAS_WINDOW_FOCUS: "hasWindowFocus",
              },
              MeasurementStateChangeSource: {
                CONTAINER: "container",
                CREATIVE: "creative",
              },
              ElementMarkup: { OMID_ELEMENT_CLASS_NAME: "omid-element" },
              CommunicationType: {
                NONE: "NONE",
                DIRECT: "DIRECT",
                POST_MESSAGE: "POST_MESSAGE",
              },
              OmidImplementer: { OMSDK: "omsdk" },
              MessageMethod: {
                IDENTIFY_SERVICE_WINDOW: "identifyServiceWindow",
              },
            },
            u = function (t) {
              (this.to = t),
                (this.communicationType_ = l.CommunicationType.NONE);
            };
          (u.prototype.sendMessage = function (t, e) {}),
            (u.prototype.handleMessage = function (t, e) {
              this.onMessage && this.onMessage(t, e);
            }),
            (u.prototype.serialize = function (t) {
              return JSON.stringify(t);
            }),
            (u.prototype.deserialize = function (t) {
              return JSON.parse(t);
            }),
            (u.prototype.isDirectCommunication = function () {
              return this.communicationType_ === l.CommunicationType.DIRECT;
            }),
            (u.prototype.isCrossOrigin = function () {});
          var h = {};
          function v() {
            var t = n.getRestArguments.apply(0, arguments);
            m(
              function () {
                throw new (Function.prototype.bind.apply(
                  Error,
                  [null, "Could not complete the test successfully - "].concat(
                    n.arrayFromIterable(t)
                  )
                ))();
              },
              function () {
                return console.error.apply(console, n.arrayFromIterable(t));
              }
            );
          }
          function p() {
            var t = n.getRestArguments.apply(0, arguments);
            m(
              function () {},
              function () {
                return console.error.apply(console, n.arrayFromIterable(t));
              }
            );
          }
          function m(t, e) {
            "undefined" != typeof jasmine && jasmine
              ? t()
              : "undefined" != typeof console &&
                console &&
                console.error &&
                e();
          }
          (h.error = v), (h.debug = p);
          var f = {},
            g,
            b = { ApiVersion: "1.0", Version: "1.6.3-iab357" },
            w = {};
          function _(t, e) {
            if (!e)
              throw Error("Value for " + t + " is undefined, null or blank.");
            if ("string" != typeof e && !(e instanceof String))
              throw Error("Value for " + t + " is not a string.");
            if ("" === e.trim())
              throw Error("Value for " + t + " is empty string.");
          }
          function y(t, e) {
            if (null == e)
              throw Error("Value for " + t + " is undefined or null");
          }
          function S(t, e) {
            if (null == e) throw Error(t + " must not be null or undefined.");
            if ("number" != typeof e || isNaN(e))
              throw Error("Value for " + t + " is not a number");
          }
          function M(t, e, i, n) {
            if ((S(t, e), e < i || e > n))
              throw Error(
                "Value for " + t + " is outside the range [" + i + "," + n + "]"
              );
          }
          function O(t, e) {
            if (!e) throw Error(t + " must not be truthy.");
          }
          function E(t, e) {
            if ((S(t, e), 0 > e))
              throw Error(t + " must be a positive number.");
          }
          (w.assertTruthyString = _),
            (w.assertNotNullObject = y),
            (w.assertNumber = S),
            (w.assertNumberBetween = M),
            (w.assertFunction = O),
            (w.assertPositiveNumber = E);
          var A = {},
            T = 3;
          function I(t) {
            return /\d+\.\d+\.\d+(-.*)?/.test(t);
          }
          function C(t, e) {
            (t = t.split("-")[0].split(".")), (e = e.split("-")[0].split("."));
            for (var i = 0; i < T; i++) {
              var n = parseInt(t[i], 10),
                s = parseInt(e[i], 10);
              if (n > s) break;
              if (n < s) return !1;
            }
            return !0;
          }
          (A.isValidVersion = I), (A.versionGreaterOrEqual = C);
          var D = {},
            j = "1.0.3";
          function V(t, e) {
            return I(t) && C(t, j) ? e : JSON.stringify(e);
          }
          function R(t, e) {
            return I(t) && C(t, j)
              ? e || []
              : e && "string" == typeof e
              ? JSON.parse(e)
              : [];
          }
          (D.serializeMessageArgs = V), (D.deserializeMessageArgs = R);
          var x = {};
          function P() {
            return (
              "undefined" != typeof crypto &&
              "function" == typeof crypto.getRandomValues
            );
          }
          function k() {
            return P() ? N() : L();
          }
          function N() {
            var t = new Uint8Array(16);
            crypto.getRandomValues(t),
              (t[6] = (15 & t[6]) | 64),
              (t[8] = (63 & t[8]) | 128);
            for (var e = [], i = 0; 16 > i; i++)
              e.push(t[i].toString(16).padStart(2, "0"));
            return (
              e[0] +
              e[1] +
              e[2] +
              e[3] +
              "-" +
              e[4] +
              e[5] +
              "-" +
              e[6] +
              e[7] +
              "-" +
              e[8] +
              e[9] +
              "-" +
              e[10] +
              e[11] +
              e[12] +
              e[13] +
              e[14] +
              e[15]
            );
          }
          function L() {
            return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
              /[xy]/g,
              function (t) {
                var e = (16 * Math.random()) | 0;
                return (t =
                  "y" === t ? ((3 & e) | 8).toString(16) : e.toString(16));
              }
            );
          }
          (x.generateGuid = k),
            (x.generateSecureGuid = N),
            (x.generateFallbackGuid = L),
            (x.isCryptoAvailable = P);
          var F = {
            OMID_PRESENT_FRAME_NAME: "omid_v1_present",
            OMID_PRESENT_FRAME_NAME_WEB: "omid_v1_present_web",
            OMID_PRESENT_FRAME_NAME_APP: "omid_v1_present_app",
            getEnvironmentIframeName: function (t) {
              var e = {};
              return ((e[l.Environment.APP] = F.OMID_PRESENT_FRAME_NAME_APP),
              (e[l.Environment.WEB] = F.OMID_PRESENT_FRAME_NAME_WEB),
              e)[t];
            },
          };
          function U(t, e) {
            try {
              return t.frames && !!t.frames[e];
            } catch (t) {
              return !1;
            }
          }
          function B(t, e) {
            t.document.write(
              '<iframe style="display:none" id="' +
                e +
                '" name="' +
                e +
                '" sandbox></iframe>'
            );
          }
          (F.isOmidPresent = function (t) {
            return [
              F.OMID_PRESENT_FRAME_NAME,
              F.OMID_PRESENT_FRAME_NAME_WEB,
              F.OMID_PRESENT_FRAME_NAME_APP,
            ].some(function (e) {
              return U(t, e);
            });
          }),
            (F.getOmidEnvironment = function (t) {
              for (
                var e = n.makeIterator(Object.values(l.Environment)),
                  i = e.next();
                !i.done;
                i = e.next()
              ) {
                if (((i = i.value), U(t, F.getEnvironmentIframeName(i))))
                  return i;
              }
              return null;
            }),
            (F.declareOmidPresence = function (t, e) {
              t.frames &&
                t.document &&
                ![
                  F.OMID_PRESENT_FRAME_NAME,
                  F.OMID_PRESENT_FRAME_NAME_WEB,
                  F.OMID_PRESENT_FRAME_NAME_APP,
                ].some(function (e) {
                  return !!t.frames[e];
                }) &&
                (null == t.document.body && F.isMutationObserverAvailable_(t)
                  ? F.registerMutationObserver_(t, e)
                  : ((e = F.getEnvironmentIframeName(e)),
                    t.document.body
                      ? (F.appendPresenceIframe_(t, F.OMID_PRESENT_FRAME_NAME),
                        F.appendPresenceIframe_(t, e))
                      : (B(t, F.OMID_PRESENT_FRAME_NAME), B(t, e))));
            }),
            (F.appendPresenceIframe_ = function (t, e) {
              var i = t.document.createElement("iframe");
              (i.id = e),
                (i.name = e),
                (i.style.display = "none"),
                (i.sandbox = ""),
                t.document.body.appendChild(i);
            }),
            (F.isMutationObserverAvailable_ = function (t) {
              return "MutationObserver" in t;
            }),
            (F.registerMutationObserver_ = function (t, e) {
              var i = new MutationObserver(function (n) {
                n.forEach(function (n) {
                  "BODY" === n.addedNodes[0].nodeName &&
                    ((n = F.getEnvironmentIframeName(e)),
                    F.appendPresenceIframe_(t, F.OMID_PRESENT_FRAME_NAME),
                    F.appendPresenceIframe_(t, n),
                    i.disconnect());
                });
              });
              i.observe(t.document.documentElement, { childList: !0 });
            });
          var z = {},
            W = {
              SESSION_SERVICE: "SessionService.",
              VERIFICATION_SERVICE: "VerificationService.",
            };
          function q(t) {
            return Q(t, W.SESSION_SERVICE);
          }
          function $(t) {
            return Y(t, W.SESSION_SERVICE);
          }
          function H(t) {
            return null != $(t);
          }
          function G(t) {
            return Q(t, W.VERIFICATION_SERVICE);
          }
          function J(t) {
            return Y(t, W.VERIFICATION_SERVICE);
          }
          function K(t) {
            return null != J(t);
          }
          function Q(t, e) {
            return e + t;
          }
          function Y(t, e) {
            return (t = t.match(new RegExp("^" + e + "(.*)"))) && t[1];
          }
          (z.getPrefixedSessionServiceMethod = q),
            (z.getPrefixedVerificationServiceMethod = G),
            (z.getUnprefixedSessionServiceMethod = $),
            (z.getUnprefixedVerificationServiceMethod = J),
            (z.isPrefixedSessionServiceMethod = H),
            (z.isPrefixedVerificationServiceMethod = K);
          var X = {};
          function Z() {
            if (void 0 !== t && t) return t;
            if (void 0 !== i.g && i.g) return i.g;
            if ("undefined" != typeof window && window) return window;
            if ("undefined" != typeof globalThis && globalThis)
              return globalThis;
            var e = Function("return this")();
            if (e) return e;
            throw Error("Could not determine global object context.");
          }
          X.omidGlobal = Z();
          var tt = {};
          function et() {
            return void 0 === e ? null : e;
          }
          function it(t, e) {
            return t && (t[e] || (t[e] = {}));
          }
          function nt(t, e, i) {
            (i = void 0 === i ? et() : i) &&
              ((t = t.split(".")).slice(0, t.length - 1).reduce(it, i)[
                t[t.length - 1]
              ] = e);
          }
          tt.packageExport = nt;
          var st = {};
          function rt(t) {
            return null != t && void 0 !== t.top && null != t.top;
          }
          function ot(t) {
            if (t === X.omidGlobal) return !1;
            try {
              if (void 0 === t.location.hostname) return !0;
              at(t);
            } catch (t) {
              return !0;
            }
            return !1;
          }
          function at(t) {
            return "" === t.x || "" !== t.x;
          }
          function dt(t) {
            return (
              void 0 === t &&
                "undefined" != typeof window &&
                window &&
                (t = window),
              rt(t) ? t : X.omidGlobal
            );
          }
          function ct(t) {
            return rt(t) ? t.top : X.omidGlobal;
          }
          function lt(t) {
            try {
              return !!t.top.location.href;
            } catch (t) {
              return !1;
            }
          }
          function ut(t) {
            return (
              t.type === l.AdEventType.SESSION_START &&
                (void 0 !== t.data.context.videoElement &&
                  (t.data.context.videoElement =
                    "Video Element (" + t.data.context.videoElement.id + ")"),
                void 0 !== t.data.context.slotElement &&
                  (t.data.context.slotElement =
                    "Slot Element (" + t.data.context.slotElement.id + ")")),
              t
            );
          }
          function ht(t) {
            if (!rt(t)) return null;
            try {
              var e = t.top;
              return ot(e) ? null : e.location.href;
            } catch (t) {
              return null;
            }
          }
          (st.evaluatePageUrl = ht),
            (st.isCrossOrigin = ot),
            (st.removeDomElements = ut),
            (st.resolveGlobalContext = dt),
            (st.resolveTopWindowContext = ct),
            (st.isTopWindowAccessible = lt);
          var vt = function (t) {
            u.call(this, t),
              (this.communicationType_ = l.CommunicationType.DIRECT),
              (this.handleExportedMessage =
                vt.prototype.handleExportedMessage.bind(this));
          };
          n.inherits(vt, u),
            (vt.prototype.sendMessage = function (t, e) {
              if (!(e = void 0 === e ? this.to : e))
                throw Error(
                  "Message destination must be defined at construction time or when sending the message."
                );
              e.handleExportedMessage(t.serialize(), this);
            }),
            (vt.prototype.handleExportedMessage = function (t, e) {
              c.isValidSerializedMessage(t) &&
                this.handleMessage(c.deserialize(t), e);
            }),
            (vt.prototype.isCrossOrigin = function () {
              return !1;
            });
          var pt = function (t, e) {
            (e = void 0 === e ? X.omidGlobal : e), u.call(this, e);
            var i = this;
            (this.communicationType_ = l.CommunicationType.POST_MESSAGE),
              t.addEventListener("message", function (t) {
                if ("object" == typeof t.data) {
                  var e = t.data;
                  c.isValidSerializedMessage(e) &&
                    ((e = c.deserialize(e)),
                    t.source && i.handleMessage(e, t.source));
                }
              });
          };
          n.inherits(pt, u),
            (pt.isCompatibleContext = function (t) {
              return !!(t && t.addEventListener && t.postMessage);
            }),
            (pt.prototype.sendMessage = function (t, e) {
              if (!(e = void 0 === e ? this.to : e))
                throw Error(
                  "Message destination must be defined at construction time or when sending the message."
                );
              e.postMessage(t.serialize(), "*");
            }),
            (pt.prototype.isCrossOrigin = function () {
              return !this.to || ot(this.to);
            });
          var mt = {},
            ft = ["omid", "v1_SessionServiceCommunication"],
            gt = ["omid", "v1_VerificationServiceCommunication"],
            bt = ["omidVerificationProperties", "serviceWindow"];
          function wt(t, e) {
            return e.reduce(function (t, e) {
              return t && t[e];
            }, t);
          }
          function _t(t, e, i, n) {
            if (!ot(e))
              try {
                var s = wt(e, i);
                if (s) return new vt(s);
              } catch (t) {}
            return n(e) ? new pt(t, e) : null;
          }
          function yt(t, e, i, s) {
            for (var r = (e = n.makeIterator(e)).next(); !r.done; r = e.next())
              if ((r = _t(t, r.value, i, s))) return r;
            return null;
          }
          function St(t, e, i) {
            i = void 0 === i ? F.isOmidPresent : i;
            var n = [t, ct(t)];
            return e && n.unshift(e), yt(t, n, ft, i);
          }
          function Mt(t, e) {
            e = void 0 === e ? F.isOmidPresent : e;
            var i = [],
              n = wt(t, bt);
            return n && i.push(n), i.push(ct(t)), yt(t, i, gt, e);
          }
          (mt.startSessionServiceCommunication = St),
            (mt.startVerificationServiceCommunication = Mt);
          var Ot = b.Version,
            Et;
          function At() {
            var t = X.omidGlobal.omid3p;
            return t &&
              "function" == typeof t.registerSessionObserver &&
              "function" == typeof t.addEventListener
              ? t
              : null;
          }
          var Tt = function (t) {
            (this.communication = t || Mt(dt()))
              ? (this.communication.onMessage = this.handleMessage_.bind(this))
              : (t = At()) && (this.omid3p = t),
              (this.remoteIntervals_ = this.remoteTimeouts_ = 0),
              (this.callbackMap_ = {}),
              (this.imgCache_ = []),
              (this.verificationClientId_ =
                (this.injectionId_ = (t =
                  X.omidGlobal.omidVerificationProperties)
                  ? t.injectionId
                  : void 0) || k());
          };
          (Tt.prototype.isSupported = function () {
            return (
              !(
                this.getEnvironment() === l.Environment.WEB &&
                !this.injectionId_
              ) && !(!this.communication && !this.omid3p)
            );
          }),
            (Tt.prototype.getEnvironment = function () {
              var t = dt();
              return (
                this.injectionSource() ||
                (0, F.getOmidEnvironment)(t) ||
                (0, F.getOmidEnvironment)(ct(t))
              );
            }),
            (Tt.prototype.injectionSource = function () {
              var t = X.omidGlobal.omidVerificationProperties;
              if (t && t.injectionSource) return t.injectionSource;
            }),
            (Tt.prototype.registerSessionObserver = function (t, e) {
              O("functionToExecute", t),
                this.omid3p
                  ? this.omid3p.registerSessionObserver(t, e, this.injectionId_)
                  : this.sendMessage_(
                      "addSessionListener",
                      t,
                      e,
                      this.injectionId_
                    );
            }),
            (Tt.prototype.attest = function (t, e) {
              y("requestPayload", t),
                _("mechanism", t.mechanism),
                y("payload", t.payload),
                O("callback", e),
                this.sendMessage_(
                  "attest",
                  e,
                  t.mechanism,
                  null == t.version ? "" : t.version,
                  t.payload,
                  this.verificationClientId_,
                  this.injectionId_
                );
            }),
            (Tt.prototype.addEventListener = function (t, e) {
              _("eventType", t),
                O("functionToExecute", e),
                this.omid3p
                  ? this.omid3p.addEventListener(t, e, this.injectionId_)
                  : this.sendMessage_(
                      "addEventListener",
                      e,
                      t,
                      this.injectionId_
                    );
            }),
            (Tt.prototype.sendUrl = function (t, e, i) {
              _("url", t),
                X.omidGlobal.document && X.omidGlobal.document.createElement
                  ? this.sendUrlWithImg_(t, e, i)
                  : this.sendMessage_(
                      "sendUrl",
                      function (t) {
                        t && e ? e() : !t && i && i();
                      },
                      t
                    );
            }),
            (Tt.prototype.sendUrlWithImg_ = function (t, e, i) {
              var n = this,
                s = X.omidGlobal.document.createElement("img");
              this.imgCache_.push(s);
              var r = function (t) {
                var e = n.imgCache_.indexOf(s);
                0 <= e && n.imgCache_.splice(e, 1), t && t();
              };
              s.addEventListener("load", r.bind(this, e)),
                s.addEventListener("error", r.bind(this, i)),
                (s.src = t);
            }),
            (Tt.prototype.injectJavaScriptResource = function (t, e, i) {
              var n = this;
              _("url", t),
                X.omidGlobal.document
                  ? this.injectJavascriptResourceUrlInDom_(t, e, i)
                  : this.sendMessage_(
                      "injectJavaScriptResource",
                      function (s, r) {
                        s
                          ? (n.evaluateJavaScript_(r, t), e())
                          : (v("Service failed to load JavaScript resource."),
                            i());
                      },
                      t
                    );
            }),
            (Tt.prototype.injectJavascriptResourceUrlInDom_ = function (
              t,
              e,
              i
            ) {
              var n = X.omidGlobal.document,
                s = n.body,
                r = n.createElement("script");
              (r.onload = e),
                (r.onerror = i),
                (r.src = t),
                (r.type = "application/javascript"),
                (t =
                  n.currentScript &&
                  n.currentScript.getAttribute("data-injection-id")) &&
                  r.setAttribute("data-injection-id", t),
                s.appendChild(r);
            }),
            (Tt.prototype.evaluateJavaScript_ = function (t, e) {
              try {
                eval(t);
              } catch (t) {
                v('Error evaluating the JavaScript resource from "' + e + '".');
              }
            }),
            (Tt.prototype.setTimeout = function (t, e) {
              if (
                (O("functionToExecute", t),
                E("timeInMillis", e),
                this.hasTimeoutMethods_())
              )
                return X.omidGlobal.setTimeout(t, e);
              var i = this.remoteTimeouts_++;
              return this.sendMessage_("setTimeout", t, i, e), i;
            }),
            (Tt.prototype.clearTimeout = function (t) {
              E("timeoutId", t),
                this.hasTimeoutMethods_()
                  ? X.omidGlobal.clearTimeout(t)
                  : this.sendOneWayMessage_("clearTimeout", t);
            }),
            (Tt.prototype.setInterval = function (t, e) {
              if (
                (O("functionToExecute", t),
                E("timeInMillis", e),
                this.hasIntervalMethods_())
              )
                return X.omidGlobal.setInterval(t, e);
              var i = this.remoteIntervals_++;
              return this.sendMessage_("setInterval", t, i, e), i;
            }),
            (Tt.prototype.clearInterval = function (t) {
              E("intervalId", t),
                this.hasIntervalMethods_()
                  ? X.omidGlobal.clearInterval(t)
                  : this.sendOneWayMessage_("clearInterval", t);
            }),
            (Tt.prototype.hasTimeoutMethods_ = function () {
              return (
                "function" == typeof X.omidGlobal.setTimeout &&
                "function" == typeof X.omidGlobal.clearTimeout
              );
            }),
            (Tt.prototype.hasIntervalMethods_ = function () {
              return (
                "function" == typeof X.omidGlobal.setInterval &&
                "function" == typeof X.omidGlobal.clearInterval
              );
            }),
            (Tt.prototype.handleMessage_ = function (t, e) {
              e = t.method;
              var i = t.guid;
              if (((t = t.args), "response" === e && this.callbackMap_[i])) {
                var n = R(b.Version, t);
                this.callbackMap_[i].apply(this, n);
              }
              "error" === e && window.console && v(t);
            }),
            (Tt.prototype.sendOneWayMessage_ = function (t) {
              var e = n.getRestArguments.apply(1, arguments);
              this.sendMessage_.apply(
                this,
                [t, null].concat(n.arrayFromIterable(e))
              );
            }),
            (Tt.prototype.sendMessage_ = function (t, e) {
              var i = n.getRestArguments.apply(2, arguments);
              if (this.communication) {
                var s = k();
                e && (this.callbackMap_[s] = e),
                  (i = new c(s, G(t), b.Version, V(b.Version, i))),
                  this.communication.sendMessage(i);
              }
            }),
            nt("OmidVerificationClient", Tt);
        },
        e
      ),
        (t.exports = function () {
          return e.OmidVerificationClient;
        });
    },
    5382: (t) => {
      "use strict";
      var e,
        i = Object.defineProperty,
        n = Object.getOwnPropertyDescriptor,
        s = Object.getOwnPropertyNames,
        r = Object.prototype.hasOwnProperty,
        o = {};
      ((t, e) => {
        for (var n in e) i(t, n, { get: e[n], enumerable: !0 });
      })(o, {
        AdFormatId: () => d,
        AdLocationContext: () => c,
        AdLocationError: () => l,
        AdLocationException: () => u,
        AdLocationOutcome: () => v,
        AdLocationWarningCode: () => p,
        DEFAULT_AD_FORMATS_BY_PRIORITY: () => it,
        FormatDetectionError: () => m,
        FormatDetectionException: () => f,
        FormatDetectionOutcome: () => b,
        annotationSpecAdFormat: () => k,
        asAdLocationException: () => h,
        asFormatDetectionException: () => g,
        celtraAdFormat: () => F,
        clipcentricAdFormat: () => H,
        detachedDetect: () => rt,
        detect: () => dt,
        encodeLocationDiagnostics: () => ct,
        fallbackClipcentricAdFormat: () => Y,
        weatherChannelLargeWebAdFormat: () => tt,
        weatherChannelMobileWebAdFormat: () => et,
      }),
        (t.exports =
          ((e = o),
          ((t, e, o, a) => {
            if ((e && "object" == typeof e) || "function" == typeof e)
              for (let d of s(e))
                !r.call(t, d) &&
                  d !== o &&
                  i(t, d, {
                    get: () => e[d],
                    enumerable: !(a = n(e, d)) || a.enumerable,
                  });
            return t;
          })(i({}, "__esModule", { value: !0 }), e)));
      var a,
        d = {
          DEFAULT: 0,
          WEATHER_CHANNEL_LWIM: 1,
          CELTRA: 2,
          CLIPCENTRIC: 4,
          WEATHER_CHANNEL_MWIM: 8,
          ANNOTATION: 16,
          FALLBACK_CLIPCENTRIC: 32,
        },
        c = class {
          annotation;
          warnings = [];
          setAnnotation(t) {
            return (this.annotation = t), this;
          }
          getAnnotation() {
            return this.annotation;
          }
          addWarning(t) {
            return this.warnings.push(t), this;
          }
          getWarnings() {
            return this.warnings.length > 0 ? this.warnings : void 0;
          }
        },
        l = {
          NO_ERROR: 0,
          UNKNOWN_ERROR: 1,
          NO_AD_FOUND: 4,
          MULTIPLE_ADS_LOCATED: 8,
          ABORTED: 16,
          CONFLICTING_CONTAINER_SELECTORS: 32,
        },
        u = class extends Error {
          errorCode;
          constructor(t, e, i) {
            super(e, i), (this.errorCode = t);
          }
        },
        h = (t) =>
          t instanceof u
            ? t
            : t instanceof DOMException &&
              ("AbortError" === t.name || "TimeoutError" === t.name)
            ? new u(l.ABORTED, t.message, { cause: t })
            : t instanceof Error
            ? new u(l.UNKNOWN_ERROR, t.message, { cause: t })
            : new u(l.UNKNOWN_ERROR, String(t)),
        v =
          (((a = v || {}).AD_LOCATED = "AD_LOCATED"),
          (a.AD_LOCATION_FAILED = "AD_LOCATION_FAILED"),
          a),
        p = { MULTIPLE_ANNOTATIONS: 1 },
        m = {
          NO_ERROR: 0,
          UNKNOWN_ERROR: 1,
          MULTIPLE_AD_FORMATS_DETECTED: 2,
          DOM_EXCEPTION: 4,
        },
        f = class extends Error {
          errorCode;
          constructor(t, e, i) {
            super(e, i), (this.errorCode = t);
          }
        },
        g = (t) =>
          t instanceof f
            ? t
            : t instanceof Error
            ? new f(m.UNKNOWN_ERROR, t.message, { cause: t })
            : new f(m.UNKNOWN_ERROR, String(t)),
        b = {
          DETECTED: "DETECTED",
          NOT_DETECTED: "NOT_DETECTED",
          DETECTION_FAILED: "DETECTION_FAILED",
        },
        w = (t) => {
          let e = {
            name: t.name,
            id: t.id,
            detect: (...i) => {
              try {
                let n = t.detect(...i);
                return null == n
                  ? { type: b.NOT_DETECTED, adFormat: e }
                  : {
                      type: b.DETECTED,
                      adFormat: e,
                      locate: async (t) => {
                        let i = new c();
                        try {
                          let s = await n(i, t);
                          return {
                            type: "AD_LOCATED",
                            adFormat: e,
                            adNode: s,
                            annotation: i.getAnnotation(),
                            warnings: i.getWarnings(),
                          };
                        } catch (t) {
                          let n = h(t);
                          return {
                            type: "AD_LOCATION_FAILED",
                            adFormat: e,
                            error: n,
                            annotation: i.getAnnotation(),
                            warnings: i.getWarnings(),
                          };
                        }
                      },
                    };
              } catch (t) {
                let i = g(t);
                return { type: b.DETECTION_FAILED, adFormat: e, error: i };
              }
            },
            detectDetached: (...i) => {
              try {
                return t.detectDetached(...i)
                  ? { type: b.DETECTED, adFormat: e }
                  : { type: b.NOT_DETECTED, adFormat: e };
              } catch (t) {
                let i = g(t);
                return { type: b.DETECTION_FAILED, adFormat: e, error: i };
              }
            },
          };
          return e;
        },
        _ = (t) => {
          let e = t.ownerDocument.defaultView?.top;
          if (null == e) throw new Error("Window does not have a top property");
          return e;
        },
        y = (t) => {
          if (t?.aborted) throw new DOMException("Aborted", "AbortError");
        },
        S = async (t, { signal: e, retryInterval: i = 1e3 }) => {
          let n = null;
          do {
            y(e), (n = t()), null === n && (await M(i));
          } while (null === n);
          return n;
        },
        M = async (t) => await new Promise((e) => setTimeout(e, t)),
        O = (t, e) => {
          let i = _(t).document.documentElement.querySelectorAll(e);
          if (1 === i.length) return i[0];
          if (i.length > 1) throw new u(l.MULTIPLE_ADS_LOCATED);
          return null;
        },
        E = (t, e, i = !1) => {
          let n = e.matchAll(t);
          if (void 0 === n.next().value) return !1;
          if (i) return !0;
          if (void 0 !== n.next().value)
            throw new f(m.MULTIPLE_AD_FORMATS_DETECTED);
          return !0;
        },
        A = (t) => (t?.nodeType === Node.ELEMENT_NODE ? t : null),
        T = (t, e) => {
          let i = [],
            n = ((t, e) =>
              ((t) => t.ownerDocument ?? t)(e).evaluate(
                t,
                e,
                null,
                XPathResult.ORDERED_NODE_ITERATOR_TYPE,
                null
              ))(t, e),
            s = n.iterateNext();
          for (; null != s; ) {
            let t = A(s);
            null != t && i.push(t), (s = n.iterateNext());
          }
          return i;
        },
        I = (t, e) => {
          let i = T(t, e);
          return i.length > 0 && i;
        },
        C = (t, e) => {
          let i = T(t, e);
          if (0 === i.length) return null;
          if (i.length > 1) throw new f(m.MULTIPLE_AD_FORMATS_DETECTED);
          return i[0];
        },
        D = "data-ad-format",
        j = "data-ad-container",
        V = new RegExp(`<[^>]*\\s+${D}(\\s*=\\s*(['"]).*?\\2)?(\\s|>)`, "g"),
        R = `//*[@${D}]`,
        x = (t, e) => t.map((t) => t[e]),
        P = (t) => {
          let e = {};
          for (let i of t) e[i] = (e[i] ?? 0) + 1;
          return e;
        },
        k = w({
          name: "Annotation Spec",
          id: d.ANNOTATION,
          detectDetached: (t) => E(V, t, !0),
          detect(t) {
            let e = ((t, e) => T(t, e))(R, t);
            return e.length > 0 ? N(e, t) : null;
          },
        }),
        N = (t, e) => async (i, n) => {
          await Promise.all(
            t.map(
              async (t) =>
                await (async (t, e, i) =>
                  await new Promise((n, s) => {
                    let r = i?.validate ?? ((t) => "string" == typeof t),
                      o = !1,
                      a = (t) => {
                        d.disconnect(),
                          null != i?.signal &&
                            i.signal.removeEventListener("abort", c),
                          n(t);
                      },
                      d = new MutationObserver(() => {
                        if (o) return;
                        let i = t.getAttribute(e);
                        r(i) && a(i);
                      });
                    function c() {
                      (o = !0),
                        d.disconnect(),
                        s(new DOMException("Aborted", "AbortError"));
                    }
                    if (null != i?.signal) {
                      if (i.signal.aborted) return void c();
                      i.signal.addEventListener("abort", c, { once: !0 });
                    }
                    let l = t.getAttribute(e);
                    r(l)
                      ? a(l)
                      : d.observe(t, { attributes: !0, attributeFilter: [e] });
                  }))(t, j, { signal: n })
            )
          );
          let s = t
            .map((t) => ({
              selector: (t.getAttribute(j) ?? "").trim(),
              name: (t.getAttribute(D) ?? "").trim(),
            }))
            .filter((t) => "" !== t.selector);
          if (0 === s.length) throw new u(l.NO_AD_FOUND);
          let r = x(s, "selector"),
            o = ((t) => Array.from(new Set(t)))(r),
            a = x(s, "name");
          if (
            (s.length > 1 &&
              i.addWarning({
                code: p.MULTIPLE_ANNOTATIONS,
                details: { selectors: P(r), names: P(a) },
              }),
            o.length > 1)
          )
            throw new u(
              l.CONFLICTING_CONTAINER_SELECTORS,
              `Multiple conflicting container selectors found: ${o.join(", ")}`
            );
          let d = o[0],
            c = a.find((t) => "" !== t) ?? "";
          return (
            i.setAnnotation({ name: c, selector: d }),
            await (
              (t, e) => async (i) =>
                await S(() => O(t, e), { signal: i })
            )(
              e,
              d
            )(n)
          );
        },
        L = /<div[^>]*class\s*=\s*(['"])(?:(?:(?!\1)\S)+\s+)*\s*celtra-ad-v/g,
        F = w({
          name: "Celtra",
          id: d.CELTRA,
          detectDetached: (t) => {
            let e = t.matchAll(L);
            if (void 0 === e.next().value) return !1;
            if (void 0 !== e.next().value)
              throw new f(m.MULTIPLE_AD_FORMATS_DETECTED);
            return !0;
          },
          detect(t) {
            let e = z(t);
            return null === e ? null : U(e);
          },
        }),
        U = (t) => async (e, i) => {
          y(i);
          let n = (await B(t, i)).celtra.viewabilityObservee;
          if (null == n) throw new u(l.NO_AD_FOUND);
          return n;
        },
        B = async (t, e) =>
          await new Promise((i, n) => {
            !0 === t.celtra?.loaded
              ? i(t)
              : (t.addEventListener(
                  "celtraLoaded",
                  () => {
                    i(t);
                  },
                  { once: !0, passive: !0, signal: e }
                ),
                e?.addEventListener(
                  "abort",
                  () => {
                    n(new u(l.ABORTED));
                  },
                  { once: !0, passive: !0 }
                ));
          }),
        z = (t) => {
          let e = T(".//div[contains(concat(' ', @class), ' celtra-ad-v')]", t);
          if (0 === e.length) return null;
          if (1 !== e.length)
            throw new f(
              m.MULTIPLE_AD_FORMATS_DETECTED,
              `Found ${e.length} Celtra tag elements`
            );
          return e[0];
        },
        W = "ccfid",
        q = /<script[^>]*id\s*=\s*(['"])\s*ccfid(?:(?!\1).)*\1/g,
        $ = `.//script[contains(@id,"${W}")]`,
        H = w({
          name: "clipcentric",
          id: d.CLIPCENTRIC,
          detectDetached: (t) => {
            let e = t.matchAll(q);
            if (void 0 === e.next().value) return !1;
            if (void 0 !== e.next().value)
              throw new f(m.MULTIPLE_AD_FORMATS_DETECTED);
            return !0;
          },
          detect(t) {
            let e = T($, t);
            if (0 === e.length) return null;
            if (e.length > 1) throw new f(m.MULTIPLE_AD_FORMATS_DETECTED);
            let [i] = e,
              n = ((t) => {
                if (null == t)
                  throw new Error("Clipcentric script node is null");
                if (!t.hasAttribute("id"))
                  throw new Error(
                    "Clipcentric script node does not have an id attribute"
                  );
                let e = t.getAttribute("id");
                if (null == e)
                  throw new Error(
                    "Clipcentric script node id attribute is null"
                  );
                return e.replace(W, "");
              })(i);
            return G(n, t);
          },
        }),
        G = (t, e) => async (i, n) => {
          let s = `.//div[@data-cc-id="${t}"]`;
          return await S(() => J(e, s), { signal: n });
        },
        J = (t, e) => {
          let i = _(t).document.documentElement,
            n = I(e, i);
          if (!1 !== n && 1 === n.length) return n[0];
          if (!1 !== n && n.length > 1) throw new u(l.MULTIPLE_ADS_LOCATED);
          return null;
        },
        K = /\/F=(\d+)\//,
        Q =
          /<script[^>]*src\s*=\s*(['"])[^'"]*clipcentric[^'"]*\/F=\d+\/[^'"]*\1[^>]*>/g,
        Y = w({
          name: "fallback-clipcentric",
          id: d.FALLBACK_CLIPCENTRIC,
          detectDetached: (t) => {
            try {
              if (H.detectDetached(t).type === b.DETECTED) return !1;
            } catch {}
            let e = t.matchAll(Q);
            if (void 0 === e.next().value) return !1;
            if (void 0 !== e.next().value)
              throw new f(m.MULTIPLE_AD_FORMATS_DETECTED);
            return !0;
          },
          detect(t) {
            try {
              if (H.detect(t).type === b.DETECTED) return null;
            } catch {}
            let e = T(
              './/script[@src and contains(@src, "clipcentric") and contains(@src, "/F=")]',
              t
            );
            if (0 === e.length) return null;
            if (e.length > 1) throw new f(m.MULTIPLE_AD_FORMATS_DETECTED);
            let [i] = e,
              n = i.getAttribute("src");
            if (null === n) return null;
            let s = K.exec(n);
            if (null === s) return null;
            let r = s[1];
            return G(r, t);
          },
        }),
        X = (t, e) => async (i, n) => await S(() => Z(t, e), { signal: n }),
        Z = (t, e) => {
          let i = _(t).document.documentElement,
            n = I(e, i);
          if (!1 !== n && 1 === n.length) return n[0];
          if (!1 !== n && n.length > 1) throw new u(l.MULTIPLE_ADS_LOCATED);
          return null;
        },
        tt = w({
          name: "Weather Channel LWIM",
          id: d.WEATHER_CHANNEL_LWIM,
          detectDetached: E.bind(
            null,
            /<div[^>]*id\s*=\s*(['"])\s*labBG\s*\1/g
          ),
          detect: (t) =>
            null != C('.//div[@id="labBG"]', t)
              ? X(t, './/div[@id="labBG"]')
              : null,
        }),
        et = w({
          name: "Weather Channel MWIM",
          id: d.WEATHER_CHANNEL_MWIM,
          detectDetached: E.bind(
            null,
            /<body[^>]*data-product\s*=\s*(['"])\s*labAdMwim\s*\1/g
          ),
          detect: (t) =>
            null != C('.//body[@data-product="labAdMwim"]', t)
              ? X(t, './/div[@id="labAdDiv"]')
              : null,
        }),
        it = [[k], [F, H, Y, tt, et]],
        nt = (t, e, i) => {
          let n = e.map((t) => `${t.adFormat.id}:0`).join(","),
            s = i.map((t) => `${t.adFormat.id}:${t.error.errorCode}`).join(",");
          return `${t}|${n}${e.length > 0 && i.length > 0 ? "," : ""}${s}`;
        },
        st = (t) => {
          let e = t.filter((t) => t.type === b.DETECTED),
            i = t.filter((t) => t.type === b.DETECTION_FAILED),
            n = ((t, e) => {
              let i = m.NO_ERROR;
              t.length > 1 && (i |= m.MULTIPLE_AD_FORMATS_DETECTED);
              for (let t of e) i |= t.error.errorCode;
              return i;
            })(e, i),
            s = 1 === e.length;
          return 0 === n
            ? { errorCode: n, detectedFormat: s ? e[0] : null }
            : { errorCode: n, detectedFormat: null, diagnostics: nt(n, e, i) };
        },
        rt = (t, e = it) => {
          for (let i of e) {
            let e = i.map((e) => e.detectDetached(t)),
              n = st(e);
            if (null != n.detectedFormat || n.errorCode !== m.NO_ERROR)
              return n;
          }
          return st([]);
        },
        ot = (t, e) => {
          try {
            if (
              null ===
              ((t) => {
                try {
                  return (
                    t &&
                    (t.contentDocument ||
                      (t.contentWindow && t.contentWindow.document) ||
                      (frames && frames[t.name] && frames[t.name].document))
                  );
                } catch {
                  return null;
                }
              })(t)
            )
              return !1;
            if ("" === t.src || "about:blank" === t.src) return !0;
            let i = new URL(t.src),
              n = new URL(e.location.href);
            return i.origin === n.origin;
          } catch {
            return !1;
          }
        },
        at = (t) => {
          let e = ((t) =>
            Array.from(t.querySelectorAll("iframe")).filter((t) =>
              ot(t, window)
            ))(t);
          return 0 === e.length
            ? [t]
            : [
                t,
                ...e
                  .map((t) => t.contentDocument)
                  .filter((t) => null !== t)
                  .flatMap((t) => at(t.documentElement)),
              ];
        },
        dt = (t, e = it) => {
          let i = at(t);
          for (let t of e) {
            let e = i.flatMap((e) => t.map((t) => t.detect(e))),
              n = st(e);
            if (null != n.detectedFormat || n.errorCode !== m.NO_ERROR)
              return n;
          }
          return st([]);
        },
        ct = (t) => {
          let e = "AD_LOCATION_FAILED" === t.type,
            i = null != t.warnings && t.warnings.length > 0;
          if (!e && !i) return null;
          let n = e ? t.error.errorCode : l.NO_ERROR,
            s = t.adFormat.id,
            r = [`${n}`, `${s}:${n}`];
          if (null != t.warnings) {
            let e = t.warnings.map((t) => `${s}:${t.code}`).join(",");
            r.push(e);
          }
          return r.join("|");
        };
    },
  },
  __webpack_module_cache__ = {};
function __webpack_require__(t) {
  var e = __webpack_module_cache__[t];
  if (void 0 !== e) return e.exports;
  var i = (__webpack_module_cache__[t] = { exports: {} });
  return (
    __webpack_modules__[t].call(i.exports, i, i.exports, __webpack_require__),
    i.exports
  );
}
__webpack_require__.g = (function () {
  if ("object" == typeof globalThis) return globalThis;
  try {
    return this || new Function("return this")();
  } catch (t) {
    if ("object" == typeof window) return window;
  }
})();
var __webpack_exports__ = {};
(() => {
  try {
    const t = __webpack_require__(6384).default;
    t.setTotalSyncTimeStartTime(__dv_global_script_start_time__),
      t.setIndexExecutionStartTime();
    const { sendS2SPartnerTelemetryEvent: e } = __webpack_require__(1360);
    e({ type: "Initialization" });
    {
      const { initScript: t } = __webpack_require__(3354);
      t();
    }
    __webpack_require__(8620)();
  } catch (t) {
    let e,
      i,
      n,
      s,
      r,
      o = "https://tps.doubleverify.com/visit.jpg",
      a = 11365;
    try {
      const { A: t, T: d, O: c } = __webpack_require__(8844),
        { getSupportedIntegrationsBitwise: l } = __webpack_require__(6128);
      (o = `${t.getServerPrefix()}${t.getErrorPath()}`),
        (a = d.getDvtpScriptVersion()),
        (e = c.getScenarioType()),
        (i = t.getTagType()),
        (s = t.getTagVersion()),
        (n = l()),
        (r = t.getAdServerId());
    } catch (t) {}
    let d = `${o}?ctx=818052&cmp=1619415&dvtagver=6.1.src&dvp_isLostImp=1&cerrt=4&jsver=11365&tgjsver=${a}&flvr=1`;
    if ("function" == typeof encodeURIComponent) {
      d += "&napr=WebPackConfig__" + encodeURIComponent(t.message);
      "string" == typeof t.stack &&
        Math.random() <= 0.1 &&
        (d += "&ee_dp_errstk=" + encodeURIComponent(t.stack));
    }
    e && (d += "&tstype=" + e),
      i && (d += "&tagtype=" + i),
      n && (d += "&mib=" + n),
      s && (d += "&tagVersion=" + s),
      r && (d += "&ee_dp_adsrv=" + r),
      "object" == typeof omidNative && "function" == typeof omidNative.sendUrl
        ? ((d += "&dvp_iomd=1"), e || (d += "&tstype=4"), omidNative.sendUrl(d))
        : (new Image().src = d);
    const { sendS2SPartnerTelemetryEvent: c } = __webpack_require__(1360);
    c({ type: "RuntimeError" });
  }
})();
