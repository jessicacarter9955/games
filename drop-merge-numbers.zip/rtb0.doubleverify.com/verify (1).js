try {
  __tagObject_callback_1795262935975421({
    ImpressionID: "60ba70292a36447798a833512bcf108a",
    ServerPublicDns: "maestro-ue1.tps.dv.tech",
  });
} catch (e) {}
try {
  $dvbs.pubSub.publish(
    "BeforeDecisionRender",
    "60ba70292a36447798a833512bcf108a"
  );
} catch (e) {}
try {
  __verify_callback_1795262935975421({
    ResultID: 2,
    Passback: "",
    ServerContext: {
      fd: {
        researchCollection: {
          adid: "2710108543176062008",
          d9: "3658259561767602418,-5488740230212662710",
          d13: "20261121",
          icat: "false",
          d12: "false",
          exti: "2848296441",
          d2: "0.05",
          crad: "false",
          tapt: "12",
          d14: "",
          d1: "10",
          impi: "60ba70292a36447798a833512bcf108a",
          dety: "1",
          d3: "rc20260909",
          urti: "1284",
          doha: "-5767225446047257874",
          d6: "",
        },
        common: { isBsAllow: "true" },
        isBsAllow: true,
      },
      ce: { ddt: 1, dt: 1 },
    },
  });
} catch (e) {}
try {
  $dvbs.pubSub.publish(
    "AfterDecisionRender",
    "60ba70292a36447798a833512bcf108a"
  );
} catch (e) {}
