(function () {
  "use strict"; /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var e = this || self;
  function f() {
    var a = g;
    return a && a.visibilityState === "visible";
  }
  function l() {
    var a = q;
    return a && a.innerWidth > 0 && a.innerHeight > 0;
  }
  function r(a) {
    var b = a.h && a.l && a.m;
    if (a.i === b) return !1;
    a.i = b;
    return !0;
  }
  function t(a) {
    if (r(a)) for (let b of a.j) b(a.i);
  }
  var u = class {
      constructor() {
        this.j = new Set();
        this.l = f();
        this.m = l();
        this.i = this.h = !1;
        var a = e.oneAfmaInstance;
        this.h = a ? a.visibilityState : !0;
        r(this);
        a = window.AFMA_Communicator;
        a == null ||
          a.addEventListener("onshow", () => {
            this.h = !0;
            t(this);
          });
        a == null ||
          a.addEventListener("onhide", () => {
            this.h = !1;
            t(this);
          });
        var b;
        (b = g) == null ||
          b.addEventListener("visibilitychange", () => {
            this.l = f();
            t(this);
          });
        var d;
        (d = q) == null ||
          d.addEventListener("resize", () => {
            this.m = l();
            t(this);
          });
      }
      listen(a) {
        a(this.i);
        this.j.add(a);
      }
      unlisten(a) {
        this.j.delete(a);
      }
    },
    g = document,
    q = window,
    v;
  function w() {
    return typeof mys !== "undefined" ? mys.pingback : void 0;
  }
  var x = class {
    constructor() {
      this.h = w();
      this.i = 0;
    }
    enabledChannel(a) {
      this.i = a;
      var b;
      (b = this.h) == null || b.tick(43, this.i);
    }
    setSlice(a, b) {
      var d;
      (d = this.h) == null || d.setAttribute(a, b);
    }
    setData(a, b) {
      var d;
      (d = this.h) == null || d.setData(a, b, this.i);
    }
    send(a) {
      var b;
      (b = this.h) == null || b.send(a);
    }
    setDataAndSend(a, b) {
      if (this.h) {
        for (let d in a) a.hasOwnProperty(d) && this.h.setData(d, a[d], this.i);
        this.h.send(b);
      }
    }
    tick(a, b) {
      var d;
      (d = this.h) == null || d.tick(a, this.i, b);
    }
    populateServerPingbackOutput() {}
    flush() {
      return [];
    }
  };
  function z(a, b) {
    var d;
    if (
      (a.h.includes(b) || a.i.includes(b)) &&
      ((d = window.performance) == null ? 0 : d.getEntries) &&
      window.PerformanceNavigationTiming &&
      window.PerformanceResourceTiming
    ) {
      d = a.h.includes(b) ? ["script"] : [];
      var c = window.performance.getEntries(),
        h = 0,
        m = 0,
        n = 0,
        p = 0;
      for (let k of c)
        if (
          !k.name.includes(
            "pagead2.googlesyndication.com/pagead/gen_204?id=mys"
          )
        )
          if (k instanceof window.PerformanceNavigationTiming)
            h += k.transferSize || 0;
          else if (k instanceof window.PerformanceResourceTiming) {
            c = k.initiatorType;
            let y = k.transferSize || 0;
            if (d.length === 0 || d.includes(c))
              n++, (m += y === 0 ? 1 : 0), (p += y);
          }
      a.h.includes(b)
        ? (a.pingback.setData(16, h),
          a.pingback.setData(17, p),
          a.pingback.setData(18, n),
          a.pingback.setData(19, m))
        : a.i.includes(b) &&
          (a.pingback.setData(20, p),
          a.pingback.setData(21, n),
          a.pingback.setData(22, m));
    }
    a.pingback.setData(b, window.performance.now());
    a.pingback.send();
  }
  function A(a, b) {
    a.j.set(b, window.performance.now());
  }
  function B(a, b) {
    var d = a.j.get(b);
    d !== void 0 &&
      (a.pingback.setData(b, window.performance.now() - d),
      b === 13 &&
        (a.pingback.setData(30, `${window.innerWidth}x${window.innerHeight}`),
        (b = a.body),
        a.pingback.setData(25, `${b.clientWidth}x${b.clientHeight}`)),
      a.pingback.send());
  }
  var D = class {
    constructor() {
      this.body = C;
      this.pingback = new x();
      this.j = new Map();
      this.o = {
        overallStart: () => void z(this, 3),
        overallReady: () => void z(this, 4),
        overallQuiet: () => void z(this, 5),
        overallError: () => void z(this, 6),
        assembleStart: () => void A(this, 7),
        assembleReady: () => void B(this, 7),
        decorateStart: () => void A(this, 8),
        decorateReady: () => void B(this, 8),
        fontStart: () => void A(this, 9),
        fontReady: () => void B(this, 9),
        spanStart: () => void A(this, 10),
        spanReady: () => void B(this, 10),
        prepareStart: () => void A(this, 11),
        prepareReady: () => void B(this, 11),
        bindingStart: () => void A(this, 12),
        bindingReady: () => void B(this, 12),
        browserStart: () => void A(this, 13),
        browserStartEnd: () => void B(this, 13),
        browserReady: () => void A(this, 14),
        browserReadyEnd: () => void B(this, 14),
        browserQuiet: () => void A(this, 15),
        browserQuietEnd: () => void B(this, 15),
      };
      this.h = [23];
      this.i = [24];
      this.m = (a) => {
        this.pingback.setData(1, a.message);
        this.pingback.setData(95, a.filename);
        this.pingback.send();
      };
      this.l = (a) => {
        var b = "custom_error: ";
        a.detail && (b += a.detail.message);
        this.pingback.setData(2, b);
        this.pingback.send();
      };
      this.pingback.enabledChannel(4);
    }
  };
  var C = document.getElementById("mys-content");
  (function () {
    var a = new D(),
      b = w();
    if (b) {
      window.addEventListener("error", a.m);
      a.body.addEventListener("customError", (c) => {
        a.l(c);
      });
      window.addEventListener(
        "click",
        (c) => {
          var h = Date.now() - b.getBaseTime();
          a.pingback.setData(47, `${c.clientX}x${c.clientY}@${h}`);
          a.pingback.send();
        },
        !0
      );
      var d;
      if ((d = window.performance) != null && d.now) {
        window.addEventListener("DOMContentLoaded", () => void z(a, 23));
        window.addEventListener("load", () => {
          z(a, 24);
          setTimeout(() => {
            var c;
            (c = window.performance) != null &&
              c.getEntriesByType &&
              (c = performance.getEntriesByType("navigation")[0]) &&
              (a.pingback.setData(50, c.fetchStart),
              a.pingback.setData(51, c.domainLookupStart),
              a.pingback.setData(52, c.domainLookupEnd),
              a.pingback.setData(53, c.connectStart),
              a.pingback.setData(54, c.connectEnd),
              a.pingback.setData(55, c.secureConnectionStart),
              a.pingback.setData(56, c.requestStart),
              a.pingback.setData(57, c.responseStart),
              a.pingback.setData(58, c.responseEnd),
              a.pingback.setData(59, c.domInteractive),
              a.pingback.setData(60, c.domContentLoadedEventStart),
              a.pingback.setData(61, c.domContentLoadedEventEnd),
              a.pingback.setData(62, c.domComplete),
              a.pingback.setData(63, c.loadEventStart),
              a.pingback.setData(64, c.loadEventEnd),
              a.pingback.send());
          }, 0);
        });
        (v || (v = new u())).listen((c) => {
          c
            ? a.pingback.setData(75, window.performance.now())
            : a.pingback.setData(76, window.performance.now());
          a.pingback.send();
        });
        for (let [c, h] of Object.entries(a.o)) a.body.addEventListener(c, h);
      }
    }
  })();
}.call(this));
