(this.workbox = this.workbox || {}),
  (this.workbox.broadcastUpdate = (function (t, a, o, e) {
    "use strict";
    try {
      self["workbox:broadcast-update:5.0.0"] && _();
    } catch (t) {}
    const s = (t, a, o) => {
        return (
          !o.some((o) => t.headers.has(o) && a.headers.has(o)) ||
          o.every((o) => {
            const e = t.headers.has(o) === a.headers.has(o),
              s = t.headers.get(o) === a.headers.get(o);
            return e && s;
          })
        );
      },
      n = "CACHE_UPDATED",
      i = "workbox-broadcast-update",
      c = ["content-length", "etag", "last-modified"],
      r = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
    function h(t) {
      return { cacheName: t.cacheName, updatedURL: t.request.url };
    }
    class d {
      constructor({ headersToCheck: t, generatePayload: a } = {}) {
        (this.t = t || c), (this.o = a || h);
      }
      async notifyIfUpdated(t) {
        if (t.oldResponse && !s(t.oldResponse, t.newResponse, this.t)) {
          const e = { type: n, meta: i, payload: this.o(t) };
          if ("navigate" === t.request.mode) {
            let e;
            t.event instanceof FetchEvent && (e = t.event.resultingClientId),
              ((await o.resultingClientExists(e)) && !r) ||
                (await a.timeout(3500));
          }
          const s = await self.clients.matchAll({ type: "window" });
          for (const t of s) t.postMessage(e);
        }
      }
    }
    return (
      (t.BroadcastCacheUpdate = d),
      (t.BroadcastUpdatePlugin = class {
        constructor(t) {
          (this.cacheDidUpdate = async (t) => {
            e.dontWaitFor(this.s.notifyIfUpdated(t));
          }),
            (this.s = new d(t));
        }
      }),
      (t.responsesAreSame = s),
      t
    );
  })({}, workbox.core._private, workbox.core._private, workbox.core._private));
//# sourceMappingURL=workbox-broadcast-update.prod.js.map
