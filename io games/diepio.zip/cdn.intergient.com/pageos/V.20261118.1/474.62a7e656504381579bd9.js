"use strict";
(self.webpackChunkpageos = self.webpackChunkpageos || []).push([
  [474],
  {
    1474(e, r, t) {
      t.d(r, { default: () => i });
      let a = !1;
      const d = (e) =>
        document.cookie.match(`(^|;)\\s*${e}\\s*=\\s*([^;]+)`)?.pop() || "";
      function i(e) {
        return (
          (a = e),
          new Promise((e) => {
            e({
              id5: n("id5"),
              live_ramp: n("liveRamp"),
              live_ramp2: n("liveRamp2"),
              uid2: n("uid2"),
              shared_id: n("sharedId"),
              criteo_id: n("criteo"),
              "33_across_id": n("33acrossId"),
              unified_id: n("unifiedId"),
              pub_cmmon_id: n("pubCommonId"),
              dmd_id: n("dmdId"),
              ftrack_id: n("ftrackId"),
              live_intent_id: n("liveIntentId"),
              merkle_id: n("merkleId"),
              admixer_id: n("admixerId"),
              deep_intent_id: n("deepIntentId"),
              kpu_id: n("kpuId"),
              connect_id: n("connectId"),
              trustp_id: n("trustpId"),
              tapad_id: n("tapadId"),
              publink_id: n("publinkId"),
              intent_iq_id: n("intentIqId"),
              fabrick_id: n("fabrickId"),
              britepool_id: n("britepoolId"),
              amx_id: n("amxId"),
              adtelligent: n("adtelligent"),
            });
          })
        );
      }
      const n = (e) => {
        try {
          switch (e) {
            case "id5":
              if (((e = a && localStorage.getItem("id5id")), e))
                return JSON.parse(decodeURIComponent(e)).original_uid;
              break;
            case "liveRamp":
              if (((e = a && localStorage.getItem("idl_env")), e))
                return JSON.parse(atob(e));
              if (((e = d("idl_env")), e)) return e;
              break;
            case "liveRamp2":
              if (((e = a && localStorage.getItem("_lr_env")), e))
                return JSON.parse(atob(e));
              if (((e = d("_lr_env")), e)) return e;
              break;
            case "uid2":
              if (((e = d("__uid_2")), e))
                return JSON.parse(decodeURIComponent(e)).advertising_token;
              break;
            case "sharedId":
              if (((e = a && localStorage.getItem("sharedid")), e)) return e;
              if (((e = d("_sharedid")), e)) return e;
              break;
            case "criteo":
              let e = a && localStorage.getItem("_criteoId");
              if (e) return JSON.parse(decodeURIComponent(e)).criteoId;
              if (((e = d("_criteoId")), e)) return e;
              break;
            case "33acrossId":
              if (((e = a && localStorage.getItem("33acrossId")), e)) return e;
              if (((e = d("33acrossId")), e)) return e;
              break;
            case "unifiedId":
              if (((e = a && localStorage.getItem("unifiedid")), e)) return e;
              if (((e = d("unifiedid")), e)) return e;
              break;
            case "pubCommonId":
              if (((e = a && localStorage.getItem("_pubcid")), e)) return e;
              if (((e = d("_pubcid")), e)) return e;
              break;
            case "dmdId":
              if (((e = d("dmd-dgid")), e)) return e;
              break;
            case "ftrackId":
              if (((e = a && localStorage.getItem("ftrackId")), e)) return e;
              break;
            case "liveIntentId":
              if (((e = a && localStorage.getItem("__tamLIResolveResult")), e))
                return e;
              if (((e = d("__tamLIResolveResult")), e)) return e;
              break;
            case "merkleId":
              if (((e = a && localStorage.getItem("merkleId")), e)) return e;
              if (((e = d("merkleId")), e)) return e;
              break;
            case "admixerId":
              if (((e = a && localStorage.getItem("admixerId")), e)) return e;
              if (((e = d("__adm__admixer")), e)) return e;
              break;
            case "deepIntentId":
              if (((e = a && localStorage.getItem("_dpes_id")), e)) return e;
              if (((e = d("_dpes_id")), e)) return e;
              break;
            case "kpuId":
              if (((e = a && localStorage.getItem("knssoId")), e)) return e;
              if (((e = d("knssoId")), e)) return e;
              break;
            case "connectId":
              if (((e = a && localStorage.getItem("connectId")), e)) return e;
              break;
            case "trustpId":
              if (((e = a && localStorage.getItem("trustpid")), e)) return e;
              break;
            case "tapadId":
              if (((e = d("tapad_id")), e)) return e;
              break;
            case "publinkId":
              if (((e = d("pbjs_publink")), e)) return e;
              break;
            case "intentIqId":
              if (((e = d("intentIqId")), e)) return e;
              break;
            case "fabrickId":
              if (((e = a && localStorage.getItem("pbjs_fabrickId")), e))
                return e;
              if (((e = d("pbjs_fabrickId")), e)) return e;
              break;
            case "britepoolId":
              if (((e = d("britepoolid")), e)) return e;
              break;
            case "amxId":
              if (((e = a && localStorage.getItem("amxId")), e)) return e;
              break;
            case "adtelligent":
              if (((e = a && localStorage.getItem("adt_id")), e)) return e;
          }
          return null;
        } catch (e) {
          return null;
        }
      };
    },
  },
]);
