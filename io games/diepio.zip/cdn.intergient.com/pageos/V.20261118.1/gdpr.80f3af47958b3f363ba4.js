"use strict";
(self.webpackChunkpageos = self.webpackChunkpageos || []).push([
  [264],
  {
    4969(e, t, i) {
      i.d(t, { default: () => d });
      var n = i(3948),
        o = i(6755),
        s = i(7690),
        a = i(1157);
      class d {
        thirdPartyActionComplete = !1;
        constructor(e, t) {
          (this.euConsentCookie = (0, n.UM)("euconsent")),
            s.dd.info("Consent String", {
              euConsentCookie: this.euConsentCookie,
            }),
            (this.hasPlaywireCmp = a.A.isUsingPlaywireCmp() || t),
            (this.hasGoogleTag = window.googletag && window.googletag.apiReady),
            (this.binaryConsent = null),
            (this.acString = null),
            (this.MODULE = e),
            (this.isCOPPA = e.isCOPPA),
            (this.advertisementCookiesEnabled = e.advertisementCookiesEnabled),
            (this.isPrivacyRestricted =
              e.isCOPPA || !1 === e.advertisementCookiesEnabled),
            (this.forceGoogleCmp = n.Ru.forceGoogleCmp),
            (this.useIubendaCmp =
              !0 === window.pwEdgeYieldOptions?.iubendaCmpEnabled),
            this.useIubendaCmp && (this.forceGoogleCmp = null),
            (this.retryCountLimit = a.A.getTcfRetries() || 10),
            (this.millisecondsInterval = a.A.getTcfMsInterval() || 500);
          const i = window.pwIubendaCmp?.loaderTimeoutMs;
          this.useIubendaCmp &&
            Number.isFinite(i) &&
            i > 0 &&
            (this.retryCountLimit = Math.max(
              this.retryCountLimit,
              Math.ceil(i / this.millisecondsInterval) + 1
            )),
            (e.getACString = this.getACString.bind(this)),
            (e.getConsentData = this.getConsentData.bind(this)),
            (e.getConsentString = this.getConsentString.bind(this)),
            (e.getTCString = this.getTCString.bind(this)),
            (e.hasConsent = !1),
            this.loadCmp();
        }
        loadCmp() {
          this.useIubendaCmp && (window.PageOS.gdpr.tcfVersion = 2);
          const e =
            "function" == typeof window.__tcfapi ||
            (!this.useIubendaCmp && "function" == typeof window.__cmp);
          let t = 0;
          switch (
            ((t = e ? t : 4),
            (t = e && this.hasGoogleTag ? 3 : t),
            (t = e ? 2 : t),
            (t =
              this.isCOPPA || !1 === this.advertisementCookiesEnabled ? 1 : t),
            this.forceGoogleCmp && (t = 3),
            t)
          ) {
            case 1:
              s.dd.info("User in EU but is a COPPA site"), this.handleNoCMP();
              break;
            case 2:
              this.hasPlaywireCmp &&
                s.dd.warn("3rd party CMP found; ignoring Playwire settings"),
                (window.PageOS.gdpr.tcfVersion =
                  "function" == typeof window.__tcfapi ? 2 : 1),
                s.dd.info("User in EU. Using CMP", "3rd party CMP"),
                s.dd.info("CMP module", { playwireCMP: 0 }),
                this.handleCMP();
              break;
            case 3:
              s.dd.info("User in EU. Checking if Google CMP should be used"),
                (window.PageOS.gdpr.tcfVersion = 2),
                this.handleCMP().then(() => {
                  s.dd.info("Using CMP", "Google CMP"),
                    s.dd.info("CMP module", { playwireCMP: 0 });
                }),
                window.PageOS.BUS.on("no_cmp_found", () => {
                  s.dd.info("No CMP found"), this.handleNoCMP();
                });
              break;
            case 4:
              s.dd.info("User in EU but No CMP found, will keep trying"),
                this.handleNoCMP();
          }
        }
        cmpFunction(e, t) {
          return new Promise((i, n) =>
            "string" != typeof e
              ? n("Invalid cmp function")
              : "function" != typeof __cmp
              ? n("Consent not available")
              : void window.__cmp(e, null, (e, o) => {
                  if (!o) return n("Error __cmp function call failed.");
                  i(t ? e[t] : e);
                })
          );
        }
        getACString() {
          return Promise.resolve(this.acString);
        }
        getConsentData() {
          return Promise.resolve({ acString: this.acString });
        }
        _handleTCData() {
          return new Promise((e, t) => {
            if (
              (window.PageOS.gdpr.fetchingFailed && e(),
              2 !== window.PageOS.gdpr.tcfVersion)
            )
              e();
            else {
              if (void 0 === window.__tcfapi && !this.useIubendaCmp)
                return (
                  (window.googlefc = window.googlefc || {}),
                  (window.googlefc.callbackQueue =
                    window.googlefc.callbackQueue || []),
                  void window.googlefc.callbackQueue.push({
                    CONSENT_DATA_READY: () =>
                      window.__tcfapi("addEventListener", 2.2, (t, i) => {
                        i && e(t);
                      }),
                  })
                );
              this._handleThirdPartyTcfApi(() => {
                window.__tcfapi("addEventListener", 2, (t, i) => {
                  i &&
                    (("tcloaded" !== t.eventStatus &&
                      "useractioncomplete" !== t.eventStatus) ||
                      e(t));
                });
              });
            }
          });
        }
        handleCMP() {
          return this._handleTCData()
            .then((e) => {
              (this.acString = e ? e.addtlConsent : ""),
                (this.MODULE.hasWindowCMP = !0),
                (this.MODULE.hasCMP = () => Promise.resolve(!0)),
                (this.MODULE.consent = e);
              const t = 2 === window.PageOS.gdpr.tcfVersion,
                i = !1 === e?.gdprApplies;
              (this.MODULE.hasConsent =
                !(!i && (void 0 !== e || t)) ||
                !0 === e?.purpose?.consents?.[1]),
                (this.MODULE.isPrivacyRestricted =
                  this.isPrivacyRestricted ||
                  !this.MODULE.hasConsent ||
                  (0, o.x)()),
                ("" !== this.acString || (0, o.x)()) &&
                  window.googletag.cmd.push(() => {
                    window.googletag
                      .pubads()
                      .setPrivacySettings({ nonPersonalizedAds: !1 });
                  }),
                window.PageOS.BUS.emit("gdpr_ready"),
                window.dispatchEvent(new Event("PageosGDPRLoaded"));
            })
            .catch((e) => {
              s.dd.error("Binary consent", {
                message: e.message,
                stack: e.stack,
              });
            });
        }
        handleNoCMP() {
          if (this.isCOPPA || !1 === this.advertisementCookiesEnabled)
            return (
              (this.MODULE.hasWindowCMP = !1),
              (this.MODULE.hasCMP = () => Promise.resolve(!1)),
              window.PageOS.BUS.emit("gdpr_ready"),
              void window.dispatchEvent(new Event("PageosGDPRLoaded"))
            );
          this._checkExistTCFAPI(this.millisecondsInterval)
            .then(() => {
              let e = !1;
              const t = (i, n) => {
                if (n) {
                  window.PageOS.gdpr.tcfVersion =
                    "function" == typeof window.__tcfapi ? 2 : 1;
                  const n = i.eventStatus;
                  "cmpuishown" === n &&
                    s.dd.info(
                      "User in EU and CMP found, waiting for consent",
                      i
                    );
                  ["tcloaded", "useractioncomplete"].includes(n) &&
                    (window.__tcfapi("removeEventListener", 2, t, i.listenerId),
                    s.dd.info("GDPR consent given", i),
                    e || ((e = !0), this.handleCMP()));
                }
              };
              window.__tcfapi("addEventListener", 2, t);
            })
            .catch(() => {
              window.PageOS.BUS.emit("no_cmp_found"),
                (this.MODULE.hasWindowCMP = !1),
                (this.MODULE.hasCMP = () => Promise.resolve(!1)),
                (this.MODULE.hasConsent = !1),
                window.googletag.cmd.push(() => {
                  window.googletag
                    .pubads()
                    .setPrivacySettings({ nonPersonalizedAds: !0 });
                }),
                window.PageOS.BUS.emit("gdpr_ready"),
                window.dispatchEvent(new Event("PageosGDPRLoaded"));
            });
        }
        getConsentString() {
          return new Promise((e, t) => {
            if (this.euConsentCookie) return e(this.euConsentCookie);
            if (2 !== window.PageOS.gdpr.tcfVersion)
              this.cmpFunction("getConsentData", "consentData")
                .then((t) => {
                  e(t);
                })
                .catch((e) => {
                  s.dd.error("Consent String", {
                    message: e.message,
                    stack: e.stack,
                  }),
                    t(e);
                });
            else {
              if (void 0 === window.__tcfapi && !this.useIubendaCmp)
                return (
                  (window.googlefc = window.googlefc || {}),
                  (window.googlefc.callbackQueue =
                    window.googlefc.callbackQueue || []),
                  void window.googlefc.callbackQueue.push({
                    CONSENT_DATA_READY: () =>
                      window.__tcfapi("addEventListener", 2.2, (t, i) => {
                        i && e(t.tcString);
                      }),
                  })
                );
              this._handleThirdPartyTcfApi(() => {
                window.__tcfapi("addEventListener", 2, (t, i) => {
                  i &&
                    (("tcloaded" !== t.eventStatus &&
                      "useractioncomplete" !== t.eventStatus) ||
                      e(t.tcString));
                });
              });
            }
          });
        }
        _checkExistTCFAPI = (e) => {
          let t = 0;
          return new Promise((i, n) => {
            const o = setInterval(() => {
              if (void 0 !== window.__tcfapi) return clearInterval(o), void i();
              t++, t >= this.retryCountLimit && (clearInterval(o), n());
            }, e);
          });
        };
        getTCString() {
          return (0, n.UM)("euconsent-v2");
        }
        _handleThirdPartyTcfApi = (e) => {
          const t = (i, n) => {
            if ((this.thirdPartyActionComplete && e && e(), n)) {
              const n = i.eventStatus;
              ["tcloaded", "useractioncomplete"].includes(n) &&
                ((this.thirdPartyActionComplete = !0),
                e && e(),
                window.__tcfapi("removeEventListener", 2, t, i.listenerId));
            }
          };
          this._checkExistTCFAPI(this.millisecondsInterval)
            .then(() => {
              window.__tcfapi("addEventListener", 2, t);
            })
            .catch(() => {
              window.PageOS.BUS.emit("no_cmp_found");
            });
        };
      }
    },
  },
]);
