"use strict";
(self.webpackChunkpageos = self.webpackChunkpageos || []).push([
  [950],
  {
    2337(e, n, r) {
      function t(e) {
        try {
          const n = document.createElement("canvas"),
            r = n.getContext("webgl") || n.getContext("experimental-webgl");
          if (r) {
            const n = r.getExtension("WEBGL_debug_renderer_info"),
              t = {
                vendor: r.getParameter(n.UNMASKED_VENDOR_WEBGL),
                renderer: r.getParameter(n.UNMASKED_RENDERER_WEBGL),
              };
            return (
              e &&
                localStorage.setItem("PageOS_Environment", JSON.stringify(t)),
              t
            );
          }
          return { vendor: null, renderer: null };
        } catch (e) {
          return { vendor: null, renderer: null };
        }
      }
      r.d(n, { default: () => t });
    },
  },
]);
