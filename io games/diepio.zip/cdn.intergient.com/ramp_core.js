window.cmpVersion = 2;
window.tycheSampling = true;
window.tycheSamplingRate = 0.05;
window.rampSampling = true;
window.rampSamplingRate = 0.05;
window.rampMinimal = window.rampMinimal || false;
window._pageViewSR = 1;
window._pageViewSampling = false;
window._adImpressionSampling = false;
window._adImpressionSR = 1;
window._pwLogger = window._pwLogger || {
  pageos: {},
  tyche: {},
  bolt: {},
  PAGEOS_HEAVY_AD: {},
  PAGEOS_REPORTING_OBSERVER: {},
};
window._pwUserInCA = false;
window._pwFpSampling = 1;
window._pwUserCC = "IT";
window._pwUserBrowserName = "Chrome";
window._pwUserDeviceType = "desktop";
window._pwUserIp = "82.90.162.235";
window._pwApsPrebidTrafficPercentage = 2;
window.pwEdgeFlags = Object.assign(
  {
    cdnHostname: "cdn.intergient.com",
    benchmarks: { sampling: true, rate: 0.001 },
    adlDisabled: ["desktop", "tablet", "mobile"],
  },
  window.pwEdgeFlags
);
window.pwEdgeFlags.pageosVersion =
  window.pwEdgeFlags.pageosVersion || "V.20261118.1";
window.pwEdgeFlags.dmpDisabledDomains = window.pwEdgeFlags
  .dmpDisabledDomains || [
  "coolmath.com",
  "coolmathgames.com",
  "nitrotype.com",
  "typing.com",
];
window._pwBotScore = 11;
("use strict");
(() => {
  var g = "pwBotScore",
    l = (t) => {
      let i = `${t}`,
        n = new Date();
      n.setTime(n.getTime() + 2880 * 60 * 1e3);
      let c = "/",
        a = window.location.hostname,
        e = window.location.protocol === "https:",
        o = `${g}=${i}; expires=${n.toUTCString()}; path=${c}; domain=${a}; secure=${e};`;
      document.cookie = o;
    },
    h = () => {
      let t = window.location.hostname.replace(/^www\./, ""),
        i = window.ramp.activeConfig ? window.ramp.activeConfig.id : "null",
        n = window.location.pathname,
        c = `https://cdn.intergi.com/bot_score/publisher/${i}/domain/${t}`,
        a = new URL(c);
      a.searchParams.append("path", n);
      let e = a.toString(),
        o = document.createElement("script");
      (o.type = "text/javascript"),
        (o.src = `${e}`),
        (o.async = !0),
        (o.onload = () => {
          typeof window._pwBotScore > "u" || l(window._pwBotScore);
        }),
        document.head.appendChild(o);
    };
  (() => {
    (window.pwEdgeFlags = window.pwEdgeFlags || {}),
      (window.PageOS = window.PageOS || {}),
      (window.tyche = window.ramp || window.tyche),
      (window.ramp = window.tyche);
    let t = (e) => {
        if (e.cdnHostname) return e.cdnHostname;
        if (e.cdn)
          return e.cdn === "dev"
            ? "cdn.intergientdev.com"
            : "cdn.intergient.com";
      },
      i = (e) => (e === "cdn.intergient.com" ? "cdn.intergientdev.com" : e),
      n = () => {
        let e = typeof window.ramp < "u",
          o = window.ramp && typeof window.ramp.config == "string",
          d = window.PageOS.adsPerformance;
        return !!(!e || o || d);
      };
    ((e) => {
      if (!window.PageOS.loadedRampCore) {
        if (((window.PageOS.loadedRampCore = !0), n())) {
          e();
          return;
        }
        window.PageOS.run = () => {
          delete window.PageOS.run, e();
        };
      }
    })(() => {
      let e = (() => {
          try {
            return new URLSearchParams(window.location.search);
          } catch {
            return new URLSearchParams();
          }
        })(),
        o = e.get("pw_pageos_dev"),
        d = e.get("pw_pageos");
      window.ramp.activeConfig =
        window.ramp.activeConfig || window.ramp.mvpConfig;
      let m =
          window.ramp.activeConfig &&
          window.ramp.activeConfig.ad_code &&
          window.ramp.activeConfig.ad_code.pageos,
        u = d || m || window.pwEdgeFlags.pageosVersion,
        w = t(window.pwEdgeFlags),
        p = `//${w}/pageos/${u}/pageos.js`;
      o && (p = `//${i(w)}/pageos/${o}/pageos.js`);
      let r = document.createElement("script");
      if (
        ((r.type = "text/javascript"),
        (r.src = p),
        (r.async = !0),
        document.head.appendChild(r),
        typeof window._pwBotScore > "u")
      ) {
        let s = document.cookie
          .split("; ")
          .find((f) => f.startsWith(g))
          ?.split("=")[1];
        s ? (window._pwBotScore = parseInt(s, 10)) : h();
      }
    });
  })();
})();
