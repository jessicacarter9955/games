window.ramp.loadCoreJS = true;
window._pwTycheAB = { name: "na", type: "A" };
window._pwUserCC = "IT";
window._pwBotScore = 2;
window._pwUserDeviceType = "desktop";
window.rampMinimal = window.rampMinimal || false;
window.ramp.configurations = {
  id: 78353,
  url: "diep.io",
  config: {
    key: "1025909_78353_primary_config",
    name: "Primary Config",
    version: "b5727e6b",
    weight: 100,
  },
  config_id: "1025909_78353_primary_config",
  version: 3,
  settings: {
    publisherId: 1025909,
    isMobile: "auto",
    blockthrough: true,
    directAdServingDisabled: false,
    adLightning: false,
    priceFloors: 2,
    displayPriceFloors: 2,
    videoPriceFloors: 2,
    nielsen: false,
    bidShapingEnabled: true,
    multiSelect: false,
    bidAdjustments: { display: {}, video: {} },
    precontentAppearance: {
      preloader: {
        background: "rgb(0,0,0)",
        loaderType: "three-bounce",
        loaderColor: "rgb(255,255,255)",
        showLogo: false,
      },
    },
    language: "en",
    rampDelay: false,
    identity: {
      desktop: [
        "lexiconId",
        "id5",
        "lotame",
        "sharedId",
        "fabrick",
        "uid2",
        "liveRamp2",
        "criteo",
        "linkedinId",
        "liveIntentId",
        "intentIq",
        "amazon",
      ],
      mobile: [
        "lexiconId",
        "id5",
        "lotame",
        "sharedId",
        "fabrick",
        "uid2",
        "liveRamp2",
        "connectId",
        "hadronId",
        "criteo",
        "linkedinId",
        "liveIntentId",
        "intentIq",
        "amazon",
      ],
      tablet: [
        "lexiconId",
        "id5",
        "lotame",
        "sharedId",
        "fabrick",
        "uid2",
        "liveRamp2",
        "criteo",
        "linkedinId",
        "liveIntentId",
        "intentIq",
        "amazon",
      ],
    },
    rtdSettings: {
      desktop: ["optable"],
      mobile: ["optable"],
      tablet: ["optable"],
    },
    ctrTracking: true,
    categories: ["video_gaming"],
    iabIds: ["IAB9-30", "680"],
    multipliers: {
      "2026-11-23": { desktop: 0.5, mobile: 0.5 },
      "2026-11-24": { desktop: 0.5, mobile: 0.5 },
      display: {
        "2026-11-23": { desktop: 0.5, mobile: 0.5 },
        "2026-11-24": { desktop: 0.5, mobile: 0.5 },
      },
      video: {
        "2026-11-23": { desktop: 0.5, mobile: 0.5 },
        "2026-11-24": { desktop: 0.5, mobile: 0.5 },
      },
    },
    fallbackPriceFloors: {
      display: { desktop: 0.04, mobile: 0.04, tablet: 0.04 },
      video: { desktop: 0.16, mobile: 0.16, tablet: 0.16 },
    },
    targeting: {
      salad: "chef",
      bowl: { dd: "mango", di: "pineapple", vd: "mango", vi: "pineapple" },
    },
    customCssSrc:
      "https://config.playwire.com/1025909/v2/websites/78353/styles.css",
    confiantConfig: { enabled: false },
    iframedApsTag: false,
    mlAuctionTimeoutsConfig: { enabled: false, mediaTypes: [] },
  },
  headerBidding: {
    display: {
      desktop: {
        timeout: 3000,
        order: [
          "amazon",
          "appnexus",
          "s2s_appnexus",
          "rubicon",
          "s2s_rubicon",
          "openx",
          "s2s_openx",
          "ix",
          "s2s_ix",
          "gumgum",
          "s2s_gumgum",
          "s2s_sonobi",
          "triplelift",
          "s2s_triplelift",
          "sharethrough",
          "s2s_sharethrough",
          "pubmatic",
          "s2s_pubmatic",
          "criteo",
          "ttd",
          "s2s_vidazoo",
          "teads",
          "medianet",
          "s2s_medianet",
          "seedtag",
          "richaudience",
          "s2s_richaudience",
          "equativ",
          "s2s_equativ",
        ],
        s2sTimeout: 2250,
        setPriceFloor: [
          "amazon",
          "appnexus",
          "s2s_appnexus",
          "rubicon",
          "s2s_rubicon",
          "openx",
          "s2s_openx",
          "ix",
          "s2s_ix",
          "gumgum",
          "s2s_gumgum",
          "s2s_sonobi",
          "triplelift",
          "s2s_triplelift",
          "sharethrough",
          "s2s_sharethrough",
          "pubmatic",
          "s2s_pubmatic",
          "criteo",
          "ttd",
          "s2s_vidazoo",
          "teads",
          "medianet",
          "s2s_medianet",
          "seedtag",
          "richaudience",
          "s2s_richaudience",
          "equativ",
          "s2s_equativ",
        ],
        userSyncBidders: [
          "amazon",
          "appnexus",
          "s2s_appnexus",
          "rubicon",
          "s2s_rubicon",
          "openx",
          "s2s_openx",
          "ix",
          "s2s_ix",
          "gumgum",
          "s2s_gumgum",
          "s2s_sonobi",
          "triplelift",
          "s2s_triplelift",
          "sharethrough",
          "s2s_sharethrough",
          "pubmatic",
          "s2s_pubmatic",
          "criteo",
          "ttd",
          "s2s_vidazoo",
          "teads",
          "medianet",
          "s2s_medianet",
          "seedtag",
          "richaudience",
          "s2s_richaudience",
          "equativ",
          "s2s_equativ",
        ],
        randomize: true,
        forcedBidders: ["seedtag"],
      },
      mobile: {
        timeout: 3000,
        order: [
          "amazon",
          "appnexus",
          "s2s_appnexus",
          "rubicon",
          "s2s_rubicon",
          "openx",
          "s2s_openx",
          "ix",
          "s2s_ix",
          "gumgum",
          "s2s_gumgum",
          "s2s_sonobi",
          "triplelift",
          "s2s_triplelift",
          "sharethrough",
          "s2s_sharethrough",
          "pubmatic",
          "s2s_pubmatic",
          "criteo",
          "ttd",
          "s2s_vidazoo",
          "teads",
          "medianet",
          "s2s_medianet",
          "seedtag",
          "richaudience",
          "s2s_richaudience",
          "equativ",
          "s2s_equativ",
        ],
        s2sTimeout: 2250,
        setPriceFloor: [
          "amazon",
          "appnexus",
          "s2s_appnexus",
          "rubicon",
          "s2s_rubicon",
          "openx",
          "s2s_openx",
          "ix",
          "s2s_ix",
          "gumgum",
          "s2s_gumgum",
          "s2s_sonobi",
          "triplelift",
          "s2s_triplelift",
          "sharethrough",
          "s2s_sharethrough",
          "pubmatic",
          "s2s_pubmatic",
          "criteo",
          "ttd",
          "s2s_vidazoo",
          "teads",
          "medianet",
          "s2s_medianet",
          "seedtag",
          "richaudience",
          "s2s_richaudience",
          "equativ",
          "s2s_equativ",
        ],
        userSyncBidders: [
          "amazon",
          "appnexus",
          "s2s_appnexus",
          "rubicon",
          "s2s_rubicon",
          "openx",
          "s2s_openx",
          "ix",
          "s2s_ix",
          "gumgum",
          "s2s_gumgum",
          "s2s_sonobi",
          "triplelift",
          "s2s_triplelift",
          "sharethrough",
          "s2s_sharethrough",
          "pubmatic",
          "s2s_pubmatic",
          "criteo",
          "ttd",
          "s2s_vidazoo",
          "teads",
          "medianet",
          "s2s_medianet",
          "seedtag",
          "richaudience",
          "s2s_richaudience",
          "equativ",
          "s2s_equativ",
        ],
        randomize: true,
        forcedBidders: ["seedtag"],
      },
      tablet: {
        timeout: 3000,
        order: [
          "amazon",
          "appnexus",
          "s2s_appnexus",
          "rubicon",
          "s2s_rubicon",
          "openx",
          "s2s_openx",
          "ix",
          "s2s_ix",
          "gumgum",
          "s2s_gumgum",
          "s2s_sonobi",
          "triplelift",
          "s2s_triplelift",
          "sharethrough",
          "s2s_sharethrough",
          "pubmatic",
          "s2s_pubmatic",
          "criteo",
          "ttd",
          "s2s_vidazoo",
          "teads",
          "medianet",
          "s2s_medianet",
          "seedtag",
          "richaudience",
          "s2s_richaudience",
          "equativ",
          "s2s_equativ",
        ],
        s2sTimeout: 2250,
        setPriceFloor: [
          "amazon",
          "appnexus",
          "s2s_appnexus",
          "rubicon",
          "s2s_rubicon",
          "openx",
          "s2s_openx",
          "ix",
          "s2s_ix",
          "gumgum",
          "s2s_gumgum",
          "s2s_sonobi",
          "triplelift",
          "s2s_triplelift",
          "sharethrough",
          "s2s_sharethrough",
          "pubmatic",
          "s2s_pubmatic",
          "criteo",
          "ttd",
          "s2s_vidazoo",
          "teads",
          "medianet",
          "s2s_medianet",
          "seedtag",
          "richaudience",
          "s2s_richaudience",
          "equativ",
          "s2s_equativ",
        ],
        userSyncBidders: [
          "amazon",
          "appnexus",
          "s2s_appnexus",
          "rubicon",
          "s2s_rubicon",
          "openx",
          "s2s_openx",
          "ix",
          "s2s_ix",
          "gumgum",
          "s2s_gumgum",
          "s2s_sonobi",
          "triplelift",
          "s2s_triplelift",
          "sharethrough",
          "s2s_sharethrough",
          "pubmatic",
          "s2s_pubmatic",
          "criteo",
          "ttd",
          "s2s_vidazoo",
          "teads",
          "medianet",
          "s2s_medianet",
          "seedtag",
          "richaudience",
          "s2s_richaudience",
          "equativ",
          "s2s_equativ",
        ],
        randomize: true,
        forcedBidders: ["seedtag"],
      },
    },
    video: {
      desktop: {
        timeout: 2250,
        order: [
          "amazon",
          "appnexus",
          "s2s_appnexus",
          "ix",
          "s2s_ix",
          "rubicon",
          "s2s_rubicon",
          "openx",
          "s2s_openx",
          "pubmatic",
          "s2s_pubmatic",
          "sharethrough",
          "s2s_sharethrough",
          "triplelift",
          "s2s_triplelift",
          "criteo",
          "s2s_gumgum",
          "ttd",
          "s2s_vidazoo",
          "s2s_sonobi",
          "medianet",
          "s2s_medianet",
          "seedtag",
          "richaudience",
          "s2s_richaudience",
          "equativ",
          "s2s_equativ",
        ],
        s2sTimeout: 2250,
        setPriceFloor: [
          "amazon",
          "appnexus",
          "s2s_appnexus",
          "ix",
          "s2s_ix",
          "rubicon",
          "s2s_rubicon",
          "openx",
          "s2s_openx",
          "pubmatic",
          "s2s_pubmatic",
          "sharethrough",
          "s2s_sharethrough",
          "triplelift",
          "s2s_triplelift",
          "criteo",
          "s2s_gumgum",
          "ttd",
          "s2s_vidazoo",
          "s2s_sonobi",
          "medianet",
          "s2s_medianet",
          "seedtag",
          "richaudience",
          "s2s_richaudience",
          "equativ",
          "s2s_equativ",
        ],
        userSyncBidders: [
          "amazon",
          "appnexus",
          "s2s_appnexus",
          "ix",
          "s2s_ix",
          "rubicon",
          "s2s_rubicon",
          "openx",
          "s2s_openx",
          "pubmatic",
          "s2s_pubmatic",
          "sharethrough",
          "s2s_sharethrough",
          "triplelift",
          "s2s_triplelift",
          "criteo",
          "s2s_gumgum",
          "ttd",
          "s2s_vidazoo",
          "s2s_sonobi",
          "medianet",
          "s2s_medianet",
          "seedtag",
          "richaudience",
          "s2s_richaudience",
          "equativ",
          "s2s_equativ",
        ],
        randomize: true,
        requestBeforeTimeout: false,
      },
      mobile: {
        timeout: 2250,
        order: [
          "amazon",
          "appnexus",
          "s2s_appnexus",
          "ix",
          "s2s_ix",
          "rubicon",
          "s2s_rubicon",
          "openx",
          "s2s_openx",
          "pubmatic",
          "s2s_pubmatic",
          "sharethrough",
          "s2s_sharethrough",
          "triplelift",
          "s2s_triplelift",
          "criteo",
          "s2s_gumgum",
          "ttd",
          "s2s_vidazoo",
          "s2s_sonobi",
          "medianet",
          "s2s_medianet",
          "seedtag",
          "richaudience",
          "s2s_richaudience",
          "equativ",
          "s2s_equativ",
        ],
        s2sTimeout: 2250,
        setPriceFloor: [
          "amazon",
          "appnexus",
          "s2s_appnexus",
          "ix",
          "s2s_ix",
          "rubicon",
          "s2s_rubicon",
          "openx",
          "s2s_openx",
          "pubmatic",
          "s2s_pubmatic",
          "sharethrough",
          "s2s_sharethrough",
          "triplelift",
          "s2s_triplelift",
          "criteo",
          "s2s_gumgum",
          "ttd",
          "s2s_vidazoo",
          "s2s_sonobi",
          "medianet",
          "s2s_medianet",
          "seedtag",
          "richaudience",
          "s2s_richaudience",
          "equativ",
          "s2s_equativ",
        ],
        userSyncBidders: [
          "amazon",
          "appnexus",
          "s2s_appnexus",
          "ix",
          "s2s_ix",
          "rubicon",
          "s2s_rubicon",
          "openx",
          "s2s_openx",
          "pubmatic",
          "s2s_pubmatic",
          "sharethrough",
          "s2s_sharethrough",
          "triplelift",
          "s2s_triplelift",
          "criteo",
          "s2s_gumgum",
          "ttd",
          "s2s_vidazoo",
          "s2s_sonobi",
          "medianet",
          "s2s_medianet",
          "seedtag",
          "richaudience",
          "s2s_richaudience",
          "equativ",
          "s2s_equativ",
        ],
        randomize: true,
        requestBeforeTimeout: false,
      },
    },
  },
  precontentUrl: "https://config.playwire.com/1025909/v2/pre_content.json",
  type: "website",
  server: "DFP_NON_COPPA",
  countryGroups: {
    international: [
      "AF",
      "AX",
      "AL",
      "DZ",
      "AS",
      "AD",
      "AO",
      "AI",
      "AQ",
      "AG",
      "AR",
      "AM",
      "AW",
      "AC",
      "AU",
      "AT",
      "AZ",
      "BS",
      "BH",
      "BD",
      "BB",
      "BY",
      "BE",
      "BZ",
      "BJ",
      "BM",
      "BT",
      "BO",
      "BA",
      "BW",
      "BV",
      "BR",
      "IO",
      "VG",
      "BN",
      "BG",
      "BF",
      "BI",
      "KH",
      "CM",
      "CA",
      "IC",
      "CV",
      "BQ",
      "KY",
      "CF",
      "EA",
      "TD",
      "CL",
      "CN",
      "CX",
      "CP",
      "CC",
      "CO",
      "KM",
      "CG",
      "CD",
      "CK",
      "CR",
      "CI",
      "HR",
      "CU",
      "CW",
      "CY",
      "CZ",
      "DK",
      "DG",
      "DJ",
      "DM",
      "DO",
      "EC",
      "EG",
      "SV",
      "GQ",
      "ER",
      "EE",
      "ET",
      "EU",
      "FK",
      "FO",
      "FJ",
      "FI",
      "FR",
      "GF",
      "PF",
      "TF",
      "GA",
      "GM",
      "GE",
      "DE",
      "GH",
      "GI",
      "GR",
      "GL",
      "GD",
      "GP",
      "GU",
      "GT",
      "GG",
      "GN",
      "GW",
      "GY",
      "HT",
      "HM",
      "HN",
      "HK",
      "HU",
      "IS",
      "IN",
      "ID",
      "IR",
      "IQ",
      "IE",
      "IM",
      "IL",
      "IT",
      "JM",
      "JP",
      "JE",
      "JO",
      "KZ",
      "KE",
      "KI",
      "XK",
      "KW",
      "KG",
      "LA",
      "LV",
      "LB",
      "LS",
      "LR",
      "LY",
      "LI",
      "LT",
      "LU",
      "MO",
      "MK",
      "MG",
      "MW",
      "MY",
      "MV",
      "ML",
      "MT",
      "MH",
      "MQ",
      "MR",
      "MU",
      "YT",
      "MX",
      "FM",
      "MD",
      "MC",
      "MN",
      "ME",
      "MS",
      "MA",
      "MZ",
      "MM",
      "NA",
      "NR",
      "NP",
      "NL",
      "AN",
      "NC",
      "NZ",
      "NI",
      "NE",
      "NG",
      "NU",
      "NF",
      "KP",
      "MP",
      "NO",
      "OM",
      "QO",
      "PK",
      "PW",
      "PS",
      "PA",
      "PG",
      "PY",
      "PE",
      "PH",
      "PN",
      "PL",
      "PT",
      "PR",
      "QA",
      "RE",
      "RO",
      "RW",
      "SX",
      "WS",
      "SM",
      "ST",
      "SA",
      "SN",
      "RS",
      "SC",
      "SL",
      "SG",
      "SK",
      "SI",
      "SB",
      "SO",
      "ZA",
      "GS",
      "KR",
      "SS",
      "ES",
      "LK",
      "BL",
      "SH",
      "KN",
      "LC",
      "MF",
      "PM",
      "VC",
      "SD",
      "SR",
      "SJ",
      "SZ",
      "SE",
      "CH",
      "SY",
      "TW",
      "TJ",
      "TZ",
      "TH",
      "TL",
      "TG",
      "TK",
      "TO",
      "TT",
      "TA",
      "TN",
      "TR",
      "TM",
      "TC",
      "TV",
      "UM",
      "VI",
      "UG",
      "UA",
      "AE",
      "GB",
      "UY",
      "UZ",
      "VU",
      "VA",
      "VE",
      "VN",
      "WF",
      "EH",
      "YE",
      "ZM",
      "ZW",
    ],
    tier1: ["AU", "AT", "BE", "CA", "FR", "DE", "IT", "NL", "NZ", "ES", "GB"],
    rest_of_world: [
      "AF",
      "AX",
      "AL",
      "DZ",
      "AS",
      "AD",
      "AO",
      "AI",
      "AQ",
      "AG",
      "AR",
      "AM",
      "AW",
      "AC",
      "AZ",
      "BS",
      "BH",
      "BD",
      "BB",
      "BY",
      "BZ",
      "BJ",
      "BM",
      "BT",
      "BO",
      "BA",
      "BW",
      "BV",
      "BR",
      "IO",
      "VG",
      "BN",
      "BG",
      "BF",
      "BI",
      "KH",
      "CM",
      "IC",
      "CV",
      "BQ",
      "KY",
      "CF",
      "EA",
      "TD",
      "CL",
      "CN",
      "CX",
      "CP",
      "CC",
      "CO",
      "KM",
      "CG",
      "CD",
      "CK",
      "CR",
      "CI",
      "HR",
      "CU",
      "CW",
      "CY",
      "CZ",
      "DK",
      "DG",
      "DJ",
      "DM",
      "DO",
      "EC",
      "EG",
      "SV",
      "GQ",
      "ER",
      "EE",
      "ET",
      "EU",
      "FK",
      "FO",
      "FJ",
      "FI",
      "GF",
      "PF",
      "TF",
      "GA",
      "GM",
      "GE",
      "GH",
      "GI",
      "GR",
      "GL",
      "GD",
      "GP",
      "GU",
      "GT",
      "GG",
      "GN",
      "GW",
      "GY",
      "HT",
      "HM",
      "HN",
      "HK",
      "HU",
      "IS",
      "IN",
      "ID",
      "IR",
      "IQ",
      "IE",
      "IM",
      "IL",
      "JM",
      "JP",
      "JE",
      "JO",
      "KZ",
      "KE",
      "KI",
      "XK",
      "KW",
      "KG",
      "LA",
      "LV",
      "LB",
      "LS",
      "LR",
      "LY",
      "LI",
      "LT",
      "LU",
      "MO",
      "MK",
      "MG",
      "MW",
      "MY",
      "MV",
      "ML",
      "MT",
      "MH",
      "MQ",
      "MR",
      "MU",
      "YT",
      "MX",
      "FM",
      "MD",
      "MC",
      "MN",
      "ME",
      "MS",
      "MA",
      "MZ",
      "MM",
      "NA",
      "NR",
      "NP",
      "AN",
      "NC",
      "NI",
      "NE",
      "NG",
      "NU",
      "NF",
      "KP",
      "MP",
      "NO",
      "OM",
      "QO",
      "PK",
      "PW",
      "PS",
      "PA",
      "PG",
      "PY",
      "PE",
      "PH",
      "PN",
      "PL",
      "PT",
      "PR",
      "QA",
      "RE",
      "RO",
      "RW",
      "SX",
      "WS",
      "SM",
      "ST",
      "SA",
      "SN",
      "RS",
      "SC",
      "SL",
      "SG",
      "SK",
      "SI",
      "SB",
      "SO",
      "ZA",
      "GS",
      "KR",
      "SS",
      "LK",
      "BL",
      "SH",
      "KN",
      "LC",
      "MF",
      "PM",
      "VC",
      "SD",
      "SR",
      "SJ",
      "SZ",
      "SE",
      "CH",
      "SY",
      "TW",
      "TJ",
      "TZ",
      "TH",
      "TL",
      "TG",
      "TK",
      "TO",
      "TT",
      "TA",
      "TN",
      "TR",
      "TM",
      "TC",
      "TV",
      "UM",
      "VI",
      "UG",
      "UA",
      "AE",
      "UY",
      "UZ",
      "VU",
      "VA",
      "VE",
      "VN",
      "WF",
      "EH",
      "YE",
      "ZM",
      "ZW",
    ],
    video_row: [
      "AF",
      "AL",
      "DZ",
      "AS",
      "AD",
      "AO",
      "AI",
      "AG",
      "AR",
      "AM",
      "AW",
      "AZ",
      "BS",
      "BD",
      "BB",
      "BY",
      "BE",
      "BZ",
      "BJ",
      "BM",
      "BT",
      "BO",
      "BA",
      "BW",
      "IO",
      "VG",
      "BN",
      "BG",
      "BF",
      "BI",
      "KH",
      "CM",
      "CV",
      "BQ",
      "KY",
      "CF",
      "TD",
      "CN",
      "CX",
      "CO",
      "KM",
      "CG",
      "CD",
      "CK",
      "CR",
      "CI",
      "HR",
      "CW",
      "CY",
      "CZ",
      "DJ",
      "DM",
      "DO",
      "EC",
      "EG",
      "SV",
      "GQ",
      "ER",
      "EE",
      "ET",
      "FK",
      "FO",
      "FJ",
      "GF",
      "PF",
      "GA",
      "GM",
      "GE",
      "GH",
      "GI",
      "GR",
      "GL",
      "GD",
      "GP",
      "GU",
      "GT",
      "GG",
      "GN",
      "GW",
      "GY",
      "HT",
      "HN",
      "HU",
      "IS",
      "IN",
      "IQ",
      "IM",
      "IL",
      "JM",
      "JP",
      "JE",
      "JO",
      "KE",
      "XK",
      "KW",
      "KG",
      "LA",
      "LV",
      "LB",
      "LS",
      "LR",
      "LY",
      "LI",
      "LT",
      "LU",
      "MO",
      "MK",
      "MG",
      "MW",
      "MV",
      "ML",
      "MT",
      "MH",
      "MQ",
      "MR",
      "MU",
      "YT",
      "FM",
      "MD",
      "MC",
      "MN",
      "ME",
      "MS",
      "MA",
      "MZ",
      "MM",
      "NA",
      "NR",
      "NP",
      "NC",
      "NI",
      "NE",
      "NG",
      "NU",
      "NF",
      "MP",
      "OM",
      "PK",
      "PW",
      "PS",
      "PA",
      "PG",
      "PY",
      "PE",
      "PH",
      "PL",
      "PT",
      "QA",
      "RE",
      "RO",
      "RW",
      "SX",
      "WS",
      "SM",
      "ST",
      "SN",
      "RS",
      "SC",
      "SL",
      "SK",
      "SI",
      "SB",
      "SO",
      "KR",
      "SS",
      "LK",
      "BL",
      "SH",
      "LC",
      "MF",
      "PM",
      "VC",
      "SD",
      "SR",
      "SJ",
      "TW",
      "TJ",
      "TZ",
      "TL",
      "TG",
      "TO",
      "TT",
      "TN",
      "TM",
      "TC",
      "TV",
      "VI",
      "UG",
      "UA",
      "UY",
      "VU",
      "VE",
      "VN",
      "WF",
      "EH",
      "YE",
      "ZM",
      "ZW",
    ],
  },
  features: {},
  pageLayouts: [{ target: "ROS", path: null, desktop: {}, mobile: {} }],
  hbParams: {
    s2s_gumgum: { 0: { zone: "6cj92jaa" }, 1: { zone: "4xc7wesv" } },
    s2s_appnexus: {
      0: { placementId: "31702144", allowSmallerSizes: true },
      1: { placementId: "31702150", allowSmallerSizes: true },
    },
    s2s_ix: { 0: { siteId: "1064288" }, 1: { siteId: "1065794" } },
    s2s_openx: {
      0: { unit: "560438818", delDomain: "playwire-d.openx.net" },
      1: { unit: "560438819", delDomain: "playwire-d.openx.net" },
    },
    s2s_pubmatic: {
      0: { publisherId: "158326", adSlot: "5635259" },
      1: { publisherId: "158326", adSlot: "5635258" },
    },
    s2s_rubicon: { 0: { accountId: 12556, siteId: 538704, zoneId: 3320452 } },
    criteo: { 0: { pubid: "100128", networkId: "6163" } },
    rubicon: {
      0: { accountId: 12556, siteId: 110932, zoneId: 523774 },
      1: {
        zoneId: 1491090,
        siteId: 143146,
        accountId: 12556,
        video: { language: "en" },
      },
    },
    pubmatic: {
      0: { publisherId: "158326" },
      1: { publisherId: "158326", adSlot: "Multiformat" },
      2: {
        publisherId: "158326",
        adSlot: "2326622",
        outstreamAU: "na",
        video: { skippable: true, playbackmethod: ["2"] },
      },
    },
    ix: { 0: { siteId: "1031634" }, 1: { siteId: "505013" } },
    openx: {
      0: { unit: "562533925", delDomain: "playwire-d.openx.net" },
      1: { unit: "560694309", delDomain: "playwire-d.openx.net" },
    },
    gumgum: {
      0: { zone: "8ylgv2wd" },
      1: { zone: "8ylgv2wd", slot: "1111710" },
      2: { zone: "8ylgv2wd", slot: "1111717" },
      3: { zone: "8ylgv2wd", slot: "1111719" },
    },
    sharethrough: {
      0: { pkey: "RnfhQD1waBVnmuMbcM3OYxJV" },
      1: { pkey: "qenD6PIClUCADHZY7ceB8azS" },
      2: { pkey: "2rfd1ihU8HlNjfOrOLLLZkau" },
      3: { pkey: "wG96mn3j2qLmo1fvTAvjFmXZ" },
      4: { pkey: "SSj2vV3YZFuf6iex4lYoh4Fb" },
    },
    s2s_sharethrough: {
      0: { pkey: "9zPY2BvueDRy9FibUoDj1HBc" },
      1: { pkey: "H2JBrqtgNgg1poBEEaaS0VYq" },
      2: { pkey: "wFa1tyhf5z2RXaIXM5EFY41M" },
      3: { pkey: "wG96mn3j2qLmo1fvTAvjFmXZ" },
      4: { pkey: "SSj2vV3YZFuf6iex4lYoh4Fb" },
    },
    ttd: { 0: { supplySourceId: "playwire", publisherId: "1025909" } },
    s2s_medianet: {
      0: { cid: "8CUIBM874", crid: "760020879" },
      1: { cid: "8CUIBM874", crid: "764118168" },
    },
    kargo: { 0: { placementId: "123456" } },
    appnexus: {
      0: { placementId: "9735442", allowSmallerSizes: true },
      1: {
        placementId: "30088997",
        video: { skippable: true, playback_methods: ["auto_play_sound_off"] },
        allowSmallerSizes: true,
      },
    },
    msft: { 0: { placement_id: 9735442 }, 1: { placement_id: 30088997 } },
    s2s_msft: { 0: { placement_id: 31702144 }, 1: { placement_id: 31702150 } },
    yahooAds: {
      0: {
        pubId: "100031",
        siteId: "8a34aac0019b9b0766df81c956b20017",
        placementId: "playwire_display",
      },
      1: {
        pubId: "100031",
        siteId: "8a34aac0019b9b0766df81c956b20017",
        placementId: "playwire_outstream",
      },
    },
    triplelift: {
      0: { inventoryCode: "PW_RON_Bottom-Rail_pb" },
      1: { inventoryCode: "PW_RON_In-Content_pb" },
      2: { inventoryCode: "PW_RON_Sticky-Sidebar_pb" },
      3: {
        inventoryCode: "PW_RON_Outstream_pb",
        video: {
          context: "outstream",
          mimes: [
            "video/mp4",
            "video/webm",
            "application/javascript",
            "video/ogg",
          ],
        },
      },
    },
    s2s_triplelift: {
      0: { inventoryCode: "playwire_d_ron_loview_gensize_s2s" },
      1: { inventoryCode: "PW_RON_Native_Incontent_S2S" },
      2: { inventoryCode: "pw_RON_outstream_s2s" },
    },
    seedtag: {
      0: { publisherId: "68c05523d5bc140007b6b8d6", integrationType: "ronId" },
    },
    richaudience: { 0: { pid: "MP_oe8hSqrwwP", supplyType: "site" } },
    s2s_richaudience: { 0: { pid: "MP_oe8hSqrwwP", supplyType: "site" } },
    equativ: { 0: { networkId: 4080 } },
  },
  units: [
    {
      id: 127706,
      unit: "bottom_rail",
      path: "ROS",
      code: "/154013155,23359523682/1025909/78353/1025909-w:78353-bottom_rail/1025909-w:78353-bottom_rail-ROS",
      sizes: [
        [1, 6],
        [320, 50],
        [728, 90],
        [970, 90],
        [320, 100],
      ],
      rules: [
        {
          dimensions: {
            device: ["Desktop", "Tablet"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: {
            closeButton: false,
            railBackground: { styling: "bgColor", color: "#f5f5f526" },
            expandable: true,
          },
        },
        {
          dimensions: {
            device: ["Mobile"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: {
            sizes: [
              [1, 6],
              [320, 50],
            ],
            closeButton: false,
            railBackground: { styling: "bgColor", color: "#f5f5f526" },
            expandable: true,
          },
        },
        {
          dimensions: {
            device: ["ANY"],
            position: "ANY",
            orientation: "ANY",
            geo: ["US"],
          },
          rule: {
            refresh: {
              enabled: true,
              type: "Auto",
              rate: 30,
              limit: 100,
              condition: "inViewOnly",
              blankAdSetting: "next",
              refreshOnTabFocus: false,
            },
          },
        },
        {
          dimensions: {
            device: ["ANY"],
            position: "ANY",
            orientation: "ANY",
            geo: ["tier1"],
          },
          rule: {
            refresh: {
              enabled: true,
              type: "Auto",
              rate: 30,
              limit: 100,
              condition: "inViewOnly",
              blankAdSetting: "next",
              refreshOnTabFocus: false,
            },
          },
        },
        {
          dimensions: {
            device: ["ANY"],
            position: "ANY",
            orientation: "ANY",
            geo: ["rest_of_world"],
          },
          rule: {
            refresh: {
              enabled: true,
              type: "Auto",
              rate: 30,
              limit: 100,
              condition: "inViewOnly",
              blankAdSetting: "never",
              refreshOnTabFocus: false,
            },
          },
        },
      ],
      headerBids: {
        bids: [
          { bidder: "s2s_gumgum", params: "0", size: ["ANY"] },
          { bidder: "s2s_appnexus", params: "0", size: ["ANY"] },
          { bidder: "s2s_ix", params: "0", size: ["ANY"] },
          { bidder: "s2s_openx", params: "0", size: ["ANY"] },
          { bidder: "s2s_pubmatic", params: "0", size: ["ANY"] },
          { bidder: "s2s_rubicon", params: "0", size: ["ANY"] },
          { bidder: "criteo", params: "0", size: ["ANY"] },
          { bidder: "rubicon", params: "0", size: ["ANY"] },
          { bidder: "pubmatic", params: "0", size: ["ANY"] },
          { bidder: "ix", params: "0", size: ["ANY"] },
          { bidder: "openx", params: "0", size: ["ANY"] },
          { bidder: "gumgum", params: "0", size: ["ANY"] },
          { bidder: "sharethrough", params: "0", size: ["ANY"] },
          { bidder: "s2s_sharethrough", params: "0", size: ["ANY"] },
          { bidder: "ttd", params: "0", size: ["ANY"] },
          { bidder: "s2s_medianet", params: "0", size: ["ANY"] },
          { bidder: "kargo", params: "0", size: ["ANY"] },
          { bidder: "appnexus", params: "0", size: ["ANY"] },
          { bidder: "msft", params: "0", size: ["ANY"] },
          { bidder: "s2s_msft", params: "0", size: ["ANY"] },
          { bidder: "yahooAds", params: "0", size: ["ANY"] },
          { bidder: "triplelift", params: "0", size: ["ANY"] },
          { bidder: "s2s_triplelift", params: "0", size: ["ANY"] },
          { bidder: "seedtag", params: "0", size: ["ANY"] },
          { bidder: "richaudience", params: "0", size: ["ANY"] },
          { bidder: "s2s_richaudience", params: "0", size: ["ANY"] },
          { bidder: "equativ", params: "0", size: ["ANY"] },
        ],
      },
    },
    {
      id: 127708,
      unit: "in_content",
      path: "ROS",
      code: "/154013155,23359523682/1025909/78353/1025909-w:78353-in_content/1025909-w:78353-in_content-ROS",
      sizes: [],
      rules: [
        {
          dimensions: {
            device: ["Desktop", "Tablet"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: {
            lazyLoad: true,
            lazyThreshold: 0,
            incrementBidsOnRender: 1,
            insertionType: "viewportHeight",
            insertedDistance: "50vh",
            excludedElements: "h1, h2, h3, h4, h5, h6",
            fetchBidsOnLoad: 4,
            adsAtf: false,
            desktopSizes: [
              [300, 250],
              [728, 90],
              [480, 60],
              [320, 100],
              [336, 280],
            ],
            adContainer: true,
            showLoader: false,
            padding: 100,
            maxHeightEnabled: true,
            background: {
              styling: "topAndBottom",
              color: "#122043",
              weight: "1px",
            },
          },
        },
        {
          dimensions: {
            device: ["Mobile"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: {
            lazyLoad: true,
            lazyThreshold: 0,
            incrementBidsOnRender: 1,
            insertionType: "viewportHeight",
            insertedDistance: "50vh",
            excludedElements: "h1, h2, h3, h4, h5, h6",
            fetchBidsOnLoad: 4,
            adsAtf: false,
            mobileSizes: [
              [300, 250],
              [320, 50],
              [320, 100],
              [336, 280],
            ],
            adContainer: true,
            showLoader: false,
            padding: 100,
            maxHeightEnabled: true,
            background: {
              styling: "topAndBottom",
              color: "#122043",
              weight: "1px",
            },
          },
        },
        {
          dimensions: {
            device: ["ANY"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: {
            adLabel: { enabled: true, color: "#888888" },
            reportAdLink: { enabled: false, color: "#4db2ec" },
          },
        },
        {
          dimensions: {
            device: ["ANY"],
            position: "ANY",
            orientation: "ANY",
            geo: ["US"],
          },
          rule: {
            refresh: {
              enabled: true,
              type: "Auto",
              rate: 30,
              limit: 100,
              condition: "inViewOnly",
              blankAdSetting: "next",
              refreshOnTabFocus: false,
            },
          },
        },
        {
          dimensions: {
            device: ["ANY"],
            position: "ANY",
            orientation: "ANY",
            geo: ["tier1"],
          },
          rule: {
            refresh: {
              enabled: true,
              type: "Auto",
              rate: 30,
              limit: 100,
              condition: "inViewOnly",
              blankAdSetting: "next",
              refreshOnTabFocus: false,
            },
          },
        },
        {
          dimensions: {
            device: ["ANY"],
            position: "ANY",
            orientation: "ANY",
            geo: ["rest_of_world"],
          },
          rule: {
            refresh: {
              enabled: true,
              type: "Auto",
              rate: 30,
              limit: 100,
              condition: "inViewOnly",
              blankAdSetting: "never",
              refreshOnTabFocus: false,
            },
          },
        },
      ],
      headerBids: {
        bids: [
          { bidder: "pubmatic", params: "1", size: ["video"] },
          { bidder: "s2s_gumgum", params: "0", size: ["ANY"] },
          { bidder: "s2s_appnexus", params: "0", size: ["ANY"] },
          { bidder: "s2s_ix", params: "0", size: ["ANY"] },
          { bidder: "s2s_openx", params: "0", size: ["ANY"] },
          { bidder: "s2s_pubmatic", params: "0", size: ["ANY"] },
          { bidder: "s2s_rubicon", params: "0", size: ["ANY"] },
          { bidder: "criteo", params: "0", size: ["ANY"] },
          { bidder: "appnexus", params: "0", size: ["ANY"] },
          { bidder: "rubicon", params: "0", size: ["ANY"] },
          { bidder: "pubmatic", params: "0", size: ["ANY"] },
          { bidder: "ix", params: "0", size: ["ANY"] },
          { bidder: "openx", params: "0", size: ["ANY"] },
          { bidder: "gumgum", params: "1", size: ["ANY"] },
          { bidder: "sharethrough", params: "1", size: ["ANY"] },
          { bidder: "s2s_sharethrough", params: "1", size: ["ANY"] },
          { bidder: "ttd", params: "0", size: ["ANY"] },
          { bidder: "s2s_medianet", params: "0", size: ["ANY"] },
          { bidder: "kargo", params: "0", size: ["ANY"] },
          { bidder: "msft", params: "0", size: ["ANY"] },
          { bidder: "s2s_msft", params: "0", size: ["ANY"] },
          { bidder: "yahooAds", params: "0", size: ["ANY"] },
          { bidder: "triplelift", params: "1", size: ["ANY"] },
          { bidder: "s2s_triplelift", params: "1", size: ["ANY"] },
          { bidder: "seedtag", params: "0", size: ["ANY"] },
          { bidder: "richaudience", params: "0", size: ["ANY"] },
          { bidder: "s2s_richaudience", params: "0", size: ["ANY"] },
          { bidder: "equativ", params: "0", size: ["ANY"] },
        ],
      },
    },
    {
      id: 127712,
      unit: "sticky_sidebar",
      path: "ROS",
      code: "/154013155,23359523682/1025909/78353/1025909-w:78353-sticky_sidebar/1025909-w:78353-sticky_sidebar-ROS",
      sizes: [
        [300, 250],
        [300, 600],
        [120, 600],
        [160, 600],
      ],
      rules: [
        {
          dimensions: {
            device: ["Desktop", "Tablet"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: {
            stickySidebarContentEnd: ".sticky_sidebar_content_end",
            recreateAd: true,
            recreateAdTime: 2,
            recreateAdHeight: 100,
          },
        },
        {
          dimensions: {
            device: ["Desktop", "Tablet"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: {
            adLabel: { enabled: false, color: "#888888" },
            reportAdLink: { enabled: false, color: "#4db2ec" },
          },
        },
        {
          dimensions: {
            device: ["Desktop", "Tablet"],
            position: "ANY",
            orientation: "ANY",
            geo: ["US"],
          },
          rule: {
            refresh: {
              enabled: true,
              type: "Auto",
              rate: 30,
              limit: 100,
              condition: "inViewOnly",
              blankAdSetting: "next",
              refreshOnTabFocus: false,
            },
          },
        },
        {
          dimensions: {
            device: ["Desktop", "Tablet"],
            position: "ANY",
            orientation: "ANY",
            geo: ["tier1"],
          },
          rule: {
            refresh: {
              enabled: true,
              type: "Auto",
              rate: 30,
              limit: 100,
              condition: "inViewOnly",
              blankAdSetting: "next",
              refreshOnTabFocus: false,
            },
          },
        },
        {
          dimensions: {
            device: ["Desktop", "Tablet"],
            position: "ANY",
            orientation: "ANY",
            geo: ["rest_of_world"],
          },
          rule: {
            refresh: {
              enabled: true,
              type: "Auto",
              rate: 30,
              limit: 100,
              condition: "inViewOnly",
              blankAdSetting: "never",
              refreshOnTabFocus: false,
            },
          },
        },
      ],
      headerBids: {
        bids: [
          { bidder: "pubmatic", params: "1", size: ["video"] },
          { bidder: "s2s_gumgum", params: "0", size: ["ANY"] },
          { bidder: "s2s_appnexus", params: "0", size: ["ANY"] },
          { bidder: "s2s_ix", params: "0", size: ["ANY"] },
          { bidder: "s2s_openx", params: "0", size: ["ANY"] },
          { bidder: "s2s_pubmatic", params: "0", size: ["ANY"] },
          { bidder: "s2s_rubicon", params: "0", size: ["ANY"] },
          { bidder: "criteo", params: "0", size: ["ANY"] },
          { bidder: "appnexus", params: "0", size: ["ANY"] },
          { bidder: "rubicon", params: "0", size: ["ANY"] },
          { bidder: "pubmatic", params: "0", size: ["ANY"] },
          { bidder: "ix", params: "0", size: ["ANY"] },
          { bidder: "openx", params: "0", size: ["ANY"] },
          { bidder: "gumgum", params: "2", size: ["ANY"] },
          { bidder: "sharethrough", params: "2", size: ["ANY"] },
          { bidder: "s2s_sharethrough", params: "2", size: ["ANY"] },
          { bidder: "ttd", params: "0", size: ["ANY"] },
          { bidder: "s2s_medianet", params: "0", size: ["ANY"] },
          { bidder: "kargo", params: "0", size: ["ANY"] },
          { bidder: "msft", params: "0", size: ["ANY"] },
          { bidder: "s2s_msft", params: "0", size: ["ANY"] },
          { bidder: "yahooAds", params: "0", size: ["ANY"] },
          { bidder: "triplelift", params: "2", size: ["ANY"] },
          { bidder: "s2s_triplelift", params: "0", size: ["ANY"] },
          { bidder: "seedtag", params: "0", size: ["ANY"] },
          { bidder: "richaudience", params: "0", size: ["ANY"] },
          { bidder: "s2s_richaudience", params: "0", size: ["ANY"] },
          { bidder: "equativ", params: "0", size: ["ANY"] },
        ],
      },
    },
    {
      id: 127716,
      unit: "web_interstitial",
      path: "ROS",
      code: "/154013155,23359523682/1025909/78353/1025909-w:78353-web_interstitial/1025909-w:78353-web_interstitial-ROS",
      sizes: [
        [320, 480],
        [300, 250],
        [336, 280],
      ],
      rules: [
        {
          dimensions: {
            device: ["Desktop"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: { on: false },
        },
        {
          dimensions: {
            device: ["Tablet"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: { on: false },
        },
        {
          dimensions: {
            device: ["Mobile"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: { on: false },
        },
      ],
    },
    {
      id: 132775,
      unit: "rewarded_ad_video",
      path: "ROS",
      code: "/154013155,23359523682/1025909/78353/1025909-w:78353-rewarded_ad_video/1025909-w:78353-rewarded_ad_video-ROS",
      sizes: [],
      rules: [
        {
          dimensions: {
            device: ["Desktop"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: { on: true, size: { desktop: [640, 480] } },
        },
        {
          dimensions: {
            device: ["Tablet"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: { on: true, size: { tablet: [640, 480] } },
        },
        {
          dimensions: {
            device: ["Mobile"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: { on: true, size: { mobile: [178, 100] } },
        },
        {
          dimensions: {
            device: ["ANY"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: { duration: 30, viewPercentReward: 75 },
        },
      ],
      headerBids: {
        bids: [
          { bidder: "rubicon", params: "1", size: ["video"] },
          { bidder: "pubmatic", params: "2", size: ["video"] },
          { bidder: "appnexus", params: "1", size: ["video"] },
          { bidder: "ix", params: "1", size: ["video"] },
          { bidder: "sharethrough", params: "3", size: ["video"] },
          { bidder: "s2s_appnexus", params: "1", size: ["video"] },
          { bidder: "s2s_openx", params: "1", size: ["video"] },
          { bidder: "s2s_pubmatic", params: "1", size: ["video"] },
          { bidder: "s2s_rubicon", params: "0", size: ["video"] },
          { bidder: "s2s_sharethrough", params: "3", size: ["video"] },
          { bidder: "s2s_gumgum", params: "1", size: ["video"] },
          { bidder: "s2s_ix", params: "1", size: ["video"] },
          { bidder: "openx", params: "1", size: ["video"] },
          { bidder: "criteo", params: "0", size: ["video"] },
          { bidder: "ttd", params: "0", size: ["video"] },
          { bidder: "s2s_medianet", params: "1", size: ["video"] },
          { bidder: "kargo", params: "0", size: ["video"] },
          { bidder: "s2s_msft", params: "1", size: ["video"] },
          { bidder: "yahooAds", params: "1", size: ["video"] },
          { bidder: "msft", params: "1", size: ["video"] },
          { bidder: "triplelift", params: "3", size: ["video"] },
          { bidder: "s2s_triplelift", params: "2", size: ["video"] },
          { bidder: "seedtag", params: "0", size: ["video"] },
          { bidder: "richaudience", params: "0", size: ["video"] },
          { bidder: "s2s_richaudience", params: "0", size: ["video"] },
          { bidder: "equativ", params: "0", size: ["video"] },
        ],
      },
    },
    {
      id: 132792,
      unit: "standard_iab",
      path: "ROS",
      alias: "standard_iab_left1",
      section: "left",
      code: "/154013155,23359523682/1025909/78353/1025909-w:78353-standard_iab/1025909-w:78353-standard_iab-ROS/1025909-w:78353-standard_iab-ROS-left1",
      sizes: [],
      rules: [
        {
          dimensions: {
            device: ["Desktop", "Tablet"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: {
            sizes: [[300, 250]],
            lazyLoad: false,
            adLabel: { enabled: false, color: "#888888", position: "top" },
            locationSelector: "#pw-diep-home-300x250",
            placementRelativeToSelector: "intoSelector",
          },
        },
        {
          dimensions: {
            device: ["Mobile"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: {
            sizes: [[320, 50]],
            lazyLoad: true,
            lazyThreshold: 0,
            adLabel: { enabled: true, color: "#888888", position: "top" },
          },
        },
        {
          dimensions: {
            device: ["ANY"],
            position: "ANY",
            orientation: "ANY",
            geo: ["US"],
          },
          rule: {
            refresh: {
              enabled: true,
              type: "Auto",
              rate: 30,
              limit: 100,
              condition: "inViewOnly",
              blankAdSetting: "next",
              refreshOnTabFocus: false,
            },
          },
        },
        {
          dimensions: {
            device: ["ANY"],
            position: "ANY",
            orientation: "ANY",
            geo: ["tier1"],
          },
          rule: {
            refresh: {
              enabled: true,
              type: "Auto",
              rate: 30,
              limit: 100,
              condition: "inViewOnly",
              blankAdSetting: "next",
              refreshOnTabFocus: false,
            },
          },
        },
        {
          dimensions: {
            device: ["ANY"],
            position: "ANY",
            orientation: "ANY",
            geo: ["rest_of_world"],
          },
          rule: {
            refresh: {
              enabled: true,
              type: "Auto",
              rate: 30,
              limit: 100,
              condition: "inViewOnly",
              blankAdSetting: "never",
              refreshOnTabFocus: false,
            },
          },
        },
      ],
      headerBids: {
        bids: [
          { bidder: "criteo", params: "0", size: ["ANY"] },
          { bidder: "appnexus", params: "0", size: ["ANY"] },
          { bidder: "rubicon", params: "0", size: ["ANY"] },
          { bidder: "pubmatic", params: "0", size: ["ANY"] },
          { bidder: "ix", params: "0", size: ["ANY"] },
          { bidder: "openx", params: "0", size: ["ANY"] },
          { bidder: "s2s_appnexus", params: "0", size: ["ANY"] },
          { bidder: "s2s_ix", params: "0", size: ["ANY"] },
          { bidder: "s2s_openx", params: "0", size: ["ANY"] },
          { bidder: "s2s_pubmatic", params: "0", size: ["ANY"] },
          { bidder: "s2s_rubicon", params: "0", size: ["ANY"] },
          { bidder: "s2s_gumgum", params: "0", size: ["ANY"] },
          { bidder: "gumgum", params: "3", size: ["ANY"] },
          { bidder: "ttd", params: "0", size: ["ANY"] },
          { bidder: "s2s_medianet", params: "0", size: ["ANY"] },
          { bidder: "kargo", params: "0", size: ["ANY"] },
          { bidder: "s2s_sharethrough", params: "4", size: ["ANY"] },
          { bidder: "sharethrough", params: "4", size: ["ANY"] },
          { bidder: "msft", params: "0", size: ["ANY"] },
          { bidder: "s2s_msft", params: "0", size: ["ANY"] },
          { bidder: "yahooAds", params: "0", size: ["ANY"] },
          { bidder: "triplelift", params: "1", size: ["ANY"] },
          { bidder: "s2s_triplelift", params: "1", size: ["ANY"] },
          { bidder: "seedtag", params: "0", size: ["ANY"] },
          { bidder: "richaudience", params: "0", size: ["ANY"] },
          { bidder: "s2s_richaudience", params: "0", size: ["ANY"] },
          { bidder: "equativ", params: "0", size: ["ANY"] },
        ],
      },
    },
    {
      id: 132793,
      unit: "standard_iab",
      path: "ROS",
      alias: "standard_iab_foot1",
      section: "foot",
      code: "/154013155,23359523682/1025909/78353/1025909-w:78353-standard_iab/1025909-w:78353-standard_iab-ROS/1025909-w:78353-standard_iab-ROS-foot1",
      sizes: [],
      rules: [
        {
          dimensions: {
            device: ["Desktop", "Tablet"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: {
            sizes: [
              [320, 50],
              [320, 100],
              [320, 106],
              [728, 90],
              [970, 90],
            ],
            lazyLoad: false,
            adLabel: { enabled: false, color: "#888888", position: "top" },
            locationSelector: "#pw-diep-game-footer-728x90",
            placementRelativeToSelector: "intoSelector",
          },
        },
        {
          dimensions: {
            device: ["Mobile"],
            position: "ANY",
            orientation: "ANY",
            geo: null,
          },
          rule: {
            sizes: [[320, 50]],
            lazyLoad: true,
            lazyThreshold: 0,
            adLabel: { enabled: true, color: "#888888", position: "top" },
          },
        },
        {
          dimensions: {
            device: ["ANY"],
            position: "ANY",
            orientation: "ANY",
            geo: ["US"],
          },
          rule: {
            refresh: {
              enabled: true,
              type: "Auto",
              rate: 30,
              limit: 100,
              condition: "Always",
              blankAdSetting: "next",
              refreshOnTabFocus: true,
            },
          },
        },
        {
          dimensions: {
            device: ["ANY"],
            position: "ANY",
            orientation: "ANY",
            geo: ["tier1"],
          },
          rule: {
            refresh: {
              enabled: true,
              type: "Auto",
              rate: 30,
              limit: 100,
              condition: "inViewOnly",
              blankAdSetting: "next",
              refreshOnTabFocus: false,
            },
          },
        },
        {
          dimensions: {
            device: ["ANY"],
            position: "ANY",
            orientation: "ANY",
            geo: ["rest_of_world"],
          },
          rule: {
            refresh: {
              enabled: true,
              type: "Auto",
              rate: 30,
              limit: 100,
              condition: "inViewOnly",
              blankAdSetting: "never",
              refreshOnTabFocus: false,
            },
          },
        },
      ],
      headerBids: {
        bids: [
          { bidder: "criteo", params: "0", size: ["ANY"] },
          { bidder: "appnexus", params: "0", size: ["ANY"] },
          { bidder: "rubicon", params: "0", size: ["ANY"] },
          { bidder: "pubmatic", params: "0", size: ["ANY"] },
          { bidder: "ix", params: "0", size: ["ANY"] },
          { bidder: "openx", params: "0", size: ["ANY"] },
          { bidder: "s2s_appnexus", params: "0", size: ["ANY"] },
          { bidder: "s2s_ix", params: "0", size: ["ANY"] },
          { bidder: "s2s_openx", params: "0", size: ["ANY"] },
          { bidder: "s2s_pubmatic", params: "0", size: ["ANY"] },
          { bidder: "s2s_rubicon", params: "0", size: ["ANY"] },
          { bidder: "s2s_gumgum", params: "0", size: ["ANY"] },
          { bidder: "gumgum", params: "3", size: ["ANY"] },
          { bidder: "ttd", params: "0", size: ["ANY"] },
          { bidder: "s2s_medianet", params: "0", size: ["ANY"] },
          { bidder: "kargo", params: "0", size: ["ANY"] },
          { bidder: "s2s_sharethrough", params: "4", size: ["ANY"] },
          { bidder: "sharethrough", params: "4", size: ["ANY"] },
          { bidder: "msft", params: "0", size: ["ANY"] },
          { bidder: "s2s_msft", params: "0", size: ["ANY"] },
          { bidder: "yahooAds", params: "0", size: ["ANY"] },
          { bidder: "triplelift", params: "1", size: ["ANY"] },
          { bidder: "s2s_triplelift", params: "1", size: ["ANY"] },
          { bidder: "seedtag", params: "0", size: ["ANY"] },
          { bidder: "richaudience", params: "0", size: ["ANY"] },
          { bidder: "s2s_richaudience", params: "0", size: ["ANY"] },
          { bidder: "equativ", params: "0", size: ["ANY"] },
        ],
      },
    },
  ],
};
window.pwEdgeFlags = Object.assign(window.pwEdgeFlags || {}, {
  botScoreBlockThreshold: 15,
  dmpDisabledDomains: [
    "coolmath.com",
    "coolmathgames.com",
    "nitrotype.com",
    "typing.com",
  ],
  prebidSrc: "https://cdn.intergient.com/prebid/prebid.a839be9caced6b1c2d11.js",
  pageosVersion: "V.20261118.1",
  tycheVersion: "4.12.5",
});
window.pwEdgeYieldOptions = Object.assign({}, window.pwEdgeYieldOptions);
window.pwWrapperPubCode =
  '(function(){window.ramp=window.ramp||{},window.ramp.que=window.ramp.que||[],window.ramp.activeConfig=window.ramp.activeConfig||{settings:{rampDelay:!1}},window.ramp.publisherOptions=window.ramp.publisherOptions||{},window.ramp.publisherOptions.async=window.ramp.publisherOptions.async??!0,window.ramp.publisherOptions.defer=window.ramp.publisherOptions.defer&&!window.ramp.publisherOptions.async||!1,window.ramp.publisherOptions.appendTarget=window.ramp.publisherOptions.appendTarget||"body",window.pwEdgeYieldOptions=window.pwEdgeYieldOptions||{};let s=window.ramp.publisherOptions.publisherId||window.pwEdgeYieldOptions.publisherId,r=window.ramp.publisherOptions.websiteId||window.pwEdgeYieldOptions.websiteId,t=`https://cdn.intergient.com/stack/${s}/${r}/ramptag.js`;if(document.getElementById("playwire-script"))return;let p={url:window.location.href};if(window.localStorage.pw_session_config){let e=JSON.parse(window.localStorage.pw_session_config);p.pw_session_config=JSON.stringify(e.config||""),p.pw_session_config_id=e.config_id||""}let n=document.createElement("script");n.id="playwire-script",n.src=`${t}?${Object.keys(p).map(e=>`${e}=${encodeURIComponent(p[e])}`).join("&")}`,window.ramp.publisherOptions.async?n.async=!0:window.ramp.publisherOptions.defer&&(n.defer=!0);let o=typeof window.ramp.publisherOptions.appendTarget=="string"&&window.ramp.publisherOptions.appendTarget.trim()||"body",i=null;try{i=document.querySelector(o)}catch{}i||(i=document.body),i&&i.appendChild?i.appendChild(n):console.warn(`[wrapper] Unable to append script to target: ${o}`)})();\n';
window.pwRampConfigNoopUrl =
  "https://cdn.intergient.com/1025909/78353/ramp.js?noop=true";
("use strict");
(() => {
  var Z = "https://cdn.intergient.com/prebid/prebid.js",
    v = (e) =>
      e.rampMinimal ||
      !(e.isWrapperConfig ? !!e.wrapperBundleUrl : !!e.headerBidding)
        ? null
        : typeof e.yieldOptionsPrebidSrc == "string"
        ? e.yieldOptionsPrebidSrc
        : e.isWrapperConfig && typeof e.wrapperBundleUrl == "string"
        ? e.wrapperBundleUrl
        : e.configSettingsPrebidSrc &&
          typeof e.configSettingsPrebidSrc == "string"
        ? e.configSettingsPrebidSrc
        : typeof e.edgeFlagPrebidSrc == "string"
        ? e.edgeFlagPrebidSrc
        : Z;
  var Q = "pw_intent_iq_partner_id";
  var A = ["chrome"],
    N = {
      partnerId: 1477556550,
      prebidNamespace: "__pwpbjs__",
      timeoutInMillis: 400,
      manualWinReportEnabled: !0,
      shouldSetPPID: !0,
      vrBrowserBlackList: [...A],
    },
    X = "intentIq",
    L = (e) => {
      let n = typeof e == "string" ? Number(e.trim()) : e;
      return typeof n == "number" && Number.isFinite(n) && n > 0 ? n : null;
    },
    ee = (e) =>
      typeof e == "number" && Number.isFinite(e) && e > 0 ? e : void 0,
    ne = () => {
      try {
        let e = L(window.localStorage.getItem(Q));
        return e === 1477556550 || e === 1300736566 ? e : null;
      } catch {
        return null;
      }
    },
    te = (e) => {
      try {
        window.localStorage.setItem(Q, `${e}`);
      } catch {}
    },
    ie = () => {
      let e = ne();
      if (e) return e;
      let n = Math.random() < 0.99 ? 1477556550 : 1300736566;
      return te(n), n;
    },
    k = (e, n = !1) => {
      let i = L(e.partnerId) ?? (n ? ie() : null);
      return i
        ? {
            partnerId: i,
            prebidNamespace: e.prebidNamespace || N.prebidNamespace,
            timeoutInMillis: ee(e.timeoutInMillis) ?? N.timeoutInMillis,
            manualWinReportEnabled:
              e.manualWinReportEnabled ?? N.manualWinReportEnabled,
            shouldSetPPID: e.shouldSetPPID ?? N.shouldSetPPID,
            vrBrowserBlackList: [...A],
          }
        : null;
    },
    oe = (e, n) => {
      if (!e) return [];
      if (Array.isArray(e)) return e;
      let i = e[n];
      return Array.isArray(i) ? i : [];
    },
    x = (e, n = "desktop") => {
      let i = oe(e?.settings?.identity, n).includes(X);
      return { configured: i, enabled: i };
    },
    B = (e) => ({ configured: !1, enabled: !1 }),
    U = (e, n) => {
      let i = e.intentIQ;
      if (i?.enabled === !1) return { settings: null };
      let r = { ...i, partnerId: i?.partnerId ?? e.iiqPartnerId };
      return n.configured
        ? { settings: n.enabled ? k(r, !0) : null }
        : {
            settings:
              i?.enabled === !0 || !!r.partnerId
                ? k(r, i?.enabled === !0)
                : null,
          };
    };
  var re = [
      "AT",
      "BE",
      "BG",
      "HR",
      "CY",
      "CZ",
      "DK",
      "EE",
      "FI",
      "FR",
      "DE",
      "GR",
      "HU",
      "IS",
      "IE",
      "IT",
      "LV",
      "LI",
      "LT",
      "LU",
      "MT",
      "NL",
      "NO",
      "PL",
      "PT",
      "RO",
      "SK",
      "SI",
      "ES",
      "SE",
      "CH",
      "GB",
      "UK",
    ],
    M = new Set(re);
  var j = "__intent_iq__",
    de = new Set([
      "US",
      "CA",
      "JP",
      "AU",
      "SG",
      "KR",
      "TH",
      "MY",
      "PH",
      "NZ",
      "MX",
      "BR",
    ]),
    ce = (e) =>
      e === 1300736566
        ? `https://agent.intentiq.com/Agent/PCDN/${e}/IIQAgent.js`
        : `https://agent.intentiq.com/Agent/${1477556550}/IIQAgent.js`,
    le = () => {
      if (typeof window._pwBotScore != "number") return !1;
      let e = window.pwEdgeFlags?.botScoreBlockThreshold,
        n = window._pwBotScore;
      if (typeof e == "number") return n <= e;
      if (Array.isArray(e)) {
        if (e.length === 0) return !1;
        let i = e.length === 1 ? 0 : e[0],
          r = e[e.length - 1];
        return typeof i != "number" || typeof r != "number"
          ? !1
          : n >= i && n <= r;
      }
      return !1;
    },
    pe = () => {
      let e = (window._pwUserCC || "").toUpperCase();
      return de.has(e) && !le();
    },
    F = () => {
      let e = window.pwIntentIQSettings;
      if (!e?.partnerId || document.getElementById(j) || !pe()) return;
      let {
          partnerId: n,
          prebidNamespace: i = "__pwpbjs__",
          timeoutInMillis: r,
          manualWinReportEnabled: s,
          shouldSetPPID: f,
        } = e,
        l = document.createElement("script");
      (l.id = j),
        (l.async = !0),
        (l.src = ce(n)),
        (l.onerror = () => {
          console.error(
            "Ramp.js: Critical error loading IntentIQ script asset."
          );
        }),
        (l.onload = () => {
          let b = function (w) {},
            y = window;
          y[i] = y[i] || {};
          let u = y[i];
          u.que = u.que || [];
          let P = window._pwUserCC || "";
          if (
            ((window.googletag = window.googletag || {}),
            (window.googletag.cmd = window.googletag.cmd || []),
            typeof window.IntentIqObject == "function")
          ) {
            let w = {
              partner: n,
              pbjs: u,
              callback: b,
              ABTestingConfigurationSource: "IIQServer",
              timeoutInMillis: r,
              manualWinReportEnabled: s,
              domainName: window.location.hostname,
              gamObjectReference: window.googletag,
              gamParameterName: `iiq_group_${n}`,
              shouldSetPPID: f,
              vrBrowserBlackList: [...A],
              ...(M.has(P.toUpperCase()) ? { region: "gdpr" } : {}),
            };
            window.intentIQInstance = new window.IntentIqObject(w);
          }
        }),
        (
          document.head ||
          document.body ||
          document.getElementsByTagName("head")[0]
        )?.appendChild(l);
    };
  var ge = "__pwpbjs__",
    fe = "[PageOS]:[Confiant]",
    S = (e, ...n) => {
      try {
        let i = window.PageOS?.logger?.get?.("CONFIANT", {
          app: { name: "PageOS" },
        });
        i && typeof i[e] == "function" && i[e](...n);
      } catch {}
      try {
        (console[e] || console.log)(fe, ...n);
      } catch {}
    },
    ue = (e, n) => {
      try {
        if (typeof window.PageOS?.BUS?.emit == "function") {
          window.PageOS.BUS.emit(e, n);
          return;
        }
        S(
          "debug",
          `PageOS.BUS is not available yet; skipped emitting "${e}"`,
          n
        );
      } catch (i) {
        S("warn", `Failed to emit "${e}" on the PageOS event bus`, i);
      }
    },
    we = (e) =>
      ({
        1: "manual_deprecated",
        2: "creative",
        3: "provider_security",
        4: "banned_domain",
        5: "provider_ibv",
        6: "unsafejs",
        7: "hrap",
      }[e] || `unknown_type_${e}`),
    W = (e, n, i) => {
      typeof window.ramp?.reloadHeavyAd == "function"
        ? (S("info", "Triggering slot refresh after blocked ad", {
            slotElementId: e,
            originalPrebidAdId: n,
            originalCreativeId: i,
          }),
          window.ramp.reloadHeavyAd(e, {
            originalPrebidAdId: n,
            originalCreativeId: i,
          }))
        : S(
            "error",
            "window.ramp.reloadHeavyAd is not a function; unable to refresh slot",
            e
          );
    },
    me = (e, n, i, r) => {
      (window.confiant = window.confiant || {}),
        (window.confiant[e] = window.confiant[e] || { clientSettings: {} });
      let s = window.confiant[e].clientSettings;
      (s.prebidNameSpace = n),
        (s.enableRefresh = !1),
        (s.enableDisplay = i),
        (s.enableVideo = r),
        S("debug", `clientSettings seeded for property "${e}"`, s);
    },
    Ce = (e, n, i, r) => {
      window.confiant?.[e] &&
        (window.confiant[e].clientSettings.callback = (s, f, l, C, b, y) => {
          if (!l) return;
          let u = y?.dfp || {},
            P = y?.prebid || {},
            w = u.s || "",
            h = u.A || "unknown_ad_unit",
            T = u.c || "unknown_creative",
            I = P.adId || "unknown_prebid_id",
            O = we(s),
            R = {
              propertyId: e,
              slotId: w || null,
              adUnitPath: h,
              creativeId: T,
              originalPrebidAdId: I,
              originalDfpLineItemId: u.I || "unknown",
              blockingType: O,
              blockingId: f,
              tagId: b,
              wrapperId: C,
            },
            _ = (t, o) => {
              o != null && (R[t] = o);
            };
          if (
            (_("originalPrebidCpm", P.cpm),
            _("originalDfpAdvertiserId", u.ad),
            _("originalDfpOrderId", u.o),
            _("originalDfpYieldGroupId", u.y),
            _("originalDfpCompanyId", u.co),
            S("info", `Confiant blocked a creative on property "${e}"`, R),
            window.PageOS?.dataStream?.handleEvent &&
              window.PageOS.dataStream.handleEvent("confiantBlocked", R),
            ue("confiantBlocked", R),
            w && r.indexOf(h) === -1)
          ) {
            let t = s === 5 || !!P.adId?.includes("video");
            ((t && i) || (!t && n)) && (r.push(h), W(w, I, T));
          }
        });
    },
    Se = (e) => {
      let n = document.createElement("script");
      (n.async = !0),
        (n.src = `https://cdn.confiant-integrations.net/${e}/gpt_and_prebid/config.js`),
        S("info", `Loading Confiant CDN script for property "${e}"`, n.src),
        (n.onerror = () => {
          S(
            "error",
            `Critical error loading Confiant script asset for property "${e}"`,
            n.src
          );
        });
      let i = document.head || document.getElementsByTagName("head")[0];
      i
        ? i.appendChild(n)
        : S(
            "error",
            "Unable to find a <head> element to inject the Confiant script into"
          );
    },
    $ = () => {
      let e = window.pwConfiantSettings,
        n = e?.prebidNamespace || ge,
        i = !!e?.enabledDisplay,
        r = !!e?.enabledVideo,
        s = e?.propertyId,
        f = (i || r) && !!s;
      if (
        (S("debug", "initConfiant called", {
          pwConfiantSettings: e || null,
          isEnabled: f,
        }),
        !f || !s)
      )
        return;
      let l = [];
      me(s, n, i, r), Ce(s, i, r, l), Se(s);
    };
  var be = "TQKqBEtrLKQeEixRZzZ_NmOAgjo",
    H = ["desktop", "tablet", "mobile"],
    q = (e) => e.toLowerCase().replace(/^www\./, ""),
    ye = (e) => {
      try {
        return q(new URL(e).hostname);
      } catch {
        return "";
      }
    },
    Ie = (e) =>
      Object.prototype.toString.call(e) === "[object Object]" &&
      !Array.isArray(e),
    Y = (e, n) => ({
      enabledDisplay: !0,
      enabledVideo: !0,
      propertyId: e,
      prebidNamespace: "__pwpbjs__",
      ...(n === void 0 ? {} : { blockDelayMs: n }),
    }),
    _e = (e) => {
      if (e == null || e === "") return;
      let n = Number(e);
      return Number.isFinite(n) && n >= 0 ? n : void 0;
    },
    V = (e) => {
      let n = e?.settings?.confiantConfig;
      if (n?.enabled !== !0) return { enabled: !1, propertyId: null };
      let i = typeof n.propertyId == "string" ? n.propertyId.trim() : "",
        r = _e(n.blockDelayMs);
      return {
        enabled: !0,
        propertyId: i || null,
        ...(r === void 0 ? {} : { blockDelayMs: r }),
      };
    },
    K = (e) => {
      let n = e?.adQualityIntegrations,
        i = Array.isArray(n)
          ? n.find((l) => l?.partnerCode === "confiant")
          : void 0,
        r = i?.enabled === !0,
        s =
          typeof i?.adQualityPropertyIdOverride == "string"
            ? i.adQualityPropertyIdOverride
            : i?.adQualityPropertyId,
        f = (r && typeof s == "string" && s.trim()) || null;
      return { enabled: r, propertyId: f };
    },
    G = (e, n, i, r) => {
      if (e.pwConfiantEnabled === !1)
        return { settings: null, pwConfiantEnabled: !1 };
      if (
        Array.isArray(e.pwConfiantDisabledForDevices) &&
        e.pwConfiantDisabledForDevices.includes(i)
      )
        return { settings: null, pwConfiantEnabled: !0 };
      if (r.enabled)
        return r.propertyId
          ? { settings: Y(r.propertyId, r.blockDelayMs), pwConfiantEnabled: !0 }
          : { settings: null, pwConfiantEnabled: !0 };
      if (e.pwConfiantEnabled !== !0) return { settings: null };
      let s = e.pwConfiantSitesEnabled;
      if (!Ie(s)) return { settings: null, pwConfiantEnabled: !1 };
      let f = be;
      if (Object.keys(s).length > 0) {
        let l = ye(n);
        if (
          ((f = Object.keys(s).reduce(
            (C, b) => C || (q(b) === l ? s[b] : ""),
            ""
          )),
          !f)
        )
          return { settings: null, pwConfiantEnabled: !0 };
      }
      return { settings: Y(f), pwConfiantEnabled: !0 };
    };
  var Ee = (e) => e !== null && typeof e == "object",
    J = (e) => {
      if (!Ee(e)) return !1;
      let n = e;
      return (
        (n.server || n.adServer?.name || n.website?.adServer?.name) ===
        "DFP_COPPA"
      );
    };
  var Pe = "/tag/js/gpt.js",
    Re = ["pagead2.googlesyndication.com", "securepubads.g.doubleclick.net"],
    z = (e) => {
      try {
        let n = new URL(e, window.location.href);
        return n.pathname === Pe && Re.includes(n.hostname);
      } catch {
        return !1;
      }
    },
    he = (e) => {
      let n = z(e);
      for (let i = 0; i < document.scripts.length; i++) {
        let r = document.scripts[i];
        if (r.src === e || (n && z(r.src))) return r;
      }
      return null;
    };
  (function () {
    if (
      ((window.PageOS = window.PageOS || {}),
      (window.pwEdgeFlags = window.pwEdgeFlags || {}),
      window.PageOS.loadedRampConfig === !0)
    )
      return;
    window.PageOS.loadedRampConfig = !0;
    let e = !1,
      n = "PageOS_Session",
      i = window.scrollY || window.pageYOffset,
      r = () => {
        if (typeof window.pwRAMPDelay == "number") return window.pwRAMPDelay;
        let t = window.ramp.activeConfig;
        if (t) {
          let o = t.settings?.rampDelayTime;
          if (typeof o == "number") return o;
          let a = t.website?.rampDelayTime;
          if (typeof a == "number") return a;
        }
        return 5e3;
      },
      s = (t) => {
        let o = !1,
          a = () => {
            if (o) return;
            o = !0;
            let g = function () {
              window.pwRAMPInitiated || ((window.pwRAMPInitiated = !0), t());
            };
            typeof window.requestIdleCallback == "function"
              ? window.requestIdleCallback(g, { timeout: 2e3 })
              : g();
          },
          p = f();
        if (
          (["click", "mousemove", "keydown", "scroll"].forEach((g) => {
            document.addEventListener(
              g,
              (E) => {
                let c = window.scrollY || window.pageYOffset;
                (E.type === "scroll" && c === i) ||
                  (window.PageOS.ttfui ||
                    (window.PageOS.ttfui = performance.now()),
                  p && a());
              },
              { once: !0 }
            );
          }),
          !p)
        )
          a();
        else {
          let g = r();
          setTimeout(() => {
            a();
          }, g);
        }
      },
      f = () =>
        window.ramp.delayMode === !1
          ? !1
          : !!(
              window.ramp.activeConfig &&
              window.ramp.activeConfig.settings &&
              window.ramp.activeConfig.settings.rampDelay === !0
            ),
      l = (t) => {
        let o = new Date(t).setHours(0, 0, 0, 0);
        return new Date().setHours(0, 0, 0, 0) - o > 0;
      },
      C = (t) =>
        typeof t != "object"
          ? null
          : t.config_id
          ? t.config_id
          : t.config && t.config.key
          ? t.config.key
          : null,
      b = (t) => {
        if (typeof t != "object") throw new Error("No config found");
        if (typeof t.traffic_percent == "number") return t.traffic_percent;
        if (t.config && typeof t.config.weight == "number")
          return t.config.weight;
      },
      y = (t) =>
        typeof t != "object"
          ? !1
          : typeof t.session_persistence < "u"
          ? !!t.session_persistence
          : !0,
      u = (t) => {
        let o = null,
          a = (() => {
            try {
              return new URLSearchParams(window.location.search);
            } catch {
              return null;
            }
          })(),
          p = a && a.get("pw_config");
        if (p) {
          let d = window.ramp.configurations.find((g) => p === `${C(g)}`);
          d && (o = d);
        }
        if (!o && !t)
          try {
            let d = window.localStorage.getItem("pw_session_config");
            if (d) {
              let g = JSON.parse(d),
                E = window.ramp.configurations.find(
                  (c) => C(g) === C(c) && y(c)
                );
              E && (o = E);
            }
          } catch {}
        if (!o) {
          let d = 0,
            g = Math.random(),
            E = window.ramp.configurations.reduce((c, m) => c + (b(m) || 0), 0);
          for (let c = 0; c < window.ramp.configurations.length; c++) {
            let m = window.ramp.configurations[c],
              D = d + (b(m) || 0) / E;
            if (g >= d && g < D) {
              o = m;
              break;
            }
            d = D;
          }
        }
        return (
          window.pwSplitConfigVersionOverride != null &&
            (o = window.ramp.configurations.find(
              (d) => C(d) === window.pwSplitConfigVersionOverride
            )),
          o
            ? o.config && o.config.key && (o.config_id = o.config.key)
            : (o = window.ramp.configurations[0]),
          o
        );
      },
      P = () =>
        window.ramp.configurations.find((t) => {
          if (
            t &&
            t.id &&
            t.settings?.publisherId &&
            t.config_id === `${t.settings.publisherId}_${t.id}_primary_config`
          )
            return t;
        }) || window.ramp.configurations[0],
      w = () => window.ramp.configType === "wrapper",
      h = () => {
        let t = U(
          window.pwEdgeFlags,
          w()
            ? B(window.ramp.activeConfig)
            : x(window.ramp.activeConfig, window._pwUserDeviceType || "desktop")
        );
        t.settings
          ? (window.pwIntentIQSettings = t.settings)
          : delete window.pwIntentIQSettings;
      },
      T = () => {
        let t = w(),
          o = G(
            window.pwEdgeFlags,
            window.location?.href || document.referrer || "",
            window._pwUserDeviceType || "desktop",
            t ? K(window.ramp.activeConfig) : V(window.ramp.activeConfig)
          );
        typeof o.pwConfiantEnabled == "boolean" &&
          (window.pwEdgeFlags.pwConfiantEnabled = o.pwConfiantEnabled),
          o.settings
            ? ((window.pwConfiantSettings = o.settings),
              (window.pwEdgeFlags.adlDisabled = H))
            : delete window.pwConfiantSettings;
      };
    try {
      let t = localStorage.getItem(n),
        o = t ? JSON.parse(t) : !1,
        a = !o || Date.now() - o.lastVisit > 1800 * 1e3,
        p = !o || l(o.lastVisit);
      e = !o || a || p;
    } catch {}
    if (Array.isArray(window.ramp.configurations))
      if (window.pwEdgeYieldAllCases && window.pwEdgeYieldAllCases.length > 0)
        (window.ramp.activeConfig = P()),
          window.localStorage.removeItem("pw_session_config");
      else {
        window.ramp.activeConfig = u(e);
        try {
          y(window.ramp.activeConfig)
            ? window.localStorage.setItem(
                "pw_session_config",
                JSON.stringify(window.ramp.activeConfig)
              )
            : window.localStorage.removeItem("pw_session_config");
        } catch {}
      }
    else window.ramp.activeConfig = window.ramp.configurations;
    (window.ramp.mvpConfig = window.ramp.activeConfig), h(), F(), T(), $();
    let I = [];
    if (!window.googletag || window.googletag._loaded_ !== !0) {
      let t = window.ramp.activeConfig,
        o = J(t),
        a = o
          ? "https://pagead2.googlesyndication.com/tag/js/gpt.js"
          : "https://securepubads.g.doubleclick.net/tag/js/gpt.js",
        p = "154013155",
        d = "96780239",
        g = new Set([
          75621, 75620, 76421, 75918, 76615, 76616, 76617, 76618, 76619, 77005,
          76844, 77002, 74780, 73599, 77503, 77546, 77547, 77548, 77496, 77674,
        ]),
        c = [
          t.adServer?.networkCode,
          t.website?.adServer?.networkCode,
          t.tpg_network,
        ]
          .map((m) => (typeof m == "string" ? m.trim() : ""))
          .find((m) => !!m);
      if (
        (!c && g.has(t.id) && (c = p),
        c || (c = o ? d : p),
        window.pwEdgeYieldOptions?.iubendaCmpEnabled !== !0 &&
          c &&
          !a.includes("network-code"))
      ) {
        let m = a.includes("?") ? "&" : "?";
        a = `${a}${m}network-code=${c}`;
      }
      I.push({
        src: a,
        callback: () => {
          window.ramp.que.push(() => window.ramp.afterDfpLoaded());
        },
      });
    }
    let O = w(),
      R = v({
        isWrapperConfig: O,
        rampMinimal: !!window.rampMinimal,
        headerBidding: !!window.ramp.activeConfig.headerBidding,
        edgeFlagPrebidSrc: window.pwEdgeFlags.prebidSrc,
        wrapperBundleUrl: window.ramp.configurations?.prebidJs?.bundleUrl,
        configSettingsPrebidSrc: window.ramp.activeConfig.settings?.prebidSrc,
        yieldOptionsPrebidSrc: window.pwEdgeYieldOptions?.prebidSrc,
      });
    if ((R && I.push({ src: R }), window.ramp.loadCoreJS === !0)) {
      let t =
        window.pwEdgeFlags?.rampCoreSrc ||
        "https://cdn.intergient.com/ramp_core.js";
      I.push({ src: t });
    }
    let _ = () => {
      for (let t = 0; t < I.length; t++) {
        let o = I[t],
          a = he(o.src);
        if (a) {
          o.callback && a.addEventListener("load", o.callback, { once: !0 });
          continue;
        }
        let p = document.createElement("script");
        (p.type = "text/javascript"),
          (p.async = !0),
          (p.src = o.src),
          o.callback && (p.onload = o.callback),
          (document.head || document.body).appendChild(p);
      }
      s(() => {
        (window.PageOS = window.PageOS || {}),
          (window.PageOS.adsPerformance = !0),
          typeof window.PageOS.run == "function" && window.PageOS.run();
      });
    };
    if (
      ((!window.pwEdgeYieldOptions ||
        typeof window.pwEdgeYieldOptions.wrapperSplitTestSource != "string") &&
        _(),
      window.pwEdgeYieldOptions?.wrapperSplitTestSource === "wrapper")
    ) {
      window.PageOS.loadedRampConfig = !1;
      let t = document.createElement("script");
      (t.innerText = window.pwWrapperPubCode || ""),
        document.head.appendChild(t);
      return;
    } else if (window.pwEdgeYieldOptions?.wrapperSplitTestSource === "ramp") {
      let t = document.createElement("script");
      (t.src = window.pwRampConfigNoopUrl || ""),
        document.head.appendChild(t),
        (t.onload = () => {
          _();
        });
    }
  })();
})();
