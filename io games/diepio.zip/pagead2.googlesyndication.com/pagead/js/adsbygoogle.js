(function (sttc) {
  "use strict";
  var aa = Object.defineProperty,
    ba = globalThis,
    ca = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
    da = {},
    ha = {};
  function ia(a, b, c) {
    if (!c || a != null) {
      c = ha[b];
      if (c == null) return a[b];
      c = a[c];
      return c !== void 0 ? c : a[b];
    }
  }
  function ja(a, b, c) {
    if (b)
      a: {
        var d = a.split(".");
        a = d.length === 1;
        var e = d[0],
          f;
        !a && e in da ? (f = da) : (f = ba);
        for (e = 0; e < d.length - 1; e++) {
          var g = d[e];
          if (!(g in f)) break a;
          f = f[g];
        }
        d = d[d.length - 1];
        c = ca && c === "es6" ? f[d] : null;
        b = b(c);
        b != null &&
          (a
            ? aa(da, d, { configurable: !0, writable: !0, value: b })
            : b !== c &&
              (ha[d] === void 0 &&
                ((a = (Math.random() * 1e9) >>> 0),
                (ha[d] = ca ? ba.Symbol(d) : "$jscp$" + a + "$" + d)),
              aa(f, ha[d], { configurable: !0, writable: !0, value: b })));
      }
  }
  ja(
    "Symbol.dispose",
    function (a) {
      return a ? a : Symbol("Symbol.dispose");
    },
    "es_next"
  ); /* 
 
 Copyright The Closure Library Authors. 
 SPDX-License-Identifier: Apache-2.0 
*/
  var t = this || self;
  function ka(a) {
    a = a.split(".");
    for (var b = t, c = 0; c < a.length; c++)
      if (((b = b[a[c]]), b == null)) return null;
    return b;
  }
  function la(a) {
    var b = typeof a;
    return b != "object" ? b : a ? (Array.isArray(a) ? "array" : b) : "null";
  }
  function ma(a) {
    var b = typeof a;
    return (b == "object" && a != null) || b == "function";
  }
  function na(a) {
    return (
      (Object.prototype.hasOwnProperty.call(a, oa) && a[oa]) || (a[oa] = ++pa)
    );
  }
  var oa = "closure_uid_" + ((Math.random() * 1e9) >>> 0),
    pa = 0;
  function qa(a, b, c) {
    a = a.split(".");
    c = c || t;
    for (var d; a.length && (d = a.shift()); )
      a.length || b === void 0
        ? c[d] && c[d] !== Object.prototype[d]
          ? (c = c[d])
          : (c = c[d] = {})
        : (c[d] = b);
  }
  function ra(a) {
    t.setTimeout(() => {
      throw a;
    }, 0);
  }
  var ta,
    ua = ka("CLOSURE_FLAGS"),
    va = ua && ua[748402147];
  ta = va != null ? va : !0;
  function wa(a) {
    return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1];
  }
  function xa(a, b) {
    var c = 0;
    a = wa(String(a)).split(".");
    b = wa(String(b)).split(".");
    var d = Math.max(a.length, b.length);
    for (let g = 0; c == 0 && g < d; g++) {
      var e = a[g] || "",
        f = b[g] || "";
      do {
        e = /(\d*)(\D*)(.*)/.exec(e) || ["", "", "", ""];
        f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
        if (e[0].length == 0 && f[0].length == 0) break;
        c =
          ya(
            e[1].length == 0 ? 0 : parseInt(e[1], 10),
            f[1].length == 0 ? 0 : parseInt(f[1], 10)
          ) ||
          ya(e[2].length == 0, f[2].length == 0) ||
          ya(e[2], f[2]);
        e = e[3];
        f = f[3];
      } while (c == 0);
    }
    return c;
  }
  function ya(a, b) {
    return a < b ? -1 : a > b ? 1 : 0;
  }
  function za() {
    var a = t.navigator;
    return a && (a = a.userAgent) ? a : "";
  }
  function u(a) {
    return za().indexOf(a) != -1;
  }
  function Aa() {
    return ((u("Chrome") || u("CriOS")) && !u("Edge")) || u("Silk");
  }
  function Ba(a) {
    var b = {};
    a.forEach((c) => {
      b[c[0]] = c[1];
    });
    return (c) => b[c.find((d) => d in b)] || "";
  }
  function Ca() {
    var a = za();
    if (u("Trident") || u("MSIE")) {
      var b = /rv: *([\d\.]*)/.exec(a);
      if (b && b[1]) a = b[1];
      else {
        b = "";
        var c = /MSIE +([\d\.]+)/.exec(a);
        if (c && c[1])
          if (((a = /Trident\/(\d.\d)/.exec(a)), c[1] == "7.0"))
            if (a && a[1])
              switch (a[1]) {
                case "4.0":
                  b = "8.0";
                  break;
                case "5.0":
                  b = "9.0";
                  break;
                case "6.0":
                  b = "10.0";
                  break;
                case "7.0":
                  b = "11.0";
              }
            else b = "7.0";
          else b = c[1];
        a = b;
      }
      return a;
    }
    c = RegExp("([A-Z][\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g");
    b = [];
    for (var d; (d = c.exec(a)); ) b.push([d[1], d[2], d[3] || void 0]);
    a = Ba(b);
    return u("Opera")
      ? a(["Version", "Opera"])
      : u("Edge")
      ? a(["Edge"])
      : u("Edg/")
      ? a(["Edg"])
      : u("Silk")
      ? a(["Silk"])
      : Aa()
      ? a(["Chrome", "CriOS", "HeadlessChrome"])
      : ((a = b[2]) && a[1]) || "";
  }
  function Da(a, b) {
    if (typeof a === "string")
      return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
    for (let c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
    return -1;
  }
  function Ga(a, b) {
    var c = a.length,
      d = [],
      e = 0,
      f = typeof a === "string" ? a.split("") : a;
    for (let g = 0; g < c; g++)
      if (g in f) {
        let h = f[g];
        b.call(void 0, h, g, a) && (d[e++] = h);
      }
    return d;
  }
  function Ha(a, b) {
    var c = a.length,
      d = Array(c),
      e = typeof a === "string" ? a.split("") : a;
    for (let f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
    return d;
  }
  function Ia(a, b) {
    var c = a.length,
      d = typeof a === "string" ? a.split("") : a;
    for (let e = 0; e < c; e++)
      if (e in d && b.call(void 0, d[e], e, a)) return !0;
    return !1;
  }
  function Ja(a, b) {
    a: {
      var c = a.length;
      let d = typeof a === "string" ? a.split("") : a;
      for (--c; c >= 0; c--)
        if (c in d && b.call(void 0, d[c], c, a)) {
          b = c;
          break a;
        }
      b = -1;
    }
    return b < 0 ? null : typeof a === "string" ? a.charAt(b) : a[b];
  }
  function Ka(a, b) {
    return Da(a, b) >= 0;
  }
  function La(a) {
    var b = a.length;
    if (b > 0) {
      let c = Array(b);
      for (let d = 0; d < b; d++) c[d] = a[d];
      return c;
    }
    return [];
  }
  function Ma(a) {
    Ma[" "](a);
    return a;
  }
  Ma[" "] = function () {};
  const Na = {};
  let Oa = null;
  function Pa(a) {
    var b = [];
    Qa(a, function (c) {
      b.push(c);
    });
    return b;
  }
  function Qa(a, b) {
    function c(e) {
      for (; d < a.length; ) {
        let f = a.charAt(d++),
          g = Oa[f];
        if (g != null) return g;
        if (!/^[\s\xa0]*$/.test(f))
          throw Error("Unknown base64 encoding at char: " + f);
      }
      return e;
    }
    Ra();
    for (var d = 0; ; ) {
      let e = c(-1),
        f = c(0),
        g = c(64),
        h = c(64);
      if (h === 64 && e === -1) break;
      b((e << 2) | (f >> 4));
      g != 64 &&
        (b(((f << 4) & 240) | (g >> 2)), h != 64 && b(((g << 6) & 192) | h));
    }
  }
  function Ra() {
    if (!Oa) {
      Oa = {};
      var a =
          "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
            ""
          ),
        b = ["+/=", "+/", "-_=", "-_.", "-_"];
      for (let c = 0; c < 5; c++) {
        let d = a.concat(b[c].split(""));
        Na[c] = d;
        for (let e = 0; e < d.length; e++) {
          let f = d[e];
          Oa[f] === void 0 && (Oa[f] = e);
        }
      }
    }
  }
  function Sa(a, b) {
    a.__closure__error__context__984382 ||
      (a.__closure__error__context__984382 = {});
    a.__closure__error__context__984382.severity = b;
  }
  let Ta = void 0,
    Ua;
  function Va(a) {
    if (Ua) throw Error("");
    Ua = (b) => {
      t.setTimeout(() => {
        a(b);
      }, 0);
    };
  }
  function Wa(a) {
    if (Ua)
      try {
        Ua(a);
      } catch (b) {
        throw ((b.cause = a), b);
      }
  }
  function Xa(a) {
    a = Error(a);
    Sa(a, "warning");
    Wa(a);
    return a;
  }
  function Ya(a, b = !1) {
    return b && Symbol.for && a
      ? Symbol.for(a)
      : a != null
      ? Symbol(a)
      : Symbol();
  }
  var Za = Ya(),
    $a = Ya(),
    ab = Ya(),
    bb = Ya("m_m", !0);
  const v = Ya("jas", !0);
  var cb;
  const db = [];
  db[v] = 7;
  cb = Object.freeze(db);
  function eb(a) {
    if (4 & a) return 512 & a ? 512 : 1024 & a ? 1024 : 0;
  }
  function fb(a) {
    a[v] |= 32;
    return a;
  }
  function gb(a, b) {
    2 & b && (a |= 2);
    return a | 1;
  }
  var hb = {};
  function ib(a, b) {
    return b === void 0
      ? a.i !== jb && !!(2 & (a.B[v] | 0))
      : !!(2 & b) && a.i !== jb;
  }
  const jb = {};
  var kb = Object.freeze({});
  Object.freeze({});
  function lb(a) {
    a.Qc = !0;
    return a;
  }
  var mb = lb((a) => typeof a === "number"),
    x = lb((a) => typeof a === "string"),
    nb = lb((a) => typeof a === "boolean"),
    ob = lb((a) => typeof a === "bigint"),
    pb = lb((a) => typeof a === "function"),
    qb = lb((a) => Array.isArray(a));
  function rb() {
    return lb((a) => (qb(a) ? a.every((b) => mb(b)) : !1));
  }
  function sb(a) {
    if (x(a)) {
      if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(a)) throw Error(String(a));
    } else if (mb(a) && !Number.isSafeInteger(a)) throw Error(String(a));
    return BigInt(a);
  }
  var tb = lb((a) => ob(a)),
    wb = lb((a) => a >= ub && a <= vb);
  const ub = BigInt(Number.MIN_SAFE_INTEGER),
    vb = BigInt(Number.MAX_SAFE_INTEGER);
  let xb = 0,
    yb = 0;
  function zb(a) {
    var b = a >>> 0;
    xb = b;
    yb = ((a - b) / 4294967296) >>> 0;
  }
  function Ab(a, b = `unexpected value ${a}!`) {
    throw Error(b);
  }
  const Bb = typeof BigInt === "function" ? BigInt.asIntN : void 0,
    Cb = Number.isSafeInteger,
    Db = Number.isFinite,
    Eb = Math.trunc;
  function Fb(a) {
    if (typeof a !== "number")
      throw Error(
        `Value of float/double field must be a number, found ${typeof a}: ${a}`
      );
    return a;
  }
  function Gb(a) {
    if (a == null || typeof a === "number") return a;
    if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a);
  }
  function Hb(a) {
    if (a != null && typeof a !== "boolean")
      throw Error(`Expected boolean but got ${la(a)}: ${a}`);
    return a;
  }
  const Ib = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
  function Jb(a) {
    switch (typeof a) {
      case "bigint":
        return !0;
      case "number":
        return Db(a);
      case "string":
        return Ib.test(a);
      default:
        return !1;
    }
  }
  function Kb(a) {
    if (!Db(a)) throw Xa("enum");
    return a | 0;
  }
  function y(a) {
    return a == null ? a : Db(a) ? a | 0 : void 0;
  }
  function Lb(a) {
    if (typeof a !== "number") throw Xa("int32");
    if (!Db(a)) throw Xa("int32");
    return a | 0;
  }
  function Mb(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return Db(a) ? a | 0 : void 0;
  }
  function Nb(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return Db(a) ? a >>> 0 : void 0;
  }
  function Ob(a) {
    if (!Jb(a)) throw Xa("int64");
    switch (typeof a) {
      case "string":
        return Pb(a);
      case "bigint":
        return sb(Bb(64, a));
      default:
        return sb(Cb(a) ? a : Qb(a));
    }
  }
  function Qb(a) {
    a = Eb(a);
    if (Cb(a)) var b = String(a);
    else {
      if (a < 0) {
        zb(-a);
        a = xb;
        var c = yb;
        c = ~c;
        a ? (a = ~a + 1) : (c += 1);
        let [d, e] = [a, c];
        xb = d >>> 0;
        yb = e >>> 0;
      } else zb(a);
      a = xb;
      c = yb;
      c & 2147483648
        ? (b = "" + ((BigInt(c | 0) << BigInt(32)) | BigInt(a >>> 0)))
        : ((c >>>= 0),
          (a >>>= 0),
          c <= 2097151
            ? (b = "" + (4294967296 * c + a))
            : (b = "" + ((BigInt(c) << BigInt(32)) | BigInt(a))));
    }
    return b;
  }
  function Pb(a) {
    var b = Eb(Number(a));
    if (Cb(b)) return sb(b);
    b = a.indexOf(".");
    b !== -1 && (a = a.substring(0, b));
    return sb(Bb(64, BigInt(a)));
  }
  function Rb(a) {
    var b = typeof a;
    if (a == null) return a;
    if (b === "bigint") return sb(Bb(64, a));
    if (Jb(a)) return b === "string" ? Pb(a) : sb(Cb(a) ? a : Qb(a));
  }
  function Sb(a) {
    if (typeof a !== "string") throw Error();
    return a;
  }
  function Tb(a) {
    if (a != null && typeof a !== "string") throw Error();
    return a;
  }
  function Ub(a) {
    return a == null || typeof a === "string" ? a : void 0;
  }
  function Vb(a, b, c, d) {
    if (a != null && a[bb] === hb) return a;
    if (!Array.isArray(a))
      return c ? (d & 2 ? b[Za] || (b[Za] = Wb(b)) : new b()) : void 0;
    c = a[v] | 0;
    d = c | (d & 32) | (d & 2);
    d !== c && (a[v] = d);
    return new b(a);
  }
  function Wb(a) {
    a = new a();
    var b = a.B;
    b[v] |= 34;
    return a;
  }
  function Xb(a) {
    return a;
  }
  function Yb(a, b, c, d) {
    var e = d !== void 0;
    d = !!d;
    var f = [],
      g = a.length,
      h = 4294967295,
      k = !1,
      l = !!(b & 64),
      m = l ? (b & 128 ? 0 : -1) : void 0;
    if (!(b & 1)) {
      var n = g && a[g - 1];
      n != null && typeof n === "object" && n.constructor === Object
        ? (g--, (h = g))
        : (n = void 0);
      !l ||
        b & 128 ||
        e ||
        ((k = !0), (h = (Zb ?? Xb)(h - m, m, a, n, void 0) + m));
    }
    b = void 0;
    for (e = 0; e < g; e++) {
      let p = a[e];
      if (p != null && (p = c(p, d)) != null)
        if (l && e >= h) {
          let r = e - m;
          (b ?? (b = {}))[r] = p;
        } else f[e] = p;
    }
    if (n)
      for (let p in n) {
        if (!Object.prototype.hasOwnProperty.call(n, p)) continue;
        a = n[p];
        if (a == null || (a = c(a, d)) == null) continue;
        g = +p;
        let r;
        l && !Number.isNaN(g) && (r = g + m) < h
          ? (f[r] = a)
          : ((b ?? (b = {}))[p] = a);
      }
    b && (k ? f.push(b) : (f[h] = b));
    return f;
  }
  function $b(a) {
    switch (typeof a) {
      case "number":
        return Number.isFinite(a) ? a : "" + a;
      case "bigint":
        return wb(a) ? Number(a) : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          let b = a[v] | 0;
          return a.length === 0 && b & 1 ? void 0 : Yb(a, b, $b);
        }
        if (a != null && a[bb] === hb) return z(a);
        return;
    }
    return a;
  }
  var ac =
    typeof structuredClone != "undefined"
      ? structuredClone
      : (a) => Yb(a, 0, $b);
  let Zb;
  function z(a) {
    a = a.B;
    return Yb(a, a[v] | 0, $b);
  }
  function bc(a, b, c, d = 0) {
    if (a == null) {
      var e = 32;
      c ? ((a = [c]), (e |= 128)) : (a = []);
      b && (e = (e & -16760833) | ((b & 1023) << 14));
    } else {
      if (!Array.isArray(a)) throw Error("narr");
      e = a[v] | 0;
      if (ta && 1 & e) throw Error("rfarr");
      2048 & e && !(2 & e) && cc();
      if (e & 256) throw Error("farr");
      if (e & 64) return (e | d) !== e && (a[v] = e | d), a;
      if (c && ((e |= 128), c !== a[0])) throw Error("mid");
      a: {
        c = a;
        e |= 64;
        var f = c.length;
        if (f) {
          var g = f - 1;
          let k = c[g];
          if (k != null && typeof k === "object" && k.constructor === Object) {
            b = e & 128 ? 0 : -1;
            g -= b;
            if (g >= 1024) throw Error("pvtlmt");
            for (var h in k) {
              if (!Object.prototype.hasOwnProperty.call(k, h)) continue;
              f = +h;
              if (f < g) (c[f + b] = k[h]), delete k[h];
              else break;
            }
            e = (e & -16760833) | ((g & 1023) << 14);
            break a;
          }
        }
        if (b) {
          h = Math.max(b, f - (e & 128 ? 0 : -1));
          if (h > 1024) throw Error("spvt");
          e = (e & -16760833) | ((h & 1023) << 14);
        }
      }
    }
    a[v] = e | 64 | d;
    return a;
  }
  function cc() {
    if (ta) throw Error("carr");
    if (ab != null) {
      var a = Ta ?? (Ta = {});
      var b = a[ab] || 0;
      b >= 5 ||
        ((a[ab] = b + 1), (a = Error()), Sa(a, "incident"), Ua ? Wa(a) : ra(a));
    }
  }
  function dc(a, b) {
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      var c = a[v] | 0;
      a.length === 0 && c & 1
        ? (a = void 0)
        : c & 2 ||
          (!b || 4096 & c || 16 & c
            ? (a = ec(a, c, !1, b && !(c & 16)))
            : ((a[v] |= 34), c & 4 && Object.freeze(a)));
      return a;
    }
    if (a != null && a[bb] === hb)
      return (
        (b = a.B),
        (c = b[v] | 0),
        ib(a, c) ? a : fc(a, b, c) ? hc(a, b) : ec(b, c)
      );
  }
  function hc(a, b, c) {
    a = new a.constructor(b);
    c && (a.i = jb);
    a.D = jb;
    return a;
  }
  function ec(a, b, c, d) {
    d ?? (d = !!(34 & b));
    a = Yb(a, b, dc, d);
    d = 32;
    c && (d |= 2);
    b = (b & 16769217) | d;
    a[v] = b;
    return a;
  }
  function jc(a) {
    var b = a.B,
      c = b[v] | 0;
    return ib(a, c)
      ? fc(a, b, c)
        ? hc(a, b, !0)
        : new a.constructor(ec(b, c, !1))
      : a;
  }
  function kc(a) {
    var b = a.B,
      c = b[v] | 0;
    return ib(a, c)
      ? a
      : fc(a, b, c)
      ? hc(a, b)
      : new a.constructor(ec(b, c, !0));
  }
  function lc(a) {
    if (a.i !== jb) return !1;
    var b = a.B;
    b = ec(b, b[v] | 0);
    b[v] |= 2048;
    a.B = b;
    a.i = void 0;
    a.D = void 0;
    return !0;
  }
  function mc(a) {
    if (!lc(a) && ib(a, a.B[v] | 0)) throw Error();
  }
  function nc(a, b) {
    b === void 0 && (b = a[v] | 0);
    b & 32 && !(b & 4096) && (a[v] = b | 4096);
  }
  function fc(a, b, c) {
    return c & 2
      ? !0
      : c & 32 && !(c & 4096)
      ? ((b[v] = c | 2), (a.i = jb), !0)
      : !1;
  }
  const oc = sb(0),
    pc = {};
  function A(a, b, c, d, e) {
    b = qc(a.B, b, c, e);
    if (b !== null || (d && a.D !== jb)) return b;
  }
  function rc(a, b, c) {
    return qc(a, b, void 0, c);
  }
  function qc(a, b, c, d) {
    if (b === -1) return null;
    var e = b + (c ? 0 : -1),
      f = a.length - 1;
    if (!(f < 1 + (c ? 0 : -1))) {
      if (e >= f) {
        var g = a[f];
        if (g != null && typeof g === "object" && g.constructor === Object) {
          c = g[b];
          var h = !0;
        } else if (e === f) c = g;
        else return;
      } else c = a[e];
      if (d && c != null) {
        d = d(c);
        if (d == null) return d;
        if (!Object.is(d, c)) return h ? (g[b] = d) : (a[e] = d), d;
      }
      return c;
    }
  }
  function B(a, b, c) {
    mc(a);
    var d = a.B;
    sc(d, d[v] | 0, b, c);
    return a;
  }
  function sc(a, b, c, d) {
    var e = c + -1,
      f = a.length - 1;
    if (f >= 0 && e >= f) {
      let g = a[f];
      if (g != null && typeof g === "object" && g.constructor === Object)
        return (g[c] = d), b;
    }
    if (e <= f) return (a[e] = d), b;
    d !== void 0 &&
      ((f = ((b ?? (b = a[v] | 0)) >> 14) & 1023 || 536870912),
      c >= f ? d != null && (a[f + -1] = { [c]: d }) : (a[e] = d));
    return b;
  }
  function tc(a, b) {
    a = qc(a.B, b);
    return (a != null && a[bb] === hb) || Array.isArray(a);
  }
  function uc() {
    var a = vc;
    return a && a === kb ? 2 : 4;
  }
  function wc(a, b, c, d, e) {
    var f = a.B,
      g = f[v] | 0;
    d = d && d !== 4 ? (d !== 1 && (a ? ib(a, g) : 2 & g) ? 1 : d) : 4;
    e = !!e || d === 3;
    d === 2 && lc(a) && ((f = a.B), (g = f[v] | 0));
    a = xc(f, b);
    var h = a === cb ? 7 : a[v] | 0,
      k = gb(h, g);
    var l = !(4 & k);
    if (l) {
      let m = 0,
        n = 0;
      for (; m < a.length; m++) {
        let p = c(a[m]);
        p != null && (a[n++] = p);
      }
      n < m && (a.length = n);
      c = (k | 4) & -513;
      k = c &= -1025;
      k &= -4097;
    }
    k !== h && ((a[v] = k), 2 & k && Object.freeze(a));
    return (a = yc(a, k, f, g, b, d, l, e));
  }
  function yc(a, b, c, d, e, f, g, h) {
    var k = b,
      l = zc(b);
    l &&
      f === 2 &&
      ((a = [...a]), (k = 0), (b = Ac(b, d)), (d = sc(c, d, e, a)), (l = !1));
    l ||
      (f === 1 || (f !== 4 ? 0 : 2 & b || (!(16 & b) && 32 & d))
        ? ((b |=
            !a.length || (g && !(4096 & b)) || (32 & d && !(4096 & b || 16 & b))
              ? 2
              : 256),
          b !== k && (a[v] = b),
          Object.freeze(a))
        : (h || (b |= 16), b !== k && (a[v] = b)));
    2 & b || !(4096 & b || 16 & b) || nc(c, d);
    return a;
  }
  function xc(a, b) {
    a = qc(a, b);
    return Array.isArray(a) ? a : cb;
  }
  function zc(a) {
    return (!!(2 & a) && !!(4 & a)) || !!(256 & a);
  }
  function Bc(a, b, c, d) {
    mc(a);
    var e = a.B,
      f = e[v] | 0;
    if (c == null) return sc(e, f, b), a;
    var g = c === cb ? 7 : c[v] | 0,
      h = g,
      k = zc(g),
      l = k || Object.isFrozen(c);
    k || (g = 0);
    l || ((c = [...c]), (h = 0), (g = Ac(g, f)), (l = !1));
    g |= 5;
    k = eb(g) ?? 1024;
    g |= k;
    for (let m = 0; m < c.length; m++) {
      let n = c[m],
        p = d(n, k);
      Object.is(n, p) ||
        (l && ((c = [...c]), (h = 0), (g = Ac(g, f)), (l = !1)), (c[m] = p));
    }
    g !== h && (l && ((c = [...c]), (g = Ac(g, f))), (c[v] = g));
    sc(e, f, b, c);
    return a;
  }
  function Cc(a, b, c, d) {
    mc(a);
    var e = a.B;
    sc(e, e[v] | 0, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
    return a;
  }
  function Dc(a, b, c, d) {
    mc(a);
    var e = a.B,
      f = e[v] | 0;
    if (d == null) {
      var g = Ec(e);
      if (Fc(g, e, f, c) === b) g.set(c, 0);
      else return a;
    } else {
      g = Ec(e);
      let h = Fc(g, e, f, c);
      h !== b && (h && (f = sc(e, f, h)), g.set(c, b));
    }
    sc(e, f, b, d);
    return a;
  }
  function Gc(a, b, c) {
    return Hc(a.B, b) === c ? c : -1;
  }
  function Hc(a, b) {
    return Fc(Ec(a), a, void 0, b);
  }
  function Ec(a) {
    return a[$a] ?? (a[$a] = new Map());
  }
  function Fc(a, b, c, d) {
    var e = a.get(d);
    if (e != null) return e;
    e = 0;
    for (let f = 0; f < d.length; f++) {
      let g = d[f];
      qc(b, g) != null && (e !== 0 && (c = sc(b, c, e)), (e = g));
    }
    a.set(d, e);
    return e;
  }
  function Ic(a, b, c) {
    mc(a);
    a = a.B;
    var d = a[v] | 0,
      e = qc(a, c);
    b = Vb(e, b, !0, d);
    b = jc(b);
    e !== b && ((d = sc(a, d, c, b)), nc(a, d));
    return b;
  }
  function Jc(a, b, c, d) {
    var e = !1;
    d = rc(a, d, (f) => {
      var g = Vb(f, c, !1, b);
      e = g !== f && g != null;
      return g;
    });
    if (d != null) return e && !ib(d) && nc(a, b), d;
  }
  function Kc(a) {
    var b = Lc;
    a = a.B;
    return Jc(a, a[v] | 0, b, 4) || b[Za] || (b[Za] = Wb(b));
  }
  function C(a, b, c) {
    var d = a.B,
      e = d[v] | 0;
    b = Jc(d, e, b, c);
    if (b == null) return b;
    e = d[v] | 0;
    if (!ib(a, e)) {
      let f = jc(b);
      f !== b &&
        (lc(a) && ((d = a.B), (e = d[v] | 0)),
        (b = f),
        (e = sc(d, e, c, b)),
        nc(d, e));
    }
    return b;
  }
  function Mc(a, b, c, d, e, f, g, h) {
    f = f && f !== 4 ? (f !== 1 && (a ? ib(a, c) : 2 & c) ? 1 : f) : 4;
    g = !!g || f === 3;
    var k = !!h && !(a ? ib(a, c) : 2 & c);
    (f === 2 || k) && a && lc(a) && ((b = a.B), (c = b[v] | 0));
    a = xc(b, e);
    var l = a === cb ? 7 : a[v] | 0,
      m = gb(l, c);
    if ((h = !(4 & m))) {
      var n = a,
        p = c;
      let r = !!(2 & m);
      r && (p |= 2);
      let q = !r,
        w = !0,
        G = 0,
        Y = 0;
      for (; G < n.length; G++) {
        let Ea = Vb(n[G], d, !1, p);
        if (Ea instanceof d) {
          if (!r) {
            let Fa = ib(Ea);
            q && (q = !Fa);
            w && (w = Fa);
          }
          n[Y++] = Ea;
        }
      }
      Y < G && (n.length = Y);
      m |= 4;
      m = w ? m & -4097 : m | 4096;
      m = q ? m | 8 : m & -9;
    }
    m !== l && ((a[v] = m), 2 & m && Object.freeze(a));
    if (
      k &&
      !(
        8 & m ||
        (!a.length &&
          (f === 1 || (f !== 4 ? 0 : 2 & m || (!(16 & m) && 32 & c))))
      )
    ) {
      zc(m) && ((a = [...a]), (m = Ac(m, c)), (c = sc(b, c, e, a)));
      d = a;
      k = m;
      for (l = 0; l < d.length; l++)
        (n = d[l]), (m = jc(n)), n !== m && (d[l] = m);
      k |= 8;
      m = k = d.length ? k | 4096 : k & -4097;
      a[v] = m;
    }
    return (a = yc(a, m, b, c, e, f, h, g));
  }
  function D(a, b, c, d) {
    var e = a.B;
    return Mc(a, e, e[v] | 0, b, c, d, !1, !0);
  }
  function Nc(a) {
    a == null && (a = void 0);
    return a;
  }
  function E(a, b, c) {
    c = Nc(c);
    B(a, b, c);
    c && !ib(c) && nc(a.B);
    return a;
  }
  function F(a, b, c, d) {
    d = Nc(d);
    Dc(a, b, c, d);
    d && !ib(d) && nc(a.B);
    return a;
  }
  function Oc(a, b, c) {
    mc(a);
    var d = a.B,
      e = d[v] | 0;
    if (c == null) sc(d, e, b);
    else {
      var f = c === cb ? 7 : c[v] | 0,
        g = f,
        h = zc(f),
        k = h || Object.isFrozen(c),
        l = !0,
        m = !0;
      for (let p = 0; p < c.length; p++) {
        var n = c[p];
        h || ((n = ib(n)), l && (l = !n), m && (m = n));
      }
      h || ((f = l ? 13 : 5), (f = m ? f & -4097 : f | 4096));
      (k && f === g) || ((c = [...c]), (g = 0), (f = Ac(f, e)));
      f !== g && (c[v] = f);
      e = sc(d, e, b, c);
      2 & f || !(4096 & f || 16 & f) || nc(d, e);
    }
    return a;
  }
  function Ac(a, b) {
    return (a = (2 & b ? a | 2 : a & -3) & -273);
  }
  function Pc(a, b) {
    mc(a);
    a = wc(a, 4, Ub, 2, !0);
    var c = eb(a === cb ? 7 : a[v] | 0) ?? 1024;
    if (Array.isArray(b)) {
      var d = b.length;
      for (let e = 0; e < d; e++) a.push(Sb(b[e], c));
    } else for (d of b) a.push(Sb(d, c));
  }
  function Qc(a, b) {
    return A(a, b, void 0, void 0, Rb);
  }
  function Rc(a, b) {
    a = A(a, b);
    return a == null || typeof a === "boolean"
      ? a
      : typeof a === "number"
      ? !!a
      : void 0;
  }
  function H(a, b, c, d) {
    return Ub(A(a, b, c, d));
  }
  function I(a, b) {
    return Rc(a, b) ?? !1;
  }
  function J(a, b) {
    return Mb(A(a, b)) ?? 0;
  }
  function Sc(a, b) {
    return A(a, b, void 0, void 0, Gb) ?? 0;
  }
  function K(a, b) {
    return H(a, b) ?? "";
  }
  function L(a, b) {
    return y(A(a, b)) ?? 0;
  }
  function Tc(a, b, c) {
    return L(a, Gc(a, c, b));
  }
  function Uc(a, b) {
    return y(A(a, b, void 0, pc));
  }
  function Vc(a, b, c) {
    return B(a, b, c == null ? c : Lb(c));
  }
  function M(a, b, c) {
    return Cc(a, b, c == null ? c : Lb(c), 0);
  }
  function N(a, b, c) {
    return B(a, b, c == null ? c : Ob(c));
  }
  function Wc(a, b, c) {
    return Cc(a, b, c == null ? c : Ob(c), "0");
  }
  function Xc(a, b, c) {
    return Dc(a, 2, b, c == null ? c : Ob(c));
  }
  function Yc(a, b, c) {
    return B(a, b, c == null ? c : Fb(c));
  }
  function Zc(a, b) {
    var c = performance.now();
    Cc(a, b, c == null ? c : Fb(c), 0);
  }
  function $c(a, b, c) {
    return B(a, b, Tb(c));
  }
  function ad(a, b, c) {
    return Cc(a, b, Tb(c), "");
  }
  function bd(a, b, c) {
    return B(a, b, c == null ? c : Kb(c));
  }
  function cd(a, b, c) {
    return Cc(a, b, c == null ? c : Kb(c), 0);
  }
  function dd(a, b, c, d) {
    return Dc(a, b, c, d == null ? d : Kb(d));
  }
  function ed(a) {
    return kc(a);
  }
  var O = class {
    constructor(a) {
      this.B = bc(a, void 0, void 0, 2048);
    }
    toJSON() {
      return z(this);
    }
    C() {
      return JSON.stringify(z(this));
    }
  };
  O.prototype[bb] = hb;
  function fd(a, b) {
    if (b == null) return new a();
    if (!Array.isArray(b)) throw Error();
    if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b))
      throw Error();
    return new a(fb(b));
  }
  function gd(a) {
    return () => a[Za] || (a[Za] = Wb(a));
  }
  function hd(a) {
    return (b) => {
      if (b == null || b == "") b = new a();
      else {
        b = JSON.parse(b);
        if (!Array.isArray(b)) throw Error("dnarr");
        b = new a(fb(b));
      }
      return b;
    };
  }
  var id = class extends O {};
  var jd = class extends O {};
  function kd(a, b) {
    if (a)
      for (let c in a)
        Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a);
  }
  function ld(a) {
    try {
      var b;
      if ((b = !!a && a.location.href != null))
        a: {
          try {
            Ma(a.foo);
            b = !0;
            break a;
          } catch (c) {}
          b = !1;
        }
      return b;
    } catch {
      return !1;
    }
  }
  function md(a) {
    return ld(a.top) ? a.top : null;
  }
  function nd(a) {
    for (var b = a; a && a !== a.parent; ) (a = a.parent), ld(a) && (b = a);
    return b;
  }
  function od(a) {
    var b = !1,
      c;
    return function () {
      b || ((c = a()), (b = !0));
      return c;
    };
  }
  function pd(a) {
    var b = a;
    return function () {
      if (b) {
        let c = b;
        b = null;
        c();
      }
    };
  }
  function qd() {
    return !rd() && (u("iPod") || u("iPhone") || u("Android") || u("IEMobile"));
  }
  function rd() {
    return u("iPad") || (u("Android") && !u("Mobile")) || u("Silk");
  } /* 
 
 Copyright Google LLC 
 SPDX-License-Identifier: Apache-2.0 
*/
  let sd = globalThis.trustedTypes,
    td;
  function ud() {
    var a = null;
    if (!sd) return a;
    try {
      let b = (c) => c;
      a = sd.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (b) {}
    return a;
  }
  var vd = class {
    constructor(a) {
      this.h = a;
    }
    toString() {
      return this.h + "";
    }
  };
  function wd(a) {
    var b;
    td === void 0 && (td = ud());
    a = (b = td) ? b.createScriptURL(a) : a;
    return new vd(a);
  }
  function xd(a) {
    if (a instanceof vd) return a.h;
    throw Error("");
  }
  var yd = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  function zd(a = document) {
    a = a.querySelector?.("script[nonce]");
    return a == null ? "" : a.nonce || a.getAttribute("nonce") || "";
  }
  const Ad =
    "alternate author bookmark canonical cite help icon license modulepreload next prefetch dns-prefetch prerender preconnect preload prev search subresource".split(
      " "
    );
  function Bd(a) {
    return String(a).replace(/\-([a-z])/g, function (b, c) {
      return c.toUpperCase();
    });
  }
  var Cd = od(() => (qd() ? 2 : rd() ? 1 : 0));
  function Dd() {
    if (!globalThis.crypto) return Math.random();
    try {
      let a = new Uint32Array(1);
      globalThis.crypto.getRandomValues(a);
      return a[0] / 65536 / 65536;
    } catch (a) {
      return Math.random();
    }
  }
  let Ed,
    Fd = 64;
  function Gd() {
    try {
      return (
        Ed ?? (Ed = new Uint32Array(64)),
        Fd >= 64 && (crypto.getRandomValues(Ed), (Fd = 0)),
        Ed[Fd++]
      );
    } catch (a) {
      return Math.floor(Math.random() * 2 ** 32);
    }
  }
  function Hd(a, b) {
    if (!mb(a.goog_pvsid))
      try {
        let c = Gd() + (Gd() & (2 ** 21 - 1)) * 2 ** 32;
        Object.defineProperty(a, "goog_pvsid", { value: c, configurable: !1 });
      } catch (c) {
        b.ia({ methodName: 784, Ia: c });
      }
    a = Number(a.goog_pvsid);
    (!a || a <= 0) &&
      b.ia({ methodName: 784, Ia: Error(`Invalid correlator, ${a}`) });
    return a || -1;
  }
  function Id(a, ...b) {
    if (b.length === 0) return wd(a[0]);
    var c = a[0];
    for (let d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
    return wd(c);
  }
  function Jd(a, b) {
    a = xd(a).toString();
    var c = a.split(/[?#]/),
      d = /[?]/.test(a) ? "?" + c[1] : "";
    return Kd(c[0], d, /[#]/.test(a) ? "#" + (d ? c[2] : c[1]) : "", b);
  }
  function Kd(a, b, c, d) {
    function e(g, h) {
      g != null &&
        (Array.isArray(g)
          ? g.forEach((k) => e(k, h))
          : ((b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g)),
            (f = "&")));
    }
    var f = b.length ? "&" : "?";
    d.constructor === Object && (d = Object.entries(d));
    Array.isArray(d) ? d.forEach((g) => e(g[1], g[0])) : d.forEach(e);
    return wd(a + b + c);
  }
  function Ld(a, b, c) {
    var d = Md("SCRIPT", a);
    d.src = xd(b);
    (b = zd(d.ownerDocument)) && d.setAttribute("nonce", b);
    c && d.setAttribute("fetchpriority", c);
    (a = a.getElementsByTagName("script")[0]) &&
      a.parentNode &&
      a.parentNode.insertBefore(d, a);
  }
  function Nd(a, b) {
    return b.getComputedStyle ? b.getComputedStyle(a, null) : a.currentStyle;
  }
  var Od = /^([0-9.]+)px$/,
    Pd = /^(-?[0-9.]{1,30})$/;
  function Qd(a) {
    if (!Pd.test(a)) return null;
    a = Number(a);
    return isNaN(a) ? null : a;
  }
  function Rd(a) {
    return (a = Od.exec(a)) ? +a[1] : null;
  }
  var Sd = (a) => {
    kd({ display: "none" }, (b, c) => {
      a.style.setProperty(c, b, "important");
    });
  };
  function Td() {
    var a = P(Ud).i(Vd.h, Vd.defaultValue),
      b = Q.document;
    if (a.length && b.head)
      for (let c of a)
        a: {
          if (!c || !b.head) break a;
          a = Md("META");
          b.head.appendChild(a);
          a.httpEquiv = "origin-trial";
          a.content = c;
        }
  }
  var Wd = (a) => Hd(a, { ia: () => {} });
  function Md(a, b = document) {
    return b.createElement(String(a).toLowerCase());
  }
  let Xd = [];
  function Yd() {
    var a = Xd;
    Xd = [];
    for (let b of a)
      try {
        b();
      } catch {}
  }
  function Zd(a, b) {
    this.width = a;
    this.height = b;
  }
  Zd.prototype.aspectRatio = function () {
    return this.width / this.height;
  };
  Zd.prototype.isEmpty = function () {
    return !(this.width * this.height);
  };
  Zd.prototype.ceil = function () {
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this;
  };
  Zd.prototype.floor = function () {
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this;
  };
  Zd.prototype.round = function () {
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this;
  };
  function $d(a, b) {
    var c = {};
    for (let d in a) b.call(void 0, a[d], d, a) && (c[d] = a[d]);
    return c;
  }
  function ae(a, b) {
    for (let c in a) if (b.call(void 0, a[c], c, a)) return !0;
    return !1;
  }
  function be(a) {
    var b = [],
      c = 0;
    for (let d in a) b[c++] = a[d];
    return b;
  }
  function ce(a, b) {
    b = String(b);
    a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
    return a.createElement(b);
  }
  function de(a) {
    this.h = a || t.document || document;
  }
  function ee(a, b, c) {
    typeof a.addEventListener === "function" && a.addEventListener(b, c, !1);
  }
  function fe(a, b, c) {
    return typeof a.removeEventListener === "function"
      ? (a.removeEventListener(b, c, !1), !0)
      : !1;
  }
  function ge(a) {
    var b = he;
    b.readyState === "complete" || b.readyState === "interactive"
      ? (Xd.push(a),
        Xd.length === 1 &&
          (window.Promise
            ? Promise.resolve().then(Yd)
            : ((a = window.setImmediate), pb(a) ? a(Yd) : setTimeout(Yd, 0))))
      : b.addEventListener("DOMContentLoaded", a);
  }
  function ie(a, b, c = null, d = !1, e = !1) {
    je(a, b, c, d, e);
  }
  function je(a, b, c, d, e = !1) {
    a.google_image_requests || (a.google_image_requests = []);
    var f = Md("IMG", a.document);
    if (c || d) {
      let g = (h) => {
        c && c(h);
        if (d) {
          h = a.google_image_requests;
          let k = Da(h, f);
          k >= 0 && Array.prototype.splice.call(h, k, 1);
        }
        fe(f, "load", g);
        fe(f, "error", g);
      };
      ee(f, "load", g);
      ee(f, "error", g);
    }
    e && (f.attributionSrc = "");
    f.src = b;
    a.google_image_requests.push(f);
  }
  function ke(a, b) {
    var c = `https://pagead2.googlesyndication.com/pagead/gen_204?id=${b}`;
    kd(a, (d, e) => {
      if (d || d === 0) c += `&${e}=${encodeURIComponent(String(d))}`;
    });
    le(c);
  }
  function le(a) {
    var b = window;
    b.fetch
      ? b.fetch(a, {
          keepalive: !0,
          credentials: "include",
          redirect: "follow",
          method: "get",
          mode: "no-cors",
        })
      : ie(b, a, void 0, !1, !1);
  }
  var he = document,
    Q = window;
  let me = null;
  var ne = (a, b = []) => {
    var c = !1;
    t.google_logging_queue || ((c = !0), (t.google_logging_queue = []));
    t.google_logging_queue.push([a, b]);
    if ((a = c)) {
      if (me == null) {
        me = !1;
        try {
          let d = md(t);
          d && d.location.hash.indexOf("google_logging") !== -1 && (me = !0);
        } catch (d) {}
      }
      a = me;
    }
    a &&
      Ld(
        t.document,
        Id`https://pagead2.googlesyndication.com/pagead/js/logging_library.js`
      );
  };
  function oe(a) {
    return !!(a.error && a.meta && a.id);
  }
  var pe = class {
    constructor(a, b) {
      this.error = a;
      this.meta = {};
      this.context = b.context;
      this.msg = b.message || "";
      this.id = b.id || "jserror";
    }
  };
  function qe(a) {
    return new pe(a, { message: re(a) });
  }
  function re(a) {
    var b = a.toString();
    a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
    a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
    if (a.stack)
      a: {
        a = a.stack;
        var c = b;
        try {
          a.indexOf(c) == -1 && (a = c + "\n" + a);
          let d;
          for (; a != d; )
            (d = a),
              (a = a.replace(
                RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"),
                "$1"
              ));
          b = a.replace(RegExp("\n *", "g"), "\n");
          break a;
        } catch (d) {
          b = c;
          break a;
        }
        b = void 0;
      }
    return b;
  }
  const se = RegExp(
    "^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)"
  );
  var te = class {
      constructor(a, b) {
        this.h = a;
        this.i = b;
      }
    },
    ue = class {
      constructor(a, b, c) {
        this.url = a;
        this.l = b;
        this.h = !!c;
        this.depth = null;
      }
    };
  let ve = null;
  function we() {
    var a = window;
    if (ve === null) {
      ve = "";
      try {
        let b = "";
        try {
          b = a.top.location.hash;
        } catch (c) {
          b = a.location.hash;
        }
        if (b) {
          let c = b.match(/\bdeid=([\d,]+)/);
          ve = c ? c[1] : "";
        }
      } catch (b) {}
    }
    return ve;
  }
  function xe() {
    var a = t.performance;
    return a && a.now && a.timing
      ? Math.floor(a.now() + a.timing.navigationStart)
      : Date.now();
  }
  function ye() {
    var a = t.performance;
    return a && a.now ? a.now() : null;
  }
  var ze = class {
    constructor(a, b) {
      var c = ye() || xe();
      this.label = a;
      this.type = b;
      this.value = c;
      this.duration = 0;
      this.taskId = this.slotId = void 0;
      this.uniqueId = Math.random();
    }
  };
  const Ae = t.performance,
    Be = !!(Ae && Ae.mark && Ae.measure && Ae.clearMarks),
    Ce = od(() => {
      var a;
      if ((a = Be)) (a = we()), (a = !!a.indexOf && a.indexOf("1337") >= 0);
      return a;
    });
  function De(a) {
    a &&
      Ae &&
      Ce() &&
      (Ae.clearMarks(`goog_${a.label}_${a.uniqueId}_start`),
      Ae.clearMarks(`goog_${a.label}_${a.uniqueId}_end`));
  }
  function Fe(a) {
    a.h = !1;
    if (a.events !== a.i.google_js_reporting_queue) {
      if (Ce()) {
        var b = a.events;
        let c = b.length;
        b = typeof b === "string" ? b.split("") : b;
        for (let d = 0; d < c; d++) d in b && De.call(void 0, b[d]);
      }
      a.events.length = 0;
    }
  }
  var Ge = class {
    constructor(a) {
      this.events = [];
      this.i = a || t;
      var b = null;
      a &&
        ((a.google_js_reporting_queue = a.google_js_reporting_queue || []),
        (this.events = a.google_js_reporting_queue),
        (b = a.google_measure_js_timing));
      this.h = Ce() || (b != null ? b : Math.random() < 1);
    }
    start(a, b) {
      if (!this.h) return null;
      a = new ze(a, b);
      b = `goog_${a.label}_${a.uniqueId}_start`;
      Ae && Ce() && Ae.mark(b);
      return a;
    }
    end(a) {
      if (this.h && mb(a.value)) {
        a.duration = (ye() || xe()) - a.value;
        var b = `goog_${a.label}_${a.uniqueId}_end`;
        Ae && Ce() && Ae.mark(b);
        !this.h || this.events.length > 2048 || this.events.push(a);
      }
    }
  };
  function He(a, b) {
    var c = {};
    c[a] = b;
    return [c];
  }
  function Ie(a, b, c, d, e) {
    var f = [];
    kd(a, (g, h) => {
      (g = Je(g, b, c, d, e)) && f.push(`${encodeURIComponent(h)}=${g}`);
    });
    return f.join(b);
  }
  function Je(a, b, c, d, e) {
    if (a == null) return "";
    b = b || "&";
    c = c || ",$";
    x(c) && (c = c.split(""));
    if (a instanceof Array) {
      if ((d || (d = 0), d < c.length)) {
        let f = [];
        for (let g = 0; g < a.length; g++) f.push(Je(a[g], b, c, d + 1, e));
        return f.join(c[d]);
      }
    } else if (typeof a === "object")
      return (
        e || (e = 0), e < 2 ? encodeURIComponent(Ie(a, b, c, d, e + 1)) : "..."
      );
    return encodeURIComponent(String(a));
  }
  function Ke(a) {
    var b = 1;
    for (let c in a.i) c.length > b && (b = c.length);
    return 3997 - b - a.j.length - 1;
  }
  function Le(a, b) {
    var c = Ke(a) - b.length;
    if (c < 0) return "";
    b = "";
    a.h.sort((f, g) => f - g);
    var d = null,
      e = "";
    for (let f = 0; f < a.h.length; f++) {
      let g = a.h[f],
        h = a.i[g];
      for (let k = 0; k < h.length; k++) {
        if (!c) {
          d = d == null ? g : d;
          break;
        }
        let l = Ie(h[k], a.j, ",$");
        if (l) {
          l = e + l;
          if (c >= l.length) {
            c -= l.length;
            b += l;
            e = a.j;
            break;
          }
          d = d == null ? g : d;
        }
      }
    }
    a = "";
    d != null && (a = `${e}trn=${d}`);
    return b + a;
  }
  function Me(a, b, c, d) {
    return Ke(a) - d.length < 0 ? "" : b + "//" + c + d + Le(a, d);
  }
  var Ne = class {
    constructor() {
      this.j = "&";
      this.i = {};
      this.u = 0;
      this.h = [];
    }
  };
  const Oe = RegExp(
      "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
    ),
    Pe = /#|$/;
  function Qe(a, b) {
    var c = a.search(Pe);
    a: {
      var d = 0;
      for (var e = b.length; (d = a.indexOf(b, d)) >= 0 && d < c; ) {
        var f = a.charCodeAt(d - 1);
        if (f == 38 || f == 63)
          if (((f = a.charCodeAt(d + e)), !f || f == 61 || f == 38 || f == 35))
            break a;
        d += e + 1;
      }
      d = -1;
    }
    if (d < 0) return null;
    e = a.indexOf("&", d);
    if (e < 0 || e > c) e = c;
    d += b.length + 1;
    return decodeURIComponent(a.slice(d, e !== -1 ? e : 0).replace(/\+/g, " "));
  }
  var Te = class {
    constructor(a = null) {
      this.pinger = Re;
      this.j = a;
      this.i = null;
      this.D = !1;
      this.H = this.M;
    }
    J(a) {
      this.H = a;
    }
    C(a) {
      this.i = a;
    }
    N(a) {
      this.D = a;
    }
    h(a, b, c) {
      try {
        if (this.j && this.j.h) {
          var d = this.j.start(a.toString(), 3);
          var e = b();
          this.j.end(d);
        } else e = b();
      } catch (f) {
        b = !0;
        try {
          De(d), (b = this.H(a, qe(f), void 0, c));
        } catch (g) {
          this.M(217, g);
        }
        if (b) window.console?.error?.(f);
        else throw f;
      }
      return e;
    }
    u(a, b) {
      return (...c) => this.h(a, () => b.apply(void 0, c));
    }
    M(a, b, c, d, e) {
      e = e || "jserror";
      var f = void 0;
      try {
        let sa = new Ne();
        var g = sa;
        g.h.push(1);
        g.i[1] = He("context", a);
        oe(b) || (b = qe(b));
        g = b;
        if (g.msg) {
          b = sa;
          var h = g.msg.substring(0, 512);
          b.h.push(2);
          b.i[2] = He("msg", h);
        }
        var k = g.meta || {};
        h = k;
        if (this.i)
          try {
            this.i(h);
          } catch (ea) {}
        if (d)
          try {
            d(h);
          } catch (ea) {}
        d = sa;
        k = [k];
        d.h.push(3);
        d.i[3] = k;
        var l;
        if (!(l = p)) {
          d = t;
          k = [];
          h = null;
          do {
            var m = d;
            if (ld(m)) {
              var n = m.location.href;
              h = (m.document && m.document.referrer) || null;
            } else (n = h), (h = null);
            k.push(new ue(n || "", m));
            try {
              d = m.parent;
            } catch (ea) {
              d = null;
            }
          } while (d && m !== d);
          for (let ea = 0, ah = k.length - 1; ea <= ah; ++ea)
            k[ea].depth = ah - ea;
          m = t;
          if (
            m.location &&
            m.location.ancestorOrigins &&
            m.location.ancestorOrigins.length === k.length - 1
          )
            for (n = 1; n < k.length; ++n) {
              let ea = k[n];
              ea.url ||
                ((ea.url = m.location.ancestorOrigins[n - 1] || ""),
                (ea.h = !0));
            }
          l = k;
        }
        var p = l;
        let fa = new ue(t.location.href, t, !1);
        l = null;
        let ic = p.length - 1;
        for (m = ic; m >= 0; --m) {
          var r = p[m];
          !l && se.test(r.url) && (l = r);
          if (r.url && !r.h) {
            fa = r;
            break;
          }
        }
        r = null;
        let Ee = p.length && p[ic].url;
        fa.depth !== 0 && Ee && (r = p[ic]);
        f = new te(fa, r);
        if (f.i) {
          p = sa;
          var q = f.i.url || "";
          p.h.push(4);
          p.i[4] = He("top", q);
        }
        var w = { url: f.h.url || "" };
        if (f.h.url) {
          let ea = f.h.url.match(Oe);
          var G = ea[1],
            Y = ea[3],
            Ea = ea[4];
          q = "";
          G && (q += G + ":");
          Y && ((q += "//"), (q += Y), Ea && (q += ":" + Ea));
          var Fa = q;
        } else Fa = "";
        G = sa;
        w = [w, { url: Fa }];
        G.h.push(5);
        G.i[5] = w;
        Se(this.pinger, e, sa, this.D, c);
      } catch (sa) {
        try {
          Se(
            this.pinger,
            e,
            { context: "ecmserr", rctx: a, msg: re(sa), url: f?.h.url ?? "" },
            this.D,
            c
          );
        } catch (fa) {}
      }
      return !0;
    }
    wa(a, b) {
      b.catch((c) => {
        c = c ? c : "unknown rejection";
        this.M(a, c instanceof Error ? c : Error(c), void 0, this.i || void 0);
      });
    }
  };
  var Ue = class extends O {},
    Ve = [2, 3, 4];
  var We = class extends O {},
    Xe = [3, 4, 5],
    Ye = [6, 7];
  var Ze = class extends O {},
    $e = [4, 5];
  function af(a, b) {
    var c = D(a, We, 2);
    if (!c.length) return bf(a, b);
    a = L(a, 1);
    if (a === 1)
      return (
        (c = af(c[0], b)), c.success ? { success: !0, value: !c.value } : c
      );
    c = Ha(c, (d) => af(d, b));
    switch (a) {
      case 2:
        return (
          c.find((d) => d.success && !d.value) ??
          c.find((d) => !d.success) ?? { success: !0, value: !0 }
        );
      case 3:
        return (
          c.find((d) => d.success && d.value) ??
          c.find((d) => !d.success) ?? { success: !0, value: !1 }
        );
      default:
        return { success: !1, R: 3 };
    }
  }
  function bf(a, b) {
    var c = Hc(a.B, Xe);
    a: {
      switch (c) {
        case 3:
          var d = Tc(a, 3, Xe);
          break a;
        case 4:
          d = Tc(a, 4, Xe);
          break a;
        case 5:
          d = Tc(a, 5, Xe);
          break a;
      }
      d = void 0;
    }
    if (!d) return { success: !1, R: 2 };
    b = (b = b[c]) && b[d];
    if (!b) return { success: !1, property: d, ja: c, R: 1 };
    try {
      var e = wc(a, 8, Ub);
      var f = b(...e);
    } catch (g) {
      return { success: !1, property: d, ja: c, R: 2 };
    }
    e = L(a, 1);
    if (e === 4) return { success: !0, value: !!f };
    if (e === 5) return { success: !0, value: f != null };
    if (e === 12) a = K(a, Gc(a, Ye, 7));
    else
      a: {
        switch (c) {
          case 4:
            a = Sc(a, Gc(a, Ye, 6));
            break a;
          case 5:
            a = K(a, Gc(a, Ye, 7));
            break a;
        }
        a = void 0;
      }
    if (a == null) return { success: !1, property: d, ja: c, R: 3 };
    if (e === 6) return { success: !0, value: f === a };
    if (e === 9)
      return { success: !0, value: f != null && xa(String(f), a) === 0 };
    if (f == null) return { success: !1, property: d, ja: c, R: 4 };
    switch (e) {
      case 7:
        c = f < a;
        break;
      case 8:
        c = f > a;
        break;
      case 12:
        c = x(a) && x(f) && new RegExp(a).test(f);
        break;
      case 10:
        c = f != null && xa(String(f), a) === -1;
        break;
      case 11:
        c = f != null && xa(String(f), a) === 1;
        break;
      default:
        return { success: !1, R: 3 };
    }
    return { success: !0, value: c };
  }
  function cf(a, b) {
    return a
      ? b
        ? af(a, b)
        : { success: !1, R: 1 }
      : { success: !0, value: !0 };
  }
  function df(a) {
    return wc(a, 4, Ub);
  }
  var Lc = class extends O {};
  var ef = class extends O {
    getValue() {
      return C(this, Lc, 2);
    }
    clearValue() {
      return B(this, 2);
    }
  };
  var ff = class extends O {},
    gf = hd(ff),
    hf = [1, 2, 3, 6, 7, 8];
  var jf = class extends O {};
  function kf(a, b) {
    try {
      let c = (d) => [{ [d.da]: d.ba }];
      return JSON.stringify([
        a.filter((d) => d.Z).map(c),
        z(b),
        a.filter((d) => !d.Z).map(c),
      ]);
    } catch (c) {
      return lf(c, b), "";
    }
  }
  function lf(a, b) {
    try {
      ke(
        {
          m: re(a instanceof Error ? a : Error(String(a))),
          b: L(b, 1) || null,
          v: K(b, 2) || null,
        },
        "rcs_internal"
      );
    } catch (c) {}
  }
  function mf(a) {
    if (a.C) {
      var b = a.j,
        c = Set;
      var d = wc(a.j, 3, Mb);
      c = [...new c([...d, ...a.C()])];
      Bc(b, 3, c, Lb);
    }
    return kc(a.j);
  }
  var nf = class {
    constructor(a, b, c) {
      this.C = c;
      c = new jf();
      a = cd(c, 1, a);
      this.j = ad(a, 2, b);
    }
  };
  function of(a) {
    var b = new CompressionStream("gzip"),
      c = new Response(b.readable).arrayBuffer(),
      d = b.writable.getWriter(),
      e = typeof a === "string" ? new TextEncoder().encode(a) : a;
    return d.ready
      .then(() => d.write(e))
      .then(() => d.close())
      .then(() => c)
      .then((f) => new Uint8Array(f));
  }
  var pf = class extends O {},
    qf = [1, 2, 3];
  var rf = class extends O {},
    sf = [2, 4];
  function tf(a) {
    var b = new uf();
    return ad(b, 1, a);
  }
  function vf(a, b) {
    mc(a);
    var c = a.B,
      d = b;
    b = Mc(a, c, c[v] | 0, pf, 4, 2, !0);
    d = d != null ? d : new pf();
    b.push(d);
    var e = b === cb ? 7 : b[v] | 0,
      f = e;
    (d = ib(d)) ? ((e &= -9), b.length === 1 && (e &= -4097)) : (e |= 4096);
    e !== f && (b[v] = e);
    d || nc(c);
    return a;
  }
  var uf = class extends O {};
  var wf = class extends O {
    getWidth() {
      return J(this, 3);
    }
    getHeight() {
      return J(this, 4);
    }
  };
  var xf = class extends O {};
  function yf(a, b) {
    return N(a, 1, b);
  }
  function zf(a, b) {
    return N(a, 2, b);
  }
  var Af = class extends O {
    getWidth() {
      return Qc(this, 1) ?? oc;
    }
    getHeight() {
      return Qc(this, 2) ?? oc;
    }
  };
  var Bf = class extends O {};
  var Cf = class extends O {};
  var Df = class extends O {};
  function Ef(a) {
    var b = new Ff();
    return cd(b, 1, a);
  }
  var Ff = class extends O {},
    Gf = [5, 6, 7, 8, 9, 10, 11, 12, 13, 14];
  var Hf = class extends O {};
  var If = class extends O {
    getValue() {
      return L(this, 1);
    }
    clearValue() {
      return B(this, 1);
    }
  };
  var Jf = class extends O {
    getContentUrl() {
      return K(this, 4);
    }
  };
  var Kf = class extends O {};
  var Lf = class extends O {};
  function Mf(a) {
    return Ic(a, Lf, 3);
  }
  var Nf = class extends O {};
  var Of = class extends O {
    getContentUrl() {
      return K(this, 1);
    }
  };
  var Pf = class extends O {};
  var Qf = class extends O {};
  var Rf = class extends O {},
    Sf = [
      4, 5, 6, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 21, 22, 23, 24,
    ];
  var Tf = class extends O {};
  var Uf = class extends O {
      getTagSessionCorrelator() {
        return Qc(this, 1) ?? oc;
      }
    },
    Vf = [3, 4, 6, 7, 8, 9, 10, 11, 12];
  var Wf = class extends O {};
  function Xf(a, b) {
    return cd(a, 1, b);
  }
  function Yf(a, b) {
    return cd(a, 2, b);
  }
  var Zf = class extends O {};
  var $f = class extends O {},
    ag = [1, 2];
  function bg(a, b) {
    return E(a, 1, b);
  }
  function cg(a, b) {
    return Oc(a, 2, b);
  }
  function dg(a, b) {
    return Bc(a, 4, b, Lb);
  }
  function eg(a, b) {
    return Oc(a, 5, b);
  }
  function fg(a, b) {
    return cd(a, 6, b);
  }
  var gg = class extends O {};
  var hg = class extends O {},
    ig = [1, 2, 3, 4, 6, 7];
  var jg = class extends O {};
  function kg(a) {
    var b = new lg();
    return F(b, 4, mg, a);
  }
  var lg = class extends O {
      getTagSessionCorrelator() {
        return Qc(this, 2) ?? oc;
      }
    },
    mg = [4, 5, 7, 8, 9];
  var ng = class extends O {};
  function og() {
    var a = pg();
    a = jc(a);
    return ad(a, 1, qg());
  }
  var rg = class extends O {};
  var sg = class extends O {};
  var tg = class extends O {
    getTagSessionCorrelator() {
      return Qc(this, 1) ?? oc;
    }
  };
  var ug = class extends O {},
    vg = [1, 7, 9],
    wg = [4, 6, 8];
  function xg(a, b) {
    return Yc(a, 2, b);
  }
  function yg(a, b) {
    return N(a, 3, b);
  }
  function zg(a, b) {
    Yc(a, 4, b);
  }
  function Ag(a, b) {
    return N(a, 6, b);
  }
  function Bg(a, b) {
    Yc(a, 7, b);
  }
  function Cg(a, b) {
    N(a, 10, b);
  }
  function Dg(a, b) {
    return N(a, 13, b);
  }
  function Eg(a, b) {
    N(a, 14, b);
  }
  function Fg(a) {
    var b = 0;
    for (let c of document.getElementsByTagName("iframe")) Gg(c) && b++;
    return N(a, 16, b);
  }
  function Hg(a, b) {
    N(a, 18, b);
  }
  function Ig(a) {
    var b = window.google_unique_id;
    b = mb(b) ? b : 0;
    return N(a, 19, b);
  }
  function Jg(a) {
    B(a, 20, Hb(t === t.top));
  }
  var Kg = class extends O {};
  class Lg {
    constructor(a) {
      this.pinger = a;
      this.h = new Mg(this.pinger);
    }
  }
  class Mg {
    constructor(a) {
      this.pinger = a;
      this.h = new Ng(this.pinger);
    }
  }
  class Ng {
    constructor(a) {
      this.pinger = a;
      this.Rb = new Og(this.pinger);
      this.Vb = new Pg(this.pinger);
    }
  }
  class Og {
    constructor(a) {
      this.pinger = a;
    }
    Na(a) {
      var b = Qg,
        c = this.pinger,
        d = tf("SSypSb");
      var e = new pf();
      e = Dc(e, 3, qf, Hb(a.Qa));
      d = vf(d, e);
      e = new rf();
      a = Xc(e, sf, Math.round(a.Xa));
      a = E(d, 3, a);
      b(c, a);
    }
  }
  class Pg {
    constructor(a) {
      this.pinger = a;
    }
    Na(a) {
      var b = Qg,
        c = this.pinger,
        d = tf("LCrzId");
      var e = new pf();
      e = Dc(e, 3, qf, Hb(a.Qa));
      d = vf(d, e);
      e = new pf();
      e = Xc(e, qf, a.priority);
      d = vf(d, e);
      e = new rf();
      a = Xc(e, sf, Math.round(a.Xa));
      a = E(d, 3, a);
      b(c, a);
    }
  }
  class Rg extends nf {
    constructor() {
      super(...arguments);
      this.J = new Lg(this);
    }
  }
  function Qg(a, ...b) {
    Sg(a, ...b.map((c) => ({ Z: !1, da: 1, ba: z(c) })));
  }
  function Tg(a, ...b) {
    Sg(a, ...b.map((c) => ({ Z: !0, da: 3, ba: z(c) })));
  }
  function Ug(a, ...b) {
    Sg(a, ...b.map((c) => ({ Z: !0, da: 4, ba: z(c) })));
  }
  function Vg(a, ...b) {
    Sg(a, ...b.map((c) => ({ Z: !0, da: 7, ba: z(c) })));
  }
  function Wg(a, ...b) {
    Sg(a, ...b.map((c) => ({ Z: !0, da: 28, ba: z(c) })));
  }
  function Xg(a, ...b) {
    Sg(a, ...b.map((c) => ({ Z: !0, da: 39, ba: z(c) })));
  }
  var Yg = class extends Rg {};
  function Zg(a, b) {
    globalThis
      .fetch(a, {
        method: "POST",
        body: b,
        keepalive: b.length < 65536,
        credentials: "omit",
        mode: "no-cors",
        redirect: "follow",
      })
      .catch(() => {});
  }
  function $g(a, b, c = 1, d = !1) {
    if (d) {
      d = typeof CompressionStream === "function";
      var e = b.length > 1024;
      typeof document !== "undefined" &&
      document.visibilityState !== "hidden" &&
      d &&
      e
        ? of(b)
            .then((f) => {
              var g = c === 1 ? 5 : 6,
                h;
              h === void 0 && (h = 0);
              Ra();
              h = Na[h];
              for (
                var k = Array(Math.floor(f.length / 3)),
                  l = h[64] || "",
                  m = 0,
                  n = 0;
                m < f.length - 2;
                m += 3
              ) {
                var p = f[m],
                  r = f[m + 1],
                  q = f[m + 2],
                  w = h[p >> 2];
                p = h[((p & 3) << 4) | (r >> 4)];
                r = h[((r & 15) << 2) | (q >> 6)];
                q = h[q & 63];
                k[n++] = w + p + r + q;
              }
              w = 0;
              q = l;
              switch (f.length - m) {
                case 2:
                  (w = f[m + 1]), (q = h[(w & 15) << 2] || l);
                case 1:
                  (f = f[m]),
                    (k[n] = h[f >> 2] + h[((f & 3) << 4) | (w >> 4)] + q + l);
              }
              Zg(`${a}?e=${g}`, k.join(""));
            })
            .catch(() => {
              Zg(`${a}?e=${c}`, b);
            })
        : Zg(`${a}?e=${c}`, b);
    } else Zg(`${a}?e=${c}`, b);
  }
  function Sg(a, ...b) {
    try {
      a.N && kf(a.h.concat(b), mf(a)).length >= 65536 && bh(a),
        a.u &&
          !a.D &&
          ((a.D = !0),
          ch(a.u, () => {
            bh(a);
          })),
        a.h.push(...b),
        a.h.length >= a.H && bh(a),
        a.h.length &&
          a.i === null &&
          (a.i = setTimeout(() => {
            bh(a);
          }, a.Y));
    } catch (c) {
      lf(c, mf(a));
    }
  }
  function bh(a) {
    a.i !== null && (clearTimeout(a.i), (a.i = null));
    if (a.h.length) {
      var b = kf(a.h, mf(a));
      a.W("https://pagead2.googlesyndication.com/pagead/ping", b, 1, !1);
      a.h = [];
    }
  }
  var dh = class extends Yg {
      constructor(a, b, c, d, e, f, g) {
        super(a, b, g);
        this.W = $g;
        this.Y = c;
        this.H = d;
        this.N = e;
        this.u = f;
        this.h = [];
        this.i = null;
        this.D = !1;
      }
    },
    eh = class extends dh {
      constructor(a, b, c = 1e3, d = 100, e = !1, f, g) {
        super(a, b, c, d, e && !0, f, g);
      }
    };
  function fh(a, b) {
    var c = Date.now();
    c = Number.isFinite(c) ? Math.round(c) : 0;
    b = Wc(b, 1, c);
    c = Wd(window);
    b = Wc(b, 2, c);
    return Wc(b, 6, a.Va);
  }
  function gh(a, b, c, d, e, f) {
    if (a.i) {
      var g = Yf(Xf(new Zf(), b), c);
      b = fg(cg(bg(eg(dg(new gg(), d), e), g), a.h.slice()), f);
      b = kg(b);
      Ug(a.pinger, fh(a, b));
      if (
        f === 1 ||
        f === 3 ||
        (f === 4 && !a.h.some((h) => L(h, 1) === L(g, 1) && L(h, 2) === c))
      )
        a.h.push(g), a.h.length > 100 && a.h.shift();
    }
  }
  function hh(a, b, c, d) {
    if (a.i) {
      var e = new Wf();
      b = Vc(e, 1, b);
      c = Vc(b, 2, c);
      d = bd(c, 3, d);
      c = new lg();
      d = F(c, 8, mg, d);
      Ug(a.pinger, fh(a, d));
    }
  }
  function ih(a, b, c, d, e) {
    if (a.i) {
      var f = new Ze();
      b = E(f, 1, b);
      c = bd(b, 2, c);
      d = Vc(c, 3, d);
      if (e.ja === void 0) dd(d, 4, $e, e.R);
      else
        switch (e.ja) {
          case 3:
            c = new Ue();
            c = dd(c, 2, Ve, e.property);
            e = bd(c, 1, e.R);
            F(d, 5, $e, e);
            break;
          case 4:
            c = new Ue();
            c = dd(c, 3, Ve, e.property);
            e = bd(c, 1, e.R);
            F(d, 5, $e, e);
            break;
          case 5:
            (c = new Ue()),
              (c = dd(c, 4, Ve, e.property)),
              (e = bd(c, 1, e.R)),
              F(d, 5, $e, e);
        }
      e = new lg();
      e = F(e, 9, mg, d);
      Ug(a.pinger, fh(a, e));
    }
  }
  var jh = class {
    constructor(a, b, c, d = new eh(6, "unknown", b)) {
      this.Va = a;
      this.j = c;
      this.pinger = d;
      this.h = [];
      this.i = a > 0 && Dd() < 1 / a;
    }
  };
  var P = (a) => {
    var b = "Pa";
    if (a.Pa && a.hasOwnProperty(b)) return a.Pa;
    b = new a();
    return (a.Pa = b);
  };
  var kh = class {
    constructor() {
      this.P = { [3]: {}, [4]: {}, [5]: {} };
    }
  };
  var lh = /^true$/.test("false");
  function mh(a, b) {
    switch (b) {
      case 1:
        return Tc(a, 1, hf);
      case 7:
        return Tc(a, 7, hf);
      case 2:
        return Tc(a, 2, hf);
      case 3:
        return Tc(a, 3, hf);
      case 6:
        return Tc(a, 6, hf);
      case 8:
        return Tc(a, 8, hf);
      default:
        return null;
    }
  }
  function nh(a, b) {
    if (!a) return null;
    switch (b) {
      case 1:
        return I(a, 1);
      case 7:
        return K(a, 3);
      case 2:
        return Sc(a, 2);
      case 3:
        return K(a, 3);
      case 6:
        return df(a);
      case 8:
        return df(a);
      default:
        return null;
    }
  }
  const oh = od(() => {
    if (!lh) return {};
    try {
      var a = window;
      try {
        var b = a.sessionStorage.getItem("GGDFSSK");
      } catch {
        b = null;
      }
      if (b) return JSON.parse(b);
    } catch {}
    return {};
  });
  function ph(a, b, c, d = 0) {
    P(qh).j[d] = P(qh).j[d]?.add(b) ?? new Set().add(b);
    var e = oh();
    if (e[b] != null) return e[b];
    b = rh(d)[b];
    if (!b) return c;
    b = gf(JSON.stringify(b));
    b = sh(b);
    a = nh(b, a);
    return a != null ? a : c;
  }
  function sh(a) {
    var b = P(kh).P;
    if (b && Hc(a.B, hf) !== 8) {
      let c = Ja(D(a, ef, 5), (d) => {
        d = cf(C(d, We, 1), b);
        return d.success && d.value;
      });
      if (c) return c.getValue() ?? null;
    }
    return C(a, Lc, 4) ?? null;
  }
  class qh {
    constructor() {
      this.i = {};
      this.u = [];
      this.j = {};
      this.h = new Map();
    }
  }
  function th(a, b = !1, c) {
    return !!ph(1, a, b, c);
  }
  function uh(a, b = "", c) {
    a = ph(7, a, b, c);
    if (x(a))
      try {
        return JSON.parse(a);
      } catch {}
    try {
      return JSON.parse(b);
    } catch {
      return null;
    }
  }
  function vh(a, b = 0, c) {
    a = Number(ph(2, a, b, c));
    return isNaN(a) ? b : a;
  }
  function wh(a, b = "", c) {
    a = ph(3, a, b, c);
    return x(a) ? a : b;
  }
  function xh(a, b = [], c) {
    a = ph(6, a, b, c);
    return Array.isArray(a) ? a : b;
  }
  function yh(a, b = [], c) {
    a = ph(8, a, b, c);
    return Array.isArray(a) ? a : b;
  }
  function rh(a) {
    return P(qh).i[a] || (P(qh).i[a] = {});
  }
  function zh(a, b) {
    var c = rh(b);
    kd(a, (d, e) => {
      if (c[e]) {
        var f = (d = gf(JSON.stringify(d))),
          g = Gc(d, hf, 8);
        y(A(f, g)) != null &&
          ((g = gf(JSON.stringify(c[e]))),
          (f = Ic(d, Lc, 4)),
          (g = df(Kc(g))),
          Pc(f, g));
        c[e] = z(d);
      } else c[e] = d;
    });
  }
  function Ah(a, b, c, d, e = !1) {
    var f = [],
      g = [];
    for (let n of b) {
      b = rh(n);
      for (let p of a) {
        var h = Hc(p.B, hf);
        let r = mh(p, h);
        if (!r) continue;
        a: {
          var k = r;
          var l = h,
            m = P(qh).h.get(n)?.get(r)?.slice(0) ?? [];
          let q = new hg();
          switch (l) {
            case 1:
              dd(q, 1, ig, k);
              break;
            case 2:
              dd(q, 2, ig, k);
              break;
            case 3:
              dd(q, 3, ig, k);
              break;
            case 6:
              dd(q, 4, ig, k);
              break;
            case 7:
              dd(q, 7, ig, k);
              break;
            case 8:
              dd(q, 6, ig, k);
              break;
            default:
              k = void 0;
              break a;
          }
          Bc(q, 5, m, Lb);
          k = q;
        }
        k && P(qh).j[n]?.has(r) && f.push(k);
        h === 8 && b[r]
          ? ((k = gf(JSON.stringify(b[r]))),
            (h = Ic(p, Lc, 4)),
            (k = df(Kc(k))),
            Pc(h, k))
          : k && P(qh).h.get(n)?.has(r) && g.push(k);
        e ||
          ((h = r),
          (k = n),
          (l = d),
          (m = P(qh)),
          m.h.has(k) || m.h.set(k, new Map()),
          m.h.get(k).has(h) || m.h.get(k).set(h, []),
          l && m.h.get(k).get(h).push(l));
        b[r] = z(p);
      }
    }
    if (f.length || g.length)
      (a = d ?? void 0),
        c.i &&
          c.j &&
          ((d = new jg()),
          (f = Oc(d, 2, f)),
          (g = Oc(f, 3, g)),
          a && M(g, 1, a),
          (f = new lg()),
          (g = F(f, 7, mg, g)),
          Ug(c.pinger, fh(c, g)));
  }
  function Bh(a, b) {
    b = rh(b);
    for (let c of a) {
      a = gf(JSON.stringify(c));
      let d = Hc(a.B, hf);
      (a = mh(a, d)) && (b[a] || (b[a] = c));
    }
  }
  function Ch() {
    return Object.keys(P(qh).i).map((a) => Number(a));
  }
  function Dh(a) {
    P(qh).u.includes(a) || zh(rh(4), a);
  }
  function R(a, b, c) {
    c.hasOwnProperty(a) || Object.defineProperty(c, String(a), { value: b });
  }
  function Eh(a, b, c) {
    return b[a] || c;
  }
  function Fh(a) {
    R(5, th, a);
    R(18, uh, a);
    R(6, vh, a);
    R(7, wh, a);
    R(8, xh, a);
    R(17, yh, a);
    R(13, Bh, a);
    R(15, Dh, a);
  }
  function Gh(a) {
    R(
      4,
      (b) => {
        P(kh).P = b;
      },
      a
    );
    R(
      9,
      (b, c) => {
        var d = P(kh);
        d.P[3][b] == null && (d.P[3][b] = c);
      },
      a
    );
    R(
      10,
      (b, c) => {
        var d = P(kh);
        d.P[4][b] == null && (d.P[4][b] = c);
      },
      a
    );
    R(
      11,
      (b, c) => {
        var d = P(kh);
        d.P[5][b] == null && (d.P[5][b] = c);
      },
      a
    );
    R(
      14,
      (b) => {
        var c = P(kh);
        for (let d of [3, 4, 5]) Object.assign(c.P[d], b[d]);
      },
      a
    );
  }
  function Hh(a) {
    a.hasOwnProperty("init-done") ||
      Object.defineProperty(a, "init-done", { value: !0 });
  }
  function Ih(a, b, c) {
    a.i = Eh(1, b, () => {});
    a.j = (d, e) => Eh(2, b, () => [])(d, c, e);
    a.u = (d) => Eh(3, b, () => [])(d ?? c);
    a.h = (d) => {
      Eh(16, b, () => {})(d, c);
    };
  }
  class Jh {
    i() {}
    h() {}
    j() {
      return [];
    }
    u() {
      return [];
    }
  }
  function Kh(a) {
    return P(Jh).u(a);
  }
  function Se(a, b, c, d = !1, e) {
    if ((d ? a.h : Math.random()) < (e || 0.01))
      try {
        let f;
        c instanceof Ne
          ? (f = c)
          : ((f = new Ne()),
            kd(c, (h, k) => {
              var l = f,
                m = l.u++;
              h = He(k, h);
              l.h.push(m);
              l.i[m] = h;
            }));
        let g = Me(f, a.protocol, a.domain, a.path + b + "&");
        g && ie(t, g);
      } catch (f) {}
  }
  function Lh(a, b) {
    b >= 0 && b <= 1 && (a.h = b);
  }
  var Mh = class {
    constructor() {
      this.domain = "pagead2.googlesyndication.com";
      this.path = "/pagead/gen_204?id=";
      this.protocol = "https:";
      this.h = Math.random();
    }
  };
  let Re, Nh;
  const Oh = new Ge(window);
  (function (a) {
    Re = a ?? new Mh();
    typeof window.google_srt !== "number" &&
      (window.google_srt = Math.random());
    Lh(Re, window.google_srt);
    Nh = new Te(Oh);
    Nh.C(() => {});
    Nh.N(!0);
    window.document.readyState === "complete"
      ? window.google_measure_js_timing || Fe(Oh)
      : Oh.h &&
        ee(window, "load", () => {
          window.google_measure_js_timing || Fe(Oh);
        });
  })();
  function Ph(a = t) {
    var b = a.context || a.AMP_CONTEXT_DATA;
    if (!b)
      try {
        b = a.parent.context || a.parent.AMP_CONTEXT_DATA;
      } catch {}
    return b?.pageViewId && b?.canonicalUrl ? b : null;
  }
  function Qh(a = Ph()) {
    return a ? (ld(a.master) ? a.master : null) : null;
  }
  var Rh = (a) => {
      a = Qh(Ph(a)) || a;
      a.google_unique_id = (a.google_unique_id || 0) + 1;
      return a.google_unique_id;
    },
    Sh = (a) => {
      if (!a) return "";
      a = a.toLowerCase();
      a.substring(0, 3) != "ca-" && (a = "ca-" + a);
      return a;
    };
  let Th = new Date().getTime();
  var Uh = {
    yc: 0,
    xc: 1,
    uc: 2,
    oc: 3,
    vc: 4,
    qc: 5,
    wc: 6,
    sc: 7,
    tc: 8,
    nc: 9,
    rc: 10,
    zc: 11,
  };
  var Vh = { Bc: 0, Cc: 1, Ac: 2 };
  function Wh(a) {
    if (a.h != 0) throw Error("Already resolved/rejected.");
  }
  var Zh = class {
    constructor() {
      this.i = new Xh(this);
      this.h = 0;
    }
    resolve(a) {
      Wh(this);
      this.h = 1;
      this.u = a;
      Yh(this.i);
    }
    reject(a) {
      Wh(this);
      this.h = 2;
      this.j = a;
      Yh(this.i);
    }
  };
  function Yh(a) {
    switch (a.h.h) {
      case 0:
        break;
      case 1:
        a.i && a.i(a.h.u);
        break;
      case 2:
        a.j && a.j(a.h.j);
        break;
      default:
        throw Error("Unhandled deferred state.");
    }
  }
  var Xh = class {
    constructor(a) {
      this.h = a;
    }
    then(a, b) {
      if (this.i) throw Error("Then functions already set.");
      this.i = a;
      this.j = b;
      Yh(this);
    }
  };
  function $h(a) {
    return new ai({ value: a }, null);
  }
  function bi(a) {
    return new ai(null, a);
  }
  function ci(a) {
    try {
      return $h(a());
    } catch (b) {
      return b instanceof Error ? bi(b) : bi(Error(String(b)));
    }
  }
  function di(a) {
    return a.h != null ? a.getValue() : null;
  }
  function ei(a, b) {
    a.h != null && b(a.getValue());
    return a;
  }
  function fi(a, b) {
    a.h != null || b(a.error);
    return a;
  }
  var ai = class {
    constructor(a, b) {
      this.h = a;
      this.error = b;
    }
    getValue() {
      return this.h.value;
    }
    map(a) {
      return this.h != null
        ? ((a = a(this.getValue())), a instanceof ai ? a : $h(a))
        : this;
    }
  };
  var gi = class {
    constructor(a) {
      this.elements = a.slice(0);
    }
    forEach(a) {
      this.elements.forEach((b, c) => void a(b, c, this));
    }
    filter(a) {
      return new gi(Ga(this.elements, a));
    }
    apply(a) {
      return new gi(a(this.elements.slice(0)));
    }
    sort(a) {
      return new gi(this.elements.slice(0).sort(a));
    }
    get(a) {
      return this.elements[a];
    }
    add(a) {
      var b = this.elements.slice(0);
      b.push(a);
      return new gi(b);
    }
    count() {
      return this.elements.length;
    }
  };
  var hi = class {
    constructor({ Ga: a, Fa: b, Oa: c, ya: d }) {
      this.slotType = 0;
      this.Fa = b;
      this.Ga = new gi(a || []);
      this.ya = d;
      this.Oa = c;
    }
  };
  var ji = class {
    constructor() {
      this.map = {};
      this.h = {};
    }
    set(a, b) {
      var c = ii(a);
      this.map[c] = b;
      this.h[c] = a;
    }
    get(a, b) {
      a = ii(a);
      return this.map[a] !== void 0 ? this.map[a] : b;
    }
    clear() {
      this.map = {};
      this.h = {};
    }
  };
  function ii(a) {
    return a instanceof Object ? String(na(a)) : `${a}`;
  }
  function ki(a) {
    var b = a.length;
    if (b === 0) return 0;
    var c = 305419896;
    for (let d = 0; d < b; d++)
      c ^= ((c << 5) + (c >> 2) + a.charCodeAt(d)) & 4294967295;
    return c > 0 ? c : 4294967296 + c;
  }
  function li(a) {
    var b = [],
      c = a.Ga;
    c && c.count() && b.push({ aa: "a", ha: String(mi(c)) });
    a.Fa != null && b.push({ aa: "as", ha: a.Fa });
    a.Oa != null && b.push({ aa: "i", ha: String(a.Oa) });
    a.ya != null && b.push({ aa: "rp", ha: String(a.ya) });
    b.sort((d, e) => d.aa.localeCompare(e.aa));
    b.unshift({ aa: "t", ha: ni(a.slotType) });
    return b;
  }
  function ni(a) {
    switch (a) {
      case 0:
        return "aa";
      case 1:
        return "ma";
      default:
        throw Error(`Invalid slot type${a}`);
    }
  }
  function mi(a) {
    a = a.elements.slice(0).map(oi);
    a = JSON.stringify(a);
    return ki(a);
  }
  function oi(a) {
    var b = {};
    H(a, 7) != null && (b.q = H(a, 7));
    Mb(A(a, 2)) != null && (b.o = Mb(A(a, 2)));
    Mb(A(a, 5)) != null && (b.p = Mb(A(a, 5)));
    return b;
  }
  function pi(a) {
    return Uc(a, 2);
  }
  var qi = class extends O {
    setLocation(a) {
      return bd(this, 1, a);
    }
  };
  function ri(...a) {
    a = a.filter((d) => d !== null);
    if (!a.length) return null;
    var b = [],
      c = {};
    for (let d of a) (b = b.concat(d.h || [])), (c = Object.assign(c, d.ca));
    return new si(b, c);
  }
  function ti(a) {
    switch (a) {
      case 1:
        return new si(null, { google_ad_semantic_area: "mc" });
      case 2:
        return new si(null, { google_ad_semantic_area: "h" });
      case 3:
        return new si(null, { google_ad_semantic_area: "f" });
      case 4:
        return new si(null, { google_ad_semantic_area: "s" });
      default:
        return null;
    }
  }
  function ui(a) {
    if (a == null) var b = null;
    else {
      b = si;
      var c = li(a);
      a = [];
      for (let d of c)
        (c = String(d.ha)),
          a.push(d.aa + "." + (c.length <= 20 ? c : c.slice(0, 19) + "_"));
      b = new b(null, { google_placement_id: a.join("~") });
    }
    return b;
  }
  var si = class {
    constructor(a, b) {
      this.h = a;
      this.ca = b;
    }
  };
  var vi = new si(["google-auto-placed"], {
    google_reactive_ad_format: 40,
    google_tag_origin: "qs",
  });
  var wi = hd(class extends O {});
  var xi = class extends O {
    getId() {
      return H(this, 3, void 0, pc);
    }
  };
  var yi = class extends O {
    h() {
      return C(this, xi, 1);
    }
  };
  var zi = class extends O {};
  var Ai = class extends O {};
  function Bi(a, b) {
    var c = [],
      d = a.length;
    for (let e = 0; e < d; e++) c.push(a[e]);
    c.forEach(b, void 0);
  }
  function Ci(a) {
    var b = [];
    Bi(a.getElementsByTagName("p"), (c) => {
      Di(c) >= 100 && b.push(c);
    });
    return b;
  }
  function Di(a) {
    if (a.nodeType === 3) return a.length;
    if (a.nodeType !== 1 || a.tagName === "SCRIPT") return 0;
    var b = 0;
    Bi(a.childNodes, (c) => {
      b += Di(c);
    });
    return b;
  }
  function Ei(a) {
    return /^[0-9]/.test(a) ? `\\${30 + Number(a[0])} ${a.substring(1)}` : a;
  }
  function Fi(a, b) {
    if (a.h == null) return b;
    switch (a.h) {
      case 1:
        return b.slice(1);
      case 2:
        return b.slice(0, b.length - 1);
      case 3:
        return b.slice(1, b.length - 1);
      case 0:
        return b;
      default:
        throw Error(`Unknown ignore mode: ${String(a.h)}`);
    }
  }
  function Gi(a, b) {
    var c = [];
    try {
      c = b.querySelectorAll(a.u);
    } catch (d) {}
    if (!c.length) return [];
    b = La(c);
    b = Fi(a, b);
    typeof a.i === "number" &&
      ((c = a.i),
      c < 0 && (c += b.length),
      (b = c >= 0 && c < b.length ? [b[c]] : []));
    if (typeof a.j === "number") {
      c = [];
      for (let d = 0; d < b.length; d++) {
        let e = Ci(b[d]),
          f = a.j;
        f < 0 && (f += e.length);
        f >= 0 && f < e.length && c.push(e[f]);
      }
      b = c;
    }
    return b;
  }
  var Hi = class {
    constructor(a, b, c, d) {
      this.u = a;
      this.i = b;
      this.j = c;
      this.h = d;
    }
    toString() {
      return JSON.stringify({
        nativeQuery: this.u,
        occurrenceIndex: this.i,
        paragraphIndex: this.j,
        ignoreMode: this.h,
      });
    }
  };
  function Ii(a) {
    if (a.nodeType !== 1) var b = !1;
    else if ((b = a.tagName === "INS"))
      a: {
        b = ["adsbygoogle-placeholder"];
        var c = a.className ? a.className.split(/\s+/) : [];
        a = {};
        for (let d = 0; d < c.length; ++d) a[c[d]] = !0;
        for (c = 0; c < b.length; ++c)
          if (!a[b[c]]) {
            b = !1;
            break a;
          }
        b = !0;
      }
    return b;
  }
  function Ji(a, b, c) {
    switch (c) {
      case 0:
        b.parentNode && b.parentNode.insertBefore(a, b);
        break;
      case 3:
        if ((c = b.parentNode)) {
          let d = b.nextSibling;
          if (d && d.parentNode !== c)
            for (; d && d.nodeType === 8; ) d = d.nextSibling;
          c.insertBefore(a, d);
        }
        break;
      case 1:
        b.insertBefore(a, b.firstChild);
        break;
      case 2:
        b.appendChild(a);
    }
    Ii(b) &&
      (b.setAttribute("data-init-display", b.style.display),
      (b.style.display = "block"));
  }
  var Ki = class {
    constructor() {
      this.i = Id`https://pagead2.googlesyndication.com/pagead/js/err_rep.js`;
    }
    M(a, b, c = 0.01, d = "jserror") {
      if (Math.random() > c) return !1;
      oe(b) || (b = new pe(b, { context: a, id: d }));
      t.google_js_errors = t.google_js_errors || [];
      t.google_js_errors.push(b);
      t.error_rep_loaded || (Ld(t.document, this.i), (t.error_rep_loaded = !0));
      return !1;
    }
    h(a, b) {
      try {
        return b();
      } catch (c) {
        if (!this.M(a, c, 0.01, "jserror")) throw c;
      }
    }
    u(a, b) {
      return (...c) => this.h(a, () => b.apply(void 0, c));
    }
    wa(a, b) {
      b.catch((c) => {
        c = c ? c : "unknown rejection";
        this.M(a, c instanceof Error ? c : Error(c), void 0);
      });
    }
  };
  function Li(a, b) {
    b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
    b.length < 2048 && b.push(a);
  }
  function Mi(a, b, c, d, e = !1) {
    var f = d || window,
      g = typeof queueMicrotask !== "undefined";
    return function (...h) {
      e &&
        g &&
        queueMicrotask(() => {
          f.google_rum_task_id_counter = f.google_rum_task_id_counter || 1;
          f.google_rum_task_id_counter += 1;
        });
      var k = ye(),
        l = 3;
      try {
        var m = b.apply(this, h);
      } catch (n) {
        l = 13;
        if (!c) throw n;
        c(a, n);
      } finally {
        f.google_measure_js_timing &&
          k &&
          Li(
            {
              label: a.toString(),
              value: k,
              duration: (ye() || 0) - k,
              type: l,
              ...(e &&
                g && {
                  taskId: (f.google_rum_task_id_counter =
                    f.google_rum_task_id_counter || 1),
                }),
            },
            f
          );
      }
      return m;
    };
  }
  function Ni(a, b) {
    return Mi(
      a,
      b,
      (c, d) => {
        new Ki().M(c, d);
      },
      void 0,
      !1
    );
  }
  function Oi(a, b, c) {
    return Mi(a, b, void 0, c, !0)();
  }
  function Pi(a) {
    if (!a) return null;
    var b = H(a, 7);
    if (H(a, 1) || H(a, 3) || wc(a, 4, Ub).length > 0) {
      var c = H(a, 3),
        d = H(a, 1),
        e = wc(a, 4, Ub);
      b = Mb(A(a, 2));
      var f = Mb(A(a, 5));
      a = Qi(y(A(a, 6)));
      let g = "";
      d && (g += d);
      c && (g += "#" + Ei(c));
      if (e) for (c = 0; c < e.length; c++) g += "." + Ei(e[c]);
      b = (e = g) ? new Hi(e, b, f, a) : null;
    } else b = b ? new Hi(b, Mb(A(a, 2)), Mb(A(a, 5)), Qi(y(A(a, 6)))) : null;
    return b;
  }
  const Ri = { [0]: 0, [1]: 1, [2]: 2, [3]: 3 };
  function Qi(a) {
    if (a != null) return Ri[a];
  }
  const Si = { [1]: 0, [2]: 1, [3]: 2, [4]: 3 };
  function Ti(a) {
    return a.google_ama_state ?? (a.google_ama_state = {});
  }
  function Ui(a) {
    var b;
    return (b = Ti(a)).optimization ?? (b.optimization = {});
  }
  var S = class {
      constructor(a, b = !1) {
        this.h = a;
        this.defaultValue = b;
      }
    },
    T = class {
      constructor(a, b = 0) {
        this.h = a;
        this.defaultValue = b;
      }
    },
    Vi = class {
      constructor(a, b = []) {
        this.h = a;
        this.defaultValue = b;
      }
    };
  var Wi = new T(619278254, 10),
    Xi = new T(1359),
    Yi = new T(1358),
    Zi = new S(1360),
    $i = new T(1357),
    aj = new S(1345),
    bj = new T(1130, 100),
    cj = new T(1340, 0.2),
    dj = new T(1338, 0.3),
    ej = new T(1339, 0.3),
    fj = new (class {
      constructor(a, b = "") {
        this.h = a;
        this.defaultValue = b;
      }
    })(14),
    gj = new T(1405),
    hj = new T(1346, 6),
    ij = new T(1347, 3),
    jj = new S(1344),
    kj = new S(1399),
    lj = new T(1400),
    mj = new S(316),
    nj = new S(313),
    oj = new S(369),
    pj = new S(45751075),
    qj = new S(970587529, !0),
    rj = new S(976718821),
    sj = new T(1404),
    tj = new T(1403),
    uj = new S(1002473706),
    vj = new T(971334269, 1e3),
    wj = new S(1009993905),
    xj = new Vi(
      45736067,
      "ca-pub-7178919035426667 ca-pub-6430486603399192 ca-pub-6217516951440692 ca-pub-3269777183832488 ca-pub-4286071012672876 ca-pub-6893876361346206 ca-pub-6865079278713445 ca-pub-6062692039613877 ca-pub-8700401253704627 ca-pub-7409460644561046 ca-pub-1807333429605702 ca-pub-4414232724432396 ca-pub-8878716159434368 ca-pub-1725310704471587 ca-pub-7286478979881995 ca-pub-5420212072167331 ca-pub-3001544606526418 ca-pub-7647808421428026 ca-pub-6109939056400055 ca-pub-6907038225839490 ca-pub-6462695325264077 ca-pub-9260533539525355 ca-pub-9284205722386242 ca-pub-0636857377230346 ca-pub-9067164180551135 ca-pub-9649286969563355 ca-pub-6150993149788596 ca-pub-0085763304086106".split(
        " "
      )
    ),
    yj = new (class {
      constructor(a, b = []) {
        this.h = a;
        this.defaultValue = b;
      }
    })(683929765, ["14"]),
    zj = new S(506914611),
    Aj = new S(1008729579),
    Bj = new T(9603, 4),
    Cj = new S(992543390),
    Dj = new S(711741274),
    Ej = new S(662101537),
    Fj = new S(834350237),
    Gj = new T(1079, 5),
    Vd = new Vi(1934, [
      "AlK2UR5SkAlj8jjdEc9p3F3xuFYlF6LYjAML3EOqw1g26eCwWPjdmecULvBH5MVPoqKYrOfPhYVL71xAXI1IBQoAAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==",
      "Amm8/NmvvQfhwCib6I7ZsmUxiSCfOxWxHayJwyU1r3gRIItzr7bNQid6O8ZYaE1GSQTa69WwhPC9flq/oYkRBwsAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==",
      "A9nrunKdU5m96PSN1XsSGr3qOP0lvPFUB2AiAylCDlN5DTl17uDFkpQuHj1AFtgWLxpLaiBZuhrtb2WOu7ofHwEAAACKeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9",
      "A93bovR+QVXNx2/38qDbmeYYf1wdte9EO37K9eMq3r+541qo0byhYU899BhPB7Cv9QqD7wIbR1B6OAc9kEfYCA4AAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9",
      "A1S5fojrAunSDrFbD8OfGmFHdRFZymSM/1ss3G+NEttCLfHkXvlcF6LGLH8Mo5PakLO1sCASXU1/gQf6XGuTBgwAAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9",
    ]),
    Hj = new S(84);
  var Ud = class {
    constructor() {
      var a = {};
      this.j = (b, c) => (a[b] != null ? a[b] : c);
      this.H = (b, c) => {
        var d = a[b];
        if (typeof d === "string" && b != null)
          try {
            return JSON.parse(d);
          } catch {}
        try {
          return JSON.parse(c);
        } catch {
          return null;
        }
      };
      this.C = (b, c) => (a[b] != null ? a[b] : c);
      this.h = (b, c) => (a[b] != null ? a[b] : c);
      this.i = (b, c) => (a[b] != null ? a[b] : c);
      this.u = (b, c) => (a[b] != null ? c.concat(a[b]) : c);
      this.D = () => {};
    }
  };
  function U(a) {
    return P(Ud).j(a.h, a.defaultValue);
  }
  function V(a) {
    return P(Ud).C(a.h, a.defaultValue);
  }
  function Ij(a, b) {
    var c = (e) => {
        e = Jj(e);
        return e == null ? !1 : 0 < e;
      },
      d = (e) => {
        e = Jj(e);
        return e == null ? !1 : 0 > e;
      };
    switch (b) {
      case 0:
        return {
          init: Kj(a.previousSibling, c),
          oa: (e) => Kj(e.previousSibling, c),
          va: 0,
        };
      case 2:
        return {
          init: Kj(a.lastChild, c),
          oa: (e) => Kj(e.previousSibling, c),
          va: 0,
        };
      case 3:
        return {
          init: Kj(a.nextSibling, d),
          oa: (e) => Kj(e.nextSibling, d),
          va: 3,
        };
      case 1:
        return {
          init: Kj(a.firstChild, d),
          oa: (e) => Kj(e.nextSibling, d),
          va: 3,
        };
      default:
        throw Error("Un-handled RelativePosition: " + b);
    }
  }
  function Jj(a) {
    return a.hasOwnProperty("google-ama-order-assurance")
      ? a["google-ama-order-assurance"]
      : null;
  }
  function Kj(a, b) {
    return a && b(a) ? a : null;
  }
  var Lj = {
    overlays: 1,
    interstitials: 2,
    vignettes: 2,
    inserts: 3,
    in_page_banner: 8,
    immersives: 4,
    list_view: 5,
    full_page: 6,
    side_rails: 7,
    rewarded: 9,
  };
  function Mj(a) {
    a = a.document;
    var b = {};
    a && (b = a.compatMode == "CSS1Compat" ? a.documentElement : a.body);
    return b || {};
  }
  function Nj(a) {
    return Mj(a).clientWidth ?? void 0;
  }
  function Oj(a, b) {
    do {
      let c = Nd(a, b);
      if (c && c.position === "fixed") return !1;
    } while ((a = a.parentElement));
    return !0;
  }
  function Pj(a, b, c) {
    var d;
    return (
      (a.style && !!a.style[c] && Rd(a.style[c])) ||
      ((d = Nd(a, b)) && !!d[c] && Rd(d[c])) ||
      null
    );
  }
  function Qj(a, b) {
    try {
      let c = b.document.documentElement.getBoundingClientRect(),
        d = a.getBoundingClientRect();
      return { x: d.left - c.left, y: d.top - c.top };
    } catch (c) {
      return null;
    }
  }
  function Rj(a, b) {
    return (a = Qj(a, b)) ? a.y : 0;
  }
  function Sj(a, b) {
    var c = Pj(b, a, "height");
    if (c) return c;
    var d = b.style.height;
    b.style.height = "inherit";
    c = Pj(b, a, "height");
    b.style.height = d;
    if (c) return c;
    c = Infinity;
    do
      (d = b.style && Rd(b.style.height)) && (c = Math.min(c, d)),
        (d = Pj(b, a, "maxHeight")) && (c = Math.min(c, d));
    while (b.parentElement && (b = b.parentElement) && b.tagName !== "HTML");
    return c;
  }
  function Tj(a, b) {
    var c;
    return (a.style && a.style.zIndex) || ((c = Nd(a, b)) && c.zIndex) || null;
  }
  var Uj = {
    google_ad_channel: !0,
    google_ad_client: !0,
    google_ad_host: !0,
    google_ad_host_channel: !0,
    google_adtest: !0,
    google_tag_for_child_directed_treatment: !0,
    google_tag_for_age_treatment: !0,
    google_tag_for_under_age_of_consent: !0,
    google_tag_partner: !0,
    google_restrict_data_processing: !0,
    google_page_url: !0,
    google_debug_params: !0,
    google_adbreak_test: !0,
    google_ad_frequency_hint: !0,
    google_admob_interstitial_slot: !0,
    google_admob_rewarded_slot: !0,
    google_admob_ads_only: !0,
    google_ad_start_delay_hint: !0,
    google_max_ad_content_rating: !0,
    google_traffic_source: !0,
    google_overlays: !0,
    google_privacy_treatments: !0,
    google_special_category_data: !0,
    google_ad_intent_query: !0,
    google_ad_intent_rs_token: !0,
    google_ad_intents_format: !0,
    google_ad_intents_in_drawer_format: !0,
    google_ad_intents_encoded_verticals4_ids: !0,
    google_ad_intents_encoded_browseonomy_ids: !0,
    google_ad_intents_ad_position: !0,
  };
  const Vj = RegExp("(^| )adsbygoogle($| )");
  function Wj(a, b) {
    for (let c = 0; c < b.length; c++) {
      let d = b[c],
        e = Bd(d.property);
      a[e] = d.value;
    }
  }
  function Xj(a) {
    var b = y(A(a, 8)) ?? null;
    switch (b) {
      case 1:
      case 2:
        return (
          a == null
            ? (a = null)
            : ((b = C(a, xi, 1)),
              b == null
                ? (a = null)
                : ((a = y(A(a, 2))),
                  (a = a == null ? null : new hi({ Ga: [b], ya: a })))),
          a != null
            ? $h(a)
            : bi(Error("Missing dimension when creating placement id"))
        );
      case 3:
        return bi(Error("Missing dimension when creating placement id"));
      default:
        return bi(Error(`Invalid type: ${b}`));
    }
  }
  var Yj = class extends O {};
  var Zj = hd(class extends O {});
  function qg() {
    return "m202611110101";
  }
  var ak = gd(ng);
  var pg = gd(rg);
  function bk(a, b) {
    return b(a) ? a : void 0;
  }
  function ck(a, b, c, d, e) {
    c = c instanceof pe ? c.error : c;
    var f = new ug(),
      g = new tg();
    try {
      var h = Wd(window);
      Wc(g, 1, h);
    } catch (p) {}
    try {
      var k = Kh();
      Bc(g, 2, k, Lb);
    } catch (p) {}
    try {
      ad(g, 3, window.document.URL);
    } catch (p) {}
    h = E(f, 2, g);
    k = new sg();
    b = cd(k, 1, b);
    try {
      var l = x(c?.name) ? c.name : "Unknown error";
      ad(b, 2, l);
    } catch (p) {}
    try {
      var m = x(c?.message) ? c.message : `Caught ${c}`;
      ad(b, 3, m);
    } catch (p) {}
    try {
      var n = x(c?.stack) ? c.stack : Error().stack;
      n && Bc(b, 4, n.split(/\n\s*/), Sb);
    } catch (p) {}
    l = F(h, 1, vg, b);
    if (e) {
      m = 0;
      switch (e.errSrc) {
        case "LCC":
          m = 1;
          break;
        case "PVC":
          m = 2;
      }
      n = og();
      b = bk(e.shv, x);
      n = ad(n, 2, b);
      m = cd(n, 6, m);
      n = ak();
      n = jc(n);
      b = bk(e.es, rb());
      n = Bc(n, 1, b, Lb);
      n = kc(n);
      m = E(m, 4, n);
      n = bk(e.client, x);
      m = $c(m, 3, n);
      n = bk(e.slotname, x);
      m = ad(m, 7, n);
      e = bk(e.tag_origin, x);
      e = ad(m, 8, e);
      e = kc(e);
    } else e = ed(og());
    e = F(l, 6, wg, e);
    d = Wc(e, 5, d ?? 1);
    Tg(a, d);
  }
  var fk = class {
      constructor() {
        this.h = dk;
      }
      na(a) {
        return ek(this.h(), a);
      }
    },
    gk = class {
      constructor() {
        this.h = dk();
      }
      na(a) {
        return ek(this.h, a);
      }
    };
  function dk() {
    return {
      Zb: Gd() + (Gd() & (2 ** 21 - 1)) * 2 ** 32,
      Lb: Number.MAX_SAFE_INTEGER,
    };
  }
  function ek(a, b) {
    return b > 0 && a.Zb * b <= a.Lb;
  }
  var jk = class {
    constructor(a = !1) {
      var b = hk;
      this.pinger = ik;
      this.D = a;
      this.H = b;
      this.i = null;
      this.j = this.M;
    }
    J(a) {
      this.j = a;
    }
    C(a) {
      this.i = a;
    }
    N() {}
    h(a, b, c) {
      try {
        var d = b();
      } catch (e) {
        b = this.D;
        try {
          b = this.j(a, qe(e), void 0, c);
        } catch (f) {
          this.M(217, f);
        }
        if (b) window.console?.error?.(e);
        else throw e;
      }
      return d;
    }
    u(a, b) {
      return (...c) => this.h(a, () => b.apply(void 0, c));
    }
    wa(a, b) {
      b.catch((c) => {
        c = c ? c : "unknown rejection";
        this.M(a, c instanceof Error ? c : Error(c), void 0, void 0);
      });
    }
    M(a, b, c, d) {
      try {
        let f = c === void 0 ? 1 / this.H : c === 0 ? 0 : 1 / c;
        if (new fk().na(f)) {
          var e = this.pinger;
          c = {};
          if (this.i)
            try {
              this.i(c);
            } catch (g) {}
          if (d)
            try {
              d(c);
            } catch (g) {}
          ck(e, a, b, f, c);
        }
      } catch (f) {}
      return this.D;
    }
  };
  var W = class extends Error {
    constructor(a = "") {
      super();
      this.name = "TagError";
      this.message = a ? "adsbygoogle.push() error: " + a : "";
      Error.captureStackTrace
        ? Error.captureStackTrace(this, W)
        : (this.stack = Error().stack || "");
    }
  };
  let ik, kk, lk, mk, hk;
  const nk = new Ge(t);
  function ok(a) {
    a != null && (t.google_measure_js_timing = a);
    t.google_measure_js_timing || Fe(nk);
  }
  (function (a, b, c = !0) {
    ({ bc: hk, Pb: lk } = pk());
    kk = a || new Mh();
    Lh(kk, lk);
    ik = b || new eh(2, qg(), 1e3, void 0, void 0, void 0, Kh);
    mk = new jk(c);
    t.document.readyState === "complete"
      ? ok()
      : nk.h &&
        ee(t, "load", () => {
          ok();
        });
  })();
  function qk(a, b, c) {
    return mk.h(a, b, c);
  }
  function rk(a, b) {
    return mk.u(a, b);
  }
  function sk(a, b) {
    mk.wa(a, b);
  }
  function tk(a, b, c = 0.01) {
    var d = Kh();
    !b.eid && d.length && (b.eid = d.toString());
    Se(kk, a, b, !0, c);
  }
  function uk(a, b, c = hk, d, e) {
    return mk.M(a, b, c, d, e);
  }
  function vk(a, b, c = hk, d, e) {
    return (oe(b) ? b.msg || re(b.error) : re(b)).indexOf("TagError") === 0
      ? (((oe(b) ? b.error : b).pbr = !0), !1)
      : uk(a, b, c, d, e);
  }
  function pk() {
    if (mb(t.google_srt)) {
      var a = t.google_srt;
      var b = t.google_srt === 0 ? 1 : 0.01;
    } else (a = Math.random()), (b = 0.01);
    return { bc: b, Pb: a };
  }
  function wk(a) {
    try {
      var b = a.localStorage.getItem("google_auto_fc_cmp_setting");
    } catch (d) {
      b = null;
    }
    var c = b;
    return c ? ci(() => Zj(c)) : $h(null);
  }
  function xk() {
    if (yk) return yk;
    var a = Qh() || window;
    var b = a.google_persistent_state_async;
    return b != null &&
      typeof b == "object" &&
      b.S != null &&
      typeof b.S == "object"
      ? (yk = b)
      : (a.google_persistent_state_async = yk = new zk());
  }
  function Ak(a) {
    return Bk[a] || `google_ps_${a}`;
  }
  function Ck(a, b, c) {
    b = Ak(b);
    a = a.S;
    var d = a[b];
    return d === void 0 ? ((a[b] = c()), a[b]) : d;
  }
  function Dk(a, b, c) {
    return Ck(a, b, () => c);
  }
  var zk = class {
      constructor() {
        this.S = {};
      }
    },
    yk = null;
  const Bk = {
    [8]: "google_prev_ad_formats_by_region",
    [9]: "google_prev_ad_slotnames_by_region",
  };
  function Ek(a) {
    this.h = a || { cookie: "" };
  }
  Ek.prototype.set = function (a, b, c) {
    var d = !1;
    if (typeof c === "object") {
      var e = c.sameSite;
      d = c.secure || !1;
      var f = c.domain || void 0;
      var g = c.path || void 0;
      var h = c.Wb;
    }
    if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
    if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
    h === void 0 && (h = -1);
    this.h.cookie =
      a +
      "=" +
      b +
      (f ? ";domain=" + f : "") +
      (g ? ";path=" + g : "") +
      (h < 0
        ? ""
        : h == 0
        ? ";expires=" + new Date(1970, 1, 1).toUTCString()
        : ";expires=" + new Date(Date.now() + h * 1e3).toUTCString()) +
      (d ? ";secure" : "") +
      (e != null ? ";samesite=" + e : "");
  };
  Ek.prototype.get = function (a, b) {
    var c = a + "=",
      d = (this.h.cookie || "").split(";");
    for (let e = 0, f; e < d.length; e++) {
      f = wa(d[e]);
      if (f.lastIndexOf(c, 0) == 0) return f.slice(c.length);
      if (f == a) return "";
    }
    return b;
  };
  Ek.prototype.isEmpty = function () {
    return !this.h.cookie;
  };
  Ek.prototype.clear = function () {
    var a = (this.h.cookie || "").split(";"),
      b = [],
      c = [];
    for (let f = 0; f < a.length; f++) {
      var d = wa(a[f]);
      var e = d.indexOf("=");
      e == -1
        ? (b.push(""), c.push(d))
        : (b.push(d.substring(0, e)), c.push(d.substring(e + 1)));
    }
    for (c = b.length - 1; c >= 0; c--)
      (a = b[c]),
        this.get(a),
        this.set(a, "", { Wb: 0, path: void 0, domain: void 0 });
  };
  function Fk(a, b = window) {
    if (I(a, 5))
      try {
        return b.localStorage;
      } catch {}
    return null;
  }
  var Gk = class extends O {};
  function Hk() {
    this.C = this.C;
    this.i = this.i;
  }
  Hk.prototype.C = !1;
  Hk.prototype.dispose = function () {
    this.C || ((this.C = !0), this.H());
  };
  Hk.prototype[ia(Symbol, "dispose")] = function () {
    this.dispose();
  };
  function Ik(a, b) {
    a.C ? b() : (a.i || (a.i = []), a.i.push(b));
  }
  Hk.prototype.H = function () {
    if (this.i) for (; this.i.length; ) this.i.shift()();
  };
  function Jk(a) {
    a.addtlConsent === void 0 || x(a.addtlConsent) || (a.addtlConsent = void 0);
    a.gdprApplies === void 0 || nb(a.gdprApplies) || (a.gdprApplies = void 0);
    return (a.tcString !== void 0 && !x(a.tcString)) ||
      (a.listenerId !== void 0 && !mb(a.listenerId))
      ? 2
      : a.cmpStatus && a.cmpStatus !== "error"
      ? 0
      : 3;
  }
  function Kk(a) {
    if (a.gdprApplies === !1) return !0;
    a.internalErrorState === void 0 && (a.internalErrorState = Jk(a));
    return a.cmpStatus === "error" || a.internalErrorState !== 0
      ? a.internalBlockOnErrors
        ? (ke({ e: String(a.internalErrorState) }, "tcfe"), !1)
        : !0
      : a.cmpStatus === "loaded" &&
          (a.eventStatus === "tcloaded" ||
            a.eventStatus === "useractioncomplete");
  }
  function Lk(a) {
    if (a.h) return a.h;
    a: {
      let d = a.j;
      for (let e = 0; e < 50; ++e) {
        try {
          var b = !(!d.frames || !d.frames.__tcfapiLocator);
        } catch {
          b = !1;
        }
        if (b) {
          b = d;
          break a;
        }
        b: {
          try {
            let f = d.parent;
            if (f && f !== d) {
              var c = f;
              break b;
            }
          } catch {}
          c = null;
        }
        if (!(d = c)) break;
      }
      b = null;
    }
    a.h = b;
    return a.h;
  }
  function Mk(a, b, c, d) {
    c || (c = () => {});
    var e = a.j;
    typeof e.__tcfapi === "function"
      ? ((a = e.__tcfapi), a(b, 2, c, d))
      : Lk(a)
      ? (Nk(a),
        (e = ++a.J),
        (a.D[e] = c),
        a.h &&
          a.h.postMessage(
            {
              __tcfapiCall: { command: b, version: 2, callId: e, parameter: d },
            },
            "*"
          ))
      : c({}, !1);
  }
  function Nk(a) {
    if (!a.u) {
      var b = (c) => {
        if (c.source === a.h)
          try {
            var d = (x(c.data) ? JSON.parse(c.data) : c.data).__tcfapiReturn;
            a.D[d.callId](d.returnValue, d.success);
          } catch (e) {}
      };
      a.u = b;
      ee(a.j, "message", b);
    }
  }
  var Ok = class extends Hk {
    constructor(a) {
      var b = {};
      super();
      this.h = null;
      this.D = {};
      this.J = 0;
      this.u = null;
      this.j = a;
      this.timeoutMs = b.timeoutMs ?? 500;
      this.Ha = b.Ha ?? !1;
    }
    H() {
      this.D = {};
      this.u && (fe(this.j, "message", this.u), delete this.u);
      delete this.D;
      delete this.j;
      delete this.h;
      super.H();
    }
    addEventListener(a) {
      var b = { internalBlockOnErrors: this.Ha },
        c = pd(() => {
          a(b);
        }),
        d = 0;
      this.timeoutMs !== -1 &&
        (d = setTimeout(() => {
          b.tcString = "tcunavailable";
          b.internalErrorState = 1;
          c();
        }, this.timeoutMs));
      var e = (f, g) => {
        clearTimeout(d);
        f
          ? ((b = f),
            (b.internalErrorState = Jk(b)),
            (b.internalBlockOnErrors = this.Ha),
            (g && b.internalErrorState === 0) ||
              ((b.tcString = "tcunavailable"), g || (b.internalErrorState = 3)))
          : ((b.tcString = "tcunavailable"), (b.internalErrorState = 3));
        a(b);
      };
      try {
        Mk(this, "addEventListener", e);
      } catch (f) {
        (b.tcString = "tcunavailable"),
          (b.internalErrorState = 3),
          d && (clearTimeout(d), (d = 0)),
          c();
      }
    }
    removeEventListener(a) {
      a && a.listenerId && Mk(this, "removeEventListener", null, a.listenerId);
    }
  };
  function Pk({
    l: a,
    X: b,
    timeoutMs: c,
    callback: d,
    pa: e = !1,
    qa: f = !1,
  }) {
    b = Qk({ l: a, X: b, pa: e, qa: f });
    b.h != null || b.error.message !== "tcunav"
      ? d(b)
      : Rk(a, c)
          .then((g) => g.map(Sk))
          .then((g) => g.map((h) => Tk(a, h)))
          .then(d);
  }
  function Qk({ l: a, X: b, pa: c = !1, qa: d = !1 }) {
    if (!Uk({ l: a, X: b, pa: c, qa: d }))
      return (b = new Gk()), (b = B(b, 5, Hb(!0))), Tk(a, b);
    b = xk();
    return (b = Dk(b, 24) ?? null) ? Tk(a, Sk(b)) : bi(Error("tcunav"));
  }
  function Uk({ l: a, X: b, pa: c, qa: d }) {
    if ((d = !d))
      (d = new Ok(a)),
        (d = typeof d.j.__tcfapi === "function" || Lk(d) != null);
    if ((d = !d)) {
      if (!c) {
        if (!(b = !b))
          if (((a = wk(a)), a.h != null)) {
            if ((a = a.getValue()) && y(A(a, 1)) != null)
              b: switch (((a = L(a, 1)), a)) {
                case 1:
                  a = !0;
                  break b;
                default:
                  a = Ab(a, `Unhandled AutoGdprFeatureStatus: ${a}`);
              }
            else a = !1;
            b = a;
          } else uk(806, a.error), (b = !1);
        c = b;
      }
      d = c;
    }
    return !d;
  }
  function Rk(a, b) {
    return Promise.race([Vk(), Wk(a, b)]);
  }
  function Vk() {
    return new Promise((a) => {
      var b = xk();
      a = { resolve: a };
      var c = Dk(b, 25, []);
      c.push(a);
      b.S[Ak(25)] = c;
    }).then(Xk);
  }
  function Wk(a, b) {
    return new Promise((c) => {
      a.setTimeout(c, b, bi(Error("tcto")));
    });
  }
  function Xk(a) {
    return a ? $h(a) : bi(Error("tcnull"));
  }
  function Sk(a) {
    var b = new Gk(),
      c = {};
    if (Kk(a))
      if (a.gdprApplies === !1) a = !0;
      else if (a.tcString === "tcunavailable") a = !c.idpcApplies;
      else if (
        (c.idpcApplies || a.gdprApplies !== void 0 || c.Hc) &&
        (c.idpcApplies || (x(a.tcString) && a.tcString.length))
      ) {
        b: {
          if (
            a.publisher &&
            a.publisher.restrictions &&
            ((c = a.publisher.restrictions["1"]), c !== void 0)
          ) {
            c = c["755"];
            break b;
          }
          c = void 0;
        }
        c === 0
          ? (a = !1)
          : a.purpose && a.vendor
          ? ((c = a.vendor.consents),
            (c = !(!c || !c["755"])) &&
            a.purposeOneTreatment &&
            a.publisherCC === "CH"
              ? (a = !0)
              : (c && ((a = a.purpose.consents), (c = !(!a || !a["1"]))),
                (a = c)))
          : (a = !0);
      } else a = !0;
    else a = !1;
    return B(b, 5, Hb(a));
  }
  function Tk(a, b) {
    return (a = Fk(b, a)) ? $h(a) : bi(Error("unav"));
  }
  var Yk = class extends O {
    h() {
      return Qc(this, 1);
    }
  };
  var Zk = class extends O {};
  var $k = class extends O {};
  var al = class extends O {};
  var bl = class extends O {};
  var cl = class extends O {
      getName() {
        return H(this, 4, void 0, pc);
      }
    },
    dl = [1, 2, 3];
  var el = class extends O {};
  var fl = class extends O {};
  var hl = class extends O {
      h() {
        return C(this, fl, Gc(this, gl, 2));
      }
    },
    gl = [1, 2];
  var il = class extends O {
    h() {
      return C(this, hl, 3);
    }
  };
  var jl = class extends O {},
    kl = hd(jl);
  function ll(a, b) {
    var c = [],
      d = a;
    for (
      a = () => {
        c.push({ anchor: d.anchor, position: d.position });
        return d.anchor === b.anchor && d.position === b.position;
      };
      d;

    ) {
      if (d.position === 1) {
        if (a()) break;
        d.position = 2;
      }
      if (d.position === 2) {
        if (a()) break;
        if (d.anchor.firstChild) {
          d = { anchor: d.anchor.firstChild, position: 1 };
          continue;
        } else d.position = 3;
      }
      if (d.position === 3) {
        if (a()) break;
        d.position = 4;
      }
      if (d.position === 4 && a()) break;
      for (
        ;
        d &&
        !d.anchor.nextSibling &&
        d.anchor.parentNode !== d.anchor.ownerDocument.body;

      ) {
        d = { anchor: d.anchor.parentNode, position: 3 };
        if (a()) return c;
        d.position = 4;
        if (a()) return c;
      }
      d && d.anchor.nextSibling
        ? (d = { anchor: d.anchor.nextSibling, position: 1 })
        : (d = null);
    }
    return c;
  }
  function ml(a, b) {
    return a.map.map[ii(b)] !== void 0;
  }
  var nl = class {
    constructor(a) {
      this.map = new ji();
      if (a) for (let b = 0; b < a.length; ++b) this.add(a[b]);
    }
    add(a) {
      this.map.set(a, !0);
    }
  };
  var ol = class {
    constructor() {
      this.map = new ji();
    }
    set(a, b) {
      var c = this.map.get(a);
      c || ((c = new nl()), this.map.set(a, c));
      c.add(b);
    }
  };
  function pl(a, b) {
    var c = new ol(),
      d = new nl();
    b.forEach((e) => {
      var f = C(e, al, Gc(e, dl, 1)),
        g = C(e, bl, Gc(e, dl, 2));
      e = C(e, $k, Gc(e, dl, 3));
      if (f) {
        g = C(f, yi, 1);
        var h = g?.h();
        e = C(f, yi, 2);
        var k = e?.h();
        if (g && h && e && k && ((h = ql(a, h)), (k = ql(a, k)), h && k))
          for (var l of ll(
            { anchor: h, position: y(A(g, 2)) ?? 0 },
            { anchor: k, position: y(A(e, 2)) ?? 0 }
          ))
            c.set(na(l.anchor), l.position);
        f = C(f, yi, 3);
        l = f?.h();
        f && l && (l = ql(a, l)) && c.set(na(l), y(A(f, 2)) ?? 0);
      } else g ? rl(a, g, c) : e && sl(a, e, d);
    });
    return new tl(c, d);
  }
  var tl = class {
    constructor(a, b) {
      this.i = a;
      this.h = b;
    }
  };
  function rl(a, b, c) {
    var d = C(b, yi, 2);
    b = C(b, xi, 1);
    d
      ? (a = ql(a, d.h())) && c.set(na(a), y(A(d, 2)) ?? 0)
      : b &&
        ul(a, b).forEach((e) => {
          e = na(e);
          c.set(e, 1);
          c.set(e, 4);
          c.set(e, 2);
          c.set(e, 3);
        });
  }
  function sl(a, b, c) {
    (b = C(b, xi, 1)) &&
      ul(a, b).forEach((d) => {
        c.add(na(d));
      });
  }
  function ql(a, b) {
    return ul(a, b)[0] ?? null;
  }
  function ul(a, b) {
    return (b = Pi(b ?? null)) ? Gi(b, a) : [];
  }
  var vl = class {
    constructor() {
      var a = Math.random;
      this.h = Math.floor(a() * 2 ** 52);
      this.i = 0;
    }
  };
  function wl(a, b, c) {
    switch (c) {
      case 2:
      case 3:
        break;
      case 1:
      case 4:
        b = b.parentElement;
        break;
      default:
        throw Error("Unknown RelativePosition: " + String(c));
    }
    for (c = []; b; ) {
      if (xl(b)) return !0;
      if (a.h.has(b)) break;
      c.push(b);
      b = b.parentElement;
    }
    c.forEach((d) => {
      a.h.add(d);
    });
    return !1;
  }
  function yl(a) {
    a = zl(a);
    return a.has("all") || a.has("after");
  }
  function Al(a) {
    a = zl(a);
    return a.has("all") || a.has("before");
  }
  function zl(a) {
    return (a = a && a.getAttribute("data-no-auto-ads"))
      ? new Set(a.split("|"))
      : new Set();
  }
  function xl(a) {
    var b = zl(a);
    return (
      a &&
      (a.tagName === "AUTO-ADS-EXCLUSION-AREA" ||
        b.has("inside") ||
        b.has("all"))
    );
  }
  var Bl = class {
    constructor() {
      this.h = new Set();
      this.i = new vl();
    }
  };
  function Cl(a, b, c) {
    switch (a) {
      case 0:
        return Dl(El(b), c);
      case 3:
        return Dl(b, c);
      case 1:
        return !1;
      case 2:
        return (
          (a = b.lastChild), Dl(a ? (a.nodeType === 1 ? a : El(a)) : null, c)
        );
      default:
        return !1;
    }
  }
  function Dl(a, b) {
    if (!a) return !1;
    a = Nd(a, b);
    if (!a) return !1;
    a = a.cssFloat || a.styleFloat;
    return a === "left" || a === "right";
  }
  function El(a) {
    for (a = a.previousSibling; a && a.nodeType !== 1; ) a = a.previousSibling;
    return a ? a : null;
  }
  function Fl(a) {
    return !!a.nextSibling || (!!a.parentNode && Fl(a.parentNode));
  }
  function Gl(a = []) {
    var b = Date.now();
    return Ga(a, (c) => b - c < 6e5);
  }
  function Hl(a) {
    try {
      let b = a.getItem("__lsa__");
      if (!b) return [];
      let c;
      try {
        c = JSON.parse(b);
      } catch (d) {}
      if (!Array.isArray(c) || Ia(c, (d) => !Number.isInteger(d)))
        return a.removeItem("__lsa__"), [];
      c = Gl(c);
      c.length || a?.removeItem("__lsa__");
      return c;
    } catch (b) {
      return null;
    }
  }
  function Il(a) {
    return {
      Dc: Jl(a),
      Ec: Kl(a, "body ins.adsbygoogle"),
      Gb: Ll(a),
      Hb: Kl(a, ".google-auto-placed"),
      Ib: Ml(a),
      Mb: Nl(a),
      Jc: Ol(a),
      Rc: Pl(a),
      Yb: Ql(a),
      Ic: Kl(a, "div.googlepublisherpluginad"),
      lc: Kl(a, "html > ins.adsbygoogle"),
    };
  }
  function Ol(a) {
    return Rl(a) || Kl(a, "div[id^=div-gpt-ad],.google-gpt-auto-placed");
  }
  function Rl(a) {
    var b = a.googletag?.apiReady ? a.googletag : void 0;
    return b
      ? Ga(
          Ha(b.pubads().getSlots(), (c) =>
            a.document.getElementById(c.getSlotElementId())
          ),
          (c) => c != null
        )
      : null;
  }
  function Kl(a, b) {
    return La(a.document.querySelectorAll(b));
  }
  function Ml(a) {
    return Kl(a, "ins.adsbygoogle[data-anchor-status]");
  }
  function Ll(a) {
    return Kl(a, "iframe[id^=aswift_],iframe[id^=google_ads_frame]");
  }
  function Pl(a) {
    return Kl(a, "ins.adsbygoogle[data-ad-format=autorelaxed]");
  }
  function Nl(a) {
    return Ol(a).concat(Kl(a, "iframe[id^=google_ads_iframe]"));
  }
  function Ql(a) {
    return Kl(
      a,
      "div.trc_related_container,div.OUTBRAIN,div[id^=rcjsload],div[id^=ligatusframe],div[id^=crt-],iframe[id^=cto_iframe],div[id^=yandex_], div[id^=Ya_sync],iframe[src*=adnxs],div.advertisement--appnexus,div[id^=apn-ad],div[id^=amzn-native-ad],iframe[src*=amazon-adsystem],iframe[id^=ox_],iframe[src*=openx],img[src*=openx],div[class*=adtech],div[id^=adtech],iframe[src*=adtech],div[data-content-ad-placement=true],div.wpcnt div[id^=atatags-]"
    );
  }
  function Jl(a) {
    return Kl(a, "ins.adsbygoogle-ablated-ad-slot");
  }
  function Sl(a) {
    return a.filter((b) => !b.querySelector('[data-google-ad-efd="true"]'));
  }
  function Tl(a) {
    var b = [];
    for (let c of a) {
      a = !0;
      for (let d = 0; d < b.length; d++) {
        let e = b[d];
        if (e.contains(c)) {
          a = !1;
          break;
        }
        if (c.contains(e)) {
          a = !1;
          b[d] = c;
          break;
        }
      }
      a && b.push(c);
    }
    return b;
  }
  function Ul(a, b) {
    if (a.u) return !0;
    a.u = !0;
    var c = D(a.j, Ai, 1);
    a.i = 0;
    var d = Vl(a.N);
    var e = a.h,
      f = I(a.j, 36),
      g = a.J,
      h;
    try {
      var k = (h = e.localStorage.getItem("google_ama_settings"))
        ? wi(h)
        : null;
    } catch (w) {
      k = null;
    }
    h = k !== null && I(k, 2);
    k = Ti(e);
    h && ((k.eatf = !0), ne(7, [!0, 0, !1]));
    b: {
      h = { Sb: !1, Tb: !1, Nb: !0 };
      var l = Kl(e, ".google-auto-placed");
      let w = Ml(e),
        G = Pl(e),
        Y = Nl(e),
        Ea = Ql(e),
        Fa = Jl(e),
        sa = Kl(e, "div.googlepublisherpluginad"),
        fa = Kl(e, "html > ins.adsbygoogle");
      var m = [].concat(...Ll(e), ...Kl(e, "body ins.adsbygoogle")),
        n = [];
      h.Nb && (n = n.concat(Kl(e, "ins.adsbygoogle[data-ad-hi]")));
      for (let [ic, Ee] of [
        [h.Lc, l],
        [h.Sb, w],
        [h.Oc, G],
        [h.Mc, Y],
        [h.Pc, Ea],
        [h.Kc, Fa],
        [h.Nc, sa],
        [h.Tb, fa],
      ])
        (l = Ee), ic === !1 ? (n = n.concat(l)) : (m = m.concat(l));
      m = Tl(m);
      n = Tl(n);
      m = m.slice(0);
      for (p of n)
        for (n = 0; n < m.length; n++)
          (p.contains(m[n]) || m[n].contains(p)) && m.splice(n, 1);
      var p = m;
      p = h.Gc ? Sl(p) : p;
      h = Mj(e).clientHeight;
      for (n = 0; n < p.length; n++)
        if (!(p[n].getBoundingClientRect().top > h)) {
          p = !0;
          break b;
        }
      p = !1;
    }
    if (p) var r = (k.eatfAbg = !0);
    else if (U(pj) && f) {
      e = Qk({ l: e, X: g });
      if ((f = e.h != null)) {
        e = di(e);
        if (!(f = e == null)) {
          try {
            e.setItem("__storage_test__", "__storage_test__");
            var q = e.getItem("__storage_test__");
            e.removeItem("__storage_test__");
            r = q === "__storage_test__";
          } catch (w) {
            r = !1;
          }
          f = !r;
        }
        r = f ? null : Hl(e);
        q = V(Wi);
        f = !(
          r?.length && Math.floor((Date.now() - Math.max(...r)) / 6e4) <= q
        );
      }
      r = f;
    } else r = !1;
    if (r) return !0;
    r = new nl([2]);
    for (q = 0; q < c.length; q++) {
      a: {
        e = a;
        g = c[q];
        f = q;
        k = b;
        (p = !C(g, qi, 4)) ||
          ((p = C(g, qi, 4)), (p = Uc(p, 1)), (p = !ml(r, p)));
        if (p || Uc(g, 8) !== 1 || (g && tc(g, 4) && d[pi(C(g, qi, 4))])) {
          e = null;
          break a;
        }
        e.i++;
        if ((k = Wl(e, g, k, d)))
          (p = Ti(e.h)),
            p.numAutoAdsPlaced || (p.numAutoAdsPlaced = 0),
            (g = C(g, xi, 1)) &&
              Mb(A(g, 5)) != null &&
              (p.numPostPlacementsPlaced
                ? p.numPostPlacementsPlaced++
                : (p.numPostPlacementsPlaced = 1)),
            p.placed == null && (p.placed = []),
            p.numAutoAdsPlaced++,
            p.placed.push({ index: f, element: k.ka }),
            ne(7, [!1, e.i, !0]);
        e = k;
      }
      if (e) return !0;
    }
    ne(7, [!1, a.i, !1]);
    return !1;
  }
  function Wl(a, b, c, d) {
    if ((b && tc(b, 4) && d[pi(C(b, qi, 4))]) || y(A(b, 8)) != 1) return null;
    d = C(b, xi, 1);
    if (!d) return null;
    d = Pi(d);
    if (!d) return null;
    d = Gi(d, a.h.document);
    if (d.length == 0) return null;
    d = d[0];
    var e = Uc(b, 2);
    e = Si[e] ?? null;
    var f;
    if (!(f = e == null)) {
      if ((c = !Cl(e, d, a.h) && !(!c && e === 2 && !Fl(d))))
        (c = e === 1 || e === 2 ? d : d.parentNode),
          (c = !(c && !Ii(c) && c.offsetWidth <= 0));
      f = !c;
    }
    if (!(c = f)) {
      c = a.D;
      f = Uc(b, 2);
      var g = c.i,
        h = na(d);
      g = g.map.get(h);
      if (!(g = g ? ml(g, f) : !1))
        a: {
          if (ml(c.h, na(d)))
            switch (f) {
              case 2:
              case 3:
                g = !0;
                break a;
              default:
                g = !1;
                break a;
            }
          for (f = d.parentElement; f; ) {
            if (ml(c.h, na(f))) {
              g = !0;
              break a;
            }
            f = f.parentElement;
          }
          g = !1;
        }
      c = g;
    }
    if (!c) {
      c = a.H;
      g = Uc(b, 2);
      a: switch (g) {
        case 1:
          f = yl(d.previousElementSibling) || Al(d);
          break a;
        case 4:
          f = yl(d) || Al(d.nextElementSibling);
          break a;
        case 2:
          f = Al(d.firstElementChild);
          break a;
        case 3:
          f = yl(d.lastElementChild);
          break a;
        default:
          throw Error("Unknown RelativePosition: " + String(g));
      }
      g = wl(c, d, g);
      c = c.i;
      tk(
        "ama_exclusion_zone",
        {
          typ: f ? (g ? "siuex" : "siex") : g ? "suex" : "noex",
          cor: c.h,
          num: c.i++,
          dvc: Cd(),
        },
        0.1
      );
      c = f || g;
    }
    if (c) return null;
    f = C(b, zi, 3);
    c = {};
    f && ((c.Db = H(f, 1)), (c.rb = H(f, 2)), (c.Kb = !!Rc(f, 3)));
    f = C(b, qi, 4) && pi(C(b, qi, 4)) ? pi(C(b, qi, 4)) : null;
    f = ti(f);
    g = Mb(A(b, 12)) != null ? Mb(A(b, 12, void 0, pc)) : null;
    g = g == null ? null : new si(null, { google_ml_rank: g });
    b = Xl(a, b);
    b = ri(a.C, f, g, b);
    f = a.h;
    a = a.W;
    h = f.document;
    var k = c.Kb || !1;
    g = ce(new de(h).h, "DIV");
    var l = g.style;
    l.width = "100%";
    l.height = "auto";
    l.clear = k ? "both" : "none";
    k = g.style;
    k.textAlign = "center";
    c.ac && Wj(k, c.ac);
    h = ce(new de(h).h, "INS");
    k = h.style;
    k.display = "block";
    k.margin = "auto";
    k.backgroundColor = "transparent";
    c.Db && (k.marginTop = c.Db);
    c.rb && (k.marginBottom = c.rb);
    c.Fb && Wj(k, c.Fb);
    g.appendChild(h);
    c = { La: g, ka: h };
    c.ka.setAttribute("data-ad-format", "auto");
    g = [];
    if ((h = b && b.h)) c.La.className = h.join(" ");
    h = c.ka;
    h.className = "adsbygoogle";
    h.setAttribute("data-ad-client", a);
    g.length && h.setAttribute("data-ad-channel", g.join("+"));
    a: {
      try {
        var m = c.La;
        if (U(nj)) {
          {
            let w = Ij(d, e);
            if (w.init) {
              var n = w.init;
              for (d = n; (d = w.oa(d)); ) n = d;
              var p = { anchor: n, position: w.va };
            } else p = { anchor: d, position: e };
          }
          m["google-ama-order-assurance"] = 0;
          Ji(m, p.anchor, p.position);
        } else Ji(m, d, e);
        b: {
          var r = c.ka;
          r.dataset.adsbygoogleStatus = "reserved";
          r.className += " adsbygoogle-noablate";
          m = { element: r };
          var q = b && b.ca;
          let w = r.getAttribute("data-pub-vars");
          if (w != null) {
            try {
              q = JSON.parse(w);
            } catch (G) {
              break b;
            }
            r.removeAttribute("data-pub-vars");
          }
          q && (m.params = q);
          (f.adsbygoogle = f.adsbygoogle || []).push(m);
        }
      } catch (w) {
        (r = c.La) &&
          r.parentNode &&
          ((q = r.parentNode),
          q.removeChild(r),
          Ii(q) &&
            (q.style.display = q.getAttribute("data-init-display") || "none"));
        r = !1;
        break a;
      }
      r = !0;
    }
    return r ? c : null;
  }
  function Xl(a, b) {
    return di(
      fi(Xj(b).map(ui), (c) => {
        Ti(a.h).exception = c;
      })
    );
  }
  var Yl = class {
    constructor(a, b, c, d, e, f = !1) {
      this.h = a;
      this.W = b;
      this.j = c;
      this.C = e || null;
      this.J = f;
      (this.N = d)
        ? ((a = a.document), (d = D(d, cl, 5)), (d = pl(a, d)))
        : (d = pl(a.document, []));
      this.D = d;
      this.H = new Bl();
      this.i = 0;
      this.u = !1;
    }
  };
  function Vl(a) {
    var b = {};
    a &&
      wc(a, 6, y).forEach((c) => {
        b[c] = !0;
      });
    return b;
  }
  var Zl = class extends O {};
  var $l = class extends O {};
  var am = class {
    constructor(a) {
      this.exception = a;
    }
  };
  function bm(a) {
    try {
      switch (a.l.document.readyState) {
        case "complete":
        case "interactive":
          Ul(a.h, !0);
          cm(a);
          break;
        default:
          Ul(a.h, !1) ? cm(a) : dm(a);
      }
    } catch (b) {
      cm(a, b);
    }
  }
  function cm(a, b) {
    try {
      var c = a.i,
        d = c.resolve,
        e = a.h;
      Ti(e.h);
      D(e.j, Ai, 1);
      d.call(c, new am(b));
    } catch (f) {
      a.i.reject(f);
    }
  }
  function dm(a) {
    a.l.setTimeout(() => {
      bm(a);
    }, 100);
  }
  class em {
    constructor(a, b, c) {
      this.l = a;
      this.h = b;
      this.i = c;
    }
    start() {
      bm(this);
    }
  }
  var fm = class extends O {
    getVersion() {
      return J(this, 2);
    }
  };
  function gm(a) {
    return Pa(a.length % 4 !== 0 ? a + "A" : a)
      .map((b) => b.toString(2).padStart(8, "0"))
      .join("");
  }
  function hm(a) {
    if (!/^[0-1]+$/.test(a))
      throw Error(`Invalid input [${a}] not a bit string.`);
    return parseInt(a, 2);
  }
  function im(a) {
    if (!/^[0-1]+$/.test(a))
      throw Error(`Invalid input [${a}] not a bit string.`);
    var b = [1, 2, 3, 5],
      c = 0;
    for (let d = 0; d < a.length - 1; d++)
      b.length <= d && b.push(b[d - 1] + b[d - 2]),
        (c += parseInt(a[d], 2) * b[d]);
    return c;
  }
  function jm(a) {
    var b = gm(a),
      c = hm(b.slice(0, 6));
    a = hm(b.slice(6, 12));
    var d = new fm();
    c = M(d, 1, c);
    a = M(c, 2, a);
    b = b.slice(12);
    c = hm(b.slice(0, 12));
    d = [];
    var e = b.slice(12).replace(/0+$/, "");
    for (let k = 0; k < c; k++) {
      if (e.length === 0)
        throw Error(
          `Found ${k} of ${c} sections [${d}] but reached end of input [${b}]`
        );
      var f = hm(e[0]) === 0;
      e = e.slice(1);
      var g = km(e, b),
        h = d.length === 0 ? 0 : d[d.length - 1];
      h = im(g) + h;
      e = e.slice(g.length);
      if (f) {
        d.push(h);
        continue;
      }
      f = km(e, b);
      g = im(f);
      for (let l = 0; l <= g; l++) d.push(h + l);
      e = e.slice(f.length);
    }
    if (e.length > 0)
      throw Error(
        `Found ${c} sections [${d}] but has remaining input [${e}], entire input [${b}]`
      );
    return Bc(a, 3, d, Lb);
  }
  function km(a, b) {
    var c = a.indexOf("11");
    if (c === -1)
      throw Error(
        `Expected section bitstring but not found in [${a}] part of [${b}]`
      );
    return a.slice(0, c + 2);
  }
  var lm = be(Uh).map((a) => Number(a)),
    mm = be(Vh).map((a) => Number(a));
  function nm() {
    var a = new om();
    return Wc(a, 1, 0);
  }
  var om = class extends O {};
  function pm(a) {
    a == null || tb(a);
    if (a != null) return qm(a);
  }
  function qm(a) {
    wb(a);
    return wb(a) ? Number(a) : String(a);
  }
  function rm(a, b) {
    if (a.h + b > a.i.length)
      throw Error(`Requested length ${b} is past end of string.`);
    var c = a.i.substring(a.h, a.h + b);
    a.h += b;
    return parseInt(c, 2);
  }
  function sm(a) {
    var b = () => {
      var c = rm(a, 6);
      if (c > 25 || c < 0)
        throw Error(
          `Invalid character code, expected in range [0,25], got: ${c}`
        );
      return String.fromCharCode(97 + c);
    };
    return b() + b();
  }
  function tm(a) {
    for (var b = rm(a, 12), c = []; b--; ) {
      var d = !!rm(a, 1) === !0,
        e = rm(a, 16);
      if (d) for (d = rm(a, 16); e <= d; e++) c.push(e);
      else c.push(e);
    }
    c.sort((f, g) => f - g);
    return c;
  }
  function um(a, b, c) {
    var d = [];
    for (let e = 0; e < b; e++)
      if (rm(a, 1)) {
        let f = e + 1;
        if (c && c.indexOf(f) === -1)
          throw Error(`ID: ${f} is outside of allowed values!`);
        d.push(f);
      }
    return d;
  }
  function vm(a) {
    var b = rm(a, 16);
    if (!!rm(a, 1) === !0) {
      a = tm(a);
      for (let c of a)
        if (c > b) throw Error(`ID ${c} is past MaxVendorId ${b}!`);
      return a;
    }
    return um(a, b);
  }
  var wm = class {
    constructor(a) {
      this.i = a;
      this.h = 0;
      if (/[^01]/.test(this.i))
        throw Error(`Input bitstring ${this.i} is malformed!`);
    }
    skip(a) {
      this.h += a;
    }
  };
  var xm = class extends O {
    h() {
      return H(this, 2) != null;
    }
  };
  var ym = class extends O {};
  var zm = hd(class extends O {});
  function Am(a) {
    a = Bm(a);
    try {
      var b = a ? zm(a) : null;
    } catch (c) {
      b = null;
    }
    return b ? C(b, ym, 4) || null : null;
  }
  function Bm(a) {
    a = a?.location?.origin !== "null" ? new Ek(a).get("FCCDCF", "") : "";
    if (a)
      if (a.startsWith("%"))
        try {
          var b = decodeURIComponent(a);
        } catch (c) {
          b = null;
        }
      else b = a;
    else b = null;
    return b;
  }
  be(Uh).map((a) => Number(a));
  be(Vh).map((a) => Number(a));
  function Cm(a) {
    a.__tcfapiPostMessageReady || Dm(new Em(a));
  }
  function Dm(a) {
    a.h = (b) => {
      var c = typeof b.data === "string";
      try {
        var d = c ? JSON.parse(b.data) : b.data;
      } catch (f) {
        return;
      }
      var e = d.__tcfapiCall;
      e &&
        (e.command === "ping" ||
          e.command === "addEventListener" ||
          e.command === "removeEventListener") &&
        (0, a.l.__tcfapi)(
          e.command,
          e.version,
          (f, g) => {
            var h = {};
            h.__tcfapiReturn =
              e.command === "removeEventListener"
                ? { success: f, callId: e.callId }
                : { returnValue: f, success: g, callId: e.callId };
            f = c ? JSON.stringify(h) : h;
            b.source &&
              typeof b.source.postMessage === "function" &&
              b.source.postMessage(f, b.origin);
            return f;
          },
          e.parameter
        );
    };
    a.l.addEventListener("message", a.h);
    a.l.__tcfapiPostMessageReady = !0;
  }
  var Em = class {
    constructor(a) {
      this.l = a;
    }
  };
  function Fm(a) {
    a.__uspapiPostMessageReady || Gm(new Hm(a));
  }
  function Gm(a) {
    a.h = (b) => {
      var c = typeof b.data === "string";
      try {
        var d = c ? JSON.parse(b.data) : b.data;
      } catch (f) {
        return;
      }
      var e = d.__uspapiCall;
      e &&
        e.command === "getUSPData" &&
        a.l.__uspapi(e.command, e.version, (f, g) => {
          var h = {};
          h.__uspapiReturn = { returnValue: f, success: g, callId: e.callId };
          f = c ? JSON.stringify(h) : h;
          b.source &&
            typeof b.source.postMessage === "function" &&
            b.source.postMessage(f, b.origin);
          return f;
        });
    };
    a.l.addEventListener("message", a.h);
    a.l.__uspapiPostMessageReady = !0;
  }
  var Hm = class {
    constructor(a) {
      this.l = a;
      this.h = null;
    }
  };
  var Im = class extends O {};
  var Jm = hd(
    class extends O {
      h() {
        return H(this, 1) != null;
      }
    }
  );
  function Km(a, b) {
    try {
      let c = a.split("."),
        d = Pa(c[0])
          .map((g) => g.toString(2).padStart(8, "0"))
          .join(""),
        e = new wm(d);
      a = { tcString: a ?? void 0, gdprApplies: b };
      e.skip(78);
      a.cmpId = rm(e, 12);
      a.cmpVersion = rm(e, 12);
      e.skip(30);
      a.tcfPolicyVersion = rm(e, 6);
      a.isServiceSpecific = !!rm(e, 1);
      a.useNonStandardStacks = !!rm(e, 1);
      a.specialFeatureOptins = Lm(um(e, 12, mm), mm);
      a.purpose = {
        consents: Lm(um(e, 24, lm), lm),
        legitimateInterests: Lm(um(e, 24, lm), lm),
      };
      a.purposeOneTreatment = !!rm(e, 1);
      a.publisherCC = sm(e);
      a.vendor = {
        consents: Lm(vm(e), null),
        legitimateInterests: Lm(vm(e), null),
      };
      let f = Mm(c);
      f && (a.vendor.disclosedVendors = f);
      return a;
    } catch (c) {
      return null;
    }
  }
  function Mm(a) {
    a.shift();
    for (let b of a)
      if (
        ((a = Pa(b)
          .map((c) => c.toString(2).padStart(8, "0"))
          .join("")),
        (a = new wm(a)),
        rm(a, 3) === 1)
      )
        return Lm(vm(a), null);
  }
  function Lm(a, b) {
    var c = {};
    if (Array.isArray(b) && b.length !== 0)
      for (let d of b) c[d] = a.indexOf(d) !== -1;
    else for (let d of a) c[d] = !0;
    delete c[0];
    return c;
  }
  function Nm(a, b) {
    function c(n) {
      if (n.length < 10) return null;
      var p = h(n.slice(0, 4));
      p = k(p);
      n = h(n.slice(6, 10));
      n = l(n);
      return "1" + p + n + "N";
    }
    function d(n) {
      if (n.length < 10) return null;
      var p = h(n.slice(0, 6));
      p = k(p);
      n = h(n.slice(6, 10));
      n = l(n);
      return "1" + p + n + "N";
    }
    function e(n) {
      if (n.length < 12) return null;
      var p = h(n.slice(0, 6));
      p = k(p);
      n = h(n.slice(8, 12));
      n = l(n);
      return "1" + p + n + "N";
    }
    function f(n) {
      if (n.length < 18) return null;
      var p = h(n.slice(0, 8));
      p = k(p);
      n = h(n.slice(12, 18));
      n = l(n);
      return "1" + p + n + "N";
    }
    function g(n) {
      if (n.length < 10) return null;
      var p = h(n.slice(0, 6));
      p = k(p);
      n = h(n.slice(6, 10));
      n = l(n);
      return "1" + p + n + "N";
    }
    function h(n) {
      var p = [],
        r = 0;
      for (let q = 0; q < n.length / 2; q++)
        p.push(hm(n.slice(r, r + 2))), (r += 2);
      return p;
    }
    function k(n) {
      return n.every((p) => p === 1) ? "Y" : "N";
    }
    function l(n) {
      return n.some((p) => p === 1) ? "Y" : "N";
    }
    if (a.length === 0) return null;
    a = a.split(".");
    if (a.length > 2) return null;
    a = gm(a[0]);
    var m = hm(a.slice(0, 6));
    a = a.slice(6);
    if (m !== 1) return null;
    switch (b) {
      case 8:
        return c(a);
      case 10:
      case 12:
      case 9:
        return d(a);
      case 11:
        return e(a);
      case 7:
        return f(a);
      case 13:
        return g(a);
      default:
        return null;
    }
  }
  function Om(a, b) {
    var c = a.document,
      d = () => {
        if (!a.frames[b])
          if (c.body) {
            let e = Md("IFRAME", c);
            e.style.display = "none";
            e.style.width = "0px";
            e.style.height = "0px";
            e.style.border = "none";
            e.style.zIndex = "-1000";
            e.style.left = "-1000px";
            e.style.top = "-1000px";
            e.name = b;
            c.body.appendChild(e);
          } else a.setTimeout(d, 5);
      };
    d();
  }
  function Pm(a) {
    Q === Q.top && ((a = new Qm(a)), Rm(a), Sm(a));
  }
  function Rm(a) {
    !a.j ||
      a.l.__uspapi ||
      a.l.frames.__uspapiLocator ||
      ((a.l.__uspapiManager = "fc"),
      Om(a.l, "__uspapiLocator"),
      qa(
        "__uspapi",
        (b, c, d) => {
          typeof d === "function" &&
            b === "getUSPData" &&
            d(
              { version: 1, uspString: a.xa !== 9 || a.i.j() ? a.j : "1---" },
              !0
            );
        },
        a.l
      ),
      Fm(a.l));
  }
  function Sm(a) {
    !a.tcString ||
      a.l.__tcfapi ||
      a.l.frames.__tcfapiLocator ||
      ((a.l.__tcfapiManager = "fc"),
      Om(a.l, "__tcfapiLocator"),
      (a.l.__tcfapiEventListeners = a.l.__tcfapiEventListeners || []),
      qa(
        "__tcfapi",
        (b, c, d, e) => {
          if (typeof d === "function")
            if (c && (c > 2.3 || c <= 1)) d(null, !1);
            else {
              var f = a.l.__tcfapiEventListeners;
              c = a.xa !== 9 || a.i.h();
              switch (b) {
                case "ping":
                  d({
                    gdprApplies: c,
                    cmpLoaded: !0,
                    cmpStatus: "loaded",
                    displayStatus: "disabled",
                    apiVersion: "2.3",
                    cmpVersion: 2,
                    cmpId: 300,
                  });
                  break;
                case "addEventListener":
                  b = f.push(d) - 1;
                  a.tcString
                    ? ((e = Km(a.tcString, c)),
                      (e.addtlConsent = a.h != null ? a.h : void 0),
                      (e.cmpStatus = "loaded"),
                      (e.eventStatus = "tcloaded"),
                      b != null && (e.listenerId = b),
                      (b = e))
                    : (b = null);
                  d(b, !0);
                  break;
                case "removeEventListener":
                  e !== void 0 && f[e] ? ((f[e] = null), d(!0)) : d(!1);
                  break;
                case "getInAppTCData":
                case "getVendorList":
                  d(null, !1);
                  break;
                case "getTCData":
                  d(null, !1);
              }
            }
        },
        a.l
      ),
      Cm(a.l));
  }
  function Tm(a) {
    a = Um(a);
    if (!a?.h() || K(a, 1).length === 0 || D(a, Im, 2).length === 0)
      return null;
    var b = K(a, 1);
    try {
      var c = jm(b.split("~")[0]);
      var d = b.includes("~") ? b.split("~").slice(1) : [];
    } catch (e) {
      return null;
    }
    a = D(a, Im, 2).reduce((e, f) => {
      var g = tc(e, 2) ? C(e, om, 2) : nm();
      g = Qc(g, 1) ?? oc;
      g = qm(g);
      var h = tc(f, 2) ? C(f, om, 2) : nm();
      h = Qc(h, 1) ?? oc;
      return g > qm(h) ? e : f;
    });
    c = wc(c, 3, Mb).indexOf(J(a, 1));
    return c === -1 || c >= d.length ? null : Nm(d[c], J(a, 1));
  }
  function Vm(a) {
    a = a.find((b) => b && L(b, 1) === 13);
    if (a?.h())
      try {
        return Jm(K(a, 2));
      } catch (b) {}
    return null;
  }
  function Um(a) {
    a = Bm(a.l.document);
    try {
      var b = a ? zm(a) : null;
    } catch (c) {
      b = null;
    }
    if (!b) return null;
    b = D(b, xm, 7);
    return Vm(b ?? []);
  }
  var Qm = class {
    constructor(a) {
      var b = Q;
      this.l = b;
      this.i = a;
      this.xa = 9;
      this.j = Tm(this);
      this.tcString = (a = Am(b.document)) && H(a, 1) != null ? K(a, 1) : null;
      this.h = (b = Am(b.document)) && H(b, 2) != null ? K(b, 2) : null;
    }
  };
  var vc;
  vc = kb;
  function Wm(a) {
    a = Number(((a.charCodeAt(0) - 43) & -3 ? "0" : "") + a + ".");
    return Number.isInteger(a) ? a : void 0;
  }
  const Xm = { google_ad_channel: !0, google_ad_host: !0 };
  function Ym(a, b) {
    a.location.href &&
      a.location.href.substring &&
      (b.url = a.location.href.substring(0, 200));
    tk("ama", b, 0.01);
  }
  function Zm(a) {
    var b = {};
    kd(Xm, (c, d) => {
      a.hasOwnProperty(d) && (b[d] = a[d]);
    });
    return b;
  }
  function $m(a) {
    var b = /[a-zA-Z0-9._~-]/,
      c = /%[89a-zA-Z]./;
    return a.replace(/(%[a-zA-Z0-9]{2})/g, (d) => {
      if (!d.match(c)) {
        let e = decodeURIComponent(d);
        if (e.match(b)) return e;
      }
      return d.toUpperCase();
    });
  }
  function an(a) {
    var b = "",
      c = /[/%?&=]/;
    for (let d = 0; d < a.length; ++d) {
      let e = a[d];
      b = e.match(c) ? b + e : b + encodeURIComponent(e);
    }
    return b;
  }
  function bn(a) {
    a = wc(a, 2, y);
    if (!a) return !1;
    for (let b = 0; b < a.length; b++) if (a[b] == 1) return !0;
    return !1;
  }
  function cn(a, b) {
    a = an($m(a.location.pathname)).replace(/(^\/)|(\/$)/g, "");
    var c = ki(a),
      d = dn(a);
    return (
      b.find((e) => {
        if (tc(e, 7)) {
          var f = C(e, Zk, 7);
          f = Nb(A(f, 1, void 0, pc));
        } else f = Nb(A(e, 1, void 0, pc));
        tc(e, 7) ? ((e = C(e, Zk, 7)), (e = Uc(e, 2))) : (e = 2);
        if (!mb(f)) return !1;
        switch (e) {
          case 1:
            return f == c;
          case 2:
            return d[f] || !1;
        }
        return !1;
      }) || null
    );
  }
  function dn(a) {
    for (var b = {}; ; ) {
      b[ki(a)] = !0;
      if (!a) return b;
      a = a.substring(0, a.lastIndexOf("/"));
    }
  }
  function X(a) {
    return (a.google_ad_modifications = a.google_ad_modifications || {});
  }
  function en(a) {
    a = X(a);
    var b = a.space_collapsing || "none";
    return a.had_ads_ablation
      ? { nb: !0, jc: b, ob: a.ablation_viewport_offset }
      : null;
  }
  function fn(a) {
    a = X(a);
    a.had_ads_ablation = !0;
    a.space_collapsing = "slot";
    a.ablation_viewport_offset = 1;
  }
  function gn(a) {
    X(Q).allow_second_reactive_tag = a;
  }
  function hn() {
    var a = X(window);
    a.afg_slotcar_vars || (a.afg_slotcar_vars = {});
    return a.afg_slotcar_vars;
  }
  function jn(a) {
    return X(a)?.head_tag_slot_vars?.google_ad_host ?? kn(a);
  }
  function kn(a) {
    return (
      a.document
        ?.querySelector('meta[name="google-adsense-platform-account"]')
        ?.getAttribute("content") ?? null
    );
  }
  const ln = [2, 7, 1, 9];
  function mn(a, b, c, d = "") {
    return b === 1 && c && (nn(a, d, c)?.N() ?? !1)
      ? !0
      : on(a, d, (e) => Ia(D(e, id, 2), (f) => Uc(f, 1) === b), !!c?.h()?.h());
  }
  function pn(a, b) {
    var c = md(Q) || Q;
    return qn(c, a) ? !0 : on(Q, "", (d) => Ia(wc(d, 3, y), (e) => e === a), b);
  }
  function qn(a, b) {
    a =
      (a =
        (a = a.location && a.location.hash) &&
        a.match(/forced_clientside_labs=([\d,]+)/)) && a[1];
    return !!a && Ka(a.split(","), b.toString());
  }
  function on(a, b, c, d) {
    a = md(a) || a;
    var e = rn(a, d);
    b && (b = Sh(String(b)));
    return ae(
      e,
      (f, g) =>
        Object.prototype.hasOwnProperty.call(e, g) && (!b || b === g) && c(f)
    );
  }
  function rn(a, b) {
    a = sn(a, b);
    var c = {};
    kd(a, (d, e) => {
      try {
        let f = fd(jd, ac(d));
        c[e] = f;
      } catch (f) {}
    });
    return c;
  }
  function sn(a, b) {
    a = Qk({ l: a, X: b });
    return a.h != null ? tn(a.getValue()) : {};
  }
  function tn(a) {
    try {
      let b = a.getItem("google_adsense_settings");
      if (!b) return {};
      let c = JSON.parse(b);
      return c !== Object(c)
        ? {}
        : $d(
            c,
            (d, e) =>
              Object.prototype.hasOwnProperty.call(c, e) &&
              x(e) &&
              Array.isArray(d)
          );
    } catch (b) {
      return {};
    }
  }
  function un(a, b) {
    var c = [];
    a = jn(t) ? ln : (a = nn(t, a, b)?.ea()) ? [...wc(a, 3, y)] : ln;
    a.includes(1) || c.push(1);
    a.includes(2) || c.push(2);
    a.includes(7) || c.push(7);
    U(Cj) && !a.includes(9) && c.push(9);
    return c;
  }
  function nn(a, b, c) {
    if (!b) return null;
    var d = Z(c)?.u(),
      e = Z(c)?.h()?.h();
    b = b ?? "";
    return (d ?? "") === b ||
      ((e ?? "") === b &&
        a.location.host &&
        (K(c, 17) || "") === a.location.host)
      ? Z(c)
      : null;
  }
  function vn(a, b, c) {
    var d = Z(c)?.h()?.h() || "",
      e = Z(c)?.u() || "";
    return (
      !!b &&
      (d === b || e === b) &&
      !!a.location.host &&
      K(c, 17) === a.location.host
    );
  }
  function wn(a, b, c, d) {
    xn(new yn(a, b, c, d));
  }
  function xn(a) {
    var b = !!a.U.h()?.h();
    fi(
      ei(Qk({ l: a.l, X: b }), (c) => {
        zn(a, c, !0);
      }),
      () => {
        An(a);
      }
    );
  }
  function zn(a, b, c) {
    fi(
      ei(Bn(b), (d) => {
        Cn("ok");
        a.h(d, { fromLocalStorage: !0 });
      }),
      () => {
        var d = a.l;
        try {
          b.removeItem("google_ama_config");
        } catch (e) {
          Ym(d, { lserr: 1 });
        }
        c ? An(a) : a.h(null, null);
      }
    );
  }
  function An(a) {
    fi(
      ei(Dn(a), (b) => {
        a.h(b, { fromPABGSettings: !0 });
      }),
      () => {
        En(a);
      }
    );
  }
  function Bn(a) {
    if (U(mj)) var b = null;
    else
      try {
        b = a.getItem("google_ama_config");
      } catch (d) {
        b = null;
      }
    try {
      var c = b ? kl(b) : null;
    } catch (d) {
      c = null;
    }
    return (a = (a = c)
      ? (pm(C(a, Yk, 3)?.h()) ?? 0) > Date.now()
        ? a
        : null
      : null)
      ? $h(a)
      : bi(Error("invlocst"));
  }
  function Dn(a) {
    if (jn(a.l) && !I(a.U, 22)) return bi(Error("invtag"));
    if (
      (a = (a = nn(a.l, a.i, a.U)?.Y()) && D(a, Ai, 1).length > 0 ? a : null)
    ) {
      var b = new jl();
      var c = D(a, Ai, 1);
      b = Oc(b, 1, c);
      c = D(a, el, 2);
      b = Oc(b, 7, c);
      a = B(b, 36, Hb(I(a, 4)));
      a = $h(a);
    } else a = bi(Error("invtag"));
    return a;
  }
  function En(a) {
    var b = !!a.U.h()?.h();
    Pk({
      l: a.l,
      X: b,
      timeoutMs: 50,
      callback: (c) => {
        Fn(a, c);
      },
    });
  }
  function Fn(a, b) {
    fi(
      ei(b, (c) => {
        zn(a, c, !1);
      }),
      (c) => {
        Cn(c.message);
        a.h(null, null);
      }
    );
  }
  function Cn(a) {
    tk(
      "abg::amalserr",
      { status: a, guarding: "true", timeout: 50, rate: 0.01 },
      0.01
    );
  }
  class yn {
    constructor(a, b, c, d) {
      this.l = a;
      this.U = b;
      this.i = c;
      this.h = d;
    }
  }
  function Gn(a, b, c, d, e) {
    var f = Hn;
    try {
      let g = cn(a, D(c, el, 7));
      if (g && bn(g)) {
        H(g, 4) && (d = ri(d, new si(null, { google_package: H(g, 4) })));
        let h = f(a, b, c, g, d, e);
        b = () => {
          Oi(
            1e3,
            () => {
              var l = new Zh();
              new em(a, h, l).start();
              return l.i;
            },
            a
          ).then(
            () => {
              Ym(a, { atf: 1 });
            },
            (l) => {
              (a.google_ama_state = a.google_ama_state || {}).exception = l;
              Ym(a, { atf: 0 });
            }
          );
        };
        let k = U(kj) ? V(lj) : null;
        k != null ? setTimeout(b, k) : b();
      }
    } catch (g) {
      Ym(a, { atf: -1 });
    }
  }
  function Hn(a, b, c, d, e, f) {
    return new Yl(a, b, c, d, e, f);
  }
  function In() {
    var a = P(Ud).u(yj.h, yj.defaultValue);
    return a.length ? a.join("~") : void 0;
  }
  function Jn(a, b) {
    if (!a) return !1;
    a = a.hash;
    if (!a || !a.indexOf) return !1;
    if (a.indexOf(b) != -1) return !0;
    var c = "";
    for (let d of b.split("_")) c += d.substring(0, 2);
    b = c;
    return b != "go" && a.indexOf(b) != -1;
  }
  var Kn = { rectangle: 1, horizontal: 2, vertical: 4 };
  function Ln(a, b) {
    var c = ["width", "height"];
    for (let e = 0; e < c.length; e++) {
      let f = "google_ad_" + c[e];
      if (!b.hasOwnProperty(f)) {
        var d = Rd(a[c[e]]);
        d = d === null ? null : Math.round(d);
        d != null && (b[f] = d);
      }
    }
  }
  function Mn(a, b) {
    return !(
      (Pd.test(b.google_ad_width) || Od.test(a.style.width)) &&
      (Pd.test(b.google_ad_height) || Od.test(a.style.height))
    );
  }
  function Nn(a, b, c) {
    if ((c = Nd(a, c)))
      (a.style.width = c.width), (a.style.height = c.height), Ln(c, b);
    b.google_ad_width || (b.google_ad_width = a.offsetWidth);
    b.google_ad_height || (b.google_ad_height = a.offsetHeight);
  }
  function On(a, b, c, d, e) {
    if (a !== a.top) return md(a) ? 3 : 16;
    if (!(Nj(a) < 488)) return 4;
    if (!(a.innerHeight >= a.innerWidth)) return 5;
    var f = Nj(a);
    if (!f || (f - c) / f > d) a = 6;
    else {
      if ((c = e.google_full_width_responsive !== "true"))
        a: {
          c = b.parentElement;
          for (b = Nj(a); c; c = c.parentElement) {
            d = Nd(c, a);
            if (!d) continue;
            if ((e = Rd(d.width)) && !(e >= b) && d.overflow !== "visible") {
              c = !0;
              break a;
            }
          }
          c = !1;
        }
      a = c ? 7 : !0;
    }
    return a;
  }
  function Pn(a, b, c, d) {
    var e = On(b, c, a, V(ej), d);
    e !== !0
      ? (a = e)
      : d.google_full_width_responsive === "true" || Oj(c, b)
      ? ((b = Nj(b)),
        (a = b - a),
        (a = b && a >= 0 ? !0 : b ? (a < -10 ? 11 : a < 0 ? 14 : 12) : 10))
      : (a = 9);
    return a;
  }
  function Qn(a, b, c) {
    a = a.style;
    b === "rtl" ? (a.marginRight = c) : (a.marginLeft = c);
  }
  function Rn(a, b) {
    if (b.nodeType === 3) return /\S/.test(b.data);
    if (b.nodeType === 1) {
      if (/^(script|style)$/i.test(b.nodeName)) return !1;
      let c;
      try {
        c = Nd(b, a);
      } catch (d) {}
      return (
        !c ||
        (c.display !== "none" &&
          !(
            c.position === "absolute" &&
            (c.visibility === "hidden" || c.visibility === "collapse")
          ))
      );
    }
    return !1;
  }
  function Sn(a, b, c) {
    a = Qj(b, a);
    return c === "rtl" ? -a.x : a.x;
  }
  function Tn(a, b) {
    var c;
    c = (c = b.parentElement) ? ((c = Nd(c, a)) ? c.direction : "") : "";
    if (c) {
      var d = b.style;
      d.border =
        d.borderStyle =
        d.outline =
        d.outlineStyle =
        d.transition =
          "none";
      d.borderSpacing = d.padding = "0";
      Qn(b, c, "0px");
      d.width = `${Nj(a)}px`;
      if (Sn(a, b, c) !== 0) {
        Qn(b, c, "0px");
        var e = Sn(a, b, c);
        Qn(b, c, `${-1 * e}px`);
        a = Sn(a, b, c);
        a !== 0 && a !== e && Qn(b, c, `${(e / (a - e)) * e}px`);
      }
      d.zIndex = "30";
    }
  }
  function Un() {
    var a = {};
    P(Ud).h(fj.h, fj.defaultValue) && (a.bust = P(Ud).h(fj.h, fj.defaultValue));
    return a;
  }
  class Vn {
    constructor() {
      this.promise = new Promise((a, b) => {
        this.resolve = a;
        this.reject = b;
      });
    }
  }
  function Wn() {
    var { promise: a, resolve: b } = new Vn();
    return { promise: a, resolve: b };
  }
  function Xn(a = () => {}) {
    t.google_llp || (t.google_llp = {});
    var b = t.google_llp,
      c = b[7];
    if (c) return c;
    c = Wn();
    b[7] = c;
    a();
    return c;
  }
  function Yn(a) {
    return Xn(() => {
      Ld(t.document, a);
    }).promise;
  }
  var Zn = class {
    constructor() {
      this.u = this.C = 1;
      this.j = new Map();
      this.i = new Set();
      this.h = new Map();
      this.isDrawerVisible = !1;
    }
    takeNextPageEventIndex() {
      return this.C++;
    }
    takeNextAnnotationEntryId() {
      return this.u++;
    }
    getTermUsageCount(a) {
      return this.j.get(a) ?? 0;
    }
    incrementTermUsageCount(a) {
      var b = this.j.get(a) ?? 0;
      this.j.set(a, b + 1);
    }
    onDrawerCollapse(a) {
      this.i.add(a);
    }
    removeOnDrawerCollapse(a) {
      this.i.delete(a);
    }
    getClickPageEventIndex(a) {
      return this.h.get(a);
    }
    setClickPageEventIndex(a, b) {
      this.h.set(a, b);
    }
    removeClickPageEventIndex(a) {
      this.h.delete(a);
    }
    notifyDrawerCollapsed() {
      for (let a of this.i) a();
    }
  };
  function $n(a) {
    a.google_reactive_ads_global_state
      ? (a.google_reactive_ads_global_state.sideRailProcessedFixedElements ==
          null &&
          (a.google_reactive_ads_global_state.sideRailProcessedFixedElements =
            new Set()),
        a.google_reactive_ads_global_state.sideRailAvailableSpace == null &&
          (a.google_reactive_ads_global_state.sideRailAvailableSpace =
            new Map()),
        a.google_reactive_ads_global_state.sideRailPlasParam == null &&
          (a.google_reactive_ads_global_state.sideRailPlasParam = new Map()),
        a.google_reactive_ads_global_state.sideRailMutationCallbacks == null &&
          (a.google_reactive_ads_global_state.sideRailMutationCallbacks = []),
        a.google_reactive_ads_global_state.adIntentsPageState == null &&
          (a.google_reactive_ads_global_state.adIntentsPageState = new Zn()),
        a.google_reactive_ads_global_state.wasAutoRewardedContentGateShown ==
          null &&
          (a.google_reactive_ads_global_state.wasAutoRewardedContentGateShown =
            !1))
      : (a.google_reactive_ads_global_state = new ao());
    return a.google_reactive_ads_global_state;
  }
  var ao = class {
      constructor() {
        this.wasPlaTagProcessed = !1;
        this.wasReactiveAdConfigReceived = {};
        this.adCount = {};
        this.wasReactiveAdVisible = {};
        this.stateForType = {};
        this.reactiveTypeEnabledInAsfe = {};
        this.wasReactiveTagRequestSent = !1;
        this.reactiveTypeDisabledByPublisher = {};
        this.tagSpecificState = {};
        this.messageValidationEnabled = !1;
        this.floatingAdsStacking = new bo();
        this.sideRailProcessedFixedElements = new Set();
        this.sideRailAvailableSpace = new Map();
        this.sideRailPlasParam = new Map();
        this.sideRailMutationCallbacks = [];
        this.clickTriggeredInterstitialMayBeDisplayed = !1;
        this.adIntentsPageState = new Zn();
        this.wasAutoRewardedContentGateShown = !1;
      }
    },
    bo = class {
      constructor() {
        this.maxZIndexRestrictions = {};
        this.nextRestrictionId = 0;
        this.maxZIndexListeners = [];
      }
    };
  Array.from({ length: 11 }, (a, b) => b / 10);
  "youtube.com youtube-nocookie.com vimeo.com dailymotion.com twitch.tv kick.com rumble.com"
    .split(" ")
    .map((a) => `iframe[src*="${a}"]`);
  function co(a) {
    if (
      t.google_apltlad ||
      (!U(Aj) && a.google_ad_intent_query) ||
      a.google_ad_intents_format
    )
      return null;
    var b =
      a.google_loader_used !== "sd" &&
      (t.top == t ? 0 : ld(t.top) ? 1 : 2) === 1;
    if ((t !== t.top && !b) || !a.google_ad_client) return null;
    t.google_apltlad = !0;
    b = {
      enable_page_level_ads: { pltais: !0 },
      google_ad_client: a.google_ad_client,
    };
    var c = b.enable_page_level_ads;
    kd(a, (d, e) => {
      Uj[e] && e !== "google_ad_client" && (c[e] = d);
    });
    c.google_pgb_reactive = 7;
    c.asro = U(zj);
    c.aimartd = V(Bj);
    c.aiof = In();
    if ("google_ad_section" in a || "google_ad_region" in a)
      c.google_ad_section = a.google_ad_section || a.google_ad_region;
    return b;
  }
  function eo(a, b) {
    X(Q).ama_ran_on_page ||
      (!U(rj) || (a.enable_page_level_ads !== !1 && a.in_page_banner !== !1)
        ? Oi(
            1001,
            () => {
              fo(new go(a, b));
            },
            t
          )
        : (X(Q).ama_ran_on_page = !0));
  }
  function fo(a) {
    wn(a.l, a.U, a.h.google_ad_client || "", (b, c) => {
      var d = a.l,
        e = a.h,
        f = a.U;
      X(Q).ama_ran_on_page || (b && ho(d, e, b, c, f));
    });
  }
  class go {
    constructor(a, b) {
      this.l = t;
      this.h = a;
      this.U = b;
    }
  }
  function ho(a, b, c, d, e) {
    d && (Ti(a).configSourceInAbg = d);
    tc(c, 24) &&
      ((d = Ui(a)),
      (d.availableAbg = !0),
      (d.ablationFromStorage = !!C(c, il, 24)?.h()?.h()));
    if (
      ma(b.enable_page_level_ads) &&
      b.enable_page_level_ads.google_pgb_reactive === 7
    ) {
      if (!cn(a, D(c, el, 7))) {
        tk("amaait", { value: "true" });
        return;
      }
      tk("amaait", { value: "false" });
    }
    X(Q).ama_ran_on_page = !0;
    C(c, il, 24)?.h()?.h() && ((Ui(a).ablatingThisPageview = !0), fn(a));
    ne(3, [z(c)]);
    var f = b.google_ad_client || "";
    b = Zm(ma(b.enable_page_level_ads) ? b.enable_page_level_ads : {});
    var g = ri(vi, new si(null, b));
    qk(782, () => {
      Gn(a, f, c, g, e.h()?.h());
    });
  }
  var io = (function (a) {
    return (b) => {
      b = JSON.parse(b);
      if (!Array.isArray(b))
        throw Error(
          "Expected jspb data to be an array, got " + la(b) + ": " + b
        );
      b[v] |= 34;
      return new a(b);
    };
  })(class extends O {});
  async function jo(a, b) {
    try {
      let c = await globalThis.fetch(
        Jd(
          Id`https://pagead2.googlesyndication.com/getconfig/abg_config`,
          new Map([
            ["client", a],
            ["plah", b],
            ["ama_t", "adsense"],
            ...Object.entries(Un()),
          ])
        ).toString(),
        { method: "GET", credentials: "omit" }
      );
      if (!c.ok) throw Error(`Fetch failed with status: ${c.status}`);
      let d = await c.text();
      if (!d) throw Error("AbgConfig endpoint returned empty response.");
      try {
        return io(d);
      } catch (e) {
        throw Error(
          `Error deserializing config: ${
            e instanceof Error ? e.message : String(e)
          }`
        );
      }
    } catch (c) {
      throw c;
    }
  }
  var ko = class {
    constructor(a, b) {
      this.G = a;
      this.A = b;
    }
    h(a) {
      return a > 300 && this.A > 300 ? this.G : Math.min(1200, Math.round(a));
    }
  };
  var lo = class extends ko {
    i() {}
  };
  function mo(a) {
    return (b) => !!(b.F() & a);
  }
  var no = class extends lo {
    constructor(a, b, c, d = !1) {
      super(a, b);
      this.u = c;
      this.j = d;
    }
    F() {
      return this.u;
    }
    Ra() {
      return this.j;
    }
    i(a, b, c) {
      c.style.height = `${this.A}px`;
      b.rpe = !0;
    }
  };
  const oo = {
      image_stacked: 1 / 1.91,
      image_sidebyside: 1 / 3.82,
      mobile_banner_image_sidebyside: 1 / 3.82,
      pub_control_image_stacked: 1 / 1.91,
      pub_control_image_sidebyside: 1 / 3.82,
      pub_control_image_card_stacked: 1 / 1.91,
      pub_control_image_card_sidebyside: 1 / 3.74,
      pub_control_text: 0,
      pub_control_text_card: 0,
    },
    po = {
      image_stacked: 80,
      image_sidebyside: 0,
      mobile_banner_image_sidebyside: 0,
      pub_control_image_stacked: 80,
      pub_control_image_sidebyside: 0,
      pub_control_image_card_stacked: 85,
      pub_control_image_card_sidebyside: 0,
      pub_control_text: 80,
      pub_control_text_card: 80,
    };
  function qo(a) {
    return a >= 1200
      ? { width: 1200, height: 600 }
      : a >= 850
      ? { width: a, height: Math.floor(a * 0.5) }
      : a >= 550
      ? { width: a, height: Math.floor(a * 0.6) }
      : a >= 468
      ? { width: a, height: Math.floor(a * 0.7) }
      : { width: a, height: Math.floor(a * 3.44) };
  }
  function ro(a, b) {
    return a * oo[b] + po[b];
  }
  const so = Ma("script");
  var to = class {
    constructor(
      a,
      b,
      c = null,
      d = null,
      e = null,
      f = null,
      g = null,
      h = null,
      k = null,
      l = null,
      m = null,
      n = null
    ) {
      this.H = a;
      this.K = b;
      this.F = c;
      this.h = d;
      this.J = e;
      this.I = f;
      this.T = g;
      this.u = h;
      this.C = k;
      this.i = l;
      this.j = m;
      this.D = n;
    }
  };
  const uo = [
    "google_content_recommendation_ui_type",
    "google_content_recommendation_columns_num",
    "google_content_recommendation_rows_num",
  ];
  var vo = class extends lo {
    constructor(a, b) {
      super(a, b);
    }
    h(a) {
      return Math.min(1200, Math.max(this.G, Math.round(a)));
    }
  };
  function wo(a, b) {
    if (a <= 0)
      throw new W(
        `Invalid responsive width from Matched Content slot ${b.google_ad_slot}: ${a}. Please ensure to put this Matched Content slot into a non-zero width div container.`
      );
    if (U(Zi)) {
      var c = qd(),
        d = V($i);
      var e = V(Yi);
      var f = V(Xi);
      a < 468
        ? c
          ? ((f = a - 8 - 8),
            (e = d - 1),
            (e =
              Math.floor(f / 1.91 + 70) +
              Math.floor(
                ro(f, "mobile_banner_image_sidebyside") * e + 8 * e + 8
              )),
            (a = {
              Aa: a,
              A: e,
              ta: 1,
              ua: d,
              sa: "mobile_banner_image_sidebyside",
            }))
          : ((e = Math.floor(
              ro(a - 8 - 8, "image_sidebyside") * d + 8 * d + 8
            )),
            (a =
              a > 1500
                ? {
                    width: 0,
                    height: 0,
                    fc: `Calculated slot width is too large: ${a}`,
                  }
                : e > 1500
                ? {
                    width: 0,
                    height: 0,
                    fc: `Calculated slot height is too large: ${e}`,
                  }
                : { width: a, height: e }),
            (a = {
              Aa: a.width,
              A: a.height,
              ta: 1,
              ua: d,
              sa: "image_sidebyside",
            }))
        : ((a = qo(a)),
          e === 1 && (a.height = Math.floor(a.height * 0.5)),
          (a = {
            Aa: a.width,
            A: a.height,
            ta: f,
            ua: e,
            sa: "image_stacked",
          }));
    } else
      (d = qo(a)),
        (e = 4),
        (f = 2),
        a < 468 &&
          ((e = 1),
          (f = 6),
          (d = {
            width: a,
            height: Math.floor(ro(a, "image_stacked") * f + 8 * f + 8),
          })),
        (a = { Aa: d.width, A: d.height, ta: e, ua: f, sa: "image_stacked" });
    b.google_content_recommendation_ui_type = a.sa;
    b.google_content_recommendation_columns_num = a.ta;
    b.google_content_recommendation_rows_num = a.ua;
    return new to(9, new vo(a.Aa, a.A));
  }
  var xo = class extends lo {
    constructor(a, b) {
      super(a, b);
    }
    h() {
      return this.G;
    }
    i(a, b, c) {
      Tn(a, c);
      c.style.height = `${this.A}px`;
      b.rpe = !0;
    }
  };
  const yo = {
    "image-top": (a) => (a <= 600 ? 284 + (a - 250) * 0.414 : 429),
    "image-middle": (a) =>
      a <= 500 ? 196 - (a - 250) * 0.13 : 164 + (a - 500) * 0.2,
    "image-side": (a) =>
      a <= 500 ? 205 - (a - 250) * 0.28 : 134 + (a - 500) * 0.21,
    "text-only": (a) => (a <= 500 ? 187 - 0.228 * (a - 250) : 130),
    "in-article": (a) =>
      a <= 420 ? a / 1.2 : a <= 460 ? a / 1.91 + 130 : a <= 800 ? a / 4 : 200,
  };
  var zo = class extends lo {
    constructor(a, b) {
      super(a, b);
    }
    h() {
      return Math.min(1200, this.G);
    }
  };
  function Ao(a, b, c, d, e) {
    var f = e.google_ad_layout || "image-top";
    if (f === "in-article") {
      var g = a;
      if (e.google_full_width_responsive === "false") a = g;
      else if (((a = On(b, c, g, V(cj), e)), a !== !0))
        (e.gfwrnwer = a), (a = g);
      else if ((a = Nj(b)))
        if (((e.google_full_width_responsive_allowed = !0), c.parentElement)) {
          b: {
            g = c;
            for (let h = 0; h < 100 && g.parentElement; ++h) {
              let k = g.parentElement.childNodes;
              for (let l = 0; l < k.length; ++l) {
                let m = k[l];
                if (m !== g && Rn(b, m)) break b;
              }
              g = g.parentElement;
              g.style.width = "100%";
              g.style.height = "auto";
            }
          }
          Tn(b, c);
        } else a = g;
      else a = g;
    }
    if (a < 250)
      throw new W(
        `Fluid responsive ads must be at least 250px wide: availableWidth=${a}`
      );
    a = Math.min(1200, Math.floor(a));
    if (d && f !== "in-article") {
      f = Math.ceil(d);
      if (f < 50)
        throw new W(
          `Fluid responsive ads must be at least 50px tall: height=${f}`
        );
      return new to(11, new lo(a, f));
    }
    if (f !== "in-article" && (d = e.google_ad_layout_key)) {
      f = `${d}`;
      if ((d = (c = f.match(/([+-][0-9a-z]+)/g)) && c.length))
        for (b = [], e = 0; e < d; e++) b.push(parseInt(c[e], 36) / 1e3);
      else b = null;
      if (!b) throw new W(`Invalid data-ad-layout-key value: ${f}`);
      f = (a + -725) / 1e3;
      c = 0;
      d = 1;
      e = b.length;
      for (g = 0; g < e; g++) (c += b[g] * d), (d *= f);
      f = Math.ceil(c * 1e3 - -725 + 10);
      if (isNaN(f)) throw new W(`Invalid height: height=${f}`);
      if (f < 50)
        throw new W(
          `Fluid responsive ads must be at least 50px tall: height=${f}`
        );
      if (f > 1200)
        throw new W(
          `Fluid responsive ads must be at most 1200px tall: height=${f}`
        );
      return new to(11, new lo(a, f));
    }
    d = yo[f];
    if (!d) throw new W("Invalid data-ad-layout value: " + f);
    c = Rj(c, b) < Mj(b).clientHeight - 100;
    b = Nj(b);
    b =
      f !== "in-article" || c || a !== b
        ? Math.ceil(d(a))
        : Math.ceil(d(a) * 1.25);
    return new to(11, f === "in-article" ? new zo(a, b) : new lo(a, b));
  }
  var Bo = [
      { G: 970, A: 90, F: 2 },
      { G: 728, A: 90, F: 2 },
      { G: 468, A: 60, F: 2 },
      { G: 336, A: 280, F: 1 },
      { G: 320, A: 100, F: 2 },
      { G: 320, A: 50, F: 2 },
      { G: 300, A: 600, F: 4 },
      { G: 300, A: 250, F: 1 },
      { G: 250, A: 250, F: 1 },
      { G: 234, A: 60, F: 2 },
      { G: 200, A: 200, F: 1 },
      { G: 180, A: 150, F: 1 },
      { G: 160, A: 600, F: 4 },
      { G: 125, A: 125, F: 1 },
      { G: 120, A: 600, F: 4 },
      { G: 120, A: 240, F: 4 },
      { G: 120, A: 120, F: 1, Ra: !0 },
    ].map((a) => new no(a.G, a.A, a.F, a.Ra ?? !1)),
    Co = [6, 12, 3, 0, 7, 14, 1, 8, 10, 4, 15, 2, 11, 5, 13, 9, 16].map(
      (a) => Bo[a]
    );
  function Do(a) {
    return (b) => b.G <= a;
  }
  function Eo(a) {
    return (b) => b.A <= a;
  }
  function Fo(a) {
    return (b) => {
      for (let c = a.length - 1; c >= 0; --c) if (!a[c](b)) return !1;
      return !0;
    };
  }
  function Go(a, b) {
    var c = Co.length,
      d = null;
    for (let e = 0; e < c; ++e) {
      let f = Co[e];
      if (a(f)) {
        if (b == null || b(f)) return f;
        d === null && (d = f);
      }
    }
    return d;
  }
  function Ho(a, b, c, d, e) {
    e.google_full_width_responsive === "false"
      ? (c = { L: a, I: 1 })
      : (b === "autorelaxed" && e.google_full_width_responsive) ||
        Io(b) ||
        e.google_ad_resize
      ? ((b = Pn(a, c, d, e)),
        (c = b !== !0 ? { L: a, I: b } : { L: Nj(c) || a, I: !0 }))
      : (c = { L: a, I: 2 });
    var { L: f, I: g } = c;
    return g !== !0
      ? { L: a, I: g }
      : d.parentElement
      ? { L: f, I: g }
      : { L: a, I: g };
  }
  function Jo(a, b, c, d, e) {
    var { L: f, I: g } = qk(247, () => Ho(a, b, c, d, e)),
      h = g === !0,
      k = Rd(d.style.width),
      l = Rd(d.style.height),
      { K: m, T: n, F: p, wb: r } = Ko(f, b, c, d, e, h);
    h = Lo(b, p);
    var q,
      w = (q = Pj(d, c, "marginLeft")) ? `${q}px` : "",
      G = (q = Pj(d, c, "marginRight")) ? `${q}px` : "";
    q = Tj(d, c) || "";
    return new to(h, m, p, null, r, g, n, w, G, l, k, q);
  }
  function Io(a) {
    return (
      a === "auto" || /^((^|,) *(horizontal|vertical|rectangle) *)+$/.test(a)
    );
  }
  function Ko(a, b, c, d, e, f) {
    b = Mo(c, a, b);
    var g = Nj(c) < 488 ? Oj(d, c) : void 0,
      h = [Do(a), mo(b)];
    e.google_max_responsive_height != null &&
      h.push(Eo(e.google_max_responsive_height));
    var k = [(p) => !p.Ra()];
    if (g) {
      let p = Sj(c, d);
      k.push(Eo(p));
    }
    var l = Go(Fo(h), Fo(k));
    if (!l) throw new W(`No slot size for availableWidth=${a}`);
    var { K: m, T: n } = qk(248, () => {
      var p;
      a: if (f) {
        if (e.gfwrnh && (p = Rd(e.gfwrnh))) {
          p = { K: new xo(a, p), T: !0 };
          break a;
        }
        if (
          e.google_resizing_allowed ||
          e.google_full_width_responsive === "true"
        )
          p = Infinity;
        else {
          p = d;
          let q = Infinity;
          do {
            var r = Pj(p, c, "height");
            r && (q = Math.min(q, r));
            (r = Pj(p, c, "maxHeight")) && (q = Math.min(q, r));
          } while (
            p.parentElement &&
            (p = p.parentElement) &&
            p.tagName !== "HTML"
          );
          p = q;
        }
        p = Math.min(a, p);
        if (p < a * 0.5 || p < 100) p = a;
        p = { K: new xo(a, Math.floor(p)), T: p < a ? 102 : !0 };
      } else p = { K: l, T: 100 };
      return p;
    });
    return e.google_ad_layout === "in-article"
      ? { K: No(a, c, d, m, e), T: !1, F: b, wb: g }
      : { K: m, T: n, F: b, wb: g };
  }
  function Lo(a, b) {
    if (a === "auto") return 1;
    switch (b) {
      case 2:
        return 2;
      case 1:
        return 3;
      case 4:
        return 4;
      case 3:
        return 5;
      case 6:
        return 6;
      case 5:
        return 7;
      case 7:
        return 8;
      default:
        throw Error("bad mask");
    }
  }
  function Mo(a, b, c) {
    if (c === "auto") (c = Math.min(1200, Nj(a))), (b = b / c <= 0.25 ? 4 : 3);
    else {
      b = 0;
      for (let d in Kn) c.indexOf(d) !== -1 && (b |= Kn[d]);
    }
    return b;
  }
  function No(a, b, c, d, e) {
    var f = e.google_ad_height || Pj(c, b, "height");
    b = Ao(a, b, c, f, e).K;
    return b.G * b.A > a * d.A ? new no(b.G, b.A, 1) : d;
  }
  function Oo(a) {
    if (a === a.top) return 0;
    for (; a && a !== a.top && ld(a); a = a.parent) {
      let b = a;
      if (b.sf_) return 2;
      if (b.$sf) return 3;
      if (b.inGptIF) return 4;
      if (b.inDapIF) return 5;
    }
    return 1;
  }
  function Po(a, b, c) {
    for (let f of b)
      a: {
        b = a;
        var d = f,
          e = c;
        for (let g = 0; g < b.h.length; g++) {
          if (b.h[g].element.contains(d)) {
            b.h[g].labels.add(e);
            break a;
          }
          if (d.contains(b.h[g].element)) {
            b.h[g].element = d;
            b.h[g].labels.add(e);
            break a;
          }
        }
        b.h.push({ element: d, labels: new Set([e]) });
      }
  }
  class Qo {
    constructor() {
      this.h = [];
    }
    getSlots() {
      return this.h;
    }
  }
  function Ro(a) {
    var b = Il(a),
      c = new Qo();
    Po(c, b.Gb, 1);
    Po(c, b.Hb, 2);
    Po(c, b.Mb, 3);
    Po(c, b.lc, 4);
    Po(c, b.Ib, 5);
    Po(c, b.Yb, 6);
    return c
      .getSlots()
      .map((d) => {
        var e = new xf();
        var f = [...d.labels];
        e = Bc(e, 1, f, Kb);
        d = d.element.getBoundingClientRect();
        f = new wf();
        f = Vc(f, 1, d.left + a.scrollX);
        f = Vc(f, 2, d.top + a.scrollY);
        f = Vc(f, 3, d.width);
        d = Vc(f, 4, d.height);
        d = kc(d);
        e = E(e, 2, d);
        return kc(e);
      })
      .sort((d, e) => {
        d = C(d, wf, 2);
        d = J(d, 2);
        e = C(e, wf, 2);
        e = J(e, 2);
        return d - e;
      });
  }
  function So(a) {
    return a.google_ad_client
      ? String(a.google_ad_client)
      : X(a).head_tag_slot_vars?.google_ad_client ??
          a.document
            .querySelector(".adsbygoogle[data-ad-client]")
            ?.getAttribute("data-ad-client") ??
          "";
  }
  function ch(a, b, c = 0) {
    To(a);
    c = Math.min(Math.max(0, c), 9);
    var d = a.h.get(c);
    d ? d.push(b) : a.h.set(c, [b]);
  }
  function Uo(a, b, c, d) {
    ee(b, c, d);
    Ik(a, () => fe(b, c, d));
  }
  function Vo(a, b) {
    a.state !== 1 && ((a.state = 1), a.h.size > 0 && Wo(a, b));
  }
  function To(a) {
    a.j ||
      ((a.j = !0),
      a.l.document.visibilityState
        ? Uo(a, a.l.document, "visibilitychange", (b) => {
            a.l.document.visibilityState === "hidden" && Vo(a, b);
            a.l.document.visibilityState === "visible" && (a.state = 0);
          })
        : "onpagehide" in a.l
        ? (Uo(a, a.l, "pagehide", (b) => {
            Vo(a, b);
          }),
          Uo(a, a.l, "pageshow", () => {
            a.state = 0;
          }))
        : Uo(a, a.l, "beforeunload", (b) => {
            Vo(a, b);
          }));
  }
  function Wo(a, b) {
    for (let c = 9; c >= 0; c--)
      a.h
        .get(c)
        ?.slice()
        .forEach((d) => void d(b));
  }
  var Xo = class extends Hk {
    constructor(a) {
      super();
      this.l = a;
      this.j = !1;
      this.state = 0;
      this.h = new Map();
    }
  };
  async function Yo(a, b) {
    var c = 10;
    return c <= 0
      ? Promise.reject(Error(`wfc bad input ${c} 200`))
      : b()
      ? Promise.resolve()
      : new Promise((d, e) => {
          var f = a.setInterval(() => {
            --c
              ? b() && (a.clearInterval(f), d())
              : (a.clearInterval(f), e(Error(`wfc timed out ${c}`)));
          }, 200);
        });
  }
  function Zo(a) {
    var b = a.state.pc;
    return b !== null && b !== 0 ? b : (a.state.pc = Wd(a.l));
  }
  function $o(a) {
    var b = a.state.wpc;
    return b !== null && b !== "" ? b : (a.state.wpc = So(a.l));
  }
  function ap(a, b) {
    var c = new Rf();
    var d = Zo(a);
    c = Wc(c, 1, d);
    d = $o(a);
    c = ad(c, 2, d);
    c = Wc(c, 3, a.state.sd);
    return Wc(c, 7, Math.round(b || a.l.performance.now()));
  }
  async function bp(a) {
    try {
      return await Yo(a.l, () => !(!Zo(a) || !$o(a))), !0;
    } catch (b) {
      return !1;
    }
  }
  function cp(a, b) {
    if (a.h) {
      var c = a.u;
      b(c);
      a.state.psi = z(c);
    }
  }
  function dp(a) {
    var b = P(ep);
    if (b.h) {
      var c = b.j;
      a(c);
      b.state.gmi = z(c);
    }
  }
  function fp(a) {
    ch(
      a.i,
      () => {
        var b = ap(a);
        b = F(b, 12, Sf, a.C);
        a.h && !a.state.le.includes(3) && (a.state.le.push(3), Vg(a.pinger, b));
      },
      9
    );
  }
  function gp(a) {
    var b = new Of();
    ch(
      a.i,
      () => {
        E(b, 2, a.u);
        a.state.gmi?.length && E(b, 5, a.j);
        Wc(b, 3, a.state.tar);
        var c = a.l;
        var d = new Bf();
        var e = Ro(c);
        d = Oc(d, 1, e);
        e = ed(zf(yf(new Af(), Nj(c)), Mj(c).clientHeight));
        d = E(d, 2, e);
        c = ed(zf(yf(new Af(), Mj(c).scrollWidth), Mj(c).scrollHeight));
        c = E(d, 3, c);
        c = kc(c);
        E(b, 4, c);
        c = a.pinger;
        d = ap(a);
        d = F(d, 8, Sf, b);
        Vg(c, d);
      },
      9
    );
  }
  async function hp(a) {
    var b = P(ep);
    if (b.h && !b.state.le.includes(1)) {
      b.state.le.push(1);
      var c = b.l.performance.now();
      if (await bp(b)) {
        var d = new Jf();
        a = Cc(d, 5, Hb(a), !1);
        d = zf(yf(new Af(), Mj(b.l).scrollWidth), Mj(b.l).scrollHeight);
        a = E(a, 2, d);
        d = zf(yf(new Af(), Nj(b.l)), Mj(b.l).clientHeight);
        a = E(a, 1, d);
        d = nd(b.l).location.href;
        a = ad(a, 4, d);
        d = Oo(b.l);
        if (d !== 0) {
          var e = new If();
          d = bd(e, 1, d);
          E(a, 3, d);
        }
        d = b.pinger;
        c = ap(b, c);
        c = F(c, 4, Sf, a);
        Vg(d, c);
        fp(b);
        gp(b);
      }
    }
  }
  async function ip(a, b, c) {
    if (a.h && c.length && !a.state.lgdp.includes(Number(b))) {
      a.state.lgdp.push(Number(b));
      var d = a.l.performance.now();
      if (await bp(a)) {
        var e = a.pinger;
        a = ap(a, d);
        d = new Hf();
        b = cd(d, 1, b);
        c = Bc(b, 2, c, Lb);
        c = F(a, 9, Sf, c);
        Vg(e, c);
      }
    }
  }
  async function jp(a, b) {
    if (await bp(a)) {
      var c = a.pinger;
      a = ap(a);
      a = Wc(a, 3, 1);
      b = F(a, 10, Sf, b);
      Vg(c, b);
    }
  }
  async function kp(a, b) {
    if (await bp(a)) {
      var c = a.pinger;
      a = ap(a);
      a = Wc(a, 3, 1);
      b = F(a, 18, Sf, b);
      Vg(c, b);
    }
  }
  var ep = class {
    constructor(a, b) {
      this.l = Qh() || window;
      this.i = b ?? new Xo(this.l);
      this.pinger = a ?? new eh(2, qg(), 100, 100, !0, this.i, Kh);
      this.state = Ck(xk(), 33, () => {
        var c = V(bj);
        return {
          sd: c,
          ssp: c > 0 && Dd() < 1 / c,
          pc: null,
          wpc: null,
          cu: null,
          le: [],
          lgdp: [],
          psi: null,
          tar: 0,
          cc: null,
          gmi: null,
        };
      });
    }
    get h() {
      return this.state.ssp;
    }
    get u() {
      return qk(1178, () => fd(Nf, ac(this.state.psi || []))) || new Nf();
    }
    get j() {
      return fd(Kf, ac(this.state.gmi || []));
    }
    get C() {
      return qk(1227, () => fd(Qf, ac(this.state.cc || []))) || new Qf();
    }
  };
  function lp(a, b) {
    dp((c) => {
      b(c, (a(c) || 0) + 1);
    });
  }
  function mp() {
    lp(
      (a) => J(a, 4),
      (a, b) => {
        M(a, 4, b);
      }
    );
  }
  function np() {
    lp(
      (a) => J(a, 5),
      (a, b) => {
        M(a, 5, b);
      }
    );
  }
  function op() {
    lp(
      (a) => J(a, 2),
      (a, b) => {
        M(a, 2, b);
      }
    );
  }
  function pp() {
    lp(
      (a) => J(a, 3),
      (a, b) => {
        M(a, 3, b);
      }
    );
  }
  function qp() {
    lp(
      (a) => J(a, 6),
      (a, b) => {
        M(a, 6, b);
      }
    );
  }
  function rp() {
    lp(
      (a) => J(a, 1),
      (a, b) => {
        M(a, 1, b);
      }
    );
  }
  function sp() {
    lp(
      (a) => J(a, 8),
      (a, b) => {
        M(a, 8, b);
      }
    );
  }
  function tp() {
    lp(
      (a) => J(a, 9),
      (a, b) => {
        M(a, 9, b);
      }
    );
  }
  function up() {
    lp(
      (a) => J(a, 10),
      (a, b) => {
        M(a, 10, b);
      }
    );
  }
  function vp() {
    lp(
      (a) => J(a, 7),
      (a, b) => {
        M(a, 7, b);
      }
    );
  }
  function wp(a, b, c, d, e) {
    var f;
    (f = Nj(b))
      ? Nj(b) < 488
        ? b.innerHeight >= b.innerWidth
          ? ((e.google_full_width_responsive_allowed = !0),
            Tn(b, c),
            (f = { L: f, I: !0 }))
          : (f = { L: a, I: 5 })
        : (f = { L: a, I: 4 })
      : (f = { L: a, I: 10 });
    var { L: g, I: h } = f;
    if (h !== !0 || a === g)
      return new to(12, new lo(a, d), null, null, !0, h, 100);
    var { K: k, T: l, F: m } = Ko(g, "auto", b, c, e, !0);
    return new to(1, k, m, 2, !0, h, l);
  }
  function xp(a) {
    var b = a.google_ad_format;
    if (b === "autorelaxed") {
      a: {
        if (a.google_content_recommendation_ui_type !== "pedestal")
          for (let c of uo)
            if (a[c] != null) {
              a = !0;
              break a;
            }
        a = !1;
      }
      return a ? 9 : 5;
    }
    if (Io(b)) return 1;
    if (b === "link") return 4;
    if (b === "fluid")
      return a.google_ad_layout === "in-article" ? (yp(a), 1) : 8;
    if (a.google_reactive_ad_format === 27) return yp(a), 1;
  }
  function zp(a, b, c, d, e = !1) {
    var f =
      b.offsetWidth ||
      ((c.google_ad_resize || e) && Pj(b, d, "width")) ||
      c.google_ad_width ||
      0;
    a === 4 && ((c.google_ad_format = "auto"), (a = 1));
    e = (e = Ap(a, f, b, c, d)) ? e : Jo(f, c.google_ad_format, d, b, c);
    e.K.i(d, c, b);
    e.F != null && (c.google_responsive_formats = e.F);
    e.J != null && (c.google_safe_for_responsive_override = e.J);
    e.I != null &&
      (e.I === !0
        ? (c.google_full_width_responsive_allowed = !0)
        : ((c.google_full_width_responsive_allowed = !1), (c.gfwrnwer = e.I)));
    e.T != null && e.T !== !0 && (c.gfwrnher = e.T);
    d = e.j || c.google_ad_width;
    d != null && (c.google_resizing_width = d);
    d = e.i || c.google_ad_height;
    d != null && (c.google_resizing_height = d);
    d = e.K.h(f);
    var g = e.K.A;
    c.google_ad_width = d;
    c.google_ad_height = g;
    var h = e.K;
    c.google_ad_format = `${h.h(f)}x${h.A}`;
    c.google_responsive_auto_format = e.H;
    e.h != null && (c.armr = e.h);
    c.google_ad_resizable = !0;
    c.google_override_format = 1;
    c.google_loader_features_used = 128;
    e.I === !0 && (c.gfwrnh = `${e.K.A}px`);
    e.u != null && (c.gfwroml = e.u);
    e.C != null && (c.gfwromr = e.C);
    e.i != null && (c.gfwroh = e.i);
    e.j != null && (c.gfwrow = e.j);
    e.D != null && (c.gfwroz = e.D);
    f = md(window) || window;
    Jn(f.location, "google_responsive_dummy_ad") &&
      (Ka([1, 2, 3, 4, 5, 6, 7, 8], e.H) || e.h === 1) &&
      e.h !== 2 &&
      ((f = JSON.stringify({
        googMsgType: "adpnt",
        key_value: [{ key: "qid", value: "DUMMY_AD" }],
      })),
      (c.dash = `<${so}>window.top.postMessage('${f}', '*'); 
          </${so}> 
          <div id="dummyAd" style="width:${d}px;height:${g}px; 
            background:#ddd;border:3px solid #f00;box-sizing:border-box; 
            color:#000;"> 
            <p>Requested size:${d}x${g}</p> 
            <p>Rendered size:${d}x${g}</p> 
          </div>`));
    a !== 1 && (b.style.height = `${e.K.A}px`);
  }
  function Ap(a, b, c, d, e) {
    var f = d.google_ad_height || Pj(c, e, "height") || 0;
    switch (a) {
      case 5:
        let { L: g, I: h } = qk(247, () => Ho(b, d.google_ad_format, e, c, d));
        h === !0 && b !== g && Tn(e, c);
        h === !0
          ? (d.google_full_width_responsive_allowed = !0)
          : ((d.google_full_width_responsive_allowed = !1), (d.gfwrnwer = h));
        return wo(g, d);
      case 9:
        return wo(b, d);
      case 8:
        return Ao(b, e, c, f, d);
      case 10:
        return wp(b, e, c, f, d);
    }
  }
  function yp(a) {
    a.google_ad_format = "auto";
    a.armr = 3;
  }
  function Bp(a, b) {
    a.google_resizing_allowed = !0;
    a.google_ad_format = "auto";
    a.iaaso = !0;
    a.armr = b;
  }
  function Cp(a, b, c, d) {
    if (U(aj) || Nj(c) < 488) {
      var e = md(c) || c,
        f = a.offsetWidth || Pj(a, c, "width") || b.google_ad_width || 0,
        g = b.google_ad_client;
      if (
        (d = Jn(e.location, "google_responsive_slot_preview") || mn(e, 1, d, g))
      )
        a: if (
          b.google_reactive_ad_format ||
          b.google_ad_resize ||
          xp(b) ||
          Mn(a, b)
        )
          d = !1;
        else {
          for (d = a; d; d = d.parentElement) {
            e = Nd(d, c);
            if (!e) {
              b.gfwrnwer = 18;
              d = !1;
              break a;
            }
            if (!Ka(["static", "relative"], e.position)) {
              b.gfwrnwer = 17;
              d = !1;
              break a;
            }
          }
          if (!U(jj) && ((d = V(dj)), (a = On(c, a, f, d, b)), a !== !0)) {
            b.gfwrnwer = a;
            d = !1;
            break a;
          }
          d = c === c.top;
        }
      d && Bp(b, 1);
    }
  }
  var Dp = {
    "120x90": !0,
    "160x90": !0,
    "180x90": !0,
    "200x90": !0,
    "468x15": !0,
    "728x15": !0,
  };
  function Ep(a, b) {
    if (b == 15) {
      if (a >= 728) return 728;
      if (a >= 468) return 468;
    } else if (b == 90) {
      if (a >= 200) return 200;
      if (a >= 180) return 180;
      if (a >= 160) return 160;
      if (a >= 120) return 120;
    }
    return null;
  }
  function Fp(a, b) {
    var c = md(b);
    if (c) {
      c = Nj(c);
      let d = Nd(a, b) || {},
        e = d.direction;
      if (d.width === "0px" && d.cssFloat !== "none") return -1;
      if (e === "ltr" && c)
        return Math.floor(Math.min(1200, c - a.getBoundingClientRect().left));
      if (e === "rtl" && c)
        return (
          (a =
            b.document.body.getBoundingClientRect().right -
            a.getBoundingClientRect().right),
          Math.floor(
            Math.min(
              1200,
              c - a - Math.floor((c - b.document.body.clientWidth) / 2)
            )
          )
        );
    }
    return -1;
  }
  function Gp(a, b, c) {
    if (
      c.document &&
      c.document.body &&
      !xp(b) &&
      !b.google_reactive_ad_format &&
      (U(Aj) ? !b.google_ad_intents_format : !b.google_ad_intent_query)
    ) {
      var d = parseInt(a.style.width, 10),
        e = Fp(a, c);
      if (e > 0 && d > e) {
        c = parseInt(a.style.height, 10);
        d = !!Dp[d + "x" + c];
        let f = e;
        if (d) {
          let g = Ep(e, c);
          if (g) (f = g), (b.google_ad_format = g + "x" + c + "_0ads_al");
          else throw new W("No slot size for availableWidth=" + e);
        }
        b.google_ad_resize = !0;
        b.google_ad_width = f;
        d || ((b.google_ad_format = null), (b.google_override_format = !0));
        e = f;
        a.style.width = `${e}px`;
        Bp(b, 4);
      }
    }
  }
  function Hp(a, b) {
    switch (a) {
      case "google_reactive_ad_format":
        return (a = parseInt(b, 10)), isNaN(a) ? 0 : a;
      default:
        return b;
    }
  }
  function Ip(a, b) {
    if (a.getAttribute("src")) {
      var c = a.getAttribute("src") || "",
        d = Qe(c, "client");
      d && (b.google_ad_client = Hp("google_ad_client", d));
      (c = Qe(c, "host")) && (b.google_ad_host = Hp("google_ad_host", c));
    }
    c = !1;
    for (let e of a.attributes)
      /data-/.test(e.name) &&
        (((a = wa(
          e.name
            .replace("data-matched-content", "google_content_recommendation")
            .replace("data", "google")
            .replace(/-/g, "_")
        )),
        (e.name !== "data-tag-for-child-directed-treatment" &&
          e.name !== "data-tag-for-under-age-of-consent") ||
          e.value !== "1")
          ? b.hasOwnProperty(a) ||
            ((d = Hp(a, e.value)), d !== null && (b[a] = d))
          : (console.warn(
              `${e.name} is deprecated. Use data-tag-for-age-treatment="1" instead.`
            ),
            (c = !0)));
    c && (b.google_tag_for_age_treatment = 1);
  }
  function Jp(a, b) {
    if ((a = Ph(a)))
      switch (a.data && a.data.autoFormat) {
        case "rspv":
          return 13;
        case "mcrspv":
          return 15;
        default:
          return 14;
      }
    else {
      if (b.google_ad_intents_format)
        a: switch (Number(b.google_ad_intents_format)) {
          case 4:
            b = 20;
            break a;
          default:
            b = 19;
        }
      else b = 12;
      return b;
    }
  }
  function Kp(a, b, c) {
    var d = !!b.iaaso,
      e = xp(b);
    e
      ? zp(e, a, b, c, d)
      : (c.location && c.location.hash === "#gfwmrp") ||
        (b.google_responsive_auto_format === 12 &&
          b.google_full_width_responsive === "true")
      ? zp(10, a, b, c, !1)
      : Math.random() < 0.01 &&
        b.google_responsive_auto_format === 12 &&
        ((a = Pn(
          a.offsetWidth || parseInt(a.style.width, 10) || b.google_ad_width,
          c,
          a,
          b
        )),
        a !== !0 ? ((b.efwr = !1), (b.gfwrnwer = a)) : (b.efwr = !0));
  }
  function Lp(a) {
    return Z(a)?.j()?.j();
  }
  function Mp(a) {
    a.googletag = a.googletag || {};
    a.googletag.cmd = a.googletag.cmd || [];
  }
  let Np = !1;
  function Op(a, b, c) {
    if (!Np) {
      Np = !0;
      a.google_adsense_migrated = !0;
      Mp(a);
      a.googletag.cmd.push(() => {
        {
          var f = V(hj);
          let g = V(ij);
          f =
            g <= 0
              ? void 0
              : {
                  fetchMarginPercent: g * 100,
                  renderMarginPercent: null,
                  mobileScaling: f / g,
                };
        }
        f && a.googletag.setConfig({ lazyLoad: f });
      });
      var d = a.document,
        e = xd(b.tb).toString();
      d.querySelector(`script[src*="/tag/js/gpt.js"], script[src="${e}"]`) ||
        ((b = b.tb),
        U(qj) && (b = Jd(b, new Map([["network-code", c]]))),
        (c = d.currentScript?.getAttribute?.("fetchpriority") ?? "high"),
        Ld(d, b, c));
    }
  }
  function Pp(a, b, c) {
    var d = Z(b);
    if (!d) return 0;
    if (!vn(a, Sh(c), b)) return mp(), 0;
    c = d.j();
    if (!c) return 0;
    c = c.h();
    return Lp(b)
      ? Jn(a.location, "google_force_gam")
        ? 2
        : c === 1
        ? 1
        : c === 2
        ? 2
        : 0
      : (np(), 0);
  }
  function Qp(a, b) {
    var c = b.id;
    if (!c) {
      a = a.document;
      c = void 0;
      let d = 1;
      for (; !c || a.getElementById(c); ) c = `adsbygoogle-gpt-slot-${d++}`;
      b.id = c;
    }
    return c;
  }
  function Rp(a) {
    return Number(a.google_reactive_ad_format) > 0;
  }
  function Sp(a, b) {
    return Rp(b)
      ? `/${a}/adsense_migrated_auto_ads`
      : (b = b.google_ad_slot)
      ? `/${a}/adsense_migrated_manual_ads/${b}`
      : `/${a}/adsense_migrated_manual_ads`;
  }
  function Tp(a) {
    var b = Number(a.google_ad_width);
    var c = Number(a.google_ad_height);
    b = b && c ? [b, c] : void 0;
    c = Rp(a);
    c ||
      b ||
      ((a = a.google_ad_format),
      a === "fluid"
        ? sp()
        : a !== "auto" && Io(a || "")
        ? vp()
        : a === "autorelaxed"
        ? tp()
        : a || up());
    return c || !b ? "auto" : b;
  }
  function Up(a) {
    return a === !0 || a === "true" || a === "1" || a === 1;
  }
  function Vp(a) {
    var b = {};
    var c = xk();
    c = Dk(c, 26);
    c !== void 0 && (b.nonPersonalizedAds = c);
    c = a.google_restrict_data_processing;
    c !== void 0 && (b.restrictDataProcessing = Up(c));
    c = a.google_tag_for_child_directed_treatment;
    a = a.google_tag_for_age_treatment;
    if (c === 1 || c === "1" || a === 1) b.tagForAgeTreatment = 1;
    if (Object.keys(b).length > 0) return b;
  }
  function Wp(a) {
    a = a.google_full_width_responsive;
    if (a !== void 0 && !Up(a)) return { enabled: !1 };
  }
  function Xp(a, b) {
    Nd(b, a)?.display === "inline" && (b.style.display = "block");
    b.style.height = "";
  }
  function Yp(a, b, c, d) {
    b.classList.add("adsbygoogle-noablate");
    var e = Qp(a, b),
      f = Sp(c, d),
      g = Tp(d);
    U(uj) && g === "auto" && Xp(a, b);
    var h = Vp(d),
      k = Wp(d);
    Mp(a);
    a.googletag.cmd.push(() => {
      var l = a.googletag.defineSlot(f, g, e);
      l &&
        (l.addService(a.googletag.pubads()),
        h && a.googletag.pubads().setPrivacySettings(h),
        k && l.setConfig({ adExpansion: k }),
        a.googletag.pubadsReady || a.googletag.enableServices(),
        a.googletag.display(e));
    });
  }
  function Zp(a, b) {
    var c = a.google_ad_channel;
    a.google_ad_channel = c ? c + "+" + b : b;
  }
  function $p(a, b, c) {
    b === 1
      ? c && Zp(a, "GamMigrationControl")
      : b === 2 && (c || Zp(a, "GamMigrationVariantFallback"));
  }
  function aq(a) {
    if (a.google_ad_host) return op(), !1;
    if (a.google_ad_intents_format) return pp(), !1;
    var b;
    if ((b = Rp(a)))
      (a = a.google_reactive_ad_format),
        (b = !(a === 40 || a === 26 || a === 27 || a === 30));
    return b ? (pp(), !1) : !0;
  }
  function bq(a, b) {
    a = a.document;
    for (var c = void 0, d = 0; !c || a.getElementById(c + "_host"); )
      c = "aswift_" + d++;
    a = c;
    c = Number(b.google_ad_width || 0);
    b = Number(b.google_ad_height || 0);
    d = document.createElement("div");
    d.id = a + "_host";
    var e = d.style;
    e.border = "none";
    e.height = `${b}px`;
    e.width = `${c}px`;
    e.margin = "0px";
    e.padding = "0px";
    e.position = "relative";
    e.visibility = "visible";
    e.backgroundColor = "transparent";
    e.display = "inline-block";
    return { Qb: a, mc: d };
  }
  function cq(a, b) {
    for (var c = [], d = 0; b && d < 25; ++d) {
      var e = void 0;
      e = (e = b.nodeType !== 9 && b.id) ? "/" + e : "";
      a: {
        if (b && b.nodeName && b.parentElement) {
          var f = b.nodeName.toString().toLowerCase();
          let g = b.parentElement.childNodes,
            h = 0;
          for (let k = 0; k < g.length; ++k) {
            let l = g[k];
            if (l.nodeName && l.nodeName.toString().toLowerCase() === f) {
              if (b === l) {
                f = "." + h;
                break a;
              }
              ++h;
            }
          }
        }
        f = "";
      }
      c.push((b.nodeName && b.nodeName.toString().toLowerCase()) + e + f);
      b = b.parentElement;
    }
    b = c.join();
    c = [];
    if (a)
      try {
        let g = a.parent;
        for (d = 0; g && g !== a && d < 25; ++d) {
          let h = g.frames;
          for (e = 0; e < h.length; ++e)
            if (a === h[e]) {
              c.push(e);
              break;
            }
          a = g;
          g = a.parent;
        }
      } catch (g) {}
    return ki(`${b}:${c.join()}`).toString();
  }
  var dq = class extends O {
    getVersion() {
      return K(this, 2);
    }
  };
  function eq(a, b) {
    return $c(a, 2, b);
  }
  function fq(a, b) {
    return $c(a, 3, b);
  }
  function gq(a, b) {
    return $c(a, 4, b);
  }
  function hq(a, b) {
    return $c(a, 5, b);
  }
  function iq(a, b) {
    return $c(a, 9, b);
  }
  function jq(a, b) {
    return Oc(a, 10, b);
  }
  function kq(a, b) {
    return B(a, 11, Hb(b));
  }
  function lq(a, b) {
    return $c(a, 1, b);
  }
  function mq(a, b) {
    return B(a, 7, Hb(b));
  }
  var nq = class extends O {};
  const oq =
    "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(
      " "
    );
  function pq() {
    var a = Q;
    if (typeof a.navigator?.userAgentData?.getHighEntropyValues !== "function")
      return null;
    var b = a.google_tag_data ?? (a.google_tag_data = {});
    if (b.uach_promise) return b.uach_promise;
    a = a.navigator.userAgentData.getHighEntropyValues(oq).then((c) => {
      b.uach ?? (b.uach = c);
      return c;
    });
    return (b.uach_promise = a);
  }
  function qq(a) {
    return kq(
      jq(
        hq(
          eq(
            lq(
              gq(
                mq(
                  iq(fq(new nq(), a.architecture || ""), a.bitness || ""),
                  a.mobile || !1
                ),
                a.model || ""
              ),
              a.platform || ""
            ),
            a.platformVersion || ""
          ),
          a.uaFullVersion || ""
        ),
        a.fullVersionList?.map((b) => {
          var c = new dq();
          c = $c(c, 1, b.brand);
          return $c(c, 2, b.version);
        }) || []
      ),
      a.wow64 || !1
    );
  }
  function rq() {
    return pq()?.then((a) => qq(a)) ?? null;
  }
  function sq(a, b) {
    b.google_ad_host || ((a = kn(a)) && (b.google_ad_host = a));
  }
  function tq(a, b) {
    a.google_sa_queue = a.google_sa_queue || [];
    a.google_sa_impl ? b() : a.google_sa_queue.push(b);
  }
  function uq() {
    var a = md(t);
    a &&
      ((a = $n(a)),
      a.tagSpecificState[1] ||
        (a.tagSpecificState[1] = { debugCard: null, debugCardRequested: !1 }));
  }
  function vq() {
    var a = rq();
    a != null &&
      a.then((b) => {
        Q.google_user_agent_client_hint = b.C();
      });
    Td();
  }
  function wq(a) {
    var b = a.google_ad_output,
      c = a.google_ad_format,
      d = a.google_ad_width || 0,
      e = a.google_ad_height || 0;
    c || (b !== "html" && b != null) || (c = `${d}x${e}`);
    b =
      !a.google_ad_slot ||
      a.google_override_format ||
      (!Dp[a.google_ad_width + "x" + a.google_ad_height] &&
        a.google_loader_used === "aa");
    c = c && b ? c.toLowerCase() : "";
    a.google_ad_format = c;
  }
  function xq(a, b) {
    b = [
      b.google_ad_slot,
      b.google_ad_format,
      b.google_ad_type,
      b.google_ad_width,
      b.google_ad_height,
    ];
    for (var c = [], d = 0; a && d < 25; a = a.parentNode, ++d)
      a.nodeType === 9 ? c.push("") : c.push(a.id);
    (a = c.join()) && b.push(a);
    return ki(b.join(":")).toString();
  }
  function yq(a) {
    return (a = a?.getAttribute("data-override-ady")) ? Wm(a) : void 0;
  }
  function zq(a) {
    return (a = a?.getAttribute("data-override-adx")) ? Wm(a) : void 0;
  }
  var Aq = ["google_pause_ad_requests", "google_user_agent_client_hint"];
  function Bq(a) {
    var b = a.xb,
      c = a.Ka,
      d = a.ca,
      e = a.l,
      f = a.U;
    c.dataset.adsbygoogleStatus = "done";
    var g = d.google_reactive_ads_config;
    b !== 2 &&
      (Ip(c, d),
      Gp(c, d, e),
      Cp(c, d, e, f),
      xp(d) ||
        (Mn(c, d)
          ? (Nn(c, d, e),
            (d.google_loader_features_used = 256),
            (d.google_responsive_auto_format = Jp(e, d)))
          : Ln(c.style, d)));
    sq(e, d);
    if (b !== 2)
      if (U(wj)) {
        if (Cq(c, d, e) || Dq(a)) return;
        Kp(c, d, e);
      } else {
        if (Dq(a)) return;
        Kp(c, d, e);
        if (Cq(c, d, e)) return;
      }
    if (Eq(d))
      t.console &&
        t.console.warn(
          "Adsbygoogle tag with data-reactive-ad-format=" +
            String(d.google_reactive_ad_format) +
            " is deprecated. Check out page-level ads at https://www.google.com/adsense"
        );
    else {
      if (b === 2) {
        f = g.page_level_pubvars || {};
        if (
          X(Q).page_contains_reactive_tag &&
          !X(Q).allow_second_reactive_tag
        ) {
          if (f.pltais) {
            gn(!1);
            return;
          }
          throw new W("Only one 'enable_page_level_ads' allowed per page.");
        }
        X(Q).page_contains_reactive_tag = !0;
        gn(f.google_pgb_reactive === 7);
      }
      d.google_unique_id = Rh(e);
      for (let h of Aq) d[h] = d[h] || e[h];
      d.google_loader_used !== "sd" && (d.google_loader_used = "aa");
      d.google_reactive_tag_first = (X(Q).first_tag_on_page || 0) === 1;
      qk(164, () => {
        var { Qb: h, mc: k } = bq(e, d);
        c.appendChild(k);
        wq(d);
        (mb(d.google_reactive_sra_index) && d.google_ad_unit_key) ||
          ((d.google_ad_unit_key = xq(c, d)),
          (d.google_ad_dom_fingerprint = cq(e, c)),
          (d.override_ady = yq(c)),
          (d.override_adx = zq(c)));
        var l = d.google_start_time ?? Th,
          m = new Date().getTime();
        d.google_async_iframe_id = h;
        d.google_start_time = l;
        d.google_bpp = m > l ? m - l : 1;
        b !== 2 && ((l = e.fqjyf || {}), (e.fqjyf = l), (l[h] = { LmpfC: d }));
        tq(e, () => {
          var n = k,
            p =
              b === 1
                ? { OSwJs: 1, mqAVR: a.ub ? { bPXfr: a.ub } : {} }
                : { OSwJs: 2, mqAVR: {} };
          if (!n || !n.isConnected)
            if (
              ((n = e.document.getElementById(
                String(d.google_async_iframe_id) + "_host"
              )),
              n == null)
            )
              throw Error("no_div");
          (p = e.google_sa_impl({
            pubWin: e,
            vars: d,
            innerInsElement: n,
            KCuMo: p,
          })) && sk(911, p);
        });
      });
    }
  }
  function Cq(a, b, c) {
    var d = en(c);
    if (
      !d?.nb ||
      b.google_adtest === "on" ||
      (x(a.className) &&
        RegExp("(\\W|^)adsbygoogle-noablate(\\W|$)").test(a.className))
    )
      d = !1;
    else if (d.ob) {
      var e = Rj(a, c);
      let f = Mj(c).clientHeight;
      d = ((f === 0 ? null : e / f) || 0) >= d.ob;
    } else d = !0;
    if (d)
      return (
        (a.className += " adsbygoogle-ablated-ad-slot"),
        (d = c.fqjyf || {}),
        (c.fqjyf = d),
        (e = String(na(a))),
        (d[e] = { LmpfC: b }),
        a.setAttribute("google_element_uid", e),
        en(c)?.jc === "slot" &&
          (Qd(a.getAttribute("width")) !== null && a.setAttribute("width", "0"),
          Qd(a.getAttribute("height")) !== null &&
            a.setAttribute("height", "0"),
          (a.style.width = "0px"),
          (a.style.height = "0px")),
        !0
      );
    if ((d = !U(Fj)))
      d =
        Nd(a, c)?.display === "none" &&
        !(
          b.google_adtest === "on" ||
          b.google_reactive_ad_format > 0 ||
          b.google_reactive_ads_config
        );
    return d
      ? (c.document.createComment &&
          a.appendChild(
            c.document.createComment(
              "No ad requested because of display:none on the adsbygoogle tag"
            )
          ),
        !0)
      : !1;
  }
  function Dq(a) {
    return (
      qk(1756, () => {
        var b = a.ca,
          c = a.l,
          d = a.U,
          e = a.pb,
          f = a.Ka,
          g = b.google_ad_client;
        g || qp();
        g = g ? Pp(c, d, g) : 0;
        d = Lp(d);
        var h = aq(b);
        if (g === 2 && h && d) return Op(c, e, d), Yp(c, f, d, b), rp(), !0;
        $p(b, g, h);
        return !1;
      }) || !1
    );
  }
  function Eq(a) {
    var b = a.google_pgb_reactive == null || a.google_pgb_reactive === 3;
    return (
      (a.google_reactive_ad_format === 1 ||
        a.google_reactive_ad_format === 8) &&
      b
    );
  }
  const Fq = { auto: 1, low: 2, high: 3, unset: 0 };
  function Gq(a, b) {
    var c = V(vj);
    if (new fk().na(c)) {
      var d = a?.crossOrigin === "anonymous";
      a =
        Fq[a?.getAttribute?.("fetchpriority")?.toLowerCase?.() ?? "unset"] ?? 4;
      b = b.J.h.h;
      b.Vb.Na({ Xa: c, Qa: d, priority: a });
      b.Rb.Na({ Xa: c, Qa: !1 });
    }
  }
  function Hq(a, b, c, d, e, f) {
    if (!Q.google_sa_queue) {
      Q.google_sa_queue = [];
      var g = I(b, 4) ? !vn(Q, Sh(e ?? ""), b) : !1;
      g
        ? ((g = !1),
          (b = Iq(Q, e)),
          jo(b.client, b.plah)
            .then((h) => {
              c.resolve(C(h, Yj, 2)?.C() || void 0);
              d.resolve(I(h, 1));
            })
            .catch((h) => {
              ck(f, 1191, h);
              c.resolve(void 0);
              d.resolve(!0);
            }))
        : (c.resolve(Z(b)?.J()?.C() || void 0), d.resolve(Z(b)?.H() ?? !0));
      Q.google_process_slots = rk(215, () => {
        Jq(Q.google_sa_queue);
      });
      a = Kq(e, a, g);
      e = Q.document.currentScript;
      g = e?.getAttribute?.("fetchpriority") ?? "high";
      Gq(e, f);
      Ld(Q.document, a, g);
    }
  }
  function Jq(a) {
    var b = a.shift();
    pb(b) && qk(216, b);
    a.length &&
      t.setTimeout(
        rk(215, () => {
          Jq(a);
        }),
        0
      );
  }
  function Kq(a, b, c) {
    var d = Q;
    b = c ? b.dc : b.ec;
    a = { ...(c ? Iq(d, a) : {}), ...Un() };
    return Jd(b, new Map(Object.entries(a)));
  }
  function Iq(a, b) {
    if (b) {
      a: {
        try {
          for (; a; ) {
            if (a.location?.hostname) {
              var c = a.location.hostname;
              break a;
            }
            a = a.parent;
          }
        } catch (d) {}
        c = "";
      }
      return { client: Sh(b), plah: c };
    }
    throw Error("PublisherCodeNotFoundForAma");
  }
  var Lq = class extends O {
    h() {
      return K(this, 1);
    }
    j() {
      return L(this, 2);
    }
  };
  var Mq = class extends O {
    getName() {
      return K(this, 1);
    }
  };
  var Nq = class extends O {
    h() {
      return D(this, Mq, 1);
    }
  };
  var Oq = class extends O {
    j() {
      return K(this, 1);
    }
    h() {
      return L(this, 2);
    }
  };
  var Pq = class extends O {
    u() {
      return K(this, 1);
    }
    h() {
      return C(this, Lq, 2);
    }
    N() {
      return I(this, 3);
    }
    W() {
      return I(this, 4);
    }
    Y() {
      return C(this, Zl, 5);
    }
    ea() {
      return C(this, $l, 6);
    }
    ga() {
      return C(this, Nq, 7);
    }
    H() {
      return I(this, 8);
    }
    J() {
      return C(this, Yj, 9);
    }
    fa() {
      return I(this, 10);
    }
    j() {
      return C(this, Oq, 11);
    }
  };
  var Qq = class extends O {
    getId() {
      return J(this, 1);
    }
  };
  var Rq = class extends O {};
  var Sq = class extends O {};
  var Tq = class extends O {
    h() {
      return Qc(this, 2) ?? oc;
    }
    j() {
      return Qc(this, 4) ?? oc;
    }
    u() {
      return I(this, 3);
    }
  };
  var Uq = class extends O {};
  var Vq = class extends O {
    h() {
      return I(this, 1);
    }
    u() {
      return I(this, 2);
    }
    j() {
      return I(this, 3);
    }
  };
  function Z(a) {
    return C(a, Pq, Gc(a, Wq, 27));
  }
  var Xq = class extends O {
      h() {
        return C(this, Vq, 26);
      }
    },
    Wq = [27, 28];
  function Yq(a) {
    var b = mk;
    try {
      if (!x(a)) throw Error(String(a));
      if (a.length > 0) return new Xq(JSON.parse(a));
    } catch (c) {
      b.M(838, c instanceof Error ? c : Error(String(c)));
    }
    return new Xq();
  }
  var Zq = class {
    constructor(a) {
      this.h = a;
      this.pinger = new eh(2, qg(), void 0, void 0, void 0, void 0, Kh);
      this.sampler = new gk();
    }
  };
  function $q() {
    var a = window;
    return t.google_adtest === "on" ||
      t.google_adbreak_test === "on" ||
      a.location.host.endsWith("h5games.usercontent.goog") ||
      a.location.host === "gamesnacks.com"
      ? a.document
          .querySelector('meta[name="h5-games-eids"]')
          ?.getAttribute("content")
          ?.split(",")
          .map((b) => Math.floor(Number(b)))
          .filter((b) => !isNaN(b) && b > 0) || []
      : [];
  }
  function ar(a, b) {
    return a instanceof HTMLScriptElement && b.test(a.src) ? 0 : 1;
  }
  function br(a) {
    var b = Q.document;
    if (b.currentScript) return ar(b.currentScript, a);
    for (let c of b.scripts) if (ar(c, a) === 0) return 0;
    return 1;
  }
  function cr(a, b) {
    var c = !!b.h()?.h();
    return {
      [3]: {
        [55]: () => a === 0,
        [23]: (d) => mn(Q, Number(d), b),
        [24]: (d) => pn(Number(d), c),
        [61]: () => c,
        [63]: () => c || K(b, 8) === ".google.ch",
      },
      [4]: { [22]: () => Z(b)?.j()?.h() ?? 0 },
      [5]: { [6]: () => K(b, 15) },
    };
  }
  function dr(a = t) {
    return a.ggeac || (a.ggeac = {});
  }
  function er(a, b = document) {
    return !!b.featurePolicy?.features().includes(a);
  }
  function fr(a, b = document) {
    return !!b.featurePolicy?.allowedFeatures().includes(a);
  }
  function gr(a, b) {
    try {
      let d = a.split(".");
      a = t;
      let e = 0,
        f;
      for (; a != null && e < d.length; e++)
        (f = a), (a = a[d[e]]), typeof a === "function" && (a = f[d[e]]());
      var c = a;
      if (typeof c === b) return c;
    } catch {}
  }
  var hr = {
    [3]: {
      [8]: (a) => {
        try {
          return ka(a) != null;
        } catch {}
      },
      [9]: (a) => {
        try {
          var b = ka(a);
        } catch {
          return;
        }
        if ((a = typeof b === "function"))
          (b = b && b.toString && b.toString()),
            (a = x(b) && b.indexOf("[native code]") != -1);
        return a;
      },
      [10]: () => window === window.top,
      [6]: (a, b) => Ka(Kh(b ? Number(b) : void 0), Number(a)),
      [27]: (a) => {
        a = gr(a, "boolean");
        return a !== void 0 ? a : void 0;
      },
      [60]: (a) => {
        try {
          return !!t.document.querySelector(a);
        } catch {}
      },
      [80]: (a) => {
        try {
          return !!t.matchMedia(a).matches;
        } catch {}
      },
      [69]: (a) => er(a, t.document),
      [70]: (a) => fr(a, t.document),
    },
    [4]: {
      [3]: () => Cd(),
      [6]: (a) => {
        a = gr(a, "number");
        return a !== void 0 ? a : void 0;
      },
    },
    [5]: {
      [2]: () => window.location.href,
      [3]: () => {
        try {
          return window.top.location.hash;
        } catch {
          return "";
        }
      },
      [4]: (a) => {
        a = gr(a, "string");
        return a !== void 0 ? a : void 0;
      },
      [12]: (a) => {
        try {
          let b = gr(a, "string");
          if (b !== void 0) return atob(b);
        } catch (b) {}
      },
    },
  };
  function ir(a) {
    return jr({ [0]: new Map(), [1]: new Map(), [2]: new Map() }, a);
  }
  function jr(a, b) {
    var c = new Map();
    for (let [f, g] of a[1].entries()) {
      var d = f,
        e = g;
      let { Cb: h, yb: k, zb: l } = e[e.length - 1];
      c.set(d, h + k * l);
    }
    for (let f of b)
      for (let g of D(f, Rq, 2)) {
        if (D(g, Qq, 2).length === 0) continue;
        b = Nb(A(g, 8)) ?? 0;
        !L(g, 4) ||
          L(g, 13) ||
          L(g, 14) ||
          ((b = c.get(L(g, 4)) ?? 0),
          (d = (Nb(A(g, 1)) ?? 0) * D(g, Qq, 2).length),
          c.set(L(g, 4), b + d));
        d = [];
        for (e = 0; e < D(g, Qq, 2).length; e++) {
          let h = {
            Cb: b,
            yb: Nb(A(g, 1)) ?? 0,
            zb: D(g, Qq, 2).length,
            Xb: e,
            ma: L(f, 1),
            Ba: g,
            V: D(g, Qq, 2)[e],
          };
          d.push(h);
        }
        kr(a[2], L(g, 10), d) ||
          kr(a[1], L(g, 4), d) ||
          kr(a[0], D(g, Qq, 2)[0].getId(), d);
      }
    return a;
  }
  function kr(a, b, c) {
    if (!b) return !1;
    a.has(b) || a.set(b, []);
    a.get(b).push(...c);
    return !0;
  }
  function lr(a = Dd()) {
    return (b) => ki(`${b} + ${a}`) % 1e3;
  }
  const mr = [12, 13, 20, 32];
  function nr(a, b) {
    var c = P(kh).P,
      d = cf(C(b.Ba, We, 3), c);
    if (!d.success) return ih(a.O, C(b.Ba, We, 3), b.ma, b.V.getId(), d), !1;
    if (!d.value) return !1;
    c = cf(C(b.V, We, 3), c);
    return c.success
      ? !!c.value
      : (ih(a.O, C(b.V, We, 3), b.ma, b.V.getId(), c), !1);
  }
  function or(a, b, c) {
    a.h[c] || (a.h[c] = []);
    a = a.h[c];
    a.includes(b) || a.push(b);
  }
  function pr(a, b, c, d) {
    var e = [],
      f;
    if ((f = b !== 9)) a.u[b] ? (f = !0) : ((a.u[b] = !0), (f = !1));
    if (f) return gh(a.O, b, c, e, [], 4), e;
    f = mr.includes(b);
    var g = [],
      h = [];
    for (let n of [0, 1, 2])
      for (let [p, r] of a.ra[n].entries()) {
        var k = p,
          l = r;
        let q = new $f();
        var m = l.filter((w) => w.ma === b && a.i[w.V.getId()] && nr(a, w));
        if (m.length) {
          for (let w of m) h.push(w.V);
          continue;
        }
        if (a.Ma) continue;
        n === 2 ? ((m = d[1]), dd(q, 2, ag, k)) : (m = d[0]);
        k =
          m?.(String(k)) ??
          (n === 2 && L(l[0].Ba, 11) === 1 ? void 0 : d[0](String(k)));
        if (k !== void 0) {
          for (let w of l) {
            if (w.ma !== b) continue;
            l = k - w.Cb;
            m = w.yb;
            let G = w.zb,
              Y = w.Xb;
            if (l < 0 || l >= m * G || l % G !== Y) continue;
            if (!nr(a, w)) continue;
            l = L(w.Ba, 13);
            l !== 0 &&
              l !== void 0 &&
              ((m = a.j[String(l)]),
              m !== void 0 && m !== w.V.getId()
                ? hh(a.O, a.j[String(l)], w.V.getId(), l)
                : (a.j[String(l)] = w.V.getId()));
            h.push(w.V);
          }
          Hc(q.B, ag) !== 0 && (M(q, 3, k), g.push(q));
        }
      }
    for (let n of h)
      (d = n.getId()),
        e.push(d),
        or(a, d, f ? 4 : c),
        Ah(D(n, ff, 2), f ? Ch() : [c], a.O, d);
    gh(a.O, b, c, e, g, 1);
    return e;
  }
  function qr(a, b) {
    b = b.map((c) => new Sq(c)).filter((c) => !mr.includes(L(c, 1)));
    a.ra = jr(a.ra, b);
  }
  function rr(a, b) {
    R(
      1,
      (c) => {
        a.i[c] = !0;
      },
      b
    );
    R(2, (c, d, e) => pr(a, c, d, e), b);
    R(3, (c) => (a.h[c] || []).concat(a.h[4]), b);
    R(12, (c) => void qr(a, c), b);
    R(16, (c, d) => void or(a, c, d), b);
  }
  var sr = class {
    constructor(a, b, c, { Ma: d = !1, Sc: e = [] } = {}) {
      this.ra = a;
      this.O = c;
      this.u = {};
      this.Ma = d;
      this.h = { [b]: [], [4]: [] };
      this.i = {};
      this.j = {};
      if ((a = we())) {
        a = a.split(",") || [];
        for (let f of a) (a = Number(f)) && (this.i[a] = !0);
      }
      for (let f of e) this.i[f] = !0;
    }
  };
  function tr(a, b) {
    a.h = Eh(14, b, () => {});
  }
  class ur {
    constructor() {
      this.h = () => {};
    }
  }
  function vr(a) {
    P(ur).h(a);
  }
  function wr({
    Ob: a,
    P: b,
    config: c,
    Jb: d = dr(),
    qb: e = 0,
    pinger: f,
    O: g = new jh(
      pm(C(a, Tq, 5)?.h()) ?? 0,
      pm(C(a, Tq, 5)?.j()) ?? 0,
      C(a, Tq, 5)?.u() ?? !1,
      f
    ),
    ra: h = ir(D(a, Sq, 2, vc && uc())),
  }) {
    d.hasOwnProperty("init-done")
      ? (Eh(12, d, () => {})(D(a, Sq, 2).map((k) => z(k))),
        Eh(13, d, () => {})(
          D(a, ff, 1).map((k) => z(k)),
          e
        ),
        b && Eh(14, d, () => {})(b),
        xr(e, d))
      : (rr(new sr(h, e, g, c), d),
        Fh(d),
        Gh(d),
        Hh(d),
        xr(e, d),
        Ah(D(a, ff, 1, vc && uc()), [e], g, void 0, !0),
        (lh = lh || !(!c || !c.Ub)),
        vr(hr),
        b && vr(b));
  }
  function xr(a, b = dr()) {
    Ih(P(Jh), b, a);
    yr(b, a);
    tr(P(ur), b);
    P(Ud).D();
  }
  function yr(a, b) {
    var c = P(Ud);
    c.j = (d, e) => Eh(5, a, () => !1)(d, e, b);
    c.H = (d, e) => Eh(18, a, () => null)(d, e, b);
    c.C = (d, e) => Eh(6, a, () => 0)(d, e, b);
    c.h = (d, e) => Eh(7, a, () => "")(d, e, b);
    c.i = (d, e) => Eh(8, a, () => [])(d, e, b);
    c.u = (d, e) => Eh(17, a, () => [])(d, e, b);
    c.D = () => {
      Eh(15, a, () => {})(b);
    };
  }
  function zr(a, b) {
    b = { [0]: lr(Wd(b).toString()) };
    b = P(Jh).j(a, b);
    a = ip(P(ep), a, b);
    Nh.wa(1085, a);
  }
  function Ar(a, b, c, d) {
    var e = C(b, Uq, 12),
      f = I(b, 9);
    wr({
      Ob: e,
      P: cr(c, b),
      config: { Ma: f && !!a.google_disable_experiments, Ub: f },
      Jb: dr(a),
      qb: 1,
      pinger: d,
    });
    if ((c = K(b, 15))) (c = Number(c)), P(Jh).i(c);
    for (let g of wc(b, 19, Mb)) P(Jh).h(g);
    zr(12, a);
    zr(32, a);
    zr(10, a);
  }
  function Br(a) {
    mk.C((b) => {
      b.shv = String(a);
      b.mjsv = qg();
      var c = Kh(),
        d = $q();
      b.eid = c.concat(d).join(",");
    });
  }
  function Cr(a, b, c) {
    var d = pm(Qc(a, 30) ?? oc);
    return {
      stavq: J(a, 1),
      jTCuI: K(a, 2),
      OmOVT: I(a, 20),
      xujKL: I(a, 9),
      AyxaY: J(a, 18) !== -1 ? J(a, 18) : void 0,
      SLqBY: K(a, 8) || void 0,
      xVQAt: K(a, 3),
      OSCLM: { UWEfJ: !!a.h()?.h(), YguOd: !!a.h()?.u(), SVQEK: !!a.h()?.j() },
      jzoix: {
        PygXN: (Z(a)?.ga()?.h() || []).map((e) => ({
          aJhyn: e.getName(),
          ihulF: K(e, 2),
        })),
      },
      gjPrg: Z(a)?.u() ?? void 0,
      zeuLy: Z(a)?.h()?.h() ?? void 0,
      ANqoe: K(a, 17) ?? void 0,
      FJPve: !1,
      GLnKw: !1,
      tYcft: b.promise,
      EGzMj: c.promise,
      uNjDc: !!Z(a)?.fa(),
      MhIdB: d && d > 0 ? d : void 0,
    };
  }
  function Dr(a, b, c) {
    if (c === "sd") return 0;
    if (I(b, 22)) return 7;
    if (I(b, 16)) return 6;
    c = Z(b)?.h()?.h();
    b = Z(b)?.h()?.j() ?? 0;
    a = c === a;
    switch (b) {
      case 1:
        return a ? 9 : 8;
      case 2:
        return a ? 11 : 10;
      case 3:
        return a ? 13 : 12;
    }
    return 1;
  }
  function Er(a, b) {
    var c = new Fr();
    try {
      let f = a.createElement("link");
      if (f.relList?.supports?.("compression-dictionary") && Aa()) {
        var d = f;
        if (b instanceof vd)
          (d.href = xd(b).toString()), (d.rel = "compression-dictionary");
        else {
          if (Ad.indexOf("compression-dictionary") === -1)
            throw Error(
              'TrustedResourceUrl href attribute required with rel="compression-dictionary"'
            );
          var e = yd.test(b) ? b : void 0;
          e !== void 0 && ((d.href = e), (d.rel = "compression-dictionary"));
        }
        a.head.appendChild(f);
      }
    } catch (f) {
      c.ia({ methodName: 1296, Ia: f });
    }
  }
  var Fr = class {
    constructor() {
      this.h = mk;
    }
    ia(a) {
      var b = a.Ia;
      this.h.M(a.methodName ?? 0, b instanceof Error ? b : Error(String(b)));
    }
  };
  function Gr(a, b, c) {
    ee(a, "message", (d) => {
      try {
        var e = JSON.parse(d.data);
      } catch (f) {
        return;
      }
      !e || e.googMsgType !== b || c(e, d);
    });
  }
  var Hr = class {
    constructor() {
      this.i = new Map();
      this.h = new Map();
    }
  };
  function Ir(a, b) {
    if (!a.h.some((d) => d.Ca === b)) return [];
    for (var c = []; a.h.length > 0; ) {
      let d = a.h[a.h.length - 1].Ca === b,
        e = a.h.pop();
      a.j.delete(e.Ca);
      c.push(e);
      a.i.dispatchEvent(e.qb, { za: a.h.length === 0 ? 5 : 6, Ua: e.format });
      if (d) break;
    }
    return c;
  }
  var Jr = class {
    constructor(a) {
      this.i = a;
      this.h = [];
      this.j = new Map();
    }
    get length() {
      return this.h.length;
    }
  };
  function Kr(a, b, c) {
    a = { ...c, Wa: ++a.i };
    try {
      b(a);
    } catch (d) {}
  }
  var Lr = class {
    constructor() {
      this.h = new Map();
      this.i = 0;
    }
    dispatchEvent(a, b) {
      var c = this.h.get(a);
      if (c) Kr(this, c, b);
      else
        for (let [d, e] of this.h.entries())
          if (((c = e), d !== a && c)) {
            Kr(this, c, { ...b, za: 8 });
            Kr(this, c, b);
            break;
          }
    }
  };
  function Mr() {
    Q.google_tag_data ?? (Q.google_tag_data = {});
    var a;
    (a = Q.google_tag_data).fsao ?? (a.fsao = new Nr());
    return Q.google_tag_data.fsao;
  }
  function Or(a, b) {
    b && a.i.h.set(1, b);
  }
  function Pr(a) {
    var b = { Ab: V(sj), Eb: 6e4 };
    if (b && !a.h.has(1)) {
      a.h.set(1, { ...b });
      var c = {};
      b.Eb && (c[1] = { [8]: b.Eb });
      b.Ab && (c[8] = { [1]: b.Ab });
      a.j.i.set(1, { Fc: c });
    }
  }
  var Nr = class {
    constructor() {
      this.i = new Lr();
      this.j = new Hr();
      this.h = new Map();
      this.u = new Jr(this.i);
    }
    releaseLock(a) {
      if (a) {
        var b = a.Ca;
        b = !(!b || typeof b !== "object");
      } else b = !1;
      if (!b) return !1;
      b = Ir(this.u, a.Ca);
      if (b.length === 0) return !1;
      if (a.Tc) for (let c of b) this.j.h.set(c.format, Date.now());
      return !0;
    }
  };
  function Qr(a) {
    switch (a) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 3:
        return 3;
      case 4:
        return 4;
      case 5:
        return 5;
      case 6:
        return 6;
      case 7:
        return 7;
      case 8:
        return 8;
      case 9:
        return 9;
      case 10:
        return 10;
      case 11:
        return 11;
      case 12:
        return 12;
      case 13:
        return 13;
      case 14:
        return 14;
      case 15:
        return 15;
      default:
        return 0;
    }
  }
  function Rr(a) {
    switch (a) {
      case 1:
        return 1;
      case 2:
        return 2;
      case 4:
        return 3;
      case 8:
        return 4;
      default:
        return 0;
    }
  }
  function Sr() {
    var a = new Set();
    ({ googletag: b } = window);
    var b = b?.apiReady ? b : void 0;
    try {
      if (!b) return a;
      let c = b.pubads();
      for (let d of c.getSlots()) a.add(d.getSlotId().getDomId());
    } catch {}
    return a;
  }
  function Gg(a) {
    a = a.id;
    return (
      a != null &&
      (Sr().has(a) ||
        a.startsWith("google_ads_iframe_") ||
        a.startsWith("aswift"))
    );
  }
  function Tr(a, b, c) {
    if (!a.sources) return !1;
    switch (Ur(a)) {
      case 2:
        let d = Vr(a);
        if (d) return c.some((f) => Wr(d, f));
        break;
      case 1:
        let e = Xr(a);
        if (e) return b.some((f) => Wr(e, f));
    }
    return !1;
  }
  function Ur(a) {
    if (!a.sources) return 0;
    a = a.sources.filter((b) => b.previousRect && b.currentRect);
    if (a.length >= 1) {
      a = a[0];
      if (a.previousRect.top < a.currentRect.top) return 2;
      if (a.previousRect.top > a.currentRect.top) return 1;
    }
    return 0;
  }
  function Xr(a) {
    return Yr(a, (b) => b.currentRect);
  }
  function Vr(a) {
    return Yr(a, (b) => b.previousRect);
  }
  function Yr(a, b) {
    return a.sources.reduce((c, d) => {
      d = b(d);
      return c
        ? d && d.width * d.height !== 0
          ? d.top < c.top
            ? d
            : c
          : c
        : d;
    }, null);
  }
  function Wr(a, b) {
    var c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
    a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
    return c <= 0 || a <= 0
      ? !1
      : (c * a * 100) / ((b.right - b.left) * (b.bottom - b.top)) >= 50;
  }
  function Zr() {
    var a = Array.from(document.getElementsByTagName("iframe")).filter(Gg),
      b = [...Sr()]
        .map((c) => document.getElementById(c))
        .filter((c) => c !== null);
    $r = window.scrollX;
    as = window.scrollY;
    return (bs = [...a, ...b].map((c) => c.getBoundingClientRect()));
  }
  function cs() {
    var a = new ds();
    if (U(Ej)) {
      var b = window;
      if (!b.google_plmetrics && window.PerformanceObserver) {
        b.google_plmetrics = !0;
        b = [
          "layout-shift",
          "largest-contentful-paint",
          "first-input",
          "longtask",
          "event",
        ];
        for (let c of b)
          (b = { type: c, buffered: !0 }),
            c === "event" && (b.durationThreshold = 40),
            es(a).observe(b);
        fs(a);
      }
    }
  }
  function gs(a, b) {
    var c = $r !== window.scrollX || as !== window.scrollY ? [] : bs,
      d = Zr();
    for (let e of b.getEntries())
      switch (((b = e.entryType), b)) {
        case "layout-shift":
          hs(a, e, c, d);
          break;
        case "largest-contentful-paint":
          b = e;
          a.fb = Math.floor(b.renderTime || b.loadTime);
          a.eb = b.size;
          break;
        case "first-input":
          b = e;
          a.Za = Number((b.processingStart - b.startTime).toFixed(3));
          a.ab = !0;
          a.h.some((f) =>
            f.entries.some(
              (g) => e.duration === g.duration && e.startTime === g.startTime
            )
          ) || is(a, e);
          break;
        case "longtask":
          b = Math.max(0, e.duration - 50);
          a.H += b;
          a.W = Math.max(a.W, b);
          a.ga += 1;
          break;
        case "event":
          is(a, e);
          break;
        default:
          Ab(b, void 0);
      }
  }
  function es(a) {
    a.O ||
      (a.O = new PerformanceObserver(
        Ni(640, (b) => {
          gs(a, b);
        })
      ));
    return a.O;
  }
  function fs(a) {
    var b = Ni(641, () => {
        var d = document;
        (d.prerendering
          ? 3
          : {
              visible: 1,
              hidden: 2,
              prerender: 3,
              preview: 4,
              unloaded: 5,
              "": 0,
            }[
              d.visibilityState ||
                d.webkitVisibilityState ||
                d.mozVisibilityState ||
                ""
            ] ?? 0) === 2 && js(a);
      }),
      c = Ni(641, () => void js(a));
    document.addEventListener("visibilitychange", b);
    document.addEventListener("pagehide", c);
    a.Ya = () => {
      document.removeEventListener("visibilitychange", b);
      document.removeEventListener("pagehide", c);
      es(a).disconnect();
    };
  }
  function js(a) {
    if (!a.ib) {
      a.ib = !0;
      es(a).takeRecords();
      var b = window,
        c = Math.min(
          a.h.length - 1,
          Math.floor((a.O ? a.bb : performance.interactionCount || 0) / 50)
        ),
        d = new Kg();
      b.LayoutShift &&
        (zg(yg(xg(Yc(d, 1, a.J), a.Y), a.fa), a.Da),
        b.LayoutShiftAttribution && Bg(Ag(Yc(d, 5, a.D), a.hb), a.mb),
        Yc(d, 8, a.lb));
      b.LargestContentfulPaint && Cg(N(d, 9, a.fb), a.eb);
      window.PerformanceEventTiming && a.ab && N(d, 11, a.Za);
      b.PerformanceLongTaskTiming && Eg(Dg(N(d, 12, a.H), a.W), a.ga);
      Jg(Ig(Fg(d)));
      a.kb ? $c(d, 17, a.kb) : Hg(d, Hd(t, { ia: () => {} }));
      b.googletag && B(d, 21, Hb(!0));
      c >= 0 && ((b = a.h[c].latency), b >= 0 && N(d, 15, b));
      Xg(a.C.Ta, d);
      a.C.Ta instanceof dh && bh(a.C.Ta);
      a.Ya();
    }
  }
  function hs(a, b, c, d) {
    if (!b.hadRecentInput) {
      a.J += Number(b.value);
      Number(b.value) > a.Y && (a.Y = Number(b.value));
      a.fa += 1;
      if ((c = Tr(b, c, d))) (a.D += b.value), a.hb++;
      if (b.startTime - a.gb > 5e3 || b.startTime - a.jb > 1e3)
        (a.gb = b.startTime), (a.i = 0), (a.j = 0);
      a.jb = b.startTime;
      a.i += b.value;
      c && (a.j += b.value);
      a.i > a.Da &&
        ((a.Da = a.i), (a.mb = a.j), (a.lb = b.startTime + b.duration));
    }
  }
  function is(a, b) {
    ks(a, b);
    var c = a.h[a.h.length - 1],
      d = a.N[b.interactionId];
    if (d || a.h.length < 10 || b.duration > c.latency)
      d
        ? (d.entries.push(b), (d.latency = Math.max(d.latency, b.duration)))
        : ((b = { id: b.interactionId, latency: b.duration, entries: [b] }),
          (a.N[b.id] = b),
          a.h.push(b)),
        a.h.sort((e, f) => f.latency - e.latency),
        a.h.splice(10).forEach((e) => {
          delete a.N[e.id];
        });
  }
  function ks(a, b) {
    b.interactionId &&
      ((a.ea = Math.min(a.ea, b.interactionId)),
      (a.u = Math.max(a.u, b.interactionId)),
      (a.bb = a.u ? (a.u - a.ea) / 7 + 1 : 0));
  }
  var ds = class {
      constructor() {
        this.C = { Ta: ik };
        this.j = this.i = this.fa = this.Y = this.J = 0;
        this.jb = this.gb = Number.NEGATIVE_INFINITY;
        this.h = [];
        this.N = {};
        this.bb = 0;
        this.ea = Infinity;
        this.Za =
          this.eb =
          this.fb =
          this.hb =
          this.mb =
          this.D =
          this.lb =
          this.Da =
          this.u =
            0;
        this.ab = !1;
        this.ga = this.W = this.H = 0;
        this.O = null;
        this.ib = !1;
        this.Ya = () => {};
        var a = document.querySelector("[data-google-query-id]");
        this.kb = a ? a.getAttribute("data-google-query-id") : null;
      }
    },
    $r,
    as,
    bs = [];
  let ls = null;
  const ms = [],
    ns = new Map();
  let os = -1;
  function ps(a) {
    return Vj.test(a.className) && a.dataset.adsbygoogleStatus !== "done";
  }
  function qs(a) {
    var b = document.getElementsByTagName("INS");
    for (let d = 0, e = b[d]; d < b.length; e = b[++d]) {
      var c = e;
      if (
        ps(c) &&
        c.dataset.adsbygoogleStatus !== "reserved" &&
        (!a || e.id === a)
      )
        return e;
    }
    return null;
  }
  function rs(a, b, c, d, e, f) {
    if (a && "shift" in a) {
      cp(P(ep), (h) => {
        var k = Mf(h);
        Sc(k, 2) || ((h = Mf(h)), Zc(h, 2));
      });
      for (var g = 20; a.length > 0 && g > 0; ) {
        try {
          ss(a.shift(), b, c, d, e, f);
        } catch (h) {
          setTimeout(() => {
            throw h;
          });
        }
        --g;
      }
    }
  }
  function ts() {
    var a = Md("INS");
    a.className = "adsbygoogle";
    a.className += " adsbygoogle-noablate";
    Sd(a);
    a.dataset.adHi = "true";
    return a;
  }
  function us(a, b, c) {
    var d = {},
      e = un(a.google_ad_client, b),
      f = U(rj);
    kd(Lj, (k, l) => {
      if (f || k !== 8)
        a.enable_page_level_ads === !1
          ? (d[l] = !1)
          : a.hasOwnProperty(l) && (f || k !== 7)
          ? (d[l] = a[l])
          : e.includes(k) && (d[l] = !1);
    });
    ma(a.enable_page_level_ads) &&
      (d.page_level_pubvars = a.enable_page_level_ads);
    var g = ts();
    he.body.appendChild(g);
    var h = {
      google_reactive_ads_config: d,
      google_ad_client: a.google_ad_client,
    };
    h.google_pause_ad_requests = !!X(Q).pause_ad_requests;
    h.abgtt = Dr(vs(a), b, h.google_loader_used) || void 0;
    Bq({ xb: 2, Ka: g, ca: h, l: window, U: b, pb: c });
    cp(P(ep), (k) => {
      var l = Mf(k);
      Sc(l, 6) || ((k = Mf(k)), Zc(k, 6));
    });
  }
  function ws(a, b, c) {
    $n(t).wasPlaTagProcessed = !0;
    var d = () => {
        us(a, b, c);
      },
      e = t.document;
    if (e.body || e.readyState === "complete" || e.readyState === "interactive")
      us(a, b, c);
    else {
      let f = pd(rk(191, d));
      ee(e, "DOMContentLoaded", f);
      t.MutationObserver != null &&
        new t.MutationObserver((g, h) => {
          e.body && (f(), h.disconnect());
        }).observe(e, { childList: !0, subtree: !0 });
    }
  }
  function ss(a, b, c, d, e, f) {
    var g = {};
    qk(
      165,
      () => {
        xs(a, g, b, c, d, e, f);
      },
      (h) => {
        h.client = h.client || g.google_ad_client || a.google_ad_client;
        h.slotname = h.slotname || g.google_ad_slot;
        h.tag_origin = h.tag_origin || g.google_tag_origin;
      }
    );
  }
  function ys(a) {
    delete a.google_checked_head;
    kd(a, (b, c) => {
      Uj[c] ||
        (delete a[c],
        t.console.warn(
          `AdSense head tag doesn't support ${c
            .replace("google", "data")
            .replace(/_/g, "-")} attribute.`
        ));
    });
  }
  function zs(a, b) {
    var c = As();
    if (c) {
      var d = {};
      Ip(c, d);
      ys(d);
      d.google_ad_intents_format && (d.google_reactive_ad_format = 42);
      c = X(window);
      let f = {};
      for (var e in d) f[e] = d[e];
      c.head_tag_slot_vars = f;
      e = { google_ad_client: d.google_ad_client, enable_page_level_ads: d };
      if ((!U(Aj) && d.google_ad_intent_query) || d.google_ad_intents_format)
        e.enable_ad_intent_display_ads = !0;
      d.google_overlays === "bottom" && (e.overlays = { bottom: !0 });
      d.google_overlays === "collapsed-bottom" &&
        (e.overlays = { bottom: !0, ["collapsed-bottom"]: !0 });
      delete d.google_overlays;
      c = Q;
      c.adsbygoogle || (c.adsbygoogle = []);
      c = c.adsbygoogle;
      c.loaded ? c.push(e) : c.splice && c.splice(0, 0, e);
      Bs(d, b, a);
    }
  }
  function As() {
    var a = Q;
    if (
      (a =
        a.document.querySelector(
          'script[src*="/pagead/js/adsbygoogle.js?client="]:not([data-checked-head])'
        ) ||
        a.document.querySelector(
          'script[src*="/pagead/js/adsbygoogle_direct.js?client="]:not([data-checked-head])'
        ) ||
        a.document.querySelector(
          'script[src*="/pagead/js/adsbygoogle.js"][data-ad-client]:not([data-checked-head])'
        ) ||
        a.document.querySelector(
          'script[src*="/pagead/js/adsbygoogle_direct.js"][data-ad-client]:not([data-checked-head])'
        ))
    )
      if (
        (a.setAttribute("data-checked-head", "true"),
        X(window).head_tag_slot_vars)
      )
        Cs(a);
      else
        return (
          cp(P(ep), (b) => {
            b = Mf(b);
            Cc(b, 7, Hb(!0), !1);
          }),
          a
        );
  }
  function Bs(a, b, c) {
    b = Z(b)?.W();
    a.google_adbreak_test || b
      ? Ds(a, c)
      : Gr(window, "sc-cnf", () => {
          Ds(a, c);
        });
  }
  function Cs(a) {
    var b = X(window).head_tag_slot_vars,
      c = a.getAttribute("src") || "";
    if (
      (a = Qe(c, "client") || a.getAttribute("data-ad-client") || "") &&
      a !== b.google_ad_client
    )
      throw new W(
        `Warning: Do not add multiple property codes with AdSense tag to avoid seeing unexpected behavior. These codes were found on the page ${a}, ${String(
          b.google_ad_client
        )}`
      );
  }
  function Es(a) {
    if (typeof a === "object" && a != null) {
      if (x(a.type)) return 2;
      if (
        x(a.sound) ||
        x(a.preloadAdBreaks) ||
        typeof a.h5AdsConfig === "object"
      )
        return 3;
    }
    return 0;
  }
  function xs(a, b, c, d, e, f, g) {
    if (a == null) throw new W("push() called with no parameters.");
    var h = P(ep);
    cp(h, (l) => {
      var m = Mf(l);
      Sc(m, 3) || ((l = Mf(l)), Zc(l, 3));
    });
    var k = Es(a);
    if (k !== 0)
      if (
        ((c = hn()),
        c.first_slotcar_request_processing_time ||
          ((c.first_slotcar_request_processing_time = Date.now()),
          (c.adsbygoogle_execution_start_time = Th)),
        ls == null)
      )
        Fs(a), ms.push(a);
      else if (k === 3) {
        let l = ls;
        qk(787, () => {
          l.handleAdConfig(a);
        });
      } else sk(730, ls.handleAdBreak(a));
    else {
      Th = new Date().getTime();
      Hq(c, d, e, f, vs(a), g);
      Gs();
      a: {
        if (
          !a.enable_ad_intent_display_ads &&
          a.enable_page_level_ads != null
        ) {
          if (x(a.google_ad_client)) {
            k = !0;
            break a;
          }
          throw new W("'google_ad_client' is missing from the tag config.");
        }
        k = !1;
      }
      if (k)
        cp(h, (l) => {
          var m = Mf(l);
          Sc(m, 4) || ((l = Mf(l)), Zc(l, 4));
        }),
          Hs(a, d, c);
      else if (
        ((k = a.params) &&
          kd(k, (l, m) => {
            b[m] = l;
          }),
        b.google_ad_output === "js")
      )
        console.warn(
          "Ads with google_ad_output='js' have been deprecated and no longer work. Contact your AdSense account manager or switch to standard AdSense ads."
        );
      else {
        b.abgtt = Dr(vs(a), d, b.google_loader_used) || void 0;
        k = Is(b, a);
        Ip(k, b);
        e = X(t).head_tag_slot_vars || {};
        kd(e, (l, m) => {
          b.hasOwnProperty(m) || (b[m] = l);
        });
        if (k.hasAttribute("data-require-head") && !X(t).head_tag_slot_vars)
          throw new W(
            "AdSense head tag is missing. AdSense body tags don't work without the head tag. You can copy the head tag from your account on https://adsense.com."
          );
        if (!b.google_ad_client)
          throw new W("Ad client is missing from the slot.");
        if ((e = (X(Q).first_tag_on_page || 0) === 0 && co(b)))
          cp(h, (l) => {
            var m = Mf(l);
            Sc(m, 5) || ((l = Mf(l)), Zc(l, 5));
          }),
            Js(e);
        (X(Q).first_tag_on_page || 0) === 0 && (X(Q).first_tag_on_page = 2);
        b.google_pause_ad_requests = !!X(Q).pause_ad_requests;
        h = a.ofxVI;
        (e = h?.recYb?.LmpfC) &&
          kd(e, (l, m) => {
            b[m] = l;
          });
        Bq({
          xb: 1,
          Ka: k,
          ca: b,
          l: window,
          U: d,
          pb: c,
          ...(h?.bPXfr ? { ub: h.bPXfr } : {}),
        });
      }
    }
  }
  function vs(a) {
    return a.google_ad_client
      ? a.google_ad_client
      : (a = a.params) && a.google_ad_client
      ? a.google_ad_client
      : So(Q);
  }
  function Gs() {
    if (U(oj)) {
      let a = en(Q);
      (a && a.nb) || fn(Q);
    }
  }
  function Js(a) {
    ge(() => {
      $n(t).wasPlaTagProcessed || (t.adsbygoogle && t.adsbygoogle.push(a));
    });
  }
  function Hs(a, b, c) {
    (X(Q).first_tag_on_page || 0) === 0 && (X(Q).first_tag_on_page = 1);
    if (a.tag_partner) {
      var d = a.tag_partner,
        e = X(t);
      e.tag_partners = e.tag_partners || [];
      e.tag_partners.push(d);
    }
    U(qj) &&
      !jn(t) &&
      a.enable_page_level_ads !== !1 &&
      ((d = Pp(t, b, a.google_ad_client)),
      (e = Lp(b)),
      d === 1
        ? (typeof a.enable_page_level_ads !== "object" &&
            (a.enable_page_level_ads = {}),
          $p(a.enable_page_level_ads, d, !0))
        : d === 2 &&
          e &&
          ((a.in_page_banner = !1),
          (a.side_rails = !1),
          (a.overlays = !1),
          (a.vignettes = !1),
          Op(t, c, e)));
    eo(a, b);
    ws(a, b, c);
  }
  function Is(a, b) {
    if (a.google_ad_format === "rewarded") {
      if (a.google_ad_slot == null)
        throw new W("Rewarded format does not have valid ad slot");
      if (a.google_ad_loaded_callback == null)
        throw new W("Rewarded format does not have ad loaded callback");
      a.google_reactive_ad_format = 11;
      a.google_wrap_fullscreen_ad = !0;
      a.google_video_play_muted = !1;
      a.google_acr = a.google_ad_loaded_callback;
      delete a.google_ad_loaded_callback;
      delete a.google_ad_format;
    }
    var c = !!a.google_wrap_fullscreen_ad,
      d = c && !a?.skip_vpt_resize;
    if (d)
      (b = ts()),
        (b.dataset.adsbygoogleStatus = "reserved"),
        he.documentElement.appendChild(b);
    else if ((b = b.element)) {
      if (!ps(b) && (b.id ? (b = qs(b.id)) : (b = null), !b))
        throw new W("'element' has already been filled.");
      if (!("innerHTML" in b))
        throw new W("'element' is not a good DOM element.");
    } else if (((b = qs()), !b))
      throw new W(
        "All 'ins' elements in the DOM with class=adsbygoogle already have ads in them."
      );
    if (d) {
      d = Q;
      try {
        let f = (d || window).document,
          g = f.compatMode == "CSS1Compat" ? f.documentElement : f.body;
        var e = new Zd(g.clientWidth, g.clientHeight).round();
      } catch (f) {
        e = new Zd(-12245933, -12245933);
      }
      a.google_ad_height = e.height;
      a.google_ad_width = e.width;
    }
    c && (a.fsapi = !0);
    return b;
  }
  function Ks(a) {
    xk().S[Ak(26)] = !!Number(a);
  }
  function Ls(a) {
    Number(a)
      ? (X(Q).pause_ad_requests = !0)
      : ((X(Q).pause_ad_requests = !1),
        (a = () => {
          if (!X(Q).pause_ad_requests) {
            var b = {};
            let c;
            typeof window.CustomEvent === "function"
              ? (c = new CustomEvent(
                  "adsbygoogle-pub-unpause-ad-requests-event",
                  b
                ))
              : ((c = document.createEvent("CustomEvent")),
                c.initCustomEvent(
                  "adsbygoogle-pub-unpause-ad-requests-event",
                  !!b.bubbles,
                  !!b.cancelable,
                  b.detail
                ));
            Q.dispatchEvent(c);
          }
        }),
        t.setTimeout(a, 0),
        t.setTimeout(a, 1e3));
  }
  function Ms(a, b = !1) {
    var c = a.revenueMicros,
      d = a.revenueCurrency;
    if (x(d) && mb(c)) {
      a = P(ep);
      var e = new Pf();
      e = $c(e, 1, "CPM");
      e = $c(e, 2, "PRECISE");
      d = $c(e, 3, d);
      c = N(d, 4, c);
      b = B(c, 5, Hb(b));
      kp(a, kc(b));
    }
  }
  function Ns(a) {
    pb(a) &&
      Gr(window, "aevi", (b) => {
        try {
          let c = b.revenueMicros,
            d = b.revenueCurrency;
          mb(c) &&
            x(d) &&
            (Ms(b), a({ valueMicros: Math.floor(c / 1e3), currencyCode: d }));
        } catch {
          console.log(
            "onPaidEvent function call failed. Please follow the documentation: https://services.google.com/fh/files/helpcenter/adsense_ilar_implementation_guide.pdf"
          );
        }
      });
  }
  function Os(a) {
    pb(a) && window.setTimeout(a, 0);
  }
  function Ps(a) {
    var b = Math.floor(a / 1e3);
    a = (a % 1e3) * 1e6;
    var c = new Cf();
    b = Wc(c, 1, b);
    return M(b, 2, a);
  }
  function Ds(a, b) {
    var c = { ...Un() };
    b = Yn(Jd(b.hc, new Map(Object.entries(c)))).then((d) => {
      ls == null && (d.init(a), (ls = d), Qs(d));
    });
    sk(723, b);
    b.finally(() => {
      ms.length = 0;
      var d = Date.now(),
        e = d - Th;
      var f = new Df();
      e = Ps(e);
      f = E(f, 1, e);
      os >= 0 && ((d = Ps(d - os)), E(f, 2, d));
      d = P(ep);
      e = Ef(23);
      f = F(e, 14, Gf, f);
      jp(d, f);
    });
  }
  function Qs(a) {
    for (let [c, d] of ns) {
      var b = c;
      let e = d;
      e !== -1 && (t.clearTimeout(e), ns.delete(b));
    }
    for (b = 0; b < ms.length; b++) {
      if (ns.has(b)) continue;
      let c = ms[b],
        d = Es(c);
      qk(723, () => {
        d === 3
          ? a.handleAdConfig(c)
          : d === 2 && sk(730, a.handleAdBreakBeforeReady(c));
      });
    }
  }
  function Fs(a) {
    var b = ms.length;
    if (Es(a) === 2 && a.type === "preroll" && a.adBreakDone != null) {
      var c = a.adBreakDone;
      os === -1 && (os = Date.now());
      var d = t.setTimeout(() => {
        try {
          c({
            breakType: "preroll",
            breakName: a.name,
            breakFormat: "preroll",
            breakStatus: "timeout",
          }),
            ns.set(b, -1),
            jp(P(ep), Ef(22));
        } catch (e) {
          console.error(
            "[Ad Placement API] adBreakDone callback threw an error:",
            e instanceof Error ? e : Error(String(e))
          );
        }
      }, V(Gj) * 1e3);
      ns.set(b, d);
    }
  }
  (function (a, b, c, d = () => {}) {
    mk.J(vk);
    qk(166, () => {
      var e = window;
      if (!e.BGtEY) {
        e.BGtEY = !0;
        var f = new eh(2, a, void 0, void 0, void 0, void 0, Kh);
        try {
          Va((r) => {
            ck(f, 1191, r);
          });
        } catch (r) {}
        var g = Yq(b);
        Br(K(g, 2));
        d();
        ne(16, [1, z(g)]);
        var h = Qh(Ph(Q)) || Q,
          k = c(a, g),
          l = Q.document.currentScript === null ? 1 : br(k.kc);
        Ar(h, g, l, f);
        U(Dj) &&
          K(g, 29) &&
          Er(
            h.document,
            Id`https://googleads.g.doubleclick.net/pagead/managed/dict/${K(
              g,
              29
            )}/adsbygoogle`
          );
        cp(P(ep), (r) => {
          var q = J(r, 1) + 1;
          M(r, 1, q);
          Q.top === Q && ((q = J(r, 2) + 1), M(r, 2, q));
          q = Mf(r);
          Sc(q, 1) || ((r = Mf(r)), Zc(r, 1));
        });
        sk(1086, hp(l === 0));
        if (V(tj)) {
          h = Mr();
          Pr(h);
          let r = new Zq({
            Ja: nd(Q).location.href,
            xa: 9,
            Sa: Hd(Q, new Fr()),
            Bb: a,
          });
          Or(h, (q) => {
            q = {
              Wa: q.Wa,
              za: Qr(q.za),
              Ua: Rr(q.Ua),
              la: q.la ? Rr(q.la) : void 0,
              Ea: q.Ea,
            };
            var w = V(gj);
            if (r.sampler.na(w)) {
              var G = r.h,
                Y = G.Sa,
                Ea = G.Ja;
              G = G.Bb;
              var Fa = Math,
                sa = Fa.trunc;
              a: {
                if (globalThis.performance) {
                  var fa = performance.timeOrigin + performance.now();
                  if (Number.isFinite(fa) && fa > 0) break a;
                }
                fa = Date.now();
                fa = Number.isFinite(fa) && fa > 0 ? fa : 0;
              }
              q = {
                Sa: Y,
                Ja: Ea,
                Bb: G,
                xa: 9,
                Va: w,
                sb: sa.call(Fa, fa),
                ...q,
              };
              w = new Tf();
              w = Vc(w, 1, q.Wa);
              w = bd(w, 4, q.za);
              w = bd(w, 5, q.Ua);
              q.la !== void 0 && bd(w, 6, q.la);
              q.Ea !== void 0 && Vc(w, 7, q.Ea);
              q.sb !== void 0 && N(w, 2, q.sb);
              $c(w, 3, q.Ja);
              Y = new Uf();
              Y = Wc(Y, 1, q.Sa);
              q = Wc(Y, 2, q.Va);
              q = F(q, 10, Vf, w);
              Wg(r.pinger, q);
            }
          });
        }
        if ((!u("Trident") && !u("MSIE")) || xa(Ca(), 11) >= 0) {
          ok(U(Hj));
          vq();
          Pm(Ic(g, Vq, 26));
          try {
            cs();
          } catch {}
          uq();
          zs(k, g);
          qk(1755, () => {
            var r = Lp(g),
              q = So(Q);
            q && Pp(Q, g, q) === 2 && r && Op(Q, k, r);
          });
          h = e.adsbygoogle;
          if (!h || !h.loaded) {
            var m = new Vn(),
              n = new Vn();
            l = {
              push: (r) => {
                ss(r, k, g, m, n, f);
              },
              loaded: !0,
              pageState: Cr(g, m, n),
            };
            try {
              Object.defineProperty(l, "requestNonPersonalizedAds", {
                set: Ks,
              }),
                Object.defineProperty(l, "pauseAdRequests", { set: Ls }),
                Object.defineProperty(l, "onload", { set: Os }),
                Object.defineProperty(l, "onPaidEvent", { set: Ns });
            } catch {}
            var p = So(Q);
            P(Ud).i(xj.h, xj.defaultValue).includes(p) &&
              Gr(Q, "aevi", (r) => {
                Ms(r, !0);
              });
            if (h)
              for (let r of [
                "requestNonPersonalizedAds",
                "pauseAdRequests",
                "onPaidEvent",
              ])
                h[r] !== void 0 && (l[r] = h[r]);
            rs(h, k, g, m, n, f);
            e.adsbygoogle = l;
            h && (l.onload = h.onload);
          }
        }
      }
    });
  })(
    qg(),
    typeof sttc === "undefined" ? void 0 : sttc,
    function (a, b, c = !1) {
      b = J(b, 1) > 2012 ? `_fy${J(b, 1)}` : "";
      var d = Id`data:text/javascript,`;
      return {
        hc: Id`https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/slotcar_library${b}.js`,
        ec: c
          ? d
          : Id`https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/show_ads_impl${b}.js`,
        dc: c
          ? d
          : Id`https://pagead2.googlesyndication.com/pagead/managed/js/adsense/${a}/show_ads_impl_with_ama${b}.js`,
        tb: Id`https://securepubads.g.doubleclick.net/tag/js/gpt.js`,
        kc: /^(?:https?:)?\/\/(?:pagead2\.googlesyndication\.com|securepubads\.g\.doubleclick\.net)\/pagead\/(?:js\/)?(?:show_ads|adsbygoogle(_direct)?)\.js(?:[?#].*)?$/,
      };
    }
  );
}.call(
  this,
  '[2021,"r20261118","r20190131",1,null,null,null,".google.it",null,null,null,[[[null,619278254,null,[null,10]],[null,45696523,null,[]],[45693370,null,null,null,[[[6,null,null,3,null,2],[1]]]],[null,1130,null,[null,100]],[null,1340,null,[null,0.2]],[null,1338,null,[null,0.3]],[null,1339,null,[null,0.3]],[null,1032,null,[null,200],[[[12,null,null,null,4,null,"Android",["navigator.userAgent"]],[null,500]]]],[null,728201648,null,[null,100]],[null,1405,null,[]],[null,1224,null,[null,0.01]],[null,1346,null,[null,6]],[null,1347,null,[null,3]],[null,846334470,null,[null,1000]],[1393,null,null,[1]],[null,1394,null,[null,120]],[null,1396,null,[null,1000]],[null,1395,null,[null,500]],[null,1263,null,[null,-1]],[null,1323,null,[null,-1]],[null,1265,null,[null,-1]],[null,1264,null,[null,-1]],[1267,null,null,[1]],[null,66,null,[null,-1]],[null,65,null,[null,-1]],[null,null,null,[null,null,null,["en","de","fr","es","ja"]],null,1273],[null,null,null,[null,null,null,["44786015","44786016"]],null,1261],[970587529,null,null,[1]],[null,1404,null,[]],[null,1403,null,[]],[null,770241922,null,[null,1000]],[null,971334269,null,[null,1000]],[null,null,null,[null,null,null,["ca-pub-7178919035426667","ca-pub-6430486603399192","ca-pub-6217516951440692","ca-pub-3269777183832488","ca-pub-4286071012672876","ca-pub-6893876361346206","ca-pub-6865079278713445","ca-pub-6062692039613877","ca-pub-8700401253704627","ca-pub-7409460644561046","ca-pub-1807333429605702","ca-pub-4414232724432396","ca-pub-8878716159434368","ca-pub-1725310704471587","ca-pub-7286478979881995","ca-pub-5420212072167331","ca-pub-3001544606526418","ca-pub-7647808421428026","ca-pub-6109939056400055","ca-pub-6907038225839490","ca-pub-6462695325264077","ca-pub-9260533539525355","ca-pub-9284205722386242","ca-pub-0636857377230346","ca-pub-9067164180551135","ca-pub-9649286969563355","ca-pub-6150993149788596","ca-pub-0085763304086106"]],null,45736067],[null,992342422,null,[null,10]],[966532578,null,null,[1]],[998501692,null,null,[1]],[1009744664,null,null,[1]],[997970723,null,null,[1]],[622128248,null,null,[]],[842638817,null,null,[1]],[1014659745,null,null,[1]],[767123927,null,null,[1]],[997880417,null,null,[1]],[998734814,null,null,[1]],[null,null,null,[null,null,null,["","ar","bn","en","es","fr","hi","id","ja","ko","mr","pt","ru","sr","te","th","tr","uk","vi","zh"]],null,712458671],[null,1009763086,null,[null,5]],[null,null,null,[null,null,null,["14"]],null,null,null,683929765],[null,null,834418651,[null,null,"calc(max(\\u003cDH\\u003e - 150px, 50px))"]],[987379248,null,null,[1]],[1008729579,null,null,[1]],[1008757348,null,null,[1]],[null,775999093,null,[null,1]],[null,9601,null,[null,0.0001]],[null,618163195,null,[null,8000]],[null,624950166,null,[null,3000]],[null,623405755,null,[null,300]],[null,508040914,null,[null,622]],[null,547455356,null,[null,49]],[null,9603,null,[null,4]],[null,650548030,null,[null,3]],[null,650548032,null,[null,300]],[null,650548031,null,[null,1]],[null,469675170,null,[null,45000]],[null,836239785,null,[null,0.6]],[null,913774067,null,[null,100]],[458320011,null,null,[]],[null,458320009,null,[null,0.4]],[null,987076816,null,[null,100]],[675298507,null,null,[]],[711741274,null,null,[]],[776685355,null,null,[]],[570863962,null,null,[]],[null,null,570879859,[null,null,"control_1\\\\.\\\\d"]],[null,570863961,null,[null,50]],[570879858,null,null,[1]],[null,null,754933823,[null,null,"1-0-45"]],[null,1085,null,[null,5]],[null,63,null,[null,30]],[null,1080,null,[null,5]],[null,10019,null,[null,5]],[null,1027,null,[null,10]],[null,57,null,[null,120]],[null,1079,null,[null,5]],[null,1050,null,[null,30]],[null,732217386,null,[null,10000]],[null,794150639,null,[null,5000]],[null,732217387,null,[null,500]],[null,811376351,null,[null,0.5]],[null,733329086,null,[null,30000]],[null,629808663,null,[null,100]],[null,736623795,null,[null,250]],[null,745376892,null,[null,1]],[null,745376893,null,[null,2]],[null,550718588,null,[null,250]],[897236184,null,null,[1]],[1009054413,null,null,[1]],[null,624290870,null,[null,50]],[null,815871887,null,[null,0.8]],[506738118,null,null,[1]],[null,null,null,[null,null,null,["AlK2UR5SkAlj8jjdEc9p3F3xuFYlF6LYjAML3EOqw1g26eCwWPjdmecULvBH5MVPoqKYrOfPhYVL71xAXI1IBQoAAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==","Amm8/NmvvQfhwCib6I7ZsmUxiSCfOxWxHayJwyU1r3gRIItzr7bNQid6O8ZYaE1GSQTa69WwhPC9flq/oYkRBwsAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==","A9nrunKdU5m96PSN1XsSGr3qOP0lvPFUB2AiAylCDlN5DTl17uDFkpQuHj1AFtgWLxpLaiBZuhrtb2WOu7ofHwEAAACKeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9","A93bovR+QVXNx2/38qDbmeYYf1wdte9EO37K9eMq3r+541qo0byhYU899BhPB7Cv9QqD7wIbR1B6OAc9kEfYCA4AAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9","A1S5fojrAunSDrFbD8OfGmFHdRFZymSM/1ss3G+NEttCLfHkXvlcF6LGLH8Mo5PakLO1sCASXU1/gQf6XGuTBgwAAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"]],null,1934]],[[12,[[10,[[31061690],[31061691,[[83,null,null,[1]],[84,null,null,[1]]]]],null,61],[40,[[95340252],[95340253,[[662101537,null,null,[1]]]]],[4,null,9,null,null,null,null,["LayoutShift"]],71,null,null,null,800,null,null,null,null,null,5],[40,[[95340254],[95340255,[[662101539,null,null,[1]]]]],[4,null,9,null,null,null,null,["LayoutShift"]],71,null,null,null,800,null,null,null,null,null,5]]],[13,[[500,[[31061692],[31061693,[[77,null,null,[1]],[78,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]]]]],[4,null,6,null,null,null,null,["31061691","4"]]]]],[10,[[10,[[31084127],[31084128]]],[1,[[42531513],[42531514,[[316,null,null,[1]]]]]],[1,[[42531644],[42531645,[[368,null,null,[1]]]],[42531646,[[369,null,null,[1]],[368,null,null,[1]]]]]],[1,[[42532242],[42532243,[[1256,null,null,[1]],[290,null,null,[1]]]]]],[100,[[42533293],[42533294,[[1383,null,null,[1]],[null,54,null,[null,100]],[null,66,null,[null,10]],[null,65,null,[null,1000]]]]],null,145],[1,[[44801778],[44801779,[[506914611,null,null,[1]]]]],[4,null,55],143],[50,[[95390277],[95390278,[[566279275,null,null,[1]],[622128248,null,null,[1]],[566279276,null,null,[1]],[767123927,null,null,[]]]],[95407167,[[767123927,null,null,[]]]]],[4,null,55],143],[null,[[95396363],[95396364,[[944081220,null,null,[1]]]]],[4,null,55]],[1000,[[95402538,[[null,1346,null,[null,24]],[null,1347,null,[null,8]],[976718821,null,null,[1]],[1009993905,null,null,[1]]]]],[3,[[4,null,6,null,null,null,null,["95400948","4"]],[4,null,6,null,null,null,null,["95400949","4"]]]]],[300,[[95404663],[95404664,[[987550324,null,null,[1]]]],[95404669,[[987550831,null,null,[1]],[969848357,null,null,[1]],[null,469675170,null,[null,30000]]]]],[4,null,55]],[200,[[95408434],[95408436,[[992218248,null,null,[1]],[null,1010416287,null,[null,0.1]]]],[95408438,[[992218248,null,null,[1]],[null,1010416288,null,[null,0.1]],[null,1010416287,null,[null,0.1]]]],[95408439,[[992218248,null,null,[1]],[null,1010416288,null,[null,0.2]],[null,1010416287,null,[null,0.2]]]]],[4,null,55]],[50,[[95408927],[95408929,[[991595594,null,null,[1]]]]],[4,null,55]],[100,[[95409688],[95409689,[[1013701189,null,null,[1]]]]],[4,null,55]],[200,[[95409873],[95409874,[[null,992342421,null,[null,10]]]]],[4,null,55]],[50,[[95409937],[95409938,[[1002414048,null,null,[1]]]],[95409939,[[1002414049,null,null,[1]],[1002414048,null,null,[1]]]]],[4,null,55]],[10,[[95410011],[95410012,[[1009862211,null,null,[1]]]]],[4,null,55]],[100,[[95410045],[95410046,[[null,1014697151,null,[null,5]]]]],[4,null,55]],[100,[[95410874],[95410875,[[991129681,null,null,[1]],[1009684130,null,null,[1]]]]],[4,null,55],161],[50,[[95411484],[95411485,[[null,null,834418651,[null,null,"calc(max(\\u003cDH\\u003e - 200px, 50px))"]]]],[95411486,[[null,null,834418651,[null,null,"calc(max(\\u003cDH\\u003e - 250px, 50px))"]]]],[95411487,[[null,null,834418651,[null,null,"calc(\\u003cSW\\u003e / 1.2)"]]]]],[4,null,55],161],[10,[[95411583],[95411584,[[1010800604,null,null,[1]]]],[95411585,[[1009110750,null,null,[1]],[1010800604,null,null,[1]]]]]],[50,[[122881368],[122881369,[[982535665,null,null,[1]]]]],null,186,null,null,null,null,null,null,null,null,null,17],[200,[[122882241],[122882242,[[1008865096,null,null,[1]]]]]],[200,[[122882243],[122882244,[[1014718859,null,null,[1]]]]]]]],[17,[[10,[[31084487],[31084488]],null,null,null,null,32,null,null,142,1],[10,[[31089209],[31089210]],null,null,null,null,39,null,null,189,1],[50,[[95373848],[95373849]],null,null,null,null,47,40,null,189,1],[10,[[95375758],[95375759]],null,null,null,null,48,140,null,189,1],[10,[[95379673],[95379674]],null,null,null,null,50,160,null,189,1],[null,[[95393484],[95393485,[[917171616,null,null,[1]],[917676946,null,null,[1]]]]],[4,null,55],null,null,null,null,null,null,242,1],[null,[[95396251],[95396252,[[903704925,null,null,[1]],[907534769,null,null,[1]]]]],[4,null,55],null,null,null,null,500,null,242,1],[null,[[122881645],[122881646,[[1000079153,null,null,[1]],[947021890,null,null,[1]],[null,987076816,null,[null,1]]]],[122881647,[[947021890,null,null,[1]],[null,987076816,null,[null,1]]]],[122881814,[[1000079153,null,null,[1]],[1000079154,null,null,[1]],[947021890,null,null,[1]],[null,987076816,null,[null,1]]]],[122881815,[[1000079154,null,null,[1]],[947021890,null,null,[1]],[null,987076816,null,[null,1]]]]],null,null,null,null,54,null,null,244,1],[50,[[122882033],[122882034,[[1000079153,null,null,[1]],[947021890,null,null,[1]],[null,987076816,null,[null,1]]]],[122882035,[[947021890,null,null,[1]],[null,987076816,null,[null,1]]]]],[1,[[12,null,null,null,2,null,"^https?://([^:/?#@]+\\\\.)?(tmo\\\\.gg|plicy\\\\.net|tilannemedia\\\\.fi)\\\\.?([:/?#]|$)"]]],null,null,null,55,500,null,244,1]]],[32,[[1000,[[95400948,null,[2,[[6,null,null,22,null,1],[1,[[12,null,null,null,3,null,"\\\\bgoogle_force_gam\\\\b"]]]]]]],null,187,null,null,null,null,null,null,null,null,44],[1000,[[95400949,null,[3,[[6,null,null,22,null,2],[12,null,null,null,3,null,"\\\\bgoogle_force_gam\\\\b"]]]]],null,187,null,null,null,null,null,null,null,null,44]]],[20,[[50,[[95407211],[95407212,[[991768865,null,null,[1]],[991768866,null,null,[1]]]]],null,null,null,null,null,500,null,198,1]]]],null,null,[null,1000,1,1000]],null,null,null,null,null,1870667361,null,null,null,null,null,null,null,[1,0,0],[],null,"m202611100101"]'
));
