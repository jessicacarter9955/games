/**
 * @id5io/id5-api.js
 * @version v1.0.103
 * @link https://id5.io/
 * @license Apache-2.0
 */
!(function () {
  "use strict";
  function r(t, e) {
    var i,
      r = Object.keys(t);
    return (
      Object.getOwnPropertySymbols &&
        ((i = Object.getOwnPropertySymbols(t)),
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
        r.push.apply(r, i)),
      r
    );
  }
  function h(t) {
    for (var e = 1; e < arguments.length; e++) {
      var i = null != arguments[e] ? arguments[e] : {};
      e % 2
        ? r(Object(i), !0).forEach(function (e) {
            l(t, e, i[e]);
          })
        : Object.getOwnPropertyDescriptors
        ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(i))
        : r(Object(i)).forEach(function (e) {
            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(i, e));
          });
    }
    return t;
  }
  function c(e, t, i, r, s, n, o) {
    try {
      var a = e[n](o),
        c = a.value;
    } catch (e) {
      return void i(e);
    }
    a.done ? t(c) : Promise.resolve(c).then(r, s);
  }
  function i(a) {
    return function () {
      var e = this,
        o = arguments;
      return new Promise(function (t, i) {
        var r = a.apply(e, o);
        function s(e) {
          c(r, t, i, s, n, "next", e);
        }
        function n(e) {
          c(r, t, i, s, n, "throw", e);
        }
        s(void 0);
      });
    };
  }
  function l(e, t, i) {
    return (
      (t = (function (e) {
        e = (function (e, t) {
          if ("object" != typeof e || null === e) return e;
          var i = e[Symbol.toPrimitive];
          if (void 0 === i) return ("string" === t ? String : Number)(e);
          t = i.call(e, t || "default");
          if ("object" != typeof t) return t;
          throw new TypeError("@@toPrimitive must return a primitive value.");
        })(e, "string");
        return "symbol" == typeof e ? e : String(e);
      })(t)) in e
        ? Object.defineProperty(e, t, {
            value: i,
            enumerable: !0,
            configurable: !0,
            writable: !0,
          })
        : (e[t] = i),
      e
    );
  }
  function u() {
    return (u = Object.assign
      ? Object.assign.bind()
      : function (e) {
          for (var t = 1; t < arguments.length; t++) {
            var i,
              r = arguments[t];
            for (i in r)
              Object.prototype.hasOwnProperty.call(r, i) && (e[i] = r[i]);
          }
          return e;
        }).apply(this, arguments);
  }
  function s(e, t) {
    if (null == e) return {};
    var i,
      r = (function (e, t) {
        if (null == e) return {};
        for (var i, r = {}, s = Object.keys(e), n = 0; n < s.length; n++)
          (i = s[n]), 0 <= t.indexOf(i) || (r[i] = e[i]);
        return r;
      })(e, t);
    if (Object.getOwnPropertySymbols)
      for (var s = Object.getOwnPropertySymbols(e), n = 0; n < s.length; n++)
        (i = s[n]),
          0 <= t.indexOf(i) ||
            (Object.prototype.propertyIsEnumerable.call(e, i) && (r[i] = e[i]));
    return r;
  }
  function g(e, t) {
    return (
      (function (e) {
        if (Array.isArray(e)) return e;
      })(e) ||
      (function (e, t) {
        var i =
          null == e
            ? null
            : ("undefined" != typeof Symbol && e[Symbol.iterator]) ||
              e["@@iterator"];
        if (null != i) {
          var r,
            s,
            n,
            o,
            a = [],
            c = !0,
            d = !1;
          try {
            if (((n = (i = i.call(e)).next), 0 === t)) {
              if (Object(i) !== i) return;
              c = !1;
            } else
              for (
                ;
                !(c = (r = n.call(i)).done) &&
                (a.push(r.value), a.length !== t);
                c = !0
              );
          } catch (e) {
            (d = !0), (s = e);
          } finally {
            try {
              if (!c && null != i.return && ((o = i.return()), Object(o) !== o))
                return;
            } finally {
              if (d) throw s;
            }
          }
          return a;
        }
      })(e, t) ||
      a(e, t) ||
      (function () {
        throw new TypeError(
          "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
        );
      })()
    );
  }
  function a(e, t) {
    if (e) {
      if ("string" == typeof e) return n(e, t);
      var i = Object.prototype.toString.call(e).slice(8, -1);
      return "Map" ===
        (i = "Object" === i && e.constructor ? e.constructor.name : i) ||
        "Set" === i
        ? Array.from(e)
        : "Arguments" === i ||
          /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i)
        ? n(e, t)
        : void 0;
    }
  }
  function n(e, t) {
    (null == t || t > e.length) && (t = e.length);
    for (var i = 0, r = new Array(t); i < t; i++) r[i] = e[i];
    return r;
  }
  function f(e, t) {
    var i =
      ("undefined" != typeof Symbol && e[Symbol.iterator]) || e["@@iterator"];
    if (!i) {
      if (
        Array.isArray(e) ||
        (i = a(e)) ||
        (t && e && "number" == typeof e.length)
      ) {
        i && (e = i);
        var r = 0,
          t = function () {};
        return {
          s: t,
          n: function () {
            return r >= e.length ? { done: !0 } : { done: !1, value: e[r++] };
          },
          e: function (e) {
            throw e;
          },
          f: t,
        };
      }
      throw new TypeError(
        "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
      );
    }
    var s,
      n = !0,
      o = !1;
    return {
      s: function () {
        i = i.call(e);
      },
      n: function () {
        var e = i.next();
        return (n = e.done), e;
      },
      e: function (e) {
        (o = !0), (s = e);
      },
      f: function () {
        try {
          n || null == i.return || i.return();
        } finally {
          if (o) throw s;
        }
      },
    };
  }
  function o(e, t, i) {
    return (
      (function (e, t) {
        if (e !== t)
          throw new TypeError("Private static access of wrong provenance");
      })(e, t),
      i
    );
  }
  function p(e, t, i) {
    if (!t.has(e))
      throw new TypeError("attempted to get private field on non-instance");
    return i;
  }
  class e {
    debug() {}
    info() {}
    warn() {}
    error() {}
  }
  const v = new e();
  class d extends e {
    constructor(e, t) {
      super(), (this._prefix = e), (this._delegate = t);
    }
    debug() {
      for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
        t[i] = arguments[i];
      this._delegate.debug(new Date().toISOString(), this._prefix, ...t);
    }
    info() {
      for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
        t[i] = arguments[i];
      this._delegate.info(new Date().toISOString(), this._prefix, ...t);
    }
    warn() {
      for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
        t[i] = arguments[i];
      this._delegate.warn(new Date().toISOString(), this._prefix, ...t);
    }
    error() {
      for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
        t[i] = arguments[i];
      this._delegate.error(new Date().toISOString(), this._prefix, ...t);
    }
  }
  function _(e, t) {
    var i = "^\\d+(\\.\\d+(\\.\\d+){0,1}){0,1}$";
    if (e.match(i) && t.match(i)) {
      var r = e.split("."),
        s = t.split("."),
        i = (e) => parseInt(e) || 0,
        e = (e, t) => {
          t = e - t;
          return 0 == t ? 0 : t < 0 ? -1 : 1;
        },
        t = e(i(r[0]), i(s[0]));
      if (0 !== t) return t;
      t = e(i(r[1]), i(s[1]));
      return 0 === t ? e(i(r[2]), i(s[2])) : t;
    }
  }
  const t = "Array",
    m = "String",
    I = "Function",
    w = Object.prototype.toString;
  function y(e, t) {
    return w.call(e) === "[object " + t + "]";
  }
  function b(e) {
    return y(e, I);
  }
  function S(e) {
    return y(e, m);
  }
  function C(e) {
    return y(e, t);
  }
  function D(e) {
    return y(e, "Number");
  }
  function E(e) {
    return y(e, "Object");
  }
  function A(e) {
    return void 0 !== e;
  }
  function T(e) {
    if (!e || "string" != typeof e) return null;
    try {
      var t = new URL(e).origin;
      return t && "null" !== t ? t : null;
    } catch (e) {
      return null;
    }
  }
  function P() {
    return A(globalThis) &&
      A(globalThis.crypto) &&
      b(globalThis.crypto.randomUUID)
      ? globalThis.crypto.randomUUID()
      : "".concat((1e6 * Math.random()) | 0);
  }
  function O(t, i) {
    if (
      !(function (e) {
        if (!e) return 1;
        if (C(e) || S(e)) return !(0 < e.length);
        for (var t in e) if (hasOwnProperty.call(e, t)) return;
        return 1;
      })(t)
    ) {
      if (b(t.forEach)) return t.forEach(i, this);
      let e = 0;
      var r = t.length;
      if (0 < r) for (; e < r; e++) i(t[e], e, t);
      else for (e in t) hasOwnProperty.call(t, e) && i.call(this, t[e], e);
    }
  }
  function R(e, t) {
    let i = document.createElement("a");
    t && "noDecodeWholeURL" in t && t.noDecodeWholeURL
      ? (i.href = e)
      : (i.href = decodeURIComponent(e));
    t = t && "decodeSearchAsString" in t && t.decodeSearchAsString;
    return {
      href: i.href,
      protocol: (i.protocol || "").replace(/:$/, ""),
      hostname: i.hostname,
      port: +i.port,
      pathname: i.pathname.replace(/^(?!\/)/, "/"),
      search: t
        ? i.search
        : (t = i.search || "")
        ? t
            .replace(/^\?/, "")
            .split("&")
            .reduce((e, t) => {
              let i = t.split("="),
                r = g(i, 2),
                s = r[0],
                n = r[1];
              return (
                /\[\]$/.test(s)
                  ? ((s = s.replace("[]", "")),
                    (e[s] = e[s] || []),
                    e[s].push(n))
                  : (e[s] = n || ""),
                e
              );
            }, {})
        : {},
      hash: (i.hash || "").replace(/^#/, ""),
      host: i.host || window.location.host,
    };
  }
  function x(e) {
    return (
      (e.protocol || "http") +
      "://" +
      (e.host || e.hostname + (e.port ? ":".concat(e.port) : "")) +
      (e.pathname || "") +
      (e.search
        ? "?".concat(
            ((i = e.search || ""),
            Object.keys(i)
              .map((t) =>
                Array.isArray(i[t])
                  ? i[t].map((e) => "".concat(t, "[]=").concat(e)).join("&")
                  : "".concat(t, "=").concat(i[t])
              )
              .join("&"))
          )
        : "") +
      (e.hash ? "#".concat(e.hash) : "")
    );
    var i;
  }
  function F(i, e) {
    function r(e, t) {
      if (b(Math.imul)) return Math.imul(e, t);
      var i = (4194303 & e) * (t |= 0);
      return 4290772992 & e && (i += ((4290772992 & e) * t) | 0), 0 | i;
    }
    e = 1 < arguments.length && void 0 !== e ? e : 0;
    let s = 3735928559 ^ e,
      n = 1103547991 ^ e;
    for (let e = 0, t; e < i.length; e++)
      (t = i.charCodeAt(e)),
        (s = r(s ^ t, 2654435761)),
        (n = r(n ^ t, 1597334677));
    return (
      (s = r(s ^ (s >>> 16), 2246822507) ^ r(n ^ (n >>> 13), 3266489909)),
      (n = r(n ^ (n >>> 16), 2246822507) ^ r(s ^ (s >>> 13), 3266489909)),
      (4294967296 * (2097151 & n) + (s >>> 0)).toString()
    );
  }
  const L = "TRUE" === G("id5_debug").toUpperCase(),
    k = "TRACE" === G("id5_debug").toUpperCase(),
    U = Boolean(window.console);
  let N = !1;
  function j(e, t, i, r, s) {
    M() &&
      U &&
      e &&
      e.apply(
        console,
        [
          "%cID5 - ".concat(t, "#").concat(i),
          "color: #fff; background: #1c307e; padding: 1px 4px; border-radius: 3px;",
          r,
        ].concat(s)
      );
  }
  function M() {
    return L || k || N;
  }
  class V extends e {
    constructor(e, t) {
      super(),
        l(this, "_invocationId", void 0),
        l(this, "_origin", void 0),
        (this._invocationId = t),
        (this._origin = e);
    }
    debug() {
      for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
        t[i] = arguments[i];
      !(function (e, t) {
        for (
          var i = arguments.length, r = new Array(2 < i ? i - 2 : 0), s = 2;
          s < i;
          s++
        )
          r[s - 2] = arguments[s];
        j(console.info, e, t, "DEBUG", r);
      })(this._origin, this._invocationId, ...t);
    }
    info() {
      for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
        t[i] = arguments[i];
      !(function (e, t) {
        for (
          var i = arguments.length, r = new Array(2 < i ? i - 2 : 0), s = 2;
          s < i;
          s++
        )
          r[s - 2] = arguments[s];
        j(console.info, e, t, "INFO", r);
      })(this._origin, this._invocationId, ...t);
    }
    warn() {
      for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
        t[i] = arguments[i];
      !(function (e, t) {
        for (
          var i = arguments.length, r = new Array(2 < i ? i - 2 : 0), s = 2;
          s < i;
          s++
        )
          r[s - 2] = arguments[s];
        j(console.warn, e, t, "WARNING", r);
      })(this._origin, this._invocationId, ...t);
    }
    error() {
      for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
        t[i] = arguments[i];
      !(function (e, t) {
        for (
          var i = arguments.length, r = new Array(2 < i ? i - 2 : 0), s = 2;
          s < i;
          s++
        )
          r[s - 2] = arguments[s];
        j(console.error, e, t, "ERROR", r);
      })(this._origin, this._invocationId, ...t);
    }
  }
  function G(e) {
    const t = new RegExp("[\\?&]" + e + "=([^&#]*)"),
      i = t.exec(window.location.search);
    return null === i ? "" : decodeURIComponent(i[1].replace(/\+/g, " "));
  }
  const W = y,
    H = b,
    B = S,
    q = C,
    z = D,
    J = E,
    X = function (e) {
      return y(e, "Boolean");
    },
    Y = A;
  function K(e) {
    let t = new Image();
    (t.referrerPolicy = "origin"), (t.src = e);
  }
  function Z(e, t, i, r, s) {
    for (t = t.split ? t.split(".") : t, r = 0; r < t.length; r++)
      e = e ? e[t[r]] : s;
    return e === s ? i : e;
  }
  new V("ajax");
  const $ = (e) => null != e && "object" == typeof e;
  function Q(e, t) {
    if (!($(e) && $(t))) return e === t;
    if (q(e) && q(t))
      return (function (t, i) {
        var e = t.length === i.length;
        if (!e) return !1;
        for (let e = 0; e < t.length; e++) if (!Q(t[e], i[e])) return !1;
        return !0;
      })(e, t);
    var i = Object.keys(e),
      r = Object.keys(t);
    if (i.length !== r.length) return !1;
    for (var s = 0, n = i; s < n.length; s++) {
      var o = n[s];
      if (!Q(e[o], t[o])) return !1;
    }
    return !0;
  }
  const ee = {
    A: 0,
    B: 1,
    C: 2,
    D: 3,
    E: 4,
    F: 5,
    G: 6,
    H: 7,
    I: 8,
    J: 9,
    K: 10,
    L: 11,
    M: 12,
    N: 13,
    O: 14,
    P: 15,
    Q: 16,
    R: 17,
    S: 18,
    T: 19,
    U: 20,
    V: 21,
    W: 22,
    X: 23,
    Y: 24,
    Z: 25,
    a: 26,
    b: 27,
    c: 28,
    d: 29,
    e: 30,
    f: 31,
    g: 32,
    h: 33,
    i: 34,
    j: 35,
    k: 36,
    l: 37,
    m: 38,
    n: 39,
    o: 40,
    p: 41,
    q: 42,
    r: 43,
    s: 44,
    t: 45,
    u: 46,
    v: 47,
    w: 48,
    x: 49,
    y: 50,
    z: 51,
    0: 52,
    1: 53,
    2: 54,
    3: 55,
    4: 56,
    5: 57,
    6: 58,
    7: 59,
    8: 60,
    9: 61,
    "-": 62,
    _: 63,
    "+": 62,
    "/": 63,
  };
  const te = ["localStoragePurposeConsent", "ccpaString"],
    ie = "131",
    re = Object.freeze({
      NONE: "none",
      TCF_V1: "TCFv1",
      TCF_V2: "TCFv2",
      USP_V1: "USPv1",
      ID5_ALLOWED_VENDORS: "ID5",
      PREBID: "PBJS",
      GPP_V1_0: "GPPv1.0",
      GPP_V1_1: "GPPv1.1",
    }),
    se = Object.freeze({
      cmp: "cmp",
      partner: "partner",
      prebid: "prebid",
      none: "none",
    }),
    ne = Object.freeze({ TCFEUV2: 2, TCFCAV1: 5 });
  class oe {
    constructor(e, t) {
      l(this, "localStoragePurposeConsent", void 0),
        l(this, "vendorsConsentForId5Granted", void 0),
        (this.localStoragePurposeConsent = e),
        (this.vendorsConsentForId5Granted = t);
    }
    isGranted() {
      return (
        !1 !== this.localStoragePurposeConsent &&
        !1 !== this.vendorsConsentForId5Granted
      );
    }
    getDebugInfo(e, t) {
      const i = {};
      return (
        void 0 !== this.localStoragePurposeConsent &&
          (i[e + "-" + t + "-localStoragePurposeConsent"] =
            this.localStoragePurposeConsent),
        void 0 !== this.vendorsConsentForId5Granted &&
          (i[e + "-" + t + "-vendorsConsentForId5Granted"] =
            this.vendorsConsentForId5Granted),
        i
      );
    }
  }
  class ae {
    constructor() {
      var e =
          0 < arguments.length && void 0 !== arguments[0]
            ? arguments[0]
            : void 0,
        t =
          1 < arguments.length && void 0 !== arguments[1]
            ? arguments[1]
            : void 0,
        i =
          2 < arguments.length && void 0 !== arguments[2]
            ? arguments[2]
            : void 0,
        r =
          3 < arguments.length && void 0 !== arguments[3]
            ? arguments[3]
            : void 0,
        s =
          4 < arguments.length && void 0 !== arguments[4]
            ? arguments[4]
            : void 0;
      l(this, "version", void 0),
        l(this, "applicableSections", void 0),
        l(this, "gppString", void 0),
        l(this, "euTcfSection", void 0),
        l(this, "canadaTcfSection", void 0),
        (this.version = e),
        (this.applicableSections = t),
        (this.gppString = i),
        (this.euTcfSection = r),
        (this.canadaTcfSection = s);
    }
    isGranted() {
      var e;
      return this.applicableSections.includes(ne.TCFEUV2)
        ? null === (e = this.euTcfSection) || void 0 === e
          ? void 0
          : e.isGranted()
        : (this.applicableSections.includes(ne.TCFCAV1), !0);
    }
    getDebugInfo() {
      var e = {};
      return (
        void 0 !== this.euTcfSection &&
          u(e, this.euTcfSection.getDebugInfo(this.version, "tcfeuv2")),
        void 0 !== this.canadaTcfSection &&
          u(e, this.canadaTcfSection.getDebugInfo(this.version, "tcfcav1")),
        e
      );
    }
    static createFrom(e) {
      const t = u(new ae(), e);
      return (
        A(t.euTcfSection)
          ? (t.euTcfSection = u(new oe(), t.euTcfSection))
          : (void 0 === t.localStoragePurposeConsent &&
              void 0 === t.vendorsConsentForId5Granted) ||
            ((t.euTcfSection = new oe(
              e.localStoragePurposeConsent,
              e.vendorsConsentForId5Granted
            )),
            delete t.localStoragePurposeConsent,
            delete t.vendorsConsentForId5Granted),
        A(t.canadaTcfSection) &&
          (t.canadaTcfSection = u(new oe(), t.canadaTcfSection)),
        t
      );
    }
  }
  class ce {
    constructor() {
      l(this, "apiTypes", void 0),
        l(this, "gdprApplies", void 0),
        l(this, "consentString", void 0),
        l(this, "localStoragePurposeConsent", void 0),
        l(this, "allowedVendors", void 0),
        l(this, "ccpaString", void 0),
        l(this, "forcedGrantByConfig", void 0),
        l(this, "gppData", void 0),
        l(this, "source", void 0),
        l(this, "vendorsConsentForId5Granted", void 0),
        (this.apiTypes = []),
        (this.gdprApplies = !1),
        (this.consentString = void 0),
        (this.localStoragePurposeConsent = !1),
        (this.ccpaString = void 0),
        (this.allowedVendors = void 0),
        (this.forcedGrantByConfig = !1),
        (this.gppData = void 0);
    }
    localStorageGrant() {
      return !0 === this.forcedGrantByConfig
        ? new le(!0, de.FORCE_ALLOWED_BY_CONFIG)
        : 0 === this.apiTypes.length
        ? new le(!0, de.PROVISIONAL)
        : this._getLocalStorageGrantFromApi();
    }
    _getLocalStorageGrantFromApi() {
      const e = this.apiTypes,
        t = {};
      var i = {};
      e.includes(re.TCF_V1) &&
        ((t[re.TCF_V1] = this._isGranted()),
        this._addToDebugInfo(re.TCF_V1, this, i)),
        e.includes(re.TCF_V2) &&
          ((t[re.TCF_V2] = this._isGranted()),
          this._addToDebugInfo(re.TCF_V2, this, i)),
        e.includes(re.ID5_ALLOWED_VENDORS) &&
          (t[re.ID5_ALLOWED_VENDORS] = this.allowedVendors.includes(ie)),
        e.includes(re.USP_V1) && (t[re.USP_V1] = !0),
        e.includes(re.GPP_V1_0) &&
          ((t[re.GPP_V1_0] = this.gppData.isGranted()),
          u(i, this.gppData.getDebugInfo())),
        e.includes(re.GPP_V1_1) &&
          ((t[re.GPP_V1_1] = this.gppData.isGranted()),
          u(i, this.gppData.getDebugInfo()));
      var r = Object.keys(t)
        .map((e) => t[e])
        .reduce((e, t) => e && t, !0);
      return new le(r, de.CONSENT_API, t, i);
    }
    _addToDebugInfo(e, t, i) {
      return (
        void 0 !== t.localStoragePurposeConsent &&
          (i[e + "-localStoragePurposeConsent"] = t.localStoragePurposeConsent),
        void 0 !== t.vendorsConsentForId5Granted &&
          (i[e + "-vendorsConsentForId5Granted"] =
            t.vendorsConsentForId5Granted),
        i
      );
    }
    _isGranted() {
      return (
        !1 === this.gdprApplies ||
        (!0 === this.localStoragePurposeConsent &&
          !1 !== this.vendorsConsentForId5Granted)
      );
    }
    hashCode() {
      this.localStoragePurposeConsent, this.ccpaString;
      var e = s(this, te);
      return F(JSON.stringify(e));
    }
    static createFrom(e) {
      const t = u(new ce(), e);
      return (
        A(t.api) &&
          ((t.apiTypes = (function (e) {
            var t = e.api;
            if (t === re.NONE) return [];
            if (t !== re.PREBID) return [t];
            {
              const i = [];
              return (
                (A(e.gdprApplies) || A(e.consentString)) && i.push(re.TCF_V2),
                A(e.ccpaString) && i.push(re.USP_V1),
                A(e.gppData) &&
                  A(e.gppData.version) &&
                  i.push(e.gppData.version),
                i
              );
            }
          })(e)),
          (t.api = void 0)),
        E(t.gppData) && (t.gppData = ae.createFrom(t.gppData)),
        t
      );
    }
    getApiTypeData(e) {
      if (this.apiTypes.includes(e)) {
        if (e === re.USP_V1) return { ccpaString: this.ccpaString };
        if (e === re.TCF_V2)
          return {
            consentString: this.consentString,
            gdprApplies: this.gdprApplies,
            localStoragePurposeConsent: this.localStoragePurposeConsent,
          };
        if (e === re.GPP_V1_1 || e === re.GPP_V1_0) return this.gppData;
        if (e === re.ID5_ALLOWED_VENDORS)
          return { allowedVendors: this.allowedVendors };
      }
    }
    toConsents() {
      let e = {};
      return (
        A(this.gdprApplies) && (e.gdpr = this.gdprApplies),
        A(this.consentString) && (e.gdpr_consent = this.consentString),
        A(this.ccpaString) && (e.us_privacy = this.ccpaString),
        A(this.gppData) &&
          ((e.gpp = this.gppData.gppString),
          (e.gpp_sid = this.gppData.applicableSections.join(","))),
        e
      );
    }
  }
  const de = Object.freeze({
    FORCE_ALLOWED_BY_CONFIG: "force_allowed_by_config",
    ID5_CONSENT: "id5_consent",
    PROVISIONAL: "provisional",
    JURISDICTION: "jurisdiction",
    CONSENT_API: "consent_api",
  });
  class le {
    constructor(e, t) {
      var i =
          2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : {},
        r = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : {};
      l(this, "allowed", !1),
        l(this, "grantType", de.NONE),
        l(this, "api", {}),
        l(this, "_debugInfo", {}),
        (this.allowed = e),
        (this.grantType = t),
        (this.api = i),
        (this._debugInfo = r);
    }
    isDefinitivelyAllowed() {
      return this.allowed && this.grantType !== de.PROVISIONAL;
    }
  }
  const he = "undefined" != typeof Promise && "undefined" != typeof fetch;
  class ue {
    constructor(e) {
      var t =
        1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0;
      (this.url = e || "https://telemetry.id5-tech.io/v1/measurements"),
        (this._metadata = t);
    }
    publish(e) {
      var t =
        1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0;
      return e && 0 < e.length
        ? (e.forEach((e) =>
            (function (i) {
              Object.keys(i).forEach(function (e) {
                var t = i[e];
                t &&
                  (t instanceof Object
                    ? (i[e] = JSON.stringify(t))
                    : (i[e] = "".concat(t)));
              });
            })(e.tags)
          ),
          fetch(this.url, {
            method: "POST",
            referrerPolicy: "origin",
            headers: { "Content-Type": "text/plain" },
            mode: "no-cors",
            keepalive: !0,
            body: JSON.stringify({
              metadata: h(h({}, this._metadata), t),
              measurements: e,
            }),
          }))
        : Promise.resolve();
    }
  }
  class ge {
    constructor(e, t) {
      l(this, "_publisher", void 0),
        l(this, "_scheduled", void 0),
        (this.meterRegistry = e),
        (this._publisher = t);
      const i = this;
      this.meterRegistry.onUnregister(function () {
        const e = i._onUnloadPublishAbortController;
        if (e) return e.abort(), i.publish({ trigger: "unregister" });
      });
    }
    publish() {
      let t =
        0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : void 0;
      return Promise.resolve(this.meterRegistry.getAllMeasurements())
        .then((e) => this._publisher(e, t))
        .then(() => this.meterRegistry.reset());
    }
    schedulePublishAfterMsec(e) {
      const t = this;
      return (
        t._scheduled ||
          (setTimeout(
            () => (
              (t._scheduled = !1),
              t.publish({ trigger: "fixed-time", fixed_time_msec: e })
            ),
            e
          ),
          (t._scheduled = !0)),
        this
      );
    }
    schedulePublishBeforeUnload() {
      const e = this;
      var t =
        "undefined" != typeof AbortController ? new AbortController() : void 0;
      return (
        t &&
          (addEventListener(
            "beforeunload",
            () => e.publish({ trigger: "beforeunload" }),
            { capture: !1, signal: t.signal }
          ),
          (this._onUnloadPublishAbortController = t)),
        this
      );
    }
  }
  const pe = Object.freeze({});
  var ve = {
    EMPTY: pe,
    from: function (e) {
      return e ? (e instanceof Map ? Object.fromEntries(e) : e) : pe;
    },
    toString: function (e) {
      return Array.from(Object.entries(e), (e) => {
        var t = g(e, 2),
          e = t[0],
          t = t[1];
        return "".concat(e, "=").concat(t);
      })
        .sort()
        .toString();
    },
  };
  const _e = Object.freeze({
    TIMER: "TIMER",
    SUMMARY: "SUMMARY",
    COUNTER: "COUNTER",
  });
  class fe {
    constructor(e, t, i) {
      l(this, "name", void 0),
        l(this, "tags", void 0),
        l(this, "values", void 0),
        (this.name = e),
        (this.tags = ve.from(t)),
        (this.type = i),
        (this.values = []);
    }
    reset() {
      this.values = [];
    }
  }
  class me extends fe {
    constructor(e) {
      super(
        e,
        1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0,
        _e.TIMER
      );
    }
    startMeasurement() {
      try {
        return new Ie(this);
      } catch (e) {
        return;
      }
    }
    record(e) {
      try {
        isNaN(e) || this.values.push({ value: e, timestamp: Date.now() });
      } catch (e) {}
    }
    recordNow() {
      try {
        var e;
        this.record(
          0 | (null === (e = performance) || void 0 === e ? void 0 : e.now())
        );
      } catch (e) {}
    }
  }
  class Ie {
    constructor() {
      (this.timer =
        0 < arguments.length && void 0 !== arguments[0]
          ? arguments[0]
          : void 0),
        (this.startTime = performance.now());
    }
    record() {
      var t =
        0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : void 0;
      try {
        var i = (performance.now() - this.startTime) | 0;
        let e = t || this.timer;
        return e && e.record(i), i;
      } catch (e) {
        return;
      }
    }
  }
  class we extends fe {
    constructor(e) {
      super(
        e,
        1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0,
        _e.COUNTER
      );
    }
    inc() {
      var e =
        0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : 1;
      try {
        return (
          0 === this.values.length
            ? this.values.push({ value: e, timestamp: Date.now() })
            : ((this.values[0].value += e),
              (this.values[0].timestamp = Date.now())),
          this.values[0].value
        );
      } catch (e) {}
    }
  }
  class ye extends fe {
    constructor(e) {
      super(
        e,
        1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0,
        _e.SUMMARY
      );
    }
    record(e) {
      try {
        this.values.push({ value: e, timestamp: Date.now() });
      } catch (e) {}
    }
  }
  class be {
    has(e) {
      return !1;
    }
    set(e, t) {
      return this;
    }
    get(e) {}
    values() {
      return [];
    }
  }
  class Se extends be {
    has(e) {
      return void 0 !== this[e];
    }
    set(e, t) {
      return (this[e] = t), this;
    }
    get(e) {
      return this[e];
    }
    values() {
      return Object.entries(this).map((e) => {
        return g(e, 2)[1];
      });
    }
  }
  function Ce() {
    return new Ie();
  }
  function De(e) {
    return { partner: e };
  }
  class Ee extends class {
    constructor() {
      var e =
          0 < arguments.length && void 0 !== arguments[0]
            ? arguments[0]
            : new be(),
        t =
          1 < arguments.length && void 0 !== arguments[1]
            ? arguments[1]
            : void 0,
        i =
          2 < arguments.length && void 0 !== arguments[2]
            ? arguments[2]
            : void 0;
      l(this, "_registry", void 0),
        l(this, "commonTags", void 0),
        l(this, "_onUnregisterCallback", void 0),
        (this._registry = e),
        (this.commonTags = ve.from(t)),
        (this.commonPrefix = i);
    }
    getOrCreate(e, t, i) {
      var r = h(h({}, t), this.commonTags),
        t = this.commonPrefix ? this.commonPrefix + "." + e : e,
        e = "".concat(t, "[").concat(ve.toString(r), "]");
      if (this._registry.has(e)) return this._registry.get(e);
      r = i(t, r);
      return this._registry.set(e, r), r;
    }
    getAllMeasurements() {
      return this._registry
        .values()
        .map((e) => ({
          name: e.name,
          type: e.type,
          tags: e.tags,
          values: e.values,
        }))
        .filter(function (e) {
          return e.values && 0 < e.values.length;
        });
    }
    reset() {
      Array.from(this._registry.values()).forEach((e) => e.reset());
    }
    addCommonTags(e) {
      this.commonTags = h(h({}, this.commonTags), ve.from(e));
    }
    timer(e) {
      return this.getOrCreate(
        e,
        1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {},
        (e, t) => new me(e, t)
      );
    }
    counter(e) {
      return this.getOrCreate(
        e,
        1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {},
        (e, t) => new we(e, t)
      );
    }
    summary(e) {
      return this.getOrCreate(
        e,
        1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : {},
        (e, t) => new ye(e, t)
      );
    }
    unregister() {
      void 0 !== this._onUnregisterCallback && this._onUnregisterCallback(this);
    }
    onUnregister(e) {
      this._onUnregisterCallback = e;
    }
  } {
    constructor(e, t) {
      var i =
          2 < arguments.length && void 0 !== arguments[2]
            ? arguments[2]
            : void 0,
        r =
          3 < arguments.length && void 0 !== arguments[3]
            ? arguments[3]
            : void 0;
      super(
        4 < arguments.length && void 0 !== arguments[4]
          ? arguments[4]
          : new Se(),
        h(h({ source: e, version: t }, De(i)), r),
        "id5.api"
      );
    }
  }
  function Ae(e, t) {
    return e.counter(
      "consent.discrepancy.count",
      1 < arguments.length && void 0 !== t ? t : {}
    );
  }
  function Te(e, t, i) {
    return e.timer(
      "consent.request.time",
      h({ requestType: t }, 2 < arguments.length && void 0 !== i ? i : {})
    );
  }
  const Pe = Object.freeze({
      tcfv2: {
        objName: "__tcfapiCall",
        objKeys: ["command", "version"],
        returnObjName: "__tcfapiReturn",
      },
      uspv1: {
        objName: "__uspapiCall",
        objKeys: ["command", "version"],
        returnObjName: "__uspapiReturn",
      },
      gppv1: {
        objName: "__gppCall",
        objKeys: ["command", "parameter"],
        returnObjName: "__gppReturn",
      },
    }),
    Oe = Object.freeze({ TCF: 0, USP: 1, GPP: 2 });
  class Re {
    constructor(e, t) {
      l(this, "direct", void 0),
        l(this, "version", void 0),
        (this.direct = e),
        (this.version = t);
    }
    getConsentData() {
      var e = this;
      return i(function* () {
        return e.getClientConsentData();
      })();
    }
    static create(a, c) {
      return i(function* () {
        var e = Ue._findCmpApi("__gpp"),
          t = e.cmpApiFrame,
          e = e.cmpApiFunction;
        let i,
          r = !1;
        if (!t)
          return (
            a.warn("cmpApi: GPP not found! Using defaults."), Promise.resolve()
          );
        if (H(e))
          (r = !0),
            a.info(
              "cmpApi: Detected GPP is directly accessible, calling it now."
            ),
            (i = e);
        else {
          a.info(
            "cmpApi: Detected GPP is outside the current iframe. Using message passing."
          );
          const o = Ue._buildCmpSurrogate(Pe.gppv1, t);
          i = function (e, t, i) {
            o(e, i, t);
          };
        }
        var s = yield new Promise((t) => {
          var e = i("ping", function (e) {
            t(e);
          });
          J(e) && t(e);
        });
        switch (s.gppVersion) {
          case Fe.version:
            return new Fe(s, i, r);
          case ke.version:
            return new ke(s, i, r, c);
          default:
            var n = "Unsupported version of gpp: ".concat(s.gppVersion);
            return a.warn(n), Promise.reject(n);
        }
      })();
    }
    static caTcfDataHasExpressConsent(e) {
      e = e.PurposesExpressConsent;
      if (q(e) && 0 < e.length) return !0 === e[9];
    }
    static caTcfDataHasVendorExpressConsent(e) {
      let t = e.VendorExpressConsent;
      if (q(t) && 0 < t.length) return void 0 !== t.find((e) => e == ie);
    }
    static tcfDataHasLocalStorageGrant(e) {
      e = o(Re, Re, xe).call(Re, e, "PurposeConsent", "PurposeConsents");
      if (q(e) && 0 < e.length) return !0 === e[0];
    }
    static tcfDataHasID5VendorConsented(e) {
      let t = o(Re, Re, xe).call(Re, e, "VendorConsent", "VendorConsents");
      if (0 < t.length)
        return (
          void 0 !==
          (null === t || void 0 === t ? void 0 : t.find((e) => e == ie))
        );
    }
    static getTcfData(e) {
      let t = void 0;
      return q(e) && J(e[0]) ? (t = e[0]) : J(e) && (t = e), t;
    }
  }
  function xe(e, t, i) {
    return t in e ? e[t] : e[i];
  }
  class Fe extends Re {
    constructor(e, t, i) {
      super(i, Fe.version),
        l(this, "gppFn", void 0),
        l(this, "ready", void 0),
        (this.gppFn = t),
        (this.ready = this.isReady(e));
    }
    isReady(e) {
      return "loaded" === e.cmpStatus && "visible" !== e.cmpDisplayStatus;
    }
    getClientConsentData() {
      var r = this;
      return i(function* () {
        r.ready ||
          (r.ready = yield new Promise((t) => {
            r.gppFn(
              "addEventListener",
              (e) => !!r.isReady(e.pingData) && void t(!0)
            );
          }));
        var e = new Promise((t) => {
            r.gppFn("getGPPData", (e) => {
              t(e);
            });
          }),
          t = new Promise((t) => {
            r.gppFn(
              "getSection",
              (e) => {
                t(e);
              },
              "tcfeuv2"
            );
          }),
          e = g(yield Promise.all([e, t]), 2),
          t = e[0],
          e = e[1];
        const i = new ae(re.GPP_V1_0, t.applicableSections, t.gppString);
        return (
          e &&
            (i.euTcfSection = new oe(
              Re.tcfDataHasLocalStorageGrant(e),
              Re.tcfDataHasID5VendorConsented(e)
            )),
          i
        );
      })();
    }
  }
  function Le(e, t, i) {
    i && (e.apiTypes.push(t), u(e, i));
  }
  l(Fe, "version", "1.0");
  class ke extends Re {
    constructor(e, t, i, r) {
      super(i, ke.version),
        l(this, "gppFn", void 0),
        l(this, "readyPingData", void 0),
        l(this, "metrics", void 0),
        (this.gppFn = t),
        "ready" === e.signalStatus && (this.readyPingData = e),
        (this.metrics = r);
    }
    getClientConsentData() {
      var o = this;
      return i(function* () {
        const n = o.metrics;
        return new Promise((i) => {
          let r = !1;
          if (o.readyPingData) i(o.parsePingData(o.readyPingData));
          else {
            const s = Date.now();
            let t = setTimeout(() => {
              (t = void 0),
                o.gppFn("ping", (e) => {
                  "stub" === e.cmpStatus &&
                    (n.counter("gpp.stubUsed", { cmpId: e.cmpId }).inc(),
                    i(o.parsePingData(e)));
                });
            }, 1e3);
            o.gppFn(
              "addEventListener",
              (e) =>
                "ready" === e.pingData.signalStatus &&
                void (r
                  ? ke.measureAdditionalEvent(e, n, s)
                  : (t
                      ? (clearTimeout(t), (t = void 0))
                      : r ||
                        n
                          .timer("gpp.lateCmp", { cmpId: e.pingData.cmpId })
                          .record(Date.now() - s),
                    i(o.parsePingData(e.pingData)),
                    (r = !0)))
            );
          }
        });
      })();
    }
    static measureAdditionalEvent(e, t, i) {
      [
        "cmpStatus",
        "cmpDisplayStatus",
        "signalStatus",
        "sectionChange",
      ].includes(e.eventName) &&
        t
          .timer("gpp.additionalEvents", {
            cmpId: e.pingData.cmpId,
            name: e.eventName,
          })
          .record(Date.now() - i);
    }
    parsePingData(e) {
      const t = new ae(re.GPP_V1_1, e.applicableSections, e.gppString);
      var i;
      return (
        !t.applicableSections.includes(ne.TCFEUV2) ||
          ((i = Re.getTcfData(
            null === (i = e.parsedSections) || void 0 === i ? void 0 : i.tcfeuv2
          )) &&
            (t.euTcfSection = new oe(
              Re.tcfDataHasLocalStorageGrant(i),
              Re.tcfDataHasID5VendorConsented(i)
            ))),
        !t.applicableSections.includes(ne.TCFCAV1) ||
          ((e = Re.getTcfData(
            null === (e = e.parsedSections) || void 0 === e ? void 0 : e.tcfcav1
          )) &&
            (t.canadaTcfSection = new oe(
              Re.caTcfDataHasExpressConsent(e),
              Re.caTcfDataHasVendorExpressConsent(e)
            ))),
        t
      );
    }
  }
  l(ke, "version", "1.1");
  class Ue {
    constructor(e) {
      var t =
        1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : v;
      l(this, "_lookupInProgress", void 0),
        l(this, "_log", void 0),
        l(this, "_metrics", void 0),
        l(this, "_consentDataPromise", void 0),
        (this._metrics = e),
        (this._log = t);
    }
    refreshConsentData(e, t, i) {
      const r = this;
      return (
        r._lookupInProgress ||
          ((r._lookupInProgress = !0),
          (r._consentDataPromise = this._lookupConsentData(e, t, i).finally(
            () => {
              r._lookupInProgress = !1;
            }
          ))),
        this._consentDataPromise
      );
    }
    _lookupConsentData(e, t, i) {
      if (e) {
        this._log.warn(
          "cmpApi: ID5 is operating in forced consent mode and will not retrieve any consent signals from the CMP"
        );
        let e = new ce();
        return (
          (e.forcedGrantByConfig = !0),
          (e.source = se.partner),
          Promise.resolve(e)
        );
      }
      switch (t) {
        case "static":
          return new Promise((e) => {
            this._parseStaticConsentData(i, e);
          });
        case "iab":
          return new Promise((e) => {
            this._lookupIabConsent(e);
          });
        default:
          return (
            this._log.error("cmpApi: Unknown consent API: ".concat(t)),
            Promise.reject(new Error("Unknown consent API: ".concat(t)))
          );
      }
    }
    _parseStaticConsentData(e, t) {
      e = e || {};
      let i = new ce();
      if (((i.source = se.partner), J(e.getTCData))) {
        const r = this._parseTcfData(e.getTCData);
        Le(i, re.TCF_V2, r);
        try {
          const s = this._metrics;
          this._lookupTcf((e) => {
            Ae(s, {
              apiType: re.TCF_V2,
              sameString:
                (null == e ? void 0 : e.consentString) ===
                (null === r || void 0 === r ? void 0 : r.consentString),
              sameLSPC:
                (null == e ? void 0 : e.localStoragePurposeConsent) ===
                (null === r || void 0 === r
                  ? void 0
                  : r.localStoragePurposeConsent),
              sameVendorsConsentForId5Granted:
                (null == e ? void 0 : e.vendorsConsentForId5Granted) ===
                (null === r || void 0 === r
                  ? void 0
                  : r.vendorsConsentForId5Granted),
              sameGdpr:
                (null == e ? void 0 : e.gdprApplies) ===
                (null === r || void 0 === r ? void 0 : r.gdprApplies),
            }).inc();
          });
        } catch (e) {}
      }
      if (
        (q(e.allowedVendors) &&
          Le(i, re.ID5_ALLOWED_VENDORS, {
            allowedVendors: e.allowedVendors.map((e) => e.toString()),
            gdprApplies: !0,
          }),
        J(e.getUSPData))
      ) {
        const n = this._parseUspData(e.getUSPData);
        Le(i, re.USP_V1, n);
        try {
          const o = this._metrics;
          this._lookupUsp((e) => {
            Ae(o, {
              apiType: re.USP_V1,
              sameString:
                (null == e ? void 0 : e.ccpaString) ===
                (null === n || void 0 === n ? void 0 : n.ccpaString),
            }).inc();
          });
        } catch (e) {}
      }
      0 === i.apiTypes.length &&
        this._log.warn(
          "cmpApi: No static consent data detected! Using defaults."
        ),
        this._log.info(
          "cmpApi: Detected APIs '".concat(
            i.apiTypes,
            "' from static consent data"
          ),
          e
        ),
        t(i);
    }
    _lookupIabConsent(r) {
      const s = [];
      let n = new ce();
      n.source = se.cmp;
      var e = (i) => (
          (s[i] = 0),
          (e, t) => {
            s[i] ||
              ((s[i] = Date.now()),
              e && Le(n, t, e),
              s.every((e) => 0 < e) && r(n));
          }
        ),
        t = e(Oe.TCF),
        i = e(Oe.USP),
        e = e(Oe.GPP);
      this._lookupGpp(e), this._lookupTcf(t), this._lookupUsp(i);
    }
    _lookupUsp(i) {
      var e = Ue._findCmpApi("__uspapi"),
        t = e.cmpApiFrame,
        e = e.cmpApiFunction;
      let r;
      if (!t)
        return (
          this._log.warn("cmpApi: USP not found! Using defaults for CCPA."),
          void i()
        );
      r = H(e)
        ? (this._log.info(
            "cmpApi: Detected USP is directly accessible, calling it now."
          ),
          e)
        : (this._log.info(
            "cmpApi: Detected USP is outside the current iframe. Using message passing."
          ),
          Ue._buildCmpSurrogate(Pe.uspv1, t));
      r("getUSPData", 1, (e, t) => {
        t
          ? i(this._parseUspData(e), re.USP_V1)
          : (this._log.error(
              "cmpApi: USP callback not successful. Using defaults for CCPA."
            ),
            i());
      });
    }
    _lookupGpp(n) {
      var o = this;
      return i(function* () {
        var t = Date.now();
        try {
          let e = yield Re.create(o._log, o._metrics);
          if (e) {
            var i = { gppVersion: e.version, directCmp: e.direct };
            try {
              var r = yield e.getConsentData();
              n({ gppData: r }, r.version);
              var s = Date.now();
              o._metrics.timer("gpp.delay", i).record(s - t);
            } catch (e) {
              o._metrics
                .counter("gpp.failure", u({ type: "CONSENT" }, i))
                .inc(),
                o._log.error(
                  "cmpApi: getting GPP consent not successful. Using defaults for Gpp."
                ),
                n();
            }
          } else n();
        } catch (e) {
          o._metrics.counter("gpp.failure", { type: "CLIENT" }).inc(),
            o._log.error(
              "cmpApi: creating GPP client not successful. Using defaults for Gpp."
            ),
            n();
        }
      })();
    }
    static _buildCmpSurrogate(a, c) {
      return (e, t, i) => {
        const r = Math.random() + "",
          s = {},
          n = {};
        (n[a.objKeys[0]] = e),
          (n[a.objKeys[1]] = t),
          (n.callId = r),
          (s[a.objName] = n);
        const o = (e) => {
          e = Z(e, "data.".concat(a.returnObjName));
          e &&
            e.callId === r &&
            ((void 0 !== (e = i(e.returnValue, e.success)) && !0 !== e) ||
              window.removeEventListener("message", o));
        };
        window.addEventListener("message", o, !1), c.postMessage(s, "*");
      };
    }
    _lookupTcf(e) {
      var t = Ue._findTCF(),
        i = t.cmpFrame,
        t = t.cmpFunction;
      if (!i)
        return (
          this._log.warn("cmpApi: TCF not found! Using defaults for GDPR."),
          void e()
        );
      H(t)
        ? this._lookupDirectTcf(t, e)
        : (this._log.info(
            "cmpApi: Detected TCF is outside the current iframe. Using message passing."
          ),
          this._lookupMessageTcf(i, e));
    }
    _lookupMessageTcf(e, t) {
      e = Ue._buildCmpSurrogate(Pe.tcfv2, e);
      this._lookupDirectTcf(e, t);
    }
    _lookupDirectTcf(e, s) {
      const n = this._log;
      e("addEventListener", 2, (e, t) => {
        var i, r;
        return (
          (i = "event"),
          (r = e),
          n.info("cmpApi: TCFv2 - Received a call back: ".concat(i), r),
          t
            ? !(
                !e ||
                (!1 !== e.gdprApplies &&
                  "tcloaded" !== e.eventStatus &&
                  "useractioncomplete" !== e.eventStatus)
              ) && void s(this._parseTcfData(e), re.TCF_V2)
            : (n.error(
                "cmpApi: TCFv2 - Received insuccess: ".concat(
                  "addEventListener",
                  ". Please check your CMP setup. Using defaults for GDPR."
                )
              ),
              void s())
        );
      });
    }
    _parseUspData(e) {
      if (J(e) && B(e.uspString)) return { ccpaString: e.uspString };
      this._log.error(
        "cmpApi: No or malformed USP data. Using defaults for CCPA."
      );
    }
    _parseTcfData(e) {
      let t = this._log,
        i,
        r;
      if (((i = Ue._isValidV2ConsentObject), (r = Ue._normalizeV2Data), i(e)))
        return r(e);
      t.error("cmpApi: Invalid CMP data. Using defaults for GDPR.", e);
    }
    static _isValidV2ConsentObject(e) {
      var t = e && e.gdprApplies,
        e = e && e.tcString;
      return !1 === t || B(e);
    }
    static _tcfDataHasID5VendorConsented(e) {
      var t, i;
      return (
        !0 ===
        (null == e ||
        null === (t = e.vendor) ||
        void 0 === t ||
        null === (i = t.consents) ||
        void 0 === i
          ? void 0
          : i[ie])
      );
    }
    static _normalizeV2Data(e) {
      let t = Z(e, "purpose.consents.1");
      X(t) ||
        (t = (function (e, t) {
          var i = 152 + t - 1,
            t = ~~(i / 6);
          if (e && "C" === e.charAt(0) && !(e.length <= t)) {
            (t = e.charAt(t)), (t = ee[t]);
            if (void 0 !== t) return 0 != (t & (1 << (6 - (i % 6) - 1)));
          }
        })(e.tcString, 1));
      var i = Ue._tcfDataHasID5VendorConsented(e);
      return {
        consentString: e.tcString,
        localStoragePurposeConsent: t,
        gdprApplies: e.gdprApplies,
        vendorsConsentForId5Granted: i,
      };
    }
    static _findTCF() {
      let e = window,
        t,
        i;
      for (; !t; ) {
        try {
          if ("function" == typeof e.__tcfapi) {
            (i = e.__tcfapi), (t = e);
            break;
          }
        } catch (e) {}
        try {
          if (e.frames.__tcfapiLocator) {
            t = e;
            break;
          }
        } catch (e) {}
        if (e === window.top) break;
        e = e.parent;
      }
      return { cmpFrame: t, cmpFunction: i };
    }
    static _findCmpApi(e) {
      let t = window,
        i,
        r;
      for (; !i; ) {
        try {
          if ("function" == typeof t[e]) {
            (r = t[e]), (i = t);
            break;
          }
        } catch (e) {}
        try {
          if (t.frames["".concat(e, "Locator")]) {
            i = t;
            break;
          }
        } catch (e) {}
        if (t === window.top) break;
        t = t.parent;
      }
      return { cmpApiFrame: i, cmpApiFunction: r };
    }
  }
  const Ne = Object.freeze({
      CONSENT_UPDATED: "consent_updated",
      USER_ID_READY: "user_id_ready",
      CASCADE_NEEDED: "fire_sync_pixel",
      USER_ID_FETCH_CANCELED: "user_id_fetch_canceled",
      USER_ID_FETCH_FAILED: "user_id_fetch_failed",
    }),
    je = Object.freeze({
      ID5_MESSAGE_RECEIVED: "message",
      ID5_INSTANCE_JOINED: "instance-joined",
      ID5_LEADER_ELECTED: "leader-elected",
    }),
    Me = Object.freeze([...Object.values(je), ...Object.values(Ne)]);
  class Ve {
    constructor() {
      var e =
        0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : v;
      l(this, "_handlers", void 0),
        l(this, "_log", void 0),
        (this._log = e),
        (this._handlers = {});
    }
    _dispatch(t) {
      var e = this._handlers[t];
      if (e) {
        for (
          var i = arguments.length, r = new Array(1 < i ? i - 1 : 0), s = 1;
          s < i;
          s++
        )
          r[s - 1] = arguments[s];
        var n,
          o = f(e);
        try {
          for (o.s(); !(n = o.n()).done; ) {
            const a = n.value;
            try {
              a(...r);
            } catch (e) {
              this._log.error(
                "Event ".concat(t, " handler execution failed."),
                e
              );
            }
          }
        } catch (e) {
          o.e(e);
        } finally {
          o.f();
        }
      }
    }
    emit(e) {
      if (void 0 !== e && Me.includes(e)) {
        for (
          var t = arguments.length, i = new Array(1 < t ? t - 1 : 0), r = 1;
          r < t;
          r++
        )
          i[r - 1] = arguments[r];
        this._dispatch(e, ...i);
      } else this._log.warn("Unsupported event", e);
    }
    on(e, t) {
      void 0 !== e && Me.includes(e)
        ? (this._handlers[e] || (this._handlers[e] = []),
          this._handlers[e].push(t))
        : this._log.warn("Unsupported event", e);
    }
  }
  const Ge = [
      "aHR0cHM6Ly9mZXRjaC5idWxrYW55b24uYmlk",
      "aHR0cHM6Ly9mZXRjaC5mbGVza29yYW4ueHl6",
      "aHR0cHM6Ly9mZXRjaC5taXZhcnF1ZW4ueHl6",
    ],
    We = {
      fetch: "https://id5-sync.com/gm/v3",
      bounce: "https://id5-sync.com/bounce",
      event: "https://id5-sync.com/event",
      cascadeHost: "https://id5-sync.com",
      analytics: "https://analytics.id5-tech.io/v1/config",
      diagnostics: "https://telemetry.id5-tech.io/v1/measurements",
    },
    He = new URL(We.fetch).origin;
  function Be(e) {
    return (e || "").replace(/\/+$/, "");
  }
  class qe {
    constructor() {
      const i = Be(
        0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : ""
      );
      (this.apiBase = i), (this.isFallback = !!i);
      var e = (e, t) => (i ? "".concat(i).concat(e) : t);
      (this.fetch = e("/gm/v3", We.fetch)),
        (this.bounce = We.bounce),
        (this.event = e("/event", We.event)),
        (this.diagnostics = e("/diag/measurements", We.diagnostics)),
        (this._analytics = e("/analytics", We.analytics)),
        (this._cascade = We.cascadeHost);
    }
    analytics(e, t) {
      return "".concat(this._analytics, "/").concat(t, "/").concat(e);
    }
    cascade(e, t, i) {
      return new URL(
        ""
          .concat(this._cascade, "/")
          .concat(e, "/")
          .concat(t, "/")
          .concat(i, ".gif")
      );
    }
  }
  const ze = new qe();
  var Je = new WeakSet();
  class Xe {
    constructor() {
      var e =
        0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "";
      let t =
        1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : Ge;
      Je.add(this);
      e = Be(e);
      (this._configuredApiBase = e === He ? "" : e),
        (this._alternateApiBases = t.map((e) => atob(e)));
    }
    getEndpoints() {
      if (!this._endpoints) {
        var e = this._alternateApiBases,
          e =
            this._configuredApiBase ||
            (0 < e.length ? e[Math.floor(Math.random() * e.length)] : "");
        if (!e) return;
        this._endpoints = new qe(e);
      }
      return this._endpoints;
    }
    retryFor(e) {
      return e.isFallback ? ze : this.getEndpoints();
    }
    endpointsForApiBase(e) {
      return "" === e
        ? ze
        : p(this, Je, Ye).call(this, e)
        ? (this.getEndpoints().apiBase !== e && (this._endpoints = new qe(e)),
          this._endpoints)
        : void 0;
    }
  }
  function Ye(e) {
    return (
      "string" == typeof e &&
      (this._configuredApiBase
        ? e === this._configuredApiBase
        : this._alternateApiBases.includes(e))
    );
  }
  class Ke {
    constructor(e, t, i, r, s, n, o) {
      l(this, "_called", void 0),
        l(this, "_callbackFn", void 0),
        l(this, "_callbackArgs", void 0),
        l(this, "_beforeTrigger", void 0),
        l(this, "_watchdog", void 0),
        l(this, "_log", void 0),
        l(this, "_metrics", void 0),
        l(this, "_callbackName", void 0),
        (this._callbackName = e),
        (this._log = t),
        (this._metrics = i),
        (this._callbackFn = r);
      for (
        var a = arguments.length, c = new Array(7 < a ? a - 7 : 0), d = 7;
        d < a;
        d++
      )
        c[d - 7] = arguments[d];
      (this._callbackArgs = c),
        (this._beforeTrigger = o),
        (this._called = !1),
        (this._callbackTriggerTimer = Ce()),
        (this._timeout = s),
        n
          ? (this._watchdog = setTimeout(() => this._trigger("immediate"), 0))
          : 0 < s &&
            (this._watchdog = setTimeout(() => this._trigger("timeout"), s));
    }
    _trigger() {
      let e =
        0 < arguments.length && void 0 !== arguments[0]
          ? arguments[0]
          : "unknown";
      this._watchdog = void 0;
      let t = this._callbackTriggerTimer.record(
        this._metrics.timer("callback.trigger.time", {
          trigger: e,
          callbackName: this._callbackName,
          timeout: this._timeout,
        })
      );
      this._called ||
        ((this._called = !0),
        setTimeout(() => {
          this._log.debug(
            "Firing "
              .concat(this._callbackName, " callback after ")
              .concat(t, "ms. Triggered by ")
              .concat(e, ", configured timeoutMs=")
              .concat(this._timeout)
          ),
            this._beforeTrigger(),
            this._callbackFn.call(globalThis, ...this._callbackArgs);
        }, 0));
    }
    triggerNow() {
      var e =
        0 < arguments.length && void 0 !== arguments[0]
          ? arguments[0]
          : "eventOccurred";
      this.disableWatchdog(), this._trigger(e);
    }
    disableWatchdog() {
      this._watchdog &&
        (clearTimeout(this._watchdog), (this._watchdog = void 0));
    }
  }
  const Ze = "1.0.103",
    $e = Object.freeze({
      NEVER: "never",
      AFTER_UID_SET: "after-uid-set",
      ASAP: "asap",
    }),
    Qe = Object.freeze({ allowGCReclaim: Object.values($e) });
  class et {
    constructor(e) {
      var t =
        1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : v;
      if (
        (l(this, "invocationId", void 0),
        l(this, "options", void 0),
        l(this, "providedOptions", void 0),
        l(this, "invalidSegments", void 0),
        (this._log = t),
        (this.options = {
          debugBypassConsent: !1,
          allowLocalStorageWithoutConsentApi: !1,
          cmpApi: "iab",
          consentData: {},
          refreshInSeconds: 7200,
          partnerId: void 0,
          partnerUserId: void 0,
          callbackOnAvailable: void 0,
          callbackOnUpdates: void 0,
          callbackTimeoutInMs: void 0,
          pd: void 0,
          abTesting: { enabled: !1, controlGroupPct: 0 },
          provider: void 0,
          maxCascades: 8,
          applyCreativeRestrictions: !1,
          acr: !1,
          segments: void 0,
          disableUaHints: !1,
          storageExpirationDays: void 0,
          att: void 0,
          diagnostics: {
            publishingDisabled: !1,
            publishAfterLoadInMsec: 3e4,
            publishBeforeWindowUnload: !0,
            publishingSampleRatio: 0.01,
          },
          multiplexing: { _disabled: !1 },
          allowGCReclaim: $e.AFTER_UID_SET,
          gamTargetingPrefix: void 0,
          exposeTargeting: !1,
          idLookupMode: !1,
          apiBaseUrl: "",
          enablerVersion: void 0,
          enablerSrc: void 0,
          enablerFallback: void 0,
        }),
        (this.providedOptions = {}),
        !z(e.partnerId) && !B(e.partnerId))
      )
        throw new Error(
          "partnerId is required and must be a number or a string"
        );
      (this.invalidSegments = 0), this.updOptions(e);
    }
    getOptions() {
      return this.options;
    }
    getProvidedOptions() {
      return this.providedOptions;
    }
    getInvalidSegments() {
      return this.invalidSegments;
    }
    hasCreativeRestrictions() {
      return this.options.applyCreativeRestrictions || this.options.acr;
    }
    isForceAllowLocalStorageGrant() {
      var e = this.options;
      return e.allowLocalStorageWithoutConsentApi || e.debugBypassConsent;
    }
    updOptions(a) {
      const c = this,
        d = c._log;
      if (J(a)) {
        this.setPartnerId(a.partnerId);
        const l = (e, t) => {
          (this.options[e] = t), (this.providedOptions[e] = t);
        };
        var e;
        void 0 !== a.partnerData &&
          ((e = a.partnerData),
          A(a.pd) &&
            d.info(
              "Both pd and partnerData provided. Using partnerData and ignoring pd."
            ),
          (this.options.partnerData = e),
          (this.providedOptions.partnerData = e)),
          Object.keys(a).forEach((e) => {
            if ("segments" === e) {
              const r = a[e],
                s = [];
              A(r) &&
                (q(r)
                  ? (r.forEach((e, t) => {
                      t = "segments[".concat(t, "]");
                      return q(e.ids) &&
                        (function (e, t) {
                          let i = !0;
                          return O(e, (e) => (i = i && t(e))), i;
                        })(e.ids, B)
                        ? e.ids.length < 1
                          ? (d.error(
                              "Config option ".concat(
                                t,
                                ".ids should contain at least one segment ID"
                              )
                            ),
                            void (c.invalidSegments += 1))
                          : B(e.destination)
                          ? void s.push(e)
                          : (tt(
                              d,
                              "".concat(t, ".destination"),
                              "String",
                              e.destination
                            ),
                            void (c.invalidSegments += 1))
                        : (tt(
                            d,
                            "".concat(t, ".ids"),
                            "Array of String",
                            e.ids
                          ),
                          void (c.invalidSegments += 1));
                    }),
                    l(e, s))
                  : tt(d, e, "Array", r));
            } else if ("diagnostics" === e) {
              const n = this.options.diagnostics,
                o = a.diagnostics;
              if (W(o, et.configTypes.diagnostics)) {
                let t = h({}, n);
                Object.keys(o).forEach((e) => {
                  void 0 !== n[e] &&
                    typeof n[e] == typeof o[e] &&
                    (t[e] = o[e]);
                }),
                  (this.options[e] = t);
              }
              this.providedOptions[e] = a[e];
            } else {
              var t, i;
              void 0 !== Qe[e]
                ? (i = a[e]) && Qe[e].includes(i) && l(e, i)
                : "partnerId" !== e &&
                  "partnerData" !== e &&
                  ((t = et.configTypes[e]),
                  A((i = a[e])) && (W(i, t) ? l(e, i) : tt(d, e, t, i)));
            }
          });
      } else d.error("Config options must be an object");
    }
    setPartnerId(e) {
      let t;
      if (B(e)) {
        if (((t = parseInt(e)), isNaN(t) || t < 0))
          throw new Error(
            "partnerId is required and must parse to a positive integer"
          );
      } else z(e) && (t = e);
      if (z(t)) {
        if (z(this.options.partnerId) && t !== this.options.partnerId)
          throw new Error("Cannot update config with a different partnerId");
        (this.options.partnerId = t), (this.providedOptions.partnerId = e);
      }
    }
  }
  function tt(e, t, i, r) {
    e.error(
      "Config option "
        .concat(t, " must be of type ")
        .concat(i, " but was ")
        .concat(toString.call(r), ". Ignoring...")
    );
  }
  l(et, "configTypes", {
    debugBypassConsent: "Boolean",
    allowLocalStorageWithoutConsentApi: "Boolean",
    cmpApi: "String",
    consentData: "Object",
    refreshInSeconds: "Number",
    partnerUserId: "String",
    callbackOnAvailable: "Function",
    callbackOnUpdates: "Function",
    callbackTimeoutInMs: "Number",
    pd: "String",
    partnerData: "Object",
    abTesting: "Object",
    provider: "String",
    maxCascades: "Number",
    applyCreativeRestrictions: "Boolean",
    acr: "Boolean",
    disableUaHints: "Boolean",
    storageExpirationDays: "Number",
    att: "Number",
    diagnostics: "Object",
    multiplexing: "Object",
    dynamicConfig: "Object",
    allowGCReclaim: "String",
    gssProvider: "Object",
    gamTargetingPrefix: "String",
    exposeTargeting: "Boolean",
    idLookupMode: "Boolean",
    apiBaseUrl: "String",
    enablerVersion: "String",
    enablerSrc: "String",
    enablerFallback: "String",
  });
  class it {
    constructor(e) {
      const t = this,
        i = new Promise((e) => {
          t._resolve = e;
        }),
        r = (window.googletag = window.googletag || {});
      (r.secureSignalProviders = r.secureSignalProviders || []),
        r.secureSignalProviders.push({ id: e, collectorFunction: () => i });
    }
    setUserId(e) {
      this._resolve &&
        !0 !== this._resolved &&
        (this._resolve(e), (this._resolved = !0));
    }
  }
  class rt {
    constructor(e, t, i) {
      var r =
          3 < arguments.length && void 0 !== arguments[3]
            ? arguments[3]
            : void 0,
        s =
          4 < arguments.length && void 0 !== arguments[4]
            ? arguments[4]
            : void 0;
      l(this, "refererInfo", void 0),
        l(this, "apiVersion", void 0),
        l(this, "isUsingCdn", void 0),
        l(this, "scriptSrc", void 0),
        l(this, "scriptFallback", void 0),
        (this.refererInfo = e),
        (this.apiVersion = t),
        (this.isUsingCdn = i),
        (this.scriptSrc = r),
        (this.scriptFallback = s);
    }
  }
  class st {
    constructor(e, t) {
      l(this, "_targets", void 0),
        l(this, "_metrics", void 0),
        l(this, "_survivalTimer", void 0),
        (this._targets = [e, t]),
        (this._metrics = t),
        (this._survivalTimer = Ce());
    }
    unregister(e) {
      var t;
      this._survivalTimer &&
        this._metrics &&
        this._survivalTimer.record(
          ((t = this._metrics),
          (e = { unregisterTrigger: e }),
          t.timer("instance.survival.time", e))
        ),
        this._targets.forEach((e) => {
          try {
            Y(e) && H(e.unregister) && e.unregister();
          } catch (e) {}
        });
    }
  }
  globalThis.__id5_finalization_registry ||
    (globalThis.__id5_finalization_registry = new (class {
      constructor() {
        l(this, "_finalizationRegistry", void 0),
          l(this, "_instancesHolder", void 0),
          (this._instancesHolder = new Set());
        try {
          this._finalizationRegistry = new FinalizationRegistry((e) => {
            try {
              Y(e) && H(e.unregister) && e.unregister("gc-reclaim");
            } catch (e) {}
          });
        } catch (e) {}
      }
      register(e) {
        try {
          e.getOptions().allowGCReclaim !== $e.ASAP &&
            this._instancesHolder.add(e),
            this._finalizationRegistry.register(e, e._unregisterTargets, e);
        } catch (e) {}
      }
      unregister(e) {
        try {
          this.releaseInstance(e, !0), this._finalizationRegistry.unregister(e);
        } catch (e) {}
      }
      releaseInstance(e) {
        var t = 1 < arguments.length && void 0 !== arguments[1] && arguments[1];
        (!e.getOptions().allowGCReclaim === $e.NEVER && !t) ||
          this._instancesHolder.delete(e);
      }
    })());
  const nt = globalThis.__id5_finalization_registry;
  class ot {
    constructor(e) {
      l(this, "_ref", void 0), (this._ref = e);
    }
    deref() {
      return this._ref;
    }
  }
  class at {
    getOptions() {
      return this.config.getOptions();
    }
    getProvidedOptions() {
      return this.config.getProvidedOptions();
    }
    getInvalidSegments() {
      return this.config.getInvalidSegments();
    }
    getUserId() {
      return !1 === this._isExposed ? "0" : this._userId;
    }
    isFromCache() {
      return this._fromCache;
    }
    exposeUserId() {
      return this._isExposed;
    }
    getConsents() {
      return this._consents;
    }
    onAvailable(e, t) {
      if (!H(e)) throw new Error("onAvailable expects a function");
      return (
        this._availableCallback
          ? this._log.warn("onAvailable was already called, ignoring")
          : (this._availableCallback = new Ke(
              "onAvailable",
              this._log,
              this._metrics,
              e,
              t,
              this._userIdAvailable,
              () => {},
              this
            )),
        this
      );
    }
    onUpdate(e) {
      if (!H(e)) throw new Error("onUpdate expects a function");
      return (
        (this._updateCallback = e),
        this._userIdAvailable && this._fireOnUpdate(),
        this
      );
    }
    unregister() {
      try {
        this._unregisterTargets.unregister("api-call"), nt.unregister(this);
      } catch (e) {}
    }
    constructor(e, t, i, r, s, n) {
      var o =
        6 < arguments.length && void 0 !== arguments[6] ? arguments[6] : {};
      l(this, "_availableCallback", void 0),
        l(this, "_updateCallback", void 0),
        l(this, "_refreshCallback", void 0),
        l(this, "_isExposed", void 0),
        l(this, "_fromCache", void 0),
        l(this, "_signature", void 0),
        l(this, "_isRefreshing", !1),
        l(this, "_isRefreshingWithFetch", !1),
        l(this, "_userId", void 0),
        l(this, "_ext", void 0),
        l(this, "_userIdAvailable", !1),
        l(this, "_userIdAvailablePromise", void 0),
        l(this, "_userIdAvailablePromiseResolver", void 0),
        l(this, "invocationId", void 0),
        l(this, "config", void 0),
        l(this, "_metrics", void 0),
        l(this, "_log", void 0),
        l(this, "_multiplexingInstance", void 0),
        l(this, "_pageLevelInfo", void 0),
        l(this, "_origin", void 0),
        l(this, "_ids", void 0),
        l(this, "_publisherTrueLinkId", void 0),
        l(this, "_gpId", void 0),
        l(this, "_consents", void 0),
        (this.config = e),
        (this._metrics = t),
        (this._log = new d("Id5Instance:", i)),
        (this._multiplexingInstance = r),
        (this._userIdAvailablePromise = new Promise((e) => {
          this._userIdAvailablePromiseResolver = e;
        })),
        (this._pageLevelInfo = s),
        (this._unregisterTargets = new st(
          this._multiplexingInstance,
          this._metrics
        )),
        (this._origin = n),
        nt.register(this),
        (this._registrationProperties = o);
    }
    bootstrap() {
      var e;
      const n = Ce(),
        o = this.config.getOptions(),
        a = this._ref();
      this._multiplexingInstance
        .on(Ne.USER_ID_READY, (e, t) => {
          const i = a.deref();
          if (i) {
            try {
              var r = null != t && t.tags ? h({}, t.tags) : {},
                s = i._metrics;
              null != t &&
                t.timestamp &&
                s
                  .timer("userid.provisioning.delivery.delay", r)
                  .record(Date.now() - t.timestamp),
                n.record(
                  (function (e, t, i) {
                    return e.timer(
                      "userid.provisioning.delay",
                      h(
                        { cachedResponseUsed: t },
                        2 < arguments.length && void 0 !== i ? i : {}
                      )
                    );
                  })(
                    s,
                    e.isFromCache,
                    h(
                      h({}, r),
                      {},
                      {
                        isUpdate: i._userIdAvailable,
                        hasOnAvailable: void 0 !== i._availableCallback,
                        hasOnRefresh: void 0 !== i._refreshCallback,
                        hasOnUpdate: void 0 !== i._updateCallback,
                        provisioner:
                          (null == t ? void 0 : t.provisioner) || "leader",
                        hasChanged: i._userId !== e.responseObj.universal_uid,
                      }
                    )
                  )
                );
            } catch (e) {
              i._log.error("Failed to measure provisioning metrics", e);
            }
            i._setUserId(e.responseObj, e.isFromCache, e.willBeRefreshed),
              (i._consents = e.consents),
              class {
                static updateTargeting(e, t, i) {
                  var r;
                  const s = e.responseObj.tags;
                  s &&
                    t &&
                    "undefined" != typeof window &&
                    ((window.googletag = window.googletag || { cmd: [] }),
                    (window.googletag.cmd = window.googletag.cmd || []),
                    window.googletag.cmd.push(() => {
                      for (const e in s)
                        window.googletag.setConfig({
                          targeting: { [t + "_" + e]: s[e] },
                        });
                    })),
                    s &&
                      i &&
                      !Q(
                        null === (i = window) ||
                          void 0 === i ||
                          null === (r = i.id5tags) ||
                          void 0 === r
                          ? void 0
                          : r.tags,
                        s
                      ) &&
                      ((window.id5tags = window.id5tags || { cmd: [] }),
                      (window.id5tags.cmd = window.id5tags.cmd || []),
                      window.id5tags.cmd.forEach((e) => {
                        setTimeout(() => e(s), 0);
                      }),
                      (window.id5tags.cmd.push = function (e) {
                        e(s), Array.prototype.push.call(window.id5tags.cmd, e);
                      }),
                      (window.id5tags.tags = s));
                }
              }.updateTargeting(e, o.gamTargetingPrefix, o.exposeTargeting);
          }
        })
        .on(Ne.USER_ID_FETCH_CANCELED, (e) => {
          const t = a.deref();
          t && t._log.info("ID5 User ID fetch canceled:", e.reason);
        }),
        this._log.info(
          "bootstrapped for partner "
            .concat(o.partnerId, " with referer ")
            .concat(
              null === (e = this._pageLevelInfo) || void 0 === e
                ? void 0
                : e.refererInfo,
              " and options"
            ),
          this.getProvidedOptions()
        );
    }
    init() {
      const i = this.config.getOptions();
      var e = i.gssProvider;
      return (
        e &&
          !0 === e.enabled &&
          (this._gssProvider = new it(
            (null === (e = i.gssProvider) || void 0 === e ? void 0 : e.id) ||
              "id5-sync.com"
          )),
        this._gatherFetchIdData().then((e) => {
          var t;
          this._multiplexingInstance.register(
            h(
              {
                source: this._origin,
                sourceVersion: Ze,
                sourceConfiguration: { options: i },
                fetchIdData: e,
                singletonMode:
                  !0 ===
                    (null === i ||
                    void 0 === i ||
                    null === (t = i.multiplexing) ||
                    void 0 === t
                      ? void 0
                      : t._disabled) ||
                  !0 === (null === i || void 0 === i ? void 0 : i.idLookupMode),
                forceAllowLocalStorageGrant:
                  this.config.isForceAllowLocalStorageGrant(),
                storageExpirationDays: i.storageExpirationDays,
              },
              this._registrationProperties
            )
          );
        })
      );
    }
    _gatherFetchIdData() {
      var t = this;
      return i(function* () {
        var e = t.config.getOptions();
        return Promise.resolve({
          partnerId: e.partnerId,
          refererInfo: t._pageLevelInfo.refererInfo,
          origin: t._origin,
          originVersion: t._pageLevelInfo.apiVersion,
          isUsingCdn: t._pageLevelInfo.isUsingCdn,
          scriptSrc: t._pageLevelInfo.scriptSrc,
          scriptFallback: t._pageLevelInfo.scriptFallback,
          abTesting: e.abTesting,
          provider: e.provider,
          refreshInSeconds: e.refreshInSeconds,
          providedRefreshInSeconds: t.getProvidedOptions().refreshInSeconds,
          trace: k,
          consentSource: se.none,
          segments: e.segments,
          invalidSegmentsCount: t.getInvalidSegments(),
          idLookupMode: e.idLookupMode,
          apiBaseUrl: e.apiBaseUrl,
        });
      })();
    }
    _ref() {
      return new ("undefined" != typeof WeakRef ? WeakRef : ot)(this);
    }
    _setUserId(e, t) {
      var i = 2 < arguments.length && void 0 !== arguments[2] && arguments[2],
        r = e.universal_uid;
      if (((this._isExposed = !0), J(e.ab_testing)))
        switch (e.ab_testing.result) {
          case "normal":
            break;
          default:
          case "error":
            this._log.error(
              "There was an error with A/B Testing. Make sure controlGroupRatio is a number >= 0 and <= 1"
            );
            break;
          case "control":
            (this._isExposed = !1), this._log.info("User is in control group!");
        }
      var s =
        this._userId !== r ||
        !1 === Q(this._ext, e.ext) ||
        !1 === Q(this._ids, e.ids);
      (this._userIdAvailable = !0),
        (this._userId = r),
        (this._gpId = e.gp),
        (this._ids = e.ids),
        this._userIdAvailablePromiseResolver(r),
        (this._ext = e.ext),
        (this._publisherTrueLinkId = e.publisherTrueLinkId),
        (this._fromCache = t),
        (this._signature = e.signature),
        this._log.info("User id updated", { hasChanged: s, fromCache: t }),
        this._availableCallback && this._availableCallback.triggerNow(),
        this._isRefreshing &&
          this._refreshCallback &&
          (!1 === t || !1 === this._isRefreshingWithFetch) &&
          this._refreshCallback.triggerNow(),
        s && this._fireOnUpdate(),
        this.getOptions().allowGCReclaim !== $e.AFTER_UID_SET ||
          (t && i) ||
          nt.releaseInstance(this),
        this._gssProvider && this._gssProvider.setUserId(this.getUserId());
    }
    _fireOnUpdate() {
      setTimeout(() => {
        H(this._updateCallback) &&
          (this._log.debug("Firing onUpdate"), this._updateCallback(this));
      }, 0);
    }
  }
  const ct = JSON.stringify,
    dt = Object.prototype.hasOwnProperty,
    lt = Object.freeze({
      OTHER: "other",
      HEM: "hem",
      PHONE: "phone",
      XPUID: "xpuid",
      XPUID_SOURCE: "xpuidSource",
      PUID: "puid",
      IDFA: "idfa",
      GAID: "gaid",
      URL: "url",
      DOMAIN: "domain",
      IPV4: "ipv4",
      IPV6: "ipv6",
      UA: "ua",
      IS_BURNER_EMAIL: "isBurnerEmail",
      IDFV: "idfv",
      CTV_ID: "ctvId",
      CTV_ID_TYPE: "ctvIdType",
      IAB_TOKEN: "iabToken",
    }),
    ht = Object.freeze({
      [lt.OTHER]: 0,
      [lt.HEM]: 1,
      [lt.PHONE]: 2,
      [lt.XPUID]: 3,
      [lt.XPUID_SOURCE]: 4,
      [lt.PUID]: 5,
      [lt.IDFA]: 6,
      [lt.GAID]: 7,
      [lt.URL]: 8,
      [lt.DOMAIN]: 9,
      [lt.IPV4]: 10,
      [lt.IPV6]: 11,
      [lt.UA]: 12,
      [lt.IS_BURNER_EMAIL]: 13,
      [lt.IDFV]: 14,
      [lt.CTV_ID]: 15,
      [lt.CTV_ID_TYPE]: 16,
      [lt.IAB_TOKEN]: 17,
    });
  function ut() {
    return (ut = i(function* (t, i) {
      if (A(t))
        if (J(t)) {
          const l = [];
          let e = 0;
          var r,
            s = f(Object.keys(t).sort());
          try {
            for (s.s(); !(r = s.n()).done; ) {
              var n,
                o,
                a = r.value,
                c = t[a];
              dt.call(ht, a)
                ? B(c)
                  ? (n = yield (function () {
                      return gt.apply(this, arguments);
                    })(a, c, i))
                    ? ((o = ht[a]),
                      l.push("".concat(o, "=").concat(encodeURIComponent(n))))
                    : (e += 1)
                  : (i.warn(
                      'partnerData value for key "'
                        .concat(a, '" must be a string but was ')
                        .concat(ct.call(c), ". Skipping.")
                    ),
                    (e += 1))
                : (i.warn(
                    'partnerData key "'.concat(
                      a,
                      '" is not a recognized key. Skipping.'
                    )
                  ),
                  (e += 1));
            }
          } catch (e) {
            s.e(e);
          } finally {
            s.f();
          }
          if (0 < l.length) {
            var d = l.join("&"),
              d = btoa(d);
            return (
              i.info(
                "Converted partnerData with ".concat(l.length, " entries to pd")
              ),
              0 < e &&
                i.warn("Skipped ".concat(e, " invalid partnerData entries")),
              d
            );
          }
          i.warn("partnerData provided but no valid entries found"),
            0 < e &&
              i.warn("Skipped ".concat(e, " invalid partnerData entries"));
        } else
          i.error(
            "Config option partnerData must be of type Object but was ".concat(
              ct.call(t)
            )
          );
    })).apply(this, arguments);
  }
  function gt() {
    return (gt = i(function* (e, t, i) {
      return e === lt.HEM
        ? yield (function () {
            return pt.apply(this, arguments);
          })(t, i)
        : e === lt.PHONE
        ? yield (function () {
            return vt.apply(this, arguments);
          })(t, i)
        : e === lt.IDFA || e === lt.GAID || e === lt.IDFV
        ? t.toLowerCase()
        : t;
    })).apply(this, arguments);
  }
  function pt() {
    return (pt = i(function* (e, t) {
      if (mt(e)) return e.toLowerCase();
      e = (function (e) {
        if (!B(e)) return;
        let t = e.trim().toLowerCase();
        e = t.split("@");
        if (2 !== e.length || !e[0] || !e[1]) return;
        let i = g(e, 2),
          r = i[0],
          s = i[1];
        ("gmail.com" !== s && "googlemail.com" !== s) ||
          ((r = r.replace(/\./g, "")),
          -1 !== (e = r.indexOf("+")) && (r = r.substring(0, e)),
          (s = "gmail.com"));
        return "".concat(r, "@").concat(s);
      })(e);
      if (e) {
        e = yield _t(e);
        return e
          ? (t.info("Auto-hashed email for hem field"), e)
          : void t.warn(
              "Empty email after normalization for hem field. Skipping."
            );
      }
      t.warn(
        "Invalid email format for hem field (missing '@' or empty parts). Skipping."
      );
    })).apply(this, arguments);
  }
  function vt() {
    return (vt = i(function* (e, t) {
      if (mt(e)) return e.toLowerCase();
      e = yield _t(e.trim());
      return e
        ? (t.info("Auto-hashed phone number for phone field"), e)
        : void t.warn(
            "Empty or invalid phone number for phone field. Skipping."
          );
    })).apply(this, arguments);
  }
  function _t() {
    return ft.apply(this, arguments);
  }
  function ft() {
    return (ft = i(function* (e) {
      if (B(e) && 0 !== e.length) {
        (e = new TextEncoder().encode(e)),
          (e = yield crypto.subtle.digest("SHA-256", e));
        const t = Array.from(new Uint8Array(e));
        return t.map((e) => e.toString(16).padStart(2, "0")).join("");
      }
    })).apply(this, arguments);
  }
  function mt(e) {
    return B(e) && /^[a-f0-9]{64}$/i.test(e);
  }
  class It {
    static gatherUaHints(e, t) {
      return i(function* () {
        if (A(window.navigator.userAgentData) && !e) {
          let e;
          try {
            e = yield window.navigator.userAgentData.getHighEntropyValues([
              "architecture",
              "fullVersionList",
              "model",
              "platformVersion",
            ]);
          } catch (e) {
            return void t.error(
              "Error while calling navigator.userAgentData.getHighEntropyValues()",
              e
            );
          }
          return It.filterUaHints(e);
        }
      })();
    }
    static filterUaHints(e) {
      if (A(e)) {
        const t = /[()-.:;=?_/]/g;
        return (
          C(e.brands) &&
            (e.brands = e.brands.filter(
              (e) => S(e.brand) && e.brand.search(t) < 0
            )),
          C(e.fullVersionList) &&
            (e.fullVersionList = e.fullVersionList.filter(
              (e) => S(e.brand) && e.brand.search(t) < 0
            )),
          e
        );
      }
    }
  }
  function wt(e, t, i) {
    return e.timer(
      "fetch.call.time",
      h({ status: t }, 2 < arguments.length && void 0 !== i ? i : {})
    );
  }
  function yt(e, t, i, r) {
    return e.timer(
      "extensions.call.time",
      h(
        { extensionType: t, status: i ? "success" : "fail" },
        3 < arguments.length && void 0 !== r ? r : {}
      )
    );
  }
  function bt(e, t, i) {
    return e.counter(
      "instance.lateJoin.count",
      h({ instanceId: t }, 2 < arguments.length && void 0 !== i ? i : {})
    );
  }
  function St(e, t) {
    return e.summary(
      "storage.keys.expired.count",
      1 < arguments.length && void 0 !== t ? t : {}
    );
  }
  const Ct = "*";
  class Dt {
    constructor(e, t, i, r, s, n) {
      var o =
        6 < arguments.length && void 0 !== arguments[6] ? arguments[6] : void 0;
      l(this, "_isId5Message", !0),
        l(this, "id", void 0),
        l(this, "timestamp", void 0),
        l(this, "type", void 0),
        l(this, "src", void 0),
        l(this, "dst", void 0),
        l(this, "request", void 0),
        l(this, "payload", void 0),
        (this.id = r),
        (this.timestamp = e),
        (this.src = t),
        (this.dst = i),
        (this.type = n),
        (this.request = o),
        (this.payload = s);
    }
  }
  class Et {
    constructor(e) {
      l(this, "_senderId", void 0),
        l(this, "_messageSeqNb", 0),
        (this._senderId = e),
        (this._messageSeqNb = 0);
    }
    createBroadcastMessage(e) {
      var t =
        1 < arguments.length && void 0 !== arguments[1]
          ? arguments[1]
          : e.constructor.name;
      return new Dt(
        Date.now(),
        this._senderId,
        void 0,
        ++this._messageSeqNb,
        e,
        t || e.constructor.name
      );
    }
    createResponse(e, t) {
      var i =
        2 < arguments.length && void 0 !== arguments[2]
          ? arguments[2]
          : t.constructor.name;
      return new Dt(
        Date.now(),
        this._senderId,
        e.src,
        ++this._messageSeqNb,
        t,
        i || t.constructor.name,
        e
      );
    }
    createUnicastMessage(e, t) {
      var i =
        2 < arguments.length && void 0 !== arguments[2]
          ? arguments[2]
          : t.constructor.name;
      return new Dt(
        Date.now(),
        this._senderId,
        e,
        ++this._messageSeqNb,
        t,
        i || t.constructor.name
      );
    }
  }
  class At {
    constructor(e) {
      var t = 1 < arguments.length && void 0 !== arguments[1] && arguments[1],
        i =
          2 < arguments.length && void 0 !== arguments[2]
            ? arguments[2]
            : void 0;
      l(this, "instance", void 0),
        l(this, "instanceState", void 0),
        l(this, "isResponse", void 0),
        (this.instance = e),
        (this.instanceState = i),
        (this.isResponse = t);
    }
  }
  l(At, "TYPE", "HelloMessage");
  const Tt = Object.freeze({
    LEADER: "leader",
    FOLLOWER: "follower",
    STORAGE: "storage",
  });
  class Pt {
    constructor(e, t, i) {
      l(this, "target", void 0),
        l(this, "methodName", void 0),
        l(this, "methodArguments", void 0),
        (this.target = e),
        (this.methodName = t),
        (this.methodArguments = i);
    }
  }
  l(Pt, "TYPE", "RemoteMethodCallMessage");
  class Ot {
    constructor() {
      var e =
        0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : v;
      l(this, "_targets", {}), l(this, "_log", void 0), (this._log = e);
    }
    registerTarget(e, t) {
      return (this._targets[e] = t), this;
    }
    _handle(t) {
      const e = this._targets[t.target];
      if (e)
        try {
          e[t.methodName](...t.methodArguments);
        } catch (e) {
          this._log.error("Error while handling method call ", t, e);
        }
    }
  }
  class Rt {
    constructor(e, t) {
      var i =
          2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : v,
        r = 3 < arguments.length ? arguments[3] : void 0;
      l(this, "_id", void 0),
        l(this, "_messageFactory", void 0),
        l(this, "_log", void 0),
        l(this, "_metrics", void 0),
        l(this, "_onMessageCallBackFunction", void 0),
        (this._id = e),
        (this._messageFactory = new Et(this._id)),
        (this._log = i),
        (this._window = t),
        (this._handlers = {}),
        (this._metrics = r),
        this._register();
    }
    _register() {
      const s = this;
      s._abortController =
        "undefined" != typeof AbortController ? new AbortController() : void 0;
      var e =
        null === (e = s._abortController) || void 0 === e ? void 0 : e.signal;
      s._window.addEventListener(
        "message",
        (i) => {
          let r = i.data;
          if (
            void 0 !== i.data &&
            i.data._isId5Message &&
            i.data.src !== s._id &&
            (void 0 === i.data.dst || i.data.dst === s._id)
          )
            try {
              [Ct, r.type].forEach((e) => {
                let t = s._handlers[e];
                t && t.forEach((e) => e(r, i.source));
              });
            } catch (e) {
              s._log.error("Error while handling message", r, e);
            }
        },
        { capture: !1, signal: e }
      );
    }
    unregister() {
      this._abortController && this._abortController.abort();
    }
    onAnyMessage(e) {
      return this.onMessage(Ct, e);
    }
    onMessage(e, t) {
      const i = this._handlers[e];
      return i ? i.push(t) : (this._handlers[e] = [t]), this;
    }
    broadcastMessage(e, t) {
      this._log.debug("Broadcasting message", t, e),
        this._postMessage(this._messageFactory.createBroadcastMessage(e, t));
    }
    sendResponseMessage(e, t) {
      var i =
        2 < arguments.length && void 0 !== arguments[2]
          ? arguments[2]
          : t.constructor.name;
      this._log.debug("Sending response message", e, i, t),
        this._postMessage(this._messageFactory.createResponse(e, t, i));
    }
    unicastMessage(e, t) {
      var i =
        2 < arguments.length && void 0 !== arguments[2]
          ? arguments[2]
          : t.constructor.name;
      this._log.debug("Sending message to", e, i, t),
        this._postMessage(this._messageFactory.createUnicastMessage(e, t, i));
    }
    _postToWindow(e, t) {
      try {
        e.postMessage(t, "*");
      } catch (e) {
        this._log.error("Could not post message to window", e);
      }
    }
    _postMessage(r) {
      let s = this;
      (function t(e) {
        try {
          s._postToWindow(e, r);
          var i = e.frames;
          if (i) for (let e = 0; e < i.length; e++) t(i[e]);
        } catch (e) {
          s._log.error("Could not broadcast message", e);
        }
      })(s._window.top);
    }
    callProxyMethod(e, t, i, r) {
      this._log.debug("Calling ProxyMethodCall", {
        target: t,
        name: i,
        args: r,
      }),
        this.unicastMessage(e, new Pt(t, i, r), Pt.TYPE);
    }
    onProxyMethodCall(t) {
      return this.onMessage(Pt.TYPE, (e) =>
        void 0 === e.dst
          ? (this._countInvalidMessage(e, "no-destination-proxy"),
            void this._log.error(
              "Received invalid RemoteMethodCallMessage message",
              JSON.stringify(e),
              "Ignoring it...."
            ))
          : void t._handle(u(new Pt(), e.payload))
      );
    }
    _countInvalidMessage(e, t) {
      var i = (e) => null != e;
      void 0 !== this._metrics &&
        !(function (e, t) {
          return e.counter(
            "instance.message.invalid.count",
            1 < arguments.length && void 0 !== t ? t : {}
          );
        })(this._metrics, {
          reason: t,
          hasDestination: i(e.dst),
          hasSource: i(e.src),
          hasPayload: i(e.payload),
          hasRequest: i(e.request),
          hasTimestamp: i(e.timestamp),
        }).inc();
    }
  }
  const xt = Object.freeze({
    STORAGE_CONFIG: {
      ID5: { name: "id5id", expiresDays: 90 },
      ID5_V2: { name: "id5id_v2", expiresDays: 15 },
      LAST: { name: "id5id_last", expiresDays: 90 },
      CONSENT_DATA: { name: "id5id_cached_consent_data", expiresDays: 30 },
      PRIVACY: { name: "id5id_privacy", expiresDays: 30 },
      EXTENSIONS: { name: "id5id_extensions", expiresDays: 8 / 24 },
    },
    LEGACY_COOKIE_NAMES: ["id5.1st", "id5id.1st"],
    PRIVACY: { JURISDICTIONS: { gdpr: !0, ccpa: !1, lgpd: !0, other: !1 } },
    ID5_EIDS_SOURCE: "id5-sync.com",
  });
  class Ft {
    constructor(e, t) {
      (this.name = e), (this.expiresDays = t);
    }
    withNameSuffixed() {
      let e = this.name;
      for (var t = arguments.length, i = new Array(t), r = 0; r < t; r++)
        i[r] = arguments[r];
      for (var s = 0, n = i; s < n.length; s++) {
        var o = n[s];
        e += "_".concat(o);
      }
      return new Ft(e, this.expiresDays);
    }
  }
  class Lt {
    constructor() {
      let i =
        0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : void 0;
      function e(e) {
        var t = void 0 !== i ? Math.max(1, i) : e.expiresDays;
        return new Ft(e.name, t);
      }
      var t = xt.STORAGE_CONFIG;
      (this.ID5 = e(t.ID5)),
        (this.ID5_V2 = e(t.ID5_V2)),
        (this.ID5_SIGNATURE = e(t.ID5_V2).withNameSuffixed("signature")),
        (this.LAST = e(t.LAST)),
        (this.CONSENT_DATA = e(t.CONSENT_DATA)),
        (this.PRIVACY = e(t.PRIVACY)),
        (this.EXTENSIONS = new Ft(t.EXTENSIONS.name, t.EXTENSIONS.expiresDays));
    }
  }
  l(Lt, "DEFAULT", new Lt());
  class kt {
    constructor(e, t) {
      l(this, "_clientStore", void 0),
        l(this, "_trueLinkAdapter", void 0),
        (this._clientStore = e),
        (this._trueLinkAdapter = t);
    }
    hasConsentChanged(e) {
      return e && !this._clientStore.storedConsentDataMatchesConsentData(e);
    }
    storeConsent(e) {
      this._clientStore.putHashedConsentData(e);
    }
    incNb(e) {
      this._clientStore.incNbV2(
        e,
        1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 1
      );
    }
    updateNbs(e) {
      var t,
        i = f(e);
      try {
        for (i.s(); !(t = i.n()).done; ) {
          var r = g(t.value, 2),
            s = r[0],
            n = r[1],
            o = null == n ? void 0 : n.nb;
          0 < o && this.incNb(s, -o);
        }
      } catch (e) {
        i.e(e);
      } finally {
        i.f();
      }
    }
    storeResponse(e, i, r) {
      var t;
      null !== (t = i.getGenericResponse()) &&
        void 0 !== t &&
        t.signature &&
        this._clientStore.storeSignature(
          null === (t = i.getGenericResponse()) || void 0 === t
            ? void 0
            : t.signature
        );
      const s = new Set();
      e.forEach((e) => {
        var t = e.cacheId;
        s.has(t) ||
          ((e = i.getResponseFor(e.integrationId)) &&
            (this._clientStore.storeResponseV2(t, e, i.timestamp, r),
            s.add(t)));
      }),
        this._trueLinkAdapter.setPrivacy(
          null === (e = i.getGenericResponse()) || void 0 === e
            ? void 0
            : e.privacy
        );
    }
    clearAll(e) {
      this._clientStore.clearResponseV1(),
        this._clientStore.clearDateTime(),
        e.forEach((e) => {
          e = e.cacheId;
          this._clientStore.clearResponseV2(e);
        }),
        this._clientStore.clearHashedConsentData(),
        this._trueLinkAdapter.clearPrivacy(),
        this._clientStore.clearExtensions(),
        this._clientStore.clearSignature();
    }
    getCachedResponse(e) {
      e = this._clientStore.getStoredResponseV2(e);
      if (e) return new Ut(e.response, e.responseTimestamp, e.nb, e.consents);
    }
    getCachedSignature() {
      var e;
      return null === (e = this._clientStore.getStoredSignature()) ||
        void 0 === e
        ? void 0
        : e.signature;
    }
    getCachedExtensions() {
      return this._clientStore.getExtensions();
    }
    clearExtensions() {
      this._clientStore.clearExtensions();
    }
    storeExtensions(e) {
      var t = D(e.ttl) ? e.ttl / 86400 : Lt.DEFAULT.EXTENSIONS.expiresDays,
        t = new Ft(Lt.DEFAULT.EXTENSIONS.name, t);
      return this._clientStore.storeExtensions(e, t);
    }
  }
  class Ut {
    constructor(e, t) {
      var i =
          2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : 0,
        r =
          3 < arguments.length && void 0 !== arguments[3]
            ? arguments[3]
            : void 0;
      l(this, "response", void 0),
        l(this, "timestamp", void 0),
        l(this, "nb", void 0),
        l(this, "consents", void 0),
        (this.response = e),
        (this.timestamp = t),
        (this.nb = i),
        (this.consents = r);
    }
    isExpired() {
      var e = this.getMaxAge();
      return !(D(e) && 0 < e) || this._isOlderThanSec(e);
    }
    _isOlderThanSec(e) {
      return this.timestamp <= 0 || this.getAgeSec() > e;
    }
    isStale() {
      return !this.timestamp || this._isOlderThanSec(1209600);
    }
    isResponseComplete() {
      return (
        E(this.response) &&
        S(this.response.universal_uid) &&
        S(this.response.signature)
      );
    }
    isValid() {
      return this.isResponseComplete() && !this.isStale();
    }
    getMaxAge() {
      var e, t;
      return null === (e = this.response) ||
        void 0 === e ||
        null === (t = e.cache_control) ||
        void 0 === t
        ? void 0
        : t.max_age_sec;
    }
    getAgeSec() {
      return ((Date.now() - this.timestamp) / 1e3) | 0;
    }
  }
  const Nt = "_exp";
  class jt {
    constructor(e) {
      var t =
        1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : v;
      l(this, "storage", void 0),
        l(this, "_log", void 0),
        (this.storage = e),
        (this._log = t);
    }
    getItem(e) {
      try {
        return this.storage.getItem(e);
      } catch (e) {}
    }
    setItem(e, t) {
      try {
        this.storage.setItem(e, t);
      } catch (e) {}
    }
    removeItem(e) {
      try {
        this.storage.removeItem(e);
      } catch (e) {}
    }
    removeExpiredObjectWithPrefix(t) {
      var i = 1 < arguments.length && void 0 !== arguments[1] && arguments[1];
      this._log.info("Check, prefix", t);
      try {
        var r = this.storage.getKeysWithPrefix(t);
        let e = 0;
        var s,
          n = f(r);
        try {
          for (n.s(); !(s = n.n()).done; ) {
            var o,
              a,
              c = s.value;
            i
              ? (this._log.info("Found", c, " remove it"), this.removeItem(c))
              : (a =
                  null == (o = this.getObjectWithExpiration({ name: c }))
                    ? void 0
                    : o.expireAt) &&
                a < Date.now() &&
                (this._log.info(
                  "Found expired object",
                  c,
                  "expiration time",
                  a,
                  "It will be removed"
                ),
                this.removeItem(c),
                (e += 1));
          }
        } catch (e) {
          n.e(e);
        } finally {
          n.f();
        }
        return { all: r.length, expired: e };
      } catch (e) {}
    }
    removeExpiredItem(e) {
      var t = e.name,
        i = this.getItem(t + Nt),
        r = this.getItem(t),
        s = i && Mt(i),
        e = !i;
      return r && (s || e)
        ? (this.removeItem(t),
          { found: !0, removed: !0, expiredAt: e ? void 0 : new Date(i) })
        : { found: !!r, removed: !1, expiredAt: void 0 };
    }
    getItemWithExpiration(e) {
      var t = e.name,
        e = this.getItem(t + Nt);
      return e && !Mt(e)
        ? this.getItem(t)
        : (this.removeItemWithExpiration({ name: t }), null);
    }
    setItemWithExpiration(e, t) {
      var i = e.name,
        e = e.expiresDays,
        e = Date.now() + 864e5 * e,
        e = new Date(e).toUTCString();
      this.setItem(i + Nt, e), this.setItem(i, t);
    }
    removeItemWithExpiration(e) {
      e = e.name;
      this.removeItem(e), this.removeItem(e + Nt);
    }
    setObjectWithExpiration(e, t) {
      var i = e.name,
        e = e.expiresDays,
        e = Date.now() + 864e5 * e;
      this.setItem(i, JSON.stringify({ data: t, expireAt: e }));
    }
    getObjectWithExpiration(t) {
      t = t.name;
      try {
        var e = JSON.parse(this.getItem(t));
        if (null != e && e.expireAt && 0 < e.expireAt - Date.now())
          return e.data;
        null != e && e.expireAt && this.removeItem(t);
      } catch (e) {
        this._log.error("Error while getting ", t, "object from storage", e);
      }
    }
    updateObjectWithExpiration(e, t) {
      var i = e.name,
        e = e.expiresDays;
      try {
        var r = t(this.getObjectWithExpiration({ name: i }));
        return this.setObjectWithExpiration({ name: i, expiresDays: e }, r), r;
      } catch (e) {
        this._log.error("Error while updating object with ", i, e);
      }
    }
  }
  function Mt(e) {
    return new Date(e).getTime() - Date.now() <= 0;
  }
  class Vt {
    getItem() {}
    removeItem() {}
    setItem() {}
    getKeysWithPrefix() {
      return [];
    }
  }
  const Gt = new Vt();
  class Wt extends Vt {
    constructor(e) {
      var t =
        !(1 < arguments.length && void 0 !== arguments[1]) || arguments[1];
      super(),
        l(this, "_writingEnabled", void 0),
        l(this, "_underlying", void 0),
        (this._writingEnabled = t);
      try {
        this._underlying = e.localStorage;
      } catch (e) {}
    }
    getItem(e) {
      try {
        return this._underlying.getItem(e);
      } catch (e) {}
    }
    removeItem(e) {
      try {
        this._underlying.removeItem(e);
      } catch (e) {}
    }
    setItem(e, t) {
      try {
        this._writingEnabled && this._underlying.setItem(e, t);
      } catch (e) {}
    }
    getKeysWithPrefix(t) {
      try {
        var i = this._underlying.length;
        if (this._writingEnabled) {
          const r = [];
          for (let e = 0; e < i; e++) {
            const s = this._underlying.key(e);
            s && s.startsWith(t) && r.push(s);
          }
          return r;
        }
      } catch (e) {}
    }
    static checkIfAccessible() {
      var e = "__id5test";
      try {
        return (
          window.localStorage.setItem(e, e),
          window.localStorage.removeItem(e),
          !0
        );
      } catch (e) {
        return !1;
      }
    }
  }
  class Ht {
    constructor(e) {
      l(this, "_replicas", []),
        l(this, "_lastKeyOperation", {}),
        l(this, "_primaryStorage", void 0),
        (this._primaryStorage = e);
    }
    getItem(e) {
      return this._primaryStorage.getItem(e);
    }
    removeItem(t) {
      this._primaryStorage.removeItem(t);
      var e = (e) => {
        e.removeItem(t);
      };
      this._replicas.forEach(e), (this._lastKeyOperation[t] = e);
    }
    setItem(t, i) {
      this._primaryStorage.setItem(t, i);
      var e = (e) => {
        e.setItem(t, i);
      };
      this._replicas.forEach(e), (this._lastKeyOperation[t] = e);
    }
    addReplica(t) {
      Object.values(this._lastKeyOperation).forEach((e) => e(t)),
        this._replicas.push(t);
    }
    getKeysWithPrefix(e) {
      return this._primaryStorage.getKeysWithPrefix(e);
    }
  }
  class Bt {
    constructor(e) {
      var t =
        1 < arguments.length && void 0 !== arguments[1]
          ? arguments[1]
          : Date.now();
      l(this, "timestamp", void 0),
        l(this, "response", void 0),
        (this.response = e),
        (this.timestamp = t);
    }
    getGenericResponse() {
      return this.response.generic;
    }
    getResponseFor(e) {
      var t, i;
      if (
        null !== (t = this.response) &&
        void 0 !== t &&
        t.responses &&
        null !== (i = this.response) &&
        void 0 !== i &&
        i.responses[e]
      )
        return h(h({}, this.response.generic), this.response.responses[e]);
    }
  }
  var qt = new WeakSet();
  class zt {
    constructor(e, t, i) {
      qt.add(this),
        l(this, "_extensionsProvider", void 0),
        l(this, "_metrics", void 0),
        l(this, "_log", void 0),
        (this._extensionsProvider = i),
        (this._metrics = e),
        (this._log = t);
    }
    fetchId(o, a, c, d) {
      const l = this._extensionsProvider;
      return l.gather(o).then((t) => {
        const n = t.extensions,
          i = t.endpoints;
        var e = o.map((e) => {
          const t = e.cacheData;
          var i =
              null === t ||
              void 0 === t ||
              null === (s = t.response) ||
              void 0 === s
                ? void 0
                : s.signature,
            r = null === t || void 0 === t ? void 0 : t.nb,
            s = null === t || void 0 === t ? void 0 : t.getMaxAge();
          return this._createRequest(a, e, i, r, s, n, c);
        });
        const r = JSON.stringify({ requests: e, signature: d });
        this._log.info("Fetching ID5 ID from:", i.fetch, e);
        let s = i;
        return p(this, qt, Jt)
          .call(this, i.fetch, r, { fallback: i.isFallback, retry: !1 })
          .catch((e) => {
            var t = e.noResponse ? l.retryEndpoints(i) : void 0;
            return t
              ? (this._log.warn("Using ".concat(t.fetch)),
                (s = t),
                p(this, qt, Jt).call(this, t.fetch, r, {
                  fallback: t.isFallback,
                  retry: !0,
                }))
              : Promise.reject(e);
          })
          .then(
            (e) => (l.confirmApiBase(s, t), e),
            (e) => Promise.reject(e.error)
          );
      });
    }
    _validateResponse(e) {
      if (!e || !S(e) || e.length < 1)
        throw new Error(
          'Empty fetch response from ID5 servers: "'.concat(e, '"')
        );
      var t = JSON.parse(e);
      if (!E(t.generic))
        throw new Error("Server response failed to validate: ".concat(e));
      return this._log.info("Valid json response from ID5 received", t), t;
    }
    _createRequest(e, i, t, r, s, n, o) {
      var a, c;
      this._log.info("Create request data for", {
        fetchIdData: i,
        consentData: e,
        signature: t,
        nbValue: r,
        refreshInSecondUsed: s,
        extensions: n,
      });
      var d = i.partnerId;
      const l = {
        requestId: i.integrationId,
        requestCount: i.requestCount,
        role: i.role,
        cacheId: i.cacheId,
        refresh: i.refresh,
        source: i.source,
        sourceVersion: i.sourceVersion,
        partner: d,
        v: i.originVersion,
        o: i.origin,
        tml: T(
          null === (d = i.refererInfo) || void 0 === d
            ? void 0
            : d.topmostLocation
        ),
        ref: T(null === (d = i.refererInfo) || void 0 === d ? void 0 : d.ref),
        u:
          T(
            null === (d = i.refererInfo) ||
              void 0 === d ||
              null === (a = d.stack) ||
              void 0 === a
              ? void 0
              : a[0]
          ) ||
          T(null === (c = window.location) || void 0 === c ? void 0 : c.href),
        top:
          null !== (c = i.refererInfo) && void 0 !== c && c.reachedTop ? 1 : 0,
        localStorage: !0 === o ? 1 : 0,
        nbPage: r,
        id5cdn: i.isUsingCdn,
        scriptSrc: i.scriptSrc,
        scriptFallback: i.scriptFallback,
        ua: window.navigator.userAgent,
        att: i.att,
      };
      r = e.gdprApplies;
      A(r) && (l.gdpr = r ? 1 : 0);
      r = e.consentString;
      A(r) && (l.gdpr_consent = r),
        A(i.allowedVendors)
          ? (l.allowed_vendors = i.allowedVendors)
          : A(e.allowedVendors) && (l.allowed_vendors = e.allowedVendors),
        A(e.gppData) &&
          ((l.gpp_string = e.gppData.gppString),
          (l.gpp_sid = e.gppData.applicableSections.join(","))),
        A(t) && (l.s = t);
      t = i.uaHints;
      A(t) && (l.ua_hints = t),
        A(e.ccpaString) && "" !== e.ccpaString && (l.us_privacy = e.ccpaString),
        Object.entries({
          pd: "pd",
          partnerUserId: "puid",
          provider: "provider",
          enablerVersion: "enablerVersion",
          enablerSrc: "enablerSrc",
          enablerFallback: "enablerFallback",
          segments: "segments",
          trueLink: "true_link",
        }).forEach((e) => {
          var t = g(e, 2),
            e = t[0],
            t = t[1];
          A(i[e]) && (l[t] = i[e]);
        });
      e = i.abTesting;
      e &&
        !0 === e.enabled &&
        (l.ab_testing = { enabled: !0, control_group_pct: e.controlGroupPct });
      e = i.invalidSegmentsCount;
      return (
        e && 0 < e && (l._invalid_segments = e),
        !0 === i.idLookupMode && (l.idLookupMode = !0),
        i.trace && (l._trace = !0),
        (l.provided_options = {
          refresh_in_seconds: i.providedRefreshInSeconds,
        }),
        (l.used_refresh_in_seconds = s),
        (l.extensions = n),
        l
      );
    }
  }
  function Jt(e, s, n) {
    const o = this._log,
      a = this._metrics,
      c = this;
    return new Promise((t, i) => {
      const r = Ce();
      !(function (r, s, n, o, e) {
        o = 3 < arguments.length && void 0 !== o ? o : {};
        let a = 4 < arguments.length && void 0 !== e ? e : v;
        try {
          let i;
          var c,
            d = o.method || (n ? "POST" : "GET");
          let e = document.createElement("a");
          e.href = r;
          let t =
            "object" == typeof s && null !== s
              ? s
              : {
                  success: function () {
                    a.info("ajax", "xhr success");
                  },
                  error: function (e) {
                    a.error("ajax", "xhr error", null, e);
                  },
                };
          "function" == typeof s && (t.success = s),
            (i = new window.XMLHttpRequest()),
            (i.onreadystatechange = function () {
              var e;
              4 === i.readyState &&
                ((200 <= (e = i.status) && e < 300) || 304 === e
                  ? t.success(i.responseText, i)
                  : t.error(i.statusText, i));
            }),
            (i.ontimeout = function () {
              a.error("ajax", "xhr timeout after ", i.timeout, "ms");
            }),
            "GET" === d && n && (u((c = R(r, o)).search, n), (r = x(c))),
            i.open(d, r, !0),
            o.withCredentials && (i.withCredentials = !0),
            O(o.customHeaders, (e, t) => {
              i.setRequestHeader(t, e);
            }),
            o.preflight &&
              i.setRequestHeader("X-Requested-With", "XMLHttpRequest"),
            i.setRequestHeader("Content-Type", o.contentType || "text/plain"),
            "POST" === d && n ? i.send(n) : i.send();
        } catch (e) {
          a.error("ajax", "xhr construction", e);
        }
      })(
        e,
        {
          success: function (e) {
            o.info("Success at fetch call:", e),
              r.record(
                (function (e, t) {
                  return wt(
                    e,
                    "success",
                    1 < arguments.length && void 0 !== t ? t : {}
                  );
                })(a, n)
              );
            try {
              t(new Bt(c._validateResponse(e)));
            } catch (e) {
              i({ error: e, noResponse: !1 });
            }
          },
          error: function (e, t) {
            r.record(
              (function (e, t) {
                return wt(
                  e,
                  "fail",
                  1 < arguments.length && void 0 !== t ? t : {}
                );
              })(a, n)
            ),
              i({
                error: e,
                noResponse: 0 === (null == t ? void 0 : t.status),
              });
          },
        },
        s,
        { method: "POST", withCredentials: !0 },
        o
      );
    });
  }
  const Xt = Object.freeze({
      DIRECT_METHOD: "direct_method",
      POST_MESSAGE: "post_message",
    }),
    Yt = Object.freeze({ STANDARD: "follower", PASSIVE: "follower-passive" });
  class Kt {
    constructor(e, t, i) {
      var r =
          3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : v,
        s =
          4 < arguments.length && void 0 !== arguments[4]
            ? arguments[4]
            : Yt.STANDARD;
      l(this, "_instanceProperties", void 0),
        l(this, "_log", void 0),
        l(this, "callType", void 0),
        l(this, "_instanceWindow", void 0),
        (this._instanceWindow = t),
        (this._instanceProperties = i),
        (this._log = r),
        (this.callType = e),
        (this.type = s);
    }
    getId() {
      return this._instanceProperties.id;
    }
    getFetchIdData() {
      return this._instanceProperties.fetchIdData;
    }
    updateFetchIdData(e) {
      u(this._instanceProperties.fetchIdData, e);
    }
    getCacheId() {
      var e = this._instanceProperties.fetchIdData,
        e = {
          partnerId: e.partnerId,
          att: e.att,
          pd: e.pd,
          provider: e.provider,
          abTesting: e.abTesting,
          segments: JSON.stringify(e.segments),
          providedRefresh: e.providedRefreshInSeconds,
          trueLink: null === (e = e.trueLink) || void 0 === e ? void 0 : e.id,
        };
      return F(JSON.stringify(e));
    }
    getDeclaredConsentSource() {
      return this._instanceProperties.fetchIdData.consentSource || se.cmp;
    }
    getSourceVersion() {
      return this._instanceProperties.sourceVersion;
    }
    getSource() {
      return this._instanceProperties.source;
    }
    notifyUidReady() {}
    notifyFetchUidCanceled() {}
    notifyCascadeNeeded() {}
    canDoCascade() {
      return !0 === this._instanceProperties.canDoCascade;
    }
    getStorage() {
      return Gt;
    }
    getWindow() {
      return this._instanceWindow;
    }
  }
  class Zt extends Kt {
    constructor(e, t, i) {
      var r =
          3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : v,
        s = 4 < arguments.length ? arguments[4] : void 0;
      super(Xt.DIRECT_METHOD, e, t, r, Yt.STANDARD),
        l(this, "_dispatcher", void 0),
        l(this, "_provisionedUids", void 0),
        l(this, "_metrics", void 0),
        (this._dispatcher = i),
        (this._metrics = s),
        (this._provisionedUids = new Map());
    }
    notifyUidReady(e, t) {
      var i,
        r =
          null == e || null === (i = e.responseObj) || void 0 === i
            ? void 0
            : i.universal_uid;
      r &&
        (this._provisionedUids.has(r)
          ? ((i = this._provisionedUids.get(r)),
            (function (e, t) {
              return e.timer(
                "userid.provisioning.duplicate",
                h({}, 1 < arguments.length && void 0 !== t ? t : {})
              );
            })(this._metrics, {
              provisioner: t.provisioner,
              firstProvisioner: i.provisioner,
            }).record(performance.now() - i.time))
          : (this._provisionedUids.set(r, {
              provisioner: t.provisioner,
              time: performance.now(),
            }),
            this._dispatcher.emit(Ne.USER_ID_READY, e, t)));
    }
    notifyFetchUidCanceled(e) {
      this._dispatcher.emit(Ne.USER_ID_FETCH_CANCELED, e);
    }
    notifyCascadeNeeded(e) {
      this._dispatcher.emit(Ne.CASCADE_NEEDED, e);
    }
  }
  class $t {
    constructor(e, t, i, r) {
      l(this, "_store", void 0),
        l(this, "_log", void 0),
        l(this, "_provisioner", void 0),
        l(this, "_meter", void 0),
        (this._provisioner = e),
        (this._store = t),
        (this._log = i),
        (this._meter = r);
    }
    provisionFromCache(t) {
      var i =
        1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : void 0;
      try {
        const o = this._log;
        var r = t.getCacheId();
        const a = this._store.getCachedResponse(r);
        var s,
          n = !a || !a.isValid() || a.isExpired();
        let e = !1;
        return (
          a &&
            ((s = a.getAgeSec()),
            (function (e, t) {
              return e.summary(
                "userid.cached.age",
                h({}, 1 < arguments.length && void 0 !== t ? t : {})
              );
            })(this._meter, {
              expired: a.isExpired(),
              valid: a.isValid(),
              provisioner: this._provisioner,
              maxAge: a.getMaxAge(),
            }).record(isNaN(s) ? 0 : s)),
          a && a.isValid()
            ? (o.info(
                "Found valid cached response for instance ",
                JSON.stringify({
                  id: t.getId(),
                  cacheId: t.getCacheId(),
                  provisioner: this._provisioner,
                  responseFromCache: a,
                })
              ),
              t.notifyUidReady(
                {
                  timestamp: a.timestamp,
                  responseObj: a.response,
                  isFromCache: !0,
                  consents: a.consents,
                  willBeRefreshed: !!n,
                },
                {
                  timestamp: Date.now(),
                  provisioner: this._provisioner,
                  tags: h({ callType: t.callType }, i),
                }
              ),
              (e = !0))
            : o.info("Couldn't find response for cacheId", t.getCacheId()),
          {
            cacheId: r,
            responseFromCache: a,
            refreshRequired: n,
            provisioned: e,
          }
        );
      } catch (e) {
        return (
          this._log.error("Cached UserId provisioning failure", e),
          { refreshRequired: !0, provisioned: !1 }
        );
      }
    }
  }
  class Qt {
    constructor() {
      var e = 0 < arguments.length && void 0 !== arguments[0] && arguments[0],
        t = 1 < arguments.length && void 0 !== arguments[1] && arguments[1];
      l(this, "lateJoiner", !1),
        l(this, "uniqueLateJoiner", !1),
        (this.lateJoiner = e),
        (this.uniqueLateJoiner = t);
    }
  }
  class ei {
    updateConsent() {}
    updateFetchIdData() {}
    refreshUid() {}
    addFollower() {}
    getProperties() {}
  }
  class ti extends ei {
    constructor(e, t, i, r, s, n) {
      var o =
          6 < arguments.length && void 0 !== arguments[6] ? arguments[6] : v,
        a = 7 < arguments.length ? arguments[7] : void 0;
      super(),
        l(this, "_followers", void 0),
        l(this, "_followersRequests", {}),
        l(this, "_refreshRequired", {}),
        l(this, "_fetcher", void 0),
        l(this, "_log", void 0),
        l(this, "_consentManager", void 0),
        l(this, "_inProgressFetch", void 0),
        l(this, "_queuedRefreshArgs", void 0),
        l(this, "_metrics", void 0),
        l(this, "_leaderStorage", void 0),
        l(this, "_store", void 0),
        (this._followers = []),
        (this._fetcher = a),
        (this._properties = t),
        (this._consentManager = s),
        (this._metrics = n),
        (this._window = e),
        (this._leaderStorage = i),
        (this._log = o),
        (this._store = r),
        (this._firstFetchTriggered = !1),
        (this._cachedIdProvider = new $t(
          "leader",
          this._store,
          this._log,
          this._metrics
        ));
    }
    _handleRefreshResult(e, t, i, r) {
      const s = this._log,
        n = this._consentManager,
        o = this._store;
      if (void 0 !== r) {
        var a;
        n.setStoredPrivacy(
          null === (a = r.getGenericResponse()) || void 0 === a
            ? void 0
            : a.privacy
        );
        const p = n.localStorageGrant("fetcher-after-response");
        p.isDefinitivelyAllowed()
          ? (s.info("Storing ID and request hashes in cache"),
            o.updateNbs(t),
            o.storeResponse(e, r, null == i ? void 0 : i.toConsents()))
          : (s.info("Cannot use local storage to cache ID", p), o.clearAll(e));
        var c,
          d = f(e);
        try {
          for (d.s(); !(c = d.n()).done; ) {
            var l = c.value.integrationId;
            this._followersRequests[l] = (this._followersRequests[l] || 0) + 1;
          }
        } catch (e) {
          d.e(e);
        } finally {
          d.f();
        }
        const v = [];
        var h,
          u = f(this._followers);
        try {
          for (u.s(); !(h = u.n()).done; ) {
            const _ = h.value;
            var g = r.getResponseFor(_.getId());
            void 0 !== g &&
              (this._log.debug(
                "Notify uid ready.",
                "Follower:",
                _.getId(),
                "Uid:",
                g
              ),
              (this._refreshRequired[_.getId()] = !1),
              this._notifyUidReady(_, {
                timestamp: r.timestamp,
                responseObj: g,
                isFromCache: !1,
                consents: null == i ? void 0 : i.toConsents(),
              }),
              !0 === g.cascade_needed && v.push(_.getId()));
          }
        } catch (e) {
          u.e(e);
        } finally {
          u.f();
        }
        void 0 !== i &&
          0 < v.length &&
          this._consentManager
            .localStorageGrant("leader-before-cascade")
            .isDefinitivelyAllowed() &&
          this._handleCascade(v, r, i);
      }
    }
    _notifyUidReady(e, t) {
      var i = {
        timestamp: Date.now(),
        provisioner: "leader",
        tags: { callType: e.callType },
      };
      e.notifyUidReady(t, i);
    }
    _handleCascade(e, t, i) {
      var r,
        s = this._followers
          .filter(
            (t) => void 0 !== e.find((e) => t.getId() === e) && t.canDoCascade()
          )
          .sort((e, t) => {
            function i(e) {
              var t;
              return (
                (null === (e = e.getFetchIdData().refererInfo) ||
                void 0 === e ||
                null === (t = e.stack) ||
                void 0 === t
                  ? void 0
                  : t.length) || Number.MAX_SAFE_INTEGER
              );
            }
            return i(e) - i(t);
          });
      if (0 < s.length) {
        const n = s[0];
        n.notifyCascadeNeeded({
          partnerId: n.getFetchIdData().partnerId,
          userId: t.getResponseFor(n.getId()).universal_uid,
          gdprApplies: i.gdprApplies,
          consentString: i.consentString,
          gppString:
            null === (t = i.gppData) || void 0 === t ? void 0 : t.gppString,
          gppSid:
            null === (i = i.gppData) ||
            void 0 === i ||
            null === (r = i.applicableSections) ||
            void 0 === r
              ? void 0
              : r.join(","),
        });
      } else this._log.error("Couldn't find cascade eligible follower");
    }
    _handleCancel(e) {
      var t,
        i = f(this._followers);
      try {
        for (i.s(); !(t = i.n()).done; ) {
          const r = t.value;
          r.notifyFetchUidCanceled({ reason: e });
        }
      } catch (e) {
        i.e(e);
      } finally {
        i.f();
      }
    }
    _getId() {
      let o = 0 < arguments.length && void 0 !== arguments[0] && arguments[0];
      const d = this._log;
      this._waitForConsent().then((t) => {
        const e = this._consentManager.localStorageGrant(
          "fetch-before-request"
        );
        if ((d.info("Local storage grant", e), e.allowed)) {
          var i = this._store.hasConsentChanged(t);
          e.isDefinitivelyAllowed() && this._store.storeConsent(t);
          var r = Wt.checkIfAccessible(),
            s = this._store.getCachedSignature();
          const c = new Map();
          let a = o;
          const n = this._followers.map((e) => {
            var t = e.getId(),
              i = (this._followersRequests[t] || 0) + 1,
              r = this._properties.id,
              s = !0 === this._refreshRequired[e.getId()];
            a = a || s;
            var n,
              o = e.getCacheId();
            return (
              c.has(o) ||
                ((n = this._store.getCachedResponse(o)) && c.set(o, n)),
              h(
                h({}, e.getFetchIdData()),
                {},
                {
                  integrationId: t,
                  requestCount: i,
                  refresh: s,
                  role: r === e.getId() ? "leader" : e.type || "follower",
                  cacheId: o,
                  cacheData: c.get(o),
                  sourceVersion: e.getSourceVersion(),
                  source: e.getSource(),
                }
              )
            );
          });
          i || a
            ? (d.info("Decided to fetch a fresh ID5 ID", {
                consentHasChanged: i,
                shouldRefresh: a,
              }),
              d.info("Fetching ID5 ID (forceFetch:".concat(o, ")")),
              (this._inProgressFetch = !0),
              (this._firstFetchTriggered = !0),
              this._fetcher
                .fetchId(n, t, r, s)
                .then((e) => {
                  this._handleRefreshResult(n, c, t, e),
                    this._handleFetchCompleted();
                })
                .catch((e) => {
                  this._handleFailed(e), this._handleFetchCompleted();
                }))
            : (d.info("Not decided to refresh ID5 ID", {
                consentHasChanged: i,
                shouldRefresh: a,
              }),
              this._handleFetchCompleted());
        } else
          d.info("No legal basis to use ID5", t),
            this._store.clearAll(
              this._followers.map((e) => ({ cacheId: e.getCacheId() }))
            ),
            this._handleCancel("No legal basis to use ID5");
      });
    }
    _waitForConsent() {
      const t = this._log,
        e = this._consentManager,
        i = this._metrics;
      t.info("Waiting for consent");
      const r = i.timer("fetch.consent.wait.time");
      return e
        .getConsentData()
        .then((e) => (t.info("Consent received", e), r && r.recordNow(), e));
    }
    start() {
      !0 !== this._started && (this._getId(!1), (this._started = !0));
    }
    refreshUid() {
      var e =
        0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {};
      let t = 1 < arguments.length ? arguments[1] : void 0;
      var i = !0 === e.forceFetch;
      t &&
        (i
          ? (this._refreshRequired[t] = !0)
          : (i = this._followers.find((e) => e.getId() === t)) &&
            this._provisionFromCache(i)),
        (function (e, t, i) {
          return e.counter(
            "refresh.call.count",
            h({ target: t }, 2 < arguments.length && void 0 !== i ? i : {})
          );
        })(this._metrics, "leader", {
          overwrites: void 0 === this._queuedRefreshArgs,
        }).inc(),
        this._callRefresh(e, t);
    }
    _callRefresh() {
      var e =
          0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {},
        t = 1 < arguments.length ? arguments[1] : void 0;
      this._inProgressFetch
        ? (this._queuedRefreshArgs = [e, t])
        : (!0 === e.resetConsent &&
            (this._consentManager.resetConsentData(
              !0 === e.forceAllowLocalStorageGrant
            ),
            (this._awaitedConsentFrom = t)),
          this._getId(!0 === e.forceFetch));
    }
    updateConsent(e, t) {
      if (this._consentManager.hasConsentSet())
        this._handleIgnoredConsentUpdate(e);
      else {
        const s = new Set(
          this._followers
            .map((e) => e.getDeclaredConsentSource())
            .filter((e) => e !== se.none)
        );
        var i = e.source || se.cmp,
          r = 1 === s.size && s.has(se.partner);
        this._awaitedConsentFrom
          ? this._awaitedConsentFrom === t
            ? (this._consentManager.setConsentData(e),
              (this._awaitedConsentFrom = void 0))
            : this._handleIgnoredConsent(e, "awaited")
          : i !== se.partner || r
          ? this._consentManager.setConsentData(e)
          : this._handleIgnoredConsent(e, "partner");
      }
    }
    _handleIgnoredConsentUpdate(e) {
      try {
        const r = this._consentManager._consentDataHolder.getValue();
        if (r) {
          const s = {},
            n = ce.createFrom(e);
          Object.values(re).forEach((e) => {
            var t, i;
            n.apiTypes.includes(e) && r.apiTypes.includes(e)
              ? ((t = JSON.stringify(r.getApiTypeData(e))),
                (i = JSON.stringify(n.getApiTypeData(e))),
                (s[e] = t === i ? "same" : "different"))
              : n.apiTypes.includes(e)
              ? (s[e] = "added")
              : r.apiTypes.includes(e) && (s[e] = "missed");
          }),
            (function (e, t) {
              return e.counter(
                "leader.consent.change.count",
                1 < arguments.length && void 0 !== t ? t : {}
              );
            })(this._metrics, s).inc();
        }
      } catch (e) {
        this._log.error(e);
      }
    }
    _handleIgnoredConsent(e, t) {
      try {
        const i = { reason: t, source: e.source };
        e.apiTypes.forEach((e) => (i[e] = !0)),
          (function (e, t) {
            return e.counter(
              "leader.consent.ignore.count",
              1 < arguments.length && void 0 !== t ? t : {}
            );
          })(this._metrics, i).inc();
      } catch (e) {
        this._log.error(e);
      }
    }
    updateFetchIdData(t, e) {
      const i = this._followers.find((e) => e.getId() === t);
      var r = i.getCacheId();
      i.updateFetchIdData(e);
      e = i.getCacheId();
      e !== r &&
        (this._log.info(
          "Follower",
          i.getId(),
          "cacheId changed from",
          r,
          " to",
          e,
          "required refresh"
        ),
        (this._refreshRequired[i.getId()] = !0));
    }
    addFollower(t) {
      const e = this._log;
      var i =
        void 0 ===
        this._followers.find((e) => e.getCacheId() === t.getCacheId());
      this._followers.push(t),
        e.debug("Added follower", t.getId(), "cacheId", t.getCacheId()),
        this._window !== t.getWindow() &&
          ((r = t.getStorage()),
          e.debug("Adding follower's", t.getId(), "storage as replica"),
          this._leaderStorage.addReplica(r));
      var r = this._provisionFromCache(t);
      let s = new Qt();
      return (
        !0 === this._firstFetchTriggered &&
          ((s.lateJoiner = !0),
          (s.uniqueLateJoiner = i),
          r && this._callRefresh({ forceFetch: !0 })),
        s
      );
    }
    _provisionFromCache(e) {
      var t = this._cachedIdProvider.provisionFromCache(e);
      return (
        (this._refreshRequired[e.getId()] = t.refreshRequired),
        t.provisioned && this._store.incNb(t.cacheId),
        t.refreshRequired
      );
    }
    getProperties() {
      return this._properties;
    }
    _handleFetchCompleted() {
      (this._inProgressFetch = void 0),
        this._queuedRefreshArgs &&
          (this._callRefresh(...this._queuedRefreshArgs),
          (this._queuedRefreshArgs = void 0));
    }
    _handleFailed(e) {
      this._log.error("Fetch id failed", e);
      var t,
        i = f(this._followers);
      try {
        for (i.s(); !(t = i.n()).done; ) {
          const r = t.value;
          r.notifyFetchUidCanceled({ reason: "error" });
        }
      } catch (e) {
        i.e(e);
      } finally {
        i.f();
      }
    }
  }
  class ii extends ei {
    constructor(e, t) {
      super(),
        l(this, "_messenger", void 0),
        l(this, "_leaderInstanceProperties", void 0),
        (this._messenger = e),
        (this._leaderInstanceProperties = t);
    }
    _sendToLeader(e, t) {
      this._messenger.callProxyMethod(
        this._leaderInstanceProperties.id,
        Tt.LEADER,
        e,
        t
      );
    }
    updateConsent(e, t) {
      this._sendToLeader("updateConsent", [e, t]);
    }
    refreshUid(e, t) {
      this._sendToLeader("refreshUid", [e, t]);
    }
    updateFetchIdData(e, t) {
      this._sendToLeader("updateFetchIdData", [e, t]);
    }
    getProperties() {
      return this._leaderInstanceProperties;
    }
  }
  class ri extends ei {
    constructor() {
      super(...arguments),
        l(this, "_callsQueue", []),
        l(this, "_assignedLeader", void 0);
    }
    updateConsent(e, t) {
      this._callOrBuffer("updateConsent", [e, t]);
    }
    updateFetchIdData(e, t) {
      this._callOrBuffer("updateFetchIdData", [e, t]);
    }
    refreshUid(e, t) {
      this._callOrBuffer("refreshUid", [e, t]);
    }
    addFollower(e) {
      return this._callOrBuffer("addFollower", [e]);
    }
    getProperties() {
      if (this._assignedLeader) return this._assignedLeader.getProperties();
    }
    assignLeader(e) {
      this._assignedLeader = e;
      var t,
        i = f(this._callsQueue);
      try {
        for (i.s(); !(t = i.n()).done; ) {
          var r = t.value;
          this._callAssignedLeader(r.name, r.args);
        }
      } catch (e) {
        i.e(e);
      } finally {
        i.f();
      }
      this._callsQueue = [];
    }
    _callOrBuffer(e, t) {
      if (this._assignedLeader) return this._callAssignedLeader(e, t);
      this._callsQueue.push({ name: e, args: t });
    }
    _callAssignedLeader(e, t) {
      return this._assignedLeader[e](...t);
    }
  }
  class si extends Vt {
    constructor(e, t) {
      super(),
        l(this, "_messenger", void 0),
        l(this, "_destinationId", void 0),
        (this._messanger = e),
        (this._destinationId = t);
    }
    getItem() {}
    removeItem(e) {
      this._remoteCall("removeItem", [e]);
    }
    setItem(e, t) {
      this._remoteCall("setItem", [e, t]);
    }
    _remoteCall(e, t) {
      this._messanger.callProxyMethod(this._destinationId, Tt.STORAGE, e, t);
    }
  }
  class ni extends Kt {
    constructor(e, t) {
      var i =
          2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : v,
        r =
          3 < arguments.length && void 0 !== arguments[3]
            ? arguments[3]
            : Yt.STANDARD;
      super(Xt.POST_MESSAGE, e.getWindow(), e.properties, i, r),
        l(this, "_messenger", void 0),
        (this._messenger = t);
    }
    _callProxy(e, t) {
      this._messenger.callProxyMethod(this.getId(), Tt.FOLLOWER, e, t);
    }
    notifyUidReady(e, t) {
      this._callProxy("notifyUidReady", [e, t]);
    }
    notifyFetchUidCanceled(e) {
      this._callProxy("notifyFetchUidCanceled", [e]);
    }
    notifyCascadeNeeded(e) {
      this._callProxy("notifyCascadeNeeded", [e]);
    }
    getStorage() {
      return new si(this._messenger, this.getId());
    }
  }
  class oi {
    constructor() {
      l(this, "_valuePromise", void 0),
        l(this, "_value", void 0),
        l(this, "_resolve", void 0),
        l(this, "_hasValue", void 0),
        this.reset();
    }
    reset() {
      (this._value = void 0),
        (this._hasValue = !1),
        (this._valuePromise = new Promise((e) => {
          this._resolve = e;
        }));
    }
    set(e) {
      this._hasValue
        ? (this._valuePromise = Promise.resolve(e))
        : ((this._hasValue = !0), this._resolve(e)),
        (this._value = e);
    }
    getValuePromise() {
      return this._valuePromise;
    }
    hasValue() {
      return this._hasValue;
    }
    getValue() {
      return this._value;
    }
  }
  class ai extends class {
    getConsentData() {}
    localStorageGrant() {}
    setStoredPrivacy() {}
  } {
    constructor(e, t, i, r, s) {
      super(),
        l(this, "_consentDataHolder", void 0),
        l(this, "storedPrivacyData", void 0),
        l(this, "localStorage", void 0),
        l(this, "_forceAllowLocalStorageGrant", void 0),
        (this._log = r),
        (this.localStorage = e),
        (this.storageConfig = t),
        (this._consentDataHolder = new oi()),
        (this._forceAllowLocalStorageGrant = i),
        (this._metrics = s);
    }
    isForceAllowLocalStorageGrant() {
      return this._forceAllowLocalStorageGrant;
    }
    resetConsentData(e) {
      this._consentDataHolder.reset(),
        (this.storedPrivacyData = void 0),
        (this._forceAllowLocalStorageGrant = e);
    }
    localStorageGrant() {
      var e =
          0 < arguments.length && void 0 !== arguments[0]
            ? arguments[0]
            : "unknown",
        t = this._getLocalStorageGrant();
      return (
        null !==
          (e = (function (e, t) {
            return e.counter(
              "consent.lsg.count",
              1 < arguments.length && void 0 !== t ? t : {}
            );
          })(
            this._metrics,
            h(
              h(
                {
                  allowed: t.allowed,
                  grantType: t.grantType,
                  lsgContext: e,
                  consentSet:
                    null === (e = this._consentDataHolder) || void 0 === e
                      ? void 0
                      : e.hasValue(),
                },
                t.api
              ),
              t._debugInfo
            )
          )) &&
          void 0 !== e &&
          e.inc(),
        t
      );
    }
    _getLocalStorageGrant() {
      const e = this._log;
      if (!0 === this._forceAllowLocalStorageGrant)
        return (
          e.warn(
            "cmpApi: Local storage access granted by configuration override, consent will not be checked"
          ),
          new le(!0, de.FORCE_ALLOWED_BY_CONFIG)
        );
      if (
        this._consentDataHolder.hasValue() &&
        0 !== this._consentDataHolder.getValue().apiTypes.length
      )
        return this._consentDataHolder.getValue().localStorageGrant();
      if (
        (E(this.storedPrivacyData) ||
          ((t = this.localStorage.getItemWithExpiration(
            this.storageConfig.PRIVACY
          )),
          (this.storedPrivacyData = t && JSON.parse(t)),
          e.info(
            "cmpApi: Loaded stored privacy data from local storage",
            this.storedPrivacyData
          )),
        this.storedPrivacyData && !0 === this.storedPrivacyData.id5_consent)
      )
        return new le(!0, de.ID5_CONSENT);
      if (!this.storedPrivacyData || !A(this.storedPrivacyData.jurisdiction))
        return new le(!0, de.PROVISIONAL);
      var t = this.storedPrivacyData.jurisdiction,
        t = t in xt.PRIVACY.JURISDICTIONS && xt.PRIVACY.JURISDICTIONS[t];
      return new le(!1 === t, de.JURISDICTION);
    }
    setStoredPrivacy(e) {
      const t = this._log;
      try {
        E(e)
          ? ((this.storedPrivacyData = e),
            this.localStorage.setItemWithExpiration(
              this.storageConfig.PRIVACY,
              JSON.stringify(e)
            ))
          : t.error(
              "cmpApi: Cannot store privacy data if it is not an object",
              e
            );
      } catch (e) {
        t.error("cmpApi: Error while storing privacy data", e);
      }
    }
    setConsentData(e) {
      this._log.debug("Set consent data", e);
      e = ce.createFrom(e);
      this._consentDataHolder.set(e);
    }
    getConsentData() {
      return this._consentDataHolder.getValuePromise();
    }
    hasConsentSet() {
      return this._consentDataHolder.hasValue();
    }
  }
  class ci {
    constructor(e, t, i, r) {
      l(this, "localStorageGrantChecker", void 0),
        l(this, "localStorage", void 0),
        l(this, "_log", void 0),
        (this.localStorageGrantChecker = e),
        (this.localStorage = t),
        (this.storageConfig = i),
        (this._log = r);
    }
    get(e) {
      const t = this._log;
      try {
        const r = this.localStorageGrant();
        if (r.isDefinitivelyAllowed()) {
          var i = this.localStorage.getItemWithExpiration(e);
          return (
            t.info(
              "Local storage get key=".concat(e.name, " value=").concat(i)
            ),
            i
          );
        }
        t.warn("clientStore.get() has been called without definitive grant", r);
      } catch (e) {
        t.error(e);
      }
    }
    _getObject(e) {
      const t = this._log;
      try {
        const r = this.localStorageGrant();
        if (r.isDefinitivelyAllowed()) {
          var i = this.localStorage.getObjectWithExpiration(e);
          return (
            t.info(
              "Local storage get key=".concat(e.name, " value=").concat(i)
            ),
            i
          );
        }
        t.warn("clientStore.get() has been called without definitive grant", r);
      } catch (e) {
        t.error(e);
      }
    }
    clear(e) {
      const t = this._log;
      try {
        this.localStorage.removeItemWithExpiration(e);
      } catch (e) {
        t.error(e);
      }
    }
    scheduleGC(i) {
      const r = this.localStorageGrant(),
        s = this.localStorage,
        n = this.storageConfig.ID5_V2.name,
        o = this.storageConfig.ID5;
      setTimeout(function () {
        if (r.isDefinitivelyAllowed()) {
          var e = s.removeExpiredObjectWithPrefix(n);
          !(function (e, t) {
            return e.summary(
              "storage.keys.all.count",
              1 < arguments.length && void 0 !== t ? t : {}
            );
          })(i).record((null == e ? void 0 : e.all) || 0),
            St(i, { legacy: !1, expiredDaysAgo: -1 }).record(
              (null == e ? void 0 : e.expired) || 0
            );
          const t = s.removeExpiredItem(o);
          e = t.expiredAt
            ? ((t.expiredAt.getTime() - Date.now()) / 24) * 3600 * 1e3
            : 0;
          St(i, { legacy: !0, expiredDaysAgo: e }).record(1);
        }
      }, 0);
    }
    _clearObject(e) {
      const t = this._log;
      try {
        this.localStorage.removeItem(e.name);
      } catch (e) {
        t.error(e);
      }
    }
    _put(e, t) {
      const i = this._log;
      try {
        const r = this.localStorageGrant();
        r.isDefinitivelyAllowed()
          ? (i.info(
              "Local storage put key=".concat(e.name, " value=").concat(t)
            ),
            this.localStorage.setItemWithExpiration(e, t))
          : i.warn(
              "clientStore._put() has been called without definitive grant",
              r
            );
      } catch (e) {
        i.error(e);
      }
    }
    _updateObject(e, t) {
      const i = this._log;
      try {
        const r = this.localStorageGrant();
        if (r.isDefinitivelyAllowed())
          return this.localStorage.updateObjectWithExpiration(e, t);
        i.warn(
          "clientStore._updateObject() has been called without definitive grant",
          r
        );
      } catch (e) {
        i.error(e);
      }
    }
    localStorageGrant() {
      return this.localStorageGrantChecker();
    }
    clearResponseV1() {
      this.clear(this.storageConfig.ID5);
    }
    clearResponseV2(e) {
      this._clearObject(this.storageConfig.ID5_V2.withNameSuffixed(e));
    }
    getHashedConsentData() {
      return this.get(this.storageConfig.CONSENT_DATA);
    }
    clearHashedConsentData() {
      this.clear(this.storageConfig.CONSENT_DATA);
    }
    putHashedConsentData(e) {
      e !== new ce() &&
        this._put(this.storageConfig.CONSENT_DATA, e.hashCode());
    }
    clearDateTime() {
      this.clear(this.storageConfig.LAST);
    }
    storeResponseV2(e, t) {
      let i =
          2 < arguments.length && void 0 !== arguments[2]
            ? arguments[2]
            : Date.now(),
        r = 3 < arguments.length ? arguments[3] : void 0;
      return this._updateObject(
        this.storageConfig.ID5_V2.withNameSuffixed(e),
        (e) =>
          h(h({}, e), {}, { response: t, responseTimestamp: i, consents: r })
      );
    }
    getStoredResponseV2(e) {
      return this._getObject(this.storageConfig.ID5_V2.withNameSuffixed(e));
    }
    storeSignature(e) {
      return this._updateObject(this.storageConfig.ID5_SIGNATURE, () => ({
        signature: e,
      }));
    }
    getStoredSignature() {
      return this._getObject(this.storageConfig.ID5_SIGNATURE);
    }
    clearSignature() {
      return this._clearObject(this.storageConfig.ID5_SIGNATURE);
    }
    incNbV2(e) {
      let i =
        1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 1;
      return this._updateObject(
        this.storageConfig.ID5_V2.withNameSuffixed(e),
        (e) => {
          var t = Math.max(
            0,
            D(null == e ? void 0 : e.nb) ? Math.round(e.nb) + i : i
          );
          return h(h({}, e), {}, { nb: t });
        }
      );
    }
    static storedDataMatchesCurrentData(e, t) {
      return null == e || e === t;
    }
    storedConsentDataMatchesConsentData(e) {
      return ci.storedDataMatchesCurrentData(
        this.getHashedConsentData(),
        e.hashCode()
      );
    }
    getExtensions() {
      return this._getObject(this.storageConfig.EXTENSIONS);
    }
    storeExtensions(e, t) {
      return this._updateObject(t, () => e);
    }
    clearExtensions() {
      return this.clear(this.storageConfig.EXTENSIONS);
    }
  }
  const di = ["usedApiBase"],
    li = "https://lbs.eu-1-id5-sync.com/lbs/v1";
  var hi,
    ui = new WeakSet(),
    gi = new WeakSet(),
    pi = new WeakSet(),
    vi = new WeakSet(),
    _i = new WeakSet(),
    fi = new WeakSet(),
    mi = new WeakSet(),
    Ii = new WeakSet();
  class wi {
    constructor(e, t, i) {
      var r =
        3 < arguments.length && void 0 !== arguments[3]
          ? arguments[3]
          : new Xe();
      Ii.add(this),
        mi.add(this),
        fi.add(this),
        _i.add(this),
        vi.add(this),
        pi.add(this),
        gi.add(this),
        ui.add(this),
        l(this, "_metrics", void 0),
        l(this, "_log", void 0),
        l(this, "_store", void 0),
        (this._metrics = e),
        (this._log = t),
        (this._store = i),
        (this._fallbackEndpoints = r);
    }
    retryEndpoints(e) {
      return this._fallbackEndpoints.retryFor(e);
    }
    confirmApiBase(e, t) {
      var i, r;
      e.isFallback
        ? ((i = e),
          (r = t.endpoints),
          (null != i &&
            null != r &&
            i.apiBase === r.apiBase &&
            t.apiBaseStored) ||
            p(this, ui, yi).call(this, e, t.extensions))
        : t.endpoints.isFallback && this._store.clearExtensions();
    }
    static getChunkUrl(e, t) {
      return "https://d".concat(e, ".eu-").concat(t, "-id5-sync.com");
    }
    gather(e) {
      var t = this._store.getCachedExtensions();
      if (void 0 !== t) {
        var i = t.usedApiBase,
          t = s(t, di),
          i = this._fallbackEndpoints.endpointsForApiBase(i);
        if (i)
          return Promise.resolve({
            extensions: t,
            endpoints: i,
            apiBaseStored: !0,
          });
      }
      const r = p(this, fi, Ei)
        .call(this, e)
        .then(
          (e) => ({ data: e, reachable: !0 }),
          () => ({ data: {}, reachable: !1 })
        );
      return Promise.all([
        p(this, vi, Ci).call(
          this,
          e,
          r.then((e) => {
            return e.data;
          })
        ),
        r,
      ]).then((e) => {
        var t = g(e, 2),
          e = t[0],
          t = (!t[1].reachable && this._fallbackEndpoints.getEndpoints()) || ze;
        return t.isFallback
          ? (this._log.warn("Using ".concat(t.fetch)),
            { extensions: e, endpoints: t, apiBaseStored: !1 })
          : (p(this, ui, yi).call(this, t, e),
            { extensions: e, endpoints: t, apiBaseStored: !0 });
      });
    }
  }
  function yi(e, t) {
    this._store.storeExtensions(h(h({}, t), {}, { usedApiBase: e.apiBase }));
  }
  function bi(t, i) {
    var e =
      2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : void 0;
    let r = Ce();
    return fetch(t, h(h({}, e), {}, { referrerPolicy: "origin" }))
      .then((e) => {
        if (e.ok) return r.record(yt(this._metrics, i, !0)), e.json();
        r.record(yt(this._metrics, i, !1));
        e = "The call to get extensions at "
          .concat(t, " was not ok, status: ")
          .concat(e.status, ", statusText: ")
          .concat(e.statusText);
        return this._log.warn(e), Promise.reject(new Error(e));
      })
      .catch(
        (e) => (
          r.record(yt(this._metrics, i, !1)),
          this._log.warn("Got error from ".concat(t, " endpoint"), e),
          {}
        )
      );
  }
  function Si(e, i) {
    if (e) {
      let t = Ce();
      return Promise.all(
        Array.from({ length: i.length }, (e, t) => {
          t = wi.getChunkUrl(t, i.urlVersion);
          return fetch(t, { referrerPolicy: "origin" }).then((e) => {
            if (e.ok) return e.text();
            throw new Error(
              "The call to get "
                .concat(i.name, " was not ok, status: ")
                .concat(e.status, ", statusText: ")
                .concat(e.statusText)
            );
          });
        })
      )
        .then(
          (e) => (
            t.record(yt(this._metrics, i.name, !0)),
            { [i.name]: e, [i.name + "Version"]: "".concat(i.version) }
          )
        )
        .catch(
          (e) => (
            t.record(yt(this._metrics, i.name, !1)),
            this._log.warn("Got error when getting ".concat(i.name), e),
            {}
          )
        );
    }
    return Promise.resolve({});
  }
  function Ci(i, r) {
    let s = Ce(),
      n = p(this, _i, Di).call(this);
    return p(this, gi, bi)
      .call(this, "https://lb.eu-1-id5-sync.com/lb/v1", "lb")
      .then((e) => {
        var t = p(this, mi, Ai).call(this, e, p(this, Ii, Ti).call(this, i));
        return Promise.allSettled([
          Promise.resolve(e),
          p(this, pi, Si).call(this, t, wi.CHUNKS_CONFIGS.devChunks),
          p(this, pi, Si).call(this, t, wi.CHUNKS_CONFIGS.groupChunks),
          r,
          n,
        ]);
      })
      .then((e) => {
        s.record(yt(this._metrics, "all", !0));
        let t = wi.DEFAULT_RESPONSE;
        return (
          e.forEach((e) => {
            e.value && (t = h(h({}, t), e.value));
          }),
          t
        );
      })
      .catch(
        (e) => (
          s.record(yt(this._metrics, "all", !1)),
          this._log.error(
            "Got error ".concat(e, " when gathering extensions data")
          ),
          wi.DEFAULT_RESPONSE
        )
      );
  }
  function Di() {
    const e = new AbortController(),
      t = setTimeout(() => e.abort(), 3e3);
    let i = p(this, gi, bi).call(this, li, "lbs", { signal: e.signal });
    return i.finally(() => {
      clearTimeout(t);
    });
  }
  function Ei(e) {
    const t = p(this, Ii, Ti).call(this, e),
      i = ze.bounce;
    let r = Ce();
    return fetch(i, {
      credentials: t ? "omit" : "include",
      referrerPolicy: "origin",
    }).then(
      (e) => (
        r.record(yt(this._metrics, "bounce", e.ok)),
        e.ok && !t ? e.json().catch(() => ({})) : {}
      ),
      (e) => (
        r.record(yt(this._metrics, "bounce", !1)),
        this._log.warn("Got error from ".concat(i, " endpoint"), e),
        Promise.reject(e)
      )
    );
  }
  function Ai(e, t) {
    e = null == e ? void 0 : e.chunks;
    return 0 !== e && !t && e;
  }
  function Ti(e) {
    return e.some((e) => !0 === e.idLookupMode);
  }
  l(
    wi,
    "CHUNKS_CONFIGS",
    Object.freeze({
      devChunks: { name: "devChunks", urlVersion: 3, length: 8, version: 4 },
      groupChunks: {
        name: "groupChunks",
        urlVersion: 4,
        length: 8,
        version: 4,
      },
    })
  ),
    l(wi, "DEFAULT_RESPONSE", { lbCDN: "%%LB_CDN%%" });
  const Pi = {
      createExtensions: function (e, t, i, r) {
        return new wi(e, t, i, r);
      },
    },
    Oi = Object.freeze({
      UNKNOWN: "unknown",
      LEADER: "leader",
      FOLLOWER: "follower",
    }),
    Ri = Object.freeze({
      MULTIPLEXING: "multiplexing",
      SINGLETON: "singleton",
      MULTIPLEXING_PASSIVE: "multiplexing-passive",
    }),
    xi = Object.freeze({
      AWAITING_SCHEDULE: "awaiting_schedule",
      SKIPPED: "skipped",
      SCHEDULED: "scheduled",
      COMPLETED: "completed",
      CANCELED: "canceled",
    }),
    Fi = Symbol.for("id5.multiplexing.windowId");
  class Li {
    constructor(e, t, i) {
      l(this, "properties", void 0),
        l(this, "knownState", void 0),
        l(this, "_joinTime", void 0),
        l(this, "_window", void 0),
        (this.properties = e),
        (this.knownState = t),
        (this._window = i),
        (this._joinTime = performance.now());
    }
    getId() {
      return this.properties.id;
    }
    isMultiplexingPartyAllowed() {
      var e =
        null === (e = this.knownState) || void 0 === e
          ? void 0
          : e.operatingMode;
      return e === Ri.MULTIPLEXING || e === Ri.MULTIPLEXING_PASSIVE;
    }
    isLeaderCapable() {
      var e;
      return (
        (null === (e = this.knownState) || void 0 === e
          ? void 0
          : e.operatingMode) === Ri.MULTIPLEXING
      );
    }
    isPassive() {
      var e;
      return (
        (null === (e = this.knownState) || void 0 === e
          ? void 0
          : e.operatingMode) === Ri.MULTIPLEXING_PASSIVE
      );
    }
    getInstanceMultiplexingLeader() {
      var e, t;
      if (
        (null === (e = this.knownState) || void 0 === e
          ? void 0
          : e.operatingMode) === Ri.MULTIPLEXING
      )
        return null === (e = this.knownState) ||
          void 0 === e ||
          null === (t = e.multiplexing) ||
          void 0 === t
          ? void 0
          : t.leader;
    }
    getWindow() {
      return this._window;
    }
  }
  class ki {
    constructor(e, t, i, r) {
      l(this, "properties", void 0),
        l(this, "_messenger", void 0),
        l(this, "_knownInstances", new Map()),
        l(this, "role", void 0),
        l(this, "_mode", void 0),
        l(this, "_metrics", void 0),
        l(this, "_logger", void 0),
        l(this, "_window", void 0);
      var s = P();
      (this.properties = u(
        {
          id: s,
          version: "1.0.49",
          windowId: (function (e) {
            try {
              return (
                e[Fi] ||
                  Object.defineProperty(e, Fi, { value: P(), enumerable: !1 }),
                e[Fi]
              );
            } catch (e) {
              return;
            }
          })(e),
          domain:
            null === (s = e.location) || void 0 === s ? void 0 : s.hostname,
        },
        t
      )),
        (this.role = Oi.UNKNOWN),
        (this._metrics = i),
        (this._loadTime = performance.now()),
        (this._logger = new Ui(r, this)),
        (this._window = e),
        (this._dispatcher = new Ve(this._logger)),
        (this._followerRole = new Zt(
          this._window,
          this.properties,
          this._dispatcher,
          this._logger,
          this._metrics
        ));
    }
    updateConfig(e) {
      u(this.properties, e);
    }
    register(e) {
      try {
        this.updateConfig(e),
          this.init(),
          this._messenger.broadcastMessage(
            this._createHelloMessage(!1),
            At.TYPE
          );
      } catch (e) {
        this._logger.error("Failed to register integration instance", e);
      }
      return this;
    }
    init() {
      let r = this,
        s = r._window;
      (r._mode = Ri.MULTIPLEXING_PASSIVE),
        (r._messenger = new Rt(r.properties.id, s, r._logger, r._metrics)),
        r._messenger
          .onAnyMessage((e, t) => {
            var i = (Date.now() - e.timestamp) | 0;
            !(function (e, t) {
              return e.timer(
                "instance.message.delivery.time",
                1 < arguments.length && void 0 !== t ? t : {}
              );
            })(r._metrics, { messageType: e.type, sameWindow: s === t }).record(
              i
            ),
              r._logger.debug("Message received", e),
              r._doFireEvent(je.ID5_MESSAGE_RECEIVED, e);
          })
          .onMessage(At.TYPE, (e, t) => {
            let i = u(new At(), e.payload);
            void 0 === i.isResponse && (i.isResponse = void 0 !== e.dst),
              r._handleHelloMessage(i, e, t);
          });
    }
    _handleHelloMessage(e, t, i) {
      var r = e.isResponse;
      const s = new Li(e.instance, e.instanceState, i);
      this._knownInstances.get(s.getId())
        ? this._logger.debug("Instance already known", s.getId())
        : (this._knownInstances.set(s.getId(), s),
          r ||
            this._messenger.sendResponseMessage(
              t,
              this._createHelloMessage(!0),
              At.TYPE
            ),
          this._logger.debug("Instance joined", s.getId()),
          this._doFireEvent(je.ID5_INSTANCE_JOINED, s.properties),
          this._onInstanceDiscovered(e, s));
    }
    unregister() {
      this._logger.info("Unregistering"),
        this._messenger && this._messenger.unregister();
    }
    on(e, t) {
      return this._dispatcher.on(e, t), this;
    }
    _onInstanceDiscovered() {}
    _createHelloMessage() {
      var e = 0 < arguments.length && void 0 !== arguments[0] && arguments[0],
        t = {
          operatingMode: this._mode,
          knownInstances: Array.from(this._knownInstances.values()).map(
            (e) => e.properties
          ),
        };
      return new At(this.properties, e, t);
    }
    _doFireEvent(e) {
      for (
        var t = arguments.length, i = new Array(1 < t ? t - 1 : 0), r = 1;
        r < t;
        r++
      )
        i[r - 1] = arguments[r];
      this._dispatcher.emit(e, ...i);
    }
    getId() {
      return this.properties.id;
    }
  }
  class Ui extends e {
    constructor(e, t) {
      super(),
        l(this, "_instance", void 0),
        (this._delegate = e || v),
        (this._instance = t);
    }
    _prefix() {
      return "Instance(id="
        .concat(this._instance.getId(), ", role=")
        .concat(this._instance.role, ")");
    }
    debug() {
      for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
        t[i] = arguments[i];
      this._delegate.debug(new Date().toISOString(), this._prefix(), ...t);
    }
    info() {
      for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
        t[i] = arguments[i];
      this._delegate.info(new Date().toISOString(), this._prefix(), ...t);
    }
    warn() {
      for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
        t[i] = arguments[i];
      this._delegate.warn(new Date().toISOString(), this._prefix(), ...t);
    }
    error() {
      for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
        t[i] = arguments[i];
      this._delegate.error(new Date().toISOString(), this._prefix(), ...t);
    }
  }
  class Ni {
    constructor(e) {
      l(this, "_knownValues", []),
        l(this, "_counter", void 0),
        (this._counter = e);
    }
    add(e) {
      e &&
        -1 === this._knownValues.indexOf(e) &&
        (this._counter.inc(), this._knownValues.push(e));
    }
  }
  class ji {
    constructor(e, t) {
      l(this, "_instancesCounter", void 0),
        l(this, "_domainsCounter", void 0),
        l(this, "_windowsCounter", void 0),
        l(this, "_partnersCounter", void 0);
      var i = t.id;
      (this._instancesCounter = (function (e, t, i) {
        return e.counter(
          "instance.count",
          h({ instanceId: t }, 2 < arguments.length && void 0 !== i ? i : {})
        );
      })(e, t.id)),
        (this._windowsCounter = new Ni(
          (function (e, t, i) {
            return e.counter(
              "instance.windows.count",
              h(
                { instanceId: t },
                2 < arguments.length && void 0 !== i ? i : {}
              )
            );
          })(e, i)
        )),
        (this._partnersCounter = new Ni(
          (function (e, t, i) {
            return e.counter(
              "instance.partners.count",
              h(
                { instanceId: t },
                2 < arguments.length && void 0 !== i ? i : {}
              )
            );
          })(e, i)
        )),
        (this._domainsCounter = new Ni(
          (function (e, t, i) {
            return e.counter(
              "instance.domains.count",
              h(
                { instanceId: t },
                2 < arguments.length && void 0 !== i ? i : {}
              )
            );
          })(e, i)
        ));
    }
    addInstance(e) {
      var t, i, r;
      this._instancesCounter.inc(),
        this._partnersCounter.add(
          (null == e || null === (t = e.fetchIdData) || void 0 === t
            ? void 0
            : t.partnerId) |
            (null == e ||
            null === (i = e.sourceConfiguration) ||
            void 0 === i ||
            null === (r = i.options) ||
            void 0 === r
              ? void 0
              : r.partnerId)
        ),
        this._domainsCounter.add(null == e ? void 0 : e.domain),
        this._windowsCounter.add(
          (null == e ? void 0 : e.windowId) || (null == e ? void 0 : e.href)
        );
    }
  }
  class Mi {
    constructor(e) {
      l(this, "_scheduleTime", void 0),
        l(this, "_closeTime", void 0),
        l(this, "_timeoutId", void 0),
        l(this, "_state", xi.AWAITING_SCHEDULE),
        l(this, "_delayMs", void 0),
        l(this, "_instance", void 0),
        (this._instance = e);
    }
    schedule(e) {
      const t = this;
      (t._delayMs = e),
        (this._timeoutId = setTimeout(() => {
          t._timeoutId &&
            ((t._timeoutId = void 0),
            t._instance._doElection(),
            t._closeWithState(xi.COMPLETED));
        }, t._delayMs)),
        (t._state = xi.SCHEDULED),
        (t._scheduleTime = performance.now());
    }
    skip() {
      this._closeWithState(xi.SKIPPED);
    }
    cancel() {
      this._timeoutId &&
        (clearTimeout(this._timeoutId), (this._timeoutId = void 0)),
        this._closeWithState(xi.CANCELED);
    }
    _closeWithState(e) {
      (this._state = e), (this._closeTime = performance.now());
    }
  }
  class Vi extends ki {
    constructor(e, t, i, r, s, n, o) {
      super(e, t, r, s),
        l(this, "_lastJoinedInstance", void 0),
        l(this, "_leader", void 0),
        l(this, "_remoteCallsToLeaderHandler", void 0),
        l(this, "_instanceCounters", void 0),
        l(this, "_election", void 0),
        l(this, "_storage", void 0),
        l(this, "_trueLinkAdapter", void 0),
        l(this, "_cachedIdProvider", void 0),
        (this._leader = new ri()),
        (this._remoteCallsToLeaderHandler = new ri()),
        (this._instanceCounters = new ji(r, this.properties)),
        (this._storage = i),
        (this._trueLinkAdapter = n),
        (this._cachedIdProvider = new $t(
          "self",
          new kt(o, n),
          this._logger,
          this._metrics
        )),
        (this._election = new Mi(this));
    }
    init() {
      super.init();
      var e,
        t = this;
      (t._mode =
        !0 === t.properties.singletonMode ? Ri.SINGLETON : Ri.MULTIPLEXING),
        t._instanceCounters.addInstance(t.properties),
        (function (i) {
          const r = i._metrics;
          [100, 200, 500, 1e3, 2e3, 3e3, 5e3].forEach((t) => {
            setTimeout(() => {
              var e =
                ((null === (e = i._knownInstances) || void 0 === e
                  ? void 0
                  : e.size) || 0) + 1;
              r.summary("instance.partySize", {
                after: t,
                electionState: i._election._state,
              }).record(e);
            }, t);
          });
        })(t),
        t._messenger.onProxyMethodCall(
          new Ot(t._logger)
            .registerTarget(Tt.LEADER, t._remoteCallsToLeaderHandler)
            .registerTarget(Tt.FOLLOWER, t._followerRole)
            .registerTarget(Tt.STORAGE, t._storage)
        ),
        t._mode === Ri.SINGLETON
          ? (t._election.skip(), t._onLeaderElected(t.properties))
          : t._mode === Ri.MULTIPLEXING &&
            ((e = t.properties.electionDelayMSec || 500),
            t._election.schedule(e));
    }
    _onInstanceDiscovered(e, t) {
      e = e.isResponse;
      (this._lastJoinedInstance = t),
        this._instanceCounters.addInstance(t.properties),
        (function (e, t) {
          return e.timer(
            "instance.join.delay.time",
            1 < arguments.length && void 0 !== t ? t : {}
          );
        })(this._metrics, { election: this._election._state }).record(
          (performance.now() - this._loadTime) | 0
        ),
        e
          ? ((e = t.getInstanceMultiplexingLeader()),
            this._mode === Ri.MULTIPLEXING &&
              this.role === Oi.UNKNOWN &&
              void 0 !== e &&
              (this._logger.info("Joined late, elected leader is", e),
              this._election.cancel(),
              this._onLeaderElected(e)))
          : this._mode === Ri.MULTIPLEXING &&
            this.role !== Oi.UNKNOWN &&
            this._handleLateJoiner(t);
    }
    _createHelloMessage() {
      var e;
      let t = super._createHelloMessage(
        0 < arguments.length && void 0 !== arguments[0] && arguments[0]
      );
      return (
        (t.instanceState.multiplexing = h(
          h({}, t.instanceState.multiplexing),
          {},
          {
            role: this.role,
            electionState:
              null === (e = this._election) || void 0 === e ? void 0 : e._state,
            leader: this._leader.getProperties(),
          }
        )),
        t
      );
    }
    _handleLateJoiner(e) {
      this._logger.info("Late joiner detected", e.properties);
      var t = bt(this._metrics, this.properties.id, { scope: "party" }).inc();
      !(function (e, t) {
        return e.timer(
          "instance.lateJoin.delay",
          h({}, 1 < arguments.length && void 0 !== t ? t : {})
        );
      })(this._metrics, {
        election: this._election._state,
        isFirst: 1 === t,
      }).record(performance.now() - this._election._closeTime),
        !e.isMultiplexingPartyAllowed() ||
          this.role !== Oi.LEADER ||
          (!0 ===
            (null ==
            (e = this._leader.addFollower(
              new ni(e, this._messenger, this._logger)
            ))
              ? void 0
              : e.lateJoiner) &&
            bt(this._metrics, this.properties.id, {
              scope: "leader",
              unique: !0 === (null == e ? void 0 : e.uniqueLateJoiner),
            }).inc());
    }
    _doFireEvent(e) {
      for (
        var t = arguments.length, i = new Array(1 < t ? t - 1 : 0), r = 1;
        r < t;
        r++
      )
        i[r - 1] = arguments[r];
      this._dispatcher.emit(e, ...i);
    }
    _actAsLeader() {
      var e = this.properties;
      const t = this._logger;
      var i = this._metrics,
        r = new Ht(this._storage),
        s = new jt(r),
        n = new Lt(e.storageExpirationDays);
      const o = new ai(s, n, e.forceAllowLocalStorageGrant, t, i);
      (s = new kt(
        new ci(() => o.localStorageGrant("client-store"), s, n, t),
        this._trueLinkAdapter
      )),
        (n = new Xe(
          null === (n = e.fetchIdData) || void 0 === n ? void 0 : n.apiBaseUrl
        )),
        (n = new zt(i, t, Pi.createExtensions(i, t, s, n)));
      const a = new ti(this._window, e, r, s, o, i, t, n);
      a.addFollower(this._followerRole),
        this._leader.assignLeader(a),
        this._remoteCallsToLeaderHandler.assignLeader(a),
        this._mode === Ri.MULTIPLEXING &&
          Array.from(this._knownInstances.values())
            .filter((e) => e.isMultiplexingPartyAllowed())
            .map((e) =>
              a.addFollower(
                new ni(
                  e,
                  this._messenger,
                  t,
                  e.isPassive() ? Yt.PASSIVE : Yt.STANDARD
                )
              )
            ),
        a.start();
    }
    _followRemoteLeader(e) {
      this._leader.assignLeader(new ii(this._messenger, e)),
        this._remoteCallsToLeaderHandler.assignLeader(
          new Gi(e.id, this._logger, this._metrics)
        ),
        this._logger.info("Following remote leader ", e);
    }
    updateConsent(e) {
      this._leader.updateConsent(e, this.properties.id);
    }
    updateFetchIdData(e) {
      this._leader.updateFetchIdData(this.properties.id, e),
        u(this.properties.fetchIdData, e);
    }
    refreshUid(e) {
      this._leader.refreshUid(e, this.properties.id);
    }
    _doElection() {
      var e = this._election;
      const t = this._knownInstances;
      let i = Array.from(t.values())
        .filter((e) => e.isMultiplexingPartyAllowed() && e.isLeaderCapable())
        .map((e) => e.properties);
      i.push(this.properties),
        this._onLeaderElected(
          (function (e) {
            if (!e || 0 === e.length) return;
            e = e.sort((e, t) => {
              let i = -(0 | _(e.version, t.version));
              var r, s, n;
              return (
                0 === i &&
                  ((i = e.source.localeCompare(t.source)),
                  0 === i && (i = -(0 | _(e.sourceVersion, t.sourceVersion))),
                  0 === i &&
                    ((s =
                      (null === (s = e.fetchIdData) ||
                      void 0 === s ||
                      null === (r = s.refererInfo) ||
                      void 0 === r
                        ? void 0
                        : r.numIframes) || Number.MAX_SAFE_INTEGER),
                    (n =
                      (null === (r = t.fetchIdData) ||
                      void 0 === r ||
                      null === (n = r.refererInfo) ||
                      void 0 === n
                        ? void 0
                        : n.numIframes) || Number.MAX_SAFE_INTEGER),
                    (i = s - n)),
                  0 === i && (i = e.id.localeCompare(t.id))),
                i
              );
            });
            return e[0];
          })(i)
        );
      var r = this._lastJoinedInstance;
      r &&
        !(function (e, t) {
          return e.timer(
            "instance.lastJoin.delay",
            h({}, 1 < arguments.length && void 0 !== t ? t : {})
          );
        })(this._metrics).record(Math.max(r._joinTime - e._scheduleTime, 0));
    }
    _onLeaderElected(e) {
      var t = this;
      (t.role = e.id === t.properties.id ? Oi.LEADER : Oi.FOLLOWER),
        t.role === Oi.LEADER
          ? t._actAsLeader()
          : t.role === Oi.FOLLOWER && t._followRemoteLeader(e),
        t._logger.debug("Leader elected", e.id, "my role", t.role),
        t._doFireEvent(
          je.ID5_LEADER_ELECTED,
          t.role,
          t._leader.getProperties()
        );
    }
    lookupForCachedId() {
      return (
        this._logger.info("Self lookup for cachedId triggered"),
        this._cachedIdProvider.provisionFromCache(this._followerRole)
      );
    }
  }
  class Gi extends ei {
    constructor(e, t, i) {
      super(),
        l(this, "_metrics", void 0),
        l(this, "_log", void 0),
        l(this, "_actualLeaderId", void 0),
        (this._log = t),
        (this._metrics = i),
        (this._actualLeaderId = e);
    }
    _handleMethod(e, t) {
      try {
        this._log.warn(
          "Received unexpected call method",
          e,
          " call to leader from instance",
          t
        ),
          (function (e, t) {
            e.counter(
              "instance.message.unexpected.count",
              1 < arguments.length && void 0 !== t ? t : {}
            );
          })(this._metrics, {
            target: "remoteLeader",
            methodName: e,
            callFromLeader: this._actualLeaderId === t,
          });
      } catch (e) {}
    }
    updateConsent(e, t) {
      this._handleMethod("updateConsent", t);
    }
    refreshUid(e, t) {
      this._handleMethod("refreshUid", t);
    }
    updateFetchIdData(e) {
      this._handleMethod("updateFetchIdData", e);
    }
  }
  const Wi = new (class {
    createInstance(e, t, i, r, s, n) {
      return new Vi(e, {}, r, i, t, s, n);
    }
  })();
  class Hi extends at {
    getGpId() {
      return !1 === this._isExposed ? void 0 : this._gpId;
    }
    getPublisherTrueLinkId() {
      return !1 === this._isExposed ? void 0 : this._publisherTrueLinkId;
    }
    getLinkType() {
      return !1 === this._isExposed ? 0 : this.getExt().linkType;
    }
    getExt() {
      var e = !1 === this._isExposed ? {} : this._ext;
      return u({ abTestingControlGroup: !this.exposeUserId() }, e);
    }
    getUserIdAsEid() {
      var e, t;
      return null !==
        (t =
          null === (e = this._ids) ||
          void 0 === e ||
          null === (t = e.id5id) ||
          void 0 === t
            ? void 0
            : t.eid) && void 0 !== t
        ? t
        : {
            source: xt.ID5_EIDS_SOURCE,
            uids: [{ atype: 1, id: this.getUserId(), ext: this.getExt() }],
          };
    }
    getUserIdsAsEids() {
      return void 0 === this._ids
        ? [this.getUserIdAsEid()]
        : Object.values(this._ids).map((e) => e.eid);
    }
    onRefresh(e, t) {
      if (!H(e)) throw new Error("onRefresh expects a function");
      this._refreshCallback && this._refreshCallback.disableWatchdog();
      var i =
        !0 === this._isRefreshing &&
        !1 === this._isRefreshingWithFetch &&
        this._userIdAvailable;
      return (
        (this._refreshCallback = new Ke(
          "onRefresh",
          this._log,
          this._metrics,
          e,
          t,
          i,
          () => {
            (this._isRefreshing = !1), (this._isRefreshingWithFetch = !1);
          },
          this
        )),
        this
      );
    }
    collectEvent(t, i) {
      const r = this._endpoints.event,
        s = (e) => {
          e = new Request(r, {
            method: "POST",
            mode: "no-cors",
            referrerPolicy: "origin",
            body: JSON.stringify({
              partnerId: this.config.getOptions().partnerId,
              id5id: e,
              eventType: t,
              metadata: i,
            }),
          });
          return (
            this._log.info("Sending event", e),
            fetch(e).catch((e) =>
              this._log.error(
                "Error while sending event to ID5 of type " + t,
                e
              )
            )
          );
        };
      return this._userIdAvailable
        ? s(this._userId)
        : this._userIdAvailablePromise.then((e) => s(e));
    }
    constructor(e, t, i, r, s, n, o, a, c) {
      super(e, r, n, o, a, "api", {
        canDoCascade:
          !e.hasCreativeRestrictions() && !0 !== e.getOptions().idLookupMode,
      }),
        l(this, "clientStore", void 0),
        l(this, "consentManagement", void 0),
        l(this, "_consentDataProvider", void 0),
        l(this, "_trueLinkAdapter", void 0),
        (this.clientStore = t),
        (this.consentManagement = i),
        (this._consentDataProvider = s),
        (this._trueLinkAdapter = c),
        (this._endpoints = ze);
    }
    bootstrap() {
      super.bootstrap();
      const i = this._ref();
      this._multiplexingInstance.on(Ne.CASCADE_NEEDED, (e) => {
        const t = i.deref();
        t && t._doCascade(e);
      });
    }
    init() {
      const e = super.init(),
        t = this._submitRefreshConsent().then((e) => {
          e && this.consentManagement.setConsentData(e);
        });
      return (
        e.then(() => {
          this._multiplexingInstance.lookupForCachedId().provisioned ||
            (this._log.info(
              "Couldn't find cached userId. Will try again when consent is resolved"
            ),
            t.then(() => {
              this._log.info("Consent resolved. Looking for cached id again"),
                this._multiplexingInstance.lookupForCachedId();
            }));
        }),
        Promise.allSettled([e, t])
      );
    }
    refreshId(t, e) {
      let i, r;
      this._log.info(
        "ID refresh requested (force=".concat(t, ") with additional options "),
        e
      );
      try {
        (this._isRefreshing = !0),
          (this._isRefreshingWithFetch = t),
          this.config.updOptions(e);
        var s = this.config.getOptions();
        const n = s.allowLocalStorageWithoutConsentApi || s.debugBypassConsent;
        (i = this._gatherFetchIdData().then((e) => {
          this._multiplexingInstance.updateFetchIdData(e),
            this._multiplexingInstance.refreshUid({
              resetConsent: !0,
              forceAllowLocalStorageGrant: n,
              forceFetch: t,
            }),
            (r = this._submitRefreshConsent());
        })),
          (function (e, t, i) {
            return e.counter(
              "refresh.call.count",
              h({ target: t }, 2 < arguments.length && void 0 !== i ? i : {})
            );
          })(this._metrics, "public-api").inc();
      } catch (e) {
        return (
          this._log.error("Exception caught from refreshId()", e),
          Promise.reject(e)
        );
      }
      return Promise.allSettled([i, r]);
    }
    _doCascade(e) {
      var t,
        i = this.config.getOptions();
      if (
        e.partnerId === i.partnerId &&
        0 <= i.maxCascades &&
        !this.config.hasCreativeRestrictions()
      ) {
        var r = i.partnerUserId && 0 < i.partnerUserId.length,
          s = this._endpoints.cascade(
            r ? "s" : "i",
            i.partnerId,
            i.maxCascades
          );
        const n = s.searchParams;
        n.set("o", "api"),
          n.set("id5id", e.userId),
          n.set("gdpr_consent", e.consentString),
          n.set("gdpr", e.gdprApplies),
          e.gppString &&
            (n.set("gpp", e.gppString), n.set("gpp_sid", e.gppSid)),
          r && n.set("puid", i.partnerUserId),
          this._log.info("Opportunities to cascade available", s.href),
          (t = s.href),
          "loading" !== document.readyState
            ? K(t)
            : document.addEventListener("DOMContentLoaded", function () {
                K(t);
              });
      }
    }
    _gatherFetchIdData() {
      var n = () => super._gatherFetchIdData,
        o = this;
      return i(function* () {
        var e,
          t = o.config.getOptions(),
          i = yield It.gatherUaHints(t.disableUaHints, o._log),
          r = yield n().call(o);
        let s = t.pd;
        return (
          !t.partnerData ||
            (void 0 !==
              (e = yield (function () {
                return ut.apply(this, arguments);
              })(t.partnerData, o._log)) &&
              (s = e)),
          h(
            h({}, r),
            {},
            {
              uaHints: i,
              pd: s,
              partnerUserId: t.partnerUserId,
              allowedVendors:
                null === (i = t.consentData) || void 0 === i
                  ? void 0
                  : i.allowedVendors,
              consentSource:
                "iab" === t.cmpApi && !0 !== t.debugBypassConsent
                  ? se.cmp
                  : se.partner,
              trueLink: o._trueLinkAdapter.getTrueLink(),
              att: t.att,
            }
          )
        );
      })();
    }
    _submitRefreshConsent() {
      var n = this;
      return i(function* () {
        var e = n.config.getOptions();
        let t = Ce();
        var i = e.debugBypassConsent ? "bypass" : e.cmpApi;
        let r;
        try {
          r = yield n._consentDataProvider.refreshConsentData(
            e.debugBypassConsent,
            e.cmpApi,
            e.consentData
          );
          const s = {};
          r.apiTypes.forEach((e) => (s[e] = !0)),
            t.record(Te(n._metrics, i, h({ success: !0 }, s))),
            n._multiplexingInstance.updateConsent(r);
        } catch (e) {
          n._log.error("Couldn't get consent data", e),
            t.record(Te(n._metrics, i, { success: !1, error: e.message }));
        }
        return r;
      })();
    }
    localStorageGrant() {
      return this.clientStore.localStorageGrant();
    }
    getSignature() {
      return this._signature;
    }
  }
  class Bi {
    isBooted() {
      return E(window.id5Bootstrap);
    }
    getTrueLink() {
      return this.isBooted()
        ? window.id5Bootstrap.getTrueLinkInfo()
        : { booted: !1 };
    }
    setPrivacy(e) {
      this.isBooted() &&
        window.id5Bootstrap.setPrivacy &&
        window.id5Bootstrap.setPrivacy(e);
    }
    clearPrivacy() {
      this.setPrivacy(void 0);
    }
  }
  const qi =
    ((hi = window),
    function () {
      try {
        var t = zi(),
          i = t.length - 1,
          r = null !== t[i].location || (0 < i && null !== t[i - 1].referrer),
          s = (function (e) {
            let t = [];
            var i,
              r = null;
            let s = null,
              n = null,
              o = null,
              a = null,
              c;
            for (c = e.length - 1; 0 <= c; c--) {
              try {
                s = e[c].location;
              } catch (e) {}
              if (s) t.push(s), (a = a || s);
              else if (0 !== c) {
                i = e[c - 1];
                try {
                  (n = i.referrer), (o = i.ancestor);
                } catch (e) {}
                n
                  ? (t.push(n), (a = a || n))
                  : o
                  ? (t.push(o), (a = a || o))
                  : t.push(r);
              } else t.push(r);
            }
            return { stack: t, detectedRefererUrl: a };
          })(t);
        let e;
        try {
          e = T(hi.top.document.referrer);
        } catch (e) {}
        return {
          topmostLocation: s.detectedRefererUrl,
          ref: e || null,
          reachedTop: r,
          numIframes: i,
          stack: s.stack,
        };
      } catch (e) {}
    });
  function zi() {
    let i = (function () {
      let t = [],
        i;
      do {
        try {
          i = i ? i.parent : hi;
          try {
            t.push({
              referrer: T(i.document.referrer),
              location: T(i.location.href),
              isTop: i === hi.top,
            });
          } catch (e) {
            t.push({ referrer: null, location: null, isTop: i === hi.top });
          }
        } catch (e) {
          return t.push({ referrer: null, location: null, isTop: !1 }), t;
        }
      } while (i !== hi.top);
      return t;
    })();
    var r = (function () {
      try {
        return hi.location.ancestorOrigins
          ? hi.location.ancestorOrigins
          : void 0;
      } catch (e) {}
    })();
    if (r) for (let e = 0, t = r.length; e < t; e++) i[e].ancestor = T(r[e]);
    return i;
  }
  class Ji {
    get version() {
      return this._version;
    }
    set debug(e) {
      (e = e), (N = !!e);
    }
    get debug() {
      return M();
    }
    static assignApiStandard(e, r) {
      (e.init = function (e) {
        return r.init(e);
      }),
        (e.refreshId = function (e, t, i) {
          return r.refreshId(e, t, i);
        }),
        (e.ApiStandardLoaded = !0);
    }
    static assignApiLite(e, t) {
      (e.initLite = function (e) {
        return t.init(e);
      }),
        (e.ApiLiteLoaded = !0);
    }
    constructor() {
      l(this, "loaded", !1),
        l(this, "_isUsingCdn", !1),
        l(this, "_scriptSrc", void 0),
        l(this, "_scriptFallback", void 0),
        l(this, "_referer", !1),
        l(this, "_version", Ze),
        l(this, "versions", {}),
        l(this, "invocationId", 0),
        l(this, "ApiStandardLoaded", !1),
        l(this, "init", void 0),
        l(this, "refreshId", void 0),
        l(this, "ApiLiteLoaded", !1),
        l(this, "initLite", void 0),
        (this.loaded = !0);
      var e =
        null === (e = document) || void 0 === e ? void 0 : e.currentScript;
      (this._scriptSrc = (null == e ? void 0 : e.src) || void 0),
        (this._scriptFallback = (null == e ? void 0 : e.fallback) || void 0),
        (this._isUsingCdn = !(
          !this._scriptSrc ||
          0 !== this._scriptSrc.indexOf("https://cdn.id5-sync.com")
        )),
        (this._referer = qi()),
        (this.versions[Ze] = !0);
    }
  }
  const Xi = "_id5Placeholder";
  function Yi(e) {
    var t = Ki(e),
      e = e.pbjs;
    return !e || (t && e[Xi]) ? t : e;
  }
  function Ki(t) {
    if (q(t._pbjsGlobals)) {
      var e = t._pbjsGlobals.find((e) => "pbjs" !== e && t[e]);
      return e ? t[e] : void 0;
    }
  }
  class Zi {
    constructor() {
      var e =
          0 < arguments.length && void 0 !== arguments[0]
            ? arguments[0]
            : window,
        t = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : v;
      (this._window = e),
        (this._pbjsPromise = null),
        (this._pbjs = null),
        (this._logger = t);
    }
    getPbjs() {
      var t = this;
      return i(function* () {
        return (
          t._pbjs ||
          t._pbjsPromise ||
          ((t._pbjsPromise = new Promise((e) => {
            !(function (t, i) {
              try {
                const s = t._window;
                let e = !1;
                const n = () => {
                    e || ((e = !0), (t._pbjs = Yi(s)), i(t._pbjs));
                  },
                  o = (e, t) => {
                    (e.que = e.que || []), e.que.push(t);
                  };
                var r = Yi(s);
                if (r) return o(r, n);
                const a = (s.pbjs = { [Xi]: !0 });
                o(a, () => {
                  delete a[Xi], n();
                }),
                  (function (i, r) {
                    const s = (i._pbjsGlobals = q(i._pbjsGlobals)
                        ? i._pbjsGlobals
                        : []),
                      n = s.push.bind(s);
                    s.push = function () {
                      var e = n(...arguments),
                        t = Ki(i);
                      return t && ((s.push = n), r(t)), e;
                    };
                  })(s, (e) => o(e, n));
              } catch (e) {
                t._logger.error("PbjsDetector: Failed to setup detection:", e),
                  i(null);
              }
            })(t, e);
          })),
          t._pbjsPromise)
        );
      })();
    }
  }
  var $i = Object.freeze({
    AUCTION_END: "auctionEnd",
    BID_WON: "bidWon",
    TCF2_ENFORCEMENT: "tcf2Enforcement",
    AD_RENDER_FAILED: "adRenderFailed",
    AD_RENDER_SUCCEEDED: "adRenderSucceeded",
  });
  const Qi = [
      $i.AUCTION_END,
      $i.BID_WON,
      $i.AD_RENDER_FAILED,
      $i.AD_RENDER_SUCCEEDED,
    ],
    er = new Date().getTimezoneOffset(),
    tr = Array.isArray,
    ir = "id5-api-js",
    rr = {};
  (rr[$i.AUCTION_END] = function (e) {
    const t = {
      auctionId: e.auctionId,
      timestamp: e.timestamp,
      auctionEnd: e.auctionEnd,
    };
    tr(e.bidsReceived) && (t.bidsReceived = e.bidsReceived.map(dr));
    tr(e.noBids) && (t.noBids = e.noBids.map(ar));
    tr(e.bidderRequests) && (t.bidderRequests = e.bidderRequests.map(nr));
    return t;
  }),
    (rr[$i.BID_WON] = lr),
    (rr[$i.AD_RENDER_FAILED] = function (e) {
      return { adId: e.adId, reason: e.reason };
    }),
    (rr[$i.AD_RENDER_SUCCEEDED] = function (e) {
      return { adId: e.adId, bid: lr(e.bid) };
    }),
    (rr.analyticsError = (e) => e);
  class sr {
    constructor(e, t, i, r) {
      var s =
        4 < arguments.length && void 0 !== arguments[4] ? arguments[4] : v;
      (this._partnerId = e),
        (this._sampling = t),
        (this._ingestUrl = i),
        (this._pbjsVersion = r),
        (this._logger = s);
    }
    track(e, t) {
      if (!t) return Promise.resolve();
      try {
        return (
          this._logger.debug("pbjsEventsTracker: Tracking event", e, t),
          this.sendEvent(this.makeEvent(e, t))
        );
      } catch (e) {
        return (
          this._logger.error("pbjsEventsTracker: ERROR", e),
          this.sendErrorEvent(e)
        );
      }
    }
    sendEvent(e) {
      var s = this;
      return i(function* () {
        var t = JSON.stringify(e),
          i = 1024 < t.length && "CompressionStream" in window;
        try {
          const r = { "Content-Type": "application/json" };
          let e = t;
          return (
            i &&
              ((e = yield new Response(
                new Response(t).body.pipeThrough(new CompressionStream("gzip"))
              ).blob()),
              (r["Content-Encoding"] = "gzip")),
            fetch(s._ingestUrl, {
              method: "POST",
              referrerPolicy: "origin",
              headers: r,
              body: e,
            }).catch((e) => {
              s._logger.error("pbjsEventsTracker: sendEvent failed", e);
            })
          );
        } catch (e) {
          s._logger.error("pbjsEventsTracker: sendEvent failed (sync)", e);
        }
        return Promise.resolve();
      })();
    }
    makeEvent(e, t) {
      t = rr[e] ? rr[e](t) : {};
      return {
        source: ir,
        event: e,
        payload: t,
        partnerId: this._partnerId,
        meta: {
          sampling: this._sampling,
          pbjs: this._pbjsVersion,
          version: Ze,
          tz: er,
        },
      };
    }
    sendErrorEvent(e) {
      return this.sendEvent(
        this.makeEvent("analyticsError", { message: e.message, stack: e.stack })
      );
    }
  }
  function nr(e) {
    if (e) {
      const t = {};
      return (
        e.bidderCode && (t.bidderCode = e.bidderCode),
        tr(e.bids) && (t.bids = e.bids.map(cr)),
        e.ortb2 && (t.ortb2 = hr(e.ortb2)),
        t
      );
    }
  }
  function or(e) {
    if (e) {
      const t = {};
      return (
        e.ext &&
          (t.ext = (function (e) {
            if (e)
              return {
                linkType: e.linkType,
                pba: e.pba,
                abTestingControlGroup: e.abTestingControlGroup,
              };
          })(e.ext)),
        t
      );
    }
  }
  function ar(e) {
    if (e) {
      const t = {};
      return (t.bidId = e.bidId), t;
    }
  }
  function cr(e) {
    if (e) {
      const t = {};
      return (
        e.adUnitCode && (t.adUnitCode = e.adUnitCode),
        e.bidId && (t.bidId = e.bidId),
        e.userId &&
          (t.userId = (function (t) {
            if (t) {
              const i = {};
              return (
                Object.keys(t).forEach((e) => {
                  "id5id" === e ? (i.id5id = or(t[e])) : (i[e] = 1);
                }),
                i
              );
            }
          })(e.userId)),
        e.ortb2 && (t.ortb2 = hr(e.ortb2)),
        tr(e.userIdAsEids) && (t.userIdAsEids = e.userIdAsEids.map(ur)),
        t
      );
    }
  }
  function dr(i) {
    if (i) {
      const r = {};
      return (
        [
          "adUnitCode",
          "bidderCode",
          "requestId",
          "creativeId",
          "dealId",
          "responseTimestamp",
          "requestTimestamp",
          "width",
          "height",
          "netRevenue",
          "mediaType",
          "originalCpm",
          "originalCurrency",
          "cpm",
          "currency",
        ].forEach((e) => {
          var t = i[e];
          t && (r[e] = t);
        }),
        r
      );
    }
  }
  function lr(i) {
    if (i) {
      const r = {};
      return (
        [
          "auctionId",
          "adUnitCode",
          "bidderCode",
          "requestId",
          "creativeId",
          "dealId",
          "responseTimestamp",
          "requestTimestamp",
          "width",
          "height",
          "netRevenue",
          "mediaType",
          "originalCpm",
          "originalCurrency",
          "cpm",
          "currency",
        ].forEach((e) => {
          var t = i[e];
          t && (r[e] = t);
        }),
        r
      );
    }
  }
  function hr(e) {
    if (e) {
      const t = {};
      return (
        e.user &&
          (t.user = (function (e) {
            if (e) {
              const t = {};
              return (
                e.ext &&
                  (t.ext = (function (e) {
                    if (e) {
                      const t = {};
                      return tr(e.eids) && (t.eids = e.eids.map(ur)), t;
                    }
                    return;
                  })(e.ext)),
                t
              );
            }
            return;
          })(e.user)),
        t
      );
    }
  }
  function ur(e) {
    if (e) {
      const t = {};
      return (
        e.source && (t.source = e.source),
        tr(e.uids) && "id5-sync.com" === e.source && (t.uids = e.uids.map(or)),
        t
      );
    }
  }
  function gr(t, e, i) {
    let r = 1 < arguments.length && void 0 !== e ? e : v,
      s = 2 < arguments.length && void 0 !== i ? i : ze;
    try {
      (window.id5_pbjs_et = window.id5_pbjs_et || {}),
        !0 !== window.id5_pbjs_et[t] &&
          ((window.id5_pbjs_et[t] = !0),
          new Zi(window, r).getPbjs().then((e) => {
            !(function (o, a) {
              let c =
                  2 < arguments.length && void 0 !== arguments[2]
                    ? arguments[2]
                    : v,
                e =
                  3 < arguments.length && void 0 !== arguments[3]
                    ? arguments[3]
                    : ze;
              o
                ? tr(o.installedModules) &&
                  0 <= o.installedModules.indexOf("id5AnalyticsAdapter")
                  ? (c.info(
                      "pbjsEventsTracker: id5AnalyticsAdapter module is already installed. Skipping."
                    ),
                    Promise.resolve(!1))
                  : "number" != typeof a
                  ? (c.error(
                      "pbjsEventsTracker: partnerId in must be a number representing the id5 partner ID"
                    ),
                    Promise.resolve(!1))
                  : fetch(e.analytics(a, ir), { referrerPolicy: "origin" })
                      .then((e) => e.json())
                      .then((e) => {
                        c.info(
                          "pbjsEventsTracker: Received from configuration endpoint",
                          e
                        );
                        var t = "number" == typeof e.sampling ? e.sampling : 0;
                        if ("string" != typeof e.ingestUrl)
                          return (
                            c.error(
                              "pbjsEventsTracker: cannot find ingestUrl in config endpoint response; no analytics will be available"
                            ),
                            !1
                          );
                        var i = e.ingestUrl;
                        const r = tr(e.eventsToTrack) ? e.eventsToTrack : Qi;
                        if (0 < t && Math.random() < 1 / t) {
                          c.info(
                            "pbjsEventsTracker: Selected by sampling. Starting up!"
                          );
                          const s = new sr(a, t, i, o.version, c),
                            n = [];
                          return (
                            H(o.getEvents) &&
                              tr(o.getEvents()) &&
                              o.getEvents().forEach((e) => {
                                c.debug(
                                  "pbjsEventsTracker: Past event found",
                                  e
                                ),
                                  e && 0 <= r.indexOf(e.eventType)
                                    ? n.push(s.track(e.eventType, e.args))
                                    : c.debug(
                                        "pbjsEventsTracker: Past event ignored",
                                        e
                                      );
                              }),
                            c.info(
                              "pbjsEventsTracker: Register event handlers for",
                              r
                            ),
                            r.forEach((t) => {
                              o.onEvent(t, (e) => s.track(t, e));
                            }),
                            Promise.all(n).then(() => !0)
                          );
                        }
                        return !1;
                      })
                      .catch(
                        (e) => (
                          c.error(
                            "pbjsEventsTracker: Failed to fetch configuration",
                            e
                          ),
                          !1
                        )
                      )
                : (c.error("pbjsEventsTracker: prebidGlobal is not defined"),
                  Promise.resolve(!1));
            })(e, t, r, s);
          }));
    } catch (e) {
      r.error("pbjsEventsTracker: Failed to register", e);
    }
  }
  class pr {
    constructor(e) {
      l(this, "_id5Api", void 0),
        (this._id5Api = e),
        Ji.assignApiStandard(e, this);
    }
    init(e) {
      const t = this._id5Api;
      t.invocationId += 1;
      const i = new V("api", t.invocationId);
      try {
        i.info("ID5 API version ".concat(t._version, ". Invoking init()"), e);
        const u = new et(e, i);
        var r = u.getOptions();
        const g = this._configureDiagnostics(r, i);
        g &&
          (!(function (e, t) {
            return e.timer(
              "instance.load.delay",
              1 < arguments.length && void 0 !== t ? t : {}
            );
          })(g).recordNow(),
          (function (e, t) {
            return e.summary(
              "invocation.count",
              1 < arguments.length && void 0 !== t ? t : {}
            );
          })(g).record(t.invocationId, {
            fenced:
              "function" == typeof window.Fence &&
              window.fence instanceof window.Fence,
          }));
        var s = new Wt(window, !u.hasCreativeRestrictions()),
          n = new jt(s, i),
          o = u.isForceAllowLocalStorageGrant(),
          a = new Lt(r.storageExpirationDays);
        const p = new ai(n, a, o, i, g);
        const v = new ci(
          () => p.localStorageGrant("instance-client-store"),
          n,
          a,
          i
        );
        var c = new Bi(),
          d = Wi.createInstance(window, i, g, s, c, v),
          l = new Ue(g, i),
          h = new rt(
            t._referer,
            t._version,
            t._isUsingCdn,
            t._scriptSrc,
            t._scriptFallback
          );
        const _ = new Hi(u, v, p, g, l, i, d, h, c);
        return (
          _.bootstrap(),
          _.init(),
          v.scheduleGC(g),
          setTimeout(() => {
            var r, e;
            gr(u.getOptions().partnerId, i),
              (r = g),
              (e = i),
              new Zi(window, e).getPbjs().then((e) => {
                if (r && e) {
                  const i = Array.isArray(e.installedModules)
                    ? e.installedModules
                    : [];
                  var t = i.includes("id5IdSystem"),
                    e = i.includes("id5AnalyticsAdapter");
                  !(function (e, t) {
                    return e.counter(
                      "pbjs.detected",
                      1 < arguments.length && void 0 !== t ? t : {}
                    );
                  })(r, { hasId5IdModule: t, hasId5AnalyticsModule: e }).inc();
                }
              });
          }, 0),
          _
        );
      } catch (e) {
        i.error("Exception caught during init()", e);
      }
    }
    refreshId(e) {
      var t = 1 < arguments.length && void 0 !== arguments[1] && arguments[1],
        i = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : {};
      if (!X(t))
        throw new Error(
          "Invalid usage of refreshId(): second parameter must be a boolean"
        );
      return e.refreshId(t, i), e;
    }
    _configureDiagnostics(e, t) {
      try {
        var i = this._id5Api,
          r = e.partnerId;
        const c = new Ee("api", Ze);
        c.addCommonTags(
          h(
            h({}, De(r)),
            {},
            {
              tml: i._referer.topmostLocation,
              provider: e.provider || "default",
              idLookupMode: !0 === e.idLookupMode ? "true" : "false",
            }
          )
        );
        var s = e.diagnostics;
        if (null == s || !s.publishingDisabled) {
          var n = ze.diagnostics;
          const d = new ge(
            c,
            ((o = s.publishingSampleRatio),
            (a = n),
            Math.random() < o && he
              ? (e, t) => new ue(a, { sampling: o }).publish(e, t)
              : (e) => e)
          );
          null != s &&
            s.publishAfterLoadInMsec &&
            0 < s.publishAfterLoadInMsec &&
            d.schedulePublishAfterMsec(s.publishAfterLoadInMsec),
            null != s &&
              s.publishBeforeWindowUnload &&
              d.schedulePublishBeforeUnload();
        }
        return c;
      } catch (e) {
        return void t.error("Failed to configure diagnostics", e);
      }
      var o, a;
    }
  }
  new pr(new Ji()),
    window.ID5 || (window.ID5 = new Ji()),
    window.ID5.ApiStandardLoaded || new pr(window.ID5);
})();
