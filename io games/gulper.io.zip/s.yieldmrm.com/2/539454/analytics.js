(function () {
  var ozoki_tc = "BJf7p0wQkBLaB5q1",
    ozoki_os = "s.yieldmrm.com",
    ozoki_url =
      "https://s.yieldmrm.com/2/539454/analytics.js?dt\u003D5394541619046260404000\u0026di\u003Dwww.crazygames.com\u0026ui\u003D4b950592dcfe4b1f209ebb8669ef5e16\u0026md\u003D1\u0026sr\u003Drisecodes.com\u0026pp\u003D62a8b3133e1cca000167166d\u0026ti\u003D1795524407684337827_rtb-seller-digital-bdc5f94d4-k9ngd_l1Vhj\u0026de\u003D2\u0026to\u003D3\u0026pv\u003D2c1f2f6e-40dc-446d-a71f-cde73ce4a2e7\u0026dm\u003D300x250\u0026gt\u003DIT\u0026ac\u003D\u0026cr\u003D2179%3A591753664567074056_magnite\u0026c1\u003Ds\u0026c2\u003Dmagnite\u0026ap\u003D\u0026ci\u003D539454",
    ozoki_ct = {
      pp: "62a8b3133e1cca000167166d",
      ti: "1795524407684337827_rtb-seller-digital-bdc5f94d4-k9ngd_l1Vhj",
      c1: "s",
      c2: "magnite",
      de: "2",
      to: "3",
      dm: "300x250",
      ci: "539454",
      dt: "5394541619046260404000",
      ui: "4b950592dcfe4b1f209ebb8669ef5e16",
      md: "1",
      gt: "IT",
      ac: "",
      pv: "2c1f2f6e-40dc-446d-a71f-cde73ce4a2e7",
      cr: "2179:591753664567074056_magnite",
      ap: "",
      di: "www.crazygames.com",
      sr: "risecodes.com",
    },
    ozoki_cf = 1,
    ozoki_sav = 1,
    ozoki_opt = {
      sm: 0.4634,
      tsm: 0.8234,
      chrext: 1,
      prb: 1,
      cpl: 1,
      bwk: 1,
      nvl: 1,
      ndm: 1,
      ecm: 1,
      wor: 1,
      hco: 1,
      dup: 1,
    };
  var PAGESPEED_VERSION = "2.229.0";
  !(function () {
    var o = function () {},
      n = "undefined" != typeof window ? window : null,
      i = null !== n ? n.document : null,
      t = encodeURIComponent,
      e = Date.now,
      f = JSON.stringify;
    function c(o) {
      !(function t() {
        i.body ? i.body.appendChild(o) : n.setTimeout(t, 4);
      })();
    }
    try {
      var u = Date.now();
      "undefined" == typeof ozoki_cf && (ozoki_cf = 0),
        "undefined" == typeof ozoki_sav && (ozoki_sav = 1),
        (function (n, u, r, s) {
          void 0 === r && (r = ""), void 0 === s && (s = !1);
          var a,
            _ = u.PAGESPEED_VERSION,
            k = u.ozoki_url,
            z = u.ozoki_os,
            d = u.ozoki_tc,
            p = u.ozoki_ct,
            v = u.ozoki_opt,
            l = u.ozoki_cf,
            m = u.ozoki_sav,
            E = u.ozoki_fsm,
            y = k.substr(0, k.indexOf(":")),
            S = y + "://" + z + "/2",
            x = S + "/" + p.ci + "/" + d,
            I = (function (o, n, i, t, e, f, c, u) {
              var r, s;
              if (t) s = t;
              else if (1 === e) {
                var a = void 0 === f ? 1 : f;
                (r = "fss0" + a), (s = o + "://cadmus2.script.ac/s/fs0" + a);
              } else s = n + "/" + i;
              return {
                mainSrc: s + "/main.js" + (u.oz_cb ? "?cb=" + c : ""),
                bucket: r,
              };
            })(y, S, _, r, l, m, d, p),
            N = I.mainSrc,
            g = I.bucket,
            P = (function () {
              var o = "oz_pl=1";
              for (var n in p)
                p.hasOwnProperty(n) && (o += "&" + t(n) + "=" + t(p[n]));
              return p.hasOwnProperty("psv") ? o : o + "&psv=" + _;
            })(),
            R =
              -1 !==
              (-1 !== (a = k.indexOf("?")) ? k.substring(0, a) : k).indexOf(
                "/vg.js"
              )
                ? "vg"
                : "postback",
            w = S + "/" + _ + "/" + p.ci + "/" + d + "/" + R + "?" + P;
          function O(n) {
            !(function (n) {
              try {
                var i = new XMLHttpRequest();
                i.open("POST", w + "&_x=1", !0),
                  (i.withCredentials = !1),
                  i.setRequestHeader("Content-Type", "text/plain"),
                  "function" == typeof i.overrideMimeType &&
                    i.overrideMimeType("text/plain"),
                  i.send(f(n));
              } catch (n) {
                o(n);
              }
            })({ loader: n });
          }
          if (
            ((o = function (o) {
              !(function (o) {
                if ("undefined" != typeof Image) {
                  var n = new Image();
                  (n.src = o),
                    (n.style.visibility = "hidden"),
                    (n.style.width = "1px"),
                    (n.style.height = "1px"),
                    document.body && document.body.appendChild(n);
                }
              })(
                x +
                  "/y.gif?en=" +
                  t(o.name) +
                  "&em=" +
                  t(o.message) +
                  "&es=" +
                  t(o.stack) +
                  "&ets=" +
                  t(e()) +
                  "&" +
                  P
              );
            }),
            null !== i && (i[d] ? v.dup : ((i[d] = !0), 0)))
          )
            O({ sm: v.sm, init: 0, dup: !0 });
          else {
            O({ sm: v.sm, init: 1, bkt: g });
            var h,
              D,
              b,
              A,
              V,
              C,
              G,
              j,
              T = e(),
              U = i.createElement("script"),
              q = {
                PAGESPEED_VERSION: _,
                API_VERSION: "2",
                is_vast: !(!p.vver || !p.vs),
                ozoki_st: n,
                ozoki_os: z,
                ozoki_url: k,
                ozoki_tc: d,
                ozoki_ct: p,
                ozoki_opt: v,
                ozoki_mn: N,
                ozoki_onf: U.onfocus,
              },
              H =
                ((D = (h = N).indexOf(".") + 1),
                (b = h.substring(D, D + 8)),
                isNaN(b) ? b : h.substring(0, 8)),
              J = (function (o) {
                var n = o.indexOf(".") + 1,
                  i = o.substring(n, n + 1);
                return isNaN(i) ? i : o.substring(0, 1);
              })(N),
              L = q.ozoki_onf,
              M = function (o) {
                return o ? L && L.call(this, o) : M;
              };
            (M.toString = function () {
              return L + "";
            }),
              (M[J] = function (o) {
                return o == H ? q : void 0;
              }),
              (U.onload = function () {
                return O({ load: e() - T });
              }),
              (U.onerror = function () {
                return O({ error: e() - T });
              }),
              (U.onfocus = M),
              (U.src = N),
              s &&
                ((U.integrity =
                  "sha256-jrTxeYl/1a7GFQFSPI+jPqzU5Jx7qWGTs8Aymf0Trto="),
                (U.crossOrigin = "anonymous")),
              c(U),
              1 !== l ||
                (0 !== E && 1 !== E) ||
                (function (o) {
                  if (o) {
                    var n = i.createElement("script");
                    (n.src = o), (n.async = !0), c(n);
                  }
                })(
                  ((A = k),
                  (V = String(p.ci)),
                  (C = 1 === E),
                  (G = d),
                  -1 ===
                  (j = (j = decodeURIComponent(A)).replace(
                    new RegExp(V, "g"),
                    "999" + V
                  )).indexOf("?")
                    ? null
                    : j + "&fsm=" + (C ? "1" : "0") + "&ptc=" + t(G))
                );
          }
        })(u, {
          PAGESPEED_VERSION: PAGESPEED_VERSION,
          ozoki_url: ozoki_url,
          ozoki_os: ozoki_os,
          ozoki_tc: ozoki_tc,
          ozoki_ct: ozoki_ct,
          ozoki_opt: ozoki_opt,
          ozoki_cf: ozoki_cf,
          ozoki_sav: ozoki_sav,
          ozoki_fsm: "undefined" != typeof ozoki_fsm ? ozoki_fsm : void 0,
        });
    } catch (n) {
      o(n);
    }
  })();
})();
