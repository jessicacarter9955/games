(() => {
  "use strict";
  var e = {
      477(e, t, i) {
        i.d(t, { Ay: () => o });
        var s = i(971);
        const n = "onetagActivity";
        class r {
          constructor(e) {
            this.target = e;
          }
          publish(e) {
            try {
              const t = void 0 === this.target ? window.top : this.target;
              if (null == t) return;
              void 0 === this.instance && (this.instance = s.A.generate());
              const i = Object.assign(Object.assign({}, e), {
                instance: this.instance,
                sequence: ++r.sequence,
                time: Date.now(),
              });
              t.postMessage(JSON.stringify({ [n]: i }), "*");
            } catch (e) {}
          }
        }
        r.sequence = 0;
        const o = r;
      },
      373(e, t, i) {
        function s(e) {
          switch (e) {
            case "cdn":
              return "cdn";
            case "self":
              return "self";
          }
        }
        i.d(t, { s: () => s });
      },
      8(e, t, i) {
        i.d(t, { A: () => a });
        var s = i(712),
          n = i(661),
          r = i(873),
          o = i(373);
        class a {
          constructor(e, t, i, a) {
            (this.nodeEnv =
              null != e
                ? (0, s.s)(e) || "production"
                : (0, s.s)("production") || "production"),
              (this.testType =
                null != t ? (!1 === t ? null : (0, n.s)(t) || null) : null),
              (this.telemetrySink = (null != i && (0, r.s)(i)) || "remote"),
              (this.artifactHost = (null != a && (0, o.s)(a)) || "cdn");
          }
          isProduction() {
            return "production" === this.nodeEnv;
          }
          isDevelopment() {
            return "development" === this.nodeEnv;
          }
          isE2ETest() {
            return "e2e" === this.testType;
          }
          isUnitTest() {
            return "unit" === this.testType;
          }
          isTest() {
            return this.isE2ETest() || this.isUnitTest();
          }
          hasConsoleTelemetry() {
            return "console" === this.telemetrySink;
          }
          sendsTelemetry() {
            return (
              this.isProduction() &&
              !this.isTest() &&
              !this.hasConsoleTelemetry()
            );
          }
          hasSelfHostedArtifacts() {
            return "self" === this.artifactHost;
          }
        }
      },
      712(e, t, i) {
        function s(e) {
          switch (e) {
            case "production":
              return "production";
            case "development":
              return "development";
          }
        }
        i.d(t, { s: () => s });
      },
      971(e, t, i) {
        i.d(t, { A: () => s });
        class s {
          static generate() {
            try {
              return crypto.randomUUID();
            } catch (e) {
              return String(Math.random());
            }
          }
        }
      },
      681(e, t, i) {
        function s(e) {
          switch (e) {
            case 0:
              return "FATAL";
            case 1:
              return "ERROR";
            case 2:
              return "WARN";
            case 3:
              return "INFO";
            case 4:
              return "DEBUG";
            case 5:
              return "TRACE";
            case 6:
              return "SILLY";
          }
        }
        i.d(t, { A: () => s });
      },
      873(e, t, i) {
        function s(e) {
          switch (e) {
            case "remote":
              return "remote";
            case "console":
              return "console";
          }
        }
        i.d(t, { s: () => s });
      },
      661(e, t, i) {
        function s(e) {
          switch (e) {
            case "e2e":
              return "e2e";
            case "unit":
              return "unit";
          }
        }
        i.d(t, { s: () => s });
      },
    },
    t = {};
  function i(s) {
    var n = t[s];
    if (void 0 !== n) return n.exports;
    var r = (t[s] = { exports: {} });
    return e[s](r, r.exports, i), r.exports;
  }
  (i.d = (e, t) => {
    for (var s in t)
      i.o(t, s) &&
        !i.o(e, s) &&
        Object.defineProperty(e, s, { enumerable: !0, get: t[s] });
  }),
    (i.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t));
  var s = i(8);
  const n = (function () {
    if ("undefined" == typeof document) return "";
    const e = document.currentScript;
    return (e && e.src) || "";
  })();
  function r(e = n) {
    const t = /^[a-z][a-z0-9+.-]*:\/\/[^/]+/i.exec(e);
    return null !== t ? t[0] : "";
  }
  var o = i(681),
    a = i(477),
    l = function (e, t) {
      var i = {};
      for (var s in e)
        Object.prototype.hasOwnProperty.call(e, s) &&
          t.indexOf(s) < 0 &&
          (i[s] = e[s]);
      if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
        var n = 0;
        for (s = Object.getOwnPropertySymbols(e); n < s.length; n++)
          t.indexOf(s[n]) < 0 &&
            Object.prototype.propertyIsEnumerable.call(e, s[n]) &&
            (i[s[n]] = e[s[n]]);
      }
      return i;
    };
  class c {
    static getCallerStack(e, t) {
      try {
        if (e > 2) return;
        const i = new Error();
        if (!this.hasStack(i)) return;
        const s = i.stack;
        try {
          if (this.hasCaptureStackTrace(Error))
            return (
              Error.captureStackTrace(i, t),
              this.hasFrames(i.stack, i) ? i.stack : s
            );
          const e = s.split("\n");
          return e.length > this.OWN_FRAMES
            ? e.slice(this.OWN_FRAMES).join("\n")
            : s;
        } catch (e) {
          return s;
        }
      } catch (e) {
        return;
      }
    }
    static getMessage(e) {
      switch (typeof e) {
        case "string":
          return e;
        case "undefined":
          return;
        case "object":
          if (null === e) return;
          if (this.hasMessage(e)) return e.message;
          try {
            return JSON.stringify(e);
          } catch (t) {
            try {
              return String(e);
            } catch (e) {
              return;
            }
          }
        default:
          return String(e);
      }
    }
    static hasMessage(e) {
      return (
        null !== e &&
        "object" == typeof e &&
        "message" in e &&
        "string" == typeof e.message
      );
    }
    static hasStack(e) {
      return (
        null !== e &&
        "object" == typeof e &&
        "stack" in e &&
        "string" == typeof e.stack
      );
    }
    static hasName(e) {
      return (
        null !== e &&
        "object" == typeof e &&
        "name" in e &&
        "string" == typeof e.name
      );
    }
    static hasCode(e) {
      return (
        null !== e &&
        "object" == typeof e &&
        "code" in e &&
        "string" == typeof e.code
      );
    }
    static hasAttachments(e) {
      return (
        null !== e &&
        "object" == typeof e &&
        "getAttachments" in e &&
        "function" == typeof e.getAttachments
      );
    }
    static hasCaptureStackTrace(e) {
      return null != e && "function" == typeof e.captureStackTrace;
    }
    static hasFrames(e, t) {
      return e.split("\n").some((e) => "" !== e && e !== String(t));
    }
    static draw(e, t = Math.random) {
      return e >= 1 || t() < e;
    }
    constructor(e, t, i = new a.Ay(), s = console, n = () => Math.random()) {
      (this.environment = e),
        (this.client = t),
        (this.channel = i),
        (this.sink = s),
        (this.random = n),
        (this.activationTimestamp = new Date().toISOString()),
        (this.attachments = []),
        (this.maxLogLevel =
          e.isProduction() && !e.hasConsoleTelemetry() ? 3 : 5);
    }
    attach(e) {
      return this.attachments.push(e), this;
    }
    integrate(e) {
      let t = !0;
      for (let i = 0; i < this.attachments.length; i++)
        this.attachments[i].type === e.type &&
          ((this.attachments[i] = Object.assign(
            Object.assign({}, this.attachments[i]),
            e
          )),
          (t = !1));
      return t && this.attach(e), this;
    }
    fork() {
      const e = new c(
        this.environment,
        this.client,
        this.channel,
        this.sink,
        this.random
      );
      return (
        (e.maxLogLevel = this.maxLogLevel),
        (e.attachments = [...this.attachments]),
        e
      );
    }
    log(e, t, i) {
      this.logFrom(this.log, e, t, i);
    }
    error(e, t) {
      this.logFrom(this.error, e, 1, t);
    }
    fatal(e, t) {
      this.logFrom(this.fatal, e, 0, t);
    }
    debug(e, t) {
      this.logFrom(this.debug, e, 4, t);
    }
    warn(e, t) {
      this.logFrom(this.warn, e, 2, t);
    }
    info(e, t) {
      this.logFrom(this.info, e, 3, t);
    }
    trace(e, t) {
      this.logFrom(this.trace, e, 5, t);
    }
    silly(e, t) {
      this.logFrom(this.silly, e, 6, t);
    }
    event(e, t) {
      this.publishActivity(() => ({ type: "event", id: e, name: t }));
    }
    logFrom(e, t, i, s) {
      try {
        i <= 2 &&
          this.publishActivity(() => ({
            type: "log",
            level: i,
            code: c.hasCode(t) ? t.code : void 0,
            name: c.hasName(t) ? t.name : void 0,
            message: c.getMessage(t) || void 0,
          }));
        const n = null == s || c.draw(s, this.random),
          r = n || i > 4 ? i : 4,
          o = n && null != s && s < 1 ? s : void 0,
          a = (!n && null != s) || void 0;
        if (r <= this.maxLogLevel)
          if (this.environment.sendsTelemetry())
            this.client.post(
              c.tslogURL,
              JSON.stringify(this.serialize(t, r, !1, o, a, e)),
              {}
            );
          else {
            const {
                message: i,
                name: s,
                code: n,
                levelName: l,
                stack: c,
                entries: h,
                timestamp: d,
              } = this.serialize(t, r, !0, o, a, e),
              u = `%c[${d}] %c${l} ${
                n ? `[${n}]` : s ? `(${s})` : ""
              } %c${i}\n${c || ""}`,
              p = ["color: #707070ff"];
            switch (r) {
              case 0:
                p.push("color: #a11eddff");
                break;
              case 1:
                p.push("color: #FF0000");
                break;
              case 2:
                p.push("color: #FF7F00");
                break;
              case 3:
                p.push("color: #FFD700");
                break;
              case 4:
                p.push("color: #1E90FF");
                break;
              case 5:
                p.push("color: #32CD32");
                break;
              case 6:
                p.push("color: #87CEFA");
            }
            switch ((p.push("color: #1B6EA3"), r)) {
              case 0:
              case 1:
                this.sink.error(u, ...p, h);
                break;
              case 2:
                this.sink.warn(u, ...p, h);
                break;
              default:
                this.sink.log(u, ...p, h);
            }
          }
      } catch (t) {}
    }
    publishActivity(e) {
      try {
        if (this.environment.sendsTelemetry()) return;
        const t = e(),
          i = this.lastAttachment("context"),
          s = this.lastAttachment("renderer");
        this.channel.publish(
          Object.assign(Object.assign({}, t), {
            artifact:
              "string" == typeof (null == i ? void 0 : i.artifactName)
                ? i.artifactName
                : void 0,
            version:
              "string" == typeof (null == s ? void 0 : s.version)
                ? s.version
                : void 0,
          })
        );
      } catch (e) {}
    }
    lastAttachment(e) {
      for (let t = this.attachments.length - 1; t >= 0; t--)
        if (this.attachments[t].type === e) return this.attachments[t];
    }
    serialize(e, t, i, s, n, r) {
      const a = c.getMessage(e),
        h = c.hasStack(e) ? e.stack : c.getCallerStack(t, r),
        d = c.hasName(e) ? e.name : void 0,
        u = c.hasCode(e) ? e.code : void 0;
      return {
        entries: this.attachments
          .concat(c.hasAttachments(e) ? e.getAttachments() : [])
          .reduce((e, t) => {
            var { type: i } = t,
              s = l(t, ["type"]);
            return (e[i] = Object.assign({}, s)), e;
          }, {}),
        message: i ? a : a ? a.substring(0, 500) : void 0,
        timestamp: i ? new Date().toLocaleString() : new Date().toISOString(),
        activationTimestamp: i
          ? new Date(this.activationTimestamp).toLocaleString()
          : this.activationTimestamp,
        level: t,
        levelName: (0, o.A)(t),
        stack: i ? h : h ? h.substring(0, 500) : void 0,
        name: d,
        code: u,
        sampleRate: s,
        sampledOut: n,
      };
    }
  }
  (c.OWN_FRAMES = 4), (c.tslogURL = "https://onetag-sys.com/tslog/");
  const h = c;
  class d extends Error {
    getAttachments() {
      return [];
    }
  }
  class u extends d {
    constructor(e) {
      super(
        (function (e) {
          switch (e) {
            case "http-error":
              return "HttpClient: error status";
            case "http-timeout":
              return "HttpClient: timeout";
            case "http-aborted":
              return "HttpClient: aborted";
            case "http-offline":
              return "HttpClient: offline";
            case "http-transport-failure":
              return "HttpClient: transport failure";
          }
        })(e.kind)
      ),
        (this.context = e),
        (this.code = e.kind);
    }
    getAttachments() {
      return [this.context];
    }
  }
  class p {
    static isFetchSupported(e = window) {
      return "function" == typeof e.fetch && void 0 !== e.AbortController;
    }
    constructor(e, t = window) {
      (this.defaultTimeout = e),
        (this.scope = t),
        (this.defaultMethod = "POST"),
        (this.defaultCredentials = "include");
    }
    send(e, t = {}, i) {
      const {
        body: s,
        method: n = this.defaultMethod,
        credentials: r = this.defaultCredentials,
        timeout: o = this.defaultTimeout,
        keepalive: a = !1,
      } = t;
      if (!i)
        return new Promise((t, i) => {
          const l = (e) => t(e),
            c = (e) => i(e);
          this.sendInternal(e, n, s, r, o, a, l, c);
        });
      {
        const { onLoad: t, onError: l } = i;
        this.sendInternal(e, n, s, r, o, a, t, l);
      }
    }
    sendInternal(e, t, i, s, n, r, o, a) {
      p.isFetchSupported(this.scope)
        ? this.sendWithFetch(e, t, i, s, n, r, o, a)
        : this.sendWithXHR(e, t, i, s, n, r, o, a);
    }
    sendWithFetch(e, t, i, s, n, r, o, a) {
      const l = new this.scope.AbortController(),
        c = m("fetch", e, t, r, this.scope.navigator),
        h = g(o, a);
      let d;
      const u = {
        method: t,
        credentials: "include" === s ? "include" : "omit",
        signal: l.signal,
        keepalive: r,
      };
      i && (u.body = i),
        void 0 !== n &&
          n > 0 &&
          (d = window.setTimeout(() => {
            h.error(c("http-timeout", { timeoutMs: n })), l.abort();
          }, n));
      const p = () => {
        void 0 !== d && window.clearTimeout(d);
      };
      this.scope
        .fetch(e, u)
        .then((e) =>
          e.ok
            ? e.text().then((e) => {
                p(), h.load(e);
              })
            : (p(), void h.error(c("http-error", { status: e.status })))
        )
        .catch((e) => {
          p();
          const t = (function (e) {
              const { name: t, message: i } =
                null !== e && "object" == typeof e ? e : {};
              return {
                rawName: "string" == typeof t ? t : void 0,
                rawMessage: "string" == typeof i ? i : void 0,
              };
            })(e),
            i =
              "AbortError" === t.rawName
                ? "http-aborted"
                : !1 === this.scope.navigator.onLine
                ? "http-offline"
                : "http-transport-failure";
          h.error(c(i, t));
        });
    }
    sendWithXHR(e, t, i, s, n, r, o, a) {
      const l = new this.scope.XMLHttpRequest(),
        c = m("xhr", e, t, r, this.scope.navigator),
        h = g(o, a);
      l.open(t, e, !0),
        void 0 !== n && n > 0 && (l.timeout = n),
        (l.withCredentials = "include" === s),
        (l.onload = () => {
          l.status >= 200 && l.status <= 299
            ? h.load(l.responseText)
            : h.error(c("http-error", { status: l.status }));
        }),
        (l.ontimeout = () => {
          h.error(c("http-timeout", { timeoutMs: n }));
        }),
        (l.onabort = () => {
          h.error(c("http-aborted"));
        }),
        (l.onerror = () => {
          h.error(
            c(
              !1 === this.scope.navigator.onLine
                ? "http-offline"
                : "http-transport-failure"
            )
          );
        }),
        i ? l.send(i) : l.send();
    }
    get(e, t = {}, i) {
      const { timeout: s, credentials: n } = t;
      return i
        ? this.send(e, { method: "GET", timeout: s, credentials: n }, i)
        : this.send(e, { method: "GET", timeout: s, credentials: n });
    }
    post(e, t, i = {}, s) {
      const { timeout: n, credentials: r = "include" } = i;
      return s
        ? this.send(
            e,
            { method: "POST", body: t, timeout: n, credentials: r },
            s
          )
        : this.send(e, { method: "POST", body: t, timeout: n, credentials: r });
    }
  }
  function m(e, t, i, s, n) {
    const r = Date.now();
    return (o, a) =>
      new u(
        Object.assign(
          {
            type: "http",
            kind: o,
            transport: e,
            method: i,
            url: t.split(/[?#]/)[0],
            elapsedMs: Date.now() - r,
            onLine: n.onLine,
            keepalive: s,
          },
          a
        )
      );
  }
  function g(e, t) {
    let i = !1;
    return {
      load(s) {
        if (!i) {
          i = !0;
          try {
            e && e(s);
          } catch (e) {
            t && t(e);
          }
        }
      },
      error(e) {
        i || ((i = !0), t && t(e));
      },
    };
  }
  class f {
    static fromCreative(e) {
      return new f({
        debugInfo: e.debugInfo,
        impressionId: e.impressionId,
        bidUUID: e.bidUUID,
      });
    }
    constructor(e) {
      var t;
      (this.debugInfo = e.debugInfo),
        (this.impressionId =
          null !== (t = e.impressionId) && void 0 !== t ? t : ""),
        (this.bidUUID = e.bidUUID);
    }
    getDspId() {
      var e;
      return null === (e = this.debugInfo) || void 0 === e ? void 0 : e.dspId;
    }
    getCrId() {
      var e;
      return null === (e = this.debugInfo) || void 0 === e ? void 0 : e.crId;
    }
    getAdomain() {
      var e;
      return null === (e = this.debugInfo) || void 0 === e ? void 0 : e.adomain;
    }
    getPubId() {
      var e;
      return null === (e = this.debugInfo) || void 0 === e ? void 0 : e.pubId;
    }
    getDomain() {
      var e;
      return null === (e = this.debugInfo) || void 0 === e ? void 0 : e.domain;
    }
    getImpressionId() {
      return this.impressionId;
    }
    getBidUUID() {
      return this.bidUUID;
    }
    toJSON() {
      var e, t, i, s, n;
      return {
        dspId: null === (e = this.debugInfo) || void 0 === e ? void 0 : e.dspId,
        crId: null === (t = this.debugInfo) || void 0 === t ? void 0 : t.crId,
        adomain:
          null === (i = this.debugInfo) || void 0 === i ? void 0 : i.adomain,
        pubId: null === (s = this.debugInfo) || void 0 === s ? void 0 : s.pubId,
        domain:
          null === (n = this.debugInfo) || void 0 === n ? void 0 : n.domain,
        bidUUID: this.bidUUID,
        impressionId: this.impressionId,
      };
    }
  }
  class v {
    constructor() {
      this.events = {};
    }
    emit(e, ...t) {
      if (e in this.events)
        for (const { handler: i, context: s } of this.events[e].slice())
          null != s ? i.call(s, ...t) : i(...t);
    }
    on(e, t, i) {
      e in this.events || (this.events[e] = []),
        this.events[e].push({ handler: t, context: i });
    }
    off(e, t) {
      e in this.events &&
        (null != t &&
          (this.events[e] = this.events[e].filter((e) => e.handler !== t)),
        (null != t && 0 !== this.events[e].length) || delete this.events[e]);
    }
    once(e, t, i) {
      const s = (...n) => {
        this.off(e, s), null != i ? t.call(i, ...n) : t(...n);
      };
      this.on(e, s);
    }
    next(e) {
      return new Promise((t) => {
        this.once(e, (...e) => {
          0 === e.length ? t(void 0) : t(e);
        });
      });
    }
    handlerCount(e) {
      var t, i;
      return null !==
        (i =
          null === (t = this.events[e]) || void 0 === t ? void 0 : t.length) &&
        void 0 !== i
        ? i
        : 0;
    }
    clear() {
      for (const e in this.events) this.off(e);
    }
  }
  function w(
    {
      width: e,
      height: t,
      shouldSandbox: i,
      isVisible: s,
      forceUniqueOrigin: n = !1,
      trackClicks: r = !0,
    },
    o
  ) {
    const a = document.createElement("iframe"),
      l = new v();
    (a.frameBorder = "0"),
      (a.scrolling = "no"),
      (a.marginWidth = "0"),
      (a.marginHeight = "0"),
      (a.hspace = 0),
      (a.vspace = 0),
      (a.src = 'javascript:""');
    const c = a.style;
    if (
      ((c.border = "0px none"),
      (c.verticalAlign = "bottom"),
      !1 === s && (c.display = "none"),
      i)
    ) {
      const e =
        "allow-forms allow-modals allow-orientation-lock allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-presentation allow-same-origin allow-scripts allow-top-navigation-by-user-activation";
      a.setAttribute("sandbox", e);
    }
    if (n) {
      const e =
        "allow-forms allow-modals allow-orientation-lock allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-presentation allow-scripts allow-top-navigation-by-user-activation";
      a.setAttribute("sandbox", e);
    }
    return (
      (a.height = t + "px"),
      (a.width = e + "px"),
      {
        element: a,
        emitter: l,
        writeDocument(e) {
          var t;
          try {
            if (
              (null === (t = a.contentWindow) || void 0 === t || t.document,
              navigator.userAgent &&
                navigator.userAgent.toLowerCase().indexOf("firefox/") > -1)
            ) {
              const e = /firefox\/([\d\.]+)/,
                t = navigator.userAgent.toLowerCase().match(e)[1];
              t &&
                parseInt(t, 10) < 67 &&
                a.contentWindow.document.open("text/html", "replace");
            }
          } catch (e) {
            throw e;
          }
          if (
            (a.contentWindow.document.write(e),
            a.contentWindow.document.close(),
            r)
          ) {
            a.contentWindow.document.addEventListener("click", () =>
              l.emit("click")
            );
            const e = (function (e, t, i = document) {
              try {
                const t = [],
                  s = [],
                  n = (e) => -1 !== t.indexOf(e),
                  r = (e) => t.push(e),
                  o = (e, t) => s.push({ doc: e, listener: t }),
                  a = (e) => {
                    for (let t = 0; t < s.length; t++)
                      if (s[t].doc === e) return s[t].listener;
                  },
                  l = () => {
                    const t = i.getElementsByTagName("iframe");
                    for (let i = 0; i < t.length; i++) {
                      const s = t[i];
                      if (!n(s))
                        try {
                          if (s.contentWindow && s.contentWindow.document) {
                            const t = s.contentWindow.document,
                              i = function () {
                                e();
                              };
                            t.addEventListener("click", i), r(s), o(t, i);
                          }
                        } catch (e) {}
                    }
                  };
                l();
                let c = null,
                  h = null,
                  d = window;
                return (
                  "undefined" != typeof MutationObserver && i.body
                    ? ((c = new MutationObserver(function (e) {
                        for (let t = 0; t < e.length; t++) {
                          const i = e[t].addedNodes;
                          for (let e = 0; e < i.length; e++) {
                            const t = i[e];
                            if (1 === t.nodeType)
                              if ("IFRAME" === t.tagName) l();
                              else {
                                t.getElementsByTagName("iframe").length > 0 &&
                                  l();
                              }
                          }
                        }
                      })),
                      c.observe(i.body, { childList: !0, subtree: !0 }))
                    : (h = d.setInterval(l, 500)),
                  {
                    disconnect: function () {
                      const e = i.getElementsByTagName("iframe");
                      for (let t = 0; t < e.length; t++)
                        try {
                          const i =
                            e[t].contentWindow && e[t].contentWindow.document;
                          if (i) {
                            const e = a(i);
                            e && i.removeEventListener("click", e);
                          }
                        } catch (e) {}
                      c && c.disconnect(), null !== h && clearInterval(h);
                    },
                  }
                );
              } catch (e) {
                t.error(e);
              }
            })(
              () => {
                l.emit("click"), e && e.disconnect();
              },
              o,
              a.contentDocument
            );
          }
        },
      }
    );
  }
  function y() {
    let e = window;
    if (e.sfAPI || e.$sf) return !0;
    try {
      for (; e !== e.parent; ) {
        if (e.sfAPI || e.$sf) return !0;
        e = e.parent;
      }
      return !1;
    } catch (e) {
      return !1;
    }
  }
  class b extends v {
    static isSupported(e = window) {
      return null != e.IntersectionObserver;
    }
    static getWindowFromElement(e) {
      return e.ownerDocument && e.ownerDocument.defaultView
        ? e.ownerDocument.defaultView
        : window;
    }
    constructor(e, t = {}) {
      var i;
      super(),
        (this.element = e),
        (this.observer = null),
        (this._isIntersecting = !1),
        (this._hasTriggeredOnce = !1),
        (this.threshold = null !== (i = t.threshold) && void 0 !== i ? i : 0.5),
        (this.onIntersectionChange = this.onIntersectionChange.bind(this));
      const s = b.getWindowFromElement(e);
      if (b.isSupported(s)) {
        const e = { threshold: this.threshold };
        void 0 !== t.delay && (e.delay = t.delay),
          void 0 !== t.trackVisibility &&
            (e.trackVisibility = t.trackVisibility),
          (this.observer = new s.IntersectionObserver(
            this.onIntersectionChange,
            e
          )),
          this.observer.observe(this.element);
      }
    }
    get isIntersecting() {
      return this._isIntersecting;
    }
    get isSupported() {
      return null != this.observer;
    }
    get hasTriggeredOnce() {
      return this._hasTriggeredOnce;
    }
    onIntersectionChange(e) {
      const t = e[0];
      this.handleIntersectionEntry(t);
    }
    handleIntersectionEntry(e) {
      const t = this._isIntersecting;
      (this._isIntersecting = e.isIntersecting),
        t !== this._isIntersecting &&
          (this.emit("change", this._isIntersecting),
          this._isIntersecting &&
            !this._hasTriggeredOnce &&
            ((this._hasTriggeredOnce = !0), this.emit("intersecting")));
    }
    dispose() {
      this.observer &&
        (this.observer.unobserve(this.element), this.observer.disconnect()),
        this.clear();
    }
  }
  var x = function (e, t, i, s) {
    return new (i || (i = Promise))(function (n, r) {
      function o(e) {
        try {
          l(s.next(e));
        } catch (e) {
          r(e);
        }
      }
      function a(e) {
        try {
          l(s.throw(e));
        } catch (e) {
          r(e);
        }
      }
      function l(e) {
        var t;
        e.done
          ? n(e.value)
          : ((t = e.value),
            t instanceof i
              ? t
              : new i(function (e) {
                  e(t);
                })).then(o, a);
      }
      l((s = s.apply(e, t || [])).next());
    });
  };
  function I() {
    return void 0 !== document.hidden
      ? document.hidden
      : void 0 !== document.msHidden
      ? document.msHidden
      : void 0 !== document.webkitHidden && document.webkitHidden;
  }
  function E() {
    return void 0 !== document.hidden
      ? "visibilitychange"
      : void 0 !== document.msHidden
      ? "msvisibilitychange"
      : void 0 !== document.webkitHidden
      ? "webkitvisibilitychange"
      : "";
  }
  function T() {
    return x(this, void 0, void 0, function* () {
      for (; "loading" === document.readyState; )
        yield new Promise((e) => {
          const t = () => {
            document.removeEventListener("readystatechange", t), e();
          };
          document.addEventListener("readystatechange", t);
        });
    });
  }
  function P(e, t) {
    return new Promise((i) => {
      const s = t.getTopmostFriendlyContext().getWindow();
      let n = !1;
      const r = () => {
          n = !0;
        },
        o = () => {
          n = !1;
        },
        a = () => {
          n &&
            (s.removeEventListener("blur", a),
            e.removeEventListener("mouseover", r),
            e.removeEventListener("mouseout", o),
            i(0));
        };
      s.addEventListener("blur", a),
        e.addEventListener("mouseover", r),
        e.addEventListener("mouseout", o);
    });
  }
  class S {}
  class C {
    constructor() {
      (this.timestamp = null), (this._total = 0), (this._max = 0);
    }
    get isStarted() {
      return null != this.timestamp;
    }
    get max() {
      if (null != this.timestamp) {
        const e = Date.now() - this.timestamp;
        return e > this._max ? e : this._max;
      }
      return this._max;
    }
    get total() {
      if (null != this.timestamp) {
        const e = Date.now() - this.timestamp;
        return this._total + e;
      }
      return this._total;
    }
    start(e) {
      null == this.timestamp && (this.timestamp = null != e ? e : Date.now());
    }
    stop() {
      if (null != this.timestamp) {
        const e = Date.now() - this.timestamp;
        e > this._max && (this._max = e),
          (this._total += e),
          (this.timestamp = null);
      }
    }
  }
  class M extends S {
    constructor() {
      super(...arguments), (this.stopwatch = new C());
    }
    start() {
      this.stopwatch.start();
    }
    get isStarted() {
      return this.stopwatch.isStarted;
    }
  }
  var F = function (e, t, i, s) {
    return new (i || (i = Promise))(function (n, r) {
      function o(e) {
        try {
          l(s.next(e));
        } catch (e) {
          r(e);
        }
      }
      function a(e) {
        try {
          l(s.throw(e));
        } catch (e) {
          r(e);
        }
      }
      function l(e) {
        var t;
        e.done
          ? n(e.value)
          : ((t = e.value),
            t instanceof i
              ? t
              : new i(function (e) {
                  e(t);
                })).then(o, a);
      }
      l((s = s.apply(e, t || [])).next());
    });
  };
  class O {
    constructor(e = "", t = "", i, n, r) {
      (this.bidrequestId = e),
        (this.impressionId = t),
        (this.environment = i),
        (this.logger = n),
        (this.client = r),
        (this.collectors = []),
        (this.timerId = null),
        (this.startedAt = null),
        (this.started = !1),
        (this.environment = i || new s.A());
    }
    get isStarted() {
      return this.started;
    }
    addDataCollector(e) {
      if ((this.collectors.push(e), this.isStarted))
        if (e instanceof M)
          try {
            e.start();
          } catch (e) {
            this.logger.warn(e);
          }
        else
          this.mergeCollections([e]).then((e) => {
            this.log(e);
          });
    }
    addDataCollectors(...e) {
      e.forEach((e) => this.addDataCollector(e));
    }
    start() {
      this.started ||
        ((this.started = !0),
        this.periodicCollectors.forEach((e) => {
          try {
            e.start();
          } catch (e) {
            this.logger.warn(e);
          }
        }),
        this.getInitialData().then((e) => {
          this.log(e), (this.startedAt = Date.now()), this.loop();
        }));
    }
    stop() {
      null != this.timerId &&
        (clearInterval(this.timerId), (this.timerId = null)),
        (this.started = !1);
    }
    loop() {
      this.timerId = window.setTimeout(
        () =>
          F(this, void 0, void 0, function* () {
            const e = yield this.getPeriodicData();
            this.log(e),
              Date.now() - this.startedAt < O.MAX_ALIVE_TIME_MS
                ? this.loop()
                : this.logger.silly(
                    "Analytics max alive time reached, stopping..."
                  );
          }),
        5e3
      );
    }
    get initialCollectors() {
      return this.collectors.filter((e) => !(e instanceof M));
    }
    getInitialData() {
      return F(this, void 0, void 0, function* () {
        return this.mergeCollections(this.initialCollectors);
      });
    }
    get periodicCollectors() {
      return this.collectors.filter((e) => e instanceof M);
    }
    getPeriodicData() {
      return F(this, void 0, void 0, function* () {
        return this.mergeCollections(this.periodicCollectors);
      });
    }
    mergeCollections(e) {
      return F(this, void 0, void 0, function* () {
        return (yield Promise.all(
          e.map((e) =>
            F(this, void 0, void 0, function* () {
              var t;
              try {
                return null !== (t = yield e.collect()) && void 0 !== t
                  ? t
                  : {};
              } catch (e) {
                return this.logger.warn(e), {};
              }
            })
          )
        )).reduce((e, t) => Object.assign(Object.assign({}, e), t), {});
      });
    }
    log(e) {
      if (0 !== Object.keys(e).length) {
        const t = Object.assign(Object.assign({}, e), {
          bidrequestId: this.bidrequestId,
          impressionId: this.impressionId,
        });
        this.environment.sendsTelemetry()
          ? this.client.post(O.URL, JSON.stringify(t), {
              credentials: "include",
            })
          : this.logger.silly(
              `Analytics Collected\n${JSON.stringify(t, null, 2)}`
            );
      }
    }
  }
  (O.MAX_ALIVE_TIME_MS = 12e5), (O.URL = "https://onetag-sys.com/analytics/");
  const A = O;
  class V extends S {
    constructor(e, t = window, i = y) {
      super(), (this.context = e), (this.win = t), (this.detectSafeFrame = i);
    }
    collect() {
      const { navigator: e } = this.win;
      return {
        ancestorOrigin: this.context.getTopmostOrigin(),
        isTopWindow: this.context.isTopmost(),
        isFriendly: this.context.isFriendly(),
        isSafeFrame: this.detectSafeFrame(),
        isTouchDevice:
          "ontouchstart" in this.win ||
          e.maxTouchPoints > 0 ||
          (null != e.msMaxTouchPoints && e.msMaxTouchPoints > 0),
      };
    }
  }
  class D extends M {
    constructor() {
      super(...arguments), (this.initialTime = 0);
    }
    start() {
      (this.initialTime = Date.now()),
        document.hidden && this.stopwatch.start(this.initialTime),
        document.addEventListener(E(), () => {
          document.hidden ? this.stopwatch.start() : this.stopwatch.stop();
        });
    }
    collect() {
      return {
        totalTime: Date.now() - this.initialTime,
        totalHiddenTime: this.stopwatch.total,
      };
    }
  }
  class k extends M {
    constructor(e) {
      super(), (this.watcher = e);
    }
    start() {
      this.watcher.visibility.fiftyPercent.on("intersectionChange", (e) => {
        e ? this.stopwatch.start() : this.stopwatch.stop();
      }),
        this.watcher.visibility.fiftyPercent.isIntersecting &&
          this.stopwatch.start();
    }
    collect() {
      return { maxVisibilityTime: this.stopwatch.max };
    }
  }
  class H extends M {
    constructor(e) {
      super(), (this.target = e), (this.mouseEnters = 0);
    }
    start() {
      this.target.addEventListener("mouseenter", () => {
        ++this.mouseEnters, this.stopwatch.start();
      }),
        this.target.addEventListener("mouseleave", () => {
          this.stopwatch.stop();
        });
    }
    collect() {
      return {
        mouseEnters: this.mouseEnters,
        totalMouseTime: this.stopwatch.total,
      };
    }
  }
  class L extends S {
    constructor(e, t) {
      super(), (this.element = e), (this.context = t);
    }
    collect() {
      return (function (e, t) {
        var i;
        const {
            top: s,
            left: n,
            width: r,
            height: o,
          } = e.getBoundingClientRect(),
          a = { top: s, left: n, width: r, height: o };
        try {
          const s =
            (null === (i = e.ownerDocument) || void 0 === i
              ? void 0
              : i.defaultView) || window;
          (a.top += s.pageYOffset), (a.left += s.pageXOffset);
          for (const e of t.getFriendlyFrames()) {
            const { top: t, left: i } = e.getBoundingClientRect(),
              s = e.ownerDocument.defaultView;
            (a.top = a.top + t + s.pageYOffset),
              (a.left = a.left + i + s.pageXOffset);
          }
          return a;
        } catch (e) {
          return a;
        }
      })(this.element, this.context);
    }
  }
  class _ extends S {
    constructor(e) {
      super(), (this.stickyPlacement = e);
    }
    collect() {
      return { stickyPlacement: this.stickyPlacement };
    }
  }
  var R = function (e, t, i, s) {
    return new (i || (i = Promise))(function (n, r) {
      function o(e) {
        try {
          l(s.next(e));
        } catch (e) {
          r(e);
        }
      }
      function a(e) {
        try {
          l(s.throw(e));
        } catch (e) {
          r(e);
        }
      }
      function l(e) {
        var t;
        e.done
          ? n(e.value)
          : ((t = e.value),
            t instanceof i
              ? t
              : new i(function (e) {
                  e(t);
                })).then(o, a);
      }
      l((s = s.apply(e, t || [])).next());
    });
  };
  class B extends S {
    constructor(e) {
      super(), (this.supported = e);
    }
    collect() {
      return R(this, void 0, void 0, function* () {
        const e = yield this.supported;
        return void 0 === e ? {} : { supportsScrollReveal: e };
      });
    }
  }
  function N(e) {
    return (
      ("visible" !== e.overflowX && "clip" !== e.overflowX) ||
      ("visible" !== e.overflowY && "clip" !== e.overflowY)
    );
  }
  function U(e) {
    var t, i;
    return (
      $(e.transform, "none") ||
      $(e.translate, "none") ||
      $(e.rotate, "none") ||
      $(e.scale, "none") ||
      $(e.perspective, "none") ||
      $(e.filter, "none") ||
      $(e.backdropFilter, "none") ||
      $(e.webkitBackdropFilter, "none") ||
      /transform|translate|rotate|scale|perspective|filter/.test(
        null !== (t = e.willChange) && void 0 !== t ? t : ""
      ) ||
      /paint|layout|strict|content/.test(
        null !== (i = e.contain) && void 0 !== i ? i : ""
      ) ||
      $(e.containerType, "normal") ||
      $(e.contentVisibility, "visible")
    );
  }
  function W(e, t) {
    const i = [];
    for (let t = e; null !== t; t = t.parentElement) i.unshift(t);
    const s = e.ownerDocument,
      n = s.documentElement,
      r = s.body;
    let o = !1,
      a = !1,
      l = !1;
    for (const e of i) {
      const i = t(e);
      if ("fixed" === i.position && !a)
        return { element: e, position: "fixed" };
      if ("sticky" === i.position && !l)
        return { element: e, position: "sticky" };
      U(i) && (a = !0),
        e === n ? (o = N(i)) : (e !== r || o) && (l = l || N(i));
    }
    return null;
  }
  function j(e, t) {
    if (null !== W(e, t)) return !1;
    const i = e.parentElement,
      s = e.ownerDocument;
    return (
      !(!i || i === s.body || i === s.documentElement) &&
      (function (e, t) {
        const i = e.ownerDocument,
          s = i.documentElement,
          n = i.body,
          r = !N(t(s));
        let o = e.parentElement;
        for (; o && o !== s && (o !== n || !r); ) {
          if (N(t(o))) return !1;
          o = o.parentElement;
        }
        return !0;
      })(e, t)
    );
  }
  function $(e, t) {
    return null != e && "" !== e && e !== t;
  }
  function z(e, t, i, { observed: s = !1, underHeader: n = !1 } = {}) {
    if (
      !(function (e, t) {
        return e.width >= 100 && e.height >= 20 && e.height <= 0.5 * t;
      })(e, t)
    )
      return "not-sticky";
    const r = "fixed" === i || s ? Math.max(4, 0.5 * e.height) : 4,
      o = t - e.bottom;
    return (o >= -r && o <= 4) || ("fixed" === i && o > 0 && o <= 48)
      ? "sticky-bottom"
      : (e.top >= -r && e.top <= 4) || n
      ? "sticky-top"
      : "not-sticky";
  }
  class q {
    constructor() {
      this.pinned = !1;
    }
    next(e) {
      const t = this.reference;
      if (void 0 === t) return (this.reference = e), null;
      const i = e.scrollY - t.scrollY,
        s = e.box.top - t.box.top,
        n = e.viewportHeight - e.box.bottom - (t.viewportHeight - t.box.bottom);
      if (Math.abs(s) <= 4 || Math.abs(n) <= 4) {
        const t = e.box.bottom > 4 && e.box.top < e.viewportHeight - 4;
        return this.pinned || !t || Math.abs(i) < 24
          ? null
          : ((this.pinned = !0), "pinned");
      }
      this.reference = e;
      return 0 !== i && Math.abs(s + i) <= Math.abs(i) / 2 && e.box.bottom <= 0
        ? "in-flow"
        : null;
    }
  }
  class J {
    static forPlacement(e, t, i) {
      var s;
      let n = null;
      try {
        n = t.isFriendly() ? (t.isTopmost() ? e : t.getTopmostIFrame()) : null;
      } catch (e) {
        i.warn(e);
      }
      return new J(
        n,
        null !== (s = null == n ? void 0 : n.ownerDocument.defaultView) &&
        void 0 !== s
          ? s
          : null,
        i
      );
    }
    constructor(e, t, i, s = 3e4) {
      (this.slot = e),
        (this.win = t),
        (this.logger = i),
        (this.observationTimeout = s),
        (this.verdict = "unknown"),
        (this.observation = new q()),
        (this.frameId = null),
        (this.timeoutId = null),
        (this.observing = !1),
        (this.failed = !1),
        (this.onScroll = this.onScroll.bind(this)),
        (this.sample = this.sample.bind(this));
    }
    detect() {
      var e, t;
      const { slot: i, win: s } = this;
      if (null === i || null === s) return (this.verdict = "unknown");
      try {
        const n = s.getComputedStyle(i),
          r =
            "none" === n.display || "hidden" === n.visibility
              ? null
              : this.readBox(i),
          o = this.readStyle(s),
          a =
            null !==
              (t =
                null === (e = W(i, o)) || void 0 === e ? void 0 : e.position) &&
            void 0 !== t
              ? t
              : null,
          l =
            null !== r &&
            null !== a &&
            r.top < s.innerHeight &&
            this.isInOrUnderPinnedHeader(i, o, s);
        return (this.verdict = (function (e, t, i, s = !1) {
          return null === e || 0 === e.width || 0 === e.height
            ? "unknown"
            : null === i
            ? "not-sticky"
            : e.top >= t - 4 || e.bottom <= 4
            ? "unknown"
            : z(e, t, i, { underHeader: s });
        })(r, s.innerHeight, a, l));
      } catch (e) {
        return this.fail(e), (this.verdict = "unknown");
      }
    }
    observe(e) {
      const { slot: t, win: i } = this;
      if (null !== t && null !== i && !this.observing && !this.failed) {
        try {
          i.addEventListener("scroll", this.onScroll, { passive: !0 }),
            (this.timeoutId = i.setTimeout(
              () => this.stop(),
              this.observationTimeout
            ));
        } catch (e) {
          return void this.fail(e);
        }
        (this.observing = !0), (this.onChange = e);
      }
    }
    dispose() {
      this.stop();
    }
    onScroll() {
      null === this.frameId &&
        null !== this.win &&
        (this.frameId = this.win.requestAnimationFrame(this.sample));
    }
    sample() {
      var e, t;
      this.frameId = null;
      const { slot: i, win: s } = this;
      if (this.observing && null !== i && null !== s)
        try {
          const n = this.readBox(i);
          if (null === n || 0 === n.width || 0 === n.height)
            return void this.stop();
          const r = this.observation.next({
            scrollY: s.pageYOffset,
            viewportHeight: s.innerHeight,
            box: n,
          });
          if (null === r) return;
          const o = this.onChange;
          let a;
          if ("in-flow" === r) (a = "not-sticky"), this.stop();
          else {
            const r = this.readStyle(s);
            a = z(
              n,
              s.innerHeight,
              null !==
                (t =
                  null === (e = W(i, r)) || void 0 === e
                    ? void 0
                    : e.position) && void 0 !== t
                ? t
                : null,
              {
                observed: !0,
                underHeader: this.isInOrUnderPinnedHeader(i, r, s),
              }
            );
          }
          a !== this.verdict && ((this.verdict = a), null == o || o(a));
        } catch (e) {
          this.fail(e);
        }
    }
    fail(e) {
      (this.failed = !0), this.logger.warn(e), this.stop();
    }
    stop() {
      const e = this.win;
      this.observing &&
        null !== e &&
        ((this.observing = !1),
        delete this.onChange,
        e.removeEventListener("scroll", this.onScroll),
        null !== this.frameId &&
          (e.cancelAnimationFrame(this.frameId), (this.frameId = null)),
        null !== this.timeoutId &&
          (e.clearTimeout(this.timeoutId), (this.timeoutId = null)));
    }
    readBox(e) {
      if (!e.ownerDocument.documentElement.contains(e)) return null;
      const {
        top: t,
        bottom: i,
        width: s,
        height: n,
      } = e.getBoundingClientRect();
      return { top: t, bottom: i, width: s, height: n };
    }
    readStyle(e) {
      return (t) => e.getComputedStyle(t);
    }
    isInOrUnderPinnedHeader(e, t, i) {
      const s = i.innerHeight,
        n = e.getBoundingClientRect(),
        r = n.left + n.width / 2;
      let o = n.top;
      for (let n = 0; n < 2 && o > 4; n++) {
        const n = i.document.elementFromPoint(r, o - 1),
          a = null === n ? null : W(n, t);
        if (null === a) return !1;
        const l = a.element.getBoundingClientRect(),
          c = l.top <= 4 && l.top >= 0.5 * -l.height;
        if (!a.element.contains(e)) return c && Math.abs(l.bottom - o) <= 4;
        if (c && l.height <= 0.5 * s) return !0;
        o = l.top;
      }
      return !1;
    }
  }
  var Y = function (e, t, i, s) {
    return new (i || (i = Promise))(function (n, r) {
      function o(e) {
        try {
          l(s.next(e));
        } catch (e) {
          r(e);
        }
      }
      function a(e) {
        try {
          l(s.throw(e));
        } catch (e) {
          r(e);
        }
      }
      function l(e) {
        var t;
        e.done
          ? n(e.value)
          : ((t = e.value),
            t instanceof i
              ? t
              : new i(function (e) {
                  e(t);
                })).then(o, a);
      }
      l((s = s.apply(e, t || [])).next());
    });
  };
  function X(e, t, i = window) {
    const s = e.split(".").reduce((e, t) => ((e[t] = e[t] || {}), e[t]), i);
    return Object.keys(t).forEach((e) => (s[e] = t[e])), t;
  }
  function G(e, t, i) {
    const s = 0 === t.clientWidth && 0 === t.clientHeight,
      n = y() && s ? parseInt(window.getComputedStyle(t).width) : t.clientWidth,
      r =
        y() && s ? parseInt(window.getComputedStyle(t).height) : t.clientHeight,
      o = e.width < n && e.height < r,
      a = e.width > n && e.height > r;
    if (e.width === n && e.height === r) return 1;
    if (a || (i && o)) {
      let t = n / e.width;
      return e.height * t > r && (t = r / e.height), o && t > 1.5 ? 1.5 : t;
    }
    return e.width > n ? n / e.width : e.height > r ? r / e.height : 1;
  }
  class K {
    constructor(e, t, i = new s.A(), n = () => window.sessionStorage) {
      (this.key = e),
        (this.defaultValue = t),
        (this.environment = i),
        (this.storage = n);
    }
    write(e) {
      try {
        let t = JSON.stringify(e);
        this.environment.isProduction() && (t = btoa(t)),
          this.storage().setItem(this.key, t);
      } catch (e) {
        return;
      }
    }
    read() {
      try {
        let e = this.storage().getItem(this.key);
        return null != e
          ? (this.environment.isProduction() && (e = atob(e)), JSON.parse(e))
          : this.defaultValue;
      } catch (e) {
        return this.defaultValue;
      }
    }
    clear() {
      try {
        this.storage().removeItem(this.key);
      } catch (e) {}
    }
  }
  class Q extends K {
    constructor(e, t) {
      super(Q.key, [], e, t);
    }
    add(...e) {
      const t = this.read(),
        i = e
          .map(({ bidUUID: e }) => ({ bidUUID: e }))
          .filter((e) => t.every((t) => e.bidUUID !== t.bidUUID)),
        s = t.concat(i);
      this.write(s);
    }
  }
  Q.key = "_otdup";
  const Z = Q;
  class ee {
    constructor(e = navigator.userAgent) {
      this.userAgent = e;
    }
    isTouchDevice() {
      return !!this.userAgent.match(
        /Mobile|iP(hone|od|ad)|Android|BlackBerry|IEMobile|Kindle|NetFront|Silk-Accelerated|(hpw|web)OS|Fennec|Minimo|Opera M(obi|ini)|Blazer|Dolfin|Dolphin|Skyfire|Zune/
      );
    }
  }
  const te = [
    "Unknown MRAID event: exposureChange",
    "Unknown event: exposureChange",
  ];
  class ie extends d {
    constructor(e, t) {
      super("MRAID container error"),
        (this.containerError = e),
        (this.action = t),
        (this.code = "mraid-container-error");
    }
    isBenign() {
      return (
        "removeEventListener" === this.action ||
        ("addEventListener" === this.action &&
          -1 !== te.indexOf(this.containerError))
      );
    }
    getAttachments() {
      return [
        {
          type: "mraid",
          containerError: this.containerError,
          action: this.action,
        },
      ];
    }
  }
  class se {
    constructor() {
      (this.shouldTriggerOneTagPixel = !0), (this.canBeFiredMultipleTimes = !0);
    }
    get name() {
      return Object.getPrototypeOf(this).constructor.name.replace(/Event$/, "");
    }
  }
  class ne extends se {
    constructor() {
      super(...arguments), (this.id = 770), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class re extends se {
    constructor() {
      super(...arguments), (this.id = 705), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class oe extends se {
    constructor() {
      super(...arguments), (this.id = 711);
    }
  }
  class ae extends se {
    constructor() {
      super(...arguments), (this.id = 704), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class le extends se {
    constructor() {
      super(...arguments), (this.id = 718), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class ce extends se {
    constructor() {
      super(...arguments), (this.id = 730), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class he extends se {
    constructor() {
      super(...arguments), (this.id = 717), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class de extends se {
    constructor() {
      super(...arguments), (this.id = 732), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class ue extends se {
    constructor() {
      super(...arguments), (this.id = 776), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class pe extends v {
    constructor(e) {
      super(), (this.options = e), (this.id = null);
    }
    get isRunning() {
      return null != this.id;
    }
    start() {
      null === this.id &&
        (this.id = window.setTimeout(() => {
          (this.id = null),
            this.emit("expire"),
            this.options.loop && this.start();
        }, this.options.duration));
    }
    stop() {
      null !== this.id && (window.clearTimeout(this.id), (this.id = null));
    }
  }
  function me(e) {
    return !0 === e || "true" === e;
  }
  class ge {
    constructor(e, t, i) {
      (this.mraid = e),
        (this.logger = t),
        (this.bidDomain = i),
        (this.listeners = new Map());
    }
    get listenerCount() {
      return this.listeners.size;
    }
    addEventListener(e, t) {
      const i = this.listenerFor(e, t);
      try {
        this.mraid.addEventListener(e, i), this.listeners.set(e, i);
      } catch (t) {
        this.isExpectedRegistrationFailure(e)
          ? this.logger.debug(t)
          : this.logger.warn(t);
      }
    }
    removeEventListener(e) {
      try {
        const t = this.listeners.get(e);
        t && (this.mraid.removeEventListener(e, t), this.listeners.delete(e));
      } catch (e) {
        this.logger.warn(e);
      }
    }
    removeAllListeners() {
      for (const e of Array.from(this.listeners.keys()))
        this.removeEventListener(e);
    }
    getState() {
      return this.mraid.getState();
    }
    isViewable() {
      return me(!!this.mraid.isViewable && this.mraid.isViewable());
    }
    listenerFor(e, t) {
      if ("viewableChange" !== e) return t;
      const i = t;
      return (e) => i(me(e));
    }
    isExpectedRegistrationFailure(e) {
      return "viewableChange" === e && "com.truecaller" === this.bidDomain;
    }
  }
  class fe {
    constructor(e = window, t) {
      (this.win = e), (this.logger = t);
    }
    isAvailable() {
      var e;
      try {
        return null != this.win.mraid || null != this.win.MRAID_ENV;
      } catch (t) {
        return null === (e = this.logger) || void 0 === e || e.warn(t), !1;
      }
    }
    getMraid() {
      var e, t;
      try {
        return null !== (e = this.win.mraid) && void 0 !== e ? e : void 0;
      } catch (e) {
        return void (null === (t = this.logger) || void 0 === t || t.warn(e));
      }
    }
    detectVersion() {
      const e = this.readMraidVersion();
      return void 0 !== e ? e : this.readEnvVersion();
    }
    readMraidVersion() {
      const e = this.win.mraid;
      if (e && "function" == typeof e.getVersion) {
        const t = e.getVersion();
        if (null != t) return parseFloat(t);
      }
    }
    readEnvVersion() {
      const e = this.win.MRAID_ENV;
      if (e && null != e.version) return parseFloat(e.version);
    }
  }
  class ve {
    constructor() {
      (this._isReady = !1),
        (this._version = void 0),
        (this._lastExposure = void 0),
        (this._lastViewable = void 0);
    }
    markReady(e) {
      (this._isReady = !0), (this._version = e);
    }
    setLastExposure(e) {
      this._lastExposure = e;
    }
    setLastViewable(e) {
      this._lastViewable = e;
    }
    get isReady() {
      return this._isReady;
    }
    get version() {
      return this._version;
    }
    get lastExposure() {
      return this._lastExposure;
    }
    get lastViewable() {
      return this._lastViewable;
    }
  }
  class we {
    build(e, t) {
      return (
        "<script>function doPollingOnObject(object, callback) {const interval = 100;const timeout = 1000;let startTime = Date.now();let intervalId;intervalId = setInterval(function() {if (object in window) {clearInterval(intervalId);callback(true);return;}if (Date.now() - startTime >= timeout) {clearInterval(intervalId);callback(false);}}, interval);}doPollingOnObject('mraid', function(objectFound) {if (objectFound && window.mraid.open) {const originalOpen = window.mraid.open;window.mraid.open = function(url) {new Image().src = '" +
        e.replace("ONETAG_EVENT_ID", String(t)) +
        "';originalOpen(url);}}});</script>"
      );
    }
  }
  class ye extends v {
    constructor(e, t, i) {
      super(), (this.topic = e), (this.origin = t), (this.source = i);
    }
    send(e) {
      this.source.postMessage({ onetag: e }, this.origin);
    }
    onMessageReceived(e) {
      this.emit("message", e);
    }
    dispose() {
      super.clear();
    }
  }
  function be(e) {
    return null != e && "object" == typeof e && "onetag" in e;
  }
  class xe {
    constructor(e, t) {
      (this.data = e), (this.channel = t);
    }
    reply(e) {
      this.channel.send(e);
    }
  }
  class Ie extends v {
    constructor(e, t, i = "*", s = window, n) {
      super(),
        (this.topic = e),
        (this.logger = t),
        (this.origin = i),
        (this.provider = s),
        (this.target = n),
        (this.channels = []),
        (this.onMessage = this.onMessage.bind(this));
    }
    getChannels() {
      return [...this.channels];
    }
    listen() {
      this.logger.silly(
        `Message server ${this.topic}: now listening for connections`
      ),
        this.provider.addEventListener("message", this.onMessage);
    }
    dispose() {
      for (const e of this.channels) e.dispose();
      (this.channels = []),
        this.provider.removeEventListener("message", this.onMessage);
    }
    broadcast(e) {
      for (const t of this.channels) t.send(e);
    }
    onMessage(e) {
      if (("*" === this.origin || this.origin === e.origin) && be(e.data)) {
        const t = e.data.onetag,
          i =
            null != e.source &&
            (function (e) {
              return null != e && "postMessage" in e;
            })(e.source)
              ? e.source
              : this.target;
        if (i) {
          const s = new ye(this.topic, this.origin, i);
          this.logger.silly(
            `Message server "${this.topic}": received message from origin ${
              e.origin
            }\n${JSON.stringify(t, null, 2)}`
          ),
            this.channels.every((e) => s.source !== e.source) &&
              this.channels.push(s),
            this.emit("message", new xe(t, s));
        }
      }
    }
  }
  class Ee extends ye {
    constructor(e, t, i = "*", s = window.parent, n = window) {
      super(e, i, s),
        (this.logger = t),
        (this.provider = n),
        (this.onMessage = this.onMessage.bind(this));
    }
    connect() {
      this.provider.addEventListener("message", this.onMessage);
    }
    dispose() {
      this.provider.removeEventListener("message", this.onMessage),
        super.dispose();
    }
    onMessage(e) {
      const t = e.data,
        i = "*" === this.origin || this.origin === e.origin;
      if (be(t) && i) {
        const i = t.onetag;
        this.logger.silly(
          `Message client "${this.topic}": received message from origin ${
            e.origin
          }\n${JSON.stringify(i, null, 2)}`
        ),
          this.onMessageReceived(new xe(i, this));
      }
    }
  }
  var Te = function (e, t, i, s) {
    return new (i || (i = Promise))(function (n, r) {
      function o(e) {
        try {
          l(s.next(e));
        } catch (e) {
          r(e);
        }
      }
      function a(e) {
        try {
          l(s.throw(e));
        } catch (e) {
          r(e);
        }
      }
      function l(e) {
        var t;
        e.done
          ? n(e.value)
          : ((t = e.value),
            t instanceof i
              ? t
              : new i(function (e) {
                  e(t);
                })).then(o, a);
      }
      l((s = s.apply(e, t || [])).next());
    });
  };
  class Pe extends v {
    constructor(e, t, i, s = {}) {
      var n, r, o, a, l, c, h;
      super(),
        (this.adEventManager = e),
        (this.bidRequestInfo = i),
        (this.logger = t
          .fork()
          .integrate({ type: "renderer", context: "MraidHandler" })),
        (this.detector =
          null !== (n = s.detector) && void 0 !== n
            ? n
            : new fe(window, this.logger)),
        (this.stateStore =
          null !== (r = s.stateStore) && void 0 !== r ? r : new ve()),
        (this.children =
          null !== (o = s.children) && void 0 !== o
            ? o
            : new Ie("mraid", this.logger)),
        (this.parent =
          null !== (a = s.parent) && void 0 !== a
            ? a
            : new Ee("mraid", this.logger)),
        (this.openCodeBuilder =
          null !== (l = s.openCodeBuilder) && void 0 !== l ? l : new we()),
        (this.creativeViewTimer =
          null !== (c = s.creativeViewTimer) && void 0 !== c
            ? c
            : new pe({ duration: 1e3 })),
        (this.apiFactory =
          null !== (h = s.apiFactory) && void 0 !== h
            ? h
            : (e) => new ge(e, this.logger, this.bidRequestInfo.getDomain())),
        (this.onReady = this.onReady.bind(this)),
        (this.onError = this.onError.bind(this)),
        (this.onViewableChange = this.onViewableChange.bind(this)),
        (this.onExposureChange = this.onExposureChange.bind(this)),
        this.creativeViewTimer.on("expire", () => {
          this.adEventManager.fire(new ae());
        });
    }
    get detectedMraidVersion() {
      return this._detectedMraidVersion;
    }
    get listenerCount() {
      return this.api ? this.api.listenerCount : 0;
    }
    isAvailable() {
      return this.detector.isAvailable();
    }
    addEventListener(e, t) {
      this.ensureApi(), this.api && this.api.addEventListener(e, t);
    }
    removeEventListener(e) {
      var t;
      null === (t = this.api) || void 0 === t || t.removeEventListener(e);
    }
    start() {
      return Te(this, void 0, void 0, function* () {
        try {
          this.isAvailable()
            ? ((this._detectedMraidVersion = this.detector.detectVersion()),
              this.triggerMeasurableImpressionEvents(
                this._detectedMraidVersion
              ),
              this.listen())
            : this.connectToMainMRAIDHandler();
        } catch (e) {
          this.logger.warn(e);
        }
      });
    }
    destroy() {
      try {
        this.creativeViewTimer.stop(),
          this.children.dispose(),
          this.parent.dispose(),
          this.isAvailable() && this.api && this.api.removeAllListeners();
      } catch (e) {
        this.logger.warn(e);
      }
    }
    onReady() {
      try {
        if ((this.ensureApi(), !this.api)) return;
        this.adEventManager.fire(new ue()),
          this.api.addEventListener("error", this.onError),
          null == this._detectedMraidVersion &&
            (this._detectedMraidVersion = this.detector.detectVersion()),
          null != this._detectedMraidVersion &&
            (this._detectedMraidVersion >= 3 &&
              this.api.addEventListener(
                "exposureChange",
                this.onExposureChange
              ),
            this.api.isViewable()
              ? this.onViewableChange(!0)
              : this.api.addEventListener(
                  "viewableChange",
                  this.onViewableChange
                )),
          this.api.removeEventListener("ready"),
          this.stateStore.markReady(this._detectedMraidVersion),
          this.children.broadcast({
            type: "ready",
            version: this._detectedMraidVersion,
          });
      } catch (e) {
        this.logger.warn(e);
      }
    }
    onViewableChange(e) {
      try {
        e &&
          !this.adEventManager.hasFired(new ce()) &&
          (this.adEventManager.fire(new ce()),
          this.adEventManager.fire(new he()),
          this.emit("billableMraidImpressionTriggered")),
          this.stateStore.setLastViewable(e),
          this.children.broadcast({ type: "viewableChange", viewable: e });
      } catch (e) {
        this.logger.warn(e);
      }
    }
    onExposureChange(e, t, i) {
      try {
        this.logger.silly(
          "exposureChange handled -> exposedPercentage = " +
            e +
            ", visibleRectangle = " +
            JSON.stringify(t) +
            ", occlusionRectangles = " +
            JSON.stringify(i)
        ),
          e > 0 &&
            !this.adEventManager.hasFired(new ce()) &&
            (this.adEventManager.fire(new ce()),
            this.adEventManager.fire(new le()),
            this.emit("billableMraidImpressionTriggered")),
          e >= 50 && !this.adEventManager.hasFired(new ae())
            ? this.creativeViewTimer.start()
            : this.creativeViewTimer.stop(),
          this.stateStore.setLastExposure({
            exposedPercentage: e,
            visibleRectangle: t,
            occlusionRectangles: i,
          }),
          this.children.broadcast({
            type: "exposureChange",
            exposedPercentage: e,
            visibleRectangle: t,
            occlusionRectangles: i,
          });
      } catch (e) {
        this.logger.warn(e);
      }
    }
    broadcastMraidEvent(e, t) {
      this.children.broadcast(Object.assign({ type: e }, t));
    }
    getOverrideOpenCode() {
      return this.openCodeBuilder.build(
        this.adEventManager.pingUrl,
        new de().id
      );
    }
    listen() {
      this.children.on("message", (e) => {
        "request-state" === e.data.type &&
          e.reply({
            type: "state-response",
            state: {
              isAvailable: this.isAvailable(),
              isReady: this.stateStore.isReady,
              version: this.stateStore.version,
              lastExposure: this.stateStore.lastExposure,
              lastViewable: this.stateStore.lastViewable,
            },
          });
      }),
        this.children.listen(),
        this.ensureApi(),
        this.api &&
          ("loading" === this.api.getState()
            ? this.api.addEventListener("ready", this.onReady)
            : this.onReady());
    }
    connectToMainMRAIDHandler() {
      this.logger.silly(
        "Additional creative: listening for proxied MRAID events"
      ),
        this.parent.on("message", (e) => {
          switch (e.data.type) {
            case "ready":
              this.adEventManager.fire(new ue());
              break;
            case "state-response":
              this.handleStateResponse(e.data);
              break;
            case "viewableChange": {
              const t = e.data;
              null != t.viewable && this.onViewableChange(t.viewable);
              break;
            }
            case "exposureChange": {
              const t = e.data;
              null != t.exposedPercentage &&
                this.onExposureChange(
                  t.exposedPercentage,
                  t.visibleRectangle,
                  t.occlusionRectangles
                );
              break;
            }
          }
        }),
        this.parent.connect(),
        this.parent.send({ type: "request-state" });
    }
    handleStateResponse(e) {
      e.state.isAvailable &&
        this.triggerMeasurableImpressionEvents(e.state.version),
        e.state.isReady &&
          (this.adEventManager.fire(new ue()),
          e.state.lastExposure &&
            this.onExposureChange(
              e.state.lastExposure.exposedPercentage,
              e.state.lastExposure.visibleRectangle,
              e.state.lastExposure.occlusionRectangles
            ),
          null != e.state.lastViewable &&
            this.onViewableChange(e.state.lastViewable));
    }
    triggerMeasurableImpressionEvents(e) {
      switch ((this.adEventManager.fire(new ne()), e)) {
        case 3:
          this.adEventManager.fire(new re());
          break;
        case 2:
        case 1:
          this.adEventManager.fire(new oe());
      }
    }
    onError(e, t) {
      try {
        const i = new ie(e, t);
        i.isBenign() ? this.logger.debug(i) : this.logger.warn(i);
      } catch (e) {
        this.logger.warn(e);
      }
    }
    ensureApi() {
      if (this.api) return;
      const e = this.detector.getMraid();
      e && (this.api = this.apiFactory(e));
    }
  }
  class Se {
    constructor(e, t, i = [], s = window) {
      (this.pingUrl = e),
        (this.logger = t),
        (this.thirdPartyEventPixels = i),
        (this.scope = s),
        (this.firedEvents = new Set());
    }
    setThirdPartyPixels(e = []) {
      this.thirdPartyEventPixels = e;
    }
    hasFired(e) {
      return this.firedEvents.has(e.id);
    }
    fire(e) {
      let t = Promise.resolve();
      if (!e.canBeFiredMultipleTimes && this.hasFired(e))
        this.logger.warn(
          `Event ${e.id} has already been fired and cannot be called multiple times.`
        );
      else {
        this.logger.trace(`Fire ad event ${e.name} (${e.id})`),
          this.logger.event(e.id, e.name),
          e.shouldTriggerOneTagPixel && (t = this.callOneTagPixel(e));
        const i = this.thirdPartyEventPixels.filter(
          ({ eventId: t }) => t === e.id
        );
        for (const { method: e, pixel: t } of i) {
          switch (e) {
            case 1:
              new this.scope.Image().src = t;
              break;
            case 2:
              const i = this.scope.document.createElement("script");
              (i.async = !0),
                (i.src = t),
                this.scope.document.body.appendChild(i);
              break;
            default:
              this.logger.error(
                new Error(`Invalid third party pixel method ${e}`)
              );
          }
          this.logger.silly(
            `Called third party pixel ${t} (method: ${
              1 === e ? "<img>" : "<script>"
            })`
          );
        }
        this.firedEvents.add(e.id);
      }
      return t;
    }
    callOneTagPixel(e) {
      return new Promise((t) => {
        const i = new this.scope.Image(),
          s = () => {
            window.clearTimeout(n), (i.onload = null), (i.onerror = null), t();
          },
          n = window.setTimeout(() => {
            this.logger.trace(
              `OneTag pixel of event ${e.id} did not answer within 1000 ms`
            ),
              s();
          }, 1e3);
        (i.onload = s),
          (i.onerror = s),
          (i.src = this.pingUrl.replace("ONETAG_EVENT_ID", String(e.id)));
      });
    }
  }
  function Ce(e) {
    return new Promise((t) => setTimeout(t, e));
  }
  var Me = function (e, t, i, s) {
    return new (i || (i = Promise))(function (n, r) {
      function o(e) {
        try {
          l(s.next(e));
        } catch (e) {
          r(e);
        }
      }
      function a(e) {
        try {
          l(s.throw(e));
        } catch (e) {
          r(e);
        }
      }
      function l(e) {
        var t;
        e.done
          ? n(e.value)
          : ((t = e.value),
            t instanceof i
              ? t
              : new i(function (e) {
                  e(t);
                })).then(o, a);
      }
      l((s = s.apply(e, t || [])).next());
    });
  };
  var Fe = function (e, t, i, s) {
      return new (i || (i = Promise))(function (n, r) {
        function o(e) {
          try {
            l(s.next(e));
          } catch (e) {
            r(e);
          }
        }
        function a(e) {
          try {
            l(s.throw(e));
          } catch (e) {
            r(e);
          }
        }
        function l(e) {
          var t;
          e.done
            ? n(e.value)
            : ((t = e.value),
              t instanceof i
                ? t
                : new i(function (e) {
                    e(t);
                  })).then(o, a);
        }
        l((s = s.apply(e, t || [])).next());
      });
    },
    Oe = function (e, t) {
      var i = {};
      for (var s in e)
        Object.prototype.hasOwnProperty.call(e, s) &&
          t.indexOf(s) < 0 &&
          (i[s] = e[s]);
      if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
        var n = 0;
        for (s = Object.getOwnPropertySymbols(e); n < s.length; n++)
          t.indexOf(s[n]) < 0 &&
            Object.prototype.propertyIsEnumerable.call(e, s[n]) &&
            (i[s[n]] = e[s[n]]);
      }
      return i;
    };
  function Ae(e, t, i) {
    return Fe(this, arguments, void 0, function* (e, t, i, s = {}) {
      var { exclude: n } = s,
        r = Oe(s, ["exclude"]);
      try {
        if (i.isProduction()) {
          const i = yield new Promise((i, s) => {
              var n;
              new p().post(
                `https://${
                  ((n = t),
                  n.localDecoder
                    ? n.localDecoder.concat(".onetag-sys.com")
                    : "onetag-sys.com")
                }/update`,
                JSON.stringify(
                  Object.assign(Object.assign(Object.assign({}, t), r), {
                    multiFormat: e.reduce(
                      (e, t) =>
                        e.concat(
                          t.formats.map((e) => ({
                            formatId: e,
                            sizes: t.sizes,
                          }))
                        ),
                      []
                    ),
                  })
                ),
                {},
                {
                  onLoad: (e) => {
                    let t;
                    try {
                      t = JSON.parse(e);
                    } catch (e) {
                      t = { invocations: [] };
                    }
                    Array.isArray(null == t ? void 0 : t.invocations) ||
                      (t.invocations = []),
                      i(t);
                  },
                  onError: s,
                }
              );
            }),
            { invocations: s } = i,
            o = Oe(i, ["invocations"]);
          return Object.assign(Object.assign({}, o), {
            invocations: n
              ? s.filter((e) => n.every(({ bidUUID: t }) => e.bidUUID !== t))
              : s,
          });
        }
        {
          const e = window.fakeFetchCreatives;
          if (e) {
            const t = yield e();
            return (
              Array.isArray(null == t ? void 0 : t.invocations) ||
                (t.invocations = []),
              t
            );
          }
          return { invocations: [] };
        }
      } catch (e) {
        return { invocations: [] };
      }
    });
  }
  function Ve(e, t, i, s, n) {
    const r = w(
      {
        width: e.w,
        height: e.h,
        shouldSandbox: !1,
        forceUniqueOrigin: !1,
        isVisible: !0,
      },
      n
    );
    if (2 == e.formatId) {
      const i = G({ width: e.w, height: e.h }, t, s);
      (r.element.style.transform = `scale(${i})`),
        (r.element.style.flex = "0 0 auto");
    } else (r.element.style.width = "100%"), (r.element.style.height = "100%");
    (r.element.src = e.invocationUrl), (new Image().src = e.ping);
    const o = document.createElement("div");
    return (
      (o.style.cssText = `\n        background: transparent;\n        display: flex;\n        align-items: center;\n        justify-content: center;\n        width: 100%;\n        height: 100%;\n        position: absolute;\n        z-index: ${
        i ? 1 : -1
      };\n        opacity: ${i ? 1 : 0};\n    `),
      o.appendChild(r.element),
      t.appendChild(o),
      o
    );
  }
  var De = function (e, t, i, s) {
    return new (i || (i = Promise))(function (n, r) {
      function o(e) {
        try {
          l(s.next(e));
        } catch (e) {
          r(e);
        }
      }
      function a(e) {
        try {
          l(s.throw(e));
        } catch (e) {
          r(e);
        }
      }
      function l(e) {
        var t;
        e.done
          ? n(e.value)
          : ((t = e.value),
            t instanceof i
              ? t
              : new i(function (e) {
                  e(t);
                })).then(o, a);
      }
      l((s = s.apply(e, t || [])).next());
    });
  };
  const ke = 8e3;
  function He(e) {
    return e instanceof HTMLIFrameElement;
  }
  function Le({
    container: e,
    enableScaleOut: t,
    postBidInvocations: i,
    logger: s,
    initialStorySlides: n = [],
    stopAfterFirstCycle: r = !1,
    showProgressBar: o = !1,
    onCycleComplete: a,
  }) {
    let l,
      c,
      h = !1;
    const d = E(),
      u = (e) =>
        new Promise((t) => {
          const i = () => {
            (l = void 0), t();
          };
          (l = { remaining: e, startedAt: Date.now(), id: 0, resolve: i }),
            I() || (l.id = window.setTimeout(i, e));
        }),
      { container: p, bars: m } = o
        ? (function (e, t) {
            const i = document.createElement("div");
            i.style.cssText =
              "\n        position: absolute;\n        top: .5em;\n        left: .5em;\n        right: .5em;\n        display: flex;\n        box-sizing: border-box;\n        gap: 5px;\n        z-index: 2;\n        opacity: 1;\n        transition: opacity .5s ease-out;\n        visibility: hidden;\n    ";
            const s = [];
            for (let e = 0; e < t; e++) {
              const e = document.createElement("div");
              e.style.cssText =
                "\n            background: rgb(0 0 0 / 35%);\n            border-radius: 2px;\n            flex: 1 1 0;\n            height: 2px;\n            overflow: hidden;\n            position: relative;\n            box-shadow: 0 0 1px rgb(0 0 0 / 30%);\n            transition: flex-grow .3s ease-out, opacity .3s ease-out;\n            opacity: 1;\n        ";
              const t = document.createElement("div");
              (t.style.cssText =
                "\n            position: absolute;\n            top: 0;\n            left: 0;\n            width: 100%;\n            height: 100%;\n            background: #fff;\n        "),
                e.appendChild(t),
                i.appendChild(e),
                s.push({ element: e, filler: t });
            }
            return e.appendChild(i), { container: i, bars: s };
          })(e, 2)
        : { container: void 0, bars: [] },
      g = () => {
        p && (p.style.visibility = "visible");
      },
      f = () => {
        p &&
          (m.forEach(({ filler: e }) => {
            (e.style.transform = "translateX(-100%)"),
              (e.style.transition = "none");
          }),
          p.scrollHeight);
      },
      v = (e, t) => {
        p &&
          ((c = { index: e, remaining: t, startedAt: Date.now() }),
          I() ||
            ((m[e].filler.style.transform = "translateX(0)"),
            (m[e].filler.style.transition = `transform ${t}ms linear`)));
      },
      w = (e) => {
        m[e] &&
          ((m[e].element.style.flexGrow = "0"),
          (m[e].element.style.opacity = "0"));
      },
      y = () => {
        I()
          ? (() => {
              if (
                (l &&
                  (window.clearTimeout(l.id),
                  (l.remaining = Math.max(
                    0,
                    l.remaining - (Date.now() - l.startedAt)
                  ))),
                c)
              ) {
                c.remaining = Math.max(
                  0,
                  c.remaining - (Date.now() - c.startedAt)
                );
                const { filler: e } = m[c.index],
                  t = window.getComputedStyle(e).transform;
                (e.style.transition = "none"),
                  (e.style.transform = "none" === t ? "translateX(-100%)" : t);
              }
            })()
          : (() => {
              if (c) {
                const { filler: e } = m[c.index];
                e.scrollHeight,
                  (c.startedAt = Date.now()),
                  (e.style.transition = `transform ${c.remaining}ms linear`),
                  (e.style.transform = "translateX(0)");
              }
              l &&
                ((l.startedAt = Date.now()),
                (l.id = window.setTimeout(l.resolve, l.remaining)));
            })();
      };
    return (
      d && document.addEventListener(d, y),
      (() => {
        De(this, void 0, void 0, function* () {
          try {
            let o = 0,
              l = 0;
            const c = n;
            let d = 2;
            for (i.length > 0 && g(), f(); !h; ) {
              const n = 0 === o ? 3e3 : ke;
              0 === l && o > 0 && f(), v(l, n);
              if (c.length === d) {
                if ((yield u(n), h)) break;
              } else {
                if ((yield u(n - 1500), h)) break;
                const r = i.shift();
                if (r) {
                  const i = Ve(r, e, !1, t, s);
                  c.push({ type: "additional", creative: r, container: i }),
                    g();
                } else (d = c.length), w(d);
                if ((yield u(1500), h)) break;
              }
              const p = l,
                m = (l + 1) % c.length,
                y = c[p],
                b = c[m];
              if (
                ((y.container.style.zIndex = "-1"),
                He(y.container.firstChild) &&
                  (y.container.firstChild.style.pointerEvents = "none"),
                (y.container.style.opacity = "0"),
                (b.container.style.zIndex = "1"),
                He(b.container.firstChild) &&
                  (b.container.firstChild.style.pointerEvents = "auto"),
                (b.container.style.opacity = "1"),
                (h =
                  "additional" === b.type &&
                  (3 === b.creative.formatId || 19 === b.creative.formatId)),
                r && c.length === d && m === c.length - 1)
              ) {
                if ((v(m, ke), yield u(ke), h)) break;
                null == a || a(), (h = !0);
              }
              (l = m), (o = o === Number.MAX_SAFE_INTEGER ? 0 : o + 1);
            }
          } catch (e) {
            s.error(e);
          }
        });
      })(),
      () => {
        if (((h = !0), l)) {
          window.clearTimeout(l.id);
          const e = l;
          (l = void 0), e.resolve();
        }
        d && document.removeEventListener(d, y);
      }
    );
  }
  var _e = function (e, t, i, s) {
    return new (i || (i = Promise))(function (n, r) {
      function o(e) {
        try {
          l(s.next(e));
        } catch (e) {
          r(e);
        }
      }
      function a(e) {
        try {
          l(s.throw(e));
        } catch (e) {
          r(e);
        }
      }
      function l(e) {
        var t;
        e.done
          ? n(e.value)
          : ((t = e.value),
            t instanceof i
              ? t
              : new i(function (e) {
                  e(t);
                })).then(o, a);
      }
      l((s = s.apply(e, t || [])).next());
    });
  };
  function Re(e, t, i, s, n, r, o) {
    return _e(this, void 0, void 0, function* () {
      const a = [
        ...(yield Ae(
          s,
          Object.assign(Object.assign({}, t), { contentId: 1 }),
          o,
          { exclude: i.read() }
        )).invocations,
      ];
      a.length < 2 &&
        (yield (function (e, t) {
          return Me(this, void 0, void 0, function* () {
            let i,
              s,
              n = 0;
            do {
              null != t.delay && (yield Ce(t.delay)), (s = null);
              try {
                i = yield e();
              } catch (e) {
                s = e;
              } finally {
                n++;
              }
            } while (n < t.maxAttempts && (null != s || (null != t.while && t.while(i))));
            return i;
          });
        })(
          () =>
            _e(this, void 0, void 0, function* () {
              const { invocations: e } = yield Ae(
                s,
                Object.assign(Object.assign({}, t), { contentId: 1 }),
                o,
                { exclude: i.read() }
              );
              for (const t of e) a.push(t);
            }),
          {
            maxAttempts: 5,
            delay: 0 === a.length ? 2e3 : 1e3,
            while: () => a.length < 2,
          }
        ));
      const l = a.shift();
      if (null != l) {
        switch (l.formatId) {
          case 2:
          case 6: {
            const t = Ve(l, e, !0, n, r);
            Le({
              container: e,
              enableScaleOut: n,
              postBidInvocations: a,
              logger: r,
              initialStorySlides: [
                { type: "additional", container: t, creative: l },
              ],
            });
            break;
          }
          case 3:
          case 19: {
            const t = a.findIndex((e) => 2 === e.formatId);
            if (-1 != t) {
              const i = a[t];
              a.splice(t, 1);
              const s = Ve(i, e, !0, n, r);
              a.unshift(l),
                Le({
                  container: e,
                  enableScaleOut: n,
                  postBidInvocations: a,
                  logger: r,
                  initialStorySlides: [
                    { type: "additional", container: s, creative: i },
                  ],
                });
            } else Ve(l, e, !0, n, r);
            break;
          }
        }
        return !0;
      }
      return !1;
    });
  }
  class Be {
    constructor() {
      this.cleanups = [];
    }
    add(e) {
      this.cleanups.push(e);
    }
    setTimeout(e, t) {
      const i = window.setTimeout(e, t);
      this.add(() => clearTimeout(i));
    }
    dispose() {
      for (const e of this.cleanups) e();
      this.cleanups.length = 0;
    }
  }
  class Ne extends se {
    constructor() {
      super(...arguments), (this.id = 697);
    }
  }
  class Ue extends se {
    constructor() {
      super(...arguments), (this.id = 703);
    }
  }
  class We extends se {
    constructor() {
      super(...arguments), (this.id = 700);
    }
  }
  class je extends se {
    constructor() {
      super(...arguments), (this.id = 747);
    }
  }
  class $e extends se {
    constructor() {
      super(...arguments), (this.id = 311);
    }
  }
  class ze extends se {
    constructor() {
      super(...arguments), (this.id = 312);
    }
  }
  class qe extends se {
    constructor() {
      super(...arguments), (this.id = 313);
    }
  }
  class Je extends se {
    constructor() {
      super(...arguments), (this.id = 467);
    }
  }
  class Ye extends se {
    constructor() {
      super(...arguments), (this.id = 337);
    }
  }
  class Xe extends se {
    constructor() {
      super(...arguments), (this.id = 751);
    }
  }
  class Ge extends se {
    constructor() {
      super(...arguments), (this.id = 771);
    }
  }
  class Ke extends se {
    constructor() {
      super(...arguments), (this.id = 1), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class Qe extends se {
    constructor() {
      super(...arguments), (this.id = 766), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class Ze extends se {
    constructor() {
      super(...arguments), (this.id = 767), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class et extends se {
    constructor() {
      super(...arguments), (this.id = 768), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class tt extends se {
    constructor() {
      super(...arguments), (this.id = 287), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class it extends se {
    constructor() {
      super(...arguments), (this.id = 128), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class st extends se {
    constructor() {
      super(...arguments), (this.id = 464), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class nt extends se {
    constructor() {
      super(...arguments), (this.id = 637);
    }
  }
  class rt extends se {
    constructor() {
      super(...arguments), (this.id = 2);
    }
  }
  class ot extends se {
    constructor() {
      super(...arguments), (this.id = 759);
    }
  }
  class at extends se {
    constructor() {
      super(...arguments), (this.id = 760);
    }
  }
  class lt extends se {
    constructor() {
      super(...arguments), (this.id = 752);
    }
  }
  class ct extends se {
    constructor() {
      super(...arguments), (this.id = 731);
    }
  }
  class ht extends d {
    constructor(e, t) {
      super("OMID sessionError"),
        (this.containerMessage = t),
        (this.code = "omid-session-error"),
        (this.errorType = String(e).toLowerCase());
    }
    isVideo() {
      return "video" === this.errorType;
    }
    getAttachments() {
      return [
        {
          type: "omid",
          errorType: this.errorType,
          sessionError: this.containerMessage,
        },
      ];
    }
  }
  class dt extends se {
    constructor() {
      super(...arguments), (this.id = 783), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class ut extends se {
    constructor() {
      super(...arguments), (this.id = 785), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class pt extends se {
    constructor() {
      super(...arguments), (this.id = 786), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class mt extends se {
    constructor() {
      super(...arguments), (this.id = 784), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class gt extends se {
    constructor() {
      super(...arguments), (this.id = 802), (this.canBeFiredMultipleTimes = !1);
    }
  }
  var ft = function (e, t, i, s) {
    return new (i || (i = Promise))(function (n, r) {
      function o(e) {
        try {
          l(s.next(e));
        } catch (e) {
          r(e);
        }
      }
      function a(e) {
        try {
          l(s.throw(e));
        } catch (e) {
          r(e);
        }
      }
      function l(e) {
        var t;
        e.done
          ? n(e.value)
          : ((t = e.value),
            t instanceof i
              ? t
              : new i(function (e) {
                  e(t);
                })).then(o, a);
      }
      l((s = s.apply(e, t || [])).next());
    });
  };
  class vt {
    constructor(
      e = document,
      t = window,
      i = "https://onetag-cdn.com/res/omid-verification-client-v1.js"
    ) {
      (this.doc = e), (this.win = t), (this.scriptUrl = i);
    }
    load() {
      return ft(this, void 0, void 0, function* () {
        yield this.loadScript();
        const e = this.resolveCtor();
        return e ? new e() : void 0;
      });
    }
    loadScript() {
      return new Promise((e, t) => {
        const i = this.doc.createElement("script");
        (i.src = this.scriptUrl),
          (i.onload = () => e()),
          (i.onerror = () =>
            t(new Error("Failed to load OMID verification client script"))),
          this.doc.head.appendChild(i);
      });
    }
    resolveCtor() {
      const e = this.win.OmidVerificationClient;
      if (!e) return;
      const t = Object.keys(e);
      return t.length > 0 ? e[t[0]] : void 0;
    }
  }
  class wt {
    constructor(e, t, i = 50) {
      (this.onFired = t),
        (this.minPercentageInView = i),
        (this.timerId = null),
        (this.fired = !1),
        (this.durationMs = e);
    }
    setDuration(e) {
      this.durationMs = e;
    }
    update(e) {
      this.fired ||
        (e >= this.minPercentageInView
          ? null === this.timerId &&
            (this.timerId = setTimeout(() => {
              (this.fired = !0), (this.timerId = null), this.onFired();
            }, this.durationMs))
          : null !== this.timerId &&
            (clearTimeout(this.timerId), (this.timerId = null)));
    }
    stop() {
      null !== this.timerId &&
        (clearTimeout(this.timerId), (this.timerId = null));
    }
  }
  var yt = function (e, t, i, s) {
    return new (i || (i = Promise))(function (n, r) {
      function o(e) {
        try {
          l(s.next(e));
        } catch (e) {
          r(e);
        }
      }
      function a(e) {
        try {
          l(s.throw(e));
        } catch (e) {
          r(e);
        }
      }
      function l(e) {
        var t;
        e.done
          ? n(e.value)
          : ((t = e.value),
            t instanceof i
              ? t
              : new i(function (e) {
                  e(t);
                })).then(o, a);
      }
      l((s = s.apply(e, t || [])).next());
    });
  };
  class bt extends v {
    constructor(e, t = new vt(), i = !1) {
      super(),
        (this.loader = t),
        (this.adEventManager = null),
        (this.viewabilityTracker = null),
        (this.sessionStarted = !1),
        (this.mediaType = null),
        (this.measurableImpressionFired = !1),
        (this.lastPercentageInView = 0),
        (this.logger = e
          .fork()
          .integrate({ type: "renderer", context: "OmidHandler" })),
        (this.logFailure = i
          ? (e) => this.logger.fatal(e)
          : (e) => this.logger.warn(e)),
        (this.logUnsupportedEnvironment = i
          ? (e) => this.logger.fatal(e)
          : (e) => this.logger.debug(e));
    }
    integrateLogContext(e, t) {
      return (
        this.logger.integrate(e),
        null != t && (this.logger.maxLogLevel = t),
        this
      );
    }
    start(e) {
      return yt(this, void 0, void 0, function* () {
        let t;
        try {
          t = yield this.loader.load();
        } catch (e) {
          return void this.logger.warn(
            new Error(`Failed to load OMID verification client: ${e.message}`)
          );
        }
        if (t)
          if (t.isSupported())
            try {
              t.registerSessionObserver((t) => {
                switch (t.type) {
                  case "sessionStart":
                    this.onSessionStart(t, e);
                    break;
                  case "sessionError":
                    this.onSessionError(t);
                    break;
                  case "sessionFinish":
                    this.onSessionFinish();
                }
              }, "onetag.com-omid"),
                t.addEventListener("impression", () => {
                  var e;
                  null === (e = this.adEventManager) ||
                    void 0 === e ||
                    e.fire(new ut()),
                    this.onImpression(),
                    this.emit("billableOmidImpression");
                }),
                t.addEventListener("geometryChange", (e) => {
                  var t, i, s, n;
                  (this.lastPercentageInView =
                    null !==
                      (s =
                        null ===
                          (i =
                            null === (t = e.data) || void 0 === t
                              ? void 0
                              : t.adView) || void 0 === i
                          ? void 0
                          : i.percentageInView) && void 0 !== s
                      ? s
                      : 0),
                    null === (n = this.viewabilityTracker) ||
                      void 0 === n ||
                      n.update(this.lastPercentageInView);
                }),
                this.logger.trace("OMID Handler started successfully");
            } catch (e) {
              this.logger.fatal(
                `Failed to initialize OMID handler: ${e.message}`
              );
            }
          else
            this.logUnsupportedEnvironment(
              new Error(
                "OMID verification client reports unsupported environment"
              )
            );
        else
          this.logFailure(
            new Error(
              "OMID verification client script loaded but no constructor found on window.OmidVerificationClient"
            )
          );
      });
    }
    onSessionStart(e, t) {
      var i;
      this.sessionStarted ||
        ((this.sessionStarted = !0),
        (this.mediaType = e.data.mediaType),
        this.logger.integrate({
          type: "context",
          omidEnvironment: e.data.context.environment,
          appId:
            null === (i = e.data.context.app) || void 0 === i
              ? void 0
              : i.appId,
        }),
        (this.adEventManager = t(e)),
        this.adEventManager &&
          ("video" !== this.mediaType && this.startViewabilityTracking(1e3),
          this.adEventManager.fire(new dt())));
    }
    onImpression() {
      "video" === this.mediaType &&
        !this.measurableImpressionFired &&
        this.adEventManager &&
        ((this.measurableImpressionFired = !0),
        this.adEventManager.fire(new gt()),
        this.startViewabilityTracking(2e3));
    }
    startViewabilityTracking(e) {
      (this.viewabilityTracker = new wt(e, () => {
        this.adEventManager.fire(new pt());
      })),
        this.viewabilityTracker.update(this.lastPercentageInView);
    }
    onSessionError(e) {
      const { errorType: t, message: i } = e.data,
        s = new ht(t, i);
      s.isVideo() ? this.logger.debug(s) : this.logger.warn(s);
    }
    onSessionFinish() {
      var e;
      this.logger.trace("OMID sessionFinish received"),
        null === (e = this.adEventManager) || void 0 === e || e.fire(new mt());
    }
  }
  class xt extends se {
    constructor() {
      super(...arguments), (this.id = 782), (this.canBeFiredMultipleTimes = !1);
    }
  }
  const It = window.document.currentScript;
  class Et {
    constructor(e, t) {
      (this.config = e),
        (this.logger = t
          .fork()
          .integrate({ type: "renderer", context: "InfoLinksTag" })),
        (this.adEventManager = new Se(e.ipu, this.logger));
    }
    start() {
      try {
        const {
          purl: e,
          gppData: t,
          usPrivacy: i,
          ad: s,
          bl: n,
          width: r,
          height: o,
          bcat: a,
        } = this.config;
        window.infolinks_config = {
          pid: 3443816,
          purl: e,
          gppData: t,
          usPrivacy: i,
          iframe: !0,
          inplace_slot: {
            ad: s,
            width: r,
            height: o,
            plugin_version: "oneTag",
            bl: n,
            keepFrame: !0,
          },
          bcat: null != a ? a : [],
        };
        const l = window.document.createElement("script");
        (l.type = "text/javascript"),
          (l.src = "https://resources.infolinks.com/js/infolinks_main.js"),
          It &&
            (It.insertAdjacentElement("afterend", l),
            this.adEventManager.fire(new xt()));
      } catch (e) {
        this.logger.warn(e);
      }
    }
  }
  var Tt = function (e, t, i, s) {
    return new (i || (i = Promise))(function (n, r) {
      function o(e) {
        try {
          l(s.next(e));
        } catch (e) {
          r(e);
        }
      }
      function a(e) {
        try {
          l(s.throw(e));
        } catch (e) {
          r(e);
        }
      }
      function l(e) {
        var t;
        e.done
          ? n(e.value)
          : ((t = e.value),
            t instanceof i
              ? t
              : new i(function (e) {
                  e(t);
                })).then(o, a);
      }
      l((s = s.apply(e, t || [])).next());
    });
  };
  class Pt {
    get win() {
      var e;
      return null !== (e = this.topWindow) && void 0 !== e ? e : top;
    }
    constructor(e, t) {
      (this.size = e),
        (this.element = t),
        (this.bottomBarH = 0),
        (this.disposed = !1),
        (this.layout = this.layout.bind(this));
    }
    canRender(e) {
      return Tt(this, void 0, void 0, function* () {
        return (
          yield T(),
          (this.topWindow = top),
          !!this.isMobile() &&
            !(
              "undefined" == typeof CSS ||
              !CSS.supports ||
              !CSS.supports("overflow", "clip")
            ) &&
            e
        );
      });
    }
    apply() {
      return Tt(this, void 0, void 0, function* () {
        (this.inlineStyle = this.element.style.cssText),
          yield T(),
          (this.topWindow = top),
          this.render(),
          this.topWindow.addEventListener("resize", this.layout),
          this.layout();
      });
    }
    dispose() {
      this.disposed ||
        ((this.disposed = !0),
        this.topWindow &&
          this.topWindow.removeEventListener("resize", this.layout),
        this.clipBox &&
          ((this.clipBox.style.cssText = this.clipBoxStyle || ""),
          delete this.clipBox,
          delete this.clipBoxStyle,
          delete this.panelOffset),
        this.panel &&
          this.panel.parentNode &&
          this.panel.parentNode.removeChild(this.panel),
        delete this.panel,
        delete this.topLabel,
        delete this.bottomLabel,
        void 0 !== this.inlineStyle &&
          ((this.element.style.cssText = this.inlineStyle),
          delete this.inlineStyle));
    }
    render() {
      const e = this.element.parentElement,
        t = this.element.ownerDocument;
      (this.clipBox = e),
        (this.clipBoxStyle = e.style.cssText),
        (e.style.height = "calc(100dvh + (100dvh * 0.5))"),
        (e.style.overflowX = "visible"),
        (e.style.overflowY = "clip"),
        (e.style.position = "relative");
      const i = t.createElement("div");
      (i.style.cssText = [
        "position: absolute",
        "top: 0",
        "height: 100%",
        "width: 100vw",
        "margin: 0",
        "background: #FFFFFF",
      ].join("; ")),
        (this.topLabel = this.createLabel(t, "Advertisement", "top")),
        (this.bottomLabel = this.createLabel(
          t,
          "Scroll to continue with content",
          "bottom"
        )),
        i.appendChild(this.topLabel),
        i.appendChild(this.bottomLabel),
        e.insertBefore(i, this.element),
        (this.panel = i);
    }
    layout() {
      var e;
      const t = this.panel;
      if (!t) return;
      const [i, s] = this.size,
        n = this.topLabel.offsetHeight,
        r = this.bottomLabel.offsetHeight;
      r !== this.bottomBarH &&
        ((this.bottomBarH = r),
        (this.bottomLabel.style.top = `calc(100dvh - ${r}px)`));
      const o = Math.round(
        t.getBoundingClientRect().left +
          (null !== (e = this.panelOffset) && void 0 !== e ? e : 0)
      );
      o !== this.panelOffset &&
        ((this.panelOffset = o), (t.style.left = -o + "px"));
      const a = Math.max(n, r),
        l = Math.max(1, this.getViewportHeight() - 2 * a),
        c = Math.min(this.getViewportWidth() / i, l / s);
      this.element.style.cssText = [
        `width: ${i}px`,
        `height: ${s}px`,
        "display: block",
        "position: sticky",
        "top: 0",
        `margin: 0 auto calc(50dvh - ${s - (s * c) / 2 - r}px) calc(50vw - ${
          i / 2
        }px - ${this.panelOffset}px)`,
        "z-index: 0",
        "transform-origin: top center",
        `transform: translateY(calc(50dvh - ${(s * c) / 2}px)) scale(${c})`,
      ].join("; ");
    }
    createLabel(e, t, i) {
      const s = e.createElement("div");
      return (
        (s.textContent = t),
        (s.style.cssText = [
          "position: sticky",
          "z-index: 1",
          "left: 0",
          "right: 0",
          ...("top" === i ? ["top: 0"] : []),
          "padding: 7px 8px",
          "margin: 0",
          "text-align: center",
          "color: #fff",
          "background: #000",
          "font-family: Arial, Helvetica, sans-serif",
          "font-size: 12px",
          "line-height: 1",
          "letter-spacing: 1px",
          "text-transform: uppercase",
          "box-sizing: border-box",
          "pointer-events: none",
        ].join("; ")),
        s
      );
    }
    isMobile() {
      const e = new ee(this.win.navigator.userAgent).isTouchDevice(),
        t = Math.min(this.getViewportWidth(), this.getViewportHeight());
      return e && t <= 768;
    }
    getViewportWidth() {
      return (
        this.win.document.documentElement.clientWidth || this.win.innerWidth
      );
    }
    getViewportHeight() {
      var e, t;
      return null !==
        (t =
          null === (e = this.win.visualViewport) || void 0 === e
            ? void 0
            : e.height) && void 0 !== t
        ? t
        : this.win.innerHeight;
    }
  }
  var St = function (e, t, i, s) {
    return new (i || (i = Promise))(function (n, r) {
      function o(e) {
        try {
          l(s.next(e));
        } catch (e) {
          r(e);
        }
      }
      function a(e) {
        try {
          l(s.throw(e));
        } catch (e) {
          r(e);
        }
      }
      function l(e) {
        var t;
        e.done
          ? n(e.value)
          : ((t = e.value),
            t instanceof i
              ? t
              : new i(function (e) {
                  e(t);
                })).then(o, a);
      }
      l((s = s.apply(e, t || [])).next());
    });
  };
  class Ct {
    constructor(e, t, i = window) {
      (this.size = e),
        (this.element = t),
        (this.win = i),
        (this.savedSlotStyle = null),
        (this.savedElementStyle = null),
        (this.disposed = !1),
        (this.targetPosition = 0),
        (this.appliedPosition = 0),
        (this.seeded = !1),
        (this.onScroll = this.onScroll.bind(this)),
        (this.update = this.update.bind(this)),
        (this.onIntersection = this.onIntersection.bind(this)),
        (this.tick = this.tick.bind(this)),
        (this.isMobile = this.detectMobile());
    }
    apply() {
      return St(this, void 0, void 0, function* () {
        yield T();
        const e = yield this.resolveSlot();
        if (!this.disposed && e) {
          if (
            ((this.slot = e),
            (this.savedSlotStyle = e.getAttribute("style")),
            (this.savedElementStyle = this.element.getAttribute("style")),
            (e.style.overflow = "hidden"),
            (this.element.style.flex = "0 0 auto"),
            (this.element.style.height = `${this.size[1]}px`),
            (this.element.style.willChange = "transform"),
            "function" == typeof this.win.IntersectionObserver)
          ) {
            const t = this.isMobile
              ? Ct.THRESHOLD_STEPS
              : Ct.DESKTOP_THRESHOLD_STEPS;
            return (
              (this.observer = new this.win.IntersectionObserver(
                this.onIntersection,
                { threshold: this.buildThresholds(t) }
              )),
              this.observer.observe(e),
              void this.applyPosition(0)
            );
          }
          this.win.addEventListener("scroll", this.onScroll, { passive: !0 }),
            this.update();
        }
      });
    }
    dispose() {
      (this.disposed = !0),
        this.observer && (this.observer.disconnect(), delete this.observer),
        this.win.removeEventListener("scroll", this.onScroll),
        void 0 !== this.updateHandle &&
          (this.win.cancelAnimationFrame(this.updateHandle),
          delete this.updateHandle),
        void 0 !== this.tweenHandle &&
          (this.win.cancelAnimationFrame(this.tweenHandle),
          delete this.tweenHandle),
        this.slot &&
          (this.restoreStyle(this.slot, this.savedSlotStyle), delete this.slot),
        this.restoreStyle(this.element, this.savedElementStyle),
        (this.savedSlotStyle = null),
        (this.savedElementStyle = null);
    }
    onIntersection(e) {
      if (this.disposed || 0 === e.length) return;
      const t = this.positionFromEntry(e[e.length - 1]);
      this.applyPosition(t);
    }
    onScroll() {
      void 0 === this.updateHandle &&
        (this.updateHandle = this.win.requestAnimationFrame(() => {
          delete this.updateHandle, this.update();
        }));
    }
    update() {
      if (!this.slot) return;
      const e = this.slot.getBoundingClientRect(),
        t = e.height;
      if (t <= 0) return;
      const i = this.win.innerHeight,
        s = Math.max(0, e.bottom - i),
        n = Math.max(0, -e.top),
        r = this.clamp((s - n) / t, -1, 1);
      this.applyPosition(r);
    }
    positionFromEntry(e) {
      const t = e.boundingClientRect,
        i = e.intersectionRect,
        s = t.height;
      if (s <= 0) return 0;
      if (!(e.isIntersecting || i.height > 0)) {
        return t.top <= -s ? -1 : 1;
      }
      const n = s - i.height,
        r = i.top - t.top > t.bottom - i.bottom ? -n : n;
      return this.clamp(r / s, -1, 1);
    }
    buildThresholds(e) {
      const t = [];
      for (let i = 0; i <= e; i++) t.push(i / e);
      return t;
    }
    applyPosition(e) {
      return (
        (this.targetPosition = e),
        this.seeded
          ? this.isMobile
            ? ((this.appliedPosition = e), void this.writePosition(e))
            : void this.startTween()
          : ((this.seeded = !0),
            (this.appliedPosition = e),
            void this.writePosition(e))
      );
    }
    startTween() {
      void 0 !== this.tweenHandle ||
        this.disposed ||
        (this.tweenHandle = this.win.requestAnimationFrame(this.tick));
    }
    tick() {
      if (((this.tweenHandle = void 0), this.disposed)) return;
      const e = this.targetPosition - this.appliedPosition,
        t = 0.5 / Math.max(1, this.size[1]);
      if (Math.abs(e) <= t)
        return (
          (this.appliedPosition = this.targetPosition),
          void this.writePosition(this.appliedPosition)
        );
      (this.appliedPosition += e * Ct.DESKTOP_LERP),
        this.writePosition(this.appliedPosition),
        (this.tweenHandle = this.win.requestAnimationFrame(this.tick));
    }
    writePosition(e) {
      const t = -e * this.size[1];
      this.element.style.transform = `translateY(${t.toFixed(2)}px)`;
    }
    resolveSlot() {
      return St(this, void 0, void 0, function* () {
        for (let e = 0; e < 10; e++) {
          const e = this.element.parentElement;
          if (e) return e;
          if ((yield this.nextFrame(), this.disposed)) return null;
        }
        return this.element.parentElement;
      });
    }
    nextFrame() {
      return new Promise((e) => {
        "function" == typeof this.win.requestAnimationFrame
          ? this.win.requestAnimationFrame(() => e())
          : this.win.setTimeout(e, 16);
      });
    }
    detectMobile() {
      try {
        const e = (this.win.navigator && this.win.navigator.userAgent) || "";
        return /android|iphone|ipad|ipod|iemobile|blackberry|bada|windows phone|webos|opera mini|mobile/i.test(
          e
        );
      } catch (e) {
        return !1;
      }
    }
    restoreStyle(e, t) {
      null == t ? e.removeAttribute("style") : e.setAttribute("style", t);
    }
    clamp(e, t, i) {
      return Math.max(t, Math.min(i, e));
    }
  }
  (Ct.THRESHOLD_STEPS = 2500),
    (Ct.DESKTOP_THRESHOLD_STEPS = 100),
    (Ct.DESKTOP_LERP = 0.1);
  const Mt = Ct;
  class Ft {
    constructor(e, t, i) {
      (this.height = e), (this.element = t), (this.context = i);
    }
    getTopmostElement() {
      var e;
      return null !== (e = this.context.getTopmostIFrame()) && void 0 !== e
        ? e
        : this.element;
    }
    bust() {
      const e = [],
        t = this.context.getFrameElement(),
        i = [
          ...[
            ...(t instanceof HTMLIFrameElement ? [t] : []),
            ...this.context.getFriendlyFrames(),
          ],
          this.element,
        ];
      for (const t of i)
        e.push({ element: t, cssHeight: t.style.height }),
          (t.style.height = `${this.height}px`);
      this.snapshot = { ancestors: e };
    }
    dispose() {
      if (this.snapshot) {
        for (const e of this.snapshot.ancestors)
          e.element.style.height = e.cssHeight;
        delete this.snapshot;
      }
    }
  }
  class Ot extends v {
    constructor(e, t) {
      super(),
        (this.element = e),
        (this.observer = t((e) => {
          try {
            Array.from(e)
              .filter((e) => "childList" === e.type)
              .some((e) =>
                Array.from(e.removedNodes).some(
                  (e) => e === this.element || e.contains(this.element)
                )
              ) && (this.emit("removed"), this.dispose());
          } catch (e) {
            this.dispose();
          }
        }));
    }
    start() {
      this.isDetached()
        ? this.onRemoved()
        : ((this.interval = window.setInterval(() => {
            this.isDetached() && this.onRemoved();
          }, 600)),
          this.observer.observe(this.element.parentNode, {
            childList: !0,
            subtree: !1,
          }));
    }
    dispose() {
      this.interval &&
        (window.clearInterval(this.interval), delete this.interval),
        this.observer.disconnect(),
        this.clear();
    }
    isDetached() {
      const e = this.element;
      return !e.ownerDocument || !e.isConnected || !e.parentNode;
    }
    onRemoved() {
      this.emit("removed"), this.dispose();
    }
  }
  class At {
    static getCurrent() {
      return new At({ window });
    }
    constructor(e = { window }, t = null) {
      (this.source = e), (this.fallbackOrigin = t);
    }
    getType() {
      return this.isDetached()
        ? "DETACHED_FRAME"
        : this.isTopmost()
        ? "TOPMOST"
        : this.isFriendly()
        ? "FRIENDLY_FRAME"
        : this.isOpaque()
        ? "OPAQUE_FRAME"
        : "UNFRIENDLY_FRAME";
    }
    getWindow() {
      return this.source.window;
    }
    getDepth() {
      if (this.isDetached()) return -1;
      let e = 0,
        t = this.source.window;
      for (; t !== t.top; ) {
        if ((e++, null == t.parent)) return -1;
        t = t.parent;
      }
      return e;
    }
    isDetached() {
      return (
        null == this.source.window.top || null == this.source.window.parent
      );
    }
    isTopmost() {
      return (
        !this.isDetached() && this.source.window.top === this.source.window
      );
    }
    isNested() {
      return !this.isTopmost();
    }
    isAccessible() {
      try {
        return this.source.window.location.href, !0;
      } catch (e) {
        return !1;
      }
    }
    isFriendly() {
      return (
        !this.isDetached() &&
        (!!this.isTopmost() ||
          (this.isAccessible() &&
            this.getAncestors().every((e) => e.isAccessible())))
      );
    }
    isUnfriendly() {
      return !this.isFriendly();
    }
    isOpaque() {
      return this.isUnfriendly() && "null" === this.source.window.origin;
    }
    getOrigin() {
      return this.isAccessible()
        ? this.source.window.location.origin
        : this.fallbackOrigin;
    }
    getParent() {
      return this.isDetached() || this.isTopmost()
        ? null
        : new At(
            { window: this.source.window.parent },
            this.getAncestorOrigins()[0]
          );
    }
    getAncestorOrigins() {
      return this.isAccessible() && this.source.window.location.ancestorOrigins
        ? (function (e) {
            const t = [];
            for (let i = 0; i < e.length; i++) t.push(e[i]);
            return t;
          })(this.source.window.location.ancestorOrigins)
        : [];
    }
    getAncestors() {
      if (this.isDetached() || this.isTopmost()) return [];
      const e = this.getAncestorOrigins();
      let t = 0,
        i = this.source.window.parent;
      const s = [];
      for (; null != i && i !== i.top; )
        s.push(new At({ window: i }, e[t])), (i = i.parent), t++;
      return null != i && s.push(new At({ window: i }, e[t])), s;
    }
    getFrameElement() {
      return !this.isDetached() && this.isNested()
        ? this.source.window.frameElement
        : null;
    }
    getTopmostContext() {
      if (this.isDetached() || this.isTopmost()) return this;
      const e = this.getAncestors();
      return 0 === e.length ? null : e[e.length - 1];
    }
    getTopmostOrigin() {
      const e = this.getTopmostContext();
      return e ? e.getOrigin() : null;
    }
    getTopmostFriendlyContext() {
      let e = this;
      for (const t of this.getAncestors()) {
        if (!t.isAccessible()) break;
        e = t;
      }
      return e;
    }
    getTopmostIFrame() {
      if (this.isDetached() || this.isTopmost() || this.isUnfriendly())
        return null;
      let e = null;
      if (1 === this.getDepth()) e = this.getFrameElement();
      else {
        const t = this.getAncestors().slice(0, -1);
        t.length > 0 && (e = t[t.length - 1].getFrameElement());
      }
      return null != e && At.isHTMLFrameElement(e) ? e : null;
    }
    getFriendlyFrames() {
      const e = [];
      for (const t of this.getAncestors()) {
        if (!t.isAccessible()) break;
        {
          const i = t.getFrameElement();
          null != i && At.isHTMLFrameElement(i) && e.push(i);
        }
      }
      return e;
    }
    getTopmostFriendlyWindow() {
      return this.getTopmostFriendlyContext().getWindow();
    }
    getTopmostFriendlyHref() {
      return this.getTopmostFriendlyWindow().location.href;
    }
    toJSON() {
      return {
        localReferrer: this.getWindow().document.referrer,
        localFrameUrl: this.getWindow().location.href,
        topmostFriendlyHref: this.getTopmostFriendlyHref(),
        topmostOrigin: this.getTopmostOrigin(),
        nesting: { depth: this.getDepth(), type: this.getType() },
      };
    }
    static isHTMLFrameElement(e) {
      return "iframe" === e.tagName.toLowerCase();
    }
  }
  class Vt extends se {
    constructor() {
      super(...arguments), (this.id = 794);
    }
  }
  class Dt extends se {
    constructor() {
      super(...arguments), (this.id = 797);
    }
  }
  class kt extends se {
    constructor() {
      super(...arguments), (this.id = 795);
    }
  }
  class Ht extends se {
    constructor() {
      super(...arguments), (this.id = 796);
    }
  }
  class Lt extends se {
    constructor() {
      super(...arguments), (this.id = 800);
    }
  }
  class _t {
    static known(e, t) {
      return new _t(t, e);
    }
    static declaredByCreative(e, t = 1e4) {
      const i = new _t(e, null);
      return (
        (i.timeoutId = window.setTimeout(() => {
          null === i.element &&
            e.warn(
              new Error(
                `No measurement target declared by the creative within ${t}ms`
              )
            );
        }, t)),
        i
      );
    }
    constructor(e, t) {
      (this.logger = e),
        (this.element = t),
        (this.listeners = []),
        (this.timeoutId = null);
    }
    get() {
      return this.element;
    }
    onceAvailable(e) {
      null !== this.element
        ? this.notify(e, this.element)
        : this.listeners.push(e);
    }
    dispose() {
      (this.listeners = []), this.stopWaiting();
    }
    declare(e) {
      if (null !== this.element)
        return void this.logger.warn(
          new Error("setMeasurementTarget called more than once")
        );
      this.element = e;
      const t = this.listeners;
      (this.listeners = []), this.stopWaiting();
      for (const e of t) this.notify(e, this.element);
    }
    stopWaiting() {
      null !== this.timeoutId &&
        (clearTimeout(this.timeoutId), (this.timeoutId = null));
    }
    notify(e, t) {
      try {
        e(t);
      } catch (e) {
        this.logger.error(e);
      }
    }
  }
  class Rt {
    constructor(e, t) {
      (this.functions = e), (this.logger = t);
    }
    publishOn(e) {
      if (null === e)
        throw new Error("No window to publish the creative API on");
      const t = {};
      Object.keys(this.functions).forEach((e) => {
        const i = this.functions[e];
        void 0 !== i && (t[e] = this.guard(i));
      }),
        X("onetag", t, e);
    }
    guard(e) {
      return (...t) => {
        try {
          e(...t);
        } catch (e) {
          this.logger.error(e);
        }
      };
    }
  }
  class Bt {
    constructor(e, t, i) {
      (this.createFrame = e), (this.context = t), (this.logger = i);
    }
    inject(e, t) {
      try {
        if ("string" != typeof e || 0 === e.length) return;
        if (this.context.isOpaque())
          return void this.logger.trace(
            "additionalHtml skipped: opaque context"
          );
        const i = this.createFrame({ width: 0, height: 0, isVisible: !1 });
        if ((t.appendChild(i.element), null == i.element.contentWindow))
          return void this.logger.trace(
            "additionalHtml skipped: container out of the document"
          );
        i.writeDocument(e);
      } catch (e) {
        this.logger.warn(e);
      }
    }
  }
  function Nt({ width: e, height: t, isVisible: i }) {
    const s = document.createElement("iframe");
    return (
      (s.marginHeight = "0"),
      (s.marginWidth = "0"),
      (s.frameBorder = "0"),
      (s.scrolling = "no"),
      (s.width = `${e}px`),
      (s.height = `${t}px`),
      (s.style.border = "0px none"),
      (s.style.display = i ? "block" : "none"),
      {
        element: s,
        writeDocument(e) {
          const t = s.contentWindow.document;
          t.open(), t.write(e), t.close();
        },
      }
    );
  }
  class Ut extends se {
    constructor() {
      super(...arguments), (this.id = 830);
    }
  }
  class Wt extends se {
    constructor() {
      super(...arguments), (this.id = 829), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class jt {
    constructor() {
      (this.active = null), (this.slots = []);
    }
    enqueue(e) {
      -1 === this.slots.indexOf(e) &&
        this.active !== e &&
        (null === this.active
          ? ((this.active = e), e(!0))
          : this.slots.push(e));
    }
    remove(e) {
      if (this.active === e) {
        (this.active = null), e(!1);
        const t = this.slots.shift();
        t && ((this.active = t), t(!0));
      }
      this.slots = this.slots.filter((t) => t !== e);
    }
  }
  class $t extends v {
    static for(e) {
      try {
        const t = window.top;
        return (
          t.onetag || (t.onetag = {}),
          t.onetag.queue || (t.onetag.queue = new jt()),
          new $t(e, t.onetag.queue)
        );
      } catch (e) {
        return;
      }
    }
    constructor(e, t, i = new ee()) {
      super(),
        (this.element = e),
        (this.queue = t),
        (this.deviceDetector = i),
        (this.placeholder = null),
        (this.style = null),
        (this.booster = (e) => {
          if (e) {
            if (this.element.parentNode && this.element.ownerDocument) {
              const e = this.element.getBoundingClientRect(),
                {
                  position: t,
                  zIndex: i,
                  top: s,
                  bottom: n,
                  left: r,
                  transform: o,
                  transformOrigin: a,
                } = this.element.style;
              (this.style = {
                position: t,
                zIndex: i,
                top: s,
                bottom: n,
                left: r,
                transform: o,
                transformOrigin: a,
              }),
                (this.element.style.position = "fixed"),
                (this.element.style.zIndex = "99999999"),
                (this.element.style.top = e.top <= 0 ? "0" : "auto"),
                (this.element.style.bottom = e.top < 0 ? "auto" : "0"),
                (this.element.style.left = `${
                  this.deviceDetector.isTouchDevice() ? 0 : e.left
                }px`),
                this.deviceDetector.isTouchDevice() &&
                  e.height > 150 &&
                  ((this.element.style.transform = `scale(${150 / e.height})`),
                  (this.element.style.transformOrigin =
                    e.top < 0 ? "top left" : "bottom left")),
                (this.placeholder =
                  this.element.ownerDocument.createElement("div")),
                (this.placeholder.style.cssText = `width: ${e.width}px; height: ${e.height}px`),
                this.element.parentNode.insertBefore(
                  this.placeholder,
                  this.element
                ),
                this.emit("boost");
            }
          } else if (this.placeholder && this.placeholder.parentNode) {
            this.placeholder.parentNode.removeChild(this.placeholder);
            const {
              position: e,
              zIndex: t,
              top: i,
              bottom: s,
              left: n,
              transform: r,
              transformOrigin: o,
            } = this.style;
            (this.element.style.position = e),
              (this.element.style.zIndex = t),
              (this.element.style.top = i),
              (this.element.style.bottom = s),
              (this.element.style.left = n),
              (this.element.style.transform = r),
              (this.element.style.transformOrigin = o),
              (this.style = null);
          }
        });
    }
    boost() {
      this.queue.enqueue(this.booster);
    }
    restore() {
      this.queue.remove(this.booster);
    }
  }
  class zt extends v {
    constructor(e) {
      super(),
        (this.target = e),
        (this.isRunning = !1),
        (this.interval = new pe({ duration: 400, loop: !0 })),
        this.interval.on("expire", () => this.update());
    }
    start() {
      this.isRunning ||
        (this.update(), this.interval.start(), (this.isRunning = !0));
    }
    stop() {
      this.isRunning && (this.interval.stop(), (this.isRunning = !1));
    }
    update() {
      this.emit("change", this.computeCoverage());
    }
    computeCoverage() {
      if (
        this.target.ownerDocument &&
        "elementFromPoint" in this.target.ownerDocument
      ) {
        const {
            left: e,
            top: t,
            width: i,
            height: s,
          } = this.target.getBoundingClientRect(),
          n = this.target.ownerDocument.elementFromPoint(e + i / 2, t + s / 2);
        if (null != n) return n !== this.target && !this.target.contains(n);
      }
      return !1;
    }
  }
  class qt extends v {
    constructor(e) {
      super(),
        (this.baseDuration = "banner" === e.type ? 1e3 : 2e3),
        (this.timers = new Map()),
        (this.fulfilled = new Map()),
        this.initializeTimers(!0 === e.coverageless),
        this.setupEventHandlers();
    }
    initializeTimers(e) {
      this.timers.set("fiftyPercent", new pe({ duration: this.baseDuration })),
        e &&
          this.timers.set(
            "coverageless",
            new pe({ duration: this.baseDuration })
          ),
        this.timers.set(
          "hundredPercent",
          new pe({ duration: this.baseDuration })
        ),
        this.timers.set("visibility", new pe({ duration: this.baseDuration })),
        this.timers.set("fiveSeconds", new pe({ duration: 5e3 }));
      for (let e = 1; e <= 10; e++)
        this.timers.set(`hundredPercent${e}s`, new pe({ duration: 1e3 * e }));
      this.timers.forEach((e, t) => this.fulfilled.set(t, !1));
    }
    setupEventHandlers() {
      var e;
      this.timers.get("fiftyPercent").once("expire", () => {
        this.fulfilled.set("fiftyPercent", !0), this.emit("viewable");
      }),
        null === (e = this.timers.get("coverageless")) ||
          void 0 === e ||
          e.once("expire", () => {
            this.fulfilled.set("coverageless", !0),
              this.emit("viewableCoverageless");
          }),
        this.timers.get("fiveSeconds").once("expire", () => {
          this.fulfilled.set("fiveSeconds", !0),
            this.emit("viewableFiftyPercent5s");
        }),
        this.timers.get("visibility").once("expire", () => {
          this.fulfilled.set("visibility", !0), this.emit("visible");
        }),
        this.timers.get("hundredPercent").once("expire", () => {
          this.fulfilled.set("hundredPercent", !0),
            this.emit("viewableHundredPercent");
        });
      [
        ["hundredPercent1s", "viewableHundredPercent1s"],
        ["hundredPercent2s", "viewableHundredPercent2s"],
        ["hundredPercent3s", "viewableHundredPercent3s"],
        ["hundredPercent4s", "viewableHundredPercent4s"],
        ["hundredPercent5s", "viewableHundredPercent5s"],
        ["hundredPercent6s", "viewableHundredPercent6s"],
        ["hundredPercent7s", "viewableHundredPercent7s"],
        ["hundredPercent8s", "viewableHundredPercent8s"],
        ["hundredPercent9s", "viewableHundredPercent9s"],
        ["hundredPercent10s", "viewableHundredPercent10s"],
      ].forEach(([e, t]) => {
        this.timers.get(e).once("expire", () => {
          this.fulfilled.set(e, !0), this.emit(t);
        });
      });
    }
    startFiftyPercentTimers() {
      this.fulfilled.get("fiftyPercent") ||
        this.timers.get("fiftyPercent").start(),
        this.fulfilled.get("fiveSeconds") ||
          this.timers.get("fiveSeconds").start();
    }
    stopFiftyPercentTimers() {
      this.timers.get("fiftyPercent").stop(),
        this.timers.get("fiveSeconds").stop();
    }
    startCoveragelessTimer() {
      var e;
      this.fulfilled.get("coverageless") ||
        null === (e = this.timers.get("coverageless")) ||
        void 0 === e ||
        e.start();
    }
    stopCoveragelessTimer() {
      var e;
      null === (e = this.timers.get("coverageless")) ||
        void 0 === e ||
        e.stop();
    }
    startHundredPercentTimers() {
      this.fulfilled.get("hundredPercent") ||
        this.timers.get("hundredPercent").start();
      for (let e = 1; e <= 10; e++) {
        const t = `hundredPercent${e}s`;
        this.fulfilled.get(t) || this.timers.get(t).start();
      }
    }
    stopHundredPercentTimers() {
      this.timers.get("hundredPercent").stop();
      for (let e = 1; e <= 10; e++) {
        const t = `hundredPercent${e}s`;
        this.fulfilled.get(t) || this.timers.get(t).stop();
      }
    }
    startVisibilityTimer() {
      this.fulfilled.get("visibility") || this.timers.get("visibility").start();
    }
    stopVisibilityTimer() {
      this.timers.get("visibility").stop();
    }
    get isFiftyPercentFulfilled() {
      var e;
      return (
        null !== (e = this.fulfilled.get("fiftyPercent")) && void 0 !== e && e
      );
    }
    get isAllFulfilled() {
      return Array.from(this.fulfilled.values()).every((e) => e);
    }
    dispose() {
      this.timers.forEach((e) => {
        e.stop(), e.clear();
      }),
        this.clear();
    }
  }
  class Jt extends v {
    static findBoostableContainer(e, t) {
      const i = t.isTopmost() ? e : t.getTopmostIFrame();
      if (null != i) {
        if (i === e) return i;
        const { height: t } = i.getBoundingClientRect(),
          { height: s } = e.getBoundingClientRect();
        return t <= s + s * 0.5 && i;
      }
    }
    constructor(e, t, i, s, n) {
      super(),
        (this.boost = t),
        (this.visibility = i),
        (this.booster = s),
        (this.coverage = n),
        (this.isWatching = !1),
        (this.isBoostDeactivated = !1),
        (this.timerManager = new qt({ type: e, coverageless: null != n })),
        (this.onPageVisibilityChange = this.onPageVisibilityChange.bind(this)),
        (this.onHalfIntersectionChange =
          this.onHalfIntersectionChange.bind(this)),
        (this.onFullIntersectionChange =
          this.onFullIntersectionChange.bind(this)),
        (this.onHalfVisibilityChange = this.onHalfVisibilityChange.bind(this)),
        (this.onVisibilitySupportChange =
          this.onVisibilitySupportChange.bind(this)),
        this.setupTimerEvents(),
        n &&
          n.on("change", (e) => {
            e
              ? this.timerManager.stopFiftyPercentTimers()
              : this.timerManager.startFiftyPercentTimers();
          }),
        i.fiftyPercent.on("intersectionChange", this.onHalfIntersectionChange),
        i.hundredPercent.on(
          "intersectionChange",
          this.onFullIntersectionChange
        ),
        i.fiftyPercent.on("visibilityChange", this.onHalfVisibilityChange),
        i.fiftyPercent.on(
          "visibilitySupportChange",
          this.onVisibilitySupportChange
        ),
        document.addEventListener(E(), this.onPageVisibilityChange);
    }
    setupTimerEvents() {
      this.timerManager.on("viewable", () => {
        this.emit("isViewable"),
          this.coverage && this.emit("isViewableCoverageChecked"),
          (this.isBoostDeactivated = !0),
          setTimeout(() => {
            var e;
            return null === (e = this.booster) || void 0 === e
              ? void 0
              : e.restore();
          }, 500),
          this.updateDisposal();
      }),
        this.timerManager.on("viewableCoverageless", () => {
          this.emit("isViewableCoverageless"), this.updateDisposal();
        }),
        this.timerManager.on("viewableFiftyPercent5s", () => {
          this.emit("isViewableFiftyPercent5s"), this.updateDisposal();
        }),
        this.timerManager.on("visible", () => {
          this.emit("isVisible"), this.updateDisposal();
        }),
        this.timerManager.on("viewableHundredPercent", () => {
          this.emit("isViewableHundredPercent"), this.updateDisposal();
        });
      [
        ["viewableHundredPercent1s", "isViewableHundredPercent1s"],
        ["viewableHundredPercent2s", "isViewableHundredPercent2s"],
        ["viewableHundredPercent3s", "isViewableHundredPercent3s"],
        ["viewableHundredPercent4s", "isViewableHundredPercent4s"],
        ["viewableHundredPercent5s", "isViewableHundredPercent5s"],
        ["viewableHundredPercent6s", "isViewableHundredPercent6s"],
        ["viewableHundredPercent7s", "isViewableHundredPercent7s"],
        ["viewableHundredPercent8s", "isViewableHundredPercent8s"],
        ["viewableHundredPercent9s", "isViewableHundredPercent9s"],
        ["viewableHundredPercent10s", "isViewableHundredPercent10s"],
      ].forEach(([e, t]) => {
        this.timerManager.on(e, () => {
          this.emit(t), this.updateDisposal();
        });
      });
    }
    start() {
      (this.isWatching = !0),
        this.updateHalfIntersectionState(),
        this.updateFullIntersectionState(),
        this.updateHalfVisibilityState(),
        this.updateVisibilitySupport(),
        !this.visibility.fiftyPercent.isIntersecting &&
          this.booster &&
          "hard" === this.boost &&
          this.booster.boost();
    }
    stop() {
      (this.isWatching = !1),
        this.updateHalfIntersectionState(),
        this.updateFullIntersectionState();
    }
    dispose() {
      this.timerManager.dispose(),
        this.coverage && (this.coverage.stop(), this.coverage.clear()),
        this.visibility.fiftyPercent.dispose(),
        this.visibility.hundredPercent.dispose(),
        document.removeEventListener(E(), this.onPageVisibilityChange);
    }
    onHalfIntersectionChange(e) {
      !e &&
        this.booster &&
        this.boost &&
        !this.isBoostDeactivated &&
        this.booster.boost(),
        this.updateHalfIntersectionState();
    }
    onVisibilitySupportChange() {
      this.updateVisibilitySupport();
    }
    onHalfVisibilityChange() {
      this.updateHalfVisibilityState();
    }
    onFullIntersectionChange() {
      this.updateFullIntersectionState();
    }
    onPageVisibilityChange() {
      this.updateHalfIntersectionState(),
        this.updateFullIntersectionState(),
        this.updateHalfVisibilityState();
    }
    updateVisibilitySupport() {
      this.isWatching &&
        null != this.visibility.fiftyPercent.isVisibilitySupported &&
        this.emit(
          "visibilitySupportChange",
          this.visibility.fiftyPercent.isVisibilitySupported
        );
    }
    updateHalfVisibilityState() {
      this.isWatching && !I() && this.visibility.fiftyPercent.isVisible
        ? this.timerManager.startVisibilityTimer()
        : this.timerManager.stopVisibilityTimer();
    }
    updateHalfIntersectionState() {
      var e;
      this.isWatching && !I() && this.visibility.fiftyPercent.isIntersecting
        ? (this.coverage
            ? this.coverage.start()
            : this.timerManager.startFiftyPercentTimers(),
          this.timerManager.startCoveragelessTimer())
        : (null === (e = this.coverage) || void 0 === e || e.stop(),
          this.timerManager.stopFiftyPercentTimers(),
          this.timerManager.stopCoveragelessTimer());
    }
    updateFullIntersectionState() {
      this.isWatching && !I() && this.visibility.hundredPercent.isIntersecting
        ? this.timerManager.startHundredPercentTimers()
        : this.timerManager.stopHundredPercentTimers();
    }
    updateDisposal() {
      this.timerManager.isAllFulfilled &&
        (this.visibility.fiftyPercent.off(
          "intersectionChange",
          this.onHalfIntersectionChange
        ),
        this.visibility.hundredPercent.off(
          "intersectionChange",
          this.onFullIntersectionChange
        ),
        this.visibility.fiftyPercent.off(
          "visibilityChange",
          this.onHalfVisibilityChange
        ),
        this.visibility.fiftyPercent.off(
          "visibilitySupportChange",
          this.onVisibilitySupportChange
        ),
        document.removeEventListener(E(), this.onPageVisibilityChange));
    }
  }
  class Yt extends v {
    static isSupported(e = window) {
      return b.isSupported(e);
    }
    constructor(e, t = 0.5) {
      super(),
        (this.element = e),
        (this.threshold = t),
        (this._isVisible = null),
        (this._isVisibilitySupported = null),
        (this.intersectionWatcher = new b(e, {
          threshold: t,
          delay: 100,
          trackVisibility: !0,
        })),
        this.setupV2Observer();
    }
    setupV2Observer() {
      const e = this.intersectionWatcher.observer;
      if (!e) return;
      e.unobserve(this.element);
      const t = new (this.getWindowFromElement(
        this.element
      ).IntersectionObserver)(this.onV2Change.bind(this), {
        threshold: this.threshold,
        delay: 100,
        trackVisibility: !0,
      });
      t.observe(this.element), (this.intersectionWatcher.observer = t);
    }
    getWindowFromElement(e) {
      return e.ownerDocument && e.ownerDocument.defaultView
        ? e.ownerDocument.defaultView
        : window;
    }
    get isIntersecting() {
      return this.intersectionWatcher.isIntersecting;
    }
    get isVisible() {
      return this._isVisible;
    }
    get isVisibilitySupported() {
      return this._isVisibilitySupported;
    }
    get isSupported() {
      return this.intersectionWatcher.isSupported;
    }
    onV2Change(e) {
      const t = e[0],
        { isIntersecting: i, isVisible: s } = t;
      if (
        (null == this._isVisibilitySupported &&
          (null != s
            ? ((this._isVisibilitySupported = !0),
              this.emit("visibilitySupportChange", !0))
            : ((this._isVisibilitySupported = !1),
              this.emit("visibilitySupportChange", !1))),
        null != s)
      ) {
        const e = this._isVisible;
        !e && s && i
          ? ((this._isVisible = !0), this.emit("visibilityChange", !0))
          : !e ||
            (s && i) ||
            ((this._isVisible = !1), this.emit("visibilityChange", !1));
      } else
        (this._isVisibilitySupported = !1),
          this.emit("visibilitySupportChange", !1);
      const n = this.intersectionWatcher._isIntersecting;
      (this.intersectionWatcher._isIntersecting = i),
        n !== i && this.emit("intersectionChange", i);
    }
    dispose() {
      this.intersectionWatcher.dispose(), this.clear();
    }
  }
  class Xt extends se {
    constructor() {
      super(...arguments), (this.id = 6), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class Gt extends se {
    constructor() {
      super(...arguments), (this.id = 835), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class Kt extends se {
    constructor() {
      super(...arguments), (this.id = 836), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class Qt extends se {
    constructor() {
      super(...arguments), (this.id = 638), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class Zt extends se {
    constructor() {
      super(...arguments), (this.id = 569), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class ei extends se {
    constructor() {
      super(...arguments), (this.id = 601), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class ti extends se {
    constructor() {
      super(...arguments), (this.id = 671), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class ii extends se {
    constructor() {
      super(...arguments), (this.id = 672), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class si extends se {
    constructor() {
      super(...arguments), (this.id = 673), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class ni extends se {
    constructor() {
      super(...arguments), (this.id = 674), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class ri extends se {
    constructor() {
      super(...arguments), (this.id = 675), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class oi extends se {
    constructor() {
      super(...arguments), (this.id = 676), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class ai extends se {
    constructor() {
      super(...arguments), (this.id = 677), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class li extends se {
    constructor() {
      super(...arguments), (this.id = 678), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class ci extends se {
    constructor() {
      super(...arguments), (this.id = 679), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class hi extends se {
    constructor() {
      super(...arguments), (this.id = 680), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class di extends se {
    constructor() {
      super(...arguments), (this.id = 657), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class ui extends se {
    constructor() {
      super(...arguments), (this.id = 639), (this.canBeFiredMultipleTimes = !1);
    }
  }
  class pi extends se {
    constructor() {
      super(...arguments), (this.id = 466);
    }
  }
  class mi extends se {
    constructor() {
      super(...arguments), (this.id = 553);
    }
  }
  class gi extends se {
    constructor() {
      super(...arguments), (this.id = 581);
    }
  }
  class fi extends se {
    constructor() {
      super(...arguments), (this.id = 582);
    }
  }
  const vi = (e, t) => new Yt(e, t);
  class wi {
    static isSupported() {
      return Yt.isSupported();
    }
    constructor(e) {
      (this.options = e),
        (this.isImpressionReported = !1),
        (this.timeoutId = null);
      const { isSupported: t = wi.isSupported } = e;
      t() &&
        e.surface.onceAvailable((e) => {
          (this.watcher = this.createWatcher(e)), this.startWhenReady();
        });
    }
    reportImpression() {
      (this.isImpressionReported = !0), this.startWhenReady();
    }
    dispose() {
      var e;
      null !== this.timeoutId &&
        (clearTimeout(this.timeoutId), (this.timeoutId = null)),
        null === (e = this.watcher) || void 0 === e || e.dispose();
    }
    startWhenReady() {
      if (!this.isImpressionReported || void 0 === this.watcher) return;
      const e = this.watcher,
        { analytics: t, startDelay: i } = this.options;
      this.bindEvents(e),
        (this.timeoutId = window.setTimeout(() => {
          t.addDataCollector(new k(e)), e.start();
        }, i));
    }
    createWatcher(e) {
      const {
          context: t,
          adEventManager: i,
          boost: s,
          coverage: n,
          createVisibilityWatcher: r = vi,
        } = this.options,
        o = Jt.findBoostableContainer(e, t);
      return (
        s &&
          !o &&
          (i.fire(new mi()), null == o ? i.fire(new gi()) : i.fire(new fi())),
        new Jt(
          "banner",
          s,
          { fiftyPercent: r(e, 0.5), hundredPercent: r(e, 1) },
          o ? $t.for(o) : void 0,
          n && o ? new zt(o) : void 0
        )
      );
    }
    bindEvents(e) {
      var t;
      const { adEventManager: i } = this.options;
      [
        ["isViewable", Xt],
        ["isViewableCoverageless", Gt],
        ["isViewableCoverageChecked", Kt],
        ["isViewableFiftyPercent5s", Zt],
        ["isViewableHundredPercent", ei],
        ["isVisible", Qt],
        ["isViewableHundredPercent1s", ti],
        ["isViewableHundredPercent2s", ii],
        ["isViewableHundredPercent3s", si],
        ["isViewableHundredPercent4s", ni],
        ["isViewableHundredPercent5s", ri],
        ["isViewableHundredPercent6s", oi],
        ["isViewableHundredPercent7s", ai],
        ["isViewableHundredPercent8s", li],
        ["isViewableHundredPercent9s", ci],
        ["isViewableHundredPercent10s", hi],
      ].forEach(([t, s]) => e.once(t, () => i.fire(new s()))),
        e.once("visibilitySupportChange", (e) => {
          e ? i.fire(new di()) : i.fire(new ui());
        }),
        null === (t = e.booster) ||
          void 0 === t ||
          t.once("boost", () => i.fire(new pi()));
    }
  }
  class yi {
    static fromCreative(e) {
      var t;
      return new yi(
        null === (t = e.debugInfo) || void 0 === t ? void 0 : t.version,
        e.isPreprod,
        e.maxLogLevel
      );
    }
    constructor(e = "", t = !1, i) {
      (this.version = e), (this._isPreprod = t), (this.maxLogLevel = i);
    }
    getVersion() {
      return this.version;
    }
    isPreprod() {
      return this._isPreprod;
    }
    getMaxLogLevel() {
      return null != this.maxLogLevel
        ? this.maxLogLevel
        : this._isPreprod
        ? 4
        : void 0;
    }
    toJSON() {
      return { version: this.version, isPreprod: this._isPreprod };
    }
  }
  class bi extends d {
    constructor() {
      super("Container element not found"), (this.code = "container-missing");
    }
  }
  class xi extends d {
    constructor(e, t) {
      super("Ad JSON could not be decoded"),
        (this.failure = e),
        (this.detail = t),
        (this.code = "adjson-invalid");
    }
    getAttachments() {
      return [{ type: "adJson", failure: this.failure, cause: this.detail }];
    }
  }
  function Ii(e) {
    return e instanceof Error ? e.message : String(e);
  }
  var Ei = function (e, t, i, s) {
    return new (i || (i = Promise))(function (n, r) {
      function o(e) {
        try {
          l(s.next(e));
        } catch (e) {
          r(e);
        }
      }
      function a(e) {
        try {
          l(s.throw(e));
        } catch (e) {
          r(e);
        }
      }
      function l(e) {
        var t;
        e.done
          ? n(e.value)
          : ((t = e.value),
            t instanceof i
              ? t
              : new i(function (e) {
                  e(t);
                })).then(o, a);
      }
      l((s = s.apply(e, t || [])).next());
    });
  };
  new Ke().id;
  const Ti = new ce().id,
    Pi = new ut().id;
  function Si(e, t, i, s, o, a, l, c, h, d, u, p, m, g) {
    const {
        width: f,
        height: T,
        viewEnhancer: S,
        dealId: C,
        strongViewEnhancer: M,
        thirdPartyEventPixels: F,
        clickAsEstimation: O,
        samedomain: A,
        additionalHtml: V,
        additional: D,
        contentInfo: k,
        contentDecoder: H,
        bidUUID: L,
        impressionId: _ = "",
        nodeId: R,
        triggerEvent: B,
        iflk: N,
        superscroller: U = !1,
        aryelSuperscroller: W = !1,
      } = e,
      j = e.html,
      $ = w(
        { width: f, height: T, shouldSandbox: !0, forceUniqueOrigin: !1 },
        c
      ),
      z = document.createElement("div");
    (z.style.background = "transparent"),
      (z.style.width = "100%"),
      (z.style.height = "100%"),
      (z.style.position = "absolute"),
      (z.style.display = "flex"),
      (z.style.alignItems = "center"),
      (z.style.justifyContent = "center");
    if (U && !W) {
      const e = () => {
        const e = new Mt([f, T], $.element);
        e.apply(),
          m.add(() => {
            e.dispose();
          });
      };
      if (i.isFriendly()) {
        const s = new Ft(T, t, i),
          n = s.getTopmostElement(),
          r = new Ot(n, (e) => new MutationObserver(e)),
          o = new Pt([f, T], n);
        r.once("removed", () => m.dispose());
        const a = () => m.dispose();
        addEventListener("pagehide", a),
          g
            .then((e) => o.canRender(!0 === e))
            .then((t) => {
              t ? (s.bust(), o.apply()) : e();
            }),
          r.start(),
          m.add(() => {
            removeEventListener("pagehide", a),
              o.dispose(),
              r.dispose(),
              s.dispose();
          });
      } else e();
    } else {
      const e = G({ width: f, height: T }, t, a);
      ($.element.style.flex = "0 0 auto"),
        ($.element.style.transform = `scale(${e})`);
    }
    z.appendChild($.element), t.appendChild(z);
    const q = W && i.isFriendly(),
      J = q ? _t.declaredByCreative(c) : _t.known($.element, c);
    m.add(() => J.dispose());
    let Y = !1;
    const X = new wi({
      surface: J,
      context: i,
      adEventManager: d,
      analytics: s,
      boost: !!S && (null != C || M ? "hard" : "soft"),
      coverage: S && null == C && !M,
      startDelay: q ? 250 : 1500,
    });
    m.add(() => X.dispose());
    const K = () =>
        J.onceAvailable((s) => {
          (function (e) {
            return x(this, arguments, void 0, function* (e, t = 0.5) {
              const i = new b(e, { threshold: t });
              return new Promise((e) => {
                i.isIntersecting
                  ? (i.dispose(), e())
                  : i.once("intersecting", () => {
                      i.dispose(), e();
                    });
              });
            });
          })(s, 0.5).then(() =>
            Ei(this, void 0, void 0, function* () {
              var s, n, r;
              if (!D && H && 1 === H.contentId) {
                const l =
                  ((n = H.stories.losers),
                  (r = o.read()),
                  n.filter((e) => r.every((t) => t.bidUUID !== e.bidUUID)));
                if (k && 0 === l.length) {
                  const t = yield Ae(
                    (function (e, t, i) {
                      const s =
                        !e.app &&
                        -1 !== t.stories.formats.indexOf(3) &&
                        (function (e) {
                          const t =
                              "portrait" ===
                              (function () {
                                try {
                                  return top &&
                                    top.matchMedia("(orientation: portrait)")
                                      .matches
                                    ? "portrait"
                                    : "landscape";
                                } catch (e) {
                                  return null;
                                }
                              })(),
                            i = new ee();
                          return e.isFriendly() && i.isTouchDevice() && t;
                        })(i);
                      return [
                        { formats: t.stories.formats, sizes: t.stories.sizes },
                      ].concat(
                        s
                          ? [
                              {
                                formats: [19],
                                sizes: [{ w: e.pWidth, h: e.pHeight }].concat([
                                  { w: 400, h: 300 },
                                ]),
                              },
                            ]
                          : []
                      );
                    })(e, H, i),
                    k,
                    h,
                    { exclude: o.read() }
                  );
                  for (const e of t.invocations) l.push(e);
                }
                const d = Le({
                  container: t,
                  enableScaleOut: a,
                  postBidInvocations: l,
                  logger: c,
                  initialStorySlides: [{ type: "main", container: z }],
                  stopAfterFirstCycle: null != N,
                  showProgressBar:
                    null !== (s = H.stories.progressBar) && void 0 !== s && s,
                  onCycleComplete: () => {
                    m.dispose();
                    new Et(N, c).start();
                  },
                });
                m.add(d);
              }
            })
          );
        }),
      Q = e.app ? new Pe(d, c, u) : void 0,
      Z = e.app ? new bt(c) : void 0,
      te = B === Ti,
      ie = B === Pi,
      se = () => {
        try {
          if (Y) return;
          null === document.getElementById(R) && d.fire(new Ge()),
            d.fire(new Ke()),
            m.setTimeout(() => d.fire(new Qe()), 500),
            m.setTimeout(() => d.fire(new Ze()), 1e3),
            m.setTimeout(() => d.fire(new et()), 1500),
            (Y = !0),
            wi.isSupported()
              ? (d.fire(new tt()), X.reportImpression(), K())
              : d.fire(new it()),
            m.setTimeout(() => d.fire(new st()), 1e4),
            new Bt(Nt, i, c).inject(V, z);
        } catch (e) {
          c.error(e);
        }
      };
    te &&
      (null == Q ||
        Q.on("billableMraidImpressionTriggered", () => {
          se();
        })),
      ie &&
        (null == Z ||
          Z.on("billableOmidImpression", () => {
            se();
          })),
      null == Q || Q.start(),
      null == Z || Z.start((e) => d);
    const ne = -1 !== j.indexOf("ONETAG_ONCLICK_FUNCTION"),
      re = () => {
        d.fire(new rt()),
          (function (e) {
            const t = Date.now(),
              i = () => {
                I() ||
                  (e(Date.now() - t), document.removeEventListener(E(), i));
              };
            document.addEventListener(E(), i);
          })((e) => {
            e <= 5e3
              ? d.fire(new $e())
              : e <= 1e4
              ? d.fire(new ze())
              : e <= 15e3
              ? d.fire(new qe())
              : e <= 3e4
              ? d.fire(new Je())
              : d.fire(new Ye());
          });
      },
      oe = y();
    let ae;
    if ((oe && d.fire(new Xe()), A || oe)) {
      ne && (window.onetag.click = re);
      const e =
        j.replace(/ONETAG_ONCLICK_FUNCTION/, "parent.onetag.click()") +
        (Q ? Q.getOverrideOpenCode() : "");
      try {
        new Rt(
          {
            setMeasurementTarget: q ? (e) => J.declare(e) : void 0,
            clickProbe: () => d.fire(new Ut()),
          },
          c
        ).publishOn($.element.contentWindow);
      } catch (e) {
        c.trace(e);
      }
      try {
        $.writeDocument(e);
      } catch (t) {
        $.element.srcdoc = e;
      }
      d.fire(new Wt()), (ae = $.emitter);
    } else {
      ae = new v();
      const t = h.hasSelfHostedArtifacts()
          ? (function (e = n) {
              if ("" === r(e)) return "";
              const t = e.split(/[?#]/)[0];
              return t.slice(0, t.lastIndexOf("/") + 1);
            })()
          : l
          ? "https://onetag-sys.com/static-preprod/"
          : "https://onetag-sys.com/static/",
        s = h.hasSelfHostedArtifacts()
          ? r()
          : l
          ? "https://onetag-sys.com"
          : "https://onetag-sys.com",
        o = new Ie(
          "creative-sandbox",
          c,
          i.isOpaque() ? "*" : s,
          window,
          $.element.contentWindow
        );
      o.on("message", (t) => {
        switch (
          (o.getChannels().length > 1 &&
            c.warn("Creative sandbox handshake occurred more than once"),
          t.data.event)
        ) {
          case "LOAD":
            t.reply({
              event: "INJECT",
              creative: {
                width: f,
                height: T,
                html: j + (Q ? Q.getOverrideOpenCode() : ""),
                app: e.app,
              },
              isPreprod: l,
              samedomain: A,
              sessionInfo: { bidUUID: L, impressionId: _ },
              debugInfo: e.debugInfo,
              version: p.getVersion(),
            }),
              null == t.data.version &&
                c.warn("Child creative sandbox outdated protocol detected");
            break;
          case "INJECTED":
            d.fire(new je()), d.fire(new Wt());
            break;
          case "CLICK":
            ae.emit("click");
        }
      }),
        o.listen();
      const a = p.getVersion(),
        u = "" !== a ? `?${a}` : "";
      $.element.setAttribute("src", `${t}creative-sandbox.html${u}`);
    }
    te || ie || window.setTimeout(se, 500),
      J.onceAvailable((e) =>
        (function (e, t, i, s, n, r, o) {
          return Ei(this, void 0, void 0, function* () {
            try {
              const n = yield (function (e, t, i) {
                return Promise.race([
                  P(e, i),
                  new Promise((e) => {
                    t.once("click", () => e("click:dom"));
                  }),
                  ((s = e),
                  new Promise((e) => {
                    let t = !1;
                    const i = () => {
                        t = !0;
                      },
                      n = () => {
                        t = !1;
                      },
                      r = () => {
                        I() &&
                          t &&
                          (document.removeEventListener(E(), r),
                          s.removeEventListener("mouseover", i),
                          s.removeEventListener("mouseout", n),
                          e(1));
                      };
                    document.addEventListener(E(), r),
                      s.addEventListener("mouseover", i),
                      s.addEventListener("mouseout", n);
                  })),
                ]);
                var s;
              })(e, t, r);
              switch ((!i ? s.fire(new nt()) : o(), n)) {
                case 0:
                  s.fire(new ot());
                  break;
                case 1:
                  s.fire(new at());
                  break;
                case "click:dom":
                  s.fire(new lt());
              }
            } catch (e) {
              n.error(e);
            }
          });
        })(e, ae, O, d, c, i, re)
      ),
      m.add(() => {
        null == Q || Q.destroy(), z.remove();
      });
  }
  X("onetag.BannerAdBannerPlacement", {
    init: function (e) {
      return Ei(this, void 0, void 0, function* () {
        var t;
        const i = At.getCurrent(),
          n = new Be(),
          r = new s.A(),
          o = new p(),
          a = new h(r, o);
        try {
          let s;
          a.attach(
            Object.assign(
              { type: "context", artifactName: "BannerAdBannerPlacement" },
              i.toJSON()
            )
          );
          try {
            s = (function (e) {
              let t, i;
              try {
                t = atob(e);
              } catch (e) {
                throw new xi("base64", Ii(e));
              }
              try {
                i = JSON.parse(t);
              } catch (e) {
                throw new xi("json", Ii(e));
              }
              if (null === i || "object" != typeof i || Array.isArray(i))
                throw new xi(
                  "not-an-object",
                  null === i ? "null" : Array.isArray(i) ? "array" : typeof i
                );
              return i;
            })(e.adJson);
          } catch (t) {
            return void a
              .attach({
                type: "renderer",
                adJson: e.adJson,
                pingUrl: e.pingUrl,
              })
              .fatal(t);
          }
          const {
              sid: l,
              bidrequestId: c = "",
              impressionId: h = "",
              nodeId: d,
              width: u,
              height: p,
              consentDenied: m,
              additional: g,
              pWidth: v = u,
              pHeight: w = p,
              bidUUID: y,
              contentInfo: b,
              contentDecoder: x,
              soEnabled: I = !1,
              app: E = !1,
              samedomain: P = !0,
            } = s,
            S = new Se(e.pingUrl, a, s.thirdPartyEventPixels),
            C = f.fromCreative(s),
            M = yi.fromCreative(s),
            F = M.isPreprod();
          (a.maxLogLevel =
            null !== (t = M.getMaxLogLevel()) && void 0 !== t
              ? t
              : a.maxLogLevel),
            a.integrate({ type: "context", app: E }),
            a.attach(
              Object.assign(
                Object.assign(
                  Object.assign({ type: "renderer" }, C.toJSON()),
                  M.toJSON()
                ),
                { samedomain: P }
              )
            ),
            m ||
              (function (e, t) {
                try {
                  t && e.isFriendly() && localStorage.setItem("onetag_sid", t);
                } catch (e) {}
              })(i, l);
          const O = new Z(),
            k = document.getElementById(d);
          if (null === k)
            throw (
              (a.integrate({ type: "renderer", adJson: e.adJson, nodeId: d }),
              new bi())
            );
          const R = new A(c, h, r, a, o),
            N = O.read().some((e) => e.bidUUID === y);
          O.add(s),
            (k.style.cssText = `\n            width: ${v}px;\n            height: ${w}px;\n            position: relative;\n        `),
            n.add(() => {
              R.stop(), (k.style.cssText = ""), k.remove();
            }),
            R.addDataCollectors(new V(i), new L(k, i), new D(), new H(k));
          const U = J.forPlacement(k, i, a);
          R.addDataCollector(new _(U.detect())),
            s.superscroller ||
              s.aryelSuperscroller ||
              U.observe((e) => {
                R.addDataCollector(new _(e));
              }),
            n.add(() => U.dispose());
          let W = Promise.resolve(void 0);
          switch (
            (i.isFriendly() &&
              ((W = (function (e, t, i) {
                return Y(this, void 0, void 0, function* () {
                  var s;
                  yield T();
                  try {
                    const i =
                        null !== (s = t.getTopmostIFrame()) && void 0 !== s
                          ? s
                          : e,
                      n = i.ownerDocument.defaultView;
                    if (null === n) return;
                    return j(i, (e) => n.getComputedStyle(e));
                  } catch (e) {
                    return void i.warn(e);
                  }
                });
              })(k, i, a)),
              R.addDataCollector(new B(W))),
            i.getType())
          ) {
            case "DETACHED_FRAME":
              S.fire(new Lt());
              break;
            case "TOPMOST":
              S.fire(new Vt());
              break;
            case "FRIENDLY_FRAME":
              S.fire(new Dt());
              break;
            case "UNFRIENDLY_FRAME":
              S.fire(new kt());
              break;
            case "OPAQUE_FRAME":
              S.fire(new Ht());
          }
          if (g)
            return Si(s, k, i, R, O, I, F, a, r, S, C, M, n, W), void R.start();
          if (N && (S.fire(new Ne()), b && b.duplicatePreventionEnabled)) {
            S.fire(new Ue()), R.start();
            const e = yield Re(
              k,
              b,
              O,
              (function (e) {
                return [
                  { formats: [2], sizes: [{ w: e.pWidth, h: e.pHeight }] },
                ];
              })(s),
              I,
              a,
              r
            );
            if (e) return void n.setTimeout(() => S.fire(new We()), 500);
          }
          x
            ? (function (e, t, i, s, n, r, o, a, l, c, h, d, u, p, m) {
                switch (r.contentId) {
                  case 1:
                  case 0:
                    Si(e, t, i, n, s, o, a, l, c, h, d, u, p, m);
                    break;
                  default:
                    h.fire(new ct()),
                      Si(e, t, i, n, s, o, a, l, c, h, d, u, p, m);
                }
              })(s, k, i, O, R, x, I, F, a, r, S, C, M, n, W)
            : Si(s, k, i, R, O, I, F, a, r, S, C, M, n, W),
            R.isStarted || R.start();
        } catch (e) {
          a.error(e);
        }
      });
    },
  });
})();
