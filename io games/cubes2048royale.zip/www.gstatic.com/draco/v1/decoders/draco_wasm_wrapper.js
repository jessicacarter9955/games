var $jscomp = $jscomp || {};
$jscomp.scope = {};
$jscomp.ASSUME_ES2020 = !1;
$jscomp.ASSUME_ES6 = $jscomp.ASSUME_ES2020;
$jscomp.ASSUME_ES5 = $jscomp.ASSUME_ES6;
$jscomp.ASSUME_NO_NATIVE_MAP = !1;
$jscomp.ASSUME_NO_NATIVE_SET = !1;
$jscomp.ISOLATE_POLYFILLS = !1;
$jscomp.FORCE_POLYFILL_PROMISE = !1;
$jscomp.FORCE_POLYFILL_PROMISE_WHEN_NO_UNHANDLED_REJECTION = !1;
$jscomp.INSTRUMENT_ASYNC_CONTEXT = !0;
$jscomp.objectCreate =
  $jscomp.ASSUME_ES5 || typeof Object.create == "function"
    ? Object.create
    : function (f) {
        var h = function () {};
        h.prototype = f;
        return new h();
      };
$jscomp.defineProperty =
  $jscomp.ASSUME_ES5 || typeof Object.defineProperties == "function"
    ? Object.defineProperty
    : function (f, h, m) {
        if (f == Array.prototype || f == Object.prototype) return f;
        f[h] = m.value;
        return f;
      };
$jscomp.getGlobal = function (f) {
  f = [
    "object" == typeof globalThis && globalThis,
    f,
    "object" == typeof window && window,
    "object" == typeof self && self,
    "object" == typeof global && global,
  ];
  for (var h = 0; h < f.length; ++h) {
    var m = f[h];
    if (m && m.Math == Math) return m;
  }
  throw Error("Cannot find global object");
};
$jscomp.global = $jscomp.ASSUME_ES2020 ? globalThis : $jscomp.getGlobal(this);
$jscomp.IS_SYMBOL_NATIVE =
  typeof Symbol === "function" && typeof Symbol("x") === "symbol";
$jscomp.TRUST_ES6_POLYFILLS =
  !$jscomp.ISOLATE_POLYFILLS || $jscomp.IS_SYMBOL_NATIVE;
$jscomp.polyfills = {};
$jscomp.propertyToPolyfillSymbol = {};
$jscomp.POLYFILL_PREFIX = "$jscp$";
var $jscomp$lookupPolyfilledValue = function (f, h, m) {
  if (!m || f != null) {
    m = $jscomp.propertyToPolyfillSymbol[h];
    if (m == null) return f[h];
    m = f[m];
    return m !== void 0 ? m : f[h];
  }
};
$jscomp.TYPED_ARRAY_CLASSES = (function () {
  var f =
    "Int8 Uint8 Uint8Clamped Int16 Uint16 Int32 Uint32 Float32 Float64".split(
      " "
    );
  $jscomp.global.BigInt64Array && (f.push("BigInt64"), f.push("BigUint64"));
  return f;
})();
$jscomp.polyfillTypedArrayMethod = function (f, h, m, q) {
  if (h)
    for (var g = 0; g < $jscomp.TYPED_ARRAY_CLASSES.length; g++) {
      var r = $jscomp.TYPED_ARRAY_CLASSES[g] + "Array.prototype." + f;
      $jscomp.ISOLATE_POLYFILLS
        ? $jscomp.polyfillIsolated(r, h, m, q)
        : $jscomp.polyfillUnisolated(r, h, m, q);
    }
};
$jscomp.polyfill = function (f, h, m, q) {
  h &&
    ($jscomp.ISOLATE_POLYFILLS
      ? $jscomp.polyfillIsolated(f, h, m, q)
      : $jscomp.polyfillUnisolated(f, h, m, q));
};
$jscomp.polyfillUnisolated = function (f, h, m, q) {
  m = $jscomp.global;
  f = f.split(".");
  for (q = 0; q < f.length - 1; q++) {
    var g = f[q];
    if (!(g in m)) return;
    m = m[g];
  }
  f = f[f.length - 1];
  q = m[f];
  h = h(q);
  h != q &&
    h != null &&
    $jscomp.defineProperty(m, f, { configurable: !0, writable: !0, value: h });
};
$jscomp.polyfillIsolated = function (f, h, m, q) {
  var g = f.split(".");
  f = g.length === 1;
  q = g[0];
  q = !f && q in $jscomp.polyfills ? $jscomp.polyfills : $jscomp.global;
  for (var r = 0; r < g.length - 1; r++) {
    var k = g[r];
    if (!(k in q)) return;
    q = q[k];
  }
  g = g[g.length - 1];
  m = $jscomp.IS_SYMBOL_NATIVE && m === "es6" ? q[g] : null;
  h = h(m);
  h != null &&
    (f
      ? $jscomp.defineProperty($jscomp.polyfills, g, {
          configurable: !0,
          writable: !0,
          value: h,
        })
      : h !== m &&
        ($jscomp.propertyToPolyfillSymbol[g] === void 0 &&
          ((m = (Math.random() * 1e9) >>> 0),
          ($jscomp.propertyToPolyfillSymbol[g] = $jscomp.IS_SYMBOL_NATIVE
            ? $jscomp.global.Symbol(g)
            : $jscomp.POLYFILL_PREFIX + m + "$" + g)),
        $jscomp.defineProperty(q, $jscomp.propertyToPolyfillSymbol[g], {
          configurable: !0,
          writable: !0,
          value: h,
        })));
};
$jscomp.getConstructImplementation = function () {
  function f() {
    function m() {}
    new m();
    Reflect.construct(m, [], function () {});
    return new m() instanceof m;
  }
  if (
    $jscomp.TRUST_ES6_POLYFILLS &&
    typeof Reflect != "undefined" &&
    Reflect.construct
  ) {
    if (f()) return Reflect.construct;
    var h = Reflect.construct;
    return function (m, q, g) {
      m = h(m, q);
      g && Reflect.setPrototypeOf(m, g.prototype);
      return m;
    };
  }
  return function (m, q, g) {
    g === void 0 && (g = m);
    g = $jscomp.objectCreate(g.prototype || Object.prototype);
    return Function.prototype.apply.call(m, g, q) || g;
  };
};
$jscomp.construct = { valueOf: $jscomp.getConstructImplementation }.valueOf();
$jscomp.underscoreProtoCanBeSet = function () {
  var f = { a: !0 },
    h = {};
  try {
    return (h.__proto__ = f), h.a;
  } catch (m) {}
  return !1;
};
$jscomp.setPrototypeOf =
  $jscomp.ASSUME_ES6 ||
  ($jscomp.TRUST_ES6_POLYFILLS && typeof Object.setPrototypeOf == "function")
    ? Object.setPrototypeOf
    : $jscomp.underscoreProtoCanBeSet()
    ? function (f, h) {
        f.__proto__ = h;
        if (f.__proto__ !== h) throw new TypeError(f + " is not extensible");
        return f;
      }
    : null;
$jscomp.inherits = function (f, h) {
  f.prototype = $jscomp.objectCreate(h.prototype);
  f.prototype.constructor = f;
  if ($jscomp.ASSUME_ES6 || $jscomp.setPrototypeOf) {
    var m = $jscomp.setPrototypeOf;
    m(f, h);
  } else
    for (m in h)
      if (m != "prototype")
        if (Object.defineProperties) {
          var q = Object.getOwnPropertyDescriptor(h, m);
          q && Object.defineProperty(f, m, q);
        } else f[m] = h[m];
  f.superClass_ = h.prototype;
};
$jscomp.arrayIteratorImpl = function (f) {
  var h = 0;
  return function () {
    return h < f.length ? { done: !1, value: f[h++] } : { done: !0 };
  };
};
$jscomp.arrayIterator = function (f) {
  return { next: $jscomp.arrayIteratorImpl(f) };
};
$jscomp.makeIterator = function (f) {
  var h = typeof Symbol != "undefined" && Symbol.iterator && f[Symbol.iterator];
  if (h) return h.call(f);
  if (typeof f.length == "number") return $jscomp.arrayIterator(f);
  throw Error(String(f) + " is not an iterable or ArrayLike");
};
$jscomp.arrayFromIterator = function (f) {
  for (var h, m = []; !(h = f.next()).done; ) m.push(h.value);
  return m;
};
$jscomp.arrayFromIterable = function (f) {
  return f instanceof Array
    ? f
    : $jscomp.arrayFromIterator($jscomp.makeIterator(f));
};
$jscomp.createTemplateTagFirstArg = function (f) {
  return $jscomp.createTemplateTagFirstArgWithRaw(f, f);
};
$jscomp.createTemplateTagFirstArgWithRaw = function (f, h) {
  f.raw = h;
  Object.freeze && (Object.freeze(f), Object.freeze(h));
  return f;
};
$jscomp.generator = {};
$jscomp.generator.ensureIteratorResultIsObject_ = function (f) {
  if (!(f instanceof Object))
    throw new TypeError("Iterator result " + f + " is not an object");
};
$jscomp.generator.Context = function () {
  this.isRunning_ = !1;
  this.yieldAllIterator_ = null;
  this.yieldResult = void 0;
  this.nextAddress = 1;
  this.finallyAddress_ = this.catchAddress_ = 0;
  this.finallyContexts_ = this.abruptCompletion_ = null;
};
$jscomp.generator.Context.prototype.start_ = function () {
  if (this.isRunning_) throw new TypeError("Generator is already running");
  this.isRunning_ = !0;
};
$jscomp.generator.Context.prototype.stop_ = function () {
  this.isRunning_ = !1;
};
$jscomp.generator.Context.prototype.jumpToErrorHandler_ = function () {
  this.nextAddress = this.catchAddress_ || this.finallyAddress_;
};
$jscomp.generator.Context.prototype.next_ = function (f) {
  this.yieldResult = f;
};
$jscomp.generator.Context.prototype.throw_ = function (f) {
  this.abruptCompletion_ = { exception: f, isException: !0 };
  this.jumpToErrorHandler_();
};
$jscomp.generator.Context.prototype.getNextAddressJsc = function () {
  return this.nextAddress;
};
$jscomp.generator.Context.prototype.getNextAddressJsc = function () {
  return this.nextAddress;
};
$jscomp.generator.Context.prototype.getYieldResultJsc = function () {
  return this.yieldResult;
};
$jscomp.generator.Context.prototype.getYieldResultJsc = function () {
  return this.yieldResult;
};
$jscomp.generator.Context.prototype.return = function (f) {
  this.abruptCompletion_ = { return: f };
  this.nextAddress = this.finallyAddress_;
};
$jscomp.generator.Context.prototype["return"] =
  $jscomp.generator.Context.prototype.return;
$jscomp.generator.Context.prototype.jumpThroughFinallyBlocks = function (f) {
  this.abruptCompletion_ = { jumpTo: f };
  this.nextAddress = this.finallyAddress_;
};
$jscomp.generator.Context.prototype.jumpThroughFinallyBlocks =
  $jscomp.generator.Context.prototype.jumpThroughFinallyBlocks;
$jscomp.generator.Context.prototype.yield = function (f, h) {
  this.nextAddress = h;
  return { value: f };
};
$jscomp.generator.Context.prototype.yield =
  $jscomp.generator.Context.prototype.yield;
$jscomp.generator.Context.prototype.yieldAll = function (f, h) {
  f = $jscomp.makeIterator(f);
  var m = f.next();
  $jscomp.generator.ensureIteratorResultIsObject_(m);
  if (m.done) (this.yieldResult = m.value), (this.nextAddress = h);
  else return (this.yieldAllIterator_ = f), this.yield(m.value, h);
};
$jscomp.generator.Context.prototype.yieldAll =
  $jscomp.generator.Context.prototype.yieldAll;
$jscomp.generator.Context.prototype.jumpTo = function (f) {
  this.nextAddress = f;
};
$jscomp.generator.Context.prototype.jumpTo =
  $jscomp.generator.Context.prototype.jumpTo;
$jscomp.generator.Context.prototype.jumpToEnd = function () {
  this.nextAddress = 0;
};
$jscomp.generator.Context.prototype.jumpToEnd =
  $jscomp.generator.Context.prototype.jumpToEnd;
$jscomp.generator.Context.prototype.setCatchFinallyBlocks = function (f, h) {
  this.catchAddress_ = f;
  h != void 0 && (this.finallyAddress_ = h);
};
$jscomp.generator.Context.prototype.setCatchFinallyBlocks =
  $jscomp.generator.Context.prototype.setCatchFinallyBlocks;
$jscomp.generator.Context.prototype.setFinallyBlock = function (f) {
  this.catchAddress_ = 0;
  this.finallyAddress_ = f || 0;
};
$jscomp.generator.Context.prototype.setFinallyBlock =
  $jscomp.generator.Context.prototype.setFinallyBlock;
$jscomp.generator.Context.prototype.leaveTryBlock = function (f, h) {
  this.nextAddress = f;
  this.catchAddress_ = h || 0;
};
$jscomp.generator.Context.prototype.leaveTryBlock =
  $jscomp.generator.Context.prototype.leaveTryBlock;
$jscomp.generator.Context.prototype.enterCatchBlock = function (f) {
  this.catchAddress_ = f || 0;
  f = this.abruptCompletion_.exception;
  this.abruptCompletion_ = null;
  return f;
};
$jscomp.generator.Context.prototype.enterCatchBlock =
  $jscomp.generator.Context.prototype.enterCatchBlock;
$jscomp.generator.Context.prototype.enterFinallyBlock = function (f, h, m) {
  m
    ? (this.finallyContexts_[m] = this.abruptCompletion_)
    : (this.finallyContexts_ = [this.abruptCompletion_]);
  this.catchAddress_ = f || 0;
  this.finallyAddress_ = h || 0;
};
$jscomp.generator.Context.prototype.enterFinallyBlock =
  $jscomp.generator.Context.prototype.enterFinallyBlock;
$jscomp.generator.Context.prototype.leaveFinallyBlock = function (f, h) {
  h = this.finallyContexts_.splice(h || 0)[0];
  if ((h = this.abruptCompletion_ = this.abruptCompletion_ || h)) {
    if (h.isException) return this.jumpToErrorHandler_();
    h.jumpTo != void 0 && this.finallyAddress_ < h.jumpTo
      ? ((this.nextAddress = h.jumpTo), (this.abruptCompletion_ = null))
      : (this.nextAddress = this.finallyAddress_);
  } else this.nextAddress = f;
};
$jscomp.generator.Context.prototype.leaveFinallyBlock =
  $jscomp.generator.Context.prototype.leaveFinallyBlock;
$jscomp.generator.Context.prototype.forIn = function (f) {
  return new $jscomp.generator.Context.PropertyIterator(f);
};
$jscomp.generator.Context.prototype.forIn =
  $jscomp.generator.Context.prototype.forIn;
$jscomp.generator.Context.PropertyIterator = function (f) {
  this.object_ = f;
  this.properties_ = [];
  for (var h in f) this.properties_.push(h);
  this.properties_.reverse();
};
$jscomp.generator.Context.PropertyIterator.prototype.getNext = function () {
  for (; this.properties_.length > 0; ) {
    var f = this.properties_.pop();
    if (f in this.object_) return f;
  }
  return null;
};
$jscomp.generator.Context.PropertyIterator.prototype.getNext =
  $jscomp.generator.Context.PropertyIterator.prototype.getNext;
$jscomp.generator.Engine_ = function (f) {
  this.context_ = new $jscomp.generator.Context();
  this.program_ = f;
};
$jscomp.generator.Engine_.prototype.next_ = function (f) {
  this.context_.start_();
  if (this.context_.yieldAllIterator_)
    return this.yieldAllStep_(
      this.context_.yieldAllIterator_.next,
      f,
      this.context_.next_
    );
  this.context_.next_(f);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.return_ = function (f) {
  this.context_.start_();
  var h = this.context_.yieldAllIterator_;
  if (h)
    return this.yieldAllStep_(
      "return" in h
        ? h["return"]
        : function (m) {
            return { value: m, done: !0 };
          },
      f,
      this.context_.return
    );
  this.context_.return(f);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.throw_ = function (f) {
  this.context_.start_();
  if (this.context_.yieldAllIterator_)
    return this.yieldAllStep_(
      this.context_.yieldAllIterator_["throw"],
      f,
      this.context_.next_
    );
  this.context_.throw_(f);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.yieldAllStep_ = function (f, h, m) {
  try {
    var q = f.call(this.context_.yieldAllIterator_, h);
    $jscomp.generator.ensureIteratorResultIsObject_(q);
    if (!q.done) return this.context_.stop_(), q;
    var g = q.value;
  } catch (r) {
    return (
      (this.context_.yieldAllIterator_ = null),
      this.context_.throw_(r),
      this.nextStep_()
    );
  }
  this.context_.yieldAllIterator_ = null;
  m.call(this.context_, g);
  return this.nextStep_();
};
$jscomp.generator.Engine_.prototype.nextStep_ = function () {
  for (; this.context_.nextAddress; )
    try {
      var f = this.program_(this.context_);
      if (f) return this.context_.stop_(), { value: f.value, done: !1 };
    } catch (h) {
      (this.context_.yieldResult = void 0), this.context_.throw_(h);
    }
  this.context_.stop_();
  if (this.context_.abruptCompletion_) {
    f = this.context_.abruptCompletion_;
    this.context_.abruptCompletion_ = null;
    if (f.isException) throw f.exception;
    return { value: f.return, done: !0 };
  }
  return { value: void 0, done: !0 };
};
$jscomp.generator.Generator_ = function (f) {
  this.next = function (h) {
    return f.next_(h);
  };
  this.throw = function (h) {
    return f.throw_(h);
  };
  this.return = function (h) {
    return f.return_(h);
  };
  this[Symbol.iterator] = function () {
    return this;
  };
};
$jscomp.generator.createGenerator = function (f, h) {
  h = new $jscomp.generator.Generator_(new $jscomp.generator.Engine_(h));
  $jscomp.setPrototypeOf &&
    f.prototype &&
    $jscomp.setPrototypeOf(h, f.prototype);
  return h;
};
$jscomp.asyncExecutePromiseGenerator = function (f) {
  function h(q) {
    return f.next(q);
  }
  function m(q) {
    return f.throw(q);
  }
  return new Promise(function (q, g) {
    function r(k) {
      k.done ? q(k.value) : Promise.resolve(k.value).then(h, m).then(r, g);
    }
    r(f.next());
  });
};
$jscomp.asyncExecutePromiseGeneratorFunction = function (f) {
  return $jscomp.asyncExecutePromiseGenerator(f());
};
$jscomp.asyncExecutePromiseGeneratorProgram = function (f) {
  return $jscomp.asyncExecutePromiseGenerator(
    new $jscomp.generator.Generator_(new $jscomp.generator.Engine_(f))
  );
};
$jscomp.polyfill(
  "globalThis",
  function (f) {
    return f || $jscomp.global;
  },
  "es_2020",
  "es3"
);
$jscomp.polyfill(
  "Reflect",
  function (f) {
    return f ? f : {};
  },
  "es6",
  "es3"
);
$jscomp.polyfill(
  "Reflect.construct",
  function (f) {
    return $jscomp.construct;
  },
  "es6",
  "es3"
);
$jscomp.polyfill(
  "Reflect.setPrototypeOf",
  function (f) {
    if (f) return f;
    if ($jscomp.setPrototypeOf) {
      var h = $jscomp.setPrototypeOf;
      return function (m, q) {
        try {
          return h(m, q), !0;
        } catch (g) {
          return !1;
        }
      };
    }
    return null;
  },
  "es6",
  "es5"
);
$jscomp.initSymbol = function () {};
$jscomp.polyfill(
  "Symbol",
  function (f) {
    if (f) return f;
    var h = function (r, k) {
      this.$jscomp$symbol$id_ = r;
      $jscomp.defineProperty(this, "description", {
        configurable: !0,
        writable: !0,
        value: k,
      });
    };
    h.prototype.toString = function () {
      return this.$jscomp$symbol$id_;
    };
    var m = "jscomp_symbol_" + ((Math.random() * 1e9) >>> 0) + "_",
      q = 0,
      g = function (r) {
        if (this instanceof g)
          throw new TypeError("Symbol is not a constructor");
        return new h(m + (r || "") + "_" + q++, r);
      };
    return g;
  },
  "es6",
  "es3"
);
$jscomp.polyfill(
  "Symbol.iterator",
  function (f) {
    if (f) return f;
    f = Symbol("Symbol.iterator");
    $jscomp.defineProperty(Array.prototype, f, {
      configurable: !0,
      writable: !0,
      value: function () {
        return $jscomp.iteratorPrototype($jscomp.arrayIteratorImpl(this));
      },
    });
    return f;
  },
  "es6",
  "es3"
);
$jscomp.iteratorPrototype = function (f) {
  f = { next: f };
  f[Symbol.iterator] = function () {
    return this;
  };
  return f;
};
$jscomp.polyfill(
  "Promise",
  function (f) {
    function h() {
      this.batch_ = null;
    }
    function m(k) {
      return k instanceof g
        ? k
        : new g(function (p, t) {
            p(k);
          });
    }
    if (
      f &&
      (!(
        $jscomp.FORCE_POLYFILL_PROMISE ||
        ($jscomp.FORCE_POLYFILL_PROMISE_WHEN_NO_UNHANDLED_REJECTION &&
          typeof $jscomp.global.PromiseRejectionEvent === "undefined")
      ) ||
        !$jscomp.global.Promise ||
        $jscomp.global.Promise.toString().indexOf("[native code]") === -1)
    )
      return f;
    h.prototype.asyncExecute = function (k) {
      if (this.batch_ == null) {
        this.batch_ = [];
        var p = this;
        this.asyncExecuteFunction(function () {
          p.executeBatch_();
        });
      }
      this.batch_.push(k);
    };
    var q = $jscomp.global.setTimeout;
    h.prototype.asyncExecuteFunction = function (k) {
      q(k, 0);
    };
    h.prototype.executeBatch_ = function () {
      for (; this.batch_ && this.batch_.length; ) {
        var k = this.batch_;
        this.batch_ = [];
        for (var p = 0; p < k.length; ++p) {
          var t = k[p];
          k[p] = null;
          try {
            t();
          } catch (w) {
            this.asyncThrow_(w);
          }
        }
      }
      this.batch_ = null;
    };
    h.prototype.asyncThrow_ = function (k) {
      this.asyncExecuteFunction(function () {
        throw k;
      });
    };
    var g = function (k) {
      this.state_ = 0;
      this.result_ = void 0;
      this.onSettledCallbacks_ = [];
      this.isRejectionHandled_ = !1;
      var p = this.createResolveAndReject_();
      try {
        k(p.resolve, p.reject);
      } catch (t) {
        p.reject(t);
      }
    };
    g.prototype.createResolveAndReject_ = function () {
      function k(w) {
        return function (A) {
          t || ((t = !0), w.call(p, A));
        };
      }
      var p = this,
        t = !1;
      return { resolve: k(this.resolveTo_), reject: k(this.reject_) };
    };
    g.prototype.resolveTo_ = function (k) {
      if (k === this)
        this.reject_(new TypeError("A Promise cannot resolve to itself"));
      else if (k instanceof g) this.settleSameAsPromise_(k);
      else {
        a: switch (typeof k) {
          case "object":
            var p = k != null;
            break a;
          case "function":
            p = !0;
            break a;
          default:
            p = !1;
        }
        p ? this.resolveToNonPromiseObj_(k) : this.fulfill_(k);
      }
    };
    g.prototype.resolveToNonPromiseObj_ = function (k) {
      var p = void 0;
      try {
        p = k.then;
      } catch (t) {
        this.reject_(t);
        return;
      }
      typeof p == "function"
        ? this.settleSameAsThenable_(p, k)
        : this.fulfill_(k);
    };
    g.prototype.reject_ = function (k) {
      this.settle_(2, k);
    };
    g.prototype.fulfill_ = function (k) {
      this.settle_(1, k);
    };
    g.prototype.settle_ = function (k, p) {
      if (this.state_ != 0)
        throw Error(
          "Cannot settle(" +
            k +
            ", " +
            p +
            "): Promise already settled in state" +
            this.state_
        );
      this.state_ = k;
      this.result_ = p;
      this.state_ === 2 && this.scheduleUnhandledRejectionCheck_();
      this.executeOnSettledCallbacks_();
    };
    g.prototype.scheduleUnhandledRejectionCheck_ = function () {
      var k = this;
      q(function () {
        if (k.notifyUnhandledRejection_()) {
          var p = $jscomp.global.console;
          typeof p !== "undefined" && p.error(k.result_);
        }
      }, 1);
    };
    g.prototype.notifyUnhandledRejection_ = function () {
      if (this.isRejectionHandled_) return !1;
      var k = $jscomp.global.CustomEvent,
        p = $jscomp.global.Event,
        t = $jscomp.global.dispatchEvent;
      if (typeof t === "undefined") return !0;
      typeof k === "function"
        ? (k = new k("unhandledrejection", { cancelable: !0 }))
        : typeof p === "function"
        ? (k = new p("unhandledrejection", { cancelable: !0 }))
        : ((k = $jscomp.global.document.createEvent("CustomEvent")),
          k.initCustomEvent("unhandledrejection", !1, !0, k));
      k.promise = this;
      k.reason = this.result_;
      return t(k);
    };
    g.prototype.executeOnSettledCallbacks_ = function () {
      if (this.onSettledCallbacks_ != null) {
        for (var k = 0; k < this.onSettledCallbacks_.length; ++k)
          r.asyncExecute(this.onSettledCallbacks_[k]);
        this.onSettledCallbacks_ = null;
      }
    };
    var r = new h();
    g.prototype.settleSameAsPromise_ = function (k) {
      var p = this.createResolveAndReject_();
      k.callWhenSettled_(p.resolve, p.reject);
    };
    g.prototype.settleSameAsThenable_ = function (k, p) {
      var t = this.createResolveAndReject_();
      try {
        k.call(p, t.resolve, t.reject);
      } catch (w) {
        t.reject(w);
      }
    };
    g.prototype.then = function (k, p) {
      function t(B, z) {
        return typeof B == "function"
          ? function (H) {
              try {
                w(B(H));
              } catch (D) {
                A(D);
              }
            }
          : z;
      }
      var w,
        A,
        F = new g(function (B, z) {
          w = B;
          A = z;
        });
      this.callWhenSettled_(t(k, w), t(p, A));
      return F;
    };
    g.prototype.catch = function (k) {
      return this.then(void 0, k);
    };
    g.prototype.callWhenSettled_ = function (k, p) {
      function t() {
        switch (w.state_) {
          case 1:
            k(w.result_);
            break;
          case 2:
            p(w.result_);
            break;
          default:
            throw Error("Unexpected state: " + w.state_);
        }
      }
      var w = this;
      this.onSettledCallbacks_ == null
        ? r.asyncExecute(t)
        : this.onSettledCallbacks_.push(t);
      this.isRejectionHandled_ = !0;
    };
    g.resolve = m;
    g.reject = function (k) {
      return new g(function (p, t) {
        t(k);
      });
    };
    g.race = function (k) {
      return new g(function (p, t) {
        for (
          var w = $jscomp.makeIterator(k), A = w.next();
          !A.done;
          A = w.next()
        )
          m(A.value).callWhenSettled_(p, t);
      });
    };
    g.all = function (k) {
      var p = $jscomp.makeIterator(k),
        t = p.next();
      return t.done
        ? m([])
        : new g(function (w, A) {
            function F(H) {
              return function (D) {
                B[H] = D;
                z--;
                z == 0 && w(B);
              };
            }
            var B = [],
              z = 0;
            do
              B.push(void 0),
                z++,
                m(t.value).callWhenSettled_(F(B.length - 1), A),
                (t = p.next());
            while (!t.done);
          });
    };
    return g;
  },
  "es6",
  "es3"
);
$jscomp.checkStringArgs = function (f, h, m) {
  if (f == null)
    throw new TypeError(
      "The 'this' value for String.prototype." +
        m +
        " must not be null or undefined"
    );
  if (h instanceof RegExp)
    throw new TypeError(
      "First argument to String.prototype." +
        m +
        " must not be a regular expression"
    );
  return f + "";
};
$jscomp.polyfill(
  "String.prototype.startsWith",
  function (f) {
    return f
      ? f
      : function (h, m) {
          var q = $jscomp.checkStringArgs(this, h, "startsWith");
          h += "";
          var g = q.length,
            r = h.length;
          m = Math.max(0, Math.min(m | 0, q.length));
          for (var k = 0; k < r && m < g; ) if (q[m++] != h[k++]) return !1;
          return k >= r;
        };
  },
  "es6",
  "es3"
);
$jscomp.polyfill(
  "String.prototype.codePointAt",
  function (f) {
    return f
      ? f
      : function (h) {
          var m = $jscomp.checkStringArgs(this, null, "codePointAt"),
            q = m.length;
          h = Number(h) || 0;
          if (h >= 0 && h < q) {
            h |= 0;
            var g = m.charCodeAt(h);
            if (g < 55296 || g > 56319 || h + 1 === q) return g;
            h = m.charCodeAt(h + 1);
            return h < 56320 || h > 57343 ? g : (g - 55296) * 1024 + h + 9216;
          }
        };
  },
  "es6",
  "es3"
);
var DracoDecoderModule = (function () {
  var f,
    h,
    m =
      (f = globalThis.document) == null
        ? void 0
        : (h = f.currentScript) == null
        ? void 0
        : h.src;
  return function (q) {
    function g() {
      this.ptr = za();
      C(g)[this.ptr] = this;
    }
    function r() {
      this.ptr = Aa();
      C(r)[this.ptr] = this;
    }
    function k() {
      this.ptr = Ba();
      C(k)[this.ptr] = this;
    }
    function p() {
      this.ptr = Ca();
      C(p)[this.ptr] = this;
    }
    function t() {
      this.ptr = Da();
      C(t)[this.ptr] = this;
    }
    function w() {
      this.ptr = Ea();
      C(w)[this.ptr] = this;
    }
    function A() {
      this.ptr = Fa();
      C(A)[this.ptr] = this;
    }
    function F() {
      this.ptr = Ga();
      C(F)[this.ptr] = this;
    }
    function B() {
      this.ptr = Ha();
      C(B)[this.ptr] = this;
    }
    function z() {
      throw "cannot construct a Status, no constructor in IDL";
    }
    function H() {
      this.ptr = Ia();
      C(H)[this.ptr] = this;
    }
    function D() {
      this.ptr = Ja();
      C(D)[this.ptr] = this;
    }
    function I() {
      this.ptr = Ka();
      C(I)[this.ptr] = this;
    }
    function J() {
      this.ptr = La();
      C(J)[this.ptr] = this;
    }
    function G() {
      this.ptr = Ma();
      C(G)[this.ptr] = this;
    }
    function x() {
      this.ptr = Na();
      C(x)[this.ptr] = this;
    }
    function O() {
      this.ptr = Oa();
      C(O)[this.ptr] = this;
    }
    function K() {
      this.ptr = Pa();
      C(K)[this.ptr] = this;
    }
    function M() {
      this.ptr = Qa();
      C(M)[this.ptr] = this;
    }
    function R() {
      throw "cannot construct a VoidPtr, no constructor in IDL";
    }
    function ka(l) {
      if (typeof l === "object") {
        for (var a = u.alloc(l, P), b = 0; b < l.length; b++) P[a + b] = l[b];
        return a;
      }
      return l;
    }
    function S(l) {
      if (typeof l === "string") {
        l = Ra(l);
        for (var a = u.alloc(l, P), b = 0; b < l.length; b++) P[a + b] = l[b];
        return a;
      }
      return l;
    }
    function Id(l) {
      return l.__class__;
    }
    function Jd(l) {
      return l.ptr;
    }
    function Kd(l, a) {
      return l.ptr === a.ptr;
    }
    function Ld(l) {
      if (!l.__destroy__)
        throw "Error: Cannot destroy object. (Did you create it yourself?)";
      l.__destroy__();
      delete C(l.__class__)[l.ptr];
    }
    function Md(l, a) {
      return N(l.ptr, a);
    }
    function N(l, a) {
      var b = C(a),
        d = b[l];
      if (d) return d;
      d = Object.create((a || y).prototype);
      d.ptr = l;
      return (b[l] = d);
    }
    function C(l) {
      return (l || y).__cache__;
    }
    function y() {}
    function Nd() {
      var l, a, b;
      return (0, $jscomp.asyncExecutePromiseGeneratorProgram)(function (d) {
        if (d.getNextAddressJsc() == 1) {
          Od();
          l = c.setStatus;
          if (!l) return d.jumpTo(2);
          l("Running...");
          return d.yield(
            new Promise(function (n) {
              return setTimeout(n, 1);
            }),
            3
          );
        }
        d.getNextAddressJsc() != 2 && setTimeout(l, 1, "");
        if (la) return d.return();
        ma = !0;
        Z(na);
        aa.g();
        (b = (a = c).onRuntimeInitialized) == null || b.call(a);
        Pd();
        d.jumpToEnd();
      });
    }
    function Qd() {
      function l(e) {
        e = aa = e.exports;
        c._webidl_free = e.h;
        c._free = e.i;
        c._webidl_malloc = e.j;
        c._malloc = e.k;
        Sa = c._emscripten_bind_VoidPtr___destroy___0 = e.l;
        Qa = c._emscripten_bind_DecoderBuffer_DecoderBuffer_0 = e.m;
        Ta = c._emscripten_bind_DecoderBuffer_Init_2 = e.n;
        Ua = c._emscripten_bind_DecoderBuffer___destroy___0 = e.o;
        Pa =
          c._emscripten_bind_AttributeTransformData_AttributeTransformData_0 =
            e.p;
        Va = c._emscripten_bind_AttributeTransformData_transform_type_0 = e.q;
        Wa = c._emscripten_bind_AttributeTransformData___destroy___0 = e.r;
        Oa = c._emscripten_bind_GeometryAttribute_GeometryAttribute_0 = e.s;
        Xa = c._emscripten_bind_GeometryAttribute___destroy___0 = e.t;
        Na = c._emscripten_bind_PointAttribute_PointAttribute_0 = e.u;
        Ya = c._emscripten_bind_PointAttribute_size_0 = e.v;
        Za = c._emscripten_bind_PointAttribute_GetAttributeTransformData_0 =
          e.w;
        $a = c._emscripten_bind_PointAttribute_attribute_type_0 = e.x;
        ab = c._emscripten_bind_PointAttribute_data_type_0 = e.y;
        bb = c._emscripten_bind_PointAttribute_num_components_0 = e.z;
        cb = c._emscripten_bind_PointAttribute_normalized_0 = e.A;
        db = c._emscripten_bind_PointAttribute_byte_stride_0 = e.B;
        eb = c._emscripten_bind_PointAttribute_byte_offset_0 = e.C;
        fb = c._emscripten_bind_PointAttribute_unique_id_0 = e.D;
        gb = c._emscripten_bind_PointAttribute___destroy___0 = e.E;
        Ma =
          c._emscripten_bind_AttributeQuantizationTransform_AttributeQuantizationTransform_0 =
            e.F;
        hb =
          c._emscripten_bind_AttributeQuantizationTransform_InitFromAttribute_1 =
            e.G;
        ib =
          c._emscripten_bind_AttributeQuantizationTransform_quantization_bits_0 =
            e.H;
        jb = c._emscripten_bind_AttributeQuantizationTransform_min_value_1 =
          e.I;
        kb = c._emscripten_bind_AttributeQuantizationTransform_range_0 = e.J;
        lb = c._emscripten_bind_AttributeQuantizationTransform___destroy___0 =
          e.K;
        La =
          c._emscripten_bind_AttributeOctahedronTransform_AttributeOctahedronTransform_0 =
            e.L;
        mb =
          c._emscripten_bind_AttributeOctahedronTransform_InitFromAttribute_1 =
            e.M;
        nb =
          c._emscripten_bind_AttributeOctahedronTransform_quantization_bits_0 =
            e.N;
        ob = c._emscripten_bind_AttributeOctahedronTransform___destroy___0 =
          e.O;
        Ka = c._emscripten_bind_PointCloud_PointCloud_0 = e.P;
        pb = c._emscripten_bind_PointCloud_num_attributes_0 = e.Q;
        qb = c._emscripten_bind_PointCloud_num_points_0 = e.R;
        rb = c._emscripten_bind_PointCloud___destroy___0 = e.S;
        Ja = c._emscripten_bind_Mesh_Mesh_0 = e.T;
        sb = c._emscripten_bind_Mesh_num_faces_0 = e.U;
        tb = c._emscripten_bind_Mesh_num_attributes_0 = e.V;
        ub = c._emscripten_bind_Mesh_num_points_0 = e.W;
        vb = c._emscripten_bind_Mesh___destroy___0 = e.X;
        Ia = c._emscripten_bind_Metadata_Metadata_0 = e.Y;
        wb = c._emscripten_bind_Metadata___destroy___0 = e.Z;
        xb = c._emscripten_bind_Status_code_0 = e._;
        yb = c._emscripten_bind_Status_ok_0 = e.$;
        zb = c._emscripten_bind_Status_error_msg_0 = e.aa;
        Ab = c._emscripten_bind_Status___destroy___0 = e.ba;
        Ha = c._emscripten_bind_DracoFloat32Array_DracoFloat32Array_0 = e.ca;
        Bb = c._emscripten_bind_DracoFloat32Array_GetValue_1 = e.da;
        Cb = c._emscripten_bind_DracoFloat32Array_size_0 = e.ea;
        Db = c._emscripten_bind_DracoFloat32Array___destroy___0 = e.fa;
        Ga = c._emscripten_bind_DracoInt8Array_DracoInt8Array_0 = e.ga;
        Eb = c._emscripten_bind_DracoInt8Array_GetValue_1 = e.ha;
        Fb = c._emscripten_bind_DracoInt8Array_size_0 = e.ia;
        Gb = c._emscripten_bind_DracoInt8Array___destroy___0 = e.ja;
        Fa = c._emscripten_bind_DracoUInt8Array_DracoUInt8Array_0 = e.ka;
        Hb = c._emscripten_bind_DracoUInt8Array_GetValue_1 = e.la;
        Ib = c._emscripten_bind_DracoUInt8Array_size_0 = e.ma;
        Jb = c._emscripten_bind_DracoUInt8Array___destroy___0 = e.na;
        Ea = c._emscripten_bind_DracoInt16Array_DracoInt16Array_0 = e.oa;
        Kb = c._emscripten_bind_DracoInt16Array_GetValue_1 = e.pa;
        Lb = c._emscripten_bind_DracoInt16Array_size_0 = e.qa;
        Mb = c._emscripten_bind_DracoInt16Array___destroy___0 = e.ra;
        Da = c._emscripten_bind_DracoUInt16Array_DracoUInt16Array_0 = e.sa;
        Nb = c._emscripten_bind_DracoUInt16Array_GetValue_1 = e.ta;
        Ob = c._emscripten_bind_DracoUInt16Array_size_0 = e.ua;
        Pb = c._emscripten_bind_DracoUInt16Array___destroy___0 = e.va;
        Ca = c._emscripten_bind_DracoInt32Array_DracoInt32Array_0 = e.wa;
        Qb = c._emscripten_bind_DracoInt32Array_GetValue_1 = e.xa;
        Rb = c._emscripten_bind_DracoInt32Array_size_0 = e.ya;
        Sb = c._emscripten_bind_DracoInt32Array___destroy___0 = e.za;
        Ba = c._emscripten_bind_DracoUInt32Array_DracoUInt32Array_0 = e.Aa;
        Tb = c._emscripten_bind_DracoUInt32Array_GetValue_1 = e.Ba;
        Ub = c._emscripten_bind_DracoUInt32Array_size_0 = e.Ca;
        Vb = c._emscripten_bind_DracoUInt32Array___destroy___0 = e.Da;
        Aa = c._emscripten_bind_MetadataQuerier_MetadataQuerier_0 = e.Ea;
        Wb = c._emscripten_bind_MetadataQuerier_HasEntry_2 = e.Fa;
        Xb = c._emscripten_bind_MetadataQuerier_GetIntEntry_2 = e.Ga;
        Yb = c._emscripten_bind_MetadataQuerier_GetIntEntryArray_3 = e.Ha;
        Zb = c._emscripten_bind_MetadataQuerier_GetDoubleEntry_2 = e.Ia;
        $b = c._emscripten_bind_MetadataQuerier_GetStringEntry_2 = e.Ja;
        ac = c._emscripten_bind_MetadataQuerier_NumEntries_1 = e.Ka;
        bc = c._emscripten_bind_MetadataQuerier_GetEntryName_2 = e.La;
        cc = c._emscripten_bind_MetadataQuerier___destroy___0 = e.Ma;
        za = c._emscripten_bind_Decoder_Decoder_0 = e.Na;
        dc = c._emscripten_bind_Decoder_DecodeArrayToPointCloud_3 = e.Oa;
        ec = c._emscripten_bind_Decoder_DecodeArrayToMesh_3 = e.Pa;
        fc = c._emscripten_bind_Decoder_GetAttributeId_2 = e.Qa;
        hc = c._emscripten_bind_Decoder_GetAttributeIdByName_2 = e.Ra;
        ic = c._emscripten_bind_Decoder_GetAttributeIdByMetadataEntry_3 = e.Sa;
        jc = c._emscripten_bind_Decoder_GetAttribute_2 = e.Ta;
        kc = c._emscripten_bind_Decoder_GetAttributeByUniqueId_2 = e.Ua;
        lc = c._emscripten_bind_Decoder_GetMetadata_1 = e.Va;
        mc = c._emscripten_bind_Decoder_GetAttributeMetadata_2 = e.Wa;
        nc = c._emscripten_bind_Decoder_GetFaceFromMesh_3 = e.Xa;
        oc = c._emscripten_bind_Decoder_GetTriangleStripsFromMesh_2 = e.Ya;
        pc = c._emscripten_bind_Decoder_GetTrianglesUInt16Array_3 = e.Za;
        qc = c._emscripten_bind_Decoder_GetTrianglesUInt32Array_3 = e._a;
        rc = c._emscripten_bind_Decoder_GetAttributeFloat_3 = e.$a;
        sc = c._emscripten_bind_Decoder_GetAttributeFloatForAllPoints_3 = e.ab;
        tc = c._emscripten_bind_Decoder_GetAttributeIntForAllPoints_3 = e.bb;
        uc = c._emscripten_bind_Decoder_GetAttributeInt8ForAllPoints_3 = e.cb;
        vc = c._emscripten_bind_Decoder_GetAttributeUInt8ForAllPoints_3 = e.db;
        wc = c._emscripten_bind_Decoder_GetAttributeInt16ForAllPoints_3 = e.eb;
        xc = c._emscripten_bind_Decoder_GetAttributeUInt16ForAllPoints_3 = e.fb;
        yc = c._emscripten_bind_Decoder_GetAttributeInt32ForAllPoints_3 = e.gb;
        zc = c._emscripten_bind_Decoder_GetAttributeUInt32ForAllPoints_3 = e.hb;
        Ac = c._emscripten_bind_Decoder_GetAttributeDataArrayForAllPoints_5 =
          e.ib;
        Bc = c._emscripten_bind_Decoder_SkipAttributeTransform_1 = e.jb;
        Cc = c._emscripten_bind_Decoder_GetEncodedGeometryType_Deprecated_1 =
          e.kb;
        Dc = c._emscripten_bind_Decoder_DecodeBufferToPointCloud_2 = e.lb;
        Ec = c._emscripten_bind_Decoder_DecodeBufferToMesh_2 = e.mb;
        Fc = c._emscripten_bind_Decoder___destroy___0 = e.nb;
        Gc =
          c._emscripten_enum_draco_AttributeTransformType_ATTRIBUTE_INVALID_TRANSFORM =
            e.ob;
        Hc =
          c._emscripten_enum_draco_AttributeTransformType_ATTRIBUTE_NO_TRANSFORM =
            e.pb;
        Ic =
          c._emscripten_enum_draco_AttributeTransformType_ATTRIBUTE_QUANTIZATION_TRANSFORM =
            e.qb;
        Jc =
          c._emscripten_enum_draco_AttributeTransformType_ATTRIBUTE_OCTAHEDRON_TRANSFORM =
            e.rb;
        Kc = c._emscripten_enum_draco_GeometryAttribute_Type_INVALID = e.sb;
        Lc = c._emscripten_enum_draco_GeometryAttribute_Type_POSITION = e.tb;
        Mc = c._emscripten_enum_draco_GeometryAttribute_Type_NORMAL = e.ub;
        Nc = c._emscripten_enum_draco_GeometryAttribute_Type_COLOR = e.vb;
        Oc = c._emscripten_enum_draco_GeometryAttribute_Type_TEX_COORD = e.wb;
        Pc = c._emscripten_enum_draco_GeometryAttribute_Type_GENERIC = e.xb;
        Qc =
          c._emscripten_enum_draco_EncodedGeometryType_INVALID_GEOMETRY_TYPE =
            e.yb;
        Rc = c._emscripten_enum_draco_EncodedGeometryType_POINT_CLOUD = e.zb;
        Sc = c._emscripten_enum_draco_EncodedGeometryType_TRIANGULAR_MESH =
          e.Ab;
        Tc = c._emscripten_enum_draco_DataType_DT_INVALID = e.Bb;
        Uc = c._emscripten_enum_draco_DataType_DT_INT8 = e.Cb;
        Vc = c._emscripten_enum_draco_DataType_DT_UINT8 = e.Db;
        Wc = c._emscripten_enum_draco_DataType_DT_INT16 = e.Eb;
        Xc = c._emscripten_enum_draco_DataType_DT_UINT16 = e.Fb;
        Yc = c._emscripten_enum_draco_DataType_DT_INT32 = e.Gb;
        Zc = c._emscripten_enum_draco_DataType_DT_UINT32 = e.Hb;
        $c = c._emscripten_enum_draco_DataType_DT_INT64 = e.Ib;
        ad = c._emscripten_enum_draco_DataType_DT_UINT64 = e.Jb;
        bd = c._emscripten_enum_draco_DataType_DT_FLOAT32 = e.Kb;
        cd = c._emscripten_enum_draco_DataType_DT_FLOAT64 = e.Lb;
        dd = c._emscripten_enum_draco_DataType_DT_BOOL = e.Mb;
        ed = c._emscripten_enum_draco_DataType_DT_TYPES_COUNT = e.Nb;
        fd = c._emscripten_enum_draco_StatusCode_OK = e.Ob;
        gd = c._emscripten_enum_draco_StatusCode_DRACO_ERROR = e.Pb;
        hd = c._emscripten_enum_draco_StatusCode_IO_ERROR = e.Qb;
        id = c._emscripten_enum_draco_StatusCode_INVALID_PARAMETER = e.Rb;
        jd = c._emscripten_enum_draco_StatusCode_UNSUPPORTED_VERSION = e.Sb;
        kd = c._emscripten_enum_draco_StatusCode_UNKNOWN_VERSION = e.Tb;
        ba = e.f;
        ld();
        return aa;
      }
      var a, b, d, n;
      return (0, $jscomp.asyncExecutePromiseGeneratorProgram)(function (e) {
        if (e.getNextAddressJsc() == 1) {
          a = { a: md };
          if ((b = c.instantiateWasm))
            return e.return(
              new Promise(function (v) {
                b(a, function (E) {
                  return v(l(E));
                });
              })
            );
          ca != null || (ca = Rd("draco_decoder.wasm"));
          return e.yield(Sd(W, ca, a), 2);
        }
        d = e.getYieldResultJsc();
        n = l(d.instance);
        return e.return(n);
      });
    }
    function Sd(l, a, b) {
      var d, n, e;
      return (0, $jscomp.asyncExecutePromiseGeneratorProgram)(function (v) {
        switch (v.getNextAddressJsc()) {
          case 1:
            if (l || X(a) || oa) {
              v.jumpTo(2);
              break;
            }
            v.setCatchFinallyBlocks(3);
            d = fetch(a, { credentials: "same-origin" });
            return v.yield(WebAssembly.instantiateStreaming(d, b), 5);
          case 5:
            return (n = v.getYieldResultJsc()), v.return(n);
          case 3:
            (e = v.enterCatchBlock()),
              T("wasm streaming compile failed: " + e),
              T("falling back to ArrayBuffer instantiation");
          case 2:
            return v.return(Td(a, b));
        }
      });
    }
    function Td(l, a) {
      var b, d, n;
      return (0, $jscomp.asyncExecutePromiseGeneratorProgram)(function (e) {
        switch (e.getNextAddressJsc()) {
          case 1:
            return e.setCatchFinallyBlocks(2), e.yield(Ud(l), 4);
          case 4:
            return (
              (b = e.getYieldResultJsc()),
              e.yield(WebAssembly.instantiate(b, a), 5)
            );
          case 5:
            return (d = e.getYieldResultJsc()), e.return(d);
          case 2:
            (n = e.enterCatchBlock()),
              T("failed to asynchronously prepare wasm: " + n),
              U(n),
              e.jumpToEnd();
        }
      });
    }
    function Ud(l) {
      var a;
      return (0, $jscomp.asyncExecutePromiseGeneratorProgram)(function (b) {
        switch (b.getNextAddressJsc()) {
          case 1:
            if (W) {
              b.jumpTo(2);
              break;
            }
            b.setCatchFinallyBlocks(3);
            return b.yield(pa(l), 5);
          case 5:
            return (a = b.getYieldResultJsc()), b.return(new Uint8Array(a));
          case 3:
            b.enterCatchBlock();
          case 2:
            var d = b.return;
            if (l == ca && W) var n = new Uint8Array(W);
            else if (da) n = da(l);
            else throw "both async and sync fetching of the wasm failed";
            return d.call(b, n);
        }
      });
    }
    function U(l) {
      var a, b;
      (b = (a = c).onAbort) == null || b.call(a, l);
      l = "Aborted(" + l + ")";
      T(l);
      la = !0;
      throw new WebAssembly.RuntimeError(
        l + ". Build with -sASSERTIONS for more info."
      );
    }
    function Pd() {
      var l = c.postRun;
      l &&
        (typeof l == "function" && (l = [l]),
        ea.push.apply(ea, (0, $jscomp.arrayFromIterable)(l)));
      Z(ea);
    }
    function Od() {
      var l = c.preRun;
      l &&
        (typeof l == "function" && (l = [l]),
        fa.push.apply(fa, (0, $jscomp.arrayFromIterable)(l)));
      Z(fa);
    }
    function ld() {
      var l, a;
      ((l = P) == null ? 0 : (a = l.buffer) == null ? 0 : a.resizable) ||
        ((l = ba.buffer),
        (c.HEAP8 = P = new Int8Array(l)),
        (c.HEAP16 = new Int16Array(l)),
        (c.HEAPU8 = ha = new Uint8Array(l)),
        (c.HEAPU16 = new Uint16Array(l)),
        (c.HEAP32 = new Int32Array(l)),
        (c.HEAPU32 = Q = new Uint32Array(l)),
        (c.HEAPF32 = new Float32Array(l)),
        (c.HEAPF64 = new Float64Array(l)));
    }
    function Rd(l) {
      return c.locateFile ? c.locateFile(l, Y) : Y + l;
    }
    function Vd(l) {
      if (typeof l !== "string") return !1;
      l = l.split(".");
      return l.length < 2 || l.length > 3
        ? !1
        : l[0] == 1 && l[1] >= 0 && l[1] <= 5
        ? !0
        : l[0] != 0 || l[1] > 10
        ? !1
        : !0;
    }
    q = q === void 0 ? {} : q;
    var c,
      nd,
      ia,
      od,
      pd,
      qd,
      oa,
      qa,
      ra,
      Y,
      pa,
      da,
      sa,
      ta,
      T,
      W,
      la,
      X,
      ua,
      rd,
      ma,
      ca,
      P,
      Z,
      ea,
      fa,
      Q,
      L,
      sd,
      td,
      ud,
      vd,
      wd,
      va,
      xd,
      ha,
      yd,
      zd,
      Ad,
      wa,
      Bd,
      xa,
      Cd,
      ja,
      Dd,
      Ed,
      Fd,
      Ra,
      na,
      Gd,
      V,
      Sa,
      Qa,
      Ta,
      Ua,
      Pa,
      Va,
      Wa,
      Oa,
      Xa,
      Na,
      Ya,
      Za,
      $a,
      ab,
      bb,
      cb,
      db,
      eb,
      fb,
      gb,
      Ma,
      hb,
      ib,
      jb,
      kb,
      lb,
      La,
      mb,
      nb,
      ob,
      Ka,
      pb,
      qb,
      rb,
      Ja,
      sb,
      tb,
      ub,
      vb,
      Ia,
      wb,
      xb,
      yb,
      zb,
      Ab,
      Ha,
      Bb,
      Cb,
      Db,
      Ga,
      Eb,
      Fb,
      Gb,
      Fa,
      Hb,
      Ib,
      Jb,
      Ea,
      Kb,
      Lb,
      Mb,
      Da,
      Nb,
      Ob,
      Pb,
      Ca,
      Qb,
      Rb,
      Sb,
      Ba,
      Tb,
      Ub,
      Vb,
      Aa,
      Wb,
      Xb,
      Yb,
      Zb,
      $b,
      ac,
      bc,
      cc,
      za,
      dc,
      ec,
      fc,
      hc,
      ic,
      jc,
      kc,
      lc,
      mc,
      nc,
      oc,
      pc,
      qc,
      rc,
      sc,
      tc,
      uc,
      vc,
      wc,
      xc,
      yc,
      zc,
      Ac,
      Bc,
      Cc,
      Dc,
      Ec,
      Fc,
      Gc,
      Hc,
      Ic,
      Jc,
      Kc,
      Lc,
      Mc,
      Nc,
      Oc,
      Pc,
      Qc,
      Rc,
      Sc,
      Tc,
      Uc,
      Vc,
      Wc,
      Xc,
      Yc,
      Zc,
      $c,
      ad,
      bd,
      cd,
      dd,
      ed,
      fd,
      gd,
      hd,
      id,
      jd,
      kd,
      ba,
      md,
      aa,
      u;
    return (0, $jscomp.asyncExecutePromiseGeneratorProgram)(function (l) {
      if (l.getNextAddressJsc() == 1) {
        c = q;
        nd = !!globalThis.window;
        ia = !!globalThis.WorkerGlobalScope;
        oa =
          ((od = globalThis.process) == null
            ? void 0
            : (pd = od.versions) == null
            ? void 0
            : pd.node) &&
          ((qd = globalThis.process) == null ? void 0 : qd.type) != "renderer";
        ra = qa = !1;
        c.onRuntimeInitialized = function () {
          qa = !0;
          if (ra && typeof c.onModuleLoaded === "function") c.onModuleLoaded(c);
        };
        c.onModuleParsed = function () {
          ra = !0;
          if (qa && typeof c.onModuleLoaded === "function") c.onModuleLoaded(c);
        };
        c.isVersionSupported = Vd;
        typeof __filename != "undefined"
          ? (m = __filename)
          : ia && (m = self.location.href);
        Y = "";
        if (oa)
          (sa = require("node:fs")),
            (Y = __dirname + "/"),
            (da = function (a) {
              a = X(a) ? new URL(a) : a;
              return sa.readFileSync(a);
            }),
            (pa = function (a, b) {
              b = b === void 0 ? !0 : b;
              var d;
              return (0, $jscomp.asyncExecutePromiseGeneratorProgram)(function (
                n
              ) {
                a = X(a) ? new URL(a) : a;
                d = sa.readFileSync(a, b ? void 0 : "utf8");
                return n.return(d);
              });
            }),
            process.argv.length > 1 && process.argv[1].replace(/\\/g, "/"),
            process.argv.slice(2);
        else if (nd || ia) {
          try {
            Y = new URL(".", m).href;
          } catch (a) {}
          ia &&
            (da = function (a) {
              var b = new XMLHttpRequest();
              b.open("GET", a, !1);
              b.responseType = "arraybuffer";
              b.send(null);
              return new Uint8Array(b.response);
            });
          pa = function (a) {
            var b;
            return (0, $jscomp.asyncExecutePromiseGeneratorProgram)(function (
              d
            ) {
              if (d.getNextAddressJsc() == 1)
                return X(a)
                  ? d.return(
                      new Promise(function (n, e) {
                        var v = new XMLHttpRequest();
                        v.open("GET", a, !0);
                        v.responseType = "arraybuffer";
                        v.onload = function () {
                          v.status == 200 || (v.status == 0 && v.response)
                            ? n(v.response)
                            : e(v.status);
                        };
                        v.onerror = e;
                        v.send(null);
                      })
                    )
                  : d.yield(fetch(a, { credentials: "same-origin" }), 2);
              b = d.getYieldResultJsc();
              if (b.ok) return d.return(b.arrayBuffer());
              throw Error(b.status + " : " + b.url);
            });
          };
        }
        ta = console.log.bind(console);
        T = console.error.bind(console);
        la = !1;
        X = function (a) {
          return a.startsWith("file://");
        };
        ua = function () {};
        rd = function () {
          return ua.apply(this, arguments) || this;
        };
        $jscomp.inherits(rd, ua);
        ma = !1;
        Z = function (a) {
          for (; a.length > 0; ) a.shift()(c);
        };
        ea = [];
        fa = [];
        L = function (a) {
          this.excPtr = a;
          this.ptr = a - 24;
        };
        L.prototype.set_type = function (a) {
          Q[(this.ptr + 4) >> 2] = a;
        };
        L.prototype.get_type = function () {
          return Q[(this.ptr + 4) >> 2];
        };
        L.prototype.set_destructor = function (a) {
          Q[(this.ptr + 8) >> 2] = a;
        };
        L.prototype.get_destructor = function () {
          return Q[(this.ptr + 8) >> 2];
        };
        L.prototype.set_caught = function (a) {
          P[this.ptr + 12] = a ? 1 : 0;
        };
        L.prototype.get_caught = function () {
          return P[this.ptr + 12] != 0;
        };
        L.prototype.set_rethrown = function (a) {
          P[this.ptr + 13] = a ? 1 : 0;
        };
        L.prototype.get_rethrown = function () {
          return P[this.ptr + 13] != 0;
        };
        L.prototype.init = function (a, b) {
          this.set_adjusted_ptr(0);
          this.set_type(a);
          this.set_destructor(b);
        };
        L.prototype.set_adjusted_ptr = function (a) {
          Q[(this.ptr + 16) >> 2] = a;
        };
        L.prototype.get_adjusted_ptr = function () {
          return Q[(this.ptr + 16) >> 2];
        };
        sd = 0;
        td = function (a) {
          U();
        };
        ud = function (a, b, d) {
          new L(a).init(b, d);
          sd++;
          td(a);
        };
        vd = function () {
          return U("");
        };
        wd = function () {
          return 2147483648;
        };
        va = function (a, b) {
          return Math.ceil(a / b) * b;
        };
        xd = function (a) {
          var b = ba.buffer.byteLength;
          try {
            return ba.grow(((a - b + 65535) / 65536) | 0), ld(), 1;
          } catch (d) {}
        };
        yd = function (a) {
          var b = ha.length;
          a >>>= 0;
          var d = wd();
          if (a > d) return !1;
          for (var n = 1; n <= 4; n *= 2) {
            var e = b * (1 + 0.2 / n);
            e = Math.min(e, a + 100663296);
            e = Math.min(d, va(Math.max(a, e), 65536));
            if (xd(e)) return !0;
          }
          return !1;
        };
        zd = function (a) {
          return 52;
        };
        Ad = [null, [], []];
        wa = globalThis.TextDecoder && new TextDecoder();
        Bd = function (a, b, d, n) {
          d = b + d;
          if (n) return d;
          for (; a[b] && !(b >= d); ) ++b;
          return b;
        };
        xa = function (a, b, d, n) {
          b = b === void 0 ? 0 : b;
          d = Bd(a, b, d, n);
          if (d - b > 16 && a.buffer && wa) return wa.decode(a.subarray(b, d));
          for (n = ""; b < d; ) {
            var e = a[b++];
            if (e & 128) {
              var v = a[b++] & 63;
              if ((e & 224) == 192)
                n += String.fromCharCode(((e & 31) << 6) | v);
              else {
                var E = a[b++] & 63;
                e =
                  (e & 240) == 224
                    ? ((e & 15) << 12) | (v << 6) | E
                    : ((e & 7) << 18) | (v << 12) | (E << 6) | (a[b++] & 63);
                e < 65536
                  ? (n += String.fromCharCode(e))
                  : ((e -= 65536),
                    (n += String.fromCharCode(
                      55296 | (e >> 10),
                      56320 | (e & 1023)
                    )));
              }
            } else n += String.fromCharCode(e);
          }
          return n;
        };
        Cd = function (a, b) {
          var d = Ad[a];
          b && b !== 10
            ? d.push(b)
            : ((a === 1 ? ta : T)(xa(d)), (d.length = 0));
        };
        ja = function (a, b, d) {
          return a ? xa(ha, a, b, d) : "";
        };
        Dd = function (a, b, d, n) {
          for (var e = 0, v = 0; v < d; v++) {
            var E = Q[b >> 2],
              Hd = Q[(b + 4) >> 2];
            b += 8;
            for (var ya = 0; ya < Hd; ya++) Cd(a, ha[E + ya]);
            e += Hd;
          }
          Q[n >> 2] = e;
          return 0;
        };
        Ed = function (a) {
          for (var b = 0, d = 0; d < a.length; ++d) {
            var n = a.charCodeAt(d);
            n <= 127
              ? b++
              : n <= 2047
              ? (b += 2)
              : n >= 55296 && n <= 57343
              ? ((b += 4), ++d)
              : (b += 3);
          }
          return b;
        };
        Fd = function (a, b, d, n) {
          if (!(n > 0)) return 0;
          var e = d;
          n = d + n - 1;
          for (var v = 0; v < a.length; ++v) {
            var E = a.codePointAt(v);
            if (E <= 127) {
              if (d >= n) break;
              b[d++] = E;
            } else if (E <= 2047) {
              if (d + 1 >= n) break;
              b[d++] = 192 | (E >> 6);
              b[d++] = 128 | (E & 63);
            } else if (E <= 65535) {
              if (d + 2 >= n) break;
              b[d++] = 224 | (E >> 12);
              b[d++] = 128 | ((E >> 6) & 63);
              b[d++] = 128 | (E & 63);
            } else {
              if (d + 3 >= n) break;
              b[d++] = 240 | (E >> 18);
              b[d++] = 128 | ((E >> 12) & 63);
              b[d++] = 128 | ((E >> 6) & 63);
              b[d++] = 128 | (E & 63);
              v++;
            }
          }
          b[d] = 0;
          return d - e;
        };
        Ra = function (a, b, d) {
          d = d > 0 ? d : Ed(a) + 1;
          d = Array(d);
          a = Fd(a, d, 0, d.length);
          b && (d.length = a);
          return d;
        };
        na = [];
        Gd = function (a) {
          return na.push(a);
        };
        c.print && (ta = c.print);
        c.printErr && (T = c.printErr);
        c.wasmBinary && (W = c.wasmBinary);
        if ((V = c.preInit))
          for (typeof V == "function" && (c.preInit = V = [V]); V.length > 0; )
            V.shift()();
        md = { a: ud, e: vd, c: yd, d: zd, b: Dd };
        return l.yield(Qd(), 2);
      }
      if (l.getNextAddressJsc() != 3)
        return (aa = l.getYieldResultJsc()), l.yield(Nd(), 3);
      y.prototype = Object.create(y.prototype);
      y.prototype.constructor = y;
      y.prototype.__class__ = y;
      y.__cache__ = {};
      c.WrapperObject = y;
      c.getCache = C;
      c.wrapPointer = N;
      c.castObject = Md;
      c.NULL = N(0);
      c.destroy = Ld;
      c.compare = Kd;
      c.getPointer = Jd;
      c.getClass = Id;
      u = {
        buffer: 0,
        size: 0,
        pos: 0,
        temps: [],
        needed: 0,
        prepare: function () {
          if (u.needed) {
            for (var a = 0; a < u.temps.length; a++) c._webidl_free(u.temps[a]);
            u.temps.length = 0;
            c._webidl_free(u.buffer);
            u.buffer = 0;
            u.size += u.needed;
            u.needed = 0;
          }
          u.buffer ||
            ((u.size += 128),
            (u.buffer = c._webidl_malloc(u.size)),
            u.buffer || U(void 0));
          u.pos = 0;
        },
        alloc: function (a, b) {
          u.buffer || U(void 0);
          a = a.length * b.BYTES_PER_ELEMENT;
          a = va(a, 8);
          u.pos + a >= u.size
            ? (a > 0 || U(void 0),
              (u.needed += a),
              (b = c._webidl_malloc(a)),
              u.temps.push(b))
            : ((b = u.buffer + u.pos), (u.pos += a));
          return b;
        },
      };
      R.prototype = Object.create(y.prototype);
      R.prototype.constructor = R;
      R.prototype.__class__ = R;
      R.__cache__ = {};
      c.VoidPtr = R;
      R.prototype.__destroy__ = R.prototype.__destroy__ = function () {
        Sa(this.ptr);
      };
      M.prototype = Object.create(y.prototype);
      M.prototype.constructor = M;
      M.prototype.__class__ = M;
      M.__cache__ = {};
      c.DecoderBuffer = M;
      M.prototype.Init = M.prototype.Init = function (a, b) {
        var d = this.ptr;
        u.prepare();
        typeof a == "object" && (a = ka(a));
        b && typeof b === "object" && (b = b.ptr);
        Ta(d, a, b);
      };
      M.prototype.__destroy__ = M.prototype.__destroy__ = function () {
        Ua(this.ptr);
      };
      K.prototype = Object.create(y.prototype);
      K.prototype.constructor = K;
      K.prototype.__class__ = K;
      K.__cache__ = {};
      c.AttributeTransformData = K;
      K.prototype.transform_type = K.prototype.transform_type = function () {
        return Va(this.ptr);
      };
      K.prototype.__destroy__ = K.prototype.__destroy__ = function () {
        Wa(this.ptr);
      };
      O.prototype = Object.create(y.prototype);
      O.prototype.constructor = O;
      O.prototype.__class__ = O;
      O.__cache__ = {};
      c.GeometryAttribute = O;
      O.prototype.__destroy__ = O.prototype.__destroy__ = function () {
        Xa(this.ptr);
      };
      x.prototype = Object.create(y.prototype);
      x.prototype.constructor = x;
      x.prototype.__class__ = x;
      x.__cache__ = {};
      c.PointAttribute = x;
      x.prototype.size = x.prototype.size = function () {
        return Ya(this.ptr);
      };
      x.prototype.GetAttributeTransformData =
        x.prototype.GetAttributeTransformData = function () {
          return N(Za(this.ptr), K);
        };
      x.prototype.attribute_type = x.prototype.attribute_type = function () {
        return $a(this.ptr);
      };
      x.prototype.data_type = x.prototype.data_type = function () {
        return ab(this.ptr);
      };
      x.prototype.num_components = x.prototype.num_components = function () {
        return bb(this.ptr);
      };
      x.prototype.normalized = x.prototype.normalized = function () {
        return !!cb(this.ptr);
      };
      x.prototype.byte_stride = x.prototype.byte_stride = function () {
        return db(this.ptr);
      };
      x.prototype.byte_offset = x.prototype.byte_offset = function () {
        return eb(this.ptr);
      };
      x.prototype.unique_id = x.prototype.unique_id = function () {
        return fb(this.ptr);
      };
      x.prototype.__destroy__ = x.prototype.__destroy__ = function () {
        gb(this.ptr);
      };
      G.prototype = Object.create(y.prototype);
      G.prototype.constructor = G;
      G.prototype.__class__ = G;
      G.__cache__ = {};
      c.AttributeQuantizationTransform = G;
      G.prototype.InitFromAttribute = G.prototype.InitFromAttribute = function (
        a
      ) {
        var b = this.ptr;
        a && typeof a === "object" && (a = a.ptr);
        return !!hb(b, a);
      };
      G.prototype.quantization_bits = G.prototype.quantization_bits =
        function () {
          return ib(this.ptr);
        };
      G.prototype.min_value = G.prototype.min_value = function (a) {
        var b = this.ptr;
        a && typeof a === "object" && (a = a.ptr);
        return jb(b, a);
      };
      G.prototype.range = G.prototype.range = function () {
        return kb(this.ptr);
      };
      G.prototype.__destroy__ = G.prototype.__destroy__ = function () {
        lb(this.ptr);
      };
      J.prototype = Object.create(y.prototype);
      J.prototype.constructor = J;
      J.prototype.__class__ = J;
      J.__cache__ = {};
      c.AttributeOctahedronTransform = J;
      J.prototype.InitFromAttribute = J.prototype.InitFromAttribute = function (
        a
      ) {
        var b = this.ptr;
        a && typeof a === "object" && (a = a.ptr);
        return !!mb(b, a);
      };
      J.prototype.quantization_bits = J.prototype.quantization_bits =
        function () {
          return nb(this.ptr);
        };
      J.prototype.__destroy__ = J.prototype.__destroy__ = function () {
        ob(this.ptr);
      };
      I.prototype = Object.create(y.prototype);
      I.prototype.constructor = I;
      I.prototype.__class__ = I;
      I.__cache__ = {};
      c.PointCloud = I;
      I.prototype.num_attributes = I.prototype.num_attributes = function () {
        return pb(this.ptr);
      };
      I.prototype.num_points = I.prototype.num_points = function () {
        return qb(this.ptr);
      };
      I.prototype.__destroy__ = I.prototype.__destroy__ = function () {
        rb(this.ptr);
      };
      D.prototype = Object.create(y.prototype);
      D.prototype.constructor = D;
      D.prototype.__class__ = D;
      D.__cache__ = {};
      c.Mesh = D;
      D.prototype.num_faces = D.prototype.num_faces = function () {
        return sb(this.ptr);
      };
      D.prototype.num_attributes = D.prototype.num_attributes = function () {
        return tb(this.ptr);
      };
      D.prototype.num_points = D.prototype.num_points = function () {
        return ub(this.ptr);
      };
      D.prototype.__destroy__ = D.prototype.__destroy__ = function () {
        vb(this.ptr);
      };
      H.prototype = Object.create(y.prototype);
      H.prototype.constructor = H;
      H.prototype.__class__ = H;
      H.__cache__ = {};
      c.Metadata = H;
      H.prototype.__destroy__ = H.prototype.__destroy__ = function () {
        wb(this.ptr);
      };
      z.prototype = Object.create(y.prototype);
      z.prototype.constructor = z;
      z.prototype.__class__ = z;
      z.__cache__ = {};
      c.Status = z;
      z.prototype.code = z.prototype.code = function () {
        return xb(this.ptr);
      };
      z.prototype.ok = z.prototype.ok = function () {
        return !!yb(this.ptr);
      };
      z.prototype.error_msg = z.prototype.error_msg = function () {
        return ja(zb(this.ptr));
      };
      z.prototype.__destroy__ = z.prototype.__destroy__ = function () {
        Ab(this.ptr);
      };
      B.prototype = Object.create(y.prototype);
      B.prototype.constructor = B;
      B.prototype.__class__ = B;
      B.__cache__ = {};
      c.DracoFloat32Array = B;
      B.prototype.GetValue = B.prototype.GetValue = function (a) {
        var b = this.ptr;
        a && typeof a === "object" && (a = a.ptr);
        return Bb(b, a);
      };
      B.prototype.size = B.prototype.size = function () {
        return Cb(this.ptr);
      };
      B.prototype.__destroy__ = B.prototype.__destroy__ = function () {
        Db(this.ptr);
      };
      F.prototype = Object.create(y.prototype);
      F.prototype.constructor = F;
      F.prototype.__class__ = F;
      F.__cache__ = {};
      c.DracoInt8Array = F;
      F.prototype.GetValue = F.prototype.GetValue = function (a) {
        var b = this.ptr;
        a && typeof a === "object" && (a = a.ptr);
        return Eb(b, a);
      };
      F.prototype.size = F.prototype.size = function () {
        return Fb(this.ptr);
      };
      F.prototype.__destroy__ = F.prototype.__destroy__ = function () {
        Gb(this.ptr);
      };
      A.prototype = Object.create(y.prototype);
      A.prototype.constructor = A;
      A.prototype.__class__ = A;
      A.__cache__ = {};
      c.DracoUInt8Array = A;
      A.prototype.GetValue = A.prototype.GetValue = function (a) {
        var b = this.ptr;
        a && typeof a === "object" && (a = a.ptr);
        return Hb(b, a);
      };
      A.prototype.size = A.prototype.size = function () {
        return Ib(this.ptr);
      };
      A.prototype.__destroy__ = A.prototype.__destroy__ = function () {
        Jb(this.ptr);
      };
      w.prototype = Object.create(y.prototype);
      w.prototype.constructor = w;
      w.prototype.__class__ = w;
      w.__cache__ = {};
      c.DracoInt16Array = w;
      w.prototype.GetValue = w.prototype.GetValue = function (a) {
        var b = this.ptr;
        a && typeof a === "object" && (a = a.ptr);
        return Kb(b, a);
      };
      w.prototype.size = w.prototype.size = function () {
        return Lb(this.ptr);
      };
      w.prototype.__destroy__ = w.prototype.__destroy__ = function () {
        Mb(this.ptr);
      };
      t.prototype = Object.create(y.prototype);
      t.prototype.constructor = t;
      t.prototype.__class__ = t;
      t.__cache__ = {};
      c.DracoUInt16Array = t;
      t.prototype.GetValue = t.prototype.GetValue = function (a) {
        var b = this.ptr;
        a && typeof a === "object" && (a = a.ptr);
        return Nb(b, a);
      };
      t.prototype.size = t.prototype.size = function () {
        return Ob(this.ptr);
      };
      t.prototype.__destroy__ = t.prototype.__destroy__ = function () {
        Pb(this.ptr);
      };
      p.prototype = Object.create(y.prototype);
      p.prototype.constructor = p;
      p.prototype.__class__ = p;
      p.__cache__ = {};
      c.DracoInt32Array = p;
      p.prototype.GetValue = p.prototype.GetValue = function (a) {
        var b = this.ptr;
        a && typeof a === "object" && (a = a.ptr);
        return Qb(b, a);
      };
      p.prototype.size = p.prototype.size = function () {
        return Rb(this.ptr);
      };
      p.prototype.__destroy__ = p.prototype.__destroy__ = function () {
        Sb(this.ptr);
      };
      k.prototype = Object.create(y.prototype);
      k.prototype.constructor = k;
      k.prototype.__class__ = k;
      k.__cache__ = {};
      c.DracoUInt32Array = k;
      k.prototype.GetValue = k.prototype.GetValue = function (a) {
        var b = this.ptr;
        a && typeof a === "object" && (a = a.ptr);
        return Tb(b, a);
      };
      k.prototype.size = k.prototype.size = function () {
        return Ub(this.ptr);
      };
      k.prototype.__destroy__ = k.prototype.__destroy__ = function () {
        Vb(this.ptr);
      };
      r.prototype = Object.create(y.prototype);
      r.prototype.constructor = r;
      r.prototype.__class__ = r;
      r.__cache__ = {};
      c.MetadataQuerier = r;
      r.prototype.HasEntry = r.prototype.HasEntry = function (a, b) {
        var d = this.ptr;
        u.prepare();
        a && typeof a === "object" && (a = a.ptr);
        b = b && typeof b === "object" ? b.ptr : S(b);
        return !!Wb(d, a, b);
      };
      r.prototype.GetIntEntry = r.prototype.GetIntEntry = function (a, b) {
        var d = this.ptr;
        u.prepare();
        a && typeof a === "object" && (a = a.ptr);
        b = b && typeof b === "object" ? b.ptr : S(b);
        return Xb(d, a, b);
      };
      r.prototype.GetIntEntryArray = r.prototype.GetIntEntryArray = function (
        a,
        b,
        d
      ) {
        var n = this.ptr;
        u.prepare();
        a && typeof a === "object" && (a = a.ptr);
        b = b && typeof b === "object" ? b.ptr : S(b);
        d && typeof d === "object" && (d = d.ptr);
        Yb(n, a, b, d);
      };
      r.prototype.GetDoubleEntry = r.prototype.GetDoubleEntry = function (
        a,
        b
      ) {
        var d = this.ptr;
        u.prepare();
        a && typeof a === "object" && (a = a.ptr);
        b = b && typeof b === "object" ? b.ptr : S(b);
        return Zb(d, a, b);
      };
      r.prototype.GetStringEntry = r.prototype.GetStringEntry = function (
        a,
        b
      ) {
        var d = this.ptr;
        u.prepare();
        a && typeof a === "object" && (a = a.ptr);
        b = b && typeof b === "object" ? b.ptr : S(b);
        return ja($b(d, a, b));
      };
      r.prototype.NumEntries = r.prototype.NumEntries = function (a) {
        var b = this.ptr;
        a && typeof a === "object" && (a = a.ptr);
        return ac(b, a);
      };
      r.prototype.GetEntryName = r.prototype.GetEntryName = function (a, b) {
        var d = this.ptr;
        a && typeof a === "object" && (a = a.ptr);
        b && typeof b === "object" && (b = b.ptr);
        return ja(bc(d, a, b));
      };
      r.prototype.__destroy__ = r.prototype.__destroy__ = function () {
        cc(this.ptr);
      };
      g.prototype = Object.create(y.prototype);
      g.prototype.constructor = g;
      g.prototype.__class__ = g;
      g.__cache__ = {};
      c.Decoder = g;
      g.prototype.DecodeArrayToPointCloud =
        g.prototype.DecodeArrayToPointCloud = function (a, b, d) {
          var n = this.ptr;
          u.prepare();
          typeof a == "object" && (a = ka(a));
          b && typeof b === "object" && (b = b.ptr);
          d && typeof d === "object" && (d = d.ptr);
          return N(dc(n, a, b, d), z);
        };
      g.prototype.DecodeArrayToMesh = g.prototype.DecodeArrayToMesh = function (
        a,
        b,
        d
      ) {
        var n = this.ptr;
        u.prepare();
        typeof a == "object" && (a = ka(a));
        b && typeof b === "object" && (b = b.ptr);
        d && typeof d === "object" && (d = d.ptr);
        return N(ec(n, a, b, d), z);
      };
      g.prototype.GetAttributeId = g.prototype.GetAttributeId = function (
        a,
        b
      ) {
        var d = this.ptr;
        a && typeof a === "object" && (a = a.ptr);
        b && typeof b === "object" && (b = b.ptr);
        return fc(d, a, b);
      };
      g.prototype.GetAttributeIdByName = g.prototype.GetAttributeIdByName =
        function (a, b) {
          var d = this.ptr;
          u.prepare();
          a && typeof a === "object" && (a = a.ptr);
          b = b && typeof b === "object" ? b.ptr : S(b);
          return hc(d, a, b);
        };
      g.prototype.GetAttributeIdByMetadataEntry =
        g.prototype.GetAttributeIdByMetadataEntry = function (a, b, d) {
          var n = this.ptr;
          u.prepare();
          a && typeof a === "object" && (a = a.ptr);
          b = b && typeof b === "object" ? b.ptr : S(b);
          d = d && typeof d === "object" ? d.ptr : S(d);
          return ic(n, a, b, d);
        };
      g.prototype.GetAttribute = g.prototype.GetAttribute = function (a, b) {
        var d = this.ptr;
        a && typeof a === "object" && (a = a.ptr);
        b && typeof b === "object" && (b = b.ptr);
        return N(jc(d, a, b), x);
      };
      g.prototype.GetAttributeByUniqueId = g.prototype.GetAttributeByUniqueId =
        function (a, b) {
          var d = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          b && typeof b === "object" && (b = b.ptr);
          return N(kc(d, a, b), x);
        };
      g.prototype.GetMetadata = g.prototype.GetMetadata = function (a) {
        var b = this.ptr;
        a && typeof a === "object" && (a = a.ptr);
        return N(lc(b, a), H);
      };
      g.prototype.GetAttributeMetadata = g.prototype.GetAttributeMetadata =
        function (a, b) {
          var d = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          b && typeof b === "object" && (b = b.ptr);
          return N(mc(d, a, b), H);
        };
      g.prototype.GetFaceFromMesh = g.prototype.GetFaceFromMesh = function (
        a,
        b,
        d
      ) {
        var n = this.ptr;
        a && typeof a === "object" && (a = a.ptr);
        b && typeof b === "object" && (b = b.ptr);
        d && typeof d === "object" && (d = d.ptr);
        return !!nc(n, a, b, d);
      };
      g.prototype.GetTriangleStripsFromMesh =
        g.prototype.GetTriangleStripsFromMesh = function (a, b) {
          var d = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          b && typeof b === "object" && (b = b.ptr);
          return oc(d, a, b);
        };
      g.prototype.GetTrianglesUInt16Array =
        g.prototype.GetTrianglesUInt16Array = function (a, b, d) {
          var n = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          b && typeof b === "object" && (b = b.ptr);
          d && typeof d === "object" && (d = d.ptr);
          return !!pc(n, a, b, d);
        };
      g.prototype.GetTrianglesUInt32Array =
        g.prototype.GetTrianglesUInt32Array = function (a, b, d) {
          var n = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          b && typeof b === "object" && (b = b.ptr);
          d && typeof d === "object" && (d = d.ptr);
          return !!qc(n, a, b, d);
        };
      g.prototype.GetAttributeFloat = g.prototype.GetAttributeFloat = function (
        a,
        b,
        d
      ) {
        var n = this.ptr;
        a && typeof a === "object" && (a = a.ptr);
        b && typeof b === "object" && (b = b.ptr);
        d && typeof d === "object" && (d = d.ptr);
        return !!rc(n, a, b, d);
      };
      g.prototype.GetAttributeFloatForAllPoints =
        g.prototype.GetAttributeFloatForAllPoints = function (a, b, d) {
          var n = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          b && typeof b === "object" && (b = b.ptr);
          d && typeof d === "object" && (d = d.ptr);
          return !!sc(n, a, b, d);
        };
      g.prototype.GetAttributeIntForAllPoints =
        g.prototype.GetAttributeIntForAllPoints = function (a, b, d) {
          var n = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          b && typeof b === "object" && (b = b.ptr);
          d && typeof d === "object" && (d = d.ptr);
          return !!tc(n, a, b, d);
        };
      g.prototype.GetAttributeInt8ForAllPoints =
        g.prototype.GetAttributeInt8ForAllPoints = function (a, b, d) {
          var n = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          b && typeof b === "object" && (b = b.ptr);
          d && typeof d === "object" && (d = d.ptr);
          return !!uc(n, a, b, d);
        };
      g.prototype.GetAttributeUInt8ForAllPoints =
        g.prototype.GetAttributeUInt8ForAllPoints = function (a, b, d) {
          var n = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          b && typeof b === "object" && (b = b.ptr);
          d && typeof d === "object" && (d = d.ptr);
          return !!vc(n, a, b, d);
        };
      g.prototype.GetAttributeInt16ForAllPoints =
        g.prototype.GetAttributeInt16ForAllPoints = function (a, b, d) {
          var n = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          b && typeof b === "object" && (b = b.ptr);
          d && typeof d === "object" && (d = d.ptr);
          return !!wc(n, a, b, d);
        };
      g.prototype.GetAttributeUInt16ForAllPoints =
        g.prototype.GetAttributeUInt16ForAllPoints = function (a, b, d) {
          var n = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          b && typeof b === "object" && (b = b.ptr);
          d && typeof d === "object" && (d = d.ptr);
          return !!xc(n, a, b, d);
        };
      g.prototype.GetAttributeInt32ForAllPoints =
        g.prototype.GetAttributeInt32ForAllPoints = function (a, b, d) {
          var n = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          b && typeof b === "object" && (b = b.ptr);
          d && typeof d === "object" && (d = d.ptr);
          return !!yc(n, a, b, d);
        };
      g.prototype.GetAttributeUInt32ForAllPoints =
        g.prototype.GetAttributeUInt32ForAllPoints = function (a, b, d) {
          var n = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          b && typeof b === "object" && (b = b.ptr);
          d && typeof d === "object" && (d = d.ptr);
          return !!zc(n, a, b, d);
        };
      g.prototype.GetAttributeDataArrayForAllPoints =
        g.prototype.GetAttributeDataArrayForAllPoints = function (
          a,
          b,
          d,
          n,
          e
        ) {
          var v = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          b && typeof b === "object" && (b = b.ptr);
          d && typeof d === "object" && (d = d.ptr);
          n && typeof n === "object" && (n = n.ptr);
          e && typeof e === "object" && (e = e.ptr);
          return !!Ac(v, a, b, d, n, e);
        };
      g.prototype.SkipAttributeTransform = g.prototype.SkipAttributeTransform =
        function (a) {
          var b = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          Bc(b, a);
        };
      g.prototype.GetEncodedGeometryType_Deprecated =
        g.prototype.GetEncodedGeometryType_Deprecated = function (a) {
          var b = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          return Cc(b, a);
        };
      g.prototype.DecodeBufferToPointCloud =
        g.prototype.DecodeBufferToPointCloud = function (a, b) {
          var d = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          b && typeof b === "object" && (b = b.ptr);
          return N(Dc(d, a, b), z);
        };
      g.prototype.DecodeBufferToMesh = g.prototype.DecodeBufferToMesh =
        function (a, b) {
          var d = this.ptr;
          a && typeof a === "object" && (a = a.ptr);
          b && typeof b === "object" && (b = b.ptr);
          return N(Ec(d, a, b), z);
        };
      g.prototype.__destroy__ = g.prototype.__destroy__ = function () {
        Fc(this.ptr);
      };
      (function () {
        function a() {
          c.ATTRIBUTE_INVALID_TRANSFORM = Gc();
          c.ATTRIBUTE_NO_TRANSFORM = Hc();
          c.ATTRIBUTE_QUANTIZATION_TRANSFORM = Ic();
          c.ATTRIBUTE_OCTAHEDRON_TRANSFORM = Jc();
          c.INVALID = Kc();
          c.POSITION = Lc();
          c.NORMAL = Mc();
          c.COLOR = Nc();
          c.TEX_COORD = Oc();
          c.GENERIC = Pc();
          c.INVALID_GEOMETRY_TYPE = Qc();
          c.POINT_CLOUD = Rc();
          c.TRIANGULAR_MESH = Sc();
          c.DT_INVALID = Tc();
          c.DT_INT8 = Uc();
          c.DT_UINT8 = Vc();
          c.DT_INT16 = Wc();
          c.DT_UINT16 = Xc();
          c.DT_INT32 = Yc();
          c.DT_UINT32 = Zc();
          c.DT_INT64 = $c();
          c.DT_UINT64 = ad();
          c.DT_FLOAT32 = bd();
          c.DT_FLOAT64 = cd();
          c.DT_BOOL = dd();
          c.DT_TYPES_COUNT = ed();
          c.OK = fd();
          c.DRACO_ERROR = gd();
          c.IO_ERROR = hd();
          c.INVALID_PARAMETER = id();
          c.UNSUPPORTED_VERSION = jd();
          c.UNKNOWN_VERSION = kd();
        }
        ma ? a() : Gd(a);
      })();
      c.Decoder.prototype.GetEncodedGeometryType = function (a) {
        if (a.__class__ && a.__class__ === c.DecoderBuffer)
          return c.Decoder.prototype.GetEncodedGeometryType_Deprecated(a);
        if (a.byteLength < 8) return c.INVALID_GEOMETRY_TYPE;
        switch (a[7]) {
          case 0:
            return c.POINT_CLOUD;
          case 1:
            return c.TRIANGULAR_MESH;
          default:
            return c.INVALID_GEOMETRY_TYPE;
        }
      };
      if (typeof c.onModuleParsed === "function") c.onModuleParsed();
      return l.return(c);
    });
  };
})();
typeof exports === "object" && typeof module === "object"
  ? ((module.exports = DracoDecoderModule),
    (module.exports.default = DracoDecoderModule))
  : typeof define === "function" &&
    define.amd &&
    define([], function () {
      return DracoDecoderModule;
    });
