(function () {
  var aa =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            function b() {}
            b.prototype = a;
            return new b();
          },
    h =
      typeof Object.defineProperties == "function"
        ? Object.defineProperty
        : function (a, b, d) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = d.value;
            return a;
          };
  function ba(a) {
    a = [
      "object" == typeof globalThis && globalThis,
      a,
      "object" == typeof window && window,
      "object" == typeof self && self,
      "object" == typeof global && global,
    ];
    for (var b = 0; b < a.length; ++b) {
      var d = a[b];
      if (d && d.Math == Math) return d;
    }
    throw Error("Cannot find global object");
  }
  var r = ba(this);
  function u(a, b) {
    if (b)
      a: {
        var d = r;
        a = a.split(".");
        for (var e = 0; e < a.length - 1; e++) {
          var l = a[e];
          if (!(l in d)) break a;
          d = d[l];
        }
        a = a[a.length - 1];
        e = d[a];
        b = b(e);
        b != e &&
          b != null &&
          h(d, a, { configurable: !0, writable: !0, value: b });
      }
  }
  function v(a) {
    var b = 0;
    return function () {
      return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
    };
  }
  function w(a) {
    var b =
      typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
    if (b) return b.call(a);
    if (typeof a.length == "number") return { next: v(a) };
    throw Error(String(a) + " is not an iterable or ArrayLike");
  }
  function x(a) {
    return ca(a, a);
  }
  function ca(a, b) {
    a.raw = b;
    Object.freeze && (Object.freeze(a), Object.freeze(b));
    return a;
  }
  var y =
    typeof Object.assign == "function"
      ? Object.assign
      : function (a, b) {
          if (a == null) throw new TypeError("No nullish arg");
          a = Object(a);
          for (var d = 1; d < arguments.length; d++) {
            var e = arguments[d];
            if (e)
              for (var l in e)
                Object.prototype.hasOwnProperty.call(e, l) && (a[l] = e[l]);
          }
          return a;
        };
  function z(a) {
    if (!(a instanceof Object))
      throw new TypeError("Iterator result " + a + " is not an object");
  }
  function A() {
    this.B = !1;
    this.j = null;
    this.o = void 0;
    this.h = 1;
    this.l = this.m = 0;
    this.I = this.i = null;
  }
  function B(a) {
    if (a.B) throw new TypeError("Generator is already running");
    a.B = !0;
  }
  A.prototype.G = function (a) {
    this.o = a;
  };
  function C(a, b) {
    a.i = { U: b, V: !0 };
    a.h = a.m || a.l;
  }
  A.prototype.getNextAddressJsc = function () {
    return this.h;
  };
  A.prototype.getYieldResultJsc = function () {
    return this.o;
  };
  A.prototype.return = function (a) {
    this.i = { return: a };
    this.h = this.l;
  };
  A.prototype["return"] = A.prototype.return;
  A.prototype.X = function (a) {
    this.i = { L: a };
    this.l < a ? ((this.h = a), (this.i = null)) : (this.h = this.l);
  };
  A.prototype.jumpThroughFinallyBlocks = A.prototype.X;
  A.prototype.A = function (a, b) {
    this.h = b;
    return { value: a };
  };
  A.prototype.yield = A.prototype.A;
  A.prototype.aa = function (a, b) {
    a = w(a);
    var d = a.next();
    z(d);
    if (d.done) (this.o = d.value), (this.h = b);
    else return (this.j = a), this.A(d.value, b);
  };
  A.prototype.yieldAll = A.prototype.aa;
  A.prototype.L = function (a) {
    this.h = a;
  };
  A.prototype.jumpTo = A.prototype.L;
  A.prototype.N = function () {
    this.h = 0;
  };
  A.prototype.jumpToEnd = A.prototype.N;
  A.prototype.K = function (a, b) {
    this.m = a;
    b != void 0 && (this.l = b);
  };
  A.prototype.setCatchFinallyBlocks = A.prototype.K;
  A.prototype.Z = function (a) {
    this.m = 0;
    this.l = a || 0;
  };
  A.prototype.setFinallyBlock = A.prototype.Z;
  A.prototype.J = function (a, b) {
    this.h = a;
    this.m = b || 0;
  };
  A.prototype.leaveTryBlock = A.prototype.J;
  A.prototype.H = function (a) {
    this.m = a || 0;
    a = this.i.U;
    this.i = null;
    return a;
  };
  A.prototype.enterCatchBlock = A.prototype.H;
  A.prototype.T = function (a, b, d) {
    d ? (this.I[d] = this.i) : (this.I = [this.i]);
    this.m = a || 0;
    this.l = b || 0;
    this.i = null;
  };
  A.prototype.enterFinallyBlock = A.prototype.T;
  A.prototype.Y = function (a, b) {
    b = this.I.splice(b || 0)[0];
    (b = this.i = this.i || b)
      ? b.V
        ? (this.h = this.m || this.l)
        : b.L != void 0 && this.l < b.L
        ? ((this.h = b.L), (this.i = null))
        : (this.h = this.l)
      : (this.h = a);
  };
  A.prototype.leaveFinallyBlock = A.prototype.Y;
  A.prototype.W = function (a) {
    return new D(a);
  };
  A.prototype.forIn = A.prototype.W;
  function D(a) {
    this.j = a;
    this.h = [];
    for (var b in a) this.h.push(b);
    this.h.reverse();
  }
  D.prototype.i = function () {
    for (; this.h.length > 0; ) {
      var a = this.h.pop();
      if (a in this.j) return a;
    }
    return null;
  };
  D.prototype.getNext = D.prototype.i;
  function da(a) {
    this.h = new A();
    this.i = a;
  }
  function ea(a, b) {
    B(a.h);
    var d = a.h.j;
    if (d)
      return E(
        a,
        "return" in d
          ? d["return"]
          : function (e) {
              return { value: e, done: !0 };
            },
        b,
        a.h.return
      );
    a.h.return(b);
    return F(a);
  }
  function E(a, b, d, e) {
    try {
      var l = b.call(a.h.j, d);
      z(l);
      if (!l.done) return (a.h.B = !1), l;
      var k = l.value;
    } catch (c) {
      return (a.h.j = null), C(a.h, c), F(a);
    }
    a.h.j = null;
    e.call(a.h, k);
    return F(a);
  }
  function F(a) {
    for (; a.h.h; )
      try {
        var b = a.i(a.h);
        if (b) return (a.h.B = !1), { value: b.value, done: !1 };
      } catch (d) {
        (a.h.o = void 0), C(a.h, d);
      }
    a.h.B = !1;
    if (a.h.i) {
      b = a.h.i;
      a.h.i = null;
      if (b.V) throw b.U;
      return { value: b.return, done: !0 };
    }
    return { value: void 0, done: !0 };
  }
  function fa(a) {
    this.next = function (b) {
      B(a.h);
      a.h.j ? (b = E(a, a.h.j.next, b, a.h.G)) : (a.h.G(b), (b = F(a)));
      return b;
    };
    this.throw = function (b) {
      B(a.h);
      if (a.h.j) {
        var d = a.h.j["throw"];
        if (d) var e = E(a, d, b, a.h.G);
        else {
          b = a.h.j;
          a.h.j = null;
          try {
            b["return"] && ((e = b["return"]()), z(e)),
              C(
                a.h,
                new TypeError("The iterator does not provide a 'throw' method.")
              );
          } catch (l) {
            C(a.h, l);
          }
          e = F(a);
        }
      } else C(a.h, b), (e = F(a));
      return e;
    };
    this.return = function (b) {
      return ea(a, b);
    };
    this[Symbol.iterator] = function () {
      return this;
    };
  }
  function ha(a) {
    function b(e) {
      return a.next(e);
    }
    function d(e) {
      return a.throw(e);
    }
    return new Promise(function (e, l) {
      function k(c) {
        c.done ? e(c.value) : Promise.resolve(c.value).then(b, d).then(k, l);
      }
      k(a.next());
    });
  }
  function G(a) {
    return ha(new fa(new da(a)));
  }
  function ia() {
    for (var a = Number(this), b = [], d = a; d < arguments.length; d++)
      b[d - a] = arguments[d];
    return b;
  }
  u("globalThis", function (a) {
    return a || r;
  });
  u("Symbol", function (a) {
    function b(k) {
      if (this instanceof b) throw new TypeError("Symbol is not a constructor");
      return new d(e + (k || "") + "_" + l++, k);
    }
    function d(k, c) {
      this.h = k;
      h(this, "description", { configurable: !0, writable: !0, value: c });
    }
    if (a) return a;
    d.prototype.toString = function () {
      return this.h;
    };
    var e = "jscomp_symbol_" + ((Math.random() * 1e9) >>> 0) + "_",
      l = 0;
    return b;
  });
  u("Symbol.iterator", function (a) {
    if (a) return a;
    a = Symbol("Symbol.iterator");
    h(Array.prototype, a, {
      configurable: !0,
      writable: !0,
      value: function () {
        return ja(v(this));
      },
    });
    return a;
  });
  function ja(a) {
    var b =
        (typeof Iterator != "undefined" &&
        Iterator.prototype &&
        !Iterator.prototype.next
          ? Iterator.prototype
          : null) || Object.prototype,
      d = aa(b);
    d.next = a;
    b[Symbol.iterator] ||
      (d[Symbol.iterator] = function () {
        return this;
      });
    return d;
  }
  u("Promise", function (a) {
    function b(c) {
      this.i = 0;
      this.j = void 0;
      this.h = [];
      this.A = !1;
      var f = this.l();
      try {
        c(f.resolve, f.reject);
      } catch (g) {
        f.reject(g);
      }
    }
    function d() {
      this.h = null;
    }
    function e(c) {
      return c instanceof b
        ? c
        : new b(function (f) {
            f(c);
          });
    }
    if (a) return a;
    d.prototype.i = function (c) {
      if (this.h == null) {
        this.h = [];
        var f = this;
        this.j(function () {
          f.m();
        });
      }
      this.h.push(c);
    };
    var l = r.setTimeout;
    d.prototype.j = function (c) {
      l(c, 0);
    };
    d.prototype.m = function () {
      for (; this.h && this.h.length; ) {
        var c = this.h;
        this.h = [];
        for (var f = 0; f < c.length; ++f) {
          var g = c[f];
          c[f] = null;
          try {
            g();
          } catch (m) {
            this.l(m);
          }
        }
      }
      this.h = null;
    };
    d.prototype.l = function (c) {
      this.j(function () {
        throw c;
      });
    };
    b.prototype.l = function () {
      function c(m) {
        return function (n) {
          g || ((g = !0), m.call(f, n));
        };
      }
      var f = this,
        g = !1;
      return { resolve: c(this.J), reject: c(this.m) };
    };
    b.prototype.J = function (c) {
      if (c === this)
        this.m(new TypeError("A Promise cannot resolve to itself"));
      else if (c instanceof b) this.N(c);
      else {
        a: switch (typeof c) {
          case "object":
            var f = c != null;
            break a;
          case "function":
            f = !0;
            break a;
          default:
            f = !1;
        }
        f ? this.I(c) : this.o(c);
      }
    };
    b.prototype.I = function (c) {
      var f = void 0;
      try {
        f = c.then;
      } catch (g) {
        this.m(g);
        return;
      }
      typeof f == "function" ? this.T(f, c) : this.o(c);
    };
    b.prototype.m = function (c) {
      this.B(2, c);
    };
    b.prototype.o = function (c) {
      this.B(1, c);
    };
    b.prototype.B = function (c, f) {
      if (this.i != 0)
        throw Error(
          "Cannot settle(" +
            c +
            ", " +
            f +
            "): Promise already settled in state" +
            this.i
        );
      this.i = c;
      this.j = f;
      this.i === 2 && this.K();
      this.G();
    };
    b.prototype.K = function () {
      var c = this;
      l(function () {
        if (c.H()) {
          var f = r.console;
          typeof f !== "undefined" && f.error(c.j);
        }
      }, 1);
    };
    b.prototype.H = function () {
      if (this.A) return !1;
      var c = r.CustomEvent,
        f = r.Event,
        g = r.dispatchEvent;
      if (typeof g === "undefined") return !0;
      typeof c === "function"
        ? (c = new c("unhandledrejection", { cancelable: !0 }))
        : typeof f === "function"
        ? (c = new f("unhandledrejection", { cancelable: !0 }))
        : ((c = r.document.createEvent("CustomEvent")),
          c.initCustomEvent("unhandledrejection", !1, !0, c));
      c.promise = this;
      c.reason = this.j;
      return g(c);
    };
    b.prototype.G = function () {
      if (this.h != null) {
        for (var c = 0; c < this.h.length; ++c) k.i(this.h[c]);
        this.h = null;
      }
    };
    var k = new d();
    b.prototype.N = function (c) {
      var f = this.l();
      c.O(f.resolve, f.reject);
    };
    b.prototype.T = function (c, f) {
      var g = this.l();
      try {
        c.call(f, g.resolve, g.reject);
      } catch (m) {
        g.reject(m);
      }
    };
    b.prototype.then = function (c, f) {
      function g(q, t) {
        return typeof q == "function"
          ? function (J) {
              try {
                m(q(J));
              } catch (K) {
                n(K);
              }
            }
          : t;
      }
      var m,
        n,
        p = new b(function (q, t) {
          m = q;
          n = t;
        });
      this.O(g(c, m), g(f, n));
      return p;
    };
    b.prototype.catch = function (c) {
      return this.then(void 0, c);
    };
    b.prototype.O = function (c, f) {
      function g() {
        switch (m.i) {
          case 1:
            c(m.j);
            break;
          case 2:
            f(m.j);
            break;
          default:
            throw Error("Unexpected state: " + m.i);
        }
      }
      var m = this;
      this.h == null ? k.i(g) : this.h.push(g);
      this.A = !0;
    };
    b.resolve = e;
    b.reject = function (c) {
      return new b(function (f, g) {
        g(c);
      });
    };
    b.race = function (c) {
      return new b(function (f, g) {
        for (var m = w(c), n = m.next(); !n.done; n = m.next())
          e(n.value).O(f, g);
      });
    };
    b.all = function (c) {
      var f = w(c),
        g = f.next();
      return g.done
        ? e([])
        : new b(function (m, n) {
            function p(J) {
              return function (K) {
                q[J] = K;
                t--;
                t == 0 && m(q);
              };
            }
            var q = [],
              t = 0;
            do
              q.push(void 0),
                t++,
                e(g.value).O(p(q.length - 1), n),
                (g = f.next());
            while (!g.done);
          });
    };
    return b;
  });
  u("Object.assign", function (a) {
    return a || y;
  }); /* 
 
 Copyright Google LLC 
 SPDX-License-Identifier: Apache-2.0 
*/
  var H = globalThis.trustedTypes,
    I;
  function ka() {
    var a = null;
    if (!H) return a;
    try {
      var b = function (d) {
        return d;
      };
      a = H.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (d) {}
    return a;
  }
  function L(a) {
    this.h = a;
  }
  L.prototype.toString = function () {
    return this.h + "";
  };
  function M(a) {
    var b;
    I === void 0 && (I = ka());
    a = (b = I) ? b.createScriptURL(a) : a;
    return new L(a);
  }
  function N(a) {
    var b = ia.apply(1, arguments);
    if (b.length === 0) return M(a[0]);
    for (var d = a[0], e = 0; e < b.length; e++)
      d += encodeURIComponent(b[e]) + a[e + 1];
    return M(d);
  }
  var la = x(["https://tpc.googlesyndication.com/sodar/", ".js"]),
    ma = x(["https://ep2.adtrafficquality.google/sodar/", ".js"]),
    na = x(["https://www.google.com/recaptcha/api2/aframe"]);
  N(na);
  function oa(a, b) {
    if (b instanceof L) b = b.h;
    else throw Error("");
    a.src = b;
    var d;
    b = a.ownerDocument;
    b = b === void 0 ? document : b;
    var e;
    b =
      (e = (d = b).querySelector) == null ? void 0 : e.call(d, "script[nonce]");
    (d = b == null ? "" : b.nonce || b.getAttribute("nonce") || "") &&
      a.setAttribute("nonce", d);
  }
  function pa(a, b) {
    typeof a.addEventListener === "function" &&
      a.addEventListener.call(a, "load", b, !1);
  }
  function qa(a) {
    var b = window,
      d = !0;
    d = d === void 0 ? !1 : d;
    new Promise(function (e, l) {
      function k() {
        c.onload = null;
        c.onerror = null;
        var f;
        (f = c.parentElement) == null || f.removeChild(c);
      }
      var c = b.document.createElement("script");
      c.onload = function () {
        k();
        e();
      };
      c.onerror = function () {
        k();
        l(void 0);
      };
      c.type = "text/javascript";
      oa(c, a);
      d && b.document.readyState !== "complete"
        ? pa(b, function () {
            b.document.body.appendChild(c);
          })
        : b.document.body.appendChild(c);
    });
  }
  var O = {},
    ra =
      ((O["internal-error"] = -1),
      (O["non-recoverable-error"] = -2),
      (O["api-disabled-by-application"] = -3),
      (O["invalid-argument"] = -4),
      (O["token-provider-invalid"] = -5),
      O);
  function sa() {
    this.u = !1;
  }
  var P;
  function Q() {
    P || (P = new sa());
    return P;
  }
  function ta(a) {
    var b;
    G(function (d) {
      if (d.h == 1)
        return (
          d.K(2),
          d.A(
            window.android.webview.getExperimentalMediaIntegrityTokenProvider({
              cloudProjectNumber: 187810013193,
            }),
            4
          )
        );
      if (d.h != 2) return (a.i = d.o), (a.h = void 0), d.J(0);
      b = d.H();
      a.h = ua(b);
      d.N();
    });
  }
  function ua(a) {
    if (!a || typeof a !== "object") return -100;
    var b = a.mediaIntegrityErrorName;
    if (typeof b === "string") {
      var d;
      return (d = ra[b]) != null ? d : -100;
    }
    a = a.code;
    if (typeof a === "function")
      try {
        return a();
      } catch (e) {}
    return -100;
  }
  function va(a) {
    var b, d, e, l, k, c, f, g, m, n;
    return G(function (p) {
      switch (p.h) {
        case 1:
          return (
            (b = a.D
              ? "https://ep1.adtrafficquality.google/getconfig/sodar"
              : "https://pagead2.googlesyndication.com/getconfig/sodar"),
            (d = a.C ? "&sjk=" + a.C : ""),
            (e = a.h === "cr" && a.v === "env" ? a.h + "_" + a.v : a.v),
            (l = b + "?sv=200&tid=" + a.i + ("&tv=" + a.j + "&st=") + e + d),
            (k = void 0),
            p.K(2),
            p.A(wa(l), 4)
          );
        case 4:
          k = p.o;
          p.J(3);
          break;
        case 2:
          p.H();
        case 3:
          if (!k) return p.return(void 0);
          c = a.C || k.sodar_query_id;
          f = k.rc_enable !== void 0 ? k.rc_enable : "n";
          g = k.bg_snapshot_delay_ms === void 0 ? "0" : k.bg_snapshot_delay_ms;
          m = k.is_gen_204 === void 0 ? "1" : k.is_gen_204;
          return c && k.bg_hash_basename && k.bg_binary
            ? ((n = {
                context: a.h,
                ca: k.bg_hash_basename,
                ba: k.bg_binary,
                da: a.i + "_" + a.j,
                C: c,
                v: a.v,
                R: f,
                S: g,
                P: m,
                D: a.D,
                M: a.M,
                F: a.F,
              }),
              a.u ? p.return(y({}, n, { u: !0 })) : p.return(n))
            : p.return(void 0);
      }
    });
  }
  function wa(a) {
    return new Promise(function (b, d) {
      var e = new XMLHttpRequest();
      e.onreadystatechange = function () {
        e.readyState === e.DONE &&
          (e.status >= 200 && e.status < 300
            ? b(Object.assign(Object.create(null), JSON.parse(e.responseText)))
            : d());
      };
      e.open("GET", a, !0);
      e.send();
    });
  }
  var R,
    S = document.currentScript;
  R =
    (S = S === void 0 ? null : S) && S.getAttribute("data-jc") === "76"
      ? S
      : document.querySelector('[data-jc="76"]');
  var T;
  if (R) {
    for (var U = {}, V = R.attributes, W = V.length - 1; W >= 0; W--) {
      var X = V[W].name;
      X.indexOf("data-jcp-") === 0 && (U[X.substring(9)] = V[W].value);
    }
    T = U;
  } else T = {};
  var Y = T,
    Z = new (function () {
      this.h = "xfad";
      this.i = "r20100101";
      this.j = "cr";
      this.v = "env";
      this.R = "n";
      this.S = "0";
      this.P = "1";
      this.M = this.u = this.D = !1;
      this.F = !0;
    })();
  Z.v = "int";
  Z.F = !1;
  Y.bgai && (Z.C = Y.bgai);
  (function (a) {
    var b;
    G(function (d) {
      if (d.h == 1) {
        if (a.u) {
          Q().u = !0;
          var e = Q();
          window.android &&
            window.android.webview &&
            window.android.webview.getExperimentalMediaIntegrityTokenProvider &&
            e.u &&
            ta(e);
        }
        return d.A(va(a), 2);
      }
      if ((b = d.o)) {
        e = b;
        var l = "sodar2";
        l = l === void 0 ? "sodar2" : l;
        var k = window,
          c = k.GoogleGcLKhOms;
        (c && typeof c.push === "function") || (c = k.GoogleGcLKhOms = []);
        var f,
          g = {},
          m =
            ((g._ctx_ = e.context),
            (g._bgv_ = e.ca),
            (g._bgp_ = e.ba),
            (g._li_ = e.da),
            (g._jk_ = e.C),
            (g._st_ = e.v),
            (g._rc_ = e.R),
            (g._dl_ = e.S),
            (g._g2_ = e.P),
            (g._atqg_ = e.D ? "1" : "0"),
            (g._sic_ = e.M ? "1" : "0"),
            (g._ivm_ = ((f = e.F) != null ? f : 1) ? "1" : "0"),
            g);
        e.u && (m._wvp_ = "1");
        c.push(m);
        if ((c = k.GoogleDX5YKUSkRag)) {
          if (c.length > 0 && (k = c.shift()))
            try {
              k();
            } catch (n) {}
        } else if ((c = k.GoogleDX5YKUSk)) (k.GoogleDX5YKUSk = void 0), c[1]();
        e = e.D ? N(ma, l) : N(la, l);
        qa(e);
      }
      return d.return(b);
    });
  })(
    new (function (a) {
      this.i = a.h;
      this.j = a.i;
      this.h = a.j;
      this.C = a.C;
      this.v = a.v;
      this.R = a.R;
      this.S = a.S;
      this.P = a.P;
      this.D = a.D;
      this.u = a.u;
      this.M = a.M;
      this.F = a.F;
    })(Z)
  );
}.call(this));
