/*! Kargo AdTag - v10.9.0-kat-7484-test [20261118] */ (() => {
  var __webpack_modules__ = {
      8542: (t, e, r) => {
        "use strict";
        var i;
        r.d(e, { p: () => i }),
          (function (t) {
            (t.HOVER = "Hover"),
              (t.BANNER = "Banner"),
              (t.VAST_DELIVERED_OUTSTREAM = "VastDeliveredOutstream");
          })(i || (i = {}));
      },
      6096: (t, e, r) => {
        "use strict";
        var i;
        r.d(e, { B: () => i }),
          (function (t) {
            (t.ABA_ADHESION_DISPLAY = "ABAAdhesionDisplay"),
              (t.ABA_DISPLAY = "ABADisplay"),
              (t.ABA_VIDEO = "ABAVideo"),
              (t.ADAPTIVE_OUTSTREAM = "AdaptiveOutstream"),
              (t.ANCHOR = "Anchor"),
              (t.APP_INTERSTITIAL = "AppInterstitial"),
              (t.BILLBOARD = "Billboard"),
              (t.BITLY = "Bitly"),
              (t.BOTTOM_BANNER = "BottomBanner"),
              (t.BREAKAWAY = "Breakaway"),
              (t.BREAKOUT = "Breakout"),
              (t.DESKTOP_BREAKOUT = "DesktopBreakout"),
              (t.DESKTOP_HOVER = "DesktopHover"),
              (t.DESKTOP_RUNWAY = "DesktopRunway"),
              (t.DESKTOP_SKINS = "DesktopSkins"),
              (t.FABRIK_OUTSTREAM = "FabrikOutstream"),
              (t.HALF_PAGE = "HalfPage"),
              (t.HIGH_RISE = "HighRise"),
              (t.HOVER = "Hover"),
              (t.KEY_ART = "KeyArt"),
              (t.LARGE_LEADERBOARD = "LargeLeaderboard"),
              (t.LEADERBOARD = "Leaderboard"),
              (t.LIGHTHOUSE = "Lighthouse"),
              (t.MIDDLE_BANNER = "MiddleBanner"),
              (t.NATIVE = "Native"),
              (t.NATIVE_VIDEO_KEY_ART = "NativeVideoKeyArt"),
              (t.NONVAST_OUTSTREAM_VIDEO = "NonVastOutstreamVideo"),
              (t.NONVAST_RUNWAY_VIDEO = "NonVastRunwayVideo"),
              (t.OUTSTREAM_VIDEO = "OutstreamVideo"),
              (t.RUNWAY = "Runway"),
              (t.SIDEKICK = "Sidekick"),
              (t.SOCIAL_CANVAS = "SocialCanvas"),
              (t.SWIPE_UP = "SwipeUp"),
              (t.TOP_BANNER = "TopBanner"),
              (t.ULTRAWIDE = "Ultrawide"),
              (t.FISHTANK = "FishTank"),
              (t.UPTICK = "Uptick"),
              (t.VENTI = "Venti"),
              (t.VIDEO_ANCHOR = "VideoAnchor"),
              (t.VIDEO_HALO = "VideoHalo"),
              (t.VIDEO_RUNWAY = "VideoRunway"),
              (t.VIDEO_VENTI = "VideoVenti"),
              (t.WIDESKYSCRAPER = "WideSkyscraper"),
              (t.WRAPPER = "Wrapper");
          })(i || (i = {}));
      },
      7551: (t, e, r) => {
        "use strict";
        r.d(e, {
          $4: () => s,
          $U: () => x,
          GW: () => w,
          Nd: () => m,
          RM: () => c,
          ZP: () => d,
          Zz: () => b,
          _G: () => k,
          _S: () => u,
          ak: () => f,
          cT: () => E,
          gY: () => v,
          gj: () => _,
          hR: () => a,
          im: () => p,
          nr: () => C,
          qr: () => h,
          sf: () => y,
          t3: () => A,
          un: () => g,
          vW: () => l,
        });
        var i,
          n = r(6096),
          o = r(8542),
          a = [
            {
              id: 3,
              sspID: 4,
              name: n.B.HOVER,
              type: o.p.HOVER,
              dfpShortname: n.B.HOVER.toLowerCase(),
              size: { w: 320, h: 50 },
            },
            {
              id: 5,
              sspID: 5,
              name: n.B.ANCHOR,
              type: o.p.HOVER,
              dfpShortname: n.B.ANCHOR.toLowerCase(),
              size: { w: 320, h: 50 },
            },
            {
              id: 6,
              sspID: 6,
              name: n.B.BREAKOUT,
              type: o.p.HOVER,
              dfpShortname: n.B.BREAKOUT.toLowerCase(),
              size: { w: 320, h: 50 },
            },
            {
              id: 4,
              sspID: 7,
              name: n.B.SIDEKICK,
              type: o.p.HOVER,
              dfpShortname: "side",
              size: { w: 140, h: 140 },
            },
            {
              id: 10,
              sspID: 8,
              name: n.B.TOP_BANNER,
              type: o.p.BANNER,
              dfpShortname: "top",
              size: { w: 320, h: 50 },
            },
            {
              id: 11,
              sspID: 9,
              name: n.B.MIDDLE_BANNER,
              type: o.p.BANNER,
              dfpShortname: "mid",
              size: { w: 300, h: 250 },
            },
            {
              id: 8,
              sspID: 11,
              name: n.B.BOTTOM_BANNER,
              type: o.p.BANNER,
              dfpShortname: "bot",
              size: { w: 320, h: 50 },
            },
            {
              id: 17,
              sspID: 18,
              name: n.B.VENTI,
              type: o.p.BANNER,
              dfpShortname: n.B.VENTI.toLowerCase(),
              size: { w: 320, h: 460 },
            },
            {
              id: 19,
              sspID: 20,
              name: n.B.OUTSTREAM_VIDEO,
              type: o.p.BANNER,
              dfpShortname: "midvid vastm",
              size: { w: 300, h: 200 },
            },
            {
              id: 21,
              sspID: 23,
              name: n.B.VIDEO_ANCHOR,
              type: o.p.HOVER,
              dfpShortname: n.B.VIDEO_ANCHOR.toLowerCase(),
              size: { w: 300, h: 250 },
            },
            {
              id: 23,
              sspID: 25,
              name: n.B.KEY_ART,
              type: o.p.BANNER,
              dfpShortname: n.B.KEY_ART.toLowerCase(),
              size: { w: 320, h: 350 },
            },
            {
              id: 24,
              sspID: 26,
              name: n.B.NONVAST_OUTSTREAM_VIDEO,
              type: o.p.BANNER,
              dfpShortname: "novastmidvid",
              size: { w: 300, h: 200 },
            },
            {
              id: 25,
              sspID: 27,
              name: n.B.ABA_DISPLAY,
              type: o.p.BANNER,
              dfpShortname: "",
              size: { w: 320, h: 350 },
            },
            {
              id: 27,
              sspID: 29,
              name: n.B.ABA_VIDEO,
              type: o.p.BANNER,
              dfpShortname: "",
              size: { w: 320, h: 350 },
            },
            {
              id: 28,
              sspID: 30,
              name: n.B.ABA_ADHESION_DISPLAY,
              type: o.p.HOVER,
              dfpShortname: "",
              size: { w: 320, h: 50 },
              minSize: { w: 0, h: 0 },
            },
            {
              id: 29,
              sspID: 31,
              name: n.B.BREAKAWAY,
              type: o.p.HOVER,
              dfpShortname: n.B.BREAKAWAY.toLowerCase(),
              size: { w: 140, h: 140 },
            },
            {
              id: 30,
              sspID: 32,
              name: n.B.HIGH_RISE,
              type: o.p.BANNER,
              dfpShortname: n.B.HIGH_RISE.toLowerCase(),
              size: { w: 320, h: 460 },
            },
            {
              id: 32,
              sspID: 33,
              name: n.B.LEADERBOARD,
              type: o.p.BANNER,
              dfpShortname: n.B.LEADERBOARD.toLowerCase(),
              size: { w: 728, h: 90 },
            },
            {
              id: 33,
              sspID: 34,
              name: n.B.WIDESKYSCRAPER,
              type: o.p.BANNER,
              dfpShortname: "wskyscraper",
              size: { w: 160, h: 600 },
            },
            {
              id: 34,
              sspID: 35,
              name: n.B.HALF_PAGE,
              type: o.p.BANNER,
              dfpShortname: n.B.HALF_PAGE.toLowerCase(),
              size: { w: 300, h: 600 },
            },
            {
              id: 35,
              sspID: 36,
              name: n.B.LARGE_LEADERBOARD,
              type: o.p.BANNER,
              dfpShortname: "lrgleaderboard",
              size: { w: 970, h: 90 },
            },
            {
              id: 36,
              sspID: 37,
              name: n.B.WRAPPER,
              type: o.p.HOVER,
              dfpShortname: n.B.WRAPPER.toLowerCase(),
              size: { w: 320, h: 50 },
            },
            {
              id: 37,
              sspID: 38,
              name: n.B.SWIPE_UP,
              type: o.p.HOVER,
              dfpShortname: n.B.SWIPE_UP.toLowerCase(),
              size: { w: 320, h: 100 },
            },
            {
              id: 38,
              sspID: 39,
              name: n.B.SOCIAL_CANVAS,
              type: o.p.BANNER,
              dfpShortname: n.B.SOCIAL_CANVAS.toLowerCase(),
              size: { w: 320, h: 180 },
            },
            {
              id: 39,
              sspID: 40,
              name: n.B.BILLBOARD,
              type: o.p.BANNER,
              dfpShortname: n.B.BILLBOARD,
              size: { w: 970, h: 250 },
            },
            {
              id: 40,
              sspID: 41,
              name: n.B.DESKTOP_HOVER,
              type: o.p.HOVER,
              dfpShortname: n.B.DESKTOP_HOVER,
              size: { w: 728, h: 90 },
            },
            {
              id: 41,
              sspID: 42,
              name: n.B.DESKTOP_BREAKOUT,
              type: o.p.HOVER,
              dfpShortname: n.B.DESKTOP_BREAKOUT,
              size: { w: 970, h: 200 },
            },
            {
              id: 43,
              sspID: 43,
              name: n.B.RUNWAY,
              type: o.p.HOVER,
              dfpShortname: n.B.RUNWAY,
              size: { w: 320, h: 50 },
            },
            {
              id: 44,
              sspID: 44,
              name: n.B.DESKTOP_RUNWAY,
              type: o.p.HOVER,
              dfpShortname: n.B.DESKTOP_RUNWAY,
              size: { w: 970, h: 200 },
            },
            {
              id: 48,
              sspID: 46,
              name: n.B.FABRIK_OUTSTREAM,
              type: o.p.VAST_DELIVERED_OUTSTREAM,
              dfpShortname: n.B.FABRIK_OUTSTREAM,
              size: { w: 300, h: 250 },
            },
            {
              id: 49,
              sspID: 45,
              name: n.B.LIGHTHOUSE,
              type: o.p.BANNER,
              dfpShortname: n.B.LIGHTHOUSE,
              size: { w: 320, h: 460 },
            },
            {
              id: 50,
              sspID: 47,
              name: n.B.UPTICK,
              type: o.p.BANNER,
              dfpShortname: n.B.UPTICK,
              size: { w: 320, h: 350 },
            },
            {
              id: 51,
              sspID: 48,
              name: n.B.VIDEO_HALO,
              type: o.p.VAST_DELIVERED_OUTSTREAM,
              dfpShortname: n.B.VIDEO_HALO,
              size: { w: 300, h: 250 },
            },
            {
              id: 52,
              sspID: 49,
              name: n.B.VIDEO_VENTI,
              type: o.p.VAST_DELIVERED_OUTSTREAM,
              dfpShortname: n.B.VIDEO_VENTI,
              size: { w: 300, h: 250 },
            },
            {
              id: 53,
              sspID: 50,
              name: n.B.ADAPTIVE_OUTSTREAM,
              type: o.p.VAST_DELIVERED_OUTSTREAM,
              dfpShortname: n.B.ADAPTIVE_OUTSTREAM,
              size: { w: 300, h: 250 },
            },
            {
              id: 54,
              sspID: 51,
              name: n.B.ULTRAWIDE,
              type: o.p.VAST_DELIVERED_OUTSTREAM,
              dfpShortname: n.B.ULTRAWIDE,
              size: { w: 970, h: 250 },
            },
            {
              id: 58,
              sspID: 55,
              name: n.B.VIDEO_RUNWAY,
              type: o.p.VAST_DELIVERED_OUTSTREAM,
              dfpShortname: n.B.VIDEO_RUNWAY,
              size: { w: 300, h: 250 },
            },
            {
              id: 60,
              sspID: 57,
              name: n.B.FISHTANK,
              type: o.p.VAST_DELIVERED_OUTSTREAM,
              dfpShortname: n.B.FISHTANK,
              size: { w: 300, h: 250 },
            },
            {
              id: 61,
              sspID: 58,
              name: n.B.DESKTOP_SKINS,
              type: o.p.BANNER,
              dfpShortname: n.B.DESKTOP_SKINS,
              size: { w: 970, h: 250 },
            },
            {
              id: 63,
              sspID: 60,
              name: n.B.NONVAST_RUNWAY_VIDEO,
              type: o.p.HOVER,
              dfpShortname: n.B.NONVAST_RUNWAY_VIDEO,
              size: { w: 300, h: 250 },
            },
            {
              id: 64,
              sspID: 61,
              name: n.B.APP_INTERSTITIAL,
              type: o.p.BANNER,
              dfpShortname: n.B.APP_INTERSTITIAL.toLowerCase(),
              size: { w: 300, h: 250 },
            },
            {
              id: 65,
              sspID: 62,
              name: n.B.BITLY,
              type: o.p.BANNER,
              dfpShortname: n.B.BITLY.toLowerCase(),
              size: { w: 300, h: 250 },
            },
          ],
          s = a.reduce(function (t, e) {
            return (t[e.name] = e), t;
          }, {}),
          c = [
            n.B.ABA_DISPLAY,
            n.B.APP_INTERSTITIAL,
            n.B.ABA_VIDEO,
            n.B.BITLY,
            n.B.DESKTOP_SKINS,
            n.B.FABRIK_OUTSTREAM,
            n.B.HALF_PAGE,
            n.B.HIGH_RISE,
            n.B.KEY_ART,
            n.B.NATIVE_VIDEO_KEY_ART,
            n.B.NATIVE,
            n.B.NONVAST_OUTSTREAM_VIDEO,
            n.B.OUTSTREAM_VIDEO,
            n.B.VENTI,
            n.B.WIDESKYSCRAPER,
            n.B.LIGHTHOUSE,
            n.B.UPTICK,
            n.B.ADAPTIVE_OUTSTREAM,
            n.B.VIDEO_HALO,
            n.B.VIDEO_RUNWAY,
            n.B.VIDEO_VENTI,
            n.B.FISHTANK,
          ],
          l = [
            n.B.APP_INTERSTITIAL,
            n.B.HIGH_RISE,
            n.B.KEY_ART,
            n.B.NONVAST_OUTSTREAM_VIDEO,
            n.B.OUTSTREAM_VIDEO,
            n.B.FABRIK_OUTSTREAM,
            n.B.VENTI,
            n.B.LIGHTHOUSE,
            n.B.UPTICK,
            n.B.ADAPTIVE_OUTSTREAM,
            n.B.VIDEO_HALO,
            n.B.VIDEO_RUNWAY,
            n.B.VIDEO_VENTI,
            n.B.FISHTANK,
          ],
          u = "kargo",
          h =
            (((i = {})[n.B.FABRIK_OUTSTREAM] = "mobilized"),
            (i[n.B.ADAPTIVE_OUTSTREAM] = "mobilized"),
            (i[n.B.FISHTANK] = "mobilized"),
            (i[n.B.ULTRAWIDE] = "mobilized"),
            (i[n.B.VIDEO_HALO] = "mobilized"),
            (i[n.B.VIDEO_VENTI] = "mobilized"),
            (i[n.B.VENTI] = "mobilized"),
            (i[n.B.DESKTOP_SKINS] = "mobilized"),
            i),
          d =
            (n.B.ADAPTIVE_OUTSTREAM,
            n.B.FABRIK_OUTSTREAM,
            n.B.FISHTANK,
            n.B.MIDDLE_BANNER,
            n.B.NONVAST_OUTSTREAM_VIDEO,
            n.B.OUTSTREAM_VIDEO,
            n.B.VIDEO_RUNWAY,
            [n.B.OUTSTREAM_VIDEO, n.B.VIDEO_ANCHOR, n.B.FABRIK_OUTSTREAM]),
          p = [n.B.TOP_BANNER, n.B.MIDDLE_BANNER, n.B.BOTTOM_BANNER],
          g = [n.B.APP_INTERSTITIAL].concat(p, [
            n.B.ABA_DISPLAY,
            n.B.HOVER,
            n.B.NATIVE,
            n.B.DESKTOP_HOVER,
            n.B.HALF_PAGE,
            n.B.LEADERBOARD,
            n.B.LARGE_LEADERBOARD,
            n.B.WIDESKYSCRAPER,
          ]),
          f = [n.B.KEY_ART, n.B.VENTI, n.B.LIGHTHOUSE, n.B.UPTICK],
          v = [
            n.B.APP_INTERSTITIAL,
            n.B.BITLY,
            n.B.BREAKAWAY,
            n.B.WRAPPER,
            n.B.RUNWAY,
            n.B.SWIPE_UP,
            n.B.DESKTOP_BREAKOUT,
            n.B.DESKTOP_RUNWAY,
            n.B.VIDEO_RUNWAY,
          ],
          m = [
            n.B.BREAKAWAY,
            n.B.SIDEKICK,
            n.B.WRAPPER,
            n.B.RUNWAY,
            n.B.VIDEO_RUNWAY,
            n.B.NONVAST_RUNWAY_VIDEO,
            n.B.SWIPE_UP,
            n.B.VIDEO_ANCHOR,
          ],
          k = [
            n.B.LARGE_LEADERBOARD,
            n.B.LEADERBOARD,
            n.B.WIDESKYSCRAPER,
            n.B.SOCIAL_CANVAS,
            n.B.BILLBOARD,
            n.B.DESKTOP_HOVER,
            n.B.DESKTOP_RUNWAY,
            n.B.DESKTOP_SKINS,
            n.B.ULTRAWIDE,
          ],
          b = [n.B.MIDDLE_BANNER],
          y = [
            n.B.NONVAST_OUTSTREAM_VIDEO,
            n.B.NATIVE_VIDEO_KEY_ART,
            n.B.ABA_VIDEO,
          ],
          w = [
            n.B.ADAPTIVE_OUTSTREAM,
            n.B.FABRIK_OUTSTREAM,
            n.B.OUTSTREAM_VIDEO,
            n.B.ULTRAWIDE,
            n.B.VIDEO_ANCHOR,
            n.B.VIDEO_HALO,
            n.B.VIDEO_RUNWAY,
            n.B.VIDEO_VENTI,
            n.B.FISHTANK,
          ],
          _ = [
            n.B.ADAPTIVE_OUTSTREAM,
            n.B.FABRIK_OUTSTREAM,
            n.B.NONVAST_OUTSTREAM_VIDEO,
            n.B.OUTSTREAM_VIDEO,
            n.B.ULTRAWIDE,
            n.B.VIDEO_HALO,
            n.B.VIDEO_RUNWAY,
            n.B.VIDEO_VENTI,
            n.B.FISHTANK,
          ],
          A = [
            n.B.ABA_VIDEO,
            n.B.ADAPTIVE_OUTSTREAM,
            n.B.FABRIK_OUTSTREAM,
            n.B.NATIVE_VIDEO_KEY_ART,
            n.B.NONVAST_OUTSTREAM_VIDEO,
            n.B.OUTSTREAM_VIDEO,
            n.B.ULTRAWIDE,
            n.B.VIDEO_ANCHOR,
            n.B.VIDEO_HALO,
            n.B.VIDEO_RUNWAY,
            n.B.NONVAST_RUNWAY_VIDEO,
            n.B.VIDEO_VENTI,
            n.B.FISHTANK,
          ],
          C = [n.B.HALF_PAGE, n.B.WIDESKYSCRAPER],
          E = [
            n.B.BREAKAWAY,
            n.B.SIDEKICK,
            n.B.RUNWAY,
            n.B.VIDEO_RUNWAY,
            n.B.NONVAST_RUNWAY_VIDEO,
          ],
          x = [n.B.ANCHOR, n.B.BREAKOUT, n.B.RUNWAY];
      },
      6496: (t, e, r) => {
        (e = r(1364)(!1)).push([
          t.id,
          "@supports(width:100vw){@media(max-width:320px){.kargo-ad-VAR_LOCAL_ID{left:50%;position:relative;transform:translateX(-50%);width:100vw}}}@supports(width:100vw){.kargo-ad-VAR_LOCAL_ID[data-format=Lighthouse]{left:0;transform:unset;width:100vw}}.kargo-ad-VAR_LOCAL_ID.kargo-ad-hidden{display:none}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner{line-height:0;position:relative;text-align:center}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.vast{height:100%}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.vpaid{text-align:left}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.kargo-banner--branding-advertisement .kargo-banner-optout.kargo-branding-created,.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.kargo-banner--branding-advertisement .kargo-banner-optout.kargo-branding-kargo,.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.kargo-banner--branding-none .kargo-banner-optout.kargo-branding-advertisement,.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.kargo-banner--branding-none .kargo-banner-optout.kargo-branding-created,.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.kargo-banner--branding-none .kargo-banner-optout.kargo-branding-kargo{display:none!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.kargo-banner--branding-advertisement .kargo-banner-optout.kargo-branding-advertisement{display:inline-block!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.kargo-banner--branding-created .kargo-banner-optout.kargo-branding-advertisement,.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.kargo-banner--branding-created .kargo-banner-optout.kargo-branding-kargo{display:none!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.kargo-banner--branding-created .kargo-banner-optout.kargo-branding-created{display:block!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-banner-optout{left:0;position:absolute;text-decoration:none;top:0}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-banner-optout>*{box-sizing:content-box!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-banner-optout.kargo-branding-kargo{border-right:19px solid transparent;border-top:19px solid hsla(0,0%,100%,.85);display:inline-block;z-index:10004}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-banner-optout.kargo-branding-kargo .kargo-svg-bolt{fill:#ff7500;height:11px;left:2px;position:absolute;top:-18px;width:8px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-banner-optout.kargo-branding-created{display:none!important;margin:0 auto;padding-top:15px;position:relative;top:-10px;z-index:2}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-banner-optout.kargo-branding-created .by-kargo-svg-grey{height:10px;width:60px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-banner-optout.kargo-branding-advertisement{background-color:#585858;border:none;border-radius:50%;display:none!important;height:15px;width:15px;z-index:10004}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-banner-optout.kargo-branding-advertisement .kargo-svg-advertisement{display:none}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-banner-optout.kargo-branding-advertisement .kargo-svg-opt-out{fill:#fff;height:15px;width:15px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-banner-optout.kargo-branding-advertisement.above{background-color:transparent;height:100%;margin:0 auto;padding-top:15px;position:relative;top:-10px;width:100px;z-index:2}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-banner-optout.kargo-branding-advertisement.above .kargo-svg-advertisement{display:block}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-banner-optout.kargo-branding-advertisement.above .kargo-svg-opt-out{display:none}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-banner-optout.vpaid{z-index:10000}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-banner-optout.show{visibility:visible}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-banner-optout.hide{visibility:hidden}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-overlay.vast{height:100%;left:50%;opacity:1;position:absolute;transform:translate(-50%);width:300px;z-index:1000000000}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-overlay.vast.fade{opacity:0;transition:opacity .6s ease-in;z-index:1}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-overlay.vast .kargo-overlay-bolt{fill:#5e5e5e;display:none;height:58px;left:50%;position:absolute;top:50%;transform:translate(-50%,-50%);width:40px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-overlay.vast .kargo-overlay-bolt.kargo{display:block}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-interscroller{width:100vw}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-ad-content{display:inline-block;line-height:0;min-width:300px;position:relative}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-ad-content.desktop{min-width:VAR_DESKTOP_WIDTHpx}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-ad-content .kargo-loader{left:0}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-ad-content .kargo-loader.fade{transition:background-color .4s ease-in}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-ad-content .kargo-loader .svg-loader{height:39px;left:50%;padding:1px;position:absolute;top:50%;transform:translate3d(-20px,-50%,0);width:39px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-ad-content.vpaid{display:block;margin:0 auto;text-align:center}@supports(width:100vw){.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-ad-content.kargo-banner-width{display:block;left:50%;position:relative;transform:translateX(-50%);width:100vw}}@supports not (width:100vw){.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-ad-content.kargo-banner-width{width:100%}}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-ad-content.unfaded{opacity:.1}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-ad-content.fade{opacity:1;transition:opacity .4s ease-in .2s}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-ad-content.vast{display:block;height:auto;z-index:1000}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-ad-content.center-vertical{margin:auto}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-ad-content .kargo-loader{background-color:transparent;left:50%;position:absolute;transform:translate(-50%);visibility:hidden}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-ad-content .kargo-loader.fade{background-color:#000;visibility:visible}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-ad-content .kargo-loader.hide{background-color:#000;transition:visibility .4s ease-in;visibility:hidden}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-ad-content .kargo-loader svg{height:39px;left:50%;padding:1px;position:absolute;top:50%;transform:translate3d(-20px,-50%,0);width:39px}div#professor_prebid-root{height:0!important;width:0!important}",
          "",
        ]),
          (t.exports = e);
      },
      6052: (t, e, r) => {
        (e = r(1364)(!1)).push([
          t.id,
          ".kargo-ad-VAR_LOCAL_ID .kargo-ad-content{max-width:unset!important;width:var(--krg-bitly-width,100vw)!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-ad-content.kargo-banner-width{left:0!important;position:fixed;transform:none}",
          "",
        ]),
          (t.exports = e);
      },
      1582: (t, e, r) => {
        (e = r(1364)(!1)).push([
          t.id,
          ".kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.kargo-desktop-skins{height:100%;left:0;pointer-events:none;position:absolute;top:0;width:100%}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.kargo-desktop-skins.kargo-banner--branding-advertisement .kargo-desktop-skins-optout.branding-by-kargo{display:none!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.kargo-desktop-skins.kargo-banner--branding-advertisement .kargo-desktop-skins-optout{width:75px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.kargo-desktop-skins.kargo-banner--branding-created .kargo-desktop-skins-optout.branding-advertisement{display:none!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.kargo-desktop-skins.kargo-banner--branding-created svg{display:block;height:8px;position:absolute;top:3px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.kargo-desktop-skins.kargo-banner--branding-none .kargo-desktop-skins-optout{display:none!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.kargo-desktop-skins .kargo-desktop-skins-optout{border-bottom:13px solid rgba(0,0,0,.65);border-left:13px solid transparent;border-right:13px solid transparent;bottom:0;box-sizing:content-box!important;position:fixed;right:22px;width:52px;z-index:2147483641}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner.kargo-desktop-skins .kargo-desktop-skins-optout .kargo-svg-advertisement{fill:#fff;display:block;height:10px;opacity:.9;position:absolute;top:3px;width:75px}",
          "",
        ]),
          (t.exports = e);
      },
      8960: (t, e, r) => {
        (e = r(1364)(!1)).push([
          t.id,
          ".kargo-ad-VAR_LOCAL_ID .kargo-ad-content,.kargo-ad-VAR_LOCAL_ID .kargo-creative{width:100%}",
          "",
        ]),
          (t.exports = e);
      },
      7298: (t, e, r) => {
        (e = r(1364)(!1)).push([
          t.id,
          ".kargo-lighthouse-relative{position:relative!important}.kargo-lighthouse-fixed{left:0!important;position:fixed!important;right:0!important;top:0!important}.kargo-lighthouse-bottom{bottom:0!important;height:100dvh;position:absolute!important}.kargo-lighthouse-scrollbar{background:rgba(0,0,0,.3);bottom:0!important;height:100dvh;opacity:0;position:absolute;right:0;width:5px;z-index:3}.kargo-lighthouse-scroller{background:hsla(0,0%,100%,.5);border-radius:0 0 10px 10px;cursor:pointer;height:0;position:absolute;right:0;top:var(--scrollbar-offset,20px);width:100%}.kargo-lighthouse-scroller.scrolled-to-bottom{border-radius:0}.kargo-lighthouse-skip{-webkit-tap-highlight-color:rgba(0,0,0,0);background-color:rgba(0,0,0,.35);border-radius:13px;cursor:pointer;height:26px;pointer-events:auto;position:absolute;right:20px;top:30px;transition:opacity .3s ease;width:61px;z-index:10005}.kargo-lighthouse-skip:focus{outline:none}.kargo-lighthouse-skip:focus-visible{outline:2px solid hsla(0,0%,100%,.9);outline-offset:2px}",
          "",
        ]),
          (t.exports = e);
      },
      5264: (t, e, r) => {
        (e = r(1364)(!1)).push([
          t.id,
          ".kargo-ad-VAR_LOCAL_ID .kargo-ad-hover{animation:slideUp 1.7s ease-in 1 forwards;left:0;margin-bottom:VAR_HEIGHT_OFFSETpx;position:fixed;right:0;text-align:center;visibility:visible;z-index:2147483642}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--swipeup .kargo-hover-content{max-height:50px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--swipeup .kargo-hover-content .kargo-ad-content{bottom:0;left:50%;position:absolute;transform:translate3d(-50%,0,0)}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--swipeup .kargo-hover-content .new-template{max-height:120px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--swipeup .kargo-hover-content .new-template-after-click{animation:swipeUp .65s ease-in 1 forwards;max-height:460px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--responsive .kargo-hover-content{max-width:428px;width:100%}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--responsive .kargo-ad-content{width:100%}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--wrapper-fill{background-color:rgba(0,0,0,.65)}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--wrapper-fill .kargo-hover-content{box-sizing:content-box!important;padding:5px 0}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--wrapper-fill .kargo-hover-close{top:-11px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--wrapper-fill .kargo-hover-close.unfilled,.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--wrapper-nofill .kargo-hover-close.filled{display:none}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top{animation:slideUpTop 1.7s ease-in 1 forwards;margin-top:VAR_HEIGHT_OFFSETpx}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top .kargo-hover-close{bottom:-16px;top:auto!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top.kargo-hover--wrapper-fill .kargo-hover-close{bottom:-11px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-content{float:left;left:50%;min-height:50px;min-width:320px;position:relative;transform:translate(-50%);z-index:2147483642}@keyframes slideUp{0%{bottom:0;padding-bottom:0;transform:translate3d(0,300px,0)}80%{bottom:0;padding-bottom:4px;transform:translateZ(0)}83%{bottom:0;padding-bottom:0;transform:translate3d(0,7px,0)}90%{bottom:0;padding-bottom:1px;transform:translateZ(0)}95%{bottom:-2px;padding-bottom:0;transform:translate3d(0,1px,0)}to{bottom:-1px;padding-bottom:0;transform:translateZ(0)}}@keyframes swipeUp{0%{bottom:0;max-height:120px}10%{bottom:0;max-height:154px}20%{bottom:0;max-height:188px}30%{bottom:0;max-height:222px}40%{bottom:0;max-height:256px}50%{bottom:0;max-height:290px}60%{bottom:0;max-height:324px}70%{bottom:0;max-height:392px}80%{bottom:-2px;max-height:426px}90%{bottom:0;max-height:450px}to{bottom:-1px;max-height:460px}}@keyframes slideUpTop{0%{padding-top:0;top:0;transform:translate3d(0,-300px,0)}80%{padding-top:4px;top:0;transform:translateZ(0)}83%{padding-top:0;top:0;transform:translate3d(0,-7px,0)}90%{padding-top:1px;top:0;transform:translateZ(0)}95%{padding-top:0;top:-2px;transform:translate3d(0,-1px,0)}to{padding-top:0;top:-1px;transform:translateZ(0)}}",
          "",
        ]),
          (t.exports = e);
      },
      5322: (t, e, r) => {
        (e = r(1364)(!1)).push([
          t.id,
          "@supports(width:100vw){@media(max-width:320px){.kargo-ad-VAR_LOCAL_ID{left:auto!important;transform:none!important}}}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-uptick-close{background-color:#585858;border-radius:50%;display:block;height:24px;position:relative;right:-148px;top:1px;width:24px;z-index:2147483642}.kargo-ad-VAR_LOCAL_ID .kargo-ad-banner .kargo-uptick-close svg{fill:#fff;height:24px;left:0;position:absolute;width:24px;z-index:2147483642}.no-padding{padding-top:0!important}.uptick-ad-content{box-sizing:content-box!important;display:flex!important;height:100px!important;left:auto!important;max-height:none!important;max-width:none!important;min-height:0!important;min-width:0!important;overflow:hidden!important;position:fixed!important;right:0!important;top:0!important;transform:translateX(0)!important;width:175px!important;z-index:2147483642}.uptick-reset{height:100%;position:relative;top:0;width:100%}.tempBanner{background-color:transparent;background-position:50%;background-repeat:no-repeat;background-size:contain;display:block;margin-left:auto;margin-right:auto;max-width:428px;min-width:300px;width:100%}.hide{display:none!important}.show{display:block!important}",
          "",
        ]),
          (t.exports = e);
      },
      7080: (t, e, r) => {
        (e = r(1364)(!1)).push([
          t.id,
          ".kargo-ad-VAR_LOCAL_ID.kargo-ad-hidden{display:none}.kargo-ad-VAR_LOCAL_ID.kargo-ad-preload{display:block}.kargo-ad-VAR_LOCAL_ID.kargo-ad-preload .kargo-ad-hover{animation:none!important;left:calc(-infinity*1px);right:auto}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover-slide-up-fast{animation:slideUpFast .9s ease-in 1 forwards!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover-slide-down-fast{animation:slideDownFast .9s ease-in 1 forwards!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover{animation:slideUp 1.7s ease-in 1 forwards;left:0;margin-bottom:VAR_HEIGHT_OFFSETpx;position:fixed;right:0;text-align:center;visibility:visible;z-index:2147483642}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--branding-advertisement.kargo-desktop-hover .kargo-svg-advertisement{opacity:1}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--branding-advertisement .kargo-hover-link{width:68px!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--branding-advertisement .kargo-hover-link .by-kargo-svg-white{display:none!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover:not(.kargo-hover--branding-advertisement) .kargo-hover-link .kargo-svg-advertisement{display:none!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--branding-none .kargo-hover-link{display:none!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--responsive .kargo-hover-content{width:100%}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--wrapper-fill{background-color:rgba(0,0,0,.65)}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--wrapper-fill .kargo-hover-content{box-sizing:content-box!important;padding:5px 0}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--wrapper-fill .kargo-hover-content.kargo-desktop-hover{width:728px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--wrapper-fill .kargo-hover-content.kargo-desktop-hover-responsive{width:100%}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--wrapper-fill .kargo-hover-content.kargo-desktop-hover-responsive .kargo-ad-content{margin:auto}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--wrapper-fill .kargo-hover-close{top:-11px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--wrapper-fill .kargo-hover-close.unfilled,.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--wrapper-fill .kargo-hover-link.unfilled,.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--wrapper-nofill .kargo-hover-close.filled,.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--wrapper-nofill .kargo-hover-link.filled{display:none}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top{animation:slideUpTop 1.7s ease-in 1 forwards;margin-top:VAR_HEIGHT_OFFSETpx}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top .kargo-hover-close{bottom:-16px;top:auto!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top.kargo-hover--wrapper-fill .kargo-hover-close{bottom:-11px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top .kargo-hover-link{bottom:-13px;top:auto!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top .kargo-hover-link .kargo-svg-bolt{bottom:3px;top:auto!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top .kargo-hover-link .kargo-svg-ad,.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top .kargo-hover-link .kargo-svg-kargo{bottom:0;top:auto!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top .kargo-hover-link .kargo-svg-advertisement{bottom:3px;top:auto!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--videoanchor{z-index:2147483642}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--breakout .kargo-hover-content{max-height:50px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--breakout .kargo-hover-content .kargo-ad-content{bottom:0;left:50%;position:absolute;transform:translate(-50%)}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--breakout.kargo-hover--wrapper-fill .kargo-ad-content{bottom:5px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--desktop-breakout .kargo-hover-content .kargo-ad-content{min-width:100%!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--desktop-breakout .kargo-hover-content .kargo-hover-close{bottom:77px;top:auto}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--desktop-breakout .kargo-hover-content .kargo-hover-close.kargo-desktop-runway-close{bottom:108px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--desktop-breakout .kargo-hover-content .kargo-hover-link{border-left:13px solid transparent!important;border-right:13px solid transparent!important;bottom:0;left:auto;right:5px;top:auto}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--desktop-breakout .kargo-hover-content .kargo-hover-link svg.by-kargo-svg-white{height:8px;left:1.5px;top:2.3px;width:48px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--desktop-breakout.kargo-hover--wrapper-fill .kargo-ad-content{bottom:5px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-triplex-execution{bottom:0;max-width:428px;position:fixed;width:100%}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-triplex-execution .kargo-hover-close{top:-13px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--align-left,.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--align-right{pointer-events:none}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--align-left.kargo-hover--align-right .kargo-hover-content,.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--align-right.kargo-hover--align-right .kargo-hover-content{float:right}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--align-left .kargo-hover-content,.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--align-right .kargo-hover-content{left:auto;min-width:VAR_SIDEKICK_WIDTHpx;pointer-events:auto;right:auto;transform:none}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--align-left.kargo-hover--top .kargo-hover-link,.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--align-right.kargo-hover--top .kargo-hover-link{bottom:auto!important;top:0}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-desktop-sidekick .kargo-hover-content{min-height:VAR_SIDEKICK_HEIGHTpx}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--one-sec-interstitial{animation:none;opacity:0}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--one-sec-interstitial.is-loaded{animation:slideUp 1.7s ease-in 1 forwards;opacity:1}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--prevent-close .kargo-hover-close{display:none}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--amp-sticky{animation:none!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--amp-sticky.kargo-hover--wrapper-fill{background-color:#fff}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--amp-sticky .kargo-hover-content{padding:9px 0 5px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--amp-sticky .kargo-hover-content .kargo-ad-content .kargo-hover-optout{border-right:19px solid transparent;border-top:19px solid hsla(0,0%,100%,.85);display:inline-block;left:0;position:absolute;text-decoration:none;top:9px;z-index:2147483642}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--amp-sticky .kargo-hover-content .kargo-ad-content .kargo-hover-optout .kargo-svg-opt-out{display:none}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--amp-sticky .kargo-hover-content .kargo-ad-content .kargo-hover-optout .kargo-svg-bolt{fill:#ff7500;height:11px;left:2px;position:absolute;top:-18px;width:8px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--amp-sticky .kargo-hover-content .kargo-ad-content .kargo-hover-optout>*{box-sizing:content-box!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--amp-sticky .kargo-hover-content .kargo-ad-content .kargo-hover-optout.kargo-hover--branding-advertisement{background-color:#585858;border:none;border-radius:50%;height:15px;width:15px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--amp-sticky .kargo-hover-content .kargo-ad-content .kargo-hover-optout.kargo-hover--branding-advertisement .kargo-svg-bolt{display:none}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--amp-sticky .kargo-hover-content .kargo-ad-content .kargo-hover-optout.kargo-hover--branding-advertisement .kargo-svg-opt-out{fill:#fff;display:block;height:15px;width:15px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover:not(.kargo-hover--amp-sticky) .kargo-hover-optout{display:none!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-content{float:left;left:50%;min-height:50px;min-width:320px;position:relative;transform:translate(-50%);z-index:2147483641}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-link{border-bottom:13px solid rgba(0,0,0,.65);border-right:13px solid transparent;box-sizing:content-box!important;left:0;position:absolute;top:-13px;width:52px;z-index:2147483641}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-link.kargo-sidekick-branding{border-left:13px solid transparent!important;border-right:13px solid transparent!important;margin:auto!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-link.kargo-sidekick-branding .by-kargo-svg-white{height:8px;left:0;top:2px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-link.kargo-sidekick-branding.kargo-breakaway-branding{right:26px!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-link.kargo-sidekick-branding:not(.kargo-breakaway-branding){left:0!important;right:0!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-link.kargo-sidekick-branding.breakaway-left-align{left:26px!important;margin:initial!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-link.kargo-triplex-execution{border-bottom:13px solid rgba(0,0,0,.65);border-left:13px solid transparent;border-right:13px solid transparent;bottom:0;left:auto;position:absolute;right:26px;top:auto;width:58px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-link.kargo-triplex-execution .by-kargo-svg-white{top:2px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-link.hide{display:none}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-link.desktop-format{width:52px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-link svg{display:inline-block;position:absolute}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-link svg.kargo-svg-bolt{fill:#ff7500;height:7px;left:4px;top:3px;width:5px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-link svg.kargo-svg-kargo{fill:#fff;height:14px;left:12px;width:26px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-link svg.kargo-svg-ad{fill:#ff7500;height:14px;left:39px;width:11px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-link svg.kargo-svg-advertisement{fill:#aaa;height:7px;left:-1px;opacity:.75;top:4px;width:71px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-link svg.by-kargo-svg-white{height:9px;left:2px;top:4px;width:52px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-close{background-color:#585858;border-radius:50%;height:24px;position:absolute;right:5px;top:-13px;width:24px;z-index:2147483642}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-close.expanded{right:10px;top:10px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-close.hide{display:none}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-close.left-align{left:5px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-close .kargo-svg-close,.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-close .kargo-svg-close-no-border{fill:#fff;height:24px;left:0;position:absolute;width:24px;z-index:2147483642}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-close.runway-close-position{top:8px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-close .kargo-svg-close-no-border{display:none}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-close.kargo-hover-filled{top:-11px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-hover-close-progress{display:none}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--align-right:not(.kargo-hover--videoanchor) .kargo-hover-link{border-left:13px solid transparent;border-right:none;bottom:0;left:auto;right:0;top:auto}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--align-right:not(.kargo-hover--videoanchor).kargo-sidekick-branding{border-right:13px solid transparent!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--align-left .kargo-hover-close{left:5px!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--align-left .kargo-hover-link{bottom:0;left:0;right:auto;top:auto}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top.kargo-hover--branding-advertisement .kargo-hover-link .kargo-advertisement{top:-8px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top .kargo-hover-link{border-bottom:none;border-right:13px solid transparent;border-top:13px solid rgba(0,0,0,.65)}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top .kargo-hover-link.kargo-sidekick-branding{border-left:13px solid transparent!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top .kargo-hover-link .kargo-svg-bolt{top:-10px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top .kargo-hover-link .kargo-kargo{left:11px;top:-13px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top .kargo-hover-link .kargo-ad{left:38px;top:-13px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top.kargo-hover--align-right .kargo-hover-link{border-right:none;left:auto;right:0;top:0}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top.kargo-hover--align-right .kargo-hover-link.kargo-sidekick-branding{border-right:13px solid transparent!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top.kargo-hover--align-right .kargo-hover-link .kargo-advertisement{top:-8px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top.kargo-hover--align-left .kargo-hover-link{left:0;top:0}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover.kargo-hover--top.kargo-hover--align-left .kargo-advertisement{top:-8px}@keyframes slideUp{0%{bottom:0;padding-bottom:0;transform:translateY(300px)}80%{bottom:0;padding-bottom:4px;transform:translate(0)}83%{bottom:0;padding-bottom:0;transform:translateY(7px)}90%{bottom:0;padding-bottom:1px;transform:translate(0)}95%{bottom:-2px;padding-bottom:0;transform:translateY(1px)}to{bottom:-1px;padding-bottom:0;transform:translate(0)}}@keyframes slideUpFast{0%{bottom:0;padding-bottom:0;transform:translateY(300px)}to{bottom:-1px;padding-bottom:0;transform:translate(0)}}@keyframes slideDownFast{0%{bottom:-1px;padding-bottom:0;transform:translate(0)}to{bottom:0;padding-bottom:0;transform:translateY(300px)}}@keyframes slideUpTop{0%{padding-top:0;top:0;transform:translateY(-300px)}80%{padding-top:4px;top:0;transform:translate(0)}83%{padding-top:0;top:0;transform:translateY(-7px)}90%{padding-top:1px;top:0;transform:translate(0)}95%{padding-top:0;top:-2px;transform:translateY(-1px)}to{padding-top:0;top:-1px;transform:translate(0)}}div#professor_prebid-root{height:0!important;width:0!important}",
          "",
        ]),
          (t.exports = e);
      },
      3392: (t, e, r) => {
        (e = r(1364)(!1)).push([
          t.id,
          ".kargo-ad-VAR_LOCAL_ID.kargo-ad-hidden{display:none}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover{position:relative;text-align:center}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-ad-content{display:inline-block;line-height:0;position:relative}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-ad-content .kargo-hover-optout{border-right:19px solid transparent;border-top:19px solid hsla(0,0%,100%,.85);display:inline-block;left:0;position:absolute;text-decoration:none;top:0;z-index:2147483642}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-ad-content .kargo-hover-optout .kargo-svg-opt-out{display:none}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-ad-content .kargo-hover-optout .kargo-svg-bolt{fill:#ff7500;height:11px;left:2px;position:absolute;top:-18px;width:8px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-ad-content .kargo-hover-optout>*{box-sizing:content-box!important}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-ad-content .kargo-hover-optout.kargo-hover--branding-advertisement{background-color:#585858;border:none;border-radius:50%;height:15px;width:15px}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-ad-content .kargo-hover-optout.kargo-hover--branding-advertisement .kargo-svg-bolt{display:none}.kargo-ad-VAR_LOCAL_ID .kargo-ad-hover .kargo-ad-content .kargo-hover-optout.kargo-hover--branding-advertisement .kargo-svg-opt-out{fill:#fff;display:block;height:15px;width:15px}",
          "",
        ]),
          (t.exports = e);
      },
      4162: (t, e, r) => {
        t.exports =
          '<div class="kargo-ad-banner VAR_VAST VAR_BRANDING VAR_FLOURISH_BANNER"> <div class="kargo-overlay VAR_VAST VAR_BOLT"></div> <a class="kargo-banner-optout kargo-branding-created VAR_VAST" href=https://www.kargo.com/privacy target=_blank> ' +
          r(5822) +
          ' </a> <div class="kargo-ad-content VAR_VAST VAR_FADE VAR_WIDTH VAR_FLOURISH_CONTENT"> <a class="kargo-banner-optout kargo-branding-kargo VAR_VAST" href=https://www.kargo.com/privacy target=_blank> ' +
          r(9475) +
          ' </a> <a class="kargo-banner-optout kargo-branding-advertisement VAR_ABOVE VAR_VAST" href=https://www.kargo.com/privacy target=_blank> ' +
          r(9262) +
          " " +
          r(81) +
          ' </a> <div class="kargo-loader VAR_SHOW"> ' +
          r(2019) +
          " </div> </div> </div> ";
      },
      4490: (t, e, r) => {
        t.exports =
          '<div class="kargo-ad-hover VAR_HUG_SIDE VAR_SHOW_KARGO_LOGO_TAG VAR_WRAPPER_FILL VAR_PREVENT_CLOSE VAR_HORIZONTAL_ALIGN VAR_FORMAT VAR_BRANDING VAR_VERTICAL_ALIGN VAR_WIDTH VAR_AMP_MODE VAR_TRIPLEX"> <div class=kargo-hover-content> <a class="kargo-hover-link desktop-format unfilled" href=https://www.kargo.com/privacy target=_blank> ' +
          r(3742) +
          " " +
          r(81) +
          ' </a> <a class="kargo-hover-close unfilled VAR_RUNWAY"> ' +
          r(86) +
          " " +
          r(9525) +
          ' </a> <div class="kargo-hover-close-progress unfilled"></div> <div class=kargo-ad-content> </div> </div> </div>';
      },
      2164: (t, e, r) => {
        t.exports =
          '<div class="kargo-ad-hover kargo-desktop-hover VAR_HUG_SIDE VAR_SHOW_KARGO_LOGO_TAG VAR_WRAPPER_FILL VAR_PREVENT_CLOSE VAR_HORIZONTAL_ALIGN VAR_FORMAT VAR_BRANDING VAR_VERTICAL_ALIGN VAR_WIDTH VAR_AMP_MODE VAR_TRIPLEX"> <a class="kargo-hover-link filled desktop-format" href=https://www.kargo.com/privacy target=_blank> ' +
          r(3742) +
          " " +
          r(81) +
          ' </a> <a class="kargo-hover-close filled"> ' +
          r(86) +
          " " +
          r(9525) +
          ' </a> <div class="kargo-hover-content VAR_DESKTOP_HOVER"> <div class=kargo-ad-content> </div> </div> </div>';
      },
      8632: (t, e, r) => {
        t.exports =
          '<div class="kargo-ad-banner kargo-desktop-skins VAR_BRANDING"> <div class=kargo-ad-content> <a class="kargo-desktop-skins-optout branding-advertisement" href=https://www.kargo.com/privacy target=_blank> ' +
          r(81) +
          ' </a> <a class="kargo-desktop-skins-optout branding-by-kargo" href=https://www.kargo.com/privacy target=_blank> ' +
          r(3742) +
          ' </a> <div class="kargo-loader VAR_SHOW"> ' +
          r(2019) +
          " </div> </div> </div> ";
      },
      6012: (t) => {
        t.exports =
          "html { scrollbar-width: none; } /* Firefox */ body { -ms-overflow-style: none; } /* IE and Edge */ body::-webkit-scrollbar, body::-webkit-scrollbar-button { display: none; } /* Chrome */ ";
      },
      9246: (t) => {
        t.exports =
          '<div class="kargo-ad-hover kargo-hover--swipeup VAR_HUG_SIDE VAR_WRAPPER_FILL VAR_HORIZONTAL_ALIGN VAR_BRANDING VAR_WIDTH"> <div class="kargo-hover-close-progress unfilled"></div> <div class=kargo-hover-content> <div class="kargo-hover-close-progress unfilled"></div> <div class=kargo-ad-content></div> </div> </div> ';
      },
      1712: (t, e, r) => {
        t.exports =
          '<div class="kargo-ad-banner VAR_VAST VAR_BRANDING"> <div class="kargo-ad-content VAR_WIDTH"> <a class="kargo-uptick-close VAR_CLOSEBUTTON hide"> ' +
          r(7217) +
          ' </a> <a class="kargo-banner-optout kargo-branding-kargo VAR_VAST" href=https://www.kargo.com/privacy target=_blank> ' +
          r(9475) +
          ' </a> <a class="kargo-banner-optout kargo-branding-advertisement VAR_ABOVE VAR_VAST" href=https://www.kargo.com/privacy target=_blank> ' +
          r(9262) +
          " " +
          r(81) +
          " </a> </div> </div> ";
      },
      3930: (t) => {
        t.exports =
          '<div class="kargo-ad-hover VAR_HUG_SIDE VAR_SHOW_KARGO_LOGO_TAG VAR_WRAPPER_FILL VAR_PREVENT_CLOSE VAR_HORIZONTAL_ALIGN VAR_FORMAT VAR_BRANDING VAR_VERTICAL_ALIGN VAR_WIDTH VAR_AMP_MODE"> <div class=kargo-hover-content> <div class=kargo-ad-content> </div> </div> </div> ';
      },
      5966: (t, e, r) => {
        t.exports =
          '<div class="kargo-ad-hover VAR_HUG_SIDE VAR_SHOW_KARGO_LOGO_TAG VAR_WRAPPER_FILL VAR_PREVENT_CLOSE VAR_HORIZONTAL_ALIGN VAR_FORMAT VAR_BRANDING VAR_VERTICAL_ALIGN VAR_WIDTH VAR_AMP_MODE VAR_TRIPLEX"> <a class="kargo-hover-link filled" href=https://www.kargo.com/privacy target=_blank> ' +
          r(81) +
          " " +
          r(3742) +
          ' </a> <a class="kargo-hover-close filled"> ' +
          r(86) +
          " " +
          r(9525) +
          ' </a> <div class="kargo-hover-close-progress filled"></div> <div class="kargo-hover-content VAR_DESKTOP_HOVER"> <a class="kargo-hover-link unfilled VAR_SIDEKICK_BRANDING VAR_TRIPLEX" href=https://www.kargo.com/privacy target=_blank> ' +
          r(81) +
          " " +
          r(3742) +
          ' </a> <a class="kargo-hover-close unfilled VAR_RUNWAY VAR_LEFT_ALIGN"> ' +
          r(86) +
          " " +
          r(9525) +
          ' </a> <div class="kargo-hover-close-progress unfilled"></div> <div class=kargo-ad-content> <a class="kargo-hover-optout VAR_BRANDING" href=https://www.kargo.com/privacy target=_blank> ' +
          r(9475) +
          " " +
          r(9262) +
          " </a> </div> </div> </div> ";
      },
      9452: (t, e, r) => {
        t.exports =
          '<div class="kargo-ad-hover VAR_BRANDING"> <div class=kargo-ad-content> <a class="kargo-hover-optout VAR_BRANDING" href=https://www.kargo.com/privacy target=_blank> ' +
          r(9475) +
          " " +
          r(9262) +
          " </a> </div> </div> ";
      },
      81: (t) => {
        t.exports =
          '<svg class=kargo-svg-advertisement xmlns=http://www.w3.org/2000/svg viewBox="0 0 108.96143 12.34375"> <text transform="translate(0 8.58)" font-size=10 fill=#AAAAAA font-family="Arial-BoldMT, Arial" font-weight=700 letter-spacing=.18em>ADVERTISEMENT</text> </svg> ';
      },
      9475: (t) => {
        t.exports =
          '<svg class=kargo-svg-bolt xmlns=http://www.w3.org/2000/svg viewBox="0 0 12.93951 18.88957"> <path d="M12.94 7.948H7.682L10.589 0 0 10.941h5.257L2.35 18.89 12.94 7.948z"/> </svg> ';
      },
      5822: (t) => {
        t.exports =
          '<?xml version="1.0" encoding="UTF-8"?> <svg class=by-kargo-svg-grey id=Layer_2 data-name="Layer 2" xmlns=http://www.w3.org/2000/svg viewBox="0 0 60.01 9.98"> <g id=Layer_1-2 data-name="Layer 1"> <g> <g fill=#abacab> <path d=m15.5,6.55c0,1.11-.76,1.93-2.31,1.93h-2.94V1.5h2.56c1.51,0,2.32.59,2.32,1.7,0,.63-.29,1.27-1.07,1.56h0c.92.24,1.44.86,1.44,1.79Zm-3.87-2.19h1.01c.56,0,1.07-.26,1.07-.83,0-.49-.34-.81-1.16-.81h-.92v1.64Zm2.4,2.02c0-.55-.41-.9-1.25-.9h-1.15v1.79h1.14c.75,0,1.26-.29,1.26-.89Z /> <path d=m22.01,1.5l-2.37,3.91v3.07h-1.42v-3.07l-2.35-3.91h1.61l1.45,2.55h.02l1.43-2.55h1.63Z /> <path d=m27.62,5.68l-.7.82v1.98h-1.4V1.5h1.4v3.08h0l2.46-3.08h1.78l-2.62,3.08,2.7,3.9h-1.73l-1.89-2.8h0Z /> <path d=m36.28,7.09h-2.73l-.48,1.4h-1.47l2.63-6.98h1.35l2.65,6.98h-1.47l-.48-1.4Zm-.41-1.18l-.95-2.74h-.02l-.94,2.74h1.91Z /> <path d=m42.98,8.48l-1.59-2.39h-.82v2.39h-1.39V1.5h2.69c1.71,0,2.47.98,2.47,2.32,0,1.12-.55,1.81-1.46,2.1l1.76,2.56h-1.66Zm-2.41-3.61h.98c.87,0,1.34-.43,1.34-1.08s-.46-1.06-1.28-1.06h-1.04v2.14Z /> <path d=m45.23,5c0-2.04,1.35-3.59,3.57-3.59,1,0,2.09.38,2.82,1.2l-1,.83c-.44-.41-1.04-.72-1.82-.72-1.17,0-2.1.85-2.1,2.28,0,1.28.82,2.28,2.16,2.28.51,0,.98-.12,1.44-.39v-1.03h-1.6v-1.18h2.95v3.01c-.64.51-1.7.86-2.79.86-2.05,0-3.63-1.31-3.63-3.55Z /> <path d=m52.77,4.99c0-2.07,1.47-3.58,3.62-3.58s3.61,1.45,3.61,3.58-1.52,3.57-3.61,3.57-3.62-1.5-3.62-3.57Zm5.77,0c0-1.32-.92-2.28-2.14-2.28-1.28,0-2.17,1.01-2.17,2.28s.89,2.28,2.17,2.28,2.14-.97,2.14-2.28Z /> </g> <g fill=#ff7500> <path d=m2.89,5.82s0,0,0,0c-.01.03-.03.07-.04.1-.08.23-.17.45-.25.68-.06.17-.13.33-.19.5-.07.19-.14.38-.21.58-.06.16-.12.32-.18.48-.06.16-.12.33-.18.49-.06.16-.12.32-.18.48-.07.19-.14.38-.21.57-.03.09-.07.19-.1.28,0,0,0,0,0,0,1.95-1.94,3.9-3.87,5.87-5.82h-.08c-.92,0-1.84,0-2.76,0-.02,0-.04,0-.06,0,0,0,0,0,0,0,0,0,0-.02,0-.02.07-.19.15-.38.22-.58.05-.13.1-.27.15-.4.05-.13.1-.26.15-.38.05-.14.11-.28.16-.42.06-.15.12-.31.18-.46.07-.18.14-.36.21-.54.07-.19.15-.38.22-.57.07-.19.15-.37.22-.56.03-.07.05-.15.08-.22,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0-.01.01-.03.02-.04.04-.71.7-1.42,1.39-2.13,2.09C2.52,3.35,1.28,4.56.05,5.78c-.01.01-.03.03-.05.05h.07c.92,0,1.84,0,2.76,0,.02,0,.04,0,.06,0Z /> <path d=m5.93,0c-.02.07-.05.15-.08.22-.07.19-.14.37-.22.56-.07.19-.15.38-.22.57-.07.18-.14.36-.21.54-.06.15-.12.31-.18.46-.05.14-.11.28-.16.42-.05.13-.1.26-.15.38-.05.13-.1.27-.15.4-.07.19-.15.38-.22.58,0,0,0,.02,0,.02,0,0,0,0,0,0,.02,0,.04,0,.06,0,.92,0,1.84,0,2.76,0h.08c-1.96,1.95-3.91,3.88-5.87,5.82,0,0,0,0,0,0,.04-.09.07-.19.1-.28.07-.19.14-.38.21-.57.06-.16.12-.32.18-.48.06-.16.12-.33.18-.49.06-.16.12-.32.18-.48.07-.19.14-.38.21-.58.06-.17.13-.33.19-.5.08-.23.17-.45.25-.68.01-.03.03-.07.04-.1,0,0,0,0,0,0-.02,0-.04,0-.06,0-.92,0-1.84,0-2.76,0h-.07s.03-.03.05-.05c1.24-1.22,2.48-2.43,3.71-3.65.71-.7,1.42-1.39,2.13-2.09.01-.01.03-.02.04-.04h0Z /> <polygon points="5.93 0 5.93 0 5.93 0 5.93 0 5.93 0"/> <path d=m4.34,4.16s0,0,0,0c0,0,0,0,0,0Z /> <path d=m2.89,5.82s0,0,0,0c0,0,0,0,0,0Z /> </g> </g> </g> </svg>';
      },
      3742: (t) => {
        t.exports =
          '<?xml version="1.0" encoding="UTF-8"?> <svg class=by-kargo-svg-white id=Layer_2 data-name="Layer 2" xmlns=http://www.w3.org/2000/svg viewBox="0 0 60.01 9.98"> <g id=Layer_1-2 data-name="Layer 1"> <g> <g fill=#fff> <path d=m15.5,6.55c0,1.11-.76,1.93-2.31,1.93h-2.94V1.5h2.56c1.51,0,2.32.59,2.32,1.7,0,.63-.29,1.27-1.07,1.56h0c.92.24,1.44.86,1.44,1.79Zm-3.87-2.19h1.01c.56,0,1.07-.26,1.07-.83,0-.49-.34-.81-1.16-.81h-.92v1.64Zm2.4,2.02c0-.55-.41-.9-1.25-.9h-1.15v1.79h1.14c.75,0,1.26-.29,1.26-.89Z /> <path d=m22.01,1.5l-2.37,3.91v3.07h-1.42v-3.07l-2.35-3.91h1.61l1.45,2.55h.02l1.43-2.55h1.63Z /> <path d=m27.62,5.68l-.7.82v1.98h-1.4V1.5h1.4v3.08h0l2.46-3.08h1.78l-2.62,3.08,2.7,3.9h-1.73l-1.89-2.8h0Z /> <path d=m36.28,7.09h-2.73l-.48,1.4h-1.47l2.63-6.98h1.35l2.65,6.98h-1.47l-.48-1.4Zm-.41-1.18l-.95-2.74h-.02l-.94,2.74h1.91Z /> <path d=m42.98,8.48l-1.59-2.39h-.82v2.39h-1.39V1.5h2.69c1.71,0,2.47.98,2.47,2.32,0,1.12-.55,1.81-1.46,2.1l1.76,2.56h-1.66Zm-2.41-3.61h.98c.87,0,1.34-.43,1.34-1.08s-.46-1.06-1.28-1.06h-1.04v2.14Z /> <path d=m45.23,5c0-2.04,1.35-3.59,3.57-3.59,1,0,2.09.38,2.82,1.2l-1,.83c-.44-.41-1.04-.72-1.82-.72-1.17,0-2.1.85-2.1,2.28,0,1.28.82,2.28,2.16,2.28.51,0,.98-.12,1.44-.39v-1.03h-1.6v-1.18h2.95v3.01c-.64.51-1.7.86-2.79.86-2.05,0-3.63-1.31-3.63-3.55Z /> <path d=m52.77,4.99c0-2.07,1.47-3.58,3.62-3.58s3.61,1.45,3.61,3.58-1.52,3.57-3.61,3.57-3.62-1.5-3.62-3.57Zm5.77,0c0-1.32-.92-2.28-2.14-2.28-1.28,0-2.17,1.01-2.17,2.28s.89,2.28,2.17,2.28,2.14-.97,2.14-2.28Z /> </g> <g fill=#ff7500> <path d=m2.89,5.82s0,0,0,0c-.01.03-.03.07-.04.1-.08.23-.17.45-.25.68-.06.17-.13.33-.19.5-.07.19-.14.38-.21.58-.06.16-.12.32-.18.48-.06.16-.12.33-.18.49-.06.16-.12.32-.18.48-.07.19-.14.38-.21.57-.03.09-.07.19-.1.28,0,0,0,0,0,0,1.95-1.94,3.9-3.87,5.87-5.82h-.08c-.92,0-1.84,0-2.76,0-.02,0-.04,0-.06,0,0,0,0,0,0,0,0,0,0-.02,0-.02.07-.19.15-.38.22-.58.05-.13.1-.27.15-.4.05-.13.1-.26.15-.38.05-.14.11-.28.16-.42.06-.15.12-.31.18-.46.07-.18.14-.36.21-.54.07-.19.15-.38.22-.57.07-.19.15-.37.22-.56.03-.07.05-.15.08-.22,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0-.01.01-.03.02-.04.04-.71.7-1.42,1.39-2.13,2.09C2.52,3.35,1.28,4.56.05,5.78c-.01.01-.03.03-.05.05h.07c.92,0,1.84,0,2.76,0,.02,0,.04,0,.06,0Z /> <path d=m5.93,0c-.02.07-.05.15-.08.22-.07.19-.14.37-.22.56-.07.19-.15.38-.22.57-.07.18-.14.36-.21.54-.06.15-.12.31-.18.46-.05.14-.11.28-.16.42-.05.13-.1.26-.15.38-.05.13-.1.27-.15.4-.07.19-.15.38-.22.58,0,0,0,.02,0,.02,0,0,0,0,0,0,.02,0,.04,0,.06,0,.92,0,1.84,0,2.76,0h.08c-1.96,1.95-3.91,3.88-5.87,5.82,0,0,0,0,0,0,.04-.09.07-.19.1-.28.07-.19.14-.38.21-.57.06-.16.12-.32.18-.48.06-.16.12-.33.18-.49.06-.16.12-.32.18-.48.07-.19.14-.38.21-.58.06-.17.13-.33.19-.5.08-.23.17-.45.25-.68.01-.03.03-.07.04-.1,0,0,0,0,0,0-.02,0-.04,0-.06,0-.92,0-1.84,0-2.76,0h-.07s.03-.03.05-.05c1.24-1.22,2.48-2.43,3.71-3.65.71-.7,1.42-1.39,2.13-2.09.01-.01.03-.02.04-.04h0Z /> <polygon points="5.93 0 5.93 0 5.93 0 5.93 0 5.93 0"/> <path d=m4.34,4.16s0,0,0,0c0,0,0,0,0,0Z /> <path d=m2.89,5.82s0,0,0,0c0,0,0,0,0,0Z /> </g> </g> </g> </svg>';
      },
      9525: (t) => {
        t.exports =
          '<svg class=kargo-svg-close-no-border xmlns=http://www.w3.org/2000/svg viewBox="0 0 48 48"> <path d="M31.75 32.75a.997.997 0 0 1-.707-.293l-15.75-15.75a1 1 0 0 1 1.414-1.414l15.75 15.75a1 1 0 0 1-.707 1.707z"/> <path d="M16 32.75a1 1 0 0 1-.707-1.707l15.75-15.75a1 1 0 0 1 1.414 1.414l-15.75 15.75a.997.997 0 0 1-.707.293z"/> </svg> ';
      },
      86: (t) => {
        t.exports =
          '<svg class=kargo-svg-close xmlns=http://www.w3.org/2000/svg viewBox="0 0 48 48"> <path d="M24 2A22 22 0 1 1 2 24 22.025 22.025 0 0 1 24 2m0-2a24 24 0 1 0 24 24A24 24 0 0 0 24 0z"/> <path d="M31.75 32.75a.997.997 0 0 1-.707-.293l-15.75-15.75a1 1 0 0 1 1.414-1.414l15.75 15.75a1 1 0 0 1-.707 1.707z"/> <path d="M16 32.75a1 1 0 0 1-.707-1.707l15.75-15.75a1 1 0 0 1 1.414 1.414l-15.75 15.75a.997.997 0 0 1-.707.293z"/> </svg> ';
      },
      2019: (t) => {
        t.exports =
          '<svg class=kargo-svg-loader xmlns=http://www.w3.org/2000/svg width=39 height=39 viewBox="0 0 39 39" stroke=#fff> <g transform="translate(1 1)" stroke-width=3 fill=none fill-rule=evenodd> <circle stroke-opacity=.5 cx=18.5 cy=18.5 r=18 stroke=#dee2e6 /> <path d="M36.473 19.65C37.08 9.664 29.536 1.13 19.65.527" stroke=#FF7500> <animateTransform attributeName=transform type=rotate from="0 18.5 18.5" to="360 18.5 18.5" dur=1s repeatCount=indefinite /> </path> </g> </svg> ';
      },
      9262: (t) => {
        t.exports =
          '<svg class=kargo-svg-opt-out xmlns=http://www.w3.org/2000/svg viewBox="0 0 22 22"> <rect x=9.528 y=10.141 width=2.943 height=7.679 rx=1.472 ry=1.472 /> <circle cx=11 cy=6.076 r=1.897 /> <path d="M11 1.897A9.103 9.103 0 1 1 1.897 11 9.114 9.114 0 0 1 11 1.897M11 0a11 11 0 1 0 11 11A11 11 0 0 0 11 0z"/> </svg> ';
      },
      5071: (t) => {
        t.exports =
          '<svg width=61 height=26 viewBox="0 0 61 26" fill=none xmlns=http://www.w3.org/2000/svg> <rect x=0.25 y=0.25 width=60.5 height=25.5 rx=12.75 fill=black fill-opacity=0.25 stroke=white stroke-width=0.5 /> <path d="M46.0273 8.5L50.9797 13.4525M46.0272 18.4356L50.9797 13.4831" stroke=white stroke-width=1.75 stroke-linecap=round /> <path d="M15.4789 18.0916C14.8681 18.0916 14.3184 17.9869 13.8298 17.7775C13.3411 17.5594 12.9572 17.2539 12.678 16.8613C12.3988 16.4686 12.2591 16.0105 12.2591 15.487H13.8559C13.8909 15.8796 14.0436 16.2025 14.314 16.4555C14.5933 16.7086 14.9816 16.8351 15.4789 16.8351C15.9938 16.8351 16.3951 16.713 16.6831 16.4686C16.971 16.2156 17.115 15.8927 17.115 15.5001C17.115 15.1947 17.0234 14.946 16.8401 14.754C16.6656 14.5621 16.4431 14.4137 16.1726 14.309C15.9109 14.2043 15.5444 14.0909 15.0732 13.9687C14.4798 13.8116 13.9956 13.6546 13.6204 13.4975C13.2539 13.3317 12.9397 13.0787 12.678 12.7384C12.4162 12.3981 12.2853 11.9443 12.2853 11.3772C12.2853 10.8536 12.4162 10.3955 12.678 10.0029C12.9397 9.61021 13.3062 9.30917 13.7774 9.09975C14.2486 8.89034 14.794 8.78563 15.4135 8.78563C16.2948 8.78563 17.0147 9.00813 17.5731 9.45315C18.1403 9.88943 18.4544 10.4915 18.5155 11.2594H16.8663C16.8401 10.9278 16.6831 10.6442 16.3951 10.4086C16.1072 10.173 15.7276 10.0552 15.2564 10.0552C14.8289 10.0552 14.4798 10.1643 14.2093 10.3824C13.9388 10.6006 13.8036 10.9147 13.8036 11.3248C13.8036 11.604 13.8865 11.8353 14.0523 12.0185C14.2268 12.193 14.4449 12.3326 14.7067 12.4373C14.9685 12.5421 15.3262 12.6555 15.78 12.7776C16.382 12.9434 16.8707 13.1092 17.2459 13.275C17.6298 13.4408 17.9527 13.6982 18.2145 14.0472C18.4849 14.3875 18.6202 14.8456 18.6202 15.4215C18.6202 15.884 18.4937 16.3203 18.2406 16.7304C17.9963 17.1405 17.6342 17.4721 17.1543 17.7251C16.6831 17.9695 16.1246 18.0916 15.4789 18.0916ZM25.3938 18L21.8729 13.9294V18H20.3808V8.90342H21.8729V13.0525L25.4068 8.90342H27.2785L23.3258 13.4583L27.344 18H25.3938ZM30.1555 8.90342V18H28.6634V8.90342H30.1555ZM38.4756 11.6128C38.4756 12.0752 38.3665 12.5115 38.1484 12.9216C37.9302 13.3317 37.5812 13.6677 37.1013 13.9294C36.6214 14.1825 36.0062 14.309 35.2558 14.309H33.6066V18H32.1145V8.90342H35.2558C35.9539 8.90342 36.5429 9.02558 37.0228 9.2699C37.5114 9.5055 37.8735 9.82835 38.1091 10.2385C38.3534 10.6486 38.4756 11.1067 38.4756 11.6128ZM35.2558 13.0918C35.823 13.0918 36.2462 12.9653 36.5254 12.7122C36.8046 12.4504 36.9442 12.084 36.9442 11.6128C36.9442 10.618 36.3814 10.1207 35.2558 10.1207H33.6066V13.0918H35.2558Z" fill=white /> </svg> ';
      },
      7217: (t) => {
        t.exports =
          '<svg class=kargo-svg-close xmlns=http://www.w3.org/2000/svg viewBox="0 0 48 48" width=100 height=100> <circle cx=24 cy=24 r=22 fill=#696969 stroke=#FFFFFF stroke-width=4 /> <line x1=16 y1=17 x2=31.75 y2=32.75 stroke=#FFFFFF stroke-width=4 stroke-linecap=round /> <line x1=31.75 y1=17 x2=16 y2=32.75 stroke=#FFFFFF stroke-width=4 stroke-linecap=round /> </svg>';
      },
      4234: (
        __unused_webpack_module,
        __webpack_exports__,
        __webpack_require__
      ) => {
        "use strict";
        function convertNodeListToArray(t) {
          return Array.prototype.slice.call(t);
        }
        function convertStringToFunction(str) {
          return eval("(function() {".concat(str, "})"));
        }
        function executeStringFunction(t, e) {
          return convertStringToFunction(e).apply(t);
        }
        function replaceSmartCharacters(t) {
          return t
            .replace(/[\u2018\u2019]/g, "'")
            .replace(/[\u201c\u201d]/g, '"')
            .replace(/[\u2014]/g, "--");
        }
        function escapeRegexString(t) {
          return t.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&");
        }
        function fireCallbacks(t, e, r) {
          void 0 === r && (r = []);
          for (var i = 0; i < e.length; i += 1) e[i].apply(t, r);
        }
        function getSafeWindowVar(t, e) {
          var r = null;
          if (t && e && e.length) {
            r = t;
            for (var i = e.split("."), n = 0; n < i.length; n++)
              try {
                if (!r.hasOwnProperty(i[n])) {
                  r = null;
                  break;
                }
                r = r[i[n]];
              } catch (t) {
                return null;
              }
          }
          return r;
        }
        function generateUUID(t) {
          var e;
          e =
            t.crypto && t.crypto.getRandomValues
              ? function () {
                  var e = new Uint32Array(4),
                    r = new Array(16);
                  t.crypto.getRandomValues(e);
                  for (var i = 0; i < 16; i++)
                    r[i] = (e[i >> 2] >>> (8 * (3 & i))) & 255;
                  return r;
                }
              : function () {
                  var e = 0,
                    r = new Array(16),
                    i = new PRNG(
                      (function () {
                        var e, r, i, n, o, a;
                        for (
                          o = [],
                            r = i = 0,
                            n = (a =
                              new Date().getTime() +
                              Math.random().toString() +
                              t.location.href +
                              t.document.cookie).length;
                          i < n;
                          r = ++i
                        )
                          (e = a[r]), o.push(e.charCodeAt(0));
                        return o;
                      })()
                    ),
                    n = 0;
                  for (n = 0; n < 16; n++)
                    (e = 68719476736 * i.random()),
                      (r[n] = (e >>> ((3 & n) << 3)) & 255);
                  return r;
                };
          for (var r = [], i = 0; i < 256; i++)
            r[i] = (i + 256).toString(16).substr(1);
          var n = e();
          (n[6] = (15 & n[6]) | 64), (n[8] = (63 & n[8]) | 128);
          var o = (function (t) {
            var e = 0,
              i = r;
            return (
              i[t[e++]] +
              i[t[e++]] +
              i[t[e++]] +
              i[t[e++]] +
              "-" +
              i[t[e++]] +
              i[t[e++]] +
              "-" +
              i[t[e++]] +
              i[t[e++]] +
              "-" +
              i[t[e++]] +
              i[t[e++]] +
              "-" +
              i[t[e++]] +
              i[t[e++]] +
              i[t[e++]] +
              i[t[e++]] +
              i[t[e++]] +
              i[t[e++]]
            );
          })(n);
          return o;
        }
        function isArray(t) {
          return t && "[object Array]" === Object.prototype.toString.call(t);
        }
        function isDocument(t) {
          return !(!t || !t.nodeType || 9 !== t.nodeType);
        }
        function isElement(t) {
          return !(!t || !t.nodeType || 1 !== t.nodeType);
        }
        function isFunction(t) {
          return t && "[object Function]" === Object.prototype.toString.call(t);
        }
        function isObject(t) {
          return t && t === Object(t) && !isArray(t) && !isFunction(t);
        }
        function isWindow(t) {
          return !!(t && t.document && t.location && t.alert && t.setInterval);
        }
        function getObjectSize(t) {
          var e = 0;
          if (isObject(t)) for (var r in t) t.hasOwnProperty(r) && e++;
          return e;
        }
        function leftPad(t, e, r) {
          for (t += ""; t.length < e; ) t = r + t;
          return t;
        }
        function merge() {
          for (var t = [], e = 0; e < arguments.length; e++)
            t[e] = arguments[e];
          var r = !1 !== arguments[arguments.length - 1],
            i = function (t, e) {
              if ("object" != typeof e || null === e) return t;
              if (!isElement(e) && !isWindow(e) && !isDocument(e))
                for (var n in e) {
                  var o = e[n];
                  e.hasOwnProperty(n) &&
                    void 0 !== o &&
                    ((!r && t[n]) ||
                      (isElement(o) ||
                      isWindow(o) ||
                      isDocument(o) ||
                      "object" != typeof o ||
                      null === o
                        ? (t[n] = o)
                        : "object" != typeof t[n] || null === t[n]
                        ? (t[n] = i(Array.isArray(o) ? [] : {}, o))
                        : Array.isArray(t[n]) && Array.isArray(o)
                        ? (t[n] = t[n].concat(o))
                        : i(t[n], o)));
                }
              return t;
            },
            n = arguments[0] || {};
          if (!n || n !== Object(n)) return n;
          for (var o = 1; o < arguments.length; o++) i(n, arguments[o]);
          return n;
        }
        function spliceString(t, e, r) {
          return t.slice(0, r) + e + t.slice(r, t.length);
        }
        function safeStringReplace(t, e, r) {
          return "string" != typeof r
            ? t.replace(e, r)
            : t.replace(e, r.replace(/\$/g, "$$$$"));
        }
        function setIntervalWithTimeout(t, e, r, i) {
          var n = !1,
            o = t.setInterval(function () {
              n ? t.clearInterval(o) : e();
            }, r);
          return (
            t.setTimeout(function () {
              n = !0;
            }, i),
            o
          );
        }
        __webpack_require__.d(__webpack_exports__, {
          cy: () => isArray,
          h1: () => merge,
          xF: () => getSafeWindowVar,
        });
      },
      3629: (
        __unused_webpack_module,
        __webpack_exports__,
        __webpack_require__
      ) => {
        "use strict";
        __webpack_require__.d(__webpack_exports__, {
          AF: () => escapeRegexString,
          PX: () => leftPad,
          _o: () => spliceString,
          a: () => replaceSmartCharacters,
          cy: () => isArray,
          h1: () => merge,
          lP: () => fireCallbacks,
          lk: () => generateUUID,
          xF: () => getSafeWindowVar,
          xP: () => safeStringReplace,
          zH: () => executeStringFunction,
        });
        var _prng__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9775);
        function convertNodeListToArray(t) {
          return Array.prototype.slice.call(t);
        }
        function convertStringToFunction(str) {
          return eval("(function() {".concat(str, "})"));
        }
        function executeStringFunction(t, e) {
          return convertStringToFunction(e).apply(t);
        }
        function replaceSmartCharacters(t) {
          return t
            .replace(/[\u2018\u2019]/g, "'")
            .replace(/[\u201c\u201d]/g, '"')
            .replace(/[\u2014]/g, "--");
        }
        function escapeRegexString(t) {
          return t.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&");
        }
        function fireCallbacks(t, e, r) {
          void 0 === r && (r = []);
          for (var i = 0; i < e.length; i += 1) e[i].apply(t, r);
        }
        function getSafeWindowVar(t, e) {
          var r = null;
          if (t && e && e.length) {
            r = t;
            for (var i = e.split("."), n = 0; n < i.length; n++)
              try {
                if (!r.hasOwnProperty(i[n])) {
                  r = null;
                  break;
                }
                r = r[i[n]];
              } catch (t) {
                return null;
              }
          }
          return r;
        }
        function generateUUID(t) {
          var e;
          e =
            t.crypto && t.crypto.getRandomValues
              ? function () {
                  var e = new Uint32Array(4),
                    r = new Array(16);
                  t.crypto.getRandomValues(e);
                  for (var i = 0; i < 16; i++)
                    r[i] = (e[i >> 2] >>> (8 * (3 & i))) & 255;
                  return r;
                }
              : function () {
                  var e = 0,
                    r = new Array(16),
                    i = new _prng__WEBPACK_IMPORTED_MODULE_0__.c(
                      (function () {
                        var e, r, i, n, o, a;
                        for (
                          o = [],
                            r = i = 0,
                            n = (a =
                              new Date().getTime() +
                              Math.random().toString() +
                              t.location.href +
                              t.document.cookie).length;
                          i < n;
                          r = ++i
                        )
                          (e = a[r]), o.push(e.charCodeAt(0));
                        return o;
                      })()
                    ),
                    n = 0;
                  for (n = 0; n < 16; n++)
                    (e = 68719476736 * i.random()),
                      (r[n] = (e >>> ((3 & n) << 3)) & 255);
                  return r;
                };
          for (var r = [], i = 0; i < 256; i++)
            r[i] = (i + 256).toString(16).substr(1);
          var n = e();
          (n[6] = (15 & n[6]) | 64), (n[8] = (63 & n[8]) | 128);
          var o = (function (t) {
            var e = 0,
              i = r;
            return (
              i[t[e++]] +
              i[t[e++]] +
              i[t[e++]] +
              i[t[e++]] +
              "-" +
              i[t[e++]] +
              i[t[e++]] +
              "-" +
              i[t[e++]] +
              i[t[e++]] +
              "-" +
              i[t[e++]] +
              i[t[e++]] +
              "-" +
              i[t[e++]] +
              i[t[e++]] +
              i[t[e++]] +
              i[t[e++]] +
              i[t[e++]] +
              i[t[e++]]
            );
          })(n);
          return o;
        }
        function isArray(t) {
          return t && "[object Array]" === Object.prototype.toString.call(t);
        }
        function isDocument(t) {
          return !(!t || !t.nodeType || 9 !== t.nodeType);
        }
        function isElement(t) {
          return !(!t || !t.nodeType || 1 !== t.nodeType);
        }
        function isFunction(t) {
          return t && "[object Function]" === Object.prototype.toString.call(t);
        }
        function isObject(t) {
          return t && t === Object(t) && !isArray(t) && !isFunction(t);
        }
        function isWindow(t) {
          return !!(t && t.document && t.location && t.alert && t.setInterval);
        }
        function getObjectSize(t) {
          var e = 0;
          if (isObject(t)) for (var r in t) t.hasOwnProperty(r) && e++;
          return e;
        }
        function leftPad(t, e, r) {
          for (t += ""; t.length < e; ) t = r + t;
          return t;
        }
        function merge() {
          for (var t = [], e = 0; e < arguments.length; e++)
            t[e] = arguments[e];
          var r = !1 !== arguments[arguments.length - 1],
            i = function (t, e) {
              if ("object" != typeof e || null === e) return t;
              if (!isElement(e) && !isWindow(e) && !isDocument(e))
                for (var n in e) {
                  var o = e[n];
                  e.hasOwnProperty(n) &&
                    void 0 !== o &&
                    ((!r && t[n]) ||
                      (isElement(o) ||
                      isWindow(o) ||
                      isDocument(o) ||
                      "object" != typeof o ||
                      null === o
                        ? (t[n] = o)
                        : "object" != typeof t[n] || null === t[n]
                        ? (t[n] = i(Array.isArray(o) ? [] : {}, o))
                        : Array.isArray(t[n]) && Array.isArray(o)
                        ? (t[n] = t[n].concat(o))
                        : i(t[n], o)));
                }
              return t;
            },
            n = arguments[0] || {};
          if (!n || n !== Object(n)) return n;
          for (var o = 1; o < arguments.length; o++) i(n, arguments[o]);
          return n;
        }
        function spliceString(t, e, r) {
          return t.slice(0, r) + e + t.slice(r, t.length);
        }
        function safeStringReplace(t, e, r) {
          return "string" != typeof r
            ? t.replace(e, r)
            : t.replace(e, r.replace(/\$/g, "$$$$"));
        }
        function setIntervalWithTimeout(t, e, r, i) {
          var n = !1,
            o = t.setInterval(function () {
              n ? t.clearInterval(o) : e();
            }, r);
          return (
            t.setTimeout(function () {
              n = !0;
            }, i),
            o
          );
        }
      },
      9486: (t, e, r) => {
        "use strict";
        r.d(e, { qw: () => a, wm: () => v });
        var i,
          n =
            ((i = function (t, e) {
              return (
                (i =
                  Object.setPrototypeOf ||
                  ({ __proto__: [] } instanceof Array &&
                    function (t, e) {
                      t.__proto__ = e;
                    }) ||
                  function (t, e) {
                    for (var r in e)
                      Object.prototype.hasOwnProperty.call(e, r) &&
                        (t[r] = e[r]);
                  }),
                i(t, e)
              );
            }),
            function (t, e) {
              if ("function" != typeof e && null !== e)
                throw new TypeError(
                  "Class extends value " +
                    String(e) +
                    " is not a constructor or null"
                );
              function r() {
                this.constructor = t;
              }
              i(t, e),
                (t.prototype =
                  null === e
                    ? Object.create(e)
                    : ((r.prototype = e.prototype), new r()));
            }),
          o = function () {
            return (
              (o =
                Object.assign ||
                function (t) {
                  for (var e, r = 1, i = arguments.length; r < i; r++)
                    for (var n in (e = arguments[r]))
                      Object.prototype.hasOwnProperty.call(e, n) &&
                        (t[n] = e[n]);
                  return t;
                }),
              o.apply(this, arguments)
            );
          },
          a = (function (t) {
            function e(e, r) {
              void 0 === r && (r = {});
              var i = this.constructor,
                n = t.call(this, e) || this;
              return (
                Object.setPrototypeOf(n, i.prototype),
                (n.message = n.buildErrorMessage(e || "", r)),
                n
              );
            }
            return (
              n(e, t),
              (e.prototype.addContext = function (t, e) {
                var r = e.ctx,
                  i = e.moduleName,
                  n = e.prep,
                  o = e.reason,
                  a = t || "";
                if ((i && (a = "".concat(i, ": ").concat(a)), r)) {
                  var s = n || "in";
                  a = "".concat(a, " ").concat(s, " ").concat(r);
                }
                return o && (a += ": ".concat(o)), a;
              }),
              (e.prototype.buildErrorMessage = function (t, e) {
                return this.addContext(t, e);
              }),
              e
            );
          })(Error),
          s = (function (t) {
            function e() {
              return (null !== t && t.apply(this, arguments)) || this;
            }
            return (
              n(e, t),
              (e.prototype.buildErrorMessage = function (t, e) {
                return this.addContext("Cannot ".concat(t), e);
              }),
              e
            );
          })(a),
          c = (function (t) {
            function e() {
              return (null !== t && t.apply(this, arguments)) || this;
            }
            return (
              n(e, t),
              (e.prototype.buildErrorMessage = function (t, e) {
                return this.addContext("".concat(t, " is disabled"), e);
              }),
              e
            );
          })(a),
          l = (function (t) {
            function e() {
              return (null !== t && t.apply(this, arguments)) || this;
            }
            return (
              n(e, t),
              (e.prototype.buildErrorMessage = function (t, e) {
                return this.addContext("Cannot load ".concat(t), e);
              }),
              e
            );
          })(a),
          u = (function (t) {
            function e() {
              return (null !== t && t.apply(this, arguments)) || this;
            }
            return (
              n(e, t),
              (e.prototype.buildErrorMessage = function (t, e) {
                return this.addContext("Cannot get ".concat(t), e);
              }),
              e
            );
          })(a),
          h = (function (t) {
            function e() {
              return (null !== t && t.apply(this, arguments)) || this;
            }
            return (
              n(e, t),
              (e.prototype.buildErrorMessage = function (t, e) {
                var r = t ? "No ".concat(t) : "Empty",
                  i = "".concat(r, " response");
                return this.addContext(i, e);
              }),
              e
            );
          })(a),
          d = (function (t) {
            function e() {
              return (null !== t && t.apply(this, arguments)) || this;
            }
            return (
              n(e, t),
              (e.prototype.buildErrorMessage = function (t, e) {
                return this.addContext(
                  "".concat(t, " not supported"),
                  o({ prep: e.prep || "by" }, e)
                );
              }),
              e
            );
          })(a),
          p = (function (t) {
            function e() {
              return (null !== t && t.apply(this, arguments)) || this;
            }
            return (
              n(e, t),
              (e.prototype.buildErrorMessage = function (t, e) {
                return this.addContext("".concat(t, " is not set"), e);
              }),
              e
            );
          })(a),
          g = (function (t) {
            function e() {
              return (null !== t && t.apply(this, arguments)) || this;
            }
            return (
              n(e, t),
              (e.prototype.buildErrorMessage = function (t, e) {
                return this.addContext("".concat(t, " is invalid"), e);
              }),
              e
            );
          })(a),
          f = (function (t) {
            function e() {
              return (null !== t && t.apply(this, arguments)) || this;
            }
            return (
              n(e, t),
              (e.prototype.buildErrorMessage = function (t, e) {
                return this.addContext(
                  "Request for ".concat(t, " timed out"),
                  o({ prep: e.prep || "after" }, e)
                );
              }),
              e
            );
          })(a),
          v = (function () {
            function t(t) {
              this.moduleName = t;
            }
            return (
              (t.prototype.errCant = function (t, e, r) {
                return new s(t, {
                  ctx: e,
                  reason: r,
                  moduleName: this.moduleName,
                });
              }),
              (t.prototype.errDisabled = function (t, e) {
                return new c("".concat(t), {
                  ctx: e,
                  moduleName: this.moduleName,
                });
              }),
              (t.prototype.errLoad = function (t, e) {
                return new l("".concat(t), {
                  ctx: e,
                  moduleName: this.moduleName,
                });
              }),
              (t.prototype.errGet = function (t, e) {
                return new u("".concat(t), {
                  ctx: e,
                  moduleName: this.moduleName,
                });
              }),
              (t.prototype.errNew = function (t) {
                return new a(t, { moduleName: this.moduleName });
              }),
              (t.prototype.errNoResponse = function (t, e) {
                return new h(t, { ctx: e, moduleName: this.moduleName });
              }),
              (t.prototype.errNoSupport = function (t, e) {
                return new d(t, {
                  ctx: e,
                  prep: "by",
                  moduleName: this.moduleName,
                });
              }),
              (t.prototype.errNotSet = function (t, e) {
                return new p(t, { ctx: e, moduleName: this.moduleName });
              }),
              (t.prototype.errInvalid = function (t, e) {
                return new g(t, { ctx: e, moduleName: this.moduleName });
              }),
              (t.prototype.errTimeout = function (t, e) {
                return new f(t, { ctx: e, moduleName: this.moduleName });
              }),
              t
            );
          })();
      },
      2840: (t, e, r) => {
        "use strict";
        r.d(e, { V: () => g });
        var i = r(3629),
          n = r(7833),
          o = r(4845),
          a = r(8509),
          s = r(3746),
          c = (function () {
            function t(t, e, r, i, n) {
              void 0 === n && (n = 1),
                (this.win = t),
                (this.dataBucket = e),
                (this.allowedReportParamKeys = r),
                (this.params = i),
                (this.counter = n);
            }
            return (
              (t.prototype.createReportUrl = function () {
                var t = this,
                  e = "".concat("https://ad-monitor.kargo.com", "?data="),
                  r = this.dataBucket;
                return (
                  Object.keys(this.params).forEach(function (e) {
                    if (t.allowedReportParamKeys.has(e)) {
                      var i = t.params[e];
                      if (i || 0 === i || !1 === i) {
                        var n = t.escapeLineProtocolTagKeyOrValue(t.params[e]);
                        r += ","
                          .concat(t.escapeLineProtocolTagKeyOrValue(e), "=")
                          .concat(n);
                      }
                    }
                  }),
                  (r += " value=".concat(this.counter)),
                  "".concat(e).concat(encodeURIComponent(r))
                );
              }),
              (t.prototype.escapeLineProtocolTagKeyOrValue = function (t) {
                return "object" == typeof t
                  ? "invalid"
                  : "".concat(t).replace(/,|\s|=/g, "\\$&");
              }),
              (t.prototype.report = function () {
                try {
                  var t = this.createReportUrl();
                  (0, n.jN)(
                    t,
                    this.win,
                    { timeout: 1e3, withCredentials: !1 },
                    function () {}
                  );
                } catch (t) {
                  console.error(t);
                }
              }),
              t
            );
          })(),
          l = new Set([
            "branch_test",
            "browser",
            "err_code",
            "format",
            "frame_type",
            "os",
            "platform",
            "version",
          ]),
          u = "safeframe",
          h = "iframe",
          d = "main_frame",
          p = { 1: "error", 2: "warn", 3: "log", 4: "debug" },
          g = (function () {
            function t(t, e, r, i) {
              void 0 === e && (e = ""),
                void 0 === r && (r = 3),
                void 0 === i && (i = true),
                (this.label = e),
                (this.level = r),
                (this.reportingEnabled = i),
                (this.win = t);
            }
            return (
              (t.prototype.setLabel = function (t) {
                this.label = t;
              }),
              (t.prototype.setLevel = function (t) {
                this.level = t;
              }),
              (t.prototype.setReporting = function (t) {
                this.reportingEnabled = t;
              }),
              (t.prototype.getLabelString = function () {
                var t = "[KARGO]";
                if (this.label)
                  if ((0, i.cy)(this.label))
                    for (var e = 0; e < this.label.length; e += 1)
                      t += "[".concat(this.label[e], "]");
                  else t += "[".concat(this.label, "]");
                return t;
              }),
              (t.prototype.write = function (t, e) {
                var r;
                if ((0, i.cy)(e) && 0 !== e.length) {
                  var n = (0, o.pO)(this.win),
                    a = (0, i.xF)(this.win, "Kargo.Config.getGlobalConfig");
                  if (
                    (a && a() && a().isDebug()) ||
                    (0, o.P3)(n, "krg_debug") ||
                    t <= this.level
                  ) {
                    var s = e;
                    4 === t
                      ? (s = [
                          "%c".concat(this.getLabelString()),
                          "color: #FF7500",
                        ].concat(s))
                      : s.unshift(this.getLabelString());
                    for (var c = 0; c < s.length; c += 1)
                      s[c] instanceof Error
                        ? (s[c] =
                            (s[c].name ? "".concat(s[c].name, " - ") : "") +
                            s[c].message)
                        : "object" != typeof s[c] ||
                          s[c] instanceof HTMLElement ||
                          (s[c] = (0, i.h1)({}, s[c]));
                    try {
                      (r = this.win.console)[p[t]].apply(r, s);
                    } catch (t) {}
                  }
                }
              }),
              (t.prototype.log = function () {
                for (var t = [], e = 0; e < arguments.length; e++)
                  t[e] = arguments[e];
                this.write(3, t);
              }),
              (t.prototype.warn = function () {
                for (var t = [], e = 0; e < arguments.length; e++)
                  t[e] = arguments[e];
                this.write(2, t);
              }),
              (t.prototype.error = function () {
                for (var t = [], e = 0; e < arguments.length; e++)
                  t[e] = arguments[e];
                this.write(1, t);
              }),
              (t.prototype.debug = function () {
                for (var t = [], e = 0; e < arguments.length; e++)
                  t[e] = arguments[e];
                this.write(4, t);
              }),
              (t.prototype.report = function (t, e, r, s) {
                void 0 === r && (r = {}), void 0 === s && (s = !1);
                try {
                  if (this.reportingEnabled) {
                    var u = {
                      url: (0, o.pO)(this.win),
                      err_code: t,
                      msg: e,
                      platform: (0, a.uo)(this.win),
                      os: (0, a.R0)(this.win),
                      browser: (0, a.X5)(this.win),
                    };
                    (u = (0, i.h1)(u, r)).frame_type = this.getFrameType();
                    var h =
                        "https://s3.amazonaws.com/log.kargo.com/adtag.error",
                      d = [];
                    Object.keys(u).forEach(function (t) {
                      d.push(
                        ""
                          .concat(encodeURIComponent(t), "=")
                          .concat(encodeURIComponent(u[t]))
                      );
                    });
                    var p = d.join("&");
                    if (
                      (p.length && (h += "?".concat(p)),
                      (h = this.scrubString(h)),
                      (0, n.Ho)(this.win, h),
                      !s)
                    )
                      new c(this.win, "ad-tag-error", l, u).report();
                  }
                } catch (t) {
                  console.error(t);
                }
              }),
              (t.prototype.getFrameType = function () {
                return (0, s.r1)(this.win) ? u : (0, s.GZ)(this.win) ? h : d;
              }),
              (t.prototype.reportAdMetric = function (t, e) {
                var r = {
                  format: t.adFormat,
                  version: t.adTagVersion,
                  slot: t.adSlot,
                  platform: (0, a.uo)(this.win),
                  os: (0, a.R0)(this.win),
                  browser: (0, a.X5)(this.win),
                  frame_type: this.getFrameType(),
                };
                "" !== t.errCode && (r.err_code = t.errCode),
                  "gam-iframes" === t.type && (r.gam_iframes = t.gamIframes),
                  "sticky-overlap" === t.type &&
                    (r.sticky_overlap = t.stickyOverlap),
                  "vpaid-clickable" === t.type &&
                    (r.vpaid_clickable = t.vpaidClickable),
                  t.branchTest && (r.branch_test = t.branchTest),
                  t.safeframeEvent && (r.safeframe_events = t.safeframeEvent);
                var i = ""
                    .concat(
                      "https://ad-metrics.kargo.com/api/v1/send",
                      "?metric="
                    )
                    .concat(t.type, "&value=")
                    .concat(t.value),
                  o = [];
                Object.keys(r).forEach(function (t) {
                  o.push(
                    '"'
                      .concat(encodeURIComponent(t), '":"')
                      .concat(encodeURIComponent(r[t]), '"')
                  );
                }),
                  o.length && (i += "&params={".concat(o, "}")),
                  (0, n.Fl)(i, this.win, 2e3, !1, function (t) {
                    e && e(t);
                  });
              }),
              (t.prototype.scrubString = function (t) {
                return t.replace(/%25/g, "");
              }),
              t
            );
          })();
      },
      9775: (t, e, r) => {
        "use strict";
        r.d(e, { c: () => i });
        var i = (function () {
          function t(t) {
            t || (t = [new Date().getTime()]),
              (this.N = 624),
              (this.M = 397),
              (this.MATRIX_A = 2567483615),
              (this.UPPER_MASK = 2147483648),
              (this.LOWER_MASK = 2147483647),
              (this.mt = new Array(this.N)),
              (this.mti = this.N + 1),
              this.initByArray(t);
          }
          return (
            (t.prototype.initByInt = function (t) {
              this.mt[0] = t >>> 0;
              var e = [];
              for (this.mti = 1; this.mti < this.N; this.mti++) {
                var r = this.mt[this.mti - 1] ^ (this.mt[this.mti - 1] >>> 30);
                (this.mt[this.mti] =
                  ((1812433253 * ((4294901760 & r) >>> 16)) << 16) +
                  1812433253 * (65535 & r) +
                  this.mti),
                  e.push((this.mt[this.mti] >>>= 0));
              }
              return e;
            }),
            (t.prototype.initByArray = function (t) {
              this.initByInt(19650218);
              for (
                var e = 1, r = 0, i = t.length, n = this.N > i ? this.N : i;
                n;
                n--
              ) {
                var o = this.mt[e - 1] ^ (this.mt[e - 1] >>> 30);
                (this.mt[e] =
                  (this.mt[e] ^
                    (((1664525 * ((4294901760 & o) >>> 16)) << 16) +
                      1664525 * (65535 & o))) +
                  t[r] +
                  r),
                  (this.mt[e] >>>= 0),
                  r++,
                  ++e >= this.N &&
                    ((this.mt[0] = this.mt[this.N - 1]), (e = 1)),
                  r >= i && (r = 0);
              }
              for (n = this.N - 1; n; n--) {
                o = this.mt[e - 1] ^ (this.mt[e - 1] >>> 30);
                (this.mt[e] =
                  (this.mt[e] ^
                    (((1566083941 * ((4294901760 & o) >>> 16)) << 16) +
                      1566083941 * (65535 & o))) -
                  e),
                  (this.mt[e] >>>= 0),
                  ++e >= this.N &&
                    ((this.mt[0] = this.mt[this.N - 1]), (e = 1));
              }
              this.mt[0] = 2147483648;
            }),
            (t.prototype.genRandInt32 = function () {
              var t,
                e = new Array(0, this.MATRIX_A);
              if (this.mti >= this.N) {
                var r = void 0;
                for (this.mti, this.N, r = 0; r < this.N - this.M; r++)
                  (t =
                    (this.mt[r] & this.UPPER_MASK) |
                    (this.mt[r + 1] & this.LOWER_MASK)),
                    (this.mt[r] = this.mt[r + this.M] ^ (t >>> 1) ^ e[1 & t]);
                for (; r < this.N - 1; r++)
                  (t =
                    (this.mt[r] & this.UPPER_MASK) |
                    (this.mt[r + 1] & this.LOWER_MASK)),
                    (this.mt[r] =
                      this.mt[r + (this.M - this.N)] ^ (t >>> 1) ^ e[1 & t]);
                (t =
                  (this.mt[this.N - 1] & this.UPPER_MASK) |
                  (this.mt[0] & this.LOWER_MASK)),
                  (this.mt[this.N - 1] =
                    this.mt[this.M - 1] ^ (t >>> 1) ^ e[1 & t]),
                  (this.mti = 0);
              }
              return (
                (t = this.mt[this.mti++]),
                (t ^= t >>> 11),
                (t ^= (t << 7) & 2636928640),
                (t ^= (t << 15) & 4022730752),
                (t ^= t >>> 18) >>> 0
              );
            }),
            (t.prototype.genRandInt31 = function () {
              return this.genRandInt32() >>> 1;
            }),
            (t.prototype.random = function () {
              return this.genRandInt32() * (1 / 4294967296);
            }),
            (t.prototype.genRandRes53 = function () {
              return (
                (67108864 * (this.genRandInt32() >>> 5) +
                  (this.genRandInt32() >>> 6)) *
                (1 / 9007199254740992)
              );
            }),
            t
          );
        })();
      },
      7833: (t, e, r) => {
        "use strict";
        r.d(e, {
          $_: () => v,
          Fl: () => d,
          Ho: () => c,
          KI: () => p,
          _G: () => g,
          dA: () => m,
          jN: () => f,
          k0: () => h,
        });
        var i = r(3629),
          n = r(4845),
          o = r(9486),
          a = function (t, e) {
            var r = {};
            for (var i in t)
              Object.prototype.hasOwnProperty.call(t, i) &&
                e.indexOf(i) < 0 &&
                (r[i] = t[i]);
            if (
              null != t &&
              "function" == typeof Object.getOwnPropertySymbols
            ) {
              var n = 0;
              for (i = Object.getOwnPropertySymbols(t); n < i.length; n++)
                e.indexOf(i[n]) < 0 &&
                  Object.prototype.propertyIsEnumerable.call(t, i[n]) &&
                  (r[i[n]] = t[i[n]]);
            }
            return r;
          },
          s = new o.wm("ad-util/request");
        function c(t, e, r) {
          void 0 === r && (r = !1);
          var o = e,
            a = t.document.createElement("img");
          if (
            ((a.style.position = "absolute"),
            (a.style.visibility = "hidden"),
            (a.style.left = "-9999px"),
            (a.style.top = "0"),
            r &&
              (o += ""
                .concat(e.indexOf("?") > -1 ? "&" : "?", "_cb=")
                .concat(Date.now() * Math.random())),
            -1 !== o.indexOf("tk.kargo.com"))
          ) {
            var s = (0, i.xF)(t, "Kargo.Plugin.Cerberus.getLexId");
            s && s() && (o = (0, n.JT)(o, { kid: s() }));
          }
          var c,
            l = function (t) {
              t.parentNode && t.parentNode.removeChild(t);
            };
          return (
            a.addEventListener(
              "load",
              function () {
                t.clearTimeout(c), l(a);
              },
              !1
            ),
            (c = t.setTimeout(function () {
              l(a);
            }, 8e3)),
            (a.src = o),
            t.document.body.appendChild(a),
            a
          );
        }
        function l(t) {
          t && t.start();
        }
        function u(t) {
          t && t.stop();
        }
        function h(t, e, r, i, n) {
          if ((void 0 === n && (n = {}), t && t.length)) {
            var o,
              a = e.document.head || e.document.body,
              c = n.latencyTracker,
              h = e.document.createElement("script");
            h.src = t;
            var d = !1;
            (h.onload = function () {
              u(c), e.clearTimeout(o), d || i(null, h);
            }),
              r &&
                (o = e.setTimeout(function () {
                  (d = !0),
                    n.onTimeoutFail
                      ? i(s.errTimeout(t, "".concat(r, " ms")))
                      : i(null, h);
                }, r)),
              l(c),
              a.appendChild(h);
          } else i(new Error("Invalid URL"));
        }
        function d(t, e, r, i, n, o) {
          if ((void 0 === o && (o = {}), t && t.length)) {
            var a = new XMLHttpRequest(),
              s = o.latencyTracker;
            i && (a.withCredentials = !0),
              r && (a.timeout = r),
              (a.onload = function () {
                if ((u(s), a.status >= 200 && a.status < 400)) {
                  var t = (a.responseText || "").trim();
                  if (t.length) {
                    try {
                      t = JSON.parse(t);
                    } catch (t) {}
                    n(null, t);
                  } else n(new Error("Empty Response"));
                } else
                  n(
                    new Error(
                      "GET Request Failed with Status: "
                        .concat(a.status, " - ")
                        .concat(a.statusText)
                    )
                  );
              }),
              (a.ontimeout = function (t) {
                n(t);
              }),
              (a.onerror = function (t) {
                n(t);
              }),
              a.open("GET", t, !0),
              l(s),
              a.send();
          } else n(new Error("Invalid URL"));
        }
        function p(t, e, r, i, n, o, a, s) {
          if (
            (void 0 === a && (a = {}),
            void 0 === s && (s = "application/json;charset=UTF-8"),
            t && t.length)
          ) {
            var c = new XMLHttpRequest(),
              h = a.latencyTracker;
            n && (c.withCredentials = !0),
              i && (c.timeout = i),
              (c.onload = function () {
                if ((u(h), c.status >= 200 && c.status < 400)) {
                  var t = (c.responseText || "").trim();
                  if (t.length) {
                    try {
                      t = JSON.parse(t);
                    } catch (t) {}
                    o(null, t);
                  } else o(new Error("Empty Response"));
                } else
                  o(
                    new Error(
                      "GET Request Failed with Status: "
                        .concat(c.status, " - ")
                        .concat(c.statusText)
                    )
                  );
              }),
              (c.ontimeout = function (t) {
                o(t);
              }),
              (c.onerror = function (t) {
                o(t);
              }),
              c.open("POST", t, !0),
              c.setRequestHeader("Content-Type", s),
              l(h),
              c.send(JSON.stringify(e || {}));
          } else o(new Error("Invalid URL"));
        }
        function g(t, e, r, i) {
          return h(t, e, r.timeout || null, i, a(r, ["timeout"]));
        }
        function f(t, e, r, i) {
          var n = r.timeout,
            o = void 0 === n ? 0 : n,
            s = r.withCredentials;
          return d(
            t,
            0,
            o,
            void 0 !== s && s,
            i,
            a(r, ["timeout", "withCredentials"])
          );
        }
        function v(t, e, r) {
          void 0 === r && (r = {});
          var i = r.timeout,
            n = void 0 === i ? 0 : i,
            o = a(r, ["timeout"]);
          return new Promise(function (r, i) {
            h(
              t,
              e,
              n,
              function (t, e) {
                return t ? i(t) : r(e);
              },
              o
            );
          });
        }
        function m(t, e, r) {
          return new Promise(function (i, n) {
            if (!t || 0 === t.length) return n(new Error("Invalid URL"));
            var o = r.withCredentials,
              a = r.timeout,
              s = r.latencyTracker,
              c = {};
            return (
              o && (c.credentials = "include"),
              l(s),
              (function (t, e) {
                return t
                  ? Promise.race([
                      e,
                      new Promise(function (e, r) {
                        return setTimeout(r, t, new Error("timeout"));
                      }),
                    ])
                  : e;
              })(a, e.fetch(t, c))
                .then(function (t) {
                  var e = t.headers.get("content-type");
                  return t.ok
                    ? e && -1 !== e.indexOf("application/json")
                      ? t.json()
                      : t.text()
                    : n(t);
                })
                .then(function (t) {
                  return u(s), i(t);
                })
                .catch(function (t) {
                  return n(t);
                })
            );
          });
        }
      },
      7911: (t, e, r) => {
        "use strict";
        r.d(e, { y: () => o });
        var i = r(3629),
          n = r(7833),
          o = (function () {
            function t(t, e) {
              (this.win = t), (this.logger = e), (this.kael = null);
            }
            return (
              (t.prototype.loadKael = function () {
                var t = this;
                return new Promise(function (e, r) {
                  if (t.kael) e(t.kael);
                  else {
                    t.win.Kargo = t.win.Kargo || {};
                    var i = t.win.Kargo.AnalyticsEventsLibrary;
                    if (i) (t.kael = new i()), e(t.kael);
                    else {
                      var n = t.win.document.createElement("script");
                      (n.type = "text/javascript"),
                        (n.src =
                          "https://storage.cloud.kargo.com/ad/network/kael/v1.10.0-041624.js"),
                        (n.onload = function () {
                          (i = t.win.Kargo.AnalyticsEventsLibrary)
                            ? ((t.kael = new i()), e(t.kael))
                            : r(new Error("Failed to load KAEL library"));
                        }),
                        t.win.document.head.appendChild(n);
                    }
                  }
                });
              }),
              (t.prototype.getLexId = function () {
                var t = (0, i.xF)(this.win, "Kargo.Plugin.Cerberus.getLexId");
                return t && t() ? t() : void 0;
              }),
              (t.prototype.kaelImpression = function (t, e, r) {
                var i = this;
                return this.loadKael().then(function (n) {
                  var o = {
                    group: e,
                    impressionId: r,
                    namespace: t,
                    lexId: i.getLexId(),
                    sessionId: n.getSessionId(),
                  };
                  new n.Track(o).impression();
                });
              }),
              (t.prototype.kaelCustomEvent = function (t, e, r, i, n) {
                var o = this;
                return this.loadKael().then(function (a) {
                  var s = {
                    group: e,
                    namespace: t,
                    impressionId: n,
                    lexId: o.getLexId(),
                    sessionId: a.getSessionId(),
                  };
                  new a.Track(s).custom(r, i);
                });
              }),
              (t.prototype.kaelViewability = function (t, e, r, i) {
                var n = this;
                return this.loadKael().then(function (o) {
                  var a = {
                    group: e,
                    namespace: t,
                    impressionId: i,
                    lexId: n.getLexId(),
                    sessionId: o.getSessionId(),
                  };
                  new o.Viewability(a).inViewDuration(r);
                });
              }),
              (t.prototype.trackEvent = function (t, e, r) {
                void 0 === r && (r = {});
                var o = this.getImpressionEventUrl(t, e, r);
                if (o) {
                  var a = r.impId || "",
                    s = {
                      uuid: a,
                      krg_imp_id: a,
                      aslot: e || "",
                      creative_source: r.creativeSource || "",
                      deal_id: r.deal_id || "",
                      line_item_id: r.line_item_id || "",
                    };
                  false,
                    r.creativeTemplateId &&
                      (s.creative_template_id = r.creativeTemplateId),
                    r.exp && (s.exp = r.exp),
                    r.branchTest && (s.branch_test = r.branchTest);
                  var c = (0, i.xF)(this.win, "Kargo.Plugin.Cerberus.getLexId");
                  c && c() && (s.kid = c()),
                    (0, n.KI)(
                      o,
                      s,
                      this.win,
                      0,
                      !1,
                      function () {},
                      {},
                      "text/plain"
                    );
                }
              }),
              (t.prototype.getImpressionEventUrl = function (t, e, r) {
                void 0 === r && (r = {});
                var i = null;
                return (
                  [
                    "start",
                    "request",
                    "response",
                    "serve",
                    "completeview",
                    "view",
                    "view-predict-in",
                    "view-predict-out",
                    "view-predict-in-confirmed",
                    "view-predict-in-confirmed-502",
                    "close",
                    "click",
                  ].indexOf(t) > -1 &&
                    ((i = "https://tk.kargo.com/t/"
                      .concat("imp_track", "-")
                      .concat(t, "-")
                      .concat(e)),
                    r.format && (i += "-".concat(r.format)),
                    r.server && (i += "-".concat(r.server))),
                  i
                );
              }),
              t
            );
          })();
      },
      4845: (t, e, r) => {
        "use strict";
        r.d(e, {
          JT: () => n,
          P3: () => a,
          WX: () => o,
          ox: () => c,
          pO: () => s,
        });
        var i = r(3746);
        function n(t, e) {
          if (!e) return t;
          var r,
            i = t;
          return (
            Object.keys(e).forEach(function (t) {
              (r = e[t]),
                (i += ""
                  .concat(i.indexOf("?") > -1 ? "&" : "?")
                  .concat(t, "=")
                  .concat(encodeURIComponent(r)));
            }),
            i
          );
        }
        function o(t) {
          return void 0 === t && (t = 8), Math.random().toString().substr(2, t);
        }
        function a(t, e) {
          return decodeURIComponent(
            (new RegExp("".concat(e, "=(.+?)(&|$)"), "i").exec(t) || [
              "",
              "",
            ])[1]
          );
        }
        function s(t) {
          var e = "";
          try {
            e = t.location.href;
          } catch (t) {}
          return (
            t.AMP_CONTEXT_DATA && t.AMP_CONTEXT_DATA.sourceUrl
              ? (e = t.AMP_CONTEXT_DATA.sourceUrl)
              : t.context && t.context.sourceUrl
              ? (e = t.context.sourceUrl)
              : (0, i.aX)(t) && t.document.referrer
              ? (e = t.document.referrer)
              : a(e, "content_url") && (e = a(e, "content_url")),
            e
          );
        }
        function c(t) {
          var e = document.createElement("a");
          return (e.href = t), /\./.test(e.host) ? e.host : "";
        }
      },
      8509: (t, e, r) => {
        "use strict";
        r.d(e, {
          Fr: () => R,
          Jp: () => L,
          R0: () => I,
          X5: () => S,
          uo: () => T,
          v1: () => D,
          xl: () => V,
        });
        var i = "Chrome",
          n = "Safari",
          o = "Firefox",
          a = "Opera",
          s = "MSIE",
          c = "ie",
          l = "Edge",
          u = "facebook",
          h = "twitter",
          d = "pinterest",
          p = "instagram",
          g = "snapchat",
          f = "linkedIn",
          v = "Android",
          m = "ios",
          k = "Linux",
          b = "Windows",
          y = "MacOS",
          w = "other",
          _ = "Mobile",
          A = "MobileWeb",
          C = "TabletWeb",
          E = "Desktop";
        function x(t) {
          return t.toLowerCase();
        }
        function S(t) {
          var e = t.navigator.userAgent,
            r = w;
          return (
            e.indexOf("".concat(l, "/")) > -1
              ? (r = x(l))
              : e.indexOf("".concat(i, "/")) > -1
              ? (r = x(i))
              : e.indexOf("".concat(n, "/")) > -1
              ? (r = x(n))
              : e.indexOf("".concat(o, "/")) > -1
              ? (r = x(o))
              : e.indexOf(a) > -1
              ? (r = x(a))
              : e.indexOf(s) > -1 || e.indexOf("Trident/") > -1
              ? (r = c)
              : e.indexOf("FBAN/FBForIPhone") > -1 ||
                e.indexOf("FBAN/FBIOS") > -1 ||
                e.indexOf("facebookexternalhit/") > -1
              ? (r = u)
              : e.indexOf("Twitter for iPhone") > -1
              ? (r = h)
              : e.indexOf("Instagram") > -1
              ? (r = p)
              : e.indexOf("Pinterest") > -1
              ? (r = d)
              : e.indexOf("LinkedInApp") > -1
              ? (r = f)
              : e.indexOf("Snapchat") > -1 && (r = g),
            r
          );
        }
        function I(t) {
          var e = t.navigator.userAgent,
            r = w;
          return (
            e.indexOf(v) > -1
              ? (r = x(v))
              : /iP(hone|od|ad)/.test(e)
              ? (r = m)
              : /windows/i.test(e)
              ? (r = b)
              : /macintosh/i.test(e)
              ? (r = y)
              : /linux/i.test(e) && (r = k),
            r
          );
        }
        function O(t) {
          var e = I(t),
            r = {};
          (r[x(v)] = "android"),
            (r[x(m)] = "os"),
            (r[x(y)] = "mac os x"),
            (r[x(b)] = "windows nt");
          var i = r[x(e)],
            n = new RegExp(
              "".concat(i, "\\s+(\\d+)[_\\.](\\d+)?[_\\.]?(\\d+)?")
            ),
            o = x(t.navigator.userAgent).match(n) || [0, 0];
          return parseInt(o[1], 10);
        }
        function R(t) {
          var e = t.navigator.userAgent;
          return e.indexOf(_) > -1 && !/iPad|Xoom|SCH-I800|Kindle/.test(e);
        }
        function D(t) {
          var e = t.navigator.userAgent;
          return (
            /iPad|Xoom|SCH-I800|Kindle/.test(e) ||
            (e.indexOf(v) >= 0 && e.indexOf(_) < 0)
          );
        }
        function T(t) {
          return R(t) ? A : D(t) ? C : E;
        }
        function V(t) {
          return !(R(t) || D(t));
        }
        function L(t) {
          var e = I(t),
            r = O(t),
            o = S(t),
            a = (function (t) {
              var e = t.navigator.userAgent,
                r = S(t),
                i = 0;
              if (r === x(n)) i = O(t);
              else {
                var o = "".concat(r, "\\/(\\d+)\\.?");
                i = parseInt((x(e).match(o) || ["0", "0"])[1], 10);
              }
              return i;
            })(t);
          return (
            (e === x(v) && o === x(i) && a > 52) || (e === m && r > 9) || V(t)
          );
        }
      },
      3746: (t, e, r) => {
        "use strict";
        function i(t, e) {
          var r = e.Kargo,
            i = t.Kargo,
            n = e.context;
          if (
            (t !== e
              ? r
                ? i !== r && (t.Kargo = r)
                : ((t.Kargo = i || {}), (e.Kargo = t.Kargo))
              : (e.Kargo = r || {}),
            n && n.master && e !== n.master)
          ) {
            var o = n.master;
            o.Kargo
              ? o.Kargo !== e.Kargo && (e.Kargo = o.Kargo)
              : (o.Kargo = e.Kargo);
          }
          return e.Kargo;
        }
        function n(t) {
          for (var e = t, r = t.top; e !== r; ) {
            var i = void 0;
            try {
              i = e.parent.location.href;
            } catch (t) {
              i = !1;
            }
            if (!i) break;
            for (
              var n = e.parent.document.getElementsByTagName("iframe"),
                o = void 0,
                a = null,
                s = 0;
              s < n.length;
              s += 1
            )
              if ((o = n[s]).contentWindow === e) {
                a = o;
                break;
              }
            if (a) if (a.className.split(" ").indexOf("krg-nobust") > -1) break;
            if (e.mraid && "function" == typeof e.mraid.getVersion) break;
            e = e.parent;
          }
          return e;
        }
        function o(t) {
          var e;
          try {
            e = t.top.location.href;
          } catch (t) {
            e = null;
          }
          return !e;
        }
        function a(t) {
          try {
            return t.self !== t.top;
          } catch (t) {
            return !0;
          }
        }
        function s(t) {
          return !(!t.$sf || !t.$sf.ext);
        }
        function c(t) {
          return !(!t.AMP_LISTENING && !t.AMP_CONTEXT_DATA);
        }
        function l(t) {
          var e,
            r = n(t),
            i = null;
          try {
            if (t !== r) {
              for (var o = t; o.parent !== r; ) o = o.parent;
              for (
                var a = r.document.getElementsByTagName("iframe"), s = 0;
                s < a.length;
                s += 1
              )
                if ((e = a[s]).contentWindow === o) {
                  i = e;
                  break;
                }
            }
          } catch (t) {}
          return i;
        }
        function u(t, e) {
          for (var r = t.parentNode; r; ) {
            if (r === e) return !0;
            r = r.parentNode;
          }
          return !1;
        }
        r.d(e, {
          Fk: () => i,
          GZ: () => a,
          ZR: () => l,
          aX: () => o,
          gh: () => c,
          r1: () => s,
          sk: () => n,
          t2: () => u,
        });
      },
      1364: (t) => {
        "use strict";
        t.exports = function (t) {
          var e = [];
          return (
            (e.toString = function () {
              return this.map(function (e) {
                var r = (function (t, e) {
                  var r = t[1] || "",
                    i = t[3];
                  if (!i) return r;
                  if (e && "function" == typeof btoa) {
                    var n =
                        ((a = i),
                        (s = btoa(
                          unescape(encodeURIComponent(JSON.stringify(a)))
                        )),
                        (c =
                          "sourceMappingURL=data:application/json;charset=utf-8;base64,".concat(
                            s
                          )),
                        "/*# ".concat(c, " */")),
                      o = i.sources.map(function (t) {
                        return "/*# sourceURL="
                          .concat(i.sourceRoot || "")
                          .concat(t, " */");
                      });
                    return [r].concat(o).concat([n]).join("\n");
                  }
                  var a, s, c;
                  return [r].join("\n");
                })(e, t);
                return e[2] ? "@media ".concat(e[2], " {").concat(r, "}") : r;
              }).join("");
            }),
            (e.i = function (t, r, i) {
              "string" == typeof t && (t = [[null, t, ""]]);
              var n = {};
              if (i)
                for (var o = 0; o < this.length; o++) {
                  var a = this[o][0];
                  null != a && (n[a] = !0);
                }
              for (var s = 0; s < t.length; s++) {
                var c = [].concat(t[s]);
                (i && n[c[0]]) ||
                  (r &&
                    (c[2]
                      ? (c[2] = "".concat(r, " and ").concat(c[2]))
                      : (c[2] = r)),
                  e.push(c));
              }
            }),
            e
          );
        };
      },
      7967: (t, e, r) => {
        var i = /^\s+|\s+$/g,
          n = /^[-+]0x[0-9a-f]+$/i,
          o = /^0b[01]+$/i,
          a = /^0o[0-7]+$/i,
          s = parseInt,
          c = "object" == typeof r.g && r.g && r.g.Object === Object && r.g,
          l = "object" == typeof self && self && self.Object === Object && self,
          u = c || l || Function("return this")(),
          h = Object.prototype.toString,
          d = Math.max,
          p = Math.min,
          g = function () {
            return u.Date.now();
          };
        function f(t) {
          var e = typeof t;
          return !!t && ("object" == e || "function" == e);
        }
        function v(t) {
          if ("number" == typeof t) return t;
          if (
            (function (t) {
              return (
                "symbol" == typeof t ||
                ((function (t) {
                  return !!t && "object" == typeof t;
                })(t) &&
                  "[object Symbol]" == h.call(t))
              );
            })(t)
          )
            return NaN;
          if (f(t)) {
            var e = "function" == typeof t.valueOf ? t.valueOf() : t;
            t = f(e) ? e + "" : e;
          }
          if ("string" != typeof t) return 0 === t ? t : +t;
          t = t.replace(i, "");
          var r = o.test(t);
          return r || a.test(t)
            ? s(t.slice(2), r ? 2 : 8)
            : n.test(t)
            ? NaN
            : +t;
        }
        t.exports = function (t, e, r) {
          var i,
            n,
            o,
            a,
            s,
            c,
            l = 0,
            u = !1,
            h = !1,
            m = !0;
          if ("function" != typeof t)
            throw new TypeError("Expected a function");
          function k(e) {
            var r = i,
              o = n;
            return (i = n = void 0), (l = e), (a = t.apply(o, r));
          }
          function b(t) {
            var r = t - c;
            return void 0 === c || r >= e || r < 0 || (h && t - l >= o);
          }
          function y() {
            var t = g();
            if (b(t)) return w(t);
            s = setTimeout(
              y,
              (function (t) {
                var r = e - (t - c);
                return h ? p(r, o - (t - l)) : r;
              })(t)
            );
          }
          function w(t) {
            return (s = void 0), m && i ? k(t) : ((i = n = void 0), a);
          }
          function _() {
            var t = g(),
              r = b(t);
            if (((i = arguments), (n = this), (c = t), r)) {
              if (void 0 === s)
                return (function (t) {
                  return (l = t), (s = setTimeout(y, e)), u ? k(t) : a;
                })(c);
              if (h) return (s = setTimeout(y, e)), k(c);
            }
            return void 0 === s && (s = setTimeout(y, e)), a;
          }
          return (
            (e = v(e) || 0),
            f(r) &&
              ((u = !!r.leading),
              (o = (h = "maxWait" in r) ? d(v(r.maxWait) || 0, e) : o),
              (m = "trailing" in r ? !!r.trailing : m)),
            (_.cancel = function () {
              void 0 !== s && clearTimeout(s),
                (l = 0),
                (i = c = n = s = void 0);
            }),
            (_.flush = function () {
              return void 0 === s ? a : w(g());
            }),
            _
          );
        };
      },
      8188: (t, e, r) => {
        var i = "__lodash_hash_undefined__",
          n = "[object Function]",
          o = "[object GeneratorFunction]",
          a = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/,
          s = /^\w*$/,
          c = /^\./,
          l =
            /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
          u = /\\(\\)?/g,
          h = /^\[object .+?Constructor\]$/,
          d = "object" == typeof r.g && r.g && r.g.Object === Object && r.g,
          p = "object" == typeof self && self && self.Object === Object && self,
          g = d || p || Function("return this")();
        var f,
          v = Array.prototype,
          m = Function.prototype,
          k = Object.prototype,
          b = g["__core-js_shared__"],
          y = (f = /[^.]+$/.exec((b && b.keys && b.keys.IE_PROTO) || ""))
            ? "Symbol(src)_1." + f
            : "",
          w = m.toString,
          _ = k.hasOwnProperty,
          A = k.toString,
          C = RegExp(
            "^" +
              w
                .call(_)
                .replace(/[\\^$.*+?()[\]{}|]/g, "\\$&")
                .replace(
                  /hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g,
                  "$1.*?"
                ) +
              "$"
          ),
          E = g.Symbol,
          x = v.splice,
          S = F(g, "Map"),
          I = F(Object, "create"),
          O = E ? E.prototype : void 0,
          R = O ? O.toString : void 0;
        function D(t) {
          var e = -1,
            r = t ? t.length : 0;
          for (this.clear(); ++e < r; ) {
            var i = t[e];
            this.set(i[0], i[1]);
          }
        }
        function T(t) {
          var e = -1,
            r = t ? t.length : 0;
          for (this.clear(); ++e < r; ) {
            var i = t[e];
            this.set(i[0], i[1]);
          }
        }
        function V(t) {
          var e = -1,
            r = t ? t.length : 0;
          for (this.clear(); ++e < r; ) {
            var i = t[e];
            this.set(i[0], i[1]);
          }
        }
        function L(t, e) {
          for (var r, i, n = t.length; n--; )
            if ((r = t[n][0]) === (i = e) || (r != r && i != i)) return n;
          return -1;
        }
        function P(t, e) {
          var r;
          e = (function (t, e) {
            if (j(t)) return !1;
            var r = typeof t;
            if (
              "number" == r ||
              "symbol" == r ||
              "boolean" == r ||
              null == t ||
              W(t)
            )
              return !0;
            return s.test(t) || !a.test(t) || (null != e && t in Object(e));
          })(e, t)
            ? [e]
            : j((r = e))
            ? r
            : B(r);
          for (var i = 0, n = e.length; null != t && i < n; ) t = t[U(e[i++])];
          return i && i == n ? t : void 0;
        }
        function M(t) {
          if (!z(t) || ((e = t), y && y in e)) return !1;
          var e,
            r =
              (function (t) {
                var e = z(t) ? A.call(t) : "";
                return e == n || e == o;
              })(t) ||
              (function (t) {
                var e = !1;
                if (null != t && "function" != typeof t.toString)
                  try {
                    e = !!(t + "");
                  } catch (t) {}
                return e;
              })(t)
                ? C
                : h;
          return r.test(
            (function (t) {
              if (null != t) {
                try {
                  return w.call(t);
                } catch (t) {}
                try {
                  return t + "";
                } catch (t) {}
              }
              return "";
            })(t)
          );
        }
        function N(t, e) {
          var r,
            i,
            n = t.__data__;
          return (
            "string" == (i = typeof (r = e)) ||
            "number" == i ||
            "symbol" == i ||
            "boolean" == i
              ? "__proto__" !== r
              : null === r
          )
            ? n["string" == typeof e ? "string" : "hash"]
            : n.map;
        }
        function F(t, e) {
          var r = (function (t, e) {
            return null == t ? void 0 : t[e];
          })(t, e);
          return M(r) ? r : void 0;
        }
        (D.prototype.clear = function () {
          this.__data__ = I ? I(null) : {};
        }),
          (D.prototype.delete = function (t) {
            return this.has(t) && delete this.__data__[t];
          }),
          (D.prototype.get = function (t) {
            var e = this.__data__;
            if (I) {
              var r = e[t];
              return r === i ? void 0 : r;
            }
            return _.call(e, t) ? e[t] : void 0;
          }),
          (D.prototype.has = function (t) {
            var e = this.__data__;
            return I ? void 0 !== e[t] : _.call(e, t);
          }),
          (D.prototype.set = function (t, e) {
            return (this.__data__[t] = I && void 0 === e ? i : e), this;
          }),
          (T.prototype.clear = function () {
            this.__data__ = [];
          }),
          (T.prototype.delete = function (t) {
            var e = this.__data__,
              r = L(e, t);
            return (
              !(r < 0) && (r == e.length - 1 ? e.pop() : x.call(e, r, 1), !0)
            );
          }),
          (T.prototype.get = function (t) {
            var e = this.__data__,
              r = L(e, t);
            return r < 0 ? void 0 : e[r][1];
          }),
          (T.prototype.has = function (t) {
            return L(this.__data__, t) > -1;
          }),
          (T.prototype.set = function (t, e) {
            var r = this.__data__,
              i = L(r, t);
            return i < 0 ? r.push([t, e]) : (r[i][1] = e), this;
          }),
          (V.prototype.clear = function () {
            this.__data__ = {
              hash: new D(),
              map: new (S || T)(),
              string: new D(),
            };
          }),
          (V.prototype.delete = function (t) {
            return N(this, t).delete(t);
          }),
          (V.prototype.get = function (t) {
            return N(this, t).get(t);
          }),
          (V.prototype.has = function (t) {
            return N(this, t).has(t);
          }),
          (V.prototype.set = function (t, e) {
            return N(this, t).set(t, e), this;
          });
        var B = H(function (t) {
          var e;
          t =
            null == (e = t)
              ? ""
              : (function (t) {
                  if ("string" == typeof t) return t;
                  if (W(t)) return R ? R.call(t) : "";
                  var e = t + "";
                  return "0" == e && 1 / t == -1 / 0 ? "-0" : e;
                })(e);
          var r = [];
          return (
            c.test(t) && r.push(""),
            t.replace(l, function (t, e, i, n) {
              r.push(i ? n.replace(u, "$1") : e || t);
            }),
            r
          );
        });
        function U(t) {
          if ("string" == typeof t || W(t)) return t;
          var e = t + "";
          return "0" == e && 1 / t == -1 / 0 ? "-0" : e;
        }
        function H(t, e) {
          if ("function" != typeof t || (e && "function" != typeof e))
            throw new TypeError("Expected a function");
          var r = function () {
            var i = arguments,
              n = e ? e.apply(this, i) : i[0],
              o = r.cache;
            if (o.has(n)) return o.get(n);
            var a = t.apply(this, i);
            return (r.cache = o.set(n, a)), a;
          };
          return (r.cache = new (H.Cache || V)()), r;
        }
        H.Cache = V;
        var j = Array.isArray;
        function z(t) {
          var e = typeof t;
          return !!t && ("object" == e || "function" == e);
        }
        function W(t) {
          return (
            "symbol" == typeof t ||
            ((function (t) {
              return !!t && "object" == typeof t;
            })(t) &&
              "[object Symbol]" == A.call(t))
          );
        }
        t.exports = function (t, e, r) {
          var i = null == t ? void 0 : P(t, e);
          return void 0 === i ? r : i;
        };
      },
      2709: (t, e, r) => {
        var i = "[object Symbol]",
          n = /[^\x00-\x2f\x3a-\x40\x5b-\x60\x7b-\x7f]+/g,
          o = /[\xc0-\xd6\xd8-\xf6\xf8-\xff\u0100-\u017f]/g,
          a = "\\ud800-\\udfff",
          s = "\\u2700-\\u27bf",
          c = "a-z\\xdf-\\xf6\\xf8-\\xff",
          l = "A-Z\\xc0-\\xd6\\xd8-\\xde",
          u =
            "\\xac\\xb1\\xd7\\xf7\\x00-\\x2f\\x3a-\\x40\\x5b-\\x60\\x7b-\\xbf\\u2000-\\u206f \\t\\x0b\\f\\xa0\\ufeff\\n\\r\\u2028\\u2029\\u1680\\u180e\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200a\\u202f\\u205f\\u3000",
          h = "['’]",
          d = "[" + u + "]",
          p = "[\\u0300-\\u036f\\ufe20-\\ufe23\\u20d0-\\u20f0]",
          g = "\\d+",
          f = "[" + s + "]",
          v = "[" + c + "]",
          m = "[^" + a + u + g + s + c + l + "]",
          k = "(?:\\ud83c[\\udde6-\\uddff]){2}",
          b = "[\\ud800-\\udbff][\\udc00-\\udfff]",
          y = "[" + l + "]",
          w = "(?:" + v + "|" + m + ")",
          _ = "(?:" + y + "|" + m + ")",
          A = "(?:['’](?:d|ll|m|re|s|t|ve))?",
          C = "(?:['’](?:D|LL|M|RE|S|T|VE))?",
          E = "(?:" + p + "|\\ud83c[\\udffb-\\udfff])" + "?",
          x = "[\\ufe0e\\ufe0f]?",
          S =
            x +
            E +
            ("(?:\\u200d(?:" +
              ["[^" + a + "]", k, b].join("|") +
              ")" +
              x +
              E +
              ")*"),
          I = "(?:" + [f, k, b].join("|") + ")" + S,
          O = RegExp(h, "g"),
          R = RegExp(p, "g"),
          D = RegExp(
            [
              y + "?" + v + "+" + A + "(?=" + [d, y, "$"].join("|") + ")",
              _ + "+" + C + "(?=" + [d, y + w, "$"].join("|") + ")",
              y + "?" + w + "+" + A,
              y + "+" + C,
              g,
              I,
            ].join("|"),
            "g"
          ),
          T =
            /[a-z][A-Z]|[A-Z]{2,}[a-z]|[0-9][a-zA-Z]|[a-zA-Z][0-9]|[^a-zA-Z0-9 ]/,
          V = "object" == typeof r.g && r.g && r.g.Object === Object && r.g,
          L = "object" == typeof self && self && self.Object === Object && self,
          P = V || L || Function("return this")();
        var M,
          N =
            ((M = {
              À: "A",
              Á: "A",
              Â: "A",
              Ã: "A",
              Ä: "A",
              Å: "A",
              à: "a",
              á: "a",
              â: "a",
              ã: "a",
              ä: "a",
              å: "a",
              Ç: "C",
              ç: "c",
              Ð: "D",
              ð: "d",
              È: "E",
              É: "E",
              Ê: "E",
              Ë: "E",
              è: "e",
              é: "e",
              ê: "e",
              ë: "e",
              Ì: "I",
              Í: "I",
              Î: "I",
              Ï: "I",
              ì: "i",
              í: "i",
              î: "i",
              ï: "i",
              Ñ: "N",
              ñ: "n",
              Ò: "O",
              Ó: "O",
              Ô: "O",
              Õ: "O",
              Ö: "O",
              Ø: "O",
              ò: "o",
              ó: "o",
              ô: "o",
              õ: "o",
              ö: "o",
              ø: "o",
              Ù: "U",
              Ú: "U",
              Û: "U",
              Ü: "U",
              ù: "u",
              ú: "u",
              û: "u",
              ü: "u",
              Ý: "Y",
              ý: "y",
              ÿ: "y",
              Æ: "Ae",
              æ: "ae",
              Þ: "Th",
              þ: "th",
              ß: "ss",
              Ā: "A",
              Ă: "A",
              Ą: "A",
              ā: "a",
              ă: "a",
              ą: "a",
              Ć: "C",
              Ĉ: "C",
              Ċ: "C",
              Č: "C",
              ć: "c",
              ĉ: "c",
              ċ: "c",
              č: "c",
              Ď: "D",
              Đ: "D",
              ď: "d",
              đ: "d",
              Ē: "E",
              Ĕ: "E",
              Ė: "E",
              Ę: "E",
              Ě: "E",
              ē: "e",
              ĕ: "e",
              ė: "e",
              ę: "e",
              ě: "e",
              Ĝ: "G",
              Ğ: "G",
              Ġ: "G",
              Ģ: "G",
              ĝ: "g",
              ğ: "g",
              ġ: "g",
              ģ: "g",
              Ĥ: "H",
              Ħ: "H",
              ĥ: "h",
              ħ: "h",
              Ĩ: "I",
              Ī: "I",
              Ĭ: "I",
              Į: "I",
              İ: "I",
              ĩ: "i",
              ī: "i",
              ĭ: "i",
              į: "i",
              ı: "i",
              Ĵ: "J",
              ĵ: "j",
              Ķ: "K",
              ķ: "k",
              ĸ: "k",
              Ĺ: "L",
              Ļ: "L",
              Ľ: "L",
              Ŀ: "L",
              Ł: "L",
              ĺ: "l",
              ļ: "l",
              ľ: "l",
              ŀ: "l",
              ł: "l",
              Ń: "N",
              Ņ: "N",
              Ň: "N",
              Ŋ: "N",
              ń: "n",
              ņ: "n",
              ň: "n",
              ŋ: "n",
              Ō: "O",
              Ŏ: "O",
              Ő: "O",
              ō: "o",
              ŏ: "o",
              ő: "o",
              Ŕ: "R",
              Ŗ: "R",
              Ř: "R",
              ŕ: "r",
              ŗ: "r",
              ř: "r",
              Ś: "S",
              Ŝ: "S",
              Ş: "S",
              Š: "S",
              ś: "s",
              ŝ: "s",
              ş: "s",
              š: "s",
              Ţ: "T",
              Ť: "T",
              Ŧ: "T",
              ţ: "t",
              ť: "t",
              ŧ: "t",
              Ũ: "U",
              Ū: "U",
              Ŭ: "U",
              Ů: "U",
              Ű: "U",
              Ų: "U",
              ũ: "u",
              ū: "u",
              ŭ: "u",
              ů: "u",
              ű: "u",
              ų: "u",
              Ŵ: "W",
              ŵ: "w",
              Ŷ: "Y",
              ŷ: "y",
              Ÿ: "Y",
              Ź: "Z",
              Ż: "Z",
              Ž: "Z",
              ź: "z",
              ż: "z",
              ž: "z",
              Ĳ: "IJ",
              ĳ: "ij",
              Œ: "Oe",
              œ: "oe",
              ŉ: "'n",
              ſ: "ss",
            }),
            function (t) {
              return null == M ? void 0 : M[t];
            });
        var F = Object.prototype.toString,
          B = P.Symbol,
          U = B ? B.prototype : void 0,
          H = U ? U.toString : void 0;
        function j(t) {
          if ("string" == typeof t) return t;
          if (
            (function (t) {
              return (
                "symbol" == typeof t ||
                ((function (t) {
                  return !!t && "object" == typeof t;
                })(t) &&
                  F.call(t) == i)
              );
            })(t)
          )
            return H ? H.call(t) : "";
          var e = t + "";
          return "0" == e && 1 / t == -1 / 0 ? "-0" : e;
        }
        function z(t) {
          return null == t ? "" : j(t);
        }
        var W,
          K =
            ((W = function (t, e, r) {
              return t + (r ? "-" : "") + e.toLowerCase();
            }),
            function (t) {
              return (function (t, e, r, i) {
                var n = -1,
                  o = t ? t.length : 0;
                for (i && o && (r = t[++n]); ++n < o; ) r = e(r, t[n], n, t);
                return r;
              })(
                (function (t, e, r) {
                  return (
                    (t = z(t)),
                    void 0 === (e = r ? void 0 : e)
                      ? (function (t) {
                          return T.test(t);
                        })(t)
                        ? (function (t) {
                            return t.match(D) || [];
                          })(t)
                        : (function (t) {
                            return t.match(n) || [];
                          })(t)
                      : t.match(e) || []
                  );
                })(
                  (function (t) {
                    return (t = z(t)) && t.replace(o, N).replace(R, "");
                  })(t).replace(O, "")
                ),
                W,
                ""
              );
            });
        t.exports = K;
      },
      3697: (t) => {
        for (var e = [], r = 0; r < 256; ++r)
          e[r] = (r + 256).toString(16).substr(1);
        t.exports = function (t, r) {
          var i = r || 0,
            n = e;
          return [
            n[t[i++]],
            n[t[i++]],
            n[t[i++]],
            n[t[i++]],
            "-",
            n[t[i++]],
            n[t[i++]],
            "-",
            n[t[i++]],
            n[t[i++]],
            "-",
            n[t[i++]],
            n[t[i++]],
            "-",
            n[t[i++]],
            n[t[i++]],
            n[t[i++]],
            n[t[i++]],
            n[t[i++]],
            n[t[i++]],
          ].join("");
        };
      },
      7240: (t) => {
        var e =
          ("undefined" != typeof crypto &&
            crypto.getRandomValues &&
            crypto.getRandomValues.bind(crypto)) ||
          ("undefined" != typeof msCrypto &&
            "function" == typeof window.msCrypto.getRandomValues &&
            msCrypto.getRandomValues.bind(msCrypto));
        if (e) {
          var r = new Uint8Array(16);
          t.exports = function () {
            return e(r), r;
          };
        } else {
          var i = new Array(16);
          t.exports = function () {
            for (var t, e = 0; e < 16; e++)
              3 & e || (t = 4294967296 * Math.random()),
                (i[e] = (t >>> ((3 & e) << 3)) & 255);
            return i;
          };
        }
      },
      7918: (t) => {
        "use strict";
        function e(t, e, r, i) {
          switch (t) {
            case 0:
              return (e & r) ^ (~e & i);
            case 1:
            case 3:
              return e ^ r ^ i;
            case 2:
              return (e & r) ^ (e & i) ^ (r & i);
          }
        }
        function r(t, e) {
          return (t << e) | (t >>> (32 - e));
        }
        t.exports = function (t) {
          var i = [1518500249, 1859775393, 2400959708, 3395469782],
            n = [1732584193, 4023233417, 2562383102, 271733878, 3285377520];
          if ("string" == typeof t) {
            var o = unescape(encodeURIComponent(t));
            t = new Array(o.length);
            for (var a = 0; a < o.length; a++) t[a] = o.charCodeAt(a);
          }
          t.push(128);
          var s = t.length / 4 + 2,
            c = Math.ceil(s / 16),
            l = new Array(c);
          for (a = 0; a < c; a++) {
            l[a] = new Array(16);
            for (var u = 0; u < 16; u++)
              l[a][u] =
                (t[64 * a + 4 * u] << 24) |
                (t[64 * a + 4 * u + 1] << 16) |
                (t[64 * a + 4 * u + 2] << 8) |
                t[64 * a + 4 * u + 3];
          }
          for (
            l[c - 1][14] = (8 * (t.length - 1)) / Math.pow(2, 32),
              l[c - 1][14] = Math.floor(l[c - 1][14]),
              l[c - 1][15] = (8 * (t.length - 1)) & 4294967295,
              a = 0;
            a < c;
            a++
          ) {
            for (var h = new Array(80), d = 0; d < 16; d++) h[d] = l[a][d];
            for (d = 16; d < 80; d++)
              h[d] = r(h[d - 3] ^ h[d - 8] ^ h[d - 14] ^ h[d - 16], 1);
            var p = n[0],
              g = n[1],
              f = n[2],
              v = n[3],
              m = n[4];
            for (d = 0; d < 80; d++) {
              var k = Math.floor(d / 20),
                b = (r(p, 5) + e(k, g, f, v) + m + i[k] + h[d]) >>> 0;
              (m = v), (v = f), (f = r(g, 30) >>> 0), (g = p), (p = b);
            }
            (n[0] = (n[0] + p) >>> 0),
              (n[1] = (n[1] + g) >>> 0),
              (n[2] = (n[2] + f) >>> 0),
              (n[3] = (n[3] + v) >>> 0),
              (n[4] = (n[4] + m) >>> 0);
          }
          return [
            (n[0] >> 24) & 255,
            (n[0] >> 16) & 255,
            (n[0] >> 8) & 255,
            255 & n[0],
            (n[1] >> 24) & 255,
            (n[1] >> 16) & 255,
            (n[1] >> 8) & 255,
            255 & n[1],
            (n[2] >> 24) & 255,
            (n[2] >> 16) & 255,
            (n[2] >> 8) & 255,
            255 & n[2],
            (n[3] >> 24) & 255,
            (n[3] >> 16) & 255,
            (n[3] >> 8) & 255,
            255 & n[3],
            (n[4] >> 24) & 255,
            (n[4] >> 16) & 255,
            (n[4] >> 8) & 255,
            255 & n[4],
          ];
        };
      },
      9678: (t, e, r) => {
        var i = r(3697);
        t.exports = function (t, e, r) {
          var n = function (t, n, o, a) {
            var s = (o && a) || 0;
            if (
              ("string" == typeof t &&
                (t = (function (t) {
                  t = unescape(encodeURIComponent(t));
                  for (var e = new Array(t.length), r = 0; r < t.length; r++)
                    e[r] = t.charCodeAt(r);
                  return e;
                })(t)),
              "string" == typeof n &&
                (n = (function (t) {
                  var e = [];
                  return (
                    t.replace(/[a-fA-F0-9]{2}/g, function (t) {
                      e.push(parseInt(t, 16));
                    }),
                    e
                  );
                })(n)),
              !Array.isArray(t))
            )
              throw TypeError("value must be an array of bytes");
            if (!Array.isArray(n) || 16 !== n.length)
              throw TypeError(
                "namespace must be uuid string or an Array of 16 byte values"
              );
            var c = r(n.concat(t));
            if (((c[6] = (15 & c[6]) | e), (c[8] = (63 & c[8]) | 128), o))
              for (var l = 0; l < 16; ++l) o[s + l] = c[l];
            return o || i(c);
          };
          try {
            n.name = t;
          } catch (t) {}
          return (
            (n.DNS = "6ba7b810-9dad-11d1-80b4-00c04fd430c8"),
            (n.URL = "6ba7b811-9dad-11d1-80b4-00c04fd430c8"),
            n
          );
        };
      },
      1212: (t, e, r) => {
        var i = r(7240),
          n = r(3697);
        t.exports = function (t, e, r) {
          var o = (e && r) || 0;
          "string" == typeof t &&
            ((e = "binary" === t ? new Array(16) : null), (t = null));
          var a = (t = t || {}).random || (t.rng || i)();
          if (((a[6] = (15 & a[6]) | 64), (a[8] = (63 & a[8]) | 128), e))
            for (var s = 0; s < 16; ++s) e[o + s] = a[s];
          return e || n(a);
        };
      },
      9315: (t, e, r) => {
        var i = r(9678),
          n = r(7918);
        t.exports = i("v5", 80, n);
      },
      820: (t, e, r) => {
        var i = r(6496);
        i && i.__esModule && (i = i.default),
          (t.exports = "string" == typeof i ? i : i.toString());
      },
      1752: (t, e, r) => {
        var i = r(6052);
        i && i.__esModule && (i = i.default),
          (t.exports = "string" == typeof i ? i : i.toString());
      },
      2482: (t, e, r) => {
        var i = r(1582);
        i && i.__esModule && (i = i.default),
          (t.exports = "string" == typeof i ? i : i.toString());
      },
      7108: (t, e, r) => {
        var i = r(8960);
        i && i.__esModule && (i = i.default),
          (t.exports = "string" == typeof i ? i : i.toString());
      },
      2390: (t, e, r) => {
        var i = r(7298);
        i && i.__esModule && (i = i.default),
          (t.exports = "string" == typeof i ? i : i.toString());
      },
      9783: (t, e, r) => {
        var i = r(5264);
        i && i.__esModule && (i = i.default),
          (t.exports = "string" == typeof i ? i : i.toString());
      },
      4590: (t, e, r) => {
        var i = r(5322);
        i && i.__esModule && (i = i.default),
          (t.exports = "string" == typeof i ? i : i.toString());
      },
      5964: (t, e, r) => {
        var i = r(7080);
        i && i.__esModule && (i = i.default),
          (t.exports = "string" == typeof i ? i : i.toString());
      },
      9028: (t, e, r) => {
        var i = r(3392);
        i && i.__esModule && (i = i.default),
          (t.exports = "string" == typeof i ? i : i.toString());
      },
      8541: (t, e, r) => {
        var i = r(2990).default;
        function n() {
          "use strict";
          /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ (t.exports =
            n =
              function () {
                return r;
              }),
            (t.exports.__esModule = !0),
            (t.exports.default = t.exports);
          var e,
            r = {},
            o = Object.prototype,
            a = o.hasOwnProperty,
            s =
              Object.defineProperty ||
              function (t, e, r) {
                t[e] = r.value;
              },
            c = "function" == typeof Symbol ? Symbol : {},
            l = c.iterator || "@@iterator",
            u = c.asyncIterator || "@@asyncIterator",
            h = c.toStringTag || "@@toStringTag";
          function d(t, e, r) {
            return (
              Object.defineProperty(t, e, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0,
              }),
              t[e]
            );
          }
          try {
            d({}, "");
          } catch (e) {
            d = function (t, e, r) {
              return (t[e] = r);
            };
          }
          function p(t, e, r, i) {
            var n = e && e.prototype instanceof y ? e : y,
              o = Object.create(n.prototype),
              a = new V(i || []);
            return s(o, "_invoke", { value: O(t, r, a) }), o;
          }
          function g(t, e, r) {
            try {
              return { type: "normal", arg: t.call(e, r) };
            } catch (t) {
              return { type: "throw", arg: t };
            }
          }
          r.wrap = p;
          var f = "suspendedStart",
            v = "suspendedYield",
            m = "executing",
            k = "completed",
            b = {};
          function y() {}
          function w() {}
          function _() {}
          var A = {};
          d(A, l, function () {
            return this;
          });
          var C = Object.getPrototypeOf,
            E = C && C(C(L([])));
          E && E !== o && a.call(E, l) && (A = E);
          var x = (_.prototype = y.prototype = Object.create(A));
          function S(t) {
            ["next", "throw", "return"].forEach(function (e) {
              d(t, e, function (t) {
                return this._invoke(e, t);
              });
            });
          }
          function I(t, e) {
            function r(n, o, s, c) {
              var l = g(t[n], t, o);
              if ("throw" !== l.type) {
                var u = l.arg,
                  h = u.value;
                return h && "object" == i(h) && a.call(h, "__await")
                  ? e.resolve(h.__await).then(
                      function (t) {
                        r("next", t, s, c);
                      },
                      function (t) {
                        r("throw", t, s, c);
                      }
                    )
                  : e.resolve(h).then(
                      function (t) {
                        (u.value = t), s(u);
                      },
                      function (t) {
                        return r("throw", t, s, c);
                      }
                    );
              }
              c(l.arg);
            }
            var n;
            s(this, "_invoke", {
              value: function (t, i) {
                function o() {
                  return new e(function (e, n) {
                    r(t, i, e, n);
                  });
                }
                return (n = n ? n.then(o, o) : o());
              },
            });
          }
          function O(t, r, i) {
            var n = f;
            return function (o, a) {
              if (n === m) throw Error("Generator is already running");
              if (n === k) {
                if ("throw" === o) throw a;
                return { value: e, done: !0 };
              }
              for (i.method = o, i.arg = a; ; ) {
                var s = i.delegate;
                if (s) {
                  var c = R(s, i);
                  if (c) {
                    if (c === b) continue;
                    return c;
                  }
                }
                if ("next" === i.method) i.sent = i._sent = i.arg;
                else if ("throw" === i.method) {
                  if (n === f) throw ((n = k), i.arg);
                  i.dispatchException(i.arg);
                } else "return" === i.method && i.abrupt("return", i.arg);
                n = m;
                var l = g(t, r, i);
                if ("normal" === l.type) {
                  if (((n = i.done ? k : v), l.arg === b)) continue;
                  return { value: l.arg, done: i.done };
                }
                "throw" === l.type &&
                  ((n = k), (i.method = "throw"), (i.arg = l.arg));
              }
            };
          }
          function R(t, r) {
            var i = r.method,
              n = t.iterator[i];
            if (n === e)
              return (
                (r.delegate = null),
                ("throw" === i &&
                  t.iterator.return &&
                  ((r.method = "return"),
                  (r.arg = e),
                  R(t, r),
                  "throw" === r.method)) ||
                  ("return" !== i &&
                    ((r.method = "throw"),
                    (r.arg = new TypeError(
                      "The iterator does not provide a '" + i + "' method"
                    )))),
                b
              );
            var o = g(n, t.iterator, r.arg);
            if ("throw" === o.type)
              return (
                (r.method = "throw"), (r.arg = o.arg), (r.delegate = null), b
              );
            var a = o.arg;
            return a
              ? a.done
                ? ((r[t.resultName] = a.value),
                  (r.next = t.nextLoc),
                  "return" !== r.method && ((r.method = "next"), (r.arg = e)),
                  (r.delegate = null),
                  b)
                : a
              : ((r.method = "throw"),
                (r.arg = new TypeError("iterator result is not an object")),
                (r.delegate = null),
                b);
          }
          function D(t) {
            var e = { tryLoc: t[0] };
            1 in t && (e.catchLoc = t[1]),
              2 in t && ((e.finallyLoc = t[2]), (e.afterLoc = t[3])),
              this.tryEntries.push(e);
          }
          function T(t) {
            var e = t.completion || {};
            (e.type = "normal"), delete e.arg, (t.completion = e);
          }
          function V(t) {
            (this.tryEntries = [{ tryLoc: "root" }]),
              t.forEach(D, this),
              this.reset(!0);
          }
          function L(t) {
            if (t || "" === t) {
              var r = t[l];
              if (r) return r.call(t);
              if ("function" == typeof t.next) return t;
              if (!isNaN(t.length)) {
                var n = -1,
                  o = function r() {
                    for (; ++n < t.length; )
                      if (a.call(t, n))
                        return (r.value = t[n]), (r.done = !1), r;
                    return (r.value = e), (r.done = !0), r;
                  };
                return (o.next = o);
              }
            }
            throw new TypeError(i(t) + " is not iterable");
          }
          return (
            (w.prototype = _),
            s(x, "constructor", { value: _, configurable: !0 }),
            s(_, "constructor", { value: w, configurable: !0 }),
            (w.displayName = d(_, h, "GeneratorFunction")),
            (r.isGeneratorFunction = function (t) {
              var e = "function" == typeof t && t.constructor;
              return (
                !!e &&
                (e === w || "GeneratorFunction" === (e.displayName || e.name))
              );
            }),
            (r.mark = function (t) {
              return (
                Object.setPrototypeOf
                  ? Object.setPrototypeOf(t, _)
                  : ((t.__proto__ = _), d(t, h, "GeneratorFunction")),
                (t.prototype = Object.create(x)),
                t
              );
            }),
            (r.awrap = function (t) {
              return { __await: t };
            }),
            S(I.prototype),
            d(I.prototype, u, function () {
              return this;
            }),
            (r.AsyncIterator = I),
            (r.async = function (t, e, i, n, o) {
              void 0 === o && (o = Promise);
              var a = new I(p(t, e, i, n), o);
              return r.isGeneratorFunction(e)
                ? a
                : a.next().then(function (t) {
                    return t.done ? t.value : a.next();
                  });
            }),
            S(x),
            d(x, h, "Generator"),
            d(x, l, function () {
              return this;
            }),
            d(x, "toString", function () {
              return "[object Generator]";
            }),
            (r.keys = function (t) {
              var e = Object(t),
                r = [];
              for (var i in e) r.push(i);
              return (
                r.reverse(),
                function t() {
                  for (; r.length; ) {
                    var i = r.pop();
                    if (i in e) return (t.value = i), (t.done = !1), t;
                  }
                  return (t.done = !0), t;
                }
              );
            }),
            (r.values = L),
            (V.prototype = {
              constructor: V,
              reset: function (t) {
                if (
                  ((this.prev = 0),
                  (this.next = 0),
                  (this.sent = this._sent = e),
                  (this.done = !1),
                  (this.delegate = null),
                  (this.method = "next"),
                  (this.arg = e),
                  this.tryEntries.forEach(T),
                  !t)
                )
                  for (var r in this)
                    "t" === r.charAt(0) &&
                      a.call(this, r) &&
                      !isNaN(+r.slice(1)) &&
                      (this[r] = e);
              },
              stop: function () {
                this.done = !0;
                var t = this.tryEntries[0].completion;
                if ("throw" === t.type) throw t.arg;
                return this.rval;
              },
              dispatchException: function (t) {
                if (this.done) throw t;
                var r = this;
                function i(i, n) {
                  return (
                    (s.type = "throw"),
                    (s.arg = t),
                    (r.next = i),
                    n && ((r.method = "next"), (r.arg = e)),
                    !!n
                  );
                }
                for (var n = this.tryEntries.length - 1; n >= 0; --n) {
                  var o = this.tryEntries[n],
                    s = o.completion;
                  if ("root" === o.tryLoc) return i("end");
                  if (o.tryLoc <= this.prev) {
                    var c = a.call(o, "catchLoc"),
                      l = a.call(o, "finallyLoc");
                    if (c && l) {
                      if (this.prev < o.catchLoc) return i(o.catchLoc, !0);
                      if (this.prev < o.finallyLoc) return i(o.finallyLoc);
                    } else if (c) {
                      if (this.prev < o.catchLoc) return i(o.catchLoc, !0);
                    } else {
                      if (!l)
                        throw Error("try statement without catch or finally");
                      if (this.prev < o.finallyLoc) return i(o.finallyLoc);
                    }
                  }
                }
              },
              abrupt: function (t, e) {
                for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                  var i = this.tryEntries[r];
                  if (
                    i.tryLoc <= this.prev &&
                    a.call(i, "finallyLoc") &&
                    this.prev < i.finallyLoc
                  ) {
                    var n = i;
                    break;
                  }
                }
                n &&
                  ("break" === t || "continue" === t) &&
                  n.tryLoc <= e &&
                  e <= n.finallyLoc &&
                  (n = null);
                var o = n ? n.completion : {};
                return (
                  (o.type = t),
                  (o.arg = e),
                  n
                    ? ((this.method = "next"), (this.next = n.finallyLoc), b)
                    : this.complete(o)
                );
              },
              complete: function (t, e) {
                if ("throw" === t.type) throw t.arg;
                return (
                  "break" === t.type || "continue" === t.type
                    ? (this.next = t.arg)
                    : "return" === t.type
                    ? ((this.rval = this.arg = t.arg),
                      (this.method = "return"),
                      (this.next = "end"))
                    : "normal" === t.type && e && (this.next = e),
                  b
                );
              },
              finish: function (t) {
                for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                  var r = this.tryEntries[e];
                  if (r.finallyLoc === t)
                    return this.complete(r.completion, r.afterLoc), T(r), b;
                }
              },
              catch: function (t) {
                for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                  var r = this.tryEntries[e];
                  if (r.tryLoc === t) {
                    var i = r.completion;
                    if ("throw" === i.type) {
                      var n = i.arg;
                      T(r);
                    }
                    return n;
                  }
                }
                throw Error("illegal catch attempt");
              },
              delegateYield: function (t, r, i) {
                return (
                  (this.delegate = {
                    iterator: L(t),
                    resultName: r,
                    nextLoc: i,
                  }),
                  "next" === this.method && (this.arg = e),
                  b
                );
              },
            }),
            r
          );
        }
        (t.exports = n),
          (t.exports.__esModule = !0),
          (t.exports.default = t.exports);
      },
      2990: (t) => {
        function e(r) {
          return (
            (t.exports = e =
              "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (t) {
                    return typeof t;
                  }
                : function (t) {
                    return t &&
                      "function" == typeof Symbol &&
                      t.constructor === Symbol &&
                      t !== Symbol.prototype
                      ? "symbol"
                      : typeof t;
                  }),
            (t.exports.__esModule = !0),
            (t.exports.default = t.exports),
            e(r)
          );
        }
        (t.exports = e),
          (t.exports.__esModule = !0),
          (t.exports.default = t.exports);
      },
      232: (t, e, r) => {
        var i = r(8541)();
        t.exports = i;
        try {
          regeneratorRuntime = i;
        } catch (t) {
          "object" == typeof globalThis
            ? (globalThis.regeneratorRuntime = i)
            : Function("r", "regeneratorRuntime = r")(i);
        }
      },
      8407: (t, e, r) => {
        "use strict";
        function i(t, e, r, i, n, o, a) {
          try {
            var s = t[o](a),
              c = s.value;
          } catch (t) {
            return void r(t);
          }
          s.done ? e(c) : Promise.resolve(c).then(i, n);
        }
        function n(t) {
          return function () {
            var e = this,
              r = arguments;
            return new Promise(function (n, o) {
              var a = t.apply(e, r);
              function s(t) {
                i(a, n, o, s, c, "next", t);
              }
              function c(t) {
                i(a, n, o, s, c, "throw", t);
              }
              s(void 0);
            });
          };
        }
        r.d(e, { A: () => n });
      },
      8175: (t, e, r) => {
        "use strict";
        r.d(e, { A: () => n });
        var i = r(5813);
        function n(t, e, r) {
          return (
            (e = (0, i.A)(e)) in t
              ? Object.defineProperty(t, e, {
                  value: r,
                  enumerable: !0,
                  configurable: !0,
                  writable: !0,
                })
              : (t[e] = r),
            t
          );
        }
      },
      5813: (t, e, r) => {
        "use strict";
        function i(t) {
          return (
            (i =
              "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (t) {
                    return typeof t;
                  }
                : function (t) {
                    return t &&
                      "function" == typeof Symbol &&
                      t.constructor === Symbol &&
                      t !== Symbol.prototype
                      ? "symbol"
                      : typeof t;
                  }),
            i(t)
          );
        }
        function n(t) {
          var e = (function (t, e) {
            if ("object" != i(t) || !t) return t;
            var r = t[Symbol.toPrimitive];
            if (void 0 !== r) {
              var n = r.call(t, e || "default");
              if ("object" != i(n)) return n;
              throw new TypeError(
                "@@toPrimitive must return a primitive value."
              );
            }
            return ("string" === e ? String : Number)(t);
          })(t, "string");
          return "symbol" == i(e) ? e : e + "";
        }
        r.d(e, { A: () => n });
      },
    },
    __webpack_module_cache__ = {},
    inProgress,
    dataWebpackPrefix;
  function __webpack_require__(t) {
    var e = __webpack_module_cache__[t];
    if (void 0 !== e) return e.exports;
    var r = (__webpack_module_cache__[t] = { id: t, exports: {} });
    return __webpack_modules__[t](r, r.exports, __webpack_require__), r.exports;
  }
  (__webpack_require__.m = __webpack_modules__),
    (__webpack_require__.n = (t) => {
      var e = t && t.__esModule ? () => t.default : () => t;
      return __webpack_require__.d(e, { a: e }), e;
    }),
    (__webpack_require__.d = (t, e) => {
      for (var r in e)
        __webpack_require__.o(e, r) &&
          !__webpack_require__.o(t, r) &&
          Object.defineProperty(t, r, { enumerable: !0, get: e[r] });
    }),
    (__webpack_require__.f = {}),
    (__webpack_require__.e = (t) =>
      Promise.all(
        Object.keys(__webpack_require__.f).reduce(
          (e, r) => (__webpack_require__.f[r](t, e), e),
          []
        )
      )),
    (__webpack_require__.u = (t) =>
      "versions/" +
      { 653: "overlap-monitor", 995: "flourish-color-display" }[t] +
      "-10.9.0-kat-7484-test.min.js"),
    (__webpack_require__.g = (function () {
      if ("object" == typeof globalThis) return globalThis;
      try {
        return this || new Function("return this")();
      } catch (t) {
        if ("object" == typeof window) return window;
      }
    })()),
    (__webpack_require__.o = (t, e) =>
      Object.prototype.hasOwnProperty.call(t, e)),
    (inProgress = {}),
    (dataWebpackPrefix = "kargo_ad_tag_10.9.0-kat-7484-test:"),
    (__webpack_require__.l = (t, e, r, i) => {
      if (inProgress[t]) inProgress[t].push(e);
      else {
        var n, o;
        if (void 0 !== r)
          for (
            var a = document.getElementsByTagName("script"), s = 0;
            s < a.length;
            s++
          ) {
            var c = a[s];
            if (
              c.getAttribute("src") == t ||
              c.getAttribute("data-webpack") == dataWebpackPrefix + r
            ) {
              n = c;
              break;
            }
          }
        n ||
          ((o = !0),
          ((n = document.createElement("script")).charset = "utf-8"),
          (n.timeout = 120),
          __webpack_require__.nc &&
            n.setAttribute("nonce", __webpack_require__.nc),
          n.setAttribute("data-webpack", dataWebpackPrefix + r),
          (n.src = t)),
          (inProgress[t] = [e]);
        var l = (e, r) => {
            (n.onerror = n.onload = null), clearTimeout(u);
            var i = inProgress[t];
            if (
              (delete inProgress[t],
              n.parentNode && n.parentNode.removeChild(n),
              i && i.forEach((t) => t(r)),
              e)
            )
              return e(r);
          },
          u = setTimeout(
            l.bind(null, void 0, { type: "timeout", target: n }),
            12e4
          );
        (n.onerror = l.bind(null, n.onerror)),
          (n.onload = l.bind(null, n.onload)),
          o && document.head.appendChild(n);
      }
    }),
    (__webpack_require__.r = (t) => {
      "undefined" != typeof Symbol &&
        Symbol.toStringTag &&
        Object.defineProperty(t, Symbol.toStringTag, { value: "Module" }),
        Object.defineProperty(t, "__esModule", { value: !0 });
    }),
    (__webpack_require__.p = "https://storage.cloud.kargo.com/ad/network/tag/"),
    (() => {
      var t = { 376: 0 };
      __webpack_require__.f.j = (e, r) => {
        var i = __webpack_require__.o(t, e) ? t[e] : void 0;
        if (0 !== i)
          if (i) r.push(i[2]);
          else {
            var n = new Promise((r, n) => (i = t[e] = [r, n]));
            r.push((i[2] = n));
            var o = __webpack_require__.p + __webpack_require__.u(e),
              a = new Error();
            __webpack_require__.l(
              o,
              (r) => {
                if (
                  __webpack_require__.o(t, e) &&
                  (0 !== (i = t[e]) && (t[e] = void 0), i)
                ) {
                  var n = r && ("load" === r.type ? "missing" : r.type),
                    o = r && r.target && r.target.src;
                  (a.message =
                    "Loading chunk " + e + " failed.\n(" + n + ": " + o + ")"),
                    (a.name = "ChunkLoadError"),
                    (a.type = n),
                    (a.request = o),
                    i[1](a);
                }
              },
              "chunk-" + e,
              e
            );
          }
      };
      var e = (e, r) => {
          var i,
            n,
            [o, a, s] = r,
            c = 0;
          if (o.some((e) => 0 !== t[e])) {
            for (i in a)
              __webpack_require__.o(a, i) && (__webpack_require__.m[i] = a[i]);
            if (s) s(__webpack_require__);
          }
          for (e && e(r); c < o.length; c++)
            (n = o[c]),
              __webpack_require__.o(t, n) && t[n] && t[n][0](),
              (t[n] = 0);
        },
        r = (self.webpackChunk_kargo_ad_tag_10_9_0_kat_7484_test =
          self.webpackChunk_kargo_ad_tag_10_9_0_kat_7484_test || []);
      r.forEach(e.bind(null, 0)), (r.push = e.bind(null, r.push.bind(r)));
    })();
  var __webpack_exports__ = {};
  (() => {
    "use strict";
    var t = {};
    __webpack_require__.r(t),
      __webpack_require__.d(t, {
        ABAAdhesionDisplay: () => Qs,
        ABADisplay: () => ec,
        ABAVideo: () => rc,
        AdaptiveOutstream: () => uc,
        Anchor: () => hc,
        AppInterstitial: () => dc,
        BannerVideo: () => Ps,
        Billboard: () => gc,
        Bitly: () => vc,
        BottomBanner: () => mc,
        Breakaway: () => kc,
        Breakout: () => bc,
        DesktopBreakout: () => wc,
        DesktopHover: () => Ac,
        DesktopRunway: () => Cc,
        DesktopSkins: () => Ic,
        FabrikOutstream: () => lc,
        FishTank: () => Il,
        HalfPage: () => Oc,
        HighRise: () => Rc,
        KeyArt: () => Dc,
        LargeLeaderboard: () => Tc,
        Leaderboard: () => Ec,
        Lighthouse: () => Jc,
        MiddleBanner: () => Xc,
        NonVastOutstreamVideo: () => Qc,
        NonVastRunwayVideo: () => fl,
        OutstreamVideo: () => vl,
        Runway: () => gl,
        Sidekick: () => bl,
        SocialCanvas: () => yl,
        SwipeUp: () => El,
        TopBanner: () => xl,
        Ultrawide: () => Sl,
        Uptick: () => Ll,
        Venti: () => Pl,
        VideoAnchor: () => Nl,
        VideoHalo: () => Fl,
        VideoRunway: () => Bl,
        VideoVenti: () => Ul,
        WideSkyscraper: () => Hl,
        Wrapper: () => Kl,
      });
    var e = __webpack_require__(8188),
      r = __webpack_require__.n(e),
      i = __webpack_require__(3746),
      n = __webpack_require__(2840),
      o = __webpack_require__(4845),
      a = __webpack_require__(2709),
      s = __webpack_require__.n(a),
      c = __webpack_require__(7833),
      l = __webpack_require__(9486),
      u = new l.wm("ModuleLoader"),
      h = (function () {
        function t(t, e) {
          (this.win = t),
            (this.moduleFolder = e),
            (this.moduleUrlRoot = ""
              .concat("https://storage.cloud.kargo.com", "/")
              .concat("ad/network/tag/bundle")),
            (this.win.Kargo = this.win.Kargo || {});
          var r = (0, o.P3)(this.win.location.href, "krg_module_url_root");
          r && (this.moduleUrlRoot = r);
        }
        return (
          (t.prototype.filterRequiredModules = function (t) {
            var e = "string" == typeof t ? [t] : t,
              r = this.win.Kargo;
            return e.filter(function (t) {
              return !(t in r);
            });
          }),
          (t.prototype.getModuleFolder = function () {
            return "function" == typeof this.moduleFolder
              ? this.moduleFolder()
              : this.moduleFolder;
          }),
          (t.prototype.buildModulePaths = function (t, e) {
            var r = this;
            return t.map(function (t) {
              return ""
                .concat(r.moduleUrlRoot, "/")
                .concat(r.getModuleFolder(), "/")
                .concat(t, "/")
                .concat(e, ".js");
            });
          }),
          (t.prototype.getModule = function (t, e, r) {
            var i = this;
            void 0 === r && (r = 2e3);
            var n = "string" == typeof t ? [t] : t,
              o = this.filterRequiredModules(n).map(function (t) {
                return s()(t);
              }),
              a = this.buildModulePaths(o, e);
            return Promise.all(
              a.map(function (t) {
                return (0, c.$_)(t, i.win, { timeout: r, onTimeoutFail: !0 });
              })
            ).then(function () {
              for (
                var e = i.win.Kargo, r = [], o = 0, a = n;
                o < a.length;
                o++
              ) {
                var s = a[o],
                  c = e[s];
                if (!c) return Promise.reject(u.errLoad(s));
                r.push(c);
              }
              return Promise.resolve("string" == typeof t ? r[0] : r);
            });
          }),
          t
        );
      })(),
      d = __webpack_require__(3629);
    function p(t, e) {
      return t.className.split(" ").indexOf(e) > -1;
    }
    function g(t, e) {
      p(t, e) || (t.className += " ".concat(e));
    }
    function f(t, e, r) {
      switch (e) {
        case "append":
          r.appendChild(t);
          break;
        case "prepend":
          r.firstChild ? r.insertBefore(t, r.firstChild) : r.appendChild(t);
          break;
        case "before":
          r.parentNode ? r.parentNode.insertBefore(t, r) : r.insertBefore(t, r);
          break;
        default:
          r.parentNode
            ? r.nextSibling
              ? r.parentNode.insertBefore(t, r.nextSibling)
              : r.parentNode.appendChild(t)
            : r.insertBefore(t, r);
      }
    }
    function v(t, e) {
      var r = !1;
      if (t.ownerDocument) {
        var i = null;
        if (
          ("head" === e
            ? (i = t.ownerDocument.head)
            : "body" === e && (i = t.ownerDocument.body),
          i)
        )
          for (var n = t.parentElement; n; ) {
            if (n === i) {
              r = !0;
              break;
            }
            n = n.parentElement;
          }
      }
      return r;
    }
    function m(t) {
      return v(t, "body");
    }
    function k(t) {
      return { top: 0, left: 0, bottom: t.innerHeight, right: t.innerWidth };
    }
    function b(t, e, r) {
      var i = e.getComputedStyle(t),
        n = t.getBoundingClientRect(),
        o = k(e),
        a = !0;
      return (
        ("0" !== i.opacity &&
          "none" !== i.display &&
          "hidden" !== i.visibility &&
          m(t) &&
          0 !== n.height &&
          0 !== n.width &&
          (function (t, e, r) {
            void 0 === r && (r = {});
            var i = r.clientRect || t.getBoundingClientRect(),
              n = r.viewport || k(e);
            return !(
              i.left > n.right ||
              i.right < n.left ||
              i.top > n.bottom ||
              i.bottom < n.top
            );
          })(t, e, { clientRect: n, viewport: o }) &&
          (void 0 === r ||
            (function (t, e, r, i) {
              void 0 === i && (i = {});
              var n = i.clientRect || t.getBoundingClientRect(),
                o = i.viewport || k(e),
                a = t.offsetWidth * r,
                s = t.offsetHeight * r,
                c = o.right - n.left,
                l = n.right - o.left,
                u = o.bottom - n.top,
                h = n.bottom - o.top,
                d = !0;
              return (c < a || l < a || u < s || h < s) && (d = !1), d;
            })(t, e, r, { clientRect: n, viewport: o }))) ||
          (a = !1),
        a
      );
    }
    function y(t, e) {
      var r = null,
        i = new RegExp(
          "^\x3c!--(?:\\r|\\n|\\s)*?[\"']".concat(
            (0, d.AF)(e),
            "[\"']:((?:\\r|\\n|.)*?)--\x3e$"
          )
        );
      if (t.indexOf(e) > 0) {
        var n = t.match(/<!--(?:\r|\n|.)*?-->/g);
        if (n)
          for (var o = 0; o < n.length; o += 1) {
            var a = n[o].match(i);
            if (a) {
              var s = (a[1] || "").trim();
              "" !== s &&
                ((s = JSON.parse(s)),
                (r = null === r || "string" == typeof s ? s : (0, d.h1)(r, s)));
            }
          }
      }
      return r;
    }
    function w(t, e) {
      var r = t.className.split(" "),
        i = r.indexOf(e);
      i > -1 && (r.splice(i, 1), (t.className = r.join(" ")));
    }
    function _(t) {
      t && t.parentNode && t.parentNode.removeChild(t);
    }
    function A(t, e) {
      var r = t;
      if (r.indexOf(e) > -1) {
        var i = new RegExp(
            "\x3c!--(?:\\r|\\n|\\s)*?[\"']".concat(
              (0, d.AF)(e),
              "[\"']:(?:\\r|\\n|.)*?--\x3e"
            ),
            "g"
          ),
          n = r.match(i);
        if (n) for (var o = 0; o < n.length; o += 1) r = r.replace(n[o], "");
      }
      return r;
    }
    __webpack_require__(9315);
    var C = __webpack_require__(1212);
    var E = (function () {
      function t() {
        (this.creatives = void 0), (this.creatives = {});
      }
      var e = t.prototype;
      return (
        (e.getActiveCreatives = function () {
          var t = {};
          for (var e in this.creatives)
            this.creatives[e].isDestroyed() || (t[e] = this.creatives[e]);
          return t;
        }),
        (e.add = function (t) {
          for (
            var e = t.getId() || C(), r = e, i = 1;
            i <= 10 && this.creatives[r];
            i++
          )
            r = e + "-" + i;
          this.creatives[r] || (this.creatives[r] = t);
        }),
        (e.get = function (t) {
          if (!t) return null;
          var e = this.getActiveCreatives();
          return (
            Object.values(e).find(function (e) {
              return e.getId() === t;
            }) || null
          );
        }),
        (e.getAll = function () {
          var t = [],
            e = this.getActiveCreatives();
          for (var r in e) {
            var i = e[r];
            t.push(i);
          }
          return t;
        }),
        (e.getByLocalId = function (t) {
          var e = this.getActiveCreatives();
          for (var r in e) {
            var i = e[r];
            if (i.getLocalId() === t) return i;
          }
          return null;
        }),
        (e.getCreativesOfType = function (t) {
          var e = [],
            r = this.getActiveCreatives();
          for (var i in r) {
            var n = r[i];
            n.getType() === t && e.push(n);
          }
          return e;
        }),
        (e.getCreativesOfFormat = function (t) {
          var e = [],
            r = this.getActiveCreatives();
          for (var i in r) {
            var n = r[i];
            n.getFormat() === t && e.push(n);
          }
          return e;
        }),
        (e.getCreativesOfSlot = function (t) {
          var e = [],
            r = this.getActiveCreatives();
          for (var i in r) {
            var n = r[i];
            n.getSlotId() === t && e.push(n);
          }
          return e;
        }),
        (e.getAnalytics = function () {
          var t = [];
          for (var e in this.creatives) {
            var r = this.creatives[e].getAnalytics();
            if (r && r.localId) {
              var i = r.localId;
              delete r.localId, (t[i] = r);
            }
          }
          return t;
        }),
        t
      );
    })();
    const x = E;
    function S(t) {
      return t ? t.split("#")[0].split("?")[0] : "";
    }
    function I(t) {
      var e, r;
      return null != (e = null == (r = t.Kargo) ? void 0 : r.Config) ? e : null;
    }
    function O(t, e) {
      return (
        t.versions || (t.versions = {}),
        t.versions[e] || (t.versions[e] = {}),
        t.versions[e]
      );
    }
    var R = {
      isDebugMode: function (t) {
        var e = (0, o.pO)(t);
        return !!(0, o.P3)(e, "krg_debug");
      },
    };
    function D(t, e) {
      var r = (0, i.sk)(t),
        o = (0, i.Fk)(t, r),
        a = O(o, e);
      if (!a.CreativeRegister) {
        new n.V(r).setLabel(["CREATIVE REGISTER", e]);
        var s = new x();
        a.CreativeRegister = {
          add: function (t) {
            return s.add(t);
          },
          get: function (t) {
            return s.get(t);
          },
          getAll: function () {
            return s.getAll();
          },
          getByLocalId: function (t) {
            return s.getByLocalId(t);
          },
          getCreativesOfType: function (t) {
            return s.getCreativesOfType(t);
          },
          getCreativesOfFormat: function (t) {
            return s.getCreativesOfFormat(t);
          },
          getCreativesOfSlot: function (t) {
            return s.getCreativesOfSlot(t);
          },
          report: function () {
            for (var t, e, i = s.getAnalytics(), n = [], o = 1; i[o]; ) {
              var a = null;
              i[o].timestamps.displayed &&
                (a = i[o].timestamps.displayed - i[o].timestamps.start + " ms");
              var c = null;
              i[o].timestamps.firstVisible &&
                (c =
                  i[o].timestamps.firstVisible - i[o].timestamps.start + " ms");
              var l = null;
              i[o].timestamps.viewable &&
                (l = i[o].timestamps.viewable - i[o].timestamps.start + " ms");
              var u = null;
              i[o].timestamps.destroyed &&
                (u = i[o].timestamps.destroyed - i[o].timestamps.start + " ms"),
                n.push({
                  ID: i[o].id,
                  Type: i[o].type,
                  Format: i[o].format,
                  Execution: i[o].execution,
                  "Kargo Creative": i[o].kargoCreativeId,
                  "Started at":
                    ((t = i[o].timestamps.start),
                    (e = void 0),
                    (e = new Date(t)),
                    (0, d.PX)(e.getHours(), 2, "0") +
                      ":" +
                      (0, d.PX)(e.getMinutes(), 2, "0") +
                      ":" +
                      (0, d.PX)(e.getSeconds(), 2, "0") +
                      "." +
                      (0, d.PX)(e.getMilliseconds(), 3, "0")),
                  "Displayed at": a,
                  "First Visible at": c,
                  "Viewable at": l,
                  "Destroyed at": u,
                }),
                (o += 1);
            }
            R.isDebugMode(r) &&
              (r.console.log("Creatives"), r.console.table(n));
          },
        };
      }
      o.CreativeRegister || (o.CreativeRegister = a.CreativeRegister),
        (function (t) {
          t.report ||
            (t.report = function () {
              var e = t.versions || {};
              Object.keys(e).forEach(function (t) {
                var r = e[t],
                  i = r.AdTag,
                  n = r.CreativeRegister;
                i && "function" == typeof i.report && i.report(),
                  n && "function" == typeof n.report && n.report();
              });
            });
        })(o);
    }
    var T = __webpack_require__(8175),
      V = __webpack_require__(8407),
      L = __webpack_require__(232),
      P = __webpack_require__.n(L),
      M = __webpack_require__(7911),
      N = "CREATIVE",
      F = "IDENT",
      B = "KRAKEN",
      U = "KIT",
      H = "HEPHAESTUS",
      j = "IFRAME",
      z = "SAFEFRAME",
      W = "VAST",
      K = "CONFIG:AD_REQUEST_TIMEOUT",
      q = "CONFIG:JS_UNSAFE_EVAL",
      G = "CONFIG:FORMAT_JS_ERROR",
      Y = "CONFIG:GLOBAL_CONFIG_TIMEOUT",
      J = "CONFIG:GLOBAL_CHECK_ERROR",
      Z = "CONFIG:GLOBAL_JS_ERROR",
      $ = "CONFIG:SLOT_CHECK_ERROR",
      X = "CONFIG:SLOT_FAIL_CALLBACK_ERROR",
      Q = "CREATIVE:PREDISPLAY_ABORT",
      tt = "CREATIVE:FLOURISH_INIT_ERROR",
      et = "CREATIVE:SAFEFRAME_SLOT_GEOM_TIMEOUT",
      rt = "CREATIVE:CELTRA_SIZES_UNREADABLE",
      it = "CREATIVE:SAFEFRAME_SIZE_TIMEOUT",
      nt = "CREATIVE:SAFEFRAME_NO_ROOM_TO_EXPAND",
      ot = "CREATIVE:SAFEFRAME_MRAID_NOT_USED",
      at = "CREATIVE:SAFEFRAME_EXPAND_REJECTED",
      st = "CREATIVE:SAFEFRAME_COLLAPSE_IGNORED",
      ct = "CREATIVE:SAFEFRAME_IAS_NOT_IN_CONTAINER",
      lt = "CREATIVE:SAFEFRAME_COLLAPSE_FAILED",
      ut = "CREATIVE:SAFEFRAME_UNSUPPORTED_CREATIVE",
      ht = "CREATIVE:SAFEFRAME_EXPAND_NOT_CONFIRMED",
      dt = "CREATIVE:IFRAME_CORS",
      pt = "CREATIVE:HEIGHT_EXCEEDS_MAX",
      gt = "CREATIVE:AD_FORMAT_POSITION_NOT_FOUND",
      ft = "CREATIVE:AD_CONTAINER_REMOVED",
      vt = "CREATIVE:SLOT_REFRESH_CONFLICT",
      mt = "CREATIVE:KARGO_IN_OPEN_AUCTION",
      kt = "CREATIVE:NO_MP4_IN_VAST",
      bt = "CREATIVE:HEAVY_AD_INTERVENTION",
      yt = "CREATIVE:ACTIVEVIEW_INVALID_URL",
      wt = "CREATIVE:CLICK_NO_NAVIGATE",
      _t = "CREATIVE:CLICK_NO_TARGET",
      At = "CREATIVE:AUTOPLAY_NOT_SUPPORTED",
      Ct = "CREATIVE:INTERNAL",
      Et = "CREATIVE:NULL_REF",
      xt = "CREATIVE:INTERSECTION_OBSERVER",
      St = "CREATIVE:TEMPLATE_FETCH_FAILED",
      It = "CREATIVE:XHR_FAILED",
      Ot = [
        N,
        Q,
        tt,
        et,
        rt,
        it,
        nt,
        ot,
        at,
        st,
        ct,
        lt,
        ut,
        ht,
        dt,
        pt,
        gt,
        ft,
        vt,
        mt,
        kt,
        bt,
        yt,
        wt,
        _t,
        At,
        Ct,
        Et,
        xt,
        St,
        It,
      ],
      Rt = function (t, e) {
        return t instanceof Error &&
          ("EvalError" === t.name || t.message.includes("unsafe-eval"))
          ? q
          : e;
      },
      Dt = "VIDEO_PLAYER:AD_BLOCKED",
      Tt = "VIDEO_PLAYER:MEDIA_LOAD_TIMEOUT",
      Vt = "VIDEO_PLAYER:MEDIA_DISPLAY_ERROR",
      Lt = "VIDEO_PLAYER:NO_ADS",
      Pt = "VIDEO_PLAYER:VPAID_START_TIMEOUT",
      Mt = "VIDEO_PLAYER:REQUEST_ERROR",
      Nt = "VIDEO_PLAYER:PLAYBACK_ERROR",
      Ft = "VIDEO_PLAYER:HEAVY_AD_INTERVENTION",
      Bt = "VIDEO_PLAYER:VPAID_INIT_TIMEOUT",
      Ut = "VIDEO_PLAYER:VAST_CORS_ERROR",
      Ht = "VIDEO_PLAYER:SDK_LOAD_ERROR",
      jt = "VIDEO_PLAYER:VPAID_INTERNAL_ERROR",
      zt = "VIDEO_PLAYER:PLAYBACK_TIMEOUT",
      Wt = "VIDEO_PLAYER:UNKNOWN",
      Kt = "KRAKEN:NO_BILLABLE_TRACKERS",
      qt = "KRAKEN:NO_FORMAT",
      Gt = "KRAKEN:PMP_MISSING_FORMAT",
      Yt = "KRAKEN:FORMAT_MISMATCH",
      Jt = "KRAKEN:MISSING_ADM",
      Zt = "KRAKEN:FORMAT_UNSUPPORTED",
      $t = "KRAKEN:NATIVE_JSON_PARSE_ERROR",
      Xt = "KRAKEN:MISSING_AUCTION_TYPE",
      Qt = "KRAKEN:NO_CREATIVE_DATA",
      te = [].concat(
        [F, U, "SSP", H, j, z, W],
        ["CONFIG", K, q, G, Y, J, Z, $, X],
        Ot,
        [Dt, Tt, Vt, Lt, Pt, Mt, Nt, Ft, Bt, Ut, Ht, jt, zt, Wt],
        [B, Kt, qt, Gt, Yt, Jt, Zt, $t, Xt, Qt]
      ),
      ee = "_general",
      re = /^[a-zA-Z0-9_-]+$/;
    function ie(t) {
      if (!t || !re.test(t))
        throw new Error('Invalid experiment name: "' + t + '"');
    }
    var ne = (function () {
      function t() {
        (this.experiments = new Map()),
          (this.impressionExperiments = new Map());
      }
      t.getInstance = function () {
        if ("undefined" == typeof window)
          return (
            t.fallbackInstance || (t.fallbackInstance = new t()),
            t.fallbackInstance
          );
        var e = window,
          r = (0, i.Fk)(e, (0, i.sk)(e));
        return (
          r.experimentRegistry || (r.experimentRegistry = new t()),
          r.experimentRegistry
        );
      };
      var e = t.prototype;
      return (
        (e.reset = function () {
          this.experiments.clear(), this.impressionExperiments.clear();
        }),
        (e.setPageExperiment = function (t, e, r, i) {
          ie(t);
          var n = i || ee,
            o = this.experiments.get(n);
          o || ((o = new Map()), this.experiments.set(n, o)),
            o.set(t, { value: e, label: r });
        }),
        (e.setImpressionExperiment = function (t, e, r, i) {
          ie(e);
          var n = this.impressionExperiments.get(t);
          n || ((n = new Map()), this.impressionExperiments.set(t, n)),
            n.set(e, { value: r, label: i });
        }),
        (e.onImpressionDestroy = function (t) {
          this.impressionExperiments.delete(t);
        }),
        (e.getExperimentValue = function (t, e) {
          var r;
          if (e) {
            var i = this.experiments.get(e),
              n = null == i ? void 0 : i.get(t);
            if (n) return n.value;
          }
          var o = this.experiments.get(ee);
          return null == o || null == (r = o.get(t)) ? void 0 : r.value;
        }),
        (e.getExpObject = function (t, e) {
          var r = new Map(),
            i = this.experiments.get(ee);
          if (
            (i &&
              i.forEach(function (t, e) {
                r.set(e, t.label);
              }),
            e)
          ) {
            var n = this.experiments.get(e);
            n &&
              n.forEach(function (t, e) {
                r.set(e, t.label);
              });
          }
          if (t) {
            var o = this.impressionExperiments.get(t);
            o &&
              o.forEach(function (t, e) {
                r.set(e, t.label);
              });
          }
          if (0 === r.size) return null;
          var a = {};
          return (
            Array.from(r.keys())
              .sort()
              .forEach(function (t) {
                a[t] = r.get(t) || "";
              }),
            a
          );
        }),
        t
      );
    })();
    ne.fallbackInstance = void 0;
    var oe = ["ctrl", "test"];
    function ae(t) {
      if (!t || "string" != typeof t) return null;
      var e = t.indexOf(":");
      if (e <= 0) return null;
      var r = t.slice(0, e),
        i = t.slice(e + 1);
      return -1 === oe.indexOf(i) ? null : { name: r, variant: i };
    }
    function se(t) {
      var e = ae(t);
      return e ? e.name + "_" + e.variant : void 0;
    }
    function ce(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, i);
      }
      return r;
    }
    function le(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2
          ? ce(Object(r), !0).forEach(function (e) {
              (0, T.A)(t, e, r[e]);
            })
          : Object.getOwnPropertyDescriptors
          ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
          : ce(Object(r)).forEach(function (e) {
              Object.defineProperty(
                t,
                e,
                Object.getOwnPropertyDescriptor(r, e)
              );
            });
      }
      return t;
    }
    var ue = function (t, e) {
        for (
          var r = arguments.length, i = new Array(r > 2 ? r - 2 : 0), n = 2;
          n < r;
          n++
        )
          i[n - 2] = arguments[n];
        t.report.apply(t, [e].concat(i));
      },
      he = (function () {
        function t(t, e, r) {
          (this.win = void 0),
            (this.target = void 0),
            (this.infoOverride = void 0),
            (this.reporterInfo = void 0),
            (this.logger = void 0),
            (this.win = t),
            (this.target = e),
            (this.infoOverride = r),
            (this.logger = (e && e.logger) || new n.V(this.win)),
            e ||
              this.logger.error(
                "Reporting target is not ready, reporting result might be affected"
              );
          var i = this.collectReporterInfo();
          this.reporterInfo = le(le({}, i), r);
        }
        var e = t.prototype;
        return (
          (e.collectReporterInfo = function () {
            var t,
              e = this.target || {},
              r =
                e.dfpCreativeData ||
                e.krakenCreativeData ||
                e.krakenResponse ||
                {};
            "string" == typeof r && (r = (r = y(r, "krg_ad_info")) || {});
            var i = "unknown",
              n = e.type || r.source || i;
            e.responseJson
              ? (r = (0, d.h1)(r, e.responseJson) || {})
              : e.rawResponse && (r = (0, d.h1)(r, e.rawResponse) || {}),
              (this.reporterInfo = le(
                {
                  version: "10.9.0-kat-7484-test",
                  slot:
                    e.slotConfig && e.slotConfig.getId
                      ? e.slotConfig.getId()
                      : i,
                  format: r.format || i,
                  source: n,
                  creative:
                    (null == (t = e.creativeData) ? void 0 : t.creativeId) ||
                    r.creative ||
                    r.id ||
                    i,
                  deal_id: r.dealId || r.deal_id || i,
                  campaign_id: r.campaign || i,
                  line_item_id: r.biddableId || r.biddable_id || i,
                  bid_id: r.krg_imp_id || i,
                  adomain:
                    r.advertiserDomain || r.advertiser_domain || r.adomain || i,
                },
                this.infoOverride
              ));
            var o = se(e.branchTestString);
            o
              ? (this.reporterInfo.branch_test = o)
              : delete this.reporterInfo.branch_test;
            try {
              var a,
                s =
                  (null == (a = this.target) ? void 0 : a.impressionId) ||
                  void 0,
                c = ne.getInstance().getExpObject(s, this.reporterInfo.format);
              c ? (this.reporterInfo.exp = c) : delete this.reporterInfo.exp;
            } catch (t) {
              this.logger.debug("ErrorReporter: experiment lookup failed", t);
            }
            return this.reporterInfo;
          }),
          (e.report = function (t, e, r, i) {
            void 0 === i && (i = !1), this.target && this.collectReporterInfo();
            var n = le(le({}, this.reporterInfo), r);
            this.logger.debug(
              "ErrorReporter: ",
              "Code: " + t + ",",
              "Message: " + e + ",",
              "isWarning: " + i + ",",
              "Payload:",
              n
            ),
              ue(this.logger, t, e, n, i);
          }),
          t
        );
      })(),
      de = (function () {
        function t() {}
        return (
          (t.executeGlobalConditionalCheck = function (t, e, r) {
            var i,
              n,
              o = null == (i = I(r)) ? void 0 : i.getGlobalConfig;
            if (
              o &&
              o() &&
              null != (n = t = o()) &&
              n.getConditionalCheckFunc &&
              t.getConditionalCheckFunc()
            )
              try {
                (0, d.zH)(r, t.getConditionalCheckFunc());
              } catch (t) {
                var a = "Error in Global Conditional Check:";
                e.error(a, t),
                  ue(
                    e,
                    Rt(t, J),
                    a +
                      " " +
                      (t instanceof Error
                        ? t.name + " - " + t.message
                        : String(t)),
                    { version: "10.9.0-kat-7484-test" }
                  );
              }
          }),
          (t.executePreloadJS = function (t, e, r) {
            if (null != t && t.getPreLoadFunc && t.getPreLoadFunc())
              try {
                (0, d.zH)(r, t.getPreLoadFunc());
              } catch (t) {
                var i = "Error in Global Javascript:";
                e.error(i, t),
                  ue(
                    e,
                    Rt(t, Z),
                    i +
                      " " +
                      (t instanceof Error
                        ? t.name + " - " + t.message
                        : String(t)),
                    { version: "10.9.0-kat-7484-test" }
                  );
              }
          }),
          (t.executePreloadCSS = function (t, e) {
            if (null != t && t.getPreLoadCss && t.getPreLoadCss()) {
              var r = e.document.createElement("style");
              (r.type = "text/css"),
                (r.className = "kargo-css"),
                (r.textContent = t.getPreLoadCss()),
                e.document.head.appendChild(r);
            }
          }),
          t
        );
      })();
    function pe(t, e, r) {
      var i = function (e) {
        for (
          var r = null, n = e.document.getElementsByTagName("script"), o = 0;
          o < n.length;
          o += 1
        )
          if (
            n[o].textContent &&
            n[o].textContent.indexOf(t) > -1 &&
            n[o].textContent.indexOf("Kargo") > -1
          ) {
            r = n[o];
            break;
          }
        if (e.AMP_LISTENING) {
          var a = e.document.querySelector("#c > script");
          if (a) r = a;
          else {
            var s = e.document.body.getElementsByTagName("*");
            s.length
              ? (r = s[0])
              : (((r = e.document.createElement("div")).style.display = "none"),
                e.document.body.appendChild(r));
          }
        }
        if (!r)
          for (
            var c = e.document.getElementsByTagName("iframe"), l = 0;
            l < c.length;
            l += 1
          )
            if (c[l].contentWindow) {
              try {
                r = i(c[l].contentWindow);
              } catch (t) {}
              if (r) break;
            }
        return r;
      };
      return i(r || e);
    }
    var ge = (function () {
        function t(t, e, r, i) {
          (this.request = void 0),
            (this.win = void 0),
            (this.logger = void 0),
            (this.errorReporter = void 0),
            (this.request = t),
            (this.win = e),
            (this.logger = r),
            (this.errorReporter = i);
        }
        var e = t.prototype;
        return (
          (e.preDrawJS = function (t, e) {
            this.formatPreDraw(t), this.slotPreDraw(e);
          }),
          (e.postDrawJS = function (t, e) {
            this.formatPostDraw(t), this.slotPostDraw(e);
          }),
          (e.formatPreDraw = function (t) {
            if (
              this.request.getFormatConfig() &&
              this.request.getFormatConfig().getPreDrawFunc &&
              this.request.getFormatConfig().getPreDrawFunc()
            )
              try {
                (0, d.zH)(
                  this.win,
                  this.request.getFormatConfig().getPreDrawFunc()
                );
              } catch (e) {
                e instanceof Error && this.logError("Format PreDraw", t, e);
              }
          }),
          (e.slotPreDraw = function (t) {
            if (
              this.request.getSlotConfig() &&
              this.request.getSlotConfig().getPreDrawFunc &&
              this.request.getSlotConfig().getPreDrawFunc() &&
              !(
                this.request.getFormatConfig() &&
                this.request.getFormatConfig().isIgnoreSlotPreDrawFunc &&
                this.request.getFormatConfig().isIgnoreSlotPreDrawFunc()
              )
            )
              try {
                (0, d.zH)(
                  this.win,
                  this.request.getSlotConfig().getPreDrawFunc()
                );
              } catch (e) {
                e instanceof Error && this.logError("Slot PreDraw", t, e);
              }
          }),
          (e.formatPostDraw = function (t) {
            if (
              this.request.getFormatConfig() &&
              this.request.getFormatConfig().getPostDrawFunc &&
              this.request.getFormatConfig().getPostDrawFunc()
            )
              try {
                (0, d.zH)(
                  this.win,
                  this.request.getFormatConfig().getPostDrawFunc()
                );
              } catch (e) {
                e instanceof Error && this.logError("Format PostDraw", t, e);
              }
          }),
          (e.slotPostDraw = function (t) {
            if (
              this.request.getSlotConfig() &&
              this.request.getSlotConfig().getPostDrawFunc &&
              this.request.getSlotConfig().getPostDrawFunc() &&
              !(
                this.request.getFormatConfig() &&
                this.request.getFormatConfig().isIgnoreSlotPostDrawFunc &&
                this.request.getFormatConfig().isIgnoreSlotPostDrawFunc()
              )
            )
              try {
                (0, d.zH)(
                  this.win,
                  this.request.getSlotConfig().getPostDrawFunc()
                );
              } catch (e) {
                e instanceof Error && this.logError("Slot PostDraw", t, e);
              }
          }),
          (e.logError = function (t, e, r) {
            var i = "Error in '" + e + "' " + t + " Javascript: ";
            (i = i + " " + r.name + " - " + r.message),
              this.logger.error(i, r),
              this.errorReporter.report(Rt(r, G), i);
          }),
          t
        );
      })(),
      fe = (function () {
        function t(t) {
          (this.win = t),
            (this.active = !1),
            (this.api = null),
            (this.status = null),
            (this.lastEventData = null),
            (this.isRegistered = !1),
            (this.initialSize = { width: 0, height: 0 }),
            (0, i.r1)(this.win) &&
              ((this.active = !0), (this.api = this.win.$sf.ext));
        }
        return (
          (t.prototype.isActive = function () {
            return this.active;
          }),
          (t.prototype.findContainerApi = function () {
            return Promise.resolve(this.isActive());
          }),
          (t.prototype.getApi = function () {
            return this.api;
          }),
          (t.prototype.getApiStatus = function () {
            return this.status;
          }),
          (t.prototype.getContainerStatus = function () {
            return this.api ? this.api.status() : null;
          }),
          (t.prototype.getLastEventData = function () {
            return this.lastEventData;
          }),
          (t.prototype.getSize = function () {
            var t = { width: 0, height: 0 };
            if (this.api) {
              var e = this.api.geom();
              t = { width: e.self.w, height: e.self.h };
            }
            return t;
          }),
          (t.prototype.getContainerSize = function () {
            return this.getSize();
          }),
          (t.prototype.getSupport = function () {
            return this.api ? this.api.supports() : null;
          }),
          (t.prototype.setInitialSize = function (t, e) {
            var r = this;
            this.api &&
              ((this.initialSize.width = t),
              (this.initialSize.height = e),
              (this.isRegistered = !0),
              this.api.register(t, e, function (t, e) {
                (r.status = t), (r.lastEventData = e);
              }));
          }),
          (t.prototype.setExpandedSize = function (t, e) {
            if (this.api) {
              var r = this.getSize();
              if (r.width !== t || r.height !== e) {
                var i = this.getSupport();
                this.api.expand({ b: e, r: t, push: !!i && i["exp-push"] });
              }
              return Promise.resolve();
            }
            return Promise.reject(new Error("SafeFrame API not set"));
          }),
          (t.prototype.setContainerSize = function (t, e) {
            return this.api && t && e && t > 0 && e > 0
              ? (this.isRegistered || this.setInitialSize(t, e),
                this.setExpandedSize(t, e))
              : Promise.reject(
                  new Error(
                    "SafeFrame API not set or invalid size of "
                      .concat(t, "x")
                      .concat(e)
                  )
                );
          }),
          (t.prototype.noAdToDisplay = function () {}),
          (t.prototype.getInViewPercentage = function () {
            return this.api ? this.api.inViewPercentage() : 0;
          }),
          (t.prototype.isVisible = function () {
            return this.getInViewPercentage() > 0;
          }),
          t
        );
      })(),
      ve = (function () {
        function t(t) {
          (this.win = t),
            (this.active = !1),
            (this.renderStarted = !1),
            (this.api = null),
            (this.size = { width: 0, height: 0 }),
            (this.percentInView = 0);
        }
        return (
          (t.prototype.findContainerApi = function () {
            var t = this;
            return new Promise(function (e) {
              var r = function (r) {
                r &&
                  r.observeIntersection &&
                  r.requestResize &&
                  (t.setApi(r), (t.active = !0)),
                  e(t.active);
              };
              if (t.win.context) r(t.win.context);
              else if (
                t.win.AMP_CONTEXT_DATA &&
                t.win.AMP_CONTEXT_DATA.ampcontextFilepath
              ) {
                var i = t.win.AMP_CONTEXT_DATA.ampcontextFilepath;
                (0, c._G)(i, t.win, {}, function () {
                  r(t.win.context || null);
                });
              } else r(null);
            });
          }),
          (t.prototype.setApi = function (t) {
            var e = this;
            (this.api = t),
              (this.size.width = this.win.innerWidth),
              (this.size.height = this.win.innerHeight),
              this.api.observeIntersection &&
                this.api.observeIntersection(function (t) {
                  e.api.hidden
                    ? (e.percentInView = 0)
                    : (e.percentInView =
                        100 * t[t.length - 1].intersectionRatio);
                });
          }),
          (t.prototype.isActive = function () {
            return this.active;
          }),
          (t.prototype.getApi = function () {
            return this.api;
          }),
          (t.prototype.getContainerSize = function () {
            return this.size;
          }),
          (t.prototype.isVisible = function () {
            return this.getInViewPercentage() > 0;
          }),
          (t.prototype.getInViewPercentage = function () {
            return this.percentInView;
          }),
          (t.prototype.setContainerSize = function (t, e) {
            var r = this,
              i = !1;
            return this.api
              ? (!this.renderStarted &&
                  this.api.renderStart &&
                  (this.api.renderStart({ width: t, height: e }),
                  (this.renderStarted = !0),
                  (i = !0)),
                (i || this.size.width !== t || this.size.height !== e) &&
                this.api.requestResize
                  ? this.api
                      .requestResize(t, e)
                      .then(function () {
                        (r.size.width = t),
                          (r.size.height = e),
                          i && r.api.signalInteractive();
                      })
                      .catch(function (t) {
                        return (
                          i && r.api.signalInteractive(), Promise.reject(t)
                        );
                      })
                  : Promise.resolve())
              : Promise.reject(new Error("GoogleAmp API not set"));
          }),
          (t.prototype.noAdToDisplay = function () {
            this.api && this.api.noContentAvailable();
          }),
          (t.prototype.getMasterWindow = function () {
            return this.api ? this.api.master : null;
          }),
          t
        );
      })(),
      me = (function () {
        function t(t) {
          (this.type = null),
            (this.ready = !1),
            (this.win = (0, i.sk)(t)),
            (this.safeFrame = new fe(this.win)),
            (this.googleAmp = new ve(this.win));
        }
        return (
          (t.prototype.getType = function () {
            return this.type;
          }),
          (t.prototype.detectEnvironment = function () {
            var t = this;
            return this.ready
              ? Promise.resolve(this.type)
              : Promise.all([
                  this.googleAmp.findContainerApi(),
                  this.safeFrame.findContainerApi(),
                ]).then(function (e) {
                  var r = e[0],
                    i = e[1];
                  return (
                    (t.type = r ? "GoogleAmp" : i ? "SafeFrame" : null),
                    (t.ready = !0),
                    t.type
                  );
                });
          }),
          (t.prototype.isInContainer = function () {
            return null !== this.type;
          }),
          (t.prototype.callContainerMethod = function (t, e, r) {
            void 0 === r && (r = null);
            var i = r;
            switch (this.type) {
              case "GoogleAmp":
                this.googleAmp[t] &&
                  (i = this.googleAmp[t].apply(this.googleAmp, e));
                break;
              case "SafeFrame":
                this.safeFrame[t] &&
                  (i = this.safeFrame[t].apply(this.safeFrame, e));
            }
            return i;
          }),
          (t.prototype.isVisible = function () {
            return this.callContainerMethod("isVisible", [], !1);
          }),
          (t.prototype.getInViewPercentage = function () {
            return this.callContainerMethod("getInViewPercentage", [], 0);
          }),
          (t.prototype.setContainerSize = function (t, e) {
            return this.callContainerMethod("setContainerSize", [t, e]);
          }),
          (t.prototype.getContainerSize = function () {
            return this.callContainerMethod("getContainerSize", [], {
              height: null,
              width: null,
            });
          }),
          (t.prototype.noAdToDisplay = function () {
            this.callContainerMethod("noAdToDisplay", []);
          }),
          t
        );
      })();
    function ke() {
      return (
        (ke = (0, V.A)(
          P().mark(function t(e, r, i) {
            var n, o;
            return P().wrap(function (t) {
              for (;;)
                switch ((t.prev = t.next)) {
                  case 0:
                    return (
                      (n = new me(e)),
                      (o = !0),
                      (t.next = 4),
                      n.detectEnvironment()
                    );
                  case 4:
                    "SafeFrame" === t.sent &&
                      ue(
                        r,
                        z,
                        "AdTag loaded in SafeFrame",
                        { slot: i, version: "10.9.0-kat-7484-test" },
                        o
                      );
                  case 6:
                  case "end":
                    return t.stop();
                }
            }, t);
          })
        )),
        ke.apply(this, arguments)
      );
    }
    var be = {
      reportSafeFrame: function (t, e, r) {
        return ke.apply(this, arguments);
      },
    };
    var ye,
      we = {
        reportAdMetric: function (t, e, r) {
          var i = ae(e.branchTestString),
            n = {
              value: t.value || 1,
              type: t.type,
              adFormat: e.format || "unknown",
              adTagVersion: t.version,
              adSlot: e.slot || "unknown",
              errCode: t.errCode || "",
              videoType: t.videoType || "",
              vpaidClickable: t.vpaidClickable || 0,
              safeframeEvent: t.safeframeEvent,
            };
          i && (n.branchTest = i.name + "_" + i.variant);
          try {
            var o = ne.getInstance().getExpObject(e.id, e.format);
            o && (n.exp = o);
          } catch (t) {
            r.debug("reportAdMetric: experiment lookup failed", t);
          }
          r.reportAdMetric(n, function (e) {
            null === e
              ? r.debug("Ad Metrics reported for " + t.type)
              : r.debug("Failed reporting Ad Metrics for " + t.type);
          });
        },
      };
    function _e(t, e) {
      return (
        (_e = Object.setPrototypeOf
          ? Object.setPrototypeOf.bind()
          : function (t, e) {
              return (t.__proto__ = e), t;
            }),
        _e(t, e)
      );
    }
    function Ae(t, e) {
      (t.prototype = Object.create(e.prototype)),
        (t.prototype.constructor = t),
        _e(t, e);
    }
    !(function (t) {
      (t.Render = "render"),
        (t.AdTagReady = "adtag_ready"),
        (t.CreativeReady = "creative_ready");
    })(ye || (ye = {}));
    var Ce = (function () {
        function t(t, e) {
          (this.win = void 0),
            (this.logger = void 0),
            (this.name = ""),
            (this.ready = !1),
            (this.readyCallbacks = []),
            (this.readyTimeout = 1e3),
            (this.win = t),
            (this.logger = e);
        }
        var e = t.prototype;
        return (
          (e.load = function () {
            var t = this;
            return new Promise(function (e) {
              t.setReady(), e();
            });
          }),
          (e.isEnabled = function () {
            var t,
              e,
              i = !1,
              n =
                null !=
                (t =
                  null == (e = I(this.win)) || null == e.getGlobalConfig
                    ? void 0
                    : e.getGlobalConfig())
                  ? t
                  : null;
            n &&
              r()(n, "getEnabledPlugins", function () {
                return [];
              })().indexOf(this.name) > -1 &&
              (i = !0);
            return i;
          }),
          (e.setReady = function () {
            this.ready = !0;
            for (var t = 0; t < this.readyCallbacks.length; t++)
              this.readyCallbacks[t]();
            this.readyCallbacks = [];
          }),
          (e.onReady = function () {
            var t = this;
            return new Promise(function (e) {
              t.ready
                ? e()
                : t.readyCallbacks.push(function () {
                    e();
                  });
            });
          }),
          (e.setReadyOnTimeout = function (t) {
            var e = this;
            void 0 === t && (t = this.readyTimeout),
              this.win.setTimeout(function () {
                e.isReady() || e.setReady();
              }, t);
          }),
          (e.isReady = function () {
            return this.ready;
          }),
          t
        );
      })(),
      Ee = (function (t) {
        function e() {
          for (var e, r = arguments.length, i = new Array(r), n = 0; n < r; n++)
            i[n] = arguments[n];
          return (
            ((e = t.call.apply(t, [this].concat(i)) || this).name =
              "IframeBuster"),
            (e.errFactory = new l.wm("IframeBuster")),
            (e.TIMEOUT = 2e3),
            (e.active = !1),
            e
          );
        }
        Ae(e, t);
        var n = e.prototype;
        return (
          (n.load = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e = this;
                return P().wrap(function (t) {
                  for (;;)
                    switch ((t.prev = t.next)) {
                      case 0:
                        return t.abrupt(
                          "return",
                          new Promise(
                            (function () {
                              var t = (0, V.A)(
                                P().mark(function t(r) {
                                  var n;
                                  return P().wrap(
                                    function (t) {
                                      for (;;)
                                        switch ((t.prev = t.next)) {
                                          case 0:
                                            if ((0, i.aX)(e.win)) {
                                              t.next = 5;
                                              break;
                                            }
                                            e.setReady(), r(), (t.next = 19);
                                            break;
                                          case 5:
                                            return (
                                              (n = new me(e.win)),
                                              (t.prev = 6),
                                              (t.next = 9),
                                              n.detectEnvironment()
                                            );
                                          case 9:
                                            null === t.sent && (e.active = !0),
                                              e.setReady(),
                                              r(),
                                              (t.next = 18);
                                            break;
                                          case 15:
                                            (t.prev = 15),
                                              (t.t0 = t.catch(6)),
                                              e.logger.error(t.t0);
                                          case 18:
                                            e.setReadyOnTimeout();
                                          case 19:
                                          case "end":
                                            return t.stop();
                                        }
                                    },
                                    t,
                                    null,
                                    [[6, 15]]
                                  );
                                })
                              );
                              return function (e) {
                                return t.apply(this, arguments);
                              };
                            })()
                          )
                        );
                      case 1:
                      case "end":
                        return t.stop();
                    }
                }, t);
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          (n.isActive = function () {
            return this.active;
          }),
          (n.requestAd = function (t, e) {
            var i = this;
            return new Promise(function (n, a) {
              var s, c;
              ue(i.logger, j, "AdTag loaded in Cross Origin Iframe", {
                slot: t,
                version: "10.9.0-kat-7484-test",
              });
              var l = (0, o.pO)(i.win).match(
                  /^https?:\/\/[\.a-z0-9-]+\.[a-z]+(?::\d+)?/
                ),
                u = "";
              if ((l && l[0] && (u = l[0]), u)) {
                var h = u + "/krg_iframebuster.html",
                  d = null,
                  p =
                    null !=
                    (s =
                      null == (c = I(i.win)) || null == c.getGlobalConfig
                        ? void 0
                        : c.getGlobalConfig())
                      ? s
                      : null;
                p && (d = p.getAdTagUrl()) && (e.adTagUrl = d);
                var g = r()(i.win, "Kargo.self_url", null);
                if ((!d && g && (d = g), d)) {
                  var f,
                    v = i.win.document.createElement("iframe");
                  (v.style.visibility = "hidden"),
                    (v.style.position = "absolute"),
                    (v.style.width = "1px"),
                    (v.style.height = "1px"),
                    (v.style.top = "0px"),
                    (v.style.left = "0px"),
                    (v.src = h);
                  var m = function (o) {
                    var s = function (t) {
                      i.win.clearTimeout(f),
                        i.win.removeEventListener("message", m),
                        a(i.errFactory.errGet("Source Iframe"));
                    };
                    if (
                      o.origin.indexOf("krg_iframebuster.html") > -1 &&
                      o.data &&
                      o.data.status
                    ) {
                      if (!o.source)
                        return void s(i.errFactory.errGet("Source Iframe"));
                      var c = r()(o.source, "Kargo.IframeBuster");
                      if (!c)
                        return void s(
                          i.errFactory.errGet("IframeBuster", "Iframe")
                        );
                      "ready" === o.data.status &&
                        c.loadAdTag(d, function (r) {
                          if ((i.win.removeEventListener("message", m), r)) s();
                          else {
                            var o = c.getTopNamespace();
                            o && o.AdTag
                              ? o.AdTag.requestAd(t, e, function () {
                                  n();
                                })
                              : s(i.errFactory.errGet("Top Namespace"));
                          }
                        });
                    }
                  };
                  i.win.addEventListener("message", m),
                    i.win.document.body.appendChild(v),
                    (f = i.win.setTimeout(function () {
                      i.win.document.body.removeChild(v),
                        i.win.addEventListener("message", m),
                        a(i.errFactory.errLoad("IframeBuster"));
                    }, i.TIMEOUT));
                } else a(i.errFactory.errCant("determine AdTag Url"));
              } else a(i.errFactory.errCant("use iFrameBuster", "", "no referring domain"));
            });
          }),
          e
        );
      })(Ce),
      xe = "Chrome",
      Se = "Safari",
      Ie = "Firefox",
      Oe = "Opera",
      Re = "Edge",
      De = "Android",
      Te = "ios",
      Ve = "Windows",
      Le = "MacOS",
      Pe = "other",
      Me = "Mobile";
    function Ne(t) {
      return t.toLowerCase();
    }
    function Fe(t) {
      var e = t.navigator.userAgent,
        r = Pe;
      return (
        e.indexOf("".concat(Re, "/")) > -1
          ? (r = Ne(Re))
          : e.indexOf("".concat(xe, "/")) > -1
          ? (r = Ne(xe))
          : e.indexOf("".concat(Se, "/")) > -1
          ? (r = Ne(Se))
          : e.indexOf("".concat(Ie, "/")) > -1
          ? (r = Ne(Ie))
          : e.indexOf(Oe) > -1
          ? (r = Ne(Oe))
          : e.indexOf("MSIE") > -1 || e.indexOf("Trident/") > -1
          ? (r = "ie")
          : e.indexOf("FBAN/FBForIPhone") > -1 ||
            e.indexOf("FBAN/FBIOS") > -1 ||
            e.indexOf("facebookexternalhit/") > -1
          ? (r = "facebook")
          : e.indexOf("Twitter for iPhone") > -1
          ? (r = "twitter")
          : e.indexOf("Instagram") > -1
          ? (r = "instagram")
          : e.indexOf("Pinterest") > -1
          ? (r = "pinterest")
          : e.indexOf("LinkedInApp") > -1
          ? (r = "linkedIn")
          : e.indexOf("Snapchat") > -1 && (r = "snapchat"),
        r
      );
    }
    function Be(t) {
      var e = t.navigator.userAgent,
        r = Pe;
      return (
        e.indexOf(De) > -1
          ? (r = Ne(De))
          : /iP(hone|od|ad)/.test(e)
          ? (r = Te)
          : /windows/i.test(e)
          ? (r = Ve)
          : /macintosh/i.test(e)
          ? (r = Le)
          : /linux/i.test(e) && (r = "Linux"),
        r
      );
    }
    function Ue(t) {
      var e = Be(t),
        r = {};
      (r[Ne(De)] = "android"),
        (r[Ne(Te)] = "os"),
        (r[Ne(Le)] = "mac os x"),
        (r[Ne(Ve)] = "windows nt");
      var i = r[Ne(e)],
        n = new RegExp("".concat(i, "\\s+(\\d+)[_\\.](\\d+)?[_\\.]?(\\d+)?")),
        o = Ne(t.navigator.userAgent).match(n) || [0, 0];
      return parseInt(o[1], 10);
    }
    function He(t) {
      var e = t.navigator.userAgent;
      return e.indexOf(Me) > -1 && !/iPad|Xoom|SCH-I800|Kindle/.test(e);
    }
    function je(t) {
      var e = t.navigator.userAgent;
      return (
        /iPad|Xoom|SCH-I800|Kindle/.test(e) ||
        (e.indexOf(De) >= 0 && e.indexOf(Me) < 0)
      );
    }
    function ze(t, e) {
      for (
        var r,
          i = t.document.cookie.split(";"),
          n = null,
          o = "".concat(e, "="),
          a = 0;
        a < i.length;
        a += 1
      ) {
        for (; " " === i[a].charAt(0); ) i[a] = i[a].substring(1, i[a].length);
        if (0 === i[a].indexOf(o)) {
          r = i[a].substring(o.length, i[a].length);
          try {
            n = JSON.parse(r);
          } catch (t) {
            n = r;
          }
          return n;
        }
      }
      return null;
    }
    function We(t, e, r, i) {
      void 0 === i && (i = 0);
      var n = "".concat(e, "=");
      if (((n += "object" == typeof r ? JSON.stringify(r) : r), i)) {
        var o = new Date(Date.now() + i);
        n += "; expires=".concat(o.toUTCString());
      }
      n += "; path=/";
      var a = Be(t),
        s = Ue(t),
        c = n;
      (a !== Te || s >= 13) && (c += "; SameSite=None; Secure"),
        (t.document.cookie = c),
        null === ze(t, e) && (t.document.cookie = n);
    }
    function Ke(t) {
      for (var e = t, r = t.top; e !== r; ) {
        var i = void 0;
        try {
          i = e.parent.location.href;
        } catch (t) {
          i = !1;
        }
        if (!i) break;
        for (
          var n = e.parent.document.getElementsByTagName("iframe"),
            o = void 0,
            a = null,
            s = 0;
          s < n.length;
          s += 1
        )
          if ((o = n[s]).contentWindow === e) {
            a = o;
            break;
          }
        if (a && a.className.split(" ").indexOf("krg-nobust") > -1) break;
        e = e.parent;
      }
      return e;
    }
    var qe = Ke(window),
      Ge = __webpack_require__(4234);
    function Ye(t, e) {
      return decodeURIComponent(
        (new RegExp("".concat(e, "=(.+?)(&|$)"), "i").exec(t) || ["", ""])[1]
      );
    }
    function Je(t) {
      var e = "";
      try {
        e = t.location.href;
      } catch (t) {}
      return (
        t.AMP_CONTEXT_DATA && t.AMP_CONTEXT_DATA.sourceUrl
          ? (e = t.AMP_CONTEXT_DATA.sourceUrl)
          : t.context && t.context.sourceUrl
          ? (e = t.context.sourceUrl)
          : (function (t) {
              var e;
              try {
                e = t.top.location.href;
              } catch (t) {
                e = null;
              }
              return !e;
            })(t) && t.document.referrer
          ? (e = t.document.referrer)
          : Ye(e, "content_url") && (e = Ye(e, "content_url")),
        e
      );
    }
    var Ze,
      $e =
        ((Ze = function (t, e) {
          return (
            (Ze =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (t, e) {
                  t.__proto__ = e;
                }) ||
              function (t, e) {
                for (var r in e)
                  Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
              }),
            Ze(t, e)
          );
        }),
        function (t, e) {
          if ("function" != typeof e && null !== e)
            throw new TypeError(
              "Class extends value " +
                String(e) +
                " is not a constructor or null"
            );
          function r() {
            this.constructor = t;
          }
          Ze(t, e),
            (t.prototype =
              null === e
                ? Object.create(e)
                : ((r.prototype = e.prototype), new r()));
        }),
      Xe = function () {
        return (
          (Xe =
            Object.assign ||
            function (t) {
              for (var e, r = 1, i = arguments.length; r < i; r++)
                for (var n in (e = arguments[r]))
                  Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
              return t;
            }),
          Xe.apply(this, arguments)
        );
      },
      Qe = (function (t) {
        function e(e, r) {
          void 0 === r && (r = {});
          var i = this.constructor,
            n = t.call(this, e) || this;
          return (
            Object.setPrototypeOf(n, i.prototype),
            (n.message = n.buildErrorMessage(e || "", r)),
            n
          );
        }
        return (
          $e(e, t),
          (e.prototype.addContext = function (t, e) {
            var r = e.ctx,
              i = e.moduleName,
              n = e.prep,
              o = e.reason,
              a = t || "";
            if ((i && (a = "".concat(i, ": ").concat(a)), r)) {
              var s = n || "in";
              a = "".concat(a, " ").concat(s, " ").concat(r);
            }
            return o && (a += ": ".concat(o)), a;
          }),
          (e.prototype.buildErrorMessage = function (t, e) {
            return this.addContext(t, e);
          }),
          e
        );
      })(Error),
      tr = (function (t) {
        function e() {
          return (null !== t && t.apply(this, arguments)) || this;
        }
        return (
          $e(e, t),
          (e.prototype.buildErrorMessage = function (t, e) {
            return this.addContext("Cannot ".concat(t), e);
          }),
          e
        );
      })(Qe),
      er = (function (t) {
        function e() {
          return (null !== t && t.apply(this, arguments)) || this;
        }
        return (
          $e(e, t),
          (e.prototype.buildErrorMessage = function (t, e) {
            return this.addContext("".concat(t, " is disabled"), e);
          }),
          e
        );
      })(Qe),
      rr = (function (t) {
        function e() {
          return (null !== t && t.apply(this, arguments)) || this;
        }
        return (
          $e(e, t),
          (e.prototype.buildErrorMessage = function (t, e) {
            return this.addContext("Cannot load ".concat(t), e);
          }),
          e
        );
      })(Qe),
      ir = (function (t) {
        function e() {
          return (null !== t && t.apply(this, arguments)) || this;
        }
        return (
          $e(e, t),
          (e.prototype.buildErrorMessage = function (t, e) {
            return this.addContext("Cannot get ".concat(t), e);
          }),
          e
        );
      })(Qe),
      nr = (function (t) {
        function e() {
          return (null !== t && t.apply(this, arguments)) || this;
        }
        return (
          $e(e, t),
          (e.prototype.buildErrorMessage = function (t, e) {
            var r = t ? "No ".concat(t) : "Empty",
              i = "".concat(r, " response");
            return this.addContext(i, e);
          }),
          e
        );
      })(Qe),
      or = (function (t) {
        function e() {
          return (null !== t && t.apply(this, arguments)) || this;
        }
        return (
          $e(e, t),
          (e.prototype.buildErrorMessage = function (t, e) {
            return this.addContext(
              "".concat(t, " not supported"),
              Xe({ prep: e.prep || "by" }, e)
            );
          }),
          e
        );
      })(Qe),
      ar = (function (t) {
        function e() {
          return (null !== t && t.apply(this, arguments)) || this;
        }
        return (
          $e(e, t),
          (e.prototype.buildErrorMessage = function (t, e) {
            return this.addContext("".concat(t, " is not set"), e);
          }),
          e
        );
      })(Qe),
      sr = (function (t) {
        function e() {
          return (null !== t && t.apply(this, arguments)) || this;
        }
        return (
          $e(e, t),
          (e.prototype.buildErrorMessage = function (t, e) {
            return this.addContext("".concat(t, " is invalid"), e);
          }),
          e
        );
      })(Qe),
      cr = (function (t) {
        function e() {
          return (null !== t && t.apply(this, arguments)) || this;
        }
        return (
          $e(e, t),
          (e.prototype.buildErrorMessage = function (t, e) {
            return this.addContext(
              "Request for ".concat(t, " timed out"),
              Xe({ prep: e.prep || "after" }, e)
            );
          }),
          e
        );
      })(Qe),
      lr = (function () {
        function t(t) {
          this.moduleName = t;
        }
        return (
          (t.prototype.errCant = function (t, e, r) {
            return new tr(t, {
              ctx: e,
              reason: r,
              moduleName: this.moduleName,
            });
          }),
          (t.prototype.errDisabled = function (t, e) {
            return new er("".concat(t), {
              ctx: e,
              moduleName: this.moduleName,
            });
          }),
          (t.prototype.errLoad = function (t, e) {
            return new rr("".concat(t), {
              ctx: e,
              moduleName: this.moduleName,
            });
          }),
          (t.prototype.errGet = function (t, e) {
            return new ir("".concat(t), {
              ctx: e,
              moduleName: this.moduleName,
            });
          }),
          (t.prototype.errNew = function (t) {
            return new Qe(t, { moduleName: this.moduleName });
          }),
          (t.prototype.errNoResponse = function (t, e) {
            return new nr(t, { ctx: e, moduleName: this.moduleName });
          }),
          (t.prototype.errNoSupport = function (t, e) {
            return new or(t, {
              ctx: e,
              prep: "by",
              moduleName: this.moduleName,
            });
          }),
          (t.prototype.errNotSet = function (t, e) {
            return new ar(t, { ctx: e, moduleName: this.moduleName });
          }),
          (t.prototype.errInvalid = function (t, e) {
            return new sr(t, { ctx: e, moduleName: this.moduleName });
          }),
          (t.prototype.errTimeout = function (t, e) {
            return new cr(t, { ctx: e, moduleName: this.moduleName });
          }),
          t
        );
      })(),
      ur = function (t, e) {
        var r = {};
        for (var i in t)
          Object.prototype.hasOwnProperty.call(t, i) &&
            e.indexOf(i) < 0 &&
            (r[i] = t[i]);
        if (null != t && "function" == typeof Object.getOwnPropertySymbols) {
          var n = 0;
          for (i = Object.getOwnPropertySymbols(t); n < i.length; n++)
            e.indexOf(i[n]) < 0 &&
              Object.prototype.propertyIsEnumerable.call(t, i[n]) &&
              (r[i[n]] = t[i[n]]);
        }
        return r;
      };
    new lr("ad-util/request");
    function hr(t, e, r) {
      void 0 === r && (r = !1);
      var i = e,
        n = t.document.createElement("img");
      if (
        ((n.style.position = "absolute"),
        (n.style.visibility = "hidden"),
        (n.style.left = "-9999px"),
        (n.style.top = "0"),
        r &&
          (i += ""
            .concat(e.indexOf("?") > -1 ? "&" : "?", "_cb=")
            .concat(Date.now() * Math.random())),
        -1 !== i.indexOf("tk.kargo.com"))
      ) {
        var o = (0, Ge.xF)(t, "Kargo.Plugin.Cerberus.getLexId");
        o &&
          o() &&
          (i = (function (t, e) {
            if (!e) return t;
            var r,
              i = t;
            return (
              Object.keys(e).forEach(function (t) {
                (r = e[t]),
                  (i += ""
                    .concat(i.indexOf("?") > -1 ? "&" : "?")
                    .concat(t, "=")
                    .concat(encodeURIComponent(r)));
              }),
              i
            );
          })(i, { kid: o() }));
      }
      var a,
        s = function (t) {
          t.parentNode && t.parentNode.removeChild(t);
        };
      return (
        n.addEventListener(
          "load",
          function () {
            t.clearTimeout(a), s(n);
          },
          !1
        ),
        (a = t.setTimeout(function () {
          s(n);
        }, 8e3)),
        (n.src = i),
        t.document.body.appendChild(n),
        n
      );
    }
    function dr(t) {
      t && t.start();
    }
    function pr(t) {
      t && t.stop();
    }
    function gr(t, e, r, i, n, o) {
      if ((void 0 === o && (o = {}), t && t.length)) {
        var a = new XMLHttpRequest(),
          s = o.latencyTracker;
        i && (a.withCredentials = !0),
          r && (a.timeout = r),
          (a.onload = function () {
            if ((pr(s), a.status >= 200 && a.status < 400)) {
              var t = (a.responseText || "").trim();
              if (t.length) {
                try {
                  t = JSON.parse(t);
                } catch (t) {}
                n(null, t);
              } else n(new Error("Empty Response"));
            } else
              n(
                new Error(
                  "GET Request Failed with Status: "
                    .concat(a.status, " - ")
                    .concat(a.statusText)
                )
              );
          }),
          (a.ontimeout = function (t) {
            n(t);
          }),
          (a.onerror = function (t) {
            n(t);
          }),
          a.open("GET", t, !0),
          dr(s),
          a.send();
      } else n(new Error("Invalid URL"));
    }
    var fr = (function () {
        function t(t, e, r, i, n) {
          void 0 === n && (n = 1),
            (this.win = t),
            (this.dataBucket = e),
            (this.allowedReportParamKeys = r),
            (this.params = i),
            (this.counter = n);
        }
        return (
          (t.prototype.createReportUrl = function () {
            var t = this,
              e = "".concat("https://ad-monitor.kargo.com", "?data="),
              r = this.dataBucket;
            return (
              Object.keys(this.params).forEach(function (e) {
                if (t.allowedReportParamKeys.has(e)) {
                  var i = t.params[e];
                  if (i || 0 === i || !1 === i) {
                    var n = t.escapeLineProtocolTagKeyOrValue(t.params[e]);
                    r += ","
                      .concat(t.escapeLineProtocolTagKeyOrValue(e), "=")
                      .concat(n);
                  }
                }
              }),
              (r += " value=".concat(this.counter)),
              "".concat(e).concat(encodeURIComponent(r))
            );
          }),
          (t.prototype.escapeLineProtocolTagKeyOrValue = function (t) {
            return "object" == typeof t
              ? "invalid"
              : "".concat(t).replace(/,|\s|=/g, "\\$&");
          }),
          (t.prototype.report = function () {
            try {
              !(function (t, e, r, i) {
                var n = r.timeout,
                  o = void 0 === n ? 0 : n,
                  a = r.withCredentials;
                gr(
                  t,
                  0,
                  o,
                  void 0 !== a && a,
                  i,
                  ur(r, ["timeout", "withCredentials"])
                );
              })(
                this.createReportUrl(),
                this.win,
                { timeout: 1e3, withCredentials: !1 },
                function () {}
              );
            } catch (t) {
              console.error(t);
            }
          }),
          t
        );
      })(),
      vr = new Set([
        "browser",
        "creative",
        "err_code",
        "format",
        "os",
        "platform",
        "slot",
        "version",
      ]),
      mr = { 1: "error", 2: "warn", 3: "log", 4: "debug" },
      kr = (function () {
        function t(t, e, r, i) {
          void 0 === e && (e = ""),
            void 0 === r && (r = 3),
            void 0 === i && (i = true),
            (this.label = e),
            (this.level = r),
            (this.reportingEnabled = i),
            (this.win = t);
        }
        return (
          (t.prototype.setLabel = function (t) {
            this.label = t;
          }),
          (t.prototype.setLevel = function (t) {
            this.level = t;
          }),
          (t.prototype.setReporting = function (t) {
            this.reportingEnabled = t;
          }),
          (t.prototype.getLabelString = function () {
            var t = "[KARGO]";
            if (this.label)
              if ((0, Ge.cy)(this.label))
                for (var e = 0; e < this.label.length; e += 1)
                  t += "[".concat(this.label[e], "]");
              else t += "[".concat(this.label, "]");
            return t;
          }),
          (t.prototype.write = function (t, e) {
            var r;
            if ((0, Ge.cy)(e) && 0 !== e.length) {
              var i = Je(this.win),
                n = (0, Ge.xF)(this.win, "Kargo.Config.getGlobalConfig");
              if (
                (n && n() && n().isDebug()) ||
                Ye(i, "krg_debug") ||
                t <= this.level
              ) {
                var o = e;
                4 === t
                  ? (o = [
                      "%c".concat(this.getLabelString()),
                      "color: #FF7500",
                    ].concat(o))
                  : o.unshift(this.getLabelString());
                for (var a = 0; a < o.length; a += 1)
                  o[a] instanceof Error
                    ? (o[a] =
                        (o[a].name ? "".concat(o[a].name, " - ") : "") +
                        o[a].message)
                    : "object" != typeof o[a] ||
                      o[a] instanceof HTMLElement ||
                      (o[a] = (0, Ge.h1)({}, o[a]));
                try {
                  (r = this.win.console)[mr[t]].apply(r, o);
                } catch (t) {}
              }
            }
          }),
          (t.prototype.log = function () {
            for (var t = [], e = 0; e < arguments.length; e++)
              t[e] = arguments[e];
            this.write(3, t);
          }),
          (t.prototype.warn = function () {
            for (var t = [], e = 0; e < arguments.length; e++)
              t[e] = arguments[e];
            this.write(2, t);
          }),
          (t.prototype.error = function () {
            for (var t = [], e = 0; e < arguments.length; e++)
              t[e] = arguments[e];
            this.write(1, t);
          }),
          (t.prototype.debug = function () {
            for (var t = [], e = 0; e < arguments.length; e++)
              t[e] = arguments[e];
            this.write(4, t);
          }),
          (t.prototype.report = function (t, e, r, i) {
            void 0 === r && (r = {}), void 0 === i && (i = !1);
            try {
              if (this.reportingEnabled) {
                var n = {
                  url: Je(this.win),
                  err_code: t,
                  msg: e,
                  platform:
                    ((c = this.win),
                    He(c) ? "MobileWeb" : je(c) ? "TabletWeb" : "Desktop"),
                  os: Be(this.win),
                  browser: Fe(this.win),
                };
                n = (0, Ge.h1)(n, r);
                var o = "https://s3.amazonaws.com/log.kargo.com/adtag.error",
                  a = [];
                Object.keys(n).forEach(function (t) {
                  a.push(
                    ""
                      .concat(encodeURIComponent(t), "=")
                      .concat(encodeURIComponent(n[t]))
                  );
                });
                var s = a.join("&");
                if (
                  (s.length && (o += "?".concat(s)),
                  (o = this.scrubString(o)),
                  hr(this.win, o),
                  !i)
                )
                  new fr(this.win, "ad-tag-error", vr, n).report();
              }
            } catch (t) {
              console.error(t);
            }
            var c;
          }),
          (t.prototype.reportAdMetric = function (t, e) {
            var r = {
              format: t.adFormat,
              version: t.adTagVersion,
              slot: t.adSlot,
            };
            "" !== t.errCode && (r.err_code = t.errCode),
              "gam-iframes" === t.type && (r.gam_iframes = t.gamIframes),
              "sticky-overlap" === t.type &&
                (r.sticky_overlap = t.stickyOverlap),
              "vpaid-clickable" === t.type &&
                (r.vpaid_clickable = t.vpaidClickable);
            var i = ""
                .concat("https://ad-metrics.kargo.com/api/v1/send", "?metric=")
                .concat(t.type, "&value=")
                .concat(t.value),
              n = [];
            Object.keys(r).forEach(function (t) {
              n.push(
                '"'
                  .concat(encodeURIComponent(t), '":"')
                  .concat(encodeURIComponent(r[t]), '"')
              );
            }),
              n.length && (i += "&params={".concat(n, "}")),
              gr(i, this.win, 2e3, !1, function (t) {
                e && e(t);
              });
          }),
          (t.prototype.scrubString = function (t) {
            return t.replace(/%25/g, "");
          }),
          t
        );
      })(),
      br = new kr(qe, "Ad Data"),
      yr = (function () {
        function t() {
          (this.STORE_PREFIX = "krg_"),
            (this.COOKIE_LIFE_TIME = 31536e6),
            (this.data = { expireTime: Date.now() }),
            (this.isCookieStorageEnabled = !1);
        }
        return (
          (t.supportsLocalStorage = function () {
            var t = !1;
            try {
              var e = "__storage_test__";
              qe.localStorage.setItem(e, e),
                qe.localStorage.removeItem(e),
                (t = !0);
            } catch (t) {}
            return t;
          }),
          (t.prototype.enableCookieStorage = function (t) {
            this.isCookieStorageEnabled = t;
          }),
          (t.prototype.getData = function () {
            return this.data.syncIds && delete this.data.syncIds, this.data;
          }),
          (t.prototype.getExpireTime = function () {
            return this.data.expireTime;
          }),
          (t.prototype.saveData = function () {
            (this.data.expireTime = Date.now() + this.DATA_LIFE_TIME),
              t.supportsLocalStorage() && this.updateStorageData(),
              this.isCookieStorageEnabled
                ? this.updateCookieData()
                : this.removeCookieData();
          }),
          (t.prototype.removeData = function () {
            t.supportsLocalStorage() && this.removeStorageData(),
              this.removeCookieData();
          }),
          (t.prototype.clearData = function () {
            (this.data = this.EMPTY_DATA), this.saveData();
          }),
          (t.prototype.isExpired = function () {
            return Date.now() > this.data.expireTime;
          }),
          (t.prototype.fetchData = function () {
            this.isCookieStorageEnabled &&
              (this.fetchCookieData(),
              this.data.segments && delete this.data.segments),
              t.supportsLocalStorage() && this.fetchStorageData(),
              this.isCookieStorageEnabled && this.updateCookieData();
          }),
          (t.prototype.getStoreName = function () {
            return this.STORE_PREFIX + this.STORE_NAME;
          }),
          (t.prototype.encodeDataForStorage = function (t) {
            return btoa(JSON.stringify(t));
          }),
          (t.prototype.decodeDataFromStorage = function (t) {
            var e = null;
            try {
              e = JSON.parse(atob(t));
            } catch (t) {}
            return e;
          }),
          (t.prototype.encodeDataForCookie = function (t) {
            return this.encodeDataForStorage(t);
          }),
          (t.prototype.decodeDataFromCookie = function (t) {
            return this.decodeDataFromStorage(t);
          }),
          (t.prototype.fetchStorageData = function () {
            var t = qe.localStorage.getItem(this.getStoreName());
            if (t) {
              var e = this.decodeDataFromStorage(t);
              e && (this.data = e);
            }
          }),
          (t.prototype.updateStorageData = function () {
            try {
              var t = this.cleanDataForLocalStorage(this.data);
              qe.localStorage.setItem(
                this.getStoreName(),
                this.encodeDataForStorage(t)
              );
            } catch (t) {
              t instanceof Error && br.report("DATA", t.message);
            }
          }),
          (t.prototype.removeStorageData = function () {
            qe.localStorage.removeItem(this.getStoreName());
          }),
          (t.prototype.fetchCookieData = function () {
            var t = ze(qe, this.getStoreName());
            if (t) {
              var e = this.decodeDataFromCookie(t);
              e && (delete e.segments, (this.data = e));
            }
          }),
          (t.prototype.updateCookieData = function () {
            var t = this.cleanDataForCookie(this.data);
            We(
              qe,
              this.getStoreName(),
              this.encodeDataForCookie(t),
              this.COOKIE_LIFE_TIME
            );
          }),
          (t.prototype.removeCookieData = function () {
            We(qe, this.getStoreName(), "", 1);
          }),
          (t.prototype.cleanDataForCookie = function (t) {
            var e = Object.assign({}, t);
            return delete e.segments, e;
          }),
          (t.prototype.cleanDataForLocalStorage = function (t) {
            return t;
          }),
          t
        );
      })(),
      wr = (function () {
        var t = function (e, r) {
          return (
            (t =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (t, e) {
                  t.__proto__ = e;
                }) ||
              function (t, e) {
                for (var r in e)
                  Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
              }),
            t(e, r)
          );
        };
        return function (e, r) {
          if ("function" != typeof r && null !== r)
            throw new TypeError(
              "Class extends value " +
                String(r) +
                " is not a constructor or null"
            );
          function i() {
            this.constructor = e;
          }
          t(e, r),
            (e.prototype =
              null === r
                ? Object.create(r)
                : ((i.prototype = r.prototype), new i()));
        };
      })(),
      _r = (function (t) {
        function e() {
          var e = (null !== t && t.apply(this, arguments)) || this;
          return (
            (e.MAX_LOCALSTORAGE_SEGMENTS = 25),
            (e.UID_STORE_NAME = "".concat(e.STORE_PREFIX, "uid")),
            (e.OLD_STORE_NAME = "".concat(e.STORE_PREFIX, "cerberus")),
            (e.STORE_NAME = "crb"),
            (e.DATA_LIFE_TIME = 864e5),
            (e.EMPTY_DATA = {
              clientId: null,
              tdID: null,
              lexId: null,
              segments: [],
              ktcId: null,
              expireTime: Date.now() + e.DATA_LIFE_TIME,
              lastSyncedAt: null,
              pageViewId: "",
              pageViewTimestamp: null,
              pageViewUrl: null,
              usp: null,
            }),
            (e.data = Object.assign({}, e.EMPTY_DATA)),
            (e.isCookieStorageEnabled = !0),
            e
          );
        }
        return (
          wr(e, t),
          (e.prototype.saveData = function () {
            if (
              (t.prototype.saveData.call(this), this.isCookieStorageEnabled)
            ) {
              var e = {
                clientId: this.data.clientId,
                userId: this.data.lexId,
                optOut: "optout" === this.data.lexId,
              };
              We(
                qe,
                this.UID_STORE_NAME,
                this.encodeUIDCookieData(e),
                this.COOKIE_LIFE_TIME
              );
            }
          }),
          (e.prototype.removeData = function () {
            t.prototype.removeData.call(this),
              We(qe, this.UID_STORE_NAME, "", 1);
          }),
          (e.prototype.clearData = function () {
            if (
              (t.prototype.clearData.call(this), this.isCookieStorageEnabled)
            ) {
              We(
                qe,
                this.UID_STORE_NAME,
                this.encodeUIDCookieData({
                  clientId: null,
                  userId: null,
                  optOut: !1,
                }),
                this.COOKIE_LIFE_TIME
              );
            }
          }),
          (e.prototype.getData = function () {
            return t.prototype.getData.call(this);
          }),
          (e.prototype.encodeDataForCookie = function (t) {
            return encodeURIComponent(
              JSON.stringify({ v: btoa(JSON.stringify(t)) })
            );
          }),
          (e.prototype.encodeUIDCookieData = function (t) {
            return encodeURIComponent(JSON.stringify({ v: t }));
          }),
          (e.prototype.decodeDataFromCookie = function (t) {
            var e = null;
            try {
              e = JSON.parse(atob(JSON.parse(decodeURIComponent(t)).v));
            } catch (t) {}
            return e;
          }),
          (e.prototype.cleanDataForLocalStorage = function (t) {
            var e,
              r = Object.assign({}, t);
            return (
              (r.segments =
                null === (e = r.segments) || void 0 === e
                  ? void 0
                  : e.slice(0, this.MAX_LOCALSTORAGE_SEGMENTS)),
              r
            );
          }),
          (e.prototype.getClientId = function () {
            return this.data.clientId;
          }),
          (e.prototype.setClientId = function (t) {
            (this.data.clientId = t), this.saveData();
          }),
          (e.prototype.getUserId = function () {
            return this.data.lexId;
          }),
          (e.prototype.setUserId = function (t) {
            (this.data.lexId = t), this.saveData();
          }),
          (e.prototype.getSegments = function () {
            return this.data.segments || null;
          }),
          (e.prototype.setSegments = function (t) {
            (this.data.segments = t), this.saveData();
          }),
          (e.prototype.getKtcId = function () {
            return this.data.ktcId;
          }),
          (e.prototype.getTdID = function () {
            return this.data.tdID;
          }),
          (e.prototype.getUSPrivacy = function () {
            return this.data.usp;
          }),
          (e.prototype.setKtcId = function (t) {
            (this.data.ktcId = t), this.saveData();
          }),
          (e.prototype.getLastSyncTime = function () {
            return this.data.lastSyncedAt;
          }),
          (e.prototype.setLastSyncTime = function (t) {
            (this.data.lastSyncedAt = t), this.saveData();
          }),
          (e.prototype.isOptOut = function () {
            return "optout" === this.getUserId();
          }),
          (e.prototype.setOptOut = function (t) {
            t
              ? ((this.data = Object.assign({}, this.EMPTY_DATA)),
                (this.data.lexId = "optout"))
              : "optout" === this.data.lexId && (this.data.lexId = null),
              this.saveData();
          }),
          (e.prototype.setTimeAndUrl = function () {
            (this.data.pageViewTimestamp = Date.now()),
              (this.data.pageViewUrl =
                qe.location.origin + qe.location.pathname),
              this.saveData();
          }),
          (e.prototype.setBrandedTakeover = function (t, e) {
            (this.data.pageViewId = t ? e : ""), this.saveData();
          }),
          (e.prototype.setUSPrivacy = function (t) {
            (this.data.usp = t), this.saveData();
          }),
          (e.prototype.setTdID = function (t) {
            (this.data.tdID = t), this.saveData();
          }),
          e
        );
      })(yr);
    function Ar(t, e) {
      for (
        var r,
          i = t.document.cookie.split(";"),
          n = null,
          o = "".concat(e, "="),
          a = 0;
        a < i.length;
        a += 1
      ) {
        for (; " " === i[a].charAt(0); ) i[a] = i[a].substring(1, i[a].length);
        if (0 === i[a].indexOf(o)) {
          r = i[a].substring(o.length, i[a].length);
          try {
            n = JSON.parse(r);
          } catch (t) {
            n = r;
          }
          return n;
        }
      }
      return null;
    }
    var Cr = function (t, e, r, i) {
        return new (r || (r = Promise))(function (n, o) {
          function a(t) {
            try {
              c(i.next(t));
            } catch (t) {
              o(t);
            }
          }
          function s(t) {
            try {
              c(i.throw(t));
            } catch (t) {
              o(t);
            }
          }
          function c(t) {
            var e;
            t.done
              ? n(t.value)
              : ((e = t.value),
                e instanceof r
                  ? e
                  : new r(function (t) {
                      t(e);
                    })).then(a, s);
          }
          c((i = i.apply(t, e || [])).next());
        });
      },
      Er = function (t, e) {
        var r,
          i,
          n,
          o = {
            label: 0,
            sent: function () {
              if (1 & n[0]) throw n[1];
              return n[1];
            },
            trys: [],
            ops: [],
          },
          a = Object.create(
            ("function" == typeof Iterator ? Iterator : Object).prototype
          );
        return (
          (a.next = s(0)),
          (a.throw = s(1)),
          (a.return = s(2)),
          "function" == typeof Symbol &&
            (a[Symbol.iterator] = function () {
              return this;
            }),
          a
        );
        function s(s) {
          return function (c) {
            return (function (s) {
              if (r) throw new TypeError("Generator is already executing.");
              for (; a && ((a = 0), s[0] && (o = 0)), o; )
                try {
                  if (
                    ((r = 1),
                    i &&
                      (n =
                        2 & s[0]
                          ? i.return
                          : s[0]
                          ? i.throw || ((n = i.return) && n.call(i), 0)
                          : i.next) &&
                      !(n = n.call(i, s[1])).done)
                  )
                    return n;
                  switch (((i = 0), n && (s = [2 & s[0], n.value]), s[0])) {
                    case 0:
                    case 1:
                      n = s;
                      break;
                    case 4:
                      return o.label++, { value: s[1], done: !1 };
                    case 5:
                      o.label++, (i = s[1]), (s = [0]);
                      continue;
                    case 7:
                      (s = o.ops.pop()), o.trys.pop();
                      continue;
                    default:
                      if (
                        !((n = o.trys),
                        (n = n.length > 0 && n[n.length - 1]) ||
                          (6 !== s[0] && 2 !== s[0]))
                      ) {
                        o = 0;
                        continue;
                      }
                      if (3 === s[0] && (!n || (s[1] > n[0] && s[1] < n[3]))) {
                        o.label = s[1];
                        break;
                      }
                      if (6 === s[0] && o.label < n[1]) {
                        (o.label = n[1]), (n = s);
                        break;
                      }
                      if (n && o.label < n[2]) {
                        (o.label = n[2]), o.ops.push(s);
                        break;
                      }
                      n[2] && o.ops.pop(), o.trys.pop();
                      continue;
                  }
                  s = e.call(t, o);
                } catch (t) {
                  (s = [6, t]), (i = 0);
                } finally {
                  r = n = 0;
                }
              if (5 & s[0]) throw s[1];
              return { value: s[0] ? s[1] : void 0, done: !0 };
            })([s, c]);
          };
        }
      },
      xr = (function () {
        function t(t) {
          (this.win = t),
            (this.GVLID = "972"),
            (this.usPrivacyString = ""),
            (this.gdprData = { gdprApplies: 0, tcString: "", eventStatus: "" }),
            (this.gppData = { gppString: "", applicableSections: [] });
        }
        return (
          (t.prototype.fetchConsents = function (t) {
            return Cr(this, void 0, void 0, function () {
              var e, r, i;
              return Er(this, function (n) {
                switch (n.label) {
                  case 0:
                    return (e = this), [4, this.fetchUSPrivacy(t)];
                  case 1:
                    return (
                      (e.usPrivacyString = n.sent()),
                      (r = this),
                      [4, this.fetchGDPR(t)]
                    );
                  case 2:
                    return (
                      (r.gdprData = n.sent()), (i = this), [4, this.fetchGPP(t)]
                    );
                  case 3:
                    return (i.gppData = n.sent()), [2];
                }
              });
            });
          }),
          (t.prototype.getUSPrivacyConsent = function () {
            return this.usPrivacyString;
          }),
          (t.prototype.getGDPRConsent = function () {
            return this.gdprData;
          }),
          (t.prototype.getGPPConsent = function () {
            return this.gppData;
          }),
          (t.prototype.fetchUSPrivacy = function (t) {
            return Cr(this, void 0, void 0, function () {
              var e,
                r,
                i = this;
              return Er(this, function (n) {
                return (
                  (e = new Promise(function (e) {
                    setTimeout(e, t, "");
                  })),
                  (r = new Promise(function (t) {
                    var e = Ar(i.win, "usprivacy");
                    e
                      ? t(e)
                      : i.win.__uspapi
                      ? i.win.__uspapi("getUSPData", 1, function (e, r) {
                          t(r ? e.uspString : "");
                        })
                      : t("");
                  })),
                  [2, Promise.race([e, r])]
                );
              });
            });
          }),
          (t.prototype.fetchGDPR = function (t) {
            return Cr(this, void 0, void 0, function () {
              var e,
                r,
                i,
                n = this;
              return Er(this, function (o) {
                return (
                  (e = { gdprApplies: 0, tcString: "", eventStatus: "" }),
                  (r = new Promise(function (r) {
                    setTimeout(r, t, e);
                  })),
                  (i = new Promise(function (t) {
                    n.win.__tcfapi
                      ? n.win.__tcfapi("ping", 2, function (r) {
                          var i = function (r, i) {
                            i && "tcloaded" === r.eventStatus ? t(r) : t(e);
                          };
                          r && "2" === r.apiVersion
                            ? n.win.__tcfapi("getTCData", 2, i)
                            : n.win.__tcfapi("addEventListener", 2, i);
                        })
                      : t(e);
                  })),
                  [2, Promise.race([r, i])]
                );
              });
            });
          }),
          (t.prototype.fetchGPP = function (t) {
            return Cr(this, void 0, void 0, function () {
              var e,
                r,
                i,
                n = this;
              return Er(this, function (o) {
                return (
                  (e = { gppString: "", applicableSections: [] }),
                  (r = new Promise(function (r) {
                    setTimeout(r, t, e);
                  })),
                  (i = new Promise(function (t) {
                    if (n.win.__gpp) {
                      var r = n.win.__gpp;
                      r("addEventListener", function (i) {
                        if ("error" !== i.pingData.cmpStatus) {
                          if ("stub" !== i.pingData.cmpStatus)
                            if ("1.0" === i.pingData.gppVersion) {
                              var n = r("getGPPData");
                              if (
                                n &&
                                void 0 !== n.gppString &&
                                void 0 !== n.applicableSections
                              )
                                return void t(n);
                              t(e);
                            } else
                              "1.1" === i.pingData.gppVersion
                                ? t({
                                    gppString: i.pingData.gppString,
                                    applicableSections:
                                      i.pingData.applicableSections,
                                  })
                                : t(e);
                        } else t(e);
                      });
                    } else t(e);
                  })),
                  [2, Promise.race([r, i])]
                );
              });
            });
          }),
          (t.prototype.getConsentParams = function () {
            return "gdpr="
              .concat(this.gdprData.gdprApplies, "&gdpr_consent=")
              .concat(this.gdprData.tcString, "&us_privacy=")
              .concat(this.usPrivacyString, "&gpp=")
              .concat(this.gppData.gppString, "&gpp_sid=")
              .concat(this.gppData.applicableSections.join(","));
          }),
          t
        );
      })(),
      Sr = function (t) {
        return t instanceof Error ? t.message : String(t);
      },
      Ir = (function (t) {
        function e() {
          for (var e, r = arguments.length, i = new Array(r), n = 0; n < r; n++)
            i[n] = arguments[n];
          return (
            ((e = t.call.apply(t, [this].concat(i)) || this).name = "Cerberus"),
            (e.errFactory = new l.wm("Cerberus")),
            (e.HOSTNAME = "crb.kargo.com"),
            (e.SEGMENT_HOSTNAME = "cma.kargo.com"),
            (e.RESYNC_IN = 864e5),
            (e.GVLID = "972"),
            (e.blockedDomains = ["doubleclick.net", "googlesyndication.com"]),
            (e.cerberusData = new _r()),
            (e.privacy = new xr(e.win)),
            e
          );
        }
        Ae(e, t);
        var i = e.prototype;
        return (
          (i.doNotTrack = function () {
            return "1" === this.win.navigator.doNotTrack;
          }),
          (i.isOptOut = function () {
            return this.doNotTrack() || this.cerberusData.isOptOut();
          }),
          (i.segmentsEnabled = function () {
            return !!Ar(this.win, "krg_seg");
          }),
          (i.getClientId = function () {
            return this.cerberusData.getClientId();
          }),
          (i.getLexId = function () {
            return this.isOptOut() ? null : this.cerberusData.getUserId();
          }),
          (i.getSegments = function () {
            return this.isOptOut() ? [] : this.cerberusData.getSegments();
          }),
          (i.getTdID = function () {
            return this.cerberusData.getTdID();
          }),
          (i.fetchConsents = (function () {
            var t = (0, V.A)(
              P().mark(function t(e) {
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          return (t.next = 2), this.privacy.fetchConsents(e);
                        case 2:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this
                );
              })
            );
            return function (e) {
              return t.apply(this, arguments);
            };
          })()),
          (i.getUSPrivacy = function () {
            return "" !== this.privacy.getUSPrivacyConsent()
              ? this.privacy.getUSPrivacyConsent()
              : this.cerberusData.getUSPrivacy() || "";
          }),
          (i.gdprApplies = function () {
            return 0 !== this.privacy.getGDPRConsent().gdprApplies;
          }),
          (i.gdprConsent = function () {
            return this.privacy.getGDPRConsent().tcString;
          }),
          (i.gppString = function () {
            return this.privacy.getGPPConsent().gppString;
          }),
          (i.gppApplicableSections = function () {
            return this.privacy.getGPPConsent().applicableSections;
          }),
          (i.handleBrandedTakeover = function (t, e) {
            this.cerberusData.setBrandedTakeover(t, e);
          }),
          (i.restoreData = function () {
            this.cerberusData.fetchData(),
              this.logger.debug(
                "Restored Cookie Data: ",
                this.cerberusData.getData()
              );
          }),
          (i.needsToResync = function () {
            var t = !0,
              e = this.cerberusData.getLastSyncTime(),
              r = "Need to Resync - ";
            return (
              e
                ? this.cerberusData.isExpired()
                  ? this.logger.debug(r + "Expiration Time Reached")
                  : Date.now() - e > this.RESYNC_IN
                  ? this.logger.debug(r + "Over 24 Hours Since Last Sync")
                  : (t = !1)
                : this.logger.debug(r + "No Last Sync Time Set"),
              t
            );
          }),
          (i.shouldUseCookies = function () {
            if (this.win.__krg_cerberus_disable_cookies) return !1;
            var t = this.win.location.hostname.split(".").slice(-2).join(".");
            return !this.blockedDomains.includes(t);
          }),
          (i.load = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e, i, n, o, a, s, c, l;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (
                            (this.cerberusData.enableCookieStorage(
                              this.shouldUseCookies()
                            ),
                            this.restoreData(),
                            this.cerberusData.setTimeAndUrl(),
                            !this.isOptOut())
                          ) {
                            t.next = 7;
                            break;
                          }
                          return (
                            this.logger.debug(
                              "User has Opted Out, Emptying Cookie"
                            ),
                            this.setReady(),
                            t.abrupt("return")
                          );
                        case 7:
                          return (t.next = 9), this.fetchConsents(10);
                        case 9:
                          if (
                            (this.cerberusData.setUSPrivacy(
                              this.privacy.getUSPrivacyConsent()
                            ),
                            this.getClientId() ||
                              this.cerberusData.setClientId(
                                (0, d.lk)(this.win)
                              ),
                            (e = this.getClientId()),
                            this.logger.debug(
                              "Client Id: " + this.getClientId()
                            ),
                            (i = Ar(this.win, "pbjs-unifiedid")))
                          )
                            try {
                              null != (n = JSON.parse(decodeURIComponent(i))) &&
                              n.TDID &&
                              "string" == typeof n.TDID
                                ? this.cerberusData.setTdID(n.TDID)
                                : this.cerberusData.setTdID("");
                            } catch (t) {
                              this.logger.debug("Unable to parse prebid tdID");
                            }
                          else
                            (o = localStorage.getItem(
                              "IXWRAPPERAdserverOrgIp"
                            )) &&
                              (a = r()(JSON.parse(o), "d.data.uids", ""))
                                .length &&
                              (null !=
                                (s = a.find(function (t) {
                                  return "TDID" === t.ext.rtiPartner;
                                })) &&
                              s.id &&
                              "string" == typeof s.id
                                ? this.cerberusData.setTdID(s.id)
                                : this.cerberusData.setTdID(""));
                          if (!this.needsToResync()) {
                            t.next = 27;
                            break;
                          }
                          return (t.next = 18), this.makeSyncRequest(e);
                        case 18:
                          return (
                            (t.prev = 18), (t.next = 21), this.fetchSyncIds(e)
                          );
                        case 21:
                          t.next = 27;
                          break;
                        case 23:
                          (t.prev = 23),
                            (t.t0 = t.catch(18)),
                            (c = Sr(t.t0)),
                            this.logger.warn("Error fetching Sync Ids: " + c);
                        case 27:
                          if (!this.segmentsEnabled()) {
                            t.next = 42;
                            break;
                          }
                          return (
                            (t.prev = 28), (t.next = 31), this.fetchSegments(e)
                          );
                        case 31:
                          t.next = 37;
                          break;
                        case 33:
                          (t.prev = 33),
                            (t.t1 = t.catch(28)),
                            (l = Sr(t.t1)),
                            this.logger.warn("Error fetching Segments: " + l);
                        case 37:
                          return (t.prev = 37), this.setReady(), t.finish(37);
                        case 40:
                          t.next = 44;
                          break;
                        case 42:
                          return this.setReady(), t.abrupt("return");
                        case 44:
                          this.setReadyOnTimeout();
                        case 45:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this,
                  [
                    [18, 23],
                    [28, 33, 37, 40],
                  ]
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          (i.getConsentParams = function () {
            return this.privacy.getConsentParams();
          }),
          (i.makeSyncRequest = (function () {
            var t = (0, V.A)(
              P().mark(function t(e) {
                var r = this;
                return P().wrap(function (t) {
                  for (;;)
                    switch ((t.prev = t.next)) {
                      case 0:
                        return t.abrupt(
                          "return",
                          new Promise(function (t) {
                            var i = r.win.__krg_cerberus_partners
                                ? "&partners=" +
                                  r.win.__krg_cerberus_partners.toString()
                                : "",
                              n = r.win.document.createElement("iframe");
                            (n.style.display = "none"),
                              (n.src =
                                "https://" +
                                r.HOSTNAME +
                                "/api/v1/initsync/" +
                                e +
                                "?" +
                                r.getConsentParams()),
                              (n.src += i),
                              r.logger.debug("Initiating ID syncing..."),
                              n.addEventListener("load", function () {
                                r.win.setTimeout(function () {
                                  _(n);
                                }, 1e3),
                                  t();
                              }),
                              r.win.document.body.appendChild(n);
                          })
                        );
                      case 1:
                      case "end":
                        return t.stop();
                    }
                }, t);
              })
            );
            return function (e) {
              return t.apply(this, arguments);
            };
          })()),
          (i.fetchSyncIds = function (t) {
            var e = this;
            return new Promise(function (r, i) {
              var n =
                "https://" +
                e.HOSTNAME +
                "/api/v1/ids/" +
                t +
                "?" +
                e.getConsentParams();
              e.logger.debug("Fetching Sync IDs...");
              (0, c.Fl)(n, e.win, 0, !0, function (t, n) {
                if (t) i(t);
                else if (n) {
                  var o = null,
                    a = null;
                  try {
                    var s = JSON.parse(atob(n));
                    (o = s.lex_id || s.lexID || null), (a = s.ktcid || null);
                  } catch (t) {}
                  var c = !(!o || !e.getLexId() || o === e.getLexId());
                  o &&
                    e.logger.debug(
                      (c ? "Updated " : "") + "Lex ID from Cerberus: " + o
                    ),
                    e.isOptOut()
                      ? e.logger.debug("User has Opted Out, Emptying Cookie")
                      : a && e.logger.debug("KTC ID: " + a),
                    o && e.cerberusData.setUserId(o),
                    a && e.cerberusData.setKtcId(a),
                    e.cerberusData.setLastSyncTime(Date.now()),
                    r();
                } else i(e.errFactory.errNoResponse());
              });
            });
          }),
          (i.fetchSegments = function (t) {
            var e = this;
            return new Promise(function (r, i) {
              var n =
                "https://" +
                e.SEGMENT_HOSTNAME +
                "/api/v1/segments/" +
                t +
                e.getConsentParams();
              e.logger.debug("Fetching segments...");
              (0, c.Fl)(n, e.win, 0, !0, function (t, n) {
                if (t) i(t);
                else if (n) {
                  var o = null,
                    a = null;
                  try {
                    (o = n.segments || null), (a = n.lexID || null);
                  } catch (t) {}
                  var s = !(!a || !e.getLexId() || a === e.getLexId());
                  a &&
                    e.logger.debug(
                      (s ? "Updated " : "") + "Lex ID from CMA: " + a
                    ),
                    e.isOptOut()
                      ? e.logger.debug("User has Opted Out, Emptying Cookie")
                      : o && e.logger.debug("Segments: " + o),
                    o && e.cerberusData.setSegments(o),
                    a && e.cerberusData.setUserId(a),
                    r();
                } else i(e.errFactory.errNoResponse());
              });
            });
          }),
          e
        );
      })(Ce);
    var Or = {
        getPluginTimeout: function (t) {
          var e = 1500,
            r = (0, o.P3)((0, o.pO)(t), "krg_plugin_timeout"),
            i = parseInt(r, 10);
          return (
            t.__krg_plugin_timeout
              ? (e = t.__krg_plugin_timeout)
              : i && (e = i),
            e
          );
        },
      },
      Rr = (function () {
        function t() {}
        return (
          (t.createPlugin = function (t, e, r) {
            if (e.Kargo) {
              e.Kargo.Plugin = e.Kargo.Plugin || {};
              var i = new n.V(e),
                o = new t(e, i),
                a = o.name
                  .replace(/([A-Z])/g, " $1")
                  .toUpperCase()
                  .trim();
              return (
                i.setLabel(["PLUGIN", r, a]),
                e.Kargo.Plugin[o.name] || (e.Kargo.Plugin[o.name] = o),
                o
                  .load()
                  .then(function () {
                    i.debug("Loaded");
                  })
                  .catch(function (t) {
                    return t;
                  }),
                o
              );
            }
          }),
          (t.loadPlugins = (function () {
            var t = (0, V.A)(
              P().mark(function t(e, r, i) {
                var n, o, a, s, c, l, u, h;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          return (
                            (n = !1),
                            (o = r.getConfig()),
                            (a = []),
                            (s = this.createPlugin(Ee, e, i)) && a.push(s),
                            o.settings.enable_cerberus &&
                              (c = this.createPlugin(Ir, e, i)) &&
                              a.push(c),
                            (l = Or.getPluginTimeout(e)),
                            (u = new Promise(function (t) {
                              e.setTimeout(function () {
                                n ||
                                  ((n = !0),
                                  t(
                                    "Plugin Loading Timed out after " + l + "ms"
                                  ));
                              }, l);
                            })),
                            (h = (0, V.A)(
                              P().mark(function t() {
                                return P().wrap(
                                  function (t) {
                                    for (;;)
                                      switch ((t.prev = t.next)) {
                                        case 0:
                                          return (
                                            (t.prev = 0),
                                            (t.next = 3),
                                            Promise.all(
                                              a.map(function (t) {
                                                return t.onReady();
                                              })
                                            )
                                          );
                                        case 3:
                                          return (
                                            (n = !0),
                                            t.abrupt(
                                              "return",
                                              "All Plugins Loaded"
                                            )
                                          );
                                        case 7:
                                          return (
                                            (t.prev = 7),
                                            (t.t0 = t.catch(0)),
                                            t.abrupt("return", t.t0)
                                          );
                                        case 10:
                                        case "end":
                                          return t.stop();
                                      }
                                  },
                                  t,
                                  null,
                                  [[0, 7]]
                                );
                              })
                            )()),
                            t.abrupt("return", Promise.race([h, u]))
                          );
                        case 10:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this
                );
              })
            );
            return function (e, r, i) {
              return t.apply(this, arguments);
            };
          })()),
          t
        );
      })();
    function Dr(t) {
      var e;
      return !(
        null == (e = t.mraid) ||
        null == e.getVersion ||
        !e.getVersion()
      );
    }
    var Tr = function (t, e) {
        var r = t.filter(function (t) {
          return e.includes(t);
        });
        return r[r.length - 1];
      },
      Vr = function (t) {
        var e = null;
        return (
          Array.isArray(t)
            ? (e = t)
            : ["string", "number", "object", "function"].indexOf(typeof t) >
                -1 &&
              null !== t &&
              (e = [t]),
          e
        );
      },
      Lr = __webpack_require__(7551),
      Pr = [
        "companion_div",
        "sc_background_div",
        "sc_foreground_div",
        "debug",
        "externalId",
        "branchTestString",
        "getAdTimestamp",
        "positionElement",
        "positionLocation",
        "previewMode",
        "sourceElement",
        "sourceWindow",
        "waitForLoad",
        "onCreate",
        "onLoad",
        "onDisplay",
        "onSizeChange",
        "onVisible",
        "onNotVisible",
        "onViewable",
        "onDestroy",
        "platform_version",
      ];
    function Mr(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, i);
      }
      return r;
    }
    var Nr = new l.wm("AdRequest"),
      Fr = (function () {
        function t(t, e, i, n, o, a) {
          var s,
            c,
            l,
            u,
            h = this;
          ((this.win = void 0),
          (this.logger = void 0),
          (this.tracking = void 0),
          (this.slotConfig = void 0),
          (this.source = void 0),
          (this.params = void 0),
          (this.failedResponse = void 0),
          (this.creativeConfig = void 0),
          (this.formatConfig = void 0),
          (this.startTimestamp = void 0),
          (this.isMeasuringViewability = void 0),
          (this.id = void 0),
          (this.creativeId = void 0),
          (this.adFormat = void 0),
          (this.slotType = void 0),
          (this.auctionType = void 0),
          (this.iasTagParams = void 0),
          (this.containerType = null),
          (this.getId = function () {
            return h.id;
          }),
          (this.getSlotConfig = function () {
            return h.slotConfig;
          }),
          (this.getFormatConfig = function () {
            return h.formatConfig;
          }),
          (this.getSource = function () {
            return h.source;
          }),
          (this.getCreativeConfig = function () {
            return h.creativeConfig;
          }),
          (this.getParams = function () {
            return h.params;
          }),
          (this.setFormatConfig = function () {
            "VastMiddleBanner" === h.creativeConfig.format &&
              (h.creativeConfig.format = "OutstreamVideo");
            var t = h.slotConfig.getAllFormatConfigs();
            if (
              (Object.keys(t).forEach(function (t) {
                t.toLowerCase() === h.creativeConfig.format.toLowerCase() &&
                  (h.creativeConfig.format = t);
              }),
              (h.formatConfig = h.slotConfig.getFormatConfig(
                h.creativeConfig.format
              )),
              h.formatConfig)
            ) {
              var e = h.formatConfig.getCreativeConfig() || {},
                r = h.creativeConfig.settings || {},
                i = (0, d.h1)({}, r, e);
              "open" ===
                (h.source && "getKrakenCreativeData" in h.source
                  ? h.source.getKrakenCreativeData().auctionType
                  : h.auctionType) || "advertisement" === r.branding
                ? (i.branding = "advertisement")
                : e.branding ||
                  (i.branding && i.branding !== Lr._S) ||
                  (i.branding = Lr.qr[h.creativeConfig.format] || Lr._S),
                (h.containerType || Dr(h.win)) &&
                  "mobilized" === i.branding &&
                  (i.branding = Lr._S),
                e.wrapper_fill &&
                  "wrapper_fill" in r &&
                  (i.wrapper_fill = r.wrapper_fill),
                (h.creativeConfig.settings = i);
            } else
              h.logger.debug(
                "Format " + h.creativeConfig.format + " not set in slot config!"
              );
          }),
          (this.getCreativeConfigSource = function () {
            if (
              ((h.creativeConfig.source = {}),
              h.source && "getKrakenCreativeData" in h.source)
            ) {
              var t,
                e = h.source.getKrakenCreativeData();
              e.krgImpId && (h.id = e.krgImpId),
                (h.creativeConfig.source = e),
                (h.creativeConfig.source.tag = "adtag"),
                (h.creativeConfig.source.type =
                  null == (t = h.source) ? void 0 : t.getType());
            }
          }),
          (this.setCreativeConfigCSS = function () {
            (h.creativeConfig.css = h.slotConfig.getCss() || ""),
              h.formatConfig &&
                h.formatConfig.getCss &&
                h.formatConfig.getCss() &&
                (h.formatConfig.isIgnoreSlotCss &&
                h.formatConfig.isIgnoreSlotCss()
                  ? (h.creativeConfig.css = h.formatConfig.getCss())
                  : (h.creativeConfig.css += h.formatConfig.getCss()));
          }),
          (this.fetchFromSourceTracking = function () {
            if (h.slotConfig && h.slotConfig.getId()) {
              var t,
                e,
                r = {
                  format: h.creativeConfig.format,
                  creativeSource: h.creativeConfig.sourceName,
                  creativeId: h.creativeConfig.creativeId,
                  line_item_id:
                    null == (t = h.creativeConfig.source)
                      ? void 0
                      : t.biddableId,
                  deal_id:
                    null == (e = h.creativeConfig.source) ? void 0 : e.dealId,
                };
              h.trackEvent("response", h.slotConfig.getId(), r);
            }
          }),
          (this.getCreativeConfigFormat = function (t) {
            var e = t.format,
              r =
                "Format '" +
                t.format +
                "' not set in '" +
                t.slot +
                "' slot config!";
            if (!h.creativeConfig.format) {
              r = "Cannot determine format from ad response";
              var i = (h.creativeConfig.content || "").match(
                /"format":\s*"([\s\S]*?)"/
              );
              e = (i && i[1]) || h.getFormatFromSlot();
            }
            return h.logger.warn(r), { creativeConfigFormat: e, msg: r };
          }),
          (this.win = t),
          (this.logger = e),
          (this.tracking = i),
          (this.slotConfig = n),
          (this.source = o),
          (this.params = a),
          (this.failedResponse = !1),
          (this.creativeConfig = null),
          (this.formatConfig = null),
          (this.startTimestamp = Date.now()),
          (this.isMeasuringViewability = !1),
          (this.id = r()(
            this.params,
            "kraken.krg_imp_id",
            "00000000-" +
              (Math.floor(9e3 * Math.random()) + 1e3) +
              "-0000-0000-000000000000"
          )),
          (this.creativeId =
            r()(this.params, "kraken.id", "") ||
            r()(this.params, "kraken.creative_id", "")),
          (this.adFormat = r()(this.params, "kraken.format", "")),
          (this.slotType = r()(this.params, "kraken.slot_type", "")),
          (this.auctionType = r()(this.params, "kraken.auction_type", "")),
          (this.iasTagParams = r()(this.params, "kraken.ias_tag_params", null)),
          null == (s = this.source) || s.setImpressionId(this.id),
          null == (c = this.source) ||
            c.setExtraMacrosCreativeId(this.creativeId, this.auctionType),
          null == (l = this.source) || l.setExtraMacrosAdFormat(this.adFormat),
          this.source) &&
            (this.source.branchTestString =
              null == (u = this.params) ? void 0 : u.branchTestString);
        }
        var e = t.prototype;
        return (
          (e.generateCreativeConfig = function () {
            var t = this;
            !this.creativeConfig &&
              this.source &&
              ((this.creativeConfig = this.source.getCreativeData()),
              this.isMeasuringViewability &&
                (this.creativeConfig.isMeasuringViewability =
                  this.isMeasuringViewability),
              null !== this.iasTagParams &&
                (this.creativeConfig.iasTagParams = this.iasTagParams),
              this.slotConfig &&
                ((this.creativeConfig.slot = this.slotConfig.getId()),
                this.creativeConfig.format && this.setFormatConfig()),
              this.getCreativeConfigSource(),
              (this.creativeConfig.id = this.id),
              (this.creativeConfig.slotType = this.slotType),
              this.setCreativeConfigCSS(),
              Pr.forEach(function (e) {
                t.params &&
                  void 0 !== t.params[e] &&
                  (t.creativeConfig[e] = t.params[e]);
              }));
          }),
          (e.fail = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e, r, i;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          return (
                            (r = new me(
                              (null == (e = this.params)
                                ? void 0
                                : e.sourceWindow) || this.win
                            )),
                            (t.prev = 1),
                            (t.next = 4),
                            r.detectEnvironment()
                          );
                        case 4:
                          if (
                            (null !== t.sent && r.noAdToDisplay(),
                            this.slotConfig &&
                              this.slotConfig.getFailedRequestFunc())
                          )
                            try {
                              (0, d.zH)(
                                this.win,
                                this.slotConfig.getFailedRequestFunc()
                              );
                            } catch (t) {
                              (i = "Error in Slot Fail Callback:"),
                                this.logger.error(i, t),
                                ue(
                                  this.logger,
                                  Rt(t, X),
                                  i +
                                    " " +
                                    (t instanceof Error
                                      ? t.name + " - " + t.message
                                      : String(t)),
                                  {
                                    slot: this.slotConfig
                                      ? this.slotConfig.getId()
                                      : "unknown",
                                    version: "10.9.0-kat-7484-test",
                                  }
                                );
                            }
                          (this.failedResponse = !0), (t.next = 13);
                          break;
                        case 10:
                          (t.prev = 10),
                            (t.t0 = t.catch(1)),
                            this.logger.error(t.t0);
                        case 13:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this,
                  [[1, 10]]
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          (e.fetchResponse = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (
                            !this.slotConfig ||
                            !this.slotConfig.getConditionalCheckFunc()
                          ) {
                            t.next = 3;
                            break;
                          }
                          return (t.next = 3), this.runConditionalCheck();
                        case 3:
                          if (this.source) {
                            t.next = 7;
                            break;
                          }
                          return (t.next = 6), this.fail();
                        case 6:
                          throw Nr.errNoResponse("", "no source");
                        case 7:
                          return (
                            (t.prev = 7),
                            (t.next = 10),
                            this.source.fetchResponse()
                          );
                        case 10:
                          t.next = 15;
                          break;
                        case 12:
                          throw (
                            ((t.prev = 12),
                            (t.t0 = t.catch(7)),
                            Nr.errNoResponse(
                              "source",
                              t.t0 instanceof Error
                                ? t.t0.message
                                : String(t.t0)
                            ))
                          );
                        case 15:
                          return (t.next = 17), this.detectContainer();
                        case 17:
                          if (
                            (this.generateCreativeConfig(),
                            this.fetchFromSourceTracking(),
                            this.formatConfig)
                          ) {
                            t.next = 22;
                            break;
                          }
                          return (t.next = 22), this.handleFormatConfig();
                        case 22:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this,
                  [[7, 12]]
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          (e.detectContainer = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e, r;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          return (
                            (t.prev = 0),
                            (r = new me(
                              (null == (e = this.params)
                                ? void 0
                                : e.sourceWindow) || this.win
                            )),
                            (t.next = 4),
                            r.detectEnvironment()
                          );
                        case 4:
                          (this.containerType = t.sent), (t.next = 10);
                          break;
                        case 7:
                          (t.prev = 7),
                            (t.t0 = t.catch(0)),
                            this.logger.error(t.t0);
                        case 10:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this,
                  [[0, 7]]
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          (e.runConditionalCheck = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (
                            ((t.prev = 0),
                            !1 !==
                              (0, d.zH)(
                                this.win,
                                this.slotConfig.getConditionalCheckFunc()
                              ))
                          ) {
                            t.next = 6;
                            break;
                          }
                          return (t.next = 5), this.fail();
                        case 5:
                          throw Nr.errNew(
                            "Ad Request failed Conditional Check"
                          );
                        case 6:
                          t.next = 14;
                          break;
                        case 8:
                          throw (
                            ((t.prev = 8),
                            (t.t0 = t.catch(0)),
                            (e = "Error in Slot Conditional Check:"),
                            this.logger.error(e, t.t0),
                            ue(
                              this.logger,
                              Rt(t.t0, $),
                              e +
                                " " +
                                (t.t0 instanceof Error
                                  ? t.t0.name + " - " + t.t0.message
                                  : String(t.t0)),
                              {
                                slot: this.slotConfig
                                  ? this.slotConfig.getId()
                                  : "unknown",
                                version: "10.9.0-kat-7484-test",
                              }
                            ),
                            t.t0)
                          );
                        case 14:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this,
                  [[0, 8]]
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          (e.handleFormatConfig = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e, r, i;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          return (
                            (e = this.getCreativeConfigFormat(
                              this.creativeConfig
                            )),
                            (r = e.creativeConfigFormat),
                            (i = e.msg),
                            (t.next = 3),
                            this.fail()
                          );
                        case 3:
                          if (r) {
                            t.next = 7;
                            break;
                          }
                          throw Nr.errNew(i);
                        case 7:
                          this.creativeConfig.format = r;
                        case 8:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          (e.getFormatFromSlot = function () {
            var t = this.slotConfig.getAllFormatConfigs(),
              e = Object.keys(t),
              r = this.creativeConfig.settings;
            return r && (r.vast_xml || r.vast_url)
              ? Tr(Lr.ZP, e)
              : this.creativeConfig.content
              ? Tr(Lr.im, e)
              : void 0;
          }),
          (e.trackEvent = function (t, e, r) {
            var i;
            void 0 === r && (r = {});
            var n = (function (t) {
              for (var e = 1; e < arguments.length; e++) {
                var r = null != arguments[e] ? arguments[e] : {};
                e % 2
                  ? Mr(Object(r), !0).forEach(function (e) {
                      (0, T.A)(t, e, r[e]);
                    })
                  : Object.getOwnPropertyDescriptors
                  ? Object.defineProperties(
                      t,
                      Object.getOwnPropertyDescriptors(r)
                    )
                  : Mr(Object(r)).forEach(function (e) {
                      Object.defineProperty(
                        t,
                        e,
                        Object.getOwnPropertyDescriptor(r, e)
                      );
                    });
              }
              return t;
            })({ impId: this.id }, r);
            try {
              var o,
                a = ne
                  .getInstance()
                  .getExpObject(
                    this.id,
                    null == (o = this.creativeConfig) ? void 0 : o.format
                  );
              a && (n.exp = a);
            } catch (t) {
              this.logger.error("Experiment tracking failed:", t);
            }
            var s = se(null == (i = this.params) ? void 0 : i.branchTestString);
            s && (n.branchTest = s), this.tracking.trackEvent(t, e, n);
          }),
          t
        );
      })();
    var Br = __webpack_require__(6096),
      Ur = __webpack_require__(8509);
    function Hr(t, e) {
      return (0, Ur.xl)(e) && !t.settings.forceResponsive;
    }
    var jr,
      zr,
      Wr = (function () {
        function t() {}
        return (
          (t.getSupportedPMPFormats = function (t) {
            var e = [];
            return (
              Object.keys(t).forEach(function (r) {
                t[r] &&
                  t[r].isApprovedForPMP &&
                  t[r].isApprovedForPMP() &&
                  e.push(r);
              }),
              e
            );
          }),
          (t.getApprovedOpenFormatsPerSlot = function (t, e) {
            for (var r = [], i = 0; i < e.length; i += 1)
              t.includes(e[i]) && r.push(e[i]);
            return r;
          }),
          (t.checkIfSidebarSlot = function (t, e, r) {
            var i;
            if (!(r ? Hr(r, e) : (0, Ur.xl)(e)) || !t) return !1;
            var n = !1,
              o = null == (i = I(e)) ? void 0 : i.getSlotConfig;
            if (o) {
              var a = o(t);
              if (a) {
                var s = a.getAllFormatConfigs();
                n = Object.keys(s).some(function (t) {
                  return Lr.nr.includes(t);
                });
              }
            }
            return n;
          }),
          t
        );
      })(),
      Kr = ".kargo-ad-content",
      qr = "kargo-ad-hidden",
      Gr = ".kargo-creative",
      Yr = {
        debug: !1,
        localId: null,
        id: null,
        type: null,
        format: null,
        execution: null,
        css: null,
        vendor: null,
        placement: null,
        slot: null,
        content: null,
        prefix: null,
        suffix: null,
        positionElement: window.document.body,
        positionLocation: "after",
        isMeasuringViewability: !1,
        source: {},
        sourceElement: null,
        sourceWindow: null,
        externalId: null,
        onCreate: null,
        onLoad: null,
        onDisplay: null,
        onSizeChange: null,
        onVisible: null,
        onNotVisible: null,
        onViewable: null,
        onClose: null,
        onDestroy: null,
        settings: {},
      };
    !(function (t) {
      (t.LINE_ITEM = "{DFP_LINE_ITEM}"), (t.CREATIVE = "{DFP_CREATIVE}");
    })(jr || (jr = {})),
      (function (t) {
        (t.CREATIVE = "{KARGO_CREATIVE}"),
          (t.FORMAT = "{KARGO_FORMAT}"),
          (t.SEQUENCE = "{SEQUENCE}");
      })(zr || (zr = {}));
    var Jr,
      Zr = "kit-version=",
      $r = "NO_BILLABLE";
    !(function (t) {
      (t.KRAKEN = "kraken"),
        (t.HEPHAESTUS = "hephaestus"),
        (t.SSP = "ssp"),
        (t.PASSBACK = "passback"),
        (t.EMPTY = ""),
        (t.HTML = "html"),
        (t.OVERRIDE_URL = "overrideUrl");
    })(Jr || (Jr = {}));
    function Xr(t, e) {
      var r = Kr;
      return (
        "Banner" === t && (r = ".kargo-ad-banner"),
        "Hover" === t && (r = ".kargo-ad-hover"),
        e ? e.querySelector(r) : null
      );
    }
    function Qr(t, e) {
      if (!t) return {};
      var i,
        n,
        o = t.id,
        a = t.format,
        s = (t.creativeId, t.sourceName);
      if (t.source) {
        var c,
          l =
            "direct" ===
            (null == (c = t.source) || null == (c = c.auctionType)
              ? void 0
              : c.toLowerCase());
        (i = t.source.dealId || ""), (n = l ? t.source.biddableId : "");
      }
      var u = Object.assign(
        {
          format: a,
          impId: o,
          creativeSource: s,
          creativeTemplateId: r()(
            t,
            "settings.native.creativeOptimizer.template_id",
            ""
          ),
          deal_id: i,
          line_item_id: n,
        },
        {},
        e
      );
      try {
        var h = ne.getInstance().getExpObject(o, a);
        h && (u.exp = h);
      } catch (t) {
        console.error("Experiment tracking failed:", t);
      }
      var d = se(t.branchTestString);
      return d && (u.branchTest = d), u;
    }
    function ti(t, e, r, i, n) {
      void 0 === n && (n = {});
      var o = Qr(r, n);
      i.trackEvent(t, e, o);
    }
    function ei(t) {
      return t ? t.querySelector(".kargo-creative") : null;
    }
    function ri(t) {
      for (
        var e = t.querySelector(".kargo-ad-content").getElementsByTagName("*"),
          r = 0;
        r < e.length;
        r += 1
      ) {
        var i = e[r];
        1 === i.offsetWidth &&
          1 === i.offsetHeight &&
          null === i.getAttribute("data-krg-tracker") &&
          (i.setAttribute("data-krg-tracker", ""),
          (i.style.position = "absolute"),
          (i.style.visibility = "hidden"),
          (i.style.left = "-9999px"),
          (i.style.top = "0px"));
      }
    }
    function ii(t, e) {
      var r,
        i = null == (r = I(e)) ? void 0 : r.getSlotConfig;
      if (i) {
        var n = i(t);
        if (n && n.allowsResponsiveCreatives && !n.allowsResponsiveCreatives())
          return !0;
      }
      return !1;
    }
    function ni(t) {
      var e = t.match(/<Extension\s+[^>]*?type="kargo-outstream"[^>]*?>/);
      return !!e && e.length > 0;
    }
    var oi = {
        getVisibilityCheckElement: Xr,
        getContentElement: function (t) {
          var e = Kr;
          return t ? t.querySelector(e) : null;
        },
        shouldAddIAS: function (t) {
          if (t) {
            if (t.type === Jr.HTML) return !1;
            if (t && "open" === t.auctionType) return !1;
          }
          return !0;
        },
        getTrackingParams: Qr,
        trackEvent: ti,
        hideThirdPartyTrackers: ri,
        validateConfig: function (t, e) {
          var n = (0, d.h1)({}, t);
          if (n.content && n.content.indexOf("celtra-ad") > -1) {
            var o = '<div class="celtra-ad-v3">';
            if (n.content.indexOf(o) > -1) {
              if (n.id) {
                var a =
                    "\n\t\x3c!-- passthroughParameters[impressionId] = raw " +
                    n.id +
                    " --\x3e",
                  s = "\n\t\x3c!-- externalSessionId = raw " + n.id + " --\x3e";
                n.content = n.content.replace(o, o + a + s);
              }
              if (r()(n, "source.kargo.creativeId")) {
                var c = n.source.kargo.creativeId,
                  l =
                    "\x3c!-- passthroughParameters[creativeId] = raw " +
                    c +
                    " --\x3e";
                -1 === n.content.indexOf("passthroughParameters[creativeId]") &&
                  null != c &&
                  (n.content = (0, d._o)(
                    n.content,
                    l,
                    n.content.indexOf(o) + 26
                  ));
              }
              if ((n.source || {}).type) {
                var u = n.source.type.toUpperCase(),
                  h =
                    "\x3c!-- passthroughParameters[network] = raw " +
                    u +
                    " --\x3e";
                null != u &&
                  (n.content = (0, d._o)(
                    n.content,
                    h,
                    n.content.indexOf(o) + 26
                  ));
              }
              if (n.idAlpha) {
                var p =
                  "\x3c!-- passthroughParameters[creativeIdAlpha] = raw " +
                  n.idAlpha +
                  " --\x3e";
                -1 ===
                  n.content.indexOf("passthroughParameters[creativeIdAlpha]") &&
                  (n.content = (0, d._o)(
                    n.content,
                    p,
                    n.content.indexOf(o) + 26
                  ));
              }
              (n.content = n.content.replace(
                /'preferredClickThroughWindow':'.*?'/,
                "'preferredClickThroughWindow':'new'"
              )),
                (n.content = n.content.replace(
                  /'externalAdServer':'.*?'/,
                  "'externalAdServer':'DFPKargo'"
                ));
            }
          }
          var g = r()(n, "positionElement.ownerDocument.defaultView", null);
          if (g && g !== e) {
            var f = (0, i.ZR)(g);
            f &&
              ((f.style.display = "none"),
              (n.positionElement = f),
              (n.positionLocation = "before"));
          } else
            n.positionElement &&
              !m(n.positionElement) &&
              ((n.positionElement = n.positionElement.ownerDocument.body),
              (n.positionLocation = "prepend"));
          return n;
        },
        preventResponsive: ii,
        hideSourceIframe: function (t) {
          if (t) {
            var e = (0, i.ZR)(t);
            e &&
              ((e.style.display = "block"),
              (e.style.visibility = "hidden"),
              (e.style.height = "1px"));
          }
        },
        addPrefixAndSuffix: function (t, e, r, i) {
          return (
            e &&
              (i.debug("Creative - adding prefix to creative content: " + e),
              (t = e + " " + t)),
            r &&
              (i.debug("Creative - adding suffix to creative content: " + r),
              (t = t + " " + r)),
            t
          );
        },
        isFabrikOutstreamMarkup: ni,
      },
      ai = (function () {
        function t() {}
        return (
          (t.getDimensionsByFormat = function (t) {
            var e = Lr.hR.filter(function (e) {
                return e.name === t;
              })[0],
              i = r()(e, "size.w", null),
              n = r()(e, "size.h", null);
            return i && n ? e.size : { w: 300, h: 250 };
          }),
          (t.getFormatFromSize = function (t) {
            if (!t) return null;
            var e = null,
              i = t.split("x"),
              n = i[0],
              o = i[1];
            return (
              Lr.hR.forEach(function (t) {
                var i = r()(t.size, "w", null),
                  a = r()(t.size, "h", null);
                i === Number(n) && a === Number(o) && (e = t.name);
              }),
              e
            );
          }),
          (t.determineFormat = function (e, r, i, n) {
            var o = i.vast_url;
            if (i.vast_xml || o) {
              var a = Wr.getApprovedOpenFormatsPerSlot(n, Lr.ZP);
              if (a.includes(Br.B.FABRIK_OUTSTREAM)) {
                if (ni(e)) return Br.B.FABRIK_OUTSTREAM;
                var s = a.indexOf(Br.B.FABRIK_OUTSTREAM);
                a.splice(s, 1);
              }
              return a[0];
            }
            var c = t.getFormatFromSize(r),
              l = Wr.getApprovedOpenFormatsPerSlot(n, Lr.un);
            return c && l.includes(c) ? c : l[0];
          }),
          (t.getFormatByInhubID = function (t) {
            var e,
              r = parseInt("" + t, 10);
            return (
              (null ==
              (e = Lr.hR.filter(function (t) {
                return t.id === r;
              })[0])
                ? void 0
                : e.name) || null
            );
          }),
          (t.isVideoFormat = function (t) {
            return Lr.t3.indexOf(t) >= 0;
          }),
          (t.isVideoBannerFormat = function (t) {
            return Lr.gj.indexOf(t) >= 0;
          }),
          (t.isVastFormat = function (t) {
            return Lr.GW.indexOf(t) >= 0;
          }),
          (t.isKapVideoFormat = function (t) {
            return Lr.sf.indexOf(t) >= 0;
          }),
          (t.isDesktopFormat = function (t) {
            return Lr._G.indexOf(t) >= 0;
          }),
          (t.isTallFormat = function (t) {
            return Lr.RM.indexOf(t) >= 0;
          }),
          (t.isRmResponsiveFormat = function (t) {
            return Lr.ak.indexOf(t) >= 0;
          }),
          (t.isUnresponsiveFormat = function (t) {
            return Lr.Zz.indexOf(t) >= 0;
          }),
          (t.getFormatByShortname = function (t) {
            t = t || "";
            var e = Lr.hR.filter(function (e) {
              return e.name.toLowerCase() === t.toLowerCase();
            });
            return e.length ? e[0] : null;
          }),
          t
        );
      })();
    var si = __webpack_require__(8542);
    function ci(t, e, r) {
      if (t.includes(Zr)) {
        var i = (t.match(/data-ad-format="(.*?)"/) || [])[1];
        i
          ? ((e.creativeData.format = i),
            e.setExtraMacrosAdFormat(e.creativeData.format))
          : e.errorReporter.report(U, "No Format in KIT");
        var n = (t.match(/data-ad-execution="(.*?)"/) || [])[1];
        n
          ? (e.creativeData.execution = n.toLowerCase())
          : e.errorReporter.report(U, "No Execution in KIT");
        var o = (t.match(/data-ad-settings="(.*?)"/) || [])[1];
        if (o)
          try {
            r.settings = JSON.parse(window.atob(o));
          } catch (t) {
            var a;
            (a = t instanceof Error ? t.message : JSON.stringify(t)),
              e.errorReporter.report(U, a);
          }
      }
    }
    function li(t, e) {
      e &&
        ((t.kargoCreative = !0),
        e.format &&
          ((t.creativeData.format = e.format),
          t.setExtraMacrosAdFormat(t.creativeData.format)),
        e.execution && (t.creativeData.execution = e.execution.toLowerCase()),
        e.idAlpha && (t.creativeData.idAlpha = e.idAlpha),
        e.settings && (0, d.h1)(t.creativeData.settings, e.settings),
        e.sid && (t.kargoCreativeData.sid = e.sid),
        e.creativeId && (t.kargoCreativeData.creativeId = e.creativeId),
        e.vendor && e.vendor.id && (t.kargoCreativeData.vendorId = e.vendor.id),
        e.vendor &&
          e.vendor.code &&
          (t.kargoCreativeData.vendor = e.vendor.code),
        e.placement &&
          e.placement.type &&
          ((t.kargoCreativeData.placement = e.placement.type),
          (t.creativeData.placementType = e.placement.type)),
        e.asdata &&
          e.asdata.verid &&
          (t.kargoCreativeData.verticals = e.asdata.verid),
        e.settings &&
          e.settings.creative_origin &&
          (t.kargoCreativeData.creativeOrigin = e.settings.creative_origin));
    }
    function ui(t, e) {
      !(function (t, e) {
        var r = e.trim();
        return ["<VAST", "&lt;VAST", "<?xml", "&lt;?xml"].reduce(function (
          t,
          e
        ) {
          return t || 0 === r.indexOf(e);
        },
        !1);
      })(0, e)
        ? (t.creativeData.content = e)
        : (t.creativeData.settings.vast_xml = e);
    }
    function hi(t, e) {
      return di.apply(this, arguments);
    }
    function di() {
      return (di = (0, V.A)(
        P().mark(function t(e, r) {
          var i, n, o, a, s, c, l, u;
          return P().wrap(function (t) {
            for (;;)
              switch ((t.prev = t.next)) {
                case 0:
                  ci(e, r, (i = {})),
                    (n = e.replace(/\r/g, "")),
                    0 === Object.keys(i).length &&
                      ((n = r.replaceMacroValues(n)),
                      (i = y(n, "krg_ad_info"))),
                    !i &&
                      n.includes('""krg_ad_info""') &&
                      ((o =
                        "Extra quotes found in creative. Trafficking error - creative may not display"),
                      r.logger.warn(o),
                      (a = r.rawResponse.id || r.rawResponse.creative_id),
                      r.errorReporter.report(Ct, o, { creative: a })),
                    (s = y(n, "settings_overrides")),
                    (c = A(n, "krg_ad_type")),
                    (l = A(c, "krg_ad_info")),
                    (u = A(l, "settings_overrides")),
                    li(r, i),
                    s && (0, d.h1)(r.creativeData.settings, s),
                    (u = r.replaceMacroValues(u)),
                    ui(r, u);
                case 13:
                case "end":
                  return t.stop();
              }
          }, t);
        })
      )).apply(this, arguments);
    }
    function pi(t, e) {
      return !!t && t.toLowerCase() !== e.toLowerCase();
    }
    function gi(t) {
      return (
        Object.keys(t)
          .filter(function (e) {
            return null === t[e] || void 0 === t[e];
          })
          .forEach(function (e) {
            return delete t[e];
          }),
        t
      );
    }
    var fi = "https://",
      vi = (function () {
        function t() {}
        return (
          (t.getPageUrl = function () {
            return fi + window.location.hostname + window.location.pathname;
          }),
          (t.getEncodedPageUrl = function () {
            return encodeURIComponent(
              fi + window.location.hostname + window.location.pathname
            );
          }),
          t
        );
      })(),
      mi = [
        "{DEVICE_ID}",
        "{DEVICE_ID_TYPE}",
        "{DEVICE_IP}",
        "{USER_AGENT}",
        "{PLATFORM}",
        "{DEVICE_OS_VERSION}",
        "{DEVICE_MODEL}",
        "{ATT}",
        "{BUNDLE_ID}",
        "{APP_NAME}",
        "{APP_STORE_URL}",
        "{GEO_COUNTRY}",
        "{GEO_REGION}",
        "{GEO_DMA}",
        "{CAMPAIGN_ID}",
        "{CREATIVE_TYPE}",
        "{AD_TYPE}",
        "{AD_PLATFORM}",
        "{CLICK_ID}",
        "{CREATIVE_SIZE}",
      ],
      ki = { in_app: "in_app", mobile_web: "m_web" };
    function bi(t) {
      return !!t && "in_app" === t["{AD_PLATFORM}"];
    }
    function yi(t) {
      var e = t.device,
        r = void 0 === e ? {} : e,
        i = t.app,
        n = void 0 === i ? {} : i,
        o = t.geo,
        a = void 0 === o ? {} : o,
        s = t.ad,
        c = void 0 === s ? {} : s,
        l = {
          "{DEVICE_ID}": r.id,
          "{DEVICE_ID_TYPE}": r.id_type,
          "{DEVICE_IP}": r.ip,
          "{USER_AGENT}": r.user_agent,
          "{PLATFORM}": r.os,
          "{DEVICE_OS_VERSION}": r.os_version,
          "{DEVICE_MODEL}": r.model,
          "{ATT}": r.att,
          "{BUNDLE_ID}": n.bundle,
          "{APP_NAME}": n.name,
          "{APP_STORE_URL}": n.store_url,
          "{GEO_COUNTRY}": a.country,
          "{GEO_REGION}": a.region,
          "{GEO_DMA}": a.dma,
          "{CAMPAIGN_ID}": c.campaign_id,
          "{CREATIVE_TYPE}": c.format_shortname,
          "{AD_TYPE}": c.media_type,
          "{AD_PLATFORM}": t.environment && ki[t.environment],
          "{CLICK_ID}": t.krg_imp_id,
          "{CREATIVE_SIZE}": t.size,
        },
        u = {};
      return (
        Object.keys(l).forEach(function (t) {
          var e = l[t];
          null != e && "" !== e && (u[t] = String(e));
        }),
        u
      );
    }
    function wi(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, i);
      }
      return r;
    }
    function _i(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2
          ? wi(Object(r), !0).forEach(function (e) {
              (0, T.A)(t, e, r[e]);
            })
          : Object.getOwnPropertyDescriptors
          ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
          : wi(Object(r)).forEach(function (e) {
              Object.defineProperty(
                t,
                e,
                Object.getOwnPropertyDescriptor(r, e)
              );
            });
      }
      return t;
    }
    var Ai,
      Ci = /\?[^?#"'\s<>\]`\\]*/g,
      Ei = /^[A-Za-z0-9._-]+$/,
      xi = /(&amp;|&)/,
      Si = (function () {
        function t(t, e, i) {
          void 0 === i && (i = ""),
            (this.win = void 0),
            (this.logger = void 0),
            (this.slotId = void 0),
            (this.macroConfig = void 0),
            (this.cachebuster = void 0),
            (this.win = t),
            (this.logger = e),
            (this.slotId = i);
          var n = r()(this.win, "Kargo.Plugin.Cerberus");
          (this.macroConfig = {
            slotId: i,
            impressionId: "",
            creativeId: "",
            creativeIdAlpha: "",
            creativeIdRtb: "",
            dealId: "",
            lineItemId: "",
            lexId: (n && n.getLexId()) || "",
            hostname: r()(this.win, "location.hostname") || "",
            adFormat: "",
          }),
            (this.cachebuster = (Date.now() * Math.random())
              .toString()
              .replace(".", ""));
        }
        var e = t.prototype;
        return (
          (e.replaceMacroWhenValid = function (t, e, r) {
            return r ? t.replace(e, r) : t;
          }),
          (e.buildTrackerUrl = function (t, e, r) {
            var i = this,
              n = t,
              o = "" + (Lr.$4[e.format] ? Lr.$4[e.format].id : null),
              a = {
                lineItem: e.dfpLineItem || null,
                creative: e.dfpCreative || null,
              },
              s = e.creativeId || null,
              c = e.sequenceKey || null;
            return (
              [
                [jr.LINE_ITEM, a.lineItem],
                [jr.CREATIVE, a.creative],
                [zr.FORMAT, o],
                [zr.CREATIVE, s],
                [zr.SEQUENCE, c],
                ["{AD_TAG_VERSION}", "10.9.0-kat-7484-test"],
                ["{CONTEXT}", r || null],
              ].forEach(function (t) {
                var e = t[0],
                  r = t[1];
                n = i.replaceMacroWhenValid(n, e, r);
              }),
              n
            );
          }),
          (e.replaceAllMacros = function (t, e) {
            var r = this;
            if (
              ((this.macroConfig = _i(_i({}, gi(this.macroConfig)), gi(e))),
              "string" == typeof t && t.length)
            ) {
              t = this.checkLegacyDFPImg(t);
              var i = _i(_i({}, this.getDfpMacros()), this.getKargoMacros());
              t &&
                "string" == typeof t &&
                i &&
                Object.keys(i).forEach(function (e) {
                  var n = i[e]();
                  t = r.replaceMacroHelper(t, e, n);
                });
              var n = this.macroConfig.inAppMacros;
              bi(n) && (t = this.replaceInAppMacros(t, n));
            }
            return t;
          }),
          (e.replaceInAppMacros = function (t, e) {
            var r = mi.filter(function (e) {
              return t.indexOf(e) >= 0;
            });
            if (!r.length) return t;
            var i = r.filter(function (t) {
              return !e[t];
            });
            return (
              i.length && (t = this.dropUnfilledParams(t, i)),
              r.forEach(function (r) {
                var i = e[r],
                  n = i
                    ? encodeURIComponent(i).replace(/[!'()*]/g, function (t) {
                        return "%" + t.charCodeAt(0).toString(16).toUpperCase();
                      })
                    : "";
                t = t.replace(new RegExp((0, d.AF)(r), "g"), function (e, r) {
                  return "$" === t.charAt(r - 1) ? e : n;
                });
              }),
              t
            );
          }),
          (e.dropUnfilledParams = function (t, e) {
            return t.replace(Ci, function (t) {
              for (
                var r = t.slice(1).split(xi), i = [], n = 0;
                n < r.length;
                n += 2
              ) {
                var o = r[n],
                  a = o.slice(o.indexOf("=") + 1);
                (o.indexOf("=") > 0 && e.indexOf(a) >= 0) ||
                  (i.length && i.push(r[n - 1]), i.push(o));
              }
              return i.length ? "?" + i.join("") : "";
            });
          }),
          (e.replaceMacroHelper = function (t, e, r) {
            try {
              if (this.macroExists(t, e))
                return (
                  "{ad_format}" === e && (r = this.convertToSnakeCase(r)),
                  t.replace(new RegExp((0, d.AF)(e), "gi"), r)
                );
            } catch (t) {
              this.logger.error(t);
            }
            return t;
          }),
          (e.macroExists = function (t, e) {
            return (
              !(!t || !e || "string" != typeof t || "string" != typeof e) &&
              (t.indexOf(e) > -1 ||
                t.indexOf(e.toUpperCase()) > -1 ||
                t.indexOf(e.toLowerCase()) > -1)
            );
          }),
          (e.getDfpMacros = function () {
            var t = this,
              e = this.macroConfig;
            return {
              "%%CLICK_URL%%": function () {
                return "";
              },
              "%%CLICK_URL_ESC%%": function () {
                return "";
              },
              "%%CLICK_URL_ESC_ESC%%": function () {
                return "";
              },
              "%%CLICK_URL_UNESC%%": function () {
                return "";
              },
              "%%VIEW_URL_UNESC%%": function () {
                return "";
              },
              "%%CACHEBUSTER%%": function () {
                return t.cachebuster;
              },
              "%%PATTERN:kid%%": function () {
                return e.lexId;
              },
              "%%PATTERN:uuid%%": function () {
                return e.impressionId;
              },
              "%%PATTERN:krg_imp_id%%": function () {
                return e.impressionId;
              },
              "%%SITE%%": function () {
                return t.getSite();
              },
              "%%ADVERTISING_IDENTIFIER_PLAIN%%": function () {
                return "";
              },
              "%%PATTERN:id%%": function () {
                return "";
              },
            };
          }),
          (e.getSite = function () {
            var t = this.macroConfig,
              e = t.hostname,
              r = t.inAppMacros,
              i = bi(r) ? r["{BUNDLE_ID}"] : void 0;
            return i && Ei.test(i) ? i : e;
          }),
          (e.checkLegacyDFPImg = function (t) {
            return t.replace(
              '<img width="1" height="1" alt="" style="position: absolute; left: -9999px;" src="%%VIEW_URL_UNESC%%" />\n',
              ""
            );
          }),
          (e.getKargoMacros = function () {
            var t = this,
              e = Date.now().toString(),
              r = this.macroConfig;
            return {
              "{timestamp}": function () {
                return e;
              },
              "{cachebuster}": function () {
                return t.cachebuster;
              },
              "{uuid}": function () {
                return r.impressionId;
              },
              "{imp_id}": function () {
                return r.impressionId;
              },
              "{ad_slot}": function () {
                return r.slotId;
              },
              "{site}": function () {
                return t.getSite();
              },
              "{ad_format}": function () {
                return r.adFormat;
              },
              "{creative_id}": function () {
                return r.creativeId;
              },
              "{creative_id_alpha}": function () {
                return r.creativeIdAlpha;
              },
              "{creative_id_rtb}": function () {
                return r.creativeIdRtb;
              },
              "{deal_id}": function () {
                return r.dealId;
              },
              "{line_item_id}": function () {
                return r.lineItemId;
              },
              "{page_url}": function () {
                return vi.getPageUrl();
              },
            };
          }),
          (e.convertToSnakeCase = function (t) {
            return (t = (t = t.replace(/([a-z])([A-Z])/g, "$1-$2")).replace(
              /([A-Z])([A-Z][a-z])/g,
              "$1-$2"
            )).toLowerCase();
          }),
          t
        );
      })();
    !(function (t) {
      (t[(t.BILLABLE_FIRES_ON_START = 0)] = "BILLABLE_FIRES_ON_START"),
        (t[(t.BILLABLE_FIRES_ON_LOAD = 1)] = "BILLABLE_FIRES_ON_LOAD"),
        (t[(t.NOT_BILLABLE = 2)] = "NOT_BILLABLE");
    })(Ai || (Ai = {}));
    var Ii = "krg-btoStuntsEnabled=true",
      Oi = ["allowStunts", "allow_stunts", "krg_allow_stunts"];
    function Ri(t) {
      return !0 === t.__krg_isDemo;
    }
    var Di = null;
    function Ti(t, e) {
      Di !== t &&
        ((Di = t),
        t.addEventListener("message", function (t) {
          var r;
          "krg-bto-stunts-request" ===
            (null == (r = t.data) ? void 0 : r.type) &&
            t.source &&
            t.source.postMessage(
              { type: "krg-bto-stunts-enabled-response", enabled: e },
              "*"
            );
        }));
    }
    function Vi(t, e) {
      (t.areBtoStuntsEnabled = !1), Ti(e, !1);
    }
    function Li(t, e) {
      (t.areBtoStuntsEnabled = !0), Ti(e, !0);
      var r = new Date(Date.now() + 288e5).toUTCString();
      e.document.cookie = Ii + "; expires=" + r + "; path=/";
    }
    function Pi(t, e, r, i) {
      void 0 === i && (i = !1);
      var n = (function (t) {
        var e = new URLSearchParams(t.location.search),
          r = Oi.map(function (t) {
            return e.get(t);
          }).find(function (t) {
            return "true" === t || "false" === t;
          });
        return void 0 === r ? null : "true" === r;
      })(t);
      return !1 === n
        ? (r.debug("BTO Stunts disabled: query param set to false."),
          void Vi(e, t))
        : !0 === n
        ? (r.debug("BTO Stunts enabled: query param set to true."),
          void Li(e, t))
        : void (!(function (t, e) {
            return (
              !!Ri(t) &&
              (e.debug("BTO Stunts enabled: demo site config flag detected."),
              !0)
            );
          })(t, r)
            ? !(function (t, e) {
                return "boolean" == typeof t.__krg_bto_stunts_enabled
                  ? t.__krg_bto_stunts_enabled
                  : !0 === e;
              })(t, i)
              ? (r.debug(
                  "BTO Stunts disabled: neither window var nor global config enabled."
                ),
                Vi(e, t))
              : !(function (t) {
                  var e;
                  return null == t ||
                    null == (e = t.document) ||
                    null == (e = e.cookie)
                    ? void 0
                    : e.includes(Ii);
                })(t)
              ? (r.debug("BTO Stunts enabled for this session"), Li(e, t))
              : (r.debug("BTO Stunts disabled. BTO cookie found."), Vi(e, t))
            : Li(e, t));
    }
    function Mi(t, e) {
      (function (t) {
        return (
          ((null == t ? void 0 : t.pageViewId) && "isBrandedTakeover" in t) ||
          !1
        );
      })(t) &&
        setTimeout(function () {
          var i = r()(e, "Kargo.Plugin.Cerberus");
          i && i.handleBrandedTakeover(t.isBrandedTakeover, t.pageViewId);
        });
    }
    function Ni(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, i);
      }
      return r;
    }
    function Fi(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2
          ? Ni(Object(r), !0).forEach(function (e) {
              (0, T.A)(t, e, r[e]);
            })
          : Object.getOwnPropertyDescriptors
          ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
          : Ni(Object(r)).forEach(function (e) {
              Object.defineProperty(
                t,
                e,
                Object.getOwnPropertyDescriptor(r, e)
              );
            });
      }
      return t;
    }
    var Bi = (function () {
        function t(t, e, r) {
          (this.logger = void 0),
            (this.win = void 0),
            (this.slotConfig = void 0),
            (this.type = void 0),
            (this.requestUrl = void 0),
            (this.usingCustomRequestUrl = void 0),
            (this.impressionId = void 0),
            (this.extraMacros = void 0),
            (this.rawResponse = void 0),
            (this.creativeData = void 0),
            (this.kargoCreative = void 0),
            (this.kargoCreativeData = void 0),
            (this.errorReporter = void 0),
            (this.macroUtil = void 0),
            (this.extraContent = void 0),
            (this.sourceElement = null),
            (this.responseType = ""),
            (this.branchTestString = void 0),
            (this.logger = e),
            (this.win = t),
            (this.slotConfig = r),
            (this.type = Jr.EMPTY),
            (this.requestUrl = ""),
            (this.usingCustomRequestUrl = !1),
            (this.impressionId = ""),
            (this.extraMacros = {
              impressionId: "",
              creativeId: "",
              creativeIdAlpha: "",
              creativeIdRtb: "",
              adFormat: "",
              lineItemId: "",
              dealId: "",
            }),
            (this.rawResponse = {}),
            (this.creativeData = this.initializeCreativeData()),
            (this.extraContent = { prefix: "", suffix: "" }),
            (this.kargoCreative = !1),
            (this.kargoCreativeData = {
              sid: null,
              creativeId: null,
              vendor: null,
              vendorId: null,
              placement: null,
              auctionType: null,
              krakenViewabilityTracker: null,
            }),
            (this.errorReporter = new he(this.win, this)),
            (this.macroUtil = new Si(
              this.win,
              this.logger,
              this.slotConfig.getId() || ""
            ));
        }
        var e = t.prototype;
        return (
          (e.initializeCreativeData = function () {
            return {
              prefix: null,
              suffix: null,
              format: null,
              execution: null,
              content: "",
              iasTagParams: null,
              positionElement: null,
              positionLocation: null,
              settings: {},
            };
          }),
          (e.setCreativeDataId = function () {
            var t;
            this.creativeData.creativeId ||
              (this.creativeData.creativeId =
                null == (t = this.kargoCreativeData) ? void 0 : t.creativeId);
          }),
          (e.extractCreativeData = (function () {
            var t = (0, V.A)(
              P().mark(function t(e) {
                var r, i;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          return (t.next = 2), hi(e, this);
                        case 2:
                          (i =
                            null == (r = this.win) ||
                            null == (r = r.Kargo) ||
                            null == (r = r.Config)
                              ? void 0
                              : r.getGlobalConfig()),
                            Pi(
                              this.win,
                              this.creativeData,
                              this.logger,
                              (null == i || null == i.shouldEnableBtoStunts
                                ? void 0
                                : i.shouldEnableBtoStunts()) || !1
                            );
                        case 4:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this
                );
              })
            );
            return function (e) {
              return t.apply(this, arguments);
            };
          })()),
          (e.getType = function () {
            return this.type;
          }),
          (e.setImpressionId = function (t) {
            (this.impressionId = t), (this.extraMacros.impressionId = t);
          }),
          (e.getImpressionId = function () {
            return this.impressionId;
          }),
          (e.setExtraMacrosCreativeId = function (t, e) {
            (this.extraMacros.creativeId = t),
              "direct" === e
                ? (this.extraMacros.creativeIdAlpha = t || "")
                : (this.extraMacros.creativeIdRtb = t || "");
          }),
          (e.getExtraMacrosCreativeId = function () {
            return this.extraMacros.creativeId;
          }),
          (e.setExtraMacrosAdFormat = function (t) {
            this.extraMacros.adFormat = t;
          }),
          (e.getExtraMacrosDealId = function () {
            return this.extraMacros.dealId;
          }),
          (e.setExtraMacrosDealId = function (t) {
            this.extraMacros.dealId = t;
          }),
          (e.getExtraMacrosLineItemId = function () {
            return this.extraMacros.lineItemId;
          }),
          (e.setExtraMacrosLineItemId = function (t) {
            this.extraMacros.lineItemId = t;
          }),
          (e.getExtraMacrosAdFormat = function () {
            return this.extraMacros.adFormat;
          }),
          (e.setRequestUrl = function (t) {
            (this.requestUrl = t), (this.usingCustomRequestUrl = !0);
          }),
          (e.getRequestUrl = function () {
            return this.requestUrl;
          }),
          (e.isCustomRequestUrl = function () {
            return this.usingCustomRequestUrl;
          }),
          (e.getCreativeData = function () {
            return this.creativeData;
          }),
          (e.fetchResponse = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                return P().wrap(function (t) {
                  for (;;)
                    switch ((t.prev = t.next)) {
                      case 0:
                      case "end":
                        return t.stop();
                    }
                }, t);
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          (e.isKargoCreative = function () {
            return this.kargoCreative;
          }),
          (e.getKargoCreativeData = function () {
            return this.kargoCreativeData;
          }),
          (e.addTrackers = function (t, e) {
            var r = this,
              i = [],
              n = Fi(
                Fi({}, e),
                {},
                { format: this.creativeData.format || null }
              ),
              o = function (e, i) {
                return (function (t, e) {
                  var r, i;
                  (r = Array.isArray(t) ? t : [t]),
                    (i = Array.isArray(e) ? e : [e]);
                  var n = r.concat(i).filter(function (t) {
                    return "string" == typeof t && t.length > 0;
                  });
                  return Array.from(new Set(n));
                })(e, i).map(function (e) {
                  return r.macroUtil.buildTrackerUrl(e, n, t.context);
                });
              };
            if (t.tracking) {
              var a = this.creativeData.settings;
              (a.tracking = a.tracking || {}),
                t.tracking.serve && (i = o(i, t.tracking.serve)),
                t.tracking.win && (i = o(i, t.tracking.win));
              var s = this.creativeData.settings.tracking;
              !(function (t, e, r) {
                e.tracking.video_start &&
                  (t.start = r(t.start, e.tracking.video_start)),
                  e.tracking.video_first_quartile &&
                    (t.firstQuartile = r(
                      t.firstQuartile,
                      e.tracking.video_first_quartile
                    )),
                  e.tracking.video_midpoint &&
                    (t.midpoint = r(t.midpoint, e.tracking.video_midpoint)),
                  e.tracking.video_third_quartile &&
                    (t.thirdQuartile = r(
                      t.thirdQuartile,
                      e.tracking.video_third_quartile
                    )),
                  e.tracking.video_complete &&
                    (t.complete = r(t.complete, e.tracking.video_complete)),
                  e.tracking.click && (t.click = r(t.click, e.tracking.click)),
                  e.tracking.view && (t.view = r(t.view, e.tracking.view)),
                  e.tracking.blocked &&
                    (t.blocked = r(t.blocked, e.tracking.blocked));
              })(s, t, o),
                t.tracking.video_load &&
                  (function (t, e) {
                    var r = t.format || e.format;
                    t.ad_format_id &&
                      (r = ai.getFormatByInhubID(t.ad_format_id));
                    var i,
                      n,
                      o = !1;
                    return (
                      (o = r
                        ? ai.isVideoFormat(r)
                        : "video" ===
                            (null == (i = t.ext) ? void 0 : i.response_type) ||
                          "vast" ===
                            (null == (n = t.ext) ? void 0 : n.response_type)),
                      o
                    );
                  })(t, this.creativeData) &&
                  (i = o(i, t.tracking.video_load));
              var c = (function (t, e) {
                var r = t.format || e.format;
                return e.content.includes("video.seenthis.se")
                  ? Ai.BILLABLE_FIRES_ON_LOAD
                  : t.tracking.billable
                  ? ai.isVastFormat(r) ||
                    (ai.isKapVideoFormat(r) && "direct" === t.auction_type)
                    ? Ai.BILLABLE_FIRES_ON_START
                    : Ai.BILLABLE_FIRES_ON_LOAD
                  : Ai.NOT_BILLABLE;
              })(t, this.creativeData);
              switch (c) {
                case Ai.BILLABLE_FIRES_ON_START:
                  s.start = o(s.start, t.tracking.billable);
                  break;
                case Ai.BILLABLE_FIRES_ON_LOAD:
                  i = o(i, t.tracking.billable);
              }
            }
            t.krk_imp_tracker && (i = o(i, t.krk_imp_tracker)),
              (this.creativeData.content += i
                .map(function (t) {
                  return '<img style="display:none" src="' + t + '"/>';
                })
                .join(""));
          }),
          (e.replaceMacroValues = function (t) {
            return (t = this.macroUtil.replaceAllMacros(t, this.extraMacros));
          }),
          (e.setSourceElement = function (t) {
            (this.sourceElement = t),
              (this.win.__krg_sourceElements =
                this.win.__krg_sourceElements || []),
              this.win.__krg_sourceElements.push(t);
          }),
          (e.isValidAdMarkup = function (t) {
            return void 0 === t && (t = ""), !!t && "" !== t;
          }),
          t
        );
      })(),
      Ui = (function (t) {
        function e(e, r, i) {
          var n;
          return (
            ((n = t.call(this, e, r, i) || this).type = Jr.OVERRIDE_URL), n
          );
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.getRequestUrl = function () {
            return (
              this.requestUrl ||
                ((this.requestUrl = this.slotConfig.getOverrideUrl()),
                (this.requestUrl +=
                  (this.requestUrl.indexOf("?") > -1 ? "&" : "?") +
                  "_cb=" +
                  (0, o.WX)())),
              this.requestUrl
            );
          }),
          (r.setRequestUrl = function (t, e) {
            void 0 === e && (e = !0),
              (this.requestUrl = t),
              e &&
                (this.requestUrl +=
                  (this.requestUrl.indexOf("?") > -1 ? "&" : "?") +
                  "_cb=" +
                  (0, o.WX)());
          }),
          (r.fetchResponse = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e, r;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          return (
                            this.logger.debug(
                              "OVERRIDE URL - Ad Request\n    Request Url: " +
                                this.requestUrl
                            ),
                            (e = this.getRequestUrl()),
                            (t.prev = 2),
                            (t.next = 5),
                            (0, c.dA)(e, this.win, {})
                          );
                        case 5:
                          return (
                            (r = t.sent),
                            (this.rawResponse = r),
                            (t.prev = 7),
                            (t.next = 10),
                            this.extractCreativeData(r)
                          );
                        case 10:
                          this.logger.debug(
                            "OVERRIDE URL - Ad Response",
                            this.getCreativeData()
                          ),
                            (t.next = 16);
                          break;
                        case 13:
                          (t.prev = 13),
                            (t.t0 = t.catch(7)),
                            this.logger.error(t.t0);
                        case 16:
                          t.next = 21;
                          break;
                        case 18:
                          (t.prev = 18),
                            (t.t1 = t.catch(2)),
                            this.logger.debug("OVERRIDE URL - No Ad Response");
                        case 21:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this,
                  [
                    [2, 18],
                    [7, 13],
                  ]
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          e
        );
      })(Bi),
      Hi = (function (t) {
        function e(e, r, i) {
          var n;
          return (
            ((n = t.call(this, e, r, i) || this).htmlResponse = void 0),
            (n.type = Jr.HTML),
            (n.htmlResponse = null),
            n
          );
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.setResponse = function (t) {
            var e;
            try {
              e = this.win.atob(t);
            } catch (r) {
              e = t;
            }
            this.htmlResponse = e;
          }),
          (r.fetchResponse = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          return (
                            this.logger.debug(
                              "HTML - Ad Request Html: ",
                              this.htmlResponse
                            ),
                            (e = this.htmlResponse),
                            (this.rawResponse = e),
                            (t.prev = 3),
                            (t.next = 6),
                            this.extractCreativeData(e)
                          );
                        case 6:
                          this.logger.debug(
                            "HTML - Ad Response",
                            this.getCreativeData()
                          ),
                            (t.next = 12);
                          break;
                        case 9:
                          (t.prev = 9),
                            (t.t0 = t.catch(3)),
                            this.logger.error(t.t0);
                        case 12:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this,
                  [[3, 9]]
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          e
        );
      })(Bi),
      ji = "err-encdng-crtve",
      zi = "crtve-hght-max",
      Wi = "clr-pckr-fail",
      Ki = (function () {
        function t() {}
        return (
          (t.base64CheckAndConversion = function (t, e) {
            return (
              /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/.test(
                e
              ) && (e = t.atob(e)),
              e
            );
          }),
          t
        );
      })(),
      qi = (function () {
        function t() {}
        return (
          (t.handleNativeResponseType = function (t, e, r, i) {
            var n = null;
            try {
              null != t.adm && (n = JSON.parse(t.adm));
            } catch (i) {
              i instanceof Error &&
                r.report($t, "Error parsing Native JSON: " + i.message, {
                  creative: t.krg_imp_id,
                  format: t.format || "unknown",
                }),
                (e = null);
            }
            if (null !== n && e) {
              (e.content = ""),
                (e.settings.native = n),
                (e.settings.native.auctionType = t.auction_type || "pmp"),
                t.creative_optimizer &&
                  (e.settings.native.creativeOptimizer = t.creative_optimizer),
                i.getFormatConfig(Br.B.ABA_ADHESION_DISPLAY)
                  ? (e.format = Br.B.ABA_ADHESION_DISPLAY)
                  : (e.format = Br.B.ABA_DISPLAY);
              var o = n.assets;
              if (o && o.length)
                for (var a = 0; a < o.length; a += 1) {
                  var s = o[a];
                  if (s.video && s.video.vasttag) {
                    (e.settings.native.vast = s.video.vasttag),
                      (e.format = Br.B.ABA_VIDEO);
                    break;
                  }
                }
            }
            return e;
          }),
          t
        );
      })();
    function Gi(t, e) {
      return (
        e.debug(
          "PASSBACK - Ad Request\n    Format: " +
            t.getFormat() +
            "\n    Size: " +
            t.getSize() +
            "\n    Html: " +
            t.getHtml()
        ),
        { format: t.getFormat(), size: t.getSize(), html: t.getHtml() }
      );
    }
    function Yi(t, e) {
      t.format || (t.format = e), (t.settings.branding = "none");
    }
    function Ji(t, e, r) {
      return Zi.apply(this, arguments);
    }
    function Zi() {
      return (Zi = (0, V.A)(
        P().mark(function t(e, r, i) {
          var n;
          return P().wrap(function (t) {
            for (;;)
              switch ((t.prev = t.next)) {
                case 0:
                  return (
                    (n = Gi(e, r.logger)),
                    (r.rawResponse = n.html),
                    (t.next = 4),
                    i(n.html)
                  );
                case 4:
                  Object.assign(r.passbackCreativeData, n),
                    Yi(r.creativeData, n.format),
                    (r.type = Jr.PASSBACK);
                case 7:
                case "end":
                  return t.stop();
              }
          }, t);
        })
      )).apply(this, arguments);
    }
    var $i = (function () {
      function t(t, e, r, i, n, o, a) {
        (this.sourceElement = null),
          (this.sequenceId = null),
          (this.win = void 0),
          (this.logger = void 0),
          (this.slotConfig = void 0),
          (this.type = "SequentialMessagingUtility"),
          (this.rawResponse = void 0),
          (this.errorReporter = void 0),
          (this.ordered = !0),
          (this.sequenceKey = "ul"),
          (this.macroUtil = void 0),
          (this.extraMacros = void 0),
          (this.SLOT_TIMEOUT = 500),
          (this.win = t),
          (this.logger = e),
          (this.slotConfig = r),
          (this.rawResponse = null),
          (this.sourceElement = a),
          i && (this.sequenceId = i),
          (this.macroUtil = n),
          (this.extraMacros = o),
          (this.errorReporter = new he(this.win, this));
      }
      var e = t.prototype;
      return (
        (e.handleSequential = (function () {
          var t = (0, V.A)(
            P().mark(function t(e) {
              var r,
                i,
                n,
                o = this;
              return P().wrap(
                function (t) {
                  for (;;)
                    switch ((t.prev = t.next)) {
                      case 0:
                        return (
                          (this.win.__krg_adms = this.win.__krg_adms || e),
                          (i = e),
                          (t.next = 4),
                          new Promise(function (t) {
                            setTimeout(t, o.SLOT_TIMEOUT);
                          })
                        );
                      case 4:
                        return (
                          (n =
                            null != (r = this.win.__krg_sourceElements)
                              ? r
                              : []),
                          t.abrupt("return", this.chooseAdm(i, n))
                        );
                      case 6:
                      case "end":
                        return t.stop();
                    }
                },
                t,
                this
              );
            })
          );
          return function (e) {
            return t.apply(this, arguments);
          };
        })()),
        (e.chooseAdm = function (t, e) {
          var r = this,
            i = this.sortSources(e);
          this.handleSequenceId() &&
            this.win.__krg_used_sources &&
            (this.logger.debug("New sequence found in response"),
            this.win.__krg_used_sources.forEach(function (t) {
              i = i.filter(function (e) {
                return e !== t;
              });
            }),
            (this.win.__krg_sourceElements = i));
          var n = this.createSequentialMap(i, t),
            o = null,
            a = null;
          if (
            (Object.keys(n).forEach(function (t) {
              n[t].source === r.sourceElement && ((o = n[t].creative), (a = t));
            }),
            o)
          ) {
            var s,
              c = "randomly chosen from ordered";
            t.ul && t.ul.includes(o)
              ? (c = "chosen randomly from unordered")
              : this.ordered && t.ol && (c = "#" + a + " from ordered chosen"),
              this.assignWindowSources(),
              (o =
                null == (s = this.macroUtil)
                  ? void 0
                  : s.replaceAllMacros(this.win.atob(o), this.extraMacros));
            var l = { slot: this.slotConfig.getId(), creativeHtml: o };
            this.logger.debug("Hephaestus - Sequential Adm " + c, l);
          } else
            this.errorReporter.report(H, "Unable to choose sequential adm");
          return o;
        }),
        (e.sortSources = function (t) {
          var e = [];
          return (
            Object.keys(t).length
              ? (e = t.slice(0).sort(function (t, e) {
                  return (
                    t.parentNode.getBoundingClientRect().top -
                    e.parentNode.getBoundingClientRect().top
                  );
                }))
              : this.errorReporter.report(
                  H,
                  "No source elements found for slots on page"
                ),
            e
          );
        }),
        (e.createSequentialMap = function (t, e) {
          var r = this,
            i = {};
          return (
            t.map(function (n, o) {
              var a = o + 1;
              i[a] = {
                source: t[o],
                creative:
                  e.ol[a] ||
                  (function () {
                    if (
                      (e.ul && e.ul.length) ||
                      (e.ol && Object.keys(e.ol).length)
                    ) {
                      if (e.ul && e.ul.length)
                        return e.ul[Math.floor(Math.random() * e.ul.length)];
                      if (e.ol && Object.keys(e.ol).length) {
                        (r.ordered = !1),
                          r.logger.debug(
                            "No unordered adms found, using random ordered adm"
                          );
                        var t = Object.values(e.ol);
                        return t[Math.floor(Math.random() * t.length)];
                      }
                    } else
                      r.errorReporter.report(H, "No creatives in response");
                  })(),
              };
            }),
            i
          );
        }),
        (e.handleSequenceId = function () {
          var t = !1;
          this.win.__krg_sequence_id &&
            this.win.__krg_sequence_id !== this.sequenceId &&
            (t = !0);
          return (this.win.__krg_sequence_id = this.sequenceId), t;
        }),
        (e.assignWindowSources = function () {
          (this.win.__krg_used_sources =
            this.win.__krg_used_sources || new Set([])),
            this.win.__krg_used_sources.add(this.sourceElement);
        }),
        t
      );
    })();
    function Xi(t, e) {
      return Qi.apply(this, arguments);
    }
    function Qi() {
      return (Qi = (0, V.A)(
        P().mark(function t(e, r) {
          var i, n, o, a;
          return P().wrap(function (t) {
            for (;;)
              switch ((t.prev = t.next)) {
                case 0:
                  if (r.adms || r.adm) {
                    t.next = 3;
                    break;
                  }
                  return (
                    e.errorReporter.report(
                      H,
                      "Missing ad markup (adm or adms)"
                    ),
                    t.abrupt("return", null)
                  );
                case 3:
                  if (((i = null), !r.adms || !r.isBrandedTakeover)) {
                    t.next = 13;
                    break;
                  }
                  if (r.adms.ol || r.adms.ul) {
                    t.next = 8;
                    break;
                  }
                  return (
                    e.errorReporter.report(H, "Missing both ol and ul in adms"),
                    t.abrupt("return", null)
                  );
                case 8:
                  return (
                    e.SQMUtil ||
                      (e.SQMUtil = new $i(
                        e.win,
                        e.logger,
                        e.slotConfig,
                        r.sequenceId,
                        e.macroUtil,
                        e.extraMacros,
                        e.sourceElement
                      )),
                    (t.next = 11),
                    e.SQMUtil.handleSequential(r.adms)
                  );
                case 11:
                  (i = t.sent) ||
                    e.errorReporter.report(
                      H,
                      "Unable to choose sequential adm"
                    );
                case 13:
                  if (
                    (r.adm
                      ? ((n = r.adm),
                        e.logger.debug("Hephaestus - Standard adm"))
                      : i &&
                        ((n = i),
                        e.logger.debug(
                          "Hephaestus - Special adms sequential response"
                        )),
                    !n)
                  ) {
                    t.next = 20;
                    break;
                  }
                  return (
                    (o = y(n, "krg_ad_info")),
                    (a = null),
                    o &&
                      o.asdata &&
                      ((e.creativeData.creativeId =
                        o.asdata.creid || o.creativeId || null),
                      (a = o.asdata.creid),
                      (e.krakenCreativeData.advertiser =
                        o.asdata.advid || null),
                      (e.krakenCreativeData.campaign = o.asdata.camid || null),
                      (e.extraMacros.lineItemId = o.asdata.linid || null),
                      (e.krakenCreativeData.placement = o.asdata.aduid || null),
                      (e.krakenCreativeData.site = o.asdata.sitid || null)),
                    (e.creativeData.creativeId =
                      a || (null == o ? void 0 : o.creativeId) || null),
                    t.abrupt("return", n)
                  );
                case 20:
                  return t.abrupt("return", null);
                case 21:
                case "end":
                  return t.stop();
              }
          }, t);
        })
      )).apply(this, arguments);
    }
    function tn(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, i);
      }
      return r;
    }
    function en(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2
          ? tn(Object(r), !0).forEach(function (e) {
              (0, T.A)(t, e, r[e]);
            })
          : Object.getOwnPropertyDescriptors
          ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
          : tn(Object(r)).forEach(function (e) {
              Object.defineProperty(
                t,
                e,
                Object.getOwnPropertyDescriptor(r, e)
              );
            });
      }
      return t;
    }
    var rn = (function (t) {
      function e(e, r, i) {
        var n;
        return (
          ((n = t.call(this, e, r, i) || this).responseType = void 0),
          (n.type = Jr.KRAKEN),
          (n.KRAKEN_AD_REQUEST_URL = "https://krk.kargo.com/api/v1/getad"),
          (n.TIMEOUT = 3e3),
          (n.errFactory = new l.wm("Kraken")),
          (n.requestJson = void 0),
          (n.responseJson = void 0),
          (n.socialCanvasSegments = []),
          (n.socialEmbedURL = ""),
          (n.krakenCreativeData = {
            admRequestUrl: "",
            advertiser: "",
            advertiserDomain: "",
            auctionType: "pmp",
            biddableId: "",
            campaign: "",
            creative: "",
            creativeFlags: {},
            dealId: "",
            dealName: "",
            gpid: "",
            krakenDomain: "",
            krgImpId: "",
            placement: "",
            site: "",
            size: "",
          }),
          (n.passbackCreativeData = { html: null, size: null, format: null }),
          (n.hephCreativeId = null),
          (n.requestError = void 0),
          (n.krakenFormatName = void 0),
          (n.SQMUtil = void 0),
          (n.type = Jr.KRAKEN),
          (n.responseType = null),
          (n.krakenFormatName = null),
          n
        );
      }
      Ae(e, t);
      var n = e.prototype;
      return (
        (n.getRequestJson = function () {
          if (this.requestJson) return this.requestJson;
          var t = this.slotConfig.getPlatform(),
            e = (0, o.pO)(this.win),
            i = !!(0, o.P3)(e, "krg_debug");
          "MobileApp" === t &&
            this.win.__krg_page_url_override &&
            (e = this.win.__krg_page_url_override);
          var n = {
              kargoID: null,
              clientID: "",
              tdID: "",
              crbIDs: {},
              optOut: !1,
              usp: null,
              gdpr: { applies: !1, consent: "" },
              gpp: { string: "", applicableSections: [] },
            },
            a = r()(this.win, "Kargo.Plugin.Cerberus");
          a &&
            ((n.optOut = a.isOptOut()),
            (n.clientID = a.getClientId() || ""),
            (n.usp = a.getUSPrivacy()),
            (n.gdpr.applies = a.gdprApplies()),
            (n.gdpr.consent = a.gdprConsent()),
            (n.gpp.string = a.gppString()),
            (n.gpp.applicableSections = a.gppApplicableSections()),
            n.optOut ||
              ((n.kargoID = a.getLexId()), (n.tdID = a.getTdID() || "")));
          var s = Ar(this.win, "krg_crb") || "";
          return (
            (this.requestJson = {
              debug: i,
              adSlotIDs: [this.slotConfig.getId()],
              timestamp: Date.now(),
              timeout: this.TIMEOUT,
              userIDs: n,
              pageURL: e,
              rawCRB: s,
              socialCanvasSegments: this.socialCanvasSegments,
              socialEmbedURL: this.socialEmbedURL,
            }),
            this.requestJson
          );
        }),
        (n.getKrakenCreativeData = function () {
          return this.krakenCreativeData;
        }),
        (n.setKrakenCreativeInfo = function () {
          t.prototype.setCreativeDataId.call(this),
            this.krakenCreativeData.creative &&
              ((this.creativeData.creativeId =
                this.krakenCreativeData.creative),
              (this.creativeData.sourceName = Jr.KRAKEN));
        }),
        (n.setResponse = function (t) {
          t.adm && (t.adm = Ki.base64CheckAndConversion(this.win, t.adm)),
            (this.responseJson = t);
        }),
        (n.setSocialCanvasSegments = function (t) {
          this.socialCanvasSegments = t;
        }),
        (n.setSocialEmbedURL = function (t) {
          this.socialEmbedURL = t;
        }),
        (n.getRequestUrl = function () {
          if (!this.requestUrl) {
            var t = window.JSON.stringify(this.getRequestJson()),
              e = (0, i.gh)(this.win) ? 1 : 0,
              r = (0, o.pO)(this.win),
              n = (0, o.P3)(r, "ad_id") || (0, o.P3)(r, "AD_ID"),
              a = {
                json: encodeURIComponent(t),
                adtag_version: "10.9.0-kat-7484-test",
                include_direct: 1,
                google_amp: e,
              };
            n && (a.ad_id = n);
            var s = Object.entries(a)
              .map(function (t) {
                return t.join("=");
              })
              .join("&");
            this.requestUrl = this.KRAKEN_AD_REQUEST_URL + "?" + s;
          }
          return this.requestUrl;
        }),
        (n.extractCreativeData = (function () {
          var t = (0, V.A)(
            P().mark(function t(e) {
              var i, n, o, a, s, c, l, u, h, p;
              return P().wrap(
                function (t) {
                  for (;;)
                    switch ((t.prev = t.next)) {
                      case 0:
                        if (((n = {}), !e.adm)) {
                          t.next = 5;
                          break;
                        }
                        (n = y(e.adm, "krg_ad_info")), (t.next = 8);
                        break;
                      case 5:
                        if (e.adm || e.adms || "open" === e.auction_type) {
                          t.next = 8;
                          break;
                        }
                        return (
                          this.errorReporter.report(Jt, "No ADM or ADMS"),
                          t.abrupt(
                            "return",
                            Promise.reject(
                              new Error("No ADM or ADMS from Kraken")
                            )
                          )
                        );
                      case 8:
                        return (
                          void 0 !== e.ias_tag_params &&
                            (this.creativeData.iasTagParams = e.ias_tag_params),
                          r()(n, "asdata")
                            ? ((this.hephCreativeId = n.asdata.creid || null),
                              (this.creativeData.creativeId =
                                this.hephCreativeId))
                            : (this.creativeData.creativeId =
                                (null == (o = n) ? void 0 : o.creativeId) ||
                                null),
                          (a = e.adm_prefix),
                          (s = e.adm_suffix),
                          a &&
                            (this.extraContent.prefix =
                              Ki.base64CheckAndConversion(this.win, a)),
                          s &&
                            (this.extraContent.suffix =
                              Ki.base64CheckAndConversion(this.win, s)),
                          (t.next = 16),
                          this.handleResponseSourceLogic(e)
                        );
                      case 16:
                        if (
                          (e.tracking &&
                            (this.creativeData.settings.tracking
                              ? (0, d.h1)(
                                  this.creativeData.settings.tracking,
                                  e.tracking
                                )
                              : (this.creativeData.settings.tracking =
                                  e.tracking)),
                          e.gpid && (this.krakenCreativeData.gpid = e.gpid),
                          e.ad_format_id &&
                            (this.krakenFormatName = ai.getFormatByInhubID(
                              e.ad_format_id
                            )),
                          !this.creativeData.format)
                        ) {
                          t.next = 34;
                          break;
                        }
                        if (
                          !pi(
                            this.krakenFormatName || "",
                            this.creativeData.format
                          )
                        ) {
                          t.next = 32;
                          break;
                        }
                        if (
                          ((c =
                            "Format Mismatch " +
                            e.id +
                            " (" +
                            this.creativeData.format +
                            " | " +
                            this.krakenFormatName +
                            ")"),
                          (l = !0),
                          (g = this.krakenFormatName || ""),
                          (f = this.creativeData.format || ""),
                          (v = this.slotConfig),
                          pi(g, f) &&
                            !v.getFormatConfig(f) &&
                            Lr.$4[f].type === si.p.HOVER &&
                            Lr.$4[g].type === si.p.BANNER &&
                            (c =
                              "Hover format banner slot mismatch - (" +
                              this.creativeData.format +
                              " | " +
                              this.krakenFormatName +
                              ")"),
                          this.slotConfig.getFormatConfig(
                            this.creativeData.format
                          ))
                        ) {
                          t.next = 31;
                          break;
                        }
                        if (
                          ((this.creativeData.format =
                            this.krakenFormatName || null),
                          this.slotConfig.getFormatConfig(
                            this.creativeData.format
                          ))
                        ) {
                          t.next = 31;
                          break;
                        }
                        return (
                          (l = !1),
                          (c +=
                            " - Slot supports neither response format nor creative format - destroying"),
                          this.errorReporter.report(
                            Zt,
                            c,
                            { creative: e.id },
                            l
                          ),
                          t.abrupt("return", Promise.reject(new Error(c)))
                        );
                      case 31:
                        this.errorReporter.report(Yt, c, { creative: e.id }, l);
                      case 32:
                        t.next = 35;
                        break;
                      case 34:
                        this.krakenFormatName &&
                          (this.creativeData.format = this.krakenFormatName);
                      case 35:
                        if (
                          (Mi(e, this.win),
                          (u = "open" !== e.auction_type),
                          e.format || e.ad_format || e.ad_format_id || !u)
                        ) {
                          t.next = 41;
                          break;
                        }
                        this.errorReporter.report(qt, "No Format in Response"),
                          (t.next = 53);
                        break;
                      case 41:
                        if (this.creativeData.format || !e.format) {
                          t.next = 45;
                          break;
                        }
                        (this.creativeData.format = e.format), (t.next = 53);
                        break;
                      case 45:
                        if (
                          !pi(e.format || "", this.creativeData.format || "")
                        ) {
                          t.next = 53;
                          break;
                        }
                        if (
                          ((h =
                            "Format Mismatch " +
                            e.creative_id +
                            "/\n      (Creative: " +
                            this.creativeData.format +
                            " | Reported: " +
                            e.format +
                            ")"),
                          this.errorReporter.report(Yt, h, {
                            format: this.creativeData.format,
                            source: "Kraken",
                          }),
                          this.slotConfig.getFormatConfig(
                            this.creativeData.format
                          ))
                        ) {
                          t.next = 53;
                          break;
                        }
                        if (
                          ((this.creativeData.format = e.format || null),
                          this.slotConfig.getFormatConfig(
                            this.creativeData.format
                          ))
                        ) {
                          t.next = 53;
                          break;
                        }
                        return (
                          this.logger.debug(
                            "Slot supports neither response format nor creative format - destroying"
                          ),
                          t.abrupt("return", Promise.reject(new Error(h)))
                        );
                      case 53:
                        "open" === e.auction_type &&
                          this.setAdvertisingBrandingForOpen(e),
                          ("native" !== e.creative_type &&
                            "native" !==
                              (null == (i = e.ext)
                                ? void 0
                                : i.response_type)) ||
                            (this.creativeData = qi.handleNativeResponseType(
                              e,
                              this.creativeData,
                              this.errorReporter,
                              this.slotConfig
                            )),
                          this.handleHTMLResponseType(e),
                          (p = r()(e.tracking, "view", null)) &&
                            (this.kargoCreativeData.krakenViewabilityTracker =
                              p.replace("{CONTEXT}", e.context));
                      case 58:
                      case "end":
                        return t.stop();
                    }
                  var g, f, v;
                },
                t,
                this
              );
            })
          );
          return function (e) {
            return t.apply(this, arguments);
          };
        })()),
        (n.validateResponse = function (t) {
          var e = this,
            i = function (t, r) {
              void 0 === r && (r = B),
                e.errorReporter.report(
                  r,
                  "Kraken response validation error: " + t
                );
            };
          if (
            ("number" == typeof t.format
              ? (i("Format number instead of string"), delete t.format)
              : ("pmp" !== t.auction_type && "direct" !== t.auction_type) ||
                t.format ||
                this.creativeData.format ||
                t.ad_format ||
                t.ad_format_id ||
                i(t.auction_type + " missing format", Gt),
            t.auction_type ||
              (t.adms
                ? (t.auction_type = "direct")
                : (i("Missing auction type", Xt), (t.auction_type = "open"))),
            !t.adm && !t.adms)
          ) {
            var n = null;
            (n = "Missing ad markup (adm)"),
              "" === t.adm &&
                ((n = "Empty ad markup (adm)"),
                void 0 !== t.adm && delete t.adm),
              i(n, Jt);
          }
          var o = r()(t, "tracking.billable"),
            a = Array.isArray(o) && o.includes($r);
          return (
            a &&
              (t.tracking.billable = o.filter(function (t) {
                return t !== $r;
              })),
            !a &&
              ((t.creative_type && "vast" !== t.creative_type) ||
                (!t.creative_type && t.adm && !t.adm.includes("<VAST"))) &&
              ((o && 0 !== o.length) || i("No billable trackers", Kt)),
            t
          );
        }),
        (n.fetchResponse = (function () {
          var t = (0, V.A)(
            P().mark(function t() {
              var e, r;
              return P().wrap(
                function (t) {
                  for (;;)
                    switch ((t.prev = t.next)) {
                      case 0:
                        return (
                          this.logger.debug(
                            "Kraken - Ad Request",
                            "Request Params:",
                            this.getRequestJson()
                          ),
                          (e = this.getRequestUrl()),
                          this.isCustomRequestUrl() &&
                            this.logger.debug(
                              "Kraken - Using Custom Request Url: " + e
                            ),
                          (t.prev = 3),
                          (t.next = 6),
                          this.getResponseJson(e)
                        );
                      case 6:
                        if (
                          ((r = t.sent),
                          this.validateAdResponse(r),
                          !r.adm_request_url)
                        ) {
                          t.next = 11;
                          break;
                        }
                        return (t.next = 11), this.fetchAdm(r);
                      case 11:
                        return (t.next = 13), this.processResponse(r);
                      case 13:
                        t.next = 20;
                        break;
                      case 15:
                        return (
                          (t.prev = 15),
                          (t.t0 = t.catch(3)),
                          this.logger.debug("Kraken - Request failed", t.t0),
                          (t.next = 20),
                          this.handlePassback(
                            this.slotConfig.getPassbackConfig(),
                            t.t0
                          )
                        );
                      case 20:
                      case "end":
                        return t.stop();
                    }
                },
                t,
                this,
                [[3, 15]]
              );
            })
          );
          return function () {
            return t.apply(this, arguments);
          };
        })()),
        (n.handlePassback = (function () {
          var e = (0, V.A)(
            P().mark(function e(r, i) {
              var n;
              return P().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (r.isEnabled()) {
                          e.next = 3;
                          break;
                        }
                        throw (
                          (this.logger.debug(
                            "Passback is not enabled, rethrowing error"
                          ),
                          i)
                        );
                      case 3:
                        return (
                          (e.prev = 3),
                          (n = t.prototype.extractCreativeData.bind(this)),
                          e.abrupt("return", Ji(r, this, n))
                        );
                      case 8:
                        throw (
                          ((e.prev = 8),
                          (e.t0 = e.catch(3)),
                          this.logger.debug("PASSBACK - Exception", e.t0),
                          (this.requestError = e.t0),
                          e.t0)
                        );
                      case 13:
                      case "end":
                        return e.stop();
                    }
                },
                e,
                this,
                [[3, 8]]
              );
            })
          );
          return function (t, r) {
            return e.apply(this, arguments);
          };
        })()),
        (n.getResponseJson = (function () {
          var t = (0, V.A)(
            P().mark(function t(e) {
              return P().wrap(
                function (t) {
                  for (;;)
                    switch ((t.prev = t.next)) {
                      case 0:
                        if (!this.responseJson) {
                          t.next = 4;
                          break;
                        }
                        (t.t0 = this.responseJson), (t.next = 7);
                        break;
                      case 4:
                        return (t.next = 6), (0, c.dA)(e, this.win, {});
                      case 6:
                        t.t0 = t.sent;
                      case 7:
                        return t.abrupt("return", t.t0);
                      case 8:
                      case "end":
                        return t.stop();
                    }
                },
                t,
                this
              );
            })
          );
          return function (e) {
            return t.apply(this, arguments);
          };
        })()),
        (n.validateAdResponse = function (t) {
          if (
            !t ||
            "noad" === t.creative_type ||
            0 === Object.entries(t).length
          )
            throw (
              (this.recordSocialCanvasBidResult(),
              this.errFactory.errNoResponse("JSON"))
            );
          "SocialCanvas" === t.format &&
            this.recordSocialCanvasBidResult({
              creative_id: t.creative_id,
              deal_id: t.deal_id,
              biddable_id: t.biddable_id,
            });
        }),
        (n.fetchAdm = (function () {
          var t = (0, V.A)(
            P().mark(function t(e) {
              var r;
              return P().wrap(
                function (t) {
                  for (;;)
                    switch ((t.prev = t.next)) {
                      case 0:
                        return (
                          (t.next = 2),
                          (0, c.dA)(e.adm_request_url, this.win, {})
                        );
                      case 2:
                        "string" == typeof (r = t.sent) && (e.adm = r);
                      case 4:
                      case "end":
                        return t.stop();
                    }
                },
                t,
                this
              );
            })
          );
          return function (e) {
            return t.apply(this, arguments);
          };
        })()),
        (n.processResponse = (function () {
          var t = (0, V.A)(
            P().mark(function t(e) {
              var r, i, n;
              return P().wrap(
                function (t) {
                  for (;;)
                    switch ((t.prev = t.next)) {
                      case 0:
                        return (
                          (r = this.validateResponse(e)),
                          (this.rawResponse = r),
                          (i = yi(r)),
                          (this.extraMacros.inAppMacros = i),
                          (this.krakenCreativeData.inAppMacros = i),
                          (t.next = 7),
                          this.extractCreativeData(r)
                        );
                      case 7:
                        (n = { creativeId: this.hephCreativeId }),
                          this.addTrackers(r, n),
                          this.logger.debug(
                            "Kraken - Ad Response",
                            this.getCreativeData()
                          ),
                          this.logger.debug(
                            "Kraken - Metadata",
                            this.getKrakenCreativeData()
                          );
                      case 11:
                      case "end":
                        return t.stop();
                    }
                },
                t,
                this
              );
            })
          );
          return function (e) {
            return t.apply(this, arguments);
          };
        })()),
        (n.recordSocialCanvasBidResult = function (t) {
          var e;
          null == (e = this.win.socialCanvas) ||
            null == e.recordBidResult ||
            e.recordBidResult(t);
        }),
        (n.handleHTMLResponseType = function (t) {
          var e,
            r =
              "direct" ===
              (null == t || null == (e = t.auction_type)
                ? void 0
                : e.toLowerCase());
          (this.krakenCreativeData.advertiserDomain = t.advertiser_domain),
            (this.krakenCreativeData.auctionType = t.auction_type),
            this.krakenCreativeData.creative ||
              ((this.krakenCreativeData.creative = t.id || t.creative_id || ""),
              this.setKrakenCreativeInfo()),
            (this.krakenCreativeData.krgImpId = t.krg_imp_id),
            (this.krakenCreativeData.krakenDomain = t.kraken_domain || ""),
            (this.krakenCreativeData.dealId = t.deal_id),
            (this.krakenCreativeData.dealName = t.deal_name),
            (this.krakenCreativeData.size = t.size),
            (this.krakenCreativeData.admRequestUrl = t.adm_request_url),
            (this.krakenCreativeData.biddableId =
              (r && (t.biddable_id || t.kraken_id)) || ""),
            (this.krakenCreativeData.creativeFlags = t.creative_flags
              ? t.creative_flags
              : {});
        }),
        (n.setAdvertisingBrandingForOpen = function (t) {
          if (
            ((this.creativeData.settings.branding = "advertisement"),
            !this.creativeData.format)
          ) {
            var e = r()(this.creativeData, "settings", {}),
              i = this.slotConfig.getAllFormatConfigs
                ? this.slotConfig.getAllFormatConfigs()
                : {},
              n = Wr.getSupportedPMPFormats(i);
            this.creativeData.format = ai.determineFormat(
              t.adm || "",
              t.size,
              e,
              n
            );
          }
        }),
        (n.copyCreativeData = function () {
          this.creativeData = en(en({}, this.creativeData), this.extraContent);
        }),
        (n.handleResponseSourceLogic = (function () {
          var e = (0, V.A)(
            P().mark(function e(r) {
              var i, n;
              return P().wrap(
                function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (
                          ((i = "direct" === r.auction_type),
                          (e.prev = 1),
                          !r.markup)
                        ) {
                          e.next = 8;
                          break;
                        }
                        return (
                          (this.responseType = "HTML"),
                          (e.next = 6),
                          t.prototype.extractCreativeData.call(this, r.markup)
                        );
                      case 6:
                        e.next = 25;
                        break;
                      case 8:
                        if (!i) {
                          e.next = 17;
                          break;
                        }
                        return (
                          (this.responseType = "Hephaestus"),
                          (e.next = 12),
                          Xi(this, r)
                        );
                      case 12:
                        return (
                          (n = e.sent),
                          (e.next = 15),
                          t.prototype.extractCreativeData.call(this, n)
                        );
                      case 15:
                        e.next = 25;
                        break;
                      case 17:
                        if (!r.adm) {
                          e.next = 23;
                          break;
                        }
                        return (
                          (this.responseType = "Kraken"),
                          (e.next = 21),
                          t.prototype.extractCreativeData.call(this, r.adm)
                        );
                      case 21:
                        e.next = 25;
                        break;
                      case 23:
                        this.errorReporter.report(
                          Qt,
                          "Unable to extract creative data from any source"
                        ),
                          we.reportAdMetric(
                            {
                              type: "failure",
                              version: "10.9.0-kat-7484-test",
                              errCode: "no-crtve-data",
                            },
                            this.slotConfig,
                            this.logger
                          );
                      case 25:
                        this.setExtraMacros(r),
                          this.copyCreativeData(),
                          (e.next = 32);
                        break;
                      case 29:
                        (e.prev = 29),
                          (e.t0 = e.catch(1)),
                          this.logger.error(e.t0);
                      case 32:
                      case "end":
                        return e.stop();
                    }
                },
                e,
                this,
                [[1, 29]]
              );
            })
          );
          return function (t) {
            return e.apply(this, arguments);
          };
        })()),
        (n.setExtraMacros = function (t) {
          this.setImpressionId(t.krg_imp_id);
          var e = t.creative_id || t.id;
          e && this.setExtraMacrosCreativeId(e, t.auction_type),
            t.biddable_id && this.setExtraMacrosLineItemId(t.biddable_id),
            t.deal_id && this.setExtraMacrosDealId(t.deal_id);
        }),
        e
      );
    })(Bi);
    function nn(t, e, r, i, n) {
      var a,
        s = (function (t) {
          var e,
            r = null,
            i = (0, o.pO)(t),
            n = (0, o.P3)(i, "krg_creative_id"),
            a = (0, o.P3)(i, "krg_time");
          if (a && 10 === a.length) e = a;
          else {
            var s = new Date(),
              c = ("0" + s.getDate()).slice(-2),
              l = ("0" + (s.getMonth() + 1)).slice(-2);
            e = "" + s.getFullYear() + l + c + "00";
          }
          return (
            n &&
              (r =
                "https://kats.prod.kargo.com/api/kssp-creative-markup?creative_id=" +
                n +
                "&response_time_id=" +
                e +
                "&limit=1"),
            r
          );
        })(t);
      if (i.getOverrideUrl() || n.override_url || s) {
        var c = new Ui(t, e, i);
        s
          ? c.setRequestUrl(s, !1)
          : n.override_url && c.setRequestUrl(n.override_url),
          (a = c);
      } else if (n.html) {
        var l = new Hi(t, e, i);
        l.setResponse(n.html), (a = l);
      } else
        (a = new rn(t, e, i)),
          n.kraken_request_url
            ? a.setRequestUrl(n.kraken_request_url)
            : n.kraken
            ? a.setResponse(n.kraken)
            : n.socialCanvasSegments
            ? a.setSocialCanvasSegments(n.socialCanvasSegments)
            : n.socialEmbedURL && a.setSocialEmbedURL(n.socialEmbedURL),
          n.sourceElement && a.setSourceElement(n.sourceElement);
      return new Fr(t, e, r, i, a, n);
    }
    function on(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, i);
      }
      return r;
    }
    function an(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2
          ? on(Object(r), !0).forEach(function (e) {
              (0, T.A)(t, e, r[e]);
            })
          : Object.getOwnPropertyDescriptors
          ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
          : on(Object(r)).forEach(function (e) {
              Object.defineProperty(
                t,
                e,
                Object.getOwnPropertyDescriptor(r, e)
              );
            });
      }
      return t;
    }
    var sn = (function () {
      function t(t, e, r, i, n, o, a, s) {
        void 0 === o && (o = ""),
          (this.win = void 0),
          (this.logger = void 0),
          (this.krakenBidID = void 0),
          (this.krakenHostname = void 0),
          (this.slotId = void 0),
          (this.scriptUrl = void 0),
          (this.config = void 0),
          (this.container = void 0),
          (this.renderEventFired = !1),
          (this.win = t),
          (this.logger = e),
          (this.krakenBidID = r),
          (this.krakenHostname = i),
          (this.slotId = n),
          (this.scriptUrl = o),
          (this.config = a),
          (this.container = s);
      }
      var e = t.prototype;
      return (
        (e.recordEvent = function (t, e) {
          if (
            (void 0 === e && (e = {}),
            t !== ye.Render || !this.renderEventFired)
          ) {
            var r = e,
              i = r.width,
              n = void 0 === i ? 0 : i,
              o = r.height,
              a = void 0 === o ? 0 : o,
              s = r.duration,
              l = void 0 === s ? 0 : s,
              u = r.creativeLoadTime,
              h = void 0 === u ? -1 : u,
              d = r.method,
              p = void 0 === d ? "basic" : d,
              g = r.creativeWidth,
              f = r.creativeHeight,
              v = null;
            switch (t) {
              case ye.Render:
                v = this.getRenderEvent(n, a, l, g, f);
                break;
              case ye.AdTagReady:
                v = this.getAdTagReadyEvent();
                break;
              case ye.CreativeReady:
                v = this.getCreativeReadyEvent(h, p);
                break;
              default:
                return void this.logger.warn("Unknown Kraken event type: " + t);
            }
            try {
              var m = this.getEventURL(v);
              (0, c.Ho)(this.win, m),
                this.logger.debug(
                  "Kraken Metrics: " + t + " event reported",
                  v
                );
            } catch (t) {
              this.logger.error("Kraken Metrics: Failed to report event", t);
            }
            t === ye.Render && (this.renderEventFired = !0);
          }
        }),
        (e.getEventURL = function (t) {
          var e = new URL(
            "https://" + this.krakenHostname + "/api/v1/event/render"
          );
          return (
            Object.keys(t).forEach(function (r) {
              var i = t[r];
              e.searchParams.append(r, String(i));
            }),
            e.toString()
          );
        }),
        (e.getPageDomain = function (t) {
          return new URL(t).hostname;
        }),
        (e.getAdTagReadyEvent = function () {
          var t = this.getBaseEventFlags("adtag_ready"),
            e = this.getPerformanceResourceTiming();
          return an(
            an({}, t),
            {},
            { adTagStartTime: e.startTime, adTagLoadDuration: e.perfDuration }
          );
        }),
        (e.getRenderEvent = function (t, e, r, n, a) {
          var s = this.getBaseEventFlags("render"),
            c = this.getPerformanceResourceTiming(),
            l = (0, o.pO)(this.win),
            u = 0;
          if (this.config) {
            var h = Lr.$4[this.config.format];
            h && (u = h.id);
            var d = Lr.t3.indexOf(this.config.format) >= 0,
              p = "";
            this.container &&
              this.container.getType() &&
              (p = this.container.getType() || "");
            var g = an(
              an({}, s),
              {},
              {
                adTagStartTime: c.startTime,
                adTagLoadDuration: c.perfDuration,
                execution: this.config.execution || "",
                mediatype: d ? "video" : "banner",
                sdk: "",
                container: p,
                pageurl: l,
                top: (0, i.aX)(this.win) ? 0 : 1,
                format: u,
                rw: t,
                rh: e,
                ww: this.win.innerWidth,
                wh: this.win.innerHeight,
                sw: this.win.screen.width,
                sh: this.win.screen.height,
                ratio: this.win.devicePixelRatio
                  ? this.win.devicePixelRatio
                  : -1,
                dur: r,
              }
            );
            return void 0 !== n && (g.cw = n), void 0 !== a && (g.ch = a), g;
          }
          throw new Error(
            "Creative config is required to generate render event"
          );
        }),
        (e.getCreativeReadyEvent = function (t, e) {
          var r = this.getBaseEventFlags("creative_ready"),
            i = this.getPerformanceResourceTiming();
          return an(
            an({}, r),
            {},
            {
              adTagStartTime: i.startTime,
              adTagLoadDuration: i.perfDuration,
              creativeReadyDuration: t,
              method: e,
            }
          );
        }),
        (e.getBaseEventFlags = function (t) {
          var e = (0, o.pO)(this.win);
          return {
            ctx: this.krakenBidID,
            cts: Date.now(),
            domain: this.getPageDomain(e),
            eventtype: t,
            sender: 0,
            slotId: this.slotId,
            adTagVersion: "10.9.0-kat-7484-test",
          };
        }),
        (e.getPerformanceResourceTiming = function () {
          var t = this;
          try {
            var e = this.win.performance;
            if (e && e.getEntriesByType) {
              var r = e.getEntriesByType("resource").find(function (e) {
                return e.name === t.scriptUrl;
              });
              if (r)
                return {
                  startTime: Math.round(r.startTime),
                  perfDuration: Math.round(r.duration),
                };
            }
          } catch (t) {}
          return { startTime: 0, perfDuration: -1 };
        }),
        t
      );
    })();
    function cn(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, i);
      }
      return r;
    }
    function ln(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2
          ? cn(Object(r), !0).forEach(function (e) {
              (0, T.A)(t, e, r[e]);
            })
          : Object.getOwnPropertyDescriptors
          ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
          : cn(Object(r)).forEach(function (e) {
              Object.defineProperty(
                t,
                e,
                Object.getOwnPropertyDescriptor(r, e)
              );
            });
      }
      return t;
    }
    var un = new l.wm("AdTag"),
      hn = (function () {
        function t(t, e, r, i) {
          (this.win = void 0),
            (this.logger = void 0),
            (this.creativeFactory = void 0),
            (this.version = void 0),
            (this.adRequests = {}),
            (this.selfUrl = ""),
            (this.AD_METRIC_RATE = 20),
            (this.initPromise = null),
            (this.globalInitPromises = new Map()),
            (this.armedConfigs = new Set()),
            (this.win = t),
            (this.logger = e),
            (this.creativeFactory = r),
            (this.version = i);
        }
        var e = t.prototype;
        return (
          (e.ensureInitialized = (function () {
            var t = (0, V.A)(
              P().mark(function t(e) {
                var r,
                  i = this;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if ((r = I(this.win))) {
                            t.next = 3;
                            break;
                          }
                          return t.abrupt("return");
                        case 3:
                          return (
                            this.armGlobalInit(r),
                            this.initPromise ||
                              (this.initPromise = this.waitForGlobalConfig(
                                r,
                                e
                              ).catch(function (t) {
                                i.logger.error("AdTag init failed:", t);
                              })),
                            (t.next = 7),
                            this.initPromise
                          );
                        case 7:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this
                );
              })
            );
            return function (e) {
              return t.apply(this, arguments);
            };
          })()),
          (e.armGlobalInit = function (t) {
            var e = this;
            this.armedConfigs.has(t) ||
              "function" != typeof t.onGlobalReady ||
              (this.armedConfigs.add(t),
              t.onGlobalReady(function () {
                var r =
                  null == t.getGlobalConfig ? void 0 : t.getGlobalConfig();
                r &&
                  !e.globalInitPromises.has(t) &&
                  e.globalInitPromises.set(
                    t,
                    e.runGlobalInit(r, t).catch(function (t) {
                      e.logger.error("AdTag init failed:", t);
                    })
                  );
              }));
          }),
          (e.waitForGlobalConfig = function (t, e) {
            var r = this;
            return null != t.getGlobalConfig && t.getGlobalConfig()
              ? Promise.resolve()
              : new Promise(function (i) {
                  var n = r.win.setTimeout(function () {
                    var t =
                      "Global Config did not arrive after 500ms, serving without global init";
                    r.logger.error(t),
                      ue(r.logger, Y, t, {
                        slot: e,
                        version: "10.9.0-kat-7484-test",
                      }),
                      i();
                  }, 500);
                  if ("function" != typeof t.onGlobalReady)
                    return r.win.clearTimeout(n), void i();
                  t.onGlobalReady(function () {
                    r.win.clearTimeout(n), i();
                  });
                });
          }),
          (e.runGlobalInit = (function () {
            var t = (0, V.A)(
              P().mark(function t(e, r) {
                var i;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          return (
                            r.pageGlobalInitRun ||
                              ((r.pageGlobalInitRun = !0),
                              de.executeGlobalConditionalCheck(
                                e,
                                this.logger,
                                this.win
                              ),
                              de.executePreloadJS(e, this.logger, this.win),
                              de.executePreloadCSS(e, this.win),
                              e.checkPageVars && e.checkPageVars(this.win)),
                            (t.next = 3),
                            Rr.loadPlugins(this.win, e, this.version)
                          );
                        case 3:
                          (i = t.sent), this.logger.debug(i);
                        case 5:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this
                );
              })
            );
            return function (e, r) {
              return t.apply(this, arguments);
            };
          })()),
          (e.applyPropertyConfig = function (t, e) {
            var r,
              i = this,
              n = I(this.win);
            if (n) {
              (null != (r = t.slots) ? r : []).forEach(function (t) {
                try {
                  n.setSlotConfig(ln(ln({}, t), {}, { kargo_id: e }));
                } catch (t) {
                  i.logger.error(
                    "unable to set slot config for " + e + ", continuing",
                    t
                  );
                }
              });
              try {
                n.setGlobalConfig(t.global);
              } catch (t) {
                this.logger.error("unable to set global config, continuing", t);
              }
            }
          }),
          (e.createAdRequest = function (t, e) {
            var r = null,
              i = null;
            this.logger.debug(
              "New Ad Request for slot " + t + " with params:",
              e
            );
            var n = I(this.win);
            if (
              (t && null != n && n.getSlotConfig && (i = n.getSlotConfig(t)), n)
            )
              if (i) {
                var o = new M.y(this.win, this.logger),
                  a = e && "object" == typeof e ? e : {};
                (r = nn(this.win, this.logger, o, i, a)),
                  (this.adRequests[r.getId()] = r);
              } else
                this.logger.error("No Kargo SlotConfig for '" + t + "' set");
            else this.logger.error("No Kargo Config instance");
            return r;
          }),
          (e.requestAd = (function () {
            var t = (0, V.A)(
              P().mark(function t(e, r) {
                var i, n, o, a, s;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (
                            ((o = this.cleanAdParams(r)).sourceElement ||
                              ((o.sourceElement = pe(
                                e,
                                this.win,
                                o.sourceWindow
                              )),
                              o.sourceElement ||
                                this.reportSourceElementError(e)),
                            (o.positionElement = o.sourceElement),
                            (o.externalId =
                              (null == (i = o.positionElement)
                                ? void 0
                                : i.getAttribute("data-external-id")) ||
                              void 0),
                            (a =
                              null == (n = I(this.win))
                                ? void 0
                                : n.onSlotReady))
                          ) {
                            t.next = 7;
                            break;
                          }
                          return t.abrupt("return", un.errNotSet("Config"));
                        case 7:
                          return (t.next = 9), this.startSlotLoadTimeout(e, a);
                        case 9:
                          if (!t.sent) {
                            t.next = 12;
                            break;
                          }
                          return t.abrupt("return");
                        case 12:
                          if ((s = this.createAdRequest(e, o))) {
                            t.next = 15;
                            break;
                          }
                          return t.abrupt("return");
                        case 15:
                          return t.abrupt("return", this.processAdRequest(s));
                        case 16:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this
                );
              })
            );
            return function (e, r) {
              return t.apply(this, arguments);
            };
          })()),
          (e.startSlotLoadTimeout = function (t, e) {
            var r = this;
            return new Promise(function (i) {
              var n = r.win.setTimeout(function () {
                var e =
                  "Ad Request timed out waiting for Ad Slot (" +
                  t +
                  ") after 2000ms";
                r.logger.error(e),
                  ue(r.logger, K, e, {
                    slot: t,
                    version: "10.9.0-kat-7484-test",
                  }),
                  i(!0);
              }, 2e3);
              e(
                t,
                (0, V.A)(
                  P().mark(function t() {
                    return P().wrap(function (t) {
                      for (;;)
                        switch ((t.prev = t.next)) {
                          case 0:
                            r.win.clearTimeout(n), i(!1);
                          case 2:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                  })
                )
              );
            });
          }),
          (e.cleanAdParams = function (t) {
            var e = ln({}, t);
            return (
              (e.sourceElement = e.source_element || e.sourceElement),
              (e.sourceWindow = e.source_window || e.sourceWindow),
              delete e.source_element,
              delete e.source_window,
              e
            );
          }),
          (e.reportSourceElementError = function (t) {
            ue(this.logger, Ct, "Could not determine source element", {
              slot: t,
              version: "10.9.0-kat-7484-test",
            });
          }),
          (e.processAdRequest = (function () {
            var t = (0, V.A)(
              P().mark(function t(e) {
                var r, i, n, o;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (e) {
                            t.next = 2;
                            break;
                          }
                          return t.abrupt("return");
                        case 2:
                          return (t.prev = 2), (t.next = 5), e.fetchResponse();
                        case 5:
                          if ((r = e.getCreativeConfig())) {
                            t.next = 8;
                            break;
                          }
                          return t.abrupt(
                            "return",
                            un.errNotSet("Creative Config")
                          );
                        case 8:
                          if ((i = e.getSource())) {
                            t.next = 11;
                            break;
                          }
                          throw new Error("Source is null");
                        case 11:
                          return (
                            (n = new he(this.win, i, {
                              slot: r.slot || "unknown",
                              creative: r.creativeId || "",
                              format: r.format || "unknown",
                            })),
                            (o = new ge(e, this.win, this.logger, n)).preDrawJS(
                              r.format,
                              r.slot
                            ),
                            (t.next = 16),
                            this.creativeFactory.createCreative(
                              r,
                              i,
                              this.version
                            )
                          );
                        case 16:
                          if (t.sent) {
                            t.next = 19;
                            break;
                          }
                          return t.abrupt(
                            "return",
                            un.errCant("create creative")
                          );
                        case 19:
                          o.postDrawJS(r.format, r.slot), (t.next = 26);
                          break;
                        case 22:
                          return (
                            (t.prev = 22),
                            (t.t0 = t.catch(2)),
                            this.logger.error(t.t0),
                            t.abrupt(
                              "return",
                              t.t0 instanceof Error
                                ? t.t0
                                : new Error(String(t.t0))
                            )
                          );
                        case 26:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this,
                  [[2, 22]]
                );
              })
            );
            return function (e) {
              return t.apply(this, arguments);
            };
          })()),
          (e.getAd = (function () {
            var t = (0, V.A)(
              P().mark(function t(e, r) {
                var i, n, o, a, s, c, l, u, h, d, p;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          return (
                            "object" != typeof e ||
                              r ||
                              ((e =
                                (null == (s = r = e) ? void 0 : s.kargo_id) ||
                                ""),
                              null == (c = r) || delete c.kargo_id),
                            r || (r = {}),
                            "open" !==
                              (null == (i = r.kraken)
                                ? void 0
                                : i.auction_type) &&
                              be.reportSafeFrame(this.win, this.logger, e),
                            (r.getAdTimestamp = Date.now()),
                            (l = ae(r.branchTestString)),
                            null != (n = r.kraken) &&
                              n.krg_imp_id &&
                              null != (o = r.kraken) &&
                              o.kraken_domain &&
                              new sn(
                                this.win,
                                this.logger,
                                (null == (u = r.kraken)
                                  ? void 0
                                  : u.krg_imp_id) || "",
                                (null == (h = r.kraken)
                                  ? void 0
                                  : h.kraken_domain) || "",
                                e,
                                this.selfUrl
                              ).recordEvent(ye.AdTagReady),
                            (l ||
                              R.isDebugMode(this.win) ||
                              1 ===
                                Math.floor(
                                  Math.random() * this.AD_METRIC_RATE
                                )) &&
                              ((d = {
                                slot: e,
                                branchTestString: r.branchTestString,
                              }),
                              we.reportAdMetric(
                                {
                                  type: "loaded",
                                  version: "10.9.0-kat-7484-test",
                                },
                                d,
                                this.logger
                              )),
                            null != (a = r.kraken) &&
                              a.property_config &&
                              this.applyPropertyConfig(
                                r.kraken.property_config,
                                r.kraken.kargo_id
                              ),
                            (t.next = 10),
                            this.ensureInitialized(e)
                          );
                        case 10:
                          return (t.next = 12), this.requestAd(e, r);
                        case 12:
                          if (!(p = t.sent)) {
                            t.next = 16;
                            break;
                          }
                          throw (
                            (this.logger.warn(
                              "Request for Slot " +
                                e +
                                " Failed with error: " +
                                p.message
                            ),
                            p)
                          );
                        case 16:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this
                );
              })
            );
            return function (e, r) {
              return t.apply(this, arguments);
            };
          })()),
          (e.loadAds = function () {
            var t,
              e = this,
              r = null == (t = this.win) ? void 0 : t.Kargo;
            if (null != r && r.ads && r.ads.length) {
              var i = r.versions || {},
                n = Object.keys(i),
                o = n.length > 0 && i[n[0]].self_url === this.selfUrl,
                a = r.ads,
                s = [],
                c = [];
              for (
                a.forEach(function (t) {
                  var r = S(t.ad_tag_url || "");
                  (r && r === e.selfUrl) || (!r && o) ? s.push(t) : c.push(t);
                }),
                  r.ads = c;
                s.length;

              )
                this.getAd(s.shift()).catch(function (t) {
                  return e.logger.error("loadAds: getAd failed", t);
                });
            }
          }),
          (e.setSelfUrl = function (t) {
            this.selfUrl = S(t);
          }),
          t
        );
      })();
    const dn = hn;
    var pn = { PRODUCTION: "production", STAGING: "staging" },
      gn = function (t, e) {
        return Object.assign(t, { krg_err_code: e });
      },
      fn = function (t) {
        var e,
          r = null == t ? void 0 : t.krg_err_code;
        return "string" == typeof (e = r) && te.includes(e) ? r : void 0;
      },
      vn = ["GoogleActiveViewClass", "GoogleActiveViewElement"],
      mn =
        /<script>(var url|\(function\(\) {var u) = '([\s\S]*?)';[\s\S]*?<\/script>/i,
      kn = /<script>function gen_\d+_debug_ping/i,
      bn = /id="(DfaVisibilityIdentifier_[\s\S]*?)"/i,
      yn = /https?:\/\/(?:www\.)?googleads.g.doubleclick.net\/dbm\/ad\?dbm.*?/i,
      wn = /https?:\/\/(?:www\.)?ad.doubleclick.net\/dbm\/ad\?dbm_*?/i,
      _n = new l.wm("ActiveView"),
      An = (function () {
        function t(t, e) {
          (this.win = void 0),
            (this.logger = void 0),
            (this.activeViewClass = void 0),
            (this.activeViewVisibilityIdentifier = void 0),
            (this.win = t),
            (this.logger = e),
            (this.activeViewClass = ""),
            (this.activeViewVisibilityIdentifier = "");
        }
        var e = t.prototype;
        return (
          (e.isActiveViewWrapped = function (t) {
            for (var e = 0; e < vn.length; e += 1) {
              if (t.indexOf(vn[e]) > 0)
                return (this.activeViewClass = vn[e]), !0;
            }
            return !1;
          }),
          (e.moveUp = function (t, e) {
            var r = e.match(mn);
            if (e.match(kn)) throw _n.errNew("new active-view pixel");
            if (!r) throw _n.errCant("find Active View script tag");
            if (!r[2].match(yn) && !r[2].match(wn))
              throw gn(_n.errInvalid("Active View script URL"), yt);
            var i = document.createElement("script");
            (i.src = r[2]), (t.className += " " + this.activeViewClass);
            var n = e.match(bn);
            if (!n) throw _n.errCant("find Active View visibility identifier");
            (this.activeViewVisibilityIdentifier = n[1]),
              t.setAttribute("id", this.activeViewVisibilityIdentifier),
              f(i, "append", t);
          }),
          (e.remove = function (t) {
            var e;
            try {
              (e = t.replace(' class="' + this.activeViewClass + '"', "")),
                this.activeViewVisibilityIdentifier &&
                  (e = e.replace(
                    ' id="' + this.activeViewVisibilityIdentifier + '"',
                    ""
                  )),
                (e = e.replace(mn, ""));
            } catch (t) {
              throw _n.errCant(
                "remove Active View elements from creative: " + t
              );
            }
            return e;
          }),
          t
        );
      })(),
      Cn = [1, 4],
      En = /[?&]jsCallback=([\w$]+)/,
      xn = function (t) {
        return !(null == t || !t.includes("dvbm.js"));
      },
      Sn = function (t, e) {
        var r = t.document,
          i = !1,
          n = function () {
            var n;
            if (i) return !0;
            var o = r.querySelector(
                'script[src*="doubleverify.com/verify.js"]'
              ),
              a = null == o || null == (n = o.src.match(En)) ? void 0 : n[1];
            return (
              !!a &&
              ((i = !0),
              (function (t, e, r) {
                var i = t,
                  n = function (t) {
                    return function (e) {
                      try {
                        return t.call(this, e);
                      } finally {
                        try {
                          r(e);
                        } catch (t) {}
                      }
                    };
                  };
                "function" != typeof i[e]
                  ? Object.defineProperty(t, e, {
                      configurable: !0,
                      get: function () {},
                      set: function (r) {
                        Object.defineProperty(t, e, {
                          configurable: !0,
                          writable: !0,
                          value: "function" == typeof r ? n(r) : r,
                        });
                      },
                    })
                  : (i[e] = n(i[e]));
              })(t, a, e),
              !0)
            );
          },
          o = new MutationObserver(function () {
            n() && o.disconnect();
          });
        return (
          n() || o.observe(r, { childList: !0, subtree: !0 }),
          function () {
            return o.disconnect();
          }
        );
      };
    var In = {
        findGWDElem: function (t) {
          return t.getElementsByClassName("GoogleActiveViewClass").item(0);
        },
        getDimensions: function (t) {
          return { width: t.clientWidth, height: t.clientHeight };
        },
        setDimensions: function (t, e) {
          (t.style.width = e.width + "px"), (t.style.height = e.height + "px");
        },
        collapse: function (t, e) {
          50 === e && t && t.setAttribute("height", e + "px");
        },
      },
      On = 1230,
      Rn = 300,
      Dn = 744,
      Tn = 250,
      Vn = 460,
      Ln = "core",
      Pn = "flex",
      Mn = "desktop-lighthouse",
      Nn = [Pn, Ln, Mn];
    function Fn(t, e, r, i) {
      var n = t.document.createElement("iframe");
      return (
        (n.style.display = r ? "none" : "block"),
        (n.className = e),
        (n.height = "" + i.height),
        (n.width = "" + i.width),
        (n.style.margin = "0px auto"),
        (n.style.textAlign = "center"),
        (n.style.border = "none"),
        n
      );
    }
    function Bn(t, e) {
      var r = Array.from(t.querySelectorAll(e));
      return r.length
        ? r
        : Array.from(t.querySelectorAll("iframe")).reduce(function (t, r) {
            return r.contentDocument ? t.concat(Bn(r.contentDocument, e)) : t;
          }, []);
    }
    function Un(t, e) {
      var r, i, n;
      (void 0 === e && (e = null),
      (i = t instanceof ho ? t.iframeConfig : t),
      (null == (r = e) ? void 0 : r.format) === Br.B.SIDEKICK)
        ? (i.expansionCheck = !1)
        : ((i.width = "100%"),
          "core" === (null == (n = e) ? void 0 : n.execution) &&
            (i.maxDimension && (i.maxDimension.width = Dn),
            i.minDimension && (i.minDimension.width = Rn)),
          t instanceof ho &&
            t.iframe &&
            (t.iframe.parentElement &&
              ((t.iframe.parentElement.style.width = "100%"),
              (t.iframe.parentElement.style.maxWidth = "100%")),
            (t.iframe.width = "100%")));
    }
    var Hn = {
      getCeltraSize: function (t, e) {
        if (t) {
          var r = t.offsetWidth,
            i = t.offsetHeight;
          return { width: Math.min(e.width, r), height: Math.min(e.height, i) };
        }
        return e;
      },
      getCeltraPaintedSize: function (t) {
        var e,
          r = t.contentDocument;
        if (!r) return null;
        var i = function (t) {
            var e = t.getBoundingClientRect(),
              r = Math.round(Math.max(t.offsetWidth, e.width)),
              i = Math.round(Math.max(t.offsetHeight, e.height));
            return r > 0 && i > 0 ? { width: r, height: i } : null;
          },
          n = r.querySelector(".celtra-ad-v3"),
          o =
            null == n || null == (e = n.celtra)
              ? void 0
              : e.viewabilityObservee;
        if (o) {
          var a = i(o);
          if (a) return a;
        }
        for (
          var s = Bn(r, '.celtra-banner, .celtra-view, [id^="celtra-object-"]'),
            c = 0;
          c < s.length;
          c += 1
        ) {
          var l = i(s[c]);
          if (l) return l;
        }
        return null;
      },
      clampToContainer: function (t, e) {
        return {
          width: e.width ? Math.min(t.width, e.width) : t.width,
          height: e.height ? Math.min(t.height, e.height) : t.height,
        };
      },
      getConfigMinMax: function (t, e) {
        return (
          t.maxDimension &&
            (t.maxDimension.height &&
              (e.height = Math.min(e.height, t.maxDimension.height)),
            t.maxDimension.width &&
              (e.width = Math.min(e.width, t.maxDimension.width))),
          t.minDimension &&
            (t.minDimension.height &&
              (e.height = Math.max(e.height, t.minDimension.height)),
            t.minDimension.width &&
              (e.width = Math.max(e.width, t.minDimension.width))),
          e
        );
      },
      getPlatformAdSize: function (t, e) {
        for (var r, i = 0; i < t.length; i += 1) {
          try {
            var n,
              o,
              a = null;
            if (
              t[i].contentWindow &&
              null != (n = t[i].contentWindow) &&
              n.document
            )
              a = null == (o = t[i].contentWindow) ? void 0 : o.document;
            a && (r = a.querySelector(".kargo-frame, .kargo-view"));
          } catch (t) {}
          if (r) break;
        }
        return r && r.offsetHeight > 0
          ? ((e.height = Math.min(e.height, r.offsetHeight)),
            (e.width = Math.min(e.width, r.offsetWidth)),
            { platformAd: !!r, platformSize: e })
          : { platformAd: !!r, platformSize: void 0 };
      },
    };
    function jn(t) {
      if (t) {
        if (t.includes("celtra-ad-v3")) return "celtra";
        if (
          t.includes("storage.cloud.kargo.com/ad/network/kap/") ||
          t.includes("Kargo.AdPlatform") ||
          t.includes("data:platform,kargo") ||
          t.includes("window.Kargo.Native")
        )
          return "kap";
        if (t.includes("servedbyivo.com")) return "ivo";
      }
      return "";
    }
    var zn = __webpack_require__(5813);
    function Wn(t, e) {
      for (var r = 0; r < e.length; r++) {
        var i = e[r];
        (i.enumerable = i.enumerable || !1),
          (i.configurable = !0),
          "value" in i && (i.writable = !0),
          Object.defineProperty(t, (0, zn.A)(i.key), i);
      }
    }
    function Kn(t, e, r) {
      return (
        e && Wn(t.prototype, e),
        r && Wn(t, r),
        Object.defineProperty(t, "prototype", { writable: !1 }),
        t
      );
    }
    var qn = function (t) {
      var e = null == t ? void 0 : t.baseSize;
      return !!e && "object" == typeof e && e.width > 0 && e.height > 0;
    };
    function Gn(t, e) {
      return t.scaleUnit
        ? Math.ceil((e * t.baseSize.height) / t.baseSize.width)
        : t.baseSize.height;
    }
    function Yn(t, e) {
      var r = (function (t, e, r) {
        var i = function (t, e) {
            return Gn(t, e);
          },
          n = t.filter(function (t) {
            return e >= t.baseSize.width && r >= i(t, e);
          });
        return n.length
          ? [].concat(n).sort(function (t, r) {
              return r.baseSize.width - t.baseSize.width || i(t, e) - i(r, e);
            })[0]
          : [].concat(t).sort(function (t, e) {
              return (
                t.baseSize.width - e.baseSize.width ||
                i(t, t.baseSize.width) - i(e, e.baseSize.width)
              );
            })[0];
      })(t, e, 1 / 0);
      return { width: e, height: Gn(r, e) };
    }
    var Jn = (function () {
        function t(t, e, r) {
          (this.safeFrameWin = void 0),
            (this.creativeWin = void 0),
            (this.reporter = void 0),
            (this.safeFrameWin = t),
            (this.creativeWin = e && e !== t ? e : null),
            (this.reporter = r);
        }
        var e = t.prototype;
        return (
          (e.find = function () {
            for (
              var t = "undefined" != typeof window ? window : null,
                e = [this.creativeWin, this.safeFrameWin, t].filter(function (
                  t,
                  e,
                  r
                ) {
                  return !!t && r.indexOf(t) === e;
                }),
                r = 0;
              r < e.length;
              r += 1
            )
              try {
                var i = e[r].document.querySelector("iframe.kargo-creative");
                if (i) return i;
              } catch (t) {}
            return null;
          }),
          (e.celtraSizes = function () {
            var t = this;
            return (function (t, e) {
              if (null == t || !t.contentDocument) return null;
              for (
                var r = [t.contentWindow],
                  i = t.contentDocument.querySelectorAll("iframe"),
                  n = 0;
                n < i.length;
                n += 1
              )
                r.push(i[n].contentWindow);
              for (var o = 0, a = 0; a < r.length; a += 1)
                try {
                  var s,
                    c = r[a],
                    l =
                      null == c ||
                      null == (s = c.creative) ||
                      null == (s = s.units) ||
                      null == (s = s.banner)
                        ? void 0
                        : s.variants;
                  if (!Array.isArray(l) || !l.length) continue;
                  var u = l.filter(qn).map(function (t) {
                    return { baseSize: t.baseSize, scaleUnit: !!t.scaleUnit };
                  });
                  if (u.length) return u;
                  o += l.length;
                } catch (t) {}
              return o && (null == e || e(o + " entries, none usable")), null;
            })(this.find(), function (e) {
              return t.reportUnreadableSizes(e);
            });
          }),
          (e.celtraTargetAt = function (t) {
            var e = this.celtraSizes();
            return e && t > 0 ? Yn(e, t) : null;
          }),
          (e.resize = function (e, r) {
            var i = this.find();
            i && t.applySize(i, e, r),
              this.iframesUpToSafeFrame().forEach(function (i) {
                return t.applySize(i, e, r);
              });
          }),
          (e.iframesUpToSafeFrame = function () {
            for (
              var t = [],
                e = this.safeFrameWin,
                r = this.creativeWin || this.safeFrameWin,
                i = 0;
              r && r !== e && i < 8;
              i += 1
            ) {
              try {
                var n = r.frameElement;
                if (!n) break;
                t.push(n);
              } catch (t) {
                break;
              }
              var o = r.parent;
              if (!o || o === r) break;
              r = o;
            }
            return t;
          }),
          (t.applySize = function (t, e, r) {
            t.setAttribute("width", String(e)),
              t.setAttribute("height", String(r)),
              (t.style.width = e + "px"),
              (t.style.height = r + "px"),
              (t.style.minWidth = e + "px"),
              (t.style.minHeight = r + "px");
          }),
          (e.reportSizeTimeout = function (t) {
            var e;
            null == (e = this.reporter) ||
              e.reportErrorOnce(
                it,
                "Creative had not reported a size after " + t + " checks"
              );
          }),
          (e.reportUnreadableSizes = function (t) {
            var e;
            null == (e = this.reporter) ||
              e.reportErrorOnce(rt, "Celtra sizes unreadable: " + t);
          }),
          t
        );
      })(),
      Zn = function (t, e) {
        return {
          format: e.format,
          slot: e.slot || "unknown",
          version: "10.9.0-kat-7484-test",
          platform: (0, Ur.uo)(t),
          os: (0, Ur.R0)(t),
          browser: (0, Ur.X5)(t),
          frame_type: "safeframe",
        };
      },
      $n = function (t, e) {
        return Math.abs(t - e) <= 2;
      },
      Xn = function (t, e) {
        return !!t && !!e && $n(t.width, e.width) && $n(t.height, e.height);
      },
      Qn = function (t) {
        return (function (t) {
          return /celtra/i.test(null != t ? t : "");
        })(t)
          ? "celtra"
          : jn(t);
      };
    function to(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, i);
      }
      return r;
    }
    function eo(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2
          ? to(Object(r), !0).forEach(function (e) {
              (0, T.A)(t, e, r[e]);
            })
          : Object.getOwnPropertyDescriptors
          ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
          : to(Object(r)).forEach(function (e) {
              Object.defineProperty(
                t,
                e,
                Object.getOwnPropertyDescriptor(r, e)
              );
            });
      }
      return t;
    }
    var ro = 100,
      io = 2500,
      no = { t: 0, r: 0, b: 0, l: 0 },
      oo = function (t) {
        return Math.max(0, t - 1);
      },
      ao = function (t) {
        return oo(t.t) + oo(t.b) + oo(t.l) + oo(t.r);
      },
      so = function (t) {
        return t.w <= 1 || t.h <= 1;
      },
      co = function (t) {
        return t.self.iv > 0;
      },
      lo = (function () {
        function t(t, e, r, i, n) {
          void 0 === i && (i = io),
            (this.win = void 0),
            (this.frame = void 0),
            (this.reporter = void 0),
            (this.registeredSlot = null),
            (this.expandedByUs = !1),
            (this.statusListeners = new Set()),
            (this.ask = null),
            (this.pending = !1),
            (this.grant = null),
            (this.inFlight = !1),
            (this.sameTargetRefits = 0),
            (this.failedExpandRetries = 0),
            (this.noRoomSince = null),
            (this.isAwaitingNoRoomRecovery = !1),
            (this.ignoredCollapses = 0),
            (this.ignoredCollapsesInView = 0),
            (this.targetProvider = null),
            (this.pollTimer = null),
            (this.expandConfirmTimer = null),
            (this.destroyed = !1),
            (this.geomWaitMs = void 0),
            (this.win = t),
            (this.reporter = e),
            (this.geomWaitMs = i),
            (this.frame = n || new Jn(t, r, e));
        }
        (t.windowWidth = function (t) {
          var e;
          return (
            (null == (e = t.$sf) ||
            null == (e = e.ext) ||
            null == (e = e.geom()) ||
            null == (e = e.win)
              ? void 0
              : e.w) ||
            t.innerWidth ||
            0
          );
        }),
          (t.getSlotHeight = function (t) {
            var e;
            return (
              (null == (e = t.$sf) ||
              null == (e = e.ext) ||
              null == (e = e.geom()) ||
              null == (e = e.self)
                ? void 0
                : e.h) || 0
            );
          }),
          (t.geomViewport = function (t) {
            var e,
              r,
              i,
              n,
              o,
              a,
              s,
              c =
                null == (e = t.$sf) || null == (e = e.ext) || null == e.geom
                  ? void 0
                  : e.geom(),
              l = null == c ? void 0 : c.self,
              u = null == c ? void 0 : c.exp;
            return null != l && l.w && null != l && l.h && u
              ? {
                  width:
                    l.w +
                    (null != (n = u.l) ? n : 0) +
                    (null != (o = u.r) ? o : 0),
                  height:
                    l.h +
                    (null != (a = u.t) ? a : 0) +
                    (null != (s = u.b) ? s : 0),
                }
              : {
                  width:
                    (null == c || null == (r = c.win) ? void 0 : r.w) ||
                    t.innerWidth ||
                    0,
                  height:
                    (null == c || null == (i = c.win) ? void 0 : i.h) ||
                    t.innerHeight ||
                    0,
                };
          });
        var e = t.prototype;
        return (
          (e.viewport = function () {
            return t.geomViewport(this.win);
          }),
          (e.availableWidth = function () {
            var e,
              r = null == (e = this.safeFrameExt) ? void 0 : e.geom();
            if (!(r && r.self.iv > 0)) return t.windowWidth(this.win);
            var i = r.self.xiv > 0 && r.self.xiv <= 1 ? r.self.xiv : 1;
            return Math.round(r.self.w * i) + r.exp.l + r.exp.r;
          }),
          (t.hostHasRoom = function (t) {
            return t.self.iv > 0 || ao(t.exp) > 0;
          }),
          (e.slotBudgetNow = function (t) {
            if (!this.expandedByUs || !this.grant) return t;
            var e = this.grant.offsets;
            return { t: t.t + e.t, r: t.r + e.r, b: t.b + e.b, l: t.l + e.l };
          }),
          (t.computeOffsets = function (t, e, r) {
            var i = Math.max(0, t.width - e.w),
              n = Math.max(0, t.height - e.h),
              o = Math.floor(i / 2),
              a = Math.min(i - Math.min(o, oo(r.l)), oo(r.r)),
              s = Math.min(i - a, oo(r.l)),
              c = Math.min(n, e.h, oo(r.b));
            return { l: s, r: a, t: Math.min(n - c, oo(r.t)), b: c };
          }),
          (e.targetSize = function () {
            return this.frame.celtraTargetAt(this.availableWidth());
          }),
          (e.onStatus = function (t) {
            this.statusListeners.add(t);
          }),
          (e.ensureRegistered = function () {
            var t,
              e = this,
              r = this.safeFrameExt;
            if (r && !this.registeredSlot) {
              var i =
                null == r.geom || null == (t = r.geom()) ? void 0 : t.self;
              i &&
                !so(i) &&
                ((this.registeredSlot = { w: i.w, h: i.h }),
                r.register(i.w, i.h, function (t) {
                  return e.onHostStatus(t);
                }));
            }
          }),
          (e.isPristine = function () {
            return !this.expandedByUs;
          }),
          (e.restoreSlot = function () {
            var t = this.safeFrameExt;
            if (t)
              try {
                t.collapse();
              } catch (t) {
                var e;
                null == (e = this.reporter) ||
                  e.reportErrorOnce(
                    lt,
                    "SafeFrame collapse failed on hover close: " + t
                  );
              }
          }),
          (e.onHostStatus = function (t) {
            var e;
            "expanded" === t &&
              ((this.failedExpandRetries = 0),
              this.clearExpandConfirmTimer(),
              null == (e = this.reporter) || e.reportTimeToSize());
            "failed" === t && this.clearExpandConfirmTimer(),
              "failed" === t &&
                this.expandedByUs &&
                !this.inFlight &&
                this.undoRejectedExpansion(),
              "collapsed" === t &&
                ((this.expandedByUs = !1),
                this.inFlight || this.noteCollapseLanded(this.ignoredCollapses),
                !this.inFlight &&
                  this.ask &&
                  this.grant &&
                  (this.pending = !0)),
              this.statusListeners.forEach(function (e) {
                return e(t);
              });
          }),
          (e.expandTo = function (e, r, i) {
            var n = this,
              o = this.safeFrameExt;
            if (o && !this.destroyed) {
              var a = { width: e, height: r };
              if (
                ((this.ask = { target: a, onGranted: i }),
                (this.pending = !0),
                this.ensureRegistered(),
                !this.expandedByUs)
              )
                return (
                  (this.inFlight = !0),
                  void this.whenGeometryReady(function () {
                    return n.applyExpansion(a);
                  })
                );
              t.hostHasRoom(o.geom()) &&
                ((this.inFlight = !0),
                this.collapseThenRun(function () {
                  return n.applyExpansion(a);
                }));
            }
          }),
          (e.isAtSlot = function () {
            var t,
              e = null == (t = this.safeFrameExt) ? void 0 : t.geom().self,
              r = this.registeredSlot;
            return !!e && !!r && $n(e.w, r.w) && $n(e.h, r.h);
          }),
          (e.collapseThenRun = function (t) {
            var e = this,
              r = this.safeFrameExt;
            if (r) {
              if (this.isAtSlot())
                return this.noteCollapseLanded(this.ignoredCollapses), void t();
              var i = co(r.geom()),
                n = !1,
                o = null,
                a = function (r) {
                  if (!n) {
                    if (((n = !0), o && e.statusListeners.delete(o), r))
                      return (
                        e.noteCollapseLanded(e.ignoredCollapses + 1), void t()
                      );
                    e.noteCollapseIgnored(i), (e.inFlight = !1);
                  }
                };
              (o = function (t) {
                "collapsed" === t ? a(!0) : "failed" === t && a(e.isAtSlot());
              }),
                this.statusListeners.add(o);
              try {
                r.collapse();
              } catch (t) {}
              this.win.setTimeout(function () {
                return a(e.isAtSlot());
              }, 1e3);
            }
          }),
          (e.whenGeometryReady = function (t) {
            var e = this,
              r = function () {
                var t,
                  r = null == (t = e.safeFrameExt) ? void 0 : t.geom();
                return !!r && !so(r.self);
              };
            if (r()) t();
            else {
              var i = 0,
                n = function () {
                  if (!e.destroyed) {
                    i += ro;
                    var o = r();
                    if (o || i >= e.geomWaitMs)
                      return (
                        o || e.reportUnusableSlot(i),
                        e.ensureRegistered(),
                        void t()
                      );
                    e.win.setTimeout(n, ro);
                  }
                };
              this.win.setTimeout(n, ro);
            }
          }),
          (e.reportUnusableSlot = function (t) {
            var e,
              r,
              i =
                null == (e = this.safeFrameExt) || null == (e = e.geom())
                  ? void 0
                  : e.self,
              n = i ? i.w + "x" + i.h : "none";
            null == (r = this.reporter) ||
              r.reportErrorOnce(
                et,
                "SafeFrame slot geometry never became usable after " +
                  t +
                  "ms, sizing from " +
                  n
              );
          }),
          (e.applyExpansion = function (e) {
            this.inFlight = !1;
            var r = this.safeFrameExt;
            if (r && !this.destroyed) {
              var i = r.geom(),
                n = i.self,
                o = i.exp;
              if (n.w && n.h) {
                var a,
                  s = t.computeOffsets(e, n, o),
                  c = s.l,
                  l = s.r,
                  u = s.t,
                  h = s.b;
                if (!(c || l || u || h))
                  return e.width <= n.w && e.height <= n.h
                    ? (null == (a = this.reporter) || a.reportTimeToSize(),
                      void this.recordGrant({ width: n.w, height: n.h }, no, o))
                    : void this.noteNoRoom(i, e);
                r.expand({ t: u, r: l, b: h, l: c, push: !1 }),
                  this.awaitExpandConfirmation(),
                  (this.expandedByUs = !0);
                var d = { width: n.w + c + l, height: n.h + u + h };
                this.resizeFrameElement(d.width, d.height),
                  this.frame.resize(d.width, d.height),
                  this.recordGrant(d, s, o);
              }
            }
          }),
          (e.undoRejectedExpansion = function () {
            var t = this.safeFrameExt;
            if (t) {
              var e,
                r = t.geom(),
                i = r.self,
                n = r.exp,
                o = { width: i.w, height: i.h };
              if (
                ((this.expandedByUs = !1),
                this.resizeFrameElement(o.width, o.height),
                this.frame.resize(o.width, o.height),
                this.failedExpandRetries >= 3)
              )
                return (
                  null == (e = this.reporter) ||
                    e.reportErrorOnce(
                      at,
                      "GAM rejected the expand " +
                        (this.failedExpandRetries + 1) +
                        " times: slot " +
                        i.w +
                        "x" +
                        i.h +
                        ", room t" +
                        n.t +
                        " r" +
                        n.r +
                        " b" +
                        n.b +
                        " l" +
                        n.l
                    ),
                  (this.grant = {
                    size: o,
                    offsets: no,
                    slotBudget: eo({}, n),
                  }),
                  void (this.pending = !1)
                );
              (this.failedExpandRetries += 1),
                (this.grant = null),
                (this.pending = !0);
            }
          }),
          (e.recordGrant = function (t, e, r) {
            var i;
            this.noteRoomGranted(),
              (this.grant = { size: t, offsets: e, slotBudget: eo({}, r) }),
              (this.pending = !1),
              null == (i = this.ask) || null == i.onGranted || i.onGranted(t);
          }),
          (e.noteNoRoom = function (t, e) {
            var r,
              i,
              n = Date.now();
            this.noRoomSince = null != (r = this.noRoomSince) ? r : n;
            var o = n - this.noRoomSince >= 3e3;
            if (!this.isAwaitingNoRoomRecovery && o) {
              var a = t.self,
                s = t.exp;
              (null == (i = this.reporter)
                ? void 0
                : i.reportErrorOnce(
                    nt,
                    "No room to expand: in view " +
                      a.iv +
                      ", slot " +
                      a.w +
                      "x" +
                      a.h +
                      ", room t" +
                      s.t +
                      " r" +
                      s.r +
                      " b" +
                      s.b +
                      " l" +
                      s.l +
                      ", wanted " +
                      e.width +
                      "x" +
                      e.height
                  )) && (this.isAwaitingNoRoomRecovery = !0);
            }
          }),
          (e.awaitExpandConfirmation = function () {
            var t = this;
            this.clearExpandConfirmTimer(),
              (this.expandConfirmTimer = this.win.setTimeout(function () {
                var e, r;
                t.expandConfirmTimer = null;
                var i = null == (e = t.safeFrameExt) ? void 0 : e.geom();
                if (!t.destroyed && i) {
                  var n = i.self,
                    o = i.exp;
                  null == (r = t.reporter) ||
                    r.reportErrorOnce(
                      ht,
                      "GAM did not confirm the expand within 3000ms: in view " +
                        n.iv +
                        ", slot " +
                        n.w +
                        "x" +
                        n.h +
                        ", room t" +
                        o.t +
                        " r" +
                        o.r +
                        " b" +
                        o.b +
                        " l" +
                        o.l
                    );
                }
              }, 3e3));
          }),
          (e.clearExpandConfirmTimer = function () {
            null !== this.expandConfirmTimer &&
              (this.win.clearTimeout(this.expandConfirmTimer),
              (this.expandConfirmTimer = null));
          }),
          (e.noteRoomGranted = function () {
            var t;
            this.isAwaitingNoRoomRecovery &&
              null !== this.noRoomSince &&
              (null == (t = this.reporter) ||
                t.reportMetric(
                  "no-room-recovered",
                  Date.now() - this.noRoomSince
                ));
            (this.noRoomSince = null), (this.isAwaitingNoRoomRecovery = !1);
          }),
          (e.noteCollapseIgnored = function (t) {
            var e, r;
            this.ignoredCollapses += 1;
            var i = null == (e = this.safeFrameExt) ? void 0 : e.geom();
            if (!!i && t && co(i)) {
              if (
                ((this.ignoredCollapsesInView += 1),
                3 === this.ignoredCollapsesInView)
              ) {
                var n = this.registeredSlot,
                  o = n ? n.w + "x" + n.h : "none";
                null == (r = this.reporter) ||
                  r.reportErrorOnce(
                    st,
                    "GAM ignored 3 collapses in a row while in view: frame " +
                      i.self.w +
                      "x" +
                      i.self.h +
                      ", registered " +
                      o
                  );
              }
            } else this.ignoredCollapsesInView = 0;
          }),
          (e.noteCollapseLanded = function (t) {
            var e;
            t > 0 &&
              (null == (e = this.reporter) ||
                e.reportMetric("collapse-retries", t));
            (this.ignoredCollapses = 0), (this.ignoredCollapsesInView = 0);
          }),
          (e.watch = function (t) {
            var e = this;
            this.destroyed ||
              ((this.targetProvider = t),
              null === this.pollTimer &&
                (this.onStatus(function () {
                  return e.check();
                }),
                (this.pollTimer = this.win.setInterval(function () {
                  return e.check();
                }, 1e3))));
          }),
          (e.destroy = function () {
            (this.destroyed = !0),
              this.clearExpandConfirmTimer(),
              null !== this.pollTimer &&
                (this.win.clearInterval(this.pollTimer),
                (this.pollTimer = null)),
              this.statusListeners.clear(),
              (this.targetProvider = null);
          }),
          (e.check = function () {
            var e,
              r,
              i,
              n,
              o = this.safeFrameExt;
            if (o && !this.destroyed && !this.inFlight) {
              var a = o.geom();
              if (!so(a.self)) {
                var s =
                  null !=
                  (e =
                    null == (r = this.targetProvider) ? void 0 : r.call(this))
                    ? e
                    : null == (i = this.ask)
                    ? void 0
                    : i.target;
                if (s) {
                  var c = t.hostHasRoom(a);
                  if (this.pending) {
                    var l;
                    c
                      ? this.expandTo(
                          s.width,
                          s.height,
                          null == (l = this.ask) ? void 0 : l.onGranted
                        )
                      : this.noteNoRoom(a, s);
                  } else {
                    var u = this.refitReason(a, s);
                    if (u) {
                      if ("target-changed" === u) this.sameTargetRefits = 0;
                      else {
                        if (this.sameTargetRefits >= 5) return;
                        this.sameTargetRefits += 1;
                      }
                      c &&
                        this.expandTo(
                          s.width,
                          s.height,
                          null == (n = this.ask) ? void 0 : n.onGranted
                        );
                    }
                  }
                }
              }
            }
          }),
          (e.refitReason = function (t, e) {
            if (!this.ask || !this.grant) return null;
            if (
              this.expandedByUs &&
              this.registeredSlot &&
              $n(t.self.w, this.registeredSlot.w) &&
              $n(t.self.h, this.registeredSlot.h)
            )
              return null;
            if (!Xn(e, this.ask.target)) return "target-changed";
            var r = this.slotBudgetNow(t.exp),
              i = this.grant.slotBudget;
            return $n(r.l, i.l) && $n(r.r, i.r)
              ? (this.ask.target.width - this.grant.size.width > 2 ||
                  this.ask.target.height - this.grant.size.height > 2) &&
                ao(r) - ao(i) > 2
                ? "deficit-room-grew"
                : null
              : "side-room-moved";
          }),
          (e.expandWhenReady = function () {
            var t = this;
            if (this.safeFrameExt) {
              var e = 0,
                r = function () {
                  if (!t.destroyed) {
                    var i = t.targetSize();
                    if (i)
                      return (
                        t.expandTo(i.width, i.height),
                        void t.watch(function () {
                          return t.targetSize();
                        })
                      );
                    100 === (e += 1) && t.frame.reportSizeTimeout(e),
                      t.win.setTimeout(r, e >= 100 ? 1e3 : ro);
                  }
                };
              r();
            }
          }),
          (e.resizeFrameElement = function (t, e) {
            try {
              var r = "undefined" != typeof window ? window : null,
                i =
                  this.win.frameElement ||
                  (null == r ? void 0 : r.frameElement) ||
                  null;
              i &&
                (i.setAttribute("width", String(t)),
                i.setAttribute("height", String(e)),
                (i.style.width = t + "px"),
                (i.style.height = e + "px"));
            } catch (t) {}
          }),
          Kn(t, [
            {
              key: "safeFrameExt",
              get: function () {
                var t;
                return null == (t = this.win.$sf) ? void 0 : t.ext;
              },
            },
          ])
        );
      })(),
      uo = (function () {
        function t(t, e, r, i, n, o, a, s) {
          var c = this;
          void 0 === s && (s = "celtra"),
            (this.win = void 0),
            (this.contentWin = void 0),
            (this.frame = void 0),
            (this.sizer = void 0),
            (this.onOutcome = void 0),
            (this.reporter = void 0),
            (this.creativeType = void 0),
            (this.hasCreativeUsedMraid = !1),
            (this.usingPageListener = !1),
            (this.firstSizeReported = !1),
            (this.lastRequestedSize = null),
            (this.state = "default"),
            (this.listeners = {}),
            (this.runwayDims = null),
            (this.grantedSize = null),
            (this.sizingLoopActive = !1),
            (this.destroyed = !1),
            (this.getVersion = function () {
              return "3.0";
            }),
            (this.getState = function () {
              return (c.hasCreativeUsedMraid = !0), c.state;
            }),
            (this.getPlacementType = function () {
              return "inline";
            }),
            (this.isViewable = function () {
              return !0;
            }),
            (this.supports = function () {
              return !1;
            }),
            (this.getMaxSize = function () {
              return c.viewport();
            }),
            (this.getScreenSize = function () {
              return c.viewport();
            }),
            (this.getCurrentPosition = function () {
              if ("expanded" === c.state) {
                var t = c.viewport();
                return { x: 0, y: 0, width: t.width, height: t.height };
              }
              var e = c.frame.find();
              if (e) {
                var r = e.getBoundingClientRect();
                if (r.width > 0)
                  return {
                    x: 0,
                    y: 0,
                    width: Math.round(r.width),
                    height: Math.round(r.height),
                  };
              }
              return {
                x: 0,
                y: 0,
                width: lo.windowWidth(c.win),
                height: lo.getSlotHeight(c.win),
              };
            }),
            (this.getDefaultPosition = function () {
              return c.getCurrentPosition();
            }),
            (this.getExpandProperties = function () {
              var t = c.viewport();
              return {
                width: t.width,
                height: t.height,
                useCustomClose: !1,
                isModal: !0,
              };
            }),
            (this.setExpandProperties = function () {}),
            (this.getResizeProperties = function () {
              return {};
            }),
            (this.setResizeProperties = function () {}),
            (this.useCustomClose = function () {}),
            (this.unload = function () {}),
            (this.resize = function () {}),
            (this.addEventListener = function (t, e) {
              c.hasCreativeUsedMraid = !0;
              var r = c.listeners[t] || (c.listeners[t] = []);
              r.indexOf(e) < 0 && r.push(e),
                c.win.setTimeout(function () {
                  if (!((c.listeners[t] || []).indexOf(e) < 0))
                    if ("ready" === t) e();
                    else if ("viewableChange" === t) e(!0);
                    else if ("exposureChange" === t) {
                      var r = c.getCurrentPosition();
                      e(
                        100,
                        { x: r.x, y: r.y, width: r.width, height: r.height },
                        null
                      );
                    }
                }, 0);
            }),
            (this.removeEventListener = function (t, e) {
              var r = c.listeners[t],
                i = r ? r.indexOf(e) : -1;
              r && i > -1 && r.splice(i, 1);
            }),
            (this.open = function (t) {
              t && c.win.open(t, "_blank");
            }),
            (this.expand = function () {
              var t, e, r;
              if (null != (t = c.win.$sf) && t.ext && "expanded" !== c.state) {
                var i = c.frame.find();
                if (i && !c.runwayDims) {
                  var n = i.getBoundingClientRect();
                  c.runwayDims = {
                    width: Math.round(n.width),
                    height: Math.round(n.height),
                  };
                }
                (c.state = "expanded"),
                  null == (e = c.reporter) || e.setMraidState(c.state),
                  null == (r = c.reporter) || r.reportMetric("mraid-expand"),
                  c.fire("stateChange", c.state),
                  c.grant(c.viewport());
              }
            }),
            (this.close = function () {
              var t, e;
              "expanded" === c.state &&
                ((c.state = "default"),
                null == (t = c.reporter) || t.setMraidState(c.state),
                null == (e = c.reporter) || e.reportMetric("mraid-close"),
                c.runwayDims && c.grant(c.runwayDims),
                c.fire("stateChange", c.state),
                c.runwayDims &&
                  c.fire(
                    "sizeChange",
                    c.runwayDims.width,
                    c.runwayDims.height
                  ));
            }),
            (this.win = t),
            (this.contentWin = e || t),
            (this.frame = i),
            (this.sizer = r),
            (this.onOutcome = o),
            (this.reporter = a),
            (this.creativeType = s),
            n &&
              n.then(function (t) {
                return c.takePageListenerSizer(t);
              });
        }
        (t.isEligible = function (t) {
          var e;
          return !(null == (e = t.$sf) || !e.ext || t.mraid);
        }),
          (t.relayHeadScript = function () {
            return "window.mraid = window.parent.__krgSfMraidHost;\n(function () {\n  var seed = function (f) {\n    try {\n      if (f && f.tagName === 'IFRAME' && f.contentWindow && !f.contentWindow.mraid) {\n        f.contentWindow.mraid = window.mraid;\n      }\n    } catch (e) {}\n  };\n  var seedAll = function (node) {\n    try {\n      seed(node);\n      if (node.querySelectorAll) {\n        var frames = node.querySelectorAll('iframe');\n        for (var i = 0; i < frames.length; i++) { seed(frames[i]); }\n      }\n    } catch (e) {}\n  };\n  try {\n    new MutationObserver(function (muts) {\n      for (var m = 0; m < muts.length; m++) {\n        for (var n = 0; n < muts[m].addedNodes.length; n++) { seedAll(muts[m].addedNodes[n]); }\n      }\n    }).observe(document.documentElement, { childList: true, subtree: true });\n  } catch (e) {}\n  document.addEventListener('load', function (e) { seed(e.target); }, true);\n})();";
          });
        var e = t.prototype;
        return (
          (e.install = function () {
            var t,
              e,
              r,
              i = this;
            ((this.contentWin.__krgSfMraidHost = this),
            null == (t = this.reporter) || t.setMraidState(this.state),
            !1 ===
              (null == (e = this.win.$sf) ||
              null == (e = e.ext) ||
              null == e.supports ||
              null == (e = e.supports())
                ? void 0
                : e["exp-ovr"])) &&
              (null == (r = this.reporter) ||
                r.reportMetric("no-overlay-expansion"));
            this.sizer.watch(function () {
              return i.wantedSize();
            }),
              this.expandToRenderedContent();
          }),
          (e.destroy = function () {
            (this.destroyed = !0),
              (this.sizingLoopActive = !1),
              this.sizer.destroy();
          }),
          (e.getSizer = function () {
            return this.sizer;
          }),
          (e.takePageListenerSizer = function (t) {
            var e,
              r = this;
            if (t)
              if (!this.destroyed && this.sizer.isPristine()) {
                this.sizer.destroy(),
                  (this.sizer = t),
                  (this.usingPageListener = !0),
                  t.watch(function () {
                    return r.wantedSize();
                  });
                var i =
                  null != (e = this.wantedSize()) ? e : this.lastRequestedSize;
                i && this.grant(i);
              } else {
                var n;
                t.destroy(),
                  this.destroyed ||
                    null == (n = this.onOutcome) ||
                    n.call(this, "postmessage-late");
              }
          }),
          (e.grant = function (t) {
            var e = this;
            (this.lastRequestedSize = t),
              this.sizer.expandTo(t.width, t.height, function (t) {
                var r = !Xn(e.grantedSize, t);
                if (((e.grantedSize = t), !e.firstSizeReported)) {
                  var i, n;
                  if (
                    ((e.firstSizeReported = !0),
                    null == e.onOutcome ||
                      e.onOutcome(e.usingPageListener ? "postmessage" : "api"),
                    e.usingPageListener)
                  )
                    null == (i = e.reporter) || i.reportTimeToSize();
                  if ("celtra" === e.creativeType && !e.hasCreativeUsedMraid)
                    null == (n = e.reporter) ||
                      n.reportErrorOnce(
                        ot,
                        "Creative never called getState or addEventListener before its first size"
                      );
                }
                r &&
                  "expanded" === e.state &&
                  e.fire("sizeChange", t.width, t.height);
              });
          }),
          (e.wantedSize = function () {
            if ("expanded" === this.state) {
              var t = this.viewport();
              return this.grantedSize && $n(t.width, this.grantedSize.width)
                ? this.grantedSize
                : t;
            }
            var e = this.targetSize();
            return (
              e ||
              (this.grantedSize
                ? {
                    width: this.sizer.availableWidth(),
                    height: this.grantedSize.height,
                  }
                : null)
            );
          }),
          (e.targetSize = function () {
            return this.frame.celtraTargetAt(this.sizer.availableWidth());
          }),
          (e.expandToRenderedContent = function () {
            var t = this;
            if (!this.sizingLoopActive) {
              this.sizingLoopActive = !0;
              var e = 0,
                r = null,
                i = 0,
                n = null,
                o = function () {
                  if (t.destroyed || "default" !== t.state)
                    t.sizingLoopActive = !1;
                  else {
                    if (e >= 75) {
                      if (n) return void (t.sizingLoopActive = !1);
                      75 === e && t.frame.reportSizeTimeout(e);
                    }
                    e += 1;
                    var a = t.targetSize();
                    if (a) return t.grant(a), void (t.sizingLoopActive = !1);
                    var s = t.measureRenderedContent();
                    if (s)
                      (i = Xn(r, s) ? i + 1 : 0),
                        (r = s),
                        i >= 3 && !Xn(n, s) && (t.grant(s), (n = s));
                    t.win.setTimeout(o, e > 75 ? 1e3 : 200);
                  }
                };
              o();
            }
          }),
          (e.measureRenderedContent = function () {
            var t,
              e =
                null == (t = this.frame.find()) ||
                null == (t = t.contentDocument)
                  ? void 0
                  : t.body;
            if (!e) return null;
            var r = Math.max(e.scrollHeight, e.offsetHeight);
            return r <= 0
              ? null
              : { width: this.sizer.availableWidth(), height: r };
          }),
          (e.fire = function (t) {
            for (
              var e = arguments.length, r = new Array(e > 1 ? e - 1 : 0), i = 1;
              i < e;
              i++
            )
              r[i - 1] = arguments[i];
            (this.listeners[t] || []).forEach(function (t) {
              try {
                t.apply(void 0, r);
              } catch (t) {}
            });
          }),
          (e.viewport = function () {
            return this.sizer.viewport();
          }),
          t
        );
      })(),
      ho = (function () {
        function t(t, e, r, i, n, o) {
          void 0 === i && (i = null),
            (this.win = void 0),
            (this.logger = void 0),
            (this.iframeConfig = void 0),
            (this.resolvedSource = void 0),
            (this.socialCanvasCreatives = void 0),
            (this.socialEmbedRenderDivId = void 0),
            (this.writeComplete = !1),
            (this.locationElement = null),
            (this.iframe = null),
            (this.canBustOutOfFrame = !0),
            (this.isMRAIDContainer = !1),
            (this.creativeId = null),
            (this.auctionType = void 0),
            (this.vendor = "undefined"),
            (this.currentSize = { width: 0, height: 0 }),
            (this.callbacks = {
              sizeChange: [],
              contentLoad: [],
              error: [],
              dvBlocked: [],
            }),
            (this.dvBlocked = !1),
            (this.AMP_INTERVAL = 100),
            (this.win = t),
            (this.logger = e),
            (this.iframeConfig = r),
            (this.resolvedSource = i),
            (this.socialCanvasCreatives = n),
            (this.socialEmbedRenderDivId = o),
            (this.isMRAIDContainer = Dr(t));
        }
        var e = t.prototype;
        return (
          (e.setLocationElement = function (t) {
            this.locationElement = t;
          }),
          (e.setCreativeApiMacros = function (t) {
            this.iframeConfig.creativeApiMacros = t;
          }),
          (e.setExtraParams = function (t) {
            this.iframeConfig.macros = Object.assign(
              this.iframeConfig.macros || {},
              t
            );
          }),
          (e.setTracking = function (t) {
            this.iframeConfig.tracking = t;
          }),
          (e.setIasTag = function (t) {
            this.iframeConfig.macros.iasTag = t;
          }),
          (e.setCreativeId = function (t) {
            this.creativeId = t;
          }),
          (e.setAuctionType = function (t) {
            this.auctionType = t;
          }),
          (e.setVendor = function (t) {
            this.vendor = t || "undefined";
          }),
          (e.setWrapper_height_offset = function (t) {
            this.iframeConfig.macros.wrapper_height_offset = t;
          }),
          (e.onSizeChange = function (t) {
            this.callbacks.sizeChange.indexOf(t) < 0 &&
              this.callbacks.sizeChange.push(t);
          }),
          (e.onContentLoad = function (t) {
            this.callbacks.contentLoad.indexOf(t) < 0 &&
              this.callbacks.contentLoad.push(t);
          }),
          (e.onError = function (t) {
            this.callbacks.error.indexOf(t) < 0 && this.callbacks.error.push(t);
          }),
          (e.onDvBlocked = function (t) {
            var e = this.callbacks.dvBlocked;
            e.indexOf(t) < 0 && e.push(t);
          }),
          (e.watchDvBlocking = function (t) {
            var e = this;
            Sn(t, function (t) {
              var r;
              !e.dvBlocked &&
                ((r = t.ResultID), Cn.includes(r)) &&
                ((e.dvBlocked = !0),
                e.logger.debug(
                  "Creative blocked by DV (ResultID " + t.ResultID + ")"
                ),
                e.callbacks.dvBlocked.forEach(function (r) {
                  try {
                    r(t);
                  } catch (t) {
                    e.logger.debug("onDvBlocked callback failed: " + t);
                  }
                }));
            });
          }),
          (e.checkCreativeSize = function (t) {
            var e,
              r = this;
            if (this.iframe && this.iframe.contentDocument) {
              var i = this.iframe.contentDocument.body;
              if (i) {
                var n = {
                  width: Math.max(i.scrollWidth, i.offsetWidth, i.clientWidth),
                  height: Math.max(
                    i.scrollHeight,
                    i.offsetHeight,
                    i.clientHeight
                  ),
                };
                if (t) {
                  var o = this.iframe.contentDocument.documentElement;
                  n = {
                    width: Math.max(
                      o.scrollWidth,
                      o.offsetWidth,
                      o.clientWidth
                    ),
                    height: Math.max(
                      o.scrollHeight,
                      o.offsetHeight,
                      o.clientHeight
                    ),
                  };
                }
                if (
                  ((n.width = Math.min(n.width, this.win.innerWidth)),
                  this.iframeConfig.fullHeight ||
                    (n.height = Math.min(n.height, this.win.innerHeight)),
                  "none" ===
                    (null == (e = this.iframe) ? void 0 : e.style.display))
                ) {
                  var a = this.iframe.previousElementSibling;
                  if (a) {
                    var s = In.findGWDElem(a);
                    if (s) {
                      var c = In.getDimensions(s);
                      In.setDimensions(a, c),
                        In.collapse(this.locationElement, c.height),
                        (n = c);
                    }
                  }
                }
                var l = i.querySelector(".celtra-ad-v3");
                l && (n = Hn.getCeltraSize(l, n));
                var u = i.querySelectorAll("iframe"),
                  h = Hn.getPlatformAdSize(u, n),
                  d = h.platformAd,
                  p = h.platformSize;
                p && (n = p);
                var g =
                  this.iframe.contentDocument.getElementById(
                    "fabrik-outstream"
                  );
                if (
                  (g && (n = { width: g.clientWidth, height: g.clientHeight }),
                  ((n = Hn.getConfigMinMax(this.iframeConfig, n)).height +=
                    parseInt(i.style.paddingTop || "0", 10) +
                    parseInt(i.style.paddingBottom || "0", 10)),
                  (n.width +=
                    parseInt(i.style.paddingLeft || "0", 10) +
                    parseInt(i.style.paddingRight || "0", 10)),
                  n.width !== this.currentSize.width ||
                    n.height !== this.currentSize.height)
                ) {
                  var f;
                  if (d) this.locationElement.style.maxWidth = n.width + "px";
                  this.isMRAIDContainer ||
                    "Lighthouse" ===
                      (null == (f = this.iframeConfig.macros)
                        ? void 0
                        : f.format) ||
                    ((this.iframe.width = n.width.toString()),
                    (this.iframe.height = n.height.toString())),
                    (this.currentSize.width = n.width),
                    (this.currentSize.height = n.height),
                    this.callbacks.sizeChange.forEach(function (t) {
                      t(r.currentSize.width, r.currentSize.height);
                    });
                }
              }
            }
          }),
          (e.monitor = function (t) {
            var e = this,
              r = function () {
                e.checkCreativeSize(t);
                var n = e.win.requestAnimationFrame(r);
                e.iframe &&
                  !(0, i.t2)(e.iframe, e.win.document.body) &&
                  e.win.cancelAnimationFrame(n);
              };
            this.iframeConfig.expansionCheck && r();
          }),
          (e.fireBlockedTracker = function () {
            var t = this;
            if (
              this.iframeConfig &&
              this.iframeConfig.tracking &&
              this.iframeConfig.tracking.blocked
            ) {
              var e = this.iframeConfig.tracking.blocked;
              Array.isArray(e) &&
                e.length &&
                e.forEach(function (e) {
                  return (0, c.Ho)(t.win, e);
                });
            }
          }),
          (e.getFrame = function () {
            return this.iframe;
          }),
          (e.adContainerFailureReport = function () {
            var t = gn(
              new l.qw("Ad Container removed before Ad could display"),
              ft
            );
            we.reportAdMetric(
              {
                type: "failure",
                version: "10.9.0-kat-7484-test",
                errCode: "ad-contr-rmvd",
              },
              this.iframeConfig,
              this.logger
            ),
              this.callbacks.error.forEach(function (e) {
                return e(t);
              });
          }),
          (e.heavyAdIntervention = function () {
            var t = this;
            (0, i.gh)(this.win) ||
              ((0, i.sk)(window).onmessage = function (e) {
                try {
                  var r = JSON.parse(e.data);
                  if ("HeavyAdIntervention" === r.id) {
                    var i,
                      n,
                      o,
                      a,
                      s = new he(
                        t.win,
                        t.resolvedSource || { logger: t.logger }
                      ),
                      c = {
                        creative:
                          (null == (i = t.iframeConfig.macros)
                            ? void 0
                            : i.creative) || void 0,
                        format:
                          null == (n = t.iframeConfig.macros)
                            ? void 0
                            : n.format,
                        slot:
                          null == (o = t.iframeConfig.macros) ? void 0 : o.slot,
                        version:
                          null == (a = t.iframeConfig.macros)
                            ? void 0
                            : a.adTagVersion,
                        vendor: t.vendor,
                      };
                    s.report(bt, "Ad blocked by browser: " + r.message, c),
                      t.fireBlockedTracker();
                  }
                } catch (t) {}
              });
          }),
          (e.assignMacros = function (t, e) {
            if (
              (this.iframeConfig.macros ||
                this.iframeConfig.creativeApiMacros) &&
              (t.Kargo || (t.Kargo = {}),
              this.iframeConfig.macros &&
                (t.Kargo.PlatformMacros = this.iframeConfig.macros),
              this.iframeConfig.creativeApiMacros)
            ) {
              t.Kargo.CreativeApi = {};
              var r = this.iframeConfig.creativeApiMacros.macroConfig;
              if (r) {
                var i = new Si(this.win, this.logger, r.slotId);
                if (
                  ((t.Kargo.CreativeApi.parseCreativeHTML = function (t) {
                    return i.replaceAllMacros(t, r);
                  }),
                  e)
                ) {
                  var n = t.Kargo.PlatformMacros;
                  t.Kargo.PlatformMacros = JSON.parse(
                    i.replaceAllMacros(JSON.stringify(n), r)
                  );
                } else if (t.Kargo.PlatformMacros && bi(r.inAppMacros)) {
                  var o = JSON.stringify(t.Kargo.PlatformMacros),
                    a = i.replaceInAppMacros(o, r.inAppMacros);
                  a !== o && (t.Kargo.PlatformMacros = JSON.parse(a));
                }
              }
              var s = this.iframeConfig.creativeApiMacros.apiMethods;
              s && Object.assign(t.Kargo.CreativeApi, s);
            }
          }),
          (e.determineCanBustOutOfFrame = function (t) {
            return (
              "open" !== this.auctionType ||
              !!(
                t.includes("data:platform,kargo") ||
                t.includes("window.Kargo.Native")
              )
            );
          }),
          (e.addBodyStyles = function (t, e) {
            var r =
              "margin: 0px; padding: 0px; overflow: hidden; line-height: 0; font-size: 0;";
            this.iframeConfig.maxDimension &&
              (this.iframeConfig.maxDimension.height &&
                (r +=
                  "max-height: " +
                  this.iframeConfig.maxDimension.height +
                  "px;"),
              this.iframeConfig.maxDimension.width &&
                (r +=
                  "max-width: " +
                  this.iframeConfig.maxDimension.width +
                  "px;")),
              this.iframeConfig.customCss && (r += this.iframeConfig.customCss),
              this.logger.debug(
                "Creative is allowed to bust out of frame: " +
                  this.canBustOutOfFrame
              );
            var i = "window.inDapIF = " + this.canBustOutOfFrame + ";",
              n = this.win.__krgSfMraidHost;
            this.isMRAIDContainer
              ? (i += "window.mraid = window.parent.mraid;")
              : n && (i += uo.relayHeadScript()),
              t.write(
                '<html><head><script type="text/javascript">' +
                  i +
                  '</script></head><body style="' +
                  r +
                  '">' +
                  e +
                  "</body></html>"
              ),
              t.close();
          }),
          (e.write = function (t) {
            var e,
              r,
              i = this;
            this.logger.debug("Writing Ad Content in iframe"),
              (this.vendor =
                (null == (e = this.resolvedSource)
                  ? void 0
                  : e.kargoCreativeData.vendor) || jn(t));
            var n = this.iframeConfig,
              o = n.hide,
              a = n.width,
              s = n.height;
            if (
              ((this.iframe = Fn(this.win, "kargo-creative", o, {
                width: null != a ? a : 0,
                height: null != s ? s : 0,
              })),
              this.isMRAIDContainer &&
                ((this.iframe.height = "100%"), (this.iframe.width = "100%")),
              (this.canBustOutOfFrame = this.determineCanBustOutOfFrame(t)),
              this.canBustOutOfFrame ||
                (this.iframe.sandbox =
                  "allow-forms allow-pointer-lock allow-scripts allow-top-navigation-by-user-activation allow-same-origin allow-popups allow-popups-to-escape-sandbox"),
              this.socialEmbedRenderDivId &&
                ((this.locationElement = this.win.document.querySelector(
                  "#" + this.socialEmbedRenderDivId
                )),
                this.logger.debug(
                  "Writing iframe into " +
                    this.socialEmbedRenderDivId +
                    " element"
                )),
              null == (r = this.locationElement) || r.appendChild(this.iframe),
              this.socialCanvasCreatives)
            ) {
              var c = this.socialCanvasCreatives.companion;
              null != c &&
                c.renderDiv &&
                c.creative &&
                (!(function (t, e, r) {
                  var i,
                    n = e.creative,
                    o = e.dimensions,
                    a = e.renderDiv,
                    s = { width: +o.width, height: +o.height },
                    c = Fn(t, "kargo-companion-creative", r, s),
                    l = t.document.querySelector("#" + a);
                  l &&
                    (l.appendChild(c),
                    null == (i = c.contentWindow) ||
                      i.document.write(
                        '<html><head><script type="text/javascript">window.inDapIF = true;</script></head><body style="' +
                          (function (t) {
                            return (
                              "margin: 0px; padding: 0px; overflow: hidden;   height: " +
                              t.height +
                              "px; width: " +
                              t.width +
                              "px"
                            );
                          })(s) +
                          '">' +
                          n +
                          "</body></html>"
                      ));
                })(this.win, c, this.iframeConfig.hide),
                this.logger.debug(
                  "Writing Companion in iframe appended to         " +
                    c.renderDiv +
                    " element"
                ));
            }
            if (this.iframe.contentWindow) {
              var l = function () {
                var e, r;
                i.logger.debug("Ad Content Initial Load Complete"),
                  null == (e = i.iframe) || e.removeEventListener("load", l),
                  i.callbacks.contentLoad.forEach(function (t) {
                    return t();
                  });
                var n =
                  null == (r = i.iframe) || null == (r = r.contentWindow)
                    ? void 0
                    : r.document.body;
                if (
                  (i.vendor ||
                    (i.vendor = jn(null == n ? void 0 : n.innerHTML)),
                  n && "open" === i.auctionType)
                ) {
                  var o;
                  i.vendor = "open";
                  var a = new RegExp(Zr, "g");
                  if (
                    /krg_ad_info/g.test(n.innerHTML) ||
                    a.test(n.innerHTML) ||
                    a.test(t) ||
                    (null == (o = i.resolvedSource) ? void 0 : o.kargoCreative)
                  )
                    new he(
                      i.win,
                      i.resolvedSource || { logger: i.logger }
                    ).report(mt, "Kargo creative found in Open");
                }
              };
              this.iframe.addEventListener("load", l),
                this.heavyAdIntervention();
              var u = this.iframe.contentWindow;
              this.assignMacros(u, t.includes(Zr)),
                t.indexOf("dcmads") > 0 &&
                  (this.iframeConfig.customCss += "text-align: center"),
                this.addBodyStyles(u.document, t),
                xn(t) && this.watchDvBlocking(u);
              var h =
                t.indexOf(
                  "https://adsdk.microsoft.com/native-to-display/sdk.js"
                ) > 0;
              this.monitor(h);
            } else this.adContainerFailureReport();
          }),
          t
        );
      })(),
      po = (function () {
        function t(t, e) {
          (this.templateName = void 0),
            (this.overrideTemplateURL = void 0),
            (this.content = ""),
            (this.css = ""),
            (this.macros = {}),
            (this.templateName = t),
            (this.overrideTemplateURL = e);
        }
        var e = t.prototype;
        return (
          (e.getHTML = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e, r, i, n, o;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (!this.content) {
                            t.next = 2;
                            break;
                          }
                          return t.abrupt("return", this.content);
                        case 2:
                          return (
                            (t.next = 4), this.fetchContent(this.templateURL())
                          );
                        case 4:
                          return (
                            (e = (e = t.sent).replace(
                              "$\\[VAST_XML]",
                              "$[VAST_XML]"
                            )),
                            (r = new DOMParser()),
                            (i = r.parseFromString(
                              this.replaceMacros(e),
                              "text/html"
                            )),
                            this.css &&
                              (((n = i.createElement("style")).innerHTML =
                                this.css),
                              i.getElementsByTagName("body")[0].appendChild(n)),
                            i.head.childNodes.length &&
                              ((o = i.body).prepend.apply(o, i.head.childNodes),
                              (i.head.innerHTML = "")),
                            t.abrupt("return", i.body.innerHTML)
                          );
                        case 11:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          (e.setVastXML = function (t) {
            this.macros.ENCODED_VAST_XML = btoa(
              unescape(encodeURIComponent(t))
            );
          }),
          (e.setMacroValue = function (t, e) {
            this.macros[t] = e;
          }),
          (e.templateURL = function () {
            return this.overrideTemplateURL
              ? this.overrideTemplateURL
              : "https://storage.cloud.kargo.com/ad/network/tag/templates/" +
                  this.templateName +
                  ".html";
          }),
          (e.fetchContent = (function () {
            var t = (0, V.A)(
              P().mark(function t(e) {
                var r;
                return P().wrap(function (t) {
                  for (;;)
                    switch ((t.prev = t.next)) {
                      case 0:
                        return (t.next = 2), fetch(e);
                      case 2:
                        if (!(r = t.sent).ok) {
                          t.next = 5;
                          break;
                        }
                        return t.abrupt("return", r.text());
                      case 5:
                        return t.abrupt(
                          "return",
                          Promise.reject(
                            new Error(
                              "fabrik template request failed with status " +
                                r.status +
                                ": " +
                                r.statusText
                            )
                          )
                        );
                      case 6:
                      case "end":
                        return t.stop();
                    }
                }, t);
              })
            );
            return function (e) {
              return t.apply(this, arguments);
            };
          })()),
          (e.replaceMacros = function (t) {
            var e = this;
            return t.replace(/\$[{[]([A-Z_]+)[}\]]/g, function (t, r) {
              return e.macros[r] || "";
            });
          }),
          t
        );
      })(),
      go = (function () {
        function t(t, e, r) {
          void 0 === r && (r = null),
            (this.win = void 0),
            (this.logger = void 0),
            (this.creative = void 0),
            (this.win = t),
            (this.logger = e),
            (this.creative = r);
        }
        var e = t.prototype;
        return (
          (e.isTrackingViewability = function () {
            var t,
              e = !0,
              r = null == (t = I(this.win)) ? void 0 : t.getGlobalConfig;
            if (r) {
              var i = r();
              i &&
                i.isIasViewabilityEnabled &&
                ((e = i.isIasViewabilityEnabled()) ||
                  this.logger.debug(
                    "Not loading IAS because IAS is disabled globally"
                  ));
            }
            if (this.creative) {
              var n = this.creative.getConfig();
              (n.source || {}).type === Jr.PASSBACK &&
                e &&
                (this.logger.debug("Not loading IAS because type is Passback"),
                (e = !1)),
                Lr.t3.indexOf(n.format) > -1 &&
                  n.format !== Br.B.NATIVE_VIDEO_KEY_ART &&
                  n.format !== Br.B.ABA_VIDEO &&
                  e &&
                  (this.logger.debug("Not loading IAS because format is Video"),
                  (e = !1)),
                n.format === Br.B.DESKTOP_SKINS && e && (e = !1),
                void 0 === n.iasTagParams &&
                  e &&
                  (this.logger.debug(
                    "Not adding IAS due to missing config `iasTagParams`"
                  ),
                  (e = !1));
            }
            return e;
          }),
          (e.getTrackingTag = function () {
            var t = this.getTrackingTagUrl();
            return t
              ? '<script type="text/javascript" src="' + t + '"></script>'
              : "";
          }),
          (e.getTrackingTagUrl = function () {
            var t;
            if (null === this.creative) return "";
            var e = this.creative.getConfig();
            if (!e.iasTagParams) return "";
            var r = Xr(e.type, this.creative.rootElement),
              i = !(
                null == (t = this.creative.flourishManifest) ||
                null == (t = t.config) ||
                !t.parallax
              );
            null ===
              (r =
                this.creative.rootElement &&
                (e.format === Br.B.UPTICK || e.format === Br.B.LIGHTHOUSE || i)
                  ? this.creative.rootElement.querySelector(".kargo-ad-content")
                  : r) &&
              (this.logger.debug(
                "Unable to find visibility element, defaulting to root element"
              ),
              (r = this.creative.rootElement));
            var n = "krg-crt-" + e.id;
            r.classList.contains(n) || r.classList.add(n);
            var o = e.iasTagParams.replace(
              /\{\{AdPath\}\}/g,
              encodeURIComponent("." + n)
            );
            return (
              this.logger.debug("Generating IAS tag parameters:", o),
              "https://pixel.adsafeprotected.com/jload?" + o
            );
          }),
          (e.getVideoData = function () {
            if (null === this.creative) return "";
            var t = this.creative.getConfig();
            return t.iasTagParams ? t.iasTagParams : "";
          }),
          (e.buildIasUrl = function () {
            if (null === this.creative) return "";
            var t = this.creative.getConfig().iasTagParams;
            return t
              ? "https://pixel.adsafeprotected.com/jload?" +
                  t.replace(/\{\{AdPath\}\}/gi, "")
              : "";
          }),
          t
        );
      })();
    function fo(t, e) {
      var r =
        ("undefined" != typeof Symbol && t[Symbol.iterator]) || t["@@iterator"];
      if (r) return (r = r.call(t)).next.bind(r);
      if (
        Array.isArray(t) ||
        (r = (function (t, e) {
          if (t) {
            if ("string" == typeof t) return vo(t, e);
            var r = {}.toString.call(t).slice(8, -1);
            return (
              "Object" === r && t.constructor && (r = t.constructor.name),
              "Map" === r || "Set" === r
                ? Array.from(t)
                : "Arguments" === r ||
                  /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
                ? vo(t, e)
                : void 0
            );
          }
        })(t)) ||
        (e && t && "number" == typeof t.length)
      ) {
        r && (t = r);
        var i = 0;
        return function () {
          return i >= t.length ? { done: !0 } : { done: !1, value: t[i++] };
        };
      }
      throw new TypeError(
        "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
      );
    }
    function vo(t, e) {
      (null == e || e > t.length) && (e = t.length);
      for (var r = 0, i = Array(e); r < e; r++) i[r] = t[r];
      return i;
    }
    var mo = new l.wm("Vast"),
      ko = (function () {
        function t(t) {
          (this.win = void 0),
            (this.parsedVastResult = null),
            (this.inputVastStr = null),
            (this.parser = void 0),
            (this.adAspectRatios = {
              "9/16": 0.5625,
              "3/5": 0.6,
              "2/3": 0.66666666,
              "4/5": 0.8,
              "1/1": 1,
              "6/5": 1.2,
              "4/3": 1.33333333,
              "16/9": 1.77777778,
            }),
            (this.win = t),
            (this.parser = this.win.Kargo.VastParser);
        }
        var e = t.prototype;
        return (
          (e.replaceVastMacros = function (t, e) {
            return (
              void 0 === e && (e = {}), this.parser.replaceVastMacros(t, e)
            );
          }),
          (e.filterMediaFiles = function (t, e) {
            var r = this;
            if (!t || !e) return t;
            try {
              var i = new DOMParser().parseFromString(t, "application/xml"),
                n = i.getElementsByTagName("parsererror");
              if (n && n.length) return t;
              var o = Array.from(i.getElementsByTagName("MediaFiles")),
                a = !1;
              return (
                o.forEach(function (t) {
                  Array.from(t.childNodes).forEach(function (i) {
                    if (1 === i.nodeType) {
                      var n = i;
                      if ("MediaFile" === n.localName) {
                        var o = n.getAttribute("width"),
                          s = n.getAttribute("height"),
                          c = o ? parseInt(o, 10) : null,
                          l = s ? parseInt(s, 10) : null;
                        if (null !== c && null !== l)
                          r.findClosestAspectRatio(c, l) === e
                            ? (a = !0)
                            : t.removeChild(n);
                      }
                    }
                  });
                }),
                a ? new XMLSerializer().serializeToString(i) : t
              );
            } catch (e) {
              return t;
            }
          }),
          (e.findClosestAspectRatio = function (t, e) {
            if (!t || !e) return "16/9";
            for (
              var r = t / e,
                i = "16/9",
                n = 1 / 0,
                o = 0,
                a = Object.entries(this.adAspectRatios);
              o < a.length;
              o++
            ) {
              var s = a[o],
                c = s[0],
                l = s[1],
                u = Math.abs(r - l);
              u < n && ((n = u), (i = c));
            }
            return i;
          }),
          (e.parse = (function () {
            var t = (0, V.A)(
              P().mark(function t(e) {
                var r = this;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          return (
                            (this.inputVastStr = e),
                            (t.next = 3),
                            new Promise(function (t, i) {
                              var n = function (e, n) {
                                e
                                  ? i(e)
                                  : n
                                  ? ((r.parsedVastResult = n), t(void 0))
                                  : i(mo.errNew("Vast failed to parse"));
                              };
                              0 == e.trim().indexOf("<")
                                ? r.parser.parseString(e, n)
                                : r.parser.parseUrl(e, n);
                            })
                          );
                        case 3:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this
                );
              })
            );
            return function (e) {
              return t.apply(this, arguments);
            };
          })()),
          (e.getParsedVastUrl = function () {
            var t = null;
            return (
              this.inputVastStr &&
                0 !== this.inputVastStr.trim().indexOf("<") &&
                (t = this.inputVastStr),
              t
            );
          }),
          (e.getParsedVastXml = function () {
            var t = null;
            return (
              this.inputVastStr &&
                0 === this.inputVastStr.trim().indexOf("<") &&
                (t = this.inputVastStr),
              t
            );
          }),
          (e.getUUID = function () {
            return this.parsedVastResult ? this.parsedVastResult.uuid : null;
          }),
          (e.getRawXml = function () {
            return this.parsedVastResult
              ? this.parsedVastResult.rawXmlResults
              : [];
          }),
          (e.getLinearCreative = function () {
            return r()(
              this.parsedVastResult,
              ["ad", "creatives", "linear"],
              null
            );
          }),
          (e.getMediaFiles = function () {
            return r()(this.getLinearCreative(), ["mediaFiles"], []);
          }),
          (e.getVpaidVideo = function () {
            for (
              var t,
                e = null,
                r = 0,
                i = 0,
                n = 0,
                o = fo(this.getMediaFiles());
              !(t = o()).done;

            ) {
              var a = t.value;
              if (
                (!e &&
                  a.apiFramework &&
                  "application/javascript" === a.type &&
                  (e = Object.assign({}, a)),
                a.width && a.height)
              ) {
                var s = a.width * a.height;
                (!n || n < s) && ((r = a.width), (i = a.height), (n = s));
              }
            }
            return e && ((e.width = r), (e.height = i)), e;
          }),
          (e.getNonVpaidSource = function () {
            var t = null,
              e = this.getMediaFiles();
            return e.length && (t = this.getHighestQualityVid(e)), t;
          }),
          (e.getHighestQualityVid = function (t) {
            var e = t.filter(function (t) {
              return "video/mp4" === t.type;
            });
            if (!e.length) return null;
            var r = e.sort(function (t, e) {
              return t.width - e.width;
            });
            return (
              e
                .filter(function (t) {
                  return t && t.width && t.width < 700;
                })
                .filter(function (t) {
                  return t && t.bitrate && t.bitrate >= 400 && t.bitrate <= 700;
                })
                .sort(function (t, e) {
                  return e.width * e.bitrate - t.width * t.bitrate;
                })[0] || r[0]
            );
          }),
          (e.isVpaid = function () {
            return !!this.getVpaidVideo();
          }),
          (e.hasMediaFile = function () {
            for (var t, e = fo(this.getMediaFiles()); !(t = e()).done; ) {
              if (!t.value.apiFramework) return !0;
            }
            return !1;
          }),
          (e.getErrorTrackers = function () {
            return r()(this.parsedVastResult, ["ad", "error"], []);
          }),
          (e.getImpressionTrackers = function () {
            return r()(this.parsedVastResult, ["ad", "impression"], []);
          }),
          (e.getViewableImpressionTrackers = function () {
            return r()(this.parsedVastResult, ["ad", "viewabletracker"], []);
          }),
          (e.getClickThroughUrl = function () {
            return r()(
              this.getLinearCreative(),
              ["videoClicks", "clickThrough"],
              null
            );
          }),
          (e.getClickTrackers = function () {
            return r()(
              this.getLinearCreative(),
              ["videoClicks", "clickTracking"],
              []
            );
          }),
          (e.getLoadTrackers = function () {
            return r()(this.parsedVastResult, ["ad", "extensions", "load"], []);
          }),
          (e.getAdVerificationTrackers = function () {
            return r()(this.parsedVastResult, ["ad", "adverifications"], []);
          }),
          (e.getTrackingEvents = function () {
            return r()(this.getLinearCreative(), ["trackingEvents"], null);
          }),
          (e.getPlaybackEvents = function () {
            return r()(this.getTrackingEvents(), ["playback"], null);
          }),
          (e.getUserEvents = function () {
            return r()(this.getTrackingEvents(), ["userActions"], null);
          }),
          (e.getAdParameters = function () {
            return r()(this.getLinearCreative(), ["adParameters"], null);
          }),
          t
        );
      })(),
      bo = function (t, e) {
        return (t + e) & 4294967295;
      },
      yo = function (t, e, r, i, n, o) {
        return (e = bo(bo(e, t), bo(i, o))), bo((e << n) | (e >>> (32 - n)), r);
      },
      wo = function (t, e, r, i, n, o, a) {
        return yo((e & r) | (~e & i), t, e, n, o, a);
      },
      _o = function (t, e, r, i, n, o, a) {
        return yo((e & i) | (r & ~i), t, e, n, o, a);
      },
      Ao = function (t, e, r, i, n, o, a) {
        return yo(e ^ r ^ i, t, e, n, o, a);
      },
      Co = function (t, e, r, i, n, o, a) {
        return yo(r ^ (e | ~i), t, e, n, o, a);
      },
      Eo = function (t, e) {
        var r = t[0],
          i = t[1],
          n = t[2],
          o = t[3];
        (r = wo(r, i, n, o, e[0], 7, -680876936)),
          (o = wo(o, r, i, n, e[1], 12, -389564586)),
          (n = wo(n, o, r, i, e[2], 17, 606105819)),
          (i = wo(i, n, o, r, e[3], 22, -1044525330)),
          (r = wo(r, i, n, o, e[4], 7, -176418897)),
          (o = wo(o, r, i, n, e[5], 12, 1200080426)),
          (n = wo(n, o, r, i, e[6], 17, -1473231341)),
          (i = wo(i, n, o, r, e[7], 22, -45705983)),
          (r = wo(r, i, n, o, e[8], 7, 1770035416)),
          (o = wo(o, r, i, n, e[9], 12, -1958414417)),
          (n = wo(n, o, r, i, e[10], 17, -42063)),
          (i = wo(i, n, o, r, e[11], 22, -1990404162)),
          (r = wo(r, i, n, o, e[12], 7, 1804603682)),
          (o = wo(o, r, i, n, e[13], 12, -40341101)),
          (n = wo(n, o, r, i, e[14], 17, -1502002290)),
          (i = wo(i, n, o, r, e[15], 22, 1236535329)),
          (r = _o(r, i, n, o, e[1], 5, -165796510)),
          (o = _o(o, r, i, n, e[6], 9, -1069501632)),
          (n = _o(n, o, r, i, e[11], 14, 643717713)),
          (i = _o(i, n, o, r, e[0], 20, -373897302)),
          (r = _o(r, i, n, o, e[5], 5, -701558691)),
          (o = _o(o, r, i, n, e[10], 9, 38016083)),
          (n = _o(n, o, r, i, e[15], 14, -660478335)),
          (i = _o(i, n, o, r, e[4], 20, -405537848)),
          (r = _o(r, i, n, o, e[9], 5, 568446438)),
          (o = _o(o, r, i, n, e[14], 9, -1019803690)),
          (n = _o(n, o, r, i, e[3], 14, -187363961)),
          (i = _o(i, n, o, r, e[8], 20, 1163531501)),
          (r = _o(r, i, n, o, e[13], 5, -1444681467)),
          (o = _o(o, r, i, n, e[2], 9, -51403784)),
          (n = _o(n, o, r, i, e[7], 14, 1735328473)),
          (i = _o(i, n, o, r, e[12], 20, -1926607734)),
          (r = Ao(r, i, n, o, e[5], 4, -378558)),
          (o = Ao(o, r, i, n, e[8], 11, -2022574463)),
          (n = Ao(n, o, r, i, e[11], 16, 1839030562)),
          (i = Ao(i, n, o, r, e[14], 23, -35309556)),
          (r = Ao(r, i, n, o, e[1], 4, -1530992060)),
          (o = Ao(o, r, i, n, e[4], 11, 1272893353)),
          (n = Ao(n, o, r, i, e[7], 16, -155497632)),
          (i = Ao(i, n, o, r, e[10], 23, -1094730640)),
          (r = Ao(r, i, n, o, e[13], 4, 681279174)),
          (o = Ao(o, r, i, n, e[0], 11, -358537222)),
          (n = Ao(n, o, r, i, e[3], 16, -722521979)),
          (i = Ao(i, n, o, r, e[6], 23, 76029189)),
          (r = Ao(r, i, n, o, e[9], 4, -640364487)),
          (o = Ao(o, r, i, n, e[12], 11, -421815835)),
          (n = Ao(n, o, r, i, e[15], 16, 530742520)),
          (i = Ao(i, n, o, r, e[2], 23, -995338651)),
          (r = Co(r, i, n, o, e[0], 6, -198630844)),
          (o = Co(o, r, i, n, e[7], 10, 1126891415)),
          (n = Co(n, o, r, i, e[14], 15, -1416354905)),
          (i = Co(i, n, o, r, e[5], 21, -57434055)),
          (r = Co(r, i, n, o, e[12], 6, 1700485571)),
          (o = Co(o, r, i, n, e[3], 10, -1894986606)),
          (n = Co(n, o, r, i, e[10], 15, -1051523)),
          (i = Co(i, n, o, r, e[1], 21, -2054922799)),
          (r = Co(r, i, n, o, e[8], 6, 1873313359)),
          (o = Co(o, r, i, n, e[15], 10, -30611744)),
          (n = Co(n, o, r, i, e[6], 15, -1560198380)),
          (i = Co(i, n, o, r, e[13], 21, 1309151649)),
          (r = Co(r, i, n, o, e[4], 6, -145523070)),
          (o = Co(o, r, i, n, e[11], 10, -1120210379)),
          (n = Co(n, o, r, i, e[2], 15, 718787259)),
          (i = Co(i, n, o, r, e[9], 21, -343485551)),
          (t[0] = bo(r, t[0])),
          (t[1] = bo(i, t[1])),
          (t[2] = bo(n, t[2])),
          (t[3] = bo(o, t[3]));
      },
      xo = function (t) {
        var e,
          r = [];
        for (e = 0; e < 64; e += 4)
          r[e >> 2] =
            t.charCodeAt(e) +
            (t.charCodeAt(e + 1) << 8) +
            (t.charCodeAt(e + 2) << 16) +
            (t.charCodeAt(e + 3) << 24);
        return r;
      },
      So = "0123456789abcdef".split(""),
      Io = function (t) {
        for (var e = "", r = 0; r < 4; r++)
          e += So[(t >> (8 * r + 4)) & 15] + So[(t >> (8 * r)) & 15];
        return e;
      },
      Oo = function (t) {
        return (function (t) {
          for (var e = 0; e < t.length; e++) t[e] = Io(t[e]);
          return t.join("");
        })(
          (function (t) {
            var e,
              r = t.length,
              i = [1732584193, -271733879, -1732584194, 271733878];
            for (e = 64; e <= t.length; e += 64)
              Eo(i, xo(t.substring(e - 64, e)));
            t = t.substring(e - 64);
            var n = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
            for (e = 0; e < t.length; e++)
              n[e >> 2] |= t.charCodeAt(e) << (e % 4 << 3);
            if (((n[e >> 2] |= 128 << (e % 4 << 3)), e > 55))
              for (Eo(i, n), e = 0; e < 16; e++) n[e] = 0;
            return (n[14] = 8 * r), Eo(i, n), i;
          })(t)
        );
      };
    function Ro(t) {
      return Oo(t);
    }
    "5d41402abc4b2a76b9719d911017c592" !== Oo("hello") &&
      (bo = function (t, e) {
        var r = (65535 & t) + (65535 & e);
        return (((t >> 16) + (e >> 16) + (r >> 16)) << 16) | (65535 & r);
      });
    var Do = "Play mp4 with video player",
      To = "No MP4 available in VAST",
      Vo = new l.wm("Video"),
      Lo = (function () {
        function t() {}
        return (
          (t.submitVastForTranscoding = (function () {
            var e = (0, V.A)(
              P().mark(function e(r, i, n, o) {
                var a, s;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (r && r.getUUID()) {
                            e.next = 2;
                            break;
                          }
                          return e.abrupt("return", !1);
                        case 2:
                          return (e.next = 4), t.isVastSubmitted(r, n);
                        case 4:
                          if (!(a = e.sent)) {
                            e.next = 9;
                            break;
                          }
                          return (
                            (s = new Date(a).toString()),
                            o.debug("VAST already submitted at " + s),
                            e.abrupt("return", !1)
                          );
                        case 9:
                          return (
                            (e.prev = 9),
                            (e.next = 12),
                            t.sendTranscodingRequest(r, i, n)
                          );
                        case 12:
                          return (
                            o.debug("VAST submitted for transcoding"),
                            e.abrupt("return", !0)
                          );
                        case 16:
                          return (
                            (e.prev = 16),
                            (e.t0 = e.catch(9)),
                            o.debug(
                              "Error. VAST not submitted for transcoding: ",
                              e.t0
                            ),
                            e.abrupt("return", !1)
                          );
                        case 20:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  null,
                  [[9, 16]]
                );
              })
            );
            return function (t, r, i, n) {
              return e.apply(this, arguments);
            };
          })()),
          (t.isVastSubmitted = (function () {
            var e = (0, V.A)(
              P().mark(function e(r, i) {
                var n, o;
                return P().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (r) {
                          e.next = 4;
                          break;
                        }
                        throw new Error("No Vast to Transcode");
                      case 4:
                        return (
                          (n = Ro(r.getUUID())),
                          (o = t.getS3Path(i) + "submit/" + n),
                          e.abrupt(
                            "return",
                            new Promise(function (t) {
                              (0, c.Fl)(o, i, 0, !1, function (e, r) {
                                t(e ? null : r.uploadTime);
                              });
                            })
                          )
                        );
                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            );
            return function (t, r) {
              return e.apply(this, arguments);
            };
          })()),
          (t.sendTranscodingRequest = (function () {
            var e = (0, V.A)(
              P().mark(function e(r, i, n) {
                var o, a;
                return P().wrap(function (e) {
                  for (;;)
                    switch ((e.prev = e.next)) {
                      case 0:
                        if (r) {
                          e.next = 4;
                          break;
                        }
                        throw new Error("No Vast to Transcode");
                      case 4:
                        return (
                          (e.next = 6),
                          new Promise(function (t) {
                            (o = {
                              ad_markup: r && r.getRawXml()[0],
                              creative_origin: i.creative_origin,
                              creative_id: i.creative_id,
                              request_origin: "adtag",
                              parameters: { format: i.format },
                            }),
                              t();
                          })
                        );
                      case 6:
                        return (
                          (a = t.getPostUrl(n)),
                          e.abrupt(
                            "return",
                            new Promise(function (t, e) {
                              (0, c.KI)(a, o, n, 0, !1, function (r, i) {
                                r ? e(r) : t(i);
                              });
                            })
                          )
                        );
                      case 8:
                      case "end":
                        return e.stop();
                    }
                }, e);
              })
            );
            return function (t, r, i) {
              return e.apply(this, arguments);
            };
          })()),
          (t.fetchProcessedVastData = (function () {
            var e = (0, V.A)(
              P().mark(function e(r, i, n) {
                var o, a, s;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (i && i.getUUID()) {
                            e.next = 4;
                            break;
                          }
                          throw Vo.errNotSet(
                            "Vast UUID to fetch processed video"
                          );
                        case 4:
                          return (
                            (o = Ro(i.getUUID())),
                            (a =
                              "json" === r
                                ? t.getS3Path(n) + "config/" + o + ".json"
                                : t.getS3Path(n) + "snippet/" + o + ".html"),
                            (s = null),
                            (e.prev = 9),
                            (e.next = 12),
                            new Promise(function (t, e) {
                              (0, c.Fl)(a, n, 0, false, function (r, i) {
                                r ? e(r) : t(i);
                              });
                            })
                          );
                        case 12:
                          (s = e.sent), (e.next = 18);
                          break;
                        case 15:
                          throw (
                            ((e.prev = 15), (e.t0 = e.catch(9)), new Error(Do))
                          );
                        case 18:
                          if (
                            !(
                              ("string" == typeof s && "html" === r) ||
                              ("object" == typeof s && "json" === r)
                            )
                          ) {
                            e.next = 20;
                            break;
                          }
                          return e.abrupt("return", s);
                        case 20:
                          throw gn(
                            Vo.errNew(
                              "Unrecognized Processed Video data response"
                            ),
                            W
                          );
                        case 21:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  null,
                  [[9, 15]]
                );
              })
            );
            return function (t, r, i) {
              return e.apply(this, arguments);
            };
          })()),
          (t.getS3Path = function (t) {
            var e = "https://storage.cloud.kargo.com/ad/kstream/prod/",
              r = (0, o.pO)(t);
            return (
              (0, o.P3)(r, "krg_qa")
                ? (e = "https://storage.cloud.kargo.com/ad/kstream/staging/")
                : (0, o.P3)(r, "krg_dev") &&
                  (e = "https://storage.cloud.kargo.com/ad/kstream/dev/"),
              e
            );
          }),
          (t.getPostUrl = function (t) {
            var e = "https://kstream-service.prod.kargo.com/api/process",
              r = (0, o.pO)(t);
            return (
              (0, o.P3)(r, "krg_qa") &&
                (e = "https://kstream-service.dev.kargo.com/api/process"),
              e
            );
          }),
          t
        );
      })(),
      Po = (function () {
        function t(t, e, r, i, n) {
          (this.win = void 0),
            (this.logger = void 0),
            (this.ias = void 0),
            (this.destroy = void 0),
            (this.version = void 0),
            (this.vast = null),
            (this.html = null),
            (this.creativeType = null),
            (this.resolvedSource = null),
            (this.config = {
              test: !1,
              impressionId: null,
              click_url_prefix: null,
              click_url: null,
              videoPlayerLocation: null,
              endcardUrl: null,
              tracking: {
                start: [],
                firstQuartile: [],
                midpoint: [],
                thirdQuartile: [],
                complete: [],
                mute: [],
                unmute: [],
                replay: [],
                error: [],
                expand: [],
                dismiss: [],
                load: [],
                click: [],
              },
              ias_tag_params: null,
              creative_origin: null,
              creative_id: null,
              disableOutOfViewPause: !1,
              startOnFullView: !1,
              format: null,
              execution: null,
              destroyAd: null,
            }),
            (this.AD_METRIC_RATE = 20),
            (this.win = t),
            (this.logger = e),
            (this.ias = r),
            (this.destroy = i),
            (this.version = n);
        }
        var e = t.prototype;
        return (
          (e.setConfig = (function () {
            var t = (0, V.A)(
              P().mark(function t(e) {
                var i,
                  n,
                  a,
                  s,
                  c,
                  l,
                  u,
                  h,
                  p,
                  g,
                  f = this;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (
                            ((i = e.source),
                            (n = e.settings),
                            (a = n.tracking || {}),
                            (s = null),
                            (c = e.creativeId || null),
                            (l = !1),
                            (u = {}),
                            (t.prev = 6),
                            !i)
                          ) {
                            t.next = 14;
                            break;
                          }
                          if (((s = i.auctionType || null), !i.dealId)) {
                            t.next = 13;
                            break;
                          }
                          return (
                            (t.next = 12), this.confirmStartFullView(i.dealId)
                          );
                        case 12:
                          l = t.sent;
                        case 13:
                          i.creativeId && ((s = "km"), (c = i.creativeId));
                        case 14:
                          return (
                            (h = !1),
                            "true" ===
                              (0, o.P3)((0, o.pO)(this.win), "krg_qa") &&
                              (h = !0),
                            (p = !0),
                            (g = r()(
                              this.win,
                              ["Kargo", "Config", "getGlobalConfig"],
                              null
                            )) &&
                              !g().isIasViewabilityEnabled() &&
                              (p = !1),
                            (u = {
                              test: n.va_test || h || !1,
                              impressionId: e.id,
                              click_url_prefix: n.click_url_prefix || null,
                              click_url: n.click_destination_url || null,
                              videoPlayerLocation:
                                ".kargo-ad-" + e.localId + " .kargo-ad-content",
                              endcardUrl: n.endcard_label,
                              tracking: {
                                start: a.start || [],
                                firstQuartile: a.firstQuartile || [],
                                midpoint: a.midpoint || [],
                                thirdQuartile: a.thirdQuartile || [],
                                complete: a.complete || [],
                                mute: a.mute || [],
                                unmute: a.unmute || [],
                                replay: a.replay || [],
                                error: a.error || [],
                                expand: a.expand || [],
                                dismiss: a.dismiss || [],
                                load: a.receive || [],
                                click: a.click || [],
                              },
                              ias_tag_params:
                                this.ias && p ? this.ias.getVideoData() : null,
                              creative_origin: s,
                              creative_id: c,
                              disableOutOfViewPause:
                                !!n.disable_out_of_view_pause || "open" === s,
                              startOnFullView: l,
                              format: e.format,
                              execution: e.execution,
                              branchTestString: e.branchTestString,
                              destroyAd: function () {
                                return f.destroy();
                              },
                            }),
                            (0, d.h1)(this.config, u),
                            t.abrupt("return")
                          );
                        case 24:
                          (t.prev = 24),
                            (t.t0 = t.catch(6)),
                            this.logger.error(t.t0);
                        case 27:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this,
                  [[6, 24]]
                );
              })
            );
            return function (e) {
              return t.apply(this, arguments);
            };
          })()),
          (e.setSource = function (t) {
            this.resolvedSource = t;
          }),
          (e.confirmStartFullView = (function () {
            var t = (0, V.A)(
              P().mark(function t(e) {
                var r;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (e) {
                            t.next = 2;
                            break;
                          }
                          return t.abrupt("return", !1);
                        case 2:
                          return (
                            (t.prev = 2),
                            (t.next = 5),
                            (0, c.dA)(
                              "https://storage.cloud.kargo.com/ad/network/tag/start-full-view.json",
                              this.win,
                              { timeout: 1e3 }
                            )
                          );
                        case 5:
                          return (
                            (r = t.sent), t.abrupt("return", r.data.includes(e))
                          );
                        case 9:
                          return (
                            (t.prev = 9),
                            (t.t0 = t.catch(2)),
                            this.logger.error(t.t0),
                            t.abrupt("return", !1)
                          );
                        case 13:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this,
                  [[2, 9]]
                );
              })
            );
            return function (e) {
              return t.apply(this, arguments);
            };
          })()),
          (e.parseVast = (function () {
            var t = (0, V.A)(
              P().mark(function t(e) {
                var r = this;
                return P().wrap(function (t) {
                  for (;;)
                    switch ((t.prev = t.next)) {
                      case 0:
                        return t.abrupt(
                          "return",
                          new Promise(function (t, i) {
                            (0, c.k0)(
                              "https://storage.cloud.kargo.com/ad/network/tag/VastParser.min.js",
                              r.win,
                              null,
                              (function () {
                                var n = (0, V.A)(
                                  P().mark(function n(o) {
                                    var a;
                                    return P().wrap(function (n) {
                                      for (;;)
                                        switch ((n.prev = n.next)) {
                                          case 0:
                                            if (!o) {
                                              n.next = 4;
                                              break;
                                            }
                                            i(o), (n.next = 10);
                                            break;
                                          case 4:
                                            return (
                                              (r.vast = new ko(r.win)),
                                              (n.next = 7),
                                              r.vast.parse(e)
                                            );
                                          case 7:
                                            null !=
                                              (a = r.vast.parsedVastResult) &&
                                              null != (a = a.ad) &&
                                              a.wrappers &&
                                              r.vast.parsedVastResult.ad
                                                .wrappers.length &&
                                              r.reportVPAIDWrapper(
                                                r.vast.parsedVastResult.ad
                                                  .wrappers.length
                                              ),
                                              r.reportVideoType(),
                                              t();
                                          case 10:
                                          case "end":
                                            return n.stop();
                                        }
                                    }, n);
                                  })
                                );
                                return function (t) {
                                  return n.apply(this, arguments);
                                };
                              })()
                            );
                          })
                        );
                      case 1:
                      case "end":
                        return t.stop();
                    }
                }, t);
              })
            );
            return function (e) {
              return t.apply(this, arguments);
            };
          })()),
          (e.reportVPAIDWrapper = function (t) {
            (this.config.branchTestString ||
              R.isDebugMode(this.win) ||
              1 === Math.floor(100 * Math.random())) &&
              we.reportAdMetric(
                {
                  value: t,
                  type: "vpaid-wrappers",
                  version: "10.9.0-kat-7484-test",
                },
                this.config,
                this.logger
              );
          }),
          (e.reportVideoType = function () {
            if (
              (this.config.branchTestString ||
                R.isDebugMode(this.win) ||
                1 === Math.floor(Math.random() * this.AD_METRIC_RATE)) &&
              this.resolvedSource.type === Jr.KRAKEN
            ) {
              var t = this.vast.isVpaid() ? "vpaid" : "vast",
                e = {
                  slot: this.resolvedSource.macroUtil.macroConfig.slotId,
                  source: this.resolvedSource,
                  format: this.config.format,
                  branchTestString: this.config.branchTestString,
                };
              we.reportAdMetric(
                {
                  value: 1,
                  type: "video-type",
                  version: "10.9.0-kat-7484-test",
                  videoType: t,
                },
                e,
                this.logger
              );
            }
          }),
          (e.fireErrorTrackers = function (t) {
            var e = this,
              r = this.config.tracking.error;
            if (this.vast) {
              var i = this.vast.getErrorTrackers().map(function (r) {
                return e.vast.replaceVastMacros(r, { errorCode: t });
              });
              r = r.concat(i);
            }
            r.forEach(function (t) {
              return (0, c.Ho)(e.win, t);
            });
          }),
          (e.transcodeVast = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          return (
                            (t.next = 2),
                            Lo.submitVastForTranscoding(
                              this.vast,
                              this.config,
                              this.win,
                              this.logger
                            )
                          );
                        case 2:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          t
        );
      })(),
      Mo = new l.wm("Video"),
      No = (function (t) {
        function e() {
          for (var e, r = arguments.length, i = new Array(r), n = 0; n < r; n++)
            i[n] = arguments[n];
          return (
            ((e =
              t.call.apply(t, [this].concat(i)) ||
              this).nativeVideoKeyArtConfig = {
              video_url: null,
              vpaid_enabled: !1,
              click_url: null,
              tracking: {
                start: [],
                firstQuartile: [],
                midpoint: [],
                thirdQuartile: [],
                complete: [],
                unmute: [],
                mute: [],
                rewind: [],
                click: [],
              },
            }),
            e
          );
        }
        return (
          Ae(e, t),
          (e.prototype.getNativeVideoSnippet = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e, r, i, n, o, a, s;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (!this.vast) {
                            t.next = 27;
                            break;
                          }
                          if (
                            ((e = this.vast),
                            (this.creativeType = Br.B.ABA_VIDEO),
                            e.hasMediaFile() || e.isVpaid())
                          ) {
                            t.next = 7;
                            break;
                          }
                          throw Mo.errGet("MediaFile or VPAID js", "VAST tag");
                        case 7:
                          if ((r = this.vast.getTrackingEvents()))
                            for (i in this.nativeVideoKeyArtConfig.tracking)
                              (n = r.playback[i] || r.userActions[i]) &&
                                (this.nativeVideoKeyArtConfig.tracking[i] =
                                  [].concat(
                                    this.nativeVideoKeyArtConfig.tracking[i],
                                    n
                                  ));
                          if (
                            (this.vast.getClickThroughUrl() &&
                              (this.nativeVideoKeyArtConfig.click_url =
                                this.vast.getClickThroughUrl()),
                            (o = this.vast.getClickTrackers()),
                            (this.nativeVideoKeyArtConfig.tracking.click =
                              this.nativeVideoKeyArtConfig.tracking.click.concat(
                                o
                              )),
                            (this.nativeVideoKeyArtConfig.vpaid_enabled =
                              e.isVpaid()),
                            !e.isVpaid())
                          ) {
                            t.next = 18;
                            break;
                          }
                          (this.nativeVideoKeyArtConfig.vpaid_url =
                            e.getParsedVastUrl()),
                            (this.nativeVideoKeyArtConfig.vpaid_xml = e
                              .getParsedVastXml()
                              .replace(/'/g, '\\"')),
                            (t.next = 24);
                          break;
                        case 18:
                          return (
                            (t.next = 20),
                            Lo.fetchProcessedVastData("json", e, this.win)
                          );
                        case 20:
                          (a = t.sent),
                            (s = a).video &&
                              (this.nativeVideoKeyArtConfig.video_url =
                                s.video.url),
                            s.kstream &&
                              ((this.nativeVideoKeyArtConfig.audio_url =
                                s.kstream.audioUrl),
                              s.kstream.spriteSheetUrls &&
                                (this.nativeVideoKeyArtConfig.sprite =
                                  s.kstream.spriteSheetUrls.default));
                        case 24:
                          return t.abrupt(
                            "return",
                            this.nativeVideoKeyArtConfig
                          );
                        case 25:
                          t.next = 28;
                          break;
                        case 27:
                          throw Mo.errNotSet("VAST tag required for ABA Video");
                        case 28:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          e
        );
      })(Po),
      Fo = (function () {
        function t(t) {
          (this.node = void 0),
            (this.currentSize = void 0),
            (this.callbacks = void 0),
            (this.interval = void 0),
            (this.node = t),
            (this.currentSize = { width: 0, height: 0 }),
            (this.callbacks = { onSizeChange: [] }),
            (this.interval = null);
        }
        var e = t.prototype;
        return (
          (e.onSizeChange = function (t) {
            this.callbacks.onSizeChange.indexOf(t) < 0 &&
              this.callbacks.onSizeChange.push(t);
          }),
          (e.checkSize = function () {
            if (
              this.node.clientWidth !== this.currentSize.width ||
              this.node.clientHeight !== this.currentSize.height
            ) {
              (this.currentSize.width = this.node.clientWidth),
                (this.currentSize.height = this.node.clientHeight);
              for (var t = 0; t < this.callbacks.onSizeChange.length; t++)
                this.callbacks.onSizeChange[t](
                  this.currentSize.width,
                  this.currentSize.height
                );
            }
          }),
          (e.start = function () {
            var t = this;
            this.interval ||
              (this.interval = setInterval(function () {
                t.checkSize();
              }, 100));
          }),
          (e.stop = function () {
            this.interval && clearInterval(this.interval);
          }),
          t
        );
      })(),
      Bo = (function () {
        function t(t, e, r) {
          (this.win = void 0),
            (this.html = void 0),
            (this.css = void 0),
            (this.replacementVars = {}),
            (this.win = t),
            (this.html = e),
            (this.css = r);
        }
        var e = t.prototype;
        return (
          (e.getHtml = function (t, e) {
            var r;
            if ("string" == typeof t) {
              if (0 === (r = t.trim()).indexOf("&lt;")) {
                var i = this.win.document.createElement("div");
                (i.innerHTML = r), (r = i.childNodes[0].nodeValue);
              }
            } else r = e;
            return r;
          }),
          (e.replaceTemplateVars = function (t) {
            var e;
            "html" == t
              ? ((e = this.html), (t = this.html))
              : ((e = this.css), (t = this.css));
            for (var r = /VAR_([A-Z_]*)/g, i = r.exec(t); i; )
              (e =
                void 0 !== this.replacementVars[i[1]] &&
                null !== this.replacementVars[i[1]]
                  ? (0, d.xP)(e, i[0], this.replacementVars[i[1]])
                  : e.replace(i[0], "")),
                (i = r.exec(t));
            return e;
          }),
          (e.setTemplateVar = function (t, e) {
            this.replacementVars[t] = e;
          }),
          (e.setDefaultTemplateVars = function (t, e) {
            this.setTemplateVar("ID", t),
              void 0 !== e && this.setTemplateVar("LOCAL_ID", e.toString());
          }),
          t
        );
      })(),
      Uo = (function () {
        function t() {}
        return (
          (t.getPlatformMacros = function (t, e) {
            var r = {
              start: Array.from(new Set(t.tracking.start)),
              firstQuartile: t.tracking.firstQuartile,
              midpoint: t.tracking.midpoint,
              midQuartile: t.tracking.midpoint,
              thirdQuartile: t.tracking.thirdQuartile,
              complete: t.tracking.complete,
              mute: t.tracking.mute,
              unmute: t.tracking.unmute,
              replay: t.tracking.replay,
              error: t.tracking.error,
              expand: t.tracking.expand,
              dismiss: t.tracking.dismiss,
              clickTrackers: [],
            };
            if (e && ("VideoAnchor" !== t.format || !e.isVpaid())) {
              (r.start = r.start.concat(e.getImpressionTrackers())),
                (r.error = r.error.concat(e.getErrorTrackers())),
                (r.clickTrackers = r.clickTrackers.concat(
                  e.getClickTrackers()
                ));
              var i = e.getClickThroughUrl();
              i && (r.clickUrl = i);
              var n = e.getTrackingEvents();
              n &&
                ((r.start = r.start.concat(n.playback.start)),
                (r.firstQuartile = r.firstQuartile.concat(
                  n.playback.firstQuartile
                )),
                (r.midpoint = r.midpoint.concat(n.playback.midpoint)),
                (r.midQuartile = r.midQuartile.concat(n.playback.midpoint)),
                (r.thirdQuartile = r.thirdQuartile.concat(
                  n.playback.thirdQuartile
                )),
                (r.complete = r.complete.concat(n.playback.complete)),
                (r.mute = r.mute.concat(n.userActions.mute)),
                (r.unmute = r.unmute.concat(n.userActions.unmute)),
                (r.expand = r.expand.concat(n.userActions.playerExpand)),
                (r.dismiss = r.dismiss.concat(n.userActions.skip)));
            }
            return (
              t.disableOutOfViewPause &&
                (r.disableOutOfViewPause = t.disableOutOfViewPause),
              t.click_url && (r.clickUrl = t.click_url),
              t.click_url_prefix &&
                (r.clickUrl
                  ? (r.clickUrl = t.click_url_prefix + r.clickUrl)
                  : (r.clickUrlPrefix = t.click_url_prefix)),
              t.ias_tag_params && (r.iasTagParams = t.ias_tag_params),
              r
            );
          }),
          (t.replacePlatformMacros = function (e, r, i) {
            var n = i,
              o = function (t, e) {
                void 0 === e && (e = !1),
                  n.indexOf(t) < 0 && (e ? (n = t + n) : (n += t));
              };
            e.tracking.load.forEach(function (t) {
              o(
                '<img style="position: absolute; visibility: hidden; left: -9999px; top: 0;" src="' +
                  t +
                  '" />'
              );
            }),
              r &&
                (r.getLoadTrackers().forEach(function (t) {
                  t.indexOf("casalemedia.com/usermatch") > -1
                    ? o(
                        '<iframe style="display: none" src="' +
                          t +
                          '"></iframe>'
                      )
                    : o(
                        '<img style="position: absolute; visibility: hidden; left: -9999px; top: 0;" src="' +
                          t +
                          '" />'
                      );
                }),
                r.getAdVerificationTrackers().forEach(function (t) {
                  o(
                    '<script type="text/javascript" src="' + t + '"></script>',
                    !0
                  );
                }));
            var a = t.getPlatformMacros(e, r),
              s = JSON.stringify(a)
                .replace(/"/g, "&quot;")
                .replace(/'/g, "\\'");
            return (n = (0, d.xP)(n, "{ADTAG_VALUES}", s));
          }),
          t
        );
      })(),
      Ho = new l.wm("Video"),
      jo = (function (t) {
        function e() {
          for (var e, r = arguments.length, i = new Array(r), n = 0; n < r; n++)
            i[n] = arguments[n];
          return (
            ((e = t.call.apply(t, [this].concat(i)) || this).anchorConfig = {
              kstream: {
                spriteSheetUrls: { small: null, large: null },
                audioUrl: null,
              },
              video: {
                url: null,
                width: null,
                height: null,
                hasAudio: !0,
                duration: null,
                ratio: null,
                vastUrl: null,
                vastXml: null,
              },
              companion: { url: null, width: null, height: null },
            }),
            e
          );
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.getVideoAnchorSnippet = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e, r, i, n, o, a, s, c;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (this.vast) {
                            t.next = 2;
                            break;
                          }
                          throw Ho.errNotSet(
                            "VAST tag required for VideoAnchor"
                          );
                        case 2:
                          if (
                            ((e = this.vast),
                            (this.anchorConfig.video.vastUrl =
                              e.getParsedVastUrl()),
                            (this.anchorConfig.video.vastXml =
                              e.getParsedVastXml()),
                            (this.creativeType = "VideoAnchor"),
                            e.hasMediaFile() || e.isVpaid())
                          ) {
                            t.next = 10;
                            break;
                          }
                          throw Ho.errGet("MediaFile or VPAID js", "VAST tag");
                        case 10:
                          if (e.isVpaid()) {
                            t.next = 32;
                            break;
                          }
                          return (
                            (t.prev = 11),
                            (t.next = 14),
                            Lo.fetchProcessedVastData("json", e, this.win)
                          );
                        case 14:
                          (n = t.sent),
                            (o = n).video &&
                              ((this.anchorConfig.video.url = o.video.url),
                              (this.anchorConfig.video.width = o.video.width),
                              (this.anchorConfig.video.height = o.video.height),
                              (this.anchorConfig.video.hasAudio =
                                o.video.hasAudio),
                              (this.anchorConfig.video.duration =
                                o.video.duration),
                              (this.anchorConfig.video.ratio = o.video.ratio)),
                            o.kstream &&
                              ((this.anchorConfig.kstream.audioUrl =
                                o.kstream.audioUrl),
                              o.kstream.spriteSheetUrls &&
                                ((this.anchorConfig.kstream.spriteSheetUrls.small =
                                  o.kstream.spriteSheetUrls.small),
                                (this.anchorConfig.kstream.spriteSheetUrls.large =
                                  o.kstream.spriteSheetUrls.large))),
                            (t.next = 30);
                          break;
                        case 20:
                          if (
                            ((t.prev = 20),
                            (t.t0 = t.catch(11)),
                            !e.getNonVpaidSource())
                          ) {
                            t.next = 29;
                            break;
                          }
                          (a = e.getNonVpaidSource()),
                            (this.anchorConfig.video.url = a.url),
                            (this.anchorConfig.video.width = a.width),
                            (this.anchorConfig.video.height = a.height),
                            (t.next = 30);
                          break;
                        case 29:
                          throw gn(Ho.errNew(To), kt);
                        case 30:
                          t.next = 33;
                          break;
                        case 32:
                          this.creativeType = "VideoPlayer";
                        case 33:
                          return (
                            null != (r = this.vast.parsedVastResult) &&
                              null != (r = r.ad) &&
                              r.creatives.companion &&
                              "Kargo" ===
                                (null == (i = this.vast.parsedVastResult)
                                  ? void 0
                                  : i.ad.system) &&
                              ((s =
                                this.vast.parsedVastResult.ad.creatives
                                  .companion),
                              (this.anchorConfig.companion.url =
                                s.iframeResource),
                              (this.anchorConfig.companion.width = parseInt(
                                s.width
                              )),
                              (this.anchorConfig.companion.height = parseInt(
                                s.height
                              ))),
                            (t.next = 36),
                            this.getVideoAnchorTemplate()
                          );
                        case 36:
                          return (
                            (c = t.sent),
                            (this.html = c),
                            (this.html = this.replaceAnchorMacros(this.html)),
                            t.abrupt("return", this.html)
                          );
                        case 40:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this,
                  [[11, 20]]
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          (r.getTemplateUrl = function () {
            return "alternate-expand" === this.config.execution
              ? "https://storage.cloud.kargo.com/ad/network/kap/video-anchor/video-anchor-test/video-anchor-template-v6.html"
              : this.config.test
              ? "https://storage.cloud.kargo.com/ad/network/tag/video-anchor-test.html"
              : "https://storage.cloud.kargo.com/ad/network/tag/video-anchor-template-v6.html";
          }),
          (r.getVideoAnchorTemplate = function () {
            var t = this,
              e = this.getTemplateUrl();
            return new Promise(function (r, i) {
              (0, c.Fl)(e, t.win, 0, !1, function (t, n) {
                if (t || !n) {
                  var o = Ho.errGet("VideoAnchor template', 'url:  " + e);
                  i(o);
                } else r(n);
              });
            });
          }),
          (r.getAnchorMacros = function () {
            var t = (0, d.h1)({}, this.config, this.anchorConfig);
            t.creative_id && (t.creativeId = t.creative_id);
            var e = (this.vast && this.vast.isVpaid()) || !1;
            if (((t.isVpaid = e), this.vast && !e)) {
              var r = this.vast.getTrackingEvents();
              r &&
                ((t.tracking.start = this.vast
                  .getImpressionTrackers()
                  .concat(t.tracking.start)
                  .concat(r.playback.start)),
                (t.tracking.firstQuartile = t.tracking.firstQuartile.concat(
                  r.playback.firstQuartile
                )),
                (t.tracking.midpoint = t.tracking.midpoint.concat(
                  r.playback.midpoint
                )),
                (t.tracking.thirdQuartile = t.tracking.thirdQuartile.concat(
                  r.playback.thirdQuartile
                )),
                (t.tracking.complete = t.tracking.complete.concat(
                  r.playback.complete
                )),
                (t.tracking.mute = t.tracking.mute.concat(r.userActions.mute)),
                (t.tracking.unmute = t.tracking.unmute.concat(
                  r.userActions.unmute
                )),
                (t.tracking.click = t.tracking.click.concat(
                  this.vast.getClickTrackers()
                )),
                (t.tracking.error = t.tracking.error.concat(
                  this.vast.getErrorTrackers()
                )));
            }
            return t;
          }),
          (r.replaceAnchorMacros = function (t) {
            var e = this.getAnchorMacros(),
              r = encodeURIComponent(JSON.stringify(e))
                .replace(/"/g, "&quot;")
                .replace(/'/g, "\\'"),
              i = t;
            return (
              (i = (0, d.xP)(i, "%%macroConfig%%", r)),
              (i = Uo.replacePlatformMacros(this.config, this.vast, i))
            );
          }),
          e
        );
      })(Po),
      zo = (function () {
        function t(t, e, r) {
          (this.win = void 0),
            (this.logger = void 0),
            (this.version = void 0),
            (this.player = void 0),
            (this.vast = null),
            (this.videoPlayerConfig = null),
            (this.resolvedSource = null),
            (this.isClickable = 0),
            (this.win = t),
            (this.logger = e),
            (this.version = r);
        }
        var e = t.prototype;
        return (
          (e.getVideoPlayerConfig = function (t, e) {
            var r,
              n,
              o = this,
              a = t ? t.getVpaidVideo() : null,
              s = !a && t ? t.getNonVpaidSource() : null,
              c = t ? t.getLinearCreative() : null,
              l = e.click_url;
            !l && t && t.getClickThroughUrl() && (l = t.getClickThroughUrl()),
              l &&
                ((this.isClickable = 1),
                (l = l.replace("[CACHEBUSTING]", this.getCachebustValue())));
            var u = {
                amp_iframe: (0, i.gh)(this.win),
                sidebar_slot: Wr.checkIfSidebarSlot(
                  null == (r = this.resolvedSource)
                    ? void 0
                    : r.creativeData.slot,
                  this.win
                ),
                debug: !1,
                player: { location: e.videoPlayerLocation },
                ias_tag_params: e.ias_tag_params || null,
                autoplay: (0, Ur.Jp)(this.win),
                endcard_url: e.endcardUrl,
                disableOutOfViewPause: e.disableOutOfViewPause,
                startOnFullView: e.startOnFullView,
                adParams: t ? t.getAdParameters() : null,
                destroyAd: e.destroyAd,
                reportErr: function (t) {
                  return o.reportErr(t);
                },
                error: e.tracking.error,
                ad_verifications: t ? t.getAdVerificationTrackers() : [],
                viewableImpressionTrackers: {
                  viewable: t ? t.getViewableImpressionTrackers() : [],
                },
                uuid: e.impressionId || null,
                duration: c && c.duration ? c.duration / 1e3 : null,
                videos: {
                  dimensions: this.getDimensions(t),
                  vpaidUrl: a ? a.url : null,
                  source: s ? s.url : null,
                  click_url: l,
                  tracking: {
                    start: e.tracking.start,
                    firstQuartile: e.tracking.firstQuartile,
                    midpoint: e.tracking.midpoint,
                    thirdQuartile: e.tracking.thirdQuartile,
                    complete: e.tracking.complete,
                    mute: e.tracking.mute,
                    unmute: e.tracking.unmute,
                    click: t ? t.getClickTrackers() : [],
                    click_url_prefix: e.click_url_prefix || null,
                  },
                  load: e.tracking.load,
                },
              },
              h = null == (n = I(this.win)) ? void 0 : n.getGlobalConfig;
            h && h() && h().isDebug() && (u.debug = !0);
            var d = t ? t.getTrackingEvents() : null;
            if (d) {
              var p = u.videos.tracking;
              (p.start = p.start
                .concat(d.playback.start)
                .concat(t.getImpressionTrackers())),
                (p.firstQuartile = p.firstQuartile.concat(
                  d.playback.firstQuartile
                )),
                (p.midpoint = p.midpoint.concat(d.playback.midpoint)),
                (p.thirdQuartile = p.thirdQuartile.concat(
                  d.playback.thirdQuartile
                )),
                (p.complete = p.complete.concat(d.playback.complete)),
                (p.mute = p.mute.concat(d.userActions.mute)),
                (p.unmute = p.unmute.concat(d.userActions.unmute));
            }
            return (
              (u.error = u.error.concat(t ? t.getErrorTrackers() : [])),
              (u.videos.load = u.videos.load.concat(
                t ? t.getLoadTrackers() : []
              )),
              u
            );
          }),
          (e.reportErr = function (t) {
            var e,
              r,
              i = new he(
                this.win,
                this.resolvedSource || { logger: this.logger }
              ),
              n =
                ((e = t.message),
                /startAd timed out/i.test((r = null != e ? e : ""))
                  ? Pt
                  : /initAd timed out/i.test(r)
                  ? Bt
                  : /Ad playback timed out/i.test(r)
                  ? zt
                  : /HeavyAdIntervention/i.test(r)
                  ? Ft
                  : /VAST_CORS_ERROR/i.test(r)
                  ? Ut
                  : /SdkLoadError/i.test(r)
                  ? Ht
                  : /VPAID_LOAD_ERROR|unexpected error within VPAID/i.test(r)
                  ? jt
                  : /blocked impression|Ad blocked/i.test(r)
                  ? Dt
                  : /media file loading reached a timeout|load timeout/i.test(r)
                  ? Tt
                  : /MEDIA_ERR_SRC_NOT_SUPPORTED|Failed to insert|failed to play media/i.test(
                      r
                    )
                  ? Vt
                  : /No Ads VAST response|no ad type found/i.test(r)
                  ? Lt
                  : /problem requesting ads|ad request reached a timeout/i.test(
                      r
                    )
                  ? Mt
                  : /error playing (the )?video/i.test(r)
                  ? Nt
                  : Wt);
            i.report(n, "VPAID Error " + t.code + ": " + t.message, {}),
              (900 !== t.code && 901 !== t.code) ||
                we.reportAdMetric(
                  {
                    type: "failure",
                    version: "10.9.0-kat-7484-test",
                    errCode: "vpaid-" + t.code,
                  },
                  this.videoPlayerConfig,
                  this.logger
                );
          }),
          (e.setSource = function (t) {
            this.resolvedSource = t;
          }),
          (e.getDimensions = function (t) {
            var e = { width: null, height: null },
              r = t ? t.getVpaidVideo() : null,
              i = !r && t ? t.getNonVpaidSource() : null,
              n = r || i || null;
            return n && ((e.width = n.width), (e.height = n.height)), e;
          }),
          (e.getCachebustValue = function () {
            return Math.random().toString().substr(2, 8);
          }),
          (e.createVideoPlayer = (function () {
            var t = (0, V.A)(
              P().mark(function t(e, r) {
                var i,
                  n,
                  a,
                  s,
                  l = this;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (
                            ((i = this.getVideoPlayerConfig(e, r)),
                            (n = i.videos).vpaidUrl || n.source)
                          ) {
                            t.next = 4;
                            break;
                          }
                          return t.abrupt("return", null);
                        case 4:
                          if (
                            ((a = n.vpaidUrl ? "VPAID" : "MP4"),
                            this.logger.debug(
                              "Video " + a + " Creative - VideoPlayer Config",
                              this.getVideoPlayerConfig(e, r)
                            ),
                            (s =
                              "https://storage.cloud.kargo.com/ad/network/tag/Kargo-VideoPlayer.js"),
                            "true" ===
                              (0, o.P3)((0, o.pO)(this.win), "krg_qa") &&
                              (s =
                                "https://storage.cloud.kargo.com/ad/network/tag/Kargo-VideoPlayer-stag.js"),
                            (r.branchTestString ||
                              R.isDebugMode(this.win) ||
                              1 === Math.floor(10 * Math.random())) &&
                              this.reportVPAIDClickable(r.branchTestString),
                            !this.win.Kargo.VideoPlayer)
                          ) {
                            t.next = 14;
                            break;
                          }
                          return (
                            (this.player = new this.win.Kargo.VideoPlayer(i)),
                            t.abrupt("return", this.player)
                          );
                        case 14:
                          return t.abrupt(
                            "return",
                            new Promise(function (t, e) {
                              (0, c.k0)(s, l.win, null, function (r) {
                                r
                                  ? e(r)
                                  : ((l.player = new l.win.Kargo.VideoPlayer(
                                      i
                                    )),
                                    t(l.player));
                              });
                            })
                          );
                        case 15:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this
                );
              })
            );
            return function (e, r) {
              return t.apply(this, arguments);
            };
          })()),
          (e.reportVPAIDClickable = function (t) {
            var e;
            (e = this.resolvedSource
              ? {
                  slot: this.resolvedSource.creativeData.slot,
                  format: this.resolvedSource.creativeData.format,
                  branchTestString: t,
                }
              : { format: "OutstreamVideo", branchTestString: t }),
              we.reportAdMetric(
                {
                  type: "vpaid-clickable",
                  version: "10.9.0-kat-7484-test",
                  vpaidClickable: this.isClickable,
                },
                e,
                this.logger
              );
          }),
          t
        );
      })(),
      Wo = new l.wm("Video"),
      Ko = (function (t) {
        function e() {
          for (var e, r = arguments.length, i = new Array(r), n = 0; n < r; n++)
            i[n] = arguments[n];
          return (
            ((e = t.call.apply(t, [this].concat(i)) || this).videoPlayer =
              null),
            e
          );
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.getDimensions = function () {
            return this.videoPlayer.getVideoPlayerConfig(this.vast, this.config)
              .videos.dimensions;
          }),
          (r.loadVideoPlayer = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          return (
                            (e = null),
                            this.videoPlayer ||
                              ((this.videoPlayer = new zo(
                                this.win,
                                this.logger,
                                this.version
                              )),
                              this.videoPlayer.setSource(this.resolvedSource),
                              (e = this.videoPlayer.createVideoPlayer(
                                this.vast,
                                this.config
                              ))),
                            t.abrupt("return", e)
                          );
                        case 3:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          (r.getViewStreamSnippet = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e, r;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (!this.vast) {
                            t.next = 23;
                            break;
                          }
                          if (this.vast.hasMediaFile() || this.vast.isVpaid()) {
                            t.next = 5;
                            break;
                          }
                          throw Wo.errGet("MediaFile or VPAID js", "VAST tag");
                        case 5:
                          if (
                            !this.vast.isVpaid() ||
                            (this.vast.hasMediaFile() && !(0, Ur.Jp)(this.win))
                          ) {
                            t.next = 14;
                            break;
                          }
                          return (
                            (this.creativeType = "VideoPlayer"),
                            (e = ""),
                            this.config.tracking.load.forEach(function (t) {
                              e +=
                                '<img style="position: absolute; visibility: hidden; left: -9999px; top: 0;" src="' +
                                t +
                                '" />';
                            }),
                            this.vast.getLoadTrackers().forEach(function (t) {
                              t.indexOf("casalemedia.com/usermatch") > -1
                                ? (e +=
                                    '<iframe style="display: none" src="' +
                                    t +
                                    '"></iframe>')
                                : (e +=
                                    '<img style="position: absolute; visibility: hidden; left: -9999px; top: 0;" src="' +
                                    t +
                                    '" />');
                            }),
                            this.vast
                              .getAdVerificationTrackers()
                              .forEach(function (t) {
                                e =
                                  '<script type="text/javascript" src="' +
                                  t +
                                  '"></script>' +
                                  e;
                              }),
                            t.abrupt("return", e)
                          );
                        case 14:
                          return (
                            (t.next = 16),
                            Lo.fetchProcessedVastData(
                              "html",
                              this.vast,
                              this.win
                            )
                          );
                        case 16:
                          return (
                            (r = t.sent),
                            (this.creativeType = "Platform"),
                            (this.html = r),
                            (this.html = Uo.replacePlatformMacros(
                              this.config,
                              this.vast,
                              this.html
                            )),
                            t.abrupt("return", this.html)
                          );
                        case 21:
                          t.next = 28;
                          break;
                        case 23:
                          if (!this.html) {
                            t.next = 27;
                            break;
                          }
                          return t.abrupt(
                            "return",
                            Uo.replacePlatformMacros(
                              this.config,
                              this.vast,
                              this.html
                            )
                          );
                        case 27:
                          throw Wo.errNotSet("VAST or ViewStream snippet");
                        case 28:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          e
        );
      })(Po),
      qo = (function () {
        function t() {}
        return (
          (t.observeElement = function (t, e, r, i) {
            var n;
            void 0 === r && (r = !1);
            var o = "top",
              a = new IntersectionObserver(
                function (e) {
                  e.some(function (e) {
                    return (
                      (n = o),
                      (o = e.intersectionRatio > 0.5 ? "top" : "bottom"),
                      r
                        ? e.isIntersecting && (a.unobserve(t), i(e, o, n))
                        : i(e, o, n),
                      !0
                    );
                  });
                },
                { threshold: e < 0.5 ? [e, 1 - e] : [e] }
              );
            return a.observe(t);
          }),
          t
        );
      })(),
      Go = [
        {
          name: "DFP",
          viewPercent: 0.5,
          timeInView: 1e3,
          callbackName: "onViewable",
        },
        {
          name: "MrcVideo",
          viewPercent: 0.5,
          timeInView: 2e3,
          callbackName: "onMrcVideoViewable",
        },
        {
          name: "CompleteView",
          viewPercent: 0.95,
          timeInView: 2e3,
          callbackName: "onCompleteViewable",
        },
      ];
    function Yo(t, e) {
      var r =
        ("undefined" != typeof Symbol && t[Symbol.iterator]) || t["@@iterator"];
      if (r) return (r = r.call(t)).next.bind(r);
      if (
        Array.isArray(t) ||
        (r = (function (t, e) {
          if (t) {
            if ("string" == typeof t) return Jo(t, e);
            var r = {}.toString.call(t).slice(8, -1);
            return (
              "Object" === r && t.constructor && (r = t.constructor.name),
              "Map" === r || "Set" === r
                ? Array.from(t)
                : "Arguments" === r ||
                  /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r)
                ? Jo(t, e)
                : void 0
            );
          }
        })(t)) ||
        (e && t && "number" == typeof t.length)
      ) {
        r && (t = r);
        var i = 0;
        return function () {
          return i >= t.length ? { done: !0 } : { done: !1, value: t[i++] };
        };
      }
      throw new TypeError(
        "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
      );
    }
    function Jo(t, e) {
      (null == e || e > t.length) && (e = t.length);
      for (var r = 0, i = Array(e); r < e; r++) i[r] = t[r];
      return i;
    }
    function Zo(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, i);
      }
      return r;
    }
    function $o(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2
          ? Zo(Object(r), !0).forEach(function (e) {
              (0, T.A)(t, e, r[e]);
            })
          : Object.getOwnPropertyDescriptors
          ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
          : Zo(Object(r)).forEach(function (e) {
              Object.defineProperty(
                t,
                e,
                Object.getOwnPropertyDescriptor(r, e)
              );
            });
      }
      return t;
    }
    var Xo = (function () {
      function t(t, e, r) {
        (this.element = void 0),
          (this.sourceElement = void 0),
          (this.isVideo = void 0),
          (this.callbacks = {
            onVisibleChange: [],
            onViewable: [],
            onMrcVideoViewable: [],
            onCompleteViewable: [],
            onMissingScript: [],
          }),
          (this.mutationObserver = void 0),
          (this.element = t),
          (this.sourceElement = e),
          (this.isVideo = r),
          (this.mutationObserver = null);
      }
      var e = t.prototype;
      return (
        (e.start = function () {
          var t = this;
          this.checkVisibility(),
            this.checkHasScript(),
            Go.forEach(function (e) {
              var r = $o(
                $o({}, e),
                {},
                {
                  timeInView:
                    t.isVideo && "DFP" === e.name ? 2e3 : e.timeInView,
                }
              );
              t.checkViewability(r);
            });
        }),
        (e.stop = function () {
          this.mutationObserver && this.mutationObserver.disconnect();
        }),
        (e.checkVisibility = function () {
          var t = this;
          qo.observeElement(this.element, 0, !1, function (e) {
            var r = e.isIntersecting;
            (0, d.lP)(t, t.callbacks.onVisibleChange, [r]);
          });
        }),
        (e.checkHasScript = function () {
          var t = this,
            e = (this.sourceElement.ownerDocument || {}).defaultView;
          (this.mutationObserver = new MutationObserver(function (r) {
            for (var i, n = Yo(r); !(i = n()).done; ) {
              var o = i.value;
              null != o &&
                o.removedNodes.length &&
                Array.from(o.removedNodes).includes(t.sourceElement) &&
                e &&
                (0, d.lP)(t, t.callbacks.onMissingScript);
            }
          })),
            this.sourceElement.ownerDocument &&
              this.mutationObserver.observe(this.sourceElement.ownerDocument, {
                attributes: !0,
                childList: !0,
                subtree: !0,
              });
        }),
        (e.checkViewability = function (t) {
          var e = this,
            r = t.viewPercent,
            i = t.timeInView,
            n = t.callbackName,
            o = !1,
            a = !1,
            s = null;
          qo.observeElement(this.element, r, !1, function (t) {
            a ||
              ((o = t.intersectionRatio > r),
              s ||
                (s = window.setTimeout(function () {
                  o
                    ? ((a = !0), (0, d.lP)(e, e.callbacks[n]))
                    : (clearTimeout(s), (s = null));
                }, i)));
          });
        }),
        (e.onVisibleChange = function (t) {
          this.callbacks.onVisibleChange.indexOf(t) < 0 &&
            this.callbacks.onVisibleChange.push(t);
        }),
        (e.onViewable = function (t) {
          this.callbacks.onViewable.indexOf(t) < 0 &&
            this.callbacks.onViewable.push(t);
        }),
        (e.onMrcVideoViewable = function (t) {
          this.callbacks.onMrcVideoViewable.indexOf(t) < 0 &&
            this.callbacks.onMrcVideoViewable.push(t);
        }),
        (e.onCompleteViewable = function (t) {
          this.callbacks.onCompleteViewable.indexOf(t) < 0 &&
            this.callbacks.onCompleteViewable.push(t);
        }),
        (e.onMissingScript = function (t) {
          this.callbacks.onMissingScript.indexOf(t) < 0 &&
            this.callbacks.onMissingScript.push(t);
        }),
        t
      );
    })();
    var Qo = "new-template-after-click",
      ta = "new-template",
      ea = {
        newTemplate: function (t) {
          g(t.rootElement.querySelector(".kargo-ad-content"), ta);
        },
        closeSwipeUp: function (t) {
          r()(t.config.settings.tracking, "dismiss", []).forEach(function (e) {
            (0, c.Ho)(t.win, e);
          }),
            t.onClose(),
            t.destroy();
        },
        clickCreative: function (t) {
          var e = t.rootElement.querySelector("." + ta);
          e && g(e, Qo);
          t.onClick({}, { format: t.config.format, event: "click" });
        },
        clickSwipeUp: function (t) {
          var e = t.rootElement.querySelector("." + ta);
          e && g(e, Qo);
          t.onClick({}, { format: t.config.format, event: "click" });
        },
        swipeCreative: function (t) {
          var e = t.rootElement.querySelector("." + ta);
          e && g(e, Qo);
          t.onClick({}, { format: t.config.format, event: "swipe" });
        },
      };
    function ra(t, e) {
      var r = t.data;
      if ("string" == typeof r && /^\{/.test(r))
        try {
          return JSON.parse(r);
        } catch (t) {
          return e.log("Could not parse json: " + r), null;
        }
      return t.data;
    }
    var ia = (function () {
      function t(t, e, r, i) {
        (this.win = void 0),
          (this.logger = void 0),
          (this.isVisible = void 0),
          (this.isDisplayed = void 0),
          (this.isViewable = void 0),
          (this.isDestroyed = void 0),
          (this.timestamps = void 0),
          (this.tracking = void 0),
          (this.destroy = void 0),
          (this.reportError = void 0),
          (this.config = null),
          (this.container = null),
          (this.metricReporter = null),
          (this.rootElement = null),
          (this.sizeMonitor = null),
          (this.win = t),
          (this.logger = e),
          (this.isVisible = !1),
          (this.isDisplayed = !1),
          (this.isViewable = !1),
          (this.isDestroyed = !1),
          (this.timestamps = {
            start: Date.now(),
            displayed: null,
            firstVisible: null,
            viewable: null,
            destroyed: null,
          }),
          (this.tracking = new M.y(t, e)),
          (this.destroy = r),
          (this.reportError = i);
      }
      var e = t.prototype;
      return (
        (e.setVariables = function (t, e, r, i) {
          (this.config = t),
            (this.container = e),
            (this.rootElement = r),
            (this.metricReporter = i);
        }),
        (e.setContainerSize = function (t, e) {
          var r = this;
          if (this.container) {
            var i = this.container.getType();
            this.logger.debug(
              "Setting " + i + " Container Size: " + e + "x" + t
            ),
              this.container.setContainerSize(e, t).catch(function (t) {
                var e = "Failed to set " + i + " Container Size";
                t && (e += ": " + t), r.logger.debug(e);
              });
          } else
            this.logger.log(
              "No container at this time for creative. Config: " + this.config
            );
        }),
        (e.onCreate = function (t) {
          var e,
            r,
            i = this;
          null !== (null == (e = this.config) ? void 0 : e.onCreate) &&
            (null == (r = this.config) || null == r.onCreate || r.onCreate()),
            this.win.addEventListener("message", function (e) {
              var r = ra(e, i.logger),
                n = ea["string" == typeof r ? r : ""];
              n && n.bind(t)(t, r);
            });
        }),
        (e.onLoad = function () {
          var t,
            e,
            r,
            i = null == (t = this.config) ? void 0 : t.format;
          if (
            this.container &&
            null !== this.container.getType() &&
            "OutstreamVideo" !== i
          ) {
            var n,
              o,
              a = this.container.getType(),
              s = Lr.$4[i].size,
              c = s.w,
              l = s.h;
            if ("GoogleAmp" === a)
              if (
                "Sidekick" ===
                  (null == (n = this.config) ? void 0 : n.format) &&
                this.sizeMonitor
              )
                (c = Math.max(this.sizeMonitor.currentSize.width, 140)),
                  (l = Math.max(this.sizeMonitor.currentSize.height, 180));
              else if (
                "Hover" === (null == (o = this.config) ? void 0 : o.type)
              ) {
                var u;
                (c =
                  (null == (u = this.config) ||
                  null == (u = u.sourceWindow) ||
                  null == (u = u.context)
                    ? void 0
                    : u.initialIntersection.rootBounds.width) || c),
                  (l = 64);
              }
            this.setContainerSize(l, c);
          }
          null !== (null == (e = this.config) ? void 0 : e.onLoad) &&
            (null == (r = this.config) || null == r.onLoad || r.onLoad());
        }),
        (e.onDisplay = function () {
          var t, e, i, n, o, a;
          this.logger.debug("Creative is displayed");
          var s = Date.now(),
            c = jn(null == (t = this.config) ? void 0 : t.content);
          if (
            (this.metricReporter &&
              this.metricReporter.reportTimeToDisplay(s, c),
            (this.isDisplayed = !0),
            (this.timestamps.displayed = Date.now()),
            null !== (null == (e = this.config) ? void 0 : e.onDisplay) &&
              (null == (i = this.config) ||
                null == i.onDisplay ||
                i.onDisplay()),
            null != (n = this.config) && n.slot && this.tracking)
          ) {
            var l,
              u,
              h = null == (l = this.config) ? void 0 : l.slot,
              d = r()(this.config, ["source", "kargo", "kraken_slot_id"], null);
            if (
              (d && (h += "-KRKSID-" + d),
              (null == (u = this.config) ? void 0 : u.source.type) !==
                Jr.PASSBACK)
            )
              ti("serve", h, this.config, this.tracking);
            else {
              var p,
                g = {
                  server:
                    null == (p = this.config)
                      ? void 0
                      : p.source.type.toLowerCase(),
                };
              ti("serve", h, this.config, this.tracking, g);
            }
          }
          if (
            (((null != (o = this.config) && o.branchTestString) ||
              R.isDebugMode(this.win) ||
              1 === Math.floor(20 * Math.random())) &&
              this.metricReporter &&
              this.metricReporter.adMetricReport("impression"),
            "lmt" === (null == (a = this.config) ? void 0 : a.source.tag) &&
              this.tracking)
          ) {
            var f, v, m;
            this.tracking.kaelImpression(
              "lmt-serve",
              null == (f = this.config) ? void 0 : f.id,
              null == (v = this.config) ? void 0 : v.id
            );
            var k,
              b,
              y = Xr(
                null == (m = this.config) ? void 0 : m.type,
                this.rootElement
              );
            if (y)
              this.tracking.kaelViewability(
                "lmt-inviewtime",
                null == (k = this.config) ? void 0 : k.id,
                y,
                null == (b = this.config) ? void 0 : b.id
              );
          }
        }),
        (e.onSizeChange = function (t, e) {
          var r, i;
          null !== (null == (r = this.config) ? void 0 : r.onSizeChange) &&
            (null == (i = this.config) ||
              null == i.onSizeChange ||
              i.onSizeChange(t, e));
        }),
        (e.onVisible = function () {
          var t,
            e,
            r,
            i = this,
            n = Date.now(),
            o = this.win.setInterval(function () {
              var t;
              if (
                null == (t = i.config) ||
                null == (t = t.sourceElement) ||
                !t.ownerDocument.defaultView
              ) {
                var e, r, a;
                if (Date.now() - n < 1e4)
                  ((null != (r = i.config) && r.branchTestString) ||
                    R.isDebugMode(i.win) ||
                    1 === Math.floor(100 * Math.random())) &&
                    i.reportError("Slot has refreshed within 10 seconds", {
                      code: vt,
                    });
                if ("Hover" === (null == (e = i.config) ? void 0 : e.type))
                  ((null != (a = i.config) && a.branchTestString) ||
                    R.isDebugMode(i.win) ||
                    1 === Math.floor(500 * Math.random())) &&
                    i.reportError("Slot refreshed with detached script", {
                      code: vt,
                    }),
                    i.destroy();
                i.win.clearTimeout(o);
              }
            }, 500);
          if (
            null != (t = this.config) &&
            null != (t = t.settings) &&
            t.enable_messaging
          ) {
            var a,
              s = ei(this.rootElement);
            if (s && s.contentWindow)
              s.contentWindow.postMessage(
                (null == (a = this.config) ? void 0 : a.format) + "-onVisible",
                "*"
              );
          }
          (this.isVisible = !0),
            this.timestamps.firstVisible ||
              (this.timestamps.firstVisible = Date.now()),
            null !== (null == (e = this.config) ? void 0 : e.onVisible) &&
              (null == (r = this.config) ||
                null == r.onVisible ||
                r.onVisible());
        }),
        (e.onNotVisible = function () {
          var t, e, r;
          if (null != (t = this.config) && t.settings.enable_messaging) {
            var i,
              n = ei(this.rootElement);
            if (n && n.contentWindow)
              n.contentWindow.postMessage(
                (null == (i = this.config) ? void 0 : i.format) +
                  "-onNotVisible",
                "*"
              );
          }
          (this.isVisible = !1),
            null !== (null == (e = this.config) ? void 0 : e.onNotVisible) &&
              (null == (r = this.config) ||
                null == r.onNotVisible ||
                r.onNotVisible());
        }),
        (e.onViewable = function () {
          var t, e, i, n, o;
          (this.isViewable = !0),
            (this.timestamps.viewable = Date.now()),
            null !== (null == (t = this.config) ? void 0 : t.onViewable) &&
              (null == (e = this.config) ||
                null == e.onViewable ||
                e.onViewable());
          var a,
            s,
            c = this.config.slot,
            l = r()(this.config, ["source", "kargo", "kraken_slot_id"], null);
          (l && (c += "-KRKSID-" + l),
          null != (i = this.config) &&
            i.slot &&
            this.tracking &&
            (null == (n = this.config) ? void 0 : n.source.type) !==
              Jr.PASSBACK &&
            ti("view", c, this.config, this.tracking),
          "lmt" === (null == (o = this.config) ? void 0 : o.source.tag) &&
            this.tracking) &&
            this.tracking.kaelImpression(
              "lmt-view",
              null == (a = this.config) ? void 0 : a.id,
              null == (s = this.config) ? void 0 : s.id
            );
          ri(this.rootElement);
        }),
        (e.onMrcVideoViewable = function () {
          var t = this.config,
            e = t.slot,
            r = t.source,
            i = t.format;
          if (e && this.tracking && r.type !== Jr.PASSBACK) {
            var n = !1;
            Lr.t3.indexOf(i) >= 0 && (n = !0),
              n &&
                ti(
                  "view-predict-in-confirmed-502",
                  e,
                  this.config,
                  this.tracking
                );
          }
        }),
        (e.onCompleteViewable = function () {
          var t, e, r;
          null != (t = this.config) &&
            t.slot &&
            this.tracking &&
            (null == (e = this.config) ? void 0 : e.source.type) !==
              Jr.PASSBACK &&
            ti(
              "completeview",
              null == (r = this.config) ? void 0 : r.slot,
              this.config,
              this.tracking
            );
        }),
        (e.onClick = function (t, e) {
          var i,
            n,
            o,
            a = this,
            s = null == (i = this.config) ? void 0 : i.slot,
            l = r()(this.config, ["source", "kargo", "kraken_slot_id"], null);
          l && (s += "-KRKSID-" + l);
          var u =
            null == (n = this.config) ? void 0 : n.settings.tracking.click;
          u &&
            u.length &&
            u.forEach(function (t) {
              (0, c.Ho)(a.win, t);
            });
          var h = r()(e, "event", null),
            d = r()(this.config, "settings.tracking.click_to_expand", [])[0],
            p = r()(this.config, "settings.tracking.swipe_to_expand", [])[0];
          "swipe" === h && p
            ? (0, c.Ho)(this.win, p)
            : "click" === h && d && (0, c.Ho)(this.win, d),
            s &&
              this.tracking &&
              (null == (o = this.config) ? void 0 : o.source.type) !==
                Jr.PASSBACK &&
              ti("click", s, this.config, this.tracking),
            this.metricReporter && this.metricReporter.adMetricReport("click");
        }),
        (e.onClose = function () {
          var t, e, i, n;
          if (
            null != (t = this.config) &&
            t.slot &&
            this.tracking &&
            (null == (e = this.config) ? void 0 : e.source.type) !== Jr.PASSBACK
          ) {
            var o,
              a = null == (o = this.config) ? void 0 : o.slot,
              s = r()(this.config, ["source", "kargo", "kraken_slot_id"], null);
            s && (a += "-KRKSID-" + s),
              ti("close", a, this.config, this.tracking);
          }
          null !== (null == (i = this.config) ? void 0 : i.onClose) &&
            (null == (n = this.config) || null == n.onClose || n.onClose());
        }),
        (e.onDestroy = function () {
          var t, e, r;
          this.isDestroyed ||
            ((this.isDestroyed = !0),
            (this.isVisible = !1),
            (this.timestamps.destroyed = Date.now()),
            null != (t = this.config) &&
              t.id &&
              ne.getInstance().onImpressionDestroy(this.config.id),
            null !== (null == (e = this.config) ? void 0 : e.onDestroy) &&
              (null == (r = this.config) ||
                null == r.onDestroy ||
                r.onDestroy()));
        }),
        t
      );
    })();
    function na(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, i);
      }
      return r;
    }
    var oa = (function () {
        function t(t, e, r) {
          (this.win = void 0),
            (this.logger = void 0),
            (this.config = void 0),
            (this.AD_METRIC_RATE = 20),
            (this.K_CONTENT = ".kargo-ad-content"),
            (this.creativeWrittenMetricReported = !1),
            (this.win = t),
            (this.logger = e),
            (this.config = r);
        }
        var e = t.prototype;
        return (
          (e.adMetricReport = function (t, e, r) {
            void 0 === e && (e = void 0),
              we.reportAdMetric(
                (function (t) {
                  for (var e = 1; e < arguments.length; e++) {
                    var r = null != arguments[e] ? arguments[e] : {};
                    e % 2
                      ? na(Object(r), !0).forEach(function (e) {
                          (0, T.A)(t, e, r[e]);
                        })
                      : Object.getOwnPropertyDescriptors
                      ? Object.defineProperties(
                          t,
                          Object.getOwnPropertyDescriptors(r)
                        )
                      : na(Object(r)).forEach(function (e) {
                          Object.defineProperty(
                            t,
                            e,
                            Object.getOwnPropertyDescriptor(r, e)
                          );
                        });
                  }
                  return t;
                })({ value: e, type: t, version: "10.9.0-kat-7484-test" }, r),
                this.config,
                this.logger
              );
          }),
          (e.reportAdInViewMetric = function () {
            (this.config.branchTestString ||
              R.isDebugMode(this.win) ||
              1 === Math.floor(100 * Math.random())) &&
              this.adMetricReport("inview-50-percent", 1);
          }),
          (e.reportTimeToDisplay = function (t, e) {
            var r = t - this.config.getAdTimestamp,
              i = { snippetType: e };
            (R.isDebugMode(this.win) || this.creativeWrittenMetricReported) &&
              (this.adMetricReport("time-to-display", r, i),
              (this.creativeWrittenMetricReported = !1));
          }),
          (e.reportTimeToCreative = function (t, e) {
            var r = t - this.config.getAdTimestamp,
              i = { snippetType: e };
            (this.config.branchTestString ||
              R.isDebugMode(this.win) ||
              1 === Math.floor(Math.random() * this.AD_METRIC_RATE)) &&
              (this.adMetricReport("time-to-creative", r, i),
              (this.creativeWrittenMetricReported = !0));
          }),
          t
        );
      })(),
      aa = (function () {
        function t(t, e, r, i) {
          (this.win = void 0),
            (this.logger = void 0),
            (this.rootElement = void 0),
            (this.source = void 0),
            (this.LISTENER_INTERVAL_PERIOD = 100),
            (this.listenerInterval = void 0),
            (this.watchingItems = []),
            (this.callbacks = []),
            (this.errored = !1),
            (this.win = t),
            (this.logger = e),
            (this.rootElement = r),
            (this.source = i);
        }
        var e = t.prototype;
        return (
          (e.eventHandler = function (t) {
            this.logger.debug("Click Detected"),
              this.callbacks.forEach(function (e) {
                ((e.settings.once && 0 === e.times) || !e.settings.once) &&
                  (e.callback(t), e.times++);
              });
          }),
          (e.onClick = function (t, e) {
            this.callbacks.find(function (r) {
              return r.callback === t && r.settings.name === e.name;
            }) || this.callbacks.push({ callback: t, settings: e, times: 0 });
          }),
          (e.attachListener = function () {
            var t = this;
            if (!this.listenerInterval) {
              var e = this.eventHandler.bind(this),
                r = function (i) {
                  t.watchingItems.includes(i)
                    ? (i.removeEventListener("click", e),
                      i.addEventListener("click", e, { passive: !0 }))
                    : (i.addEventListener("click", e, { passive: !0 }),
                      (i.kargoClickHandler = e),
                      t.watchingItems.push(i));
                  (i.document
                    ? Array.from(i.document.getElementsByTagName("iframe"))
                    : Array.from(i.getElementsByTagName("iframe"))
                  ).forEach(function (e) {
                    if (e.contentWindow)
                      try {
                        e.contentWindow.location.href, r(e.contentWindow);
                      } catch (e) {
                        if (!t.errored)
                          new he(
                            t.win,
                            t.source || { logger: t.logger }
                          ).report(
                            dt,
                            "CORS -- Failed to access iframe window"
                          ),
                            t.logger.debug(e);
                        t.errored = !0;
                      }
                  });
                };
              r(this.rootElement),
                (this.listenerInterval = this.win.setInterval(function () {
                  r(t.rootElement);
                }, this.LISTENER_INTERVAL_PERIOD));
            }
          }),
          (e.removeListener = function () {
            this.win.clearInterval(this.listenerInterval),
              this.watchingItems.forEach(function (t) {
                try {
                  t.kargoClickHandler &&
                    t.removeEventListener("click", t.kargoClickHandler);
                } catch (t) {}
              }),
              (this.listenerInterval = void 0),
              (this.watchingItems = []);
          }),
          t
        );
      })();
    function sa() {
      return (sa = (0, V.A)(
        P().mark(function t() {
          var e;
          return P().wrap(function (t) {
            for (;;)
              switch ((t.prev = t.next)) {
                case 0:
                  return (
                    (t.next = 2),
                    __webpack_require__
                      .e(653)
                      .then(__webpack_require__.bind(__webpack_require__, 9212))
                  );
                case 2:
                  if ((e = t.sent).OverlapMonitor) {
                    t.next = 5;
                    break;
                  }
                  throw new Error("OverlapMonitor class not found in module");
                case 5:
                  return t.abrupt("return", e.OverlapMonitor);
                case 6:
                case "end":
                  return t.stop();
              }
          }, t);
        })
      )).apply(this, arguments);
    }
    function ca(t, e, r) {
      var i = null,
        n = null;
      document.addEventListener("visibilitychange", function () {
        if ("visible" === document.visibilityState) {
          if (null !== n && null !== i && t && Math.abs(n - i) <= 15) {
            var r = Date.now() - n;
            (n = null), (i = null), e(r);
          }
        } else t && (n = Date.now());
      }),
        r.onClick(
          function () {
            i = Date.now();
          },
          { once: !1, name: "return_tracker" }
        );
    }
    var la = "bannerVisible",
      ua = "interactiveAds",
      ha = "bto-interactive-adhesive",
      da = "static",
      pa = "pickup";
    function ga(t) {
      var e = t.format,
        r = t.execution;
      return (
        e === Br.B.LIGHTHOUSE ||
        (null !== r &&
          ["interscroller", "lighthouse", "desktop-lighthouse"].includes(r))
      );
    }
    function fa(t) {
      var e = -1 * t.getBoundingClientRect().x;
      t.style.left = e + "px";
    }
    function va(t, e) {
      Object.assign(t.style, {
        maxWidth: On + "px",
        minWidth: "615px",
        width: e + "px",
      });
    }
    function ma(t) {
      return Math.min(Math.max(t, 615), On);
    }
    function ka(t, e) {
      var r;
      return (
        (null == (r = t.execution) ? void 0 : r.includes(ha)) ||
        "banner" === t.settings.bto_interactive_type ||
        (Hr(t, e) && "branded_takeover" === t.placementType)
      );
    }
    var ba = function (t, e, r, i, n) {
        var o = e.contentWindow.document,
          a =
            null == t
              ? void 0
              : t.filter(function (t) {
                  return !o.querySelector("." + t.tagName);
                });
        if (o && a.length > 0) {
          var s = o.createDocumentFragment();
          a.map(function (t) {
            return (
              i.debug(
                t.tagName + " Tag Missing in Creative Iframe - Attaching again"
              ),
              (function (t, e, r) {
                var i = t.createElement("div");
                i.classList.add(e);
                var n = t.createElement("script");
                return (n.src = r), [i, n];
              })(o, t.tagName, t.url).map(function (t) {
                return f(t, "append", s);
              }),
              t
            );
          }),
            f(s, "append", o.body),
            (n = r.setInterval(function () {
              ba(a, e, r, i, n);
            }, 100)),
            r.setTimeout(function () {
              return r.clearInterval(n);
            }, 5e3);
        } else n && r.clearInterval(n);
      },
      ya = 1e4,
      wa = (function () {
        function t(t, e, r, i, n) {
          (this.win = void 0),
            (this.logger = void 0),
            (this.iframe = void 0),
            (this.creativeWrittenTime = void 0),
            (this.onReady = void 0),
            (this.timeoutId = null),
            (this.pollIntervalId = null),
            (this.lastSize = null),
            (this.fired = !1),
            (this.win = t),
            (this.logger = e),
            (this.iframe = r),
            (this.creativeWrittenTime = i),
            (this.onReady = n);
        }
        var e = t.prototype;
        return (
          (e.start = function () {
            var t = this;
            this.logger.debug(
              "CeltraDisplayMonitor: Waiting for celtraLoaded event"
            );
            var e = this.iframe.contentDocument;
            if (!e)
              return (
                this.logger.warn(
                  "CeltraDisplayMonitor: No contentDocument on iframe"
                ),
                void this.cleanupAndNotify(
                  Date.now() - this.creativeWrittenTime,
                  !0
                )
              );
            var r = e.querySelector(".celtra-ad-v3");
            if (!r)
              return (
                this.logger.warn(
                  "CeltraDisplayMonitor: No .celtra-ad-v3 element found"
                ),
                void this.cleanupAndNotify(
                  Date.now() - this.creativeWrittenTime,
                  !0
                )
              );
            if (r.celtra && r.celtra.loaded)
              return (
                this.logger.debug(
                  "CeltraDisplayMonitor: Already loaded (celtra.loaded=true)"
                ),
                void this.beginSizeSettle(Date.now() - this.creativeWrittenTime)
              );
            r.addEventListener(
              "celtraLoaded",
              function () {
                var e = Date.now() - t.creativeWrittenTime;
                t.logger.debug(
                  "CeltraDisplayMonitor: celtraLoaded fired (latency=" +
                    e +
                    "ms)"
                ),
                  t.beginSizeSettle(e);
              },
              !1
            );
            var i = Date.now() - this.creativeWrittenTime,
              n = ya - i;
            if (n <= 0)
              return (
                this.logger.warn(
                  "CeltraDisplayMonitor: celtraLoaded did not fire within 10000ms"
                ),
                void this.cleanupAndNotify(i, !0)
              );
            this.timeoutId = this.win.setTimeout(function () {
              if (!t.fired) {
                t.logger.warn(
                  "CeltraDisplayMonitor: celtraLoaded did not fire within 10000ms"
                );
                var e = Date.now() - t.creativeWrittenTime;
                t.cleanupAndNotify(e, !0);
              }
            }, n);
          }),
          (e.beginSizeSettle = function (t) {
            var e = this;
            if (!this.fired && null === this.pollIntervalId) {
              null !== this.timeoutId &&
                (this.win.clearTimeout(this.timeoutId),
                (this.timeoutId = null));
              var r = Date.now(),
                i = r;
              (this.lastSize = Hn.getCeltraPaintedSize(this.iframe)),
                (this.pollIntervalId = this.win.setInterval(function () {
                  var n = Hn.getCeltraPaintedSize(e.iframe);
                  (!n ||
                    !e.lastSize ||
                    n.width !== e.lastSize.width ||
                    n.height !== e.lastSize.height) &&
                    ((e.lastSize = n), (i = Date.now()));
                  var o = Date.now();
                  ((e.lastSize && o - i >= 300) || o - r >= 3e3) &&
                    e.cleanupAndNotify(t, !1, e.lastSize || void 0);
                }, 100));
            }
          }),
          (e.clearTimers = function () {
            null !== this.timeoutId &&
              (this.win.clearTimeout(this.timeoutId), (this.timeoutId = null)),
              null !== this.pollIntervalId &&
                (this.win.clearInterval(this.pollIntervalId),
                (this.pollIntervalId = null));
          }),
          (e.cleanupAndNotify = function (t, e, r) {
            void 0 === e && (e = !1),
              this.fired ||
                ((this.fired = !0),
                this.clearTimers(),
                void 0 !== t && this.onReady && this.onReady(t, e, r));
          }),
          (e.stop = function () {
            this.cleanupAndNotify(-1, !0);
          }),
          t
        );
      })(),
      _a = (function () {
        function t(t, e, r) {
          (this.win = void 0),
            (this.kargoAdContent = void 0),
            (this.source = void 0),
            (this.countDown = 20),
            (this.interval = void 0),
            (this.globalState = void 0),
            (this.clickMonitor = void 0),
            (this.logger = void 0),
            (this.callbacks = { onCollapse: [], onExpand: [] }),
            (this.expandedToElement = null),
            (this.win = t),
            (this.kargoAdContent = e),
            (this.source = r),
            (this.logger = new n.V(t, "CeltraExpandStateManager", 4)),
            (this.interval = this.startMonitoringInterval()),
            (this.globalState = this.setUpGlobalState()),
            (this.clickMonitor = this.setUpClickMonitor());
        }
        var e = t.prototype;
        return (
          (e.log = function () {
            for (
              var t, e = arguments.length, r = new Array(e), i = 0;
              i < e;
              i++
            )
              r[i] = arguments[i];
            (t = this.logger).debug.apply(t, ["#" + this.interval].concat(r));
          }),
          (e.onExpand = function (t) {
            this.callbacks.onExpand.indexOf(t) < 0 &&
              this.callbacks.onExpand.push(t);
          }),
          (e.onCollapse = function (t) {
            this.callbacks.onCollapse.indexOf(t) < 0 &&
              this.callbacks.onCollapse.push(t);
          }),
          (e.setUpClickMonitor = function () {
            var t = this,
              e = new aa(
                this.win,
                this.logger,
                this.kargoAdContent,
                this.source
              );
            return (
              e.onClick(
                function () {
                  t.elementClicked();
                },
                { once: !1, name: "celtra_click" }
              ),
              e.attachListener(),
              e
            );
          }),
          (e.setUpGlobalState = function () {
            return (
              (this.win.__krg_global_celtra_state = this.win
                .__krg_global_celtra_state || {
                clickedElement: null,
                expandedElement: null,
              }),
              this.log("Set up global state"),
              this.win.__krg_global_celtra_state
            );
          }),
          (e.setState = function (t) {
            var e = this;
            Object.keys(t).forEach(function (r) {
              r in e.globalState && (e.globalState[r] = t[r]);
            });
          }),
          (e.elementClicked = function () {
            this.setState({ clickedElement: this.kargoAdContent }),
              (this.countDown = 20);
          }),
          (e.timeOut = function () {
            (this.countDown = 20), this.setState({ clickedElement: null });
          }),
          (e.fireCallbacks = function (t) {
            this.log("Firing callbacks for event: " + t);
            var e = null;
            "onExpand" === t && (e = this.expandedToElement),
              "onCollapse" === t && (e = this.kargoAdContent),
              this.callbacks[t].forEach(function (t) {
                return t(e);
              });
          }),
          (e.checkStateChange = function () {
            var t = this,
              e =
                (
                  Array.from(
                    this.win.document.querySelectorAll(".celtra-expanded-ad")
                  ) || []
                ).filter(function (e) {
                  return b(e, t.win);
                })[0] || null;
            if (
              this.globalState.clickedElement &&
              this.globalState.clickedElement === this.kargoAdContent
            ) {
              if (!this.countDown) return void this.timeOut();
              (this.countDown -= 1),
                e !== this.globalState.expandedElement &&
                  (e
                    ? (this.log("Expand from:", this.kargoAdContent, "to:", e),
                      (this.expandedToElement = e),
                      this.fireCallbacks("onExpand"))
                    : (this.log(
                        "Unexpected behavior, likely user closed expanded window too quickly"
                      ),
                      this.setState({ clickedElement: null })),
                  this.setState({ expandedElement: e }));
            }
            this.globalState.expandedElement &&
              e !== this.globalState.expandedElement &&
              this.globalState.expandedElement === this.expandedToElement &&
              (this.log(
                "Collapse from:",
                this.globalState.expandedElement,
                "to:",
                this.kargoAdContent
              ),
              this.setState({ expandedElement: null }),
              this.fireCallbacks("onCollapse"));
          }),
          (e.startMonitoringInterval = function () {
            var t = this;
            return (
              this.interval && this.win.clearInterval(this.interval),
              this.win.setInterval(function () {
                return t.checkStateChange();
              }, 100)
            );
          }),
          t
        );
      })(),
      Aa = (function () {
        function t(t, e) {
          (this.sendError = void 0),
            (this.sendMetric = void 0),
            (this.sentCodes = new Set()),
            (this.mraidState = null),
            (this.createdAt = void 0),
            (this.hasReportedTimeToSize = !1),
            (this.sendError = t),
            (this.sendMetric = e),
            (this.createdAt = Date.now());
        }
        var e = t.prototype;
        return (
          (e.reportErrorOnce = function (t, e) {
            if (this.sentCodes.has(t)) return !1;
            this.sentCodes.add(t);
            var r = this.mraidState
              ? " (mraid state: " + this.mraidState + ")"
              : "";
            return this.sendError(gn(new Error("" + e + r), t)), !0;
          }),
          (e.reportMetric = function (t, e) {
            this.sendMetric(t, e);
          }),
          (e.setMraidState = function (t) {
            this.mraidState = t;
          }),
          (e.reportTimeToSize = function () {
            this.hasReportedTimeToSize ||
              ((this.hasReportedTimeToSize = !0),
              this.sendMetric("time-to-size", Date.now() - this.createdAt));
          }),
          t
        );
      })(),
      Ca = new l.wm("Creative"),
      Ea = (function () {
        function t(t, e, r) {
          (this.win = void 0),
            (this.logger = void 0),
            (this.renderer = void 0),
            (this.components = void 0),
            (this.config = void 0),
            (this._config = void 0),
            (this.isCreativeLoaded = void 0),
            (this.isHidden = void 0),
            (this.sizeMonitor = null),
            (this.visibilityMonitor = null),
            (this.celtraDisplayMonitor = null),
            (this.clickMonitor = null),
            (this.metricReporter = null),
            (this.safeFrameReporter = void 0),
            (this.eventHandler = void 0),
            (this.template = null),
            (this.container = null),
            (this.ias = null),
            (this.useOverlapDetection = !1),
            (this.overlapMonitor = null),
            (this.activeView = null),
            (this.krakenMetrics = null),
            (this.rootElement = void 0),
            (this.socialCanvasCreatives = void 0),
            (this.templateHtml = ""),
            (this.templateCss = ""),
            (this.creativeTypes = void 0),
            (this.source = null),
            (this.socialEmbedLocationId = null),
            (this.flourishManifest = void 0),
            (this.version = void 0),
            (this.hasReportedIasNotInContainer = !1),
            (this.win = t),
            (this.logger = e),
            (this.version = r),
            (this.renderer = null),
            (this.components = {}),
            (this.socialCanvasCreatives = { companion: null }),
            (this.creativeTypes = []);
          var i = +(0, o.P3)((0, o.pO)(this.win), "krg_debug");
          this.win.__krg_v6_proxy_enabled || 5 === i
            ? ((this._config = (0, d.h1)({}, Yr)),
              (this.config = this._config),
              this.logger.debug("Creative config is proxified"))
            : (this.config = (0, d.h1)({}, Yr)),
            (this.isCreativeLoaded = !1),
            (this.isHidden = !0),
            (this.eventHandler = new ia(
              this.win,
              this.logger,
              this.destroy.bind(this),
              this.reportError
            )),
            (this.rootElement = this.win.document.createElement("div"));
        }
        var e = t.prototype;
        return (
          (e.getRenderConfig = function () {
            return {};
          }),
          (e.setComponents = function (t) {
            (this.components = t),
              this.components.Ias &&
                (this.ias = new this.components.Ias(
                  this.win,
                  this.logger,
                  this
                )),
              (this.template =
                this.template ||
                new this.components.Template(
                  this.win,
                  this.templateHtml,
                  this.templateCss
                )),
              this.components.ActiveView &&
                (this.activeView = new this.components.ActiveView(
                  this.win,
                  this.logger
                ));
          }),
          (e.detectContainerEnvironment = function () {
            var t = this;
            return (
              (this.container =
                this.container || new me(this.config.sourceWindow || this.win)),
              (0, V.A)(
                P().mark(function e() {
                  var r, i;
                  return P().wrap(
                    function (e) {
                      for (;;)
                        switch ((e.prev = e.next)) {
                          case 0:
                            return (
                              (e.prev = 0),
                              (e.next = 3),
                              null == (r = t.container)
                                ? void 0
                                : r.detectEnvironment()
                            );
                          case 3:
                            return (
                              null !== (i = e.sent) &&
                                t.logger.debug("Detected Container Type: " + i),
                              e.abrupt("return", i)
                            );
                          case 8:
                            return (
                              (e.prev = 8),
                              (e.t0 = e.catch(0)),
                              e.abrupt("return", t.logger.error(e.t0))
                            );
                          case 11:
                          case "end":
                            return e.stop();
                        }
                    },
                    e,
                    null,
                    [[0, 8]]
                  );
                })
              )()
            );
          }),
          (e.setConfig = function (t) {
            var e = this.validateConfig(t);
            (0, d.h1)(this.config, e),
              (this.win.__krg_creatives = this.win.__krg_creatives || 0),
              (this.win.__krg_creatives += 1),
              (this.config.localId = this.win.__krg_creatives),
              (0, o.P3)((0, o.pO)(this.win), "krg_debug") &&
                (this.config.debug = !0),
              (0, o.P3)((0, o.pO)(this.win), "kapt_qa") &&
                (this.config.staging = !0),
              this.config.id ||
                ((this.config.id =
                  this.source && this.source.impressionId
                    ? this.source.impressionId
                    : (0, d.lk)(this.win)),
                ue(
                  this.logger,
                  F,
                  "Impression ID unset in creative, regenerated a new one"
                )),
              this.config.debug && this.logger.setLevel(4),
              this.logger.setLabel([
                "CREATIVE",
                this.version,
                this.config.localId +
                  " - " +
                  (this.config.format || this.config.type).toUpperCase(),
              ]),
              this.logger.debug("Created with config:", this.config);
          }),
          (e.getConfig = function () {
            return this.config;
          }),
          (e.validateConfig = function (t) {
            return oi.validateConfig(t, this.win);
          }),
          (e.reportError = function (t, e) {
            void 0 === e && (e = {});
            var r,
              i =
                ("string" == typeof (r = e.code) && Ot.includes(r)
                  ? e.code
                  : void 0) ||
                fn(t) ||
                (function (t) {
                  var e =
                    t instanceof Error
                      ? t.name + ": " + t.message
                      : String(null != t ? t : "");
                  return /Cannot read properties of null|contentWindow/.test(e)
                    ? Et
                    : /IntersectionObserver/.test(e)
                    ? xt
                    : /Loading chunk|ChunkLoadError/.test(e)
                    ? St
                    : /XMLHttpRequest|Failed to execute 'send'/.test(e)
                    ? It
                    : void 0;
                })(t) ||
                N,
              n = new he(this.win, this.source || { logger: this.logger }),
              o = this.config.creativeId || "";
            n.report(
              i,
              t.message || t,
              {
                creative: o,
                format: this.config.format,
                slot: this.config.slot,
                source: (this.config.source || {}).type,
              },
              e.isWarning
            );
          }),
          (e.createSafeFrameReporter = function () {
            var t = this;
            return new Aa(
              function (e) {
                return t.reportError(e);
              },
              function (e, r) {
                return we.reportAdMetric(
                  {
                    type: "safeframe",
                    safeframeEvent: e,
                    value: r,
                    version: "10.9.0-kat-7484-test",
                  },
                  t.config,
                  t.logger
                );
              }
            );
          }),
          (e.reportUnsupportedSafeFrameCreative = function (t) {
            var e,
              r = t || "unknown";
            null == (e = this.safeFrameReporter) ||
              e.reportErrorOnce(
                ut,
                "SafeFrame " +
                  this.config.format +
                  " sizing supports Celtra only, creative type: " +
                  r
              );
          }),
          (e.display = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e, r;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (!this.eventHandler.isDisplayed) {
                            t.next = 2;
                            break;
                          }
                          return t.abrupt("return");
                        case 2:
                          if (this.config.positionElement) {
                            t.next = 6;
                            break;
                          }
                          return (
                            this.reportError(
                              Ca.errNotSet("positionElement", "config")
                            ),
                            this.destroy(),
                            t.abrupt("return")
                          );
                        case 6:
                          return (
                            null == (e = this.template) ||
                              e.setDefaultTemplateVars(
                                this.config.id,
                                this.config.localId
                              ),
                            this.setUpRootElement(),
                            this.setUpMetricReporting(),
                            this.setUpKrakenMetricsReporting(),
                            this.setUpEventHandling(),
                            this.setUpSizeMonitoring(),
                            this.setUpVisibilityMonitoring(),
                            this.setUpClickMonitoring(),
                            this.setUpOverlapMonitoring(),
                            this.onCreate(),
                            (null == (r = this.config.positionElement) ||
                            null == (r = r.ownerDocument)
                              ? void 0
                              : r.defaultView) !== this.config.sourceWindow &&
                              oi.hideSourceIframe(this.config.sourceWindow),
                            (this.config.content = this.config.content || ""),
                            this.setUpThirdParties(),
                            (t.next = 22),
                            this.showContent()
                          );
                        case 22:
                          this.isHidden = !1;
                        case 23:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          (e.setUpRootElement = function () {
            if (
              ((this.rootElement.className =
                "kargo-ad-v5 kargo-ad-" +
                this.config.localId +
                " kargo-ad-preload"),
              this.config.externalId &&
                (g(this.rootElement, this.config.externalId),
                this.rootElement.setAttribute(
                  "data-external-id",
                  this.config.externalId
                )),
              this.rootElement.setAttribute("data-id", this.config.id),
              this.rootElement.setAttribute("data-format", this.config.format),
              this.rootElement.setAttribute("data-slot", this.config.slot),
              this.template)
            ) {
              var t = this.template.replaceTemplateVars("html"),
                e = this.template.replaceTemplateVars("css"),
                r = this.config.css || "";
              this.rootElement.innerHTML =
                t + '<style type="text/css">' + e + r + "</style>";
            }
            f(
              this.rootElement,
              this.config.positionLocation,
              this.config.positionElement
            );
          }),
          (e.setUpVisibilityMonitoring = function () {
            var t = this,
              e = Lr.t3.indexOf(this.config.format) > -1;
            this.components.VisibilityMonitor &&
              ((this.visibilityMonitor = new this.components.VisibilityMonitor(
                oi.getVisibilityCheckElement(
                  this.config.type,
                  this.rootElement
                ),
                this.config.sourceElement,
                e
              )),
              this.visibilityMonitor.onVisibleChange(function (e) {
                e
                  ? (t.onVisible(), t.logger.debug("Visible"))
                  : (t.onNotVisible(), t.logger.debug("Not Visible"));
              }),
              this.visibilityMonitor.onViewable(function () {
                var e;
                null == (e = t.metricReporter) || e.reportAdInViewMetric(),
                  t.onViewable(),
                  t.logger.debug("Viewable");
              }),
              this.visibilityMonitor.onMrcVideoViewable(function () {
                t.onMrcVideoViewable(), t.logger.debug("MRC Video Viewable");
              }),
              this.visibilityMonitor.onCompleteViewable(function () {
                t.onCompleteViewable(), t.logger.debug("Complete Viewable");
              }),
              this.visibilityMonitor.onMissingScript(function () {
                t.logger.debug("Current script removed from DOM"), t.destroy();
              }),
              this.visibilityMonitor.start());
          }),
          (e.setUpSizeMonitoring = function () {
            var t = this;
            if (this.components.SizeMonitor) {
              var e,
                r,
                i = this.rootElement.querySelector(Kr);
              (this.sizeMonitor = new this.components.SizeMonitor(i)),
                null == (e = this.sizeMonitor) ||
                  e.onSizeChange(function (e, r) {
                    t.logger.debug("Size Change: " + e + "x" + r),
                      t.checkSizeConstraints(),
                      !t.isCreativeLoaded &&
                        r > 25 &&
                        e > 25 &&
                        (t.logger.debug("Creative Successfully Loaded"),
                        t.setAsLoaded(),
                        t.onLoad()),
                      t.onSizeChange(e, r);
                  }),
                null == (r = this.sizeMonitor) || r.start(),
                (this.eventHandler.sizeMonitor = this.sizeMonitor);
            }
          }),
          (e.setUpMetricReporting = function () {
            this.metricReporter ||
              (this.metricReporter = new oa(
                this.win,
                this.logger,
                this.config
              ));
          }),
          (e.setUpEventHandling = function () {
            this.eventHandler.setVariables(
              this.config,
              this.container,
              this.rootElement,
              this.metricReporter
            );
          }),
          (e.setUpClickMonitoring = function () {
            var t = this;
            if (!this.clickMonitor) {
              var e = this.rootElement.querySelector(Kr);
              (this.clickMonitor = new aa(
                this.win,
                this.logger,
                e,
                this.source
              )),
                ca(
                  this.config.localId,
                  this.onPageReturn.bind(this),
                  this.clickMonitor
                ),
                this.config.format !== Br.B.SWIPE_UP &&
                  this.clickMonitor.onClick(
                    function (e) {
                      t.onClick(e);
                    },
                    { once: !0, name: "kraken_click" }
                  ),
                this.clickMonitor.attachListener();
            }
          }),
          (e.getGlobalConfig = function () {
            var t;
            return null == (t = I(this.win)) || null == t.getGlobalConfig
              ? void 0
              : t.getGlobalConfig();
          }),
          (e.setUpOverlapMonitoring = function () {
            var t = this,
              e = this.getGlobalConfig();
            if (
              e &&
              e.shouldCheckOverlap &&
              e.shouldCheckOverlap() &&
              this.useOverlapDetection
            ) {
              var r = oi.getContentElement(this.rootElement),
                i = oi.getVisibilityCheckElement(
                  this.config.type,
                  this.rootElement
                );
              null !== r &&
                (function () {
                  return sa.apply(this, arguments);
                })()
                  .then(function (n) {
                    if (n) {
                      var o,
                        a = e
                          ? e.getConfig().settings.overlap_detection_sample
                          : 1;
                      (t.overlapMonitor = new n(
                        t.win,
                        t.logger,
                        r,
                        i,
                        t.config.sourceElement,
                        t.config.id,
                        t.config.slot,
                        null == (o = t.source) ||
                        null == (o = o.krakenCreativeData)
                          ? void 0
                          : o.gpid,
                        a
                      )),
                        t.logger.debug("OverlapMonitor initialized");
                    }
                  })
                  .catch(function (e) {
                    t.reportError(e),
                      t.logger.error("Failed to load OverlapMonitor:", e);
                  });
            }
          }),
          (e.setCreativeTypes = function (t, e) {
            if (((this.creativeTypes = t), e)) {
              var r = this.validateConfig(e);
              (0, d.h1)(this.config, r);
              var i = this.config.settings.tracking;
              i &&
                Object.keys(i).forEach(function (t) {
                  i[t] = Array.from(new Set(i[t]));
                });
            }
            var n;
            (this.creativeTypes.includes("ivo") &&
              this.renderer &&
              (Un(this.renderer, e), this.renderer.setVendor("ivo")),
            this.creativeTypes.includes("celtra")) &&
              (this.setUpCeltraExpandedReturnClickTracker(),
              null == (n = this.renderer) || n.setVendor("celtra"));
          }),
          (e.setUpKrakenMetricsReporting = function () {
            var t;
            if (!this.krakenMetrics && this.config.source) {
              var e = this.config.source,
                r = e.krgImpId,
                i = e.krakenDomain;
              if (r && i) {
                var n =
                  (null == (t = this.win.Kargo) ? void 0 : t.self_url) || "";
                this.krakenMetrics = new sn(
                  this.win,
                  this.logger,
                  r,
                  i,
                  this.config.slot,
                  n,
                  this.config,
                  this.container
                );
              }
            }
          }),
          (e.setUpThirdParties = function () {
            var t;
            if (
              this.ias &&
              this.ias.isTrackingViewability() &&
              oi.shouldAddIAS(this.config.source)
            )
              "SafeFrame" ===
              (null == (t = this.container) ? void 0 : t.getType())
                ? this.injectIasIntoContainerDocument()
                : (this.config.content += this.ias.getTrackingTag());
            else if (this.ias && this.config.format === Br.B.DESKTOP_SKINS) {
              var e = this.ias.buildIasUrl();
              (e || "" === e) &&
                /\{\{IAS_KRG_URL\}\}/i.test(this.config.content) &&
                (this.logger.debug(
                  "Replacing IAS URL macro in DesktopSkins ADM content"
                ),
                (this.config.content = this.config.content.replace(
                  /\{\{IAS_KRG_URL\}\}/gi,
                  e
                )));
            }
          }),
          (e.injectIasIntoContainerDocument = function () {
            var t;
            if (this.ias) {
              var e = this.ias.getTrackingTagUrl(),
                r = null == (t = this.rootElement) ? void 0 : t.ownerDocument;
              if (e) {
                if (!r)
                  return (
                    this.reportIasNotInContainer(),
                    void (this.config.content += this.ias.getTrackingTag())
                  );
                if (!r.querySelector('script[src="' + e + '"]')) {
                  var i = r.createElement("script");
                  (i.type = "text/javascript"),
                    (i.src = e),
                    r.head.appendChild(i);
                }
              }
            }
          }),
          (e.reportIasNotInContainer = function () {
            this.hasReportedIasNotInContainer ||
              ((this.hasReportedIasNotInContainer = !0),
              this.reportError(
                gn(
                  new Error(
                    "IAS kept in the creative: no SafeFrame document to load it into"
                  ),
                  ct
                )
              ));
          }),
          (e.setUpCeltraExpandedReturnClickTracker = function () {
            var t = this,
              e = this.rootElement.querySelector(".kargo-ad-content"),
              r = new _a(this.win, e, this.source),
              i = null;
            r.onExpand(function (e) {
              e &&
                ((i = new aa(t.win, t.logger, e, t.source)),
                ca(t.config.localId, t.onPageReturn.bind(t), i),
                i.attachListener());
            }),
              r.onCollapse(function () {
                i && i.removeListener();
              });
          }),
          (e.getContentWrapper = function () {
            return this.rootElement.querySelector(Kr);
          }),
          (e.showContent = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (
                            ((e = this.getContentWrapper()),
                            !this.config.content)
                          ) {
                            t.next = 16;
                            break;
                          }
                          return (
                            this.logger.debug(
                              "Writing content to contentWrapper"
                            ),
                            (t.prev = 3),
                            (t.next = 6),
                            this.write(e, this.config.content)
                          );
                        case 6:
                          this.onDisplay(), (t.next = 14);
                          break;
                        case 9:
                          (t.prev = 9),
                            (t.t0 = t.catch(3)),
                            this.reportError(t.t0),
                            this.logger.error(t.t0),
                            this.destroy();
                        case 14:
                          t.next = 19;
                          break;
                        case 16:
                          this.setAsLoaded(), this.onDisplay(), this.onLoad();
                        case 19:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this,
                  [[3, 9]]
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          (e.destroy = function () {
            this.logger.debug("Destroying"),
              (this.isHidden = !0),
              this.sizeMonitor && this.sizeMonitor.stop(),
              this.visibilityMonitor && this.visibilityMonitor.stop(),
              this.celtraDisplayMonitor && this.celtraDisplayMonitor.stop(),
              null != this.rootElement && _(this.rootElement),
              this.onDestroy();
          }),
          (e.getSocialCanvasCreatives = function (t, e) {
            var r = this.win.atob(t),
              i = (0, Ur.xl)(this.win);
            return {
              creative: r || null,
              renderDiv: e,
              dimensions: { width: i ? "500" : "320", height: i ? "86" : "50" },
            };
          }),
          (e.write = function (t, e) {
            var n,
              o,
              a,
              s,
              c,
              u,
              h,
              d,
              p,
              g,
              f,
              v = this;
            if (
              (this.config.companion_div &&
                ("social_embed_adhesion" === this.config.slotType &&
                  (this.logger.debug(
                    "social_embed_adhesion slot type detected"
                  ),
                  (this.socialEmbedLocationId = this.config.companion_div)),
                this.config.settings.companion &&
                  (this.socialCanvasCreatives.companion =
                    this.getSocialCanvasCreatives(
                      this.config.settings.companion,
                      this.config.companion_div
                    ))),
              ga(this.config) &&
                !this.config.settings.forceResponsive &&
                (e = e.replace("preview.js", "web.js")),
              e.indexOf("celtra-ad-v3") > 0 &&
                this.setUpCeltraExpandedReturnClickTracker(),
              this.config.previewMode)
            ) {
              var m = null;
              (m = e.match(/<div class="celtra-ad-v3">[\s\S]*?<\/div>/gi)) &&
                (this.logger.debug(
                  "Preview Mode - Writing Ad Content Outside of Iframe"
                ),
                (this.getRenderConfig = function () {
                  return { hide: !0 };
                }),
                m.map(function (r) {
                  (t.innerHTML += r), (e = e.replace(r, ""));
                }));
            }
            var k = this.getGlobalConfig();
            if (k && k.isActiveViewRewriteEnabled())
              try {
                this.activeView &&
                  this.activeView.isActiveViewWrapped(e) &&
                  (this.activeView.moveUp(t, e),
                  (e = this.activeView.remove(e)));
              } catch (t) {
                t instanceof Error || t instanceof l.qw || "string" == typeof t
                  ? t instanceof Error &&
                    "ActiveView: new active-view pixel" === t.message
                    ? this.logger.debug("New active-view pixel fired")
                    : this.reportError(t)
                  : this.reportError(String(t));
              }
            e = oi.addPrefixAndSuffix(
              e,
              this.config.prefix,
              this.config.suffix,
              this.logger
            );
            var b = this.win;
            t.ownerDocument &&
              t.ownerDocument.defaultView &&
              (b = t.ownerDocument.defaultView),
              (this.renderer = new this.components.CreativeSandbox(
                b,
                this.logger,
                this.getRenderConfig(),
                this.source,
                this.socialCanvasCreatives,
                this.socialEmbedLocationId
              )),
              null == (n = this.renderer) ||
                n.setCreativeId(this.config.creativeId),
              null == (o = this.renderer) ||
                o.setAuctionType(
                  null == (a = this.config.source.auctionType)
                    ? void 0
                    : a.toLowerCase()
                );
            var y = {
              creative: this.config.creativeId,
              format: this.config.format,
              slot: this.config.slot,
              source: this.config.source.type || "",
              creativeFlags: this.config.source.creativeFlags || {},
              adTagVersion: "10.9.0-kat-7484-test",
              iasTagParams: this.config.iasTagParams,
              areBtoStuntsEnabled: this.config.areBtoStuntsEnabled || !1,
            };
            if (
              (null == (s = this.renderer) || s.setExtraParams(y),
              null == (c = this.renderer) ||
                c.setTracking(this.config.settings.tracking),
              "Wrapper" === this.config.format)
            ) {
              var w,
                _,
                A = null,
                C = e.match(/<script[^>]*?skeleton.js"><\/script>/gi);
              if (C && C.length)
                (A = C[0]),
                  null == (w = this.renderer) || w.setIasTag(A),
                  (e = e.replace(A, ""));
              if (this.config.settings.height_offset)
                null == (_ = this.renderer) ||
                  _.setWrapper_height_offset(
                    this.config.settings.height_offset
                  );
            }
            var E = r()(this.win, "Kargo.Plugin.Cerberus"),
              x =
                "direct" ===
                (null == (u = this.config.source) || null == (u = u.auctionType)
                  ? void 0
                  : u.toLowerCase()),
              S = {
                macroConfig: {
                  lexId: (E && E.getLexId()) || "",
                  slotId: this.config.slot || "",
                  impressionId: this.config.id,
                  hostname: r()(this.win, "location.hostname") || "",
                  adFormat: this.config.format || "",
                  creativeId: this.config.creativeId || "",
                  creativeIdAlpha: x ? this.config.creativeId : "",
                  creativeIdRtb: x ? "" : this.config.creativeId,
                  lineItemId:
                    (x &&
                      (null == (h = this.config.source)
                        ? void 0
                        : h.biddableId)) ||
                    "",
                  dealId:
                    (null == (d = this.config.source) ? void 0 : d.dealId) ||
                    "",
                  inAppMacros:
                    null == (p = this.config.source) ? void 0 : p.inAppMacros,
                },
                apiMethods: {
                  getImpressionId: function () {
                    return v.config.id;
                  },
                  isVisible: function () {
                    return v.eventHandler.isVisible;
                  },
                  isViewable: function () {
                    return v.eventHandler.isViewable;
                  },
                  hide: function () {
                    return v.hide();
                  },
                  show: function () {
                    return v.show();
                  },
                  destroy: function () {
                    return v.destroy();
                  },
                  setCreativeTypes: function (t, e) {
                    return v.setCreativeTypes(t, e);
                  },
                  reportError: function (t, e) {
                    return void 0 === e && (e = {}), v.reportError(t, e);
                  },
                },
              };
            return (
              null == (g = this.renderer) || g.setCreativeApiMacros(S),
              null == (f = this.renderer) || f.setLocationElement(t),
              ((0, i.sk)(window).Kargo.impressionId = this.config.id),
              new Promise(function (t, r) {
                var i, n, o, a;
                null == (i = v.renderer) || i.onContentLoad(t);
                var s,
                  c = [];
                c.length > 0 &&
                  (null == (s = v.renderer) ||
                    s.onContentLoad(function () {
                      var t;
                      ba(
                        c,
                        (null == (t = v.renderer) ? void 0 : t.getFrame()) ||
                          null,
                        v.win,
                        v.logger
                      );
                    }));
                null == (n = v.renderer) || n.onError(r),
                  null == (o = v.renderer) || o.write(e);
                var l,
                  u = jn(e),
                  h = Date.now() - 1;
                (null == (a = v.metricReporter) || a.reportTimeToCreative(h, u),
                v.krakenMetrics) &&
                  (null == (l = v.renderer) ||
                    l.onContentLoad(function () {
                      var t;
                      if (v.krakenMetrics) {
                        var e = 0,
                          r = !1;
                        v.config && (r = Lr.t3.indexOf(v.config.format) >= 0);
                        var i =
                          null == (t = v.renderer) ? void 0 : t.getFrame();
                        if (i && r) {
                          var n = i.contentDocument;
                          if (n) {
                            var o = Bn(n, "video");
                            o.length && (e = o[0].duration);
                          }
                        }
                        var a = 0,
                          s = 0;
                        if (v.sizeMonitor) {
                          var c = v.sizeMonitor.currentSize;
                          (a = c.width), (s = c.height);
                        }
                        var l =
                            "celtra" === u ||
                            v.creativeTypes.includes("celtra"),
                          d = Dr(v.win);
                        if (l && d && i)
                          return (
                            v.logger.debug(
                              "CeltraDisplayMonitor: Waiting for celtra painted size before render event"
                            ),
                            (v.celtraDisplayMonitor = new wa(
                              v.win,
                              v.logger,
                              i,
                              h,
                              function (t, r, i) {
                                var n, o, c, l;
                                if (!r && i) {
                                  var u = Hn.clampToContainer(i, {
                                    width: a,
                                    height: s,
                                  });
                                  (c = u.width), (l = u.height);
                                }
                                null == (n = v.krakenMetrics) ||
                                  n.recordEvent(ye.Render, {
                                    width: a,
                                    height: s,
                                    duration: e,
                                    creativeWidth: c,
                                    creativeHeight: l,
                                  }),
                                  null == (o = v.krakenMetrics) ||
                                    o.recordEvent(ye.CreativeReady, {
                                      creativeLoadTime: t,
                                      method: "celtra",
                                    });
                              }
                            )),
                            void v.celtraDisplayMonitor.start()
                          );
                        v.krakenMetrics.recordEvent(ye.Render, {
                          width: a,
                          height: s,
                          duration: e,
                        }),
                          l &&
                            i &&
                            (v.logger.debug(
                              "CeltraDisplayMonitor: Waiting for celtraLoaded for creative-ready"
                            ),
                            (v.celtraDisplayMonitor = new wa(
                              v.win,
                              v.logger,
                              i,
                              h,
                              function (t) {
                                var e;
                                null == (e = v.krakenMetrics) ||
                                  e.recordEvent(ye.CreativeReady, {
                                    creativeLoadTime: t,
                                    method: "celtra",
                                  });
                              }
                            )),
                            v.celtraDisplayMonitor.start());
                      }
                    }));
              })
            );
          }),
          (e.show = function () {
            if (this.rootElement && this.isHidden) {
              w(this.rootElement, qr);
              var t = this.rootElement.childNodes[0];
              t &&
                (t.classList &&
                  t.classList.contains("kargo-ad-hover-slide-down-fast") &&
                  w(t, "kargo-ad-hover-slide-down-fast"),
                g(t, "kargo-ad-hover-slide-up-fast"));
            }
            this.isHidden = !1;
          }),
          (e.hide = function () {
            if (this.rootElement && !this.isHidden) {
              var t = this.rootElement.childNodes[0];
              t
                ? (w(t, "kargo-ad-hover-slide-up-fast"),
                  g(t, "kargo-ad-hover-slide-down-fast"))
                : g(this.rootElement, qr);
            }
            this.isHidden = !0;
          }),
          (e.setAsLoaded = function () {
            w(this.rootElement, "kargo-ad-preload"),
              (this.isCreativeLoaded = !0);
          }),
          (e.checkSizeConstraints = function () {
            if (this.isCreativeLoaded && this.sizeMonitor) {
              var t = this.sizeMonitor.currentSize;
              if (t.height)
                if ("MiddleBanner" === this.config.format)
                  t.height - 250 > 15 &&
                    this.reportError(
                      "SIZE: " + t.height + " is taller than allowed",
                      { code: pt, isWarning: !0 }
                    );
            }
          }),
          (e.getAnalytics = function () {
            var t = {
                localId: this.config.localId,
                id: this.config.id,
                type: this.config.type,
                format: this.config.format,
                execution: this.config.execution,
                kargoCreativeId: null,
                timestamps: this.eventHandler.timestamps,
              },
              e = r()(this.config, ["source", "kargo", "creativeId"], null);
            return e && (t.kargoCreativeId = e), t;
          }),
          (e.onCreate = function () {
            this.eventHandler.onCreate(this);
          }),
          (e.onLoad = function () {
            this.eventHandler.onLoad();
          }),
          (e.onDisplay = function () {
            this.eventHandler.onDisplay();
          }),
          (e.onSizeChange = function (t, e) {
            this.eventHandler.onSizeChange(t, e);
          }),
          (e.onVisible = function () {
            var t;
            this.eventHandler.onVisible(),
              null == (t = this.overlapMonitor) || t.start();
          }),
          (e.onNotVisible = function () {
            var t;
            this.eventHandler.onNotVisible(),
              null == (t = this.overlapMonitor) || t.stop();
          }),
          (e.onViewable = function () {
            this.eventHandler.onViewable();
          }),
          (e.onMrcVideoViewable = function () {
            this.eventHandler.onMrcVideoViewable();
          }),
          (e.onCompleteViewable = function () {
            this.eventHandler.onCompleteViewable();
          }),
          (e.onClick = function (t, e) {
            this.eventHandler.onClick(t, e);
          }),
          (e.onClose = function () {
            this.eventHandler.onClose();
          }),
          (e.onDestroy = function () {
            var t;
            null == (t = this.overlapMonitor) || t.stop(),
              this.eventHandler.onDestroy();
          }),
          (e.onPageReturn = function (t) {
            var e = r()(this.config, "settings.tracking.click_return", null);
            if (
              (this.logger.debug("User returned to page after  " + t + "ms."),
              e && e.length)
            ) {
              var i = e[0];
              (i = (0, o.JT)(i, { kid: t })),
                this.logger.debug("Click Return Tracker fired: " + i),
                (0, c.Ho)(this.win, i);
            } else
              this.logger.debug(
                "Click Return callback fired: No Tracker Found"
              );
          }),
          t
        );
      })();
    const xa = Ea;
    var Sa = __webpack_require__(4162),
      Ia = __webpack_require__(820);
    var Oa = /data-dcm-rendering-mode\s*=\s*['"]?iframe\b/i;
    function Ra(t, e, r, i, n) {
      return (function (t) {
        return !!t && Oa.test(t);
      })(r)
        ? "dcm_iframe"
        : i
        ? "safeframe"
        : (function (t, e, r) {
            var i,
              n = null == (i = I(t)) ? void 0 : i.getSlotConfig;
            if (!n) return !1;
            var o = n(e);
            if (!o) return !1;
            var a = o.getAllFormatConfigs();
            if (!a.Venti || !a.Venti.isApprovedForPMP) return !1;
            var s = a.Venti.isApprovedForPMP();
            return (
              r.debug(
                "expanding-flourish: Venti format approved for PMP: " + s
              ),
              s
            );
          })(t, e, n)
        ? null
        : "slot_not_approved";
    }
    function Da(t, e, r) {
      var i,
        n = null == (i = I(t)) ? void 0 : i.getSlotConfig;
      if (!n) return !1;
      var o = n(e);
      if (!o) return !1;
      var a = o.getAllFormatConfigs();
      if (!a.HalfPage || !a.HalfPage.isApprovedForPMP) return !1;
      var s = a.HalfPage.isApprovedForPMP();
      return (
        r.debug("expanding-flourish: HalfPage format approved for PMP: " + s), s
      );
    }
    var Ta = /https?:\/\/[a-z0-9.-]*\.adsrvr\.org\/track\/clk\?[^'"\s<>]*/i,
      Va =
        /https:\/\/adclick\.g\.doubleclick\.net\/pcs\/click\?[^'"\s\\<>]*[?&]adurl=https?[^'"\s\\<>]+/i,
      La =
        /clickUrl:\s*'(https:\/\/adclick\.g\.doubleclick\.net\/pcs\/click\?[^'\s\\<>]*&adurl=)'/i,
      Pa = /reportingId:\s*'(\d+)',\s*destinationUrl:\s*'(https?:\/\/[^']+)'/i,
      Ma = /https?:\/\/[a-z0-9.-]*\.adsrvr\.org\/[^'"\s<>]*ad\.html[^'"\s<>]*/i,
      Na = /class\s*=\s*['"]?[^'">]*\bdcmads\b/i,
      Fa =
        /^https?:\/\/([a-z0-9-]+\.)*(adsrvr\.org|mysite-analytics\.com|doubleclick\.net)(\/|$)/i;
    function Ba(t) {
      return "https://dwnld.kargo.com/?url=" + encodeURIComponent(t);
    }
    function Ua(t) {
      return Fa.test(t);
    }
    function Ha(t) {
      return /[?&]r=/.test(t);
    }
    function ja(t) {
      return /[?&]r=https?%3A|[?&]r=https?:/i.test(t);
    }
    function za(t) {
      if (!t) return null;
      try {
        var e = t.contentWindow;
        return (e && void 0 !== e.location.href && e.document) || null;
      } catch (t) {
        return null;
      }
    }
    function Wa(t) {
      for (
        var e = t.querySelectorAll("iframe[src]"), r = 0;
        r < e.length;
        r++
      ) {
        var i = e[r].src;
        if (i && Ua(i)) return i;
      }
      return null;
    }
    function Ka(t) {
      var e = t.match(/[?&"']clickTAG=([^&"'\s]+)/i);
      if (!e) return null;
      var r = decodeURIComponent(e[1]).match(Ta);
      return r && Ha(r[0]) ? r[0] : null;
    }
    function qa(t) {
      var e = Ka(t.rawAdm);
      if (e)
        return (
          t.logger.debug(
            "ttd-click-extractor: clickTAG from ADM clickTAG= param"
          ),
          e
        );
      var r = t.rawAdm.match(Ta);
      if (r && Ha(r[0]))
        return (
          t.logger.debug("ttd-click-extractor: clickTAG from bare ADM match"),
          r[0]
        );
      r &&
        t.logger.debug(
          "ttd-click-extractor: bare ADM clk match found but no &r= redirect param"
        );
      var i = za(t.adIframe);
      if (!i)
        return (
          t.logger.debug(
            "ttd-click-extractor: no clickTAG in ADM and iframe doc unreadable (cross-origin/absent)"
          ),
          null
        );
      var n = Wa(i);
      if (!n)
        return (
          t.logger.debug(
            "ttd-click-extractor: iframe doc readable but no adsrvr.org iframe src found"
          ),
          null
        );
      var o = Ka(n);
      return (
        t.logger.debug(
          o
            ? "ttd-click-extractor: clickTAG from adsrvr.org iframe src"
            : "ttd-click-extractor: adsrvr.org iframe src found but no clickTAG= in it"
        ),
        o
      );
    }
    function Ga(t) {
      var e = za(t.adIframe);
      if (e) {
        var r = Wa(e);
        if (r)
          return (
            t.logger.debug(
              "ttd-click-extractor: ad.html from live iframe src (" + r + ")"
            ),
            r
          );
      }
      var i = t.rawAdm.match(Ma);
      return i
        ? Ua(i[0])
          ? (t.logger.debug(
              "ttd-click-extractor: ad.html from ADM match (" + i[0] + ")"
            ),
            i[0])
          : (t.logger.debug(
              "ttd-click-extractor: ad.html match in ADM but host not allowed (" +
                i[0] +
                ")"
            ),
            null)
        : (t.logger.debug(
            "ttd-click-extractor: no ad.html url in live iframe or ADM"
          ),
          null);
    }
    function Ya(t) {
      if (!Na.test(t.rawAdm)) return null;
      var e = t.rawAdm.match(/data-dcm-placement\s*=\s*['"]([^'"]+)['"]/i);
      return e
        ? (t.logger.debug("ttd-click-extractor: DCM placement (" + e[1] + ")"),
          e[1])
        : (t.logger.debug(
            "ttd-click-extractor: dcmads tag present but no data-dcm-placement"
          ),
          null);
    }
    function Ja(t) {
      var e = (t || "").match(/^(\d{1,4})x(\d{1,4})$/);
      return e
        ? { width: Number(e[1]), height: Number(e[2]) }
        : { width: 300, height: 250 };
    }
    function Za(t) {
      var e = t.match(La),
        r = t.match(Pa);
      if (!e || !r) return null;
      var i = r[1],
        n = r[2];
      return (
        e[1].replace(/%5Brm_exit_id%5D|\[rm_exit_id\]/i, i) +
        encodeURIComponent(n)
      );
    }
    function $a(t, e, r) {
      return Xa.apply(this, arguments);
    }
    function Xa() {
      return (
        (Xa = (0, V.A)(
          P().mark(function t(e, r, i) {
            var n, o, a, s, c, l, u, h, d;
            return P().wrap(
              function (t) {
                for (;;)
                  switch ((t.prev = t.next)) {
                    case 0:
                      return (
                        (t.prev = 0),
                        (n = Ja(r)),
                        (o = n.width),
                        (a = n.height),
                        (s = Math.floor(1e10 * Math.random())),
                        (c =
                          "https://ad.doubleclick.net/ddm/adj/" +
                          e +
                          ";sz=" +
                          o +
                          "x" +
                          a +
                          ";ord=" +
                          s +
                          ";"),
                        (t.next = 6),
                        fetch(Ba(c))
                      );
                    case 6:
                      if ((l = t.sent).ok) {
                        t.next = 10;
                        break;
                      }
                      return (
                        i.debug(
                          "ttd-click-extractor: DCM adj fetch not ok (" +
                            l.status +
                            ")"
                        ),
                        t.abrupt("return", null)
                      );
                    case 10:
                      return (t.next = 12), l.text();
                    case 12:
                      if (
                        ((u = t.sent
                          .replace(/\\\\x/g, "\\x")
                          .replace(/\\x([0-9A-Fa-f]{2})/g, function (t, e) {
                            return String.fromCharCode(parseInt(e, 16));
                          })
                          .replace(/&amp;/g, "&")),
                        !(h = u.match(Va)))
                      ) {
                        t.next = 17;
                        break;
                      }
                      return (
                        i.debug(
                          "ttd-click-extractor: DCM adclick url resolved"
                        ),
                        t.abrupt("return", h[0])
                      );
                    case 17:
                      if (!(d = Za(u))) {
                        t.next = 21;
                        break;
                      }
                      return (
                        i.debug(
                          "ttd-click-extractor: DCM Studio adclick url resolved"
                        ),
                        t.abrupt("return", d)
                      );
                    case 21:
                      return (
                        i.debug(
                          "ttd-click-extractor: DCM response has no adclick url with a populated adurl"
                        ),
                        t.abrupt("return", null)
                      );
                    case 25:
                      return (
                        (t.prev = 25),
                        (t.t0 = t.catch(0)),
                        i.debug(
                          "ttd-click-extractor: DCM adclick resolve failed",
                          t.t0
                        ),
                        t.abrupt("return", null)
                      );
                    case 29:
                    case "end":
                      return t.stop();
                  }
              },
              t,
              null,
              [[0, 25]]
            );
          })
        )),
        Xa.apply(this, arguments)
      );
    }
    function Qa(t, e) {
      var r = encodeURIComponent(e),
        i = t.replace(/([?&]r=)(?=&|$)/, "$1" + r);
      return i === t ? null : i;
    }
    function ts(t, e) {
      return es.apply(this, arguments);
    }
    function es() {
      return (
        (es = (0, V.A)(
          P().mark(function t(e, r) {
            var i, n, o, a, s, c, l, u, h, d;
            return P().wrap(
              function (t) {
                for (;;)
                  switch ((t.prev = t.next)) {
                    case 0:
                      return (t.prev = 0), (t.next = 3), fetch(Ba(e));
                    case 3:
                      if ((n = t.sent).ok) {
                        t.next = 7;
                        break;
                      }
                      return (
                        r.debug(
                          "ttd-click-extractor: ad.html fetch not ok (" +
                            n.status +
                            ")"
                        ),
                        t.abrupt("return", null)
                      );
                    case 7:
                      return (t.next = 9), n.text();
                    case 9:
                      if (
                        ((o = t.sent),
                        (a = o.match(/ePayload\s*=\s*"([^"]+)"/)),
                        (s = o.match(/kanApi\s*=\s*"([^"]+)"/)),
                        a && s)
                      ) {
                        t.next = 15;
                        break;
                      }
                      return (
                        r.debug(
                          "ttd-click-extractor: ad.html missing DCO config (ePayload=" +
                            !!a +
                            ", kanApi=" +
                            !!s +
                            ")"
                        ),
                        t.abrupt("return", null)
                      );
                    case 15:
                      if (Ua((c = s[1]))) {
                        t.next = 19;
                        break;
                      }
                      return (
                        r.debug(
                          "ttd-click-extractor: kanApi host not allowed (" +
                            c +
                            ")"
                        ),
                        t.abrupt("return", null)
                      );
                    case 19:
                      return (
                        (l =
                          c +
                          "/Assets/Services?a=" +
                          encodeURIComponent(a[1]) +
                          "&u=&w=300&h=250&l=en&i=true&s=true&b=false"),
                        (t.next = 22),
                        fetch(Ba(l))
                      );
                    case 22:
                      if ((u = t.sent).ok) {
                        t.next = 26;
                        break;
                      }
                      return (
                        r.debug(
                          "ttd-click-extractor: kan JSON fetch not ok (" +
                            u.status +
                            ")"
                        ),
                        t.abrupt("return", null)
                      );
                    case 26:
                      return (t.t0 = JSON), (t.next = 29), u.text();
                    case 29:
                      if (
                        ((t.t1 = t.sent),
                        (h = t.t0.parse.call(t.t0, t.t1)),
                        "string" !=
                          typeof (d =
                            null == h || null == (i = h.account)
                              ? void 0
                              : i.url) || !/^https?:\/\//.test(d))
                      ) {
                        t.next = 35;
                        break;
                      }
                      return (
                        r.debug(
                          "ttd-click-extractor: landing url resolved (" +
                            d +
                            ")"
                        ),
                        t.abrupt("return", d)
                      );
                    case 35:
                      return (
                        r.debug(
                          "ttd-click-extractor: kan JSON has no valid account.url (" +
                            String(d) +
                            ")"
                        ),
                        t.abrupt("return", null)
                      );
                    case 39:
                      return (
                        (t.prev = 39),
                        (t.t2 = t.catch(0)),
                        r.debug(
                          "ttd-click-extractor: landing url fetch failed",
                          t.t2
                        ),
                        t.abrupt("return", null)
                      );
                    case 43:
                    case "end":
                      return t.stop();
                  }
              },
              t,
              null,
              [[0, 39]]
            );
          })
        )),
        es.apply(this, arguments)
      );
    }
    function rs() {
      return (rs = (0, V.A)(
        P().mark(function t(e) {
          var r, i, n, o, a;
          return P().wrap(function (t) {
            for (;;)
              switch ((t.prev = t.next)) {
                case 0:
                  if (
                    (e.logger.debug(
                      "ttd-click-extractor: start (admLen=" +
                        e.rawAdm.length +
                        ", hasIframe=" +
                        !!e.adIframe +
                        ")"
                    ),
                    (r = qa(e)))
                  ) {
                    t.next = 5;
                    break;
                  }
                  return (
                    e.logger.debug("ttd-click-extractor: no clickTAG found"),
                    t.abrupt("return", null)
                  );
                case 5:
                  if (!ja(r)) {
                    t.next = 8;
                    break;
                  }
                  return (
                    e.logger.debug(
                      "ttd-click-extractor: clickTAG already has a populated &r=; using as-is"
                    ),
                    t.abrupt("return", r)
                  );
                case 8:
                  if (((i = null), !(n = Ga(e)))) {
                    t.next = 16;
                    break;
                  }
                  return (t.next = 13), ts(n, e.logger);
                case 13:
                  (i = t.sent), (t.next = 21);
                  break;
                case 16:
                  if (!(o = Ya(e))) {
                    t.next = 21;
                    break;
                  }
                  return (t.next = 20), $a(o, e.size, e.logger);
                case 20:
                  i = t.sent;
                case 21:
                  if (i) {
                    t.next = 24;
                    break;
                  }
                  return (
                    e.logger.debug("ttd-click-extractor: no landing url"),
                    t.abrupt("return", null)
                  );
                case 24:
                  if ((a = Qa(r, i))) {
                    t.next = 28;
                    break;
                  }
                  return (
                    e.logger.debug(
                      "ttd-click-extractor: clickTAG has no empty &r= to fill"
                    ),
                    t.abrupt("return", null)
                  );
                case 28:
                  return t.abrupt("return", a);
                case 29:
                case "end":
                  return t.stop();
              }
          }, t);
        })
      )).apply(this, arguments);
    }
    function is(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, i);
      }
      return r;
    }
    function ns(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2
          ? is(Object(r), !0).forEach(function (e) {
              (0, T.A)(t, e, r[e]);
            })
          : Object.getOwnPropertyDescriptors
          ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
          : is(Object(r)).forEach(function (e) {
              Object.defineProperty(
                t,
                e,
                Object.getOwnPropertyDescriptor(r, e)
              );
            });
      }
      return t;
    }
    var os =
        /https?:\/\/tk\.kargo\.com\/t\/(?:[a-z0-9.-]+\.)?click\.[^'"\s<>]+/,
      as = [
        { name: "conversant", pattern: /cnvr-ubr-adm|dotomi\.com/ },
        { name: "yahoo", pattern: /ybp\.yahoo\.com/ },
        { name: "appnexus", pattern: /adnxs\.com/ },
        { name: "unruly", pattern: /1rx\.io/ },
        { name: "ttd", pattern: /adsrvr\.org/ },
        { name: "dv360", pattern: /doubleclick\.net\/xbbe|dbm_c=/ },
        { name: "amazon", pattern: /aax-us-east\.amazon-adsystem\.com/ },
        { name: "criteo", pattern: /criteo\.(?:com|net)/ },
        { name: "mediamath", pattern: /mathtag\.com/ },
        { name: "xandr", pattern: /xandr\.com/ },
      ];
    function ss(t) {
      try {
        var e = t.contentWindow;
        return e
          ? void 0 === e.location.href
            ? null
            : e.document || null
          : null;
      } catch (t) {
        return null;
      }
    }
    var cs = (function () {
        function t(t) {
          (this.logger = void 0),
            (this.win = void 0),
            (this.rawAdm = void 0),
            (this.size = void 0),
            (this.tkUrl = void 0),
            (this.detectedDsp = void 0),
            (this.onNavigationMissed = void 0),
            (this.onClickNoTarget = void 0),
            (this.onClickPath = void 0),
            (this.onTtdExtraction = void 0),
            (this.adIframe = null),
            (this.syntheticClick = null),
            (this.ttdClickUrl = null),
            (this.ttdResolving = !1),
            (this.logger = t.logger),
            (this.win = t.win),
            (this.onNavigationMissed = t.onNavigationMissed),
            (this.onClickNoTarget = t.onClickNoTarget),
            (this.onClickPath = t.onClickPath),
            (this.onTtdExtraction = t.onTtdExtraction),
            (this.rawAdm = t.rawAdm),
            (this.size = t.size);
          var e,
            r,
            i = t.rawAdm.match(os);
          (this.tkUrl = i ? i[0] : null),
            (this.detectedDsp = this.tkUrl
              ? "kargo"
              : ((e = t.rawAdm),
                (r = as.find(function (t) {
                  return t.pattern.test(e);
                }))
                  ? r.name
                  : "unknown")),
            this.logger.debug(
              "click-url-resolver: dsp=" +
                this.detectedDsp +
                " resolved=" +
                (null !== this.tkUrl)
            );
        }
        var e = t.prototype;
        return (
          (e.bindAdIframe = function (t) {
            (this.adIframe = t), this.installOpenTrap(t);
          }),
          (e.onNativeClickRolledBack = function () {
            this.preresolveTtdClickUrl();
          }),
          (e.preresolveTtdClickUrl = function () {
            var t,
              e = this;
            this.tkUrl ||
              "ttd" !== this.detectedDsp ||
              this.ttdClickUrl ||
              this.ttdResolving ||
              ((function (t, e) {
                var r;
                void 0 === e && (e = null);
                var i = Ka(t) || (null == (r = t.match(Ta)) ? void 0 : r[0]);
                if (i && ja(i)) return !0;
                if (Ma.test(t) || Na.test(t)) return !0;
                var n = za(e),
                  o = n ? Wa(n) : null;
                return !!o && Ma.test(o);
              })(this.rawAdm, this.adIframe) &&
                ((this.ttdResolving = !0),
                null == (t = this.onTtdExtraction) || t.call(this, "start"),
                (function (t) {
                  return rs.apply(this, arguments);
                })({
                  rawAdm: this.rawAdm,
                  adIframe: this.adIframe,
                  size: this.size,
                  logger: this.logger,
                })
                  .then(function (t) {
                    (e.ttdClickUrl = t),
                      null == e.onTtdExtraction ||
                        e.onTtdExtraction(t ? "success" : "failure");
                  })
                  .catch(function () {
                    (e.ttdClickUrl = null),
                      null == e.onTtdExtraction || e.onTtdExtraction("failure");
                  })
                  .then(function () {
                    e.ttdResolving = !1;
                  })));
          }),
          (e.forwardClick = function (t) {
            var e,
              r,
              i = this;
            if (this.tkUrl)
              return (
                t.preventDefault(),
                this.win.open(this.tkUrl, "_blank", "noopener,noreferrer"),
                void (null == (e = this.onClickPath) || e.call(this, "tk"))
              );
            if (this.ttdClickUrl)
              return (
                t.preventDefault(),
                this.win.open(
                  this.ttdClickUrl,
                  "_blank",
                  "noopener,noreferrer"
                ),
                void (null == (r = this.onClickPath) || r.call(this, "ttd"))
              );
            var n = { navigated: !1 };
            this.syntheticClick = n;
            var o = this.win.document,
              a = function () {
                "hidden" === o.visibilityState && (n.navigated = !0);
              };
            o.addEventListener("visibilitychange", a);
            var s = this.dispatchSyntheticClick();
            this.win.setTimeout(function () {
              o.removeEventListener("visibilitychange", a),
                i.checkNavigation(n, s);
            }, 500);
          }),
          (e.installOpenTrap = function (t) {
            try {
              var e = t.contentWindow;
              if (!e) return;
              this.installOpenTrapOnWindow(e);
            } catch (t) {
              this.logger.debug(
                "click-url-resolver: cannot install open trap on ad iframe",
                t
              );
            }
          }),
          (e.installOpenTrapOnWindow = function (t) {
            var e = this;
            try {
              if (void 0 === t.location.href) return;
              var r = t.open;
              t.open = function () {
                e.syntheticClick && (e.syntheticClick.navigated = !0);
                for (
                  var i = arguments.length, n = new Array(i), o = 0;
                  o < i;
                  o++
                )
                  n[o] = arguments[o];
                return r.apply(t, n);
              };
            } catch (t) {
              this.logger.debug(
                "click-url-resolver: cannot install open trap on window",
                t
              );
            }
          }),
          (e.dispatchSyntheticClick = function () {
            var t;
            if (!this.adIframe) return "no_iframe";
            var e = this.adIframe.getBoundingClientRect(),
              r = ss(this.adIframe);
            if (!r) return "doc_unreadable";
            var i = e.width / 2,
              n = e.height / 2,
              o = r.elementFromPoint(i, n);
            if (!o) return "no_element";
            if ("IFRAME" === o.tagName) {
              var a = o.getBoundingClientRect();
              o = this.deepElementFromPoint(o, i - a.left, n - a.top) || o;
            }
            var s = o.ownerDocument;
            s.defaultView &&
              s.defaultView !==
                (null == (t = this.adIframe) ? void 0 : t.contentWindow) &&
              this.installOpenTrapOnWindow(s.defaultView);
            var c = new ((s.defaultView && s.defaultView.MouseEvent) ||
              MouseEvent)("click", { bubbles: !0, cancelable: !0, button: 0 });
            return (
              o.dispatchEvent(c),
              "IFRAME" !== o.tagName || ss(o) ? null : "cross_origin_frame"
            );
          }),
          (e.deepElementFromPoint = function (t, e, r, i) {
            if ((void 0 === i && (i = 0), i > 10)) return null;
            var n = ss(t);
            if (!n) return null;
            var o = n.elementFromPoint(e, r);
            if (!o) return null;
            if ("IFRAME" === o.tagName) {
              var a = o,
                s = a.getBoundingClientRect();
              return (
                this.deepElementFromPoint(a, e - s.left, r - s.top, i + 1) || o
              );
            }
            return o;
          }),
          (e.checkNavigation = function (t, e) {
            var r;
            if (
              (this.syntheticClick === t && (this.syntheticClick = null),
              t.navigated)
            ) {
              var i;
              null == (i = this.onClickPath) || i.call(this, "synthetic");
            } else {
              var n,
                o = { dsp: this.detectedDsp, resolved: null !== this.tkUrl };
              if (e)
                null == (n = this.onClickNoTarget) ||
                  n.call(this, ns(ns({}, o), {}, { reason: e }));
              else null == (r = this.onNavigationMissed) || r.call(this, o);
            }
          }),
          Kn(t, [
            {
              key: "resolvedUrl",
              get: function () {
                return this.tkUrl;
              },
            },
            {
              key: "dsp",
              get: function () {
                return this.detectedDsp;
              },
            },
          ])
        );
      })(),
      ls = function (t) {
        var e = "(https:)?\\/\\/bs\\.serving-sys\\.com.*?";
        return new RegExp(
          '<script src=\\"' +
            e +
            '\\"><\\/scr\\+?ipt>[\\s]*?<noscript>[\\s]*?<a href=\\".*?' +
            e +
            '\\".*?>[\\s]*?<img src=\\"' +
            e +
            '\\".*?><\\/a>[\\s]*?<\\/noscript>'
        ).test(t.content);
      },
      us = function (t) {
        return t.content.includes("dcmads");
      },
      hs = function (t) {
        var e;
        return null == (e = t.content) ? void 0 : e.includes("servedbyivo.com");
      };
    function ds() {
      return (ds = (0, V.A)(
        P().mark(function t() {
          var e;
          return P().wrap(function (t) {
            for (;;)
              switch ((t.prev = t.next)) {
                case 0:
                  return (
                    (t.next = 2),
                    __webpack_require__
                      .e(995)
                      .then(__webpack_require__.bind(__webpack_require__, 4735))
                  );
                case 2:
                  return (e = t.sent), t.abrupt("return", e);
                case 4:
                case "end":
                  return t.stop();
              }
          }, t);
        })
      )).apply(this, arguments);
    }
    function ps(t, e, r) {
      var i = t.getElementById(e);
      i ||
        (((i = t.createElement("style")).id = e),
        (t.head || t.documentElement).appendChild(i)),
        (i.textContent = r);
    }
    function gs(t) {
      var e = [t]
        .concat(Array.from(t.querySelectorAll("*")))
        .map(function (t) {
          return t.getBoundingClientRect();
        })
        .filter(function (t) {
          return t.width > 0 && t.height > 0;
        });
      e.length || e.push(t.getBoundingClientRect());
      var r = Math.min.apply(
          Math,
          e.map(function (t) {
            return t.left;
          })
        ),
        i = Math.min.apply(
          Math,
          e.map(function (t) {
            return t.top;
          })
        ),
        n = Math.max.apply(
          Math,
          e.map(function (t) {
            return t.right;
          })
        ),
        o = Math.max.apply(
          Math,
          e.map(function (t) {
            return t.bottom;
          })
        );
      return {
        left: r,
        top: i,
        right: n,
        bottom: o,
        width: n - r,
        height: o - i,
      };
    }
    function fs(t, e) {
      var r = gs(t);
      return (
        (Math.max(0, Math.min(r.right, e.innerWidth) - Math.max(r.left, 0)) *
          Math.max(0, Math.min(r.bottom, e.innerHeight) - Math.max(r.top, 0))) /
        (e.innerWidth * e.innerHeight)
      );
    }
    function vs(t) {
      if (
        (function (t) {
          var e = t.getAttribute("src"),
            r = t.ownerDocument.defaultView;
          if (e && /^https?:/i.test(e) && r)
            try {
              return new URL(e, t.ownerDocument.baseURI).origin !== r.origin;
            } catch (t) {}
          try {
            return !t.contentDocument;
          } catch (t) {
            return !0;
          }
        })(t)
      )
        return null;
      try {
        return t.contentDocument;
      } catch (t) {
        return null;
      }
    }
    var ms = "krg-native-click-style",
      ks = /(?:^|\s)kargo-ad-(\d+)(?:\s|$)/,
      bs = "krg-native-click",
      ys = "krg-native-click-target",
      ws = "krg-native-click-frame",
      _s = "--krg-native-click-offset",
      As = "--krg-native-click-box-height";
    function Cs(t, e) {
      void 0 === e && (e = 0);
      var r = t.defaultView;
      return (
        !(e >= 3 || !r || !r.innerWidth || !r.innerHeight) &&
        Array.from(t.querySelectorAll("iframe")).some(function (t) {
          if (fs(t, r) < 0.9) return !1;
          var i = vs(t);
          return !i || Cs(i, e + 1);
        })
      );
    }
    function Es(t, e) {
      void 0 === e && (e = 0);
      var r = (function (t, e) {
        void 0 === e && (e = 0.9);
        var r = t.defaultView;
        return (
          (r &&
            r.innerWidth &&
            r.innerHeight &&
            Array.from(t.querySelectorAll("a[href]")).find(function (t) {
              return fs(t, r) >= e;
            })) ||
          null
        );
      })(t);
      if (r) return { docs: [t], frames: [], anchor: r };
      var i = t.defaultView;
      if (e >= 3 || !i || !i.innerWidth || !i.innerHeight) return null;
      var n = null;
      return (
        Array.from(t.querySelectorAll("iframe")).some(function (r) {
          if (fs(r, i) < 0.9) return !1;
          var o = vs(r),
            a = o ? Es(o, e + 1) : null;
          return (
            a &&
              (n = {
                docs: [t].concat(a.docs),
                frames: [r].concat(a.frames),
                anchor: a.anchor,
              }),
            !!a
          );
        }),
        n
      );
    }
    function xs(t) {
      return new Promise(function (e) {
        var r = Date.now(),
          i = function () {
            var n = Es(t);
            n
              ? e(n)
              : Cs(t)
              ? e("cross-origin-frame")
              : Date.now() - r >= 1e3
              ? e(null)
              : window.setTimeout(i, 250);
          };
        i();
      });
    }
    function Ss(t, e) {
      var r,
        i = (function (t) {
          return t.rootElement.querySelector("iframe.kargo-creative");
        })(t),
        n = t.flourishElement;
      if (i) {
        var o = null == (r = ks.exec(t.rootElement.className)) ? void 0 : r[1],
          a = o ? ms + "-" + o : ms,
          s = o ? ".kargo-ad-" + o + " " : "",
          c = function (r, i, n) {
            var o = [r, i, void 0 === n ? null : "d" + n]
              .filter(Boolean)
              .join(":");
            t.logger.debug("flourish-native-click: " + o), e.onOutcome(o);
          },
          l = null;
        try {
          l = i.contentDocument;
        } catch (t) {
          l = null;
        }
        if (l) {
          var u = function (r) {
            var o,
              c = i.getBoundingClientRect(),
              l = n.getBoundingClientRect(),
              u = e.parallax ? n.querySelector(".kargo-ad-content") : null,
              h = null == u ? void 0 : u.getBoundingClientRect(),
              d = null != (o = null == h ? void 0 : h.height) ? o : 0,
              p = t.window.getComputedStyle(i),
              g = h ? c.top - h.top - parseFloat(p.marginTop) : 0,
              f = parseFloat(p.marginTop) - (c.top - l.top),
              v = parseFloat(p.marginRight) - (l.right - c.right),
              m = "var(" + As + ", " + l.height + "px)",
              k =
                "calc(" +
                (parseFloat(p.marginBottom) + c.bottom - l.top) +
                "px - " +
                m +
                ")",
              b = parseFloat(p.marginLeft) - (c.left - l.left),
              y = [
                { left: c.left, top: c.top, width: c.width, height: c.height },
              ];
            r.frames.forEach(function (t, e) {
              var r = t.getBoundingClientRect();
              y.push({
                left: y[e].left + r.left,
                top: y[e].top + r.top,
                width: r.width,
                height: r.height,
              });
            });
            var w = gs(r.anchor),
              _ = y[y.length - 1].top + w.top - l.top,
              A = "var(" + _s + ", 0px)",
              C = function (t) {
                return u ? "calc(" + t + "px + " + A + ")" : t + "px";
              },
              E =
                "." +
                ys +
                "::before,\n      ." +
                ys +
                "::after {\n        content: '' !important;\n        display: block !important;\n        position: fixed !important;\n        left: 0 !important;\n        width: 100% !important;\n        background: transparent !important;\n      }\n      ." +
                ys +
                "::before {\n        top: 0 !important;\n        height: " +
                C(_) +
                " !important;\n      }\n      ." +
                ys +
                "::after {\n        top: " +
                C(_ + w.height) +
                " !important;\n        bottom: 0 !important;\n      }",
              x =
                "." +
                ws +
                " {\n        position: fixed !important;\n        inset: 0 !important;\n        width: 100% !important;\n        height: 100% !important;\n        max-width: none !important;\n        margin: 0 !important;\n        border: 0 !important;\n        background: transparent !important;\n        z-index: 2147483647 !important;\n      }";
            r.anchor.classList.add(ys),
              r.frames.forEach(function (t) {
                return t.classList.add(ws);
              }),
              n.classList.add(bs),
              ps(
                t.document,
                a,
                s +
                  "." +
                  bs +
                  ",\n      " +
                  s +
                  "." +
                  bs +
                  " * {\n        pointer-events: none !important;\n      }\n      /* Kargo opt-out links stay clickable (already above the iframe, banner.scss). */\n      " +
                  s +
                  "." +
                  bs +
                  " .kargo-banner-optout,\n      " +
                  s +
                  "." +
                  bs +
                  " .kargo-banner-optout * {\n        pointer-events: auto !important;\n      }\n      " +
                  s +
                  "." +
                  bs +
                  " iframe.kargo-creative {\n        display: block !important;\n        width: " +
                  l.width +
                  "px !important;\n        height: " +
                  m +
                  " !important;\n        max-width: none !important;\n        margin: " +
                  f +
                  "px " +
                  v +
                  "px " +
                  k +
                  " " +
                  b +
                  "px !important;\n        background: transparent !important;\n        border-radius: 0 !important;\n        z-index: 20 !important;\n        pointer-events: auto !important;\n      }" +
                  (u
                    ? "\n      " +
                      s +
                      "." +
                      bs +
                      " .kargo-ad-content {\n        height: " +
                      d +
                      "px !important;\n      }\n      " +
                      s +
                      "." +
                      bs +
                      " iframe.kargo-creative {\n        position: absolute !important;\n        top: calc(" +
                      g +
                      "px - " +
                      A +
                      ") !important;\n      }"
                    : "")
              );
            var S = r.docs.length - 1;
            r.docs.forEach(function (t, e) {
              ps(
                t,
                ms,
                "html {\n          background: transparent !important;\n        }\n        body {\n          position: absolute !important;\n          margin: 0 !important;\n          left: " +
                  (y[e].left - l.left) +
                  "px !important;\n          top: " +
                  C(y[e].top - l.top) +
                  " !important;\n          width: " +
                  y[e].width +
                  "px !important;\n          height: " +
                  y[e].height +
                  "px !important;\n        }\n        " +
                  (e === S ? E : x)
              );
            });
            var I = u
              ? (function (t, e, r, i) {
                  var n =
                      r.getBoundingClientRect().top -
                      e.getBoundingClientRect().top,
                    o = !1,
                    a = function () {
                      var t =
                        r.getBoundingClientRect().top -
                        e.getBoundingClientRect().top -
                        n +
                        "px";
                      i.forEach(function (e) {
                        return e.style.setProperty(_s, t);
                      });
                    },
                    s = function () {
                      e.isConnected
                        ? o ||
                          ((o = !0),
                          t.requestAnimationFrame(function () {
                            a(), (o = !1);
                          }))
                        : t.removeEventListener("scroll", s);
                    };
                  return (
                    t.addEventListener("scroll", s, { passive: !0 }), a(), a
                  );
                })(
                  t.window,
                  n,
                  u,
                  [n].concat(
                    r.docs.map(function (t) {
                      return t.documentElement;
                    })
                  )
                )
              : void 0;
            !(function (t, e) {
              var r = function () {
                t.style.setProperty(
                  As,
                  t.getBoundingClientRect().height + "px"
                ),
                  null == e || e();
              };
              if ((r(), "undefined" != typeof ResizeObserver)) {
                var i = new ResizeObserver(function () {
                  t.isConnected ? r() : i.disconnect();
                });
                i.observe(t);
              }
            })(n, I);
          };
          xs(l)
            .then(function (t) {
              if ("cross-origin-frame" !== t)
                if (t) {
                  var e,
                    r,
                    o,
                    a,
                    s = t.frames.length;
                  if (
                    ((e = t.anchor),
                    (r = e.ownerDocument.defaultView),
                    ["::before", "::after"].some(function (t) {
                      var i =
                        null == r ? void 0 : r.getComputedStyle(e, t).content;
                      return !!i && "none" !== i && "normal" !== i;
                    }))
                  )
                    c("rolled-back", "pseudo-taken", s);
                  else if (
                    ((o = n.getBoundingClientRect()),
                    (a = i.getBoundingClientRect()),
                    o.width + 2 < a.width || o.height + 2 < a.height)
                  )
                    c("rolled-back", "too-small", s);
                  else u(t), c("covered", void 0, s);
                } else c("rolled-back", "no-anchor");
              else c("rolled-back", "cross-origin-frame");
            })
            .catch(function (e) {
              t.logger.error("flourish-native-click failed", e),
                c("rolled-back", "error");
            });
        } else c("rolled-back", "cross-origin");
      }
    }
    function Is(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, i);
      }
      return r;
    }
    function Os(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2
          ? Is(Object(r), !0).forEach(function (e) {
              (0, T.A)(t, e, r[e]);
            })
          : Object.getOwnPropertyDescriptors
          ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
          : Is(Object(r)).forEach(function (e) {
              Object.defineProperty(
                t,
                e,
                Object.getOwnPropertyDescriptor(r, e)
              );
            });
      }
      return t;
    }
    var Rs = new l.wm("Banner"),
      Ds = {
        wrapper_id: null,
        wrapper_fn: null,
        branding: Lr._S,
        enable_entry_animation: !0,
        native: {},
        endcard_label: !1,
        vast_xml: null,
        vast_url: null,
        click_url_prefix: null,
        click_destination_url: null,
        tracking: {
          start: [],
          firstQuartile: [],
          midpoint: [],
          thirdQuartile: [],
          complete: [],
          error: [],
          mute: [],
          unmute: [],
          replay: [],
          expand: [],
          dismiss: [],
        },
      },
      Ts = (function (t) {
        function e(e, r, i) {
          var n;
          return (
            ((n = t.call(this, e, r, i) || this).platformMacros = void 0),
            (n.mobilized = void 0),
            (n.templateHtml = void 0),
            (n.interacted = void 0),
            (n.sidebarSlot = void 0),
            (n.hasLightboxGlowFlourish = void 0),
            (n.expandingFlourish = void 0),
            (n.flourishEligible = void 0),
            (n.clickResolver = void 0),
            (n.lighthouseObserver = void 0),
            (n.templateHtml = Sa),
            (n.templateCss = Ia),
            (n.platformMacros = null),
            (n.interacted = !1),
            (n.sidebarSlot = !1),
            (n.hasLightboxGlowFlourish = !1),
            (n.expandingFlourish = !1),
            (n.flourishEligible = !1),
            n
          );
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.getCreativeRegister = function () {
            var t, e;
            return null !=
              (t =
                null == (e = this.win.Kargo) ||
                null == (e = e.versions) ||
                null == (e = e[this.version])
                  ? void 0
                  : e.CreativeRegister)
              ? t
              : null;
          }),
          (r.validateConfig = function (e) {
            var r = (0, d.h1)({}, Ds),
              i = (0, d.h1)({ settings: r }, e);
            if (
              ((i.type = "Banner"),
              (this.mobilized = !r.branding || "mobilized" === r.branding),
              !r.forceResponsive &&
                (0, Ur.xl)(this.win) &&
                (r.has_responsive_width = !1),
              ii(i.slot, this.win) && (r.has_responsive_width = !1),
              "has_responsive_width" in r ||
                (r.has_responsive_width = this.determineResponsive(i)),
              r.tracking &&
                Object.keys(r.tracking).forEach(function (t) {
                  r.tracking[t] = Vr(r.tracking[t]) || [];
                }),
              r.vast_xml &&
                (r.vast_xml = this.template.getHtml(r.vast_xml, Ds.vast_xml)),
              !i.positionElement && r.wrapper_fn)
            )
              try {
                if (
                  ((i.positionElement = (0, d.zH)(this.win, r.wrapper_fn)),
                  (i.positionLocation = "append"),
                  i.positionElement &&
                    this.win.jQuery &&
                    i.positionElement instanceof this.win.jQuery)
                ) {
                  var n = i.positionElement;
                  i.positionElement = n[0];
                }
              } catch (t) {
                (i.positionElement = null),
                  t instanceof Error &&
                    this.reportError(
                      "Javascript Error in  " +
                        i.format +
                        " Wrapper Function: " +
                        t.name +
                        " - " +
                        t.message
                    );
              }
            return (
              !i.positionElement &&
                r.wrapper_id &&
                ((i.positionElement = this.win.document.getElementById(
                  r.wrapper_id
                )),
                (i.positionLocation = "append")),
              i.positionElement ||
                this.reportError(i.format + " position cannot be determined", {
                  code: gt,
                }),
              t.prototype.validateConfig.call(this, i)
            );
          }),
          (r.setFixedWidth = function () {
            this.template.setTemplateVar("WIDTH", ""),
              (this.config.settings.has_responsive_width = !1),
              this.logger.log(
                "A BYOC creative was found and the width responsive was set to false"
              );
          }),
          (r.determineResponsive = function (t) {
            var e = !0;
            return (
              ai.isRmResponsiveFormat(t.format) && t.content
                ? (e = !t.content.includes('<img src="//dam.cdn.kargo.com'))
                : ai.isUnresponsiveFormat(t.format) && (e = !1),
              e
            );
          }),
          (r.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                var r,
                  i,
                  n,
                  o,
                  a,
                  s,
                  c,
                  l,
                  u,
                  h,
                  d,
                  p,
                  g,
                  f,
                  v,
                  m,
                  k,
                  b = this;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (a = this.template),
                            (s = ga(this.config)),
                            (c =
                              "expanding" ===
                              (null == (r = this.flourishManifest)
                                ? void 0
                                : r.type)),
                            (l =
                              "SafeFrame" ===
                              (null == (i = this.container)
                                ? void 0
                                : i.getType())),
                            (u = c
                              ? Ra(
                                  this.win,
                                  this.config.slot,
                                  this.config.content,
                                  l,
                                  this.logger
                                )
                              : null),
                            (h = c && !u),
                            (this.flourishEligible = !(
                              !this.flourishManifest ||
                              (c && !h)
                            )),
                            this.flourishEligible
                              ? ((p = this.flourishManifest),
                                (g =
                                  p.name.includes("banner") ||
                                  (null != (d = p.config) && d.parallax)
                                    ? "FLOURISH_BANNER"
                                    : "FLOURISH_CONTENT"),
                                a.setTemplateVar(g, p.name),
                                (this.config.settings.has_responsive_width =
                                  !1),
                                we.reportAdMetric(
                                  {
                                    type: "flourish",
                                    value: p.name,
                                    version: "10.9.0-kat-7484-test",
                                  },
                                  this.config,
                                  this.logger
                                ))
                              : u
                              ? (this.logger.debug("Flourish blocked", {
                                  manifest:
                                    null == (f = this.flourishManifest)
                                      ? void 0
                                      : f.name,
                                  reason: u,
                                }),
                                we.reportAdMetric(
                                  {
                                    type: "flourish_blocked",
                                    errCode: u,
                                    version: "10.9.0-kat-7484-test",
                                  },
                                  this.config,
                                  this.logger
                                ))
                              : null != (n = this.config.source) &&
                                null != (n = n.creativeFlags) &&
                                null != (n = n.flourish) &&
                                n.manifest_url &&
                                (this.logger.debug(
                                  "Flourish not eligible to render",
                                  {
                                    manifest:
                                      null == (v = this.flourishManifest)
                                        ? void 0
                                        : v.name,
                                  }
                                ),
                                this.reportError(
                                  "Flourish declared but could not be loaded"
                                )),
                            null != (o = this.flourishManifest) &&
                              o.name.includes("lightbox-glow") &&
                              (this.hasLightboxGlowFlourish = !0),
                            c &&
                              h &&
                              ((this.expandingFlourish = !0),
                              (this.clickResolver = new cs({
                                rawAdm: this.config.content,
                                size:
                                  null !=
                                  (m =
                                    null == (k = this.config.source)
                                      ? void 0
                                      : k.size)
                                    ? m
                                    : void 0,
                                logger: this.logger,
                                win: this.win,
                                onNavigationMissed: function (t) {
                                  var e = t.dsp,
                                    r = t.resolved;
                                  b.reportError(
                                    "expanding flourish click-forward did not navigate (dsp=" +
                                      e +
                                      ", resolved=" +
                                      r +
                                      ")",
                                    { code: wt, isWarning: !0 }
                                  );
                                },
                                onClickNoTarget: function (t) {
                                  var e = t.dsp,
                                    r = t.resolved,
                                    i = t.reason;
                                  b.reportError(
                                    "expanding flourish click-forward had no click target (dsp=" +
                                      e +
                                      ", resolved=" +
                                      r +
                                      ", reason=" +
                                      i +
                                      ")",
                                    { code: _t }
                                  );
                                },
                                onClickPath: function (t) {
                                  we.reportAdMetric(
                                    {
                                      type: "flourish_click_" + t,
                                      version: "10.9.0-kat-7484-test",
                                    },
                                    b.config,
                                    b.logger
                                  );
                                },
                                onTtdExtraction: function (t) {
                                  we.reportAdMetric(
                                    {
                                      type: "flourish_ttd_extract_" + t,
                                      version: "10.9.0-kat-7484-test",
                                    },
                                    b.config,
                                    b.logger
                                  );
                                },
                              })),
                              (this.config.settings.has_responsive_width = !0)),
                            !0 !== this.config.settings.has_responsive_width ||
                              s ||
                              a.setTemplateVar("WIDTH", "kargo-banner-width"),
                            s &&
                              a.setTemplateVar("WIDTH", "kargo-interscroller"),
                            "advertisement" === this.config.settings.branding
                              ? a.setTemplateVar(
                                  "BRANDING",
                                  "kargo-banner--branding-advertisement"
                                )
                              : "mobilized" === this.config.settings.branding
                              ? a.setTemplateVar(
                                  "BRANDING",
                                  "kargo-banner--branding-created"
                                )
                              : "none" === this.config.settings.branding &&
                                a.setTemplateVar(
                                  "BRANDING",
                                  "kargo-banner--branding-none"
                                ),
                            e.abrupt("return", t.prototype.display.call(this))
                          );
                        case 14:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          (r.getRenderConfig = function (t) {
            void 0 === t && (t = {});
            var e = (0, d.h1)(
              {
                width: 320,
                height: 50,
                expansionCheck: !1,
                customCss: "",
                maxDimension: {},
                minDimension: { width: 320, height: 50 },
                macros: this.platformMacros,
              },
              t
            );
            return (
              this.config.settings.has_responsive_width ||
                (e.maxDimension.width = this.rootElement.clientWidth),
              ai.isDesktopFormat(this.config.format) ||
                this.config.format === Br.B.FABRIK_OUTSTREAM ||
                ((e.maxDimension.width = Math.min(e.maxDimension.width, 440)),
                this.config.settings.has_responsive_width &&
                  (e.width = "100%")),
              this.sidebarSlot &&
                (e = (0, d.h1)(this.getSidebarSlotWidthConfig(e))),
              hs(this.config) &&
                (this.logger.debug(
                  "IVO banner detected. Applying vendor specific css."
                ),
                Un(e)),
              e
            );
          }),
          (r.getSidebarSlotWidthConfig = function (t) {
            var e,
              r,
              i =
                ((e = this.config),
                (null == (r = e.content)
                  ? void 0
                  : r.includes("celtra-ad-v3")) || !1);
            return (
              t.maxDimension && (t.maxDimension.width = 300),
              t.minDimension &&
                (ls(this.config) || us(this.config) || i || hs(this.config)) &&
                (t.minDimension = Os(
                  Os({}, t.minDimension),
                  {},
                  { width: 300 }
                )),
              t
            );
          }),
          (r.detectSidebarSlot = function () {
            this.sidebarSlot = Wr.checkIfSidebarSlot(
              this.config.slot,
              this.win,
              this.config
            );
          }),
          (r.applySidebarSlotWidth = function (t) {
            var e = this.getRenderConfig(),
              r = e.maxDimension,
              i = e.minDimension;
            (t.style.maxWidth = (null == r ? void 0 : r.width) + "px"),
              (t.style.minWidth = (null == i ? void 0 : i.width) + "px");
          }),
          (r.onCreate = function () {
            var e = this,
              r = this.rootElement.querySelector(".kargo-ad-content");
            if (
              (this.detectSidebarSlot(),
              !ai.isVideoBannerFormat(this.config.format))
            ) {
              var i = this.config.format === Br.B.MIDDLE_BANNER ? 300 : 320,
                n = Hr(this.config, this.win) ? i : 440;
              if (
                ("desktop-lighthouse" === this.config.execution && (n = On),
                "flex" === this.config.execution ||
                  "core" === this.config.execution)
              )
                return (
                  this.sidebarSlot && this.applySidebarSlotWidth(r),
                  void t.prototype.onCreate.call(this)
                );
              ai.isDesktopFormat(this.config.format)
                ? (r.style.maxWidth = this.getRenderConfig().width + "px")
                : us(this.config) || ls(this.config)
                ? (r.style.maxWidth = "max-content")
                : (r.style.maxWidth =
                    Math.min(this.win.screen.availWidth, n) + "px"),
                this.expandingFlourish &&
                  !Hr(this.config, this.win) &&
                  (r.style.maxWidth =
                    Math.min(this.win.screen.availWidth, n) + "px"),
                this.sidebarSlot && this.applySidebarSlotWidth(r);
            }
            if (ga(this.config)) {
              var o = (200 - this.win.innerHeight).toString();
              (this.lighthouseObserver = new IntersectionObserver(
                function (t) {
                  t[0].isIntersecting
                    ? e.hideOrShowHovers("hide")
                    : e.hideOrShowHovers("show");
                },
                { rootMargin: o + "px 0px 0px 0px" }
              )),
                this.lighthouseObserver.observe(this.rootElement);
            }
            t.prototype.onCreate.call(this);
          }),
          (r.onLoad = function () {
            var e;
            this.show(),
              this.hasLightboxGlowFlourish && this.setLightboxGlowPaddingVars(),
              this.flourishEligible &&
                null != (e = this.flourishManifest) &&
                e.js &&
                this.executeManifestJs(),
              this.colorPickerEligible() && this.applyFlourishColorPicker(),
              t.prototype.onLoad.call(this);
          }),
          (r.executeManifestJs = function () {
            var t = this,
              e = this.flourishManifest;
            if (e && e.js) {
              var r = this.buildFlourishContext(e);
              if (r) {
                var i = e.js;
                requestAnimationFrame(
                  (0, V.A)(
                    P().mark(function n() {
                      var o, a, s;
                      return P().wrap(
                        function (n) {
                          for (;;)
                            switch ((n.prev = n.next)) {
                              case 0:
                                return (
                                  (n.prev = 0),
                                  (o = new Function(
                                    "ctx",
                                    "return (async () => { " + i + " })();"
                                  )),
                                  (n.next = 4),
                                  o(r)
                                );
                              case 4:
                                t.expandingFlourish &&
                                  Ss(r, {
                                    parallax: !(
                                      null == (a = e.config) || !a.parallax
                                    ),
                                    onOutcome: function (e) {
                                      var r;
                                      e.startsWith("rolled-back") &&
                                        (null == (r = t.clickResolver) ||
                                          r.onNativeClickRolledBack());
                                      we.reportAdMetric(
                                        {
                                          type: "flourish_native_click",
                                          errCode: e,
                                          version: "10.9.0-kat-7484-test",
                                        },
                                        t.config,
                                        t.logger
                                      );
                                    },
                                  }),
                                  (n.next = 12);
                                break;
                              case 7:
                                (n.prev = 7),
                                  (n.t0 = n.catch(0)),
                                  null == (s = t.clickResolver) ||
                                    s.onNativeClickRolledBack(),
                                  t.reportError(
                                    'Inline flourish "' +
                                      e.name +
                                      '" threw: ' +
                                      n.t0
                                  ),
                                  we.reportAdMetric(
                                    {
                                      type: "flourish_js_load_failure",
                                      errCode: "inline_exec_error: " + n.t0,
                                      version: "10.9.0-kat-7484-test",
                                    },
                                    t.config,
                                    t.logger
                                  );
                              case 12:
                              case "end":
                                return n.stop();
                            }
                        },
                        n,
                        null,
                        [[0, 7]]
                      );
                    })
                  )
                );
              }
            }
          }),
          (r.buildFlourishContext = function (t) {
            var e,
              r = this,
              i = t.name,
              n = this.rootElement.querySelectorAll('[class*="' + i + '"]'),
              o = null,
              a = "";
            return (
              Array.from(n).some(function (t) {
                var e = Array.from(t.classList).find(function (t) {
                  return t.includes(i);
                });
                return !!e && ((o = t), (a = e.replace(/-content$/, "")), !0);
              }),
              o
                ? {
                    flourishElement: o,
                    baseClassName: a,
                    document: this.win.document,
                    window: this.win,
                    rootElement: this.rootElement,
                    logger: {
                      debug: function () {
                        var t;
                        return (t = r.logger).debug.apply(t, arguments);
                      },
                      error: function () {
                        var t;
                        return (t = r.logger).error.apply(t, arguments);
                      },
                    },
                    clickUrl:
                      (null == (e = this.clickResolver)
                        ? void 0
                        : e.resolvedUrl) || null,
                    forwardClick: function (t) {
                      var e = t.target;
                      (e && e.closest && e.closest(".kargo-banner-optout")) ||
                        (r.clickResolver && r.clickResolver.forwardClick(t));
                    },
                    bindAdIframe: function (t) {
                      r.clickResolver && r.clickResolver.bindAdIframe(t);
                    },
                    halfPageApproved: Da(
                      this.win,
                      this.config.slot,
                      this.logger
                    ),
                    config: t.config || {},
                    reportError: function (t, e) {
                      r.reportError("[flourish:" + i + "] " + t, e);
                    },
                    getBannerInstance: function () {
                      return r;
                    },
                  }
                : (this.logger.debug(
                    'external-flourish: element not found for "' + i + '"'
                  ),
                  null)
            );
          }),
          (r.colorPickerEligible = function () {
            var t;
            return (
              this.flourishEligible &&
              !(
                null == (t = this.config.source) ||
                null == (t = t.creativeFlags) ||
                null == (t = t.flourish) ||
                !t.color_picker
              )
            );
          }),
          (r.applyFlourishColorPicker = function () {
            var t = this,
              e = this.rootElement.querySelector("iframe.kargo-creative");
            if (e) {
              var r = performance.now(),
                i = this.win.Kargo;
              (i.flourishColor = i.flourishColor || {}),
                (i.flourishColor.reExtract = function () {
                  t.applyFlourishColorPicker();
                }),
                (function () {
                  return ds.apply(this, arguments);
                })()
                  .then(function (n) {
                    var o = n.generateDisplayFlourishColor,
                      a = n.DEFAULT_STRATEGY;
                    t.logger.debug(
                      "flourish-color-picker: module loaded in " +
                        Math.round(performance.now() - r) +
                        "ms"
                    );
                    var s = t.rootElement.querySelector(".kargo-ad-content"),
                      c = i.flourishColor.strategy || a;
                    o(e, s || void 0, c)
                      .then(function (e) {
                        if (!e)
                          return (
                            t.logger.debug(
                              "flourish-color-picker: no colors extracted (" +
                                Math.round(performance.now() - r) +
                                "ms)"
                            ),
                            void t.handleError(
                              "Color picker extraction returned no colors",
                              Wi
                            )
                          );
                        var n = t.rootElement;
                        n.style.setProperty("--flourish-color-1", e.primary),
                          n.style.setProperty(
                            "--flourish-color-2",
                            e.secondary
                          ),
                          (i.flourishColor.debug = {
                            swatches: e.swatches,
                            palette: e.palette,
                            primary: e.primary,
                            secondary: e.secondary,
                          }),
                          "function" == typeof i.flourishColor.uiUpdate &&
                            i.flourishColor.uiUpdate(),
                          t.logger.debug(
                            "flourish-color-picker: applied in " +
                              Math.round(performance.now() - r) +
                              "ms [" +
                              e.source +
                              "] (" +
                              e.primary +
                              ", " +
                              e.secondary +
                              ")"
                          );
                      })
                      .catch(function (e) {
                        t.logger.debug(
                          "flourish-color-picker: color generation failed - " +
                            e
                        ),
                          t.handleError(
                            "Color picker generation failed: " + e,
                            Wi
                          );
                      });
                  })
                  .catch(function (e) {
                    t.logger.debug(
                      "flourish-color-picker: module load failed - " + e
                    ),
                      t.handleError(
                        "Color picker module load failed: " + e,
                        Wi
                      );
                  });
            }
          }),
          (r.onDisplay = function () {
            var e = this.rootElement.querySelectorAll(".kargo-banner-optout");
            Array.from(e).forEach(function (t) {
              w(t, "hide"), g(t, "show");
            }),
              t.prototype.onDisplay.call(this);
          }),
          (r.handleError = function (t, e, r) {
            var i = Rs.errNew(t);
            we.reportAdMetric(
              { type: "failure", version: "10.9.0-kat-7484-test", errCode: e },
              this.config,
              this.logger
            ),
              this.reportError(i, r ? { code: r } : {});
          }),
          (r.checkSizeConstraints = function () {
            this.expandingFlourish ||
              t.prototype.checkSizeConstraints.call(this);
          }),
          (r.onSizeChange = function (e, r) {
            if (
              !ai.isTallFormat(this.config.format) &&
              r > 300 &&
              !this.expandingFlourish
            )
              return (
                this.handleError(
                  "Creative Height exceeded max of 300px;\n          element height: " +
                    r +
                    ";\n          viewport dim: " +
                    this.win.innerWidth +
                    " x " +
                    this.win.innerHeight,
                  zi,
                  pt
                ),
                void this.destroy()
              );
            var i = this.rootElement.querySelector(".kargo-ad-banner"),
              n = this.rootElement.querySelector(".kargo-banner-optout"),
              o =
                "MiddleBanner" === this.config.format &&
                250 === r &&
                ((0, Ur.Fr)(this.win) || (0, Ur.v1)(this.win)),
              a = -1 !== Lr.vW.indexOf(this.config.format);
            this.mobilized &&
              (o || a) &&
              (g(i, "kargo-banner--branding-created"),
              g(n, "kargo-branding-created")),
              this.hasLightboxGlowFlourish && this.setLightboxGlowPaddingVars(),
              t.prototype.onSizeChange.call(this, e, r);
          }),
          (r.onVisible = function () {
            t.prototype.onVisible.call(this);
            var e = this.getGlobalConfig(),
              r = !1;
            if (
              (e && e.isHoverHidingDisabled && (r = e.isHoverHidingDisabled()),
              ka(this.config, this.win))
            ) {
              var i;
              r = !0;
              var n = this.container ? this.container.getType() : null,
                o = this.getCreativeRegister(),
                a = [];
              o && null === n && (a = o.getCreativesOfType("Hover"));
              var s = !1;
              !this.interacted &&
                (0 === a.length || (null != (i = a[0]) && i.isVisible())) &&
                (s = !0),
                s &&
                  (this.win.postMessage(
                    {
                      message: la,
                      adSlot: this.config.slot,
                      localId: this.config.localId,
                    },
                    "*"
                  ),
                  (this.interacted = !0));
            }
            r || this.hideOrShowHovers("hide");
          }),
          (r.onNotVisible = function () {
            t.prototype.onNotVisible.call(this), this.hideOrShowHovers("show");
          }),
          (r.onViewable = function () {
            t.prototype.onViewable.call(this);
          }),
          (r.onDestroy = function () {
            var e;
            null == (e = this.lighthouseObserver) ||
              e.unobserve(this.rootElement),
              t.prototype.onDestroy.call(this),
              this.hideOrShowHovers("show");
          }),
          (r.setLightboxGlowPaddingVars = function () {
            var t = this.rootElement.querySelector(".kargo-ad-content"),
              e = this.rootElement.querySelector(".kargo-creative");
            if (t && e) {
              var r = t.offsetWidth,
                i = t.offsetHeight,
                n = e.offsetWidth,
                o = e.offsetHeight,
                a = Math.min((r - n) / 2),
                s = Math.min((i - o) / 2),
                c = Math.min(a, s, 20);
              this.logger.debug(
                "Setting flourish padding vars with content dimensions " +
                  r +
                  "x" +
                  i +
                  " and creative dimensions " +
                  n +
                  "x" +
                  o +
                  ". Calculated uniform padding: " +
                  c +
                  "px"
              ),
                c <= 0 &&
                  this.handleError(
                    "Not enough space to render lightbox-glow flourish;\n          width margin: " +
                      (r - n) +
                      "px;\n          height margin: " +
                      (i - o) +
                      "px",
                    "flrsh-no-spc"
                  ),
                t.style.setProperty(
                  "--flourish-max-padding",
                  Math.max(0, c) + "px"
                );
            }
          }),
          (r.hideOrShowHovers = function (t) {
            var e = this,
              r = this.container ? this.container.getType() : null,
              i = this.getCreativeRegister();
            if (i && null === r) {
              var n = i.getCreativesOfType("Hover"),
                o = i.getCreativesOfType("Banner"),
                a = (0, d.xF)(this.win, "Kargo.getAdsOfType");
              if (a)
                for (var s = a("Hover"), c = 0; c < s.length; c += 1)
                  n.indexOf(s[c].ad_unit) < 0 && n.push(s[c].ad_unit);
              var l = o.some(function (t) {
                var r = t.getConfig(),
                  i =
                    ai.isDesktopFormat(t.getFormat()) ||
                    Wr.checkIfSidebarSlot(r.slot, e.win, r);
                return t.isVisible() && !i;
              });
              if (
                (!l && "show" === t) ||
                (l && "hide" === t) ||
                ga(this.config)
              )
                for (var u = 0; u < n.length; u += 1)
                  (("hide" === t &&
                    !n[u].getConfig().settings.disable_hover_hiding) ||
                    "show" === t ||
                    ga(this.config)) &&
                    n[u][t]();
            }
          }),
          e
        );
      })(xa);
    const Vs = Ts;
    var Ls = new l.wm("Video"),
      Ps = (function (t) {
        function e() {
          for (var e, r = arguments.length, i = new Array(r), n = 0; n < r; n++)
            i[n] = arguments[n];
          return (
            ((e = t.call.apply(t, [this].concat(i)) || this).isVpaid = !1),
            (e.vastDimensions = null),
            (e.vpaidDimensions = null),
            e
          );
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                var r, i, n;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (r = this.template),
                            (e.prev = 1),
                            (e.next = 4),
                            this.getVideoCreative()
                          );
                        case 4:
                          return (
                            (i = this.video),
                            (this.isVpaid = "VideoPlayer" === i.creativeType),
                            "OutstreamVideo" === this.config.format &&
                              (r.setTemplateVar("VAST", "vast"),
                              r.setTemplateVar("FADE", "unfaded"),
                              this.config.settings.enable_entry_animation &&
                                r.setTemplateVar("BOLT", "kargo")),
                            this.isVpaid && r.setTemplateVar("SHOW", "fade"),
                            !0 === this.config.settings.has_responsive_width &&
                              r.setTemplateVar("WIDTH", "kargo-banner-width"),
                            (n = "Video Creative - "),
                            this.logger.debug("" + n + i.creativeType),
                            this.logger.debug(n + "Snippet Config", i.config),
                            this.logger.debug(
                              n + "Vast Config",
                              i.vast ? i.vast.parsedVastResult : null
                            ),
                            (e.next = 15),
                            t.prototype.display.call(this)
                          );
                        case 15:
                          if (!this.isVpaid) {
                            e.next = 20;
                            break;
                          }
                          return (e.next = 18), i.loadVideoPlayer();
                        case 18:
                          e.sent
                            ? this.setLoaderSize(i.getDimensions())
                            : this.handleVideoDestroy(To, kt);
                        case 20:
                          e.next = 25;
                          break;
                        case 22:
                          (e.prev = 22),
                            (e.t0 = e.catch(1)),
                            this.handleVideoDestroy(
                              e.t0 instanceof Error
                                ? e.t0
                                : new Error(String(e.t0))
                            );
                        case 25:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this,
                  [[1, 22]]
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          (r.getVerticalRenderConfig = function (t) {
            var e = (0, d.h1)({}, t),
              r = this.hasVerticalTemplate(this.config.content);
            if (
              this.vastDimensions &&
              this.vastDimensions.width &&
              this.vastDimensions.height
            ) {
              if (this.vastDimensions.width / this.vastDimensions.height < 1) {
                var i =
                  (this.vastDimensions.width / this.vastDimensions.height) *
                  457;
                (e.width = i),
                  (e.customCss = " width: " + i + "px; height: 457px");
              }
            } else
              r &&
                ((e.customCss += " width: 259px; height: 460px"),
                (e.width = 258),
                (e.maxDimension.width = 258));
            return e;
          }),
          (r.hasVerticalTemplate = function (t) {
            if (t.includes("kit-version=")) {
              var e = (this.config.content.match(/data-ad-execution="(.*?)"/) ||
                [])[1];
              if (e && "Viewstream Vertical" === e) return !0;
            }
            return ["vertical: 'true'", "vertical: true"].some(function (e) {
              return t.includes(e);
            });
          }),
          (r.getRenderConfig = function () {
            var e = this.config.format,
              r = {
                customCss: "text-align: center,",
                width: 300,
                height: 200,
                maxDimension: { height: this.sidebarSlot ? 600 : 460 },
                minDimension: null,
                expansionCheck: !0,
                hide: this.isVpaid,
              },
              i = t.prototype.getRenderConfig.call(this, r);
            this.config.settings.forceResponsive && (i.fullHeight = !0);
            var n = this.hasVerticalTemplate(this.config.content);
            if (
              (ai.isVideoBannerFormat(e) &&
                (0, Ur.xl)(this.win) &&
                !n &&
                !this.config.settings.forceResponsive &&
                (i.maxDimension.width = 300),
              (this.sidebarSlot =
                !!this.config.slot &&
                Wr.checkIfSidebarSlot(this.config.slot, this.win, this.config)),
              ai.isVideoBannerFormat(e) && !1 === this.sidebarSlot)
            ) {
              var o = this.getVerticalRenderConfig(i);
              o && (i = (0, d.h1)(i, o));
            }
            return i;
          }),
          (r.setLoaderSize = function (t) {
            var e = this.rootElement.querySelector(".kargo-loader"),
              r = t.width / t.height;
            if (((e.style.width = "300px"), 1 === r)) e.style.height = "300px";
            else if (r < 1) {
              var i = Number(this.getRenderConfig().width || 0);
              (e.style.width = i + "px"), (e.style.height = (8 * i) / 5 + "px");
            } else e.style.height = 300 / r + "px";
          }),
          (r.onCreate = function () {
            var e = this.rootElement.querySelector(".kargo-ad-content"),
              r = !1;
            this.vastDimensions &&
              this.vastDimensions.height &&
              this.vastDimensions.width &&
              this.vastDimensions.height > this.vastDimensions.width &&
              ((r = !0), g(e, "center-vertical"));
            var i = r || "NonVastOutstreamVideo" === this.config.format,
              n = i ? this.getRenderConfig().width : 300;
            (this.isVpaid || i || Hr(this.config, this.win)) &&
              ((e.style.minWidth = n + "px"),
              (e.style.width = n + "px"),
              (e.style.maxWidth = n + "px")),
              t.prototype.onCreate.call(this);
          }),
          (r.onSizeChange = function (e, r) {
            this.shouldHideLoader() && this.hideLoader(),
              t.prototype.onSizeChange.call(this, e, r);
          }),
          (r.onVisible = function () {
            if ("OutstreamVideo" === this.config.format) {
              var e = this.rootElement.querySelector(".kargo-overlay"),
                r = this.rootElement.querySelector(".kargo-ad-content");
              w(this.rootElement.querySelector(".kargo-banner-optout"), "hide"),
                g(r, "fade"),
                g(e, "fade");
            }
            t.prototype.onVisible.call(this);
          }),
          (r.shouldHideLoader = function () {
            return (
              -1 !==
              ["NonVastOutstreamVideo", "OutstreamVideo"].indexOf(
                this.config.format
              )
            );
          }),
          (r.hideLoader = function () {
            g(this.rootElement.querySelector(".kargo-loader"), "hide");
          }),
          (r.getVideoCreative = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e, r, i, n, o, a;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          return (
                            (this.video =
                              new this.components.ViewstreamComponent(
                                this.win,
                                this.logger,
                                this.ias,
                                this.destroy,
                                this.version
                              )),
                            (e = this.video),
                            (r = !0),
                            (t.prev = 3),
                            e.setSource(this.source),
                            (t.next = 7),
                            e.setConfig(this.config)
                          );
                        case 7:
                          if (
                            !(i =
                              this.config.settings.vast_url ||
                              this.config.settings.vast_xml)
                          ) {
                            t.next = 13;
                            break;
                          }
                          return (t.next = 11), e.parseVast(i);
                        case 11:
                          t.next = 19;
                          break;
                        case 13:
                          if (!this.config.content) {
                            t.next = 18;
                            break;
                          }
                          (e.html = this.config.content),
                            (r = !1),
                            (t.next = 19);
                          break;
                        case 18:
                          throw Ls.errNotSet("VAST or ViewStream snippet");
                        case 19:
                          return (t.next = 21), e.getViewStreamSnippet();
                        case 21:
                          (n = t.sent),
                            r &&
                              (this.config.content =
                                n + (this.config.content || "")),
                            (this.platformMacros = Uo.getPlatformMacros(
                              e.config,
                              e.vast
                            )),
                            e.vast &&
                              ((o = e.vast.getMediaFiles()[0]),
                              (a =
                                o.width && o.height
                                  ? o.width / o.height
                                  : null),
                              (this.vastDimensions = {
                                width: (o || {}).width,
                                height: (o || {}).height,
                              }),
                              null === a || a >= 1
                                ? (this.logger.debug(
                                    "Get a horizontal video, set width to 100%. Video ratio: " +
                                      a
                                  ),
                                  (this.config.settings.has_responsive_width =
                                    !0))
                                : (this.logger.debug(
                                    "Get a vertical video, set width to 300px. Video ratio: " +
                                      a
                                  ),
                                  (this.config.settings.has_responsive_width =
                                    !1))),
                            (t.next = 38);
                          break;
                        case 27:
                          return (
                            (t.prev = 27),
                            (t.t0 = t.catch(3)),
                            (t.next = 31),
                            e.transcodeVast()
                          );
                        case 31:
                          if (
                            !(t.t0 instanceof Error && t.t0.message.match(Do))
                          ) {
                            t.next = 37;
                            break;
                          }
                          this.logger.debug("Attempting to play MP4 from VAST"),
                            (this.config.settings.has_responsive_width = !0),
                            (e.creativeType = "VideoPlayer"),
                            (t.next = 38);
                          break;
                        case 37:
                          throw t.t0;
                        case 38:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this,
                  [[3, 27]]
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          (r.handleVideoDestroy = function (t, e) {
            this.logger.error(t),
              this.video && this.video.fireErrorTrackers(400),
              this.reportError(t, e ? { code: e } : {}),
              this.destroy();
          }),
          e
        );
      })(Vs);
    var Ms = { checked: !1, passive: !1, optionsAsObject: !1 },
      Ns = function (t) {
        if (t && !Ms.checked) {
          try {
            var e = Object.defineProperties(
                {},
                {
                  capture: {
                    get: function () {
                      Ms.optionsAsObject = !0;
                    },
                  },
                  passive: {
                    get: function () {
                      Ms.passive = !0;
                    },
                  },
                }
              ),
              r = function () {};
            t.addEventListener("kargo-test", r, e),
              t.removeEventListener("kargo-test", r, e);
          } catch (t) {}
          Ms.checked = !0;
        }
      };
    function Fs(t, e, r, i, n) {
      void 0 === i && (i = !1), void 0 === n && (n = !1);
      var o = "string" == typeof e ? [e] : e;
      Ns(t);
      var a = i;
      if (
        (Ms.optionsAsObject &&
          ((a = { capture: i }), Ms.passive && (a.passive = n)),
        t.addEventListener)
      )
        for (var s = 0; s < o.length; s += 1) t.addEventListener(o[s], r, a);
    }
    function Bs(t, e, r, i) {
      void 0 === i && (i = !1);
      var n = "string" == typeof e ? [e] : e;
      Ns(t);
      var o = i;
      if ((Ms.optionsAsObject && (o = { capture: i }), t.removeEventListener))
        for (var a = 0; a < n.length; a += 1) t.removeEventListener(n[a], r, o);
    }
    !(function () {
      function t(t) {
        (this.handling = !1),
          (this.listeners = []),
          (this.handleAction = null),
          (this.type = ""),
          (this.handling = t.handling || this.handling),
          (this.listeners = t.listeners || this.listeners),
          (this.handleAction = t.handleAction || this.handleAction),
          (this.type = t.type || this.type);
      }
      (t.prototype.addListener = function (t) {
        t && this.listeners.push(t);
      }),
        (t.prototype.handle = function () {
          for (var t = 0; t < this.listeners.length; t += 1) {
            var e = this.listeners[t];
            this.handleAction
              ? this.handleAction(e, arguments)
              : console.log("handleAction function needed");
          }
        });
    })();
    var Us = (function () {
        function t() {}
        return (
          (t.interact = function (e, r, i, n, o) {
            var a,
              s = e.document.querySelector(
                ".kargo-ad-v5.kargo-ad-" +
                  o.data.localId +
                  '[data-slot="' +
                  o.data.adSlot +
                  '"]'
              );
            if (
              ((a =
                r.percent >= 95
                  ? 0.95
                  : r.percent <= 5
                  ? 0.05
                  : r.percent / 100),
              s)
            )
              if (i) {
                var c = !1;
                o.data.message === la &&
                  qo.observeElement(s, a, !0, function () {
                    Bs(e, "message", t.interact),
                      c || n({ message: ua, format: r.format }),
                      (c = !0);
                  });
              } else {
                var l = !1;
                o.data.message === la &&
                  qo.observeElement(s, a, !1, function (t, e, i) {
                    !l && t.isIntersecting && (l = !0),
                      t.boundingClientRect.y < 0 ||
                        (l &&
                          (e === i || a >= 0.5) &&
                          n({
                            message: ua,
                            format: r.format,
                            adSlot: o.data.adSlot,
                          }));
                  });
              }
          }),
          t
        );
      })(),
      Hs = __webpack_require__(5966),
      js = __webpack_require__(5964),
      zs = {
        hug_side: "bottom",
        branding: "kargo",
        wrapper_fill: !0,
        height_offset: 0,
        wrapper_override: !1,
        wrapper_id: null,
        wrapper_fn: null,
        horizontal_align: null,
        enable_entry_animation: !0,
        prevent_close: !1,
        vast_xml: null,
        vast_url: null,
        click_url_prefix: null,
        click_destination_url: null,
        tracking: {
          viewable: [],
          start: [],
          firstQuartile: [],
          midpoint: [],
          thirdQuartile: [],
          complete: [],
          error: [],
          mute: [],
          unmute: [],
          replay: [],
          expand: [],
          dismiss: [],
        },
        interact_percent: 75,
        bto_interactive_type: null,
      },
      Ws = "tri-plex",
      Ks = __webpack_require__(9452),
      qs = __webpack_require__(9028);
    function Gs(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, i);
      }
      return r;
    }
    function Ys(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2
          ? Gs(Object(r), !0).forEach(function (e) {
              (0, T.A)(t, e, r[e]);
            })
          : Object.getOwnPropertyDescriptors
          ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
          : Gs(Object(r)).forEach(function (e) {
              Object.defineProperty(
                t,
                e,
                Object.getOwnPropertyDescriptor(r, e)
              );
            });
      }
      return t;
    }
    var Js = new l.wm("Hover"),
      Zs = (function (t) {
        function e(e, r, i) {
          var n;
          return (
            ((n = t.call(this, e, r, i) || this).celtraInterval = void 0),
            (n.platformMacros = void 0),
            (n.checkHeightOffset = void 0),
            (n.video = void 0),
            (n.ampMode = null),
            (n.useOverlapDetection = !0),
            (n.templateHtml = Hs),
            (n.templateCss = js),
            (n.celtraInterval = null),
            (n.platformMacros = null),
            n
          );
        }
        Ae(e, t);
        var i = e.prototype;
        return (
          (i.validateConfig = function (e) {
            var r = (0, d.h1)({}, zs),
              i = (0, d.h1)({ settings: r }, e);
            if (
              ((i.type = "Hover"),
              ii(i.slot, this.win) && (r.has_responsive_width = !1),
              r.vast_xml &&
                (r.vast_xml = this.template.getHtml(r.vast_xml, zs.vast_xml)),
              r.tracking &&
                Object.keys(r.tracking).forEach(function (t) {
                  r.tracking[t] = Vr(r.tracking[t]) || [];
                }),
              "has_responsive_width" in r ||
                (r.has_responsive_width = Lr.gY.includes(i.format)),
              void 0 !== e.enable_messaging &&
                (r.enable_messaging = e.enable_messaging),
              -1 !== Lr.cT.indexOf(i.format) &&
                (r.horizontal_align || (r.horizontal_align = "right"),
                "standard-left" === r.execution &&
                  (r.horizontal_align = "left")),
              -1 !== Lr.Nd.indexOf(i.format) && (r.wrapper_fill = !1),
              r.watch_to_unlock &&
                ((r.wrapper_fill = !1), (r.branding = "none")),
              r.wrapper_override)
            ) {
              if (!i.positionElement) {
                if (r.wrapper_fn)
                  try {
                    if (
                      ((i.positionElement = (0, d.zH)(this.win, r.wrapper_fn)),
                      (i.positionLocation = "append"),
                      i.positionElement &&
                        this.win.jQuery &&
                        i.positionElement instanceof this.win.jQuery)
                    ) {
                      var n = i.positionElement;
                      i.positionElement = n[0];
                    }
                  } catch (t) {
                    (i.positionElement = null),
                      t instanceof Error &&
                        this.reportError(
                          "Javascript Error in  " +
                            i.format +
                            " Wrapper Function: " +
                            t.name +
                            " - " +
                            t.message
                        );
                  }
                !i.positionElement &&
                  r.wrapper_id &&
                  ((i.positionElement = this.win.document.getElementById(
                    r.wrapper_id
                  )),
                  (i.positionLocation = "append"));
              }
            } else
              (i.positionElement = this.win.document.body),
                (i.positionLocation = "append");
            return t.prototype.validateConfig.call(this, i);
          }),
          (i.detectContainerEnvironment = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                var r, i, n, o, a;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (e.next = 2),
                            t.prototype.detectContainerEnvironment.call(this)
                          );
                        case 2:
                          return (
                            (r = e.sent),
                            "GoogleAmp" ===
                            (i = this.container
                              ? this.container.getType()
                              : null)
                              ? ("AMP-STICKY-AD" ===
                                (null == (o = this.config.sourceWindow) ||
                                null == (n = o.context) ||
                                null == (n = n.container)
                                  ? void 0
                                  : n.toUpperCase())
                                  ? ((this.ampMode = "legacy"),
                                    (this.config.settings.wrapper_override =
                                      !0))
                                  : ((this.ampMode = "sticky"),
                                    (o.document.body.style.backgroundColor =
                                      "transparent"),
                                    (this.config.settings.prevent_close = !0)),
                                (a = o.document.querySelector("#c > script")),
                                (this.config.positionElement =
                                  a || this.config.sourceElement),
                                (this.config.positionLocation = "before"))
                              : null !== i
                              ? ((this.config.settings.wrapper_override = !0),
                                (this.config.positionElement =
                                  this.config.sourceElement),
                                (this.config.positionLocation = "before"))
                              : this.isInAppWebView() &&
                                ((this.config.settings.wrapper_override = !0),
                                (this.config.settings.prevent_close = !0),
                                (this.config.settings.disable_hover_hiding =
                                  !0),
                                (this.config.positionElement =
                                  this.config.sourceElement),
                                (this.config.positionLocation = "before")),
                            e.abrupt("return", r)
                          );
                        case 6:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          (i.isInAppWebView = function () {
            return (
              null === (this.container ? this.container.getType() : null) &&
              this.config.format === Br.B.HOVER &&
              Dr(this.win)
            );
          }),
          (i.sizeInAppContent = function () {
            var t = this.getContentWrapper();
            t &&
              ((t.style.display = "block"),
              (t.style.width = "100%"),
              (t.style.height = "50px"));
          }),
          (i.setHoverTemplateVars = function (t, e, r) {
            !(function (t, e, r) {
              var i;
              e.settings.wrapper_override && ((t.html = Ks), (t.css = qs)),
                "Wrapper" === e.format
                  ? t.setTemplateVar("HEIGHT_OFFSET", "0")
                  : t.setTemplateVar(
                      "HEIGHT_OFFSET",
                      (null == (i = e.settings.height_offset)
                        ? void 0
                        : i.toString()) || ""
                    ),
                "top" === e.settings.hug_side &&
                  t.setTemplateVar("HUG_SIDE", "kargo-hover--top"),
                e.execution &&
                  e.execution === Ws &&
                  t.setTemplateVar("TRIPLEX", "kargo-triplex-execution"),
                "advertisement" === e.settings.branding
                  ? t.setTemplateVar(
                      "BRANDING",
                      "kargo-hover--branding-advertisement"
                    )
                  : "none" === e.settings.branding &&
                    t.setTemplateVar("BRANDING", "kargo-hover--branding-none"),
                !0 === e.settings.wrapper_fill
                  ? t.setTemplateVar(
                      "WRAPPER_FILL",
                      "kargo-hover--wrapper-fill"
                    )
                  : t.setTemplateVar(
                      "WRAPPER_FILL",
                      "kargo-hover--wrapper-nofill"
                    ),
                "left" === e.settings.horizontal_align
                  ? t.setTemplateVar(
                      "HORIZONTAL_ALIGN",
                      "kargo-hover--align-left"
                    )
                  : "right" === e.settings.horizontal_align &&
                    t.setTemplateVar(
                      "HORIZONTAL_ALIGN",
                      "kargo-hover--align-right"
                    ),
                !0 === e.settings.has_responsive_width &&
                  t.setTemplateVar("WIDTH", "kargo-hover--responsive"),
                e.settings.breakout &&
                  t.setTemplateVar("IS_BREAKOUT", "kargo-hover--breakout"),
                e.settings.prevent_close &&
                  t.setTemplateVar(
                    "PREVENT_CLOSE",
                    "kargo-hover--prevent-close"
                  ),
                "sticky" === r &&
                  "Sidekick" !== e.format &&
                  t.setTemplateVar("AMP_MODE", "kargo-hover--amp-sticky"),
                !0 === e.settings.is_one_sec_interstitial &&
                  t.setTemplateVar(
                    "FORMAT",
                    "kargo-hover--one-sec-interstitial"
                  ),
                "peel-away" === e.execution &&
                  t.setTemplateVar("VERTICAL_ALIGN", "kargo-logo--top"),
                e.format === Br.B.DESKTOP_HOVER &&
                  ("desktop-hover-responsive" === e.execution
                    ? t.setTemplateVar(
                        "DESKTOP_HOVER",
                        "kargo-desktop-hover-responsive"
                      )
                    : t.setTemplateVar("DESKTOP_HOVER", "kargo-desktop-hover"));
            })(t, e, r);
          }),
          (i.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          this.setHoverTemplateVars(
                            this.template,
                            this.config,
                            this.ampMode
                          ),
                            t.prototype.display.call(this);
                        case 2:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          (i.getRenderConfig = function (t) {
            void 0 === t && (t = {});
            var e = {
                width: 0,
                height: 0,
                expansionCheck: !0,
                customCss: "",
                maxDimension: {},
                minDimension: { height: 0, width: 0 },
                macros: this.platformMacros,
              },
              r = (0, d.h1)(e, t),
              i = this.config.format;
            if (i === Br.B.HOVER) {
              (r.minDimension.width = 320),
                (r.minDimension.height = 50),
                (r.maxDimension.height = 77);
              var n = this.config.settings.tracking.interactive;
              n &&
                (r.macros = r.macros
                  ? Ys(Ys({}, r.macros), {}, { interactive: n })
                  : { interactive: n });
            }
            return (
              this.config.settings.watch_to_unlock &&
                ((r.height = 375), (r.expansionCheck = !0)),
              this.config.settings.has_responsive_width &&
                ((r.width = this.win.innerWidth), (r.maxDimension.width = 440)),
              this.config.execution === Ws &&
                ((r.width = 320), (r.height = 150)),
              hs(this.config) &&
                i !== Br.B.SIDEKICK &&
                (this.logger.debug(
                  "IVO hover detected. Applying vendor specific css."
                ),
                Un(r)),
              r
            );
          }),
          (i.getVideoCreative = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e, r, i;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          return (
                            (this.video =
                              new this.components.VideoAnchorComponent(
                                this.win,
                                this.logger,
                                this.ias,
                                this.destroy,
                                this.version
                              )),
                            (e = this.video).setSource(this.source),
                            (t.next = 5),
                            e.setConfig(this.config)
                          );
                        case 5:
                          if (
                            !(r =
                              this.config.settings.vast_url ||
                              this.config.settings.vast_xml)
                          ) {
                            t.next = 11;
                            break;
                          }
                          return (t.next = 9), e.parseVast(r);
                        case 9:
                          t.next = 16;
                          break;
                        case 11:
                          if (!this.config.content) {
                            t.next = 15;
                            break;
                          }
                          (e.html = this.config.content), (t.next = 16);
                          break;
                        case 15:
                          throw Js.errNotSet("VAST or ViewStream snippet");
                        case 16:
                          return (
                            (t.prev = 16),
                            (t.next = 19),
                            e.getVideoAnchorSnippet()
                          );
                        case 19:
                          (i = t.sent),
                            (this.config.content =
                              i + (this.config.content || "")),
                            (this.platformMacros = Uo.getPlatformMacros(
                              e.config,
                              e.vast
                            )),
                            (t.next = 30);
                          break;
                        case 24:
                          if (
                            ((t.prev = 24),
                            (t.t0 = t.catch(16)),
                            "VideoPlayer" === e.creativeType)
                          ) {
                            t.next = 29;
                            break;
                          }
                          return (t.next = 29), e.transcodeVast();
                        case 29:
                          throw t.t0;
                        case 30:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this,
                  [[16, 24]]
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          (i.initializeInteractiveAds = function () {
            var t = this.config.execution,
              e = r()(this.config.settings, "bto_interactive_type"),
              i = {
                animateOnce: !1,
                interactiveCallback: function (t) {
                  !(function (t) {
                    if (null == t)
                      throw new TypeError("Cannot destructure " + t);
                  })(t);
                },
              };
            if ((null != t && t.includes(ha)) || e)
              if (t === ha + "-" + pa || e === pa)
                (i = this.createBtoPickupHover()),
                  this.logger.debug("BTO-pickup hover detected.");
              else if (t === ha + "-" + da || e === da) {
                var n = r()(this.config.settings, "tracking.interactive");
                (i = this.createBtoStaticHover(n)),
                  this.logger.debug("BTO-static hover detected.");
              }
            var o = {
              percent: this.config.settings.interact_percent,
              format: this.config.format,
            };
            Fs(
              this.win,
              "message",
              Us.interact.bind(
                this,
                this.win,
                o,
                i.animateOnce,
                i.interactiveCallback
              )
            );
          }),
          (i.createBtoPickupHover = function () {
            var t = this;
            return {
              animateOnce: !0,
              interactiveCallback: function (e) {
                t.win.postMessage(e, "*"),
                  t.eventHandler.isDestroyed || t.destroy();
              },
            };
          }),
          (i.createBtoStaticHover = function (t) {
            var e = this;
            return {
              animateOnce: !1,
              interactiveCallback: function (r) {
                e.win.postMessage(r, "*"), t && (0, c.Ho)(e.win, t);
              },
            };
          }),
          (i.onCreate = function () {
            var e = this;
            if (this.config.settings.watch_to_unlock) {
              for (
                var r = this.rootElement.querySelectorAll(".kargo-hover-close"),
                  i = 0;
                i < r.length;
                i++
              )
                g(r[i], "hide");
              var n = function (t) {
                t.preventDefault();
              };
              Fs(this.win.document.body, "touchmove", n),
                this.win.setTimeout(function () {
                  e.destroy(), Bs(e.win.document.body, "touchmove", n);
                }, 7e3);
            }
            if (
              (this.isInAppWebView() && this.sizeInAppContent(),
              !this.config.settings.wrapper_override)
            )
              for (
                var o = this.rootElement.querySelectorAll(".kargo-hover-close"),
                  a = 0;
                a < o.length;
                a++
              )
                Fs(
                  o[a],
                  ["click", "touchstart"],
                  this.hoverClose.bind(this),
                  !0,
                  !1
                );
            t.prototype.onCreate.call(this);
          }),
          (i.hoverClose = function (t) {
            t.preventDefault();
            var e = new Event("kargo-hover-close");
            if (
              (this.win.dispatchEvent(e), this.config.settings.tracking.dismiss)
            )
              for (
                var r = 0;
                r < this.config.settings.tracking.dismiss.length;
                r++
              )
                (0, c.Ho)(this.win, this.config.settings.tracking.dismiss[r]);
            "SafeFrame" ===
              (this.container ? this.container.getType() : null) &&
              this.collapseSafeFrameOnClose(),
              this.onClose(),
              this.destroy();
          }),
          (i.collapseSafeFrameOnClose = function () {
            try {
              var t;
              null == (t = this.win.$sf) ||
                null == (t = t.ext) ||
                null == t.collapse ||
                t.collapse();
            } catch (t) {
              this.reportError(
                gn(
                  Js.errNew("SafeFrame collapse failed on hover close: " + t),
                  lt
                )
              );
            }
          }),
          (i.onLoad = function () {
            var e,
              r,
              i =
                null !=
                (e =
                  null == (r = this.win.Kargo) ||
                  null == (r = r.versions) ||
                  null == (r = r[this.version])
                    ? void 0
                    : r.CreativeRegister)
                  ? e
                  : null;
            if (i)
              for (
                var n = i.getCreativesOfType("Hover"), o = 0;
                o < n.length;
                o++
              )
                n[o].getId() !== this.config.id && n[o].destroy();
            (!this.config.wrapper_override && i) || this.show(),
              t.prototype.onLoad.call(this);
          }),
          (i.onDisplay = function () {
            var e = this;
            if (
              null === (this.container ? this.container.getType() : null) &&
              "bottom" === this.config.settings.hug_side &&
              "ios" === (0, Ur.R0)(this.win) &&
              "safari" === (0, Ur.X5)(this.win)
            ) {
              var r = 0;
              (this.checkHeightOffset = function () {
                var t,
                  i,
                  n,
                  o,
                  a =
                    ((t = e.win),
                    (i = t.document.documentElement || t.document.body),
                    (n =
                      t.innerWidth ||
                      i.clientWidth ||
                      t.document.body.offsetWidth),
                    (o =
                      t.innerHeight ||
                      i.clientHeight ||
                      t.document.body.offsetHeight),
                    {
                      x: n,
                      y: o,
                      screen: { w: t.screen.width, h: t.screen.height },
                      total_y: i.scrollHeight,
                      orientation: n < o ? "portrait" : "landscape",
                    }),
                  s = 0;
                if (
                  ("landscape" === a.orientation &&
                    (s = a.screen.w - e.win.innerHeight),
                  s !== r)
                ) {
                  r = s;
                  var c = e.rootElement.querySelector(".kargo-ad-hover");
                  c && (c.style.marginBottom = s + "px");
                }
              }),
                Fs(this.win, "resize", this.checkHeightOffset, !1, !0);
            }
            (this.win.Kargo.externApi = this.win.Kargo.externApi || {}),
              (this.win.Kargo.externApi.KAP_READY = function () {
                e.rootElement
                  .querySelector(".kargo-ad-hover")
                  .classList.add("is-loaded");
              }),
              this.win.setTimeout(function () {
                e.win.Kargo.externApi.KAP_READY();
              }, 500),
              t.prototype.onDisplay.call(this);
          }),
          (i.onSizeChange = function (e, r) {
            if (
              (null !== this.overlapMonitor &&
                this.overlapMonitor.checkOverlap(),
              r > 200 &&
                "Wrapper" !== this.config.format &&
                this.rootElement
                  .querySelectorAll(".kargo-hover-close")
                  .forEach(function (t) {
                    return g(t, "expanded");
                  }),
              this.config.format === Br.B.DESKTOP_HOVER ||
                this.config.format === Br.B.HOVER)
            ) {
              var i,
                n = 200;
              if (
                ("open" ===
                  (null == (i = this.config.source) ||
                  null == (i = i.auctionType)
                    ? void 0
                    : i.toLowerCase()) &&
                  (n = "DesktopHover" === this.config.format ? 90 : 50),
                r > n)
              ) {
                var o = Js.errNew(
                  " " +
                    this.config.format +
                    " Height exceeded max of " +
                    n +
                    "px;\n          creative height: " +
                    r +
                    ";\n          viewport dimensions: " +
                    this.win.innerWidth +
                    " x " +
                    this.win.innerHeight
                );
                we.reportAdMetric(
                  {
                    type: "failure",
                    version: "10.9.0-kat-7484-test",
                    errCode: zi,
                  },
                  this.config,
                  this.logger
                ),
                  this.reportError(o, { code: pt }),
                  this.destroy();
              }
            }
            if (this.config.format && Lr.$U.includes(this.config.format)) {
              var a = (function (t, e) {
                var r;
                if (!xn(t.content)) return null;
                var i =
                  null == e ||
                  null == (r = e.getFrame()) ||
                  null == (r = r.contentDocument)
                    ? void 0
                    : r.querySelector("iframe[srcdoc]");
                return null != i ? i : null;
              })(this.config, this.renderer);
              a &&
                (this.logger.debug(
                  "DV injected frame detected. Fallback DV frame size."
                ),
                a.style.setProperty("width", "100%", "important"),
                a.style.setProperty("height", "150px", "important"));
            }
            t.prototype.onSizeChange.call(this, e, r);
          }),
          (i.onVisible = function () {
            var e,
              r,
              i = this;
            ((this.config.execution && this.config.execution.includes(ha)) ||
              this.config.settings.bto_interactive_type) &&
              this.initializeInteractiveAds(),
              this.config.settings.enable_messaging &&
                window.addEventListener("message", function (t) {
                  var e = i.rootElement.querySelector(Gr).contentWindow;
                  e && e.postMessage(t.data, "*");
                });
            var n = this.container ? this.container.getType() : null,
              o =
                null !=
                (e =
                  null == (r = this.win.Kargo) ||
                  null == (r = r.versions) ||
                  null == (r = r[this.version])
                    ? void 0
                    : r.CreativeRegister)
                  ? e
                  : null,
              a = this.getGlobalConfig(),
              s = !1;
            a && a.isHoverHidingDisabled && (s = a.isHoverHidingDisabled());
            var c =
              "branded_takeover" === this.config.placementType &&
              Hr(this.config, this.win);
            if (
              ((this.config.settings.disable_hover_hiding || c) && (s = !0), o)
            ) {
              var l = o.getCreativesOfType("Banner");
              if (l.length)
                for (var u = 0; u < l.length; u++) {
                  var h = l[u].getConfig ? l[u].getConfig() : null,
                    d =
                      -1 !== Lr._G.indexOf(l[u].getFormat()) ||
                      Wr.checkIfSidebarSlot(
                        null == h ? void 0 : h.slot,
                        this.win,
                        null != h ? h : void 0
                      ),
                    p = !!h && ga(h),
                    g = !!h && ka(h, this.win);
                  !(!s && null === n) ||
                    !l[u].isVisible() ||
                    d ||
                    p ||
                    g ||
                    this.hide();
                }
              t.prototype.onVisible.call(this);
            }
          }),
          (i.onViewable = function () {
            if (this.config.settings.tracking.viewable)
              for (
                var e = 0;
                e < this.config.settings.tracking.viewable.length;
                e++
              )
                (0, c.Ho)(this.win, this.config.settings.tracking.viewable[e]);
            t.prototype.onViewable.call(this);
          }),
          (i.onDestroy = function () {
            var e = r()(this.config.settings, "tracking.interactive");
            this.celtraInterval && clearInterval(this.celtraInterval),
              e && (0, c.Ho)(this.win, e),
              t.prototype.onDestroy.call(this);
          }),
          (i.destroy = function () {
            this.checkHeightOffset &&
              (Bs(this.win, "resize", this.checkHeightOffset),
              (this.checkHeightOffset = null));
            var e = this.rootElement.querySelector(Gr).contentWindow,
              r = (0, d.xF)(e, "Kargo.PlatformMacros");
            r && r.destroyBtoStunts && r.destroyBtoStunts(),
              t.prototype.destroy.call(this);
          }),
          e
        );
      })(xa);
    const $s = Zs;
    var Xs;
    !(function (t) {
      (t.NATIVE =
        "https://storage.cloud.kargo.com/ad/network/tag/ad-native.js"),
        (t.NATIVE_STAGING =
          "https://storage.cloud.kargo.com/ad/network/tag/ad-native-stag.js");
    })(Xs || (Xs = {}));
    var Qs = (function (t) {
        function e() {
          for (var e, i = arguments.length, n = new Array(i), o = 0; o < i; o++)
            n[o] = arguments[o];
          return (
            ((e =
              t.call.apply(t, [this].concat(n)) || this).setHoverTemplateVars =
              function (i, n, o) {
                t.prototype.setHoverTemplateVars.call(e, i, n, o);
                var a = e.template,
                  s = e.config.settings.native;
                "aba-adhesion-display-2" ===
                  r()(s, "creativeOptimizer.template_id") &&
                  (a.setTemplateVar(
                    "WRAPPER_FILL",
                    "kargo-hover--wrapper-nofill"
                  ),
                  a.setTemplateVar(
                    "HORIZONTAL_ALIGN",
                    "kargo-hover--align-right"
                  ),
                  a.setTemplateVar(
                    "SIDEKICK_BRANDING",
                    "kargo-sidekick-branding"
                  ),
                  a.setTemplateVar("SIDEKICK_WIDTH", "140"));
              }),
            e
          );
        }
        return (
          Ae(e, t),
          (e.prototype.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                var r, i, n;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (
                            (this.setHoverTemplateVars(
                              this.template,
                              this.config,
                              this.ampMode
                            ),
                            ((r = this.config.settings.native).template_type =
                              "Anchor"),
                            this.logger.debug("Native config: ", r),
                            Object.keys(r || {}).length)
                          ) {
                            i = JSON.stringify(r);
                            try {
                              i = btoa(i);
                            } catch (t) {
                              if (
                                t instanceof Error &&
                                t.message.includes("Latin1")
                              ) {
                                i = (0, d.a)(i);
                                try {
                                  i = btoa(i);
                                } catch (t) {
                                  this.reportError(
                                    "Native: Error encoding the creative. Fix attempted but failed",
                                    { code: Ct }
                                  ),
                                    we.reportAdMetric(
                                      {
                                        type: "failure",
                                        version: "10.9.0-kat-7484-test",
                                        errCode: ji,
                                      },
                                      this.config,
                                      this.logger
                                    );
                                }
                              }
                            }
                            (n =
                              "true" ===
                              (0, o.P3)((0, o.pO)(this.win), "krg_qa")
                                ? Xs.NATIVE_STAGING
                                : Xs.NATIVE),
                              (this.config.content =
                                (this.config.content || "") +
                                '<script type="text/javascript" src="' +
                                n +
                                '"></script><script type="text/javascript">(function(){new window.Kargo.Native(JSON.parse(atob("' +
                                i +
                                '")));})();</script>');
                          }
                          return e.abrupt(
                            "return",
                            t.prototype.display.call(this)
                          );
                        case 6:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          e
        );
      })($s),
      tc = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        Ae(e, t);
        var i = e.prototype;
        return (
          (i.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                var i, n, a, s, c, l, u, h;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            this.logger.debug(
                              "Loading Native ads in its own space"
                            ),
                            (i = this.template),
                            (n = this.config.settings.native),
                            (e.next = 5),
                            this.getKeyArtCreative()
                          );
                        case 5:
                          (a = e.sent),
                            i.setTemplateVar("ABOVE", "above"),
                            (n.auctionType = r()(
                              this.config,
                              "source.auctionType"
                            )),
                            (n.video = a),
                            a
                              ? (n.video = a)
                              : (this.config.format = Br.B.ABA_DISPLAY),
                            (n.platform_version = this.config.platform_version),
                            (s = this.config.format),
                            (c = (n.video || {}).tracking),
                            (l = this.config.settings.tracking),
                            c &&
                              Object.keys(c).forEach(function (t) {
                                var e = l[t] || [];
                                e.length && (c[t] = [].concat(c[t], e));
                              }),
                            (n.template_type =
                              s === Br.B.NATIVE || s === Br.B.ABA_DISPLAY
                                ? "Banner"
                                : "VideoKeyArt"),
                            this.logger.debug("Native config: ", n),
                            (u = JSON.stringify(n));
                          try {
                            u = btoa(u);
                          } catch (t) {
                            if (
                              t instanceof Error &&
                              t.message.includes("Latin1")
                            ) {
                              u = (0, d.a)(u);
                              try {
                                u = btoa(u);
                              } catch (t) {
                                this.reportError(
                                  "Native: Error encoding the creative. Fix attempted but failed",
                                  { code: Ct }
                                ),
                                  we.reportAdMetric(
                                    {
                                      type: "failure",
                                      version: "10.9.0-kat-7484-test",
                                      errCode: ji,
                                    },
                                    this.config,
                                    this.logger
                                  );
                              }
                            }
                          }
                          return (
                            (h =
                              "true" ===
                              (0, o.P3)((0, o.pO)(this.win), "krg_qa")
                                ? Xs.NATIVE_STAGING
                                : Xs.NATIVE),
                            (this.config.content =
                              (this.config.content || "") +
                              '<script type="text/javascript" src="' +
                              h +
                              '"></script><script type="text/javascript">(function(){new window.Kargo.Native(JSON.parse(atob("' +
                              u +
                              '")));})();</script>'),
                            e.abrupt("return", t.prototype.display.call(this))
                          );
                        case 22:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          (i.getKeyArtCreative = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (
                            ((this.video =
                              new this.components.NativeVideoComponent(
                                this.win,
                                this.logger,
                                this.ias,
                                this.destroy,
                                this.version
                              )),
                            (e = this.video),
                            this.config.settings.native &&
                              this.config.settings.native.vast)
                          ) {
                            t.next = 4;
                            break;
                          }
                          return t.abrupt("return");
                        case 4:
                          return (
                            (t.prev = 4),
                            e.setSource(this.source),
                            (t.next = 8),
                            e.setConfig(this.config)
                          );
                        case 8:
                          return (
                            (t.next = 10),
                            e.parseVast(this.config.settings.native.vast)
                          );
                        case 10:
                          return (t.next = 12), e.getNativeVideoSnippet();
                        case 12:
                          return t.abrupt("return", t.sent);
                        case 15:
                          return (
                            (t.prev = 15),
                            (t.t0 = t.catch(4)),
                            (t.next = 19),
                            e.transcodeVast()
                          );
                        case 19:
                          if (t.t0 instanceof Error && t.t0.message.match(Do)) {
                            t.next = 21;
                            break;
                          }
                          throw t.t0;
                        case 21:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this,
                  [[4, 15]]
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          (i.getRenderConfig = function () {
            return t.prototype.getRenderConfig.call(this, {
              width: 300,
              height: 250,
              expansionCheck: !0,
            });
          }),
          e
        );
      })(Vs),
      ec = tc,
      rc = tc,
      ic = __webpack_require__(7108);
    function nc(t, e) {
      for (
        var r = new RegExp(
            '<Extension\\s+[^>]*?type="' +
              t +
              '"[^>]*?>\\s*?<!\\[CDATA\\[(.*?)\\]\\]>\\s*?<\\/Extension>',
            "g"
          ),
          i = e.matchAll(r),
          n = [],
          o = i.next();
        o && !o.done;

      ) {
        var a = o.value;
        a && a[1] && n.push(a[1]), (o = i.next());
      }
      return n;
    }
    function oc(t) {
      var e = nc("kargo-outstream", t);
      return e && 0 !== e.length ? JSON.parse(e[0]) : {};
    }
    function ac(t) {
      return nc("load", t);
    }
    function sc(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, i);
      }
      return r;
    }
    function cc(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2
          ? sc(Object(r), !0).forEach(function (e) {
              (0, T.A)(t, e, r[e]);
            })
          : Object.getOwnPropertyDescriptors
          ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
          : sc(Object(r)).forEach(function (e) {
              Object.defineProperty(
                t,
                e,
                Object.getOwnPropertyDescriptor(r, e)
              );
            });
      }
      return t;
    }
    var lc = (function (t) {
        function e() {
          for (var e, r = arguments.length, i = new Array(r), n = 0; n < r; n++)
            i[n] = arguments[n];
          return (
            ((e = t.call.apply(t, [this].concat(i)) || this).fabrikExtension =
              null),
            e
          );
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.validateConfig = function (e) {
            var r = e || {};
            return (
              (r.settings = r.settings || {}),
              (r.settings.has_responsive_width = !0),
              t.prototype.validateConfig.call(this, r)
            );
          }),
          (r.getRenderConfig = function (e) {
            var r;
            void 0 === e && (e = {});
            var i = (0, d.h1)(
              {
                width: 300,
                height: 200,
                minDimension: { width: 300, height: 200 },
                expansionCheck: !0,
              },
              e
            );
            return (
              null != (r = i = t.prototype.getRenderConfig.call(this, i)) &&
                null != (r = r.maxDimension) &&
                r.width &&
                delete i.maxDimension.width,
              i
            );
          }),
          (r.setFabrikExtension = function () {
            var t = this.config.settings.vast_xml;
            if (!t) return new Error("empty vast xml");
            var e = oc(t);
            return e.template || e.templateURL
              ? ((this.fabrikExtension = e),
                (this.fabrikExtension.templateVars =
                  this.fabrikExtension.templateVars || {}),
                null)
              : new Error(
                  "failed to fetch fabrik template name or url from vast xml"
                );
          }),
          (r.tojson = function (t) {
            try {
              return JSON.parse(t), t;
            } catch (e) {
              return JSON.stringify(t);
            }
          }),
          (r.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                var r,
                  i,
                  n,
                  o,
                  a,
                  s,
                  c,
                  l,
                  u,
                  h,
                  d,
                  p,
                  g,
                  f,
                  v,
                  m,
                  k,
                  b = this;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (
                            (((u = this.template).css += ic),
                            u.setTemplateVar("ABOVE", "above"),
                            this.fabrikExtension)
                          ) {
                            e.next = 8;
                            break;
                          }
                          if (!(h = this.setFabrikExtension())) {
                            e.next = 8;
                            break;
                          }
                          return (
                            this.destroyWithError(h, St), e.abrupt("return")
                          );
                        case 8:
                          return (
                            this.logger.debug(
                              "Writing Fabrik template: " +
                                ((null == (r = this.fabrikExtension)
                                  ? void 0
                                  : r.templateURL) ||
                                  (null == (i = this.fabrikExtension)
                                    ? void 0
                                    : i.template))
                            ),
                            (d = new this.components.FabrikTemplate(
                              null == (n = this.fabrikExtension)
                                ? void 0
                                : n.template,
                              null == (o = this.fabrikExtension)
                                ? void 0
                                : o.templateURL
                            )),
                            (p = cc(
                              {},
                              null == (a = this.fabrikExtension)
                                ? void 0
                                : a.templateVars
                            )),
                            null != (s = this.fabrikExtension) &&
                              s.execution &&
                              (p.EXECUTION = this.fabrikExtension.execution),
                            null != (c = this.fabrikExtension) &&
                              c.companionsParameters &&
                              ((g = this.fabrikExtension.companionsParameters),
                              (f = g.captions),
                              (v = g.eventsHandler),
                              (p.CAPTIONS_METADATA = this.tojson(f)),
                              v && (p.EVENTS_HANDLER_DATA = v)),
                            Object.keys(p).forEach(function (t) {
                              d.setMacroValue(t, p ? p[t] : "");
                            }),
                            d.setVastXML(this.config.settings.vast_xml),
                            (e.prev = 15),
                            (e.next = 18),
                            d.getHTML()
                          );
                        case 18:
                          (m = e.sent),
                            (this.config.content += m),
                            (e.next = 26);
                          break;
                        case 22:
                          return (
                            (e.prev = 22),
                            (e.t0 = e.catch(15)),
                            this.destroyWithError(
                              new Error(
                                'failed to fetch "' +
                                  (null == (k = this.fabrikExtension)
                                    ? void 0
                                    : k.template) +
                                  '" template: ' +
                                  e.t0
                              )
                            ),
                            e.abrupt("return")
                          );
                        case 26:
                          return (
                            "advertisement" ===
                              (null == (l = this.fabrikExtension)
                                ? void 0
                                : l.branding) &&
                              ((this.config.settings.branding =
                                "advertisement"),
                              (this.mobilized = !1)),
                            ac(this.config.settings.vast_xml).forEach(function (
                              t
                            ) {
                              b.config.content +=
                                '<img style="position: absolute; visibility: hidden; left: -9999px; top: 0;" src="' +
                                t +
                                '" />';
                            }),
                            (e.next = 30),
                            t.prototype.display.call(this)
                          );
                        case 30:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this,
                  [[15, 22]]
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          (r.destroyWithError = function (t, e) {
            this.logger.error(t),
              this.reportError(t, e ? { code: e } : {}),
              this.destroy();
          }),
          e
        );
      })(Vs),
      uc = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        return Ae(e, t), e;
      })(lc),
      hc = (function (t) {
        function e(e, r, i) {
          var n;
          return (
            ((n = t.call(this, e, r, i) || this).closeBtn = void 0),
            (n.closeBtn = null),
            n
          );
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.getRenderConfig = function () {
            var e = { width: 0 };
            return (
              ls(this.config) && ((e.height = 150), (e.width = 320)),
              this.config.execution === Ws &&
                ((e.width = 320), (e.height = 150)),
              t.prototype.getRenderConfig.call(this, e)
            );
          }),
          (r.onCreate = function () {
            var e = this;
            (this.closeBtn = this.win.document.querySelector(
              ".kargo-hover-close.unfilled"
            )),
              (this.config.settings.isGwdAnchor ||
                ls(this.config) ||
                this.config.execution === Ws) &&
                this.win.addEventListener("message", function (t) {
                  var r = t.data;
                  "function" == typeof e[r] &&
                    (e[r](),
                    e.logger.debug("Anchor post-message event: " + t.data));
                }),
              t.prototype.onCreate.call(this);
          }),
          (r.hideCloseBtn = function () {
            this.closeBtn && (this.closeBtn.style.display = "none");
          }),
          (r.showCloseBtn = function () {
            this.closeBtn && (this.closeBtn.style.display = "block");
          }),
          (r.gwdAnchorCollapse = function () {
            ei(this.rootElement).height = "50";
          }),
          e
        );
      })($s),
      dc = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        return Ae(e, t), e;
      })(Vs),
      pc = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.display = function () {
            var e = this,
              r = this.template;
            r.setTemplateVar("WIDTH", "desktop");
            var i = Lr.hR.filter(function (t) {
              return t.name === e.config.format;
            })[0];
            return (
              r.setTemplateVar("DESKTOP_WIDTH", i.size.w.toString()),
              t.prototype.display.call(this)
            );
          }),
          (r.getRenderConfig = function (e) {
            void 0 === e && (e = {});
            var r = t.prototype.getRenderConfig.call(this, e);
            return (
              r.minDimension &&
                "number" == typeof r.width &&
                ((r.minDimension.width = r.width),
                (r.minDimension.height = r.height)),
              r.maxDimension &&
                "number" == typeof r.width &&
                ((r.maxDimension.width = r.width),
                (r.maxDimension.height = r.height)),
              r
            );
          }),
          e
        );
      })(Vs),
      gc = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        return (
          Ae(e, t),
          (e.prototype.getRenderConfig = function () {
            return t.prototype.getRenderConfig.call(this, {
              width: 970,
              height: 250,
            });
          }),
          e
        );
      })(pc),
      fc = __webpack_require__(1752),
      vc = (function (t) {
        function e() {
          for (var e, r = arguments.length, i = new Array(r), n = 0; n < r; n++)
            i[n] = arguments[n];
          return (
            ((e = t.call.apply(t, [this].concat(i)) || this).fitToViewport =
              function () {
                if (e.rootElement.isConnected) {
                  var t = e.getContentWrapper();
                  if (t) {
                    var r = e.win.document.documentElement.clientWidth;
                    t.style.setProperty("--krg-bitly-width", r + "px"),
                      (t.style.left = ""),
                      fa(t);
                  }
                } else e.stopViewportTracking();
              }),
            e
          );
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            this.template && (this.template.css += fc),
                            e.abrupt("return", t.prototype.display.call(this))
                          );
                        case 2:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          (r.onCreate = function () {
            Hr(this.config, this.win) &&
              (this.fitToViewport(),
              Fs(this.win, "resize", this.fitToViewport, !1, !0)),
              t.prototype.onCreate.call(this);
          }),
          (r.destroy = function () {
            this.stopViewportTracking(), t.prototype.destroy.call(this);
          }),
          (r.stopViewportTracking = function () {
            Bs(this.win, "resize", this.fitToViewport);
          }),
          e
        );
      })(Vs),
      mc = Vs,
      kc = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.getRenderConfig = function () {
            var e = { width: 0 };
            return (
              ls(this.config) &&
                ((e.expansionCheck = !1),
                (e.customCss = "width: 100%;"),
                (e.height = 150),
                (e.minDimension = null)),
              t.prototype.getRenderConfig.call(this, e)
            );
          }),
          (r.display = function () {
            var e = this.template,
              r = "kargo-sidekick-branding kargo-breakaway-branding";
            return (
              "standard-left" === this.config.execution &&
                ((r += " breakaway-left-align"),
                e.setTemplateVar("LEFT_ALIGN", "left-align")),
              e.setTemplateVar("SIDEKICK_BRANDING", r),
              t.prototype.display.call(this)
            );
          }),
          e
        );
      })($s),
      bc = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        return (
          Ae(e, t),
          (e.prototype.display = function () {
            return (
              this.template.setTemplateVar("FORMAT", "kargo-hover--breakout"),
              t.prototype.display.call(this)
            );
          }),
          e
        );
      })($s),
      yc = __webpack_require__(4490),
      wc = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.getRenderConfig = function () {
            return t.prototype.getRenderConfig.call(this, {
              width: 970,
              height: 200,
              has_responsive_width: !0,
            });
          }),
          (r.display = function () {
            return (
              this.template && (this.template.html = yc),
              this.template.setTemplateVar(
                "FORMAT",
                "kargo-hover--desktop-breakout"
              ),
              (this.config.settings.wrapper_fill = !1),
              t.prototype.display.call(this)
            );
          }),
          e
        );
      })($s),
      _c = __webpack_require__(2164),
      Ac = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.getRenderConfig = function () {
            return t.prototype.getRenderConfig.call(this, {
              width: 728,
              height: 90,
            });
          }),
          (r.display = function () {
            return (
              this.template && (this.template.html = _c),
              t.prototype.display.call(this)
            );
          }),
          e
        );
      })($s),
      Cc = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        return (
          Ae(e, t),
          (e.prototype.display = function () {
            return (
              this.template.setTemplateVar(
                "RUNWAY",
                "kargo-desktop-runway-close"
              ),
              t.prototype.display.call(this)
            );
          }),
          e
        );
      })(wc),
      Ec = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        return (
          Ae(e, t),
          (e.prototype.getRenderConfig = function () {
            return t.prototype.getRenderConfig.call(this, {
              width: 728,
              height: 90,
              expansionCheck: !0,
            });
          }),
          e
        );
      })(pc),
      xc = __webpack_require__(8632),
      Sc = __webpack_require__(2482),
      Ic = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        return (
          Ae(e, t),
          (e.prototype.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (this.config.settings.has_responsive_width = !0),
                            this.template &&
                              ((this.template.html = xc),
                              (this.template.css += Sc)),
                            e.abrupt("return", t.prototype.display.call(this))
                          );
                        case 3:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          e
        );
      })(Ec),
      Oc = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.validateConfig = function (e) {
            var r = t.prototype.validateConfig.call(this, e);
            return (r.settings.has_responsive_width = !1), r;
          }),
          (r.getRenderConfig = function () {
            return t.prototype.getRenderConfig.call(this, {
              width: 300,
              height: 600,
              expansionCheck: !0,
            });
          }),
          e
        );
      })(pc),
      Rc = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        return (
          Ae(e, t),
          (e.prototype.getRenderConfig = function () {
            var e = t.prototype.getRenderConfig.call(this);
            return (
              (e.height = "max" === this.config.execution ? 50 : 250),
              (e.maxDimension.height = 460),
              (e.expansionCheck = !0),
              e
            );
          }),
          e
        );
      })(Vs),
      Dc = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.onCreate = function () {
            var e = this.config.execution,
              r = this.rootElement.querySelector(".kargo-ad-content");
            e &&
              Nn.includes(e) &&
              Hr(this.config, this.win) &&
              (this.detectSidebarSlot(), this.handleFlexWidth(r)),
              t.prototype.onCreate.call(this);
          }),
          (r.handleFlexWidth = function (t) {
            var e = this.rootElement.parentNode.offsetWidth,
              r = this.config,
              i = r.execution,
              n = r.format,
              o = this.sidebarSlot ? Rn : Dn;
            (t.style.minWidth = Rn + "px"),
              (t.style.width = (this.sidebarSlot ? Rn : e) + "px"),
              (t.style.maxWidth = o + "px");
            var a = Math.min(Math.max(e, Rn), o);
            this.logger.debug(n + " " + i + ": setting width to " + a + "px");
          }),
          (r.getRenderConfig = function () {
            var e = t.prototype.getRenderConfig.call(this, {
              height: 350,
              minDimension: { height: 350 },
              expansionCheck: !0,
            });
            if ("open" !== this.config.source.auctionType) {
              var r = this.win.innerWidth || 320,
                i = Math.min(Math.round(r / (440 / 350)), 350);
              e.minDimension.height = i;
            }
            return (
              this.config.execution === Ln &&
                ((e.minDimension.width = Rn),
                this.sidebarSlot || (e.maxDimension.width = Dn)),
              e
            );
          }),
          e
        );
      })(Vs),
      Tc = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        return (
          Ae(e, t),
          (e.prototype.getRenderConfig = function () {
            var e,
              r = t.prototype.getRenderConfig.call(this, {
                width: 970,
                height: 90,
                expansionCheck: !0,
              });
            return null == (e = r.maxDimension) || delete e.height, r;
          }),
          e
        );
      })(pc),
      Vc = __webpack_require__(7967),
      Lc = __webpack_require__.n(Vc);
    function Pc(t, e, i, n) {
      var o = r()(e, t);
      Array.isArray(o) && 0 !== o.length
        ? o.forEach(function (e) {
            (0, c.Ho)(i, e), n.debug("Fired " + t + " tracker");
          })
        : n.debug("No " + t + " tracker found");
    }
    function Mc(t, e) {
      var r = t.getBoundingClientRect();
      if ((0, i.sk)(e) === e) return r;
      for (var n = r.x, o = r.y, a = e; a !== a.top; ) {
        var s = a.frameElement.getBoundingClientRect();
        (n += s.x), (o += s.y), (a = a.parent);
      }
      return new DOMRect(n, o, r.width, r.height);
    }
    var Nc = __webpack_require__(2390),
      Fc = __webpack_require__(5071),
      Bc = __webpack_require__(6012),
      Uc = 1500,
      Hc = "lighthouse_sticky_event",
      jc = "lighthouse_skip_button_click",
      zc = "kargo-lighthouse-fixed",
      Wc = "kargo-lighthouse-bottom",
      Kc = "kargo-lighthouse-relative",
      qc = "kargo-lighthouse-skip",
      Gc = "kargo-lighthouse-scroller",
      Yc = "kargo-lighthouse-scrollbar",
      Jc = (function (t) {
        function e() {
          for (var e, r = arguments.length, n = new Array(r), o = 0; o < r; o++)
            n[o] = arguments[o];
          return (
            ((e = t.call.apply(t, [this].concat(n)) || this).stickyObserver =
              void 0),
            (e.scrollEventListener = void 0),
            (e.sticky = !1),
            (e.stickyHeight = void 0),
            (e.boundStickyLighthouseHandler = e.addStickyHeight.bind(e)),
            (e.parentScrollbarStyles = null),
            (e.debouncedStyleCleanup = void 0),
            (e.vh = (0, i.sk)(e.win).innerHeight || e.win.innerHeight),
            e
          );
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.getRenderConfig = function () {
            return t.prototype.getRenderConfig.call(this, {
              width: 320,
              height: 0,
              expansionCheck: !0,
            });
          }),
          (r.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                var r;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (this.sticky = this.isStickyEnabled()),
                            this.sticky &&
                              (Pc(
                                Hc,
                                null == (r = this.config.settings)
                                  ? void 0
                                  : r.tracking,
                                this.win,
                                this.logger
                              ),
                              this.win.addEventListener(
                                "message",
                                this.boundStickyLighthouseHandler
                              ),
                              (this.template.css += Nc),
                              (this.stickyHeight = this.win.innerHeight + Uc),
                              (this.rootElement.style.height =
                                this.stickyHeight + "px")),
                            (e.next = 4),
                            t.prototype.display.call(this)
                          );
                        case 4:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          (r.isStickyEnabled = function () {
            var t,
              e =
                !0 ===
                (null == (t = this.config.settings)
                  ? void 0
                  : t.enable_sticky_lighthouse),
              r =
                !0 === this.win.__krg_enable_sticky_lighthouse ||
                void 0 === this.win.__krg_enable_sticky_lighthouse,
              i = !1 !== r && (r || e),
              n = Hr(this.config, this.win);
            return "standard" !== this.config.execution && !!i && !n;
          }),
          (r.addStickyHeight = function (t) {
            if (
              "string" == typeof t.data &&
              "sticky_lighthouse_height" === t.data.split("|")[0]
            ) {
              var e = t.data.match(/height=(\d+)/),
                r = e ? parseInt(e[1], 10) : Uc;
              (this.stickyHeight = this.win.innerHeight + Math.min(r, 2400)),
                (this.rootElement.style.height = this.stickyHeight + "px");
              var i = this.rootElement.querySelector(".kargo-ad-banner");
              i && (i.style.height = this.stickyHeight + "px"),
                Bs(this.win, "message", this.boundStickyLighthouseHandler);
            }
          }),
          (r.createSkipButton = function (t) {
            var e = this;
            if (!t.querySelector("." + qc)) {
              var r = this.win.document.createElement("div");
              (r.className = qc), (r.innerHTML = Fc);
              var i = function (t) {
                var r;
                t.preventDefault(),
                  t.stopPropagation(),
                  e.removeParentScrollbarStyles();
                var i =
                  e.rootElement.getBoundingClientRect().bottom + e.win.scrollY;
                e.win.scrollTo({ top: i, behavior: "smooth" }),
                  Pc(
                    jc,
                    null == (r = e.config.settings) ? void 0 : r.tracking,
                    e.win,
                    e.logger
                  );
              };
              Fs(r, "click", i),
                Fs(r, "touchstart", i, !1, !1),
                t.appendChild(r);
            }
          }),
          (r.addScrollingBehavior = function (t) {
            var e = this,
              r = this.rootElement.querySelector(".kargo-ad-banner");
            (this.rootElement.style.height = this.stickyHeight + "px"),
              r && (r.style.height = this.stickyHeight + "px");
            var i = this.rootElement,
              n = !1,
              o = this.win.document.createElement("div");
            g(o, Yc),
              o.style.setProperty("--scrollbar-offset", "20px"),
              t.appendChild(o);
            var a = this.win.document.createElement("div");
            g(a, Gc),
              o.appendChild(a),
              (this.parentScrollbarStyles =
                this.win.document.createElement("style")),
              (this.parentScrollbarStyles.innerHTML = Bc),
              (this.stickyObserver = new IntersectionObserver(
                function (t) {
                  t.forEach(function (t) {
                    n = t.isIntersecting;
                  });
                },
                { threshold: [0, 1], rootMargin: "0px" }
              )),
              this.stickyObserver.observe(i);
            var s = function () {
              if (n) {
                e.updateScrollBar(t.querySelector("." + Gc));
                var r = Mc(i, e.win),
                  o = t.querySelector("." + qc);
                if (o) {
                  var a =
                    -r.top > (e.stickyHeight ? e.stickyHeight - e.vh : Uc) / 2;
                  (o.style.opacity = a ? "0" : "1"),
                    (o.style.pointerEvents = a ? "none" : "auto");
                }
                var s = r.top <= 0,
                  c = r.bottom >= e.vh,
                  l = r.bottom < e.vh && r.bottom > 0;
                e.handleScrollBarFlash(t, r.bottom),
                  e.handleScrollBarFlash(t, r.bottom),
                  s && c
                    ? (e.createSkipButton(t),
                      g(t, zc),
                      w(t, Kc),
                      w(t, Wc),
                      t.style.removeProperty("top"))
                    : l
                    ? (w(t, zc), w(t, Kc), g(t, Wc))
                    : (w(t, zc),
                      w(t, Wc),
                      g(t, Kc),
                      t.style.removeProperty("top"),
                      o &&
                        ((o.style.opacity = "0"),
                        (o.style.pointerEvents = "none")));
              }
            };
            this.scrollEventListener = s;
            var c = function () {
              s(),
                e.debouncedStyleCleanup ||
                  (e.debouncedStyleCleanup = Lc()(function () {
                    return e.removeScrollbarFailsafe();
                  }, 3e4)),
                e.debouncedStyleCleanup && e.debouncedStyleCleanup();
            };
            (this.scrollEventListener = c),
              this.win.document.addEventListener("scroll", c, { passive: !0 });
          }),
          (r.handleScrollBarFlash = function (t, e) {
            var r = t.querySelector("." + Yc);
            r &&
              (e >= 0
                ? r.style.setProperty("opacity", "1")
                : r.style.setProperty("opacity", "0"));
          }),
          (r.updateScrollBar = function (t) {
            var e,
              r = this.rootElement.offsetHeight - this.vh,
              i = -(
                (null == (e = Mc(this.rootElement, this.win))
                  ? void 0
                  : e.top) || 0
              ),
              n = r > 0 ? i / r : 0,
              o = this.vh * n - 40,
              a = Math.max(o, 20);
            n > 0 && n < 1
              ? (t.style.setProperty("height", a + "px"),
                t.style.setProperty("transform", "translateY(0px)"))
              : n >= 1 && t.style.setProperty("height", "calc(100dvh - 40px)"),
              n >= 1 ? g(t, "scrolled-to-bottom") : w(t, "scrolled-to-bottom"),
              this.addOrRemoveParentScrollbarOverride();
          }),
          (r.addOrRemoveParentScrollbarOverride = function () {
            var t = this.rootElement.getBoundingClientRect(),
              e = t.top + this.win.scrollY,
              r = t.bottom + this.win.scrollY,
              i =
                (this.win.scrollY / this.win.document.body.clientHeight) *
                  this.win.innerHeight +
                this.win.scrollY -
                2,
              n =
                i +
                (this.win.innerHeight / this.win.document.body.clientHeight) *
                  this.win.innerHeight,
              o =
                this.parentScrollbarStyles &&
                this.win.document.head.contains(this.parentScrollbarStyles);
            if (e <= i && r >= n) {
              if (o) return;
              this.parentScrollbarStyles &&
                this.win.document.head.appendChild(this.parentScrollbarStyles);
            } else
              o &&
                this.parentScrollbarStyles &&
                this.win.document.head.removeChild(this.parentScrollbarStyles);
          }),
          (r.removeParentScrollbarStyles = function () {
            this.parentScrollbarStyles &&
              this.win.document.head.contains(this.parentScrollbarStyles) &&
              this.parentScrollbarStyles &&
              this.win.document.head.removeChild(this.parentScrollbarStyles);
          }),
          (r.removeScrollbarFailsafe = function () {
            this.removeParentScrollbarStyles(),
              this.debouncedStyleCleanup &&
                (this.debouncedStyleCleanup.cancel(),
                (this.debouncedStyleCleanup = void 0));
          }),
          (r.onCreate = function () {
            var e,
              r = this.rootElement.querySelector(".kargo-ad-content");
            if (r) {
              if (
                (this.sticky && this.addScrollingBehavior(r),
                fa(r),
                null != (e = this.config.execution) &&
                  e.includes("desktop") &&
                  Hr(this.config, this.win))
              ) {
                var i = this.rootElement.parentNode.offsetWidth;
                va(r, i);
                var n = ma(i);
                this.logger.debug(
                  "Desktop Lighthouse: setting width to " + n + "px"
                );
              }
              t.prototype.onCreate.call(this);
            }
          }),
          (r.destroy = function () {
            this.sticky &&
              Bs(this.win, "message", this.boundStickyLighthouseHandler),
              this.stickyObserver && this.stickyObserver.disconnect(),
              this.scrollEventListener &&
                (Bs(this.win.document, "scroll", this.scrollEventListener),
                this.removeParentScrollbarStyles()),
              this.debouncedStyleCleanup &&
                (this.debouncedStyleCleanup.cancel(),
                (this.debouncedStyleCleanup = void 0)),
              t.prototype.destroy.call(this);
          }),
          e
        );
      })(Vs),
      Zc = function (t) {
        if (
          ((this.value = void 0),
          (this.label = void 0),
          "number" != typeof t || !Number.isFinite(t))
        )
          throw new Error("percentage must be a finite number");
        if (t < 0 || t > 100)
          throw new Error("percentage must be between 0 and 100");
        (this.value = Math.random() < t / 100),
          (this.label = this.value ? "on@" + t : "off@" + (100 - t));
      },
      $c = (function () {
        function t(t, e, r, i) {
          (this.name = void 0),
            (this.value = void 0),
            (this.label = void 0),
            (this.format = void 0);
          var n = new Zc(e);
          (this.name = t),
            (this.value = n.value),
            (this.label = n.label),
            (this.format = r),
            i
              ? ne
                  .getInstance()
                  .setImpressionExperiment(i, this.name, this.value, this.label)
              : ne
                  .getInstance()
                  .setPageExperiment(
                    this.name,
                    this.value,
                    this.label,
                    this.format
                  );
        }
        return (
          (t.cacheKey = function (t, e) {
            return t + "::" + (e || "");
          }),
          (t.register = function (e, r, i, n) {
            var o = t.cacheKey(e, i),
              a = t.instances.get(o);
            if (a) return a;
            var s = new t(e, r, i, n);
            return t.instances.set(o, s), s;
          }),
          (t.resetInstances = function () {
            t.instances.clear();
          }),
          t
        );
      })();
    ($c.instances = new Map()), $c.register("ban", 50, Br.B.MIDDLE_BANNER);
    var Xc = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        return (
          Ae(e, t),
          (e.prototype.getRenderConfig = function () {
            return t.prototype.getRenderConfig.call(this, {
              width: 300,
              minDimension: { width: 300, height: 250 },
              expansionCheck: !0,
            });
          }),
          e
        );
      })(Vs),
      Qc = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.display = function () {
            return (
              this.logger.debug(
                "NonVastOutstreamVideo loaded in its own space"
              ),
              t.prototype.display.call(this)
            );
          }),
          (r.onSizeChange = function (e, r) {
            var i = this.rootElement.querySelector(".kargo-ad-content"),
              n = this.rootElement.querySelector(".kargo-creative");
            n && (i.style.maxWidth = n.clientWidth + "px"),
              t.prototype.onSizeChange.call(this, e, r);
          }),
          e
        );
      })(Ps);
    function tl(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, i);
      }
      return r;
    }
    var el = "Kargo SafeFrame Slot",
      rl = "watch",
      il = function () {
        return "undefined" != typeof window ? window : null;
      },
      nl = function (t) {
        return "number" == typeof t && t > 0 ? t : 0;
      },
      ol = (function () {
        function t(t, e, r) {
          void 0 === r && (r = {}),
            (this.win = void 0),
            (this.logger = void 0),
            (this.pageWins = []),
            (this.adId = ""),
            (this.tags = void 0),
            (this.win = t),
            (this.logger = e),
            (this.tags = r);
        }
        var e = t.prototype;
        return (
          (e.canReachPage = function () {
            (this.adId = this.findAdId()),
              (this.pageWins = this.findPageWindows());
            var t = !!this.adId && this.pageWins.length > 0,
              e = t ? "can reach the page" : "no adId or ancestor window";
            return this.logger.debug("SafeFrame postMessage channel: " + e), t;
          }),
          (e.watchDimensions = function (t) {
            var e = this,
              r = function (r) {
                var i = (function (t) {
                  if (
                    (null == t ? void 0 : t.message) !== el ||
                    t.action !== rl
                  )
                    return null;
                  var e = {
                    width: nl(t.width),
                    height: nl(t.height),
                    frameWidth: nl(t.frameWidth),
                    frameHeight: nl(t.frameHeight),
                    pageWidth: nl(t.pageWidth),
                    pageHeight: nl(t.pageHeight),
                  };
                  return e.pageWidth &&
                    e.pageHeight &&
                    e.frameWidth &&
                    e.frameHeight
                    ? e
                    : null;
                })(ra(r, e.logger));
                i &&
                  (e.logger.debug(
                    "SafeFrame postMessage channel: dimensions",
                    i
                  ),
                  t(i));
              },
              i = this.pageWins.map(function (t) {
                var i = new MessageChannel();
                return (
                  (i.port1.onmessage = r),
                  e.postTo(t, { action: rl }, [i.port2]),
                  i.port1
                );
              });
            return function () {
              i.forEach(function (t) {
                (t.onmessage = null), t.close();
              });
            };
          }),
          (e.sendResize = function (t, e) {
            var r = this;
            this.logger.debug(
              "SafeFrame postMessage channel: resize " + t + "x" + e
            ),
              this.pageWins.forEach(function (i) {
                return r.postTo(i, { action: "resize", width: t, height: e });
              });
          }),
          (e.postTo = function (t, e, r) {
            t.postMessage(
              JSON.stringify(
                (function (t) {
                  for (var e = 1; e < arguments.length; e++) {
                    var r = null != arguments[e] ? arguments[e] : {};
                    e % 2
                      ? tl(Object(r), !0).forEach(function (e) {
                          (0, T.A)(t, e, r[e]);
                        })
                      : Object.getOwnPropertyDescriptors
                      ? Object.defineProperties(
                          t,
                          Object.getOwnPropertyDescriptors(r)
                        )
                      : tl(Object(r)).forEach(function (e) {
                          Object.defineProperty(
                            t,
                            e,
                            Object.getOwnPropertyDescriptor(r, e)
                          );
                        });
                  }
                  return t;
                })({ message: el, adId: this.adId, tags: this.tags }, e)
              ),
              "*",
              r
            );
          }),
          (e.findAdId = function () {
            var t = il(),
              e = (null == t ? void 0 : t.name) || "";
            if (
              !!e &&
              e.length < 64 &&
              "{" !== e[0] &&
              0 !== e.indexOf("google_ads")
            )
              return e;
            for (
              var r = [t, this.win].filter(Boolean), i = 0;
              i < r.length;
              i += 1
            ) {
              var n = (r[i].ucTagData || {}).adId;
              if (n && -1 === n.indexOf("%")) return n;
            }
            return "";
          }),
          (e.findPageWindows = function () {
            var t = il() || this.win,
              e = [];
            try {
              for (
                var r = t.parent;
                r && r !== t && e.indexOf(r) < 0 && (e.push(r), r !== r.parent);

              )
                r = r.parent;
              !e.length && t.top && e.push(t.top);
            } catch (t) {}
            return e;
          }),
          t
        );
      })(),
      al = { width: 0, height: 0 },
      sl = (function () {
        function t(t, e) {
          (this.channel = void 0),
            (this.frame = void 0),
            (this.page = null),
            (this.originalFrameBox = null),
            (this.appliedSize = null),
            (this.onGranted = void 0),
            (this.wantedSize = null),
            (this.stopListening = null),
            (this.destroyed = !1),
            (this.channel = t),
            (this.frame = e);
        }
        var e = t.prototype;
        return (
          (e.start = function (t, e) {
            var r = this;
            return new Promise(function (i) {
              var n = !1,
                o = t.setTimeout(function () {
                  n || ((n = !0), r.destroy(), i(!1));
                }, e);
              r.stopListening = r.channel.watchDimensions(function (e) {
                if (!r.destroyed) {
                  if (
                    ((r.page = e),
                    (r.originalFrameBox = r.originalFrameBox || {
                      width: e.frameWidth,
                      height: e.frameHeight,
                    }),
                    !n)
                  )
                    return (n = !0), t.clearTimeout(o), void i(!0);
                  r.refit();
                }
              });
            });
          }),
          (e.expandTo = function (t, e, r) {
            if (!this.destroyed && this.page) {
              this.onGranted = r;
              var i = {
                width: Math.min(t, this.page.pageWidth),
                height: Math.min(e, this.page.pageHeight),
              };
              this.channel.sendResize(i.width, i.height),
                this.frame.resize(i.width, i.height),
                (this.appliedSize = i),
                null == r || r(i);
            }
          }),
          (e.watch = function (t) {
            this.wantedSize = t;
          }),
          (e.viewport = function () {
            return this.page
              ? { width: this.page.pageWidth, height: this.page.pageHeight }
              : al;
          }),
          (e.availableWidth = function () {
            var t, e;
            return null != (t = null == (e = this.page) ? void 0 : e.pageWidth)
              ? t
              : 0;
          }),
          (e.slotWidth = function () {
            var t, e;
            return null != (t = null == (e = this.page) ? void 0 : e.width)
              ? t
              : 0;
          }),
          (e.isPristine = function () {
            return !this.appliedSize;
          }),
          (e.restoreSlot = function () {
            !this.destroyed &&
              this.originalFrameBox &&
              this.channel.sendResize(
                this.originalFrameBox.width,
                this.originalFrameBox.height
              );
          }),
          (e.destroy = function () {
            var t;
            (this.destroyed = !0),
              (this.wantedSize = null),
              null == (t = this.stopListening) || t.call(this),
              (this.stopListening = null);
          }),
          (e.refit = function () {
            var t,
              e = null == (t = this.wantedSize) ? void 0 : t.call(this);
            e &&
              !Xn(e, this.appliedSize) &&
              this.expandTo(e.width, e.height, this.onGranted);
          }),
          t
        );
      })();
    function cl(t) {
      var e = t.win,
        r = t.contentWin,
        i = t.reporter,
        n = t.geomWaitMs,
        o = t.logger,
        a = t.frame,
        s = t.tags,
        c = new lo(e, i, r, n, a);
      c.ensureRegistered();
      var l = new ol(e, o, s);
      if (!l.canReachPage())
        return (
          o.debug(
            "SafeFrame sizing through the SafeFrame API: no adId or ancestor window"
          ),
          {
            apiSizer: c,
            pageListenerSizer: Promise.resolve(null),
            pageListenerAsked: !1,
          }
        );
      var u = new sl(l, a);
      return {
        apiSizer: c,
        pageListenerSizer: u.start(e, 5e3).then(function (t) {
          return (
            o.debug(
              t
                ? "SafeFrame page listener answered, sizing through postMessage"
                : "no SafeFrame page listener within 5000ms, staying on the SafeFrame API"
            ),
            t ? u : null
          );
        }),
        pageListenerAsked: !0,
      };
    }
    var ll = function (t, e, r) {
        (this.value = void 0), (this.targeting = void 0);
        var i = [].concat(e, [t]);
        i.forEach(function (t) {
          if (!Number.isFinite(t.weight) || t.weight < 0)
            throw new Error("Invalid weight: " + t.weight);
        });
        var n = i.reduce(function (t, e) {
          return t + e.weight;
        }, 0);
        if (0 === n) throw new Error("Total weight must be greater than 0");
        if (100 !== n) {
          var o = "Experiment weights must equal 100, got " + n;
          return (
            r ? r.error(o) : console.error(o),
            (this.value = t.value),
            void (this.targeting = "")
          );
        }
        var a = 100 * Math.random(),
          s = 0,
          c =
            i.find(function (t) {
              return (s += t.weight), a < s;
            }) || t;
        this.value = c.value;
        var l = String(c.value).replace(/-/g, ""),
          u = c === t;
        this.targeting = u ? l + "-ctrl@" + c.weight : l + "@" + c.weight;
      },
      ul = (function () {
        function t(t, e, r, i, n, o) {
          (this.name = void 0),
            (this.value = void 0),
            (this.label = void 0),
            (this.format = void 0),
            (this.control = void 0),
            (this.choices = void 0),
            (this.name = t),
            (this.format = i),
            (this.control = e),
            (this.choices = r);
          var a = new ll(e, r, n);
          (this.value = a.value),
            (this.label = a.targeting),
            a.targeting &&
              (o
                ? ne
                    .getInstance()
                    .setImpressionExperiment(
                      o,
                      this.name,
                      this.value,
                      this.label
                    )
                : ne
                    .getInstance()
                    .setPageExperiment(
                      this.name,
                      this.value,
                      this.label,
                      this.format
                    ));
        }
        return (
          (t.cacheKey = function (t, e) {
            return t + "::" + (e || "");
          }),
          (t.register = function (e, r, i, n, o, a) {
            var s = t.cacheKey(e, n),
              c = t.instances.get(s);
            if (c)
              return (
                o &&
                  !c.matchesConfig(r, i) &&
                  o.error(
                    'WeightedChoiceExperiment.register: re-registering "' +
                      e +
                      '" (format=' +
                      (n || "") +
                      ") with different config; returning the cached instance"
                  ),
                a &&
                  c.label &&
                  ne
                    .getInstance()
                    .setImpressionExperiment(a, c.name, c.value, c.label),
                c
              );
            var l = new t(e, r, i, n, o, a);
            return t.instances.set(s, l), l;
          }),
          (t.resetInstances = function () {
            t.instances.clear();
          }),
          (t.prototype.matchesConfig = function (t, e) {
            return (
              this.control.value === t.value &&
              this.control.weight === t.weight &&
              this.choices.length === e.length &&
              this.choices.every(function (t, r) {
                return t.value === e[r].value && t.weight === e[r].weight;
              })
            );
          }),
          t
        );
      })();
    (ul.instances = new Map()),
      ul.register(
        "run",
        { value: "control", weight: 50 },
        [{ value: "variant", weight: 50 }],
        Br.B.RUNWAY
      );
    var hl = "sf-geom-wait",
      dl = { value: io, weight: 25 },
      pl = [
        { value: 4e3, weight: 25 },
        { value: 6e3, weight: 25 },
        { value: 8e3, weight: 25 },
      ],
      gl = (function (t) {
        function e() {
          for (var e, r = arguments.length, i = new Array(r), n = 0; n < r; n++)
            i[n] = arguments[n];
          return (
            ((e = t.call.apply(t, [this].concat(i)) || this).sfMraidHost =
              null),
            (e.sfApiSizer = null),
            (e.lastMraidCloseAt = 0),
            (e.geomWaitMs = void 0),
            e
          );
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.pickGeomWaitMs = function () {
            try {
              return ul.register(
                hl,
                dl,
                pl,
                Br.B.RUNWAY,
                this.logger,
                this.config.id
              ).value;
            } catch (t) {
              return (
                this.logger.error(
                  hl + ": registration failed, using default",
                  t
                ),
                io
              );
            }
          }),
          (r.detectContainerEnvironment = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                var r;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (e.next = 2),
                            t.prototype.detectContainerEnvironment.call(this)
                          );
                        case 2:
                          return (
                            "SafeFrame" === (r = e.sent) &&
                              ((this.config.settings.wrapper_override = !1),
                              (this.geomWaitMs = this.pickGeomWaitMs())),
                            e.abrupt("return", r)
                          );
                        case 5:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          (r.onCreate = function () {
            this.rootElement.parentNode.offsetWidth >= 650 &&
              ((this.platformMacros = this.platformMacros || {}),
              (this.platformMacros.device = "desktop")),
              t.prototype.onCreate.call(this);
          }),
          (r.getRenderConfig = function () {
            var e,
              r,
              i = { width: 0 };
            if (
              (ls(this.config) &&
                ((i.expansionCheck = !1),
                (i.customCss = "width: 100%;"),
                (i.height = 150),
                (i.minDimension = null)),
              (i = t.prototype.getRenderConfig.call(this, i)),
              (this.config.execution === Ln ||
                (null != (e = this.win.$sf) && e.ext)) &&
                (i.maxDimension = null),
              null != (r = this.win.$sf) && r.ext)
            ) {
              var n = lo.windowWidth(this.win),
                o = lo.getSlotHeight(this.win);
              n > 0 &&
                ((i.width = n),
                (i.height = o),
                (i.fullHeight = !0),
                (i.minDimension = { width: n, height: o }));
            }
            return i;
          }),
          (r.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                var r,
                  i,
                  n,
                  o,
                  a,
                  s,
                  c,
                  l,
                  u,
                  h = this;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (n = this.template).setTemplateVar(
                              "SIDEKICK_BRANDING",
                              "kargo-sidekick-branding kargo-breakaway-branding"
                            ),
                            n.setTemplateVar("RUNWAY", "runway-close-position"),
                            null != (r = this.win.$sf) &&
                              r.ext &&
                              (this.safeFrameReporter =
                                this.createSafeFrameReporter()),
                            null == (i = this.safeFrameReporter) ||
                              i.reportMetric("runway-display"),
                            "celtra" !== (o = Qn(this.config.content)) &&
                              this.reportUnsupportedSafeFrameCreative(o),
                            uo.isEligible(this.win) &&
                              ((s =
                                (null == (a = this.config.positionElement) ||
                                null == (a = a.ownerDocument)
                                  ? void 0
                                  : a.defaultView) || this.win),
                              (c = new Jn(this.win, s, this.safeFrameReporter)),
                              (l = cl({
                                win: this.win,
                                contentWin: s,
                                reporter: this.safeFrameReporter,
                                geomWaitMs: this.geomWaitMs,
                                logger: this.logger,
                                frame: c,
                                tags: Zn(this.win, this.config),
                              })),
                              (this.sfMraidHost = new uo(
                                this.win,
                                s,
                                l.apiSizer,
                                c,
                                l.pageListenerSizer,
                                function (t) {
                                  var e,
                                    r =
                                      "api" === t && !l.pageListenerAsked
                                        ? "api-not-asked"
                                        : t;
                                  null == (e = h.safeFrameReporter) ||
                                    e.reportMetric("sizer-" + r);
                                },
                                this.safeFrameReporter,
                                o
                              )),
                              this.sfMraidHost.install()),
                            (u = t.prototype.display.call(this)),
                            this.sfMraidHost ||
                              ((this.sfApiSizer = new lo(
                                this.win,
                                this.safeFrameReporter,
                                null,
                                this.geomWaitMs
                              )),
                              this.sfApiSizer.expandWhenReady()),
                            e.abrupt("return", u)
                          );
                        case 12:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          (r.hoverClose = function (e) {
            var r;
            if (
              "expanded" ===
              (null == (r = this.sfMraidHost) ? void 0 : r.getState())
            )
              return (
                e.preventDefault(),
                (this.lastMraidCloseAt = Date.now()),
                void this.sfMraidHost.close()
              );
            Date.now() - this.lastMraidCloseAt < 800
              ? e.preventDefault()
              : t.prototype.hoverClose.call(this, e);
          }),
          (r.collapseSafeFrameOnClose = function () {}),
          (r.restoreSlotSize = function () {
            var t,
              e,
              r =
                null !=
                (t = null == (e = this.sfMraidHost) ? void 0 : e.getSizer())
                  ? t
                  : this.sfApiSizer;
            r && !r.isPristine() && r.restoreSlot();
          }),
          (r.destroy = function () {
            var e, r;
            this.restoreSlotSize(),
              null == (e = this.sfMraidHost) || e.destroy(),
              null == (r = this.sfApiSizer) || r.destroy(),
              t.prototype.destroy.call(this);
          }),
          e
        );
      })($s),
      fl = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        return Ae(e, t), e;
      })(gl),
      vl = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.display = function () {
            return (
              this.logger.debug("OutstreamVideo loaded in its own space"),
              t.prototype.display.call(this)
            );
          }),
          (r.validateConfig = function (e) {
            var r = e || {};
            return (
              (r.settings = r.settings || {}),
              "open" === (r.source || {}).auctionType &&
                "OutstreamVideo" === r.format &&
                (r.settings.branding = "advertisement"),
              t.prototype.validateConfig.call(this, r)
            );
          }),
          (r.onDisplay = function () {
            if (!this.isVpaid) {
              var e = this.rootElement.querySelector(".kargo-loader"),
                r = (0, Ur.xl)(this.win)
                  ? 300
                  : Math.min(this.rootElement.clientWidth, 440);
              e.style.width = r + "px";
              var i = (9 * r) / 16;
              e.style.height = i + "px";
            }
            t.prototype.onDisplay.call(this);
          }),
          (r.onLoad = function () {
            var e = this;
            if (this.container && null !== this.container.getType()) {
              var r = Lr.$4[this.config.format].size;
              this.vastDimensions &&
                this.vastDimensions.width &&
                this.vastDimensions.height &&
                (r.h =
                  (this.vastDimensions.height * r.w) /
                  this.vastDimensions.width);
              var i = this.container.getType();
              this.logger.debug("Setting Container Size: " + r.w + "x" + r.h),
                this.container.setContainerSize(r.w, r.h).catch(function (t) {
                  var r = "Failed to set " + i + " Container Size";
                  t && (r += ": " + t), e.logger.debug(r);
                });
            }
            t.prototype.onLoad.call(this);
          }),
          e
        );
      })(Ps);
    function ml(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, i);
      }
      return r;
    }
    function kl(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2
          ? ml(Object(r), !0).forEach(function (e) {
              (0, T.A)(t, e, r[e]);
            })
          : Object.getOwnPropertyDescriptors
          ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
          : ml(Object(r)).forEach(function (e) {
              Object.defineProperty(
                t,
                e,
                Object.getOwnPropertyDescriptor(r, e)
              );
            });
      }
      return t;
    }
    var bl = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.getRenderConfig = function () {
            var e = Hr(this.config, this.win)
                ? this.getSidekickSize(this.win.innerHeight)
                : 140,
              r = {
                width: e,
                height: e,
                minDimension: { width: e, height: e },
              },
              i = this.config.settings.tracking.interactive;
            return (
              i &&
                (r.macros = r.macros
                  ? kl(kl({}, r.macros), {}, { interactive: i })
                  : { interactive: i }),
              (ls(this.config) || hs(this.config)) && Un(r, this.config),
              t.prototype.getRenderConfig.call(this, r)
            );
          }),
          (r.getSidekickSize = function (t) {
            var e = Math.ceil(0.25 * t);
            return (e = Math.min(Math.max(e, 200), 320));
          }),
          (r.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                var r, n;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (r = this.template),
                            (n = Hr(this.config, this.win)
                              ? this.getSidekickSize(this.win.innerHeight)
                              : 140),
                            (n = (0, i.gh)(this.win) ? 100 : n),
                            r.setTemplateVar(
                              "SIDEKICK_BRANDING",
                              "kargo-sidekick-branding"
                            ),
                            r.setTemplateVar("SIDEKICK_WIDTH", "" + n),
                            r.setTemplateVar("SIDEKICK_HEIGHT", "" + n),
                            (e.next = 8),
                            t.prototype.display.call(this)
                          );
                        case 8:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          e
        );
      })($s),
      yl = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.validateConfig = function (e) {
            var r = t.prototype.validateConfig.call(this, e);
            return (
              (0, Ur.xl)(this.win) && (r.settings.has_responsive_width = !0), r
            );
          }),
          (r.getRenderConfig = function () {
            var e = t.prototype.getRenderConfig.call(this);
            return (
              (e.width = 320),
              (e.height = 180),
              (0, Ur.xl)(this.win) && ((e.width = 500), (e.height = 281)),
              e
            );
          }),
          (r.destroy = function () {
            if (this.socialCanvasCreatives) {
              var t = this.socialCanvasCreatives;
              if (t.companion && t.companion.renderDiv) {
                var e = t.companion.renderDiv,
                  r = this.win.document.querySelector("#" + e),
                  i =
                    null == r
                      ? void 0
                      : r.querySelector(".kargo-companion-creative");
                i && (this.logger.debug("Destroying Companion"), _(i));
              }
            }
          }),
          e
        );
      })(Vs),
      wl = __webpack_require__(9246),
      _l = __webpack_require__(9783),
      Al = "new-template",
      Cl = "new-template-after-click",
      El = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.onLoad = function () {
            var e = this.rootElement.querySelector(Gr).contentWindow,
              r = (0, d.xF)(e, "Kargo.PlatformMacros");
            r &&
              ((r.destroySwipeUp = this.closeSwipeUp.bind(this)),
              (r.swipeUp = this.expandSwipe.bind(this)),
              (r.clickUp = this.expandClick.bind(this))),
              t.prototype.onLoad.call(this);
          }),
          (r.expandClick = function () {
            var t = this.rootElement.querySelector("." + Al);
            t && g(t, Cl);
            this.onClick({}, { format: this.config.format, event: "click" });
          }),
          (r.expandSwipe = function () {
            var t = this.rootElement.querySelector("." + Al);
            t && g(t, Cl);
            this.onClick({}, { format: this.config.format, event: "swipe" });
          }),
          (r.closeSwipeUp = function () {
            var t = new Event("kargo-hover-close");
            if (
              (this.win.dispatchEvent(t), this.config.settings.tracking.dismiss)
            )
              for (
                var e = 0;
                e < this.config.settings.tracking.dismiss.length;
                e++
              )
                (0, c.Ho)(this.win, this.config.settings.tracking.dismiss[e]);
            this.onClose(), this.destroy();
          }),
          (r.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                var r;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            this.template &&
                              ((this.template.html = wl),
                              (this.template.css = _l)),
                            (e.next = 3),
                            t.prototype.display.call(this)
                          );
                        case 3:
                          (r =
                            this.rootElement.querySelector(
                              ".kargo-ad-content"
                            )),
                            "v3" === this.config.execution && g(r, Al);
                        case 5:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          e
        );
      })($s),
      xl = Vs,
      Sl = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        return (
          Ae(e, t),
          (e.prototype.getRenderConfig = function (e) {
            void 0 === e && (e = {});
            var r = (0, d.h1)(
              {
                width: 970,
                height: 250,
                minDimension: { width: 970, height: 250 },
              },
              e
            );
            return t.prototype.getRenderConfig.call(this, r);
          }),
          e
        );
      })(lc),
      Il = (function (t) {
        function e() {
          for (var e, r = arguments.length, i = new Array(r), n = 0; n < r; n++)
            i[n] = arguments[n];
          return (
            ((e = t.call.apply(t, [this].concat(i)) || this).vast = null), e
          );
        }
        return (
          Ae(e, t),
          (e.prototype.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                var r, i, n;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (!this.config.settings.vast_xml) {
                            e.next = 7;
                            break;
                          }
                          if (this.fabrikExtension) {
                            e.next = 6;
                            break;
                          }
                          if (!(r = this.setFabrikExtension())) {
                            e.next = 6;
                            break;
                          }
                          return this.destroyWithError(r), e.abrupt("return");
                        case 6:
                          this.fabrikExtension &&
                            this.fabrikExtension.templateVars &&
                            this.fabrikExtension.templateVars.ASPECT_RATIO &&
                            ((i =
                              this.fabrikExtension.templateVars.ASPECT_RATIO),
                            (this.vast = new ko(this.win)),
                            (n = this.vast.filterMediaFiles(
                              this.config.settings.vast_xml,
                              i
                            )),
                            (this.config.settings.vast_xml = n));
                        case 7:
                          return (e.next = 9), t.prototype.display.call(this);
                        case 9:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          e
        );
      })(lc),
      Ol = __webpack_require__(1712),
      Rl = __webpack_require__(4590),
      Dl =
        "https://storage.cloud.kargo.com/ad/campaign/rm/SurabhiM/adtag/uptick/placeholder.jpg",
      Tl = "uptick-ad-content",
      Vl = ["allow_uptick", "demo", "krg_allow_uptick"],
      Ll = (function (t) {
        function e() {
          for (var e, r = arguments.length, i = new Array(r), n = 0; n < r; n++)
            i[n] = arguments[n];
          return (
            ((e = t.call.apply(t, [this].concat(i)) || this).shouldAnimate =
              !0),
            (e.kargoAdContent = void 0),
            (e.destroyAd = !1),
            (e.placeholderImage = Dl),
            (e.uptickCookie = "krg-uptickDisplayed=true"),
            (e.bannerHeight = 0),
            (e.bannerWidth = 0),
            (e.trackerTimeoutId = null),
            (e.boundUptickHandler = e.sendUptickMessage.bind(e)),
            e
          );
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.onCreate = function () {
            var e = this;
            this.kargoAdContent =
              this.rootElement.querySelector(".kargo-ad-content");
            var r = this.kargoAdContent.querySelector(
              ".kargo-uptick-close-" + this.config.localId
            );
            r &&
              (r.addEventListener("click", this.handleClose.bind(this)),
              r.addEventListener("touchstart", this.handleClose.bind(this))),
              (this.isDemoModeActive() ||
                (!Hr(this.config, this.win) && !this.checkForUptickCookie())) &&
                qo.observeElement(this.rootElement, 0, !1, function (t) {
                  t.boundingClientRect.bottom <= 0 &&
                    e.shouldAnimate &&
                    !e.destroyAd &&
                    e.handleUpTick();
                }),
              t.prototype.onCreate.call(this);
          }),
          (r.setPlaceholderImage = function () {
            var t = this.rootElement.querySelector("iframe"),
              e = this.rootElement.querySelector(".celtra-ad-inline-host"),
              r = null;
            if (
              (e && (r = e.querySelector("iframe")), !t || !t.contentDocument)
            )
              return (
                this.logger.warn(
                  "Iframe not found or inaccessible in rootElement."
                ),
                void (this.placeholderImage = Dl)
              );
            if (r && r.contentDocument) {
              var i = r.contentDocument.querySelector(
                  ".krg_uptick_placeholder"
                ),
                n = null == i ? void 0 : i.querySelector("img"),
                o = n ? n.src : Dl;
              this.placeholderImage = o;
            } else {
              var a = t.contentDocument.querySelector(".i-c-0-placeholder div"),
                s = (a ? window.getComputedStyle(a).backgroundImage : Dl).match(
                  /^url\(["']?(.*?)["']?\)$/
                );
              this.placeholderImage = (null == s ? void 0 : s[1]) || Dl;
            }
          }),
          (r.onVisible = function () {
            var e;
            t.prototype.onVisible.call(this),
              null == (e = this.overlapMonitor) || e.stop();
          }),
          (r.handleUpTick = function () {
            (this.shouldAnimate = !1),
              (this.bannerHeight = this.kargoAdContent.clientHeight),
              (this.bannerWidth = this.kargoAdContent.clientWidth),
              this.setPlaceholderImage(),
              this.win.postMessage(
                {
                  message: "uptick",
                  adSlot: this.config.slot,
                  localId: this.config.localId,
                },
                "*"
              ),
              this.win.addEventListener("message", this.boundUptickHandler);
          }),
          (r.sendUptickMessage = function (t) {
            if ("string" == typeof t.data) {
              var e = t.data.split("|")[0],
                r = t.data.match(/timeout=(\d+)/),
                i = r ? parseInt(r[1], 10) : 5e3;
              "uptickReceived" === e &&
                (this.activateUpTick(i),
                this.win.removeEventListener(
                  "message",
                  this.boundUptickHandler
                ));
            }
          }),
          (r.adjustTopPaddingOnOverlap = function () {
            this.overlapMonitor &&
              ((this.overlapMonitor.overlapPixelHandler = function (t, e) {
                var r;
                if (
                  "0px" === (null == (r = t.element.KrgStyle) ? void 0 : r.top)
                ) {
                  var i = t.element.offsetHeight;
                  e.style.paddingTop = Math.min(i, 220) + "px";
                }
              }),
              this.overlapMonitor.start(5),
              this.overlapMonitor.setMinCount(0),
              this.overlapMonitor.timerHandler());
          }),
          (r.activateUpTick = function (t) {
            var e,
              r = this;
            w(this.kargoAdContent, "no-padding");
            var i = this.rootElement.querySelector(".kargo-branding-kargo");
            i && (w(i, "show"), g(i, "hide")),
              this.addPlaceholderVenti(),
              this.setFixedPosition(),
              setTimeout(function () {
                r.showCloseButton();
              }, 50),
              this.setUptickCookie(),
              null != (e = this.config.settings) &&
                e.top_padding &&
                (w(this.kargoAdContent, "no-padding"),
                (this.kargoAdContent.style.paddingTop =
                  this.config.settings.top_padding + "px"));
            var n = this.rootElement.querySelector("." + Tl);
            this.clearTimeout(),
              (this.trackerTimeoutId = setTimeout(function () {
                var t;
                n &&
                  Pc(
                    "uptick_sticky_view",
                    null == (t = r.config.settings) ? void 0 : t.tracking,
                    r.win,
                    r.logger
                  );
              }, 1e3)),
              this.overlapMonitor && (this.overlapMonitor.container = n),
              this.adjustTopPaddingOnOverlap(),
              setTimeout(function () {
                r.resetUpTick();
              }, t);
          }),
          (r.setFixedPosition = function () {
            g(this.kargoAdContent, Tl),
              w(this.kargoAdContent, "kargo-banner-width");
          }),
          (r.clearTimeout = function () {
            this.trackerTimeoutId &&
              (clearTimeout(this.trackerTimeoutId),
              (this.trackerTimeoutId = null));
          }),
          (r.resetUpTick = function () {
            var t;
            this.clearTimeout(),
              this.hideCloseButton(),
              w(this.kargoAdContent, Tl),
              g(this.kargoAdContent, "kargo-banner-width"),
              g(this.kargoAdContent, "no-padding");
            var e = this.rootElement.querySelector(".kargo-branding-kargo");
            e && (w(e, "hide"), g(e, "show")),
              this.win.postMessage(
                {
                  message: "uptickReset",
                  adSlot: this.config.slot,
                  localId: this.config.localId,
                },
                "*"
              ),
              (this.shouldAnimate = this.isDemoModeActive()),
              null == (t = this.overlapMonitor) || t.stop(),
              this.removePlaceholderVenti();
          }),
          (r.isDemoModeActive = function () {
            if (Ri(this.win)) return !0;
            var t = new URLSearchParams(window.location.search),
              e = Object.fromEntries(t.entries());
            return Object.keys(e).some(function (t) {
              return Vl.includes(t) && "true" === e[t];
            });
          }),
          (r.showCloseButton = function () {
            var t = this.kargoAdContent.querySelector(
              ".kargo-uptick-close-" + this.config.localId
            );
            null != t &&
              t.classList.contains("hide") &&
              (w(t, "hide"), g(t, "show"));
          }),
          (r.handleClose = function (t) {
            var e;
            t.preventDefault(),
              this.win.dispatchEvent(
                new Event("kargo-uptick-close-" + this.config.localId)
              ),
              this.logger.debug("Uptick closed"),
              (this.destroyAd = !0),
              this.resetUpTick(),
              Pc(
                "uptick_sticky_close",
                null == (e = this.config.settings) ? void 0 : e.tracking,
                this.win,
                this.logger
              );
          }),
          (r.hideCloseButton = function () {
            var t = this.win.document.querySelector(
              ".kargo-uptick-close-" + this.config.localId
            );
            t && (w(t, "show"), g(t, "hide"));
          }),
          (r.addPlaceholderVenti = function () {
            this.removePlaceholderVenti(),
              Object.assign(this.rootElement.style, {
                height: this.bannerHeight + "px",
                width: this.bannerWidth + "px",
                maxHeight: this.bannerHeight + "px",
                minHeight: this.bannerHeight + "px",
                maxWidth: this.bannerWidth + "px",
                minWidth: this.bannerWidth + "px",
              });
            var t = this.win.document.createElement("div");
            t.classList.add("tempBanner"),
              t.classList.add("tempBanner-" + this.config.localId),
              Object.assign(t.style, {
                backgroundImage: "url(" + this.placeholderImage + ")",
                height: this.bannerHeight + "px",
                width: this.bannerWidth + "px",
              }),
              this.rootElement.appendChild(t);
          }),
          (r.removePlaceholderVenti = function () {
            this.win.document
              .querySelectorAll(".tempBanner-" + this.config.localId)
              .forEach(function (t) {
                return t.remove();
              });
          }),
          (r.setUptickCookie = function () {
            var t = new Date();
            t.setTime(t.getTime() + 36e5),
              (this.win.document.cookie =
                this.uptickCookie +
                "; expires=" +
                t.toUTCString() +
                "; path=/");
          }),
          (r.checkForUptickCookie = function () {
            return this.win.document.cookie.includes(this.uptickCookie);
          }),
          (r.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                var r, i, n;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            ((i = this.template).html = Ol),
                            (i.css += Rl),
                            i.setTemplateVar(
                              "CLOSEBUTTON",
                              "kargo-uptick-close-" + this.config.localId
                            ),
                            (this.useOverlapDetection = !0),
                            (n = this.getGlobalConfig()) &&
                              n.setEnableOverlapDetection &&
                              n.setEnableOverlapDetection(!0),
                            (e.next = 9),
                            t.prototype.display.call(this)
                          );
                        case 9:
                          null == (r = this.overlapMonitor) || r.stop();
                        case 10:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          (r.destroy = function () {
            this.win.removeEventListener("message", this.boundUptickHandler),
              t.prototype.destroy.call(this);
          }),
          e
        );
      })(Vs),
      Pl = (function (t) {
        function e() {
          for (var e, r = arguments.length, i = new Array(r), n = 0; n < r; n++)
            i[n] = arguments[n];
          return (
            ((e =
              t.call.apply(t, [this].concat(i)) ||
              this).adBannerOriginalHeight = null),
            (e.snippetType = null),
            (e.slotSizer = null),
            (e.slotFrame = null),
            (e.slotWidth = 0),
            (e.hasReportedFlexSize = !1),
            (e.celtraSizesTimer = null),
            e
          );
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.detectContainerEnvironment = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                var r, i;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (e.next = 2),
                            t.prototype.detectContainerEnvironment.call(this)
                          );
                        case 2:
                          if ("SafeFrame" !== (r = e.sent)) {
                            e.next = 13;
                            break;
                          }
                          if (
                            ((this.safeFrameReporter =
                              this.createSafeFrameReporter()),
                            this.safeFrameReporter.reportMetric(
                              "venti-display"
                            ),
                            "celtra" !== (i = Qn(this.config.content)))
                          ) {
                            e.next = 12;
                            break;
                          }
                          return (e.next = 10), this.fitFrameToSlot();
                        case 10:
                          e.next = 13;
                          break;
                        case 12:
                          this.reportUnsupportedSafeFrameCreative(i);
                        case 13:
                          return e.abrupt("return", r);
                        case 14:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          (r.fitFrameToSlot = (function () {
            var t = (0, V.A)(
              P().mark(function t() {
                var e, r, i, n, o, a, s, c, l;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          if (
                            (i = new ol(
                              this.win,
                              this.logger,
                              Zn(this.win, this.config)
                            )).canReachPage()
                          ) {
                            t.next = 4;
                            break;
                          }
                          return (
                            null == (n = this.safeFrameReporter) ||
                              n.reportMetric("venti-sizer-not-asked"),
                            t.abrupt("return")
                          );
                        case 4:
                          return (
                            (o =
                              (null == (e = this.config.positionElement) ||
                              null == (e = e.ownerDocument)
                                ? void 0
                                : e.defaultView) || this.win),
                            (a = new Jn(this.win, o, this.safeFrameReporter)),
                            (s = new sl(i, a)),
                            (t.next = 9),
                            s.start(this.win, 1e3)
                          );
                        case 9:
                          if (t.sent && s.slotWidth()) {
                            t.next = 15;
                            break;
                          }
                          return (
                            s.destroy(),
                            null == (c = this.safeFrameReporter) ||
                              c.reportMetric("venti-sizer-no-answer"),
                            this.logger.debug(
                              "Venti SafeFrame: no slot width from the page, rendering at frame size"
                            ),
                            t.abrupt("return")
                          );
                        case 15:
                          null == (r = this.safeFrameReporter) ||
                            r.reportMetric("venti-sizer-postmessage"),
                            this.detectSidebarSlot(),
                            (this.slotSizer = s),
                            (this.slotFrame = a),
                            (this.slotWidth = this.sidebarSlot
                              ? Rn
                              : s.slotWidth()),
                            (l = this.bootHeight()),
                            this.logger.debug(
                              "Venti SafeFrame: booting in " +
                                this.slotWidth +
                                "x" +
                                l
                            ),
                            s.expandTo(this.slotWidth, l);
                        case 23:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this
                );
              })
            );
            return function () {
              return t.apply(this, arguments);
            };
          })()),
          (r.bootHeight = function () {
            if (this.slotWidth < 650) return Vn;
            var t = "kap" === jn(this.config.content) ? Dn : 800;
            return Math.min(Math.round(t / 2.976), Vn);
          }),
          (r.onCreate = function () {
            var e = this.config.execution,
              r = this.rootElement.querySelector(".kargo-ad-content");
            e &&
              Nn.includes(e) &&
              (this.detectSidebarSlot(), this.handleFlexWidth(r)),
              ga(this.config) && fa(r),
              t.prototype.onCreate.call(this);
          }),
          (r.layoutWidth = function () {
            return this.slotWidth || this.rootElement.parentNode.offsetWidth;
          }),
          (r.applySlotWidth = function (t) {
            this.slotWidth &&
              ((t.style.width = this.slotWidth + "px"),
              (t.style.maxWidth = this.slotWidth + "px"));
          }),
          (r.handleFlexWidth = function (t) {
            var e = this.layoutWidth();
            if (
              (g(t, Pn),
              (this.snippetType = jn(this.config.content)),
              this.sidebarSlot)
            )
              this.applySidebarBreakpoint(t);
            else if (e < 320) this.applySmallBreakpoint(t);
            else {
              if (this.config.execution === Mn) {
                va(t, e);
                var r = ma(e);
                this.logger.debug(
                  "Desktop Lighthouse: setting width to " + r + "px"
                );
              } else
                e < 650
                  ? this.applyMediumBreakpoint(t, e)
                  : this.applyLargeBreakpoint(t, e);
              this.applySlotWidth(t);
            }
          }),
          (r.applySidebarBreakpoint = function (t) {
            this.applySmallBreakpoint(t),
              (t.style.maxWidth = Rn + "px"),
              this.logger.debug(
                "Venti " +
                  this.config.execution +
                  ": sidebar slot, width locked to 300px"
              );
          }),
          (r.applySmallBreakpoint = function (t) {
            (t.style.width = Rn + "px"),
              (t.style.height = Vn + "px"),
              (this.platformMacros = this.platformMacros || {}),
              (this.platformMacros.device = "mobile");
          }),
          (r.applyMediumBreakpoint = function (t, e) {
            if (
              ((t.style.width = e + "px"),
              (t.style.maxWidth = "440px"),
              (t.style.maxHeight = Vn + "px"),
              "open" === this.config.source.auctionType)
            )
              t.style.minHeight = Vn + "px";
            else {
              var r = Math.min(Math.round(e / (440 / 460)), Vn);
              t.style.minHeight = r + "px";
            }
            var i = Math.min(Math.max(e, Rn), 440);
            this.reportRenderedWidth(i),
              (this.platformMacros = this.platformMacros || {}),
              (this.platformMacros.device = "mobile");
          }),
          (r.applyLargeBreakpoint = function (t, e) {
            var r = "kap" === this.snippetType ? Dn : 800,
              i = Math.min(Math.round(r / 2.976), Vn);
            (t.style.width = e + "px"),
              (t.style.maxWidth = r + "px"),
              (t.style.maxHeight = i + "px");
            var n = Math.min(Math.max(e, Rn), r);
            this.reportRenderedWidth(n),
              (this.platformMacros = this.platformMacros || {}),
              (this.platformMacros.device = "desktop");
          }),
          (r.reportRenderedWidth = function (t) {
            if (
              (this.logger.debug(
                "Venti " +
                  this.config.execution +
                  ": setting width to " +
                  t +
                  "px"
              ),
              !this.hasReportedFlexSize)
            ) {
              this.hasReportedFlexSize = !0;
              var e = Math.random() < 0.2;
              (this.config.branchTestString || R.isDebugMode(this.win) || e) &&
                we.reportAdMetric(
                  {
                    type: "venti-flex-size",
                    version: "10.9.0-kat-7484-test",
                    value: t,
                  },
                  this.config,
                  this.logger
                );
            }
          }),
          (r.onSizeChange = function (e, r) {
            var i = this.layoutWidth(),
              n = this.rootElement.querySelector(".kargo-ad-content"),
              o = this.config.execution;
            if (o && Nn.includes(o)) {
              if (this.sidebarSlot || i < 320)
                return void t.prototype.onSizeChange.call(this, e, r);
              var a;
              if (i < 650) (n.style.maxWidth = "440px"), (a = Vn);
              else {
                var s = "kap" === this.snippetType ? Dn : 800;
                (n.style.maxWidth = s + "px"),
                  (a = Math.min(Math.round(0.33602150537634407 * s), Vn));
              }
              this.applySlotWidth(n);
              var c = this.rootElement.querySelector(".kargo-ad-banner");
              c &&
                (null === this.adBannerOriginalHeight &&
                  (this.adBannerOriginalHeight = c.style.height),
                r > a
                  ? (c.style.height = r + "px")
                  : this.adBannerOriginalHeight
                  ? (c.style.height = this.adBannerOriginalHeight + "px")
                  : c.style.removeProperty("height"));
            }
            t.prototype.onSizeChange.call(this, e, r);
          }),
          (r.getRenderConfig = function () {
            var e = t.prototype.getRenderConfig.call(this),
              r = this.config.settings.creative_origin;
            if (!r || !["composer", "creative-hub"].includes(r)) {
              if ("open" === this.config.source.auctionType)
                e.minDimension.height = Vn;
              else {
                var i = this.win.innerWidth,
                  n = Math.min(Math.round(i / (440 / 460)), Vn);
                e.minDimension.height = n;
              }
              Dr(this.win) || (e.maxDimension.height = Vn);
            }
            return (
              (this.config.execution !== Ln && this.config.execution !== Pn) ||
                ((e.minDimension.width = Rn),
                (e.minDimension.height = Tn),
                this.sidebarSlot || (e.maxDimension.width = Dn)),
              (e.height = 460),
              (e.expansionCheck = !0),
              this.slotWidth && this.applySafeFrameBootBox(e),
              e
            );
          }),
          (r.applySafeFrameBootBox = function (t) {
            var e = this.slotWidth,
              r = this.bootHeight();
            (t.width = e),
              (t.height = r),
              (t.fullHeight = !0),
              (t.minDimension = { width: e, height: r }),
              (t.maxDimension = null);
          }),
          (r.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                var r;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            (r = t.prototype.display.call(this)),
                            this.slotSizer && this.sizeFrameToCeltra(),
                            e.abrupt("return", r)
                          );
                        case 3:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          (r.sizeFrameToCeltra = function () {
            var t,
              e = this;
            null == (t = this.slotSizer) ||
              t.watch(function () {
                return e.refitToSlot();
              });
            var r = Date.now(),
              i = function () {
                var t,
                  n,
                  o,
                  a = e.celtraTarget();
                if (a)
                  return (
                    null == (t = e.slotSizer) || t.expandTo(a.width, a.height),
                    void (
                      null == (n = e.safeFrameReporter) || n.reportTimeToSize()
                    )
                  );
                Date.now() - r > 1e4
                  ? null == (o = e.safeFrameReporter) ||
                    o.reportErrorOnce(
                      it,
                      "Celtra sizes still unreadable after 10000ms"
                    )
                  : (e.celtraSizesTimer = e.win.setTimeout(i, 100));
              };
            i();
          }),
          (r.celtraTarget = function () {
            var t, e;
            return null !=
              (t =
                null == (e = this.slotFrame)
                  ? void 0
                  : e.celtraTargetAt(this.slotWidth))
              ? t
              : null;
          }),
          (r.refitToSlot = function () {
            var t,
              e,
              r =
                null !=
                (t = null == (e = this.slotSizer) ? void 0 : e.slotWidth())
                  ? t
                  : 0;
            if (r && r !== this.slotWidth) {
              this.slotWidth = r;
              var i = this.rootElement.querySelector(".kargo-ad-content");
              i && this.handleFlexWidth(i);
            }
            return this.celtraTarget();
          }),
          (r.destroy = function () {
            var e;
            null !== this.celtraSizesTimer &&
              this.win.clearTimeout(this.celtraSizesTimer),
              null == (e = this.slotSizer) || e.destroy(),
              t.prototype.destroy.call(this);
          }),
          e
        );
      })(Vs),
      Ml = __webpack_require__(3930),
      Nl = (function (t) {
        function e(e, r, i) {
          return t.call(this, e, r, i) || this;
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.getRenderConfig = function () {
            return t.prototype.getRenderConfig.call(this, {
              width: 0,
              height: 0,
              minDimension: null,
            });
          }),
          (r.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                var r,
                  i,
                  n,
                  o,
                  a = this;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (
                            (this.logger.debug(
                              "Video Anchor loaded in its own space"
                            ),
                            this.template &&
                              ((this.template.html = Ml),
                              (this.template.css = js)),
                            (r = this.template),
                            r.setTemplateVar("SIDEKICK_WIDTH", "80"),
                            r.setTemplateVar(
                              "FORMAT",
                              "kargo-hover--videoanchor"
                            ),
                            r.setTemplateVar(
                              "HORIZONTAL_ALIGN",
                              "kargo-hover--align-left"
                            ),
                            (i = function (t, e) {
                              a.video && a.video.fireErrorTrackers(400),
                                a.reportError(t, e ? { code: e } : {}),
                                a.destroy();
                            }),
                            (0, Ur.Jp)(this.win))
                          ) {
                            e.next = 11;
                            break;
                          }
                          return (
                            i("Autoplay not supported", At), e.abrupt("return")
                          );
                        case 11:
                          return (
                            (e.prev = 11),
                            (e.next = 14),
                            this.getVideoCreative()
                          );
                        case 14:
                          return (
                            (n = this.video),
                            (o = "Video Creative - "),
                            this.logger.debug("" + o + n.creativeType),
                            this.logger.debug(o + "Snippet Config", n.config),
                            this.logger.debug(
                              o + "Vast Config",
                              n.vast ? n.vast.parsedVastResult : null
                            ),
                            this.logger.debug(
                              o + "Anchor Config",
                              n.anchorConfig
                            ),
                            (e.next = 22),
                            t.prototype.display.call(this)
                          );
                        case 22:
                          e.next = 28;
                          break;
                        case 24:
                          (e.prev = 24),
                            (e.t0 = e.catch(11)),
                            this.logger.error(e.t0),
                            i(e.t0);
                        case 28:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this,
                  [[11, 24]]
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          (r.closeVideoAnchor = function () {
            var t = new Event("kargo-hover-close");
            if (
              (this.win.dispatchEvent(t), this.config.settings.tracking.dismiss)
            )
              for (
                var e = 0;
                e < this.config.settings.tracking.dismiss.length;
                e++
              )
                (0, c.Ho)(this.win, this.config.settings.tracking.dismiss[e]);
            this.onClose(), this.destroy();
          }),
          (r.onLoad = function () {
            var e = this.rootElement.querySelector(Gr).contentWindow,
              r = (0, d.xF)(e, "Kargo.PlatformMacros");
            r && (r.destroy = this.closeVideoAnchor.bind(this));
            var i = e.document.body;
            i && ((i.style.position = "static"), (i.style.bottom = "0")),
              t.prototype.onLoad.call(this);
          }),
          (r.onSizeChange = function (e, r) {
            var i;
            if (r > 200) {
              i = this.rootElement.querySelectorAll(".kargo-hover-link");
              for (var n = 0; n < i.length; n += 1) g(i[n], "hide");
            }
            t.prototype.onSizeChange.call(this, e, r);
          }),
          e
        );
      })($s),
      Fl = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        return Ae(e, t), e;
      })(lc),
      Bl = (function (t) {
        function e() {
          for (var e, r = arguments.length, i = new Array(r), n = 0; n < r; n++)
            i[n] = arguments[n];
          return (
            ((e = t.call.apply(t, [this].concat(i)) || this).isClosing = !1),
            (e.no_msg_back_timeout = null),
            (e.no_transitionend_timeout = null),
            e
          );
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.getRichMediaTag = function (t) {
            for (
              var e = t.matchAll(
                  /<HTMLResource>\s*?<!\[CDATA\[(.*?)\]\]>\s*?<\/HTMLResource>/g
                ),
                r = [],
                i = e.next();
              i && !i.done;

            ) {
              var n = i.value;
              n && n[1] && r.push(n[1]), (i = e.next());
            }
            return r;
          }),
          (r.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                var r,
                  i,
                  n,
                  o,
                  a,
                  s = this;
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          if (
                            ((r = this.config.settings.vast_xml),
                            (i = this.config.settings.vast_url),
                            r || i)
                          ) {
                            e.next = 5;
                            break;
                          }
                          return (
                            this.destroyWithError(
                              new Error("empty vast xml and url")
                            ),
                            e.abrupt("return")
                          );
                        case 5:
                          if (
                            "celtra" !== (n = this.getCreativeTagSource(r)) ||
                            !i
                          ) {
                            e.next = 9;
                            break;
                          }
                          return (
                            this.destroyWithError(
                              new Error(
                                "celtra video runway does not support vast url"
                              )
                            ),
                            e.abrupt("return")
                          );
                        case 9:
                          return (
                            (this.config.settings.disable_hover_hiding = !0),
                            r &&
                              ((o = this.getRichMediaTag(r)),
                              (this.config.content += o.join("")),
                              ac(r).forEach(function (t) {
                                s.config.content +=
                                  '<img style="position: absolute; visibility: hidden; left: -9999px; top: 0;" src="' +
                                  t +
                                  '" />';
                              })),
                            "ivo" === n &&
                              ((a = this.getIvoWindowVariablesScript(r, i)),
                              (this.config.content = a.concat(
                                this.config.content
                              ))),
                            (e.next = 14),
                            t.prototype.display.call(this)
                          );
                        case 14:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          (r.getHoverElem = function () {
            return this.rootElement.querySelector(".kargo-ad-hover");
          }),
          (r.getCreativeTagSource = function (t) {
            var e;
            if (!t) return "ivo";
            var r = oc(t);
            return (
              (null == r || null == (e = r.creativeTagSource)
                ? void 0
                : e.toLowerCase()) || "ivo"
            );
          }),
          (r.getIvoWindowVariablesScript = function (t, e) {
            var r = window.document.createElement("script");
            return (
              t
                ? (r.innerText =
                    'window.ivo_kargo_vast_xml = atob("' + btoa(t) + '");')
                : e && (r.innerText = "window.ivo_kargo_vast_url = " + e),
              r.outerHTML
            );
          }),
          (r.fadeOutAnimation = function () {
            var t = this.getHoverElem();
            t &&
              ((t.style.transition = "opacity 500ms ease-out"),
              (t.style.opacity = "0"));
          }),
          (r.hoverClose = function (e) {
            var r = this;
            if (!this.isClosing) {
              this.isClosing = !0;
              var i = !1,
                n = function () {
                  i ||
                    ((i = !0),
                    r.win.clearTimeout(r.no_transitionend_timeout),
                    t.prototype.hoverClose.call(r, e));
                };
              this.win.postMessage(
                { message: "krg_video_runway_initiate_close" },
                "*"
              );
              var o = function (t) {
                if ("krg_video_runway_is_closed" === t.data) {
                  r.win.clearTimeout(r.no_msg_back_timeout),
                    r.win.removeEventListener("message", o),
                    r.fadeOutAnimation();
                  var e = r.getHoverElem();
                  null == e ||
                    e.addEventListener("transitionend", function (t) {
                      t.target === e && "opacity" === t.propertyName && n();
                    }),
                    (r.no_transitionend_timeout = r.win.setTimeout(function () {
                      n();
                    }, 1e3));
                }
              };
              this.win.addEventListener("message", o),
                (this.no_msg_back_timeout = this.win.setTimeout(function () {
                  r.win.removeEventListener("message", o), n();
                }, 3500));
            }
          }),
          (r.destroyWithError = function (t) {
            this.logger.error(t), this.reportError(t), this.destroy();
          }),
          e
        );
      })(gl),
      Ul = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        return Ae(e, t), e;
      })(lc),
      Hl = (function (t) {
        function e() {
          return t.apply(this, arguments) || this;
        }
        return (
          Ae(e, t),
          (e.prototype.getRenderConfig = function () {
            return t.prototype.getRenderConfig.call(this, {
              width: 160,
              height: 600,
              expansionCheck: !0,
            });
          }),
          e
        );
      })(pc),
      jl = "kargo-hover--branding-none",
      zl = "kargo-hover-close-progress",
      Wl = "kargo-wrapper",
      Kl = (function (t) {
        function e(e, r, i) {
          var n;
          return (
            ((n = t.call(this, e, r, i) || this).hideBranding = !0),
            (n.isBreakout = !1),
            n.registerEventListener(),
            n
          );
        }
        Ae(e, t);
        var r = e.prototype;
        return (
          (r.registerEventListener = function () {
            var t = this;
            this.win.addEventListener("message", function (e) {
              t.logger.debug("Received message: ", e.data);
              var r = t.rootElement.querySelector(".kargo-ad-hover");
              "kargo-wrapper-breakout-complete" === e.data
                ? (t.isBreakout &&
                    ((r.style.display = "none"),
                    setTimeout(function () {
                      r.style.display = "block";
                    }, 100)),
                  t.showBranding(),
                  t.showCloseButton())
                : "kargo-wrapper-breakout-begin" === e.data &&
                  ((t.isBreakout = !0), t.hideCloseButton());
            });
          }),
          (r.showBranding = function () {
            var t = this.rootElement.querySelector("." + jl);
            t &&
              "none" !== this.config.settings.branding &&
              (this.logger.debug("showing branding"),
              w(t, jl),
              "kargo" !== this.config.settings.branding &&
                g(t, "kargo-hover--branding-" + this.config.settings.branding));
          }),
          (r.showCloseButton = function () {
            Array.from(
              this.rootElement.querySelectorAll(".kargo-hover-close")
            ).some(function (t) {
              return !!p(t, Wl) && (w(t, Wl), w(t, zl), !0);
            });
          }),
          (r.hideCloseButton = function () {
            Array.from(
              this.rootElement.querySelectorAll(".kargo-hover-close")
            ).some(function (t) {
              var e = t.getBoundingClientRect();
              return !(!e.height || !e.width) && (g(t, Wl), g(t, zl), !0);
            });
          }),
          (r.onLoad = function () {
            if ((t.prototype.onLoad.call(this), this.hideBranding)) {
              this.logger.debug("hiding the wrapper branding");
              var e = this.rootElement.querySelector(".kargo-ad-hover");
              if (e) {
                g(e, jl);
                var r = this.config.settings.branding;
                "kargo" !== r &&
                  "none" !== r &&
                  w(
                    e,
                    "kargo-hover--branding-" + this.config.settings.branding
                  );
              }
            }
            this.hideCloseButton();
          }),
          (r.display = (function () {
            var e = (0, V.A)(
              P().mark(function e() {
                return P().wrap(
                  function (e) {
                    for (;;)
                      switch ((e.prev = e.next)) {
                        case 0:
                          return (
                            "breakout" === this.config.execution &&
                              ((this.config.content =
                                this.config.content.replace(
                                  /\/wrapper.min.js/g,
                                  "/wrapper-breakout.min.js"
                                )),
                              this.logger.warn(
                                "Redirecting breakout execution to use breakout template"
                              )),
                            e.abrupt("return", t.prototype.display.call(this))
                          );
                        case 2:
                        case "end":
                          return e.stop();
                      }
                  },
                  e,
                  this
                );
              })
            );
            return function () {
              return e.apply(this, arguments);
            };
          })()),
          e
        );
      })($s),
      ql = Object.values(Br.B),
      Gl = (function () {
        function e() {}
        return (
          (e.normalizeFormat = function (t) {
            if (!ql.includes(t)) {
              var e = ql.find(function (e) {
                return t.toLowerCase() === e.toLowerCase();
              });
              if (e) return e;
            }
            return t;
          }),
          (e.resolveFormatClass = function (e, r) {
            if ("viewstream" === r) return Ps;
            var i = t[e];
            return i || (e === Br.B.HOVER ? $s : Vs);
          }),
          e
        );
      })(),
      Yl =
        "https://storage.cloud.kargo.com/ad/network/tag/test-mp-adtag/json/flourish-deals.json",
      Jl = "control";
    function Zl(t, e) {
      return $l.apply(this, arguments);
    }
    function $l() {
      return (
        ($l = (0, V.A)(
          P().mark(function t(e, r) {
            var n;
            return P().wrap(function (t) {
              for (;;)
                switch ((t.prev = t.next)) {
                  case 0:
                    if (!(n = (0, i.Fk)(e, (0, i.sk)(e))).flourishDeals) {
                      t.next = 3;
                      break;
                    }
                    return t.abrupt("return", n.flourishDeals);
                  case 3:
                    if (!n.flourishDealsPromise) {
                      t.next = 5;
                      break;
                    }
                    return t.abrupt("return", n.flourishDealsPromise);
                  case 5:
                    return (
                      (n.flourishDealsPromise = (0, V.A)(
                        P().mark(function t() {
                          var i;
                          return P().wrap(
                            function (t) {
                              for (;;)
                                switch ((t.prev = t.next)) {
                                  case 0:
                                    return (
                                      (t.prev = 0),
                                      (t.next = 3),
                                      (0, c.dA)(Yl, e, {})
                                    );
                                  case 3:
                                    if (
                                      ((i = t.sent),
                                      (o = i) &&
                                        "object" == typeof o &&
                                        !Array.isArray(o))
                                    ) {
                                      t.next = 7;
                                      break;
                                    }
                                    return (
                                      r.error(
                                        "flourish-experiment: malformed JSON at " +
                                          Yl,
                                        i
                                      ),
                                      t.abrupt("return", null)
                                    );
                                  case 7:
                                    return (
                                      (n.flourishDeals = i),
                                      t.abrupt("return", i)
                                    );
                                  case 11:
                                    return (
                                      (t.prev = 11),
                                      (t.t0 = t.catch(0)),
                                      r.error(
                                        "flourish-experiment: failed to load " +
                                          Yl,
                                        t.t0
                                      ),
                                      t.abrupt("return", null)
                                    );
                                  case 15:
                                  case "end":
                                    return t.stop();
                                }
                              var o;
                            },
                            t,
                            null,
                            [[0, 11]]
                          );
                        })
                      )()),
                      t.abrupt("return", n.flourishDealsPromise)
                    );
                  case 7:
                  case "end":
                    return t.stop();
                }
            }, t);
          })
        )),
        $l.apply(this, arguments)
      );
    }
    function Xl(t) {
      var e = t[Jl];
      if (void 0 === e) return null;
      var r = Object.keys(t)
        .filter(function (t) {
          return t !== Jl;
        })
        .map(function (e) {
          return { value: e, weight: t[e] };
        });
      return { control: { value: Jl, weight: e }, variants: r };
    }
    function Ql() {
      return (
        (Ql = (0, V.A)(
          P().mark(function t(e, r, i) {
            var n, o, a, s, c, l, u, h, d, p;
            return P().wrap(
              function (t) {
                for (;;)
                  switch ((t.prev = t.next)) {
                    case 0:
                      if (((t.prev = 0), e.format === Br.B.MIDDLE_BANNER)) {
                        t.next = 5;
                        break;
                      }
                      return (
                        null !=
                          (o =
                            null == (n = e.source)
                              ? void 0
                              : n.creativeFlags) &&
                          o.flourish &&
                          (delete o.flourish,
                          we.reportAdMetric(
                            {
                              type: "flourish_blocked",
                              errCode: "not_middle_banner",
                              version: "10.9.0-kat-7484-test",
                            },
                            e,
                            i
                          )),
                        t.abrupt("return")
                      );
                    case 5:
                      if (((a = e.source || {}), (s = a.dealId))) {
                        t.next = 8;
                        break;
                      }
                      return t.abrupt("return");
                    case 8:
                      return (t.next = 10), Zl(r, i);
                    case 10:
                      if ((c = t.sent)) {
                        t.next = 13;
                        break;
                      }
                      return t.abrupt("return");
                    case 13:
                      if ((l = c[s])) {
                        t.next = 16;
                        break;
                      }
                      return t.abrupt("return");
                    case 16:
                      if ((u = Xl(l))) {
                        t.next = 20;
                        break;
                      }
                      return (
                        i.error(
                          'flourish-experiment: deal "' +
                            s +
                            '" has no "control" key; skipping'
                        ),
                        t.abrupt("return")
                      );
                    case 20:
                      if (
                        ((h = ul.register(
                          s + "-flourish",
                          u.control,
                          u.variants,
                          void 0,
                          i
                        )),
                        (e.source.creativeFlags = e.source.creativeFlags || {}),
                        (d = e.source.creativeFlags),
                        h.value !== Jl)
                      ) {
                        t.next = 26;
                        break;
                      }
                      return (
                        d.flourish && delete d.flourish.manifest_url,
                        t.abrupt("return")
                      );
                    case 26:
                      (d.flourish = d.flourish || {}),
                        (p =
                          "https://storage.cloud.kargo.com/ad/network/tag/templates/" +
                          h.value +
                          ".json"),
                        (d.flourish.manifest_url = p),
                        (t.next = 34);
                      break;
                    case 31:
                      (t.prev = 31),
                        (t.t0 = t.catch(0)),
                        i.error("flourish-experiment: unexpected error", t.t0);
                    case 34:
                    case "end":
                      return t.stop();
                  }
              },
              t,
              null,
              [[0, 31]]
            );
          })
        )),
        Ql.apply(this, arguments)
      );
    }
    var tu = {
      resolveFlourishUrl: function (t, e, r) {
        return Ql.apply(this, arguments);
      },
    };
    function eu(t) {
      if (!t || "object" != typeof t) return !1;
      var e = t;
      return (
        "string" == typeof e.name &&
        ("expanding" === e.type || "non-expanding" === e.type) &&
        (void 0 === e.js || null === e.js || "string" == typeof e.js) &&
        (void 0 === e.css || null === e.css || "string" == typeof e.css)
      );
    }
    function ru() {
      return (
        (ru = (0, V.A)(
          P().mark(function t(e, r, i) {
            var n, o, a;
            return P().wrap(
              function (t) {
                for (;;)
                  switch ((t.prev = t.next)) {
                    case 0:
                      if (
                        (o =
                          null == (n = e.source) ||
                          null == (n = n.creativeFlags) ||
                          null == (n = n.flourish)
                            ? void 0
                            : n.manifest_url)
                      ) {
                        t.next = 3;
                        break;
                      }
                      return t.abrupt("return", null);
                    case 3:
                      return (t.prev = 3), (t.next = 6), (0, c.dA)(o, r, {});
                    case 6:
                      if (eu((a = t.sent))) {
                        t.next = 10;
                        break;
                      }
                      return (
                        i.error(
                          "flourish-manifest: invalid manifest at " + o,
                          a
                        ),
                        t.abrupt("return", null)
                      );
                    case 10:
                      return t.abrupt("return", a);
                    case 13:
                      return (
                        (t.prev = 13),
                        (t.t0 = t.catch(3)),
                        i.error("flourish-manifest: failed to load " + o, t.t0),
                        t.abrupt("return", null)
                      );
                    case 17:
                    case "end":
                      return t.stop();
                  }
              },
              t,
              null,
              [[3, 13]]
            );
          })
        )),
        ru.apply(this, arguments)
      );
    }
    var iu = {
        resolve: function (t, e, r) {
          return ru.apply(this, arguments);
        },
      },
      nu = (function () {
        function t(t, e, r, i) {
          (this.win = void 0),
            (this.logger = void 0),
            (this.moduleLoader = void 0),
            (this.version = void 0),
            (this.win = t),
            (this.logger = e),
            (this.moduleLoader = r),
            (this.version = i);
        }
        return (
          (t.prototype.createCreative = (function () {
            var t = (0, V.A)(
              P().mark(function t(e, r, o) {
                var a, s, c, u, h, p, g, f, v, m, k, b, y, w, _;
                return P().wrap(
                  function (t) {
                    for (;;)
                      switch ((t.prev = t.next)) {
                        case 0:
                          (a = new l.wm("CreativeFactory")),
                            (s = window),
                            (c = (0, i.sk)(s)),
                            (u = new n.V(c)),
                            (h = function (t, i) {
                              var n =
                                i instanceof Error
                                  ? i.name + " - " + i.message
                                  : String(i);
                              new he(s, r).report(t, n, {
                                slot: e.slot || "unknown",
                                format: e.format || "unknown",
                              });
                            }),
                            (t.prev = 5),
                            (e.format = Gl.normalizeFormat(e.format)),
                            (g = Gl.resolveFormatClass(e.format, e.execution)),
                            (p = new g(c, u, o)),
                            (t.next = 15);
                          break;
                        case 11:
                          return (
                            (t.prev = 11),
                            (t.t0 = t.catch(5)),
                            h(Q, t.t0),
                            t.abrupt("return", null)
                          );
                        case 15:
                          return (
                            (f = {
                              show: function () {
                                return p.show();
                              },
                              hide: function () {
                                return p.hide();
                              },
                              destroy: function () {
                                return p.destroy();
                              },
                              isVisible: function () {
                                return p.eventHandler.isVisible;
                              },
                              isViewable: function () {
                                return p.eventHandler.isViewable;
                              },
                              isDisplayed: function () {
                                return p.eventHandler.isDisplayed;
                              },
                              isDestroyed: function () {
                                return p.eventHandler.isDestroyed;
                              },
                              getLocalId: function () {
                                return p.config.localId;
                              },
                              getId: function () {
                                return p.config.id;
                              },
                              getFormat: function () {
                                return p.config.format;
                              },
                              getType: function () {
                                return p.config.type;
                              },
                              getSlotId: function () {
                                return p.config.slot;
                              },
                              getAnalytics: function () {
                                return p.getAnalytics();
                              },
                              getConfig: function () {
                                return (0, d.h1)({}, p.config);
                              },
                            }),
                            (t.prev = 16),
                            (t.next = 19),
                            tu.resolveFlourishUrl(e, this.win, u)
                          );
                        case 19:
                          return (t.next = 21), iu.resolve(e, this.win, u);
                        case 21:
                          !(m = t.sent) &&
                            null != (v = e.source) &&
                            null != (v = v.creativeFlags) &&
                            null != (v = v.flourish) &&
                            v.manifest_url &&
                            (u.debug(
                              "flourish-manifest: manifest load failed, no flourish will be applied"
                            ),
                            we.reportAdMetric(
                              {
                                type: "flourish_manifest_load_failure",
                                errCode:
                                  "manifest_fetch_failed: " +
                                  e.source.creativeFlags.flourish.manifest_url,
                                version: "10.9.0-kat-7484-test",
                              },
                              e,
                              u
                            )),
                            null != m && m.css && (p.templateCss += m.css),
                            (p.flourishManifest = m || void 0),
                            (t.next = 30);
                          break;
                        case 27:
                          (t.prev = 27), (t.t1 = t.catch(16)), h(tt, t.t1);
                        case 30:
                          return (
                            (k = function (t) {
                              p.reportError(t), p.destroy();
                            }),
                            (t.prev = 31),
                            (b = {
                              ActiveView: An,
                              CreativeSandbox: ho,
                              FabrikTemplate: po,
                              Ias: go,
                              NativeVideoComponent: No,
                              SizeMonitor: Fo,
                              Template: Bo,
                              Video: Po,
                              VideoAnchorComponent: jo,
                              ViewstreamComponent: Ko,
                              VisibilityMonitor: Xo,
                            }),
                            p.setComponents(b),
                            (p.source = r),
                            p.setConfig(e),
                            (t.prev = 36),
                            (t.next = 39),
                            p.detectContainerEnvironment()
                          );
                        case 39:
                          if (
                            (_ =
                              null !=
                              (y =
                                null == (w = s.Kargo) ||
                                null == (w = w.versions) ||
                                null == (w = w[o])
                                  ? void 0
                                  : w.CreativeRegister)
                                ? y
                                : null)
                          ) {
                            t.next = 42;
                            break;
                          }
                          throw a.errCant("Add creative to creative register");
                        case 42:
                          return _.add(f), (t.next = 45), p.display();
                        case 45:
                          return t.abrupt("return", f);
                        case 48:
                          (t.prev = 48), (t.t2 = t.catch(36)), k(t.t2);
                        case 51:
                          t.next = 56;
                          break;
                        case 53:
                          (t.prev = 53), (t.t3 = t.catch(31)), k(t.t3);
                        case 56:
                          return t.abrupt("return", f);
                        case 57:
                        case "end":
                          return t.stop();
                      }
                  },
                  t,
                  this,
                  [
                    [5, 11],
                    [16, 27],
                    [31, 53],
                    [36, 48],
                  ]
                );
              })
            );
            return function (e, r, i) {
              return t.apply(this, arguments);
            };
          })()),
          t
        );
      })();
    const ou = nu;
    function au(t) {
      return function (e, r) {
        var i = (function (t, e) {
          var r = t.versions || {},
            i = Object.keys(r);
          if (!i.length) return null;
          if (e) {
            var n = S(e),
              o = i.find(function (t) {
                return r[t].self_url === n;
              });
            return o ? r[o] : null;
          }
          return r[i[0]];
        })(t, r && r.ad_tag_url);
        i && i.AdTag && i.AdTag.getAd(e, r);
      };
    }
    const su = (function () {
      function t() {
        (this.globalConfig = void 0),
          (this.slotConfigs = void 0),
          (this.globalCallbacks = void 0),
          (this.slotCallbacks = void 0),
          (this.globalConfig = null),
          (this.slotConfigs = {}),
          (this.globalCallbacks = []),
          (this.slotCallbacks = {});
      }
      var e = t.prototype;
      return (
        (e.setGlobalConfig = function (t) {
          if ("object" == typeof t) {
            this.globalConfig = t;
            for (var e = 0; e < this.globalCallbacks.length; e += 1)
              this.globalCallbacks[e]();
            this.globalCallbacks = [];
          }
        }),
        (e.getGlobalConfig = function () {
          return this.globalConfig;
        }),
        (e.setSlotConfig = function (t) {
          if ("object" == typeof t && t.getId && "function" == typeof t.getId) {
            var e = t.getId();
            if (
              e &&
              ((this.slotConfigs[t.getId()] = t), this.slotCallbacks[e])
            ) {
              for (var r = 0; r < this.slotCallbacks[e].length; r += 1)
                this.slotCallbacks[e][r]();
              this.slotCallbacks[e] = [];
            }
          }
        }),
        (e.getSlotConfig = function (t) {
          return this.slotConfigs[t] || null;
        }),
        (e.onGlobalReady = function (t) {
          "function" == typeof t &&
            (this.globalConfig ? t() : this.globalCallbacks.push(t));
        }),
        (e.onSlotReady = function (t, e) {
          "function" == typeof e &&
            (this.slotConfigs[t]
              ? e()
              : ((this.slotCallbacks[t] = this.slotCallbacks[t] || []),
                this.slotCallbacks[t].push(e)));
        }),
        t
      );
    })();
    function cu(t, e) {
      var r = Object.keys(t);
      if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e &&
          (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })),
          r.push.apply(r, i);
      }
      return r;
    }
    function lu(t) {
      for (var e = 1; e < arguments.length; e++) {
        var r = null != arguments[e] ? arguments[e] : {};
        e % 2
          ? cu(Object(r), !0).forEach(function (e) {
              (0, T.A)(t, e, r[e]);
            })
          : Object.getOwnPropertyDescriptors
          ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
          : cu(Object(r)).forEach(function (e) {
              Object.defineProperty(
                t,
                e,
                Object.getOwnPropertyDescriptor(r, e)
              );
            });
      }
      return t;
    }
    var uu = {
        enable_active_view_rewrite: !0,
        enable_cerberus: !0,
        enable_ias_viewability: !0,
        disable_hover_hiding: !1,
        overlap_detection_sample: 1,
      },
      hu = (function () {
        function t() {
          (this.config = void 0),
            (this.win = null),
            (this.enableOverlapDetection = null),
            (this.config = {
              debug: !1,
              environment: pn.PRODUCTION,
              trackLatency: !0,
              publisher_id: null,
              property_id: null,
              conditional_check: null,
              pre_js: null,
              pre_css: null,
              settings: lu({}, uu),
            });
        }
        var e = t.prototype;
        return (
          (e.setConfig = function (t) {
            (0, d.h1)(this.config, t),
              null == this.config.settings &&
                (this.config.settings = lu({}, uu));
          }),
          (e.getConfig = function () {
            return this.config;
          }),
          (e.checkPageVars = function (t) {
            var e = (0, o.pO)(t),
              r = (0, o.P3)(e, "krg_disable_hiding");
            void 0 !== t.__krg_cerberus &&
              (this.config.settings.enable_cerberus = t.__krg_cerberus),
              (t.__krg_disable_hiding || "true" === r) &&
                (this.config.settings.disable_hover_hiding = !0),
              (0, o.P3)(e, "krg_debug") && (this.config.debug = !0);
            var i = (0, o.P3)(e, "krg_overlap");
            i &&
              (Number.isNaN(Number(i))
                ? ((this.enableOverlapDetection = !0),
                  (this.config.settings.overlap_detection_sample = 100))
                : (this.config.settings.overlap_detection_sample = Number(i))),
              void 0 !== t.__krg_track_latency &&
                (this.config.trackLatency = t.__krg_track_latency);
            var n = (0, o.P3)(e, "krg_latency");
            "true" === n
              ? (this.config.trackLatency = !0)
              : "false" === n && (this.config.trackLatency = !1),
              "boolean" == typeof t.__krg_bto_stunts_enabled &&
                (this.config.settings.enable_bto_stunts =
                  t.__krg_bto_stunts_enabled);
          }),
          (e.shouldEnableBtoStunts = function () {
            return this.config.settings.enable_bto_stunts || !1;
          }),
          (e.getEnvironment = function () {
            return this.config.environment;
          }),
          (e.isDebug = function () {
            return this.config.debug;
          }),
          (e.isLatencyTracked = function () {
            return this.config.trackLatency;
          }),
          (e.getPublisherId = function () {
            return this.config.publisher_id;
          }),
          (e.getPropertyId = function () {
            return this.config.property_id;
          }),
          (e.getConditionalCheckFunc = function () {
            return this.config.conditional_check;
          }),
          (e.getPreLoadCss = function () {
            return this.config.pre_css;
          }),
          (e.getPreLoadFunc = function () {
            return this.config.pre_js;
          }),
          (e.getEnabledPlugins = function () {
            var t = ["IframeBuster"];
            return (
              this.config.settings.enable_cerberus && t.push("Cerberus"), t
            );
          }),
          (e.isActiveViewRewriteEnabled = function () {
            return this.config.settings.enable_active_view_rewrite;
          }),
          (e.isIasViewabilityEnabled = function () {
            return this.config.settings.enable_ias_viewability;
          }),
          (e.isHoverHidingDisabled = function () {
            return this.config.settings.disable_hover_hiding;
          }),
          (e.shouldCheckOverlap = function () {
            if (null !== this.enableOverlapDetection)
              return this.enableOverlapDetection;
            var t = 100 * Math.random();
            return (
              (this.enableOverlapDetection =
                t <= this.config.settings.overlap_detection_sample),
              this.enableOverlapDetection
            );
          }),
          (e.setEnableOverlapDetection = function (t) {
            this.enableOverlapDetection = t;
          }),
          t
        );
      })();
    const du = hu;
    var pu = (function () {
      function t() {
        (this.config = void 0),
          (this.forceSource = void 0),
          (this.formatConfigs = void 0),
          (this.config = {
            kargo_id: null,
            platform: null,
            position: null,
            allow_responsive: !0,
            allow_multiple: !1,
            override_url: null,
            passback_js: null,
            fail_callback: null,
            conditional_check: null,
            pre_js: null,
            post_js: null,
            pre_css: null,
          }),
          (this.forceSource = null),
          (this.formatConfigs = {});
      }
      var e = t.prototype;
      return (
        (e.setConfig = function (t) {
          (t.settings = t.settings && this.renameToABA(t.settings)),
            (0, d.h1)(this.config, t);
        }),
        (e.renameToABA = function (t) {
          var e = this;
          return Array.isArray(t)
            ? t.map(function (t) {
                return (t.format = e.replaceFormatName(t.format)), t;
              })
            : ((t.format = this.replaceFormatName(t.format)), t);
        }),
        (e.replaceFormatName = function (t) {
          var e = t;
          return (
            "Native" === t
              ? (e = Br.B.ABA_DISPLAY)
              : "NativeVideoKeyArt" === t
              ? (e = Br.B.ABA_VIDEO)
              : "NativeAnchor" === t && (e = Br.B.ABA_ADHESION_DISPLAY),
            e
          );
        }),
        (e.getConfig = function () {
          return this.config;
        }),
        (e.checkPageVars = function (t) {
          var e = (0, o.pO)(t);
          (0, o.P3)(e, "krg_server") &&
            (this.forceSource = (0, o.P3)(e, "krg_server"));
        }),
        (e.setFormatConfig = function (t) {
          t.getFormat &&
            "function" == typeof t.getFormat &&
            (this.formatConfigs[t.getFormat()] = t);
        }),
        (e.getFormatConfig = function (t) {
          var e = null;
          return this.formatConfigs[t] && (e = this.formatConfigs[t]), e;
        }),
        (e.getAllFormatConfigs = function () {
          return this.formatConfigs;
        }),
        (e.getId = function () {
          return this.config.kargo_id;
        }),
        (e.getPlatform = function () {
          return this.config.platform;
        }),
        (e.getPosition = function () {
          return this.config.position;
        }),
        (e.getOverrideUrl = function () {
          return this.config.override_url;
        }),
        (e.getPassbackConfig = function () {
          var t = this;
          return {
            isEnabled: function () {
              return (
                (null === t.forceSource || t.forceSource === Jr.PASSBACK) &&
                null != t.config.passback_js
              );
            },
            getHtml: function () {
              return t.config.passback_js;
            },
            getFormat: function () {
              var e;
              switch (t.config.position) {
                case "top":
                  e = "TopBanner";
                  break;
                case "mid":
                  e = "MiddleBanner";
                  break;
                case "bottom":
                  e = "BottomBanner";
                  break;
                case "hover":
                  e = "Hover";
              }
              return t.config.passback_format || e;
            },
            getSize: function () {
              var e = "320x50";
              return (
                ("mid" !== t.config.position && "int" !== t.config.position) ||
                  (e = "300x250"),
                e
              );
            },
          };
        }),
        (e.allowsResponsiveCreatives = function () {
          return this.config.allow_responsive;
        }),
        (e.getFailedRequestFunc = function () {
          return this.config.fail_callback;
        }),
        (e.getConditionalCheckFunc = function () {
          return this.config.conditional_check;
        }),
        (e.getCss = function () {
          return this.config.pre_css;
        }),
        (e.getPreDrawFunc = function () {
          return this.config.pre_js;
        }),
        (e.getPostDrawFunc = function () {
          return this.config.post_js;
        }),
        t
      );
    })();
    const gu = pu;
    var fu = [
        "type",
        "format",
        "approved",
        "custom_css",
        "preload_callback",
        "success_callback",
        "ignore_slot_pre_css",
        "ignore_slot_pre_js",
        "ignore_slot_post_js",
      ],
      vu = (function () {
        function t() {
          (this.config = void 0),
            (this.config = {
              format: null,
              approved: { direct: !1, pmp: !1 },
              custom_css: null,
              preload_callback: null,
              success_callback: null,
              ignore_slot_pre_css: !1,
              ignore_slot_pre_js: !1,
              ignore_slot_post_js: !1,
            });
        }
        var e = t.prototype;
        return (
          (e.setConfig = function (t) {
            (0, d.h1)(this.config, t);
          }),
          (e.getConfig = function () {
            return this.config;
          }),
          (e.getFormat = function () {
            return this.config.format;
          }),
          (e.isApprovedForDirect = function () {
            var t, e;
            return (
              null !=
                (t = null == (e = this.config.approved) ? void 0 : e.direct) &&
              t
            );
          }),
          (e.isApprovedForPMP = function () {
            var t, e;
            return (
              null !=
                (t = null == (e = this.config.approved) ? void 0 : e.pmp) && t
            );
          }),
          (e.getCss = function () {
            return this.config.custom_css;
          }),
          (e.getPreDrawFunc = function () {
            return this.config.preload_callback;
          }),
          (e.getPostDrawFunc = function () {
            return this.config.success_callback;
          }),
          (e.isIgnoreSlotCss = function () {
            return this.config.ignore_slot_pre_css;
          }),
          (e.isIgnoreSlotPreDrawFunc = function () {
            return this.config.ignore_slot_pre_js;
          }),
          (e.isIgnoreSlotPostDrawFunc = function () {
            return this.config.ignore_slot_post_js;
          }),
          (e.getCreativeConfig = function () {
            var t = this,
              e = {};
            return (
              Object.keys(this.config).forEach(function (r) {
                fu.indexOf(r) < 0 && (e[r] = t.config[r]);
              }),
              e
            );
          }),
          t
        );
      })();
    const mu = vu;
    var ku = /(^|[./])storage(\.cloud)?\.kargo\.com\/ad\/network\/tag\//;
    function bu(t) {
      if (ku.test(t)) return !0;
      var e;
      try {
        e = new URL(t).hostname;
      } catch (t) {
        return !1;
      }
      return (
        !(!/(^|\.)kargo\.com$/.test(e) && !/(^|\.)krg\.io$/.test(e)) &&
        (t.indexOf("/ad/network/tag/") > 0 || /\/(AdTag|AdServe)[.-]/.test(t))
      );
    }
    var yu,
      wu,
      _u,
      Au = (function (t) {
        var e = t.document.currentScript;
        if (null != e && e.src) return e.src;
        for (
          var r = t.document.getElementsByTagName("script"), i = 0;
          i < r.length;
          i += 1
        ) {
          var n = r[i].src;
          if (n && bu(n)) return n;
        }
        return "";
      })(window);
    (yu = window),
      (wu = (0, i.sk)(yu)),
      (_u = (0, i.Fk)(yu, wu)).Config ||
        (_u.Config = (function (t) {
          var e = new n.V(wu);
          e.setLabel(["CONFIG", t]);
          var r = new su();
          return {
            setGlobalConfig: function (t) {
              if (!r.getGlobalConfig()) {
                var i = new du();
                i.checkPageVars(wu),
                  i.setConfig(t),
                  r.setGlobalConfig(i),
                  e.debug("Global Config set", i.getConfig());
              }
            },
            getGlobalConfig: function () {
              var t = r.getGlobalConfig(),
                e = null;
              return (
                t &&
                  (e = {
                    getConfig: function () {
                      return t.getConfig();
                    },
                    checkPageVars: function (e) {
                      return t.checkPageVars(e);
                    },
                    isDebug: function () {
                      return t.isDebug();
                    },
                    isLatencyTracked: function () {
                      return t.isLatencyTracked();
                    },
                    getEnvironment: function () {
                      return t.getEnvironment();
                    },
                    getPublisherId: function () {
                      return t.getPublisherId();
                    },
                    getPropertyId: function () {
                      return t.getPropertyId();
                    },
                    getConditionalCheckFunc: function () {
                      return t.getConditionalCheckFunc();
                    },
                    getPreLoadCss: function () {
                      return t.getPreLoadCss();
                    },
                    getPreLoadFunc: function () {
                      return t.getPreLoadFunc();
                    },
                    getEnabledPlugins: function () {
                      return t.getEnabledPlugins();
                    },
                    isActiveViewRewriteEnabled: function () {
                      return t.isActiveViewRewriteEnabled();
                    },
                    isIasViewabilityEnabled: function () {
                      return t.isIasViewabilityEnabled();
                    },
                    isHoverHidingDisabled: function () {
                      return t.isHoverHidingDisabled();
                    },
                    shouldCheckOverlap: function () {
                      return t.shouldCheckOverlap();
                    },
                    setEnableOverlapDetection: function (e) {
                      return t.setEnableOverlapDetection(e);
                    },
                    shouldEnableBtoStunts: function () {
                      return t.shouldEnableBtoStunts();
                    },
                  }),
                e
              );
            },
            setSlotConfig: function (t) {
              var i = t,
                n = new gu();
              if (
                (n.checkPageVars(wu),
                n.setConfig(t),
                n.getId() && !r.getSlotConfig(n.getId()))
              ) {
                var o = i.settings;
                if (o)
                  if (Array.isArray(o))
                    for (var a, s = 0; s < o.length; s += 1)
                      (a = new mu()).setConfig(o[s]), n.setFormatConfig(a);
                  else if (o.format) {
                    var c = new mu();
                    c.setConfig(o), n.setFormatConfig(c);
                  }
                r.setSlotConfig(n),
                  e.debug("Slot Config '" + n.getId() + "' set", n.getConfig());
              }
            },
            getSlotConfig: function (t) {
              var e = r.getSlotConfig(t);
              if (!e) return null;
              var i = function (t) {
                var r = e.getFormatConfig(t);
                return r
                  ? {
                      getConfig: function () {
                        return r.getConfig();
                      },
                      getFormat: function () {
                        return r.getFormat();
                      },
                      isApprovedForDirect: function () {
                        return r.isApprovedForDirect();
                      },
                      isApprovedForPMP: function () {
                        return r.isApprovedForPMP();
                      },
                      getCss: function () {
                        return r.getCss();
                      },
                      getPreDrawFunc: function () {
                        return r.getPreDrawFunc();
                      },
                      getPostDrawFunc: function () {
                        return r.getPostDrawFunc();
                      },
                      isIgnoreSlotCss: function () {
                        return r.isIgnoreSlotCss();
                      },
                      isIgnoreSlotPreDrawFunc: function () {
                        return r.isIgnoreSlotPreDrawFunc();
                      },
                      isIgnoreSlotPostDrawFunc: function () {
                        return r.isIgnoreSlotPostDrawFunc();
                      },
                      getCreativeConfig: function () {
                        return r.getCreativeConfig();
                      },
                    }
                  : null;
              };
              return {
                getConfig: function () {
                  return e.getConfig();
                },
                getFormatConfig: i,
                getAllFormatConfigs: function () {
                  var t = e.getAllFormatConfigs(),
                    r = {};
                  return (
                    t &&
                      Object.keys(t).forEach(function (t) {
                        var e = i(t);
                        e && (r[t] = e);
                      }),
                    r
                  );
                },
                getId: function () {
                  return e.getId();
                },
                getPlatform: function () {
                  return e.getPlatform();
                },
                getPosition: function () {
                  return e.getPosition();
                },
                getOverrideUrl: function () {
                  return e.getOverrideUrl();
                },
                getPassbackConfig: function () {
                  return e.getPassbackConfig();
                },
                isCallAutomatically: function () {
                  return e.isCallAutomatically();
                },
                getFailedRequestFunc: function () {
                  return e.getFailedRequestFunc();
                },
                getConditionalCheckFunc: function () {
                  return e.getConditionalCheckFunc();
                },
                getCss: function () {
                  return e.getCss();
                },
                getPreDrawFunc: function () {
                  return e.getPreDrawFunc();
                },
                getPostDrawFunc: function () {
                  return e.getPostDrawFunc();
                },
                allowsResponsiveCreatives: function () {
                  return e.allowsResponsiveCreatives();
                },
              };
            },
            onGlobalReady: function (t) {
              return r.onGlobalReady(t);
            },
            onSlotReady: function (t, e) {
              return r.onSlotReady(t, e);
            },
            setDeviceId: function () {},
            getDeviceId: function () {
              return null;
            },
          };
        })("page")),
      (_u.setGlobalConfig = _u.Config.setGlobalConfig),
      (_u.setAdConfig = _u.Config.setSlotConfig),
      (function (t, e) {
        var a;
        void 0 === e && (e = "");
        var s = (0, i.sk)(t),
          c = (0, i.Fk)(t, s),
          l = (function (t) {
            var e;
            return (
              (t &&
                (S(t) ||
                  (null == (e = t.split("/").pop())
                    ? void 0
                    : e.replace(".js", "")))) ||
              ""
            );
          })(e);
        if (
          l ||
          !Object.entries(null != (a = c.versions) ? a : {}).some(function (t) {
            var e = t[0],
              r = t[1];
            return "" !== e && r.AdTag;
          })
        ) {
          var u = O(c, l);
          if ((D(s, l), !u.AdTag)) {
            var d = new n.V(s);
            d.setLabel(["ADTAG", l]);
            var p = (0, o.P3)((0, o.pO)(s), "module_env"),
              g = new h(s, function () {
                var t = r()(c, "Config.getGlobalConfig", function () {}),
                  e = pn.PRODUCTION;
                return (
                  t.getEnvironment
                    ? (e = t.getEnvironment())
                    : p &&
                      Object.entries(pn).filter(function (t) {
                        t[0].toLowerCase() === p.toLowerCase() && (e = p);
                      }),
                  e
                );
              }),
              f = new ou(s, d, g, l),
              v = new dn(s, d, f, l);
            v.setSelfUrl(e),
              (u.AdTag = {
                getAd: function (t, e) {
                  v.getAd(t, e).catch(function () {});
                },
                loadAds: function () {
                  return v.loadAds();
                },
                getVersion: function () {
                  return "10.9.0-kat-7484-test";
                },
                getSelfUrl: function () {
                  return v.selfUrl;
                },
                report: function () {},
              }),
              (u.self_url = v.selfUrl),
              (u.version = "10.9.0-kat-7484-test"),
              (u.loaded = !0),
              c.AdTag || ((c.AdTag = u.AdTag), (c.self_url = v.selfUrl)),
              c.getAd ||
                ((c.getAd = au(c)),
                (c.loadAds = (function (t) {
                  return function () {
                    var e = t.versions || {};
                    Object.keys(e).forEach(function (t) {
                      var r = e[t];
                      r.AdTag && r.AdTag.loadAds();
                    });
                  };
                })(c))),
              (c.loaded = !0),
              (function (t, e) {
                "interactive" === t.document.readyState ||
                "complete" === t.document.readyState
                  ? e()
                  : t.document.addEventListener("DOMContentLoaded", e);
              })(s, function () {
                d.debug("v10.9.0-kat-7484-test"), v.loadAds();
              });
          }
        }
      })(window, Au);
  })();
})();
