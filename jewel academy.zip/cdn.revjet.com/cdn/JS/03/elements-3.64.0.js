/** Creative JS Library 3.64.0 (Mon Sep 14 20:52:16 UTC 2026) */
(function () {
  function aa(a) {
    function b(d) {
      return a.next(d);
    }
    function c(d) {
      return a.throw(d);
    }
    return new Promise(function (d, e) {
      function f(g) {
        g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e);
      }
      f(a.next());
    });
  }
  function m(a) {
    return aa(a());
  }
  function ba() {
    const a = window,
      b = a.frameElement;
    if (b) {
      var c = a.document.elementFromPoint;
      a.document.elementFromPoint = function (d, e) {
        let f = d,
          g = e;
        try {
          const h = a.getComputedStyle(b);
          if (h && h.transform) {
            const k =
              "undefined" !== typeof DOMMatrix
                ? new DOMMatrix(h.transform)
                : "undefined" !== typeof WebKitCSSMatrix
                ? new WebKitCSSMatrix(h.transform)
                : void 0;
            if (k) {
              const l = d / Math.sqrt(k.a * k.a + k.b * k.b);
              isFinite(l) && (f = l);
              const n = e / Math.sqrt(k.c * k.c + k.d * k.d);
              isFinite(n) && (g = n);
            }
          }
        } catch (h) {}
        return c.call(a.document, f, g);
      };
    }
  }
  function p(a) {
    return !a.I();
  }
  function ca(a, b) {
    return a.I() ? b() : a.get();
  }
  function da(a, b) {
    return a.I() ? b : a.get();
  }
  function r(a) {
    return a.I() ? null : a.get();
  }
  function ea(a, b) {
    return !a.I() && b(a.get());
  }
  function fa(a, b) {
    return a.I() ? b() : a;
  }
  class ha {
    constructor(a) {
      this.h = a;
    }
    I() {
      return !1;
    }
    get() {
      return this.h;
    }
    map(a) {
      return this.I() ? this : new ia(a(this.get()));
    }
    flatMap(a) {
      return this.I() ? this : a(this.get());
    }
    filter(a) {
      return this.I() || a(this.get()) ? this : t;
    }
    forEach(a) {
      this.I() || a(this.get());
    }
    match(a) {
      return this.I() ? a.Ad() : a.some(this.get());
    }
  }
  class ia extends ha {
    g(a) {
      return p(a) ? this.get() === a.get() : !1;
    }
    toString() {
      return `Some(${this.get()})`;
    }
  }
  class ja extends ha {
    constructor() {
      super();
    }
    I() {
      return !0;
    }
    get() {
      throw new TypeError("Can't extract the value of None.");
    }
    g(a) {
      return a.I();
    }
    toString() {
      return "None";
    }
  }
  const t = new ja();
  function u(a) {
    return null != a ? new ia(a) : t;
  }
  const w = "undefined" !== typeof window ? window : {};
  function x(a) {
    return "string" === typeof a;
  }
  function ka(a) {
    return "number" === typeof a;
  }
  function la(a) {
    return ("function" === typeof a && "undefined" !== typeof a.call) ||
      (a &&
        ("[object Function]" === Object.prototype.toString.call(a) ||
          ("undefined" !== typeof a.call &&
            "undefined" !== typeof a.propertyIsEnumerable &&
            !a.propertyIsEnumerable("call"))))
      ? !0
      : !1;
  }
  function ma(a, b) {
    a = a.split(".");
    b = b || w;
    for (let c; (c = a.shift()); )
      if (null != b[c]) b = b[c];
      else return t;
    return u(b);
  }
  function na(a, b) {
    a = a.split(".");
    let c = w;
    a[0] in c || !c.execScript || c.execScript("var " + a[0]);
    for (let d; a.length && (d = a.shift()); )
      a.length || void 0 === b
        ? c[d]
          ? (c = c[d])
          : (c = c[d] = {})
        : (c[d] = b);
  }
  let oa = null;
  function pa(a) {
    let b = !1,
      c;
    return function () {
      b || ((c = a()), (b = !0));
      return c;
    };
  }
  function qa(a, b) {
    return 0 === a.lastIndexOf(b, 0);
  }
  function sa(a) {
    return (
      qa(a, "http:") ||
      qa(a, "https:") ||
      qa(a, "file:") ||
      qa(a, "data:") ||
      qa(a, "//")
    );
  }
  const ta = pa(function () {
      try {
        let b = window;
        for (; b; ) {
          var a;
          if (!(a = "on" === b.logging)) {
            const c = RegExp("[?&]logging=([^&]*)").exec(b.location.search);
            a = "on" === (c && decodeURIComponent(c[1].replace(/\+/g, " ")));
          }
          if (a) return !0;
          b = b === b.parent ? null : b.parent;
        }
      } catch (b) {}
      return !1;
    }),
    ua = pa(function () {
      try {
        if (window !== window.top) {
          const a = window.parent;
          if (a.REVJET_Tag || a.REVJET_TagObj_1) return !0;
        }
      } catch (a) {}
      return !1;
    });
  function va(a, b, c) {
    if (window.top !== window.self)
      try {
        let d = window;
        for (; d && d !== window.top; )
          (d = d.parent),
            d.postMessage(
              JSON.stringify({
                module: "REVJET_Tag.Ad",
                method: a,
                messageId: b,
                properties: c,
              }),
              "*"
            );
      } catch (d) {}
  }
  function y() {
    return `${new Date().getTime()}-${Math.floor(100 * Math.random() + 1)}`;
  }
  const wa = pa(function () {
    return (
      "ontouchstart" in w ||
      !!(
        w.document &&
        document.documentElement &&
        "ontouchstart" in document.documentElement
      ) ||
      !(!w.navigator || !w.navigator.msMaxTouchPoints)
    );
  });
  function xa(a, b) {
    return null != b
      ? a.reduce(
          (c, d) =>
            -1 === c.findIndex((e) => e[b] === d[b]) ? c.concat(d) : c,
          []
        )
      : a;
  }
  const ya = pa(function () {
      return "undefined" !== typeof document.hidden
        ? "hidden"
        : "undefined" !== typeof document.webkitHidden
        ? "webkitHidden"
        : "undefined" !== typeof document.mozHidden
        ? "mozHidden"
        : "undefined" !== typeof document.msHidden
        ? "msHidden"
        : null;
    }),
    za = pa(function () {
      const a = ya();
      return a ? a.toLowerCase().replace("hidden", "visibilitychange") : null;
    });
  function Aa() {
    const a = ya();
    return a ? !!document[a] : !1;
  }
  function Ba(a) {
    return -1 !== a.indexOf("?") ? "&" : "?";
  }
  function Ca(a, b) {
    const c = a.indexOf("#");
    if (-1 !== c) {
      const d = a.slice(0, c);
      return d + Ba(d) + b + a.slice(c);
    }
    return a + Ba(a) + b;
  }
  function Da(a) {
    if (void 0 === b || b > a.length) var b = a.length;
    return " desc" === a.substring(b - 5, b);
  }
  function Ea(a) {
    if (x(a)) {
      const b = a.split(","),
        c = b
          .filter((e) => -1 !== e.indexOf("$"))
          .map((e) => e.substring(e.lastIndexOf("$") + 1)),
        d = c
          .filter((e) => -1 !== e.indexOf("_"))
          .map((e) => e.substring(0, e.lastIndexOf("_")));
      return [a].concat(b.concat(c.concat(d)));
    }
    return a;
  }
  function Fa(a) {
    if (a) {
      a.style && (a.style.cursor = "pointer");
      a = a.children || [];
      for (let b = 0; b < a.length; b++) {
        const c = a[b];
        c && Fa(c);
      }
    }
  }
  function Ga(a) {
    if (a) {
      a.style && a.style.removeProperty("cursor");
      a = a.children || [];
      for (let b = 0; b < a.length; b++) {
        const c = a[b];
        c && Ga(c);
      }
    }
  }
  function Ha(a) {
    return new Promise((b) => {
      const c = new Image();
      c.onerror = () => b();
      c.onload = () => b(c);
      c.src = a;
    });
  }
  function Ia(a, b = 0, c = 3) {
    if (!(b > c)) {
      if (a instanceof Node)
        return { id: a.id || "", nodeName: a.nodeName, nodeType: a.nodeType };
      if (!(a instanceof Window)) {
        if (Array.isArray(a)) return a.map((d) => Ia(d, b, c));
        if (!la(a)) {
          if (a instanceof Object) {
            const d = {};
            for (let e in a) d[e] = Ia(a[e], b + 1, c);
            return d;
          }
          return a;
        }
      }
    }
  }
  function Ja(a, b, c) {
    b = Array.prototype.splice.call(a, b, 1);
    Array.prototype.splice.call(a, c, 0, b[0]);
  }
  function Ka(a) {
    return a ? u(document.getElementById(a)) : t;
  }
  function La(a) {
    return a && a.parentNode ? a.parentNode.removeChild(a) : null;
  }
  function Ma(a, b) {
    let c = [];
    Na(a, b, c, !1);
    return c;
  }
  function Oa(a, b) {
    const c = [];
    return Na(a, b, c, !0) ? c[0] : void 0;
  }
  function Na(a, b, c, d) {
    if (null != a)
      for (a = a.firstChild; a; ) {
        if ((b(a) && (c.push(a), d)) || Na(a, b, c, d)) return !0;
        a = a.nextSibling;
      }
    return !1;
  }
  function Pa(a, b) {
    for (; a; ) {
      if (b(a)) return u(a);
      a = a.parentNode;
    }
    return t;
  }
  function A(a, b) {
    return Array.prototype.slice.call(a.querySelectorAll(b));
  }
  function Qa(a) {
    const b = document.createElement("a");
    b.href = a;
    return "//" + b.hostname;
  }
  let Ra = [];
  function Sa(a) {
    if (a) {
      const b = Qa(a);
      if (!Ra.find((c) => c === b)) {
        Ra = Ra.concat(b);
        a = document.createElement("link");
        a.setAttribute("rel", "dns-prefetch");
        a.setAttribute("href", b);
        const c = document.getElementsByTagName("head");
        0 < c.length && c[0].appendChild(a);
      }
    }
  }
  function Ta(a, b) {
    if (Element.prototype.closest) return a.closest(b);
    if (!document.documentElement.contains(a)) return null;
    do {
      var c = a,
        d = b;
      if (
        Element.prototype.matches
          ? c.matches(d)
          : Element.prototype.msMatchesSelector
          ? c.msMatchesSelector(d)
          : Element.prototype.webkitMatchesSelector &&
            c.webkitMatchesSelector(d)
      )
        return a;
      a = a.parentElement || a.parentNode;
    } while (null !== a && 1 === a.nodeType);
    return null;
  }
  function Ua(a) {
    return "undefined" !== typeof window.requestAnimationFrame
      ? window.requestAnimationFrame(a)
      : window.setTimeout(a, 16);
  }
  function Va() {
    return new Promise((a) => {
      Ua(a);
    });
  }
  const Wa = navigator.userAgent,
    Xa = () =>
      -1 !== Wa.indexOf("iPhone") &&
      -1 === Wa.indexOf("iPod") &&
      -1 === Wa.indexOf("iPad");
  const Ya =
      "start_animation start_html5_animation hype_start_timeline hype_continue_timeline bodymovin_play_segments bodymovin_go_to_and_play".split(
        " "
      ),
    ab = Ya.concat(
      "show hide toggle_visibility go_to_frame go_to_stage hype_show_scene hype_show_next_scene hype_show_previous_scene".split(
        " "
      )
    );
  function B(a, b, c, d) {
    "undefined" !== typeof window.addEventListener
      ? a.addEventListener(b, c, d)
      : a.attachEvent("on" + b, c);
  }
  function bb(a, b, c, d) {
    "undefined" !== typeof window.removeEventListener
      ? a.removeEventListener(b, c, d)
      : a.detachEvent("on" + b, c);
  }
  function cb(a) {
    if ((a = a || window.event))
      a.preventDefault ? a.preventDefault() : (a.returnValue = !1);
  }
  function db(a) {
    if ((a = a || window.event))
      a.stopPropagation ? a.stopPropagation() : (a.cancelBubble = !0);
  }
  function eb(a, b) {
    a.F = b;
  }
  function fb(a) {
    if (a.h) {
      var b = new Date().getTime(),
        c = a.H + a.j + a.C + a.v;
      a.g || a.s || (a.D = c - b);
      !a.g && !a.s && b >= c ? gb(a) : (a.i = Ua(() => fb(a)));
    }
  }
  function gb(a) {
    a.i = 0;
    a.stop();
    a.F && a.F();
    a.ga && a.start();
  }
  class hb {
    constructor(a, b) {
      this.v = a;
      this.F = b;
      this.h = this.ga = !1;
      this.C = this.j = this.o = this.H = this.D = 0;
      this.g = this.s = !1;
      this.i = 0;
      this.m = null;
    }
    xb() {
      return this.v;
    }
    Cb() {
      return this.h;
    }
    hb() {
      return this.D;
    }
    start() {
      if (!this.h) {
        this.h = !0;
        this.g = Aa();
        this.C = this.j = 0;
        this.D = this.v;
        var a = new Date().getTime();
        this.H = a;
        this.o = this.g ? a : 0;
        this.i = Ua(() => fb(this));
        if ((a = za()))
          (this.m = () => {
            const b = Aa();
            if (this.g !== b) {
              this.g = b;
              const c = new Date().getTime();
              b ? (this.o = c) : (this.j += c - this.o);
            }
          }),
            B(document, a, this.m, !1);
      }
    }
    stop() {
      this.h = this.s = !1;
      this.D = this.C = this.o = this.j = this.H = 0;
      if (0 !== this.i) {
        var a = this.i;
        "undefined" !== typeof window.requestAnimationFrame
          ? window.cancelAnimationFrame(a)
          : window.clearTimeout(a);
        this.i = 0;
      }
      (a = za()) &&
        null !== this.m &&
        (bb(document, a, this.m, !1), (this.m = null));
    }
    pause() {
      !this.s && this.h && (this.s = !0);
    }
  }
  function ib(a) {
    let b = null;
    return function () {
      const c = this,
        d = arguments;
      b && b.stop();
      b = new hb(250, function () {
        b = null;
        a.apply(c, d);
      });
      b.ga = !1;
      b.start();
    };
  }
  function C(a, b, c) {
    if ("string" === typeof b) a.style[b] = c;
    else for (let d in b) a.style[d] = b[d];
  }
  function jb(a, b) {
    return a
      ? a.currentStyle
        ? a.currentStyle[b]
        : window.getComputedStyle && window.getComputedStyle(a, null)
        ? ((a = window.getComputedStyle(a, null)),
          a[b] || a.getPropertyValue(b))
        : a.style[b]
      : null;
  }
  function D(a) {
    let b = 0,
      c = 0;
    if (a) {
      var d = a.getBoundingClientRect();
      "width" in d && "height" in d && ((b = d.width), (c = d.height));
      0 == b &&
        0 == c &&
        ((d = jb(a, "width")),
        (a = jb(a, "height")),
        d &&
          a &&
          ((b = String(d)),
          (c = String(a)),
          -1 !== b.indexOf("px") && (b = b.substring(0, b.length - 2)),
          -1 !== c.indexOf("px") && (c = c.substring(0, c.length - 2)),
          "auto" === b && (b = 0),
          "auto" === c && (c = 0)));
    }
    return { width: b, height: c };
  }
  function kb(a) {
    return (a || "")
      .split(";")
      .filter(Boolean)
      .reduce((b, c) => {
        const [d, e] = c.split(":");
        b[d.trim()] = e.trim();
        return b;
      }, {});
  }
  function lb(a, b, c, d, e) {
    var f = window.getComputedStyle(a, null);
    if (!f) return null;
    const g = f.fontSize ? parseFloat(f.fontSize) : null;
    f = f.fontSize ? parseFloat(f.fontSize) : 24;
    d || (a.style.lineHeight = "normal");
    for (
      ;
      f > b &&
      (a.scrollHeight > a.clientHeight || a.scrollWidth > a.clientWidth);

    )
      f--, (a.style.fontSize = f + "px");
    if (
      c &&
      (a.scrollHeight > a.clientHeight || a.scrollWidth > a.clientWidth)
    ) {
      b = a.textContent;
      c = b.length;
      d = 1;
      for (let h = 0; 10 > h; h++) {
        const k = Math.floor((c + d) / 2);
        a.textContent = b.slice(0, k) + "\u2026";
        a.scrollHeight > a.clientHeight || a.scrollWidth > a.clientWidth
          ? (c = k)
          : (d = k);
      }
      a.innerHTML = b.slice(0, d) + "\u2026";
    }
    if (e) {
      b = kb(a.style.cssText);
      e = kb(e);
      const h = Object.assign(b, e);
      a.style.cssText = Object.keys(h).reduce(
        (k, l) => k + l + ":" + h[l] + ";",
        ""
      );
    }
    return { fontSize: f, nb: g };
  }
  function mb() {
    return new Promise((a) => {
      document.fonts && document.fonts.ready
        ? document.fonts.ready.then(
            () => Ua(() => a()),
            () => a()
          )
        : window.setTimeout(() => a(), 300);
    });
  }
  function nb(a, b, c, d, e) {
    return m(function* () {
      if (!a || a.hasAttribute("data-revjet-shrinking"))
        return { Jb: () => Promise.resolve(), fontSize: null, nb: null };
      const f = () => a.hasAttribute("data-revjet-shrinking-completed");
      let g;
      const h = () => {
        a.removeAttribute("data-revjet-shrinking");
        if (!f()) {
          a.hasAttribute("data-revjet-original-visibility")
            ? ((a.style.visibility = a.getAttribute(
                "data-revjet-original-visibility"
              )),
              a.removeAttribute("data-revjet-original-visibility"))
            : (a.style.visibility = "");
          a.setAttribute("data-revjet-shrinking-completed", "");
          const z = ib(() => nb(a, b, c, d, e));
          g = new window.ResizeObserver((L) => {
            for (let ra of L) ra.target === a && z();
          });
          g.observe(a);
        }
      };
      a.setAttribute("data-revjet-shrinking", "");
      f() ||
        (a.hasAttribute("data-revjet-original-visibility") ||
          a.setAttribute("data-revjet-original-visibility", a.style.visibility),
        (a.style.visibility = "hidden"));
      let k = null;
      try {
        f() || (yield mb()), (k = lb(a, b, c, d, e));
      } finally {
        h();
      }
      let l, n, q, v;
      return {
        Jb: () => {
          a.removeAttribute("data-revjet-shrinking-completed");
          g && g.unobserve(a);
          null != k && (a.style.fontSize = k.nb + "px");
          return Promise.resolve();
        },
        fontSize:
          null != (q = null == (l = k) ? void 0 : l.fontSize) ? q : null,
        nb: null != (v = null == (n = k) ? void 0 : n.nb) ? v : null,
      };
    });
  }
  function ob(a, b, c) {
    if ((a = document.getElementById(a))) {
      const d = a.cloneNode(!0);
      d.removeAttribute("data-revjet-shrink");
      d.removeAttribute("data-revjet-font-size");
      d.style.position = "absolute";
      d.style.left = "-10000px";
      d.style.top = "-10000px";
      d.style.visibility = "hidden";
      const e = d.querySelector(".text-elm");
      if (e) {
        a.parentNode.appendChild(d);
        let f, g;
        for (f = b - 1; f > c; f--) {
          const h = e.offsetWidth,
            k = d.offsetWidth;
          if (!(e.offsetHeight > d.offsetHeight || h > k)) break;
          g = b;
          e.style.fontSize = f + "px";
        }
        null != g &&
          a.querySelectorAll(".text-elm").forEach((h) => {
            h.style.fontSize = g + "px";
          });
        a.parentNode.removeChild(d);
      }
    }
  }
  function pb(a, b, c) {
    const d = document.getElementById(a);
    return d
      ? mb().then(() => {
          var e = d.querySelector(".text-elm");
          e &&
            ((e = window.getComputedStyle(e, null)),
            ob(
              a,
              null != c
                ? c
                : e && e.fontSize
                ? Math.round(parseFloat(e.fontSize))
                : 12,
              b
            ));
        })
      : Promise.resolve();
  }
  function qb(a) {
    C(a.g, "transition", "");
    C(a.g, a.j);
    for (let b = 0; b < a.h.length; b++) a.h[b](a);
  }
  function rb(a) {
    var b = [];
    for (let c = 0; c < a.s.length; c++) {
      let d = a.s[c];
      b.push(d.oc + " " + d.duration + "ms " + d.timing + " " + d.delay + "s");
    }
    a.g.getBoundingClientRect();
    C(a.g, "transition", b.join(","));
    C(a.g, a.j);
    b = new hb(a.i, () => qb(a));
    b.ga = !1;
    b.start();
  }
  function sb(a, b) {
    a.h.push(b);
  }
  class tb {
    constructor(a, b, c, d, e) {
      this.g = a;
      this.i = b;
      this.m = c;
      this.j = d;
      this.s = Array.isArray(e) ? e : [e];
      this.h = [];
    }
    play() {
      0 === this.i
        ? qb(this)
        : (C(this.g, this.m), window.setTimeout(() => rb(this), 0));
      return !0;
    }
  }
  const ub = window.self !== window.top,
    vb = ["click", "mousedown", "mouseup"];
  function wb(a) {
    ub &&
      window.requestAnimationFrame(() => {
        try {
          var b = JSON.stringify({
            module: "REVJET_Creative",
            method: "dispatchEvent",
            messageId: y(),
            properties: { eventObject: Ia(a) },
          });
          let c = window;
          do (c = c.parent), c.postMessage(b, "*");
          while (c !== window.top);
        } catch (c) {}
      });
  }
  function xb() {
    ub && vb.forEach((a) => window.addEventListener(a, wb, !1));
  }
  function yb(a, b) {
    let c;
    if (a.touches && 1 <= a.touches.length)
      (c = a.touches[0].pageX), (a = a.touches[0].pageY);
    else if (
      (null !== a.pageX && "undefined" !== typeof a.pageX) ||
      null == a.clientX
    )
      (c = a.pageX), (a = a.pageY);
    else {
      const d = window.document.documentElement,
        e = window.document.body;
      c =
        a.clientX +
        ((d && d.scrollLeft) || (e && e.scrollLeft) || 0) -
        ((d && d.clientLeft) || (e && e.clientLeft) || 0);
      a =
        a.clientY +
        ((d && d.scrollTop) || (e && e.scrollTop) || 0) -
        ((d && d.clientTop) || (e && e.clientTop) || 0);
    }
    b && ((b = b.getBoundingClientRect()), (c += b.left), (a += b.top));
    return { cx: c, cy: a };
  }
  function zb(a) {
    let b = -1,
      c = -1;
    var d = window.document;
    d =
      window.innerWidth || d.documentElement.clientWidth || d.body.clientWidth;
    var e = window.document;
    e =
      window.innerHeight ||
      e.documentElement.clientHeight ||
      e.body.clientHeight;
    0 != d && (b = Math.floor((100 * a.cx) / d));
    0 != e && (c = Math.floor((100 * a.cy) / e));
    isNaN(b) && (b = -1);
    isNaN(c) && (c = -1);
    return { x: b, y: c };
  }
  function Ab(a) {
    var b = window.HeatmapElement;
    let c = -1,
      d = -1;
    var e = window.document.body,
      f = window.document.documentElement,
      g =
        "undefined" !== typeof window.pageXOffset
          ? window.pageXOffset
          : (f || e.parentNode || e).scrollLeft;
    f =
      "undefined" !== typeof window.pageYOffset
        ? window.pageYOffset
        : (f || e.parentNode || e).scrollTop;
    e = b.getBoundingClientRect();
    g = e.left + g;
    f = e.top + f;
    const h = "width" in e ? e.width : b.offsetWidth;
    b = "height" in e ? e.height : b.offsetHeight;
    a.cx >= g && (c = Math.floor((100 * (a.cx - g)) / h));
    a.cy >= f && (d = Math.floor((100 * (a.cy - f)) / b));
    isNaN(c) && (c = -1);
    isNaN(d) && (d = -1);
    return { x: c, y: d };
  }
  const Bb = {
      mf: "unknown",
      Ve: "ready",
      Zd: "before_personalization",
      Gd: "after_personalization",
      Xd: "before_depersonalization",
      Fd: "after_depersonalization",
      fe: "click",
      Wd: "auxclick",
      ee: "change",
      df: "swipe",
      Ke: "mouse_down",
      Oe: "mouse_over",
      Ne: "mouse_out",
      Le: "mouse_enter",
      Me: "mouse_leave",
      Ue: "orientation_change",
      he: "close",
      oe: "expand",
      Xe: "reload",
      We: "refresh",
      pe: "expand_start",
      ie: "collapse",
      $d: "before_show",
      $e: "show",
      Ce: "hide",
      Ie: "load",
      Te: "open_link",
      qe: "fire_pixel",
      kf: "transition_in",
      lf: "transition_out",
      Je: "max_action_count",
      Ff: "viewable",
      Se: "not_viewable",
      ge: "click_heatmap",
      Jd: "animation_start",
      Kd: "animation_stop",
      Hd: "animation_end",
      Id: "animation_iteration",
      Bf: "video_started",
      rf: "video_first_quartile",
      tf: "video_midpoint",
      Df: "video_third_quartile",
      qf: "video_complete",
      uf: "video_mute",
      Ef: "video_unmute",
      wf: "video_play",
      vf: "video_pause",
      Cf: "video_stop",
      yf: "video_resume",
      xf: "video_replay",
      zf: "video_seek",
      Af: "video_skip",
      sf: "video_fullscreen",
      Sd: "audio_started",
      Nd: "audio_first_quartile",
      Od: "audio_midpoint",
      Ud: "audio_third_quartile",
      Md: "audio_complete",
      Pd: "audio_mute",
      Vd: "audio_unmute",
      Rd: "audio_play",
      Qd: "audio_pause",
      Td: "audio_stop",
      Re: "mraid_viewable",
      Qe: "mraid_ready",
      Pe: "mraid_loaded",
      De: "hype_document_load",
      Ee: "hype_scene_load",
      Fe: "hype_scene_unload",
      Ge: "hype_timeline_complete",
      bf: "slider_next",
      cf: "slider_prev",
      af: "slider_card_view",
      He: "javascript_error",
      Ld: "api_call",
      de: "bodymovin_start",
      ae: "bodymovin_complete",
      be: "bodymovin_loop_complete",
      ce: "bodymovin_segment_start",
      me: "custom_event",
      ne: "data_change",
      pf: "value_change",
      ke: "consumer_data",
      je: "complete",
      Yd: "before_form_load",
      se: "form_load",
      te: "form_validated",
      nf: "validated",
      Rf: "vpaid_time_update",
      Mf: "vpaid_resize_ad",
      Qf: "vpaid_stop_ad",
      Lf: "vpaid_pause_ad",
      Nf: "vpaid_resume_ad",
      Jf: "vpaid_expand_ad",
      If: "vpaid_collapse_ad",
      Of: "vpaid_skip_ad",
      Hf: "vpaid_ad_volume_change",
      Pf: "vpaid_start_ad",
      Kf: "vpaid_init_ad",
      Ze: "safeframe_status_update",
      Gf: "viewable_event",
      Ye: "resource_load_complete",
      le: "countdown_complete",
      we: "gallery_slide_next",
      ye: "gallery_slide_prev",
      Ae: "gallery_swipe_next",
      Be: "gallery_swipe_prev",
      ue: "gallery_bullet_click",
      ve: "gallery_slide_click",
      ze: "gallery_slide_video_play",
      xe: "gallery_slide_panel_view",
      jf: "touchpoint_started",
      hf: "touchpoint_open_clicked",
      ef: "touchpoint_closed",
      ff: "touchpoint_close_clicked",
      gf: "touchpoint_cta_clicked",
    },
    Cb =
      "click auxclick change swipe mouse_down mouse_over mouse_out mouse_enter mouse_leave orientation_change slider_next slider_prev gallery_swipe_next gallery_swipe_prev gallery_bullet_click gallery_slide_click touchpoint_open_clicked touchpoint_close_clicked touchpoint_cta_clicked".split(
        " "
      ),
    Db =
      "animation_start animation_stop animation_end animation_iteration hype_scene_load hype_scene_unload hype_timeline_complete bodymovin_start bodymovin_complete bodymovin_loop_complete bodymovin_segment_start".split(
        " "
      ); /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  function Eb(a, b) {
    a.h = Object.assign({}, a.h, { button: b });
  }
  function E(a, b) {
    b && b.Db() && (a.h = Object.assign({}, a.h, { userInitiated: !0 }));
    return a;
  }
  class F {
    constructor(a, b) {
      this.h = { type: a, propagationStopped: !1 };
      if (b) {
        var c = Object.keys(b);
        for (const d of c) (c = b[d]), void 0 !== c && (this.h[d] = c);
      }
      "userInitiated" in this.h ||
        (this.h.userInitiated = -1 !== Cb.indexOf(a));
      b = document.querySelectorAll('meta[name^="innervate:creative"]');
      a = {};
      for (const d of b)
        (b = d.getAttribute("name")),
          (a[b.replace("innervate:creative:", "")] = d.getAttribute("content"));
      this.h.creative = a;
      this.h.time = new Date().getTime();
    }
    getType() {
      return this.A("type");
    }
    G() {
      return this.A("widgetId");
    }
    bc() {
      return this.A("role");
    }
    ob(a) {
      this.h = Object.assign({}, this.h, { roleId: a });
    }
    yb() {
      return this.A("roleId");
    }
    Db() {
      return !!this.A("userInitiated");
    }
    stopPropagation() {
      this.h = Object.assign({}, this.h, { propagationStopped: !0 });
    }
    Bb() {
      return this.A("propagationStopped");
    }
    P() {
      return this.h;
    }
    A(a) {
      return this.h[a];
    }
    g() {
      return !0;
    }
  }
  F.prototype.getProperty = F.prototype.A;
  F.prototype.getProperties = F.prototype.P;
  F.prototype.isPropagationStopped = F.prototype.Bb;
  F.prototype.stopPropagation = F.prototype.stopPropagation;
  F.prototype.isUserInitiated = F.prototype.Db;
  F.prototype.getRoleId = F.prototype.yb;
  F.prototype.getRole = F.prototype.bc;
  F.prototype.getWidgetId = F.prototype.G;
  F.prototype.getType = F.prototype.getType;
  class Fb extends F {
    constructor(a, b, c) {
      super("consumer_data", { value: b, fields: c });
      this.i = a;
    }
    gb() {
      return this.i;
    }
    N() {
      return this.A("value");
    }
    Sb() {
      return this.A("fields");
    }
    g() {
      return !0;
    }
  }
  Fb.prototype.getFields = Fb.prototype.Sb;
  Fb.prototype.getValue = Fb.prototype.N;
  Fb.prototype.getDataBinding = Fb.prototype.gb;
  class Gb extends F {
    constructor(a, b, c, d, e, f, g) {
      super("open_link", {
        url: a,
        target: b,
        cx: c,
        cy: d,
        cw: e,
        ch: f,
        bp: g,
      });
    }
    Ab() {
      return this.A("url");
    }
    sd() {
      return this.A("target");
    }
    g() {
      return !0;
    }
  }
  Gb.prototype.getTarget = Gb.prototype.sd;
  Gb.prototype.getUrl = Gb.prototype.Ab;
  const Hb = [
    { name: "2xl", query: "(min-width: 1536px)" },
    { name: "xl", query: "(min-width: 1280px)" },
    { name: "lg", query: "(min-width: 1024px)" },
    { name: "md", query: "(min-width: 768px)" },
    { name: "sm", query: "(min-width: 640px)" },
  ];
  function Ib() {
    let a = -1;
    var b = -1;
    let c = "-1";
    if ("matchMedia" in window) {
      var d = Hb.find((e) => window.matchMedia(e.query).matches);
      d && (c = d.name);
    }
    if ((d = window.document.documentElement))
      (b = d.getBoundingClientRect()), (a = b.width), (b = b.height);
    return { eb: a, ch: b, bb: c };
  }
  let Jb = null;
  function G() {
    Jb || (Jb = new H());
    return Jb;
  }
  function Kb(a, b) {
    "hideBody" in b && a.yc(b.hideBody);
    b.hideMethod && a.Ac(b.hideMethod);
    b.showTimeout && a.Gc(b.showTimeout);
    "deferredRendering" in b && a.vc(b.deferredRendering);
    "disableAnimation" in b && a.wc(b.disableAnimation);
    a.Cc(b.maxAnimationDuration);
    "hideCreative" in b && a.zc(b.hideCreative);
    "canonicalEventURL" in b && a.uc(b.canonicalEventURL);
    "personalizationURL" in b && a.Ec(b.personalizationURL);
    "personalizationURLBody" in b && a.Fc(b.personalizationURLBody);
    "offsetX" in b && (a.X = b.offsetX);
    "offsetY" in b && a.Dc(b.offsetY);
    "isIframeAsset" in b && a.Bc(b.isIframeAsset);
    "width" in b && a.Hc(b.width);
    "height" in b && a.xc(b.height);
  }
  class H {
    constructor() {
      this.g = !1;
      this.i = "visibility";
      this.C = 500;
      this.s = t;
      this.R = ua();
      this.m = this.h = !1;
      this.H =
        this.L =
        this.o =
        this.D =
        this.X =
        this.v =
        this.F =
        this.j =
          null;
    }
    xd() {
      return this.g;
    }
    yc(a) {
      this.g = !!a;
    }
    rd() {
      return this.C;
    }
    Gc(a) {
      this.C = a;
    }
    jd() {
      return this.i;
    }
    Ac(a) {
      this.i = a;
    }
    fd() {
      return this.R;
    }
    vc(a) {
      this.R = !!a;
    }
    vd() {
      return this.h;
    }
    wc(a) {
      this.h = !!a;
    }
    ld() {
      return this.s;
    }
    Cc(a) {
      this.s =
        "infinite" === a || "" === a || 0 === a
          ? t
          : u(a).map((b) => parseInt(b, 10));
    }
    yd() {
      return this.m;
    }
    zc(a) {
      this.m = !!a;
    }
    cd() {
      return this.j;
    }
    uc(a) {
      this.j = a;
    }
    od() {
      return this.F;
    }
    Ec(a) {
      this.F = a;
    }
    pd() {
      return this.v;
    }
    Fc(a) {
      this.v = a;
    }
    Dc(a) {
      this.D = a;
    }
    nd() {
      return this.D;
    }
    Ra() {
      return this.o;
    }
    Bc(a) {
      this.o = a;
    }
    xa() {
      return this.L;
    }
    Hc(a) {
      this.L =
        "number" === typeof a ? a : null != a ? parseInt(a, 10) || null : null;
    }
    ua() {
      return this.H;
    }
    xc(a) {
      this.H =
        "number" === typeof a ? a : null != a ? parseInt(a, 10) || null : null;
    }
  }
  H.prototype.setHeight = H.prototype.xc;
  H.prototype.getHeight = H.prototype.ua;
  H.prototype.setWidth = H.prototype.Hc;
  H.prototype.getWidth = H.prototype.xa;
  H.prototype.setIsIframeAsset = H.prototype.Bc;
  H.prototype.isIframeAsset = H.prototype.Ra;
  H.prototype.getOffsetY = H.prototype.nd;
  H.prototype.setOffsetY = H.prototype.Dc;
  H.prototype.setPersonalizationURLBody = H.prototype.Fc;
  H.prototype.getPersonalizationURLBody = H.prototype.pd;
  H.prototype.setPersonalizationURL = H.prototype.Ec;
  H.prototype.getPersonalizationURL = H.prototype.od;
  H.prototype.setCanonicalEventURL = H.prototype.uc;
  H.prototype.getCanonicalEventURL = H.prototype.cd;
  H.prototype.setHideCreative = H.prototype.zc;
  H.prototype.isHideCreative = H.prototype.yd;
  H.prototype.setMaxAnimationDuration = H.prototype.Cc;
  H.prototype.getMaxAnimationDuration = H.prototype.ld;
  H.prototype.setDisableAnimation = H.prototype.wc;
  H.prototype.isDisableAnimation = H.prototype.vd;
  H.prototype.setDeferredRendering = H.prototype.vc;
  H.prototype.getDeferredRendering = H.prototype.fd;
  H.prototype.setHideMethod = H.prototype.Ac;
  H.prototype.getHideMethod = H.prototype.jd;
  H.prototype.setShowTimeout = H.prototype.Gc;
  H.prototype.getShowTimeout = H.prototype.rd;
  H.prototype.setHideBody = H.prototype.yc;
  H.prototype.isHideBody = H.prototype.xd;
  const Lb = String.prototype.trim
    ? (a) => a.trim()
    : (a) => a.replace(/^[\s\xa0]+|[\s\xa0]+$/g, "");
  const Mb =
      "undefined" !== typeof window.JSON &&
      "function" === typeof window.JSON.parse,
    Nb = "undefined" !== typeof window.postMessage,
    Ob = () => {
      const a = ["hidden", "mozHidden", "msHidden", "webkitHidden"],
        b = [
          "visibilitychange",
          "mozvisibilitychange",
          "msvisibilitychange",
          "webkitvisibilitychange",
        ];
      for (let c = 0; c < a.length; c++)
        if ("undefined" !== typeof window.document[a[c]]) return [a[c], b[c]];
      return null;
    },
    Pb = () => {
      const a = Ob();
      return null !== a ? window.document[a[0]] : !1;
    },
    Qb = () =>
      "undefined" !== typeof window.document.visibilityState
        ? "prerender" === window.document.visibilityState
        : "undefined" !== typeof window.document.webkitVisibilityState
        ? "prerender" === window.document.webkitVisibilityState
        : !1,
    Rb = (a, b) =>
      a.innerWidth || b.documentElement.clientWidth || b.body.clientWidth,
    Sb = (a, b) =>
      a.innerHeight || b.documentElement.clientHeight || b.body.clientHeight;
  let Tb = [];
  const Ub = (a, b, c) => {
      Tb.push({ element: a, bd: b, listener: c, Dd: !1 });
      return Tb.length - 1;
    },
    Vb = (a, b, c) => {
      "undefined" !== typeof a.addEventListener
        ? a.addEventListener(b, c, !1)
        : a.attachEvent("on" + b, c);
    },
    Wb = (a, b, c) => {
      const d = Ub(a, b, c);
      Vb(a, b, c);
      return d;
    },
    Yb = (a, b) => {
      var c = window.document;
      const d = Ub(c, a, b);
      Vb(c, a, (e) => {
        Xb(d);
        b(e);
      });
    },
    Xb = (a) => {
      var b = Tb[a];
      if (b) {
        const c = b.element,
          d = b.bd,
          e = b.listener;
        b = b.Dd;
        "undefined" !== typeof c.removeEventListener
          ? c.removeEventListener(d, e, b)
          : c.detachEvent("on" + d, e);
        Tb[a] = null;
      }
    };
  class Zb {
    constructor(a, b) {
      this.j = a;
      this.s = b;
      this.i = 0.5;
      this.D = [0, 0.25, 0.5, 0.75, 1];
    }
  }
  let $b = -1;
  function ac() {
    if (-1 === $b)
      try {
        $b = bc(window);
      } catch (a) {
        $b = null;
      }
    return $b;
  }
  function bc(a) {
    const b = a.mraid;
    return b && cc(b) ? b : a === window.top ? null : bc(a.parent);
  }
  function cc(a) {
    return ["addEventListener", "getState", "removeEventListener"].every(
      (b) => {
        b = a[b];
        return ("function" === typeof b && "undefined" !== typeof b.call) ||
          (b &&
            ("[object Function]" === Object.prototype.toString.call(b) ||
              ("undefined" !== typeof b.call &&
                "undefined" !== typeof b.propertyIsEnumerable &&
                !b.propertyIsEnumerable("call"))))
          ? !0
          : !1;
      }
    );
  }
  function dc(a) {
    if (a.F || a.v) {
      if (0 !== a.m) {
        const b = a.s;
        if (new Date().getTime() >= a.m + a.j) {
          a.m = 0;
          b(5);
          return;
        }
      }
      window.requestAnimationFrame(() => dc(a));
    }
  }
  function ec(a) {
    return (a = a.o) && a.getState ? a.getState() : null;
  }
  function fc(a) {
    gc(a) &&
      ((a.v = (b) => {
        a.L = b >= 100 * a.i;
        hc(a);
      }),
      ic(a, "exposureChange", a.v));
    a.F = () => jc(a);
    ic(a, "viewableChange", a.F);
    jc(a);
  }
  function ic(a, b, c) {
    (a = a.o) && a.addEventListener && a.addEventListener(b, c);
  }
  function kc(a, b, c) {
    (a = a.o) && a.removeEventListener && a.removeEventListener(b, c);
  }
  function gc(a) {
    a = (a = (a = a.o) && a.getVersion ? a.getVersion() : null)
      ? a.split(".")
      : [];
    return 0 < a.length && 3 <= parseInt(a[0], 10);
  }
  function jc(a) {
    var b = (b = a.o) && b.isViewable ? b.isViewable() : !1;
    a.H = b;
    hc(a);
  }
  function hc(a) {
    a.H || !0 === a.L ? 0 === a.m && (a.m = new Date().getTime()) : (a.m = 0);
  }
  class lc extends Zb {
    constructor(a, b) {
      super(a, b);
      this.m = 0;
      this.H = !1;
      this.L = null;
      this.o = ac();
      this.v = this.F = this.C = null;
    }
    h() {
      this.o &&
        (window.requestAnimationFrame(() => dc(this)),
        "loading" === ec(this)
          ? ((this.C = () => fc(this)), ic(this, "ready", this.C))
          : fc(this));
    }
    g() {
      const a = this.C,
        b = this.F,
        c = this.v;
      a && (kc(this, "ready", a), (this.C = null));
      b && (kc(this, "viewableChange", b), (this.F = null));
      c && (kc(this, "exposureChange", c), (this.v = null));
    }
  }
  let mc = null;
  const nc = ["addEventListener", "getState", "removeEventListener"];
  function oc() {
    let a = window;
    for (; a; ) {
      try {
        if (a.mraid && qc(a)) return new ia(a);
      } catch (b) {}
      a = a === a.parent ? null : a.parent;
    }
    return t;
  }
  function rc() {
    if (!mc)
      if (window === window.top) mc = new sc();
      else {
        const a = oc(),
          b = a.flatMap((c) => u(c.RevJetMraidController));
        mc = ca(b, () => new sc());
        b.I() && a.forEach((c) => (c.RevJetMraidController = mc));
      }
    return mc;
  }
  function qc(a) {
    return nc.every((b) => la(a.mraid[b]));
  }
  function tc(a) {
    G();
    return a.m;
  }
  function uc(a, b) {
    a.j
      .filter((c) => c.type === b)
      .forEach((c) => {
        c.listener(a);
      });
  }
  function vc(a) {
    uc(a, 1);
    a.i.forEach((b) => {
      b.mraid.useCustomClose(a.s);
      "div" !== wc().deliveryWrapper &&
        b.mraid.setOrientationProperties &&
        b.mraid.setOrientationProperties({ allowOrientationChange: !1 });
      b.mraid.addEventListener("stateChange", () => xc(a));
    });
  }
  function yc(a) {
    uc(a, 2);
    a.i.forEach((b) => {
      "loading" === b.mraid.getState()
        ? b.mraid.addEventListener("ready", () => vc(a))
        : vc(a);
    });
    a.h ||
      ((a.h = new lc(10, () => {
        uc(a, 0);
        a.h && (a.h.g(), (a.h = null));
      })),
      (a.h.i = 0.01),
      a.h.h());
  }
  function xc(a) {
    const b = da(
      a.i.map((c) => c.mraid.getState()),
      ""
    );
    "expanded" === b
      ? uc(a, 3)
      : "default" === b
      ? uc(a, 4)
      : "hidden" === b && 5 !== a.g && zc(a);
  }
  function zc(a) {
    uc(a, 5);
    a.g = 5;
  }
  class sc {
    constructor() {
      const a = oc();
      this.i = a;
      this.m = p(a);
      this.g = 1;
      this.j = [];
      this.s = !0;
      this.h = null;
    }
    addEventListener(a, b) {
      this.j = this.j.concat({ type: a, listener: b });
    }
    removeEventListener(a, b) {
      this.j = this.j.filter((c) => c.type !== a && c.listener !== b);
    }
    expand(a, b) {
      this.i.forEach((c) => {
        c.mraid.setExpandProperties({
          width: a,
          height: b,
          useCustomClose: this.s,
        });
        "div" !== wc().deliveryWrapper &&
          c.mraid.setOrientationProperties &&
          c.mraid.setOrientationProperties({
            allowOrientationChange: !1,
            forceOrientation: a > b ? "landscape" : "portrait",
          });
        c.mraid.expand();
      });
    }
    collapse() {
      this.i.forEach((a) => a.mraid.close());
    }
  }
  function Ac(a) {
    let b;
    const c = null == (b = window.frameElement) ? void 0 : b.getAttribute(a);
    if (c) return c;
    let d;
    return null ==
      (d =
        document.querySelector("div#ad_body") ||
        document.querySelector("div#content_body"))
      ? void 0
      : d.getAttribute(a);
  }
  function Bc(a) {
    let b;
    return null ==
      (b = document.querySelector(`meta[name="innervate:tag:${a}"]`))
      ? void 0
      : b.getAttribute("content");
  }
  function Cc() {
    return (
      "revjet-expanded" === window.name ||
      "revjet-expanded" === Bc("frame-type")
    );
  }
  function Dc() {
    const a = Bc("frame-type");
    return (
      "revjet-expanded" === window.name ||
      "revjet-expanded" === a ||
      "revjet-multi-iframe" === window.name ||
      "revjet-multi-iframe" === a
    );
  }
  function wc() {
    try {
      const a =
        Ac("data-revjet-options") ||
        Ac("data-options") ||
        Bc("options") ||
        "{}";
      return JSON.parse(a);
    } catch (a) {}
    return {};
  }
  function Ec() {
    try {
      let a;
      const b =
        (null ==
        (a = document.querySelector('meta[name="innervate:slot:options"]'))
          ? void 0
          : a.getAttribute("content")) || "{}";
      return JSON.parse(b);
    } catch (a) {}
    return {};
  }
  function Fc() {
    try {
      let a;
      const b =
        (null == (a = window.frameElement)
          ? void 0
          : a.getAttribute("data-revjet-personalization")) ||
        Bc("personalization");
      if (null != b) return JSON.parse(b);
    } catch (a) {}
    return null;
  }
  function Gc() {
    var a = wc();
    if ("in_app" in a) return !!a.in_app;
    a = navigator.userAgent;
    if (-1 !== a.indexOf("CriOS")) return !1;
    if (p(rc().i)) return !0;
    if (-1 !== a.indexOf("Android")) {
      if (-1 !== a.indexOf("; wv") || -1 !== a.indexOf("Version/")) return !0;
    } else
      return /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(
        navigator.userAgent
      );
    return !1;
  }
  const Hc = /(%24%24CX%24%24)|(\$\$CX\$\$)/gi,
    Ic = /(%24%24CY%24%24)|(\$\$CY\$\$)/gi,
    Jc = /(%24%24ELT-ID%24%24)|(\$\$ELT-ID\$\$)/gi,
    Kc = /(%24%24ELT-IDS%24%24)|(\$\$ELT-IDS\$\$)/gi;
  let Lc = null;
  function Mc() {
    Lc || (Lc = new Nc());
    return Lc;
  }
  function Oc(a, b, c) {
    Xa() ||
      -1 !== Wa.indexOf("iPad") ||
      -1 !== Wa.indexOf("iPod") ||
      B(
        b,
        "mousedown",
        (d) => {
          a.i = !0;
          a.j && a.i ? ((a.j = !1), (a.i = !1)) : Pc(a, d, c);
        },
        !1
      );
    wa() &&
      B(
        b,
        "touchstart",
        (d) => {
          a.j = !0;
          a.j && a.i ? ((a.j = !1), (a.i = !1)) : Pc(a, d, c);
        },
        !1
      );
  }
  function Qc(a, b) {
    a.v = b;
  }
  function Rc(a, b, c, d, e) {
    var f = b,
      g = -1 !== b.search(Hc);
    b = Ec();
    var h = a.h;
    if (h) {
      h = "HeatmapElement" in window ? Ab(h) : zb(h);
      var k = G(),
        l = k.X;
      k = k.D;
      null != l && (h.x += l);
      null != k && (h.y += k);
      f = f.replace(Hc, String(h.x));
      f = f.replace(Ic, String(h.y));
    }
    l = a.R;
    h = a.D;
    p(l) && (f = f.replace(Kc, encodeURIComponent(l.get())));
    c = c ? c : p(a.s) ? a.s.get() : void 0;
    p(h)
      ? ((c = h.get() + (c ? `. ${c}` : "")),
        (f = f.replace(Jc, encodeURIComponent(c))))
      : c && (f = f.replace(Jc, encodeURIComponent(c)));
    if (g) {
      const n = f.split("&");
      f = n.pop();
      g = (q) => (v) => {
        n.push(q + "=" + encodeURIComponent(v));
      };
      if ((c = a.g))
        g("_cw")(String(c.eb)), g("_ch")(String(c.ch)), g("_bp")(String(c.bb));
      null != a.m && g("_btn")(String(a.m));
      fa(a.F, () => u(d)).forEach(g("_sku"));
      a.H.forEach(g("_sku_pos_card"));
      a.o.forEach(g("_card_num"));
      fa(a.C, () => u(e)).forEach(g("_sku_pos"));
      a.L.forEach(g("_slider_celt"));
      b.slot_role && g("_parent_celt")(b.slot_role);
      b.slot_role_id && g("_parent_celtid")(b.slot_role_id);
      n.push(f);
      f = n.join("&");
    }
    return f;
  }
  function Pc(a, b, c) {
    let d = t;
    const e = b.target;
    a.h = yb(b, c);
    a.g = Ib();
    a.m = b.button;
    if (e) {
      c = u(Ta(c || e, "[id][data-revjet-role][data-revjet-role-id]"));
      d = c.map((l) => l.id);
      a.R = c.map((l) => l.getAttribute("data-revjet-role-id"));
      a.D = fa(
        c.flatMap((l) => u(l.getAttribute("data-revjet-role"))),
        () => u(e.id)
      );
      const f = c.filter(
          (l) => "html5" === l.getAttribute("data-element-type")
        ),
        g = f.flatMap(() =>
          u(
            Ta(e, '[data-revjet-element-type="block"]') ||
              Ta(e, "[data-revjet-each]")
          )
        );
      a.F = g.flatMap((l) => u(l.getAttribute("data-revjet-sku-id")));
      a.C = g.flatMap((l) => u(l.getAttribute("data-revjet-sku-pos")));
      a.o = f.flatMap(() => Sc(e, "data-revjet-card-number"));
      a.H = f.flatMap(() => Sc(e, "data-revjet-sku-pos-card"));
      const h = (l) =>
        l
          .flatMap(() =>
            u(Ta(e, "[data-revjet-role]:not([data-revjet-role-id])"))
          )
          .flatMap((n) => u(n.getAttribute("data-revjet-role")));
      a.L = h(a.o);
      a.s = h(f);
      const k = g.flatMap(() => Sc(e, "data-revjet-click-url"));
      c.flatMap((l) => u(Ta(l, "a"))).forEach((l) => {
        l.getAttribute("data-revjet-original-href") ||
          l.setAttribute("data-revjet-original-href", l.getAttribute("href"));
        fa(k, () => u(l.getAttribute("data-revjet-original-href")))
          .map((n) => Rc(a, n, r(a.s)))
          .forEach((n) => {
            l.setAttribute("href", n);
            l.href = n;
          });
      });
    }
    a.v && a.v(p(d) ? d.get() : e ? e.id : null, b);
  }
  function Sc(a, b) {
    return u(Ta(a, `[${b}]`)).flatMap((c) => u(c.getAttribute(b)));
  }
  class Nc {
    constructor() {
      this.g = this.h = null;
      this.s = this.H = this.o = this.L = this.C = this.F = this.R = this.D = t;
      this.v = null;
      this.i = this.j = !1;
      this.m = null;
    }
  }
  class I extends F {
    constructor(a, b, c, d, e) {
      super("javascript_error", {
        message: a,
        errorCode: b,
        filename: c,
        lineno: d,
        colno: e,
      });
    }
    Xb() {
      return this.A("message");
    }
    Rb() {
      return this.A("errorCode");
    }
    Tb() {
      return this.A("filename");
    }
    Vb() {
      return this.A("lineno");
    }
    Ob() {
      return this.A("colno");
    }
    g() {
      return !0;
    }
  }
  I.prototype.getColno = I.prototype.Ob;
  I.prototype.getLineno = I.prototype.Vb;
  I.prototype.getFilename = I.prototype.Tb;
  I.prototype.getErrorCode = I.prototype.Rb;
  I.prototype.getMessage = I.prototype.Xb;
  class Tc extends F {
    constructor(a, b) {
      super("slider_card_view", { cardNumber: a });
      this.i = b;
    }
    wb() {
      return this.A("cardNumber");
    }
    dd() {
      return this.i;
    }
    g(a) {
      return a.cardNumber === this.wb();
    }
  }
  Tc.prototype.getContainerElement = Tc.prototype.dd;
  Tc.prototype.getCardNumber = Tc.prototype.wb;
  function Uc(a) {
    var b = a.type;
    "URL" === b ? (b = "image") : "HTML" === b && (b = "html");
    const c = new Vc();
    c.j = b;
    b = a.url;
    null != b && "" !== b && "null" !== b && (c.W = a.url);
    if ((b = a.code)) c.o = b;
    (b = a.roleId) && c.ob(b);
    if ((a = a.role)) c.D = a;
    return c;
  }
  function Wc(a, b, c) {
    let d = b ? b : a.W;
    if (d) {
      if (-1 !== d.indexOf("/track/") || -1 !== d.indexOf("/interaction/"))
        a.s && ((d += Ba(d)), (d += "__elementID=" + encodeURIComponent(a.s))),
          (d += Ba(d)),
          (d += "__stamp=" + new Date().getTime());
      a.h = !0;
      b = () => {
        let e;
        try {
          e = new window.parent.Image(1, 1);
        } catch (f) {
          e = new Image(1, 1);
        }
        e.onload = a.m.bind(a);
        e.onerror = a.m.bind(a);
        e.src = d;
      };
      null != c && 0 < c ? setTimeout(b, c) : b();
    }
  }
  class Vc {
    constructor() {
      this.j = "image";
      this.D = this.s = this.o = this.W = null;
      this.i = this.h = !1;
      this.g = [];
    }
    aa() {
      return this.j;
    }
    ob(a) {
      this.s = a;
    }
    yb() {
      return this.s;
    }
    bc() {
      return this.D;
    }
    Y(a, b) {
      if (!this.h)
        switch (this.j) {
          case "image":
            Wc(this, a, b);
            break;
          case "html":
            (this.h = !0),
              (a = document.createElement("iframe")),
              a.setAttribute("width", "1"),
              a.setAttribute("height", "1"),
              a.setAttribute("scrolling", "no"),
              a.setAttribute("frameborder", "0"),
              a.setAttribute("allowtransparency", "true"),
              (a.style.cssText =
                "visibility:hidden;position:absolute;left:-9999px;top:-9999px;width:1px;height:1px;"),
              (a.onload = this.m.bind(this)),
              (b = document.body || document.documentElement),
              a.setAttribute(
                "srcdoc",
                `<html><head></head><body>${this.o}</body></html>`
              ),
              b.appendChild(a);
        }
    }
    m(a) {
      this.i = !0;
      for (let b = 0; b < this.g.length; b++) this.g[b].call(this, a);
    }
  }
  function Xc(a, b) {
    const c = new Yc();
    c.h = a.type;
    c.i = a.id;
    b.forEach((d) => {
      c.g.push(d);
    });
    return c;
  }
  class Yc {
    constructor() {
      this.h = "unknown";
      this.g = [];
      this.i = null;
    }
  }
  let Zc = null;
  function $c() {
    Zc || (Zc = new ad());
    return Zc;
  }
  function bd(a) {
    return a.g
      .reduce((b, c) => b.concat(c.g), [])
      .filter((b) => "image" === b.aa())
      .map((b) =>
        (b = b.W) && -1 !== b.indexOf("?")
          ? b
              .substring(b.indexOf("?") + 1)
              .split("&")
              .map((c) => c.split("="))
              .reduce((c, d) => {
                c[d[0]] = d[1];
                return c;
              }, {})
          : {}
      )
      .reduce((b, c) => Object.assign({}, b, c), {});
  }
  class ad {
    constructor() {
      this.g = [];
    }
    setConfiguration(a) {
      this.g = (a || []).map((b) => {
        const c = (b.pixels || []).map((d) => Uc(d));
        return Xc(b, c);
      });
      this.g.forEach((b) =>
        b.g.filter((c) => "image" === c.aa()).forEach((c) => Sa(c.W))
      );
    }
    ad(a) {
      this.g
        .filter((b) => b.h === a)
        .map((b) => b.g)
        .reduce((b, c) => b.concat(c), [])
        .forEach((b) => b.Y());
    }
    Y(a) {
      const b = G().j,
        c = bd(this),
        d = [];
      for (const g of a) {
        const h = g.event_code;
        var e = g.event_type;
        a = g.additional_params;
        var f =
          "canonical" === e
            ? null != b
              ? b.replace("__PIXEL__", h)
              : g.url
            : g.url;
        g.passParams &&
          "canonical" !== e &&
          (f = ["__ads", "__adt", "__ade", "vid"].reduce((k, l) => {
            const n = c[l];
            return null != n ? `${k}&${l}=${n}` : k;
          }, f));
        a && (f = `${f}&${a}`);
        e =
          "canonical" === e && null != h && "" !== h
            ? this.g
                .filter((k) => String(k.i) === String(h))
                .reduce((k, l) => k.concat(l.g), [])
            : [];
        if (0 < e.length)
          for (const k of e)
            (f = k.W),
              a && (f = `${f}&${a}`),
              d.push(Uc(Object.assign({}, g, { url: f })));
        else d.push(Uc(Object.assign({}, g, { url: f })));
      }
      for (const g of d) g.Y();
    }
  }
  ad.prototype.dispatchTrackingEvent = ad.prototype.ad;
  ad.prototype.setConfiguration = ad.prototype.setConfiguration;
  let cd = null;
  const dd =
      "video_started video_first_quartile video_midpoint video_third_quartile video_complete video_play video_pause audio_started audio_first_quartile audio_midpoint audio_third_quartile audio_complete audio_play audio_pause".split(
        " "
      ),
    ed = [
      "open_link",
      "click_heatmap",
      "viewable_event",
      "resource_load_complete",
    ];
  function fd() {
    cd || (cd = new gd());
    return cd;
  }
  function hd(a) {
    id(a);
    const b = new hb(1e4, () => {
      id(a);
      a.s = !0;
    });
    b.ga = !1;
    b.start();
  }
  function jd(a, b) {
    let c;
    const d = a.W;
    var e = a.aa();
    if (d && "image" === e) {
      const f = [];
      e = b.wb();
      null != e &&
        (f.push("_card_num=" + encodeURIComponent(String(e))),
        (b = b.i),
        null != b &&
          (b = b.querySelector(`[data-revjet-card-number="${e}"]`)) &&
          A(b, "[data-revjet-sku-id]")
            .map((g) => g.getAttribute("data-revjet-sku-id"))
            .filter((g) => "" !== g)
            .forEach((g) => f.push("_sku=" + encodeURIComponent(g))));
      0 < f.length && (c = d + Ba(d) + f.join("&"));
    }
    kd(a, c);
  }
  function kd(a, b, c) {
    a.g = [];
    a.h = !1;
    a.i = !1;
    a.Y(b, c);
  }
  function ld(a, b) {
    const c = b.G() || "None",
      d = b.getType();
    if (-1 !== dd.indexOf(d))
      if (c in a.h) {
        const e = a.h[c];
        if (-1 === e.indexOf(d)) a.h[c] = e.concat(d);
        else return;
      } else a.h[c] = [d];
    if (-1 !== ed.indexOf(d)) {
      for (const e of a.g) e(b);
      va("trackingEvent", y(), b.P());
    }
    $c()
      .g.filter((e) => e.h === d)
      .reduce((e, f) => e.concat(f.g), [])
      .forEach((e) => {
        e.ob(b.yb());
        if ("click_heatmap" === d) {
          if (!(20 <= a.j)) {
            var f,
              g = e.W,
              h = e.aa();
            g &&
              "image" === h &&
              (f = Rc(
                Mc(),
                [
                  g,
                  Ba(g),
                  "_cx=$$CX$$&_cy=$$CY$$&_celt=$$ELT-ID$$&_celtid=$$ELT-IDS$$",
                ].join("")
              ));
            a.j++;
            kd(e, f);
          }
        } else if ("open_link" === d)
          (g = e.W),
            (f = e.aa()),
            g &&
              "image" === f &&
              (h =
                -1 !== g.indexOf("revjet.com/track") ||
                -1 !== g.indexOf("showserver.us/track")
                  ? Rc(Mc(), g)
                  : g),
            kd(e, h, b.A("pixelDelay"));
        else if ("javascript_error" === d) {
          if (!a.s) {
            g = "";
            (f = b.Xb()) && (g += f);
            (f = b.Tb()) && (g += " at " + f);
            if ((f = b.Vb()) || 0 === f) g += ":" + f;
            if ((f = b.Ob()) || 0 === f) g += ":" + f;
            "" !== g && md(a, e, b.Rb(), g);
          }
        } else if ("slider_card_view" === d) jd(e, b);
        else if ("consumer_data" === d) {
          f = e.W;
          h = e.aa();
          if (f && "image" === h) {
            h = [];
            const k = b.Sb();
            k && h.push("fields=" + encodeURIComponent(JSON.stringify(k)));
            0 < h.length && (g = f + Ba(f) + h.join("&"));
          }
          kd(e, g);
        } else kd(e);
      });
  }
  function md(a, b, c, d) {
    a = a.i;
    const e = a.findIndex((f) => f.nc === b);
    -1 !== e
      ? a[e].Lb.push({ count: 1, errorCode: c, message: d })
      : a.push({ nc: b, Lb: [{ count: 1, errorCode: c, message: d }] });
  }
  function id(a) {
    a.i.forEach((b) => {
      const c = b.nc;
      let d;
      const e = c.W,
        f = c.aa();
      e &&
        "image" === f &&
        ((b = b.Lb.reduce((g, h) => {
          const k = g.findIndex(
            (l) => l.message === h.message && l.errorCode === h.errorCode
          );
          if (-1 === k) return g.concat(h);
          g[k].count += 1;
          return g;
        }, [])),
        (d =
          e +
          Ba(e) +
          b
            .map(
              (g, h) =>
                `_err_code_${h}=${g.errorCode}&` +
                `_err_count_${h}=${g.count}&` +
                `_err_msg_${h}=${encodeURIComponent(g.message)}`
            )
            .join("&")));
      kd(c, d);
    });
    a.i = [];
  }
  class gd {
    constructor() {
      this.i = [];
      this.j = 0;
      this.s = !1;
      this.h = {};
      this.g = [];
      const a = new hb(5e3, () => hd(this));
      a.ga = !1;
      a.start();
    }
    addEventListener(a) {
      this.g = this.g.concat(a);
    }
    removeEventListener(a) {
      this.g = this.g.filter((b) => b !== a);
    }
  }
  const nd = {};
  function od(a) {
    if (a in nd) return nd[a];
    nd[a] = new pd(a);
    return nd[a];
  }
  function J(a, b, ...c) {
    a.log(1, b, ...c);
  }
  class pd {
    constructor(a) {
      this.g = a;
      this.h = ta() ? 10 : 0;
    }
    $() {
      return this.g;
    }
    log(a, b, ...c) {
      this.h >= a &&
        ((a =
          4 === a
            ? console.error
            : 3 === a
            ? console.warn
            : 2 === a
            ? console.info
            : console.log),
        window.name
          ? a(`[${window.name}] [${this.g}]:`, b, ...c)
          : a(`[${this.g}]:`, b, ...c));
    }
    error(a, ...b) {
      this.log(4, a, ...b);
    }
    info(a, ...b) {
      this.log(2, a, ...b);
    }
  }
  class qd extends F {
    constructor(a) {
      super("mouse_over", { duration: a });
    }
    getDuration() {
      return this.A("duration");
    }
    g(a) {
      return a.duration == this.getDuration();
    }
  }
  qd.prototype.getDuration = qd.prototype.getDuration;
  function rd(a, b) {
    a.D = b(a.D);
  }
  function sd(a, b) {
    rd(a, (c) => c.filter((d) => "viewable" !== d.type || d.jb !== b));
  }
  class td {
    constructor() {
      this.m = null;
      this.D = [];
    }
    listen(a, b) {
      rd(this, (c) => c.concat({ type: a, jb: b }));
    }
    listenOnce(a, b) {
      let c = !1;
      const d = (...e) => {
        c || ((c = !0), b(...e));
      };
      rd(this, (e) => e.concat({ type: a, jb: d }));
    }
    dispatchEvent(a) {
      !this.D.filter((b) => b.type === a.getType()).reduce((b, c) => {
        try {
          c.jb(a);
        } catch (d) {
          console.error &&
            console.error(
              `An error occurred inside '${c.type}' event listener`,
              d
            );
        }
        return b || a.Bb();
      }, !1) &&
        this.m &&
        this.m.dispatchEvent(a);
    }
    da(a) {
      const b = this;
      return m(function* () {
        const c = b.D.filter((e) => e.type === a.getType());
        let d = !1;
        for (const e of c) {
          try {
            yield e.jb(a);
          } catch (f) {
            console.error &&
              console.error(
                `An error occurred inside '${e.type}' event listener`,
                f
              );
          }
          d = d || a.Bb();
        }
        if (!d && b.m) return b.m.da(a);
      });
    }
  }
  function ud(a) {
    -1 != a.h && (window.clearTimeout(a.h), (a.h = -1));
  }
  class vd extends td {
    constructor(a, b) {
      super();
      this.g = b;
      this.i = this;
      this.h = -1;
      B(
        a,
        "mouseover",
        (c) => {
          this.g
            ? (ud(this),
              (this.h = window.setTimeout(this.j.bind(this, c), this.g)))
            : (c.stopPropagation(), this.i.dispatchEvent(new qd(this.g)));
        },
        !1
      );
      b &&
        B(
          a,
          "mouseout",
          () => {
            ud(this);
          },
          !1
        );
    }
    j() {
      ud(this);
      this.i.dispatchEvent(new qd(this.g));
    }
  }
  class wd extends F {
    constructor(a) {
      super("orientation_change", { orientation: a });
    }
    Zb() {
      return this.A("orientation");
    }
    g(a) {
      return a.orientation === this.Zb();
    }
  }
  wd.prototype.getOrientation = wd.prototype.Zb;
  function xd(a) {
    const b =
      (window.innerWidth ||
        window.document.documentElement.clientWidth ||
        window.document.body.clientWidth) >
      (window.innerHeight ||
        window.document.documentElement.clientHeight ||
        window.document.body.clientHeight)
        ? "landscape"
        : "portrait";
    ("any" !== a.s && a.s !== b) || a.i.dispatchEvent(new wd(b));
    a.h = !1;
    a.g = !1;
  }
  class yd extends td {
    constructor(a) {
      super();
      this.j = window;
      this.s = a || "any";
      this.h = this.g = !1;
      this.i = this;
      B(this.j, "resize", () => {
        ((this.h = !0), this.g) && xd(this);
      });
      B(this.j, "orientationchange", () => {
        this.g = !0;
        this.h && this.g && xd(this);
      });
    }
  }
  class zd extends F {
    constructor(a) {
      super("swipe", { direction: a });
    }
    Qb() {
      return this.A("direction");
    }
    g(a) {
      return a.direction === this.Qb();
    }
  }
  zd.prototype.getDirection = zd.prototype.Qb;
  function Ad(a) {
    a.h.x = null;
    a.h.y = null;
    a.g.x = null;
    a.g.y = null;
  }
  class Bd extends td {
    constructor(a, b) {
      super();
      this.j = b;
      this.h = { x: null, y: null };
      this.g = { x: null, y: null };
      this.i = this;
      B(a, "touchstart", (c) => {
        1 === c.touches.length
          ? ((this.h.x = c.touches[0].pageX), (this.h.y = c.touches[0].pageY))
          : Ad(this);
        c.preventDefault();
      });
      B(a, "touchmove", (c) => {
        1 === c.touches.length
          ? ((this.g.x = c.touches[0].pageX), (this.g.y = c.touches[0].pageY))
          : Ad(this);
        c.preventDefault();
      });
      B(a, "touchcancel", () => {
        Ad(this);
      });
      B(a, "touchend", (c) => {
        if (
          null != this.h.x &&
          null != this.h.y &&
          null != this.g.x &&
          null != this.g.y
        ) {
          let d = this.h.x < this.g.x ? "left_right" : "right_left";
          if ("any" === this.j || this.j === d)
            this.i.dispatchEvent(new zd(d)), Ad(this);
        }
        c.preventDefault();
      });
    }
  }
  let Cd = -1;
  function Dd() {
    try {
      return Ed(window);
    } catch (a) {}
    return null;
  }
  function Fd() {
    -1 === Cd && (Cd = Dd());
    return -1 !== Cd && !!Cd;
  }
  function Ed(a) {
    const b = a.context;
    return b && b.observeIntersection
      ? b
      : a === window.top
      ? null
      : Ed(a.parent);
  }
  function Gd(a) {
    if (a.o) {
      if (0 !== a.m && !a.v.hidden) {
        const b = a.s;
        if (new Date().getTime() >= a.m + a.j) {
          a.m = 0;
          b(7);
          return;
        }
      }
      window.requestAnimationFrame(() => Gd(a));
    }
  }
  class Hd extends Zb {
    constructor(a, b) {
      super(a, b);
      this.m = 0;
      this.v = -1 !== Cd ? Cd : Dd();
      this.o = null;
    }
    h() {
      this.v &&
        (window.requestAnimationFrame(() => Gd(this)),
        (this.o = (0, this.v.observeIntersection)((a) => {
          a.forEach((b) => {
            const c = b.intersectionRect;
            b = b.boundingClientRect;
            (c.width * c.height) / (b.width * b.height) >= this.i
              ? 0 === this.m && (this.m = new Date().getTime())
              : (this.m = 0);
          });
        })));
    }
    g() {
      this.o && (this.o(), (this.o = null));
      this.m = 0;
    }
  }
  function Id() {
    try {
      const a = window.parent;
      if (
        !0 === a.inDapIF &&
        a.parent === window.top &&
        (a.parent.document || a.parent.document.domain)
      )
        return !0;
    } catch (a) {}
    return !1;
  }
  function Jd() {
    if (Id()) return !0;
    try {
      const a = window.parent;
      if (
        null !== window.frameElement &&
        a === window.top &&
        (a.document || a.document.domain)
      )
        return !0;
    } catch (a) {}
    return !1;
  }
  function Kd(a) {
    if (a.C.parent) {
      var b = window.frameElement;
      if (b) {
        var c = a.C.parent;
        var d = c.document;
        var e = b.getBoundingClientRect(),
          f = d.body;
        var g = d.documentElement;
        g =
          "undefined" !== typeof c.pageXOffset
            ? c.pageXOffset
            : (g || f.parentNode || f).scrollLeft;
        f = d.body;
        var h = d.documentElement;
        h =
          "undefined" !== typeof c.pageYOffset
            ? c.pageYOffset
            : (h || f.parentNode || f).scrollTop;
        var k = e.left,
          l = e.top;
        e = Rb(window, window.document);
        f = Sb(window, window.document);
        g =
          Math.max(0, Math.min(g + Rb(c, d), k + g + e) - Math.max(g, k + g)) *
          Math.max(0, Math.min(h + Sb(c, d), l + h + f) - Math.max(h, l + h));
        c = 100;
        try {
          b: {
            for (k = 1; b.parentNode; ) {
              c: {
                if (b.currentStyle) {
                  var n = "none" === b.currentStyle.display;
                  break c;
                }
                const v = d.defaultView.getComputedStyle(b, null);
                n = null === v || "none" === v.getPropertyValue("display");
              }
              if (n) {
                c = -1;
                break b;
              }
              h = k;
              let q = (l = void 0);
              b.currentStyle
                ? (l =
                    "hidden" === b.currentStyle.visibility
                      ? 0
                      : b.currentStyle.opacity)
                : ((q = d.defaultView.getComputedStyle(b, null)),
                  (l =
                    null === q || "hidden" === q.getPropertyValue("visibility")
                      ? 0
                      : q.getPropertyValue("opacity")));
              l = parseFloat(l);
              k = h * (l || 0 === l ? l : 1);
              b = b.parentNode;
            }
            c = k;
          }
        } catch (q) {}
        d = g >= e * f * a.i;
        d = !Pb() && !Qb() && 0 < c && d;
      } else d = !1;
      d ? 0 === a.m && (a.m = new Date().getTime()) : (a.m = 0);
    }
  }
  function Ld(a) {
    "undefined" !== typeof window.requestAnimationFrame
      ? window.requestAnimationFrame(() => Md(a))
      : window.setTimeout(() => Md(a), 16);
  }
  function Md(a) {
    if (-1 !== a.v && -1 !== a.o) {
      if (0 !== a.m && !Qb() && !Pb()) {
        const b = a.s;
        if (new Date().getTime() >= a.m + a.j) {
          a.m = 0;
          b(3);
          return;
        }
      }
      Ld(a);
    }
  }
  class Nd extends Zb {
    constructor(a, b) {
      super(a, b);
      this.m = 0;
      this.F = this.o = this.v = -1;
      this.C = (this.H = Id()) ? window.parent : window;
    }
    h() {
      var a = this.C;
      this.v = Wb(a.parent, "scroll", () => Kd(this));
      this.o = Wb(a.parent, "resize", () => Kd(this));
      a = Ob();
      null !== a && (this.F = Wb(window.document, a[1], () => Kd(this)));
      Kd(this);
      Ld(this);
    }
    g() {
      const a = this.v,
        b = this.o,
        c = this.F;
      -1 !== a && (Xb(a), (this.v = -1));
      -1 !== b && (Xb(b), (this.o = -1));
      -1 !== c && (Xb(c), (this.F = -1));
    }
  }
  function Od() {
    return "undefined" !== typeof window.IntersectionObserver;
  }
  function Pd(a) {
    if (a.m) {
      if (0 !== a.o && !Qb() && !Pb()) {
        const b = a.s;
        if (new Date().getTime() >= a.o + a.j) {
          a.o = 0;
          b(8);
          return;
        }
      }
      window.requestAnimationFrame(() => Pd(a));
    }
  }
  class Qd extends Zb {
    constructor(a, b) {
      super(a, b);
      this.v = document.body || document.documentElement;
      this.o = 0;
      this.m = null;
    }
    h() {
      (this.m = new window.IntersectionObserver(
        (a) => {
          a.forEach((b) => {
            ("undefined" !== typeof b.isIntersecting
              ? b.isIntersecting
              : 0 < b.intersectionRatio) && b.intersectionRatio >= this.i
              ? 0 === this.o && (this.o = new Date().getTime())
              : (this.o = 0);
          });
        },
        { root: null, rootMargin: "0px", threshold: this.D }
      )),
        window.requestAnimationFrame(() => Pd(this)),
        this.m.observe(this.v);
    }
    g() {
      if (this.m) {
        try {
          "undefined" !== typeof this.m.unobserve && this.m.unobserve(this.v);
        } catch (a) {}
        this.m = null;
      }
      this.o = 0;
    }
  }
  function Rd() {
    return (
      "ontouchstart" in window ||
      !!(
        window.document &&
        document.documentElement &&
        "ontouchstart" in document.documentElement
      ) ||
      !(!window.navigator || !window.navigator.msMaxTouchPoints)
    );
  }
  function Sd(a) {
    let b;
    if (a.touches && 1 <= a.touches.length)
      (b = a.touches[0].pageX), (a = a.touches[0].pageY);
    else if (
      (null !== a.pageX && "undefined" !== typeof a.pageX) ||
      null == a.clientX
    )
      (b = a.pageX), (a = a.pageY);
    else {
      const c = window.document.documentElement,
        d = window.document.body;
      b =
        a.clientX +
        ((c && c.scrollLeft) || (d && d.scrollLeft) || 0) -
        ((c && c.clientLeft) || (d && d.clientLeft) || 0);
      a =
        a.clientY +
        ((c && c.scrollTop) || (d && d.scrollTop) || 0) -
        ((c && c.clientTop) || (d && d.clientTop) || 0);
    }
    return { x: b, y: a };
  }
  class Td extends Zb {
    constructor(a, b) {
      super(a, b);
      this.m = 0;
      this.F = this.C = this.v = -1;
      this.o = null;
    }
    h() {
      this.v = Wb(document, "mouseenter", (a) => {
        this.m = 0;
        this.o = Sd(a);
      });
      this.C = Wb(document, "mousemove", (a) => {
        var b = this.o;
        a = Sd(a);
        if (null === b) (this.m = 0), (this.o = a);
        else {
          b = Math.abs(b.y - a.y) * Math.abs(b.x - a.x);
          a = new Date().getTime();
          var c = this.j;
          const d = this.s;
          0 === this.m
            ? ((c = Rb(window, window.document) * Sb(window, window.document)),
              0 !== c && b >= c * this.i && (this.m = a))
            : a >= this.m + c && ((this.o = null), (this.m = 0), d(6));
        }
      });
      this.F = Wb(document, "mouseleave", () => {
        this.o = null;
        this.m = 0;
      });
    }
    g() {
      this.o = null;
      this.m = 0;
      -1 !== this.v && (Xb(this.v), (this.v = -1));
      -1 !== this.C && (Xb(this.C), (this.C = -1));
      -1 !== this.F && (Xb(this.F), (this.F = -1));
    }
  }
  function Ud(a) {
    a = a || window;
    try {
      if (a.$sf) return a.$sf.ext;
      if (a !== window.top) return Ud(a.parent);
    } catch (b) {}
    return null;
  }
  function Vd(a) {
    var b = a.o;
    if (b) {
      Wd(a, b.inViewPercentage() > 100 * a.i);
      if (
        0 !== a.m &&
        !Qb() &&
        !Pb() &&
        ((b = a.s), new Date().getTime() >= a.m + a.j)
      ) {
        a.m = 0;
        b(4);
        return;
      }
      "undefined" !== typeof window.requestAnimationFrame
        ? window.requestAnimationFrame(() => Vd(a))
        : window.setTimeout(() => Vd(a), 16);
    }
  }
  function Wd(a, b) {
    b ? 0 === a.m && (a.m = new Date().getTime()) : (a.m = 0);
  }
  class Xd extends Zb {
    constructor(a, b) {
      super(a, b);
      this.o = Ud();
      this.m = 0;
    }
    h() {
      "undefined" !== typeof window.requestAnimationFrame
        ? window.requestAnimationFrame(() => Vd(this))
        : window.setTimeout(() => Vd(this), 16);
    }
    g() {
      this.o = null;
      this.m = 0;
    }
  }
  function Yd(a) {
    return (
      !!a &&
      void 0 !== a.omid_message_guid &&
      void 0 !== a.omid_message_method &&
      void 0 !== a.omid_message_version &&
      "string" === typeof a.omid_message_guid &&
      "string" === typeof a.omid_message_method &&
      "string" === typeof a.omid_message_version &&
      (void 0 === a.omid_message_args || void 0 !== a.omid_message_args)
    );
  }
  function Zd(a) {
    return new $d(
      a.omid_message_guid,
      a.omid_message_method,
      a.omid_message_version,
      a.omid_message_args
    );
  }
  function ae(a) {
    const b = {
      omid_message_guid: a.h,
      omid_message_method: a.method,
      omid_message_version: a.version,
    };
    void 0 !== a.g && (b.omid_message_args = a.g);
    return b;
  }
  class $d {
    constructor(a, b, c, d) {
      this.h = a;
      this.method = b;
      this.version = c;
      this.g = d;
    }
  }
  class be {
    constructor(a) {
      this.i = a;
    }
  }
  function ce(...a) {
    de(
      () => {
        throw Error("Could not complete the test successfully - ", ...a);
      },
      () => console.error(...a)
    );
  }
  function de(a, b) {
    "undefined" !== typeof jasmine && jasmine
      ? a()
      : "undefined" !== typeof console && console && console.error && b();
  }
  function ee(a) {
    if (!a) throw Error("functionToExecute must not be truthy.");
  }
  function fe() {
    return /\d+\.\d+\.\d+(-.*)?/.test("1.4.4-dev");
  }
  function ge() {
    const a = ["1", "4", "4"],
      b = ["1", "0", "3"];
    for (let c = 0; 3 > c; c++) {
      const d = parseInt(a[c], 10),
        e = parseInt(b[c], 10);
      if (d > e) break;
      else if (d < e) return !1;
    }
    return !0;
  }
  function he() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (a) => {
      let b = (16 * Math.random()) | 0;
      return "y" === a ? ((b & 3) | 8).toString(16) : b.toString(16);
    });
  }
  function ie() {
    if ("undefined" !== typeof omidGlobal && omidGlobal) return omidGlobal;
    if ("undefined" !== typeof global && global) return global;
    if ("undefined" !== typeof window && window) return window;
    if ("undefined" !== typeof globalThis && globalThis) return globalThis;
    const a = Function("return this")();
    if (a) return a;
    throw Error("Could not determine global object context.");
  }
  let je = null;
  function ke() {
    je || (je = ie());
    return je;
  }
  function le(a) {
    return null != a && "undefined" !== typeof a.top && null != a.top;
  }
  function me(a) {
    if (a === ke()) return !1;
    try {
      if ("undefined" === typeof a.location.hostname) return !0;
    } catch (b) {
      return !0;
    }
    return !1;
  }
  class ne extends be {
    constructor(a) {
      super(a);
      this.handleExportedMessage = ne.prototype.j.bind(this);
    }
    h(a) {
      var b = this.i;
      if (!b)
        throw Error(
          "Message destination must be defined at construction time or when sending the message."
        );
      b.handleExportedMessage(ae(a), this);
    }
    j(a, b) {
      Yd(a) && this.g && this.g(Zd(a), b);
    }
  }
  class oe extends be {
    constructor(a, b = ke()) {
      super(b);
      a.addEventListener("message", (c) => {
        if ("object" === typeof c.data) {
          var d = c.data;
          Yd(d) && c.source && this.g && this.g(Zd(d), c.source);
        }
      });
    }
    h(a) {
      var b = this.i;
      if (!b)
        throw Error(
          "Message destination must be defined at construction time or when sending the message."
        );
      b.postMessage(ae(a), "*");
    }
  }
  function pe(a) {
    try {
      return a.frames ? !!a.frames.omid_v1_present : !1;
    } catch (b) {
      return !1;
    }
  }
  const qe = ["omid", "v1_VerificationServiceCommunication"],
    re = ["omidVerificationProperties", "serviceWindow"];
  function se(a, b) {
    return b.reduce((c, d) => c && c[d], a);
  }
  function te(a) {
    return !(!a.g && !a.h);
  }
  function ue(a, b, c, ...d) {
    if (a.g) {
      var e = he();
      c && (a.j[e] = c);
      b = "VerificationService." + b;
      d = fe() && ge() ? d : JSON.stringify(d);
      a.g.h(new $d(e, b, "1.4.4-dev", d));
    }
  }
  function ve(a, b) {
    ee(b);
    a.h
      ? a.h.registerSessionObserver(b, "revjet.com-omid", a.i)
      : ue(a, "addSessionListener", b, "revjet.com-omid", a.i);
  }
  class we {
    constructor() {
      var a;
      "undefined" === typeof a &&
        "undefined" !== typeof window &&
        window &&
        (a = window);
      a = le(a) ? a : ke();
      var b = [],
        c = se(a, re);
      c && b.push(c);
      b.push(le(a) ? a.top : ke());
      a: {
        for (const e of b) {
          b: {
            b = a;
            c = pe;
            if (!me(e))
              try {
                const f = se(e, qe);
                if (f) {
                  var d = new ne(f);
                  break b;
                }
              } catch (f) {}
            d = c(e) ? new oe(b, e) : null;
          }
          if ((b = d)) {
            d = b;
            break a;
          }
        }
        d = null;
      }
      if ((this.g = d)) this.g.g = this.s.bind(this);
      else if (
        (d =
          (d = ke().omid3p) &&
          "function" === typeof d.registerSessionObserver &&
          "function" === typeof d.addEventListener
            ? d
            : null)
      )
        this.h = d;
      this.m = 0;
      this.j = {};
      this.i = (d = ke().omidVerificationProperties) ? d.injectionId : void 0;
    }
    addEventListener(a, b) {
      if (!a) throw Error("Value for eventType is undefined, null or blank.");
      if ("string" !== typeof a && !(a instanceof String))
        throw Error("Value for eventType is not a string.");
      if ("" === a.trim()) throw Error("Value for eventType is empty string.");
      ee(b);
      this.h
        ? this.h.addEventListener(a, b, this.i)
        : ue(this, "addEventListener", b, a, this.i);
    }
    s(a) {
      const b = a.method,
        c = a.h;
      a = a.g;
      if ("response" === b && this.j[c]) {
        var d =
          fe() && ge()
            ? a
              ? a
              : []
            : a && "string" === typeof a
            ? JSON.parse(a)
            : [];
        this.j[c].apply(this, d);
      }
      "error" === b && window.console && ce(a);
    }
  }
  function xe() {
    return "undefined" !== typeof window.mozPaintCount;
  }
  class ye extends Zb {
    constructor(a, b) {
      super(a, b);
      this.o = 0;
      this.m = [];
    }
    h() {
      const a = Rb(window, window.document),
        b = Sb(window, window.document);
      this.m = [
        ze(new Ae(0, 0)),
        ze(new Ae(a - 2, 0)),
        ze(new Ae((a - 2) / 2, (b - 2) / 2)),
        ze(new Ae(0, b - 2)),
        ze(new Ae(a - 2, b - 2)),
      ];
      this.o = new Date().getTime();
      this.m.forEach((c) =>
        c.checkVisibility(() => {
          var d = this.m;
          let e = 0;
          for (var f = 0; f < d.length; f++) d[f].isVisible && e++;
          d = new Date().getTime();
          f = this.j;
          3 <= e
            ? d - this.o >= f && !Pb() && !Qb() && (0, this.s)(2)
            : (this.o = d);
        })
      );
    }
    g() {
      this.m.forEach((a) => {
        null !== a.g &&
          ((a.h = !0), a.g.parentNode.removeChild(a.g), (a.g = null));
      });
      this.m = [];
    }
  }
  function ze(a) {
    if (null !== a.g) return a;
    var b = {
      allowtransparency: "true",
      frameborder: "0",
      hspace: "0",
      marginwidth: "0",
      marginheight: "0",
      vspace: "0",
      width: 2,
      height: 2,
    };
    a.g = document.createElement("iframe");
    for (let c in b) b.hasOwnProperty(c) && a.g.setAttribute(c, b[c]);
    a.g.style.cssText =
      "position: absolute; border: none; pointer-events: none; z-index: 10000; width: 2px; height: 2px; " +
      `left: ${a.j}px; top: ${a.s}px; `;
    document.body.appendChild(a.g);
    b = a.g.contentWindow.document;
    b.open();
    b.write(
      '<!DOCTYPE html>\n<html>\n<body style="background: transparent none;">\n<canvas width="2" height="2" style="z-index: 1000; position: absolute; top: 0; left: 0; width: 2px; height: 2px;"></canvas>\n</body>\n</html>'
    );
    b.close();
    return a;
  }
  function Be(a, b) {
    b = b.mozPaintCount;
    return b > a.i ? ((a.isVisible = !0), (a.i = b), !0) : (a.isVisible = !1);
  }
  function Ce(a, b, c, d) {
    b.clearRect(0, 0, 2, 2);
    b.fillRect(0, 0, 2, 2);
    Be(a, c) && d();
    a.h || c.requestAnimationFrame(() => Ce(a, b, c, d));
  }
  class Ae {
    constructor(a, b) {
      this.j = a;
      this.s = b;
      this.g = null;
      this.isVisible = this.h = !1;
      this.i = 0;
    }
    checkVisibility(a) {
      if (null !== this.g) {
        this.h = this.isVisible = !1;
        var b = this.g.contentWindow,
          c = b.document.getElementsByTagName("canvas");
        0 === c.length
          ? window.setTimeout(() => this.checkVisibility(a), 50)
          : ((c = c[0]),
            (this.i = b.mozPaintCount),
            (c = c.getContext("2d")),
            (c.fillStyle = "transparent"),
            Ce(this, c, b, a));
      }
    }
  }
  let De = null,
    Ee = null;
  function Fe() {
    Ee || (Ee = new we());
    return Ee;
  }
  function Ge(a) {
    for (const b of a.i) b.cb || ((b.cb = !0), b.Bd());
  }
  function He(a) {
    a.D || a.m || ((a.o = !0), Ie(a), Ge(a));
  }
  function Je(a) {
    a.F
      ? a.o && Ge(a)
      : te(a.j) &&
        ((a.F = !0),
        (a.s = window.setTimeout(() => {
          a.s = -1;
          a.D || a.m || a.o || He(a);
        }, 1500)),
        ve(a.j, (b) => {
          -1 !== a.s && (window.clearTimeout(a.s), (a.s = -1));
          const c = b.type;
          "sessionStart" === c
            ? Ke(a, b)
            : "sessionFinish" === c
            ? Ie(a)
            : "sessionError" === c && He(a);
        }),
        a.j.addEventListener("impression", (b) => {
          b = (b.data || {}).adView;
          a.g = b ? b.percentageInView : 0;
          Le(a, a.g);
          Me(a) || ((b = Ne(a)) && Oe(a, b));
        }),
        a.j.addEventListener("geometryChange", (b) => {
          if ((b = b.data))
            (b = b.adView), (a.g = b ? b.percentageInView : 0), Le(a, a.g);
        }));
  }
  function Pe(a, b) {
    if (!a.m) {
      a = a.j;
      ee(b);
      if (isNaN(16)) throw Error("Value for timeInMillis is not a number");
      if (
        "function" === typeof ke().setTimeout &&
        "function" === typeof ke().clearTimeout
      )
        ke().setTimeout(b, 16);
      else {
        var c = a.m++;
        ue(a, "setTimeout", b, c, 16);
      }
    }
  }
  function Ke(a, b) {
    a.D = !0;
    if ((b = b.data))
      (b = b.context),
        (a.C = b),
        "accessMode" in b && (a.v = b.accessMode),
        (b = b.supports),
        Array.isArray(b) && (a.H = b);
    Pe(a, () => Qe(a));
  }
  function Ie(a) {
    a.g = 0;
    a.m = !0;
    if (a.h) {
      try {
        if ("undefined" !== typeof a.h.unobserve) {
          const b = Ne(a);
          b && a.h.unobserve(b);
        }
      } catch (b) {}
      a.h = null;
    }
  }
  function Qe(a) {
    const b = new Date().getTime();
    for (const c of a.i)
      0 !== c.Va && !c.cb && b >= c.Va + c.zd && (c.listener(9), (c.cb = !0));
    Pe(a, () => Qe(a));
  }
  function Le(a, b) {
    for (const c of a.i)
      b >= 100 * c.Ed
        ? 0 === c.Va && (c.Va = new Date().getTime())
        : (c.Va = 0);
  }
  function Re(a, b, c, d) {
    let e = null;
    const f = (g) => {
      null != e && (e.g(), (e = null), b(g));
    };
    ac()
      ? (e = new lc(a, f))
      : Fd()
      ? (e = new Hd(a, f))
      : Od()
      ? (e = new Qd(a, f))
      : Ud()
      ? (e = new Xd(a, f))
      : Jd()
      ? (e = new Nd(a, f))
      : xe()
      ? (e = new ye(a, f))
      : !Rd() && (e = new Td(a, f));
    null != e && ((e.D = d), (e.i = c), e.h());
  }
  function Me(a) {
    return "limited" === a.v || a.H.some((b) => "clid" === b);
  }
  function Ne(a) {
    a = a.C;
    return a.videoElement || a.slotElement;
  }
  function Oe(a, b) {
    "undefined" !== typeof window &&
      "undefined" !== typeof window.IntersectionObserver &&
      ((a.h = new window.IntersectionObserver(
        (c) => {
          c.forEach((d) => {
            a.g = 100 * d.intersectionRatio;
            Le(a, a.g);
          });
        },
        { root: null, rootMargin: "0px" }
      )),
      a.h && a.h.observe(b));
  }
  class Se {
    constructor() {
      this.C = {};
      this.g = 0;
      this.i = [];
      this.h = null;
      this.o = this.D = this.m = !1;
      this.v = "";
      this.H = [];
      this.j = Fe();
      this.F = !1;
      this.s = -1;
    }
    addEventListener(a, b, c, d) {
      this.i.push({
        listener: a,
        zd: b,
        Ed: c,
        threshold: d,
        Va: this.g >= 100 * c ? new Date().getTime() : 0,
        cb: !1,
        Bd: () => Re(b, a, c, d),
      });
      return () => {
        this.i = this.i.filter((e) => e.listener !== a);
      };
    }
  }
  function Te(a) {
    null != a.m && (a.m.g(), (a.m = null));
  }
  class Ue extends Zb {
    constructor(a, b) {
      super(a, b);
      De || (De = new Se());
      this.v = De;
      this.m = this.o = null;
    }
    h() {
      let a = !1;
      var b = (c) => {
        a || ((a = !0), Te(this), (0, this.s)(c));
      };
      this.o = this.v.addEventListener(b, this.j, this.i, this.D);
      Je(this.v);
      !a &&
        ac() &&
        ((b = new lc(this.j, b)),
        (b.D = this.D),
        (b.i = this.i),
        (this.m = b),
        b.h());
    }
    g() {
      null != this.o && (this.o(), (this.o = null));
      Te(this);
    }
  }
  let Ve = null;
  function We() {
    Ve || (Ve = new Xe());
    return Ve;
  }
  function Ye(a) {
    let b = !1;
    const c = window.setTimeout(() => {
        b ||
          "viewable" !== a.i ||
          ((a.i = "not_viewable"), Ze(a, "not_viewable"));
      }, 800),
      d = () => {
        b = !0;
        window.clearTimeout(c);
        $e(a);
        "not_viewable" === a.i && ((a.i = "viewable"), Ze(a, "viewable"));
        window.setTimeout(() => Ye(a), 1e3);
      };
    $e(a);
    te(Fe())
      ? (a.g = new Ue(50, d))
      : ac()
      ? (a.g = new lc(50, d))
      : Fd()
      ? (a.g = new Hd(50, d))
      : Od()
      ? (a.g = new Qd(50, d))
      : Ud()
      ? (a.g = new Xd(50, d))
      : Jd()
      ? (a.g = new Nd(50, d))
      : Rd()
      ? d()
      : (a.g = new Td(50, d));
    a.g &&
      ((a.g.D = [
        0, 0.001, 0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1,
      ]),
      (a.g.i = 0.001),
      a.g.h());
  }
  function $e(a) {
    a.g && (a.g.g(), (a.g = null));
  }
  function Ze(a, b) {
    a.h.forEach((c) => c.dispatchEvent(new F(b)));
  }
  function af(a, b) {
    return void 0 !== a.h.find((c) => c === b);
  }
  class Xe extends td {
    constructor() {
      super();
      this.g = null;
      this.i = "not_viewable";
      this.h = [this];
      Ye(this);
    }
  }
  function bf(a) {
    if (!a) return [];
    if (a.classList) return a.classList;
    a = a.className;
    return (x(a) && a.match(/\S+/g)) || [];
  }
  function cf(a, b) {
    if (!a || !x(b) || "" == b) return !1;
    let c = !1;
    if (a.classList) return a.classList.contains(b);
    a = bf(a);
    for (let d = 0; d < a.length; d++)
      if (a[d] == b) {
        c = !0;
        break;
      }
    return c;
  }
  function df(a, b) {
    a &&
      x(b) &&
      "" != b &&
      (a.classList
        ? a.classList.add(b)
        : 0 == bf(a).length
        ? (a.className = b)
        : (a.className += " " + b));
  }
  function ef(a, b) {
    cf(a, b) || df(a, b);
  }
  function ff(a, b) {
    if (a && x(b) && "" != b)
      if (a.classList) a.classList.remove(b);
      else {
        let c = bf(a);
        for (let d = 0; d < c.length; d++)
          if (c[d] == b) {
            c.splice(d, 1);
            break;
          }
        a.className = c.join(" ");
      }
  }
  function gf(a) {
    const b = a.j;
    a.s = a.o.bind(a);
    B(b, "animationend", a.s);
    ef(b, a.m);
    return new Promise((c) => {
      window.setTimeout(() => {
        a.g = [b]
          .concat(Array.prototype.slice.call(b.getElementsByTagName("*")))
          .filter((d) => 0 < parseFloat(jb(d, "animation-duration") || "0"))
          .filter((d) =>
            Pa(d, (e) => 1 === e.nodeType && "none" === jb(e, "display")).I()
          )
          .map((d) => {
            const e = (jb(d, "animation-name") || "")
              .split(",")
              .map((f) => Lb(f));
            return { element: d, ub: e };
          });
        c(a.g);
      }, 0);
    });
  }
  function hf(a) {
    a.i = !0;
    jf(a);
    a.h.forEach((b) => b && b(a));
    a.h = [];
  }
  function kf(a, b) {
    a.h = a.h.concat(b);
  }
  function jf(a) {
    const b = a.j,
      c = a.s;
    c && (bb(b, "animationend", c), (a.s = null));
  }
  function lf(a) {
    jf(a);
    a.h = [];
    var b = a.j;
    a = a.m;
    cf(b, a) && ff(b, a);
  }
  class mf {
    constructor(a, b) {
      this.j = a;
      this.m = b;
      this.g = [];
      this.h = [];
      this.s = null;
      this.i = !1;
    }
    play() {
      if (this.i) return Promise.resolve([]);
      this.i = !1;
      const a = this.j;
      var b = this.m;
      cf(a, b) && ff(a, b);
      try {
        a.offsetWidth = a.offsetWidth;
      } catch (c) {}
      return gf(this);
    }
    stop() {
      this.i || ((this.h = []), hf(this));
    }
    o(a) {
      db(a);
      this.g = this.g.map((b) =>
        b.element === a.target
          ? Object.assign({}, b, {
              ub: b.ub.filter((c) => c !== a.animationName),
            })
          : b
      );
      this.g = this.g.filter((b) => 0 < b.ub.length);
      0 === this.g.length && hf(this);
    }
  }
  function nf(a, b) {
    a.s = a.s.concat(b);
  }
  function of(a, b) {
    a.i = a.i.concat(b);
  }
  function pf(a, b) {
    a.j = a.j.concat(b);
  }
  function qf(a, b) {
    const c = (d) => {
      d = new mf(a.v, d);
      kf(d, () => rf(a));
      return d;
    };
    return b.map((d) => c(d));
  }
  function sf(a) {
    a.g = qf(a, a.m);
    0 < a.g.length &&
      a.g[0].play().then((b) => {
        a.s.forEach((c) => c(a, b));
      });
  }
  function tf(a) {
    const b = a.D;
    a.g.forEach((c) => {
      c.stop();
      lf(c);
    });
    b.forEach((c) => {
      const d = c.selector,
        e = c.widgetId,
        f = c.style || [];
      (d ? u(document.querySelector(d)) : Ka(e)).forEach((g) =>
        f.forEach((h) => {
          const k = h.name;
          h = h.value;
          null != k && null != h && C(g, k, h);
        })
      );
    });
    a.h = 1;
    a.i.forEach((c) => c(a));
  }
  function rf(a) {
    var b = a.g;
    b.every((c) => c.i)
      ? ((b = a.h), "infinite" === b || 1 < b ? uf(a) : tf(a))
      : b.find((c) => !c.i).play();
  }
  function uf(a) {
    a.g.forEach((d) => {
      d.stop();
      lf(d);
    });
    var b = a.h;
    a.h = "infinite" !== b && 1 < b ? b - 1 : b;
    b = a.m.slice(0);
    const c = a.o;
    1 === a.h && p(c) && (b[b.length - 1] = c.get());
    b = qf(a, b);
    a.g = b;
    0 < b.length && (b[0].play(), a.j.forEach((d) => d(a)));
  }
  function vf(a) {
    a.g = [];
    a.s = [];
    a.i = [];
    a.j = [];
  }
  class wf {
    constructor(a, b, c, d, e) {
      this.v = a;
      this.g = [];
      this.m = b;
      this.o = c;
      this.D = d;
      this.h = e;
      this.s = [];
      this.i = [];
      this.j = [];
    }
  }
  function K(a) {
    return a.za() ? t : Ka(a.C);
  }
  function xf(a, b) {
    for (a = new ia(a); p(a); ) {
      const c = a.get();
      if (b(c)) return a;
      a = c.getParent();
    }
    return t;
  }
  function yf(a, b) {
    a.m = b;
    a.ab = b;
  }
  function zf(a, b) {
    a.Eb = b;
  }
  function Af(a, b) {
    if (b)
      for (a = [a.H()]; 0 < a.length; ) {
        const c = a.pop();
        if (c.G() === b) return new ia(c);
        a = a.concat(c.S);
      }
    return t;
  }
  class Bf extends td {
    constructor() {
      super();
      this.C = "";
      this.o = "unknown";
      this.Xa = {};
      this.L = 0;
      this.R = this.ab = null;
      this.S = [];
      this.F = !1;
      this.sa = null;
      this.U = !1;
      this.ca = void 0;
      this.$a = !1;
      this.Eb = this.Wa = this.X = null;
      this.Ya = !1;
    }
    h() {}
    load() {
      return Promise.resolve();
    }
    refresh() {}
    za() {
      return !1;
    }
    H() {
      this.X || (this.X = xf(this, (a) => a.za()).get());
      return this.X;
    }
    getType() {
      return this.o;
    }
    K(a) {
      return this.o === a;
    }
    P() {
      return this.Xa;
    }
    G() {
      return this.C;
    }
    getParent() {
      return u(this.ab);
    }
    isViewable() {
      return this.F;
    }
    gb() {
      return this.Wa;
    }
    dispatchBrowserEvent() {}
    O(a) {
      this.forEach((b) => b.dispatchEvent(a));
    }
    forEach(a) {
      let b = [this.H()];
      for (; 0 < b.length; ) {
        const c = b.pop();
        if (!1 === a(c)) break;
        b = b.concat(c.S);
      }
    }
    oa() {
      return !1;
    }
    Fb() {}
    tc() {}
    ba() {}
    Ib(a, b) {
      a = a.L;
      b = b.L;
      return a < b ? -1 : a > b ? 1 : 0;
    }
    Ja() {
      return t;
    }
    Ka() {
      return t;
    }
  }
  let Cf = null;
  function M() {
    Cf || (Cf = new N());
    return Cf;
  }
  function Df() {
    return od("MaxAnimationDurationTimer");
  }
  function Ef(a) {
    a.h.forEach((b) => b());
    a.h = [];
  }
  class N {
    constructor() {
      const a = G();
      this.g = !1;
      this.h = [];
      this.i = a.s.map(
        (b) =>
          new hb(b, () => {
            J(Df(), "Timer finished");
            this.g = !0;
            Ef(this);
          })
      );
    }
    start() {
      this.g ||
        this.i.forEach((a) => {
          a.ga = !1;
          a.start();
          J(Df(), "Timer started (" + a.xb() + ")");
        });
    }
    disable() {
      this.g = !1;
      this.h = [];
      this.i.forEach((a) => a.stop());
      this.i = t;
      J(Df(), "Disabled");
    }
    isEnabled() {
      return p(this.i);
    }
    Cb() {
      return da(
        this.i.map((a) => a.Cb()),
        !1
      );
    }
    wd() {
      return this.g;
    }
    addListener(a) {
      this.h = this.h.concat(a);
      this.g && Ef(this);
    }
    removeListener(a) {
      this.h = this.h.filter((b) => b !== a);
    }
    hb() {
      return da(
        this.i.map((a) => a.hb()),
        0
      );
    }
    va(a) {
      if (this.isEnabled()) {
        if (this.g) return 0;
        const b = this.hb();
        if (a > b) return 0 < b ? b : 0;
      }
      return a;
    }
  }
  N.prototype.getRemainingDuration = N.prototype.va;
  N.prototype.getRemainingTime = N.prototype.hb;
  N.prototype.removeListener = N.prototype.removeListener;
  N.prototype.addListener = N.prototype.addListener;
  N.prototype.isFinished = N.prototype.wd;
  N.prototype.isEnabled = N.prototype.isEnabled;
  N.prototype.disable = N.prototype.disable;
  function Ff(a, b) {
    return Gf(a, b).flatMap((c) => K(c));
  }
  function Hf(a, b) {
    var c = Gf(a, b);
    return p(c) &&
      ((b = If(b)), (c = If(c.get())), null !== b && null !== c && b !== c)
      ? (J(od("Action"), `Relaying action to '${c.G()}'`),
        va("relayAction", y(), a.F),
        !0)
      : !1;
  }
  function Jf(a, b) {
    const c = b.M,
      d = b.Kb;
    a.v++;
    if (ta()) {
      var e = ca(
        K(c).flatMap((g) => u(g.getAttribute("data-revjet-role"))),
        () => c.G()
      );
      const f = r(
        Ff(a, c).flatMap((g) => u(g.getAttribute("data-revjet-role")))
      );
      J(od("Action"), `Running [${a.v}] '${a.h}' (${e} --> ${f})`);
    }
    e = !1;
    !d &&
      Dc() &&
      p(a.i) &&
      "expand" !== a.h &&
      "collapse" !== a.h &&
      (e = Hf(a, c));
    e || a.B(b);
  }
  function Gf(a, b) {
    return a.i.flatMap((c) => Af(b, c));
  }
  function If(a) {
    let b = null;
    for (; a; ) a.K("frame_element") && (b = a), (a = r(a.getParent()));
    return b;
  }
  class O {
    constructor(a, b) {
      this.D = 0;
      this.h = a;
      this.F = b || {};
      this.fb = (a = b.execDelay)
        ? "number" !== typeof a
          ? parseInt(a, 10)
          : a
        : 0;
      this.v = 0;
      this.Xa = b.maxRunCount || 0;
      this.i = u(b.widgetId);
      this.tb = !!b.stopEventPropagation;
    }
    getType() {
      return this.h;
    }
    K(a) {
      return this.h === a;
    }
    P() {
      return this.F;
    }
    s() {
      return !this.tb;
    }
    B(a) {
      a = a.V.getType();
      if (
        "click" === a ||
        "auxclick" === a ||
        "swipe" === a ||
        "mouse_down" === a ||
        "mouse_over" === a ||
        "link" === this.h
      )
        (a = M()), a.isEnabled() && a.disable();
    }
  }
  let Kf = 1;
  function Lf(a, b, c) {
    J(od("WidgetEventListener"), "addAction", b.getType());
    b.D = Kf;
    Kf++;
    c && (b.fb = "number" !== typeof c ? parseInt(c, 10) : c);
    a.g = a.g.concat(b);
    b.D > a.mb && (a.mb = b.D);
  }
  function Mf(a, b) {
    return !G().h || b.Db()
      ? a.g
      : a.g.filter((c) => -1 === ab.indexOf(c.getType()));
  }
  function Nf(a, b, c) {
    const d = E(new F("max_action_count"), c);
    Gf(b, a).forEach((e) => e.dispatchEvent(d));
  }
  function Of(a, b, c) {
    const d = (l) =>
        l.forEach((n) => {
          Jf(n, { M: b, V: c, mc: a.g, Kb: !1 });
        }),
      [e, f, g] = Mf(a, c).reduce(
        (l, n) => {
          let [q, v, z] = l;
          l = n.Xa;
          0 < l && n.v >= l
            ? (q = q.concat(n))
            : 0 < n.fb
            ? (z = z.concat(n))
            : (v = v.concat(n));
          return [q, v, z];
        },
        [[], [], []]
      );
    e.forEach((l) => Nf(b, l, c));
    d(f);
    const h = g.reduce((l, n) => {
      if (ta()) {
        var q = ca(
          K(b).flatMap((z) => u(z.getAttribute("data-revjet-role"))),
          () => b.G()
        );
        const v = r(
          Ff(n, b).flatMap((z) => u(z.getAttribute("data-revjet-role")))
        );
        J(
          od("WidgetEventListener"),
          `Delaying '${n.getType()}' execution by ${n.fb}` + ` (${q} --> ${v})`
        );
      }
      q = n.fb;
      l[q] = (l[q] || []).concat(n);
      return l;
    }, {});
    for (let l in h)
      if (h.hasOwnProperty(l)) {
        var k = M().va(parseInt(l, 10));
        0 === k
          ? d(h[l])
          : ((k = new hb(k, () => d(h[l]))), (k.ga = !1), k.start());
      }
  }
  function Pf(a) {
    return a.g.some((b) => b.s());
  }
  class Qf {
    constructor(a) {
      this.h = a.type;
      this.i = a;
      this.g = [];
      this.mb = 0;
    }
    getType() {
      return this.h;
    }
    P() {
      return this.i;
    }
  }
  class Rf extends F {
    constructor(a, b, c, d, e) {
      super("click_heatmap", { cx: a, cy: b, cw: c, ch: d, bp: e });
    }
    g() {
      return !0;
    }
  }
  const Sf = {
      click: "click",
      auxclick: "auxclick",
      change: "change",
      mouse_down: "mousedown",
      mouse_out: "mouseout",
      mouse_enter: "mouseenter",
      mouse_leave: "mouseleave",
    },
    Tf =
      "click auxclick swipe mouse_down mouse_over mouse_out mouse_enter mouse_leave".split(
        " "
      );
  function Uf(a, b) {
    return new Vf(a, b.type, b);
  }
  function Wf() {
    return od("BaseWidget");
  }
  function Xf(a, b) {
    K(a)
      .filter((c) => b.target === c)
      .forEach(() => Yf(a));
  }
  function Zf(a, b) {
    K(a)
      .filter((c) => b.target === c)
      .forEach(() => Yf(a));
  }
  function $f(a, b) {
    K(a)
      .filter((c) => b.target === c)
      .forEach(() => window.setTimeout(() => Yf(a), 0));
  }
  function ag(a) {
    return p(
      K(a).filter((b) => !(!b.tagName || "a" !== b.tagName.toLowerCase()))
    );
  }
  function bg(a, b) {
    ag(a) &&
      K(a).forEach((c) => {
        c.setAttribute("href", b);
        c.setAttribute("data-revjet-original-href", b);
      });
  }
  function cg(a, b) {
    return a.ia.find((c) => c.getType() === b);
  }
  function dg(a, b) {
    const c = Mc();
    var d = yb(b);
    const e = Ib();
    c.h = d;
    c.g = e;
    null != b.button && (c.m = b.button);
    K(a).forEach((f) => {
      f = f.getAttribute("data-revjet-role");
      c.D = u(f ? f : b.target.id);
    });
    d = new Rf(
      null == d ? void 0 : d.cx,
      null == d ? void 0 : d.cy,
      null == e ? void 0 : e.eb,
      null == e ? void 0 : e.ch,
      null == e ? void 0 : e.bb
    );
    null != b.button && Eb(d, b.button);
    d.stopPropagation();
    a.dispatchEvent(d);
  }
  function eg(a, b, c) {
    var d = c.target,
      e = K(b);
    if (p(e) && d) {
      let f = d;
      d = f.ownerDocument.defaultView;
      w !== d && (f = d.frameElement ? d.frameElement : f);
      e = e.get();
      e = e === f || Oa(e, (g) => g === f) ? b : null;
      return b.S.reduce((g, h) => eg(a, h, c) || g, e);
    }
    return null;
  }
  function fg(a, b, c) {
    return ((d, e, f) => {
      (f instanceof F && !f.g(d)) || e(f);
    }).bind(a, b, c);
  }
  function gg(a, b) {
    return (c) => {
      let d = a.getParent();
      for (; p(d) && !d.get().za(); ) {
        const e = cg(d.get(), c.getType());
        if (null != e && e.mb > b.mb) {
          c.stopPropagation();
          break;
        }
        d = d.get().getParent();
      }
      Pf(b) || c.stopPropagation();
      Of(b, a, c);
    };
  }
  function hg(a, b) {
    a.ia = a.ia.concat(b);
    const c = b.getType(),
      d = b.P();
    var e = K(a);
    if (!e.I()) {
      e = e.get();
      J(Wf(), "addWidgetEventListener", b.getType());
      b = gg(a, b);
      switch (c) {
        case "mouse_over":
          new vd(e, d.duration).i = a;
          b = fg(a, d, b);
          break;
        case "animation_end":
        case "animation_start":
        case "hype_scene_load":
        case "hype_scene_unload":
        case "hype_timeline_complete":
        case "custom_event":
        case "before_form_load":
        case "form_load":
        case "form_validated":
        case "validated":
        case "gallery_slide_click":
        case "gallery_slide_panel_view":
        case "gallery_slide_video_play":
          b = fg(a, d, b);
          break;
        case "swipe":
          new Bd(e, d.direction).i = a;
          b = fg(a, d, b);
          break;
        case "orientation_change":
          new yd(d.orientation).i = a;
          b = fg(a, d, b);
          break;
        case "viewable":
        case "not_viewable":
          We().h.push(a);
          break;
        default:
          c in Sf && e.addEventListener(Sf[c], a.Za.bind(a, c), !1);
      }
      a.listen(c, b);
    }
  }
  function ig(a, b) {
    K(a).forEach((d) => {
      b.h = Object.assign({}, b.h, { widgetId: a.G() });
      if (d.getAttribute) {
        var e = d.getAttribute("data-revjet-role");
        b.h = Object.assign({}, b.h, { role: e });
        b.ob(d.getAttribute("data-revjet-role-id"));
      }
    });
    const c = b.getType();
    if ("viewable" === c) {
      if (a.isViewable()) return !0;
      a.F = !0;
    }
    if ("not_viewable" === c) {
      if (!a.isViewable()) return !0;
      a.F = !1;
    }
    if (ta()) {
      const d = ca(
        K(a).flatMap((e) => u(e.getAttribute("data-revjet-role"))),
        () => a.getType()
      );
      J(Wf(), `Dispatching '${c}' event to '${a.G()}' (${d})`);
    }
    return !1;
  }
  function jg(a, b) {
    return b.findIndex((c) => c === a);
  }
  function kg(a, b, c, d) {
    J(Wf(), "moveWidget_", c, d);
    const e = b[d],
      f = b[c];
    K(b[0])
      .flatMap((g) => K(e).flatMap((h) => K(f).map((k) => [g, h, k])))
      .forEach(([g, h, k]) => {
        g.parentNode.insertBefore(k, c > d ? h : h.nextSibling);
        a.v = c;
        Ja(b, c, d);
      });
  }
  function lg(a, b) {
    return b.findIndex((c) => c.G() === a.G());
  }
  function mg(a, b, c) {
    a.S.forEach((d) => {
      d.oa() || d.dispatchEvent(E(new F(b), c));
    });
  }
  function Yf(a) {
    const b = a.oa(),
      c = a.Qa(),
      d = a.sa;
    !0 === c && b
      ? a.dispatchEvent(E(new F("hide"), d))
      : !1 !== c ||
        b ||
        (a.dispatchEvent(E(new F("before_show"), d)),
        a.dispatchEvent(E(new F("show"), d)));
  }
  class Vf extends Bf {
    constructor(a, b, c) {
      super();
      this.v = -1;
      this.ia = [];
      this.ha = !1;
      this.C = a;
      this.o = b;
      this.Xa = c;
      a = c.order;
      null != a && (this.L = a);
      a = c.parentId;
      null != a && (this.R = a);
      a = c.disableBrowserEvents;
      null != a && (this.$a = !!a);
      a = c.dataBinding;
      null != a && 0 < Object.keys(a).length && (this.Wa = a);
      c = c.mapping;
      null != c &&
        zf(this, { name: c.name, pb: c.xpath, Sf: c.adrole, type: c.type });
      Object.keys(Bb)
        .filter((e) => !Tf.find((f) => f === Bb[e]))
        .forEach((e) => this.listen(Bb[e], (f) => f.stopPropagation()));
      const d = fd();
      Object.keys(Bb).forEach((e) => this.listen(Bb[e], (f) => ld(d, f)));
      this.listen("ready", () => {
        this.Ya = !0;
      });
      this.listen("before_show", (e) => {
        mg(this, "before_show", e);
      });
      this.listen("show", (e) => {
        this.ha = !0;
        mg(this, "show", e);
      });
      this.listen("hide", (e) => {
        this.ha = !1;
        mg(this, "hide", e);
      });
      this.listen("expand_start", (e) => {
        mg(this, "expand_start", e);
      });
      this.listen("after_personalization", () => {});
      K(this).forEach((e) => {
        e.addEventListener("animationstart", (f) => Xf(this, f), !1);
        e.addEventListener("animationiteration", (f) => Zf(this, f), !1);
        e.addEventListener("animationend", (f) => $f(this, f), !1);
      });
    }
    Qa() {
      return this.ha;
    }
    h() {
      ag(this) &&
        K(this).forEach((a) => {
          a.addEventListener("click", (b) => cb(b), !1);
          a.addEventListener("dragstart", (b) => cb(b), !1);
        });
    }
    Za(a, b) {
      J(Wf(), "Browser event received", a, this.G());
      "mouse_down" === a && dg(this, b);
      ("click" !== a && "auxclick" !== a) || wb(b);
      b.stopPropagation();
      const c = eg(this, this, b);
      (c && c.K("html5_element") && c.$a) ||
        ((a = new F(a)),
        null != b.button && Eb(a, b.button),
        this.dispatchEvent(a));
    }
    dispatchBrowserEvent(a, b) {
      this.Za(a, b);
    }
    dispatchEvent(a) {
      ig(this, a) || super.dispatchEvent(a);
    }
    da(a) {
      if (!ig(this, a)) return super.da(a);
    }
    oa() {
      return da(
        K(this).map(
          (a) => "none" === jb(a, "display") || "hidden" === jb(a, "visibility")
        ),
        !0
      );
    }
    Fb(a) {
      this.getParent().forEach((b) => {
        b = b.S;
        const c = b.filter((g) => !g.oa() || g === this);
        let d = -1;
        const e = jg(this, c),
          f = jg(this, b);
        "above" === a && -1 !== e && e < c.length - 1
          ? (d = e + 1)
          : "below" === a && 0 < e
          ? (d = e - 1)
          : "on_top" === a && -1 !== e && e < c.length - 1
          ? (d = c.length - 1)
          : "on_bottom" === a && 0 < e && (d = 0);
        -1 !== d && (Ja(b, f, lg(c[d], b)), kg(this, c, e, d), (this.v = f));
      });
    }
    tc() {
      -1 !== this.v &&
        this.getParent().forEach((a) => {
          a = a.S;
          const b = jg(this, a);
          -1 !== b && kg(this, a, b, this.v);
        });
    }
    ba(a, b) {
      super.ba(a, b);
    }
  }
  function ng(a) {
    K(a).forEach((b) => {
      if (a.g && b.isPaused && b.isPaused()) b.onAction("play");
    });
    a.g = !1;
  }
  function og(a) {
    K(a).forEach((b) => {
      b.isPaused && !b.isPaused() && (b.onAction("pause"), (a.g = !0));
    });
  }
  class pg extends Vf {
    constructor(a, b) {
      super(a, "audio_element", b);
      this.g = !1;
      if ((this.i = !!b.pauseOnNotViewable))
        this.listen("viewable", () => ng(this)),
          this.listen("not_viewable", () => og(this));
      this.listen("hide", () => {
        this.ba("stop", {});
      });
    }
    h() {
      super.h();
      if (this.i) {
        const a = We();
        af(a, this) || a.h.push(this);
      }
    }
    ba(a, b) {
      K(this).forEach((c) => {
        if (c.onAction) c.onAction(a, b);
      });
    }
  }
  class qg extends Vf {
    constructor(a, b) {
      super(a, "frame_element", b);
    }
  }
  class rg extends qg {
    constructor(a, b) {
      super(a, b);
      this.o = "body_element";
    }
  }
  function sg(a) {
    return (window.lottie ? new ia(window) : t).flatMap((b) => {
      b = b.lottie.getRegisteredAnimations();
      return u(b.find((c) => c.name === a.g));
    });
  }
  function tg(a) {
    sg(a).forEach((b) => {
      b.goToAndStop(b.totalFrames, !0);
    });
  }
  class ug {
    constructor(a) {
      this.g = a;
    }
    play() {
      sg(this).forEach((a) => a.play());
    }
    stop() {
      sg(this).forEach((a) => a.stop());
    }
    pause() {
      sg(this).forEach((a) => a.pause());
    }
    playSegments(a) {
      sg(this).forEach((b) => b.playSegments(a, !0));
    }
    goToAndStop(a) {
      sg(this).forEach((b) => b.goToAndStop(a, !0));
    }
    goToAndPlay(a) {
      sg(this).forEach((b) => b.goToAndPlay(a, !0));
    }
  }
  let vg = [],
    wg = [];
  function yg(a, b) {
    "HYPE_eventListeners" in window || (window.HYPE_eventListeners = []);
    window.HYPE_eventListeners.push({ type: a, callback: b });
  }
  function zg(a) {
    return wg.find((b) =>
      p(Pa(b.element, (c) => c && c.getAttribute && c.getAttribute("id") == a))
    );
  }
  function Ag(a, b, c, d) {
    "HypeDocumentLoad" === a &&
      (wg = wg.concat({ ma: b, element: c, ud: b.currentSceneName() }));
    "HypeSceneLoad" === a && G().h && b.pauseTimelineNamed("Main Timeline");
    vg.forEach((e) => {
      if (e.type === a) {
        const f = zg(e.Vc);
        f &&
          f.ma === b &&
          e.listener(f, "HypeTimelineComplete" === a ? d.timelineName : void 0);
      }
    });
    if ("HypeDocumentLoad" === a) return !1;
  }
  function Bg(a, b) {
    vg = vg.reduce(
      (c, d) =>
        "HypeDocumentLoad" === d.type && d.listener === b && d.Vc === a.g
          ? c
          : c.concat(d),
      []
    );
  }
  function Cg(a, b) {
    if ((b = b || zg(a.g))) b.ma.showSceneNamed(b.ud);
    else {
      let c;
      c = (d) => {
        Bg(a, c);
        Cg(a, d);
      };
      a.listen("HypeDocumentLoad", c);
    }
  }
  function P(a, b, ...c) {
    if ((a = zg(a.g))) return a.ma[b](...c);
  }
  function Dg(a, b) {
    P(a, "pauseTimelineNamed", b);
  }
  function Eg(a, b) {
    P(a, "goToTimeInTimelineNamed", b, "Main Timeline");
  }
  function Fg(a) {
    return P(a, "isPlayingTimelineNamed", "Main Timeline");
  }
  function Gg(a) {
    return P(a, "currentDirectionForTimelineNamed", "Main Timeline");
  }
  function Hg(a) {
    return P(a, "durationForTimelineNamed", "Main Timeline");
  }
  function Ig(a, b) {
    if ((a = zg(a.g))) return a.ma[b];
  }
  class Jg {
    constructor(a) {
      this.g = a;
    }
    listen(a, b) {
      vg = vg.concat({ Vc: this.g, type: a, listener: b });
    }
  }
  function Kg(a) {
    return a.replace(
      /<script[^>]*/gi,
      (b) =>
        b
          .replace(/(\s+)(type)(\s*=\s*)/gi, "$1data-revjet-script-type$3")
          .replace(
            /(\s+)(language)(\s*=\s*)/gi,
            "$1data-revjet-script-language$3"
          )
          .replace(/(\s+)(src)(\s*=\s*)/gi, "$1data-revjet-script-src$3") +
        ' type="text/revjet"'
    );
  }
  function Lg(a, b) {
    const c = b.bind(this);
    a.addEventListener
      ? (a.addEventListener("load", c, !1), a.addEventListener("error", c, !1))
      : (a.onreadystatechange = () => {
          if ("loaded" === a.readyState || "complete" === a.readyState)
            (a.onreadystatechange = null), c();
        });
  }
  function Mg(a, b, c, d) {
    return () => {
      if (0 === b.length) d && d();
      else {
        var e = b.shift(),
          f = Mg(a, b, c, d);
        if ("SCRIPT" === e.nodeName && "text/revjet" === e.type) {
          var g = c.createElement("script");
          g.async = !1;
          var h = e.getAttribute("data-revjet-script-type");
          h && (g.type = h);
          g.id = e.id;
          g.text = e.text || e.textContent || e.innerHTML || "";
          (h = e.getAttribute("data-revjet-script-language")) &&
            g.setAttribute("language", h);
          e.charset && (g.charset = e.charset);
          if ((e = e.getAttribute("data-revjet-script-src"))) g.src = e;
          e = g;
          e.src && Lg(e, f);
          a.insertBefore(e, null);
          e.src || f();
        } else if (
          e.innerHTML &&
          0 <= e.innerHTML.toLowerCase().indexOf("<script")
        ) {
          for (g = []; e.firstChild; ) g.push(e.removeChild(e.firstChild));
          a.insertBefore(e, null);
          Mg(e, g, c, f)();
        } else a.insertBefore(e, null), f();
      }
    };
  }
  function Ng(a, b, c) {
    var d = window.document;
    if (b) {
      var e = d.createElement("div");
      e.innerHTML = "L<div>" + Kg(b) + "</div>";
      b = [];
      for (e = e.lastChild; e.firstChild; ) b.push(e.removeChild(e.firstChild));
      e = b;
    } else e = [];
    Mg(a, e, d, c)();
  }
  let Og = 0;
  function Pg(a) {
    return a.h.hasAttribute("data-revjet-asset-lazy-load");
  }
  function Qg(a) {
    return a.h.hasAttribute("data-revjet-asset-lazy-render");
  }
  function Rg(a, b) {
    const c = document.createElement("iframe");
    c.setAttribute("allow", "autoplay;fullscreen;encrypted-media");
    c.setAttribute("frameborder", "0");
    c.setAttribute("hspace", "0");
    c.setAttribute("marginwidth", "0");
    c.setAttribute("marginheight", "0");
    c.setAttribute("scrolling", "no");
    c.setAttribute("vspace", "0");
    c.setAttribute("data-revjet-iframe-asset", "");
    c.style.cssText = [
      "position:absolute;left:0;top:0;border:0;padding:0;margin:0;visibility:hidden",
      "width:" + a,
      "height:" + b,
    ].join(";");
    return c;
  }
  function Sg(a) {
    return a.h.getAttribute("data-revjet-asset-src");
  }
  function Tg(a) {
    return a.h.getAttribute("data-revjet-asset-content");
  }
  function Ug(a) {
    return new Promise((b, c) => {
      const d = new XMLHttpRequest();
      d.open("GET", a, !0);
      d.responseType = "text";
      d.onreadystatechange = () => {
        4 === d.readyState &&
          (200 <= d.status && 300 > d.status
            ? b(d.response)
            : c(d.status + (d.statusText ? ` (${d.statusText})` : "")));
      };
      d.send(null);
    });
  }
  function Vg(a, b, c, d, e) {
    const f = a.h;
    var g = Array.prototype.slice
        .call(f.attributes)
        .filter((z) => z.name && qa(z.name, "data-revjet-var-"))
        .map((z) => z.name),
      h = f.getAttribute("data-revjet-html5vars") || "{}";
    g = g.reduce((z, L) => {
      const ra = L.replace(/^data-revjet-var-/, "");
      return ra
        ? ((L = f.getAttribute(L)), z.replace(`%${ra}%`, L ? L : ""))
        : z;
    }, c.replace("%html5vars%", h));
    if ("div" === wc().deliveryWrapper) return Wg(a, b, g);
    h = `onAssetReady${a.s}_`;
    const k = `${"revjet.elements"}.${h}`;
    var l = `window.parent.${"revjet.elements"}.${h}`;
    h = (c = -1 === c.indexOf("revjet.elements = {"))
      ? 'window.revjet = { };Object.defineProperty(window.revjet, "elements", {  set: function() { },  get: function() { return window.parent.revjet.elements; }});Object.defineProperty(window.revjet, "elements_api", {  set: function() { },  get: function() { return window.parent.revjet.elements_api; }});Object.defineProperty(window, "click_url", {  set: function(url) { window.parent.click_url = url; },  get: function() { return window.parent.click_url.toString(); }});Object.defineProperty(window, "click_target", {  set: function(url) { window.parent.click_target = url; },  get: function() { return window.parent.click_target; }});'
      : "";
    l =
      'if (document.readyState !== "loading") {' +
      `  ${l}();` +
      "} else {" +
      `  document.addEventListener("DOMContentLoaded", ${l}, false);` +
      "}";
    const n = a.j;
    var q = (z, L) =>
      `window.document.addEventListener("${z}", function(event) {` +
      `  window.revjet.elements_api.dispatchBrowserEvent("${n}", "${L}", event);` +
      "}, false);\n";
    q =
      c && f.hasAttribute("data-revjet-asset-propagate-events")
        ? q("click", "click") + q("auxclick", "auxclick")
        : "";
    g = Xg(
      "script",
      "text/javascript",
      h +
        "\n" +
        l +
        "\n" +
        q +
        (c && f.hasAttribute("data-revjet-asset-attach-exit")
          ? 'window.document.addEventListener("click", function(event) {  window.revjet.elements_api.goToLP(event);}, false);'
          : ""),
      g
    );
    g = Xg(
      "style",
      "text/css",
      "body, html {padding:0; margin:0; cursor:pointer;}",
      g
    );
    const v = Yg(a, b, g);
    return new Promise((z) => {
      na(k, () =>
        m(function* () {
          na(k, () => {});
          a.g = "rendered";
          e && (yield e());
          d.style.visibility = "inherit";
          try {
            const L = d.contentWindow.document;
            Oc(Mc(), L, d);
          } catch (L) {}
          z(a);
        })
      );
      d.setAttribute("srcdoc", v);
      f.appendChild(d);
    });
  }
  function Zg(a, b) {
    return m(function* () {
      if ("loaded" === a.g) {
        a.g = "rendering";
        const c = Sg(a);
        return Vg(a, c, a.i, a.na, b);
      }
      return a;
    });
  }
  function Yg(a, b, c) {
    return Tg(a) || -1 === b.indexOf("/")
      ? c
      : ((a = `<base href="${b.substring(
          0,
          b.lastIndexOf("/") + 1
        )}" target="_blank">`),
        $g("head", c)
          ? ah("head", a, c)
          : $g("html", c)
          ? ah("html", `<head>${a}</head>`, c)
          : a + "\n" + c);
  }
  function Wg(a, b, c) {
    const d = a.h,
      e = Yg(
        a,
        b,
        c
          .replace(/<body/gi, '<div style="display:block;"')
          .replace(/<\/body>/gi, "</div>")
      );
    d.style.visibility = "hidden";
    return new Promise((f) => {
      Ng(d, e, () => {
        d.style.visibility = "inherit";
        a.g = "rendered";
        f(a);
      });
    });
  }
  function $g(a, b) {
    return new RegExp("<" + a + "[^>]*>", "i").test(b);
  }
  function ah(a, b, c) {
    return c.replace(new RegExp("<" + a + "[^>]*>", "i"), "$&" + b);
  }
  function Xg(a, b, c, d) {
    a = `<${a} type="${b}">${c}</${a}>`;
    return $g("head", d)
      ? ah("head", a, d)
      : $g("html", d)
      ? ah("html", `<head>${a}</head>`, d)
      : $g("body", d)
      ? ah("body", a, d)
      : a + d;
  }
  class bh {
    constructor(a, b) {
      this.j = a;
      this.h = b;
      this.na = null;
      this.s = ++Og;
      this.i = "";
      this.g = "initial";
    }
    zb() {
      return this.g;
    }
    load() {
      const a = this;
      return m(function* () {
        if ("created" === a.g) {
          a.g = "loading";
          const b = Sg(a),
            c = Tg(a);
          if (null != c && "" !== c) a.i = c;
          else if (b) a.i = yield Ug(b);
          else throw ((a.g = "error"), Error("Empty asset URL."));
          a.g = "loaded";
        }
        return a;
      });
    }
    refresh(a) {
      const b = this;
      return m(function* () {
        const c = Sg(b),
          d = b.i;
        if (c && d && b.na) {
          const f = b.na;
          f.removeAttribute("data-revjet-iframe-asset");
          var e = b.h;
          const g = e.getAttribute("data-revjet-asset-width");
          e = e.getAttribute("data-revjet-asset-height");
          b.na = Rg(g ? g : "100%", e ? e : "100%");
          b.g = "rendering";
          yield Vg(b, c, d, b.na, a);
          f.parentNode.removeChild(f);
        }
        return b;
      });
    }
  }
  let ch = null;
  function dh() {
    ch || (ch = new eh());
    return ch;
  }
  function fh(a) {
    a.g ||
      ((a.g = !0),
      Ua(() => {
        gh(a.h);
        gh(a.i);
        a.g = !1;
      }));
  }
  function hh(a, b) {
    a.h.push(b);
    fh(a);
  }
  function ih(a, b) {
    return new Promise((c) => hh(a, () => c(b())));
  }
  function jh(a, b) {
    a.i.push(b);
    fh(a);
  }
  function kh(a, b) {
    return new Promise((c) => jh(a, () => c(b())));
  }
  function gh(a) {
    let b = 0,
      c;
    for (; (c = a.shift()); ) c(), b++;
  }
  class eh {
    constructor() {
      this.h = [];
      this.i = [];
      this.g = !1;
    }
  }
  let lh = null;
  function mh(a, b, c, d) {
    const e = dh();
    return Promise.all([
      kh(e, () => {
        b.style.backgroundImage = "none";
        b.style.overflow = "hidden";
      }),
      ih(e, () => D(b)).then((f) =>
        kh(e, () => {
          var g = parseInt(f.width, 10);
          const h = parseInt(f.height, 10),
            k = Math.min(g / c.width, h / c.height).toFixed(4);
          var l = d || "center";
          var n = Math.floor(c.height * parseFloat(k));
          const q = Math.floor(g / 2 - Math.floor(c.width * parseFloat(k)) / 2),
            v = Math.floor(h / 2 - n / 2);
          n =
            "center" === l
              ? { x: q, y: v }
              : "top" === l
              ? { x: q, y: 0 }
              : "bottom" === l
              ? { x: q, y: Math.floor(h - n) }
              : { x: 0, y: 0 };
          l = document.createElement("div");
          l.style.cssText =
            "position:absolute;left:0;top:0;margin:0;padding:0;" +
            `width:${g}px;` +
            `height:${h}px;` +
            `transform:translate(${n.x}px, ${n.y}px)`;
          g = document.createElement("div");
          g.style.cssText =
            "position:absolute;left:0;top:0;margin:0;padding:0;" +
            `width:${c.width}px;` +
            `height:${c.height}px;` +
            'background-repeat:no-repeat;background-image:url("' +
            a +
            '");' +
            `background-position:-${c.left}px -${c.top}px;` +
            "transform-origin:0 0;" +
            `transform:scale(${k})`;
          l.appendChild(g);
          b.appendChild(l);
        })
      ),
    ]);
  }
  function nh(a, b) {
    return (a = new RegExp(a + "=([\\d]+)").exec(b)) ? a[1] : null;
  }
  function oh(a) {
    const b = nh("top", a),
      c = nh("left", a),
      d = nh("width", a);
    a = nh("height", a);
    return null !== b && null !== c && null !== d && null !== a
      ? {
          top: parseInt(b, 10),
          left: parseInt(c, 10),
          width: parseInt(d, 10),
          height: parseInt(a, 10),
        }
      : null;
  }
  class ph {}
  function qh(a) {
    const b = a.C;
    return "text" === a.F && x(b) && /\{[0-9]+}/g.test(b);
  }
  function rh(a, b, c, d) {
    (a = a.L) && a(b, new I(c, d));
  }
  class sh {
    constructor(a, b, c) {
      this.i = a.id;
      this.F = a.type || "text";
      this.C = "value" in a ? a.value : null;
      this.h = a.elp_id;
      this.D = !!a.hideOnEmptyValue;
      this.L = c;
    }
    o() {
      return ca(
        Ka(this.i).map((a) => this.g(a)),
        () => Promise.resolve()
      );
    }
    g() {
      return Promise.resolve();
    }
    m() {
      return ca(
        Ka(this.i).map((a) => this.s(a)),
        () => Promise.resolve()
      );
    }
    s() {
      return Promise.resolve();
    }
    I() {
      return !1;
    }
    getType() {
      return this.F;
    }
    N() {
      return this.C;
    }
  }
  function Q() {
    return Promise.resolve();
  }
  function th(a, b, c) {
    const d = (Array.isArray(b) ? b : [b]).map((e) =>
      null === e || void 0 === e ? "" : e
    );
    if (a && 0 < d.length) {
      const e = d.map((f, g) => ({ name: "value" + g, value: f }));
      return a
        .replace(/(\{[0-9]+})/g, (f, g) => {
          f = parseInt(g.substring(1, g.length - 1), 10);
          return f >= d.length ? g : d[f];
        })
        .replace(/({_[^}]+})/g, (f, g) => {
          f = g.substring(2, g.length - 1);
          g = e.map((k) => k.name).join(",");
          const h = e.map((k) => k.value);
          try {
            return (
              c.Function
                ? new c.Function(g, "return (" + f + ")")
                : new Function(g, "return (" + f + ")")
            ).apply(c, h);
          } catch (k) {
            console.error &&
              console.error(`Error evaluating expression: '${f}'`, k);
          }
          return "";
        });
    }
    return a;
  }
  function uh(a, b, c, d) {
    c = c || a.innerHTML || "";
    if (d && "" === b)
      return (
        (a.style.visibility = "hidden"),
        Promise.resolve(() => {
          a.style.removeProperty("visibility");
          return Promise.resolve();
        })
      );
    if (
      Array.isArray(b) ||
      (/\{[0-9]+}/.test(c) && !/\{[0-9]+}/.test(b || "")) ||
      /{_[^}]+}/.test(c)
    ) {
      const e = a.innerHTML;
      a.innerHTML = th(
        c,
        b || "         ".split(" "),
        a.ownerDocument.defaultView
      );
      return Promise.resolve(() => {
        a.innerHTML = e;
        return Promise.resolve();
      });
    }
    if (null != b) {
      const e = a.innerHTML;
      a.innerHTML = b;
      return Promise.resolve(() => {
        a.innerHTML = e;
        return Promise.resolve();
      });
    }
    return Promise.resolve(Q);
  }
  function vh(a, b, c) {
    c = c || a.value || "";
    if (
      Array.isArray(b) ||
      (/\{[0-9]+}/.test(c) && !/\{[0-9]+}/.test(b || "")) ||
      /{_[^}]+}/.test(c)
    ) {
      const d = a.value;
      a.value = th(c, b || "         ".split(" "), a.ownerDocument.defaultView);
      return Promise.resolve(() => {
        a.value = d;
        return Promise.resolve();
      });
    }
    if (null != b) {
      const d = a.value;
      a.value = b;
      return Promise.resolve(() => {
        a.value = d;
        return Promise.resolve();
      });
    }
    return Promise.resolve(Q);
  }
  function wh(a) {
    if (a && 0 < a.length) {
      const b = Lb(a),
        c = "http" + ("http:" === document.location.protocol ? "" : "s") + ":";
      if (qa(b.toLowerCase(), "http://")) return c + b.substring(5);
      if (qa(b, "//")) return c + b;
    }
    return a;
  }
  function xh(a, b, c) {
    const d = new IntersectionObserver(
      (e) => {
        e.forEach((f) => {
          f.isIntersecting &&
            f.target === a &&
            (d.unobserve(f.target), c(f.target));
        });
      },
      { rootMargin: b }
    );
    d.observe(a);
    return d;
  }
  function yh(a, b, c, d) {
    null != b && Array.isArray(b) && 0 < b.length && (b = b[0]);
    if ("" === b)
      return d
        ? ((a.style.visibility = "hidden"),
          Promise.resolve(() => {
            a.style.visibility = "inherit";
            return Promise.resolve();
          }))
        : Promise.resolve(() => Promise.resolve());
    const e = wh(b),
      f = dh();
    return ih(f, () => {
      const g =
          "undefined" !== typeof IntersectionObserver &&
          "lazy" === a.getAttribute("data-revjet-loading"),
        h = a.getAttribute("data-revjet-root-margin") || "100px",
        k = "none" !== a.getAttribute("data-revjet-preload"),
        l = a.getAttribute("data-revjet-image-src");
      return [g, h, k, a.src, l];
    }).then(([g, h, k, l, n]) => {
      let q;
      return kh(f, () => {
        n && a.removeAttribute("data-revjet-image-src");
        c && ((a.src = ""), k && !g && (new Image().src = e));
        g
          ? (q = xh(a, h, (v) => {
              v.src = e;
            }))
          : (a.src = e);
      }).then(() => () => {
        q && q.unobserve(a);
        a.src = l;
        n && a.setAttribute("data-revjet-image-src", n);
        return Promise.resolve();
      });
    });
  }
  function zh(a, b) {
    a.style.backgroundImage = `url("${b.replace(/"/g, "%22")}")`;
  }
  function Ah(a, b, c, d, e) {
    const f = wh(b);
    lh || (lh = new ph());
    if (d && (b = oh(d)))
      return mh(f, a, b, e).then(() => () => Promise.resolve());
    const g = dh();
    return ih(g, () => {
      const h =
          "undefined" !== typeof IntersectionObserver &&
          "lazy" === a.getAttribute("data-revjet-loading"),
        k = a.getAttribute("data-revjet-root-margin") || "100px",
        l = "none" !== a.getAttribute("data-revjet-preload");
      return [h, k, l, a.style.backgroundImage];
    }).then(([h, k, l, n]) => {
      let q;
      return kh(g, () => {
        c &&
          ((a.style.backgroundImage = "none"),
          l && !h && (new Image().src = f));
        h ? (q = xh(a, k, (v) => zh(v, f))) : zh(a, f);
      }).then(() => () => {
        q && a && q.unobserve(a);
        null == n || "" === n
          ? a.style.removeProperty("background-image")
          : zh(a, n);
        return Promise.resolve();
      });
    });
  }
  function Bh(a) {
    try {
      const b = JSON.parse(a);
      if (b && "object" === typeof b) return b;
    } catch (b) {}
    return !1;
  }
  function Ch(a) {
    const b = Bh(a || "{}");
    return !1 === b
      ? encodeURIComponent(a || "")
      : Object.keys(b)
          .map((c) => encodeURIComponent(c) + "=" + encodeURIComponent(b[c]))
          .join("&");
  }
  function Dh(a, b, c) {
    const d = r(
      ma("click_url")
        .map((e) => e.toString())
        .filter((e) => "" !== e && 0 !== e.indexOf("javascript:"))
        .map((e) => {
          var f = Ch(0 === Lb(c || "").length ? "$$suffix$$" : c);
          let g = e;
          const h = Ec();
          if (!0 === h.is_slot ? !0 === h.use_slot_level_click : 1)
            (f = f ? Ca(b, f) : b),
              Sa(f),
              (g += Ba(e) + ("" === f ? "" : "lp=" + encodeURIComponent(f)));
          Fa(a);
          a.setAttribute("data-revjet-click-url", g);
          const k = (l) => {
            db(l);
            cb(l);
            wb(l);
            window.revjet.elements_api.goToLP(l, g);
          };
          B(a, "click", k, !1);
          return () => {
            bb(a, "click", k, !1);
            a.removeAttribute("data-revjet-click-url");
            Ga(a);
            return Promise.resolve();
          };
        })
    );
    return Promise.resolve(() => (null != d ? d() : Promise.resolve()));
  }
  function Eh(a, b) {
    a = a.v;
    if (a.pb) {
      const c = document.createNSResolver(
        null == document.ownerDocument
          ? document.documentElement
          : document.ownerDocument.documentElement
      );
      b = document
        .evaluate(
          qa(a.pb, "//") ? "." + a.pb : a.pb,
          b,
          c,
          XPathResult.UNORDERED_NODE_ITERATOR_TYPE,
          null
        )
        .iterateNext();
      return u(b);
    }
    return t;
  }
  function Fh(a, b, c) {
    var d = a.getType();
    if ("text" === d) return uh(b, c, void 0, a.D);
    if ("image" === d && null != c)
      return (
        (d = G()),
        "IMG" === b.nodeName.toUpperCase() || b.getAttribute("src")
          ? yh(b, c, d.g, a.D)
          : Ah(b, c, d.g)
      );
    if ("video" === d && null != c) {
      a = (Array.isArray(c) ? c[0] : c) || {};
      c = a.video;
      null != c && (b.src = c);
      const e = a.poster;
      return null != e && "" !== e
        ? (b.setAttribute(
            "poster",
            "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
          ),
          (b.poster =
            "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"),
          new Promise((f) => {
            window.setTimeout(() => {
              b.setAttribute("poster", e);
              b.poster = e;
              f(Q);
            }, 16);
          }))
        : new Promise((f) => {
            window.setTimeout(() => f(Q), 16);
          });
    }
    return Promise.resolve(Q);
  }
  class Gh extends sh {
    constructor(a, b, c, d) {
      super(a, b, d);
      this.v = c;
      this.j = [];
    }
    o() {
      return ca(
        Ka(this.i)
          .flatMap((a) => Eh(this, a))
          .map((a) => this.g(a)),
        () => Promise.resolve()
      );
    }
    m() {
      return ca(
        Ka(this.i)
          .flatMap((a) => Eh(this, a))
          .map((a) => this.s(a)),
        () => Promise.resolve()
      );
    }
    g(a) {
      var b = this.h;
      b && ef(a, b);
      b = this.N();
      return Fh(this, a, b).then((c) => this.j.push(c));
    }
    s(a) {
      const b = this.h;
      b && ff(a, b);
      a = this.j;
      this.j = [];
      return Promise.all(a.reverse().map((c) => c()));
    }
  }
  class Hh {
    constructor(a, b, c, d, e, f) {
      this.h = a;
      this.g = b;
      this.j = c;
      this.i = d;
      this.s = e;
      this.m = f || "dataFeedItem";
    }
    $() {
      return this.m;
    }
  }
  function Ih(a, b, c, d, e) {
    try {
      const f = (
        a.Function
          ? new a.Function(d.join(","), `return ${b}`)
          : new Function(d.join(","), `return ${b}`)
      ).apply(a, e);
      return void 0 === f ? c : f;
    } catch (f) {
      console.error && console.error(`Error evaluating expression: '${b}'`, f);
    }
    return c;
  }
  function Jh(a, b, c, d) {
    const e = d.$();
    return Ih(
      a,
      b,
      c,
      [e, e + "Index", e + "Count", e + "Position", "params"],
      [d.h, d.g, d.j, d.i, d.s]
    );
  }
  function R(a, b, c) {
    return b.replace(/({_[^}]+})/g, (d, e) => {
      d = e
        .substring(2, e.length - 1)
        .replace("&lt;", "<")
        .replace("&gt;", ">");
      return Jh(a, `(${d})`, "", c);
    });
  }
  function Kh(a) {
    return a.exportRoot
      ? Promise.resolve(a.exportRoot)
      : a.AdobeAn && a.AdobeAn.bootstrapListeners
      ? new Promise((b) => {
          a.AdobeAn.bootstrapListeners = a.AdobeAn.bootstrapListeners.concat(
            () => b(a.exportRoot)
          );
        })
      : Promise.resolve();
  }
  function Lh(a) {
    a = a.text;
    return null != a && x(a);
  }
  function Mh(a) {
    const b = a.name;
    return null != b &&
      x(b) &&
      qa(b, "dataFeedItem_") &&
      (a.children || []).find((c) => null != c && c.image)
      ? !0
      : !1;
  }
  function Nh(a, b, c) {
    let d = [];
    const e = c.children || [];
    Lh(c) &&
      (c.text = R(b, c.text, new Hh(a[0], 0, a.length, 1, {}, "dataFeedItem")));
    if (Mh(c)) {
      const f = e.find((g) => null != g && g.image);
      c = c.name.replace("dataFeedItem_", "dataFeedItem.");
      (c = R(b, `{_${c}}`, new Hh(a[0], 0, a.length, 1, {}, "dataFeedItem"))) &&
        (d = d.concat(
          Ha(c).then((g) => {
            if (g) {
              var h = f.getBounds(),
                k = h.width * f.scaleX,
                l = h.height * f.scaleY;
              h = Math.min(k / g.width, l / g.height).toFixed(4);
              k = Math.floor(k / 2 - Math.floor(g.width * parseFloat(h)) / 2);
              l = Math.floor(l / 2 - Math.floor(g.height * parseFloat(h)) / 2);
              f.image = g;
              f.scaleX = h;
              f.scaleY = h;
              f.x += k;
              f.y += l;
            }
          })
        ));
    }
    d = d.concat(e.map((f) => Nh(a, b, f)));
    return Promise.all(d);
  }
  class Oh extends sh {
    I() {
      const a = this.N();
      return 0 === (null != a ? (Array.isArray(a) ? a : [a]) : []).length;
    }
    g(a) {
      const b = this.i,
        c = this.N(),
        d = null != c ? (Array.isArray(c) ? c : [c]) : [],
        e = a.defaultView || a.ownerDocument.defaultView || window;
      return this.I()
        ? (rh(this, b, "Empty personalization", 2), Promise.resolve())
        : Kh(e).then((f) => {
            if (f)
              return Nh(d, e, f).then(() => {
                f.stage && f.stage.update && f.stage.update();
              });
          });
    }
    s() {
      return Promise.resolve();
    }
  }
  function Ph(a, b, c) {
    const d = a.getAttribute("data-revjet-unique-by");
    return d
      ? ((a = Ih(a.ownerDocument.defaultView, d, null, ["params"], [b])),
        xa(c, a))
      : c;
  }
  function Qh(a, b, c) {
    const d = a.getAttribute("data-revjet-sort");
    if (d) {
      const e = a.getAttribute("data-revjet-each"),
        f = a.ownerDocument.defaultView;
      return c
        .slice()
        .sort((g, h) => Ih(f, d, 0, [e + "A", e + "B", "params"], [g, h, b]));
    }
    return c;
  }
  function Rh(a, b, c, d, e) {
    const f = 0 < d.length;
    e = e ? -1 : 1;
    var g = (h) => {
      if (f) {
        if (Array.isArray(h))
          return (
            (h = h.map((k) => d.indexOf(k)).find((k) => -1 !== k)),
            void 0 === h ? d.length : h
          );
        h = d.indexOf(h);
        return -1 === h ? d.length : h;
      }
      return Array.isArray(h) ? h[0] : h;
    };
    a = a[c];
    b = b[c];
    if ("sku_id" === c || "skuId" === c) (a = Ea(a)), (b = Ea(b));
    c = g(a);
    g = g(b);
    return x(c) && x(g) && c.localeCompare
      ? e * c.localeCompare(g)
      : e * (c < g ? -1 : c > g ? 1 : 0);
  }
  function Sh(a, b, c) {
    if (null == b || "" === b) return a;
    const d =
        null != c && "" !== c
          ? Lb(c)
              .split(";")
              .map((f) => Lb(f))
          : [],
      e = Lb(b)
        .split(",")
        .map((f) => Lb(f));
    return a.slice().sort((f, g) =>
      e
        .map((h, k) => {
          const l = Da(h);
          h = h.replace(/[\s]+(desc|asc)$/i, "");
          k = k < d.length ? d[k].split(",").map((n) => Lb(n)) : [];
          return Rh(f, g, h, k, l);
        })
        .reduce((h, k) => (h ? h : k), 0)
    );
  }
  function Th(a, b, c) {
    const d = a.getAttribute("data-revjet-order-by");
    if (d) {
      const e = a.getAttribute("data-revjet-each"),
        f = a.getAttribute("data-revjet-order-by-values");
      b = new Hh({}, 0, c.length, 0, b, e);
      a = a.ownerDocument.defaultView;
      return Sh(c, R(a, d, b), f ? R(a, f, b) : null);
    }
    return c;
  }
  function Uh(a) {
    a = a.getAttribute("data-revjet-params");
    try {
      return a ? JSON.parse(a) : {};
    } catch (b) {}
    return {};
  }
  function Vh(a, b, c) {
    return Jh(a, `!!(${b.replace("&lt;", "<").replace("&gt;", ">")})`, !1, c);
  }
  function Wh(a, b) {
    if (void 0 !== b && null !== b && "" !== b) {
      var c = G();
      const d = a.getAttribute("data-revjet-element-type");
      if ("text" === d)
        return (
          (c = a.getAttribute("data-revjet-element-template")), uh(a, b, c)
        );
      if ("value" === d)
        return (
          (c = a.getAttribute("data-revjet-element-template")), vh(a, b, c)
        );
      if ("image" === d) return yh(a, b, c.g);
      if ("background" === d) return Ah(a, b, c.g);
      if ("click_url" === d)
        return (
          (c = a.getAttribute("data-revjet-element-parameters")), Dh(a, b, c)
        );
    }
    return Promise.resolve(Q);
  }
  function Xh(a, b, c, d) {
    return b.replace(/({_[^}]+})/g, (e, f) => {
      e = f
        .substring(2, f.length - 1)
        .replace("&lt;", "<")
        .replace("&gt;", ">");
      f = c.$();
      return Ih(
        a,
        `(${e})`,
        "",
        [f, f + "Index", f + "Count", f + "Position", "click_url", "params"],
        [c.h, c.g, c.j, c.i, d, c.s]
      );
    });
  }
  function Yh(a, b, c, d) {
    return Promise.all(
      A(a, `[${c}]`).map((e) => {
        const f = e.getAttribute(c);
        return f
          ? d(e, R(a.ownerDocument.defaultView, f, b))
          : Promise.resolve(Q);
      })
    );
  }
  function Zh(a, b, c, d) {
    Fa(a);
    a.setAttribute("data-revjet-click-url", b);
    const e = (f) => {
      db(f);
      cb(f);
      wb(f);
      window.revjet.elements_api.goToLP(f, b, c, void 0, d);
    };
    B(a, "click", e, !1);
    return () => {
      bb(a, "click", e, !1);
      a.removeAttribute("data-revjet-click-url");
      Ga(a);
    };
  }
  function $h(a, b, c) {
    return a.length > b ? a.substring(0, b) + c : a;
  }
  function ai(a, b) {
    return Yh(a, b, "data-revjet-class", (c, d) => {
      const e = c.className;
      c.className = d;
      return Promise.resolve(() => {
        c.className = e;
        return Promise.resolve();
      });
    });
  }
  function bi(a, b) {
    return Yh(a, b, "data-revjet-style", (c, d) => {
      const e = c.style.cssText;
      c.style.cssText = d;
      return Promise.resolve(() => {
        c.style.cssText = e;
        return Promise.resolve();
      });
    });
  }
  function ci(a, b) {
    return Promise.all(
      A(a, "[data-revjet-exit]").map((c) => {
        const d = c.getAttribute("data-revjet-exit"),
          e = c.getAttribute("data-revjet-exit-target"),
          f = c.getAttribute("data-revjet-exit-tracker");
        if (!d) return Promise.resolve(Q);
        const g = a.ownerDocument.defaultView,
          h = r(
            ma("click_url")
              .map((k) => k.toString())
              .filter((k) => "" !== k && 0 !== k.indexOf("javascript:"))
              .map((k) => {
                k = Xh(g, d, b, k);
                const l = e ? R(g, e, b) : void 0,
                  n = f ? R(g, f, b) : void 0;
                return Zh(c, k, "" === l ? "_blank" : l, n);
              })
          );
        return Promise.resolve(() => {
          null != h && h();
          return Promise.resolve();
        });
      })
    );
  }
  function di(a, b) {
    return Promise.all(
      A(a, "[data-revjet-lp-exit]").map((c) => {
        const d = c.getAttribute("data-revjet-lp-exit"),
          e = c.getAttribute("data-revjet-exit-target"),
          f = c.getAttribute("data-revjet-exit-tracker");
        if (!d) return Promise.resolve(Q);
        const g = r(
          ma("click_url")
            .map((h) => h.toString())
            .filter((h) => "" !== h && 0 !== h.indexOf("javascript:"))
            .map((h) => {
              var k = a.ownerDocument.defaultView,
                l = R(k, d, b),
                n = Lb(c.getAttribute("data-revjet-lp-parameters") || "");
              n = Ch(0 === n.length ? "$$suffix$$" : n);
              const q = Ec();
              if (!0 === q.is_slot ? !0 === q.use_slot_level_click : 1)
                (l = "" !== l ? (n ? Ca(l, n) : l) : ""),
                  Sa(l),
                  (h +=
                    Ba(h) + ("" === l ? "" : "lp=" + encodeURIComponent(l)));
              c.setAttribute("data-revjet-click-url", h);
              l = e ? R(k, e, b) : void 0;
              k = f ? R(k, f, b) : void 0;
              return Zh(c, h, "" === l ? "_blank" : l, k);
            })
        );
        return Promise.resolve(() => {
          null != g && g();
          return Promise.resolve();
        });
      })
    );
  }
  function ei(a, b) {
    return Yh(a, b, "data-revjet-src", (c, d) => {
      if (d) {
        const e = G();
        return yh(c, d, e.g);
      }
      return Promise.resolve(Q);
    });
  }
  function fi(a, b) {
    return Yh(a, b, "data-revjet-srcset", (c, d) => {
      const e = c.srcset;
      c.srcset = d;
      return Promise.resolve(() => {
        c.srcset = e;
        return Promise.resolve();
      });
    });
  }
  function gi(a, b) {
    return Yh(a, b, "data-revjet-background-image", (c, d) => {
      if (d) {
        var e = c.getAttribute("data-revjet-auto-crop"),
          f = c.getAttribute("data-revjet-auto-crop-alignment"),
          g = a.ownerDocument.defaultView;
        e = e ? R(g, e, b) : void 0;
        f = f ? R(g, f, b) : void 0;
        g = G();
        return Ah(c, d, g.g, e, f);
      }
      return Promise.resolve(Q);
    });
  }
  function hi(a, b) {
    return Yh(a, b, "data-revjet-text", (c, d) => {
      var e = c.getAttribute("data-revjet-trim");
      d =
        e && d
          ? d.replace(new RegExp("^[" + e + "]+|[" + e + "]+$", "g"), "")
          : d;
      e = c.getAttribute("data-revjet-truncate");
      const f = c.getAttribute("data-revjet-truncate-after") || "\u2026",
        g = c.innerHTML;
      c.innerHTML = e && d ? $h(d, parseInt(e, 10), f) : d;
      return Promise.resolve(() => {
        c.innerHTML = g;
        return Promise.resolve();
      });
    });
  }
  function ii(a, b) {
    return Yh(a, b, "data-revjet-shrink", (c, d) => {
      if (d) {
        const e = c.hasAttribute("data-revjet-shrink-ellipsis"),
          f = c.hasAttribute("data-revjet-shrink-keep-line-height"),
          g = c.getAttribute("data-revjet-final-style");
        return nb(c, parseInt(d, 10), e, f, g).then((h) => h.Jb);
      }
      return Promise.resolve(Q);
    });
  }
  function ji(a, b) {
    return Yh(a, b, "data-revjet-value", (c, d) => {
      const e = c.value;
      c.value = d;
      return Promise.resolve(() => {
        c.value = e;
        return Promise.resolve();
      });
    });
  }
  function ki(a, b) {
    return Yh(a, b, "data-revjet-attribute-value", (c, d) => {
      const e = c.getAttribute("data-revjet-attribute-name");
      e && c.setAttribute(e, d || "");
      return Promise.resolve(() => {
        e && c.removeAttribute(e);
        return Promise.resolve();
      });
    });
  }
  function li(a, b) {
    return Yh(a, b, "data-revjet-alt", (c, d) => {
      const e = c.alt;
      c.alt = d;
      return Promise.resolve(() => {
        c.alt = e;
        return Promise.resolve();
      });
    });
  }
  function mi(a, b) {
    return Yh(a, b, "data-revjet-title", (c, d) => {
      const e = c.title;
      c.title = d;
      return Promise.resolve(() => {
        c.title = e;
        return Promise.resolve();
      });
    });
  }
  function ni(a, b) {
    return Promise.all(
      A(a, "[data-revjet-role]").map((c) => {
        var d = c.getAttribute("data-revjet-role");
        d = d ? b[d.toLowerCase()] : null;
        var e = c.getAttribute("data-revjet-alt-role");
        e = e ? b[e.toLowerCase()] : null;
        const f = d || e;
        return c.getAttribute("data-revjet-element-type")
          ? Wh(c, f)
          : Promise.all(
              A(c, "[data-revjet-element-type]").map((g) => Wh(g, f))
            ).then(
              (g) => () =>
                g.reverse().reduce((h, k) => h.then(k), Promise.resolve())
            );
      })
    );
  }
  function oi(a, b, c, d, e) {
    const f = b.getAttribute("data-revjet-required-fields");
    if (f) {
      const g = b.getAttribute("data-revjet-each");
      b = Lb(
        R(b.ownerDocument.defaultView, f, new Hh({}, 0, e.length, 0, c, g))
      );
      if ("" === b) return e;
      const h = b.split(",").map((k) => Lb(k));
      return e.reduce((k, l) => {
        const n = h.findIndex((q) => null == l[q] || "" === l[q]);
        -1 === n
          ? k.push(l)
          : rh(a, d, "Required field is missing: " + h[n], 3);
        return k;
      }, []);
    }
    return e;
  }
  function pi(a, b, c) {
    const d = (k) => {
      if (
        1 === k.nodeType &&
        k.hasAttribute &&
        k.hasAttribute("data-revjet-if")
      ) {
        var l = k.getAttribute("data-revjet-if");
        const n = b.ownerDocument.defaultView;
        if (l && !Vh(n, l, c)) {
          const q = k.parentNode,
            v = k.nextSibling;
          La(k);
          a.j.push(() => {
            q.insertBefore(k, v);
            return Promise.resolve();
          });
          return;
        }
      }
      for (l = 0; l < k.childNodes.length; l++) d(k.childNodes[l]);
    };
    d(b);
    const e = c.h,
      f = c.g,
      g = e.skuId || e.sku_id;
    null != g &&
      (b.setAttribute("data-revjet-sku-id", g),
      a.j.push(() => {
        b.removeAttribute("data-revjet-sku-id");
        return Promise.resolve();
      }));
    b.setAttribute("data-revjet-sku-pos", f + 1 + "");
    b.setAttribute("data-revjet-personalized", "");
    a.j.push(() => {
      b.removeAttribute("data-revjet-sku-pos");
      b.removeAttribute("data-revjet-personalized");
      return Promise.resolve();
    });
    const h = (k) => {
      a.j = a.j.concat(k);
    };
    return ai(b, c)
      .then(h)
      .then(() => bi(b, c).then(h))
      .then(() => ei(b, c).then(h))
      .then(() => fi(b, c).then(h))
      .then(() => hi(b, c).then(h))
      .then(() =>
        Promise.all([
          ii(b, c).then(h),
          ki(b, c).then(h),
          ji(b, c).then(h),
          li(b, c).then(h),
          mi(b, c).then(h),
          gi(b, c).then(h),
          ci(b, c).then(h),
          di(b, c).then(h),
          ni(b, e).then(h),
        ])
      );
  }
  class qi extends sh {
    constructor(a, b, c) {
      super(a, b, c);
      this.j = [];
    }
    N() {
      const a = super.N();
      return Array.isArray(a)
        ? a.map((b, c) =>
            null != b ? Object.assign({}, b, { index: String(c) }) : b
          )
        : a;
    }
    I() {
      const a = this.N();
      return 0 === (null != a ? (Array.isArray(a) ? a : [a]) : []).length;
    }
    g(a) {
      const b = this.i,
        c = this.N(),
        d = (null != c ? (Array.isArray(c) ? c : [c]) : []).filter(
          (e) => null != e
        );
      a = A(a, "[data-revjet-each]")
        .concat(A(a, '[data-revjet-element-type="block"]'))
        .filter((e) => {
          if (0 === d.length) {
            const h = e.getAttribute("data-revjet-if");
            var f = Uh(e),
              g = e.getAttribute("data-revjet-each");
            f = new Hh({}, 0, 0, 0, f, g);
            g = e.ownerDocument.defaultView;
            if (h && !Vh(g, h, f)) {
              const k = e.parentNode,
                l = e.nextSibling;
              La(e);
              this.j.push(() => {
                k.insertBefore(e, l);
                return Promise.resolve();
              });
              return !1;
            }
          }
          return !0;
        });
      if (this.I())
        return rh(this, b, "Empty personalization", 2), Promise.resolve();
      a = a.reduce((e, f) => {
        const g = Uh(f),
          h = Th(f, g, Qh(f, g, Ph(f, g, oi(this, f, g, b, d)))),
          k = f.getAttribute("data-revjet-if"),
          l = f.getAttribute("data-revjet-each");
        var n = f.getAttribute("data-revjet-block-start") || 1,
          q = f.getAttribute("data-revjet-block-count") || h.length;
        q = q > h.length ? h.length : q;
        const v = f.parentNode;
        let z = 0;
        var L = !1;
        let ra;
        --n;
        n < h.length &&
          ((ra = new Hh(h[n], n, h.length, z, g, l)),
          (L = f.ownerDocument.defaultView),
          (L = !(k && !Vh(L, k, ra))) && z++);
        let xg = f.nextSibling;
        for (let Za = 0; Za < q; Za++) {
          var $a = n + Za;
          if ($a < h.length && 0 < Za) {
            $a = new Hh(h[$a], $a, h.length, z, g, l);
            const jk = f.ownerDocument.defaultView;
            if (!k || Vh(jk, k, $a)) {
              const pc = f.cloneNode(!0);
              v.insertBefore(pc, xg);
              this.j.push(() => {
                La(pc);
                return Promise.resolve();
              });
              xg = pc.nextSibling;
              e = e.concat(pi(this, pc, $a));
              z++;
            }
          }
        }
        if (n < h.length)
          if (L) ra && (e = e.concat(pi(this, f, ra)));
          else {
            const Za = f.nextSibling;
            v.removeChild(f);
            this.j.push(() => {
              v.insertBefore(f, Za);
              return Promise.resolve();
            });
          }
        return e;
      }, []);
      return Promise.all(a);
    }
    s() {
      const a = this.j;
      this.j = [];
      return a.reverse().reduce((b, c) => b.then(c), Promise.resolve());
    }
  }
  function ri(a, b, c, d) {
    for (let e in c) c.hasOwnProperty(e) && si(a, e, b, c, d);
  }
  function si(a, b, c, d, e) {
    const f = G(),
      g = d[b];
    if (null != g) {
      var h = "hype_personalization" + (void 0 !== e ? "_" + e : "") + "_" + b;
      Ma(c, (k) => cf(k, h)).forEach((k) => {
        /image([0-9]+)?_link$/.test(b) ||
        /additional_image_link([0-9]+)?$/.test(b)
          ? Ah(k, g, f.g).then(
              (l) => a.j.push(l),
              () => {}
            )
          : uh(k, g).then((l) => a.j.push(l));
      });
    }
  }
  class ti extends sh {
    constructor(a, b, c) {
      super(a, b, c);
      this.j = [];
    }
    o() {
      const a = this.i;
      null != a && new Jg(a).listen("HypeSceneLoad", this.v.bind(this, a));
      return Promise.resolve();
    }
    m() {
      const a = this.j;
      this.j = [];
      return Promise.all(a.reverse().map((b) => b()));
    }
    v(a) {
      if ((a = zg(a))) {
        const b = r(Ka(a.ma.documentId()));
        a = this.N();
        Array.isArray(a)
          ? a.forEach((c, d) => ri(this, b, c, d))
          : ri(this, b, a);
      }
    }
  }
  function ui(a) {
    return A(a, "iframe[data-revjet-iframe-asset]").filter(
      (b) => null != b.contentWindow
    );
  }
  function vi(a) {
    return A(a, "[data-revjet-each]").concat(
      A(a, '[data-revjet-element-type="block"]')
    );
  }
  class wi extends sh {
    constructor(a, b, c) {
      super(a, b, c);
      this.v = new ti(a, b, c);
      this.j = new qi(a, b, c);
      this.H = new Oh(a, b, c);
    }
    I() {
      return this.v.I() || this.j.I();
    }
    g(a) {
      var b = this.h;
      b && ef(a, b);
      const c = this.j;
      b = this.v;
      const d = this.H;
      let e = [];
      const f = vi(a);
      a = ui(a).map((h) => h.contentWindow.document);
      const g = a.reduce((h, k) => h.concat(vi(k)), []);
      0 < f.length || 0 < g.length
        ? (0 < g.length && (e = e.concat(a.map((h) => c.g(h)))),
          0 < f.length && (e = e.concat(c.o())))
        : (e = e.concat(b.o()));
      0 < a.length && (e = e.concat(a.map((h) => d.g(h))));
      if (null != window.exportRoot || null != window.AdobeAn)
        e = e.concat(d.o());
      return Promise.all(e);
    }
    m() {
      return Promise.all([this.H.m(), this.v.m(), this.j.m()]);
    }
  }
  class xi extends sh {
    constructor(a, b, c, d) {
      super(a, b, d);
      this.H = c;
      this.j = [];
    }
    v() {
      return Promise.resolve(Q);
    }
    g(a) {
      const b = this.h;
      b && ef(a, b);
      const c = this.N();
      return Promise.all(
        A(a, `[data-revjet-element-type="${this.H}"]`).map((d) =>
          this.v(d, c).then((e) => this.j.push(e))
        )
      );
    }
    s(a) {
      const b = this.h;
      b && ff(a, b);
      a = this.j;
      this.j = [];
      return Promise.all(a.reverse().map((c) => c()));
    }
  }
  class yi extends xi {
    constructor(a, b, c) {
      super(a, b, "image", c);
    }
    v(a, b) {
      if (null != b) {
        const c = G();
        return yh(a, b, c.g, this.D);
      }
      return Promise.resolve(Q);
    }
  }
  class zi extends xi {
    constructor(a, b, c) {
      super(a, b, "text", c);
    }
    v(a, b) {
      return uh(a, b, void 0, this.D);
    }
  }
  class Ai extends sh {
    g(a) {
      var b = this.h;
      b && ef(a, b);
      b = this.N();
      if (null != b) {
        const c = Array.isArray(b) ? b[0] : b;
        return new Promise((d) => {
          var e = c.video;
          null != e && "" !== e && a.setAttribute("src", e);
          e = c.poster;
          null != e && "" !== e && a.setAttribute("poster", e);
          d();
        });
      }
      return Promise.resolve();
    }
    s(a) {
      const b = this.h;
      b && ff(a, b);
      return Promise.resolve();
    }
  }
  class Bi extends sh {
    g(a) {
      var b = this.h;
      b && ef(a, b);
      b = this.N();
      if (null != b) {
        const c = Array.isArray(b) ? b[0] : b;
        return new Promise((d) => {
          var e = c.video;
          null != e && "" !== e && a.setAttribute("src", e);
          e = c.poster;
          null != e && "" !== e && a.setAttribute("poster", e);
          d();
        });
      }
      return Promise.resolve();
    }
    s(a) {
      const b = this.h;
      b && ff(a, b);
      return Promise.resolve();
    }
  }
  class Ci extends sh {
    g(a) {
      var b = this.h;
      b && ef(a, b);
      b = this.N();
      if (null != b) {
        const c = Array.isArray(b) ? b : [b];
        return new Promise((d) => {
          const e = c
            .filter((f) => !!f.image_link)
            .map((f) => ({
              video: f.video || null,
              link: f.link || null,
              image: f.image_link,
            }));
          e.length && a.setAttribute("slides", JSON.stringify(e));
          d();
        });
      }
      return Promise.resolve();
    }
    s(a) {
      const b = this.h;
      b && ff(a, b);
      return Promise.resolve();
    }
  }
  function Di(a) {
    return (null == a ? [] : Array.isArray(a) ? a : [a]).some(
      (b) => null != b && "object" === typeof b && 0 < Object.keys(b).length
    );
  }
  function Ei(a) {
    return a.every(
      (b) => null != b && "string" === typeof b.type && "value" in b
    );
  }
  function Fi(a, b, c) {
    if (!b || 0 === b.length) return a;
    for (let d = 0; d < a.length; d++) {
      const e = a[d],
        f = b.find((g) => g.id === e.id);
      if (f)
        if ("html5" === f.type) {
          const g = [].concat(e.value),
            h = f.value;
          if (g.every((k) => !k.catalogSKU) && h.length)
            e.value = h.map((k, l) => Object.assign(k, g[l] || g[0]));
          else {
            const k = {};
            e.value = []
              .concat(e.value)
              .map((l) => {
                if (Array.isArray(h)) {
                  const n = h.find(
                    (q) => q.sku_id.split("$$")[1] == l.catalogSKU
                  );
                  n && ((k[n.sku_id] = !0), Object.assign(l, n));
                } else
                  h.sku_id.split("$$")[1] == l.catalogSKU &&
                    ((k[h.sku_id] = !0), Object.assign(l, h));
                "160x600" === c &&
                  l.headline &&
                  l.headline.length &&
                  (l.headline[0] = l.headline[0].replace(
                    new RegExp(String.fromCharCode(160), "g"),
                    " "
                  ));
                return l;
              })
              .concat(Array.isArray(h) ? h.filter((l) => !k[l.sku_id]) : []);
          }
        } else
          "object" === typeof e.value
            ? Object.assign(e.value, f.value || {})
            : "string" === typeof e.value && f.value && (e.value = f.value);
    }
    return a;
  }
  function Gi(a, b) {
    return b.map((c) => {
      if ("html5" !== c.type) return c;
      var d = c.value;
      const e = null != d ? [].concat(d) : [];
      d = a.map((f, g) => Object.assign({}, e[g] || {}, f));
      return Object.assign({}, c, { value: d });
    });
  }
  let Hi = null;
  function S() {
    Hi || (Hi = new T());
    return Hi;
  }
  function Ii(a, b) {
    a.j = null != b ? b : null;
  }
  function Ji(a, b) {
    if (null == a.j) return b;
    var c = G();
    a = a.j;
    c = `${c.xa() || window.innerWidth}x${c.ua() || window.innerHeight}`;
    Di(a) &&
      ((a = JSON.parse(
        JSON.stringify(null == a ? [] : Array.isArray(a) ? a : [a])
      )),
      (b = JSON.parse(JSON.stringify(b))),
      (b = Ei(a) ? Fi(a, b, c) : Gi(a, b)));
    return b;
  }
  function Ki(a, b, c) {
    return b
      .map((d, e) => Li(a, d, e, c))
      .sort((d, e) => (qh(d) ? -1 : qh(e) ? 1 : 0));
  }
  function Mi(a, b) {
    a.h = Ki(a, a.g, b);
  }
  function Li(a, b, c, d) {
    var e = b.type;
    a = u(a.s).flatMap((l) => U(l, b.id));
    var f = ea(
      a,
      (l) =>
        l.K("active_element") ||
        l.K("active_text_element") ||
        l.K("active_image_element") ||
        l.K("active_video_element")
    );
    const g = "text" === e,
      h = "image" === e,
      k = "html5" === e;
    e = "video" === e;
    if (f) {
      f = r(a.map((n) => n.Eb));
      const l = r(a.flatMap((n) => n.getParent()));
      if (null != f && null != l)
        return new Gh(
          Object.assign({}, b, { id: l.G(), type: f.type || b.type }),
          c,
          f,
          d
        );
    }
    return ea(a, (l) => l.K("yahoo_video_element"))
      ? new Bi(b, c, d)
      : ea(a, (l) => l.K("gallery_element"))
      ? new Ci(b, c, d)
      : g
      ? ((a = b.value),
        x(a) && "" !== a && sa(a) ? new yi(b, c, d) : new zi(b, c, d))
      : h
      ? ((a = b.value),
        (x(a) && "" !== a && !sa(a)) || null == a
          ? new zi(b, c, d)
          : new yi(b, c, d))
      : k
      ? new wi(b, c, d)
      : e
      ? new Ai(b, c, d)
      : new sh(b, c, d);
  }
  function Ni(a, b) {
    var c = document.body;
    "visibility" === b
      ? (c.style.visibility = a ? "visible" : "hidden")
      : "display" === b
      ? (c.style.display = a ? "block" : "none")
      : "opacity" === b && (c.style.opacity = a ? "1" : "0");
  }
  function Oi(a) {
    return m(function* () {
      const b = G();
      b.g && Ni(Cc(), b.i);
      const c = a.h;
      try {
        yield Promise.all(c.map((d) => d.o()));
      } catch (d) {
        console.error(d);
      }
      a.m = !0;
      !Cc() && b.g && (Ni(!0, b.i), yield Va());
    });
  }
  function Pi(a) {
    return m(function* () {
      const b = a.h;
      try {
        yield Promise.all(b.map((c) => c.m()));
      } catch (c) {
        console.error(c);
      }
    });
  }
  function Qi(a) {
    return a.h
      .filter((b) => "html5" === b.getType() && p(Ka(b.i)))
      .some((b) => b.I());
  }
  function Ri(a, b) {
    return (a = a.h.find((c) => c.i === b)) ? a.I() : !0;
  }
  function Si(a, b) {
    return Promise.all(a.h.filter((c) => c.i === b).map((c) => c.o()));
  }
  class T {
    constructor() {
      this.g = [];
      this.i = [];
      this.j = null;
      this.h = [];
      this.m = !1;
      this.o = 0;
      this.s = null;
    }
    Ba(a) {
      this.g = a.slice();
    }
    qd() {
      return this.g;
    }
    Ic(a, b, c, d) {
      this.Z(a, (e) =>
        e.map((f, g) => (g !== b ? f : Object.assign({}, f, { [c]: d })))
      );
    }
    La(a) {
      return da(
        u(this.g.find((b) => b.id === a)).map((b) => (b.value || []).length),
        0
      );
    }
    ja(a) {
      return da(
        u(this.g.find((b) => b.id === a)).map((b) => b.value || []),
        []
      );
    }
    Ua(a, b) {
      this.Z(a, (c) => c.filter((d, e) => e < b));
    }
    Ea(a, b, c) {
      this.Z(a, (d) => {
        const e = b.map((f) => {
          if ("sku_id" in f) return f;
          this.o++;
          return Object.assign({}, f, { sku_id: `static$$${this.o}` });
        });
        return c ? e.concat(d) : d.concat(e);
      });
    }
    Aa(a, b, c) {
      this.Z(a, (d) => {
        d = d.concat([]);
        for (let f = 0; f < d.length; f++) {
          const g = d[f];
          if (!g.__merged)
            for (let h = 0; h < d.length; h++) {
              var e = d[h];
              g !== e &&
                !e.___merged &&
                b(g, e) &&
                ((e = c ? Object.assign({}, c(g, e)) : Object.assign({}, e, g)),
                (d[f] = e),
                (d[h] = Object.assign({}, d[h], { ___merged: !0 })));
            }
        }
        return d.filter((f) => !f.___merged);
      });
    }
    Sa(a, b) {
      this.Aa(
        a,
        (c, d) =>
          null != c.sku_id && null != d.sku_id
            ? ((c = c.sku_id.replace(/^(.+\$\$)/, "")),
              (d = d.sku_id.replace(/^(.+\$\$)/, "")),
              -1 === c.indexOf("_") &&
                -1 !== d.indexOf("_") &&
                c === d.substring(0, d.lastIndexOf("_")))
            : !1,
        b
      );
    }
    wa(a) {
      return (a = a ? a.sku_id || a.skuId : null) ? Ea(a) : a;
    }
    Z(a, b) {
      this.g = this.g.map((c) => {
        if (c.id !== a) return c;
        const d = b(c.value || []);
        return Object.assign({}, c, { value: d });
      });
    }
    Fa(a, b, c) {
      this.Z(a, (d) => {
        const e = d.reduce((f, g) => f.concat(this.wa(g)), []);
        return d.concat(b.filter((f) => -1 === e.indexOf(f)).map((f) => c(f)));
      });
    }
    Cd(a, b) {
      for (let c in b)
        if (b.hasOwnProperty(c)) {
          const d = b[c],
            e = /^(.+)-([0-9]+)?$/.exec(c);
          e && this.Ic(a, e[2] - 1, e[1], d);
        }
    }
    kb() {
      return this.m;
    }
    Ia(a) {
      return m(function* () {
        var b = G(),
          c = b.F;
        if (!c) throw Error("personalizationURL is not configured");
        c = Ti(c, a);
        b = b.v;
        b =
          null != b
            ? yield fetch(c, {
                method: "POST",
                headers: {
                  "Content-Type":
                    "application/x-www-form-urlencoded; charset=utf-8",
                },
                body: b,
              })
            : yield fetch(c);
        if (!b.ok)
          throw Error(
            `Personalization request failed with status: ${b.status}`
          );
        return b.json();
      });
    }
  }
  T.prototype.fetchPersonalization = T.prototype.Ia;
  T.prototype.updateDataFeedWithHTML5Vars = T.prototype.Cd;
  T.prototype.addMissingSKU = T.prototype.Fa;
  T.prototype.updateDataFeed = T.prototype.Z;
  T.prototype.getSKUIds = T.prototype.wa;
  T.prototype.mergeSKUs = T.prototype.Sa;
  T.prototype.mergeDataFeedItems = T.prototype.Aa;
  T.prototype.addDataFeedItems = T.prototype.Ea;
  T.prototype.truncateDataFeed = T.prototype.Ua;
  T.prototype.getDataFeed = T.prototype.ja;
  T.prototype.getDataFeedLength = T.prototype.La;
  T.prototype.updateDataFeedItem = T.prototype.Ic;
  T.prototype.getPersonalizerConfig = T.prototype.qd;
  T.prototype.setPersonalizerConfig = T.prototype.Ba;
  function Ti(a, b) {
    const { elementPersonalizations: c, params: d, pixelId: e } = b || {};
    a = new URL(
      a.replace("__PIXEL__", e || "54"),
      a.startsWith("/") ? window.origin : void 0
    );
    b = a.searchParams;
    c &&
      0 < c.length &&
      b.set("__personalization", c.map((l) => l.id + ":" + l.elp_id).join(","));
    if (d)
      if ("string" === typeof d) {
        var f = new URLSearchParams(d.replace(/^[?&]+/, ""));
        const l = [];
        f.forEach((n, q) => {
          -1 === l.indexOf(q) && l.push(q);
        });
        for (const n of l) {
          const q = f.getAll(n);
          b.delete(n);
          for (const v of q) b.append(n, v);
        }
      } else for (f of Object.keys(d)) b.set(f, d[f]);
    const g = [],
      h = [];
    let k = 0;
    b.forEach((l, n) => {
      k++;
      const q = n + "=" + l;
      -1 === g.indexOf(q) && (g.push(q), h.push([n, l]));
    });
    if (h.length !== k) {
      for (const [l] of h) b.delete(l);
      for (const [l, n] of h) b.append(l, n);
    }
    return a;
  }
  function Ui(a) {
    return Promise.all(a.s.map((b) => Vi(a, b)));
  }
  function Wi(a) {
    const b = a.g;
    if (Fg(b)) {
      a.j = Gg(b);
      const c = Hg(b);
      Eg(b, c);
      window.setTimeout(() => Dg(b, "Main Timeline"), 0);
    }
    tg(a.i);
  }
  function Vi(a, b) {
    return m(function* () {
      Pg(b) && (yield b.load());
      return Pg(b) || Qg(b)
        ? Zg(b, () =>
            m(function* () {
              a.dispatchEvent(new F("load"));
              yield a.da(new F("before_personalization"));
              Si(S(), a.G()).then(() => {
                a.dispatchEvent(new F("after_personalization"));
                a.dispatchEvent(new F("before_show"));
                a.dispatchEvent(new F("show"));
              });
            })
          )
        : b;
    });
  }
  function Xi(a) {
    return m(function* () {
      return Pg(a) || (yield a.load(), Qg(a)) ? a : Zg(a);
    });
  }
  function Yi() {
    const a = M();
    return !(a.isEnabled() && a.g);
  }
  function Zi(a, b) {
    a = a.s;
    return 0 < a.length
      ? u(a.find((c) => b(c)))
          .flatMap((c) => u(c.na))
          .map((c) => c.contentWindow)
      : t;
  }
  class $i extends Vf {
    constructor(a, b) {
      super(a, "html5_element", b);
      this.j = void 0;
      this.g = new Jg(a);
      this.i = new ug(a);
      this.s = da(
        K(this).map((c) =>
          A(c, "[data-revjet-asset-src]").map((d) => new bh(a, d))
        ),
        []
      );
      this.listenOnce("before_show", () => Ui(this));
      this.listen("show", () => {
        Cg(this.g);
      });
      this.listen("hide", () => {
        this.pause();
      });
      this.listen("after_personalization", () => {
        M().addListener(() => Wi(this));
      });
    }
    ba(a, b) {
      const c = {
        play: this.play,
        pause: this.pause,
        stop: this.stop,
        hype_show_scene: this.Zc,
        hype_show_next_scene: this.Xc,
        hype_show_previous_scene: this.Yc,
        hype_start_timeline: this.$c,
        hype_pause_timeline: this.Wc,
        hype_continue_timeline: this.tb,
        bodymovin_play_segments: this.sb,
        bodymovin_go_to_and_stop: this.rb,
        bodymovin_go_to_and_play: this.qb,
      };
      a in c && c[a].call(this, b);
    }
    h() {
      super.h();
      this.s.map((a) => {
        const b = a.h;
        var c = b.getAttribute("data-revjet-asset-width"),
          d = b.getAttribute("data-revjet-asset-height");
        c = c ? c : "100%";
        d = d ? d : "100%";
        b.style.position = "absolute";
        b.style.left = "0";
        b.style.top = "0";
        b.style.width = c;
        b.style.height = d;
        "div" !== wc().deliveryWrapper && (a.na = Rg(c, d));
        a.g = "created";
      });
    }
    load() {
      return super.load().then(() => Promise.all(this.s.map((a) => Xi(a))));
    }
    refresh() {
      const a = this.s;
      if (0 !== a.length) {
        var b = 0,
          c = () => {
            const d = this;
            return m(function* () {
              b++;
              b >= a.length &&
                (d.dispatchEvent(new F("load")),
                yield d.da(new F("before_personalization")),
                Si(S(), d.G()).then(() => {
                  d.dispatchEvent(new F("after_personalization"));
                  d.dispatchEvent(new F("before_show"));
                }));
            });
          };
        Promise.all(a.map((d) => d.refresh(c))).then(() => {
          this.dispatchEvent(new F("show"));
        });
      }
    }
    play() {
      if (Yi()) {
        var a = this.g,
          b = this.i;
        if (!Fg(a)) {
          const c = Hg(a);
          P(a, "currentTimeInTimelineNamed", "Main Timeline") >= c
            ? P(a, "startTimelineNamed", "Main Timeline", this.j)
            : P(a, "continueTimelineNamed", "Main Timeline", this.j, !1);
        }
        b.play();
      }
    }
    stop() {
      const a = this.g,
        b = this.i;
      Fg(a) && ((this.j = Gg(a)), Dg(a, "Main Timeline"), Eg(a, 0));
      b.stop();
    }
    pause() {
      const a = this.g,
        b = this.i;
      Fg(a) && ((this.j = Gg(a)), Dg(a, "Main Timeline"));
      b.pause();
    }
    Zc(a) {
      const b = this.g,
        c = a.transition ? Ig(b, a.transition) : void 0;
      P(b, "showSceneNamed", a.sceneName, c, a.duration);
    }
    Xc(a) {
      const b = this.g;
      a = a.transition ? Ig(b, a.transition) : void 0;
      P(b, "showNextScene", a);
    }
    Yc(a) {
      const b = this.g;
      a = a.transition ? Ig(b, a.transition) : void 0;
      P(b, "showPreviousScene", a);
    }
    $c(a) {
      const b = this.g,
        c = a.direction ? Ig(b, a.direction) : void 0;
      P(b, "startTimelineNamed", a.timelineName, c);
    }
    Wc(a) {
      Dg(this.g, a.timelineName);
    }
    tb(a) {
      const b = this.g,
        c = a.direction ? Ig(b, a.direction) : void 0;
      P(b, "continueTimelineNamed", a.timelineName, c, a.canRestartTimeline);
    }
    sb(a) {
      Yi() &&
        ((a = a.segments),
        null != a &&
          "" !== a &&
          ((a = a.split(",").map((b) => parseInt(b, 10))),
          2 < a.length &&
            (a = a.reduce(
              (b, c) => {
                2 > b[b.length - 1].length
                  ? b[b.length - 1].push(c)
                  : b.push([c]);
                return b;
              },
              [[]]
            )),
          od("Html5").info("Playing segments", a),
          this.i.playSegments(a)));
    }
    rb(a) {
      a = a.frame;
      null != a && "" !== a && this.i.goToAndStop(parseInt(a, 10));
    }
    qb(a) {
      Yi() &&
        ((a = a.frame),
        null != a && "" !== a && this.i.goToAndPlay(parseInt(a, 10)));
    }
    Ja(a) {
      return null != a && "" !== a
        ? Zi(this, (b) => b.h.getAttribute("data-revjet-asset-name") === a)
        : Zi(this, () => !0);
    }
    Ka(a) {
      return null != a && "" !== a
        ? Zi(this, (b) => Sg(b) === a)
        : Zi(this, () => !0);
    }
  }
  class aj extends Vf {
    constructor(a, b) {
      super(a, "image_element", b);
    }
    h() {
      super.h();
    }
  }
  function bj(a) {
    function b(c) {
      let d;
      null == (d = c.ca) || tf(d);
      c.S.forEach((e) => b(e));
    }
    b(a);
  }
  class cj extends Vf {
    constructor(a, b) {
      super(a, "root", b);
      this.listen("after_personalization", () => {
        const c = M();
        c.addListener(() => bj(this));
        c.start();
      });
    }
    za() {
      return !0;
    }
    H() {
      return this;
    }
  }
  class dj extends Vf {
    constructor(a, b) {
      super(a, "text_element", b);
    }
  }
  function ej(a) {
    K(a).forEach((b) => {
      if (a.g && b.isPaused && b.isPaused()) b.onAction("play");
    });
    a.g = !1;
  }
  function fj(a) {
    K(a).forEach((b) => {
      b.isPaused && !b.isPaused() && (b.onAction("pause"), (a.g = !0));
    });
  }
  class gj extends Vf {
    constructor(a, b) {
      super(a, "video_element", b);
      this.g = !1;
      if ((this.i = !!b.pauseOnNotViewable))
        this.listen("viewable", () => ej(this)),
          this.listen("not_viewable", () => fj(this));
      this.listen("hide", () => {
        this.ba("stop", {});
      });
    }
    h() {
      super.h();
      if (this.i) {
        const a = We();
        af(a, this) || a.h.push(this);
      }
    }
    ba(a, b) {
      K(this).forEach((c) => {
        if (c.onAction) c.onAction(a, b);
      });
    }
  }
  class hj extends Vf {
    constructor(a, b) {
      super(a, "yahoo_video_element", b);
    }
    ba(a, b) {
      K(this).forEach((c) => {
        if (c.onAction) c.onAction(a, b);
      });
    }
  }
  const ij = {
    unknown: Uf,
    root: function (a, b) {
      return new cj(a, b);
    },
    body_element: function (a, b) {
      return new rg(a, b);
    },
    video_element: function (a, b) {
      return new gj(a, b);
    },
    audio_element: function (a, b) {
      return new pg(a, b);
    },
    html5_element: function (a, b) {
      return new $i(a, b);
    },
    image_element: function (a, b) {
      return new aj(a, b);
    },
    yahoo_video_element: function (a, b) {
      return new hj(a, b);
    },
    text_element: function (a, b) {
      return new dj(a, b);
    },
    frame_element: function (a, b) {
      return new qg(a, b);
    },
  };
  class jj extends F {
    constructor(a) {
      super("before_form_load", { formId: a });
    }
    ea() {
      return this.A("formId");
    }
    g(a) {
      return a.formId === this.ea();
    }
  }
  jj.prototype.getFormId = jj.prototype.ea;
  class kj extends F {
    constructor(a) {
      super("bodymovin_complete", { animationName: a });
    }
    J() {
      return this.A("animationName");
    }
    g(a) {
      return a.animationName === this.J();
    }
  }
  kj.prototype.getAnimationName = kj.prototype.J;
  class lj extends F {
    constructor(a) {
      super("bodymovin_loop_complete", { animationName: a });
    }
    J() {
      return this.A("animationName");
    }
    g(a) {
      return a.animationName === this.J();
    }
  }
  lj.prototype.getAnimationName = lj.prototype.J;
  class mj extends F {
    constructor(a) {
      super("bodymovin_segment_start", { animationName: a });
    }
    J() {
      return this.A("animationName");
    }
    g(a) {
      return a.animationName === this.J();
    }
  }
  mj.prototype.getAnimationName = mj.prototype.J;
  class nj extends F {
    constructor(a) {
      super("bodymovin_start", { animationName: a });
    }
    J() {
      return this.A("animationName");
    }
    g(a) {
      return a.animationName === this.J();
    }
  }
  nj.prototype.getAnimationName = nj.prototype.J;
  function oj(a, b) {
    return new pj(b.className, !!b.re, a, b);
  }
  class pj extends O {
    constructor(a, b, c, d) {
      super(c, d);
      this.g = a;
      this.j = b;
    }
    B(a) {
      super.B(a);
      a = a.M;
      const b = this.getType();
      Ff(this, a).forEach((c) => {
        if ("add_class" === b)
          cf(c, this.g) ||
            (df(c, this.g), c.setAttribute("data-added-class-name", this.g));
        else if ("remove_class" === b)
          if (this.j) {
            var d = new RegExp(this.g, "i");
            const e = bf(c);
            for (let f = 0; f < e.length; f++) {
              const g = e[f];
              d.test(g) && ff(c, g);
            }
          } else if ("" === this.g) {
            if ((d = c.getAttribute("data-added-class-name")))
              ff(c, d), c.removeAttribute("data-added-class-name");
          } else ff(c, this.g);
      });
    }
  }
  class qj extends F {
    constructor(a) {
      super("animation_end", { animationName: a });
    }
    J() {
      return this.A("animationName");
    }
    g(a) {
      return a.animationName === this.J();
    }
  }
  qj.prototype.getAnimationName = qj.prototype.J;
  class rj extends F {
    constructor(a) {
      super("animation_iteration", { animationName: a });
    }
    J() {
      return this.A("animationName");
    }
    g(a) {
      return a.animationName === this.J();
    }
  }
  rj.prototype.getAnimationName = rj.prototype.J;
  class sj extends F {
    constructor(a) {
      super("animation_start", { animationName: a });
    }
    J() {
      return this.A("animationName");
    }
    g(a) {
      return a.animationName === this.J();
    }
  }
  sj.prototype.getAnimationName = sj.prototype.J;
  let tj = 0;
  function uj(a, b) {
    return new vj(a, b);
  }
  function wj(a) {
    const b = a.ca;
    null != b && (tf(b), vf(b), (a.ca = null));
  }
  function xj(a, b, c) {
    b.sa = c;
    const d = a.j,
      e = a.g,
      f = a.m,
      g = a.o,
      h = a.C;
    0 !== d.length &&
      K(b).forEach((k) => {
        b.dispatchEvent(E(new sj(e), c));
        k = new wf(k, d, f, g, h);
        b.ca = k;
        of(k, () => {
          b.dispatchEvent(E(new qj(e), c));
          const l = b.ca;
          null != l && (vf(l), (b.ca = null));
        });
        tf(k);
      });
  }
  function yj(a, b, c) {
    b.sa = c;
    const d = a.j,
      e = a.g,
      f = a.m,
      g = a.o,
      h = a.C;
    0 !== d.length &&
      K(b).forEach((k) => {
        k = new wf(k, d, f, g, h);
        b.ca = k;
        nf(k, () => {
          b.dispatchEvent(E(new sj(e), c));
        });
        of(k, () => {
          b.dispatchEvent(E(new qj(e), c));
          const l = b.ca;
          null != l && (vf(l), (b.ca = null));
        });
        pf(k, () => {
          b.dispatchEvent(E(new rj(e), c));
        });
        sf(k);
      });
  }
  class vj extends O {
    constructor(a, b) {
      super(a, b);
      this.g = b.animationName || `animation-${++tj}`;
      a = b.className;
      const c = b.classNames || [];
      this.j = 0 < c.length ? c : a ? [a] : [];
      this.m = u(b.finalClassName);
      this.o = b.finalStyle || [];
      this.C = b.iterationCount || 1;
    }
    B(a) {
      super.B(a);
      const b = a.V;
      Gf(this, a.M).forEach((c) => {
        var d = this.getType();
        "start_animation" === d
          ? (wj(c),
            (d = M()),
            d.isEnabled() && d.g ? xj(this, c, b) : yj(this, c, b))
          : "stop_animation" === d && wj(c);
      });
    }
  }
  class zj extends O {
    constructor(a, b) {
      super(a, b);
      this.g = b.cssText;
    }
    B(a) {
      super.B(a);
      const b = a.M;
      Ff(this, b).forEach(() => {
        a: {
          var c = b.G();
          const f = this.g;
          if (null != f && "" !== f) {
            var d = document.getElementsByTagName("HEAD")[0] || document.body,
              e = d.getElementsByTagName("STYLE");
            for (const g of e)
              if (
                g.getAttribute("data-revjet-widget-id") === c &&
                g.getAttribute("data-revjet-css-text") === f
              ) {
                c = void 0;
                break a;
              }
            e = document.createElement("STYLE");
            e.type = "text/css";
            (d || document.getElementsByTagName("HEAD")[0]).appendChild(e);
            e.styleSheet
              ? (e.styleSheet.cssText = f)
              : e.appendChild(document.createTextNode(f));
            d = e;
            d.setAttribute("data-revjet-widget-id", c);
            d.setAttribute("data-revjet-css-text", f);
          }
          c = void 0;
        }
        return c;
      });
    }
  }
  class Aj extends O {
    constructor(a) {
      super("close", a);
    }
    B(a) {
      super.B(a);
      a.M.O(new F("close"));
      va("close", y(), {});
      a = rc();
      tc(a) && a.collapse();
    }
  }
  function Bj(a, b) {
    a = new Cj(a, b);
    b.method && (a.g = b.method);
    b.position && (a.j = b.position);
    if (null != b.duration && "" !== b.duration) {
      const c = b.duration;
      a.o = ka(c) ? c : parseInt(c, 10);
    }
    b.animationType && (a.m = b.animationType);
    b.timing && (a.C = b.timing);
    return a;
  }
  function Dj(a) {
    return "display" === a.g ? "display" : "visibility";
  }
  function Ej(a, b) {
    return "display" !== a.g
      ? "visible"
      : (b && b.getAttribute("data-revjet-display")) || "block";
  }
  function Fj(a, b, c) {
    if ("display" === a.g)
      C(b, "visibility", "hidden"),
        C(b, "display", Ej(a, b)),
        window.setTimeout(() => {
          const d = b.getBoundingClientRect();
          C(b, "display", "none");
          C(b, "visibility", "visible");
          window.setTimeout(c.bind(a, d), 0);
        }, 0);
    else {
      const d = b.getBoundingClientRect();
      window.setTimeout(c.bind(a, d), 0);
    }
  }
  function Gj(a, b, c) {
    a && a.dispatchEvent(E(new F(b), c));
  }
  function Hj(a, b, c, d, e) {
    const f = a.C;
    a = M().va(a.o);
    return new tb(b, a, d, e, [{ oc: c, duration: a, timing: f, delay: 0 }]);
  }
  function Ij(a, b, c, d, e, f, g) {
    const h = Ej(a, c);
    Gj(b, "before_show", g);
    b.U = !0;
    C(c, d);
    const k = Jj(b, c);
    C(c, Dj(a), h);
    sb(f, () => {
      C(c, e);
      b.U = !1;
      k && C(c, "overflow", k);
      Gj(b, "show", g);
    });
    f.play();
  }
  function Kj(a, b, c, d, e, f) {
    b.U = !0;
    C(c, {});
    const g = Jj(b, c);
    sb(e, () => {
      C(c, Dj(a), "display" === a.g ? "none" : "hidden");
      C(c, d);
      b.U = !1;
      g && C(c, "overflow", g);
      Gj(b, "hide", f);
    });
    e.play();
  }
  function Jj(a, b) {
    a = a.getType();
    if (
      "frame_element" === a ||
      "frames_element" === a ||
      "container_element" === a
    )
      if (((a = jb(b, "overflow")), "hidden" !== a))
        return C(b, "overflow", "hidden"), a;
    return null;
  }
  class Cj extends O {
    constructor(a, b) {
      super(a, b);
      this.g = "display";
      this.j = "as_is";
      this.o = 0;
      this.C = "ease";
      this.m = "none";
    }
    B(a) {
      super.B(a);
      const b = a.V,
        c = this.m;
      Gf(this, a.M)
        .filter((d) => "none" === c || !d.U)
        .forEach((d) => {
          K(d).forEach((e) => {
            var f = this.getType(),
              g = this.j;
            if ("show" === f && (d.oa() || "as_is" !== g)) {
              this.j && "as_is" !== this.j && d.Fb(this.j);
              g = {
                none: this.Za,
                fade: this.Ya,
                slide: this.rb,
                slide_left: this.ab,
                slide_right: this.qb,
                slide_up: this.sb,
                slide_down: this.$a,
              };
              const h = 0 === M().va(this.o) ? "none" : this.m;
              h in g && g[h].call(this, d, e, b);
            }
            "hide" !== f ||
              d.oa() ||
              (d.tc(),
              (f = {
                none: this.L,
                fade: this.H,
                slide: this.ia,
                slide_left: this.X,
                slide_right: this.ha,
                slide_up: this.Wa,
                slide_down: this.R,
              }),
              (g = this.m),
              g in f && f[g].call(this, d, e, b));
          });
        });
    }
    Za(a, b, c) {
      Gj(a, "before_show", c);
      C(b, Dj(this), Ej(this, b));
      Gj(a, "show", c);
    }
    Ya(a, b, c) {
      const d = Hj(this, b, "opacity", { opacity: "0" }, { opacity: "1" });
      Ij(this, a, b, { opacity: "0" }, { opacity: "1" }, d, c);
    }
    rb(a, b, c) {
      const d = D(b),
        e = Hj(
          this,
          b,
          "height",
          { height: "0px" },
          { height: d.height + "px" }
        );
      Ij(this, a, b, { height: "0px" }, { height: d.height + "px" }, e, c);
    }
    ab(a, b, c) {
      Fj(this, b, (d) => {
        const e = b.parentElement.getBoundingClientRect().width,
          f = Hj(this, b, "left", { left: e + "px" }, { left: d.left + "px" });
        Ij(this, a, b, { left: e + "px" }, { left: d.left + "px" }, f, c);
      });
    }
    qb(a, b, c) {
      Fj(this, b, (d) => {
        const e = D(b),
          f = Hj(
            this,
            b,
            "left",
            { left: "-" + e.width + "px" },
            { left: d.left + "px" }
          );
        Ij(
          this,
          a,
          b,
          { left: "-" + e.width + "px" },
          { left: d.left + "px" },
          f,
          c
        );
      });
    }
    sb(a, b, c) {
      Fj(this, b, (d) => {
        const e = b.parentElement.getBoundingClientRect().height,
          f = Hj(this, b, "top", { top: e + "px" }, { top: d.top + "px" });
        Ij(this, a, b, { top: e + "px" }, { top: d.top + "px" }, f, c);
      });
    }
    $a(a, b, c) {
      Fj(this, b, (d) => {
        const e = D(b),
          f = Hj(
            this,
            b,
            "top",
            { top: "-" + e.height + "px" },
            { top: d.top + "px" }
          );
        Ij(
          this,
          a,
          b,
          { top: "-" + e.height + "px" },
          { top: d.top + "px" },
          f,
          c
        );
      });
    }
    L(a, b, c) {
      C(b, Dj(this), "display" === this.g ? "none" : "hidden");
      Gj(a, "hide", c);
    }
    H(a, b, c) {
      const d = Hj(this, b, "opacity", { opacity: "1" }, { opacity: "0" });
      Kj(this, a, b, { opacity: "1" }, d, c);
    }
    ia(a, b, c) {
      const d = D(b),
        e = Hj(this, b, "height", {}, { height: "0px" });
      Kj(this, a, b, { height: d.height + "px" }, e, c);
    }
    X(a, b, c) {
      var d = D(b);
      const e = b.getBoundingClientRect();
      d = Hj(
        this,
        b,
        "left",
        { left: e.left + "px" },
        { left: "-" + d.width + "px" }
      );
      Kj(this, a, b, { left: e.left + "px" }, d, c);
    }
    ha(a, b, c) {
      const d = b.getBoundingClientRect();
      var e = b.parentElement.getBoundingClientRect().width;
      e = Hj(this, b, "left", { left: d.left + "px" }, { left: e + "px" });
      Kj(this, a, b, { left: d.left + "px" }, e, c);
    }
    Wa(a, b, c) {
      const d = b.getBoundingClientRect();
      var e = D(b);
      e = Hj(
        this,
        b,
        "top",
        { top: d.top + "px" },
        { top: "-" + e.height + "px" }
      );
      Kj(this, a, b, { top: d.top + "px" }, e, c);
    }
    R(a, b, c) {
      const d = b.getBoundingClientRect();
      var e = b.parentElement.getBoundingClientRect().height;
      e = Hj(this, b, "top", { top: d.top + "px" }, { top: e + "px" });
      Kj(this, a, b, { top: d.top + "px" }, e, c);
    }
  }
  function Lj(a) {
    const b = rc();
    if (a.j || !tc(b)) va("collapse", y(), a.P());
    else if (2 === b.g) {
      b.g = 3;
      const c = () => {
        b.removeEventListener(4, c);
        b.g = 1;
      };
      va("collapse", y(), a.P());
      b.addEventListener(4, c);
      b.collapse();
    }
  }
  class Mj extends O {
    constructor(a) {
      super("collapse", a);
      this.g = !!a.onlyContainer;
      this.j = !!a.skipMraid;
    }
    B(a) {
      super.B(a);
      this.g ? va("collapse", y(), this.P()) : Lj(this);
    }
  }
  let Nj = null;
  function V() {
    Nj || (Nj = new Oj());
    return Nj;
  }
  function Pj(a) {
    if (a.g) return a.g;
    a.g = (() => {
      let b = [window.top];
      const c = wc().vpaid_wrapper_key;
      if (null == c) return null;
      for (; 0 < b.length; ) {
        var d = b.shift();
        try {
          if (null != d.getVPAIDAd && null != d._getVPAIDWrapperByKey)
            return d._getVPAIDWrapperByKey(c);
        } catch (e) {}
        d = d.frames;
        for (let e = 0; e < d.length; e++) b.push(d[e]);
      }
      return null;
    })();
    return a.g;
  }
  class Oj {
    constructor() {
      this.g = null;
    }
    T() {
      return Pj(this);
    }
  }
  Oj.prototype.getWrapperObject = Oj.prototype.T;
  let Qj = { timestamp: null, vb: !1 };
  function Rj() {
    return od("OpenLink");
  }
  function Sj() {
    let a = window;
    for (; a; ) {
      try {
        const b = a.androidBridge;
        if (b) return new ia(b);
      } catch (b) {}
      a = a === a.parent ? null : a.parent;
    }
    return t;
  }
  function Tj() {
    const a = new Date().getTime(),
      b = Qj.timestamp;
    return null !== b && b + 200 >= a
      ? { timestamp: b, vb: !0 }
      : { timestamp: a, vb: !1 };
  }
  function Uj() {
    let a = window;
    for (; a; ) {
      try {
        const b = a.Pandora;
        if (b) return new ia(b);
      } catch (b) {}
      a = a === a.parent ? null : a.parent;
    }
    return t;
  }
  function Vj() {
    let a = window;
    for (; a; ) {
      try {
        const b = a.location;
        if (
          a.mopubFinishLoad ||
          (b && b.href && -1 !== b.href.indexOf("ads.mopub.com"))
        )
          return !0;
      } catch (b) {}
      a = a === a.parent ? null : a.parent;
    }
    return !1;
  }
  function Wj() {
    let a = window,
      b;
    try {
      for (; a !== window.top; ) (a = a.parent), (b = a.location.href);
    } catch (c) {}
    return b || window.location.toString();
  }
  function Xj(a) {
    const b = V().T();
    b && b.adClickThru(a, !1);
  }
  function Yj(a) {
    J(Rj(), "Using simulated anchor click to open URL");
    var b = document.createElement("a");
    b.setAttribute("href", a);
    b.setAttribute("target", "_blank");
    b.style.display = "none";
    document.documentElement.appendChild(b);
    a = document.createEvent("HTMLEvents");
    a.initEvent("click", !0, !0);
    b.dispatchEvent(a);
    La(b);
  }
  function Zj(a, b) {
    J(Rj(), "Opening URL using window.open");
    "_blank" === b
      ? window.open(a, b)
      : "_top" === b
      ? (window.top.location.href = a)
      : "_parent" === b
      ? (window.parent.location.href = a)
      : (window.location.href = a);
  }
  class ak extends O {
    constructor(a) {
      super("link", a);
      this.j = a.url;
      this.H = a.target || "_blank";
      this.m = a.customRole;
      this.g = a.tracker;
      this.o = a.skuId;
      this.C = a.skuPos;
    }
    Ab() {
      return this.j;
    }
    s() {
      return !1;
    }
    B(a) {
      super.B(a);
      var b = a.M,
        c = a.V;
      a = (this.j || "").toString();
      var d = this.H;
      if (
        a &&
        0 !== a.indexOf("javascript:") &&
        0 !== a.indexOf("&") &&
        0 !== a.indexOf("?")
      ) {
        if ((a = Rc(Mc(), a, this.m, this.o, this.C)))
          if (
            (-1 !== Wa.indexOf("Android") &&
              p(Sj()) &&
              (a = a + "&clickurl=" + encodeURIComponent(a)),
            (Qj = Tj()),
            Qj.vb)
          )
            J(Rj(), "Double triggering detected: ", a, d);
          else {
            J(Rj(), "Opening URL: ", a, d);
            if (this.g) {
              var e = r(
                K(b).flatMap((l) => u(l.getAttribute("data-revjet-role-id")))
              );
              $c().Y([{ url: this.g, type: "image", roleId: e }]);
            }
            e = rc().i;
            var f = Uj(),
              g = -1 === Wa.indexOf("Android") && Vj(),
              h = Mc(),
              k = h.h;
            h = h.g;
            k = new Gb(
              a,
              d,
              null == k ? void 0 : k.cx,
              null == k ? void 0 : k.cy,
              null == h ? void 0 : h.eb,
              null == h ? void 0 : h.ch,
              null == h ? void 0 : h.bb
            );
            E(k, c);
            c = null == c ? void 0 : c.A("button");
            null != c && Eb(k, c);
            "_blank" !== d ||
              p(e) ||
              p(f) ||
              g ||
              (k.h = Object.assign({}, k.h, { pixelDelay: 150 }));
            b.dispatchEvent(k);
            p(e)
              ? (J(Rj(), "Using MRAID API to open URL"),
                (b = Wj()),
                (d = a.split("?")),
                b &&
                -1 !== b.indexOf("Unity") &&
                -1 !== b.indexOf("webPlayerMraid") &&
                2 === d.length
                  ? ((b =
                      d[0] +
                      "?" +
                      d[1].split("&").map(decodeURIComponent).join("&")),
                    e.get().mraid.open(b))
                  : e.get().mraid.open(a))
              : (Xj(a),
                p(f)
                  ? (J(Rj(), "Using openLandingPage API to open URL"),
                    f.get().openLandingPage({ pageURL: a }))
                  : g
                  ? Yj(a)
                  : Zj(a, d));
          }
      } else J(Rj(), "Invalid URL:", a);
    }
  }
  class bk extends ak {
    constructor(a) {
      super(a);
      this.h = "complete";
    }
    B(a) {
      a.M.dispatchEvent(E(new F("complete"), a.V));
      super.B(a);
    }
  }
  function ck(a, b) {
    for (let d = 0; d < b.length; d++) {
      var c = b[d];
      if (c.K("frame_element") || (c = ck(a, c.S))) return c;
    }
    return null;
  }
  function dk(a, b) {
    b.M.dispatchEvent(E(new F("expand_start"), b.V));
    b = y();
    a = Object.assign({}, a.P(), {});
    va("expand", b, a);
  }
  function ek(a, b, c) {
    const d = c.M;
    let e = b;
    const f = ck(a, b.S),
      g = f || b;
    f ||
      (e = da(
        b.getParent().filter((q) => q.K("frame_element")),
        e
      ));
    if (e) {
      for (var h = u(d); p(h) && "frame_element" !== h.get().getType(); )
        h = h.get().getParent();
      p(h) &&
        p(h.get().getParent()) &&
        "frame_element" === h.get().getParent().get().getType() &&
        (h = h.get().getParent());
      b = K(e);
      if (!b.I()) {
        h.get().dispatchEvent(E(new F("expand_start"), c.V));
        var k = D(b.get()),
          l = a.P(),
          n = () => {
            const q = y(),
              v = Object.assign({}, { width: k.width, height: k.height }, l, {
                stageId: e.G(),
                sourceStageId: h.get().G(),
                sceneId: g.G(),
              });
            va("expand", q, v);
          };
        c = rc();
        tc(c) ? fk(a, c, d, k, () => n()) : n();
      }
    }
  }
  function fk(a, b, c, d, e) {
    if (1 === b.g) {
      b.g = 4;
      const f = a.P();
      a = null != f.width ? f.width : d.width;
      d = null != f.height ? f.height : d.height;
      a = "number" !== typeof a ? parseInt(a, 10) : 0;
      d = "number" !== typeof d ? parseInt(d, 10) : 0;
      const g = () => {
          b.removeEventListener(4, g);
          2 === b.g &&
            ((b.g = 3),
            window.revjet.elements_api.collapse(c.G(), { skipMraid: !0 }),
            (b.g = 1));
        },
        h = () => {
          b.removeEventListener(3, h);
          b.g = 2;
          b.addEventListener(4, g);
        };
      e();
      b.addEventListener(3, h);
      b.expand(a, d);
    }
  }
  class gk extends O {
    constructor(a, b) {
      super("expand", a);
      this.g = b;
    }
    B(a) {
      super.B(a);
      this.g
        ? dk(this, a)
        : Gf(this, a.M)
            .filter((b) => b.K("frame_element"))
            .forEach((b) => ek(this, b, a));
    }
  }
  function hk(a) {
    const b = a.M,
      c = a.mc;
    var d = !0,
      e = 0;
    for (let f = 0; f < c.length; f++) {
      let g = c[f];
      g.K("fire_pixel") && (e++, (d = d && g.j.i));
    }
    (1 === e || d) && b.dispatchEvent(E(new F("fire_pixel"), a.V));
  }
  class ik extends O {
    constructor(a, b) {
      super("fire_pixel", b);
      this.g = -1;
      this.m = !1;
      this.j = a;
    }
    B(a) {
      super.B(a);
      var b = this.j;
      b.g = [];
      b.h = !1;
      b.i = !1;
      this.j.g.push(this.o.bind(this, a));
      this.m = !1;
      0 <= this.g && (window.clearTimeout(this.g), (this.g = -1));
      this.g = window.setTimeout(this.C.bind(this, a), 1e3);
      this.j.Y();
    }
    C(a) {
      window.clearTimeout(this.g);
      this.g = -1;
      this.m = !0;
      hk(a);
    }
    o(a) {
      0 <= this.g && (window.clearTimeout(this.g), (this.g = -1));
      this.m || hk(a);
    }
  }
  function kk(a, b) {
    a = new lk(b);
    b.duration &&
      (a.g = ka(b.duration) ? b.duration : parseInt(b.duration, 10));
    b.animationType && (a.j = b.animationType);
    b.position && (a.m = b.position);
    b.timing && (a.o = b.timing);
    return a;
  }
  function mk(a, b) {
    Bj("show", a).B(b);
  }
  function nk(a, b) {
    const c = {
        none: a.H,
        fade: a.C,
        slide: a.ha,
        slide_left: a.R,
        slide_right: a.X,
        slide_up: a.ia,
        slide_down: a.L,
      },
      d = 0 === M().va(a.g) ? "none" : a.j;
    if (d in c) {
      const e = b.Da;
      K(b.Ca).forEach((f) => {
        K(e).forEach((g) => {
          c[d].call(a, b, { qa: f, ra: g });
        });
      });
    }
  }
  function ok(a, b, c) {
    mk({ method: "display", position: a.m, widgetId: b.G() }, c);
  }
  function pk(a, b) {
    Bj("hide", { method: "display", position: "as_is", widgetId: a.G() }).B(b);
  }
  function qk(a, b, c, d, e) {
    const f = a.o;
    a = M().va(a.g);
    return new tb(b, a, d, e, [{ oc: c, duration: a, timing: f, delay: 0 }]);
  }
  function rk(a, b, c, d) {
    const e = c.ra,
      f = c.qa;
    b.Ca.U = !0;
    b.Da.U = !0;
    C(e, d.ya);
    const g = jb(e, "overflow"),
      h = jb(f, "overflow");
    g && "hidden" !== g && C(e, "overflow", "hidden");
    h && "hidden" !== h && C(f, "overflow", "hidden");
    ok(a, b.Da, b.Ha);
    let k = () => {
      k = () => {
        b.Da.U = !1;
        b.Ca.U = !1;
      };
    };
    sb(d.pa, () => {
      e && g && "hidden" !== g && C(e, "overflow", g);
      k();
    });
    sb(d.la, () => {
      pk(b.Ca, b.Ha);
      C(f, d.ta);
      f && h && "hidden" !== h && C(f, "overflow", h);
      k();
    });
    d.pa.play();
    d.la.play();
  }
  class lk extends O {
    constructor(a) {
      super("go_to_frame", a);
      this.g = 0;
      this.o = "ease";
      this.j = "none";
      this.m = "as_is";
    }
    B(a) {
      super.B(a);
      const b = a.M,
        c = b.getType();
      "frames_element" === c || "container_element" === c
        ? mk(
            {
              method: "display",
              position: this.m,
              widgetId: r(this.i),
              duration: this.g,
              animationType: this.j,
              timing: this.o,
            },
            a
          )
        : xf(b, (d) => d.K("frame_element"))
            .filter((d) => !d.U)
            .forEach((d) => {
              Gf(this, b)
                .filter((e) => !e.U)
                .forEach((e) => nk(this, { Ca: d, Da: e, Ha: a }));
            });
    }
    H(a) {
      ok(this, a.Da, a.Ha);
      pk(a.Ca, a.Ha);
    }
    C(a, b) {
      var c = b.qa;
      const d = { opacity: "0" },
        e = { opacity: "1" },
        f = qk(this, b.ra, "opacity", d, e);
      c = qk(this, c, "opacity", e, d);
      rk(this, a, b, { ya: d, ta: e, pa: f, la: c });
    }
    ha(a, b) {
      var c = b.ra,
        d = b.qa;
      const e = D(c),
        f = { height: "0px" },
        g = { height: `${D(d).height}px` };
      c = qk(this, c, "height", f, { height: `${e.height}px` });
      d = qk(this, d, "height", {}, f);
      rk(this, a, b, { ya: f, ta: g, pa: c, la: d });
    }
    R(a, b) {
      var c = b.ra,
        d = b.qa;
      const e = D(d),
        f = { left: e.width + "px" },
        g = { left: "0px" };
      c = qk(this, c, "left", f, g);
      d = qk(this, d, "left", g, { left: "-" + e.width + "px" });
      rk(this, a, b, { ya: f, ta: g, pa: c, la: d });
    }
    X(a, b) {
      var c = b.ra,
        d = b.qa;
      const e = D(c),
        f = { left: "-" + e.width + "px" },
        g = { left: "0px" };
      c = qk(this, c, "left", f, g);
      d = qk(this, d, "left", g, { left: e.width + "px" });
      rk(this, a, b, { ya: f, ta: g, pa: c, la: d });
    }
    ia(a, b) {
      var c = b.ra,
        d = b.qa;
      const e = D(d),
        f = { top: e.height + "px" },
        g = { top: "0px" };
      c = qk(this, c, "top", f, g);
      d = qk(this, d, "top", g, { top: "-" + e.height + "px" });
      rk(this, a, b, { ya: f, ta: g, pa: c, la: d });
    }
    L(a, b) {
      var c = b.ra,
        d = b.qa;
      const e = D(d),
        f = { top: "-" + e.height + "px" },
        g = { top: "0px" };
      c = qk(this, c, "top", f, g);
      d = qk(this, d, "top", g, { top: e.height + "px" });
      rk(this, a, b, { ya: f, ta: g, pa: c, la: d });
    }
  }
  function sk(a) {
    return a.K("frame_element")
      ? !ea(a.getParent(), (b) => b.K("frame_element"))
      : !1;
  }
  class tk extends O {
    constructor(a) {
      super("go_to_stage", a);
      this.j = 0;
      this.o = "ease";
      this.g = "none";
      this.m = "as_is";
    }
    B(a) {
      super.B(a);
      const b = a.M;
      b.K("frames_element") || b.K("container_element")
        ? Bj("show", {
            method: "display",
            position: this.m,
            widgetId: r(this.i),
            duration: this.j,
            animationType: this.g,
            timing: this.o,
          }).B(a)
        : xf(b, (c) => sk(c) && !c.U).forEach((c) => {
            Gf(this, b)
              .filter((d) => !d.U)
              .forEach((d) => {
                nk(
                  kk("go_to_frame", {
                    duration: this.j,
                    animationType: this.g,
                    position: this.m,
                    timing: this.o,
                  }),
                  { Ca: c, Da: d, Ha: a }
                );
              });
          });
    }
  }
  class uk extends F {
    constructor() {
      super("animation_stop", { animationName: void 0 });
    }
    J() {
      return this.A("animationName");
    }
    g(a) {
      return a.animationName === this.J();
    }
  }
  uk.prototype.getAnimationName = uk.prototype.J;
  class vk {
    constructor(a) {
      this.g = a.type || "start";
      this.h = parseInt(a.at || -1, 10);
    }
    getType() {
      return this.g;
    }
  }
  class wk {
    constructor(a) {
      this.h = a.widgetId;
      this.g = parseInt(a.delay || 0, 10);
      this.j =
        "infinite" === a.repeat ? "infinite" : parseInt(a.repeat || 1, 10);
      this.i = Array.isArray(a.keyframes)
        ? a.keyframes.map((b) => new vk(b))
        : [];
    }
    G() {
      return this.h;
    }
    xb() {
      return this.g;
    }
  }
  function xk(a, b, c, d) {
    const e = M();
    if (!e.isEnabled() || !e.g) {
      var f = a.g,
        g = a.j.reduce((h, k) => {
          const l = Af(b, k.G())
            .filter((n) => "html5_element" === n.getType())
            .map((n) => yk(a, k, n, 1, d));
          return p(l) ? h.concat(l.get()) : h;
        }, []);
      Promise.all(g).then(
        () => {
          0 < g.length && ("infinite" === f || c < f) && xk(a, b, c + 1, d);
        },
        () => {
          J(od("Html5Animation"), "HTML5 animation has been interrupted");
        }
      );
    }
  }
  function yk(a, b, c, d, e) {
    c.sa = e;
    const f = b.xb(),
      g = b.j,
      h = b.i.map((k) => zk(k, f, c, e));
    return Promise.all(h).then(
      () =>
        0 < h.length && ("infinite" === g || d < g)
          ? yk(a, b, c, d + 1, e)
          : Promise.resolve(),
      () => {
        c.dispatchEvent(E(new uk(), e));
        return Promise.reject();
      }
    );
  }
  function zk(a, b, c, d) {
    return new Promise((e, f) => {
      const g = new hb(b + a.h);
      g.ga = !1;
      const h = () => {
          g.Cb() && (g.stop(), f());
        },
        k = M();
      if (k.isEnabled()) {
        if (k.g) {
          f();
          return;
        }
        k.addListener(h);
      }
      eb(g, () => {
        k.removeListener(h);
        const l = a.getType();
        "start" === l
          ? c.dispatchEvent(E(new sj(), d))
          : "stop" === l && c.dispatchEvent(E(new uk(), d));
        e();
      });
      g.start();
    });
  }
  class Ak extends O {
    constructor(a, b) {
      super(a, b);
      this.j = Array.isArray(b.widgets) ? b.widgets.map((c) => new wk(c)) : [];
      this.g =
        "infinite" === b.iterationCount
          ? "infinite"
          : parseInt(b.iterationCount || 1, 10);
    }
    B(a) {
      super.B(a);
      const b = a.M,
        c = this.g;
      ("infinite" === c || 0 < c) && xk(this, b, 1, a.V);
    }
  }
  class Bk extends O {
    constructor(a, b) {
      super("js", b);
      this.g = a;
    }
    B(a) {
      super.B(a);
      a = this.g;
      if (w.execScript) w.execScript(a, "JavaScript");
      else if (w.eval) {
        if (null == oa)
          if (
            (w.eval("var _evalTest_ = 1;"), "undefined" !== typeof w._evalTest_)
          ) {
            try {
              delete w._evalTest_;
            } catch (b) {}
            oa = !0;
          } else oa = !1;
        if (oa) w.eval(a);
        else {
          const b = w.document;
          let c = b.createElement("SCRIPT");
          c.type = "text/javascript";
          c.defer = !1;
          c.appendChild(b.createTextNode(a));
          b.body.appendChild(c);
          b.body.removeChild(c);
        }
      } else throw Error("globalEval not available");
    }
  }
  class Ck extends O {
    constructor(a) {
      super("refresh", a);
    }
    B(a) {
      super.B(a);
      a = a.M;
      a.O(new F("refresh"));
      (a = r(Gf(this, a).filter((b) => "html5_element" === b.getType())))
        ? a.refresh()
        : ua()
        ? va("refresh", y(), {})
        : window.location.reload(!1);
    }
    s() {
      return !1;
    }
  }
  class Dk extends O {
    constructor(a) {
      super("reload", a);
    }
    B(a) {
      super.B(a);
      a.M.O(new F("reload"));
      ua() ? va("reload", y(), {}) : window.location.reload(!0);
    }
    s() {
      return !1;
    }
  }
  function Ek(a) {
    Array.prototype.slice
      .call(
        (
          document.getElementsByTagName("HEAD")[0] || document.body
        ).getElementsByTagName("STYLE")
      )
      .filter((b) => b.getAttribute("data-revjet-widget-id") === a)
      .forEach((b) => La(b));
  }
  class Fk extends O {
    B(a) {
      super.B(a);
      const b = a.M;
      Ff(this, b).forEach(() => Ek(b.G()));
    }
  }
  function Gk(a, b, c) {
    Bj(b ? "show" : "hide", {
      method: a.g,
      position: a.o,
      duration: a.m,
      timing: a.C,
      animationType: a.j,
      widgetId: r(a.i),
    }).B(c);
  }
  class Hk extends O {
    constructor(a) {
      super("toggle_visibility", a);
      this.g = "display";
      this.o = "as_is";
      this.m = 0;
      this.C = "ease";
      this.j = "none";
    }
    B(a) {
      super.B(a);
      Ff(this, a.M).forEach((b) => {
        const c = this.g;
        "display" === c
          ? Gk(this, "none" === jb(b, "display"), a)
          : "visibility" === c && Gk(this, "hidden" === jb(b, "visibility"), a);
      });
    }
  }
  const Ik = new Map(),
    Jk = new Map();
  function Kk(a) {
    return Jk.get(a) || null;
  }
  function Lk(a, b) {
    return new Mk(a, b);
  }
  class Mk extends O {
    B(a) {
      super.B(a);
      const b = a.M,
        c = Kk(this.getType());
      c
        ? c({
            sourceWidgetId: b.G(),
            widgetId: r(this.i),
            properties: this.P(),
            sourceEvent: a.V.P(),
          })
        : Gf(this, b).forEach((d) => {
            -1 !== Ya.indexOf(this.getType()) && (d.sa = a.V);
            d.ba(this.getType(), this.P());
          });
    }
  }
  const Nk = {
    add_class: oj,
    apply_css: function (a, b) {
      return new zj(a, b);
    },
    close: function (a, b) {
      return new Aj(b);
    },
    collapse: function (a, b) {
      return new Mj(b);
    },
    complete: function (a, b) {
      return new bk(b);
    },
    expand: function (a, b) {
      return new gk(b, !!b.onlyContainer);
    },
    fire_pixel: function (a, b) {
      a = b.url;
      const c = b.code,
        d = b.pixelType,
        e = new Vc();
      e.j = d ? d : c ? "html" : "image";
      a && (e.W = a);
      c && (e.o = c);
      return new ik(e, b);
    },
    go_to_frame: kk,
    go_to_stage: function (a, b) {
      a = new tk(b);
      b.duration &&
        (a.j = ka(b.duration) ? b.duration : parseInt(b.duration, 10));
      b.animationType && (a.g = b.animationType);
      b.position && (a.m = b.position);
      b.timing && (a.o = b.timing);
      return a;
    },
    hide: Bj,
    js: function (a, b) {
      return new Bk(b.code, b);
    },
    link: function (a, b) {
      return new ak(b);
    },
    refresh: function (a, b) {
      return new Ck(b);
    },
    reload: function (a, b) {
      return new Dk(b);
    },
    remove_class: oj,
    reset_css: function (a, b) {
      return new Fk(a, b);
    },
    show: Bj,
    start_animation: uj,
    start_html5_animation: function (a, b) {
      return new Ak(a, b);
    },
    stop_animation: uj,
    toggle_visibility: function (a, b) {
      a = new Hk(b);
      b.method && (a.g = b.method);
      b.position && (a.o = b.position);
      b.duration &&
        (a.m = ka(b.duration) ? b.duration : parseInt(b.duration, 10));
      b.animationType && (a.j = b.animationType);
      b.timing && (a.C = b.timing);
      return a;
    },
  };
  function Ok(a) {
    const b = a.type,
      c = Nk[b];
    return (c ? c : Lk)(b, a);
  }
  class Pk extends F {
    constructor(a, b) {
      super("custom_event", { name: a, payload: b });
    }
    $() {
      return this.A("name");
    }
    $b() {
      return this.A("payload");
    }
    g(a) {
      return a.name === this.$() && a.payload === this.$b();
    }
  }
  Pk.prototype.getPayload = Pk.prototype.$b;
  Pk.prototype.getName = Pk.prototype.$;
  class Qk extends F {
    constructor(a, b) {
      super("data_change", { value: b });
      this.i = a;
    }
    gb() {
      return this.i;
    }
    N() {
      return this.A("value");
    }
    g() {
      return !0;
    }
  }
  Qk.prototype.getValue = Qk.prototype.N;
  Qk.prototype.getDataBinding = Qk.prototype.gb;
  class Rk extends F {
    constructor(a) {
      super("form_load", { formId: a });
    }
    ea() {
      return this.A("formId");
    }
    g(a) {
      return a.formId === this.ea();
    }
  }
  Rk.prototype.getFormId = Rk.prototype.ea;
  class Sk extends F {
    constructor(a, b) {
      super("form_validated", { formId: a, result: b });
    }
    ea() {
      return this.A("formId");
    }
    Na() {
      return this.A("result");
    }
    g(a) {
      return a.result === this.Na() && a.formId === this.ea();
    }
  }
  Sk.prototype.getResult = Sk.prototype.Na;
  Sk.prototype.getFormId = Sk.prototype.ea;
  class Tk extends F {
    constructor(a) {
      super("validated", { result: a });
    }
    Na() {
      return this.A("result");
    }
    g(a) {
      return a.result === this.Na();
    }
  }
  Tk.prototype.getResult = Tk.prototype.Na;
  class Uk extends F {
    constructor(a) {
      super("value_change", { value: a });
    }
    N() {
      return this.A("value");
    }
    g() {
      return !0;
    }
  }
  Uk.prototype.getValue = Uk.prototype.N;
  class Vk extends F {
    constructor(a) {
      super("vpaid_ad_volume_change", { volume: a });
    }
    hc() {
      return this.A("volume");
    }
    g(a) {
      return a.volume === this.hc();
    }
  }
  Vk.prototype.getVolume = Vk.prototype.hc;
  class Wk extends F {
    constructor(a, b, c) {
      super("vpaid_resize_ad", { width: a, height: b, viewMode: c });
    }
    xa() {
      return this.A("width");
    }
    ua() {
      return this.A("height");
    }
    Pa() {
      return this.A("viewMode");
    }
    g(a) {
      return a.viewMode === this.Pa();
    }
  }
  Wk.prototype.getViewMode = Wk.prototype.Pa;
  Wk.prototype.getHeight = Wk.prototype.ua;
  Wk.prototype.getWidth = Wk.prototype.xa;
  class W extends F {
    constructor(a, b, c, d, e, f) {
      super("vpaid_init_ad", {
        width: a,
        height: b,
        viewMode: c,
        desiredBitrate: d,
        creativeData: e,
        environmentVars: f,
      });
    }
    xa() {
      return this.A("width");
    }
    ua() {
      return this.A("height");
    }
    Pa() {
      return this.A("viewMode");
    }
    gd() {
      return this.A("desiredBitrate");
    }
    ed() {
      return this.A("creativeData");
    }
    hd() {
      return this.A("environmentVars");
    }
    g(a) {
      return a.viewMode === this.Pa();
    }
  }
  W.prototype.getEnvironmentVars = W.prototype.hd;
  W.prototype.getCreativeData = W.prototype.ed;
  W.prototype.getDesiredBitrate = W.prototype.gd;
  W.prototype.getViewMode = W.prototype.Pa;
  W.prototype.getHeight = W.prototype.ua;
  W.prototype.getWidth = W.prototype.xa;
  class Xk extends F {
    constructor(a, b) {
      super("safeframe_status_update", { status: a, data: b });
    }
    zb() {
      return this.A("status");
    }
    getData() {
      return this.A("data");
    }
    g(a) {
      return a.status === this.zb();
    }
  }
  Xk.prototype.getData = Xk.prototype.getData;
  Xk.prototype.getStatus = Xk.prototype.zb;
  class Yk extends F {
    constructor(a, b, c, d) {
      super("viewable_event", { name: a, num: b, pixelType: c, latent: d });
    }
    $() {
      return this.A("name");
    }
    md() {
      return this.A("num");
    }
    aa() {
      return this.A("pixelType");
    }
    kd() {
      return this.A("latent");
    }
    g(a) {
      return a.name === this.$();
    }
  }
  Yk.prototype.getLatent = Yk.prototype.kd;
  Yk.prototype.getPixelType = Yk.prototype.aa;
  Yk.prototype.getNum = Yk.prototype.md;
  Yk.prototype.getName = Yk.prototype.$;
  class Zk extends F {
    constructor(a) {
      super("resource_load_complete", { timeStamp: a });
    }
    td() {
      return this.A("timeStamp");
    }
    g() {
      return !0;
    }
  }
  Zk.prototype.getTimeStamp = Zk.prototype.td;
  class $k extends F {
    constructor(a) {
      super("ready", { version: a });
    }
    ib() {
      return this.A("version");
    }
    g() {
      return !0;
    }
  }
  $k.prototype.getVersion = $k.prototype.ib;
  class al extends F {
    constructor(a) {
      super("gallery_slide_click", { num: a });
    }
    fa() {
      return this.A("num");
    }
    g(a) {
      return a.num === this.fa();
    }
  }
  al.prototype.getSlideNumber = al.prototype.fa;
  class bl extends F {
    constructor(a) {
      super("gallery_slide_panel_view", { num: a });
    }
    fa() {
      return this.A("num");
    }
    g(a) {
      return a.num === this.fa();
    }
  }
  bl.prototype.getSlideNumber = bl.prototype.fa;
  class cl extends F {
    constructor(a) {
      super("gallery_slide_video_play", { num: a });
    }
    fa() {
      return this.A("num");
    }
    g(a) {
      return a.num === this.fa();
    }
  }
  cl.prototype.getSlideNumber = cl.prototype.fa;
  function U(a, b, c) {
    return b ? ((a = (c || a.g).find((d) => d.G() === b)), u(a)) : t;
  }
  function dl(a) {
    return a.reduce((b, c, d) => {
      c = Object.assign({}, c, { order: c.order || d });
      c = (ij[c.type] || Uf)(c.id, c);
      return null === c ? b : b.concat(c);
    }, []);
  }
  function el(a, b) {
    const c = U(a, "RootWidget", b).get();
    b.forEach((d) => {
      const e = d.R;
      e
        ? U(a, e, b).forEach((f) => {
            yf(d, f);
            f.S.push(d);
            f.S.sort(f.Ib);
          })
        : c &&
          "RootWidget" !== d.G() &&
          (yf(d, c), (d.R = c.G()), c.S.push(d), c.S.sort(c.Ib));
    });
  }
  function fl(a, b) {
    const c = b.sourceWidgetId;
    c && (Array.isArray(c) ? c : [c]).forEach((d) => gl(a, d, b));
  }
  function hl(a) {
    U(a, "RootWidget").forEach((b) => {
      il(a, b, "click");
      il(a, b, "auxclick");
    });
  }
  function jl(a) {
    $c().setConfiguration(a.D);
    a.g = dl(a.o);
    el(a, a.g);
    a.g.forEach((b) => b.h());
    a.i.forEach((b) => fl(a, b));
    hl(a);
  }
  function kl(a) {
    let b = "";
    for (let c in a)
      if (a.hasOwnProperty(c)) {
        if ("delay" === c) continue;
        let d = a[c];
        null != d &&
          (x(d) || (d = String(d)),
          (d = Lb(d)),
          0 !== d.length && (b += (x(c) ? c : String(c)) + ":" + d + ";"));
      }
    return b;
  }
  function gl(a, b, c) {
    const d = a.m,
      e = U(a, b, a.g);
    e.I() ||
      (b in d || (d[b] = {}),
      c.events.forEach((f) => {
        var g = kl(f);
        let h;
        g in d[b]
          ? (h = d[b][g])
          : ((h = new Qf(f)), (d[b][g] = h), hg(e.get(), h));
        g = Ok(c);
        Lf(h, g, f.delay);
        ("click" !== h.getType() && "auxclick" !== h.getType()) ||
          e.flatMap((k) => K(k)).forEach((k) => (k.style.cursor = "pointer"));
      }));
  }
  function il(a, b, c, d) {
    let e = void 0;
    var f = cg(b, c);
    null != f &&
      (f = f.g.find((g) => g.K("link"))) &&
      (e = (f.Ab() || "").toString()) &&
      bg(b, e);
    !e && d && ((e = d), bg(b, e));
    b = b.S;
    for (const g of b) il(a, g, c, e);
  }
  function ll(a) {
    return m(function* () {
      const b = a.g;
      for (const c of b) yield a.da(c.G(), "before_personalization");
    });
  }
  function ml(a, b, c) {
    U(a, b).forEach((d) => {
      -1 !== Db.indexOf(c.getType()) && E(c, d.sa);
      d.dispatchEvent(c);
    });
  }
  function nl(a, b) {
    b = b || {};
    const c = b.animationName;
    return "gallery_slide_video_play" === a
      ? new cl(b.num)
      : "gallery_slide_panel_view" === a
      ? new bl(b.num)
      : "gallery_slide_click" === a
      ? new al(b.num)
      : "slider_card_view" === a
      ? new Tc(b.cardNumber, b.containerElement)
      : "bodymovin_complete" === a
      ? new kj(c)
      : "bodymovin_loop_complete" === a
      ? new lj(c)
      : "bodymovin_segment_start" === a
      ? new mj(c)
      : "bodymovin_start" === a
      ? new nj(c)
      : "custom_event" === a
      ? new Pk(b.name, b.payload)
      : "vpaid_ad_volume_change" === a
      ? new Vk(b.volume)
      : "vpaid_resize_ad" === a
      ? new Wk(b.width, b.height, b.viewMode)
      : "vpaid_init_ad" === a
      ? new W(
          b.width,
          b.height,
          b.viewMode,
          b.desiredBitrate,
          b.creativeData,
          b.environmentVars
        )
      : "safeframe_status_update" === a
      ? new Xk(b.status, b.data)
      : "viewable_event" === a
      ? new Yk(b.name, b.num, b.type, !!b.latent)
      : "resource_load_complete" === a
      ? new Zk(b.timeStamp)
      : "ready" === a
      ? new $k(b.version)
      : "before_form_load" === a
      ? new jj(b.formId)
      : "form_load" === a
      ? new Rk(b.formId)
      : "form_validated" === a
      ? new Sk(b.formId, b.result)
      : "validated" === a
      ? new Tk(b.result)
      : "data_change" === a
      ? new Qk(b.dataBinding || null, b.value)
      : "value_change" === a
      ? new Uk(b.value)
      : "consumer_data" === a
      ? new Fb(b.dataBinding || null, b.value, b.fields)
      : new F(a);
  }
  function ol(a, b, c) {
    return m(function* () {
      const d = U(a, b);
      if (p(d)) return d.get().da(c);
    });
  }
  function pl(a, b, c) {
    fa(U(a, b), () => U(a, "RootWidget")).forEach((d) => {
      var e = Mc(),
        f = e.h;
      e = e.g;
      f = new Rf(
        null == f ? void 0 : f.cx,
        null == f ? void 0 : f.cy,
        null == e ? void 0 : e.eb,
        null == e ? void 0 : e.ch,
        null == e ? void 0 : e.bb
      );
      null != c.button && Eb(f, c.button);
      d.dispatchEvent(f);
    });
  }
  function ql(a) {
    Cc() ||
      a.g.forEach((b) => {
        b.dispatchEvent(new F("load"));
      });
  }
  function rl(a) {
    Cc() ||
      U(a, "RootWidget").forEach((b) => {
        b.dispatchEvent(new F("before_show"));
        b.dispatchEvent(new F("show"));
        a.s = !0;
      });
  }
  function sl(a) {
    if (
      a &&
      (a =
        "undefined" !== typeof a.nodeType
          ? a
          : a.nativeEvent && a.nativeEvent.target
          ? a.nativeEvent.target
          : a.target || a.srcElement)
    ) {
      try {
        const b = a.ownerDocument.defaultView;
        w !== b && (a = b.frameElement ? b.frameElement : a);
      } catch (b) {}
      return Pa(
        a,
        (b) =>
          b.id &&
          b.getAttribute &&
          b.getAttribute("data-revjet-role") &&
          b.getAttribute("data-revjet-role-id")
      );
    }
    return t;
  }
  function tl(a, b, c, d, e) {
    "ready" === c && b.Ya
      ? ((b = nl(c, { version: "3.64.0" })), d.call(a, c, e, b))
      : b.listen(c, d.bind(a, c, e));
  }
  function ul(a, b) {
    a.g
      .filter((c) => c.getParent().g(u(b)))
      .forEach((c) => {
        const d = c.G();
        0 < c.S.length
          ? console.groupCollapsed(`${d} (${c.getType()})`)
          : console.log(`${d} (${c.getType()})`);
        ul(a, c);
        0 < c.S.length && console.groupEnd();
      });
  }
  class vl {
    constructor(a) {
      this.g = [];
      this.h = a;
      this.D = a.tracking || [];
      var b = (a.widgets || []).filter(
        (e) =>
          p(Ka(e.id)) ||
          "active_element" === e.type ||
          "active_text_element" === e.type ||
          "active_image_element" === e.type ||
          "active_video_element" === e.type
      );
      b = xa(b, "id");
      this.o = [{ id: "RootWidget", type: "root" }].concat(b);
      b = (a.actions || [])
        .map((e) =>
          Xa() ||
          -1 !== Wa.indexOf("iPad") ||
          -1 !== Wa.indexOf("iPod") ||
          -1 !== Wa.indexOf("Android")
            ? Object.assign({}, e, {
                events: (e.events || []).filter(
                  (f) =>
                    "mouse_out" !== f.type &&
                    "mouse_enter" !== f.type &&
                    "mouse_leave" !== f.type &&
                    "mouse_over" !== f.type
                ),
              })
            : e
        )
        .map((e, f) => {
          const g = e.id;
          return Object.assign({}, e, { id: null != g ? g : f });
        });
      b = xa(b, "id");
      const c = a.eligibleActions;
      a = c
        ? b.reduce((e, f) => {
            const g = f.id;
            f = f.relatedActions || [];
            return 0 < f.length && -1 !== c.indexOf(g) ? e.concat(f) : e;
          }, [])
        : [];
      const d = c ? c.concat(a) : [];
      this.i = c ? b.filter((e) => ~d.indexOf(e.id)) : b;
      this.j = b.some((e) => "close" === e.type || "collapse" === e.type);
      this.m = {};
      this.s = !1;
    }
    load() {
      return new Promise((a) => {
        if (-1 !== navigator.userAgent.indexOf("Firefox")) {
          const b = window.getComputedStyle(document.documentElement, null);
          if (b && 0 !== b.length) a();
          else {
            const c = () => {
              const d = window.getComputedStyle(document.documentElement, null);
              d && 0 !== d.length ? a() : Ua(() => c());
            };
            c();
          }
        } else a();
      }).then(() =>
        Promise.all(
          this.g.map((a) =>
            a
              .load()
              .catch((b) =>
                od("CreativeLayout").error("Error while loading widget.", b)
              )
          )
        )
      );
    }
    O(a, b, c) {
      const d = this.g;
      for (const e of d) (!b && e.za()) || this.dispatchEvent(e.G(), a, c);
    }
    dispatchEvent(a, b, c) {
      ml(this, a, nl(b, c));
    }
    da(a, b) {
      return ol(this, a, nl(b));
    }
    dispatchBrowserEvent(a, b, c) {
      U(this, a).forEach((d) => d.dispatchBrowserEvent(b, c));
    }
    lb() {
      return this.s;
    }
    listen(a, b, c, d) {
      if (d)
        sl(d)
          .map((e) => e.id)
          .flatMap((e) => U(this, e))
          .forEach((e) => tl(this, e, a, b, d));
      else {
        const e = U(this, c);
        p(e)
          ? tl(this, e.get(), a, b, c)
          : this.g
              .filter((f) => !f.za())
              .forEach((f) => tl(this, f, a, b, f.G()));
      }
    }
    listenOnce(a, b, c, d) {
      let e = !1;
      this.listen(
        a,
        (...f) => {
          if (!e) return (e = !0), b(...f);
        },
        c,
        d
      );
    }
  }
  class wl {
    P() {
      a: {
        try {
          const b = Bc("properties") || "{}";
          var a = JSON.parse(b);
          break a;
        } catch (b) {}
        a = {};
      }
      return a;
    }
  }
  wl.prototype.getProperties = wl.prototype.P;
  function X(a, b) {
    sl(a).match({
      some: b,
      Ad: () => {
        console.error("Could not find source widget element", { source: a });
      },
    });
  }
  function xl(a, b) {
    const c = a.g;
    U(c, b).forEach((d) => {
      c.g
        .filter(
          (e) =>
            e !== d &&
            e.K("frame_element") &&
            e.getParent().g(d.getParent()) &&
            !e.oa()
        )
        .forEach((e) => a.ka(e.G(), "display", "as_is"));
    });
  }
  function yl(a, b, c, d, e, f, g, h) {
    a.B({
      type: b ? "show" : "hide",
      sourceWidgetId: c,
      method: d,
      position: e,
      widgetId: c,
      duration: f,
      animationType: g,
      timing: h,
    });
  }
  function zl(a, b, c, d, e, f, g) {
    const h = r(ma("click_target").map((k) => k.toString())) || "_blank";
    X(b, (k) => {
      const l = k.id,
        n = new F("api_call");
      b instanceof Event && null != b.button && Eb(n, b.button);
      ma("click_url")
        .map((q) => q.toString())
        .filter((q) => "" !== q && 0 !== q.indexOf("javascript:"))
        .forEach((q) => {
          const v = Ec();
          q = (!0 === v.is_slot ? !0 === v.use_slot_level_click : 1)
            ? `${q}&${c}=${encodeURIComponent(d)}`
            : q;
          a.B(
            {
              type: "link",
              sourceWidgetId: l,
              url: q,
              target: h,
              customRole: e,
              skuId: f,
              skuPos: g,
            },
            n
          );
        });
    });
  }
  function Al(a, b, c) {
    const d = c || {},
      e = a.g;
    X(b, (f) => {
      f = f.id;
      const g = U(e, f).flatMap((k) => {
          for (; k; ) {
            if (
              k.K("frame_element") &&
              ea(k.getParent(), (l) => l.K("frame_element"))
            )
              return u(k);
            k = r(k.getParent());
          }
          return t;
        }),
        h = document
          .querySelector(
            `[id][data-revjet-role-id][data-revjet-role="${d.sceneToExpand}"]`
          )
          .getAttribute("id");
      a.B(
        Object.assign({}, d, {
          type: "expand",
          sourceWidgetId: f,
          collapsedFrameId: g.get().G(),
          widgetId: h,
        })
      );
    });
  }
  function Bl(a, b) {
    for (let c in a.h) na(`${b}.${c}`, a.h[c]);
  }
  function Cl(a, b) {
    return r(
      a.g.g
        .filter((c) => "html5_element" === c.getType())
        .reduce((c, d) => (c.I() ? b(d) : c), t)
    );
  }
  class Y {
    constructor(a) {
      this.g = a;
      const b = V().T();
      this.h = {
        addDataFeedItems: this.Ea.bind(this),
        addMissingSKU: this.Fa.bind(this),
        adjustFont: pb,
        broadcastEvent: this.O.bind(this),
        reapplyPersonalization: this.pc.bind(this),
        close: this.close.bind(this),
        collapse: this.collapse.bind(this),
        collapseContainer: this.Hb.bind(this),
        collapseStage: this.Ga.bind(this),
        dispatchBrowserEvent: this.dispatchBrowserEvent.bind(this),
        dispatchEvent: this.dispatchEvent.bind(this),
        expand: this.expand.bind(this),
        expandContainer: this.Mb.bind(this),
        fetchPersonalization: this.Ia.bind(this),
        findAssetByName: this.Ja.bind(this),
        findAssetByURL: this.Ka.bind(this),
        findWidgetElement: this.Nb.bind(this),
        firePixel: this.Y.bind(this),
        getDataFeed: this.ja.bind(this),
        getDataFeedFirstObject: this.Pb.bind(this),
        getDataFeedLength: this.La.bind(this),
        getLayout: this.Ma.bind(this),
        getMaxAnimationDurationTimer: this.Wb.bind(this),
        getOptions: this.Yb.bind(this),
        getPersonalizer: this.ac.bind(this),
        getSKUIds: this.wa.bind(this),
        getTagOptions: this.dc.bind(this),
        getTagObject: this.cc.bind(this),
        goToDataFeedLP: this.ic.bind(this),
        goToLP: this.goToLP.bind(this),
        goToLPEvent: this.jc.bind(this),
        goToLPEventByName: this.kc.bind(this),
        hide: this.ka.bind(this),
        isInApp: this.lc.bind(this),
        isIframeAsset: this.Ra.bind(this),
        isPersonalized: this.kb.bind(this),
        isShown: this.lb.bind(this),
        listen: this.listen.bind(this),
        listenOnce: this.listenOnce.bind(this),
        registerExtension: this.rc.bind(this),
        getExtension: this.getExtension.bind(this),
        registerActionType: this.qc.bind(this),
        mergeDataFeedItems: this.Aa.bind(this),
        mergeSKUs: this.Sa.bind(this),
        runAction: this.B.bind(this),
        show: this.show.bind(this),
        showStage: this.Ta.bind(this),
        shrinkText: nb,
        truncateDataFeed: this.Ua.bind(this),
        updateDataFeed: this.Z.bind(this),
        vpaid: b,
        isVpaid: () => null != b,
        vpaidAdInteraction: this.Jc.bind(this),
        vpaidPauseAd: this.Kc.bind(this),
        vpaidPauseVideo: this.Lc.bind(this),
        vpaidPlayVideo: this.Mc.bind(this),
        vpaidResumeAd: this.Nc.bind(this),
        vpaidResumeVideo: this.Oc.bind(this),
        vpaidSetAdDuration: this.Pc.bind(this),
        vpaidSetAdRemainingTime: this.Qc.bind(this),
        vpaidSkipAd: this.Rc.bind(this),
        vpaidStopAd: this.Tc.bind(this),
        vpaidStartVideoProgress: this.Sc.bind(this),
        vpaidUpdateVideoProgress: this.Uc.bind(this),
        addTrackingEventListener: this.Gb.bind(this),
        removeTrackingEventListener: this.sc.bind(this),
        getVisibilityState: this.Qa.bind(this),
        getVersion: this.ib.bind(this),
        getHtml5Vars: this.Ub.bind(this),
        getVars: this.fc.bind(this),
      };
    }
    O(a, b, c) {
      this.g.O(a, b, c);
    }
    dispatchEvent(a, b, c) {
      const d = this.g;
      fa(u(x(a) ? a : null), () =>
        sl(a).flatMap((e) => u(e.getAttribute("id")))
      ).forEach((e) => d.dispatchEvent(e, b, c));
    }
    dispatchBrowserEvent(a, b, c) {
      this.g.dispatchBrowserEvent(a, b, c);
    }
    Ga(a, b) {
      this.ka(a, "display", "as_is");
      b && this.show(b, "display", "as_is");
    }
    Hb(a, b) {
      const c = b || {};
      X(a, (d) => {
        this.B(
          Object.assign({}, c, {
            type: "collapse",
            onlyContainer: !0,
            sourceWidgetId: d.id,
          })
        );
      });
    }
    Ta(a, b) {
      U(this.g, a).I() ||
        (xl(this, a),
        this.show(a, "display", "as_is"),
        b && a !== b && (this.show(b, "display", "as_is"), xl(this, b)));
    }
    show(a, b, c, d, e, f) {
      yl(this, !0, a, b, c, d, e, f);
    }
    ka(a, b, c, d, e, f) {
      yl(this, !1, a, b, c, d, e, f);
    }
    lb() {
      return this.g.lb();
    }
    kb() {
      return S().kb();
    }
    Ea(a, b, c) {
      X(a, (d) => {
        S().Ea(d.id, b, c);
      });
    }
    Aa(a, b, c) {
      X(a, (d) => {
        S().Aa(d.id, b, c);
      });
    }
    Sa(a, b) {
      X(a, (c) => {
        S().Sa(c.id, b);
      });
    }
    Z(a, b) {
      X(a, (c) => {
        S().Z(c.id, b);
      });
    }
    wa(a) {
      return S().wa(a);
    }
    Fa(a, b, c) {
      X(a, (d) => {
        S().Fa(d.id, b, c);
      });
    }
    La(a) {
      return da(
        sl(a).map((b) => S().La(b.id)),
        0
      );
    }
    ja(a) {
      return da(
        sl(a).map((b) => S().ja(b.id)),
        []
      );
    }
    Pb(a) {
      a = this.ja(a);
      return 0 < a.length ? a[0] : {};
    }
    Ua(a, b) {
      X(a, (c) => {
        S().Ua(c.id, b);
      });
    }
    ac() {
      return S();
    }
    Wb() {
      return M();
    }
    goToLP(a, b, c, d, e) {
      const f = b || r(ma("click_url").map((h) => h.toString())),
        g = c || r(ma("click_target").map((h) => h.toString())) || "_blank";
      X(a, (h) => {
        const k = new F("api_call");
        a instanceof Event && null != a.button && Eb(k, a.button);
        this.B(
          {
            type: "link",
            sourceWidgetId: h.id,
            url: f,
            target: g,
            customRole: d,
            tracker: e,
          },
          k
        );
      });
    }
    Nb(a) {
      return r(sl(a));
    }
    jc(a, b, c) {
      zl(this, a, "prm_tag", b, c);
    }
    kc(a, b, c) {
      zl(this, a, "prm_name", b, c);
    }
    ic(a, b, c) {
      var d = encodeURIComponent("$$suffix$$");
      d = -1 === b.indexOf(d) ? Ca(b, d) : b;
      var e = this.ja(a);
      const f = e.findIndex((g) => g.link === b);
      e = -1 !== f ? e[f] : void 0;
      zl(
        this,
        a,
        "lp",
        d,
        c,
        e ? e.skuId || e.sku_id : void 0,
        -1 !== f ? f + 1 + "" : void 0
      );
    }
    Y(a) {
      a &&
        ((a = (x(a) ? JSON.parse(a) : Array.isArray(a) ? a : [a]).map((b) => {
          const c = r(
            u(b.source)
              .flatMap((d) => sl(d))
              .flatMap((d) => u(d.getAttribute("data-revjet-role-id")))
          );
          return Object.assign({}, b, { roleId: c });
        })),
        $c().Y(a));
    }
    listen(a, b, c, d) {
      this.g.listen(a, b, c, d);
    }
    listenOnce(a, b, c, d) {
      this.g.listenOnce(a, b, c, d);
    }
    rc(a, b) {
      Ik.has(a) ? (a = !1) : (Ik.set(a, b), (a = !0));
      return a;
    }
    getExtension(a) {
      return Ik.get(a) || null;
    }
    qc(a, b) {
      Jk.set(a, b);
    }
    Gb(a) {
      fd().addEventListener(a);
    }
    sc(a) {
      fd().removeEventListener(a);
    }
    expand(a, b) {
      const c = b || {},
        d = this.g;
      null != c.sceneToExpand
        ? Al(this, a, b)
        : u(d.i.find((e) => "expand" === e.type)).forEach((e) => {
            e = c ? Object.assign({}, e, c) : e;
            this.B(e);
          });
    }
    Mb(a, b) {
      const c = b || {};
      X(a, (d) => {
        this.B(
          Object.assign({}, c, {
            type: "expand",
            onlyContainer: !0,
            sourceWidgetId: d.id,
          })
        );
      });
    }
    close(a, b) {
      const c = b || {};
      X(a, (d) => {
        this.B(Object.assign({}, c, { type: "close", sourceWidgetId: d.id }));
      });
    }
    collapse(a, b) {
      const c = b || {};
      X(a, (d) => {
        this.B(
          Object.assign({}, c, { type: "collapse", sourceWidgetId: d.id })
        );
      });
    }
    dc() {
      return wc();
    }
    cc() {
      a: {
        try {
          const b =
            Ac("data-revjet-slot-object-name") || Bc("slot-object-name");
          if (b) {
            var a = window.parent[b];
            break a;
          }
        } catch (b) {}
        a = null;
      }
      return a ? a : new wl();
    }
    Yb() {
      return G();
    }
    lc() {
      return Gc();
    }
    Ra() {
      return G().Ra();
    }
    B(a, b) {
      const c = this.g,
        d = a.sourceWidgetId;
      d &&
        (Array.isArray(d) ? d : [d])
          .map((e) => U(c, e))
          .filter((e) => p(e))
          .forEach((e) => {
            Jf(Ok(a), {
              M: e.get(),
              V: null != b ? b : new F("api_call"),
              mc: [],
              Kb: !0,
            });
          });
    }
    Ma() {
      return this.g.h;
    }
    Ja(a) {
      return Cl(this, (b) => b.Ja(a));
    }
    Ka(a) {
      return Cl(this, (b) => b.Ka(a));
    }
    Tc() {
      const a = V().T();
      a && a.stopAd();
    }
    Rc() {
      const a = V().T();
      a && a.skipAd();
    }
    Kc() {
      const a = V().T();
      a && a.pauseAd();
    }
    Nc() {
      const a = V().T();
      a && a.resumeAd();
    }
    Mc(a) {
      const b = V().T();
      b && b.playVideo(a);
    }
    Lc() {
      const a = V().T();
      a && a.pauseVideo();
    }
    Oc() {
      const a = V().T();
      a && a.resumeVideo();
    }
    Jc() {
      const a = V().T();
      a && a.adInteraction();
    }
    Pc(a) {
      const b = V().T();
      b && b.setAdDuration(a);
    }
    Qc(a) {
      const b = V().T();
      b && b.setAdRemainingTime(a);
    }
    Sc() {
      const a = V().T();
      a && a.startVideoProgress();
    }
    Uc(a, b) {
      const c = V().T();
      c && c.updateVideoProgress(a, b);
    }
    pc(a) {
      const b = this;
      return m(function* () {
        const c = b.g,
          d = S();
        c.O("before_depersonalization", !0);
        yield Pi(d);
        c.O("after_depersonalization", !0);
        Array.isArray(a)
          ? d.Ba(Ji(d, a))
          : d.Ba(
              Ji(
                d,
                d.i.map((e) => (e.id === a.id ? a : e))
              )
            );
        yield ll(c);
        Mi(d, (e, f) => ml(c, e, f));
        yield Oi(d);
        c.O("after_personalization", !0);
      });
    }
    Ia(a) {
      return S().Ia(a);
    }
    Qa(a) {
      const b = this.g,
        c = fa(u(x(a) ? a : null), () => sl(a).map((d) => d.id)).flatMap((d) =>
          U(b, d)
        );
      if (c.I()) throw Error("Cannot find target widget");
      return c.get().Qa();
    }
    ib() {
      return "3.64.0";
    }
    Ub() {
      return this.g.h.html5vars;
    }
    fc() {
      return this.g.h.vars;
    }
  }
  Y.prototype.getVars = Y.prototype.fc;
  Y.prototype.getHtml5Vars = Y.prototype.Ub;
  Y.prototype.getVersion = Y.prototype.ib;
  Y.prototype.getVisibilityState = Y.prototype.Qa;
  Y.prototype.fetchPersonalization = Y.prototype.Ia;
  Y.prototype.reapplyPersonalization = Y.prototype.pc;
  Y.prototype.vpaidUpdateVideoProgress = Y.prototype.Uc;
  Y.prototype.vpaidStartVideoProgress = Y.prototype.Sc;
  Y.prototype.vpaidSetAdRemainingTime = Y.prototype.Qc;
  Y.prototype.vpaidSetAdDuration = Y.prototype.Pc;
  Y.prototype.vpaidAdInteraction = Y.prototype.Jc;
  Y.prototype.vpaidResumeVideo = Y.prototype.Oc;
  Y.prototype.vpaidPauseVideo = Y.prototype.Lc;
  Y.prototype.vpaidPlayVideo = Y.prototype.Mc;
  Y.prototype.vpaidResumeAd = Y.prototype.Nc;
  Y.prototype.vpaidPauseAd = Y.prototype.Kc;
  Y.prototype.vpaidSkipAd = Y.prototype.Rc;
  Y.prototype.vpaidStopAd = Y.prototype.Tc;
  Y.prototype.findAssetByURL = Y.prototype.Ka;
  Y.prototype.findAssetByName = Y.prototype.Ja;
  Y.prototype.getLayout = Y.prototype.Ma;
  Y.prototype.runAction = Y.prototype.B;
  Y.prototype.isIframeAsset = Y.prototype.Ra;
  Y.prototype.isInApp = Y.prototype.lc;
  Y.prototype.getOptions = Y.prototype.Yb;
  Y.prototype.getTagObject = Y.prototype.cc;
  Y.prototype.getTagOptions = Y.prototype.dc;
  Y.prototype.collapse = Y.prototype.collapse;
  Y.prototype.close = Y.prototype.close;
  Y.prototype.expandContainer = Y.prototype.Mb;
  Y.prototype.expand = Y.prototype.expand;
  Y.prototype.removeTrackingEventListener = Y.prototype.sc;
  Y.prototype.addTrackingEventListener = Y.prototype.Gb;
  Y.prototype.registerActionType = Y.prototype.qc;
  Y.prototype.getExtension = Y.prototype.getExtension;
  Y.prototype.registerExtension = Y.prototype.rc;
  Y.prototype.listenOnce = Y.prototype.listenOnce;
  Y.prototype.listen = Y.prototype.listen;
  Y.prototype.firePixel = Y.prototype.Y;
  Y.prototype.goToDataFeedLP = Y.prototype.ic;
  Y.prototype.goToLPEventByName = Y.prototype.kc;
  Y.prototype.goToLPEvent = Y.prototype.jc;
  Y.prototype.findWidgetElement = Y.prototype.Nb;
  Y.prototype.goToLP = Y.prototype.goToLP;
  Y.prototype.getMaxAnimationDurationTimer = Y.prototype.Wb;
  Y.prototype.getPersonalizer = Y.prototype.ac;
  Y.prototype.truncateDataFeed = Y.prototype.Ua;
  Y.prototype.getDataFeedFirstObject = Y.prototype.Pb;
  Y.prototype.getDataFeed = Y.prototype.ja;
  Y.prototype.getDataFeedLength = Y.prototype.La;
  Y.prototype.addMissingSKU = Y.prototype.Fa;
  Y.prototype.getSKUIds = Y.prototype.wa;
  Y.prototype.updateDataFeed = Y.prototype.Z;
  Y.prototype.mergeSKUs = Y.prototype.Sa;
  Y.prototype.mergeDataFeedItems = Y.prototype.Aa;
  Y.prototype.addDataFeedItems = Y.prototype.Ea;
  Y.prototype.isPersonalized = Y.prototype.kb;
  Y.prototype.isShown = Y.prototype.lb;
  Y.prototype.hide = Y.prototype.ka;
  Y.prototype.show = Y.prototype.show;
  Y.prototype.showStage = Y.prototype.Ta;
  Y.prototype.collapseContainer = Y.prototype.Hb;
  Y.prototype.collapseStage = Y.prototype.Ga;
  Y.prototype.dispatchBrowserEvent = Y.prototype.dispatchBrowserEvent;
  Y.prototype.dispatchEvent = Y.prototype.dispatchEvent;
  Y.prototype.broadcastEvent = Y.prototype.O;
  class Z {
    constructor(a) {
      this.g = a;
    }
    dispatchEvent(a) {
      this.g.dispatchEvent(a.widgetId, a.eventType, a.properties);
    }
    O(a) {
      this.g.O(a.eventType, void 0, a.properties);
    }
    listen(a, b, c) {
      this.g.listen(
        a.eventType,
        (d, e, f) => {
          d = {
            module: "REVJET_Tag.Ad",
            method: "dispatchEvent",
            messageId: b,
            properties: { eventType: d, widgetId: e, event: f },
          };
          try {
            c.postMessage(JSON.stringify(d), "*");
          } catch (g) {}
        },
        a.widgetId
      );
    }
    show(a) {
      this.g.show(a.widgetId, a.method, a.position);
    }
    ka(a) {
      this.g.ka(a.widgetId, a.method, a.position);
    }
    Ta(a) {
      this.g.Ta(a.stageId, a.sceneId);
    }
    Ga(a) {
      this.g.Ga(a.stageId, a.sourceStageId);
    }
    B(a) {
      this.g.B(a);
    }
    Ma(a, b, c) {
      a = {
        module: "REVJET_Tag.Ad",
        method: "setLayout",
        messageId: b,
        properties: { layout: this.g.Ma() },
      };
      try {
        c.postMessage(JSON.stringify(a), "*");
      } catch (d) {}
    }
  }
  Z.prototype.getLayout = Z.prototype.Ma;
  Z.prototype.runAction = Z.prototype.B;
  Z.prototype.collapseStage = Z.prototype.Ga;
  Z.prototype.showStage = Z.prototype.Ta;
  Z.prototype.hide = Z.prototype.ka;
  Z.prototype.show = Z.prototype.show;
  Z.prototype.listen = Z.prototype.listen;
  Z.prototype.broadcastEvent = Z.prototype.O;
  Z.prototype.dispatchEvent = Z.prototype.dispatchEvent;
  class Dl extends F {
    constructor(a) {
      super("hype_scene_load", { sceneName: a });
    }
    Oa() {
      return this.A("sceneName");
    }
    g(a) {
      return a.sceneName === this.Oa();
    }
  }
  Dl.prototype.getSceneName = Dl.prototype.Oa;
  class El extends F {
    constructor(a) {
      super("hype_scene_unload", { sceneName: a });
    }
    Oa() {
      return this.A("sceneName");
    }
    g(a) {
      return a.sceneName === this.Oa();
    }
  }
  El.prototype.getSceneName = El.prototype.Oa;
  class Fl extends F {
    constructor(a) {
      super("hype_timeline_complete", { timelineName: a });
    }
    ec() {
      return this.A("timelineName");
    }
    g(a) {
      return a.timelineName === this.ec();
    }
  }
  Fl.prototype.getTimelineName = Fl.prototype.ec;
  function Gl() {
    try {
      if (window !== window.top) {
        const c = window.parent;
        if (c.REVJET_Tag || c.REVJET_TagObj_1) return !0;
        a: {
          const d = document.querySelector(
            'meta[name="innervate:tag:options"][content]'
          );
          if (d)
            try {
              var a = JSON.parse(d.getAttribute("content") || "{}");
              break a;
            } catch (e) {}
          a = {};
        }
        if (a && 0 < Object.keys(a).length) return !0;
        a: {
          const d = document.querySelector(
            'meta[name="innervate:slot:options"][content]'
          );
          if (d)
            try {
              var b = JSON.parse(d.getAttribute("content") || "{}");
              break a;
            } catch (e) {}
          b = {};
        }
        if (b && b.js_tag_env) return !0;
      }
    } catch (c) {}
    return !1;
  }
  function Hl(a, b, c) {
    a.h = !0;
    const d = a.m();
    null != d
      ? Il(a, d, b, c)
      : (a.C || a.L || ((a.L = !0), Jl("0")), (a.h = !1));
    return a.h;
  }
  function Kl(a, b) {
    a.h ? (a.j = b) : Hl(a, -1, () => b(!0));
  }
  function Ll(a) {
    a.v = Wb(window, "message", (b) => Ml(a, b));
  }
  function Nl(a, b, c) {
    const d = "duration" in b ? parseInt(b.duration, 10) : 30,
      e = b.pixelPattern,
      f = (g, h) => {
        const k = b[h];
        null != k && "" !== k && a.s.push({ t: g, u: k, p: e, l: c, n: h });
      };
    f(0, "start");
    f(Math.floor(250 * d), "firstQuartile");
    f(Math.floor(500 * d), "midpoint");
    f(Math.floor(750 * d), "thirdQuartile");
    f(1e3 * d, "complete");
  }
  function Ol(a, b) {
    const c = a.m();
    if (null != c) {
      var d = null;
      d = a.o(c, 0, (e) => {
        null != d &&
          (d.g(), (d = null), Pl(a, b.pixelPattern, b["0s"], a.F, e, "0s"));
      });
      d.i = 0.001;
      null != d && d.h();
    }
  }
  function Ql(a) {
    a.h &&
      (null !== a.j &&
        ("function" === typeof a.j
          ? a.j(!0)
          : Rl({ salt: !0, slotObjectName: a.j }),
        (a.j = null)),
      (a.h = !1));
    if (a.i >= a.s.length) return !1;
    const b = a.s[a.i];
    if (0 === a.i) {
      if (!Hl(a, 0, () => Ql(a))) return a.i++, !1;
    } else {
      const c = a.i;
      window.setTimeout(
        () => Hl(a, c, () => Ql(a)),
        b.t - a.s[a.i - 1].t - 1e3
      );
    }
    a.i++;
    return !0;
  }
  function Sl(a, b) {
    const c = Ob();
    Qb() && null !== c
      ? Yb(c[1], () => Sl(a, b))
      : window.setTimeout(() => {
          0 === a.D && ((a.D = 1), (a.F = !0), Pl(a), (a.s = []), Nl(a, b, !0));
        }, 1e4);
  }
  function Tl() {
    var a = new Ul();
    if (
      "undefined" !== typeof window.Salt &&
      window.Salt &&
      window.Salt.adsDomainName &&
      window.Salt.adsDomainName
    ) {
      Mb && Nb && Ll(a);
      var b = window.Salt;
      "mduration" in b && (a.R = b.mduration);
      window.Salt = window.Salt || {};
      window.Salt.getStatus = (c) => Kl(a, c);
      "start" in b &&
        (Nl(a, b, !1),
        "0s" in b && Ol(a, b),
        Ql(a) && "invisible" in b && Sl(a, b));
    }
  }
  function Vl(a, b) {
    new Image(1, 1).src = a;
    b &&
      window.revjet &&
      window.revjet.elements_api &&
      window.revjet.elements_api.dispatchEvent(
        "RootWidget",
        "viewable_event",
        b
      );
  }
  function Pl(a, b, c, d, e, f) {
    const g = window.Salt;
    b = b ? b : g.pixelPattern;
    c = c ? c : g.invisible;
    b &&
      ((a.D = 2),
      (a = b + (-1 === b.indexOf("?") ? "?" : "&")),
      e && (a += "vis_type=" + e + "&"),
      (a += "__stamp=" + new Date().getTime()),
      (a = a.replace("%%PIXEL%%", c)),
      (a = a.replace("%%LATENT%%", d ? "1" : "0")),
      Vl(a, { name: f ? f : "invisible", num: c, type: e, latent: d }));
  }
  function Jl(a, b) {
    var c = window.Salt;
    c &&
      (c = c.pixelPattern) &&
      Vl(
        (
          `${c}${-1 === c.indexOf("?") ? "?" : "&"}measurable=${a}` +
          `&vis_type=${b || 0}&__stamp=${new Date().getTime()}`
        )
          .replace("%%PIXEL%%", "915")
          .replace("%%LATENT%%", "-1")
      );
  }
  function Wl(a, b) {
    a.C || a.H || ((a.H = !0), Jl("1", b));
  }
  function Il(a, b, c, d) {
    a.g && (a.g.g(), (a.g = null));
    a.g = a.o(b, a.R, (e) => {
      a.g && (a.g.g(), (a.g = null));
      if (!(0 > c || 0 > c)) {
        var f = a.s[c];
        Pl(a, f.p, f.u, f.l, e, f.n);
      }
      d();
    });
    a.g && (Wl(a, b), a.g.h());
  }
  function Rl(a) {
    if (Mb && Nb) {
      a = {
        module: "REVJET_Tag.Salt",
        method: "setSalt",
        messageId:
          new Date().getTime() + "-" + Math.floor(100 * Math.random() + 1),
        properties: a,
      };
      try {
        window.parent.postMessage(JSON.stringify(a), "*");
      } catch (b) {}
    }
  }
  function Ml(a, b) {
    let c = null;
    try {
      c = JSON.parse(b.data);
    } catch (d) {}
    if (c && "REVJET_Salt" === c.module && "getSalt" === c.method) {
      const d = c.properties;
      a.h
        ? (a.j = d.slotObjectName)
        : Hl(a, -1, () => Rl({ salt: !0, slotObjectName: d.slotObjectName }));
      Xb(a.v);
      a.v = -1;
    }
  }
  class Xl {
    constructor() {
      this.D = 0;
      this.s = [];
      this.i = 0;
      this.h = !1;
      this.j = null;
      this.v = -1;
      this.R = 1e3;
      this.g = null;
      this.H = this.L = !1;
      this.C = Gl();
      this.F = !1;
    }
    o(a, b, c) {
      return 2 === a
        ? new ye(b, c)
        : 3 === a
        ? new Nd(b, c)
        : 4 === a
        ? new Xd(b, c)
        : 5 === a
        ? new lc(b, c)
        : 6 === a
        ? new Td(b, c)
        : 7 === a
        ? new Hd(b, c)
        : 8 === a
        ? new Qd(b, c)
        : null;
    }
    m() {
      if (ac()) return 5;
      if (Fd()) return 7;
      if (Od()) return 8;
      if (Ud()) return 4;
      if (Jd()) return 3;
      if (xe()) return 2;
      if (!Rd()) return 6;
    }
  }
  class Ul extends Xl {
    o(a, b, c) {
      const d = super.o(a, b, c);
      return null != d ? d : 9 === a ? new Ue(b, c) : null;
    }
    m() {
      return te(Fe()) ? 9 : super.m();
    }
  }
  function Yl(a) {
    const b = new Z(a);
    window.addEventListener(
      "message",
      (c) => {
        if (c && "data" in c) {
          var d = null;
          try {
            d = JSON.parse(c.data);
          } catch (e) {}
          if (
            null != d &&
            ("LSM_Elements" === d.module || "revjet.elements" === d.module) &&
            d.method
          ) {
            const e = d.method;
            Z.prototype[e] &&
              Z.prototype[e].call(b, d.properties, d.messageId, c.source);
          }
        }
      },
      !1
    );
  }
  function Zl(a) {
    const b = new Y(a);
    Bl(b, "revjet.elements");
    Bl(b, "revjet.elements_api");
    Yl(b);
    const c = window.revjet.elements_api.layoutEventListeners_ || [];
    for (const d of c)
      d.once
        ? a.listenOnce(d.eventType, d.listener, d.widgetId, d.source)
        : a.listen(d.eventType, d.listener, d.widgetId, d.source);
    window.revjet.elements_api.layoutEventListeners_ = [];
    try {
      for (a = window; a !== window.top; ) {
        a = a.parent;
        const d = ma("revjet.elements.onInitialized", a);
        if (p(d)) {
          d.forEach((e) => e(b, window));
          break;
        }
      }
    } catch (d) {}
  }
  function $l(a) {
    const b = Mc();
    Qc(b, (c, d) => {
      c && pl(a, c, d);
    });
    Oc(b, window.document);
  }
  function am(a) {
    const b = rc();
    tc(b) &&
      (b.addEventListener(2, () =>
        a.dispatchEvent("RootWidget", "mraid_loaded")
      ),
      b.addEventListener(1, () => a.dispatchEvent("RootWidget", "mraid_ready")),
      b.addEventListener(0, () =>
        a.dispatchEvent("RootWidget", "mraid_viewable")
      ),
      (b.s = a.j),
      yc(b));
  }
  function bm() {
    const a = window.document.body.getBoundingClientRect();
    va("resized", y(), {
      top: a.top,
      right: a.right,
      bottom: a.bottom,
      left: a.left,
      width: a.width,
      height: a.height,
      x: a.x,
      y: a.y,
    });
  }
  function cm() {
    bm();
    window.ResizeObserver &&
      window.document.body &&
      new window.ResizeObserver((a) => {
        for (let b of a) b.target === window.document.body && bm();
      }).observe(window.document.body);
  }
  function dm() {
    return new Promise((a) => {
      let b = !1,
        c = null;
      const d = We(),
        e = () => {
          if (!b) {
            b = !0;
            sd(d, e);
            if (c) {
              if (f && c)
                try {
                  f.removeEventListener("viewableChange", c);
                } catch (g) {}
              c = null;
            }
            a();
          }
        };
      d.listen("viewable", e);
      const f = ac();
      if (f) {
        c = () => {
          em(f) && e();
        };
        if (f && c)
          try {
            f.addEventListener("viewableChange", c);
          } catch (g) {}
        em(f) && e();
      }
    });
  }
  function em(a) {
    try {
      return !!a && la(a.isViewable) && !0 === a.isViewable();
    } catch (b) {
      return !1;
    }
  }
  function fm(a) {
    a.g
      .filter((b) => b.K("html5_element"))
      .forEach((b) => {
        const c = b.G();
        b = new Jg(c);
        zg(c)
          ? a.dispatchEvent(c, "hype_document_load")
          : b.listen("HypeDocumentLoad", () =>
              a.dispatchEvent(c, "hype_document_load")
            );
        b.listen("HypeSceneLoad", (d) => {
          d = new Dl(d.ma.currentSceneName());
          ml(a, c, d);
        });
        b.listen("HypeSceneUnload", (d) => {
          d = new El(d.ma.currentSceneName());
          ml(a, c, d);
        });
        b.listen("HypeTimelineComplete", (d, e) => {
          d = new Fl(e);
          ml(a, c, d);
        });
      });
  }
  function gm(a) {
    var b;
    let c;
    const d =
      null == (b = window.revjet)
        ? void 0
        : null == (c = b.elements_api)
        ? void 0
        : c.initialErrorHandler_;
    null != d &&
      (window.removeEventListener("error", d, !1),
      (window.revjet.elements_api.initialErrorHandler_ = null));
    let e, f, g;
    b =
      null !=
      (g =
        null == (e = window.revjet)
          ? void 0
          : null == (f = e.elements_api)
          ? void 0
          : f.javaScriptErrors_)
        ? g
        : [];
    for (const k of b)
      ml(a, "RootWidget", new I(k.message, 1, k.filename, k.lineno, k.colno));
    let h;
    if (null == (h = window.revjet) ? 0 : h.elements_api)
      window.revjet.elements_api.javaScriptErrors_ = [];
    window.addEventListener(
      "error",
      (k) => {
        ml(a, "RootWidget", new I(k.message, 1, k.filename, k.lineno, k.colno));
      },
      !1
    );
  }
  function hm(a) {
    const b = ma("revjet.elements");
    p(b)
      ? im(b.get(), a)
      : ma("revjet").forEach((c) => {
          let d = void 0;
          Object.defineProperty(c, "elements", {
            set: (e) => {
              (d = e) && im(d, a);
            },
            get: () => d,
          });
        });
  }
  function im(a, b) {
    m(function* () {
      var c = G();
      Kb(c, a.options || {});
      const d = new vl(a);
      jl(d);
      gm(d);
      ta() && !Cc() && ul(d);
      Zl(d);
      xb();
      const e = S();
      e.s = d;
      Ii(e, a.staticPersonalization);
      const f = a.personalization || [];
      e.i = f.slice();
      e.Ba(Ji(e, f));
      const g = Fc();
      null != g &&
        (Array.isArray(g)
          ? e.Ba(Ji(e, g))
          : e.Ba(
              Ji(
                e,
                e.i.map((h) => (h.id === g.id ? g : h))
              )
            ));
      yield d.load();
      $l(d);
      Cc() || Tl();
      am(d);
      d.O("ready", !0, { version: "3.64.0" });
      ql(d);
      yield ll(d);
      Mi(e, (h, k) => ml(d, h, k));
      va("setElementsInitialized", y(), {
        initialized: !0,
        showCloseButton: !d.j,
        isEmptyPersonalization: Qi(e),
        options: {
          hideBody: c.g,
          hideMethod: c.i,
          showTimeout: c.C,
          disableAnimation: c.h,
          maxAnimationDuration: r(c.s),
          hideCreative: c.m,
          canonicalEventURL: c.j,
          isIframeAsset: c.o,
        },
      });
      "dynamic" === wc().responsive_height && cm();
      if ("complete" !== document.readyState) {
        const h = function (k) {
          window.removeEventListener("load", h, !1);
          d.dispatchEvent("RootWidget", "resource_load_complete", {
            timeStamp: k.timeStamp,
          });
        };
        window.addEventListener("load", h, !1);
      } else d.dispatchEvent("RootWidget", "resource_load_complete", {});
      yield Oi(S());
      c = d.g;
      for (const h of c)
        Ri(e, h.G()) &&
          da(
            K(h).map((k) => A(k, "img[data-revjet-image-src]")),
            []
          ).forEach((k) => {
            const l = k.getAttribute("data-revjet-image-src");
            l && (k.removeAttribute("data-revjet-image-src"), (k.src = l));
          });
      b || (yield dm());
      d.O("after_personalization", !0);
      rl(d);
      fm(d);
      d.O("viewable");
    });
  }
  window.NodeList &&
    !NodeList.prototype.forEach &&
    (NodeList.prototype.forEach = Array.prototype.forEach);
  try {
    ba();
  } catch (a) {}
  (function (a) {
    yg("HypeDocumentLoad", Ag.bind(w, "HypeDocumentLoad"));
    yg("HypeSceneLoad", Ag.bind(w, "HypeSceneLoad"));
    yg("HypeSceneUnload", Ag.bind(w, "HypeSceneUnload"));
    yg("HypeTimelineComplete", Ag.bind(w, "HypeTimelineComplete"));
    "loading" !== window.document.readyState
      ? hm(a)
      : window.document.addEventListener("DOMContentLoaded", () => hm(a), !1);
  })();
}.call(this));
