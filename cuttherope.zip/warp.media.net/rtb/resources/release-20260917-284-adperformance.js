!(function () {
  "use strict";
  function e(e) {
    return null != e;
  }
  function t(t) {
    return e(t) && "" !== t;
  }
  function i(e) {
    return "function" == typeof e;
  }
  function n(e) {
    return "[object Array]" === Object.prototype.toString.call(e);
  }
  function s(e, t) {
    let i = Math.floor(Math.random() * (t - e + 1) + e);
    return i > t && (i = t), i;
  }
  function r(t, i, n) {
    e(t) && t.addEventListener
      ? t.addEventListener(i, n, !1)
      : e(t) && t.attachEvent && t.attachEvent("on" + i, n),
      (t = null);
  }
  function o(t, i, n) {
    e(t) && t.removeEventListener
      ? t.removeEventListener(i, n, !1)
      : e(t) && t.detachEvent && t.detachEvent("on" + i, n),
      (t = null);
  }
  const a = (e) => {
    try {
      const i = e.charAt(0),
        n = e.substr(1).split(":"),
        s = n[0],
        r = t(n[1]) && parseInt(n[1], 10);
      let o;
      switch (i) {
        case "@":
          o = document.getElementsByTagName(s);
          break;
        case "#":
          o = document.getElementById(s);
          break;
        case "$":
          o = document.getElementsByName(s);
          break;
        case ".":
          o = document.getElementsByClassName(s);
          break;
        default:
          o = document.getElementById(e);
      }
      return !o || "boolean" == typeof r || o instanceof HTMLElement
        ? o
        : o.item(r);
    } catch (e) {
      return null;
    }
  };
  function l(e, t, i) {
    return e
      ? (i &&
          "string" == typeof t &&
          (t = (function (e) {
            if (!e) return "";
            return encodeURIComponent(e);
          })(t)),
        "&" + e + "=" + t)
      : "";
  }
  function c() {
    return (
      (function (e, t) {
        let i =
          !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2];
        if (e.length >= t) return e;
        const n = t - e.length,
          s = [];
        for (let e = 0; e < n; e++) s.push("0");
        return i ? s.join("") + e : e + s.join("");
      })(
        "" +
          ((e) => {
            const t = e.split(".");
            return 256 * (256 * (256 * +t[0] + +t[1]) + +t[2]) + +t[3];
          })(s(0, 254) + "." + s(0, 254) + "." + s(0, 254) + "." + s(0, 254)),
        10
      ) +
      "" +
      s(1e6, 9999999) +
      Date.now().toString()
    );
  }
  class h {
    constructor(e) {
      this.execExistingFunctionsInQueue(e);
    }
    push(e) {
      try {
        h.executeFunction(e);
      } catch (e) {
        console.log("ERR", e);
      }
    }
    static executeFunction(e) {
      i(e) && e();
    }
    execExistingFunctionsInQueue(e) {
      for (const t of e) this.push(t);
    }
  }
  const d = "IMPRESSION_CLICKED",
    u = "IMPRESSION_VIEWED";
  var m, p, g;
  !(function (e) {
    (e[(e.ABSTRACT = 0)] = "ABSTRACT"),
      (e[(e.UNLOAD = 1)] = "UNLOAD"),
      (e[(e.ACTIVE_ELEMENT = 2)] = "ACTIVE_ELEMENT"),
      (e[(e.OMID = 3)] = "OMID");
  })(m || (m = {})),
    (function (e) {
      (e[(e.INTERSECTION_OBSERVER = 1)] = "INTERSECTION_OBSERVER"),
        (e[(e.DOM = 2)] = "DOM"),
        (e[(e.DFP = 3)] = "DFP"),
        (e[(e.DEFAULT = 4)] = "DEFAULT"),
        (e[(e.MRAID = 5)] = "MRAID"),
        (e[(e.OMID_DISPLAY = 6)] = "OMID_DISPLAY"),
        (e[(e.OMID_VIDEO = 7)] = "OMID_VIDEO");
    })(p || (p = {})),
    (function (e) {
      e[(e.UNKNOWN = -1)] = "UNKNOWN";
    })(g || (g = {}));
  const w = "focus",
    f = 200;
  var E;
  !(function (e) {
    (e.VIEW = "VIEW"), (e.CLICK = "CLICK");
  })(E || (E = {}));
  const v = new (class {
    constructor() {
      this.trackerMap = new Map();
    }
    add(t) {
      return e(t) && this.trackerMap.set(t.id, t), this;
    }
    each(e) {
      this.trackerMap.forEach((t, i) => {
        e(t, i);
      });
    }
    find(t) {
      const i = this.trackerMap.get(t);
      return e(i) ? i : null;
    }
    remove(e) {
      return this.trackerMap.delete(e.id), this;
    }
    values() {
      return [];
    }
  })();
  var b;
  !(function (e) {
    (e[(e.TRACKING = 0)] = "TRACKING"), (e[(e.DISABLED = 1)] = "DISABLED");
  })(b || (b = {}));
  class T {
    constructor(e) {
      (this.eventName = e), (this.listeners = new Array());
    }
    addListener(e) {
      const t = {
        callback: e,
        once: arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
      };
      this.listeners.push(t);
    }
    removeListener(e) {
      const t = this.findListener(e);
      if (t) {
        const e = this.listeners.indexOf(t);
        this.listeners.splice(e, 1);
      }
    }
    triggerListeners(e, t) {
      this.listeners.slice(0).forEach((i) => {
        t || e
          ? t
            ? i.callback(void 0, t)
            : e && i.callback(e)
          : i.callback(),
          i.once && this.removeListener(i.callback);
      });
    }
    findListener(e) {
      return this.listeners.find((t) => t.callback === e);
    }
  }
  class I extends class {
    constructor() {
      this.events = new Map();
    }
    on(e, t) {
      let i =
          !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
        n = this.events.get(e);
      n || ((n = new T(e)), this.events.set(e, n)), n.addListener(t, i);
    }
    off(e, t) {
      const i = this.events.get(e);
      i &&
        (i.removeListener(t),
        0 === i.listeners.length && this.events.delete(e));
    }
    emit(e, t, i) {
      const n = this.events.get(e);
      n &&
        (void 0 === t && void 0 === i
          ? n.triggerListeners()
          : void 0 === t ||
            "number" == typeof t ||
            t instanceof Error ||
            void 0 !== i
          ? "number" == typeof t && void 0 === i
            ? setTimeout(() => {
                n.triggerListeners();
              }, t)
            : void 0 === t ||
              "number" == typeof t ||
              t instanceof Error ||
              "number" != typeof i
            ? void 0 !== t &&
              "number" != typeof t &&
              t instanceof Error &&
              void 0 === i
              ? n.triggerListeners(t, void 0)
              : void 0 !== t &&
                "number" != typeof t &&
                t instanceof Error &&
                "number" == typeof i &&
                setTimeout(() => {
                  n.triggerListeners(t, void 0);
                }, i)
            : setTimeout(() => {
                n.triggerListeners(void 0, t);
              }, i)
          : n.triggerListeners(void 0, t));
    }
    destroy(e) {
      this.events.get(e) && this.events.delete(e);
    }
  } {
    constructor(e, t) {
      super(),
        (this.stateMap = new Map()),
        (this.detectorMap = new Map()),
        (this.id = t);
      for (const t of e)
        this.stateMap.set(t.type, b.TRACKING),
          this.detectorMap.set(t.type, t),
          t.startTracking((e) => {
            this.isActive(t.type) &&
              (t.isOneTimeEvent() &&
                (t.disable(this.id), this.stateMap.set(t.type, b.DISABLED)),
              this.emit(t.event, e));
          }, this.id);
    }
    getMeta(e) {
      var t;
      return (
        (null === (t = this.detectorMap.get(e)) || void 0 === t
          ? void 0
          : t.getMeta(this.id)) || { strategyUsed: g.UNKNOWN }
      );
    }
    killType(t) {
      this.stateMap.set(t, b.DISABLED);
      const i = this.detectorMap.get(t);
      e(i) && i.stopTracking(this.id);
    }
    isActive(e) {
      return this.stateMap.get(e) === b.TRACKING;
    }
    kill(e) {
      for (const t of e) this.killType(t);
    }
  }
  class M {
    constructor() {
      this.trackerTypeToDetectorsMap = new Map();
    }
    static getDetectorByPreference(t, i) {
      for (const n of t) if (e(n) && n.isSupported(i)) return n;
      return null;
    }
    getDetector(t, i) {
      if (e(i) && e(this.trackerTypeToDetectorsMap)) {
        const n = this.trackerTypeToDetectorsMap.get(t);
        if (e(n)) return M.getDetectorByPreference(n, i);
      }
      return null;
    }
    setupDetectors(e) {
      for (const t of e) {
        const e = t.type,
          i = this.trackerTypeToDetectorsMap.get(e) || [];
        i.push(t), this.trackerTypeToDetectorsMap.set(t.type, i);
      }
    }
    getNewTracker(t, i) {
      let n = v.find(i);
      null !== n && n.kill(t);
      const s = [];
      for (const n of t) {
        const t = this.getDetector(n, i);
        e(t) && s.push(t);
      }
      return 0 === s.length ? null : ((n = new I(s, i)), v.add(n), n);
    }
    getTracker(e) {
      return v.find(e);
    }
    removeTracker(t, i) {
      e(t) && (v.remove(t), t.kill(i));
    }
    enableDebugger() {}
  }
  const C = new M();
  function k() {
    return document[
      (function () {
        if (void 0 !== document.hidden) return "hidden";
        if (void 0 !== document.mozHidden) return "mozHidden";
        if (void 0 !== document.msHidden) return "msHidden";
        if (void 0 !== document.webkitHidden) return "webkitHidden";
        return "";
      })()
    ];
  }
  const L = 242e3,
    A = 100,
    D = 50,
    y = 0.5,
    V = 1e3,
    S = 30,
    O = 0.3,
    N = 1e3,
    P = 50,
    R = 2e3,
    _ = () => {};
  class F {
    constructor(e) {
      (this.onTime = new Date().getTime()),
        (this.onTimeCount = 0),
        (this.status = 1),
        (this.upperBound = e),
        (this.countdown = e),
        (this.timerId = c());
    }
    get id() {
      return this.timerId;
    }
    get onCount() {
      return this.onTimeCount;
    }
    getElapsedTime() {
      return this.isTimerOn()
        ? this.upperBound - this.getRemainingCountdownTime()
        : this.upperBound - this.countdown;
    }
    getRemainingCountdownTime() {
      const e = new Date().getTime() - this.onTime;
      return this.countdown - e;
    }
    on() {
      return (
        this.isTimerOn() ||
          ((this.status = 0),
          (this.timeoutId = setTimeout(() => {
            this.countdownComplete();
          }, this.countdown)),
          (this.onTime = new Date().getTime())),
        this.onTimeCount++,
        this.countdown
      );
    }
    pause() {
      return (
        this.isTimerOn() &&
          (clearTimeout(this.timeoutId),
          (this.countdown = this.getRemainingCountdownTime()),
          (this.status = 2)),
        this.countdown
      );
    }
    time() {
      return this.countdown;
    }
    isTimerOn() {
      return 0 === this.status;
    }
    countdownComplete() {
      this.callback(!0), (this.callback = _);
    }
  }
  function H(e) {
    return e.clientWidth * e.clientHeight >= L ? 1 : 0;
  }
  function U(t, i, n) {
    const s = t.get(i);
    if (!e(s)) return { strategyUsed: n };
    const r = s.getElapsedTime();
    return { inViewCount: s.onCount, inViewTime: r, strategyUsed: n };
  }
  function B(t, i) {
    let n = t.get(i);
    return e(n) || ((n = new F(1e9)), t.set(i, n)), n;
  }
  function K(e) {
    switch (H(e)) {
      case 0:
        return V;
      case 1:
        return N;
      case 2:
        return R;
      default:
        return 1e3;
    }
  }
  class x {
    constructor() {
      this.mraidEventsSet = !1;
    }
    static setMraidScreenVisibility(t) {
      e(window.mraid) &&
        i(window.mraid.isViewable) &&
        t(window.mraid.isViewable());
    }
    setMraidEvents(t) {
      this.mraidEventsSet ||
        (e(window.mraid) &&
          e(window.mraid.addEventListener) &&
          (parseInt(window.mraid.getVersion()) >= 3
            ? window.mraid.addEventListener("exposureChange", (e, i, n) => {
                t(e > 0);
              })
            : window.mraid.addEventListener("viewableChange", (e) => {
                t(e);
              })));
    }
    setChecksForInApp(e) {
      x.setMraidScreenVisibility(e), this.setMraidEvents(e);
    }
  }
  const W = new x();
  const G = new (class {
    constructor() {
      (this.switchListeners = []), (this.isListening = !1);
    }
    visibilityChangeEventListener() {
      const e = !k();
      this.notifyListeners(e);
    }
    notifyListeners(e) {
      this.switchListeners.forEach((t) => {
        t.listener(e, t.element);
      });
    }
    refreshTimeout(e) {
      let t,
        i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : f;
      return (n) => {
        clearTimeout(t), (t = setTimeout(() => e(n), i));
      };
    }
    track(e) {
      this.switchListeners.push({ element: e.element, listener: e.listener });
    }
    listen() {
      if (this.isListening) return;
      this.isListening = !0;
      const e = this.refreshTimeout(
        this.visibilityChangeEventListener.bind(this),
        f
      );
      r(
        window,
        void 0 !== document.hidden
          ? "visibilitychange"
          : void 0 !== document.mozHidden
          ? "mozvisibilitychange"
          : void 0 !== document.msHidden
          ? "msvisibilitychange"
          : void 0 !== document.webkitHidden
          ? "webkitvisibilitychange"
          : "",
        e
      ),
        r(window, w, e);
    }
  })();
  function Y(e, t) {
    G.track({
      element: t,
      listener: (i) => {
        if (!i) {
          B(e, t).pause();
        }
      },
    });
  }
  const z = (e, t, n) => {
    const s = i(n) ? n : Date.now;
    let r = s();
    return function () {
      const i = s();
      if (i - r >= e) {
        r = i;
        for (var n = arguments.length, o = new Array(n), a = 0; a < n; a++)
          o[a] = arguments[a];
        t.apply(null, o);
      }
    };
  };
  const j = new (class {
    constructor() {
      (this.elementInViewMap = new Map()),
        (this.elementDebounceIdMap = new Map()),
        (this.isScreenVisible = !0),
        (this.targetViewTimerMap = new Map()),
        this.isSupported() &&
          (this.setObserverForAds(),
          this.setObserverForLargeAds(),
          W.setChecksForInApp((e) => {
            this.mraidCallback(e);
          }));
    }
    setObserverForLargeAds() {
      const e = { threshold: O };
      this.IOForLargeAds = new window.IntersectionObserver(
        this.handlerForLargeAds.bind(this),
        e
      );
    }
    setObserverForAds() {
      const e = { threshold: y };
      this.IOForAds = new window.IntersectionObserver(
        this.handlerForAds.bind(this),
        e
      );
    }
    handlerForAds(e, t) {
      e.forEach((e) => {
        const t = e.target,
          i = B(this.targetViewTimerMap, t);
        e.intersectionRatio >= y
          ? (this.elementInViewMap.set(t, !0),
            this.checkForViewableIABTime(t, V),
            i.on())
          : (this.elementInViewMap.set(t, !1), i.pause());
      });
    }
    handlerForLargeAds(e, t) {
      e.forEach((e) => {
        const t = e.target,
          i = B(this.targetViewTimerMap, t);
        e.intersectionRatio >= O
          ? (this.elementInViewMap.set(t, !0),
            this.checkForViewableIABTime(t, N),
            i.on())
          : (this.elementInViewMap.set(t, !1), i.pause());
      });
    }
    checkForViewableIABTime(t) {
      let i =
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1e3;
      const n = (function (t, i, n) {
        return e(t) && clearInterval(t), window.setTimeout(n, i);
      })(
        (this.elementDebounceIdMap.has(t) &&
          this.elementDebounceIdMap.get(t)) ||
          null,
        i,
        this.postThresholdTimeCheck(t)
      );
      this.elementDebounceIdMap.set(t, n);
    }
    postThresholdTimeCheck(e) {
      return () => {
        this.elementInViewMap.has(e) &&
          this.elementInViewMap.get(e) &&
          i(this.genericCallbackForElements) &&
          this.isScreenVisible &&
          this.genericCallbackForElements(e);
      };
    }
    mraidCallback(e) {
      if (((this.isScreenVisible = e), this.isScreenVisible))
        for (const [e, t] of this.elementInViewMap)
          t && this.checkForViewableIABTime(e);
    }
    getMeta(e) {
      return U(this.targetViewTimerMap, e, p.INTERSECTION_OBSERVER);
    }
    set fireCallbackForElement(e) {
      this.genericCallbackForElements = e;
    }
    observe(e) {
      const t = H(e);
      switch ((Y(this.targetViewTimerMap, e), t)) {
        case 0:
          this.IOForAds.observe(e);
          break;
        case 1:
          this.IOForLargeAds.observe(e);
      }
    }
    unobserve(e) {
      switch (H(e)) {
        case 0:
          this.IOForAds.unobserve(e);
          break;
        case 1:
          this.IOForLargeAds.unobserve(e);
      }
      this.elementInViewMap.set(e, !1), this.targetViewTimerMap.delete(e);
    }
    isSupported() {
      return i(window.IntersectionObserver);
    }
  })();
  let X, q, Q, J, $;
  function Z() {
    const e = { width: (t = oe).innerWidth, height: t.innerHeight };
    var t;
    q = { width: e.width, height: e.height };
  }
  function ee(t) {
    if ((e(t) && t && Z(), i(X))) {
      X().forEach(te);
    }
  }
  function te(t) {
    const i = $(),
      n = i.get(t.id);
    if (!e(n)) return;
    const s = q,
      r = ie(t, s);
    if (n.previousStatus === r) return;
    e(n.timerId) && clearTimeout(n.timerId);
    const o = B(J(), t);
    let a = null;
    if (r) {
      o.on();
      const e = () => {
          ie(t, s) && Q(t);
        },
        i = K(t);
      a = window.setTimeout(e, i);
    } else o.pause();
    i.set(t.id, { previousStatus: r, timerId: a });
  }
  function ie(e, t) {
    switch (H(e)) {
      case 0:
        return (function (e, t) {
          return se(e, t) >= D;
        })(e, t);
      case 1:
        return (function (e, t) {
          return se(e, t) >= S;
        })(e, t);
      default:
        return !1;
    }
  }
  function ne(e) {
    return (
      (e.pageYOffset && { X: e.pageXOffset, Y: e.pageYOffset }) || {
        X: 0,
        Y: 0,
      }
    );
  }
  function se(t, i) {
    if (!(e(i) && e(i.width) && e(i.height))) return 0;
    const n = (function (e) {
        const t = ne(oe),
          i = oe;
        let n = window,
          s = e,
          r = 0,
          o = 0;
        do {
          const e = s.getBoundingClientRect();
          if (n === i) {
            const t = ne(n);
            (r += e.left + t.X), (o += e.top + t.Y);
            break;
          }
          (r += e.left),
            (o += e.top),
            n.frameElement && (s = n.frameElement),
            (n = n.parent);
        } while (n && n.document);
        return {
          height: e.clientHeight,
          left: r - t.X,
          top: o - t.Y,
          width: s.clientWidth,
          x: r - t.X,
          y: o - t.Y,
        };
      })(t),
      s = n.left,
      r = n.top,
      o = n.width,
      a = n.height;
    return (
      ((re(0, i.width, s, s + o) * re(0, i.height, r, r + a)) / (o * a)) * 100
    );
  }
  function re(e, t, i, n) {
    return e >= t || i >= n || n <= e || i >= t
      ? 0
      : e <= i && t >= n
      ? n - i
      : e >= i && t <= n
      ? t - e
      : e > i && t > n
      ? n - e
      : e < i && t < n
      ? t - i
      : 0;
  }
  const oe = (function () {
    let e = window;
    if (window.top) {
      const t = window.top;
      try {
        let i = 0;
        if (t)
          for (; e !== t && i < 20; ) {
            e.parent.innerWidth;
            (e = e.parent), i++;
          }
      } catch (e) {}
    }
    return e;
  })();
  const ae = z(A, function () {
    ee();
  });
  const le = z(A, function () {
    ee(!0);
  });
  class ce {
    constructor() {
      var e, t, i, n;
      (this.isScreenVisible = !0),
        (this.targetViewTimerMap = new Map()),
        (this.elementVisibilityStateMap = new Map()),
        (this.elementList = []),
        (this.tracking = !1),
        (e = this.getElementList.bind(this)),
        (t = this.fireCallback.bind(this)),
        (i = this.getTargetViewTimerMap.bind(this)),
        (n = this.getElementVisibilityStateMap.bind(this)),
        (X = e),
        (Q = t),
        Z(),
        (J = i),
        ($ = n),
        W.setChecksForInApp((e) => {
          this.mraidCallback(e);
        });
    }
    static setupEventHandlers() {
      r(window, "scroll", ae), r(window, "resize", le);
    }
    static unsetEventHandlers() {
      o(window, "scroll", ae), o(window, "resize", le);
    }
    getElementList() {
      return this.elementList;
    }
    getMeta(e) {
      return U(this.targetViewTimerMap, e, p.DOM);
    }
    getTargetViewTimerMap() {
      return this.targetViewTimerMap;
    }
    getElementVisibilityStateMap() {
      return this.elementVisibilityStateMap;
    }
    fireCallback(t) {
      e(this.genericCallbackForElements) &&
        this.isScreenVisible &&
        this.genericCallbackForElements(t);
    }
    mraidCallback(e) {
      (this.isScreenVisible = e), this.isScreenVisible && ae();
    }
    set fireCallbackForElement(e) {
      this.genericCallbackForElements = e;
    }
    observe(e) {
      this.tracking || ((this.tracking = !0), ce.setupEventHandlers()),
        this.elementVisibilityStateMap.set(e.id, {
          previousStatus: !1,
          timerId: null,
        }),
        this.elementList.push(e),
        Y(this.targetViewTimerMap, e),
        le(),
        ae();
    }
    unobserve(e) {
      if (this.elementList.includes(e)) {
        const t = this.elementList.indexOf(e);
        this.elementList.splice(t, 1),
          0 === this.elementList.length &&
            ((this.tracking = !1), ce.unsetEventHandlers());
      }
      this.targetViewTimerMap.delete(e);
    }
    static isTopWindow() {
      try {
        return (
          "object" == typeof window &&
          "object" == typeof window.top &&
          window === window.top
        );
      } catch (e) {
        return !1;
      }
    }
    isSupported() {
      return ce.isTopWindow();
    }
  }
  const he = new ce();
  const de = new (class {
    constructor() {}
    set fireCallbackForElement(e) {
      this.genericCallbackForElements = e;
    }
    observe(e) {}
    unobserve(e) {}
    isSupported() {
      return !0;
    }
    getMeta(e) {
      return { strategyUsed: p.DEFAULT };
    }
  })();
  class ue {
    constructor() {
      (this.name = "DOM"),
        (this.type = E.VIEW),
        (this.event = u),
        (this.elementIdMap = new Map()),
        (this.elementCallbackMap = new Map()),
        (this.detectorStrategy = ue.getSelectedStrategy()),
        (this.detectorStrategy.fireCallbackForElement =
          this.fireCallbackForElement.bind(this)),
        this.setupEventHandlers();
    }
    disable(t) {
      const i = this.elementIdMap.get(t);
      e(i) &&
        this.elementCallbackMap.has(i) &&
        this.elementCallbackMap.delete(i);
    }
    isSupported(t) {
      const i = a(t);
      return (
        !!(e(i) && i instanceof Element) &&
        (this.elementIdMap.set(t, i), j.isSupported() || he.isSupported())
      );
    }
    isOneTimeEvent() {
      return !0;
    }
    getMeta(t) {
      const i = this.elementIdMap.get(t);
      return e(i) && this.detectorStrategy
        ? this.detectorStrategy.getMeta(i)
        : { strategyUsed: g.UNKNOWN };
    }
    startTracking(t, i) {
      const n = this.elementIdMap.get(i);
      e(n) &&
        (this.elementCallbackMap.set(n, t), this.detectorStrategy.observe(n));
    }
    stopTracking(t) {
      this.disable(t);
      const i = this.elementIdMap.get(t);
      e(i) && e(this.detectorStrategy) && this.detectorStrategy.unobserve(i);
    }
    fireCallbackForElement(e) {
      if (this.elementCallbackMap.has(e)) {
        const t = this.elementCallbackMap.get(e);
        i(t) && t(this.getMeta(e.id));
      }
    }
    static getSelectedStrategy() {
      return j.isSupported() ? j : he.isSupported() ? he : de;
    }
    setupEventHandlers() {
      G.listen();
    }
  }
  const me = new ue();
  let pe,
    ge,
    we = !1;
  function fe(t, i) {
    if (!e(i)) return;
    const n = (function (e) {
      switch (H(e)) {
        case 0:
          return D;
        case 1:
          return S;
        case 2:
          return P;
      }
    })(i);
    e(n) &&
      (function (e, t) {
        if (we === e) return;
        (we = e), clearTimeout(pe);
        const i = B(ge(), t);
        we
          ? ((pe = window.setTimeout(() => {
              we && ve.elementViewedCallback();
            }, K(t))),
            i.on())
          : i.pause();
      })(t >= n, i);
  }
  const Ee = z(A, (e, t) => fe(e, t));
  const ve = new (class {
      constructor() {
        var e;
        (this.event = u),
          (this.name = "MRAID"),
          (this.type = E.VIEW),
          (this.mraid = null),
          (this.targetViewTimerMap = new Map()),
          (this.elementIdMap = new Map()),
          (this.elementCallbackMap = new Map()),
          (this.eventAttached = !1),
          (e = this.getTargetViewTimerMap.bind(this)),
          (ge = e);
      }
      disable(e) {
        this.deleteFromElementCallbackMap(e);
      }
      getTargetViewTimerMap() {
        return this.targetViewTimerMap;
      }
      isOneTimeEvent() {
        return !0;
      }
      isSupported(t) {
        const i = a(t);
        return (
          e(i) && i instanceof Element && this.elementIdMap.set(t, i),
          (this.mraid = (function (t) {
            let i =
                arguments.length > 1 && void 0 !== arguments[1]
                  ? arguments[1]
                  : "mraid",
              n =
                arguments.length > 2 && void 0 !== arguments[2]
                  ? arguments[2]
                  : 20,
              s = t;
            for (let t = 0; t <= n; t++)
              try {
                const t = s[i];
                if (e(t)) return t;
                if (s === s.parent || s === s.top) break;
                s = s.parent;
              } catch (e) {
                break;
              }
            return null;
          })(window)),
          e(this.mraid) &&
            e(this.mraid.getState) &&
            e(this.mraid.addEventListener) &&
            e(this.mraid.getVersion)
        );
      }
      getMeta(t) {
        const i = this.elementIdMap.get(t);
        return e(i)
          ? U(this.targetViewTimerMap, i, p.MRAID)
          : { strategyUsed: p.MRAID };
      }
      elementViewedCallback() {
        this.elementCallbackMap.forEach((e, t) => {
          i(e) && e(this.getMeta(t));
        });
      }
      setElementCallbackMap(e, t) {
        this.elementCallbackMap.set(e, t);
      }
      deleteFromElementCallbackMap(e) {
        this.elementCallbackMap.delete(e);
      }
      startTracking(t, n) {
        if (!e(this.mraid)) return;
        if ((this.setElementCallbackMap(n, t), this.eventAttached)) return;
        const s = this.elementIdMap.get(n);
        (this.exposureChangeHandler = (e) => {
          Ee(e, s);
        }),
          (this.viewableChangeHandler = (e) => {
            Ee(e ? 100 : 0, s);
          });
        const r = () => {
          if (!e(this.mraid)) return;
          parseInt(this.mraid.getVersion()) >= 3
            ? this.mraid.addEventListener(
                "exposureChange",
                this.exposureChangeHandler
              )
            : (this.mraid.addEventListener(
                "viewableChange",
                this.viewableChangeHandler
              ),
              i(this.mraid.isViewable) &&
                this.viewableChangeHandler(this.mraid.isViewable()));
        };
        "loading" === this.mraid.getState()
          ? this.mraid.addEventListener("ready", r)
          : r(),
          (this.eventAttached = !0);
      }
      stopTracking(t) {
        var i, n;
        if (!e(this.mraid)) return;
        this.disable(t);
        const s = this.elementIdMap.get(t);
        if (
          (e(s) && this.targetViewTimerMap.delete(s),
          !this.eventAttached || this.elementCallbackMap.size > 0)
        )
          return;
        parseInt(
          (null === (n = (i = this.mraid).getVersion) || void 0 === n
            ? void 0
            : n.call(i)) || "2"
        ) >= 3
          ? this.mraid.removeEventListener(
              "exposureChange",
              this.exposureChangeHandler
            )
          : this.mraid.removeEventListener(
              "viewableChange",
              this.viewableChangeHandler
            ),
          (this.exposureChangeHandler = () => {}),
          (this.viewableChangeHandler = () => {}),
          (this.eventAttached = !1);
      }
    })(),
    be = "hidden",
    Te = "focused",
    Ie = "pointerDown";
  var Me, Ce, ke;
  function Le(e, t, i, n) {
    try {
      t(e, i, n);
    } catch (e) {}
  }
  !(function (e) {
    (e[(e.MOUSE_IN_TARGET = 0)] = "MOUSE_IN_TARGET"),
      (e[(e.CLICK_IN_TARGET = 1)] = "CLICK_IN_TARGET");
  })(Me || (Me = {})),
    (function (e) {
      (e.COMPOSITE_CLICK = "COMPOSITE_CLICK"),
        (e.ACTIVE_ELEMENT_CLICK = "ACTIVE_ELEMENT_CLICK"),
        (e.HEURISTIC_CLICK_DETECTOR = "HEURISTIC_CLICK_DETECTOR"),
        (e.OMID_CLICK_DETECTOR = "OMID_CLICK_DETECTOR");
    })(Ce || (Ce = {})),
    (function (e) {
      (e.BLUR = "blur"),
        (e.MOUSE_DOWN = "mousedown"),
        (e.MOUSE_ENTER = "mouseenter"),
        (e.MOUSE_LEAVE = "mouseleave"),
        (e.POINTER_DOWN = "pointerdown"),
        (e.VISIBILITY_CHANGE = "visibilitychange"),
        (e.BEFORE_UNLOAD = "beforeunload"),
        (e.PAGE_HIDE = "pagehide");
    })(ke || (ke = {}));
  class Ae {
    constructor(e, t) {
      (this.type = E.CLICK),
        (this.event = d),
        (this.supportedElemMap = new Map()),
        (this.elementCallbackMap = new Map()),
        (this.name = e),
        (this.allEventHandlers = t);
      for (const e of this.allEventHandlers)
        e.fireCallbackForElement = this.onValidClickNotify.bind(this);
    }
    disable(t) {
      const i = this.supportedElemMap.get(t);
      e(i) && this.elementCallbackMap.delete(i);
    }
    onValidClickNotify(e, t) {
      const i = this.elementCallbackMap.get(e);
      "function" == typeof i && i(t);
    }
    static getSupportedElement(e) {
      const t = a(e);
      return t && t instanceof Element ? t : null;
    }
    getMeta(e) {
      return { strategyUsed: g.UNKNOWN };
    }
    isOneTimeEvent() {
      return !0;
    }
    isSupported(e) {
      const t = Ae.getSupportedElement(e);
      return null !== t && (this.supportedElemMap.set(e, t), !0);
    }
    startTracking(t, i) {
      const n = this.supportedElemMap.get(i);
      if (e(n)) {
        this.elementCallbackMap.set(n, t);
        for (const e of this.allEventHandlers) e.observe(n);
      }
    }
    stopTracking(t) {
      this.disable(t);
      const i = this.supportedElemMap.get(t);
      if (e(i)) for (const e of this.allEventHandlers) e.unobserve(i);
    }
  }
  function De(e, t) {
    if (!(e instanceof Node)) return null;
    for (const i of t) if (i.contains(e)) return i;
    return null;
  }
  const ye = new Ae(Ce.ACTIVE_ELEMENT_CLICK, [
    new (class {
      constructor() {
        (this.elementSet = new Set()),
          (this.reportedSignals = new Map()),
          (this.lastPointerDownedAd = null),
          (this.pointerDownTimerId = null),
          (this.pointerDownTimestamp = null),
          (this.eventsAttached = !1),
          (this.pointerDownHandler = (t) => {
            this.clearPointerDownTimer();
            const i = De(t.target, this.elementSet);
            e(i)
              ? ((this.lastPointerDownedAd = i),
                (this.pointerDownTimestamp = Date.now()),
                (this.pointerDownTimerId = window.setTimeout(() => {
                  (this.lastPointerDownedAd = null),
                    (this.pointerDownTimerId = null),
                    (this.pointerDownTimestamp = null);
                }, 1e3)))
              : ((this.lastPointerDownedAd = null),
                (this.pointerDownTimestamp = null));
          }),
          (this.visibilityChangeHandler = (e) => {
            document.visibilityState === be && this.reportActiveAds(e.type);
          }),
          (this.unloadHandler = (e) => {
            this.reportActiveAds(e.type);
          }),
          (this.reportActiveAds = (t) => {
            this.clearPointerDownTimer();
            const i = De(document.activeElement, this.elementSet),
              n = e(this.pointerDownTimestamp)
                ? Date.now() - this.pointerDownTimestamp
                : void 0;
            for (const s of this.elementSet) {
              if (this.reportedSignals.has(s)) continue;
              let r = null;
              if (
                (s === i
                  ? (r = Te)
                  : s === this.lastPointerDownedAd && (r = Ie),
                !e(r))
              )
                continue;
              const o = t + ":" + r;
              this.fireCallbackForElement(s, {
                strategyUsed: m.ACTIVE_ELEMENT,
                eventName: o,
                testData: { [r]: { delayMs: n } },
              }),
                this.reportedSignals.set(s, o);
            }
          });
      }
      isSupported() {
        return !0;
      }
      clearPointerDownTimer() {
        e(this.pointerDownTimerId) &&
          (clearTimeout(this.pointerDownTimerId),
          (this.pointerDownTimerId = null));
      }
      getMeta(e) {
        return {
          strategyUsed: m.ACTIVE_ELEMENT,
          eventName: this.reportedSignals.get(e),
        };
      }
      observe(e) {
        if ((this.elementSet.add(e), !this.eventsAttached)) {
          Le(window, r, ke.BEFORE_UNLOAD, this.unloadHandler),
            Le(window, r, ke.PAGE_HIDE, this.unloadHandler),
            Le(document, r, ke.VISIBILITY_CHANGE, this.visibilityChangeHandler);
          try {
            document.addEventListener(
              ke.POINTER_DOWN,
              this.pointerDownHandler,
              { capture: !0 }
            );
          } catch (e) {}
          this.eventsAttached = !0;
        }
      }
      unobserve(e) {
        if (
          (this.elementSet.delete(e),
          this.reportedSignals.delete(e),
          this.lastPointerDownedAd === e &&
            ((this.lastPointerDownedAd = null),
            (this.pointerDownTimestamp = null)),
          0 === this.elementSet.size && this.eventsAttached)
        ) {
          Le(window, o, ke.BEFORE_UNLOAD, this.unloadHandler),
            Le(window, o, ke.PAGE_HIDE, this.unloadHandler),
            Le(document, o, ke.VISIBILITY_CHANGE, this.visibilityChangeHandler);
          try {
            document.removeEventListener(
              ke.POINTER_DOWN,
              this.pointerDownHandler,
              { capture: !0 }
            );
          } catch (e) {}
          this.clearPointerDownTimer(), (this.eventsAttached = !1);
        }
      }
    })(),
  ]);
  var Ve;
  !(function (e) {
    (e[(e.VIEW = 1)] = "VIEW"), (e[(e.CLICK = 2)] = "CLICK");
  })(Ve || (Ve = {}));
  const Se = { [E.VIEW]: Ve.VIEW, [E.CLICK]: Ve.CLICK },
    Oe = { [E.VIEW]: u, [E.CLICK]: d },
    Ne = {
      adUnitPath: "aupath",
      isPageVisible: "ispv",
      strategyUsed: "apstrat",
      inViewTime: "invwtm",
      inViewCount: "invwct",
      eventName: "domen",
      testData: "td",
    };
  class Pe {
    config;
    globalAdPerfPixel;
    constructor(e, i, s) {
      const r = {};
      for (let s = 0; s < e.length; s++) {
        let o = e[s];
        if (t(o) && ((r[o] = []), n(i) && i.length > 0)) {
          let e = i[s];
          n(e) && e.length > 0 && (r[o] = e);
        }
      }
      (this.config = r), (this.globalAdPerfPixel = s);
    }
    getValue(e) {
      return this.config[e];
    }
    isTrackingEnabled(t) {
      const i = this.getValue(t);
      return e(i) && n(i);
    }
    getTrackingUrls(i) {
      const n = { customUrls: this.getValue(i), globalAdPerfPixel: "" };
      return (
        t(this.globalAdPerfPixel) &&
          (n.globalAdPerfPixel =
            this.globalAdPerfPixel +
            (function (t) {
              let i = "";
              const n = Se[t];
              return e(n) && (i = l("evttyp", n, !1)), i;
            })(i)),
        n
      );
    }
  }
  const Re = {
    enrichURL(t, i) {
      if (!e(i)) return t;
      const s = new URL(t);
      for (const [t, o] of Object.entries(i)) {
        const i = Ne[t];
        if (e(i) && e(o)) {
          const t =
            !e((r = o)) ||
            (function (e) {
              const t = typeof e;
              return (
                "boolean" === t ||
                "number" === t ||
                "string" === t ||
                "symbol" === t
              );
            })(r) ||
            n(r)
              ? o.toString()
              : JSON.stringify(o);
          s.searchParams.append(i, t);
        }
      }
      var r;
      return s.toString();
    },
    sendViaBeacon(t) {
      let n =
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
      return (
        !(!e(navigator.sendBeacon) || !i(navigator.sendBeacon)) &&
        navigator.sendBeacon(t, n)
      );
    },
    fireViaImageRequests(e) {
      e.forEach((e) => {
        new Image().src = e;
      });
    },
    submit: (e) => (t) => {
      const i = Re.enrichURL(e.globalAdPerfPixel, t);
      Re.sendViaBeacon(i)
        ? Re.fireViaImageRequests(e.customUrls)
        : Re.fireViaImageRequests([i, ...e.customUrls]);
    },
  };
  function _e(i, n) {
    if (!e(n) || !i.isTrackingEnabled(E.VIEW)) return;
    const s = (function (e) {
        if (!t(e.globalAdPerfPixel)) return e;
        const i = new URL(e.globalAdPerfPixel);
        return (
          i.searchParams.set("evttyp", "3"),
          (e.globalAdPerfPixel = i.toString()),
          e
        );
      })(i.getTrackingUrls(E.VIEW)),
      r = Re.submit(s);
    window.addEventListener("pagehide", (e) => {
      const t = n.getMeta(E.VIEW);
      r(t);
    });
  }
  (window.adPerf = new (class {
    allowedTrackers = [];
    eventCallbackMap = (() => new Map())();
    constructor() {
      C.setupDetectors([ve, me, ye]);
    }
    track(i, n, s) {
      let r = "https://hblg-nv.media.net/log?logid=kfke&evtid=adpvlog";
      t(window.adPerformancePixel) && (r = window.adPerformancePixel);
      const o = (function () {
          let e =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : "",
            i =
              arguments.length > 1 && void 0 !== arguments[1]
                ? arguments[1]
                : "";
          return (
            void 0 !== window.mraid &&
              (e += "&mraid_version=" + window.mraid.getVersion()),
            t(i) ? (t(e) ? i + e : i) : ""
          );
        })(window.logParams, r),
        a = new Pe(n, s, o);
      this.processForATrackerType(a, E.VIEW),
        this.processForATrackerType(a, E.CLICK);
      const l = C.getNewTracker(this.allowedTrackers, i);
      if ((_e(a, l), e(l) && this.eventCallbackMap.size > 0)) {
        for (const [e, { callback: t, oneTimeEvent: i }] of this
          .eventCallbackMap)
          l.on(
            e,
            (e, i) => {
              t(i);
            },
            i
          );
        return !0;
      }
      return !1;
    }
    processForATrackerType(e, t) {
      if (e.isTrackingEnabled(t)) {
        this.allowedTrackers.push(t);
        const i = e.getTrackingUrls(t),
          n = { callback: Re.submit(i), oneTimeEvent: t !== E.CLICK };
        this.eventCallbackMap.set(Oe[t], n);
      }
    }
  })()),
    (window._adp = new h(window._adp || []));
})();
