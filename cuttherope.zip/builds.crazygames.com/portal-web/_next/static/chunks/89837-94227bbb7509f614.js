!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var r = arguments[t];
          if (null != r) for (var o in r) r.hasOwnProperty(o) && (e[o] = r[o]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "cd3fad58-3865-45c1-86d0-a2040c049090"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-cd3fad58-3865-45c1-86d0-a2040c049090"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [89837],
    {
      589: (e, t, r) => {
        "use strict";
        r.d(t, { A: () => g, S: () => f });
        var o = r(6029),
          a = r(55729),
          n = r(79942),
          i = r(13060),
          s = r(71237),
          l = r(33165),
          d = r(93800),
          u = r(28073),
          c = r.n(u);
        let p = {
            "progress-bar-wrapper": c().progressBarWrapper,
            "progress-bar-0": c().progressBarFill,
          },
          f = () => {
            let { user: e } = s.Jd();
            if (!e) return 100;
            let t = [
              e?.profile?.avatar,
              e?.profile?.cover,
              e?.profile?.country,
              e?.profile?.gender,
              e?.profile?.birthday,
            ];
            return (t.filter((e) => e).length / t.length) * 100;
          },
          g = a.memo((e) => {
            let { progress: t } = e,
              { openDrawer: r } = a.useContext(l.lv),
              { i18n: s } = (0, n.uB)(),
              u = a.useCallback(() => {
                r("editProfile");
              }, [r]);
            return (0, o.jsxs)("div", {
              className: c().root,
              onClick: u,
              children: [
                (0, o.jsxs)("div", {
                  className: c().row,
                  children: [
                    (0, o.jsx)(n.x6, {
                      id: "common.upDrawer.profileProgress",
                      values: { number: t },
                    }),
                    (0, o.jsxs)("a", {
                      className: c().completeNow,
                      children: [
                        (0, o.jsx)(n.x6, { id: "common.upDrawer.completeNow" }),
                        (0, o.jsx)(d.A, {
                          name: "chevron-right",
                          className: c().chevronRight,
                        }),
                      ],
                    }),
                  ],
                }),
                (0, o.jsx)(i.A, {
                  progresses: [t / 100],
                  customStyles: p,
                  "aria-label": s._({
                    id: "common.upDrawer.profileProgress",
                    values: { number: t },
                  }),
                }),
              ],
            });
          });
      },
      2140: (e, t, r) => {
        "use strict";
        var o = Object.create
            ? function (e, t, r, o) {
                void 0 === o && (o = r);
                var a = Object.getOwnPropertyDescriptor(t, r);
                (!a ||
                  ("get" in a
                    ? !t.__esModule
                    : a.writable || a.configurable)) &&
                  (a = {
                    enumerable: !0,
                    get: function () {
                      return t[r];
                    },
                  }),
                  Object.defineProperty(e, o, a);
              }
            : function (e, t, r, o) {
                void 0 === o && (o = r), (e[o] = t[r]);
              },
          a = function (e, t) {
            for (var r in e)
              "default" === r ||
                Object.prototype.hasOwnProperty.call(t, r) ||
                o(t, e, r);
          };
        Object.defineProperty(t, "__esModule", { value: !0 }),
          a(r(21048), t),
          a(r(69857), t),
          a(r(78136), t),
          a(r(47553), t);
      },
      2145: (e, t, r) => {
        "use strict";
        var o = Object.create
          ? function (e, t, r, o) {
              void 0 === o && (o = r);
              var a = Object.getOwnPropertyDescriptor(t, r);
              (!a ||
                ("get" in a ? !t.__esModule : a.writable || a.configurable)) &&
                (a = {
                  enumerable: !0,
                  get: function () {
                    return t[r];
                  },
                }),
                Object.defineProperty(e, o, a);
            }
          : function (e, t, r, o) {
              void 0 === o && (o = r), (e[o] = t[r]);
            };
        Object.defineProperty(t, "__esModule", { value: !0 });
        var a = r(8832);
        for (var n in a)
          "default" === n ||
            Object.prototype.hasOwnProperty.call(t, n) ||
            o(t, a, n);
      },
      2716: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      3678: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      4893: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      5490: (e, t) => {
        "use strict";
        var r, o;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.InterstitialAdPluginEvents = void 0),
          ((o = r || (t.InterstitialAdPluginEvents = r = {})).Loaded =
            "interstitialAdLoaded"),
          (o.FailedToLoad = "interstitialAdFailedToLoad"),
          (o.Showed = "interstitialAdShowed"),
          (o.FailedToShow = "interstitialAdFailedToShow"),
          (o.Dismissed = "interstitialAdDismissed");
      },
      6479: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      8026: (e, t, r) => {
        "use strict";
        r.d(t, { Z: () => u });
        var o = r(75155),
          a = r(55729),
          n = r(3948),
          i = r(57784),
          s = r(14886),
          l = r(24141),
          d = r(43038);
        function u(e) {
          let t,
            r,
            u,
            c,
            p = (0, o.c)(14),
            { user: f } = (0, a.useContext)(s.R),
            [g, h] = (0, a.useState)(i.i.CANCEL),
            [w, m] = (0, n._)(l.cg),
            { data: y, error: v, loading: b, called: _ } = m;
          p[0] !== e.id || p[1] !== e.slug || p[2] !== w || p[3] !== f
            ? ((t = () => {
                f && e.id
                  ? w({ variables: { gameId: e.id } })
                  : h((0, d.hO)(e.slug));
              }),
              (r = [f, e.id, e.slug, w]),
              (p[0] = e.id),
              (p[1] = e.slug),
              (p[2] = w),
              (p[3] = f),
              (p[4] = t),
              (p[5] = r))
            : ((t = p[4]), (r = p[5])),
            (0, a.useEffect)(t, r),
            p[6] !== _ || p[7] !== y || p[8] !== v || p[9] !== b
              ? ((u = { data: y, error: v, loading: b, called: _ }),
                (p[6] = _),
                (p[7] = y),
                (p[8] = v),
                (p[9] = b),
                (p[10] = u))
              : (u = p[10]);
          let [P, A] = (0, a.useState)(u);
          return (
            (P.data !== y ||
              P.error !== v ||
              P.loading !== b ||
              P.called !== _) &&
              (A({ data: y, error: v, loading: b, called: _ }),
              _ &&
                !b &&
                (v
                  ? (console.error(
                      "[useUserGameVote] Error fetching user game vote:",
                      v
                    ),
                    h((0, d.hO)(e.slug)))
                  : y && h(y.getUserGameVote ?? i.i.CANCEL))),
            p[11] !== b || p[12] !== g
              ? ((c = { vote: g, loading: b }),
                (p[11] = b),
                (p[12] = g),
                (p[13] = c))
              : (c = p[13]),
            c
          );
        }
      },
      8832: (e, t, r) => {
        "use strict";
        var o = Object.create
            ? function (e, t, r, o) {
                void 0 === o && (o = r);
                var a = Object.getOwnPropertyDescriptor(t, r);
                (!a ||
                  ("get" in a
                    ? !t.__esModule
                    : a.writable || a.configurable)) &&
                  (a = {
                    enumerable: !0,
                    get: function () {
                      return t[r];
                    },
                  }),
                  Object.defineProperty(e, o, a);
              }
            : function (e, t, r, o) {
                void 0 === o && (o = r), (e[o] = t[r]);
              },
          a = function (e, t) {
            for (var r in e)
              "default" === r ||
                Object.prototype.hasOwnProperty.call(t, r) ||
                o(t, e, r);
          };
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.AdMob = void 0);
        let n = r(34651);
        a(r(58690), t),
          a(r(68701), t),
          a(r(39569), t),
          a(r(81099), t),
          a(r(2140), t),
          a(r(35425), t),
          a(r(82326), t),
          (t.AdMob = (0, n.registerPlugin)("AdMob", {
            web: () =>
              r
                .e(78702)
                .then(r.bind(r, 78702))
                .then((e) => new e.AdMobWeb()),
          }));
      },
      10429: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      11667: (e, t, r) => {
        "use strict";
        r.d(t, { G1: () => _, Mn: () => P, ft: () => v, iV: () => p });
        var o = r(75155),
          a = r(55729),
          n = r(50113),
          i = r(98417),
          s = r(14886),
          l = r(71855),
          d = r(71684),
          u = r(86381),
          c = r(97968);
        function p() {
          return (
            "enabled" ===
            (0, l.U)("czyExpClientGameNotificationPreferences_CZY_21603")
          );
        }
        let f = new Map();
        function g(e) {
          let t,
            r,
            n,
            s,
            l = (0, o.c)(10),
            { services: u } = a.useContext(d.A),
            [c, p] = a.useState();
          l[0] !== e
            ? ((t = e?.slice().sort().join(",")), (l[0] = e), (l[1] = t))
            : (t = l[1]);
          let f = t;
          l[2] !== f || l[3] !== u.api
            ? ((r = () => {
                if (!(0, i.O)(f)) return;
                let e = !1,
                  t = "" === f ? [] : f.split(",");
                return (
                  (async () => {
                    try {
                      let r = t.filter(m);
                      if (r.length > 0) {
                        let { games: e } = await u.api.getGamesExtraData(r);
                        e.forEach(w);
                      }
                      e ||
                        p({
                          gameIdsKey: f,
                          games: new Map(t.flatMap(h)),
                          error: !1,
                        });
                    } catch {
                      e || p({ gameIdsKey: f, games: new Map(), error: !0 });
                    }
                  })(),
                  () => {
                    e = !0;
                  }
                );
              }),
              (n = [f, u.api]),
              (l[2] = f),
              (l[3] = u.api),
              (l[4] = r),
              (l[5] = n))
            : ((r = l[4]), (n = l[5])),
            a.useEffect(r, n);
          let g = c?.games,
            y = void 0 !== f && c?.gameIdsKey !== f,
            v = c?.gameIdsKey === f && !!c?.error;
          return (
            l[6] !== g || l[7] !== y || l[8] !== v
              ? ((s = { games: g, loading: y, error: v }),
                (l[6] = g),
                (l[7] = y),
                (l[8] = v),
                (l[9] = s))
              : (s = l[9]),
            s
          );
        }
        function h(e) {
          return f.has(e) ? [[e, f.get(e)]] : [];
        }
        function w(e) {
          let { id: t, name: r, cover: o, covers: a } = e;
          return f.set(t, { name: r, cover: a?.["1x1"] ?? o });
        }
        function m(e) {
          return !f.has(e);
        }
        function y(e, t) {
          return e.flatMap((e) => {
            let { gameId: r, types: o } = e,
              a = t?.get(r),
              n = (0, c.L)(o);
            return a && n.length > 0
              ? [{ id: r, name: a.name, cover: a.cover, types: n }]
              : [];
          });
        }
        function v() {
          let e,
            t,
            r,
            i,
            l,
            d = (0, o.c)(13),
            { user: c } = a.useContext(s.R),
            f = p(),
            h = !c || !f;
          d[0] !== h
            ? ((e = { skip: h, fetchPolicy: "cache-and-network" }),
              (d[0] = h),
              (d[1] = e))
            : (e = d[1]);
          let { data: w, loading: m, error: v } = (0, n.IT)(u.h4, e),
            _ = w?.gameNotificationPreferences;
          d[2] !== _ ? ((t = _?.map(b)), (d[2] = _), (d[3] = t)) : (t = d[3]);
          let P = g(t);
          d[4] !== _ ? ((r = _ ?? []), (d[4] = _), (d[5] = r)) : (r = d[5]),
            d[6] !== P.games || d[7] !== r
              ? ((i = y(r, P.games)), (d[6] = P.games), (d[7] = r), (d[8] = i))
              : (i = d[8]);
          let A = (m && !w) || P.loading,
            k = !!v || P.error;
          return (
            d[9] !== i || d[10] !== A || d[11] !== k
              ? ((l = { games: i, loading: A, error: k }),
                (d[9] = i),
                (d[10] = A),
                (d[11] = k),
                (d[12] = l))
              : (l = d[12]),
            l
          );
        }
        function b(e) {
          let { gameId: t } = e;
          return t;
        }
        function _(e) {
          let t,
            r,
            i,
            l,
            d,
            c = (0, o.c)(14),
            { user: f } = a.useContext(s.R),
            h = p(),
            w = e ?? "";
          c[0] !== w
            ? ((t = { gameId: w }), (c[0] = w), (c[1] = t))
            : (t = c[1]);
          let m = !f || !h || !e;
          c[2] !== t || c[3] !== m
            ? ((r = {
                variables: t,
                skip: m,
                fetchPolicy: "cache-and-network",
              }),
              (c[2] = t),
              (c[3] = m),
              (c[4] = r))
            : (r = c[4]);
          let { data: v, loading: b, error: _ } = (0, n.IT)(u.u$, r),
            P = v?.gameNotificationPreferencesForGame ?? void 0;
          c[5] !== P
            ? ((i = P ? [P.gameId] : void 0), (c[5] = P), (c[6] = i))
            : (i = c[6]);
          let A = g(i);
          c[7] !== A || c[8] !== P
            ? ((l = P ? y([P], A.games)[0] : void 0),
              (c[7] = A),
              (c[8] = P),
              (c[9] = l))
            : (l = c[9]);
          let k = (b && !v) || A.loading,
            O = !!_ || A.error;
          return (
            c[10] !== l || c[11] !== k || c[12] !== O
              ? ((d = { game: l, loading: k, error: O }),
                (c[10] = l),
                (c[11] = k),
                (c[12] = O),
                (c[13] = d))
              : (d = c[13]),
            d
          );
        }
        function P(e) {
          let t,
            r,
            i = (0, o.c)(5),
            { user: l } = a.useContext(s.R),
            d = p();
          i[0] !== e
            ? ((t = { gameId: e }), (i[0] = e), (i[1] = t))
            : (t = i[1]);
          let f = !l || !d;
          i[2] !== t || i[3] !== f
            ? ((r = {
                variables: t,
                skip: f,
                fetchPolicy: "cache-and-network",
              }),
              (i[2] = t),
              (i[3] = f),
              (i[4] = r))
            : (r = i[4]);
          let { data: g } = (0, n.IT)(u.u$, r),
            h = (0, c.L)(g?.gameNotificationPreferencesForGame?.types ?? []);
          if (d && 0 !== h.length) return h.some(A) ? "on" : "off";
        }
        function A(e) {
          let { enabled: t } = e;
          return t;
        }
      },
      13885: (e, t, r) => {
        "use strict";
        r.d(t, { W: () => s });
        var o = r(2145),
          a = r(39481);
        let n = null,
          i = null;
        async function s() {
          n ??= a.il.get().catch(() => void 0);
          let e = await n;
          return (
            e ||
              (null !== i && Date.now() - i < 6e4) ||
              ((i = Date.now()),
              o.AdMob.getInstallAttribution({ timeoutMs: 1e4 })
                .catch(() => ({}))
                .then(async (e) => {
                  e.network && ((n = Promise.resolve(e)), await a.il.set(e));
                })
                .catch((e) =>
                  console.error("Failed to store the install attribution", e)
                )),
            e
          );
        }
      },
      14468: (e, t) => {
        "use strict";
        var r, o;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.RewardInterstitialAdPluginEvents = void 0),
          ((o = r || (t.RewardInterstitialAdPluginEvents = r = {})).Loaded =
            "onRewardedInterstitialAdLoaded"),
          (o.FailedToLoad = "onRewardedInterstitialAdFailedToLoad"),
          (o.Showed = "onRewardedInterstitialAdShowed"),
          (o.FailedToShow = "onRewardedInterstitialAdFailedToShow"),
          (o.Dismissed = "onRewardedInterstitialAdDismissed"),
          (o.Rewarded = "onRewardedInterstitialAdReward");
      },
      21048: (e, t) => {
        "use strict";
        var r, o;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.RewardAdPluginEvents = void 0),
          ((o = r || (t.RewardAdPluginEvents = r = {})).Loaded =
            "onRewardedVideoAdLoaded"),
          (o.FailedToLoad = "onRewardedVideoAdFailedToLoad"),
          (o.Showed = "onRewardedVideoAdShowed"),
          (o.FailedToShow = "onRewardedVideoAdFailedToShow"),
          (o.Dismissed = "onRewardedVideoAdDismissed"),
          (o.Rewarded = "onRewardedVideoAdReward");
      },
      23181: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      26205: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      28073: (e) => {
        e.exports = {
          czyButton: "ProfileCompletionProgressBar_czyButton__P6EmX",
          "czyButton--contained--purple":
            "ProfileCompletionProgressBar_czyButton--contained--purple__aOIW6",
          "czyButton--contained--white":
            "ProfileCompletionProgressBar_czyButton--contained--white__Q9a6_",
          "czyButton--contained--grey":
            "ProfileCompletionProgressBar_czyButton--contained--grey__cfPRG",
          "czyButton--contained--warning":
            "ProfileCompletionProgressBar_czyButton--contained--warning__XEcPT",
          "czyButton--contained--alert":
            "ProfileCompletionProgressBar_czyButton--contained--alert__V7D7O",
          "czyButton--contained--success":
            "ProfileCompletionProgressBar_czyButton--contained--success__DnXmJ",
          "czyButton--contained--black":
            "ProfileCompletionProgressBar_czyButton--contained--black__RfpVd",
          "czyButton--contained--green-gradient":
            "ProfileCompletionProgressBar_czyButton--contained--green-gradient__iszWI",
          "czyButton--contained--animated-green-gradient":
            "ProfileCompletionProgressBar_czyButton--contained--animated-green-gradient__7i_Ef",
          "scroll-gradient":
            "ProfileCompletionProgressBar_scroll-gradient__i8F0X",
          "czyButton--outlined--purple":
            "ProfileCompletionProgressBar_czyButton--outlined--purple__CDV7i",
          "czyButton--link--purple":
            "ProfileCompletionProgressBar_czyButton--link--purple__SypcH",
          "czyButton--outlined--white":
            "ProfileCompletionProgressBar_czyButton--outlined--white___amd1",
          "czyButton--link--white":
            "ProfileCompletionProgressBar_czyButton--link--white__L9VLd",
          "czyButton--outlined--grey":
            "ProfileCompletionProgressBar_czyButton--outlined--grey__3S282",
          "czyButton--link--grey":
            "ProfileCompletionProgressBar_czyButton--link--grey__eCMeh",
          "czyButton--outlined--warning":
            "ProfileCompletionProgressBar_czyButton--outlined--warning__Sb7Mo",
          "czyButton--link--warning":
            "ProfileCompletionProgressBar_czyButton--link--warning__ZVpEL",
          "czyButton--outlined--alert":
            "ProfileCompletionProgressBar_czyButton--outlined--alert__YcJJx",
          "czyButton--link--alert":
            "ProfileCompletionProgressBar_czyButton--link--alert__AlfkX",
          "czyButton--outlined--success":
            "ProfileCompletionProgressBar_czyButton--outlined--success__NqkGR",
          "czyButton--link--success":
            "ProfileCompletionProgressBar_czyButton--link--success__dJKnk",
          "czyButton--outlined":
            "ProfileCompletionProgressBar_czyButton--outlined__61x05",
          "czyButton--disabled":
            "ProfileCompletionProgressBar_czyButton--disabled__OrEnh",
          "czyButton--height50":
            "ProfileCompletionProgressBar_czyButton--height50__dYTCe",
          "czyButton--height34":
            "ProfileCompletionProgressBar_czyButton--height34__6Qr0z",
          "czyButton--height28":
            "ProfileCompletionProgressBar_czyButton--height28__9F5sY",
          "czyButton--fullWidth":
            "ProfileCompletionProgressBar_czyButton--fullWidth__U3ej3",
          "czyButton--headerIcon":
            "ProfileCompletionProgressBar_czyButton--headerIcon__NU13g",
          "czyButton--headerIcon--desktop":
            "ProfileCompletionProgressBar_czyButton--headerIcon--desktop__n_TzS",
          "czyButton--headerIcon--mobile":
            "ProfileCompletionProgressBar_czyButton--headerIcon--mobile__H_FjB",
          "czyButton--headerIcon--withLabel":
            "ProfileCompletionProgressBar_czyButton--headerIcon--withLabel__85OMd",
          root: "ProfileCompletionProgressBar_root__WFVnW",
          row: "ProfileCompletionProgressBar_row__cSiY2",
          completeNow: "ProfileCompletionProgressBar_completeNow__V8Hiu",
          chevronRight: "ProfileCompletionProgressBar_chevronRight__nZ_1R",
          progressBarWrapper:
            "ProfileCompletionProgressBar_progressBarWrapper__cenRT",
          progressBarFill:
            "ProfileCompletionProgressBar_progressBarFill__rpboG",
        };
      },
      28349: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      28918: (e, t, r) => {
        "use strict";
        r.d(t, { A: () => ea, S: () => eo });
        var o = r(6029),
          a = r(75155),
          n = r(55729),
          i = r(46871),
          s = r(89964),
          l = r(71024),
          d = r.n(l),
          u = r(71855),
          c = r(45364),
          p = r(43461),
          f = r(56919);
        let g = d()(
            () =>
              Promise.all([
                r.e(61019),
                r.e(16688),
                r.e(28930),
                r.e(11591),
              ]).then(r.bind(r, 28930)),
            {
              loadableGenerated: { webpack: () => [28930] },
              loading: () => null,
              ssr: !1,
            }
          ),
          h = !1;
        function w(e, t) {
          e.window.postMessage(t, "*");
        }
        let m = (e) => {
          let t,
            r,
            i,
            l,
            d,
            m = (0, a.c)(14),
            { gfSource: y } = e,
            v = (0, u.U)("czyExpClientAdFree_CZY_21530"),
            b = "disabled" === v ? null : v,
            _ = (0, f.Q)(b, "pre_ad_message"),
            [P, A] = n.useState(!1);
          m[0] !== y || m[1] !== b
            ? ((t = () => {
                w(y, {
                  type: "adFreePreAdMessageSync",
                  data: {
                    allowed:
                      null !== b &&
                      ((0, p.Mf)() || (0, p.sB)((0, p.Lh)(), h, Date.now())),
                  },
                });
              }),
              (m[0] = y),
              (m[1] = b),
              (m[2] = t))
            : (t = m[2]);
          let k = t;
          if (
            (m[3] !== y || m[4] !== k || m[5] !== _
              ? ((r = () => {
                  k();
                  let e = (e) => {
                    if (e.source === y.window && e.data?.type === s.x)
                      switch (e.data.event) {
                        case "adFreePreAdShown":
                          (h = !0),
                            (0, p.wR)(Date.now()),
                            _("shown", "entry_point"),
                            k();
                          break;
                        case "adFreePreAdClicked":
                          _("clicked", "entry_point"),
                            c.A.isFullscreen() && c.A.exitNativeFullscreen(),
                            A(!0);
                          break;
                        case "adFreePreAdClosed": {
                          let { reason: t, dontShowAgain: r } = e.data;
                          r && (0, p.DO)(),
                            _("closed", r ? "dont_show_again" : t),
                            k();
                        }
                      }
                  };
                  return (
                    window.addEventListener("message", e),
                    () => window.removeEventListener("message", e)
                  );
                }),
                (i = [y, k, _]),
                (m[3] = y),
                (m[4] = k),
                (m[5] = _),
                (m[6] = r),
                (m[7] = i))
              : ((r = m[6]), (i = m[7])),
            n.useEffect(r, i),
            !P || null === b)
          )
            return null;
          m[8] !== y || m[9] !== k
            ? ((l = () => {
                A(!1), k(), w(y, { type: "adFreeOfferClosed" });
              }),
              (m[8] = y),
              (m[9] = k),
              (m[10] = l))
            : (l = m[10]);
          let O = l;
          return (
            m[11] !== O || m[12] !== b
              ? ((d = (0, o.jsx)(g, {
                  variant: b,
                  entryPoint: "pre_ad_message",
                  onClose: O,
                })),
                (m[11] = O),
                (m[12] = b),
                (m[13] = d))
              : (d = m[13]),
            d
          );
        };
        r(24141);
        var y = r(93802),
          v = r(32485),
          b = r(83072);
        let _ = (e) => {
          let t,
            r,
            o = (0, a.c)(4),
            { game: i } = e,
            { state: l } = (0, v.F)(),
            d = (0, b.r)(i),
            u = l?.puzzleDate;
          return (
            o[0] !== d || o[1] !== u
              ? ((t = () => {
                  if (!d) return;
                  let e = (e) => {
                    if (
                      e.data?.type !== s.x ||
                      "dailyEvent" !== e.data.event ||
                      !e.data.dailyEvent
                    )
                      return;
                    let t = e.data.dailyEvent;
                    "puzzleEnded" === t.type &&
                      "daily" === t.puzzleType &&
                      t.puzzleDate === u &&
                      (0, y.k)();
                  };
                  return (
                    window.addEventListener("message", e),
                    () => window.removeEventListener("message", e)
                  );
                }),
                (r = [d, u]),
                (o[0] = d),
                (o[1] = u),
                (o[2] = t),
                (o[3] = r))
              : ((t = o[2]), (r = o[3])),
            n.useEffect(t, r),
            null
          );
        };
        var P = r(10945),
          A = r(7234),
          k = r(98417),
          O = r(14886),
          E = r(71237),
          B = r(13246),
          M = r(33165),
          C = r(96301);
        class S extends Error {
          constructor(e, t) {
            super(t), (this.code = e), (this.name = "XsollaStoreCatalogError");
          }
        }
        async function R(e) {
          let t,
            r,
            { xsollaProjectId: o, limit: a, offset: n, xsollaUserToken: i } = e;
          try {
            t = await fetch(
              `https://store.xsolla.com/api/v2/project/${o}/items?limit=${a}&offset=${n}`,
              {
                method: "GET",
                headers: (0, k.O)(i) ? { Authorization: `Bearer ${i}` } : {},
              }
            );
          } catch (e) {
            throw (
              (console.error(
                "Network error while fetching the Xsolla catalog",
                e
              ),
              new S(
                "catalogFetchFailed",
                "Could not reach the Xsolla store API."
              ))
            );
          }
          if (!t.ok)
            throw (
              (console.error(
                `Error fetching the Xsolla catalog: ${t.status} ${t.statusText}`
              ),
              new S(
                "catalogFetchFailed",
                "The Xsolla store API could not return the catalog."
              ))
            );
          try {
            r = await t.json();
          } catch (e) {
            throw (
              (console.error("Failed to parse the Xsolla catalog response", e),
              new S(
                "catalogFetchFailed",
                "Received an invalid response from the Xsolla store API."
              ))
            );
          }
          return { items: r.items.map(T), hasMore: r.has_more };
        }
        function T(e) {
          var t;
          return {
            sku: e.sku,
            name: e.name,
            description: e.description,
            imageUrl: e.image_url,
            price:
              ((t = e.price),
              (0, k.O)(t)
                ? {
                    amount: t.amount,
                    amountWithoutDiscount: t.amount_without_discount,
                    currency: t.currency,
                  }
                : null),
            isFree: e.is_free,
            canBeBought: e.can_be_bought,
          };
        }
        var I = r(81766);
        class N extends Error {
          constructor(e, t) {
            super(t), (this.code = e), (this.name = "XsollaStorePurchaseError");
          }
        }
        async function j() {
          return (
            (0, k.O)(window.XPayStationWidget) ||
              (await (0, I.jo)(
                "https://cdn.xsolla.net/payments-bucket-prod/embed/1.5.4/widget.min.js"
              )),
            window.XPayStationWidget
          );
        }
        async function F(e) {
          let t,
            r,
            o,
            {
              xsollaProjectId: a,
              itemId: n,
              sandbox: i,
              xsollaUserToken: s,
            } = e,
            l = new AbortController(),
            d = setTimeout(() => l.abort(), 1e4);
          try {
            t = await fetch(
              `https://store.xsolla.com/api/v2/project/${a}/payment/item/${n}`,
              {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: `Bearer ${s}`,
                },
                body: JSON.stringify({ sandbox: i }),
                signal: l.signal,
              }
            );
          } catch (e) {
            throw (
              (console.error(
                "Network error while contacting Xsolla payment API:",
                e
              ),
              new N(
                "unexpectedError",
                "Could not reach the Xsolla payment API"
              ))
            );
          } finally {
            clearTimeout(d);
          }
          try {
            r = await t.json();
          } catch (e) {
            throw (
              (console.error("Failed to parse Xsolla response:", e),
              new N(
                "unexpectedError",
                "Received an invalid response from the Xsolla payment API"
              ))
            );
          }
          if (!t.ok || !r.token)
            throw (
              (console.error(
                `Error initiating purchase: ${t.status} ${t.statusText}`,
                r
              ),
              new N("purchaseInitFailed", "Something went wrong."))
            );
          try {
            o = await j();
          } catch (e) {
            throw (
              (console.error(
                "Failed to load the Xsolla Pay Station widget:",
                e
              ),
              new N(
                "unexpectedError",
                "Could not load the Xsolla payment widget"
              ))
            );
          }
          return new Promise((e, t) => {
            let a = () => {
              o.off(o.eventTypes.STATUS_DONE), o.off(o.eventTypes.CLOSE);
            };
            o.on(o.eventTypes.STATUS_DONE, () => {
              e(), a();
            }),
              o.on(o.eventTypes.CLOSE, () => {
                t(new N("purchaseCancelled", "The purchase was cancelled.")),
                  a();
              }),
              o.init({ access_token: r.token, sandbox: i }),
              o.open();
          });
        }
        let x = (e) =>
            "object" == typeof e &&
            null !== e &&
            "graphQLErrors" in e &&
            Array.isArray(e.graphQLErrors),
          D = "sdkAddFriends",
          z = (e) => {
            let { gameId: t } = e,
              { user: r, userTokenExists: o } = n.useContext(O.R),
              { openedDrawer: a } = n.useContext(M.l9),
              { drawerOpeningPending: i } = n.useContext(M.Cx),
              { openDrawer: l } = n.useContext(M.lv),
              d = (0, P.m)(),
              { refetch: u, loading: p } = E.ic(),
              { refetch: f, loading: g } = E.X6(),
              { fetch: h } = E.qx(),
              { fetch: w } = E.K(),
              [m, y] = (0, n.useState)(!1),
              [v, b] = (0, n.useState)(null),
              { user: _ } = E.Jd(),
              [T] = (0, A.n)(C.sL);
            (0, n.useEffect)(() => {
              if (
                !i &&
                m &&
                v &&
                (r ||
                  a ||
                  (y(!1),
                  b(null),
                  v.postMessage(
                    {
                      type: "showAuthPromptResponse",
                      error: {
                        code: "userCancelled",
                        message: "User cancelled the auth prompt",
                      },
                    },
                    "*"
                  )),
                r && _ && !a)
              ) {
                y(!1), b(null);
                let e = {
                  type: "showAuthPromptResponse",
                  user: {
                    id: _.id,
                    username: `${_.username}`,
                    profilePictureUrl: `${B.A.Instance.data.images}${_.profile.avatar}`,
                  },
                };
                v.postMessage(e, "*");
              }
            }, [a, m, r, v, _, i, o]);
            let I = (0, n.useCallback)(
                async (e, o, a) => {
                  let n;
                  if (!r) {
                    (n = {
                      type: "requestUserTokenResponse",
                      error: {
                        code: "userNotAuthenticated",
                        message: "The user is not authenticated",
                      },
                    }),
                      e.postMessage(n, "*");
                    return;
                  }
                  if (p) return;
                  let i = await u({
                      gameId: t,
                      iframeUrl: o,
                      signingKeyType: a,
                    }),
                    s = i.data?.userToken;
                  i.error || !s
                    ? (console.error("User token retrieve error", i.error),
                      (n = {
                        type: "requestUserTokenResponse",
                        error: {
                          code: "unexpectedError",
                          message: "Failed to retrieve user token",
                        },
                      }))
                    : (n = {
                        type: "requestUserTokenResponse",
                        token: s.token,
                        expiresIn: s.expiresIn,
                      }),
                    e.postMessage(n, "*");
                },
                [r, p, u, t]
              ),
              j = (0, n.useCallback)(
                async (e) => {
                  let o;
                  if (!e) return void console.error("GFWindow not found");
                  if (!r) {
                    (o = {
                      type: "requestXsollaUserTokenResponse",
                      error: {
                        code: "userNotAuthenticated",
                        message: "The user is not authenticated",
                      },
                    }),
                      e.postMessage(o, "*");
                    return;
                  }
                  if (g) return;
                  let a = await f({ gameId: t }),
                    n = a.data?.xsollaUserToken;
                  if (a.error || !n) {
                    let e, t;
                    console.error("Xsolla user token retrieve error", a.error),
                      x(a.error) &&
                        a.error.graphQLErrors.length > 0 &&
                        ((e = a.error.graphQLErrors[0]?.extensions?.code),
                        (t = a.error.graphQLErrors[0]?.message)),
                      (o = e
                        ? {
                            type: "requestXsollaUserTokenResponse",
                            error: { code: e, message: t || "" },
                          }
                        : {
                            type: "requestXsollaUserTokenResponse",
                            error: {
                              code: "unexpectedError",
                              message: "Failed to retrieve Xsolla user token",
                            },
                          });
                  } else
                    o = {
                      type: "requestXsollaUserTokenResponse",
                      token: n.token,
                      expiresIn: n.expiresIn,
                    };
                  e.postMessage(o, "*");
                },
                [t, f, r, g]
              ),
              z = (0, n.useCallback)(
                async (e, o) => {
                  let { itemId: a, xsollaProjectId: n, sandbox: i } = o,
                    s = (t, r) => {
                      let o;
                      return (
                        (o = {
                          type: "storeBuyItemResponse",
                          itemId: a,
                          error: { code: t, message: r },
                        }),
                        e.postMessage(o, "*")
                      );
                    };
                  if (!r)
                    return void s(
                      "userNotAuthenticated",
                      "The user is not authenticated"
                    );
                  let l = await f({ gameId: t });
                  if (l.error)
                    return (console.error(
                      "Error retrieving Xsolla user token:",
                      l.error
                    ),
                    "userNotAuthenticated" ===
                      (x(l.error) && l.error.graphQLErrors.length > 0
                        ? l.error.graphQLErrors[0]?.extensions?.code
                        : void 0))
                      ? void s(
                          "userNotAuthenticated",
                          "User must be logged in to perform this action."
                        )
                      : void s(
                          "unexpectedError",
                          "Something went wrong while retrieving the Xsolla token."
                        );
                  let d = l.data?.xsollaUserToken?.token;
                  if (!(0, k.O)(d))
                    return void s(
                      "unexpectedError",
                      "Xsolla token missing even though the user is authenticated."
                    );
                  try {
                    await F({
                      xsollaProjectId: n,
                      itemId: a,
                      sandbox: i,
                      xsollaUserToken: d,
                    }),
                      e.postMessage(
                        { type: "storeBuyItemResponse", itemId: a },
                        "*"
                      );
                  } catch (e) {
                    if (e instanceof N) return void s(e.code, e.message);
                    console.error(
                      "Unexpected failure while buying an Xsolla item",
                      e
                    ),
                      s(
                        "unexpectedError",
                        "The purchase could not be completed."
                      );
                  }
                },
                [r, d, t, f]
              ),
              L = (0, n.useCallback)(
                async (e, o) => {
                  let a,
                    n,
                    i,
                    {
                      requestId: s,
                      xsollaProjectId: l,
                      limit: d,
                      offset: u,
                    } = o,
                    c = (t, r) => {
                      let o;
                      return (
                        (o = {
                          type: "storeGetCatalogItemsResponse",
                          requestId: s,
                          error: { code: t, message: r },
                        }),
                        e.postMessage(o, "*")
                      );
                    };
                  if (r)
                    try {
                      let e = await f({ gameId: t });
                      n = e.data?.xsollaUserToken?.token;
                    } catch (e) {
                      console.error(
                        "No Xsolla user token available, requesting the catalog anonymously",
                        e
                      );
                    }
                  try {
                    i = await R({
                      xsollaProjectId: l,
                      limit: d,
                      offset: u,
                      xsollaUserToken: n,
                    });
                  } catch (e) {
                    if (e instanceof S) return void c(e.code, e.message);
                    console.error(
                      "Unexpected failure while listing the Xsolla catalog",
                      e
                    ),
                      c(
                        "unexpectedError",
                        "The catalog could not be retrieved."
                      );
                    return;
                  }
                  (a = {
                    type: "storeGetCatalogItemsResponse",
                    requestId: s,
                    catalogPage: i,
                  }),
                    e.postMessage(a, "*");
                },
                [r, d, t, f]
              ),
              G = (0, n.useCallback)(
                async (e, t, r) => {
                  try {
                    let o = await h({
                        variables: {
                          input: { pagination: { page: e, size: t } },
                        },
                      }),
                      a = o.data?.friendsPage;
                    if ((0, k.O)(o.error)) throw o.error;
                    if (!(0, k.O)(a)) throw Error("No friends data returned");
                    let n = {
                      type: "requestFriendsListResponse",
                      friendsPage: {
                        friends: a.friends.map((e) => ({
                          id: e.id,
                          username: e.username,
                          profilePictureUrl: `${B.A.Instance.data.images}${e.profile.avatar}`,
                        })),
                        page: a.page,
                        size: a.size,
                        hasMore: a.hasMore,
                        total: a.total,
                      },
                    };
                    r.postMessage(n, "*");
                  } catch (e) {
                    console.error("Failed to fetch friends list", e),
                      r.postMessage(
                        {
                          type: "requestFriendsListResponse",
                          error: {
                            code: "unexpectedError",
                            message: "Failed to retrieve friends list",
                          },
                        },
                        "*"
                      );
                  }
                },
                [h]
              ),
              U = (0, n.useCallback)(
                async (e, t) => {
                  let o;
                  if (!r) {
                    l("friendsGuest", { clickOrigin: D }),
                      e.postMessage(
                        {
                          type: "requestAddFriendsResponse",
                          outcome: "notLoggedIn",
                        },
                        "*"
                      );
                    return;
                  }
                  if (t)
                    try {
                      let { data: e, error: r } = await w({
                        variables: { id: t },
                      });
                      !r && e?.user?.id && (o = e.user.id);
                    } catch (e) {
                      console.error(
                        "Failed to look up user for add friends",
                        e
                      );
                    }
                  l("addFriends", {
                    params: { highlightUserId: o },
                    clickOrigin: D,
                  }),
                    e.postMessage(
                      { type: "requestAddFriendsResponse", outcome: "shown" },
                      "*"
                    );
                },
                [r, l, w]
              ),
              q = (0, n.useCallback)(
                async (e, o) => {
                  let a, n;
                  if (!r)
                    return void e.postMessage(
                      {
                        type: "requestNudgeFriendResponse",
                        error: {
                          code: "userNotAuthenticated",
                          message: "The user is not authenticated",
                        },
                      },
                      "*"
                    );
                  try {
                    let { data: e } = await T({
                      variables: { input: { gameId: t, friendUserId: o } },
                    });
                    a = e?.nudgeFriend;
                  } catch (e) {
                    console.error("Failed to nudge friend", e);
                  }
                  (n = a
                    ? { type: "requestNudgeFriendResponse", outcome: a }
                    : {
                        type: "requestNudgeFriendResponse",
                        error: {
                          code: "unexpectedError",
                          message: "Failed to nudge friend",
                        },
                      }),
                    e.postMessage(n, "*");
                },
                [r, t, T]
              );
            return (
              (0, n.useEffect)(() => {
                let e = (e) => {
                  if (e.data && e.data.type === s.x)
                    switch (e.data.event) {
                      case "requestUserToken": {
                        let t = e.data;
                        I(e.source, t.iframeUrl, t.signingKeyType);
                        break;
                      }
                      case "requestXsollaUserToken":
                        j(e.source);
                        break;
                      case "storeBuyItem":
                        z(e.source, e.data);
                        break;
                      case "storeGetCatalogItems":
                        L(e.source, e.data);
                        break;
                      case "showAuthPrompt":
                        let t;
                        (t = () => {
                          setTimeout(() => {
                            l("signIn", { clickOrigin: "sdkAuthPrompt" }),
                              y(!0),
                              b(e.source),
                              c.A.removeFakeFullscreenListener(t);
                          }, 100);
                        }),
                          c.A.isFakeFullscreen()
                            ? c.A.addFakeFullscreenListener(t)
                            : (l("signIn", { clickOrigin: "sdkAuthPrompt" }),
                              y(!0),
                              b(e.source));
                        break;
                      case "requestFriendsList":
                        let r = e.data.options;
                        G(r.page, r.size, e.source);
                        break;
                      case "requestAddFriends":
                        U(e.source, e.data.userId);
                        break;
                      case "requestNudgeFriend":
                        q(e.source, e.data.userId);
                        break;
                      default:
                        return;
                    }
                };
                return (
                  window.addEventListener("message", e),
                  function () {
                    window.removeEventListener("message", e);
                  }
                );
              }, [t, r, l, j, z, L, I, G, U, q]),
              null
            );
          };
        var L = r(8026),
          G = r(51196),
          U = r(71684);
        let q = (e) => {
          let { gfSource: t } = e,
            { services: r } = n.useContext(U.A),
            o = r.crazyAnalyticsService,
            a = r.analyticsAPIService,
            { pageUrlHelper: i } = n.useContext(G.e);
          return (
            n.useEffect(() => {}, [a, t, !1]),
            n.useEffect(() => {
              (async () => {
                let e = await o.analyticsInfo();
                i.isOnPreviewPage() && (e.enabled = !1),
                  t.window?.postMessage(
                    {
                      type: "analyticsInfoGF",
                      data: { analyticsInfo: e, shouldRelayEvents: !1 },
                    },
                    "*"
                  );
              })();
            }, [o, t, i, !1]),
            null
          );
        };
        function X(e) {
          return parseFloat(e) || 0;
        }
        r(96532);
        var $ = r(18262);
        let W = (e) => {
          let { gfSource: t } = e;
          return (
            n.useEffect(() => {
              let e,
                r = (0, $.y)();
              if (!r) return;
              let o =
                  ((e = document.createElement("div")).setAttribute(
                    "aria-hidden",
                    "true"
                  ),
                  (e.style.cssText =
                    "position:fixed;visibility:hidden;pointer-events:none;width:0;height:0;padding:var(--safe-area-inset-top) var(--safe-area-inset-right) var(--safe-area-inset-bottom) var(--safe-area-inset-left)"),
                  document.body.appendChild(e),
                  e),
                a = null,
                n = () => {
                  var e;
                  let n,
                    i,
                    s,
                    l = (function (e, t) {
                      let r = t.getBoundingClientRect(),
                        o = getComputedStyle(t),
                        a = r.top + X(o.borderTopWidth) + X(o.paddingTop),
                        n = r.right - X(o.borderRightWidth) - X(o.paddingRight),
                        i =
                          r.bottom -
                          X(o.borderBottomWidth) -
                          X(o.paddingBottom),
                        s = r.left + X(o.borderLeftWidth) + X(o.paddingLeft),
                        { clientWidth: l, clientHeight: d } =
                          t.ownerDocument.documentElement,
                        u = Math.max(0, a),
                        c = Math.max(0, l - n),
                        p = Math.max(0, d - i),
                        f = Math.max(0, s);
                      return {
                        top: Math.max(0, Math.round(e.top - u)),
                        right: Math.max(0, Math.round(e.right - c)),
                        bottom: Math.max(0, Math.round(e.bottom - p)),
                        left: Math.max(0, Math.round(e.left - f)),
                      };
                    })(
                      {
                        top: X((n = getComputedStyle(o)).paddingTop),
                        right: X(n.paddingRight),
                        bottom: X(n.paddingBottom),
                        left: X(n.paddingLeft),
                      },
                      r
                    );
                  (null !== a &&
                    ((i = (e = a).top === l.top && e.bottom === l.bottom),
                    (s = e.left === l.left && e.right === l.right),
                    i && s)) ||
                    ((a = l),
                    t.window.postMessage(
                      { type: "safeAreaInsetsForGameframe", insets: l },
                      "*"
                    ));
                };
              n();
              let i = new MutationObserver(n);
              i.observe(document.documentElement, {
                attributes: !0,
                attributeFilter: ["style"],
              });
              let s = new ResizeObserver(n);
              return (
                s.observe(r),
                window.addEventListener("resize", n),
                () => {
                  i.disconnect(),
                    s.disconnect(),
                    window.removeEventListener("resize", n),
                    o.remove();
                }
              );
            }, [t]),
            null
          );
        };
        var V = r(28478),
          Q = r(589),
          J = r(11667),
          H = r(31211);
        let K = (e) => {
          let t,
            r,
            o,
            i,
            s,
            l = (0, a.c)(20),
            { game: d, gfSource: u } = e,
            { user: c, loadingUser: p } = n.useContext(O.R),
            { user: f, refetch: g } = E.Jd(),
            h = (0, Q.S)(),
            [w, m] = n.useState(!1),
            y = n.useRef(!1),
            { openedDrawer: v } = n.useContext(M.l9),
            { favouriteGames: b } = E.oS();
          if (l[0] !== b || l[1] !== d.slug) {
            let e;
            l[3] !== d.slug
              ? ((e = (e) => e.slug === d.slug), (l[3] = d.slug), (l[4] = e))
              : (e = l[4]),
              (t = b.some(e)),
              (l[0] = b),
              (l[1] = d.slug),
              (l[2] = t);
          } else t = l[2];
          let _ = t,
            P = (0, J.Mn)(d.id),
            [A, k] = n.useState(v);
          return (
            v !== A &&
              (k(v),
              v && ["signIn", "signUpEmail"].includes(v.drawer) && m(!0)),
            l[5] !== w || l[6] !== u || l[7] !== g || l[8] !== c
              ? ((r = () => {
                  w &&
                    c &&
                    !y.current &&
                    ((y.current = !0),
                    (async function () {
                      let e = await g();
                      if (!e.data) {
                        y.current = !1;
                        return;
                      }
                      let t = e.data.me,
                        r = {
                          username: `${t.username}`,
                          profilePictureUrl: `${B.A.Instance.data.images}${t.profile.avatar}`,
                        },
                        o = {
                          type: "userLoggedIn",
                          data: {
                            accountId: c.uid,
                            userData: r,
                            email: c?.email || void 0,
                          },
                        };
                      u.window?.postMessage(o, "*");
                    })());
                }),
                (o = [c, u, g, w]),
                (l[5] = w),
                (l[6] = u),
                (l[7] = g),
                (l[8] = c),
                (l[9] = r),
                (l[10] = o))
              : ((r = l[9]), (o = l[10])),
            n.useEffect(r, o),
            l[11] !== P ||
            l[12] !== u ||
            l[13] !== _ ||
            l[14] !== p ||
            l[15] !== h ||
            l[16] !== c ||
            l[17] !== f
              ? ((i = () => {
                  if (p) return;
                  let e = f
                      ? {
                          username: `${f.username}`,
                          profilePictureUrl: `${B.A.Instance.data.images}${f.profile.avatar}`,
                        }
                      : void 0,
                    t = {
                      type: "userPortalInfoSync",
                      data: {
                        accountId: c?.uid,
                        userData: e,
                        isFavouriteGame: _,
                        gameNotificationsStatus: c ? P : void 0,
                        email: c?.email || void 0,
                        profileCompleteStatus: {
                          isComplete: 100 === h,
                          hasGender: f?.profile.gender !== null,
                          hasBirthdate: f?.profile.birthday !== null,
                        },
                        lastActiveAt: (function () {
                          let e = V.A.LocalStorage.getItem(H.Aq);
                          if (e) return new Date(e).getTime();
                        })(),
                      },
                    };
                  u.window?.postMessage(t, "*");
                }),
                (s = [_, P, p, c, f, u, h]),
                (l[11] = P),
                (l[12] = u),
                (l[13] = _),
                (l[14] = p),
                (l[15] = h),
                (l[16] = c),
                (l[17] = f),
                (l[18] = i),
                (l[19] = s))
              : ((i = l[18]), (s = l[19])),
            n.useEffect(i, s),
            null
          );
        };
        async function Y(e, t) {
          switch (t.data.event) {
            case "sessionStart":
              await e.handleSessionStart(t);
              break;
            case "requestToFavouriteGame":
              await e.handleRequestToFavouriteGame(t);
              break;
            case "requestToUnFavouriteGame":
              await e.handleRequestToUnFavouriteGame(t);
              break;
            case "setGameNotifications":
              await e.handleSetGameNotifications(t);
              break;
            case "openGameNotificationPreferences":
              await e.handleOpenGameNotificationPreferences(t);
              break;
            case "openGameNotificationTypes":
              await e.handleOpenGameNotificationTypes(t);
              break;
            case "forwardToUpGraphql":
              await e.handleForwardToUpGraphql(t);
              break;
            case "requestGfInit":
              await e.handleRequestGfInit(t);
              break;
            case "redirectToHomepage":
              await e.handleRedirectToHomepage(t);
              break;
            case "refreshGamePage":
              await e.handleRefreshGamePage(t);
              break;
            case "browserBack":
              await e.handleBrowserBack(t);
              break;
            case "openProgressStatusDrawer":
              await e.handleOpenProgressStatusDrawer(t);
              break;
            case "feedback":
              await e.handleFeedback(t);
              break;
            case "showInviteButton":
              await e.handleShowInviteButton(t);
              break;
            case "hideInviteButton":
              await e.handleHideInviteButton(t);
              break;
            case "showFriendsDrawer":
              await e.handleShowFriendsDrawer(t);
              break;
            case "showEditProfileDrawer":
              await e.handleShowEditProfileDrawer(t);
              break;
            case "showLoginDrawer":
              await e.handleShowLoginDrawer(t);
              break;
            case "afterPlayNow":
              await e.handleAfterPlayNow(t);
              break;
            case "triggerPlayOnApp":
              await e.handleTriggerPlayOnApp(t);
              break;
            case "nativeVideo":
              await e.handleNativeVideo(t);
              break;
            case "completeProfile":
              await e.handleCompleteProfile(t);
              break;
            case "submitScore":
              await e.handleSubmitScore(t);
              break;
            case "gtagEvent":
              await e.handleGtagEvent(t);
              break;
            case "pointerLockChanged":
              await e.handlePointerLockChanged(t);
              break;
            case "updateMultiplayerRoomData":
              await e.handleUpdateMultiplayerRoomData(t);
              break;
            case "leftMultiplayerRoom":
              await e.handleLeftMultiplayerRoom(t);
              break;
            case "onJoinRoomListenerChange":
              await e.handleOnJoinRoomListenerChange(t);
              break;
            case "offlineGetGameData":
              await e.handleOfflineGetGameData(t);
              break;
            case "offlineReplaceGameData":
              await e.handleOfflineReplaceGameData(t);
              break;
            case "offlineClearGameData":
              await e.handleOfflineClearGameData(t);
              break;
            case "offlineFetchSdkGameData":
              await e.handleOfflineFetchSdkGameData(t);
              break;
            case "offlineSaveSdkGameData":
              await e.handleOfflineSaveSdkGameData(t);
              break;
            case "setGameContext":
              await e.handleSetGameContext(t);
              break;
            case "reportGameCompletedPercentage":
              await e.handleReportGameCompletedPercentage(t);
          }
        }
        var Z = r(27424);
        let ee = (e) => {
            let { gfSource: t } = e,
              { user: r } = n.useContext(O.R),
              { profile: o } = n.useContext(Z.u);
            return (
              n.useEffect(() => {
                let e = {
                  type: "userPortalInfoSync",
                  data: {
                    accountId: r?.uid,
                    email: r?.email ?? void 0,
                    isFavouriteGame: !1,
                    profileCompleteStatus: {
                      isComplete: !1,
                      hasGender: !1,
                      hasBirthdate: !1,
                    },
                    userData: o
                      ? { username: o.username, profilePictureUrl: o.avatarUrl }
                      : void 0,
                  },
                };
                t.window?.postMessage(e, "*");
              }, [r, t, o]),
              null
            );
          },
          et = "[OfflineSdkUserListener]",
          er = () => {
            let { user: e } = n.useContext(O.R);
            return (
              n.useEffect(() => {
                let t = (t) => {
                  if (!t.data || t.data.type !== s.x) return;
                  let r = t.source;
                  switch (t.data.event) {
                    case "requestUserToken": {
                      let t = e
                        ? {
                            code: "unexpectedError",
                            message:
                              "User tokens are unavailable during offline play",
                          }
                        : {
                            code: "userNotAuthenticated",
                            message: "The user is not authenticated",
                          };
                      console.log(
                        `${et} requestUserToken → responding ${t.code}`
                      ),
                        r.postMessage(
                          { type: "requestUserTokenResponse", error: t },
                          "*"
                        );
                      break;
                    }
                    case "showAuthPrompt":
                      console.log(
                        `${et} showAuthPrompt → responding userCancelled, signing in is unavailable offline`
                      ),
                        r.postMessage(
                          {
                            type: "showAuthPromptResponse",
                            error: {
                              code: "userCancelled",
                              message: "Signing in is unavailable offline",
                            },
                          },
                          "*"
                        );
                      break;
                    case "requestXsollaUserToken":
                      console.log(
                        `${et} requestXsollaUserToken → responding unexpectedError, payments are unavailable offline`
                      ),
                        r.postMessage(
                          {
                            type: "requestXsollaUserTokenResponse",
                            error: {
                              code: "unexpectedError",
                              message: "Payments are unavailable offline",
                            },
                          },
                          "*"
                        );
                      break;
                    case "requestFriendsList":
                      console.log(
                        `${et} requestFriendsList → responding unexpectedError, friends are unavailable offline`
                      ),
                        r.postMessage(
                          {
                            type: "requestFriendsListResponse",
                            error: {
                              code: "unexpectedError",
                              message:
                                "The friends list is unavailable offline",
                            },
                          },
                          "*"
                        );
                      break;
                    case "requestNudgeFriend":
                      console.log(
                        `${et} requestNudgeFriend → responding unexpectedError, friends are unavailable offline`
                      ),
                        r.postMessage(
                          {
                            type: "requestNudgeFriendResponse",
                            error: {
                              code: "unexpectedError",
                              message: "Nudging friends is unavailable offline",
                            },
                          },
                          "*"
                        );
                      break;
                    default:
                      return;
                  }
                };
                return (
                  window.addEventListener("message", t),
                  () => window.removeEventListener("message", t)
                );
              }, [e]),
              null
            );
          },
          eo = null,
          ea = (e) => {
            let t,
              r,
              l,
              d,
              u,
              c,
              p,
              f,
              g,
              h,
              w,
              y,
              v,
              b,
              P = (0, a.c)(38),
              { game: A, handlers: k, isOfflineGaming: E } = e,
              { user: B } = n.useContext(O.R),
              { vote: M, loading: C } = (0, L.Z)(A),
              [S, R] = n.useState(null),
              T = n.useRef(k);
            if (
              (P[0] !== k
                ? ((t = () => {
                    T.current = k;
                  }),
                  (P[0] = k),
                  (P[1] = t))
                : (t = P[1]),
              n.useLayoutEffect(t),
              P[2] === Symbol.for("react.memo_cache_sentinel")
                ? ((r = () => {
                    let e = (e) => {
                      if (e.data && e.data.type === s.x) {
                        if ("appAudioMute" === e.data.event) {
                          let t = e.data.muted;
                          e.source === eo?.window &&
                            "boolean" == typeof t &&
                            (0, i.setAppAudioMuted)(t);
                          return;
                        }
                        if ("requestGfInit" === e.data.event) {
                          let t = e.source;
                          R({ window: t }), (eo = { window: t });
                        }
                        Y(T.current, e).catch((t) => {
                          console.error(
                            `GameFrame handler failed (${e.data.event})`,
                            t
                          );
                        });
                      }
                    };
                    return (
                      window.addEventListener("message", e),
                      () => {
                        window.removeEventListener("message", e), (eo = null);
                      }
                    );
                  }),
                  (l = []),
                  (P[2] = r),
                  (P[3] = l))
                : ((r = P[2]), (l = P[3])),
              n.useEffect(r, l),
              P[4] !== S || P[5] !== B || P[6] !== M || P[7] !== C
                ? ((d = () => {
                    S &&
                      B &&
                      !C &&
                      S.window &&
                      S.window.postMessage(
                        { type: "gameRating-update", vote: M },
                        "*"
                      );
                  }),
                  (u = [S, B, M, C]),
                  (P[4] = S),
                  (P[5] = B),
                  (P[6] = M),
                  (P[7] = C),
                  (P[8] = d),
                  (P[9] = u))
                : ((d = P[8]), (u = P[9])),
              n.useEffect(d, u),
              !S)
            )
              return null;
            let I = E ? ee : K;
            return (
              P[10] !== S ? ((c = !1), (P[10] = S), (P[11] = c)) : (c = P[11]),
              P[12] !== I || P[13] !== A || P[14] !== S
                ? ((p = (0, o.jsx)(I, { game: A, gfSource: S })),
                  (P[12] = I),
                  (P[13] = A),
                  (P[14] = S),
                  (P[15] = p))
                : (p = P[15]),
              P[16] !== A || P[17] !== E
                ? ((f = E
                    ? (0, o.jsx)(er, {})
                    : (0, o.jsx)(z, { gameId: A.id })),
                  (g = !E && (0, o.jsx)(_, { game: A })),
                  (P[16] = A),
                  (P[17] = E),
                  (P[18] = f),
                  (P[19] = g))
                : ((f = P[18]), (g = P[19])),
              P[20] !== A || P[21] !== E
                ? ((h = !1), (P[20] = A), (P[21] = E), (P[22] = h))
                : (h = P[22]),
              P[23] !== S
                ? ((w = (0, o.jsx)(q, { gfSource: S })),
                  (y = (0, o.jsx)(W, { gfSource: S })),
                  (P[23] = S),
                  (P[24] = w),
                  (P[25] = y))
                : ((w = P[24]), (y = P[25])),
              P[26] !== S || P[27] !== E
                ? ((v = !E && (0, o.jsx)(m, { gfSource: S })),
                  (P[26] = S),
                  (P[27] = E),
                  (P[28] = v))
                : (v = P[28]),
              P[29] !== h ||
              P[30] !== w ||
              P[31] !== y ||
              P[32] !== v ||
              P[33] !== c ||
              P[34] !== p ||
              P[35] !== f ||
              P[36] !== g
                ? ((b = (0, o.jsxs)(o.Fragment, {
                    children: [c, p, f, g, h, w, y, v],
                  })),
                  (P[29] = h),
                  (P[30] = w),
                  (P[31] = y),
                  (P[32] = v),
                  (P[33] = c),
                  (P[34] = p),
                  (P[35] = f),
                  (P[36] = g),
                  (P[37] = b))
                : (b = P[37]),
              b
            );
          };
      },
      29366: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      31352: (e, t) => {
        "use strict";
        var r, o;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.BannerAdSize = void 0),
          ((o = r || (t.BannerAdSize = r = {})).BANNER = "BANNER"),
          (o.FULL_BANNER = "FULL_BANNER"),
          (o.LARGE_BANNER = "LARGE_BANNER"),
          (o.MEDIUM_RECTANGLE = "MEDIUM_RECTANGLE"),
          (o.LEADERBOARD = "LEADERBOARD"),
          (o.ADAPTIVE_BANNER = "ADAPTIVE_BANNER"),
          (o.SMART_BANNER = "SMART_BANNER");
      },
      35078: (e, t) => {
        "use strict";
        var r, o;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.BannerAdPosition = void 0),
          ((o = r || (t.BannerAdPosition = r = {})).TOP_CENTER = "TOP_CENTER"),
          (o.CENTER = "CENTER"),
          (o.BOTTOM_CENTER = "BOTTOM_CENTER");
      },
      35425: (e, t, r) => {
        "use strict";
        var o = Object.create
            ? function (e, t, r, o) {
                void 0 === o && (o = r);
                var a = Object.getOwnPropertyDescriptor(t, r);
                (!a ||
                  ("get" in a
                    ? !t.__esModule
                    : a.writable || a.configurable)) &&
                  (a = {
                    enumerable: !0,
                    get: function () {
                      return t[r];
                    },
                  }),
                  Object.defineProperty(e, o, a);
              }
            : function (e, t, r, o) {
                void 0 === o && (o = r), (e[o] = t[r]);
              },
          a = function (e, t) {
            for (var r in e)
              "default" === r ||
                Object.prototype.hasOwnProperty.call(t, r) ||
                o(t, e, r);
          };
        Object.defineProperty(t, "__esModule", { value: !0 }),
          a(r(44935), t),
          a(r(39485), t),
          a(r(73013), t),
          a(r(50851), t),
          a(r(29366), t),
          a(r(70024), t);
      },
      39167: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      39485: (e, t) => {
        "use strict";
        var r, o;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.AdmobConsentDebugGeography = void 0),
          ((o = r || (t.AdmobConsentDebugGeography = r = {}))[
            (o.DISABLED = 0)
          ] = "DISABLED"),
          (o[(o.EEA = 1)] = "EEA"),
          (o[(o.NOT_EEA = 2)] = "NOT_EEA"),
          (o[(o.US = 3)] = "US"),
          (o[(o.OTHER = 4)] = "OTHER");
      },
      39569: (e, t, r) => {
        "use strict";
        var o = Object.create
            ? function (e, t, r, o) {
                void 0 === o && (o = r);
                var a = Object.getOwnPropertyDescriptor(t, r);
                (!a ||
                  ("get" in a
                    ? !t.__esModule
                    : a.writable || a.configurable)) &&
                  (a = {
                    enumerable: !0,
                    get: function () {
                      return t[r];
                    },
                  }),
                  Object.defineProperty(e, o, a);
              }
            : function (e, t, r, o) {
                void 0 === o && (o = r), (e[o] = t[r]);
              },
          a = function (e, t) {
            for (var r in e)
              "default" === r ||
                Object.prototype.hasOwnProperty.call(t, r) ||
                o(t, e, r);
          };
        Object.defineProperty(t, "__esModule", { value: !0 }),
          a(r(5490), t),
          a(r(39167), t);
      },
      39730: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      41260: (e, t) => {
        "use strict";
        var r;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.AdMobPluginEvents = void 0),
          ((r || (t.AdMobPluginEvents = r = {})).Paid = "adPaid");
      },
      43461: (e, t, r) => {
        "use strict";
        r.d(t, {
          DO: () => b,
          Gr: () => _,
          HX: () => l,
          Lh: () => h,
          Mf: () => d,
          Nl: () => m,
          PQ: () => c,
          iS: () => y,
          sB: () => f,
          wR: () => v,
          zC: () => u,
        });
        var o = r(11027),
          a = r(75651);
        let n = r(28478).A.LocalStorage,
          i = "czy_ad_free_offer_state",
          s = {
            promptShownAt: [],
            promptShownInSession: null,
            promptDontShowAgain: !1,
            preAdShownAt: [],
            preAdDontShowAgain: !1,
            offerOpened: !1,
          };
        function l() {
          return window.location.search.includes("forceAdFreeSessionPrompt");
        }
        function d() {
          return window.location.search.includes("forceAdFreePreAdMessage");
        }
        function u(e) {
          return (0, a.B5)(e) || (0, a.pC)(e) || e === o.kl3.isoCode;
        }
        function c(e, t, r) {
          if (
            e.offerOpened ||
            e.promptDontShowAgain ||
            e.promptShownAt.length >= 3
          )
            return !1;
          if (null === e.promptShownInSession) return t >= 5;
          let o = Math.max(...e.promptShownAt);
          return t - e.promptShownInSession >= 5 && r - o >= 864e5;
        }
        function p(e, t) {
          return e.filter((e) => t - e < 6048e5);
        }
        function f(e, t, r) {
          return (
            !e.offerOpened &&
            !e.preAdDontShowAgain &&
            !t &&
            p(e.preAdShownAt, r).length < 3
          );
        }
        function g(e) {
          return Array.isArray(e) ? e.filter(Number.isFinite) : [];
        }
        function h() {
          try {
            let e = JSON.parse(n.getItem(i) || "{}");
            return {
              promptShownAt: g(e.promptShownAt),
              promptShownInSession: Number.isFinite(e.promptShownInSession)
                ? e.promptShownInSession
                : null,
              promptDontShowAgain: !0 === e.promptDontShowAgain,
              preAdShownAt: g(e.preAdShownAt),
              preAdDontShowAgain: !0 === e.preAdDontShowAgain,
              offerOpened: !0 === e.offerOpened,
            };
          } catch {
            return s;
          }
        }
        function w(e) {
          n.setItem(i, JSON.stringify({ ...h(), ...e }));
        }
        function m(e, t) {
          w({
            promptShownAt: [...h().promptShownAt, t],
            promptShownInSession: e,
          });
        }
        function y() {
          w({ promptDontShowAgain: !0 });
        }
        function v(e) {
          w({ preAdShownAt: [...p(h().preAdShownAt, e), e] });
        }
        function b() {
          w({ preAdDontShowAgain: !0 });
        }
        function _() {
          w({ offerOpened: !0 });
        }
      },
      44935: (e, t) => {
        "use strict";
        var r, o;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.AdmobConsentStatus = void 0),
          ((o = r || (t.AdmobConsentStatus = r = {})).NOT_REQUIRED =
            "NOT_REQUIRED"),
          (o.OBTAINED = "OBTAINED"),
          (o.REQUIRED = "REQUIRED"),
          (o.UNKNOWN = "UNKNOWN");
      },
      46871: (e, t, r) => {
        "use strict";
        var o = Object.create
          ? function (e, t, r, o) {
              void 0 === o && (o = r);
              var a = Object.getOwnPropertyDescriptor(t, r);
              (!a ||
                ("get" in a ? !t.__esModule : a.writable || a.configurable)) &&
                (a = {
                  enumerable: !0,
                  get: function () {
                    return t[r];
                  },
                }),
                Object.defineProperty(e, o, a);
            }
          : function (e, t, r, o) {
              void 0 === o && (o = r), (e[o] = t[r]);
            };
        Object.defineProperty(t, "__esModule", { value: !0 });
        var a = r(88140);
        for (var n in a)
          "default" === n ||
            Object.prototype.hasOwnProperty.call(t, n) ||
            o(t, a, n);
      },
      47553: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      48610: (e, t) => {
        "use strict";
        var r, o;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.BannerAdPluginEvents = void 0),
          ((o = r || (t.BannerAdPluginEvents = r = {})).SizeChanged =
            "bannerAdSizeChanged"),
          (o.Loaded = "bannerAdLoaded"),
          (o.FailedToLoad = "bannerAdFailedToLoad"),
          (o.Opened = "bannerAdOpened"),
          (o.Closed = "bannerAdClosed"),
          (o.AdImpression = "bannerAdImpression");
      },
      50851: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      58690: (e, t) => {
        "use strict";
        var r, o;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.MaxAdContentRating = void 0),
          ((o = r || (t.MaxAdContentRating = r = {})).General = "General"),
          (o.ParentalGuidance = "ParentalGuidance"),
          (o.Teen = "Teen"),
          (o.MatureAudience = "MatureAudience");
      },
      60287: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      68284: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      68701: (e, t, r) => {
        "use strict";
        var o = Object.create
            ? function (e, t, r, o) {
                void 0 === o && (o = r);
                var a = Object.getOwnPropertyDescriptor(t, r);
                (!a ||
                  ("get" in a
                    ? !t.__esModule
                    : a.writable || a.configurable)) &&
                  (a = {
                    enumerable: !0,
                    get: function () {
                      return t[r];
                    },
                  }),
                  Object.defineProperty(e, o, a);
              }
            : function (e, t, r, o) {
                void 0 === o && (o = r), (e[o] = t[r]);
              },
          a = function (e, t) {
            for (var r in e)
              "default" === r ||
                Object.prototype.hasOwnProperty.call(t, r) ||
                o(t, e, r);
          };
        Object.defineProperty(t, "__esModule", { value: !0 }),
          a(r(60287), t),
          a(r(48610), t),
          a(r(35078), t),
          a(r(31352), t),
          a(r(6479), t),
          a(r(68284), t);
      },
      69857: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      70024: (e, t) => {
        "use strict";
        var r, o;
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.PrivacyOptionsRequirementStatus = void 0),
          ((o =
            r || (t.PrivacyOptionsRequirementStatus = r = {})).NOT_REQUIRED =
            "NOT_REQUIRED"),
          (o.REQUIRED = "REQUIRED"),
          (o.UNKNOWN = "UNKNOWN");
      },
      73013: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      78136: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      81099: (e, t, r) => {
        "use strict";
        var o = Object.create
            ? function (e, t, r, o) {
                void 0 === o && (o = r);
                var a = Object.getOwnPropertyDescriptor(t, r);
                (!a ||
                  ("get" in a
                    ? !t.__esModule
                    : a.writable || a.configurable)) &&
                  (a = {
                    enumerable: !0,
                    get: function () {
                      return t[r];
                    },
                  }),
                  Object.defineProperty(e, o, a);
              }
            : function (e, t, r, o) {
                void 0 === o && (o = r), (e[o] = t[r]);
              },
          a = function (e, t) {
            for (var r in e)
              "default" === r ||
                Object.prototype.hasOwnProperty.call(t, r) ||
                o(t, e, r);
          };
        Object.defineProperty(t, "__esModule", { value: !0 }),
          a(r(14468), t),
          a(r(4893), t),
          a(r(2716), t),
          a(r(28349), t);
      },
      82326: (e, t, r) => {
        "use strict";
        var o = Object.create
            ? function (e, t, r, o) {
                void 0 === o && (o = r);
                var a = Object.getOwnPropertyDescriptor(t, r);
                (!a ||
                  ("get" in a
                    ? !t.__esModule
                    : a.writable || a.configurable)) &&
                  (a = {
                    enumerable: !0,
                    get: function () {
                      return t[r];
                    },
                  }),
                  Object.defineProperty(e, o, a);
              }
            : function (e, t, r, o) {
                void 0 === o && (o = r), (e[o] = t[r]);
              },
          a = function (e, t) {
            for (var r in e)
              "default" === r ||
                Object.prototype.hasOwnProperty.call(t, r) ||
                o(t, e, r);
          };
        Object.defineProperty(t, "__esModule", { value: !0 }),
          a(r(94716), t),
          a(r(10429), t),
          a(r(39730), t),
          a(r(26205), t),
          a(r(41260), t),
          a(r(23181), t);
      },
      83072: (e, t, r) => {
        "use strict";
        r.d(t, { r: () => n });
        var o = r(75155),
          a = r(32485);
        function n(e) {
          let t,
            r = (0, o.c)(4),
            { enabled: n, state: i } = (0, a.F)();
          return (
            r[0] !== n || r[1] !== e || r[2] !== i?.games
              ? ((t =
                  n &&
                  (!!e.isDailyGame ||
                    !!i?.games.some((t) => t.gameId === e.id))),
                (r[0] = n),
                (r[1] = e),
                (r[2] = i?.games),
                (r[3] = t))
              : (t = r[3]),
            t
          );
        }
      },
      88140: (e, t, r) => {
        "use strict";
        var o = Object.create
          ? function (e, t, r, o) {
              void 0 === o && (o = r);
              var a = Object.getOwnPropertyDescriptor(t, r);
              (!a ||
                ("get" in a ? !t.__esModule : a.writable || a.configurable)) &&
                (a = {
                  enumerable: !0,
                  get: function () {
                    return t[r];
                  },
                }),
                Object.defineProperty(e, o, a);
            }
          : function (e, t, r, o) {
              void 0 === o && (o = r), (e[o] = t[r]);
            };
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.WebviewConfigurator = void 0),
          (t.setBackForwardNavigationGestures = function (e) {
            try {
              t.WebviewConfigurator.setBackForwardNavigationGestures({
                enable: e,
              });
            } catch (e) {}
          }),
          (t.getBackForwardNavigationGesturesState = s),
          (t.setWebviewBounce = function (e) {
            try {
              t.WebviewConfigurator.setWebviewBounce({ enable: e });
            } catch (e) {}
          }),
          (t.getCookies = l),
          (t.getAppAudioMuted = d),
          (t.setAppAudioMuted = function (e) {
            "ios" === a.Capacitor.getPlatform() &&
              t.WebviewConfigurator.setAppAudioMuted({ muted: e }).catch(
                (e) => {
                  console.error("Failed to set the app audio mute", e);
                }
              );
          });
        let a = r(34651);
        var n = r(3678);
        for (var i in n)
          "default" === i ||
            Object.prototype.hasOwnProperty.call(t, i) ||
            o(t, n, i);
        async function s() {
          try {
            return (
              await t.WebviewConfigurator.getBackForwardNavigationGesturesState()
            ).data;
          } catch (e) {}
        }
        async function l() {
          try {
            return (await t.WebviewConfigurator.getCookies()).cookies;
          } catch (e) {}
        }
        async function d() {
          if ("ios" === a.Capacitor.getPlatform())
            try {
              return (await t.WebviewConfigurator.getAppAudioMuted()).muted;
            } catch (e) {
              return;
            }
        }
        t.WebviewConfigurator = (0, a.registerPlugin)(
          "WebviewConfiguratorPlugin"
        );
      },
      94716: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      96532: (e, t, r) => {
        "use strict";
        r.d(t, { Hc: () => b, N5: () => v, UL: () => h }), r(75155), r(55729);
        var o = r(2145),
          a = r(37983),
          n = r(74339),
          i = r(13885),
          s = r(68401),
          l = r(13246),
          d = r(95815),
          u = r(28918);
        let c = "[GFAdConnector]",
          p = { rewarded: null, interstitial: null },
          f = null;
        function g(e) {
          switch (e) {
            case "rewarded":
              return "rewarded";
            case "midroll":
            case "preroll":
              return "interstitial";
          }
        }
        function h(e) {
          u.S?.window.postMessage(
            {
              type: "NativeAdEvent",
              data: { action: "onAdError", message: e },
            },
            "*"
          );
        }
        let w = [
          "Organic",
          "Google Organic Search",
          "DirectLink",
          "Untrusted Devices",
        ];
        async function m() {
          let { generic: e, campaign: t } =
            l.A.Instance.data.advertizing.adMob.adUnitId;
          if (!t) return e;
          let r = (await (0, i.W)())?.network;
          return r && !w.includes(r) ? t : e;
        }
        async function y(e, t) {
          return (await m())[e][t];
        }
        async function v(e, t) {
          if (!(0, d.so)())
            return (
              console.log(`${c} ${e} show skipped — offline`),
              h("Ads are not available while offline"),
              "skippedOffline"
            );
          if (void 0 !== t)
            try {
              await o.AdMob.setApplicationMuted({ muted: t });
            } catch (e) {
              console.error(
                `${c} Failed to apply the ${
                  t ? "muted" : "unmuted"
                } state to AdMob`,
                e
              );
            }
          let r = g(e),
            a = await y(n.Capacitor.getPlatform(), r);
          return await P(a, r), "requested";
        }
        async function b(e) {
          if (!(0, d.so)())
            return void console.log(`${c} ${e} prefetch skipped — offline`);
          let t = g(e),
            r = await y(n.Capacitor.getPlatform(), t);
          await _(r, t);
        }
        async function _(e, t) {
          let r = await (!f &&
              (f = a.App.getInfo()
                .then((e) => !(0, s.x)(e.version, "1.7.0"))
                .catch(() => !0)),
            f),
            n = p[t];
          if (
            r &&
            n &&
            n.adUnitId === e &&
            !(Date.now() - n.preparedAt > 354e4)
          )
            return;
          let i = "development" === l.A.Instance.environment;
          switch (t) {
            case "rewarded":
              await o.AdMob.prepareRewardVideoAd({ adId: e, isTesting: i });
              break;
            case "interstitial":
              await o.AdMob.prepareInterstitial({ adId: e, isTesting: i });
              break;
            default:
              throw Error(`Unhandled AdMobVideoType: ${t}`);
          }
          r && (p[t] = { adUnitId: e, preparedAt: Date.now() });
        }
        async function P(e, t) {
          try {
            switch ((await _(e, t), (p[t] = null), t)) {
              case "rewarded":
                await o.AdMob.showRewardVideoAd();
                break;
              case "interstitial":
                await o.AdMob.showInterstitial();
                break;
              default:
                throw Error(`Unhandled AdMobVideoType: ${t}`);
            }
          } catch (e) {
            console.error(e);
          }
        }
      },
      97968: (e, t, r) => {
        "use strict";
        r.d(t, { L: () => n, M: () => a });
        let o = {
          "energy-refilled":
            "friends.upDrawer.gameNotifications.type.energyRefilled",
        };
        function a(e) {
          return o[e];
        }
        function n(e) {
          return e.filter((e) => {
            let { type: t } = e;
            return void 0 !== o[t];
          });
        }
      },
    },
  ]);
