!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (null != n) for (var o in n) n.hasOwnProperty(o) && (e[o] = n[o]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "b87b2597-4bd6-4380-834b-d98db5060e96"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-b87b2597-4bd6-4380-834b-d98db5060e96"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [83582, 89247],
    {
      2334: (e) => {
        e.exports = {
          multipleLabelsContainer:
            "GameThumbLabel_multipleLabelsContainer__eEBwr",
          mobile: "GameThumbLabel_mobile__cawJl",
          label: "GameThumbLabel_label__dz3yR",
          videoPlaying: "GameThumbLabel_videoPlaying__Xtmok",
          withOriginals: "GameThumbLabel_withOriginals__7mhGw",
          hot: "GameThumbLabel_hot__CWhxn",
          new: "GameThumbLabel_new__8GnG6",
          updated: "GameThumbLabel_updated__Z69rK",
          originals: "GameThumbLabel_originals__dbBXE",
        };
      },
      9756: (e) => {
        e.exports = {
          czyButton: "GameThumbMobile_czyButton__jtyWe",
          "czyButton--contained--purple":
            "GameThumbMobile_czyButton--contained--purple__3bHaE",
          "czyButton--contained--white":
            "GameThumbMobile_czyButton--contained--white__I5HwS",
          "czyButton--contained--grey":
            "GameThumbMobile_czyButton--contained--grey__dRRzA",
          "czyButton--contained--warning":
            "GameThumbMobile_czyButton--contained--warning__4cAKx",
          "czyButton--contained--alert":
            "GameThumbMobile_czyButton--contained--alert__leJTC",
          "czyButton--contained--success":
            "GameThumbMobile_czyButton--contained--success__rCfF7",
          "czyButton--contained--black":
            "GameThumbMobile_czyButton--contained--black__PPuaj",
          "czyButton--contained--green-gradient":
            "GameThumbMobile_czyButton--contained--green-gradient__k2ipt",
          "czyButton--contained--animated-green-gradient":
            "GameThumbMobile_czyButton--contained--animated-green-gradient__RqVLG",
          "scroll-gradient": "GameThumbMobile_scroll-gradient__i0Hyv",
          "czyButton--outlined--purple":
            "GameThumbMobile_czyButton--outlined--purple__Jb6u7",
          "czyButton--link--purple":
            "GameThumbMobile_czyButton--link--purple__YuER1",
          "czyButton--outlined--white":
            "GameThumbMobile_czyButton--outlined--white__4zJ2S",
          "czyButton--link--white":
            "GameThumbMobile_czyButton--link--white__rkgAD",
          "czyButton--outlined--grey":
            "GameThumbMobile_czyButton--outlined--grey__4EQ6S",
          "czyButton--link--grey":
            "GameThumbMobile_czyButton--link--grey__EYgfr",
          "czyButton--outlined--warning":
            "GameThumbMobile_czyButton--outlined--warning__gp2OD",
          "czyButton--link--warning":
            "GameThumbMobile_czyButton--link--warning__k0_Kb",
          "czyButton--outlined--alert":
            "GameThumbMobile_czyButton--outlined--alert__WT__7",
          "czyButton--link--alert":
            "GameThumbMobile_czyButton--link--alert__GTkjf",
          "czyButton--outlined--success":
            "GameThumbMobile_czyButton--outlined--success__JkMKX",
          "czyButton--link--success":
            "GameThumbMobile_czyButton--link--success__4Zppf",
          "czyButton--outlined": "GameThumbMobile_czyButton--outlined__YqKId",
          "czyButton--disabled": "GameThumbMobile_czyButton--disabled__2FCPO",
          "czyButton--height50": "GameThumbMobile_czyButton--height50__1oJZ3",
          "czyButton--height34": "GameThumbMobile_czyButton--height34__84C6r",
          "czyButton--height28": "GameThumbMobile_czyButton--height28__nauL5",
          "czyButton--fullWidth": "GameThumbMobile_czyButton--fullWidth__QCYE2",
          "czyButton--headerIcon":
            "GameThumbMobile_czyButton--headerIcon__EPY8u",
          "czyButton--headerIcon--desktop":
            "GameThumbMobile_czyButton--headerIcon--desktop__d0FXY",
          "czyButton--headerIcon--mobile":
            "GameThumbMobile_czyButton--headerIcon--mobile__9_WyK",
          "czyButton--headerIcon--withLabel":
            "GameThumbMobile_czyButton--headerIcon--withLabel__TYs06",
          mobileGameGridThumbContainer:
            "GameThumbMobile_mobileGameGridThumbContainer__NNLR2",
          isResponsiveGrid: "GameThumbMobile_isResponsiveGrid__MCYTM",
          gameThumbLinkMobile: "GameThumbMobile_gameThumbLinkMobile__71JCG",
          gameThumbTitleContainer:
            "GameThumbMobile_gameThumbTitleContainer__0tcw6",
        };
      },
      25590: (e) => {
        e.exports = {
          czyButton: "GameThumbDesktop_czyButton__k12LK",
          "czyButton--contained--purple":
            "GameThumbDesktop_czyButton--contained--purple__bG51A",
          "czyButton--contained--white":
            "GameThumbDesktop_czyButton--contained--white__d869V",
          "czyButton--contained--grey":
            "GameThumbDesktop_czyButton--contained--grey__4iRtg",
          "czyButton--contained--warning":
            "GameThumbDesktop_czyButton--contained--warning__sLLgn",
          "czyButton--contained--alert":
            "GameThumbDesktop_czyButton--contained--alert__HJW1Q",
          "czyButton--contained--success":
            "GameThumbDesktop_czyButton--contained--success__ftX53",
          "czyButton--contained--black":
            "GameThumbDesktop_czyButton--contained--black__jt3M9",
          "czyButton--contained--green-gradient":
            "GameThumbDesktop_czyButton--contained--green-gradient__lMIm_",
          "czyButton--contained--animated-green-gradient":
            "GameThumbDesktop_czyButton--contained--animated-green-gradient__hizhw",
          "scroll-gradient": "GameThumbDesktop_scroll-gradient__X0k24",
          "czyButton--outlined--purple":
            "GameThumbDesktop_czyButton--outlined--purple__yDa79",
          "czyButton--link--purple":
            "GameThumbDesktop_czyButton--link--purple__UOr1c",
          "czyButton--outlined--white":
            "GameThumbDesktop_czyButton--outlined--white__R2wVm",
          "czyButton--link--white":
            "GameThumbDesktop_czyButton--link--white__ZcCNn",
          "czyButton--outlined--grey":
            "GameThumbDesktop_czyButton--outlined--grey__BrrOK",
          "czyButton--link--grey":
            "GameThumbDesktop_czyButton--link--grey__dZZhm",
          "czyButton--outlined--warning":
            "GameThumbDesktop_czyButton--outlined--warning__viWmg",
          "czyButton--link--warning":
            "GameThumbDesktop_czyButton--link--warning__qo_pO",
          "czyButton--outlined--alert":
            "GameThumbDesktop_czyButton--outlined--alert__dV9CV",
          "czyButton--link--alert":
            "GameThumbDesktop_czyButton--link--alert__3NTVW",
          "czyButton--outlined--success":
            "GameThumbDesktop_czyButton--outlined--success__ySFUJ",
          "czyButton--link--success":
            "GameThumbDesktop_czyButton--link--success__bl6qv",
          "czyButton--outlined": "GameThumbDesktop_czyButton--outlined__F9G01",
          "czyButton--disabled": "GameThumbDesktop_czyButton--disabled__gJr0T",
          "czyButton--height50": "GameThumbDesktop_czyButton--height50__oNLdK",
          "czyButton--height34": "GameThumbDesktop_czyButton--height34__QtIU4",
          "czyButton--height28": "GameThumbDesktop_czyButton--height28__bq_Y0",
          "czyButton--fullWidth":
            "GameThumbDesktop_czyButton--fullWidth__OuPY3",
          "czyButton--headerIcon":
            "GameThumbDesktop_czyButton--headerIcon__OVtuU",
          "czyButton--headerIcon--desktop":
            "GameThumbDesktop_czyButton--headerIcon--desktop__9bRik",
          "czyButton--headerIcon--mobile":
            "GameThumbDesktop_czyButton--headerIcon--mobile__rDty4",
          "czyButton--headerIcon--withLabel":
            "GameThumbDesktop_czyButton--headerIcon--withLabel__XLCq0",
          gameThumbLinkDesktop: "GameThumbDesktop_gameThumbLinkDesktop__LS_Bs",
          isResponsiveGrid: "GameThumbDesktop_isResponsiveGrid__2KUfG",
          gameThumbMedia: "GameThumbDesktop_gameThumbMedia__L7si1",
          hasHoverOverlay: "GameThumbDesktop_hasHoverOverlay__qNdmo",
          hoverScaleOriginCenter:
            "GameThumbDesktop_hoverScaleOriginCenter__4LeMx",
          hoverScaleOriginRight:
            "GameThumbDesktop_hoverScaleOriginRight__hnAg8",
          hoverScaleOriginLeft: "GameThumbDesktop_hoverScaleOriginLeft___uXXv",
        };
      },
      46571: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => o });
        let o = function (e, t) {
          let n =
            arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
          try {
            return e.number(t, n);
          } catch (e) {
            return console.error(e), `${t}`;
          }
        };
      },
      58781: (e) => {
        e.exports = {
          czyButton: "GameThumbDesktopHovered_czyButton__d1ntT",
          "czyButton--contained--purple":
            "GameThumbDesktopHovered_czyButton--contained--purple__IxhW4",
          "czyButton--contained--white":
            "GameThumbDesktopHovered_czyButton--contained--white__qiGua",
          "czyButton--contained--grey":
            "GameThumbDesktopHovered_czyButton--contained--grey__uPPwB",
          "czyButton--contained--warning":
            "GameThumbDesktopHovered_czyButton--contained--warning__6VhaM",
          "czyButton--contained--alert":
            "GameThumbDesktopHovered_czyButton--contained--alert__lFehV",
          "czyButton--contained--success":
            "GameThumbDesktopHovered_czyButton--contained--success__yREeO",
          "czyButton--contained--black":
            "GameThumbDesktopHovered_czyButton--contained--black__pcNkL",
          "czyButton--contained--green-gradient":
            "GameThumbDesktopHovered_czyButton--contained--green-gradient__6hf_z",
          "czyButton--contained--animated-green-gradient":
            "GameThumbDesktopHovered_czyButton--contained--animated-green-gradient__9lQwQ",
          "scroll-gradient": "GameThumbDesktopHovered_scroll-gradient__Ud5LF",
          "czyButton--outlined--purple":
            "GameThumbDesktopHovered_czyButton--outlined--purple___ObPA",
          "czyButton--link--purple":
            "GameThumbDesktopHovered_czyButton--link--purple__mZy3r",
          "czyButton--outlined--white":
            "GameThumbDesktopHovered_czyButton--outlined--white__MZ6F1",
          "czyButton--link--white":
            "GameThumbDesktopHovered_czyButton--link--white__ZROvH",
          "czyButton--outlined--grey":
            "GameThumbDesktopHovered_czyButton--outlined--grey__U3DLx",
          "czyButton--link--grey":
            "GameThumbDesktopHovered_czyButton--link--grey__C8HZ2",
          "czyButton--outlined--warning":
            "GameThumbDesktopHovered_czyButton--outlined--warning__PhRgO",
          "czyButton--link--warning":
            "GameThumbDesktopHovered_czyButton--link--warning__yNXy_",
          "czyButton--outlined--alert":
            "GameThumbDesktopHovered_czyButton--outlined--alert__8rAoP",
          "czyButton--link--alert":
            "GameThumbDesktopHovered_czyButton--link--alert__2xxN_",
          "czyButton--outlined--success":
            "GameThumbDesktopHovered_czyButton--outlined--success__dFGXR",
          "czyButton--link--success":
            "GameThumbDesktopHovered_czyButton--link--success__rTiVe",
          "czyButton--outlined":
            "GameThumbDesktopHovered_czyButton--outlined__uv2Fy",
          "czyButton--disabled":
            "GameThumbDesktopHovered_czyButton--disabled__kvOvf",
          "czyButton--height50":
            "GameThumbDesktopHovered_czyButton--height50__5nwB_",
          "czyButton--height34":
            "GameThumbDesktopHovered_czyButton--height34__8YdLJ",
          "czyButton--height28":
            "GameThumbDesktopHovered_czyButton--height28__1FtMK",
          "czyButton--fullWidth":
            "GameThumbDesktopHovered_czyButton--fullWidth__vFe8P",
          "czyButton--headerIcon":
            "GameThumbDesktopHovered_czyButton--headerIcon__YgOot",
          "czyButton--headerIcon--desktop":
            "GameThumbDesktopHovered_czyButton--headerIcon--desktop__0xSNL",
          "czyButton--headerIcon--mobile":
            "GameThumbDesktopHovered_czyButton--headerIcon--mobile__zqHfd",
          "czyButton--headerIcon--withLabel":
            "GameThumbDesktopHovered_czyButton--headerIcon--withLabel__i3HLi",
          gameThumbHovered: "GameThumbDesktopHovered_gameThumbHovered__ODkww",
          "game-thumb-video-fade-in":
            "GameThumbDesktopHovered_game-thumb-video-fade-in__sHIF_",
          greyedOutOverlayVariant:
            "GameThumbDesktopHovered_greyedOutOverlayVariant__mBTLv",
          gameThumbTitleContainer:
            "GameThumbDesktopHovered_gameThumbTitleContainer__6GxTA",
          title: "GameThumbDesktopHovered_title__nahha",
          subTitleContainer: "GameThumbDesktopHovered_subTitleContainer__yq8BL",
          category: "GameThumbDesktopHovered_category__IrvXU",
          totals: "GameThumbDesktopHovered_totals__6aOmO",
          totalPlays: "GameThumbDesktopHovered_totalPlays__TKADR",
          releaseYear: "GameThumbDesktopHovered_releaseYear__VdNhN",
        };
      },
      59126: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => r });
        var o = n(6029),
          a = n(75155);
        n(55729);
        var i = n(50212),
          u = n(56732),
          l = n.n(u);
        let r = (e) => {
          let t,
            n,
            u = (0, a.c)(4),
            { className: r } = e;
          return (
            u[0] !== r
              ? ((t = (0, i.A)(l().skeleton, "skeleton", r)),
                (u[0] = r),
                (u[1] = t))
              : (t = u[1]),
            u[2] !== t
              ? ((n = (0, o.jsx)("div", { className: t })),
                (u[2] = t),
                (u[3] = n))
              : (n = u[3]),
            n
          );
        };
      },
      65619: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => y });
        var o = n(6029),
          a = n(75155);
        n(55729);
        var i = n(79942),
          u = n(50212),
          l = n(46571),
          r = n(47883),
          s = n(84376),
          c = n(93800),
          m = n(98542),
          d = n(56732),
          _ = n.n(d),
          h = n(58781),
          b = n.n(h);
        let y = (e) => {
          let t,
            n,
            d,
            h,
            y,
            g,
            z = (0, a.c)(28),
            {
              game: p,
              width: B,
              className: T,
              hideTitle: k,
              isPortrait: v,
            } = e,
            { game: G } = (0, r.F)(p),
            D = (0, r.m)();
          z[0] !== G || z[1] !== D || z[2] !== v || z[3] !== B
            ? ((t = D ? (0, s.A)(G, { width: B }, v) : null),
              (z[0] = G),
              (z[1] = D),
              (z[2] = v),
              (z[3] = B),
              (z[4] = t))
            : (t = z[4]);
          let w = t,
            { i18n: x } = (0, i.uB)();
          z[5] !== G.totalPlays || z[6] !== x
            ? ((n =
                G.totalPlays && G.totalPlays >= 100
                  ? (0, l.A)(x, G.totalPlays, { notation: "compact" })
                  : null),
              (z[5] = G.totalPlays),
              (z[6] = x),
              (z[7] = n))
            : (n = z[7]);
          let f = n;
          z[8] !== G.totalLikes || z[9] !== x
            ? ((d =
                G.totalLikes && G.totalLikes >= 10
                  ? (0, l.A)(x, G.totalLikes, { notation: "compact" })
                  : null),
              (z[8] = G.totalLikes),
              (z[9] = x),
              (z[10] = d))
            : (d = z[10]);
          let A = d;
          return (
            z[11] !== T ||
            z[12] !== G ||
            z[13] !== D ||
            z[14] !== v ||
            z[15] !== w ||
            z[16] !== B
              ? ((h = w
                  ? (0, o.jsx)("video", {
                      loop: !0,
                      autoPlay: !0,
                      preload: "none",
                      muted: !0,
                      disableRemotePlayback: !0,
                      children: (0, o.jsx)("source", {
                        src: w,
                        type: "video/mp4",
                      }),
                    })
                  : (0, o.jsxs)(o.Fragment, {
                      children: [
                        (0, o.jsx)(m.A, {
                          game: G,
                          greyedOut: !0,
                          width: B,
                          className: T,
                          forceAspectRatio: v ? "portrait" : void 0,
                        }),
                        D &&
                          (0, o.jsx)("div", {
                            className: (0, u.A)(
                              _().greyedOutOverlay,
                              b().greyedOutOverlayVariant
                            ),
                            children: (0, o.jsx)(c.A, { name: "cam-disabled" }),
                          }),
                      ],
                    })),
                (z[11] = T),
                (z[12] = G),
                (z[13] = D),
                (z[14] = v),
                (z[15] = w),
                (z[16] = B),
                (z[17] = h))
              : (h = z[17]),
            z[18] !== G.categoryName ||
            z[19] !== G.name ||
            z[20] !== G.releaseYear ||
            z[21] !== k ||
            z[22] !== A ||
            z[23] !== f
              ? ((y =
                  !k &&
                  (0, o.jsxs)("div", {
                    className: (0, u.A)(
                      b().gameThumbTitleContainer,
                      "gameThumbTitleContainer"
                    ),
                    children: [
                      (0, o.jsx)("div", {
                        className: b().title,
                        children: G.name,
                      }),
                      (0, o.jsxs)("div", {
                        className: (0, u.A)(
                          b().subTitleContainer,
                          "subtitle-container"
                        ),
                        children: [
                          G.categoryName &&
                            (0, o.jsx)("span", {
                              className: b().category,
                              children: G.categoryName,
                            }),
                          G.releaseYear &&
                            (0, o.jsx)("span", {
                              className: b().releaseYear,
                              children: G.releaseYear,
                            }),
                          f &&
                            (0, o.jsxs)("span", {
                              className: (0, u.A)(b().totals, b().totalPlays),
                              children: [
                                (0, o.jsx)(c.A, { name: "play-triangle" }),
                                f,
                              ],
                            }),
                          A &&
                            (0, o.jsxs)("span", {
                              className: (0, u.A)(b().totals, b().totalLikes),
                              children: [
                                (0, o.jsx)(c.A, { name: "thumb-up-filled" }),
                                A,
                              ],
                            }),
                        ],
                      }),
                    ],
                  })),
                (z[18] = G.categoryName),
                (z[19] = G.name),
                (z[20] = G.releaseYear),
                (z[21] = k),
                (z[22] = A),
                (z[23] = f),
                (z[24] = y))
              : (y = z[24]),
            z[25] !== h || z[26] !== y
              ? ((g = (0, o.jsxs)("div", {
                  className: b().gameThumbHovered,
                  children: [h, y],
                })),
                (z[25] = h),
                (z[26] = y),
                (z[27] = g))
              : (g = z[27]),
            g
          );
        };
      },
      80474: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => D, Y: () => G });
        var o = n(6029),
          a = n(55729),
          i = n(50212),
          u = n(4230),
          l = n(34302),
          r = n(47883),
          s = n(90930),
          c = n(40369),
          m = n(71684),
          d = n(47352),
          _ = n(52711),
          h = n(98542),
          b = n(83582),
          y = n(99521),
          g = n(59126),
          z = n(82207),
          p = n(65619),
          B = n(56732),
          T = n.n(B),
          k = n(25590),
          v = n.n(k);
        let G = 273,
          D = a.memo((e) => {
            let {
                game: t,
                addViewedGames: n,
                eagerLoading: B,
                bottomLabel: k,
                imgFetchPriority: D,
                className: w,
                onClickAction: x,
                icon: f,
                iconFn: A,
                hideTitle: L,
                thumbClassName: M,
                mediaClassName: H,
                enableInstantJoin: j,
                width: C,
                children: O,
                forceAspectRatio: N,
                isResponsiveGrid: I,
                removeThumbLabels: P,
                hoverScaleOrigin: S,
                disableHoverScale: R,
              } = e,
              [F, Y] = a.useState(!1),
              V = a.useRef(null),
              K = a.useRef(null),
              [E, J] = a.useState(!1),
              W = a.useContext(s.o),
              { services: q } = a.useContext(m.A),
              { artworkId: X, artworkExperimentId: Z } = (0, r.F)(t),
              U = a.useContext(u.A);
            a.useEffect(() => {
              let e = K.current;
              return (
                e &&
                  _.A.get().observe(e, () => {
                    _.A.get().unobserve(e), n && n(t.id, (0, c.Ay)(W)), J(!0);
                  }),
                () => {
                  _.A.get().unobserve(e),
                    V.current && window.clearTimeout(V.current);
                }
              );
            }, [n, t.id, W]),
              (0, l.A)({
                gameId: t.id,
                artworkId: X,
                artworkExperimentId: Z,
                enabled: E,
              });
            let Q = a.useMemo(
                () => (t.gameThumbLabels ?? []).filter((e) => !P?.includes(e)),
                [t.gameThumbLabels, P]
              ),
              $ = a.useCallback(() => {
                q.gameService.prefetchGameData(t, U);
              }, [q, t, U]),
              ee = C || G;
            if (t.loading) return (0, o.jsx)(g.A, {}, t.slug);
            let et = "desktop" === U.deviceType,
              en = (0, i.A)(
                w,
                v().gameThumbLinkDesktop,
                I && v().isResponsiveGrid,
                !R && v().hasHoverOverlay,
                "center" === S && v().hoverScaleOriginCenter,
                "left" === S && v().hoverScaleOriginLeft,
                "right" === S && v().hoverScaleOriginRight,
                "game-thumb-test-class"
              );
            return (0, o.jsx)(d.A, {
              slug: t.slug,
              isKids: t.isKids,
              className: en,
              isInstantJoin: j && !!t?.multiplayerOptions?.supportsInstantJoin,
              onClick: () => {
                x?.(t.id, t.slug);
              },
              onMouseOver: () => {
                F ||
                  (Y(!0),
                  (V.current = window.setTimeout(() => {
                    $();
                  }, 500)));
              },
              onMouseLeave: () => {
                Y(!1),
                  V.current && (clearTimeout(V.current), (V.current = null));
              },
              ref: K,
              "aria-label": t.name,
              children: (0, o.jsxs)(o.Fragment, {
                children: [
                  (0, o.jsx)(b.default, {
                    videoPlaying: F,
                    gameThumbLabels: Q,
                  }),
                  f
                    ? (0, o.jsx)("div", {
                        className: T().closeBtnContainer,
                        onClick: (e) => {
                          e.preventDefault(),
                            e.stopPropagation(),
                            A && A(t.id, t.slug);
                        },
                        children: f,
                      })
                    : null,
                  k &&
                    (0, o.jsx)("div", {
                      className: (0, i.A)(
                        T().bottomLabelContainer,
                        F && T().videoPlaying
                      ),
                      children: k,
                    }),
                  (0, o.jsxs)("div", {
                    className: (0, i.A)(v().gameThumbMedia, H),
                    children: [
                      F &&
                        et &&
                        (0, o.jsx)(p.A, {
                          game: t,
                          width: ee,
                          className: M,
                          hideTitle: L,
                        }),
                      !F && (0, o.jsx)(y.A, { game: t }),
                      (0, o.jsx)(h.A, {
                        game: t,
                        greyedOut: (0, z.V)(t) && !F,
                        eagerLoading: B,
                        width: ee,
                        imgFetchPriority: D,
                        className: M,
                        forceAspectRatio: N,
                      }),
                    ],
                  }),
                  O,
                ],
              }),
            });
          });
      },
      83582: (e, t, n) => {
        "use strict";
        n.r(t), n.d(t, { default: () => _ });
        var o = n(6029),
          a = n(75155),
          i = n(55729),
          u = n(50212),
          l = n(50293),
          r = n(4230),
          s = n(93800),
          c = n(2334),
          m = n.n(c);
        let d = ["updated", "new", "hot-desktop", "hot-mobile"],
          _ = (e) => {
            let t,
              n,
              c,
              _,
              h,
              b,
              y = (0, a.c)(22),
              { videoPlaying: g, gameThumbLabels: z, extraLabel: p } = e,
              B = i.useContext(r.A);
            if (y[0] !== B || y[1] !== p || y[2] !== z || y[3] !== g) {
              h = Symbol.for("react.early_return_sentinel");
              e: {
                if (((t = (0, l.xl)(B)), (!z || 0 === z.length) && !p)) {
                  h = null;
                  break e;
                }
                (_ = (e) =>
                  (0, o.jsx)("div", {
                    className: (0, u.A)(
                      m().multipleLabelsContainer,
                      !t && m().mobile
                    ),
                    children: e,
                  })),
                  (c = (e) =>
                    (0, o.jsx)("div", {
                      "aria-label": "Originals",
                      className: (0, u.A)(
                        m().label,
                        !t && m().mobile,
                        e && m().withOriginals,
                        m().originals,
                        g && m().videoPlaying
                      ),
                      children: (0, o.jsx)(s.A, { name: "originals6" }),
                    }));
                let e = (e, n) => {
                  if ("hot-desktop" === e) {
                    if (t)
                      return (0, o.jsx)("div", {
                        "aria-label": "Hot",
                        className: (0, u.A)(
                          m().label,
                          n && m().withOriginals,
                          m().hot,
                          g && m().videoPlaying
                        ),
                        children: (0, o.jsx)(s.A, { name: "hot" }),
                      });
                  } else if ("hot-mobile" === e) {
                    if (!t)
                      return (0, o.jsx)("div", {
                        "aria-label": "Hot",
                        className: (0, u.A)(
                          m().label,
                          n && m().withOriginals,
                          m().hot,
                          g && m().videoPlaying
                        ),
                        children: (0, o.jsx)(s.A, { name: "hot" }),
                      });
                  } else if ("new" === e)
                    return (0, o.jsx)("div", {
                      "aria-label": "New",
                      className: (0, u.A)(
                        m().label,
                        n && m().withOriginals,
                        m().new,
                        g && m().videoPlaying
                      ),
                      children: (0, o.jsx)(s.A, { name: "new" }),
                    });
                  else if ("updated" === e)
                    return (0, o.jsx)("div", {
                      "aria-label": "Updated",
                      className: (0, u.A)(
                        m().label,
                        n && m().withOriginals,
                        m().updated,
                        g && m().videoPlaying
                      ),
                      children: (0, o.jsx)(s.A, { name: "refresh" }),
                    });
                  return null;
                };
                n = z ?? [];
                let a = t && n.includes("originals") && n.length > 1,
                  i = !!p || a;
                for (let t of d)
                  if (n.includes(t)) {
                    let n = e(t, i);
                    if (null !== n) {
                      if (!i) {
                        h = n;
                        break e;
                      }
                      h = _(
                        (0, o.jsxs)(o.Fragment, {
                          children: [a && c(!0), n, p],
                        })
                      );
                      break e;
                    }
                  }
              }
              (y[0] = B),
                (y[1] = p),
                (y[2] = z),
                (y[3] = g),
                (y[4] = t),
                (y[5] = n),
                (y[6] = c),
                (y[7] = _),
                (y[8] = h);
            } else (t = y[4]), (n = y[5]), (c = y[6]), (_ = y[7]), (h = y[8]);
            if (h !== Symbol.for("react.early_return_sentinel")) return h;
            if (n.includes("originals")) {
              let e;
              if (t || p) {
                let e, t, n;
                return (
                  y[9] !== c
                    ? ((e = c(!0)), (y[9] = c), (y[10] = e))
                    : (e = y[10]),
                  y[11] !== p || y[12] !== e
                    ? ((t = (0, o.jsxs)(o.Fragment, { children: [e, p] })),
                      (y[11] = p),
                      (y[12] = e),
                      (y[13] = t))
                    : (t = y[13]),
                  y[14] !== _ || y[15] !== t
                    ? ((n = _(t)), (y[14] = _), (y[15] = t), (y[16] = n))
                    : (n = y[16]),
                  n
                );
              }
              return (
                y[17] !== c
                  ? ((e = c(!1)), (y[17] = c), (y[18] = e))
                  : (e = y[18]),
                e
              );
            }
            return (
              y[19] !== p || y[20] !== _
                ? ((b = p ? _(p) : null), (y[19] = p), (y[20] = _), (y[21] = b))
                : (b = y[21]),
              b
            );
          };
      },
      84376: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => a });
        var o = n(13246);
        let a = (e, t, n) => {
          let { videos: a } = e,
            { width: i, height: u } = t;
          if (
            (i || u) &&
            a &&
            ((a.sizes && a.sizes.length > 0) ||
              (n && a.portraitSizes && a.portraitSizes.length > 0))
          ) {
            let e = 1;
            window.devicePixelRatio > 1 && (e = window.devicePixelRatio);
            let i = u ? "height" : "width",
              l = [
                ...(n && a.portraitSizes && a.portraitSizes.length > 0
                  ? a.portraitSizes
                  : a.sizes),
              ].sort((e, t) => e[i] - t[i]),
              r = l.find((n) => n[i] >= t[i] * e);
            return r
              ? `${o.A.Instance.data.videos}${r.location}`
              : `${o.A.Instance.data.videos}${l[l.length - 1].location}`;
          }
          return null;
        };
      },
      89247: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => x });
        var o = n(6029),
          a = n(75155),
          i = n(55729),
          u = n(4230),
          l = n(50293),
          r = n(52461),
          s = n(82638),
          c = n(80474),
          m = n(50212),
          d = n(34302),
          _ = n(47883),
          h = n(90930),
          b = n(40369),
          y = n(47352),
          g = n(52711),
          z = n(98542),
          p = n(83582),
          B = n(99521),
          T = n(82207),
          k = n(56732),
          v = n.n(k),
          G = n(9756),
          D = n.n(G);
        let w = i.memo((e) => {
            let {
                game: t,
                eagerLoading: n,
                bottomLabel: a,
                className: l,
                onClickAction: r,
                imgFetchPriority: s,
                icon: c,
                iconFn: k,
                addViewedGames: G,
                isResponsiveGrid: w,
                hideTitle: x,
                thumbClassName: f,
                enableInstantJoin: A,
                children: L,
                removeThumbLabels: M,
              } = e,
              H = i.useRef(null),
              [j, C] = i.useState(!1),
              O = i.useContext(h.o),
              N = i.useContext(u.A),
              { artworkId: I, artworkExperimentId: P } = (0, _.F)(t);
            i.useEffect(() => {
              let e = H.current;
              return (
                e &&
                  g.A.get().observe(e, () => {
                    g.A.get().unobserve(e), G && G(t.id, (0, b.Ay)(O)), C(!0);
                  }),
                () => {
                  g.A.get().unobserve(e);
                }
              );
            }, [G, t.id, O]),
              (0, d.A)({
                gameId: t.id,
                artworkId: I,
                artworkExperimentId: P,
                enabled: j,
              });
            let S = i.useMemo(
                () => (t.gameThumbLabels ?? []).filter((e) => !M?.includes(e)),
                [t.gameThumbLabels, M]
              ),
              R = () =>
                !(t.androidFriendly || t.iosFriendly) ||
                (0, T.Q)(t, N) ||
                (0, T.V)(t),
              F = !R(),
              Y = [l || ""].filter((e) => e.length > 0).join(" ");
            return (0, o.jsx)("div", {
              className: (0, m.A)(
                D().mobileGameGridThumbContainer,
                w && D().isResponsiveGrid,
                l
              ),
              children: (0, o.jsx)(y.A, {
                className: (0, m.A)(
                  Y,
                  D().gameThumbLinkMobile,
                  "game-thumb-test-class"
                ),
                slug: t.slug,
                isKids: t.isKids,
                onClick: () => {
                  r?.(t.id, t.slug);
                },
                ref: H,
                isInstantJoin:
                  A && !!t?.multiplayerOptions?.supportsInstantJoin,
                children: (0, o.jsxs)(o.Fragment, {
                  children: [
                    F && (0, o.jsx)(p.default, { gameThumbLabels: S }),
                    !x &&
                      (0, o.jsx)("div", {
                        className: (0, m.A)(
                          D().gameThumbTitleContainer,
                          "gameThumbTitleContainer"
                        ),
                        children: t.name,
                      }),
                    c
                      ? (0, o.jsx)("div", {
                          className: v().closeBtnContainer,
                          onClick: (e) => {
                            e.preventDefault(),
                              e.stopPropagation(),
                              k && k(t.id, t.slug);
                          },
                          children: c,
                        })
                      : null,
                    (0, o.jsx)(B.A, { game: t }),
                    a &&
                      (0, o.jsx)("div", {
                        className: v().bottomLabelContainer,
                        children: a,
                      }),
                    (0, o.jsx)(z.A, {
                      game: t,
                      greyedOut: R(),
                      eagerLoading: n,
                      width: 205,
                      imgFetchPriority: s,
                      className: f,
                    }),
                    L,
                  ],
                }),
              }),
            });
          }),
          x = (e) => {
            let t = (0, a.c)(12),
              n = i.useContext(s.g).addViewedGames,
              m = i.useContext(u.A);
            if ((0, l.PS)(m)) {
              let a, i;
              return (
                t[0] !== n || t[1] !== e
                  ? ((a = (0, o.jsx)(c.A, { addViewedGames: n, ...e })),
                    (t[0] = n),
                    (t[1] = e),
                    (t[2] = a))
                  : (a = t[2]),
                t[3] !== e.game.origin || t[4] !== a
                  ? ((i = (0, o.jsx)(r.x, {
                      newClickOrigin: e.game.origin,
                      children: a,
                    })),
                    (t[3] = e.game.origin),
                    (t[4] = a),
                    (t[5] = i))
                  : (i = t[5]),
                i
              );
            }
            {
              let a, i;
              return (
                t[6] !== n || t[7] !== e
                  ? ((a = (0, o.jsx)(w, { addViewedGames: n, ...e })),
                    (t[6] = n),
                    (t[7] = e),
                    (t[8] = a))
                  : (a = t[8]),
                t[9] !== e.game.origin || t[10] !== a
                  ? ((i = (0, o.jsx)(r.x, {
                      newClickOrigin: e.game.origin,
                      children: a,
                    })),
                    (t[9] = e.game.origin),
                    (t[10] = a),
                    (t[11] = i))
                  : (i = t[11]),
                i
              );
            }
          };
      },
      98542: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => h, H: () => _ });
        var o = n(6029),
          a = n(75155),
          i = n(55729),
          u = n(50212),
          l = n(47883),
          r = n(50293),
          s = n(4230),
          c = n(81930),
          m = n(56732),
          d = n.n(m);
        let _ = { portrait: "2x3", landscape: "16x9", square: "1x1" },
          h = (e) => {
            let t,
              n,
              m,
              h,
              b,
              y,
              g,
              z = (0, a.c)(34),
              {
                game: p,
                greyedOut: B,
                eagerLoading: T,
                height: k,
                width: v,
                imgFetchPriority: G,
                onClick: D,
                className: w,
                forceAspectRatio: x,
                staticLayout: f,
              } = e,
              A = void 0 !== f && f,
              { game: L } = (0, l.F)(p),
              M = (0, l.m)(),
              [H, j] = i.useState(!1),
              C = i.useContext(s.A),
              O = x ? L.covers?.[_[x]] : null,
              N = L.cover;
            O
              ? (N = O)
              : (0, r.Fr)(C) && L.covers
              ? (N = L.covers["1x1"] || L.covers["2x3"] || L.cover)
              : !(0, r.xl)(C) && L.covers?.["1x1"] && (N = L.covers["1x1"]);
            let I = T ? "eager" : "lazy",
              P = v || void 0,
              S = k || void 0;
            if (z[0] !== N || z[1] !== P || z[2] !== S) {
              let e = { quality: 85, width: P, height: S, fit: "crop" };
              (t = (0, c.Ay)(N, e)),
                (n = (0, c.Wn)(N, e)),
                (z[0] = N),
                (z[1] = P),
                (z[2] = S),
                (z[3] = t),
                (z[4] = n);
            } else (t = z[3]), (n = z[4]);
            let R = n,
              F = !A && d().gameThumbImagePositioned,
              Y = B && d().greyedOut;
            z[5] !== w || z[6] !== F || z[7] !== Y
              ? ((m = (0, u.A)(d().gameThumbImage, F, Y, d().imageSkeleton, w)),
                (z[5] = w),
                (z[6] = F),
                (z[7] = Y),
                (z[8] = m))
              : (m = z[8]);
            let V = m;
            if (!M || !t) {
              let e, t;
              return (
                z[9] !== k || z[10] !== A || z[11] !== v
                  ? ((e = A ? { width: v, height: k } : void 0),
                    (z[9] = k),
                    (z[10] = A),
                    (z[11] = v),
                    (z[12] = e))
                  : (e = z[12]),
                z[13] !== V || z[14] !== D || z[15] !== e
                  ? ((t = (0, o.jsx)("div", {
                      className: V,
                      style: e,
                      onClick: D,
                    })),
                    (z[13] = V),
                    (z[14] = D),
                    (z[15] = e),
                    (z[16] = t))
                  : (t = z[16]),
                t
              );
            }
            let K = !A && d().gameThumbImagePositioned,
              E = B && d().greyedOut,
              J = !H && d().imageSkeleton;
            return (
              z[17] !== w || z[18] !== J || z[19] !== K || z[20] !== E
                ? ((h = (0, u.A)(d().gameThumbImage, K, E, J, w)),
                  (z[17] = w),
                  (z[18] = J),
                  (z[19] = K),
                  (z[20] = E),
                  (z[21] = h))
                : (h = z[21]),
              z[22] === Symbol.for("react.memo_cache_sentinel")
                ? ((b = () => j(!0)), (z[22] = b))
                : (b = z[22]),
              z[23] !== G
                ? ((y = G && { fetchPriority: G }), (z[23] = G), (z[24] = y))
                : (y = z[24]),
              z[25] !== k ||
              z[26] !== t ||
              z[27] !== I ||
              z[28] !== D ||
              z[29] !== R ||
              z[30] !== h ||
              z[31] !== y ||
              z[32] !== v
                ? ((g = (0, o.jsx)("img", {
                    className: h,
                    loading: I,
                    src: t,
                    alt: "",
                    width: v,
                    height: k,
                    srcSet: R,
                    onLoad: b,
                    ...y,
                    onClick: D,
                  })),
                  (z[25] = k),
                  (z[26] = t),
                  (z[27] = I),
                  (z[28] = D),
                  (z[29] = R),
                  (z[30] = h),
                  (z[31] = y),
                  (z[32] = v),
                  (z[33] = g))
                : (g = z[33]),
              g
            );
          };
      },
    },
  ]);
