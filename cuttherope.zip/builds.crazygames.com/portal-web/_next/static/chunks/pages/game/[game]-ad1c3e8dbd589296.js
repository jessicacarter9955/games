!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var a = arguments[t];
          if (null != a) for (var r in a) a.hasOwnProperty(r) && (e[r] = a[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "7c491781-7403-4f4d-b919-594d3bedd266"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-7c491781-7403-4f4d-b919-594d3bedd266"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [28939, 82335],
    {
      23033: (e, t, a) => {
        "use strict";
        a.d(t, {
          $Y: () => b,
          AJ: () => f,
          CZ: () => x,
          EJ: () => S,
          H_: () => y,
          Qe: () => A,
          Qh: () => g,
          Qq: () => m,
          SF: () => w,
          T5: () => h,
          a1: () => _,
          dq: () => d,
          hA: () => T,
          uA: () => v,
          wN: () => P,
          xV: () => R,
        });
        var r = a(14278),
          n = a(4801),
          i = a(72224),
          o = a(13246),
          s = a(61411),
          l = a(57212),
          c = a(87295),
          u = a(79430);
        function d() {
          return o.A.Instance.data.domains
            .map((e) => {
              let t = "en-US" === (0, s.cy)(e.host),
                a = { ...i.a },
                r = new n.A(a).generateHome();
              if (!r) return null;
              let o = (0, u.A)(e.host, r.href, {
                isMainDomain: t,
                locale: e.locale,
              }).toString();
              return { locale: e.locale, href: o.toString(), host: e.host };
            })
            .filter((e) => !!e);
        }
        function m(e) {
          return E((e) => e.generateCompetitions(), {}, e, "competitions");
        }
        function g(e) {
          return E((e) => e.generateScholarship(), {}, e, "scholarship");
        }
        function p(e) {
          return I((t) => t.generatePaginatedUpdatedGames({ page: e }), {});
        }
        function h(e) {
          return E((e) => e.generateRecent(), {}, e, "recent");
        }
        function f() {
          return I((e) => e.generateOriginals(), {});
        }
        function y(e) {
          return E((e) => e.generateTags(), {}, e, "tags");
        }
        function w(e, t) {
          return I((e, t) => e.generateLeaderboards(t), {
            page: e,
            sorting: t,
          });
        }
        function v(e, t) {
          return E((e, t) => e.generateGame(t), { slug: e }, t, "game");
        }
        function P(e) {
          return E((e) => e.generatePrivacyPolicy(), {}, e, "privacyPolicy");
        }
        function S(e) {
          return E(
            (e) => e.generateTermsAndConditions(),
            {},
            e,
            "termsAndConditions"
          );
        }
        function A(e) {
          return E((e) => e.generateSearch(), {}, e, "search");
        }
        function T(e) {
          return I((t) => t.generateProfilePage(e), {});
        }
        async function x(e, t, a, r) {
          if (t && "hot" === t)
            return I((e) => e.generatePaginatedHotGames({ page: 1 }), {});
          switch (e) {
            case c.QI:
              return E(
                (e) => e.generatePaginatedNewGames({ page: r }),
                {},
                await a.getRouteProviderData("newGames"),
                "newGames"
              );
            case c.F3:
              return p(r);
            default:
              return console.warn(`unexpected sorting in games ${e}`), p(r);
          }
        }
        async function b(e, t, a) {
          if (e.isCategory) {
            let r = await t.getRouteProviderData("category");
            return E(
              (e, t) => e.generateCategory(t),
              { slugTrl: e.slug, page: a },
              r,
              "category"
            );
          }
          {
            let r = await t.getRouteProviderData("tag");
            return E(
              (e, t) => e.generateTag(t),
              { slugTrl: e.slug, page: a },
              r,
              "tag"
            );
          }
        }
        function _(e, t, a) {
          return I((t, a) => t.generateMultiplayerWithTag(a, e.slug), {
            page: t,
            sorting: a,
          });
        }
        function R(e) {
          return I((t) => t.generateAllGames(e), {});
        }
        function E(e, t, a, r) {
          var l;
          let c;
          return ((l = a),
          (c = o.A.Instance.data.domains),
          l.map((e) => ({
            domain: c.find((t) => (0, s.qz)(t.locale) === e.locale),
            routeData: e,
          })))
            .map((a) => {
              let o = a.domain,
                l = "en-US" === (0, s.cy)(o.host),
                c = o.locale,
                d = {
                  ...i.a,
                  [r]: a.routeData.route,
                  locale: a.routeData.locale,
                },
                m = e(new n.A(d), t);
              if (!m || !a.domain) return null;
              let g = (0, u.A)(a.domain.host, m.href, {
                isMainDomain: l,
                locale: c,
              }).toString();
              return {
                locale: a.domain.locale,
                href: g.toString(),
                host: a.domain.host,
              };
            })
            .filter((e) => !!e);
        }
        function I(e, t) {
          let a = o.A.Instance.data.domains;
          return r.Y.map((r) => {
            let o = a.find((e) => e.locale === r);
            if (!o) return null;
            let c = "en-US" === (0, s.cy)(o.host),
              d = { ...i.a, locale: l.Ec[r].serverLocale },
              m = e(new n.A(d), t);
            if (!m) return null;
            let g = (0, u.A)(o.host, m.href, {
              isMainDomain: c,
              locale: r,
            }).toString();
            return { locale: o.locale, href: g.toString(), host: o.host };
          }).filter((e) => !!e);
        }
      },
      26356: (e, t, a) => {
        "use strict";
        a.r(t), a.d(t, { default: () => q });
        var r = a(6029),
          n = a(75155),
          i = a(55729),
          o = a(18699),
          s = a(98417),
          l = a(79942),
          c = a(71024),
          u = a.n(c),
          d = a(81278),
          m = a.n(d),
          g = a(57802),
          p = a(45018),
          h = a(33770),
          f = a(13246),
          y = a(36173),
          w = a(952),
          v = a(80123),
          P = a(58107),
          S = a(41645),
          A = a(60092),
          T = a(93389),
          x = a(71543);
        let b = (e) => {
          let t,
            a,
            o,
            s,
            c = (0, n.c)(10),
            { structuredData: u } = e,
            { i18n: d } = (0, l.uB)(),
            { routeHelper: m } = i.useContext(T.A);
          return u
            ? (c[0] !== d || c[1] !== m || c[2] !== u
                ? ((a = "application/ld+json"),
                  (t = JSON.stringify([{ ...u, isPartOf: (0, x.Xr)(d, m) }])),
                  (c[0] = d),
                  (c[1] = m),
                  (c[2] = u),
                  (c[3] = t),
                  (c[4] = a))
                : ((t = c[3]), (a = c[4])),
              c[5] !== t
                ? ((o = { __html: t }), (c[5] = t), (c[6] = o))
                : (o = c[6]),
              c[7] !== a || c[8] !== o
                ? ((s = (0, r.jsx)("script", {
                    type: a,
                    dangerouslySetInnerHTML: o,
                  })),
                  (c[7] = a),
                  (c[8] = o),
                  (c[9] = s))
                : (s = c[9]),
              s)
            : null;
        };
        var _ = a(51196),
          R = a(91831),
          E = a(33163),
          I = a(23033),
          j = a(4230),
          D = a(50293),
          C = a(4699),
          L = a(78029),
          k = a(65889),
          M = a(61411),
          G = a(20183),
          U = a(15583),
          F = a(87295),
          W = a(66670),
          O = a(12097);
        let H = u()(
            () =>
              Promise.all([
                a.e(61019),
                a.e(22821),
                a.e(67592),
                a.e(60151),
                a.e(30944),
                a.e(55707),
                a.e(77938),
                a.e(16901),
                a.e(13e3),
                a.e(9690),
                a.e(89837),
                a.e(33297),
                a.e(65142),
                a.e(86092),
              ]).then(a.bind(a, 70642)),
            {
              loadableGenerated: { webpack: () => [70642] },
              loading: () => null,
              ssr: !0,
            }
          ),
          N = u()(
            () =>
              Promise.all([
                a.e(61019),
                a.e(30944),
                a.e(55707),
                a.e(77938),
                a.e(60151),
                a.e(28333),
                a.e(22821),
                a.e(67592),
                a.e(53),
                a.e(27239),
                a.e(9690),
                a.e(65597),
                a.e(8603),
                a.e(89837),
                a.e(3601),
                a.e(39565),
                a.e(33297),
                a.e(65142),
                a.e(54840),
                a.e(92511),
              ]).then(a.bind(a, 24795)),
            {
              loadableGenerated: { webpack: () => [24795] },
              loading: () => null,
              ssr: !0,
            }
          );
        {
          let e,
            t = (0, D.nO)();
          (0, s.O)(t) &&
            ((e = (0, L.BM)(
              Object.fromEntries(new URLSearchParams(window.location.search))
            )),
            "enabled" ===
              (0, o.y_)(
                "czyExpClientGamePagePreload",
                e.czyExpClientGamePagePreload
              )) &&
            ((0, D.PS)(t)
              ? Promise.all([
                  a.e(61019),
                  a.e(22821),
                  a.e(67592),
                  a.e(60151),
                  a.e(30944),
                  a.e(55707),
                  a.e(77938),
                  a.e(16901),
                  a.e(13e3),
                  a.e(9690),
                  a.e(89837),
                  a.e(33297),
                  a.e(65142),
                  a.e(86092),
                ]).then(a.bind(a, 70642))
              : Promise.all([
                  a.e(61019),
                  a.e(30944),
                  a.e(55707),
                  a.e(77938),
                  a.e(60151),
                  a.e(28333),
                  a.e(22821),
                  a.e(67592),
                  a.e(53),
                  a.e(27239),
                  a.e(9690),
                  a.e(65597),
                  a.e(8603),
                  a.e(89837),
                  a.e(3601),
                  a.e(39565),
                  a.e(33297),
                  a.e(65142),
                  a.e(54840),
                  a.e(92511),
                ]).then(a.bind(a, 24795))
            ).catch(() => {});
        }
        let z = (e) => {
          let t,
            a,
            o,
            s,
            c,
            u,
            d,
            m,
            h,
            P,
            S,
            x,
            I,
            L,
            k,
            M,
            G,
            U,
            F,
            W,
            O,
            z,
            q,
            B,
            J = (0, n.c)(88),
            {
              game: K,
              related: $,
              alternatives: X,
              isCrawler: Y,
              locale: Z,
              gamePlayerArm: ee,
            } = e,
            { routeHelper: et } = (0, i.useContext)(T.A),
            ea = (0, i.useContext)(j.A),
            { pageUrlHelper: er } = (0, i.useContext)(_.e),
            en = (0, l.uB)();
          J[0] !== K.id
            ? ((t = () => ((0, C.I)({ gameId: K.id }), V)),
              (a = [K.id]),
              (J[0] = K.id),
              (J[1] = t),
              (J[2] = a))
            : ((t = J[1]), (a = J[2])),
            (0, i.useEffect)(t, a);
          let ei = K.category?.name || "";
          if (
            J[3] !== K.metaDescription ||
            J[4] !== K.name ||
            J[5] !== K.pageTitle ||
            J[6] !== en ||
            J[7] !== ei
          ) {
            let e,
              t = { name: K.name, category: ei };
            J[10] !== K.name || J[11] !== K.pageTitle || J[12] !== en
              ? ((e = K.pageTitle
                  ? K.pageTitle
                  : en._("game.head.title", { name: K.name })),
                (J[10] = K.name),
                (J[11] = K.pageTitle),
                (J[12] = en),
                (J[13] = e))
              : (e = J[13]),
              (s = e),
              (o =
                K.metaDescription ||
                en._("game.head.metaDescriptionFallback", t)),
              (J[3] = K.metaDescription),
              (J[4] = K.name),
              (J[5] = K.pageTitle),
              (J[6] = en),
              (J[7] = ei),
              (J[8] = o),
              (J[9] = s);
          } else (o = J[8]), (s = J[9]);
          let eo = o;
          J[14] !== K.slug || J[15] !== et
            ? ((c = et.gameCanonical(K.slug)),
              (J[14] = K.slug),
              (J[15] = et),
              (J[16] = c))
            : (c = J[16]);
          let es = c,
            el = f.A.Instance.data.advertizing.domain;
          J[17] !== ea || J[18] !== K || J[19] !== er
            ? ((u = (0, p.j)(K, ea, er)),
              (J[17] = ea),
              (J[18] = K),
              (J[19] = er),
              (J[20] = u))
            : (u = J[20]);
          let ec = u;
          J[21] !== K.tags
            ? ((d = K.tags.map(Q)), (J[21] = K.tags), (J[22] = d))
            : (d = J[22]);
          let eu = d;
          J[23] !== K.customStructuredData
            ? ((m = () => {
                if (K.customStructuredData)
                  return (0, r.jsx)("script", {
                    type: "application/ld+json",
                    dangerouslySetInnerHTML: { __html: K.customStructuredData },
                  });
              }),
              (J[23] = K.customStructuredData),
              (J[24] = m))
            : (m = J[24]);
          let ed = m,
            em = ee ?? null,
            eg = K.slug,
            ep = K.category?.enSlug,
            eh = K.category?.name;
          J[25] !== K.loaderType ||
          J[26] !== K.name ||
          J[27] !== K.slug ||
          J[28] !== K.upvotes ||
          J[29] !== ep ||
          J[30] !== eh ||
          J[31] !== eu
            ? ((h = {
                gameName: K.name,
                gameSlug: K.slug,
                categoryEnSlug: ep,
                categoryName: eh,
                tagsSlug: eu,
                numLikes: K.upvotes,
                loader: K.loaderType,
              }),
              (J[25] = K.loaderType),
              (J[26] = K.name),
              (J[27] = K.slug),
              (J[28] = K.upvotes),
              (J[29] = ep),
              (J[30] = eh),
              (J[31] = eu),
              (J[32] = h))
            : (h = J[32]),
            J[33] !== K.maxWaitForSmartRefreshInMs ||
            J[34] !== K.minWaitForSmartRefreshInMs
              ? ((P = {
                  minWaitInMs: K.minWaitForSmartRefreshInMs,
                  maxWaitInMs: K.maxWaitForSmartRefreshInMs,
                }),
                (J[33] = K.maxWaitForSmartRefreshInMs),
                (J[34] = K.minWaitForSmartRefreshInMs),
                (J[35] = P))
              : (P = J[35]),
            J[36] === Symbol.for("react.memo_cache_sentinel")
              ? ((S = {}), (J[36] = S))
              : (S = J[36]),
            J[37] !== K.name
              ? ((x = (0, r.jsx)("meta", {
                  name: "apple-mobile-web-app-title",
                  content: K.name,
                })),
                (J[37] = K.name),
                (J[38] = x))
              : (x = J[38]),
            J[39] !== K.status
              ? ((I =
                  ("BASIC_LAUNCH" === K.status || "DRAFT" === K.status) &&
                  (0, r.jsx)("meta", { name: "robots", content: "noindex" })),
                (J[39] = K.status),
                (J[40] = I))
              : (I = J[40]),
            J[41] === Symbol.for("react.memo_cache_sentinel")
              ? ((L = (0, r.jsx)("link", { rel: "preconnect", href: el })),
                (J[41] = L))
              : (L = J[41]),
            J[42] !== ed
              ? ((k = ed()), (J[42] = ed), (J[43] = k))
              : (k = J[43]),
            J[44] !== X ||
            J[45] !== es ||
            J[46] !== eo ||
            J[47] !== x ||
            J[48] !== I ||
            J[49] !== k ||
            J[50] !== s
              ? ((M = (0, r.jsxs)(w.A, {
                  title: s,
                  metaDescription: eo,
                  canonical: es,
                  alternatives: X,
                  children: [x, I, L, k],
                })),
                (J[44] = X),
                (J[45] = es),
                (J[46] = eo),
                (J[47] = x),
                (J[48] = I),
                (J[49] = k),
                (J[50] = s),
                (J[51] = M))
              : (M = J[51]),
            J[52] !== K.structuredData
              ? ((G = (0, r.jsx)(b, { structuredData: K.structuredData })),
                (J[52] = K.structuredData),
                (J[53] = G))
              : (G = J[53]);
          let ef = K.cover ?? void 0;
          J[54] !== es || J[55] !== eo || J[56] !== ef || J[57] !== s
            ? ((U = (0, r.jsx)(R.A, {
                canonical: es,
                title: s,
                description: eo,
                imageUrl: ef,
                imageQuality: 100,
                type: "game",
              })),
              (J[54] = es),
              (J[55] = eo),
              (J[56] = ef),
              (J[57] = s),
              (J[58] = U))
            : (U = J[58]),
            J[59] !== ea || J[60] !== K || J[61] !== Y || J[62] !== $
              ? ((F = (0, D.PS)(ea)
                  ? (0, r.jsx)(H, {
                      game: K,
                      crawlerData: { isCrawler: Y, games: $ },
                    })
                  : (0, r.jsx)(N, {
                      game: K,
                      crawlerData: { isCrawler: Y, games: $ },
                    })),
                (J[59] = ea),
                (J[60] = K),
                (J[61] = Y),
                (J[62] = $),
                (J[63] = F))
              : (F = J[63]),
            J[64] !== ec ||
            J[65] !== K.slug ||
            J[66] !== Z ||
            J[67] !== h ||
            J[68] !== P ||
            J[69] !== M ||
            J[70] !== G ||
            J[71] !== U ||
            J[72] !== F
              ? ((W = (0, r.jsxs)(
                  g.A,
                  {
                    locale: Z,
                    advertisingGame: h,
                    disabled: ec,
                    smartRefresh: P,
                    edgeExperiments: S,
                    children: [M, G, U, F],
                  },
                  eg
                )),
                (J[64] = ec),
                (J[65] = K.slug),
                (J[66] = Z),
                (J[67] = h),
                (J[68] = P),
                (J[69] = M),
                (J[70] = G),
                (J[71] = U),
                (J[72] = F),
                (J[73] = W))
              : (W = J[73]);
          let ey = `gametracking-${K.slug}`;
          return (
            J[74] !== K || J[75] !== ey
              ? ((O = (0, r.jsx)(A.A, { game: K }, ey)),
                (J[74] = K),
                (J[75] = ey),
                (J[76] = O))
              : (O = J[76]),
            J[77] !== K
              ? ((z = (0, r.jsx)(y.R, { game: K })), (J[77] = K), (J[78] = z))
              : (z = J[78]),
            J[79] !== K.id || J[80] !== K.technology
              ? ((q = (0, r.jsx)(E.A, {
                  gameId: K.id,
                  gameTechnology: K.technology,
                })),
                (J[79] = K.id),
                (J[80] = K.technology),
                (J[81] = q))
              : (q = J[81]),
            J[82] !== W ||
            J[83] !== O ||
            J[84] !== z ||
            J[85] !== q ||
            J[86] !== em
              ? ((B = (0, r.jsxs)(v.d.Provider, {
                  value: em,
                  children: [W, O, z, q],
                })),
                (J[82] = W),
                (J[83] = O),
                (J[84] = z),
                (J[85] = q),
                (J[86] = em),
                (J[87] = B))
              : (B = J[87]),
            B
          );
        };
        z.getInitialProps = async (e) => {
          let t = (0, M.JK)(e),
            a = (e, t, a) => {
              let r = e.category?.enSlug;
              return e.collection
                ? t.tagPageDirectLink(e.collection, { returnRelative: a })
                : e.category
                ? t.categoryPageDirectLink(r, { returnRelative: a })
                : t.homePageLink();
            },
            {
              pageService: r,
              routeDataService: n,
              crawlerService: i,
            } = (0, O.V)(e),
            o = e.query[F.xL],
            s = (0, D.hz)(e),
            l = (0, D.Gz)(s) ? k.fU : k.TS,
            [{ game: c }, u] = await Promise.all([
              r.gamePage(o, s),
              n.getRouteProviderData("game"),
            ]),
            { res: d } = e;
          if ("ARCHIVED" === c.status) {
            let r = await n.getLocaleRouteProviderData(t),
              i = U.A.createFromContext(e, r);
            if (d) {
              let e = a(c, i, !1);
              d.writeHead(302, { Location: e.href }), d.end();
            } else {
              let e = a(c, i, !0);
              await m().push(e.href, e.href);
            }
          }
          d &&
            (d.setHeader(
              "Cache-Control",
              (0, h.H9)({ staleWhileRevalidate: 3600 })
            ),
            c.isKids &&
              (d.writeHead(302, {
                Location: `${f.A.Instance.data.kids}/game/${c.slug}`,
              }),
              d.end()));
          let g = (0, I.uA)(c.slug, u),
            p = "true" === e.query[F.pr],
            y = {
              game: c,
              numRelatedGames: l,
              alternatives: g,
              isCrawler: p,
              locale: t,
            },
            w = p ? null : (0, P.c)(o, s, e.query);
          return ("gameplayer" === w &&
            null !== (0, S.mW)(c) &&
            (y.gamePlayerArm = w),
          "gameframe-ssr" !== w ||
            !e.req ||
            c.isPreview ||
            c.activeArtworkExperiment ||
            (y.gamePlayerArm = w),
          p)
            ? await i.replaceGamePageForCrawler(y, s)
            : y;
        };
        let q = (0, G.A)("game")((0, W.A)(z));
        function V() {
          return (0, C.I)({ gameId: null });
        }
        function Q(e) {
          return e.enSlug || e.slug;
        }
      },
      39160: (e, t, a) => {
        "use strict";
        var r = Object.create
          ? function (e, t, a, r) {
              void 0 === r && (r = a);
              var n = Object.getOwnPropertyDescriptor(t, a);
              (!n ||
                ("get" in n ? !t.__esModule : n.writable || n.configurable)) &&
                (n = {
                  enumerable: !0,
                  get: function () {
                    return t[a];
                  },
                }),
                Object.defineProperty(e, r, n);
            }
          : function (e, t, a, r) {
              void 0 === r && (r = a), (e[r] = t[a]);
            };
        Object.defineProperty(t, "__esModule", { value: !0 });
        var n = a(41022);
        for (var i in n)
          "default" === i ||
            Object.prototype.hasOwnProperty.call(t, i) ||
            r(t, n, i);
      },
      41022: (e, t, a) => {
        "use strict";
        a.r(t), a.d(t, { InAppReview: () => r });
        let r = (0, a(34651).registerPlugin)("InAppReview", {
          web: () =>
            a
              .e(46296)
              .then(a.bind(a, 46296))
              .then((e) => new e.InAppReviewWeb()),
        });
      },
      41645: (e, t, a) => {
        "use strict";
        a.d(t, { JR: () => s, KG: () => c, Lz: () => l, mW: () => o });
        var r = a(79899),
          n = a(66424),
          i = a(18699);
        function o(e) {
          if (
            "html5" !== e.loaderType ||
            !e.loaderConfig ||
            !("url" in e.loaderConfig)
          )
            return null;
          let { url: t } = e.loaderConfig;
          return "string" == typeof t && t.length > 0 ? t : null;
        }
        function s(e, t) {
          let a = new URL(e);
          return (
            new URL(t).searchParams.forEach((e, t) => {
              "v" !== t && a.searchParams.append(t, e);
            }),
            a.toString()
          );
        }
        function l() {
          let e = {};
          return (
            (0, i.VS)()
              .filter((e) => e.startsWith("czyExpClient"))
              .forEach((t) => {
                if ((0, n.Hn)(t)) {
                  let { defaultValue: a, otherValues: r } = (0, n.bY)(t);
                  e[t] = [a, ...r];
                } else if ((0, r.H)(t)) {
                  let { defaultValue: a, otherValues: n } = (0, r.BK)(t);
                  e[t] = [a, ...n].map((e) => e.configCatValue);
                } else e[t] = null;
              }),
            e
          );
        }
        function c(e, t) {
          let a = new URL(e),
            r = new URL(t),
            n = a.origin + a.pathname === r.origin + r.pathname ? [] : ["path"];
          return (
            new Set([
              ...a.searchParams.keys(),
              ...r.searchParams.keys(),
            ]).forEach((e) => {
              a.searchParams.get(e) !== r.searchParams.get(e) && n.push(e);
            }),
            n.sort()
          );
        }
      },
      60092: (e, t, a) => {
        "use strict";
        a.d(t, { A: () => b });
        var r = a(6029),
          n = a(55729),
          i = a(89964),
          o = a(17802),
          s = a(79361),
          l = a(69933),
          c = a(18789),
          u = a(65233),
          d = a(56611),
          m = a(75155),
          g = a(74339),
          p = a(39160),
          h = a(14886),
          f = a(95815),
          y = a(49955),
          w = a(28478),
          v = a(71684);
        let P = (e) => {
          let t,
            a,
            r,
            i,
            o,
            s,
            l,
            c,
            d,
            P,
            x,
            b,
            _ = (0, m.c)(28),
            { gameId: R } = e,
            { services: E } = n.useContext(v.A),
            { user: I } = n.useContext(h.R),
            { syncPlayedTime: j } = n.useContext(u.oJ),
            [D] = n.useState(S);
          _[0] === Symbol.for("react.memo_cache_sentinel")
            ? ((t = Object.fromEntries(y.Ll.map(A))), (_[0] = t))
            : (t = _[0]);
          let C = n.useRef(t),
            L = n.useRef(!1),
            k = T,
            { gamesPlayedService: M, analyticsService: G } = E;
          _[1] !== j
            ? ((a = () => () => {
                j();
              }),
              (_[1] = j),
              (_[2] = a))
            : (a = _[2]),
            _[3] !== R || _[4] !== j
              ? ((r = [j, R]), (_[3] = R), (_[4] = j), (_[5] = r))
              : (r = _[5]),
            n.useEffect(a, r),
            _[6] !== G || _[7] !== R || _[8] !== D
              ? ((i = () => {
                  let e = Math.round((Date.now() - D) / 1e3);
                  y.Ll.forEach((t) => {
                    e >= 60 * t &&
                      !C.current[t] &&
                      (G.trackSessionPlaytimeRanges(R, t), (C.current[t] = !0));
                  });
                }),
                (_[6] = G),
                (_[7] = R),
                (_[8] = D),
                (_[9] = i))
              : (i = _[9]);
          let U = i;
          _[10] !== R || _[11] !== M || _[12] !== D || _[13] !== I
            ? ((o = () => {
                if (!I) return;
                let e = Math.round((Date.now() - D) / 1e3);
                M.handlePlayedTimeForUPSync(R, e);
              }),
              (_[10] = R),
              (_[11] = M),
              (_[12] = D),
              (_[13] = I),
              (_[14] = o))
            : (o = _[14]);
          let F = o;
          _[15] !== D
            ? ((s = () => {
                Math.round((Date.now() - D) / 1e3) >= 300 &&
                  !k() &&
                  (L.current = !0);
              }),
              (_[15] = D),
              (_[16] = s))
            : (s = _[16]);
          let W = s;
          return (
            _[17] === Symbol.for("react.memo_cache_sentinel")
              ? ((l = () => () => {
                  L.current &&
                    !k() &&
                    (0, f.so)() &&
                    (g.Capacitor.isNativePlatform() &&
                      p.InAppReview.requestReview(),
                    (function () {
                      w.A.LocalStorage.setItem(
                        "IN_APP_REVIEW_REQUESTED",
                        "true"
                      );
                    })());
                }),
                (c = []),
                (_[17] = l),
                (_[18] = c))
              : ((l = _[17]), (c = _[18])),
            n.useEffect(l, c),
            _[19] !== F || _[20] !== I
              ? ((P = () => {
                  I && F();
                }),
                (d = [I, F]),
                (_[19] = F),
                (_[20] = I),
                (_[21] = d),
                (_[22] = P))
              : ((d = _[21]), (P = _[22])),
            n.useEffect(P, d),
            _[23] !== U || _[24] !== F || _[25] !== W
              ? ((x = () => {
                  let e = null,
                    t = () => {
                      e = window.setInterval(() => {
                        F(), U();
                      }, y.sB);
                    },
                    a = () => {
                      document.hidden
                        ? e && (window.clearInterval(e), F(), U(), (e = null))
                        : t();
                    };
                  return (
                    t(),
                    document.addEventListener("visibilitychange", a),
                    function () {
                      document.removeEventListener("visibilitychange", a),
                        e && window.clearInterval(e);
                    }
                  );
                }),
                (b = [U, F, W]),
                (_[23] = U),
                (_[24] = F),
                (_[25] = W),
                (_[26] = x),
                (_[27] = b))
              : ((x = _[26]), (b = _[27])),
            n.useEffect(x, b),
            null
          );
        };
        function S() {
          return Date.now();
        }
        function A(e) {
          return [e, !1];
        }
        function T() {
          return "true" === w.A.LocalStorage.getItem("IN_APP_REVIEW_REQUESTED");
        }
        class x extends n.Component {
          constructor(e) {
            super(e),
              (this.addToRecentTimeout = null),
              (this.gameStartTime = 0),
              (this.pageUnload = () => {
                this.savePlayedGameTime();
              }),
              (this.processMessage = (e) => {
                if (e.data && e.data.type === i.x)
                  switch (e.data.event) {
                    case "afterPlayNow":
                    case "gameStartLoad":
                      break;
                    case "gameLoaded": {
                      let { gfVersion: t, loadedAt: a } = e.data;
                      this.handlePlayerStartedPlaying(t, a);
                      return;
                    }
                  }
              }),
              (this.delayedAddToRecent = () => {
                (0, o.Vc)("Game Add To Recent");
                let { game: e, userRecent: t } = this.props;
                t.addToRecent({
                  id: e.id,
                  slug: e.slug,
                  name: e.name,
                  cover: e.cover ?? "",
                  covers: e.covers ?? void 0,
                  videos: e.videos ?? {},
                  status: e.status,
                  iosFriendly: !!e.iosFriendly,
                  androidFriendly: !!e.androidFriendly,
                  gameThumbLabels: [],
                  activeArtworkExperiment: e.activeArtworkExperiment,
                  playedTime: 45,
                });
              }),
              (this.state = { trackTime: !1 });
          }
          render() {
            let { game: e } = this.props,
              { trackTime: t } = this.state;
            return t && (0, r.jsx)(P, { gameId: e.id });
          }
          componentDidMount() {
            let { services: e, game: t, isOfflineGaming: a } = this.props;
            a || e.crazyAnalyticsService.gamePageLoaded(t.id, t.buildId ?? ""),
              window.addEventListener("message", this.processMessage),
              window.addEventListener("pagehide", this.pageUnload);
          }
          componentWillUnmount() {
            this.savePlayedGameTime(),
              this.clearGameTracking(),
              window.removeEventListener("pagehide", this.pageUnload),
              window.removeEventListener("message", this.processMessage),
              this.props.services.crazyAnalyticsService.gamePageExited();
          }
          handlePlayerStartedPlaying(e, t) {
            (0, o.Vc)("Game Loaded"),
              this.setGameTracking(e, t),
              this.addToRecent();
          }
          addToRecent() {
            this.addToRecentTimeout = window.setTimeout(
              this.delayedAddToRecent,
              45e3
            );
          }
          setGameTracking(e, t) {
            let { services: a, game: r, isOfflineGaming: n } = this.props,
              { gamesPlayedService: i, crazyAnalyticsService: o } = a;
            i.startedPlayingGame(r), (this.gameStartTime = Date.now());
            let s = (0, d.SS)(r.slug)?.numPlays || 1;
            o.playingStarts({
              gfVersion: e,
              gameId: r.id,
              buildId: r.buildId,
              numPlays: s,
              offlineGaming: n,
              time: t,
            }),
              (0, d.A8)(r.slug),
              this.setState({ trackTime: !0 });
          }
          savePlayedGameTime() {
            let { game: e, services: t } = this.props;
            if (this.gameStartTime) {
              let a = Math.min(27e5, Date.now() - this.gameStartTime);
              t.gamesPlayedService.trackPlayedTime(e.slug, a),
                (0, s.Pq)(e.id, a);
            }
          }
          clearGameTracking() {
            this.addToRecentTimeout &&
              window.clearTimeout(this.addToRecentTimeout),
              this.setState({ trackTime: !1 });
          }
        }
        let b = (0, c.A)((0, u.QR)((0, l.A)(x)));
      },
      69933: (e, t, a) => {
        "use strict";
        a.d(t, { A: () => s });
        var r = a(6029),
          n = a(75155),
          i = a(55729),
          o = a(60362);
        let s = function (e) {
          return (t) => {
            let a,
              s = (0, n.c)(3),
              l = i.useContext(o.H);
            return (
              s[0] !== l || s[1] !== t
                ? ((a = (0, r.jsx)(e, { experiment: l, ...t })),
                  (s[0] = l),
                  (s[1] = t),
                  (s[2] = a))
                : (a = s[2]),
              a
            );
          };
        };
      },
      72224: (e, t, a) => {
        "use strict";
        a.d(t, { a: () => n, c: () => r });
        let r = [
            "newGames",
            "tags",
            "category",
            "tag",
            "game",
            "termsAndConditions",
            "informationForParents",
            "privacyPolicy",
            "recent",
            "search",
            "scholarship",
            "competitions",
          ],
          n = {
            newGames: { old: "", new: "" },
            tags: { old: "", new: "" },
            category: { old: "", new: "" },
            tag: { old: "", new: "" },
            game: { old: "", new: "" },
            termsAndConditions: { old: "", new: "" },
            privacyPolicy: { old: "", new: "" },
            recent: { old: "", new: "" },
            search: { old: "", new: "" },
            locale: { old: "", new: "" },
          };
      },
      80123: (e, t, a) => {
        "use strict";
        a.d(t, { d: () => r });
        let r = a(55729).createContext(null);
      },
      91831: (e, t, a) => {
        "use strict";
        a.d(t, { A: () => d });
        var r = a(6029),
          n = a(75155),
          i = a(55729),
          o = a(95669),
          s = a.n(o),
          l = a(61411),
          c = a(81930),
          u = a(74198);
        let d = (e) => {
          let t,
            a,
            o,
            d,
            m,
            g,
            p,
            h,
            f,
            y,
            w,
            v,
            P,
            S,
            A,
            T,
            x,
            b,
            _ = (0, n.c)(49),
            {
              canonical: R,
              title: E,
              description: I,
              imageUrl: j,
              imageWidth: D,
              imageHeight: C,
              imageQuality: L,
              type: k,
            } = e,
            M = void 0 === j ? "crazygames/share.png" : j,
            G = void 0 === D ? 1200 : D,
            U = void 0 === C ? 630 : C,
            { locale: F } = i.useContext(u.A);
          _[0] !== U || _[1] !== L || _[2] !== M || _[3] !== G
            ? ((t = (0, c.Ay)(M, {
                width: G,
                height: U,
                fit: "crop",
                quality: L,
              })),
              (_[0] = U),
              (_[1] = L),
              (_[2] = M),
              (_[3] = G),
              (_[4] = t))
            : (t = _[4]);
          let W = t;
          return (
            _[5] !== R
              ? ((a = (0, r.jsx)("meta", { property: "og:url", content: R })),
                (_[5] = R),
                (_[6] = a))
              : (a = _[6]),
            _[7] !== E
              ? ((o = (0, r.jsx)("meta", { property: "og:title", content: E })),
                (_[7] = E),
                (_[8] = o))
              : (o = _[8]),
            _[9] !== I
              ? ((d = (0, r.jsx)("meta", {
                  property: "og:description",
                  content: I,
                })),
                (_[9] = I),
                (_[10] = d))
              : (d = _[10]),
            _[11] !== F
              ? ((m = (0, l.qz)(F)), (_[11] = F), (_[12] = m))
              : (m = _[12]),
            _[13] !== m
              ? ((g = (0, r.jsx)("meta", {
                  property: "og:locale",
                  content: m,
                })),
                (_[13] = m),
                (_[14] = g))
              : (g = _[14]),
            _[15] !== W
              ? ((p = (0, r.jsx)("meta", { property: "og:image", content: W })),
                (_[15] = W),
                (_[16] = p))
              : (p = _[16]),
            _[17] !== G
              ? ((h = G.toString()), (_[17] = G), (_[18] = h))
              : (h = _[18]),
            _[19] !== h
              ? ((f = (0, r.jsx)("meta", {
                  property: "og:image:width",
                  content: h,
                })),
                (_[19] = h),
                (_[20] = f))
              : (f = _[20]),
            _[21] !== U
              ? ((y = U.toString()), (_[21] = U), (_[22] = y))
              : (y = _[22]),
            _[23] !== y
              ? ((w = (0, r.jsx)("meta", {
                  property: "og:image:height",
                  content: y,
                })),
                (_[23] = y),
                (_[24] = w))
              : (w = _[24]),
            _[25] !== k
              ? ((v =
                  k && (0, r.jsx)("meta", { property: "og:type", content: k })),
                (_[25] = k),
                (_[26] = v))
              : (v = _[26]),
            _[27] === Symbol.for("react.memo_cache_sentinel")
              ? ((P = (0, r.jsx)("meta", {
                  property: "twitter:card",
                  content: "summary_large_image",
                })),
                (_[27] = P))
              : (P = _[27]),
            _[28] !== R
              ? ((S = (0, r.jsx)("meta", {
                  property: "twitter:url",
                  content: R,
                })),
                (_[28] = R),
                (_[29] = S))
              : (S = _[29]),
            _[30] !== E
              ? ((A = (0, r.jsx)("meta", {
                  property: "twitter:title",
                  content: E,
                })),
                (_[30] = E),
                (_[31] = A))
              : (A = _[31]),
            _[32] !== I
              ? ((T = (0, r.jsx)("meta", {
                  property: "twitter:description",
                  content: I,
                })),
                (_[32] = I),
                (_[33] = T))
              : (T = _[33]),
            _[34] !== W
              ? ((x = (0, r.jsx)("meta", {
                  property: "twitter:image",
                  content: W,
                })),
                (_[34] = W),
                (_[35] = x))
              : (x = _[35]),
            _[36] !== p ||
            _[37] !== f ||
            _[38] !== w ||
            _[39] !== v ||
            _[40] !== S ||
            _[41] !== A ||
            _[42] !== T ||
            _[43] !== x ||
            _[44] !== a ||
            _[45] !== o ||
            _[46] !== d ||
            _[47] !== g
              ? ((b = (0, r.jsxs)(s(), {
                  children: [a, o, d, g, p, f, w, v, P, S, A, T, x],
                })),
                (_[36] = p),
                (_[37] = f),
                (_[38] = w),
                (_[39] = v),
                (_[40] = S),
                (_[41] = A),
                (_[42] = T),
                (_[43] = x),
                (_[44] = a),
                (_[45] = o),
                (_[46] = d),
                (_[47] = g),
                (_[48] = b))
              : (b = _[48]),
            b
          );
        };
      },
      99161: (e, t, a) => {
        (window.__NEXT_P = window.__NEXT_P || []).push([
          "/game/[game]",
          function () {
            return a(26356);
          },
        ]);
      },
    },
    (e) => {
      e.O(0, [6847, 5869, 89247, 88823, 73066, 46593, 90636, 38792], () =>
        e((e.s = 99161))
      ),
        (_N_E = e.O());
    },
  ]);
