!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (null != n) for (var a in n) n.hasOwnProperty(a) && (e[a] = n[a]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "51b8b763-d9c5-4d5b-a05f-86d9fc42efb2"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-51b8b763-d9c5-4d5b-a05f-86d9fc42efb2"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [49181, 86092],
    {
      3495: (e) => {
        e.exports = {
          gameContainerDesktopRoot:
            "GameContainerDesktop_gameContainerDesktopRoot__qvoxU",
          gameContainer: "GameContainerDesktop_gameContainer__TT_xK",
          gameIframe: "GameContainerDesktop_gameIframe__6GEYI",
          iframeLoading: "GameContainerDesktop_iframeLoading__cy9LG",
        };
      },
      22463: (e, t, n) => {
        "use strict";
        n.d(t, { L: () => s, v: () => c });
        var a = n(55729);
        let r = new Set(),
          l = !1,
          i = null;
        function o() {
          r.forEach((e) => e());
        }
        function s() {
          console.log(
            "[offlineAdMessageStore] showOfflineRewardedAdMessage() called — triggering toast"
          ),
            i && clearTimeout(i),
            (i = setTimeout(() => {
              (l = !1), (i = null), o();
            }, 4e3)),
            l || ((l = !0), o());
        }
        function d(e) {
          return (
            r.add(e),
            () => {
              r.delete(e);
            }
          );
        }
        function c() {
          return (0, a.useSyncExternalStore)(d, m, u);
        }
        function u() {
          return !1;
        }
        function m() {
          return l;
        }
      },
      32548: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => u });
        var a = n(6029),
          r = n(75155),
          l = n(55729),
          i = n(77650),
          o = n(50212);
        let s = (e) => e.toString().padStart(2, "0");
        var d = n(86268),
          c = n.n(d);
        let u = (e) => {
          let t,
            n,
            d,
            u,
            m,
            _ = (0, r.c)(11),
            { nextResetAt: g, className: h } = e,
            y = (function (e) {
              let t,
                n,
                a,
                [r, i] = l.useState(null);
              return (l.useEffect(() => {
                let e = () => i(Date.now()),
                  t = window.setTimeout(e, 0),
                  n = window.setInterval(e, 1e3);
                return () => {
                  window.clearTimeout(t), window.clearInterval(n);
                };
              }, []),
              null === r)
                ? null
                : ((n = Math.floor(
                    (t = Math.max(
                      0,
                      Math.floor(
                        ((e
                          ? new Date(e)
                          : (function () {
                              let e =
                                  arguments.length > 0 &&
                                  void 0 !== arguments[0]
                                    ? arguments[0]
                                    : new Date(),
                                t = new Date(
                                  Date.UTC(
                                    e.getUTCFullYear(),
                                    e.getUTCMonth(),
                                    e.getUTCDate(),
                                    5
                                  )
                                );
                              return (
                                t.getTime() <= e.getTime() &&
                                  t.setUTCDate(t.getUTCDate() + 1),
                                t
                              );
                            })(new Date(r))
                        ).getTime() -
                          r) /
                          1e3
                      )
                    )) / 3600
                  )),
                  (a = Math.floor((t % 3600) / 60)),
                  `${s(n)}:${s(a)}:${s(t % 60)}`);
            })(g);
          _[0] !== h
            ? ((t = (0, o.A)(c().countdown, h)), (_[0] = h), (_[1] = t))
            : (t = _[1]),
            _[2] !== y
              ? ((n = y
                  ? i.Ru._({
                      id: "common.dailyGames.resetsIn",
                      values: { time: y },
                    })
                  : void 0),
                (_[2] = y),
                (_[3] = n))
              : (n = _[3]),
            _[4] === Symbol.for("react.memo_cache_sentinel")
              ? ((d = (0, a.jsx)("span", {
                  className: c().hourglass,
                  "aria-hidden": !0,
                })),
                (_[4] = d))
              : (d = _[4]);
          let p = y ?? "--:--:--";
          return (
            _[5] !== p
              ? ((u = (0, a.jsx)("span", {
                  className: c().time,
                  "aria-hidden": !0,
                  children: p,
                })),
                (_[5] = p),
                (_[6] = u))
              : (u = _[6]),
            _[7] !== t || _[8] !== n || _[9] !== u
              ? ((m = (0, a.jsxs)("span", {
                  className: t,
                  role: "timer",
                  "aria-label": n,
                  children: [d, u],
                })),
                (_[7] = t),
                (_[8] = n),
                (_[9] = u),
                (_[10] = m))
              : (m = _[10]),
            m
          );
        };
      },
      35081: (e) => {
        e.exports = {
          czyButton: "AdUnit_czyButton__VfkFq",
          "czyButton--contained--purple":
            "AdUnit_czyButton--contained--purple__voBXC",
          "czyButton--contained--white":
            "AdUnit_czyButton--contained--white__k2A9P",
          "czyButton--contained--grey":
            "AdUnit_czyButton--contained--grey__4XyB6",
          "czyButton--contained--warning":
            "AdUnit_czyButton--contained--warning__n6K1B",
          "czyButton--contained--alert":
            "AdUnit_czyButton--contained--alert__I8I4C",
          "czyButton--contained--success":
            "AdUnit_czyButton--contained--success__f7DGM",
          "czyButton--contained--black":
            "AdUnit_czyButton--contained--black__gCaQV",
          "czyButton--contained--green-gradient":
            "AdUnit_czyButton--contained--green-gradient__kSob9",
          "czyButton--contained--animated-green-gradient":
            "AdUnit_czyButton--contained--animated-green-gradient__4dLQb",
          "scroll-gradient": "AdUnit_scroll-gradient__kdLyA",
          "czyButton--outlined--purple":
            "AdUnit_czyButton--outlined--purple__wetQ0",
          "czyButton--link--purple": "AdUnit_czyButton--link--purple__pZ2zl",
          "czyButton--outlined--white":
            "AdUnit_czyButton--outlined--white__c54pa",
          "czyButton--link--white": "AdUnit_czyButton--link--white__Im23U",
          "czyButton--outlined--grey":
            "AdUnit_czyButton--outlined--grey__mIDlb",
          "czyButton--link--grey": "AdUnit_czyButton--link--grey__AhXmb",
          "czyButton--outlined--warning":
            "AdUnit_czyButton--outlined--warning__EoPir",
          "czyButton--link--warning": "AdUnit_czyButton--link--warning__HAxPm",
          "czyButton--outlined--alert":
            "AdUnit_czyButton--outlined--alert__drksZ",
          "czyButton--link--alert": "AdUnit_czyButton--link--alert__57TEu",
          "czyButton--outlined--success":
            "AdUnit_czyButton--outlined--success__0lU53",
          "czyButton--link--success": "AdUnit_czyButton--link--success__lmj_h",
          "czyButton--outlined": "AdUnit_czyButton--outlined__GiMYZ",
          "czyButton--disabled": "AdUnit_czyButton--disabled__raKC9",
          "czyButton--height50": "AdUnit_czyButton--height50__gZ18m",
          "czyButton--height34": "AdUnit_czyButton--height34__7t5me",
          "czyButton--height28": "AdUnit_czyButton--height28__ywrcI",
          "czyButton--fullWidth": "AdUnit_czyButton--fullWidth___2bRc",
          "czyButton--headerIcon": "AdUnit_czyButton--headerIcon__DNaJ8",
          "czyButton--headerIcon--desktop":
            "AdUnit_czyButton--headerIcon--desktop__xhCBv",
          "czyButton--headerIcon--mobile":
            "AdUnit_czyButton--headerIcon--mobile__HccLa",
          "czyButton--headerIcon--withLabel":
            "AdUnit_czyButton--headerIcon--withLabel__N8XfV",
          adUnitRoot: "AdUnit_adUnitRoot__QUPaT",
          adUnitPaper: "AdUnit_adUnitPaper__hyYgu",
          innerWrapper: "AdUnit_innerWrapper__wpS4D",
          adSlot: "AdUnit_adSlot__JJinj",
          adWrapper: "AdUnit_adWrapper__OIK0n",
          adBlockWarning: "AdUnit_adBlockWarning___3c3B",
          alternativeAdWrapper: "AdUnit_alternativeAdWrapper__ylHEj",
          label: "AdUnit_label__E6Sg3",
          labelVertical: "AdUnit_labelVertical__iqLlA",
        };
      },
      46195: (e) => {
        e.exports = {
          czyButton: "GamePageDesktop_czyButton__gSwRs",
          "czyButton--contained--purple":
            "GamePageDesktop_czyButton--contained--purple__GIWws",
          "czyButton--contained--white":
            "GamePageDesktop_czyButton--contained--white__z2COm",
          "czyButton--contained--grey":
            "GamePageDesktop_czyButton--contained--grey__gBra2",
          "czyButton--contained--warning":
            "GamePageDesktop_czyButton--contained--warning__wENuO",
          "czyButton--contained--alert":
            "GamePageDesktop_czyButton--contained--alert__aN2rt",
          "czyButton--contained--success":
            "GamePageDesktop_czyButton--contained--success__Nb2OR",
          "czyButton--contained--black":
            "GamePageDesktop_czyButton--contained--black__0G_md",
          "czyButton--contained--green-gradient":
            "GamePageDesktop_czyButton--contained--green-gradient__VNxSU",
          "czyButton--contained--animated-green-gradient":
            "GamePageDesktop_czyButton--contained--animated-green-gradient__DXtQ1",
          "scroll-gradient": "GamePageDesktop_scroll-gradient__yD_GK",
          "czyButton--outlined--purple":
            "GamePageDesktop_czyButton--outlined--purple__DFWpc",
          "czyButton--link--purple":
            "GamePageDesktop_czyButton--link--purple___A_Rd",
          "czyButton--outlined--white":
            "GamePageDesktop_czyButton--outlined--white__d7zMQ",
          "czyButton--link--white":
            "GamePageDesktop_czyButton--link--white__kuYdH",
          "czyButton--outlined--grey":
            "GamePageDesktop_czyButton--outlined--grey__t_4M3",
          "czyButton--link--grey":
            "GamePageDesktop_czyButton--link--grey__jzD1X",
          "czyButton--outlined--warning":
            "GamePageDesktop_czyButton--outlined--warning__z1bhw",
          "czyButton--link--warning":
            "GamePageDesktop_czyButton--link--warning__8wdhP",
          "czyButton--outlined--alert":
            "GamePageDesktop_czyButton--outlined--alert__vsB7x",
          "czyButton--link--alert":
            "GamePageDesktop_czyButton--link--alert__vKYCk",
          "czyButton--outlined--success":
            "GamePageDesktop_czyButton--outlined--success__gZG4M",
          "czyButton--link--success":
            "GamePageDesktop_czyButton--link--success__JLVit",
          "czyButton--outlined": "GamePageDesktop_czyButton--outlined__FxhK7",
          "czyButton--disabled": "GamePageDesktop_czyButton--disabled__HBR8h",
          "czyButton--height50": "GamePageDesktop_czyButton--height50___asZ_",
          "czyButton--height34": "GamePageDesktop_czyButton--height34__Zf73G",
          "czyButton--height28": "GamePageDesktop_czyButton--height28__Qr_gH",
          "czyButton--fullWidth": "GamePageDesktop_czyButton--fullWidth__DfReJ",
          "czyButton--headerIcon":
            "GamePageDesktop_czyButton--headerIcon__zd9hv",
          "czyButton--headerIcon--desktop":
            "GamePageDesktop_czyButton--headerIcon--desktop__w3uVv",
          "czyButton--headerIcon--mobile":
            "GamePageDesktop_czyButton--headerIcon--mobile__vguLm",
          "czyButton--headerIcon--withLabel":
            "GamePageDesktop_czyButton--headerIcon--withLabel__TOaQ4",
          main: "GamePageDesktop_main__fSalE",
          mainContainer: "GamePageDesktop_mainContainer__QMRhB",
          gfContainer: "GamePageDesktop_gfContainer__ywzsh",
          gfAspectRatioContainer:
            "GamePageDesktop_gfAspectRatioContainer__f_hUp",
          leaderboardContainer: "GamePageDesktop_leaderboardContainer__Mmiky",
          leaderboard: "GamePageDesktop_leaderboard__ddMUk",
          gameInfoContainer: "GamePageDesktop_gameInfoContainer__SwKQu",
          dailyGamesSidebar: "GamePageDesktop_dailyGamesSidebar__5qHi4",
          showMoreIndicatorDesktop:
            "GamePageDesktop_showMoreIndicatorDesktop__ii_Z_",
          hidden: "GamePageDesktop_hidden__jtqKL",
          underGameContainerGrid:
            "GamePageDesktop_underGameContainerGrid__cdhNC",
          underGameContainerGamesWrapper:
            "GamePageDesktop_underGameContainerGamesWrapper__Rahgf",
          showMoreButton: "GamePageDesktop_showMoreButton__xWgfT",
          rightSidebar: "GamePageDesktop_rightSidebar__QgTMJ",
          rightMpuContainer: "GamePageDesktop_rightMpuContainer__tFXsw",
          rightGridContainer: "GamePageDesktop_rightGridContainer__qJUvH",
          scrollable: "GamePageDesktop_scrollable__SdiLU",
          isScrolling: "GamePageDesktop_isScrolling__v9jVS",
          showMoreButtonDesktop: "GamePageDesktop_showMoreButtonDesktop__nw_lD",
          playNextTitle: "GamePageDesktop_playNextTitle__mvetU",
        };
      },
      59458: (e, t, n) => {
        "use strict";
        (t._H = i),
          (t.uw = function (e, t) {
            switch (e) {
              case "gold":
                return t ? t._("common.leaderboard.rank.1st") : "1st";
              case "silver":
                return t ? t._("common.leaderboard.rank.2nd") : "2nd";
              case "bronze":
                return t ? t._("common.leaderboard.rank.3rd") : "3rd";
              case "level_4":
                return "Crazy";
              case "level_5":
                return "Master";
              case "level_6":
                return "Pro";
              default:
                return "Rookie";
            }
          }),
          (t.Vy = function (e) {
            switch (e) {
              case "gold":
                return "1";
              case "silver":
                return "2";
              case "bronze":
                return "3";
              case "level_4":
                return "1%";
              case "level_5":
                return "5%";
              case "level_6":
                return "10%";
              default:
                return "90%";
            }
          }),
          (t.lL = function (e, t) {
            if (!(0, a.isDefined)(e) || e < 1) return null;
            let n = Math.max(1, Math.floor(t || 0)),
              o = Math.max(1, Math.floor(e || 1)),
              s = Math.min(o, n),
              d = s !== o || n !== t,
              c = i(s, n),
              u = (function (e, t) {
                let n = r.BADGE_ORDER.indexOf(e);
                if (n <= 0) return null;
                let a = Math.max(1, Math.floor(t));
                for (let e = n - 1; e >= 0; e--) {
                  let t = r.BADGE_ORDER[e];
                  if (
                    "gold" === t ||
                    "silver" === t ||
                    "bronze" === t ||
                    l(t, a) > 3
                  )
                    return t;
                }
                return null;
              })(c, n),
              m = u ? l(u, n) : null,
              _ = null;
            if (u && null !== m) {
              let e = l(c, n),
                t = e - m;
              _ =
                t > 0
                  ? Math.floor(100 * Math.max(0, Math.min(1, (e - s) / t)))
                  : 100 * (s <= m);
            }
            return {
              currentBadge: c,
              nextBadge: u,
              nextBadgeMinRank: m,
              progressToNext: _,
              _clamped: d,
            };
          }),
          (t.ns = function (e) {
            let t = Math.max(1, Math.floor(e || 0));
            return {
              level_4: Math.ceil(t * r.PERCENT_THRESHOLDS.level_4),
              level_5: Math.ceil(t * r.PERCENT_THRESHOLDS.level_5),
              level_6: Math.ceil(t * r.PERCENT_THRESHOLDS.level_6),
            };
          });
        let a = n(8725),
          r = n(97429);
        function l(e, t) {
          return "gold" === e
            ? 1
            : "silver" === e
            ? 2
            : "bronze" === e
            ? 3
            : Math.ceil(Math.max(1, Math.floor(t)) * r.PERCENT_THRESHOLDS[e]);
        }
        function i(e, t) {
          let n = Math.max(1, Math.floor(t || 0)),
            a = Math.min(Math.max(1, Math.floor(e || 1)), n);
          return 1 === a
            ? "gold"
            : 2 === a
            ? "silver"
            : 3 === a
            ? "bronze"
            : a <= l("level_4", n)
            ? "level_4"
            : a <= l("level_5", n)
            ? "level_5"
            : a <= l("level_6", n)
            ? "level_6"
            : "default";
        }
      },
      63811: (e, t, n) => {
        "use strict";
        function a() {
          return {
            blurredVideo: null,
            original: null,
            portraitOriginal: null,
            portraitSizes: [],
            sizes: [],
          };
        }
        n.d(t, { R: () => a });
      },
      64258: (e, t, n) => {
        "use strict";
        n.d(t, { Pe: () => c, s9: () => d, tf: () => s, w1: () => o });
        var a = n(59458),
          r = n(98417),
          l = n(77502);
        let i = new Set(["bronze", "silver", "gold"]),
          o = (e) => i.has(e);
        function s(e, t) {
          var n, i, s, d;
          let c = (0, l.pn)(e.score);
          if (!(0, r.O)(c)) return null;
          let u = (0, a._H)(e.newRank, e.totalPlayers),
            m = "level_4" === u || o(u),
            _ = m ? null : e.scoreForNextBadge;
          return {
            score: c,
            countFromRank: e.oldRank ?? Math.max(e.totalPlayers, e.newRank),
            newRank: e.newRank,
            ranksUp: (0, r.O)(e.oldRank) ? e.oldRank - e.newRank : null,
            currentBadge: u,
            isLastDivision: m,
            topPercent: o((n = u))
              ? (0, a.Vy)("level_4")
              : (0, a.Vy)("default" === n ? null : n),
            nextDivisionScore: _,
            progress: (0, r.O)(_)
              ? ((i = c),
                (s = _),
                (d = t),
                s <= 0 || i <= 0
                  ? 0
                  : Math.min(1, Math.max(0, "ASC" === d ? s / i : i / s)))
              : null,
          };
        }
        function d(e) {
          return (
            !!(0, r.O)(e.oldRank) &&
            (0, a._H)(e.oldRank, e.totalPlayers) !==
              (0, a._H)(e.newRank, e.totalPlayers)
          );
        }
        function c(e, t) {
          return (0, r.O)(e) && t - e < 15e4;
        }
      },
      66036: (e, t, n) => {
        "use strict";
        n.d(t, { P: () => l, jK: () => o, ps: () => i, un: () => d });
        var a = n(87295),
          r = n(18262);
        let l = "data-game-player-src",
          i = "data-game-player-experiments",
          o = "data-game-player-hold-messages",
          s = `(function () {
  var w = window;
  if (w.__czyGamePlayerBoot) return;
  var GAME_ID = '${r.u}';
  var SRC_ATTRIBUTE = '${l}';
  var EXPERIMENTS_ATTRIBUTE = '${i}';
  var HOLD_MESSAGES_ATTRIBUTE = '${o}';
  var CLIENT_ONLY_PARAMS = ${JSON.stringify(a.N)};

  // Same rule as portal's getIsFirstSessionForGameFrame with getSessionCount.
  function isFirstSession() {
    var param = new URLSearchParams(location.search).get('isFirstSession');
    if (param === 'true') return true;
    if (param === 'false') return false;
    var stored = null;
    try { stored = localStorage.getItem('_sessionCount'); } catch (e) {}
    return (stored ? parseInt(stored) : 1) === 1;
  }

  // The browser-only parts of the URL: client-only query params and experiments, and the first session.
  function completeUrl(base, accepted) {
    var url = new URL(base);
    var pageParams = new URLSearchParams(location.search);
    CLIENT_ONLY_PARAMS.forEach(function (key) {
      if (pageParams.has(key)) url.searchParams.set(key, pageParams.get(key));
    });
    var experiments = w.czyExperiments || {};
    Object.keys(accepted).forEach(function (key) {
      var value = experiments[key];
      var values = accepted[key];
      if (typeof value === 'string' && value !== '' && !url.searchParams.has(key) && (values === null || values.indexOf(value) !== -1)) {
        url.searchParams.set(key, value);
      }
    });
    if (!url.searchParams.has('isFirstSession') && isFirstSession()) {
      url.searchParams.set('isFirstSession', 'true');
    }
    return url.toString();
  }

  function boot() {
    var frame = document.getElementById(GAME_ID);
    var existing = w.__czyGamePlayer;
    if (existing) {
      if (existing.frame === frame) return existing;
      existing.dispose();
    }
    if (!frame || !frame.getAttribute(SRC_ATTRIBUTE)) return null;
    var accepted = {};
    try { accepted = JSON.parse(frame.getAttribute(EXPERIMENTS_ATTRIBUTE) || '{}'); } catch (e) {}

    var player = {
      frame: frame,
      srcSetAt: null,
      loadedAt: null,
      listener: null,
      disposeTimer: null,
      held: frame.hasAttribute(HOLD_MESSAGES_ATTRIBUTE) ? [] : null,
      // Called with 'srcSet' or 'loaded', and immediately for whatever already happened.
      attach: function (listener) {
        clearTimeout(player.disposeTimer);
        player.listener = listener;
        if (player.srcSetAt !== null) listener('srcSet');
        if (player.loadedAt !== null) listener('loaded');
      },
      // Hands the held messages to portal's listeners, in order and as if just received, then lets new ones through.
      drain: function () {
        var held = player.held;
        if (!held) return;
        player.held = null;
        w.removeEventListener('message', hold, true);
        held.forEach(function (m) {
          var data = m.data;
          if (data.event === 'gameLoaded' && data.loadedAt == null) {
            data = Object.assign({}, data, { loadedAt: Math.round(performance.timeOrigin + m.at) });
          }
          w.dispatchEvent(new MessageEvent('message', { data: data, origin: m.origin, source: m.source }));
        });
      },
      // Deferred, so an immediate remount (React StrictMode) keeps the running game.
      release: function () {
        player.listener = null;
        player.disposeTimer = setTimeout(player.dispose, 0);
      },
      dispose: function () {
        clearTimeout(player.disposeTimer);
        player.listener = null;
        player.held = null;
        frame.removeEventListener('load', onLoad);
        w.removeEventListener('message', hold, true);
        if (w.__czyGamePlayer === player) delete w.__czyGamePlayer;
      },
    };
    w.__czyGamePlayer = player;

    // The gameframe sends some messages once only; before portal hydrates nothing would hear them.
    function hold(event) {
      if (!player.held || event.source !== frame.contentWindow || !event.data || event.data.type !== 'GFEvent') return;
      event.stopImmediatePropagation();
      player.held.push({ data: event.data, origin: event.origin, source: event.source, at: performance.now() });
    }
    if (player.held) w.addEventListener('message', hold, true);

    function onLoad() {
      if (player.srcSetAt === null || player.loadedAt !== null) return;
      // While the HTML is parsed, the frame's initial about:blank load can still arrive after src is set.
      // The game is cross-origin, so reading its location throws.
      try {
        if (frame.contentWindow.location.href === 'about:blank') return;
      } catch (e) {}
      player.loadedAt = performance.now();
      if (player.listener) player.listener('loaded');
    }
    frame.addEventListener('load', onLoad);

    // Chrome drops a src set in the same task the parser inserted the iframe, so it is set one task later.
    setTimeout(function () {
      if (w.__czyGamePlayer !== player) return;
      frame.src = completeUrl(frame.getAttribute(SRC_ATTRIBUTE), accepted);
      player.srcSetAt = performance.now();
      if (player.listener) player.listener('srcSet');
    }, 0);
    return player;
  }

  w.__czyGamePlayerBoot = boot;

  if (document.readyState === 'loading') {
    var observer = new MutationObserver(function () {
      if (document.getElementById(GAME_ID)) {
        observer.disconnect();
        boot();
      }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    document.addEventListener('DOMContentLoaded', function () { observer.disconnect(); });
  }
})();`;
        function d() {
          if (!window.__czyGamePlayerBoot) {
            let e = document.createElement("script");
            (e.text = s), document.head.appendChild(e), e.remove();
          }
          return window.__czyGamePlayerBoot?.() ?? null;
        }
      },
      70642: (e, t, n) => {
        "use strict";
        n.r(t), n.d(t, { default: () => tf });
        var a = n(6029),
          r = n(75155),
          l = n(55729),
          i = n(18019),
          o = n(98417),
          s = n(79942),
          d = n(71024),
          c = n.n(d),
          u = n(63811),
          m = n(81631),
          _ = n(52461),
          g = n(65889),
          h = n(54596),
          y = n(96834),
          p = n(67988),
          f = n(13184),
          v = n(50212),
          b = n(14886),
          w = n(71684),
          z = n(81930),
          A = n(78339),
          x = n.n(A);
        let B = (e) => {
          let t,
            n,
            l,
            i,
            o,
            d,
            c,
            u,
            m = (0, r.c)(18),
            { width: _, height: g } = e;
          m[0] === Symbol.for("react.memo_cache_sentinel")
            ? ((t = (0, z.Ay)("chestfrown.svg")), (m[0] = t))
            : (t = m[0]);
          let h = t,
            y = _ && g ? _ / g : 1,
            p = (0, s.uB)();
          m[1] !== p
            ? ((n = p._("game.adUnitPlaceholder.title")),
              (m[1] = p),
              (m[2] = n))
            : (n = m[2]);
          let f = n,
            b = f.length > 46 ? 15 : 20,
            w = y > 2 && x().wide;
          m[3] !== w
            ? ((l = (0, v.A)(x().adUnitPlaceholder, w)), (m[3] = w), (m[4] = l))
            : (l = m[4]),
            m[5] !== g || m[6] !== _
              ? ((i = { width: _, height: g }),
                (m[5] = g),
                (m[6] = _),
                (m[7] = i))
              : (i = m[7]),
            m[8] === Symbol.for("react.memo_cache_sentinel")
              ? ((o = (0, a.jsx)("img", { alt: "Adblock detected", src: h })),
                (m[8] = o))
              : (o = m[8]);
          let A = x()[`fontSize${b}`];
          return (
            m[9] !== A
              ? ((d = (0, v.A)(x().placeholderTitle, A)),
                (m[9] = A),
                (m[10] = d))
              : (d = m[10]),
            m[11] !== d || m[12] !== f
              ? ((c = (0, a.jsx)("div", { className: d, children: f })),
                (m[11] = d),
                (m[12] = f),
                (m[13] = c))
              : (c = m[13]),
            m[14] !== l || m[15] !== i || m[16] !== c
              ? ((u = (0, a.jsxs)("div", {
                  className: l,
                  style: i,
                  children: [o, c],
                })),
                (m[14] = l),
                (m[15] = i),
                (m[16] = c),
                (m[17] = u))
              : (u = m[17]),
            u
          );
        };
        var S = n(89147),
          k = n(57802),
          D = n(35081),
          P = n.n(D);
        let j = c()(() => n.e(49378).then(n.bind(n, 49378)), {
            loadableGenerated: { webpack: () => [49378] },
            loading: () => null,
            ssr: !1,
          }),
          E = c()(() => n.e(16790).then(n.bind(n, 16790)), {
            loadableGenerated: { webpack: () => [16790] },
            loading: () => null,
            ssr: !1,
          }),
          C = {
            [i.R.LeaderboardBelowGameRefresh]: "ad-unit-leaderboard",
            [i.R.RightMpuRefresh]: "ad-unit-right-mpu",
            [i.R.SecondLeaderboardBelowGameRefresh]:
              "ad-unit-second-leaderboard",
            [i.R.SecondMpuBelowGameRefresh]: "ad-unit-second-mpu",
          },
          U = (e) => {
            let t,
              n,
              i,
              d,
              c,
              u,
              m,
              _,
              g,
              h,
              y,
              p,
              f,
              z,
              A = (0, r.c)(49),
              {
                id: x,
                width: D,
                height: U,
                align: G,
                className: R,
                customLabelStyle: N,
                customPaperStyle: L,
                customAdWrapperStyle: T,
                verticalLabel: I,
                addAdBlockWarning: M,
              } = e,
              F = void 0 === R ? "" : R,
              [O, W] = l.useState(null),
              { user: H, loadingUser: K } = l.useContext(b.R),
              { addAdUnit: $, removeAdUnit: Q } = l.useContext(k.g),
              V = l.useRef(null),
              { analyticsService: q } = l.useContext(w.A).services,
              Y = q.getHasAdblock(),
              [X, J] = l.useState(null);
            A[0] !== K || A[1] !== H
              ? ((t = () => {
                  K || J(Math.floor(Math.random() * ((0, o.O)(H) ? 1 : 2)) + 1);
                }),
                (n = [H, K]),
                (A[0] = K),
                (A[1] = H),
                (A[2] = t),
                (A[3] = n))
              : ((t = A[2]), (n = A[3])),
              l.useEffect(t, n),
              A[4] !== $ || A[5] !== x || A[6] !== Q
                ? ((i = () => {
                    let e = !0,
                      t = {
                        id: x,
                        onRender: (t) => {
                          e && W(!t);
                        },
                      };
                    $(t);
                    let n = V.current;
                    return function () {
                      (e = !1), Q(t, n);
                    };
                  }),
                  (d = [x, $, Q]),
                  (A[4] = $),
                  (A[5] = x),
                  (A[6] = Q),
                  (A[7] = i),
                  (A[8] = d))
                : ((i = A[7]), (d = A[8])),
              l.useEffect(i, d);
            let Z = G || "center",
              ee = `${D}px`,
              et = `${U}px`;
            A[9] !== Z || A[10] !== ee || A[11] !== et
              ? ((c = {
                  "--ad-unit-width": ee,
                  "--ad-unit-height": et,
                  "--ad-unit-text-align": Z,
                }),
                (A[9] = Z),
                (A[10] = ee),
                (A[11] = et),
                (A[12] = c))
              : (c = A[12]);
            let en = c;
            A[13] !== U || A[14] !== D
              ? ((u = (e) => {
                  switch (e) {
                    case 1:
                    default:
                      return (0, a.jsx)(j, { width: D, height: U });
                    case 2:
                      return (0, a.jsx)(E, { width: D, height: U });
                  }
                }),
                (A[13] = U),
                (A[14] = D),
                (A[15] = u))
              : (u = A[15]);
            let ea = u,
              er = M && Y && !1 === O,
              el = (0, S.z)(x) && !1 === O && !er && null !== X,
              ei = !el && !er && O;
            A[16] !== F
              ? ((m = (0, v.A)(P().adUnitRoot, F)), (A[16] = F), (A[17] = m))
              : (m = A[17]);
            let eo = C[x];
            A[18] !== N || A[19] !== ei || A[20] !== I
              ? ((_ =
                  ei &&
                  (0, a.jsx)("div", {
                    className: (0, v.A)(P().label, I && P().labelVertical),
                    style: N,
                    children: (0, a.jsx)(s.x6, {
                      id: "common.advertisement.label",
                    }),
                  })),
                (A[18] = N),
                (A[19] = ei),
                (A[20] = I),
                (A[21] = _))
              : (_ = A[21]);
            let es = P(),
              ed = P(),
              ec = (0, v.A)(
                P().adSlot,
                O
                  ? (0, v.A)(P().adWrapper, M && Y && P().adBlockWarning)
                  : P().alternativeAdWrapper
              ),
              eu = O ? T : void 0;
            return (
              A[22] !== x || A[23] !== ec || A[24] !== eu
                ? ((g = (0, a.jsx)("div", {
                    className: ec,
                    ref: V,
                    id: x,
                    style: eu,
                  })),
                  (A[22] = x),
                  (A[23] = ec),
                  (A[24] = eu),
                  (A[25] = g))
                : (g = A[25]),
              A[26] !== U || A[27] !== er || A[28] !== D
                ? ((h = er && (0, a.jsx)(B, { width: D, height: U })),
                  (A[26] = U),
                  (A[27] = er),
                  (A[28] = D),
                  (A[29] = h))
                : (h = A[29]),
              A[30] !== X || A[31] !== ea || A[32] !== el
                ? ((y = el && ea(X)),
                  (A[30] = X),
                  (A[31] = ea),
                  (A[32] = el),
                  (A[33] = y))
                : (y = A[33]),
              A[34] !== ed.innerWrapper ||
              A[35] !== g ||
              A[36] !== h ||
              A[37] !== y
                ? ((p = (0, a.jsxs)("div", {
                    className: ed.innerWrapper,
                    children: [g, h, y],
                  })),
                  (A[34] = ed.innerWrapper),
                  (A[35] = g),
                  (A[36] = h),
                  (A[37] = y),
                  (A[38] = p))
                : (p = A[38]),
              A[39] !== L || A[40] !== es.adUnitPaper || A[41] !== p
                ? ((f = (0, a.jsx)("div", {
                    className: es.adUnitPaper,
                    style: L,
                    children: p,
                  })),
                  (A[39] = L),
                  (A[40] = es.adUnitPaper),
                  (A[41] = p),
                  (A[42] = f))
                : (f = A[42]),
              A[43] !== en ||
              A[44] !== m ||
              A[45] !== eo ||
              A[46] !== _ ||
              A[47] !== f
                ? ((z = (0, a.jsxs)("div", {
                    className: m,
                    style: en,
                    "data-testid": eo,
                    children: [_, f],
                  })),
                  (A[43] = en),
                  (A[44] = m),
                  (A[45] = eo),
                  (A[46] = _),
                  (A[47] = f),
                  (A[48] = z))
                : (z = A[48]),
              z
            );
          },
          G = (e) => {
            let t,
              n,
              l,
              i = (0, r.c)(7),
              { breakpoints: o } = (0, p.D)();
            i[0] !== o
              ? ((t = o.up("gp_x6")), (i[0] = o), (i[1] = t))
              : (t = i[1]);
            let s = (0, f.A)(t) ? -3 : -10;
            return (
              i[2] !== s
                ? ((n = { bottom: s, left: 5, transform: "none" }),
                  (i[2] = s),
                  (i[3] = n))
                : (n = i[3]),
              i[4] !== e || i[5] !== n
                ? ((l = (0, a.jsx)(U, {
                    width: 728,
                    height: 90,
                    align: "left",
                    customLabelStyle: n,
                    verticalLabel: !0,
                    ...e,
                  })),
                  (i[4] = e),
                  (i[5] = n),
                  (i[6] = l))
                : (l = i[6]),
              l
            );
          },
          R = (e) => {
            let t,
              n = (0, r.c)(2),
              { game: l, children: i } = e;
            return "UNAVAILABLE" === l.status
              ? null
              : (n[0] !== i
                  ? ((t = (0, a.jsx)(a.Fragment, { children: i })),
                    (n[0] = i),
                    (n[1] = t))
                  : (t = n[1]),
                t);
          };
        var N = n(90135),
          L = n(84040);
        let T = (e) => {
          let t,
            n,
            l = (0, r.c)(3);
          return (
            l[0] === Symbol.for("react.memo_cache_sentinel")
              ? ((t = { right: 355, top: -3 }), (l[0] = t))
              : (t = l[0]),
            l[1] !== e
              ? ((n = (0, a.jsx)(U, {
                  id: i.R.SecondMpuBelowGameRefresh,
                  width: 300,
                  height: 250,
                  customLabelStyle: t,
                  ...e,
                })),
                (l[1] = e),
                (l[2] = n))
              : (n = l[2]),
            n
          );
        };
        var I = n(55678),
          M = n(62879),
          F = n(87222),
          O = n(82245),
          W = n(52359),
          H = n(49188),
          K = n.n(H);
        let $ = (e) => {
          let t,
            n,
            l,
            o,
            s,
            d,
            c,
            u,
            m,
            _,
            g,
            h,
            p,
            f,
            b = (0, r.c)(33),
            { game: w } = e,
            {
              gamesInSeries: z,
              appStoreUrl: A,
              playStoreUrl: x,
              steamStoreUrl: B,
              msnStoreUrl: S,
            } = w;
          b[0] !== w.category
            ? ((t = w.category ? { ...w.category, isCategory: !0 } : void 0),
              (b[0] = w.category),
              (b[1] = t))
            : (t = b[1]);
          let k = t,
            D = !!A || !!x || !!B || !!S,
            P = z && z.length > 0;
          return (
            b[2] === Symbol.for("react.memo_cache_sentinel")
              ? ((n = (0, v.A)(K().gameInfo, K().isDesktop)), (b[2] = n))
              : (n = b[2]),
            b[3] === Symbol.for("react.memo_cache_sentinel")
              ? ((l = (0, a.jsx)(G, {
                  id: i.R.SecondLeaderboardBelowGameRefresh,
                  verticalLabel: !0,
                  addAdBlockWarning: !0,
                  customLabelStyle: {
                    left: -14,
                    top: 75,
                    transformOrigin: "left",
                  },
                  customAdWrapperStyle: {
                    boxShadow: `inset 0px 0px 0px 1px ${y.l.black[60]}`,
                    background: "rgba(71, 73, 103, 0.10)",
                  },
                })),
                (b[3] = l))
              : (l = b[3]),
            b[4] !== w
              ? ((o = (0, a.jsx)("div", {
                  className: K().leaderboard,
                  children: (0, a.jsx)(R, { game: w, children: l }),
                })),
                (b[4] = w),
                (b[5] = o))
              : (o = b[5]),
            b[6] !== w
              ? ((s = (0, a.jsx)(O.A, { game: w })), (b[6] = w), (b[7] = s))
              : (s = b[7]),
            b[8] !== k || b[9] !== w.tags
              ? ((d = (0, a.jsx)(I.A, {
                  tags: k ? [k, ...w.tags] : [...w.tags],
                  dataTestId: "game-tags",
                })),
                (b[8] = k),
                (b[9] = w.tags),
                (b[10] = d))
              : (d = b[10]),
            b[11] !== s || b[12] !== d
              ? ((c = (0, a.jsxs)("div", {
                  className: K().gameInfoTopSection,
                  children: [s, d],
                })),
                (b[11] = s),
                (b[12] = d),
                (b[13] = c))
              : (c = b[13]),
            b[14] !== o || b[15] !== c
              ? ((u = (0, a.jsxs)("div", {
                  className: K().leftColumn,
                  children: [o, c],
                })),
                (b[14] = o),
                (b[15] = c),
                (b[16] = u))
              : (u = b[16]),
            b[17] === Symbol.for("react.memo_cache_sentinel")
              ? ((m = (0, a.jsx)(T, {
                  customLabelStyle: {
                    height: 0,
                    transform: "translate(0,250px)",
                  },
                  customAdWrapperStyle: {
                    boxShadow: `inset 0px 0px 0px 1px ${y.l.black[60]}`,
                    background: "rgba(71, 73, 103, 0.10)",
                  },
                })),
                (b[17] = m))
              : (m = b[17]),
            b[18] !== w
              ? ((_ = (0, a.jsx)("div", {
                  className: K().rightColumn,
                  children: (0, a.jsx)(R, { game: w, children: m }),
                })),
                (b[18] = w),
                (b[19] = _))
              : (_ = b[19]),
            b[20] !== _ || b[21] !== u
              ? ((g = (0, a.jsxs)("div", {
                  className: K().top,
                  children: [u, _],
                })),
                (b[20] = _),
                (b[21] = u),
                (b[22] = g))
              : (g = b[22]),
            b[23] !== w
              ? ((h = (0, a.jsx)("div", {
                  className: K().roundedCornersContainer,
                  children: (0, a.jsx)(M.A, { game: w }),
                })),
                (b[23] = w),
                (b[24] = h))
              : (h = b[24]),
            b[25] !== w || b[26] !== P || b[27] !== D
              ? ((p =
                  P || D
                    ? (0, a.jsxs)("div", {
                        className: (0, v.A)(
                          K().roundedCornersContainer,
                          K().removeTopPadding
                        ),
                        children: [
                          P && (0, a.jsx)(W.A, { game: w }),
                          D && (0, a.jsx)(F.A, { game: w }),
                        ],
                      })
                    : null),
                (b[25] = w),
                (b[26] = P),
                (b[27] = D),
                (b[28] = p))
              : (p = b[28]),
            b[29] !== g || b[30] !== h || b[31] !== p
              ? ((f = (0, a.jsx)(a.Fragment, {
                  children: (0, a.jsxs)("div", {
                    className: n,
                    children: [g, h, p],
                  }),
                })),
                (b[29] = g),
                (b[30] = h),
                (b[31] = p),
                (b[32] = f))
              : (f = b[32]),
            f
          );
        };
        var Q = n(78718),
          V = n(18262);
        function q(e, t) {
          return e === t
            ? "game"
            : null === e ||
              e === document.body ||
              e === document.documentElement
            ? "page"
            : "other";
        }
        let Y = "focusStealAttempt";
        function X(e, t) {
          let n = e;
          for (; n; ) {
            if ("IFRAME" === n.tagName && n.id.includes(t)) return !0;
            n = n.parentElement;
          }
          return !1;
        }
        let J = () => (
          l.useEffect(() => {
            let e = null;
            function t(t) {
              t.target && "focus" in t.target && (e = t.target);
            }
            function n(t) {
              setTimeout(() => {
                if (X(document.activeElement, V.u)) {
                  e = (0, V.y)();
                  return;
                }
                if (X(document.activeElement, "google_ads_iframe")) {
                  let t = e ?? (0, V.y)();
                  t && t.focus();
                  return;
                }
                e =
                  t.relatedTarget && "focus" in t.relatedTarget
                    ? t.relatedTarget
                    : null;
              });
            }
            let a = !1,
              r = 0;
            function l() {
              r = Date.now();
            }
            document.addEventListener("focus", t, !0),
              document.addEventListener("blur", n, !0),
              document.addEventListener("pointerdown", l, !0),
              document.addEventListener("keydown", l, !0);
            let i = null;
            return (
              (i = window.setInterval(() => {
                let e = (0, V.y)();
                if (e) {
                  var t, n, l;
                  let i = document.activeElement;
                  i?.id?.includes("google_ads_iframe") &&
                    e.contentWindow?.postMessage({ type: Y }, "*");
                  let o = q(i, e);
                  (t = a),
                    (n = document.hasFocus()),
                    (l = Date.now() - r),
                    t &&
                      "page" === o &&
                      n &&
                      l > 200 &&
                      (e.focus(),
                      e.contentWindow?.postMessage({ type: Y }, "*")),
                    (a = "game" === q(document.activeElement, e));
                }
              }, 32)),
              function () {
                i && window.clearInterval(i),
                  document.removeEventListener("focus", t, !0),
                  document.removeEventListener("blur", n, !0),
                  document.removeEventListener("pointerdown", l, !0),
                  document.removeEventListener("keydown", l, !0);
              }
            );
          }, []),
          null
        );
        var Z = n(27096),
          ee = n(89964),
          et = n(28528),
          en = n(7842),
          ea = n(81278),
          er = n(60574),
          el = n(51579),
          ei = n(75403),
          eo = n(45018),
          es = n(60362),
          ed = n(71855),
          ec = n(50190),
          eu = n(34302),
          em = n(47883),
          e_ = n(87295),
          eg = n(93389),
          eh = n(68406),
          ey = n(4230),
          ep = n(45364),
          ef = n(50113),
          ev = n(28478),
          eb = n(15325),
          ew = n(77257),
          ez = n(64258);
        let eA = (e) => `rankProgressOverlayShownAt_${e}`,
          ex = c()(
            () =>
              Promise.all([n.e(73940), n.e(11119), n.e(87808)]).then(
                n.bind(n, 87808)
              ),
            {
              loadableGenerated: { webpack: () => [87808] },
              loading: () => null,
              ssr: !1,
            }
          ),
          eB = (e) => {
            let t,
              n,
              i = (0, r.c)(9),
              { game: s, onClose: d } = e,
              {
                view: c,
                neighbours: u,
                close: m,
              } = (function (e) {
                let t,
                  n,
                  a,
                  i,
                  s,
                  d,
                  c,
                  u = (0, r.c)(22),
                  m =
                    "enabled" ===
                    (0, ed.U)("czyExpClientLbRankProgress_CZY_21923"),
                  { services: _ } = l.useContext(w.A),
                  [g, h] = l.useState(null),
                  y = e.leaderboardOptions?.scoreSorting,
                  p = e.isPreview ?? !1;
                u[0] !== m ||
                u[1] !== e.id ||
                u[2] !== _.crazyAnalyticsService ||
                u[3] !== y
                  ? ((t = () => {
                      if (m && y)
                        return (0, ew.m)((t) => {
                          var n;
                          let a,
                            r = Date.now();
                          if (
                            t.gameId !== e.id ||
                            (!(0, ez.s9)(t) &&
                              (0, ez.Pe)(
                                ((n = t.gameId),
                                Number.isFinite(
                                  (a = Number(
                                    ev.A.SessionStorage.getItem(eA(n))
                                  ))
                                ) && a > 0
                                  ? a
                                  : null),
                                r
                              ))
                          )
                            return;
                          let l = (0, ez.tf)(t, y);
                          l &&
                            (ev.A.SessionStorage.setItem(
                              eA(t.gameId),
                              String(r)
                            ),
                            _.crazyAnalyticsService.leaderboardEvent(
                              "gamepage",
                              "rankprogressviewed",
                              {
                                score: {
                                  value: l.score,
                                  globalRank: l.newRank,
                                  countryRank: null,
                                  friendsRank: null,
                                },
                              }
                            ),
                            h(l));
                        });
                    }),
                    (n = [m, y, e.id, _.crazyAnalyticsService]),
                    (u[0] = m),
                    (u[1] = e.id),
                    (u[2] = _.crazyAnalyticsService),
                    (u[3] = y),
                    (u[4] = t),
                    (u[5] = n))
                  : ((t = u[4]), (n = u[5])),
                  l.useEffect(t, n),
                  u[6] !== e.id || u[7] !== p
                    ? ((a = { gameId: e.id, isPreview: p }),
                      (u[6] = e.id),
                      (u[7] = p),
                      (u[8] = a))
                    : (a = u[8]);
                let f = !g?.isLastDivision;
                u[9] !== a || u[10] !== f
                  ? ((i = { variables: a, fetchPolicy: "no-cache", skip: f }),
                    (u[9] = a),
                    (u[10] = f),
                    (u[11] = i))
                  : (i = u[11]);
                let { data: v, error: b } = (0, ef.IT)(eb.Pf, i);
                u[12] !== v?.me?.globalLeaderboardNeighbourhood ||
                u[13] !== b ||
                u[14] !== g?.isLastDivision
                  ? ((s = g?.isLastDivision
                      ? b
                        ? []
                        : v?.me?.globalLeaderboardNeighbourhood?.filter(o.O) ??
                          null
                      : null),
                    (u[12] = v?.me?.globalLeaderboardNeighbourhood),
                    (u[13] = b),
                    (u[14] = g?.isLastDivision),
                    (u[15] = s))
                  : (s = u[15]);
                let z = s;
                u[16] !== _.crazyAnalyticsService
                  ? ((d = () => {
                      _.crazyAnalyticsService.leaderboardEvent(
                        "gamepage",
                        "rankprogressclosed"
                      ),
                        h(null);
                    }),
                    (u[16] = _.crazyAnalyticsService),
                    (u[17] = d))
                  : (d = u[17]);
                let A = d;
                return (
                  u[18] !== A || u[19] !== z || u[20] !== g
                    ? ((c = { view: g, neighbours: z, close: A }),
                      (u[18] = A),
                      (u[19] = z),
                      (u[20] = g),
                      (u[21] = c))
                    : (c = u[21]),
                  c
                );
              })(s),
              _ = s.leaderboardOptions?.scoreLabel;
            i[0] !== m || i[1] !== d
              ? ((t = () => {
                  m(), d();
                }),
                (i[0] = m),
                (i[1] = d),
                (i[2] = t))
              : (t = i[2]);
            let g = t;
            if (!c || !_) return null;
            let h = `${c.newRank}-${c.score}`;
            return (
              i[3] !== g || i[4] !== u || i[5] !== _ || i[6] !== h || i[7] !== c
                ? ((n = (0, a.jsx)(
                    ex,
                    { view: c, scoreLabel: _, neighbours: u, onClose: g },
                    h
                  )),
                  (i[3] = g),
                  (i[4] = u),
                  (i[5] = _),
                  (i[6] = h),
                  (i[7] = c),
                  (i[8] = n))
                : (n = i[8]),
              n
            );
          };
        var eS = n(16472),
          ek = n(88748),
          eD = n(51196),
          eP = n(41645),
          ej = n(66036),
          eE = n(28967),
          eC = n(52268),
          eU = n(26165),
          eG = n(94448),
          eR = n(16316),
          eN = n(41136),
          eL = n(29457);
        let eT = {
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            overflow: "hidden",
          },
          eI = {
            width: "100%",
            height: "100%",
            transformOrigin: "0 0",
            transform: "none",
          };
        var eM = n(3495),
          eF = n.n(eM);
        let eO = (e) => {
          let t,
            n,
            i,
            o,
            s,
            d,
            c,
            u,
            m,
            _,
            g,
            h,
            y,
            p,
            f,
            b,
            z,
            A,
            x,
            B,
            S,
            k,
            D,
            P,
            j,
            E,
            C,
            U,
            G,
            R,
            N,
            L,
            T,
            I,
            M,
            F,
            O = (0, r.c)(83),
            { game: W, waitForQATool: H, serverRendered: K } = e,
            $ = void 0 !== K && K,
            { arm: q, artworkId: Y, artworkExperimentId: X } = (0, em.F)(W),
            J = l.useRef(null),
            Z = l.useRef(null),
            ef = l.useRef(null),
            ev = l.useRef(!1),
            eb = (0, ec.A)(),
            [ew, ez] = l.useState(!1),
            eA = ew
              ? "disabled"
              : $ || (eb && !(void 0 !== H && H))
              ? "enabled"
              : "loading",
            ex = "enabled" === eA;
          O[0] !== X || O[1] !== Y || O[2] !== W.id || O[3] !== ex
            ? ((t = {
                gameId: W.id,
                artworkId: Y,
                artworkExperimentId: X,
                enabled: ex,
              }),
              (O[0] = X),
              (O[1] = Y),
              (O[2] = W.id),
              (O[3] = ex),
              (O[4] = t))
            : (t = O[4]),
            (0, eu.A)(t);
          let { routeHelper: eM } = l.useContext(eg.A),
            { pageUrlHelper: eO } = l.useContext(eD.e),
            { services: e$ } = l.useContext(w.A),
            eQ = l.useContext(ey.A),
            eV = (0, eh.E)(),
            eq =
              "enabled" ===
              (0, ed.U)("czyExpClientHappyTimeFullscreen_CZY_21067"),
            eY = l.useContext(es.H);
          O[5] !== q ||
          O[6] !== eQ ||
          O[7] !== eY ||
          O[8] !== W ||
          O[9] !== eO ||
          O[10] !== eM ||
          O[11] !== e$.crazyAnalyticsService
            ? ((n = (e, t) => {
                let n = void 0 !== t && t,
                  a = e$.crazyAnalyticsService.getSessionCount(),
                  r = !n && (0, eU.d)(eO.routeData.query?.isFirstSession, a),
                  l = eO.getPreviewBuildId(),
                  i = eM.gameIframeUrl(
                    W.desktopUrl,
                    {
                      ...(n
                        ? eO.filteredQueryParams()
                        : eO.queryParamsForGameframe()),
                      ...(r && { isFirstSession: r }),
                      ...(W.isPreview && { isPreview: !0 }),
                      ...(W.isPreview && l && { gameBuildId: l }),
                      ...("variant" === q && { [e_.mt]: q }),
                      ...((0, eo.j)(W, eQ, eO) && { [et._]: "true" }),
                      ...(void 0 === e ? {} : e),
                    },
                    eY,
                    n ? {} : { ...(0, er.jU)() }
                  );
                return W.isPreview ? (0, ek.qP)(i, (0, ek.P4)()) : i;
              }),
              (O[5] = q),
              (O[6] = eQ),
              (O[7] = eY),
              (O[8] = W),
              (O[9] = eO),
              (O[10] = eM),
              (O[11] = e$.crazyAnalyticsService),
              (O[12] = n))
            : (n = O[12]);
          let eX = n;
          O[13] !== eX
            ? ((i = (e) => {
                let { query: t } = e;
                Z.current && (Z.current.src = eX(t ?? {}));
              }),
              (O[13] = eX),
              (O[14] = i))
            : (i = O[14]);
          let eJ = i,
            eZ = l.useRef(eJ),
            e0 = l.useRef(eX);
          O[15] !== eX || O[16] !== eJ
            ? ((o = () => {
                (eZ.current = eJ), (e0.current = eX);
              }),
              (O[15] = eX),
              (O[16] = eJ),
              (O[17] = o))
            : (o = O[17]),
            l.useEffect(o),
            O[18] === Symbol.for("react.memo_cache_sentinel")
              ? ((s = () => (0, eN.o)((e) => eZ.current(e))),
                (d = []),
                (O[18] = s),
                (O[19] = d))
              : ((s = O[18]), (d = O[19])),
            l.useEffect(s, d),
            O[20] !== eX || O[21] !== $
              ? ((c = () =>
                  $
                    ? {
                        url: eX({}, !0),
                        experiments: JSON.stringify((0, eP.Lz)()),
                      }
                    : null),
                (O[20] = eX),
                (O[21] = $),
                (O[22] = c))
              : (c = O[22]);
          let [e1] = l.useState(c);
          O[23] !== $ || O[24] !== e$.crazyAnalyticsService
            ? ((u = () => {
                if (!$) return;
                let e = (0, ej.un)();
                if (!e) return;
                e.attach(eW);
                let t = window.setTimeout(() => {
                  e.drain();
                  let t = Z.current?.getAttribute("src"),
                    n = t ? (0, eP.KG)(t, e0.current()) : [];
                  n.length > 0 &&
                    e$.crazyAnalyticsService.trackGenericError(
                      "gameframeSsrSrcMismatch",
                      { keys: n }
                    );
                }, 0);
                return () => {
                  clearTimeout(t), e.release();
                };
              }),
              (O[23] = $),
              (O[24] = e$.crazyAnalyticsService),
              (O[25] = u))
            : (u = O[25]),
            O[26] !== $ || O[27] !== e$
              ? ((m = [$, e$]), (O[26] = $), (O[27] = e$), (O[28] = m))
              : (m = O[28]),
            l.useEffect(u, m);
          let { wrapperStyle: e2, iframeStyle: e3 } = (function (e) {
            let [t, n] = l.useState(eI);
            return (
              l.useEffect(() => {
                let t = e.current;
                if (!t) return;
                let a = () => {
                  let e = t.clientWidth,
                    a = t.clientHeight,
                    r = a <= 0 ? 1 : Math.max(1, a / 2160);
                  r <= 1
                    ? n(eI)
                    : n({
                        width: `${Math.ceil(e / r)}px`,
                        height: `${Math.ceil(a / r)}px`,
                        transformOrigin: "0 0",
                        transform: `scale(${r})`,
                      });
                };
                a();
                let r = new ResizeObserver(a);
                r.observe(t);
                let l = ["fullscreenchange", "webkitfullscreenchange"];
                return (
                  l.forEach((e) => document.addEventListener(e, a)),
                  () => {
                    r.disconnect(),
                      l.forEach((e) => document.removeEventListener(e, a));
                  }
                );
              }, [e]),
              { wrapperStyle: eT, iframeStyle: t }
            );
          })(ef);
          O[29] === Symbol.for("react.memo_cache_sentinel")
            ? ((_ = () => {
                let e = Z.current;
                e &&
                  !document.hidden &&
                  setTimeout(() => {
                    window.focus(),
                      e.focus(),
                      e.contentWindow?.focus(),
                      e.contentWindow?.postMessage(
                        { type: "focusStealAttempt" },
                        "*"
                      );
                  }, 0);
              }),
              (O[29] = _))
            : (_ = O[29]);
          let e4 = _;
          return (
            O[30] === Symbol.for("react.memo_cache_sentinel")
              ? ((g = () => {
                  let e = (e) => {
                    let t = new URL(e, window.location.href);
                    window.location.pathname !== t.pathname && ez(!0);
                  };
                  return (
                    ea.Router.events.on("routeChangeStart", e),
                    function () {
                      ea.Router.events.off("routeChangeStart", e);
                    }
                  );
                }),
                (h = []),
                (O[30] = g),
                (O[31] = h))
              : ((g = O[30]), (h = O[31])),
            l.useEffect(g, h),
            O[32] !== eQ ||
            O[33] !== W.desktopUrl ||
            O[34] !== eq ||
            O[35] !== eV ||
            O[36] !== eM
              ? ((y = () => {
                  let e = (e) => {
                    let t;
                    if (!e.data || e.data.type !== ee.x || !e.origin) return;
                    try {
                      t = new URL(e.origin);
                    } catch {
                      return;
                    }
                    let n = eM.isMessageFromGameframe(e, W.desktopUrl),
                      a = t.hostname === window.location.hostname;
                    if (n || a)
                      switch (e.data.event) {
                        case "happytime":
                          (0, eE.A)(eQ, !1, eV, eq).catch(eH);
                          break;
                        case "inviteLink": {
                          let t = e.data.url;
                          try {
                            window.history.replaceState(
                              { ...window.history.state, as: t, url: t },
                              "",
                              t
                            );
                          } catch (e) {
                            console.error(e);
                          }
                          break;
                        }
                        case "exitFullscreen":
                          ep.A.exitNativeFullscreen();
                          break;
                        case "requestFullscreen":
                          (ev.current = !0),
                            document.documentElement
                              .requestFullscreen()
                              .then(() => {
                                Z.current?.contentWindow?.postMessage(
                                  { type: "fullscreenActivated" },
                                  "*"
                                );
                              })
                              .catch(() => {
                                ev.current = !1;
                              });
                      }
                  };
                  return (
                    window.addEventListener("message", e),
                    function () {
                      window.removeEventListener("message", e);
                    }
                  );
                }),
                (p = [W.desktopUrl, eQ, eV, eM, eq]),
                (O[32] = eQ),
                (O[33] = W.desktopUrl),
                (O[34] = eq),
                (O[35] = eV),
                (O[36] = eM),
                (O[37] = y),
                (O[38] = p))
              : ((y = O[37]), (p = O[38])),
            l.useEffect(y, p),
            O[39] === Symbol.for("react.memo_cache_sentinel")
              ? ((f = () => {
                  let e = () => {
                    !document.fullscreenElement &&
                      ev.current &&
                      ((ev.current = !1),
                      Z.current?.contentWindow?.postMessage(
                        { type: "fullscreenDeactivated" },
                        "*"
                      ),
                      requestAnimationFrame(eK));
                  };
                  return (
                    document.addEventListener("fullscreenchange", e),
                    () => document.removeEventListener("fullscreenchange", e)
                  );
                }),
                (b = []),
                (O[39] = f),
                (O[40] = b))
              : ((f = O[39]), (b = O[40])),
            l.useEffect(f, b),
            O[41] === Symbol.for("react.memo_cache_sentinel")
              ? ((z = () => {
                  let e = () => {
                    (0, ei.z)(
                      window,
                      Z.current?.contentWindow,
                      (0, V.y)()?.contentWindow
                    );
                  };
                  return (
                    (0, el.b)().addInstallListener(e),
                    function () {
                      (0, el.b)().removeInstallListener(e);
                    }
                  );
                }),
                (A = []),
                (O[41] = z),
                (O[42] = A))
              : ((z = O[41]), (A = O[42])),
            l.useEffect(z, A),
            O[43] !== eA
              ? ((x = function () {
                  "enabled" !== eA || document.hidden || e4();
                }),
                (B = [e4, eA]),
                (O[43] = eA),
                (O[44] = x),
                (O[45] = B))
              : ((x = O[44]), (B = O[45])),
            l.useEffect(x, B),
            O[46] === Symbol.for("react.memo_cache_sentinel")
              ? ((S = function () {
                  let e = () => {
                    document.hidden || e4();
                  };
                  return (
                    document.addEventListener("visibilitychange", e),
                    () => document.removeEventListener("visibilitychange", e)
                  );
                }),
                (k = [e4]),
                (O[46] = S),
                (O[47] = k))
              : ((S = O[46]), (k = O[47])),
            l.useEffect(S, k),
            O[48] !== eX ||
            O[49] !== W ||
            O[50] !== eA ||
            O[51] !== e3 ||
            O[52] !== e1 ||
            O[53] !== e2
              ? ((U = eF().gameContainerDesktopRoot),
                (G = "game-container"),
                O[61] === Symbol.for("react.memo_cache_sentinel")
                  ? ((E = (0, v.A)("GameContainer", eF().gameContainer)),
                    (O[61] = E))
                  : (E = O[61]),
                (C = J),
                (D = ef),
                (P = e2),
                (j = (() => {
                  if ("disabled" === eA) return null;
                  if ("loading" === eA)
                    return (0, a.jsx)("div", {
                      className: eF().iframeLoading,
                      children: (0, a.jsx)(en.y, { tone: "neutral" }),
                    });
                  let e = (0, eG.A)(W),
                    t = { importance: "high" },
                    n = W.descriptionFirst
                      ? `${W.descriptionFirst} ${W.descriptionRest}`
                      : null,
                    r = n ? { dangerouslySetInnerHTML: { __html: n } } : {},
                    l = (0, eR.e)(W);
                  return e1
                    ? (0, a.jsx)(
                        "iframe",
                        {
                          [ej.P]: e1.url,
                          [ej.ps]: e1.experiments,
                          [ej.jK]: "",
                          id: V.u,
                          "data-testid": "game-iframe",
                          title: W.name,
                          scrolling: "no",
                          allow: l,
                          allowFullScreen: !0,
                          ref: Z,
                          sandbox: e,
                          loading: "eager",
                          ...t,
                          ...r,
                          "data-hj-allow-iframe": !0,
                          className: eF().gameIframe,
                          style: e3,
                          suppressHydrationWarning: !0,
                        },
                        W.slug
                      )
                    : (0, a.jsx)(
                        eL.A,
                        {
                          buildSource: eX,
                          id: V.u,
                          "data-testid": "game-iframe",
                          title: W.name,
                          scrolling: "no",
                          allow: l,
                          allowFullScreen: !0,
                          ref: Z,
                          sandbox: e,
                          loading: "eager",
                          ...t,
                          ...r,
                          "data-hj-allow-iframe": !0,
                          className: eF().gameIframe,
                          style: e3,
                        },
                        W.slug
                      );
                })()),
                (O[48] = eX),
                (O[49] = W),
                (O[50] = eA),
                (O[51] = e3),
                (O[52] = e1),
                (O[53] = e2),
                (O[54] = D),
                (O[55] = P),
                (O[56] = j),
                (O[57] = E),
                (O[58] = C),
                (O[59] = U),
                (O[60] = G))
              : ((D = O[54]),
                (P = O[55]),
                (j = O[56]),
                (E = O[57]),
                (C = O[58]),
                (U = O[59]),
                (G = O[60])),
            O[62] !== D || O[63] !== P || O[64] !== j
              ? ((R = (0, a.jsx)("div", { ref: D, style: P, children: j })),
                (O[62] = D),
                (O[63] = P),
                (O[64] = j),
                (O[65] = R))
              : (R = O[65]),
            O[66] !== W
              ? ((N = (0, Q.m)(W) && (0, a.jsx)(eB, { game: W, onClose: e4 })),
                (O[66] = W),
                (O[67] = N))
              : (N = O[67]),
            O[68] !== E || O[69] !== C || O[70] !== R || O[71] !== N
              ? ((L = (0, a.jsxs)("div", {
                  className: E,
                  ref: C,
                  children: [R, N],
                })),
                (O[68] = E),
                (O[69] = C),
                (O[70] = R),
                (O[71] = N),
                (O[72] = L))
              : (L = O[72]),
            O[73] !== U || O[74] !== G || O[75] !== L
              ? ((T = (0, a.jsx)("div", {
                  className: U,
                  "data-testid": G,
                  children: L,
                })),
                (O[73] = U),
                (O[74] = G),
                (O[75] = L),
                (O[76] = T))
              : (T = O[76]),
            O[77] === Symbol.for("react.memo_cache_sentinel")
              ? ((I = (0, a.jsx)(eC.A, {})), (O[77] = I))
              : (I = O[77]),
            O[78] !== W
              ? ((M = (0, a.jsx)(eS.A, { game: W })), (O[78] = W), (O[79] = M))
              : (M = O[79]),
            O[80] !== T || O[81] !== M
              ? ((F = (0, a.jsxs)(a.Fragment, { children: [T, I, M] })),
                (O[80] = T),
                (O[81] = M),
                (O[82] = F))
              : (F = O[82]),
            F
          );
        };
        function eW() {}
        function eH(e) {
          console.error(e);
        }
        function eK() {
          return window.scrollTo(0, 0);
        }
        var e$ = n(28918),
          eQ = n(80123);
        let eV = c()(
            () =>
              Promise.all([n.e(80580), n.e(67297), n.e(59598)]).then(
                n.bind(n, 59598)
              ),
            { loadableGenerated: { webpack: () => [59598] } }
          ),
          eq = (e) => {
            let t,
              n,
              i,
              o = (0, r.c)(12),
              { game: s, waitForQATool: d } = e,
              c = (0, Z.j)(s),
              u = l.useContext(eQ.d);
            if ("gameplayer" === u) {
              let e;
              return (
                o[0] !== s
                  ? ((e = (0, a.jsx)(eV, { game: s })), (o[0] = s), (o[1] = e))
                  : (e = o[1]),
                e
              );
            }
            let m = "gameframe-ssr" === u;
            return (
              o[2] !== s || o[3] !== m || o[4] !== d
                ? ((t = (0, a.jsx)(eO, {
                    game: s,
                    waitForQATool: d,
                    serverRendered: m,
                  })),
                  (o[2] = s),
                  (o[3] = m),
                  (o[4] = d),
                  (o[5] = t))
                : (t = o[5]),
              o[6] !== s || o[7] !== c
                ? ((n = (0, a.jsx)(e$.A, { game: s, handlers: c })),
                  (o[6] = s),
                  (o[7] = c),
                  (o[8] = n))
                : (n = o[8]),
              o[9] !== t || o[10] !== n
                ? ((i = (0, a.jsxs)(a.Fragment, { children: [t, n] })),
                  (o[9] = t),
                  (o[10] = n),
                  (o[11] = i))
                : (i = o[11]),
              i
            );
          };
        var eY = n(93800),
          eX = n(37434),
          eJ = n(70930),
          eZ = n(84921),
          e0 = n.n(eZ);
        let e1 = (e) => {
          let t,
            n,
            l,
            i = (0, r.c)(14),
            {
              displayedGames: o,
              start: s,
              end: d,
              options: c,
              className: u,
              twoColumnHoverScale: m,
            } = e,
            _ = void 0 === s ? 0 : s;
          i[0] !== c
            ? ((t = void 0 === c ? {} : c), (i[0] = c), (i[1] = t))
            : (t = i[1]);
          let g = t,
            h = d || o.length;
          i[2] !== o || i[3] !== h || i[4] !== _
            ? ((n = o.slice(_, h)),
              (i[2] = o),
              (i[3] = h),
              (i[4] = _),
              (i[5] = n))
            : (n = i[5]);
          let y = n;
          return (
            i[6] !== u ||
            i[7] !== o ||
            i[8] !== g ||
            i[9] !== h ||
            i[10] !== y.length ||
            i[11] !== _ ||
            i[12] !== m
              ? ((l =
                  y.length === h - _
                    ? (0, a.jsx)(eJ.A, {
                        className: (0, v.A)(e0().gameGrid, u),
                        games: o.slice(_, h),
                        justifyContent: "center",
                        slidesToLoadEagerly: g.slidesToLoadEagerly,
                        customStyles: g.customStyles,
                        twoColumnHoverScale: m,
                      })
                    : null),
                (i[6] = u),
                (i[7] = o),
                (i[8] = g),
                (i[9] = h),
                (i[10] = y.length),
                (i[11] = _),
                (i[12] = m),
                (i[13] = l))
              : (l = i[13]),
            l
          );
        };
        var e2 = n(46195),
          e3 = n.n(e2);
        let e4 = (e) => {
            let t,
              n,
              i,
              o,
              d,
              c,
              u,
              m,
              g = (0, r.c)(19),
              { related: h } = e,
              [y, p] = l.useState(!1),
              f = l.useRef(null);
            g[0] !== h || g[1] !== y
              ? ((t = y ? h : h.slice(0, 12)),
                (g[0] = h),
                (g[1] = y),
                (g[2] = t))
              : (t = g[2]);
            let v = t;
            g[3] === Symbol.for("react.memo_cache_sentinel")
              ? ((n = (0, a.jsx)("div", {
                  className: e3().playNextTitle,
                  children: (0, a.jsx)(s.x6, { id: "game.related.playNext" }),
                })),
                (g[3] = n))
              : (n = g[3]),
              g[4] !== v
                ? ((i = (0, a.jsxs)("div", {
                    className: e3().underGameContainerGamesWrapper,
                    children: [
                      n,
                      (0, a.jsx)(_.x, {
                        newClickOrigin: "gamePage-related",
                        children: (0, a.jsx)(e1, { displayedGames: v }),
                      }),
                    ],
                  })),
                  (g[4] = v),
                  (g[5] = i))
                : (i = g[5]),
              g[6] !== y
                ? ((o = y
                    ? () => {
                        document
                          .getElementById("gamePageMainContainer")
                          ?.scrollIntoView(),
                          p(!1);
                      }
                    : () => p(!0)),
                  (g[6] = y),
                  (g[7] = o))
                : (o = g[7]);
            let b = y ? "minus" : "plus";
            return (
              g[8] !== b
                ? ((d = (0, a.jsx)(eY.A, { name: b })), (g[8] = b), (g[9] = d))
                : (d = g[9]),
              g[10] !== y
                ? ((c = y
                    ? (0, a.jsx)(s.x6, { id: "common.showLess" })
                    : (0, a.jsx)(s.x6, { id: "common.showMore" })),
                  (g[10] = y),
                  (g[11] = c))
                : (c = g[11]),
              g[12] !== o || g[13] !== d || g[14] !== c
                ? ((u = (0, a.jsxs)(eX.A, {
                    variant: "contained",
                    color: "purple",
                    height: 50,
                    className: e3().showMoreButton,
                    onClick: o,
                    children: [d, c],
                  })),
                  (g[12] = o),
                  (g[13] = d),
                  (g[14] = c),
                  (g[15] = u))
                : (u = g[15]),
              g[16] !== i || g[17] !== u
                ? ((m = (0, a.jsxs)("div", {
                    className: e3().underGameContainerGrid,
                    ref: f,
                    children: [i, u],
                  })),
                  (g[16] = i),
                  (g[17] = u),
                  (g[18] = m))
                : (m = g[18]),
              m
            );
          },
          e5 = (e) => {
            let t,
              n,
              l = (0, r.c)(3);
            return (
              l[0] === Symbol.for("react.memo_cache_sentinel")
                ? ((t = { right: 355, top: -3 }), (l[0] = t))
                : (t = l[0]),
              l[1] !== e
                ? ((n = (0, a.jsx)(U, {
                    id: i.R.RightMpuRefresh,
                    width: 300,
                    height: 250,
                    customLabelStyle: t,
                    ...e,
                  })),
                  (l[1] = e),
                  (l[2] = n))
                : (n = l[2]),
              n
            );
          };
        var e6 = n(83072),
          e7 = n(77650),
          e8 = n(76436),
          e9 = n(47352),
          te = n(32548),
          tt = n(41738),
          tn = n(60788),
          ta = n(47953),
          tr = n.n(ta),
          tl = n(75864),
          ti = n.n(tl);
        let to = (e) => {
            let t,
              n,
              l,
              i,
              o = (0, r.c)(11),
              { entry: s, size: d, done: c } = e,
              u = ti()[d],
              m = c && ti().thumbDone;
            return (
              o[0] !== u || o[1] !== m
                ? ((t = (0, v.A)(ti().thumb, u, m)),
                  (o[0] = u),
                  (o[1] = m),
                  (o[2] = t))
                : (t = o[2]),
              o[3] !== s.game
                ? ((n =
                    s.game &&
                    (0, a.jsx)("img", {
                      src: (0, z.Ay)(s.game.covers?.["1x1"] || s.game.cover, {
                        width: 120,
                      }),
                      alt: "",
                    })),
                  (o[3] = s.game),
                  (o[4] = n))
                : (n = o[4]),
              o[5] !== c
                ? ((l =
                    c &&
                    (0, a.jsx)("span", {
                      className: ti().check,
                      "aria-hidden": !0,
                    })),
                  (o[5] = c),
                  (o[6] = l))
                : (l = o[6]),
              o[7] !== t || o[8] !== n || o[9] !== l
                ? ((i = (0, a.jsxs)("span", {
                    className: t,
                    children: [n, l],
                  })),
                  (o[7] = t),
                  (o[8] = n),
                  (o[9] = l),
                  (o[10] = i))
                : (i = o[10]),
              i
            );
          },
          ts = (e) => {
            let t,
              n,
              l,
              i = (0, r.c)(7),
              { entry: o } = e,
              s = o.game?.name;
            return (
              i[0] !== s
                ? ((t = (0, a.jsx)("span", {
                    className: ti().name,
                    children: s,
                  })),
                  (i[0] = s),
                  (i[1] = t))
                : (t = i[1]),
              i[2] !== o.daily.currentStreak
                ? ((n = (0, a.jsx)(tn.A, { streak: o.daily.currentStreak })),
                  (i[2] = o.daily.currentStreak),
                  (i[3] = n))
                : (n = i[3]),
              i[4] !== t || i[5] !== n
                ? ((l = (0, a.jsxs)("span", {
                    className: ti().text,
                    children: [t, n],
                  })),
                  (i[4] = t),
                  (i[5] = n),
                  (i[6] = l))
                : (l = i[6]),
              l
            );
          },
          td = (e) => {
            let t,
              n = (0, r.c)(4),
              { entry: l, className: i, children: o } = e;
            return (
              n[0] !== o || n[1] !== i || n[2] !== l.game
                ? ((t = l.game
                    ? (0, a.jsx)(e9.A, {
                        slug: l.game.slug,
                        className: i,
                        launchSource: "dailyPuzzle",
                        children: o,
                      })
                    : (0, a.jsx)("div", { className: i, children: o })),
                  (n[0] = o),
                  (n[1] = i),
                  (n[2] = l.game),
                  (n[3] = t))
                : (t = n[3]),
              t
            );
          },
          tc = (e) => {
            let t,
              n,
              i,
              o,
              d = (0, r.c)(35),
              { currentGameId: c } = e,
              {
                entries: u,
                solvedCount: m,
                total: _,
                nextResetAt: g,
                getEntry: h,
              } = (0, tt.A)(),
              y = (0, e8.G)(),
              { capture: p } = y;
            d[0] !== c || d[1] !== h
              ? ((t = h(c)?.daily.completed),
                (d[0] = c),
                (d[1] = h),
                (d[2] = t))
              : (t = d[2]);
            let f = !!t,
              [b, w] = l.useState(f),
              [z, A] = l.useState(null);
            if (
              (f !== b && (w(f), A(f ? "completing" : null)),
              d[3] !== p || d[4] !== z
                ? ((n = () => {
                    if ("completing" === z) {
                      let e = window.setTimeout(() => {
                        p(), A("settled");
                      }, 600);
                      return () => window.clearTimeout(e);
                    }
                    if ("settled" === z) {
                      let e = window.setTimeout(() => A(null), 1800);
                      return () => window.clearTimeout(e);
                    }
                  }),
                  (i = [z, p]),
                  (d[3] = p),
                  (d[4] = z),
                  (d[5] = n),
                  (d[6] = i))
                : ((n = d[5]), (i = d[6])),
              l.useEffect(n, i),
              d[7] !== y ||
                d[8] !== c ||
                d[9] !== u ||
                d[10] !== g ||
                d[11] !== z ||
                d[12] !== m ||
                d[13] !== _)
            ) {
              let e,
                t,
                n,
                r,
                l,
                i,
                h,
                p,
                {
                  top: f,
                  toPlay: b,
                  completed: w,
                  highlightedGameId: A,
                } = (function (e, t, n) {
                  let a = e.find((e) => e.daily.gameId === t),
                    r = "completing" === n,
                    l = (e) => !e.daily.completed || (r && e === a),
                    i = e.filter(l),
                    o = e.filter((e) => !l(e));
                  if (a && i.includes(a)) {
                    let e = i.filter((e) => e !== a);
                    return {
                      top: {
                        kind: r ? "justCompleted" : "nowPlaying",
                        entry: a,
                      },
                      toPlay: e,
                      completed: o,
                      highlightedGameId: r ? e[0]?.daily.gameId : void 0,
                    };
                  }
                  let [s, ...d] = i;
                  return {
                    top: s ? { kind: "upNext", entry: s } : null,
                    toPlay: d,
                    completed: o,
                    highlightedGameId: "settled" === n ? t : void 0,
                  };
                })(u, c, z),
                x = f?.kind === "nowPlaying" ? m : -1;
              if (
                (d[15] === Symbol.for("react.memo_cache_sentinel")
                  ? ((e = e7.Ru._({ id: "common.dailyGames.title" })),
                    (d[15] = e))
                  : (e = d[15]),
                d[16] === Symbol.for("react.memo_cache_sentinel")
                  ? ((t = (0, a.jsx)("h2", {
                      className: ti().title,
                      children: (0, a.jsx)(s.x6, {
                        id: "common.dailyGames.title",
                      }),
                    })),
                    (d[16] = t))
                  : (t = d[16]),
                d[17] !== g
                  ? ((n = (0, a.jsxs)("div", {
                      className: ti().header,
                      children: [
                        t,
                        (0, a.jsx)(te.A, {
                          nextResetAt: g,
                          className: ti().countdown,
                        }),
                      ],
                    })),
                    (d[17] = g),
                    (d[18] = n))
                  : (n = d[18]),
                d[19] !== x || d[20] !== m || d[21] !== _)
              ) {
                let e;
                d[23] !== x || d[24] !== m
                  ? ((e = (e, t) =>
                      (0, a.jsx)(
                        "span",
                        {
                          className: (0, v.A)(
                            ti().segment,
                            t < m && ti().segmentDone,
                            t === x && ti().segmentPlaying
                          ),
                        },
                        t
                      )),
                    (d[23] = x),
                    (d[24] = m),
                    (d[25] = e))
                  : (e = d[25]),
                  (r = (0, a.jsx)("span", {
                    className: ti().segments,
                    "aria-hidden": !0,
                    children: Array.from({ length: _ }, e),
                  })),
                  (d[19] = x),
                  (d[20] = m),
                  (d[21] = _),
                  (d[22] = r);
              } else r = d[22];
              d[26] !== m || d[27] !== _
                ? ((l = { solved: m, total: _ }),
                  (d[26] = m),
                  (d[27] = _),
                  (d[28] = l))
                : (l = d[28]),
                d[29] === Symbol.for("react.memo_cache_sentinel")
                  ? ((i = { 0: (0, a.jsx)("strong", {}) }), (d[29] = i))
                  : (i = d[29]),
                d[30] !== l
                  ? ((h = (0, a.jsx)("span", {
                      className: ti().progressLabel,
                      children: (0, a.jsx)(s.x6, {
                        id: "common.dailyGames.progress",
                        values: l,
                        components: i,
                      }),
                    })),
                    (d[30] = l),
                    (d[31] = h))
                  : (h = d[31]),
                d[32] !== h || d[33] !== r
                  ? ((p = (0, a.jsxs)("div", {
                      className: ti().progress,
                      children: [r, h],
                    })),
                    (d[32] = h),
                    (d[33] = r),
                    (d[34] = p))
                  : (p = d[34]),
                (o = (0, a.jsxs)("aside", {
                  className: ti().sidebar,
                  "aria-label": e,
                  children: [
                    n,
                    p,
                    f?.kind === "upNext"
                      ? (0, a.jsxs)(a.Fragment, {
                          children: [
                            (0, a.jsx)("h3", {
                              className: (0, v.A)(
                                ti().sectionTitle,
                                ti().upNextTitle
                              ),
                              children: (0, a.jsx)(s.x6, {
                                id: "common.dailyGames.upNext",
                              }),
                            }),
                            (0, a.jsx)("div", {
                              ref: y.ref(f.entry.daily.gameId),
                              children: (0, a.jsx)(td, {
                                entry: f.entry,
                                className: ti().upNextCard,
                                children: (0, a.jsxs)("span", {
                                  className: ti().cardContent,
                                  children: [
                                    (0, a.jsxs)("span", {
                                      className: ti().row,
                                      children: [
                                        (0, a.jsx)(to, {
                                          entry: f.entry,
                                          size: "large",
                                        }),
                                        (0, a.jsx)(ts, { entry: f.entry }),
                                      ],
                                    }),
                                    (0, a.jsx)("span", {
                                      className: (0, v.A)(
                                        tr().greenPill,
                                        ti().solveNow
                                      ),
                                      children: (0, a.jsx)(s.x6, {
                                        id: "common.dailyGames.solveNow",
                                      }),
                                    }),
                                  ],
                                }),
                              }),
                            }),
                          ],
                        })
                      : f &&
                        (0, a.jsxs)(a.Fragment, {
                          children: [
                            (0, a.jsx)("h3", {
                              className: (0, v.A)(
                                ti().sectionTitle,
                                ti().nowPlayingTitle
                              ),
                              children: (0, a.jsx)(s.x6, {
                                id: "common.dailyGames.nowPlaying",
                              }),
                            }),
                            (0, a.jsxs)("div", {
                              ref: y.ref(f.entry.daily.gameId),
                              className: (0, v.A)(
                                ti().nowPlayingCard,
                                "justCompleted" === f.kind && ti().justCompleted
                              ),
                              children: [
                                (0, a.jsx)(to, {
                                  entry: f.entry,
                                  size: "large",
                                  done: "justCompleted" === f.kind,
                                }),
                                (0, a.jsx)(ts, { entry: f.entry }),
                              ],
                            }),
                          ],
                        }),
                    b.length > 0 &&
                      (0, a.jsxs)(a.Fragment, {
                        children: [
                          (0, a.jsxs)("h3", {
                            className: ti().sectionTitle,
                            children: [
                              (0, a.jsx)(s.x6, {
                                id: "common.dailyGames.toPlay",
                              }),
                              (0, a.jsx)("span", {
                                className: ti().sectionCount,
                                children: (0, a.jsx)(s.x6, {
                                  id: "common.dailyGames.left",
                                  values: { count: b.length },
                                }),
                              }),
                            ],
                          }),
                          (0, a.jsx)("ul", {
                            className: (0, v.A)(ti().list, ti().toPlayList),
                            children: b.map((e) =>
                              (0, a.jsx)(
                                "li",
                                {
                                  ref: y.ref(e.daily.gameId),
                                  children: (0, a.jsx)(td, {
                                    entry: e,
                                    className: (0, v.A)(
                                      ti().listRow,
                                      e.daily.gameId === A && ti().highlightNext
                                    ),
                                    children: (0, a.jsxs)("span", {
                                      className: ti().row,
                                      children: [
                                        (0, a.jsx)(to, {
                                          entry: e,
                                          size: "small",
                                        }),
                                        (0, a.jsx)(ts, { entry: e }),
                                        (0, a.jsx)("span", {
                                          className: tr().greenPill,
                                          children: (0, a.jsx)(s.x6, {
                                            id: "common.dailyGames.solveShort",
                                          }),
                                        }),
                                      ],
                                    }),
                                  }),
                                },
                                e.daily.gameId
                              )
                            ),
                          }),
                        ],
                      }),
                    w.length > 0 &&
                      (0, a.jsxs)(a.Fragment, {
                        children: [
                          (0, a.jsxs)("h3", {
                            className: ti().sectionTitle,
                            children: [
                              (0, a.jsx)(s.x6, {
                                id: "common.dailyGames.completed",
                              }),
                              (0, a.jsx)("span", {
                                className: ti().sectionCount,
                                children: (0, a.jsx)(s.x6, {
                                  id: "common.dailyGames.completedCount",
                                  values: { solved: w.length, total: _ },
                                }),
                              }),
                            ],
                          }),
                          (0, a.jsx)("ul", {
                            className: (0, v.A)(ti().list, ti().completedList),
                            children: w.map((e) =>
                              (0, a.jsx)(
                                "li",
                                {
                                  ref: y.ref(e.daily.gameId),
                                  children: (0, a.jsx)(td, {
                                    entry: e,
                                    className: (0, v.A)(
                                      ti().listRow,
                                      ti().completedRow,
                                      e.daily.gameId === A && ti().highlightDone
                                    ),
                                    children: (0, a.jsxs)("span", {
                                      className: ti().row,
                                      children: [
                                        (0, a.jsx)(to, {
                                          entry: e,
                                          size: "small",
                                          done: !0,
                                        }),
                                        (0, a.jsx)(ts, { entry: e }),
                                        (0, a.jsx)("span", {
                                          className: ti().replay,
                                          "aria-hidden": !0,
                                        }),
                                      ],
                                    }),
                                  }),
                                },
                                e.daily.gameId
                              )
                            ),
                          }),
                        ],
                      }),
                  ],
                })),
                (d[7] = y),
                (d[8] = c),
                (d[9] = u),
                (d[10] = g),
                (d[11] = z),
                (d[12] = m),
                (d[13] = _),
                (d[14] = o);
            } else o = d[14];
            return o;
          },
          tu = (e) => {
            let t,
              n,
              i,
              o,
              d,
              c,
              u,
              m,
              _ = (0, r.c)(15),
              { scrollContainerRef: g, pinnedTopRef: h } = e,
              [y, p] = l.useState(!0);
            _[0] !== g
              ? ((t = () => {
                  let e = g?.current,
                    t = e ?? window,
                    n = () => {
                      let t = e
                        ? e.scrollTop + e.clientHeight < e.scrollHeight - 50
                        : 0 === window.scrollY;
                      p((e) => (t !== e ? t : e));
                    };
                  return (
                    n(),
                    t.addEventListener("scroll", n, { passive: !0 }),
                    () => {
                      t.removeEventListener("scroll", n);
                    }
                  );
                }),
                (n = [g]),
                (_[0] = g),
                (_[1] = t),
                (_[2] = n))
              : ((t = _[1]), (n = _[2])),
              l.useEffect(t, n),
              _[3] !== h || _[4] !== g
                ? ((i = (e) => {
                    e.stopPropagation();
                    let t = g?.current;
                    if (!t)
                      return void window.scrollBy({
                        top: 400,
                        behavior: "smooth",
                      });
                    let n = t.clientHeight - (h?.current?.offsetHeight ?? 0);
                    t.scrollBy({
                      top: Math.max(n - 120, n / 2),
                      behavior: "smooth",
                    });
                  }),
                  (_[3] = h),
                  (_[4] = g),
                  (_[5] = i))
                : (i = _[5]);
            let f = i,
              b = !y && e3().hidden;
            return (
              _[6] !== b
                ? ((o = (0, v.A)(e3().showMoreIndicatorDesktop, b)),
                  (_[6] = b),
                  (_[7] = o))
                : (o = _[7]),
              _[8] === Symbol.for("react.memo_cache_sentinel")
                ? ((d = (0, a.jsx)(eY.A, { name: "arrow-simple-down" })),
                  (c = (0, a.jsx)(s.x6, { id: "game.viewMore" })),
                  (_[8] = d),
                  (_[9] = c))
                : ((d = _[8]), (c = _[9])),
              _[10] !== f
                ? ((u = (0, a.jsxs)(eX.A, {
                    className: e3().showMoreButtonDesktop,
                    variant: "contained",
                    onClick: f,
                    children: [d, c],
                  })),
                  (_[10] = f),
                  (_[11] = u))
                : (u = _[11]),
              _[12] !== o || _[13] !== u
                ? ((m = (0, a.jsx)("div", { className: o, children: u })),
                  (_[12] = o),
                  (_[13] = u),
                  (_[14] = m))
                : (m = _[14]),
              m
            );
          },
          tm = () => {
            let e,
              t = (0, r.c)(2),
              n = (0, Q.Y)();
            return (
              t[0] !== n
                ? ((e = (0, a.jsx)("div", { style: { height: n } })),
                  (t[0] = n),
                  (t[1] = e))
                : (e = t[1]),
              e
            );
          },
          t_ = c()(
            () =>
              Promise.all([
                n.e(73940),
                n.e(110),
                n.e(8272),
                n.e(30944),
                n.e(55707),
                n.e(59160),
                n.e(65527),
                n.e(37239),
              ]).then(n.bind(n, 65527)),
            {
              loadableGenerated: { webpack: () => [65527] },
              ssr: !1,
              loading: () => (0, a.jsx)(tm, {}),
            }
          ),
          tg = (e) => {
            let t,
              n,
              i,
              o,
              d,
              c,
              u,
              m,
              g,
              h,
              b,
              w = (0, r.c)(27),
              { game: z, related: A } = e,
              x =
                "enabled" ===
                (0, ed.U)("czyExpGamePageScrollableSidebar_CZY_21338b"),
              { breakpoints: B } = (0, p.D)();
            w[0] !== B
              ? ((t = B.up("lg")), (w[0] = B), (w[1] = t))
              : (t = w[1]);
            let S = (0, f.A)(t),
              k = x && S,
              D = l.useRef(null),
              P = l.useRef(null),
              j = (0, e6.r)(z);
            if (
              (w[2] !== k
                ? ((n = () => {
                    let e,
                      t = D.current;
                    if (!k || !t) return;
                    let n = () => {
                      t.classList.add(e3().isScrolling),
                        clearTimeout(e),
                        (e = setTimeout(
                          () => t.classList.remove(e3().isScrolling),
                          150
                        ));
                    };
                    return (
                      t.addEventListener("scroll", n, { passive: !0 }),
                      () => {
                        t.removeEventListener("scroll", n),
                          clearTimeout(e),
                          t.classList.remove(e3().isScrolling);
                      }
                    );
                  }),
                  (i = [k]),
                  (w[2] = k),
                  (w[3] = n),
                  (w[4] = i))
                : ((n = w[3]), (i = w[4])),
              l.useEffect(n, i),
              j)
            ) {
              let e, t;
              return (
                w[5] === Symbol.for("react.memo_cache_sentinel")
                  ? ((e = (0, v.A)(e3().rightSidebar, e3().dailyGamesSidebar)),
                    (w[5] = e))
                  : (e = w[5]),
                w[6] !== z.id
                  ? ((t = (0, a.jsx)("div", {
                      className: e,
                      children: (0, a.jsx)(tc, { currentGameId: z.id }),
                    })),
                    (w[6] = z.id),
                    (w[7] = t))
                  : (t = w[7]),
                t
              );
            }
            let E = x && e3().scrollable;
            return (
              w[8] !== E
                ? ((o = (0, v.A)(e3().rightSidebar, E)), (w[8] = E), (w[9] = o))
                : (o = w[9]),
              w[10] !== z
                ? ((d =
                    (0, Q.m)(z) &&
                    (0, a.jsx)(t_, { game: z, position: "right-column" })),
                  (w[10] = z),
                  (w[11] = d))
                : (d = w[11]),
              w[12] === Symbol.for("react.memo_cache_sentinel")
                ? ((c = (0, a.jsx)(e5, {
                    verticalLabel: !0,
                    addAdBlockWarning: !0,
                    customLabelStyle: {
                      marginLeft: 0,
                      transform: "translate(0)",
                      right: "0",
                      top: 255,
                    },
                    customAdWrapperStyle: {
                      boxShadow: `inset 0px 0px 0px 1px ${y.l.black[60]}`,
                      background: "rgba(71, 73, 103, 0.10)",
                    },
                  })),
                  (w[12] = c))
                : (c = w[12]),
              w[13] !== z
                ? ((u = (0, a.jsx)("div", {
                    className: e3().rightMpuContainer,
                    ref: P,
                    children: (0, a.jsx)(R, { game: z, children: c }),
                  })),
                  (w[13] = z),
                  (w[14] = u))
                : (u = w[14]),
              w[15] === Symbol.for("react.memo_cache_sentinel")
                ? ((m = (0, a.jsx)("div", {
                    className: e3().playNextTitle,
                    children: (0, a.jsx)(s.x6, { id: "game.related.playNext" }),
                  })),
                  (w[15] = m))
                : (m = w[15]),
              w[16] !== A
                ? ((g = (0, a.jsxs)("div", {
                    className: e3().rightGridContainer,
                    children: [
                      m,
                      (0, a.jsx)(_.x, {
                        newClickOrigin: "gamePage-related",
                        children: (0, a.jsx)(e1, {
                          displayedGames: A,
                          twoColumnHoverScale: !0,
                          className: "game-page-related-grid",
                        }),
                      }),
                    ],
                  })),
                  (w[16] = A),
                  (w[17] = g))
                : (g = w[17]),
              w[18] !== z.isPreview || w[19] !== k
                ? ((h =
                    !z.isPreview &&
                    (0, a.jsx)(tu, {
                      scrollContainerRef: k ? D : void 0,
                      pinnedTopRef: P,
                    })),
                  (w[18] = z.isPreview),
                  (w[19] = k),
                  (w[20] = h))
                : (h = w[20]),
              w[21] !== g ||
              w[22] !== h ||
              w[23] !== o ||
              w[24] !== d ||
              w[25] !== u
                ? ((b = (0, a.jsxs)("div", {
                    className: o,
                    ref: D,
                    children: [d, u, g, h],
                  })),
                  (w[21] = g),
                  (w[22] = h),
                  (w[23] = o),
                  (w[24] = d),
                  (w[25] = u),
                  (w[26] = b))
                : (b = w[26]),
              b
            );
          },
          th = c()(
            () =>
              Promise.all([
                n.e(80580),
                n.e(56448),
                n.e(64773),
                n.e(60700),
              ]).then(n.bind(n, 60700)),
            {
              loadableGenerated: { webpack: () => [60700] },
              loading: () => null,
              ssr: !1,
            }
          ),
          ty = c()(
            () =>
              Promise.all([
                n.e(80580),
                n.e(56448),
                n.e(61019),
                n.e(42886),
                n.e(92179),
                n.e(12039),
              ]).then(n.bind(n, 12039)),
            {
              loadableGenerated: { webpack: () => [12039] },
              loading: () => null,
              ssr: !1,
            }
          ),
          tp = c()(
            () =>
              Promise.all([
                n.e(73940),
                n.e(110),
                n.e(8272),
                n.e(30944),
                n.e(55707),
                n.e(59160),
                n.e(65527),
                n.e(37239),
              ]).then(n.bind(n, 65527)),
            {
              loadableGenerated: { webpack: () => [65527] },
              ssr: !1,
              loading: () => (0, a.jsx)("div", { style: { height: "99px" } }),
            }
          ),
          tf = (e) => {
            let t,
              n,
              d,
              c,
              u,
              p,
              f,
              v,
              b,
              w,
              z,
              A,
              x,
              B,
              S,
              k,
              D,
              P,
              j,
              E,
              C,
              U = (0, r.c)(58),
              {
                game: T,
                previewSubmission: I,
                previewBuild: M,
                isQaTool: F,
                disableSubmitQA: O,
                submissionBlocked: W,
                crawlerData: H,
              } = e;
            U[0] !== F || U[1] !== M || U[2] !== I
              ? ((t = F && (0, o.O)(I) && (0, o.O)(M)),
                (U[0] = F),
                (U[1] = M),
                (U[2] = I),
                (U[3] = t))
              : (t = U[3]);
            let K = t,
              [V, q] = l.useState(!1);
            U[4] === Symbol.for("react.memo_cache_sentinel")
              ? ((n = () => q(!0)), (U[4] = n))
              : (n = U[4]);
            let Y = n,
              { games: X, isInjecting: Z } = (0, h.z)(
                H?.isCrawler ?? !1,
                !0 === T.isPreview,
                T.id
              );
            U[5] === Symbol.for("react.memo_cache_sentinel")
              ? ((d = Array.from({ length: g.TS }, tv)), (U[5] = d))
              : (d = U[5]);
            let ee = d;
            U[6] !== H?.games || U[7] !== H?.isCrawler || U[8] !== T.isPreview
              ? ((c = () =>
                  H?.isCrawler ? H?.games ?? [] : !0 === T.isPreview ? [] : ee),
                (U[6] = H?.games),
                (U[7] = H?.isCrawler),
                (U[8] = T.isPreview),
                (U[9] = c))
              : (c = U[9]);
            let [et, en] = l.useState(c),
              { getModelGames: ea } = (0, L.A)();
            U[10] !== T.id || U[11] !== T.isPreview || U[12] !== ea
              ? ((u = () => {
                  let e = async () => {
                    let e = await ea({
                      gameId: T.id,
                      numGames: g.TS,
                      place: "gamePage",
                    });
                    e &&
                      en(
                        e.items.length % 2 == 0 ? e.items : e.items.slice(0, -1)
                      );
                  };
                  T.isPreview || e();
                }),
                (p = [ea, en, T.isPreview, T.id]),
                (U[10] = T.id),
                (U[11] = T.isPreview),
                (U[12] = ea),
                (U[13] = u),
                (U[14] = p))
              : ((u = U[13]), (p = U[14])),
              l.useEffect(u, p);
            let er = et.some(tb);
            e: {
              let e;
              if (er || Z) {
                f = ee;
                break e;
              }
              U[15] !== X || U[16] !== et
                ? ((e = (0, m.cY)(et, X, m.PV)),
                  (U[15] = X),
                  (U[16] = et),
                  (U[17] = e))
                : (e = U[17]),
                (f = e);
            }
            let el = f,
              ei = K && !V;
            return (
              U[18] !== T || U[19] !== ei
                ? ((v = (0, a.jsx)("div", {
                    className: e3().gfContainer,
                    children: (0, a.jsx)("div", {
                      className: e3().gfAspectRatioContainer,
                      children: (0, a.jsx)(eq, { game: T, waitForQATool: ei }),
                    }),
                  })),
                  (U[18] = T),
                  (U[19] = ei),
                  (U[20] = v))
                : (v = U[20]),
              U[21] !== T || U[22] !== I
                ? ((b = I && (0, a.jsx)(ty, { game: T })),
                  (U[21] = T),
                  (U[22] = I),
                  (U[23] = b))
                : (b = U[23]),
              U[24] !== T
                ? ((w =
                    (0, Q.m)(T) &&
                    (0, a.jsx)(tp, { game: T, position: "under-gameframe" })),
                  (U[24] = T),
                  (U[25] = w))
                : (w = U[25]),
              U[26] === Symbol.for("react.memo_cache_sentinel")
                ? ((z = (0, a.jsx)(G, {
                    id: i.R.LeaderboardBelowGameRefresh,
                    verticalLabel: !0,
                    addAdBlockWarning: !0,
                    customLabelStyle: {
                      transform: "none",
                      right: -19,
                      writingMode: "vertical-lr",
                      top: 3,
                    },
                    customAdWrapperStyle: {
                      boxShadow: `inset 0px 0px 0px 1px ${y.l.black[60]}`,
                      background: "rgba(71, 73, 103, 0.10)",
                    },
                  })),
                  (U[26] = z))
                : (z = U[26]),
              U[27] !== T
                ? ((A = (0, a.jsx)("div", {
                    className: e3().leaderboardContainer,
                    children: (0, a.jsx)("div", {
                      className: e3().leaderboard,
                      children: (0, a.jsx)(R, { game: T, children: z }),
                    }),
                  })),
                  (U[27] = T),
                  (U[28] = A))
                : (A = U[28]),
              U[29] !== el
                ? ((x = (0, a.jsx)(e4, { related: el })),
                  (U[29] = el),
                  (U[30] = x))
                : (x = U[30]),
              U[31] !== T
                ? ((B = (0, a.jsx)("div", {
                    className: e3().gameInfoContainer,
                    children: (0, a.jsx)(_.x, {
                      newClickOrigin: "gamePage",
                      children: (0, a.jsx)($, { game: T }),
                    }),
                  })),
                  (U[31] = T),
                  (U[32] = B))
                : (B = U[32]),
              U[33] !== b ||
              U[34] !== w ||
              U[35] !== A ||
              U[36] !== x ||
              U[37] !== B ||
              U[38] !== v
                ? ((S = (0, a.jsxs)("div", {
                    className: e3().mainContainer,
                    id: "gamePageMainContainer",
                    children: [v, b, w, A, x, B],
                  })),
                  (U[33] = b),
                  (U[34] = w),
                  (U[35] = A),
                  (U[36] = x),
                  (U[37] = B),
                  (U[38] = v),
                  (U[39] = S))
                : (S = U[39]),
              U[40] !== T || U[41] !== el
                ? ((k = (0, a.jsx)(tg, { game: T, related: el })),
                  (U[40] = T),
                  (U[41] = el),
                  (U[42] = k))
                : (k = U[42]),
              U[43] === Symbol.for("react.memo_cache_sentinel")
                ? ((D = (0, a.jsx)(N.A, {
                    height: 50,
                    playAnimation: !0,
                    label: (0, a.jsx)(s.x6, { id: "game.backToGame" }),
                    addDelayTimeMs: 1e3,
                    center: !0,
                  })),
                  (U[43] = D))
                : (D = U[43]),
              U[44] !== O ||
              U[45] !== T ||
              U[46] !== M ||
              U[47] !== I ||
              U[48] !== K ||
              U[49] !== W
                ? ((P =
                    K &&
                    (0, a.jsx)(th, {
                      submission: I,
                      build: M,
                      disableSubmitQA: O,
                      submissionBlocked: W,
                      game: T,
                      onReady: Y,
                    })),
                  (U[44] = O),
                  (U[45] = T),
                  (U[46] = M),
                  (U[47] = I),
                  (U[48] = K),
                  (U[49] = W),
                  (U[50] = P))
                : (P = U[50]),
              U[51] !== S || U[52] !== k || U[53] !== P
                ? ((j = (0, a.jsxs)("div", {
                    className: e3().main,
                    children: [S, k, D, P],
                  })),
                  (U[51] = S),
                  (U[52] = k),
                  (U[53] = P),
                  (U[54] = j))
                : (j = U[54]),
              U[55] === Symbol.for("react.memo_cache_sentinel")
                ? ((E = (0, a.jsx)(J, {})), (U[55] = E))
                : (E = U[55]),
              U[56] !== j
                ? ((C = (0, a.jsxs)(a.Fragment, { children: [j, E] })),
                  (U[56] = j),
                  (U[57] = C))
                : (C = U[57]),
              C
            );
          };
        function tv(e, t) {
          return {
            id: `${t}`,
            name: `loading-${t}`,
            slug: `loading-${t}`,
            cover: void 0,
            videos: (0, u.R)(),
            status: "PUBLISHED",
            loading: !0,
          };
        }
        function tb(e) {
          return e.loading;
        }
      },
      75864: (e) => {
        e.exports = {
          sidebar: "DailyPuzzlesSidebar_sidebar__V4xgg",
          header: "DailyPuzzlesSidebar_header__TUwu5",
          title: "DailyPuzzlesSidebar_title__n_Bh7",
          countdown: "DailyPuzzlesSidebar_countdown__9SU3F",
          progress: "DailyPuzzlesSidebar_progress__XhhRU",
          segments: "DailyPuzzlesSidebar_segments__Ia9DM",
          segment: "DailyPuzzlesSidebar_segment__gTmop",
          segmentDone: "DailyPuzzlesSidebar_segmentDone__2mRFG",
          segmentPlaying: "DailyPuzzlesSidebar_segmentPlaying__YXo3D",
          "segment-sweep": "DailyPuzzlesSidebar_segment-sweep__HQess",
          progressLabel: "DailyPuzzlesSidebar_progressLabel__5UrZy",
          sectionTitle: "DailyPuzzlesSidebar_sectionTitle___QMU5",
          nowPlayingTitle: "DailyPuzzlesSidebar_nowPlayingTitle__lP0YI",
          upNextTitle: "DailyPuzzlesSidebar_upNextTitle__InqLd",
          sectionCount: "DailyPuzzlesSidebar_sectionCount__oquZ7",
          row: "DailyPuzzlesSidebar_row__LKIRi",
          thumb: "DailyPuzzlesSidebar_thumb__ueDoj",
          large: "DailyPuzzlesSidebar_large__ky_DO",
          small: "DailyPuzzlesSidebar_small__Np80U",
          thumbDone: "DailyPuzzlesSidebar_thumbDone__gXfYE",
          check: "DailyPuzzlesSidebar_check__lwDkM",
          justCompleted: "DailyPuzzlesSidebar_justCompleted__rr9rH",
          pop: "DailyPuzzlesSidebar_pop__79fzK",
          text: "DailyPuzzlesSidebar_text__DYqQr",
          name: "DailyPuzzlesSidebar_name__VLDh9",
          nowPlayingCard: "DailyPuzzlesSidebar_nowPlayingCard__daj93",
          upNextCard: "DailyPuzzlesSidebar_upNextCard__86Ui7",
          cardContent: "DailyPuzzlesSidebar_cardContent__Dwxtn",
          solveNow: "DailyPuzzlesSidebar_solveNow__QJ_AX",
          list: "DailyPuzzlesSidebar_list__xRX0q",
          toPlayList: "DailyPuzzlesSidebar_toPlayList__unQtT",
          completedList: "DailyPuzzlesSidebar_completedList__Mjw8K",
          listRow: "DailyPuzzlesSidebar_listRow__Lm8Cr",
          completedRow: "DailyPuzzlesSidebar_completedRow__oIxKU",
          highlightNext: "DailyPuzzlesSidebar_highlightNext__bzWH7",
          highlightDone: "DailyPuzzlesSidebar_highlightDone__06xwO",
          replay: "DailyPuzzlesSidebar_replay__xgmoM",
        };
      },
      76436: (e, t, n) => {
        "use strict";
        n.d(t, { G: () => r });
        var a = n(55729);
        function r() {
          let e = a.useRef(new Map()),
            t = a.useRef(null),
            n = a.useCallback(() => {
              t.current = new Map(
                [...e.current].map((e) => {
                  let [t, n] = e;
                  return [t, n.getBoundingClientRect().top];
                })
              );
            }, []);
          return (
            a.useLayoutEffect(() => {
              if (!t.current) return;
              let n = t.current;
              (t.current = null),
                e.current.forEach((e, t) => {
                  let a = n.get(t);
                  if (void 0 === a) return;
                  let r = a - e.getBoundingClientRect().top;
                  0 !== r &&
                    e.animate(
                      [
                        { transform: `translateY(${r}px)` },
                        { transform: "none" },
                      ],
                      { duration: 250, easing: "cubic-bezier(0.16, 1, 0.3, 1)" }
                    );
                });
            }),
            {
              capture: n,
              ref: (t) => (n) => {
                n ? e.current.set(t, n) : e.current.delete(t);
              },
            }
          );
        }
      },
      77502: (e, t, n) => {
        "use strict";
        n.d(t, { EI: () => o, Pj: () => i, pn: () => l });
        var a = n(98417),
          r = n(46571);
        function l(e) {
          if (!(0, a.O)(e)) return null;
          let t = parseFloat(e);
          return Number.isNaN(t) ? null : t;
        }
        function i(e, t) {
          return (0, r.A)(e, t, { maximumFractionDigits: 2 });
        }
        function o(e, t) {
          let n = l(t);
          return (0, a.O)(n) ? i(e, n) : null;
        }
      },
      78339: (e) => {
        e.exports = {
          czyButton: "AdUnitAlternatives_czyButton___umGt",
          "czyButton--contained--purple":
            "AdUnitAlternatives_czyButton--contained--purple__4F1q1",
          "czyButton--contained--white":
            "AdUnitAlternatives_czyButton--contained--white__cv2cs",
          "czyButton--contained--grey":
            "AdUnitAlternatives_czyButton--contained--grey__tDD9t",
          "czyButton--contained--warning":
            "AdUnitAlternatives_czyButton--contained--warning__tMRcH",
          "czyButton--contained--alert":
            "AdUnitAlternatives_czyButton--contained--alert__nV_uV",
          "czyButton--contained--success":
            "AdUnitAlternatives_czyButton--contained--success__SJzZ4",
          "czyButton--contained--black":
            "AdUnitAlternatives_czyButton--contained--black__f89W6",
          "czyButton--contained--green-gradient":
            "AdUnitAlternatives_czyButton--contained--green-gradient__IEWo_",
          "czyButton--contained--animated-green-gradient":
            "AdUnitAlternatives_czyButton--contained--animated-green-gradient__4jpmK",
          "scroll-gradient": "AdUnitAlternatives_scroll-gradient__Xdf6z",
          "czyButton--outlined--purple":
            "AdUnitAlternatives_czyButton--outlined--purple__FVzXi",
          "czyButton--link--purple":
            "AdUnitAlternatives_czyButton--link--purple__telH_",
          "czyButton--outlined--white":
            "AdUnitAlternatives_czyButton--outlined--white__K2O2Y",
          "czyButton--link--white":
            "AdUnitAlternatives_czyButton--link--white__p8fXK",
          "czyButton--outlined--grey":
            "AdUnitAlternatives_czyButton--outlined--grey__pOazL",
          "czyButton--link--grey":
            "AdUnitAlternatives_czyButton--link--grey__4Tixr",
          "czyButton--outlined--warning":
            "AdUnitAlternatives_czyButton--outlined--warning__4G6j3",
          "czyButton--link--warning":
            "AdUnitAlternatives_czyButton--link--warning__a_utS",
          "czyButton--outlined--alert":
            "AdUnitAlternatives_czyButton--outlined--alert__vzUDK",
          "czyButton--link--alert":
            "AdUnitAlternatives_czyButton--link--alert__DITfG",
          "czyButton--outlined--success":
            "AdUnitAlternatives_czyButton--outlined--success__6uGLa",
          "czyButton--link--success":
            "AdUnitAlternatives_czyButton--link--success__nUHrh",
          "czyButton--outlined":
            "AdUnitAlternatives_czyButton--outlined__AeTzs",
          "czyButton--disabled":
            "AdUnitAlternatives_czyButton--disabled__hJi8Y",
          "czyButton--height50":
            "AdUnitAlternatives_czyButton--height50__OwbQU",
          "czyButton--height34":
            "AdUnitAlternatives_czyButton--height34__n4GBJ",
          "czyButton--height28":
            "AdUnitAlternatives_czyButton--height28__0LEbG",
          "czyButton--fullWidth":
            "AdUnitAlternatives_czyButton--fullWidth__PzSkC",
          "czyButton--headerIcon":
            "AdUnitAlternatives_czyButton--headerIcon__CZ_Kn",
          "czyButton--headerIcon--desktop":
            "AdUnitAlternatives_czyButton--headerIcon--desktop__4s_Bq",
          "czyButton--headerIcon--mobile":
            "AdUnitAlternatives_czyButton--headerIcon--mobile__DB7fB",
          "czyButton--headerIcon--withLabel":
            "AdUnitAlternatives_czyButton--headerIcon--withLabel__Cb_7C",
          adUnitPlaceholder: "AdUnitAlternatives_adUnitPlaceholder__XsD6j",
          wide: "AdUnitAlternatives_wide__28zVb",
          placeholderTitle: "AdUnitAlternatives_placeholderTitle__KVaAM",
          fontSize15: "AdUnitAlternatives_fontSize15__LZsbR",
          fontSize20: "AdUnitAlternatives_fontSize20__QAGk8",
          placeholderSubtitle: "AdUnitAlternatives_placeholderSubtitle__bKUf5",
          adUnitAlternative: "AdUnitAlternatives_adUnitAlternative___KK86",
          image: "AdUnitAlternatives_image__HbCbx",
          fontSize28: "AdUnitAlternatives_fontSize28__00cXM",
          secondLayout: "AdUnitAlternatives_secondLayout__3s3G4",
          iconButton: "AdUnitAlternatives_iconButton__RhOan",
          horBackground: "AdUnitAlternatives_horBackground__c87fr",
          squareBackground: "AdUnitAlternatives_squareBackground__cCUGh",
        };
      },
      86268: (e) => {
        e.exports = {
          countdown: "DailyResetCountdown_countdown__KJ5YH",
          time: "DailyResetCountdown_time__fpfQ5",
          hourglass: "DailyResetCountdown_hourglass__kjc7m",
        };
      },
      88748: (e, t, n) => {
        "use strict";
        n.d(t, { P4: () => i, VG: () => r, qP: () => l });
        var a = n(23942);
        let r = {
          limitAdFrequency: {
            label: "Limit midroll frequency",
            defaultAdmin: !1,
            defaultDev: !0,
            tooltip:
              "On CrazyGames we limit midrolls in favor of UX. Toggle to show every midroll.",
          },
          testAds: {
            label: "Include test ads",
            defaultAdmin: !0,
            defaultDev: !0,
            tooltip: "Show test ads instead of real ads.",
          },
          secretSkipVideoAndFallback: {
            label: "Skip video and fallback ads",
            defaultAdmin: !1,
            defaultDev: !1,
            tooltip: "Skip rewarded/midroll ads.",
          },
          enableUnityCache: {
            label: "Enable Unity Cache",
            defaultAdmin: !1,
            defaultDev: !1,
            tooltip:
              "Get Unity files from local cache; should be 'false' when measuring initial download size.",
          },
          instantJoin: {
            label: "Instant Multiplayer",
            defaultAdmin: !1,
            defaultDev: !1,
            tooltip:
              "Start the game as party host with 'instant multiplayer' setting.",
          },
          disableChat: {
            label: "Disable Chat setting",
            defaultAdmin: !1,
            defaultDev: !1,
            tooltip:
              "Start the game with user setting to disable chat enabled.",
          },
          sdkFailMode: {
            label: "Throw SDK Error",
            defaultAdmin: !1,
            defaultDev: !1,
            tooltip:
              "Force all SDK methods to throw errors, even those that don't usually throw. Example: for testing rewarded ad errors.",
          },
          sdk_debug: {
            label: "SDK Debug",
            defaultAdmin: !0,
            defaultDev: !0,
            tooltip: "Enable SDK debug logging.",
          },
        };
        function l(e, t) {
          let n = new URL(e, window.location.origin);
          return (
            Object.entries(t).forEach((e) => {
              let [a] = e;
              return n.searchParams.set(a, `${t[a]}`);
            }),
            n.toString()
          );
        }
        function i() {
          let e = new URLSearchParams(window.location.search),
            t = "admin" === e.get(a.S),
            n = {};
          Object.entries(r).forEach((e) => {
            let [a, r] = e;
            n[a] = t ? r.defaultAdmin : r.defaultDev;
          });
          let l = e.get("initialDisableChatQaOption");
          null !== l && (n.disableChat = "true" === l);
          let i = e.get("initialInstantMultiplayerQaOption");
          return null !== i && (n.instantJoin = "true" === i), n;
        }
      },
      96834: (e, t, n) => {
        "use strict";
        n.d(t, { l: () => a });
        let a = {
          brand: {
            0: "#fff",
            20: "#E1D9FF",
            30: "#D2C6FF",
            40: "#C3B3FF",
            50: "#B4A1FF",
            60: "#A48EFF",
            70: "#957BFF",
            80: "#8668FF",
            100: "#6842FF",
            120: "#5335CC",
            130: "#492EB3",
            140: "#3E2899",
            150: "#342180",
            160: "#2A1A66",
            180: "#150D33",
            200: "#07050F",
          },
          black: {
            10: "#474967",
            20: "#434561",
            40: "#373952",
            50: "#2F3148",
            60: "#28293D",
            70: "#212233",
            80: "#1A1B28",
            90: "#13141E",
            100: "#0C0D14",
          },
          white: {
            10: "#666A7F",
            20: "#767A8E",
            30: "#878A9E",
            40: "#989BAE",
            50: "#AAADBE",
            60: "#BDBFCE",
            70: "#D0D2DE",
            80: "#E5E6EE",
            90: "#EFF0F7",
            100: "#F9FAFF",
          },
          success: { 100: "#4AF0A7" },
          alert: { 60: "#F16E9D", 80: "#EC3D7D", 100: "#E70D5C" },
          warning: { 100: "#FFAC4A", 200: "#3C2A16" },
        };
      },
      97429: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.BADGE_ORDER =
            t.PERCENT_THRESHOLDS =
            t.SEASON_END_AWARDS_CONFIG =
            t.PODIUM_AWARDS =
              void 0),
          (t.PODIUM_AWARDS = [
            { position: 1, name: "gold" },
            { position: 2, name: "silver" },
            { position: 3, name: "bronze" },
          ]);
        let n = { percentage: 0.01, name: "level_4" },
          a = { percentage: 0.05, name: "level_5" },
          r = { percentage: 0.1, name: "level_6" };
        (t.SEASON_END_AWARDS_CONFIG = [n, a, r]),
          (t.PERCENT_THRESHOLDS = {
            level_4: n.percentage,
            level_5: a.percentage,
            level_6: r.percentage,
            default: 1,
          }),
          (t.BADGE_ORDER = [
            "gold",
            "silver",
            "bronze",
            "level_4",
            "level_5",
            "level_6",
            "default",
          ]);
      },
    },
  ]);
