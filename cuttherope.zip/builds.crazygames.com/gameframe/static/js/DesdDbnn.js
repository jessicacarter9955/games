!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "2f0b6938-cf0a-5eba-bf0d-3188c9eae556"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `f99103c1-0e13-4925-82f5-fd70e0295577`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-f99103c1-0e13-4925-82f5-fd70e0295577`));
  } catch {}
})();
import { Wt as e, pn as t } from "../../bundle.js";
var n = 0.01,
  r = class {
    constructor() {
      t(this, `lastReportedProgress`, void 0),
        t(this, `currentProgress`, 0),
        t(this, `passedFirstIncrement`, !1);
    }
    reset() {
      (this.lastReportedProgress = void 0),
        (this.currentProgress = 0),
        (this.passedFirstIncrement = !1);
    }
    trackLoadStarted() {
      e.trackProgress(0), (this.lastReportedProgress = 0), e.gameStartLoad();
    }
    trackProgress(t) {
      if (t <= this.currentProgress) return this.currentProgress;
      this.currentProgress = t;
      let r = Math.floor(t * 10) / 10;
      return (
        r !== 1 &&
          t > 0 &&
          (!this.passedFirstIncrement && t >= 0.01 && t < 0.1
            ? ((this.passedFirstIncrement = !0),
              e.trackProgress(n),
              (this.lastReportedProgress = t))
            : ((!this.lastReportedProgress && t > 0.1) ||
                (this.lastReportedProgress &&
                  t > this.lastReportedProgress + 0.1)) &&
              (e.trackProgress(r), (this.lastReportedProgress = t))),
        t
      );
    }
    trackLoadFinished() {
      this.lastReportedProgress !== 1 &&
        ((this.lastReportedProgress = 1), e.trackProgress(1), e.loadFinished());
    }
  };
export { r as t };
//# debugId=2f0b6938-cf0a-5eba-bf0d-3188c9eae556
