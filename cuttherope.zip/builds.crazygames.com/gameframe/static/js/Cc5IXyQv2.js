!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "83bccccb-0439-5067-a030-ad67368091d2"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `7ec02ff0-28a2-4427-a77c-b46a0bfb6c9a`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-7ec02ff0-28a2-4427-a77c-b46a0bfb6c9a`));
  } catch {}
})();
import {
  Jt as e,
  Kt as t,
  Sn as n,
  cn as r,
  ct as i,
  ft as a,
  gn as o,
  gt as s,
  ht as c,
  nt as l,
  rn as u,
  un as d,
  yn as f,
} from "../../bundle.js";
var p = n(f()),
  m = r(),
  h = n(c()),
  g = {
    content: `_content_12fl0_7`,
    close: `_close_12fl0_13`,
    closeIcon: `_closeIcon_12fl0_34`,
    body: `_body_12fl0_38`,
    preview: `_preview_12fl0_48`,
    previewImage: `_previewImage_12fl0_53`,
    title: `_title_12fl0_58`,
    description: `_description_12fl0_64`,
    actions: `_actions_12fl0_71`,
    button: `_button_12fl0_77`,
  },
  _ = o();
function v(t) {
  e.getInstance().sendEvent({
    type: `notificationAction`,
    notificationSource: `chrome-pointer-warning`,
    action: t,
  });
}
var y = `PointerKey_count`,
  b = `PointerKey_lastTime`,
  x = p.lazy(() => d(() => import(`../../bundle.js`), [], import.meta.url)),
  S = () => {
    let e = (0, m.c)(10),
      [n, r] = p.useState(!1),
      o = u().device?.browser,
      c;
    e[0] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((c = () => {
          v(`closed`), r(!1);
        }),
        (e[0] = c))
      : (c = e[0]);
    let d = c,
      f;
    e[1] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((f = () => {
          r(!1), v(`ignored`);
        }),
        (e[1] = f))
      : (f = e[1]);
    let S = f,
      C;
    e[2] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((C = () => {
          r(!1), v(`continue`);
        }),
        (e[2] = C))
      : (C = e[2]);
    let w = C,
      T,
      E;
    e[3] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((T = () => {
          let e = async function () {
              let e = u().device?.browser,
                n = e?.name === `Chrome`,
                i = e?.name === `Opera`,
                a = n && e.major && parseInt(e.major) >= 131,
                o = i && e.major && parseInt(e.major) >= 118;
              if (
                (a || o) &&
                (await navigator.permissions.query({ name: `pointer-lock` }))
                  .state === `denied`
              ) {
                let n = `${e?.name?.toLowerCase()}${y}`,
                  i = `${e?.name?.toLowerCase()}${b}`,
                  a = t.Instance.getItem(n) ?? `1`,
                  o = t.Instance.getItem(i),
                  s = Date.now() - 3e5,
                  c = o ? new Date(o).getTime() : 0;
                Number.parseInt(a) <= 5 &&
                  c < s &&
                  (t.Instance.setItem(n, `${Number.parseInt(a) + 1}`),
                  t.Instance.setItem(i, `${new Date()}`),
                  v(`shown`),
                  r(!0));
              }
            },
            n = (0, h.default)(async () => {
              try {
                await e();
              } catch (e) {
                console.error(e);
              }
            }, 300);
          return n(), () => n.cancel();
        }),
        (E = []),
        (e[3] = T),
        (e[4] = E))
      : ((T = e[3]), (E = e[4])),
      p.useEffect(T, E);
    let D =
      o?.name === `Chrome`
        ? `chrome_pointer_permissions_v2.png`
        : `opera_pointer_permissions.png`;
    if (n) {
      let t;
      e[5] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((t = (0, _.jsx)(`button`, {
            type: `button`,
            className: g.close,
            onClick: d,
            children: (0, _.jsx)(a, {
              name: `close`,
              size: 20,
              className: g.closeIcon,
            }),
          })),
          (e[5] = t))
        : (t = e[5]);
      let n;
      e[6] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((n = (0, _.jsxs)(`div`, {
            className: g.body,
            children: [
              (0, _.jsx)(`div`, {
                className: g.preview,
                children: (0, _.jsx)(`img`, {
                  src: s(D, { quality: 100 }),
                  alt: `Mouse permissions disabled`,
                  className: g.previewImage,
                }),
              }),
              (0, _.jsx)(`h2`, {
                className: g.title,
                children: `Mouse permissions disabled`,
              }),
              (0, _.jsx)(`p`, {
                className: g.description,
                children: `To ensure all games run smoothly, CrazyGames needs browser permission to lock your mouse.`,
              }),
            ],
          })),
          (e[6] = n))
        : (n = e[6]);
      let r;
      e[7] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((r = (0, _.jsxs)(`div`, {
            className: g.actions,
            children: [
              (0, _.jsx)(l, {
                variant: `outlined`,
                color: `white`,
                height: 34,
                className: g.button,
                onClick: S,
                children: `Ignore`,
              }),
              (0, _.jsx)(l, {
                variant: `contained`,
                height: 34,
                className: g.button,
                onClick: w,
                children: `Done`,
              }),
            ],
          })),
          (e[7] = r))
        : (r = e[7]);
      let o;
      return (
        e[8] === n
          ? (o = e[9])
          : ((o = (0, _.jsx)(p.Suspense, {
              children: (0, _.jsx)(x, {
                hideBackdrop: !0,
                children: (0, _.jsxs)(i, {
                  className: g.content,
                  children: [t, n, r],
                }),
              }),
            })),
            (e[8] = n),
            (e[9] = o)),
        o
      );
    }
    return null;
  };
export { S as default };
//# debugId=83bccccb-0439-5067-a030-ad67368091d2
