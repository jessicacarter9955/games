(function () {
  var aa =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            function b() {}
            b.prototype = a;
            return new b();
          },
    ba =
      typeof Object.defineProperties == "function"
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          };
  function ca(a) {
    a = [
      "object" == typeof globalThis && globalThis,
      a,
      "object" == typeof window && window,
      "object" == typeof self && self,
      "object" == typeof global && global,
    ];
    for (var b = 0; b < a.length; ++b) {
      var c = a[b];
      if (c && c.Math == Math) return c;
    }
    throw Error("Cannot find global object");
  }
  var p = ca(this);
  function r(a, b) {
    if (b)
      a: {
        var c = p;
        a = a.split(".");
        for (var d = 0; d < a.length - 1; d++) {
          var f = a[d];
          if (!(f in c)) break a;
          c = c[f];
        }
        a = a[a.length - 1];
        d = c[a];
        b = b(d);
        b != d &&
          b != null &&
          ba(c, a, { configurable: !0, writable: !0, value: b });
      }
  }
  var da;
  if (typeof Object.setPrototypeOf == "function") da = Object.setPrototypeOf;
  else {
    var ea;
    a: {
      var fa = { a: !0 },
        ha = {};
      try {
        ha.__proto__ = fa;
        ea = ha.a;
        break a;
      } catch (a) {}
      ea = !1;
    }
    da = ea
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var ia = da;
  function ja(a, b) {
    a.prototype = aa(b.prototype);
    a.prototype.constructor = a;
    if (ia) ia(a, b);
    else
      for (var c in b)
        if (c != "prototype")
          if (Object.defineProperties) {
            var d = Object.getOwnPropertyDescriptor(b, c);
            d && Object.defineProperty(a, c, d);
          } else a[c] = b[c];
    a.aa = b.prototype;
  }
  function ka(a) {
    var b = 0;
    return function () {
      return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
    };
  }
  function la(a) {
    var b =
      typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
    if (b) return b.call(a);
    if (typeof a.length == "number") return { next: ka(a) };
    throw Error(String(a) + " is not an iterable or ArrayLike");
  }
  function ma() {
    for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
      b[c - a] = arguments[c];
    return b;
  }
  r("globalThis", function (a) {
    return a || p;
  });
  r("Promise", function (a) {
    function b(e) {
      this.i = 0;
      this.j = void 0;
      this.h = [];
      this.u = !1;
      var g = this.l();
      try {
        e(g.resolve, g.reject);
      } catch (k) {
        g.reject(k);
      }
    }
    function c() {
      this.h = null;
    }
    function d(e) {
      return e instanceof b
        ? e
        : new b(function (g) {
            g(e);
          });
    }
    if (a) return a;
    c.prototype.i = function (e) {
      if (this.h == null) {
        this.h = [];
        var g = this;
        this.j(function () {
          g.m();
        });
      }
      this.h.push(e);
    };
    var f = p.setTimeout;
    c.prototype.j = function (e) {
      f(e, 0);
    };
    c.prototype.m = function () {
      for (; this.h && this.h.length; ) {
        var e = this.h;
        this.h = [];
        for (var g = 0; g < e.length; ++g) {
          var k = e[g];
          e[g] = null;
          try {
            k();
          } catch (l) {
            this.l(l);
          }
        }
      }
      this.h = null;
    };
    c.prototype.l = function (e) {
      this.j(function () {
        throw e;
      });
    };
    b.prototype.l = function () {
      function e(l) {
        return function (m) {
          k || ((k = !0), l.call(g, m));
        };
      }
      var g = this,
        k = !1;
      return { resolve: e(this.D), reject: e(this.m) };
    };
    b.prototype.D = function (e) {
      if (e === this)
        this.m(new TypeError("A Promise cannot resolve to itself"));
      else if (e instanceof b) this.G(e);
      else {
        a: switch (typeof e) {
          case "object":
            var g = e != null;
            break a;
          case "function":
            g = !0;
            break a;
          default:
            g = !1;
        }
        g ? this.C(e) : this.o(e);
      }
    };
    b.prototype.C = function (e) {
      var g = void 0;
      try {
        g = e.then;
      } catch (k) {
        this.m(k);
        return;
      }
      typeof g == "function" ? this.H(g, e) : this.o(e);
    };
    b.prototype.m = function (e) {
      this.v(2, e);
    };
    b.prototype.o = function (e) {
      this.v(1, e);
    };
    b.prototype.v = function (e, g) {
      if (this.i != 0)
        throw Error(
          "Cannot settle(" +
            e +
            ", " +
            g +
            "): Promise already settled in state" +
            this.i
        );
      this.i = e;
      this.j = g;
      this.i === 2 && this.F();
      this.A();
    };
    b.prototype.F = function () {
      var e = this;
      f(function () {
        if (e.B()) {
          var g = p.console;
          typeof g !== "undefined" && g.error(e.j);
        }
      }, 1);
    };
    b.prototype.B = function () {
      if (this.u) return !1;
      var e = p.CustomEvent,
        g = p.Event,
        k = p.dispatchEvent;
      if (typeof k === "undefined") return !0;
      typeof e === "function"
        ? (e = new e("unhandledrejection", { cancelable: !0 }))
        : typeof g === "function"
        ? (e = new g("unhandledrejection", { cancelable: !0 }))
        : ((e = p.document.createEvent("CustomEvent")),
          e.initCustomEvent("unhandledrejection", !1, !0, e));
      e.promise = this;
      e.reason = this.j;
      return k(e);
    };
    b.prototype.A = function () {
      if (this.h != null) {
        for (var e = 0; e < this.h.length; ++e) h.i(this.h[e]);
        this.h = null;
      }
    };
    var h = new c();
    b.prototype.G = function (e) {
      var g = this.l();
      e.I(g.resolve, g.reject);
    };
    b.prototype.H = function (e, g) {
      var k = this.l();
      try {
        e.call(g, k.resolve, k.reject);
      } catch (l) {
        k.reject(l);
      }
    };
    b.prototype.then = function (e, g) {
      function k(n, t) {
        return typeof n == "function"
          ? function (w) {
              try {
                l(n(w));
              } catch (y) {
                m(y);
              }
            }
          : t;
      }
      var l,
        m,
        q = new b(function (n, t) {
          l = n;
          m = t;
        });
      this.I(k(e, l), k(g, m));
      return q;
    };
    b.prototype.catch = function (e) {
      return this.then(void 0, e);
    };
    b.prototype.I = function (e, g) {
      function k() {
        switch (l.i) {
          case 1:
            e(l.j);
            break;
          case 2:
            g(l.j);
            break;
          default:
            throw Error("Unexpected state: " + l.i);
        }
      }
      var l = this;
      this.h == null ? h.i(k) : this.h.push(k);
      this.u = !0;
    };
    b.resolve = d;
    b.reject = function (e) {
      return new b(function (g, k) {
        k(e);
      });
    };
    b.race = function (e) {
      return new b(function (g, k) {
        for (var l = la(e), m = l.next(); !m.done; m = l.next())
          d(m.value).I(g, k);
      });
    };
    b.all = function (e) {
      var g = la(e),
        k = g.next();
      return k.done
        ? d([])
        : new b(function (l, m) {
            function q(w) {
              return function (y) {
                n[w] = y;
                t--;
                t == 0 && l(n);
              };
            }
            var n = [],
              t = 0;
            do
              n.push(void 0),
                t++,
                d(k.value).I(q(n.length - 1), m),
                (k = g.next());
            while (!k.done);
          });
    };
    return b;
  });
  r("Object.is", function (a) {
    return a
      ? a
      : function (b, c) {
          return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c;
        };
  });
  r("Number.isFinite", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b !== "number"
            ? !1
            : !isNaN(b) && b !== Infinity && b !== -Infinity;
        };
  });
  r("Number.MAX_SAFE_INTEGER", function () {
    return 9007199254740991;
  });
  r("Number.MIN_SAFE_INTEGER", function () {
    return -9007199254740991;
  });
  r("Number.isNaN", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b === "number" && isNaN(b);
        };
  }); /* 
 
 Copyright The Closure Library Authors. 
 SPDX-License-Identifier: Apache-2.0 
*/
  var u = this || self;
  function na(a) {
    u.setTimeout(function () {
      throw a;
    }, 0);
  }
  var oa, v;
  a: {
    for (var pa = ["CLOSURE_FLAGS"], z = u, qa = 0; qa < pa.length; qa++)
      if (((z = z[pa[qa]]), z == null)) {
        v = null;
        break a;
      }
    v = z;
  }
  var ra = v && v[748402147];
  oa = ra != null ? ra : !0;
  var sa = Array.prototype.indexOf
      ? function (a, b) {
          return Array.prototype.indexOf.call(a, b, void 0);
        }
      : function (a, b) {
          if (typeof a === "string")
            return typeof b !== "string" || b.length != 1
              ? -1
              : a.indexOf(b, 0);
          for (var c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
          return -1;
        },
    ta = Array.prototype.forEach
      ? function (a, b) {
          Array.prototype.forEach.call(a, b, void 0);
        }
      : function (a, b) {
          for (
            var c = a.length,
              d = typeof a === "string" ? a.split("") : a,
              f = 0;
            f < c;
            f++
          )
            f in d && b.call(void 0, d[f], f, a);
        };
  function ua(a) {
    ua[" "](a);
    return a;
  }
  ua[" "] = function () {};
  var va = void 0;
  var wa = typeof Symbol === "function" && typeof Symbol() === "symbol";
  function xa(a, b, c) {
    return typeof Symbol === "function" && typeof Symbol() === "symbol"
      ? (c === void 0 ? 0 : c) && Symbol.for && a
        ? Symbol.for(a)
        : a != null
        ? Symbol(a)
        : Symbol()
      : b;
  }
  var ya = xa("jas", void 0, !0),
    za = xa(void 0, "0actk"),
    A = xa("m_m", "Z", !0);
  var Aa = { W: { value: 0, configurable: !0, writable: !0, enumerable: !1 } },
    Ba = Object.defineProperties,
    B = wa ? ya : "W";
  function Ca(a, b) {
    wa || B in a || Ba(a, Aa);
    a[B] |= b;
  }
  function C(a, b) {
    wa || B in a || Ba(a, Aa);
    a[B] = b;
  }
  var E = {};
  function F(a, b) {
    return b === void 0
      ? a.i !== G && !!(2 & (a.h[B] | 0))
      : !!(2 & b) && a.i !== G;
  }
  var G = {};
  function Da(a) {
    a.Y = !0;
    return a;
  }
  var Ea = Da(function (a) {
      return typeof a === "number";
    }),
    Fa = Da(function (a) {
      return typeof a === "string";
    });
  var Ga = typeof u.BigInt === "function" && typeof u.BigInt(0) === "bigint";
  var Qa = Da(function (a) {
      return Ga ? a >= Ha && a <= Ia : a[0] === "-" ? Ja(a, Oa) : Ja(a, Pa);
    }),
    Oa = Number.MIN_SAFE_INTEGER.toString(),
    Ha = Ga ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
    Pa = Number.MAX_SAFE_INTEGER.toString(),
    Ia = Ga ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;
  function Ja(a, b) {
    if (a.length > b.length) return !1;
    if (a.length < b.length || a === b) return !0;
    for (var c = 0; c < a.length; c++) {
      var d = a[c],
        f = b[c];
      if (d > f) return !1;
      if (d < f) return !0;
    }
  }
  var Ra = Number.isFinite;
  function Sa(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return Ra(a) ? a | 0 : void 0;
  }
  function Ta(a) {
    return a;
  }
  function Ua(a, b, c, d) {
    var f = d !== void 0;
    d = !!d;
    var h = [],
      e = a.length,
      g = 4294967295,
      k = !1,
      l = !!(b & 64),
      m = l ? (b & 128 ? 0 : -1) : void 0;
    if (!(b & 1)) {
      var q = e && a[e - 1];
      q != null && typeof q === "object" && q.constructor === Object
        ? (e--, (g = e))
        : (q = void 0);
      if (l && !(b & 128) && !f) {
        k = !0;
        var n;
        g = ((n = Va) != null ? n : Ta)(g - m, m, a, q, void 0) + m;
      }
    }
    b = void 0;
    for (f = 0; f < e; f++)
      if (((n = a[f]), n != null && (n = c(n, d)) != null))
        if (l && f >= g) {
          var t = f - m,
            w = void 0;
          ((w = b) != null ? w : (b = {}))[t] = n;
        } else h[f] = n;
    if (q)
      for (var y in q)
        (a = q[y]),
          a != null &&
            (a = c(a, d)) != null &&
            ((e = +y),
            (f = void 0),
            l && !Number.isNaN(e) && (f = e + m) < g
              ? (h[f] = a)
              : ((e = void 0), (((e = b) != null ? e : (b = {}))[y] = a)));
    b && (k ? h.push(b) : (h[g] = b));
    return h;
  }
  function Wa(a) {
    switch (typeof a) {
      case "number":
        return Number.isFinite(a) ? a : "" + a;
      case "bigint":
        return Qa(a) ? Number(a) : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          var b = a[B] | 0;
          return a.length === 0 && b & 1 ? void 0 : Ua(a, b, Wa);
        }
        if (a != null && a[A] === E) return Xa(a);
        return;
    }
    return a;
  }
  var Va;
  function Xa(a) {
    a = a.h;
    return Ua(a, a[B] | 0, Wa);
  }
  function Ya(a, b, c, d) {
    d = d === void 0 ? 0 : d;
    if (a == null) {
      var f = 32;
      c ? ((a = [c]), (f |= 128)) : (a = []);
      b && (f = (f & -16760833) | ((b & 1023) << 14));
    } else {
      if (!Array.isArray(a)) throw Error("narr");
      f = a[B] | 0;
      if (oa && 1 & f) throw Error("rfarr");
      2048 & f && !(2 & f) && Za();
      if (f & 256) throw Error("farr");
      if (f & 64) return (f | d) !== f && C(a, f | d), a;
      if (c && ((f |= 128), c !== a[0])) throw Error("mid");
      a: {
        c = a;
        f |= 64;
        var h = c.length;
        if (h) {
          var e = h - 1,
            g = c[e];
          if (g != null && typeof g === "object" && g.constructor === Object) {
            b = f & 128 ? 0 : -1;
            e -= b;
            if (e >= 1024) throw Error("pvtlmt");
            for (var k in g)
              (h = +k), h < e && ((c[h + b] = g[k]), delete g[k]);
            f = (f & -16760833) | ((e & 1023) << 14);
            break a;
          }
        }
        if (b) {
          k = Math.max(b, h - (f & 128 ? 0 : -1));
          if (k > 1024) throw Error("spvt");
          f = (f & -16760833) | ((k & 1023) << 14);
        }
      }
    }
    C(a, f | 64 | d);
    return a;
  }
  function Za() {
    if (oa) throw Error("carr");
    if (za != null) {
      var a;
      var b = (a = va) != null ? a : (va = {});
      a = b[za] || 0;
      a >= 5 ||
        ((b[za] = a + 1),
        (b = Error()),
        b.__closure__error__context__984382 ||
          (b.__closure__error__context__984382 = {}),
        (b.__closure__error__context__984382.severity = "incident"),
        na(b));
    }
  }
  function $a(a, b) {
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      var c = a[B] | 0;
      a.length === 0 && c & 1
        ? (a = void 0)
        : c & 2 ||
          (!b || 4096 & c || 16 & c
            ? (a = H(a, c, !1, b && !(c & 16)))
            : (Ca(a, 34), c & 4 && Object.freeze(a)));
      return a;
    }
    if (a != null && a[A] === E)
      return (
        (b = a.h),
        (c = b[B] | 0),
        F(a, c) ? a : ab(a, b, c) ? bb(a, b) : H(b, c)
      );
  }
  function bb(a, b, c) {
    a = new a.constructor(b);
    c && (a.i = G);
    a.j = G;
    return a;
  }
  function H(a, b, c, d) {
    d != null || (d = !!(34 & b));
    a = Ua(a, b, $a, d);
    d = 32;
    c && (d |= 2);
    b = (b & 16769217) | d;
    C(a, b);
    return a;
  }
  function cb(a, b) {
    b === void 0 && (b = a[B] | 0);
    b & 32 && !(b & 4096) && C(a, b | 4096);
  }
  function ab(a, b, c) {
    return c & 2
      ? !0
      : c & 32 && !(c & 4096)
      ? (C(b, c | 2), (a.i = G), !0)
      : !1;
  }
  function db(a, b) {
    a = eb(a.h, b);
    if (a !== null) return a;
  }
  function fb(a, b) {
    return eb(a, 1, void 0, b);
  }
  function eb(a, b, c, d) {
    if (b === -1) return null;
    var f = b + (c ? 0 : -1),
      h = a.length - 1;
    if (!(h < 1 + (c ? 0 : -1))) {
      if (f >= h) {
        var e = a[h];
        if (e != null && typeof e === "object" && e.constructor === Object) {
          c = e[b];
          var g = !0;
        } else if (f === h) c = e;
        else return;
      } else c = a[f];
      if (d && c != null) {
        d = d(c);
        if (d == null) return d;
        if (!Object.is(d, c)) return g ? (e[b] = d) : (a[f] = d), d;
      }
      return c;
    }
  }
  function gb(a) {
    a = eb(a.h, 1);
    return (a != null && a[A] === E) || Array.isArray(a);
  }
  function hb(a, b) {
    var c = ib,
      d = !1,
      f = fb(a, function (h) {
        if (h != null && h[A] === E) var e = h;
        else if (Array.isArray(h)) {
          e = h[B] | 0;
          var g = e | (b & 32);
          g |= b & 2;
          g !== e && C(h, g);
          e = new c(h);
        } else e = void 0;
        d = e !== h && e != null;
        return e;
      });
    if (f != null) return d && !F(f) && cb(a, b), f;
  }
  function jb(a) {
    var b = a.h,
      c = b[B] | 0,
      d = hb(b, c);
    if (d == null) return d;
    c = b[B] | 0;
    if (!F(a, c)) {
      var f = d;
      var h = f.h,
        e = h[B] | 0;
      f = F(f, e)
        ? ab(f, h, e)
          ? bb(f, h, !0)
          : new f.constructor(H(h, e, !1))
        : f;
      if (f !== d) {
        a.i === G
          ? ((d = a.h),
            (d = H(d, d[B] | 0)),
            Ca(d, 2048),
            (a.h = d),
            (a.i = void 0),
            (a.j = void 0),
            (d = !0))
          : (d = !1);
        d && ((b = a.h), (c = b[B] | 0));
        d = f;
        a: {
          a = b;
          f = d;
          h = a.length - 1;
          if (
            h >= 0 &&
            0 >= h &&
            ((e = a[h]),
            e != null && typeof e === "object" && e.constructor === Object)
          ) {
            e[1] = f;
            break a;
          }
          if (0 <= h) a[0] = f;
          else if (f !== void 0) {
            var g;
            h =
              (((g = c) != null ? g : (c = a[B] | 0)) >> 14) & 1023 ||
              536870912;
            1 >= h
              ? f != null && ((g = {}), (a[h + -1] = ((g[1] = f), g)))
              : (a[0] = f);
          }
        }
        cb(b, c);
      }
    }
    return d;
  }
  function I(a, b) {
    a = db(a, b);
    return a == null || typeof a === "string" ? a : void 0;
  }
  function J(a, b) {
    a = db(a, b);
    a =
      a == null || typeof a === "boolean"
        ? a
        : typeof a === "number"
        ? !!a
        : void 0;
    return a != null ? a : !1;
  }
  function K(a, b) {
    var c = c === void 0 ? 0 : c;
    a = Sa(db(a, b));
    return a != null ? a : c;
  }
  function M(a, b) {
    var c;
    return (c = I(a, b)) != null ? c : "";
  }
  function N(a, b, c) {
    this.h = Ya(a, b, c, 2048);
  }
  N.prototype.toJSON = function () {
    return Xa(this);
  };
  N.prototype[A] = E;
  function ib(a) {
    this.h = Ya(a, void 0, void 0, 2048);
  }
  ja(ib, N);
  function kb(a) {
    this.h = Ya(a, void 0, void 0, 2048);
  }
  ja(kb, N);
  var lb = (function (a) {
    return function (b) {
      if (b == null || b == "") b = new a();
      else {
        b = JSON.parse(b);
        if (!Array.isArray(b)) throw Error("dnarr");
        Ca(b, 32);
        b = new a(b);
      }
      return b;
    };
  })(kb);
  function mb(a, b) {
    if (a)
      for (var c in a)
        Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a);
  }
  function nb(a) {
    var b = !1,
      c;
    return function () {
      b || ((c = a()), (b = !0));
      return c;
    };
  } /* 
 
 Copyright Google LLC 
 SPDX-License-Identifier: Apache-2.0 
*/
  var ob = globalThis.trustedTypes,
    pb;
  function qb() {
    var a = null;
    if (!ob) return a;
    try {
      var b = function (c) {
        return c;
      };
      a = ob.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (c) {}
    return a;
  }
  function rb(a) {
    this.h = a;
  }
  rb.prototype.toString = function () {
    return this.h + "";
  };
  function sb(a, b) {
    b = b === void 0 ? document : b;
    return b.createElement(String(a).toLowerCase());
  }
  function O(a) {
    var b = document;
    return typeof a === "string" ? b.getElementById(a) : a;
  }
  function tb(a) {
    var b = document;
    if (b.getElementsByClassName) a = b.getElementsByClassName(a)[0];
    else {
      b = document;
      var c;
      a
        ? (c = b.querySelector(a ? "." + a : ""))
        : (c =
            (a
              ? b.querySelectorAll(a ? "." + a : "")
              : b.getElementsByTagName("*"))[0] || null);
      a = c;
    }
    return a || null;
  }
  function ub(a) {
    a && a.parentNode && a.parentNode.removeChild(a);
  }
  var vb = { passive: !0 },
    wb = nb(function () {
      var a = !1;
      try {
        var b = Object.defineProperty({}, "passive", {
          get: function () {
            a = !0;
          },
        });
        u.addEventListener("test", null, b);
      } catch (c) {}
      return a;
    });
  function xb(a) {
    return a ? (a.passive && wb() ? a : a.capture || !1) : !1;
  }
  function P(a, b, c, d) {
    typeof a.addEventListener === "function" && a.addEventListener(b, c, xb(d));
  }
  function Q(a) {
    a.preventDefault ? a.preventDefault() : (a.returnValue = !1);
  }
  function yb(a, b, c, d) {
    zb(a, b, c === void 0 ? null : c, d === void 0 ? !1 : d);
  }
  function zb(a, b, c, d) {
    var f = !1;
    f = f === void 0 ? !1 : f;
    a.google_image_requests || (a.google_image_requests = []);
    var h = sb("IMG", a.document);
    if (c || d) {
      var e = function (g) {
        c && c(g);
        if (d) {
          g = a.google_image_requests;
          var k = sa(g, h);
          k >= 0 && Array.prototype.splice.call(g, k, 1);
        }
        typeof h.removeEventListener === "function" &&
          h.removeEventListener("load", e, xb());
        typeof h.removeEventListener === "function" &&
          h.removeEventListener("error", e, xb());
      };
      P(h, "load", e);
      P(h, "error", e);
    }
    f && (h.attributionSrc = "");
    h.src = b;
    a.google_image_requests.push(h);
  }
  function Ab(a, b) {
    var c = c === void 0 ? !1 : c;
    var d;
    if ((d = a.navigator))
      (d = a.navigator.userAgent), (d = !(!/Chrome/.test(d) || /Edge/.test(d)));
    d && typeof a.navigator.sendBeacon === "function"
      ? a.navigator.sendBeacon(b)
      : yb(a, b, void 0, c);
  }
  var Bb = 0;
  function Cb(a) {
    return ((a = Hb(a)) && a.getAttribute("data-jc-version")) || "unknown";
  }
  function Hb(a) {
    var b = document.currentScript;
    return (b = b === void 0 ? null : b) &&
      b.getAttribute("data-jc") === String(a)
      ? b
      : document.querySelector('[data-jc="' + a + '"]');
  }
  function Kb() {
    var a = a === void 0 ? 0.01 : a;
    if (!(Math.random() > a)) {
      var b = Hb(60);
      a =
        "https://" +
        (b && b.getAttribute("data-jc-rcd") === "true"
          ? "pagead2.googlesyndication-cn.com"
          : "pagead2.googlesyndication.com") +
        "/pagead/gen_204?id=jca&jc=60&version=" +
        Cb(60) +
        "&sample=" +
        a;
      Ab(window, a);
    }
  }
  var Lb = document,
    R = window;
  function Mb(a) {
    return typeof a.className == "string"
      ? a.className
      : (a.getAttribute && a.getAttribute("class")) || "";
  }
  function Nb(a, b) {
    a.classList
      ? (b = a.classList.contains(b))
      : ((a = a.classList ? a.classList : Mb(a).match(/\S+/g) || []),
        (b = sa(a, b) >= 0));
    return b;
  }
  function S(a, b) {
    if (a.classList) a.classList.add(b);
    else if (!Nb(a, b)) {
      var c = Mb(a);
      b = c + (c.length > 0 ? " " + b : b);
      typeof a.className == "string"
        ? (a.className = b)
        : a.setAttribute && a.setAttribute("class", b);
    }
  }
  function Ob(a) {
    this.serializedAttributionData = Xa(a);
    var b = a.h,
      c = b[B] | 0;
    this.h = ab(a, b, c) ? bb(a, b, !0) : new a.constructor(H(b, c, !1));
    if ((a = gb(this.h))) (a = jb(this.h)), (a = !!J(a, 33));
    this.isMutableImpression = a;
    this.T = !!J(this.h, 11);
    this.hasUserFeedbackData = !!this.h && gb(this.h);
    this.M = !!J(this.h, 4);
    this.P = !!J(this.h, 6);
    this.L = !!J(this.h, 13);
    K(this.h, 8);
    this.creativeIndexSuffix = K(this.h, 8) > 1 ? K(this.h, 7).toString() : "";
    I(this.h, 34) != null &&
      (this.creativeIndexSuffix =
        M(this.h, 34) + "_" + this.creativeIndexSuffix);
    this.U = !!J(this.h, 17);
    this.S = !!J(this.h, 18);
    this.K = !!J(this.h, 14);
    this.F = !!J(this.h, 15);
    this.V = !!J(this.h, 31);
    this.R = J(this.h, 9) == 1;
    this.openAttributionInline = J(this.h, 10) == 1;
    this.isMobileDevice = !!J(this.h, 12);
    this.C = null;
    this.O = (a = Lb.querySelector("[data-slide]"))
      ? a.getAttribute("data-slide") === "true"
      : !1;
    (this.H = K(this.h, 8) > 1) &&
      R.goog_multislot_cache === void 0 &&
      (R.goog_multislot_cache = {});
    this.H && !this.O
      ? ((a = R.goog_multislot_cache.hd),
        a === void 0 &&
          ((a = !1),
          (b = Lb.querySelector("[data-dim]"))
            ? ((b = b.getBoundingClientRect()),
              b.right - b.left >= 150 && b.bottom - b.top >= 150
                ? (a = !1)
                : ((c = document.body.getBoundingClientRect()),
                  (Math.abs(c.left - b.left) <= 1 &&
                  Math.abs(c.right - b.right) <= 1
                    ? b.bottom - b.top
                    : b.right - b.left) < 150 && (a = !0)))
            : (a = !1),
          (window.goog_multislot_cache.hd = a)))
      : (a = !1);
    this.G = a;
    this.A = O("abgcp" + this.creativeIndexSuffix);
    this.v = O("abgc" + this.creativeIndexSuffix);
    this.i = O("abgs" + this.creativeIndexSuffix);
    O("abgl" + this.creativeIndexSuffix);
    this.u = O("abgb" + this.creativeIndexSuffix);
    this.D = O("abgac" + this.creativeIndexSuffix);
    O("mute_panel" + this.creativeIndexSuffix);
    this.B = tb("goog_delegate_attribution" + this.creativeIndexSuffix);
    this.isDelegateAttributionActive =
      !!this.B && !!this.K && !tb("goog_delegate_disabled") && !this.F;
    if (this.i)
      a: for (a = this.i, b = a.childNodes, c = 0; c < b.length; c++) {
        var d = b.item(c);
        if (typeof d.tagName != "undefined" && d.tagName.toUpperCase() == "A") {
          a = d;
          break a;
        }
      }
    else a = null;
    this.m = a;
    this.l = this.isDelegateAttributionActive
      ? this.B
      : O("cbb" + this.creativeIndexSuffix);
    this.N = this.G ? this.creativeIndexSuffix === "0" : !0;
    this.enableDelegateDismissableMenu =
      !!this.l && Nb(this.l, "goog_dismissable_menu");
    this.o = null;
    this.J = 0;
    this.j = this.isDelegateAttributionActive
      ? this.B
      : this.P && this.A
      ? this.A
      : this.v;
    this.autoExpandOnLoad = !!J(this.h, 19);
    this.adbadgeEnabled = !!J(this.h, 24);
    this.enableNativeJakeUi = !!J(this.h, 27);
  }
  function Pb(a, b) {
    if (!a) throw Error("bad conv util ctor args");
    this.i = a;
    this.h = b;
  }
  function Qb(a, b) {
    var c = c === void 0 ? {} : c;
    this.error = a;
    this.meta = c;
    this.context = b.context;
    this.msg = b.message || "";
    this.id = b.id || "jserror";
  }
  function Rb(a) {
    var b = a.toString();
    a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
    a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
    if (a.stack)
      a: {
        a = a.stack;
        var c = b;
        try {
          a.indexOf(c) == -1 && (a = c + "\n" + a);
          for (var d; a != d; )
            (d = a),
              (a = a.replace(
                RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"),
                "$1"
              ));
          b = a.replace(RegExp("\n *", "g"), "\n");
          break a;
        } catch (f) {
          b = c;
          break a;
        }
        b = void 0;
      }
    return b;
  }
  var Sb = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");
  function Tb(a, b) {
    this.h = a;
    this.i = b;
  }
  function Ub(a, b) {
    this.url = a;
    this.h = !!b;
    this.depth = null;
  }
  var Vb = null;
  function Wb() {
    var a = a === void 0 ? u : a;
    return (a = a.performance) && a.now && a.timing
      ? Math.floor(a.now() + a.timing.navigationStart)
      : Date.now();
  }
  function Xb() {
    var a = a === void 0 ? u : a;
    return (a = a.performance) && a.now ? a.now() : null;
  }
  function Yb(a, b) {
    var c = Xb() || Wb();
    var d = d === void 0 ? 0 : d;
    this.label = a;
    this.type = b;
    this.value = c;
    this.duration = d;
    this.taskId = this.slotId = void 0;
    this.uniqueId = Math.random();
  }
  var T = u.performance,
    Zb = !!(T && T.mark && T.measure && T.clearMarks),
    U = nb(function () {
      var a;
      if ((a = Zb)) {
        var b = b === void 0 ? window : b;
        if (Vb === null) {
          Vb = "";
          try {
            a = "";
            try {
              a = b.top.location.hash;
            } catch (d) {
              a = b.location.hash;
            }
            if (a) {
              var c = a.match(/\bdeid=([\d,]+)/);
              Vb = c ? c[1] : "";
            }
          } catch (d) {}
        }
        b = Vb;
        a = !!b.indexOf && b.indexOf("1337") >= 0;
      }
      return a;
    });
  function $b() {
    var a = window;
    this.i = [];
    this.j = a || u;
    var b = null;
    a &&
      ((a.google_js_reporting_queue = a.google_js_reporting_queue || []),
      (this.i = a.google_js_reporting_queue),
      (b = a.google_measure_js_timing));
    this.h = U() || (b != null ? b : Math.random() < 1);
  }
  function ac(a) {
    a &&
      T &&
      U() &&
      (T.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_start"),
      T.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_end"));
  }
  $b.prototype.start = function (a, b) {
    if (!this.h) return null;
    a = new Yb(a, b);
    b = "goog_" + a.label + "_" + a.uniqueId + "_start";
    T && U() && T.mark(b);
    return a;
  };
  $b.prototype.end = function (a) {
    if (this.h && Ea(a.value)) {
      a.duration = (Xb() || Wb()) - a.value;
      var b = "goog_" + a.label + "_" + a.uniqueId + "_end";
      T && U() && T.mark(b);
      !this.h || this.i.length > 2048 || this.i.push(a);
    }
  };
  function bc() {
    this.j = "&";
    this.i = {};
    this.l = 0;
    this.h = [];
  }
  function cc(a, b) {
    var c = {};
    c[a] = b;
    return [c];
  }
  function dc(a, b, c, d, f) {
    var h = [];
    mb(a, function (e, g) {
      (e = ec(e, b, c, d, f)) && h.push(encodeURIComponent(g) + "=" + e);
    });
    return h.join(b);
  }
  function ec(a, b, c, d, f) {
    if (a == null) return "";
    b = b || "&";
    c = c || ",$";
    Fa(c) && (c = c.split(""));
    if (a instanceof Array) {
      if ((d || (d = 0), d < c.length)) {
        for (var h = [], e = 0; e < a.length; e++)
          h.push(ec(a[e], b, c, d + 1, f));
        return h.join(c[d]);
      }
    } else if (typeof a === "object")
      return (
        f || (f = 0), f < 2 ? encodeURIComponent(dc(a, b, c, d, f + 1)) : "..."
      );
    return encodeURIComponent(String(a));
  }
  function fc(a, b, c, d) {
    return hc(a) - d.length < 0 ? "" : b + "//" + c + d + ic(a, d);
  }
  function ic(a, b) {
    var c = hc(a) - b.length;
    if (c < 0) return "";
    b = "";
    a.h.sort(function (m, q) {
      return m - q;
    });
    for (var d = null, f = "", h = 0; h < a.h.length; h++)
      for (var e = a.h[h], g = a.i[e], k = 0; k < g.length; k++) {
        if (!c) {
          d = d == null ? e : d;
          break;
        }
        var l = dc(g[k], a.j, ",$");
        if (l) {
          l = f + l;
          if (c >= l.length) {
            c -= l.length;
            b += l;
            f = a.j;
            break;
          }
          d = d == null ? e : d;
        }
      }
    a = "";
    d != null && (a = f + "trn=" + d);
    return b + a;
  }
  function hc(a) {
    var b = 1,
      c;
    for (c in a.i) c.length > b && (b = c.length);
    return 3997 - b - a.j.length - 1;
  }
  var jc = RegExp(
    "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
  );
  function kc() {
    var a = lc,
      b = mc;
    b = b === void 0 ? null : b;
    this.pinger = a;
    this.h = b;
    this.i = null;
    this.j = !1;
    this.m = this.l;
  }
  function nc(a, b, c) {
    try {
      if (a.h && a.h.h) {
        var d = a.h.start(b.toString(), 3);
        var f = c();
        a.h.end(d);
      } else f = c();
    } catch (g) {
      c = !0;
      try {
        ac(d), (c = a.m(b, new Qb(g, { message: Rb(g) }), void 0, void 0));
      } catch (k) {
        a.l(217, k);
      }
      if (c) {
        var h, e;
        (h = window.console) == null || (e = h.error) == null || e.call(h, g);
      } else throw g;
    }
    return f;
  }
  function oc(a, b) {
    var c = V;
    return function () {
      var d = ma.apply(0, arguments);
      return nc(c, a, function () {
        return b.apply(void 0, d);
      });
    };
  }
  kc.prototype.l = function (a, b, c, d, f) {
    f = f || "jserror";
    var h = void 0;
    try {
      var e = new bc();
      e.h.push(1);
      e.i[1] = cc("context", a);
      (b.error && b.meta && b.id) || (b = new Qb(b, { message: Rb(b) }));
      if (b.msg) {
        var g = b.msg.substring(0, 512);
        e.h.push(2);
        e.i[2] = cc("msg", g);
      }
      var k = b.meta || {};
      if (this.i)
        try {
          this.i(k);
        } catch (L) {}
      if (d)
        try {
          d(k);
        } catch (L) {}
      d = [k];
      e.h.push(3);
      e.i[3] = d;
      var l;
      if (!(l = x)) {
        g = u;
        d = [];
        k = null;
        do {
          var m = g;
          try {
            var q;
            if ((q = !!m && m.location.href != null))
              b: {
                try {
                  ua(m.foo);
                  q = !0;
                  break b;
                } catch (L) {}
                q = !1;
              }
            var n = q;
          } catch (L) {
            n = !1;
          }
          if (n) {
            var t = m.location.href;
            k = (m.document && m.document.referrer) || null;
          } else (t = k), (k = null);
          d.push(new Ub(t || ""));
          try {
            g = m.parent;
          } catch (L) {
            g = null;
          }
        } while (g && m !== g);
        t = 0;
        for (var w = d.length - 1; t <= w; ++t) d[t].depth = w - t;
        m = u;
        if (
          m.location &&
          m.location.ancestorOrigins &&
          m.location.ancestorOrigins.length === d.length - 1
        )
          for (w = 1; w < d.length; ++w) {
            var y = d[w];
            y.url ||
              ((y.url = m.location.ancestorOrigins[w - 1] || ""), (y.h = !0));
          }
        l = d;
      }
      var x = l;
      var Ka = new Ub(u.location.href, !1);
      l = null;
      var La = x.length - 1;
      for (m = La; m >= 0; --m) {
        var D = x[m];
        !l && Sb.test(D.url) && (l = D);
        if (D.url && !D.h) {
          Ka = D;
          break;
        }
      }
      D = null;
      var Gc = x.length && x[La].url;
      Ka.depth !== 0 && Gc && (D = x[La]);
      h = new Tb(Ka, D);
      if (h.i) {
        var Hc = h.i.url || "";
        e.h.push(4);
        e.i[4] = cc("top", Hc);
      }
      var Ma = { url: h.h.url || "" };
      if (h.h.url) {
        var Na = h.h.url.match(jc),
          Db = Na[1],
          Eb = Na[3],
          Fb = Na[4];
        x = "";
        Db && (x += Db + ":");
        Eb && ((x += "//"), (x += Eb), Fb && (x += ":" + Fb));
        var Gb = x;
      } else Gb = "";
      Ma = [Ma, { url: Gb }];
      e.h.push(5);
      e.i[5] = Ma;
      pc(this.pinger, f, e, this.j, c);
    } catch (L) {
      try {
        var Ib, Jb;
        pc(
          this.pinger,
          f,
          {
            context: "ecmserr",
            rctx: a,
            msg: Rb(L),
            url: (Jb = (Ib = h) == null ? void 0 : Ib.h.url) != null ? Jb : "",
          },
          this.j,
          c
        );
      } catch (Uc) {}
    }
    return !0;
  };
  function qc(a, b, c, d) {
    d = d === void 0 ? !1 : d;
    this.domain = a;
    this.path = b;
    this.l = c;
    this.j = d;
    this.protocol = "https:";
    this.i = Math.random();
  }
  function rc() {
    var a = lc,
      b = window.google_srt;
    b >= 0 && b <= 1 && (a.i = b);
  }
  function pc(a, b, c, d, f) {
    if (((d === void 0 ? 0 : d) ? a.i : Math.random()) < (f || a.l))
      try {
        if (c instanceof bc) var h = c;
        else
          (h = new bc()),
            mb(c, function (g, k) {
              var l = h,
                m = l.l++;
              g = cc(k, g);
              l.h.push(m);
              l.i[m] = g;
            });
        var e = fc(h, a.protocol, a.h(), a.path + b + "&");
        e && (a.j ? Ab(u, e) : yb(u, e));
      } catch (g) {}
  }
  qc.prototype.h = function () {
    return this.domain;
  };
  var lc,
    V,
    sc = !1;
  function tc() {
    qc.apply(this, arguments);
  }
  ja(tc, qc);
  tc.prototype.h = function () {
    if (sc) {
      var a = { X: !0 };
      a = (a === void 0 ? {} : a).X;
      a = (a === void 0 ? 0 : a)
        ? "connect.pagead2.googlesyndication.com"
        : "pagead2.googlesyndication.com";
    } else a = qc.prototype.h.call(this);
    return a;
  };
  var mc = new $b();
  function uc() {
    if (!window.google_measure_js_timing) {
      var a = mc;
      a.h = !1;
      a.i !== a.j.google_js_reporting_queue &&
        (U() && ta(a.i, ac), (a.i.length = 0));
    }
  }
  (function (a) {
    sc = !1;
    lc =
      a != null
        ? a
        : new tc("pagead2.googlesyndication.com", "/pagead/gen_204?id=", 0.01);
    typeof window.google_srt !== "number" &&
      (window.google_srt = Math.random());
    rc();
    V = new kc();
    V.i = function (b) {
      var c = Bb;
      c !== 0 && ((b.jc = String(c)), (b.shv = Cb(c)));
    };
    V.j = !0;
    window.document.readyState === "complete"
      ? uc()
      : mc.h &&
        P(window, "load", function () {
          uc();
        });
  })();
  function W(a, b) {
    return oc(a, b);
  }
  function X(a, b) {
    a &&
      mb(b, function (c, d) {
        a.style[d] = c;
      });
  }
  function vc(a, b) {
    var c = this;
    this.h = a;
    this.i = b;
    this.h.U ||
      ((this.l = !1),
      (this.j = null),
      !this.h.G || this.h.adbadgeEnabled || this.h.N
        ? wc(this)
        : ((a = { display: "none" }),
          (b = { width: "15px", height: "15px" }),
          this.h.isMobileDevice
            ? (X(this.h.u, a), X(this.h.i, a), X(this.h.A, b), X(this.h.v, b))
            : X(this.h.v, a)),
      xc(this),
      this.h.enableNativeJakeUi && S(this.h.D, "abgnac"),
      this.h.isDelegateAttributionActive
        ? (S(document.body, "goog_delegate_active"), S(document.body, "jaa"))
        : (!this.h.isMutableImpression && this.h.l && ub(this.h.l),
          setTimeout(
            function () {
              S(document.body, "jar");
            },
            this.h.L ? 750 : 100
          )),
      this.h.F && S(document.body, "goog_delegate_disabled"),
      this.h.autoExpandOnLoad &&
        R.addEventListener("load", function () {
          return c.i();
        }));
  }
  function xc(a) {
    if (a.h.T)
      P(
        a.h.j,
        "click",
        W(365, function (c) {
          var d = R.goog_interstitial_display;
          d && (d(c), c && (c.stopPropagation(), c.preventDefault()));
        })
      );
    else if (a.h.isMutableImpression && a.h.isMobileDevice)
      P(a.h.j, "click", function () {
        return a.i();
      });
    else if (
      (a.h.isMutableImpression &&
        !a.h.isMobileDevice &&
        (a.h.l &&
          (P(a.h.l, "click", function () {
            return a.i();
          }),
          P(a.h.l, "keydown", function (c) {
            (c.code !== "Enter" && c.code !== "Space") || a.i();
          })),
        a.h.V &&
          a.h.i &&
          P(a.h.i, "click", function () {
            return a.i();
          })),
      a.h.M)
    )
      yc(a);
    else {
      P(
        a.h.j,
        "mouseover",
        W(367, function () {
          return yc(a);
        })
      );
      P(
        a.h.j,
        "mouseout",
        W(369, function () {
          return zc(a, 500);
        })
      );
      P(
        a.h.j,
        "touchstart",
        W(368, function () {
          return yc(a);
        }),
        vb
      );
      var b = W(370, function () {
        return zc(a, 4e3);
      });
      P(a.h.j, "mouseup", b);
      P(a.h.j, "touchend", b);
      P(a.h.j, "touchcancel", b);
      a.h.m &&
        P(
          a.h.m,
          "click",
          W(371, function (c) {
            return a.preventDefault(c);
          })
        );
    }
  }
  function wc(a) {
    if (a.h.m && a.h.S) {
      var b = jb(a.h.h);
      b &&
        I(b, 5) != null &&
        I(b, 6) != null &&
        (a.j = new Pb(M(b, 5), M(b, 19)));
      P(
        a.h.m,
        "click",
        W(452, function () {
          if (!a.l && ((a.l = !0), a.j)) {
            var c = a.j,
              d = c.i + "&label=closebutton_whythisad_click";
            d += "&label_instance=1";
            c.h && (d += "&cid=" + c.h);
            yb(window, d);
          }
        })
      );
    }
  }
  function Ac(a) {
    var b = a.h.D;
    b !== void 0 &&
      ((b.style.display = "block"),
      a.h.enableNativeJakeUi &&
        window.requestAnimationFrame(function () {
          S(b, "abgacfo");
        }));
  }
  function yc(a) {
    window.clearTimeout(a.h.o);
    a.h.o = null;
    (a.h.i && a.h.i.style.display == "block") ||
      ((a.h.J = Date.now()),
      a.h.u &&
        a.h.i &&
        ((a.h.u.style.display = "none"), (a.h.i.style.display = "block")));
  }
  function zc(a, b) {
    window.clearTimeout(a.h.o);
    a.h.o = window.setTimeout(function () {
      return Bc(a);
    }, b);
  }
  function Bc(a) {
    window.clearTimeout(a.h.o);
    a.h.o = null;
    a.h.u &&
      a.h.i &&
      ((a.h.u.style.display = "block"), (a.h.i.style.display = "none"));
  }
  vc.prototype.preventDefault = function (a) {
    if (
      this.h.i &&
      this.h.i.style.display == "block" &&
      Date.now() - this.h.J < 500
    )
      Q(a);
    else if (this.h.openAttributionInline) {
      var b = this.h.m.getAttribute("href");
      window.adSlot
        ? window.adSlot.openAttribution(b) && Q(a)
        : window.openAttribution && (window.openAttribution(b), Q(a));
    } else
      this.h.R &&
        ((b = this.h.m.getAttribute("href")),
        window.adSlot
          ? window.adSlot.openSystemBrowser(b) && Q(a)
          : window.openSystemBrowser && (window.openSystemBrowser(b), Q(a)));
  };
  function Cc(a) {
    var b = Dc,
      c = this;
    if (!b) throw Error("bad ctor");
    this.j = b;
    this.i = a;
    this.h = !1;
    tb("goog_delegate_deferred")
      ? R.goog_delegate_deferred_token !== void 0
        ? Ec(this)
        : ((a = function () {
            Ec(c);
          }),
          (R.goog_delegate_deferred_token = a),
          setTimeout(a, 5e3))
      : Ec(this);
  }
  function Ec(a) {
    if (!a.h && ((a.h = !0), (R.goog_delegate_deferred_token = void 0), a.i)) {
      var b = a.j;
      a = lb(JSON.stringify(a.i));
      if (!a) throw Error("bad attrdata");
      a = new Ob(a);
      new b(a);
    }
  }
  function Fc() {
    var a = this;
    this.promise = new Promise(function (b, c) {
      a.resolve = b;
      a.reject = c;
    });
  }
  function Ic() {
    var a = new Fc();
    return { promise: a.promise, resolve: a.resolve };
  }
  function Jc(a, b) {
    b = b === void 0 ? function () {} : b;
    a.google_llp || (a.google_llp = {});
    a = a.google_llp;
    var c = a[5];
    if (c) return c;
    c = Ic();
    a[5] = c;
    b();
    return c;
  }
  function Kc(a, b) {
    return Jc(a, function () {
      var c = a.document,
        d = sb("SCRIPT", c);
      if (b instanceof rb) var f = b.h;
      else throw Error("");
      d.src = f;
      var h;
      f = d.ownerDocument;
      f = f === void 0 ? document : f;
      var e;
      f =
        (e = (h = f).querySelector) == null
          ? void 0
          : e.call(h, "script[nonce]");
      (h = f == null ? "" : f.nonce || f.getAttribute("nonce") || "") &&
        d.setAttribute("nonce", h);
      (c = c.getElementsByTagName("script")[0]) &&
        c.parentNode &&
        c.parentNode.insertBefore(d, c);
    }).promise;
  }
  function Lc(a) {
    a = a === null ? "null" : a === void 0 ? "undefined" : a;
    var b;
    pb === void 0 && (pb = qb());
    a = (b = pb) ? b.createScriptURL(a) : a;
    return new rb(a);
  }
  function Dc(a) {
    var b = this;
    this.h = a;
    this.i = new vc(
      this.h,
      W(359, function () {
        return Mc(b);
      })
    );
  }
  function Mc(a) {
    a.h.C
      ? a.h.C.expandAttributionCard()
      : (nc(V, 373, function () {
          Bc(a.i);
          Ac(a.i);
        }),
        Kc(
          window,
          Lc(
            "https://pagead2.googlesyndication.com/pagead/js/" +
              (M(a.h.h, 33) + "/abg_survey.js")
          )
        ).then(function (b) {
          b.createAttributionCard(a.h);
          a.h.C = b;
          b.expandAttributionCard();
        }),
        Kb());
  }
  function Nc(a) {
    var b = [a];
    b = b === void 0 ? [] : b;
    u.google_logging_queue || (u.google_logging_queue = []);
    u.google_logging_queue.push([11, b]);
    new Cc(a);
  }
  Bb = 60;
  var Oc = Hb(60);
  if (Oc == null) throw Error("JSC not found 60");
  for (var Pc = {}, Qc = Oc.attributes, Rc = Qc.length - 1; Rc >= 0; Rc--) {
    var Sc = Qc[Rc].name;
    Sc.indexOf("data-jcp-") === 0 && (Pc[Sc.substring(9)] = Qc[Rc].value);
  }
  if (Pc["attribution-data"]) Nc(JSON.parse(Pc["attribution-data"]));
  else
    for (
      var Tc = ["buildAttribution"], Y = u, Z;
      Tc.length && (Z = Tc.shift());

    )
      Tc.length || Nc === void 0
        ? Y[Z] && Y[Z] !== Object.prototype[Z]
          ? (Y = Y[Z])
          : (Y = Y[Z] = {})
        : (Y[Z] = Nc);
}.call(this));
