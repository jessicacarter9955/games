var _33AcrossIdMappingsProvider;
(() => {
  "use strict";
  var e = {
      d: (t, n) => {
        for (var s in n)
          e.o(n, s) &&
            !e.o(t, s) &&
            Object.defineProperty(t, s, { enumerable: !0, get: n[s] });
      },
      o: (e, t) => Object.prototype.hasOwnProperty.call(e, t),
    },
    t = {};
  (() => {
    e.d(t, { default: () => K });
    const n = { CCPA: "__uspapi", GDPR: "__tcfapi", GPP: "__gpp" },
      s = {
        GDPR: "__tcfapiLocator",
        CCPA: "__uspapiLocator",
        GPP: "__gppLocator",
      },
      r = {
        GDPR: ["addEventListener"],
        CCPA: ["getUSPData"],
        GPP: ["ping", "addEventListener"],
      },
      a = "iab",
      o = "static",
      i = { GDPR: 2, CCPA: 1 },
      c = {
        GDPR(e, t, n) {
          e(t, i.GDPR, n);
        },
        CCPA(e, t, n) {
          e(t, i.CCPA, n);
        },
        GPP(e, t, n, s) {
          e(t, n, s);
        },
      };
    class l {
      #e;
      #t;
      #n;
      #s;
      #r;
      #a;
      #o;
      #i;
      constructor(e) {
        let { name: t, win: s = window, config: r = {}, hashFn: a } = e;
        (this.#e = t),
          (this.#t = n[t]),
          (this.#s = s),
          (this.#r = r.consentTimeout || 1e4),
          (this.#a =
            this.#s._33across?.idMappingsConfig?.regs?.[this.#e.toLowerCase()]),
          (this.#i = a);
      }
      #c(e) {
        let t =
          arguments.length > 1 && void 0 !== arguments[1]
            ? arguments[1]
            : this.#s;
        try {
          if ("function" == typeof t[this.#t])
            return { cmpApi: t[this.#t], win: t };
          if (t.frames[e]) return { win: t };
        } catch (e) {}
        return t === this.#s.top ? {} : this.#c(e, t.parent);
      }
      #l() {
        let e =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        const t = "boolean" == typeof e.gdprApplies && e.gdprApplies;
        return !t || ((n = e.tcString) && "string" == typeof n)
          ? {
              consentData: this.#d({
                consentString: e.tcString,
                consentObject: e,
                additionalFields: {
                  applies: t,
                  ...("string" == typeof e.addtlConsent
                    ? { addtlConsent: e.addtlConsent }
                    : {}),
                },
                valuesToHash: [t, e.tcString],
              }),
            }
          : this.#h(e);
        var n;
      }
      #p(e) {
        return (
          (t = e?.uspString),
          t && "string" == typeof t
            ? {
                consentData: this.#d({
                  consentString: e.uspString,
                  consentObject: e,
                  valuesToHash: e.uspString,
                }),
              }
            : this.#h(e)
        );
        var t;
      }
      #h(e) {
        return this.#u("CMP returned unexpected value during lookup process.", {
          consentObject: e,
        });
      }
      #u(e, t) {
        return { errMsg: e, errArgs: t, consentData: this.#d() };
      }
      #g(e) {
        const t = (e) => Array.isArray(e) && e.length > 0 && 0 !== e[0];
        return t(e.applicableSections)
          ? e.applicableSections
          : t(e.applicableSection)
          ? e.applicableSection
          : null;
      }
      #m() {
        let e =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        const t = Object.assign({}, e, e.pingData);
        if (!t.gppString || "string" != typeof t.gppString) return this.#h(t);
        const n = this.#g(t);
        return n
          ? {
              consentData: this.#d({
                consentString: t.gppString,
                apiVersion: t.gppVersion,
                consentObject: t,
                additionalFields: { applicableSections: n },
                valuesToHash: [n, t.gppString],
              }),
            }
          : this.#h(t);
      }
      #d() {
        let {
          consentString: e = "",
          consentObject: t = {},
          apiVersion: n = i[this.#e],
          additionalFields: s,
          valuesToHash: r = null,
        } = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return {
          consentString: e,
          vendorData: t,
          apiVersion: n,
          name: this.#e,
          hash: this.#i(JSON.stringify(r)),
          ...s,
        };
      }
      #f(e, t) {
        const n = {
          GDPR: (e) => this.#l(e),
          CCPA: (e) => this.#p(e),
          GPP: (e) => this.#m(e),
        }[this.#e](e);
        return t && this.#o?.(n, this.#e), n;
      }
      #w(e, t) {
        switch (this.#e) {
          case "GDPR":
            return [
              !1 === e.gdprApplies ||
                "tcloaded" === e.eventStatus ||
                "useractioncomplete" === e.eventStatus,
            ];
          case "CCPA":
            return [!0];
          case "GPP": {
            if ("sectionChange" === e.eventName) return [!0, !0];
            const n = e.pingData || e;
            return "loaded" === n.cmpStatus
              ? n.gppString || e.hasOwnProperty("gppString")
                ? [!0]
                : (this.#v("getGPPData").then(t), [!1])
              : "ready" === n.signalStatus
              ? [!0]
              : "error" === n.cmpStatus
              ? [
                  !1,
                  !1,
                  "CMP returned with a cmpStatus:error response. Please check CMP setup.",
                ]
              : [!1];
          }
          default:
            return [!1];
        }
      }
      #C(e, t) {
        if (arguments.length > 2 && void 0 !== arguments[2] && !arguments[2])
          return void e(
            this.#u(
              "CMP unable to register callback function.  Please check CMP setup."
            )
          );
        const [n, s, r] = this.#w(t, e);
        n ? e(this.#f(t, s)) : r ? e({ errMsg: r }) : (this.#n = t);
      }
      #I(e, t) {
        const n = `${this.#t}Return`,
          s = (e.data?.includes?.(n) ? JSON.parse(e.data) : e.data)[n];
        s?.callId &&
          (t[s.callId]?.(s.returnValue, s.success), delete t[s.callId]);
      }
      #S(e, t, n) {
        const s = {},
          r = `${this.#t}Call`;
        this.#s.addEventListener("message", (e) => this.#I(e, s), !1),
          (function (e, n, a) {
            let o =
              arguments.length > 3 && void 0 !== arguments[3]
                ? arguments[3]
                : null;
            const i = Math.random().toString(),
              c = {
                [r]: Object.assign(
                  { command: e, callId: i },
                  n && { version: n },
                  o && { parameter: o }
                ),
              };
            (s[i] = a), t.postMessage(c, "*");
          })(e, i[this.#e], n);
      }
      #v(e) {
        var t = this;
        return new Promise((n) => {
          const { cmpApi: r, win: a } = this.#c(s[this.#e]);
          if (!a)
            return void n(
              this.#u(
                "CMP not found, the CMP script needs to be loaded before the 33across script"
              )
            );
          const o = function () {
            n.fnName = e;
            for (var s = arguments.length, r = new Array(s), a = 0; a < s; a++)
              r[a] = arguments[a];
            t.#C(n, ...r);
          };
          r ? c[this.#e](r, e, o) : this.#S(e, a, o);
        });
      }
      #b() {
        return this.#f(this.#a);
      }
      onChange(e) {
        this.#o = e;
      }
      loadConsentData() {
        const e = this.#a ? o : "iab",
          t = {
            [a]: () => r[this.#e].map((e) => this.#v(e)),
            [o]: () => [this.#b()],
          };
        let n = null;
        const s = new Promise((e) => {
          n = this.#s.setTimeout(() => {
            const { consentData: t, errMsg: n } = this.#f(this.#n);
            e(
              Object.assign(this.#u("CMP hasn't been loaded"), {
                consentData: n ? this.#d() : t,
              })
            );
          }, this.#r);
        });
        return Promise.race([...t[e](), s]).finally(() =>
          this.#s.clearTimeout(n)
        );
      }
    }
    const d = {
        GDPR: (e) => {
          let { consentString: t } = e;
          return { gdpr_consent: t };
        },
        CCPA: (e) => {
          let { consentString: t } = e;
          return { us_privacy: t };
        },
        GPP: (e) => {
          let { consentString: t, applicableSections: n = [] } = e;
          return { gpp: t, gpp_sid: encodeURIComponent(n.join(",")) };
        },
      },
      h = "33acrossId_csti",
      p = "COPPA",
      u = ["GDPR", "CCPA", "GPP"],
      g = u.concat([p]);
    function m(e) {
      let t =
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
      const n = function (e, t) {
        if ("function" == typeof Math.imul) return Math.imul(e, t);
        let n = (4194303 & e) * (t |= 0);
        return 4290772992 & e && (n += ((4290772992 & e) * t) | 0), 0 | n;
      };
      let s = 3735928559 ^ t,
        r = 1103547991 ^ t;
      for (let t, a = 0; a < e.length; a++)
        (t = e.charCodeAt(a)),
          (s = n(s ^ t, 2654435761)),
          (r = n(r ^ t, 1597334677));
      return (
        (s = n(s ^ (s >>> 16), 2246822507) ^ n(r ^ (r >>> 13), 3266489909)),
        (r = n(r ^ (r >>> 16), 2246822507) ^ n(s ^ (s >>> 13), 3266489909)),
        (4294967296 * (2097151 & r) + (s >>> 0)).toString()
      );
    }
    class f {
      #P;
      constructor(e) {
        this.#P = e;
      }
      #y(e, t) {
        return (
          t.forEach((t) => {
            t.id || t.storageManager.setId(e);
          }),
          this
        );
      }
      setId(e) {
        return (
          this.#P.forEach((t) => {
            t.setId(e);
          }),
          this
        );
      }
      getId() {
        const e = this.#P.map((e) => ({ storageManager: e, id: e.getId() })),
          t = e.find((e) => e.id)?.id || null;
        return t && this.#y(t, e), t;
      }
      clear() {
        return (
          this.#P.forEach((e) => {
            e.clear();
          }),
          this
        );
      }
    }
    class w {
      #s;
      #D;
      constructor(e) {
        let { win: t = window } =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        (this.#s = t), (this.#D = e);
      }
      setId(e) {
        return this.#s.localStorage.setItem(this.#D, e), this;
      }
      getId() {
        return this.#s.localStorage.getItem(this.#D);
      }
      clear() {
        return this.#s.localStorage.removeItem(this.#D), this;
      }
    }
    const v = 31536e6;
    class C {
      #s;
      #M;
      #D;
      #E;
      constructor(e, t) {
        let { win: n = window, cookieExpirationInMs: s = v } =
          arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        (this.#s = n), (this.#M = t), (this.#D = e), (this.#E = s);
      }
      setId(e) {
        const t = new Date(Date.now() + this.#E);
        return (
          this.#M.setCookie({
            win: this.#s,
            key: this.#D,
            value: e,
            expires: t.toUTCString(),
            domain: this.#M.calculateTopMostCookieableDomain(this.#s),
          }),
          this
        );
      }
      getId() {
        return this.#M.getCookie(this.#D);
      }
      clear() {
        return (
          this.#M.removeCookie(
            this.#D,
            this.#M.calculateTopMostCookieableDomain(this.#s),
            this.#s
          ),
          this
        );
      }
    }
    function I(e) {
      let {
        key: t,
        value: n,
        expires: s,
        sameSite: r = "",
        domain: a,
        win: o = window,
      } = e;
      const i = a ? ` ;domain=${encodeURIComponent(a)}` : "",
        c = s ? ` ;expires=${s}` : "",
        l = "none" === r.toLowerCase() ? "; Secure" : "",
        d = r ? `; SameSite=${r}` : "";
      o.document.cookie = `${t}=${encodeURIComponent(
        n
      )}${c}; path=/${i}${d}${l}`;
    }
    function S(e) {
      const t = (
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : window
      ).document.cookie.match(`(^|;)\\s*${e}\\s*=\\s*([^;]*)\\s*(;|$)`);
      return t ? decodeURIComponent(t[2]) : null;
    }
    function b(e, t) {
      I({
        win:
          arguments.length > 2 && void 0 !== arguments[2]
            ? arguments[2]
            : window,
        key: e,
        value: "",
        expires: "Thu, 01 Jan 1970 00:00:01 GMT",
        domain: t,
      });
    }
    const P = {
      setCookie: I,
      getCookie: S,
      removeCookie: b,
      calculateTopMostCookieableDomain: function () {
        let e =
          arguments.length > 0 && void 0 !== arguments[0]
            ? arguments[0]
            : window;
        const t = e.document.domain.split("."),
          n = `_gd${Date.now()}_`;
        let s;
        for (let r, a = 0; a < t.length; a++) {
          const o = t.slice(a).join(".");
          if (
            (I({ win: e, key: n, value: "1", domain: o }),
            (r = S(n, e)),
            b(n, o, e),
            "1" !== r)
          )
            break;
          s = o;
        }
        return s;
      },
      hasCookieSupport: function () {
        return (
          arguments.length > 0 && void 0 !== arguments[0]
            ? arguments[0]
            : window
        ).navigator.cookieEnabled;
      },
    };
    function y(e) {
      return new Promise((t, n) => {
        const s = (function (e) {
          let { url: t, params: n = {}, win: s = window, options: r = {} } = e;
          const a = new s.XMLHttpRequest("MSXML2.XMLHTTP.3.0"),
            o = new URLSearchParams(n);
          return (
            a.open("GET", `${t}?${o}`, 1),
            a.setRequestHeader(
              "Content-type",
              "application/x-www-form-urlencoded"
            ),
            (a.withCredentials = void 0 !== r.withCredentials),
            (a.timeout = r.timeout),
            a
          );
        })(e);
        (s.onreadystatechange = () => {
          4 === s.readyState &&
            (s.status >= 200 && s.status < 300
              ? t(s.responseText)
              : n(`Ajax: Status code ${s.status}`));
        }),
          (s.onerror = () => n("Ajax: Network error")),
          (s.ontimeout = () => n("Ajax: Timeout")),
          s.send();
      });
    }
    const D = 28800,
      M = 30;
    class E {
      #x;
      #k;
      #s;
      #R;
      #P = {};
      constructor(e, t) {
        let {
          idKeyName: n,
          refreshInSeconds: s = D,
          expires: r = M,
          win: a = window,
        } = e;
        (this.#x = { VALUE: n, LAST: `${n}_last`, EXP: `${n}_exp` }),
          (this.#P = Object.values(this.#x).reduce(
            (e, n) => ((e[n] = t(n)), e),
            {}
          )),
          (this.#s = a),
          (this.#k = s),
          (this.#R = 864e5 * r);
      }
      hasExpired() {
        const e = this.#P[this.#x.EXP].getId();
        return !!e && new Date(e).getTime() - Date.now() <= 0;
      }
      isRefreshRequired() {
        const e = this.#P[this.#x.LAST].getId();
        return !e || Date.now() - new Date(e).getTime() >= 1e3 * this.#k;
      }
      setId(e) {
        const t = new Date(Date.now() + this.#R),
          n = new Date();
        return (
          this.#P[this.#x.VALUE].setId(e),
          this.#P[this.#x.EXP].setId(t.toUTCString()),
          this.#P[this.#x.LAST].setId(n.toUTCString()),
          this
        );
      }
      getId() {
        return this.#s.decodeURIComponent(this.#P[this.#x.VALUE].getId() || "");
      }
      clear() {
        return (
          this.#P[this.#x.VALUE].clear(),
          this.#P[this.#x.EXP].clear(),
          this.#P[this.#x.LAST].clear(),
          this
        );
      }
    }
    const x = [
        { level: "error", color: "red" },
        { level: "warn", color: "yellow" },
        { level: "info", color: "green" },
        { level: "debug", color: "cyan" },
        { level: "trace", color: "blue" },
      ],
      k = "display: inline-block; padding: 1px 4px;",
      R = "3px",
      A = {
        core: k,
        bordersize: R,
        prefix: `${k}\n    border-top-left-radius: ${R};\n    border-bottom-left-radius: ${R};\n    color: #fff;\n    background-color: #be1e2d;\n  `,
        product: `${k}\n    border-top-right-radius: ${R};\n    border-bottom-right-radius: ${R};\n    color: #000;\n    background-color: #f2f2f2;\n    font-weight: lighter;\n    font-size: 0.9em;\n  `,
        baseLvl: `${k}\n    border-radius: ${R};\n    background-color: black;\n  `,
        date: `${k} color:grey;`,
      };
    function $(e, t) {
      let n =
        arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
      if (!(e instanceof Object))
        throw new Error(
          `Invalid target type. Expected an object, but got: ${e}`
        );
      const s = e.name || e.constructor.name || "???";
      return new Proxy(e, {
        get(e, a) {
          if ("function" == typeof e) return e[a];
          const o = e[a];
          if ("object" == typeof o && null !== o) return $(o, t, n);
          const i = `${s}.${String(a)}`;
          return "function" == typeof o
            ? r(o, e, i)
            : (t.print(4, n, `${i}:`, o), o);
        },
        set: (e, r, a, o) => (
          t.print(4, n, `${s}.${String(r)} <=`, a), Reflect.set(e, r, a, o)
        ),
        deleteProperty: (e, r) => (
          t.print(4, n, `delete ${s}.${String(r)} (denied)`), !1
        ),
        apply: (e, t, n) => r(e, t, s)(...n),
        construct(e, r) {
          const a = `new ${s}`;
          t.print(4, n, `construct ${a}`, ...r);
          const o = Reflect.construct(e, r);
          return t.print(3, n + 1, a, o), $(o, t, n);
        },
      });
      function r(e, s, r) {
        return function () {
          let a = `${r}(`;
          for (var o = arguments.length, i = new Array(o), c = 0; c < o; c++)
            i[c] = arguments[c];
          i.length || (a += ")"), t.print(4, n, a, ...i);
          const l = (e) => (t.print(3, n + 1, `${a} =>`, e), e),
            d = (e) => {
              if ((t.print(0, n + 1, a, e), e.propagate))
                throw (delete e.propagate, e);
            };
          try {
            const t = Reflect.apply(e, s, i);
            return "function" == typeof t?.then ? t.then(l, d) : l(t);
          } catch (e) {
            return d(e);
          }
        };
      }
    }
    class O {
      #A = -1;
      get level() {
        return x[this.#A]?.level || "silent";
      }
      #$ = "33across";
      #O = "Lexicon";
      #j = null;
      #L = (() => console)();
      constructor() {
        let e =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        (this.#O = e.product ?? this.#O),
          (this.#$ = e.prefix ?? this.#$),
          (this.#j = e.customHandler ?? this.#j),
          (this.#L = e.baseLogger ?? this.#L);
      }
      setLogLevel = (e) => {
        this.#A = x.findIndex((t) => t.level === e);
      };
      wrap(e) {
        return $(e, this);
      }
      error = (() => {
        var e = this;
        return function () {
          for (var t = arguments.length, n = new Array(t), s = 0; s < t; s++)
            n[s] = arguments[s];
          return e.print(0, 1, ...n);
        };
      })();
      warn = (() => {
        var e = this;
        return function () {
          for (var t = arguments.length, n = new Array(t), s = 0; s < t; s++)
            n[s] = arguments[s];
          return e.print(1, 1, ...n);
        };
      })();
      info = (() => {
        var e = this;
        return function () {
          for (var t = arguments.length, n = new Array(t), s = 0; s < t; s++)
            n[s] = arguments[s];
          return e.print(2, 1, ...n);
        };
      })();
      debug = (() => {
        var e = this;
        return function () {
          for (var t = arguments.length, n = new Array(t), s = 0; s < t; s++)
            n[s] = arguments[s];
          return e.print(3, 1, ...n);
        };
      })();
      trace = (() => {
        var e = this;
        return function () {
          for (var t = arguments.length, n = new Array(t), s = 0; s < t; s++)
            n[s] = arguments[s];
          return e.print(4, 1, ...n);
        };
      })();
      print = (() => {
        var e = this;
        return function (t, n) {
          if (e.#A < t) return;
          const s = e.#T(n),
            { color: r, level: a } = x[t];
          for (
            var o = arguments.length, i = new Array(o > 2 ? o - 2 : 0), c = 2;
            c < o;
            c++
          )
            i[c - 2] = arguments[c];
          if (
            (e.#L[a](
              "%c%s|%c%s %c%d %c%s %c%s",
              A.prefix,
              e.#$,
              A.product,
              e.#O,
              A.date,
              Date.now(),
              `${A.baseLvl} color: ${r}`,
              a,
              A.core,
              s,
              ...i
            ),
            e.#j)
          )
            try {
              e.#j(t, n, ...i);
            } catch (t) {
              e.#L.error("Error in custom log handler:", t);
            }
        };
      })();
      #T() {
        let e =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 0;
        const t = (new Error().stack || "").split("\n");
        "Error" === t[0] && e++;
        const n = t[2 + e],
          s = /at\s+(.*)\s+\(/.exec(n) || /(.*)@/.exec(n);
        return s ? s[1] : "";
      }
    }
    const j = { COOKIE: "cookie", LOCALSTORAGE: "localstorage" };
    const L = {
        localstorage: (e, t) => new w(e, t),
        cookie: (e, t) => new C(e, P, t),
      },
      T = (e, t) => {
        const n = (t?.enabledStorageTypes ?? [j.LOCALSTORAGE])
          .map((n) =>
            n !== j.COOKIE || P.hasCookieSupport() ? L[n]?.(e, t) : null
          )
          .filter(Boolean);
        return new f(n);
      },
      U = "https://lexicon.33across.com/v1/envelope",
      G = "ima";
    class _ {
      #U;
      #G;
      #_;
      #H = [];
      #V = [];
      #K;
      #N;
      #F;
      #s;
      #P;
      #X;
      constructor(e, t) {
        let {
            pid: n,
            apiUrl: s = U,
            src: r = G,
            win: a = window,
            hem: o = {},
          } = e,
          {
            ajax: i = y,
            consentDataHandler: c,
            refreshableStorageId: l,
            storageManagers: d,
          } = t;
        (this.#U = n),
          (this.#G = s),
          (this.#_ = i),
          (this.#K = c),
          (this.#N = r),
          (this.#F = l),
          (this.#s = a),
          (this.#P = d),
          (this.#X = o);
      }
      #q(e) {
        const t = JSON.parse(e);
        return t.succeeded
          ? {
              idsToStore: {
                idEnvelope: t.data.envelope || "",
                fpId: t.data.fp || "",
                tpId: t.data.tp || "",
              },
              succeeded: !0,
            }
          : (this.#P.hashedEmail.clear(),
            {
              idsToStore: { idEnvelope: "", fpId: "", tpId: "" },
              succeeded: !1,
            });
      }
      async #J(e) {
        const { idEnvelope: t, fpId: n, tpId: s } = await this.#B(e);
        return (
          n ? this.#P.firstPartyId.setId(n) : this.#P.firstPartyId.clear(),
          s ? this.#P.lexId.setId(s) : this.#P.lexId.clear(),
          t ? (this.#F.setId(t), this.#z(t)) : (this.#F.clear(), [])
        );
      }
      async #B() {
        let e =
          arguments.length > 0 && void 0 !== arguments[0]
            ? arguments[0]
            : this.#K.consentData;
        await e;
        try {
          const e = await this.#_({
              url: this.#G,
              params: this.#Q(),
              options: { withCredentials: !0, timeout: 1e4 },
            }),
            { succeeded: t, idsToStore: n } = this.#q(e);
          return !1 === t && this.#P.hashedEmail.clear(), n;
        } catch (e) {
          throw new Error(`_33AcrossIdMappingsProvider: ${e}`);
        }
      }
      #Q() {
        const e = this.#P.firstPartyId.getId(),
          t = this.#P.lexId.getId(),
          n = this.#X.sha256 || this.#P.hashedEmail.getId();
        return {
          pid: this.#U,
          src: this.#N,
          ver: "1.18.0",
          ...(e && { fp: this.#s.decodeURIComponent(e) }),
          ...(t && { tp: this.#s.decodeURIComponent(t) }),
          ...(n && { sha256: this.#s.decodeURIComponent(n) }),
          ...this.#K.calculatePrivacyParams(),
        };
      }
      #z(e) {
        const [t] = this.#V,
          [n] = t.uids;
        return (
          Object.assign(n, { id: e, atype: 1 }), (this.#H = this.#V), this.#H
        );
      }
      async fetch() {
        (this.#V = [{ source: "33across.com", uids: [{}] }]),
          this.#X.sha256 && this.#P.hashedEmail.setId(this.#X.sha256),
          this.#K.onChange((e) => {
            this.#F.clear(), this.#J(e);
          });
        const e = this.#F.getId(),
          t = await this.#K.hasChangedSinceStored();
        return this.#F.hasExpired() || !e || t
          ? this.#J()
          : (this.#F.isRefreshRequired() && this.#J(), this.#z(e));
      }
      getIds() {
        return this.#H;
      }
      getLoadingIds() {
        return this.#V;
      }
      getPid() {
        return this.#U;
      }
      getSource() {
        return this.#N;
      }
    }
    const H = (function (e, t) {
        let n =
          arguments.length > 2 && void 0 !== arguments[2]
            ? arguments[2]
            : window;
        const s = {},
          r = u.reduce((t, n) => Object.assign(t, { [n]: e(n) }), {}),
          a = Number(!!n._33across?.idMappingsConfig?.regs?.coppa),
          o = () =>
            u
              .map((e) => s[e]?.consentData.hash)
              .concat(a)
              .join(":"),
          i = (e, t) => {
            (s[e] = t), n.localStorage.setItem(h, o());
          },
          c = () => n.localStorage.getItem(h)?.split(":") || [],
          l = c();
        let m;
        return {
          onChange(e) {
            r.GPP.onChange((t) => {
              const n = g.indexOf("GPP"),
                r = c()[n];
              t.consentData?.hash !== r && (i("GPP", t), e(Object.values(s)));
            });
          },
          consentData: new Promise((e) => {
            const t = Object.entries(r).reduce((e, t) => {
              let [n, s] = t;
              return (e[n] = s.loadConsentData()).then((e) => i(n, e)), e;
            }, {});
            Promise.all(Object.values(t)).then(() => e(Object.values(s))),
              t.GPP.then((t) => {
                t.consentData?.consentString && e(Object.values(s));
              });
          }),
          getChangedSinceStoredResult: () => m,
          async hasChangedSinceStored() {
            const e = n.localStorage.getItem("33acrossId_cst");
            return (
              (!l && !e) ||
              (void 0 !== m ||
                (await this.consentData,
                (m =
                  (!e || t(o()) !== e) &&
                  (() => {
                    const e = g.reduce(
                      (e, t, n) => Object.assign(e, { [t]: l[n] }),
                      {}
                    );
                    return (
                      !!Object.entries(s).find((t) => {
                        let [n, { consentData: s }] = t;
                        const r = s.hash || "";
                        return !(!e[n] && !s.consentString) && r !== e[n];
                      }) || String(a) !== (e[p] ?? "0")
                    );
                  })())),
              m)
            );
          },
          calculatePrivacyParams() {
            const e = Object.values(s).reduce((e, t) => {
              let { consentData: n = {} } = t;
              const s = d[n.name];
              return n.consentString && s && Object.assign(e, s(n)), e;
            }, {});
            return a && (e.coppa = 1), e;
          },
        };
      })(
        (e) => new l({ name: e, hashFn: m }),
        function (e) {
          return (function (e) {
            const t = [];
            for (; e > 0; ) t.push(String.fromCharCode(255 & e)), (e >>>= 8);
            return btoa(t.join());
          })(m(e));
        }
      ),
      V = "33acrossId",
      K = function e(t) {
        let {
          expires: n,
          refreshInSeconds: s,
          win: r = window,
          enabledStorageTypes: a,
          ...o
        } = t;
        const i = "esp" === o.src ? `${o.src}_${V}` : V,
          c = (function () {
            let {
              uri: e,
              level: t,
              ...n
            } = arguments.length > 0 && void 0 !== arguments[0]
              ? arguments[0]
              : {};
            const s = (() => {
                try {
                  return new URL(e || globalThis.location.href).searchParams;
                } catch {
                  return null;
                }
              })(),
              r = s?.get("lex_debug") || "silent",
              a = t || r,
              o = new O(n);
            return o.setLogLevel(a), o;
          })({ product: "Lexicon ID Mappings Provider" }),
          l = c.wrap(E),
          d = c.wrap(_),
          h = { win: r, enabledStorageTypes: a },
          p = { win: r, enabledStorageTypes: Object.values(j) },
          u = new l({ idKeyName: i, expires: n, refreshInSeconds: s }, (e) =>
            T(e, h)
          ),
          g = new d(
            { win: r, hem: r._33across?.hem, ...o },
            {
              consentDataHandler: H,
              refreshableStorageId: u,
              storageManagers: {
                firstPartyId: T("33acrossIdFp", p),
                lexId: T("33acrossIdTp", p),
                hashedEmail: new f(
                  Object.values(L).map((e) =>
                    e("33acrossIdHm", { cookieExpirationInMs: 432e5 })
                  )
                ),
              },
            }
          );
        return (
          "providers" in e || Object.assign(e, { providers: {} }),
          Object.assign(e.providers, { [i]: g }),
          g
        );
      };
  })(),
    (_33AcrossIdMappingsProvider = t.default);
})();
