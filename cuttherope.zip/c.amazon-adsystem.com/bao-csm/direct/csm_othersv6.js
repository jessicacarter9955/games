(window.amzncsm = window.amzncsm || {}),
  window.amzncsm.rmD ||
    (function () {
      var initCSM,
        amzncsm = amzncsm || {};
      (amzncsm.errorCodes = {
        SLOT_INSIDE_UNFRIENDLY_FRAME: 1,
        UNSUPPORTED_BROWSER: 2,
        ERROR_SENDING_PIXEL: 3,
        INVALID_API: 4,
      }),
        (amzncsm.PST_ERROR_CODE = {
          UNSUPPORTED_FEATURE_POLICY: "UNSUPPORTED_FEATURE_POLICY",
          FEATURE_POLICY_EXCEPTION: "FEATURE_POLICY_EXCEPTION",
          TOKEN_NOT_PRESENT: "TOKEN_NOT_PRESENT",
          TUNGSTEN_LOGGING_ERROR: "TUNGSTEN_LOGGING_ERROR",
          HAS_RR_API_FAILURE: "HAS_RR_API_FAILURE",
          HAS_TOKEN_API_FAILURE: "HAS_TOKEN_API_FAILURE",
          TRS_RESPONSE_STATUS_NOT_200: "TRS_RESPONSE_STATUS_NOT_200",
          REDEMPTION_ERROR: "REDEMPTION_ERROR",
          SEND_RR_PAYLOAD_ERROR: "SEND_RR_PAYLOAD_ERROR",
        }),
        (amzncsm.errorBeaconSent = !1),
        (amzncsm.errors = []),
        (amzncsm.reportErrors = function (a, b, c) {
          c && amzncsm.errors.push(c),
            (amzncsm.errors = []),
            (amzncsm.errorBeaconSent = !0),
            amzncsm.detachAllHandlers &&
              "function" == typeof amzncsm.detachAllHandlers &&
              amzncsm.detachAllHandlers();
        }),
        (function (a, b) {
          function c(a) {
            return a ? a.replace(/^\s+|\s+$/g, "") : void 0;
          }
          function d(a) {
            if (a && a.s) {
              var b,
                c = a.s.length > 0 ? a.s[0] : "",
                d = a.s.length > 1 ? a.s[1] : "";
              c && (b = c.match(k)),
                (b && 3 == b.length) || !d || (b = d.match(j)),
                b && 3 == b.length && ((a.f = b[1]), (a.l = b[2]));
            }
          }
          function e(a, b) {
            if (((b = b || {}), !a)) return {};
            a.m && a.m.message && (a = a.m);
            var e,
              j,
              k,
              l,
              m,
              n = {
                m: f(a, b),
                c: a.c ? "" + a.c : a.c,
                s: [],
                l: a.l || a.line || a.lineno || a.lineNumber,
                name: a.name,
                type: a.type,
              },
              o = 0,
              p = 0;
            if (((e = a.stack || (a.err ? a.err.stack : "")), e && e.split))
              for (j = e.split("\n"); o < j.length && n.s.length < h; )
                (k = j[o++]), k && n.s.unshift(c(k));
            else
              for (
                l = g(a.args || arguments, "callee"), o = 0, p = 0;
                l && h > o;

              )
                (m = i),
                  l.skipTrace ||
                    ((k = l.toString()),
                    k &&
                      k.substr &&
                      ((m = 0 === p ? 4 * i : m),
                      (m = 1 == p ? 2 * i : m),
                      n.s.unshift(k.substr(0, m)),
                      p++)),
                  (l = g(l, "caller")),
                  o++;
            return !n.f && n.s.length > 0 && d(n), n;
          }
          function f(a, b) {
            var c = b.m || b.message || "";
            return (c +=
              a.m && a.m.message
                ? a.m.message
                : a.m && a.m.target && a.m.target.tagName
                ? "Error handler invoked by " + a.m.target.tagName + " tag"
                : a.m
                ? a.m
                : a.message
                ? a.message
                : "Unknown error");
          }
          function g(a, b) {
            try {
              return a[b];
            } catch (c) {
              return;
            }
          }
          var h = 20,
            i = 256,
            j = /\(?([^\s]*):(\d+):\d+\)?/,
            k = /.*@(.*):(\d*)/;
          a.constructErrorMessage = e;
        })(amzncsm, window),
        (amzncsm.getModules = function (a, b, c, d) {
          return {
            eventUtils: { default: !0, params: [], global: !0 },
            utils: { default: !0, params: [], global: !0 },
            pixelQueue: { default: !0, params: [b] },
            hoverStats: { params: [a] },
            pageMetrics: { params: [c] },
            domainMask: { params: [] },
            detectBrowser: { params: [] },
            privateStateToken: { params: [] },
          };
        }),
        (function () {
          var a = Array.prototype.slice;
          try {
            a.call(document.documentElement);
          } catch (b) {
            Array.prototype.slice = function (b, c) {
              var d, e, f, g, h, i;
              if (
                ((c = "undefined" != typeof c ? c : this.length),
                "[object Array]" === Object.prototype.toString.call(this))
              )
                return a.call(this, b, c);
              if (
                ((e = []),
                (g = this.length),
                (h = b || 0),
                (h = h >= 0 ? h : g + h),
                (i = c ? c : g),
                0 > c && (i = g + c),
                (f = i - h),
                f > 0)
              )
                if (((e = new Array(f)), this.charAt))
                  for (d = 0; f > d; d++) e[d] = this.charAt(h + d);
                else for (d = 0; f > d; d++) e[d] = this[h + d];
              return e;
            };
          }
        })(),
        Object.keys ||
          (Object.keys = (function () {
            "use strict";
            var a = Object.prototype.hasOwnProperty,
              b = !{ toString: null }.propertyIsEnumerable("toString"),
              c = [
                "toString",
                "toLocaleString",
                "valueOf",
                "hasOwnProperty",
                "isPrototypeOf",
                "propertyIsEnumerable",
                "constructor",
              ],
              d = c.length;
            return function (e) {
              if (
                "object" != typeof e &&
                ("function" != typeof e || null === e)
              )
                throw new TypeError("Object.keys called on non-object");
              var f,
                g,
                h = [];
              for (f in e) a.call(e, f) && h.push(f);
              if (b) for (g = 0; d > g; g++) a.call(e, c[g]) && h.push(c[g]);
              return h;
            };
          })()),
        window.JSON ||
          (window.JSON = {
            parse: function (sJSON) {
              return eval("(" + sJSON + ")");
            },
            stringify: (function () {
              var a = Object.prototype.toString,
                b =
                  Array.isArray ||
                  function (b) {
                    return "[object Array]" === a.call(b);
                  },
                c = {
                  '"': '\\"',
                  "\\": "\\\\",
                  "\b": "\\b",
                  "\f": "\\f",
                  "\n": "\\n",
                  "\r": "\\r",
                  "	": "\\t",
                },
                d = function (a) {
                  return (
                    c[a] ||
                    "\\u" + (a.charCodeAt(0) + 65536).toString(16).substr(1)
                  );
                },
                e = /[\\"\u0000-\u001F\u2028\u2029]/g;
              return function f(c) {
                var g, h, i, j;
                if (null == c) return "null";
                if ("number" == typeof c)
                  return isFinite(c) ? c.toString() : "null";
                if ("boolean" == typeof c) return c.toString();
                if ("object" == typeof c) {
                  if ("function" == typeof c.toJSON) return f(c.toJSON());
                  if (b(c)) {
                    for (g = "[", h = 0; h < c.length; h++)
                      g += (h ? ", " : "") + f(c[h]);
                    return g + "]";
                  }
                  if ("[object Object]" === a.call(c)) {
                    i = [];
                    for (j in c)
                      c.hasOwnProperty(j) && i.push(f(j) + ": " + f(c[j]));
                    return "{" + i.join(", ") + "}";
                  }
                }
                return '"' + c.toString().replace(e, d) + '"';
              };
            })(),
          }),
        Array.isArray ||
          (Array.isArray = function (a) {
            return "[object Array]" === Object.prototype.toString.call(a);
          }),
        String.prototype.endsWith ||
          (String.prototype.endsWith = function (a, b) {
            var c,
              d = this.toString();
            return (
              ("number" != typeof b ||
                !isFinite(b) ||
                Math.floor(b) !== b ||
                b > d.length) &&
                (b = d.length),
              (b -= a.length),
              (c = d.indexOf(a, b)),
              -1 !== c && c === b
            );
          }),
        window.Event &&
          document.createEvent &&
          !(function () {
            function a(a, b) {
              b = b || { bubbles: !1, cancelable: !1, detail: void 0 };
              var c = document.createEvent("CustomEvent");
              return c.initCustomEvent(a, b.bubbles, b.cancelable, b.detail), c;
            }
            (a.prototype = window.Event.prototype), (window.CustomEvent = a);
          })(),
        (function (a) {
          var b, c, d, e, f;
          a.performance || (a.performance = {}),
            a.performance.now ||
              (a.performance.now =
                performance.now ||
                performance.webkitNow ||
                performance.msNow ||
                performance.mozNow),
            a.performance.now ||
              ((b = Date.now ? Date.now() : +new Date()),
              performance.timing &&
                performance.timing &&
                (b = performance.timing.navigationStart),
              (a.performance.now = function () {
                var a = Date.now ? Date.now() : +new Date();
                return a - b;
              })),
            (c = []),
            (d = {}),
            (e = function (a, b) {
              for (var d = 0, e = c.length, f = []; e > d; d++)
                c[d][a] == b && f.push(c[d]);
              return f;
            }),
            (f = function (a, b) {
              for (var d, e = c.length; e--; )
                (d = c[e]),
                  d.entryType != a ||
                    (void 0 !== b && d.name != b) ||
                    c.splice(e, 1);
            }),
            a.performance.mark ||
              (a.performance.mark =
                a.performance.webkitMark ||
                function (b) {
                  var e = {
                    name: b,
                    entryType: "mark",
                    startTime: a.performance.now(),
                    duration: 0,
                  };
                  c.push(e), (d[b] = e);
                }),
            a.performance.measure ||
              (a.performance.measure =
                a.performance.webkitMeasure ||
                function (a, b, e) {
                  (b = d[b] ? d[b].startTime : 0),
                    (e = d[e] ? d[e].startTime : 0),
                    c.push({
                      name: a,
                      entryType: "measure",
                      startTime: b,
                      duration: e - b,
                    });
                }),
            a.performance.getEntriesByType ||
              (a.performance.getEntriesByType =
                a.performance.webkitGetEntriesByType ||
                function (a) {
                  return e("entryType", a);
                }),
            a.performance.getEntriesByName ||
              (a.performance.getEntriesByName =
                a.performance.webkitGetEntriesByName ||
                function (a) {
                  return e("name", a);
                }),
            a.performance.clearMarks ||
              (a.performance.clearMarks =
                a.performance.webkitClearMarks ||
                function (a) {
                  f("mark", a);
                }),
            a.performance.clearMeasures ||
              (a.performance.clearMeasures =
                a.performance.webkitClearMeasures ||
                function (a) {
                  f("measure", a);
                });
        })(window),
        (amzncsm.log = function (a) {
          try {
            -1 !== window.location.href.indexOf("csm_debug_mode") &&
              window.console &&
              window.console.log(a);
          } catch (b) {}
        }),
        (amzncsm.loadModules = function (a, b) {
          var c, d, e;
          try {
            for (c = 0; c < b.length; c++)
              if (
                ((d = b[c].name),
                (e = b[c].params || []),
                window.performance &&
                  window.performance.mark &&
                  "function" == typeof window.performance.mark &&
                  window.performance.mark("loadStart" + d + a),
                "[object Array]" !== Object.prototype.toString.call(e) &&
                  amzncsm.log(
                    "Params passed in the amzncsm.loadModules methods must be an array"
                  ),
                amzncsm[d])
              ) {
                if (void 0 === amzncsm[d].shortName)
                  throw new amzncsm.invalidModuleException(
                    "Module shortName not defined for module " + d + ". "
                  );
                e.unshift(a),
                  amzncsm[d].init.apply(amzncsm[d], e),
                  amzncsm.log("Initiated " + d + " module"),
                  window.performance &&
                    window.performance.mark &&
                    "function" == typeof window.performance.mark &&
                    (window.performance.mark("loadEnd" + d + a),
                    window.performance.measure(
                      "lt" + amzncsm[d].shortName + a,
                      "loadStart" + d + a,
                      "loadEnd" + d + a
                    ));
              } else amzncsm.log("Undefined module " + d);
          } catch (f) {
            f.message && amzncsm.errors.push(f.message);
          }
        }),
        (amzncsm.define = function (a) {
          var b, c, d, e, f, g, h, i;
          try {
            for (
              b = function (a) {
                return "string" == typeof a ? amzncsm[a] : a;
              },
                c = Array.prototype.slice.call(arguments),
                d = c[0],
                e = c.length > 2 ? c[1] : [],
                f = c[c.length - 1],
                g = [],
                h = 0,
                i = e.length;
              i > h;
              h++
            )
              g.push(b(e[h]));
            amzncsm[d] = f.apply(f, g);
          } catch (j) {
            j.message && amzncsm.errors.push(j.message);
          }
        }),
        (amzncsm.invalidModuleException = function (a) {
          (this.value = a),
            (this.message =
              "does not conform to the expected format of a module"),
            (this.toString = function () {
              return this.value + this.message;
            });
        }),
        amzncsm.define("utils", [], function () {
          var a = { shortName: "ut" },
            b = "www.btd-cmh.tq-tungsten.com/log/";
          return (
            (a.init = function (a) {}),
            (a.log = function (a) {
              try {
                -1 !== window.location.href.indexOf("csm_debug_mode") &&
                  window.console &&
                  window.console.log(a);
              } catch (b) {
                amzncsm.reportClientError(b);
              }
            }),
            (a.getFlashVersion = function () {
              var a,
                b,
                c,
                d = window.navigator,
                e = "application/x-shockwave-flash",
                f = "ShockwaveFlash.ShockwaveFlash",
                g = "Shockwave Flash";
              if (void 0 != d.plugins && "object" == typeof d.plugins[g])
                (b = d.plugins[g].description),
                  b &&
                    void 0 !== d.mimeTypes &&
                    d.mimeTypes[e] &&
                    d.mimeTypes[e].enabledPlugin &&
                    (a = Number(
                      b.replace(/^.*\s+(\d+)(\.\S+)?(\s+\S+)?$/, "$1")
                    ));
              else if (void 0 !== window.ActiveXObject)
                try {
                  (c = new ActiveXObject(f)),
                    c &&
                      ((b = c.GetVariable("$version")),
                      b && (a = Number(b.split(" ")[1].split(",")[0])));
                } catch (h) {}
              return (!a || isNaN(a)) && (a = 0), a;
            }),
            (a.getIEVersion = function () {
              var a,
                b,
                c = -1;
              return (
                "Microsoft Internet Explorer" == navigator.appName
                  ? ((a = navigator.userAgent),
                    (b = new RegExp("MSIE ([0-9]{1,}[.0-9]{0,})")),
                    null != b.exec(a) && (c = parseFloat(RegExp.$1)))
                  : navigator.userAgent.match(/Trident.*rv\:11\./)
                  ? (c = 11)
                  : navigator.userAgent.match(/Edge\/\d+\.\d+/) && (c = 12),
                c
              );
            }),
            (a.isIE = function () {
              var b = a.getIEVersion();
              return b > -1;
            }),
            (a.isFirefox = function () {
              return "undefined" != typeof InstallTrigger;
            }),
            (a.isChrome = function () {
              return (
                /Chrome/.test(navigator.userAgent) &&
                /Google Inc/.test(navigator.vendor)
              );
            }),
            (a.isSafari = function () {
              return (
                /Safari/.test(navigator.userAgent) &&
                /Apple Computer/.test(navigator.vendor)
              );
            }),
            (a.isWebkit = function () {
              return a.isChrome() || a.isSafari();
            }),
            (a.isSilk = function () {
              return /\bSilk\b/.test(navigator.userAgent);
            }),
            (a.isAndroid = function () {
              return window.webclient &&
                "function" == typeof webclient.getRealClickTime
                ? window.cordova &&
                  window.cordova.platformId &&
                  "ios" == cordova.platformId
                  ? !1
                  : !0
                : !1;
            }),
            (a.detachAllHandlers = function () {
              var a, b;
              for (b = 0; b < amzncsm.eventHandlers.length; b++)
                (a = amzncsm.eventHandlers[b]),
                  amzncsm.removeEvent(a.elem, a.eventName, a.cb);
            }),
            (a.reportClientError = function (b) {
              var c, d;
              amzncsm.errorBeaconSent !== !0 &&
                ((c = window.location.host + window.location.pathname),
                (d =
                  b === parseInt(b, 10)
                    ? { m: b, debug: encodeURIComponent(c.replace(/\//g, "_")) }
                    : amzncsm.constructErrorMessage(b)),
                amzncsm.log("ERROR " + d),
                (amzncsm.errorBeaconSent = !0),
                a.detachAllHandlers());
            }),
            (a.setTimeout = function (b, c) {
              return setTimeout(function () {
                try {
                  b.call();
                } catch (c) {
                  c.message && amzncsm.log("Error: " + c.message),
                    a.reportClientError(c);
                }
              }, c);
            }),
            (a.setInterval = function (b, c) {
              return setInterval(function () {
                try {
                  b.call();
                } catch (c) {
                  c.message && amzncsm.log("Error: " + c.message),
                    a.reportClientError(c);
                }
              }, c);
            }),
            (a.sample = function (b, c) {
              if ("function" == typeof b) {
                var d = Math.random();
                (-1 !== window.location.href.indexOf("csm_debug_mode") ||
                  c / 100 > d) &&
                  b.call(a);
              }
            }),
            (a.isValidUrl = function (a) {
              var b = new RegExp(
                "^((ftp|https?):\\/\\/)((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,})",
                "i"
              );
              return !!b.test(a);
            }),
            (a.reportErrorToTungsten = function (b, c) {
              var d, e, f, g;
              try {
                (d =
                  b === parseInt(b, 10)
                    ? { m: "' + ex + '" }
                    : amzncsm.constructErrorMessage(b)),
                  (e = [
                    {
                      ver: amzncsm.version,
                      ts: new Date().getTime(),
                      error: 1,
                      bidId: amzncsm.bidId,
                      fmp: d,
                    },
                  ]),
                  (f = function () {
                    var b,
                      f = a.getTungstenLoggingHost(
                        amzncsm.tungstenCSMLoggingFrameworkUrl,
                        c
                      );
                    f &&
                      ((b = f.startsWith("http") ? "" : "https://"),
                      a.isPSTTenant(c) &&
                        ((c = amzncsm.tungstenTenants.pstErrorLoggingEvent),
                        (e = [
                          {
                            bidId: amzncsm.bidId || "",
                            timeStamp: Date.now(),
                            failureFunction:
                              amzncsm.PST_ERROR_CODE.TUNGSTEN_LOGGING_ERROR,
                            errorStackTrace: JSON.stringify(d),
                          },
                        ])),
                      amzncsm.postRequest(b + f + c, e, function (a) {
                        amzncsm.reportClientError(a);
                      }));
                  }),
                  (g = function () {
                    return !!amzncsm.tungstenCSMLoggingFrameworkUrl;
                  }),
                  g()
                    ? f()
                    : ((amzncsm.csmReport.tungstenCsmLogs =
                        amzncsm.csmReport.tungstenCsmLogs || []),
                      amzncsm.csmReport.tungstenCsmLogs.push({
                        payload: e,
                        tenantId: c,
                        isError: 1,
                      }));
              } catch (h) {
                amzncsm.reportClientError(h);
              }
            }),
            (a.logToTungsten = function (b, c, d, e) {
              var f, g;
              try {
                (f = function () {
                  var f, g;
                  if (!amzncsm.bidId && !d) throw new Error("bidId is not set");
                  (f = a.getTungstenLoggingHost(
                    amzncsm.tungstenCSMLoggingFrameworkUrl,
                    c
                  )),
                    f &&
                      ((g = f.startsWith("http") ? "" : "https://"),
                      amzncsm.postRequest(
                        g + f + c,
                        b,
                        function (a) {
                          amzncsm.reportErrorToTungsten(a, c);
                        },
                        e
                      ));
                }),
                  (g = function () {
                    return !!amzncsm.tungstenCSMLoggingFrameworkUrl;
                  }),
                  g()
                    ? f()
                    : ((amzncsm.csmReport.tungstenCsmLogs =
                        amzncsm.csmReport.tungstenCsmLogs || []),
                      amzncsm.csmReport.tungstenCsmLogs.push({
                        payload: b,
                        tenantId: c,
                        isError: d,
                        options: e,
                      }));
              } catch (h) {
                amzncsm.reportErrorToTungsten(h, c);
              }
            }),
            (a.isRegionNA = function (a) {
              return a.indexOf(".na.") >= 0;
            }),
            (a.isPSTTenant = function (a) {
              return (
                a === amzncsm.tungstenTenants.pstErrorLoggingEvent ||
                a === amzncsm.tungstenTenants.pstRRLoggingEvent
              );
            }),
            (a.getTungstenCSMLoggingFrameworkBaseUrl = function (a) {
              var b = a.indexOf("/");
              return b > 0 ? a.substring(0, b) : a;
            }),
            (a.getTungstenLoggingHost = function (c, d) {
              return a.isPSTTenant(d) ? (a.isRegionNA(c) ? b : null) : c;
            }),
            (a.postRequest = function (a, b, c, d) {
              var e = new Headers({ "Content-Type": "application/json" }),
                f = d || {
                  cache: "no-cache",
                  method: "POST",
                  body: JSON.stringify(b),
                  headers: e,
                };
              fetch(a, f)
                .then(function (a) {
                  if (200 !== a.status) throw new Error(a.status);
                })
                ["catch"](function (a) {
                  c && c(a);
                });
            }),
            a
          );
        }),
        amzncsm.define("eventUtils", [], function () {
          var a = { shortName: "eu" };
          return (
            (a.init = function (b) {
              a.eventHandlers = [];
            }),
            (a.addEvent = function (b, c, d, e) {
              b.addEventListener
                ? b.addEventListener(c, d, e)
                : b.attachEvent && b.attachEvent("on" + c, d);
              var f = { elem: b, eventName: c, cb: d };
              a.eventHandlers.push(f);
            }),
            (a.addCustomEvent = function (a, b, c) {
              document.addEventListener
                ? document.addEventListener(a, b, c)
                : document.attachEvent
                ? document.attachEvent("on" + a, function () {
                    return b.call(document, window.event);
                  })
                : (document["on" + a] = b);
            }),
            (a.removeEvent = function (a, b, c, d) {
              (d = d || !1),
                document.removeEventListener
                  ? a.removeEventListener(b, c, d)
                  : document.detachEvent && a.detachEvent("on" + b, c);
            }),
            (a.createEvent = (function () {
              return document.createEvent
                ? function (a) {
                    var b = document.createEvent("Event");
                    return b.initEvent(a, !0, !0), b;
                  }
                : function (a) {
                    var b = document.createEventObject();
                    return (b.eventType = a), b;
                  };
            })()),
            (a.dispatchCustomEvent = function (b) {
              document.dispatchEvent
                ? document.dispatchEvent(a.createEvent(b))
                : document[b]
                ? document[b]()
                : document["on" + b] && document["on" + b]();
            }),
            (a.stopPropagation = function (a) {
              return a.stopPropagation
                ? void a.stopPropagation()
                : void (a.cancelBubble = !0);
            }),
            (a.preventDefault = function (a) {
              a.preventDefault && a.preventDefault(), (a.returnValue = !1);
            }),
            (a.getClickXY = function (a) {
              return "pageX" in a
                ? { pageX: a.pageX, pageY: a.pageY }
                : {
                    pageX: a.clientX + document.documentElement.scrollLeft,
                    pageY: a.clientY + document.documentElement.scrollTop,
                  };
            }),
            (a.getVisibilityChangeEventName = function (a) {
              var b,
                c = a.document;
              return (
                "undefined" != typeof c.hidden
                  ? (b = "visibilitychange")
                  : "undefined" != typeof c.mozHidden
                  ? (b = "mozvisibilitychange")
                  : "undefined" != typeof c.msHidden
                  ? (b = "msvisibilitychange")
                  : "undefined" != typeof c.webkitHidden &&
                    (b = "webkitvisibilitychange"),
                b
              );
            }),
            (a.handleVisibilityChange = function (b, c) {
              var d = a.getVisibilityChangeEventName(b),
                e = b.document;
              d && a.addEvent(e, d, c, !1);
            }),
            (a.isPageVisibilitySupported = function () {
              return (
                "undefined" != typeof document.hidden ||
                "undefined" != typeof document.mozHidden ||
                "undefined" != typeof document.msHidden ||
                "undefined" != typeof document.webkitHidden
              );
            }),
            (a.documentHasFocus = function (a) {
              return a.hasFocus ? a.hasFocus() : !0;
            }),
            (a.isDocHidden = function () {
              var a;
              return (
                "undefined" != typeof document.hidden
                  ? (a = "hidden")
                  : "undefined" != typeof document.mozHidden
                  ? (a = "mozHidden")
                  : "undefined" != typeof document.msHidden
                  ? (a = "msHidden")
                  : "undefined" != typeof document.webkitHidden &&
                    (a = "webkitHidden"),
                document[a]
              );
            }),
            (a.isWindowActive = function () {
              var b = a.isDocHidden();
              return "undefined" == typeof b
                ? a.documentHasFocus(document)
                : !b;
            }),
            (a.isTabActive = function () {
              var b = a.isDocHidden();
              return !(b === !0);
            }),
            (a.isWindowAndTabVisible = function (b) {
              return a.documentHasFocus(b) && a.isWindowActive();
            }),
            (a.registerPostMessageHandler = function (a) {
              var b = window.addEventListener
                  ? "addEventListener"
                  : "attachEvent",
                c = window[b],
                d = "attachEvent" == b ? "onmessage" : "message";
              c(
                d,
                function (b) {
                  var c = b.message ? "message" : "data",
                    d = b[c];
                  a(d);
                },
                !1
              );
            }),
            (a.getPixelID = (function () {
              var a = null;
              return function () {
                return (
                  null === a && (a = Math.random().toString(36).substr(2)), a
                );
              };
            })()),
            a
          );
        }),
        amzncsm.define("pixelQueue", [], function () {
          var a,
            b = { shortName: "pq" },
            c = 2500,
            d = 4;
          return (
            (b.init = function (a, b) {
              amzncsm.csmReport.pq = { queue: [], impId: b };
            }),
            (b.getPixelUrl = function () {
              var a = "https://",
                b = amzncsm.host || "aax.amazon-adsystem.com",
                c = "/x/px/",
                d = amzncsm.csmReport.pq;
              return a + b + c + (d.impId ? d.impId + "/" : "");
            }),
            (b.firePixel = function (a, b) {
              try {
                var c = JSON.parse(a);
                (c.ver = amzncsm.version), (a = JSON.stringify(c));
              } catch (d) {}
            }),
            (b.logForensicsCsmEventToTungsten = function (a, b) {
              (a = [
                {
                  ver: amzncsm.version,
                  ts: new Date().getTime(),
                  error: b ? 1 : 0,
                  bidId: amzncsm.bidId,
                  fmp: a,
                },
              ]),
                amzncsm.logToTungsten(
                  a,
                  amzncsm.tungstenTenants.forensicsCsmEvent,
                  b
                );
            }),
            (a = function () {
              var a = amzncsm.csmReport.pq;
              a.queue.length > 0 && (a.queue = []);
            }),
            (b.addPixel = function (b) {
              var e = this,
                f = amzncsm.csmReport.pq;
              amzncsm.log("Received pixel " + JSON.stringify(b)),
                0 === f.queue.length &&
                  amzncsm.setTimeout(function () {
                    f.queue.length > 0 && (e.send(), a());
                  }, c),
                f.queue.push(b),
                f.queue.length >= d && (e.send(), a());
            }),
            (b.send = function () {
              var a = amzncsm.getPixelID(),
                c = new Date().getTime(),
                d = amzncsm.csmReport.pq;
              b.firePixel(
                '{"adCsm": ' +
                  JSON.stringify(d.queue) +
                  ', "pixelId": "' +
                  a +
                  '", "ts": ' +
                  c +
                  "}",
                ""
              );
            }),
            b
          );
        }),
        amzncsm.define("hoverStats", [], function () {
          var a,
            b,
            c = { shortName: "hs" },
            d = 2;
          return (
            (c.init = function (c, d) {
              (amzncsm.csmReport[c].hs = {
                stime: 0,
                duration: 0,
                adIframe: d,
                pixelCount: 0,
              }),
                amzncsm.addEvent(d, "mouseover", a, !1),
                amzncsm.addEvent(d, "mouseout", b, !1);
            }),
            (a = function (a) {
              var b, c, d;
              try {
                (a = a || window.event),
                  (b = a.target || a.srcElement),
                  (c = "#" + b.id),
                  (amzncsm.csmReport[c].hs.stime = performance.now()),
                  (d = { hvrx: a.clientX, hvry: a.clientY }),
                  void 0 !== a.isTrusted &&
                    "" != a.isTrusted &&
                    (d.trusted = a.isTrusted),
                  amzncsm.pixelQueue.addPixel(d);
              } catch (e) {
                amzncsm.reportClientError(e);
              }
            }),
            (b = function (c) {
              var e, f, g, h, i;
              try {
                (c = c || window.event),
                  (e = performance.now()),
                  (f = c.target || c.srcElement),
                  (g = "#" + f.id),
                  (h = amzncsm.csmReport[g].hs),
                  e - h.stime > h.duration &&
                    ((h.duration = e - h.stime),
                    h.duration > 500 &&
                      ((i = { hdr: h.duration.toFixed(0) }),
                      amzncsm.pixelQueue.addPixel(i),
                      h.pixelCount++,
                      h.pixelCount >= d &&
                        (amzncsm.removeEvent(h.adIframe, "mouseout", b),
                        amzncsm.removeEvent(h.adIframe, "mouseover", a)))),
                  (h.stime = 0);
              } catch (j) {
                amzncsm.reportClientError(j);
              }
            }),
            c
          );
        }),
        amzncsm.define("pageMetrics", [], function () {
          var a,
            b = { shortName: "pm" };
          new Date().getTime();
          return (
            (b.init = function (a, b) {
              var c, d, e;
              (amzncsm.csmReport[a].pm = {
                visStatusTimes: {
                  visible: { stime: 0, duration: 0 },
                  hidden: { stime: 0, duration: 0 },
                  prerender: { stime: 0, duration: 0 },
                  unloaded: { stime: 0, duration: 0 },
                  states: "",
                },
              }),
                (c = {}),
                (d = amzncsm.csmReport[a].pm),
                b.opener && b.opener !== b && (c.ipp = !0),
                amzncsm.isPageVisibilitySupported() &&
                  ((e = amzncsm.isWindowActive() ? "visible" : "hidden"),
                  void 0 !== e &&
                    ((d.visStatusTimes.states = e.charAt(0)),
                    (d.visStatusTimes[e].stime = window.performance
                      .now()
                      .toFixed(0))),
                  amzncsm.addCustomEvent(
                    "visStateChange" + a,
                    function (b) {
                      var c,
                        d,
                        f = amzncsm.csmReport[a].pm;
                      f.visStatusTimes.states.length >= 5 ||
                        ((c = window.performance.now().toFixed(0)),
                        (d = f.visStatusTimes),
                        amzncsm.log(
                          "prev visState " +
                            e +
                            " curVisState " +
                            (amzncsm.isWindowActive() ? "visible" : "hidden")
                        ),
                        (d[e].duration += c - d[e].stime),
                        (e = amzncsm.isWindowActive() ? "visible" : "hidden"),
                        (d[e].stime = c),
                        (d.states += e.charAt(0)),
                        amzncsm.pixelQueue.addPixel(d));
                    },
                    !1
                  ));
            }),
            (a = function (a) {
              if (
                "ontouchstart" in window &&
                "string" == typeof document.body.style.webkitTextSizeAdjust
              ) {
                var b =
                  90 == Math.abs(window.orientation)
                    ? screen.height
                    : screen.width;
                a.pz = b / window.innerWidth;
              }
            }),
            b
          );
        }),
        amzncsm.define("detectBrowser", [], function () {
          var a,
            b = { shortName: "db" },
            c = function () {
              return null != a
                ? a
                : (a = (function () {
                    var a,
                      b,
                      c,
                      d,
                      e,
                      f = [],
                      g = "unknown",
                      h = {
                        trident: 0,
                        gecko: 0,
                        presto: 0,
                        webkit: 0,
                        unknown: -1,
                      },
                      i = {},
                      j = document.createElement("nadu");
                    for (a in j.style)
                      (g = (/^([A-Za-z][a-z]*)[A-Z]/.exec(a) || [])[1]),
                        g &&
                          ((g = g.toLowerCase()), g in i ? i[g]++ : (i[g] = 1));
                    for (b in i) f.push([b, i[b]]);
                    for (
                      f = f
                        .sort(function (a, b) {
                          return b[1] - a[1];
                        })
                        .slice(0, 10),
                        c = 0;
                      c < f.length;
                      c++
                    )
                      switch (f[c][0]) {
                        case "moz":
                          h.gecko += 5;
                          break;
                        case "ms":
                          h.trident += 5;
                          break;
                        case "get":
                          h.webkit++;
                          break;
                        case "webkit":
                          h.webkit += 5;
                          break;
                        case "o":
                          h.presto += 2;
                          break;
                        case "xv":
                          h.presto += 2;
                      }
                    "onhelp" in window && h.trident++,
                      "maxConnectionsPerServer" in window && h.trident++;
                    try {
                      void 0 !== window.ActiveXObject.toString &&
                        (h.trident += 5);
                    } catch (k) {}
                    void 0 !== function () {}.toSource && (h.gecko += 5),
                      (d = "unknown");
                    for (e in h) h[e] > h[d] && (d = e);
                    return d;
                  })());
            };
          return (
            (b.isChrome = function () {
              return !!window.chrome && !!window.chrome.webstore;
            }),
            (b.isFirefox = function () {
              return "undefined" != typeof InstallTrigger;
            }),
            (b.isSafari = function () {
              return (
                !b.isChrome() &&
                !b.isEdge() &&
                !b.isOpera() &&
                "WebkitAppearance" in document.documentElement.style
              );
            }),
            (b.isOpera = function () {
              return !!window.opera || (!!window.opr && !!window.opr.addons);
            }),
            (b.isIE = function () {
              return !1 || !!document.documentMode;
            }),
            (b.isEdge = function () {
              return (
                !b.isIE() &&
                "undefined" != typeof CSS &&
                CSS.supports("(-ms-ime-align:auto)")
              );
            }),
            (b.isGecko = function () {
              return "gecko" == c();
            }),
            (b.isTrident = function () {
              return "trident" == c();
            }),
            (b.isWebkit = function () {
              return "webkit" == c();
            }),
            (b.isInternetExplorer = function () {
              return (
                void 0 !== window.chrome &&
                void 0 !== navigator.msLaunchUri &&
                void 0 === window.ActiveXObject &&
                b.isTrident()
              );
            }),
            (b.init = function (a) {}),
            b
          );
        }),
        amzncsm.define("domainMask", [], function () {
          function a() {
            var a = window,
              b = !1;
            try {
              for (; a.parent.document !== a.document; ) {
                if (!a.parent.document) {
                  b = !0;
                  break;
                }
                a = a.parent;
              }
            } catch (c) {
              b = !0;
            }
            return { topFrame: a, err: b };
          }
          function b(a) {
            var b,
              c = a.err,
              d = a.topFrame,
              e = "";
            if (c)
              try {
                try {
                  e = window.top.location.hostname;
                } catch (f) {
                  window.location.ancestorOrigins
                    ? ((b = window.location.ancestorOrigins),
                      (e = b[b.length - 1]))
                    : parent === top && (e = document.referrer);
                }
              } catch (f) {
                e = d.document.referrer;
              }
            else e = d.location.hostname;
            return e;
          }
          function c() {
            var c,
              d,
              e,
              f = a(),
              g = b(f);
            /^https?:\/\//.test(g) === !0 &&
              ((c = /https?:\/\/([^\/]*)/), (d = g.match(c)), (g = d[1])),
              g &&
                (amzncsm.log("Top level domain url " + g),
                (e = { tld: encodeURIComponent(g) }),
                amzncsm.pixelQueue.addPixel(e));
          }
          var d = { shortName: "dm" };
          return (
            (d.init = function (a) {
              c();
            }),
            d
          );
        }),
        (amzncsm.detectViewability = function (a, b, c, d, e) {
          function f() {
            return A.iab && A.groupm && A.amazon;
          }
          function g() {
            var a;
            A.iab === !1 &&
              ((a =
                void 0 !== z.visibilityState && "visible" !== z.visibilityState
                  ? "notActiveTab"
                  : amzncsm.documentHasFocus(z) === !1
                  ? "windowInBackground"
                  : "notInVP"),
              j(
                '{"adViewability":[{"vCancel": "' +
                  a +
                  '", "pixelId": "' +
                  x +
                  '"}]}',
                ""
              ));
          }
          function h(a, b) {
            var c = new Date().getTime(),
              d = e === !0 ? "_ben" : "",
              f = {},
              g =
                amzncsm.isAmp === !0
                  ? amzncsm.computeAmpViewability
                  : amzncsm.computeViewability;
            try {
              switch (a) {
                case "above_the_fold":
                  (f["atf" + d] = b.atf),
                    g.generatePayload(f),
                    j(JSON.stringify(f), "" === d ? "atf/" : "");
                  break;
                case "viewable":
                  (f["v" + d] = { def: b.defn, p: b.p, t: b.t }),
                    window.performance &&
                      window.performance.timing &&
                      ((f.ttv = (
                        (c -
                          (window.performance.timing.responseStart ||
                            window.performance.timing.domLoading)) /
                        1e3
                      ).toFixed(2)),
                      y &&
                        y.performance &&
                        y.performance.timing &&
                        (f.ptv = (
                          (c -
                            (y.performance.timing.responseStart ||
                              y.performance.timing.domLoading)) /
                          1e3
                        ).toFixed(2))),
                    g.getScrollIndex &&
                      g.distanceFromVPCenter &&
                      ((f.si = g.getScrollIndex(k, l)),
                      (f.dcv = g.distanceFromVPCenter())),
                    g.generatePayload(f),
                    j(JSON.stringify(f), "" === d ? "v/" : "");
                  break;
                case "unmeasured":
                  (f["atf" + d] = "unknown"),
                    (f.ts = new Date().getTime()),
                    (f.pixelId = x),
                    j(JSON.stringify(f), "" === d ? "atf/" : "");
              }
            } catch (h) {
              amzncsm.log(h), amzncsm.reportClientError(h);
            }
          }
          function i() {
            function a() {
              F && (amzncsm.log("Cleared setTimeout call"), clearTimeout(F)),
                (F = amzncsm.setTimeout(function () {
                  h("viewable", { viewable: !0, defn: "iab", p: 50, t: 1 }),
                    (A.iab = !0);
                }, v));
            }
            function b() {
              (H = !0),
                a(),
                (D = new Date().getTime() / 1e3),
                (k = amzncsm.computeViewability.scrollX),
                (l = amzncsm.computeViewability.scrollY),
                amzncsm.log(w + " In View");
            }
            function c() {
              (H = !1),
                clearTimeout(F),
                (E = new Date().getTime() / 1e3),
                amzncsm.log(w + " Not In View"),
                amzncsm.log(w + " viewed for: " + (E - D) + " seconds");
            }
            function e(a) {
              return amzncsm.isAmp === !0
                ? amzncsm.computeAmpViewability.isPageVisible()
                : amzncsm.isWindowAndTabVisible(a);
            }
            function i(a, b) {
              var c = e(z);
              switch (a) {
                case "IAB":
                  c = c && b >= s;
                  break;
                case "GROUPM":
                  c = c && b >= t;
                  break;
                case "AMZN":
                  c = c && b >= u;
              }
              return c;
            }
            function j(a) {
              A.iab === !1 && (i("IAB", a) ? H === !1 && b() : H === !0 && c());
            }
            function m(a) {
              A.groupm === !1 &&
                i("GROUPM", a) &&
                (h("viewable", { viewable: !0, defn: "groupm", p: 100, t: 0 }),
                (A.groupm = !0));
            }
            function n(a) {
              A.amazon === !1 &&
                i("AMZN", a) &&
                (h("viewable", { viewable: !0, defn: "amzn", p: 0, t: 0 }),
                (A.amazon = !0));
            }
            function o(a) {
              m(a), n(a), j(a);
            }
            function p(a) {
              i("IAB", a) && amzncsm.setTimeout(g, v + 200);
            }
            function q(a) {
              var b = a >= s;
              h("above_the_fold", { atf: b });
            }
            function r(a) {
              i("IAB", a)
                ? amzncsm.dispatchCustomEvent("vis" + d)
                : amzncsm.dispatchCustomEvent("inv" + d),
                amzncsm.log("Area fraction inside viewport " + a);
            }
            function x(a) {
              r(a), q(a), o(a), p(a);
            }
            function B(a) {
              h("unmeasured"), amzncsm.reportClientError(a);
            }
            function C(a) {
              r(a), o(a);
            }
            var D,
              E,
              F,
              G = 0,
              H = !1;
            return function (a) {
              if (amzncsm.computeViewability) {
                if (amzncsm.isAmp === !0)
                  return void amzncsm.computeAmpViewability.initViewComp(
                    x,
                    B,
                    C
                  );
                (G = amzncsm.computeViewability.fractionInViewport(y, z)),
                  r(G),
                  f() === !1 && (a === !0 ? (q(G), o(G), p(G)) : o(G));
              }
            };
          }
          function j() {
            var a = Array.prototype.slice.call(arguments);
            amzncsm.pixelQueue.firePixel.apply(amzncsm.pixelQueue, a);
          }
          var k,
            l,
            m,
            n,
            o,
            p,
            q,
            r,
            s = 0.5,
            t = 0.95,
            u = 0.05,
            v = 1e3,
            w = a,
            x = amzncsm.getPixelID(),
            y = b,
            z = c,
            A = { iab: !1, groupm: !1, amazon: !1 };
          for (
            this.collectData = function () {
              var a,
                b = i();
              b(!0),
                amzncsm.isAmp !== !0 &&
                  ((a = function () {
                    try {
                      var a = amzncsm.setTimeout(function () {
                        a && clearTimeout(a), b(!1);
                      }, 50);
                    } catch (c) {
                      amzncsm.log(c), amzncsm.reportClientError(c);
                    }
                  }),
                  amzncsm.addEvent(y, "blur", a, !1),
                  amzncsm.addEvent(y, "focus", a, !1),
                  amzncsm.handleVisibilityChange(window, function () {
                    amzncsm.dispatchCustomEvent("visStateChange" + d), a();
                  }),
                  amzncsm.addEvent(y, "resize", a, !1),
                  amzncsm.addEvent(y, "scroll", a, !1),
                  amzncsm.addCustomEvent(
                    "vdrcompl" + d,
                    function (b) {
                      amzncsm.removeEvent(y, "blur", a),
                        amzncsm.removeEvent(y, "focus", a),
                        amzncsm.removeEvent(y, "resize", a),
                        amzncsm.removeEvent(y, "scroll", a),
                        amzncsm.log("Removed all attached handlers");
                    },
                    !1
                  ));
            },
              m = null,
              n = 0,
              this.xdifr = !1;
            y.parent && y != y.parent && this.xdifr === !1 && 5 >= n;

          )
            try {
              n++,
                (o = y.parent),
                (p =
                  o.document && o.document.body && o.document.body.innerHTML),
                p && ((m = y), (y = y.parent), (z = y.document));
            } catch (B) {
              (this.xdifr = !0),
                amzncsm.log(
                  "Exception " +
                    B +
                    " while crawling up the iframe ancestral path"
                );
              break;
            }
          if (
            this.xdifr === !0 &&
            amzncsm.isAmp !== !0 &&
            amzncsm.computeViewability
          )
            return void h("unmeasured");
          if (null != m)
            for (
              q = z.getElementsByTagName("iframe"), q = [].slice.call(q), r = 0;
              r < q.length;
              r++
            )
              if (q[r].contentWindow == m) {
                w = q[r];
                break;
              }
          a && a.document && "IFRAME" != a.tagName && (a = a.document.body),
            w && w.document && "IFRAME" != w.tagName && (w = w.document.body),
            amzncsm.log("Initiated viewability module"),
            (amzncsm.csmReport[d].container = w),
            (amzncsm.csmReport[d].adElement = a);
        }),
        (initCSM = function (a, b, c, d, e) {
          var f,
            g = "DTB",
            h = "Error occurred while processing method rmD";
          try {
            (amzncsm.impId = b),
              (amzncsm.bmk = e),
              (amzncsm.host = window.amzncsm.host),
              amzncsm.rm(g, { e: a, i: b, w: c, d: d });
          } catch (i) {
            (f = i.message ? i.message : h), amzncsm.reportErrors(g, b, f);
          }
        }),
        (window.amzncsm.rmD = function (a, b, c, d, e, f) {
          (amzncsm.csmParams = f),
            f && f.renderType && (amzncsm.isAmp = "AMP" === f.renderType),
            initCSM(a, b, c, d, !1);
        }),
        (window.amzncsm.rmDN = function (a, b, c, d) {
          initCSM(a, b, c, d, !0);
        }),
        (window.amzncsm.rmN = function (a, b, c, d) {
          var e,
            f = "NSA",
            g = "Error occurred while processing method rmN";
          try {
            (amzncsm.impId = b), amzncsm.rm(f, { e: a, i: b, w: c, d: d });
          } catch (h) {
            (e = h.message ? h.message : g), amzncsm.reportErrors(f, b, e);
          }
        }),
        amzncsm.define("privateStateToken", [], function () {
          var a,
            b,
            c,
            d,
            e,
            f,
            g = { shortName: "pst" },
            h = { chrome: "private-state-token-redemption" },
            i = "https://www.amazon.com/tt/r",
            j = "https://www.amazon.com";
          return (
            (g.init = function () {
              a();
            }),
            (a = function () {
              if (b()) {
                var a = c();
                a
                  ? document
                      .hasRedemptionRecord(j)
                      .then(function (a) {
                        a ? e(a, !1) : d();
                      })
                      ["catch"](function (a) {
                        amzncsm.log(
                          "Error in calling hasRedemptionRecord function : " +
                            a.toString()
                        ),
                          f(
                            a,
                            amzncsm.PST_ERROR_CODE.HAS_RR_API_FAILURE,
                            !1,
                            !1
                          );
                      })
                  : null !== a &&
                    (amzncsm.log(
                      "PrivateStateToken feature policy not supported."
                    ),
                    f(
                      null,
                      amzncsm.PST_ERROR_CODE.UNSUPPORTED_FEATURE_POLICY,
                      !1,
                      !1
                    ));
              }
            }),
            (b = function () {
              try {
                return "function" == typeof document.hasPrivateToken;
              } catch (a) {
                return amzncsm.log("PST operation is not supported."), null;
              }
            }),
            (c = function () {
              try {
                return (
                  "undefined" != typeof document.featurePolicy &&
                  "undefined" != typeof document.featurePolicy.allowsFeature &&
                  document.featurePolicy.allowsFeature(h.chrome)
                );
              } catch (a) {
                return (
                  amzncsm.log(
                    "Exception in validating if PrivateStateToken feature policy is supported."
                  ),
                  f(a, amzncsm.PST_ERROR_CODE.FEATURE_POLICY_EXCEPTION, !1, !1),
                  null
                );
              }
            }),
            (d = function () {
              document
                .hasPrivateToken(j)
                .then(function (a) {
                  a
                    ? fetch(i, {
                        privateToken: {
                          version: 1,
                          operation: "token-redemption",
                          refreshPolicy: "none",
                        },
                      })
                        .then(function (b) {
                          amzncsm.log(
                            "Response from redeem call : " +
                              b.status +
                              "," +
                              b.statusText
                          ),
                            200 !== b.status
                              ? f(
                                  b.status,
                                  amzncsm.PST_ERROR_CODE
                                    .TRS_RESPONSE_STATUS_NOT_200,
                                  !1,
                                  a
                                )
                              : e(!1, a);
                        })
                        ["catch"](function (b) {
                          amzncsm.log(
                            "Error in redeeming token : " + b.toString()
                          ),
                            f(
                              b,
                              amzncsm.PST_ERROR_CODE.REDEMPTION_ERROR,
                              !1,
                              a
                            );
                        })
                    : (amzncsm.log(
                        "No Private State Token present in browser."
                      ),
                      f(null, amzncsm.PST_ERROR_CODE.TOKEN_NOT_PRESENT, !1, a));
                })
                ["catch"](function (a) {
                  amzncsm.log(
                    "Error in calling hasPrivateToken function : " +
                      a.toString()
                  ),
                    f(a, amzncsm.PST_ERROR_CODE.HAS_TOKEN_API_FAILURE, !1, !1);
                });
            }),
            (e = function (a, b) {
              var c, d, e, g;
              try {
                (c = [
                  {
                    bidId: amzncsm.bidId || "",
                    hasToken: b,
                    hasRR: a,
                    timeStamp: Date.now(),
                  },
                ]),
                  (d = {
                    version: 1,
                    operation: "send-redemption-record",
                    issuers: [j],
                  }),
                  (e = new Headers({ "Content-Type": "application/json" })),
                  (g = {
                    cache: "no-cache",
                    method: "POST",
                    body: JSON.stringify(c),
                    privateToken: d,
                    headers: e,
                  }),
                  amzncsm.logToTungsten(
                    c,
                    amzncsm.tungstenTenants.pstRRLoggingEvent,
                    !1,
                    g
                  );
              } catch (h) {
                amzncsm.log(
                  "Error in constructing params for send-rr call : " +
                    h.toString()
                ),
                  f(h, amzncsm.PST_ERROR_CODE.SEND_RR_PAYLOAD_ERROR, a, b);
              }
            }),
            (f = function (a, b, c, d, e) {
              var f, g;
              try {
                (f = a
                  ? a === parseInt(a, 10)
                    ? '{"m": "' + a + '"}'
                    : amzncsm.constructErrorMessage(a)
                  : ""),
                  (g = [
                    {
                      bidId: amzncsm.bidId || "",
                      hasToken: d,
                      hasRR: c,
                      failureFunction: b,
                      timeStamp: Date.now(),
                      errorStackTrace: JSON.stringify(f),
                      extraInfoJSON: e ? JSON.stringify(e) : "",
                    },
                  ]),
                  amzncsm.logToTungsten(
                    g,
                    amzncsm.tungstenTenants.pstErrorLoggingEvent,
                    !1
                  );
              } catch (a) {
                amzncsm.reportErrorToTungsten(
                  a,
                  amzncsm.tungstenTenants.pstErrorLoggingEvent
                );
              }
            }),
            g
          );
        }),
        (amzncsm.rm = (function () {
          var a, b, c, d, e, f, g, h;
          return (
            (amzncsm.version = "d-1.19"),
            (amzncsm.version = "d-1.24"),
            (amzncsm.initTime = new Date()),
            (amzncsm.fscm = [9, 16, 21, 30]),
            (amzncsm.tungstenTenants = {
              pstRRLoggingEvent: "pstRRLoggingEvent",
              pstErrorLoggingEvent: "pstErrorLoggingEvent",
            }),
            (a = {
              DTB: {
                viewDuration: !0,
                hoverStats: !0,
                pageMetrics: !0,
                domainMask: !0,
                detectBrowser: !0,
                privateStateToken: !1,
                computeViewability: !0,
                computeAmpViewability: !0,
              },
              NSA: {
                viewDuration: !1,
                hoverStats: !1,
                pageMetrics: !1,
                domainMask: !1,
                detectBrowser: !1,
                privateStateToken: !1,
                computeViewability: !0,
              },
            }),
            (a.DTB.privateStateToken = !0),
            (b = function (a) {
              for (var b, c, d = []; a.parentNode; ) {
                if (a.id) {
                  d.unshift("#" + a.id);
                  break;
                }
                if (a == a.ownerDocument.documentElement) d.unshift(a.tagName);
                else {
                  for (
                    b = 1, c = a;
                    c.previousElementSibling;
                    c = c.previousElementSibling, b++
                  );
                  d.unshift(a.tagName + ":nth-child(" + b + ")");
                }
                a = a.parentNode;
              }
              return d.join(" > ").substring(0, 100);
            }),
            (c = function (a) {
              var b, c;
              if (
                window.performance &&
                window.performance.getEntriesByType &&
                "function" == typeof window.performance.getEntriesByType
              )
                for (
                  b = window.performance.getEntriesByType("resource"), c = 0;
                  c < b.length;
                  ++c
                )
                  if (a.test(b[c].name) === !0) return b[c];
              return null;
            }),
            (d = function () {
              var a,
                b,
                d = new RegExp("csm([\\S]+)?.js"),
                e = c(d);
              null !== e &&
                ((a =
                  window.performance.timing &&
                  "undefined" !=
                    typeof window.performance.timing.navigationStart
                    ? window.performance.timing.navigationStart
                    : 0),
                (b = {
                  ns: a,
                  st: e.startTime.toFixed(2),
                  re: e.responseEnd.toFixed(2),
                  ldTot: e.duration.toFixed(2),
                }),
                amzncsm.pixelQueue.addPixel(b));
            }),
            (e = function (a) {
              var b,
                c,
                d,
                e = window.performance.getEntriesByType("measure"),
                f = {};
              for (b = 0; b < e.length; ++b)
                e[b].name.endsWith(a) &&
                  ((c = e[b]),
                  (d = c.name.substring(0, c.name.length - a.length)),
                  (f[d] = c.duration.toFixed(2)));
              amzncsm.pixelQueue.addPixel(f);
            }),
            (f = function (a, c) {
              var d,
                f = c.e,
                g = c.i,
                i = c.w,
                j = c.d,
                k = amzncsm.bmk,
                l = b(f);
              if (
                ((amzncsm.csmReport = amzncsm.csmReport || {}),
                amzncsm.csmReport.hasOwnProperty(l))
              ) {
                if (
                  (1 === amzncsm.csmReport[l].reg && k === !1) ||
                  (1 === amzncsm.csmReport[l].ben && k === !0)
                )
                  return !1;
                k === !0
                  ? (amzncsm.csmReport[l].ben = 1)
                  : (amzncsm.csmReport[l].reg = 1);
              } else
                amzncsm.csmReport[l] = {
                  reg: k === !1 ? 1 : 0,
                  ben: k === !0 ? 1 : 0,
                };
              amzncsm.log("Initiating CSM computation for ad slot " + l),
                h(a, f, g, i, j, l),
                window.performance &&
                  window.performance.mark &&
                  "function" == typeof window.performance.mark &&
                  window.performance.mark("csmStart" + l),
                (amzncsm.api = a),
                (d = new amzncsm.detectViewability(f, i, j, l, k)),
                (d.xdifr !== !1 && amzncsm.isAmp !== !0) ||
                  !d.collectData ||
                  d.collectData(),
                window.performance &&
                  window.performance.mark &&
                  "function" == typeof window.performance.mark &&
                  (window.performance.mark("csmEnd" + l),
                  window.performance.measure(
                    "csmTot" + l,
                    "csmStart" + l,
                    "csmEnd" + l
                  ),
                  e(l)),
                amzncsm.errors.length > 0 && amzncsm.reportErrors(a, g);
            }),
            (g = function () {
              try {
                var a = function (a) {
                  var b, c;
                  try {
                    if (
                      ((b = JSON.parse(a)),
                      !b ||
                        !b.tungstenCSMLoggingFrameworkUrl ||
                        amzncsm.tungstenCSMLoggingFrameworkUrl)
                    )
                      return;
                    (amzncsm.tungstenCSMLoggingFrameworkUrl =
                      b.tungstenCSMLoggingFrameworkUrl),
                      (amzncsm.bidId = b.bidId);
                  } catch (d) {
                    return;
                  }
                  try {
                    (c = amzncsm.csmReport.tungstenCsmLogs || []),
                      c &&
                        c instanceof Array &&
                        c.forEach(function (a) {
                          var b = a.payload;
                          b.forEach(function (a) {
                            a.bidId = amzncsm.bidId;
                          }),
                            a.options &&
                              a.options.body &&
                              (a.options.body = JSON.stringify(b)),
                            amzncsm.logToTungsten(
                              b,
                              a.tenantId,
                              a.isError,
                              a.options
                            );
                        });
                  } catch (d) {
                    amzncsm.reportClientError(d);
                  }
                };
                amzncsm.registerPostMessageHandler(a);
              } catch (b) {
                amzncsm.reportClientError(b);
              }
            }),
            (h = function (b, c, e, f, h, i) {
              var j,
                k,
                l,
                m = amzncsm.getModules(c, e, f, h);
              for (j in m)
                if (
                  m.hasOwnProperty(j) &&
                  ((k = m[j]),
                  (k["default"] === !0 || a[b][j] === !0) &&
                    (amzncsm.loadModules(i, [{ name: j, params: k.params }]),
                    k.global === !0))
                )
                  for (l in amzncsm[j])
                    amzncsm[j].hasOwnProperty(l) &&
                      (amzncsm[l] = amzncsm[j][l]);
              g(),
                window.ADF &&
                  (window.ADF.init({
                    pixelQueue: amzncsm.pixelQueue,
                    eventUtils: amzncsm.eventUtils,
                  }),
                  delete window.ADF),
                d();
            }),
            f
          );
        })());
    })();
