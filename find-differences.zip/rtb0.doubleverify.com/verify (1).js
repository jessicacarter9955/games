try {
  __tagObject_callback_1795264613347627({
    ImpressionID: "ec6c4e217c134989bd627a8c12f2bcee",
    ServerPublicDns: "maestro-ue1.tps.dv.tech",
  });
} catch (e) {}
try {
  $dvbs.pubSub.publish(
    "BeforeDecisionRender",
    "ec6c4e217c134989bd627a8c12f2bcee"
  );
} catch (e) {}
try {
  __verify_callback_1795264613347627({
    ResultID: 2,
    Passback: "",
    ServerContext: {
      fd: {
        researchCollection: {
          adid: "2710108543176062008",
          d9: "3658259561767602418,-5488740230212662710",
          d13: "20261121",
          icat: "false",
          d12: "false",
          exti: "2848296441",
          d2: "0.05",
          crad: "false",
          tapt: "12",
          d14: "",
          d1: "10",
          impi: "ec6c4e217c134989bd627a8c12f2bcee",
          dety: "1",
          d3: "rc20260909",
          urti: "1284",
          doha: "-5767225446047257874",
          d6: "",
        },
        common: { isBsAllow: "true" },
        isBsAllow: true,
      },
      ce: { ddt: 1, dt: 1 },
    },
  });
} catch (e) {}
try {
  $dvbs.pubSub.publish(
    "AfterDecisionRender",
    "ec6c4e217c134989bd627a8c12f2bcee"
  );
} catch (e) {}
