try {
  var dv_win = window._dv_win || window.parent._dv_win;
  dv_win["dvCallback_1795264613347863"](
    $dv,
    window,
    "7930491d76e34d2689dccf3fe9882ad9",
    "maestro-ue1.tps.dv.tech",
    {
      fd: {
        researchCollection: {
          adid: "2710108543176062008",
          d9: "3658259561767602418,-5488740230212662710",
          d13: "20261121",
          icat: "false",
          d12: "false",
          exti: "2848296441",
          d2: "0.05",
          crad: "false",
          tapt: "1",
          d14: "",
          d1: "10",
          impi: "7930491d76e34d2689dccf3fe9882ad9",
          dety: "1",
          d3: "rc20260909",
          urti: "1284",
          doha: "-5767225446047257874",
          d6: "",
        },
        isBsAllow: false,
      },
      ce: { ddt: 1, dt: 1 },
    }
  );
} catch (e) {
  try {
    var image = window.document.createElement("img");
    image.src =
      ("https://tps.doubleverify.com/visit.jpg" ||
        window.location.protocol + "//tps30.doubleverify.com/visit.jpg") +
      "?ctx=818052&cmp=1619415&dvtagver=6.1.src&dvp_cbError=" +
      encodeURIComponent(e.message);
  } catch (e) {}
}
try {
  $dv.pubSub.publish("ImpressionServed", $uid);
  $dv.pubSub.publish("ImpressionServed", $frmId);
} catch (e) {}
