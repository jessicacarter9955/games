(function () {
  let e = new Uint8Array(16);
  function t() {
    return crypto.getRandomValues(e);
  }
  let n = [];
  for (let e = 0; e < 256; ++e) n.push((e + 256).toString(16).slice(1));
  function r(e, t = 0) {
    return (
      n[e[t + 0]] +
      n[e[t + 1]] +
      n[e[t + 2]] +
      n[e[t + 3]] +
      `-` +
      n[e[t + 4]] +
      n[e[t + 5]] +
      `-` +
      n[e[t + 6]] +
      n[e[t + 7]] +
      `-` +
      n[e[t + 8]] +
      n[e[t + 9]] +
      `-` +
      n[e[t + 10]] +
      n[e[t + 11]] +
      n[e[t + 12]] +
      n[e[t + 13]] +
      n[e[t + 14]] +
      n[e[t + 15]]
    ).toLowerCase();
  }
  let i = {};
  function a(e, n, a) {
    let c;
    if (e) c = s(e.random ?? e.rng?.() ?? t(), e.msecs, e.seq, n, a);
    else {
      let e = Date.now(),
        r = t();
      o(i, e, r), (c = s(r, i.msecs, i.seq, n, a));
    }
    return n ?? r(c);
  }
  function o(e, t, n) {
    return (
      (e.msecs ??= -1 / 0),
      (e.seq ??= 0),
      t > e.msecs
        ? ((e.seq = (n[6] << 23) | (n[7] << 16) | (n[8] << 8) | n[9]),
          (e.msecs = t))
        : ((e.seq = (e.seq + 1) | 0), e.seq === 0 && e.msecs++),
      e
    );
  }
  function s(e, t, n, r, i = 0) {
    if (e.length < 16) throw Error(`Random bytes length must be >= 16`);
    if (!r) (r = new Uint8Array(16)), (i = 0);
    else if (i < 0 || i + 16 > r.length)
      throw RangeError(
        `UUID byte range ${i}:${i + 15} is out of buffer bounds`
      );
    return (
      (t ??= Date.now()),
      (n ??= ((e[6] * 127) << 24) | (e[7] << 16) | (e[8] << 8) | e[9]),
      (r[i++] = (t / 1099511627776) & 255),
      (r[i++] = (t / 4294967296) & 255),
      (r[i++] = (t / 16777216) & 255),
      (r[i++] = (t / 65536) & 255),
      (r[i++] = (t / 256) & 255),
      (r[i++] = t & 255),
      (r[i++] = 112 | ((n >>> 28) & 15)),
      (r[i++] = (n >>> 20) & 255),
      (r[i++] = 128 | ((n >>> 14) & 63)),
      (r[i++] = (n >>> 6) & 255),
      (r[i++] = ((n << 2) & 255) | (e[10] & 3)),
      (r[i++] = e[11]),
      (r[i++] = e[12]),
      (r[i++] = e[13]),
      (r[i++] = e[14]),
      (r[i++] = e[15]),
      r
    );
  }
  function c() {
    return `window` in globalThis ? globalThis.window : void 0;
  }
  function l(e) {
    try {
      return e();
    } catch {
      return;
    }
  }
  function u() {
    try {
      return c()?.history;
    } catch {
      return;
    }
  }
  function d() {
    if (typeof performance < `u`) {
      if (Number.isFinite(performance.timeOrigin))
        return Math.round(performance.timeOrigin);
      if (typeof performance.now == `function`)
        return Math.round(Date.now() - performance.now());
    }
    return Date.now();
  }
  function f(e) {
    let t = e.trim();
    return t.startsWith(`<%`) && t.endsWith(`%>`);
  }
  let p = new Set();
  function m(e) {
    if (typeof document > `u`) return;
    let t = document
      .querySelector(`meta[name="sg:${e}"]`)
      ?.getAttribute(`content`);
    if (!t) return;
    let n = t.trim();
    if (n.length !== 0) {
      if (f(n)) {
        p.has(e) ||
          (p.add(e),
          console.error(
            `Unresolved template placeholder found in <meta name="sg:${e}"> content. Replace values like <%ENVIRONMENT%> with real values before deployment.`
          ));
        return;
      }
      return n;
    }
  }
  let h = `sg:persisted-session`,
    g = `${h}=`;
  function _(e) {
    return typeof e == `object` && !!e && !Array.isArray(e);
  }
  let v = {
    read: () => {
      try {
        let e = u()?.state;
        if (!_(e)) return null;
        let t = e[h];
        return typeof t == `string` ? t : null;
      } catch {
        return null;
      }
    },
    write: (e) => {
      let t = u();
      if (t)
        try {
          let { state: n } = t;
          if (n != null && !_(n)) return;
          t.replaceState({ ...n, [h]: e }, ``);
        } catch {}
    },
    clear: () => {
      let e = u();
      if (e)
        try {
          let { state: t } = e;
          if (!_(t) || !(`sg:persisted-session` in t)) return;
          let n = { ...t };
          delete n[h],
            e.replaceState(Object.keys(n).length === 0 ? null : n, ``);
        } catch {}
    },
  };
  function y(e) {
    return {
      read: () => {
        try {
          return l(e)?.getItem(`sg:persisted-session`) ?? null;
        } catch {
          return null;
        }
      },
      write: (t) => {
        try {
          l(e)?.setItem(h, t);
        } catch {}
      },
      clear: () => {
        try {
          l(e)?.removeItem(h);
        } catch {}
      },
    };
  }
  let b = [
    {
      read: () => {
        try {
          let e = c()?.name ?? ``;
          return e.startsWith(g) ? e.slice(g.length) : null;
        } catch {
          return null;
        }
      },
      write: (e) => {
        let t = c();
        if (t)
          try {
            let { name: n } = t;
            (n === `` || n.startsWith(g)) && (t.name = `${g}${e}`);
          } catch {}
      },
      clear: () => {
        let e = c();
        if (e)
          try {
            e.name.startsWith(g) && (e.name = ``);
          } catch {}
      },
    },
    y(() => sessionStorage),
    v,
    y(() => localStorage),
  ];
  function x() {
    let e = b.map((e) => e.read());
    for (let e of b) e.clear();
    for (let t of e) {
      if (t === null) continue;
      let e = S(t);
      if (e) return e;
    }
  }
  function S(e) {
    try {
      let t = JSON.parse(e);
      if (typeof t.id == `string` && typeof t.ttl == `number` && t.ttl >= d()) {
        let e = typeof t.retryAttempts == `number` ? t.retryAttempts + 1 : 1;
        return { sessionId: t.id, retryAttempts: e };
      }
    } catch {}
  }
  function C() {
    let e = globalThis.SESSION;
    if (e && typeof e == `object`) return e;
    let t = { retryAttempts: 0 };
    return (globalThis.SESSION = t), t;
  }
  function w(e) {
    if (typeof e.timestamp == `number` && Number.isFinite(e.timestamp))
      return e.timestamp;
    let t = d();
    return (e.timestamp = t), t;
  }
  function T(e) {
    if (e.sessionId) return e.sessionId;
    let t = x();
    if (t)
      return (
        (e.sessionId = t.sessionId),
        (e.retryAttempts = t.retryAttempts),
        t.sessionId
      );
    let n = a({ msecs: w(e) });
    return (e.sessionId = n), n;
  }
  function E() {
    let e = C();
    return (
      w(e),
      T(e),
      (e.environment ||= m(`environment`) ?? ``),
      (e.platform ||= m(`platform`) ?? ``),
      (e.gameSlug ||= m(`game-slug`) ?? ``),
      (e.gameVersion ||= m(`game-version`) ?? ``),
      e
    );
  }
  let D = `https://d3ok7fu77sdimr.cloudfront.net/g/web-games`;
  function O(e, t) {
    let n = JSON.stringify({
      eventName: e,
      payload: { ...t, "Schema Version": `171` },
    });
    k(n) || A(n);
  }
  function k(e) {
    if (typeof navigator > `u` || typeof navigator.sendBeacon != `function`)
      return !1;
    try {
      let t = `${D}?x-api-key=web-games_KTfgCZMzLA6O`;
      return navigator.sendBeacon(t, e);
    } catch {
      return !1;
    }
  }
  function A(e) {
    if (typeof fetch == `function`)
      try {
        fetch(D, {
          method: `PUT`,
          headers: {
            "x-api-key": `web-games_KTfgCZMzLA6O`,
            "Content-Type": `application/json`,
          },
          body: e,
          keepalive: !0,
          credentials: `omit`,
        });
      } catch {}
  }
  function j(e) {
    return typeof e == `string` && f(e);
  }
  function M() {
    let { currentScript: e } = document;
    if (!N(e)) return { data: {}, hasUnresolvedTemplateParams: !1 };
    try {
      let t = new URL(e.src).searchParams,
        n = t.get(`environment`),
        r = t.get(`platform`),
        i = t.get(`gameSlug`),
        a = t.get(`gameVersion`),
        o = j(n) || j(r) || j(i) || j(a);
      return {
        data: {
          environment: n ?? void 0,
          platform: r ?? void 0,
          gameSlug: i ?? void 0,
          gameVersion: a ?? void 0,
        },
        hasUnresolvedTemplateParams: o,
      };
    } catch {
      return { data: {}, hasUnresolvedTemplateParams: !1 };
    }
  }
  function N(e) {
    return e instanceof HTMLScriptElement;
  }
  function P() {
    return (
      globalThis.location.protocol === `file:` ||
      globalThis.location.origin === `null`
    );
  }
  function F() {
    try {
      if (P()) return;
      let e = C(),
        t = M();
      if (t.hasUnresolvedTemplateParams) {
        console.error(
          `Unresolved template placeholders found in session-start script query params. Replace values like <%ENVIRONMENT%> with real values before deployment.`
        );
        return;
      }
      (e.environment = t.data.environment ?? e.environment),
        (e.platform = t.data.platform ?? e.platform),
        (e.gameSlug = t.data.gameSlug ?? e.gameSlug),
        (e.gameVersion = t.data.gameVersion ?? e.gameVersion);
      let n = E();
      if (n.retryAttempts > 0) return;
      O(`Loading Phase Started`, {
        "Client Timestamp": n.timestamp,
        "Meta Properties": [],
        "Session Id": n.sessionId,
        "Game Slug": n.gameSlug,
        "Game Version": n.gameVersion,
        "Platform Name": n.platform,
        Environment: n.environment,
      });
    } catch {}
  }
  F();
})();
//# sourceMappingURL=sg-session.js.map
