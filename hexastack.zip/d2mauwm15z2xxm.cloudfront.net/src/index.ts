import type { SessionData, SessionEnvironment } from '@repo/shared/types';
import {
  ensureSession,
  getOrCreateWindowSession,
  isUnresolvedTemplateValue,
} from '@repo/shared/session';
import { sendTrackingEvent } from '@repo/shared/tracking';

type SessionQueryParams = {
  data: Partial<SessionData>;
  hasUnresolvedTemplateParams: boolean;
};

type SessionStartEventPayload = {
  'Client Timestamp': number;
  'Meta Properties': Record<string, unknown>[];
  'Session Id': string;
  'Game Slug': string;
  'Game Version': string;
  'Platform Name': string;
  Environment: SessionEnvironment;
};

function isUnresolvedTemplateParam(value: string | null): boolean {
  return typeof value === 'string' && isUnresolvedTemplateValue(value);
}

function parseQueryParams(): SessionQueryParams {
  const { currentScript } = document;

  if (!isHTMLScriptElement(currentScript)) {
    return {
      data: {},
      hasUnresolvedTemplateParams: false,
    };
  }

  try {
    const scriptUrl = new URL(currentScript.src);
    const params = scriptUrl.searchParams;
    const environment = params.get('environment');
    const platform = params.get('platform');
    const gameSlug = params.get('gameSlug');
    const gameVersion = params.get('gameVersion');

    const hasUnresolvedTemplateParams =
      isUnresolvedTemplateParam(environment) ||
      isUnresolvedTemplateParam(platform) ||
      isUnresolvedTemplateParam(gameSlug) ||
      isUnresolvedTemplateParam(gameVersion);

    return {
      data: {
        environment: environment ?? undefined,
        platform: platform ?? undefined,
        gameSlug: gameSlug ?? undefined,
        gameVersion: gameVersion ?? undefined,
      },
      hasUnresolvedTemplateParams,
    };
  } catch {
    return {
      data: {},
      hasUnresolvedTemplateParams: false,
    };
  }
}

function isHTMLScriptElement(element: unknown): element is HTMLScriptElement {
  return element instanceof HTMLScriptElement;
}

function isFileOrigin(): boolean {
  return globalThis.location.protocol === 'file:' || globalThis.location.origin === 'null';
}

function startSessionTracking(): void {
  try {
    // Local file previews (origin "null") are expected to fail CORS on many APIs.
    if (isFileOrigin()) {
      return;
    }

    const windowData = getOrCreateWindowSession();
    const queryData = parseQueryParams();

    if (queryData.hasUnresolvedTemplateParams) {
      // oxlint-disable-next-line no-console
      console.error(
        'Unresolved template placeholders found in session-start script query params. Replace values like <%ENVIRONMENT%> with real values before deployment.',
      );
      return;
    }

    windowData.environment = queryData.data.environment ?? windowData.environment;
    windowData.platform = queryData.data.platform ?? windowData.platform;
    windowData.gameSlug = queryData.data.gameSlug ?? windowData.gameSlug;
    windowData.gameVersion = queryData.data.gameVersion ?? windowData.gameVersion;

    const session = ensureSession();

    if (session.retryAttempts > 0) {
      return;
    }

    const payload: SessionStartEventPayload = {
      'Client Timestamp': session.timestamp,
      'Meta Properties': [],
      'Session Id': session.sessionId,
      'Game Slug': session.gameSlug,
      'Game Version': session.gameVersion,
      'Platform Name': session.platform,
      Environment: session.environment,
    };

    sendTrackingEvent('Loading Phase Started', payload);
  } catch {
    // Never throw to avoid blocking game startup
  }
}

startSessionTracking();
