import { pageStartTimestamp } from './browser';
import { persistenceChannels } from './channels/index';

// Shape stored in each channel. `ttl` is the epoch-ms timestamp at which the entry expires
// (i.e. the moment it was written plus the requested lifetime).
interface PersistedSession {
  id: string;
  ttl: number;
  retryAttempts: number;
}

// What `consumePersistedSession` hands back: the restored id and the already-incremented
// reload counter.
export interface RestoredSession {
  sessionId: string;
  retryAttempts: number;
}

/**
 * Persist a session id so a page reload can pick it up again. The entry is written to every
 * available channel — `window.name`, `sessionStorage`, `history.state` and `localStorage` —
 * expires `ttl` seconds from now, and is consumed by the next `ensureSessionId` call. Writing
 * all of them costs nothing when one is occupied by the host page or blocked by the browser:
 * the next channel carries the session instead. Never throws.
 */
export function writePersistedSession(sessionId: string, retryAttempts: number, ttl: number): void {
  const entry: PersistedSession = { id: sessionId, retryAttempts, ttl: Date.now() + ttl * 1000 };
  const raw = JSON.stringify(entry);
  for (const channel of persistenceChannels) {
    channel.write(raw);
  }
}

/**
 * Read every channel and then clear every channel, so a persisted entry is used at most once.
 * Clearing all of them up front — before parsing, and regardless of validity — keeps a reload
 * from being counted twice when several channels hold the same entry, and keeps a leftover in
 * one channel from resurfacing on a later load. Returns the first well-formed, non-expired
 * entry; otherwise (missing, malformed, or expired) undefined.
 */
export function consumePersistedSession(): RestoredSession | undefined {
  const raws = persistenceChannels.map((channel) => channel.read());
  for (const channel of persistenceChannels) {
    channel.clear();
  }

  for (const raw of raws) {
    if (raw === null) {
      continue;
    }
    const restored = parsePersistedEntry(raw);
    if (restored) {
      return restored;
    }
  }
  return undefined;
}

// Validate a serialized `PersistedSession`. Returns the restored session with its reload
// counter already incremented, or undefined when the entry is malformed or expired.
function parsePersistedEntry(raw: string): RestoredSession | undefined {
  try {
    // oxlint-disable-next-line typescript/no-unsafe-type-assertion -- validated below
    const entry = JSON.parse(raw) as Partial<PersistedSession>;
    // Validate against the page start, not `Date.now()`: the entry is valid if the reload
    // began before it expired, regardless of how long the page then took to run this code.
    if (
      typeof entry.id === 'string' &&
      typeof entry.ttl === 'number' &&
      entry.ttl >= pageStartTimestamp()
    ) {
      // increase retry attempts for each reload
      const retryAttempts = typeof entry.retryAttempts === 'number' ? entry.retryAttempts + 1 : 1;
      return { sessionId: entry.id, retryAttempts };
    }
  } catch {
    // Malformed JSON — treat as no persisted session.
  }
  return undefined;
}
