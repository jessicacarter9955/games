// Guarded access to the browser globals this module reads. Nothing in here throws: the code
// also runs where a global is missing entirely (SSR, workers) and where merely touching one
// throws (Firefox with site data blocked, sandboxed iframes with an opaque origin).

// Return the window only when one exists (not in SSR / workers / node).
export function safeWindow(): Window | undefined {
  return 'window' in globalThis ? globalThis.window : undefined;
}

// Return a Storage only when it exists and is accessible. Merely touching the `localStorage`
// or `sessionStorage` property (even via `typeof`) throws a SecurityError in Firefox when
// storage is blocked — cookies disabled, or third-party storage in embedded iframes such as
// Facebook Instant Games — so the access itself must be guarded.
export function safeStorage(getStorage: () => Storage): Storage | undefined {
  try {
    return getStorage();
  } catch {
    return undefined;
  }
}

// The part of the History API this module uses. Declaring it narrows the `any`-typed
// `history.state` to `unknown` at the boundary, so the value has to be validated before use.
export interface HistoryLike {
  readonly state: unknown;
  replaceState: (data: unknown, unused: string) => void;
}

// Return the History object only when one exists and is reachable.
export function safeHistory(): HistoryLike | undefined {
  try {
    return safeWindow()?.history;
  } catch {
    return undefined;
  }
}

// The session starts when the page starts loading, not when this code happens to run —
// which may be long after, when called from the session-utils fallback.
export function pageStartTimestamp(): number {
  if (typeof performance !== 'undefined') {
    if (Number.isFinite(performance.timeOrigin)) {
      return Math.round(performance.timeOrigin);
    }
    if (typeof performance.now === 'function') {
      return Math.round(Date.now() - performance.now());
    }
  }
  return Date.now();
}
