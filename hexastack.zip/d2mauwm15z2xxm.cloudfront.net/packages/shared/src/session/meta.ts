// Reading the descriptive session fields the host page declares as `<meta name="sg:...">`.

/**
 * Whether a configuration value still contains an unresolved template placeholder
 * such as `<%ENVIRONMENT%>` — i.e. the host platform's templating did not run.
 */
export function isUnresolvedTemplateValue(value: string): boolean {
  const trimmed = value.trim();
  return trimmed.startsWith('<%') && trimmed.endsWith('%>');
}

// `ensureSession` re-resolves empty fields on every call — warn only once per field.
const warnedMetaFields = new Set<string>();

// Read `<meta name="sg:<field>" content="...">` from the host page. Empty content and
// unresolved template placeholders (e.g. `<%GAME_SLUG%>`) count as absent.
export function readMetaContent(field: string): string | undefined {
  if (typeof document === 'undefined') {
    return undefined;
  }

  const content = document.querySelector(`meta[name="sg:${field}"]`)?.getAttribute('content');
  if (!content) {
    return undefined;
  }

  const trimmed = content.trim();
  if (trimmed.length === 0) {
    return undefined;
  }

  if (isUnresolvedTemplateValue(trimmed)) {
    if (!warnedMetaFields.has(field)) {
      warnedMetaFields.add(field);
      // oxlint-disable-next-line no-console
      console.error(
        `Unresolved template placeholder found in <meta name="sg:${field}"> content. Replace values like <%ENVIRONMENT%> with real values before deployment.`,
      );
    }
    return undefined;
  }

  return trimmed;
}
