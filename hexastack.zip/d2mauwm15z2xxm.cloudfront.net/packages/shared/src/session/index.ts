import type { SessionData } from '../types/index';
import { v7 as uuid7 } from 'uuid';
import { pageStartTimestamp } from './browser';
import { readMetaContent } from './meta';
import { consumePersistedSession } from './persisted-session';

export { isUnresolvedTemplateValue } from './meta';
export { writePersistedSession } from './persisted-session';

/**
 * Get the existing `globalThis.SESSION` object or create (and assign) an empty one.
 * Whoever runs first (`@softgames/session-start` or `@softgames/session-utils`) creates
 * the object; everyone after reuses it.
 */
export function getOrCreateWindowSession(): Partial<SessionData> {
  const existing = globalThis.SESSION;

  if (existing && typeof existing === 'object') {
    return existing;
  }

  // oxlint-disable-next-line typescript/no-unsafe-type-assertion -- fields are filled by the ensure* helpers
  const initial = {
    retryAttempts: 0,
  } as SessionData;
  globalThis.SESSION = initial;
  return initial;
}

/**
 * Ensure the session has a startup timestamp and return it. Prefers an existing value
 * (e.g. from a pre-seeded `window.SESSION`), otherwise uses the page start:
 * `performance.timeOrigin` when available, `Date.now() - performance.now()` as fallback.
 */
export function ensureTimestamp(session: Partial<SessionData>): number {
  if (typeof session.timestamp === 'number' && Number.isFinite(session.timestamp)) {
    return session.timestamp;
  }

  const timestamp = pageStartTimestamp();
  session.timestamp = timestamp;
  return timestamp;
}

/**
 * Ensure the session has a session id and return it. Precedence:
 *
 * 1. An id already on the session object.
 * 2. A non-expired id persisted by `persistSession` before a page reload (see
 *    `libs/session-utils`), taken from the first persistence channel that holds one. The
 *    persisted entry is always consumed — read once and then removed from every channel —
 *    whether or not it was still valid.
 * 3. A freshly generated UUIDv7 seeded with the session's startup timestamp.
 */
export function ensureSessionId(session: Partial<SessionData>): string {
  if (session.sessionId) {
    return session.sessionId;
  }

  const persisted = consumePersistedSession();
  if (persisted) {
    session.sessionId = persisted.sessionId;
    // [FH] This is not really expected here, but the session was already mutated before this change.
    session.retryAttempts = persisted.retryAttempts;
    return persisted.sessionId;
  }

  const sessionId = uuid7({ msecs: ensureTimestamp(session) });
  session.sessionId = sessionId;
  return sessionId;
}

/**
 * Ensure `globalThis.SESSION` exists and every field is populated, then return it:
 *
 * - `timestamp` and `sessionId` are generated if missing.
 * - The descriptive fields are taken from `<meta name="sg:...">` tags of the host page
 *   when missing or empty, and fall back to empty strings.
 *
 * Existing values are never overwritten, so the order of precedence is: values already
 * on `window.SESSION` (script query params written by session-start, or a pre-seeded
 * object) → meta tags → empty string. Empty fields are re-resolved on every call, so a
 * source that runs later (e.g. session-start's query params) still fills them in.
 */
export function ensureSession(): SessionData {
  const session = getOrCreateWindowSession();
  ensureTimestamp(session);
  ensureSessionId(session);

  if (!session.environment) {
    session.environment = readMetaContent('environment') ?? '';
  }
  if (!session.platform) {
    session.platform = readMetaContent('platform') ?? '';
  }
  if (!session.gameSlug) {
    session.gameSlug = readMetaContent('game-slug') ?? '';
  }
  if (!session.gameVersion) {
    session.gameVersion = readMetaContent('game-version') ?? '';
  }

  // oxlint-disable-next-line typescript/no-unsafe-type-assertion -- all fields are ensured above
  return session as SessionData;
}
