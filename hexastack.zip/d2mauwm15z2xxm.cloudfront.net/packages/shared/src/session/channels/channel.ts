// What every persistence channel has to provide, and the key they all store under.

// Key under which a session id is persisted across a page reload: the `localStorage` and
// `sessionStorage` key, the `history.state` property, and — suffixed with `=` — the marker
// that prefixes our value in `window.name`.
export const PERSISTED_SESSION_KEY = 'sg:persisted-session';
export const WINDOW_NAME_PREFIX = `${PERSISTED_SESSION_KEY}=`;

// A place a serialized persisted session can survive a page reload. Every method is
// best-effort and must never throw; `read` returns null when the channel holds nothing.
export interface PersistenceChannel {
  read: () => string | null;
  write: (raw: string) => void;
  clear: () => void;
}
