import { safeHistory } from '../browser';
import { PERSISTED_SESSION_KEY, type PersistenceChannel } from './channel';

// Whether a `history.state` value is an object we can safely merge our key into.
function isMergeableState(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/**
 * `history.state` is restored when the current history entry is reloaded. It is not a Storage
 * API, so site-data blocking and third-party partitioning do not reach it, and it is a keyed
 * object rather than one shared string, so our entry coexists with a host router's state
 * instead of competing for it. Lost when the host replaces the whole state or pushes a new
 * entry before the reload. `replaceState` throws in a sandboxed frame with an opaque origin,
 * hence the guards.
 */
export const historyStateChannel: PersistenceChannel = {
  read: () => {
    try {
      const state = safeHistory()?.state;
      if (!isMergeableState(state)) {
        return null;
      }
      const raw = state[PERSISTED_SESSION_KEY];
      return typeof raw === 'string' ? raw : null;
    } catch {
      return null;
    }
  },
  write: (raw) => {
    const history = safeHistory();
    if (!history) {
      return;
    }
    try {
      const { state } = history;
      // A host keeping a non-object state (a string, an array) is left alone: merging would
      // drop it and replacing it would break the host's own restore.
      if (state !== null && state !== undefined && !isMergeableState(state)) {
        return;
      }
      history.replaceState({ ...state, [PERSISTED_SESSION_KEY]: raw }, '');
    } catch {
      // Best-effort: `replaceState` is unavailable in sandboxed frames and is rate-limited.
    }
  },
  clear: () => {
    const history = safeHistory();
    if (!history) {
      return;
    }
    try {
      const { state } = history;
      if (!isMergeableState(state) || !(PERSISTED_SESSION_KEY in state)) {
        return;
      }
      const rest: Record<string, unknown> = { ...state };
      delete rest[PERSISTED_SESSION_KEY];
      // Hand back a null state when our entry was the only thing in there: host code that
      // treats a non-null state as "this is a history navigation" must not see our leftovers.
      history.replaceState(Object.keys(rest).length === 0 ? null : rest, '');
    } catch {
      // Best-effort.
    }
  },
};
