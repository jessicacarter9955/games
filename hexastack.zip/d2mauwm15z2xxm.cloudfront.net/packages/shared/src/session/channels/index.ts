import type { PersistenceChannel } from './channel';
import { historyStateChannel } from './history-state';
import { localStorageChannel, sessionStorageChannel } from './storage';
import { windowNameChannel } from './window-name';

export type { PersistenceChannel };

/**
 * The channels a persisted session is written to, in read order. Every channel is always
 * written and always cleared; the order decides only which value wins when more than one
 * holds a valid entry. The first three are scoped to the browsing context that reloads, so
 * they come before `localStorage`, which is shared by every tab of the origin and would
 * otherwise be able to hand one tab another tab's id.
 */
export const persistenceChannels: PersistenceChannel[] = [
  windowNameChannel,
  sessionStorageChannel,
  historyStateChannel,
  localStorageChannel,
];
