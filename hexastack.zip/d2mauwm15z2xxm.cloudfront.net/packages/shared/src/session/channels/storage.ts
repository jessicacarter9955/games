import { safeStorage } from '../browser';
import { PERSISTED_SESSION_KEY, type PersistenceChannel } from './channel';

// Build a channel backed by a Storage. The accessor is called on every access rather than
// resolved once, because reaching the global is what throws when storage is blocked.
function createStorageChannel(getStorage: () => Storage): PersistenceChannel {
  return {
    read: () => {
      try {
        return safeStorage(getStorage)?.getItem(PERSISTED_SESSION_KEY) ?? null;
      } catch {
        return null;
      }
    },
    write: (raw) => {
      try {
        safeStorage(getStorage)?.setItem(PERSISTED_SESSION_KEY, raw);
      } catch {
        // Best-effort: swallow storage errors (quota exceeded, access denied in sandboxes).
      }
    },
    clear: () => {
      try {
        safeStorage(getStorage)?.removeItem(PERSISTED_SESSION_KEY);
      } catch {
        // Best-effort.
      }
    },
  };
}

/**
 * Per tab and origin, and restored on a same-entry reload. Unlike `window.name` it is a
 * private namespace no host page can occupy, and unlike `localStorage` it is never shared
 * with another tab. Unavailable whenever the Storage API is blocked.
 */
export const sessionStorageChannel = createStorageChannel(() => sessionStorage);

/**
 * Shared by every tab of the origin, so it also covers a "reload" that lands in a new
 * browsing context: the platform recreating the game iframe, or reopening from a link within
 * the TTL. It is the only channel `@softgames/session-utils` < 3.2.0 wrote, so it is also
 * what restores a session persisted by an older game. Unavailable when storage is blocked.
 */
export const localStorageChannel = createStorageChannel(() => localStorage);
