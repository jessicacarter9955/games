import { safeWindow } from '../browser';
import { WINDOW_NAME_PREFIX, type PersistenceChannel } from './channel';

/**
 * `window.name` is scoped to the browsing context that reloads, so two tabs of the same game
 * each restore their own id. It survives a same-origin reload even when every Storage API is
 * blocked, is never sent to a server, and browsers reset it on cross-origin navigation.
 *
 * The value is shared with the host page, so it is only written when it is empty or already
 * carries our marker, and only ever cleared back to ''. A host page keeping its own value
 * there — a frame name used as a navigation target, a `window.name` transport — blocks this
 * channel, which is why the session is written to the others as well.
 */
export const windowNameChannel: PersistenceChannel = {
  read: () => {
    try {
      const name = safeWindow()?.name ?? '';
      return name.startsWith(WINDOW_NAME_PREFIX) ? name.slice(WINDOW_NAME_PREFIX.length) : null;
    } catch {
      return null;
    }
  },
  write: (raw) => {
    const win = safeWindow();
    if (!win) {
      return;
    }
    try {
      const { name } = win;
      if (name === '' || name.startsWith(WINDOW_NAME_PREFIX)) {
        win.name = `${WINDOW_NAME_PREFIX}${raw}`;
      }
    } catch {
      // Best-effort: `name` may be inaccessible in exotic sandboxes.
    }
  },
  clear: () => {
    const win = safeWindow();
    if (!win) {
      return;
    }
    try {
      if (win.name.startsWith(WINDOW_NAME_PREFIX)) {
        win.name = '';
      }
    } catch {
      // Best-effort.
    }
  },
};
