const TRACKING_ENDPOINT = 'https://d3ok7fu77sdimr.cloudfront.net/g/web-games';
const TRACKING_API_KEY = 'web-games_KTfgCZMzLA6O';
const SCHEMA_VERSION = '171';

export type TrackingEventPayload = Record<string, unknown>;

/**
 * Send a tracking event to the Softgames ingestion endpoint. The Avo schema version is
 * appended to the payload automatically.
 * Prefers `navigator.sendBeacon()` (POST, api key in the query string) and falls back to
 * `fetch()` (PUT, api key header). Never throws — tracking must not break game startup.
 */
export function sendTrackingEvent(eventName: string, payload: TrackingEventPayload): void {
  const body = JSON.stringify({
    eventName,
    payload: {
      ...payload,
      'Schema Version': SCHEMA_VERSION,
    },
  });

  if (postWithBeacon(body)) {
    return;
  }
  postWithFetch(body);
}

function postWithBeacon(body: string): boolean {
  if (typeof navigator === 'undefined' || typeof navigator.sendBeacon !== 'function') {
    return false;
  }

  try {
    const beaconUrl = `${TRACKING_ENDPOINT}?x-api-key=${encodeURIComponent(TRACKING_API_KEY)}`;
    return navigator.sendBeacon(beaconUrl, body);
  } catch {
    return false;
  }
}

function postWithFetch(body: string): void {
  if (typeof fetch !== 'function') {
    return;
  }

  try {
    void fetch(TRACKING_ENDPOINT, {
      method: 'PUT',
      headers: {
        'x-api-key': TRACKING_API_KEY,
        'Content-Type': 'application/json',
      },
      body,
      keepalive: true,
      credentials: 'omit',
    });
  } catch {
    // Swallow errors to avoid blocking game startup
  }
}
