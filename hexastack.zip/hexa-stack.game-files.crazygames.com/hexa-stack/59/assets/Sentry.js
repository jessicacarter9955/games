import { g as vn } from "./getGameLogger.js";
import "./index-BUwntghg.js";
import "./pixi.js";
const m = typeof __SENTRY_DEBUG__ > "u" || __SENTRY_DEBUG__,
  M = "8.55.2",
  g = globalThis;
function yt(t, e, n) {
  const r = n || g,
    s = (r.__SENTRY__ = r.__SENTRY__ || {}),
    o = (s[M] = s[M] || {});
  return o[t] || (o[t] = e());
}
const H = typeof __SENTRY_DEBUG__ > "u" || __SENTRY_DEBUG__,
  wn = "Sentry Logger ",
  Dt = ["debug", "info", "warn", "error", "log", "assert", "trace"],
  gt = {};
function G(t) {
  if (!("console" in g)) return t();
  const e = g.console,
    n = {},
    r = Object.keys(gt);
  r.forEach((s) => {
    const o = gt[s];
    (n[s] = e[s]), (e[s] = o);
  });
  try {
    return t();
  } finally {
    r.forEach((s) => {
      e[s] = n[s];
    });
  }
}
function kn() {
  let t = !1;
  const e = {
    enable: () => {
      t = !0;
    },
    disable: () => {
      t = !1;
    },
    isEnabled: () => t,
  };
  return (
    H
      ? Dt.forEach((n) => {
          e[n] = (...r) => {
            t &&
              G(() => {
                g.console[n](`${wn}[${n}]:`, ...r);
              });
          };
        })
      : Dt.forEach((n) => {
          e[n] = () => {};
        }),
    e
  );
}
const d = yt("logger", kn),
  ze = 50,
  $ = "?",
  ce = /\(error: (.*)\)/,
  ue = /captureMessage|captureException/;
function Ke(...t) {
  const e = t.sort((n, r) => n[0] - r[0]).map((n) => n[1]);
  return (n, r = 0, s = 0) => {
    const o = [],
      i = n.split(`
`);
    for (let a = r; a < i.length; a++) {
      const c = i[a];
      if (c.length > 1024) continue;
      const u = ce.test(c) ? c.replace(ce, "$1") : c;
      if (!u.match(/\S*Error: /)) {
        for (const l of e) {
          const f = l(u);
          if (f) {
            o.push(f);
            break;
          }
        }
        if (o.length >= ze + s) break;
      }
    }
    return xn(o.slice(s));
  };
}
function Nn(t) {
  return Array.isArray(t) ? Ke(...t) : t;
}
function xn(t) {
  if (!t.length) return [];
  const e = Array.from(t);
  return (
    /sentryWrapped/.test(it(e).function || "") && e.pop(),
    e.reverse(),
    ue.test(it(e).function || "") &&
      (e.pop(), ue.test(it(e).function || "") && e.pop()),
    e
      .slice(0, ze)
      .map((n) => ({
        ...n,
        filename: n.filename || it(e).filename,
        function: n.function || $,
      }))
  );
}
function it(t) {
  return t[t.length - 1] || {};
}
const kt = "<anonymous>";
function A(t) {
  try {
    return !t || typeof t != "function" ? kt : t.name || kt;
  } catch {
    return kt;
  }
}
function fe(t) {
  const e = t.exception;
  if (e) {
    const n = [];
    try {
      return (
        e.values.forEach((r) => {
          r.stacktrace.frames && n.push(...r.stacktrace.frames);
        }),
        n
      );
    } catch {
      return;
    }
  }
}
const pt = {},
  le = {};
function W(t, e) {
  (pt[t] = pt[t] || []), pt[t].push(e);
}
function q(t, e) {
  if (!le[t]) {
    le[t] = !0;
    try {
      e();
    } catch (n) {
      H && d.error(`Error while instrumenting ${t}`, n);
    }
  }
}
function N(t, e) {
  const n = t && pt[t];
  if (n)
    for (const r of n)
      try {
        r(e);
      } catch (s) {
        H &&
          d.error(
            `Error while triggering instrumentation handler.
Type: ${t}
Name: ${A(r)}
Error:`,
            s
          );
      }
}
let Nt = null;
function On(t) {
  const e = "error";
  W(e, t), q(e, Rn);
}
function Rn() {
  (Nt = g.onerror),
    (g.onerror = function (t, e, n, r, s) {
      return (
        N("error", { column: r, error: s, line: n, msg: t, url: e }),
        Nt ? Nt.apply(this, arguments) : !1
      );
    }),
    (g.onerror.__SENTRY_INSTRUMENTED__ = !0);
}
let xt = null;
function Dn(t) {
  const e = "unhandledrejection";
  W(e, t), q(e, Cn);
}
function Cn() {
  (xt = g.onunhandledrejection),
    (g.onunhandledrejection = function (t) {
      return N("unhandledrejection", t), xt ? xt.apply(this, arguments) : !0;
    }),
    (g.onunhandledrejection.__SENTRY_INSTRUMENTED__ = !0);
}
function Et() {
  return Kt(g), g;
}
function Kt(t) {
  const e = (t.__SENTRY__ = t.__SENTRY__ || {});
  return (e.version = e.version || M), (e[M] = e[M] || {});
}
const Xe = Object.prototype.toString;
function Xt(t) {
  switch (Xe.call(t)) {
    case "[object Error]":
    case "[object Exception]":
    case "[object DOMException]":
    case "[object WebAssembly.Exception]":
      return !0;
    default:
      return F(t, Error);
  }
}
function Z(t, e) {
  return Xe.call(t) === `[object ${e}]`;
}
function Ve(t) {
  return Z(t, "ErrorEvent");
}
function de(t) {
  return Z(t, "DOMError");
}
function Pn(t) {
  return Z(t, "DOMException");
}
function R(t) {
  return Z(t, "String");
}
function Vt(t) {
  return (
    typeof t == "object" &&
    t !== null &&
    "__sentry_template_string__" in t &&
    "__sentry_template_values__" in t
  );
}
function Jt(t) {
  return (
    t === null || Vt(t) || (typeof t != "object" && typeof t != "function")
  );
}
function z(t) {
  return Z(t, "Object");
}
function St(t) {
  return typeof Event < "u" && F(t, Event);
}
function An(t) {
  return typeof Element < "u" && F(t, Element);
}
function Mn(t) {
  return Z(t, "RegExp");
}
function bt(t) {
  return !!(t && t.then && typeof t.then == "function");
}
function $n(t) {
  return (
    z(t) &&
    "nativeEvent" in t &&
    "preventDefault" in t &&
    "stopPropagation" in t
  );
}
function F(t, e) {
  try {
    return t instanceof e;
  } catch {
    return !1;
  }
}
function Je(t) {
  return !!(typeof t == "object" && t !== null && (t.__isVue || t._isVue));
}
const Zt = g,
  Fn = 80;
function Ze(t, e = {}) {
  if (!t) return "<unknown>";
  try {
    let n = t;
    const r = 5,
      s = [];
    let o = 0,
      i = 0;
    const a = " > ",
      c = a.length;
    let u;
    const l = Array.isArray(e) ? e : e.keyAttrs,
      f = (!Array.isArray(e) && e.maxStringLength) || Fn;
    for (
      ;
      n &&
      o++ < r &&
      ((u = Ln(n, l)),
      !(u === "html" || (o > 1 && i + s.length * c + u.length >= f)));

    )
      s.push(u), (i += u.length), (n = n.parentNode);
    return s.reverse().join(a);
  } catch {
    return "<unknown>";
  }
}
function Ln(t, e) {
  const n = t,
    r = [];
  if (!n || !n.tagName) return "";
  if (Zt.HTMLElement && n instanceof HTMLElement && n.dataset) {
    if (n.dataset.sentryComponent) return n.dataset.sentryComponent;
    if (n.dataset.sentryElement) return n.dataset.sentryElement;
  }
  r.push(n.tagName.toLowerCase());
  const s =
    e && e.length
      ? e.filter((i) => n.getAttribute(i)).map((i) => [i, n.getAttribute(i)])
      : null;
  if (s && s.length)
    s.forEach((i) => {
      r.push(`[${i[0]}="${i[1]}"]`);
    });
  else {
    n.id && r.push(`#${n.id}`);
    const i = n.className;
    if (i && R(i)) {
      const a = i.split(/\s+/);
      for (const c of a) r.push(`.${c}`);
    }
  }
  const o = ["aria-label", "type", "name", "title", "alt"];
  for (const i of o) {
    const a = n.getAttribute(i);
    a && r.push(`[${i}="${a}"]`);
  }
  return r.join("");
}
function Un() {
  try {
    return Zt.document.location.href;
  } catch {
    return "";
  }
}
function jn(t) {
  if (!Zt.HTMLElement) return null;
  let e = t;
  const n = 5;
  for (let r = 0; r < n; r++) {
    if (!e) return null;
    if (e instanceof HTMLElement) {
      if (e.dataset.sentryComponent) return e.dataset.sentryComponent;
      if (e.dataset.sentryElement) return e.dataset.sentryElement;
    }
    e = e.parentNode;
  }
  return null;
}
function Y(t, e = 0) {
  return typeof t != "string" || e === 0 || t.length <= e
    ? t
    : `${t.slice(0, e)}...`;
}
function pe(t, e) {
  if (!Array.isArray(t)) return "";
  const n = [];
  for (let r = 0; r < t.length; r++) {
    const s = t[r];
    try {
      Je(s) ? n.push("[VueViewModel]") : n.push(String(s));
    } catch {
      n.push("[value cannot be serialized]");
    }
  }
  return n.join(e);
}
function Bn(t, e, n = !1) {
  return R(t)
    ? Mn(e)
      ? e.test(t)
      : R(e)
      ? n
        ? t === e
        : t.includes(e)
      : !1
    : !1;
}
function It(t, e = [], n = !1) {
  return e.some((r) => Bn(t, r, n));
}
function I(t, e, n) {
  if (!(e in t)) return;
  const r = t[e],
    s = n(r);
  typeof s == "function" && Qe(s, r);
  try {
    t[e] = s;
  } catch {
    H && d.log(`Failed to replace method "${e}" in object`, t);
  }
}
function L(t, e, n) {
  try {
    Object.defineProperty(t, e, { value: n, writable: !0, configurable: !0 });
  } catch {
    H && d.log(`Failed to add non-enumerable property "${e}" to object`, t);
  }
}
function Qe(t, e) {
  try {
    const n = e.prototype || {};
    (t.prototype = e.prototype = n), L(t, "__sentry_original__", e);
  } catch {}
}
function Qt(t) {
  return t.__sentry_original__;
}
function tn(t) {
  if (Xt(t))
    return { message: t.message, name: t.name, stack: t.stack, ...ge(t) };
  if (St(t)) {
    const e = {
      type: t.type,
      target: he(t.target),
      currentTarget: he(t.currentTarget),
      ...ge(t),
    };
    return (
      typeof CustomEvent < "u" && F(t, CustomEvent) && (e.detail = t.detail), e
    );
  } else return t;
}
function he(t) {
  try {
    return An(t) ? Ze(t) : Object.prototype.toString.call(t);
  } catch {
    return "<unknown>";
  }
}
function ge(t) {
  if (typeof t == "object" && t !== null) {
    const e = {};
    for (const n in t)
      Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
    return e;
  } else return {};
}
function Hn(t, e = 40) {
  const n = Object.keys(tn(t));
  n.sort();
  const r = n[0];
  if (!r) return "[object has no keys]";
  if (r.length >= e) return Y(r, e);
  for (let s = n.length; s > 0; s--) {
    const o = n.slice(0, s).join(", ");
    if (!(o.length > e)) return s === n.length ? o : Y(o, e);
  }
  return "";
}
function v(t) {
  return Ct(t, new Map());
}
function Ct(t, e) {
  if (Gn(t)) {
    const n = e.get(t);
    if (n !== void 0) return n;
    const r = {};
    e.set(t, r);
    for (const s of Object.getOwnPropertyNames(t))
      typeof t[s] < "u" && (r[s] = Ct(t[s], e));
    return r;
  }
  if (Array.isArray(t)) {
    const n = e.get(t);
    if (n !== void 0) return n;
    const r = [];
    return (
      e.set(t, r),
      t.forEach((s) => {
        r.push(Ct(s, e));
      }),
      r
    );
  }
  return t;
}
function Gn(t) {
  if (!z(t)) return !1;
  try {
    const e = Object.getPrototypeOf(t).constructor.name;
    return !e || e === "Object";
  } catch {
    return !0;
  }
}
const en = 1e3;
function tt() {
  return Date.now() / en;
}
function Wn() {
  const { performance: t } = g;
  if (!t || !t.now) return tt;
  const e = Date.now() - t.now(),
    n = t.timeOrigin == null ? e : t.timeOrigin;
  return () => (n + t.now()) / en;
}
const D = Wn();
(() => {
  const { performance: t } = g;
  if (!t || !t.now) return;
  const e = 3600 * 1e3,
    n = t.now(),
    r = Date.now(),
    s = t.timeOrigin ? Math.abs(t.timeOrigin + n - r) : e,
    o = s < e,
    i = t.timing && t.timing.navigationStart,
    c = typeof i == "number" ? Math.abs(i + n - r) : e,
    u = c < e;
  return o || u ? (s <= c ? t.timeOrigin : i) : r;
})();
function w() {
  const t = g,
    e = t.crypto || t.msCrypto;
  let n = () => Math.random() * 16;
  try {
    if (e && e.randomUUID) return e.randomUUID().replace(/-/g, "");
    e &&
      e.getRandomValues &&
      (n = () => {
        const r = new Uint8Array(1);
        return e.getRandomValues(r), r[0];
      });
  } catch {}
  return ("10000000100040008000" + 1e11).replace(/[018]/g, (r) =>
    (r ^ ((n() & 15) >> (r / 4))).toString(16)
  );
}
function nn(t) {
  return t.exception && t.exception.values ? t.exception.values[0] : void 0;
}
function P(t) {
  const { message: e, event_id: n } = t;
  if (e) return e;
  const r = nn(t);
  return r
    ? r.type && r.value
      ? `${r.type}: ${r.value}`
      : r.type || r.value || n || "<unknown>"
    : n || "<unknown>";
}
function Pt(t, e, n) {
  const r = (t.exception = t.exception || {}),
    s = (r.values = r.values || []),
    o = (s[0] = s[0] || {});
  o.value || (o.value = e || ""), o.type || (o.type = "Error");
}
function K(t, e) {
  const n = nn(t);
  if (!n) return;
  const r = { type: "generic", handled: !0 },
    s = n.mechanism;
  if (((n.mechanism = { ...r, ...s, ...e }), e && "data" in e)) {
    const o = { ...(s && s.data), ...e.data };
    n.mechanism.data = o;
  }
}
function _e(t) {
  if (qn(t)) return !0;
  try {
    L(t, "__sentry_captured__", !0);
  } catch {}
  return !1;
}
function qn(t) {
  try {
    return t.__sentry_captured__;
  } catch {}
}
var x;
(function (t) {
  t[(t.PENDING = 0)] = "PENDING";
  const n = 1;
  t[(t.RESOLVED = n)] = "RESOLVED";
  const r = 2;
  t[(t.REJECTED = r)] = "REJECTED";
})(x || (x = {}));
function U(t) {
  return new T((e) => {
    e(t);
  });
}
function _t(t) {
  return new T((e, n) => {
    n(t);
  });
}
class T {
  constructor(e) {
    T.prototype.__init.call(this),
      T.prototype.__init2.call(this),
      T.prototype.__init3.call(this),
      T.prototype.__init4.call(this),
      (this._state = x.PENDING),
      (this._handlers = []);
    try {
      e(this._resolve, this._reject);
    } catch (n) {
      this._reject(n);
    }
  }
  then(e, n) {
    return new T((r, s) => {
      this._handlers.push([
        !1,
        (o) => {
          if (!e) r(o);
          else
            try {
              r(e(o));
            } catch (i) {
              s(i);
            }
        },
        (o) => {
          if (!n) s(o);
          else
            try {
              r(n(o));
            } catch (i) {
              s(i);
            }
        },
      ]),
        this._executeHandlers();
    });
  }
  catch(e) {
    return this.then((n) => n, e);
  }
  finally(e) {
    return new T((n, r) => {
      let s, o;
      return this.then(
        (i) => {
          (o = !1), (s = i), e && e();
        },
        (i) => {
          (o = !0), (s = i), e && e();
        }
      ).then(() => {
        if (o) {
          r(s);
          return;
        }
        n(s);
      });
    });
  }
  __init() {
    this._resolve = (e) => {
      this._setResult(x.RESOLVED, e);
    };
  }
  __init2() {
    this._reject = (e) => {
      this._setResult(x.REJECTED, e);
    };
  }
  __init3() {
    this._setResult = (e, n) => {
      if (this._state === x.PENDING) {
        if (bt(n)) {
          n.then(this._resolve, this._reject);
          return;
        }
        (this._state = e), (this._value = n), this._executeHandlers();
      }
    };
  }
  __init4() {
    this._executeHandlers = () => {
      if (this._state === x.PENDING) return;
      const e = this._handlers.slice();
      (this._handlers = []),
        e.forEach((n) => {
          n[0] ||
            (this._state === x.RESOLVED && n[1](this._value),
            this._state === x.REJECTED && n[2](this._value),
            (n[0] = !0));
        });
    };
  }
}
function Yn(t) {
  const e = D(),
    n = {
      sid: w(),
      init: !0,
      timestamp: e,
      started: e,
      duration: 0,
      status: "ok",
      errors: 0,
      ignoreDuration: !1,
      toJSON: () => Kn(n),
    };
  return t && X(n, t), n;
}
function X(t, e = {}) {
  if (
    (e.user &&
      (!t.ipAddress && e.user.ip_address && (t.ipAddress = e.user.ip_address),
      !t.did &&
        !e.did &&
        (t.did = e.user.id || e.user.email || e.user.username)),
    (t.timestamp = e.timestamp || D()),
    e.abnormal_mechanism && (t.abnormal_mechanism = e.abnormal_mechanism),
    e.ignoreDuration && (t.ignoreDuration = e.ignoreDuration),
    e.sid && (t.sid = e.sid.length === 32 ? e.sid : w()),
    e.init !== void 0 && (t.init = e.init),
    !t.did && e.did && (t.did = `${e.did}`),
    typeof e.started == "number" && (t.started = e.started),
    t.ignoreDuration)
  )
    t.duration = void 0;
  else if (typeof e.duration == "number") t.duration = e.duration;
  else {
    const n = t.timestamp - t.started;
    t.duration = n >= 0 ? n : 0;
  }
  e.release && (t.release = e.release),
    e.environment && (t.environment = e.environment),
    !t.ipAddress && e.ipAddress && (t.ipAddress = e.ipAddress),
    !t.userAgent && e.userAgent && (t.userAgent = e.userAgent),
    typeof e.errors == "number" && (t.errors = e.errors),
    e.status && (t.status = e.status);
}
function zn(t, e) {
  let n = {};
  t.status === "ok" && (n = { status: "exited" }), X(t, n);
}
function Kn(t) {
  return v({
    sid: `${t.sid}`,
    init: t.init,
    started: new Date(t.started * 1e3).toISOString(),
    timestamp: new Date(t.timestamp * 1e3).toISOString(),
    status: t.status,
    errors: t.errors,
    did:
      typeof t.did == "number" || typeof t.did == "string"
        ? `${t.did}`
        : void 0,
    duration: t.duration,
    abnormal_mechanism: t.abnormal_mechanism,
    attrs: {
      release: t.release,
      environment: t.environment,
      ip_address: t.ipAddress,
      user_agent: t.userAgent,
    },
  });
}
function me() {
  return w();
}
function At() {
  return w().substring(16);
}
function Tt(t, e, n = 2) {
  if (!e || typeof e != "object" || n <= 0) return e;
  if (t && e && Object.keys(e).length === 0) return t;
  const r = { ...t };
  for (const s in e)
    Object.prototype.hasOwnProperty.call(e, s) &&
      (r[s] = Tt(r[s], e[s], n - 1));
  return r;
}
const Mt = "_sentrySpan";
function ye(t, e) {
  e ? L(t, Mt, e) : delete t[Mt];
}
function Ee(t) {
  return t[Mt];
}
const Xn = 100;
class te {
  constructor() {
    (this._notifyingListeners = !1),
      (this._scopeListeners = []),
      (this._eventProcessors = []),
      (this._breadcrumbs = []),
      (this._attachments = []),
      (this._user = {}),
      (this._tags = {}),
      (this._extra = {}),
      (this._contexts = {}),
      (this._sdkProcessingMetadata = {}),
      (this._propagationContext = { traceId: me(), spanId: At() });
  }
  clone() {
    const e = new te();
    return (
      (e._breadcrumbs = [...this._breadcrumbs]),
      (e._tags = { ...this._tags }),
      (e._extra = { ...this._extra }),
      (e._contexts = { ...this._contexts }),
      this._contexts.flags &&
        (e._contexts.flags = { values: [...this._contexts.flags.values] }),
      (e._user = this._user),
      (e._level = this._level),
      (e._session = this._session),
      (e._transactionName = this._transactionName),
      (e._fingerprint = this._fingerprint),
      (e._eventProcessors = [...this._eventProcessors]),
      (e._requestSession = this._requestSession),
      (e._attachments = [...this._attachments]),
      (e._sdkProcessingMetadata = { ...this._sdkProcessingMetadata }),
      (e._propagationContext = { ...this._propagationContext }),
      (e._client = this._client),
      (e._lastEventId = this._lastEventId),
      ye(e, Ee(this)),
      e
    );
  }
  setClient(e) {
    this._client = e;
  }
  setLastEventId(e) {
    this._lastEventId = e;
  }
  getClient() {
    return this._client;
  }
  lastEventId() {
    return this._lastEventId;
  }
  addScopeListener(e) {
    this._scopeListeners.push(e);
  }
  addEventProcessor(e) {
    return this._eventProcessors.push(e), this;
  }
  setUser(e) {
    return (
      (this._user = e || {
        email: void 0,
        id: void 0,
        ip_address: void 0,
        username: void 0,
      }),
      this._session && X(this._session, { user: e }),
      this._notifyScopeListeners(),
      this
    );
  }
  getUser() {
    return this._user;
  }
  getRequestSession() {
    return this._requestSession;
  }
  setRequestSession(e) {
    return (this._requestSession = e), this;
  }
  setTags(e) {
    return (
      (this._tags = { ...this._tags, ...e }), this._notifyScopeListeners(), this
    );
  }
  setTag(e, n) {
    return (
      (this._tags = { ...this._tags, [e]: n }),
      this._notifyScopeListeners(),
      this
    );
  }
  setExtras(e) {
    return (
      (this._extra = { ...this._extra, ...e }),
      this._notifyScopeListeners(),
      this
    );
  }
  setExtra(e, n) {
    return (
      (this._extra = { ...this._extra, [e]: n }),
      this._notifyScopeListeners(),
      this
    );
  }
  setFingerprint(e) {
    return (this._fingerprint = e), this._notifyScopeListeners(), this;
  }
  setLevel(e) {
    return (this._level = e), this._notifyScopeListeners(), this;
  }
  setTransactionName(e) {
    return (this._transactionName = e), this._notifyScopeListeners(), this;
  }
  setContext(e, n) {
    return (
      n === null ? delete this._contexts[e] : (this._contexts[e] = n),
      this._notifyScopeListeners(),
      this
    );
  }
  setSession(e) {
    return (
      e ? (this._session = e) : delete this._session,
      this._notifyScopeListeners(),
      this
    );
  }
  getSession() {
    return this._session;
  }
  update(e) {
    if (!e) return this;
    const n = typeof e == "function" ? e(this) : e,
      [r, s] =
        n instanceof j
          ? [n.getScopeData(), n.getRequestSession()]
          : z(n)
          ? [e, e.requestSession]
          : [],
      {
        tags: o,
        extra: i,
        user: a,
        contexts: c,
        level: u,
        fingerprint: l = [],
        propagationContext: f,
      } = r || {};
    return (
      (this._tags = { ...this._tags, ...o }),
      (this._extra = { ...this._extra, ...i }),
      (this._contexts = { ...this._contexts, ...c }),
      a && Object.keys(a).length && (this._user = a),
      u && (this._level = u),
      l.length && (this._fingerprint = l),
      f && (this._propagationContext = f),
      s && (this._requestSession = s),
      this
    );
  }
  clear() {
    return (
      (this._breadcrumbs = []),
      (this._tags = {}),
      (this._extra = {}),
      (this._user = {}),
      (this._contexts = {}),
      (this._level = void 0),
      (this._transactionName = void 0),
      (this._fingerprint = void 0),
      (this._requestSession = void 0),
      (this._session = void 0),
      ye(this, void 0),
      (this._attachments = []),
      this.setPropagationContext({ traceId: me() }),
      this._notifyScopeListeners(),
      this
    );
  }
  addBreadcrumb(e, n) {
    const r = typeof n == "number" ? n : Xn;
    if (r <= 0) return this;
    const s = { timestamp: tt(), ...e };
    return (
      this._breadcrumbs.push(s),
      this._breadcrumbs.length > r &&
        ((this._breadcrumbs = this._breadcrumbs.slice(-r)),
        this._client &&
          this._client.recordDroppedEvent("buffer_overflow", "log_item")),
      this._notifyScopeListeners(),
      this
    );
  }
  getLastBreadcrumb() {
    return this._breadcrumbs[this._breadcrumbs.length - 1];
  }
  clearBreadcrumbs() {
    return (this._breadcrumbs = []), this._notifyScopeListeners(), this;
  }
  addAttachment(e) {
    return this._attachments.push(e), this;
  }
  clearAttachments() {
    return (this._attachments = []), this;
  }
  getScopeData() {
    return {
      breadcrumbs: this._breadcrumbs,
      attachments: this._attachments,
      contexts: this._contexts,
      tags: this._tags,
      extra: this._extra,
      user: this._user,
      level: this._level,
      fingerprint: this._fingerprint || [],
      eventProcessors: this._eventProcessors,
      propagationContext: this._propagationContext,
      sdkProcessingMetadata: this._sdkProcessingMetadata,
      transactionName: this._transactionName,
      span: Ee(this),
    };
  }
  setSDKProcessingMetadata(e) {
    return (
      (this._sdkProcessingMetadata = Tt(this._sdkProcessingMetadata, e, 2)),
      this
    );
  }
  setPropagationContext(e) {
    return (this._propagationContext = { spanId: At(), ...e }), this;
  }
  getPropagationContext() {
    return this._propagationContext;
  }
  captureException(e, n) {
    const r = n && n.event_id ? n.event_id : w();
    if (!this._client)
      return (
        d.warn("No client configured on scope - will not capture exception!"), r
      );
    const s = new Error("Sentry syntheticException");
    return (
      this._client.captureException(
        e,
        { originalException: e, syntheticException: s, ...n, event_id: r },
        this
      ),
      r
    );
  }
  captureMessage(e, n, r) {
    const s = r && r.event_id ? r.event_id : w();
    if (!this._client)
      return (
        d.warn("No client configured on scope - will not capture message!"), s
      );
    const o = new Error(e);
    return (
      this._client.captureMessage(
        e,
        n,
        { originalException: e, syntheticException: o, ...r, event_id: s },
        this
      ),
      s
    );
  }
  captureEvent(e, n) {
    const r = n && n.event_id ? n.event_id : w();
    return this._client
      ? (this._client.captureEvent(e, { ...n, event_id: r }, this), r)
      : (d.warn("No client configured on scope - will not capture event!"), r);
  }
  _notifyScopeListeners() {
    this._notifyingListeners ||
      ((this._notifyingListeners = !0),
      this._scopeListeners.forEach((e) => {
        e(this);
      }),
      (this._notifyingListeners = !1));
  }
}
const j = te;
function Vn() {
  return yt("defaultCurrentScope", () => new j());
}
function Jn() {
  return yt("defaultIsolationScope", () => new j());
}
class Zn {
  constructor(e, n) {
    let r;
    e ? (r = e) : (r = new j());
    let s;
    n ? (s = n) : (s = new j()),
      (this._stack = [{ scope: r }]),
      (this._isolationScope = s);
  }
  withScope(e) {
    const n = this._pushScope();
    let r;
    try {
      r = e(n);
    } catch (s) {
      throw (this._popScope(), s);
    }
    return bt(r)
      ? r.then(
          (s) => (this._popScope(), s),
          (s) => {
            throw (this._popScope(), s);
          }
        )
      : (this._popScope(), r);
  }
  getClient() {
    return this.getStackTop().client;
  }
  getScope() {
    return this.getStackTop().scope;
  }
  getIsolationScope() {
    return this._isolationScope;
  }
  getStackTop() {
    return this._stack[this._stack.length - 1];
  }
  _pushScope() {
    const e = this.getScope().clone();
    return this._stack.push({ client: this.getClient(), scope: e }), e;
  }
  _popScope() {
    return this._stack.length <= 1 ? !1 : !!this._stack.pop();
  }
}
function V() {
  const t = Et(),
    e = Kt(t);
  return (e.stack = e.stack || new Zn(Vn(), Jn()));
}
function Qn(t) {
  return V().withScope(t);
}
function tr(t, e) {
  const n = V();
  return n.withScope(() => ((n.getStackTop().scope = t), e(t)));
}
function Se(t) {
  return V().withScope(() => t(V().getIsolationScope()));
}
function er() {
  return {
    withIsolationScope: Se,
    withScope: Qn,
    withSetScope: tr,
    withSetIsolationScope: (t, e) => Se(e),
    getCurrentScope: () => V().getScope(),
    getIsolationScope: () => V().getIsolationScope(),
  };
}
function ee(t) {
  const e = Kt(t);
  return e.acs ? e.acs : er();
}
function C() {
  const t = Et();
  return ee(t).getCurrentScope();
}
function et() {
  const t = Et();
  return ee(t).getIsolationScope();
}
function nr() {
  return yt("globalScope", () => new j());
}
function rr(...t) {
  const e = Et(),
    n = ee(e);
  if (t.length === 2) {
    const [r, s] = t;
    return r ? n.withSetScope(r, s) : n.withScope(s);
  }
  return n.withScope(t[0]);
}
function E() {
  return C().getClient();
}
function sr(t) {
  const e = t.getPropagationContext(),
    { traceId: n, spanId: r, parentSpanId: s } = e;
  return v({ trace_id: n, span_id: r, parent_span_id: s });
}
const or = "_sentryMetrics";
function ir(t) {
  const e = t[or];
  if (!e) return;
  const n = {};
  for (const [, [r, s]] of e) (n[r] || (n[r] = [])).push(v(s));
  return n;
}
const ar = "sentry.source",
  cr = "sentry.sample_rate",
  ur = "sentry.op",
  fr = "sentry.origin",
  lr = 0,
  dr = 1,
  pr = "sentry-",
  hr = /^sentry-/;
function gr(t) {
  const e = _r(t);
  if (!e) return;
  const n = Object.entries(e).reduce((r, [s, o]) => {
    if (s.match(hr)) {
      const i = s.slice(pr.length);
      r[i] = o;
    }
    return r;
  }, {});
  if (Object.keys(n).length > 0) return n;
}
function _r(t) {
  if (!(!t || (!R(t) && !Array.isArray(t))))
    return Array.isArray(t)
      ? t.reduce((e, n) => {
          const r = be(n);
          return (
            Object.entries(r).forEach(([s, o]) => {
              e[s] = o;
            }),
            e
          );
        }, {})
      : be(t);
}
function be(t) {
  return t
    .split(",")
    .map((e) => e.split("=").map((n) => decodeURIComponent(n.trim())))
    .reduce((e, [n, r]) => (n && r && (e[n] = r), e), {});
}
const mr = 1;
let Ie = !1;
function yr(t) {
  const { spanId: e, traceId: n, isRemote: r } = t.spanContext(),
    s = r ? e : ne(t).parent_span_id,
    o = r ? At() : e;
  return v({ parent_span_id: s, span_id: o, trace_id: n });
}
function Te(t) {
  return typeof t == "number"
    ? ve(t)
    : Array.isArray(t)
    ? t[0] + t[1] / 1e9
    : t instanceof Date
    ? ve(t.getTime())
    : D();
}
function ve(t) {
  return t > 9999999999 ? t / 1e3 : t;
}
function ne(t) {
  if (Sr(t)) return t.getSpanJSON();
  try {
    const { spanId: e, traceId: n } = t.spanContext();
    if (Er(t)) {
      const {
        attributes: r,
        startTime: s,
        name: o,
        endTime: i,
        parentSpanId: a,
        status: c,
      } = t;
      return v({
        span_id: e,
        trace_id: n,
        data: r,
        description: o,
        parent_span_id: a,
        start_timestamp: Te(s),
        timestamp: Te(i) || void 0,
        status: Ir(c),
        op: r[ur],
        origin: r[fr],
        _metrics_summary: ir(t),
      });
    }
    return { span_id: e, trace_id: n };
  } catch {
    return {};
  }
}
function Er(t) {
  const e = t;
  return (
    !!e.attributes && !!e.startTime && !!e.name && !!e.endTime && !!e.status
  );
}
function Sr(t) {
  return typeof t.getSpanJSON == "function";
}
function br(t) {
  const { traceFlags: e } = t.spanContext();
  return e === mr;
}
function Ir(t) {
  if (!(!t || t.code === lr))
    return t.code === dr ? "ok" : t.message || "unknown_error";
}
const Tr = "_sentryRootSpan";
function rn(t) {
  return t[Tr] || t;
}
function vr() {
  Ie ||
    (G(() => {
      console.warn(
        "[Sentry] Deprecation warning: Returning null from `beforeSendSpan` will be disallowed from SDK version 9.0.0 onwards. The callback will only support mutating spans. To drop certain spans, configure the respective integrations directly."
      );
    }),
    (Ie = !0));
}
function wr(t) {
  if (typeof __SENTRY_TRACING__ == "boolean" && !__SENTRY_TRACING__) return !1;
  const e = E(),
    n = e && e.getOptions();
  return (
    !!n && (n.enableTracing || "tracesSampleRate" in n || "tracesSampler" in n)
  );
}
const re = "production",
  kr = "_frozenDsc";
function sn(t, e) {
  const n = e.getOptions(),
    { publicKey: r } = e.getDsn() || {},
    s = v({
      environment: n.environment || re,
      release: n.release,
      public_key: r,
      trace_id: t,
    });
  return e.emit("createDsc", s), s;
}
function Nr(t, e) {
  const n = e.getPropagationContext();
  return n.dsc || sn(n.traceId, t);
}
function xr(t) {
  const e = E();
  if (!e) return {};
  const n = rn(t),
    r = n[kr];
  if (r) return r;
  const s = n.spanContext().traceState,
    o = s && s.get("sentry.dsc"),
    i = o && gr(o);
  if (i) return i;
  const a = sn(t.spanContext().traceId, e),
    c = ne(n),
    u = c.data || {},
    l = u[cr];
  l != null && (a.sample_rate = `${l}`);
  const f = u[ar],
    p = c.description;
  return (
    f !== "url" && p && (a.transaction = p),
    wr() && (a.sampled = String(br(n))),
    e.emit("createDsc", a, n),
    a
  );
}
function Or(t) {
  if (typeof t == "boolean") return Number(t);
  const e = typeof t == "string" ? parseFloat(t) : t;
  if (typeof e != "number" || isNaN(e) || e < 0 || e > 1) {
    m &&
      d.warn(
        `[Tracing] Given sample rate is invalid. Sample rate must be a boolean or a number between 0 and 1. Got ${JSON.stringify(
          t
        )} of type ${JSON.stringify(typeof t)}.`
      );
    return;
  }
  return e;
}
const Rr = /^(?:(\w+):)\/\/(?:(\w+)(?::(\w+)?)?@)([\w.-]+)(?::(\d+))?\/(.+)/;
function Dr(t) {
  return t === "http" || t === "https";
}
function vt(t, e = !1) {
  const {
    host: n,
    path: r,
    pass: s,
    port: o,
    projectId: i,
    protocol: a,
    publicKey: c,
  } = t;
  return `${a}://${c}${e && s ? `:${s}` : ""}@${n}${o ? `:${o}` : ""}/${
    r && `${r}/`
  }${i}`;
}
function Cr(t) {
  const e = Rr.exec(t);
  if (!e) {
    G(() => {
      console.error(`Invalid Sentry Dsn: ${t}`);
    });
    return;
  }
  const [n, r, s = "", o = "", i = "", a = ""] = e.slice(1);
  let c = "",
    u = a;
  const l = u.split("/");
  if ((l.length > 1 && ((c = l.slice(0, -1).join("/")), (u = l.pop())), u)) {
    const f = u.match(/^\d+/);
    f && (u = f[0]);
  }
  return on({
    host: o,
    pass: s,
    path: c,
    projectId: u,
    port: i,
    protocol: n,
    publicKey: r,
  });
}
function on(t) {
  return {
    protocol: t.protocol,
    publicKey: t.publicKey || "",
    pass: t.pass || "",
    host: t.host,
    port: t.port || "",
    path: t.path || "",
    projectId: t.projectId,
  };
}
function Pr(t) {
  if (!H) return !0;
  const { port: e, projectId: n, protocol: r } = t;
  return ["protocol", "publicKey", "host", "projectId"].find((i) =>
    t[i] ? !1 : (d.error(`Invalid Sentry Dsn: ${i} missing`), !0)
  )
    ? !1
    : n.match(/^\d+$/)
    ? Dr(r)
      ? e && isNaN(parseInt(e, 10))
        ? (d.error(`Invalid Sentry Dsn: Invalid port ${e}`), !1)
        : !0
      : (d.error(`Invalid Sentry Dsn: Invalid protocol ${r}`), !1)
    : (d.error(`Invalid Sentry Dsn: Invalid projectId ${n}`), !1);
}
function Ar(t) {
  const e = typeof t == "string" ? Cr(t) : on(t);
  if (!(!e || !Pr(e))) return e;
}
function Mr() {
  const t = typeof WeakSet == "function",
    e = t ? new WeakSet() : [];
  function n(s) {
    if (t) return e.has(s) ? !0 : (e.add(s), !1);
    for (let o = 0; o < e.length; o++) if (e[o] === s) return !0;
    return e.push(s), !1;
  }
  function r(s) {
    if (t) e.delete(s);
    else
      for (let o = 0; o < e.length; o++)
        if (e[o] === s) {
          e.splice(o, 1);
          break;
        }
  }
  return [n, r];
}
function O(t, e = 100, n = 1 / 0) {
  try {
    return $t("", t, e, n);
  } catch (r) {
    return { ERROR: `**non-serializable** (${r})` };
  }
}
function an(t, e = 3, n = 100 * 1024) {
  const r = O(t, e);
  return Ur(r) > n ? an(t, e - 1, n) : r;
}
function $t(t, e, n = 1 / 0, r = 1 / 0, s = Mr()) {
  const [o, i] = s;
  if (
    e == null ||
    ["boolean", "string"].includes(typeof e) ||
    (typeof e == "number" && Number.isFinite(e))
  )
    return e;
  const a = $r(t, e);
  if (!a.startsWith("[object ")) return a;
  if (e.__sentry_skip_normalization__) return e;
  const c =
    typeof e.__sentry_override_normalization_depth__ == "number"
      ? e.__sentry_override_normalization_depth__
      : n;
  if (c === 0) return a.replace("object ", "");
  if (o(e)) return "[Circular ~]";
  const u = e;
  if (u && typeof u.toJSON == "function")
    try {
      const _ = u.toJSON();
      return $t("", _, c - 1, r, s);
    } catch {}
  const l = Array.isArray(e) ? [] : {};
  let f = 0;
  const p = tn(e);
  for (const _ in p) {
    if (!Object.prototype.hasOwnProperty.call(p, _)) continue;
    if (f >= r) {
      l[_] = "[MaxProperties ~]";
      break;
    }
    const h = p[_];
    (l[_] = $t(_, h, c - 1, r, s)), f++;
  }
  return i(e), l;
}
function $r(t, e) {
  try {
    if (t === "domain" && e && typeof e == "object" && e._events)
      return "[Domain]";
    if (t === "domainEmitter") return "[DomainEmitter]";
    if (typeof global < "u" && e === global) return "[Global]";
    if (typeof window < "u" && e === window) return "[Window]";
    if (typeof document < "u" && e === document) return "[Document]";
    if (Je(e)) return "[VueViewModel]";
    if ($n(e)) return "[SyntheticEvent]";
    if (typeof e == "number" && !Number.isFinite(e)) return `[${e}]`;
    if (typeof e == "function") return `[Function: ${A(e)}]`;
    if (typeof e == "symbol") return `[${String(e)}]`;
    if (typeof e == "bigint") return `[BigInt: ${String(e)}]`;
    const n = Fr(e);
    return /^HTML(\w*)Element$/.test(n)
      ? `[HTMLElement: ${n}]`
      : `[object ${n}]`;
  } catch (n) {
    return `**non-serializable** (${n})`;
  }
}
function Fr(t) {
  const e = Object.getPrototypeOf(t);
  return e ? e.constructor.name : "null prototype";
}
function Lr(t) {
  return ~-encodeURI(t).split(/%..|./).length;
}
function Ur(t) {
  return Lr(JSON.stringify(t));
}
function nt(t, e = []) {
  return [t, e];
}
function jr(t, e) {
  const [n, r] = t;
  return [n, [...r, e]];
}
function we(t, e) {
  const n = t[1];
  for (const r of n) {
    const s = r[0].type;
    if (e(r, s)) return !0;
  }
  return !1;
}
function Ft(t) {
  return g.__SENTRY__ && g.__SENTRY__.encodePolyfill
    ? g.__SENTRY__.encodePolyfill(t)
    : new TextEncoder().encode(t);
}
function Br(t) {
  const [e, n] = t;
  let r = JSON.stringify(e);
  function s(o) {
    typeof r == "string"
      ? (r = typeof o == "string" ? r + o : [Ft(r), o])
      : r.push(typeof o == "string" ? Ft(o) : o);
  }
  for (const o of n) {
    const [i, a] = o;
    if (
      (s(`
${JSON.stringify(i)}
`),
      typeof a == "string" || a instanceof Uint8Array)
    )
      s(a);
    else {
      let c;
      try {
        c = JSON.stringify(a);
      } catch {
        c = JSON.stringify(O(a));
      }
      s(c);
    }
  }
  return typeof r == "string" ? r : Hr(r);
}
function Hr(t) {
  const e = t.reduce((s, o) => s + o.length, 0),
    n = new Uint8Array(e);
  let r = 0;
  for (const s of t) n.set(s, r), (r += s.length);
  return n;
}
function Gr(t) {
  const e = typeof t.data == "string" ? Ft(t.data) : t.data;
  return [
    v({
      type: "attachment",
      length: e.length,
      filename: t.filename,
      content_type: t.contentType,
      attachment_type: t.attachmentType,
    }),
    e,
  ];
}
const Wr = {
  session: "session",
  sessions: "session",
  attachment: "attachment",
  transaction: "transaction",
  event: "error",
  client_report: "internal",
  user_report: "default",
  profile: "profile",
  profile_chunk: "profile",
  replay_event: "replay",
  replay_recording: "replay",
  check_in: "monitor",
  feedback: "feedback",
  span: "span",
  statsd: "metric_bucket",
  raw_security: "security",
};
function ke(t) {
  return Wr[t];
}
function cn(t) {
  if (!t || !t.sdk) return;
  const { name: e, version: n } = t.sdk;
  return { name: e, version: n };
}
function qr(t, e, n, r) {
  const s =
    t.sdkProcessingMetadata && t.sdkProcessingMetadata.dynamicSamplingContext;
  return {
    event_id: t.event_id,
    sent_at: new Date().toISOString(),
    ...(e && { sdk: e }),
    ...(!!n && r && { dsn: vt(r) }),
    ...(s && { trace: v({ ...s }) }),
  };
}
function Yr(t, e) {
  return (
    e &&
      ((t.sdk = t.sdk || {}),
      (t.sdk.name = t.sdk.name || e.name),
      (t.sdk.version = t.sdk.version || e.version),
      (t.sdk.integrations = [
        ...(t.sdk.integrations || []),
        ...(e.integrations || []),
      ]),
      (t.sdk.packages = [...(t.sdk.packages || []), ...(e.packages || [])])),
    t
  );
}
function zr(t, e, n, r) {
  const s = cn(n),
    o = {
      sent_at: new Date().toISOString(),
      ...(s && { sdk: s }),
      ...(!!r && e && { dsn: vt(e) }),
    },
    i =
      "aggregates" in t
        ? [{ type: "sessions" }, t]
        : [{ type: "session" }, t.toJSON()];
  return nt(o, [i]);
}
function Kr(t, e, n, r) {
  const s = cn(n),
    o = t.type && t.type !== "replay_event" ? t.type : "event";
  Yr(t, n && n.sdk);
  const i = qr(t, s, r, e);
  return delete t.sdkProcessingMetadata, nt(i, [[{ type: o }, t]]);
}
function Lt(t, e, n, r = 0) {
  return new T((s, o) => {
    const i = t[r];
    if (e === null || typeof i != "function") s(e);
    else {
      const a = i({ ...e }, n);
      m &&
        i.id &&
        a === null &&
        d.log(`Event processor "${i.id}" dropped event`),
        bt(a)
          ? a.then((c) => Lt(t, c, n, r + 1).then(s)).then(null, o)
          : Lt(t, a, n, r + 1)
              .then(s)
              .then(null, o);
    }
  });
}
let at, Ne, ct;
function Xr(t) {
  const e = g._sentryDebugIds;
  if (!e) return {};
  const n = Object.keys(e);
  return (
    (ct && n.length === Ne) ||
      ((Ne = n.length),
      (ct = n.reduce((r, s) => {
        at || (at = {});
        const o = at[s];
        if (o) r[o[0]] = o[1];
        else {
          const i = t(s);
          for (let a = i.length - 1; a >= 0; a--) {
            const c = i[a],
              u = c && c.filename,
              l = e[s];
            if (u && l) {
              (r[u] = l), (at[s] = [u, l]);
              break;
            }
          }
        }
        return r;
      }, {}))),
    ct
  );
}
function Vr(t, e) {
  const {
    fingerprint: n,
    span: r,
    breadcrumbs: s,
    sdkProcessingMetadata: o,
  } = e;
  Jr(t, e), r && ts(t, r), es(t, n), Zr(t, s), Qr(t, o);
}
function xe(t, e) {
  const {
    extra: n,
    tags: r,
    user: s,
    contexts: o,
    level: i,
    sdkProcessingMetadata: a,
    breadcrumbs: c,
    fingerprint: u,
    eventProcessors: l,
    attachments: f,
    propagationContext: p,
    transactionName: _,
    span: h,
  } = e;
  ut(t, "extra", n),
    ut(t, "tags", r),
    ut(t, "user", s),
    ut(t, "contexts", o),
    (t.sdkProcessingMetadata = Tt(t.sdkProcessingMetadata, a, 2)),
    i && (t.level = i),
    _ && (t.transactionName = _),
    h && (t.span = h),
    c.length && (t.breadcrumbs = [...t.breadcrumbs, ...c]),
    u.length && (t.fingerprint = [...t.fingerprint, ...u]),
    l.length && (t.eventProcessors = [...t.eventProcessors, ...l]),
    f.length && (t.attachments = [...t.attachments, ...f]),
    (t.propagationContext = { ...t.propagationContext, ...p });
}
function ut(t, e, n) {
  t[e] = Tt(t[e], n, 1);
}
function Jr(t, e) {
  const {
      extra: n,
      tags: r,
      user: s,
      contexts: o,
      level: i,
      transactionName: a,
    } = e,
    c = v(n);
  c && Object.keys(c).length && (t.extra = { ...c, ...t.extra });
  const u = v(r);
  u && Object.keys(u).length && (t.tags = { ...u, ...t.tags });
  const l = v(s);
  l && Object.keys(l).length && (t.user = { ...l, ...t.user });
  const f = v(o);
  f && Object.keys(f).length && (t.contexts = { ...f, ...t.contexts }),
    i && (t.level = i),
    a && t.type !== "transaction" && (t.transaction = a);
}
function Zr(t, e) {
  const n = [...(t.breadcrumbs || []), ...e];
  t.breadcrumbs = n.length ? n : void 0;
}
function Qr(t, e) {
  t.sdkProcessingMetadata = { ...t.sdkProcessingMetadata, ...e };
}
function ts(t, e) {
  (t.contexts = { trace: yr(e), ...t.contexts }),
    (t.sdkProcessingMetadata = {
      dynamicSamplingContext: xr(e),
      ...t.sdkProcessingMetadata,
    });
  const n = rn(e),
    r = ne(n).description;
  r && !t.transaction && t.type === "transaction" && (t.transaction = r);
}
function es(t, e) {
  (t.fingerprint = t.fingerprint
    ? Array.isArray(t.fingerprint)
      ? t.fingerprint
      : [t.fingerprint]
    : []),
    e && (t.fingerprint = t.fingerprint.concat(e)),
    t.fingerprint && !t.fingerprint.length && delete t.fingerprint;
}
function ns(t, e, n, r, s, o) {
  const { normalizeDepth: i = 3, normalizeMaxBreadth: a = 1e3 } = t,
    c = {
      ...e,
      event_id: e.event_id || n.event_id || w(),
      timestamp: e.timestamp || tt(),
    },
    u = n.integrations || t.integrations.map((S) => S.name);
  rs(c, t),
    is(c, u),
    s && s.emit("applyFrameMetadata", e),
    e.type === void 0 && ss(c, t.stackParser);
  const l = cs(r, n.captureContext);
  n.mechanism && K(c, n.mechanism);
  const f = s ? s.getEventProcessors() : [],
    p = nr().getScopeData();
  if (o) {
    const S = o.getScopeData();
    xe(p, S);
  }
  if (l) {
    const S = l.getScopeData();
    xe(p, S);
  }
  const _ = [...(n.attachments || []), ...p.attachments];
  _.length && (n.attachments = _), Vr(c, p);
  const h = [...f, ...p.eventProcessors];
  return Lt(h, c, n).then(
    (S) => (S && os(S), typeof i == "number" && i > 0 ? as(S, i, a) : S)
  );
}
function rs(t, e) {
  const { environment: n, release: r, dist: s, maxValueLength: o = 250 } = e;
  (t.environment = t.environment || n || re),
    !t.release && r && (t.release = r),
    !t.dist && s && (t.dist = s),
    t.message && (t.message = Y(t.message, o));
  const i = t.exception && t.exception.values && t.exception.values[0];
  i && i.value && (i.value = Y(i.value, o));
  const a = t.request;
  a && a.url && (a.url = Y(a.url, o));
}
function ss(t, e) {
  const n = Xr(e);
  try {
    t.exception.values.forEach((r) => {
      r.stacktrace.frames.forEach((s) => {
        n && s.filename && (s.debug_id = n[s.filename]);
      });
    });
  } catch {}
}
function os(t) {
  const e = {};
  try {
    t.exception.values.forEach((r) => {
      r.stacktrace.frames.forEach((s) => {
        s.debug_id &&
          (s.abs_path
            ? (e[s.abs_path] = s.debug_id)
            : s.filename && (e[s.filename] = s.debug_id),
          delete s.debug_id);
      });
    });
  } catch {}
  if (Object.keys(e).length === 0) return;
  (t.debug_meta = t.debug_meta || {}),
    (t.debug_meta.images = t.debug_meta.images || []);
  const n = t.debug_meta.images;
  Object.entries(e).forEach(([r, s]) => {
    n.push({ type: "sourcemap", code_file: r, debug_id: s });
  });
}
function is(t, e) {
  e.length > 0 &&
    ((t.sdk = t.sdk || {}),
    (t.sdk.integrations = [...(t.sdk.integrations || []), ...e]));
}
function as(t, e, n) {
  if (!t) return null;
  const r = {
    ...t,
    ...(t.breadcrumbs && {
      breadcrumbs: t.breadcrumbs.map((s) => ({
        ...s,
        ...(s.data && { data: O(s.data, e, n) }),
      })),
    }),
    ...(t.user && { user: O(t.user, e, n) }),
    ...(t.contexts && { contexts: O(t.contexts, e, n) }),
    ...(t.extra && { extra: O(t.extra, e, n) }),
  };
  return (
    t.contexts &&
      t.contexts.trace &&
      r.contexts &&
      ((r.contexts.trace = t.contexts.trace),
      t.contexts.trace.data &&
        (r.contexts.trace.data = O(t.contexts.trace.data, e, n))),
    t.spans &&
      (r.spans = t.spans.map((s) => ({
        ...s,
        ...(s.data && { data: O(s.data, e, n) }),
      }))),
    t.contexts &&
      t.contexts.flags &&
      r.contexts &&
      (r.contexts.flags = O(t.contexts.flags, 3, n)),
    r
  );
}
function cs(t, e) {
  if (!e) return t;
  const n = t ? t.clone() : new j();
  return n.update(e), n;
}
function us(t, e) {
  return C().captureException(t, void 0);
}
function un(t, e) {
  return C().captureEvent(t, e);
}
function Oe(t) {
  const e = E(),
    n = et(),
    r = C(),
    { release: s, environment: o = re } = (e && e.getOptions()) || {},
    { userAgent: i } = g.navigator || {},
    a = Yn({
      release: s,
      environment: o,
      user: r.getUser() || n.getUser(),
      ...(i && { userAgent: i }),
      ...t,
    }),
    c = n.getSession();
  return (
    c && c.status === "ok" && X(c, { status: "exited" }),
    fn(),
    n.setSession(a),
    r.setSession(a),
    a
  );
}
function fn() {
  const t = et(),
    e = C(),
    n = e.getSession() || t.getSession();
  n && zn(n), ln(), t.setSession(), e.setSession();
}
function ln() {
  const t = et(),
    e = C(),
    n = E(),
    r = e.getSession() || t.getSession();
  r && n && n.captureSession(r);
}
function Re(t = !1) {
  if (t) {
    fn();
    return;
  }
  ln();
}
const fs = "7";
function ls(t) {
  const e = t.protocol ? `${t.protocol}:` : "",
    n = t.port ? `:${t.port}` : "";
  return `${e}//${t.host}${n}${t.path ? `/${t.path}` : ""}/api/`;
}
function ds(t) {
  return `${ls(t)}${t.projectId}/envelope/`;
}
function ps(t, e) {
  const n = { sentry_version: fs };
  return (
    t.publicKey && (n.sentry_key = t.publicKey),
    e && (n.sentry_client = `${e.name}/${e.version}`),
    new URLSearchParams(n).toString()
  );
}
function hs(t, e, n) {
  return e || `${ds(t)}?${ps(t, n)}`;
}
const De = [];
function gs(t) {
  const e = {};
  return (
    t.forEach((n) => {
      const { name: r } = n,
        s = e[r];
      (s && !s.isDefaultInstance && n.isDefaultInstance) || (e[r] = n);
    }),
    Object.values(e)
  );
}
function _s(t) {
  const e = t.defaultIntegrations || [],
    n = t.integrations;
  e.forEach((i) => {
    i.isDefaultInstance = !0;
  });
  let r;
  if (Array.isArray(n)) r = [...e, ...n];
  else if (typeof n == "function") {
    const i = n(e);
    r = Array.isArray(i) ? i : [i];
  } else r = e;
  const s = gs(r),
    o = s.findIndex((i) => i.name === "Debug");
  if (o > -1) {
    const [i] = s.splice(o, 1);
    s.push(i);
  }
  return s;
}
function ms(t, e) {
  const n = {};
  return (
    e.forEach((r) => {
      r && dn(t, r, n);
    }),
    n
  );
}
function Ce(t, e) {
  for (const n of e) n && n.afterAllSetup && n.afterAllSetup(t);
}
function dn(t, e, n) {
  if (n[e.name]) {
    m &&
      d.log(`Integration skipped because it was already installed: ${e.name}`);
    return;
  }
  if (
    ((n[e.name] = e),
    De.indexOf(e.name) === -1 &&
      typeof e.setupOnce == "function" &&
      (e.setupOnce(), De.push(e.name)),
    e.setup && typeof e.setup == "function" && e.setup(t),
    typeof e.preprocessEvent == "function")
  ) {
    const r = e.preprocessEvent.bind(e);
    t.on("preprocessEvent", (s, o) => r(s, o, t));
  }
  if (typeof e.processEvent == "function") {
    const r = e.processEvent.bind(e),
      s = Object.assign((o, i) => r(o, i, t), { id: e.name });
    t.addEventProcessor(s);
  }
  m && d.log(`Integration installed: ${e.name}`);
}
function ys(t, e, n) {
  const r = [
    { type: "client_report" },
    { timestamp: tt(), discarded_events: t },
  ];
  return nt(e ? { dsn: e } : {}, [r]);
}
class k extends Error {
  constructor(e, n = "warn") {
    super(e), (this.message = e), (this.logLevel = n);
  }
}
const Pe = "Not capturing exception because it's already been captured.";
class Es {
  constructor(e) {
    if (
      ((this._options = e),
      (this._integrations = {}),
      (this._numProcessing = 0),
      (this._outcomes = {}),
      (this._hooks = {}),
      (this._eventProcessors = []),
      e.dsn
        ? (this._dsn = Ar(e.dsn))
        : m && d.warn("No DSN provided, client will not send events."),
      this._dsn)
    ) {
      const s = hs(this._dsn, e.tunnel, e._metadata ? e._metadata.sdk : void 0);
      this._transport = e.transport({
        tunnel: this._options.tunnel,
        recordDroppedEvent: this.recordDroppedEvent.bind(this),
        ...e.transportOptions,
        url: s,
      });
    }
    const r = ["enableTracing", "tracesSampleRate", "tracesSampler"].find(
      (s) => s in e && e[s] == null
    );
    r &&
      G(() => {
        console.warn(
          `[Sentry] Deprecation warning: \`${r}\` is set to undefined, which leads to tracing being enabled. In v9, a value of \`undefined\` will result in tracing being disabled.`
        );
      });
  }
  captureException(e, n, r) {
    const s = w();
    if (_e(e)) return m && d.log(Pe), s;
    const o = { event_id: s, ...n };
    return (
      this._process(
        this.eventFromException(e, o).then((i) => this._captureEvent(i, o, r))
      ),
      o.event_id
    );
  }
  captureMessage(e, n, r, s) {
    const o = { event_id: w(), ...r },
      i = Vt(e) ? e : String(e),
      a = Jt(e)
        ? this.eventFromMessage(i, n, o)
        : this.eventFromException(e, o);
    return (
      this._process(a.then((c) => this._captureEvent(c, o, s))), o.event_id
    );
  }
  captureEvent(e, n, r) {
    const s = w();
    if (n && n.originalException && _e(n.originalException))
      return m && d.log(Pe), s;
    const o = { event_id: s, ...n },
      a = (e.sdkProcessingMetadata || {}).capturedSpanScope;
    return this._process(this._captureEvent(e, o, a || r)), o.event_id;
  }
  captureSession(e) {
    typeof e.release != "string"
      ? m &&
        d.warn("Discarded session because of missing or non-string release")
      : (this.sendSession(e), X(e, { init: !1 }));
  }
  getDsn() {
    return this._dsn;
  }
  getOptions() {
    return this._options;
  }
  getSdkMetadata() {
    return this._options._metadata;
  }
  getTransport() {
    return this._transport;
  }
  flush(e) {
    const n = this._transport;
    return n
      ? (this.emit("flush"),
        this._isClientDoneProcessing(e).then((r) =>
          n.flush(e).then((s) => r && s)
        ))
      : U(!0);
  }
  close(e) {
    return this.flush(e).then(
      (n) => ((this.getOptions().enabled = !1), this.emit("close"), n)
    );
  }
  getEventProcessors() {
    return this._eventProcessors;
  }
  addEventProcessor(e) {
    this._eventProcessors.push(e);
  }
  init() {
    (this._isEnabled() ||
      this._options.integrations.some(({ name: e }) =>
        e.startsWith("Spotlight")
      )) &&
      this._setupIntegrations();
  }
  getIntegrationByName(e) {
    return this._integrations[e];
  }
  addIntegration(e) {
    const n = this._integrations[e.name];
    dn(this, e, this._integrations), n || Ce(this, [e]);
  }
  sendEvent(e, n = {}) {
    this.emit("beforeSendEvent", e, n);
    let r = Kr(e, this._dsn, this._options._metadata, this._options.tunnel);
    for (const o of n.attachments || []) r = jr(r, Gr(o));
    const s = this.sendEnvelope(r);
    s && s.then((o) => this.emit("afterSendEvent", e, o), null);
  }
  sendSession(e) {
    const n = zr(e, this._dsn, this._options._metadata, this._options.tunnel);
    this.sendEnvelope(n);
  }
  recordDroppedEvent(e, n, r) {
    if (this._options.sendClientReports) {
      const s = typeof r == "number" ? r : 1,
        o = `${e}:${n}`;
      m && d.log(`Recording outcome: "${o}"${s > 1 ? ` (${s} times)` : ""}`),
        (this._outcomes[o] = (this._outcomes[o] || 0) + s);
    }
  }
  on(e, n) {
    const r = (this._hooks[e] = this._hooks[e] || []);
    return (
      r.push(n),
      () => {
        const s = r.indexOf(n);
        s > -1 && r.splice(s, 1);
      }
    );
  }
  emit(e, ...n) {
    const r = this._hooks[e];
    r && r.forEach((s) => s(...n));
  }
  sendEnvelope(e) {
    return (
      this.emit("beforeEnvelope", e),
      this._isEnabled() && this._transport
        ? this._transport
            .send(e)
            .then(
              null,
              (n) => (m && d.error("Error while sending envelope:", n), n)
            )
        : (m && d.error("Transport disabled"), U({}))
    );
  }
  _setupIntegrations() {
    const { integrations: e } = this._options;
    (this._integrations = ms(this, e)), Ce(this, e);
  }
  _updateSessionFromEvent(e, n) {
    let r = n.level === "fatal",
      s = !1;
    const o = n.exception && n.exception.values;
    if (o) {
      s = !0;
      for (const c of o) {
        const u = c.mechanism;
        if (u && u.handled === !1) {
          r = !0;
          break;
        }
      }
    }
    const i = e.status === "ok";
    ((i && e.errors === 0) || (i && r)) &&
      (X(e, {
        ...(r && { status: "crashed" }),
        errors: e.errors || Number(s || r),
      }),
      this.captureSession(e));
  }
  _isClientDoneProcessing(e) {
    return new T((n) => {
      let r = 0;
      const s = 1,
        o = setInterval(() => {
          this._numProcessing == 0
            ? (clearInterval(o), n(!0))
            : ((r += s), e && r >= e && (clearInterval(o), n(!1)));
        }, s);
    });
  }
  _isEnabled() {
    return this.getOptions().enabled !== !1 && this._transport !== void 0;
  }
  _prepareEvent(e, n, r = C(), s = et()) {
    const o = this.getOptions(),
      i = Object.keys(this._integrations);
    return (
      !n.integrations && i.length > 0 && (n.integrations = i),
      this.emit("preprocessEvent", e, n),
      e.type || s.setLastEventId(e.event_id || n.event_id),
      ns(o, e, n, r, this, s).then((a) => {
        if (a === null) return a;
        a.contexts = { trace: sr(r), ...a.contexts };
        const c = Nr(this, r);
        return (
          (a.sdkProcessingMetadata = {
            dynamicSamplingContext: c,
            ...a.sdkProcessingMetadata,
          }),
          a
        );
      })
    );
  }
  _captureEvent(e, n = {}, r) {
    return this._processEvent(e, n, r).then(
      (s) => s.event_id,
      (s) => {
        m &&
          (s instanceof k && s.logLevel === "log"
            ? d.log(s.message)
            : d.warn(s));
      }
    );
  }
  _processEvent(e, n, r) {
    const s = this.getOptions(),
      { sampleRate: o } = s,
      i = hn(e),
      a = pn(e),
      c = e.type || "error",
      u = `before send for type \`${c}\``,
      l = typeof o > "u" ? void 0 : Or(o);
    if (a && typeof l == "number" && Math.random() > l)
      return (
        this.recordDroppedEvent("sample_rate", "error", e),
        _t(
          new k(
            `Discarding event because it's not included in the random sample (sampling rate = ${o})`,
            "log"
          )
        )
      );
    const f = c === "replay_event" ? "replay" : c,
      _ = (e.sdkProcessingMetadata || {}).capturedSpanIsolationScope;
    return this._prepareEvent(e, n, r, _)
      .then((h) => {
        if (h === null)
          throw (
            (this.recordDroppedEvent("event_processor", f, e),
            new k(
              "An event processor returned `null`, will not send event.",
              "log"
            ))
          );
        if (n.data && n.data.__sentry__ === !0) return h;
        const S = bs(this, s, h, n);
        return Ss(S, u);
      })
      .then((h) => {
        if (h === null) {
          if ((this.recordDroppedEvent("before_send", f, e), i)) {
            const wt = 1 + (e.spans || []).length;
            this.recordDroppedEvent("before_send", "span", wt);
          }
          throw new k(`${u} returned \`null\`, will not send event.`, "log");
        }
        const st = r && r.getSession();
        if ((!i && st && this._updateSessionFromEvent(st, h), i)) {
          const ot =
              (h.sdkProcessingMetadata &&
                h.sdkProcessingMetadata.spanCountBeforeProcessing) ||
              0,
            wt = h.spans ? h.spans.length : 0,
            ae = ot - wt;
          ae > 0 && this.recordDroppedEvent("before_send", "span", ae);
        }
        const S = h.transaction_info;
        if (i && S && h.transaction !== e.transaction) {
          const ot = "custom";
          h.transaction_info = { ...S, source: ot };
        }
        return this.sendEvent(h, n), h;
      })
      .then(null, (h) => {
        throw h instanceof k
          ? h
          : (this.captureException(h, {
              data: { __sentry__: !0 },
              originalException: h,
            }),
            new k(`Event processing pipeline threw an error, original event will not be sent. Details have been sent as a new event.
Reason: ${h}`));
      });
  }
  _process(e) {
    this._numProcessing++,
      e.then(
        (n) => (this._numProcessing--, n),
        (n) => (this._numProcessing--, n)
      );
  }
  _clearOutcomes() {
    const e = this._outcomes;
    return (
      (this._outcomes = {}),
      Object.entries(e).map(([n, r]) => {
        const [s, o] = n.split(":");
        return { reason: s, category: o, quantity: r };
      })
    );
  }
  _flushOutcomes() {
    m && d.log("Flushing outcomes...");
    const e = this._clearOutcomes();
    if (e.length === 0) {
      m && d.log("No outcomes to send");
      return;
    }
    if (!this._dsn) {
      m && d.log("No dsn provided, will not send outcomes");
      return;
    }
    m && d.log("Sending outcomes:", e);
    const n = ys(e, this._options.tunnel && vt(this._dsn));
    this.sendEnvelope(n);
  }
}
function Ss(t, e) {
  const n = `${e} must return \`null\` or a valid event.`;
  if (bt(t))
    return t.then(
      (r) => {
        if (!z(r) && r !== null) throw new k(n);
        return r;
      },
      (r) => {
        throw new k(`${e} rejected with ${r}`);
      }
    );
  if (!z(t) && t !== null) throw new k(n);
  return t;
}
function bs(t, e, n, r) {
  const { beforeSend: s, beforeSendTransaction: o, beforeSendSpan: i } = e;
  if (pn(n) && s) return s(n, r);
  if (hn(n)) {
    if (n.spans && i) {
      const a = [];
      for (const c of n.spans) {
        const u = i(c);
        u ? a.push(u) : (vr(), t.recordDroppedEvent("before_send", "span"));
      }
      n.spans = a;
    }
    if (o) {
      if (n.spans) {
        const a = n.spans.length;
        n.sdkProcessingMetadata = {
          ...n.sdkProcessingMetadata,
          spanCountBeforeProcessing: a,
        };
      }
      return o(n, r);
    }
  }
  return n;
}
function pn(t) {
  return t.type === void 0;
}
function hn(t) {
  return t.type === "transaction";
}
function Is(t, e) {
  e.debug === !0 &&
    (m
      ? d.enable()
      : G(() => {
          console.warn(
            "[Sentry] Cannot initialize SDK with `debug` option using a non-debug bundle."
          );
        })),
    C().update(e.initialScope);
  const r = new t(e);
  return Ts(r), r.init(), r;
}
function Ts(t) {
  C().setClient(t);
}
function vs(t) {
  const e = [];
  function n() {
    return t === void 0 || e.length < t;
  }
  function r(i) {
    return e.splice(e.indexOf(i), 1)[0] || Promise.resolve(void 0);
  }
  function s(i) {
    if (!n())
      return _t(new k("Not adding Promise because buffer limit was reached."));
    const a = i();
    return (
      e.indexOf(a) === -1 && e.push(a),
      a.then(() => r(a)).then(null, () => r(a).then(null, () => {})),
      a
    );
  }
  function o(i) {
    return new T((a, c) => {
      let u = e.length;
      if (!u) return a(!0);
      const l = setTimeout(() => {
        i && i > 0 && a(!1);
      }, i);
      e.forEach((f) => {
        U(f).then(() => {
          --u || (clearTimeout(l), a(!0));
        }, c);
      });
    });
  }
  return { $: e, add: s, drain: o };
}
const ws = 60 * 1e3;
function ks(t, e = Date.now()) {
  const n = parseInt(`${t}`, 10);
  if (!isNaN(n)) return n * 1e3;
  const r = Date.parse(`${t}`);
  return isNaN(r) ? ws : r - e;
}
function Ns(t, e) {
  return t[e] || t.all || 0;
}
function xs(t, e, n = Date.now()) {
  return Ns(t, e) > n;
}
function Os(t, { statusCode: e, headers: n }, r = Date.now()) {
  const s = { ...t },
    o = n && n["x-sentry-rate-limits"],
    i = n && n["retry-after"];
  if (o)
    for (const a of o.trim().split(",")) {
      const [c, u, , , l] = a.split(":", 5),
        f = parseInt(c, 10),
        p = (isNaN(f) ? 60 : f) * 1e3;
      if (!u) s.all = r + p;
      else
        for (const _ of u.split(";"))
          _ === "metric_bucket"
            ? (!l || l.split(";").includes("custom")) && (s[_] = r + p)
            : (s[_] = r + p);
    }
  else i ? (s.all = r + ks(i, r)) : e === 429 && (s.all = r + 60 * 1e3);
  return s;
}
const Rs = 64;
function Ds(t, e, n = vs(t.bufferSize || Rs)) {
  let r = {};
  const s = (i) => n.drain(i);
  function o(i) {
    const a = [];
    if (
      (we(i, (f, p) => {
        const _ = ke(p);
        if (xs(r, _)) {
          const h = Ae(f, p);
          t.recordDroppedEvent("ratelimit_backoff", _, h);
        } else a.push(f);
      }),
      a.length === 0)
    )
      return U({});
    const c = nt(i[0], a),
      u = (f) => {
        we(c, (p, _) => {
          const h = Ae(p, _);
          t.recordDroppedEvent(f, ke(_), h);
        });
      },
      l = () =>
        e({ body: Br(c) }).then(
          (f) => (
            f.statusCode !== void 0 &&
              (f.statusCode < 200 || f.statusCode >= 300) &&
              m &&
              d.warn(
                `Sentry responded with status code ${f.statusCode} to sent event.`
              ),
            (r = Os(r, f)),
            f
          ),
          (f) => {
            throw (u("network_error"), f);
          }
        );
    return n.add(l).then(
      (f) => f,
      (f) => {
        if (f instanceof k)
          return (
            m && d.error("Skipped sending event because buffer is full."),
            u("queue_overflow"),
            U({})
          );
        throw f;
      }
    );
  }
  return { send: o, flush: s };
}
function Ae(t, e) {
  if (!(e !== "event" && e !== "transaction"))
    return Array.isArray(t) ? t[1] : void 0;
}
function Cs(t, e, n = [e], r = "npm") {
  const s = t._metadata || {};
  s.sdk ||
    (s.sdk = {
      name: `sentry.javascript.${e}`,
      packages: n.map((o) => ({ name: `${r}:@sentry/${o}`, version: M })),
      version: M,
    }),
    (t._metadata = s);
}
const Ps = 100;
function B(t, e) {
  const n = E(),
    r = et();
  if (!n) return;
  const { beforeBreadcrumb: s = null, maxBreadcrumbs: o = Ps } = n.getOptions();
  if (o <= 0) return;
  const a = { timestamp: tt(), ...t },
    c = s ? G(() => s(a, e)) : a;
  c !== null &&
    (n.emit && n.emit("beforeAddBreadcrumb", c, e), r.addBreadcrumb(c, o));
}
let Me;
const As = "FunctionToString",
  $e = new WeakMap(),
  Ms = () => ({
    name: As,
    setupOnce() {
      Me = Function.prototype.toString;
      try {
        Function.prototype.toString = function (...t) {
          const e = Qt(this),
            n = $e.has(E()) && e !== void 0 ? e : this;
          return Me.apply(n, t);
        };
      } catch {}
    },
    setup(t) {
      $e.set(t, !0);
    },
  }),
  $s = Ms,
  Fs = [
    /^Script error\.?$/,
    /^Javascript error: Script error\.? on line 0$/,
    /^ResizeObserver loop completed with undelivered notifications.$/,
    /^Cannot redefine property: googletag$/,
    /^Can't find variable: gmo$/,
    "undefined is not an object (evaluating 'a.L')",
    `can't redefine non-configurable property "solana"`,
    "vv().getRestrictions is not a function. (In 'vv().getRestrictions(1,a)', 'vv().getRestrictions' is undefined)",
    "Can't find variable: _AutofillCallbackHandler",
    /^Non-Error promise rejection captured with value: Object Not Found Matching Id:\d+, MethodName:simulateEvent, ParamCount:\d+$/,
    /^Java exception was raised during method invocation$/,
  ],
  Ls = "InboundFilters",
  Us = (t = {}) => ({
    name: Ls,
    processEvent(e, n, r) {
      const s = r.getOptions(),
        o = Bs(t, s);
      return Hs(e, o) ? null : e;
    },
  }),
  js = Us;
function Bs(t = {}, e = {}) {
  return {
    allowUrls: [...(t.allowUrls || []), ...(e.allowUrls || [])],
    denyUrls: [...(t.denyUrls || []), ...(e.denyUrls || [])],
    ignoreErrors: [
      ...(t.ignoreErrors || []),
      ...(e.ignoreErrors || []),
      ...(t.disableErrorDefaults ? [] : Fs),
    ],
    ignoreTransactions: [
      ...(t.ignoreTransactions || []),
      ...(e.ignoreTransactions || []),
    ],
    ignoreInternal: t.ignoreInternal !== void 0 ? t.ignoreInternal : !0,
  };
}
function Hs(t, e) {
  return e.ignoreInternal && Ks(t)
    ? (m &&
        d.warn(`Event dropped due to being internal Sentry Error.
Event: ${P(t)}`),
      !0)
    : Gs(t, e.ignoreErrors)
    ? (m &&
        d.warn(`Event dropped due to being matched by \`ignoreErrors\` option.
Event: ${P(t)}`),
      !0)
    : Vs(t)
    ? (m &&
        d.warn(`Event dropped due to not having an error message, error type or stacktrace.
Event: ${P(t)}`),
      !0)
    : Ws(t, e.ignoreTransactions)
    ? (m &&
        d.warn(`Event dropped due to being matched by \`ignoreTransactions\` option.
Event: ${P(t)}`),
      !0)
    : qs(t, e.denyUrls)
    ? (m &&
        d.warn(`Event dropped due to being matched by \`denyUrls\` option.
Event: ${P(t)}.
Url: ${mt(t)}`),
      !0)
    : Ys(t, e.allowUrls)
    ? !1
    : (m &&
        d.warn(`Event dropped due to not being matched by \`allowUrls\` option.
Event: ${P(t)}.
Url: ${mt(t)}`),
      !0);
}
function Gs(t, e) {
  return t.type || !e || !e.length ? !1 : zs(t).some((n) => It(n, e));
}
function Ws(t, e) {
  if (t.type !== "transaction" || !e || !e.length) return !1;
  const n = t.transaction;
  return n ? It(n, e) : !1;
}
function qs(t, e) {
  if (!e || !e.length) return !1;
  const n = mt(t);
  return n ? It(n, e) : !1;
}
function Ys(t, e) {
  if (!e || !e.length) return !0;
  const n = mt(t);
  return n ? It(n, e) : !0;
}
function zs(t) {
  const e = [];
  t.message && e.push(t.message);
  let n;
  try {
    n = t.exception.values[t.exception.values.length - 1];
  } catch {}
  return (
    n &&
      n.value &&
      (e.push(n.value), n.type && e.push(`${n.type}: ${n.value}`)),
    e
  );
}
function Ks(t) {
  try {
    return t.exception.values[0].type === "SentryError";
  } catch {}
  return !1;
}
function Xs(t = []) {
  for (let e = t.length - 1; e >= 0; e--) {
    const n = t[e];
    if (n && n.filename !== "<anonymous>" && n.filename !== "[native code]")
      return n.filename || null;
  }
  return null;
}
function mt(t) {
  try {
    let e;
    try {
      e = t.exception.values[0].stacktrace.frames;
    } catch {}
    return e ? Xs(e) : null;
  } catch {
    return m && d.error(`Cannot extract url for event ${P(t)}`), null;
  }
}
function Vs(t) {
  return t.type ||
    !t.exception ||
    !t.exception.values ||
    t.exception.values.length === 0
    ? !1
    : !t.message &&
        !t.exception.values.some(
          (e) => e.stacktrace || (e.type && e.type !== "Error") || e.value
        );
}
function Js(t, e, n = 250, r, s, o, i) {
  if (
    !o.exception ||
    !o.exception.values ||
    !i ||
    !F(i.originalException, Error)
  )
    return;
  const a =
    o.exception.values.length > 0
      ? o.exception.values[o.exception.values.length - 1]
      : void 0;
  a &&
    (o.exception.values = Zs(
      Ut(t, e, s, i.originalException, r, o.exception.values, a, 0),
      n
    ));
}
function Ut(t, e, n, r, s, o, i, a) {
  if (o.length >= n + 1) return o;
  let c = [...o];
  if (F(r[s], Error)) {
    Fe(i, a);
    const u = t(e, r[s]),
      l = c.length;
    Le(u, s, l, a), (c = Ut(t, e, n, r[s], s, [u, ...c], u, l));
  }
  return (
    Array.isArray(r.errors) &&
      r.errors.forEach((u, l) => {
        if (F(u, Error)) {
          Fe(i, a);
          const f = t(e, u),
            p = c.length;
          Le(f, `errors[${l}]`, p, a), (c = Ut(t, e, n, u, s, [f, ...c], f, p));
        }
      }),
    c
  );
}
function Fe(t, e) {
  (t.mechanism = t.mechanism || { type: "generic", handled: !0 }),
    (t.mechanism = {
      ...t.mechanism,
      ...(t.type === "AggregateError" && { is_exception_group: !0 }),
      exception_id: e,
    });
}
function Le(t, e, n, r) {
  (t.mechanism = t.mechanism || { type: "generic", handled: !0 }),
    (t.mechanism = {
      ...t.mechanism,
      type: "chained",
      source: e,
      exception_id: n,
      parent_id: r,
    });
}
function Zs(t, e) {
  return t.map((n) => (n.value && (n.value = Y(n.value, e)), n));
}
function Ot(t) {
  if (!t) return {};
  const e = t.match(
    /^(([^:/?#]+):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?$/
  );
  if (!e) return {};
  const n = e[6] || "",
    r = e[8] || "";
  return {
    host: e[4],
    path: e[5],
    protocol: e[2],
    search: n,
    hash: r,
    relative: e[5] + n + r,
  };
}
function Qs(t) {
  const e = "console";
  W(e, t), q(e, to);
}
function to() {
  "console" in g &&
    Dt.forEach(function (t) {
      t in g.console &&
        I(g.console, t, function (e) {
          return (
            (gt[t] = e),
            function (...n) {
              N("console", { args: n, level: t });
              const s = gt[t];
              s && s.apply(g.console, n);
            }
          );
        });
    });
}
function eo(t) {
  return t === "warn"
    ? "warning"
    : ["fatal", "error", "warning", "log", "info", "debug"].includes(t)
    ? t
    : "log";
}
const no = "Dedupe",
  ro = () => {
    let t;
    return {
      name: no,
      processEvent(e) {
        if (e.type) return e;
        try {
          if (oo(e, t))
            return (
              m &&
                d.warn(
                  "Event dropped due to being a duplicate of previously captured event."
                ),
              null
            );
        } catch {}
        return (t = e);
      },
    };
  },
  so = ro;
function oo(t, e) {
  return e ? !!(io(t, e) || ao(t, e)) : !1;
}
function io(t, e) {
  const n = t.message,
    r = e.message;
  return !(
    (!n && !r) ||
    (n && !r) ||
    (!n && r) ||
    n !== r ||
    !_n(t, e) ||
    !gn(t, e)
  );
}
function ao(t, e) {
  const n = Ue(e),
    r = Ue(t);
  return !(
    !n ||
    !r ||
    n.type !== r.type ||
    n.value !== r.value ||
    !_n(t, e) ||
    !gn(t, e)
  );
}
function gn(t, e) {
  let n = fe(t),
    r = fe(e);
  if (!n && !r) return !0;
  if ((n && !r) || (!n && r) || ((n = n), (r = r), r.length !== n.length))
    return !1;
  for (let s = 0; s < r.length; s++) {
    const o = r[s],
      i = n[s];
    if (
      o.filename !== i.filename ||
      o.lineno !== i.lineno ||
      o.colno !== i.colno ||
      o.function !== i.function
    )
      return !1;
  }
  return !0;
}
function _n(t, e) {
  let n = t.fingerprint,
    r = e.fingerprint;
  if (!n && !r) return !0;
  if ((n && !r) || (!n && r)) return !1;
  (n = n), (r = r);
  try {
    return n.join("") === r.join("");
  } catch {
    return !1;
  }
}
function Ue(t) {
  return t.exception && t.exception.values && t.exception.values[0];
}
function mn(t) {
  if (t !== void 0)
    return t >= 400 && t < 500 ? "warning" : t >= 500 ? "error" : void 0;
}
const jt = g;
function yn() {
  if (!("fetch" in jt)) return !1;
  try {
    return (
      new Headers(), new Request("http://www.example.com"), new Response(), !0
    );
  } catch {
    return !1;
  }
}
function Bt(t) {
  return (
    t && /^function\s+\w+\(\)\s+\{\s+\[native code\]\s+\}$/.test(t.toString())
  );
}
function co() {
  if (typeof EdgeRuntime == "string") return !0;
  if (!yn()) return !1;
  if (Bt(jt.fetch)) return !0;
  let t = !1;
  const e = jt.document;
  if (e && typeof e.createElement == "function")
    try {
      const n = e.createElement("iframe");
      (n.hidden = !0),
        e.head.appendChild(n),
        n.contentWindow &&
          n.contentWindow.fetch &&
          (t = Bt(n.contentWindow.fetch)),
        e.head.removeChild(n);
    } catch (n) {
      H &&
        d.warn(
          "Could not create sandbox iframe for pure fetch check, bailing to window.fetch: ",
          n
        );
    }
  return t;
}
function uo(t, e) {
  const n = "fetch";
  W(n, t), q(n, () => fo(void 0, e));
}
function fo(t, e = !1) {
  (e && !co()) ||
    I(g, "fetch", function (n) {
      return function (...r) {
        const s = new Error(),
          { method: o, url: i } = lo(r),
          a = {
            args: r,
            fetchData: { method: o, url: i },
            startTimestamp: D() * 1e3,
            virtualError: s,
          };
        return (
          N("fetch", { ...a }),
          n.apply(g, r).then(
            async (c) => (
              N("fetch", { ...a, endTimestamp: D() * 1e3, response: c }), c
            ),
            (c) => {
              throw (
                (N("fetch", { ...a, endTimestamp: D() * 1e3, error: c }),
                Xt(c) &&
                  c.stack === void 0 &&
                  ((c.stack = s.stack), L(c, "framesToPop", 1)),
                c)
              );
            }
          )
        );
      };
    });
}
function Ht(t, e) {
  return !!t && typeof t == "object" && !!t[e];
}
function je(t) {
  return typeof t == "string"
    ? t
    : t
    ? Ht(t, "url")
      ? t.url
      : t.toString
      ? t.toString()
      : ""
    : "";
}
function lo(t) {
  if (t.length === 0) return { method: "GET", url: "" };
  if (t.length === 2) {
    const [n, r] = t;
    return {
      url: je(n),
      method: Ht(r, "method") ? String(r.method).toUpperCase() : "GET",
    };
  }
  const e = t[0];
  return {
    url: je(e),
    method: Ht(e, "method") ? String(e.method).toUpperCase() : "GET",
  };
}
function po() {
  return "npm";
}
const ft = g;
function ho() {
  const t = ft.chrome,
    e = t && t.app && t.app.runtime,
    n = "history" in ft && !!ft.history.pushState && !!ft.history.replaceState;
  return !e && n;
}
const y = g;
let Gt = 0;
function En() {
  return Gt > 0;
}
function go() {
  Gt++,
    setTimeout(() => {
      Gt--;
    });
}
function J(t, e = {}) {
  function n(s) {
    return typeof s == "function";
  }
  if (!n(t)) return t;
  try {
    const s = t.__sentry_wrapped__;
    if (s) return typeof s == "function" ? s : t;
    if (Qt(t)) return t;
  } catch {
    return t;
  }
  const r = function (...s) {
    try {
      const o = s.map((i) => J(i, e));
      return t.apply(this, o);
    } catch (o) {
      throw (
        (go(),
        rr((i) => {
          i.addEventProcessor(
            (a) => (
              e.mechanism && (Pt(a, void 0), K(a, e.mechanism)),
              (a.extra = { ...a.extra, arguments: s }),
              a
            )
          ),
            us(o);
        }),
        o)
      );
    }
  };
  try {
    for (const s in t)
      Object.prototype.hasOwnProperty.call(t, s) && (r[s] = t[s]);
  } catch {}
  Qe(r, t), L(t, "__sentry_wrapped__", r);
  try {
    Object.getOwnPropertyDescriptor(r, "name").configurable &&
      Object.defineProperty(r, "name", {
        get() {
          return t.name;
        },
      });
  } catch {}
  return r;
}
const rt = typeof __SENTRY_DEBUG__ > "u" || __SENTRY_DEBUG__;
function se(t, e) {
  const n = oe(t, e),
    r = { type: So(e), value: bo(e) };
  return (
    n.length && (r.stacktrace = { frames: n }),
    r.type === void 0 &&
      r.value === "" &&
      (r.value = "Unrecoverable error caught"),
    r
  );
}
function _o(t, e, n, r) {
  const s = E(),
    o = s && s.getOptions().normalizeDepth,
    i = ko(e),
    a = { __serialized__: an(e, o) };
  if (i) return { exception: { values: [se(t, i)] }, extra: a };
  const c = {
    exception: {
      values: [
        {
          type: St(e) ? e.constructor.name : r ? "UnhandledRejection" : "Error",
          value: vo(e, { isUnhandledRejection: r }),
        },
      ],
    },
    extra: a,
  };
  if (n) {
    const u = oe(t, n);
    u.length && (c.exception.values[0].stacktrace = { frames: u });
  }
  return c;
}
function Rt(t, e) {
  return { exception: { values: [se(t, e)] } };
}
function oe(t, e) {
  const n = e.stacktrace || e.stack || "",
    r = yo(e),
    s = Eo(e);
  try {
    return t(n, r, s);
  } catch {}
  return [];
}
const mo = /Minified React error #\d+;/i;
function yo(t) {
  return t && mo.test(t.message) ? 1 : 0;
}
function Eo(t) {
  return typeof t.framesToPop == "number" ? t.framesToPop : 0;
}
function Sn(t) {
  return typeof WebAssembly < "u" && typeof WebAssembly.Exception < "u"
    ? t instanceof WebAssembly.Exception
    : !1;
}
function So(t) {
  const e = t && t.name;
  return !e && Sn(t)
    ? t.message && Array.isArray(t.message) && t.message.length == 2
      ? t.message[0]
      : "WebAssembly.Exception"
    : e;
}
function bo(t) {
  const e = t && t.message;
  return e
    ? e.error && typeof e.error.message == "string"
      ? e.error.message
      : Sn(t) && Array.isArray(t.message) && t.message.length == 2
      ? t.message[1]
      : e
    : "No error message";
}
function Io(t, e, n, r) {
  const s = (n && n.syntheticException) || void 0,
    o = ie(t, e, s, r);
  return (
    K(o),
    (o.level = "error"),
    n && n.event_id && (o.event_id = n.event_id),
    U(o)
  );
}
function To(t, e, n = "info", r, s) {
  const o = (r && r.syntheticException) || void 0,
    i = Wt(t, e, o, s);
  return (i.level = n), r && r.event_id && (i.event_id = r.event_id), U(i);
}
function ie(t, e, n, r, s) {
  let o;
  if (Ve(e) && e.error) return Rt(t, e.error);
  if (de(e) || Pn(e)) {
    const i = e;
    if ("stack" in e) o = Rt(t, e);
    else {
      const a = i.name || (de(i) ? "DOMError" : "DOMException"),
        c = i.message ? `${a}: ${i.message}` : a;
      (o = Wt(t, c, n, r)), Pt(o, c);
    }
    return (
      "code" in i && (o.tags = { ...o.tags, "DOMException.code": `${i.code}` }),
      o
    );
  }
  return Xt(e)
    ? Rt(t, e)
    : z(e) || St(e)
    ? ((o = _o(t, e, n, s)), K(o, { synthetic: !0 }), o)
    : ((o = Wt(t, e, n, r)), Pt(o, `${e}`), K(o, { synthetic: !0 }), o);
}
function Wt(t, e, n, r) {
  const s = {};
  if (r && n) {
    const o = oe(t, n);
    o.length &&
      (s.exception = { values: [{ value: e, stacktrace: { frames: o } }] }),
      K(s, { synthetic: !0 });
  }
  if (Vt(e)) {
    const { __sentry_template_string__: o, __sentry_template_values__: i } = e;
    return (s.logentry = { message: o, params: i }), s;
  }
  return (s.message = e), s;
}
function vo(t, { isUnhandledRejection: e }) {
  const n = Hn(t),
    r = e ? "promise rejection" : "exception";
  return Ve(t)
    ? `Event \`ErrorEvent\` captured as ${r} with message \`${t.message}\``
    : St(t)
    ? `Event \`${wo(t)}\` (type=${t.type}) captured as ${r}`
    : `Object captured as ${r} with keys: ${n}`;
}
function wo(t) {
  try {
    const e = Object.getPrototypeOf(t);
    return e ? e.constructor.name : void 0;
  } catch {}
}
function ko(t) {
  for (const e in t)
    if (Object.prototype.hasOwnProperty.call(t, e)) {
      const n = t[e];
      if (n instanceof Error) return n;
    }
}
function No(t, { metadata: e, tunnel: n, dsn: r }) {
  const s = {
      event_id: t.event_id,
      sent_at: new Date().toISOString(),
      ...(e && e.sdk && { sdk: { name: e.sdk.name, version: e.sdk.version } }),
      ...(!!n && !!r && { dsn: vt(r) }),
    },
    o = xo(t);
  return nt(s, [o]);
}
function xo(t) {
  return [{ type: "user_report" }, t];
}
class Oo extends Es {
  constructor(e) {
    const n = { parentSpanIsAlwaysRootSpan: !0, ...e },
      r = y.SENTRY_SDK_SOURCE || po();
    Cs(n, "browser", ["browser"], r),
      super(n),
      n.sendClientReports &&
        y.document &&
        y.document.addEventListener("visibilitychange", () => {
          y.document.visibilityState === "hidden" && this._flushOutcomes();
        });
  }
  eventFromException(e, n) {
    return Io(this._options.stackParser, e, n, this._options.attachStacktrace);
  }
  eventFromMessage(e, n = "info", r) {
    return To(
      this._options.stackParser,
      e,
      n,
      r,
      this._options.attachStacktrace
    );
  }
  captureUserFeedback(e) {
    if (!this._isEnabled()) {
      rt && d.warn("SDK not enabled, will not capture user feedback.");
      return;
    }
    const n = No(e, {
      metadata: this.getSdkMetadata(),
      dsn: this.getDsn(),
      tunnel: this.getOptions().tunnel,
    });
    this.sendEnvelope(n);
  }
  _prepareEvent(e, n, r) {
    return (
      (e.platform = e.platform || "javascript"), super._prepareEvent(e, n, r)
    );
  }
}
const Ro = typeof __SENTRY_DEBUG__ > "u" || __SENTRY_DEBUG__,
  b = g,
  Do = 1e3;
let Be, qt, Yt;
function Co(t) {
  W("dom", t), q("dom", Po);
}
function Po() {
  if (!b.document) return;
  const t = N.bind(null, "dom"),
    e = He(t, !0);
  b.document.addEventListener("click", e, !1),
    b.document.addEventListener("keypress", e, !1),
    ["EventTarget", "Node"].forEach((n) => {
      const s = b[n],
        o = s && s.prototype;
      !o ||
        !o.hasOwnProperty ||
        !o.hasOwnProperty("addEventListener") ||
        (I(o, "addEventListener", function (i) {
          return function (a, c, u) {
            if (a === "click" || a == "keypress")
              try {
                const l = (this.__sentry_instrumentation_handlers__ =
                    this.__sentry_instrumentation_handlers__ || {}),
                  f = (l[a] = l[a] || { refCount: 0 });
                if (!f.handler) {
                  const p = He(t);
                  (f.handler = p), i.call(this, a, p, u);
                }
                f.refCount++;
              } catch {}
            return i.call(this, a, c, u);
          };
        }),
        I(o, "removeEventListener", function (i) {
          return function (a, c, u) {
            if (a === "click" || a == "keypress")
              try {
                const l = this.__sentry_instrumentation_handlers__ || {},
                  f = l[a];
                f &&
                  (f.refCount--,
                  f.refCount <= 0 &&
                    (i.call(this, a, f.handler, u),
                    (f.handler = void 0),
                    delete l[a]),
                  Object.keys(l).length === 0 &&
                    delete this.__sentry_instrumentation_handlers__);
              } catch {}
            return i.call(this, a, c, u);
          };
        }));
    });
}
function Ao(t) {
  if (t.type !== qt) return !1;
  try {
    if (!t.target || t.target._sentryId !== Yt) return !1;
  } catch {}
  return !0;
}
function Mo(t, e) {
  return t !== "keypress"
    ? !1
    : !e || !e.tagName
    ? !0
    : !(
        e.tagName === "INPUT" ||
        e.tagName === "TEXTAREA" ||
        e.isContentEditable
      );
}
function He(t, e = !1) {
  return (n) => {
    if (!n || n._sentryCaptured) return;
    const r = $o(n);
    if (Mo(n.type, r)) return;
    L(n, "_sentryCaptured", !0), r && !r._sentryId && L(r, "_sentryId", w());
    const s = n.type === "keypress" ? "input" : n.type;
    Ao(n) ||
      (t({ event: n, name: s, global: e }),
      (qt = n.type),
      (Yt = r ? r._sentryId : void 0)),
      clearTimeout(Be),
      (Be = b.setTimeout(() => {
        (Yt = void 0), (qt = void 0);
      }, Do));
  };
}
function $o(t) {
  try {
    return t.target;
  } catch {
    return null;
  }
}
let lt;
function bn(t) {
  const e = "history";
  W(e, t), q(e, Fo);
}
function Fo() {
  if (!ho()) return;
  const t = b.onpopstate;
  b.onpopstate = function (...n) {
    const r = b.location.href,
      s = lt;
    if (((lt = r), N("history", { from: s, to: r }), t))
      try {
        return t.apply(this, n);
      } catch {}
  };
  function e(n) {
    return function (...r) {
      const s = r.length > 2 ? r[2] : void 0;
      if (s) {
        const o = lt,
          i = String(s);
        (lt = i), N("history", { from: o, to: i });
      }
      return n.apply(this, r);
    };
  }
  I(b.history, "pushState", e), I(b.history, "replaceState", e);
}
const ht = {};
function Lo(t) {
  const e = ht[t];
  if (e) return e;
  let n = b[t];
  if (Bt(n)) return (ht[t] = n.bind(b));
  const r = b.document;
  if (r && typeof r.createElement == "function")
    try {
      const s = r.createElement("iframe");
      (s.hidden = !0), r.head.appendChild(s);
      const o = s.contentWindow;
      o && o[t] && (n = o[t]), r.head.removeChild(s);
    } catch (s) {
      Ro &&
        d.warn(
          `Could not create sandbox iframe for ${t} check, bailing to window.${t}: `,
          s
        );
    }
  return n && (ht[t] = n.bind(b));
}
function Ge(t) {
  ht[t] = void 0;
}
const Q = "__sentry_xhr_v3__";
function Uo(t) {
  W("xhr", t), q("xhr", jo);
}
function jo() {
  if (!b.XMLHttpRequest) return;
  const t = XMLHttpRequest.prototype;
  (t.open = new Proxy(t.open, {
    apply(e, n, r) {
      const s = new Error(),
        o = D() * 1e3,
        i = R(r[0]) ? r[0].toUpperCase() : void 0,
        a = Bo(r[1]);
      if (!i || !a) return e.apply(n, r);
      (n[Q] = { method: i, url: a, request_headers: {} }),
        i === "POST" &&
          a.match(/sentry_key/) &&
          (n.__sentry_own_request__ = !0);
      const c = () => {
        const u = n[Q];
        if (u && n.readyState === 4) {
          try {
            u.status_code = n.status;
          } catch {}
          const l = {
            endTimestamp: D() * 1e3,
            startTimestamp: o,
            xhr: n,
            virtualError: s,
          };
          N("xhr", l);
        }
      };
      return (
        "onreadystatechange" in n && typeof n.onreadystatechange == "function"
          ? (n.onreadystatechange = new Proxy(n.onreadystatechange, {
              apply(u, l, f) {
                return c(), u.apply(l, f);
              },
            }))
          : n.addEventListener("readystatechange", c),
        (n.setRequestHeader = new Proxy(n.setRequestHeader, {
          apply(u, l, f) {
            const [p, _] = f,
              h = l[Q];
            return (
              h && R(p) && R(_) && (h.request_headers[p.toLowerCase()] = _),
              u.apply(l, f)
            );
          },
        })),
        e.apply(n, r)
      );
    },
  })),
    (t.send = new Proxy(t.send, {
      apply(e, n, r) {
        const s = n[Q];
        if (!s) return e.apply(n, r);
        r[0] !== void 0 && (s.body = r[0]);
        const o = { startTimestamp: D() * 1e3, xhr: n };
        return N("xhr", o), e.apply(n, r);
      },
    }));
}
function Bo(t) {
  if (R(t)) return t;
  try {
    return t.toString();
  } catch {}
}
function Ho(t, e = Lo("fetch")) {
  let n = 0,
    r = 0;
  function s(o) {
    const i = o.body.length;
    (n += i), r++;
    const a = {
      body: o.body,
      method: "POST",
      referrerPolicy: "origin",
      headers: t.headers,
      keepalive: n <= 6e4 && r < 15,
      ...t.fetchOptions,
    };
    if (!e) return Ge("fetch"), _t("No fetch implementation available");
    try {
      return e(t.url, a).then(
        (c) => (
          (n -= i),
          r--,
          {
            statusCode: c.status,
            headers: {
              "x-sentry-rate-limits": c.headers.get("X-Sentry-Rate-Limits"),
              "retry-after": c.headers.get("Retry-After"),
            },
          }
        )
      );
    } catch (c) {
      return Ge("fetch"), (n -= i), r--, _t(c);
    }
  }
  return Ds(t, s);
}
const Go = 30,
  Wo = 50;
function zt(t, e, n, r) {
  const s = { filename: t, function: e === "<anonymous>" ? $ : e, in_app: !0 };
  return n !== void 0 && (s.lineno = n), r !== void 0 && (s.colno = r), s;
}
const qo = /^\s*at (\S+?)(?::(\d+))(?::(\d+))\s*$/i,
  Yo =
    /^\s*at (?:(.+?\)(?: \[.+\])?|.*?) ?\((?:address at )?)?(?:async )?((?:<anonymous>|[-a-z]+:|.*bundle|\/)?.*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i,
  zo = /\((\S*)(?::(\d+))(?::(\d+))\)/,
  Ko = (t) => {
    const e = qo.exec(t);
    if (e) {
      const [, r, s, o] = e;
      return zt(r, $, +s, +o);
    }
    const n = Yo.exec(t);
    if (n) {
      if (n[2] && n[2].indexOf("eval") === 0) {
        const i = zo.exec(n[2]);
        i && ((n[2] = i[1]), (n[3] = i[2]), (n[4] = i[3]));
      }
      const [s, o] = In(n[1] || $, n[2]);
      return zt(o, s, n[3] ? +n[3] : void 0, n[4] ? +n[4] : void 0);
    }
  },
  Xo = [Go, Ko],
  Vo =
    /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:[-a-z]+)?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i,
  Jo = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i,
  Zo = (t) => {
    const e = Vo.exec(t);
    if (e) {
      if (e[3] && e[3].indexOf(" > eval") > -1) {
        const o = Jo.exec(e[3]);
        o &&
          ((e[1] = e[1] || "eval"), (e[3] = o[1]), (e[4] = o[2]), (e[5] = ""));
      }
      let r = e[3],
        s = e[1] || $;
      return (
        ([s, r] = In(s, r)),
        zt(r, s, e[4] ? +e[4] : void 0, e[5] ? +e[5] : void 0)
      );
    }
  },
  Qo = [Wo, Zo],
  ti = [Xo, Qo],
  ei = Ke(...ti),
  In = (t, e) => {
    const n = t.indexOf("safari-extension") !== -1,
      r = t.indexOf("safari-web-extension") !== -1;
    return n || r
      ? [
          t.indexOf("@") !== -1 ? t.split("@")[0] : $,
          n ? `safari-extension:${e}` : `safari-web-extension:${e}`,
        ]
      : [t, e];
  },
  dt = 1024,
  ni = "Breadcrumbs",
  ri = (t = {}) => {
    const e = {
      console: !0,
      dom: !0,
      fetch: !0,
      history: !0,
      sentry: !0,
      xhr: !0,
      ...t,
    };
    return {
      name: ni,
      setup(n) {
        e.console && Qs(ai(n)),
          e.dom && Co(ii(n, e.dom)),
          e.xhr && Uo(ci(n)),
          e.fetch && uo(ui(n)),
          e.history && bn(fi(n)),
          e.sentry && n.on("beforeSendEvent", oi(n));
      },
    };
  },
  si = ri;
function oi(t) {
  return function (n) {
    E() === t &&
      B(
        {
          category: `sentry.${
            n.type === "transaction" ? "transaction" : "event"
          }`,
          event_id: n.event_id,
          level: n.level,
          message: P(n),
        },
        { event: n }
      );
  };
}
function ii(t, e) {
  return function (r) {
    if (E() !== t) return;
    let s,
      o,
      i = typeof e == "object" ? e.serializeAttribute : void 0,
      a =
        typeof e == "object" && typeof e.maxStringLength == "number"
          ? e.maxStringLength
          : void 0;
    a &&
      a > dt &&
      (rt &&
        d.warn(
          `\`dom.maxStringLength\` cannot exceed ${dt}, but a value of ${a} was configured. Sentry will use ${dt} instead.`
        ),
      (a = dt)),
      typeof i == "string" && (i = [i]);
    try {
      const u = r.event,
        l = li(u) ? u.target : u;
      (s = Ze(l, { keyAttrs: i, maxStringLength: a })), (o = jn(l));
    } catch {
      s = "<unknown>";
    }
    if (s.length === 0) return;
    const c = { category: `ui.${r.name}`, message: s };
    o && (c.data = { "ui.component_name": o }),
      B(c, { event: r.event, name: r.name, global: r.global });
  };
}
function ai(t) {
  return function (n) {
    if (E() !== t) return;
    const r = {
      category: "console",
      data: { arguments: n.args, logger: "console" },
      level: eo(n.level),
      message: pe(n.args, " "),
    };
    if (n.level === "assert")
      if (n.args[0] === !1)
        (r.message = `Assertion failed: ${
          pe(n.args.slice(1), " ") || "console.assert"
        }`),
          (r.data.arguments = n.args.slice(1));
      else return;
    B(r, { input: n.args, level: n.level });
  };
}
function ci(t) {
  return function (n) {
    if (E() !== t) return;
    const { startTimestamp: r, endTimestamp: s } = n,
      o = n.xhr[Q];
    if (!r || !s || !o) return;
    const { method: i, url: a, status_code: c, body: u } = o,
      l = { method: i, url: a, status_code: c },
      f = { xhr: n.xhr, input: u, startTimestamp: r, endTimestamp: s },
      p = mn(c);
    B({ category: "xhr", data: l, type: "http", level: p }, f);
  };
}
function ui(t) {
  return function (n) {
    if (E() !== t) return;
    const { startTimestamp: r, endTimestamp: s } = n;
    if (
      s &&
      !(n.fetchData.url.match(/sentry_key/) && n.fetchData.method === "POST")
    )
      if (n.error) {
        const o = n.fetchData,
          i = {
            data: n.error,
            input: n.args,
            startTimestamp: r,
            endTimestamp: s,
          };
        B({ category: "fetch", data: o, level: "error", type: "http" }, i);
      } else {
        const o = n.response,
          i = { ...n.fetchData, status_code: o && o.status },
          a = {
            input: n.args,
            response: o,
            startTimestamp: r,
            endTimestamp: s,
          },
          c = mn(i.status_code);
        B({ category: "fetch", data: i, type: "http", level: c }, a);
      }
  };
}
function fi(t) {
  return function (n) {
    if (E() !== t) return;
    let r = n.from,
      s = n.to;
    const o = Ot(y.location.href);
    let i = r ? Ot(r) : void 0;
    const a = Ot(s);
    (!i || !i.path) && (i = o),
      o.protocol === a.protocol && o.host === a.host && (s = a.relative),
      o.protocol === i.protocol && o.host === i.host && (r = i.relative),
      B({ category: "navigation", data: { from: r, to: s } });
  };
}
function li(t) {
  return !!t && !!t.target;
}
const di = [
    "EventTarget",
    "Window",
    "Node",
    "ApplicationCache",
    "AudioTrackList",
    "BroadcastChannel",
    "ChannelMergerNode",
    "CryptoOperation",
    "EventSource",
    "FileReader",
    "HTMLUnknownElement",
    "IDBDatabase",
    "IDBRequest",
    "IDBTransaction",
    "KeyOperation",
    "MediaController",
    "MessagePort",
    "ModalWindow",
    "Notification",
    "SVGElementInstance",
    "Screen",
    "SharedWorker",
    "TextTrack",
    "TextTrackCue",
    "TextTrackList",
    "WebSocket",
    "WebSocketWorker",
    "Worker",
    "XMLHttpRequest",
    "XMLHttpRequestEventTarget",
    "XMLHttpRequestUpload",
  ],
  pi = "BrowserApiErrors",
  hi = (t = {}) => {
    const e = {
      XMLHttpRequest: !0,
      eventTarget: !0,
      requestAnimationFrame: !0,
      setInterval: !0,
      setTimeout: !0,
      ...t,
    };
    return {
      name: pi,
      setupOnce() {
        e.setTimeout && I(y, "setTimeout", We),
          e.setInterval && I(y, "setInterval", We),
          e.requestAnimationFrame && I(y, "requestAnimationFrame", _i),
          e.XMLHttpRequest &&
            "XMLHttpRequest" in y &&
            I(XMLHttpRequest.prototype, "send", mi);
        const n = e.eventTarget;
        n && (Array.isArray(n) ? n : di).forEach(yi);
      },
    };
  },
  gi = hi;
function We(t) {
  return function (...e) {
    const n = e[0];
    return (
      (e[0] = J(n, {
        mechanism: {
          data: { function: A(t) },
          handled: !1,
          type: "instrument",
        },
      })),
      t.apply(this, e)
    );
  };
}
function _i(t) {
  return function (e) {
    return t.apply(this, [
      J(e, {
        mechanism: {
          data: { function: "requestAnimationFrame", handler: A(t) },
          handled: !1,
          type: "instrument",
        },
      }),
    ]);
  };
}
function mi(t) {
  return function (...e) {
    const n = this;
    return (
      ["onload", "onerror", "onprogress", "onreadystatechange"].forEach((s) => {
        s in n &&
          typeof n[s] == "function" &&
          I(n, s, function (o) {
            const i = {
                mechanism: {
                  data: { function: s, handler: A(o) },
                  handled: !1,
                  type: "instrument",
                },
              },
              a = Qt(o);
            return a && (i.mechanism.data.handler = A(a)), J(o, i);
          });
      }),
      t.apply(this, e)
    );
  };
}
function yi(t) {
  const n = y[t],
    r = n && n.prototype;
  !r ||
    !r.hasOwnProperty ||
    !r.hasOwnProperty("addEventListener") ||
    (I(r, "addEventListener", function (s) {
      return function (o, i, a) {
        try {
          Ei(i) &&
            (i.handleEvent = J(i.handleEvent, {
              mechanism: {
                data: { function: "handleEvent", handler: A(i), target: t },
                handled: !1,
                type: "instrument",
              },
            }));
        } catch {}
        return s.apply(this, [
          o,
          J(i, {
            mechanism: {
              data: { function: "addEventListener", handler: A(i), target: t },
              handled: !1,
              type: "instrument",
            },
          }),
          a,
        ]);
      };
    }),
    I(r, "removeEventListener", function (s) {
      return function (o, i, a) {
        try {
          const c = i.__sentry_wrapped__;
          c && s.call(this, o, c, a);
        } catch {}
        return s.call(this, o, i, a);
      };
    }));
}
function Ei(t) {
  return typeof t.handleEvent == "function";
}
const Si = () => ({
    name: "BrowserSession",
    setupOnce() {
      if (typeof y.document > "u") {
        rt &&
          d.warn(
            "Using the `browserSessionIntegration` in non-browser environments is not supported."
          );
        return;
      }
      Oe({ ignoreDuration: !0 }),
        Re(),
        bn(({ from: t, to: e }) => {
          t !== void 0 && t !== e && (Oe({ ignoreDuration: !0 }), Re());
        });
    },
  }),
  bi = "GlobalHandlers",
  Ii = (t = {}) => {
    const e = { onerror: !0, onunhandledrejection: !0, ...t };
    return {
      name: bi,
      setupOnce() {
        Error.stackTraceLimit = 50;
      },
      setup(n) {
        e.onerror && (vi(n), qe("onerror")),
          e.onunhandledrejection && (wi(n), qe("onunhandledrejection"));
      },
    };
  },
  Ti = Ii;
function vi(t) {
  On((e) => {
    const { stackParser: n, attachStacktrace: r } = Tn();
    if (E() !== t || En()) return;
    const { msg: s, url: o, line: i, column: a, error: c } = e,
      u = xi(ie(n, c || s, void 0, r, !1), o, i, a);
    (u.level = "error"),
      un(u, {
        originalException: c,
        mechanism: { handled: !1, type: "onerror" },
      });
  });
}
function wi(t) {
  Dn((e) => {
    const { stackParser: n, attachStacktrace: r } = Tn();
    if (E() !== t || En()) return;
    const s = ki(e),
      o = Jt(s) ? Ni(s) : ie(n, s, void 0, r, !0);
    (o.level = "error"),
      un(o, {
        originalException: s,
        mechanism: { handled: !1, type: "onunhandledrejection" },
      });
  });
}
function ki(t) {
  if (Jt(t)) return t;
  try {
    if ("reason" in t) return t.reason;
    if ("detail" in t && "reason" in t.detail) return t.detail.reason;
  } catch {}
  return t;
}
function Ni(t) {
  return {
    exception: {
      values: [
        {
          type: "UnhandledRejection",
          value: `Non-Error promise rejection captured with value: ${String(
            t
          )}`,
        },
      ],
    },
  };
}
function xi(t, e, n, r) {
  const s = (t.exception = t.exception || {}),
    o = (s.values = s.values || []),
    i = (o[0] = o[0] || {}),
    a = (i.stacktrace = i.stacktrace || {}),
    c = (a.frames = a.frames || []),
    u = r,
    l = n,
    f = R(e) && e.length > 0 ? e : Un();
  return (
    c.length === 0 &&
      c.push({ colno: u, filename: f, function: $, in_app: !0, lineno: l }),
    t
  );
}
function qe(t) {
  rt && d.log(`Global Handler attached: ${t}`);
}
function Tn() {
  const t = E();
  return (
    (t && t.getOptions()) || { stackParser: () => [], attachStacktrace: !1 }
  );
}
const Oi = () => ({
    name: "HttpContext",
    preprocessEvent(t) {
      if (!y.navigator && !y.location && !y.document) return;
      const e = (t.request && t.request.url) || (y.location && y.location.href),
        { referrer: n } = y.document || {},
        { userAgent: r } = y.navigator || {},
        s = {
          ...(t.request && t.request.headers),
          ...(n && { Referer: n }),
          ...(r && { "User-Agent": r }),
        },
        o = { ...t.request, ...(e && { url: e }), headers: s };
      t.request = o;
    },
  }),
  Ri = "cause",
  Di = 5,
  Ci = "LinkedErrors",
  Pi = (t = {}) => {
    const e = t.limit || Di,
      n = t.key || Ri;
    return {
      name: Ci,
      preprocessEvent(r, s, o) {
        const i = o.getOptions();
        Js(se, i.stackParser, i.maxValueLength, n, e, r, s);
      },
    };
  },
  Ai = Pi;
function Mi(t) {
  const e = [js(), $s(), gi(), si(), Ti(), Ai(), so(), Oi()];
  return t.autoSessionTracking !== !1 && e.push(Si()), e;
}
function $i(t = {}) {
  const e = {
    defaultIntegrations: Mi(t),
    release:
      typeof __SENTRY_RELEASE__ == "string"
        ? __SENTRY_RELEASE__
        : y.SENTRY_RELEASE && y.SENTRY_RELEASE.id
        ? y.SENTRY_RELEASE.id
        : void 0,
    autoSessionTracking: !0,
    sendClientReports: !0,
  };
  return (
    t.defaultIntegrations == null && delete t.defaultIntegrations,
    { ...e, ...t }
  );
}
function Fi() {
  const t = typeof y.window < "u" && y;
  if (!t) return !1;
  const e = t.chrome ? "chrome" : "browser",
    n = t[e],
    r = n && n.runtime && n.runtime.id,
    s = (y.location && y.location.href) || "",
    o = [
      "chrome-extension:",
      "moz-extension:",
      "ms-browser-extension:",
      "safari-web-extension:",
    ],
    i = !!r && y === y.top && o.some((c) => s.startsWith(`${c}//`)),
    a = typeof t.nw < "u";
  return !!r && !i && !a;
}
function Li(t = {}) {
  const e = $i(t);
  if (!e.skipBrowserExtensionCheck && Fi()) {
    G(() => {
      console.error(
        "[Sentry] You cannot run Sentry this way in a browser extension, check: https://docs.sentry.io/platforms/javascript/best-practices/browser-extensions/"
      );
    });
    return;
  }
  rt &&
    (yn() ||
      d.warn(
        "No Fetch API detected. The Sentry SDK requires a Fetch API compatible environment to send events. Please add a Fetch API polyfill."
      ));
  const n = {
    ...e,
    stackParser: Nn(e.stackParser || ei),
    integrations: _s(e),
    transport: e.transport || Ho,
  };
  return Is(Oo, n);
}
const Ye = 0.2,
  Ui = ["NETWORK_FAILURE", "Unknown", "UNKNOWN"];
function ji(t) {
  const e = t?.originalException?.code;
  return e ? Ui.includes(e) : !1;
}
function Wi(t) {
  t &&
    (vn().log("Sentry initializing"),
    Li({
      dsn: t.dns,
      integrations: [],
      tracesSampleRate: Ye,
      sampleRate: Ye,
      dist: "1.44.1.0-rc4",
      release: "1.44.1.0-rc4",
      attachStacktrace: !0,
      environment: "prod",
      beforeSend: (e, n) => {
        if (ji(n)) return null;
        if (
          ((e.extra = { ...e.extra, platform: "crazygames" }),
          e.exception?.values !== void 0)
        ) {
          const { stacktrace: r } = e.exception.values[0];
          r?.frames &&
            r.frames.forEach((s) => {
              if (s.filename === void 0) return;
              const o = (s.filename.split(/[\\/]/).pop() || s.filename)
                .split("?")
                .shift();
              (s.filename = `app:///${o}`), (s.abs_path = `app:///${o}`);
            });
        }
        return e;
      },
    }));
}
export { Wi as default };
