!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var r = arguments[t];
          if (null != r) for (var a in r) r.hasOwnProperty(a) && (e[a] = r[a]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "54bcd5b4-645f-4c76-9a5c-4dade100e577"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-54bcd5b4-645f-4c76-9a5c-4dade100e577"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [48200, 65527],
    {
      3016: (e) => {
        e.exports = {
          divider: "Divider_divider__rv5PT",
          horizontal: "Divider_horizontal__YEZTp",
          vertical: "Divider_vertical__PF74_",
          my1: "Divider_my1__qn2V_",
          borderBlack50: "Divider_borderBlack50__1TBhI",
          marginTopSpacing: "Divider_marginTopSpacing__G3HQA",
        };
      },
      6500: (e) => {
        e.exports = {
          endSeasonContainer: "LeaderboardCountdown_endSeasonContainer__hU5ky",
          czyButton: "LeaderboardCountdown_czyButton__S8jcM",
          "czyButton--contained--purple":
            "LeaderboardCountdown_czyButton--contained--purple__pGMFc",
          "czyButton--contained--white":
            "LeaderboardCountdown_czyButton--contained--white__WTxtl",
          "czyButton--contained--grey":
            "LeaderboardCountdown_czyButton--contained--grey__dWbvq",
          "czyButton--contained--warning":
            "LeaderboardCountdown_czyButton--contained--warning__cR9f8",
          "czyButton--contained--alert":
            "LeaderboardCountdown_czyButton--contained--alert__p6Q2U",
          "czyButton--contained--success":
            "LeaderboardCountdown_czyButton--contained--success__ANZsq",
          "czyButton--contained--black":
            "LeaderboardCountdown_czyButton--contained--black__R0GmX",
          "czyButton--contained--green-gradient":
            "LeaderboardCountdown_czyButton--contained--green-gradient__ARAli",
          "czyButton--contained--animated-green-gradient":
            "LeaderboardCountdown_czyButton--contained--animated-green-gradient__s4T2V",
          "scroll-gradient": "LeaderboardCountdown_scroll-gradient__fIC4B",
          "czyButton--outlined--purple":
            "LeaderboardCountdown_czyButton--outlined--purple__5XtaV",
          "czyButton--link--purple":
            "LeaderboardCountdown_czyButton--link--purple__qJl6N",
          "czyButton--outlined--white":
            "LeaderboardCountdown_czyButton--outlined--white__AzE1k",
          "czyButton--link--white":
            "LeaderboardCountdown_czyButton--link--white__g1XSj",
          "czyButton--outlined--grey":
            "LeaderboardCountdown_czyButton--outlined--grey__T2orp",
          "czyButton--link--grey":
            "LeaderboardCountdown_czyButton--link--grey__SdaXU",
          "czyButton--outlined--warning":
            "LeaderboardCountdown_czyButton--outlined--warning__GyJ_m",
          "czyButton--link--warning":
            "LeaderboardCountdown_czyButton--link--warning__g11wd",
          "czyButton--outlined--alert":
            "LeaderboardCountdown_czyButton--outlined--alert__d4JPg",
          "czyButton--link--alert":
            "LeaderboardCountdown_czyButton--link--alert__5DoR8",
          "czyButton--outlined--success":
            "LeaderboardCountdown_czyButton--outlined--success__BSp_p",
          "czyButton--link--success":
            "LeaderboardCountdown_czyButton--link--success__Syx4B",
          "czyButton--outlined":
            "LeaderboardCountdown_czyButton--outlined__n0pa6",
          "czyButton--disabled":
            "LeaderboardCountdown_czyButton--disabled__2Cjjd",
          "czyButton--height50":
            "LeaderboardCountdown_czyButton--height50__RX9rt",
          "czyButton--height34":
            "LeaderboardCountdown_czyButton--height34__0eZtp",
          "czyButton--height28":
            "LeaderboardCountdown_czyButton--height28__di8j4",
          "czyButton--fullWidth":
            "LeaderboardCountdown_czyButton--fullWidth__ocsPU",
          "czyButton--headerIcon":
            "LeaderboardCountdown_czyButton--headerIcon__5J8hd",
          "czyButton--headerIcon--desktop":
            "LeaderboardCountdown_czyButton--headerIcon--desktop___O0Bc",
          "czyButton--headerIcon--mobile":
            "LeaderboardCountdown_czyButton--headerIcon--mobile__4c_V6",
          "czyButton--headerIcon--withLabel":
            "LeaderboardCountdown_czyButton--headerIcon--withLabel__jHa0h",
        };
      },
      8009: (e) => {
        e.exports = {
          badgeContainer: "Badge_badgeContainer__EaXpx",
          tooltip: "Badge_tooltip__58WMW",
          title: "Badge_title__4Mk6n",
        };
      },
      11787: (e, t, r) => {
        "use strict";
        r.d(t, { A: () => i });
        var a = r(6029),
          n = r(75155),
          o = r(25886),
          d = r.n(o);
        let i = () => {
          let e,
            t,
            r = (0, n.c)(2);
          return (
            r[0] === Symbol.for("react.memo_cache_sentinel")
              ? ((e = (0, a.jsxs)("g", {
                  clipPath: "url(#clip0)",
                  children: [
                    (0, a.jsx)("path", {
                      d: "M187.633 58.3368C187.983 39.5888 186.254 15.3036 176.167 3.815C173.957 1.308 171.003 0 167.545 0C161.659 0 154.285 4.0548 145.073 12.3606C131.726 6.649 115.927 3.8586 96.9562 3.8586C77.9851 3.8586 62.2087 6.649 48.8829 12.3388C39.7146 4.0548 32.3406 0 26.4545 0C23.0192 0 20.0433 1.308 17.8771 3.7932C7.81164 15.2818 6.06113 39.5016 6.41123 58.2278C2.16625 70.2832 0 84.3224 0 99.953C0 134.375 10.0873 160.099 29.9993 176.406C39.3864 184.057 50.6115 189.42 64.0029 192.581L61.2896 193.911H61.224L61.1584 193.976C60.1737 194.5 59.189 194.979 58.2044 195.481C58.0074 195.59 57.8105 195.677 57.5917 195.786C54.5283 197.312 51.3774 198.881 47.9639 200.952L47.0011 201.454L46.6291 201.65L46.279 201.89C44.6379 203.067 43.5439 204.833 43.2375 206.773C42.9312 208.67 43.3907 210.675 44.5285 212.223C45.6882 213.814 47.4825 214.904 49.43 215.166C50.6115 215.34 51.8588 215.558 53.0841 215.755C53.2592 215.776 53.4124 215.82 53.5874 215.842C56.3882 216.3 59.2547 216.757 62.2305 216.997L65.3158 217.346C66.4974 217.477 67.6352 217.586 68.7949 217.629L75.1405 217.978H75.3812C76.4097 218 77.4381 218 78.4446 218C86.6064 218 94.5055 217.411 101.901 216.256C110.632 214.948 119.407 212.506 127.984 208.997C136.561 205.465 144.526 200.931 151.725 195.524C166.276 184.254 177.545 169.386 184.372 152.447C186.735 146.649 188.617 140.392 189.974 133.874C192.621 123.737 193.934 112.314 193.934 99.9748C193.934 84.3878 191.79 70.3922 187.567 58.3586L187.633 58.3368ZM184.307 132.566C183.081 138.604 181.309 144.556 178.989 150.311C172.622 166.138 161.878 180.351 148.224 190.924C141.332 196.113 133.739 200.386 125.774 203.656C117.787 206.926 109.472 209.28 101.004 210.566C93.5209 211.743 85.9718 212.245 78.4665 212.245C77.4818 212.245 76.4972 212.245 75.5125 212.223L69.1669 211.874C68.0947 211.809 67.0444 211.722 65.9941 211.613L62.8213 211.264C59.9111 211.024 57.0447 210.544 54.1782 210.087C52.8872 209.869 51.5743 209.651 50.2833 209.476C49.4518 209.345 48.8829 208.561 49.0361 207.732C49.1017 207.296 49.3862 206.904 49.7144 206.664L50.8522 206.075C54.1344 204.07 57.2416 202.522 60.2831 201.018C61.4866 200.407 62.6901 199.819 63.8716 199.208L68.1385 197.137L75.6438 193.475C77.3068 192.625 78.926 191.84 80.5233 191.055C81.4205 190.619 82.2957 190.205 83.1491 189.769C62.4275 188.025 46.1696 182.161 33.7192 171.98C15.2294 156.851 5.84232 132.675 5.84232 100.04C5.84232 84.4968 8.00857 70.9154 12.2754 59.2742C11.9253 44.3848 12.8225 18.53 22.2752 7.7172C23.3912 6.4528 24.8134 5.9078 26.4545 5.9078C32.5157 5.9078 41.487 13.3198 47.767 19.3584C60.9833 12.9492 77.2411 9.7882 96.9781 9.7882C116.715 9.7882 132.995 12.9492 146.211 19.3802C152.491 13.3416 161.462 5.9296 167.545 5.9296V5.8642C169.208 5.8642 170.631 6.4092 171.747 7.6736C181.221 18.4864 182.097 44.4284 181.746 59.3178C185.991 70.9372 188.136 84.5186 188.136 99.9966C188.136 112.03 186.845 122.887 184.328 132.588L184.307 132.566Z",
                      fill: "#F9FAFF",
                    }),
                    (0, a.jsx)("path", {
                      d: "M139.275 53.3664C130.238 45.9762 116.387 42.3356 96.9781 42.3356C77.5694 42.3356 63.7185 45.9326 54.6815 53.3664C43.9815 62.13 38.7957 77.39 38.7957 99.953C38.7957 147.782 62.0555 157.57 96.9781 157.57C131.901 157.57 155.161 147.782 155.161 99.953C155.161 77.3682 149.931 62.13 139.275 53.3664ZM66.9569 98.8412C65.9285 98.8412 64.9001 98.4488 64.1124 97.664C62.5369 96.0944 62.5369 93.5438 64.1124 91.9742L68.8606 87.2436L64.1124 82.513C62.5369 80.9434 62.5369 78.3928 64.1124 76.8232C65.6878 75.2536 68.2479 75.2536 69.8234 76.8232L74.5717 81.5538L79.3199 76.8232C80.8954 75.2536 83.4555 75.2536 85.0309 76.8232C86.6064 78.3928 86.6064 80.9434 85.0309 82.513L80.2827 87.2436L85.0309 91.9742C86.6064 93.5438 86.6064 96.0944 85.0309 97.664C84.2432 98.4488 83.2148 98.8412 82.1864 98.8412C81.1579 98.8412 80.1295 98.4488 79.3418 97.664L74.5935 92.9334L69.8453 97.664C69.0576 98.4488 68.0291 98.8412 67.0007 98.8412H66.9569ZM120.479 127.966H118.75V132.348C118.75 138.692 114.396 143.88 109.057 143.88C103.718 143.88 99.3632 138.692 99.3632 132.348V127.966H73.6745C71.9678 127.966 70.5674 126.593 70.5674 124.87C70.5674 123.148 71.9459 121.775 73.6745 121.775H120.457C122.164 121.775 123.564 123.148 123.564 124.87C123.564 126.593 122.185 127.966 120.457 127.966H120.479ZM129.888 91.9742C131.463 93.5438 131.463 96.0944 129.888 97.664C129.1 98.4488 128.072 98.8412 127.043 98.8412C126.015 98.8412 124.986 98.4488 124.199 97.664L119.45 92.9334L114.702 97.664C113.914 98.4488 112.886 98.8412 111.857 98.8412C110.829 98.8412 109.801 98.4488 109.013 97.664C107.437 96.0944 107.437 93.5438 109.013 91.9742L113.761 87.2436L109.013 82.513C107.437 80.9434 107.437 78.3928 109.013 76.8232C110.588 75.2536 113.148 75.2536 114.724 76.8232L119.472 81.5538L124.22 76.8232C125.796 75.2536 128.356 75.2536 129.931 76.8232C131.507 78.3928 131.507 80.9434 129.931 82.513L125.183 87.2436L129.931 91.9742H129.888Z",
                      fill: "#F9FAFF",
                    }),
                  ],
                })),
                (r[0] = e))
              : (e = r[0]),
            r[1] === Symbol.for("react.memo_cache_sentinel")
              ? ((t = (0, a.jsx)("div", {
                  className: d().sizer,
                  children: (0, a.jsxs)("div", {
                    className: d().container,
                    children: [
                      (0, a.jsxs)("svg", {
                        className: d().ziggy,
                        viewBox: "0 0 194 218",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        "aria-hidden": "true",
                        children: [
                          e,
                          (0, a.jsx)("defs", {
                            children: (0, a.jsx)("clipPath", {
                              id: "clip0",
                              children: (0, a.jsx)("rect", {
                                width: "194",
                                height: "218",
                                fill: "white",
                              }),
                            }),
                          }),
                        ],
                      }),
                      (0, a.jsx)("h2", {
                        className: d().title,
                        children: "Oops",
                      }),
                      (0, a.jsx)("div", {
                        className: d().sub,
                        children: "Something went wrong",
                      }),
                    ],
                  }),
                })),
                (r[1] = t))
              : (t = r[1]),
            t
          );
        };
      },
      25886: (e) => {
        e.exports = {
          czyButton: "ErrorBoundary_czyButton__yEq_Y",
          "czyButton--contained--purple":
            "ErrorBoundary_czyButton--contained--purple__ykWrq",
          "czyButton--contained--white":
            "ErrorBoundary_czyButton--contained--white__C70Bx",
          "czyButton--contained--grey":
            "ErrorBoundary_czyButton--contained--grey__VjdZT",
          "czyButton--contained--warning":
            "ErrorBoundary_czyButton--contained--warning__lBHvt",
          "czyButton--contained--alert":
            "ErrorBoundary_czyButton--contained--alert__qaxsh",
          "czyButton--contained--success":
            "ErrorBoundary_czyButton--contained--success__oJXAL",
          "czyButton--contained--black":
            "ErrorBoundary_czyButton--contained--black__3RRxe",
          "czyButton--contained--green-gradient":
            "ErrorBoundary_czyButton--contained--green-gradient__izVF3",
          "czyButton--contained--animated-green-gradient":
            "ErrorBoundary_czyButton--contained--animated-green-gradient__8J4bb",
          "scroll-gradient": "ErrorBoundary_scroll-gradient__DRvny",
          "czyButton--outlined--purple":
            "ErrorBoundary_czyButton--outlined--purple__GK7UB",
          "czyButton--link--purple":
            "ErrorBoundary_czyButton--link--purple__vTkVF",
          "czyButton--outlined--white":
            "ErrorBoundary_czyButton--outlined--white__dEgHW",
          "czyButton--link--white":
            "ErrorBoundary_czyButton--link--white__9qFdr",
          "czyButton--outlined--grey":
            "ErrorBoundary_czyButton--outlined--grey__57tSe",
          "czyButton--link--grey": "ErrorBoundary_czyButton--link--grey__tpB6q",
          "czyButton--outlined--warning":
            "ErrorBoundary_czyButton--outlined--warning__ThXQj",
          "czyButton--link--warning":
            "ErrorBoundary_czyButton--link--warning__Uh7p_",
          "czyButton--outlined--alert":
            "ErrorBoundary_czyButton--outlined--alert__xZQFr",
          "czyButton--link--alert":
            "ErrorBoundary_czyButton--link--alert__POVzJ",
          "czyButton--outlined--success":
            "ErrorBoundary_czyButton--outlined--success__1LhZk",
          "czyButton--link--success":
            "ErrorBoundary_czyButton--link--success__Y8NUX",
          "czyButton--outlined": "ErrorBoundary_czyButton--outlined__p_qqr",
          "czyButton--disabled": "ErrorBoundary_czyButton--disabled__yg90W",
          "czyButton--height50": "ErrorBoundary_czyButton--height50__072_S",
          "czyButton--height34": "ErrorBoundary_czyButton--height34__IwOJv",
          "czyButton--height28": "ErrorBoundary_czyButton--height28__ioh4V",
          "czyButton--fullWidth": "ErrorBoundary_czyButton--fullWidth__NtDfm",
          "czyButton--headerIcon": "ErrorBoundary_czyButton--headerIcon__Tjd8X",
          "czyButton--headerIcon--desktop":
            "ErrorBoundary_czyButton--headerIcon--desktop__CgpXe",
          "czyButton--headerIcon--mobile":
            "ErrorBoundary_czyButton--headerIcon--mobile__nac5_",
          "czyButton--headerIcon--withLabel":
            "ErrorBoundary_czyButton--headerIcon--withLabel__ZDKcg",
          sizer: "ErrorBoundary_sizer__ooBC0",
          container: "ErrorBoundary_container___znrS",
          ziggy: "ErrorBoundary_ziggy__S2Cvl",
          title: "ErrorBoundary_title__CjxuH",
          sub: "ErrorBoundary_sub__hBEIi",
        };
      },
      42357: (e, t, r) => {
        "use strict";
        r.r(t), r.d(t, { default: () => _ });
        var a = r(6029),
          n = r(75155);
        r(55729);
        var o = r(59458),
          d = r(77650),
          i = r(79942),
          c = r(81930),
          l = r(8009),
          s = r.n(l);
        let _ = (e) => {
          let t,
            r,
            l,
            _,
            u,
            g,
            y,
            b,
            m,
            h = (0, n.c)(26),
            { type: B, draggable: z, size: p, addTooltip: x } = e,
            v = void 0 === p ? 43 : p;
          h[0] !== B
            ? ((t = () => {
                switch (B) {
                  case "gold":
                    return "leaderboard_gold_badge3x.png";
                  case "silver":
                    return "leaderboard_silver_badge3x.png";
                  case "bronze":
                    return "leaderboard_bronze_badge3x.png";
                  case "level_4":
                    return "leaderboard_champion_badge3x.png";
                  case "level_5":
                    return "leaderboard_master_badge3x.png";
                  case "level_6":
                    return "leaderboard_elite_badge3x.png";
                  default:
                    return "challenger.svg";
                }
              }),
              (h[0] = B),
              (h[1] = t))
            : (t = h[1]);
          let C = t;
          h[2] !== B
            ? ((r = (0, o.uw)(B, d.Ru)), (h[2] = B), (h[3] = r))
            : (r = h[3]);
          let W = r,
            L = `crazygames/leaderboard/${C()}`;
          h[4] !== v || h[5] !== L
            ? ((l = (0, c.Ay)(L, { height: v })),
              (h[4] = v),
              (h[5] = L),
              (h[6] = l))
            : (l = h[6]),
            h[7] !== v || h[8] !== L
              ? ((_ = (0, c.Wn)(L, { height: v })),
                (h[7] = v),
                (h[8] = L),
                (h[9] = _))
              : (_ = h[9]);
          let w = B || "No Badge";
          h[10] !== z ||
          h[11] !== v ||
          h[12] !== l ||
          h[13] !== _ ||
          h[14] !== w
            ? ((u = (0, a.jsx)("img", {
                src: l,
                srcSet: _,
                height: v,
                alt: w,
                draggable: z,
              })),
              (h[10] = z),
              (h[11] = v),
              (h[12] = l),
              (h[13] = _),
              (h[14] = w),
              (h[15] = u))
            : (u = h[15]);
          let f = u;
          if (!x) return f;
          h[16] !== W
            ? ((g = (0, a.jsx)("div", { className: s().title, children: W })),
              (h[16] = W),
              (h[17] = g))
            : (g = h[17]);
          let j = `common.leaderboard.rankTooltip.${B}`;
          return (
            h[18] !== j
              ? ((y = (0, a.jsx)("div", {
                  children: (0, a.jsx)(i.x6, { id: j }),
                })),
                (h[18] = j),
                (h[19] = y))
              : (y = h[19]),
            h[20] !== y || h[21] !== g
              ? ((b = (0, a.jsxs)("div", {
                  className: s().tooltip,
                  children: [g, y],
                })),
                (h[20] = y),
                (h[21] = g),
                (h[22] = b))
              : (b = h[22]),
            h[23] !== f || h[24] !== b
              ? ((m = (0, a.jsxs)("div", {
                  className: s().badgeContainer,
                  children: [f, b],
                })),
                (h[23] = f),
                (h[24] = b),
                (h[25] = m))
              : (m = h[25]),
            m
          );
        };
      },
      43112: (e, t, r) => {
        "use strict";
        function a(e, t) {
          return e._({
            id: `common.leaderboard.label.${t.toLowerCase()}`,
            message: t,
          });
        }
        r.d(t, { d: () => a });
      },
      43363: (e) => {
        e.exports = {
          modalContainer: "HighscoreRegisterModal_modalContainer__Qhr2A",
          modalContent: "HighscoreRegisterModal_modalContent__vpJgy",
          czyButton: "HighscoreRegisterModal_czyButton__C1xCg",
          "czyButton--contained--purple":
            "HighscoreRegisterModal_czyButton--contained--purple__LZnro",
          "czyButton--contained--white":
            "HighscoreRegisterModal_czyButton--contained--white__lRC8W",
          "czyButton--contained--grey":
            "HighscoreRegisterModal_czyButton--contained--grey__j4ejf",
          "czyButton--contained--warning":
            "HighscoreRegisterModal_czyButton--contained--warning__qWwMb",
          "czyButton--contained--alert":
            "HighscoreRegisterModal_czyButton--contained--alert___9XUE",
          "czyButton--contained--success":
            "HighscoreRegisterModal_czyButton--contained--success__HrALl",
          "czyButton--contained--black":
            "HighscoreRegisterModal_czyButton--contained--black__hDvcQ",
          "czyButton--contained--green-gradient":
            "HighscoreRegisterModal_czyButton--contained--green-gradient__OzG58",
          "czyButton--contained--animated-green-gradient":
            "HighscoreRegisterModal_czyButton--contained--animated-green-gradient__NlMid",
          "scroll-gradient": "HighscoreRegisterModal_scroll-gradient__AuZnU",
          "czyButton--outlined--purple":
            "HighscoreRegisterModal_czyButton--outlined--purple__5ju_I",
          "czyButton--link--purple":
            "HighscoreRegisterModal_czyButton--link--purple__Q9n5N",
          "czyButton--outlined--white":
            "HighscoreRegisterModal_czyButton--outlined--white__HS_1s",
          "czyButton--link--white":
            "HighscoreRegisterModal_czyButton--link--white__m_IEu",
          "czyButton--outlined--grey":
            "HighscoreRegisterModal_czyButton--outlined--grey__0jKYb",
          "czyButton--link--grey":
            "HighscoreRegisterModal_czyButton--link--grey__Se6aa",
          "czyButton--outlined--warning":
            "HighscoreRegisterModal_czyButton--outlined--warning__XJgNt",
          "czyButton--link--warning":
            "HighscoreRegisterModal_czyButton--link--warning__X1Nt0",
          "czyButton--outlined--alert":
            "HighscoreRegisterModal_czyButton--outlined--alert__v4zDB",
          "czyButton--link--alert":
            "HighscoreRegisterModal_czyButton--link--alert__yedAv",
          "czyButton--outlined--success":
            "HighscoreRegisterModal_czyButton--outlined--success__4Ivap",
          "czyButton--link--success":
            "HighscoreRegisterModal_czyButton--link--success__WcvsF",
          "czyButton--outlined":
            "HighscoreRegisterModal_czyButton--outlined__JC_u_",
          "czyButton--disabled":
            "HighscoreRegisterModal_czyButton--disabled__ElZWg",
          "czyButton--height50":
            "HighscoreRegisterModal_czyButton--height50__wH5Ai",
          "czyButton--height34":
            "HighscoreRegisterModal_czyButton--height34__NTy_5",
          "czyButton--height28":
            "HighscoreRegisterModal_czyButton--height28__AGLFF",
          "czyButton--fullWidth":
            "HighscoreRegisterModal_czyButton--fullWidth__9rEWm",
          "czyButton--headerIcon":
            "HighscoreRegisterModal_czyButton--headerIcon__o77a_",
          "czyButton--headerIcon--desktop":
            "HighscoreRegisterModal_czyButton--headerIcon--desktop___ftKE",
          "czyButton--headerIcon--mobile":
            "HighscoreRegisterModal_czyButton--headerIcon--mobile__8u3KT",
          "czyButton--headerIcon--withLabel":
            "HighscoreRegisterModal_czyButton--headerIcon--withLabel__1FgD6",
          badgeContainer: "HighscoreRegisterModal_badgeContainer__jcHa2",
          body: "HighscoreRegisterModal_body__JuVXE",
          buttons: "HighscoreRegisterModal_buttons__O6WOR",
        };
      },
      44194: (e, t, r) => {
        "use strict";
        r.d(t, { A: () => c });
        var a = r(6029),
          n = r(55729),
          o = r(18789),
          d = r(11787);
        class i extends n.Component {
          constructor(e) {
            super(e), (this.state = { hasError: !1 });
          }
          static getDerivedStateFromError(e) {
            return { hasError: !0 };
          }
          componentDidCatch(e, t) {
            let { services: r } = this.props;
            r.crazyAnalyticsService.trackGenericError("errorBoundary", {
              errorName: e.name,
              path: window.location.pathname,
              ...t,
            });
          }
          renderFallback() {
            let { fallback: e } = this.props;
            return e ? e(this.props) : (0, a.jsx)(d.A, {});
          }
          render() {
            return this.state.hasError
              ? this.renderFallback()
              : this.props.children;
          }
        }
        let c = (0, o.A)(i);
      },
      48200: (e, t, r) => {
        "use strict";
        r.d(t, { A: () => l });
        var a = r(6029),
          n = r(75155);
        r(55729);
        var o = r(50212),
          d = r(3016),
          i = r.n(d);
        let c = {
            default: void 0,
            black50: i().borderBlack50,
            spacing: i().marginTopSpacing,
            my1: i().my1,
          },
          l = (e) => {
            let t,
              r,
              d = (0, n.c)(6),
              { orientation: l, className: s, variant: _ } = e,
              u =
                "vertical" === (void 0 === l ? "horizontal" : l)
                  ? i().vertical
                  : i().horizontal,
              g = c[void 0 === _ ? "default" : _];
            return (
              d[0] !== s || d[1] !== u || d[2] !== g
                ? ((t = (0, o.A)(i().divider, u, g, s)),
                  (d[0] = s),
                  (d[1] = u),
                  (d[2] = g),
                  (d[3] = t))
                : (t = d[3]),
              d[4] !== t
                ? ((r = (0, a.jsx)("div", { role: "separator", className: t })),
                  (d[4] = t),
                  (d[5] = r))
                : (r = d[5]),
              r
            );
          };
      },
      56692: (e) => {
        e.exports = {
          ticker: "LeaderboardTicker_ticker__cT8fa",
          ranked: "LeaderboardTicker_ranked__auLBA",
          "new-score": "LeaderboardTicker_new-score__MkEal",
          avatar: "LeaderboardTicker_avatar__OhcNX",
          text: "LeaderboardTicker_text__p8uAc",
          score: "LeaderboardTicker_score__JOgAs",
          entering: "LeaderboardTicker_entering__d8rVQ",
          "ticker-enter": "LeaderboardTicker_ticker-enter__LThxA",
          leaving: "LeaderboardTicker_leaving__wFUAB",
          "ticker-leave": "LeaderboardTicker_ticker-leave__6PFpO",
          scrollBox: "LeaderboardTicker_scrollBox__9jjf2",
          scrollText: "LeaderboardTicker_scrollText__yuZGa",
        };
      },
      56797: () => {},
      60510: (e, t, r) => {
        "use strict";
        r.d(t, { A: () => s });
        var a = r(6029),
          n = r(75155);
        r(55729);
        var o = r(79942),
          d = r(93800),
          i = r(99703),
          c = r(6500),
          l = r.n(c);
        let s = (e) => {
          let t,
            r,
            c,
            s = (0, n.c)(6),
            { endDate: _, addLabel: u } = e,
            g = (0, i.s)(_);
          s[0] !== u || s[1] !== g
            ? ((t =
                null === g
                  ? u
                    ? (0, a.jsx)(o.x6, {
                        id: "common.carousel.leaderboards.endsIn",
                        values: { time: "…" },
                      })
                    : "…"
                  : u
                  ? (0, a.jsx)(
                      o.x6,
                      {
                        id: "common.carousel.leaderboards.endsIn",
                        values: { time: g },
                      },
                      g
                    )
                  : g),
              (s[0] = u),
              (s[1] = g),
              (s[2] = t))
            : (t = s[2]);
          let y = t;
          return (
            s[3] === Symbol.for("react.memo_cache_sentinel")
              ? ((r = (0, a.jsx)(d.A, { name: "clock" })), (s[3] = r))
              : (r = s[3]),
            s[4] !== y
              ? ((c = (0, a.jsxs)("div", {
                  className: l().endSeasonContainer,
                  children: [r, " ", y],
                })),
                (s[4] = y),
                (s[5] = c))
              : (c = s[5]),
            c
          );
        };
      },
      65527: (e, t, r) => {
        "use strict";
        let a;
        r.r(t), r.d(t, { default: () => ek });
        var n,
          o,
          d = r(6029),
          i = r(75155),
          c = r(55729),
          l = r(3948),
          s = r(98417),
          _ = r(50599),
          u = r(463),
          g = r(14886),
          y = r(11787),
          b = r(44194),
          m = r(71855),
          h = r(4230),
          B = r(28967),
          z = r(71684),
          p = r(15325),
          x = r(86381),
          v = r(59458),
          C = r(79942),
          W = r(37434),
          L = r(25312),
          w = r(33165),
          f = r(38662),
          j = r(42357),
          k = r(43363),
          S = r.n(k);
        let N = (e) => {
          let t,
            r,
            a,
            n,
            o,
            l,
            s,
            _,
            u,
            g,
            y,
            b,
            m,
            h,
            B = (0, i.c)(33),
            { newBadge: z, onIgnored: p, onLogin: x, seasonEndTime: k } = e,
            { openDrawer: N } = c.useContext(w.lv);
          B[0] !== x || B[1] !== N
            ? ((t = (e) => {
                e.preventDefault(),
                  e.stopPropagation(),
                  x(),
                  N("signIn", { clickOrigin: "highscore-register-modal" });
              }),
              (B[0] = x),
              (B[1] = N),
              (B[2] = t))
            : (t = B[2]);
          let A = t;
          B[3] !== z
            ? ((r = (0, v.Vy)(z)), (B[3] = z), (B[4] = r))
            : (r = B[4]),
            B[5] !== r
              ? ((a = (0, d.jsx)(C.x6, {
                  id: "common.leaderboard.modalRegister.topValue",
                  values: { value: r },
                })),
                (B[5] = r),
                (B[6] = a))
              : (a = B[6]);
          let R = a,
            E = k || "";
          B[7] !== E
            ? ((n = (0, L.wx)(E)), (B[7] = E), (B[8] = n))
            : (n = B[8]);
          let I = n;
          return null === z
            ? null
            : (B[9] !== z
                ? ((o = (0, d.jsx)("div", {
                    className: S().badgeContainer,
                    children: (0, d.jsx)(j.default, {
                      type: z,
                      size: 127,
                      draggable: !1,
                      addTooltip: !1,
                    }),
                  })),
                  (B[9] = z),
                  (B[10] = o))
                : (o = B[10]),
              B[11] !== z
                ? ((l = (0, v.uw)(z)), (B[11] = z), (B[12] = l))
                : (l = B[12]),
              B[13] !== l
                ? ((s = (0, d.jsx)("h2", {
                    children: (0, d.jsx)(C.x6, {
                      id: "common.leaderboard.modalRegister.title",
                      values: { badge: l },
                    }),
                  })),
                  (B[13] = l),
                  (B[14] = s))
                : (s = B[14]),
              B[15] !== I || B[16] !== R
                ? ((_ = (0, d.jsx)("div", {
                    className: S().body,
                    children: (0, d.jsx)(C.x6, {
                      id: "common.leaderboard.modalRegister.body",
                      values: { badge: R, time: I },
                    }),
                  })),
                  (B[15] = I),
                  (B[16] = R),
                  (B[17] = _))
                : (_ = B[17]),
              B[18] === Symbol.for("react.memo_cache_sentinel")
                ? ((u = (0, d.jsx)(C.x6, {
                    id: "common.leaderboard.modalRegister.btnLogin",
                  })),
                  (B[18] = u))
                : (u = B[18]),
              B[19] !== A
                ? ((g = (0, d.jsx)(W.A, {
                    variant: "contained",
                    color: "purple",
                    onClick: A,
                    height: 50,
                    children: u,
                  })),
                  (B[19] = A),
                  (B[20] = g))
                : (g = B[20]),
              B[21] === Symbol.for("react.memo_cache_sentinel")
                ? ((y = (0, d.jsx)(C.x6, {
                    id: "common.leaderboard.modalRegister.btnIgnore",
                  })),
                  (B[21] = y))
                : (y = B[21]),
              B[22] !== p
                ? ((b = (0, d.jsx)(W.A, {
                    variant: "link",
                    onClick: p,
                    height: 50,
                    children: y,
                  })),
                  (B[22] = p),
                  (B[23] = b))
                : (b = B[23]),
              B[24] !== g || B[25] !== b
                ? ((m = (0, d.jsxs)("div", {
                    className: S().buttons,
                    children: [g, b],
                  })),
                  (B[24] = g),
                  (B[25] = b),
                  (B[26] = m))
                : (m = B[26]),
              B[27] !== p ||
              B[28] !== m ||
              B[29] !== o ||
              B[30] !== s ||
              B[31] !== _
                ? ((h = (0, d.jsxs)(f.A, {
                    onClose: p,
                    contentClassName: S().modalContainer,
                    hasCloseButton: !1,
                    innerContentClassName: S().modalContent,
                    children: [o, s, _, m],
                  })),
                  (B[27] = p),
                  (B[28] = m),
                  (B[29] = o),
                  (B[30] = s),
                  (B[31] = _),
                  (B[32] = h))
                : (h = B[32]),
              h);
        };
        var A = r(50293),
          R = r(45364),
          E = r(59701),
          I = r(97429);
        let M = r(28478).A.LocalStorage,
          P = new Map();
        function T(e) {
          let t = P.get(e);
          return (
            t ||
              ((t = { guestBestBadge: "default", dismissedThisVisit: !1 }),
              P.set(e, t)),
            t
          );
        }
        function H(e, t) {
          return `czy_hs_reg_local_${t}_${e}`;
        }
        function D(e, t) {
          return (
            "default" !== e &&
            I.BADGE_ORDER.indexOf(e) < I.BADGE_ORDER.indexOf(t)
          );
        }
        function F(e) {
          let t = parseInt(M.getItem(H(e, "shown")) || "0", 10);
          return Number.isFinite(t) ? t : 0;
        }
        var O = r(7842),
          G = r(74265),
          X = r.n(G),
          J = r(97324),
          U = r(50212),
          V = r(81930),
          Z = r(46571),
          q = r(20583),
          K = r(43112),
          $ = r(77502),
          Q = r(56692),
          Y = r.n(Q);
        function ee(e, t) {
          return null === t.scoreIndex ? null : e[t.scoreIndex] ?? null;
        }
        let et = (e) => {
            let t,
              r,
              a,
              n,
              o,
              c,
              l,
              s,
              _,
              u,
              g,
              y,
              b = (0, i.c)(47),
              {
                slide: m,
                score: h,
                players: B,
                scoreLabel: z,
                isCurrent: p,
                className: x,
                onAnimationEnd: v,
                onScrollStart: W,
              } = e,
              { i18n: L } = (0, C.uB)();
            b[0] !== p || b[1] !== W || b[2] !== m.id
              ? ((t = { isScrolling: p, content: m.id, onScrollStart: W }),
                (b[0] = p),
                (b[1] = W),
                (b[2] = m.id),
                (b[3] = t))
              : (t = b[3]);
            let { containerRef: w, textRef: f } = (0, q.P)(t);
            if (!h) {
              let e, t, r, a, n;
              return (
                b[4] !== x
                  ? ((e = (0, U.A)(Y().ranked, x)), (b[4] = x), (b[5] = e))
                  : (e = b[5]),
                b[6] !== L || b[7] !== B
                  ? ((t = L._(
                      "common.carousel.leaderboards.numberPlayersRanked",
                      {
                        number: (0, Z.A)(L, B, { notation: "compact" }),
                        count: B,
                      }
                    )),
                    (b[6] = L),
                    (b[7] = B),
                    (b[8] = t))
                  : (t = b[8]),
                b[9] !== t || b[10] !== f
                  ? ((r = (0, d.jsx)("span", {
                      ref: f,
                      className: Y().scrollText,
                      children: t,
                    })),
                    (b[9] = t),
                    (b[10] = f),
                    (b[11] = r))
                  : (r = b[11]),
                b[12] !== w || b[13] !== r
                  ? ((a = (0, d.jsx)("div", {
                      ref: w,
                      className: Y().scrollBox,
                      children: r,
                    })),
                    (b[12] = w),
                    (b[13] = r),
                    (b[14] = a))
                  : (a = b[14]),
                b[15] !== v || b[16] !== e || b[17] !== a
                  ? ((n = (0, d.jsx)("div", {
                      className: e,
                      onAnimationEnd: v,
                      children: a,
                    })),
                    (b[15] = v),
                    (b[16] = e),
                    (b[17] = a),
                    (b[18] = n))
                  : (n = b[18]),
                n
              );
            }
            let { username: j, avatar: k, score: S } = h;
            b[19] !== x
              ? ((r = (0, U.A)(Y()["new-score"], x)), (b[19] = x), (b[20] = r))
              : (r = b[20]),
              b[21] !== k
                ? ((a = k
                    ? (0, d.jsx)("img", {
                        className: Y().avatar,
                        src: (0, V.Ay)(k, { width: 20, height: 20 }),
                        srcSet: (0, V.Wn)(k, { width: 20, height: 20 }),
                        alt: "",
                      })
                    : (0, d.jsx)("div", { className: Y().avatar })),
                  (b[21] = k),
                  (b[22] = a))
                : (a = b[22]),
              b[23] === Symbol.for("react.memo_cache_sentinel")
                ? ((n = (0, U.A)(Y().text, Y().scrollBox)), (b[23] = n))
                : (n = b[23]),
              b[24] !== L || b[25] !== S
                ? ((o = (0, $.Pj)(L, S)), (b[24] = L), (b[25] = S), (b[26] = o))
                : (o = b[26]),
              b[27] !== L || b[28] !== z
                ? ((c = (0, K.d)(L, z)), (b[27] = L), (b[28] = z), (b[29] = c))
                : (c = b[29]);
            let N = `${o} ${c}`;
            return (
              b[30] !== N || b[31] !== j
                ? ((l = { username: j, score: N }),
                  (b[30] = N),
                  (b[31] = j),
                  (b[32] = l))
                : (l = b[32]),
              b[33] === Symbol.for("react.memo_cache_sentinel")
                ? ((s = [
                    (0, d.jsx)("span", { className: Y().username }, "0"),
                    (0, d.jsx)("span", { className: Y().score }, "1"),
                  ]),
                  (b[33] = s))
                : (s = b[33]),
              b[34] !== l
                ? ((_ = (0, d.jsx)(C.x6, {
                    id: "common.leaderboard.playerScored",
                    values: l,
                    components: s,
                  })),
                  (b[34] = l),
                  (b[35] = _))
                : (_ = b[35]),
              b[36] !== _ || b[37] !== f
                ? ((u = (0, d.jsx)("span", {
                    ref: f,
                    className: Y().scrollText,
                    children: _,
                  })),
                  (b[36] = _),
                  (b[37] = f),
                  (b[38] = u))
                : (u = b[38]),
              b[39] !== w || b[40] !== u
                ? ((g = (0, d.jsx)("div", {
                    ref: w,
                    className: n,
                    children: u,
                  })),
                  (b[39] = w),
                  (b[40] = u),
                  (b[41] = g))
                : (g = b[41]),
              b[42] !== v || b[43] !== g || b[44] !== r || b[45] !== a
                ? ((y = (0, d.jsxs)("div", {
                    className: r,
                    onAnimationEnd: v,
                    children: [a, g],
                  })),
                  (b[42] = v),
                  (b[43] = g),
                  (b[44] = r),
                  (b[45] = a),
                  (b[46] = y))
                : (y = b[46]),
              y
            );
          },
          er = (e) => {
            let t,
              r,
              a,
              n,
              o,
              l,
              s,
              _,
              g,
              y,
              b,
              m = (0, i.c)(37),
              { gameId: h, isPreview: B, players: z, scoreLabel: p } = e,
              { recentScores: x } = (0, u.vP)(h, B);
            m[0] !== x
              ? ((t = x
                  .map((e) => {
                    let { user: t, score: r } = e;
                    return {
                      username: t.username,
                      avatar: t.avatar,
                      score: Number(r),
                    };
                  })
                  .filter((e) => {
                    let { username: t, score: r } = e;
                    return t && Number.isFinite(r);
                  })),
                (m[0] = x),
                (m[1] = t))
              : (t = m[1]);
            let v = t;
            m[2] === Symbol.for("react.memo_cache_sentinel")
              ? ((r = {
                  current: { id: 0, scoreIndex: null },
                  leaving: null,
                  lastScoreIndex: null,
                }),
                (m[2] = r))
              : (r = m[2]);
            let [C, W] = c.useState(r),
              { current: L, leaving: w } = C,
              [f, j] = c.useState(null),
              k = f?.slideId === L.id ? f.ms : 0,
              S = null !== L.scoreIndex;
            m[3] !== k || m[4] !== S || m[5] !== z || m[6] !== v.length
              ? ((a = () => {
                  var e;
                  if (0 === v.length) return;
                  let t = setTimeout(
                    () =>
                      W((e) => {
                        var t;
                        let r;
                        return (
                          (t = v.length),
                          (r =
                            null !== e.current.scoreIndex || 0 === t
                              ? null
                              : null === e.lastScoreIndex
                              ? 0
                              : (e.lastScoreIndex + 1) % t),
                          {
                            leaving: e.current,
                            current: { id: e.current.id + 1, scoreIndex: r },
                            lastScoreIndex: r ?? e.lastScoreIndex,
                          }
                        );
                      }),
                    Math.max(
                      S || (e = z) >= 0
                        ? 2e3
                        : Math.round(
                            Math.min(
                              Math.max(
                                25e3 +
                                  -(
                                    ((Math.log10(Math.max(e, 1)) -
                                      Math.log10(17)) /
                                      (Math.log10(17e3) - Math.log10(17))) *
                                    22e3
                                  ),
                                3e3
                              ),
                              3e4
                            )
                          ),
                      k
                    )
                  );
                  return () => clearTimeout(t);
                }),
                (m[3] = k),
                (m[4] = S),
                (m[5] = z),
                (m[6] = v.length),
                (m[7] = a))
              : (a = m[7]),
              m[8] !== L ||
              m[9] !== k ||
              m[10] !== S ||
              m[11] !== z ||
              m[12] !== v.length
                ? ((n = [L, S, k, z, v.length]),
                  (m[8] = L),
                  (m[9] = k),
                  (m[10] = S),
                  (m[11] = z),
                  (m[12] = v.length),
                  (m[13] = n))
                : (n = m[13]),
              c.useEffect(a, n),
              m[14] === Symbol.for("react.memo_cache_sentinel")
                ? ((o = () => W(ea)), (m[14] = o))
                : (o = m[14]);
            let N = o;
            m[15] !== L.id
              ? ((l = (e) => j({ slideId: L.id, ms: e })),
                (m[15] = L.id),
                (m[16] = l))
              : (l = m[16]);
            let A = l;
            m[17] !== w || m[18] !== z || m[19] !== p || m[20] !== v
              ? ((s =
                  w &&
                  (0, d.jsx)(
                    et,
                    {
                      slide: w,
                      score: ee(v, w),
                      players: z,
                      scoreLabel: p,
                      isCurrent: !1,
                      className: Y().leaving,
                      onAnimationEnd: N,
                    },
                    w.id
                  )),
                (m[17] = w),
                (m[18] = z),
                (m[19] = p),
                (m[20] = v),
                (m[21] = s))
              : (s = m[21]);
            let R = L.id;
            m[22] !== L || m[23] !== v
              ? ((_ = ee(v, L)), (m[22] = L), (m[23] = v), (m[24] = _))
              : (_ = m[24]);
            let E = L.id > 0 && Y().entering;
            return (
              m[25] !== E
                ? ((g = (0, U.A)(E)), (m[25] = E), (m[26] = g))
                : (g = m[26]),
              m[27] !== L ||
              m[28] !== A ||
              m[29] !== z ||
              m[30] !== p ||
              m[31] !== g ||
              m[32] !== _
                ? ((y = (0, d.jsx)(
                    et,
                    {
                      slide: L,
                      score: _,
                      players: z,
                      scoreLabel: p,
                      isCurrent: !0,
                      onScrollStart: A,
                      className: g,
                    },
                    R
                  )),
                  (m[27] = L),
                  (m[28] = A),
                  (m[29] = z),
                  (m[30] = p),
                  (m[31] = g),
                  (m[32] = _),
                  (m[33] = y))
                : (y = m[33]),
              m[34] !== y || m[35] !== s
                ? ((b = (0, d.jsxs)("div", {
                    className: Y().ticker,
                    children: [s, y],
                  })),
                  (m[34] = y),
                  (m[35] = s),
                  (m[36] = b))
                : (b = m[36]),
              b
            );
          };
        function ea(e) {
          return { ...e, leaving: null };
        }
        let en = (e) => {
          let t,
            r,
            a,
            n,
            o,
            c,
            l,
            s,
            _,
            u,
            g,
            y,
            b = (0, i.c)(28),
            { title: m, meta: h, text: B, onClick: z } = e,
            { i18n: p } = (0, C.uB)(),
            x = h && h.players > 0;
          b[0] === Symbol.for("react.memo_cache_sentinel")
            ? ((t = (0, U.A)(X().leaderboardWidgetNoRanking)),
              (r = {
                "--leaderboard-widget-no-ranking-bg": `url(${(0, V.Ay)(
                  "assets/PNG/components/leaderboard-widget/leaderboard-widget-no-reward-bg.png"
                )})`,
              }),
              (b[0] = t),
              (b[1] = r))
            : ((t = b[0]), (r = b[1]));
          let v = !h && X().onlyTitle;
          return (
            b[2] !== v
              ? ((a = (0, U.A)(v)), (b[2] = v), (b[3] = a))
              : (a = b[3]),
            b[4] !== m
              ? ((n = (0, d.jsx)("div", {
                  className: X().leaderboardWidgetNoRankingTitle,
                  children: m,
                })),
                (b[4] = m),
                (b[5] = n))
              : (n = b[5]),
            b[6] !== x || b[7] !== p || b[8] !== h
              ? ((o =
                  h &&
                  (0, d.jsx)("div", {
                    className: X().leaderboardWidgetNoRankingMeta,
                    children: x
                      ? (0, d.jsx)(er, {
                          gameId: h.gameId,
                          isPreview: h.isPreview,
                          players: h.players,
                          scoreLabel: h.scoreLabel ?? "POINTS",
                        })
                      : p._("common.leaderboard.noRankedPlayer"),
                  })),
                (b[6] = x),
                (b[7] = p),
                (b[8] = h),
                (b[9] = o))
              : (o = b[9]),
            b[10] !== a || b[11] !== n || b[12] !== o
              ? ((c = (0, d.jsxs)("div", { className: a, children: [n, o] })),
                (b[10] = a),
                (b[11] = n),
                (b[12] = o),
                (b[13] = c))
              : (c = b[13]),
            b[14] !== B
              ? ((l = (0, d.jsx)("p", {
                  className: X().leaderboardWidgetNoRankingText,
                  children: B,
                })),
                (b[14] = B),
                (b[15] = l))
              : (l = b[15]),
            b[16] === Symbol.for("react.memo_cache_sentinel")
              ? ((s = { position: "only", code: "arrow_forward" }), (b[16] = s))
              : (s = b[16]),
            b[17] !== p
              ? ((_ = p._("common.leaderboard.title")),
                (b[17] = p),
                (b[18] = _))
              : (_ = b[18]),
            b[19] !== _
              ? ((u = (0, d.jsx)(J.$, {
                  size: "xs",
                  tone: "purple",
                  icon: s,
                  label: _,
                  "data-testid": "leaderboard-widget-arrow",
                })),
                (b[19] = _),
                (b[20] = u))
              : (u = b[20]),
            b[21] !== u || b[22] !== l
              ? ((g = (0, d.jsxs)("div", { children: [l, u] })),
                (b[21] = u),
                (b[22] = l),
                (b[23] = g))
              : (g = b[23]),
            b[24] !== z || b[25] !== g || b[26] !== c
              ? ((y = (0, d.jsxs)("div", {
                  className: t,
                  style: r,
                  onClick: z,
                  children: [c, g],
                })),
                (b[24] = z),
                (b[25] = g),
                (b[26] = c),
                (b[27] = y))
              : (y = b[27]),
            y
          );
        };
        var eo = r(75651),
          ed = r(32994),
          ei = r(71237),
          ec = r(96912),
          el = r(74532),
          es = r(74564),
          e_ = r(99703),
          eu = r(69705),
          eg = r.n(eu);
        let ey = (e) => {
            let t,
              r,
              a,
              n,
              o = (0, i.c)(11),
              {
                label: c,
                number: l,
                measure: s,
                onClick: _,
                isRankProgressTarget: u,
              } = e;
            o[0] !== _
              ? ((t = (e) => {
                  _ && (e.stopPropagation(), _());
                }),
                (o[0] = _),
                (o[1] = t))
              : (t = o[1]);
            let g = t;
            o[2] !== c
              ? ((r = (0, d.jsx)("div", {
                  className: eg().label,
                  children: c,
                })),
                (o[2] = c),
                (o[3] = r))
              : (r = o[3]);
            let y = u || void 0,
              b = "rank" === s ? `#${l}` : l;
            return (
              o[4] !== y || o[5] !== b
                ? ((a = (0, d.jsx)("div", {
                    className: eg().number,
                    "data-rank-progress-target": y,
                    children: b,
                  })),
                  (o[4] = y),
                  (o[5] = b),
                  (o[6] = a))
                : (a = o[6]),
              o[7] !== g || o[8] !== r || o[9] !== a
                ? ((n = (0, d.jsxs)("div", {
                    className: eg().leaderboardWidgetNumberCard,
                    onClick: g,
                    children: [r, a],
                  })),
                  (o[7] = g),
                  (o[8] = r),
                  (o[9] = a),
                  (o[10] = n))
                : (n = o[10]),
              n
            );
          },
          eb = {
            Wrap: (e) => {
              let t,
                r,
                a = (0, i.c)(5),
                { position: n, children: o } = e,
                c = X()[`leaderboardWidgetWrap--${n}`];
              return (
                a[0] !== c
                  ? ((t = (0, U.A)(X().leaderboardWidgetWrap, c)),
                    (a[0] = c),
                    (a[1] = t))
                  : (t = a[1]),
                a[2] !== o || a[3] !== t
                  ? ((r = (0, d.jsx)("div", { className: t, children: o })),
                    (a[2] = o),
                    (a[3] = t),
                    (a[4] = r))
                  : (r = a[4]),
                r
              );
            },
            Loading: () => {
              let e,
                t = (0, i.c)(1);
              return (
                t[0] === Symbol.for("react.memo_cache_sentinel")
                  ? ((e = (0, d.jsx)("div", {
                      className: X().leaderboardWidgetLoading,
                      children: (0, d.jsx)(O.y, {
                        size: "small",
                        tone: "brand",
                      }),
                    })),
                    (t[0] = e))
                  : (e = t[0]),
                e
              );
            },
            StartingSoon: () => {
              let e,
                t,
                r,
                a,
                n = (0, i.c)(11),
                { openDrawer: o } = c.useContext(w.lv),
                { services: l } = c.useContext(z.A),
                { i18n: s } = (0, C.uB)();
              n[0] !== o || n[1] !== l.crazyAnalyticsService
                ? ((e = () => {
                    l.crazyAnalyticsService.leaderboardEvent(
                      "gamepage",
                      "draweropened"
                    ),
                      o("leaderboard");
                  }),
                  (n[0] = o),
                  (n[1] = l.crazyAnalyticsService),
                  (n[2] = e))
                : (e = n[2]);
              let _ = e;
              return (
                n[3] !== s
                  ? ((t = s._("common.leaderboard.title")),
                    (n[3] = s),
                    (n[4] = t))
                  : (t = n[4]),
                n[5] !== s
                  ? ((r = s._("common.leaderboard.startingSoonBody")),
                    (n[5] = s),
                    (n[6] = r))
                  : (r = n[6]),
                n[7] !== _ || n[8] !== t || n[9] !== r
                  ? ((a = (0, d.jsx)(en, { title: t, text: r, onClick: _ })),
                    (n[7] = _),
                    (n[8] = t),
                    (n[9] = r),
                    (n[10] = a))
                  : (a = n[10]),
                a
              );
            },
            NonParticipant: (e) => {
              let t,
                r,
                a,
                n,
                o,
                l,
                s,
                _ = (0, i.c)(23),
                {
                  gameId: u,
                  isPreview: g,
                  isGuest: y,
                  totalPlayers: b,
                  leaderboardGuide: m,
                  scoreLabel: h,
                } = e,
                { openDrawer: B } = c.useContext(w.lv),
                { services: p } = c.useContext(z.A),
                { i18n: x } = (0, C.uB)();
              _[0] !== B || _[1] !== p
                ? ((t = () => {
                    p.crazyAnalyticsService.leaderboardEvent(
                      "gamepage",
                      "draweropened"
                    ),
                      B("leaderboard");
                  }),
                  (_[0] = B),
                  (_[1] = p),
                  (_[2] = t))
                : (t = _[2]);
              let v = t;
              _[3] !== B || _[4] !== p
                ? ((r = () => {
                    p.crazyAnalyticsService.leaderboardEvent(
                      "gamepage",
                      "signinprompted"
                    ),
                      B("signIn", {
                        params: { openDrawerAfterLogin: "leaderboard" },
                        clickOrigin: "leaderboardWidget",
                      });
                  }),
                  (_[3] = B),
                  (_[4] = p),
                  (_[5] = r))
                : (r = _[5]);
              let W = r;
              _[6] !== x
                ? ((a = x._(
                    "common.leaderboard.widgetGuestBodyIncreasedProminance"
                  )),
                  (_[6] = x),
                  (_[7] = a))
                : (a = _[7]);
              let L = a;
              _[8] !== x || _[9] !== m
                ? ((n = m || x._("common.leaderboard.widgetLoggedInBody")),
                  (_[8] = x),
                  (_[9] = m),
                  (_[10] = n))
                : (n = _[10]);
              let f = n;
              _[11] !== x
                ? ((o = x._("common.leaderboard.title")),
                  (_[11] = x),
                  (_[12] = o))
                : (o = _[12]),
                _[13] !== u || _[14] !== g || _[15] !== h || _[16] !== b
                  ? ((l = {
                      gameId: u,
                      isPreview: g,
                      players: b,
                      scoreLabel: h,
                    }),
                    (_[13] = u),
                    (_[14] = g),
                    (_[15] = h),
                    (_[16] = b),
                    (_[17] = l))
                  : (l = _[17]);
              let j = y ? L : f,
                k = y ? W : v;
              return (
                _[18] !== o || _[19] !== l || _[20] !== j || _[21] !== k
                  ? ((s = (0, d.jsx)(en, {
                      title: o,
                      meta: l,
                      text: j,
                      onClick: k,
                    })),
                    (_[18] = o),
                    (_[19] = l),
                    (_[20] = j),
                    (_[21] = k),
                    (_[22] = s))
                  : (s = _[22]),
                s
              );
            },
            Participant: (e) => {
              let t,
                r,
                a,
                n,
                o,
                l,
                s,
                _,
                u,
                g,
                y,
                b,
                m,
                h,
                B,
                p,
                x,
                v,
                W,
                L,
                f,
                k,
                S,
                N,
                A,
                R,
                E,
                I,
                M,
                P,
                T,
                H,
                D,
                F,
                O,
                G,
                V,
                q = (0, i.c)(81),
                {
                  leaderboardOptions: Q,
                  leaderboardSeason: Y,
                  scoreData: ee,
                  totalPlayers: et,
                } = e,
                { scoreLabel: er } = Q,
                { endDate: ea } = Y,
                { i18n: en } = (0, C.uB)(),
                { openDrawer: eu } = c.useContext(w.lv),
                { countryCode: eg } = c.useContext(el.A),
                { services: eb } = c.useContext(z.A),
                { user: em } = ei.Jd();
              q[0] !== eg || q[1] !== em?.profile?.country
                ? ((t = em?.profile?.country
                    ? (0, eo.wE)(em?.profile?.country)
                    : eg),
                  (q[0] = eg),
                  (q[1] = em?.profile?.country),
                  (q[2] = t))
                : (t = q[2]);
              let eh = t;
              q[3] !== en || q[4] !== ee?.score
                ? ((r = (0, $.EI)(en, ee?.score) ?? (0, $.Pj)(en, 0)),
                  (q[3] = en),
                  (q[4] = ee?.score),
                  (q[5] = r))
                : (r = q[5]);
              let eB = r,
                ez = ee?.overallRank || 0;
              q[6] !== en || q[7] !== ez
                ? ((a = (0, Z.A)(en, ez)), (q[6] = en), (q[7] = ez), (q[8] = a))
                : (a = q[8]);
              let ep = a,
                ex = ee?.friendsRank || 0;
              q[9] !== en || q[10] !== ex
                ? ((n = (0, Z.A)(en, ex)),
                  (q[9] = en),
                  (q[10] = ex),
                  (q[11] = n))
                : (n = q[11]);
              let ev = n,
                eC = ee?.countryRank || 0;
              q[12] !== en || q[13] !== eC
                ? ((o = (0, Z.A)(en, eC)),
                  (q[12] = en),
                  (q[13] = eC),
                  (q[14] = o))
                : (o = q[14]);
              let eW = o,
                eL = (0, e_.s)(ea),
                ew = (0, es.B)(ee?.overallRank || 0, et),
                ef = ew?.currentBadge ?? null;
              q[15] !== eu || q[16] !== eb.crazyAnalyticsService
                ? ((l = (e) => {
                    eb.crazyAnalyticsService.leaderboardEvent(
                      "gamepage",
                      "draweropened",
                      { tab: e }
                    ),
                      eu(
                        "leaderboard",
                        e ? { params: { preselectedTab: e } } : void 0
                      );
                  }),
                  (q[15] = eu),
                  (q[16] = eb.crazyAnalyticsService),
                  (q[17] = l))
                : (l = q[17]);
              let ej = l,
                ek = ef && X()[`leaderboardWidgetParticipant--${ef}`];
              q[18] !== ek
                ? ((s = (0, U.A)(X().leaderboardWidgetParticipant, ek)),
                  (q[18] = ek),
                  (q[19] = s))
                : (s = q[19]),
                q[20] !== ej
                  ? ((_ = () => ej()), (q[20] = ej), (q[21] = _))
                  : (_ = q[21]),
                q[22] === Symbol.for("react.memo_cache_sentinel")
                  ? ((u = (0, d.jsx)("div", {
                      className: X().leaderboardWidgetParticipantTitle,
                      children: (0, d.jsx)(C.x6, {
                        id: "common.leaderboard.title",
                      }),
                    })),
                    (g = (0, U.A)(X().leaderboardWidgetParticipantEndDate)),
                    (y = (0, d.jsx)(ed.I, { size: "xsmall", name: "clock" })),
                    (q[22] = u),
                    (q[23] = g),
                    (q[24] = y))
                  : ((u = q[22]), (g = q[23]), (y = q[24]));
              let eS = eL ?? "…";
              q[25] !== eS
                ? ((b = (0, d.jsxs)("div", {
                    className: g,
                    children: [y, eS],
                  })),
                  (q[25] = eS),
                  (q[26] = b))
                : (b = q[26]),
                q[27] === Symbol.for("react.memo_cache_sentinel")
                  ? ((m = (0, d.jsx)("div", {
                      className: (0, U.A)(
                        X().leaderboardWidgetParticipantDivider,
                        X().right
                      ),
                    })),
                    (q[27] = m))
                  : (m = q[27]),
                q[28] !== b
                  ? ((h = (0, d.jsxs)("div", { children: [u, b, m] })),
                    (q[28] = b),
                    (q[29] = h))
                  : (h = q[29]),
                q[30] === Symbol.for("react.memo_cache_sentinel")
                  ? ((B = (0, d.jsx)(C.x6, {
                      id: "common.leaderboard.widgetMyScore",
                    })),
                    (q[30] = B))
                  : (B = q[30]),
                q[31] !== en || q[32] !== er
                  ? ((p = (0, K.d)(en, er)),
                    (q[31] = en),
                    (q[32] = er),
                    (q[33] = p))
                  : (p = q[33]);
              let eN = `${eB} ${p}`;
              return (
                q[34] !== eN
                  ? ((x = (0, d.jsx)("div", {
                      className: X().leaderboardWidgetParticipantScore,
                      children: (0, d.jsx)(ey, {
                        label: B,
                        measure: "score",
                        number: eN,
                      }),
                    })),
                    (q[34] = eN),
                    (q[35] = x))
                  : (x = q[35]),
                q[36] !== ef
                  ? ((v =
                      ef &&
                      (0, d.jsx)("div", {
                        className: X().leaderboardWidgetParticipantBadge,
                        children: (0, d.jsx)(j.default, { type: ef }),
                      })),
                    (q[36] = ef),
                    (q[37] = v))
                  : (v = q[37]),
                q[38] === Symbol.for("react.memo_cache_sentinel")
                  ? ((W = (0, d.jsx)("div", {
                      className: (0, U.A)(
                        X().leaderboardWidgetParticipantDivider,
                        X().right
                      ),
                    })),
                    (q[38] = W))
                  : (W = q[38]),
                q[39] !== x || q[40] !== v
                  ? ((L = (0, d.jsxs)("div", { children: [x, v, W] })),
                    (q[39] = x),
                    (q[40] = v),
                    (q[41] = L))
                  : (L = q[41]),
                q[42] === Symbol.for("react.memo_cache_sentinel")
                  ? ((f = (0, d.jsx)(C.x6, {
                      id: "common.leaderboard.widgetGlobal",
                    })),
                    (q[42] = f))
                  : (f = q[42]),
                q[43] !== ep
                  ? ((k = (0, d.jsx)(ey, {
                      label: f,
                      measure: "rank",
                      number: ep,
                      isRankProgressTarget: !0,
                    })),
                    (q[43] = ep),
                    (q[44] = k))
                  : (k = q[44]),
                q[45] === Symbol.for("react.memo_cache_sentinel")
                  ? ((S = (0, d.jsx)(C.x6, {
                      id: "common.leaderboard.widgetFriends",
                    })),
                    (q[45] = S))
                  : (S = q[45]),
                q[46] !== ej
                  ? ((N = () => ej("friends")), (q[46] = ej), (q[47] = N))
                  : (N = q[47]),
                q[48] !== ev || q[49] !== N
                  ? ((A = (0, d.jsx)(ey, {
                      label: S,
                      measure: "rank",
                      number: ev,
                      onClick: N,
                    })),
                    (q[48] = ev),
                    (q[49] = N),
                    (q[50] = A))
                  : (A = q[50]),
                q[51] === Symbol.for("react.memo_cache_sentinel")
                  ? ((R = (0, d.jsx)(C.x6, {
                      id: "common.leaderboard.widgetNational",
                    })),
                    (q[51] = R))
                  : (R = q[51]),
                q[52] !== eh
                  ? ((E = eh && (0, d.jsx)(ec.A, { code: eh })),
                    (q[52] = eh),
                    (q[53] = E))
                  : (E = q[53]),
                q[54] !== E
                  ? ((I = (0, d.jsxs)(d.Fragment, { children: [R, " ", E] })),
                    (q[54] = E),
                    (q[55] = I))
                  : (I = q[55]),
                q[56] !== ej
                  ? ((M = () => ej("country")), (q[56] = ej), (q[57] = M))
                  : (M = q[57]),
                q[58] !== eW || q[59] !== I || q[60] !== M
                  ? ((P = (0, d.jsx)(ey, {
                      label: I,
                      measure: "rank",
                      number: eW,
                      onClick: M,
                    })),
                    (q[58] = eW),
                    (q[59] = I),
                    (q[60] = M),
                    (q[61] = P))
                  : (P = q[61]),
                q[62] !== k || q[63] !== A || q[64] !== P
                  ? ((T = (0, d.jsxs)("div", {
                      className: X().leaderboardWidgetParticipantStandings,
                      children: [k, A, P],
                    })),
                    (q[62] = k),
                    (q[63] = A),
                    (q[64] = P),
                    (q[65] = T))
                  : (T = q[65]),
                q[66] === Symbol.for("react.memo_cache_sentinel")
                  ? ((H = (0, d.jsx)("div", {
                      className: (0, U.A)(
                        X().leaderboardWidgetParticipantDivider,
                        X().contained
                      ),
                    })),
                    (q[66] = H))
                  : (H = q[66]),
                q[67] === Symbol.for("react.memo_cache_sentinel")
                  ? ((D = { position: "only", code: "arrow_forward" }),
                    (q[67] = D))
                  : (D = q[67]),
                q[68] !== en
                  ? ((F = en._("common.leaderboard.title")),
                    (q[68] = en),
                    (q[69] = F))
                  : (F = q[69]),
                q[70] !== F
                  ? ((O = (0, d.jsx)(J.$, {
                      tone: "alphaWhite",
                      icon: D,
                      size: "s",
                      label: F,
                      "data-testid": "leaderboard-widget-arrow",
                    })),
                    (q[70] = F),
                    (q[71] = O))
                  : (O = q[71]),
                q[72] !== T || q[73] !== O
                  ? ((G = (0, d.jsxs)("div", { children: [T, H, O] })),
                    (q[72] = T),
                    (q[73] = O),
                    (q[74] = G))
                  : (G = q[74]),
                q[75] !== s ||
                q[76] !== _ ||
                q[77] !== h ||
                q[78] !== L ||
                q[79] !== G
                  ? ((V = (0, d.jsxs)("div", {
                      className: s,
                      onClick: _,
                      children: [h, L, G],
                    })),
                    (q[75] = s),
                    (q[76] = _),
                    (q[77] = h),
                    (q[78] = L),
                    (q[79] = G),
                    (q[80] = V))
                  : (V = q[80]),
                V
              );
            },
          };
        var em = r(48200),
          eh = r(93800),
          eB = r(60510),
          ez = r(95446),
          ep = r.n(ez);
        let ex = {
            mobile: "mobile",
            "right-column": "rightColumn",
            "under-gameframe": "underGameframe",
          },
          ev = {
            Wrap: (e) => {
              let t,
                r,
                a = (0, i.c)(6),
                { position: n, isLoading: o, children: c } = e,
                l = ep()[ex[n]],
                s = o && ep().loading;
              return (
                a[0] !== l || a[1] !== s
                  ? ((t = (0, U.A)(ep().leaderboardWidgetWrap, l, s)),
                    (a[0] = l),
                    (a[1] = s),
                    (a[2] = t))
                  : (t = a[2]),
                a[3] !== c || a[4] !== t
                  ? ((r = (0, d.jsx)("div", { className: t, children: c })),
                    (a[3] = c),
                    (a[4] = t),
                    (a[5] = r))
                  : (r = a[5]),
                r
              );
            },
            Loading: () => {
              let e,
                t = (0, i.c)(1);
              return (
                t[0] === Symbol.for("react.memo_cache_sentinel")
                  ? ((e = (0, d.jsx)("div", {
                      className: (0, U.A)(ep().leaderboardWidget, ep().loading),
                      children: (0, d.jsx)(O.y, {
                        tone: "brand",
                        size: "small",
                      }),
                    })),
                    (t[0] = e))
                  : (e = t[0]),
                e
              );
            },
            StartingSoon: () => {
              let e,
                t,
                r,
                a,
                n,
                o,
                l,
                s = (0, i.c)(10),
                { openDrawer: _ } = c.useContext(w.lv),
                { services: u } = c.useContext(z.A);
              s[0] === Symbol.for("react.memo_cache_sentinel")
                ? ((e = (0, V.Wn)(
                    "crazygames/leaderboard/leaderboard_guest_awards3x.png",
                    { width: 105 }
                  )),
                  (s[0] = e))
                : (e = s[0]);
              let g = e;
              s[1] !== _ || s[2] !== u.crazyAnalyticsService
                ? ((t = () => {
                    u.crazyAnalyticsService.leaderboardEvent(
                      "gamepage",
                      "draweropened"
                    ),
                      _("leaderboard");
                  }),
                  (s[1] = _),
                  (s[2] = u.crazyAnalyticsService),
                  (s[3] = t))
                : (t = s[3]);
              let y = t;
              return (
                s[4] === Symbol.for("react.memo_cache_sentinel")
                  ? ((r = (0, U.A)(
                      ep().leaderboardWidget,
                      ep().nonParticipantWidget,
                      ep().startingSoonWidget
                    )),
                    (s[4] = r))
                  : (r = s[4]),
                s[5] === Symbol.for("react.memo_cache_sentinel")
                  ? ((a = (0, d.jsxs)("div", {
                      className: ep().topContainer,
                      children: [
                        (0, d.jsx)("div", {
                          className: ep().leftContainer,
                          children: (0, d.jsx)("div", {
                            className: ep().titleContainer,
                            children: (0, d.jsx)(C.x6, {
                              id: "common.leaderboard.title",
                            }),
                          }),
                        }),
                        (0, d.jsx)("img", {
                          src: (0, V.Ay)(
                            "crazygames/leaderboard/leaderboard_guest_awards3x.png"
                          ),
                          srcSet: g,
                          alt: "",
                        }),
                      ],
                    })),
                    (s[5] = a))
                  : (a = s[5]),
                s[6] === Symbol.for("react.memo_cache_sentinel")
                  ? ((n = (0, d.jsx)("div", {
                      className: ep().bodyContainer,
                      children: (0, d.jsx)(C.x6, {
                        id: "common.leaderboard.startingSoonBody",
                      }),
                    })),
                    (s[6] = n))
                  : (n = s[6]),
                s[7] === Symbol.for("react.memo_cache_sentinel")
                  ? ((o = (0, d.jsxs)("div", {
                      className: ep().bottomContainer,
                      children: [
                        n,
                        (0, d.jsx)("div", {
                          className: ep().chevronContainer,
                          children: (0, d.jsx)(eh.A, { name: "chevron-right" }),
                        }),
                      ],
                    })),
                    (s[7] = o))
                  : (o = s[7]),
                s[8] !== y
                  ? ((l = (0, d.jsxs)("div", {
                      className: r,
                      onClick: y,
                      children: [a, o],
                    })),
                    (s[8] = y),
                    (s[9] = l))
                  : (l = s[9]),
                l
              );
            },
            NonParticipant: (e) => {
              let t,
                r,
                a,
                n,
                o,
                l,
                s,
                _,
                u,
                g,
                y,
                b,
                m,
                h,
                B,
                p,
                x,
                v,
                W,
                f,
                j = (0, i.c)(44),
                {
                  endOfSeason: k,
                  isGuest: S,
                  totalPlayers: N,
                  leaderboardGuide: A,
                } = e,
                { openDrawer: R } = c.useContext(w.lv),
                { services: E } = c.useContext(z.A),
                { i18n: I } = (0, C.uB)();
              j[0] === Symbol.for("react.memo_cache_sentinel")
                ? ((t = (0, V.Wn)(
                    "crazygames/leaderboard/leaderboard_guest_awards3x.png",
                    { width: 75 }
                  )),
                  (j[0] = t))
                : (t = j[0]);
              let M = t;
              j[1] !== k
                ? ((r = (0, L.wx)(k)), (j[1] = k), (j[2] = r))
                : (r = j[2]);
              let P = r;
              j[3] !== I || j[4] !== N
                ? ((a = (0, Z.A)(I, N, { notation: "compact" })),
                  (j[3] = I),
                  (j[4] = N),
                  (j[5] = a))
                : (a = j[5]);
              let T = a;
              j[6] !== R || j[7] !== E.crazyAnalyticsService
                ? ((n = () => {
                    E.crazyAnalyticsService.leaderboardEvent(
                      "gamepage",
                      "draweropened"
                    ),
                      R("leaderboard");
                  }),
                  (j[6] = R),
                  (j[7] = E.crazyAnalyticsService),
                  (j[8] = n))
                : (n = j[8]);
              let H = n;
              j[9] !== R || j[10] !== E.crazyAnalyticsService
                ? ((o = (e) => {
                    e.stopPropagation(),
                      e.preventDefault(),
                      E.crazyAnalyticsService.leaderboardEvent(
                        "gamepage",
                        "signinprompted"
                      ),
                      R("signIn", {
                        params: { openDrawerAfterLogin: "leaderboard" },
                        clickOrigin: "leaderboardWidget",
                      });
                  }),
                  (j[9] = R),
                  (j[10] = E.crazyAnalyticsService),
                  (j[11] = o))
                : (o = j[11]);
              let D = o;
              j[12] !== I || j[13] !== A
                ? ((l = A || I._("common.leaderboard.widgetLoggedInBody")),
                  (j[12] = I),
                  (j[13] = A),
                  (j[14] = l))
                : (l = j[14]);
              let F = l;
              return (
                j[15] === Symbol.for("react.memo_cache_sentinel")
                  ? ((s = (0, U.A)(
                      ep().leaderboardWidget,
                      ep().nonParticipantWidget
                    )),
                    (j[15] = s))
                  : (s = j[15]),
                j[16] === Symbol.for("react.memo_cache_sentinel")
                  ? ((_ = (0, d.jsx)("div", {
                      className: ep().titleContainer,
                      children: (0, d.jsx)(C.x6, {
                        id: "common.leaderboard.title",
                      }),
                    })),
                    (j[16] = _))
                  : (_ = j[16]),
                j[17] === Symbol.for("react.memo_cache_sentinel")
                  ? ((u = (0, d.jsx)(eh.A, { name: "users" })), (j[17] = u))
                  : (u = j[17]),
                j[18] !== T
                  ? ((g = (0, d.jsxs)("div", {
                      className: ep().usersContainer,
                      children: [u, " ", T],
                    })),
                    (j[18] = T),
                    (j[19] = g))
                  : (g = j[19]),
                j[20] !== P
                  ? ((y =
                      P &&
                      (0, d.jsxs)("div", {
                        className: ep().endSeasonContainer,
                        children: [(0, d.jsx)(eh.A, { name: "clock" }), " ", P],
                      })),
                    (j[20] = P),
                    (j[21] = y))
                  : (y = j[21]),
                j[22] !== g || j[23] !== y
                  ? ((b = (0, d.jsxs)("div", {
                      className: ep().leftContainer,
                      children: [
                        _,
                        (0, d.jsxs)("div", {
                          className: ep().subtitleContainer,
                          children: [g, y],
                        }),
                      ],
                    })),
                    (j[22] = g),
                    (j[23] = y),
                    (j[24] = b))
                  : (b = j[24]),
                j[25] === Symbol.for("react.memo_cache_sentinel")
                  ? ((m = (0, d.jsx)("img", {
                      src: (0, V.Ay)(
                        "crazygames/leaderboard/leaderboard_guest_awards3x.png"
                      ),
                      srcSet: M,
                    })),
                    (j[25] = m))
                  : (m = j[25]),
                j[26] !== b
                  ? ((h = (0, d.jsxs)("div", {
                      className: ep().topContainer,
                      children: [b, m],
                    })),
                    (j[26] = b),
                    (j[27] = h))
                  : (h = j[27]),
                j[28] !== D || j[29] !== S || j[30] !== F
                  ? ((B = S
                      ? (0, d.jsx)(C.x6, {
                          id: "common.leaderboard.widgetGuestBody",
                          values: {
                            login: (0, d.jsx)("a", {
                              onClick: D,
                              children: (0, d.jsx)(C.x6, {
                                id: "common.leaderboard.widgetGuestBodyLogIn",
                              }),
                            }),
                          },
                        })
                      : F),
                    (j[28] = D),
                    (j[29] = S),
                    (j[30] = F),
                    (j[31] = B))
                  : (B = j[31]),
                j[32] !== B
                  ? ((p = (0, d.jsx)("div", {
                      className: ep().bodyContainer,
                      children: B,
                    })),
                    (j[32] = B),
                    (j[33] = p))
                  : (p = j[33]),
                j[34] === Symbol.for("react.memo_cache_sentinel")
                  ? ((x = (0, d.jsx)(eh.A, { name: "chevron-right" })),
                    (j[34] = x))
                  : (x = j[34]),
                j[35] !== H
                  ? ((v = (0, d.jsx)("div", {
                      className: ep().chevronContainer,
                      onClick: H,
                      children: x,
                    })),
                    (j[35] = H),
                    (j[36] = v))
                  : (v = j[36]),
                j[37] !== p || j[38] !== v
                  ? ((W = (0, d.jsxs)("div", {
                      className: ep().bottomContainer,
                      children: [p, v],
                    })),
                    (j[37] = p),
                    (j[38] = v),
                    (j[39] = W))
                  : (W = j[39]),
                j[40] !== H || j[41] !== h || j[42] !== W
                  ? ((f = (0, d.jsxs)("div", {
                      className: s,
                      onClick: H,
                      children: [h, W],
                    })),
                    (j[40] = H),
                    (j[41] = h),
                    (j[42] = W),
                    (j[43] = f))
                  : (f = j[43]),
                f
              );
            },
            Participant: (e) => {
              let t,
                r,
                a,
                n,
                o,
                l,
                s,
                _,
                u,
                g,
                y,
                b,
                m,
                h,
                B,
                p,
                x,
                v,
                W,
                L,
                f,
                k,
                S,
                N,
                A,
                R,
                E,
                I,
                M,
                P,
                T,
                H,
                D,
                F,
                O,
                G,
                X,
                J = (0, i.c)(84),
                {
                  leaderboardOptions: V,
                  leaderboardSeason: q,
                  scoreData: Q,
                  totalPlayers: Y,
                } = e,
                { scoreLabel: ee } = V,
                { endDate: et } = q,
                { i18n: er } = (0, C.uB)(),
                { openDrawer: ea } = c.useContext(w.lv),
                { countryCode: en } = c.useContext(el.A),
                { services: ed } = c.useContext(z.A),
                { user: e_ } = ei.Jd();
              J[0] !== en || J[1] !== e_?.profile?.country
                ? ((t = e_?.profile?.country
                    ? (0, eo.wE)(e_?.profile?.country)
                    : en),
                  (J[0] = en),
                  (J[1] = e_?.profile?.country),
                  (J[2] = t))
                : (t = J[2]);
              let eu = t;
              J[3] !== er || J[4] !== Q?.score
                ? ((r = (0, $.EI)(er, Q?.score) ?? (0, $.Pj)(er, 0)),
                  (J[3] = er),
                  (J[4] = Q?.score),
                  (J[5] = r))
                : (r = J[5]);
              let eg = r,
                ey = Q?.overallRank || 0;
              J[6] !== er || J[7] !== ey
                ? ((a = (0, Z.A)(er, ey)), (J[6] = er), (J[7] = ey), (J[8] = a))
                : (a = J[8]);
              let eb = a,
                ez = Q?.friendsRank || 0;
              J[9] !== er || J[10] !== ez
                ? ((n = (0, Z.A)(er, ez)),
                  (J[9] = er),
                  (J[10] = ez),
                  (J[11] = n))
                : (n = J[11]);
              let ex = n,
                ev = Q?.countryRank || 0;
              J[12] !== er || J[13] !== ev
                ? ((o = (0, Z.A)(er, ev)),
                  (J[12] = er),
                  (J[13] = ev),
                  (J[14] = o))
                : (o = J[14]);
              let eC = o,
                eW = (0, es.B)(Q?.overallRank || 0, Y),
                eL = eW?.currentBadge ?? null;
              J[15] !== ea || J[16] !== ed.crazyAnalyticsService
                ? ((l = (e) => {
                    ed.crazyAnalyticsService.leaderboardEvent(
                      "gamepage",
                      "draweropened",
                      { tab: e }
                    ),
                      ea(
                        "leaderboard",
                        e ? { params: { preselectedTab: e } } : void 0
                      );
                  }),
                  (J[15] = ea),
                  (J[16] = ed.crazyAnalyticsService),
                  (J[17] = l))
                : (l = J[17]);
              let ew = l,
                ef = eL && ep()[eL];
              return (
                J[18] !== ef
                  ? ((s = (0, U.A)(
                      ep().leaderboardWidget,
                      ep().participantWidget,
                      ef
                    )),
                    (J[18] = ef),
                    (J[19] = s))
                  : (s = J[19]),
                J[20] !== ew
                  ? ((_ = () => {
                      ew();
                    }),
                    (J[20] = ew),
                    (J[21] = _))
                  : (_ = J[21]),
                J[22] === Symbol.for("react.memo_cache_sentinel")
                  ? ((u = (0, U.A)(ep().row, ep().switchDirection)),
                    (J[22] = u))
                  : (u = J[22]),
                J[23] === Symbol.for("react.memo_cache_sentinel")
                  ? ((g = (0, d.jsx)("div", {
                      className: ep().titleContainer,
                      children: (0, d.jsx)(C.x6, {
                        id: "common.leaderboard.title",
                      }),
                    })),
                    (J[23] = g))
                  : (g = J[23]),
                J[24] !== et
                  ? ((y = (0, d.jsxs)("div", {
                      className: u,
                      children: [g, (0, d.jsx)(eB.A, { endDate: et })],
                    })),
                    (J[24] = et),
                    (J[25] = y))
                  : (y = J[25]),
                J[26] === Symbol.for("react.memo_cache_sentinel")
                  ? ((b = (0, d.jsx)(em.A, {
                      className: ep().hideInRightColumn,
                      orientation: "vertical",
                    })),
                    (J[26] = b))
                  : (b = J[26]),
                J[27] === Symbol.for("react.memo_cache_sentinel")
                  ? ((m = (0, d.jsx)("div", {
                      className: ep().label,
                      children: (0, d.jsx)(C.x6, {
                        id: "common.leaderboard.widgetMyScore",
                      }),
                    })),
                    (J[27] = m))
                  : (m = J[27]),
                J[28] !== er || J[29] !== ee
                  ? ((h = (0, K.d)(er, ee)),
                    (J[28] = er),
                    (J[29] = ee),
                    (J[30] = h))
                  : (h = J[30]),
                J[31] !== eg || J[32] !== h
                  ? ((B = (0, d.jsxs)("div", {
                      children: [
                        m,
                        (0, d.jsxs)("div", {
                          className: ep().highlightedNumber,
                          children: [eg, " ", h],
                        }),
                      ],
                    })),
                    (J[31] = eg),
                    (J[32] = h),
                    (J[33] = B))
                  : (B = J[33]),
                J[34] !== eL
                  ? ((p =
                      eL &&
                      (0, d.jsx)("div", {
                        className: (0, U.A)(
                          ep().badgeContainer,
                          ep().hideUnderGameframe
                        ),
                        children: (0, d.jsx)(j.default, { type: eL }),
                      })),
                    (J[34] = eL),
                    (J[35] = p))
                  : (p = J[35]),
                J[36] !== B || J[37] !== p
                  ? ((x = (0, d.jsxs)("div", {
                      className: ep().row,
                      children: [B, p],
                    })),
                    (J[36] = B),
                    (J[37] = p),
                    (J[38] = x))
                  : (x = J[38]),
                J[39] === Symbol.for("react.memo_cache_sentinel")
                  ? ((v = (0, d.jsx)(em.A, {
                      className: ep().hideInRightColumn,
                      orientation: "vertical",
                    })),
                    (W = (0, U.A)(ep().row, ep().scoreContainerRow)),
                    (J[39] = v),
                    (J[40] = W))
                  : ((v = J[39]), (W = J[40])),
                J[41] !== eL
                  ? ((L =
                      eL &&
                      (0, d.jsx)("div", {
                        className: (0, U.A)(
                          ep().badgeContainer,
                          ep().hideInRightColumn
                        ),
                        children: (0, d.jsx)(j.default, { type: eL }),
                      })),
                    (J[41] = eL),
                    (J[42] = L))
                  : (L = J[42]),
                J[43] === Symbol.for("react.memo_cache_sentinel")
                  ? ((f = (0, d.jsx)("div", {
                      className: ep().label,
                      children: (0, d.jsx)(C.x6, {
                        id: "common.leaderboard.widgetGlobal",
                      }),
                    })),
                    (J[43] = f))
                  : (f = J[43]),
                J[44] !== eb
                  ? ((k = (0, d.jsxs)("div", {
                      children: [
                        f,
                        (0, d.jsxs)("div", {
                          className: ep().highlightedNumber,
                          children: ["#", eb],
                        }),
                      ],
                    })),
                    (J[44] = eb),
                    (J[45] = k))
                  : (k = J[45]),
                J[46] !== ew
                  ? ((S = (e) => {
                      e.preventDefault(), e.stopPropagation(), ew("friends");
                    }),
                    (J[46] = ew),
                    (J[47] = S))
                  : (S = J[47]),
                J[48] === Symbol.for("react.memo_cache_sentinel")
                  ? ((N = (0, d.jsx)("div", {
                      className: ep().label,
                      children: (0, d.jsx)(C.x6, {
                        id: "common.leaderboard.widgetFriends",
                      }),
                    })),
                    (J[48] = N))
                  : (N = J[48]),
                J[49] !== ex
                  ? ((A = (0, d.jsxs)("div", {
                      className: ep().highlightedNumber,
                      children: ["#", ex],
                    })),
                    (J[49] = ex),
                    (J[50] = A))
                  : (A = J[50]),
                J[51] !== S || J[52] !== A
                  ? ((R = (0, d.jsxs)("div", { onClick: S, children: [N, A] })),
                    (J[51] = S),
                    (J[52] = A),
                    (J[53] = R))
                  : (R = J[53]),
                J[54] !== ew
                  ? ((E = (e) => {
                      e.preventDefault(), e.stopPropagation(), ew("country");
                    }),
                    (J[54] = ew),
                    (J[55] = E))
                  : (E = J[55]),
                J[56] === Symbol.for("react.memo_cache_sentinel")
                  ? ((I = (0, d.jsx)(C.x6, {
                      id: "common.leaderboard.widgetNational",
                    })),
                    (J[56] = I))
                  : (I = J[56]),
                J[57] !== eu
                  ? ((M = eu && (0, d.jsx)(ec.A, { code: eu })),
                    (J[57] = eu),
                    (J[58] = M))
                  : (M = J[58]),
                J[59] !== M
                  ? ((P = (0, d.jsxs)("div", {
                      className: ep().label,
                      children: [I, " ", M],
                    })),
                    (J[59] = M),
                    (J[60] = P))
                  : (P = J[60]),
                J[61] !== eC
                  ? ((T = (0, d.jsxs)("div", {
                      className: ep().highlightedNumber,
                      children: ["#", eC],
                    })),
                    (J[61] = eC),
                    (J[62] = T))
                  : (T = J[62]),
                J[63] !== E || J[64] !== P || J[65] !== T
                  ? ((H = (0, d.jsxs)("div", { onClick: E, children: [P, T] })),
                    (J[63] = E),
                    (J[64] = P),
                    (J[65] = T),
                    (J[66] = H))
                  : (H = J[66]),
                J[67] !== ew
                  ? ((D = (e) => {
                      e.stopPropagation(), ew();
                    }),
                    (J[67] = ew),
                    (J[68] = D))
                  : (D = J[68]),
                J[69] === Symbol.for("react.memo_cache_sentinel")
                  ? ((F = (0, d.jsx)(eh.A, { name: "chevron-right" })),
                    (J[69] = F))
                  : (F = J[69]),
                J[70] !== D
                  ? ((O = (0, d.jsx)("div", {
                      className: ep().chevronContainer,
                      onClick: D,
                      children: F,
                    })),
                    (J[70] = D),
                    (J[71] = O))
                  : (O = J[71]),
                J[72] !== L ||
                J[73] !== k ||
                J[74] !== R ||
                J[75] !== H ||
                J[76] !== O
                  ? ((G = (0, d.jsxs)("div", {
                      className: W,
                      children: [L, k, R, H, O],
                    })),
                    (J[72] = L),
                    (J[73] = k),
                    (J[74] = R),
                    (J[75] = H),
                    (J[76] = O),
                    (J[77] = G))
                  : (G = J[77]),
                J[78] !== s ||
                J[79] !== _ ||
                J[80] !== y ||
                J[81] !== x ||
                J[82] !== G
                  ? ((X = (0, d.jsxs)("div", {
                      className: s,
                      onClick: _,
                      children: [y, b, x, v, G],
                    })),
                    (J[78] = s),
                    (J[79] = _),
                    (J[80] = y),
                    (J[81] = x),
                    (J[82] = G),
                    (J[83] = X))
                  : (X = J[83]),
                X
              );
            },
          };
        function eC() {
          return "enabled" === (0, m.U)("czyExpIncreasedLeaderboardProminance")
            ? eb
            : ev;
        }
        let eW = null,
          eL = !1,
          ew = 0,
          ef = null,
          ej = (e) => {
            let t,
              r,
              a = (0, i.c)(4),
              { position: n } = e,
              { Wrap: o } = eC();
            return (
              a[0] === Symbol.for("react.memo_cache_sentinel")
                ? ((t = (0, d.jsx)(y.A, {})), (a[0] = t))
                : (t = a[0]),
              a[1] !== o || a[2] !== n
                ? ((r = (0, d.jsx)(o, { position: n, children: t })),
                  (a[1] = o),
                  (a[2] = n),
                  (a[3] = r))
                : (r = a[3]),
              r
            );
          },
          ek =
            ((n = (e) => {
              let t,
                r,
                a,
                n,
                o,
                y,
                b,
                m,
                v,
                C,
                W,
                L,
                w,
                f,
                j,
                k,
                S,
                I,
                P = (0, i.c)(74),
                { game: O, position: G } = e,
                {
                  Wrap: X,
                  Loading: J,
                  StartingSoon: U,
                  NonParticipant: V,
                  Participant: Z,
                } = eC(),
                { user: q, loadingUser: K } = c.useContext(g.R),
                $ = c.useContext(h.A),
                { services: Q } = c.useContext(z.A),
                Y = c.useContext(h.A),
                ee = c.useRef(null),
                et = c.useRef(void 0),
                er = c.useRef(!1),
                {
                  id: ea,
                  isPreview: en,
                  leaderboardOptions: eo,
                  leaderboardGuide: ed,
                } = O;
              P[0] !== ea
                ? ((t = () => {
                    eW !== ea && ((eW = ea), (eL = !1), (ef = null));
                  }),
                  (r = [ea]),
                  (P[0] = ea),
                  (P[1] = t),
                  (P[2] = r))
                : ((t = P[1]), (r = P[2])),
                c.useEffect(t, r),
                P[3] === Symbol.for("react.memo_cache_sentinel")
                  ? ((a = []), (P[3] = a))
                  : (a = P[3]),
                c.useEffect(eN, a),
                P[4] === Symbol.for("react.memo_cache_sentinel")
                  ? ((n = { fetchPolicy: "cache-and-network" }), (P[4] = n))
                  : (n = P[4]);
              let [ei, ec] = (0, l._)(x.B8, n),
                { called: el, data: es, loading: e_, refetch: eu } = ec,
                [eg, ey] = (0, l._)(p.Op),
                { data: eb, loading: em } = ey,
                { totalPlayers: eh, loading: eB } = (0, u.O_)(ea);
              P[5] !== ea ||
              P[6] !== ei ||
              P[7] !== en ||
              P[8] !== q ||
              P[9] !== el
                ? ((o = () => {
                    q &&
                      !el &&
                      ea &&
                      ei({ variables: { gameIds: [ea], isPreview: en } });
                  }),
                  (y = [q, el, ea, en, ei]),
                  (P[5] = ea),
                  (P[6] = ei),
                  (P[7] = en),
                  (P[8] = q),
                  (P[9] = el),
                  (P[10] = o),
                  (P[11] = y))
                : ((o = P[10]), (y = P[11])),
                c.useEffect(o, y),
                P[12] !== ea || P[13] !== eg || P[14] !== en
                  ? ((m = () => {
                      ea && eg({ variables: { gameId: ea, isPreview: en } });
                    }),
                    (b = [ea, en, eg]),
                    (P[12] = ea),
                    (P[13] = eg),
                    (P[14] = en),
                    (P[15] = b),
                    (P[16] = m))
                  : ((b = P[15]), (m = P[16])),
                c.useEffect(m, b);
              let ez = es?.me.currentSeasonScoresForGames[0];
              P[17] !== ez
                ? ((v = (0, s.O)(ez) ? parseFloat(ez.score) : 0),
                  (P[17] = ez),
                  (P[18] = v))
                : (v = P[18]);
              let ep = v;
              P[19] !== ez?.score || P[20] !== eu
                ? ((C = () => {
                    (et.current = ez?.score), (er.current = !0), eu();
                  }),
                  (P[19] = ez?.score),
                  (P[20] = eu),
                  (P[21] = C))
                : (C = P[21]),
                ez?.score;
              let ex = C;
              (0, _.Lx)("backendScoreSubmission", ex),
                P[22] !== ez ||
                P[23] !== e_ ||
                P[24] !== Q.crazyAnalyticsService
                  ? ((W = () => {
                      !er.current ||
                        e_ ||
                        ((er.current = !1),
                        ez &&
                          ez.score !== et.current &&
                          ef !== ez.score &&
                          ((ef = ez.score),
                          Q.crazyAnalyticsService.leaderboardEvent(
                            "gamepage",
                            "scoreupdated",
                            {
                              score: {
                                value: parseFloat(ez.score),
                                globalRank: ez.overallRank,
                                countryRank: ez.countryRank,
                                friendsRank: ez.friendsRank,
                              },
                            }
                          )));
                    }),
                    (L = [ez, e_, Q.crazyAnalyticsService]),
                    (P[22] = ez),
                    (P[23] = e_),
                    (P[24] = Q.crazyAnalyticsService),
                    (P[25] = W),
                    (P[26] = L))
                  : ((W = P[25]), (L = P[26])),
                c.useEffect(W, L),
                P[27] !== Y ||
                P[28] !== eo?.scoreSorting ||
                P[29] !== ep ||
                P[30] !== e_ ||
                P[31] !== el
                  ? ((w = () => {
                      if (el && !e_) {
                        if (null === ee.current) {
                          ee.current = ep;
                          return;
                        }
                        ep !== ee.current &&
                          ((eo?.scoreSorting === "DESC" &&
                            ep > (ee.current || 0)) ||
                            (eo?.scoreSorting === "ASC" &&
                              ep < (ee.current || 0))) &&
                          ((ee.current = ep), (0, B.A)(Y, !0));
                      }
                    }),
                    (P[27] = Y),
                    (P[28] = eo?.scoreSorting),
                    (P[29] = ep),
                    (P[30] = e_),
                    (P[31] = el),
                    (P[32] = w))
                  : (w = P[32]);
              let ev = eo?.scoreSorting;
              P[33] !== Y ||
              P[34] !== ep ||
              P[35] !== e_ ||
              P[36] !== ev ||
              P[37] !== el
                ? ((f = [Y, ev, ep, el, e_]),
                  (P[33] = Y),
                  (P[34] = ep),
                  (P[35] = e_),
                  (P[36] = ev),
                  (P[37] = el),
                  (P[38] = f))
                : (f = P[38]),
                c.useEffect(w, f);
              let ew = ez?.overallRank !== null && ez?.overallRank !== void 0,
                ej = !!eo,
                ek = !!eb?.currentLeaderboardSeason,
                eS = K || e_ || em || eB,
                eA = !eS && !!eo && ek,
                eR = eb?.currentLeaderboardSeason?.endDate
                  ? eb.currentLeaderboardSeason.endDate
                  : null,
                eE = !eS && ek && ej && (!q || !ew),
                eI = !eS && ek && ej && !eE && ew,
                eM = !eS && !ek && !eE && !eI;
              P[39] !== eA ||
              P[40] !== $ ||
              P[41] !== ea ||
              P[42] !== G ||
              P[43] !== q
                ? ((j = {
                    gameId: ea,
                    position: G,
                    user: q,
                    basicConditionToDisplayLeaderboard: eA,
                    deviceInfo: $,
                  }),
                  (P[39] = eA),
                  (P[40] = $),
                  (P[41] = ea),
                  (P[42] = G),
                  (P[43] = q),
                  (P[44] = j))
                : (j = P[44]);
              let {
                showRegisterModal: eP,
                modalBadge: eT,
                onModalIgnored: eH,
                onModalLogin: eD,
              } = (function (e) {
                let {
                    gameId: t,
                    position: r,
                    user: a,
                    basicConditionToDisplayLeaderboard: n,
                    deviceInfo: o,
                  } = e,
                  { gamesPlayedService: d, crazyAnalyticsService: i } =
                    c.useContext(z.A).services,
                  [l, s] = c.useState(!1),
                  [_, u] = c.useState(null),
                  g = "right-column" !== r,
                  [y, b] = c.useState(a);
                a !== y && (b(a), a && s(!1));
                let m = c.useRef({
                  user: a,
                  basicConditionToDisplayLeaderboard: n,
                  deviceInfo: o,
                });
                c.useEffect(() => {
                  m.current = {
                    user: a,
                    basicConditionToDisplayLeaderboard: n,
                    deviceInfo: o,
                  };
                }, [a, n, o]),
                  c.useEffect(() => {
                    if (g)
                      return (0, E.S)((e) => {
                        var r;
                        if (e.gameId !== t) return;
                        let a = m.current;
                        if (
                          a.user ||
                          !a.basicConditionToDisplayLeaderboard ||
                          ((0, A.xl)(a.deviceInfo) &&
                            (R.A.isFullscreen() || R.A.isFakeFullscreen())) ||
                          !(function (e, t) {
                            let r;
                            if (F(e) >= 5 || T(e).dismissedThisVisit) return !1;
                            let a = Number.isFinite(
                              (r = parseInt(
                                M.getItem(H(e, "dismiss_at")) || "",
                                10
                              ))
                            )
                              ? r
                              : null;
                            return null === a || !(t - a < 864e5);
                          })(t, Date.now())
                        )
                          return;
                        let n = T(t).guestBestBadge,
                          o =
                            window.location.search.includes(
                              "forceHighscoreRegisterPlaytime"
                            ) || d.getTotalPlayTimeFromLS() >= 9e5,
                          c = (function (e) {
                            var t;
                            let r = e.awardId ?? "default",
                              a = D((t = e.prevSessionBestBadge), r) ? t : r;
                            return (D(r, e.prevSessionBestBadge) &&
                              "default" !== r) ||
                              (e.playtimeMet && e.awardId)
                              ? {
                                  mergedSessionBest: a,
                                  openModal: !0,
                                  badgeForModal: e.awardId,
                                }
                              : {
                                  mergedSessionBest: a,
                                  openModal: !1,
                                  badgeForModal: null,
                                };
                          })({
                            awardId: e.awardId,
                            prevSessionBestBadge: n,
                            playtimeMet: o,
                          });
                        (r = c.mergedSessionBest),
                          (T(t).guestBestBadge = r),
                          c.openModal &&
                            (M.setItem(H(t, "shown"), String(F(t) + 1)),
                            i.notificationActionEvent(
                              "leaderboard-register-nudge",
                              "shown"
                            ),
                            u(c.badgeForModal),
                            s(!0));
                      });
                  }, [i, t, d, g]);
                let h = c.useCallback(() => {
                  var e;
                  (T(t).dismissedThisVisit = !0),
                    (e = Date.now()),
                    M.setItem(H(t, "dismiss_at"), String(e)),
                    i.notificationActionEvent(
                      "leaderboard-register-nudge",
                      "ignored"
                    ),
                    s(!1);
                }, [i, t]);
                return {
                  showRegisterModal: g && l,
                  modalBadge: _,
                  onModalIgnored: h,
                  onModalLogin: c.useCallback(() => {
                    i.notificationActionEvent(
                      "leaderboard-register-nudge",
                      "clicked"
                    ),
                      s(!1);
                  }, [i]),
                };
              })(j);
              return (
                P[45] !== eA || P[46] !== Q.crazyAnalyticsService
                  ? ((k = () => {
                      eA &&
                        !eL &&
                        (Q.crazyAnalyticsService.leaderboardEvent(
                          "gamepage",
                          "widgetviewed"
                        ),
                        (eL = !0));
                    }),
                    (S = [eA, Q.crazyAnalyticsService]),
                    (P[45] = eA),
                    (P[46] = Q.crazyAnalyticsService),
                    (P[47] = k),
                    (P[48] = S))
                  : ((k = P[47]), (S = P[48])),
                c.useEffect(k, S),
                P[49] !== J ||
                P[50] !== V ||
                P[51] !== Z ||
                P[52] !== U ||
                P[53] !== X ||
                P[54] !== eE ||
                P[55] !== eI ||
                P[56] !== eM ||
                P[57] !== ej ||
                P[58] !== eR ||
                P[59] !== ea ||
                P[60] !== eS ||
                P[61] !== en ||
                P[62] !== ez ||
                P[63] !== ed ||
                P[64] !== eb ||
                P[65] !== eo ||
                P[66] !== eT ||
                P[67] !== eH ||
                P[68] !== eD ||
                P[69] !== G ||
                P[70] !== eP ||
                P[71] !== eh ||
                P[72] !== q
                  ? ((I = ej
                      ? (0, d.jsxs)(d.Fragment, {
                          children: [
                            eP &&
                              (0, d.jsx)(N, {
                                newBadge: eT,
                                onIgnored: eH,
                                onLogin: eD,
                                seasonEndTime:
                                  eb?.currentLeaderboardSeason?.endDate || "",
                              }),
                            (0, d.jsxs)(X, {
                              position: G,
                              isLoading: eS,
                              children: [
                                eS && (0, d.jsx)(J, {}),
                                eM && (0, d.jsx)(U, {}),
                                eE &&
                                  eR &&
                                  (0, d.jsx)(V, {
                                    gameId: ea,
                                    isPreview: en,
                                    leaderboardGuide: ed || void 0,
                                    endOfSeason: eR,
                                    isGuest: !q,
                                    totalPlayers: eh || 0,
                                    scoreLabel: eo?.scoreLabel,
                                  }),
                                eI &&
                                  eo &&
                                  eb.currentLeaderboardSeason &&
                                  (0, d.jsx)(Z, {
                                    scoreData: ez,
                                    leaderboardOptions: eo,
                                    leaderboardSeason:
                                      eb.currentLeaderboardSeason,
                                    totalPlayers: eh || 0,
                                  }),
                              ],
                            }),
                          ],
                        })
                      : null),
                    (P[49] = J),
                    (P[50] = V),
                    (P[51] = Z),
                    (P[52] = U),
                    (P[53] = X),
                    (P[54] = eE),
                    (P[55] = eI),
                    (P[56] = eM),
                    (P[57] = ej),
                    (P[58] = eR),
                    (P[59] = ea),
                    (P[60] = eS),
                    (P[61] = en),
                    (P[62] = ez),
                    (P[63] = ed),
                    (P[64] = eb),
                    (P[65] = eo),
                    (P[66] = eT),
                    (P[67] = eH),
                    (P[68] = eD),
                    (P[69] = G),
                    (P[70] = eP),
                    (P[71] = eh),
                    (P[72] = q),
                    (P[73] = I))
                  : (I = P[73]),
                I
              );
            }),
            (o = (e) => (0, d.jsx)(ej, { ...e })),
            ((a = (e) => {
              let t,
                r,
                a,
                c = (0, i.c)(7);
              return (
                c[0] !== e
                  ? ((t = o ? () => o(e) : void 0), (c[0] = e), (c[1] = t))
                  : (t = c[1]),
                c[2] !== e
                  ? ((r = (0, d.jsx)(n, { ...e })), (c[2] = e), (c[3] = r))
                  : (r = c[3]),
                c[4] !== t || c[5] !== r
                  ? ((a = (0, d.jsx)(b.A, { fallback: t, children: r })),
                    (c[4] = t),
                    (c[5] = r),
                    (c[6] = a))
                  : (a = c[6]),
                a
              );
            }).displayName = `withErrorBoundary(${
              n.displayName || n.name || "Component"
            })`),
            a);
        function eS() {
          0 == (ew -= 1) && (eL = !1);
        }
        function eN() {
          return (ew += 1), eS;
        }
      },
      69705: (e) => {
        e.exports = {
          leaderboardWidgetNumberCard:
            "LeaderboardWidgetNumberCard_leaderboardWidgetNumberCard__ac8UM",
          label: "LeaderboardWidgetNumberCard_label__NZoiY",
          number: "LeaderboardWidgetNumberCard_number__Fz0TP",
        };
      },
      74265: (e) => {
        e.exports = {
          czyButton: "LeaderboardWidget_czyButton__iSSFe",
          "czyButton--contained--purple":
            "LeaderboardWidget_czyButton--contained--purple__QtqHf",
          "czyButton--contained--white":
            "LeaderboardWidget_czyButton--contained--white___HyHP",
          "czyButton--contained--grey":
            "LeaderboardWidget_czyButton--contained--grey__apXcs",
          "czyButton--contained--warning":
            "LeaderboardWidget_czyButton--contained--warning__NPPyt",
          "czyButton--contained--alert":
            "LeaderboardWidget_czyButton--contained--alert__7exzX",
          "czyButton--contained--success":
            "LeaderboardWidget_czyButton--contained--success__ObfHj",
          "czyButton--contained--black":
            "LeaderboardWidget_czyButton--contained--black__81zpo",
          "czyButton--contained--green-gradient":
            "LeaderboardWidget_czyButton--contained--green-gradient__oaCAd",
          "czyButton--contained--animated-green-gradient":
            "LeaderboardWidget_czyButton--contained--animated-green-gradient___beW2",
          "scroll-gradient": "LeaderboardWidget_scroll-gradient__gWbna",
          "czyButton--outlined--purple":
            "LeaderboardWidget_czyButton--outlined--purple__4zmQm",
          "czyButton--link--purple":
            "LeaderboardWidget_czyButton--link--purple__Ba53_",
          "czyButton--outlined--white":
            "LeaderboardWidget_czyButton--outlined--white__63pZp",
          "czyButton--link--white":
            "LeaderboardWidget_czyButton--link--white__f20RX",
          "czyButton--outlined--grey":
            "LeaderboardWidget_czyButton--outlined--grey__Jy0m5",
          "czyButton--link--grey":
            "LeaderboardWidget_czyButton--link--grey__0O_cg",
          "czyButton--outlined--warning":
            "LeaderboardWidget_czyButton--outlined--warning__2fjDV",
          "czyButton--link--warning":
            "LeaderboardWidget_czyButton--link--warning__6w40_",
          "czyButton--outlined--alert":
            "LeaderboardWidget_czyButton--outlined--alert__zGjho",
          "czyButton--link--alert":
            "LeaderboardWidget_czyButton--link--alert__8W5YI",
          "czyButton--outlined--success":
            "LeaderboardWidget_czyButton--outlined--success__QwBj9",
          "czyButton--link--success":
            "LeaderboardWidget_czyButton--link--success__O_J_5",
          "czyButton--outlined": "LeaderboardWidget_czyButton--outlined__EthSG",
          "czyButton--disabled": "LeaderboardWidget_czyButton--disabled__UkxGO",
          "czyButton--height50": "LeaderboardWidget_czyButton--height50__0em2r",
          "czyButton--height34": "LeaderboardWidget_czyButton--height34__lKMFw",
          "czyButton--height28": "LeaderboardWidget_czyButton--height28__xWXJC",
          "czyButton--fullWidth":
            "LeaderboardWidget_czyButton--fullWidth__a8oGu",
          "czyButton--headerIcon":
            "LeaderboardWidget_czyButton--headerIcon__Xl85I",
          "czyButton--headerIcon--desktop":
            "LeaderboardWidget_czyButton--headerIcon--desktop__uH9m3",
          "czyButton--headerIcon--mobile":
            "LeaderboardWidget_czyButton--headerIcon--mobile__jh0X0",
          "czyButton--headerIcon--withLabel":
            "LeaderboardWidget_czyButton--headerIcon--withLabel__etX6h",
          leaderboardWidgetWrap:
            "LeaderboardWidget_leaderboardWidgetWrap__0eibN",
          "leaderboardWidgetWrap--mobile":
            "LeaderboardWidget_leaderboardWidgetWrap--mobile__pvXJO",
          leaderboardWidgetParticipantDivider:
            "LeaderboardWidget_leaderboardWidgetParticipantDivider__g0RUm",
          leaderboardWidgetNoRanking:
            "LeaderboardWidget_leaderboardWidgetNoRanking__i_l1U",
          onlyTitle: "LeaderboardWidget_onlyTitle__pTnIY",
          "leaderboardWidgetWrap--right-column":
            "LeaderboardWidget_leaderboardWidgetWrap--right-column__dJbB4",
          "leaderboardWidgetWrap--under-gameframe":
            "LeaderboardWidget_leaderboardWidgetWrap--under-gameframe__s5xi5",
          leaderboardWidgetLoading:
            "LeaderboardWidget_leaderboardWidgetLoading__nR7Jv",
          leaderboardWidgetParticipant:
            "LeaderboardWidget_leaderboardWidgetParticipant__zIm7i",
          leaderboardWidgetNoRankingTitle:
            "LeaderboardWidget_leaderboardWidgetNoRankingTitle__2DQ_c",
          leaderboardWidgetNoRankingMeta:
            "LeaderboardWidget_leaderboardWidgetNoRankingMeta__hSEvz",
          leaderboardWidgetNoRankingText:
            "LeaderboardWidget_leaderboardWidgetNoRankingText__bGCpK",
          right: "LeaderboardWidget_right__Zg1Lu",
          contained: "LeaderboardWidget_contained___nsbw",
          leaderboardWidgetParticipantTitle:
            "LeaderboardWidget_leaderboardWidgetParticipantTitle__1HFjX",
          leaderboardWidgetParticipantEndDate:
            "LeaderboardWidget_leaderboardWidgetParticipantEndDate___ONKx",
          leaderboardWidgetParticipantScore:
            "LeaderboardWidget_leaderboardWidgetParticipantScore__UgKEc",
          leaderboardWidgetParticipantBadge:
            "LeaderboardWidget_leaderboardWidgetParticipantBadge__lUdD4",
          leaderboardWidgetParticipantStandings:
            "LeaderboardWidget_leaderboardWidgetParticipantStandings__n_HOq",
          "leaderboardWidgetParticipant--gold":
            "LeaderboardWidget_leaderboardWidgetParticipant--gold__wBN1s",
          "leaderboardWidgetParticipant--silver":
            "LeaderboardWidget_leaderboardWidgetParticipant--silver___Wuan",
          "leaderboardWidgetParticipant--bronze":
            "LeaderboardWidget_leaderboardWidgetParticipant--bronze__oy7Ap",
          "leaderboardWidgetParticipant--level_4":
            "LeaderboardWidget_leaderboardWidgetParticipant--level_4__56toS",
          "leaderboardWidgetParticipant--level_5":
            "LeaderboardWidget_leaderboardWidgetParticipant--level_5__paqwz",
          "leaderboardWidgetParticipant--level_6":
            "LeaderboardWidget_leaderboardWidgetParticipant--level_6__Jzwb3",
        };
      },
      74564: (e, t, r) => {
        "use strict";
        r.d(t, { B: () => o });
        var a = r(55729),
          n = r(59458);
        function o(e, t) {
          return a.useMemo(() => (e ? (0, n.lL)(e, t ?? e) : null), [e, t]);
        }
      },
      95446: (e) => {
        e.exports = {
          usersContainer: "LeaderboardWidget_usersContainer__nZ6U7",
          endSeasonContainer: "LeaderboardWidget_endSeasonContainer__0Y5Lg",
          leaderboardWidgetWrap:
            "LeaderboardWidget_leaderboardWidgetWrap__50X7p",
          leaderboardWidget: "LeaderboardWidget_leaderboardWidget__sazWJ",
          chevronContainer: "LeaderboardWidget_chevronContainer__mayIM",
          participantWidget: "LeaderboardWidget_participantWidget__AndFN",
          row: "LeaderboardWidget_row__6ydR4",
          badgeContainer: "LeaderboardWidget_badgeContainer__yweKD",
          czyButton: "LeaderboardWidget_czyButton__ohhJw",
          "czyButton--contained--purple":
            "LeaderboardWidget_czyButton--contained--purple__BkgsV",
          "czyButton--contained--white":
            "LeaderboardWidget_czyButton--contained--white__fhQc7",
          "czyButton--contained--grey":
            "LeaderboardWidget_czyButton--contained--grey__OSO1e",
          "czyButton--contained--warning":
            "LeaderboardWidget_czyButton--contained--warning__zoX1J",
          "czyButton--contained--alert":
            "LeaderboardWidget_czyButton--contained--alert__I9hoR",
          "czyButton--contained--success":
            "LeaderboardWidget_czyButton--contained--success__SGuAq",
          "czyButton--contained--black":
            "LeaderboardWidget_czyButton--contained--black__ZA_qf",
          "czyButton--contained--green-gradient":
            "LeaderboardWidget_czyButton--contained--green-gradient__gzzdF",
          "czyButton--contained--animated-green-gradient":
            "LeaderboardWidget_czyButton--contained--animated-green-gradient__0MUHr",
          "scroll-gradient": "LeaderboardWidget_scroll-gradient__OCPja",
          "czyButton--outlined--purple":
            "LeaderboardWidget_czyButton--outlined--purple__khOMP",
          "czyButton--link--purple":
            "LeaderboardWidget_czyButton--link--purple__hX_GU",
          "czyButton--outlined--white":
            "LeaderboardWidget_czyButton--outlined--white__UuAda",
          "czyButton--link--white":
            "LeaderboardWidget_czyButton--link--white__BVSTh",
          "czyButton--outlined--grey":
            "LeaderboardWidget_czyButton--outlined--grey__k4W1O",
          "czyButton--link--grey":
            "LeaderboardWidget_czyButton--link--grey__JfBCX",
          "czyButton--outlined--warning":
            "LeaderboardWidget_czyButton--outlined--warning__yYxfN",
          "czyButton--link--warning":
            "LeaderboardWidget_czyButton--link--warning__9to8p",
          "czyButton--outlined--alert":
            "LeaderboardWidget_czyButton--outlined--alert__UC4PX",
          "czyButton--link--alert":
            "LeaderboardWidget_czyButton--link--alert__o8SU7",
          "czyButton--outlined--success":
            "LeaderboardWidget_czyButton--outlined--success__Ye3F0",
          "czyButton--link--success":
            "LeaderboardWidget_czyButton--link--success__rM_Hj",
          "czyButton--outlined": "LeaderboardWidget_czyButton--outlined__8ZpZj",
          "czyButton--disabled": "LeaderboardWidget_czyButton--disabled__CSGdw",
          "czyButton--height50": "LeaderboardWidget_czyButton--height50__fOHiq",
          "czyButton--height34": "LeaderboardWidget_czyButton--height34__i3hYA",
          "czyButton--height28": "LeaderboardWidget_czyButton--height28__f0KK1",
          "czyButton--fullWidth":
            "LeaderboardWidget_czyButton--fullWidth__MpW7Y",
          "czyButton--headerIcon":
            "LeaderboardWidget_czyButton--headerIcon__3jX8G",
          "czyButton--headerIcon--desktop":
            "LeaderboardWidget_czyButton--headerIcon--desktop__vMHJU",
          "czyButton--headerIcon--mobile":
            "LeaderboardWidget_czyButton--headerIcon--mobile__gfqei",
          "czyButton--headerIcon--withLabel":
            "LeaderboardWidget_czyButton--headerIcon--withLabel__REJTA",
          titleContainer: "LeaderboardWidget_titleContainer__5LRMf",
          highlightedNumber: "LeaderboardWidget_highlightedNumber__d_sAl",
          label: "LeaderboardWidget_label__D665r",
          bronze: "LeaderboardWidget_bronze__QEfNO",
          silver: "LeaderboardWidget_silver___CeBO",
          gold: "LeaderboardWidget_gold__jVfaT",
          level_6: "LeaderboardWidget_level_6__vzhZX",
          level_5: "LeaderboardWidget_level_5__r7g4p",
          level_4: "LeaderboardWidget_level_4__nc6Qw",
          nonParticipantWidget: "LeaderboardWidget_nonParticipantWidget__7ik8L",
          topContainer: "LeaderboardWidget_topContainer__7wubn",
          leftContainer: "LeaderboardWidget_leftContainer__u9qKr",
          subtitleContainer: "LeaderboardWidget_subtitleContainer__MWEGg",
          bottomContainer: "LeaderboardWidget_bottomContainer__wIOtR",
          bodyContainer: "LeaderboardWidget_bodyContainer__vx39R",
          startingSoonWidget: "LeaderboardWidget_startingSoonWidget__4mKI8",
          loading: "LeaderboardWidget_loading__e2T9S",
          mobile: "LeaderboardWidget_mobile__4J5z8",
          hideInRightColumn: "LeaderboardWidget_hideInRightColumn__aVK7_",
          switchDirection: "LeaderboardWidget_switchDirection__gX0wV",
          scoreContainerRow: "LeaderboardWidget_scoreContainerRow__yxdkO",
          hideUnderGameframe: "LeaderboardWidget_hideUnderGameframe__fE7FK",
          rightColumn: "LeaderboardWidget_rightColumn__aHsoW",
          underGameframe: "LeaderboardWidget_underGameframe__CxdMp",
        };
      },
      96912: (e, t, r) => {
        "use strict";
        r.d(t, { A: () => o });
        var a = r(6029),
          n = r(75155);
        r(56797);
        let o = (e) => {
          let t,
            r,
            o,
            d = (0, n.c)(7),
            { code: i } = e;
          d[0] !== i
            ? ((t = i.toLowerCase()), (d[0] = i), (d[1] = t))
            : (t = d[1]);
          let c = t,
            l = `fi fi-${c}`;
          return (
            d[2] !== i
              ? ((r = i.toUpperCase()), (d[2] = i), (d[3] = r))
              : (r = d[3]),
            d[4] !== l || d[5] !== r
              ? ((o = (0, a.jsx)("span", { className: l, "aria-label": r })),
                (d[4] = l),
                (d[5] = r),
                (d[6] = o))
              : (o = d[6]),
            o
          );
        };
      },
      99703: (e, t, r) => {
        "use strict";
        r.d(t, { s: () => o });
        var a = r(55729),
          n = r(25312);
        let o = (e) => {
          let [t, r] = a.useState(null),
            o = a.useRef(e);
          e && (o.current = e);
          let d = e || o.current;
          return (
            a.useEffect(() => {
              let e = null,
                t = !1,
                a = () => {
                  t || r(new Date());
                };
              a();
              let n = () => {
                let t = new Date(d).getTime();
                if (!Number.isFinite(t)) return;
                let r = t - Date.now();
                !(r <= 0) &&
                  (e = window.setTimeout(
                    () => {
                      a(), n();
                    },
                    r > 864e5
                      ? r % 36e5 || 36e5
                      : r > 36e5
                      ? r % 6e4 || 6e4
                      : r % 1e3 || 1e3
                  ));
              };
              return (
                n(),
                () => {
                  (t = !0), null !== e && window.clearTimeout(e);
                }
              );
            }, [d]),
            null === t ? null : (0, n.qz)(d, t)
          );
        };
      },
    },
  ]);
