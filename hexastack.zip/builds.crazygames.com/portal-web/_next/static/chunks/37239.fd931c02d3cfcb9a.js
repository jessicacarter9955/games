!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (null != n) for (var a in n) n.hasOwnProperty(a) && (e[a] = n[a]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "0510247e-54cc-4c29-8d06-a3f8adc731fa"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-0510247e-54cc-4c29-8d06-a3f8adc731fa"));
  } catch (e) {}
})();
("use strict");
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [11591, 37239],
  {
    11591: (e, t, n) => {
      n.d(t, { A: () => c });
      var a = n(6029),
        r = n(75155);
      n(55729);
      var l = n(50212),
        o = n(56760),
        i = n(69386),
        s = n(85893),
        d = n(82026),
        u = n.n(d);
      let c = (e) => {
        let t,
          n,
          d,
          c,
          h = (0, r.c)(12),
          { open: f, blurred: m, onClose: v, children: g, className: p } = e;
        if (((0, i.K)(f), !f)) return null;
        let y = void 0 !== m && m && u().blurred;
        if (
          (h[0] !== p || h[1] !== y
            ? ((t = (0, l.A)(u().modal, y, p)),
              (h[0] = p),
              (h[1] = y),
              (h[2] = t))
            : (t = h[2]),
          h[3] !== v || h[4] !== f
            ? ((n = (0, a.jsx)(s.k, { open: f, onClick: v })),
              (h[3] = v),
              (h[4] = f),
              (h[5] = n))
            : (n = h[5]),
          h[6] !== g
            ? ((d = (0, a.jsx)("div", {
                className: u().modalContent,
                children: g,
              })),
              (h[6] = g),
              (h[7] = d))
            : (d = h[7]),
          h[8] !== t || h[9] !== n || h[10] !== d)
        ) {
          let e = (0, a.jsxs)("div", { className: t, children: [n, d] });
          (c = (0, o.createPortal)(e, document.body)),
            (h[8] = t),
            (h[9] = n),
            (h[10] = d),
            (h[11] = c);
        } else c = h[11];
        return c;
      };
    },
    25312: (e, t, n) => {
      n.d(t, {
        LW: () => u,
        WH: () => d,
        _5: () => l,
        aB: () => o,
        ec: () => r,
        qz: () => s,
        wx: () => i,
      });
      var a = n(91828);
      let r = 864e5,
        l = 6048e5,
        o = (e) => parseFloat(((Date.now() - e) / 6e4).toFixed(2));
      function i(e) {
        let t = new Date(e),
          n = new Date();
        if (!(0, a.vd)(t) || t < n) return null;
        let r = t.getTime() - n.getTime(),
          { days: l, hours: o, minutes: i } = (0, a.Hf)(r),
          s = [];
        return (
          l > 0 && s.push(`${l}d`),
          o > 0 && s.push(`${o}h`),
          0 === l && 0 === o && i > 0 && s.push(`${i}m`),
          `${s.join(" ")}`
        );
      }
      function s(e, t) {
        let n = new Date(e);
        if (!(0, a.vd)(n) || n <= t) return null;
        let r = Math.floor((n.getTime() - t.getTime()) / 1e3),
          l = Math.floor(r / 86400),
          o = Math.floor((r % 86400) / 3600),
          i = Math.floor((r % 3600) / 60);
        if (l > 0) {
          let e = [`${l}d`];
          return o > 0 && e.push(`${o}h`), e.join(" ");
        }
        if (o > 0) {
          let e = [`${o}h`];
          return i > 0 && e.push(`${i}m`), e.join(" ");
        }
        return `${i}m ${r % 60}s`;
      }
      function d(e, t) {
        if (!e) return !1;
        let n = new Date(e).getTime();
        return !isNaN(n) && Date.now() - n >= t;
      }
      function u(e) {
        return new Intl.DateTimeFormat("en-US", {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          hour12: !1,
        }).format(e);
      }
    },
    38662: (e, t, n) => {
      n.d(t, { A: () => c });
      var a = n(6029),
        r = n(75155);
      n(55729);
      var l = n(50212),
        o = n(93800),
        i = n(37434),
        s = n(11591),
        d = n(82026),
        u = n.n(d);
      let c = (e) => {
        let t,
          n,
          d,
          c,
          h,
          f,
          m,
          v,
          g,
          p,
          y = (0, r.c)(34),
          {
            children: b,
            isSubmitDisabled: w,
            onClose: x,
            onSubmit: j,
            submitLabel: C,
            titleLabel: N,
            open: _,
            hasCloseButton: M,
            fullWidthSubmit: k,
            zeroPaddingContainer: D,
            contentClassName: A,
            innerContentClassName: T,
            className: $,
            dataTestId: B,
          } = e,
          I = void 0 === _ || _,
          E = void 0 === M || M,
          z = void 0 === k || k;
        y[0] !== $
          ? ((t = (0, l.A)(u().dialogContentRoot, $)), (y[0] = $), (y[1] = t))
          : (t = y[1]);
        let P = D && u().zeroPaddingContainer;
        return (
          y[2] !== A || y[3] !== P
            ? ((n = (0, l.A)(u().dialogContent, P, A)),
              (y[2] = A),
              (y[3] = P),
              (y[4] = n))
            : (n = y[4]),
          y[5] !== E || y[6] !== x
            ? ((d =
                E &&
                (0, a.jsx)("div", {
                  className: u().exitButtonContainer,
                  children: (0, a.jsx)("button", {
                    onClick: x,
                    className: u().exitButton,
                    "data-testid": "modal-close",
                    children: (0, a.jsx)(o.A, { name: "close" }),
                  }),
                })),
              (y[5] = E),
              (y[6] = x),
              (y[7] = d))
            : (d = y[7]),
          y[8] !== T
            ? ((c = (0, l.A)(u().dialogInnerContent, T)),
              (y[8] = T),
              (y[9] = c))
            : (c = y[9]),
          y[10] !== N
            ? ((h =
                N &&
                (0, a.jsx)("h1", { className: u().headerTitle, children: N })),
              (y[10] = N),
              (y[11] = h))
            : (h = y[11]),
          y[12] !== b || y[13] !== c || y[14] !== h
            ? ((f = (0, a.jsxs)("div", { className: c, children: [h, b] })),
              (y[12] = b),
              (y[13] = c),
              (y[14] = h),
              (y[15] = f))
            : (f = y[15]),
          y[16] !== z || y[17] !== w || y[18] !== j || y[19] !== C
            ? ((m =
                j &&
                (0, a.jsx)("div", {
                  className: u().modalButtonContainer,
                  children: (0, a.jsx)("div", {
                    className: u().submitButtonContainer,
                    children: (0, a.jsx)(i.A, {
                      className: u().czyModalButton,
                      height: 50,
                      fullWidth: z,
                      variant: "contained",
                      disabled: w,
                      onClick: j,
                      dataTestId: "modal-submit",
                      children: C,
                    }),
                  }),
                })),
              (y[16] = z),
              (y[17] = w),
              (y[18] = j),
              (y[19] = C),
              (y[20] = m))
            : (m = y[20]),
          y[21] !== f || y[22] !== m || y[23] !== n || y[24] !== d
            ? ((v = (0, a.jsxs)("div", { className: n, children: [d, f, m] })),
              (y[21] = f),
              (y[22] = m),
              (y[23] = n),
              (y[24] = d),
              (y[25] = v))
            : (v = y[25]),
          y[26] !== B || y[27] !== v || y[28] !== t
            ? ((g = (0, a.jsx)("div", {
                className: t,
                "data-testid": B,
                children: v,
              })),
              (y[26] = B),
              (y[27] = v),
              (y[28] = t),
              (y[29] = g))
            : (g = y[29]),
          y[30] !== x || y[31] !== I || y[32] !== g
            ? ((p = (0, a.jsx)(s.A, { open: I, onClose: x, children: g })),
              (y[30] = x),
              (y[31] = I),
              (y[32] = g),
              (y[33] = p))
            : (p = y[33]),
          p
        );
      };
    },
  },
]);
