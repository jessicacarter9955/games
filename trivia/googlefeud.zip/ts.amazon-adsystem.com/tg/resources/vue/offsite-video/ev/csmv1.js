!(function (e) {
  var o = {};
  function t(n) {
    if (o[n]) return o[n].exports;
    var i = (o[n] = { i: n, l: !1, exports: {} });
    return e[n].call(i.exports, i, i.exports, t), (i.l = !0), i.exports;
  }
  (t.m = e),
    (t.c = o),
    (t.d = function (e, o, n) {
      t.o(e, o) || Object.defineProperty(e, o, { enumerable: !0, get: n });
    }),
    (t.r = function (e) {
      "undefined" != typeof Symbol &&
        Symbol.toStringTag &&
        Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
        Object.defineProperty(e, "__esModule", { value: !0 });
    }),
    (t.t = function (e, o) {
      if ((1 & o && (e = t(e)), 8 & o)) return e;
      if (4 & o && "object" == typeof e && e && e.__esModule) return e;
      var n = Object.create(null);
      if (
        (t.r(n),
        Object.defineProperty(n, "default", { enumerable: !0, value: e }),
        2 & o && "string" != typeof e)
      )
        for (var i in e)
          t.d(
            n,
            i,
            function (o) {
              return e[o];
            }.bind(null, i)
          );
      return n;
    }),
    (t.n = function (e) {
      var o =
        e && e.__esModule
          ? function () {
              return e.default;
            }
          : function () {
              return e;
            };
      return t.d(o, "a", o), o;
    }),
    (t.o = function (e, o) {
      return Object.prototype.hasOwnProperty.call(e, o);
    }),
    (t.p = ""),
    t((t.s = 17));
})([
  function (e, o) {
    e.exports = function (e, o, t) {
      return (
        o in e
          ? Object.defineProperty(e, o, {
              value: t,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (e[o] = t),
        e
      );
    };
  },
  function (e, o) {
    function t(o) {
      return (
        "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
          ? (e.exports = t =
              function (e) {
                return typeof e;
              })
          : (e.exports = t =
              function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              }),
        t(o)
      );
    }
    e.exports = t;
  },
  function (e, o, t) {
    var n = t(7),
      i = t(8),
      r = t(9),
      m = t(11);
    e.exports = function (e, o) {
      return n(e) || i(e, o) || r(e, o) || m();
    };
  },
  function (e, o) {
    e.exports = function (e, o) {
      if (!(e instanceof o))
        throw new TypeError("Cannot call a class as a function");
    };
  },
  function (module, exports, __webpack_require__) {
    (function (global) {
      !(function (e, o, t) {
        if ("object" == typeof t && "string" != typeof t.nodeName) o(e, t);
        else {
          t = {};
          var n = ["1.3.2"];
          function i(e) {
            for (var o in e) e.hasOwnProperty(o) && (e[o] = i(e[o]));
            return Object.freeze(e);
          }
          for (var r in (o(e, t), t))
            t.hasOwnProperty(r) &&
              (null == Object.getOwnPropertyDescriptor(e, r) &&
                Object.defineProperty(e, r, { value: {} }),
              n.forEach(function (o) {
                if (null == Object.getOwnPropertyDescriptor(e[r], o)) {
                  var n = i(t[r]);
                  Object.defineProperty(e[r], o, {
                    get: function () {
                      return n;
                    },
                    enumerable: !0,
                  });
                }
              }));
        }
      })(
        void 0 === global ? this : global,
        function (omidGlobal, omidExports) {
          "use strict";
          var $jscomp = $jscomp || {};
          ($jscomp.scope = {}),
            ($jscomp.arrayIteratorImpl = function (e) {
              var o = 0;
              return function () {
                return o < e.length
                  ? { done: !1, value: e[o++] }
                  : { done: !0 };
              };
            }),
            ($jscomp.arrayIterator = function (e) {
              return { next: $jscomp.arrayIteratorImpl(e) };
            }),
            ($jscomp.makeIterator = function (e) {
              var o =
                "undefined" != typeof Symbol &&
                Symbol.iterator &&
                e[Symbol.iterator];
              return o ? o.call(e) : $jscomp.arrayIterator(e);
            }),
            ($jscomp.arrayFromIterator = function (e) {
              for (var o, t = []; !(o = e.next()).done; ) t.push(o.value);
              return t;
            }),
            ($jscomp.arrayFromIterable = function (e) {
              return e instanceof Array
                ? e
                : $jscomp.arrayFromIterator($jscomp.makeIterator(e));
            }),
            ($jscomp.ASSUME_ES5 = !1),
            ($jscomp.ASSUME_NO_NATIVE_MAP = !1),
            ($jscomp.ASSUME_NO_NATIVE_SET = !1),
            ($jscomp.SIMPLE_FROUND_POLYFILL = !1),
            ($jscomp.objectCreate =
              $jscomp.ASSUME_ES5 || "function" == typeof Object.create
                ? Object.create
                : function (e) {
                    var o = function () {};
                    return (o.prototype = e), new o();
                  }),
            ($jscomp.underscoreProtoCanBeSet = function () {
              var e = {};
              try {
                return (e.__proto__ = { a: !0 }), e.a;
              } catch (e) {}
              return !1;
            }),
            ($jscomp.setPrototypeOf =
              "function" == typeof Object.setPrototypeOf
                ? Object.setPrototypeOf
                : $jscomp.underscoreProtoCanBeSet()
                ? function (e, o) {
                    if (((e.__proto__ = o), e.__proto__ !== o))
                      throw new TypeError(e + " is not extensible");
                    return e;
                  }
                : null),
            ($jscomp.inherits = function (e, o) {
              if (
                ((e.prototype = $jscomp.objectCreate(o.prototype)),
                (e.prototype.constructor = e),
                $jscomp.setPrototypeOf)
              ) {
                var t = $jscomp.setPrototypeOf;
                t(e, o);
              } else
                for (t in o)
                  if ("prototype" != t)
                    if (Object.defineProperties) {
                      var n = Object.getOwnPropertyDescriptor(o, t);
                      n && Object.defineProperty(e, t, n);
                    } else e[t] = o[t];
              e.superClass_ = o.prototype;
            });
          var module$exports$omid$common$argsChecker = {
              assertTruthyString: function (e, o) {
                if (!o)
                  throw Error(
                    "Value for " + e + " is undefined, null or blank."
                  );
                if ("string" != typeof o && !(o instanceof String))
                  throw Error("Value for " + e + " is not a string.");
                if ("" === o.trim())
                  throw Error("Value for " + e + " is empty string.");
              },
              assertNotNullObject: function (e, o) {
                if (null == o)
                  throw Error("Value for " + e + " is undefined or null");
              },
              assertNumber: function (e, o) {
                if (null == o)
                  throw Error(e + " must not be null or undefined.");
                if ("number" != typeof o || isNaN(o))
                  throw Error("Value for " + e + " is not a number");
              },
              assertNumberBetween: function (e, o, t, n) {
                if (
                  ((0, module$exports$omid$common$argsChecker.assertNumber)(
                    e,
                    o
                  ),
                  o < t || o > n)
                )
                  throw Error(
                    "Value for " +
                      e +
                      " is outside the range [" +
                      t +
                      "," +
                      n +
                      "]"
                  );
              },
              assertFunction: function (e, o) {
                if (!o) throw Error(e + " must not be truthy.");
              },
              assertPositiveNumber: function (e, o) {
                if (
                  ((0, module$exports$omid$common$argsChecker.assertNumber)(
                    e,
                    o
                  ),
                  0 > o)
                )
                  throw Error(e + " must be a positive number.");
              },
            },
            module$exports$omid$common$VersionUtils = {},
            module$contents$omid$common$VersionUtils_SEMVER_DIGITS_NUMBER = 3;
          (module$exports$omid$common$VersionUtils.isValidVersion = function (
            e
          ) {
            return /\d+\.\d+\.\d+(-.*)?/.test(e);
          }),
            (module$exports$omid$common$VersionUtils.versionGreaterOrEqual =
              function (e, o) {
                (e = e.split("-")[0].split(".")),
                  (o = o.split("-")[0].split("."));
                for (
                  var t = 0;
                  t <
                  module$contents$omid$common$VersionUtils_SEMVER_DIGITS_NUMBER;
                  t++
                ) {
                  var n = parseInt(e[t], 10),
                    i = parseInt(o[t], 10);
                  if (n > i) break;
                  if (n < i) return !1;
                }
                return !0;
              });
          var module$exports$omid$common$ArgsSerDe = {},
            module$contents$omid$common$ArgsSerDe_ARGS_NOT_SERIALIZED_VERSION =
              "1.0.3";
          (module$exports$omid$common$ArgsSerDe.serializeMessageArgs =
            function (e, o) {
              return (0,
              module$exports$omid$common$VersionUtils.isValidVersion)(e) &&
                (0,
                module$exports$omid$common$VersionUtils.versionGreaterOrEqual)(
                  e,
                  module$contents$omid$common$ArgsSerDe_ARGS_NOT_SERIALIZED_VERSION
                )
                ? o
                : JSON.stringify(o);
            }),
            (module$exports$omid$common$ArgsSerDe.deserializeMessageArgs =
              function (e, o) {
                return (0,
                module$exports$omid$common$VersionUtils.isValidVersion)(e) &&
                  (0,
                  module$exports$omid$common$VersionUtils.versionGreaterOrEqual)(
                    e,
                    module$contents$omid$common$ArgsSerDe_ARGS_NOT_SERIALIZED_VERSION
                  )
                  ? o || []
                  : o && "string" == typeof o
                  ? JSON.parse(o)
                  : [];
              });
          var module$exports$omid$common$constants = {
            AdEventType: {
              IMPRESSION: "impression",
              STATE_CHANGE: "stateChange",
              GEOMETRY_CHANGE: "geometryChange",
              SESSION_START: "sessionStart",
              SESSION_ERROR: "sessionError",
              SESSION_FINISH: "sessionFinish",
              MEDIA: "media",
              VIDEO: "video",
              LOADED: "loaded",
              START: "start",
              FIRST_QUARTILE: "firstQuartile",
              MIDPOINT: "midpoint",
              THIRD_QUARTILE: "thirdQuartile",
              COMPLETE: "complete",
              PAUSE: "pause",
              RESUME: "resume",
              BUFFER_START: "bufferStart",
              BUFFER_FINISH: "bufferFinish",
              SKIPPED: "skipped",
              VOLUME_CHANGE: "volumeChange",
              PLAYER_STATE_CHANGE: "playerStateChange",
              AD_USER_INTERACTION: "adUserInteraction",
            },
            MediaEventType: {
              LOADED: "loaded",
              START: "start",
              FIRST_QUARTILE: "firstQuartile",
              MIDPOINT: "midpoint",
              THIRD_QUARTILE: "thirdQuartile",
              COMPLETE: "complete",
              PAUSE: "pause",
              RESUME: "resume",
              BUFFER_START: "bufferStart",
              BUFFER_FINISH: "bufferFinish",
              SKIPPED: "skipped",
              VOLUME_CHANGE: "volumeChange",
              PLAYER_STATE_CHANGE: "playerStateChange",
              AD_USER_INTERACTION: "adUserInteraction",
            },
          };
          (module$exports$omid$common$constants.VideoEventType =
            module$exports$omid$common$constants.MediaEventType),
            (module$exports$omid$common$constants.ImpressionType = {
              DEFINED_BY_JAVASCRIPT: "definedByJavaScript",
              UNSPECIFIED: "unspecified",
              LOADED: "loaded",
              BEGIN_TO_RENDER: "beginToRender",
              ONE_PIXEL: "onePixel",
              VIEWABLE: "viewable",
              AUDIBLE: "audible",
              OTHER: "other",
            }),
            (module$exports$omid$common$constants.ErrorType = {
              GENERIC: "generic",
              VIDEO: "video",
              MEDIA: "media",
            }),
            (module$exports$omid$common$constants.AdSessionType = {
              NATIVE: "native",
              HTML: "html",
              JAVASCRIPT: "javascript",
            }),
            (module$exports$omid$common$constants.EventOwner = {
              NATIVE: "native",
              JAVASCRIPT: "javascript",
              NONE: "none",
            }),
            (module$exports$omid$common$constants.AccessMode = {
              FULL: "full",
              LIMITED: "limited",
            }),
            (module$exports$omid$common$constants.AppState = {
              BACKGROUNDED: "backgrounded",
              FOREGROUNDED: "foregrounded",
            }),
            (module$exports$omid$common$constants.Environment = {
              APP: "app",
              WEB: "web",
            }),
            (module$exports$omid$common$constants.InteractionType = {
              CLICK: "click",
              INVITATION_ACCEPT: "invitationAccept",
            }),
            (module$exports$omid$common$constants.CreativeType = {
              DEFINED_BY_JAVASCRIPT: "definedByJavaScript",
              HTML_DISPLAY: "htmlDisplay",
              NATIVE_DISPLAY: "nativeDisplay",
              VIDEO: "video",
              AUDIO: "audio",
            }),
            (module$exports$omid$common$constants.MediaType = {
              DISPLAY: "display",
              VIDEO: "video",
            }),
            (module$exports$omid$common$constants.Reason = {
              NOT_FOUND: "notFound",
              HIDDEN: "hidden",
              BACKGROUNDED: "backgrounded",
              VIEWPORT: "viewport",
              OBSTRUCTED: "obstructed",
              CLIPPED: "clipped",
            }),
            (module$exports$omid$common$constants.SupportedFeatures = {
              CONTAINER: "clid",
              VIDEO: "vlid",
            }),
            (module$exports$omid$common$constants.VideoPosition = {
              PREROLL: "preroll",
              MIDROLL: "midroll",
              POSTROLL: "postroll",
              STANDALONE: "standalone",
            }),
            (module$exports$omid$common$constants.VideoPlayerState = {
              MINIMIZED: "minimized",
              COLLAPSED: "collapsed",
              NORMAL: "normal",
              EXPANDED: "expanded",
              FULLSCREEN: "fullscreen",
            }),
            (module$exports$omid$common$constants.NativeViewKeys = {
              X: "x",
              LEFT: "left",
              Y: "y",
              TOP: "top",
              WIDTH: "width",
              HEIGHT: "height",
              AD_SESSION_ID: "adSessionId",
              IS_FRIENDLY_OBSTRUCTION_FOR: "isFriendlyObstructionFor",
              CLIPS_TO_BOUNDS: "clipsToBounds",
              CHILD_VIEWS: "childViews",
              END_X: "endX",
              END_Y: "endY",
              OBSTRUCTIONS: "obstructions",
              OBSTRUCTION_CLASS: "obstructionClass",
              OBSTRUCTION_PURPOSE: "obstructionPurpose",
              OBSTRUCTION_REASON: "obstructionReason",
              PIXELS: "pixels",
            }),
            (module$exports$omid$common$constants.MeasurementStateChangeSource =
              { CONTAINER: "container", CREATIVE: "creative" }),
            (module$exports$omid$common$constants.ElementMarkup = {
              OMID_ELEMENT_CLASS_NAME: "omid-element",
            }),
            (module$exports$omid$common$constants.CommunicationType = {
              NONE: "NONE",
              DIRECT: "DIRECT",
              POST_MESSAGE: "POST_MESSAGE",
            }),
            (module$exports$omid$common$constants.OmidImplementer = {
              OMSDK: "omsdk",
            });
          var module$contents$omid$common$InternalMessage_GUID_KEY =
              "omid_message_guid",
            module$contents$omid$common$InternalMessage_METHOD_KEY =
              "omid_message_method",
            module$contents$omid$common$InternalMessage_VERSION_KEY =
              "omid_message_version",
            module$contents$omid$common$InternalMessage_ARGS_KEY =
              "omid_message_args",
            module$exports$omid$common$InternalMessage = function (e, o, t, n) {
              (this.guid = e),
                (this.method = o),
                (this.version = t),
                (this.args = n);
            };
          (module$exports$omid$common$InternalMessage.isValidSerializedMessage =
            function (e) {
              return (
                !!e &&
                void 0 !==
                  e[module$contents$omid$common$InternalMessage_GUID_KEY] &&
                void 0 !==
                  e[module$contents$omid$common$InternalMessage_METHOD_KEY] &&
                void 0 !==
                  e[module$contents$omid$common$InternalMessage_VERSION_KEY] &&
                "string" ==
                  typeof e[
                    module$contents$omid$common$InternalMessage_GUID_KEY
                  ] &&
                "string" ==
                  typeof e[
                    module$contents$omid$common$InternalMessage_METHOD_KEY
                  ] &&
                "string" ==
                  typeof e[
                    module$contents$omid$common$InternalMessage_VERSION_KEY
                  ] &&
                (void 0 ===
                  e[module$contents$omid$common$InternalMessage_ARGS_KEY] ||
                  void 0 !==
                    e[module$contents$omid$common$InternalMessage_ARGS_KEY])
              );
            }),
            (module$exports$omid$common$InternalMessage.deserialize = function (
              e
            ) {
              return new module$exports$omid$common$InternalMessage(
                e[module$contents$omid$common$InternalMessage_GUID_KEY],
                e[module$contents$omid$common$InternalMessage_METHOD_KEY],
                e[module$contents$omid$common$InternalMessage_VERSION_KEY],
                e[module$contents$omid$common$InternalMessage_ARGS_KEY]
              );
            }),
            (module$exports$omid$common$InternalMessage.prototype.serialize =
              function () {
                var e = {};
                return (
                  (e[module$contents$omid$common$InternalMessage_GUID_KEY] =
                    this.guid),
                  (e[module$contents$omid$common$InternalMessage_METHOD_KEY] =
                    this.method),
                  (e[module$contents$omid$common$InternalMessage_VERSION_KEY] =
                    this.version),
                  (e = e),
                  void 0 !== this.args &&
                    (e[module$contents$omid$common$InternalMessage_ARGS_KEY] =
                      this.args),
                  e
                );
              });
          var module$exports$omid$common$Communication = function (e) {
            (this.to = e),
              (this.communicationType_ =
                module$exports$omid$common$constants.CommunicationType.NONE);
          };
          (module$exports$omid$common$Communication.prototype.sendMessage =
            function (e, o) {}),
            (module$exports$omid$common$Communication.prototype.handleMessage =
              function (e, o) {
                this.onMessage && this.onMessage(e, o);
              }),
            (module$exports$omid$common$Communication.prototype.serialize =
              function (e) {
                return JSON.stringify(e);
              }),
            (module$exports$omid$common$Communication.prototype.deserialize =
              function (e) {
                return JSON.parse(e);
              }),
            (module$exports$omid$common$Communication.prototype.isDirectCommunication =
              function () {
                return (
                  this.communicationType_ ===
                  module$exports$omid$common$constants.CommunicationType.DIRECT
                );
              }),
            (module$exports$omid$common$Communication.prototype.isCrossOrigin =
              function () {});
          var module$exports$omid$common$DetectOmid = {
              OMID_PRESENT_FRAME_NAME: "omid_v1_present",
              isOmidPresent: function (e) {
                try {
                  return (
                    !!e.frames &&
                    !!e.frames[
                      module$exports$omid$common$DetectOmid
                        .OMID_PRESENT_FRAME_NAME
                    ]
                  );
                } catch (e) {
                  return !1;
                }
              },
              declareOmidPresence: function (e) {
                e.frames &&
                  e.document &&
                  (module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME in
                    e.frames ||
                    (null == e.document.body &&
                    module$exports$omid$common$DetectOmid.isMutationObserverAvailable_(
                      e
                    )
                      ? module$exports$omid$common$DetectOmid.registerMutationObserver_(
                          e
                        )
                      : e.document.body
                      ? module$exports$omid$common$DetectOmid.appendPresenceIframe_(
                          e
                        )
                      : e.document.write(
                          '<iframe style="display:none" id="' +
                            module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME +
                            '" name="' +
                            module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME +
                            '"></iframe>'
                        )));
              },
              appendPresenceIframe_: function (e) {
                var o = e.document.createElement("iframe");
                (o.id =
                  module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME),
                  (o.name =
                    module$exports$omid$common$DetectOmid.OMID_PRESENT_FRAME_NAME),
                  (o.style.display = "none"),
                  e.document.body.appendChild(o);
              },
              isMutationObserverAvailable_: function (e) {
                return "MutationObserver" in e;
              },
              registerMutationObserver_: function (e) {
                var o = new MutationObserver(function (t) {
                  t.forEach(function (t) {
                    "BODY" === t.addedNodes[0].nodeName &&
                      (module$exports$omid$common$DetectOmid.appendPresenceIframe_(
                        e
                      ),
                      o.disconnect());
                  });
                });
                o.observe(e.document.documentElement, { childList: !0 });
              },
            },
            module$exports$omid$common$DirectCommunication = function (e) {
              module$exports$omid$common$Communication.call(this, e),
                (this.communicationType_ =
                  module$exports$omid$common$constants.CommunicationType.DIRECT),
                (this.handleExportedMessage =
                  module$exports$omid$common$DirectCommunication.prototype.handleExportedMessage.bind(
                    this
                  ));
            };
          $jscomp.inherits(
            module$exports$omid$common$DirectCommunication,
            module$exports$omid$common$Communication
          ),
            (module$exports$omid$common$DirectCommunication.prototype.sendMessage =
              function (e, o) {
                if (!(o = void 0 === o ? this.to : o))
                  throw Error(
                    "Message destination must be defined at construction time or when sending the message."
                  );
                o.handleExportedMessage(e.serialize(), this);
              }),
            (module$exports$omid$common$DirectCommunication.prototype.handleExportedMessage =
              function (e, o) {
                module$exports$omid$common$InternalMessage.isValidSerializedMessage(
                  e
                ) &&
                  this.handleMessage(
                    module$exports$omid$common$InternalMessage.deserialize(e),
                    o
                  );
              }),
            (module$exports$omid$common$DirectCommunication.prototype.isCrossOrigin =
              function () {
                return !1;
              });
          var module$exports$omid$common$eventTypedefs = {},
            module$exports$omid$common$exporter = {};
          function module$contents$omid$common$exporter_getOmidExports() {
            return void 0 === omidExports ? null : omidExports;
          }
          function module$contents$omid$common$exporter_getOrCreateName(e, o) {
            return e && (e[o] || (e[o] = {}));
          }
          module$exports$omid$common$exporter.packageExport = function (
            e,
            o,
            t
          ) {
            (t =
              void 0 === t
                ? module$contents$omid$common$exporter_getOmidExports()
                : t) &&
              ((e = e.split("."))
                .slice(0, e.length - 1)
                .reduce(
                  module$contents$omid$common$exporter_getOrCreateName,
                  t
                )[e[e.length - 1]] = o);
          };
          var module$exports$omid$common$guid = {
              generateGuid: function () {
                return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
                  /[xy]/g,
                  function (e) {
                    var o = (16 * Math.random()) | 0;
                    return (e =
                      "y" === e ? ((3 & o) | 8).toString(16) : o.toString(16));
                  }
                );
              },
            },
            module$exports$omid$common$logger = {
              error: function (e) {
                for (var o = [], t = 0; t < arguments.length; ++t)
                  o[t - 0] = arguments[t];
                module$contents$omid$common$logger_executeLog(
                  function () {
                    throw new (Function.prototype.bind.apply(
                      Error,
                      [
                        null,
                        "Could not complete the test successfully - ",
                      ].concat($jscomp.arrayFromIterable(o))
                    ))();
                  },
                  function () {
                    return console.error.apply(
                      console,
                      $jscomp.arrayFromIterable(o)
                    );
                  }
                );
              },
              debug: function (e) {
                for (var o = [], t = 0; t < arguments.length; ++t)
                  o[t - 0] = arguments[t];
                module$contents$omid$common$logger_executeLog(
                  function () {},
                  function () {
                    return console.error.apply(
                      console,
                      $jscomp.arrayFromIterable(o)
                    );
                  }
                );
              },
            };
          function module$contents$omid$common$logger_executeLog(e, o) {
            "undefined" != typeof jasmine && jasmine
              ? e()
              : "undefined" != typeof console &&
                console &&
                console.error &&
                o();
          }
          var module$exports$omid$common$OmidGlobalProvider = {},
            module$contents$omid$common$OmidGlobalProvider_globalThis =
              eval("this");
          function module$contents$omid$common$OmidGlobalProvider_getOmidGlobal() {
            if (void 0 !== omidGlobal && omidGlobal) return omidGlobal;
            if (void 0 !== global && global) return global;
            if ("undefined" != typeof window && window) return window;
            if (
              void 0 !==
                module$contents$omid$common$OmidGlobalProvider_globalThis &&
              module$contents$omid$common$OmidGlobalProvider_globalThis
            )
              return module$contents$omid$common$OmidGlobalProvider_globalThis;
            throw Error("Could not determine global object context.");
          }
          module$exports$omid$common$OmidGlobalProvider.omidGlobal =
            module$contents$omid$common$OmidGlobalProvider_getOmidGlobal();
          var module$exports$omid$common$windowUtils = {};
          function module$contents$omid$common$windowUtils_isValidWindow(e) {
            return null != e && void 0 !== e.top && null != e.top;
          }
          function module$contents$omid$common$windowUtils_isSameOriginForIE(
            e
          ) {
            return "" === e.x || "" !== e.x;
          }
          (module$exports$omid$common$windowUtils.isCrossOrigin = function (e) {
            if (e === module$exports$omid$common$OmidGlobalProvider.omidGlobal)
              return !1;
            try {
              if (void 0 === e.location.hostname) return !0;
              module$contents$omid$common$windowUtils_isSameOriginForIE(e);
            } catch (e) {
              return !0;
            }
            return !1;
          }),
            (module$exports$omid$common$windowUtils.resolveGlobalContext =
              function (e) {
                return (
                  void 0 === e &&
                    "undefined" != typeof window &&
                    window &&
                    (e = window),
                  module$contents$omid$common$windowUtils_isValidWindow(e)
                    ? e
                    : module$exports$omid$common$OmidGlobalProvider.omidGlobal
                );
              }),
            (module$exports$omid$common$windowUtils.resolveTopWindowContext =
              function (e) {
                return module$contents$omid$common$windowUtils_isValidWindow(e)
                  ? e.top
                  : module$exports$omid$common$OmidGlobalProvider.omidGlobal;
              }),
            (module$exports$omid$common$windowUtils.evaluatePageUrl = function (
              e
            ) {
              if (!module$contents$omid$common$windowUtils_isValidWindow(e))
                return null;
              try {
                var o = e.top;
                return (0,
                module$exports$omid$common$windowUtils.isCrossOrigin)(o)
                  ? null
                  : o.location.href;
              } catch (e) {
                return null;
              }
            });
          var module$exports$omid$common$PostMessageCommunication = function (
            e,
            o
          ) {
            (o =
              void 0 === o
                ? module$exports$omid$common$OmidGlobalProvider.omidGlobal
                : o),
              module$exports$omid$common$Communication.call(this, o);
            var t = this;
            (this.communicationType_ =
              module$exports$omid$common$constants.CommunicationType.POST_MESSAGE),
              e.addEventListener("message", function (e) {
                if ("object" == typeof e.data) {
                  var o = e.data;
                  module$exports$omid$common$InternalMessage.isValidSerializedMessage(
                    o
                  ) &&
                    ((o =
                      module$exports$omid$common$InternalMessage.deserialize(
                        o
                      )),
                    e.source && t.handleMessage(o, e.source));
                }
              });
          };
          $jscomp.inherits(
            module$exports$omid$common$PostMessageCommunication,
            module$exports$omid$common$Communication
          ),
            (module$exports$omid$common$PostMessageCommunication.isCompatibleContext =
              function (e) {
                return !!(e && e.addEventListener && e.postMessage);
              }),
            (module$exports$omid$common$PostMessageCommunication.prototype.sendMessage =
              function (e, o) {
                if (!(o = void 0 === o ? this.to : o))
                  throw Error(
                    "Message destination must be defined at construction time or when sending the message."
                  );
                o.postMessage(e.serialize(), "*");
              }),
            (module$exports$omid$common$PostMessageCommunication.prototype.isCrossOrigin =
              function () {
                return (
                  !this.to ||
                  (0, module$exports$omid$common$windowUtils.isCrossOrigin)(
                    this.to
                  )
                );
              });
          var module$exports$omid$common$Rectangle = function (e, o, t, n) {
              (this.x = e), (this.y = o), (this.width = t), (this.height = n);
            },
            module$exports$omid$common$serviceCommunication = {},
            module$contents$omid$common$serviceCommunication_EXPORTED_SESSION_COMMUNICATION_NAME =
              ["omid", "v1_SessionServiceCommunication"],
            module$contents$omid$common$serviceCommunication_EXPORTED_VERIFICATION_COMMUNICATION_NAME =
              ["omid", "v1_VerificationServiceCommunication"],
            module$contents$omid$common$serviceCommunication_EXPORTED_SERVICE_WINDOW_NAME =
              ["omidVerificationProperties", "serviceWindow"];
          function module$contents$omid$common$serviceCommunication_getValueForKeypath(
            e,
            o
          ) {
            return o.reduce(function (e, o) {
              return e && e[o];
            }, e);
          }
          function module$contents$omid$common$serviceCommunication_startServiceCommunication(
            e,
            o,
            t,
            n
          ) {
            if (!(0, module$exports$omid$common$windowUtils.isCrossOrigin)(o))
              try {
                var i =
                  module$contents$omid$common$serviceCommunication_getValueForKeypath(
                    o,
                    t
                  );
                if (i)
                  return new module$exports$omid$common$DirectCommunication(i);
              } catch (e) {}
            return n(o)
              ? new module$exports$omid$common$PostMessageCommunication(e, o)
              : null;
          }
          function module$contents$omid$common$serviceCommunication_startServiceCommunicationFromCandidates(
            e,
            o,
            t,
            n
          ) {
            for (
              var i = (o = $jscomp.makeIterator(o)).next();
              !i.done;
              i = o.next()
            )
              if (
                (i =
                  module$contents$omid$common$serviceCommunication_startServiceCommunication(
                    e,
                    i.value,
                    t,
                    n
                  ))
              )
                return i;
            return null;
          }
          (module$exports$omid$common$serviceCommunication.startSessionServiceCommunication =
            function (e, o, t) {
              t =
                void 0 === t
                  ? module$exports$omid$common$DetectOmid.isOmidPresent
                  : t;
              var n = [
                e,
                (0,
                module$exports$omid$common$windowUtils.resolveTopWindowContext)(
                  e
                ),
              ];
              return (
                o && n.unshift(o),
                module$contents$omid$common$serviceCommunication_startServiceCommunicationFromCandidates(
                  e,
                  n,
                  module$contents$omid$common$serviceCommunication_EXPORTED_SESSION_COMMUNICATION_NAME,
                  t
                )
              );
            }),
            (module$exports$omid$common$serviceCommunication.startVerificationServiceCommunication =
              function (e, o) {
                o =
                  void 0 === o
                    ? module$exports$omid$common$DetectOmid.isOmidPresent
                    : o;
                var t = [],
                  n =
                    module$contents$omid$common$serviceCommunication_getValueForKeypath(
                      e,
                      module$contents$omid$common$serviceCommunication_EXPORTED_SERVICE_WINDOW_NAME
                    );
                return (
                  n && t.push(n),
                  t.push(
                    (0,
                    module$exports$omid$common$windowUtils.resolveTopWindowContext)(
                      e
                    )
                  ),
                  module$contents$omid$common$serviceCommunication_startServiceCommunicationFromCandidates(
                    e,
                    t,
                    module$contents$omid$common$serviceCommunication_EXPORTED_VERIFICATION_COMMUNICATION_NAME,
                    o
                  )
                );
              });
          var module$exports$omid$common$VastProperties = function (
            e,
            o,
            t,
            n
          ) {
            (this.isSkippable = e),
              (this.skipOffset = o),
              (this.isAutoPlay = t),
              (this.position = n);
          };
          module$exports$omid$common$VastProperties.prototype.toJSON =
            function () {
              return {
                isSkippable: this.isSkippable,
                skipOffset: this.skipOffset,
                isAutoPlay: this.isAutoPlay,
                position: this.position,
              };
            };
          var module$exports$omid$common$version = {
              ApiVersion: "1.0",
              Version: "1.3.2",
            },
            module$contents$omid$verificationClient$VerificationClient_VERIFICATION_CLIENT_VERSION =
              module$exports$omid$common$version.Version,
            module$contents$omid$verificationClient$VerificationClient_EventCallback;
          function module$contents$omid$verificationClient$VerificationClient_getThirdPartyOmid() {
            var e =
              module$exports$omid$common$OmidGlobalProvider.omidGlobal.omid3p;
            return e &&
              "function" == typeof e.registerSessionObserver &&
              "function" == typeof e.addEventListener
              ? e
              : null;
          }
          var module$exports$omid$verificationClient$VerificationClient =
            function (e) {
              (this.communication =
                e ||
                (0,
                module$exports$omid$common$serviceCommunication.startVerificationServiceCommunication)(
                  (0,
                  module$exports$omid$common$windowUtils.resolveGlobalContext)()
                ))
                ? (this.communication.onMessage =
                    this.handleMessage_.bind(this))
                : (e =
                    module$contents$omid$verificationClient$VerificationClient_getThirdPartyOmid()) &&
                  (this.omid3p = e),
                (this.remoteIntervals_ = this.remoteTimeouts_ = 0),
                (this.callbackMap_ = {}),
                (this.imgCache_ = []),
                (this.injectionId_ = (e =
                  module$exports$omid$common$OmidGlobalProvider.omidGlobal
                    .omidVerificationProperties)
                  ? e.injectionId
                  : void 0);
            };
          (module$exports$omid$verificationClient$VerificationClient.prototype.isSupported =
            function () {
              return !(!this.communication && !this.omid3p);
            }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.registerSessionObserver =
              function (e, o) {
                (0, module$exports$omid$common$argsChecker.assertFunction)(
                  "functionToExecute",
                  e
                ),
                  this.omid3p
                    ? this.omid3p.registerSessionObserver(
                        e,
                        o,
                        this.injectionId_
                      )
                    : this.sendMessage_(
                        "addSessionListener",
                        e,
                        o,
                        this.injectionId_
                      );
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.addEventListener =
              function (e, o) {
                (0, module$exports$omid$common$argsChecker.assertTruthyString)(
                  "eventType",
                  e
                ),
                  (0, module$exports$omid$common$argsChecker.assertFunction)(
                    "functionToExecute",
                    o
                  ),
                  this.omid3p
                    ? this.omid3p.addEventListener(e, o)
                    : this.sendMessage_("addEventListener", o, e);
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.sendUrl =
              function (e, o, t) {
                (0, module$exports$omid$common$argsChecker.assertTruthyString)(
                  "url",
                  e
                ),
                  module$exports$omid$common$OmidGlobalProvider.omidGlobal
                    .document &&
                  module$exports$omid$common$OmidGlobalProvider.omidGlobal
                    .document.createElement
                    ? this.sendUrlWithImg_(e, o, t)
                    : this.sendMessage_(
                        "sendUrl",
                        function (e) {
                          e && o ? o() : !e && t && t();
                        },
                        e
                      );
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.sendUrlWithImg_ =
              function (e, o, t) {
                var n = this,
                  i =
                    module$exports$omid$common$OmidGlobalProvider.omidGlobal.document.createElement(
                      "img"
                    );
                this.imgCache_.push(i);
                var r = function (e) {
                  var o = n.imgCache_.indexOf(i);
                  0 <= o && n.imgCache_.splice(o, 1), e && e();
                };
                i.addEventListener("load", r.bind(this, o)),
                  i.addEventListener("error", r.bind(this, t)),
                  (i.src = e);
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.injectJavaScriptResource =
              function (e, o, t) {
                var n = this;
                (0, module$exports$omid$common$argsChecker.assertTruthyString)(
                  "url",
                  e
                ),
                  module$exports$omid$common$OmidGlobalProvider.omidGlobal
                    .document
                    ? this.injectJavascriptResourceUrlInDom_(e, o, t)
                    : this.sendMessage_(
                        "injectJavaScriptResource",
                        function (i, r) {
                          i
                            ? (n.evaluateJavaScript_(r, e), o())
                            : (module$exports$omid$common$logger.error(
                                "Service failed to load JavaScript resource."
                              ),
                              t());
                        },
                        e
                      );
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.injectJavascriptResourceUrlInDom_ =
              function (e, o, t) {
                var n =
                    module$exports$omid$common$OmidGlobalProvider.omidGlobal
                      .document,
                  i = n.body;
                ((n = n.createElement("script")).onload = o),
                  (n.onerror = t),
                  (n.src = e),
                  (n.type = "application/javascript"),
                  i.appendChild(n);
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.evaluateJavaScript_ =
              function (a, b) {
                try {
                  eval(a);
                } catch (e) {
                  module$exports$omid$common$logger.error(
                    'Error evaluating the JavaScript resource from "' + b + '".'
                  );
                }
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.setTimeout =
              function (e, o) {
                if (
                  ((0, module$exports$omid$common$argsChecker.assertFunction)(
                    "functionToExecute",
                    e
                  ),
                  (0,
                  module$exports$omid$common$argsChecker.assertPositiveNumber)(
                    "timeInMillis",
                    o
                  ),
                  this.hasTimeoutMethods_())
                )
                  return module$exports$omid$common$OmidGlobalProvider.omidGlobal.setTimeout(
                    e,
                    o
                  );
                var t = this.remoteTimeouts_++;
                return this.sendMessage_("setTimeout", e, t, o), t;
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.clearTimeout =
              function (e) {
                (0,
                module$exports$omid$common$argsChecker.assertPositiveNumber)(
                  "timeoutId",
                  e
                ),
                  this.hasTimeoutMethods_()
                    ? module$exports$omid$common$OmidGlobalProvider.omidGlobal.clearTimeout(
                        e
                      )
                    : this.sendOneWayMessage_("clearTimeout", e);
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.setInterval =
              function (e, o) {
                if (
                  ((0, module$exports$omid$common$argsChecker.assertFunction)(
                    "functionToExecute",
                    e
                  ),
                  (0,
                  module$exports$omid$common$argsChecker.assertPositiveNumber)(
                    "timeInMillis",
                    o
                  ),
                  this.hasIntervalMethods_())
                )
                  return module$exports$omid$common$OmidGlobalProvider.omidGlobal.setInterval(
                    e,
                    o
                  );
                var t = this.remoteIntervals_++;
                return this.sendMessage_("setInterval", e, t, o), t;
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.clearInterval =
              function (e) {
                (0,
                module$exports$omid$common$argsChecker.assertPositiveNumber)(
                  "intervalId",
                  e
                ),
                  this.hasIntervalMethods_()
                    ? module$exports$omid$common$OmidGlobalProvider.omidGlobal.clearInterval(
                        e
                      )
                    : this.sendOneWayMessage_("clearInterval", e);
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.hasTimeoutMethods_ =
              function () {
                return (
                  "function" ==
                    typeof module$exports$omid$common$OmidGlobalProvider
                      .omidGlobal.setTimeout &&
                  "function" ==
                    typeof module$exports$omid$common$OmidGlobalProvider
                      .omidGlobal.clearTimeout
                );
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.hasIntervalMethods_ =
              function () {
                return (
                  "function" ==
                    typeof module$exports$omid$common$OmidGlobalProvider
                      .omidGlobal.setInterval &&
                  "function" ==
                    typeof module$exports$omid$common$OmidGlobalProvider
                      .omidGlobal.clearInterval
                );
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.handleMessage_ =
              function (e, o) {
                o = e.method;
                var t = e.guid;
                if (((e = e.args), "response" === o && this.callbackMap_[t])) {
                  var n = (0,
                  module$exports$omid$common$ArgsSerDe.deserializeMessageArgs)(
                    module$contents$omid$verificationClient$VerificationClient_VERIFICATION_CLIENT_VERSION,
                    e
                  );
                  this.callbackMap_[t].apply(this, n);
                }
                "error" === o &&
                  window.console &&
                  module$exports$omid$common$logger.error(e);
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.sendOneWayMessage_ =
              function (e, o) {
                for (var t = [], n = 1; n < arguments.length; ++n)
                  t[n - 1] = arguments[n];
                this.sendMessage_.apply(
                  this,
                  [e, null].concat($jscomp.arrayFromIterable(t))
                );
              }),
            (module$exports$omid$verificationClient$VerificationClient.prototype.sendMessage_ =
              function (e, o, t) {
                for (var n = [], i = 2; i < arguments.length; ++i)
                  n[i - 2] = arguments[i];
                this.communication &&
                  ((i = (0, module$exports$omid$common$guid.generateGuid)()),
                  o && (this.callbackMap_[i] = o),
                  (n = new module$exports$omid$common$InternalMessage(
                    i,
                    "VerificationService." + e,
                    module$contents$omid$verificationClient$VerificationClient_VERIFICATION_CLIENT_VERSION,
                    (0,
                    module$exports$omid$common$ArgsSerDe.serializeMessageArgs)(
                      module$contents$omid$verificationClient$VerificationClient_VERIFICATION_CLIENT_VERSION,
                      n
                    )
                  )),
                  this.communication.sendMessage(n));
              }),
            (0, module$exports$omid$common$exporter.packageExport)(
              "OmidVerificationClient",
              module$exports$omid$verificationClient$VerificationClient
            );
        },
        exports
      );
    }.call(this, __webpack_require__(5)));
  },
  function (e, o) {
    var t;
    t = (function () {
      return this;
    })();
    try {
      t = t || new Function("return this")();
    } catch (e) {
      "object" == typeof window && (t = window);
    }
    e.exports = t;
  },
  function (e, o) {
    function t(e, o) {
      for (var t = 0; t < o.length; t++) {
        var n = o[t];
        (n.enumerable = n.enumerable || !1),
          (n.configurable = !0),
          "value" in n && (n.writable = !0),
          Object.defineProperty(e, n.key, n);
      }
    }
    e.exports = function (e, o, n) {
      return o && t(e.prototype, o), n && t(e, n), e;
    };
  },
  function (e, o) {
    e.exports = function (e) {
      if (Array.isArray(e)) return e;
    };
  },
  function (e, o) {
    e.exports = function (e, o) {
      if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) {
        var t = [],
          n = !0,
          i = !1,
          r = void 0;
        try {
          for (
            var m, s = e[Symbol.iterator]();
            !(n = (m = s.next()).done) &&
            (t.push(m.value), !o || t.length !== o);
            n = !0
          );
        } catch (e) {
          (i = !0), (r = e);
        } finally {
          try {
            n || null == s.return || s.return();
          } finally {
            if (i) throw r;
          }
        }
        return t;
      }
    };
  },
  function (e, o, t) {
    var n = t(10);
    e.exports = function (e, o) {
      if (e) {
        if ("string" == typeof e) return n(e, o);
        var t = Object.prototype.toString.call(e).slice(8, -1);
        return (
          "Object" === t && e.constructor && (t = e.constructor.name),
          "Map" === t || "Set" === t
            ? Array.from(t)
            : "Arguments" === t ||
              /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
            ? n(e, o)
            : void 0
        );
      }
    };
  },
  function (e, o) {
    e.exports = function (e, o) {
      (null == o || o > e.length) && (o = e.length);
      for (var t = 0, n = new Array(o); t < o; t++) n[t] = e[t];
      return n;
    };
  },
  function (e, o) {
    e.exports = function () {
      throw new TypeError(
        "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
      );
    };
  },
  function (e, o, t) {
    "use strict";
    (function (e) {
      t.d(o, "b", function () {
        return b;
      });
      var n = t(1),
        i = t.n(n),
        r = t(3),
        m = t.n(r),
        s = t(0),
        a = t.n(s),
        c = Symbol("_omidAdapter"),
        l = Symbol("_latencyMap"),
        d = Symbol("_getLatency"),
        u = Symbol("_reportError"),
        $ = Symbol("_adID"),
        p = Symbol("_isWinPerf"),
        f = Symbol("_isDte"),
        h = Symbol("_eventSequence"),
        v = Symbol("_playerStateData"),
        y = Symbol("_eventShortName");
      function b(e) {
        var o = e.indexOf("/", 8),
          t = e.substring(0, o),
          n = e.substring(o, e.length);
        return (
          "https://www.twitch.tv/r/c/" +
          (function (e) {
            var o = 0;
            if (0 === e.length) return o;
            for (var t = 0; t < e.length; t += 1)
              (o = (o << 5) - o + e.charCodeAt(t)), (o |= 0);
            return o;
          })(t) +
          n
        );
      }
      o.a = function o(t, n, r) {
        var s = this;
        m()(this, o),
          a()(this, "clearEventData", function (e) {
            var o = "missingEvent",
              t = "missing",
              n = [],
              r = [];
            if (
              e &&
              ((o = "missingEventData"),
              e.data && ((o = "missingAdView"), e.data.adView))
            ) {
              var m = e.data.adView;
              (o =
                void 0 !== m.percentageInView
                  ? m.percentageInView
                  : "undefined"),
                (t = i()(m.percentageInView)),
                m.onScreenGeometry &&
                  void 0 !== m.onScreenGeometry.obstructions &&
                  (r = m.onScreenGeometry.obstructions),
                void 0 !== m.reasons && (n = m.reasons);
            }
            return {
              reasons: n,
              obstructions: r,
              percentageInView: o,
              percentageInViewDataType: t,
            };
          }),
          a()(this, "addEventSequence", function (e, o, t) {
            var n = s[y][e];
            if (void 0 !== n) {
              var i,
                r,
                m = { en: n, et: o, vf: t },
                a = s[h].length;
              if (0 === a || "gc" !== n) s[h].push(m);
              else {
                var c = s[h][a - 1];
                "gc" !== c.en && "v" !== c.en && "atf" !== c.en
                  ? s[h].push(m)
                  : (i = c.vf) === (r = t) ||
                    (i > 0 && i < 0.5 && r > 0 && r < 0.5) ||
                    (i >= 0.5 && i <= 1 && r >= 0.5 && r <= 1) ||
                    s[h].push(m);
              }
            }
          }),
          a()(this, "addPlayerStateData", function (e) {
            var o = {
              pState: e && e.data && e.data.state ? e.data.state : "undefined",
              et: e && e.timestamp ? e.timestamp : 0,
            };
            s[v].push(o);
          }),
          a()(this, "getPlayerStateData", function () {
            return s[v];
          }),
          a()(this, "getEventSequence", function () {
            return s[h];
          }),
          a()(this, "checkWinPerfAPI", function () {
            return (
              "undefined" != typeof window &&
              window.performance &&
              window.performance.mark &&
              "function" == typeof window.performance.mark
            );
          }),
          a()(this, "checkDateFunction", function () {
            return "function" == typeof Date;
          }),
          a()(this, "startLatencyForParam", function (e) {
            try {
              s[p]
                ? window.performance.mark("".concat(e, "Start").concat(s[$]))
                : void 0 === s[l].get("".concat(e, "Start").concat(s[$])) &&
                  s[l].set(
                    "".concat(e, "Start").concat(s[$]),
                    s.getTimeStamp()
                  );
            } catch (e) {
              s[u].reportClientError(e);
            }
          }),
          a()(this, "endLatencyForParam", function (e) {
            s[p]
              ? (window.performance.mark("".concat(e, "End").concat(s[$])),
                0 !==
                  window.performance.getEntriesByName(
                    "".concat(e, "Start").concat(s[$])
                  ).length &&
                  window.performance.measure(
                    "".concat(e).concat(s[$]),
                    "".concat(e, "Start").concat(s[$]),
                    "".concat(e, "End").concat(s[$])
                  ))
              : void 0 !== s[l].get("".concat(e, "Start").concat(s[$])) &&
                (s[l].set("".concat(e, "End").concat(s[$]), s.getTimeStamp()),
                s.latencyMeasureQueue.push({
                  name: "".concat(e).concat(s[$]),
                  duration: s[d](e),
                }));
          }),
          a()(this, "getTimeStamp", function () {
            return s[p] ? performance.now() : s[f] ? Date.now() : void 0;
          }),
          a()(this, d, function (e) {
            return (
              s[l].get("".concat(e, "End").concat(s[$])) -
              s[l].get("".concat(e, "Start").concat(s[$]))
            );
          }),
          a()(this, "setTimeout", function (e, o) {
            return s[c].setTimeout(function () {
              try {
                e();
              } catch (e) {
                s[u].reportClientError(e);
              }
            }, o);
          }),
          a()(this, "setInterval", function (e, o) {
            return s[c].setInterval(function () {
              try {
                e();
              } catch (e) {
                s[u].reportClientError(e);
              }
            }, o);
          }),
          a()(this, "getVisibilityState", function (e) {
            try {
              var o = e || document;
              return void 0 === o.visibilityState
                ? "Unknown"
                : o.visibilityState;
            } catch (e) {
              return "Unknown";
            }
          }),
          a()(this, "dispatchCustomEvent", function (o) {
            try {
              var t =
                (void 0 !== e && e && e.document) ||
                ("undefined" != typeof window && window && window.document) ||
                ("undefined" != typeof globalThis &&
                  globalThis &&
                  globalThis.document) ||
                ("undefined" != typeof document && document) ||
                null;
              t &&
                (t.dispatchEvent
                  ? t.dispatchEvent(s.createEvent(t, o))
                  : t[o]
                  ? t[o]()
                  : t["on".concat(o)] && t["on".concat(o)]());
            } catch (e) {}
          }),
          a()(this, "createEvent", function (e, o) {
            if (e.createEvent) {
              var t = e.createEvent("Event");
              return t.initEvent(o, !0, !0), t;
            }
            var n = e.createEventObject();
            return (n.eventType = o), n;
          }),
          (this[c] = t),
          (this[l] = new Map()),
          (this[u] = n),
          (this[p] = this.checkWinPerfAPI()),
          (this[f] = this.checkDateFunction()),
          (this.latencyMeasureQueue = []),
          (this[$] = r),
          (this[v] = []),
          (this[h] = []),
          (this[y] = {
            impression: "im",
            geometryChange: "gc",
            loaded: "ld",
            start: "st",
            pause: "pa",
            resume: "re",
            skipped: "sk",
            complete: "cm",
            atf: "atf",
            v: "v",
          });
      };
    }.call(this, t(5)));
  },
  function (e, o, t) {
    "use strict";
    (function (e) {
      var n = t(1),
        i = t.n(n),
        r = t(2),
        m = t.n(r),
        s = t(3),
        a = t.n(s),
        c = t(6),
        l = t.n(c),
        d = t(0),
        u = t.n(d),
        $ = t(16),
        p = t(14),
        f = t(15),
        h = t(12),
        v = t(4);
      function y(e) {
        if ("undefined" == typeof Symbol || null == e[Symbol.iterator]) {
          if (
            Array.isArray(e) ||
            (e = (function (e, o) {
              if (!e) return;
              if ("string" == typeof e) return b(e, o);
              var t = Object.prototype.toString.call(e).slice(8, -1);
              "Object" === t && e.constructor && (t = e.constructor.name);
              if ("Map" === t || "Set" === t) return Array.from(t);
              if (
                "Arguments" === t ||
                /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t)
              )
                return b(e, o);
            })(e))
          ) {
            var o = 0,
              t = function () {};
            return {
              s: t,
              n: function () {
                return o >= e.length
                  ? { done: !0 }
                  : { done: !1, value: e[o++] };
              },
              e: function (e) {
                throw e;
              },
              f: t,
            };
          }
          throw new TypeError(
            "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
          );
        }
        var n,
          i,
          r = !0,
          m = !1;
        return {
          s: function () {
            n = e[Symbol.iterator]();
          },
          n: function () {
            var e = n.next();
            return (r = e.done), e;
          },
          e: function (e) {
            (m = !0), (i = e);
          },
          f: function () {
            try {
              r || null == n.return || n.return();
            } finally {
              if (m) throw i;
            }
          },
        };
      }
      function b(e, o) {
        (null == o || o > e.length) && (o = e.length);
        for (var t = 0, n = new Array(o); t < o; t++) n[t] = e[t];
        return n;
      }
      var g = Symbol("_pixelQueue"),
        _ = Symbol("_utils"),
        S = Symbol("_reportError"),
        E = Symbol("_omidAdapter"),
        x = Symbol("_adID"),
        I = Symbol("_errorStr"),
        O = Symbol("_reportPerfMetrics"),
        C = Symbol("_startViewComp"),
        T = Symbol("_sessionObsCallback"),
        w = Symbol("_setup"),
        M = Symbol("_reportOMSupport"),
        P = Symbol("_initParams"),
        V = (function () {
          function o() {
            var t = this;
            a()(this, o),
              u()(this, O, function () {
                var e = null,
                  o = { mtd: null };
                t[_].checkWinPerfAPI()
                  ? ((e = window.performance.getEntriesByType("measure")),
                    (o.mtd = "win"))
                  : ((e = t[_].latencyMeasureQueue), (o.mtd = "prim"));
                for (var n = 0; n < e.length; n += 1) {
                  var i = e[n];
                  if (i.name.endsWith(t[x]))
                    o[i.name.substring(0, i.name.length - t[x].length)] =
                      i.duration.toFixed(2);
                }
                Object.keys(o).length > 1 && t[g].addPixel(o);
              }),
              u()(this, P, function () {
                var o = {};
                try {
                  var n =
                    (void 0 !== e && e && e.document) ||
                    ("undefined" != typeof window &&
                      window &&
                      window.document) ||
                    ("undefined" != typeof globalThis &&
                      globalThis &&
                      globalThis.document) ||
                    ("undefined" != typeof document && document) ||
                    null;
                  if (n && n.currentScript) {
                    var i = n.currentScript.src.split("?")[1];
                    if (i) {
                      var r,
                        s = y(i.split("&"));
                      try {
                        for (s.s(); !(r = s.n()).done; ) {
                          var a = r.value.split("="),
                            c = m()(a, 2),
                            l = c[0],
                            d = c[1];
                          o[l] = decodeURIComponent(d);
                        }
                      } catch (e) {
                        s.e(e);
                      } finally {
                        s.f();
                      }
                    }
                  }
                } catch (e) {
                  t[I] = e.message;
                }
                return o;
              }),
              u()(this, T, function (e, o) {
                if (
                  "sessionStart" === e.type &&
                  e.data &&
                  "object" === i()(e.data) &&
                  e.data.verificationParameters
                ) {
                  var n = JSON.parse(e.data.verificationParameters);
                  for (var r in n) void 0 === o[r] && (o[r] = n[r]);
                  if (
                    ((t[g] = new p.a(t[E])),
                    t[g].setPixelParams(o),
                    (t[S] = new f.a(t[g])),
                    t[I] && t[S])
                  ) {
                    var m = new Error(t[I]);
                    (m.stack = null), t[S].reportClientError(m);
                  }
                  t[w](e.data);
                }
              }),
              u()(this, w, function () {
                var e =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : null;
                try {
                  (t[x] = Math.round(1e7 * Math.random()).toString()),
                    (t[_] = new h.a(t[E], t[S], t[x])),
                    t[M](e),
                    t[C]();
                } catch (e) {
                  t[S].reportClientError(e);
                }
              }),
              u()(this, M, function () {
                var e =
                    arguments.length > 0 && void 0 !== arguments[0]
                      ? arguments[0]
                      : null,
                  o = {},
                  n = null,
                  i = null;
                e &&
                  e.context &&
                  ((n = e.context.omidJsInfo), (i = e.context.omidNativeInfo)),
                  (o = { om: !0, omidJsInfo: n, omidNativeInfo: i }),
                  t[g].firePixel({ adCsm: [o] });
              }),
              u()(this, C, function () {
                t[_].startLatencyForParam("csm");
                new $.a(t[E], t[g], t[S], t[_], !1).collectData(),
                  t[_].endLatencyForParam("csm"),
                  t[O]();
              }),
              (this[E] = new v.OmidVerificationClient());
          }
          return (
            l()(o, [
              {
                key: "init",
                value: function () {
                  var e = this,
                    o = this[P]();
                  try {
                    this[E].registerSessionObserver(function (t) {
                      return e[T](t, o);
                    }, "amazon.com-omid");
                  } catch (e) {}
                },
              },
            ]),
            o
          );
        })();
      o.a = V;
    }.call(this, t(5)));
  },
  function (e, o, t) {
    "use strict";
    var n = t(1),
      i = t.n(n),
      r = t(3),
      m = t.n(r),
      s = t(6),
      a = t.n(s),
      c = t(12),
      l = ["650", "651"],
      d = { "v/": "v", "atf/": "atf", "btr/": "btr", "ev/": "16", "": "other" },
      u = {
        btr: "bt",
        atf: "at",
        v: "v",
        adCsm: "ac",
        adViewability: "av",
        16: "ev",
        other: "o",
      },
      $ = Symbol("_pixelQueue"),
      p = Symbol("_omidAdapter"),
      f = Symbol("_sanitizePixelUrl"),
      h = Symbol("_flushQueue"),
      v = Symbol("_pixelId"),
      y = Symbol("_timerId"),
      b = Symbol("_pixelParams"),
      g = Symbol("_constructPixelUrl"),
      _ = Symbol("_getVuePixelType"),
      S = Symbol("_replacePixelMacro"),
      E = Symbol("_getPixelUrls"),
      x = Symbol("_constructInstrUrl"),
      I = Symbol("_constructMacroBasedUrl"),
      O = (function () {
        function e(o) {
          m()(this, e),
            (this[p] = o),
            (this[b] = null),
            (this[v] = Math.random().toString(36).substr(2)),
            (this[$] = []),
            (this[y] = null);
        }
        return (
          a()(e, [
            {
              key: "setPixelParams",
              value: function (e) {
                this[b] = e;
                var o = e.pm || {};
                (o = "object" === i()(o) ? o : JSON.parse(o)), (this[b].pm = o);
              },
            },
            {
              key: "getPixelParams",
              value: function () {
                return this[b];
              },
            },
            {
              key: S,
              value: function (e, o, t) {
                var n = encodeURIComponent(o);
                if (-1 !== e.indexOf(n)) return e.replace(n, t);
                if (-1 !== e.indexOf(o)) return e.replace(o, t);
                throw new Error(
                  ""
                    .concat(o.replace(/\$/g, ""), " is not part of URL ")
                    .concat(e)
                );
              },
            },
            {
              key: x,
              value: function (e, o, t) {
                var n = this[f](e, !0),
                  i = Math.round(1e7 * Math.random());
                return (n =
                  "" === t
                    ? "".concat(n, "?p=").concat(o, "&cb=").concat(i)
                    : "".concat(n).concat(t).concat(o, "?cb=").concat(i));
              },
            },
            {
              key: I,
              value: function (e, o, t) {
                var n = this[f](e, !1),
                  i = d[t];
                return (
                  (n = this[S](n, "${AAX_TYPE}", i)),
                  (n = this[S](n, "${AAX_PAYLOAD}", o)),
                  (n = ""
                    .concat(n, "&cb=")
                    .concat(Math.round(1e7 * Math.random())))
                );
              },
            },
            {
              key: g,
              value: function (e, o, t) {
                var n = encodeURIComponent(
                  JSON.stringify(e).replace(/%/g, "<per>")
                );
                return "instrUrl" === t
                  ? this[x](this[b][t], n, o)
                  : this[I](this[b][t], n, o);
              },
            },
            {
              key: E,
              value: function (e, o, t) {
                for (
                  var n = u[o],
                    i = [],
                    r = this[b].pm[n] || ["instrUrl"],
                    m = 0;
                  m < r.length;
                  m += 1
                )
                  i.push(this[g](e, t, r[m]));
                return i;
              },
            },
            {
              key: _,
              value: function (e, o) {
                var t = o;
                return (
                  "other" === o &&
                    (void 0 !== e.adCsm
                      ? (t = "adCsm")
                      : void 0 !== e.adViewability && (t = "adViewability")),
                  t
                );
              },
            },
            {
              key: "firePixel",
              value: function (e) {
                var o =
                  arguments.length > 1 && void 0 !== arguments[1]
                    ? arguments[1]
                    : "";
                if (!e || 0 === Object.keys(e).length)
                  throw new Error("No payload to send");
                void 0 === e.pixelId && (e.pixelId = this[v]);
                for (
                  var t = this[_](e, d[o]), n = this[E](e, t, o), i = 0;
                  i < n.length;
                  i += 1
                )
                  null != n[i] && this[p].sendUrl(n[i]);
              },
            },
            {
              key: "addPixel",
              value: function (e) {
                var o = this;
                if (!e || 0 === Object.keys(e).length)
                  throw new Error("No payload to send");
                var t = function () {
                  o[$].length > 0 &&
                    (o.firePixel({ adCsm: o[$] }),
                    o[h](),
                    o[p].clearTimeout(o[y]));
                };
                0 === this[$].length && (this[y] = this[p].setTimeout(t, 2500)),
                  this[$].push(e),
                  this[$].length >= 4 && t();
              },
            },
            {
              key: f,
              value: function (e, o) {
                var t = e;
                return (
                  t &&
                    (!0 === /^http:\/\//.test(t) &&
                      (t = t.replace("http://", "https://")),
                    o && (t = "/" === t[t.length - 1] ? t : "".concat(t, "/"))),
                  (t = -1 !== l.indexOf(this[b].sourceid) ? Object(c.b)(t) : t)
                );
              },
            },
            {
              key: h,
              value: function () {
                this[$] = [];
              },
            },
            {
              key: "pixelId",
              get: function () {
                return this[v];
              },
            },
          ]),
          e
        );
      })();
    o.a = O;
  },
  function (e, o, t) {
    "use strict";
    var n = t(3),
      i = t.n(n),
      r = t(6),
      m = t.n(r),
      s = Symbol("_pixelQueue"),
      a = Symbol("_errorMessages"),
      c = Symbol("_constructErrorMessage"),
      l = Symbol("_getErrorMessage"),
      d = Symbol("_get"),
      u = Symbol("_sanitizeStackFrame"),
      $ = (function () {
        function e(o) {
          i()(this, e), (this[s] = o), (this[a] = []);
        }
        return (
          m()(e, [
            {
              key: u,
              value: function (e) {
                if (e) {
                  var o = e.indexOf("?"),
                    t = e.split(":"),
                    n = t.length;
                  if (-1 !== o || n >= 2) {
                    var i = t[n - 2],
                      r = t[n - 1];
                    return (e.slice(0, o) + ":" + i + ":" + r)
                      .replace(/^\s+|\s+$/g, "")
                      .replace(/%/g, "<per>")
                      .slice(-256);
                  }
                  return e.replace(/^\s+|\s+$/g, "").slice(-256);
                }
                return e;
              },
            },
            {
              key: c,
              value: function (e, o) {
                if (((o = o || {}), !e)) return {};
                e.m && e.m.message && (e = e.m);
                var t,
                  n,
                  i,
                  r,
                  m = {
                    m: this[l](e, o),
                    c: e.c ? "".concat(e.c) : e.c,
                    s: [],
                    l: e.l || e.line || e.lineno || e.lineNumber,
                    name: e.name,
                    type: e.type,
                  },
                  s = 0,
                  a = 0,
                  c = e.stack || (e.err ? e.err.stack : "");
                if (c && c.split)
                  for (t = c.split("\n"); s < t.length && m.s.length < 5; )
                    (n = t[s]), (s += 1), n && m.s.unshift(this[u](n));
                else
                  for (
                    i = this[d](e.args || arguments, "callee"), s = 0, a = 0;
                    i && s < 5;

                  )
                    (r = 256),
                      i.skipTrace ||
                        ((n = i.toString()) &&
                          n.substr &&
                          ((r = 0 === a ? 1024 : r),
                          (r = 1 === a ? 512 : r),
                          m.s.unshift(n.substr(0, r)),
                          (a += 1))),
                      (i = this[d](i, "caller")),
                      (s += 1);
                return m;
              },
            },
            {
              key: l,
              value: function (e, o) {
                var t = o.m || o.message || "";
                return (
                  e.m && e.m.message
                    ? (t += e.m.message)
                    : e.m && e.m.target && e.m.target.tagName
                    ? (t += "Error handler invoked by ".concat(
                        e.m.target.tagName,
                        " tag"
                      ))
                    : e.m
                    ? (t += e.m)
                    : e.message
                    ? (t += e.message)
                    : (t += "Unknown error"),
                  t
                );
              },
            },
            {
              key: d,
              value: function (e, o) {
                try {
                  return e[o];
                } catch (e) {
                  return "";
                }
              },
            },
            {
              key: "reportClientError",
              value: function (e) {
                var o = this[c](e),
                  t = {
                    adViewability: [{ error: o }],
                    c: "viewability",
                    api: "MAPPVDO",
                    error: 1,
                  };
                -1 === this[a].indexOf(o) &&
                  (this[a].push(o), this[s].firePixel(t));
              },
            },
            {
              key: "reportAdviewData",
              value: function (e) {
                this[s].firePixel({ adCsm: [e] });
              },
            },
          ]),
          e
        );
      })();
    o.a = $;
  },
  function (e, o, t) {
    "use strict";
    var n = t(3),
      i = t.n(n),
      r = t(6),
      m = t.n(r),
      s = t(0),
      a = t.n(s),
      c = Symbol("_omidAdapter"),
      l = Symbol("_reportError"),
      d = Symbol("_utils"),
      u = Symbol("_pixelQueue"),
      $ = Symbol("_videoEventCallback"),
      p = Symbol("_impressionEventCallback"),
      f = Symbol("_geometryChangeEventCallback"),
      h = Symbol("_fractionInViewportOMSDK"),
      v = Symbol("_handlePauseResume"),
      y = Symbol("_handleVolumeChange"),
      b = Symbol("_handleStart"),
      g = Symbol("_viewabilityChangeEventCb"),
      _ = Symbol("_setGroupmTimeCutOff"),
      S = Symbol("_isPlayerMute"),
      E = Symbol("_hasGeometryData"),
      x = Symbol("_checkAndSendBtrPixel"),
      I = Symbol("_isAutoPlay"),
      O = Symbol("_isMute"),
      C = Symbol("_adDuration"),
      T = Symbol("_isVideoOn"),
      w = Symbol("_atfPixelFired"),
      M = Symbol("_isGeometrySet"),
      P = Symbol("_isImpressionDataSent"),
      V = Symbol("_isGeometryDataSent"),
      A = Symbol("_isBtrBeaconSent"),
      N = function e(o, t, n, r) {
        var m = this;
        i()(this, e),
          a()(this, "initViewCompOMSDK", function (e, o, t, n, i) {
            try {
              (m[_] = i),
                (m[g] = t),
                m[c].addEventListener("video", function (e) {
                  return m[$](e);
                }),
                m[c].addEventListener("impression", function (t) {
                  return m[p](t, e, o, n);
                });
            } catch (e) {
              m[l].reportClientError(e);
            }
          }),
          a()(this, "isAutoPlay", function () {
            return m[I];
          }),
          a()(this, "isMute", function () {
            return m[O];
          }),
          a()(this, "isVideoOn", function () {
            return m[T];
          }),
          a()(this, "hasBTR", function () {
            return m[A];
          }),
          a()(this, "getAdDuration", function () {
            return m[C];
          }),
          a()(this, v, function (e) {
            (m[T] = "resume" === e.type), m[g](e.type);
          }),
          a()(this, S, function (e) {
            return 0 === e.data.deviceVolume || 0 === e.data.playerVolume;
          }),
          a()(this, x, function () {
            if (!1 === m[A]) {
              m[A] = !0;
              try {
                m[u].firePixel({ measurementMethod: "btr_client" }, "btr/");
              } catch (e) {
                m[l].reportClientError(e);
              }
            }
          }),
          a()(this, b, function (e) {
            (m[T] = !0),
              (m[C] = 1e3 * e.data.duration),
              (m[O] = m[S](e)),
              m[_](m[C]),
              m[x]();
          }),
          a()(this, y, function (e) {
            m[O] = m[S](e);
            var o = m[O] ? "muteOn" : "muteOff";
            m[g](o);
          }),
          a()(this, E, function (e) {
            return (
              e &&
              e.data &&
              e.data.adView &&
              e.data.adView.geometry &&
              e.data.adView.geometry.width &&
              e.data.viewport
            );
          }),
          a()(this, $, function (e) {
            try {
              "loaded" === e.type
                ? (m[I] = e.data.autoPlay)
                : "start" === e.type
                ? (m[b](e), m[g](e.type))
                : "pause" === e.type || "resume" === e.type
                ? m[v](e)
                : "volumeChange" === e.type
                ? m[y](e)
                : "skipped" === e.type || "complete" === e.type
                ? m[g](e.type)
                : "firstQuartile" === e.type && m[x]();
            } catch (e) {
              m[l].reportClientError(e);
            }
          }),
          a()(this, h, function (e, o, t, n, i) {
            if (
              (!m[M] && m[E](e) && (n(e.data), (m[M] = !0)),
              e &&
                e.data &&
                e.data.adView &&
                "number" == typeof e.data.adView.percentageInView)
            ) {
              var r = e.data.adView.percentageInView / 100;
              m[w] ? t(r, i) : ((m[w] = !0), o(r, i));
            }
          }),
          a()(this, p, function (e, o, t, n) {
            try {
              m[c].addEventListener("geometryChange", function (e) {
                return m[f](e, o, t, n);
              }),
                m[h](e, o, t, n, "im1");
            } catch (e) {
              m[l].reportClientError(e);
            }
          }),
          a()(this, f, function (e, o, t, n) {
            try {
              m[h](e, o, t, n, "gc1");
            } catch (e) {
              m[l].reportClientError(e);
            }
          }),
          (this[c] = o),
          (this[l] = t),
          (this[I] = !1),
          (this[O] = !1),
          (this[T] = !1),
          (this[C] = 0),
          (this[w] = !1),
          (this[M] = !1),
          (this[d] = n),
          (this[u] = r),
          (this[P] = !1),
          (this[V] = !1),
          (this[A] = !1);
      },
      D = Symbol("_utils"),
      R = Symbol("_reportError"),
      G = Symbol("_pixelQueue"),
      k = Symbol("_pixelQueue"),
      U = Symbol("_checkAndReportDuration"),
      F = Symbol("_vd"),
      j = function e(o, t, n, r) {
        var m = this;
        i()(this, e),
          a()(this, "visHandler", function () {
            m[F].visible ||
              ((m[F].startTs = m[D].getTimeStamp()),
              (m[F].latestTs = m[D].getTimeStamp()),
              (m[F].setIntervalHandler = m[D].setInterval(function () {
                m[U]();
              }, 1e3))),
              (m[F].visible = !0);
          }),
          a()(this, "invHandler", function () {
            m[F].visible &&
              ((m[F].totalDuration += m[D].getTimeStamp() - m[F].latestTs),
              m[k].clearInterval(m[F].setIntervalHandler)),
              (m[F].visible = !1);
          }),
          a()(this, U, function () {
            try {
              if (m[F].visible) {
                for (
                  var e = m[D].getTimeStamp() - m[F].startTs;
                  m[F].pCount < m[F].pixelReportTime.length &&
                  e >= m[F].pixelReportTime[m[F].pCount];

                )
                  (m[F].latestTs = m[D].getTimeStamp()),
                    (m[F].totalDuration += e),
                    m[G].addPixel({
                      vdr: e.toFixed(2),
                      tdr: m[F].totalDuration.toFixed(2),
                    }),
                    (m[F].pCount += 1);
                m[F].pCount >= m[F].pixelReportTime.length &&
                  m[k].clearInterval(m[F].setIntervalHandler);
              }
            } catch (e) {
              m[R].reportClientError(e);
            }
          }),
          (this[k] = o),
          (this[D] = t),
          (this[R] = n),
          (this[G] = r),
          (this[F] = {
            startTs: 0,
            latestTs: 0,
            totalDuration: 0,
            visible: !1,
            pixelReportTime: [2e3, 4e3, 8e3, 16e3],
            setIntervalHandler: null,
            pCount: 0,
          });
      },
      L = Symbol("_videoViewability"),
      B = Symbol("_omidAdapter"),
      Y = Symbol("_pixelQueue"),
      H = Symbol("_reportError"),
      K = Symbol("_viewDuration"),
      W = Symbol("_utils"),
      J = Symbol("_computeViewability"),
      z = Symbol("_fireBeacon"),
      Q = Symbol("_allViewBeaconsFired"),
      X = Symbol("_seenForTimeIab"),
      q = Symbol("_seenForTimeMrc"),
      Z = Symbol("_seenForTimeGroupm"),
      ee = Symbol("_setGeometryDataOMSDK"),
      oe = Symbol("_checkAndStartIabTimer"),
      te = Symbol("_resetIabTimer"),
      ne = Symbol("_checkAndStartMrcTimer"),
      ie = Symbol("_resetMrcTimer"),
      re = Symbol("_checkAndStartGroupmTimer"),
      me = Symbol("_resetGroupmTimer"),
      se = Symbol("_setGroupmTimeCutOff"),
      ae = Symbol("_sendViewNot"),
      ce = Symbol("_reportViewEvent"),
      le = Symbol("_viewabilityEventCb"),
      de = Symbol("_timerStartTimeIab"),
      ue = Symbol("_timerStartTimeMrc"),
      $e = Symbol("_timerStartTimeGroupm"),
      pe = Symbol("_timerEngagedViewEligible"),
      fe = Symbol("_timerStartedEngagedViewEligible"),
      he = Symbol("_timerStartTimeEngagedViewEligible"),
      ve = Symbol("_seenForTimeEngagedViewEligible"),
      ye = Symbol("_checkAndStartEngagedViewEligibleTimer"),
      be = Symbol("_resetEngagedViewEligibleTimer"),
      ge = Symbol("_timerEngagedView"),
      _e = Symbol("_timerStartedEngagedView"),
      Se = Symbol("_timerStartTimeEngagedView"),
      Ee = Symbol("_seenForTimeEngagedView"),
      xe = Symbol("_checkAndStartEngagedViewTimer"),
      Ie = Symbol("_resetEngagedViewTimer"),
      Oe = Symbol("_engagedViewEligibility"),
      Ce = Symbol("_engagedViewThreshold"),
      Te = Symbol("_atfPixelFired"),
      we = Symbol("_leftPos"),
      Me = Symbol("_topPos"),
      Pe = Symbol("_iabAreaCuttOff"),
      Ve = Symbol("_mrcAreaCuttOff"),
      Ae = Symbol("_groupmAreaCutOff"),
      Ne = Symbol("_evAreaCutOff"),
      De = Symbol("_mrcTimeCutOff"),
      Re = Symbol("_iabTimeCutOff"),
      Ge = Symbol("_groupmTimeCutOff"),
      ke = Symbol("_timerIab"),
      Ue = Symbol("_timerStartedIab"),
      Fe = Symbol("_timerMrc"),
      je = Symbol("_timerStartedMrc"),
      Le = Symbol("_timerGroupm"),
      Be = Symbol("_timerStartedGroupm"),
      Ye = Symbol("_beaconSent"),
      He = Symbol("_adWidth"),
      Ke = Symbol("_adHeight"),
      We = Symbol("_winWidth"),
      Je = Symbol("_winHeight"),
      ze = Symbol("_area"),
      Qe = Symbol("_timerArea"),
      Xe = Symbol("_viewCbType"),
      qe = Symbol("_latestCb"),
      Ze = Symbol("_isBenchmark"),
      eo = Symbol("_maxTimeCutOffGroupm"),
      oo = Symbol("_isEventSequenceSent"),
      to = (function () {
        function e(o, t, n, r) {
          var m = this,
            s = arguments.length > 4 && void 0 !== arguments[4] && arguments[4];
          i()(this, e),
            a()(this, Q, function () {
              return m[Ye].iab && m[Ye].groupm && m[Ye].mrc;
            }),
            a()(this, X, function () {
              m[Ye].iab ||
                (m[ze] >= m[Pe] &&
                  (m[z]("viewable", {
                    viewable: !0,
                    defn: "iab",
                    p: parseInt((100 * m[ze]).toFixed(2), 10),
                    t: m.getTimeInView(m[de]),
                    dbg: m[Xe],
                  }),
                  (m[Ye].iab = !0),
                  m[W].dispatchCustomEvent("amzncsmIabView")));
            }),
            a()(this, ve, function () {
              m[Ye].evev ||
                (m[ze] >= m[Ne] &&
                  (m[z]("engaged_view", {
                    e: "evev",
                    p: parseInt((100 * m[ze]).toFixed(2), 10),
                    t: m.getTimeInView(m[he]),
                    evet: m[Oe],
                    th: m[Ce],
                    dbg: m[Xe],
                  }),
                  (m[Ye].evev = !0)));
            }),
            a()(this, Ee, function () {
              m[Ye].ev ||
                (m[ze] >= m[Ne] &&
                  (m[z]("engaged_view", {
                    e: "ev",
                    p: parseInt((100 * m[ze]).toFixed(2), 10),
                    t: m.getTimeInView(m[Se]),
                    evet: m[Oe],
                    th: m[Ce],
                    dbg: m[Xe],
                  }),
                  (m[Ye].ev = !0)));
            }),
            a()(this, q, function () {
              m[Ye].mrc ||
                (m[ze] >= m[Ve] &&
                  (m[z]("viewable", {
                    viewable: !0,
                    defn: "mrc",
                    p: parseInt((100 * m[ze]).toFixed(2), 10),
                    t: m.getTimeInView(m[ue]),
                    dbg: m[Xe],
                  }),
                  (m[Ye].mrc = !0)));
            }),
            a()(this, Z, function () {
              m[Ye].groupm ||
                (m[ze] >= m[Ae] &&
                  (m[z]("viewable", {
                    viewable: !0,
                    defn: "groupm",
                    p: parseInt((100 * m[ze]).toFixed(2), 10),
                    t: m.getTimeInView(m[$e]),
                  }),
                  (m[Ye].groupm = !0)));
            }),
            a()(this, z, function (e, o) {
              var t, n, i;
              if (
                !(
                  ("above_the_fold" === e && m[Ye].atf) ||
                  ("viewable" === e && m[Ye][o.defn])
                )
              )
                try {
                  var r = {},
                    s = "",
                    c = "";
                  switch (e) {
                    case "above_the_fold":
                      (m[Ye].atf = !0),
                        (s = m[Ze] ? "" : "atf/"),
                        (c = m[Ze] ? "atf_ben" : "atf"),
                        (t = {}),
                        a()(t, c, o.atf),
                        a()(t, "ah", null !== m[Ke] ? m[Ke] : "undefined"),
                        a()(t, "aw", null !== m[He] ? m[He] : "undefined"),
                        a()(t, "wh", null !== m[Je] ? m[Je] : "undefined"),
                        a()(t, "ww", null !== m[We] ? m[We] : "undefined"),
                        a()(t, "left", null !== m[we] ? m[we] : "undefined"),
                        a()(t, "top", null !== m[Me] ? m[Me] : "undefined"),
                        a()(t, "dbg", null !== o.dbg ? o.dbg : "undefined"),
                        a()(t, "p", null !== o.p ? o.p : "undefined"),
                        a()(t, "ts", new Date().getTime()),
                        (r = t),
                        m[Y].firePixel(r, s);
                      break;
                    case "viewable":
                      (s = m[Ze] ? "" : "v/"),
                        (c = m[Ze] ? "v_ben" : "v"),
                        (n = {}),
                        a()(n, c, { p: o.p, t: o.t, def: "".concat(o.defn) }),
                        a()(n, "ah", null !== m[Ke] ? m[Ke] : "undefined"),
                        a()(n, "aw", null !== m[He] ? m[He] : "undefined"),
                        a()(n, "wh", null !== m[Je] ? m[Je] : "undefined"),
                        a()(n, "ww", null !== m[We] ? m[We] : "undefined"),
                        a()(n, "left", null !== m[we] ? m[we] : "undefined"),
                        a()(n, "top", null !== m[Me] ? m[Me] : "undefined"),
                        a()(n, "ts", new Date().getTime()),
                        a()(
                          n,
                          "p0",
                          null !== m[Qe] ? "".concat(m[Qe]) : "undefined"
                        ),
                        a()(
                          n,
                          "dbg",
                          null !== o.dbg ? "".concat(o.dbg) : "undefined"
                        ),
                        (r = n),
                        m[Y].firePixel(r, s);
                      break;
                    case "engaged_view":
                      (s = m[Ze] ? "" : "ev/"),
                        (c = m[Ze] ? "ev_ben" : "ev"),
                        (i = {}),
                        a()(i, c, {
                          e: o.e,
                          p: o.p,
                          t: o.t,
                          evet: o.evet,
                          th: o.th,
                        }),
                        a()(i, "ah", null !== m[Ke] ? m[Ke] : "undefined"),
                        a()(i, "aw", null !== m[He] ? m[He] : "undefined"),
                        a()(i, "wh", null !== m[Je] ? m[Je] : "undefined"),
                        a()(i, "ww", null !== m[We] ? m[We] : "undefined"),
                        a()(i, "left", null !== m[we] ? m[we] : "undefined"),
                        a()(i, "top", null !== m[Me] ? m[Me] : "undefined"),
                        a()(i, "ts", new Date().getTime()),
                        a()(
                          i,
                          "dbg",
                          null !== o.dbg ? "".concat(o.dbg) : "undefined"
                        ),
                        (r = i),
                        m[Y].firePixel(r, s);
                      break;
                    default:
                      r = {};
                  }
                } catch (e) {
                  m[H].reportClientError(e);
                }
            }),
            a()(this, "getTimeInView", function (e) {
              return parseFloat(((m[W].getTimeStamp() - e) / 1e3).toFixed(3));
            }),
            a()(this, ee, function (e) {
              try {
                (m[we] = e.adView.geometry.x),
                  (m[Me] = e.adView.geometry.y),
                  (m[He] = e.adView.geometry.width),
                  (m[Ke] = e.adView.geometry.height),
                  (m[Je] = e.viewport.height),
                  (m[We] = e.viewport.width);
              } catch (e) {
                m[H].reportClientError(e);
              }
            }),
            a()(this, se, function (e) {
              m[Ge] = Math.min(m[eo], e / 2);
            }),
            a()(this, ae, function (e) {
              m[Ze] || (e ? m[K].visHandler() : m[K].invHandler());
            }),
            a()(this, ce, function (e) {
              e > m[Pe] ? m[ae](!0) : m[ae](!1);
            }),
            a()(this, J, function (e) {
              var o = function (e) {
                !m[Ue] &&
                  m[L].isVideoOn() &&
                  m[ze] >= m[Pe] &&
                  ((m[Qe] = m[ze]),
                  (m[Xe] = e),
                  !1 === m[Ye].iab &&
                    (m[ke] && m[B].clearTimeout(m[ke]),
                    (m[de] = m[W].getTimeStamp()),
                    (m[ke] = m[W].setTimeout(function () {
                      m[X]();
                    }, m[Re]))),
                  (m[Ue] = !0));
              };
              m[oe] = o;
              var t = function () {
                m[ke] &&
                  (m[B].clearTimeout(m[ke]), (m[Ue] = !1), (m[de] = null));
              };
              m[te] = t;
              var n = function (e) {
                !m[je] &&
                  m[L].isVideoOn() &&
                  m[L].hasBTR() &&
                  m[ze] >= m[Ve] &&
                  ((m[Qe] = m[ze]),
                  (m[Xe] = e),
                  !1 === m[Ye].mrc &&
                    (m[Fe] && m[B].clearTimeout(m[Fe]),
                    (m[ue] = m[W].getTimeStamp()),
                    (m[Fe] = m[W].setTimeout(function () {
                      m[q]();
                    }, m[De]))),
                  (m[je] = !0));
              };
              m[ne] = n;
              var i = function () {
                m[Fe] &&
                  (m[B].clearTimeout(m[Fe]), (m[je] = !1), (m[ue] = null));
              };
              m[ie] = i;
              var r = function () {
                if (
                  !m[Be] &&
                  m[L].isVideoOn() &&
                  !m[L].isMute() &&
                  !m[L].isAutoPlay() &&
                  m[ze] > m[Ae] &&
                  m[Ge]
                )
                  try {
                    !1 === m[Ye].groupm &&
                      (m[Le] && m[B].clearTimeout(m[Le]),
                      (m[$e] = m[W].getTimeStamp()),
                      (m[Le] = m[W].setTimeout(function () {
                        m[Z]();
                      }, m[Ge]))),
                      (m[Be] = !0);
                  } catch (e) {
                    m[H].reportClientError(e);
                  }
              };
              m[re] = r;
              var s = function () {
                m[Le] &&
                  (m[B].clearTimeout(m[Le]), (m[Be] = !1), (m[$e] = null));
              };
              m[me] = s;
              var a = function (e) {
                m.isEngagedViewEligible() &&
                  !m[fe] &&
                  m[L].isVideoOn() &&
                  m[ze] >= m[Pe] &&
                  ((m[Xe] = e),
                  !1 === m[Ye].evev &&
                    (m[pe] && m[B].clearTimeout(m[pe]),
                    (m[he] = m[W].getTimeStamp()),
                    (m[pe] = m[W].setTimeout(function () {
                      m[ve]();
                    }, m[Re]))),
                  (m[fe] = !0));
              };
              m[ye] = a;
              var c = function () {
                m[pe] &&
                  (m[B].clearTimeout(m[pe]), (m[fe] = !1), (m[he] = null));
              };
              m[be] = c;
              var l = function (e) {
                m.isEngagedViewEligible() &&
                  !m[_e] &&
                  m[L].isVideoOn() &&
                  m[ze] >= m[Pe] &&
                  ((m[Xe] = e),
                  !1 === m[Ye].ev &&
                    (m[ge] && m[B].clearTimeout(m[ge]),
                    (m[Se] = m[W].getTimeStamp()),
                    (m[ge] = m[W].setTimeout(function () {
                      m[Ee]();
                    }, m[Ce]))),
                  (m[_e] = !0));
              };
              m[xe] = l;
              var d = function () {
                m[ge] &&
                  (m[B].clearTimeout(m[ge]), (m[_e] = !1), (m[Se] = null));
              };
              m[Ie] = d;
              e &&
                (m[W].startLatencyForParam("atfComp"),
                (m[L] = new N(m[B], m[H], m[W], m[Y])),
                m[L].initViewCompOMSDK(
                  function (e, t) {
                    try {
                      var i;
                      (m[ze] = e),
                        (m[qe] = t),
                        (i = m[ze] >= m[Pe]),
                        m[ze] > m[Ae] && r(),
                        m[ze] >= m[Pe] && o(t),
                        m[ze] >= m[Ve] && n(t),
                        m[ze] >= m[Ne] && (a(t), l(t)),
                        m[W].endLatencyForParam("atfComp"),
                        m[z]("above_the_fold", { atf: i, dbg: t, p: e }),
                        m[ce](e);
                    } catch (e) {
                      m[H].reportClientError(e);
                    }
                  },
                  function (e, u) {
                    try {
                      if (
                        ((m[ze] = e),
                        (m[qe] = u),
                        m[ce](e),
                        m[Ye].iab && m[Ye].groupm && m[Ye].mrc)
                      )
                        return;
                      e >= m[Pe] && !m[Ue] ? o(u) : e < m[Pe] && m[Ue] && t(),
                        e >= m[Ve] && !m[je] ? n(u) : e < m[Ve] && m[je] && i(),
                        e >= m[Ae] && !m[Be] ? r() : e <= m[Ae] && m[Be] && s(),
                        e >= m[Ne] && !m[fe] ? a(u) : e < m[Ne] && m[fe] && c(),
                        e >= m[Ne] && !m[_e] ? l(u) : e < m[Ne] && m[_e] && d();
                    } catch (e) {
                      m[H].reportClientError(e);
                    }
                  },
                  m[le],
                  m[ee],
                  m[se]
                ));
            }),
            a()(this, le, function (e) {
              "resume" === e || "start" === e
                ? (m[oe](m[qe]),
                  m[ne](m[qe]),
                  m[ye](m[qe]),
                  m[xe](m[qe]),
                  m[re]())
                : "pause" === e
                ? (m[te](), m[ie](), m[be](), m[Ie](), m[me]())
                : "muteOn" === e
                ? m[me]()
                : "muteOff" === e
                ? m[re]()
                : ("skipped" !== e && "complete" !== e) ||
                  (m[te](), m[ie](), m[be](), m[Ie](), m[me](), m[ae](!1));
            }),
            a()(this, "initEngagedViewParams", function () {
              var e = m[Y].getPixelParams() || {};
              (m[Oe] = e.evet || "0"),
                (m[Ce] = Number(e.th) || 5e3),
                m[Ce] <= 0 && (m[Oe] = "0");
            }),
            a()(this, "collectData", function () {
              m.initEngagedViewParams(), (m[Te] = !0), m[J](!0);
            }),
            (this[B] = o),
            (this[Y] = t),
            (this[H] = n),
            (this[W] = r),
            (this[K] = new j(o, r, n, t)),
            (this[Pe] = 0.5),
            (this[Ve] = 0.5),
            (this[Ae] = 0.9),
            (this[Ne] = 0.5),
            (this[Re] = 2e3),
            (this[De] = 2e3),
            (this[Ge] = null),
            (this[eo] = 15e3),
            (this[ke] = !1),
            (this[Ue] = !1),
            (this[de] = null),
            (this[Fe] = !1),
            (this[je] = !1),
            (this[ue] = null),
            (this[Le] = !1),
            (this[Be] = !1),
            (this[$e] = null),
            (this[pe] = !1),
            (this[fe] = !1),
            (this[he] = null),
            (this[ge] = !1),
            (this[_e] = !1),
            (this[Se] = null),
            (this[Oe] = "0"),
            (this[Ce] = 0),
            (this[Ye] = {
              atf: !1,
              mrc: !1,
              iab: !1,
              groupm: !1,
              eventSequence: !1,
              evev: !1,
              ev: !1,
            }),
            (this[we] = null),
            (this[Me] = null),
            (this[He] = null),
            (this[Ke] = null),
            (this[Je] = null),
            (this[We] = null),
            (this[ze] = null),
            (this[Xe] = null),
            (this[Qe] = null),
            (this[qe] = null),
            (this[oo] = !1),
            (this[Ze] = s);
        }
        return (
          m()(e, [
            {
              key: "isEngagedViewEligible",
              value: function () {
                return "0" !== this[Oe];
              },
            },
          ]),
          e
        );
      })();
    o.a = to;
  },
  function (e, o, t) {
    "use strict";
    t.r(o), new (t(13).a)().init();
  },
]);
