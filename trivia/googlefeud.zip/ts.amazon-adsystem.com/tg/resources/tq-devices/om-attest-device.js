!(function (e, t) {
  "object" == typeof exports && "object" == typeof module
    ? (module.exports = t())
    : "function" == typeof define && define.amd
    ? define([], t)
    : "object" == typeof exports
    ? (exports.DeviceAttestation = t())
    : (e.DeviceAttestation = t());
})(this, () =>
  (() => {
    "use strict";
    var e = {};
    function t(e) {
      return (
        (t =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              }),
        t(e)
      );
    }
    var n = ["iOS", "iPhone OS", "iPadOS"],
      o = ["macOS", "Mac OS X"];
    function i(e, i, r) {
      return (
        (function (e, t, i) {
          var r = parseInt(t, 10);
          return n.includes(e)
            ? r >= 16
            : !!o.includes(e) && r >= 13 && "Safari" === i;
        })(e, i, r) ||
        (function () {
          if (
            ((e =
              "undefined" != typeof CSS &&
              "function" == typeof CSS.supports &&
              CSS.supports("container-type: inline-size")),
            (n =
              "undefined" != typeof CSS &&
              "function" == typeof CSS.supports &&
              CSS.supports("grid-template-rows", "subgrid")),
            (o =
              "undefined" != typeof HTMLFormElement &&
              "requestSubmit" in HTMLFormElement.prototype),
            !(e && n && o))
          )
            return !1;
          var e, n, o;
          if (
            "object" !==
              ("undefined" == typeof window ? "undefined" : t(window)) ||
            "object" !== t(window.navigator)
          )
            return !1;
          var i = window.navigator.userAgent,
            r = /iPhone|iPad/.test(i),
            d = /(Macintosh)/.test(i),
            a = i.match(/(Mac OS X|CPU (?:iPhone )?OS) (\d+)[_.](\d+)/);
          if (!a) return !1;
          var c = parseInt(a[2], 10);
          if (r && c < 16) return !1;
          if (d) {
            var s = i.match(/Version\/(\d+)\.(\d+)/);
            return (
              !!s && parseInt(s[1], 10) >= 16 && /Version\/.+Safari/.test(i)
            );
          }
          return r || (c >= 16 && !/Version\//.test(i));
        })()
      );
    }
    var r = "1.3.2";
    return (
      (function () {
        try {
          var e = (function () {
            var e,
              t =
                ("undefined" != typeof window && window && window.document) ||
                document;
            if (t) {
              var n =
                  null == t || null === (e = t.currentScript) || void 0 === e
                    ? void 0
                    : e.src,
                o = {};
              if (!n) return o;
              var i = n.split("?")[1];
              if (i)
                for (var r = i.split("&"), d = 0; d < r.length; d++) {
                  var a = r[d].split("=");
                  if (a.length >= 2) {
                    var c = a[0],
                      s = a[1];
                    if (c && /^[a-zA-Z0-9_-]+$/.test(c) && void 0 !== s)
                      try {
                        var u = decodeURIComponent(s).replace(/[<>"'&]/g, "");
                        o[c] = u;
                      } catch (e) {
                        continue;
                      }
                  }
                }
              return o;
            }
          })();
          if (
            i(
              null == e ? void 0 : e.osN,
              null == e ? void 0 : e.osV,
              null == e ? void 0 : e.brF
            ) &&
            Math.floor(100 * Math.random()) < 100
          ) {
            var t = (function () {
              var e =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : {},
                t = e.appName,
                n = void 0 === t ? "appName1" : t,
                o = e.impressionId,
                i = void 0 === o ? "impressionId1" : o,
                r = e.device,
                d = void 0 === r ? "APPLE" : r;
              return "https://origin.amazon-ads-attestation.com/v1/attest-device?appName=%s&impressionId=%s&device=%s"
                .replace("%s", encodeURIComponent(n))
                .replace("%s", encodeURIComponent(i))
                .replace("%s", encodeURIComponent(d));
            })({ impressionId: null == e ? void 0 : e.bidId });
            (n = t),
              (o =
                ("undefined" != typeof window && window && window.document) ||
                document) &&
                (function (e, t, n) {
                  var o = 0;
                  !(function i() {
                    if (
                      e &&
                      e.body &&
                      "function" == typeof e.body.appendChild
                    ) {
                      var r = e.createElement("script");
                      n && (r.onload = n),
                        (r.onerror = function () {
                          o <= 2 && ((o += 1), i());
                        }),
                        (r.src = t),
                        e.body.appendChild(r);
                    } else o <= 2 && ((o += 1), setTimeout(i, 100));
                  })();
                })(
                  o,
                  "https://c.amazon-adsystem.com/bao-csm/mobile/ovc.js",
                  function () {
                    !(function (e) {
                      try {
                        if (
                          window.OmidVerificationClient &&
                          r in window.OmidVerificationClient
                        ) {
                          var t = new (0, window.OmidVerificationClient[r])();
                          "true" ==
                            (!0 === t.isSupported() ? "true" : "false") &&
                            t.sendUrl(e);
                        }
                      } catch (e) {}
                    })(n);
                  }
                );
          }
        } catch (e) {}
        var n, o;
      })(),
      e.default
    );
  })()
);
//# sourceMappingURL=om-attest-device.js.map
