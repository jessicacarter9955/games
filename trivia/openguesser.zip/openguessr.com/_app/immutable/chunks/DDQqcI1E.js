import { t as e } from "./XKyaHtl9.js";
var t = e((e, t, n) => {
  (function (n, r) {
    typeof e == `object` && t !== void 0
      ? r(e)
      : typeof define == `function` && define.amd
      ? define([`exports`], r)
      : ((n = typeof globalThis < `u` ? globalThis : n || self),
        r((n.leaflet = {})));
  })(n, function (e) {
    var t = `1.9.4`;
    function n(e) {
      for (var t, n = 1, r = arguments.length, i; n < r; n++)
        for (t in ((i = arguments[n]), i)) e[t] = i[t];
      return e;
    }
    var r =
      Object.create ||
      (function () {
        function e() {}
        return function (t) {
          return (e.prototype = t), new e();
        };
      })();
    function i(e, t) {
      var n = Array.prototype.slice;
      if (e.bind) return e.bind.apply(e, n.call(arguments, 1));
      var r = n.call(arguments, 2);
      return function () {
        return e.apply(t, r.length ? r.concat(n.call(arguments)) : arguments);
      };
    }
    var a = 0;
    function o(e) {
      return `_leaflet_id` in e || (e._leaflet_id = ++a), e._leaflet_id;
    }
    function s(e, t, n) {
      var r,
        i,
        a,
        o = function () {
          (r = !1), (i &&= (a.apply(n, i), !1));
        };
      return (
        (a = function () {
          r
            ? (i = arguments)
            : (e.apply(n, arguments), setTimeout(o, t), (r = !0));
        }),
        a
      );
    }
    function c(e, t, n) {
      var r = t[1],
        i = t[0],
        a = r - i;
      return e === r && n ? e : ((((e - i) % a) + a) % a) + i;
    }
    function l() {
      return !1;
    }
    function u(e, t) {
      if (t === !1) return e;
      var n = 10 ** (t === void 0 ? 6 : t);
      return Math.round(e * n) / n;
    }
    function d(e) {
      return e.trim ? e.trim() : e.replace(/^\s+|\s+$/g, ``);
    }
    function f(e) {
      return d(e).split(/\s+/);
    }
    function p(e, t) {
      for (var n in (Object.prototype.hasOwnProperty.call(e, `options`) ||
        (e.options = e.options ? r(e.options) : {}),
      t))
        e.options[n] = t[n];
      return e.options;
    }
    function m(e, t, n) {
      var r = [];
      for (var i in e)
        r.push(
          encodeURIComponent(n ? i.toUpperCase() : i) +
            `=` +
            encodeURIComponent(e[i])
        );
      return (!t || t.indexOf(`?`) === -1 ? `?` : `&`) + r.join(`&`);
    }
    var ee = /\{ *([\w_ -]+) *\}/g;
    function h(e, t) {
      return e.replace(ee, function (e, n) {
        var r = t[n];
        if (r === void 0) throw Error(`No value provided for variable ` + e);
        return typeof r == `function` && (r = r(t)), r;
      });
    }
    var g =
      Array.isArray ||
      function (e) {
        return Object.prototype.toString.call(e) === `[object Array]`;
      };
    function te(e, t) {
      for (var n = 0; n < e.length; n++) if (e[n] === t) return n;
      return -1;
    }
    var ne = `data:image/gif;base64,R0lGODlhAQABAAD/ACwAAAAAAQABAAACADs=`;
    function re(e) {
      return window[`webkit` + e] || window[`moz` + e] || window[`ms` + e];
    }
    var ie = 0;
    function ae(e) {
      var t = +new Date(),
        n = Math.max(0, 16 - (t - ie));
      return (ie = t + n), window.setTimeout(e, n);
    }
    var oe = window.requestAnimationFrame || re(`RequestAnimationFrame`) || ae,
      se =
        window.cancelAnimationFrame ||
        re(`CancelAnimationFrame`) ||
        re(`CancelRequestAnimationFrame`) ||
        function (e) {
          window.clearTimeout(e);
        };
    function _(e, t, n) {
      if (n && oe === ae) e.call(t);
      else return oe.call(window, i(e, t));
    }
    function v(e) {
      e && se.call(window, e);
    }
    var ce = {
      __proto__: null,
      extend: n,
      create: r,
      bind: i,
      get lastId() {
        return a;
      },
      stamp: o,
      throttle: s,
      wrapNum: c,
      falseFn: l,
      formatNum: u,
      trim: d,
      splitWords: f,
      setOptions: p,
      getParamString: m,
      template: h,
      isArray: g,
      indexOf: te,
      emptyImageUrl: ne,
      requestFn: oe,
      cancelFn: se,
      requestAnimFrame: _,
      cancelAnimFrame: v,
    };
    function y() {}
    (y.extend = function (e) {
      var t = function () {
          p(this),
            this.initialize && this.initialize.apply(this, arguments),
            this.callInitHooks();
        },
        i = (t.__super__ = this.prototype),
        a = r(i);
      for (var o in ((a.constructor = t), (t.prototype = a), this))
        Object.prototype.hasOwnProperty.call(this, o) &&
          o !== `prototype` &&
          o !== `__super__` &&
          (t[o] = this[o]);
      return (
        e.statics && n(t, e.statics),
        e.includes && (le(e.includes), n.apply(null, [a].concat(e.includes))),
        n(a, e),
        delete a.statics,
        delete a.includes,
        a.options &&
          ((a.options = i.options ? r(i.options) : {}),
          n(a.options, e.options)),
        (a._initHooks = []),
        (a.callInitHooks = function () {
          if (!this._initHooksCalled) {
            i.callInitHooks && i.callInitHooks.call(this),
              (this._initHooksCalled = !0);
            for (var e = 0, t = a._initHooks.length; e < t; e++)
              a._initHooks[e].call(this);
          }
        }),
        t
      );
    }),
      (y.include = function (e) {
        var t = this.prototype.options;
        return (
          n(this.prototype, e),
          e.options &&
            ((this.prototype.options = t), this.mergeOptions(e.options)),
          this
        );
      }),
      (y.mergeOptions = function (e) {
        return n(this.prototype.options, e), this;
      }),
      (y.addInitHook = function (e) {
        var t = Array.prototype.slice.call(arguments, 1),
          n =
            typeof e == `function`
              ? e
              : function () {
                  this[e].apply(this, t);
                };
        return (
          (this.prototype._initHooks = this.prototype._initHooks || []),
          this.prototype._initHooks.push(n),
          this
        );
      });
    function le(e) {
      if (typeof L < `u` && L && L.Mixin) {
        e = g(e) ? e : [e];
        for (var t = 0; t < e.length; t++)
          e[t] === L.Mixin.Events &&
            console.warn(
              `Deprecated include of L.Mixin.Events: this property will be removed in future releases, please inherit from L.Evented instead.`,
              Error().stack
            );
      }
    }
    var b = {
      on: function (e, t, n) {
        if (typeof e == `object`) for (var r in e) this._on(r, e[r], t);
        else {
          e = f(e);
          for (var i = 0, a = e.length; i < a; i++) this._on(e[i], t, n);
        }
        return this;
      },
      off: function (e, t, n) {
        if (!arguments.length) delete this._events;
        else if (typeof e == `object`) for (var r in e) this._off(r, e[r], t);
        else {
          e = f(e);
          for (var i = arguments.length === 1, a = 0, o = e.length; a < o; a++)
            i ? this._off(e[a]) : this._off(e[a], t, n);
        }
        return this;
      },
      _on: function (e, t, n, r) {
        if (typeof t != `function`)
          console.warn(`wrong listener type: ` + typeof t);
        else if (this._listens(e, t, n) === !1) {
          n === this && (n = void 0);
          var i = { fn: t, ctx: n };
          r && (i.once = !0),
            (this._events = this._events || {}),
            (this._events[e] = this._events[e] || []),
            this._events[e].push(i);
        }
      },
      _off: function (e, t, n) {
        var r, i, a;
        if (this._events && ((r = this._events[e]), r)) {
          if (arguments.length === 1) {
            if (this._firingCount)
              for (i = 0, a = r.length; i < a; i++) r[i].fn = l;
            delete this._events[e];
          } else if (typeof t != `function`)
            console.warn(`wrong listener type: ` + typeof t);
          else {
            var o = this._listens(e, t, n);
            if (o !== !1) {
              var s = r[o];
              this._firingCount &&
                ((s.fn = l), (this._events[e] = r = r.slice())),
                r.splice(o, 1);
            }
          }
        }
      },
      fire: function (e, t, r) {
        if (!this.listens(e, r)) return this;
        var i = n({}, t, {
          type: e,
          target: this,
          sourceTarget: (t && t.sourceTarget) || this,
        });
        if (this._events) {
          var a = this._events[e];
          if (a) {
            this._firingCount = this._firingCount + 1 || 1;
            for (var o = 0, s = a.length; o < s; o++) {
              var c = a[o],
                l = c.fn;
              c.once && this.off(e, l, c.ctx), l.call(c.ctx || this, i);
            }
            this._firingCount--;
          }
        }
        return r && this._propagateEvent(i), this;
      },
      listens: function (e, t, n, r) {
        typeof e != `string` && console.warn(`"string" type argument expected`);
        var i = t;
        typeof t != `function` && ((r = !!t), (i = void 0), (n = void 0));
        var a = this._events && this._events[e];
        if (a && a.length && this._listens(e, i, n) !== !1) return !0;
        if (r) {
          for (var o in this._eventParents)
            if (this._eventParents[o].listens(e, t, n, r)) return !0;
        }
        return !1;
      },
      _listens: function (e, t, n) {
        if (!this._events) return !1;
        var r = this._events[e] || [];
        if (!t) return !!r.length;
        n === this && (n = void 0);
        for (var i = 0, a = r.length; i < a; i++)
          if (r[i].fn === t && r[i].ctx === n) return i;
        return !1;
      },
      once: function (e, t, n) {
        if (typeof e == `object`) for (var r in e) this._on(r, e[r], t, !0);
        else {
          e = f(e);
          for (var i = 0, a = e.length; i < a; i++) this._on(e[i], t, n, !0);
        }
        return this;
      },
      addEventParent: function (e) {
        return (
          (this._eventParents = this._eventParents || {}),
          (this._eventParents[o(e)] = e),
          this
        );
      },
      removeEventParent: function (e) {
        return this._eventParents && delete this._eventParents[o(e)], this;
      },
      _propagateEvent: function (e) {
        for (var t in this._eventParents)
          this._eventParents[t].fire(
            e.type,
            n({ layer: e.target, propagatedFrom: e.target }, e),
            !0
          );
      },
    };
    (b.addEventListener = b.on),
      (b.removeEventListener = b.clearAllEventListeners = b.off),
      (b.addOneTimeEventListener = b.once),
      (b.fireEvent = b.fire),
      (b.hasEventListeners = b.listens);
    var ue = y.extend(b);
    function x(e, t, n) {
      (this.x = n ? Math.round(e) : e), (this.y = n ? Math.round(t) : t);
    }
    var de =
      Math.trunc ||
      function (e) {
        return e > 0 ? Math.floor(e) : Math.ceil(e);
      };
    x.prototype = {
      clone: function () {
        return new x(this.x, this.y);
      },
      add: function (e) {
        return this.clone()._add(S(e));
      },
      _add: function (e) {
        return (this.x += e.x), (this.y += e.y), this;
      },
      subtract: function (e) {
        return this.clone()._subtract(S(e));
      },
      _subtract: function (e) {
        return (this.x -= e.x), (this.y -= e.y), this;
      },
      divideBy: function (e) {
        return this.clone()._divideBy(e);
      },
      _divideBy: function (e) {
        return (this.x /= e), (this.y /= e), this;
      },
      multiplyBy: function (e) {
        return this.clone()._multiplyBy(e);
      },
      _multiplyBy: function (e) {
        return (this.x *= e), (this.y *= e), this;
      },
      scaleBy: function (e) {
        return new x(this.x * e.x, this.y * e.y);
      },
      unscaleBy: function (e) {
        return new x(this.x / e.x, this.y / e.y);
      },
      round: function () {
        return this.clone()._round();
      },
      _round: function () {
        return (
          (this.x = Math.round(this.x)), (this.y = Math.round(this.y)), this
        );
      },
      floor: function () {
        return this.clone()._floor();
      },
      _floor: function () {
        return (
          (this.x = Math.floor(this.x)), (this.y = Math.floor(this.y)), this
        );
      },
      ceil: function () {
        return this.clone()._ceil();
      },
      _ceil: function () {
        return (this.x = Math.ceil(this.x)), (this.y = Math.ceil(this.y)), this;
      },
      trunc: function () {
        return this.clone()._trunc();
      },
      _trunc: function () {
        return (this.x = de(this.x)), (this.y = de(this.y)), this;
      },
      distanceTo: function (e) {
        e = S(e);
        var t = e.x - this.x,
          n = e.y - this.y;
        return Math.sqrt(t * t + n * n);
      },
      equals: function (e) {
        return (e = S(e)), e.x === this.x && e.y === this.y;
      },
      contains: function (e) {
        return (
          (e = S(e)),
          Math.abs(e.x) <= Math.abs(this.x) && Math.abs(e.y) <= Math.abs(this.y)
        );
      },
      toString: function () {
        return `Point(` + u(this.x) + `, ` + u(this.y) + `)`;
      },
    };
    function S(e, t, n) {
      return e instanceof x
        ? e
        : g(e)
        ? new x(e[0], e[1])
        : e == null
        ? e
        : typeof e == `object` && `x` in e && `y` in e
        ? new x(e.x, e.y)
        : new x(e, t, n);
    }
    function C(e, t) {
      if (e)
        for (var n = t ? [e, t] : e, r = 0, i = n.length; r < i; r++)
          this.extend(n[r]);
    }
    C.prototype = {
      extend: function (e) {
        var t, n;
        if (!e) return this;
        if (e instanceof x || typeof e[0] == `number` || `x` in e) t = n = S(e);
        else if (((e = w(e)), (t = e.min), (n = e.max), !t || !n)) return this;
        return (
          !this.min && !this.max
            ? ((this.min = t.clone()), (this.max = n.clone()))
            : ((this.min.x = Math.min(t.x, this.min.x)),
              (this.max.x = Math.max(n.x, this.max.x)),
              (this.min.y = Math.min(t.y, this.min.y)),
              (this.max.y = Math.max(n.y, this.max.y))),
          this
        );
      },
      getCenter: function (e) {
        return S(
          (this.min.x + this.max.x) / 2,
          (this.min.y + this.max.y) / 2,
          e
        );
      },
      getBottomLeft: function () {
        return S(this.min.x, this.max.y);
      },
      getTopRight: function () {
        return S(this.max.x, this.min.y);
      },
      getTopLeft: function () {
        return this.min;
      },
      getBottomRight: function () {
        return this.max;
      },
      getSize: function () {
        return this.max.subtract(this.min);
      },
      contains: function (e) {
        var t, n;
        return (
          (e = typeof e[0] == `number` || e instanceof x ? S(e) : w(e)),
          e instanceof C ? ((t = e.min), (n = e.max)) : (t = n = e),
          t.x >= this.min.x &&
            n.x <= this.max.x &&
            t.y >= this.min.y &&
            n.y <= this.max.y
        );
      },
      intersects: function (e) {
        e = w(e);
        var t = this.min,
          n = this.max,
          r = e.min,
          i = e.max,
          a = i.x >= t.x && r.x <= n.x,
          o = i.y >= t.y && r.y <= n.y;
        return a && o;
      },
      overlaps: function (e) {
        e = w(e);
        var t = this.min,
          n = this.max,
          r = e.min,
          i = e.max,
          a = i.x > t.x && r.x < n.x,
          o = i.y > t.y && r.y < n.y;
        return a && o;
      },
      isValid: function () {
        return !!(this.min && this.max);
      },
      pad: function (e) {
        var t = this.min,
          n = this.max,
          r = Math.abs(t.x - n.x) * e,
          i = Math.abs(t.y - n.y) * e;
        return w(S(t.x - r, t.y - i), S(n.x + r, n.y + i));
      },
      equals: function (e) {
        return e
          ? ((e = w(e)),
            this.min.equals(e.getTopLeft()) &&
              this.max.equals(e.getBottomRight()))
          : !1;
      },
    };
    function w(e, t) {
      return !e || e instanceof C ? e : new C(e, t);
    }
    function T(e, t) {
      if (e)
        for (var n = t ? [e, t] : e, r = 0, i = n.length; r < i; r++)
          this.extend(n[r]);
    }
    T.prototype = {
      extend: function (e) {
        var t = this._southWest,
          n = this._northEast,
          r,
          i;
        if (e instanceof D) (r = e), (i = e);
        else if (e instanceof T) {
          if (((r = e._southWest), (i = e._northEast), !r || !i)) return this;
        } else return e ? this.extend(O(e) || E(e)) : this;
        return (
          !t && !n
            ? ((this._southWest = new D(r.lat, r.lng)),
              (this._northEast = new D(i.lat, i.lng)))
            : ((t.lat = Math.min(r.lat, t.lat)),
              (t.lng = Math.min(r.lng, t.lng)),
              (n.lat = Math.max(i.lat, n.lat)),
              (n.lng = Math.max(i.lng, n.lng))),
          this
        );
      },
      pad: function (e) {
        var t = this._southWest,
          n = this._northEast,
          r = Math.abs(t.lat - n.lat) * e,
          i = Math.abs(t.lng - n.lng) * e;
        return new T(new D(t.lat - r, t.lng - i), new D(n.lat + r, n.lng + i));
      },
      getCenter: function () {
        return new D(
          (this._southWest.lat + this._northEast.lat) / 2,
          (this._southWest.lng + this._northEast.lng) / 2
        );
      },
      getSouthWest: function () {
        return this._southWest;
      },
      getNorthEast: function () {
        return this._northEast;
      },
      getNorthWest: function () {
        return new D(this.getNorth(), this.getWest());
      },
      getSouthEast: function () {
        return new D(this.getSouth(), this.getEast());
      },
      getWest: function () {
        return this._southWest.lng;
      },
      getSouth: function () {
        return this._southWest.lat;
      },
      getEast: function () {
        return this._northEast.lng;
      },
      getNorth: function () {
        return this._northEast.lat;
      },
      contains: function (e) {
        e =
          typeof e[0] == `number` || e instanceof D || `lat` in e ? O(e) : E(e);
        var t = this._southWest,
          n = this._northEast,
          r,
          i;
        return (
          e instanceof T
            ? ((r = e.getSouthWest()), (i = e.getNorthEast()))
            : (r = i = e),
          r.lat >= t.lat && i.lat <= n.lat && r.lng >= t.lng && i.lng <= n.lng
        );
      },
      intersects: function (e) {
        e = E(e);
        var t = this._southWest,
          n = this._northEast,
          r = e.getSouthWest(),
          i = e.getNorthEast(),
          a = i.lat >= t.lat && r.lat <= n.lat,
          o = i.lng >= t.lng && r.lng <= n.lng;
        return a && o;
      },
      overlaps: function (e) {
        e = E(e);
        var t = this._southWest,
          n = this._northEast,
          r = e.getSouthWest(),
          i = e.getNorthEast(),
          a = i.lat > t.lat && r.lat < n.lat,
          o = i.lng > t.lng && r.lng < n.lng;
        return a && o;
      },
      toBBoxString: function () {
        return [
          this.getWest(),
          this.getSouth(),
          this.getEast(),
          this.getNorth(),
        ].join(`,`);
      },
      equals: function (e, t) {
        return e
          ? ((e = E(e)),
            this._southWest.equals(e.getSouthWest(), t) &&
              this._northEast.equals(e.getNorthEast(), t))
          : !1;
      },
      isValid: function () {
        return !!(this._southWest && this._northEast);
      },
    };
    function E(e, t) {
      return e instanceof T ? e : new T(e, t);
    }
    function D(e, t, n) {
      if (isNaN(e) || isNaN(t))
        throw Error(`Invalid LatLng object: (` + e + `, ` + t + `)`);
      (this.lat = +e), (this.lng = +t), n !== void 0 && (this.alt = +n);
    }
    D.prototype = {
      equals: function (e, t) {
        return e
          ? ((e = O(e)),
            Math.max(Math.abs(this.lat - e.lat), Math.abs(this.lng - e.lng)) <=
              (t === void 0 ? 1e-9 : t))
          : !1;
      },
      toString: function (e) {
        return `LatLng(` + u(this.lat, e) + `, ` + u(this.lng, e) + `)`;
      },
      distanceTo: function (e) {
        return A.distance(this, O(e));
      },
      wrap: function () {
        return A.wrapLatLng(this);
      },
      toBounds: function (e) {
        var t = (180 * e) / 40075017,
          n = t / Math.cos((Math.PI / 180) * this.lat);
        return E([this.lat - t, this.lng - n], [this.lat + t, this.lng + n]);
      },
      clone: function () {
        return new D(this.lat, this.lng, this.alt);
      },
    };
    function O(e, t, n) {
      return e instanceof D
        ? e
        : g(e) && typeof e[0] != `object`
        ? e.length === 3
          ? new D(e[0], e[1], e[2])
          : e.length === 2
          ? new D(e[0], e[1])
          : null
        : e == null
        ? e
        : typeof e == `object` && `lat` in e
        ? new D(e.lat, `lng` in e ? e.lng : e.lon, e.alt)
        : t === void 0
        ? null
        : new D(e, t, n);
    }
    var k = {
        latLngToPoint: function (e, t) {
          var n = this.projection.project(e),
            r = this.scale(t);
          return this.transformation._transform(n, r);
        },
        pointToLatLng: function (e, t) {
          var n = this.scale(t),
            r = this.transformation.untransform(e, n);
          return this.projection.unproject(r);
        },
        project: function (e) {
          return this.projection.project(e);
        },
        unproject: function (e) {
          return this.projection.unproject(e);
        },
        scale: function (e) {
          return 256 * 2 ** e;
        },
        zoom: function (e) {
          return Math.log(e / 256) / Math.LN2;
        },
        getProjectedBounds: function (e) {
          if (this.infinite) return null;
          var t = this.projection.bounds,
            n = this.scale(e);
          return new C(
            this.transformation.transform(t.min, n),
            this.transformation.transform(t.max, n)
          );
        },
        infinite: !1,
        wrapLatLng: function (e) {
          var t = this.wrapLng ? c(e.lng, this.wrapLng, !0) : e.lng,
            n = this.wrapLat ? c(e.lat, this.wrapLat, !0) : e.lat,
            r = e.alt;
          return new D(n, t, r);
        },
        wrapLatLngBounds: function (e) {
          var t = e.getCenter(),
            n = this.wrapLatLng(t),
            r = t.lat - n.lat,
            i = t.lng - n.lng;
          if (r === 0 && i === 0) return e;
          var a = e.getSouthWest(),
            o = e.getNorthEast();
          return new T(
            new D(a.lat - r, a.lng - i),
            new D(o.lat - r, o.lng - i)
          );
        },
      },
      A = n({}, k, {
        wrapLng: [-180, 180],
        R: 6371e3,
        distance: function (e, t) {
          var n = Math.PI / 180,
            r = e.lat * n,
            i = t.lat * n,
            a = Math.sin(((t.lat - e.lat) * n) / 2),
            o = Math.sin(((t.lng - e.lng) * n) / 2),
            s = a * a + Math.cos(r) * Math.cos(i) * o * o,
            c = 2 * Math.atan2(Math.sqrt(s), Math.sqrt(1 - s));
          return this.R * c;
        },
      }),
      fe = 6378137,
      pe = {
        R: fe,
        MAX_LATITUDE: 85.0511287798,
        project: function (e) {
          var t = Math.PI / 180,
            n = this.MAX_LATITUDE,
            r = Math.max(Math.min(n, e.lat), -n),
            i = Math.sin(r * t);
          return new x(
            this.R * e.lng * t,
            (this.R * Math.log((1 + i) / (1 - i))) / 2
          );
        },
        unproject: function (e) {
          var t = 180 / Math.PI;
          return new D(
            (2 * Math.atan(Math.exp(e.y / this.R)) - Math.PI / 2) * t,
            (e.x * t) / this.R
          );
        },
        bounds: (function () {
          var e = fe * Math.PI;
          return new C([-e, -e], [e, e]);
        })(),
      };
    function me(e, t, n, r) {
      g(e)
        ? ((this._a = e[0]),
          (this._b = e[1]),
          (this._c = e[2]),
          (this._d = e[3]))
        : ((this._a = e), (this._b = t), (this._c = n), (this._d = r));
    }
    me.prototype = {
      transform: function (e, t) {
        return this._transform(e.clone(), t);
      },
      _transform: function (e, t) {
        return (
          (t ||= 1),
          (e.x = t * (this._a * e.x + this._b)),
          (e.y = t * (this._c * e.y + this._d)),
          e
        );
      },
      untransform: function (e, t) {
        return (
          (t ||= 1),
          new x((e.x / t - this._b) / this._a, (e.y / t - this._d) / this._c)
        );
      },
    };
    function he(e, t, n, r) {
      return new me(e, t, n, r);
    }
    var ge = n({}, A, {
        code: `EPSG:3857`,
        projection: pe,
        transformation: (function () {
          var e = 0.5 / (Math.PI * pe.R);
          return he(e, 0.5, -e, 0.5);
        })(),
      }),
      _e = n({}, ge, { code: `EPSG:900913` });
    function ve(e) {
      return document.createElementNS(`http://www.w3.org/2000/svg`, e);
    }
    function ye(e, t) {
      for (var n = ``, r = 0, i, a = e.length, o, s, c; r < a; r++) {
        for (s = e[r], i = 0, o = s.length; i < o; i++)
          (c = s[i]), (n += (i ? `L` : `M`) + c.x + ` ` + c.y);
        n += t ? (M.svg ? `z` : `x`) : ``;
      }
      return n || `M0 0`;
    }
    var be = document.documentElement.style,
      xe = `ActiveXObject` in window,
      Se = xe && !document.addEventListener,
      Ce = `msLaunchUri` in navigator && !(`documentMode` in document),
      we = j(`webkit`),
      Te = j(`android`),
      Ee = j(`android 2`) || j(`android 3`),
      De = parseInt(/WebKit\/([0-9]+)|$/.exec(navigator.userAgent)[1], 10),
      Oe = Te && j(`Google`) && De < 537 && !(`AudioNode` in window),
      ke = !!window.opera,
      Ae = !Ce && j(`chrome`),
      je = j(`gecko`) && !we && !ke && !xe,
      Me = !Ae && j(`safari`),
      Ne = j(`phantom`),
      Pe = `OTransition` in be,
      Fe = navigator.platform.indexOf(`Win`) === 0,
      Ie = xe && `transition` in be,
      Le =
        `WebKitCSSMatrix` in window &&
        `m11` in new window.WebKitCSSMatrix() &&
        !Ee,
      Re = `MozPerspective` in be,
      ze = !window.L_DISABLE_3D && (Ie || Le || Re) && !Pe && !Ne,
      Be = typeof orientation < `u` || j(`mobile`),
      Ve = Be && we,
      He = Be && Le,
      Ue = !window.PointerEvent && window.MSPointerEvent,
      We = !!(window.PointerEvent || Ue),
      Ge = `ontouchstart` in window || !!window.TouchEvent,
      Ke = !window.L_NO_TOUCH && (Ge || We),
      qe = Be && ke,
      Je = Be && je,
      Ye =
        (window.devicePixelRatio ||
          window.screen.deviceXDPI / window.screen.logicalXDPI) > 1,
      Xe = (function () {
        var e = !1;
        try {
          var t = Object.defineProperty({}, "passive", {
            get: function () {
              e = !0;
            },
          });
          window.addEventListener(`testPassiveEventSupport`, l, t),
            window.removeEventListener(`testPassiveEventSupport`, l, t);
        } catch {}
        return e;
      })(),
      Ze = (function () {
        return !!document.createElement(`canvas`).getContext;
      })(),
      Qe = !!(document.createElementNS && ve(`svg`).createSVGRect),
      $e =
        !!Qe &&
        (function () {
          var e = document.createElement(`div`);
          return (
            (e.innerHTML = `<svg/>`),
            (e.firstChild && e.firstChild.namespaceURI) ===
              `http://www.w3.org/2000/svg`
          );
        })(),
      et =
        !Qe &&
        (function () {
          try {
            var e = document.createElement(`div`);
            e.innerHTML = `<v:shape adj="1"/>`;
            var t = e.firstChild;
            return (
              (t.style.behavior = `url(#default#VML)`),
              t && typeof t.adj == `object`
            );
          } catch {
            return !1;
          }
        })(),
      tt = navigator.platform.indexOf(`Mac`) === 0,
      nt = navigator.platform.indexOf(`Linux`) === 0;
    function j(e) {
      return navigator.userAgent.toLowerCase().indexOf(e) >= 0;
    }
    var M = {
        ie: xe,
        ielt9: Se,
        edge: Ce,
        webkit: we,
        android: Te,
        android23: Ee,
        androidStock: Oe,
        opera: ke,
        chrome: Ae,
        gecko: je,
        safari: Me,
        phantom: Ne,
        opera12: Pe,
        win: Fe,
        ie3d: Ie,
        webkit3d: Le,
        gecko3d: Re,
        any3d: ze,
        mobile: Be,
        mobileWebkit: Ve,
        mobileWebkit3d: He,
        msPointer: Ue,
        pointer: We,
        touch: Ke,
        touchNative: Ge,
        mobileOpera: qe,
        mobileGecko: Je,
        retina: Ye,
        passiveEvents: Xe,
        canvas: Ze,
        svg: Qe,
        vml: et,
        inlineSvg: $e,
        mac: tt,
        linux: nt,
      },
      rt = M.msPointer ? `MSPointerDown` : `pointerdown`,
      it = M.msPointer ? `MSPointerMove` : `pointermove`,
      at = M.msPointer ? `MSPointerUp` : `pointerup`,
      ot = M.msPointer ? `MSPointerCancel` : `pointercancel`,
      st = { touchstart: rt, touchmove: it, touchend: at, touchcancel: ot },
      ct = { touchstart: vt, touchmove: _t, touchend: _t, touchcancel: _t },
      lt = {},
      ut = !1;
    function dt(e, t, n) {
      return (
        t === `touchstart` && gt(),
        ct[t]
          ? ((n = ct[t].bind(this, n)), e.addEventListener(st[t], n, !1), n)
          : (console.warn(`wrong event specified:`, t), l)
      );
    }
    function ft(e, t, n) {
      st[t]
        ? e.removeEventListener(st[t], n, !1)
        : console.warn(`wrong event specified:`, t);
    }
    function pt(e) {
      lt[e.pointerId] = e;
    }
    function mt(e) {
      lt[e.pointerId] && (lt[e.pointerId] = e);
    }
    function ht(e) {
      delete lt[e.pointerId];
    }
    function gt() {
      ut ||=
        (document.addEventListener(rt, pt, !0),
        document.addEventListener(it, mt, !0),
        document.addEventListener(at, ht, !0),
        document.addEventListener(ot, ht, !0),
        !0);
    }
    function _t(e, t) {
      if (t.pointerType !== (t.MSPOINTER_TYPE_MOUSE || `mouse`)) {
        for (var n in ((t.touches = []), lt)) t.touches.push(lt[n]);
        (t.changedTouches = [t]), e(t);
      }
    }
    function vt(e, t) {
      t.MSPOINTER_TYPE_TOUCH &&
        t.pointerType === t.MSPOINTER_TYPE_TOUCH &&
        U(t),
        _t(e, t);
    }
    function yt(e) {
      var t = {},
        n,
        r;
      for (r in e) (n = e[r]), (t[r] = n && n.bind ? n.bind(e) : n);
      return (
        (e = t),
        (t.type = `dblclick`),
        (t.detail = 2),
        (t.isTrusted = !1),
        (t._simulated = !0),
        t
      );
    }
    var bt = 200;
    function xt(e, t) {
      e.addEventListener(`dblclick`, t);
      var n = 0,
        r;
      function i(e) {
        if (e.detail !== 1) r = e.detail;
        else if (
          !(
            e.pointerType === `mouse` ||
            (e.sourceCapabilities && !e.sourceCapabilities.firesTouchEvents)
          )
        ) {
          var i = on(e);
          if (
            !i.some(function (e) {
              return e instanceof HTMLLabelElement && e.attributes.for;
            }) ||
            i.some(function (e) {
              return (
                e instanceof HTMLInputElement || e instanceof HTMLSelectElement
              );
            })
          ) {
            var a = Date.now();
            a - n <= bt ? (r++, r === 2 && t(yt(e))) : (r = 1), (n = a);
          }
        }
      }
      return e.addEventListener(`click`, i), { dblclick: t, simDblclick: i };
    }
    function St(e, t) {
      e.removeEventListener(`dblclick`, t.dblclick),
        e.removeEventListener(`click`, t.simDblclick);
    }
    var Ct = Ft([
        `transform`,
        `webkitTransform`,
        `OTransform`,
        `MozTransform`,
        `msTransform`,
      ]),
      wt = Ft([
        `webkitTransition`,
        `transition`,
        `OTransition`,
        `MozTransition`,
        `msTransition`,
      ]),
      Tt =
        wt === `webkitTransition` || wt === `OTransition`
          ? wt + `End`
          : `transitionend`;
    function Et(e) {
      return typeof e == `string` ? document.getElementById(e) : e;
    }
    function Dt(e, t) {
      var n = e.style[t] || (e.currentStyle && e.currentStyle[t]);
      if ((!n || n === `auto`) && document.defaultView) {
        var r = document.defaultView.getComputedStyle(e, null);
        n = r ? r[t] : null;
      }
      return n === `auto` ? null : n;
    }
    function N(e, t, n) {
      var r = document.createElement(e);
      return (r.className = t || ``), n && n.appendChild(r), r;
    }
    function P(e) {
      var t = e.parentNode;
      t && t.removeChild(e);
    }
    function Ot(e) {
      for (; e.firstChild; ) e.removeChild(e.firstChild);
    }
    function kt(e) {
      var t = e.parentNode;
      t && t.lastChild !== e && t.appendChild(e);
    }
    function At(e) {
      var t = e.parentNode;
      t && t.firstChild !== e && t.insertBefore(e, t.firstChild);
    }
    function jt(e, t) {
      if (e.classList !== void 0) return e.classList.contains(t);
      var n = Nt(e);
      return n.length > 0 && RegExp(`(^|\\s)` + t + `(\\s|$)`).test(n);
    }
    function F(e, t) {
      if (e.classList !== void 0)
        for (var n = f(t), r = 0, i = n.length; r < i; r++)
          e.classList.add(n[r]);
      else if (!jt(e, t)) {
        var a = Nt(e);
        Mt(e, (a ? a + ` ` : ``) + t);
      }
    }
    function I(e, t) {
      e.classList === void 0
        ? Mt(e, d((` ` + Nt(e) + ` `).replace(` ` + t + ` `, ` `)))
        : e.classList.remove(t);
    }
    function Mt(e, t) {
      e.className.baseVal === void 0
        ? (e.className = t)
        : (e.className.baseVal = t);
    }
    function Nt(e) {
      return (
        e.correspondingElement && (e = e.correspondingElement),
        e.className.baseVal === void 0 ? e.className : e.className.baseVal
      );
    }
    function R(e, t) {
      `opacity` in e.style
        ? (e.style.opacity = t)
        : `filter` in e.style && Pt(e, t);
    }
    function Pt(e, t) {
      var n = !1,
        r = `DXImageTransform.Microsoft.Alpha`;
      try {
        n = e.filters.item(r);
      } catch {
        if (t === 1) return;
      }
      (t = Math.round(t * 100)),
        n
          ? ((n.Enabled = t !== 100), (n.Opacity = t))
          : (e.style.filter += ` progid:` + r + `(opacity=` + t + `)`);
    }
    function Ft(e) {
      for (var t = document.documentElement.style, n = 0; n < e.length; n++)
        if (e[n] in t) return e[n];
      return !1;
    }
    function It(e, t, n) {
      var r = t || new x(0, 0);
      e.style[Ct] =
        (M.ie3d
          ? `translate(` + r.x + `px,` + r.y + `px)`
          : `translate3d(` + r.x + `px,` + r.y + `px,0)`) +
        (n ? ` scale(` + n + `)` : ``);
    }
    function z(e, t) {
      (e._leaflet_pos = t),
        M.any3d
          ? It(e, t)
          : ((e.style.left = t.x + `px`), (e.style.top = t.y + `px`));
    }
    function Lt(e) {
      return e._leaflet_pos || new x(0, 0);
    }
    var Rt, zt, Bt;
    if (`onselectstart` in document)
      (Rt = function () {
        B(window, `selectstart`, U);
      }),
        (zt = function () {
          H(window, `selectstart`, U);
        });
    else {
      var Vt = Ft([
        `userSelect`,
        `WebkitUserSelect`,
        `OUserSelect`,
        `MozUserSelect`,
        `msUserSelect`,
      ]);
      (Rt = function () {
        if (Vt) {
          var e = document.documentElement.style;
          (Bt = e[Vt]), (e[Vt] = `none`);
        }
      }),
        (zt = function () {
          Vt && ((document.documentElement.style[Vt] = Bt), (Bt = void 0));
        });
    }
    function Ht() {
      B(window, `dragstart`, U);
    }
    function Ut() {
      H(window, `dragstart`, U);
    }
    var Wt, Gt;
    function Kt(e) {
      for (; e.tabIndex === -1; ) e = e.parentNode;
      e.style &&
        (qt(),
        (Wt = e),
        (Gt = e.style.outlineStyle),
        (e.style.outlineStyle = `none`),
        B(window, `keydown`, qt));
    }
    function qt() {
      Wt &&
        ((Wt.style.outlineStyle = Gt),
        (Wt = void 0),
        (Gt = void 0),
        H(window, `keydown`, qt));
    }
    function Jt(e) {
      do e = e.parentNode;
      while ((!e.offsetWidth || !e.offsetHeight) && e !== document.body);
      return e;
    }
    function Yt(e) {
      var t = e.getBoundingClientRect();
      return {
        x: t.width / e.offsetWidth || 1,
        y: t.height / e.offsetHeight || 1,
        boundingClientRect: t,
      };
    }
    var Xt = {
      __proto__: null,
      TRANSFORM: Ct,
      TRANSITION: wt,
      TRANSITION_END: Tt,
      get: Et,
      getStyle: Dt,
      create: N,
      remove: P,
      empty: Ot,
      toFront: kt,
      toBack: At,
      hasClass: jt,
      addClass: F,
      removeClass: I,
      setClass: Mt,
      getClass: Nt,
      setOpacity: R,
      testProp: Ft,
      setTransform: It,
      setPosition: z,
      getPosition: Lt,
      get disableTextSelection() {
        return Rt;
      },
      get enableTextSelection() {
        return zt;
      },
      disableImageDrag: Ht,
      enableImageDrag: Ut,
      preventOutline: Kt,
      restoreOutline: qt,
      getSizedParentNode: Jt,
      getScale: Yt,
    };
    function B(e, t, n, r) {
      if (t && typeof t == `object`) for (var i in t) $t(e, i, t[i], n);
      else {
        t = f(t);
        for (var a = 0, o = t.length; a < o; a++) $t(e, t[a], n, r);
      }
      return this;
    }
    var V = `_leaflet_events`;
    function H(e, t, n, r) {
      if (arguments.length === 1) Zt(e), delete e[V];
      else if (t && typeof t == `object`) for (var i in t) en(e, i, t[i], n);
      else if (((t = f(t)), arguments.length === 2))
        Zt(e, function (e) {
          return te(t, e) !== -1;
        });
      else for (var a = 0, o = t.length; a < o; a++) en(e, t[a], n, r);
      return this;
    }
    function Zt(e, t) {
      for (var n in e[V]) {
        var r = n.split(/\d/)[0];
        (!t || t(r)) && en(e, r, null, null, n);
      }
    }
    var Qt = {
      mouseenter: `mouseover`,
      mouseleave: `mouseout`,
      wheel: !(`onwheel` in window) && `mousewheel`,
    };
    function $t(e, t, n, r) {
      var i = t + o(n) + (r ? `_` + o(r) : ``);
      if (e[V] && e[V][i]) return this;
      var a = function (t) {
          return n.call(r || e, t || window.event);
        },
        s = a;
      !M.touchNative && M.pointer && t.indexOf(`touch`) === 0
        ? (a = dt(e, t, a))
        : M.touch && t === `dblclick`
        ? (a = xt(e, a))
        : `addEventListener` in e
        ? t === `touchstart` ||
          t === `touchmove` ||
          t === `wheel` ||
          t === `mousewheel`
          ? e.addEventListener(
              Qt[t] || t,
              a,
              M.passiveEvents ? { passive: !1 } : !1
            )
          : t === `mouseenter` || t === `mouseleave`
          ? ((a = function (t) {
              (t ||= window.event), un(e, t) && s(t);
            }),
            e.addEventListener(Qt[t], a, !1))
          : e.addEventListener(t, s, !1)
        : e.attachEvent(`on` + t, a),
        (e[V] = e[V] || {}),
        (e[V][i] = a);
    }
    function en(e, t, n, r, i) {
      i ||= t + o(n) + (r ? `_` + o(r) : ``);
      var a = e[V] && e[V][i];
      if (!a) return this;
      !M.touchNative && M.pointer && t.indexOf(`touch`) === 0
        ? ft(e, t, a)
        : M.touch && t === `dblclick`
        ? St(e, a)
        : `removeEventListener` in e
        ? e.removeEventListener(Qt[t] || t, a, !1)
        : e.detachEvent(`on` + t, a),
        (e[V][i] = null);
    }
    function tn(e) {
      return (
        e.stopPropagation
          ? e.stopPropagation()
          : e.originalEvent
          ? (e.originalEvent._stopped = !0)
          : (e.cancelBubble = !0),
        this
      );
    }
    function nn(e) {
      return $t(e, `wheel`, tn), this;
    }
    function rn(e) {
      return (
        B(e, `mousedown touchstart dblclick contextmenu`, tn),
        (e._leaflet_disable_click = !0),
        this
      );
    }
    function U(e) {
      return e.preventDefault ? e.preventDefault() : (e.returnValue = !1), this;
    }
    function an(e) {
      return U(e), tn(e), this;
    }
    function on(e) {
      if (e.composedPath) return e.composedPath();
      for (var t = [], n = e.target; n; ) t.push(n), (n = n.parentNode);
      return t;
    }
    function sn(e, t) {
      if (!t) return new x(e.clientX, e.clientY);
      var n = Yt(t),
        r = n.boundingClientRect;
      return new x(
        (e.clientX - r.left) / n.x - t.clientLeft,
        (e.clientY - r.top) / n.y - t.clientTop
      );
    }
    var cn =
      M.linux && M.chrome
        ? window.devicePixelRatio
        : M.mac
        ? window.devicePixelRatio * 3
        : window.devicePixelRatio > 0
        ? 2 * window.devicePixelRatio
        : 1;
    function ln(e) {
      return M.edge
        ? e.wheelDeltaY / 2
        : e.deltaY && e.deltaMode === 0
        ? -e.deltaY / cn
        : e.deltaY && e.deltaMode === 1
        ? -e.deltaY * 20
        : e.deltaY && e.deltaMode === 2
        ? -e.deltaY * 60
        : e.deltaX || e.deltaZ
        ? 0
        : e.wheelDelta
        ? (e.wheelDeltaY || e.wheelDelta) / 2
        : e.detail && Math.abs(e.detail) < 32765
        ? -e.detail * 20
        : e.detail
        ? (e.detail / -32765) * 60
        : 0;
    }
    function un(e, t) {
      var n = t.relatedTarget;
      if (!n) return !0;
      try {
        for (; n && n !== e; ) n = n.parentNode;
      } catch {
        return !1;
      }
      return n !== e;
    }
    var dn = {
        __proto__: null,
        on: B,
        off: H,
        stopPropagation: tn,
        disableScrollPropagation: nn,
        disableClickPropagation: rn,
        preventDefault: U,
        stop: an,
        getPropagationPath: on,
        getMousePosition: sn,
        getWheelDelta: ln,
        isExternalTarget: un,
        addListener: B,
        removeListener: H,
      },
      fn = ue.extend({
        run: function (e, t, n, r) {
          this.stop(),
            (this._el = e),
            (this._inProgress = !0),
            (this._duration = n || 0.25),
            (this._easeOutPower = 1 / Math.max(r || 0.5, 0.2)),
            (this._startPos = Lt(e)),
            (this._offset = t.subtract(this._startPos)),
            (this._startTime = +new Date()),
            this.fire(`start`),
            this._animate();
        },
        stop: function () {
          this._inProgress && (this._step(!0), this._complete());
        },
        _animate: function () {
          (this._animId = _(this._animate, this)), this._step();
        },
        _step: function (e) {
          var t = +new Date() - this._startTime,
            n = this._duration * 1e3;
          t < n
            ? this._runFrame(this._easeOut(t / n), e)
            : (this._runFrame(1), this._complete());
        },
        _runFrame: function (e, t) {
          var n = this._startPos.add(this._offset.multiplyBy(e));
          t && n._round(), z(this._el, n), this.fire(`step`);
        },
        _complete: function () {
          v(this._animId), (this._inProgress = !1), this.fire(`end`);
        },
        _easeOut: function (e) {
          return 1 - (1 - e) ** this._easeOutPower;
        },
      }),
      W = ue.extend({
        options: {
          crs: ge,
          center: void 0,
          zoom: void 0,
          minZoom: void 0,
          maxZoom: void 0,
          layers: [],
          maxBounds: void 0,
          renderer: void 0,
          zoomAnimation: !0,
          zoomAnimationThreshold: 4,
          fadeAnimation: !0,
          markerZoomAnimation: !0,
          transform3DLimit: 8388608,
          zoomSnap: 1,
          zoomDelta: 1,
          trackResize: !0,
        },
        initialize: function (e, t) {
          (t = p(this, t)),
            (this._handlers = []),
            (this._layers = {}),
            (this._zoomBoundLayers = {}),
            (this._sizeChanged = !0),
            this._initContainer(e),
            this._initLayout(),
            (this._onResize = i(this._onResize, this)),
            this._initEvents(),
            t.maxBounds && this.setMaxBounds(t.maxBounds),
            t.zoom !== void 0 && (this._zoom = this._limitZoom(t.zoom)),
            t.center &&
              t.zoom !== void 0 &&
              this.setView(O(t.center), t.zoom, { reset: !0 }),
            this.callInitHooks(),
            (this._zoomAnimated =
              wt && M.any3d && !M.mobileOpera && this.options.zoomAnimation),
            this._zoomAnimated &&
              (this._createAnimProxy(),
              B(this._proxy, Tt, this._catchTransitionEnd, this)),
            this._addLayers(this.options.layers);
        },
        setView: function (e, t, r) {
          return (
            (t = t === void 0 ? this._zoom : this._limitZoom(t)),
            (e = this._limitCenter(O(e), t, this.options.maxBounds)),
            (r ||= {}),
            this._stop(),
            this._loaded &&
            !r.reset &&
            r !== !0 &&
            (r.animate !== void 0 &&
              ((r.zoom = n({ animate: r.animate }, r.zoom)),
              (r.pan = n({ animate: r.animate, duration: r.duration }, r.pan))),
            this._zoom === t
              ? this._tryAnimatedPan(e, r.pan)
              : this._tryAnimatedZoom && this._tryAnimatedZoom(e, t, r.zoom))
              ? (clearTimeout(this._sizeTimer), this)
              : (this._resetView(e, t, r.pan && r.pan.noMoveStart), this)
          );
        },
        setZoom: function (e, t) {
          return this._loaded
            ? this.setView(this.getCenter(), e, { zoom: t })
            : ((this._zoom = e), this);
        },
        zoomIn: function (e, t) {
          return (
            (e ||= M.any3d ? this.options.zoomDelta : 1),
            this.setZoom(this._zoom + e, t)
          );
        },
        zoomOut: function (e, t) {
          return (
            (e ||= M.any3d ? this.options.zoomDelta : 1),
            this.setZoom(this._zoom - e, t)
          );
        },
        setZoomAround: function (e, t, n) {
          var r = this.getZoomScale(t),
            i = this.getSize().divideBy(2),
            a = (e instanceof x ? e : this.latLngToContainerPoint(e))
              .subtract(i)
              .multiplyBy(1 - 1 / r),
            o = this.containerPointToLatLng(i.add(a));
          return this.setView(o, t, { zoom: n });
        },
        _getBoundsCenterZoom: function (e, t) {
          (t ||= {}), (e = e.getBounds ? e.getBounds() : E(e));
          var n = S(t.paddingTopLeft || t.padding || [0, 0]),
            r = S(t.paddingBottomRight || t.padding || [0, 0]),
            i = this.getBoundsZoom(e, !1, n.add(r));
          if (
            ((i = typeof t.maxZoom == `number` ? Math.min(t.maxZoom, i) : i),
            i === 1 / 0)
          )
            return { center: e.getCenter(), zoom: i };
          var a = r.subtract(n).divideBy(2),
            o = this.project(e.getSouthWest(), i),
            s = this.project(e.getNorthEast(), i);
          return {
            center: this.unproject(o.add(s).divideBy(2).add(a), i),
            zoom: i,
          };
        },
        fitBounds: function (e, t) {
          if (((e = E(e)), !e.isValid())) throw Error(`Bounds are not valid.`);
          var n = this._getBoundsCenterZoom(e, t);
          return this.setView(n.center, n.zoom, t);
        },
        fitWorld: function (e) {
          return this.fitBounds(
            [
              [-90, -180],
              [90, 180],
            ],
            e
          );
        },
        panTo: function (e, t) {
          return this.setView(e, this._zoom, { pan: t });
        },
        panBy: function (e, t) {
          if (((e = S(e).round()), (t ||= {}), !e.x && !e.y))
            return this.fire(`moveend`);
          if (t.animate !== !0 && !this.getSize().contains(e))
            return (
              this._resetView(
                this.unproject(this.project(this.getCenter()).add(e)),
                this.getZoom()
              ),
              this
            );
          if (
            (this._panAnim ||
              ((this._panAnim = new fn()),
              this._panAnim.on(
                {
                  step: this._onPanTransitionStep,
                  end: this._onPanTransitionEnd,
                },
                this
              )),
            t.noMoveStart || this.fire(`movestart`),
            t.animate !== !1)
          ) {
            F(this._mapPane, `leaflet-pan-anim`);
            var n = this._getMapPanePos().subtract(e).round();
            this._panAnim.run(
              this._mapPane,
              n,
              t.duration || 0.25,
              t.easeLinearity
            );
          } else this._rawPanBy(e), this.fire(`move`).fire(`moveend`);
          return this;
        },
        flyTo: function (e, t, n) {
          if (((n ||= {}), n.animate === !1 || !M.any3d))
            return this.setView(e, t, n);
          this._stop();
          var r = this.project(this.getCenter()),
            i = this.project(e),
            a = this.getSize(),
            o = this._zoom;
          (e = O(e)), (t = t === void 0 ? o : t);
          var s = Math.max(a.x, a.y),
            c = s * this.getZoomScale(o, t),
            l = i.distanceTo(r) || 1,
            u = 1.42,
            d = u * u;
          function f(e) {
            var t = e ? -1 : 1,
              n = e ? c : s,
              r = (c * c - s * s + t * d * d * l * l) / (2 * n * d * l),
              i = Math.sqrt(r * r + 1) - r;
            return i < 1e-9 ? -18 : Math.log(i);
          }
          function p(e) {
            return (Math.exp(e) - Math.exp(-e)) / 2;
          }
          function m(e) {
            return (Math.exp(e) + Math.exp(-e)) / 2;
          }
          function ee(e) {
            return p(e) / m(e);
          }
          var h = f(0);
          function g(e) {
            return s * (m(h) / m(h + u * e));
          }
          function te(e) {
            return (s * (m(h) * ee(h + u * e) - p(h))) / d;
          }
          function ne(e) {
            return 1 - (1 - e) ** 1.5;
          }
          var re = Date.now(),
            ie = (f(1) - h) / u,
            ae = n.duration ? 1e3 * n.duration : 1e3 * ie * 0.8;
          function oe() {
            var n = (Date.now() - re) / ae,
              a = ne(n) * ie;
            n <= 1
              ? ((this._flyToFrame = _(oe, this)),
                this._move(
                  this.unproject(r.add(i.subtract(r).multiplyBy(te(a) / l)), o),
                  this.getScaleZoom(s / g(a), o),
                  { flyTo: !0 }
                ))
              : this._move(e, t)._moveEnd(!0);
          }
          return this._moveStart(!0, n.noMoveStart), oe.call(this), this;
        },
        flyToBounds: function (e, t) {
          var n = this._getBoundsCenterZoom(e, t);
          return this.flyTo(n.center, n.zoom, t);
        },
        setMaxBounds: function (e) {
          return (
            (e = E(e)),
            this.listens(`moveend`, this._panInsideMaxBounds) &&
              this.off(`moveend`, this._panInsideMaxBounds),
            e.isValid()
              ? ((this.options.maxBounds = e),
                this._loaded && this._panInsideMaxBounds(),
                this.on(`moveend`, this._panInsideMaxBounds))
              : ((this.options.maxBounds = null), this)
          );
        },
        setMinZoom: function (e) {
          var t = this.options.minZoom;
          return (
            (this.options.minZoom = e),
            this._loaded &&
            t !== e &&
            (this.fire(`zoomlevelschange`),
            this.getZoom() < this.options.minZoom)
              ? this.setZoom(e)
              : this
          );
        },
        setMaxZoom: function (e) {
          var t = this.options.maxZoom;
          return (
            (this.options.maxZoom = e),
            this._loaded &&
            t !== e &&
            (this.fire(`zoomlevelschange`),
            this.getZoom() > this.options.maxZoom)
              ? this.setZoom(e)
              : this
          );
        },
        panInsideBounds: function (e, t) {
          this._enforcingBounds = !0;
          var n = this.getCenter(),
            r = this._limitCenter(n, this._zoom, E(e));
          return (
            n.equals(r) || this.panTo(r, t), (this._enforcingBounds = !1), this
          );
        },
        panInside: function (e, t) {
          t ||= {};
          var n = S(t.paddingTopLeft || t.padding || [0, 0]),
            r = S(t.paddingBottomRight || t.padding || [0, 0]),
            i = this.project(this.getCenter()),
            a = this.project(e),
            o = this.getPixelBounds(),
            s = w([o.min.add(n), o.max.subtract(r)]),
            c = s.getSize();
          if (!s.contains(a)) {
            this._enforcingBounds = !0;
            var l = a.subtract(s.getCenter()),
              u = s.extend(a).getSize().subtract(c);
            (i.x += l.x < 0 ? -u.x : u.x),
              (i.y += l.y < 0 ? -u.y : u.y),
              this.panTo(this.unproject(i), t),
              (this._enforcingBounds = !1);
          }
          return this;
        },
        invalidateSize: function (e) {
          if (!this._loaded) return this;
          e = n({ animate: !1, pan: !0 }, e === !0 ? { animate: !0 } : e);
          var t = this.getSize();
          (this._sizeChanged = !0), (this._lastCenter = null);
          var r = this.getSize(),
            a = t.divideBy(2).round(),
            o = r.divideBy(2).round(),
            s = a.subtract(o);
          return !s.x && !s.y
            ? this
            : (e.animate && e.pan
                ? this.panBy(s)
                : (e.pan && this._rawPanBy(s),
                  this.fire(`move`),
                  e.debounceMoveend
                    ? (clearTimeout(this._sizeTimer),
                      (this._sizeTimer = setTimeout(
                        i(this.fire, this, `moveend`),
                        200
                      )))
                    : this.fire(`moveend`)),
              this.fire(`resize`, { oldSize: t, newSize: r }));
        },
        stop: function () {
          return (
            this.setZoom(this._limitZoom(this._zoom)),
            this.options.zoomSnap || this.fire(`viewreset`),
            this._stop()
          );
        },
        locate: function (e) {
          if (
            ((e = this._locateOptions = n({ timeout: 1e4, watch: !1 }, e)),
            !(`geolocation` in navigator))
          )
            return (
              this._handleGeolocationError({
                code: 0,
                message: `Geolocation not supported.`,
              }),
              this
            );
          var t = i(this._handleGeolocationResponse, this),
            r = i(this._handleGeolocationError, this);
          return (
            e.watch
              ? (this._locationWatchId = navigator.geolocation.watchPosition(
                  t,
                  r,
                  e
                ))
              : navigator.geolocation.getCurrentPosition(t, r, e),
            this
          );
        },
        stopLocate: function () {
          return (
            navigator.geolocation &&
              navigator.geolocation.clearWatch &&
              navigator.geolocation.clearWatch(this._locationWatchId),
            this._locateOptions && (this._locateOptions.setView = !1),
            this
          );
        },
        _handleGeolocationError: function (e) {
          if (this._container._leaflet_id) {
            var t = e.code,
              n =
                e.message ||
                (t === 1
                  ? `permission denied`
                  : t === 2
                  ? `position unavailable`
                  : `timeout`);
            this._locateOptions.setView && !this._loaded && this.fitWorld(),
              this.fire(`locationerror`, {
                code: t,
                message: `Geolocation error: ` + n + `.`,
              });
          }
        },
        _handleGeolocationResponse: function (e) {
          if (this._container._leaflet_id) {
            var t = e.coords.latitude,
              n = e.coords.longitude,
              r = new D(t, n),
              i = r.toBounds(e.coords.accuracy * 2),
              a = this._locateOptions;
            if (a.setView) {
              var o = this.getBoundsZoom(i);
              this.setView(r, a.maxZoom ? Math.min(o, a.maxZoom) : o);
            }
            var s = { latlng: r, bounds: i, timestamp: e.timestamp };
            for (var c in e.coords)
              typeof e.coords[c] == `number` && (s[c] = e.coords[c]);
            this.fire(`locationfound`, s);
          }
        },
        addHandler: function (e, t) {
          if (!t) return this;
          var n = (this[e] = new t(this));
          return this._handlers.push(n), this.options[e] && n.enable(), this;
        },
        remove: function () {
          if (
            (this._initEvents(!0),
            this.options.maxBounds &&
              this.off(`moveend`, this._panInsideMaxBounds),
            this._containerId !== this._container._leaflet_id)
          )
            throw Error(`Map container is being reused by another instance`);
          try {
            delete this._container._leaflet_id, delete this._containerId;
          } catch {
            (this._container._leaflet_id = void 0),
              (this._containerId = void 0);
          }
          for (var e in (this._locationWatchId !== void 0 && this.stopLocate(),
          this._stop(),
          P(this._mapPane),
          this._clearControlPos && this._clearControlPos(),
          (this._resizeRequest &&= (v(this._resizeRequest), null)),
          this._clearHandlers(),
          this._loaded && this.fire(`unload`),
          this._layers))
            this._layers[e].remove();
          for (e in this._panes) P(this._panes[e]);
          return (
            (this._layers = []),
            (this._panes = []),
            delete this._mapPane,
            delete this._renderer,
            this
          );
        },
        createPane: function (e, t) {
          var n = N(
            `div`,
            `leaflet-pane` +
              (e ? ` leaflet-` + e.replace(`Pane`, ``) + `-pane` : ``),
            t || this._mapPane
          );
          return e && (this._panes[e] = n), n;
        },
        getCenter: function () {
          return (
            this._checkIfLoaded(),
            this._lastCenter && !this._moved()
              ? this._lastCenter.clone()
              : this.layerPointToLatLng(this._getCenterLayerPoint())
          );
        },
        getZoom: function () {
          return this._zoom;
        },
        getBounds: function () {
          var e = this.getPixelBounds();
          return new T(
            this.unproject(e.getBottomLeft()),
            this.unproject(e.getTopRight())
          );
        },
        getMinZoom: function () {
          return this.options.minZoom === void 0
            ? this._layersMinZoom || 0
            : this.options.minZoom;
        },
        getMaxZoom: function () {
          return this.options.maxZoom === void 0
            ? this._layersMaxZoom === void 0
              ? 1 / 0
              : this._layersMaxZoom
            : this.options.maxZoom;
        },
        getBoundsZoom: function (e, t, n) {
          (e = E(e)), (n = S(n || [0, 0]));
          var r = this.getZoom() || 0,
            i = this.getMinZoom(),
            a = this.getMaxZoom(),
            o = e.getNorthWest(),
            s = e.getSouthEast(),
            c = this.getSize().subtract(n),
            l = w(this.project(s, r), this.project(o, r)).getSize(),
            u = M.any3d ? this.options.zoomSnap : 1,
            d = c.x / l.x,
            f = c.y / l.y,
            p = t ? Math.max(d, f) : Math.min(d, f);
          return (
            (r = this.getScaleZoom(p, r)),
            u &&
              ((r = Math.round(r / (u / 100)) * (u / 100)),
              (r = t ? Math.ceil(r / u) * u : Math.floor(r / u) * u)),
            Math.max(i, Math.min(a, r))
          );
        },
        getSize: function () {
          return (
            (!this._size || this._sizeChanged) &&
              ((this._size = new x(
                this._container.clientWidth || 0,
                this._container.clientHeight || 0
              )),
              (this._sizeChanged = !1)),
            this._size.clone()
          );
        },
        getPixelBounds: function (e, t) {
          var n = this._getTopLeftPoint(e, t);
          return new C(n, n.add(this.getSize()));
        },
        getPixelOrigin: function () {
          return this._checkIfLoaded(), this._pixelOrigin;
        },
        getPixelWorldBounds: function (e) {
          return this.options.crs.getProjectedBounds(
            e === void 0 ? this.getZoom() : e
          );
        },
        getPane: function (e) {
          return typeof e == `string` ? this._panes[e] : e;
        },
        getPanes: function () {
          return this._panes;
        },
        getContainer: function () {
          return this._container;
        },
        getZoomScale: function (e, t) {
          var n = this.options.crs;
          return (t = t === void 0 ? this._zoom : t), n.scale(e) / n.scale(t);
        },
        getScaleZoom: function (e, t) {
          var n = this.options.crs;
          t = t === void 0 ? this._zoom : t;
          var r = n.zoom(e * n.scale(t));
          return isNaN(r) ? 1 / 0 : r;
        },
        project: function (e, t) {
          return (
            (t = t === void 0 ? this._zoom : t),
            this.options.crs.latLngToPoint(O(e), t)
          );
        },
        unproject: function (e, t) {
          return (
            (t = t === void 0 ? this._zoom : t),
            this.options.crs.pointToLatLng(S(e), t)
          );
        },
        layerPointToLatLng: function (e) {
          var t = S(e).add(this.getPixelOrigin());
          return this.unproject(t);
        },
        latLngToLayerPoint: function (e) {
          return this.project(O(e))._round()._subtract(this.getPixelOrigin());
        },
        wrapLatLng: function (e) {
          return this.options.crs.wrapLatLng(O(e));
        },
        wrapLatLngBounds: function (e) {
          return this.options.crs.wrapLatLngBounds(E(e));
        },
        distance: function (e, t) {
          return this.options.crs.distance(O(e), O(t));
        },
        containerPointToLayerPoint: function (e) {
          return S(e).subtract(this._getMapPanePos());
        },
        layerPointToContainerPoint: function (e) {
          return S(e).add(this._getMapPanePos());
        },
        containerPointToLatLng: function (e) {
          var t = this.containerPointToLayerPoint(S(e));
          return this.layerPointToLatLng(t);
        },
        latLngToContainerPoint: function (e) {
          return this.layerPointToContainerPoint(this.latLngToLayerPoint(O(e)));
        },
        mouseEventToContainerPoint: function (e) {
          return sn(e, this._container);
        },
        mouseEventToLayerPoint: function (e) {
          return this.containerPointToLayerPoint(
            this.mouseEventToContainerPoint(e)
          );
        },
        mouseEventToLatLng: function (e) {
          return this.layerPointToLatLng(this.mouseEventToLayerPoint(e));
        },
        _initContainer: function (e) {
          var t = (this._container = Et(e));
          if (!t) throw Error(`Map container not found.`);
          if (t._leaflet_id)
            throw Error(`Map container is already initialized.`);
          B(t, `scroll`, this._onScroll, this), (this._containerId = o(t));
        },
        _initLayout: function () {
          var e = this._container;
          (this._fadeAnimated = this.options.fadeAnimation && M.any3d),
            F(
              e,
              `leaflet-container` +
                (M.touch ? ` leaflet-touch` : ``) +
                (M.retina ? ` leaflet-retina` : ``) +
                (M.ielt9 ? ` leaflet-oldie` : ``) +
                (M.safari ? ` leaflet-safari` : ``) +
                (this._fadeAnimated ? ` leaflet-fade-anim` : ``)
            );
          var t = Dt(e, `position`);
          t !== `absolute` &&
            t !== `relative` &&
            t !== `fixed` &&
            t !== `sticky` &&
            (e.style.position = `relative`),
            this._initPanes(),
            this._initControlPos && this._initControlPos();
        },
        _initPanes: function () {
          var e = (this._panes = {});
          (this._paneRenderers = {}),
            (this._mapPane = this.createPane(`mapPane`, this._container)),
            z(this._mapPane, new x(0, 0)),
            this.createPane(`tilePane`),
            this.createPane(`overlayPane`),
            this.createPane(`shadowPane`),
            this.createPane(`markerPane`),
            this.createPane(`tooltipPane`),
            this.createPane(`popupPane`),
            this.options.markerZoomAnimation ||
              (F(e.markerPane, `leaflet-zoom-hide`),
              F(e.shadowPane, `leaflet-zoom-hide`));
        },
        _resetView: function (e, t, n) {
          z(this._mapPane, new x(0, 0));
          var r = !this._loaded;
          (this._loaded = !0),
            (t = this._limitZoom(t)),
            this.fire(`viewprereset`);
          var i = this._zoom !== t;
          this._moveStart(i, n)._move(e, t)._moveEnd(i),
            this.fire(`viewreset`),
            r && this.fire(`load`);
        },
        _moveStart: function (e, t) {
          return e && this.fire(`zoomstart`), t || this.fire(`movestart`), this;
        },
        _move: function (e, t, n, r) {
          t === void 0 && (t = this._zoom);
          var i = this._zoom !== t;
          return (
            (this._zoom = t),
            (this._lastCenter = e),
            (this._pixelOrigin = this._getNewPixelOrigin(e)),
            r
              ? n && n.pinch && this.fire(`zoom`, n)
              : ((i || (n && n.pinch)) && this.fire(`zoom`, n),
                this.fire(`move`, n)),
            this
          );
        },
        _moveEnd: function (e) {
          return e && this.fire(`zoomend`), this.fire(`moveend`);
        },
        _stop: function () {
          return (
            v(this._flyToFrame), this._panAnim && this._panAnim.stop(), this
          );
        },
        _rawPanBy: function (e) {
          z(this._mapPane, this._getMapPanePos().subtract(e));
        },
        _getZoomSpan: function () {
          return this.getMaxZoom() - this.getMinZoom();
        },
        _panInsideMaxBounds: function () {
          this._enforcingBounds || this.panInsideBounds(this.options.maxBounds);
        },
        _checkIfLoaded: function () {
          if (!this._loaded) throw Error(`Set map center and zoom first.`);
        },
        _initEvents: function (e) {
          (this._targets = {}), (this._targets[o(this._container)] = this);
          var t = e ? H : B;
          t(
            this._container,
            `click dblclick mousedown mouseup mouseover mouseout mousemove contextmenu keypress keydown keyup`,
            this._handleDOMEvent,
            this
          ),
            this.options.trackResize &&
              t(window, `resize`, this._onResize, this),
            M.any3d &&
              this.options.transform3DLimit &&
              (e ? this.off : this.on).call(this, `moveend`, this._onMoveEnd);
        },
        _onResize: function () {
          v(this._resizeRequest),
            (this._resizeRequest = _(function () {
              this.invalidateSize({ debounceMoveend: !0 });
            }, this));
        },
        _onScroll: function () {
          (this._container.scrollTop = 0), (this._container.scrollLeft = 0);
        },
        _onMoveEnd: function () {
          var e = this._getMapPanePos();
          Math.max(Math.abs(e.x), Math.abs(e.y)) >=
            this.options.transform3DLimit &&
            this._resetView(this.getCenter(), this.getZoom());
        },
        _findEventTargets: function (e, t) {
          for (
            var n = [],
              r,
              i = t === `mouseout` || t === `mouseover`,
              a = e.target || e.srcElement,
              s = !1;
            a;

          ) {
            if (
              ((r = this._targets[o(a)]),
              r &&
                (t === `click` || t === `preclick`) &&
                this._draggableMoved(r))
            ) {
              s = !0;
              break;
            }
            if (
              (r && r.listens(t, !0) && ((i && !un(a, e)) || (n.push(r), i))) ||
              a === this._container
            )
              break;
            a = a.parentNode;
          }
          return (
            !n.length && !s && !i && this.listens(t, !0) && (n = [this]), n
          );
        },
        _isClickDisabled: function (e) {
          for (; e && e !== this._container; ) {
            if (e._leaflet_disable_click) return !0;
            e = e.parentNode;
          }
        },
        _handleDOMEvent: function (e) {
          var t = e.target || e.srcElement;
          if (
            !(
              !this._loaded ||
              t._leaflet_disable_events ||
              (e.type === `click` && this._isClickDisabled(t))
            )
          ) {
            var n = e.type;
            n === `mousedown` && Kt(t), this._fireDOMEvent(e, n);
          }
        },
        _mouseEvents: [
          `click`,
          `dblclick`,
          `mouseover`,
          `mouseout`,
          `contextmenu`,
        ],
        _fireDOMEvent: function (e, t, r) {
          if (e.type === `click`) {
            var i = n({}, e);
            (i.type = `preclick`), this._fireDOMEvent(i, i.type, r);
          }
          var a = this._findEventTargets(e, t);
          if (r) {
            for (var o = [], s = 0; s < r.length; s++)
              r[s].listens(t, !0) && o.push(r[s]);
            a = o.concat(a);
          }
          if (a.length) {
            t === `contextmenu` && U(e);
            var c = a[0],
              l = { originalEvent: e };
            if (
              e.type !== `keypress` &&
              e.type !== `keydown` &&
              e.type !== `keyup`
            ) {
              var u = c.getLatLng && (!c._radius || c._radius <= 10);
              (l.containerPoint = u
                ? this.latLngToContainerPoint(c.getLatLng())
                : this.mouseEventToContainerPoint(e)),
                (l.layerPoint = this.containerPointToLayerPoint(
                  l.containerPoint
                )),
                (l.latlng = u
                  ? c.getLatLng()
                  : this.layerPointToLatLng(l.layerPoint));
            }
            for (s = 0; s < a.length; s++)
              if (
                (a[s].fire(t, l, !0),
                l.originalEvent._stopped ||
                  (a[s].options.bubblingMouseEvents === !1 &&
                    te(this._mouseEvents, t) !== -1))
              )
                return;
          }
        },
        _draggableMoved: function (e) {
          return (
            (e = e.dragging && e.dragging.enabled() ? e : this),
            (e.dragging && e.dragging.moved()) ||
              (this.boxZoom && this.boxZoom.moved())
          );
        },
        _clearHandlers: function () {
          for (var e = 0, t = this._handlers.length; e < t; e++)
            this._handlers[e].disable();
        },
        whenReady: function (e, t) {
          return (
            this._loaded
              ? e.call(t || this, { target: this })
              : this.on(`load`, e, t),
            this
          );
        },
        _getMapPanePos: function () {
          return Lt(this._mapPane) || new x(0, 0);
        },
        _moved: function () {
          var e = this._getMapPanePos();
          return e && !e.equals([0, 0]);
        },
        _getTopLeftPoint: function (e, t) {
          return (
            e && t !== void 0
              ? this._getNewPixelOrigin(e, t)
              : this.getPixelOrigin()
          ).subtract(this._getMapPanePos());
        },
        _getNewPixelOrigin: function (e, t) {
          var n = this.getSize()._divideBy(2);
          return this.project(e, t)
            ._subtract(n)
            ._add(this._getMapPanePos())
            ._round();
        },
        _latLngToNewLayerPoint: function (e, t, n) {
          var r = this._getNewPixelOrigin(n, t);
          return this.project(e, t)._subtract(r);
        },
        _latLngBoundsToNewLayerBounds: function (e, t, n) {
          var r = this._getNewPixelOrigin(n, t);
          return w([
            this.project(e.getSouthWest(), t)._subtract(r),
            this.project(e.getNorthWest(), t)._subtract(r),
            this.project(e.getSouthEast(), t)._subtract(r),
            this.project(e.getNorthEast(), t)._subtract(r),
          ]);
        },
        _getCenterLayerPoint: function () {
          return this.containerPointToLayerPoint(this.getSize()._divideBy(2));
        },
        _getCenterOffset: function (e) {
          return this.latLngToLayerPoint(e).subtract(
            this._getCenterLayerPoint()
          );
        },
        _limitCenter: function (e, t, n) {
          if (!n) return e;
          var r = this.project(e, t),
            i = this.getSize().divideBy(2),
            a = new C(r.subtract(i), r.add(i)),
            o = this._getBoundsOffset(a, n, t);
          return Math.abs(o.x) <= 1 && Math.abs(o.y) <= 1
            ? e
            : this.unproject(r.add(o), t);
        },
        _limitOffset: function (e, t) {
          if (!t) return e;
          var n = this.getPixelBounds(),
            r = new C(n.min.add(e), n.max.add(e));
          return e.add(this._getBoundsOffset(r, t));
        },
        _getBoundsOffset: function (e, t, n) {
          var r = w(
              this.project(t.getNorthEast(), n),
              this.project(t.getSouthWest(), n)
            ),
            i = r.min.subtract(e.min),
            a = r.max.subtract(e.max);
          return new x(this._rebound(i.x, -a.x), this._rebound(i.y, -a.y));
        },
        _rebound: function (e, t) {
          return e + t > 0
            ? Math.round(e - t) / 2
            : Math.max(0, Math.ceil(e)) - Math.max(0, Math.floor(t));
        },
        _limitZoom: function (e) {
          var t = this.getMinZoom(),
            n = this.getMaxZoom(),
            r = M.any3d ? this.options.zoomSnap : 1;
          return r && (e = Math.round(e / r) * r), Math.max(t, Math.min(n, e));
        },
        _onPanTransitionStep: function () {
          this.fire(`move`);
        },
        _onPanTransitionEnd: function () {
          I(this._mapPane, `leaflet-pan-anim`), this.fire(`moveend`);
        },
        _tryAnimatedPan: function (e, t) {
          var n = this._getCenterOffset(e)._trunc();
          return (t && t.animate) !== !0 && !this.getSize().contains(n)
            ? !1
            : (this.panBy(n, t), !0);
        },
        _createAnimProxy: function () {
          var e = (this._proxy = N(
            `div`,
            `leaflet-proxy leaflet-zoom-animated`
          ));
          this._panes.mapPane.appendChild(e),
            this.on(
              `zoomanim`,
              function (e) {
                var t = Ct,
                  n = this._proxy.style[t];
                It(
                  this._proxy,
                  this.project(e.center, e.zoom),
                  this.getZoomScale(e.zoom, 1)
                ),
                  n === this._proxy.style[t] &&
                    this._animatingZoom &&
                    this._onZoomTransitionEnd();
              },
              this
            ),
            this.on(`load moveend`, this._animMoveEnd, this),
            this._on(`unload`, this._destroyAnimProxy, this);
        },
        _destroyAnimProxy: function () {
          P(this._proxy),
            this.off(`load moveend`, this._animMoveEnd, this),
            delete this._proxy;
        },
        _animMoveEnd: function () {
          var e = this.getCenter(),
            t = this.getZoom();
          It(this._proxy, this.project(e, t), this.getZoomScale(t, 1));
        },
        _catchTransitionEnd: function (e) {
          this._animatingZoom &&
            e.propertyName.indexOf(`transform`) >= 0 &&
            this._onZoomTransitionEnd();
        },
        _nothingToAnimate: function () {
          return !this._container.getElementsByClassName(
            `leaflet-zoom-animated`
          ).length;
        },
        _tryAnimatedZoom: function (e, t, n) {
          if (this._animatingZoom) return !0;
          if (
            ((n ||= {}),
            !this._zoomAnimated ||
              n.animate === !1 ||
              this._nothingToAnimate() ||
              Math.abs(t - this._zoom) > this.options.zoomAnimationThreshold)
          )
            return !1;
          var r = this.getZoomScale(t),
            i = this._getCenterOffset(e)._divideBy(1 - 1 / r);
          return n.animate !== !0 && !this.getSize().contains(i)
            ? !1
            : (_(function () {
                this._moveStart(!0, n.noMoveStart || !1)._animateZoom(e, t, !0);
              }, this),
              !0);
        },
        _animateZoom: function (e, t, n, r) {
          this._mapPane &&
            (n &&
              ((this._animatingZoom = !0),
              (this._animateToCenter = e),
              (this._animateToZoom = t),
              F(this._mapPane, `leaflet-zoom-anim`)),
            this.fire(`zoomanim`, { center: e, zoom: t, noUpdate: r }),
            (this._tempFireZoomEvent ||= this._zoom !== this._animateToZoom),
            this._move(this._animateToCenter, this._animateToZoom, void 0, !0),
            setTimeout(i(this._onZoomTransitionEnd, this), 250));
        },
        _onZoomTransitionEnd: function () {
          this._animatingZoom &&
            (this._mapPane && I(this._mapPane, `leaflet-zoom-anim`),
            (this._animatingZoom = !1),
            this._move(this._animateToCenter, this._animateToZoom, void 0, !0),
            this._tempFireZoomEvent && this.fire(`zoom`),
            delete this._tempFireZoomEvent,
            this.fire(`move`),
            this._moveEnd(!0));
        },
      });
    function pn(e, t) {
      return new W(e, t);
    }
    var G = y.extend({
        options: { position: `topright` },
        initialize: function (e) {
          p(this, e);
        },
        getPosition: function () {
          return this.options.position;
        },
        setPosition: function (e) {
          var t = this._map;
          return (
            t && t.removeControl(this),
            (this.options.position = e),
            t && t.addControl(this),
            this
          );
        },
        getContainer: function () {
          return this._container;
        },
        addTo: function (e) {
          this.remove(), (this._map = e);
          var t = (this._container = this.onAdd(e)),
            n = this.getPosition(),
            r = e._controlCorners[n];
          return (
            F(t, `leaflet-control`),
            n.indexOf(`bottom`) === -1
              ? r.appendChild(t)
              : r.insertBefore(t, r.firstChild),
            this._map.on(`unload`, this.remove, this),
            this
          );
        },
        remove: function () {
          return (
            (this._map &&=
              (P(this._container),
              this.onRemove && this.onRemove(this._map),
              this._map.off(`unload`, this.remove, this),
              null)),
            this
          );
        },
        _refocusOnMap: function (e) {
          this._map &&
            e &&
            e.screenX > 0 &&
            e.screenY > 0 &&
            this._map.getContainer().focus();
        },
      }),
      mn = function (e) {
        return new G(e);
      };
    W.include({
      addControl: function (e) {
        return e.addTo(this), this;
      },
      removeControl: function (e) {
        return e.remove(), this;
      },
      _initControlPos: function () {
        var e = (this._controlCorners = {}),
          t = `leaflet-`,
          n = (this._controlContainer = N(
            `div`,
            t + `control-container`,
            this._container
          ));
        function r(r, i) {
          var a = t + r + ` ` + t + i;
          e[r + i] = N(`div`, a, n);
        }
        r(`top`, `left`),
          r(`top`, `right`),
          r(`bottom`, `left`),
          r(`bottom`, `right`);
      },
      _clearControlPos: function () {
        for (var e in this._controlCorners) P(this._controlCorners[e]);
        P(this._controlContainer),
          delete this._controlCorners,
          delete this._controlContainer;
      },
    });
    var hn = G.extend({
        options: {
          collapsed: !0,
          position: `topright`,
          autoZIndex: !0,
          hideSingleBase: !1,
          sortLayers: !1,
          sortFunction: function (e, t, n, r) {
            return n < r ? -1 : +(r < n);
          },
        },
        initialize: function (e, t, n) {
          for (var r in (p(this, n),
          (this._layerControlInputs = []),
          (this._layers = []),
          (this._lastZIndex = 0),
          (this._handlingClick = !1),
          (this._preventClick = !1),
          e))
            this._addLayer(e[r], r);
          for (r in t) this._addLayer(t[r], r, !0);
        },
        onAdd: function (e) {
          this._initLayout(),
            this._update(),
            (this._map = e),
            e.on(`zoomend`, this._checkDisabledLayers, this);
          for (var t = 0; t < this._layers.length; t++)
            this._layers[t].layer.on(`add remove`, this._onLayerChange, this);
          return this._container;
        },
        addTo: function (e) {
          return G.prototype.addTo.call(this, e), this._expandIfNotCollapsed();
        },
        onRemove: function () {
          this._map.off(`zoomend`, this._checkDisabledLayers, this);
          for (var e = 0; e < this._layers.length; e++)
            this._layers[e].layer.off(`add remove`, this._onLayerChange, this);
        },
        addBaseLayer: function (e, t) {
          return this._addLayer(e, t), this._map ? this._update() : this;
        },
        addOverlay: function (e, t) {
          return this._addLayer(e, t, !0), this._map ? this._update() : this;
        },
        removeLayer: function (e) {
          e.off(`add remove`, this._onLayerChange, this);
          var t = this._getLayer(o(e));
          return (
            t && this._layers.splice(this._layers.indexOf(t), 1),
            this._map ? this._update() : this
          );
        },
        expand: function () {
          F(this._container, `leaflet-control-layers-expanded`),
            (this._section.style.height = null);
          var e = this._map.getSize().y - (this._container.offsetTop + 50);
          return (
            e < this._section.clientHeight
              ? (F(this._section, `leaflet-control-layers-scrollbar`),
                (this._section.style.height = e + `px`))
              : I(this._section, `leaflet-control-layers-scrollbar`),
            this._checkDisabledLayers(),
            this
          );
        },
        collapse: function () {
          return I(this._container, `leaflet-control-layers-expanded`), this;
        },
        _initLayout: function () {
          var e = `leaflet-control-layers`,
            t = (this._container = N(`div`, e)),
            n = this.options.collapsed;
          t.setAttribute(`aria-haspopup`, !0), rn(t), nn(t);
          var r = (this._section = N(`section`, e + `-list`));
          n &&
            (this._map.on(`click`, this.collapse, this),
            B(
              t,
              { mouseenter: this._expandSafely, mouseleave: this.collapse },
              this
            ));
          var i = (this._layersLink = N(`a`, e + `-toggle`, t));
          (i.href = `#`),
            (i.title = `Layers`),
            i.setAttribute(`role`, `button`),
            B(
              i,
              {
                keydown: function (e) {
                  e.keyCode === 13 && this._expandSafely();
                },
                click: function (e) {
                  U(e), this._expandSafely();
                },
              },
              this
            ),
            n || this.expand(),
            (this._baseLayersList = N(`div`, e + `-base`, r)),
            (this._separator = N(`div`, e + `-separator`, r)),
            (this._overlaysList = N(`div`, e + `-overlays`, r)),
            t.appendChild(r);
        },
        _getLayer: function (e) {
          for (var t = 0; t < this._layers.length; t++)
            if (this._layers[t] && o(this._layers[t].layer) === e)
              return this._layers[t];
        },
        _addLayer: function (e, t, n) {
          this._map && e.on(`add remove`, this._onLayerChange, this),
            this._layers.push({ layer: e, name: t, overlay: n }),
            this.options.sortLayers &&
              this._layers.sort(
                i(function (e, t) {
                  return this.options.sortFunction(
                    e.layer,
                    t.layer,
                    e.name,
                    t.name
                  );
                }, this)
              ),
            this.options.autoZIndex &&
              e.setZIndex &&
              (this._lastZIndex++, e.setZIndex(this._lastZIndex)),
            this._expandIfNotCollapsed();
        },
        _update: function () {
          if (!this._container) return this;
          Ot(this._baseLayersList),
            Ot(this._overlaysList),
            (this._layerControlInputs = []);
          var e,
            t,
            n,
            r,
            i = 0;
          for (n = 0; n < this._layers.length; n++)
            (r = this._layers[n]),
              this._addItem(r),
              (t ||= r.overlay),
              (e ||= !r.overlay),
              (i += +!r.overlay);
          return (
            this.options.hideSingleBase &&
              ((e &&= i > 1),
              (this._baseLayersList.style.display = e ? `` : `none`)),
            (this._separator.style.display = t && e ? `` : `none`),
            this
          );
        },
        _onLayerChange: function (e) {
          this._handlingClick || this._update();
          var t = this._getLayer(o(e.target)),
            n = t.overlay
              ? e.type === `add`
                ? `overlayadd`
                : `overlayremove`
              : e.type === `add`
              ? `baselayerchange`
              : null;
          n && this._map.fire(n, t);
        },
        _createRadioElement: function (e, t) {
          var n =
              `<input type="radio" class="leaflet-control-layers-selector" name="` +
              e +
              `"` +
              (t ? ` checked="checked"` : ``) +
              `/>`,
            r = document.createElement(`div`);
          return (r.innerHTML = n), r.firstChild;
        },
        _addItem: function (e) {
          var t = document.createElement(`label`),
            n = this._map.hasLayer(e.layer),
            r;
          e.overlay
            ? ((r = document.createElement(`input`)),
              (r.type = `checkbox`),
              (r.className = `leaflet-control-layers-selector`),
              (r.defaultChecked = n))
            : (r = this._createRadioElement(
                `leaflet-base-layers_` + o(this),
                n
              )),
            this._layerControlInputs.push(r),
            (r.layerId = o(e.layer)),
            B(r, `click`, this._onInputClick, this);
          var i = document.createElement(`span`);
          i.innerHTML = ` ` + e.name;
          var a = document.createElement(`span`);
          return (
            t.appendChild(a),
            a.appendChild(r),
            a.appendChild(i),
            (e.overlay ? this._overlaysList : this._baseLayersList).appendChild(
              t
            ),
            this._checkDisabledLayers(),
            t
          );
        },
        _onInputClick: function () {
          if (!this._preventClick) {
            var e = this._layerControlInputs,
              t,
              n,
              r = [],
              i = [];
            this._handlingClick = !0;
            for (var a = e.length - 1; a >= 0; a--)
              (t = e[a]),
                (n = this._getLayer(t.layerId).layer),
                t.checked ? r.push(n) : t.checked || i.push(n);
            for (a = 0; a < i.length; a++)
              this._map.hasLayer(i[a]) && this._map.removeLayer(i[a]);
            for (a = 0; a < r.length; a++)
              this._map.hasLayer(r[a]) || this._map.addLayer(r[a]);
            (this._handlingClick = !1), this._refocusOnMap();
          }
        },
        _checkDisabledLayers: function () {
          for (
            var e = this._layerControlInputs,
              t,
              n,
              r = this._map.getZoom(),
              i = e.length - 1;
            i >= 0;
            i--
          )
            (t = e[i]),
              (n = this._getLayer(t.layerId).layer),
              (t.disabled =
                (n.options.minZoom !== void 0 && r < n.options.minZoom) ||
                (n.options.maxZoom !== void 0 && r > n.options.maxZoom));
        },
        _expandIfNotCollapsed: function () {
          return this._map && !this.options.collapsed && this.expand(), this;
        },
        _expandSafely: function () {
          var e = this._section;
          (this._preventClick = !0), B(e, `click`, U), this.expand();
          var t = this;
          setTimeout(function () {
            H(e, `click`, U), (t._preventClick = !1);
          });
        },
      }),
      gn = function (e, t, n) {
        return new hn(e, t, n);
      },
      _n = G.extend({
        options: {
          position: `topleft`,
          zoomInText: `<span aria-hidden="true">+</span>`,
          zoomInTitle: `Zoom in`,
          zoomOutText: `<span aria-hidden="true">&#x2212;</span>`,
          zoomOutTitle: `Zoom out`,
        },
        onAdd: function (e) {
          var t = `leaflet-control-zoom`,
            n = N(`div`, t + ` leaflet-bar`),
            r = this.options;
          return (
            (this._zoomInButton = this._createButton(
              r.zoomInText,
              r.zoomInTitle,
              t + `-in`,
              n,
              this._zoomIn
            )),
            (this._zoomOutButton = this._createButton(
              r.zoomOutText,
              r.zoomOutTitle,
              t + `-out`,
              n,
              this._zoomOut
            )),
            this._updateDisabled(),
            e.on(`zoomend zoomlevelschange`, this._updateDisabled, this),
            n
          );
        },
        onRemove: function (e) {
          e.off(`zoomend zoomlevelschange`, this._updateDisabled, this);
        },
        disable: function () {
          return (this._disabled = !0), this._updateDisabled(), this;
        },
        enable: function () {
          return (this._disabled = !1), this._updateDisabled(), this;
        },
        _zoomIn: function (e) {
          !this._disabled &&
            this._map._zoom < this._map.getMaxZoom() &&
            this._map.zoomIn(
              this._map.options.zoomDelta * (e.shiftKey ? 3 : 1)
            );
        },
        _zoomOut: function (e) {
          !this._disabled &&
            this._map._zoom > this._map.getMinZoom() &&
            this._map.zoomOut(
              this._map.options.zoomDelta * (e.shiftKey ? 3 : 1)
            );
        },
        _createButton: function (e, t, n, r, i) {
          var a = N(`a`, n, r);
          return (
            (a.innerHTML = e),
            (a.href = `#`),
            (a.title = t),
            a.setAttribute(`role`, `button`),
            a.setAttribute(`aria-label`, t),
            rn(a),
            B(a, `click`, an),
            B(a, `click`, i, this),
            B(a, `click`, this._refocusOnMap, this),
            a
          );
        },
        _updateDisabled: function () {
          var e = this._map,
            t = `leaflet-disabled`;
          I(this._zoomInButton, t),
            I(this._zoomOutButton, t),
            this._zoomInButton.setAttribute(`aria-disabled`, `false`),
            this._zoomOutButton.setAttribute(`aria-disabled`, `false`),
            (this._disabled || e._zoom === e.getMinZoom()) &&
              (F(this._zoomOutButton, t),
              this._zoomOutButton.setAttribute(`aria-disabled`, `true`)),
            (this._disabled || e._zoom === e.getMaxZoom()) &&
              (F(this._zoomInButton, t),
              this._zoomInButton.setAttribute(`aria-disabled`, `true`));
        },
      });
    W.mergeOptions({ zoomControl: !0 }),
      W.addInitHook(function () {
        this.options.zoomControl &&
          ((this.zoomControl = new _n()), this.addControl(this.zoomControl));
      });
    var vn = function (e) {
        return new _n(e);
      },
      yn = G.extend({
        options: {
          position: `bottomleft`,
          maxWidth: 100,
          metric: !0,
          imperial: !0,
        },
        onAdd: function (e) {
          var t = `leaflet-control-scale`,
            n = N(`div`, t),
            r = this.options;
          return (
            this._addScales(r, t + `-line`, n),
            e.on(r.updateWhenIdle ? `moveend` : `move`, this._update, this),
            e.whenReady(this._update, this),
            n
          );
        },
        onRemove: function (e) {
          e.off(
            this.options.updateWhenIdle ? `moveend` : `move`,
            this._update,
            this
          );
        },
        _addScales: function (e, t, n) {
          e.metric && (this._mScale = N(`div`, t, n)),
            e.imperial && (this._iScale = N(`div`, t, n));
        },
        _update: function () {
          var e = this._map,
            t = e.getSize().y / 2,
            n = e.distance(
              e.containerPointToLatLng([0, t]),
              e.containerPointToLatLng([this.options.maxWidth, t])
            );
          this._updateScales(n);
        },
        _updateScales: function (e) {
          this.options.metric && e && this._updateMetric(e),
            this.options.imperial && e && this._updateImperial(e);
        },
        _updateMetric: function (e) {
          var t = this._getRoundNum(e),
            n = t < 1e3 ? t + ` m` : t / 1e3 + ` km`;
          this._updateScale(this._mScale, n, t / e);
        },
        _updateImperial: function (e) {
          var t = e * 3.2808399,
            n,
            r,
            i;
          t > 5280
            ? ((n = t / 5280),
              (r = this._getRoundNum(n)),
              this._updateScale(this._iScale, r + ` mi`, r / n))
            : ((i = this._getRoundNum(t)),
              this._updateScale(this._iScale, i + ` ft`, i / t));
        },
        _updateScale: function (e, t, n) {
          (e.style.width = Math.round(this.options.maxWidth * n) + `px`),
            (e.innerHTML = t);
        },
        _getRoundNum: function (e) {
          var t = 10 ** ((Math.floor(e) + ``).length - 1),
            n = e / t;
          return (
            (n = n >= 10 ? 10 : n >= 5 ? 5 : n >= 3 ? 3 : n >= 2 ? 2 : 1), t * n
          );
        },
      }),
      bn = function (e) {
        return new yn(e);
      },
      xn = G.extend({
        options: {
          position: `bottomright`,
          prefix:
            `<a href="https://leafletjs.com" title="A JavaScript library for interactive maps">` +
            (M.inlineSvg
              ? `<svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="12" height="8" viewBox="0 0 12 8" class="leaflet-attribution-flag"><path fill="#4C7BE1" d="M0 0h12v4H0z"/><path fill="#FFD500" d="M0 4h12v3H0z"/><path fill="#E0BC00" d="M0 7h12v1H0z"/></svg> `
              : ``) +
            `Leaflet</a>`,
        },
        initialize: function (e) {
          p(this, e), (this._attributions = {});
        },
        onAdd: function (e) {
          for (var t in ((e.attributionControl = this),
          (this._container = N(`div`, `leaflet-control-attribution`)),
          rn(this._container),
          e._layers))
            e._layers[t].getAttribution &&
              this.addAttribution(e._layers[t].getAttribution());
          return (
            this._update(),
            e.on(`layeradd`, this._addAttribution, this),
            this._container
          );
        },
        onRemove: function (e) {
          e.off(`layeradd`, this._addAttribution, this);
        },
        _addAttribution: function (e) {
          e.layer.getAttribution &&
            (this.addAttribution(e.layer.getAttribution()),
            e.layer.once(
              `remove`,
              function () {
                this.removeAttribution(e.layer.getAttribution());
              },
              this
            ));
        },
        setPrefix: function (e) {
          return (this.options.prefix = e), this._update(), this;
        },
        addAttribution: function (e) {
          return (
            e &&
              (this._attributions[e] || (this._attributions[e] = 0),
              this._attributions[e]++,
              this._update()),
            this
          );
        },
        removeAttribution: function (e) {
          return (
            e &&
              this._attributions[e] &&
              (this._attributions[e]--, this._update()),
            this
          );
        },
        _update: function () {
          if (this._map) {
            var e = [];
            for (var t in this._attributions)
              this._attributions[t] && e.push(t);
            var n = [];
            this.options.prefix && n.push(this.options.prefix),
              e.length && n.push(e.join(`, `)),
              (this._container.innerHTML = n.join(
                ` <span aria-hidden="true">|</span> `
              ));
          }
        },
      });
    W.mergeOptions({ attributionControl: !0 }),
      W.addInitHook(function () {
        this.options.attributionControl && new xn().addTo(this);
      }),
      (G.Layers = hn),
      (G.Zoom = _n),
      (G.Scale = yn),
      (G.Attribution = xn),
      (mn.layers = gn),
      (mn.zoom = vn),
      (mn.scale = bn),
      (mn.attribution = function (e) {
        return new xn(e);
      });
    var K = y.extend({
      initialize: function (e) {
        this._map = e;
      },
      enable: function () {
        return this._enabled || ((this._enabled = !0), this.addHooks()), this;
      },
      disable: function () {
        return (
          this._enabled && ((this._enabled = !1), this.removeHooks()), this
        );
      },
      enabled: function () {
        return !!this._enabled;
      },
    });
    K.addTo = function (e, t) {
      return e.addHandler(t, this), this;
    };
    var Sn = { Events: b },
      Cn = M.touch ? `touchstart mousedown` : `mousedown`,
      wn = ue.extend({
        options: { clickTolerance: 3 },
        initialize: function (e, t, n, r) {
          p(this, r),
            (this._element = e),
            (this._dragStartTarget = t || e),
            (this._preventOutline = n);
        },
        enable: function () {
          this._enabled ||=
            (B(this._dragStartTarget, Cn, this._onDown, this), !0);
        },
        disable: function () {
          this._enabled &&
            (wn._dragging === this && this.finishDrag(!0),
            H(this._dragStartTarget, Cn, this._onDown, this),
            (this._enabled = !1),
            (this._moved = !1));
        },
        _onDown: function (e) {
          if (
            this._enabled &&
            ((this._moved = !1), !jt(this._element, `leaflet-zoom-anim`))
          ) {
            if (e.touches && e.touches.length !== 1)
              wn._dragging === this && this.finishDrag();
            else if (
              !(
                wn._dragging ||
                e.shiftKey ||
                (e.which !== 1 && e.button !== 1 && !e.touches)
              ) &&
              ((wn._dragging = this),
              this._preventOutline && Kt(this._element),
              Ht(),
              Rt(),
              !this._moving)
            ) {
              this.fire(`down`);
              var t = e.touches ? e.touches[0] : e,
                n = Jt(this._element);
              (this._startPoint = new x(t.clientX, t.clientY)),
                (this._startPos = Lt(this._element)),
                (this._parentScale = Yt(n));
              var r = e.type === `mousedown`;
              B(document, r ? `mousemove` : `touchmove`, this._onMove, this),
                B(
                  document,
                  r ? `mouseup` : `touchend touchcancel`,
                  this._onUp,
                  this
                );
            }
          }
        },
        _onMove: function (e) {
          if (this._enabled) {
            if (e.touches && e.touches.length > 1) this._moved = !0;
            else {
              var t = e.touches && e.touches.length === 1 ? e.touches[0] : e,
                n = new x(t.clientX, t.clientY)._subtract(this._startPoint);
              (n.x || n.y) &&
                (Math.abs(n.x) + Math.abs(n.y) < this.options.clickTolerance ||
                  ((n.x /= this._parentScale.x),
                  (n.y /= this._parentScale.y),
                  U(e),
                  this._moved ||
                    (this.fire(`dragstart`),
                    (this._moved = !0),
                    F(document.body, `leaflet-dragging`),
                    (this._lastTarget = e.target || e.srcElement),
                    window.SVGElementInstance &&
                      this._lastTarget instanceof window.SVGElementInstance &&
                      (this._lastTarget =
                        this._lastTarget.correspondingUseElement),
                    F(this._lastTarget, `leaflet-drag-target`)),
                  (this._newPos = this._startPos.add(n)),
                  (this._moving = !0),
                  (this._lastEvent = e),
                  this._updatePosition()));
            }
          }
        },
        _updatePosition: function () {
          var e = { originalEvent: this._lastEvent };
          this.fire(`predrag`, e),
            z(this._element, this._newPos),
            this.fire(`drag`, e);
        },
        _onUp: function () {
          this._enabled && this.finishDrag();
        },
        finishDrag: function (e) {
          I(document.body, `leaflet-dragging`),
            (this._lastTarget &&=
              (I(this._lastTarget, `leaflet-drag-target`), null)),
            H(document, `mousemove touchmove`, this._onMove, this),
            H(document, `mouseup touchend touchcancel`, this._onUp, this),
            Ut(),
            zt();
          var t = this._moved && this._moving;
          (this._moving = !1),
            (wn._dragging = !1),
            t &&
              this.fire(`dragend`, {
                noInertia: e,
                distance: this._newPos.distanceTo(this._startPos),
              });
        },
      });
    function Tn(e, t, n) {
      for (
        var r, i = [1, 4, 2, 8], a = 0, o, s, c, l, u = e.length, d, f;
        a < u;
        a++
      )
        e[a]._code = Rn(e[a], t);
      for (s = 0; s < 4; s++) {
        for (d = i[s], r = [], a = 0, u = e.length, o = u - 1; a < u; o = a++)
          (c = e[a]),
            (l = e[o]),
            c._code & d
              ? l._code & d ||
                ((f = Ln(l, c, d, t, n)), (f._code = Rn(f, t)), r.push(f))
              : (l._code & d &&
                  ((f = Ln(l, c, d, t, n)), (f._code = Rn(f, t)), r.push(f)),
                r.push(c));
        e = r;
      }
      return e;
    }
    function En(e, t) {
      var n, r, i, a, o, s, c, l, u;
      if (!e || e.length === 0) throw Error(`latlngs not passed`);
      q(e) ||
        (console.warn(`latlngs are not flat! Only the first ring will be used`),
        (e = e[0]));
      var d = O([0, 0]),
        f = E(e);
      f.getNorthWest().distanceTo(f.getSouthWest()) *
        f.getNorthEast().distanceTo(f.getNorthWest()) <
        1700 && (d = Dn(e));
      var p = e.length,
        m = [];
      for (n = 0; n < p; n++) {
        var ee = O(e[n]);
        m.push(t.project(O([ee.lat - d.lat, ee.lng - d.lng])));
      }
      for (s = c = l = 0, n = 0, r = p - 1; n < p; r = n++)
        (i = m[n]),
          (a = m[r]),
          (o = i.y * a.x - a.y * i.x),
          (c += (i.x + a.x) * o),
          (l += (i.y + a.y) * o),
          (s += o * 3);
      u = s === 0 ? m[0] : [c / s, l / s];
      var h = t.unproject(S(u));
      return O([h.lat + d.lat, h.lng + d.lng]);
    }
    function Dn(e) {
      for (var t = 0, n = 0, r = 0, i = 0; i < e.length; i++) {
        var a = O(e[i]);
        (t += a.lat), (n += a.lng), r++;
      }
      return O([t / r, n / r]);
    }
    var On = {
      __proto__: null,
      clipPolygon: Tn,
      polygonCenter: En,
      centroid: Dn,
    };
    function kn(e, t) {
      if (!t || !e.length) return e.slice();
      var n = t * t;
      return (e = Pn(e, n)), (e = Mn(e, n)), e;
    }
    function An(e, t, n) {
      return Math.sqrt(Bn(e, t, n, !0));
    }
    function jn(e, t, n) {
      return Bn(e, t, n);
    }
    function Mn(e, t) {
      var n = e.length,
        r = new (typeof Uint8Array < `u` ? Uint8Array : Array)(n);
      (r[0] = r[n - 1] = 1), Nn(e, r, t, 0, n - 1);
      var i,
        a = [];
      for (i = 0; i < n; i++) r[i] && a.push(e[i]);
      return a;
    }
    function Nn(e, t, n, r, i) {
      for (var a = 0, o, s = r + 1, c; s <= i - 1; s++)
        (c = Bn(e[s], e[r], e[i], !0)), c > a && ((o = s), (a = c));
      a > n && ((t[o] = 1), Nn(e, t, n, r, o), Nn(e, t, n, o, i));
    }
    function Pn(e, t) {
      for (var n = [e[0]], r = 1, i = 0, a = e.length; r < a; r++)
        zn(e[r], e[i]) > t && (n.push(e[r]), (i = r));
      return i < a - 1 && n.push(e[a - 1]), n;
    }
    var Fn;
    function In(e, t, n, r, i) {
      var a = r ? Fn : Rn(e, n),
        o = Rn(t, n),
        s,
        c,
        l;
      for (Fn = o; ; ) {
        if (!(a | o)) return [e, t];
        if (a & o) return !1;
        (s = a || o),
          (c = Ln(e, t, s, n, i)),
          (l = Rn(c, n)),
          s === a ? ((e = c), (a = l)) : ((t = c), (o = l));
      }
    }
    function Ln(e, t, n, r, i) {
      var a = t.x - e.x,
        o = t.y - e.y,
        s = r.min,
        c = r.max,
        l,
        u;
      return (
        n & 8
          ? ((l = e.x + (a * (c.y - e.y)) / o), (u = c.y))
          : n & 4
          ? ((l = e.x + (a * (s.y - e.y)) / o), (u = s.y))
          : n & 2
          ? ((l = c.x), (u = e.y + (o * (c.x - e.x)) / a))
          : n & 1 && ((l = s.x), (u = e.y + (o * (s.x - e.x)) / a)),
        new x(l, u, i)
      );
    }
    function Rn(e, t) {
      var n = 0;
      return (
        e.x < t.min.x ? (n |= 1) : e.x > t.max.x && (n |= 2),
        e.y < t.min.y ? (n |= 4) : e.y > t.max.y && (n |= 8),
        n
      );
    }
    function zn(e, t) {
      var n = t.x - e.x,
        r = t.y - e.y;
      return n * n + r * r;
    }
    function Bn(e, t, n, r) {
      var i = t.x,
        a = t.y,
        o = n.x - i,
        s = n.y - a,
        c = o * o + s * s,
        l;
      return (
        c > 0 &&
          ((l = ((e.x - i) * o + (e.y - a) * s) / c),
          l > 1
            ? ((i = n.x), (a = n.y))
            : l > 0 && ((i += o * l), (a += s * l))),
        (o = e.x - i),
        (s = e.y - a),
        r ? o * o + s * s : new x(i, a)
      );
    }
    function q(e) {
      return !g(e[0]) || (typeof e[0][0] != `object` && e[0][0] !== void 0);
    }
    function Vn(e) {
      return (
        console.warn(
          `Deprecated use of _flat, please use L.LineUtil.isFlat instead.`
        ),
        q(e)
      );
    }
    function Hn(e, t) {
      var n, r, i, a, o, s, c, l;
      if (!e || e.length === 0) throw Error(`latlngs not passed`);
      q(e) ||
        (console.warn(`latlngs are not flat! Only the first ring will be used`),
        (e = e[0]));
      var u = O([0, 0]),
        d = E(e);
      d.getNorthWest().distanceTo(d.getSouthWest()) *
        d.getNorthEast().distanceTo(d.getNorthWest()) <
        1700 && (u = Dn(e));
      var f = e.length,
        p = [];
      for (n = 0; n < f; n++) {
        var m = O(e[n]);
        p.push(t.project(O([m.lat - u.lat, m.lng - u.lng])));
      }
      for (n = 0, r = 0; n < f - 1; n++) r += p[n].distanceTo(p[n + 1]) / 2;
      if (r === 0) l = p[0];
      else
        for (n = 0, a = 0; n < f - 1; n++)
          if (
            ((o = p[n]), (s = p[n + 1]), (i = o.distanceTo(s)), (a += i), a > r)
          ) {
            (c = (a - r) / i),
              (l = [s.x - c * (s.x - o.x), s.y - c * (s.y - o.y)]);
            break;
          }
      var ee = t.unproject(S(l));
      return O([ee.lat + u.lat, ee.lng + u.lng]);
    }
    var Un = {
        __proto__: null,
        simplify: kn,
        pointToSegmentDistance: An,
        closestPointOnSegment: jn,
        clipSegment: In,
        _getEdgeIntersection: Ln,
        _getBitCode: Rn,
        _sqClosestPointOnSegment: Bn,
        isFlat: q,
        _flat: Vn,
        polylineCenter: Hn,
      },
      Wn = {
        project: function (e) {
          return new x(e.lng, e.lat);
        },
        unproject: function (e) {
          return new D(e.y, e.x);
        },
        bounds: new C([-180, -90], [180, 90]),
      },
      Gn = {
        R: 6378137,
        R_MINOR: 6356752.314245179,
        bounds: new C(
          [-20037508.34279, -15496570.73972],
          [20037508.34279, 18764656.23138]
        ),
        project: function (e) {
          var t = Math.PI / 180,
            n = this.R,
            r = e.lat * t,
            i = this.R_MINOR / n,
            a = Math.sqrt(1 - i * i),
            o = a * Math.sin(r),
            s = Math.tan(Math.PI / 4 - r / 2) / ((1 - o) / (1 + o)) ** (a / 2);
          return (
            (r = -n * Math.log(Math.max(s, 1e-10))), new x(e.lng * t * n, r)
          );
        },
        unproject: function (e) {
          for (
            var t = 180 / Math.PI,
              n = this.R,
              r = this.R_MINOR / n,
              i = Math.sqrt(1 - r * r),
              a = Math.exp(-e.y / n),
              o = Math.PI / 2 - 2 * Math.atan(a),
              s = 0,
              c = 0.1,
              l;
            s < 15 && Math.abs(c) > 1e-7;
            s++
          )
            (l = i * Math.sin(o)),
              (l = ((1 - l) / (1 + l)) ** (i / 2)),
              (c = Math.PI / 2 - 2 * Math.atan(a * l) - o),
              (o += c);
          return new D(o * t, (e.x * t) / n);
        },
      },
      Kn = { __proto__: null, LonLat: Wn, Mercator: Gn, SphericalMercator: pe },
      qn = n({}, A, {
        code: `EPSG:3395`,
        projection: Gn,
        transformation: (function () {
          var e = 0.5 / (Math.PI * Gn.R);
          return he(e, 0.5, -e, 0.5);
        })(),
      }),
      Jn = n({}, A, {
        code: `EPSG:4326`,
        projection: Wn,
        transformation: he(1 / 180, 1, -1 / 180, 0.5),
      }),
      Yn = n({}, k, {
        projection: Wn,
        transformation: he(1, 0, -1, 0),
        scale: function (e) {
          return 2 ** e;
        },
        zoom: function (e) {
          return Math.log(e) / Math.LN2;
        },
        distance: function (e, t) {
          var n = t.lng - e.lng,
            r = t.lat - e.lat;
          return Math.sqrt(n * n + r * r);
        },
        infinite: !0,
      });
    (k.Earth = A),
      (k.EPSG3395 = qn),
      (k.EPSG3857 = ge),
      (k.EPSG900913 = _e),
      (k.EPSG4326 = Jn),
      (k.Simple = Yn);
    var J = ue.extend({
      options: {
        pane: `overlayPane`,
        attribution: null,
        bubblingMouseEvents: !0,
      },
      addTo: function (e) {
        return e.addLayer(this), this;
      },
      remove: function () {
        return this.removeFrom(this._map || this._mapToAdd);
      },
      removeFrom: function (e) {
        return e && e.removeLayer(this), this;
      },
      getPane: function (e) {
        return this._map.getPane(e ? this.options[e] || e : this.options.pane);
      },
      addInteractiveTarget: function (e) {
        return (this._map._targets[o(e)] = this), this;
      },
      removeInteractiveTarget: function (e) {
        return delete this._map._targets[o(e)], this;
      },
      getAttribution: function () {
        return this.options.attribution;
      },
      _layerAdd: function (e) {
        var t = e.target;
        if (t.hasLayer(this)) {
          if (
            ((this._map = t),
            (this._zoomAnimated = t._zoomAnimated),
            this.getEvents)
          ) {
            var n = this.getEvents();
            t.on(n, this),
              this.once(
                `remove`,
                function () {
                  t.off(n, this);
                },
                this
              );
          }
          this.onAdd(t), this.fire(`add`), t.fire(`layeradd`, { layer: this });
        }
      },
    });
    W.include({
      addLayer: function (e) {
        if (!e._layerAdd) throw Error(`The provided object is not a Layer.`);
        var t = o(e);
        return (
          this._layers[t] ||
            ((this._layers[t] = e),
            (e._mapToAdd = this),
            e.beforeAdd && e.beforeAdd(this),
            this.whenReady(e._layerAdd, e)),
          this
        );
      },
      removeLayer: function (e) {
        var t = o(e);
        return (
          this._layers[t] &&
            (this._loaded && e.onRemove(this),
            delete this._layers[t],
            this._loaded &&
              (this.fire(`layerremove`, { layer: e }), e.fire(`remove`)),
            (e._map = e._mapToAdd = null)),
          this
        );
      },
      hasLayer: function (e) {
        return o(e) in this._layers;
      },
      eachLayer: function (e, t) {
        for (var n in this._layers) e.call(t, this._layers[n]);
        return this;
      },
      _addLayers: function (e) {
        e = e ? (g(e) ? e : [e]) : [];
        for (var t = 0, n = e.length; t < n; t++) this.addLayer(e[t]);
      },
      _addZoomLimit: function (e) {
        (isNaN(e.options.maxZoom) && isNaN(e.options.minZoom)) ||
          ((this._zoomBoundLayers[o(e)] = e), this._updateZoomLevels());
      },
      _removeZoomLimit: function (e) {
        var t = o(e);
        this._zoomBoundLayers[t] &&
          (delete this._zoomBoundLayers[t], this._updateZoomLevels());
      },
      _updateZoomLevels: function () {
        var e = 1 / 0,
          t = -1 / 0,
          n = this._getZoomSpan();
        for (var r in this._zoomBoundLayers) {
          var i = this._zoomBoundLayers[r].options;
          (e = i.minZoom === void 0 ? e : Math.min(e, i.minZoom)),
            (t = i.maxZoom === void 0 ? t : Math.max(t, i.maxZoom));
        }
        (this._layersMaxZoom = t === -1 / 0 ? void 0 : t),
          (this._layersMinZoom = e === 1 / 0 ? void 0 : e),
          n !== this._getZoomSpan() && this.fire(`zoomlevelschange`),
          this.options.maxZoom === void 0 &&
            this._layersMaxZoom &&
            this.getZoom() > this._layersMaxZoom &&
            this.setZoom(this._layersMaxZoom),
          this.options.minZoom === void 0 &&
            this._layersMinZoom &&
            this.getZoom() < this._layersMinZoom &&
            this.setZoom(this._layersMinZoom);
      },
    });
    var Xn = J.extend({
        initialize: function (e, t) {
          p(this, t), (this._layers = {});
          var n, r;
          if (e) for (n = 0, r = e.length; n < r; n++) this.addLayer(e[n]);
        },
        addLayer: function (e) {
          var t = this.getLayerId(e);
          return (
            (this._layers[t] = e), this._map && this._map.addLayer(e), this
          );
        },
        removeLayer: function (e) {
          var t = e in this._layers ? e : this.getLayerId(e);
          return (
            this._map &&
              this._layers[t] &&
              this._map.removeLayer(this._layers[t]),
            delete this._layers[t],
            this
          );
        },
        hasLayer: function (e) {
          return (
            (typeof e == `number` ? e : this.getLayerId(e)) in this._layers
          );
        },
        clearLayers: function () {
          return this.eachLayer(this.removeLayer, this);
        },
        invoke: function (e) {
          var t = Array.prototype.slice.call(arguments, 1),
            n,
            r;
          for (n in this._layers)
            (r = this._layers[n]), r[e] && r[e].apply(r, t);
          return this;
        },
        onAdd: function (e) {
          this.eachLayer(e.addLayer, e);
        },
        onRemove: function (e) {
          this.eachLayer(e.removeLayer, e);
        },
        eachLayer: function (e, t) {
          for (var n in this._layers) e.call(t, this._layers[n]);
          return this;
        },
        getLayer: function (e) {
          return this._layers[e];
        },
        getLayers: function () {
          var e = [];
          return this.eachLayer(e.push, e), e;
        },
        setZIndex: function (e) {
          return this.invoke(`setZIndex`, e);
        },
        getLayerId: function (e) {
          return o(e);
        },
      }),
      Zn = function (e, t) {
        return new Xn(e, t);
      },
      Y = Xn.extend({
        addLayer: function (e) {
          return this.hasLayer(e)
            ? this
            : (e.addEventParent(this),
              Xn.prototype.addLayer.call(this, e),
              this.fire(`layeradd`, { layer: e }));
        },
        removeLayer: function (e) {
          return this.hasLayer(e)
            ? (e in this._layers && (e = this._layers[e]),
              e.removeEventParent(this),
              Xn.prototype.removeLayer.call(this, e),
              this.fire(`layerremove`, { layer: e }))
            : this;
        },
        setStyle: function (e) {
          return this.invoke(`setStyle`, e);
        },
        bringToFront: function () {
          return this.invoke(`bringToFront`);
        },
        bringToBack: function () {
          return this.invoke(`bringToBack`);
        },
        getBounds: function () {
          var e = new T();
          for (var t in this._layers) {
            var n = this._layers[t];
            e.extend(n.getBounds ? n.getBounds() : n.getLatLng());
          }
          return e;
        },
      }),
      Qn = function (e, t) {
        return new Y(e, t);
      },
      $n = y.extend({
        options: {
          popupAnchor: [0, 0],
          tooltipAnchor: [0, 0],
          crossOrigin: !1,
        },
        initialize: function (e) {
          p(this, e);
        },
        createIcon: function (e) {
          return this._createIcon(`icon`, e);
        },
        createShadow: function (e) {
          return this._createIcon(`shadow`, e);
        },
        _createIcon: function (e, t) {
          var n = this._getIconUrl(e);
          if (!n) {
            if (e === `icon`)
              throw Error(`iconUrl not set in Icon options (see the docs).`);
            return null;
          }
          var r = this._createImg(n, t && t.tagName === `IMG` ? t : null);
          return (
            this._setIconStyles(r, e),
            (this.options.crossOrigin || this.options.crossOrigin === ``) &&
              (r.crossOrigin =
                this.options.crossOrigin === !0
                  ? ``
                  : this.options.crossOrigin),
            r
          );
        },
        _setIconStyles: function (e, t) {
          var n = this.options,
            r = n[t + `Size`];
          typeof r == `number` && (r = [r, r]);
          var i = S(r),
            a = S(
              (t === `shadow` && n.shadowAnchor) ||
                n.iconAnchor ||
                (i && i.divideBy(2, !0))
            );
          (e.className = `leaflet-marker-` + t + ` ` + (n.className || ``)),
            a &&
              ((e.style.marginLeft = -a.x + `px`),
              (e.style.marginTop = -a.y + `px`)),
            i && ((e.style.width = i.x + `px`), (e.style.height = i.y + `px`));
        },
        _createImg: function (e, t) {
          return (t ||= document.createElement(`img`)), (t.src = e), t;
        },
        _getIconUrl: function (e) {
          return (
            (M.retina && this.options[e + `RetinaUrl`]) ||
            this.options[e + `Url`]
          );
        },
      });
    function er(e) {
      return new $n(e);
    }
    var tr = $n.extend({
        options: {
          iconUrl: `marker-icon.png`,
          iconRetinaUrl: `marker-icon-2x.png`,
          shadowUrl: `marker-shadow.png`,
          iconSize: [25, 41],
          iconAnchor: [12, 41],
          popupAnchor: [1, -34],
          tooltipAnchor: [16, -28],
          shadowSize: [41, 41],
        },
        _getIconUrl: function (e) {
          return (
            typeof tr.imagePath != `string` &&
              (tr.imagePath = this._detectIconPath()),
            (this.options.imagePath || tr.imagePath) +
              $n.prototype._getIconUrl.call(this, e)
          );
        },
        _stripUrl: function (e) {
          var t = function (e, t, n) {
            var r = t.exec(e);
            return r && r[n];
          };
          return (
            (e = t(e, /^url\((['"])?(.+)\1\)$/, 2)),
            e && t(e, /^(.*)marker-icon\.png$/, 1)
          );
        },
        _detectIconPath: function () {
          var e = N(`div`, `leaflet-default-icon-path`, document.body),
            t = Dt(e, `background-image`) || Dt(e, `backgroundImage`);
          if ((document.body.removeChild(e), (t = this._stripUrl(t)), t))
            return t;
          var n = document.querySelector(`link[href$="leaflet.css"]`);
          return n ? n.href.substring(0, n.href.length - 11 - 1) : ``;
        },
      }),
      nr = K.extend({
        initialize: function (e) {
          this._marker = e;
        },
        addHooks: function () {
          var e = this._marker._icon;
          (this._draggable ||= new wn(e, e, !0)),
            this._draggable
              .on(
                {
                  dragstart: this._onDragStart,
                  predrag: this._onPreDrag,
                  drag: this._onDrag,
                  dragend: this._onDragEnd,
                },
                this
              )
              .enable(),
            F(e, `leaflet-marker-draggable`);
        },
        removeHooks: function () {
          this._draggable
            .off(
              {
                dragstart: this._onDragStart,
                predrag: this._onPreDrag,
                drag: this._onDrag,
                dragend: this._onDragEnd,
              },
              this
            )
            .disable(),
            this._marker._icon &&
              I(this._marker._icon, `leaflet-marker-draggable`);
        },
        moved: function () {
          return this._draggable && this._draggable._moved;
        },
        _adjustPan: function (e) {
          var t = this._marker,
            n = t._map,
            r = this._marker.options.autoPanSpeed,
            i = this._marker.options.autoPanPadding,
            a = Lt(t._icon),
            o = n.getPixelBounds(),
            s = n.getPixelOrigin(),
            c = w(o.min._subtract(s).add(i), o.max._subtract(s).subtract(i));
          if (!c.contains(a)) {
            var l = S(
              (Math.max(c.max.x, a.x) - c.max.x) / (o.max.x - c.max.x) -
                (Math.min(c.min.x, a.x) - c.min.x) / (o.min.x - c.min.x),
              (Math.max(c.max.y, a.y) - c.max.y) / (o.max.y - c.max.y) -
                (Math.min(c.min.y, a.y) - c.min.y) / (o.min.y - c.min.y)
            ).multiplyBy(r);
            n.panBy(l, { animate: !1 }),
              this._draggable._newPos._add(l),
              this._draggable._startPos._add(l),
              z(t._icon, this._draggable._newPos),
              this._onDrag(e),
              (this._panRequest = _(this._adjustPan.bind(this, e)));
          }
        },
        _onDragStart: function () {
          (this._oldLatLng = this._marker.getLatLng()),
            this._marker.closePopup && this._marker.closePopup(),
            this._marker.fire(`movestart`).fire(`dragstart`);
        },
        _onPreDrag: function (e) {
          this._marker.options.autoPan &&
            (v(this._panRequest),
            (this._panRequest = _(this._adjustPan.bind(this, e))));
        },
        _onDrag: function (e) {
          var t = this._marker,
            n = t._shadow,
            r = Lt(t._icon),
            i = t._map.layerPointToLatLng(r);
          n && z(n, r),
            (t._latlng = i),
            (e.latlng = i),
            (e.oldLatLng = this._oldLatLng),
            t.fire(`move`, e).fire(`drag`, e);
        },
        _onDragEnd: function (e) {
          v(this._panRequest),
            delete this._oldLatLng,
            this._marker.fire(`moveend`).fire(`dragend`, e);
        },
      }),
      rr = J.extend({
        options: {
          icon: new tr(),
          interactive: !0,
          keyboard: !0,
          title: ``,
          alt: `Marker`,
          zIndexOffset: 0,
          opacity: 1,
          riseOnHover: !1,
          riseOffset: 250,
          pane: `markerPane`,
          shadowPane: `shadowPane`,
          bubblingMouseEvents: !1,
          autoPanOnFocus: !0,
          draggable: !1,
          autoPan: !1,
          autoPanPadding: [50, 50],
          autoPanSpeed: 10,
        },
        initialize: function (e, t) {
          p(this, t), (this._latlng = O(e));
        },
        onAdd: function (e) {
          (this._zoomAnimated =
            this._zoomAnimated && e.options.markerZoomAnimation),
            this._zoomAnimated && e.on(`zoomanim`, this._animateZoom, this),
            this._initIcon(),
            this.update();
        },
        onRemove: function (e) {
          this.dragging &&
            this.dragging.enabled() &&
            ((this.options.draggable = !0), this.dragging.removeHooks()),
            delete this.dragging,
            this._zoomAnimated && e.off(`zoomanim`, this._animateZoom, this),
            this._removeIcon(),
            this._removeShadow();
        },
        getEvents: function () {
          return { zoom: this.update, viewreset: this.update };
        },
        getLatLng: function () {
          return this._latlng;
        },
        setLatLng: function (e) {
          var t = this._latlng;
          return (
            (this._latlng = O(e)),
            this.update(),
            this.fire(`move`, { oldLatLng: t, latlng: this._latlng })
          );
        },
        setZIndexOffset: function (e) {
          return (this.options.zIndexOffset = e), this.update();
        },
        getIcon: function () {
          return this.options.icon;
        },
        setIcon: function (e) {
          return (
            (this.options.icon = e),
            this._map && (this._initIcon(), this.update()),
            this._popup && this.bindPopup(this._popup, this._popup.options),
            this
          );
        },
        getElement: function () {
          return this._icon;
        },
        update: function () {
          if (this._icon && this._map) {
            var e = this._map.latLngToLayerPoint(this._latlng).round();
            this._setPos(e);
          }
          return this;
        },
        _initIcon: function () {
          var e = this.options,
            t = `leaflet-zoom-` + (this._zoomAnimated ? `animated` : `hide`),
            n = e.icon.createIcon(this._icon),
            r = !1;
          n !== this._icon &&
            (this._icon && this._removeIcon(),
            (r = !0),
            e.title && (n.title = e.title),
            n.tagName === `IMG` && (n.alt = e.alt || ``)),
            F(n, t),
            e.keyboard &&
              ((n.tabIndex = `0`), n.setAttribute(`role`, `button`)),
            (this._icon = n),
            e.riseOnHover &&
              this.on({
                mouseover: this._bringToFront,
                mouseout: this._resetZIndex,
              }),
            this.options.autoPanOnFocus &&
              B(n, `focus`, this._panOnFocus, this);
          var i = e.icon.createShadow(this._shadow),
            a = !1;
          i !== this._shadow && (this._removeShadow(), (a = !0)),
            i && (F(i, t), (i.alt = ``)),
            (this._shadow = i),
            e.opacity < 1 && this._updateOpacity(),
            r && this.getPane().appendChild(this._icon),
            this._initInteraction(),
            i && a && this.getPane(e.shadowPane).appendChild(this._shadow);
        },
        _removeIcon: function () {
          this.options.riseOnHover &&
            this.off({
              mouseover: this._bringToFront,
              mouseout: this._resetZIndex,
            }),
            this.options.autoPanOnFocus &&
              H(this._icon, `focus`, this._panOnFocus, this),
            P(this._icon),
            this.removeInteractiveTarget(this._icon),
            (this._icon = null);
        },
        _removeShadow: function () {
          this._shadow && P(this._shadow), (this._shadow = null);
        },
        _setPos: function (e) {
          this._icon && z(this._icon, e),
            this._shadow && z(this._shadow, e),
            (this._zIndex = e.y + this.options.zIndexOffset),
            this._resetZIndex();
        },
        _updateZIndex: function (e) {
          this._icon && (this._icon.style.zIndex = this._zIndex + e);
        },
        _animateZoom: function (e) {
          var t = this._map
            ._latLngToNewLayerPoint(this._latlng, e.zoom, e.center)
            .round();
          this._setPos(t);
        },
        _initInteraction: function () {
          if (
            this.options.interactive &&
            (F(this._icon, `leaflet-interactive`),
            this.addInteractiveTarget(this._icon),
            nr)
          ) {
            var e = this.options.draggable;
            this.dragging &&
              ((e = this.dragging.enabled()), this.dragging.disable()),
              (this.dragging = new nr(this)),
              e && this.dragging.enable();
          }
        },
        setOpacity: function (e) {
          return (
            (this.options.opacity = e), this._map && this._updateOpacity(), this
          );
        },
        _updateOpacity: function () {
          var e = this.options.opacity;
          this._icon && R(this._icon, e), this._shadow && R(this._shadow, e);
        },
        _bringToFront: function () {
          this._updateZIndex(this.options.riseOffset);
        },
        _resetZIndex: function () {
          this._updateZIndex(0);
        },
        _panOnFocus: function () {
          var e = this._map;
          if (e) {
            var t = this.options.icon.options,
              n = t.iconSize ? S(t.iconSize) : S(0, 0),
              r = t.iconAnchor ? S(t.iconAnchor) : S(0, 0);
            e.panInside(this._latlng, {
              paddingTopLeft: r,
              paddingBottomRight: n.subtract(r),
            });
          }
        },
        _getPopupAnchor: function () {
          return this.options.icon.options.popupAnchor;
        },
        _getTooltipAnchor: function () {
          return this.options.icon.options.tooltipAnchor;
        },
      });
    function ir(e, t) {
      return new rr(e, t);
    }
    var ar = J.extend({
        options: {
          stroke: !0,
          color: `#3388ff`,
          weight: 3,
          opacity: 1,
          lineCap: `round`,
          lineJoin: `round`,
          dashArray: null,
          dashOffset: null,
          fill: !1,
          fillColor: null,
          fillOpacity: 0.2,
          fillRule: `evenodd`,
          interactive: !0,
          bubblingMouseEvents: !0,
        },
        beforeAdd: function (e) {
          this._renderer = e.getRenderer(this);
        },
        onAdd: function () {
          this._renderer._initPath(this),
            this._reset(),
            this._renderer._addPath(this);
        },
        onRemove: function () {
          this._renderer._removePath(this);
        },
        redraw: function () {
          return this._map && this._renderer._updatePath(this), this;
        },
        setStyle: function (e) {
          return (
            p(this, e),
            this._renderer &&
              (this._renderer._updateStyle(this),
              this.options.stroke &&
                e &&
                Object.prototype.hasOwnProperty.call(e, `weight`) &&
                this._updateBounds()),
            this
          );
        },
        bringToFront: function () {
          return this._renderer && this._renderer._bringToFront(this), this;
        },
        bringToBack: function () {
          return this._renderer && this._renderer._bringToBack(this), this;
        },
        getElement: function () {
          return this._path;
        },
        _reset: function () {
          this._project(), this._update();
        },
        _clickTolerance: function () {
          return (
            (this.options.stroke ? this.options.weight / 2 : 0) +
            (this._renderer.options.tolerance || 0)
          );
        },
      }),
      or = ar.extend({
        options: { fill: !0, radius: 10 },
        initialize: function (e, t) {
          p(this, t),
            (this._latlng = O(e)),
            (this._radius = this.options.radius);
        },
        setLatLng: function (e) {
          var t = this._latlng;
          return (
            (this._latlng = O(e)),
            this.redraw(),
            this.fire(`move`, { oldLatLng: t, latlng: this._latlng })
          );
        },
        getLatLng: function () {
          return this._latlng;
        },
        setRadius: function (e) {
          return (this.options.radius = this._radius = e), this.redraw();
        },
        getRadius: function () {
          return this._radius;
        },
        setStyle: function (e) {
          var t = (e && e.radius) || this._radius;
          return ar.prototype.setStyle.call(this, e), this.setRadius(t), this;
        },
        _project: function () {
          (this._point = this._map.latLngToLayerPoint(this._latlng)),
            this._updateBounds();
        },
        _updateBounds: function () {
          var e = this._radius,
            t = this._radiusY || e,
            n = this._clickTolerance(),
            r = [e + n, t + n];
          this._pxBounds = new C(this._point.subtract(r), this._point.add(r));
        },
        _update: function () {
          this._map && this._updatePath();
        },
        _updatePath: function () {
          this._renderer._updateCircle(this);
        },
        _empty: function () {
          return (
            this._radius && !this._renderer._bounds.intersects(this._pxBounds)
          );
        },
        _containsPoint: function (e) {
          return (
            e.distanceTo(this._point) <= this._radius + this._clickTolerance()
          );
        },
      });
    function sr(e, t) {
      return new or(e, t);
    }
    var cr = or.extend({
      initialize: function (e, t, r) {
        if (
          (typeof t == `number` && (t = n({}, r, { radius: t })),
          p(this, t),
          (this._latlng = O(e)),
          isNaN(this.options.radius))
        )
          throw Error(`Circle radius cannot be NaN`);
        this._mRadius = this.options.radius;
      },
      setRadius: function (e) {
        return (this._mRadius = e), this.redraw();
      },
      getRadius: function () {
        return this._mRadius;
      },
      getBounds: function () {
        var e = [this._radius, this._radiusY || this._radius];
        return new T(
          this._map.layerPointToLatLng(this._point.subtract(e)),
          this._map.layerPointToLatLng(this._point.add(e))
        );
      },
      setStyle: ar.prototype.setStyle,
      _project: function () {
        var e = this._latlng.lng,
          t = this._latlng.lat,
          n = this._map,
          r = n.options.crs;
        if (r.distance === A.distance) {
          var i = Math.PI / 180,
            a = this._mRadius / A.R / i,
            o = n.project([t + a, e]),
            s = n.project([t - a, e]),
            c = o.add(s).divideBy(2),
            l = n.unproject(c).lat,
            u =
              Math.acos(
                (Math.cos(a * i) - Math.sin(t * i) * Math.sin(l * i)) /
                  (Math.cos(t * i) * Math.cos(l * i))
              ) / i;
          (isNaN(u) || u === 0) && (u = a / Math.cos((Math.PI / 180) * t)),
            (this._point = c.subtract(n.getPixelOrigin())),
            (this._radius = isNaN(u) ? 0 : c.x - n.project([l, e - u]).x),
            (this._radiusY = c.y - o.y);
        } else {
          var d = r.unproject(
            r.project(this._latlng).subtract([this._mRadius, 0])
          );
          (this._point = n.latLngToLayerPoint(this._latlng)),
            (this._radius = this._point.x - n.latLngToLayerPoint(d).x);
        }
        this._updateBounds();
      },
    });
    function lr(e, t, n) {
      return new cr(e, t, n);
    }
    var X = ar.extend({
      options: { smoothFactor: 1, noClip: !1 },
      initialize: function (e, t) {
        p(this, t), this._setLatLngs(e);
      },
      getLatLngs: function () {
        return this._latlngs;
      },
      setLatLngs: function (e) {
        return this._setLatLngs(e), this.redraw();
      },
      isEmpty: function () {
        return !this._latlngs.length;
      },
      closestLayerPoint: function (e) {
        for (
          var t = 1 / 0, n = null, r = Bn, i, a, o = 0, s = this._parts.length;
          o < s;
          o++
        )
          for (var c = this._parts[o], l = 1, u = c.length; l < u; l++) {
            (i = c[l - 1]), (a = c[l]);
            var d = r(e, i, a, !0);
            d < t && ((t = d), (n = r(e, i, a)));
          }
        return n && (n.distance = Math.sqrt(t)), n;
      },
      getCenter: function () {
        if (!this._map)
          throw Error(`Must add layer to map before using getCenter()`);
        return Hn(this._defaultShape(), this._map.options.crs);
      },
      getBounds: function () {
        return this._bounds;
      },
      addLatLng: function (e, t) {
        return (
          (t ||= this._defaultShape()),
          (e = O(e)),
          t.push(e),
          this._bounds.extend(e),
          this.redraw()
        );
      },
      _setLatLngs: function (e) {
        (this._bounds = new T()), (this._latlngs = this._convertLatLngs(e));
      },
      _defaultShape: function () {
        return q(this._latlngs) ? this._latlngs : this._latlngs[0];
      },
      _convertLatLngs: function (e) {
        for (var t = [], n = q(e), r = 0, i = e.length; r < i; r++)
          n
            ? ((t[r] = O(e[r])), this._bounds.extend(t[r]))
            : (t[r] = this._convertLatLngs(e[r]));
        return t;
      },
      _project: function () {
        var e = new C();
        (this._rings = []),
          this._projectLatlngs(this._latlngs, this._rings, e),
          this._bounds.isValid() &&
            e.isValid() &&
            ((this._rawPxBounds = e), this._updateBounds());
      },
      _updateBounds: function () {
        var e = this._clickTolerance(),
          t = new x(e, e);
        this._rawPxBounds &&
          (this._pxBounds = new C([
            this._rawPxBounds.min.subtract(t),
            this._rawPxBounds.max.add(t),
          ]));
      },
      _projectLatlngs: function (e, t, n) {
        var r = e[0] instanceof D,
          i = e.length,
          a,
          o;
        if (r) {
          for (o = [], a = 0; a < i; a++)
            (o[a] = this._map.latLngToLayerPoint(e[a])), n.extend(o[a]);
          t.push(o);
        } else for (a = 0; a < i; a++) this._projectLatlngs(e[a], t, n);
      },
      _clipPoints: function () {
        var e = this._renderer._bounds;
        if (
          ((this._parts = []), this._pxBounds && this._pxBounds.intersects(e))
        ) {
          if (this.options.noClip) this._parts = this._rings;
          else
            for (
              var t = this._parts,
                n = 0,
                r,
                i = 0,
                a = this._rings.length,
                o,
                s,
                c;
              n < a;
              n++
            )
              for (c = this._rings[n], r = 0, o = c.length; r < o - 1; r++)
                (s = In(c[r], c[r + 1], e, r, !0)),
                  s &&
                    ((t[i] = t[i] || []),
                    t[i].push(s[0]),
                    (s[1] !== c[r + 1] || r === o - 2) &&
                      (t[i].push(s[1]), i++));
        }
      },
      _simplifyPoints: function () {
        for (
          var e = this._parts,
            t = this.options.smoothFactor,
            n = 0,
            r = e.length;
          n < r;
          n++
        )
          e[n] = kn(e[n], t);
      },
      _update: function () {
        this._map &&
          (this._clipPoints(), this._simplifyPoints(), this._updatePath());
      },
      _updatePath: function () {
        this._renderer._updatePoly(this);
      },
      _containsPoint: function (e, t) {
        var n,
          r,
          i,
          a,
          o,
          s,
          c = this._clickTolerance();
        if (!this._pxBounds || !this._pxBounds.contains(e)) return !1;
        for (n = 0, a = this._parts.length; n < a; n++)
          for (
            s = this._parts[n], r = 0, o = s.length, i = o - 1;
            r < o;
            i = r++
          )
            if ((t || r !== 0) && An(e, s[i], s[r]) <= c) return !0;
        return !1;
      },
    });
    function ur(e, t) {
      return new X(e, t);
    }
    X._flat = Vn;
    var dr = X.extend({
      options: { fill: !0 },
      isEmpty: function () {
        return !this._latlngs.length || !this._latlngs[0].length;
      },
      getCenter: function () {
        if (!this._map)
          throw Error(`Must add layer to map before using getCenter()`);
        return En(this._defaultShape(), this._map.options.crs);
      },
      _convertLatLngs: function (e) {
        var t = X.prototype._convertLatLngs.call(this, e),
          n = t.length;
        return (
          n >= 2 && t[0] instanceof D && t[0].equals(t[n - 1]) && t.pop(), t
        );
      },
      _setLatLngs: function (e) {
        X.prototype._setLatLngs.call(this, e),
          q(this._latlngs) && (this._latlngs = [this._latlngs]);
      },
      _defaultShape: function () {
        return q(this._latlngs[0]) ? this._latlngs[0] : this._latlngs[0][0];
      },
      _clipPoints: function () {
        var e = this._renderer._bounds,
          t = this.options.weight,
          n = new x(t, t);
        if (
          ((e = new C(e.min.subtract(n), e.max.add(n))),
          (this._parts = []),
          this._pxBounds && this._pxBounds.intersects(e))
        ) {
          if (this.options.noClip) this._parts = this._rings;
          else
            for (var r = 0, i = this._rings.length, a; r < i; r++)
              (a = Tn(this._rings[r], e, !0)), a.length && this._parts.push(a);
        }
      },
      _updatePath: function () {
        this._renderer._updatePoly(this, !0);
      },
      _containsPoint: function (e) {
        var t = !1,
          n,
          r,
          i,
          a,
          o,
          s,
          c,
          l;
        if (!this._pxBounds || !this._pxBounds.contains(e)) return !1;
        for (a = 0, c = this._parts.length; a < c; a++)
          for (
            n = this._parts[a], o = 0, l = n.length, s = l - 1;
            o < l;
            s = o++
          )
            (r = n[o]),
              (i = n[s]),
              r.y > e.y != i.y > e.y &&
                e.x < ((i.x - r.x) * (e.y - r.y)) / (i.y - r.y) + r.x &&
                (t = !t);
        return t || X.prototype._containsPoint.call(this, e, !0);
      },
    });
    function fr(e, t) {
      return new dr(e, t);
    }
    var Z = Y.extend({
      initialize: function (e, t) {
        p(this, t), (this._layers = {}), e && this.addData(e);
      },
      addData: function (e) {
        var t = g(e) ? e : e.features,
          n,
          r,
          i;
        if (t) {
          for (n = 0, r = t.length; n < r; n++)
            (i = t[n]),
              (i.geometries || i.geometry || i.features || i.coordinates) &&
                this.addData(i);
          return this;
        }
        var a = this.options;
        if (a.filter && !a.filter(e)) return this;
        var o = pr(e, a);
        return o
          ? ((o.feature = br(e)),
            (o.defaultOptions = o.options),
            this.resetStyle(o),
            a.onEachFeature && a.onEachFeature(e, o),
            this.addLayer(o))
          : this;
      },
      resetStyle: function (e) {
        return e === void 0
          ? this.eachLayer(this.resetStyle, this)
          : ((e.options = n({}, e.defaultOptions)),
            this._setLayerStyle(e, this.options.style),
            this);
      },
      setStyle: function (e) {
        return this.eachLayer(function (t) {
          this._setLayerStyle(t, e);
        }, this);
      },
      _setLayerStyle: function (e, t) {
        e.setStyle &&
          (typeof t == `function` && (t = t(e.feature)), e.setStyle(t));
      },
    });
    function pr(e, t) {
      var n = e.type === `Feature` ? e.geometry : e,
        r = n ? n.coordinates : null,
        i = [],
        a = t && t.pointToLayer,
        o = (t && t.coordsToLatLng) || hr,
        s,
        c,
        l,
        u;
      if (!r && !n) return null;
      switch (n.type) {
        case `Point`:
          return (s = o(r)), mr(a, e, s, t);
        case `MultiPoint`:
          for (l = 0, u = r.length; l < u; l++)
            (s = o(r[l])), i.push(mr(a, e, s, t));
          return new Y(i);
        case `LineString`:
        case `MultiLineString`:
          return (c = gr(r, n.type === `LineString` ? 0 : 1, o)), new X(c, t);
        case `Polygon`:
        case `MultiPolygon`:
          return (c = gr(r, n.type === `Polygon` ? 1 : 2, o)), new dr(c, t);
        case `GeometryCollection`:
          for (l = 0, u = n.geometries.length; l < u; l++) {
            var d = pr(
              {
                geometry: n.geometries[l],
                type: `Feature`,
                properties: e.properties,
              },
              t
            );
            d && i.push(d);
          }
          return new Y(i);
        case `FeatureCollection`:
          for (l = 0, u = n.features.length; l < u; l++) {
            var f = pr(n.features[l], t);
            f && i.push(f);
          }
          return new Y(i);
        default:
          throw Error(`Invalid GeoJSON object.`);
      }
    }
    function mr(e, t, n, r) {
      return e ? e(t, n) : new rr(n, r && r.markersInheritOptions && r);
    }
    function hr(e) {
      return new D(e[1], e[0], e[2]);
    }
    function gr(e, t, n) {
      for (var r = [], i = 0, a = e.length, o; i < a; i++)
        (o = t ? gr(e[i], t - 1, n) : (n || hr)(e[i])), r.push(o);
      return r;
    }
    function _r(e, t) {
      return (
        (e = O(e)),
        e.alt === void 0
          ? [u(e.lng, t), u(e.lat, t)]
          : [u(e.lng, t), u(e.lat, t), u(e.alt, t)]
      );
    }
    function vr(e, t, n, r) {
      for (var i = [], a = 0, o = e.length; a < o; a++)
        i.push(t ? vr(e[a], q(e[a]) ? 0 : t - 1, n, r) : _r(e[a], r));
      return !t && n && i.length > 0 && i.push(i[0].slice()), i;
    }
    function yr(e, t) {
      return e.feature ? n({}, e.feature, { geometry: t }) : br(t);
    }
    function br(e) {
      return e.type === `Feature` || e.type === `FeatureCollection`
        ? e
        : { type: `Feature`, properties: {}, geometry: e };
    }
    var xr = {
      toGeoJSON: function (e) {
        return yr(this, {
          type: `Point`,
          coordinates: _r(this.getLatLng(), e),
        });
      },
    };
    rr.include(xr),
      cr.include(xr),
      or.include(xr),
      X.include({
        toGeoJSON: function (e) {
          var t = !q(this._latlngs),
            n = vr(this._latlngs, +!!t, !1, e);
          return yr(this, {
            type: (t ? `Multi` : ``) + `LineString`,
            coordinates: n,
          });
        },
      }),
      dr.include({
        toGeoJSON: function (e) {
          var t = !q(this._latlngs),
            n = t && !q(this._latlngs[0]),
            r = vr(this._latlngs, n ? 2 : +!!t, !0, e);
          return (
            t || (r = [r]),
            yr(this, { type: (n ? `Multi` : ``) + `Polygon`, coordinates: r })
          );
        },
      }),
      Xn.include({
        toMultiPoint: function (e) {
          var t = [];
          return (
            this.eachLayer(function (n) {
              t.push(n.toGeoJSON(e).geometry.coordinates);
            }),
            yr(this, { type: `MultiPoint`, coordinates: t })
          );
        },
        toGeoJSON: function (e) {
          var t =
            this.feature && this.feature.geometry && this.feature.geometry.type;
          if (t === `MultiPoint`) return this.toMultiPoint(e);
          var n = t === `GeometryCollection`,
            r = [];
          return (
            this.eachLayer(function (t) {
              if (t.toGeoJSON) {
                var i = t.toGeoJSON(e);
                if (n) r.push(i.geometry);
                else {
                  var a = br(i);
                  a.type === `FeatureCollection`
                    ? r.push.apply(r, a.features)
                    : r.push(a);
                }
              }
            }),
            n
              ? yr(this, { geometries: r, type: `GeometryCollection` })
              : { type: `FeatureCollection`, features: r }
          );
        },
      });
    function Sr(e, t) {
      return new Z(e, t);
    }
    var Cr = Sr,
      wr = J.extend({
        options: {
          opacity: 1,
          alt: ``,
          interactive: !1,
          crossOrigin: !1,
          errorOverlayUrl: ``,
          zIndex: 1,
          className: ``,
        },
        initialize: function (e, t, n) {
          (this._url = e), (this._bounds = E(t)), p(this, n);
        },
        onAdd: function () {
          this._image ||
            (this._initImage(),
            this.options.opacity < 1 && this._updateOpacity()),
            this.options.interactive &&
              (F(this._image, `leaflet-interactive`),
              this.addInteractiveTarget(this._image)),
            this.getPane().appendChild(this._image),
            this._reset();
        },
        onRemove: function () {
          P(this._image),
            this.options.interactive &&
              this.removeInteractiveTarget(this._image);
        },
        setOpacity: function (e) {
          return (
            (this.options.opacity = e),
            this._image && this._updateOpacity(),
            this
          );
        },
        setStyle: function (e) {
          return e.opacity && this.setOpacity(e.opacity), this;
        },
        bringToFront: function () {
          return this._map && kt(this._image), this;
        },
        bringToBack: function () {
          return this._map && At(this._image), this;
        },
        setUrl: function (e) {
          return (this._url = e), this._image && (this._image.src = e), this;
        },
        setBounds: function (e) {
          return (this._bounds = E(e)), this._map && this._reset(), this;
        },
        getEvents: function () {
          var e = { zoom: this._reset, viewreset: this._reset };
          return this._zoomAnimated && (e.zoomanim = this._animateZoom), e;
        },
        setZIndex: function (e) {
          return (this.options.zIndex = e), this._updateZIndex(), this;
        },
        getBounds: function () {
          return this._bounds;
        },
        getElement: function () {
          return this._image;
        },
        _initImage: function () {
          var e = this._url.tagName === `IMG`,
            t = (this._image = e ? this._url : N(`img`));
          F(t, `leaflet-image-layer`),
            this._zoomAnimated && F(t, `leaflet-zoom-animated`),
            this.options.className && F(t, this.options.className),
            (t.onselectstart = l),
            (t.onmousemove = l),
            (t.onload = i(this.fire, this, `load`)),
            (t.onerror = i(this._overlayOnError, this, `error`)),
            (this.options.crossOrigin || this.options.crossOrigin === ``) &&
              (t.crossOrigin =
                this.options.crossOrigin === !0
                  ? ``
                  : this.options.crossOrigin),
            this.options.zIndex && this._updateZIndex(),
            e
              ? (this._url = t.src)
              : ((t.src = this._url), (t.alt = this.options.alt));
        },
        _animateZoom: function (e) {
          var t = this._map.getZoomScale(e.zoom),
            n = this._map._latLngBoundsToNewLayerBounds(
              this._bounds,
              e.zoom,
              e.center
            ).min;
          It(this._image, n, t);
        },
        _reset: function () {
          var e = this._image,
            t = new C(
              this._map.latLngToLayerPoint(this._bounds.getNorthWest()),
              this._map.latLngToLayerPoint(this._bounds.getSouthEast())
            ),
            n = t.getSize();
          z(e, t.min),
            (e.style.width = n.x + `px`),
            (e.style.height = n.y + `px`);
        },
        _updateOpacity: function () {
          R(this._image, this.options.opacity);
        },
        _updateZIndex: function () {
          this._image &&
            this.options.zIndex !== void 0 &&
            this.options.zIndex !== null &&
            (this._image.style.zIndex = this.options.zIndex);
        },
        _overlayOnError: function () {
          this.fire(`error`);
          var e = this.options.errorOverlayUrl;
          e && this._url !== e && ((this._url = e), (this._image.src = e));
        },
        getCenter: function () {
          return this._bounds.getCenter();
        },
      }),
      Tr = function (e, t, n) {
        return new wr(e, t, n);
      },
      Er = wr.extend({
        options: {
          autoplay: !0,
          loop: !0,
          keepAspectRatio: !0,
          muted: !1,
          playsInline: !0,
        },
        _initImage: function () {
          var e = this._url.tagName === `VIDEO`,
            t = (this._image = e ? this._url : N(`video`));
          if (
            (F(t, `leaflet-image-layer`),
            this._zoomAnimated && F(t, `leaflet-zoom-animated`),
            this.options.className && F(t, this.options.className),
            (t.onselectstart = l),
            (t.onmousemove = l),
            (t.onloadeddata = i(this.fire, this, `load`)),
            e)
          ) {
            for (
              var n = t.getElementsByTagName(`source`), r = [], a = 0;
              a < n.length;
              a++
            )
              r.push(n[a].src);
            this._url = n.length > 0 ? r : [t.src];
          } else {
            g(this._url) || (this._url = [this._url]),
              !this.options.keepAspectRatio &&
                Object.prototype.hasOwnProperty.call(t.style, `objectFit`) &&
                (t.style.objectFit = `fill`),
              (t.autoplay = !!this.options.autoplay),
              (t.loop = !!this.options.loop),
              (t.muted = !!this.options.muted),
              (t.playsInline = !!this.options.playsInline);
            for (var o = 0; o < this._url.length; o++) {
              var s = N(`source`);
              (s.src = this._url[o]), t.appendChild(s);
            }
          }
        },
      });
    function Dr(e, t, n) {
      return new Er(e, t, n);
    }
    var Or = wr.extend({
      _initImage: function () {
        var e = (this._image = this._url);
        F(e, `leaflet-image-layer`),
          this._zoomAnimated && F(e, `leaflet-zoom-animated`),
          this.options.className && F(e, this.options.className),
          (e.onselectstart = l),
          (e.onmousemove = l);
      },
    });
    function kr(e, t, n) {
      return new Or(e, t, n);
    }
    var Q = J.extend({
      options: {
        interactive: !1,
        offset: [0, 0],
        className: ``,
        pane: void 0,
        content: ``,
      },
      initialize: function (e, t) {
        e && (e instanceof D || g(e))
          ? ((this._latlng = O(e)), p(this, t))
          : (p(this, e), (this._source = t)),
          this.options.content && (this._content = this.options.content);
      },
      openOn: function (e) {
        return (
          (e = arguments.length ? e : this._source._map),
          e.hasLayer(this) || e.addLayer(this),
          this
        );
      },
      close: function () {
        return this._map && this._map.removeLayer(this), this;
      },
      toggle: function (e) {
        return (
          this._map
            ? this.close()
            : (arguments.length ? (this._source = e) : (e = this._source),
              this._prepareOpen(),
              this.openOn(e._map)),
          this
        );
      },
      onAdd: function (e) {
        (this._zoomAnimated = e._zoomAnimated),
          this._container || this._initLayout(),
          e._fadeAnimated && R(this._container, 0),
          clearTimeout(this._removeTimeout),
          this.getPane().appendChild(this._container),
          this.update(),
          e._fadeAnimated && R(this._container, 1),
          this.bringToFront(),
          this.options.interactive &&
            (F(this._container, `leaflet-interactive`),
            this.addInteractiveTarget(this._container));
      },
      onRemove: function (e) {
        e._fadeAnimated
          ? (R(this._container, 0),
            (this._removeTimeout = setTimeout(
              i(P, void 0, this._container),
              200
            )))
          : P(this._container),
          this.options.interactive &&
            (I(this._container, `leaflet-interactive`),
            this.removeInteractiveTarget(this._container));
      },
      getLatLng: function () {
        return this._latlng;
      },
      setLatLng: function (e) {
        return (
          (this._latlng = O(e)),
          this._map && (this._updatePosition(), this._adjustPan()),
          this
        );
      },
      getContent: function () {
        return this._content;
      },
      setContent: function (e) {
        return (this._content = e), this.update(), this;
      },
      getElement: function () {
        return this._container;
      },
      update: function () {
        this._map &&
          ((this._container.style.visibility = `hidden`),
          this._updateContent(),
          this._updateLayout(),
          this._updatePosition(),
          (this._container.style.visibility = ``),
          this._adjustPan());
      },
      getEvents: function () {
        var e = { zoom: this._updatePosition, viewreset: this._updatePosition };
        return this._zoomAnimated && (e.zoomanim = this._animateZoom), e;
      },
      isOpen: function () {
        return !!this._map && this._map.hasLayer(this);
      },
      bringToFront: function () {
        return this._map && kt(this._container), this;
      },
      bringToBack: function () {
        return this._map && At(this._container), this;
      },
      _prepareOpen: function (e) {
        var t = this._source;
        if (!t._map) return !1;
        if (t instanceof Y) {
          t = null;
          var n = this._source._layers;
          for (var r in n)
            if (n[r]._map) {
              t = n[r];
              break;
            }
          if (!t) return !1;
          this._source = t;
        }
        if (!e) {
          if (t.getCenter) e = t.getCenter();
          else if (t.getLatLng) e = t.getLatLng();
          else if (t.getBounds) e = t.getBounds().getCenter();
          else throw Error(`Unable to get source layer LatLng.`);
        }
        return this.setLatLng(e), this._map && this.update(), !0;
      },
      _updateContent: function () {
        if (this._content) {
          var e = this._contentNode,
            t =
              typeof this._content == `function`
                ? this._content(this._source || this)
                : this._content;
          if (typeof t == `string`) e.innerHTML = t;
          else {
            for (; e.hasChildNodes(); ) e.removeChild(e.firstChild);
            e.appendChild(t);
          }
          this.fire(`contentupdate`);
        }
      },
      _updatePosition: function () {
        if (this._map) {
          var e = this._map.latLngToLayerPoint(this._latlng),
            t = S(this.options.offset),
            n = this._getAnchor();
          this._zoomAnimated
            ? z(this._container, e.add(n))
            : (t = t.add(e).add(n));
          var r = (this._containerBottom = -t.y),
            i = (this._containerLeft =
              -Math.round(this._containerWidth / 2) + t.x);
          (this._container.style.bottom = r + `px`),
            (this._container.style.left = i + `px`);
        }
      },
      _getAnchor: function () {
        return [0, 0];
      },
    });
    W.include({
      _initOverlay: function (e, t, n, r) {
        var i = t;
        return (
          i instanceof e || (i = new e(r).setContent(t)), n && i.setLatLng(n), i
        );
      },
    }),
      J.include({
        _initOverlay: function (e, t, n, r) {
          var i = n;
          return (
            i instanceof e
              ? (p(i, r), (i._source = this))
              : ((i = t && !r ? t : new e(r, this)), i.setContent(n)),
            i
          );
        },
      });
    var Ar = Q.extend({
        options: {
          pane: `popupPane`,
          offset: [0, 7],
          maxWidth: 300,
          minWidth: 50,
          maxHeight: null,
          autoPan: !0,
          autoPanPaddingTopLeft: null,
          autoPanPaddingBottomRight: null,
          autoPanPadding: [5, 5],
          keepInView: !1,
          closeButton: !0,
          autoClose: !0,
          closeOnEscapeKey: !0,
          className: ``,
        },
        openOn: function (e) {
          return (
            (e = arguments.length ? e : this._source._map),
            !e.hasLayer(this) &&
              e._popup &&
              e._popup.options.autoClose &&
              e.removeLayer(e._popup),
            (e._popup = this),
            Q.prototype.openOn.call(this, e)
          );
        },
        onAdd: function (e) {
          Q.prototype.onAdd.call(this, e),
            e.fire(`popupopen`, { popup: this }),
            this._source &&
              (this._source.fire(`popupopen`, { popup: this }, !0),
              this._source instanceof ar || this._source.on(`preclick`, tn));
        },
        onRemove: function (e) {
          Q.prototype.onRemove.call(this, e),
            e.fire(`popupclose`, { popup: this }),
            this._source &&
              (this._source.fire(`popupclose`, { popup: this }, !0),
              this._source instanceof ar || this._source.off(`preclick`, tn));
        },
        getEvents: function () {
          var e = Q.prototype.getEvents.call(this);
          return (
            (this.options.closeOnClick === void 0
              ? this._map.options.closePopupOnClick
              : this.options.closeOnClick) && (e.preclick = this.close),
            this.options.keepInView && (e.moveend = this._adjustPan),
            e
          );
        },
        _initLayout: function () {
          var e = `leaflet-popup`,
            t = (this._container = N(
              `div`,
              e +
                ` ` +
                (this.options.className || ``) +
                ` leaflet-zoom-animated`
            )),
            n = (this._wrapper = N(`div`, e + `-content-wrapper`, t));
          if (
            ((this._contentNode = N(`div`, e + `-content`, n)),
            rn(t),
            nn(this._contentNode),
            B(t, `contextmenu`, tn),
            (this._tipContainer = N(`div`, e + `-tip-container`, t)),
            (this._tip = N(`div`, e + `-tip`, this._tipContainer)),
            this.options.closeButton)
          ) {
            var r = (this._closeButton = N(`a`, e + `-close-button`, t));
            r.setAttribute(`role`, `button`),
              r.setAttribute(`aria-label`, `Close popup`),
              (r.href = `#close`),
              (r.innerHTML = `<span aria-hidden="true">&#215;</span>`),
              B(
                r,
                `click`,
                function (e) {
                  U(e), this.close();
                },
                this
              );
          }
        },
        _updateLayout: function () {
          var e = this._contentNode,
            t = e.style;
          (t.width = ``), (t.whiteSpace = `nowrap`);
          var n = e.offsetWidth;
          (n = Math.min(n, this.options.maxWidth)),
            (n = Math.max(n, this.options.minWidth)),
            (t.width = n + 1 + `px`),
            (t.whiteSpace = ``),
            (t.height = ``);
          var r = e.offsetHeight,
            i = this.options.maxHeight,
            a = `leaflet-popup-scrolled`;
          i && r > i ? ((t.height = i + `px`), F(e, a)) : I(e, a),
            (this._containerWidth = this._container.offsetWidth);
        },
        _animateZoom: function (e) {
          var t = this._map._latLngToNewLayerPoint(
              this._latlng,
              e.zoom,
              e.center
            ),
            n = this._getAnchor();
          z(this._container, t.add(n));
        },
        _adjustPan: function () {
          if (this.options.autoPan) {
            if (
              (this._map._panAnim && this._map._panAnim.stop(),
              this._autopanning)
            )
              this._autopanning = !1;
            else {
              var e = this._map,
                t = parseInt(Dt(this._container, `marginBottom`), 10) || 0,
                n = this._container.offsetHeight + t,
                r = this._containerWidth,
                i = new x(this._containerLeft, -n - this._containerBottom);
              i._add(Lt(this._container));
              var a = e.layerPointToContainerPoint(i),
                o = S(this.options.autoPanPadding),
                s = S(this.options.autoPanPaddingTopLeft || o),
                c = S(this.options.autoPanPaddingBottomRight || o),
                l = e.getSize(),
                u = 0,
                d = 0;
              a.x + r + c.x > l.x && (u = a.x + r - l.x + c.x),
                a.x - u - s.x < 0 && (u = a.x - s.x),
                a.y + n + c.y > l.y && (d = a.y + n - l.y + c.y),
                a.y - d - s.y < 0 && (d = a.y - s.y),
                (u || d) &&
                  (this.options.keepInView && (this._autopanning = !0),
                  e.fire(`autopanstart`).panBy([u, d]));
            }
          }
        },
        _getAnchor: function () {
          return S(
            this._source && this._source._getPopupAnchor
              ? this._source._getPopupAnchor()
              : [0, 0]
          );
        },
      }),
      jr = function (e, t) {
        return new Ar(e, t);
      };
    W.mergeOptions({ closePopupOnClick: !0 }),
      W.include({
        openPopup: function (e, t, n) {
          return this._initOverlay(Ar, e, t, n).openOn(this), this;
        },
        closePopup: function (e) {
          return (e = arguments.length ? e : this._popup), e && e.close(), this;
        },
      }),
      J.include({
        bindPopup: function (e, t) {
          return (
            (this._popup = this._initOverlay(Ar, this._popup, e, t)),
            (this._popupHandlersAdded ||=
              (this.on({
                click: this._openPopup,
                keypress: this._onKeyPress,
                remove: this.closePopup,
                move: this._movePopup,
              }),
              !0)),
            this
          );
        },
        unbindPopup: function () {
          return (
            (this._popup &&=
              (this.off({
                click: this._openPopup,
                keypress: this._onKeyPress,
                remove: this.closePopup,
                move: this._movePopup,
              }),
              (this._popupHandlersAdded = !1),
              null)),
            this
          );
        },
        openPopup: function (e) {
          return (
            this._popup &&
              (this instanceof Y || (this._popup._source = this),
              this._popup._prepareOpen(e || this._latlng) &&
                this._popup.openOn(this._map)),
            this
          );
        },
        closePopup: function () {
          return this._popup && this._popup.close(), this;
        },
        togglePopup: function () {
          return this._popup && this._popup.toggle(this), this;
        },
        isPopupOpen: function () {
          return this._popup ? this._popup.isOpen() : !1;
        },
        setPopupContent: function (e) {
          return this._popup && this._popup.setContent(e), this;
        },
        getPopup: function () {
          return this._popup;
        },
        _openPopup: function (e) {
          if (this._popup && this._map) {
            an(e);
            var t = e.layer || e.target;
            this._popup._source === t && !(t instanceof ar)
              ? this._map.hasLayer(this._popup)
                ? this.closePopup()
                : this.openPopup(e.latlng)
              : ((this._popup._source = t), this.openPopup(e.latlng));
          }
        },
        _movePopup: function (e) {
          this._popup.setLatLng(e.latlng);
        },
        _onKeyPress: function (e) {
          e.originalEvent.keyCode === 13 && this._openPopup(e);
        },
      });
    var Mr = Q.extend({
        options: {
          pane: `tooltipPane`,
          offset: [0, 0],
          direction: `auto`,
          permanent: !1,
          sticky: !1,
          opacity: 0.9,
        },
        onAdd: function (e) {
          Q.prototype.onAdd.call(this, e),
            this.setOpacity(this.options.opacity),
            e.fire(`tooltipopen`, { tooltip: this }),
            this._source &&
              (this.addEventParent(this._source),
              this._source.fire(`tooltipopen`, { tooltip: this }, !0));
        },
        onRemove: function (e) {
          Q.prototype.onRemove.call(this, e),
            e.fire(`tooltipclose`, { tooltip: this }),
            this._source &&
              (this.removeEventParent(this._source),
              this._source.fire(`tooltipclose`, { tooltip: this }, !0));
        },
        getEvents: function () {
          var e = Q.prototype.getEvents.call(this);
          return this.options.permanent || (e.preclick = this.close), e;
        },
        _initLayout: function () {
          var e =
            `leaflet-tooltip ` +
            (this.options.className || ``) +
            ` leaflet-zoom-` +
            (this._zoomAnimated ? `animated` : `hide`);
          (this._contentNode = this._container = N(`div`, e)),
            this._container.setAttribute(`role`, `tooltip`),
            this._container.setAttribute(`id`, `leaflet-tooltip-` + o(this));
        },
        _updateLayout: function () {},
        _adjustPan: function () {},
        _setPosition: function (e) {
          var t,
            n,
            r = this._map,
            i = this._container,
            a = r.latLngToContainerPoint(r.getCenter()),
            o = r.layerPointToContainerPoint(e),
            s = this.options.direction,
            c = i.offsetWidth,
            l = i.offsetHeight,
            u = S(this.options.offset),
            d = this._getAnchor();
          s === `top`
            ? ((t = c / 2), (n = l))
            : s === `bottom`
            ? ((t = c / 2), (n = 0))
            : s === `center`
            ? ((t = c / 2), (n = l / 2))
            : s === `right`
            ? ((t = 0), (n = l / 2))
            : s === `left`
            ? ((t = c), (n = l / 2))
            : o.x < a.x
            ? ((s = `right`), (t = 0), (n = l / 2))
            : ((s = `left`), (t = c + (u.x + d.x) * 2), (n = l / 2)),
            (e = e.subtract(S(t, n, !0)).add(u).add(d)),
            I(i, `leaflet-tooltip-right`),
            I(i, `leaflet-tooltip-left`),
            I(i, `leaflet-tooltip-top`),
            I(i, `leaflet-tooltip-bottom`),
            F(i, `leaflet-tooltip-` + s),
            z(i, e);
        },
        _updatePosition: function () {
          var e = this._map.latLngToLayerPoint(this._latlng);
          this._setPosition(e);
        },
        setOpacity: function (e) {
          (this.options.opacity = e), this._container && R(this._container, e);
        },
        _animateZoom: function (e) {
          var t = this._map._latLngToNewLayerPoint(
            this._latlng,
            e.zoom,
            e.center
          );
          this._setPosition(t);
        },
        _getAnchor: function () {
          return S(
            this._source &&
              this._source._getTooltipAnchor &&
              !this.options.sticky
              ? this._source._getTooltipAnchor()
              : [0, 0]
          );
        },
      }),
      Nr = function (e, t) {
        return new Mr(e, t);
      };
    W.include({
      openTooltip: function (e, t, n) {
        return this._initOverlay(Mr, e, t, n).openOn(this), this;
      },
      closeTooltip: function (e) {
        return e.close(), this;
      },
    }),
      J.include({
        bindTooltip: function (e, t) {
          return (
            this._tooltip && this.isTooltipOpen() && this.unbindTooltip(),
            (this._tooltip = this._initOverlay(Mr, this._tooltip, e, t)),
            this._initTooltipInteractions(),
            this._tooltip.options.permanent &&
              this._map &&
              this._map.hasLayer(this) &&
              this.openTooltip(),
            this
          );
        },
        unbindTooltip: function () {
          return (
            (this._tooltip &&=
              (this._initTooltipInteractions(!0), this.closeTooltip(), null)),
            this
          );
        },
        _initTooltipInteractions: function (e) {
          if (e || !this._tooltipHandlersAdded) {
            var t = e ? `off` : `on`,
              n = { remove: this.closeTooltip, move: this._moveTooltip };
            this._tooltip.options.permanent
              ? (n.add = this._openTooltip)
              : ((n.mouseover = this._openTooltip),
                (n.mouseout = this.closeTooltip),
                (n.click = this._openTooltip),
                this._map
                  ? this._addFocusListeners()
                  : (n.add = this._addFocusListeners)),
              this._tooltip.options.sticky && (n.mousemove = this._moveTooltip),
              this[t](n),
              (this._tooltipHandlersAdded = !e);
          }
        },
        openTooltip: function (e) {
          return (
            this._tooltip &&
              (this instanceof Y || (this._tooltip._source = this),
              this._tooltip._prepareOpen(e) &&
                (this._tooltip.openOn(this._map),
                this.getElement
                  ? this._setAriaDescribedByOnLayer(this)
                  : this.eachLayer &&
                    this.eachLayer(this._setAriaDescribedByOnLayer, this))),
            this
          );
        },
        closeTooltip: function () {
          if (this._tooltip) return this._tooltip.close();
        },
        toggleTooltip: function () {
          return this._tooltip && this._tooltip.toggle(this), this;
        },
        isTooltipOpen: function () {
          return this._tooltip.isOpen();
        },
        setTooltipContent: function (e) {
          return this._tooltip && this._tooltip.setContent(e), this;
        },
        getTooltip: function () {
          return this._tooltip;
        },
        _addFocusListeners: function () {
          this.getElement
            ? this._addFocusListenersOnLayer(this)
            : this.eachLayer &&
              this.eachLayer(this._addFocusListenersOnLayer, this);
        },
        _addFocusListenersOnLayer: function (e) {
          var t = typeof e.getElement == `function` && e.getElement();
          t &&
            (B(
              t,
              `focus`,
              function () {
                (this._tooltip._source = e), this.openTooltip();
              },
              this
            ),
            B(t, `blur`, this.closeTooltip, this));
        },
        _setAriaDescribedByOnLayer: function (e) {
          var t = typeof e.getElement == `function` && e.getElement();
          t && t.setAttribute(`aria-describedby`, this._tooltip._container.id);
        },
        _openTooltip: function (e) {
          if (this._tooltip && this._map) {
            if (
              this._map.dragging &&
              this._map.dragging.moving() &&
              !this._openOnceFlag
            ) {
              this._openOnceFlag = !0;
              var t = this;
              this._map.once(`moveend`, function () {
                (t._openOnceFlag = !1), t._openTooltip(e);
              });
            } else
              (this._tooltip._source = e.layer || e.target),
                this.openTooltip(
                  this._tooltip.options.sticky ? e.latlng : void 0
                );
          }
        },
        _moveTooltip: function (e) {
          var t = e.latlng,
            n,
            r;
          this._tooltip.options.sticky &&
            e.originalEvent &&
            ((n = this._map.mouseEventToContainerPoint(e.originalEvent)),
            (r = this._map.containerPointToLayerPoint(n)),
            (t = this._map.layerPointToLatLng(r))),
            this._tooltip.setLatLng(t);
        },
      });
    var Pr = $n.extend({
      options: {
        iconSize: [12, 12],
        html: !1,
        bgPos: null,
        className: `leaflet-div-icon`,
      },
      createIcon: function (e) {
        var t = e && e.tagName === `DIV` ? e : document.createElement(`div`),
          n = this.options;
        if (
          (n.html instanceof Element
            ? (Ot(t), t.appendChild(n.html))
            : (t.innerHTML = n.html === !1 ? `` : n.html),
          n.bgPos)
        ) {
          var r = S(n.bgPos);
          t.style.backgroundPosition = -r.x + `px ` + -r.y + `px`;
        }
        return this._setIconStyles(t, `icon`), t;
      },
      createShadow: function () {
        return null;
      },
    });
    function Fr(e) {
      return new Pr(e);
    }
    $n.Default = tr;
    var Ir = J.extend({
      options: {
        tileSize: 256,
        opacity: 1,
        updateWhenIdle: M.mobile,
        updateWhenZooming: !0,
        updateInterval: 200,
        zIndex: 1,
        bounds: null,
        minZoom: 0,
        maxZoom: void 0,
        maxNativeZoom: void 0,
        minNativeZoom: void 0,
        noWrap: !1,
        pane: `tilePane`,
        className: ``,
        keepBuffer: 2,
      },
      initialize: function (e) {
        p(this, e);
      },
      onAdd: function () {
        this._initContainer(),
          (this._levels = {}),
          (this._tiles = {}),
          this._resetView();
      },
      beforeAdd: function (e) {
        e._addZoomLimit(this);
      },
      onRemove: function (e) {
        this._removeAllTiles(),
          P(this._container),
          e._removeZoomLimit(this),
          (this._container = null),
          (this._tileZoom = void 0);
      },
      bringToFront: function () {
        return (
          this._map && (kt(this._container), this._setAutoZIndex(Math.max)),
          this
        );
      },
      bringToBack: function () {
        return (
          this._map && (At(this._container), this._setAutoZIndex(Math.min)),
          this
        );
      },
      getContainer: function () {
        return this._container;
      },
      setOpacity: function (e) {
        return (this.options.opacity = e), this._updateOpacity(), this;
      },
      setZIndex: function (e) {
        return (this.options.zIndex = e), this._updateZIndex(), this;
      },
      isLoading: function () {
        return this._loading;
      },
      redraw: function () {
        if (this._map) {
          this._removeAllTiles();
          var e = this._clampZoom(this._map.getZoom());
          e !== this._tileZoom && ((this._tileZoom = e), this._updateLevels()),
            this._update();
        }
        return this;
      },
      getEvents: function () {
        var e = {
          viewprereset: this._invalidateAll,
          viewreset: this._resetView,
          zoom: this._resetView,
          moveend: this._onMoveEnd,
        };
        return (
          this.options.updateWhenIdle ||
            ((this._onMove ||= s(
              this._onMoveEnd,
              this.options.updateInterval,
              this
            )),
            (e.move = this._onMove)),
          this._zoomAnimated && (e.zoomanim = this._animateZoom),
          e
        );
      },
      createTile: function () {
        return document.createElement(`div`);
      },
      getTileSize: function () {
        var e = this.options.tileSize;
        return e instanceof x ? e : new x(e, e);
      },
      _updateZIndex: function () {
        this._container &&
          this.options.zIndex !== void 0 &&
          this.options.zIndex !== null &&
          (this._container.style.zIndex = this.options.zIndex);
      },
      _setAutoZIndex: function (e) {
        for (
          var t = this.getPane().children,
            n = -e(-1 / 0, 1 / 0),
            r = 0,
            i = t.length,
            a;
          r < i;
          r++
        )
          (a = t[r].style.zIndex),
            t[r] !== this._container && a && (n = e(n, +a));
        isFinite(n) &&
          ((this.options.zIndex = n + e(-1, 1)), this._updateZIndex());
      },
      _updateOpacity: function () {
        if (this._map && !M.ielt9) {
          R(this._container, this.options.opacity);
          var e = +new Date(),
            t = !1,
            n = !1;
          for (var r in this._tiles) {
            var i = this._tiles[r];
            if (i.current && i.loaded) {
              var a = Math.min(1, (e - i.loaded) / 200);
              R(i.el, a),
                a < 1
                  ? (t = !0)
                  : (i.active ? (n = !0) : this._onOpaqueTile(i),
                    (i.active = !0));
            }
          }
          n && !this._noPrune && this._pruneTiles(),
            t &&
              (v(this._fadeFrame),
              (this._fadeFrame = _(this._updateOpacity, this)));
        }
      },
      _onOpaqueTile: l,
      _initContainer: function () {
        this._container ||
          ((this._container = N(
            `div`,
            `leaflet-layer ` + (this.options.className || ``)
          )),
          this._updateZIndex(),
          this.options.opacity < 1 && this._updateOpacity(),
          this.getPane().appendChild(this._container));
      },
      _updateLevels: function () {
        var e = this._tileZoom,
          t = this.options.maxZoom;
        if (e !== void 0) {
          for (var n in this._levels)
            (n = Number(n)),
              this._levels[n].el.children.length || n === e
                ? ((this._levels[n].el.style.zIndex = t - Math.abs(e - n)),
                  this._onUpdateLevel(n))
                : (P(this._levels[n].el),
                  this._removeTilesAtZoom(n),
                  this._onRemoveLevel(n),
                  delete this._levels[n]);
          var r = this._levels[e],
            i = this._map;
          return (
            r ||
              ((r = this._levels[e] = {}),
              (r.el = N(
                `div`,
                `leaflet-tile-container leaflet-zoom-animated`,
                this._container
              )),
              (r.el.style.zIndex = t),
              (r.origin = i
                .project(i.unproject(i.getPixelOrigin()), e)
                .round()),
              (r.zoom = e),
              this._setZoomTransform(r, i.getCenter(), i.getZoom()),
              r.el.offsetWidth,
              this._onCreateLevel(r)),
            (this._level = r),
            r
          );
        }
      },
      _onUpdateLevel: l,
      _onRemoveLevel: l,
      _onCreateLevel: l,
      _pruneTiles: function () {
        if (this._map) {
          var e,
            t,
            n = this._map.getZoom();
          if (n > this.options.maxZoom || n < this.options.minZoom)
            this._removeAllTiles();
          else {
            for (e in this._tiles) (t = this._tiles[e]), (t.retain = t.current);
            for (e in this._tiles)
              if (((t = this._tiles[e]), t.current && !t.active)) {
                var r = t.coords;
                this._retainParent(r.x, r.y, r.z, r.z - 5) ||
                  this._retainChildren(r.x, r.y, r.z, r.z + 2);
              }
            for (e in this._tiles) this._tiles[e].retain || this._removeTile(e);
          }
        }
      },
      _removeTilesAtZoom: function (e) {
        for (var t in this._tiles)
          this._tiles[t].coords.z === e && this._removeTile(t);
      },
      _removeAllTiles: function () {
        for (var e in this._tiles) this._removeTile(e);
      },
      _invalidateAll: function () {
        for (var e in this._levels)
          P(this._levels[e].el),
            this._onRemoveLevel(Number(e)),
            delete this._levels[e];
        this._removeAllTiles(), (this._tileZoom = void 0);
      },
      _retainParent: function (e, t, n, r) {
        var i = Math.floor(e / 2),
          a = Math.floor(t / 2),
          o = n - 1,
          s = new x(+i, +a);
        s.z = +o;
        var c = this._tileCoordsToKey(s),
          l = this._tiles[c];
        return l && l.active
          ? ((l.retain = !0), !0)
          : (l && l.loaded && (l.retain = !0),
            o > r && this._retainParent(i, a, o, r));
      },
      _retainChildren: function (e, t, n, r) {
        for (var i = 2 * e; i < 2 * e + 2; i++)
          for (var a = 2 * t; a < 2 * t + 2; a++) {
            var o = new x(i, a);
            o.z = n + 1;
            var s = this._tileCoordsToKey(o),
              c = this._tiles[s];
            c && c.active
              ? (c.retain = !0)
              : (c && c.loaded && (c.retain = !0),
                n + 1 < r && this._retainChildren(i, a, n + 1, r));
          }
      },
      _resetView: function (e) {
        var t = e && (e.pinch || e.flyTo);
        this._setView(this._map.getCenter(), this._map.getZoom(), t, t);
      },
      _animateZoom: function (e) {
        this._setView(e.center, e.zoom, !0, e.noUpdate);
      },
      _clampZoom: function (e) {
        var t = this.options;
        return t.minNativeZoom !== void 0 && e < t.minNativeZoom
          ? t.minNativeZoom
          : t.maxNativeZoom !== void 0 && t.maxNativeZoom < e
          ? t.maxNativeZoom
          : e;
      },
      _setView: function (e, t, n, r) {
        var i = Math.round(t);
        i =
          (this.options.maxZoom !== void 0 && i > this.options.maxZoom) ||
          (this.options.minZoom !== void 0 && i < this.options.minZoom)
            ? void 0
            : this._clampZoom(i);
        var a = this.options.updateWhenZooming && i !== this._tileZoom;
        (!r || a) &&
          ((this._tileZoom = i),
          this._abortLoading && this._abortLoading(),
          this._updateLevels(),
          this._resetGrid(),
          i !== void 0 && this._update(e),
          n || this._pruneTiles(),
          (this._noPrune = !!n)),
          this._setZoomTransforms(e, t);
      },
      _setZoomTransforms: function (e, t) {
        for (var n in this._levels)
          this._setZoomTransform(this._levels[n], e, t);
      },
      _setZoomTransform: function (e, t, n) {
        var r = this._map.getZoomScale(n, e.zoom),
          i = e.origin
            .multiplyBy(r)
            .subtract(this._map._getNewPixelOrigin(t, n))
            .round();
        M.any3d ? It(e.el, i, r) : z(e.el, i);
      },
      _resetGrid: function () {
        var e = this._map,
          t = e.options.crs,
          n = (this._tileSize = this.getTileSize()),
          r = this._tileZoom,
          i = this._map.getPixelWorldBounds(this._tileZoom);
        i && (this._globalTileRange = this._pxBoundsToTileRange(i)),
          (this._wrapX = t.wrapLng &&
            !this.options.noWrap && [
              Math.floor(e.project([0, t.wrapLng[0]], r).x / n.x),
              Math.ceil(e.project([0, t.wrapLng[1]], r).x / n.y),
            ]),
          (this._wrapY = t.wrapLat &&
            !this.options.noWrap && [
              Math.floor(e.project([t.wrapLat[0], 0], r).y / n.x),
              Math.ceil(e.project([t.wrapLat[1], 0], r).y / n.y),
            ]);
      },
      _onMoveEnd: function () {
        this._map && !this._map._animatingZoom && this._update();
      },
      _getTiledPixelBounds: function (e) {
        var t = this._map,
          n = t._animatingZoom
            ? Math.max(t._animateToZoom, t.getZoom())
            : t.getZoom(),
          r = t.getZoomScale(n, this._tileZoom),
          i = t.project(e, this._tileZoom).floor(),
          a = t.getSize().divideBy(r * 2);
        return new C(i.subtract(a), i.add(a));
      },
      _update: function (e) {
        var t = this._map;
        if (t) {
          var n = this._clampZoom(t.getZoom());
          if (
            (e === void 0 && (e = t.getCenter()), this._tileZoom !== void 0)
          ) {
            var r = this._getTiledPixelBounds(e),
              i = this._pxBoundsToTileRange(r),
              a = i.getCenter(),
              o = [],
              s = this.options.keepBuffer,
              c = new C(
                i.getBottomLeft().subtract([s, -s]),
                i.getTopRight().add([s, -s])
              );
            if (
              !(
                isFinite(i.min.x) &&
                isFinite(i.min.y) &&
                isFinite(i.max.x) &&
                isFinite(i.max.y)
              )
            )
              throw Error(`Attempted to load an infinite number of tiles`);
            for (var l in this._tiles) {
              var u = this._tiles[l].coords;
              (u.z === this._tileZoom && c.contains(new x(u.x, u.y))) ||
                (this._tiles[l].current = !1);
            }
            if (Math.abs(n - this._tileZoom) > 1) this._setView(e, n);
            else {
              for (var d = i.min.y; d <= i.max.y; d++)
                for (var f = i.min.x; f <= i.max.x; f++) {
                  var p = new x(f, d);
                  if (((p.z = this._tileZoom), this._isValidTile(p))) {
                    var m = this._tiles[this._tileCoordsToKey(p)];
                    m ? (m.current = !0) : o.push(p);
                  }
                }
              if (
                (o.sort(function (e, t) {
                  return e.distanceTo(a) - t.distanceTo(a);
                }),
                o.length !== 0)
              ) {
                this._loading || ((this._loading = !0), this.fire(`loading`));
                var ee = document.createDocumentFragment();
                for (f = 0; f < o.length; f++) this._addTile(o[f], ee);
                this._level.el.appendChild(ee);
              }
            }
          }
        }
      },
      _isValidTile: function (e) {
        var t = this._map.options.crs;
        if (!t.infinite) {
          var n = this._globalTileRange;
          if (
            (!t.wrapLng && (e.x < n.min.x || e.x > n.max.x)) ||
            (!t.wrapLat && (e.y < n.min.y || e.y > n.max.y))
          )
            return !1;
        }
        if (!this.options.bounds) return !0;
        var r = this._tileCoordsToBounds(e);
        return E(this.options.bounds).overlaps(r);
      },
      _keyToBounds: function (e) {
        return this._tileCoordsToBounds(this._keyToTileCoords(e));
      },
      _tileCoordsToNwSe: function (e) {
        var t = this._map,
          n = this.getTileSize(),
          r = e.scaleBy(n),
          i = r.add(n);
        return [t.unproject(r, e.z), t.unproject(i, e.z)];
      },
      _tileCoordsToBounds: function (e) {
        var t = this._tileCoordsToNwSe(e),
          n = new T(t[0], t[1]);
        return this.options.noWrap || (n = this._map.wrapLatLngBounds(n)), n;
      },
      _tileCoordsToKey: function (e) {
        return e.x + `:` + e.y + `:` + e.z;
      },
      _keyToTileCoords: function (e) {
        var t = e.split(`:`),
          n = new x(+t[0], +t[1]);
        return (n.z = +t[2]), n;
      },
      _removeTile: function (e) {
        var t = this._tiles[e];
        t &&
          (P(t.el),
          delete this._tiles[e],
          this.fire(`tileunload`, {
            tile: t.el,
            coords: this._keyToTileCoords(e),
          }));
      },
      _initTile: function (e) {
        F(e, `leaflet-tile`);
        var t = this.getTileSize();
        (e.style.width = t.x + `px`),
          (e.style.height = t.y + `px`),
          (e.onselectstart = l),
          (e.onmousemove = l),
          M.ielt9 && this.options.opacity < 1 && R(e, this.options.opacity);
      },
      _addTile: function (e, t) {
        var n = this._getTilePos(e),
          r = this._tileCoordsToKey(e),
          a = this.createTile(this._wrapCoords(e), i(this._tileReady, this, e));
        this._initTile(a),
          this.createTile.length < 2 && _(i(this._tileReady, this, e, null, a)),
          z(a, n),
          (this._tiles[r] = { el: a, coords: e, current: !0 }),
          t.appendChild(a),
          this.fire(`tileloadstart`, { tile: a, coords: e });
      },
      _tileReady: function (e, t, n) {
        t && this.fire(`tileerror`, { error: t, tile: n, coords: e });
        var r = this._tileCoordsToKey(e);
        (n = this._tiles[r]),
          n &&
            ((n.loaded = +new Date()),
            this._map._fadeAnimated
              ? (R(n.el, 0),
                v(this._fadeFrame),
                (this._fadeFrame = _(this._updateOpacity, this)))
              : ((n.active = !0), this._pruneTiles()),
            t ||
              (F(n.el, `leaflet-tile-loaded`),
              this.fire(`tileload`, { tile: n.el, coords: e })),
            this._noTilesToLoad() &&
              ((this._loading = !1),
              this.fire(`load`),
              M.ielt9 || !this._map._fadeAnimated
                ? _(this._pruneTiles, this)
                : setTimeout(i(this._pruneTiles, this), 250)));
      },
      _getTilePos: function (e) {
        return e.scaleBy(this.getTileSize()).subtract(this._level.origin);
      },
      _wrapCoords: function (e) {
        var t = new x(
          this._wrapX ? c(e.x, this._wrapX) : e.x,
          this._wrapY ? c(e.y, this._wrapY) : e.y
        );
        return (t.z = e.z), t;
      },
      _pxBoundsToTileRange: function (e) {
        var t = this.getTileSize();
        return new C(
          e.min.unscaleBy(t).floor(),
          e.max.unscaleBy(t).ceil().subtract([1, 1])
        );
      },
      _noTilesToLoad: function () {
        for (var e in this._tiles) if (!this._tiles[e].loaded) return !1;
        return !0;
      },
    });
    function Lr(e) {
      return new Ir(e);
    }
    var Rr = Ir.extend({
      options: {
        minZoom: 0,
        maxZoom: 18,
        subdomains: `abc`,
        errorTileUrl: ``,
        zoomOffset: 0,
        tms: !1,
        zoomReverse: !1,
        detectRetina: !1,
        crossOrigin: !1,
        referrerPolicy: !1,
      },
      initialize: function (e, t) {
        (this._url = e),
          (t = p(this, t)),
          t.detectRetina && M.retina && t.maxZoom > 0
            ? ((t.tileSize = Math.floor(t.tileSize / 2)),
              t.zoomReverse
                ? (t.zoomOffset--,
                  (t.minZoom = Math.min(t.maxZoom, t.minZoom + 1)))
                : (t.zoomOffset++,
                  (t.maxZoom = Math.max(t.minZoom, t.maxZoom - 1))),
              (t.minZoom = Math.max(0, t.minZoom)))
            : t.zoomReverse
            ? (t.minZoom = Math.min(t.maxZoom, t.minZoom))
            : (t.maxZoom = Math.max(t.minZoom, t.maxZoom)),
          typeof t.subdomains == `string` &&
            (t.subdomains = t.subdomains.split(``)),
          this.on(`tileunload`, this._onTileRemove);
      },
      setUrl: function (e, t) {
        return (
          this._url === e && t === void 0 && (t = !0),
          (this._url = e),
          t || this.redraw(),
          this
        );
      },
      createTile: function (e, t) {
        var n = document.createElement(`img`);
        return (
          B(n, `load`, i(this._tileOnLoad, this, t, n)),
          B(n, `error`, i(this._tileOnError, this, t, n)),
          (this.options.crossOrigin || this.options.crossOrigin === ``) &&
            (n.crossOrigin =
              this.options.crossOrigin === !0 ? `` : this.options.crossOrigin),
          typeof this.options.referrerPolicy == `string` &&
            (n.referrerPolicy = this.options.referrerPolicy),
          (n.alt = ``),
          (n.src = this.getTileUrl(e)),
          n
        );
      },
      getTileUrl: function (e) {
        var t = {
          r: M.retina ? `@2x` : ``,
          s: this._getSubdomain(e),
          x: e.x,
          y: e.y,
          z: this._getZoomForUrl(),
        };
        if (this._map && !this._map.options.crs.infinite) {
          var r = this._globalTileRange.max.y - e.y;
          this.options.tms && (t.y = r), (t[`-y`] = r);
        }
        return h(this._url, n(t, this.options));
      },
      _tileOnLoad: function (e, t) {
        M.ielt9 ? setTimeout(i(e, this, null, t), 0) : e(null, t);
      },
      _tileOnError: function (e, t, n) {
        var r = this.options.errorTileUrl;
        r && t.getAttribute(`src`) !== r && (t.src = r), e(n, t);
      },
      _onTileRemove: function (e) {
        e.tile.onload = null;
      },
      _getZoomForUrl: function () {
        var e = this._tileZoom,
          t = this.options.maxZoom,
          n = this.options.zoomReverse,
          r = this.options.zoomOffset;
        return n && (e = t - e), e + r;
      },
      _getSubdomain: function (e) {
        var t = Math.abs(e.x + e.y) % this.options.subdomains.length;
        return this.options.subdomains[t];
      },
      _abortLoading: function () {
        var e, t;
        for (e in this._tiles)
          if (
            this._tiles[e].coords.z !== this._tileZoom &&
            ((t = this._tiles[e].el),
            (t.onload = l),
            (t.onerror = l),
            !t.complete)
          ) {
            t.src = ne;
            var n = this._tiles[e].coords;
            P(t),
              delete this._tiles[e],
              this.fire(`tileabort`, { tile: t, coords: n });
          }
      },
      _removeTile: function (e) {
        var t = this._tiles[e];
        if (t)
          return (
            t.el.setAttribute(`src`, ne), Ir.prototype._removeTile.call(this, e)
          );
      },
      _tileReady: function (e, t, n) {
        if (!(!this._map || (n && n.getAttribute(`src`) === ne)))
          return Ir.prototype._tileReady.call(this, e, t, n);
      },
    });
    function zr(e, t) {
      return new Rr(e, t);
    }
    var Br = Rr.extend({
      defaultWmsParams: {
        service: `WMS`,
        request: `GetMap`,
        layers: ``,
        styles: ``,
        format: `image/jpeg`,
        transparent: !1,
        version: `1.1.1`,
      },
      options: { crs: null, uppercase: !1 },
      initialize: function (e, t) {
        this._url = e;
        var r = n({}, this.defaultWmsParams);
        for (var i in t) i in this.options || (r[i] = t[i]);
        t = p(this, t);
        var a = t.detectRetina && M.retina ? 2 : 1,
          o = this.getTileSize();
        (r.width = o.x * a), (r.height = o.y * a), (this.wmsParams = r);
      },
      onAdd: function (e) {
        (this._crs = this.options.crs || e.options.crs),
          (this._wmsVersion = parseFloat(this.wmsParams.version));
        var t = this._wmsVersion >= 1.3 ? `crs` : `srs`;
        (this.wmsParams[t] = this._crs.code), Rr.prototype.onAdd.call(this, e);
      },
      getTileUrl: function (e) {
        var t = this._tileCoordsToNwSe(e),
          n = this._crs,
          r = w(n.project(t[0]), n.project(t[1])),
          i = r.min,
          a = r.max,
          o = (
            this._wmsVersion >= 1.3 && this._crs === Jn
              ? [i.y, i.x, a.y, a.x]
              : [i.x, i.y, a.x, a.y]
          ).join(`,`),
          s = Rr.prototype.getTileUrl.call(this, e);
        return (
          s +
          m(this.wmsParams, s, this.options.uppercase) +
          (this.options.uppercase ? `&BBOX=` : `&bbox=`) +
          o
        );
      },
      setParams: function (e, t) {
        return n(this.wmsParams, e), t || this.redraw(), this;
      },
    });
    function Vr(e, t) {
      return new Br(e, t);
    }
    (Rr.WMS = Br), (zr.wms = Vr);
    var $ = J.extend({
        options: { padding: 0.1 },
        initialize: function (e) {
          p(this, e), o(this), (this._layers = this._layers || {});
        },
        onAdd: function () {
          this._container ||
            (this._initContainer(),
            F(this._container, `leaflet-zoom-animated`)),
            this.getPane().appendChild(this._container),
            this._update(),
            this.on(`update`, this._updatePaths, this);
        },
        onRemove: function () {
          this.off(`update`, this._updatePaths, this), this._destroyContainer();
        },
        getEvents: function () {
          var e = {
            viewreset: this._reset,
            zoom: this._onZoom,
            moveend: this._update,
            zoomend: this._onZoomEnd,
          };
          return this._zoomAnimated && (e.zoomanim = this._onAnimZoom), e;
        },
        _onAnimZoom: function (e) {
          this._updateTransform(e.center, e.zoom);
        },
        _onZoom: function () {
          this._updateTransform(this._map.getCenter(), this._map.getZoom());
        },
        _updateTransform: function (e, t) {
          var n = this._map.getZoomScale(t, this._zoom),
            r = this._map.getSize().multiplyBy(0.5 + this.options.padding),
            i = this._map.project(this._center, t),
            a = r
              .multiplyBy(-n)
              .add(i)
              .subtract(this._map._getNewPixelOrigin(e, t));
          M.any3d ? It(this._container, a, n) : z(this._container, a);
        },
        _reset: function () {
          for (var e in (this._update(),
          this._updateTransform(this._center, this._zoom),
          this._layers))
            this._layers[e]._reset();
        },
        _onZoomEnd: function () {
          for (var e in this._layers) this._layers[e]._project();
        },
        _updatePaths: function () {
          for (var e in this._layers) this._layers[e]._update();
        },
        _update: function () {
          var e = this.options.padding,
            t = this._map.getSize(),
            n = this._map.containerPointToLayerPoint(t.multiplyBy(-e)).round();
          (this._bounds = new C(n, n.add(t.multiplyBy(1 + e * 2)).round())),
            (this._center = this._map.getCenter()),
            (this._zoom = this._map.getZoom());
        },
      }),
      Hr = $.extend({
        options: { tolerance: 0 },
        getEvents: function () {
          var e = $.prototype.getEvents.call(this);
          return (e.viewprereset = this._onViewPreReset), e;
        },
        _onViewPreReset: function () {
          this._postponeUpdatePaths = !0;
        },
        onAdd: function () {
          $.prototype.onAdd.call(this), this._draw();
        },
        _initContainer: function () {
          var e = (this._container = document.createElement(`canvas`));
          B(e, `mousemove`, this._onMouseMove, this),
            B(
              e,
              `click dblclick mousedown mouseup contextmenu`,
              this._onClick,
              this
            ),
            B(e, `mouseout`, this._handleMouseOut, this),
            (e._leaflet_disable_events = !0),
            (this._ctx = e.getContext(`2d`));
        },
        _destroyContainer: function () {
          v(this._redrawRequest),
            delete this._ctx,
            P(this._container),
            H(this._container),
            delete this._container;
        },
        _updatePaths: function () {
          if (!this._postponeUpdatePaths) {
            var e;
            for (var t in ((this._redrawBounds = null), this._layers))
              (e = this._layers[t]), e._update();
            this._redraw();
          }
        },
        _update: function () {
          if (!(this._map._animatingZoom && this._bounds)) {
            $.prototype._update.call(this);
            var e = this._bounds,
              t = this._container,
              n = e.getSize(),
              r = M.retina ? 2 : 1;
            z(t, e.min),
              (t.width = r * n.x),
              (t.height = r * n.y),
              (t.style.width = n.x + `px`),
              (t.style.height = n.y + `px`),
              M.retina && this._ctx.scale(2, 2),
              this._ctx.translate(-e.min.x, -e.min.y),
              this.fire(`update`);
          }
        },
        _reset: function () {
          $.prototype._reset.call(this),
            this._postponeUpdatePaths &&
              ((this._postponeUpdatePaths = !1), this._updatePaths());
        },
        _initPath: function (e) {
          this._updateDashArray(e), (this._layers[o(e)] = e);
          var t = (e._order = { layer: e, prev: this._drawLast, next: null });
          this._drawLast && (this._drawLast.next = t),
            (this._drawLast = t),
            (this._drawFirst = this._drawFirst || this._drawLast);
        },
        _addPath: function (e) {
          this._requestRedraw(e);
        },
        _removePath: function (e) {
          var t = e._order,
            n = t.next,
            r = t.prev;
          n ? (n.prev = r) : (this._drawLast = r),
            r ? (r.next = n) : (this._drawFirst = n),
            delete e._order,
            delete this._layers[o(e)],
            this._requestRedraw(e);
        },
        _updatePath: function (e) {
          this._extendRedrawBounds(e),
            e._project(),
            e._update(),
            this._requestRedraw(e);
        },
        _updateStyle: function (e) {
          this._updateDashArray(e), this._requestRedraw(e);
        },
        _updateDashArray: function (e) {
          if (typeof e.options.dashArray == `string`) {
            for (
              var t = e.options.dashArray.split(/[, ]+/), n = [], r, i = 0;
              i < t.length;
              i++
            ) {
              if (((r = Number(t[i])), isNaN(r))) return;
              n.push(r);
            }
            e.options._dashArray = n;
          } else e.options._dashArray = e.options.dashArray;
        },
        _requestRedraw: function (e) {
          this._map &&
            (this._extendRedrawBounds(e),
            (this._redrawRequest =
              this._redrawRequest || _(this._redraw, this)));
        },
        _extendRedrawBounds: function (e) {
          if (e._pxBounds) {
            var t = (e.options.weight || 0) + 1;
            (this._redrawBounds = this._redrawBounds || new C()),
              this._redrawBounds.extend(e._pxBounds.min.subtract([t, t])),
              this._redrawBounds.extend(e._pxBounds.max.add([t, t]));
          }
        },
        _redraw: function () {
          (this._redrawRequest = null),
            this._redrawBounds &&
              (this._redrawBounds.min._floor(), this._redrawBounds.max._ceil()),
            this._clear(),
            this._draw(),
            (this._redrawBounds = null);
        },
        _clear: function () {
          var e = this._redrawBounds;
          if (e) {
            var t = e.getSize();
            this._ctx.clearRect(e.min.x, e.min.y, t.x, t.y);
          } else
            this._ctx.save(),
              this._ctx.setTransform(1, 0, 0, 1, 0, 0),
              this._ctx.clearRect(
                0,
                0,
                this._container.width,
                this._container.height
              ),
              this._ctx.restore();
        },
        _draw: function () {
          var e,
            t = this._redrawBounds;
          if ((this._ctx.save(), t)) {
            var n = t.getSize();
            this._ctx.beginPath(),
              this._ctx.rect(t.min.x, t.min.y, n.x, n.y),
              this._ctx.clip();
          }
          this._drawing = !0;
          for (var r = this._drawFirst; r; r = r.next)
            (e = r.layer),
              (!t || (e._pxBounds && e._pxBounds.intersects(t))) &&
                e._updatePath();
          (this._drawing = !1), this._ctx.restore();
        },
        _updatePoly: function (e, t) {
          if (this._drawing) {
            var n,
              r,
              i,
              a,
              o = e._parts,
              s = o.length,
              c = this._ctx;
            if (s) {
              for (c.beginPath(), n = 0; n < s; n++) {
                for (r = 0, i = o[n].length; r < i; r++)
                  (a = o[n][r]), c[r ? `lineTo` : `moveTo`](a.x, a.y);
                t && c.closePath();
              }
              this._fillStroke(c, e);
            }
          }
        },
        _updateCircle: function (e) {
          if (this._drawing && !e._empty()) {
            var t = e._point,
              n = this._ctx,
              r = Math.max(Math.round(e._radius), 1),
              i = (Math.max(Math.round(e._radiusY), 1) || r) / r;
            i !== 1 && (n.save(), n.scale(1, i)),
              n.beginPath(),
              n.arc(t.x, t.y / i, r, 0, Math.PI * 2, !1),
              i !== 1 && n.restore(),
              this._fillStroke(n, e);
          }
        },
        _fillStroke: function (e, t) {
          var n = t.options;
          n.fill &&
            ((e.globalAlpha = n.fillOpacity),
            (e.fillStyle = n.fillColor || n.color),
            e.fill(n.fillRule || `evenodd`)),
            n.stroke &&
              n.weight !== 0 &&
              (e.setLineDash &&
                e.setLineDash((t.options && t.options._dashArray) || []),
              (e.globalAlpha = n.opacity),
              (e.lineWidth = n.weight),
              (e.strokeStyle = n.color),
              (e.lineCap = n.lineCap),
              (e.lineJoin = n.lineJoin),
              e.stroke());
        },
        _onClick: function (e) {
          for (
            var t = this._map.mouseEventToLayerPoint(e),
              n,
              r,
              i = this._drawFirst;
            i;
            i = i.next
          )
            (n = i.layer),
              n.options.interactive &&
                n._containsPoint(t) &&
                ((e.type !== `click` && e.type !== `preclick`) ||
                  !this._map._draggableMoved(n)) &&
                (r = n);
          this._fireEvent(r ? [r] : !1, e);
        },
        _onMouseMove: function (e) {
          if (
            !(
              !this._map ||
              this._map.dragging.moving() ||
              this._map._animatingZoom
            )
          ) {
            var t = this._map.mouseEventToLayerPoint(e);
            this._handleMouseHover(e, t);
          }
        },
        _handleMouseOut: function (e) {
          var t = this._hoveredLayer;
          t &&
            (I(this._container, `leaflet-interactive`),
            this._fireEvent([t], e, `mouseout`),
            (this._hoveredLayer = null),
            (this._mouseHoverThrottled = !1));
        },
        _handleMouseHover: function (e, t) {
          if (!this._mouseHoverThrottled) {
            for (var n, r, a = this._drawFirst; a; a = a.next)
              (n = a.layer),
                n.options.interactive && n._containsPoint(t) && (r = n);
            r !== this._hoveredLayer &&
              (this._handleMouseOut(e),
              r &&
                (F(this._container, `leaflet-interactive`),
                this._fireEvent([r], e, `mouseover`),
                (this._hoveredLayer = r))),
              this._fireEvent(
                this._hoveredLayer ? [this._hoveredLayer] : !1,
                e
              ),
              (this._mouseHoverThrottled = !0),
              setTimeout(
                i(function () {
                  this._mouseHoverThrottled = !1;
                }, this),
                32
              );
          }
        },
        _fireEvent: function (e, t, n) {
          this._map._fireDOMEvent(t, n || t.type, e);
        },
        _bringToFront: function (e) {
          var t = e._order;
          if (t) {
            var n = t.next,
              r = t.prev;
            if (n) n.prev = r;
            else return;
            r ? (r.next = n) : n && (this._drawFirst = n),
              (t.prev = this._drawLast),
              (this._drawLast.next = t),
              (t.next = null),
              (this._drawLast = t),
              this._requestRedraw(e);
          }
        },
        _bringToBack: function (e) {
          var t = e._order;
          if (t) {
            var n = t.next,
              r = t.prev;
            if (r) r.next = n;
            else return;
            n ? (n.prev = r) : r && (this._drawLast = r),
              (t.prev = null),
              (t.next = this._drawFirst),
              (this._drawFirst.prev = t),
              (this._drawFirst = t),
              this._requestRedraw(e);
          }
        },
      });
    function Ur(e) {
      return M.canvas ? new Hr(e) : null;
    }
    var Wr = (function () {
        try {
          return (
            document.namespaces.add(`lvml`, `urn:schemas-microsoft-com:vml`),
            function (e) {
              return document.createElement(`<lvml:` + e + ` class="lvml">`);
            }
          );
        } catch {}
        return function (e) {
          return document.createElement(
            `<` + e + ` xmlns="urn:schemas-microsoft.com:vml" class="lvml">`
          );
        };
      })(),
      Gr = {
        _initContainer: function () {
          this._container = N(`div`, `leaflet-vml-container`);
        },
        _update: function () {
          this._map._animatingZoom ||
            ($.prototype._update.call(this), this.fire(`update`));
        },
        _initPath: function (e) {
          var t = (e._container = Wr(`shape`));
          F(t, `leaflet-vml-shape ` + (this.options.className || ``)),
            (t.coordsize = `1 1`),
            (e._path = Wr(`path`)),
            t.appendChild(e._path),
            this._updateStyle(e),
            (this._layers[o(e)] = e);
        },
        _addPath: function (e) {
          var t = e._container;
          this._container.appendChild(t),
            e.options.interactive && e.addInteractiveTarget(t);
        },
        _removePath: function (e) {
          var t = e._container;
          P(t), e.removeInteractiveTarget(t), delete this._layers[o(e)];
        },
        _updateStyle: function (e) {
          var t = e._stroke,
            n = e._fill,
            r = e.options,
            i = e._container;
          (i.stroked = !!r.stroke),
            (i.filled = !!r.fill),
            r.stroke
              ? ((t ||= e._stroke = Wr(`stroke`)),
                i.appendChild(t),
                (t.weight = r.weight + `px`),
                (t.color = r.color),
                (t.opacity = r.opacity),
                r.dashArray
                  ? (t.dashStyle = g(r.dashArray)
                      ? r.dashArray.join(` `)
                      : r.dashArray.replace(/( *, *)/g, ` `))
                  : (t.dashStyle = ``),
                (t.endcap = r.lineCap.replace(`butt`, `flat`)),
                (t.joinstyle = r.lineJoin))
              : t && (i.removeChild(t), (e._stroke = null)),
            r.fill
              ? ((n ||= e._fill = Wr(`fill`)),
                i.appendChild(n),
                (n.color = r.fillColor || r.color),
                (n.opacity = r.fillOpacity))
              : n && (i.removeChild(n), (e._fill = null));
        },
        _updateCircle: function (e) {
          var t = e._point.round(),
            n = Math.round(e._radius),
            r = Math.round(e._radiusY || n);
          this._setPath(
            e,
            e._empty()
              ? `M0 0`
              : `AL ` + t.x + `,` + t.y + ` ` + n + `,` + r + ` 0,23592600`
          );
        },
        _setPath: function (e, t) {
          e._path.v = t;
        },
        _bringToFront: function (e) {
          kt(e._container);
        },
        _bringToBack: function (e) {
          At(e._container);
        },
      },
      Kr = M.vml ? Wr : ve,
      qr = $.extend({
        _initContainer: function () {
          (this._container = Kr(`svg`)),
            this._container.setAttribute(`pointer-events`, `none`),
            (this._rootGroup = Kr(`g`)),
            this._container.appendChild(this._rootGroup);
        },
        _destroyContainer: function () {
          P(this._container),
            H(this._container),
            delete this._container,
            delete this._rootGroup,
            delete this._svgSize;
        },
        _update: function () {
          if (!(this._map._animatingZoom && this._bounds)) {
            $.prototype._update.call(this);
            var e = this._bounds,
              t = e.getSize(),
              n = this._container;
            (this._svgSize && this._svgSize.equals(t)) ||
              ((this._svgSize = t),
              n.setAttribute(`width`, t.x),
              n.setAttribute(`height`, t.y)),
              z(n, e.min),
              n.setAttribute(`viewBox`, [e.min.x, e.min.y, t.x, t.y].join(` `)),
              this.fire(`update`);
          }
        },
        _initPath: function (e) {
          var t = (e._path = Kr(`path`));
          e.options.className && F(t, e.options.className),
            e.options.interactive && F(t, `leaflet-interactive`),
            this._updateStyle(e),
            (this._layers[o(e)] = e);
        },
        _addPath: function (e) {
          this._rootGroup || this._initContainer(),
            this._rootGroup.appendChild(e._path),
            e.addInteractiveTarget(e._path);
        },
        _removePath: function (e) {
          P(e._path),
            e.removeInteractiveTarget(e._path),
            delete this._layers[o(e)];
        },
        _updatePath: function (e) {
          e._project(), e._update();
        },
        _updateStyle: function (e) {
          var t = e._path,
            n = e.options;
          t &&
            (n.stroke
              ? (t.setAttribute(`stroke`, n.color),
                t.setAttribute(`stroke-opacity`, n.opacity),
                t.setAttribute(`stroke-width`, n.weight),
                t.setAttribute(`stroke-linecap`, n.lineCap),
                t.setAttribute(`stroke-linejoin`, n.lineJoin),
                n.dashArray
                  ? t.setAttribute(`stroke-dasharray`, n.dashArray)
                  : t.removeAttribute(`stroke-dasharray`),
                n.dashOffset
                  ? t.setAttribute(`stroke-dashoffset`, n.dashOffset)
                  : t.removeAttribute(`stroke-dashoffset`))
              : t.setAttribute(`stroke`, `none`),
            n.fill
              ? (t.setAttribute(`fill`, n.fillColor || n.color),
                t.setAttribute(`fill-opacity`, n.fillOpacity),
                t.setAttribute(`fill-rule`, n.fillRule || `evenodd`))
              : t.setAttribute(`fill`, `none`));
        },
        _updatePoly: function (e, t) {
          this._setPath(e, ye(e._parts, t));
        },
        _updateCircle: function (e) {
          var t = e._point,
            n = Math.max(Math.round(e._radius), 1),
            r = Math.max(Math.round(e._radiusY), 1) || n,
            i = `a` + n + `,` + r + ` 0 1,0 `,
            a = e._empty()
              ? `M0 0`
              : `M` +
                (t.x - n) +
                `,` +
                t.y +
                i +
                n * 2 +
                `,0 ` +
                i +
                -n * 2 +
                `,0 `;
          this._setPath(e, a);
        },
        _setPath: function (e, t) {
          e._path.setAttribute(`d`, t);
        },
        _bringToFront: function (e) {
          kt(e._path);
        },
        _bringToBack: function (e) {
          At(e._path);
        },
      });
    M.vml && qr.include(Gr);
    function Jr(e) {
      return M.svg || M.vml ? new qr(e) : null;
    }
    W.include({
      getRenderer: function (e) {
        var t =
          e.options.renderer ||
          this._getPaneRenderer(e.options.pane) ||
          this.options.renderer ||
          this._renderer;
        return (
          (t ||= this._renderer = this._createRenderer()),
          this.hasLayer(t) || this.addLayer(t),
          t
        );
      },
      _getPaneRenderer: function (e) {
        if (e === `overlayPane` || e === void 0) return !1;
        var t = this._paneRenderers[e];
        return (
          t === void 0 &&
            ((t = this._createRenderer({ pane: e })),
            (this._paneRenderers[e] = t)),
          t
        );
      },
      _createRenderer: function (e) {
        return (this.options.preferCanvas && Ur(e)) || Jr(e);
      },
    });
    var Yr = dr.extend({
      initialize: function (e, t) {
        dr.prototype.initialize.call(this, this._boundsToLatLngs(e), t);
      },
      setBounds: function (e) {
        return this.setLatLngs(this._boundsToLatLngs(e));
      },
      _boundsToLatLngs: function (e) {
        return (
          (e = E(e)),
          [
            e.getSouthWest(),
            e.getNorthWest(),
            e.getNorthEast(),
            e.getSouthEast(),
          ]
        );
      },
    });
    function Xr(e, t) {
      return new Yr(e, t);
    }
    (qr.create = Kr),
      (qr.pointsToPath = ye),
      (Z.geometryToLayer = pr),
      (Z.coordsToLatLng = hr),
      (Z.coordsToLatLngs = gr),
      (Z.latLngToCoords = _r),
      (Z.latLngsToCoords = vr),
      (Z.getFeature = yr),
      (Z.asFeature = br),
      W.mergeOptions({ boxZoom: !0 });
    var Zr = K.extend({
      initialize: function (e) {
        (this._map = e),
          (this._container = e._container),
          (this._pane = e._panes.overlayPane),
          (this._resetStateTimeout = 0),
          e.on(`unload`, this._destroy, this);
      },
      addHooks: function () {
        B(this._container, `mousedown`, this._onMouseDown, this);
      },
      removeHooks: function () {
        H(this._container, `mousedown`, this._onMouseDown, this);
      },
      moved: function () {
        return this._moved;
      },
      _destroy: function () {
        P(this._pane), delete this._pane;
      },
      _resetState: function () {
        (this._resetStateTimeout = 0), (this._moved = !1);
      },
      _clearDeferredResetState: function () {
        this._resetStateTimeout !== 0 &&
          (clearTimeout(this._resetStateTimeout),
          (this._resetStateTimeout = 0));
      },
      _onMouseDown: function (e) {
        if (!e.shiftKey || (e.which !== 1 && e.button !== 1)) return !1;
        this._clearDeferredResetState(),
          this._resetState(),
          Rt(),
          Ht(),
          (this._startPoint = this._map.mouseEventToContainerPoint(e)),
          B(
            document,
            {
              contextmenu: an,
              mousemove: this._onMouseMove,
              mouseup: this._onMouseUp,
              keydown: this._onKeyDown,
            },
            this
          );
      },
      _onMouseMove: function (e) {
        this._moved ||
          ((this._moved = !0),
          (this._box = N(`div`, `leaflet-zoom-box`, this._container)),
          F(this._container, `leaflet-crosshair`),
          this._map.fire(`boxzoomstart`)),
          (this._point = this._map.mouseEventToContainerPoint(e));
        var t = new C(this._point, this._startPoint),
          n = t.getSize();
        z(this._box, t.min),
          (this._box.style.width = n.x + `px`),
          (this._box.style.height = n.y + `px`);
      },
      _finish: function () {
        this._moved && (P(this._box), I(this._container, `leaflet-crosshair`)),
          zt(),
          Ut(),
          H(
            document,
            {
              contextmenu: an,
              mousemove: this._onMouseMove,
              mouseup: this._onMouseUp,
              keydown: this._onKeyDown,
            },
            this
          );
      },
      _onMouseUp: function (e) {
        if (
          (e.which === 1 || e.button === 1) &&
          (this._finish(), this._moved)
        ) {
          this._clearDeferredResetState(),
            (this._resetStateTimeout = setTimeout(
              i(this._resetState, this),
              0
            ));
          var t = new T(
            this._map.containerPointToLatLng(this._startPoint),
            this._map.containerPointToLatLng(this._point)
          );
          this._map.fitBounds(t).fire(`boxzoomend`, { boxZoomBounds: t });
        }
      },
      _onKeyDown: function (e) {
        e.keyCode === 27 &&
          (this._finish(), this._clearDeferredResetState(), this._resetState());
      },
    });
    W.addInitHook(`addHandler`, `boxZoom`, Zr),
      W.mergeOptions({ doubleClickZoom: !0 });
    var Qr = K.extend({
      addHooks: function () {
        this._map.on(`dblclick`, this._onDoubleClick, this);
      },
      removeHooks: function () {
        this._map.off(`dblclick`, this._onDoubleClick, this);
      },
      _onDoubleClick: function (e) {
        var t = this._map,
          n = t.getZoom(),
          r = t.options.zoomDelta,
          i = e.originalEvent.shiftKey ? n - r : n + r;
        t.options.doubleClickZoom === `center`
          ? t.setZoom(i)
          : t.setZoomAround(e.containerPoint, i);
      },
    });
    W.addInitHook(`addHandler`, `doubleClickZoom`, Qr),
      W.mergeOptions({
        dragging: !0,
        inertia: !0,
        inertiaDeceleration: 3400,
        inertiaMaxSpeed: 1 / 0,
        easeLinearity: 0.2,
        worldCopyJump: !1,
        maxBoundsViscosity: 0,
      });
    var $r = K.extend({
      addHooks: function () {
        if (!this._draggable) {
          var e = this._map;
          (this._draggable = new wn(e._mapPane, e._container)),
            this._draggable.on(
              {
                dragstart: this._onDragStart,
                drag: this._onDrag,
                dragend: this._onDragEnd,
              },
              this
            ),
            this._draggable.on(`predrag`, this._onPreDragLimit, this),
            e.options.worldCopyJump &&
              (this._draggable.on(`predrag`, this._onPreDragWrap, this),
              e.on(`zoomend`, this._onZoomEnd, this),
              e.whenReady(this._onZoomEnd, this));
        }
        F(this._map._container, `leaflet-grab leaflet-touch-drag`),
          this._draggable.enable(),
          (this._positions = []),
          (this._times = []);
      },
      removeHooks: function () {
        I(this._map._container, `leaflet-grab`),
          I(this._map._container, `leaflet-touch-drag`),
          this._draggable.disable();
      },
      moved: function () {
        return this._draggable && this._draggable._moved;
      },
      moving: function () {
        return this._draggable && this._draggable._moving;
      },
      _onDragStart: function () {
        var e = this._map;
        if (
          (e._stop(),
          this._map.options.maxBounds && this._map.options.maxBoundsViscosity)
        ) {
          var t = E(this._map.options.maxBounds);
          (this._offsetLimit = w(
            this._map.latLngToContainerPoint(t.getNorthWest()).multiplyBy(-1),
            this._map
              .latLngToContainerPoint(t.getSouthEast())
              .multiplyBy(-1)
              .add(this._map.getSize())
          )),
            (this._viscosity = Math.min(
              1,
              Math.max(0, this._map.options.maxBoundsViscosity)
            ));
        } else this._offsetLimit = null;
        e.fire(`movestart`).fire(`dragstart`),
          e.options.inertia && ((this._positions = []), (this._times = []));
      },
      _onDrag: function (e) {
        if (this._map.options.inertia) {
          var t = (this._lastTime = +new Date()),
            n = (this._lastPos =
              this._draggable._absPos || this._draggable._newPos);
          this._positions.push(n), this._times.push(t), this._prunePositions(t);
        }
        this._map.fire(`move`, e).fire(`drag`, e);
      },
      _prunePositions: function (e) {
        for (; this._positions.length > 1 && e - this._times[0] > 50; )
          this._positions.shift(), this._times.shift();
      },
      _onZoomEnd: function () {
        var e = this._map.getSize().divideBy(2),
          t = this._map.latLngToLayerPoint([0, 0]);
        (this._initialWorldOffset = t.subtract(e).x),
          (this._worldWidth = this._map.getPixelWorldBounds().getSize().x);
      },
      _viscousLimit: function (e, t) {
        return e - (e - t) * this._viscosity;
      },
      _onPreDragLimit: function () {
        if (this._viscosity && this._offsetLimit) {
          var e = this._draggable._newPos.subtract(this._draggable._startPos),
            t = this._offsetLimit;
          e.x < t.min.x && (e.x = this._viscousLimit(e.x, t.min.x)),
            e.y < t.min.y && (e.y = this._viscousLimit(e.y, t.min.y)),
            e.x > t.max.x && (e.x = this._viscousLimit(e.x, t.max.x)),
            e.y > t.max.y && (e.y = this._viscousLimit(e.y, t.max.y)),
            (this._draggable._newPos = this._draggable._startPos.add(e));
        }
      },
      _onPreDragWrap: function () {
        var e = this._worldWidth,
          t = Math.round(e / 2),
          n = this._initialWorldOffset,
          r = this._draggable._newPos.x,
          i = ((r - t + n) % e) + t - n,
          a = ((r + t + n) % e) - t - n,
          o = Math.abs(i + n) < Math.abs(a + n) ? i : a;
        (this._draggable._absPos = this._draggable._newPos.clone()),
          (this._draggable._newPos.x = o);
      },
      _onDragEnd: function (e) {
        var t = this._map,
          n = t.options,
          r = !n.inertia || e.noInertia || this._times.length < 2;
        if ((t.fire(`dragend`, e), r)) t.fire(`moveend`);
        else {
          this._prunePositions(+new Date());
          var i = this._lastPos.subtract(this._positions[0]),
            a = (this._lastTime - this._times[0]) / 1e3,
            o = n.easeLinearity,
            s = i.multiplyBy(o / a),
            c = s.distanceTo([0, 0]),
            l = Math.min(n.inertiaMaxSpeed, c),
            u = s.multiplyBy(l / c),
            d = l / (n.inertiaDeceleration * o),
            f = u.multiplyBy(-d / 2).round();
          !f.x && !f.y
            ? t.fire(`moveend`)
            : ((f = t._limitOffset(f, t.options.maxBounds)),
              _(function () {
                t.panBy(f, {
                  duration: d,
                  easeLinearity: o,
                  noMoveStart: !0,
                  animate: !0,
                });
              }));
        }
      },
    });
    W.addInitHook(`addHandler`, `dragging`, $r),
      W.mergeOptions({ keyboard: !0, keyboardPanDelta: 80 });
    var ei = K.extend({
      keyCodes: {
        left: [37],
        right: [39],
        down: [40],
        up: [38],
        zoomIn: [187, 107, 61, 171],
        zoomOut: [189, 109, 54, 173],
      },
      initialize: function (e) {
        (this._map = e),
          this._setPanDelta(e.options.keyboardPanDelta),
          this._setZoomDelta(e.options.zoomDelta);
      },
      addHooks: function () {
        var e = this._map._container;
        e.tabIndex <= 0 && (e.tabIndex = `0`),
          B(
            e,
            {
              focus: this._onFocus,
              blur: this._onBlur,
              mousedown: this._onMouseDown,
            },
            this
          ),
          this._map.on(
            { focus: this._addHooks, blur: this._removeHooks },
            this
          );
      },
      removeHooks: function () {
        this._removeHooks(),
          H(
            this._map._container,
            {
              focus: this._onFocus,
              blur: this._onBlur,
              mousedown: this._onMouseDown,
            },
            this
          ),
          this._map.off(
            { focus: this._addHooks, blur: this._removeHooks },
            this
          );
      },
      _onMouseDown: function () {
        if (!this._focused) {
          var e = document.body,
            t = document.documentElement,
            n = e.scrollTop || t.scrollTop,
            r = e.scrollLeft || t.scrollLeft;
          this._map._container.focus(), window.scrollTo(r, n);
        }
      },
      _onFocus: function () {
        (this._focused = !0), this._map.fire(`focus`);
      },
      _onBlur: function () {
        (this._focused = !1), this._map.fire(`blur`);
      },
      _setPanDelta: function (e) {
        for (
          var t = (this._panKeys = {}),
            n = this.keyCodes,
            r = 0,
            i = n.left.length;
          r < i;
          r++
        )
          t[n.left[r]] = [-1 * e, 0];
        for (r = 0, i = n.right.length; r < i; r++) t[n.right[r]] = [e, 0];
        for (r = 0, i = n.down.length; r < i; r++) t[n.down[r]] = [0, e];
        for (r = 0, i = n.up.length; r < i; r++) t[n.up[r]] = [0, -1 * e];
      },
      _setZoomDelta: function (e) {
        for (
          var t = (this._zoomKeys = {}),
            n = this.keyCodes,
            r = 0,
            i = n.zoomIn.length;
          r < i;
          r++
        )
          t[n.zoomIn[r]] = e;
        for (r = 0, i = n.zoomOut.length; r < i; r++) t[n.zoomOut[r]] = -e;
      },
      _addHooks: function () {
        B(document, `keydown`, this._onKeyDown, this);
      },
      _removeHooks: function () {
        H(document, `keydown`, this._onKeyDown, this);
      },
      _onKeyDown: function (e) {
        if (!(e.altKey || e.ctrlKey || e.metaKey)) {
          var t = e.keyCode,
            n = this._map,
            r;
          if (t in this._panKeys) {
            if (!n._panAnim || !n._panAnim._inProgress) {
              if (
                ((r = this._panKeys[t]),
                e.shiftKey && (r = S(r).multiplyBy(3)),
                n.options.maxBounds &&
                  (r = n._limitOffset(S(r), n.options.maxBounds)),
                n.options.worldCopyJump)
              ) {
                var i = n.wrapLatLng(
                  n.unproject(n.project(n.getCenter()).add(r))
                );
                n.panTo(i);
              } else n.panBy(r);
            }
          } else if (t in this._zoomKeys)
            n.setZoom(n.getZoom() + (e.shiftKey ? 3 : 1) * this._zoomKeys[t]);
          else if (t === 27 && n._popup && n._popup.options.closeOnEscapeKey)
            n.closePopup();
          else return;
          an(e);
        }
      },
    });
    W.addInitHook(`addHandler`, `keyboard`, ei),
      W.mergeOptions({
        scrollWheelZoom: !0,
        wheelDebounceTime: 40,
        wheelPxPerZoomLevel: 60,
      });
    var ti = K.extend({
      addHooks: function () {
        B(this._map._container, `wheel`, this._onWheelScroll, this),
          (this._delta = 0);
      },
      removeHooks: function () {
        H(this._map._container, `wheel`, this._onWheelScroll, this);
      },
      _onWheelScroll: function (e) {
        var t = ln(e),
          n = this._map.options.wheelDebounceTime;
        (this._delta += t),
          (this._lastMousePos = this._map.mouseEventToContainerPoint(e)),
          (this._startTime ||= +new Date());
        var r = Math.max(n - (+new Date() - this._startTime), 0);
        clearTimeout(this._timer),
          (this._timer = setTimeout(i(this._performZoom, this), r)),
          an(e);
      },
      _performZoom: function () {
        var e = this._map,
          t = e.getZoom(),
          n = this._map.options.zoomSnap || 0;
        e._stop();
        var r = this._delta / (this._map.options.wheelPxPerZoomLevel * 4),
          i = (4 * Math.log(2 / (1 + Math.exp(-Math.abs(r))))) / Math.LN2,
          a = n ? Math.ceil(i / n) * n : i,
          o = e._limitZoom(t + (this._delta > 0 ? a : -a)) - t;
        (this._delta = 0),
          (this._startTime = null),
          o &&
            (e.options.scrollWheelZoom === `center`
              ? e.setZoom(t + o)
              : e.setZoomAround(this._lastMousePos, t + o));
      },
    });
    W.addInitHook(`addHandler`, `scrollWheelZoom`, ti);
    var ni = 600;
    W.mergeOptions({
      tapHold: M.touchNative && M.safari && M.mobile,
      tapTolerance: 15,
    });
    var ri = K.extend({
      addHooks: function () {
        B(this._map._container, `touchstart`, this._onDown, this);
      },
      removeHooks: function () {
        H(this._map._container, `touchstart`, this._onDown, this);
      },
      _onDown: function (e) {
        if ((clearTimeout(this._holdTimeout), e.touches.length === 1)) {
          var t = e.touches[0];
          (this._startPos = this._newPos = new x(t.clientX, t.clientY)),
            (this._holdTimeout = setTimeout(
              i(function () {
                this._cancel(),
                  this._isTapValid() &&
                    (B(document, `touchend`, U),
                    B(
                      document,
                      `touchend touchcancel`,
                      this._cancelClickPrevent
                    ),
                    this._simulateEvent(`contextmenu`, t));
              }, this),
              ni
            )),
            B(document, `touchend touchcancel contextmenu`, this._cancel, this),
            B(document, `touchmove`, this._onMove, this);
        }
      },
      _cancelClickPrevent: function e() {
        H(document, `touchend`, U), H(document, `touchend touchcancel`, e);
      },
      _cancel: function () {
        clearTimeout(this._holdTimeout),
          H(document, `touchend touchcancel contextmenu`, this._cancel, this),
          H(document, `touchmove`, this._onMove, this);
      },
      _onMove: function (e) {
        var t = e.touches[0];
        this._newPos = new x(t.clientX, t.clientY);
      },
      _isTapValid: function () {
        return (
          this._newPos.distanceTo(this._startPos) <=
          this._map.options.tapTolerance
        );
      },
      _simulateEvent: function (e, t) {
        var n = new MouseEvent(e, {
          bubbles: !0,
          cancelable: !0,
          view: window,
          screenX: t.screenX,
          screenY: t.screenY,
          clientX: t.clientX,
          clientY: t.clientY,
        });
        (n._simulated = !0), t.target.dispatchEvent(n);
      },
    });
    W.addInitHook(`addHandler`, `tapHold`, ri),
      W.mergeOptions({ touchZoom: M.touch, bounceAtZoomLimits: !0 });
    var ii = K.extend({
      addHooks: function () {
        F(this._map._container, `leaflet-touch-zoom`),
          B(this._map._container, `touchstart`, this._onTouchStart, this);
      },
      removeHooks: function () {
        I(this._map._container, `leaflet-touch-zoom`),
          H(this._map._container, `touchstart`, this._onTouchStart, this);
      },
      _onTouchStart: function (e) {
        var t = this._map;
        if (
          !(
            !e.touches ||
            e.touches.length !== 2 ||
            t._animatingZoom ||
            this._zooming
          )
        ) {
          var n = t.mouseEventToContainerPoint(e.touches[0]),
            r = t.mouseEventToContainerPoint(e.touches[1]);
          (this._centerPoint = t.getSize()._divideBy(2)),
            (this._startLatLng = t.containerPointToLatLng(this._centerPoint)),
            t.options.touchZoom !== `center` &&
              (this._pinchStartLatLng = t.containerPointToLatLng(
                n.add(r)._divideBy(2)
              )),
            (this._startDist = n.distanceTo(r)),
            (this._startZoom = t.getZoom()),
            (this._moved = !1),
            (this._zooming = !0),
            t._stop(),
            B(document, `touchmove`, this._onTouchMove, this),
            B(document, `touchend touchcancel`, this._onTouchEnd, this),
            U(e);
        }
      },
      _onTouchMove: function (e) {
        if (e.touches && e.touches.length === 2 && this._zooming) {
          var t = this._map,
            n = t.mouseEventToContainerPoint(e.touches[0]),
            r = t.mouseEventToContainerPoint(e.touches[1]),
            a = n.distanceTo(r) / this._startDist;
          if (
            ((this._zoom = t.getScaleZoom(a, this._startZoom)),
            !t.options.bounceAtZoomLimits &&
              ((this._zoom < t.getMinZoom() && a < 1) ||
                (this._zoom > t.getMaxZoom() && a > 1)) &&
              (this._zoom = t._limitZoom(this._zoom)),
            t.options.touchZoom === `center`)
          ) {
            if (((this._center = this._startLatLng), a === 1)) return;
          } else {
            var o = n._add(r)._divideBy(2)._subtract(this._centerPoint);
            if (a === 1 && o.x === 0 && o.y === 0) return;
            this._center = t.unproject(
              t.project(this._pinchStartLatLng, this._zoom).subtract(o),
              this._zoom
            );
          }
          (this._moved ||= (t._moveStart(!0, !1), !0)), v(this._animRequest);
          var s = i(
            t._move,
            t,
            this._center,
            this._zoom,
            { pinch: !0, round: !1 },
            void 0
          );
          (this._animRequest = _(s, this, !0)), U(e);
        }
      },
      _onTouchEnd: function () {
        !this._moved || !this._zooming
          ? (this._zooming = !1)
          : ((this._zooming = !1),
            v(this._animRequest),
            H(document, `touchmove`, this._onTouchMove, this),
            H(document, `touchend touchcancel`, this._onTouchEnd, this),
            this._map.options.zoomAnimation
              ? this._map._animateZoom(
                  this._center,
                  this._map._limitZoom(this._zoom),
                  !0,
                  this._map.options.zoomSnap
                )
              : this._map._resetView(
                  this._center,
                  this._map._limitZoom(this._zoom)
                ));
      },
    });
    W.addInitHook(`addHandler`, `touchZoom`, ii),
      (W.BoxZoom = Zr),
      (W.DoubleClickZoom = Qr),
      (W.Drag = $r),
      (W.Keyboard = ei),
      (W.ScrollWheelZoom = ti),
      (W.TapHold = ri),
      (W.TouchZoom = ii),
      (e.Bounds = C),
      (e.Browser = M),
      (e.CRS = k),
      (e.Canvas = Hr),
      (e.Circle = cr),
      (e.CircleMarker = or),
      (e.Class = y),
      (e.Control = G),
      (e.DivIcon = Pr),
      (e.DivOverlay = Q),
      (e.DomEvent = dn),
      (e.DomUtil = Xt),
      (e.Draggable = wn),
      (e.Evented = ue),
      (e.FeatureGroup = Y),
      (e.GeoJSON = Z),
      (e.GridLayer = Ir),
      (e.Handler = K),
      (e.Icon = $n),
      (e.ImageOverlay = wr),
      (e.LatLng = D),
      (e.LatLngBounds = T),
      (e.Layer = J),
      (e.LayerGroup = Xn),
      (e.LineUtil = Un),
      (e.Map = W),
      (e.Marker = rr),
      (e.Mixin = Sn),
      (e.Path = ar),
      (e.Point = x),
      (e.PolyUtil = On),
      (e.Polygon = dr),
      (e.Polyline = X),
      (e.Popup = Ar),
      (e.PosAnimation = fn),
      (e.Projection = Kn),
      (e.Rectangle = Yr),
      (e.Renderer = $),
      (e.SVG = qr),
      (e.SVGOverlay = Or),
      (e.TileLayer = Rr),
      (e.Tooltip = Mr),
      (e.Transformation = me),
      (e.Util = ce),
      (e.VideoOverlay = Er),
      (e.bind = i),
      (e.bounds = w),
      (e.canvas = Ur),
      (e.circle = lr),
      (e.circleMarker = sr),
      (e.control = mn),
      (e.divIcon = Fr),
      (e.extend = n),
      (e.featureGroup = Qn),
      (e.geoJSON = Sr),
      (e.geoJson = Cr),
      (e.gridLayer = Lr),
      (e.icon = er),
      (e.imageOverlay = Tr),
      (e.latLng = O),
      (e.latLngBounds = E),
      (e.layerGroup = Zn),
      (e.map = pn),
      (e.marker = ir),
      (e.point = S),
      (e.polygon = fr),
      (e.polyline = ur),
      (e.popup = jr),
      (e.rectangle = Xr),
      (e.setOptions = p),
      (e.stamp = o),
      (e.svg = Jr),
      (e.svgOverlay = kr),
      (e.tileLayer = zr),
      (e.tooltip = Nr),
      (e.transformation = he),
      (e.version = t),
      (e.videoOverlay = Dr);
    var ai = window.L;
    (e.noConflict = function () {
      return (window.L = ai), this;
    }),
      (window.L = e);
  });
});
export default t();
