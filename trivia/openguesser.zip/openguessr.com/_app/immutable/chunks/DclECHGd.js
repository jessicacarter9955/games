var e = function (e, t) {
    return new URL(e, t).href;
  },
  t = {},
  n = function (e) {
    return e.pathname.endsWith(`.css`);
  },
  r = function (e, t, n) {
    if (t in e) return e[t];
    let r = n();
    if (!r) {
      e[t] = void 0;
      return;
    }
    let i = r.then(
      () => {
        e[t] = void 0;
      },
      (n) => {
        throw ((e[t] = void 0), n);
      }
    );
    return (e[t] = i), i;
  },
  i = function (i, a, o) {
    let s = Promise.resolve();
    if (a && a.length > 0) {
      let i,
        c = document.querySelector(`meta[property=csp-nonce]`),
        l = c?.nonce || c?.getAttribute(`nonce`);
      function u(e) {
        return Promise.all(
          e.map((e) =>
            Promise.resolve(e).then(
              (e) => ({ status: `fulfilled`, value: e }),
              (e) => ({ status: `rejected`, reason: e })
            )
          )
        );
      }
      function d(e) {
        return import.meta.resolve
          ? new URL(import.meta.resolve(e))
          : new URL(e, import.meta.url);
      }
      s = u(
        a
          .map((a) => {
            a = e(a, o);
            let s = d(a),
              c = n(s);
            return r(t, s.href, () => {
              if (i === void 0) {
                i = { all: new Set(), styles: new Set() };
                let e = document.getElementsByTagName(`link`);
                for (let t = e.length - 1; t >= 0; t--) {
                  let n = e[t];
                  i.all.add(n.href),
                    n.rel === `stylesheet` && i.styles.add(n.href);
                }
              }
              if ((c ? i.styles : i.all).has(s.href)) return;
              let e = document.createElement(`link`);
              if (
                ((e.rel = c ? `stylesheet` : `modulepreload`),
                c || (e.as = `script`),
                (e.crossOrigin = ``),
                (e.href = s.href),
                l && e.setAttribute(`nonce`, l),
                document.head.appendChild(e),
                c)
              )
                return new Promise((t, n) => {
                  let r = (i) => {
                    e.removeEventListener(`load`, r),
                      e.removeEventListener(`error`, r),
                      i.type === `error`
                        ? n(Error(`Unable to preload CSS for ${s}`))
                        : t(i);
                  };
                  e.addEventListener(`load`, r), e.addEventListener(`error`, r);
                });
            });
          })
          .filter((e) => e !== void 0)
      );
    }
    function c(e) {
      let t = new Event(`vite:preloadError`, { cancelable: !0 });
      if (((t.payload = e), window.dispatchEvent(t), !t.defaultPrevented))
        throw e;
    }
    return s.then((e) => {
      for (let t of e || []) t.status === `rejected` && c(t.reason);
      return i().catch(c);
    });
  };
export { i as t };
