import "./xihTtKlq.js";
import { o as e, s as t } from "./hxBKRHPW.js";
import { F as n } from "./DbFYFRnT.js";
var r = {
  name: `user`,
  size: 24,
  node: [
    [`path`, { d: `M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2` }],
    [`circle`, { cx: `12`, cy: `7`, r: `4` }],
  ],
};
r.node;
var i = new Set([`$$slots`, `$$events`, `$$legacy`]);
function a(a, o) {
  let s = e(o, i);
  n(
    a,
    t(() => s, {
      get icon() {
        return r;
      },
    })
  );
}
export { a as t };
