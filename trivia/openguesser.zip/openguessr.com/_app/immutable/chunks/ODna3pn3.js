import "./xihTtKlq.js";
import { o as e, s as t } from "./hxBKRHPW.js";
import { F as n } from "./DbFYFRnT.js";
var r = {
  name: `layers`,
  size: 24,
  node: [
    [
      `path`,
      {
        d: `M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z`,
      },
    ],
    [
      `path`,
      {
        d: `M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12`,
      },
    ],
    [
      `path`,
      {
        d: `M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17`,
      },
    ],
  ],
  aliases: [`layers-3`],
};
r.node;
var i = new Set([`$$slots`, `$$events`, `$$legacy`]);
function a(a, o) {
  let s = e(o, i);
  n(
    a,
    t(() => s, {
      get icon() {
        return r;
      },
    })
  );
}
export { a as t };
