import "./xihTtKlq.js";
import { o as e, s as t } from "./hxBKRHPW.js";
import { F as n } from "./DbFYFRnT.js";
var r = {
  name: `external-link`,
  size: 24,
  node: [
    [`path`, { d: `M15 3h6v6` }],
    [`path`, { d: `M10 14 21 3` }],
    [`path`, { d: `M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6` }],
  ],
};
r.node;
var i = new Set([`$$slots`, `$$events`, `$$legacy`]);
function a(a, o) {
  let s = e(o, i);
  n(
    a,
    t(() => s, {
      get icon() {
        return r;
      },
    })
  );
}
export { a as t };
