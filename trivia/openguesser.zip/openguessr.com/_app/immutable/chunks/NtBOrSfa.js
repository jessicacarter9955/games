import {
  Dt as e,
  Tt as t,
  ct as n,
  g as r,
  lt as i,
  r as a,
  st as o,
  t as s,
} from "./hxBKRHPW.js";
var c = class {
    constructor(e, t) {
      (this.status = e),
        (this.body =
          typeof t == `string`
            ? { message: t }
            : t || { message: `Error: ${e}` });
    }
    toString() {
      return JSON.stringify(this.body);
    }
  },
  l = class {
    constructor(e, t) {
      try {
        new Headers({ location: t });
      } catch {
        throw Error(
          `Invalid redirect location ${JSON.stringify(
            t
          )}: this string contains characters that cannot be used in HTTP headers`
        );
      }
      (this.status = e), (this.location = t);
    }
  },
  u = class extends Error {
    constructor(e, t, n) {
      super(n), (this.status = e), (this.text = t);
    }
  };
new URL(`sveltekit-internal://`);
function d(e, t) {
  return e === `/` || t === `ignore`
    ? e
    : t === `never`
    ? e.endsWith(`/`)
      ? e.slice(0, -1)
      : e
    : t === `always` && !e.endsWith(`/`)
    ? e + `/`
    : e;
}
function f(e) {
  return e.split(`%25`).map(decodeURI).join(`%25`);
}
function p(e) {
  for (let t in e) e[t] = decodeURIComponent(e[t]);
  return e;
}
function m({ href: e }) {
  return e.split(`#`)[0];
}
function h(e, t, n, r = !1) {
  let i = new URL(e);
  Object.defineProperty(i, "searchParams", {
    value: new Proxy(i.searchParams, {
      get(e, r) {
        if (r === `get` || r === `getAll` || r === `has`)
          return (t, ...i) => (n(t), e[r](t, ...i));
        t();
        let i = Reflect.get(e, r);
        return typeof i == `function` ? i.bind(e) : i;
      },
    }),
    enumerable: !0,
    configurable: !0,
  });
  let a = [`href`, `pathname`, `search`, `toString`, `toJSON`];
  r && a.push(`hash`);
  for (let n of a)
    Object.defineProperty(i, n, {
      get() {
        return t(), e[n];
      },
      enumerable: !0,
      configurable: !0,
    });
  return i;
}
function g() {}
function _(...e) {
  let t = 5381;
  for (let n of e)
    if (typeof n == `string`) {
      let e = n.length;
      for (; e; ) t = (t * 33) ^ n.charCodeAt(--e);
    } else if (ArrayBuffer.isView(n)) {
      let e = new Uint8Array(n.buffer, n.byteOffset, n.byteLength),
        r = e.length;
      for (; r; ) t = (t * 33) ^ e[--r];
    } else throw TypeError(`value must be a string or TypedArray`);
  return (t >>> 0).toString(36);
}
new TextEncoder();
function v(e) {
  let t = atob(e),
    n = new Uint8Array(t.length);
  for (let e = 0; e < t.length; e++) n[e] = t.charCodeAt(e);
  return n;
}
var ee = window.fetch;
window.fetch = (e, t) => (
  (e instanceof Request ? e.method : t?.method || `GET`) !== `GET` &&
    y.delete(x(e)),
  ee(e, t)
);
var y = new Map();
function b(e, t) {
  let n = x(e, t),
    r = document.querySelector(n);
  if (r?.textContent) {
    r.remove();
    let { body: e, ...t } = JSON.parse(r.textContent);
    r.getAttribute(`data-b64`) !== null && (e = v(e));
    let i = r.getAttribute(`data-ttl`);
    return (
      i && y.set(n, { body: e, init: t, ttl: 1e3 * Number(i) }),
      Promise.resolve(new Response(e, t))
    );
  }
  return window.fetch(e, t);
}
function te(e, t, n) {
  if (y.size > 0) {
    let t = x(e, n),
      r = y.get(t);
    if (r) {
      if (
        performance.now() < r.ttl &&
        [`default`, `force-cache`, `only-if-cached`, void 0].includes(n?.cache)
      )
        return new Response(r.body, r.init);
      y.delete(t);
    }
  }
  return window.fetch(t, n);
}
function x(e, t) {
  let n = `script[data-sveltekit-fetched][data-url=${JSON.stringify(
    e instanceof Request ? e.url : e
  )}]`;
  if (t?.headers || t?.body) {
    let e = [];
    t.headers && e.push([...new Headers(t.headers)].join(`,`)),
      t.body &&
        (typeof t.body == `string` || ArrayBuffer.isView(t.body)) &&
        e.push(t.body),
      (n += `[data-hash="${_(...e)}"]`);
  }
  return n;
}
var ne = /^(\[)?(\.\.\.)?(\w+)(?:=(\w+))?(\])?$/,
  re = /^\/\((?:[^)]+)\)$/;
function ie(e) {
  let t = [];
  return {
    pattern:
      e === `/` || re.test(e)
        ? /^\/$/
        : RegExp(
            `^${oe(e)
              .map((e) => {
                let n = /^\[\.\.\.(\w+)(?:=(\w+))?\]$/.exec(e);
                if (n)
                  return (
                    t.push({
                      name: n[1],
                      matcher: n[2],
                      optional: !1,
                      rest: !0,
                      chained: !0,
                    }),
                    `(?:/([^]*))?`
                  );
                let r = /^\[\[(\w+)(?:=(\w+))?\]\]$/.exec(e);
                if (r)
                  return (
                    t.push({
                      name: r[1],
                      matcher: r[2],
                      optional: !0,
                      rest: !1,
                      chained: !0,
                    }),
                    `(?:/([^/]+))?`
                  );
                if (!e) return;
                let i = e.split(/\[(.+?)\](?!\])/);
                return (
                  `/` +
                  i
                    .map((e, n) => {
                      if (n % 2) {
                        if (e.startsWith(`x+`))
                          return ce(
                            String.fromCharCode(parseInt(e.slice(2), 16))
                          );
                        if (e.startsWith(`u+`))
                          return ce(
                            String.fromCharCode(
                              ...e
                                .slice(2)
                                .split(`-`)
                                .map((e) => parseInt(e, 16))
                            )
                          );
                        let [, r, a, o, s] = ne.exec(e);
                        return (
                          t.push({
                            name: o,
                            matcher: s,
                            optional: !!r,
                            rest: !!a,
                            chained: a ? n === 1 && i[0] === `` : !1,
                          }),
                          a ? `([^]*?)` : r ? `([^/]*)?` : `([^/]+?)`
                        );
                      }
                      return ce(e);
                    })
                    .join(``)
                );
              })
              .join(``)}/?$`
          ),
    params: t,
  };
}
function ae(e) {
  return e !== `` && !/^\([^)]+\)$/.test(e);
}
function oe(e) {
  return e.slice(1).split(`/`).filter(ae);
}
function se(e, t, n) {
  let r = {},
    i = e.slice(1),
    a = i.filter((e) => e !== void 0),
    o = 0;
  for (let e = 0; e < t.length; e += 1) {
    let s = t[e],
      c = i[e - o];
    if (
      (s.chained &&
        s.rest &&
        o &&
        ((c = i
          .slice(e - o, e + 1)
          .filter((e) => e)
          .join(`/`)),
        (o = 0)),
      c === void 0)
    ) {
      if (s.rest) c = ``;
      else continue;
    }
    if (!s.matcher || n[s.matcher](c)) {
      r[s.name] = c;
      let n = t[e + 1],
        l = i[e + 1];
      n && !n.rest && n.optional && l && s.chained && (o = 0),
        !n && !l && Object.keys(r).length === a.length && (o = 0);
    } else if (s.optional && s.chained) o++;
    else return;
  }
  if (!o) return r;
}
function ce(e) {
  return e
    .normalize()
    .replace(/[[\]]/g, `\\$&`)
    .replace(/%/g, `%25`)
    .replace(/\//g, `%2[Ff]`)
    .replace(/\?/g, `%3[Ff]`)
    .replace(/#/g, `%23`)
    .replace(/[.*+?^${}()|\\]/g, `\\$&`);
}
function le({ nodes: e, server_loads: t, dictionary: n, matchers: r }) {
  let i = new Set(t);
  return Object.entries(n).map(([t, [n, i, s]]) => {
    let { pattern: c, params: l } = ie(t),
      u = {
        id: t,
        exec: (e) => {
          let t = c.exec(e);
          if (t) return se(t, l, r);
        },
        errors: [1, ...(s || [])].map((t) => e[t]),
        layouts: [0, ...(i || [])].map(o),
        leaf: a(n),
      };
    return (
      (u.errors.length = u.layouts.length =
        Math.max(u.errors.length, u.layouts.length)),
      u
    );
  });
  function a(t) {
    let n = t < 0;
    return n && (t = ~t), [n, e[t]];
  }
  function o(t) {
    return t === void 0 ? t : [i.has(t), e[t]];
  }
}
function ue(e, t = JSON.parse) {
  try {
    return t(sessionStorage[e]);
  } catch {}
}
function de(e, t, n = JSON.stringify) {
  let r = n(t);
  try {
    sessionStorage[e] = r;
  } catch {}
}
var S = globalThis.__sveltekit_13x2ayc?.base ?? ``,
  fe = globalThis.__sveltekit_13x2ayc?.assets ?? S ?? ``,
  pe = `1795479097917`,
  me = `sveltekit:snapshot`,
  he = `sveltekit:scroll`,
  ge = `sveltekit:states`,
  C = `sveltekit:history`,
  w = `sveltekit:navigation`,
  T = { tap: 1, hover: 2, viewport: 3, eager: 4, off: -1, false: -1 },
  _e = location.origin;
function ve(e) {
  if (e instanceof URL) return e;
  let t = document.baseURI;
  if (!t) {
    let e = document.getElementsByTagName(`base`);
    t = e.length ? e[0].href : document.URL;
  }
  return new URL(e, t);
}
function E() {
  return { x: pageXOffset, y: pageYOffset };
}
function D(e, t) {
  return e.getAttribute(`data-sveltekit-${t}`);
}
var ye = { ...T, "": T.hover };
function be(e) {
  let t = e.assignedSlot ?? e.parentNode;
  return t?.nodeType === 11 && (t = t.host), t;
}
function xe(e, t) {
  for (; e && e !== t; ) {
    if (e.nodeName.toUpperCase() === `A` && e.hasAttribute(`href`)) return e;
    e = be(e);
  }
}
function Se(e, t, n) {
  let r;
  try {
    if (
      ((r = new URL(
        e instanceof SVGAElement ? e.href.baseVal : e.href,
        document.baseURI
      )),
      n && r.hash.match(/^#[^/]/))
    ) {
      let e = location.hash.split(`#`)[1] || `/`;
      r.hash = `#${e}${r.hash}`;
    }
  } catch {}
  let i = e instanceof SVGAElement ? e.target.baseVal : e.target,
    a =
      !r ||
      !!i ||
      k(r, t, n) ||
      (e.getAttribute(`rel`) || ``).split(/\s+/).includes(`external`),
    o = r?.origin === _e && e.hasAttribute(`download`);
  return { url: r, external: a, target: i, download: o };
}
function O(e) {
  let t = null,
    n = null,
    r = null,
    i = null,
    a = null,
    o = null,
    s = e;
  for (; s && s !== document.documentElement; )
    r === null && (r = D(s, `preload-code`)),
      i === null && (i = D(s, `preload-data`)),
      t === null && (t = D(s, `keepfocus`)),
      n === null && (n = D(s, `noscroll`)),
      a === null && (a = D(s, `reload`)),
      o === null && (o = D(s, `replacestate`)),
      (s = be(s));
  function c(e) {
    switch (e) {
      case ``:
      case `true`:
        return !0;
      case `off`:
      case `false`:
        return !1;
      default:
        return;
    }
  }
  return {
    preload_code: ye[r ?? `off`],
    preload_data: ye[i ?? `off`],
    keepfocus: c(t),
    noscroll: c(n),
    reload: c(a),
    replace_state: c(o),
  };
}
function Ce(e) {
  let t = r(e),
    n = !0;
  function i() {
    (n = !0), t.update((e) => e);
  }
  function a(e) {
    (n = !1), t.set(e);
  }
  function o(e) {
    let r;
    return t.subscribe((t) => {
      (r === void 0 || (n && t !== r)) && e((r = t));
    });
  }
  return { notify: i, set: a, subscribe: o };
}
var we = { v: g };
function Te() {
  let { set: e, subscribe: t } = r(!1),
    n;
  async function i() {
    clearTimeout(n);
    try {
      let t = await fetch(`${fe}/_app/version.json`, {
        headers: { pragma: `no-cache`, "cache-control": `no-cache` },
      });
      if (!t.ok) return !1;
      let r = (await t.json()).version !== pe;
      return r && (e(!0), we.v(), clearTimeout(n)), r;
    } catch {
      return !1;
    }
  }
  return { subscribe: t, check: i };
}
function k(e, t, n) {
  return e.origin !== _e || !e.pathname.startsWith(t)
    ? !0
    : n
    ? e.pathname !== location.pathname
    : !1;
}
function Ee(e) {}
var De = new Set([
  `load`,
  `prerender`,
  `csr`,
  `ssr`,
  `trailingSlash`,
  `config`,
]);
[...De], [...new Set([...De])];
function Oe(e) {
  return e.filter((e) => e != null);
}
function ke(e, t) {
  return e + `/` + t;
}
function Ae(e) {
  return e instanceof c || e instanceof u ? e.status : 500;
}
function je(e) {
  return e instanceof u ? e.text : `Internal Error`;
}
var A,
  j,
  Me,
  Ne =
    a.toString().includes(`$$`) || /function \w+\(\) \{\}/.test(a.toString()),
  Pe = `a:`;
Ne
  ? ((A = {
      data: {},
      form: null,
      error: null,
      params: {},
      route: { id: null },
      state: {},
      status: -1,
      url: new URL(Pe),
    }),
    (j = { current: null }),
    (Me = { current: !1 }))
  : ((A = new (class {
      #e = e({});
      get data() {
        return o(this.#e);
      }
      set data(e) {
        t(this.#e, e);
      }
      #t = e(null);
      get form() {
        return o(this.#t);
      }
      set form(e) {
        t(this.#t, e);
      }
      #n = e(null);
      get error() {
        return o(this.#n);
      }
      set error(e) {
        t(this.#n, e);
      }
      #r = e({});
      get params() {
        return o(this.#r);
      }
      set params(e) {
        t(this.#r, e);
      }
      #i = e({ id: null });
      get route() {
        return o(this.#i);
      }
      set route(e) {
        t(this.#i, e);
      }
      #a = e({});
      get state() {
        return o(this.#a);
      }
      set state(e) {
        t(this.#a, e);
      }
      #o = e(-1);
      get status() {
        return o(this.#o);
      }
      set status(e) {
        t(this.#o, e);
      }
      #s = e(new URL(Pe));
      get url() {
        return o(this.#s);
      }
      set url(e) {
        t(this.#s, e);
      }
    })()),
    (j = new (class {
      #e = e(null);
      get current() {
        return o(this.#e);
      }
      set current(e) {
        t(this.#e, e);
      }
    })()),
    (Me = new (class {
      #e = e(!1);
      get current() {
        return o(this.#e);
      }
      set current(e) {
        t(this.#e, e);
      }
    })()),
    (we.v = () => (Me.current = !0)));
function Fe(e) {
  Object.assign(A, e);
}
var Ie = {
    spanContext() {
      return Le;
    },
    setAttribute() {
      return this;
    },
    setAttributes() {
      return this;
    },
    addEvent() {
      return this;
    },
    setStatus() {
      return this;
    },
    updateName() {
      return this;
    },
    end() {
      return this;
    },
    isRecording() {
      return !1;
    },
    recordException() {
      return this;
    },
    addLink() {
      return this;
    },
    addLinks() {
      return this;
    },
  },
  Le = { traceId: ``, spanId: ``, traceFlags: 0 },
  { onMount: Re, tick: ze } = s,
  Be = new Set([`icon`, `shortcut icon`, `apple-touch-icon`]),
  M = null,
  N = ue(`sveltekit:scroll`) ?? {},
  P = ue(`sveltekit:snapshot`) ?? {},
  F = { url: Ce({}), page: Ce({}), navigating: r(null), updated: Te() };
function Ve(e) {
  N[e] = E();
}
function He(e, t) {
  let n = e + 1;
  for (; N[n]; ) delete N[n], (n += 1);
  for (n = t + 1; P[n]; ) delete P[n], (n += 1);
}
function I(e, t = !1) {
  return (
    t ? location.replace(e.href) : (location.href = e.href), new Promise(g)
  );
}
async function Ue() {
  if (`serviceWorker` in navigator) {
    let e = await navigator.serviceWorker.getRegistration(S || `/`);
    e && (await e.update());
  }
}
var We,
  Ge,
  L,
  R,
  Ke,
  z,
  qe = {},
  Je = {},
  B = [],
  Ye = [],
  V = null;
function Xe() {
  V?.fork?.then((e) => e?.discard()),
    (V = null),
    (Q = { element: void 0, href: void 0 });
}
var H = new Map(),
  Ze = new Set(),
  Qe = new Set(),
  U = new Set(),
  W = { branch: [], error: null, url: null, nav: null },
  $e = !1,
  G = !1,
  et = !0,
  K = !1,
  q = !1,
  tt = !1,
  nt = !1,
  rt,
  J,
  Y,
  X,
  it = new Set(),
  at = new Map(),
  ot = new Map();
async function st(e, t, n) {
  if (globalThis.__sveltekit_13x2ayc.data) {
    let {
      q: e = {},
      p: t = {},
      l: n = {},
      f: r = {},
    } = globalThis.__sveltekit_13x2ayc.data;
    for (let t in e) qe[t] = e[t];
    for (let e in n) qe[e] = n[e];
    for (let e in r) qe[e] = r[e];
    for (let e in t) Je[e] = t[e];
  }
  document.URL !== location.href && (location.href = location.href),
    (z = e),
    await e.hooks.init?.(),
    (We = le(e)),
    (R = document.documentElement),
    (Ke = t),
    (Ge = e.nodes[0]),
    (L = e.nodes[1]),
    Ge(),
    L(),
    (J = history.state?.[C]),
    (Y = history.state?.[w]),
    J ||
      ((J = Y = Date.now()),
      history.replaceState({ ...history.state, [C]: J, [w]: Y }, ``));
  let r = N[J];
  function i() {
    r && ((history.scrollRestoration = `manual`), scrollTo(r.x, r.y));
  }
  n
    ? (i(), await Bt(Ke, n))
    : (await Z({
        type: `enter`,
        url: ve(z.hash ? Kt(new URL(location.href)) : location.href),
        replace_state: !0,
      }),
      i()),
    zt();
}
function ct() {
  (B.length = 0), (nt = !1);
}
function lt(e) {
  Ye.some((e) => e?.snapshot) && (P[e] = Ye.map((e) => e?.snapshot?.capture()));
}
function ut(e) {
  P[e]?.forEach((e, t) => {
    Ye[t]?.snapshot?.restore(e);
  });
}
function dt() {
  Ve(J), de(he, N), lt(Y), de(me, P);
}
async function ft(e, t, n, r) {
  let a, o;
  t.invalidateAll && Xe(),
    await Z({
      type: `goto`,
      url: ve(e),
      keepfocus: t.keepFocus,
      noscroll: t.noScroll,
      replace_state: t.replaceState,
      state: t.state,
      redirect_count: n,
      nav_token: r,
      accept: () => {
        if (t.invalidateAll) {
          (nt = !0), (a = new Set());
          for (let [e, t] of at)
            for (let [n, r] of t) r.resource?.reset(), a.add(ke(e, n));
          o = new Set();
          for (let [e, t] of ot) for (let n of t.keys()) o.add(ke(e, n));
        }
        t.invalidate && t.invalidate.forEach(Rt);
      },
    }),
    t.invalidateAll &&
      i()
        .then(i)
        .then(() => {
          for (let [e, t] of at)
            for (let [n, { resource: r }] of t) a?.has(ke(e, n)) && r.start();
          for (let [e, t] of ot)
            for (let [n, { resource: r }] of t)
              o?.has(ke(e, n)) && r.reconnect();
        });
}
async function pt(e) {
  if (e.id !== V?.id) {
    Xe();
    let t = {};
    it.add(t),
      (V = {
        id: e.id,
        token: t,
        promise: Ct({ ...e, preload: t }).then(
          (e) => (it.delete(t), e.type === `loaded` && e.state.error && Xe(), e)
        ),
        fork: null,
      });
  }
  return V.promise;
}
async function mt(e) {
  let t = (await Dt(e, !1))?.route;
  t &&
    (await Promise.all(
      [...t.layouts, t.leaf].filter(Boolean).map((e) => e[1]())
    ));
}
async function ht(e, t, n) {
  let r = {
    params: W.params,
    route: { id: W.route?.id ?? null },
    url: new URL(location.href),
  };
  if (
    ((W = { ...e.state, nav: r }),
    Fe(e.props.page),
    (rt = new z.root({
      target: t,
      props: { ...e.props, stores: F, components: Ye },
      hydrate: n,
      sync: !1,
      transformError: void 0,
    })),
    await Promise.resolve(),
    n)
  ) {
    let e = {
      from: null,
      to: { ...r, scroll: N[J] ?? E() },
      willUnload: !1,
      type: `enter`,
      complete: Promise.resolve(),
    };
    U.forEach((t) => t(e));
  }
  ut(Y), (G = !0);
}
async function gt({
  url: e,
  params: t,
  branch: n,
  errors: r,
  status: i,
  error: a,
  route: o,
  form: s,
}) {
  let c = `never`;
  if (S && (e.pathname === S || e.pathname === S + `/`)) c = `always`;
  else for (let e of n) e?.slash !== void 0 && (c = e.slash);
  (e.pathname = d(e.pathname, c)), (e.search = e.search);
  let l = {
    type: `loaded`,
    state: { url: e, params: t, branch: n, error: a, route: o },
    props: { constructors: Oe(n).map((e) => e.node.component), page: Gt(A) },
  };
  s !== void 0 && (l.props.form = s);
  let u = {},
    f = !A,
    p = 0;
  for (let e = 0; e < Math.max(n.length, W.branch.length); e += 1) {
    let t = n[e],
      r = W.branch[e];
    t?.data !== r?.data && (f = !0),
      t &&
        ((u = { ...u, ...t.data }), f && (l.props[`data_${p}`] = u), (p += 1));
  }
  return (
    (!W.url ||
      e.href !== W.url.href ||
      W.error !== a ||
      (s !== void 0 && s !== A.form) ||
      f) &&
      (l.props.page = {
        error: a,
        params: t,
        route: { id: o?.id ?? null },
        state: {},
        status: i,
        url: new URL(e),
        form: s ?? null,
        data: f ? u : A.data,
      }),
    l
  );
}
async function _t({
  loader: e,
  parent: t,
  url: n,
  params: r,
  route: i,
  server_data_node: a,
}) {
  let o = null,
    s = !0,
    c = {
      dependencies: new Set(),
      params: new Set(),
      parent: !1,
      route: !1,
      url: !1,
      search_params: new Set(),
    },
    l = await e();
  if (l.universal?.load) {
    function e(...e) {
      for (let t of e) {
        let { href: e } = new URL(t, n);
        c.dependencies.add(e);
      }
    }
    let u = {
      tracing: { enabled: !1, root: Ie, current: Ie },
      route: new Proxy(i, { get: (e, t) => (s && (c.route = !0), e[t]) }),
      params: new Proxy(r, { get: (e, t) => (s && c.params.add(t), e[t]) }),
      data: a?.data ?? null,
      url: h(
        n,
        () => {
          s && (c.url = !0);
        },
        (e) => {
          s && c.search_params.add(e);
        },
        z.hash
      ),
      async fetch(t, r) {
        t instanceof Request &&
          (r = {
            body:
              t.method === `GET` || t.method === `HEAD`
                ? void 0
                : await t.blob(),
            cache: t.cache,
            credentials: t.credentials,
            headers: [...t.headers].length > 0 ? t?.headers : void 0,
            integrity: t.integrity,
            keepalive: t.keepalive,
            method: t.method,
            mode: t.mode,
            redirect: t.redirect,
            referrer: t.referrer,
            referrerPolicy: t.referrerPolicy,
            signal: t.signal,
            ...r,
          });
        let { resolved: i, promise: a } = vt(t, r, n);
        return s && e(i.href), a;
      },
      setHeaders: g,
      depends: e,
      parent() {
        return s && (c.parent = !0), t();
      },
      untrack(e) {
        s = !1;
        try {
          return e();
        } finally {
          s = !0;
        }
      },
    };
    o = (await l.universal.load.call(null, u)) ?? null;
  }
  return {
    node: l,
    loader: e,
    server: a,
    universal: l.universal?.load ? { type: `data`, data: o, uses: c } : null,
    data: o ?? a?.data ?? null,
    slash: l.universal?.trailingSlash ?? a?.slash,
  };
}
function vt(e, t, n) {
  let r = e instanceof Request ? e.url : e,
    i = new URL(r, n);
  return (
    i.origin === n.origin && (r = i.href.slice(n.origin.length)),
    { resolved: i, promise: G ? te(r, i.href, t) : b(r, t) }
  );
}
function yt(e, t, n, r, i, a) {
  if (nt) return !0;
  if (!i) return !1;
  if ((i.parent && e) || (i.route && t) || (i.url && n)) return !0;
  for (let e of i.search_params) if (r.has(e)) return !0;
  for (let e of i.params) if (a[e] !== W.params[e]) return !0;
  for (let e of i.dependencies) if (B.some((t) => t(new URL(e)))) return !0;
  return !1;
}
function bt(e, t) {
  return e?.type === `data` ? e : e?.type === `skip` ? t ?? null : null;
}
function xt(e, t) {
  if (!e) return new Set(t.searchParams.keys());
  let n = new Set([...e.searchParams.keys(), ...t.searchParams.keys()]);
  for (let r of n) {
    let i = e.searchParams.getAll(r),
      a = t.searchParams.getAll(r);
    i.every((e) => a.includes(e)) &&
      a.every((e) => i.includes(e)) &&
      n.delete(r);
  }
  return n;
}
function St({ error: e, url: t, route: n, params: r }) {
  return {
    type: `loaded`,
    state: { error: e, url: t, route: n, params: r, branch: [] },
    props: { page: Gt(A), constructors: [] },
  };
}
async function Ct({
  id: e,
  invalidating: t,
  url: n,
  params: r,
  route: i,
  preload: a,
}) {
  if (V?.id === e) return it.delete(V.token), V.promise;
  let { errors: o, layouts: s, leaf: u } = i,
    d = [...s, u];
  o.forEach((e) => e?.().catch(g)), d.forEach((e) => e?.[1]().catch(g));
  let f = W.url ? e !== kt(W.url) : !1,
    p = W.route ? i.id !== W.route.id : !1,
    m = xt(W.url, n),
    h = !1,
    _ = d.map(async (e, t) => {
      if (!e) return;
      let a = W.branch[t];
      return e[1] === a?.loader && !yt(h, p, f, m, a.universal?.uses, r)
        ? a
        : ((h = !0),
          _t({
            loader: e[1],
            url: n,
            params: r,
            route: i,
            parent: async () => {
              let e = {};
              for (let n = 0; n < t; n += 1)
                Object.assign(e, (await _[n])?.data);
              return e;
            },
            server_data_node: bt(
              e[0] ? { type: `skip` } : null,
              e[0] ? a?.server : void 0
            ),
          }));
    });
  for (let e of _) e.catch(g);
  let v = [];
  for (let e = 0; e < d.length; e += 1)
    if (d[e])
      try {
        v.push(await _[e]);
      } catch (t) {
        if (t instanceof l) return { type: `redirect`, location: t.location };
        if (a && it.has(a))
          return St({
            error: await $(t, { params: r, url: n, route: { id: i.id } }),
            url: n,
            params: r,
            route: i,
          });
        let s = Ae(t),
          u;
        if (t instanceof c) u = t.body;
        else {
          if (await F.updated.check()) return await Ue(), await I(n);
          u = await $(t, { params: r, url: n, route: { id: i.id } });
        }
        let d = await wt(e, v, o);
        return d
          ? gt({
              url: n,
              params: r,
              branch: v.slice(0, d.idx).concat(d.node),
              errors: o,
              status: s,
              error: u,
              route: i,
            })
          : await jt(n, { id: i.id }, u, s);
      }
    else v.push(void 0);
  return gt({
    url: n,
    params: r,
    branch: v,
    errors: o,
    status: 200,
    error: null,
    route: i,
    form: t ? void 0 : null,
  });
}
async function wt(e, t, n) {
  for (; e--; )
    if (n[e]) {
      let r = e;
      for (; !t[r]; ) --r;
      try {
        return {
          idx: r + 1,
          node: {
            node: await n[e](),
            loader: n[e],
            data: {},
            server: null,
            universal: null,
          },
        };
      } catch {
        continue;
      }
    }
}
async function Tt({ status: e, error: t, url: n, route: r }) {
  let i = {};
  try {
    return gt({
      url: n,
      params: i,
      branch: [
        await _t({
          loader: Ge,
          url: n,
          params: i,
          route: r,
          parent: () => Promise.resolve({}),
          server_data_node: bt(null),
        }),
        {
          node: await L(),
          loader: L,
          universal: null,
          server: null,
          data: null,
        },
      ],
      status: e,
      error: t,
      errors: [],
      route: null,
    });
  } catch (t) {
    if (t instanceof l) {
      await ft(new URL(t.location, location.href), {}, 0);
      return;
    }
    let a = await z.get_error_template(),
      o = await $(t, { url: n, params: i, route: r }),
      s = a({
        status: e,
        message: String(o?.message ?? ``)
          .replace(/&/g, `&amp;`)
          .replace(/</g, `&lt;`)
          .replace(/>/g, `&gt;`),
      }),
      c = new DOMParser().parseFromString(s, `text/html`);
    throw (
      (document.documentElement.replaceChild(
        document.adoptNode(c.head),
        document.head
      ),
      document.documentElement.replaceChild(
        document.adoptNode(c.body),
        document.body
      ),
      t)
    );
  }
}
async function Et(e) {
  let t = e.href;
  if (H.has(t)) return H.get(t);
  let n;
  try {
    let r = (async () => {
      let t =
        (await z.hooks.reroute({
          url: new URL(e),
          fetch: async (t, n) => vt(t, n, e).promise,
        })) ?? e;
      if (typeof t == `string`) {
        let n = new URL(e);
        z.hash ? (n.hash = t) : (n.pathname = t), (t = n);
      }
      return t;
    })();
    H.set(t, r), (n = await r);
  } catch {
    H.delete(t);
    return;
  }
  return n;
}
async function Dt(e, t) {
  if (e && !k(e, S, z.hash)) {
    let n = await Et(e);
    if (!n) return;
    let r = Ot(n);
    for (let n of We) {
      let i = n.exec(r);
      if (i)
        return { id: kt(e), invalidating: t, route: n, params: p(i), url: e };
    }
  }
}
function Ot(e) {
  return (
    f(
      z.hash
        ? e.hash.replace(/^#/, ``).replace(/[?#].+/, ``)
        : e.pathname.slice(S.length)
    ) || `/`
  );
}
function kt(e) {
  return (z.hash ? e.hash.replace(/^#/, ``) : e.pathname) + e.search;
}
function At({ url: e, type: t, intent: n, delta: r, event: i, scroll: a }) {
  let o = !1,
    s = Wt(W, n, e, t, a ?? null);
  r !== void 0 && (s.navigation.delta = r),
    i !== void 0 && (s.navigation.event = i);
  let c = {
    ...s.navigation,
    cancel: () => {
      (o = !0), s.reject(Error(`navigation cancelled`));
    },
  };
  return K || Ze.forEach((e) => e(c)), o ? null : s;
}
async function Z({
  type: e,
  url: t,
  popped: r,
  keepfocus: a,
  noscroll: o,
  replace_state: s,
  state: c = {},
  redirect_count: l = 0,
  nav_token: d = {},
  accept: f = g,
  block: p = g,
  event: m,
}) {
  let h = X;
  X = d;
  let _ = await Dt(t, !1),
    v =
      e === `enter`
        ? Wt(W, _, t, e)
        : At({
            url: t,
            type: e,
            delta: r?.delta,
            intent: _,
            scroll: r?.scroll,
            event: m,
          });
  if (!v) {
    p(), X === d && (X = h);
    return;
  }
  let ee = J,
    y = Y;
  f(),
    (K = !0),
    G &&
      v.navigation.type !== `enter` &&
      F.navigating.set((j.current = v.navigation));
  let b = _ && (await Ct(_));
  if (!b) {
    if (k(t, S, z.hash)) return await I(t, s);
    b = await jt(
      t,
      { id: null },
      await $(new u(404, `Not Found`, `Not found: ${t.pathname}`), {
        url: t,
        params: {},
        route: { id: null },
      }),
      404,
      s
    );
  }
  if (((t = _?.url || t), X !== d)) {
    v.reject(Error(`navigation aborted`));
    return;
  }
  if (!b) return;
  if (b.type === `redirect`) {
    if (l < 20) {
      await Z({
        type: e,
        url: new URL(b.location, t),
        popped: r,
        keepfocus: a,
        noscroll: o,
        replace_state: s,
        state: c,
        redirect_count: l + 1,
        nav_token: d,
      }),
        v.fulfil(void 0);
      return;
    }
    if (
      ((b = await Tt({
        status: 500,
        error: await $(Error(`Redirect loop`), {
          url: t,
          params: {},
          route: { id: null },
        }),
        url: t,
        route: { id: null },
      })),
      !b)
    )
      return;
  } else if (b.props.page.status >= 400 && (await F.updated.check()))
    return await Ue(), await I(t, s);
  if (
    (ct(),
    Ve(ee),
    lt(y),
    b.props.page.url.pathname !== t.pathname &&
      (t.pathname = b.props.page.url.pathname),
    (c = r ? r.state : c),
    !r)
  ) {
    let e = +!s,
      n = { [C]: (J += e), [w]: (Y += e), [ge]: c };
    (s ? history.replaceState : history.pushState).call(history, n, ``, t),
      s || He(J, Y);
  }
  let te = _ && V?.id === _.id ? V.fork : null;
  V?.fork && !te ? Xe() : ((V = null), (Q = { element: void 0, href: void 0 })),
    (b.props.page.state = c);
  let x;
  if (G) {
    let e = (await Promise.all(Array.from(Qe, (e) => e(v.navigation)))).filter(
      (e) => typeof e == `function`
    );
    if (e.length > 0) {
      function t() {
        e.forEach((e) => {
          U.delete(e);
        });
      }
      e.push(t),
        e.forEach((e) => {
          U.add(e);
        });
    }
    let r = v.navigation.to;
    (W = { ...b.state, nav: { params: r.params, route: r.route, url: r.url } }),
      b.props.page && (b.props.page.url = t),
      !a &&
        document.activeElement instanceof HTMLElement &&
        document.activeElement !== document.body &&
        document.activeElement.blur();
    let i = te && (await te);
    i
      ? (x = i.commit())
      : ((M = null),
        rt.$set(b.props),
        M && Object.assign(b.props.page, M),
        Fe(b.props.page),
        (x = n?.())),
      (tt = !0);
  } else await ht(b, Ke, !1);
  let { activeElement: ne } = document;
  if ((await x, await i(), await i(), X !== d)) {
    v.reject(Error(`navigation aborted`));
    return;
  }
  b.props.page && M && Object.assign(b.props.page, M);
  let re = null;
  if (et) {
    let e = r ? r.scroll : o ? E() : null;
    e
      ? scrollTo(e.x, e.y)
      : (re = t.hash && document.getElementById(qt(t)))
      ? re.scrollIntoView()
      : scrollTo(0, 0);
  }
  let ie =
    document.activeElement !== ne && document.activeElement !== document.body;
  !a && !ie && Ut(t, !re),
    (et = !0),
    (K = !1),
    v.fulfil(void 0),
    v.navigation.to && (v.navigation.to.scroll = E()),
    U.forEach((e) => e(v.navigation)),
    e === `popstate` && ut(Y),
    F.navigating.set((j.current = null));
}
async function jt(e, t, n, r, i) {
  return e.origin === _e && e.pathname === location.pathname && !$e
    ? await Tt({ status: r, error: n, url: e, route: t })
    : await I(e, i);
}
var Q = { element: void 0, href: void 0 };
function Mt() {
  let e, t;
  R.addEventListener(`mousemove`, (t) => {
    let n = t.target;
    clearTimeout(e),
      (e = setTimeout(() => {
        i(n, T.hover);
      }, 20));
  });
  function n(e) {
    e.defaultPrevented || i(e.composedPath()[0], T.tap);
  }
  R.addEventListener(`mousedown`, n),
    R.addEventListener(`touchstart`, n, { passive: !0 });
  let r = new IntersectionObserver(
    (e) => {
      for (let t of e)
        t.isIntersecting && (mt(new URL(t.target.href)), r.unobserve(t.target));
    },
    { threshold: 0 }
  );
  async function i(e, n) {
    let r = xe(e, R),
      i = r === Q.element && r?.href === Q.href && n >= t;
    if (!r || i) return;
    let { url: a, external: o, download: s } = Se(r, S, z.hash);
    if (o || s) return;
    let c = O(r),
      l = a && kt(W.url) === kt(a);
    if (!(c.reload || l)) {
      if (n <= c.preload_data) {
        (Q = { element: r, href: r.href }), (t = T.tap);
        let e = await Dt(a, !1);
        if (!e) return;
        pt(e);
      } else
        n <= c.preload_code &&
          ((Q = { element: r, href: r.href }), (t = n), mt(a));
    }
  }
  function a() {
    r.disconnect();
    for (let e of R.querySelectorAll(`a`)) {
      let { url: t, external: n, download: i } = Se(e, S, z.hash);
      if (n || i) continue;
      let a = O(e);
      a.reload ||
        (a.preload_code === T.viewport && r.observe(e),
        a.preload_code === T.eager && mt(t));
    }
  }
  U.add(a), a();
}
function $(e, t) {
  if (e instanceof c) return e.body;
  let n = Ae(e),
    r = je(e);
  return (
    z.hooks.handleError({ error: e, event: t, status: n, message: r }) ?? {
      message: r,
    }
  );
}
function Nt(e, t) {
  Re(
    () => (
      e.add(t),
      () => {
        e.delete(t);
      }
    )
  );
}
function Pt(e) {
  Nt(U, e);
}
function Ft(e) {
  Nt(Ze, e);
}
function It(e) {
  Nt(Qe, e);
}
function Lt(e, t = {}) {
  return (
    (e = new URL(ve(e))),
    e.origin === _e ? ft(e, t, 0) : Promise.reject(Error(`goto: invalid URL`))
  );
}
function Rt(e) {
  if (typeof e == `function`) B.push(e);
  else {
    let { href: t } = new URL(e, location.href);
    B.push((e) => e.href === t);
  }
}
function zt() {
  (history.scrollRestoration = `manual`),
    addEventListener(`beforeunload`, (e) => {
      let t = !1;
      if ((dt(), !K)) {
        let e = Wt(W, void 0, null, `leave`),
          n = {
            ...e.navigation,
            cancel: () => {
              (t = !0), e.reject(Error(`navigation cancelled`));
            },
          };
        Ze.forEach((e) => e(n));
      }
      t
        ? (e.preventDefault(), (e.returnValue = ``))
        : (history.scrollRestoration = `auto`);
    }),
    addEventListener(`visibilitychange`, () => {
      document.visibilityState === `hidden` && dt();
    }),
    navigator.connection?.saveData || Mt(),
    R.addEventListener(`click`, async (t) => {
      if (
        t.button ||
        t.which !== 1 ||
        t.metaKey ||
        t.ctrlKey ||
        t.shiftKey ||
        t.altKey ||
        t.defaultPrevented
      )
        return;
      let n = xe(t.composedPath()[0], R);
      if (!n) return;
      let { url: r, external: i, target: a, download: o } = Se(n, S, z.hash);
      if (!r) return;
      if (a === `_parent` || a === `_top`) {
        if (window.parent !== window) return;
      } else if (a && a !== `_self`) return;
      let s = O(n);
      if (
        (!(n instanceof SVGAElement) &&
          r.protocol !== location.protocol &&
          r.protocol !== `https:` &&
          r.protocol !== `http:`) ||
        o
      )
        return;
      let [c, l] = (z.hash ? r.hash.replace(/^#/, ``) : r.href).split(`#`),
        u = c === m(location);
      if (i || (s.reload && (!u || !l)))
        At({ url: r, type: `link`, event: t }) ? (K = !0) : t.preventDefault();
      else {
        if (l !== void 0 && u) {
          let [, i] = W.url.href.split(`#`);
          if (i === l) {
            if (
              (t.preventDefault(),
              l === `` ||
                (l === `top` && n.ownerDocument.getElementById(`top`) === null))
            )
              scrollTo({ top: 0 });
            else {
              let e = n.ownerDocument.getElementById(decodeURIComponent(l));
              e && (e.scrollIntoView(), e.focus());
            }
            return;
          }
          if (((q = !0), Ve(J), e(r), !s.replace_state)) return;
          q = !1;
        }
        t.preventDefault(),
          await new Promise((e) => {
            requestAnimationFrame(() => {
              setTimeout(e, 0);
            }),
              setTimeout(e, 100);
          }),
          await Z({
            type: `link`,
            url: r,
            keepfocus: s.keepfocus,
            noscroll: s.noscroll,
            replace_state: s.replace_state ?? r.href === location.href,
            event: t,
          });
      }
    }),
    R.addEventListener(`submit`, (e) => {
      if (e.defaultPrevented) return;
      let t = HTMLFormElement.prototype.cloneNode.call(e.target),
        n = e.submitter;
      if (
        (n?.formTarget || t.target) === `_blank` ||
        (n?.formMethod || t.method) !== `get`
      )
        return;
      let r = new URL(
        (n?.hasAttribute(`formaction`) && n?.formAction) || t.action
      );
      if (k(r, S, !1)) return;
      let i = e.target,
        a = O(i);
      if (a.reload) return;
      e.preventDefault(), e.stopPropagation();
      let o = new FormData(i, n);
      (r.search = new URLSearchParams(o).toString()),
        Z({
          type: `form`,
          url: r,
          keepfocus: a.keepfocus,
          noscroll: a.noscroll,
          replace_state: a.replace_state ?? r.href === location.href,
          event: e,
        });
    }),
    addEventListener(`popstate`, async (t) => {
      if (!Ht) {
        if (t.state?.[`sveltekit:history`]) {
          let n = t.state[C];
          if (((X = {}), n === J)) return;
          let r = N[n],
            i = t.state[`sveltekit:states`] ?? {},
            a = new URL(t.state[`sveltekit:pageurl`] ?? location.href),
            o = t.state[w],
            s = W.url ? m(location) === m(W.url) : !1;
          if (o === Y && (tt || s)) {
            i !== A.state && (A.state = i),
              e(a),
              (N[J] = E()),
              r && scrollTo(r.x, r.y),
              (J = n);
            return;
          }
          let c = n - J;
          await Z({
            type: `popstate`,
            url: a,
            popped: { state: i, scroll: r, delta: c },
            accept: () => {
              (J = n), (Y = o);
            },
            block: () => {
              history.go(-c);
            },
            nav_token: X,
            event: t,
          });
        } else q || (e(new URL(location.href)), z.hash && location.reload());
      }
    }),
    addEventListener(`hashchange`, () => {
      q &&
        ((q = !1),
        history.replaceState(
          { ...history.state, [C]: ++J, [w]: Y },
          ``,
          location.href
        ));
    });
  for (let e of document.querySelectorAll(`link`))
    Be.has(e.rel) && (e.href = e.href);
  addEventListener(`pageshow`, (e) => {
    e.persisted && F.navigating.set((j.current = null));
  });
  function e(e) {
    (W.url = A.url = e), F.page.set(Gt(A)), F.page.notify();
  }
}
async function Bt(
  e,
  {
    status: t = 200,
    error: n,
    node_ids: r,
    params: i,
    route: a,
    server_route: o,
    data: s,
    form: c,
  }
) {
  $e = !0;
  let u = new URL(location.href),
    d;
  ({ params: i = {}, route: a = { id: null } } = (await Dt(u, !1)) || {}),
    (d = We.find(({ id: e }) => e === a.id));
  let f,
    p = !0;
  try {
    let e = r.map(async (t, n) => {
        let r = s[n];
        return (
          r?.uses && (r.uses = Vt(r.uses)),
          _t({
            loader: z.nodes[t],
            url: u,
            params: i,
            route: a,
            parent: async () => {
              let t = {};
              for (let r = 0; r < n; r += 1)
                Object.assign(t, (await e[r]).data);
              return t;
            },
            server_data_node: bt(r),
          })
        );
      }),
      o = await Promise.all(e);
    if (d) {
      let e = d.layouts;
      for (let t = 0; t < e.length; t++) e[t] || o.splice(t, 0, void 0);
    }
    f = await gt({
      url: u,
      params: i,
      branch: o,
      status: t,
      error: n,
      errors: d?.errors,
      form: c,
      route: d ?? null,
    });
  } catch (t) {
    if (t instanceof l) return await I(new URL(t.location, location.href));
    (f = await Tt({
      status: Ae(t),
      error: await $(t, { url: u, params: i, route: a }),
      url: u,
      route: a,
    })),
      (e.textContent = ``),
      (p = !1);
  }
  f && (f.props.page && (f.props.page.state = {}), await ht(f, e, p));
}
function Vt(e) {
  return {
    dependencies: new Set(e?.dependencies ?? []),
    params: new Set(e?.params ?? []),
    parent: !!e?.parent,
    route: !!e?.route,
    url: !!e?.url,
    search_params: new Set(e?.search_params ?? []),
  };
}
var Ht = !1;
function Ut(e, t = !0) {
  let n = document.querySelector(`[autofocus]`);
  if (n) n.focus();
  else {
    let n = qt(e);
    if (n && document.getElementById(n)) {
      let { x: r, y: i } = E();
      setTimeout(() => {
        let a = history.state;
        (Ht = !0),
          location.replace(new URL(`#${n}`, location.href)),
          history.replaceState(a, ``, e),
          t && scrollTo(r, i),
          (Ht = !1);
      });
    } else {
      let e = document.body,
        t = e.getAttribute(`tabindex`);
      (e.tabIndex = -1),
        e.focus({ preventScroll: !0, focusVisible: !1 }),
        t === null
          ? e.removeAttribute(`tabindex`)
          : e.setAttribute(`tabindex`, t);
    }
    let r = getSelection();
    if (r && r.type !== `None`) {
      let e = [];
      for (let t = 0; t < r.rangeCount; t += 1) e.push(r.getRangeAt(t));
      setTimeout(() => {
        if (r.rangeCount === e.length) {
          for (let t = 0; t < r.rangeCount; t += 1) {
            let n = e[t],
              i = r.getRangeAt(t);
            if (
              n.commonAncestorContainer !== i.commonAncestorContainer ||
              n.startContainer !== i.startContainer ||
              n.endContainer !== i.endContainer ||
              n.startOffset !== i.startOffset ||
              n.endOffset !== i.endOffset
            )
              return;
          }
          r.removeAllRanges();
        }
      });
    }
  }
}
function Wt(e, t, n, r, i = null) {
  let a,
    o,
    s = new Promise((e, t) => {
      (a = e), (o = t);
    });
  return (
    s.catch(g),
    {
      navigation: {
        from: {
          params: e.params,
          route: { id: e.route?.id ?? null },
          url: e.url,
          scroll: E(),
        },
        to: n && {
          params: t?.params ?? null,
          route: { id: t?.route?.id ?? null },
          url: n,
          scroll: i,
        },
        willUnload: !t,
        type: r,
        complete: s,
      },
      fulfil: a,
      reject: o,
    }
  );
}
function Gt(e) {
  return {
    data: e.data,
    error: e.error,
    form: e.form,
    params: e.params,
    route: e.route,
    state: e.state,
    status: e.status,
    url: e.url,
  };
}
function Kt(e) {
  let t = new URL(e);
  return (t.hash = decodeURIComponent(e.hash)), t;
}
function qt(e) {
  let t;
  if (z.hash) {
    let [, , n] = e.hash.split(`#`, 3);
    t = n ?? ``;
  } else t = e.hash.slice(1);
  return decodeURIComponent(t);
}
export {
  st as a,
  A as c,
  It as i,
  Ee as l,
  Ft as n,
  F as o,
  Lt as r,
  j as s,
  Pt as t,
};
