!(function (e) {
  "function" == typeof fuseDefine && fuseDefine.amd ? fuseDefine(e) : e();
})(function () {
  "use strict";
  var e = {
      settings: {
        account_code: "openguessr",
        account_domain_map: {},
        account_name: "Openguessr",
        account_name_domain_map: {},
        fuse_blocked_url: [],
        fuse_breakpoints: { l: 1501, m: 970, s: 728, xl: 1900, xs: 0 },
        fuse_cdn: "cdn.fuseplatform.net",
        fuse_cdn_platform: "cloudflare",
        fuse_id: 4180,
        fuse_industry: ["IAB1"],
        fuse_settings: {
          admiral: { enabled: !1 },
          afs: { enabled: !1 },
          amazonUam: { enabled: !1 },
          bidderGeoExclusions: {
            country: {
              AE: ["33across", "adyoulike", "gumgum", "oms"],
              AL: [
                "33across",
                "adagio",
                "gumgum",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "openx",
                "richaudience",
                "rubicon",
                "smartadserver",
                "smilewanted",
                "sovrn",
                "vidazoo",
              ],
              AM: [
                "33across",
                "adagio",
                "amx",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "medianet",
                "nobid",
                "oms",
                "onetag",
                "openx",
                "pubmatic",
                "pubxai",
                "richaudience",
                "seedtag",
                "smartadserver",
                "smilewanted",
                "sovrn",
                "vidazoo",
              ],
              AR: ["33across", "adyoulike", "gumgum", "nobid", "vidazoo"],
              AT: ["33across", "adyoulike"],
              AU: ["nobid"],
              AZ: [
                "33across",
                "adagio",
                "appnexus",
                "criteo",
                "gumgum",
                "kueezrtb",
                "nobid",
                "oms",
                "pubmatic",
                "richaudience",
                "smilewanted",
                "vidazoo",
              ],
              BA: [
                "33across",
                "adagio",
                "adyoulike",
                "criteo",
                "gumgum",
                "kueezrtb",
                "oms",
                "pubmatic",
                "smilewanted",
                "vidazoo",
              ],
              BD: [
                "33across",
                "adagio",
                "adyoulike",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "onetag",
                "smartadserver",
                "smilewanted",
                "vidazoo",
              ],
              BE: ["33across", "adyoulike", "nobid"],
              BG: [
                "33across",
                "adyoulike",
                "gumgum",
                "medianet",
                "nobid",
                "smilewanted",
                "vidazoo",
              ],
              BH: [
                "33across",
                "adagio",
                "amx",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "onetag",
                "openx",
                "pubmatic",
                "richaudience",
                "rubicon",
                "smilewanted",
                "sovrn",
              ],
              BR: ["33across", "adyoulike", "gumgum"],
              BY: [
                "33across",
                "adyoulike",
                "amx",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "openx",
                "pubmatic",
                "pubxai",
                "richaudience",
                "rubicon",
                "seedtag",
                "smilewanted",
                "vidazoo",
              ],
              CH: ["33across"],
              CL: ["33across", "adyoulike", "gumgum", "smilewanted", "vidazoo"],
              CO: [
                "33across",
                "adyoulike",
                "gumgum",
                "kueezrtb",
                "smilewanted",
                "vidazoo",
              ],
              CR: [
                "33across",
                "adagio",
                "appnexus",
                "gumgum",
                "nobid",
                "pubxai",
                "smilewanted",
              ],
              CY: [
                "33across",
                "gumgum",
                "kueezrtb",
                "medianet",
                "oms",
                "richaudience",
                "seedtag",
                "smartadserver",
                "smilewanted",
                "vidazoo",
              ],
              CZ: ["33across", "adyoulike", "gumgum", "smilewanted", "vidazoo"],
              DE: ["33across", "adyoulike"],
              DK: ["33across", "adyoulike"],
              DO: [
                "33across",
                "adagio",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "onetag",
                "openx",
                "pubmatic",
                "smilewanted",
                "sovrn",
              ],
              DZ: [
                "33across",
                "adagio",
                "amx",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "onetag",
                "openx",
                "pubmatic",
                "pubxai",
                "richaudience",
                "rubicon",
                "seedtag",
                "smartadserver",
                "smilewanted",
                "sovrn",
                "vidazoo",
              ],
              EC: [
                "33across",
                "adagio",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "smilewanted",
                "vidazoo",
              ],
              EE: ["33across", "adyoulike", "vidazoo"],
              EG: [
                "33across",
                "adagio",
                "adyoulike",
                "appnexus",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "pubmatic",
                "pubxai",
                "smilewanted",
                "sovrn",
                "vidazoo",
              ],
              ES: ["33across", "adyoulike"],
              ET: [
                "33across",
                "adagio",
                "amx",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "onetag",
                "openx",
                "pubmatic",
                "richaudience",
                "rubicon",
                "smartadserver",
                "smilewanted",
                "sovrn",
              ],
              FI: ["33across", "adyoulike", "vidazoo"],
              FR: ["33across", "adyoulike"],
              GB: ["33across"],
              GE: [
                "33across",
                "adyoulike",
                "appnexus",
                "criteo",
                "gumgum",
                "kueezrtb",
                "nobid",
                "pubmatic",
                "richaudience",
                "smilewanted",
                "vidazoo",
              ],
              GR: [
                "33across",
                "adyoulike",
                "gumgum",
                "nobid",
                "smilewanted",
                "vidazoo",
              ],
              GT: [
                "33across",
                "adagio",
                "appnexus",
                "criteo",
                "gumgum",
                "kueezrtb",
                "nobid",
                "oms",
                "richaudience",
                "smilewanted",
              ],
              HK: ["33across", "adyoulike"],
              HR: [
                "33across",
                "adyoulike",
                "gumgum",
                "medianet",
                "nobid",
                "smilewanted",
                "vidazoo",
              ],
              HU: ["33across", "adyoulike", "gumgum", "vidazoo"],
              ID: [
                "33across",
                "adyoulike",
                "nobid",
                "pubxai",
                "smilewanted",
                "vidazoo",
              ],
              IE: ["33across", "adyoulike"],
              IL: [
                "33across",
                "adyoulike",
                "gumgum",
                "nobid",
                "smilewanted",
                "vidazoo",
              ],
              IN: ["33across", "adyoulike", "gumgum", "nobid", "vidazoo"],
              IQ: [
                "33across",
                "adagio",
                "appnexus",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "onetag",
                "pubmatic",
                "pubxai",
                "richaudience",
                "seedtag",
                "smilewanted",
                "sovrn",
                "vidazoo",
              ],
              IS: [
                "33across",
                "adagio",
                "criteo",
                "gumgum",
                "insticator",
                "medianet",
                "nobid",
                "oms",
                "richaudience",
                "smartadserver",
                "smilewanted",
                "vidazoo",
              ],
              IT: ["33across"],
              JE: [
                "33across",
                "adagio",
                "amx",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "onetag",
                "openx",
                "pubmatic",
                "richaudience",
                "rubicon",
                "smilewanted",
                "sovrn",
              ],
              JO: [
                "33across",
                "adagio",
                "appnexus",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "openx",
                "pubmatic",
                "pubxai",
                "richaudience",
                "rubicon",
                "smilewanted",
                "sovrn",
                "vidazoo",
              ],
              JP: ["33across", "adyoulike", "smilewanted", "vidazoo"],
              KE: [
                "33across",
                "adagio",
                "amx",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "onetag",
                "openx",
                "pubmatic",
                "richaudience",
                "rubicon",
                "seedtag",
                "smartadserver",
                "smilewanted",
                "vidazoo",
              ],
              KG: [
                "33across",
                "adagio",
                "amx",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "nobid",
                "oms",
                "openx",
                "pubmatic",
                "richaudience",
                "rubicon",
                "smartadserver",
                "smilewanted",
                "sovrn",
                "vidazoo",
              ],
              KH: [
                "33across",
                "adagio",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "onetag",
                "pubxai",
                "seedtag",
                "smilewanted",
                "sovrn",
                "vidazoo",
              ],
              KR: [
                "33across",
                "adagio",
                "adyoulike",
                "gumgum",
                "nobid",
                "smilewanted",
                "vidazoo",
              ],
              KW: [
                "33across",
                "appnexus",
                "criteo",
                "gumgum",
                "kueezrtb",
                "nobid",
                "oms",
                "richaudience",
                "smilewanted",
              ],
              KZ: [
                "33across",
                "adyoulike",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "nobid",
                "richaudience",
                "smilewanted",
                "vidazoo",
              ],
              LB: [
                "33across",
                "adagio",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "pubmatic",
                "richaudience",
                "smartadserver",
                "smilewanted",
                "sovrn",
                "vidazoo",
              ],
              LK: [
                "33across",
                "adagio",
                "amx",
                "appnexus",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "onetag",
                "richaudience",
                "smartadserver",
                "smilewanted",
                "sovrn",
                "vidazoo",
              ],
              LT: ["33across", "adyoulike", "gumgum", "vidazoo"],
              LU: [
                "33across",
                "gumgum",
                "nobid",
                "richaudience",
                "smilewanted",
                "vidazoo",
              ],
              LV: [
                "33across",
                "adyoulike",
                "gumgum",
                "nobid",
                "richaudience",
                "vidazoo",
              ],
              MA: [
                "33across",
                "adagio",
                "appnexus",
                "gumgum",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "pubxai",
                "smartadserver",
                "smilewanted",
                "sovrn",
                "vidazoo",
              ],
              MD: [
                "33across",
                "adagio",
                "appnexus",
                "gumgum",
                "medianet",
                "nobid",
                "oms",
                "pubxai",
                "richaudience",
                "smilewanted",
                "vidazoo",
              ],
              ME: [
                "33across",
                "appnexus",
                "criteo",
                "gumgum",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "pubmatic",
                "pubxai",
                "richaudience",
                "smartadserver",
                "smilewanted",
                "vidazoo",
              ],
              MK: [
                "33across",
                "adagio",
                "adyoulike",
                "amx",
                "gumgum",
                "insticator",
                "kueezrtb",
                "oms",
                "pubmatic",
                "richaudience",
                "smilewanted",
                "vidazoo",
              ],
              MN: [
                "33across",
                "adagio",
                "amx",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "onetag",
                "openx",
                "pubmatic",
                "richaudience",
                "rubicon",
                "smartadserver",
                "smilewanted",
                "sovrn",
                "vidazoo",
              ],
              MT: [
                "33across",
                "criteo",
                "gumgum",
                "nobid",
                "oms",
                "pubxai",
                "richaudience",
                "smilewanted",
                "vidazoo",
              ],
              MX: ["33across", "adyoulike"],
              MY: [
                "33across",
                "adyoulike",
                "nobid",
                "oms",
                "pubxai",
                "smilewanted",
                "vidazoo",
              ],
              NL: ["33across", "adyoulike"],
              NO: ["33across", "adyoulike", "vidazoo"],
              NP: [
                "33across",
                "adagio",
                "adyoulike",
                "appnexus",
                "gumgum",
                "insticator",
                "kueezrtb",
                "nobid",
                "oms",
                "openx",
                "pubxai",
                "richaudience",
                "smartadserver",
                "smilewanted",
                "vidazoo",
              ],
              NZ: ["adyoulike", "nobid"],
              OM: [
                "33across",
                "adagio",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "pubmatic",
                "richaudience",
                "smilewanted",
                "sovrn",
              ],
              PA: [
                "33across",
                "adagio",
                "amx",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "nobid",
                "oms",
                "richaudience",
                "rubicon",
                "smilewanted",
              ],
              PE: [
                "33across",
                "adagio",
                "adyoulike",
                "gumgum",
                "nobid",
                "smilewanted",
                "vidazoo",
              ],
              PH: ["33across", "adyoulike", "pubxai", "smilewanted"],
              PK: [
                "33across",
                "adagio",
                "adyoulike",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "pubxai",
                "richaudience",
                "seedtag",
                "smartadserver",
                "smilewanted",
                "sovrn",
                "vidazoo",
              ],
              PL: ["33across", "adyoulike", "gumgum"],
              PR: [
                "33across",
                "adagio",
                "criteo",
                "gumgum",
                "kueezrtb",
                "nobid",
                "pubmatic",
                "richaudience",
                "smilewanted",
                "sovrn",
              ],
              PT: ["33across", "adyoulike", "smilewanted", "vidazoo"],
              PY: [
                "33across",
                "adagio",
                "amx",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "openx",
                "richaudience",
                "smartadserver",
                "smilewanted",
                "sovrn",
              ],
              QA: [
                "33across",
                "gumgum",
                "medianet",
                "nobid",
                "oms",
                "richaudience",
                "smilewanted",
                "vidazoo",
              ],
              RO: ["33across", "adyoulike", "gumgum", "nobid", "vidazoo"],
              RS: [
                "33across",
                "adyoulike",
                "gumgum",
                "kueezrtb",
                "nobid",
                "oms",
                "pubmatic",
                "smilewanted",
                "vidazoo",
              ],
              RU: [
                "33across",
                "adagio",
                "adyoulike",
                "amx",
                "criteo",
                "gumgum",
                "kueezrtb",
                "medianet",
                "onetag",
                "pubmatic",
                "pubxai",
                "richaudience",
                "seedtag",
                "smilewanted",
                "sovrn",
                "vidazoo",
              ],
              SA: [
                "33across",
                "adyoulike",
                "gumgum",
                "nobid",
                "smilewanted",
                "vidazoo",
              ],
              SE: ["33across"],
              SG: ["33across", "adyoulike"],
              SI: [
                "33across",
                "adyoulike",
                "gumgum",
                "medianet",
                "smilewanted",
                "vidazoo",
              ],
              SK: ["33across", "adyoulike", "gumgum", "smilewanted", "vidazoo"],
              TH: [
                "33across",
                "adyoulike",
                "nobid",
                "pubxai",
                "smilewanted",
                "vidazoo",
              ],
              TN: [
                "33across",
                "adagio",
                "amx",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "onetag",
                "openx",
                "pubmatic",
                "pubxai",
                "richaudience",
                "rubicon",
                "seedtag",
                "smartadserver",
                "smilewanted",
                "vidazoo",
              ],
              TR: [
                "33across",
                "adyoulike",
                "gumgum",
                "nobid",
                "smilewanted",
                "vidazoo",
              ],
              TT: [
                "33across",
                "adagio",
                "amx",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "pubmatic",
                "richaudience",
                "rubicon",
                "smartadserver",
                "smilewanted",
                "sovrn",
              ],
              TW: [
                "33across",
                "adyoulike",
                "gumgum",
                "kueezrtb",
                "nobid",
                "smilewanted",
                "vidazoo",
              ],
              UA: [
                "33across",
                "adagio",
                "adyoulike",
                "amx",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "nobid",
                "oms",
                "pubmatic",
                "richaudience",
                "smilewanted",
                "vidazoo",
              ],
              UY: [
                "33across",
                "adagio",
                "criteo",
                "gumgum",
                "kueezrtb",
                "nobid",
                "oms",
                "pubxai",
                "smilewanted",
                "sovrn",
                "vidazoo",
              ],
              UZ: [
                "33across",
                "appnexus",
                "criteo",
                "gumgum",
                "kueezrtb",
                "nobid",
                "richaudience",
                "smilewanted",
                "vidazoo",
              ],
              VE: [
                "33across",
                "adagio",
                "amx",
                "appnexus",
                "criteo",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "openx",
                "pubmatic",
                "pubxai",
                "richaudience",
                "seedtag",
                "smartadserver",
                "smilewanted",
                "sovrn",
              ],
              VN: [
                "33across",
                "adagio",
                "adyoulike",
                "kueezrtb",
                "nobid",
                "oms",
                "pubxai",
                "smilewanted",
                "vidazoo",
              ],
              XK: [
                "33across",
                "adagio",
                "adyoulike",
                "appnexus",
                "gumgum",
                "insticator",
                "kueezrtb",
                "medianet",
                "nobid",
                "oms",
                "onetag",
                "openx",
                "pubmatic",
                "richaudience",
                "smartadserver",
                "smilewanted",
                "sovrn",
                "vidazoo",
              ],
              ZA: ["33across", "adyoulike", "gumgum", "oms"],
            },
          },
          blockthrough: !0,
          cmp: "script",
          cmpProvider: { partner: "fundingchoices" },
          confiant: !0,
          confiantId: "6uPAEf1kzkZykYQ3BH9Z8BUTQEE",
          disableAutoLoadSlots: !1,
          disableGdprPersonalisation: !1,
          enableAutoRegistration: !1,
          enableIntentIQ: !0,
          enableMiniScrollers: !1,
          forceSafeFrame: !1,
          fullScreenAdExpansion: 5,
          fuse_test_urls: [],
          gptUseNewApiPageSettings: 95,
          gptUseNewApiPageTargeting: 95,
          gptUseNewApiSlotTargeting: 95,
          headerbidding: 1e3,
          id5: { enabled: !0, partnerId: 1189 },
          identity: { enabled: !1 },
          in2wAdvertiserId: 5068036699,
          in2wInjection: 95,
          in2wRatio: 0.9,
          in2wSafeframe: !1,
          inskinWidth: 1200,
          intentIQVersion: "iiq-latest",
          networkAccountParams: {
            "33across": {
              siteId: {
                serverclient: [
                  {
                    accountCode: "openguessr",
                    parameterValue: "bCbwaiXWqr8ikbrkHcnnVW",
                  },
                ],
              },
            },
            adagio: {
              site: {
                serverclient: [
                  {
                    accountCode: "openguessr",
                    parameterValue: "openguessr-com",
                  },
                ],
              },
            },
            adyoulike: {
              placement: {
                serverclient: [
                  {
                    accountCode: "openguessr",
                    parameterValue: "7a0795764fdaede7e6ad700e1785a4bb",
                  },
                ],
              },
              placement300x250: {
                serverclient: [
                  {
                    accountCode: "openguessr",
                    parameterValue: "b56e8fd395fd5a86fff1cd94c52cd592",
                  },
                ],
              },
            },
            appnexus: {
              placement_id: {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: 36814674 },
                ],
              },
            },
            criteo: {
              pubid: {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "112095" },
                ],
              },
            },
            gumgum: {
              slot: {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: 1355239 },
                ],
              },
              zone: {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "bzwjmere" },
                ],
              },
            },
            medianet: {
              crid: {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "633209149" },
                ],
              },
            },
            nobid: {
              siteId: {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: 206007 },
                ],
              },
            },
            openx: {
              unit: {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "564240610" },
                ],
              },
            },
            richaudience: {
              supplyType: {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "site" },
                ],
              },
            },
            rubicon: {
              siteId: {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: 615507 },
                ],
              },
              zoneId: {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: 3983121 },
                ],
              },
            },
            seedtag: {
              publisherId: {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "8851-5321-01" },
                ],
              },
            },
            sovrn: {
              "120x600": {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "1302299" },
                ],
              },
              "160x600": {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "1302300" },
                ],
              },
              "250x250": {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "1302301" },
                ],
              },
              "300x1050": {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "1302307" },
                ],
              },
              "300x250": {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "1302304" },
                ],
              },
              "300x600": {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "1302303" },
                ],
              },
              "320x100": {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "1302312" },
                ],
              },
              "320x480": {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "1302313" },
                ],
              },
              "320x50": {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "1302310" },
                ],
              },
              "336x280": {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "1302302" },
                ],
              },
              "468x60": {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "1302308" },
                ],
              },
              "728x90": {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "1302305" },
                ],
              },
              "970x250": {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "1302311" },
                ],
              },
              "970x90": {
                serverclient: [
                  { accountCode: "openguessr", parameterValue: "1302306" },
                ],
              },
            },
            ttd: {
              publisherId: {
                serverclient: [
                  {
                    accountCode: "openguessr",
                    parameterValue: "01KAA6HPSWDX3ZMCM3KWPPCGRJ",
                  },
                ],
              },
            },
          },
          networkCode: "71161633",
          networkContractParams: {
            "33across": {
              productId: { serverclient: { parameterValue: "siab" } },
            },
            adagio: {
              organizationId: { serverclient: { parameterValue: "1140" } },
            },
            amx: {
              tagId: { serverclient: { parameterValue: "cHVibGlmdC5jb20" } },
            },
            criteo: { networkId: { serverclient: { parameterValue: 4130 } } },
            insticator: {
              adUnitId: {
                serverclient: { parameterValue: "01JKV5SHEG6WD9H6Q2VPZ5V0SX" },
              },
              publisherId: {
                serverclient: {
                  parameterValue: "ea7873c5-662b-4e03-a3f3-cec1a01d8a95",
                },
              },
            },
            kueezrtb: {
              cId: {
                serverclient: { parameterValue: "672357405abdfcb87eaca9cd" },
              },
              pId: {
                serverclient: { parameterValue: "65lk7c192882r0011813fn9" },
              },
            },
            medianet: {
              cid: { serverclient: { parameterValue: "8CU995W35" } },
            },
            oms: { publisherId: { serverclient: { parameterValue: "20605" } } },
            onetag: {
              pubId: { serverclient: { parameterValue: "77253abd802c05e" } },
            },
            openx: {
              delDomain: {
                serverclient: { parameterValue: "publift-d.openx.net" },
              },
            },
            pubmatic: {
              publisherId: { serverclient: { parameterValue: "156762" } },
            },
            pubxai: {
              placement: { serverclient: { parameterValue: "PUBX_PUBLIFT" } },
            },
            richaudience: {
              pid: { serverclient: { parameterValue: "MP_uUzZIc9lYN" } },
            },
            rubicon: { accountId: { serverclient: { parameterValue: 11504 } } },
            smartadserver: {
              domain: {
                client: { parameterValue: "https://prg.smartadserver.com" },
              },
              formatId: { client: { parameterValue: 116284 } },
              networkId: { client: { parameterValue: 4191 } },
              prebid_client_pageId: { client: { parameterValue: 1720333 } },
              prebid_client_siteId: { client: { parameterValue: 566977 } },
            },
            smilewanted: {
              zoneId: {
                serverclient: { parameterValue: "publift.com_hb_display" },
              },
            },
            ttd: {
              supplySourceId: { serverclient: { parameterValue: "publift" } },
            },
            vidazoo: {
              cId: {
                serverclient: { parameterValue: "66bcb2841f24a4c72df7aca4" },
              },
              pId: {
                serverclient: { parameterValue: "59ac17c192832d0011283fe3" },
              },
              subDomain: { serverclient: { parameterValue: "exchange" } },
            },
          },
          networkNetworkParams: {
            gumgum: { product: { serverclient: { parameterValue: "skins" } } },
          },
          onLoadCallback:
            "window.googletag = window.googletag || { cmd: [] };\ngoogletag.cmd.push(function () {\n  googletag.pubads().set('page_url', null);\n});",
          prebid: {
            analytics: [],
            breakpoint_options: {
              l: { enabled: !0, timeout: 1e3 },
              m: { enabled: !0, timeout: 1e3 },
              s: { enabled: !0, timeout: 1e3 },
              xl: { enabled: !0, timeout: 1e3 },
              xs: { enabled: !0, timeout: 1e3 },
            },
            defaultTimeout: 1e3,
            enabled: !0,
            sendAllBids: !1,
          },
          prebidClientBidderCodes: [
            "33across",
            "adagio",
            "amx",
            "appnexus",
            "criteo",
            "gumgum",
            "kueezrtb",
            "medianet",
            "nobid",
            "oms",
            "onetag",
            "openx",
            "pubmatic",
            "pubxai",
            "richaudience",
            "rubicon",
            "seedtag",
            "smartadserver",
            "smilewanted",
            "sovrn",
            "ttd",
            "vidazoo",
          ],
          prebidServerBidderCodes: [
            "33across",
            "adagio",
            "amx",
            "appnexus",
            "criteo",
            "gumgum",
            "kueezrtb",
            "medianet",
            "nobid",
            "oms",
            "onetag",
            "openx",
            "pubmatic",
            "richaudience",
            "rubicon",
            "seedtag",
            "smartadserver",
            "smilewanted",
            "sovrn",
            "ttd",
            "vidazoo",
          ],
          prebidTelemetrySampleRate: 1,
          preconnectDomains: [
            "ap.lijit.com",
            "bidder.criteo.com",
            "btlr.sharethrough.com",
            "fastlane.rubiconproject.com",
            "hbopenbid.pubmatic.com",
            "htlb.casalemedia.com",
            "ib.adnxs.com",
            "rtb.openx.net",
            "tlx.3lift.com",
          ],
          responsive: !0,
          strict_cmp: !1,
          tagCategories: {},
          telemetry: "default",
          topStickyHeaderSelector: "",
          useActiveViewRefresh: 5,
          useAssertiveYield: 95,
          useAuctionSlotLimit: 5,
          useBackwardCompatibleNaming: !1,
          useBannerPosSignal: 5,
          useBfcachePageReset: 5,
          useBidCacheFloors: 5,
          useComboZones: 5,
          useGamSf: !0,
          useHeavyAdRefresh: 5,
          useIncreaseInitialTimeout: 95,
          useMaxViewports: 5,
          useOrtbChromeAiRtd: 5,
          useOrtbDeviceGeo: 5,
          usePreconnectHints: 5,
          usePreloadHints: 5,
          useRefreshPrebidTimeoutBuffering: 95,
          useRefreshTimeoutExpansion: 5,
          useTestMinOnScreenDuration: 5,
          useUserSyncAuctionDelay: 5,
          videoSettings: { enabled: !1 },
          yandexBlockId: "",
        },
        fuse_slots: [
          {
            activateConditionConfig: { type: "none" },
            afsAttributes: { maxTop: "4", width: "auto" },
            attributes: {
              adblock: !1,
              afs: !1,
              comboZoneEnabled: !1,
              dynamic: !1,
              headerbidding: !0,
              interscroller: !1,
              interstitial: !1,
              manualDisplay: !1,
              miniscroller: !1,
              refresh: 30,
              scrollToStick: !1,
              sticky: !1,
            },
            bids: [],
            dynamicAttributes: {
              each: 0,
              incrementEach: 0,
              position: "in",
              repeatHeight: 1e3,
              skip: 0,
            },
            gamAdUnitId: "23326067451",
            id: "Game_incontent_1",
            interscrollerAttributes: { showBanner: !1, zIndex: 0 },
            matchedNetworks: [
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { siteId: null } },
                      contract: { mandatory: { productId: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "33acrossBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "33across",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { site: null } },
                      contract: { mandatory: { organizationId: null } },
                      zone: {
                        mandatory: { adUnitElementId: null, placement: null },
                      },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "adagioBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "adagio",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { contract: { mandatory: { tagId: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "amxBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "amx",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { account: { mandatory: { placement_id: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "appnexusBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "appnexus",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { pubid: null } },
                      contract: { mandatory: { networkId: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "criteoBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "criteo",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { slot: null, zone: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "gumgumInSlotBidconfig",
                      sizes: ["320x50", "728x90"],
                    },
                  },
                ],
                network_code: "gumgum",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      contract: { mandatory: { cId: null, pId: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "kueezrtbBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "kueezrtb",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { crid: null } },
                      contract: { mandatory: { cid: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "medianetBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "medianet",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { account: { mandatory: { siteId: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "noBidBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "nobid",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { contract: { mandatory: { publisherId: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "omsBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "oms",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { contract: { mandatory: { pubId: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "oneTagBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "onetag",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { unit: null } },
                      contract: { mandatory: { delDomain: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "openxAccountLevelUnitBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "openx",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      contract: { mandatory: { publisherId: null } },
                      zone: { mandatory: { adSlot: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "pubmaticBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "pubmatic",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { contract: { mandatory: { placement: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "pubxaiBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "pubxai",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { supplyType: null } },
                      contract: { mandatory: { pid: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "richaudienceBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "richaudience",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { siteId: null, zoneId: null } },
                      contract: { mandatory: { accountId: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "rubiconAcctSiteIdZoneIdBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "rubicon",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { publisherId: null } },
                      zone: {
                        mandatory: {
                          adUnitId: null,
                          placement: { defaultValue: "inBanner" },
                        },
                      },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "seedtagBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "seedtag",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "client",
                    fields: {
                      contract: {
                        mandatory: {
                          formatId: null,
                          networkId: null,
                          prebid_client_pageId: { renameTo: "pageId" },
                          prebid_client_siteId: { renameTo: "siteId" },
                        },
                        optional: { domain: null },
                      },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "smartAdClientBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "smartadserver",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { contract: { mandatory: { zoneId: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "smilewantedBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "smilewanted",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: {
                        mandatory: { "728x90": { renameTo: "tagid" } },
                      },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "sovrn728x90Bidconfig",
                      sizes: ["728x90"],
                    },
                  },
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: {
                        mandatory: { "320x50": { renameTo: "tagid" } },
                      },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "sovrn320x50Bidconfig",
                      sizes: ["320x50"],
                    },
                  },
                ],
                network_code: "sovrn",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { publisherId: null } },
                      contract: { mandatory: { supplySourceId: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "ttdBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "ttd",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      contract: {
                        mandatory: { cId: null, pId: null },
                        optional: { subDomain: null },
                      },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "vidazooBidconfig",
                      sizes: [
                        "300x50",
                        "300x90",
                        "320x50",
                        "320x90",
                        "380x90",
                        "450x90",
                        "468x90",
                        "640x90",
                        "728x90",
                      ],
                    },
                  },
                ],
                network_code: "vidazoo",
              },
            ],
            mediaTypes: [],
            networkZoneParameters: {
              adagio: {
                adUnitElementId: {
                  serverclient: {
                    parameterValue: "01KAGW9Q9X3X1SXSDCAGDFWT3P",
                  },
                },
                placement: {
                  serverclient: { parameterValue: "Game_incontent_1" },
                },
              },
              pubmatic: {
                adSlot: {
                  serverclient: {
                    parameterValue:
                      "/71161633/OPNGSR_openguessr/Game_incontent_1",
                  },
                },
              },
              seedtag: {
                adUnitId: { serverclient: { parameterValue: "37295787" } },
                placement: { serverclient: { parameterValue: "inBanner" } },
              },
            },
            sizeMapping: {
              l: [
                [300, 90],
                [320, 90],
                [328, 90],
                [380, 90],
                [400, 90],
                [450, 90],
                [468, 90],
                [640, 90],
                [725, 90],
                [728, 90],
              ],
              m: [
                [300, 50],
                [320, 50],
              ],
              s: [
                [300, 50],
                [320, 50],
              ],
              xl: [[728, 90]],
              xs: [
                [300, 50],
                [320, 50],
              ],
            },
            sizes: [
              [300, 50],
              [300, 90],
              [320, 50],
              [320, 90],
              [328, 90],
              [380, 90],
              [400, 90],
              [450, 90],
              [468, 90],
              [640, 90],
              [725, 90],
              [728, 90],
            ],
            slot: "/71161633,23114577746/OPNGSR_openguessr/Game_incontent_1",
            stickyAttributes: {
              allowClose: !1,
              allowReopen: !1,
              bgOpacity: 1,
              compact: !1,
              isButtonOutside: !1,
              isHideForever: !1,
              isTop: !1,
              scrollCreative: !1,
            },
          },
          {
            activateConditionConfig: { type: "none" },
            afsAttributes: { maxTop: "4", width: "auto" },
            attributes: {
              adblock: !1,
              afs: !1,
              comboZoneEnabled: !1,
              dynamic: !1,
              headerbidding: !0,
              interscroller: !1,
              interstitial: !1,
              manualDisplay: !1,
              miniscroller: !1,
              refresh: 30,
              scrollToStick: !1,
              sticky: !1,
            },
            bids: [],
            dynamicAttributes: {
              each: 0,
              incrementEach: 0,
              position: "in",
              repeatHeight: 1e3,
              skip: 0,
            },
            gamAdUnitId: "23326067511",
            id: "Game_Result_incontent_1",
            interscrollerAttributes: { showBanner: !1, zIndex: 0 },
            matchedNetworks: [
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { siteId: null } },
                      contract: { mandatory: { productId: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "33acrossBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "33across",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { site: null } },
                      contract: { mandatory: { organizationId: null } },
                      zone: {
                        mandatory: { adUnitElementId: null, placement: null },
                      },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "adagioBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "adagio",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { contract: { mandatory: { tagId: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "amxBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "amx",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { account: { mandatory: { placement_id: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "appnexusBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "appnexus",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { pubid: null } },
                      contract: { mandatory: { networkId: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "criteoBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "criteo",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { slot: null, zone: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "gumgumInSlotBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "gumgum",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      contract: { mandatory: { cId: null, pId: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "kueezrtbBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "kueezrtb",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { crid: null } },
                      contract: { mandatory: { cid: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "medianetBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "medianet",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { account: { mandatory: { siteId: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "noBidBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "nobid",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { contract: { mandatory: { publisherId: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "omsBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "oms",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { contract: { mandatory: { pubId: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "oneTagBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "onetag",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { unit: null } },
                      contract: { mandatory: { delDomain: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "openxAccountLevelUnitBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "openx",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      contract: { mandatory: { publisherId: null } },
                      zone: { mandatory: { adSlot: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "pubmaticBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "pubmatic",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { contract: { mandatory: { placement: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "pubxaiBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "pubxai",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { supplyType: null } },
                      contract: { mandatory: { pid: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "richaudienceBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "richaudience",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { siteId: null, zoneId: null } },
                      contract: { mandatory: { accountId: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "rubiconAcctSiteIdZoneIdBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "rubicon",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { publisherId: null } },
                      zone: {
                        mandatory: {
                          adUnitId: null,
                          placement: { defaultValue: "inBanner" },
                        },
                      },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "seedtagBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "seedtag",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "client",
                    fields: {
                      contract: {
                        mandatory: {
                          formatId: null,
                          networkId: null,
                          prebid_client_pageId: { renameTo: "pageId" },
                          prebid_client_siteId: { renameTo: "siteId" },
                        },
                        optional: { domain: null },
                      },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "smartAdClientBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "smartadserver",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { contract: { mandatory: { zoneId: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "smilewantedBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "smilewanted",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: {
                        mandatory: { "728x90": { renameTo: "tagid" } },
                      },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "sovrn728x90Bidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "sovrn",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { publisherId: null } },
                      contract: { mandatory: { supplySourceId: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "ttdBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "ttd",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      contract: {
                        mandatory: { cId: null, pId: null },
                        optional: { subDomain: null },
                      },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "vidazooBidconfig",
                      sizes: ["728x90"],
                    },
                  },
                ],
                network_code: "vidazoo",
              },
            ],
            mediaTypes: [],
            networkZoneParameters: {
              adagio: {
                adUnitElementId: {
                  serverclient: {
                    parameterValue: "01KAGW9Q9YCPVVE249CVHCXKE0",
                  },
                },
                placement: {
                  serverclient: { parameterValue: "Game_Result_incontent_1" },
                },
              },
              pubmatic: {
                adSlot: {
                  serverclient: {
                    parameterValue:
                      "/71161633/OPNGSR_openguessr/Game_Result_incontent_1",
                  },
                },
              },
              seedtag: {
                adUnitId: { serverclient: { parameterValue: "37295786" } },
                placement: { serverclient: { parameterValue: "inBanner" } },
              },
            },
            sizeMapping: { l: [], m: [], s: [], xl: [[728, 90]], xs: [] },
            sizes: [[728, 90]],
            slot: "/71161633,23114577746/OPNGSR_openguessr/Game_Result_incontent_1",
            stickyAttributes: {
              allowClose: !1,
              allowReopen: !1,
              bgOpacity: 1,
              compact: !1,
              isButtonOutside: !1,
              isHideForever: !1,
              isTop: !1,
              scrollCreative: !1,
            },
          },
          {
            activateConditionConfig: { type: "none" },
            afsAttributes: { maxTop: "4", width: "auto" },
            attributes: {
              adblock: !1,
              afs: !1,
              comboZoneEnabled: !1,
              dynamic: !1,
              headerbidding: !0,
              interscroller: !1,
              interstitial: !1,
              manualDisplay: !1,
              miniscroller: !1,
              refresh: 30,
              scrollToStick: !1,
              sticky: !1,
            },
            bids: [],
            dynamicAttributes: {
              each: 0,
              incrementEach: 0,
              position: "in",
              repeatHeight: 1e3,
              skip: 0,
            },
            gamAdUnitId: "23329403556",
            id: "Game_Result_Mob_Only",
            interscrollerAttributes: { showBanner: !1, zIndex: 0 },
            matchedNetworks: [
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { siteId: null } },
                      contract: { mandatory: { productId: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "33acrossBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "33across",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { site: null } },
                      contract: { mandatory: { organizationId: null } },
                      zone: {
                        mandatory: { adUnitElementId: null, placement: null },
                      },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "adagioBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "adagio",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { contract: { mandatory: { tagId: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "amxBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "amx",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { account: { mandatory: { placement_id: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "appnexusBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "appnexus",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { pubid: null } },
                      contract: { mandatory: { networkId: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "criteoBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "criteo",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { slot: null, zone: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "gumgumInSlotBidconfig",
                      sizes: ["320x50"],
                    },
                  },
                ],
                network_code: "gumgum",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      contract: { mandatory: { cId: null, pId: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "kueezrtbBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "kueezrtb",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { crid: null } },
                      contract: { mandatory: { cid: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "medianetBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "medianet",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { account: { mandatory: { siteId: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "noBidBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "nobid",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { contract: { mandatory: { publisherId: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "omsBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "oms",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { contract: { mandatory: { pubId: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "oneTagBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "onetag",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { unit: null } },
                      contract: { mandatory: { delDomain: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "openxAccountLevelUnitBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "openx",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      contract: { mandatory: { publisherId: null } },
                      zone: { mandatory: { adSlot: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "pubmaticBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "pubmatic",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { contract: { mandatory: { placement: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "pubxaiBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "pubxai",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { supplyType: null } },
                      contract: { mandatory: { pid: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "richaudienceBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "richaudience",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { siteId: null, zoneId: null } },
                      contract: { mandatory: { accountId: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "rubiconAcctSiteIdZoneIdBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "rubicon",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { publisherId: null } },
                      zone: {
                        mandatory: {
                          adUnitId: null,
                          placement: { defaultValue: "inBanner" },
                        },
                      },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "seedtagBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "seedtag",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "client",
                    fields: {
                      contract: {
                        mandatory: {
                          formatId: null,
                          networkId: null,
                          prebid_client_pageId: { renameTo: "pageId" },
                          prebid_client_siteId: { renameTo: "siteId" },
                        },
                        optional: { domain: null },
                      },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "smartAdClientBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "smartadserver",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: { contract: { mandatory: { zoneId: null } } },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "smilewantedBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "smilewanted",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: {
                        mandatory: { "320x50": { renameTo: "tagid" } },
                      },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "sovrn320x50Bidconfig",
                      sizes: ["320x50"],
                    },
                  },
                ],
                network_code: "sovrn",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      account: { mandatory: { publisherId: null } },
                      contract: { mandatory: { supplySourceId: null } },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "ttdBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "ttd",
              },
              {
                matched_schemas: [
                  {
                    bid_type: "serverclient",
                    fields: {
                      contract: {
                        mandatory: { cId: null, pId: null },
                        optional: { subDomain: null },
                      },
                    },
                    matched_schema: {
                      runtime_criteria: [],
                      schema_name: "vidazooBidconfig",
                      sizes: ["300x50", "320x50"],
                    },
                  },
                ],
                network_code: "vidazoo",
              },
            ],
            mediaTypes: [],
            networkZoneParameters: {
              adagio: {
                adUnitElementId: {
                  serverclient: {
                    parameterValue: "01KC46PD2ZQRZMA9CW25RH6DXR",
                  },
                },
                placement: {
                  serverclient: { parameterValue: "Game_Result_Mob_Only" },
                },
              },
              pubmatic: {
                adSlot: {
                  serverclient: {
                    parameterValue:
                      "/71161633/OPNGSR_openguessr/Game_Result_Mob_Only",
                  },
                },
              },
              seedtag: {
                adUnitId: { serverclient: { parameterValue: "37295788" } },
                placement: { serverclient: { parameterValue: "inBanner" } },
              },
            },
            sizeMapping: {
              l: [
                [300, 50],
                [320, 50],
              ],
              m: [
                [300, 50],
                [320, 50],
              ],
              s: [
                [300, 50],
                [320, 50],
              ],
              xl: [],
              xs: [
                [300, 50],
                [320, 50],
              ],
            },
            sizes: [
              [300, 50],
              [320, 50],
            ],
            slot: "/71161633,23114577746/OPNGSR_openguessr/Game_Result_Mob_Only",
            stickyAttributes: {
              allowClose: !1,
              allowReopen: !1,
              bgOpacity: 1,
              compact: !1,
              isButtonOutside: !1,
              isHideForever: !1,
              isTop: !1,
              scrollCreative: !1,
            },
          },
        ],
        fuse_tenant: "publift",
        sco: { asi: "publift.com", sellerId: "01KAA6HPSWDX3ZMCM3KWPPCGRJ" },
        tenantId: "DGKSPXNV53",
        fuse_flavour: "cf-default",
        fuse_uuid: "f8e29f96-1d14-5318-bbdf-b767cdc6bab8",
        publication_metadata: {
          publication_id: 4,
          generation_version: "4.1709348.0",
          generation_time: "2026-10-30T11:05:37.438Z",
          revision: "v6",
          prebid_version: "9.53.5",
        },
        fuse_prebid_hash:
          "9.53.5-8ab738b3837e09e05fbdefe1a5f2239c298e92072bb6ecf79da83a8564607cdb",
      },
      onLoadCallback: (e, t, n, i) => {
        (window.googletag = window.googletag || { cmd: [] }),
          googletag.cmd.push(function () {
            googletag.pubads().set("page_url", null);
          });
      },
      in2wHook: (e, t, n, i, r, o, a) => {
        !(function (t, n, i, r, o, a, s) {
          try {
            if (
              (e.__iwcshook__ && e.__iwcshook__(),
              n &&
                0 !== n.length &&
                i &&
                r &&
                o &&
                a &&
                s &&
                ((t.googletag = t.googletag || {}),
                (t.googletag.cmd = t.googletag.cmd || []),
                t.googletag.cmd.push) &&
                !t.googletag.__yb_init)
            ) {
              t.googletag.__yb_init = 1;
              var c,
                u = function () {
                  c = Date.now();
                },
                l = e.document.hasFocus();
              l && u();
              try {
                e.addEventListener("focus", function () {
                  try {
                    (l = !0), u();
                  } catch (e) {}
                }),
                  e.addEventListener("focusin", function () {
                    try {
                      (l = !0), u();
                    } catch (e) {}
                  }),
                  e.addEventListener("blur", function () {
                    try {
                      l = e.document.hasFocus();
                    } catch (e) {}
                  }),
                  e.addEventListener("focusout", function () {
                    try {
                      l = e.document.hasFocus();
                    } catch (e) {}
                  });
                for (
                  var d = "mousedown scroll touchstart touchend".split(" "),
                    f = 0;
                  f < d.length;
                  f++
                )
                  e.addEventListener(d[f], u);
              } catch (a) {}
              var g,
                m = function (e) {
                  return parseInt(100 * e + 1e-4);
                },
                v = (function () {
                  for (
                    var e = [
                        "0.01~0.01~1vi8sg0,1v2sw74#e8eqyo,dsyups#1dqyry8,1dbivpc#n41r7k,moluyo#1mmls74,1m75vy8#5crqps,4xbugw#14vbrpc,14fvvgg#rjv9c0,r4fd34#1r2fabk,1qmze2o#9sl8u8,9d5clc#19b59ts,18vpdkw#io8934,i8scu8#1i6sa2o,1hrcdts#wy8lc,hiccg#10fi9kw,1002dc0#y7liio,xs5m9s#1xq5ji8,1xapn9c#ggbi0w,g0vls0#1fyvj0g,1fjfmrk#pbyi9s,owim0w#1ouij9c,1of2n0g#7kohs0,758lj4#1738irk,16nsmio#trs0e8,tcc45c#1tac1ds,1suw54w#c0hzwg,bl23nk#1bj20w0,1b3m4n4#kw505c,1kep14w,1jz94w0,kgp3wg",
                        "0.01~0.3~34uznk,2pf3eo#12nf0n4,127z4e8#x3n4zk,wo78qo#1wm75z4,1w6r9q8#fcd4hs,ewx88w#1eux5hc,1efh98g#o804qo,nsk8hs#1nqk5q8,1nb49hc#6gq48w,61a800#15za58g,15ju8zk#sntmv4,s8dqm8#1s6dnuo,1rqxrls#awjmdc,ah3q4g#1af3ncw,19znr40#js6mm8,jcqqdc#1jaqnls,1ivarcw#20wm4g,1lgpvk#11jgn40,1140qv4#zbjw1s,yw3zsw#1yu3x1c,1yeo0sg#hk9vk0,h4tzb4#1h2twjk,1gne0ao#qfwvsw,q0gzk0#1pygwsg,1pj10jk#8omvb4,896z28#1876wao,17rr01s#1ueaeww,uvqdxc,1tyuio0,ugahog#d4gdfk,cp0h6o",
                        "0.01~0.59~1cn0ef4,1c7ki68#m03dog,lknhfk#1lineo0,1l37if4#48td6o,3tdgxs#13rde68,13bxhxc#vfpkow,w481z4#1uy9log,1vms2yo#dofk74,ecy1hc#1d6zl6o,1dvi2gw#mk2kg0,n8l1q8#1m2mlfk,1mr52ps#4ssjy8,5hb18g#14bckxs,14zv280#qzw2kg,roejuo#1qig3k0,1r6yku8#98m22o,9x4jcw#18r6328,19fokcg#i492bk,isrjls#1hmt3b4,1ibbklc#cz1ts,11hj40#zvj2tc,10k1k3k#xnmbr4,yc4t1c#1x66cqo,1xuou0w#fwcb9c,gkusjk#1fewc8w,1g3etj4#orzbi8,pghssg#1oajchs,1oz1ts0#70pb0g,7p7sao#16j9c00,177rta8#t7stmo,twbaww#1sqcum8,1tevbwg#bgit4w,c51af4#1az2u4g,1bnlbeo#kc5tds,l0oao0#1jupudc,1kj8bnk#2kvsw0,39ea68#123ftvk,12ryb5s#wjny80,x86fi8#1w27z7k,1wqqghs#esdxq8,fgwf0g#1eaxyps,1ezgg00#no0xz4,ocjf9c#1n6kyyo,1nv3g8w#5wqxhc,6l9erk#15faygw,163tfr4#s3ug3k,sscxds#1rmeh34,1sawydc#ackfls,b12ww0#19v4glc,1ajmxvk#j87fuo,jwpx4w#1iqrgu8,1jf9y4g#1gxfcw,25fwn4#10zhgcg,11nzxmo#yrkpa8,1ya4q9s,zg36kg,1yyn7k0#h0aosg,hot62o#1giups0,1h7d728#pvxp1c,qkg6bk",
                        "0.01~1.17~1pehq0w,1q307b4#84nojk,8t65ts#17n7pj4,18bq6tc#ubr75s,v09og0#1tub85c,1uitpfk#ckh6o0,d8zny8#1c317nk,1crjoxs#lg46ww,m4mo74#1kyo7wg,1ln6p6o#3ou6f4,4dcnpc#137e7eo,13vwoow#vpp62o,va99ts#1v89728,1ustatc#dyf5kw,diz9c0#1dgz6kg,1d1jabk#mu25ts,mem9kw#1mcm6tc,1lx6akg#52s5c0,4nc934#14lc6bk,145wa2o#r9vny8,qufrpc#1qsfoxs,1qczsow#9ilngg,935r7k#1915og0,18lps74#ie8npc,hysrgg#1hwsoow,1hhcsg0#myn7k,7iqyo#105io74,zq2ry8#xxlx4w,xi60w0#1xg5y4g,1x0q1vk#g6bwn4,fqw0e8#1fovxmo,1f9g1ds#p1yww0,omj0n4#1okixvk,1o531mo#7aowe8,6v905c#16t8xds,16dt14w#thsf0g,t2cirk#1t0cg00,1skwjr4#bqieio,bb2i9s#1b92fi8,1atmj9c#km5erk,k6piio#1k4pfr4,1jp9ji8#2uve9s,2ffi0w#12dff9c,11xzj0g#wtnjls,we7ncw#1wc7klc,1vwrocg#f2dj40,emxmv4#1ekxk3k,1e5hnuo#ny0jcw,nikn40#1ngkkcg,1n14o3k#66qiv4,5ramm8#15pajuo,159unls#sdu1hc,rye58g#1rwe2gw,1rgy680#amk0zk,a744qo#1a541z4,19po5q8#ji718g,j2r4zk#1j0r280,1ilb5z4#1qx0qo,1bh4hs#119h1q8,10u15hc#z1kao0,ym4ef4#1yk4bnk,1y4ofeo#haaa68,guudxc#1gsub5s,1gdeeww#q5xaf4,pqhe68#1pohbeo,1p91f5s#8en9xc,7z7dog#17x7aww,17hreo0#ulqsjk,u6awao#1u4atj4,1touxa8#cugs1s,cf0vsw#1cd0t1c,1bxkwsg#lq3sao,lanw1s#1l8nta8,1kt7x1c#3ytrsw,3jdvk0#13hdssg,131xwjk#v5pzb4,vu8glc#1uoa0ao,1vcshkw#defytc,e2yg3k#1cwzzsw,1dlih34#ma2z28,mylgcg#1lsn01s,1mh5hc0#4isykg,57bfuo#141czk0,14pvgu8#1q8gi68,qpwh6o,1qwyzgg,reeygw",
                        "0.02~2.02~8ymgow,18h6hog,9n4xz4,195oyyo#hu9gxs,1hcthxc,1i1bz7k,iiry80#2zgg0,zljhfk,rhxq8,10a1yps#xdmqdc,1ww6rcw,y257nk",
                        "0.01~2.09~1xkp8n4#fmcpvk,gav75s#1f4wqv4,1ftf85c#ohzq4g,p6i7eo#1o0jr40,1op28e8#6qppmo,7f86ww#1699qm8,16xs7wg#sxt88w,tmbpj4#1sgd98g,1t4vqio#b6j7r4,bv1p1c#1ap38qo,1bdlq0w#k26800,kqopa8#1jkq8zk,1k98q9s#2aw7i8,2zeosg#11tg8hs,12hyps0#w9ocu8,wy6u4g#1vs8dts,eieccg,f6wtmo,1wgqv40",
                        "0.02~2.27~1e0ydc0,ne1clc,1epgum8,o2jtvk#1mwldkw,5mrc3k,1nl3uv4,6b9tds#155bd34,rtuups,15ttudc,sidc00#1rcevpc,1s0xczk",
                        "0.01~2.34~a2ku80,ar3bi8#19l4v7k,1a9nchs#iy7ugw,jmqbr4#1igrvgg,1j5acqo#16xtz4,1vgb9c#10phuyo,11e0c8w#yhl3wg,z63l6o#1y054w0,1yonm68#gqb3eo,hetkow#1g8v4e8,1gxdlog#ply3nk,qagkxs#1p4i4n4,1pt0lxc#7uo35s,8j6kg0#17d845c,181qlfk#u1rls0,uqa328#1tkbmrk,1u8u41s#cahla8,1bt1m9s,1chk3k0,cz02kg",
                        "0.02~2.52~1koomio,l64lj4,1ld73sw,lun2tc#3eul1c,12xem0w,43d2bk,13lx3b4#w4ok5c,vf92io",
                        "0.01~2.57~1vn8l4w,1uxt3i8#edejnk,dnz20w#1dvykn4,1d6j30g#n91jwg,mjm29s#1mrlkw0,1m2639c#5hrjeo,4sc1s0#150bke8,14aw2rk#rov20w,qzfke8#1r7f30g,1qhzlds#9xl1j4,985jwg#19g52io,18qpkw0#it81s0,i3sk5c#1ibs2rk,1hmcl4w#11y1a8,cijnk#10ki29s,zv2kn4#yclb7k,xn5tkw#1xv5c74,1x5pukg#glbaps,fvvt34#1g3vbpc,1fefu2o#pgyayo,oritc0#1oziby8,1oa2ubk#7poagw,708su8#1788bgg,16istts#twrt34,t7cbgg#1tfbu2o,1spwcg0#c5hslc,bg2ayo#1bo1tkw,1aymby8#l14su8,kbpb7k#1kjotts,1ju9c74#39uscg,2kfaps#12setc0,122zbpc#x8mxog,wj7g1s#1wr6yo0,1w1rh1c#fhcx6o,erxfk0#1ezwy68,1eahgjk#oczxfk,nnkfsw#1nvjyf4,1n64gsg#6lpwxs,5wafb4#1649xxc,15eugao#sstfk0,s3dxxc#1sbdgjk,1rlxyww#b1jf28,ac3xfk#1ak3g1s,19unyf4#jx6fb4,j7qxog",
                        "0.05~3.05~1yz3pq8,1y9o83k#8tmo00,8476dc#1cs0740,1c2kphc#vkpdds,vz89a8#1m7me4g,1mm5a0w#9dlurk,9s4qo0#100ivi8,10f1reo#owz474,pbi03k#1svcnb4,1t9vj7k#2pvlkw,34ehhc#1efxreo,1eugnb4#s8u8sg,snd4ow#1ivr9j4,1jaa5fk#h5ahhc,hjtdds#17s7i80,186qe4g#ll3zls,lzmvi8#1vd8zr4,1unti4g#57ry0w,4icge8#1965h4w,18gpzi8#y2lpts,xd6874#1opiqkg,1o038xs",
                        "0.06~4.09~bvi77k,b62pkw#12if7y8,11szqbk",
                        "0.05~4.2~o30c1s,ndkuf4#1s1dv5s,1rbydj4#1vwtfk,16hbsw",
                        "0.06~4.34~1gxu3uo,1g8em80#uqql8g,u1b3ls",
                        "0.05~4.45~1ldnlz4,1ko84cg#djfri8,dxyneo#146cs8w,14kvo5c",
                        "0.06~4.59~hz99mo,ids5j4#1x16k1s,1xfpfy8",
                        "0.05~4.7~6vpibk,7a8e80#1au31fk,1b8lxc0#weo5j4,wt71fk",
                        "0.06~4.84~1n1l69s,1ng4268#a7kmww,am3itc",
                        "0.05~4.95~10uhnnk,1190jk0#pqxwcg,q5gs8w#1tpbfgg,1u3ubcw",
                        "0.06~5.09~3judq8,3yd9mo#1dogvls,1d90zcw",
                        "0.05~5.2~rhdczk,r1xgqo#1i4adq8,1houhhc#gdtlog,fydpfk#170qmf4,16laq68#ktn3sw,ke77k0#1wjp9mo,1w49dds#6e87wg,5ysbnk#1aclr0g,19x5urk#z91zpc,ytm3gg#1pvz0g0,1pgj474#d1yh34,cmiku8#13ovhts,139flkw#mhko3k,n635ds#1qfy77k,1r4gohs#ah5hc,yzmrk#1fcefwg,1g0wx6o#t5axa8,tttekg#1js7y0w,1kgqfb4#epw1ds,feeio0#15ct24g,161bjeo#j5pji8,ju80sg#1y7mtxc,1yw5b7k#825s74,8qo9hc#1c0jbb4,1cp1slc#vn79q8,v7rdhc#1ma4agw,1luoe80#9g3r40,90nuv4#1030ruo,znkvls#ozh0jk,ok14ao#1sxujnk,1sieneo#2sdhxc,2cxlog#1eifnr4,1e2zri8#sbc54w,rvw8w0#1iy95vk,1iit9mo#h7sdts,gschkw#17upekg,17f9ibk#lnlvy8,l85zpc#1uls3y8,1vaal8g#4gb280,54tji8#18eolc0,19372m8#xb4u0w,xznbb4#1ny1urk,1omkc1s#b41beo,bsjsow#11qyc5c,12fgtfk#nbjg8w,o01xj4#1r9wzcw,1ryfgn4#14fxmo,1syeww#1g6d81s,1guvpc0#tz9pfk,uns6ps#1km6q68,1lap7gg#eawnb4,dlh5og#14xto1s,148e6f4#iqq5fk,i1answ#1xsnfuo,1x37y80#7n6e4g,6xqwhs#1bljx8g,1aw4fls#x651c0,wgpjpc",
                        "0.5~8.5~fyu7ls,gdd3i8#mwk268,m74kjk#8h569s,7rpon4#rwcr28,savmyo#c1qy2o,bmb1ts#i5i0hs,iu0hs0#3q34lc,4ellvk#z2t8u8,yndclc#ejnaio,f85rsw#pi794w,osrri8#4z1atc,5dk6ps#uhzy0w,uwitxc#assruo,a3da80#k8eyv4,kmxurk#vpaf4,g9e68#vegmio,w2z3sw#gz1qm8,hnk7wg#nwrl6o,nhboxs#6pgrgg,7dz8qo#rnm3uo,qy6m80#d877y8,cirqbk#jbyadc,jqh69s#2ym8sg,296r5s#xhdkw0,xvwgsg",
                        "1.0~21.0~qgjcw0,q13gn4#tiew3k,t2yzuo#l6r2m8,lv9jwg#wpa800,x3t3wg#mfp8u8,mu84qo#sly7ls,s6ibcw#icd8g0,hwxc74#yfpon4,z485xc#ov3oxs,p9mku8#uov5z4,tzfocg#ky0feo,kikj5s#vrklc0,vc4p34#nfwruo,o4f94w#r6raio,rla6f4#jp296o,izmrk0",
                      ],
                      t = {},
                      n = 0;
                    n < e.length;
                    n++
                  )
                    try {
                      for (
                        var i = e[n].split("~"),
                          r = m(parseFloat(i[0])),
                          o = m(parseFloat(i[1])),
                          a = i[2].split("#"),
                          s = 0,
                          c = 0;
                        c < a.length;
                        c++
                      )
                        try {
                          for (
                            var u = parseInt(s * r + o),
                              l = [],
                              d = a[c],
                              f =
                                (-1 !== d.indexOf(",")
                                  ? (l = d.split(","))
                                  : l.push(d),
                                u / 100),
                              g = 0;
                            g < l.length;
                            g++
                          )
                            t[l[g]] = f;
                          s++;
                        } catch (e) {}
                    } catch (e) {}
                  return t;
                })(),
                p = function (e, t) {
                  try {
                    for (var n = 0; n < e.length; n++)
                      if ("string" == typeof e[n])
                        for (var i = e[n].split(","), r = 0; r < t.length; r++)
                          for (var o = 0; o < i.length; o++)
                            if (i[o] === t[r]) return !0;
                  } catch (e) {}
                  return !1;
                },
                b = function (e) {
                  for (var t = [], n = 0; n < e.length; n++)
                    t.push(e[n].toLowerCase());
                  return t;
                },
                h = function (e) {
                  var t = "u";
                  try {
                    var n,
                      a,
                      s = e.getTargeting(i),
                      c = b(s);
                    p(c, r)
                      ? (t = "b")
                      : p(c, o)
                      ? (t = "o")
                      : ((n = googletag.pubads().getTargeting(i)),
                        (a = b(n)),
                        p(a, r) ? (t = "b") : p(a, o) && (t = "o"));
                  } catch (e) {}
                  return t;
                },
                y = Math.random(),
                S = y < 0.5 ? "0" : y < 0.75 ? "1" : "2",
                I = [
                  { inclusive_min: 0, exclusive_max: 10, delta: 0.01 },
                  { inclusive_min: 10, exclusive_max: 20, delta: 0.05 },
                  { inclusive_min: 20, exclusive_max: 100, delta: 0.5 },
                  { inclusive_min: 100, exclusive_max: 101, delta: 1 },
                ],
                w = [
                  { inclusive_min: 0, exclusive_max: 0.01, delta: 0.01 },
                  { inclusive_min: 0.01, exclusive_max: 10, delta: 0.05 },
                  { inclusive_min: 10, exclusive_max: 20, delta: 0.05 },
                  { inclusive_min: 20, exclusive_max: 100, delta: 0.5 },
                  { inclusive_min: 100, exclusive_max: 101, delta: 1 },
                ],
                _ = [
                  { inclusive_min: 0, exclusive_max: 0.01, delta: 0.01 },
                  { inclusive_min: 0.01, exclusive_max: 10, delta: 0.1 },
                  { inclusive_min: 10, exclusive_max: 20, delta: 0.1 },
                  { inclusive_min: 20, exclusive_max: 100, delta: 0.5 },
                  { inclusive_min: 100, exclusive_max: 101, delta: 1 },
                ],
                E = function (e, t) {
                  if (e < 0) return e;
                  for (var n = m(e), i = 0; i < t.length; i++) {
                    var r = t[i],
                      o = m(r.inclusive_min),
                      a = m(r.exclusive_max);
                    r = m(r.delta);
                    if (o <= n && n < a) return parseInt((n - o) / r) * r + o;
                  }
                  return m(t[t.length - 1].inclusive_min);
                },
                k = function (e) {
                  return parseFloat(e);
                },
                C = function (e) {
                  var t,
                    n = -1;
                  try {
                    void 0 !== e &&
                      2 === (t = e.split("x")).length &&
                      (n = parseInt(t[0] * t[1]));
                  } catch (e) {}
                  return n;
                },
                T = function (e) {
                  try {
                    if (e.getTargeting && e.__setTargeting) {
                      var t = [],
                        n = h(e);
                      if ("o" === n || "b" === n) {
                        for (
                          var i,
                            r = e.getTargeting("amznbid")[0],
                            o = v[r],
                            a =
                              (void 0 !== o &&
                                ((i = e.getTargeting("amznsz")[0]),
                                t.push({
                                  bidder: "amznbid",
                                  price: [o],
                                  size: void 0 !== i ? "a" + i : -1,
                                  area: C(i),
                                })),
                              [
                                [
                                  "hb_pb",
                                  "hb_bidder",
                                  "hb_size",
                                  k,
                                  1,
                                  "hb_pb_unknown",
                                ],
                              ]),
                            s = 0;
                          s < a.length;
                          ++s
                        ) {
                          var c,
                            u,
                            l = a[s][0],
                            d = a[s][1],
                            f = a[s][2],
                            g = e.getTargeting(l)[0];
                          void 0 !== g &&
                            ((c = e.getTargeting(d)[0] || a[s][5]),
                            (u = e.getTargeting(f)[0]),
                            t.push({
                              bidder: c,
                              price: [a[s][3](g) * a[s][4]],
                              size: void 0 !== u ? "p" + u : -1,
                              area: C(u),
                            }));
                        }
                        t.sort(function (e, t) {
                          var n,
                            i = t.price[0] - e.price[0];
                          return 0 == i
                            ? 0 == (n = t.area - e.area)
                              ? t.bidder.localeCompare(e)
                              : n
                            : i;
                        });
                      }
                      !(function (e, t, n) {
                        var i = [-1],
                          r = [
                            { prefix: "a", price: -1, group: w },
                            { prefix: "b", price: -1, group: _ },
                          ],
                          o = ["nobidder"],
                          a = [-1];
                        if (0 < t.length) {
                          (i[0] = E(t[0].price[0], I).toString()),
                            (o[0] = t[0].bidder),
                            (a[0] = t[0].size),
                            i.push(-3);
                          for (var s = 0; s < r.length; ++s)
                            r[s].price = E(
                              t[0].price[0],
                              r[s].group
                            ).toString();
                        }
                        if ("o" === n) {
                          var c = i.length;
                          for (s = 0; s < c; s++)
                            i.push("o_" + i[s]), i.push("o_" + i[s] + "_" + S);
                          o.push("o_" + o[0]), a.push("o_" + a[0]);
                        }
                        if (-1 !== i[0])
                          for (s = 0; s < r.length; ++s)
                            i.push(r[s].prefix + r[s].price),
                              "o" === n &&
                                (i.push(r[s].prefix + "o_" + r[s].price),
                                i.push(
                                  r[s].prefix + "o_" + r[s].price + "_" + S
                                ));
                        e.__setTargeting("in2w_upa_price", i),
                          e.__setTargeting("in2w_upa_bidder", o),
                          e.__setTargeting("in2w_upa_size", a);
                      })(e, t, n);
                    }
                  } catch (e) {}
                },
                A = -8,
                R = a,
                x = [
                  "0",
                  "1",
                  "2",
                  "3",
                  "4",
                  "5",
                  "6",
                  "7",
                  "8",
                  "9",
                  "a",
                  "b",
                  "c",
                  "d",
                  "e",
                  "f",
                  "g",
                  "h",
                  "i",
                  "j",
                  "k",
                  "l",
                  "m",
                  "n",
                  "o",
                  "p",
                  "q",
                  "r",
                  "s",
                  "t",
                  "u",
                  "v",
                  "w",
                  "x",
                  "y",
                  "z",
                ],
                P = {
                  "1_0010": "01",
                  "1_0011": "02",
                  "1_0020": "03",
                  "1_0021": "04",
                  "1_0110": "05",
                  "1_0111": "06",
                  "1_0120": "07",
                  "1_0121": "08",
                  "1_0310": "09",
                  "1_0311": "0a",
                  "1_0320": "0b",
                  "1_0321": "0c",
                  "1_0610": "0d",
                  "1_0611": "0e",
                  "1_0620": "0f",
                  "1_0621": "0g",
                  "1_0810": "0h",
                  "1_0811": "0i",
                  "1_0820": "0j",
                  "1_0821": "0k",
                  "2_0000": "19",
                  "2_0001": "1a",
                  "2_0002": "1b",
                  "2_000z": "1c",
                  "2_0030": "1d",
                  "2_0031": "1e",
                  "2_0032": "1f",
                  "2_003z": "1g",
                  "2_0100": "1h",
                  "2_0101": "1i",
                  "2_0102": "1j",
                  "2_010z": "1k",
                  "2_0130": "1l",
                  "2_0131": "1m",
                  "2_0132": "1n",
                  "2_013z": "1o",
                  "2_0300": "1p",
                  "2_0301": "1q",
                  "2_0302": "1r",
                  "2_030z": "1s",
                  "2_0330": "1t",
                  "2_0331": "1u",
                  "2_0332": "1v",
                  "2_033z": "1w",
                  "2_0600": "1x",
                  "2_0601": "1y",
                  "2_0602": "1z",
                  "2_060z": "20",
                  "2_0630": "21",
                  "2_0631": "22",
                  "2_0632": "23",
                  "2_063z": "24",
                  "2_0800": "25",
                  "2_0801": "26",
                  "2_0802": "27",
                  "2_080z": "28",
                  "2_0830": "29",
                  "2_0831": "2a",
                  "2_0832": "2b",
                  "2_083z": "2c",
                  "1_0z10": "3l",
                  "1_0z11": "3m",
                  "1_0z20": "3n",
                  "1_0z21": "3o",
                  "2_0z00": "3x",
                  "2_0z01": "3y",
                  "2_0z02": "3z",
                  "2_0z0z": "40",
                  "2_0z30": "41",
                  "2_0z31": "42",
                  "2_0z32": "43",
                  "2_0z3z": "44",
                },
                O = {
                  gpt: 0,
                  amp: 1,
                  video: 2,
                  mobile: 3,
                  gpt_lite: 4,
                  adx_tag: 5,
                },
                D = {
                  out_of_page: 0,
                  anchor: 1,
                  app_open: 2,
                  banner: 3,
                  instream_audio: 4,
                  instream_video: 5,
                  interstitial: 6,
                  native_advance: 7,
                  rewarded: 8,
                  others: 35,
                },
                N = {
                  desktop: 0,
                  smartphone: 1,
                  tablet: 2,
                  connecttv: 3,
                  others: 35,
                },
                z = { ios: 0, android: 1, macos: 2, windows: 3, others: 35 },
                B = { chrome: 0, safari: 1, edge: 2, others: 35 },
                M = {},
                U = {
                  childDirectedTreatment: 1,
                  underAgeOfConsent: 8,
                  nonPersonalizedAds: 64,
                  limitedAds: 256,
                  restrictDataProcessing: 1024,
                },
                j = {},
                L = function () {
                  var t = e.navigator;
                  return (t = t && t.userAgent) || "";
                },
                F = function () {
                  var t = e.navigator;
                  return (t = t && t.userAgentData) || null;
                },
                G = function (e) {
                  return J(e, "Win")
                    ? "windows"
                    : J(e, "like Mac")
                    ? "ios"
                    : J(e, "Mac")
                    ? "macos"
                    : J(e, "Android")
                    ? "android"
                    : "others";
                },
                V = function (e) {
                  return q(e)
                    ? "tablet"
                    : H(e)
                    ? "smartphone"
                    : W(e)
                    ? "connecttv"
                    : "desktop";
                },
                H = function (e) {
                  return (
                    J(e, "iPod") ||
                    J(e, "iPhone") ||
                    J(e, "Android") ||
                    J(e, "IEMobile")
                  );
                },
                q = function (e) {
                  return (
                    J(e, "iPad") ||
                    J(e, "Tablet") ||
                    (J(e, "Android") && !J(e, "Mobile")) ||
                    J(e, "Silk")
                  );
                },
                W = function (e) {
                  return (
                    J(e, "Roku") ||
                    J(e, "SMART-TV") ||
                    J(e, "SmartTV") ||
                    J(e, "NetCast") ||
                    J(e, "crkey")
                  );
                },
                Y = function (e, t) {
                  return (
                    (t = Z(t)) ||
                    (J(e, "OPR/") || J(e, "Opera")
                      ? "others"
                      : J(e, "Edg")
                      ? "edge"
                      : J(e, "Firefox")
                      ? "others"
                      : J(e, "Chrome")
                      ? "chrome"
                      : J(e, "Safari") ||
                        J(e, "iPad") ||
                        J(e, "iPhone") ||
                        J(e, "iphone")
                      ? "safari"
                      : "others")
                  );
                },
                Z = function (e) {
                  if (e && e.brands) {
                    if (Q(e.brands, "Opera")) return "opera";
                    if (Q(e.brands, "Microsoft Edge")) return "edge";
                    if (Q(e.brands, "Chrome")) return "chrome";
                  }
                  return null;
                },
                J = function (e, t) {
                  return -1 !== e.indexOf(t);
                },
                Q = function (e, t) {
                  return e.some(function (e) {
                    return e.brand === t;
                  });
                },
                K = function (e, t) {
                  if (e) return ["0"];
                  for (
                    var n = Math.floor(1e3 * Math.random() + 1),
                      i = [],
                      r = 0,
                      o = 0;
                    o < t.length;
                    ++o
                  ) {
                    for (var a = 1, s = t[o], c = 0, u = 0; u < s.length; u++)
                      if (n <= (c += s[u])) {
                        a = u + 1;
                        break;
                      }
                    1 < a && 0 < r && (a = a + r - 1), (r += t[o].length);
                    var l = x[a];
                    for (u = 0; u < i.length; ++u)
                      if (i[u] === l) {
                        u = -1;
                        break;
                      }
                    -1 !== u && i.push(l);
                  }
                  for (u = 0; u < i.length; ++u)
                    "1" === i[u] && (i[u] = Math.random() <= 0.38 ? "x" : i[u]);
                  return i;
                },
                X = function (e) {
                  e = new Date().getTime() + 36e5 * e;
                  var t = parseInt(e / 36e5, 10) % 24;
                  return [
                    [1, 0],
                    [3, 24],
                    [6, 32],
                  ].map(function (e) {
                    return x[Math.floor(t / e[0]) + e[1]];
                  });
                },
                $ = function () {
                  var e, t, n;
                  return (
                    g ||
                      ((n = (function () {
                        var e = L(),
                          t = F();
                        return { os: G(e), dc: V(e), browser: Y(e, t) };
                      })()),
                      (e = void 0 !== B[n.browser] ? B[n.browser] : B.others),
                      (t = void 0 !== z[n.os] ? z[n.os] : z.others),
                      (n = void 0 !== N[n.dc] ? N[n.dc] : N.others),
                      (g = { dc: x[n], os: x[t], browser: x[e] })),
                    g
                  );
                },
                ee = function (e, t) {
                  if (void 0 === (e = O[e])) throw new Error();
                  return (
                    (t =
                      void 0 !==
                      D[
                        (t =
                          "top_anchor" !== t && "bottom_anchor" !== t
                            ? t
                            : "anchor")
                      ]
                        ? D[t]
                        : D.others),
                    { rt: x[e], ivf: x[t] }
                  );
                },
                te = function (t) {
                  var n;
                  return (
                    M[t] ||
                      ((n = (function () {
                        var t = e.navigator;
                        return (t = t && t.language) || "";
                      })()),
                      (M[t] = oe(n, t))),
                    M[t]
                  );
                },
                ne = function (e) {
                  try {
                    if (!e.length) return "0";
                    for (var t = 305419896, n = 0; n < e.length; ++n)
                      t ^= ((t << 5) + (t >> 2) + e.charCodeAt(n)) & 4294967295;
                    return (t < 0 ? 4294967296 + t : t) + "";
                  } catch (e) {
                    return "-1";
                  }
                },
                ie = function (e, t) {
                  try {
                    var n = t ? (e + "").toLowerCase() : e + "";
                    return n.length + "_" + ne(n);
                  } catch (e) {
                    return "-1";
                  }
                },
                re = function (e) {
                  if (
                    "" ===
                    (e = (function (e) {
                      return "" === e || null == e
                        ? ""
                        : "/" !== e[0]
                        ? "/" + e
                        : e;
                    })(e))
                  )
                    return ["-2", "p-2"];
                  for (
                    var t,
                      n = [
                        { path: e, prefix: "" },
                        {
                          path: e.split("/").slice(0, -1).join("/"),
                          prefix: "p",
                        },
                      ],
                      i = [],
                      r = 0;
                    r < n.length;
                    ++r
                  ) {
                    try {
                      t = n[r].prefix + ie(n[r].path, !0);
                    } catch (e) {
                      t = n[r].prefix + "-1";
                    }
                    i.push(t);
                  }
                  return i;
                },
                oe = function (e, t) {
                  var n,
                    i,
                    r,
                    o,
                    a,
                    s = [];
                  try {
                    "" === e || null == e
                      ? (s = ["-2"])
                      : ((i = (n = e.split("-"))[0]),
                        (r = ie(i, !0)),
                        s.push(r),
                        1 < n.length &&
                          ((o = n[0] + "-" + n[1]),
                          (a = ie(o, !0)),
                          s.push(a)));
                  } catch (e) {
                    s = ["-1"];
                  }
                  if (!t)
                    for (var c = s.length, u = 0; u < c; ++u)
                      s.push("o_" + s[u]);
                  return s;
                },
                ae = function (t, n) {
                  var i = ["u"];
                  try {
                    if ("" === t || null == t)
                      throw ((i = ["u1"]), new Error("u1"));
                    var r = e.document.getElementById(t);
                    if (null == r) throw ((i = ["u2"]), new Error("u2"));
                    var o = e.innerHeight;
                    if (void 0 === o || o <= 0)
                      throw ((i = ["u3"]), new Error("u3"));
                    var a,
                      s,
                      c = r.getBoundingClientRect(),
                      u = void 0 !== c.y ? c.y : c.top;
                    if (void 0 === u) throw ((i = ["u4"]), new Error("u4"));
                    i =
                      u < 0
                        ? [
                            "a",
                            "a" +
                              (a = (a = parseInt(u / o, 10) - 1) < -2 ? -2 : a),
                          ]
                        : u < o
                        ? ["i", "i" + (parseInt(u / (o / 3), 10) + 1)]
                        : [
                            "b",
                            "b" +
                              (s =
                                9 < (s = parseInt((u - o) / o, 10) + 1)
                                  ? 9
                                  : s),
                            "bg" + Math.ceil(s / 3),
                          ];
                  } catch (t) {}
                  if (!n)
                    for (var l = i.length, d = 0; d < l; ++d)
                      i.push("o_" + i[d]);
                  return i;
                },
                se = function (e) {
                  var t = [];
                  try {
                    var n,
                      i = 0;
                    for (n in U)
                      !!(2751 & U[n]) && t.push(U[n].toString(36)), (i += U[n]);
                    t.push(i.toString(36));
                  } catch (e) {
                    t = ["-1"];
                  }
                  if (!e)
                    for (var r = t.length, o = 0; o < r; ++o)
                      t.push("o_" + t[o]);
                  return t;
                },
                ce = function (e) {
                  try {
                    return j[e] || (j[e] = se(e)), j[e];
                  } catch (e) {
                    return ["-1"];
                  }
                },
                ue = function (e, t) {
                  return (t -= (e += "").length) <= 0
                    ? e
                    : (function (e, t) {
                        for (var n = "", i = 0; i < t; i++) n += e;
                        return n;
                      })("0", t) + e;
                },
                le = function (e) {
                  try {
                    var t = 1 + parseInt(20 * Math.random(), 10),
                      n = [ue(t, 2)];
                    if (!e)
                      for (var i = n.length, r = 0; r < i; ++r)
                        n.push("o_" + n[r]);
                    return n;
                  } catch (e) {
                    return ["-1"];
                  }
                },
                de = function (e, t) {
                  var n = [];
                  try {
                    var i = new Date().getTime() + 36e5 * e,
                      r = parseInt(i / 36e5, 10) % 24,
                      o = Math.floor(r);
                    n.push(ue(o, 2));
                  } catch (e) {
                    n = ["-1"];
                  }
                  if (!t)
                    for (var a = n.length, s = 0; s < a; ++s)
                      n.push("o_" + n[s]);
                  return n;
                },
                fe = function (t) {
                  var n = [];
                  try {
                    var i,
                      r = l ? "1" : "0",
                      o =
                        ((i =
                          null == c
                            ? "0"
                            : (Date.now() - c) / 1e3 <= 3
                            ? "1"
                            : "2"),
                        "visible" === e.document.visibilityState ? "1" : "0");
                    n.push(r + i + o);
                  } catch (t) {
                    n = ["-1"];
                  }
                  if (!t)
                    for (var a = n.length, s = 0; s < a; ++s)
                      n.push("o_" + n[s]);
                  return n;
                },
                ge = function () {
                  return "w49";
                },
                me = function () {
                  return "8s4o";
                },
                ve = function (e, t, n, i, r, o, a, s, c) {
                  try {
                    if ("u" === n)
                      return [
                        { key: "in2w_key16", values: [] },
                        { key: "in2w_key20", values: [] },
                        { key: "in2w_key21", values: null },
                        { key: "in2w_key23", values: null },
                        { key: "in2w_key26", values: [] },
                        { key: "in2w_key27", values: [] },
                        { key: "in2w_key28", values: [] },
                        { key: "in2w_key30", values: [] },
                        { key: "in2w_key31", values: [] },
                        { key: "in2w_key33", values: [] },
                        { key: "in2w_key34", values: null },
                        { key: "in2w_key35", values: null },
                        { key: "in2w_upa_bidder", values: [] },
                        { key: "in2w_upa_price", values: [] },
                        { key: "in2w_upa_size", values: [] },
                      ];
                    var u = ee(i, r),
                      l = $(),
                      d = u.rt,
                      f = u.ivf,
                      g = l.dc,
                      m = l.os,
                      v = l.browser,
                      p = "b" === n,
                      b = (function (e, t, n, i, r, o, a) {
                        for (
                          var s = [],
                            c =
                              ("0" === n || "3" === n
                                ? (r = P["2_" + e + t + n + r]) && s.push(r)
                                : (r = P["1_" + e + t + n + i]) && s.push(r),
                              []),
                            u = [],
                            l = 0;
                          l < s.length;
                          l++
                        ) {
                          var d = s[l];
                          for (c.push("-" + d), l = 0; l < o.length; ++l) {
                            var f = d + o[l];
                            c.push(f);
                            for (var g = 0; g < a.length; g++) {
                              var m = a[g];
                              u.push(f + m);
                            }
                          }
                        }
                        return { short: c, full: u };
                      })(d, f, g, m, v, K(p, t), X(e)),
                      h = (p && (b.short = []), []);
                    o &&
                      o.length &&
                      h.push(
                        (function (e) {
                          for (
                            var t,
                              n,
                              i = e,
                              r =
                                (("fluid" === e ||
                                  ("number" == typeof i[0] &&
                                    "number" == typeof i[1])) &&
                                  (i = [e]),
                                []),
                              o = 1e5,
                              a = 1,
                              s = 1e5,
                              c = 1,
                              u = 0;
                            u < i.length;
                            u++
                          )
                            "fluid" === i[u]
                              ? r.push(i[u])
                              : ((t = i[u][0]) < o && (o = t),
                                a < t && (a = t),
                                (n = i[u][1]) < s && (s = n),
                                c < n && (c = n),
                                r.push(t + "x" + n));
                          return (
                            r.sort(function (e, t) {
                              return e < t ? -1 : 1;
                            }),
                            (e = r.length),
                            r.push(o),
                            r.push(a),
                            r.push(s),
                            r.push(c),
                            r.push(e),
                            ne(r.join(","))
                          );
                        })(o)
                      );
                    try {
                      var y = "-1";
                      if (void 0 !== c && 0 < c.length)
                        for (var I = 0; I < c.length; I++)
                          if ("o" !== c[I][0]) {
                            y = "-1" === c[I] ? "-1" : "-3";
                            break;
                          }
                      var w,
                        _ = b.full.length;
                      for (I = 0; I < _; I++) {
                        var E = b.full[I];
                        "_" !== E[0] && b.full.push(E + "_" + y);
                      }
                      0 < _ &&
                        "-3" === y &&
                        ((w = b.full[0].substring(0, 2) + "1"),
                        b.full.push(w + "_-3_"),
                        "o" === n) &&
                        (b.full.push(w + "_o_-3_"),
                        b.full.push(w + "_o_-3_" + S));
                      var k = b.short.length;
                      for (I = 0; I < k; I++) {
                        var C = b.short[I];
                        "_" !== C[0] && b.short.push(C + "_" + y);
                      }
                    } catch (e) {}
                    var T = [
                        { key: "in2w_key16", values: b.short },
                        { key: "in2w_key20", values: b.full },
                        { key: "in2w_key21", values: h },
                      ],
                      A = [
                        "in2w_key23",
                        "in2w_key26",
                        "in2w_key27",
                        "in2w_key28",
                        "in2w_key30",
                        "in2w_key31",
                        "in2w_key33",
                        "in2w_key34",
                        "in2w_key35",
                      ];
                    for (I = 0; I < A.length; I++)
                      try {
                        switch (A[I]) {
                          case "in2w_key23":
                            T.push({ key: A[I], values: re(a) });
                            break;
                          case "in2w_key26":
                            T.push({ key: A[I], values: te(p) });
                            break;
                          case "in2w_key27":
                            T.push({ key: A[I], values: ae(s, p) });
                            break;
                          case "in2w_key28":
                            T.push({ key: A[I], values: ce(p) });
                            break;
                          case "in2w_key30":
                            T.push({ key: A[I], values: le(p) });
                            break;
                          case "in2w_key31":
                            T.push({ key: A[I], values: de(e, p) });
                            break;
                          case "in2w_key33":
                            T.push({ key: A[I], values: fe(p) });
                            break;
                          case "in2w_key34":
                            T.push({ key: A[I], values: ge() });
                            break;
                          case "in2w_key35":
                            T.push({ key: A[I], values: me() });
                        }
                      } catch (e) {}
                    return T;
                  } catch (e) {
                    return [
                      { key: "in2w_key20", values: ["4p10", "4p1o", "4p1w"] },
                    ];
                  }
                },
                pe = function (t) {
                  try {
                    if (t.__should_skip_labeling) t.__should_skip_labeling = !1;
                    else {
                      var n,
                        i = h(t),
                        r = "banner";
                      if (t.__is_oop)
                        r = googletag.enums.OutOfPageFormat[t.__oop_format]
                          ? googletag.enums.OutOfPageFormat[
                              t.__oop_format
                            ].toLowerCase()
                          : "out_of_page";
                      else
                        try {
                          if (t.__sz_mapping)
                            for (
                              var o = Math.round(e.innerWidth),
                                a = Math.round(e.innerHeight),
                                s = 0;
                              s < t.__sz_mapping.length;
                              s++
                            ) {
                              var c = t.__sz_mapping[s][0];
                              if (c[0] <= o && c[1] <= a) {
                                n = t.__sz_mapping[s][1];
                                break;
                              }
                            }
                          else t.__def_sizes && (n = t.__def_sizes);
                        } catch (t) {}
                      var u = ve(
                        A,
                        R,
                        i,
                        "gpt",
                        r,
                        n,
                        t.getAdUnitPath(),
                        t.getSlotElementId(),
                        t.getTargeting("in2w_upa_price")
                      );
                      for (s = 0; s < u.length; s++)
                        t.__setTargeting(u[s].key, u[s].values);
                    }
                  } catch (t) {}
                },
                be = function () {
                  try {
                    var e = new Date(),
                      i = new Date(
                        e.toLocaleString("en-US", { timeZone: "UTC" })
                      ),
                      r = new Date(e.toLocaleString("en-US", { timeZone: s }));
                    A = (r.getTime() - i.getTime()) / 36e5;
                  } catch (e) {
                    A = -8;
                  }
                  var o = [
                      "slotRequested",
                      "slotResponseReceived",
                      "slotRenderEnded",
                      "slotOnload",
                      "impressionViewable",
                      "slotVisibilityChanged",
                    ],
                    a = o.slice(1),
                    c = t.googletag.pubads(),
                    u =
                      ((c.__product_version = 3),
                      (c.__pkgv = "49"),
                      (c.__build_id = "8s4o"),
                      (c.__hook_version = 8),
                      (t.googletag.__display = t.googletag.display),
                      (t.googletag.display = function (e) {
                        for (var n = [], i = 0; i < arguments.length; i++)
                          n.push(arguments[i]);
                        try {
                          var r = this.pubads().getSlots();
                          for (i = 0; i < r.length; i++) {
                            var o = r[i];
                            T(o);
                          }
                        } catch (e) {}
                        return t.googletag.__display.apply(c, n);
                      }.bind(t.googletag)),
                      (c.__refresh = c.refresh),
                      (c.refresh = function (e) {
                        for (var t = [], n = 0; n < arguments.length; n++)
                          t.push(arguments[n]);
                        try {
                          for (
                            e = e || this.getSlots(), n = 0;
                            n < e.length;
                            n++
                          ) {
                            var i,
                              r = e[n],
                              o =
                                (T(r), (i = u = s = a = f = d = l = void 0), r);
                            try {
                              var a,
                                s,
                                u,
                                l = [],
                                d = null,
                                f = h(o);
                              ("o" !== f && "b" !== f) ||
                                (0 < (a = o.__refreshCount || 0) && (d = "1"),
                                (s =
                                  f +
                                  ((i = a) < 11
                                    ? i
                                    : i < 26
                                    ? "10-"
                                    : i < 51
                                    ? "25-"
                                    : i < 101
                                    ? "50-"
                                    : "100-")),
                                l.push(s),
                                (u = (function (e) {
                                  try {
                                    var t = "-1";
                                    if (void 0 !== e && 0 < e.length)
                                      for (var n = 0; n < e.length; n++)
                                        if ("o" !== e[n][0]) {
                                          t = "-1" === e[n] ? "-1" : "-3";
                                          break;
                                        }
                                    return t;
                                  } catch (e) {}
                                  return "-1";
                                })(o.getTargeting("in2w_upa_price"))),
                                l.push(s + "_" + u)),
                                o.setTargeting("in2w_key15", l),
                                o.__setTargeting("in2w_key22", d);
                            } catch (e) {}
                          }
                        } catch (e) {}
                        c.__refresh.apply(c, t);
                      }.bind(c)),
                      (c.__setPrivacySettings = c.setPrivacySettings),
                      (c.setPrivacySettings = function (e) {
                        for (var t = [], n = 0; n < arguments.length; n++)
                          t.push(arguments[n]);
                        try {
                          void 0 !== e.childDirectedTreatment &&
                            (null === e.childDirectedTreatment
                              ? (U.childDirectedTreatment = 1)
                              : e.childDirectedTreatment
                              ? (U.childDirectedTreatment = 4)
                              : (U.childDirectedTreatment = 2)),
                            void 0 !== e.underAgeOfConsent &&
                              (null === e.underAgeOfConsent
                                ? (U.underAgeOfConsent = 8)
                                : e.underAgeOfConsent
                                ? (U.underAgeOfConsent = 32)
                                : (U.underAgeOfConsent = 16)),
                            void 0 !== e.nonPersonalizedAds &&
                              (e.nonPersonalizedAds
                                ? (U.nonPersonalizedAds = 128)
                                : (U.nonPersonalizedAds = 64)),
                            void 0 !== e.limitedAds &&
                              (e.limitedAds
                                ? (U.limitedAds = 512)
                                : (U.limitedAds = 256)),
                            void 0 !== e.restrictDataProcessing &&
                              (e.restrictDataProcessing
                                ? (U.restrictDataProcessing = 2048)
                                : (U.restrictDataProcessing = 1024)),
                            (j[!0] = se(!0)),
                            (j[!1] = se(!1));
                        } catch (e) {}
                        return c.__setPrivacySettings.apply(c, t);
                      }.bind(c)),
                      (c.__setTargeting = c.setTargeting),
                      (c.__clearTargeting = c.clearTargeting),
                      (t.googletag.__defineOutOfPageSlot =
                        t.googletag.defineOutOfPageSlot),
                      (t.googletag.__defineSlot = t.googletag.defineSlot),
                      (c.setTargeting = function () {
                        for (var e = [], t = 0; t < arguments.length; t++)
                          e.push(arguments[t]);
                        var n = c.__setTargeting.apply(c, e);
                        try {
                          var i = this.getSlots();
                          for (t = 0; t < i.length; t++) {
                            var r = i[t];
                            pe(r);
                          }
                        } catch (e) {}
                        return n;
                      }.bind(c)),
                      (c.clearTargeting = function () {
                        for (var e = [], t = 0; t < arguments.length; t++)
                          e.push(arguments[t]);
                        var n = c.__clearTargeting.apply(c, e);
                        try {
                          var i = this.getSlots();
                          for (t = 0; t < i.length; t++) {
                            var r = i[t];
                            pe(r);
                          }
                        } catch (e) {}
                        return n;
                      }.bind(c)),
                      function (e) {
                        (e.__setTargeting = e.setTargeting),
                          (e.setTargeting = function () {
                            for (var t = [], n = 0; n < arguments.length; n++)
                              t.push(arguments[n]);
                            var i = e.__setTargeting.apply(e, t);
                            return pe(e), i;
                          }.bind(e));
                      }),
                    l = function (e) {
                      (e.__clearTargeting = e.clearTargeting),
                        (e.clearTargeting = function () {
                          for (var t = [], n = 0; n < arguments.length; n++)
                            t.push(arguments[n]);
                          var i = e.__clearTargeting.apply(e, t);
                          return pe(e), i;
                        }.bind(e));
                    },
                    d = function (e) {
                      (e.__updateTargetingFromMap = e.updateTargetingFromMap),
                        (e.updateTargetingFromMap = function () {
                          try {
                            for (var t = [], n = 0; n < arguments.length; n++)
                              t.push(arguments[n]);
                            e.__updateTargetingFromMap.apply(e, t), T(e);
                          } catch (t) {}
                          return e;
                        }.bind(e));
                    };
                  (t.googletag.defineOutOfPageSlot = function () {
                    for (var e = [], n = 0; n < arguments.length; n++)
                      e.push(arguments[n]);
                    var i = t.googletag.__defineOutOfPageSlot.apply(
                      t.googletag,
                      e
                    );
                    return (
                      i &&
                        ((i.__is_oop = !0),
                        (i.__oop_format = e[1]),
                        u(i),
                        l(i),
                        d(i),
                        pe(i)),
                      i
                    );
                  }.bind(t.googletag)),
                    (t.googletag.defineSlot = function () {
                      for (var e = [], n = 0; n < arguments.length; n++)
                        e.push(arguments[n]);
                      var i = t.googletag.__defineSlot.apply(t.googletag, e);
                      return (
                        i &&
                          ((i.__is_oop = !1),
                          (i.__def_sizes = arguments[1]),
                          u(i),
                          l(i),
                          d(i),
                          (i.__defineSizeMapping = i.defineSizeMapping),
                          (i.defineSizeMapping = function (e) {
                            for (var t = [], n = 0; n < arguments.length; n++)
                              t.push(arguments[n]);
                            var r = i.__defineSizeMapping.apply(i, t);
                            return (
                              e && 0 < e.length && (i.__sz_mapping = e),
                              pe(i),
                              r
                            );
                          }.bind(i)),
                          pe(i)),
                        i
                      );
                    }.bind(t.googletag));
                  try {
                    for (var f = c.getSlots(), g = 0; g < f.length; g++)
                      try {
                        var m = f[g];
                        void 0 !== m.__setTargeting ||
                          m.getOutOfPage() ||
                          ((m.__is_oop = !1), u(m), l(m), pe(m));
                      } catch (e) {}
                  } catch (e) {}
                  (c.__reportEvents = function (e, t) {
                    if (c.__eventProxy && c.__eventProxy[e])
                      for (var n = 0; n < c.__eventProxy[e].length; n++)
                        try {
                          c.__eventProxy[e][n](t);
                        } catch (e) {}
                  }),
                    (c.__addEventListener = c.addEventListener),
                    (c.addEventListener = function (e, t) {
                      if (-1 !== o.indexOf(e))
                        try {
                          return (
                            (this.__eventProxy = this.__eventProxy || {}),
                            this.__eventProxy[e]
                              ? (-1 === this.__eventProxy[e].indexOf(t) &&
                                  this.__eventProxy[e].push(t),
                                c)
                              : ((this.__eventProxy[e] = [t]),
                                c.__addEventListener(e, function (t) {
                                  var i = t.slot;
                                  if (
                                    i.__skipEvent &&
                                    i.__skipEvent[e] &&
                                    new Date().getTime() - i.__skipEvent[e] <
                                      3e3
                                  )
                                    delete i.__skipEvent[e];
                                  else if (
                                    -1 === a.indexOf(e) ||
                                    !(function (e) {
                                      return (
                                        (e = e.__getResponseInformation
                                          ? e.__getResponseInformation()
                                          : e.getResponseInformation()) &&
                                        e.advertiserId &&
                                        -1 !== n.indexOf(e.advertiserId)
                                      );
                                    })(i)
                                  )
                                    for (
                                      var r = 0;
                                      r < c.__eventProxy[e].length;
                                      r++
                                    )
                                      try {
                                        c.__eventProxy[e][r](t);
                                      } catch (t) {}
                                }))
                          );
                        } catch (t) {}
                      return c.__addEventListener(e, t);
                    }.bind(c)),
                    (c.__removeEventListener = c.removeEventListener),
                    (c.removeEventListener = function (e, t) {
                      try {
                        var n = this.__eventProxy;
                        if (n && n[e])
                          return (
                            -1 !== n[e].indexOf(t) &&
                            (n[e].splice(n[e].indexOf(t), 1), !0)
                          );
                      } catch (e) {}
                      return c.__removeEventListener(e, t);
                    }.bind(c)),
                    c.addEventListener("slotRequested", function (e) {
                      delete (e = e.slot).__responseInfo,
                        (e.__refreshCount = e.__refreshCount || 0),
                        ++e.__refreshCount;
                    });
                };
              t.googletag.cmd.unshift
                ? (t.googletag.cmd.unshift(be),
                  (t.googletag.cmd.unshift = function (e) {
                    t.googletag.cmd.splice(1, 0, e);
                  }))
                : t.googletag.cmd.push(be);
            }
          } catch (a) {}
        })(e, t, n, i, r, o, a);
      },
      geo: { country: "IT", state: "25", code: "EU-GDPR" },
      cfConfig: {
        geo: { country: "IT", state: "25", code: "EU-GDPR" },
        bot: { score: 83, verified: false, category: "" },
      },
    },
    t = [
      "ads-monitor.xyz",
      "adtimizer.co",
      "adtimizer.com",
      "akedo.gg",
      "controlium.net",
      "cookie-sync.xyz",
      "discover-tech.io",
      "glispadiscover.com",
      "impchkdsp.com",
      "mtrtb.com",
      "myipinfo.io",
      "nutralove.co",
      "powerium.net",
      "sdk-analytics.com",
      "tekma-dmp.ai",
      "tracookiepixel.xyz",
      "trustlayersdk.com",
      "volasim.com",
    ];
  function n(e, t) {
    (null == t || t > e.length) && (t = e.length);
    for (var n = 0, i = Array(t); n < t; n++) i[n] = e[n];
    return i;
  }
  function i(e, t, n) {
    return (
      (t = d(t)),
      (function (e, t) {
        if (t && ("object" == typeof t || "function" == typeof t)) return t;
        if (void 0 !== t)
          throw new TypeError(
            "Derived constructors may only return object or undefined"
          );
        return (function (e) {
          if (void 0 === e)
            throw new ReferenceError(
              "this hasn't been initialised - super() hasn't been called"
            );
          return e;
        })(e);
      })(
        e,
        g() ? Reflect.construct(t, n || [], d(e).constructor) : t.apply(e, n)
      )
    );
  }
  function r(e, t) {
    if (!(e instanceof t))
      throw new TypeError("Cannot call a class as a function");
  }
  function o(e, t) {
    for (var n = 0; n < t.length; n++) {
      var i = t[n];
      (i.enumerable = i.enumerable || !1),
        (i.configurable = !0),
        "value" in i && (i.writable = !0),
        Object.defineProperty(e, S(i.key), i);
    }
  }
  function a(e, t, n) {
    return (
      t && o(e.prototype, t),
      n && o(e, n),
      Object.defineProperty(e, "prototype", { writable: !1 }),
      e
    );
  }
  function s(e, t) {
    var n =
      ("undefined" != typeof Symbol && e[Symbol.iterator]) || e["@@iterator"];
    if (!n) {
      if (Array.isArray(e) || (n = w(e)) || t) {
        n && (e = n);
        var i = 0,
          r = function () {};
        return {
          s: r,
          n: function () {
            return i >= e.length ? { done: !0 } : { done: !1, value: e[i++] };
          },
          e: function (e) {
            throw e;
          },
          f: r,
        };
      }
      throw new TypeError(
        "Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
      );
    }
    var o,
      a = !0,
      s = !1;
    return {
      s: function () {
        n = n.call(e);
      },
      n: function () {
        var e = n.next();
        return (a = e.done), e;
      },
      e: function (e) {
        (s = !0), (o = e);
      },
      f: function () {
        try {
          a || null == n.return || n.return();
        } finally {
          if (s) throw o;
        }
      },
    };
  }
  function c(e, t, n, i) {
    var r = { configurable: !0, enumerable: !0 };
    return (r[e] = i), Object.defineProperty(t, n, r);
  }
  function u(e, t, n) {
    return (
      (t = S(t)) in e
        ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0,
          })
        : (e[t] = n),
      e
    );
  }
  function l() {
    return (
      (l =
        "undefined" != typeof Reflect && Reflect.get
          ? Reflect.get.bind()
          : function (e, t, n) {
              var i = (function (e, t) {
                for (; !{}.hasOwnProperty.call(e, t) && null !== (e = d(e)); );
                return e;
              })(e, t);
              if (i) {
                var r = Object.getOwnPropertyDescriptor(i, t);
                return r.get
                  ? r.get.call(arguments.length < 3 ? e : n)
                  : r.value;
              }
            }),
      l.apply(null, arguments)
    );
  }
  function d(e) {
    return (
      (d = Object.setPrototypeOf
        ? Object.getPrototypeOf.bind()
        : function (e) {
            return e.__proto__ || Object.getPrototypeOf(e);
          }),
      d(e)
    );
  }
  function f(e, t) {
    if ("function" != typeof t && null !== t)
      throw new TypeError("Super expression must either be null or a function");
    (e.prototype = Object.create(t && t.prototype, {
      constructor: { value: e, writable: !0, configurable: !0 },
    })),
      Object.defineProperty(e, "prototype", { writable: !1 }),
      t && p(e, t);
  }
  function g() {
    try {
      var e = !Boolean.prototype.valueOf.call(
        Reflect.construct(Boolean, [], function () {})
      );
    } catch (e) {}
    return (g = function () {
      return !!e;
    })();
  }
  function m() {
    /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/babel/babel/blob/main/packages/babel-helpers/LICENSE */
    var e,
      t,
      n = "function" == typeof Symbol ? Symbol : {},
      i = n.iterator || "@@iterator",
      r = n.toStringTag || "@@toStringTag";
    function o(n, i, r, o) {
      var c = i && i.prototype instanceof s ? i : s,
        u = Object.create(c.prototype);
      return (
        v(
          u,
          "_invoke",
          (function (n, i, r) {
            var o,
              s,
              c,
              u = 0,
              l = r || [],
              d = !1,
              f = {
                p: 0,
                n: 0,
                v: e,
                a: g,
                f: g.bind(e, 4),
                d: function (t, n) {
                  return (o = t), (s = 0), (c = e), (f.n = n), a;
                },
              };
            function g(n, i) {
              for (s = n, c = i, t = 0; !d && u && !r && t < l.length; t++) {
                var r,
                  o = l[t],
                  g = f.p,
                  m = o[2];
                n > 3
                  ? (r = m === i) &&
                    ((c = o[(s = o[4]) ? 5 : ((s = 3), 3)]), (o[4] = o[5] = e))
                  : o[0] <= g &&
                    ((r = n < 2 && g < o[1])
                      ? ((s = 0), (f.v = i), (f.n = o[1]))
                      : g < m &&
                        (r = n < 3 || o[0] > i || i > m) &&
                        ((o[4] = n), (o[5] = i), (f.n = m), (s = 0)));
              }
              if (r || n > 1) return a;
              throw ((d = !0), i);
            }
            return function (r, l, m) {
              if (u > 1) throw TypeError("Generator is already running");
              for (
                d && 1 === l && g(l, m), s = l, c = m;
                (t = s < 2 ? e : c) || !d;

              ) {
                o ||
                  (s
                    ? s < 3
                      ? (s > 1 && (f.n = -1), g(s, c))
                      : (f.n = c)
                    : (f.v = c));
                try {
                  if (((u = 2), o)) {
                    if ((s || (r = "next"), (t = o[r]))) {
                      if (!(t = t.call(o, c)))
                        throw TypeError("iterator result is not an object");
                      if (!t.done) return t;
                      (c = t.value), s < 2 && (s = 0);
                    } else
                      1 === s && (t = o.return) && t.call(o),
                        s < 2 &&
                          ((c = TypeError(
                            "The iterator does not provide a '" + r + "' method"
                          )),
                          (s = 1));
                    o = e;
                  } else if ((t = (d = f.n < 0) ? c : n.call(i, f)) !== a)
                    break;
                } catch (t) {
                  (o = e), (s = 1), (c = t);
                } finally {
                  u = 1;
                }
              }
              return { value: t, done: d };
            };
          })(n, r, o),
          !0
        ),
        u
      );
    }
    var a = {};
    function s() {}
    function c() {}
    function u() {}
    t = Object.getPrototypeOf;
    var l = [][i]
        ? t(t([][i]()))
        : (v((t = {}), i, function () {
            return this;
          }),
          t),
      d = (u.prototype = s.prototype = Object.create(l));
    function f(e) {
      return (
        Object.setPrototypeOf
          ? Object.setPrototypeOf(e, u)
          : ((e.__proto__ = u), v(e, r, "GeneratorFunction")),
        (e.prototype = Object.create(d)),
        e
      );
    }
    return (
      (c.prototype = u),
      v(d, "constructor", u),
      v(u, "constructor", c),
      (c.displayName = "GeneratorFunction"),
      v(u, r, "GeneratorFunction"),
      v(d),
      v(d, r, "Generator"),
      v(d, i, function () {
        return this;
      }),
      v(d, "toString", function () {
        return "[object Generator]";
      }),
      (m = function () {
        return { w: o, m: f };
      })()
    );
  }
  function v(e, t, n, i) {
    var r = Object.defineProperty;
    try {
      r({}, "", {});
    } catch (e) {
      r = 0;
    }
    (v = function (e, t, n, i) {
      function o(t, n) {
        v(e, t, function (e) {
          return this._invoke(t, n, e);
        });
      }
      t
        ? r
          ? r(e, t, {
              value: n,
              enumerable: !i,
              configurable: !i,
              writable: !i,
            })
          : (e[t] = n)
        : (o("next", 0), o("throw", 1), o("return", 2));
    }),
      v(e, t, n, i);
  }
  function p(e, t) {
    return (
      (p = Object.setPrototypeOf
        ? Object.setPrototypeOf.bind()
        : function (e, t) {
            return (e.__proto__ = t), e;
          }),
      p(e, t)
    );
  }
  function b(e, t) {
    return (
      (function (e) {
        if (Array.isArray(e)) return e;
      })(e) ||
      (function (e, t) {
        var n =
          null == e
            ? null
            : ("undefined" != typeof Symbol && e[Symbol.iterator]) ||
              e["@@iterator"];
        if (null != n) {
          var i,
            r,
            o,
            a,
            s = [],
            c = !0,
            u = !1;
          try {
            if (((o = (n = n.call(e)).next), 0 === t)) {
              if (Object(n) !== n) return;
              c = !1;
            } else
              for (
                ;
                !(c = (i = o.call(n)).done) &&
                (s.push(i.value), s.length !== t);
                c = !0
              );
          } catch (e) {
            (u = !0), (r = e);
          } finally {
            try {
              if (!c && null != n.return && ((a = n.return()), Object(a) !== a))
                return;
            } finally {
              if (u) throw r;
            }
          }
          return s;
        }
      })(e, t) ||
      w(e, t) ||
      (function () {
        throw new TypeError(
          "Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
        );
      })()
    );
  }
  function h(e, t, n, i) {
    var r = l(d(e.prototype), t, n);
    return "function" == typeof r
      ? function (e) {
          return r.apply(n, e);
        }
      : r;
  }
  function y(e) {
    return (
      (function (e) {
        if (Array.isArray(e)) return n(e);
      })(e) ||
      (function (e) {
        if (
          ("undefined" != typeof Symbol && null != e[Symbol.iterator]) ||
          null != e["@@iterator"]
        )
          return Array.from(e);
      })(e) ||
      w(e) ||
      (function () {
        throw new TypeError(
          "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
        );
      })()
    );
  }
  function S(e) {
    var t = (function (e, t) {
      if ("object" != typeof e || !e) return e;
      var n = e[Symbol.toPrimitive];
      if (void 0 !== n) {
        var i = n.call(e, t);
        if ("object" != typeof i) return i;
        throw new TypeError("@@toPrimitive must return a primitive value.");
      }
      return ("string" === t ? String : Number)(e);
    })(e, "string");
    return "symbol" == typeof t ? t : t + "";
  }
  function I(e) {
    return (
      (I =
        "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
          ? function (e) {
              return typeof e;
            }
          : function (e) {
              return e &&
                "function" == typeof Symbol &&
                e.constructor === Symbol &&
                e !== Symbol.prototype
                ? "symbol"
                : typeof e;
            }),
      I(e)
    );
  }
  function w(e, t) {
    if (e) {
      if ("string" == typeof e) return n(e, t);
      var i = {}.toString.call(e).slice(8, -1);
      return (
        "Object" === i && e.constructor && (i = e.constructor.name),
        "Map" === i || "Set" === i
          ? Array.from(e)
          : "Arguments" === i ||
            /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(i)
          ? n(e, t)
          : void 0
      );
    }
  }
  Array.prototype.includes ||
    Object.defineProperty(Array.prototype, "includes", {
      value: function (e, t) {
        if (null == this) throw new TypeError('"this" is null or not defined');
        var n = Object(this),
          i = n.length >>> 0;
        if (0 === i) return !1;
        for (
          var r, o, a = 0 | t, s = Math.max(0 <= a ? a : i - Math.abs(a), 0);
          s < i;

        ) {
          if (
            (r = n[s]) === (o = e) ||
            ("number" == typeof r &&
              "number" == typeof o &&
              isNaN(r) &&
              isNaN(o))
          )
            return !0;
          s++;
        }
        return !1;
      },
    }),
    "undefined" != typeof window &&
      window.NodeList &&
      !window.NodeList.prototype.forEach &&
      (NodeList.prototype.forEach = Array.prototype.forEach),
    Array.prototype.flat ||
      Object.defineProperty(Array.prototype, "flat", {
        configurable: !0,
        value: function e() {
          var t = isNaN(arguments[0]) ? 1 : Number(arguments[0]);
          return t
            ? Array.prototype.reduce.call(
                this,
                function (n, i) {
                  return (
                    Array.isArray(i)
                      ? n.push.apply(n, e.call(i, t - 1))
                      : n.push(i),
                    n
                  );
                },
                []
              )
            : Array.prototype.slice.call(this);
        },
        writable: !0,
      }),
    Array.prototype.flatMap ||
      Object.defineProperty(Array.prototype, "flatMap", {
        configurable: !0,
        value: function (e) {
          return Array.prototype.map.apply(this, arguments).flat();
        },
        writable: !0,
      });
  var _ = ["verbose", "debug", "info", "warn", "error", "off"],
    E = Symbol(),
    k = Symbol(),
    C = Symbol(),
    T = Symbol(),
    A = Symbol(),
    R = Symbol(),
    x = Symbol(),
    P = Symbol(),
    O = Symbol(),
    D = Symbol(),
    N = Symbol(),
    z = Symbol();
  function B(e, t, n) {
    var i,
      r =
        arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "off",
      o = [],
      a = r,
      s = _.indexOf(r),
      c = n;
    function l() {
      return c ? " [".concat(Date.now() - c, "]") : "";
    }
    function d(n) {
      if ("off" !== n) {
        var i = "error" === n || _.indexOf(n) >= s,
          r = "warn" === n || "error" === n;
        if (i || r) {
          for (
            var a = arguments.length, c = new Array(a > 1 ? a - 1 : 0), u = 1;
            u < a;
            u++
          )
            c[u - 1] = arguments[u];
          var d,
            f =
              "function" == typeof (d = c[0])
                ? d()
                : "string" == typeof d
                ? d
                : String(d),
            g = ["[".concat(t, "]-").concat(f).concat(l())].concat(
              y(c.slice(1))
            );
          if (
            (r &&
              (o.length >= 1e3 && (o = []), o.push({ level: n, params: g })),
            i)
          )
            e["verbose" != n ? n : "debug"].apply(null, g);
        }
      }
    }
    function f() {
      for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++)
        t[n] = arguments[n];
      d.apply(void 0, ["debug"].concat(t));
    }
    return (
      u(
        u(
          u(
            u(
              u(
                u(
                  u(
                    u(
                      u(
                        u((i = {}), x, function (e) {
                          c = e;
                        }),
                        P,
                        l
                      ),
                      O,
                      d
                    ),
                    T,
                    function () {
                      for (
                        var e = arguments.length, t = new Array(e), n = 0;
                        n < e;
                        n++
                      )
                        t[n] = arguments[n];
                      d.apply(void 0, ["error"].concat(t));
                    }
                  ),
                  E,
                  function () {
                    for (
                      var e = arguments.length, t = new Array(e), n = 0;
                      n < e;
                      n++
                    )
                      t[n] = arguments[n];
                    d.apply(void 0, ["warn"].concat(t));
                  }
                ),
                C,
                function () {
                  for (
                    var e = arguments.length, t = new Array(e), n = 0;
                    n < e;
                    n++
                  )
                    t[n] = arguments[n];
                  d.apply(void 0, ["info"].concat(t));
                }
              ),
              A,
              function () {
                for (
                  var e = arguments.length, t = new Array(e), n = 0;
                  n < e;
                  n++
                )
                  t[n] = arguments[n];
                d.apply(void 0, ["info"].concat(t));
              }
            ),
            k,
            f
          ),
          R,
          f
        ),
        D,
        function (e) {
          (a = e), (s = _.indexOf(e));
        }
      ),
      u(
        u(i, N, function () {
          return a;
        }),
        z,
        function () {
          return o;
        }
      )
    );
  }
  function M() {
    return function (e) {
      return function (t, n) {
        return e(
          (function (e, t) {
            function n(n, i, o) {
              if (e.has(n)) {
                if (t) return r;
                throw new Error(
                  "Token ".concat(String(n), " is already registered")
                );
              }
              return e.set(n, { deps: i, factory: o }), r;
            }
            function i() {
              return r;
            }
            var r = { register: n, export: i };
            return r;
          })(t, n)
        );
      };
    };
  }
  function U(e, t) {
    var n,
      i = null !== (n = e.fuseDebugger) && void 0 !== n ? n : null;
    return i && (i.connect(), t[k]("[MONITORING]: Debugger attached")), i;
  }
  var j = Symbol(),
    L = Symbol(),
    F = Symbol(),
    G = Symbol(),
    V = Symbol(),
    H = Symbol(),
    q = Symbol(),
    W = Symbol(),
    Y = Symbol();
  function Z(e, t) {
    var n = e.search
      .split(/[?&]/)
      .filter(function (e) {
        return "" !== e;
      })
      .map(function (e) {
        return e.split("=");
      })
      .filter(function (e) {
        return e[0] === t;
      });
    return n[0] || [];
  }
  function J(e) {
    try {
      return e.self.location;
    } catch (t) {
      return e.location;
    }
  }
  function Q(e) {
    var t,
      n = e.performance;
    return (
      (null === (t = null == n ? void 0 : n.timing) || void 0 === t
        ? void 0
        : t.navigationStart) || n.timeOrigin
    );
  }
  function K(e) {
    if ("true" === Z(e, "fuse_debug")[1]) return "debug";
    var t = Z(e, "fuse_log_level")[1];
    return t && -1 !== _.indexOf(t) ? t : "off";
  }
  function X(e, t, n) {
    return B(e.console, "FUSE", t, n);
  }
  var $,
    ee = M()(function (e) {
      return e
        .register(j, [], function () {
          return window.self;
        })
        .register(H, [j], J)
        .register(q, [H], function (e) {
          return e.href;
        })
        .register(Y, [], function () {
          return 2;
        })
        .register(G, [], function () {
          return (function () {
            for (
              var e =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : 20,
                t = "",
                n = 0;
              n < e;
              ++n
            )
              t += Math.floor(16 * Math.random()).toString(16);
            return t;
          })();
        })
        .register(V, [j], Q)
        .register(W, [H], K)
        .register(L, [j, V, W], X)
        .register(F, [j, L], U)
        .export();
    });
  function te(e) {
    return "object" === I(e) && null !== e;
  }
  function ne(e) {
    return "number" == typeof e && e == e;
  }
  function ie(e) {
    return "boolean" == typeof e && e == e;
  }
  function re(e) {
    return null == e;
  }
  function oe(e) {
    return void 0 === e;
  }
  function ae(e) {
    return !re(e);
  }
  function se(e) {
    return Array.isArray(e) && e.length > 0;
  }
  function ce(e) {
    throw new Error(
      "exhaustiveCheck(".concat(e, ") should not have been called")
    );
  }
  var ue = Symbol(),
    le = Symbol(),
    de = Symbol(),
    fe = Symbol(),
    ge = Symbol(),
    me = Symbol(),
    ve = Symbol(),
    pe = Symbol(),
    be = Symbol(),
    he = Symbol(),
    ye = Symbol(),
    Se = Symbol(),
    Ie = Symbol(),
    we = Symbol(),
    _e = Symbol(),
    Ee = Symbol(),
    ke = Symbol(),
    Ce = Symbol(),
    Te = new Set(["__proto__", "constructor", "prototype"]);
  function Ae(e) {
    return Te.has(e);
  }
  function Re(e, t) {
    var n,
      i = function (n) {
        var i = t(n)[1];
        if (i) {
          var r = parseInt(i);
          if (Number.isInteger(r)) return r;
          e[A](
            "[SETTINGS]: Could not parse "
              .concat(n, " with value ")
              .concat(i, " as a number")
          );
        }
        return null;
      },
      r = function (n) {
        var i = t(n)[1];
        if (re(i)) return null;
        var r = /^(false|true|1|0)$/i.test(i)
          ? Boolean(/^(true|1)$/i.test(i))
          : null;
        return (
          re(r) &&
            e[A](
              "[SETTINGS] Could not parse "
                .concat(n, " with value: ")
                .concat(i, " as a boolean")
            ),
          r
        );
      },
      o = function (e) {
        return t(e)[1] || "";
      },
      a = function (e) {
        var t = o(e);
        return t ? t.split(",") : null;
      };
    return (
      u(
        u(
          u(
            u(
              u(
                u(
                  u(
                    u(
                      u(
                        u((n = {}), ue, function () {
                          return i("fuseDelayInit");
                        }),
                        le,
                        function () {
                          return i("fuseDelayQuantcastInit");
                        }
                      ),
                      de,
                      function () {
                        return i("fuseDelayGptInit");
                      }
                    ),
                    fe,
                    function () {
                      return i("fuseDelayPrebidInit");
                    }
                  ),
                  ge,
                  function () {
                    return i("fuseDelayUamInit");
                  }
                ),
                me,
                function () {
                  return r("fuseMcmOff");
                }
              ),
              ve,
              function () {
                return r("fuseTestCreatives");
              }
            ),
            pe,
            function () {
              return r("fuseUseBrowserOuterwidth");
            }
          ),
          be,
          function () {
            return r("fuseDisableYandexSticky");
          }
        ),
        he,
        function () {
          return a("fuseAllowedBiddersInNewBids");
        }
      ),
      u(
        u(
          u(
            u(
              u(
                u(
                  u(
                    u(n, ye, function () {
                      return r("fuseUseBackwardCompatibleNaming");
                    }),
                    Se,
                    i
                  ),
                  Ie,
                  r
                ),
                we,
                o
              ),
              _e,
              a
            ),
            Ee,
            function (t) {
              var n = o(t);
              if (!re(n) && "" !== n) {
                if ("true" === n || "false" === n) return "true" === n;
                var i = parseInt(n, 10);
                if (Number.isInteger(i)) return i;
                e[A](
                  "[SETTINGS] Could not parse "
                    .concat(t, " with value: ")
                    .concat(n, " as a number")
                );
              }
            }
          ),
          ke,
          function (t, n, i) {
            t && t > 0
              ? (e[A]("[DELAY]: Delaying by ".concat(t, "ms to ").concat(n)),
                setTimeout(i, t))
              : i();
          }
        ),
        Ce,
        function (e, t) {
          var n = new RegExp(
              String.raw(
                $ ||
                  ($ = (function (e, t) {
                    return (
                      t || (t = e.slice(0)),
                      Object.freeze(
                        Object.defineProperties(e, {
                          raw: { value: Object.freeze(t) },
                        })
                      )
                    );
                  })(
                    [
                      "^fuse_(w+)_",
                      "(.(?!__proto__|constructor|prototype)w+|)$",
                    ],
                    [
                      "^fuse_(\\w+)_",
                      "(\\.(?!__proto__|constructor|prototype)\\w+|)$",
                    ]
                  )),
                e
              ),
              "i"
            ),
            i = t.search
              .split(/[?&]/)
              .filter(function (e) {
                return "" !== e;
              })
              .map(function (e) {
                return e.split("=");
              })
              .filter(function (e) {
                return n.test(e[0]);
              }),
            r = {};
          return (
            i.forEach(function (e) {
              var t = n.exec(e[0]);
              if (null == t ? void 0 : t[1]) {
                var i = decodeURIComponent(e[1]);
                "true" === e[1] ? (i = !0) : "false" === e[1] && (i = !1);
                var o = t[1];
                if (Ae(o)) return;
                if ((void 0 === r[o] && (r[o] = {}), t[2])) {
                  var a = t[2].substring(1);
                  if (Ae(a)) return;
                  r[o][a] = i;
                }
              }
            }),
            r
          );
        }
      )
    );
  }
  var xe = Symbol(),
    Pe = Symbol(),
    Oe = Symbol(),
    De = Symbol(),
    Ne = Symbol(),
    ze = Symbol(),
    Be = Symbol(),
    Me = Symbol(),
    Ue = Symbol(),
    je = Symbol(),
    Le = Symbol(),
    Fe = Symbol(),
    Ge = Symbol(),
    Ve = Symbol(),
    He = Symbol(),
    qe = "fuseConfigOverride";
  function We(e, t) {
    var n = e.search
      .split(/[?&]/)
      .filter(function (e) {
        return "" !== e;
      })
      .map(function (e) {
        return e.split("=");
      })
      .find(function (e) {
        return e[0] === t;
      });
    return n || [];
  }
  function Ye() {
    return e;
  }
  function Ze(e) {
    return !ae(e) || 0 == e.settings.publication_metadata.publication_id;
  }
  function Je(e, t, n, i) {
    if (n && e[qe]) return e[qe];
    var r = null != i ? i : t;
    if (!r) throw new Error("No injected config found");
    return r;
  }
  function Qe(e, t) {
    return Re(e, function (e) {
      try {
        return We(t.self.location, e);
      } catch (n) {
        return We(t.location, e);
      }
    });
  }
  function Ke(e) {
    return e.settings;
  }
  function Xe(e) {
    return (function (e) {
      var t = {};
      return (
        e.fuse_breakpoints.xl && (t.xl = e.fuse_breakpoints.xl),
        e.fuse_breakpoints.l && (t.l = e.fuse_breakpoints.l),
        (t.m = e.fuse_breakpoints.m),
        (t.s = e.fuse_breakpoints.s),
        (t.xs = e.fuse_breakpoints.xs),
        t
      );
    })(e);
  }
  function $e(e, t) {
    var n, i;
    return (
      null !==
        (i =
          null !== (n = e[pe]()) && void 0 !== n
            ? n
            : t.fuse_settings.isUseBrowserOuterwidth) &&
      void 0 !== i &&
      i
    );
  }
  function et(e) {
    return e.zoneCustomiser;
  }
  function tt(e) {
    return e.onLoadCallback;
  }
  function nt(e) {
    return e.in2wHook;
  }
  function it(e) {
    return e.admiralScript;
  }
  function rt(e) {
    return e.customTelemetryCallback;
  }
  function ot(e) {
    return te(e.geo) ? e.geo : void 0;
  }
  function at(e) {
    return te(e.cfConfig) ? e.cfConfig : void 0;
  }
  var st = M()(function (e) {
    return e
      .register(Oe, [], Ye)
      .register(Pe, [], function () {})
      .register(Be, [Oe], Ze)
      .register(xe, [j, Oe, Be, Pe], Je)
      .register(De, [L, j], Qe)
      .register(Ne, [xe], Ke)
      .register(ze, [Ne], Xe)
      .register(Me, [De, Ne], $e)
      .register(Ue, [xe], et)
      .register(je, [xe], tt)
      .register(Le, [xe], nt)
      .register(Fe, [xe], it)
      .register(Ge, [xe], rt)
      .register(Ve, [xe], ot)
      .register(He, [xe], at)
      .export();
  });
  function ct(e, t) {
    var n = [],
      i = null,
      r = [];
    function o(e) {
      n.push(e);
    }
    function a(e) {
      var t = n.indexOf(e);
      return t >= 0 && (n.splice(t, 1), !0);
    }
    function s(e) {
      var t = (function (e) {
        var t;
        return null ===
          (t = r
            .filter(function (t) {
              return t.subscriber === e;
            })
            .shift()) || void 0 === t
          ? void 0
          : t.wrapper;
      })(e);
      return a(t || e);
    }
    function c(e) {
      var t = function (n) {
        e(n), s(t);
      };
      o(t), r.push({ wrapper: t, subscriber: e });
    }
    return {
      eventName: t,
      subscribe: o,
      unsubscribe: s,
      once: c,
      immediateOrOnce: function (n) {
        return ae(i)
          ? (e[k](
              "[EVENT][".concat(
                t,
                "]: Already triggered, invoking callback synchronously"
              )
            ),
            n(i),
            !0)
          : (c(n), !1);
      },
      emit: function (r) {
        var o = n.length;
        o > 0
          ? e[k](
              "[EVENT]["
                .concat(t, "]: Fired, start processing ")
                .concat(o, " callbacks")
            )
          : e[k]("[EVENT][".concat(t, "]: Fired, no pending callbacks")),
          (i = r),
          n
            .map(function (e) {
              return e;
            })
            .forEach(function (n) {
              try {
                n(r);
              } catch (n) {
                n instanceof Error
                  ? e[T](
                      "[EVENT]["
                        .concat(t, "]: Caught exception in callback with item ")
                        .concat(r),
                      n.message,
                      n.stack
                    )
                  : e[T](
                      "[EVENT]["
                        .concat(
                          t,
                          "]: Caught exception of invalid type in callback with item "
                        )
                        .concat(r)
                    );
              }
            });
      },
      getSubscriberCount: function () {
        return n.length;
      },
    };
  }
  function ut(e, t, n, i) {
    var r = ct(e, t);
    return (
      n.subscribe(function (e) {
        var t = i(e);
        ae(t) && r.emit(t);
      }),
      r
    );
  }
  var lt = Symbol(),
    dt = Symbol(),
    ft = Symbol(),
    gt = Symbol(),
    mt = Symbol(),
    vt = Symbol(),
    pt = Symbol(),
    bt = Symbol(),
    ht = Symbol(),
    yt = Symbol(),
    St = Symbol(),
    It = Symbol(),
    wt = Symbol(),
    _t = Symbol(),
    Et = Symbol(),
    kt = Symbol(),
    Ct = Symbol(),
    Tt = Symbol(),
    At = Symbol(),
    Rt = Symbol(),
    xt = Symbol(),
    Pt = Symbol(),
    Ot = Symbol(),
    Dt = Symbol(),
    Nt = Symbol(),
    zt = Symbol(),
    Bt = Symbol(),
    Mt = Symbol(),
    Ut = Symbol(),
    jt = Symbol(),
    Lt = Symbol(),
    Ft = Symbol(),
    Gt = Symbol(),
    Vt = Symbol(),
    Ht = Symbol(),
    qt = Symbol(),
    Wt = Symbol(),
    Yt = Symbol(),
    Zt = Symbol(),
    Jt = Symbol();
  function Qt(e, t) {
    var n,
      i = {},
      r = {};
    function o(n) {
      var r,
        o = ct(e, n),
        a = null == t ? void 0 : t.fuseEventEmitterWrapper(),
        s = a ? a(o) : o;
      return null !== (r = i[n]) && void 0 !== r ? r : (i[n] = s);
    }
    function a(t, n, i) {
      var o;
      return null !== (o = r[t]) && void 0 !== o ? o : (r[t] = ut(e, t, n, i));
    }
    var s =
      (c(
        "get",
        c(
          "get",
          c(
            "get",
            c(
              "get",
              c(
                "get",
                c(
                  "get",
                  c(
                    "get",
                    c(
                      "get",
                      c(
                        "get",
                        c("get", (n = {}), lt, function () {
                          return o("onTagInitComplete");
                        }),
                        dt,
                        function () {
                          return o("onPageInit");
                        }
                      ),
                      ft,
                      function () {
                        return o("onPageInit");
                      }
                    ),
                    gt,
                    function () {
                      return o("onPageReset");
                    }
                  ),
                  mt,
                  function () {
                    return o("onZoneEvent");
                  }
                ),
                vt,
                function () {
                  return o("onAuctionEvent");
                }
              ),
              pt,
              function () {
                return a("register_zone", s[mt], function (e) {
                  return "registered" == e.zoneEventType ? e : null;
                });
              }
            ),
            bt,
            function () {
              return a("delete_zone", s[mt], function (e) {
                return "deleted" == e.zoneEventType ? e : null;
              });
            }
          ),
          ht,
          function () {
            return a("activate_zone_api", s[mt], function (e) {
              return "activate_zone_api" == e.zoneEventType ? e : null;
            });
          }
        ),
        yt,
        function () {
          return s[ht];
        }
      ),
      c(
        "get",
        c(
          "get",
          c(
            "get",
            c(
              "get",
              c(
                "get",
                c(
                  "get",
                  c(
                    "get",
                    c(
                      "get",
                      c(
                        "get",
                        c("get", n, St, function () {
                          return o("onComponentInitEvent");
                        }),
                        It,
                        function () {
                          return o("onInitManagerReady");
                        }
                      ),
                      wt,
                      function () {
                        return o("onWindowResized");
                      }
                    ),
                    Vt,
                    function () {
                      return o("onSlotRegistered");
                    }
                  ),
                  Ht,
                  function () {
                    return o("onSlotViewportEntered");
                  }
                ),
                qt,
                function () {
                  return o("onSlotDestroyed");
                }
              ),
              Wt,
              function () {
                return o("onHeldSlotReleaseRequested");
              }
            ),
            Yt,
            function () {
              return o("onHeldSlotAbandonRequested");
            }
          ),
          _t,
          function () {
            return o("onSlotLoaded");
          }
        ),
        Et,
        function () {
          return o("onSlotRender");
        }
      ),
      c(
        "get",
        c(
          "get",
          c(
            "get",
            c(
              "get",
              c(
                "get",
                c(
                  "get",
                  c(
                    "get",
                    c(
                      "get",
                      c(
                        "get",
                        c("get", n, kt, function () {
                          return o("onSlotResponse");
                        }),
                        Ct,
                        function () {
                          return o("onSlotRequested");
                        }
                      ),
                      Tt,
                      function () {
                        return o("onImpressionViewable");
                      }
                    ),
                    At,
                    function () {
                      return o("onSlotVisibilityChanged");
                    }
                  ),
                  Rt,
                  function () {
                    return o("onGameManualInterstitialSlotReady");
                  }
                ),
                xt,
                function () {
                  return o("onGameManualInterstitialSlotClosed");
                }
              ),
              Pt,
              function () {
                return o("onH5InterstitialUnsupported");
              }
            ),
            Ot,
            function () {
              return o("onRewardedSlotReady");
            }
          ),
          Dt,
          function () {
            return o("onRewardedSlotGranted");
          }
        ),
        Nt,
        function () {
          return o("onRewardedSlotClosed");
        }
      ),
      c(
        "get",
        c(
          "get",
          c(
            "get",
            c(
              "get",
              c(
                "get",
                c(
                  "get",
                  c(
                    "get",
                    c(
                      "get",
                      c(
                        "get",
                        c("get", n, zt, function () {
                          return o("onRewardedSlotVideoCompleted");
                        }),
                        Bt,
                        function () {
                          return o("onRewardedUnsupported");
                        }
                      ),
                      Mt,
                      function () {
                        return o("onPrebidAuctionEnd");
                      }
                    ),
                    Ut,
                    function () {
                      return o("onPrebidAdRenderFailed");
                    }
                  ),
                  jt,
                  function () {
                    return o("onPrebidAdRenderSucceeded");
                  }
                ),
                Lt,
                function () {
                  return o("onPrebidBidWon");
                }
              ),
              Ft,
              function () {
                return a("onBreakpointChanged", s[wt], function (e) {
                  return e.crossedBp ? e : null;
                });
              }
            ),
            Gt,
            function () {
              return o("onPrivacySettingsSet");
            }
          ),
          Zt,
          function () {
            return o("onCmpReady");
          }
        ),
        Jt,
        function () {
          return o("onIntentIqEidsReady");
        }
      ));
    return s;
  }
  var Kt = Symbol(),
    Xt = M()(function (e) {
      return e.register(Kt, [L, F], Qt).export();
    }),
    $t = Symbol(),
    en = Symbol(),
    tn = Symbol();
  function nn(e) {
    var t = {};
    function n(t) {
      var n = e.document.createElement("div");
      return (n.innerHTML = t), n.firstElementChild;
    }
    return u(
      u(
        u({}, $t, function (e, i) {
          return n(
            '<div id="'
              .concat(
                (function (e) {
                  t[e] || (t[e] = 0);
                  return "fuse-injected-".concat(e, "-").concat(++t[e]);
                })(e),
                '" data-fuse="'
              )
              .concat(e, '" data-fuse-injected-at="')
              .concat(new Date().getTime(), '" class="')
              .concat(i, '"></div>')
          );
        }),
        en,
        n
      ),
      tn,
      function (t, n) {
        var i = e.document.createElement("div");
        (i.innerHTML = '<style id="'.concat(t, '">').concat(n, "</style>")),
          e.document
            .querySelector("body")
            .insertAdjacentElement("beforeend", i.firstElementChild);
      }
    );
  }
  function rn(e) {
    return null === e ? void 0 : e;
  }
  function on(e) {
    try {
      return JSON.stringify(e);
    } catch (e) {
      return;
    }
  }
  var an = Symbol(),
    sn = Symbol(),
    cn = u(
      u({}, an, function () {}),
      sn,
      function () {}
    ),
    un = function (e) {
      var t = e.getBoundingClientRect().width;
      return t > 0 ? t : void 0;
    },
    ln = function (e, t) {
      e[E](
        "[VIEWPORT]: ResizeObserver failed, the breakpoint follows the window width",
        t
      );
    };
  function dn(e, t, n, i) {
    var r = t.ResizeObserver;
    if (!r)
      return (
        e[C](
          "[VIEWPORT]: ResizeObserver is not supported, the breakpoint follows the window width"
        ),
        cn
      );
    try {
      return (function (e, t, n, i) {
        var r,
          o,
          a = t.document,
          s = t.ResizeObserver,
          c = JSON.stringify(n),
          l = function () {
            return r && un(r);
          },
          d = function () {
            e[C](
              "[VIEWPORT]: No element matches ".concat(
                c,
                ", the breakpoint follows the window width"
              )
            );
          },
          f = new s(function () {
            r &&
              !r.isConnected &&
              (f.disconnect(), (r = void 0), "missing" === g() && d());
            var e = l();
            e !== o && ((o = e), i.onResized());
          });
        function g() {
          var t = (function (e, t) {
            try {
              return e.querySelector(t);
            } catch (e) {
              return "invalid";
            }
          })(a, n);
          if ("invalid" === t)
            return (
              e[E](
                "[VIEWPORT]: ".concat(
                  c,
                  " is not a valid breakpoint width selector, "
                ) + "the breakpoint follows the window width"
              ),
              "invalid"
            );
          if (!t) return "missing";
          try {
            f.observe(t, { box: "border-box" });
          } catch (t) {
            return ln(e, t), "failed";
          }
          return (
            (r = t),
            e[k](function () {
              return "[VIEWPORT]: The breakpoint follows the width of "
                .concat(c, ", currently ")
                .concat(un(t));
            }),
            "attached"
          );
        }
        var m = function () {
            a.removeEventListener("readystatechange", m);
            var e = g();
            "attached" === e
              ? ((o = l()), i.onFoundAfterParsing())
              : "missing" === e && d();
          },
          v = g();
        (o = l()),
          "missing" === v &&
            ("loading" === a.readyState
              ? a.addEventListener("readystatechange", m)
              : d());
        return u(
          u({}, an, function () {
            return o;
          }),
          sn,
          function () {
            a.removeEventListener("readystatechange", m), f.disconnect();
          }
        );
      })(e, { document: t.document, ResizeObserver: r }, n, i);
    } catch (t) {
      return ln(e, t), cn;
    }
  }
  var fn = Symbol(),
    gn = Symbol(),
    mn = Symbol(),
    vn = Symbol();
  function pn(e, t, n, i, r) {
    var o,
      a,
      s,
      c,
      l,
      d,
      f,
      g,
      m,
      v = function () {
        var e = t;
        return {
          width: r ? e.outerWidth : e.innerWidth,
          innerHeight: e.innerHeight,
          outerHeight: e.outerHeight,
          hidden: e.document.hidden,
          offset: { x: e.scrollX, y: e.scrollY },
        };
      },
      p =
        ((o = 500),
        (a = function () {
          return I();
        }),
        (g = function () {
          var e = Date.now() - d;
          e < o && e >= 0
            ? (s = setTimeout(g, o - e))
            : ((s = null), (f = a.apply(l, c)), s || (l = c = null));
        }),
        function () {
          return (
            (l = this),
            (c = arguments),
            (d = Date.now()),
            s || (s = setTimeout(g, o)),
            f
          );
        }),
      h = function () {
        var e = null == m ? void 0 : m[an]();
        return void 0 === e ? v().width : Math.max(e, n.xs);
      },
      y = function () {
        return (function (e, t) {
          var n = null;
          return (
            Object.entries(e).forEach(function (e) {
              var i = b(e, 2),
                r = i[0],
                o = i[1];
              t >= o && (!n || o > n.size) && (n = { size: o, name: r });
            }),
            n
          );
        })(n, h());
      },
      S = y().size;
    function I() {
      var t = y(),
        n = t.size,
        r = t.name,
        o = S !== n,
        a = o ? "changed to ".concat(r) : "unchanged at ".concat(r);
      e[k](function () {
        return (
          "[VIEWPORT]: Resized, window dimensions: ".concat(
            JSON.stringify(v()),
            ", "
          ) +
          "breakpoint width: ".concat(h(), ". The breakpoint was ").concat(a)
        );
      }),
        (S = n),
        i[wt].emit({ crossedBp: o, name: r, currentFrom: n });
    }
    function w() {
      y().size !== S && I();
    }
    return (
      t.addEventListener("resize", p),
      e[k]("[VIEWPORT]: Initialised at breakpoint ".concat(y().name)),
      u(
        u(
          u(u({}, fn, y), gn, function () {
            return "xs" !== y().name;
          }),
          mn,
          v
        ),
        vn,
        function (n) {
          null == m || m[sn](),
            (m = dn(e, t, n, { onFoundAfterParsing: w, onResized: p })),
            w();
        }
      )
    );
  }
  var bn = Symbol(),
    hn = Symbol(),
    yn = Symbol(),
    Sn = M()(function (e) {
      return e
        .register(bn, [j], nn)
        .register(hn, [L, j, ze, Kt, Me], pn)
        .register(yn, [hn], function (e) {
          return e[fn];
        })
        .export();
    }),
    In = [
      { name: "useControl" },
      null,
      { name: "in2wInjection", canBeIneligible: !0 },
      null,
      null,
      null,
      null,
      { name: "useIncreaseInitialTimeout" },
      { name: "useRefreshPrebidTimeoutBuffering", canBeIneligible: !0 },
      { name: "useAuctionSlotLimit" },
      { name: "useMaxViewports" },
      { name: "in2wSafeframe" },
      null,
      { name: "fullScreenAdExpansion" },
      null,
      null,
      { name: "useComboZones" },
      null,
      null,
      { name: "useAbandonLazyAuction" },
      null,
      null,
      { name: "useGamera", canBeIneligible: !0 },
      { name: "usePubxai" },
      { name: "usePubxaiPrebidOnly", canBeIneligible: !0 },
      { name: "useAdmiral", canBeIneligible: !0 },
      null,
      null,
      null,
      null,
      { name: "useAssertiveYield", canBeIneligible: !0 },
      null,
      { name: "usePubx" },
      { name: "usePrebidAuctionOptions" },
      { name: "useRefreshCap" },
      { name: "useBfcachePageReset" },
      { name: "gptUseNewApiPageTargeting" },
      { name: "gptUseNewApiSlotTargeting" },
      { name: "usePreconnectHints", canBeIneligible: !0 },
      { name: "gptUseNewApiPageSettings" },
      {
        name: "useTestMinOnScreenDuration",
        valKey: { values: ["5000", "10000", "15000", "20000"] },
      },
      { name: "usePreloadHints" },
      {
        name: "useRefreshTimeoutExpansion",
        canBeIneligible: !0,
        valKey: { values: ["6000", "10000", "20000"] },
      },
      { name: "useActiveViewRefresh" },
      { name: "useBidCacheFloors", canBeIneligible: !0 },
      { name: "useLazyBidding", canBeIneligible: !0 },
      { name: "useHeavyAdRefresh" },
      { name: "useBannerPosSignal", canBeIneligible: !0 },
      { name: "useOrtbDeviceGeo", canBeIneligible: !0 },
      { name: "useOrtbChromeAiRtd", canBeIneligible: !0 },
      {
        name: "useUserSyncAuctionDelay",
        canBeIneligible: !0,
        valKey: { values: ["100", "250", "500", "750", "1000"] },
      },
    ];
  function wn(e, t) {
    var n = Object.assign({}, e);
    for (var i in t)
      Object.prototype.hasOwnProperty.call(t, i) &&
        void 0 !== t[i] &&
        (n[i] = t[i]);
    return n;
  }
  var _n = Symbol(),
    En = Symbol(),
    kn = Symbol(),
    Cn = Symbol(),
    Tn = Symbol(),
    An = Symbol(),
    Rn = Symbol(),
    xn = Symbol();
  function Pn(e) {
    var t = { capture: !0, passive: !0 },
      n = e[Tn].getWindow(),
      i = e[Rn];
    return (
      n.addEventListener("scroll", i, t),
      u({}, xn, function () {
        n.removeEventListener("scroll", i, t);
      })
    );
  }
  var On = "InView";
  function Dn(e) {
    return u(
      u(u({}, _n, On), En, function (e) {
        return [Pn(e)];
      }),
      kn,
      function (t, n) {
        var i = n.slotRegistry.getSlot(t);
        if (i) {
          var r = n.viewportInfo[fn]().name,
            o = e[r];
          return !(!re(o) && !1 !== o) || i.isInView(o);
        }
        return !1;
      }
    );
  }
  function Nn(e, t, n) {
    var i = function (t) {
      n(t) && e[Rn]();
    };
    return (
      t.subscribe(i),
      u({}, xn, function () {
        return t.unsubscribe(i);
      })
    );
  }
  function zn(e) {
    var t = e[Tn].slotRegistry.getSlot(e[Cn]).zoneInstanceId;
    return Nn(e, e[Tn].events[ht], function (e) {
      return e.instanceId === t;
    });
  }
  var Bn = "ManualActivate";
  function Mn() {
    return u(
      u(u({}, _n, Bn), En, function (e) {
        return [zn(e)];
      }),
      kn,
      function (e, t) {
        var n,
          i =
            null === (n = t.slotRegistry.getSlot(e)) || void 0 === n
              ? void 0
              : n.zoneInstanceId;
        return ae(i) && t.zoneRegistry.isManuallyActivated(i);
      }
    );
  }
  var Un = Symbol(),
    jn = Symbol(),
    Ln = Symbol(),
    Fn = Symbol(),
    Gn = Symbol();
  function Vn() {
    var e = {},
      t = {};
    function n(t) {
      return e[t] || 0;
    }
    function i(e) {
      return t[e] || 0;
    }
    return u(
      u(
        u(u(u({}, Un, n), jn, i), Ln, function (t) {
          e[t] = n(t) + 1;
        }),
        Fn,
        function (e) {
          t[e] = i(e) + 1;
        }
      ),
      Gn,
      function () {
        (e = {}), (t = {});
      }
    );
  }
  var Hn = Symbol(),
    qn = Symbol(),
    Wn = Symbol(),
    Yn = Symbol(),
    Zn = Symbol(),
    Jn = Symbol(),
    Qn = Symbol(),
    Kn = Symbol(),
    Xn = Symbol(),
    $n = Symbol(),
    ei = Symbol(),
    ti = Symbol(),
    ni = Symbol(),
    ii = Symbol(),
    ri = Symbol(),
    oi = Symbol(),
    ai = Symbol(),
    si = Symbol(),
    ci = Symbol(),
    ui = Symbol(),
    li = Symbol(),
    di = Symbol(),
    fi = Symbol(),
    gi = Symbol(),
    mi = Symbol(),
    vi = Symbol(),
    pi = Symbol(),
    bi = Symbol(),
    hi = Symbol(),
    yi = Symbol();
  function Si(e, t) {
    var n,
      i,
      r,
      o,
      a,
      s,
      l,
      d,
      f,
      g,
      m = [],
      v = [],
      p = [],
      b = Date.now(),
      h = b - e,
      y = !1,
      S = !1,
      I = !1;
    function w() {
      return e;
    }
    function _() {
      return new Date().getTime() - w();
    }
    function E(e) {
      var t = Date.now();
      m.push(u(u(u({}, e, !0), "ts", t), "load_time_ms", t - w()));
    }
    function k(e, t) {
      var n = Date.now();
      v.push(
        Object.assign(Object.assign({ adEvent: e }, t), {
          ts: n,
          event_time_ms: n - w(),
        })
      );
    }
    return (
      m.push(u(u(u({}, "tag_loaded", !0), "ts", b), "load_time_ms", h)),
      t[_t].subscribe(function (e) {
        y || (E("gpt_first_slot_loaded"), (y = !0)),
          k("gpt_slot_loaded_".concat(e.slot.getSlotElementId()));
      }),
      t[kt].subscribe(function (e) {
        S || (E("gpt_first_slot_render_ended"), (S = !0)),
          k("gpt_slot_render_ended_".concat(e.slot.getSlotElementId()));
      }),
      t[Tt].subscribe(function (e) {
        I || (E("gpt_first_impression_viewable"), (I = !0)),
          k("gpt_impression_viewable_".concat(e.slot.getSlotElementId()));
      }),
      c(
        "get",
        c(
          "get",
          c(
            "get",
            c(
              "get",
              c(
                "get",
                c(
                  "get",
                  c(
                    "get",
                    u(u(u((n = {}), Hn, m), qn, v), Wn, p),
                    Yn,
                    function () {
                      return i;
                    }
                  ),
                  Zn,
                  function () {
                    return r;
                  }
                ),
                Jn,
                function () {
                  return Boolean(o && o <= 10);
                }
              ),
              Kn,
              function () {
                return Boolean(a && a <= 10);
              }
            ),
            Qn,
            function () {
              return o;
            }
          ),
          Xn,
          function () {
            return f;
          }
        ),
        $n,
        function () {
          return g;
        }
      ),
      u(
        u(
          u(
            u(
              u(
                u(
                  c(
                    "get",
                    c(
                      "get",
                      c(
                        "get",
                        c("get", n, ei, function () {
                          return h;
                        }),
                        oi,
                        function () {
                          return s;
                        }
                      ),
                      ai,
                      function () {
                        return l;
                      }
                    ),
                    si,
                    function () {
                      return d;
                    }
                  ),
                  ti,
                  function () {
                    return p;
                  }
                ),
                ni,
                function (e) {
                  p.length >= 1e3 && (p = p.slice(100)),
                    p.push(Object.assign(Object.assign({}, e), { time: _() }));
                }
              ),
              ii,
              w
            ),
            ri,
            _
          ),
          ci,
          function () {
            i = _();
          }
        ),
        ui,
        function () {
          r = r || _();
        }
      ),
      u(
        u(
          u(
            u(
              u(
                u(
                  u(
                    u(
                      u(
                        u(n, gi, function () {
                          o = o || _() - r;
                        }),
                        li,
                        function (e) {
                          s = e;
                        }
                      ),
                      di,
                      function (e) {
                        l = e;
                      }
                    ),
                    fi,
                    function (e) {
                      d = e;
                    }
                  ),
                  mi,
                  function () {
                    a = a || _() - r;
                  }
                ),
                vi,
                function () {
                  f = f || _();
                }
              ),
              pi,
              function () {
                g = g || _();
              }
            ),
            bi,
            E
          ),
          hi,
          k
        ),
        yi,
        function () {
          return Boolean(
            m.find(function (e) {
              return e.cmp_prompt_shown;
            })
          );
        }
      )
    );
  }
  var Ii = (function () {
      return a(
        function e(t, n, i, o, a, s, c, u) {
          var l = this;
          r(this, e),
            (this.slot = t),
            (this.logger = i),
            (this.reporter = o),
            (this.gptCountManager = s),
            (this.isRefreshPrebidTimeoutBuffering = c),
            (this.prebidRefreshTimeoutMs = u),
            (this.isRefreshEnabled = !0),
            (this.lastGptRequestTimestamp = 0),
            (this.lastRefreshTimestamp = 0),
            (this.lastAuctionTriggerTimestamp = 0),
            (this.slotRenderEventHandle = function () {
              return l.handleSlotRenderEvent();
            }),
            (this.slotLoadEventHandle = function () {
              return l.handleSlotLoadEvent();
            }),
            (this.slotRequestedEventHandle = function () {
              return l.handleSlotRequestedEvent();
            }),
            (this.refreshInterval = n),
            (this.slotRenderEventStream = this.createFilteredObservable(
              a[Et],
              t
            )),
            (this.slotLoadEventStream = this.createFilteredObservable(
              a[_t],
              t
            )),
            (this.slotRequestedEventStream = this.createFilteredObservable(
              a[Ct],
              t
            )),
            this.slotRenderEventStream.subscribe(this.slotRenderEventHandle),
            this.slotLoadEventStream.subscribe(this.slotLoadEventHandle),
            this.slotRequestedEventStream.subscribe(
              this.slotRequestedEventHandle
            );
        },
        [
          {
            key: "createFilteredObservable",
            value: function (e, t) {
              return ut(this.logger, "", e, function (e) {
                return e.slot.getSlotElementId() === t.slotDivId ? t : null;
              });
            },
          },
          {
            key: "createFilteredEventObservable",
            value: function (e, t) {
              return ut(this.logger, "", e, function (e) {
                return e.slot.getSlotElementId() === t.slotDivId ? e : null;
              });
            },
          },
          {
            key: "handleSlotRequestedEvent",
            value: function () {
              var e = this,
                t = Date.now(),
                n = this.lastGptRequestTimestamp;
              (this.lastGptRequestTimestamp = t),
                this.logger[k](function () {
                  var i = e.formatElapsedSeconds(t, n),
                    r = e.getRequestedLogContextExtras(t);
                  return "[REFRESH]: Received gpt requested for slot "
                    .concat(e.slot.slotDivId, " (")
                    .concat(i, " since last request")
                    .concat(r, ")");
                });
            },
          },
          {
            key: "getRequestedLogContextExtras",
            value: function (e) {
              return "";
            },
          },
          {
            key: "formatElapsedSeconds",
            value: function (e, t) {
              return t <= 0 || e < t
                ? "n/a"
                : "".concat(((e - t) / 1e3).toFixed(2), "s");
            },
          },
          {
            key: "disableRefresh",
            value: function () {
              (this.isRefreshEnabled = !1),
                this.logger[k](
                  "[REFRESH]: Refresh disabled for slot ".concat(
                    this.slot.slotDivId
                  )
                );
            },
          },
          {
            key: "enableRefresh",
            value: function () {
              (this.isRefreshEnabled = !0),
                this.scheduleRefresh("enableRefresh"),
                this.logger[k](
                  "[REFRESH]: Refresh enabled for slot ".concat(
                    this.slot.slotDivId
                  )
                );
            },
          },
          {
            key: "isBlockedByRefreshCallback",
            value: function () {
              try {
                return !this.slot.isAllowRefresh();
              } catch (e) {
                return (
                  this.logger[T](
                    "[REFRESH]: "
                      .concat(
                        this.slot.slotDivId,
                        " Refresh callback failed with "
                      )
                      .concat(JSON.stringify(e))
                  ),
                  !0
                );
              }
            },
          },
          {
            key: "isBlockedByRefreshExclusion",
            value: function () {
              return void 0 !== this.slot.refreshBlockedBy;
            },
          },
          {
            key: "isRefreshBlocked",
            value: function () {
              return this.isBlockedByRefreshCallback()
                ? (this.logger[C](
                    "[REFRESH]: ".concat(
                      this.slot.slotDivId,
                      " Refresh blocked by callback"
                    )
                  ),
                  !0)
                : !!this.isBlockedByRefreshExclusion() &&
                    (this.logger[C](
                      "[REFRESH]: "
                        .concat(
                          this.slot.slotDivId,
                          " Refresh blocked by exclusion: "
                        )
                        .concat(this.slot.refreshBlockedBy)
                    ),
                    !0);
            },
          },
          {
            key: "destroy",
            value: function () {
              this.slotRenderEventStream.unsubscribe(
                this.slotRenderEventHandle
              ),
                this.slotLoadEventStream.unsubscribe(this.slotLoadEventHandle),
                this.slotRequestedEventStream.unsubscribe(
                  this.slotRequestedEventHandle
                ),
                this.refreshTimer &&
                  (clearInterval(this.refreshTimer),
                  (this.refreshTimer = null)),
                (this.isRefreshEnabled = !1),
                (this.lastGptRequestTimestamp = 0),
                (this.lastRefreshTimestamp = 0),
                (this.lastAuctionTriggerTimestamp = 0),
                this.logger[k](
                  "[REFRESH]: Refresh strategy destroyed for slot ".concat(
                    this.slot.slotDivId
                  )
                );
            },
          },
          {
            key: "getLastGptRequestElapsedTime",
            value: function () {
              return this.lastGptRequestTimestamp - this.reporter[ii]();
            },
          },
          {
            key: "getPreFireOffsetMs",
            value: function () {
              return this.isRefreshPrebidTimeoutBuffering
                ? this.prebidRefreshTimeoutMs
                : 0;
            },
          },
          {
            key: "isCycleGateClosed",
            value: function () {
              var e = Date.now();
              return (
                !!this.isTriggeredAuctionPending(e) ||
                e <
                  this.lastGptRequestTimestamp +
                    1e3 * this.refreshInterval -
                    this.getPreFireOffsetMs()
              );
            },
          },
          {
            key: "isTriggeredAuctionPending",
            value: function (e) {
              var t = 1e3 * Math.max(this.refreshInterval, 30);
              return (
                this.lastAuctionTriggerTimestamp >
                  this.lastGptRequestTimestamp &&
                e <
                  this.lastAuctionTriggerTimestamp +
                    t +
                    this.prebidRefreshTimeoutMs
              );
            },
          },
          {
            key: "isRefreshCapped",
            value: function (e) {
              return (
                e.isUseRefreshCap &&
                e.maxRefreshCount > 0 &&
                this.gptCountManager[Un](this.slot.slotDivId) >
                  e.maxRefreshCount
              );
            },
          },
        ]
      );
    })(),
    wi = function (e) {
      return Array.isArray(e) ? "fluid" !== e[0] : "fluid" !== e;
    };
  function _i(e) {
    var t = (function (e) {
      return e.filter(wi);
    })(e);
    return t.length > 0 ? t : void 0;
  }
  var Ei = function (e, t) {
    var n = function (e) {
      if (e.includes("px")) {
        var t = Number(e.split("px")[0]);
        return Number.isNaN(t) ? void 0 : t;
      }
    };
    return {
      maxWidth: n(t.getComputedStyle(e).maxWidth),
      maxHeight: n(t.getComputedStyle(e).maxHeight),
    };
  };
  var ki = function (e) {
      return e[0] + "x" + e[1];
    },
    Ci = function (e) {
      return e.split("x").map(Number);
    },
    Ti = function (e) {
      var t = [1, 1];
      return (
        e.forEach(function (e) {
          e[0] > t[0] && (t[0] = e[0]), e[1] > t[1] && (t[1] = e[1]);
        }),
        t
      );
    },
    Ai = function (e, t) {
      return parseInt((100 * (e / t - 1)).toFixed());
    },
    Ri = [
      {
        name: "H3@300x250",
        parentSize: [970, 250],
        comboZoneSize: [300, 250],
        computedSize: [920, 250],
      },
      {
        name: "H2@300x250",
        parentSize: [970, 250],
        comboZoneSize: [300, 250],
        computedSize: [620, 250],
      },
      {
        name: "V2@300x250",
        parentSize: [300, 600],
        comboZoneSize: [300, 250],
        computedSize: [300, 510],
      },
    ];
  function xi(e) {
    var t = b(e.split("@"), 2),
      n = t[0],
      i = t[1];
    if (i)
      return {
        name: e,
        layout: "v" === n[0].toLowerCase() ? "vertical" : "horizontal",
        numZones: parseInt(n[1]),
        sizes: [Ci(i)],
      };
  }
  var Pi,
    Oi,
    Di,
    Ni = "fuse_format",
    zi = function (e, t) {
      var n,
        i,
        r,
        o = e.stickyAttributes,
        a = t.breakpoint,
        s =
          Boolean(null == o ? void 0 : o.isDoubleSticky) &&
          Boolean(e.attributes.sticky) &&
          !(null == o ? void 0 : o.isTop) &&
          !(null == o ? void 0 : o.compact) &&
          !(null == o ? void 0 : o.scrollCreative) &&
          !e.attributes.scrollToStick &&
          !(null == o ? void 0 : o.isCarousel) &&
          !e.attributes.comboZoneEnabled &&
          !e.attributes.forceComboZone &&
          t.viewportWidth >= 1546 &&
          void 0 !== a &&
          ((r = null === (n = e.sizeMapping) || void 0 === n ? void 0 : n[a]),
          Boolean(
            null == r
              ? void 0
              : r.some(function (e) {
                  return Array.isArray(e) && 728 === e[0] && 90 === e[1];
                })
          ))
            ? xi("H2@728x90")
            : void 0;
      return s
        ? Object.assign(Object.assign({}, e), {
            attributes: Object.assign(Object.assign({}, e.attributes), {
              forceComboZone: !0,
            }),
            comboZoneAttributes: s,
            sizeMapping: Object.assign(
              Object.assign({}, e.sizeMapping),
              u({}, a, y(s.sizes))
            ),
            targeting: [].concat(
              y(
                (null !== (i = e.targeting) && void 0 !== i ? i : []).filter(
                  function (e) {
                    return e.key !== Ni;
                  }
                )
              ),
              [{ key: Ni, value: "double_sticky" }]
            ),
          })
        : e;
    },
    Bi = /^v([1-9]\d?)$/;
  function Mi(e, t) {
    var n = Ui(e),
      i = Ui(t);
    return void 0 !== n && void 0 !== i && n >= i;
  }
  function Ui(e) {
    var t = Bi.exec(e);
    return null === t ? void 0 : Number(t[1]);
  }
  var ji = In.reduce(function (e, t) {
      return null !== t && void 0 !== t.valKey
        ? Object.assign(
            Object.assign({}, e),
            u({}, t.name, t.valKey.values.map(Number))
          )
        : e;
    }, {}),
    Li =
      null !== (Pi = ji.useTestMinOnScreenDuration) && void 0 !== Pi ? Pi : [],
    Fi = "0imnfm2",
    Gi = /^[a-z0-9]+$/i,
    Vi =
      null !== (Oi = ji.useRefreshTimeoutExpansion) && void 0 !== Oi ? Oi : [],
    Hi = null !== (Di = ji.useUserSyncAuctionDelay) && void 0 !== Di ? Di : [],
    qi = (function () {
      function e(t, n, i, o, a, s, c, l, d, f, g) {
        var m,
          v,
          p = this;
        r(this, e),
          (this.logger = t),
          (this.accountSettings = n),
          (this.breakpoints = i),
          (this.viewportInfo = o),
          (this.hostname = a),
          (this.queryParamReader = s),
          (this.zoneCustomiser = c),
          (this.in2wHook = l),
          (this.geo = d),
          (this.cfConfig = f),
          (this.overrideParams = g),
          (this.forceDisablePrebid = !1),
          (this.v2Compatibility = { disableWidgetsRenderer: !1 }),
          (this.isUamEnabled = function () {
            var e;
            return (
              !p.isYandexEnabled() &&
              (null === (e = p.fuseSettings.amazonUam) || void 0 === e
                ? void 0
                : e.enabled)
            );
          }),
          (this.isResponsiveEnabled = function () {
            return p.fuseSettings.responsive;
          }),
          (this.getInskinWidth = function () {
            return p.fuseSettings.inskinWidth;
          });
        var b = this.applyQueryOverrides(n.fuse_settings);
        (this.accountCode = this.determineAccount(
          a,
          n.account_code,
          n.account_domain_map
        )),
          (this.accountName = this.determineAccountName(
            a,
            n.account_name,
            n.account_name_domain_map
          ));
        var h = "71161633" === b.networkCode;
        (this.yieldExperiments = this.makeYieldExperimentsSettings(h, b)),
          this.logger[k](function () {
            return "[SETTINGS]: Yield experiments settings: ".concat(
              JSON.stringify(p.yieldExperiments)
            );
          }),
          (this.minOnScreenDurationMs = this.yieldExperiments
            .useTestMinOnScreenDuration.experimentValue
            ? this.computeBucketedMinOnScreenDurationMs()
            : null !== (m = b.minOnScreenDurationMs) && void 0 !== m
            ? m
            : 1e3),
          (this.prebidRefreshTimeoutMs = this.yieldExperiments
            .useRefreshTimeoutExpansion.experimentValue
            ? this.computeBucketedPrebidRefreshTimeoutMs()
            : null !== (v = b.prebidRefreshTimeoutMs) && void 0 !== v
            ? v
            : 4e3),
          (this.userSyncAuctionDelayMs = this.yieldExperiments
            .useUserSyncAuctionDelay.experimentValue
            ? this.computeBucketedUserSyncAuctionDelayMs()
            : 0),
          (this.forceSafeFrames = b.forceSafeFrame),
          (this.fuseSettings = this.applyYieldExperimentsOverrides(
            b,
            this.yieldExperiments
          )),
          this.logger[k](function () {
            return "[SETTINGS]: Final: ".concat(JSON.stringify(p.fuseSettings));
          }),
          this.initFuseSlots(),
          (this.yieldExperimentsTargeting = In.reduce(function (e, t, n) {
            if (null === t) return e;
            var i = p.yieldExperiments[t.name];
            if (!i.isYieldExperiment) return e;
            var r = "fuse_exp_".concat(n),
              o = i.isEligible
                ? "".concat(Boolean(i.experimentValue))
                : "ineligible";
            return Object.assign(Object.assign({}, e), u({}, r, o));
          }, {})),
          (this.additionalYieldExperimentTargeting = Object.assign(
            Object.assign(
              Object.assign(
                {},
                this.yieldExperiments.useTestMinOnScreenDuration
                  .experimentValue && {
                  "fuse_exp_40-val": this.minOnScreenDurationMs.toString(),
                }
              ),
              this.yieldExperiments.useRefreshTimeoutExpansion
                .experimentValue && {
                "fuse_exp_42-val": this.prebidRefreshTimeoutMs.toString(),
              }
            ),
            this.yieldExperiments.useUserSyncAuctionDelay.experimentValue && {
              "fuse_exp_50-val": this.userSyncAuctionDelayMs.toString(),
            }
          ));
      }
      return a(
        e,
        [
          {
            key: "overrideVideoSettings",
            value: function (e, t, n, i) {
              return t
                ? n
                  ? {
                      enabled: t,
                      partner: "primis",
                      placementId: n,
                      injectedAdUnitId: i,
                    }
                  : (this.logger[T](
                      "[SETTINGS]: Cannot enable Primis video partner without a valid placementId. Video settings not overridden."
                    ),
                    e)
                : e;
            },
          },
          {
            key: "applyQueryOverrides",
            value: function (e) {
              var t = this.queryParamReader;
              return wn(e, {
                useControl: t[Ee]("fuseUseControl"),
                in2wInjection: t[Ee]("fuseIn2wInjection"),
                useId5: rn(t[Ie]("fuseUseId5")),
                useCriteoId: rn(t[Ie]("fuseUseCriteoId")),
                useIncreaseInitialTimeout: t[Ee](
                  "fuseUseIncreaseInitialTimeout"
                ),
                useRefreshPrebidTimeoutBuffering: t[Ee](
                  "fuseUseRefreshPrebidTimeoutBuffering"
                ),
                prebidRefreshTimeoutMs: rn(t[Se]("fusePrebidRefreshTimeoutMs")),
                useRefreshTimeoutExpansion: t[Ee](
                  "fuseUseRefreshTimeoutExpansion"
                ),
                useAuctionSlotLimit: t[Ee]("fuseUseAuctionSlotLimit"),
                useMaxViewports: t[Ee]("fuseUseMaxViewports"),
                forceSafeFrame: rn(t[Ie]("fuseForceSafeFrame")),
                in2wSafeframe: t[Ee]("fuseIn2wSafeframe"),
                fullScreenAdExpansion: t[Ee]("fuseFullScreenAdExpansion"),
                useSharedId: rn(t[Ie]("fuseUseSharedId")),
                useComboZones: t[Ee]("fuseUseComboZones"),
                usePairId: rn(t[Ie]("fuseUsePairId")),
                useActiveViewRefresh: t[Ee]("fuseUseActiveViewRefresh"),
                useTestMinOnScreenDuration: t[Ee](
                  "fuseUseTestMinOnScreenDuration"
                ),
                minOnScreenDurationMs: rn(t[Se]("fuseMinOnScreenDurationMs")),
                useAbandonLazyAuction: t[Ee]("fuseUseAbandonLazyAuction"),
                useGamera: t[Ee]("fuseUseGamera"),
                usePubxai: t[Ee]("fuseUsePubxai"),
                usePubxaiPrebidOnly: t[Ee]("fuseUsePubxaiPrebidOnly"),
                useAdmiral: t[Ee]("fuseUseAdmiral"),
                useMinimumPerceivedRefresh: rn(
                  t[Ie]("fuseUseMinimumPerceivedRefresh")
                ),
                useCmpV2: rn(t[Ie]("fuseUseCmpV2")),
                useGpp: rn(t[Ie]("fuseUseGpp")),
                useGppUspv1: rn(t[Ie]("fuseUseGppUspv1")),
                useBackwardCompatibleNaming: rn(
                  t[Ie]("fuseUseBackwardCompatibleNaming")
                ),
                useAssertiveYield: t[Ee]("fuseUseAssertiveYield"),
                useAdfixusId: rn(t[Ie]("fuseUseAdfixusId")),
                usePubx: t[Ee]("fuseUsePubx"),
                pubxOnPercentage: rn(t[Se]("fusePubxOnPercentage")),
                pubxFloorFetch: rn(t[Ie]("fusePubxFloorFetch")),
                pubxAuctionDelay: rn(t[Se]("fusePubxAuctionDelay")),
                usePrebidAuctionOptions: t[Ee]("fuseUsePrebidAuctionOptions"),
                enableOptable: rn(t[Ie]("fuseEnableOptable")),
                useRefreshCap: t[Ee]("fuseUseRefreshCap"),
                iiqWaitForCallback: rn(t[Ie]("fuseIiqWaitForCallback")),
                ayWaitForCallback: rn(t[Ie]("fuseAyWaitForCallback")),
                maxRefreshCount: rn(t[Se]("fuseMaxRefreshCount")),
                videoSettings: this.overrideVideoSettings(
                  e.videoSettings,
                  rn(t[Ie]("fuseEnablePrimisVideo")),
                  rn(t[Se]("fusePrimisVideoPlacementId")),
                  rn(t[we]("fusePrimisVideoZoneIdentifier"))
                ),
                useGamSf: rn(t[Ie]("fuseUseGamSf")),
                useStickyCarousel: rn(t[Ie]("fuseUseStickyCarousel")),
                useCmpReadyEvent: rn(t[Ie]("fuseUseCmpReadyEvent")),
                useCmpGeoDetermination: rn(t[Ie]("fuseUseCmpGeoDetermination")),
                disableGdprInUS: rn(t[Ie]("fuseDisableGdprInUS")),
                easePrebidActivityControl: rn(
                  t[Ie]("fuseEasePrebidActivityControl")
                ),
                intentIQInChrome: rn(t[Ie]("fuseIntentIQInChrome")),
                useCookieBotEventListener: rn(
                  t[Ie]("fuseUseCookieBotEventListener")
                ),
                useBfcachePageReset: t[Ee]("fuseUseBfcachePageReset"),
                gptUseNewApiForceSafeFrame: rn(
                  t[Ie]("fuseGptUseNewApiForceSafeFrame")
                ),
                gptUseNewApiPageSettings: t[Ee]("fuseGptUseNewApiPageSettings"),
                gptUseNewApiPageTargeting: t[Ee](
                  "fuseGptUseNewApiPageTargeting"
                ),
                gptUseNewApiSlotTargeting: t[Ee](
                  "fuseGptUseNewApiSlotTargeting"
                ),
                usePreconnectHints: t[Ee]("fuseUsePreconnectHints"),
                usePreloadHints: t[Ee]("fuseUsePreloadHints"),
                useBidCacheFloors: t[Ee]("fuseUseBidCacheFloors"),
                useLazyBidding: t[Ee]("fuseUseLazyBidding"),
                useHeavyAdRefresh: t[Ee]("fuseUseHeavyAdRefresh"),
                useBannerPosSignal: t[Ee]("fuseUseBannerPosSignal"),
                useOrtbDeviceGeo: t[Ee]("fuseUseOrtbDeviceGeo"),
                useOrtbChromeAiRtd: t[Ee]("fuseUseOrtbChromeAiRtd"),
                useUserSyncAuctionDelay: t[Ee]("fuseUseUserSyncAuctionDelay"),
                useAmxId: rn(t[Ie]("fuseUseAmxId")),
                useUnifiedId: rn(t[Ie]("fuseUseUnifiedId")),
                disableCollapseEmptyDivs: rn(
                  t[Ie]("fuseDisableCollapseEmptyDivs")
                ),
              });
            },
          },
          {
            key: "applyYieldExperimentsOverrides",
            value: function (e, t) {
              var n = {};
              for (var i in t)
                Object.prototype.hasOwnProperty.call(t, i) &&
                  (n[i] = t[i].experimentValue);
              return wn(e, n);
            },
          },
          {
            key: "getYieldExperiment",
            value: function (e) {
              var t =
                  !(arguments.length > 1 && void 0 !== arguments[1]) ||
                  arguments[1],
                n = ne(e);
              return {
                setting: null != e && e,
                isYieldExperiment: n,
                isEligible: t,
                experimentValue:
                  t && n ? 100 * Math.random() < Number(e) : void 0,
              };
            },
          },
          {
            key: "computeBucketedMinOnScreenDurationMs",
            value: function () {
              var e,
                t = Math.min(
                  Math.floor(Math.random() * Li.length),
                  Li.length - 1
                );
              return null !== (e = Li[t]) && void 0 !== e ? e : 1e3;
            },
          },
          {
            key: "computeBucketedPrebidRefreshTimeoutMs",
            value: function () {
              var e,
                t = this.queryParamReader[Se](
                  "fuseRefreshTimeoutExpansionBucket"
                );
              if (null !== t && Vi.includes(t)) return t;
              var n = Math.min(
                Math.floor(Math.random() * Vi.length),
                Vi.length - 1
              );
              return null !== (e = Vi[n]) && void 0 !== e ? e : 4e3;
            },
          },
          {
            key: "computeBucketedUserSyncAuctionDelayMs",
            value: function () {
              var e,
                t = this.queryParamReader[Se]("fuseUserSyncAuctionDelayBucket");
              if (null !== t && Hi.includes(t)) return t;
              var n = Math.min(
                Math.floor(Math.random() * Hi.length),
                Hi.length - 1
              );
              return null !== (e = Hi[n]) && void 0 !== e ? e : 0;
            },
          },
          {
            key: "getYieldExperimentSettingValue",
            value: function (e) {
              return !!ie(e) && e;
            },
          },
          {
            key: "makeYieldExperimentsSettings",
            value: function (t, n) {
              var i,
                r,
                o,
                a,
                s = !1 !== n.useMinimumPerceivedRefresh,
                c = this.getYieldExperiment(
                  n.useRefreshPrebidTimeoutBuffering,
                  s
                ),
                u =
                  c.isEligible &&
                  (ie(n.useRefreshPrebidTimeoutBuffering)
                    ? n.useRefreshPrebidTimeoutBuffering
                    : Boolean(c.experimentValue)),
                l = this.getYieldExperiment(n.useActiveViewRefresh);
              return {
                useControl: this.getYieldExperiment(
                  re(n.useControl) ? 5 : n.useControl
                ),
                in2wInjection: this.getYieldExperiment(
                  n.in2wInjection,
                  void 0 !== this.in2wHook
                ),
                useIncreaseInitialTimeout: this.getYieldExperiment(
                  n.useIncreaseInitialTimeout
                ),
                useRefreshPrebidTimeoutBuffering: c,
                useAuctionSlotLimit: this.getYieldExperiment(
                  n.useAuctionSlotLimit
                ),
                useMaxViewports: this.getYieldExperiment(
                  !n.maxViewportsFirstAuction && n.useMaxViewports
                ),
                in2wSafeframe: this.getYieldExperiment(n.in2wSafeframe),
                fullScreenAdExpansion: this.getYieldExperiment(
                  n.fullScreenAdExpansion
                ),
                useComboZones: this.getYieldExperiment(n.useComboZones),
                useTestMinOnScreenDuration: this.getYieldExperiment(
                  n.useTestMinOnScreenDuration
                ),
                useAbandonLazyAuction: this.getYieldExperiment(
                  n.useAbandonLazyAuction
                ),
                useGamera: this.getYieldExperiment(n.useGamera, t),
                usePubxai: this.getYieldExperiment(n.usePubxai),
                usePubxaiPrebidOnly: this.getYieldExperiment(
                  n.usePubxaiPrebidOnly,
                  !n.usePubxai
                ),
                useAdmiral: this.getYieldExperiment(
                  n.useAdmiral,
                  !(null === (i = n.admiral) || void 0 === i
                    ? void 0
                    : i.enabled)
                ),
                useAssertiveYield: this.getYieldExperiment(
                  n.useAssertiveYield,
                  (null === (r = n.prebidServerBidderCodes) || void 0 === r
                    ? void 0
                    : r.length) > 0
                ),
                usePubx: this.getYieldExperiment(n.usePubx),
                usePrebidAuctionOptions: this.getYieldExperiment(
                  n.usePrebidAuctionOptions
                ),
                useRefreshCap: this.getYieldExperiment(n.useRefreshCap),
                useBfcachePageReset: this.getYieldExperiment(
                  n.useBfcachePageReset
                ),
                gptUseNewApiPageSettings: this.getYieldExperiment(
                  n.gptUseNewApiPageSettings
                ),
                gptUseNewApiPageTargeting: this.getYieldExperiment(
                  n.gptUseNewApiPageTargeting
                ),
                gptUseNewApiSlotTargeting: this.getYieldExperiment(
                  n.gptUseNewApiSlotTargeting
                ),
                usePreconnectHints: this.getYieldExperiment(
                  n.usePreconnectHints,
                  (null !==
                    (a =
                      null === (o = n.preconnectDomains) || void 0 === o
                        ? void 0
                        : o.length) && void 0 !== a
                    ? a
                    : 0) > 0 ||
                    !(
                      n.yandex ||
                      this.queryParamReader[Ie]("fuseYandex") ||
                      "" !== this.queryParamReader[we]("fuseYandexBlockId")
                    )
                ),
                usePreloadHints: this.getYieldExperiment(n.usePreloadHints),
                useRefreshTimeoutExpansion: this.getYieldExperiment(
                  n.useRefreshTimeoutExpansion,
                  u
                ),
                useActiveViewRefresh: l,
                useBidCacheFloors: this.getYieldExperiment(
                  n.useBidCacheFloors,
                  e.isBidCacheEnabledFor(n)
                ),
                useLazyBidding: this.getYieldExperiment(
                  n.useLazyBidding,
                  e.hasHeaderBiddingFor(n) && !this.isYandexEnabledFor(n)
                ),
                useHeavyAdRefresh: this.getYieldExperiment(n.useHeavyAdRefresh),
                useBannerPosSignal: this.getYieldExperiment(
                  n.useBannerPosSignal,
                  e.hasHeaderBiddingFor(n) && e.hasPrebidBannerFor(n)
                ),
                useOrtbDeviceGeo: this.getYieldExperiment(
                  n.useOrtbDeviceGeo,
                  e.hasHeaderBiddingFor(n)
                ),
                useOrtbChromeAiRtd: this.getYieldExperiment(
                  n.useOrtbChromeAiRtd,
                  e.hasHeaderBiddingFor(n) && this.checkMinimumRevision("v6")
                ),
                useUserSyncAuctionDelay: this.getYieldExperiment(
                  n.useUserSyncAuctionDelay,
                  e.hasHeaderBiddingFor(n) && e.hasConfiguredPrebidUserIdFor(n)
                ),
              };
            },
          },
          {
            key: "getYieldExperimentsTargeting",
            value: function () {
              return this.yieldExperimentsTargeting;
            },
          },
          {
            key: "getAdditionalYieldExperimentsTargeting",
            value: function () {
              return this.additionalYieldExperimentTargeting;
            },
          },
          {
            key: "getUamSettings",
            value: function () {
              return this.fuseSettings.amazonUam;
            },
          },
          {
            key: "isPrebidEnabled",
            value: function () {
              var e;
              return (
                !this.isYandexEnabled() &&
                !this.forceDisablePrebid &&
                (null === (e = this.fuseSettings.prebid) || void 0 === e
                  ? void 0
                  : e.enabled)
              );
            },
          },
          {
            key: "getAssertiveYieldEntityId",
            value: function () {
              return this.fuseSettings.assertiveYieldEntityId;
            },
          },
          {
            key: "getPrebidServerBidders",
            value: function () {
              var e,
                t =
                  null !== (e = this.fuseSettings.prebidServerBidderCodes) &&
                  void 0 !== e
                    ? e
                    : [],
                n = this.getExcludedNetworksForGeo();
              if (0 === n.length) return t;
              var i = new Set(n);
              return t.filter(function (e) {
                return !i.has(e);
              });
            },
          },
          {
            key: "getPrebidClientBidders",
            value: function () {
              var e;
              return null !== (e = this.fuseSettings.prebidClientBidderCodes) &&
                void 0 !== e
                ? e
                : [];
            },
          },
          {
            key: "getPrebidSettings",
            value: function () {
              return this.fuseSettings.prebid;
            },
          },
          {
            key: "getFuseUUID",
            value: function () {
              return this.accountSettings.fuse_uuid;
            },
          },
          {
            key: "getSco",
            value: function () {
              return this.accountSettings.sco;
            },
          },
          {
            key: "getTagRevision",
            value: function () {
              return this.accountSettings.publication_metadata.revision;
            },
          },
          {
            key: "isPrebidV11",
            value: function () {
              return "v8" === this.getTagRevision();
            },
          },
          {
            key: "checkMinimumRevision",
            value: function (e) {
              return Mi(this.getTagRevision(), e);
            },
          },
          {
            key: "getFuseId",
            value: function () {
              return this.accountSettings.fuse_id;
            },
          },
          {
            key: "getUseTelemetry",
            value: function () {
              return "disabled" !== this.fuseSettings.telemetry;
            },
          },
          {
            key: "getReportPageInfo",
            value: function () {
              return Boolean(this.fuseSettings.useReportPageInfo);
            },
          },
          {
            key: "getEventHistoryTTLOverride",
            value: function () {
              var e;
              return null !== (e = this.fuseSettings.eventHistoryTTLOverride) &&
                void 0 !== e
                ? e
                : 300;
            },
          },
          {
            key: "getMinBidCacheTTLOverride",
            value: function () {
              var e;
              return null !== (e = this.fuseSettings.minBidCacheTTLOverride) &&
                void 0 !== e
                ? e
                : 60;
            },
          },
          {
            key: "getConfiantId",
            value: function () {
              return this.fuseSettings.confiantId;
            },
          },
          {
            key: "getLowDwellPages",
            value: function () {
              var e;
              return null !== (e = this.fuseSettings.lowDwellPages) &&
                void 0 !== e
                ? e
                : [];
            },
          },
          {
            key: "getMaxViewportsFirstAuction",
            value: function () {
              var e;
              return null !==
                (e = this.fuseSettings.maxViewportsFirstAuction) && void 0 !== e
                ? e
                : this.isUseMaxViewportsEnabled()
                ? 1
                : void 0;
            },
          },
          {
            key: "getCmpProvider",
            value: function () {
              return (
                this._cmpProvider ||
                  ((this._cmpProvider = this.isCmpRequired()
                    ? this.fuseSettings.cmpProvider
                    : { partner: "none" }),
                  this.isNoCmpTestMode() &&
                    "none" === this._cmpProvider.partner &&
                    (this.logger[E](
                      "[SETTINGS]: No CMP provider configured for noCmpTestMode, forcing Quantcast"
                    ),
                    (this._cmpProvider = { partner: "quantcast" }))),
                this._cmpProvider
              );
            },
          },
          {
            key: "isCmpRequired",
            value: function () {
              return (
                !this.isYandexEnabled() &&
                ("none" !== this.fuseSettings.cmp || this.isNoCmpTestMode())
              );
            },
          },
          {
            key: "useCmpReadyEvent",
            value: function () {
              var e;
              return (
                this.isCmpRequired() &&
                this.isCmpV2Enabled() &&
                ((null !== (e = this.fuseSettings.useCmpReadyEvent) &&
                  void 0 !== e &&
                  e) ||
                  this.isUseWaitForCmpDeterminationEnabled())
              );
            },
          },
          {
            key: "useCmpGeoDetermination",
            value: function () {
              var e;
              return (
                this.isCmpRequired() &&
                this.isCmpV2Enabled() &&
                ((null !== (e = this.fuseSettings.useCmpGeoDetermination) &&
                  void 0 !== e &&
                  e) ||
                  this.isUseWaitForCmpDeterminationEnabled())
              );
            },
          },
          {
            key: "isUseWaitForCmpDeterminationEnabled",
            value: function () {
              var e;
              return (
                null !== (e = this.fuseSettings.useWaitForCmpDetermination) &&
                void 0 !== e &&
                e
              );
            },
          },
          {
            key: "disableGdprInUS",
            value: function () {
              return (
                Boolean(this.fuseSettings.disableGdprInUS) &&
                this.isGppEnabled()
              );
            },
          },
          {
            key: "easePrebidActivityControlEnabled",
            value: function () {
              var e;
              return (
                this.isPrebidActivityControlEnabled() &&
                null !== (e = this.fuseSettings.easePrebidActivityControl) &&
                void 0 !== e &&
                e
              );
            },
          },
          {
            key: "isNoCmpTestMode",
            value: function () {
              var e;
              return (
                void 0 === this._noCmpTestValue &&
                  (this._noCmpTestValue =
                    "noCmp" === this.accountSettings.fuse_flavour &&
                    100 * Math.random() <
                      (null !== (e = this.fuseSettings.noCmpTestWeight) &&
                      void 0 !== e
                        ? e
                        : 1)),
                this._noCmpTestValue
              );
            },
          },
          {
            key: "getCmpMode",
            value: function () {
              return this.isYandexEnabled() || !this.fuseSettings.cmp
                ? "disabled"
                : this.fuseSettings.strict_cmp
                ? "strict"
                : "enabled";
            },
          },
          {
            key: "getCmpSkipStub",
            value: function () {
              var e;
              return Boolean(
                null !== (e = this.fuseSettings.cmpSkipStub) && void 0 !== e
                  ? e
                  : "fundingchoices" === this.getCmpProvider().partner
              );
            },
          },
          {
            key: "getDisableGppStub",
            value: function () {
              return Boolean(this.fuseSettings.disableGppStub);
            },
          },
          {
            key: "getPrebidGdprTimeoutMs",
            value: function () {
              var e, t;
              return null !==
                (t =
                  null !==
                    (e = this.queryParamReader[Se](
                      "fusePrebidGdprTimeoutMs"
                    )) && void 0 !== e
                    ? e
                    : this.fuseSettings.prebidGdprTimeoutMs) && void 0 !== t
                ? t
                : 2e4;
            },
          },
          {
            key: "getPrebidUspTimeoutMs",
            value: function () {
              var e, t;
              return null !==
                (t =
                  null !==
                    (e = this.queryParamReader[Se]("fusePrebidUspTimeoutMs")) &&
                  void 0 !== e
                    ? e
                    : this.fuseSettings.prebidUspTimeoutMs) && void 0 !== t
                ? t
                : 1e3;
            },
          },
          {
            key: "getPrebidGppTimeoutMs",
            value: function () {
              var e, t;
              return null !==
                (t =
                  null !==
                    (e = this.queryParamReader[Se]("fusePrebidGppTimeoutMs")) &&
                  void 0 !== e
                    ? e
                    : this.fuseSettings.prebidGppTimeoutMs) && void 0 !== t
                ? t
                : 1e3;
            },
          },
          {
            key: "getTagStartCutoffMs",
            value: function () {
              var e;
              return null !==
                (e = this.queryParamReader[Se]("fuseTagStartCutoffMs")) &&
                void 0 !== e
                ? e
                : this.fuseSettings.tagStartCutoffMs;
            },
          },
          {
            key: "getPrebidDownloadCutoffMs",
            value: function () {
              var e;
              return null !==
                (e = this.queryParamReader[Se]("fusePrebidDownloadCutoffMs")) &&
                void 0 !== e
                ? e
                : this.fuseSettings.prebidDownloadCutoffMs;
            },
          },
          {
            key: "getPrebidTagStartCutoffMs",
            value: function () {
              var e;
              return null !==
                (e = this.queryParamReader[Se]("fusePrebidTagStartCutoffMs")) &&
                void 0 !== e
                ? e
                : this.fuseSettings.prebidTagStartCutoffMs;
            },
          },
          {
            key: "getUamTagStartCutoffMs",
            value: function () {
              var e;
              return null !==
                (e = this.queryParamReader[Se]("fuseUamTagStartCutoffMs")) &&
                void 0 !== e
                ? e
                : this.fuseSettings.uamTagStartCutoffMs;
            },
          },
          {
            key: "getAuctionMaxSlots",
            value: function () {
              var e,
                t,
                n =
                  null !==
                    (t =
                      null !==
                        (e = this.queryParamReader[Se](
                          "fuseAuctionMaxSlots"
                        )) && void 0 !== e
                        ? e
                        : this.fuseSettings.auctionMaxSlots) && void 0 !== t
                    ? t
                    : 99;
              return this.isAuctionSlotLimitEnabled() ? Math.min(n, 10) : n;
            },
          },
          {
            key: "isIdentityEnabled",
            value: function () {
              var e, t;
              return (
                !this.enableOptable() &&
                null !==
                  (t =
                    null === (e = this.fuseSettings.identity) || void 0 === e
                      ? void 0
                      : e.enabled) &&
                void 0 !== t &&
                t
              );
            },
          },
          {
            key: "getIdentitySettings",
            value: function () {
              return this.fuseSettings.identity;
            },
          },
          {
            key: "getAfsSettings",
            value: function () {
              var e;
              return null !== (e = this.fuseSettings.afs) && void 0 !== e
                ? e
                : { enabled: !1 };
            },
          },
          {
            key: "isComboZoneEnabled",
            value: function () {
              return this.getYieldExperimentSettingValue(
                this.fuseSettings.useComboZones
              );
            },
          },
          {
            key: "isComboZoneYeRunning",
            value: function () {
              return this.yieldExperiments.useComboZones.isYieldExperiment;
            },
          },
          {
            key: "isStickyCarouselEnabled",
            value: function () {
              var e;
              return (
                null !== (e = this.fuseSettings.useStickyCarousel) &&
                void 0 !== e &&
                e
              );
            },
          },
          {
            key: "isCaptureInViewTimeEnabled",
            value: function () {
              return this.getUseTelemetry();
            },
          },
          {
            key: "isStopRefreshOnMatchedIdEnabled",
            value: function () {
              var e;
              return (
                null !== (e = this.fuseSettings.useStopRefreshOnMatchedId) &&
                void 0 !== e &&
                e
              );
            },
          },
          {
            key: "isStopRefreshOnMatchedIdActive",
            value: function () {
              var e, t, n, i;
              if (!this.isStopRefreshOnMatchedIdEnabled()) return !1;
              var r = this.fuseSettings.refreshExclusions;
              return (
                (null !==
                  (t =
                    null === (e = null == r ? void 0 : r.advertiserIds) ||
                    void 0 === e
                      ? void 0
                      : e.length) && void 0 !== t
                  ? t
                  : 0) > 0 ||
                (null !==
                  (i =
                    null === (n = null == r ? void 0 : r.orderIds) ||
                    void 0 === n
                      ? void 0
                      : n.length) && void 0 !== i
                  ? i
                  : 0) > 0
              );
            },
          },
          {
            key: "getStopRefreshAdvertiserIds",
            value: function () {
              var e, t;
              return null !==
                (t =
                  null === (e = this.fuseSettings.refreshExclusions) ||
                  void 0 === e
                    ? void 0
                    : e.advertiserIds) && void 0 !== t
                ? t
                : [];
            },
          },
          {
            key: "getStopRefreshCampaignIds",
            value: function () {
              var e, t;
              return null !==
                (t =
                  null === (e = this.fuseSettings.refreshExclusions) ||
                  void 0 === e
                    ? void 0
                    : e.orderIds) && void 0 !== t
                ? t
                : [];
            },
          },
          {
            key: "getStopRefreshMode",
            value: function () {
              var e, t;
              return null !==
                (t =
                  null === (e = this.fuseSettings.refreshExclusions) ||
                  void 0 === e
                    ? void 0
                    : e.mode) && void 0 !== t
                ? t
                : "block";
            },
          },
          {
            key: "isId5Enabled",
            value: function () {
              var e, t;
              return null !==
                (t =
                  null === (e = this.fuseSettings.id5) || void 0 === e
                    ? void 0
                    : e.enabled) && void 0 !== t
                ? t
                : !1 !== this.fuseSettings.useId5;
            },
          },
          {
            key: "isIn2wInjection",
            value: function () {
              return (
                !!this.yieldExperiments.in2wInjection.isEligible &&
                this.getYieldExperimentSettingValue(
                  this.fuseSettings.in2wInjection
                )
              );
            },
          },
          {
            key: "isIn2wSafeframe",
            value: function () {
              return this.getYieldExperimentSettingValue(
                this.fuseSettings.in2wSafeframe
              );
            },
          },
          {
            key: "isBidCacheEnabled",
            value: function () {
              return e.isBidCacheEnabledFor(this.fuseSettings);
            },
          },
          {
            key: "isPairIdEnabled",
            value: function () {
              return (
                !this.enableOptable() && !0 === this.fuseSettings.usePairId
              );
            },
          },
          {
            key: "isAdfixusIdEnabled",
            value: function () {
              return !0 === this.fuseSettings.useAdfixusId;
            },
          },
          {
            key: "isAmxIdEnabled",
            value: function () {
              return !1 !== this.fuseSettings.useAmxId;
            },
          },
          {
            key: "isUnifiedIdEnabled",
            value: function () {
              return !1 !== this.fuseSettings.useUnifiedId;
            },
          },
          {
            key: "getUnifiedIdPartner",
            value: function () {
              var e = this.fuseSettings.unifiedIdPartner;
              return e
                ? Gi.test(e)
                  ? e
                  : (this.logger[E](
                      "[SETTINGS]: unifiedIdPartner is not alphanumeric, using the default partner"
                    ),
                    Fi)
                : Fi;
            },
          },
          {
            key: "isPrebidAuctionOptionsEnabled",
            value: function () {
              return this.getYieldExperimentSettingValue(
                this.fuseSettings.usePrebidAuctionOptions
              );
            },
          },
          {
            key: "isAbandonLazyAuctionEnabled",
            value: function () {
              return this.getYieldExperimentSettingValue(
                this.fuseSettings.useAbandonLazyAuction
              );
            },
          },
          {
            key: "isLazyBiddingEnabled",
            value: function () {
              return (
                !!this.yieldExperiments.useLazyBidding.isEligible &&
                this.getYieldExperimentSettingValue(
                  this.fuseSettings.useLazyBidding
                )
              );
            },
          },
          {
            key: "isSharedIdEnabled",
            value: function () {
              return !1 !== this.fuseSettings.useSharedId;
            },
          },
          {
            key: "isCriteoIdEnabled",
            value: function () {
              return !1 !== this.fuseSettings.useCriteoId;
            },
          },
          {
            key: "isRefreshPrebidTimeoutBuffering",
            value: function () {
              return (
                !!this.yieldExperiments.useRefreshPrebidTimeoutBuffering
                  .isEligible &&
                this.getYieldExperimentSettingValue(
                  this.fuseSettings.useRefreshPrebidTimeoutBuffering
                )
              );
            },
          },
          {
            key: "getPrebidRefreshTimeoutMs",
            value: function () {
              return this.prebidRefreshTimeoutMs;
            },
          },
          {
            key: "getPrebidUserSyncAuctionDelayMs",
            value: function () {
              return this.userSyncAuctionDelayMs;
            },
          },
          {
            key: "isIncreaseInitialTimeout",
            value: function () {
              return this.getYieldExperimentSettingValue(
                this.fuseSettings.useIncreaseInitialTimeout
              );
            },
          },
          {
            key: "isAuctionSlotLimitEnabled",
            value: function () {
              return this.getYieldExperimentSettingValue(
                this.fuseSettings.useAuctionSlotLimit
              );
            },
          },
          {
            key: "isUseMaxViewportsEnabled",
            value: function () {
              return this.getYieldExperimentSettingValue(
                this.fuseSettings.useMaxViewports
              );
            },
          },
          {
            key: "isUseGameraEnabled",
            value: function () {
              return (
                !!this.yieldExperiments.useGamera.isEligible &&
                this.getYieldExperimentSettingValue(this.fuseSettings.useGamera)
              );
            },
          },
          {
            key: "isActiveViewRefreshEnabled",
            value: function () {
              return (
                !!this.yieldExperiments.useActiveViewRefresh.isEligible &&
                this.getYieldExperimentSettingValue(
                  this.fuseSettings.useActiveViewRefresh
                )
              );
            },
          },
          {
            key: "isHeavyAdRefreshEnabled",
            value: function () {
              return this.getYieldExperimentSettingValue(
                this.fuseSettings.useHeavyAdRefresh
              );
            },
          },
          {
            key: "isBannerPosSignalEnabled",
            value: function () {
              return (
                !!this.yieldExperiments.useBannerPosSignal.isEligible &&
                this.getYieldExperimentSettingValue(
                  this.fuseSettings.useBannerPosSignal
                )
              );
            },
          },
          {
            key: "isOrtbDeviceGeoEnabled",
            value: function () {
              return (
                !!this.yieldExperiments.useOrtbDeviceGeo.isEligible &&
                this.getYieldExperimentSettingValue(
                  this.fuseSettings.useOrtbDeviceGeo
                )
              );
            },
          },
          {
            key: "isOrtbChromeAiRtdEnabled",
            value: function () {
              return (
                !!this.yieldExperiments.useOrtbChromeAiRtd.isEligible &&
                this.getYieldExperimentSettingValue(
                  this.fuseSettings.useOrtbChromeAiRtd
                )
              );
            },
          },
          {
            key: "getMinOnScreenDurationMs",
            value: function () {
              return this.minOnScreenDurationMs;
            },
          },
          {
            key: "isUseRefreshCapEnabled",
            value: function () {
              return this.getYieldExperimentSettingValue(
                this.fuseSettings.useRefreshCap
              );
            },
          },
          {
            key: "isBfcachePageResetEnabled",
            value: function () {
              return this.getYieldExperimentSettingValue(
                this.fuseSettings.useBfcachePageReset
              );
            },
          },
          {
            key: "getMaxRefreshCount",
            value: function () {
              var e;
              return null !== (e = this.fuseSettings.maxRefreshCount) &&
                void 0 !== e
                ? e
                : 50;
            },
          },
          {
            key: "isAdmiralEnabled",
            value: function () {
              var e, t;
              return null !==
                (t =
                  null === (e = this.fuseSettings.admiral) || void 0 === e
                    ? void 0
                    : e.enabled) && void 0 !== t
                ? t
                : !!this.yieldExperiments.useAdmiral.isEligible &&
                    this.getYieldExperimentSettingValue(
                      this.fuseSettings.useAdmiral
                    );
            },
          },
          {
            key: "isAssertiveYieldEnabled",
            value: function () {
              return this.yieldExperiments.useAssertiveYield.isEligible
                ? this.getYieldExperimentSettingValue(
                    this.fuseSettings.useAssertiveYield
                  )
                : this.queryParamReader[Ie]("fuseAssertiveYield");
            },
          },
          {
            key: "isAllBiddersWithAYEnabled",
            value: function () {
              return !0 === this.fuseSettings.useAllBiddersWithAY;
            },
          },
          {
            key: "getAssertiveYieldAbPercentage",
            value: function () {
              var e;
              return null !==
                (e = this.queryParamReader[Se](
                  "fuseAssertiveYieldAbPercentage"
                )) && void 0 !== e
                ? e
                : 95;
            },
          },
          {
            key: "shouldWaitForIiqCallback",
            value: function () {
              return (
                Boolean(this.fuseSettings.enableIntentIQ) &&
                Boolean(this.fuseSettings.iiqWaitForCallback)
              );
            },
          },
          {
            key: "shouldWaitForAyCallback",
            value: function () {
              var e;
              return (
                Boolean(this.isAssertiveYieldEnabled()) &&
                (null === (e = this.fuseSettings.ayWaitForCallback) ||
                  void 0 === e ||
                  e)
              );
            },
          },
          {
            key: "isCollapseEmptyDivsDisabled",
            value: function () {
              var e;
              return (
                null === (e = this.fuseSettings.disableCollapseEmptyDivs) ||
                void 0 === e ||
                e
              );
            },
          },
          {
            key: "isAutoRegistrationEnabled",
            value: function () {
              return Boolean(this.fuseSettings.enableAutoRegistration);
            },
          },
          {
            key: "getId5PartnerId",
            value: function () {
              var e, t;
              return (
                null === (e = this.fuseSettings.id5) || void 0 === e
                  ? void 0
                  : e.enabled
              )
                ? null === (t = this.fuseSettings.id5) || void 0 === t
                  ? void 0
                  : t.partnerId
                : void 0;
            },
          },
          {
            key: "getVideoSettings",
            value: function () {
              var e;
              return null !== (e = this.fuseSettings.videoSettings) &&
                void 0 !== e
                ? e
                : { enabled: !1 };
            },
          },
          {
            key: "isConfiantEnabled",
            value: function () {
              return !this.isYandexEnabled() && this.fuseSettings.confiant;
            },
          },
          {
            key: "isUserSyncEnabled",
            value: function () {
              return !this.fuseSettings.disableUserSync;
            },
          },
          {
            key: "getDisableUserSyncOverride",
            value: function () {
              var e;
              return (
                null !== (e = this.fuseSettings.disableUserSyncOverride) &&
                void 0 !== e &&
                e
              );
            },
          },
          {
            key: "getDisableIframeUserSync",
            value: function () {
              var e;
              return (
                null !== (e = this.fuseSettings.disableIframeUserSync) &&
                void 0 !== e &&
                e
              );
            },
          },
          {
            key: "getIframeUserSyncBidders",
            value: function () {
              return this.fuseSettings.iframeUserSyncBidders;
            },
          },
          {
            key: "getEnableIntentIQ",
            value: function () {
              var e;
              return (
                null !== (e = this.fuseSettings.enableIntentIQ) &&
                void 0 !== e &&
                e
              );
            },
          },
          {
            key: "getIntentIQVersion",
            value: function () {
              return this.fuseSettings.intentIQVersion;
            },
          },
          {
            key: "getIntentIQInChrome",
            value: function () {
              var e;
              return (
                Boolean(this.fuseSettings.intentIQInChrome) &&
                "US" ===
                  (null === (e = this.getFuseGeo()) || void 0 === e
                    ? void 0
                    : e.country)
              );
            },
          },
          {
            key: "getIntentIQManualReport",
            value: function () {
              return Boolean(this.fuseSettings.intentIQManualReport);
            },
          },
          {
            key: "getIntentIQGamParameterName",
            value: function () {
              return this.fuseSettings.intentIQGamParameterName;
            },
          },
          {
            key: "isBlockthroughEnabled",
            value: function () {
              return !this.isYandexEnabled() && this.fuseSettings.blockthrough;
            },
          },
          {
            key: "isWidgetRendererEnabled",
            value: function () {
              return (
                !this.v2Compatibility.disableWidgetsRenderer &&
                !this.fuseSettings.disableWidgetsRenderer
              );
            },
          },
          {
            key: "setDisableWidgetRenderer",
            value: function () {
              this.v2Compatibility.disableWidgetsRenderer = !0;
            },
          },
          {
            key: "isStrictCmp",
            value: function () {
              return Boolean(this.fuseSettings.strict_cmp);
            },
          },
          {
            key: "useZoneCustomiseH5",
            value: function () {
              return Boolean(this.fuseSettings.useZoneCustomiseH5);
            },
          },
          {
            key: "isStaleSlotDivRemovalOnResetEnabled",
            value: function () {
              var e;
              return (
                null !==
                  (e = this.fuseSettings.useStaleSlotDivRemovalOnReset) &&
                void 0 !== e &&
                e
              );
            },
          },
          {
            key: "isPrebidActivityControlEnabled",
            value: function () {
              return (
                Boolean(this.fuseSettings.prebidActivityControl) &&
                this.isCmpV2Enabled() &&
                this.checkMinimumRevision("v6")
              );
            },
          },
          {
            key: "isCmpDeterminationEnabled",
            value: function () {
              return (
                this.isCmpRequired() &&
                (this.isStrictCmp() ||
                  this.isPrebidActivityControlEnabled() ||
                  this.isUseWaitForCmpDeterminationEnabled())
              );
            },
          },
          {
            key: "isStrictCmpScriptGated",
            value: function () {
              return this.isCmpDeterminationEnabled() && this.isStrictCmp();
            },
          },
          {
            key: "isPrebidStrictConsentModulesEnabled",
            value: function () {
              var e;
              return (
                null !==
                  (e = this.fuseSettings.usePrebidStrictConsentModules) &&
                void 0 !== e &&
                e
              );
            },
          },
          {
            key: "getBidLibrariesCutoffMs",
            value: function () {
              return this.isCmpRequired() && this.isCmpDeterminationEnabled()
                ? 5e3
                : 1e3;
            },
          },
          {
            key: "isRequestGdprPersonalisation",
            value: function () {
              return !this.fuseSettings.disableGdprPersonalisation;
            },
          },
          {
            key: "isIframeCmp",
            value: function () {
              return "iframe" === this.fuseSettings.cmp;
            },
          },
          {
            key: "setForceDisablePrebid",
            value: function () {
              this.logger[C]("[CONFIG]: Forcefully disabling prebid"),
                (this.forceDisablePrebid = !0);
            },
          },
          {
            key: "isMiniScrollersEnabled",
            value: function () {
              return Boolean(this.fuseSettings.enableMiniScrollers);
            },
          },
          {
            key: "scrollToStickDisableDepth",
            value: function () {
              return this.fuseSettings.scrollToStickDisableDepth;
            },
          },
          {
            key: "isSpaOldBlockingPageInit",
            value: function () {
              return Boolean(this.fuseSettings.spaOldBlockingPageInit);
            },
          },
          {
            key: "getTopStickyHeaderSelector",
            value: function () {
              var e, t;
              return (
                (null ===
                  (t =
                    null ===
                      (e = this.getFuseSlots().find(function (e) {
                        var t, n;
                        return (
                          (null === (t = e.attributes) || void 0 === t
                            ? void 0
                            : t.miniscroller) &&
                          (null === (n = e.miniscrollerAttributes) ||
                          void 0 === n
                            ? void 0
                            : n.topStickyHeaderSelector)
                        );
                      })) || void 0 === e
                      ? void 0
                      : e.miniscrollerAttributes) || void 0 === t
                  ? void 0
                  : t.topStickyHeaderSelector) ||
                this.queryParamReader[we]("fuseTopStickyHeaderSelector") ||
                this.fuseSettings.topStickyHeaderSelector
              );
            },
          },
          {
            key: "getSlotRefWithoutMcm",
            value: function (e) {
              var t = /^(\/\d*),(\d*)(\/.*)$/i;
              if (!1 === t.test(e))
                return (
                  this.logger[k](function () {
                    return "[SETTINGS]: regExGamAdUnitRef.test(slotRef): "
                      .concat(JSON.stringify(t.test(e)), ", slotRef: ")
                      .concat(e);
                  }),
                  e
                );
              this.logger[k](function () {
                return "[SETTINGS]: regExGamAdUnitRef.test(slotRef): "
                  .concat(JSON.stringify(t.test(e)), ", slotRef: ")
                  .concat(e);
              });
              var n = t.exec(e);
              return (
                this.logger[k](function () {
                  return "[SETTINGS]: slotRef: "
                    .concat(e, ", matches: ")
                    .concat(JSON.stringify(n));
                }),
                "".concat(n[1]).concat(n[3])
              );
            },
          },
          {
            key: "cleanSlotBasedOnMcmMode",
            value: function (e) {
              var t = this.getSlotRefWithoutMcm(e.slot);
              return (
                this.logger[k](
                  "[SETTINGS]: before: with MCM: "
                    .concat(e.slot, ", after: without MCM: ")
                    .concat(t)
                ),
                Object.assign(Object.assign({}, e), { slot: t })
              );
            },
          },
          {
            key: "cleanSlotSizeMapping",
            value: function (e) {
              var t,
                n,
                i,
                r,
                o,
                a = {};
              return (
                (null === (t = e.sizeMapping) || void 0 === t
                  ? void 0
                  : t.xl) && (a.xl = e.sizeMapping.xl),
                (null === (n = e.sizeMapping) || void 0 === n ? void 0 : n.l) &&
                  (a.l = e.sizeMapping.l),
                (a.m =
                  null === (i = e.sizeMapping) || void 0 === i ? void 0 : i.m),
                (a.s =
                  null === (r = e.sizeMapping) || void 0 === r ? void 0 : r.s),
                (a.xs =
                  null === (o = e.sizeMapping) || void 0 === o ? void 0 : o.xs),
                Object.assign(Object.assign({}, e), { sizeMapping: a })
              );
            },
          },
          {
            key: "initFuseSlots",
            value: function () {
              var e,
                t = this,
                n =
                  this.isLazyBiddingEnabled() &&
                  this.isPrebidEnabledAtBP(this.getViewportBreakpoint().name),
                i = {
                  viewportWidth: this.viewportInfo[mn]().width,
                  breakpoint:
                    null === (e = this.getViewportBreakpoint()) || void 0 === e
                      ? void 0
                      : e.name,
                };
              this.accountSettings.fuse_slots =
                this.accountSettings.fuse_slots.map(function (e) {
                  var r = t.cleanFuseSlot(Boolean(t.queryParamReader[me]()), e),
                    o =
                      "lazy" === r.activateConditionConfig.type
                        ? t.getViewportBreakpoint()
                        : void 0;
                  return (
                    (r = Wi(r, o)),
                    (r = Yi(r, t.fuseSettings.tagCategories)),
                    (r = t.applyOverrides(r)),
                    (r = zi(r, i)),
                    (r = Ji(r, n && t.isHeaderBiddingSlot(r))),
                    (r = Ki(r)),
                    t.cleanSlotSizeMapping(r)
                  );
                });
            },
          },
          {
            key: "cleanFuseSlot",
            value: function (e, t) {
              return e
                ? (this.logger[k](
                    "[SETTINGS]: will"
                      .concat(
                        e ? "" : " NOT",
                        " remove MCM child reference from the slot ref - "
                      )
                      .concat(t.slot)
                  ),
                  this.cleanSlotBasedOnMcmMode(t))
                : t;
            },
          },
          {
            key: "getFuseSlots",
            value: function () {
              return this.accountSettings.fuse_slots;
            },
          },
          {
            key: "parseAttributesToComboZoneParams",
            value: function (e) {
              return xi(e.layout);
            },
          },
          {
            key: "applyOverrides",
            value: function (e) {
              var t,
                n,
                i,
                r,
                o,
                a,
                s,
                c,
                u,
                l,
                d,
                f,
                g,
                m,
                v,
                p,
                b,
                h,
                y,
                S,
                I,
                w,
                _,
                E,
                k,
                C,
                T,
                A,
                R,
                x,
                P,
                O,
                D,
                N,
                z;
              return Object.assign(Object.assign({}, e), {
                attributes: Object.assign(Object.assign({}, e.attributes), {
                  interscroller:
                    void 0 !==
                      (null ===
                        (n =
                          null === (t = this.overrideParams) || void 0 === t
                            ? void 0
                            : t.interscrollersParams) || void 0 === n
                        ? void 0
                        : n[e.id]) ||
                    (null === (i = e.attributes) || void 0 === i
                      ? void 0
                      : i.interscroller),
                  sticky:
                    void 0 !==
                      (null ===
                        (o =
                          null === (r = this.overrideParams) || void 0 === r
                            ? void 0
                            : r.stickiesParams) || void 0 === o
                        ? void 0
                        : o[e.id]) ||
                    (null === (a = e.attributes) || void 0 === a
                      ? void 0
                      : a.sticky),
                  dynamic:
                    void 0 !==
                      (null ===
                        (c =
                          null === (s = this.overrideParams) || void 0 === s
                            ? void 0
                            : s.dynamicParams) || void 0 === c
                        ? void 0
                        : c[e.id]) ||
                    (null === (u = e.attributes) || void 0 === u
                      ? void 0
                      : u.dynamic),
                  scrollToStick:
                    void 0 !==
                      (null ===
                        (d =
                          null === (l = this.overrideParams) || void 0 === l
                            ? void 0
                            : l.scrollToStickParams) || void 0 === d
                        ? void 0
                        : d[e.id]) ||
                    (null === (f = e.attributes) || void 0 === f
                      ? void 0
                      : f.scrollToStick),
                  miniscroller:
                    void 0 !==
                      (null ===
                        (m =
                          null === (g = this.overrideParams) || void 0 === g
                            ? void 0
                            : g.miniscrollersParams) || void 0 === m
                        ? void 0
                        : m[e.id]) ||
                    (null === (v = e.attributes) || void 0 === v
                      ? void 0
                      : v.miniscroller),
                  forceComboZone:
                    void 0 !==
                      (null ===
                        (h =
                          null ===
                            (b =
                              null === (p = this.overrideParams) || void 0 === p
                                ? void 0
                                : p.comboZoneParams) || void 0 === b
                            ? void 0
                            : b[e.id]) || void 0 === h
                        ? void 0
                        : h.layout) ||
                    (null === (y = e.attributes) || void 0 === y
                      ? void 0
                      : y.forceComboZone),
                  comboZoneEnabled:
                    void 0 !==
                      (null ===
                        (w =
                          null ===
                            (I =
                              null === (S = this.overrideParams) || void 0 === S
                                ? void 0
                                : S.comboZoneParams) || void 0 === I
                            ? void 0
                            : I[e.id]) || void 0 === w
                        ? void 0
                        : w.comboZoneEnabled) || e.attributes.comboZoneEnabled,
                }),
                interscrollerAttributes: Object.assign(
                  Object.assign({}, e.interscrollerAttributes),
                  null ===
                    (E =
                      null === (_ = this.overrideParams) || void 0 === _
                        ? void 0
                        : _.interscrollersParams) || void 0 === E
                    ? void 0
                    : E[e.id]
                ),
                stickyAttributes: Object.assign(
                  Object.assign({}, e.stickyAttributes),
                  null ===
                    (C =
                      null === (k = this.overrideParams) || void 0 === k
                        ? void 0
                        : k.stickiesParams) || void 0 === C
                    ? void 0
                    : C[e.id]
                ),
                dynamicAttributes: Object.assign(
                  Object.assign({}, e.dynamicAttributes),
                  null ===
                    (A =
                      null === (T = this.overrideParams) || void 0 === T
                        ? void 0
                        : T.dynamicParams) || void 0 === A
                    ? void 0
                    : A[e.id]
                ),
                miniscrollerAttributes: Object.assign(
                  Object.assign({}, e.miniscrollerAttributes),
                  null ===
                    (x =
                      null === (R = this.overrideParams) || void 0 === R
                        ? void 0
                        : R.miniscrollersParams) || void 0 === x
                    ? void 0
                    : x[e.id]
                ),
                comboZoneAttributes: Object.assign(
                  Object.assign({}, e.comboZoneAttributes),
                  (
                    null ===
                      (D =
                        null ===
                          (O =
                            null === (P = this.overrideParams) || void 0 === P
                              ? void 0
                              : P.comboZoneParams) || void 0 === O
                          ? void 0
                          : O[e.id]) || void 0 === D
                      ? void 0
                      : D.layout
                  )
                    ? this.parseAttributesToComboZoneParams(
                        null ===
                          (z =
                            null === (N = this.overrideParams) || void 0 === N
                              ? void 0
                              : N.comboZoneParams) || void 0 === z
                          ? void 0
                          : z[e.id]
                      )
                    : {}
                ),
              });
            },
          },
          {
            key: "generateZoneTemplate",
            value: function (e, t) {
              var n = this.getZoneTemplate(e);
              if (n) {
                if (!this.zoneCustomiser) return n;
                var i = (function (e, t, n, i) {
                  if ("function" == typeof t) {
                    if (!i)
                      return void e[T](
                        "[ZONE][".concat(
                          n,
                          "][fuseZoneCustomiser] api is not defined, skip customisation"
                        )
                      );
                    try {
                      return (
                        e[C](
                          "[ZONE][".concat(n, "][fuseZoneCustomiser] Start")
                        ),
                        t(n, i)
                      );
                    } catch (t) {
                      e[T](
                        "[ZONE][".concat(
                          n,
                          "][fuseZoneCustomiser] Encountered error during evaluation"
                        ),
                        t
                      );
                    }
                  }
                })(this.logger, this.zoneCustomiser, e, t);
                if (i) {
                  var r = Object.assign(
                      Object.assign(
                        Object.assign(
                          Object.assign(Object.assign({}, n), {
                            id: i.id,
                            slot: i.gamSlotPath,
                          }),
                          i.bids ? { bids: i.bids } : {}
                        ),
                        i.targeting ? { targeting: i.targeting } : {}
                      ),
                      { originalZoneTemplateId: n.id }
                    ),
                    o = this.accountSettings.fuse_slots.find(function (e) {
                      return e.id === r.id;
                    });
                  return o
                    ? o.slot !== r.slot
                      ? (this.logger[T](
                          "[SETTINGS]: ZoneTemplateOverrides for id "
                            .concat(r.id, " does not match slot ")
                            .concat(
                              r.slot,
                              " - the customised settings will be ignored"
                            )
                        ),
                        o)
                      : r
                    : (this.accountSettings.fuse_slots.push(r), r);
                }
                return n;
              }
            },
          },
          {
            key: "getZoneTemplate",
            value: function (e) {
              return this.getFuseSlots().find(function (t) {
                return e == t.id || e == t.gamAdUnitId;
              });
            },
          },
          {
            key: "isScanDOMOnPageLoad",
            value: function () {
              var e = this.fuseSettings.disableAutoLoadSlots;
              return re(e) || !e;
            },
          },
          {
            key: "isHeaderBiddingSlot",
            value: function (e) {
              return !e.attributes.interstitial && e.attributes.headerbidding;
            },
          },
          {
            key: "isSlotWidget",
            value: function (e) {
              var t, n, i;
              return (
                (null === (t = e.attributes) || void 0 === t
                  ? void 0
                  : t.interscroller) ||
                (null === (n = e.attributes) || void 0 === n
                  ? void 0
                  : n.sticky) ||
                (null === (i = e.attributes) || void 0 === i
                  ? void 0
                  : i.dynamic) ||
                null
              );
            },
          },
          {
            key: "maxSlotHeightForBreakpoint",
            value: function (e, t) {
              var n;
              return null === (n = e.sizeMapping[t]) || void 0 === n
                ? void 0
                : n.reduce(function (e, t) {
                    return ne(t[1]) && t[1] > e ? Number(t[1]) : e;
                  }, 0);
            },
          },
          {
            key: "getPrebidOptions",
            value: function (e) {
              var t, n, i;
              if (
                this.isPrebidEnabled() &&
                this.fuseSettings.prebid.breakpoint_options
              ) {
                var r = this.fuseSettings.prebid.breakpoint_options[e];
                if (r)
                  return {
                    enabled: r.enabled,
                    sendAllBids: !0 === this.fuseSettings.prebid.sendAllBids,
                    timeout:
                      null !==
                        (n =
                          null !== (t = r.timeout) && void 0 !== t
                            ? t
                            : this.fuseSettings.prebid.defaultTimeout) &&
                      void 0 !== n
                        ? n
                        : 1e3,
                  };
              }
              return {
                enabled: this.isPrebidEnabled(),
                sendAllBids: !0 === this.fuseSettings.prebid.sendAllBids,
                timeout:
                  null !== (i = this.fuseSettings.prebid.defaultTimeout) &&
                  void 0 !== i
                    ? i
                    : 1e3,
              };
            },
          },
          {
            key: "isPrebidEnabledAtBP",
            value: function (e) {
              return this.isPrebidEnabled() && this.getPrebidOptions(e).enabled;
            },
          },
          {
            key: "isUamEnabledAtBP",
            value: function (e) {
              return this.isUamEnabled() && this.getPrebidOptions(e).enabled;
            },
          },
          {
            key: "getHbTimeout",
            value: function (e, t) {
              var n = this.getPrebidOptions(e).timeout;
              return t
                ? this.isRefreshPrebidTimeoutBuffering()
                  ? this.prebidRefreshTimeoutMs
                  : n
                : this.isIncreaseInitialTimeout()
                ? 1.5 * n
                : n;
            },
          },
          {
            key: "getPrebidMediaTypes",
            value: function () {
              return e.getPrebidMediaTypesFor(this.fuseSettings);
            },
          },
          {
            key: "isPrebidBannerEnabled",
            value: function () {
              return e.hasPrebidBannerFor(this.fuseSettings);
            },
          },
          {
            key: "isPrebidVideoEnabled",
            value: function () {
              return this.getPrebidMediaTypes().includes("video");
            },
          },
          {
            key: "isPrebidNativeEnabled",
            value: function () {
              return this.getPrebidMediaTypes().includes("native");
            },
          },
          {
            key: "isSlotEnabledForBreakpoint",
            value: function (e, t) {
              var n, i;
              return (
                (null !==
                  (i =
                    null === (n = e.sizeMapping) || void 0 === n
                      ? void 0
                      : n[t]) && void 0 !== i
                  ? i
                  : []
                ).length > 0
              );
            },
          },
          {
            key: "getPublicationId",
            value: function () {
              return this.accountSettings.publication_metadata.publication_id;
            },
          },
          {
            key: "getFlavour",
            value: function () {
              var e;
              return null !== (e = this.accountSettings.fuse_flavour) &&
                void 0 !== e
                ? e
                : "default";
            },
          },
          {
            key: "getFuseCDN",
            value: function () {
              return this.accountSettings.fuse_cdn;
            },
          },
          {
            key: "getFuseCDNPlatform",
            value: function () {
              return this.accountSettings.fuse_cdn_platform;
            },
          },
          {
            key: "getPrebidHash",
            value: function () {
              return this.accountSettings.fuse_prebid_hash;
            },
          },
          {
            key: "getBlockedUrls",
            value: function () {
              var e;
              return null !== (e = this.accountSettings.fuse_blocked_url) &&
                void 0 !== e
                ? e
                : [];
            },
          },
          {
            key: "getFuseIndustry",
            value: function () {
              return this.accountSettings.fuse_industry;
            },
          },
          {
            key: "getBadAdv",
            value: function () {
              return t;
            },
          },
          {
            key: "getFuseSettings",
            value: function () {
              return this.fuseSettings;
            },
          },
          {
            key: "getEdgeHtmlMaxAdsRefreshLimit",
            value: function () {
              var e;
              return null !==
                (e = this.fuseSettings.edgeHtmlMaxAdsRefreshLimit) &&
                void 0 !== e
                ? e
                : 60;
            },
          },
          {
            key: "getDefaultRefreshInterval",
            value: function () {
              return this.fuseSettings.refresh;
            },
          },
          {
            key: "getRefreshInterval",
            value: function (e) {
              var t = e.attributes.refresh,
                n = void 0;
              if (ne(t) && t > 0) n = t;
              else if (0 === t) n = void 0;
              else {
                var i = this.getDefaultRefreshInterval();
                i && i > 0 && (n = i);
              }
              return n;
            },
          },
          {
            key: "getAccountSettings",
            value: function () {
              return this.accountSettings;
            },
          },
          {
            key: "getV2CompatOverrides",
            value: function () {
              return this.v2Compatibility;
            },
          },
          {
            key: "isTestCreatives",
            value: function () {
              var e;
              return (
                null !== (e = this.queryParamReader[ve]()) && void 0 !== e && e
              );
            },
          },
          {
            key: "getCmpDeterminedSampleRate",
            value: function () {
              var e;
              return null !== (e = this.fuseSettings.cmpDeterminedSampleRate) &&
                void 0 !== e
                ? e
                : this.isCmpV2Enabled()
                ? 100
                : 1;
            },
          },
          {
            key: "getPrebidTelemetrySampleRate",
            value: function () {
              var e;
              return null !==
                (e = this.fuseSettings.prebidTelemetrySampleRate) &&
                void 0 !== e
                ? e
                : 1;
            },
          },
          {
            key: "getSlotRequestTelemetrySampleRate",
            value: function () {
              var e;
              return null !==
                (e = this.fuseSettings.slotRequestTelemetrySampleRate) &&
                void 0 !== e
                ? e
                : 1;
            },
          },
          {
            key: "getSlotRenderEndedSampleRate",
            value: function () {
              var e;
              return null !==
                (e = this.fuseSettings.slotRenderEndedSampleRate) &&
                void 0 !== e
                ? e
                : 1;
            },
          },
          {
            key: "getSlotViewableSampleRate",
            value: function () {
              var e;
              return null !== (e = this.fuseSettings.slotViewableSampleRate) &&
                void 0 !== e
                ? e
                : 1;
            },
          },
          {
            key: "getCarouselTelemetrySampleRate",
            value: function () {
              var e;
              return null !==
                (e = this.fuseSettings.carouselTelemetrySampleRate) &&
                void 0 !== e
                ? e
                : 100;
            },
          },
          {
            key: "getCwvSampleRate",
            value: function () {
              var e;
              return null !== (e = this.fuseSettings.cwvSampleRate) &&
                void 0 !== e
                ? e
                : 100;
            },
          },
          {
            key: "getPrebidAdRenderSucceededTelemetrySampleRate",
            value: function () {
              var e;
              return null !==
                (e =
                  this.fuseSettings
                    .prebidAdRenderSucceededTelemetrySampleRate) && void 0 !== e
                ? e
                : 1;
            },
          },
          {
            key: "getHeavyAdTelemetrySampleRate",
            value: function () {
              var e;
              return null !==
                (e = this.fuseSettings.heavyAdTelemetrySampleRate) &&
                void 0 !== e
                ? e
                : 100;
            },
          },
          {
            key: "getCurrentBreakpoint",
            value: function () {
              var e;
              return null !== (e = this.getViewportBreakpoint()) && void 0 !== e
                ? e
                : { name: "xs", size: 0 };
            },
          },
          {
            key: "getSlotTestUrls",
            value: function () {
              var e;
              return null !== (e = this.fuseSettings.fuse_test_urls) &&
                void 0 !== e
                ? e
                : [];
            },
          },
          {
            key: "getYandexBlockId",
            value: function () {
              return (
                this.queryParamReader[we]("fuseYandexBlockId") ||
                this.fuseSettings.yandexBlockId
              );
            },
          },
          {
            key: "isYandexEnabled",
            value: function () {
              return this.isYandexEnabledFor(this.fuseSettings);
            },
          },
          {
            key: "isYandexEnabledFor",
            value: function (e) {
              return (
                e.yandex ||
                this.queryParamReader[Ie]("fuseYandex") ||
                "" !== this.queryParamReader[we]("fuseYandexBlockId")
              );
            },
          },
          {
            key: "isMinimumPerceivedRefreshEnabled",
            value: function () {
              return !1 !== this.fuseSettings.useMinimumPerceivedRefresh;
            },
          },
          {
            key: "getMinGptRefreshInterval",
            value: function (e) {
              var t,
                n =
                  null !== (t = this.fuseSettings.minGptRefreshInterval) &&
                  void 0 !== t
                    ? t
                    : 30;
              return this.isRefreshPrebidTimeoutBuffering()
                ? Math.max(n, null != e ? e : 0)
                : n;
            },
          },
          {
            key: "disableYandexSticky",
            value: function () {
              var e, t;
              return (
                this.isYandexEnabled() &&
                null !==
                  (t =
                    null !== (e = this.queryParamReader[be]()) && void 0 !== e
                      ? e
                      : this.fuseSettings.disableYandexSticky) &&
                void 0 !== t &&
                t
              );
            },
          },
          {
            key: "isPubxaiEnabled",
            value: function () {
              return this.getYieldExperimentSettingValue(
                this.fuseSettings.usePubxai
              );
            },
          },
          {
            key: "isPubxEnabled",
            value: function () {
              return this.getYieldExperimentSettingValue(
                this.fuseSettings.usePubx
              );
            },
          },
          {
            key: "isPreconnectHintsEnabled",
            value: function () {
              return this.getYieldExperimentSettingValue(
                this.fuseSettings.usePreconnectHints
              );
            },
          },
          {
            key: "getPreconnectDomains",
            value: function () {
              var e;
              return null !== (e = this.fuseSettings.preconnectDomains) &&
                void 0 !== e
                ? e
                : [];
            },
          },
          {
            key: "isPreloadHintsEnabled",
            value: function () {
              return this.getYieldExperimentSettingValue(
                this.fuseSettings.usePreloadHints
              );
            },
          },
          {
            key: "getPubxOnPercentage",
            value: function () {
              return this.fuseSettings.pubxOnPercentage;
            },
          },
          {
            key: "getPubxFloorFetch",
            value: function () {
              return this.fuseSettings.pubxFloorFetch;
            },
          },
          {
            key: "getPubxAuctionDelay",
            value: function () {
              return this.fuseSettings.pubxAuctionDelay;
            },
          },
          {
            key: "isPubxaiPrebidOnlyEnabled",
            value: function () {
              return (
                !!this.yieldExperiments.usePubxaiPrebidOnly.isEligible &&
                this.getYieldExperimentSettingValue(
                  this.fuseSettings.usePubxaiPrebidOnly
                )
              );
            },
          },
          {
            key: "isBidCacheFloorsEnabled",
            value: function () {
              return (
                !!this.yieldExperiments.useBidCacheFloors.isEligible &&
                this.getYieldExperimentSettingValue(
                  this.fuseSettings.useBidCacheFloors
                )
              );
            },
          },
          {
            key: "getIn2wRatio",
            value: function () {
              return this.yieldExperiments.in2wInjection.isYieldExperiment &&
                this.yieldExperiments.in2wInjection.experimentValue
                ? 0.9
                : this.fuseSettings.in2wRatio;
            },
          },
          {
            key: "getIn2wAdvertiserId",
            value: function () {
              return this.fuseSettings.in2wAdvertiserId;
            },
          },
          {
            key: "getIn2wAdvertiserTimeZone",
            value: function () {
              return this.fuseSettings.in2wAdvertiserTimeZone;
            },
          },
          {
            key: "isCmpV2Enabled",
            value: function () {
              return (
                !(
                  !this.isCmpRequired() ||
                  !this.isUseWaitForCmpDeterminationEnabled()
                ) || !0 === this.fuseSettings.useCmpV2
              );
            },
          },
          {
            key: "isGppEnabled",
            value: function () {
              var e;
              return (
                this.isCmpV2Enabled() &&
                "US" ===
                  (null === (e = this.getFuseGeo()) || void 0 === e
                    ? void 0
                    : e.country) &&
                !0 === this.fuseSettings.useGpp
              );
            },
          },
          {
            key: "isGppUspv1Enabled",
            value: function () {
              return (
                this.isGppEnabled() && !0 === this.fuseSettings.useGppUspv1
              );
            },
          },
          {
            key: "getTenantCode",
            value: function () {
              return this.accountSettings.fuse_tenant;
            },
          },
          {
            key: "getPrebidIasPubId",
            value: function () {
              return this.fuseSettings.prebidIasPubId;
            },
          },
          {
            key: "getSampledBidders",
            value: function () {
              var e = this.fuseSettings.apsSampleRate;
              return void 0 === e ? [] : [{ bidder: "aps", sampleRate: e }];
            },
          },
          {
            key: "isUseBackwardCompatibleNaming",
            value: function () {
              var e, t;
              return (
                null !==
                  (t =
                    null !== (e = this.queryParamReader[ye]()) && void 0 !== e
                      ? e
                      : this.fuseSettings.useBackwardCompatibleNaming) &&
                void 0 !== t &&
                t
              );
            },
          },
          {
            key: "enableOptable",
            value: function () {
              var e, t;
              return (
                this.checkMinimumRevision("v6") &&
                null !== (e = this.fuseSettings.enableOptable) &&
                void 0 !== e &&
                e &&
                "US" ===
                  (null === (t = this.getFuseGeo()) || void 0 === t
                    ? void 0
                    : t.country)
              );
            },
          },
          {
            key: "getOptableSlug",
            value: function () {
              return (
                this.fuseSettings.optableSlug || this.accountCode.toLowerCase()
              );
            },
          },
          {
            key: "getUseGamSf",
            value: function () {
              var e;
              return (
                null !== (e = this.fuseSettings.useGamSf) && void 0 !== e && e
              );
            },
          },
          {
            key: "getUseCookieBotEventListener",
            value: function () {
              var e;
              return (
                null !== (e = this.fuseSettings.useCookieBotEventListener) &&
                void 0 !== e &&
                e
              );
            },
          },
          {
            key: "determineAccount",
            value: function (e, t, n) {
              if (t) return t;
              if (n) {
                var i = n[e];
                if (i) return i;
                this.logger[T](
                  "[SETTINGS]: Unable to determine account, no account code defined and/or unable to determine account from given domain map"
                );
              } else
                this.logger[T](
                  "[SETTINGS]: Unable to determine account, neither account code nor domain map were defined."
                );
            },
          },
          {
            key: "determineAccountName",
            value: function (e, t, n) {
              if (t) return t;
              if (n) {
                var i = n[e];
                return i || void 0;
              }
            },
          },
          {
            key: "getAccountCode",
            value: function () {
              return this.accountCode;
            },
          },
          {
            key: "getAccountName",
            value: function () {
              var e;
              return null !== (e = this.fuseSettings.accountName) &&
                void 0 !== e
                ? e
                : this.accountName;
            },
          },
          {
            key: "isForceSafeFrames",
            value: function () {
              return Boolean(this.forceSafeFrames);
            },
          },
          {
            key: "getGptUseNewApi",
            value: function () {
              var e;
              return {
                forceSafeFrame:
                  null !== (e = this.fuseSettings.gptUseNewApiForceSafeFrame) &&
                  void 0 !== e &&
                  e,
                pageSettings: this.getYieldExperimentSettingValue(
                  this.fuseSettings.gptUseNewApiPageSettings
                ),
                pageTargeting: this.getYieldExperimentSettingValue(
                  this.fuseSettings.gptUseNewApiPageTargeting
                ),
                slotTargeting: this.getYieldExperimentSettingValue(
                  this.fuseSettings.gptUseNewApiSlotTargeting
                ),
              };
            },
          },
          {
            key: "setForceSafeFrames",
            value: function (e) {
              this.forceSafeFrames = Boolean(null == e || e);
            },
          },
          {
            key: "getViewportBreakpoint",
            value: function () {
              return this.viewportInfo[fn]();
            },
          },
          {
            key: "getAvailableNewBidders",
            value: function () {
              return Array.from(
                new Set(
                  this.accountSettings.fuse_slots.reduce(function (e, t) {
                    var n;
                    return [].concat(
                      y(e),
                      y(
                        (null !== (n = t.matchedNetworks) && void 0 !== n
                          ? n
                          : []
                        ).map(function (e) {
                          return e.network_code;
                        })
                      )
                    );
                  }, [])
                )
              );
            },
          },
          {
            key: "allowedBiddersInNewBids",
            value: function () {
              var e;
              return null !== (e = this.queryParamReader[he]()) && void 0 !== e
                ? e
                : [];
            },
          },
          {
            key: "getNetworkParams",
            value: function () {
              return {
                constant: this.fuseSettings.networkNetworkParams,
                account: this.fuseSettings.networkAccountParams,
                contract: this.fuseSettings.networkContractParams,
              };
            },
          },
          {
            key: "getFuseGeo",
            value: function () {
              var e;
              if (
                "<FUSE_GEO_CODE>" !==
                (null === (e = this.geo) || void 0 === e ? void 0 : e.code)
              )
                return this.getCfConfig() ? this.getCfConfig().geo : this.geo;
            },
          },
          {
            key: "getCfConfig",
            value: function () {
              return this.cfConfig;
            },
          },
          {
            key: "getBidderGeoExclusions",
            value: function () {
              return this.fuseSettings.bidderGeoExclusions;
            },
          },
          {
            key: "getExcludedNetworksForGeo",
            value: function () {
              var e,
                t,
                n,
                i,
                r,
                o,
                a = this.getBidderGeoExclusions(),
                s = this.getFuseGeo();
              return a && s
                ? Array.from(
                    new Set(
                      [].concat(
                        y(
                          null !==
                            (t =
                              null === (e = a.country) || void 0 === e
                                ? void 0
                                : e[s.country]) && void 0 !== t
                            ? t
                            : []
                        ),
                        y(
                          null !==
                            (i =
                              null === (n = a.state) || void 0 === n
                                ? void 0
                                : n[
                                    "".concat(s.country, "-").concat(s.state)
                                  ]) && void 0 !== i
                            ? i
                            : []
                        ),
                        y(
                          null !==
                            (o =
                              null === (r = a.code) || void 0 === r
                                ? void 0
                                : r[s.code]) && void 0 !== o
                            ? o
                            : []
                        )
                      )
                    )
                  )
                : [];
            },
          },
          {
            key: "isFuseH5Test",
            value: function () {
              var e;
              return (
                null !== (e = this.queryParamReader[Ie]("fuseH5Test")) &&
                void 0 !== e &&
                e
              );
            },
          },
        ],
        [
          {
            key: "isBidCacheEnabledFor",
            value: function (e) {
              var t;
              return Boolean(null === (t = e.useBidCache) || void 0 === t || t);
            },
          },
          {
            key: "hasHeaderBiddingFor",
            value: function (e) {
              var t;
              return Boolean(
                null === (t = e.prebid) || void 0 === t ? void 0 : t.enabled
              );
            },
          },
          {
            key: "hasConfiguredPrebidUserIdFor",
            value: function (e) {
              var t, n;
              if (!0 === e.disableUserSync) return !1;
              var i =
                  !0 ===
                    (null === (t = e.id5) || void 0 === t
                      ? void 0
                      : t.enabled) && Boolean(e.id5.partnerId),
                r =
                  !e.enableOptable &&
                  !0 ===
                    (null === (n = e.identity) || void 0 === n
                      ? void 0
                      : n.enabled),
                o = !e.enableOptable && !0 === e.usePairId,
                a = !1 !== e.useAmxId,
                s = !1 !== e.useUnifiedId;
              return (
                a ||
                s ||
                i ||
                r ||
                o ||
                !0 === e.useAdfixusId ||
                !1 !== e.useCriteoId ||
                !1 !== e.useSharedId
              );
            },
          },
          {
            key: "getPrebidMediaTypesFor",
            value: function (e) {
              var t;
              return null !== (t = e.prebidMediaTypes) && void 0 !== t
                ? t
                : ["banner"];
            },
          },
          {
            key: "hasPrebidBannerFor",
            value: function (t) {
              return e.getPrebidMediaTypesFor(t).includes("banner");
            },
          },
        ]
      );
    })(),
    Wi = function (e, t) {
      var n = e.activateConditionConfig,
        i = {
          activateCondition: void 0,
          excludeFromAuctionBlock: "none" !== n.type,
        };
      switch (n.type) {
        case "none":
          break;
        case "lazy":
          var r = null == t ? void 0 : t.name,
            o = n.scrollDistance[r];
          if (re(o) || !1 === o) break;
          i = Object.assign(Object.assign({}, i), {
            activateCondition: {
              type: "condition",
              name: On,
              params: n.scrollDistance,
            },
          });
          break;
        case "manual":
          i = Object.assign(Object.assign({}, i), {
            activateCondition: { type: "condition", name: Bn },
          });
          break;
        case "custom":
          i = Object.assign(Object.assign({}, i), {
            activateCondition: n.config,
          });
          break;
        default:
          ce(n);
      }
      return Object.assign(Object.assign({}, e), i);
    },
    Yi = function (e, t) {
      var n;
      if (!t || !Object.keys(t).length) return e;
      if (
        !(null === (n = e.zoneCategories) || void 0 === n ? void 0 : n.length)
      )
        return e;
      var i = {
        type: "or",
        subConditions: e.zoneCategories.map(function (e) {
          return t[e];
        }),
      };
      return e.activateCondition
        ? Object.assign(Object.assign({}, e), {
            activateCondition: {
              type: "and",
              subConditions: [e.activateCondition, i],
            },
          })
        : Object.assign(Object.assign({}, e), { activateCondition: i });
    },
    Zi = ["manualDisplay", "h5Interstitial", "rewarded", "afs", "rail"],
    Ji = function (e, t) {
      var n;
      return t &&
        !Zi.some(function (t) {
          return e.attributes[t];
        }) &&
        "lazy" === e.activateConditionConfig.type &&
        "condition" ===
          (null === (n = e.activateCondition) || void 0 === n
            ? void 0
            : n.type) &&
        e.activateCondition.name === On
        ? Object.assign(Object.assign({}, e), { isBidAheadZone: !0 })
        : e;
    },
    Qi = "gumgum",
    Ki = function (e) {
      var t;
      return (null !== (t = e.matchedNetworks) && void 0 !== t ? t : []).some(
        function (e) {
          return (
            e.network_code === Qi &&
            e.matched_schemas.some(function (e) {
              return "gumgumSkinsBidconfig" === e.matched_schema.schema_name;
            })
          );
        }
      )
        ? Object.assign(Object.assign({}, e), { isGumGumSkinZone: !0 })
        : e;
    },
    Xi = Symbol(),
    $i = Symbol(),
    er = Symbol();
  function tr(e, t) {
    return {
      comboZoneParams: e[Ce]("combozone", t.location),
      stickiesParams: e[Ce]("sticky", t.location),
    };
  }
  function nr(e) {
    return e.location.hostname;
  }
  function ir(e, t, n, i, r, o, a, s, c, u, l) {
    return new qi(e, t, n, i, r, o, a, s, c, u, l);
  }
  var rr,
    or,
    ar,
    sr = M()(function (e) {
      return e
        .register(Xi, [De, j], tr)
        .register(er, [j], nr)
        .register($i, [L, Ne, ze, hn, er, De, Ue, Le, Ve, He, Xi], ir)
        .export();
    });
  function cr(e) {
    var t =
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "gzip",
      n = JSON.stringify(e),
      i = new TextEncoder().encode(n),
      r = new ReadableStream({
        start: function (e) {
          e.enqueue(i), e.close();
        },
      }).pipeThrough(new CompressionStream(t));
    return new Response(r).arrayBuffer().then(function (e) {
      return btoa(String.fromCodePoint.apply(String, y(new Uint8Array(e))));
    });
  }
  !(function (e) {
    (e.Desktop = "desktop"), (e.Tablet = "tablet"), (e.Mobile = "mobile");
  })(rr || (rr = {})),
    (function (e) {
      (e.Chrome = "chrome"),
        (e.Safari = "safari"),
        (e.Opera = "opera"),
        (e.Edge = "edge"),
        (e.IE11 = "ie11"),
        (e.Firefox = "firefox"),
        (e.Other = "other");
    })(or || (or = {})),
    (function (e) {
      (e.IOS = "ios"),
        (e.MacOS = "mac"),
        (e.Android = "android"),
        (e.Windows = "windows"),
        (e.Linux = "linux"),
        (e.ChromeOs = "chromeos"),
        (e.Other = "other");
    })(ar || (ar = {}));
  var ur = [
      { regex: /\sedg\//i, browser: or.Edge },
      { regex: /edg([ea]|ios)/i, browser: or.Edge },
      { regex: /opera/i, browser: or.Opera },
      { regex: /opr\/|opios/i, browser: or.Opera },
      { regex: /chrome|crios|crmo/i, browser: or.Chrome },
      { regex: /firefox|iceweasel|fxios/i, browser: or.Firefox },
      { regex: /safari|applewebkit/i, browser: or.Safari },
    ],
    lr = [
      { regex: /huawei/i, device: rr.Mobile },
      { regex: /nexus\s*(?:7|8|9|10).*/i, device: rr.Tablet },
      { regex: /ipad/i, device: rr.Tablet },
      { regex: /tablet(?! pc)/i, device: rr.Tablet },
      { regex: /(ipod|iphone)/i, device: rr.Mobile },
      { regex: /nexus\s*[0-6].*/i, device: rr.Mobile },
      { regex: /[^-]mobi/i, device: rr.Mobile },
    ],
    dr = [
      { os: ar.MacOS, regex: /macintosh/i },
      { os: ar.IOS, regex: /(ipod|iphone|ipad)/i },
      { os: ar.Android, regex: /android/i },
      { os: ar.Windows, regex: /windows /i },
      { os: ar.Linux, regex: /linux/i },
      { os: ar.ChromeOs, regex: /CrOS/ },
    ],
    fr = Symbol(),
    gr = Symbol(),
    mr = Symbol();
  function vr(e) {
    var t = e.navigator.userAgent,
      n = (function (e, t) {
        var n,
          i = lr.filter(function (t) {
            return t.regex.test(e);
          });
        return i.length > 0
          ? i[0].device
          : (
              null === (n = t.navigator.userAgentData) || void 0 === n
                ? void 0
                : n.mobile
            )
          ? rr.Mobile
          : rr.Desktop;
      })(t, e),
      i = (function (e) {
        var t = ur.filter(function (t) {
          return t.regex.test(e);
        });
        return t.length > 0 ? t[0].browser : or.Other;
      })(t),
      r = (function (e) {
        var t = dr.filter(function (t) {
          return t.regex.test(e);
        });
        return t.length > 0 ? t[0].os : ar.Other;
      })(t);
    return u(
      u(
        u({}, fr, function () {
          return n;
        }),
        gr,
        function () {
          return i;
        }
      ),
      mr,
      function () {
        return r;
      }
    );
  }
  var pr = function (e, t, n, i) {
      return function (r) {
        var o =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
        return e.fetch ? br(e, t, n, i, r, o) : hr(r, o);
      };
    },
    br = function (e, t, n, i, r) {
      var o =
        arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : {};
      return e
        .fetch(r, {
          method: o.method || "GET",
          credentials: "omit",
          mode: o.mode || "cors",
          keepalive: !0,
          headers: o.headers || {},
          body: o.body,
        })
        .then(function (e) {
          if (!e.ok && "no-cors" !== o.mode)
            throw new Error("Network response was not ok");
          return e;
        })
        .catch(function (e) {
          var r = String(e).toLowerCase();
          if (
            r.includes(
              "TypeError: NetworkError when attempting to fetch resource".toLowerCase()
            )
          )
            t[E](
              "Unable to fire ".concat(
                i,
                " request, possibly unable to outlive environment."
              )
            );
          else if (
            r.includes("TypeError: Load failed".toLowerCase()) &&
            n === or.Safari
          )
            t[E](
              "Unable to fire ".concat(i, " request, unknown network error.")
            );
          else {
            if (!r.includes("TypeError: Failed to fetch".toLowerCase()))
              throw e;
            t[E](
              "Unable to fire ".concat(
                i,
                " request, possibly be blocked by AdBlock."
              )
            );
          }
        });
    },
    hr = function (e) {
      var t =
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
      return new Promise(function (n, i) {
        var r = new XMLHttpRequest();
        (r.onload = function () {
          r.status >= 200 && r.status < 300
            ? n(
                new Response(r.responseText, {
                  status: r.status,
                  statusText: r.statusText,
                })
              )
            : i(new Error("Request failed with status " + r.status));
        }),
          (r.onerror = function () {
            return i(new Error("Network error"));
          }),
          r.open(t.method || "GET", e, !0),
          ae(t.headers) &&
            Object.keys(t.headers).forEach(function (e) {
              r.setRequestHeader(e, t.headers[e]);
            }),
          r.send(t.body || null);
      });
    },
    yr = Symbol(),
    Sr = Symbol();
  function Ir(e) {
    var t = {};
    return (
      e[gt].subscribe(function () {
        t = {};
      }),
      e[bt].subscribe(function (e) {
        var n;
        (n = e.slotDivId), delete t[n];
      }),
      u(
        u({}, yr, function () {
          return 0 === Object.keys(t).length ? void 0 : t;
        }),
        Sr,
        function (e, n) {
          t[e] = n;
        }
      )
    );
  }
  function wr(e) {
    if (e >= 1e4) return "over_9999";
    var t = e < 4e3 ? 500 : 1e3,
      n = Math.floor(e / t) * t;
    return "".concat(n, "-").concat(n + t - 1);
  }
  var _r = function (e) {
    return e < 50
      ? e.toString()
      : e < 76
      ? "50-75"
      : e < 101
      ? "76-100"
      : e < 151
      ? "101-150"
      : e < 201
      ? "151-200"
      : e < 301
      ? "201-300"
      : e < 401
      ? "301-400"
      : e < 501
      ? "401-500"
      : "over_500";
  };
  function Er(e) {
    return {
      _tag: "loading",
      loadStart: e,
      deferredLoad:
        arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
    };
  }
  function kr(e, t, n) {
    return {
      _tag: "ready",
      loadStart: e.loadStart,
      loadFinish: t,
      loadElapsed: t - e.loadStart,
      deferredLoad: e.deferredLoad,
      output: n,
    };
  }
  var Cr = [
      "yandex",
      "gpt",
      "prebid",
      "cmp",
      "uam",
      "docReadyScan",
      "pubxai",
      "gamera",
      "interstitial",
      "intentIQ",
      "afs",
      "assertiveYield",
    ],
    Tr = Symbol(),
    Ar = Symbol();
  function Rr(e, t, n) {
    var i = Cr.reduce(function (e, t) {
      return (e[t] = { _tag: "pending" }), e;
    }, {});
    return u(
      c("get", {}, Tr, function () {
        return i;
      }),
      Ar,
      function (r, o) {
        (i[r] = o),
          n[bi]("component_init_".concat(r, "_").concat(o._tag)),
          "ready" === o._tag &&
            t[C]("[INIT]: Component ".concat(r, " is ready")),
          e[St].emit({ component: r, state: o });
      }
    );
  }
  function xr(e) {
    return (
      "disabled" == e._tag ||
      ("ready" === e._tag && e.output.allowPersonalisation)
    );
  }
  function Pr(e) {
    return "ready" == e._tag ? e.output.jurisdiction : "unknown";
  }
  function Or(e) {
    switch (e._tag) {
      case "ready":
        return wr(e.loadFinish);
      case "disabled":
        return "disabled";
      case "cancelled":
        return "cancelled";
      case "pending":
      case "deferred":
      case "loaded":
      case "loading":
        return "not_ready";
      default:
        ce(e);
    }
  }
  var Dr =
      (this && this.__rest) ||
      function (e, t) {
        var n = {};
        for (var i in e)
          Object.prototype.hasOwnProperty.call(e, i) &&
            t.indexOf(i) < 0 &&
            (n[i] = e[i]);
        if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
          var r = 0;
          for (i = Object.getOwnPropertySymbols(e); r < i.length; r++)
            t.indexOf(i[r]) < 0 &&
              Object.prototype.propertyIsEnumerable.call(e, i[r]) &&
              (n[i[r]] = e[i[r]]);
        }
        return n;
      },
    Nr = Symbol();
  function zr(e, t, n) {
    var i = {};
    return (
      n[Vt].subscribe(function (e) {
        i = Object.assign(
          Object.assign({}, i),
          u({}, e.slot.slotDivId, { registeredTime: e.slot.storedAt })
        );
      }),
      n[Ct].subscribe(function (e) {
        var n = e.slot.getSlotElementId(),
          r = i[n];
        i = Object.assign(
          Object.assign({}, i),
          u({}, n, {
            registeredTime: null == r ? void 0 : r.registeredTime,
            inViewTime: null == r ? void 0 : r.inViewTime,
            gptRequestTime: t[ri](),
            hasEmptyRender: null == r ? void 0 : r.hasEmptyRender,
            hasEmptyRenderBefore: null == r ? void 0 : r.hasEmptyRenderBefore,
          })
        );
      }),
      n[Et].subscribe(function (n) {
        var r = n.slot.getSlotElementId(),
          o = !0 === n.isEmpty,
          a = i[r],
          s = !0 === (null == a ? void 0 : a.hasEmptyRender);
        s !== o &&
          e[C](
            "[SLOTS]["
              .concat(r, "]: previousEmpty: ")
              .concat(s, ", currentEmpty: ")
              .concat(o)
          ),
          (i = Object.assign(
            Object.assign({}, i),
            u(
              {},
              r,
              Object.assign(Object.assign({}, a), {
                renderTime: t[ri](),
                hasEmptyRender: o,
                hasEmptyRenderBefore:
                  (null == a ? void 0 : a.hasEmptyRenderBefore) || o,
              })
            )
          ));
      }),
      n[Ht].subscribe(function (e) {
        var t = i[e.slotDivId];
        t &&
          !ae(t.inViewTime) &&
          (i = Object.assign(
            Object.assign({}, i),
            u(
              {},
              e.slotDivId,
              Object.assign(Object.assign({}, t), { inViewTime: e.enteredAt })
            )
          ));
      }),
      n[gt].subscribe(function () {
        i = {};
      }),
      n[bt].subscribe(function (e) {
        var t = i,
          n = e.slotDivId;
        t[n];
        var r = Dr(t, ["symbol" === I(n) ? n : n + ""]);
        i = r;
      }),
      u({}, Nr, function (e) {
        var t = i[e];
        return t ? Object.assign({}, t) : void 0;
      })
    );
  }
  var Br,
    Mr = -1,
    Ur = function (e) {
      addEventListener(
        "pageshow",
        function (t) {
          t.persisted && ((Mr = t.timeStamp), e(t));
        },
        !0
      );
    },
    jr = function () {
      var e =
        self.performance &&
        performance.getEntriesByType &&
        performance.getEntriesByType("navigation")[0];
      if (e && e.responseStart > 0 && e.responseStart < performance.now())
        return e;
    },
    Lr = function () {
      var e = jr();
      return (e && e.activationStart) || 0;
    },
    Fr = function (e, t) {
      var n = jr(),
        i = "navigate";
      return (
        Mr >= 0
          ? (i = "back-forward-cache")
          : n &&
            (document.prerendering || Lr() > 0
              ? (i = "prerender")
              : document.wasDiscarded
              ? (i = "restore")
              : n.type && (i = n.type.replace(/_/g, "-"))),
        {
          name: e,
          value: void 0 === t ? -1 : t,
          rating: "good",
          delta: 0,
          entries: [],
          id: "v4-"
            .concat(Date.now(), "-")
            .concat(Math.floor(8999999999999 * Math.random()) + 1e12),
          navigationType: i,
        }
      );
    },
    Gr = function (e, t, n) {
      try {
        if (PerformanceObserver.supportedEntryTypes.includes(e)) {
          var i = new PerformanceObserver(function (e) {
            Promise.resolve().then(function () {
              t(e.getEntries());
            });
          });
          return (
            i.observe(Object.assign({ type: e, buffered: !0 }, n || {})), i
          );
        }
      } catch (e) {}
    },
    Vr = function (e, t, n, i) {
      var r, o;
      return function (a) {
        t.value >= 0 &&
          (a || i) &&
          ((o = t.value - (r || 0)) || void 0 === r) &&
          ((r = t.value),
          (t.delta = o),
          (t.rating = (function (e, t) {
            return e > t[1] ? "poor" : e > t[0] ? "needs-improvement" : "good";
          })(t.value, n)),
          e(t));
      };
    },
    Hr = function (e) {
      requestAnimationFrame(function () {
        return requestAnimationFrame(function () {
          return e();
        });
      });
    },
    qr = function (e) {
      document.addEventListener("visibilitychange", function () {
        "hidden" === document.visibilityState && e();
      });
    },
    Wr = function (e) {
      var t = !1;
      return function () {
        t || (e(), (t = !0));
      };
    },
    Yr = -1,
    Zr = function () {
      return "hidden" !== document.visibilityState || document.prerendering
        ? 1 / 0
        : 0;
    },
    Jr = function (e) {
      "hidden" === document.visibilityState &&
        Yr > -1 &&
        ((Yr = "visibilitychange" === e.type ? e.timeStamp : 0), Kr());
    },
    Qr = function () {
      addEventListener("visibilitychange", Jr, !0),
        addEventListener("prerenderingchange", Jr, !0);
    },
    Kr = function () {
      removeEventListener("visibilitychange", Jr, !0),
        removeEventListener("prerenderingchange", Jr, !0);
    },
    Xr = function () {
      return (
        Yr < 0 &&
          ((Yr = Zr()),
          Qr(),
          Ur(function () {
            setTimeout(function () {
              (Yr = Zr()), Qr();
            }, 0);
          })),
        {
          get firstHiddenTime() {
            return Yr;
          },
        }
      );
    },
    $r = function (e) {
      document.prerendering
        ? addEventListener(
            "prerenderingchange",
            function () {
              return e();
            },
            !0
          )
        : e();
    },
    eo = [1800, 3e3],
    to = function (e, t) {
      (t = t || {}),
        $r(function () {
          var n,
            i = Xr(),
            r = Fr("FCP"),
            o = Gr("paint", function (e) {
              e.forEach(function (e) {
                "first-contentful-paint" === e.name &&
                  (o.disconnect(),
                  e.startTime < i.firstHiddenTime &&
                    ((r.value = Math.max(e.startTime - Lr(), 0)),
                    r.entries.push(e),
                    n(!0)));
              });
            });
          o &&
            ((n = Vr(e, r, eo, t.reportAllChanges)),
            Ur(function (i) {
              (r = Fr("FCP")),
                (n = Vr(e, r, eo, t.reportAllChanges)),
                Hr(function () {
                  (r.value = performance.now() - i.timeStamp), n(!0);
                });
            }));
        });
    },
    no = [0.1, 0.25],
    io = 0,
    ro = 1 / 0,
    oo = 0,
    ao = function (e) {
      e.forEach(function (e) {
        e.interactionId &&
          ((ro = Math.min(ro, e.interactionId)),
          (oo = Math.max(oo, e.interactionId)),
          (io = oo ? (oo - ro) / 7 + 1 : 0));
      });
    },
    so = function () {
      return Br ? io : performance.interactionCount || 0;
    },
    co = function () {
      "interactionCount" in performance ||
        Br ||
        (Br = Gr("event", ao, {
          type: "event",
          buffered: !0,
          durationThreshold: 0,
        }));
    },
    uo = [],
    lo = new Map(),
    fo = 0,
    go = [],
    mo = function (e) {
      if (
        (go.forEach(function (t) {
          return t(e);
        }),
        e.interactionId || "first-input" === e.entryType)
      ) {
        var t = uo[uo.length - 1],
          n = lo.get(e.interactionId);
        if (n || uo.length < 10 || e.duration > t.latency) {
          if (n)
            e.duration > n.latency
              ? ((n.entries = [e]), (n.latency = e.duration))
              : e.duration === n.latency &&
                e.startTime === n.entries[0].startTime &&
                n.entries.push(e);
          else {
            var i = { id: e.interactionId, latency: e.duration, entries: [e] };
            lo.set(i.id, i), uo.push(i);
          }
          uo.sort(function (e, t) {
            return t.latency - e.latency;
          }),
            uo.length > 10 &&
              uo.splice(10).forEach(function (e) {
                return lo.delete(e.id);
              });
        }
      }
    },
    vo = function (e) {
      var t = self.requestIdleCallback || self.setTimeout,
        n = -1;
      return (
        (e = Wr(e)),
        "hidden" === document.visibilityState ? e() : ((n = t(e)), qr(e)),
        n
      );
    },
    po = [200, 500],
    bo = function (e, t) {
      "PerformanceEventTiming" in self &&
        "interactionId" in PerformanceEventTiming.prototype &&
        ((t = t || {}),
        $r(function () {
          var n;
          co();
          var i,
            r = Fr("INP"),
            o = function (e) {
              vo(function () {
                e.forEach(mo);
                var t = (function () {
                  var e = Math.min(uo.length - 1, Math.floor((so() - fo) / 50));
                  return uo[e];
                })();
                t &&
                  t.latency !== r.value &&
                  ((r.value = t.latency), (r.entries = t.entries), i());
              });
            },
            a = Gr("event", o, {
              durationThreshold:
                null !== (n = t.durationThreshold) && void 0 !== n ? n : 40,
            });
          (i = Vr(e, r, po, t.reportAllChanges)),
            a &&
              (a.observe({ type: "first-input", buffered: !0 }),
              qr(function () {
                o(a.takeRecords()), i(!0);
              }),
              Ur(function () {
                (fo = so()),
                  (uo.length = 0),
                  lo.clear(),
                  (r = Fr("INP")),
                  (i = Vr(e, r, po, t.reportAllChanges));
              }));
        }));
    },
    ho = [2500, 4e3],
    yo = {},
    So = [800, 1800],
    Io = function e(t) {
      document.prerendering
        ? $r(function () {
            return e(t);
          })
        : "complete" !== document.readyState
        ? addEventListener(
            "load",
            function () {
              return e(t);
            },
            !0
          )
        : setTimeout(t, 0);
    },
    wo = function (e, t) {
      t = t || {};
      var n = Fr("TTFB"),
        i = Vr(e, n, So, t.reportAllChanges);
      Io(function () {
        var r = jr();
        r &&
          ((n.value = Math.max(r.responseStart - Lr(), 0)),
          (n.entries = [r]),
          i(!0),
          Ur(function () {
            (n = Fr("TTFB", 0)), (i = Vr(e, n, So, t.reportAllChanges))(!0);
          }));
      });
    },
    _o = function (e) {
      return e.bottom < 0;
    },
    Eo = function (e, t) {
      return t - e.top;
    },
    ko = {
      name: "amxId",
      eidSources: ["amxdt.net"],
      isEnabled: function (e) {
        return e.isAmxIdEnabled();
      },
      buildEntry: function (e) {
        return (
          e.logger[k]("[PREBID]: Added amx id"),
          { storage: { name: "amxId", type: "html5", expires: 30 } }
        );
      },
    },
    Co = {
      name: "sharedId",
      eidSources: ["pubcid.org"],
      isEnabled: function (e) {
        return e.isSharedIdEnabled();
      },
      buildEntry: function (e) {
        return (
          e.logger[k]("[PREBID]: Added shared id"),
          { storage: { name: "_sharedID", type: "cookie", expires: 30 } }
        );
      },
    },
    To = {
      name: "pairId",
      eidSources: ["google.com"],
      isEnabled: function (e) {
        return e.isPairIdEnabled();
      },
      buildEntry: function (e) {
        return (
          e.logger[k]("[PREBID]: Added pair id"),
          { params: { liveramp: { storageKey: "_lr_pairId" } } }
        );
      },
    },
    Ao = {
      name: "adfixusId",
      eidSources: ["acid.adfixus.com", "plid.adfixus.com"],
      isEnabled: function (e) {
        return e.isAdfixusIdEnabled();
      },
      buildEntry: function (e) {
        return (
          e.logger[k]("[PREBID]: Added adfixus id"),
          { params: { enablePlatformID: !0, enableAcid: !0 } }
        );
      },
    },
    Ro = {
      name: "identityLink",
      eidSources: ["liveramp.com"],
      isEnabled: function (e) {
        return e.isIdentityEnabled();
      },
      setup: function (e) {
        var t,
          n = e.browserWindow,
          i = e.settings.getIdentitySettings(),
          r = n.document.createElement("script");
        (r.async = !0),
          (r.defer = !0),
          (r.src = "https://launchpad-wrapper.privacymanager.io/".concat(
            i.userIdentityGlobal || "47eddec1-62a9-4081-b655-0c9fa5eb8a0d",
            "/launchpad-liveramp.js"
          ));
        var o = n.document.getElementsByTagName("script")[0];
        null === (t = null == o ? void 0 : o.parentNode) ||
          void 0 === t ||
          t.insertBefore(r, o);
      },
      buildEntry: function (e) {
        var t = e.settings;
        return (
          e.logger[k]("[PREBID]: Added identity link id"),
          {
            params: { pid: t.getIdentitySettings().placementId },
            storage: {
              type: "cookie",
              name: "idl_env",
              expires: 7,
              refreshInSeconds: 1800,
              notUse3P: !1,
            },
          }
        );
      },
      getAnalytics: function (e) {
        return {
          provider: "atsAnalytics",
          options: { pid: e.getIdentitySettings().placementId },
        };
      },
      userSyncOverrides: { syncDelay: 3e3 },
    },
    xo = {
      name: "id5Id",
      eidSources: ["id5-sync.com", "true-link-id5-sync.com"],
      isEnabled: function (e) {
        return e.isId5Enabled() && Boolean(e.getId5PartnerId());
      },
      buildEntry: function (e) {
        var t = e.settings;
        return (
          e.logger[k]("[PREBID]: Added id5 id"),
          {
            params: {
              partner: t.getId5PartnerId(),
              externalModuleUrl:
                "https://cdn.id5-sync.com/api/1.0/id5PrebidModule.js",
              canCookieSync: !0,
            },
            storage: {
              type: "html5",
              name: "id5id",
              expires: 90,
              refreshInSeconds: 7200,
            },
          }
        );
      },
      getAnalytics: function (e) {
        return {
          provider: "id5Analytics",
          options: { partnerId: e.getId5PartnerId() },
        };
      },
    },
    Po = {
      name: "unifiedId",
      eidSources: ["adserver.org"],
      isEnabled: function (e) {
        return e.isUnifiedIdEnabled();
      },
      buildEntry: function (e) {
        var t = e.settings,
          n = e.logger,
          i = t.getUnifiedIdPartner();
        return (
          n[k]("[PREBID]: Added unified id with partner ".concat(i)),
          {
            params: { partner: i },
            storage: { name: "pbjs-unifiedid", type: "html5", expires: 30 },
          }
        );
      },
    },
    Oo = [
      Ao,
      ko,
      {
        name: "criteo",
        eidSources: ["criteo.com"],
        isEnabled: function (e) {
          return e.isCriteoIdEnabled();
        },
        buildEntry: function () {
          return {};
        },
      },
      xo,
      Ro,
      To,
      Co,
      Po,
    ];
  var Do =
      (this && this.__rest) ||
      function (e, t) {
        var n = {};
        for (var i in e)
          Object.prototype.hasOwnProperty.call(e, i) &&
            t.indexOf(i) < 0 &&
            (n[i] = e[i]);
        if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
          var r = 0;
          for (i = Object.getOwnPropertySymbols(e); r < i.length; r++)
            t.indexOf(i[r]) < 0 &&
              Object.prototype.propertyIsEnumerable.call(e, i[r]) &&
              (n[i[r]] = e[i[r]]);
        }
        return n;
      },
    No = function (e) {
      return 100 * Math.random() < e;
    },
    zo = function (e) {
      var t, n, i;
      if ("LCP" === e.name)
        i = null === (t = e.entries[0]) || void 0 === t ? void 0 : t.element;
      else if ("CLS" === e.name) {
        var r = e.entries.reduce(function (e, t) {
          return !e || t.value > e.value ? t : e;
        }, void 0);
        i =
          null === (n = null == r ? void 0 : r.sources[r.sources.length - 1]) ||
          void 0 === n
            ? void 0
            : n.node;
      } else if ("INP" === e.name) {
        var o = e.entries.reduce(function (e, t) {
          return !e || t.duration > e.duration ? t : e;
        }, void 0);
        i = null == o ? void 0 : o.target;
      }
      return i
        ? (function (e) {
            var t, n, i;
            if (
              !(null == e ? void 0 : e.tagName) ||
              !(null == e ? void 0 : e.classList)
            )
              return "";
            var r = e.tagName.toLowerCase(),
              o = e.id ? " #".concat(e.id) : "",
              a = e.classList.length > 0 ? " .".concat(e.classList.value) : "",
              s =
                null !==
                  (n =
                    null === (t = e.style) || void 0 === t
                      ? void 0
                      : t.cssText) && void 0 !== n
                  ? n
                  : "",
              c = null === (i = e.dataset) || void 0 === i ? void 0 : i.fuse,
              u = c ? ' [data-fuse="'.concat(c, '"]') : "";
            return ""
              .concat(r)
              .concat(o)
              .concat(a)
              .concat(u, " ")
              .concat(s)
              .trim();
          })(i)
        : void 0;
    };
  function Bo(e, t) {
    var n = new RegExp("^[^#]*[?&]" + e + "=([^&#]*)").exec(t);
    return n ? decodeURIComponent(n[1].replace(/\+/g, " ")) : null;
  }
  function Mo(e) {
    return e.replace(/#.*/, "").replace(/[{}]/g, "");
  }
  var Uo = Symbol(),
    jo = Symbol(),
    Lo = Symbol(),
    Fo = Symbol(),
    Go = Symbol(),
    Vo = Symbol(),
    Ho = Symbol(),
    qo = Symbol(),
    Wo = Symbol(),
    Yo = Symbol(),
    Zo = Symbol(),
    Jo = Symbol(),
    Qo = Symbol(),
    Ko = Symbol(),
    Xo = Symbol(),
    $o = Symbol();
  function ea(e, t, n, i, r, o, a, c, l, d, f, g, m, v) {
    var p,
      h = f.getFuseCDN(),
      S = f.getFuseCDNPlatform(),
      w = f.getFuseUUID(),
      _ = f.getFuseId(),
      R = f.getPublicationId(),
      x = f.isYandexEnabled() ? "yandex" : "gpt",
      P = f.getTenantCode(),
      O = f.getAccountCode(),
      D = f.isBidCacheEnabled(),
      N = f.getPrebidTelemetrySampleRate(),
      z = f.getSlotRequestTelemetrySampleRate(),
      B = f.getSlotRenderEndedSampleRate(),
      M = f.getSlotViewableSampleRate(),
      U = f.getCarouselTelemetrySampleRate(),
      j = f.getCwvSampleRate(),
      L = f.getPrebidAdRenderSucceededTelemetrySampleRate(),
      F = f.getHeavyAdTelemetrySampleRate(),
      G = f.getExcludedNetworksForGeo(),
      V = Object.assign(
        Object.assign({}, f.getYieldExperimentsTargeting()),
        f.getAdditionalYieldExperimentsTargeting()
      ),
      H = void 0,
      q = new Set();
    if (f.getUseTelemetry()) {
      var W = function (e) {
        var t = e.slot.getAdUnitPath(),
          n = f.getFuseSlots().find(function (e) {
            return e.slot === t;
          });
        return n
          ? { adUnit: n, slotElementId: e.slot.getSlotElementId() }
          : void 0;
      };
      g[Ct].subscribe(function (e) {
        var t = W(e);
        t && Q(t);
      }),
        g[Et].subscribe(function (e) {
          var t = W(e);
          t && K(Object.assign(Object.assign({}, t), { isEmpty: e.isEmpty }));
        }),
        g[Tt].subscribe(function (e) {
          var t = W(e);
          t && X(t);
        }),
        g[ft].subscribe(function (e) {
          e.isPageTransition && $(i.scrollY);
        }),
        g[St].subscribe(function (t) {
          if (
            "cmp" === t.component &&
            ["ready", "disabled"].includes(t.state._tag)
          ) {
            var n = "ready" === t.state._tag ? t.state : void 0,
              i = e[Tr];
            ee(
              {
                gdpr: "gdpr" === Pr(i.cmp) || !1,
                TCData: null == n ? void 0 : n.output.tcData,
                prebid_nry: "ready" !== i.prebid._tag || !1,
                uam_nry: "ready" !== i.uam._tag || !1,
                adserver_nry:
                  ("ready" !== i.gpt._tag && "ready" !== i.yandex._tag) || !1,
                docscan_nry: "ready" !== i.docReadyScan._tag || !1,
                no_cmp: "disabled" === t.state._tag,
                usp: "usp" === Pr(i.cmp) || !1,
                gppString: null == n ? void 0 : n.output.gppString,
                cmpStubLoadedMs: a[oi],
                cmpTcfLoadedMs: a[ai],
                cmpGppLoadedMs: a[si],
              },
              f.getCmpDeterminedSampleRate()
            );
          }
        });
    }
    function Y(e) {
      var t = e.activateConditionConfig;
      if ("lazy" === t.type) {
        var n = t.scrollDistance[f.getCurrentBreakpoint().name];
        return "number" == typeof n ? n : void 0;
      }
    }
    function Z(e) {
      var t,
        n = e.adUnit,
        r = e.slotElementId,
        a = e.isEmpty,
        s = null !== (t = o[Un](r)) && void 0 !== t ? t : 0,
        c = l[Nr](r);
      return Object.assign(
        {
          auid: n.id,
          slotid: r,
          aup: n.slot,
          empty: a,
          rc: Math.max(0, s - 1),
          dd: n.attributes.manualDisplay || n.isBidAheadZone,
          lsd: Y(n),
          srt: null == c ? void 0 : c.registeredTime,
          ivt: null == c ? void 0 : c.inViewTime,
          grt: null == c ? void 0 : c.gptRequestTime,
          rt: null == c ? void 0 : c.renderTime,
        },
        (function (e) {
          var t,
            n =
              null === (t = i.document.getElementById(e)) || void 0 === t
                ? void 0
                : t.parentElement;
          if (n) {
            var r = n.getBoundingClientRect();
            return { sp: String(Math.round(Eo(r, i.innerHeight))), abv: _o(r) };
          }
        })(r)
      );
    }
    function J(e, t, n, i) {
      oe(
        e,
        Object.assign(Object.assign(Object.assign({}, Z(t)), i), { srate: n }),
        se()
      );
    }
    function Q(e) {
      J("slot-request", e, z), ae(e.adUnit.id, "slot-request");
    }
    function K(e) {
      J("slot-rendered", e, B);
    }
    function X(e) {
      J("slot-viewable", e, M, { vt: a[ri]() }),
        ae(e.adUnit.id, "slot-viewable");
    }
    function $(e) {
      oe("page-transition", Object.assign({ sdi: e }, le()));
    }
    function ee(e, t) {
      if (e.TCData) {
        n[C](
          "[TELEMETRY]: TCData found, sending cmp-determined with compressed TCData"
        );
        var i = e.TCData;
        i.vendor,
          i.customVendorConsents,
          i.googleVendorConsents,
          ue(
            Do(i, ["vendor", "customVendorConsents", "googleVendorConsents"]),
            "cmp-determined",
            1e4
          )
            .then(function (n) {
              var i = n.compressedData,
                r = n.errMsg;
              oe(
                "cmp-determined",
                Object.assign(Object.assign({}, e), {
                  TCData: i,
                  errMsg: r,
                  srate: t,
                }),
                se()
              );
            })
            .catch(function (e) {
              n[T](
                "[TELEMETRY]: Error sending cmp-determined event telemetry with compressed TCData: ".concat(
                  e
                )
              );
            });
      } else
        n[C](
          "[TELEMETRY]: TCData not found, sending cmp-determined without compression"
        ),
          oe(
            "cmp-determined",
            Object.assign(Object.assign({}, e), { srate: t })
          );
    }
    function te() {
      for (var e = arguments.length, t = new Array(e), i = 0; i < e; i++)
        t[i] = arguments[i];
      n[A](function () {
        return "".concat(
          t.map(function (e) {
            return JSON.stringify(e);
          })
        );
      });
    }
    function ne() {
      var e;
      if (!(q.size <= 0)) {
        te("Flushing request queue");
        var t,
          n,
          i = [],
          r = s(q);
        try {
          for (r.s(); !(n = r.n()).done; ) {
            var o = n.value;
            "web-vitals" === o.eventType &&
            (null === (e = o.record) || void 0 === e ? void 0 : e.cwvRep)
              ? (i.push.apply(i, y(o.record.cwvRep)),
                o.cmpData && (t = o.cmpData))
              : oe(o.eventType, o.record, o.cmpData);
          }
        } catch (e) {
          r.e(e);
        } finally {
          r.f();
        }
        for (; i.length >= 1; )
          re("web-vitals", { cwvRep: i.splice(0, 10), srate: j }, t);
        q.clear();
      }
    }
    function ie(e, o, s) {
      var u,
        l,
        d,
        g =
          ((u = Object.assign(
            Object.assign(Object.assign({}, o), {
              cmpj: null == s ? void 0 : s.jurisdiction,
              cmpdialog: null == s ? void 0 : s.dialogShown,
            }),
            (function (e) {
              var o =
                  arguments.length > 1 && void 0 !== arguments[1]
                    ? arguments[1]
                    : 100,
                s = arguments.length > 2 ? arguments[2] : void 0,
                u = [i.location.href, ce()],
                l = u[0],
                d = u[1],
                g = f.getFuseGeo(),
                m = f.getCfConfig(),
                p = v
                  ? (function (e, t, n, i) {
                      try {
                        var r = t(n, i);
                        if (!r || "object" !== I(r) || Array.isArray(r))
                          return {};
                        for (
                          var o = {}, a = 0, s = Object.entries(r);
                          a < s.length;
                          a++
                        ) {
                          var c = b(s[a], 2),
                            u = c[0],
                            l = c[1];
                          "string" == typeof l && (o["custom_".concat(u)] = l);
                        }
                        return o;
                      } catch (t) {
                        return (
                          e[E](
                            "[TELEMETRY][customTelemetryCallback] Encountered error during evaluation",
                            t
                          ),
                          {}
                        );
                      }
                    })(n, v, i, null != s ? s : se())
                  : {};
              return Object.assign(
                Object.assign(
                  Object.assign(
                    {
                      v: "1",
                      ttm: Date.now(),
                      cookie: i.navigator.cookieEnabled,
                      res: "".concat(screen.width, "x").concat(screen.height),
                      device: t[fr](),
                      browser: t[gr](),
                      fuuid: w,
                      fid: _,
                      pubid: R,
                      url: Mo(l),
                      refr: Mo(d),
                      sid: r,
                      srate: o,
                      adserver: x,
                      etm: a[ri](),
                      e: e,
                      tenant: P,
                      sd: i.scrollY,
                      fusecdn: S,
                      tlt: a[ei],
                      account: O,
                      experiments: Object.keys(V).length ? V : void 0,
                      sf: f.isForceSafeFrames(),
                      cz: c[yr](),
                      bge: G.join(","),
                      bp: f.getCurrentBreakpoint().name,
                    },
                    g
                      ? {
                          geo_country: g.country,
                          geo_state: g.state,
                          geo_code: g.code,
                        }
                      : {}
                  ),
                  (null == m ? void 0 : m.bot) ? { bs: m.bot.score } : {}
                ),
                p
              );
            })(e, null == o ? void 0 : o.srate, s)
          )),
          Object.entries(u).reduce(function (e, t) {
            var n = b(t, 2),
              i = n[0],
              r = n[1];
            return r
              ? ("object" === I(r) && (r = JSON.stringify(r)),
                ""
                  .concat(e ? e + "&" : "?")
                  .concat(encodeURIComponent(i), "=")
                  .concat(encodeURIComponent(r)))
              : e;
          }, "")),
        m = "https://".concat(h);
      return "https://"
        .concat(
          ((l = m),
          (d = /^(?:(?:https?|ftp):)\/*(?:[^@/]+@)?([^:/#]+)/.exec(l)),
          d ? d[1] : l),
          "/telemetry/noconsent"
        )
        .concat(g);
    }
    function re(e, t, n) {
      f.getUseTelemetry() && d(ie(e, t, n));
    }
    function oe(e, t, n) {
      var i;
      f.getUseTelemetry() &&
        No(
          null !== (i = null == t ? void 0 : t.srate) && void 0 !== i ? i : 100
        ) &&
        d(ie(e, t, n));
    }
    function ae(e, i) {
      n[k](
        "[STATS]: Record "
          .concat(i, " event for fuse ")
          .concat(_, ", ad ")
          .concat(e, " on device ")
          .concat(t[fr](), " and browser ")
          .concat(t[gr]())
      );
    }
    function se() {
      var t = e[Tr].cmp;
      return {
        jurisdiction: Pr(t),
        personalisation: xr(t),
        dialogShown: a[yi](),
      };
    }
    function ce(e) {
      var t = Bo("referrer", i.location.href) || Bo("referer", i.location.href);
      if (t) return t;
      try {
        if (i.top) return i.top.document.referrer;
        if (i.parent) return i.parent.document.referrer;
      } catch (e) {}
      return i.document.referrer;
    }
    function ue(e, t) {
      var r =
        arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 11e3;
      return i.CompressionStream
        ? m(e)
            .then(function (e) {
              return e.length > r
                ? (n[E](
                    "[AUCTION]: Compressed payload too long: ".concat(
                      e.length,
                      " bytes. It will not be sent."
                    )
                  ),
                  { errMsg: "Compressed payload too long" })
                : { compressedData: e };
            })
            .catch(function (e) {
              return (
                n[T](
                  "[AUCTION]: Error compressing event - "
                    .concat(t, " - telemetry: ")
                    .concat(e)
                ),
                { errMsg: "Error compressing payload: ".concat(e.message) }
              );
            })
        : Promise.resolve({ errMsg: "CompressionStream API unavailable" });
    }
    function le() {
      var t = e[Tr];
      return {
        prebid_ready_ms: Or(t.prebid),
        uam_ready_ms: Or(t.uam),
        gpt_ready_ms: Or(t.gpt),
        cmp_load_finish_ms: a[Zn],
        cmp_determined_ms: Or(t.cmp),
        cmp_gdpr_cached: a[Jn],
      };
    }
    return (
      u(
        u(
          u(
            u(
              u(
                u(
                  u(u(u(u((p = {}), Uo, Q), jo, K), Lo, X), Fo, function (e) {
                    var t,
                      r,
                      o,
                      a = {
                        bid: e.bid,
                        size:
                          null === (t = e.bid) || void 0 === t
                            ? void 0
                            : t.size,
                        mediaType:
                          null === (r = e.bid) || void 0 === r
                            ? void 0
                            : r.mediaType,
                        bidder:
                          null === (o = e.bid) || void 0 === o
                            ? void 0
                            : o.bidder,
                        message: e.message,
                        reason: e.reason,
                        adId: e.adId,
                      };
                    try {
                      if (!a.bidder && i.fusePbjs && e.adId)
                        for (
                          var s = 0,
                            c = Object.values(i.fusePbjs.getBidResponses());
                          s < c.length;
                          s++
                        ) {
                          var u = c[s].bids.find(function (t) {
                            return t.adId === e.adId;
                          });
                          u &&
                            ((a.bidder = u.bidder),
                            (a.size = u.size),
                            (a.mediaType = u.mediaType));
                        }
                    } catch (t) {
                      n[T](
                        "[TELEMETRY]: Error getting bid response for adId "
                          .concat(e.adId, ": ")
                          .concat(JSON.stringify(t))
                      );
                    }
                    return ue(a, "prebid-ad-render-failed", 3e3).then(function (
                      e
                    ) {
                      return oe("prebid-ad-render-failed", {
                        pbAdRenderFailedGzipped: e.compressedData,
                        errMsg: e.errMsg,
                      });
                    });
                  }),
                  Go,
                  function (e) {
                    var t, n, i;
                    return ue(
                      {
                        size:
                          null === (t = e.bid) || void 0 === t
                            ? void 0
                            : t.size,
                        mediaType:
                          null === (n = e.bid) || void 0 === n
                            ? void 0
                            : n.mediaType,
                        bidder:
                          null === (i = e.bid) || void 0 === i
                            ? void 0
                            : i.bidder,
                        adId: e.adId,
                      },
                      "prebid-ad-render-succeeded",
                      3e3
                    ).then(function (e) {
                      var t = e.compressedData,
                        n = e.errMsg;
                      return oe("prebid-ad-render-succeeded", {
                        pbAdRenderSucceededGzipped: t,
                        srate: L,
                        errMsg: n,
                      });
                    });
                  }
                ),
                Vo,
                function (e) {
                  var t = e.bid,
                    n = e.adUnit,
                    i = e.adUnitCode,
                    r = e.slideNumber;
                  J(
                    "carousel-render-request",
                    { adUnit: n, slotElementId: i },
                    U,
                    {
                      slide: r,
                      adId: t.adId,
                      auctionId: t.auctionId,
                      bidder: t.bidder,
                      cpm: String(t.cpm),
                      creativeId: t.creativeId,
                      currency: t.currency,
                      height: t.height,
                      mediaType: t.mediaType,
                      requestId: t.requestId,
                      size: t.size,
                      status: t.status,
                      transactionId: t.transactionId,
                      ttl: t.ttl,
                      width: t.width,
                    }
                  );
                }
              ),
              Ho,
              function (e, t, n) {
                var i,
                  r,
                  a,
                  c,
                  u = Array.from(
                    new Set(
                      e.adUnits.map(function (e) {
                        return e.code;
                      })
                    )
                  ),
                  l =
                    null ===
                      (a =
                        null ===
                          (r =
                            null === (i = e.bidderRequests[0]) || void 0 === i
                              ? void 0
                              : i.ortb2) || void 0 === r
                          ? void 0
                          : r.site) || void 0 === a
                      ? void 0
                      : a.content,
                  d =
                    void 0 !== (null == l ? void 0 : l.language) ||
                    void 0 !== (null == l ? void 0 : l.keywords)
                      ? {
                          siteContentLanguage: null == l ? void 0 : l.language,
                          siteContentKeywords:
                            null === (c = null == l ? void 0 : l.keywords) ||
                            void 0 === c
                              ? void 0
                              : c.slice(0, 500),
                        }
                      : void 0,
                  g = (function (e) {
                    return e.isUserSyncEnabled()
                      ? Oo.filter(function (t) {
                          return t.isEnabled(e);
                        }).map(function (e) {
                          return e.name;
                        })
                      : [];
                  })(f),
                  m = new Set(g),
                  v = (function (e) {
                    var t,
                      n,
                      i,
                      r,
                      o,
                      a = new Set(),
                      c = function (e) {
                        if (e) {
                          var t,
                            n = s(e);
                          try {
                            for (n.s(); !(t = n.n()).done; ) {
                              var i = t.value;
                              "string" == typeof i.source &&
                                i.source.length > 0 &&
                                a.add(i.source);
                            }
                          } catch (e) {
                            n.e(e);
                          } finally {
                            n.f();
                          }
                        }
                      },
                      u = s(e);
                    try {
                      for (u.s(); !(o = u.n()).done; ) {
                        var l = o.value;
                        c(
                          null ===
                            (i =
                              null ===
                                (n =
                                  null === (t = l.ortb2) || void 0 === t
                                    ? void 0
                                    : t.user) || void 0 === n
                                ? void 0
                                : n.ext) || void 0 === i
                            ? void 0
                            : i.eids
                        );
                        var d,
                          f = s(null !== (r = l.bids) && void 0 !== r ? r : []);
                        try {
                          for (f.s(); !(d = f.n()).done; )
                            c(d.value.userIdAsEids);
                        } catch (e) {
                          f.e(e);
                        } finally {
                          f.f();
                        }
                      }
                    } catch (e) {
                      u.e(e);
                    } finally {
                      u.f();
                    }
                    return Oo.filter(function (e) {
                      return e.eidSources.some(function (e) {
                        return a.has(e);
                      });
                    }).map(function (e) {
                      return e.name;
                    });
                  })(e.bidderRequests).filter(function (e) {
                    return m.has(e);
                  }),
                  p = Object.assign(
                    Object.assign(
                      Object.assign(
                        Object.assign(
                          {
                            pbVer: t,
                            aucId: e.auctionId,
                            aucTimeout: e.timeout,
                            aucStart: e.timestamp,
                            aucEnd: e.auctionEnd,
                            bidCacheEnabled: D,
                          },
                          d ? { ortb2: d } : {}
                        ),
                        v.length > 0 && { userIds: v }
                      ),
                      g.length > 0 && { configuredUserIds: g }
                    ),
                    {
                      zones: u.map(function (t) {
                        var i,
                          r,
                          a,
                          s,
                          c,
                          u,
                          l,
                          d = n.getSlot(t),
                          f = o[Un](t),
                          g = o[jn](null == d ? void 0 : d.zoneTemplateId);
                        return {
                          id: t,
                          isRefresh: f > 0,
                          slotPrevReq: _r(f),
                          templatePrevReq: _r(g),
                          bidders: e.bidderRequests
                            .filter(function (e) {
                              return e.bids.find(function (e) {
                                return e.adUnitCode === t;
                              });
                            })
                            .map(function (e) {
                              return e.bidderCode;
                            }),
                          bidsReceived: e.bidsReceived
                            .filter(function (e) {
                              return e.adUnitCode === t;
                            })
                            .map(function (e) {
                              return {
                                bidder: e.bidder,
                                connectType: e.source,
                                mediaType: e.mediaType,
                                size: e.size,
                                timeToRespond: e.timeToRespond,
                                cpm: e.cpm,
                                currency: e.currency,
                                dealId: e.dealId,
                              };
                            }),
                          floorApplied:
                            null !==
                              (a =
                                null ===
                                  (r =
                                    null ===
                                      (i = e.bidsReceived.find(function (e) {
                                        return e.adUnitCode === t;
                                      })) || void 0 === i
                                      ? void 0
                                      : i.floorData) || void 0 === r
                                  ? void 0
                                  : r.floorValue) && void 0 !== a
                              ? a
                              : null ===
                                  (u =
                                    null ===
                                      (c = (
                                        null !== (s = e.bidsRejected) &&
                                        void 0 !== s
                                          ? s
                                          : []
                                      ).find(function (e) {
                                        return e.adUnitCode === t;
                                      })) || void 0 === c
                                      ? void 0
                                      : c.floorData) || void 0 === u
                              ? void 0
                              : u.floorValue,
                          bidsRejected: (null !== (l = e.bidsRejected) &&
                          void 0 !== l
                            ? l
                            : []
                          )
                            .filter(function (e) {
                              return e.adUnitCode === t;
                            })
                            .map(function (e) {
                              return {
                                bidder: e.bidder,
                                connectType: e.source,
                                mediaType: e.mediaType,
                                size: e.size,
                                timeToRespond: e.timeToRespond,
                                cpm: e.cpm,
                                currency: e.currency,
                                dealId: e.dealId,
                                rejectionReason: e.rejectionReason,
                              };
                            }),
                          bids: e.adUnits
                            .filter(function (e) {
                              return e.code === t;
                            })
                            .reduce(function (e, t) {
                              return e.concat(
                                t.bids.map(function (e) {
                                  return {
                                    mediaTypes: t.mediaTypes,
                                    bidder: e.bidder,
                                    params: e.params,
                                    bidSizes: e.bidSizes,
                                  };
                                })
                              );
                            }, []),
                        };
                      }),
                    }
                  );
                return ue(p, "prebid-auction-end").then(function (e) {
                  var t = e.compressedData,
                    n = e.errMsg;
                  oe(
                    "prebid-auction-end",
                    Object.assign(
                      { pbAuctionGzipped: t, errMsg: n, srate: N },
                      le()
                    )
                  );
                });
              }
            ),
            qo,
            function (e) {
              oe("fuse-load", { sdi: e });
            }
          ),
          Wo,
          function (e) {
            oe("deprecated-api-used", { deprecatedApi: e, srate: 100 }, se());
          }
        ),
        Yo,
        $
      ),
      u(
        u(
          u(
            u(
              u(u(p, Zo, ee), Jo, function (e, t, n) {
                oe(
                  "rogue-bidder-response",
                  {
                    slotid: e,
                    bidder: t.bidder,
                    pbTrId: t.transactionId,
                    pbReqId: t.requestId,
                    pbAdId: t.adId,
                    pbCrId: t.creativeId,
                    pbSize: t.size,
                    size: ki(n),
                    wDiff: Ai(t.width, n[0]),
                    hDiff: Ai(t.height, n[1]),
                  },
                  se()
                );
              }),
              Qo,
              function (e, t, n) {
                var i,
                  r,
                  o = t.size;
                oe(
                  "rogue-bidder-response",
                  {
                    slotid: e,
                    bidder: "adx",
                    pbAdId:
                      null === (i = t.sourceAgnosticLineItemId) || void 0 === i
                        ? void 0
                        : i.toString(),
                    pbCrId:
                      null === (r = t.sourceAgnosticCreativeId) || void 0 === r
                        ? void 0
                        : r.toString(),
                    pbSize: ki(o),
                    size: ki(n),
                    wDiff: Ai(o[0], n[0]),
                    hDiff: Ai(o[1], n[1]),
                  },
                  se()
                );
              }
            ),
            Ko,
            function (e) {
              var t;
              oe(
                "heavy-ad-intervention",
                {
                  har: e.raw,
                  harn: e.reason,
                  harm: "".concat(e.wasRemoved),
                  hav: e.via,
                  hafi: e.frameId,
                  hafu: e.reportableFrameUrl,
                  hasi: e.slotId,
                  haz: e.zoneCode,
                  harc:
                    null === (t = e.refreshCount) || void 0 === t
                      ? void 0
                      : t.toString(),
                  harf: "".concat(e.refreshed),
                  srate: F,
                },
                se()
              );
            }
          ),
          Xo,
          function () {
            if (No(j)) {
              var e = function (e) {
                var t,
                  n,
                  i,
                  r = (function (e) {
                    return {
                      name: e.name,
                      value: "".concat(e.value),
                      rating: e.rating,
                      id: e.id,
                      delta: "".concat(e.delta),
                      element: zo(e),
                    };
                  })(e);
                te("[WEB-VITALS]: ".concat(JSON.stringify(r))),
                  (t = "web-vitals"),
                  (n = { cwvRep: [r] }),
                  (i = se()),
                  q.add({ eventType: t, record: n, cmpData: i }),
                  clearTimeout(H),
                  (H = setTimeout(function () {
                    ne();
                  }, 5e3));
              };
              te("[WEB-VITALS]: Set up web vitals callbacks"),
                (function (e, t) {
                  (t = t || {}),
                    to(
                      Wr(function () {
                        var n,
                          i = Fr("CLS", 0),
                          r = 0,
                          o = [],
                          a = function (e) {
                            e.forEach(function (e) {
                              if (!e.hadRecentInput) {
                                var t = o[0],
                                  n = o[o.length - 1];
                                r &&
                                e.startTime - n.startTime < 1e3 &&
                                e.startTime - t.startTime < 5e3
                                  ? ((r += e.value), o.push(e))
                                  : ((r = e.value), (o = [e]));
                              }
                            }),
                              r > i.value &&
                                ((i.value = r), (i.entries = o), n());
                          },
                          s = Gr("layout-shift", a);
                        s &&
                          ((n = Vr(e, i, no, t.reportAllChanges)),
                          qr(function () {
                            a(s.takeRecords()), n(!0);
                          }),
                          Ur(function () {
                            (r = 0),
                              (i = Fr("CLS", 0)),
                              (n = Vr(e, i, no, t.reportAllChanges)),
                              Hr(function () {
                                return n();
                              });
                          }),
                          setTimeout(n, 0));
                      })
                    );
                })(e, { reportAllChanges: !0 }),
                to(e),
                bo(e),
                (function (e, t) {
                  (t = t || {}),
                    $r(function () {
                      var n,
                        i = Xr(),
                        r = Fr("LCP"),
                        o = function (e) {
                          t.reportAllChanges || (e = e.slice(-1)),
                            e.forEach(function (e) {
                              e.startTime < i.firstHiddenTime &&
                                ((r.value = Math.max(e.startTime - Lr(), 0)),
                                (r.entries = [e]),
                                n());
                            });
                        },
                        a = Gr("largest-contentful-paint", o);
                      if (a) {
                        n = Vr(e, r, ho, t.reportAllChanges);
                        var s = Wr(function () {
                          yo[r.id] ||
                            (o(a.takeRecords()),
                            a.disconnect(),
                            (yo[r.id] = !0),
                            n(!0));
                        });
                        ["keydown", "click"].forEach(function (e) {
                          addEventListener(
                            e,
                            function () {
                              return vo(s);
                            },
                            { once: !0, capture: !0 }
                          );
                        }),
                          qr(s),
                          Ur(function (i) {
                            (r = Fr("LCP")),
                              (n = Vr(e, r, ho, t.reportAllChanges)),
                              Hr(function () {
                                (r.value = performance.now() - i.timeStamp),
                                  (yo[r.id] = !0),
                                  n(!0);
                              });
                          });
                      }
                    });
                })(e, { reportAllChanges: !0 }),
                wo(e);
            } else
              te(
                "[WEB-VITALS]: Disabled web vitals recording for session not sampled at rate ".concat(
                  j
                )
              );
          }
        ),
        $o,
        function () {
          i.addEventListener("visibilitychange", function () {
            "hidden" === i.document.visibilityState && ne();
          });
        }
      )
    );
  }
  var ta = Symbol(),
    na = Symbol(),
    ia = Symbol(),
    ra = Symbol(),
    oa = Symbol(),
    aa = Symbol(),
    sa = Symbol(),
    ca = Symbol(),
    ua = Symbol();
  function la(e, t, n) {
    return pr(e, t, n[gr](), "telemetry");
  }
  var da = M()(function (e) {
      return e
        .register(ta, [j], vr)
        .register(oa, [], Vn)
        .register(na, [V, Kt], Si)
        .register(aa, [Kt], Ir)
        .register(sa, [L, na, Kt], zr)
        .register(ca, [j, L, ta], la)
        .register(ra, [Kt, L, na], Rr)
        .register(ua, [], function () {
          return cr;
        })
        .register(ia, [ra, ta, L, j, G, oa, na, aa, sa, ca, $i, Kt, ua, Ge], ea)
        .export();
    }),
    fa = Symbol(),
    ga = Symbol(),
    ma = Symbol();
  function va(e, t) {
    var n = t;
    return u(
      u(
        u({}, fa, function () {
          !(function () {
            e[k]("[CMP]: Generating TCF stub");
            for (
              var t = "__tcfapiLocator",
                i = [],
                r = n,
                o = void 0,
                a = function () {
                  var n = r.document,
                    i = !!r.frames[t];
                  if (i) e[k]("[CMP] Found existing TCF stub");
                  else if (
                    (e[k]("[CMP] TCF stub not found - generating"), n.body)
                  ) {
                    var o = n.createElement("iframe");
                    (o.style.cssText = "display:none"),
                      (o.name = t),
                      n.body.appendChild(o);
                  } else setTimeout(a, 5);
                  return !i;
                },
                s = r,
                c = function () {
                  try {
                    if (s.frames[t])
                      return (o = s), e[k]("[CMP] Found locator frame"), 0;
                  } catch (t) {
                    "{}" !== JSON.stringify(t) &&
                      e[C](function () {
                        return "[CMP]: ".concat(JSON.stringify(t));
                      });
                  }
                  if (s === n.top) return 0;
                  s = s.parent;
                };
              s && 0 !== c();

            );
            o ||
              (e[k]("[CMP] Locator frame not found"),
              a(),
              (r.__tcfapi = function () {
                var e = arguments,
                  t = void 0;
                if (!e.length) return i;
                if ("setGdprApplies" === e[0])
                  e.length > 3 &&
                    2 === e[2] &&
                    "boolean" == typeof e[3] &&
                    ((t = e[3]), "function" == typeof e[2] && e[2]("set", !0));
                else if ("ping" === e[0]) {
                  var n = { gdprApplies: t, cmpLoaded: !1, cmpStatus: "stub" };
                  "function" == typeof e[2] && e[2](n);
                } else {
                  var r =
                    "init" === e[0] && "object" === I(e[3])
                      ? [
                          e[0],
                          e[1],
                          e[2],
                          Object.assign(e[3], { tag_version: "V2" }),
                        ].concat(Array.from(e).slice(4))
                      : e;
                  i.push(r);
                }
              }),
              r.addEventListener(
                "message",
                function (t) {
                  var i = "string" == typeof t.data,
                    r = void 0;
                  try {
                    r = i ? JSON.parse(t.data) : t.data;
                  } catch (t) {
                    "{}" !== JSON.stringify(t) &&
                      e[T]("[CMP]: Error parsing message", JSON.stringify(t));
                  }
                  var o = null == r ? void 0 : r.__tcfapiCall;
                  if (o) {
                    var a = t.source;
                    n.__tcfapi(
                      o.command,
                      o.version,
                      function (e, t) {
                        var n = {
                          __tcfapiReturn: {
                            returnValue: e,
                            success: t,
                            callId: o.callId,
                          },
                        };
                        (null == a ? void 0 : a.postMessage) &&
                          a.postMessage(i ? JSON.stringify(n) : n, "*");
                      },
                      o.parameter
                    ),
                      (a = null);
                  }
                },
                !1
              ));
          })();
        }),
        ga,
        function () {
          e[C]("[CMP]: Generating GPP stub");
          var t = n;
          (n.__gpp_addFrame = function (e) {
            if (!t.frames[e])
              if (t.document.body) {
                var n = document.createElement("iframe");
                (n.style.cssText = "display:none"),
                  (n.name = e),
                  t.document.body.appendChild(n);
              } else
                t.setTimeout(function () {
                  return t.__gpp_addFrame(e);
                }, 10);
          }),
            (n.__gpp_stub = function () {
              var e = arguments;
              if (((t.__gpp.queue = t.__gpp.queue || []), !e.length))
                return t.__gpp.queue;
              var n = e[0],
                i = e.length > 1 ? e[1] : null,
                r = e.length > 2 ? e[2] : null;
              if ("ping" === n) {
                var o = {
                  gppVersion: "1.1",
                  cmpStatus: "stub",
                  cmpDisplayStatus: "hidden",
                  supportedAPIs: ["2:tcfeuv2", "5:tcfcav1", "6:uspv1"],
                  cmpId: 31,
                  sectionList: [],
                  applicableSections: [-1],
                  gppString: "",
                };
                return i(o, !0), o;
              }
              if ("addEventListener" === n) {
                (t.__gpp.events = t.__gpp.events || []),
                  "lastId" in t.__gpp || (t.__gpp.lastId = 0),
                  t.__gpp.lastId++;
                var a = t.__gpp.lastId;
                t.__gpp.events.push({ id: a, callback: i, parameter: r });
                var s = {
                  eventName: "listenerRegistered",
                  listenerId: a,
                  data: !0,
                  pingData: {
                    gppVersion: "1.1",
                    cmpStatus: "stub",
                    cmpDisplayStatus: "hidden",
                    supportedAPIs: [
                      "2:tcfeuv2",
                      "5:tcfcav1",
                      "9:usva",
                      "7:usnat",
                    ],
                    cmpId: 31,
                    sectionList: [],
                    applicableSections: [-1],
                    gppString: "",
                  },
                };
                return i(s, !0), s;
              }
              if ("removeEventListener" === n) {
                var c = !1;
                t.__gpp.events = t.__gpp.events || [];
                for (var u = 0; u < t.__gpp.events.length; u++)
                  if (t.__gpp.events[u].id == r) {
                    t.__gpp.events.splice(u, 1), (c = !0);
                    break;
                  }
                var l = {
                  eventName: "listenerRemoved",
                  listenerId: r,
                  data: c,
                  pingData: {
                    gppVersion: "1.1",
                    cmpStatus: "stub",
                    cmpDisplayStatus: "hidden",
                    supportedAPIs: [
                      "2:tcfeuv2",
                      "5:tcfcav1",
                      "9:usva",
                      "7:usnat",
                    ],
                    cmpId: 31,
                    sectionList: [],
                    applicableSections: [-1],
                    gppString: "",
                  },
                };
                return i(l, !0), l;
              }
              if ("hasSection" === n || "getSection" === n || "getField" === n)
                return null;
              t.__gpp.queue.push([].slice.apply(e));
            }),
            (n.__gpp_msghandler = function (e) {
              var n,
                i = "string" == typeof e.data;
              try {
                n = i ? JSON.parse(e.data) : e.data;
              } catch (e) {
                n = null;
              }
              if ("object" === I(n) && null !== n && "__gppCall" in n) {
                var r = n.__gppCall;
                t.__gpp(
                  r.command,
                  function (t, n) {
                    var o = {
                      __gppReturn: {
                        returnValue: t,
                        success: n,
                        callId: r.callId,
                      },
                    };
                    e.source.postMessage(i ? JSON.stringify(o) : o, "*");
                  },
                  "parameter" in r ? r.parameter : null,
                  "version" in r ? r.version : "1.1"
                );
              }
            }),
            "__gpp" in n && "function" == typeof n.__gpp
              ? e[C]("[CMP]: GPP already set, not setting __gpp")
              : (e[C]("[CMP]: GPP not yet set, setting to stub"),
                (n.__gpp = n.__gpp_stub),
                n.addEventListener("message", n.__gpp_msghandler, !1),
                n.__gpp_addFrame("__gppLocator"));
        }
      ),
      ma,
      function () {
        ("__uspapi" in n && "function" == typeof n.__uspapi) ||
          (n.__uspapi = function (t, n, i) {
            "getUSPData" === t
              ? i({ uspString: "1---" }, !0)
              : (e[E]("__uspapi command not supported: ".concat(t)),
                i({ uspString: "1---" }, !1));
          });
      }
    );
  }
  function pa(e) {
    var t = "https:".concat(e.url).concat(e.file);
    return e.query ? "".concat(t, "?").concat(e.query) : t;
  }
  var ba = function (e, t, n, i) {
      var r;
      e.logger[k]("[INIT]: Downloading library ".concat(t.name));
      var o = e.window.document.createElement("script");
      if (
        ((o.async = !0),
        (o.type = "text/javascript"),
        t.id && (o.id = t.id),
        t.attributes &&
          Object.keys(t.attributes).forEach(function (e) {
            o.setAttribute(e, t.attributes[e]);
          }),
        "function" == typeof n &&
          (o.readyState
            ? (o.onreadystatechange = function () {
                ("loaded" !== o.readyState && "complete" !== o.readyState) ||
                  ((o.onreadystatechange = null), n());
              })
            : (o.onload = function () {
                n();
              }),
          (o.onerror = function () {
            e.logger[E](
              "[INIT]: Failed to load library "
                .concat(t.name, " from ")
                .concat(o.src)
            ),
              "function" == typeof i && i();
          })),
        (o.src = pa(t)),
        t.insertSelector)
      ) {
        var a = e.window.document.querySelector(t.insertSelector);
        a
          ? a.appendChild(o)
          : e.logger[E](
              "[INIT]: Injection library "
                .concat(t.name, ". Element with selector ")
                .concat(t.insertSelector, " not found")
            );
      } else {
        var s = e.window.document.getElementsByTagName("script")[0];
        null === (r = s.parentNode) || void 0 === r || r.insertBefore(o, s);
      }
    },
    ha = Symbol();
  function ya(e, t, n) {
    return u({}, ha, function (i) {
      switch ((n[bi]("cmp_load_quantcast_start"), i.partner)) {
        case "quantcast":
          return (function () {
            e[C]("[CMP]: Loading Quantcast CMP provider");
            var n = t.document.location.hostname,
              i = t.document.createElement("script"),
              r = t.document.getElementsByTagName("script")[0],
              o =
                t.document.getElementsByTagName("head")[0] ||
                t.document.documentElement,
              a = "https://cmp.inmobi.com".concat(
                "/choice/",
                "PRrmquD1Ggcb1",
                "/",
                n,
                "/choice.js?tag_version=V3"
              ),
              s = new XMLHttpRequest();
            (s.onreadystatechange = function () {
              4 === this.readyState &&
                ((i.async = !0),
                (i.type = "text/javascript"),
                200 === this.status
                  ? (i.src = a)
                  : e[T](
                      "GET call to CMP script with "
                        .concat(n, " responded with the status code - ")
                        .concat(this.status)
                    ),
                (null == r ? void 0 : r.parentNode)
                  ? r.parentNode.insertBefore(i, r)
                  : (e[k](
                      "First script element not fully initialised, falling back to head-based insertion"
                    ),
                    o.insertBefore(i, o.firstChild)),
                e[C]("[CMP]: Added Quantcast script to document"));
            }),
              e[C]("[CMP]: Opening Quantcast URL"),
              s.open("GET", a, !0),
              s.send();
          })();
        case "cookiebot":
          return (
            (o = i.domainGroupId),
            e[C]("[CMP]: Loading Cookie Bot - ".concat(o)),
            void ba(
              { logger: e, window: t },
              {
                name: "CookieBot",
                url: "//consent.cookiebot.com/",
                file: "uc.js",
                insertSelector: "head",
                attributes: {
                  "data-cbid": o,
                  "data-blockingmode": "auto",
                  "data-framework": "IAB",
                },
              },
              function () {
                e[C]("[CMP]: Cookie Bot script loaded");
              }
            )
          );
        case "fundingchoices":
          return void e[C](
            "[CMP]: Funding Choices CMP provider selected no external script required"
          );
        case "consentmanager":
          return (
            (r = i.cdid),
            e[C]("[CMP]: Loading ConsentManager - ".concat(r)),
            void ba(
              { logger: e, window: t },
              {
                name: "ConsentManager",
                url: "//eu-us-apac-cdn.consentmanager.net/delivery/js/",
                file: "semiautomatic.min.js",
                insertSelector: "head",
                attributes: {
                  "data-cmp-ab": "1",
                  "data-cmp-cdid": r,
                  "data-cmp-host": "eu-us-apac.consentmanager.net",
                  "data-cmp-cdn": "eu-us-apac-cdn.consentmanager.net",
                  "data-cmp-codesrc": "0",
                },
              },
              function () {
                e[C]("[CMP]: ConsentManager script loaded");
              }
            )
          );
      }
      var r, o;
    });
  }
  var Sa = function (e) {
      return e.self !== e.top;
    },
    Ia = Symbol();
  function wa(e) {
    var t =
        arguments.length > 1 && void 0 !== arguments[1]
          ? arguments[1]
          : "div[data-fuse-privacy-tool]",
      n =
        arguments.length > 2 && void 0 !== arguments[2]
          ? arguments[2]
          : "fuse-privacy-tool";
    return u({}, Ia, function (i, r) {
      var o = e.document.querySelector(t);
      if (o)
        if (r) {
          var a = document.createElement("a");
          (a.href = "javascript:void(0)"),
            (a.id = n),
            (a.innerHTML = i),
            a.addEventListener("click", r),
            o.appendChild(a);
        } else o.textContent = i;
    });
  }
  function _a(e, t, n) {
    var i,
      r = Ea();
    t.addEventListener("message", function (t) {
      ka(e, t, n, r);
    });
    var o = {
      __tcfapiCall: { command: "addEventListener", version: 2, callId: r },
    };
    null === (i = t.top) || void 0 === i || i.postMessage(o, "*");
  }
  var Ea = function () {
      return "undefined" != typeof crypto &&
        "function" ==
          typeof (null === crypto || void 0 === crypto
            ? void 0
            : crypto.randomUUID)
        ? crypto.randomUUID()
        : ""
            .concat(Date.now(), "-")
            .concat(Math.random().toString(36).slice(2));
    },
    ka = function (e, t, n, i) {
      try {
        var r = ("string" == typeof t.data ? JSON.parse(t.data) : t.data)
          .__tcfapiReturn;
        if ((null == r ? void 0 : r.callId) === i && r.returnValue) {
          var o = r.returnValue;
          n(null != o ? o : null, Boolean(o));
        }
      } catch (n) {
        e[C](
          "[CMP-UTILS]: Error parsing TCF API message from origin ".concat(
            t.origin
          )
        );
      }
    },
    Ca = function (e, t) {
      var n, i, r;
      return (
        (null ===
          (i =
            null === (n = t.purpose) || void 0 === n ? void 0 : n.consents) ||
        void 0 === i
          ? void 0
          : i[e]) ||
        (null === (r = t.purposeConsents) || void 0 === r ? void 0 : r[e])
      );
    },
    Ta = function (e, t) {
      var n, i;
      return Boolean(
        Ca(e, t) ||
          (null ===
            (i =
              null === (n = t.purpose) || void 0 === n
                ? void 0
                : n.legitimateInterests) || void 0 === i
            ? void 0
            : i[e])
      );
    },
    Aa = (function () {
      return a(
        function e(t, n, i) {
          r(this, e),
            (this.logger = t),
            (this.consentUIPrompt = i),
            (this.callCount = -1),
            (this.uspTries = 0),
            (this.uspTriesLimit = 3),
            (this.browserWindow = n),
            this.createUspStub();
        },
        [
          {
            key: "cmpLoaded",
            value: function (e) {
              var t = !1;
              setTimeout(function () {
                if (!t) return e(!1);
              }, 1e3),
                this.browserWindow.__tcfapi("ping", 2, function (n) {
                  return (
                    (t = !0), (null == n ? void 0 : n.cmpLoaded) ? e(!0) : e(!1)
                  );
                });
            },
          },
          {
            key: "setGDPRConsentPrompt",
            value: function () {
              var e = this;
              this.consentUIPrompt[Ia]("Privacy Settings", function () {
                e.browserWindow.__tcfapi("displayConsentUi", 2, function () {
                  return e.logger[C]("[CMP-V2]: GDPR Consent UI displayed");
                });
              });
            },
          },
          {
            key: "setCCPAConsentPrompt",
            value: function () {
              var e = this;
              this.consentUIPrompt[Ia]("Do Not Sell My Data", function () {
                e.browserWindow.__uspapi("displayUspUi");
              });
            },
          },
          {
            key: "checkForCCPA",
            value: function (e) {
              var t = this;
              if (this.browserWindow.googlefc || this.browserWindow.Cookiebot)
                return (
                  this.logger[C](
                    "[CMP-v2]: Checking CCPA with cookiebot/funding choices"
                  ),
                  this.handleNonInmobiCCPA(e)
                );
              this.browserWindow.__uspapi("uspPing", 1, function (n, i) {
                i &&
                n.mode.includes("USP") &&
                n.jurisdiction.includes(n.location.toUpperCase())
                  ? (t.logger[C]("[CMP-V2]: CCPA Region"),
                    t.browserWindow.__uspapi(
                      "setUspDftData",
                      1,
                      function (n, i) {
                        t.logger[C](function () {
                          return "[CMP-V2]: Setting up data for USP API "
                            .concat(JSON.stringify(n), " ")
                            .concat(i);
                        }),
                          t.browserWindow.__uspapi(
                            "getUSPData",
                            1,
                            function (n, i) {
                              if (!i)
                                return (
                                  t.logger[C](
                                    "[CMP-V2]: Failed retrieving USP data use default instead"
                                  ),
                                  e({ applies: !0, privacyString: "1---" })
                                );
                              e({ applies: !0, privacyString: n.uspString });
                            }
                          );
                      }
                    ))
                  : e({ applies: !1 });
              });
            },
          },
          {
            key: "handleNonInmobiCCPA",
            value: function (e) {
              var t,
                n,
                i = this;
              Boolean(
                (null === (t = this.browserWindow.googlefc) || void 0 === t
                  ? void 0
                  : t.ccpa) ||
                  (null === (n = this.browserWindow.Cookiebot) || void 0 === n
                    ? void 0
                    : n.regulations.ccpaApplies)
              )
                ? this.browserWindow.__uspapi("getUSPData", 1, function (t, n) {
                    if (!n)
                      return (
                        i.logger[C](
                          "[CMP-V2]: Failed retrieving USP data use default instead"
                        ),
                        e({ applies: !0, privacyString: "1---" })
                      );
                    e({ applies: !0, privacyString: t.uspString });
                  })
                : e({ applies: !1 });
            },
          },
          {
            key: "handleGdprApplies",
            value: function (e, t) {
              var n = e.eventStatus.toLowerCase();
              if ("useractioncomplete" === n || "tcloaded" === n) {
                var i = Ca(1, e),
                  r = Ca(3, e),
                  o = Ca(4, e),
                  a = Ta(2, e),
                  s = Ta(7, e),
                  c = Ta(9, e),
                  u = Ta(10, e),
                  l = !re(i),
                  d = !re(r),
                  f = !re(o),
                  g = l && d && f,
                  m = g && i && r && o && a && s && c && u;
                return (
                  this.logger[k](function () {
                    return "[CMP-V2]: Consents available: "
                      .concat(g, ", Consent: ")
                      .concat(m, " Data: ")
                      .concat(JSON.stringify(e));
                  }),
                  t({
                    dataAvailable: !0,
                    gdprChoiceReceived: !0,
                    personalisedAdsConsent: m,
                    gdprApplies: !0,
                    cmpStatus: null == e ? void 0 : e.cmpStatus,
                    eventStatus: null == e ? void 0 : e.eventStatus,
                    tcData: e,
                  })
                );
              }
              return (
                "cmpuishown" === n ||
                  (this.callCount % 8 == 0 &&
                    this.logger[E](function () {
                      return "[CMP-V2]: Unexpected eventStatus. Data: ".concat(
                        JSON.stringify(e)
                      );
                    })),
                t({
                  dataAvailable: !0,
                  gdprChoiceReceived: !1,
                  gdprApplies: !0,
                  cmpStatus: null == e ? void 0 : e.cmpStatus,
                  eventStatus: null == e ? void 0 : e.eventStatus,
                })
              );
            },
          },
          {
            key: "createUspStub",
            value: function () {
              var e = this,
                t = this.logger,
                n = this.browserWindow,
                i = function () {
                  for (
                    var e = arguments.length, n = new Array(e), i = 0;
                    i < e;
                    i++
                  )
                    n[i] = arguments[i];
                  t[E](
                    "[CMP-V2] USP is still in stub mode. Calling to ".concat(
                      n[0],
                      " API will be unsuccessful"
                    )
                  ),
                    "function" == typeof n[2] && n[2](void 0, !1);
                };
              if (void 0 === n.__uspapi) {
                n.__uspapi = i;
                var r = setInterval(function () {
                  e.uspTries++,
                    n.__uspapi !== i
                      ? (t[k]("[CMP-V2]: USP stub function has been replaced"),
                        clearInterval(r))
                      : e.uspTries < e.uspTriesLimit
                      ? t[k](
                          "[CMP-V2]: USP stub function has NOT been replaced, will retry"
                        )
                      : (t[E](
                          "[CMP-V2]: USP stub function has NOT been replaced, but the timeout has been reached"
                        ),
                        clearInterval(r));
                }, 300);
              }
            },
          },
        ]
      );
    })(),
    Ra = (function (e) {
      function t(e, n, o, a) {
        var s;
        return (
          r(this, t),
          ((s = i(this, t, [e, n, o])).logger = e),
          (s.consentUIPrompt = o),
          (s.allowTopFrameCheck = a),
          (s.tcData = null),
          Sa(n) && a
            ? (s.logger[C]("[CMP-V2.2]: TCF v2.2 running inside an iframe"),
              _a(e, n, s.handleTCEvent.bind(s)))
            : (s.logger[C]("[CMP-V2.2]: TCF v2.2 running in top window"),
              s.browserWindow.__tcfapi(
                "addEventListener",
                2,
                s.handleTCEvent.bind(s)
              )),
          s
        );
      }
      return (
        f(t, e),
        a(t, [
          {
            key: "getConsentData",
            value: function (e) {
              var t,
                n,
                i,
                r,
                o,
                a,
                s,
                c = this;
              return (
                this.callCount++,
                this.tcData
                  ? re(this.tcData.gdprApplies) ||
                    "loading" ===
                      (null ===
                        (n =
                          null === (t = this.tcData) || void 0 === t
                            ? void 0
                            : t.cmpStatus) || void 0 === n
                        ? void 0
                        : n.toLowerCase()) ||
                    (this.tcData.gdprApplies &&
                      re(
                        null === (i = this.tcData) || void 0 === i
                          ? void 0
                          : i.eventStatus
                      ))
                    ? (this.logger[C]("[CMP-V2.2]: GDPR not yet determined"),
                      e({
                        dataAvailable: !0,
                        gdprApplies: void 0,
                        cmpStatus:
                          null === (r = this.tcData) || void 0 === r
                            ? void 0
                            : r.cmpStatus,
                        eventStatus:
                          null === (o = this.tcData) || void 0 === o
                            ? void 0
                            : o.eventStatus,
                      }))
                    : !1 === this.tcData.gdprApplies
                    ? e({
                        dataAvailable: !0,
                        gdprApplies: !1,
                        cmpStatus:
                          null === (a = this.tcData) || void 0 === a
                            ? void 0
                            : a.cmpStatus,
                        eventStatus:
                          null === (s = this.tcData) || void 0 === s
                            ? void 0
                            : s.eventStatus,
                      })
                    : !0 === this.tcData.gdprApplies
                    ? this.handleGdprApplies(this.tcData, e)
                    : void this.logger[E](function () {
                        return "[CMP-V2.2]: Unexpected gdprApplies status. Data: ".concat(
                          JSON.stringify(c.tcData)
                        );
                      })
                  : (this.logger[C]("[CMP-V2.2]: TCData not yet set"),
                    e({
                      dataAvailable: !1,
                      cmpStatus: void 0,
                      eventStatus: void 0,
                    }))
              );
            },
          },
          {
            key: "handleTCEvent",
            value: function (e, t) {
              t && e
                ? (this.logger[C]("[CMP-V2.2]: TCF event listener triggered"),
                  (this.tcData = Object.assign({}, e)))
                : this.logger[C](function () {
                    return "[CMP-V2.2]: TCF event listener failed - success "
                      .concat(t, " - tcData ")
                      .concat(JSON.stringify(e));
                  });
            },
          },
        ])
      );
    })(Aa),
    xa = Symbol();
  function Pa(e, t, n, i, r, o, a) {
    var s = void 0,
      c = e,
      l = 0,
      d = !1;
    function f(e) {
      var i = e.found,
        o = e.versionNumber;
      ae(s)
        ? t[E]("[CMP]: Version already loaded: ".concat(o))
        : i
        ? 2 === o
          ? (n[bi]("cmp_load_wait_finish"),
            n[ui](),
            t[k]("[CMP]: Loaded version ".concat(o)),
            t[C]("[CMP]: Using TCF v2.2"),
            (s = new Ra(t, c, r, !a.isIframeCmp())),
            (function () {
              t[A]("[CMP]: Checking if the GDPR applies"),
                n[bi]("cmp_gdpr_applies_check_start");
              var e = function (e, i) {
                n[bi]("cmp_gdpr_applies_check_finish"),
                  !1 === e
                    ? (function () {
                        t[A]("[CMP]: GDPR does not apply");
                        var e = !1,
                          i = !1;
                        setTimeout(function () {
                          i ||
                            ((i = !0),
                            n[bi]("cmp_check_for_ccpa_timeout"),
                            t[E](
                              "[CMP]: USP API is not responding, continue as if not in CCPA region"
                            ),
                            v("none", !0, !0));
                        }, 2e3),
                          n[bi]("cmp_check_for_ccpa_start"),
                          (o = function (o) {
                            var a = o.applies,
                              c = o.privacyString;
                            i
                              ? t[E](
                                  "[CMP]: Got CCPA response, but timeout already reached"
                                )
                              : ((i = !0),
                                n[bi]("cmp_check_for_ccpa_finish"),
                                a
                                  ? (null == s || s.setCCPAConsentPrompt(),
                                    (e =
                                      "Y" ===
                                      (null == c
                                        ? void 0
                                        : c[2].toUpperCase())),
                                    t[A](
                                      "[CMP]: CCPA applies. disablePersonalisation: ".concat(
                                        e
                                      )
                                    ),
                                    v("ccpa", !e, !1))
                                  : (t[A](
                                      "[CMP]: Not in CCPA region, continue with personalisation"
                                    ),
                                    r[Ia](
                                      "You are outside the CCPA jurisdiction."
                                    ),
                                    v("none", !0, !1)));
                          }),
                          null == s || s.checkForCCPA(o);
                        var o;
                      })()
                    : a.isRequestGdprPersonalisation()
                    ? (function () {
                        t[C](
                          "[CMP]: GDPR applies, checking if personalisation is allowed"
                        ),
                          n[bi]("cmp_gdpr_choice_wait_start"),
                          null == s || s.setGDPRConsentPrompt();
                        var e = !1;
                        m(function (i) {
                          var r = i.gdprChoiceReceived,
                            o = i.personalisedAdsConsent,
                            a = i.tcData;
                          if (
                            (r &&
                              ((e = !0),
                              n[bi]("cmp_gdpr_choice_wait_finish"),
                              t[A](
                                "[CMP]: GDPR decision received via short-circuit. Allow personalisation: ".concat(
                                  o
                                )
                              ),
                              v("gdpr", Boolean(o), !1, a)),
                            !e)
                          ) {
                            (d = !0), n[bi]("cmp_prompt_shown");
                            var s = 0,
                              c = setInterval(function () {
                                m(function (i) {
                                  var r = i.gdprChoiceReceived,
                                    o = i.personalisedAdsConsent,
                                    a = i.cmpStatus,
                                    u = i.eventStatus,
                                    l = i.tcData;
                                  r
                                    ? ((e = !0),
                                      n[bi]("cmp_gdpr_choice_wait_finish"),
                                      t[A](
                                        "[CMP]: GDPR decision received. Allow personalisation: ".concat(
                                          o
                                        )
                                      ),
                                      clearInterval(c),
                                      v("gdpr", Boolean(o), !1, l))
                                    : ++s % 10 == 0 &&
                                      t[A](
                                        "[CMP]: Waiting for GDPR personalisation choice. cmpStatus: "
                                          .concat(a, ", eventStatus: ")
                                          .concat(u)
                                      );
                                });
                              }, 100);
                          }
                        });
                      })()
                    : (n[bi]("cmp_gdpr_choice_wait_finish"),
                      t[A](
                        "[CMP]: The GDPR applies, but we will assume they do not allow personalisation (show limited ads)"
                      ),
                      v("gdpr", !1, !1, i));
              };
              m(function (n) {
                var i = n.gdprApplies,
                  r = n.tcData;
                if (re(i)) {
                  var o = 250,
                    a = 0;
                  t[k]("[CMP]: Setting a check interval of ".concat(o, "ms"));
                  var s = !1,
                    c = setInterval(function () {
                      m(function (n) {
                        var i = n.gdprApplies,
                          r = n.tcData;
                        re(i)
                          ? a++ % 4 == 0 &&
                            t[A]("[CMP]: Waiting for GDPR determination")
                          : (clearInterval(c), s || ((s = !0), e(i, r)));
                      });
                    }, o);
                } else
                  t[k](
                    "[CMP]: GDPR status already available, processing immediately"
                  ),
                    e(i, r);
              });
            })())
          : (t[T](
              "[CMP]: Version ".concat(
                o,
                " is not supported, disabling personalisation"
              )
            ),
            v("none", !0, !0))
        : (++l % 10 == 0 && t[k]("[CMP] Waiting for load"),
          setTimeout(function () {
            return g();
          }, 50));
    }
    function g() {
      return Sa(c) && !a.isIframeCmp()
        ? (t[C]("[CMP]: In an iframe, checking __tcfapi via iframe messaging"),
          void (function (e, t, n, i) {
            var r = Ea();
            t.addEventListener("message", function (t) {
              ka(e, t, n, r);
            });
            var o = {
              __tcfapiCall: {
                command: "ping",
                version: null,
                callId: r,
                parameter: i,
              },
            };
            t.top.postMessage(o, "*");
          })(t, c, function (e, n) {
            return (
              (n && e) || t[C]("[CMP]: __tcfapi ping via iframe failed"),
              f({
                found: Boolean(n && (null == e ? void 0 : e.cmpLoaded)),
                versionNumber: 2,
              })
            );
          }))
        : a.getCmpSkipStub() && !c.__tcfapi
        ? (t[C]("[CMP]: Stub function not setup yet"),
          f({ found: !1, versionNumber: 2 }))
        : void c.__tcfapi("ping", null, function (e, n) {
            var i = e.cmpLoaded;
            i &&
              c.Cookiebot &&
              !c.Cookiebot.userCountry &&
              (t[C](function () {
                return "[CMP]: CookieBot ping response when no user country: "
                  .concat(n, " - ")
                  .concat(JSON.stringify(e));
              }),
              (i = !1)),
              f({ found: i, versionNumber: 2 });
          });
    }
    function m(e) {
      null == s || s.getConsentData(e);
    }
    function v(e, i, r, s) {
      var c = o[Tr].cmp._tag;
      if (("gdpr" === e && n[gi](), "loading" == c)) {
        var u = {
          jurisdiction: e,
          timeout: r,
          allowPersonalisation: i,
          dialogShown: d,
          noCmpTestResult: a.isNoCmpTestMode() ? e : void 0,
          tcData: s,
        };
        t[A](function () {
          return "[CMP]: Determination: ".concat(JSON.stringify(u));
        });
        var l = n[ri]();
        o[Ar]("cmp", kr(o[Tr].cmp, l, u));
      } else t[T]("[CMP]: CMP in unexpected state: ".concat(c));
    }
    return u({}, xa, function () {
      o[Ar]("cmp", Er(n[ri]())),
        a.getCmpSkipStub()
          ? t[C]("[CMP]: Skipping stubs")
          : (i[fa](), a.getDisableGppStub() || i[ga]()),
        n[bi]("cmp_load_wait_start"),
        t[A]("[CMP]: Wait for CMP to load"),
        g();
    });
  }
  var Oa = {
      tcfeuv2: 2,
      tcfcav1: 5,
      uspv1: 6,
      usnat: 7,
      usca: 8,
      usva: 9,
      usco: 10,
      usut: 11,
      usct: 12,
      usfl: 13,
      usmt: 14,
      usor: 15,
      ustx: 16,
      usde: 17,
      usia: 18,
      usne: 19,
      usnh: 20,
      usnj: 21,
      ustn: 22,
      usmn: 23,
      usmd: 24,
      usin: 25,
      usky: 26,
      usri: 27,
    },
    Da = {
      NAT: [
        "PersonalDataConsents",
        "SharingOptOut",
        "SaleOptOut",
        "TargetedAdvertisingOptOut",
      ],
      CA: ["PersonalDataConsents", "SharingOptOut", "SaleOptOut"],
      CO_CT_VA: [
        "PersonalDataConsents",
        "SaleOptOut",
        "TargetedAdvertisingOptOut",
      ],
      FL: ["PersonalDataConsents", "SaleOptOut", "TargetedAdvertisingOptOut"],
    };
  function Na(e, t) {
    var n;
    return Boolean(
      null === (n = t.PurposeConsents) || void 0 === n ? void 0 : n[e]
    );
  }
  function za(e, t) {
    var n;
    return Boolean(
      Na(e, t) ||
        (null === (n = t.PurposeLegitimateInterests) || void 0 === n
          ? void 0
          : n[e])
    );
  }
  var Ba = function (e, t) {
    var n;
    return Boolean(
      null === (n = t.SpecialFeatureOptins) || void 0 === n ? void 0 : n[e]
    );
  };
  function Ma(e) {
    return e.applicableSections.includes(Oa.tcfeuv2);
  }
  function Ua(e) {
    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
      n = e.applicableSections;
    return t
      ? !n.includes(Oa.tcfeuv2) &&
          n.some(function (e) {
            return e >= Oa.uspv1;
          })
      : ![Oa.tcfeuv2, Oa.tcfcav1].includes(n[0]);
  }
  function ja(e) {
    var t = e.applicableSections,
      n = e.supportedAPIs,
      i = e.parsedSections;
    return (
      -1 === t[0] ||
      t.every(function (e) {
        var t = (function (e, t) {
          var n;
          return null ===
            (n = e
              .reduce(function (e, t) {
                return (
                  t.includes(",")
                    ? e.push.apply(
                        e,
                        y(
                          t.split(",").map(function (e) {
                            return e.trim();
                          })
                        )
                      )
                    : e.push(t),
                  e
                );
              }, [])
              .map(function (e) {
                return e.split(":");
              })
              .find(function (e) {
                return Number.parseInt(e[0]) === t;
              })) || void 0 === n
            ? void 0
            : n[1];
        })(n, e);
        return !t || t in i;
      })
    );
  }
  function La(e, t) {
    var n = Array.isArray(e) ? e[0] : e;
    return !t.some(function (e) {
      return 1 === n[e];
    });
  }
  function Fa(e) {
    return "string" == typeof e && "Y" === e.toUpperCase();
  }
  function Ga(e, t, n, i, r) {
    var o = arguments.length > 5 && void 0 !== arguments[5] && arguments[5];
    function a(t) {
      var i,
        r,
        a,
        s =
          null === (i = t.cmpStatus) || void 0 === i ? void 0 : i.toLowerCase(),
        u =
          null === (r = t.cmpDisplayStatus) || void 0 === r
            ? void 0
            : r.toLowerCase(),
        l =
          null === (a = t.signalStatus) || void 0 === a
            ? void 0
            : a.toLowerCase(),
        d = t.applicableSections,
        f = Ua(t, o),
        g = Ma(t);
      if ("loaded" === s) {
        if ("disabled" === u)
          return (
            e[A](
              "[CMP-GPP]: cmpDisplayStatus disabled. Processed/disabled GPP"
            ),
            c(t)
          );
        if ("ready" === l) {
          if (-1 === d[0])
            return (
              e[C]("[CMP-GPP]: Sections not applicable"),
              n({
                dataAvailable: !0,
                uspApplies: !1,
                gdprApplies: !1,
                cmpStatus: s,
                cmpDisplayStatus: u,
                signalStatus: l,
              })
            );
          if ("visible" === u)
            return (
              e[C]("[CMP-GPP]: CMP now displays the consent layer"),
              n({
                dataAvailable: !1,
                uspApplies: f,
                gdprApplies: g,
                cmpStatus: s,
                cmpDisplayStatus: u,
                signalStatus: l,
              })
            );
          if ("hidden" === u || "disabled" === u)
            return Ua(t, o) || ja(t)
              ? (e[C]("[CMP-GPP]: GPP determined"), c(t))
              : (e[C]("[CMP-GPP]: CMP not yet to displays the consent layer"),
                n({
                  dataAvailable: !0,
                  uspApplies: f,
                  gdprApplies: g,
                  cmpStatus: s,
                  cmpDisplayStatus: u,
                  signalStatus: l,
                }));
        }
        if ("not ready" === l)
          return void e[C](function () {
            return "[CMP-GPP]: Not ready status. Data: ".concat(
              JSON.stringify(t)
            );
          });
      }
      e[E](function () {
        return "[CMP-GPP]: Unexpected uspApplies status. Data: ".concat(
          JSON.stringify(t)
        );
      });
    }
    function s(t) {
      var n = !0,
        i = !0,
        a = (function (e) {
          var t,
            n,
            i,
            r = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
            o = e.applicableSections,
            a = e.parsedSections;
          if (r) {
            var s = new Set(
              Object.values(Oa).filter(function (e) {
                return e >= Oa.usnat;
              })
            );
            i =
              null !==
                (t = o.find(function (e) {
                  return s.has(e);
                })) && void 0 !== t
                ? t
                : o.find(function (e) {
                    return e === Oa.uspv1;
                  });
          } else -1 !== o[0] && (i = o[0]);
          if (void 0 !== i) {
            var c = Object.keys(Oa).find(function (e) {
              return Oa[e] === i;
            });
            if (c) {
              var u = "".concat(c, "v1");
              return {
                key: c,
                section: null !== (n = a[c]) && void 0 !== n ? n : a[u],
              };
            }
          }
        })(t, o);
      if (!a)
        return (
          e[C]("[CMP-GPP]: No applicable section found for US Privacy data"),
          { allowPersonalisation: n, consentsAvailable: i }
        );
      var s = a.key,
        c = a.section;
      if (!c)
        return (
          e[C]("[CMP-GPP]: No section found for US Privacy data"),
          { allowPersonalisation: n, consentsAvailable: i }
        );
      if (o && "uspv1" === s) {
        var u = (function (e) {
          for (var t = e, n = 0; n < 3 && Array.isArray(t); n++) t = t[0];
          if ("string" == typeof t) {
            if (t.length < 3) return;
            return !Fa(t[2]);
          }
          if (t && "object" === I(t) && !Array.isArray(t)) {
            var i = t.uspString;
            return "string" == typeof i && i.length >= 3
              ? !Fa(i[2])
              : !Fa(t.OptOutSale);
          }
        })(c);
        return (
          void 0 === u &&
            e[E](function () {
              return "[CMP-GPP]: Unparseable uspv1 payload (type: "
                .concat(I(c), ", array: ")
                .concat(Array.isArray(c), ")");
            }),
          (n = null == u || u),
          e[C](
            "[CMP-GPP]: uspv1 consent parsed. Allow personalisation: ".concat(n)
          ),
          { allowPersonalisation: n, consentsAvailable: i }
        );
      }
      switch (s) {
        case "usca":
          n = La(c, Da.CA);
          break;
        case "usfl":
          n = La(c, Da.FL);
          break;
        case "usco":
        case "usct":
        case "usva":
          n = La(c, Da.CO_CT_VA);
          break;
        default:
          n = La(c, "FL" === (null == r ? void 0 : r.state) ? Da.FL : Da.NAT);
      }
      return { allowPersonalisation: n, consentsAvailable: i };
    }
    function c(t) {
      var i,
        r,
        a,
        c = !0,
        u = !0,
        l = Ua(t, o),
        d = Ma(t);
      if (l) {
        var f = s(t);
        (c = f.allowPersonalisation), (u = f.consentsAvailable);
      } else if (d) {
        var g = (function (e) {
          var t,
            n = e.parsedSections.tcfeuv2,
            i = Array.isArray(n) ? n[0] : n,
            r = Na(1, i),
            o = Na(2, i),
            a = Na(3, i),
            s = Na(4, i),
            c = za(2, i),
            u = za(7, i),
            l = za(9, i),
            d = za(10, i);
          return {
            personalisedAdsConsent:
              (t = r && a && s) && r && a && s && c && u && l && d,
            consentsAvailable: t,
            purposeConsents: {
              storage: r,
              basicAds: o,
              personalizedAds: s,
              measurement: u,
              transmitPreciseGeo: Ba(1, i),
            },
          };
        })(t);
        (c = g.personalisedAdsConsent), (u = g.consentsAvailable);
      }
      return (
        e[k](function () {
          return "[CMP-GPP]: Consents available: "
            .concat(u, ", PersonalisedAds: ")
            .concat(c, ", Data: ")
            .concat(JSON.stringify(t));
        }),
        n({
          dataAvailable: !0,
          uspChoiceReceived: l,
          gdprChoiceReceived: d,
          personalisedAdsConsent: c,
          uspApplies: l,
          gdprApplies: d,
          cmpStatus:
            null === (i = t.cmpStatus) || void 0 === i
              ? void 0
              : i.toLowerCase(),
          cmpDisplayStatus:
            null === (r = t.cmpDisplayStatus) || void 0 === r
              ? void 0
              : r.toLowerCase(),
          signalStatus:
            null === (a = t.signalStatus) || void 0 === a
              ? void 0
              : a.toLowerCase(),
          gppString: t.gppString,
        })
      );
    }
    return (
      e[k]("[CMP-GPP]: Loading version"),
      t.__gpp("addEventListener", function (t, n) {
        var r;
        if ("eventName" in t) {
          if (
            "not ready" ===
            (null === (r = t.pingData.signalStatus) || void 0 === r
              ? void 0
              : r.toLowerCase())
          )
            return;
          switch (t.eventName) {
            case "listenerRegistered":
              n
                ? a(t.pingData)
                : e[C](function () {
                    return "[CMP-GPP]: GPP event listener failed - success "
                      .concat(n, " - evt ")
                      .concat(JSON.stringify(t));
                  });
              break;
            case "cmpDisplayStatus":
              "string" == typeof t.data &&
                (null == i || i(t.data.toLowerCase())),
                a(t.pingData);
              break;
            case "sectionChange":
            case "signalStatus":
              a(t.pingData);
              break;
            default:
              e[C](function () {
                return "[CMP-GPP]: GPP not processed event "
                  .concat(t.eventName, " ")
                  .concat(JSON.stringify(t));
              });
          }
        } else a(t);
      }),
      { type: "GPP" }
    );
  }
  var Va = function (e, t) {
      var n, i, r;
      return Boolean(
        (null ===
          (i =
            null === (n = t.purpose) || void 0 === n ? void 0 : n.consents) ||
        void 0 === i
          ? void 0
          : i[e]) ||
          (null === (r = t.purposeConsents) || void 0 === r ? void 0 : r[e])
      );
    },
    Ha = function (e, t) {
      var n, i;
      return Boolean(
        Va(e, t) ||
          (null ===
            (i =
              null === (n = t.purpose) || void 0 === n
                ? void 0
                : n.legitimateInterests) || void 0 === i
            ? void 0
            : i[e])
      );
    },
    qa = function (e, t) {
      var n;
      return Boolean(
        null === (n = t.specialFeatureOptins) || void 0 === n ? void 0 : n[e]
      );
    },
    Wa = "V2.2";
  function Za(e, t, n, i, r) {
    function o(o, a) {
      e[C](
        "[CMP-V2.2]: TCF event triggered success: "
          .concat(a, " ")
          .concat(o.eventStatus)
      ),
        a && o
          ? (e[C](function () {
              return "[CMP-V2.2]: TCF event listener triggered ".concat(
                JSON.stringify(o)
              );
            }),
            (function (o) {
              var a,
                s =
                  null === (a = o.eventStatus) || void 0 === a
                    ? void 0
                    : a.toLowerCase();
              if (o.gdprApplies) {
                if ("disabled" === o.cmpDisplayStatus)
                  return void e[A](
                    "[CMP-V2.2]: cmpDisplayStatus disabled. Not processing TCF"
                  );
                if ("useractioncomplete" === s || "tcloaded" === s) {
                  var c = (function (e) {
                      var t = Va(1, e),
                        n = Va(2, e),
                        i = Va(3, e),
                        r = Va(4, e),
                        o = Ha(2, e),
                        a = Ha(7, e),
                        s = Ha(9, e),
                        c = Ha(10, e),
                        u = t && i && r,
                        l = u && t && i && r && o && a && s && c;
                      return {
                        consentsAvailable: u,
                        personalisedAdsConsent: l,
                        purposeConsents: {
                          storage: t,
                          basicAds: n,
                          personalizedAds: r,
                          measurement: a,
                          transmitPreciseGeo: qa(1, e),
                        },
                      };
                    })(o),
                    u = c.consentsAvailable,
                    l = c.personalisedAdsConsent,
                    d = c.purposeConsents;
                  return (
                    e[k](function () {
                      return "[CMP-V2.2]: Consents available: "
                        .concat(u, ", Consent: ")
                        .concat(l, " Purpose: ")
                        .concat(JSON.stringify(d), " Data: ")
                        .concat(JSON.stringify(o));
                    }),
                    n({
                      dataAvailable: !0,
                      gdprChoiceReceived: !0,
                      personalisedAdsConsent: l,
                      gdprApplies: !0,
                      cmpStatus: null == o ? void 0 : o.cmpStatus,
                      eventStatus: null == o ? void 0 : o.eventStatus,
                      tcData: o,
                    })
                  );
                }
                if ("cmpuishown" === s)
                  i("visible"),
                    n({
                      dataAvailable: !0,
                      gdprChoiceReceived: !1,
                      gdprApplies: !0,
                      cmpStatus: null == o ? void 0 : o.cmpStatus,
                      eventStatus: null == o ? void 0 : o.eventStatus,
                    });
              } else {
                var f =
                  "US" === (null == r ? void 0 : r.country) &&
                  "CA" === (null == r ? void 0 : r.state);
                if ((e[A]("[CMP-V2.2]: GDPR not applies. CCPA geo:", f), !f))
                  return n({
                    dataAvailable: !0,
                    gdprChoiceReceived: !1,
                    gdprApplies: !1,
                    cmpStatus: null == o ? void 0 : o.cmpStatus,
                    eventStatus: null == o ? void 0 : o.eventStatus,
                  });
                !(function (n) {
                  t.__uspapi("getUSPData", 1, function (t, i) {
                    return i
                      ? (e[A]("[CMP-V2.2] USP String:", t.uspString),
                        n(t.uspString))
                      : (e[E]("[CMP-V2.2] Could not retrieve USP data"),
                        n("1---"));
                  });
                })(function (e) {
                  var t = "1---" !== e,
                    i = t && "Y" === (null == e ? void 0 : e[2].toUpperCase());
                  return n({
                    dataAvailable: !0,
                    gdprChoiceReceived: !1,
                    gdprApplies: !1,
                    uspApplies: t,
                    uspChoiceReceived: t,
                    personalisedAdsConsent: !i,
                    cmpStatus: null == o ? void 0 : o.cmpStatus,
                    eventStatus: null == o ? void 0 : o.eventStatus,
                  });
                });
              }
            })(o))
          : e[C](function () {
              return "[CMP-V2.2]: TCF event listener failed - success "
                .concat(a, " - tcData ")
                .concat(JSON.stringify(o));
            });
    }
    return (
      e[C]("[CMP-".concat(Wa, "]: Loading")),
      Sa(t)
        ? (e[C](
            "[CMP-".concat(
              Wa,
              "]: Running inside an iframe, will attempt to get TCData from top frame"
            )
          ),
          _a(e, t, function (e, t) {
            o(e, Boolean(t && e));
          }))
        : t.__tcfapi("addEventListener", 2, o),
      { type: Wa }
    );
  }
  function Ja(e, t, n, i, r, o, a, s) {
    var c,
      l = e,
      d = 0,
      f = 0,
      g = 0,
      m = !1,
      v = !1,
      p = a.getFuseGeo(),
      b =
        null === (c = a.getCmpProvider()) || void 0 === c ? void 0 : c.partner,
      h = a.getCmpDeterminedSampleRate() > 0,
      y = 1e5,
      S = a.isGppEnabled();
    function I() {
      t[A]("[CMP]: Setting default determination upon timeout"),
        _() ? O("usp", !0, !0) : E() ? O("gdpr", !1, !0) : O("none", !0, !0);
    }
    function w(i) {
      var r = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
      if (
        (t[A](
          "[CMP]: Waiting for CMP parts to be ready: useTimeouts="
            .concat(h, ", skipGppCheck=")
            .concat(r)
        ),
        Sa(e))
      )
        return (
          t[A](
            "[CMP]: Detected iframe environment, skipping stub checks and proceeding to check CMP directly"
          ),
          i(!1)
        );
      var o = setInterval(function () {
        if (
          (++d % 10 == 0 && t[k]("[CMP][STUB] Waiting for load ".concat(d)),
          h && d > 400)
        )
          return (
            clearInterval(o),
            n[li](y),
            t[T]("[CMP][STUB]: Timeout waiting for stubs to load"),
            void I()
          );
        if (S && !r && l.__gpp) {
          t[A]("[CMP]: GPP detected"), clearInterval(o), n[li](50 * d);
          var e = setInterval(function () {
            if (
              (++f % 10 == 0 && t[k]("[CMP][GPP] Waiting for load ".concat(f)),
              h && f > 400)
            )
              return (
                n[fi](y),
                clearInterval(e),
                t[T](
                  "[CMP][GPP]: Timeout waiting for GPP to load, falling back to TCF"
                ),
                (d = 0),
                void w(i, !0)
              );
            l.__gpp("ping", function (t) {
              var r,
                o,
                a = t;
              "loaded" ===
                (null === (r = a.cmpStatus) || void 0 === r
                  ? void 0
                  : r.toLowerCase()) &&
                "ready" ===
                  (null === (o = a.signalStatus) || void 0 === o
                    ? void 0
                    : o.toLowerCase()) &&
                (n[fi](50 * f), clearInterval(e), i(!0));
            });
          }, 50);
        } else if (l.__tcfapi) {
          t[A]("[CMP]: TCF detected"), clearInterval(o), n[li](50 * d);
          var a = setInterval(function () {
            if (
              (++g % 10 == 0 && t[k]("[CMP][TCF] Waiting for load ".concat(g)),
              h && g > 400)
            )
              return (
                n[di](y),
                clearInterval(a),
                t[T]("[CMP][TCF]: Timeout waiting for TCF to load"),
                void I()
              );
            l.__tcfapi("ping", 2, function (e) {
              e.cmpLoaded && (n[di](50 * g), clearInterval(a), i(!1));
            });
          }, 50);
        }
      }, 50);
    }
    t[A](
      "[CMP]: "
        .concat(b, " - GPP: ")
        .concat(S, ", geo country: ")
        .concat(null == p ? void 0 : p.country)
    );
    var _ = function () {
        return "US" === (null == p ? void 0 : p.country);
      },
      E = function () {
        return "EU-GDPR" === (null == p ? void 0 : p.code);
      };
    function R() {
      if (
        (n[bi]("cmp_load_wait_start"),
        a.useCmpGeoDetermination() &&
          p &&
          (t[A]("[CMP]: Using geo-based determination"), !_() && !E()))
      )
        return (
          t[A](
            "[CMP]: Geo does not indicate GDPR or USP jurisdiction, setting CMP determination to none"
          ),
          void O("none", !0, !1)
        );
      w(function (e) {
        e ? Ga(t, l, P, x, p, a.isGppUspv1Enabled()) : Za(t, l, P, x, p);
      });
    }
    function x(e) {
      "visible" === e &&
        ((m = !0),
        t[A]("[CMP]: Consent dialog is visible"),
        n[bi]("cmp_prompt_shown")),
        "hidden" === e &&
          (t[A]("[CMP]: Consent dialog is hidden"), n[bi]("cmp_prompt_hidden"));
    }
    function P(e) {
      t[k](function () {
        return "[CMP]: Consent data received ".concat(JSON.stringify(e));
      });
      var i = e.uspApplies,
        o = e.gdprApplies,
        a = e.uspChoiceReceived,
        s = e.gdprChoiceReceived,
        c = e.personalisedAdsConsent,
        u = e.gppString,
        d = e.tcData,
        f = e.purposeConsents;
      if (!i && !o)
        return (
          t[A]("[CMP]: Neither GDPR nor USP applies"), void O("none", !0, !1)
        );
      o &&
        (v ||
          ((v = !0),
          t[A]("[CMP]: Setting up GDPR consent prompt"),
          r[Ia]("Privacy Settings", function () {
            l.__tcfapi("displayConsentUi", 2, function () {
              return t[C]("[CMP-V2]: GDPR Consent UI displayed");
            });
          }))),
        i &&
          (v ||
            ((v = !0),
            r[Ia]("Do Not Sell My Data", function () {
              l.__uspapi("displayUspUi");
            }))),
        s &&
          (n[bi]("cmp_gdpr_choice_wait_finish"),
          t[A](
            "[CMP]: GDPR decision received. Allow personalisation: ".concat(c)
          ),
          O("gdpr", Boolean(c), !1, u, d, f)),
        a &&
          (n[bi]("cmp_usp_choice_wait_finish"),
          t[A](
            "[CMP]: USP decision received. Allow personalisation: ".concat(c)
          ),
          O("usp", Boolean(c), !1, u, d, f));
    }
    function O(e, i, r, c, u, l) {
      var d,
        f,
        g = o[Tr].cmp._tag;
      if (
        ("gdpr" === e && n[gi](),
        "usp" === e && n[mi](),
        "loading" == g || "ready" == g)
      ) {
        var v = {
          jurisdiction: e,
          allowPersonalisation: i,
          timeout: r,
          dialogShown: m,
          noCmpTestResult: a.isNoCmpTestMode() ? e : void 0,
          gppString: c,
          tcData: u,
          purposeConsents: l,
        };
        if (
          (t[A](function () {
            return "[CMP]: Determination: "
              .concat(g, " ")
              .concat(null == u ? void 0 : u.eventStatus, " ")
              .concat(JSON.stringify(v));
          }),
          "loading" == g)
        ) {
          var p = n[ri]();
          o[Ar]("cmp", kr(o[Tr].cmp, p, v)), s[Zt].emit(v);
        } else
          "ready" == g &&
            o[Ar](
              "cmp",
              ((d = o[Tr].cmp),
              (f = v),
              Object.assign(Object.assign({}, d), { output: f }))
            );
        s[Gt].emit({ allowPersonalisation: i, jurisdiction: e });
      } else t[T]("[CMP]: CMP in unexpected state: ".concat(g));
    }
    return u({}, xa, function () {
      o[Ar]("cmp", Er(n[ri]())),
        a.getCmpSkipStub()
          ? t[C]("[CMP]: Skipping stubs")
          : (i[fa](), a.getDisableGppStub() || i[ga](), i[ma]()),
        R();
    });
  }
  var Qa = Symbol();
  function Ka(e, t) {
    var n = t,
      i = t.document.referrer ? new URL(t.document.referrer).origin : "",
      r = {
        cmpStatus: "loaded",
        eventStatus: "tcloaded",
        tcfPolicyVersion: 2,
        cmpVersion: 44,
        cmpId: 10,
      },
      o = 1,
      a = {};
    return u({}, Qa, function () {
      (n.__tcfapi = function (t, n, i, s) {
        switch (t) {
          case "ping":
            return (function (e) {
              var t = {
                cmpLoaded: !0,
                cmpStatus: r.cmpStatus,
                cmpVersion: r.cmpVersion,
                displayStatus: "disabled",
                apiVersion: "2",
                cmpId: r.cmpId,
                gdprApplies: r.gdprApplies,
              };
              e(t);
            })(i);
          case "getTCData":
            return (function (e) {
              e(Object.assign({}, r), !0);
            })(i);
          case "addEventListener":
            return (function (t) {
              e[C]("[CMP]: Adding Event Listener. Listener ID: ".concat(o)),
                (a["".concat(o)] = t);
              var n = Object.assign(Object.assign({}, r), { listenerId: o });
              return o++, t(n, !0);
            })(i);
          case "removeEventListener":
            return (
              "number" == typeof s &&
                (e[C]("[CMP]: Removing Event Listener ID: ".concat(s)),
                delete a["".concat(s)]),
              i(Object.assign({}, r), !0)
            );
          default:
            return e[C]("[CMP]: Unsupported command: ".concat(t)), i({}, !1);
        }
      }),
        n.addEventListener("message", function (t) {
          var n;
          if (i && t.origin !== i)
            e[C]("[CMP]: Ignoring message from origin ".concat(t.origin));
          else {
            if ("set-tc-data" === t.data.type) {
              r = Object.assign({}, t.data.data);
              var o = ["tcloaded", "useractioncomplete"].includes(r.eventStatus)
                ? "tcloaded"
                : r.eventStatus;
              return (
                e[C](
                  "[CMP]: Calling event listeners with event status ".concat(o)
                ),
                void Object.entries(a).forEach(function (e) {
                  var t = b(e, 2),
                    n = t[0];
                  (0,
                  t[1])(Object.assign(Object.assign({}, r), { listenerId: parseInt(n, 10), eventStatus: o }), !0);
                })
              );
            }
            e[C](
              "[CMP]: unknown iframe message: ".concat(
                null === (n = t.data) || void 0 === n ? void 0 : n.type
              )
            );
          }
        });
    });
  }
  var Xa = Symbol(),
    $a = Symbol(),
    es = Symbol(),
    ts = Symbol(),
    ns = Symbol();
  function is(e, t, n, i, r, o, a, s) {
    return a.isCmpV2Enabled()
      ? Ja(e, t, n, i, r, o, a, s)
      : Pa(e, t, n, i, r, o, a);
  }
  var rs = M()(function (e) {
    return e
      .register(Xa, [L, j], va)
      .register($a, [L, j, na], ya)
      .register(es, [j], wa)
      .register(ns, [L, j], Ka)
      .register(ts, [j, L, na, Xa, es, ra, $i, Kt], is)
      .export();
  });
  function os(e) {
    return (function (e) {
      return e instanceof Error;
    })(e)
      ? e
      : new Error(String(e));
  }
  function as(e) {
    return Nn(e, e[Tn].events[wt], function (e) {
      return !e.crossedBp;
    });
  }
  var ss = Symbol(),
    cs = Symbol(),
    us = Symbol(),
    ls = Symbol(),
    ds = Symbol(),
    fs = Symbol(),
    gs = Symbol();
  function ms() {
    return u(
      u(u({}, _n, "AlwaysFalse"), kn, function () {
        return !1;
      }),
      En,
      function (e) {
        return [];
      }
    );
  }
  var vs = Symbol();
  function ps(e) {
    return u(
      u(u(u({}, _n, "AndCondition"), vs, e), En, function (e) {
        return [];
      }),
      kn,
      function () {
        return e.reduce(function (e, t) {
          return e && t[ls]();
        }, !0);
      }
    );
  }
  function bs(e) {
    return u(
      u(u(u({}, _n, "OrCondition"), vs, e), En, function (e) {
        return [];
      }),
      kn,
      function () {
        return e.reduce(function (e, t) {
          return e || t[ls]();
        }, !1);
      }
    );
  }
  function hs(e, t, n, i, r) {
    var o = !1;
    function a(a) {
      if (!o) {
        try {
          o = t[kn](e, n);
        } catch (n) {
          var s = os(n);
          return (
            r[E](
              "[CONDITION]["
                .concat(t[_n], "][")
                .concat(e, "]: Caught exception while checking condition"),
              s.message,
              s.stack
            ),
            !1
          );
        }
        o && a && i();
      }
      return o;
    }
    function s(e, t) {
      var n = e[cs];
      if ("AndCondition" === n[_n] || "OrCondition" === n[_n])
        n[vs].forEach(function (e) {
          return s(e, t);
        });
      else
        try {
          t(e);
        } catch (t) {
          var i = os(t);
          r[E](
            "[CONDITION]["
              .concat(n[_n], "][")
              .concat(e[ss], "]: Caught exception while visiting condition:"),
            i.message,
            i.stack
          );
        }
    }
    var c = u(
      u(
        u(
          u(u(u({}, ss, e), cs, t), ls, function () {
            return a(!1);
          }),
          ds,
          a
        ),
        fs,
        function () {
          return s(c, function (e) {
            e[us] &&
              e[us].forEach(function (e) {
                e[xn]();
              });
          });
        }
      ),
      gs,
      function (e) {
        return s(c, function (t) {
          var n = t[cs],
            i = u(u(u(u({}, Cn, t[ss]), Tn, e), An, r), Rn, function () {
              return t[ds](!0);
            });
          t[us] = [].concat(y(n[En](i)), [as(i)]);
        });
      }
    );
    return c;
  }
  var ys = Symbol(),
    Ss = Symbol(),
    Is = Symbol(),
    ws = Symbol();
  var _s = Symbol();
  function Es(e, t) {
    var n = {
        AlwaysTrue: function () {
          return u(
            u(u({}, _n, "AlwaysTrue"), kn, function () {
              return !0;
            }),
            En,
            function (e) {
              return [];
            }
          );
        },
        AlwaysFalse: function () {
          return ms();
        },
      },
      i = {};
    function r(t, r, s, c) {
      var u = r.type;
      switch (u) {
        case "and":
          return a(t, r, s, c, function (e) {
            return ps(e);
          });
        case "or":
          return a(t, r, s, c, function (e) {
            return bs(e);
          });
        case "condition":
        case "custom-condition":
          return (function (t, r, a, s) {
            var c,
              u = n[r.name];
            if (u) return hs(t, u(), a, s, e);
            var l = i[r.name];
            if (!l)
              return (
                e[T](
                  "[CONDITION-FACTORY]: Could not find condition ".concat(
                    r.name,
                    ", it will be deemed false"
                  )
                ),
                o(t, a, s)
              );
            var d = l(null !== (c = r.params) && void 0 !== c ? c : {}, e);
            return hs(t, d, a, s, e);
          })(t, r, s, c);
        default:
          ce(u);
      }
    }
    function o(t, n, i) {
      return hs(t, ms(), n, i, e);
    }
    function a(t, n, i, a, s) {
      var c = n.subConditions;
      if (!c || 0 === c.length)
        return (
          e[T]("[CONDITION-FACTORY]: Boolean condition with no sub-conditions"),
          o(t, i, a)
        );
      var u = s(
        c.map(function (e) {
          return r(t, e, i, a);
        })
      );
      return hs(t, u, i, a, e);
    }
    return (
      Object.entries(t).forEach(function (e) {
        var t = b(e, 2);
        !(function (e, t) {
          if (i[e])
            throw new Error("Condition with ".concat(e, " already registered"));
          i[e] = t;
        })(t[0], t[1]);
      }),
      u({}, _s, function (t, n, i, o) {
        var a,
          s = r(n, t, i, function () {
            return a[ws]();
          });
        return (
          (a = (function (e, t, n, i, r) {
            var o = !1;
            return u(
              u(
                u(
                  u({}, ys, function () {
                    n[gs](i);
                  }),
                  Ss,
                  function () {
                    n[fs]();
                  }
                ),
                Is,
                function () {
                  return n[ls]();
                }
              ),
              ws,
              function () {
                o ||
                  (n[ls]() &&
                    (e[A](
                      "[ACTIVATOR][".concat(
                        t,
                        "]: Conditions are satisfied. Destroying triggers and invoking callback"
                      )
                    ),
                    n[fs](),
                    (o = !0),
                    r(t)));
              }
            );
          })(e, n, s, i, o)),
          a
        );
      })
    );
  }
  var ks = "AbsoluteScrollDistance";
  function Cs(e) {
    return u(
      u(u({}, _n, ks), En, function (e) {
        return [Pn(e)];
      }),
      kn,
      function (t, n) {
        return (
          n.getWindow().scrollY >=
          ((null == e ? void 0 : e.pixelsDistance) || 0)
        );
      }
    );
  }
  var Ts = "BreakpointMatch",
    As = { xs: 1, s: 2, m: 3, l: 4, xl: 5 };
  function Rs(e, t, n) {
    var i = As[e],
      r = As[t];
    return "gte" === n ? r >= i : r <= i;
  }
  function xs(e) {
    return u(
      u(u({}, _n, Ts), En, function (e) {
        return [];
      }),
      kn,
      function (t, n) {
        var i = n.viewportInfo[fn]().name,
          r = !("gte" in e) || Rs(e.gte, i, "gte"),
          o = !("lte" in e) || Rs(e.lte, i, "lte");
        return r && o;
      }
    );
  }
  function Ps(e) {
    var t = e[Tn].getWindow(),
      n = e[Rn];
    return (
      document.addEventListener("readystatechange", n),
      u({}, xn, function () {
        t.removeEventListener("readystatechange", n);
      })
    );
  }
  var Os = "DocumentStatus";
  function Ds(e) {
    return u(
      u(u({}, _n, Os), En, function (e) {
        return [Ps(e)];
      }),
      kn,
      function (t, n) {
        return -1 !== e.state.indexOf(document.readyState);
      }
    );
  }
  function Ns(e, t) {
    var n = setInterval(e[Rn], t);
    return u({}, xn, function () {
      clearInterval(n);
    });
  }
  var zs = function (e, t, n) {
      if (!n)
        return (
          t[E]("[WIDGETS] safeQuerySelector selector should be defined"), null
        );
      try {
        return e.querySelector(n);
      } catch (e) {
        t[T]("[WIDGETS] safeQuerySelector error: ".concat(n));
      }
      return null;
    },
    Bs = "DomElementExists";
  function Ms(e, t) {
    return u(
      u(u({}, _n, Bs), En, function (e) {
        return [Ns(e, 250)];
      }),
      kn,
      function (n, i) {
        return null !== zs(document, t, e.selector);
      }
    );
  }
  var Us = "PageCount";
  function js(e) {
    return "fuse-page-views-".concat(e);
  }
  function Ls(e, t) {
    return Number(t.sessionStorage.getItem(js(e)) || 0);
  }
  function Fs(e) {
    var t = !1,
      n = !1;
    return u(
      u(u({}, _n, Us), En, function (e) {
        return [];
      }),
      kn,
      function (i, r) {
        if (!t) {
          !(function (e, t) {
            t.sessionStorage.setItem(js(e), "".concat(Ls(e, t) + 1));
          })(i, r.getWindow()),
            (t = !0);
          var o = Ls(i, r.getWindow());
          (n = o >= ((null == e ? void 0 : e.pageCount) || 1)) &&
            (function (e, t) {
              t.sessionStorage.setItem(js(e), "0");
            })(i, r.getWindow());
        }
        return n;
      }
    );
  }
  var Gs = "UrlRegex";
  function Vs(e) {
    return u(
      u(u({}, _n, Gs), En, function (e) {
        return [];
      }),
      kn,
      function (t, n) {
        var i = n.getWindow().location.toString().match(e.regex);
        return ae(i) && i.length > 0;
      }
    );
  }
  var Hs = "WindowHeightDistance";
  function qs(e) {
    return u(
      u(u({}, _n, Hs), En, function (e) {
        return [Pn(e)];
      }),
      kn,
      function (t, n) {
        var i = n.getWindow();
        return (
          i.scrollY >=
          i.innerHeight * ((null == e ? void 0 : e.windowHeightDistance) || 0)
        );
      }
    );
  }
  var Ws = "WindowValue";
  function Ys(e) {
    return u(
      u(u({}, _n, Ws), En, function () {
        return [];
      }),
      kn,
      function (t, n) {
        return n.getWindow()[e.name] === e.value;
      }
    );
  }
  var Zs = "LocalStorageValue";
  function Js(e) {
    return u(
      u(u({}, _n, Zs), En, function () {
        return [];
      }),
      kn,
      function (t, n) {
        var i = n.getWindow().localStorage.getItem(e.name);
        return void 0 === e.value
          ? null == i
          : n.getWindow().localStorage.getItem(e.name) === e.value;
      }
    );
  }
  var Qs = "MetaTagProperty";
  function Ks(e) {
    var t = e.metaTagKey,
      n = e.metaTagValues;
    return u(
      u(u({}, _n, Qs), En, function () {
        return [];
      }),
      kn,
      function (e, i) {
        var r = i
          .getWindow()
          .document.querySelector('meta[name="'.concat(t, '"]'));
        return !re(r) && n.includes(r.getAttribute("content"));
      }
    );
  }
  var Xs = Symbol(),
    $s = Symbol(),
    ec = Symbol(),
    tc = Symbol();
  function nc() {
    var e;
    return (
      u(
        u(
          u(
            u(
              u(
                u(u(u(u(u((e = {}), ks, Cs), Ts, xs), Bs, Ms), On, Dn), Bn, Mn),
                Us,
                Fs
              ),
              Gs,
              Vs
            ),
            Hs,
            qs
          ),
          Ws,
          Ys
        ),
        Zs,
        Js
      ),
      u(e, Qs, Ks)
    );
  }
  function ic() {
    return u(
      u(
        u(
          u(
            u(
              u(u(u(u(u({}, Os, Ds), ks, Cs), Ts, xs), Hs, qs), Gs, Vs),
              Bs,
              Ms
            ),
            Us,
            Fs
          ),
          Ws,
          Ys
        ),
        Zs,
        Js
      ),
      Qs,
      Ks
    );
  }
  var rc = M()(function (e) {
    return e
      .register(ec, [], nc)
      .register(tc, [], ic)
      .register(Xs, [L, ec], Es)
      .register($s, [L, tc], Es)
      .export();
  });
  function oc(e, t) {
    e && t();
  }
  function ac(e, t, n, i) {
    e && e > 0
      ? (n[A]("[DELAY]: Delaying by ".concat(e, "ms to ").concat(t)),
        setTimeout(i, e))
      : i();
  }
  function sc(e, t) {
    var n = e.getPrebidHash(),
      i = e.getFuseCDN();
    return Object.assign(
      { name: "Prebid.org" },
      n
        ? { url: "//".concat(i, "/prebid/"), file: "prebid-".concat(n, ".js") }
        : {
            url: "//"
              .concat(i, "/")
              .concat(e.getTenantCode(), "/tags/")
              .concat(t, "/")
              .concat(e.getFuseId(), "/"),
            file: "prebid.js",
          }
    );
  }
  var cc = /^[a-zA-Z0-9.-]+$/,
    uc = function (e) {
      return !e || cc.test(e);
    },
    lc = "iiq-latest",
    dc = function (e, t) {
      return e === lc && void 0 !== t
        ? (function (e) {
            return {
              name: "IIQUniversalID",
              url: "//agent.intentiq.com/",
              file: "Agent/".concat(e, "/IIQAgent.js"),
            };
          })(t)
        : (function (e) {
            return {
              name: "IIQUniversalID",
              url: "//cdn.fuseplatform.net/",
              file: e
                ? "prebid/IIQUniversalID-".concat(e, ".js")
                : "prebid/IIQUniversalID.js",
            };
          })(e === lc ? void 0 : e);
    },
    fc = new Set([
      5068036699, 5101751880, 5125288044, 5144578315, 5266853499, 5360458305,
      5427000173, 5478360641, 5478568069, 5553332325, 5564006844, 5640602832,
      5640602859, 5649638833, 5699612790, 5737855598, 5748438433, 5809074645,
      5830943240, 5837005183, 5857383498, 5902912075, 5907620796, 5944988342,
      6018002579, 6047195989, 6043612286, 6081323979, 6097440381, 6097635321,
      6104024521, 6124055233, 6142153860, 6158007561, 6165251260, 6164813165,
      6165250558, 6158968959, 6185438879, 6184617328, 6141097666,
    ]),
    gc = function (e) {
      var t;
      return fc.has(
        null === (t = e.slot.getResponseInformation()) || void 0 === t
          ? void 0
          : t.advertiserId
      );
    };
  function mc(e) {
    return !!e.pendingHeavyAdRecovery && ((e.pendingHeavyAdRecovery = !1), !0);
  }
  var vc = function (e, t, n, i) {
      e[k](function () {
        return ""
          .concat(i, "[EVENT][")
          .concat(n.slot.getSlotElementId(), "]: ")
          .concat(t, " event details: ")
          .concat(JSON.stringify(n));
      });
    },
    pc = Symbol(),
    bc = Symbol();
  function hc(e, t) {
    return (
      e.googletag
        ? e.googletag.cmd ||
          (t[A]("[GPT]: Initialised window.googletag.cmd as it was missing"),
          (e.googletag.cmd = []))
        : (e.googletag = { cmd: [] }),
      e.googletag
    );
  }
  function yc(e, t) {
    function n() {
      return e.googletag;
    }
    return u(u({}, pc, n), bc, function (i) {
      return (
        t[k]("[GPT]: Queuing function for GPT"),
        hc(e, t).cmd.push(function () {
          return i(n(), t);
        })
      );
    });
  }
  var Sc = Symbol(),
    Ic = Symbol(),
    wc = Symbol();
  function _c(e, t) {
    return u(
      u(
        u({}, Sc, function (n) {
          var i = Object.keys(n).join(",");
          e[k]("[GPT CONFIG]: Queueing setConfig with keys=[".concat(i, "]")),
            t[bc](function (e, t) {
              e.setConfig(n),
                t[k](
                  "[GPT CONFIG]: Applied queued setConfig with keys=[".concat(
                    i,
                    "]"
                  )
                );
            });
        }),
        Ic,
        function (n, i) {
          var r = Object.keys(i).join(","),
            o = n.getSlotElementId();
          e[k](function () {
            return "[GPT CONFIG]: Queueing slot.setConfig with slot="
              .concat(o, " keys=[")
              .concat(r, "]");
          }),
            t[bc](function (e, t) {
              n.setConfig(i),
                t[k](function () {
                  return "[GPT CONFIG]: Applied queued slot.setConfig with slot="
                    .concat(o, " keys=[")
                    .concat(r, "]");
                });
            });
        }
      ),
      wc,
      function (t, n) {
        var i = t.getSlotElementId();
        return (
          e[k](function () {
            return "[GPT CONFIG]: Reading slot.getConfig with slot="
              .concat(i, " key=[")
              .concat(String(n), "]");
          }),
          t.getConfig(n)
        );
      }
    );
  }
  var Ec = Symbol(),
    kc = Symbol(),
    Cc = Symbol(),
    Tc = Symbol();
  function Ac(e, t) {
    var n = t.getGptUseNewApi().slotTargeting;
    function i(t, i) {
      var r;
      if (n) {
        var o =
          null === (r = e[wc](t, "targeting")) || void 0 === r ? void 0 : r[i];
        return Array.isArray(o) ? o[0] : null != o ? o : void 0;
      }
      return t.getTargeting(i)[0];
    }
    return u(
      u(
        u(
          u({}, Ec, function (t, i, r) {
            n ? e[Ic](t, { targeting: u({}, i, r) }) : t.setTargeting(i, r);
          }),
          kc,
          function (t, n) {
            e[Ic](t, { targeting: u({}, n, null) });
          }
        ),
        Cc,
        i
      ),
      Tc,
      function (e) {
        return i(e, "hb_size") || i(e, "amznsz");
      }
    );
  }
  var Rc = "fuse_har";
  function xc(e) {
    return "function" == typeof e.getVersion
      ? "v".concat(e.getVersion())
      : "unknown version";
  }
  function Pc(e, t, n, i, r, o, a, c, l, d, f, g) {
    var m,
      v = !1,
      p = !1,
      h = !1,
      y = o.getGptUseNewApi(),
      S = y.forceSafeFrame,
      I = y.pageSettings,
      w = y.pageTargeting,
      _ = o.isCollapseEmptyDivsDisabled(),
      C = !o.isBfcachePageResetEnabled(),
      R = !o.isHeavyAdRefreshEnabled();
    function x() {
      return d[pc]();
    }
    function P(e) {
      return d[bc](function (t, n) {
        return e(V, t, n);
      });
    }
    function O(e, t) {
      if (!e) return n[T]("Called getGPTSlot() without a fuseSlotCode"), [];
      var i = x().pubads().getSlots(),
        r = i.filter(function (t) {
          return e.includes(t.getSlotElementId());
        });
      if (r.length !== e.length) {
        var o = i.map(function (e) {
            return e.getSlotElementId();
          }),
          a = e.filter(function (e) {
            return !o.includes(e);
          });
        n[E](function () {
          return "[AUCTION]["
            .concat(
              t,
              "]: Could not find a GPT slot for all fuse slots.\n          Missing Slots="
            )
            .concat(JSON.stringify(a), ",\n          All GPT Slots: ")
            .concat(JSON.stringify(o));
        });
      }
      return r;
    }
    function D(e) {
      return n[k]("[GPT]: googletag.display()", e), x().display(e);
    }
    function N(e, t) {
      n[k](
        "[GPT]: Setting page targeting for [key: "
          .concat(e, ", value: ")
          .concat(t, "]")
      ),
        w
          ? g[Sc]({ targeting: u({}, e, t) })
          : x().pubads().clearTargeting(e).setTargeting(e, t);
    }
    function z(e, t) {
      P(function () {
        return F(e, t);
      });
    }
    function B() {
      var a;
      n[k]("[GPT]: Applying page targeting");
      var c,
        u = {},
        l = w
          ? function (e, t) {
              u[e] = t;
            }
          : N;
      l("fuse_site", (c = r.host).substring(c.length - 40, c.length)),
        l(
          "fuse_path",
          (function (e) {
            var t = e.pathname;
            return t.substring(t.length - 40, t.length);
          })(r)
        ),
        l(
          "fuse_query",
          (function (e) {
            var t = e.search;
            return t.substring(t.length - 40, t.length);
          })(r)
        ),
        l(
          "fuse_category",
          (function (e) {
            var t,
              n = [],
              i = s(e.pathname.split("/"));
            try {
              for (i.s(); !(t = i.n()).done; ) {
                var r = t.value;
                r.length && !r.includes(".") && n.push(r);
              }
            } catch (e) {
              i.e(e);
            } finally {
              i.f();
            }
            return n;
          })(r)
        );
      var d = o.getFuseIndustry();
      d && l("fuse_industry", d), l("testmode", "".concat(o.isTestCreatives()));
      var f = o.getInskinWidth(),
        m = "".concat(ae(f) && i.screen.width >= f);
      l("inskin_yes", m),
        l("fuse_uuid", o.getFuseUUID()),
        l("fuse_publication_id", o.getPublicationId().toString()),
        l("fuse_flavour", o.getFlavour()),
        l("fuse_revision", o.getTagRevision());
      var p = o.getFuseGeo();
      p &&
        (l("fuse_geo_country", p.country),
        l("fuse_geo_state", p.state),
        l("fuse_geo_code", p.code)),
        l("fuse_optable", "".concat(o.enableOptable())),
        l("fuse_gamsf", "".concat(o.getUseGamSf()));
      var b,
        h = function (e, t) {
          l(e, v ? "refresh" : t);
        },
        y = function (e, t) {
          t && h(e, wr(t));
        };
      if (
        (h("GPT_READY_MS", Or(t[Tr].gpt)),
        h("PREBID_READY_MS", Or(t[Tr].prebid)),
        h("UAM_READY_MS", Or(t[Tr].uam)),
        h("CMP_DETERMINED_MS", Or(t[Tr].cmp)),
        h("CMP_GDPR_CACHED", String(e[Jn])),
        h("CMP_USP_CACHED", String(e[Kn])),
        y("FUSE_LOADED_MS", e[ei]),
        e[Yn] && y("GPT_AUCTION_START_MS", e[Yn]),
        e[Zn] && y("CMP_LOAD_FINISH_MS", e[Zn]),
        e[Qn] && y("CMP_GDPR_ELAPSED_MS", e[Qn]),
        e[Xn] && y("FIRST_ZONE_MS", e[Xn]),
        e[$n] && y("HB_AUCTION_START_MS", e[$n]),
        null === (a = o.getCfConfig()) || void 0 === a ? void 0 : a.bot)
      ) {
        var S = o.getCfConfig().bot;
        l("fuse_bs", String(S.score)),
          l(
            "fuse_bs_bucket",
            String(
              1 === (b = S.score)
                ? "AU"
                : b > 1 && b < 30
                ? "LA"
                : b >= 30 && b <= 99
                ? "LH"
                : "NC"
            )
          );
      }
      var I = Pr(t[Tr].cmp);
      l("CMP_JURISDICTION", I),
        l("CMP_ALLOW_PERSONAL", "".concat(xr(t[Tr].cmp)));
      var _ = (function (e) {
        if ("ready" == e._tag && e.output.noCmpTestResult)
          return "gdpr" === e.output.noCmpTestResult ||
            "ccpa" === e.output.noCmpTestResult
            ? e.output.noCmpTestResult
            : "false";
      })(t[Tr].cmp);
      _ && l("nocmp_mismatch", _);
      for (
        var E = o.getYieldExperimentsTargeting(), C = 0, T = Object.keys(E);
        C < T.length;
        C++
      ) {
        var A = T[C];
        l(A, E[A]);
      }
      for (
        var R = o.getAdditionalYieldExperimentsTargeting(),
          x = 0,
          P = Object.keys(R);
        x < P.length;
        x++
      ) {
        var O = P[x];
        l(O, R[O]);
      }
      w &&
        (n[k](function () {
          return "[GPT]: Applying default page targeting via setConfig: keys=[".concat(
            Object.keys(u).join(","),
            "]"
          );
        }),
        g[Sc]({ targeting: u }));
    }
    function M(e) {
      n[k](
        "[GPT]: googletag.setConfig({ safeFrame: { forceSafeFrame: ".concat(
          e,
          " } })"
        )
      ),
        g[Sc]({ safeFrame: { forceSafeFrame: e } });
    }
    function U(e) {
      return (
        n[k]("[GPT]: googletag.pubads().setForceSafeFrame(".concat(e, ")")),
        x().pubads().setForceSafeFrame(e)
      );
    }
    function j(e) {
      return e.addService(x().pubads());
    }
    function L(e, t) {
      return (
        n[k](function () {
          return "[GPT]: Calling googletag.pubads().refresh(".concat(
            e.map(function (e) {
              return e.getSlotElementId();
            }),
            ")"
          );
        }),
        x().pubads().refresh(e, t)
      );
    }
    function F(e, t) {
      var i = {
        nonPersonalizedAds: "gdpr" === t && !e,
        restrictDataProcessing: ("usp" === t || "ccpa" === t) && !e,
      };
      n[A](function () {
        return "[GPT]: googletag.pubads().setPrivacySettings(".concat(
          JSON.stringify(i),
          ")"
        );
      }),
        x().pubads().setPrivacySettings(i);
    }
    function G(e) {
      n[k]("[GPT]: Clearing page targeting for key: ".concat(e)),
        w
          ? g[Sc]({ targeting: u({}, e, null) })
          : x().pubads().clearTargeting(e);
    }
    var V =
      (u(
        u(
          u(
            u(
              u(
                u(
                  u(
                    u(
                      u(
                        u((m = {}), Dc, function (t, i) {
                          var r = t.zoneTemplate.slot,
                            o = x().defineSlot(r, t.sizes, t.slotDivId);
                          if (o) {
                            e[hi]("register_gpt_slot_".concat(t.slotDivId), {
                              gpid: t.gpid,
                            }),
                              j(o);
                            var a,
                              c = s(i);
                            try {
                              for (c.s(); !(a = c.n()).done; ) {
                                var u = a.value;
                                f[Ec](o, u.key, u.value);
                              }
                            } catch (e) {
                              c.e(e);
                            } finally {
                              c.f();
                            }
                          } else
                            n[E](function () {
                              return "[GPT]: googletag.defineSlot("
                                .concat(r, ", ")
                                .concat(JSON.stringify(t.sizes), ", ")
                                .concat(t.slotDivId, ") returned null");
                            });
                          return o;
                        }),
                        Nc,
                        D
                      ),
                      zc,
                      N
                    ),
                    Bc,
                    P
                  ),
                  Mc,
                  function (e) {
                    !(function (e) {
                      var t = (function (e, t, n) {
                        return function (i, r) {
                          return function (o) {
                            var a = t(o);
                            if (
                              (vc(e, i, o, a ? "[".concat(n, "]") : ""), !t(o))
                            )
                              return r(o);
                          };
                        };
                      })(n, gc, "IN2W");
                      if (
                        ((function () {
                          if (!o.isCmpRequired()) return void F(!0, "none");
                          a[Gt].immediateOrOnce(function (e) {
                            z(e.allowPersonalisation, e.jurisdiction),
                              a[Gt].subscribe(function (e) {
                                z(e.allowPersonalisation, e.jurisdiction);
                              });
                          });
                        })(),
                        I)
                      ) {
                        var i = _ ? "DISABLED" : "BEFORE_FETCH";
                        n[k](
                          "[GPT]: googletag.setConfig({ disableInitialLoad: true, collapseDiv: '".concat(
                            i,
                            "', centering: true })"
                          )
                        ),
                          e.setConfig({
                            disableInitialLoad: !0,
                            collapseDiv: i,
                            centering: !0,
                          });
                      } else {
                        var r = _
                          ? ""
                          : " googletag.pubads().collapseEmptyDivs(true);";
                        n[k](
                          "[GPT]: googletag.pubads().disableInitialLoad();".concat(
                            r,
                            " googletag.pubads().setCentering(true)"
                          )
                        ),
                          e.pubads().disableInitialLoad(),
                          _ || e.pubads().collapseEmptyDivs(!0),
                          e.pubads().setCentering(!0);
                      }
                      n[k](
                        "[GPT]: googletag.setConfig({ singleRequest: true, autoRefresh: { backForwardCache: "
                          .concat(C, ", heavyAds: ")
                          .concat(R, " } })")
                      ),
                        e.setConfig({
                          singleRequest: !0,
                          autoRefresh: { backForwardCache: C, heavyAds: R },
                        }),
                        e.enableServices(),
                        o.isForceSafeFrames() &&
                          (n[k]("[GPT]: Setting forceSafeFrames to true"),
                          S ? M(!0) : U(!0));
                      e.pubads().addEventListener(
                        "slotRequested",
                        t("requested", function (e) {
                          n[k](function () {
                            return "[GPT]: emitting slotRequested event: ".concat(
                              JSON.stringify(e)
                            );
                          }),
                            a[Ct].emit(e);
                        })
                      ),
                        e.pubads().addEventListener(
                          "slotResponseReceived",
                          t("response", function (e) {
                            n[k](function () {
                              return "[GPT]: emitting slotResponseReceived event: ".concat(
                                JSON.stringify(e)
                              );
                            }),
                              a[kt].emit(e);
                          })
                        ),
                        e.pubads().addEventListener(
                          "slotOnload",
                          t("load", function (e) {
                            n[k](function () {
                              return "[GPT]: emitting slotOnload event: ".concat(
                                JSON.stringify(e)
                              );
                            }),
                              a[_t].emit(e);
                          })
                        ),
                        e.pubads().addEventListener(
                          "slotRenderEnded",
                          t("render", function (e) {
                            n[k](function () {
                              return "[GPT]: emitting slotRenderEnded event: ".concat(
                                JSON.stringify(e)
                              );
                            }),
                              a[Et].emit(e);
                          })
                        ),
                        e.pubads().addEventListener(
                          "impressionViewable",
                          t("viewable", function (e) {
                            n[k](function () {
                              return "[GPT]: emitting impressionViewable event: ".concat(
                                JSON.stringify(e)
                              );
                            }),
                              a[Tt].emit(e);
                          })
                        ),
                        e.pubads().addEventListener(
                          "slotVisibilityChanged",
                          t("slotVisibilityChanged", function (e) {
                            n[k](function () {
                              return "[GPT]: emitting slotVisibilityChanged event: ".concat(
                                JSON.stringify(e)
                              );
                            }),
                              a[At].emit(e);
                          })
                        ),
                        e.pubads().addEventListener(
                          "gameManualInterstitialSlotReady",
                          t("h5InterstitialReady", function (e) {
                            n[k](function () {
                              return "[GPT]: emitting gameManualInterstitialSlotReady event: ".concat(
                                JSON.stringify(e)
                              );
                            }),
                              a[Rt].emit(e);
                          })
                        ),
                        e.pubads().addEventListener(
                          "gameManualInterstitialSlotClosed",
                          t("h5InterstitialClosed", function (e) {
                            n[k](function () {
                              return "[GPT]: emitting gameManualInterstitialSlotClosed event: ".concat(
                                JSON.stringify(e)
                              );
                            }),
                              a[xt].emit(e);
                          })
                        ),
                        e.pubads().addEventListener(
                          "rewardedSlotReady",
                          t("rewardedReady", function (e) {
                            n[k](function () {
                              return "[GPT]: emitting rewardedSlotReady event: ".concat(
                                JSON.stringify(e)
                              );
                            }),
                              a[Ot].emit(e);
                          })
                        ),
                        e.pubads().addEventListener(
                          "rewardedSlotGranted",
                          t("rewardedGranted", function (e) {
                            n[k](function () {
                              return "[GPT]: emitting rewardedSlotGranted event: ".concat(
                                JSON.stringify(e)
                              );
                            }),
                              a[Dt].emit(e);
                          })
                        ),
                        e.pubads().addEventListener(
                          "rewardedSlotClosed",
                          t("rewardedClosed", function (e) {
                            n[k](function () {
                              return "[GPT]: emitting rewardedSlotClosed event: ".concat(
                                JSON.stringify(e)
                              );
                            }),
                              a[Nt].emit(e);
                          })
                        ),
                        e.pubads().addEventListener(
                          "rewardedSlotVideoCompleted",
                          t("rewardedVideoCompleted", function (e) {
                            n[k](function () {
                              return "[GPT]: emitting rewardedSlotVideoCompleted event: ".concat(
                                JSON.stringify(e)
                              );
                            }),
                              a[zt].emit(e);
                          })
                        ),
                        B();
                    })(e);
                  }
                ),
                Uc,
                function (t, r) {
                  P(function () {
                    n[k](function () {
                      return "[AUCTION]["
                        .concat(t, "]: Requested to start GPT auction for (")
                        .concat(
                          r.map(function (e) {
                            return e.slotDivId;
                          }),
                          ")"
                        );
                    });
                    var o,
                      a = [],
                      u = s(r);
                    try {
                      for (u.s(); !(o = u.n()).done; ) {
                        var d = o.value,
                          g = O([d.slotDivId], t)[0];
                        g
                          ? a.push([d, g])
                          : n[E](
                              "[AUCTION]["
                                .concat(
                                  t,
                                  "]: Could not find GPT Slot corresponding to "
                                )
                                .concat(d.slotDivId)
                            );
                      }
                    } catch (e) {
                      u.e(e);
                    } finally {
                      u.f();
                    }
                    var m = a.map(function (e) {
                      var t = b(e, 2);
                      return t[0], t[1];
                    });
                    if (m && 0 !== m.length) {
                      var y,
                        S = function () {
                          !(function (e) {
                            var t,
                              n = s(e);
                            try {
                              for (n.s(); !(t = n.n()).done; ) {
                                var i = t.value,
                                  r = i[1],
                                  o = r.getSlotElementId(),
                                  a = i[0].zoneTemplateId,
                                  u = c[Un](o),
                                  d = c[jn](a),
                                  g = _r(u);
                                f[Ec](r, "is_refresh", (u > 0).toString()),
                                  f[Ec](r, "slot_prev_count", g),
                                  f[Ec](r, "adunit_prev_count", _r(d));
                                var m = l[Nr](o);
                                f[Ec](r, "slot_prev_no_fill", [
                                  (
                                    !0 ===
                                    (null == m
                                      ? void 0
                                      : m.hasEmptyRenderBefore)
                                  ).toString(),
                                  ""
                                    .concat(g, "_")
                                    .concat(
                                      !0 ===
                                        (null == m ? void 0 : m.hasEmptyRender)
                                    ),
                                ]),
                                  mc(i[0])
                                    ? (f[Ec](r, Rc, "true"), (h = !0))
                                    : h && f[kc](r, Rc);
                              }
                            } catch (e) {
                              n.e(e);
                            } finally {
                              n.f();
                            }
                          })(a);
                          var n = JSON.stringify(
                            m.map(function (e) {
                              return e.getSlotElementId();
                            })
                          );
                          e[hi]("gpt_pubads_refresh_".concat(n), {
                            requestId: t,
                          }),
                            v || (e[ci](), e[bi]("first_gpt_request")),
                            B(),
                            (v = !0),
                            L(m, { changeCorrelator: p }),
                            (p = !1),
                            (function (e) {
                              var t,
                                n = s(e);
                              try {
                                for (n.s(); !(t = n.n()).done; ) {
                                  var i = t.value,
                                    r = i[1].getSlotElementId(),
                                    o = i[0].zoneTemplateId;
                                  c[Fn](o), c[Ln](r);
                                }
                              } catch (e) {
                                n.e(e);
                              } finally {
                                n.f();
                              }
                            })(a);
                        };
                      !0 ===
                      (function (e) {
                        return /Edge/.test(e.navigator.userAgent);
                      })(i)
                        ? (n[k](
                            "[GC] will trigger GC for iFrames in Edge browser"
                          ),
                          ((y = i.document.querySelectorAll(
                            "div[data-fuse] iframe"
                          )),
                          new Promise(function (e) {
                            setTimeout(function () {
                              try {
                                e();
                              } catch (e) {}
                            }, 5);
                            for (
                              var t = Array.from(y), n = 0, i = t;
                              n < i.length;
                              n++
                            )
                              i[n].addEventListener(
                                "load",
                                function () {
                                  try {
                                    for (; this.contentWindow.lastChild; )
                                      this.contentWindow.lastChild.remove();
                                  } catch (e) {}
                                },
                                { once: !0 }
                              );
                            for (var r = 0, o = t; r < o.length; r++)
                              o[r].setAttribute("src", "about:blank");
                            e();
                          }))
                            .then(function () {
                              try {
                                CollectGarbage();
                              } catch (e) {
                                n[T](
                                  "[GC]: error in CollectGarbage => ".concat(
                                    JSON.stringify(e)
                                  )
                                );
                              }
                              S();
                            })
                            .catch(function (e) {
                              n[T](
                                "[GC]: error in purgeIframes => ".concat(
                                  JSON.stringify(e)
                                )
                              );
                            }))
                        : S();
                    } else
                      n[A](
                        "[AUCTION][".concat(
                          t,
                          "]: Cancelled adserver request because no matching GPT slots found"
                        )
                      );
                  });
                }
              ),
              jc,
              function () {
                P(function () {
                  B();
                });
              }
            ),
            Lc,
            function () {
              S
                ? M(o.isForceSafeFrames() || null)
                : P(function () {
                    U(o.isForceSafeFrames());
                  });
            }
          ),
          Fc,
          function (e) {
            P(function () {
              var t = x().defineOutOfPageSlot(
                e,
                x().enums.OutOfPageFormat.INTERSTITIAL
              );
              t
                ? (j(t),
                  D(t),
                  n[k](
                    "[GPT]: Requesting interstitial refresh for ".concat(
                      t.getSlotElementId()
                    )
                  ),
                  L([t], { changeCorrelator: !1 }))
                : n[E](
                    "setInterstitialSlot(): googletag.defineOutOfPageSlot returned undefined"
                  );
            });
          }
        ),
        Gc,
        function (e) {
          P(function () {
            var t = x()
              .pubads()
              .getSlots()
              .filter(function (t) {
                return t.getOutOfPage() && e === t.getAdUnitPath();
              });
            x().destroySlots(t);
          });
        }
      ),
      u(
        u(
          u(
            u(
              u(
                u(
                  u(
                    u(
                      u(m, Vc, function (e) {
                        P(function () {
                          var t = x().defineOutOfPageSlot(
                            e,
                            x().enums.OutOfPageFormat.GAME_MANUAL_INTERSTITIAL
                          );
                          t
                            ? (j(t),
                              D(t),
                              n[k](
                                "[GPT]: Requesting H5 interstitial refresh for ".concat(
                                  t.getSlotElementId()
                                )
                              ),
                              L([t], { changeCorrelator: !1 }))
                            : (n[E](
                                "setH5InterstitialSlotAsync(): googletag.defineOutOfPageSlot returned undefined; emitting onH5InterstitialUnsupported for ".concat(
                                  e
                                )
                              ),
                              a[Pt].emit({ slotPath: e }));
                        });
                      }),
                      Hc,
                      function (e) {
                        P(function () {
                          var t = x()
                            .pubads()
                            .getSlots()
                            .filter(function (t) {
                              return (
                                t.getOutOfPage() && e === t.getAdUnitPath()
                              );
                            });
                          x().destroySlots(t);
                        });
                      }
                    ),
                    qc,
                    function (e) {
                      P(function () {
                        var t = x().defineOutOfPageSlot(
                          e,
                          x().enums.OutOfPageFormat.REWARDED
                        );
                        t
                          ? (j(t),
                            D(t),
                            n[k](
                              "[GPT]: Rewarded slot created: ".concat(
                                t.getSlotElementId()
                              )
                            ),
                            L([t], { changeCorrelator: !1 }))
                          : (n[E](
                              "setRewardedSlotAsync(): googletag.defineOutOfPageSlot returned undefined; emitting onRewardedUnsupported for ".concat(
                                e
                              )
                            ),
                            a[Bt].emit({ slotPath: e }));
                      });
                    }
                  ),
                  Wc,
                  function (e) {
                    P(function () {
                      var t = x()
                        .pubads()
                        .getSlots()
                        .filter(function (t) {
                          return t.getOutOfPage() && e === t.getAdUnitPath();
                        });
                      x().destroySlots(t);
                    });
                  }
                ),
                Yc,
                function (e) {
                  P(function () {
                    !(function (e) {
                      n[k](function () {
                        return "[GPT]: Destroying slots ".concat(
                          e.map(function (e) {
                            return e.getSlotElementId();
                          })
                        );
                      }),
                        x().destroySlots(e);
                    })(e);
                  });
                }
              ),
              Zc,
              function (e, t) {
                P(function () {
                  return N(e, t);
                });
              }
            ),
            Jc,
            function (e) {
              P(function () {
                var t,
                  n = s(e);
                try {
                  for (n.s(); !(t = n.n()).done; ) {
                    G(t.value.key);
                  }
                } catch (e) {
                  n.e(e);
                } finally {
                  n.f();
                }
              });
            }
          ),
          Qc,
          function () {
            p = !0;
          }
        ),
        Kc,
        z
      ));
    return V;
  }
  function Oc(e, t, n, i, r, o) {
    e[bc](function (e) {
      t[k]("[GPT]: Queued events beginning to execute"),
        n[bi]("gpt_queue_start"),
        o(e);
    }),
      ac(r, "simulate gpt init delay", t, function () {
        n[bi]("gpt_load_start"),
          (function (e, t, n) {
            var i = hc(t, e);
            (null == i ? void 0 : i._loadStarted_)
              ? e[k](
                  "[INIT]: GPT ".concat(
                    xc(i),
                    " is already on the page, skip loading another copy"
                  )
                )
              : ba(
                  { logger: e, window: t },
                  {
                    name: "Google Publisher Tag",
                    url: "//securepubads.g.doubleclick.net/tag/js/",
                    file: "gpt.js",
                  },
                  function () {
                    var r;
                    e[k](
                      "[INIT]: GPT ".concat(
                        (
                          null === (r = t.googletag) || void 0 === r
                            ? void 0
                            : r._loadStarted_
                        )
                          ? "".concat(xc(i), " is loaded")
                          : "not loaded"
                      )
                    ),
                      n();
                  }
                );
          })(t, i, function () {
            n[bi]("gpt_load_finish");
          });
      });
  }
  var Dc = Symbol(),
    Nc = Symbol(),
    zc = Symbol(),
    Bc = Symbol(),
    Mc = Symbol(),
    Uc = Symbol(),
    jc = Symbol(),
    Lc = Symbol(),
    Fc = Symbol(),
    Gc = Symbol(),
    Vc = Symbol(),
    Hc = Symbol(),
    qc = Symbol(),
    Wc = Symbol(),
    Yc = Symbol(),
    Zc = Symbol(),
    Jc = Symbol(),
    Qc = Symbol(),
    Kc = Symbol(),
    Xc = Symbol(),
    $c = Symbol(),
    eu = Symbol(),
    tu = Symbol(),
    nu = Symbol(),
    iu = Symbol(),
    ru = Symbol(),
    ou = Symbol();
  function au(e, t, n) {
    var i = {},
      r = {},
      o = function (n) {
        e[k](function () {
          return "[GPT-REGISTRY]: Calling googletag.destroySlots(".concat(
            JSON.stringify(
              n.map(function (e) {
                return e.getSlotElementId();
              })
            ),
            ")"
          );
        }),
          t[Yc](n);
      };
    function a(e) {
      return e.toLowerCase();
    }
    function s(e) {
      return e && "string" == typeof e && Array.isArray(r[a(e)]) ? r[a(e)] : [];
    }
    function c(e, t, n) {
      var r = a(e);
      i[r] || (i[r] = {}), (i[r][t] = n);
    }
    return u(
      u(
        u(
          u(
            u(
              u(
                u(
                  u({}, Xc, function (t, o) {
                    var s = a(t);
                    Array.isArray(r[s]) || (r[s] = []),
                      e[k]("[GPT-REGISTRY]: Added ".concat(s)),
                      r[s].push(o);
                    var c = i[s];
                    c
                      ? (Object.keys(c).forEach(function (t) {
                          n[Ec](o, t, c[t]),
                            e[k](
                              "[GPT-REGISTRY]: Set targeting. zoneTemplateId: "
                                .concat(s, ", gpt slot id: ")
                                .concat(o.getSlotElementId(), ", key: ")
                                .concat(t, ", value: ")
                                .concat(c[t])
                            );
                        }),
                        e[k](
                          "[GPT-REGISTRY]: Applied targeting for "
                            .concat(s, " on newly added gpt slot - id: ")
                            .concat(o.getSlotElementId())
                        ))
                      : e[k](
                          "[GPT-REGISTRY]: No template targeting set for zoneTemplateId: ".concat(
                            s
                          )
                        );
                  }),
                  $c,
                  function () {
                    Object.keys(r).forEach(function (t) {
                      return (function (t) {
                        var n = a(t);
                        e[k]("[GPT REGISTRY]: Purging ".concat(n));
                        var s = r[n];
                        s && (o(s), delete r[n], delete i[n]);
                      })(t);
                    });
                  }
                ),
                eu,
                function (t, n) {
                  var i = s(t) || [],
                    c = i.find(function (e) {
                      return e.getSlotElementId() === n;
                    });
                  c
                    ? (o([c]),
                      (r[a(t)] = i.filter(function (e) {
                        return e.getSlotElementId() !== n;
                      })))
                    : e[k](
                        "[GPT-REGISTRY]: Could could not destroy slot ".concat(
                          n,
                          " because it has not been registered with GPT"
                        )
                      );
                }
              ),
              tu,
              function () {
                return Object.keys(r).length;
              }
            ),
            nu,
            s
          ),
          iu,
          c
        ),
        ru,
        function (e) {
          var t = a(e);
          return i[t] || null;
        }
      ),
      ou,
      function (t, i, r) {
        c(t, i, r),
          e[k](function () {
            return "[GPT-REGISTRY]: Template targeting set. zoneTemplateId: "
              .concat(t, ", key: ")
              .concat(i, ", value: ")
              .concat(JSON.stringify(r));
          }),
          s(t).forEach(function (o) {
            try {
              n[Ec](o, i, r),
                e[k](function () {
                  return "[GPT-REGISTRY]: Applied template targetings. slot id: "
                    .concat(o.getSlotElementId(), ", key: ")
                    .concat(i, ", value: ")
                    .concat(JSON.stringify(r));
                });
            } catch (n) {
              n instanceof Error
                ? e[T](
                    "[GPT-REGISTRY]: Error occurred while individually setTargeting for slot ".concat(
                      t,
                      "."
                    ),
                    n.message,
                    n.stack
                  )
                : e[T](
                    "[GPT-REGISTRY]: Error of unexpected type occurred while individually setTargeting for slot ".concat(
                      t,
                      "."
                    )
                  );
            }
          });
      }
    );
  }
  var su = Symbol(),
    cu = Symbol(),
    uu = Symbol(),
    lu = Symbol();
  function du(e, t, n, i) {
    var r = [],
      o = i.getGptUseNewApi().pageTargeting;
    function a(i, a) {
      for (var s = -1, c = 0; c < r.length; c++) {
        var l = r[c];
        -1 === s && l.key === i && (s = c);
      }
      e[A](
        "[TARGETING]: Updating custom targeting for [key: "
          .concat(i, ", value: ")
          .concat(a, "]")
      ),
        s > -1 ? (r[s].value = a) : r.push({ key: i, value: a }),
        o ? n[Sc]({ targeting: u({}, i, a) }) : t[Zc](i, a);
    }
    return u(
      u(
        u(
          u({}, su, function () {
            if ((e[A]("[TARGETING] Clearing page targeting"), 0 !== r.length)) {
              if (o) {
                var i = r.reduce(function (e, t) {
                  return Object.assign(
                    Object.assign({}, e),
                    u({}, t.key, null)
                  );
                }, {});
                e[k](function () {
                  return "[TARGETING] Clearing keys via setConfig: ".concat(
                    Object.keys(i).join(",")
                  );
                }),
                  n[Sc]({ targeting: i });
              } else t[Jc](r);
              r = [];
            }
          }),
          cu,
          a
        ),
        uu,
        function (e) {
          var t,
            n = s(e);
          try {
            for (n.s(); !(t = n.n()).done; ) {
              var i = t.value;
              a(i.key, i.value);
            }
          } catch (e) {
            n.e(e);
          } finally {
            n.f();
          }
        }
      ),
      lu,
      function () {
        return r;
      }
    );
  }
  var fu = Symbol(),
    gu = Symbol(),
    mu = Symbol(),
    vu = Symbol(),
    pu = Symbol(),
    bu = Symbol(),
    hu = M()(function (e) {
      return e
        .register(gu, [j, L], yc)
        .register(pu, [L, gu], _c)
        .register(bu, [pu, $i], Ac)
        .register(mu, [na, ra, L, j, H, $i, Kt, oa, sa, gu, bu, pu], Pc)
        .register(fu, [L, mu, bu], au)
        .register(vu, [L, mu, pu, $i], du)
        .export();
    });
  function yu(e, t, n, i, r) {
    var o,
      a = { tag_initialised: !1, on_low_dwell_page: !1 },
      s = r.getBidLibrariesCutoffMs(),
      c = !1;
    function u() {
      var e = f("cmp"),
        t = f("docReadyScan");
      return {
        cmpOk: "ready" === e || "disabled" === e,
        docReady: "ready" == t || "disabled" === t,
        anyBidLibraryReady: m(),
      };
    }
    function l() {
      var e = u();
      return (
        0 ===
        Object.values(e).filter(function (e) {
          return !e;
        }).length
      );
    }
    function d() {
      re(o) &&
        l() &&
        (t[bi]("initmanager_fired_auction_ready"),
        (o = t[ri]()),
        n[It].emit({ eventType: "onInitManagerReady" }));
    }
    function f(e) {
      return i[Tr][e]._tag;
    }
    function g(e) {
      return "ready" === f(e);
    }
    function m() {
      var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
      if ("disabled" === f("yandex")) {
        var n = f("prebid"),
          i = f("uam"),
          r = t
            ? ["ready", "disabled", "cancelled", "deferred", "loaded"]
            : ["ready", "disabled", "cancelled"];
        return (
          e[k](
            "[FUSE][INIT] Checking bid library states, prebid: "
              .concat(n, ", uam: ")
              .concat(i, ", cutoff: ")
              .concat(c)
          ),
          c || (r.includes(n) && r.includes(i))
        );
      }
      return g("yandex");
    }
    return (
      n[St].subscribe(function (t) {
        "gpt" !== t.component ||
          "ready" !== t.state._tag ||
          c ||
          setTimeout(function () {
            m(r.isCmpDeterminationEnabled()) ||
              ((c = !0),
              e[A](
                "[FUSE][INIT] Bid libraries cutoff by timeout ".concat(s, "ms")
              ),
              d());
          }, s),
          d();
      }),
      {
        getInitStatus: u,
        isReadyForInit: l,
        isComponentReady: g,
        setTagInitialised: function () {
          a.tag_initialised = !0;
        },
        isTagInitialised: function () {
          return a.tag_initialised;
        },
        setIsLowDwellPage: function (e) {
          a.on_low_dwell_page = e;
        },
        isLowDwellPage: function () {
          return a.on_low_dwell_page;
        },
      }
    );
  }
  var Su = Symbol(),
    Iu = Symbol(),
    wu = Symbol(),
    _u = Symbol();
  function Eu(e, t) {
    var n = !1;
    function i() {
      return t.fusetag.que;
    }
    return u(
      u(
        u(u({}, Su, i), Iu, function () {
          var t = i().length;
          e[k](
            "[QUEUE]: Cleared fuse queue with ".concat(t, " remaining items")
          ),
            i().splice(0, t);
        }),
        wu,
        function (e) {
          return i().push(e);
        }
      ),
      _u,
      function () {
        if (n) e[T]("[INIT] processBacklog() called, but it already ran");
        else {
          for (
            n = !0,
              e[C](
                "[INIT]: Processing fuse queue with ".concat(
                  i().length,
                  " pending items"
                )
              );
            i().length > 0;

          ) {
            var t = i().shift();
            if ("function" == typeof t)
              try {
                e[k]("[INIT]: Calling queued function"),
                  t.call(),
                  (t.called = !0);
              } catch (t) {
                e[T](
                  "[INIT]: Error calling queued function:",
                  t.message,
                  t.stack
                );
              }
            else
              e[T](
                "[INIT]: Commands written into fusetag.que.push must be wrapped in a function"
              );
          }
          i().push = function (t) {
            if ("function" == typeof t)
              try {
                t.call();
              } catch (t) {
                e[T]("Error processing command :", t.message, t.stack);
              }
            else
              e[T](
                "Commands written into fusetag.que.push must be wrapped in a function"
              );
            return 0;
          };
        }
      }
    );
  }
  var ku = Symbol(),
    Cu = Symbol(),
    Tu = M()(function (e) {
      return e
        .register(ku, [L, na, Kt, ra, $i], yu)
        .register(Cu, [L, j], Eu)
        .export();
    });
  function Au(e, t, n, i) {
    var r = n / 100,
      o = (function (e, t, n, i, r) {
        var o = e.top,
          a = e.bottom,
          s = e.left,
          c = e.right,
          u = e.width,
          l = e.height * r,
          d = u * r;
        return o + l + i >= 0 && s + d >= 0 && a - l - i <= n && c - d <= t;
      })(t.getBoundingClientRect(), e.width, e.innerHeight, i, r);
    return !e.hidden && o;
  }
  var Ru = Symbol(),
    xu = Symbol();
  function Pu(e, t, n) {
    var i = 1;
    return u(
      u({}, Ru, function () {
        return i++ + "";
      }),
      xu,
      function () {
        n[k]("[INIT]: loadIn2wSafeframe"),
          e.addEventListener("message", function (i) {
            if (
              i.data &&
              "object" === I(i.data) &&
              void 0 !== i.data.__i2wGPTEvent
            )
              try {
                var r = i.data.__i2wGPTEvent,
                  o = r.i2wcbid,
                  a = e.googletag
                    .pubads()
                    .getSlots()
                    .find(function (e) {
                      return e.__i2wcbid === o;
                    });
                if (a)
                  switch (r.type) {
                    case "slotResponseReceived":
                      n[k](function () {
                        return "[I2w]: emitting slotResponseReceived event: ".concat(
                          JSON.stringify(i)
                        );
                      }),
                        t[kt].emit(
                          Object.assign(
                            Object.assign({}, r.responseInformation),
                            { slot: a, i2wcbid: o }
                          )
                        );
                      break;
                    case "slotRenderEnded":
                      n[k](function () {
                        return "[I2w]: emitting slotRenderEnded event: ".concat(
                          JSON.stringify(i)
                        );
                      }),
                        t[Et].emit(
                          Object.assign(
                            Object.assign({}, r.responseInformation),
                            { slot: a, i2wcbid: o }
                          )
                        );
                      break;
                    case "slotOnload":
                      n[k](function () {
                        return "[I2w]: emitting slotOnload event: ".concat(
                          JSON.stringify(i)
                        );
                      }),
                        t[_t].emit(
                          Object.assign(
                            Object.assign({}, r.responseInformation),
                            { slot: a, i2wcbid: o }
                          )
                        );
                      break;
                    default:
                      n[E](function () {
                        return "[I2w]: Unknown event type: "
                          .concat(r.type, ": ")
                          .concat(JSON.stringify(i));
                      });
                  }
                else n[E]("[I2w]: no slot found with i2wcbid: ".concat(o));
              } catch (e) {
                n[T](
                  "[I2w]: Something wrong while processing safeframe gpt events: ".concat(
                    e.toString()
                  )
                );
              }
          });
      }
    );
  }
  var Ou =
    /^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$/i;
  function Du(e) {
    var t,
      n,
      i = [].concat(
        y(
          "string" == typeof (n = e.asi) && Ou.test(n)
            ? []
            : ["asi must be a non-empty domain-like string"]
        ),
        y(
          "string" != typeof (t = e.sellerId) || 0 === t.length
            ? ["sellerId must be a non-empty string"]
            : []
        )
      );
    return 0 === i.length ? { valid: !0 } : { valid: !1, errors: i };
  }
  var Nu =
      (this && this.__awaiter) ||
      function (e, t, n, i) {
        return new (n || (n = Promise))(function (r, o) {
          function a(e) {
            try {
              c(i.next(e));
            } catch (e) {
              o(e);
            }
          }
          function s(e) {
            try {
              c(i.throw(e));
            } catch (e) {
              o(e);
            }
          }
          function c(e) {
            var t;
            e.done
              ? r(e.value)
              : ((t = e.value),
                t instanceof n
                  ? t
                  : new n(function (e) {
                      e(t);
                    })).then(a, s);
          }
          c((i = i.apply(e, t || [])).next());
        });
      },
    zu = [
      "33across",
      "adyoulike",
      "inmobi",
      "kargo",
      "oms",
      "optidigital",
      "rubicon",
      "seedtag",
      "smilewanted",
    ];
  function Bu(e, t) {
    if (!t.isUserSyncEnabled()) return { syncEnabled: !1 };
    var n,
      i = t.getIframeUserSyncBidders(),
      r = t.getDisableIframeUserSync() ? (null != i ? i : [].concat(zu)) : "*";
    return Object.assign(
      {
        filterSettings: {
          iframe: { bidders: r, filter: "include" },
          image: { bidders: "*", filter: "include" },
        },
        enableOverride: !t.getDisableUserSyncOverride(),
        userIds:
          ((n = { settings: t, logger: e }),
          n.settings.isUserSyncEnabled()
            ? Oo.filter(function (e) {
                return e.isEnabled(n.settings);
              }).map(function (e) {
                return Object.assign({ name: e.name }, e.buildEntry(n));
              })
            : []),
        auctionDelay: t.getPrebidUserSyncAuctionDelayMs(),
      },
      (function (e) {
        return e.isUserSyncEnabled()
          ? Oo.reduce(function (t, n) {
              return n.userSyncOverrides && n.isEnabled(e)
                ? Object.assign(Object.assign({}, t), n.userSyncOverrides)
                : t;
            }, {})
          : {};
      })(t)
    );
  }
  function Mu(e, t, n) {
    var i, r, o;
    e[k]("[PREBID]: Configured CMP module consentManagement");
    var a = t.isGppEnabled(),
      s =
        "US" ===
        (null === (i = t.getFuseGeo()) || void 0 === i ? void 0 : i.country),
      c = t.isPrebidActivityControlEnabled(),
      u = !0,
      l = !0;
    if (
      t.isCmpDeterminationEnabled() &&
      t.isPrebidStrictConsentModulesEnabled() &&
      "ready" === n[Tr].cmp._tag
    ) {
      var d = n[Tr].cmp;
      (u = Boolean(
        null === (r = d.output) || void 0 === r ? void 0 : r.gppString
      )),
        (l = Boolean(
          null === (o = d.output) || void 0 === o ? void 0 : o.tcData
        ));
    }
    e[k]("[PREBID]: CMP consent status - TCF: ".concat(l, ", GPP: ").concat(u));
    var f = c ? { rules: Fu(t.easePrebidActivityControlEnabled()) } : {};
    return {
      consentManagement: Object.assign(
        Object.assign(
          Object.assign(
            {},
            l &&
              !t.disableGdprInUS() && {
                gdpr: Object.assign(
                  {
                    cmpApi: "iab",
                    timeout: t.getPrebidGdprTimeoutMs(),
                    defaultGdprScope: !0,
                  },
                  f
                ),
              }
          ),
          s && { usp: { cmpApi: "iab", timeout: t.getPrebidUspTimeoutMs() } }
        ),
        a &&
          u && {
            gpp: Object.assign(
              { cmpApi: "iab", timeout: t.getPrebidGppTimeoutMs() },
              f
            ),
          }
      ),
    };
  }
  function Uu(e) {
    return (
      e[k]("[PREBID]: Configured GPT Pre auction module"),
      {
        gptPreAuction: {
          enabled: !0,
          customPreAuction: function (e) {
            var t;
            return null ===
              (t = document.querySelector(
                'div[data-fuse-slot="'.concat(e.code, '"]')
              )) || void 0 === t
              ? void 0
              : t.dataset.gpid;
          },
        },
      }
    );
  }
  function ju(e, t) {
    var n = [];
    return (
      e.getPrebidIasPubId() &&
        n.push({
          name: "ias",
          waitForIt: !0,
          params: { pubId: e.getPrebidIasPubId() },
        }),
      e.enableOptable() &&
        n.push({
          name: "optable",
          waitForIt: !0,
          params: { handleRtd: Lu(t) },
        }),
      e.isOrtbChromeAiRtdEnabled() &&
        n.push({
          name: "chromeAi",
          waitForIt: !1,
          params: { summarizer: { enabled: !0 } },
        }),
      n
    );
  }
  function Lu(e) {
    return function (t, n, i) {
      return Nu(
        this,
        void 0,
        void 0,
        m().m(function r() {
          var o, a, s;
          return m().w(function (r) {
            for (;;)
              switch (r.n) {
                case 0:
                  if (
                    !(e.optable && e.optable.rtd && e.optable.rtd.handleRtd)
                  ) {
                    r.n = 1;
                    break;
                  }
                  return r.a(2, e.optable.rtd.handleRtd(t, n, i));
                case 1:
                  if (
                    ((a = JSON.parse(
                      e.localStorage.getItem("OPTABLE_RESOLVED") || "{}"
                    ).ortb2),
                    !(s =
                      (null === (o = null == a ? void 0 : a.user) ||
                      void 0 === o
                        ? void 0
                        : o.eids) || []).length)
                  ) {
                    r.n = 2;
                    break;
                  }
                  return r.a(
                    2,
                    i(
                      t.ortb2Fragments.global,
                      Object.assign(Object.assign({}, a), {
                        user: Object.assign(Object.assign({}, a.user), {
                          ext: Object.assign(Object.assign({}, a.user.ext), {
                            eids: s,
                          }),
                        }),
                      })
                    )
                  );
                case 2:
                  return (
                    (e.optable = e.optable || {}),
                    (e.optable.cmd = e.optable.cmd || []),
                    r.a(
                      2,
                      new Promise(function (r) {
                        e.optable.cmd.push(function () {
                          r(e.optable.rtd.handleRtd(t, n, i));
                        });
                      })
                    )
                  );
              }
          }, r);
        })
      );
    };
  }
  function Fu() {
    var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
      t = { enforcePurpose: !e, enforceVendor: !e };
    return [
      Object.assign({ purpose: "storage" }, t),
      Object.assign({ purpose: "basicAds" }, t),
      Object.assign(Object.assign({ purpose: "personalizedAds" }, t), {
        eidsRequireP4Consent: !0,
      }),
      Object.assign({ purpose: "measurement" }, t),
      Object.assign({ purpose: "transmitPreciseGeo" }, t),
    ];
  }
  function Gu(e) {
    var t = {
      allow: !0,
      priority: 1,
      condition: function (t) {
        var n, i;
        if ("ready" === e[Tr].cmp._tag) {
          var r = e[Tr].cmp;
          return (
            "usp" ===
              (null === (n = r.output) || void 0 === n
                ? void 0
                : n.jurisdiction) &&
            !0 ===
              (null === (i = r.output) || void 0 === i
                ? void 0
                : i.allowPersonalisation)
          );
        }
        return !1;
      },
    };
    return {
      allowActivities: {
        accessDevice: { default: !0 },
        transmitEids: { default: !0, rules: [t] },
        enrichEids: { default: !0, rules: [t] },
        syncUser: { default: !0, rules: [t] },
      },
    };
  }
  function Vu(e, t) {
    return (
      t[k](function () {
        return "[PREBID]: Enabling Prebid Server for ".concat(
          JSON.stringify(e)
        );
      }),
      {
        s2sConfig: {
          accountId: "20884",
          bidders: e,
          adapter: "prebidServer",
          enabled: !0,
          endpoint: "https://mpbs.rubiconproject.com/openrtb2/auction",
          syncEndpoint: "https://mpbs.rubiconproject.com/cookie_sync",
          timeout: 750,
          extPrebid: { cache: { vastxml: { returnCreative: !1 } } },
        },
      }
    );
  }
  function Hu(e, t, n) {
    var i,
      r,
      o,
      a,
      s = y(null !== (i = e.getFuseIndustry()) && void 0 !== i ? i : []);
    return {
      name: null !== (r = e.getAccountName()) && void 0 !== r ? r : t.hostname,
      domain: t.hostname,
      cat: s,
      cattax: 1,
      sectioncat: s,
      pagecat: s,
      content: { cat: s },
      page: t.href,
      ref: n.document.referrer,
      keywords:
        null !==
          (a =
            null === (o = n.document.querySelector('meta[name="keywords"]')) ||
            void 0 === o
              ? void 0
              : o.getAttribute("content")) && void 0 !== a
          ? a
          : void 0,
      privacypolicy: 1,
    };
  }
  function qu(e, t) {
    var n = Du(e);
    if (!0 === n.valid)
      return {
        ext: {
          schain: {
            ver: "1.0",
            complete: 1,
            nodes: [{ asi: e.asi, sid: e.sellerId, hp: 1 }],
          },
        },
      };
    t[T]("[PREBID]: schain validation failed; omitting schain", n.errors);
  }
  function Wu(e) {
    if (e.isOrtbDeviceGeoEnabled()) {
      var t = e.getFuseGeo(),
        n = (null == t ? void 0 : t.country) || void 0,
        i = (null == t ? void 0 : t.state) || void 0;
      if (void 0 !== n) {
        var r = i ? "".concat(n, "-").concat(i) : void 0;
        return {
          geo: Object.assign({ country: n }, void 0 !== r && { region: r }),
        };
      }
    }
  }
  function Yu(e) {
    var t = e.getBadAdv();
    return (null == t ? void 0 : t.length) ? y(t) : void 0;
  }
  function Zu(e) {
    var t = e.site,
      n = e.source,
      i = e.device,
      r = e.badv;
    return t || n || i || r
      ? {
          ortb2: Object.assign(
            Object.assign(
              Object.assign(
                Object.assign({}, t && { site: t }),
                n && { source: n }
              ),
              i && { device: i }
            ),
            r && { badv: r }
          ),
        }
      : {};
  }
  function Ju(e) {
    var t = (function (e) {
      var t,
        n =
          null === (t = null == e ? void 0 : e.aps) || void 0 === t
            ? void 0
            : t.accountID;
      if (!n || !("client" in n) || Array.isArray(n.client)) return;
      return "string" == typeof n.client.parameterValue
        ? n.client.parameterValue
        : void 0;
    })(e.getNetworkParams().contract);
    return t ? { bidders: ["aps"], config: { aps: { accountID: t } } } : void 0;
  }
  var Qu = {
    supportsAps: !0,
    getConfig: function (e) {
      var t = e.params,
        n = e.logger,
        i = e.settings,
        r = e.fuseWindow,
        o = e.location,
        a = e.pluginStatusStore,
        s = ju(i, r),
        c = !0 === t.sendAllBids,
        u = t.sco ? qu(t.sco, n) : void 0;
      return Object.assign(
        Object.assign(
          Object.assign(
            Object.assign(
              Object.assign(
                Object.assign(
                  Object.assign(
                    Object.assign(
                      Object.assign(
                        Object.assign(
                          {
                            priceGranularity: {
                              buckets: [
                                { max: 3, increment: 0.01, precision: 2 },
                                { max: 10, increment: 0.1, precision: 2 },
                                { max: 50, increment: 1, precision: 2 },
                                { max: 100, increment: 10, precision: 2 },
                              ],
                            },
                            userSync: Bu(n, i),
                            targetingControls: {
                              addTargetingKeys: ["SOURCE", "DSP", "CRID"],
                              sendAllBids: c,
                            },
                            eventHistoryTTL: i.getEventHistoryTTLOverride(),
                            minBidCacheTTL: i.getMinBidCacheTTLOverride(),
                          },
                          i.isCmpRequired() && Mu(n, i, a)
                        ),
                        Uu(n)
                      ),
                      Zu({
                        site: Hu(i, o, r),
                        source: u,
                        device: Wu(i),
                        badv: Yu(i),
                      })
                    ),
                    t.prebidServerBidders.length > 0 &&
                      Vu(t.prebidServerBidders, n)
                  ),
                  {
                    currency: {
                      adServerCurrency: "USD",
                      granularityMultiplier: 1,
                      defaultRates: { AUD: { USD: 0.67 } },
                    },
                  }
                ),
                i.isBidCacheEnabled() && { useBidCache: !0 }
              ),
              s.length > 0 && {
                realTimeData: { auctionDelay: 150, dataProviders: s },
              }
            ),
            { enableTIDs: !0 }
          ),
          i.isPrebidAuctionOptionsEnabled() && {
            auctionOptions: {
              suppressStaleRender: !0,
              suppressExpiredRender: !0,
            },
          }
        ),
        i.isPrebidActivityControlEnabled() && Gu(a)
      );
    },
    applyConfig: function (e, t, n, i) {
      return (
        t[k](function () {
          return "[PREBID][V10]: Applied config settings ".concat(
            JSON.stringify(e)
          );
        }),
        n.setConfig(
          Object.assign(
            Object.assign({}, e),
            i.isPrebidVideoEnabled() && {
              rubicon: {
                rendererConfig: {
                  align: "center",
                  position: "append",
                  closeButton: !0,
                  label: "Advertisement",
                  collapse: !0,
                },
              },
            }
          )
        ),
        (n.bidderSettings = {
          adagio: { storageAllowed: !0 },
          standard: { storageAllowed: !0 },
        }),
        n.aliasBidder("nexx360", "pubxai", { gvlid: 1485 }),
        e
      );
    },
  };
  var Ku = {
    supportsAps: !0,
    getConfig: function (e) {
      var t = e.params,
        n = e.logger,
        i = e.settings,
        r = e.fuseWindow,
        o = e.location,
        a = e.pluginStatusStore,
        s = ju(i, r),
        c = !0 === t.sendAllBids,
        u = t.sco ? qu(t.sco, n) : void 0;
      return Object.assign(
        Object.assign(
          Object.assign(
            Object.assign(
              Object.assign(
                Object.assign(
                  Object.assign(
                    Object.assign(
                      Object.assign(
                        Object.assign(
                          {
                            priceGranularity: {
                              buckets: [
                                { max: 3, increment: 0.01, precision: 2 },
                                { max: 10, increment: 0.1, precision: 2 },
                                { max: 50, increment: 1, precision: 2 },
                                { max: 100, increment: 10, precision: 2 },
                              ],
                            },
                            userSync: Bu(n, i),
                            targetingControls: {
                              addTargetingKeys: ["SOURCE", "DSP", "CRID"],
                              sendAllBids: c,
                            },
                            storageControl: { enforcement: "off" },
                            eventHistoryTTL: i.getEventHistoryTTLOverride(),
                            minBidCacheTTL: i.getMinBidCacheTTLOverride(),
                          },
                          i.isCmpRequired() && Mu(n, i, a)
                        ),
                        Uu(n)
                      ),
                      Zu({
                        site: Hu(i, o, r),
                        source: u,
                        device: Wu(i),
                        badv: Yu(i),
                      })
                    ),
                    t.prebidServerBidders.length > 0 &&
                      Vu(t.prebidServerBidders, n)
                  ),
                  {
                    currency: {
                      adServerCurrency: "USD",
                      granularityMultiplier: 1,
                      defaultRates: { AUD: { USD: 0.67 } },
                    },
                  }
                ),
                i.isBidCacheEnabled() && { useBidCache: !0 }
              ),
              s.length > 0 && {
                realTimeData: { auctionDelay: 150, dataProviders: s },
              }
            ),
            { enableTIDs: !0 }
          ),
          i.isPrebidAuctionOptionsEnabled() && {
            auctionOptions: {
              suppressStaleRender: !0,
              suppressExpiredRender: !0,
            },
          }
        ),
        i.isPrebidActivityControlEnabled() && Gu(a)
      );
    },
    applyConfig: function (e, t, n, i) {
      return (
        t[k](function () {
          return "[PREBID][V11]: Applied config settings ".concat(
            JSON.stringify(e)
          );
        }),
        n.setConfig(
          Object.assign(
            Object.assign({}, e),
            i.isPrebidVideoEnabled() && {
              rubicon: {
                rendererConfig: {
                  align: "center",
                  position: "append",
                  closeButton: !0,
                  label: "Advertisement",
                  collapse: !0,
                },
              },
            }
          )
        ),
        (n.bidderSettings = {
          adagio: { storageAllowed: !0 },
          standard: { storageAllowed: !0 },
        }),
        n.aliasBidder("nexx360", "pubxai", { gvlid: 1485 }),
        e
      );
    },
  };
  var Xu = {
    getConfig: function (e) {
      var t,
        n = e.params,
        i = e.logger,
        r = e.settings,
        o = e.fuseWindow,
        a = e.location,
        s = e.pluginStatusStore,
        c = ju(r, o);
      return Object.assign(
        Object.assign(
          Object.assign(
            Object.assign(
              Object.assign(
                Object.assign(
                  Object.assign(
                    Object.assign(
                      Object.assign(
                        Object.assign(
                          Object.assign(
                            {
                              enableSendAllBids:
                                !0 === (null == n ? void 0 : n.sendAllBids),
                              priceGranularity: {
                                buckets: [
                                  { max: 3, increment: 0.01, precision: 2 },
                                  { max: 10, increment: 0.1, precision: 2 },
                                  { max: 50, increment: 1, precision: 2 },
                                  { max: 100, increment: 10, precision: 2 },
                                ],
                              },
                              userSync: Bu(i, r),
                              targetingControls: {
                                addTargetingKeys: ["SOURCE", "DSP", "CRID"],
                              },
                              eventHistoryTTL: r.getEventHistoryTTLOverride(),
                              minBidCacheTTL: r.getMinBidCacheTTLOverride(),
                            },
                            r.isCmpRequired() && Mu(i, r, s)
                          ),
                          Uu(i)
                        ),
                        Zu({ site: Hu(r, a, o), device: Wu(r), badv: Yu(r) })
                      ),
                      n.sco && {
                        schain: {
                          validation: "strict",
                          config: {
                            ver: "1.0",
                            complete: 1,
                            nodes: [
                              { asi: (t = n.sco).asi, sid: t.sellerId, hp: 1 },
                            ],
                          },
                        },
                      }
                    ),
                    n.prebidServerBidders.length > 0 &&
                      Vu(n.prebidServerBidders, i)
                  ),
                  {
                    currency: {
                      adServerCurrency: "USD",
                      granularityMultiplier: 1,
                      defaultRates: { AUD: { USD: 0.67 } },
                    },
                  }
                ),
                r.isBidCacheEnabled() && { useBidCache: !0 }
              ),
              c.length > 0 && {
                realTimeData: { auctionDelay: 150, dataProviders: c },
              }
            ),
            { enableTIDs: !0 }
          ),
          r.isPrebidAuctionOptionsEnabled() && {
            auctionOptions: {
              suppressStaleRender: !0,
              suppressExpiredRender: !0,
            },
          }
        ),
        r.isPrebidActivityControlEnabled() && Gu(s)
      );
    },
    applyConfig: function (e, t, n, i) {
      return (
        t[k](function () {
          return "[PREBID]: Applied config settings ".concat(JSON.stringify(e));
        }),
        n.setConfig(
          Object.assign(
            Object.assign({}, e),
            i.isPrebidVideoEnabled() && {
              cache: { url: "https://prebid.adnxs.com/pbc/v1/cache" },
              rubicon: {
                rendererConfig: {
                  align: "center",
                  position: "append",
                  closeButton: !0,
                  label: "Advertisement",
                  collapse: !0,
                },
              },
            }
          )
        ),
        (n.bidderSettings = {
          adagio: { storageAllowed: !0 },
          standard: { storageAllowed: !0 },
        }),
        n.aliasBidder("nexx360", "pubxai", { gvlid: 1485 }),
        e
      );
    },
  };
  function $u(e) {
    return !0 === e.libLoaded;
  }
  function el(e, t, n) {
    try {
      n();
    } catch (n) {
      n instanceof Error
        ? e[T]("".concat(t, " :"), n.message, n.stack)
        : e[T]("".concat(t, " :"), n);
    }
  }
  var tl = Symbol(),
    nl = Symbol();
  function il(e, t) {
    function n() {
      return e;
    }
    return u(u({}, tl, n), nl, function (e) {
      var i = n();
      i.que.push(function () {
        return el(t, "Error processing command", function () {
          return e(i);
        });
      });
    });
  }
  function rl(e) {
    return e.fusePbjs || (e.fusePbjs = { que: [] }), e.fusePbjs;
  }
  var ol = Symbol(),
    al = Symbol(),
    sl = Symbol(),
    cl = new Set(["v7", "v8"]);
  function ul(e) {
    return u(
      u(
        u({}, ol, function (t) {
          var n = t.settings,
            i = t.logger,
            r = t.browserWindow,
            o = t.windowLocation,
            a = t.packageMajorVersion,
            s = t.reporter,
            c = t.pluginStatusStore,
            u = t.qpr,
            l = t.eventHandlers,
            d = t.componentLoadCallback,
            f = t.onReadyCallback,
            g = t.onPrebidConfigured,
            m = (function (e) {
              var t = e.getTagRevision();
              return "v7" === t ? Qu : "v8" === t ? Ku : Xu;
            })(n),
            v = !cl.has(n.getTagRevision());
          function p(e) {
            var t = n.getPrebidSettings(),
              a = {
                sendAllBids: !0 === (null == t ? void 0 : t.sendAllBids),
                sco: n.getSco(),
                prebidServerBidders: [],
              },
              s = m.getConfig({
                params: a,
                logger: i,
                settings: n,
                fuseWindow: r,
                location: o,
                pluginStatusStore: c,
              }),
              u = (function (e) {
                return e.isUserSyncEnabled()
                  ? Oo.reduce(function (t, n) {
                      var i;
                      if (!n.isEnabled(e)) return t;
                      var r =
                        null === (i = n.getAnalytics) || void 0 === i
                          ? void 0
                          : i.call(n, e);
                      return r ? [].concat(y(t), [r]) : t;
                    }, [])
                  : [];
              })(n);
            m.applyConfig(s, i, e, n),
              (function (e, t, n) {
                0 !== n.length &&
                  (t[k](function () {
                    return "[PREBID] Enabled analytics modules: ".concat(
                      n
                        .map(function (e) {
                          return e.provider;
                        })
                        .join(", ")
                    );
                  }),
                  el(t, "Error enabling analytics modules", function () {
                    return e.enableAnalytics(n);
                  }));
              })(e, i, u);
            var d = Ju(n);
            m.supportsAps &&
              d &&
              (i[k](function () {
                return "[PREBID]: aps bidder config, accountID ".concat(
                  d.config.aps.accountID
                );
              }),
              e.setBidderConfig(d, !0)),
              (function (e, t, n) {
                t[k]("[PREBID] Adding auctionEnd event listener"),
                  e.onEvent("auctionEnd", function (e) {
                    t[k]("[PREBID] auctionEnd event callback triggered"),
                      n[Mt].emit(e);
                  }),
                  t[k]("[PREBID] Adding adRenderFailed event listener"),
                  e.onEvent("adRenderFailed", function (e) {
                    t[k]("[PREBID] adRenderFailed event callback triggered"),
                      n[Ut].emit(e);
                  }),
                  t[k]("[PREBID] Adding adRenderSucceeded event listener"),
                  e.onEvent("adRenderSucceeded", function (e) {
                    t[k]("[PREBID] adRenderSucceeded event callback triggered"),
                      n[jt].emit(e);
                  }),
                  t[k]("[PREBID] Adding onBidWon event listener"),
                  e.onEvent("bidWon", function (e) {
                    t[k]("[PREBID] bidWon event callback triggered"),
                      n[Lt].emit(e);
                  });
              })(e, i, l),
              i[k](function () {
                return "[PREBID]: Enabled prebid ".concat(JSON.stringify(s));
              });
          }
          ac(u[fe](), "simulate prebid download delay", i, function () {
            var t = s[ri]();
            !(function (e, t, n, i, r, o) {
              r[bi]("prebid_load_script_start");
              var a = rl(t);
              $u(a)
                ? (e[E](
                    "[INIT]: Prebid ".concat(
                      a.version,
                      " is already loaded skip loading it again"
                    )
                  ),
                  r[bi]("prebid_onload_received"),
                  o())
                : ba({ logger: e, window: t }, sc(i, n), function () {
                    var t = $u(a)
                      ? "".concat(a.version, " is loaded and ready")
                      : "not loaded";
                    e[k]("[INIT]: Prebid ".concat(t)),
                      r[bi]("prebid_onload_received"),
                      o();
                  });
            })(i, r, a, n, s, function () {
              d(t);
              var o = e[tl](),
                a = r.pbjs;
              oe(a) || !$u(a)
                ? (r.pbjs = o)
                : a.renderAd && (a.renderAd = o.renderAd);
              var s = function (e) {
                  p(e), g(e);
                },
                c = function () {
                  return s(o);
                },
                u = v
                  ? function () {
                      return e[nl](s);
                    }
                  : function () {
                      return el(i, "Error initialising prebid", c);
                    };
              n.useCmpReadyEvent()
                ? (i[k](
                    "[PREBID]: Waiting for CMP ready event before configuring Prebid"
                  ),
                  l[Zt].immediateOrOnce(function (e) {
                    i[k](
                      "[PREBID]: CMP ready event received, configuring Prebid with consent data"
                    ),
                      n.isStrictCmp() && !e.allowPersonalisation
                        ? (i[k](
                            "[PREBID]: CMP is ready and personalisation is NOT allowed, skipping Prebid initialisation"
                          ),
                          f(!0))
                        : (n.isStrictCmp() &&
                            i[k](
                              "[PREBID]: CMP is ready and personalisation is allowed, initialising Prebid"
                            ),
                          u(),
                          f());
                  }))
                : (u(), f());
            });
          });
        }),
        al,
        function () {
          var t = e[tl]();
          $u(t) && t.removeAdUnit();
        }
      ),
      sl,
      function (t, n, i) {
        var r = e[tl]();
        return $u(r)
          ? (r.renderAd(t, n), !0)
          : (null == i ||
              i[T](
                "[PREBID]: cannot render cached bid ".concat(
                  n,
                  ", Prebid is not loaded"
                )
              ),
            !1);
      }
    );
  }
  function ll(e, t) {
    var n = e.advertiserId,
      i = e.campaignId,
      r = {
        isAdvertiserListed: ne(n) && t.advertiserIds.includes(n),
        isCampaignListed: ne(i) && t.campaignIds.includes(i),
      };
    return "allow" === t.mode
      ? (function (e, t, n) {
          var i = e.advertiserId,
            r = e.campaignId;
          if (!n.isAdvertiserListed && !n.isCampaignListed)
            return t.advertiserIds.length > 0 && ne(i)
              ? "advertiserId=".concat(i, " not in allow list")
              : t.campaignIds.length > 0 && ne(r)
              ? "campaignId=".concat(r, " not in allow list")
              : void 0;
        })(e, t, r)
      : (function (e, t) {
          var n = e.advertiserId,
            i = e.campaignId;
          return t.isAdvertiserListed
            ? "advertiserId=".concat(n)
            : t.isCampaignListed
            ? "campaignId=".concat(i)
            : void 0;
        })(e, r);
  }
  var dl = Symbol(),
    fl = Symbol();
  function gl(e, t, n, i) {
    function r(e) {
      return "[SLOT-FORMAT][".concat(e.id, "]:");
    }
    return u(
      u({}, dl, function (o, a) {
        var s = a.attributes;
        !t.isMiniScrollersEnabled() ||
          !1 === s.miniscroller ||
          s.sticky ||
          s.interscroller ||
          s.interstitial ||
          s.scrollToStick ||
          a.attributes.forceComboZone ||
          a.attributes.comboZoneEnabled ||
          (function (t, n) {
            var o = i.getComputedStyle(t),
              a = o.height,
              s = o.minHeight;
            return (
              e[k](
                ""
                  .concat(
                    r(n),
                    ' applying miniscroller on element with height "'
                  )
                  .concat(a, '" min-height: "')
                  .concat(s, '"')
              ),
              -1 === ["0px", "auto"].indexOf(a) &&
                (e[k](
                  ""
                    .concat(
                      r(n),
                      " Miniscroller was not applied because of height "
                    )
                    .concat(a, ' already set for element "')
                    .concat(t.id, '"')
                ),
                !0)
            );
          })(o, a) ||
          (function (t, n) {
            for (
              var o = t.parentElement,
                a = ["hidden", "scroll", "auto"],
                s = ["overflow", "overflow-x", "overflow-y"];
              o;

            )
              s.forEach(function (t) {
                var s = i.getComputedStyle(o)[t];
                if (ae(s) && -1 !== a.indexOf(s))
                  return (
                    e[k](
                      ""
                        .concat(r(n), " Miniscroller was not applied. ")
                        .concat(String(t), ' on "')
                        .concat(o.id, " ")
                        .concat(o.className, '"')
                    ),
                    !0
                  );
              }),
                (o = o.parentElement);
            return !1;
          })(o, a) ||
          (e[k](
            ""
              .concat(r(a), ' Update slot element "')
              .concat(o.id, '" to miniscroller')
          ),
          (function (e, i) {
            var r = n[fn]().name;
            e.classList.add("fuse-slot-mini-scroller");
            var o = t.maxSlotHeightForBreakpoint(i, r);
            e.style.minHeight = "".concat(o, "px");
          })(o, a));
      }),
      fl,
      function (e, t) {
        var i,
          r = n[fn]().name,
          o = null === (i = t.sizeMapping) || void 0 === i ? void 0 : i[r],
          a = 0,
          s = 0;
        o &&
          o.length > 0 &&
          (o.forEach(function (e) {
            "fluid" !== e &&
              "fluid" !== e[0] &&
              (Number(e[0]) > s && (s = Number(e[0])),
              Number(e[1]) > a && (a = Number(e[1])));
          }),
          (e.style.width = "".concat(s, "px")),
          (e.style.height = "".concat(a, "px")),
          (e.style.margin = "auto"));
      }
    );
  }
  var ml = "fuse_exp_16-val",
    vl = Symbol();
  function pl(e, t, n) {
    var i = 0,
      r = 0,
      o = !1,
      a = n.isComboZoneEnabled(),
      s = n.isComboZoneYeRunning();
    function c(t, n) {
      if (!s) return [];
      if (
        (e[A](
          "[COMBO-ZONE][".concat(t.id, "]: Calculating comboZone targeting")
        ),
        !t.attributes.comboZoneEnabled)
      ) {
        var r = "ye-".concat(a, "_zone_disabled");
        return (
          e[A](
            "[COMBO-ZONE]["
              .concat(t.id, "]: ComboZone is disabled - setting targeting to ")
              .concat(r, " ")
          ),
          [{ key: ml, value: r }]
        );
      }
      var o = (function (e) {
          var t = e.length > 0;
          if (t && a && l(i)) return e[0].name;
          var n = "ye-".concat(a.toString()),
            r = t ? "eligible" : "ineligible";
          if (t) {
            var o = l(i) ? "selected" : "not-selected";
            return "".concat(n, "_").concat(r, "_").concat(o);
          }
          return "".concat(n, "_").concat(r);
        })(n),
        c = [{ key: ml, value: o }];
      return (
        e[A](
          "[COMBO-ZONE]["
            .concat(t.id, "]: ComboZone targeting calculated with result: ")
            .concat(JSON.stringify(c))
        ),
        n.length > 0 && i++,
        c
      );
    }
    function l(e) {
      return e < 1;
    }
    function d(n, i, r, a) {
      var s;
      if (!(null === (s = i.sizeMapping) || void 0 === s ? void 0 : s[r]))
        return (
          e[C](
            "[COMBO-ZONE]["
              .concat(i.id, "] no sizes found for breakpoint ")
              .concat(r)
          ),
          { zoneDivs: [n], template: i }
        );
      n.setAttribute("data-fuse-combo", i.id),
        n.removeAttribute("data-fuse"),
        e[C](
          "[COMBO-ZONE][".concat(i.id, "] updated data-fuse to data-fuse-combo")
        );
      var c = "fuse-zone-combo-".concat(a.name.replace("@", "-"));
      n.classList.add(c),
        e[C](
          "[COMBO-ZONE]["
            .concat(i.id, "] added class ")
            .concat(c, " to combo zone parent div")
        );
      var l = new Array(a.numZones).fill(0).map(function () {
        return t[$t](i.id, "fuse-slot-comboZone");
      });
      e[C](
        "[COMBO-ZONE]["
          .concat(i.id, "] created ")
          .concat(l.length, " slots for template")
      ),
        n.append.apply(n, y(l)),
        o ||
          (t[tn](
            "publift-fuse-combozone-styles",
            "\n      .fuse-zone-combo-V2-300x250, .fuse-zone-combo-V2-728x90 {\n        display: flex;\n        flex-direction: column;\n      }\n      .fuse-zone-combo-V2-300x250 .fuse-slot-comboZone, .fuse-zone-combo-V2-728x90 .fuse-slot-comboZone {\n        margin-bottom: 10px;\n      }\n      .fuse-zone-combo-H2-300x250, .fuse-zone-combo-H3-300x250, .fuse-zone-combo-H2-728x90 {\n        display: flex;\n        flex-direction: row;\n        justify-content: center;\n      }\n      .fuse-zone-combo-H2-300x250 .fuse-slot-comboZone, .fuse-zone-combo-H3-300x250 .fuse-slot-comboZone {\n        padding-right: 10px;\n      }\n      .fuse-zone-combo-H2-728x90 .fuse-slot-comboZone + .fuse-slot-comboZone {\n        margin-left: 30px;\n      }\n    "
          ),
          (o = !0));
      var d = Object.assign(Object.assign({}, i), {
        sizeMapping: Object.assign(
          Object.assign({}, i.sizeMapping),
          u({}, r, y(a.sizes))
        ),
      });
      return (
        e[C](
          "[COMBO-ZONE]["
            .concat(i.id, "] Updated comboZone slot sizes to ")
            .concat(JSON.stringify(a.sizes))
        ),
        { zoneDivs: l, template: d }
      );
    }
    return u({}, vl, function (t) {
      var i,
        o,
        a,
        s,
        u,
        f,
        g,
        m,
        v = t.currentBp,
        p = t.comboZoneOptions,
        b = t.template,
        h = t.zoneDiv,
        S =
          n.isComboZoneEnabled() &&
          l(r) &&
          (null === (i = b.attributes) || void 0 === i
            ? void 0
            : i.comboZoneEnabled) &&
          p.length > 0,
        I =
          (null === (o = b.attributes) || void 0 === o
            ? void 0
            : o.forceComboZone) &&
          (null === (a = null == b ? void 0 : b.comboZoneAttributes) ||
          void 0 === a
            ? void 0
            : a.name);
      if (
        (e[k](
          "[COMBO-ZONE]["
            .concat(b.id, "]: Checking if template can be used as Combo zone ")
            .concat(
              JSON.stringify({
                isComboZoneQualified: {
                  count: r,
                  enabled:
                    null === (s = b.attributes) || void 0 === s
                      ? void 0
                      : s.comboZoneEnabled,
                  comboZoneOptions: p,
                },
                isComboZoneForced: {
                  forced:
                    null === (u = b.attributes) || void 0 === u
                      ? void 0
                      : u.forceComboZone,
                  eligible:
                    null === (f = b.comboZoneAttributes) || void 0 === f
                      ? void 0
                      : f.name,
                },
              })
            )
        ),
        !S && !I)
      ) {
        e[A](
          "[COMBO-ZONE][".concat(
            b.id,
            "]: Template wasn't be picked for comboZone"
          )
        );
        var w = c(b, p);
        return {
          zoneDivs: [h],
          template: Object.assign(Object.assign({}, b), {
            targeting: [].concat(y(b.targeting || []), y(w)),
          }),
          comboZoneVal: null === (g = w[0]) || void 0 === g ? void 0 : g.value,
        };
      }
      e[A]("[COMBO-ZONE][".concat(b.id, "]: Using template as Combo zone")),
        I || ++r;
      var _ = xi(I ? b.comboZoneAttributes.name : p[0].name);
      e[C](
        "[COMBO-ZONE]["
          .concat(b.id, "]: Picked attributes for the comboZone: ")
          .concat(JSON.stringify(_))
      );
      var E = d(h, b, v, _),
        T = E.zoneDivs,
        R = E.template,
        x = c(R, p);
      return {
        zoneDivs: T,
        template: Object.assign(Object.assign({}, R), {
          targeting: [].concat(y(R.targeting || []), y(x)),
        }),
        comboZoneVal: null === (m = x[0]) || void 0 === m ? void 0 : m.value,
      };
    });
  }
  var bl = "div",
    hl = "data-fuse",
    yl = "".concat(bl, "[").concat(hl, "]"),
    Sl = "data-fuse-reset-at",
    Il = Symbol(),
    wl = Symbol(),
    _l = Symbol(),
    El = Symbol();
  function kl(e, t, n, i, r, o, a, s) {
    var c = t.document,
      l = {},
      d = {},
      f = function (e, t) {
        return t[e] || (t[e] = 0), ++t[e];
      },
      g = function (i, r) {
        var c,
          u = i.getAttribute(hl);
        if (!u)
          return e[E]("[SLOTS]: Empty data-fuse attribute ".concat(u)), [];
        var l = n.generateZoneTemplate(u, o);
        if (!l)
          return (
            e[E](
              "[SLOTS]: Unknown ZoneCode found in data-fuse attribute ".concat(
                u
              )
            ),
            []
          );
        if (!m(i, r)) return [];
        var d = o.viewportInfo[fn]().name,
          f = (function (e, t, n) {
            if (!n || n.length < 1) return [];
            var i = Ei(e, t),
              r = i.maxWidth,
              o = i.maxHeight;
            return Ri.filter(function (e) {
              var t = n.find(function (t) {
                  return t[0] === e.parentSize[0] && t[1] === e.parentSize[1];
                }),
                i = n.find(function (t) {
                  return (
                    t[0] === e.comboZoneSize[0] && t[1] === e.comboZoneSize[1]
                  );
                });
              return (
                t &&
                i &&
                (!r || r >= e.computedSize[0]) &&
                (!o || o >= e.computedSize[1])
              );
            });
          })(
            i,
            t,
            null === (c = l.sizeMapping) || void 0 === c ? void 0 : c[d]
          ),
          g = a[vl]({
            zoneDiv: i,
            currentBp: d,
            comboZoneOptions: f,
            template: l,
          }),
          p = g.template,
          b = g.zoneDivs,
          h = g.comboZoneVal,
          y = v({
            templateToUse: p,
            zoneDivs: b,
            comboZoneEligible: f.length > 0,
          });
        return (
          h &&
            y.forEach(function (e) {
              s[Sr](e.slotDivId, h);
            }),
          y
        );
      },
      m = function (t, n) {
        var i = t.getAttribute("data-fuse-code"),
          r = t.getAttribute(Sl);
        if (n) {
          if (i && !r)
            return (
              e[k](
                "[SLOTS]: Skip ".concat(i, " because it was already processed")
              ),
              !1
            );
          i &&
            r &&
            e[k](
              "[SLOTS]: Processing ".concat(
                i,
                " again because it has been reset"
              )
            );
        } else
          i &&
            e[E](
              "[SLOTS]: Processing ".concat(
                i,
                " again. This is likely to be an error, but preserved for backwards compatibility"
              )
            );
        return !0;
      },
      v = function (t) {
        var o = t.comboZoneEligible,
          a = t.templateToUse;
        return t.zoneDivs.map(function (t) {
          var s,
            u,
            g,
            m = (null === (s = t.id) || void 0 === s ? void 0 : s.trim())
              ? null === (u = t.id) || void 0 === u
                ? void 0
                : u.trim()
              : void 0,
            v = n.isUseBackwardCompatibleNaming() ? a.gamAdUnitId : a.id,
            p = "fuse-slot-".concat((g = v), "-").concat(f(g, l)),
            h = (function (e) {
              return "zone-instance-".concat(e, "-").concat(f(e, d));
            })(v),
            y = (function (e, t, n) {
              return "".concat(t, "#").concat(n, "-").concat(l[e]);
            })(v, a.slot, "single");
          return (
            (function (t, o, a, s, u) {
              if (
                (e[k]("[SLOTS][".concat(t, ": Preparing the element")),
                s.setAttribute("data-fuse-code", "".concat(t)),
                s.setAttribute("data-fuse-zone-instance", "".concat(o)),
                s.setAttribute("data-fuse-slot", "".concat(t)),
                s.setAttribute("data-gpid", a),
                s.setAttribute("data-fuse-processed-at", r[ri]().toString()),
                s.removeAttribute(Sl),
                c.getElementById(t))
              )
                e[E](
                  "[DOM-SCAN]: Found existing slot element with id ".concat(t)
                );
              else {
                var l = c.createElement("div");
                l.setAttribute("id", "".concat(t)),
                  l.classList.add("fuse-slot"),
                  (l.style.maxWidth = "inherit"),
                  (l.style.maxHeight = "inherit"),
                  i[dl](s, u),
                  n.isYandexEnabled() && i[fl](l, u),
                  s.appendChild(l);
              }
            })(p, h, y, t, a),
            {
              zoneTemplate: a,
              slotDivId: p,
              zoneDiv: t,
              zoneDivId: m,
              zoneInstanceId: h,
              gpid: y,
              targeting: b(t),
              comboZoneEligible: o,
              manualDisplay: a.attributes.manualDisplay,
            }
          );
        });
      },
      p = function (e) {
        return e.indexOf(",") > 0
          ? e
              .split(",")
              .map(function (e) {
                return e.trim();
              })
              .filter(function (e) {
                return "" !== e;
              })
          : e;
      },
      b = function (e) {
        var t = e
            .getAttributeNames()
            .filter(function (e) {
              return "data-targeting-key" !== e && "data-targeting-value" !== e;
            })
            .filter(function (e) {
              return 0 === e.indexOf("data-targeting-", 0);
            })
            .map(function (e) {
              return {
                attributeKey: e,
                targetingKey: e.replace("data-targeting-", "").trim(),
              };
            })
            .map(function (t) {
              return {
                key: t.targetingKey,
                value: e.getAttribute(t.attributeKey),
              };
            })
            .filter(function (e) {
              var t = e.key,
                n = e.value;
              return (
                (null == t ? void 0 : t.length) &&
                (null == n ? void 0 : n.length)
              );
            })
            .map(function (e) {
              var t = e.key,
                n = e.value;
              return { key: t, value: p(n) };
            }),
          n = e.getAttribute("data-targeting-key"),
          i = e.getAttribute("data-targeting-value");
        return (
          (null == n ? void 0 : n.length) &&
            (null == i ? void 0 : i.length) &&
            !t.some(function (e) {
              return e.key === n;
            }) &&
            t.push({ key: n, value: p(i) }),
          t
        );
      },
      h = function (e) {
        return c.querySelectorAll(
          "".concat(bl, "[").concat(hl, '="').concat(e, '"]')
        );
      },
      S = function (e, t) {
        return Array.from(e).reduce(function (e, n) {
          var i = g(n, t);
          return [].concat(y(e), y(i));
        }, []);
      };
    return u(
      u(
        u(
          u({}, Il, function (e) {
            var t = c.querySelectorAll(yl);
            return S(t, e);
          }),
          wl,
          function (t, n) {
            var i,
              r,
              o =
                ((i = t),
                0 ==
                (r = c.querySelectorAll(
                  "".concat(bl, '[id="').concat(i, '"][').concat(hl, "]")
                )).length
                  ? e[E](
                      "[SLOTS]: No DOM element found with both id='".concat(
                        i,
                        "' AND a data-fuse attribute"
                      )
                    )
                  : r.length > 1 &&
                    e[E](
                      "[SLOTS]: Multiple DOM elements found with id '".concat(
                        i,
                        "'"
                      )
                    ),
                r);
            return S(o, n);
          }
        ),
        _l,
        function (e, t) {
          var n = h(e),
            i = S(n, t);
          return i[i.length - 1];
        }
      ),
      El,
      function (e, t) {
        var n = h(e);
        return S(n, t);
      }
    );
  }
  var Cl =
      (this && this.__rest) ||
      function (e, t) {
        var n = {};
        for (var i in e)
          Object.prototype.hasOwnProperty.call(e, i) &&
            t.indexOf(i) < 0 &&
            (n[i] = e[i]);
        if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
          var r = 0;
          for (i = Object.getOwnPropertySymbols(e); r < i.length; r++)
            t.indexOf(i[r]) < 0 &&
              Object.prototype.propertyIsEnumerable.call(e, i[r]) &&
              (n[i[r]] = e[i[r]]);
        }
        return n;
      },
    Tl = Symbol(),
    Al = Symbol(),
    Rl = Symbol(),
    xl = Symbol(),
    Pl = Symbol(),
    Ol = Symbol(),
    Dl = Symbol(),
    Nl = Symbol(),
    zl = Symbol(),
    Bl = Symbol(),
    Ml = Symbol(),
    Ul = Symbol(),
    jl = Symbol();
  function Ll(e) {
    return ae(e.sizes);
  }
  function Fl(e, t, n, i, r, o, a, c, l, d, f, g) {
    var m,
      v,
      p = [],
      b = {},
      h = {},
      S = {},
      w = [],
      _ = ct(e, "onSlotCreated"),
      R = ct(e, "onSlotsInitialised");
    function x() {
      return Object.keys(b)
        .filter(function (e) {
          return b[e].currentlyActive;
        })
        .map(function (e) {
          return b[e];
        });
    }
    function P(e) {
      return ae(window.document.getElementById(e));
    }
    function O(e) {
      return -1 !== p.indexOf(e);
    }
    function D(e) {
      var t, n;
      return (
        null !==
          (n =
            null === (t = b[e]) || void 0 === t
              ? void 0
              : t.isAboveViewport()) &&
        void 0 !== n &&
        n
      );
    }
    function N(e) {
      var t = S[e];
      if (t) {
        var n = S,
          i = e;
        n[i];
        var r = Cl(n, ["symbol" === I(i) ? i : i + ""]);
        (S = r), t.disconnect();
      }
    }
    function z(o) {
      var a,
        s,
        c = null === (a = b[o]) || void 0 === a ? void 0 : a.zoneDiv;
      try {
        O(o) && e[C]("[EVENT]: resetSlots() unit already deleted ".concat(o)),
          p.push(o);
        var u = b[o];
        u &&
          (i[eu](u.zoneTemplate.id, o),
          u.zoneDiv.setAttribute(Sl, t[ri]().toString())),
          null === (s = h[o]) || void 0 === s || s[Ss](),
          delete b[o],
          delete h[o],
          N(o);
      } catch (t) {
        e[E](
          "[SLOTS][".concat(o, "]: Failed to reset slot"),
          t instanceof Error ? t.message : String(t)
        );
      }
      r.isStaleSlotDivRemovalOnResetEnabled() &&
        (function (t, i) {
          var r,
            o =
              null !==
                (r =
                  i &&
                  Array.from(i.children).find(function (e) {
                    return e.id === t;
                  })) && void 0 !== r
                ? r
                : n.document.getElementById(t);
          o &&
            (e[k]("[SLOTS][".concat(t, "]: Removed stale slot div")),
            o.remove());
        })(o, c);
    }
    function B(e) {
      for (var t = 0, n = Object.keys(b); t < n.length; t++) {
        var i = n[t];
        e.has(i) || z(i);
      }
      var r;
      0 === e.size &&
        ((b = {}),
        (h = {}),
        (r = Object.values(S)),
        (S = {}),
        r.forEach(function (e) {
          return e.disconnect();
        }));
    }
    function M(e, t) {
      (e.currentlyActive = !0),
        U(e, t),
        c[mt].emit({
          zoneTemplateId: e.zoneTemplate.id,
          zoneDivId: e.zoneDivId,
          zoneEventType: "registered",
          instanceId: e.zoneInstanceId,
          status: "active",
          gpid: e.gpid,
          comboZoneEligible: e.comboZoneEligible,
          slotDivId: e.slotDivId,
        });
    }
    function U(t, n) {
      t.zoneTemplate.attributes.afs
        ? e[k](
            "[SLOTS][".concat(
              t.slotDivId,
              "]: Afs zone detected, skipping gpt/prebid registration"
            )
          )
        : ((function (t, n) {
            g[Bc](function (o) {
              if (O(t.slotDivId))
                e[C](
                  "[SLOTS][".concat(
                    t.slotDivId,
                    "]: Skip GPT registration because div deleted"
                  )
                );
              else {
                var a;
                r.isIn2wSafeframe() && (a = f[Ru]());
                var s = a
                  ? o[Dc](t, [].concat(y(n), [{ key: "i2wcbid", value: a }]))
                  : o[Dc](t, n);
                s &&
                  (r.isIn2wSafeframe() && (s.__i2wcbid = a),
                  i[Xc](t.zoneTemplate.id, s),
                  o[Nc](t.slotDivId));
              }
            });
          })(t, n),
          t.allowHeaderBidding
            ? (function (t) {
                var n = function () {
                  O(t.slotDivId)
                    ? e[C](
                        "[SLOTS][".concat(
                          t.slotDivId,
                          "]: Skip prebid registration because div deleted"
                        )
                      )
                    : l.registerPrebidUnit(t);
                };
                $u(d[tl]()) ? n() : w.push(n);
              })(t)
            : e[k](
                "[SLOTS][".concat(
                  t.slotDivId,
                  "]: Skip prebid registration because headerbidding not enabled"
                )
              ));
    }
    function j(t) {
      var n;
      e[k]("[SLOTS][".concat(t, "]: Deleting slot"));
      var r = L(t);
      r
        ? i[eu](r.zoneTemplate.id, r.slotDivId)
        : e[k](
            "[SLOTS][".concat(t, "]: Registered slot not found upon deletion")
          ),
        p.push(t),
        delete b[t],
        null === (n = h[t]) || void 0 === n || n[Ss](),
        delete h[t],
        c[qt].emit({ slotDivId: t }),
        r &&
          c[mt].emit({
            zoneTemplateId: r.zoneTemplate.id,
            zoneDivId: r.zoneDivId,
            zoneEventType: "deleted",
            instanceId: r.zoneInstanceId,
            gpid: r.gpid,
            slotDivId: r.slotDivId,
          }),
        N(t);
    }
    function L(e) {
      return b[e];
    }
    function F(t) {
      if (r.isAbandonLazyAuctionEnabled() && D(t.slotDivId))
        return (
          e[C](
            "[SLOTS][".concat(
              t.slotDivId,
              "]: Held slot scrolled past, abandoning instead of releasing"
            )
          ),
          void c[Yt].emit({ slot: t, reason: "slot aboveViewport" })
        );
      c[Wt].emit({ slot: t });
    }
    function G(t, n, i, r, a) {
      return o[_s](n, t.slotDivId, i, function () {
        t.isAdRequestHeld
          ? F(t)
          : (function (t, n, i) {
              var r = t.slotDivId;
              if (b[r] && !0 === b[r].currentlyActive)
                e[E](
                  "[SLOTS][".concat(
                    r,
                    "]: Skipped activation because the slot was already activated"
                  )
                );
              else {
                if (!P(r))
                  return (
                    e[E](
                      "[SLOTS][".concat(
                        r,
                        "]: Skipped activation because the slot was removed from the DOM"
                      )
                    ),
                    void j(r)
                  );
                h[r][Ss](),
                  (t.currentlyActive = !0),
                  U(t, n),
                  c[mt].emit({
                    zoneTemplateId: t.zoneTemplate.id,
                    zoneDivId: t.zoneDivId,
                    zoneEventType: "activated",
                    instanceId: t.zoneInstanceId,
                    gpid: t.gpid,
                    slotDivId: t.slotDivId,
                  }),
                  i([t]);
              }
            })(t, r, a);
      });
    }
    function V(i) {
      var o,
        l = i.slotDivId,
        d = i.zoneDiv,
        f = i.zoneInstanceId,
        g = i.zoneDivId,
        m = i.zoneTemplate,
        p = i.gpid,
        y = i.targeting,
        w = i.forceActivate,
        k = i.api,
        T = i.runAuctionFn,
        R = i.comboZoneEligible,
        x = a[fn]().name,
        O = (function (e, t, n) {
          var i = Ei(t, e),
            r = i.maxWidth,
            o = i.maxHeight;
          return n
            .filter(function (e) {
              return !wi(e) || !ae(r) || e[0] <= r;
            })
            .filter(function (e) {
              return !wi(e) || !ae(o) || e[1] <= o;
            });
        })(n, d, null !== (o = m.sizeMapping[x]) && void 0 !== o ? o : []),
        D = O.length > 0 ? O : void 0,
        z = _i(O),
        B = Object.assign(
          Object.assign(
            Object.assign(
              Object.assign(
                Object.assign(
                  Object.assign(
                    Object.assign(
                      Object.assign(
                        {},
                        (function (t, i, r, o, s) {
                          return {
                            slotDivId: t,
                            zoneDiv: o,
                            zoneDivId: s,
                            zoneInstanceId: i,
                            zoneTemplate: r,
                            zoneTemplateId: r.id,
                            isInView: function () {
                              var i =
                                  arguments.length > 0 &&
                                  void 0 !== arguments[0]
                                    ? arguments[0]
                                    : 0,
                                o = r.attributes.interscroller
                                  ? n.document.querySelector(
                                      ".publift-widget-".concat(
                                        r.id,
                                        "-container"
                                      )
                                    )
                                  : n.document.getElementById(t);
                              if (o) {
                                var s = (
                                    r.attributes.interscroller
                                      ? o
                                      : o.parentElement
                                  ).getBoundingClientRect(),
                                  c = s.top,
                                  u = s.bottom,
                                  l = s.left,
                                  d = s.right,
                                  f = s.width,
                                  g = s.height;
                                return c || u || l || d || f || g
                                  ? Au(a[mn](), o, 50, i)
                                  : (e[C](
                                      "[SLOTS][".concat(
                                        t,
                                        "]: Skipped slot checkInView because zone/interscroller element is not visible"
                                      )
                                    ),
                                    !1);
                              }
                              return (
                                e[E](
                                  "[SLOTS][".concat(
                                    t,
                                    "]: Slot element is not found"
                                  )
                                ),
                                !1
                              );
                            },
                            isAllowRefresh: function () {
                              return !0;
                            },
                            isInDom: function () {
                              return P(t);
                            },
                            isAboveViewport: function () {
                              return _o(o.getBoundingClientRect());
                            },
                          };
                        })(l, f, m, d, g)
                      ),
                      {
                        currentlyActive: !1,
                        storedAt: t[ri](),
                        breakpoint: x,
                        sizes: D,
                        sizesHb: z,
                        path: m.slot,
                        allowHeaderBidding:
                          ae(z) && z.length > 0 && r.isHeaderBiddingSlot(m),
                      }
                    ),
                    m.mediaTypes && { mediaTypes: m.mediaTypes }
                  ),
                  m.videoAttributes && { prebidVideoConfig: m.videoAttributes }
                ),
                { gpid: p }
              ),
              m.targeting && { targeting: m.targeting }
            ),
            ae(v)
              ? {
                  isAllowRefresh: function () {
                    return v(l);
                  },
                }
              : {}
          ),
          {
            comboZoneEligible: R,
            manualDisplay: m.attributes.manualDisplay,
            isAdRequestHeld: !1,
            pendingHeavyAdRecovery: !1,
          }
        );
      if (((b[l] = B), oe(D)))
        return (
          e[A](
            "[SLOTS][".concat(
              l,
              "]: Registered as inactive because no sizes available"
            )
          ),
          B
        );
      var U = B,
        j = (function (e, t, n, i) {
          e[C](
            "[SLOTS]["
              .concat(t, "]: merge slot targeting ")
              .concat(JSON.stringify(n), ", ")
              .concat(JSON.stringify(i))
          );
          var r = n;
          if (i) {
            var o,
              a = s(i);
            try {
              var c = function () {
                var e = o.value;
                r.find(function (t) {
                  return t.key === e.key;
                }) || r.push({ key: e.key, value: e.value });
              };
              for (a.s(); !(o = a.n()).done; ) c();
            } catch (e) {
              a.e(e);
            } finally {
              a.f();
            }
          }
          return (
            e[C](function () {
              return "[SLOTS]["
                .concat(t, "]: set slot targeting ")
                .concat(JSON.stringify(r));
            }),
            r
          );
        })(e, l, y, m.targeting);
      if (w)
        e[A](
          "[SLOTS][".concat(l, "]: Registering as active because it is forced")
        ),
          M(U, j);
      else if (m.activateCondition) {
        var L = G(U, m.activateCondition, k, j, T);
        L[Is]()
          ? (e[A](
              "[SLOTS][".concat(
                l,
                "]: Registering as active because conditions already satisfied"
              )
            ),
            M(U, j))
          : m.isBidAheadZone
          ? (e[A](
              "[SLOTS][".concat(
                l,
                "]: Registering as active to bid ahead, holding the GAM request"
              )
            ),
            (U.isAdRequestHeld = !0),
            M(U, j),
            (h[l] = L),
            L[ys]())
          : (e[A](
              "[SLOTS][".concat(
                l,
                "]: Registering as inactive and enabling triggers"
              )
            ),
            (function (e, t) {
              (h[e.slotDivId] = t),
                c[mt].emit({
                  zoneTemplateId: e.zoneTemplate.id,
                  zoneDivId: e.zoneDivId,
                  zoneEventType: "registered",
                  instanceId: e.zoneInstanceId,
                  status: "inactive",
                  gpid: e.gpid,
                  comboZoneEligible: e.comboZoneEligible,
                  slotDivId: e.slotDivId,
                });
            })(U, L),
            L[ys]());
      } else
        e[C](
          "[SLOTS][".concat(
            l,
            "]: Registering as active because no conditions defined"
          )
        ),
          M(U, j);
      return (
        _.emit({}),
        c[Vt].emit({ slot: U }),
        (function (i) {
          var o = n.IntersectionObserver;
          if ("function" == typeof o && r.isCaptureInViewTimeEnabled()) {
            var a = i.slotDivId;
            N(a);
            try {
              var s = (function (e, t) {
                var n = !1;
                return new e(
                  function (e) {
                    !n &&
                      e.some(function (e) {
                        return e.isIntersecting;
                      }) &&
                      (t(), (n = !0));
                  },
                  { threshold: 0 }
                );
              })(o, function () {
                S[a] === s &&
                  (c[Ht].emit({ slotDivId: a, enteredAt: t[ri]() }), N(a));
              });
              (S = Object.assign(Object.assign({}, S), u({}, a, s))),
                s.observe(i.zoneDiv);
            } catch (t) {
              e[A](
                "[SLOTS][".concat(a, "]: Failed to observe viewport entry"),
                t instanceof Error ? t.message : String(t)
              );
              var l = S,
                d = a;
              l[d];
              var f = Cl(l, ["symbol" === I(d) ? d : d + ""]);
              S = f;
            }
          }
        })(U),
        B
      );
    }
    function H() {
      e[k]("[DOM]: Clearing fuse skins");
      for (
        var t = n.document.querySelectorAll("div.fuse-custom-skin"), i = 0;
        i < t.length;
        i++
      )
        t[i].parentNode.removeChild(t[i]);
    }
    if (r.isStopRefreshOnMatchedIdActive()) {
      var q = {
        advertiserIds: r.getStopRefreshAdvertiserIds(),
        campaignIds: r.getStopRefreshCampaignIds(),
        mode: r.getStopRefreshMode(),
      };
      c[Et].subscribe(function (t) {
        var n = b[t.slot.getSlotElementId()];
        if (n) {
          var i = ll(t, q);
          (n.refreshBlockedBy = i),
            void 0 !== i &&
              e[C](
                "[REFRESH]: stopping refresh for slot "
                  .concat(n.slotDivId, " — ")
                  .concat(i)
              );
        }
      });
    }
    return (
      u(
        u(
          u(
            u(
              u(
                u(
                  u(
                    u(
                      u(
                        u((m = {}), Tl, function () {
                          var t =
                            arguments.length > 0 &&
                            void 0 !== arguments[0] &&
                            arguments[0]
                              ? (function () {
                                  for (
                                    var t,
                                      n = new Set(),
                                      i = 0,
                                      r = Object.keys(b);
                                    i < r.length;
                                    i++
                                  ) {
                                    var o = r[i];
                                    (null === (t = b[o]) || void 0 === t
                                      ? void 0
                                      : t.zoneTemplate.attributes
                                          .ignoreBreakpointRefresh) &&
                                      (e[A](
                                        "[RESPONSIVE][".concat(
                                          o,
                                          "]: Skipping reset — ignoreBreakpointRefresh is enabled"
                                        )
                                      ),
                                      n.add(o));
                                  }
                                  return n;
                                })()
                              : new Set();
                          B(t), H();
                        }),
                        Al,
                        function () {
                          for (
                            var e = {}, t = 0, n = Object.keys(b);
                            t < n.length;
                            t++
                          ) {
                            var i = n[t],
                              r = b[i];
                            e[r.slotDivId] = r.zoneTemplate;
                          }
                          return e;
                        }
                      ),
                      Rl,
                      function (e) {
                        return b[
                          Object.keys(b).find(function (t) {
                            return b[t].zoneDivId === e;
                          })
                        ];
                      }
                    ),
                    xl,
                    j
                  ),
                  Pl,
                  function (t, n, i, r) {
                    var o = t
                      .map(function (e) {
                        return V({
                          slotDivId: e.slotDivId,
                          zoneDiv: e.zoneDiv,
                          zoneInstanceId: e.zoneInstanceId,
                          zoneDivId: e.zoneDivId,
                          zoneTemplate: e.zoneTemplate,
                          gpid: e.gpid,
                          targeting: e.targeting,
                          forceActivate: i,
                          api: n,
                          runAuctionFn: r,
                          comboZoneEligible: e.comboZoneEligible,
                        });
                      })
                      .filter(ae);
                    return (
                      e[k]("[SLOTS]: Registered ".concat(o.length, " slots")),
                      R.emit({}),
                      o
                    );
                  }
                ),
                Ol,
                function () {
                  return R;
                }
              ),
              zl,
              function () {
                return _;
              }
            ),
            Nl,
            function (t) {
              (v = t), e[k]("[SLOTS]: Registered setAllowSlotRefreshCallback");
            }
          ),
          Dl,
          function () {
            for (var e = {}, t = 0, n = Object.keys(b); t < n.length; t++) {
              var i = n[t],
                r = b[i];
              e[r.slotDivId] = r.zoneDiv;
            }
            return e;
          }
        ),
        Bl,
        function () {
          return b;
        }
      ),
      u(
        u(
          u(
            u(
              u(
                u(
                  u(
                    u(
                      u(
                        u(m, Ml, function () {
                          for (var t; (t = w.shift()); )
                            try {
                              t();
                            } catch (t) {
                              t instanceof Error
                                ? e[T](
                                    "[SLOTS]: Error flushing pending prebid registration:",
                                    t.message,
                                    t.stack
                                  )
                                : e[T](
                                    "[SLOTS]: Error flushing pending prebid registration:",
                                    t
                                  );
                            }
                        }),
                        Ul,
                        function (e) {
                          var t = b[e];
                          t && (t.pendingHeavyAdRecovery = !0);
                        }
                      ),
                      jl,
                      function (e) {
                        var t = b[e];
                        t && (t.pendingHeavyAdRecovery = !1);
                      }
                    ),
                    "getSlot",
                    L
                  ),
                  "getSlotsForTemplateId",
                  function (e) {
                    return Object.keys(b)
                      .filter(function (t) {
                        return b[t].zoneTemplate.id === e;
                      })
                      .map(function (e) {
                        return b[e];
                      });
                  }
                ),
                "getActiveSlots",
                x
              ),
              "excludeDeleted",
              function (e, t) {
                return e.filter(function (e) {
                  var n = !O(e.slotDivId);
                  return !n && t && t(e.slotDivId), n;
                });
              }
            ),
            "isAboveViewport",
            D
          ),
          "isLazy",
          function (e) {
            var t;
            return (
              "lazy" ===
              (null === (t = b[e]) || void 0 === t
                ? void 0
                : t.zoneTemplate.activateConditionConfig.type)
            );
          }
        ),
        "clearAdRequestHold",
        function (e) {
          var t = b[e];
          t && (t.isAdRequestHeld = !1);
        }
      ),
      u(
        u(
          u(
            u(u(m, "clearFuseSkins", H), "getSlots", function (e) {
              var t,
                n = [],
                i = s(e);
              try {
                for (i.s(); !(t = i.n()).done; ) {
                  var r = L(t.value);
                  r && n.push(r);
                }
              } catch (e) {
                i.e(e);
              } finally {
                i.f();
              }
              return n;
            }),
            "isDeletedSlot",
            O
          ),
          "destroySticky",
          function () {
            var e,
              t = x().filter(function (e) {
                return e.zoneTemplate.attributes.sticky;
              }),
              n = s(t);
            try {
              for (n.s(); !(e = n.n()).done; ) {
                j(e.value.slotDivId);
              }
            } catch (e) {
              n.e(e);
            } finally {
              n.f();
            }
          }
        ),
        "deleteSlot",
        j
      )
    );
  }
  function Gl(e) {
    try {
      return e instanceof Error && "string" == typeof e.message
        ? e.message.slice(0, 200)
        : "unknown error";
    } catch (e) {
      return "unknown error";
    }
  }
  var Vl,
    Hl,
    ql = /\(id=([^;]{0,200});url=([^\n]{0,400})\)$/,
    Wl = [
      ["network usage", "network"],
      ["total CPU usage", "cpu-total"],
      ["peak CPU usage", "cpu-peak"],
    ];
  function Yl(e) {
    return (
      "intervention" === e.type &&
      (function (e) {
        if ("object" !== I(e) || null === e || Array.isArray(e)) return !1;
        var t = e.id,
          n = e.message;
        return "HeavyAdIntervention" === t && "string" == typeof n;
      })(e.body)
    );
  }
  function Zl(e) {
    var t,
      n = s(Wl);
    try {
      for (n.s(); !(t = n.n()).done; ) {
        var i = b(t.value, 2),
          r = i[0],
          o = i[1];
        if (e.includes(r)) return o;
      }
    } catch (e) {
      n.e(e);
    } finally {
      n.f();
    }
    return "unknown";
  }
  function Jl(e) {
    return e.split("#")[0].split("?")[0];
  }
  function Ql(e, t) {
    return y(new Set([].concat(y(e), y(t))));
  }
  function Kl(e) {
    var t = Xl(e),
      n = (function (e) {
        var t, n, i, r;
        return null !==
          (r =
            null ===
              (i =
                null ===
                  (n =
                    null === (t = null == e ? void 0 : e.hbPlan) || void 0 === t
                      ? void 0
                      : t.uamPlan) || void 0 === n
                  ? void 0
                  : n.slots) || void 0 === i
              ? void 0
              : i.map(function (e) {
                  return e.slotDivId;
                })) && void 0 !== r
          ? r
          : [];
      })(e);
    return Ql(t, n);
  }
  function Xl(e) {
    var t, n, i, r;
    return null !==
      (r =
        null ===
          (i =
            null ===
              (n =
                null === (t = null == e ? void 0 : e.hbPlan) || void 0 === t
                  ? void 0
                  : t.prebidPlan) || void 0 === n
              ? void 0
              : n.slots) || void 0 === i
          ? void 0
          : i.map(function (e) {
              return e.slotDivId;
            })) && void 0 !== r
      ? r
      : [];
  }
  !(function (e) {
    (e.GPT_REQUEST = "GPT_REQUEST"),
      (e.GPT_RESPONSE = "GPT_RESPONSE"),
      (e.GPT_RENDERED = "GPT_RENDERED"),
      (e.GPT_LOADED = "GPT_LOADED"),
      (e.CANCELLED = "CANCELLED"),
      (e.SUPERSEDED = "SUPERSEDED");
  })(Vl || (Vl = {})),
    (function (e) {
      (e[(e.PREBID_REQUEST = 0)] = "PREBID_REQUEST"),
        (e[(e.PREBID_RESPONSE = 1)] = "PREBID_RESPONSE"),
        (e[(e.PREBID_SKIPPED = 2)] = "PREBID_SKIPPED"),
        (e[(e.UAM_REQUEST = 3)] = "UAM_REQUEST"),
        (e[(e.UAM_RESPONSE = 4)] = "UAM_RESPONSE"),
        (e[(e.UAM_SKIPPED = 5)] = "UAM_SKIPPED"),
        (e[(e.GPT_REQUEST = 6)] = "GPT_REQUEST"),
        (e[(e.CANCELLED = 7)] = "CANCELLED");
    })(Hl || (Hl = {}));
  for (var $l, ed = [], td = 0; td < 256; ++td)
    ed.push((td + 256).toString(16).slice(1));
  var nd = new Uint8Array(16);
  var id = {
    randomUUID:
      "undefined" != typeof crypto &&
      crypto.randomUUID &&
      crypto.randomUUID.bind(crypto),
  };
  function rd(e, t, n) {
    var i, r, o, a;
    if (id.randomUUID && !e) return id.randomUUID();
    var s =
      null !==
        (i =
          null !== (r = (e = e || {}).random) && void 0 !== r
            ? r
            : null === (o = (a = e).rng) || void 0 === o
            ? void 0
            : o.call(a)) && void 0 !== i
        ? i
        : (function () {
            if (!$l) {
              if ("undefined" == typeof crypto || !crypto.getRandomValues)
                throw new Error(
                  "crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported"
                );
              $l = crypto.getRandomValues.bind(crypto);
            }
            return $l(nd);
          })();
    if (s.length < 16) throw new Error("Random bytes length must be >= 16");
    return (
      (s[6] = (15 & s[6]) | 64),
      (s[8] = (63 & s[8]) | 128),
      (function (e) {
        var t =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
        return (
          ed[e[t + 0]] +
          ed[e[t + 1]] +
          ed[e[t + 2]] +
          ed[e[t + 3]] +
          "-" +
          ed[e[t + 4]] +
          ed[e[t + 5]] +
          "-" +
          ed[e[t + 6]] +
          ed[e[t + 7]] +
          "-" +
          ed[e[t + 8]] +
          ed[e[t + 9]] +
          "-" +
          ed[e[t + 10]] +
          ed[e[t + 11]] +
          ed[e[t + 12]] +
          ed[e[t + 13]] +
          ed[e[t + 14]] +
          ed[e[t + 15]]
        ).toLowerCase();
      })(s)
    );
  }
  var od = Symbol();
  function ad(e, t, n, i, r) {
    return u({}, od, function (o, a) {
      e[k](function () {
        return "[PLANNER]: Planning auction with ".concat(
          o
            .map(function (e) {
              return e.slotDivId;
            })
            .join(", ")
        );
      });
      var s,
        c,
        u,
        l,
        d = rd(),
        f = (function (t, n) {
          var i = n.sort(function (e, t) {
              var n = e.zoneDiv.getBoundingClientRect(),
                i = t.zoneDiv.getBoundingClientRect();
              return n.top - i.top;
            }),
            r = i.map(function (e) {
              return e.slotDivId;
            });
          return (
            e[k](function () {
              return "[PLANNER]["
                .concat(t, "]: Slot priority order: ")
                .concat(JSON.stringify(r));
            }),
            i
          );
        })(d, o),
        g = a.maxViewports
          ? (function (e, t) {
              var n = e.filter(function (e) {
                return e.zoneDiv.getBoundingClientRect().top < t;
              });
              return se(n) ? n : e;
            })(
              f,
              ((s = a.maxViewports),
              (c = n[mn]()),
              (u = c.offset),
              (l = c.innerHeight),
              u.y + l + l * s)
            )
          : f,
        m = (function (t, n, i, r) {
          var o = n.slice(0, i);
          if (
            !r.isFirstAuctionOfPage ||
            !o.some(function (e) {
              return e.isAdRequestHeld;
            })
          )
            return o;
          var a = n
            .filter(function (e) {
              return !e.isAdRequestHeld;
            })
            .slice(0, i);
          if (!se(a)) return o;
          if (
            !a.some(function (e) {
              return !e.manualDisplay;
            })
          )
            return o;
          var s = o.filter(function (e) {
            return e.isAdRequestHeld;
          }).length;
          return (
            e[A](
              "[PLANNER]["
                .concat(t, "]: Deferred ")
                .concat(s, " bid-ahead slots past the first auction")
            ),
            a
          );
        })(d, g, t.getAuctionMaxSlots(), a),
        v = (function (o, a, s) {
          var c = a.filter(function (e) {
            return e.allowHeaderBidding;
          });
          if (!se(c))
            return void e[k](
              "[AUCTION][".concat(
                o,
                "]: No headerbidding slots enabled for this auction"
              )
            );
          if (i())
            return void e[k](
              "[AUCTION][".concat(
                o,
                "]: Low dwell page detected, skipping headerbidding"
              )
            );
          var u = n[fn]().name,
            l = t.isUamEnabledAtBP(u),
            d = (function (n, i, o, a) {
              var s = "ready" === r[Tr].prebid._tag,
                c = t.getHbTimeout(i, a),
                u = t.isPrebidEnabledAtBP(i);
              if (!u)
                return void e[k](
                  "[AUCTION][".concat(
                    n,
                    "]: Excluded prebid from the auction because it is not configured"
                  )
                );
              if (!s)
                return void e[A](
                  "[AUCTION][".concat(
                    n,
                    "]: Prebid has not finished loading and will be excluded from the auction"
                  )
                );
              return { timeout: c, slots: o };
            })(o, u, c, s.isRefresh),
            f = (function (n, i, o) {
              var a = "ready" === r[Tr].uam._tag;
              if (!n)
                return void e[k](
                  "[AUCTION][".concat(
                    i,
                    "]: UAM has been excluded from the auction because it is not configured"
                  )
                );
              if (!a)
                return void e[A](
                  "[AUCTION][".concat(
                    i,
                    "]: UAM has not finished loading and will be excluded from the auction"
                  )
                );
              if (0 === o.length)
                return void e[k](
                  "[AUCTION][".concat(
                    i,
                    "]: UAM has been excluded from the auction because no headerbidding slots are enabled"
                  )
                );
              if (t.isForceSafeFrames())
                return void e[A](
                  "[AUCTION][".concat(
                    i,
                    "]: UAM disabled due to forceSafeFrames"
                  )
                );
              return { slots: o };
            })(l, o, c);
          if (!ae(d) && !ae(f))
            return void e[k](
              "[AUCTION][".concat(
                o,
                "]: No uam or prebid plan for this auction"
              )
            );
          var g = f ? 1e3 : 0,
            m = d ? d.timeout + 250 : 0;
          return { cancelTimeout: Math.max(g, m), prebidPlan: d, uamPlan: f };
        })(d, m, a);
      return Object.assign(
        { auctionId: d, breakpointName: n[fn]().name, hbPlan: v, slots: m },
        a.isRefresh
          ? {
              isRefresh: !0,
              lastGptAuction: a.lastGptAuction,
              nextGptAuction: t.isMinimumPerceivedRefreshEnabled()
                ? a.lastGptAuction +
                  1e3 *
                    t.getMinGptRefreshInterval(
                      t.getRefreshInterval(m[0].zoneTemplate)
                    )
                : void 0,
            }
          : {}
      );
    });
  }
  var sd = Symbol();
  function cd(e) {
    return {
      floors: {
        enforcement: { floorDeals: !1 },
        data: {
          currency: "USD",
          schema: { fields: ["adUnitCode"] },
          default: 0,
          values: Object.entries(e).reduce(function (e, t) {
            var n = b(t, 2),
              i = n[0],
              r = n[1];
            return Object.assign(
              Object.assign({}, e),
              u(
                {},
                i,
                r.reduce(function (e, t) {
                  return Math.max(t.cpm, e);
                }, 0)
              )
            );
          }, {}),
        },
      },
    };
  }
  function ud(e, t, n, i) {
    return u({}, sd, function (r) {
      if (t.isBidCacheFloorsEnabled() && $u(e)) {
        var o = cd(
          r.reduce(function (e, t) {
            return Object.assign(
              Object.assign({}, e),
              u({}, t, n.getUnrenderedValidBidsFromCache(t))
            );
          }, {})
        );
        i[k](function () {
          return "[PREBID][FLOORS]: pushing ".concat(
            JSON.stringify(o.floors.data.values)
          );
        }),
          e.setConfig(o);
      }
    });
  }
  var ld = Symbol(),
    dd = Symbol();
  function fd(e, t, n, i, r, o) {
    function a(i, o) {
      n[bi]("uam_initialise_start");
      var a = (function (e) {
        var t = {};
        e || (t.gdpr = { cmpTimeout: 0 });
        var n = r.getSco();
        !re(n) &&
          Object.getOwnPropertyNames(n).length &&
          (t.schain = {
            ver: "1.0",
            complete: 1,
            nodes: [{ asi: n.asi, sid: n.sellerId, hp: 1 }],
          });
        return Object.assign(
          { pubID: r.getUamSettings().pubID, adServer: "googletag" },
          t
        );
      })(i);
      t.apstag.init(a, function () {
        e[A](function () {
          return "[UAM]: Initialisation finished with config: ".concat(
            JSON.stringify(a)
          );
        }),
          n[bi]("uam_initialise_finish"),
          o();
      });
    }
    return u(
      u({}, ld, function (i, s, c) {
        if (
          (e[k]("[UAM]: Loading script"),
          n[bi]("uam_script_load_start"),
          (function (e, t, n, i, r, o) {
            if (!t[e]) {
              t[e] = {
                init: function () {
                  c("i", arguments);
                },
                fetchBids: function () {
                  c("f", arguments);
                },
                setDisplayBids: function () {},
                targetingKeys: function () {
                  return [];
                },
                _Q: [],
              };
              var a = n.createElement(i);
              (a.async = !0),
                (a.src = r),
                "function" == typeof o &&
                  (a.readyState
                    ? (a.onreadystatechange = function () {
                        ("loaded" !== a.readyState &&
                          "complete" !== a.readyState) ||
                          ((a.onreadystatechange = null), o());
                      })
                    : (a.onload = function () {
                        o();
                      }));
              var s = n.getElementsByTagName(i)[0];
              s.parentNode.insertBefore(a, s);
            }
            function c(n, i) {
              t[e]._Q.push([n, i]);
            }
          })(
            "apstag",
            t,
            t.document,
            "script",
            pa({
              name: "UAM",
              url: "//c.amazon-adsystem.com/",
              file: "aax2/apstag.js",
            }),
            function () {
              n[bi]("uam_script_load_finish"),
                s(),
                r.useCmpReadyEvent()
                  ? (e[k](
                      "[UAM]: Waiting for CMP ready event before configuring UAM"
                    ),
                    o[Zt].immediateOrOnce(function (t) {
                      e[k](
                        "[UAM]: CMP ready event received, reconfiguring UAM with consent data"
                      ),
                        r.isStrictCmp()
                          ? t.allowPersonalisation
                            ? (e[k](
                                "[UAM]: CMP is ready and personalisation is allowed, initialising UAM"
                              ),
                              a(i, c))
                            : (e[k](
                                "[UAM]: CMP is ready and personalisation is NOT allowed, skipping UAM initialisation"
                              ),
                              c(!0))
                          : a(i, c);
                    }))
                  : a(i, c);
            }
          ),
          !t.apstag)
        )
          return e[T]("[INIT]: UAM script load failed.");
      }),
      dd,
      function (n, r) {
        var o = n.hbPlan.uamPlan.slots.map(function (e) {
          return { slotID: e.slotDivId, slotName: e.path, sizes: e.sizesHb };
        });
        e[k](function () {
          return "[AUCTION]["
            .concat(n.auctionId, "]: Sending UAM request with slot details: ")
            .concat(JSON.stringify(o));
        }),
          t.apstag.fetchBids({ slots: o }, function (e) {
            i[Bc](function () {
              t.apstag.setDisplayBids(), r(e);
            });
          });
      }
    );
  }
  var gd = Symbol(),
    md = Symbol(),
    vd = Symbol(),
    pd = Symbol(),
    bd = Symbol(),
    hd = Symbol(),
    yd = Symbol(),
    Sd = Symbol(),
    Id = Symbol();
  function wd(e, t, n, i, r, o, a, c, l, d) {
    var f = (function (e, t) {
        var n = {},
          i = {};
        function r(e, t) {
          return n[e].slotStatus[t];
        }
        function o(t, r) {
          var o = i[t];
          if (o) return n[o].slotStatus[t];
          e[k](
            "[AUCTION-STATUS]["
              .concat(r, "]: Could not find active GPT call for ")
              .concat(t)
          );
        }
        function a(t) {
          var n = i[t];
          n
            ? (e[k](
                "[AUCTION]["
                  .concat(n, "]: Removed ")
                  .concat(t, " from GPT active list")
              ),
              delete i[t])
            : e[k](
                "[AUCTION]: Could not find ".concat(
                  t,
                  " in the GPT active list"
                )
              );
        }
        return {
          getAuctions: function () {
            return n;
          },
          getAuctionStatus: function (e) {
            return n[e];
          },
          getActiveGptCalls: function () {
            return Object.keys(i);
          },
          createNewAuction: function (e, i, r) {
            var o, a, s, c;
            n[e.auctionId] = {
              started: t[ri](),
              creativeDivIds:
                ((s = e),
                (c = "slotDivId"),
                s.slots.map(function (e) {
                  return e[c];
                })),
              hbDivIds: Kl(e),
              uamIncluded: ae(
                null === (o = e.hbPlan) || void 0 === o ? void 0 : o.uamPlan
              ),
              uamResponded: !1,
              uamSkipped: !1,
              prebidIncluded: ae(
                null === (a = e.hbPlan) || void 0 === a ? void 0 : a.prebidPlan
              ),
              prebidResponded: !1,
              prebidSkipped: !1,
              uamCancelled: !1,
              prebidCancelled: !1,
              gptRequestSent: !1,
              hasHeldAtStart: e.slots.some(function (e) {
                return e.isAdRequestHeld;
              }),
              auctionPhaseCallback: i,
              slotStatus: e.slots.reduce(function (e, t) {
                return Object.assign(
                  Object.assign({}, e),
                  u({}, t.slotDivId, {
                    slotPhaseCallback: function (e) {
                      return r(t, e);
                    },
                  })
                );
              }, {}),
            };
          },
          onPrebidRequest: function (e) {
            var i = n[e];
            (i.prebidRequestTime = t[ri]()),
              i.auctionPhaseCallback(Hl.PREBID_REQUEST);
          },
          onPrebidResponse: function (e) {
            var i = n[e];
            (i.prebidResponseTime = t[ri]()),
              (i.prebidResponded = !0),
              i.auctionPhaseCallback(Hl.PREBID_RESPONSE);
          },
          onPrebidSkipped: function (e) {
            var t = n[e];
            (t.prebidSkipped = !0), t.auctionPhaseCallback(Hl.PREBID_SKIPPED);
          },
          onUamRequest: function (e) {
            var i = n[e];
            (i.uamRequestTime = t[ri]()),
              i.auctionPhaseCallback(Hl.UAM_REQUEST);
          },
          onUamSkipped: function (e) {
            var t = n[e];
            (t.uamSkipped = !0), t.auctionPhaseCallback(Hl.UAM_SKIPPED);
          },
          onUamResponse: function (e) {
            var i = n[e];
            (i.uamResponseTime = t[ri]()),
              (i.uamResponded = !0),
              i.auctionPhaseCallback(Hl.UAM_RESPONSE);
          },
          cancelAuction: function (i, r) {
            var o = n[i];
            e[A](
              "[AUCTION][".concat(i, "]: Cancelled auction because ").concat(r)
            ),
              (o.cancelled = t[ri]()),
              (o.cancelledReason = r),
              o.auctionPhaseCallback(Hl.CANCELLED);
          },
          setSlotDisplayable: function (e, t) {
            var n = r(e, t);
            n && (n.isDisplayable = !0);
          },
          onGptRequest: function (o, a) {
            var c,
              u = s(a);
            try {
              for (u.s(); !(c = u.n()).done; ) {
                var l = c.value.slotDivId,
                  d = r(o, l);
                if (d) {
                  (d.gptRequestTime = t[ri]()),
                    d.slotPhaseCallback(Vl.GPT_REQUEST);
                  var f = i[l];
                  f &&
                    (e[E](
                      "[AUCTION]["
                        .concat(o, "]: ")
                        .concat(l, " is part of an uncompleted auction: ")
                        .concat(f, " and is marked superseded")
                    ),
                    (n[f].slotStatus[l].supersededTime = t[ri]()),
                    n[f].slotStatus[l].slotPhaseCallback(Vl.SUPERSEDED)),
                    (i[l] = o);
                }
              }
            } catch (e) {
              u.e(e);
            } finally {
              u.f();
            }
            (n[o].gptRequestSent = !0),
              n[o].auctionPhaseCallback(Hl.GPT_REQUEST);
          },
          onGptResponse: function (e) {
            var n = o(e, Vl.GPT_RESPONSE);
            n &&
              ((n.gptResponseTime = t[ri]()),
              n.slotPhaseCallback(Vl.GPT_RESPONSE));
          },
          onGptSlotRendered: function (e, n) {
            var i = o(e, Vl.GPT_RENDERED);
            i &&
              ((i.gptOnRenderTime = t[ri]()),
              n || a(e),
              i.slotPhaseCallback(Vl.GPT_RENDERED));
          },
          onGptSlotLoaded: function (e) {
            var n = o(e, Vl.GPT_LOADED);
            n &&
              ((n.gptOnLoadTime = t[ri]()),
              a(e),
              n.slotPhaseCallback(Vl.GPT_LOADED));
          },
          cancelSlotAuction: function (n, i, o) {
            e[A](
              "[AUCTION]["
                .concat(n, "]: Cancelled auction for ")
                .concat(i, " because ")
                .concat(o)
            );
            var s = r(n, i);
            s &&
              !ae(s.cancelledTime) &&
              ((s.cancelledTime = t[ri]()),
              a(i),
              s.slotPhaseCallback(Vl.CANCELLED));
          },
          removeFromGptActive: a,
        };
      })(i, r),
      g = !1,
      m = !1,
      v = !1,
      p = !1;
    function b(t) {
      var n = t.auctionId,
        a = e.excludeDeleted(t.slots, function (e) {
          f.cancelSlotAuction(n, e, "slot DOM element was deleted");
        }),
        s = o.isAbandonLazyAuctionEnabled()
          ? (function (e, t, n, i, r) {
              return t.filter(function (t) {
                var o = n(t.slotDivId) && i(t.slotDivId);
                return (
                  e[k](function () {
                    return "[AUCTION]: Slot "
                      .concat(t.slotDivId, " is lazy: ")
                      .concat(n(t.slotDivId), " and above viewport: ")
                      .concat(i(t.slotDivId));
                  }),
                  o &&
                    (e[k](
                      "[AUCTION]: Slot ".concat(
                        t.slotDivId,
                        " is lazy and above viewport, excluding"
                      )
                    ),
                    r(t.slotDivId)),
                  !o
                );
              });
            })(i, a, e.isLazy.bind(e), e.isAboveViewport.bind(e), function (e) {
              f.cancelSlotAuction(n, e, "slot DOM element aboveViewport");
            })
          : a;
      if (!se(s))
        return (
          i[C](
            "[AUCTION][".concat(n, "]: No slots to request, cancelling auction")
          ),
          void f.cancelAuction(n, "every slot was deleted or scrolled past")
        );
      var u = function (e) {
          var t;
          return (
            i[k](
              "[ACTION][".concat(
                n,
                "]: Filtering out delayed display slots from auction slots"
              )
            ),
            (function (e, t) {
              return e.filter(function (e) {
                var n;
                return (
                  !e.isAdRequestHeld &&
                  (!e.manualDisplay ||
                    (null === (n = null == t ? void 0 : t[e.slotDivId]) ||
                    void 0 === n
                      ? void 0
                      : n.isDisplayable))
                );
              });
            })(
              e,
              null === (t = f.getAuctions()[n]) || void 0 === t
                ? void 0
                : t.slotStatus
            )
          );
        },
        l = u(s);
      if (0 === l.length)
        return (
          i[C](
            "[AUCTION][".concat(
              n,
              "]: No non-delayed display slots to request, skipping GPT request"
            )
          ),
          void (
            f.getAuctionStatus(n).hasHeldAtStart &&
            f.cancelAuction(n, "ad request held")
          )
        );
      if (
        (i[C](function () {
          return "[AUCTION]["
            .concat(n, "]: Sending GPT request for slots: ")
            .concat(
              l
                .map(function (e) {
                  return e.slotDivId;
                })
                .join(", ")
            );
        }),
        f.onGptRequest(n, l),
        e.clearFuseSkins(),
        i[k]("Refreshing ads"),
        (function (e) {
          var t = e;
          return (
            (function (e) {
              return (
                !0 === (null == e ? void 0 : e.isRefresh) &&
                1 === e.slots.length
              );
            })(e) && void 0 !== t.nextGptAuction
          );
        })(t))
      ) {
        var d = t.nextGptAuction - r[ri]();
        i[k](function () {
          return "[AUCTION]["
            .concat(n, "][GPT-SCHEDULE]: Refreshing with perceived refresh ")
            .concat(t.nextGptAuction, " - ")
            .concat(r[ri](), " = ")
            .concat(d, "ms");
        }),
          d > 0
            ? (i[k](
                "[AUCTION]["
                  .concat(n, "][GPT-SCHEDULE]: Refreshing too soon, delay for ")
                  .concat(d, "ms")
              ),
              setTimeout(function () {
                c[Uc](n, u(t.slots));
              }, d))
            : (i[k](
                "[AUCTION][".concat(
                  n,
                  "][GPT-SCHEDULE]: No delay, refreshing immediately"
                )
              ),
              c[Uc](n, u(t.slots)));
      } else c[Uc](n, u(s));
    }
    function h(e, t, n) {
      var r = e.auctionId;
      i[C](
        "[AUCTION]["
          .concat(r, "]: Handling HB response from ")
          .concat(null != t ? t : "timeout")
      );
      var o = f.getAuctionStatus(r);
      if (o.gptRequestSent || void 0 !== o.cancelled)
        t &&
          (function (e, t, n) {
            n.gptRequestSent
              ? i[E](
                  "[AUCTION]["
                    .concat(e, "]: Received ")
                    .concat(t, " response after adserver request already sent")
                )
              : i[E](
                  "[AUCTION]["
                    .concat(e, "]: Received ")
                    .concat(t, " response after the auction was cancelled")
                );
          })(r, t, o);
      else {
        var a = o.prebidIncluded,
          s = o.uamIncluded;
        if (n) {
          var c = s ? o.uamResponded : "excluded",
            u = a ? o.prebidResponded : "excluded";
          i[E](
            "[AUCTION]["
              .concat(
                r,
                "]: Timeout reached with missing responses, sending to GPT. UAM responded="
              )
              .concat(c, ", Prebid responded=")
              .concat(u)
          ),
            b(e);
        } else
          s && a
            ? (o.uamResponded || o.uamCancelled) &&
              (o.prebidResponded || o.prebidCancelled)
              ? (i[A](
                  "[AUCTION][".concat(
                    r,
                    "]: All necessary responses received, sending to GPT"
                  )
                ),
                b(e))
              : i[k](
                  "[AUCTION]["
                    .concat(r, "]: Got response from ")
                    .concat(t, ", waiting for other responses")
                )
            : (i[k](
                "[AUCTION]["
                  .concat(r, "]: ")
                  .concat(t, " complete, calling GPT")
              ),
              b(e));
      }
    }
    function y(e) {
      i[k]("[AUCTION][".concat(e.auctionId, "]: Starting GPT-only auction")),
        b(e);
    }
    function S(e) {
      var t = e.slot.getSlotElementId();
      f.onGptSlotLoaded(t);
    }
    function I(e) {
      var t = e.slot.getSlotElementId();
      f.onGptResponse(t);
    }
    function w(t) {
      var n = !t.isEmpty,
        o = t.slot.getSlotElementId();
      i[k](function () {
        return "[AUCTION]: "
          .concat(o, " render event details: ")
          .concat(JSON.stringify(t));
      });
      var a = e.getSlot(o);
      if (a) {
        if (n)
          i[A]("[AUCTION]: Adserver responded with creative for ".concat(o));
        else {
          var s = {
            fuseSlotId: a.zoneTemplate.id,
            fuseSlotCode: o,
            errorType: "MISSING_CREATIVE",
          };
          r[ni](s),
            i[E](
              "[AUCTION]: Adserver responded without creative for ".concat(o)
            );
        }
        if (l && a.sizes) {
          var c = Ti(
              a.sizes.filter(function (e) {
                return wi(e);
              })
            ),
            u = Array.isArray(t.size) ? t.size : null;
          2 === (null == u ? void 0 : u.length) &&
            (u[1] > c[0] || u[1] > c[1]) &&
            (Ai(u[0], c[0]) > 50 || Ai(u[1], c[1]) > 50) &&
            (i[k](function () {
              return "[AUCTION]["
                .concat(o, "]: Received a rogue bid ")
                .concat(u, "  with mismatch maxArea ")
                .concat(c, " from adx: ")
                .concat(JSON.stringify(t));
            }),
            null == l || l[Qo](o, t, c));
        }
        f.onGptSlotRendered(o, n);
      } else e.isDeletedSlot(o) ? (i[A]("[AUCTION]: Slot Render Ended Event fired for deleted unit ".concat(o)), f.onGptSlotRendered(o, n)) : i[k]("[AUCTION]: SlotRenderEnded Event fired for non fuse units: ".concat(o, ". HasCreative: ").concat(n));
    }
    return (
      a[_t].subscribe(function (e) {
        S(e);
      }),
      a[kt].subscribe(function (e) {
        I(e);
      }),
      a[Et].subscribe(function (e) {
        w(e);
      }),
      a[Mt].subscribe(function (n) {
        var i;
        l[Ho](n, null !== (i = t.version) && void 0 !== i ? i : "unknown", e);
      }),
      a[Ut].subscribe(function (e) {
        l[Fo](e);
      }),
      a[jt].subscribe(function (e) {
        l[Go](e);
      }),
      u(
        u(
          u(
            u(
              u(
                u(
                  u(
                    u(u({}, gd, y), md, function (c, u, b) {
                      a[vt].emit(
                        Object.assign({ auctionEventType: "started" }, c)
                      ),
                        f.createNewAuction(c, u, b),
                        i[C](function () {
                          return "[AUCTION]["
                            .concat(c.auctionId, "]: Running with plan: ")
                            .concat(
                              (function (e) {
                                var t = e;
                                return JSON.stringify(
                                  Object.assign(
                                    {
                                      auctionId: e.auctionId,
                                      hbSettings: !!e.hbPlan && {
                                        cancelTimeout: e.hbPlan.cancelTimeout,
                                        usePrebid: !!e.hbPlan.prebidPlan && {
                                          timeout: e.hbPlan.prebidPlan.timeout,
                                          slots: e.hbPlan.prebidPlan.slots.map(
                                            function (e) {
                                              return e.slotDivId;
                                            }
                                          ),
                                        },
                                        useUam: !!e.hbPlan.uamPlan && {
                                          slots: e.hbPlan.uamPlan.slots.map(
                                            function (e) {
                                              return e.slotDivId;
                                            }
                                          ),
                                        },
                                      },
                                      gptSlots: e.slots.map(function (e) {
                                        return e.slotDivId;
                                      }),
                                      gpids: e.slots.map(function (e) {
                                        return e.gpid;
                                      }),
                                      breakpointName: e.breakpointName,
                                    },
                                    t.isRefresh
                                      ? {
                                          isRefresh: t.isRefresh,
                                          lastGptAuction: t.lastGptAuction,
                                          nextGtpAuction: t.nextGptAuction,
                                        }
                                      : {}
                                  )
                                );
                              })(c)
                            );
                        }),
                        o.isYandexEnabled()
                          ? (function (e) {
                              var t = e.auctionId,
                                n = o.getYandexBlockId();
                              n
                                ? (i[C](
                                    "[AUCTION]["
                                      .concat(t, "]: Run Yandex with blockId ")
                                      .concat(n)
                                  ),
                                  window.yaContextCb.push(function () {
                                    var o,
                                      a = s(e.slots);
                                    try {
                                      for (a.s(); !(o = a.n()).done; ) {
                                        var c = o.value,
                                          u = c.slotDivId,
                                          l = c.zoneTemplateId,
                                          d = Number(
                                            l.substring(7) +
                                              u.substring(
                                                u.lastIndexOf("-") + 1
                                              )
                                          );
                                        i[C](
                                          "[AUCTION]["
                                            .concat(t, "][")
                                            .concat(u, "]: Set pageNumber ")
                                            .concat(d)
                                        ),
                                          Ya.Context.AdvManager.render({
                                            renderTo: "".concat(u),
                                            blockId: n,
                                            pageNumber: d,
                                            onRender: function () {
                                              r[bi]("yandex_unit_rendered");
                                            },
                                          });
                                      }
                                    } catch (e) {
                                      a.e(e);
                                    } finally {
                                      a.f();
                                    }
                                  }))
                                : i[T](
                                    "[AUCTION][".concat(
                                      t,
                                      "]: Cannot run Yandex cause yandexBlockId is not set"
                                    )
                                  );
                            })(c)
                          : (function (e) {
                              return void 0 !== e.hbPlan;
                            })(c)
                          ? (function (o) {
                              var a = o.auctionId,
                                c = (function (e) {
                                  var t;
                                  return ae(
                                    null ===
                                      (t = null == e ? void 0 : e.hbPlan) ||
                                      void 0 === t
                                      ? void 0
                                      : t.prebidPlan
                                  );
                                })(o);
                              c &&
                                (function (n) {
                                  var o = Xl(n),
                                    a = n.auctionId;
                                  r[hi](
                                    "prebid_request_".concat(JSON.stringify(o)),
                                    { auctionId: a }
                                  ),
                                    i[A](function () {
                                      return "[AUCTION]["
                                        .concat(a, "]: Requesting prebid for: ")
                                        .concat(JSON.stringify(o));
                                    }),
                                    g ||
                                      ((g = !0), r[bi]("first_prebid_request"));
                                  var c = t;
                                  d[sd](o),
                                    c.requestBids({
                                      auctionId: a,
                                      adUnitCodes: o,
                                      timeout: n.hbPlan.prebidPlan.timeout,
                                      bidsBackHandler: function (t, u) {
                                        var d;
                                        f.onPrebidResponse(a);
                                        var g = t ? Object.keys(t) : [];
                                        if (
                                          (i[A](function () {
                                            return "[AUCTION]["
                                              .concat(
                                                a,
                                                "]: Prebid auction complete. Any-bidder-timeout?="
                                              )
                                              .concat(u, ". Responding slots: ")
                                              .concat(JSON.stringify(g));
                                          }),
                                          g.length > 0)
                                        ) {
                                          if (
                                            (i[k](function () {
                                              return "[AUCTION]["
                                                .concat(
                                                  a,
                                                  "]: Prebid response details: "
                                                )
                                                .concat(JSON.stringify(t));
                                            }),
                                            l)
                                          ) {
                                            var m = function (n) {
                                              var r = e.getSlot(n);
                                              if (
                                                null ===
                                                  (d =
                                                    null == r
                                                      ? void 0
                                                      : r.sizesHb) ||
                                                void 0 === d
                                                  ? void 0
                                                  : d.length
                                              ) {
                                                var o,
                                                  c = Ti(r.sizesHb),
                                                  u = s(t[n].bids);
                                                try {
                                                  var f = function () {
                                                    var e = o.value;
                                                    (e.width > c[0] ||
                                                      e.height > c[1]) &&
                                                      (i[k](function () {
                                                        return "[AUCTION]["
                                                          .concat(a, "][")
                                                          .concat(
                                                            n,
                                                            "]: Received a rogue bid "
                                                          )
                                                          .concat(e.width, "x")
                                                          .concat(
                                                            e.height,
                                                            "  with mismatch maxArea "
                                                          )
                                                          .concat(c, " from ")
                                                          .concat(
                                                            e.bidder,
                                                            ": "
                                                          )
                                                          .concat(
                                                            JSON.stringify(e)
                                                          );
                                                      }),
                                                      null == l ||
                                                        l[Jo](n, e, c));
                                                  };
                                                  for (
                                                    u.s();
                                                    !(o = u.n()).done;

                                                  )
                                                    f();
                                                } catch (e) {
                                                  u.e(e);
                                                } finally {
                                                  u.f();
                                                }
                                              }
                                            };
                                            for (var p in t) m(p);
                                          }
                                        } else
                                          i[E](
                                            "[AUCTION][".concat(
                                              a,
                                              "]: No bid responses received from prebid"
                                            )
                                          );
                                        r[hi](
                                          "prebid_response_".concat(
                                            JSON.stringify(g)
                                          ),
                                          { auctionId: a }
                                        ),
                                          v ||
                                            ((v = !0),
                                            r[bi]("first_prebid_response"));
                                        try {
                                          c.setTargetingForGPTAsync(o),
                                            h(n, "prebid", !1);
                                        } catch (e) {
                                          var b = os(e);
                                          i[T](
                                            "[AUCTION]["
                                              .concat(a, "]: ")
                                              .concat(b.message, " ")
                                              .concat(b.stack)
                                          );
                                        }
                                      },
                                    });
                                })(o);
                              var u = (function (e) {
                                var t;
                                return ae(
                                  null ===
                                    (t = null == e ? void 0 : e.hbPlan) ||
                                    void 0 === t
                                    ? void 0
                                    : t.uamPlan
                                );
                              })(o);
                              u &&
                                (function (e) {
                                  var t = e.auctionId,
                                    o = e.hbPlan.uamPlan.slots,
                                    a = JSON.stringify(
                                      o.map(function (e) {
                                        return e.slotDivId;
                                      })
                                    );
                                  i[A](
                                    "[AUCTION]["
                                      .concat(
                                        e.auctionId,
                                        "]: Sending UAM request for "
                                      )
                                      .concat(a)
                                  ),
                                    r[hi]("uam_request_".concat(a), {
                                      auctionId: t,
                                    }),
                                    m || ((m = !0), r[bi]("first_uam_request")),
                                    n[dd](e, function (n) {
                                      i[A](
                                        "[AUCTION][".concat(
                                          t,
                                          "]: Received UAM response"
                                        )
                                      ),
                                        i[k](function () {
                                          return "[AUCTION]["
                                            .concat(
                                              t,
                                              "]: UAM response details:  "
                                            )
                                            .concat(JSON.stringify(n));
                                        }),
                                        r[hi]("uam_response_".concat(a), {
                                          auctionId: t,
                                        }),
                                        p ||
                                          ((p = !0),
                                          r[bi]("first_uam_response")),
                                        f.onUamResponse(t),
                                        h(e, "uam", !1);
                                    });
                                })(o);
                              var b =
                                  c && !f.getAuctionStatus(a).prebidCancelled,
                                S = u && !f.getAuctionStatus(a).uamCancelled;
                              b || S
                                ? (r[pi](),
                                  (function (e) {
                                    i[k](
                                      "[AUCTION]["
                                        .concat(
                                          e.auctionId,
                                          "]: Set auction failure timeout of "
                                        )
                                        .concat(e.hbPlan.cancelTimeout, "ms")
                                    ),
                                      setTimeout(function () {
                                        return h(e, void 0, !0);
                                      }, e.hbPlan.cancelTimeout);
                                  })(o))
                                : y(o);
                            })(c)
                          : y(c);
                    }),
                    vd,
                    function (e, t) {
                      if (
                        (i[C](
                          "[AUCTION]["
                            .concat(e, "][")
                            .concat(
                              t.slotDivId,
                              "]: Handling delayed display slot"
                            )
                        ),
                        t.manualDisplay)
                      ) {
                        var n = f.getAuctions()[e];
                        if (n) {
                          var r = n.slotStatus[t.slotDivId];
                          if (r)
                            if (r.gptRequestTime)
                              i[T](
                                "[AUCTION]["
                                  .concat(e, "][")
                                  .concat(
                                    t.slotDivId,
                                    "]: displayZone called after GPT request already sent, cancelling manual displayZone()"
                                  )
                              );
                            else {
                              if (n.uamIncluded || n.prebidIncluded) {
                                if (
                                  !(
                                    n.uamResponded ||
                                    n.uamCancelled ||
                                    n.prebidResponded ||
                                    n.prebidCancelled
                                  )
                                )
                                  return (
                                    i[E](
                                      "[AUCTION]["
                                        .concat(e, "][")
                                        .concat(
                                          t.slotDivId,
                                          "]: Auction currently in process for delayed display zone. Marking zone as displayable"
                                        )
                                    ),
                                    void f.setSlotDisplayable(e, t.slotDivId)
                                  );
                                i[C](
                                  "[AUCTION]["
                                    .concat(e, "][")
                                    .concat(
                                      t.slotDivId,
                                      "]: Either UAM or Prebid completed, proceeding to displayZone"
                                    )
                                );
                              }
                              f.onGptRequest(e, [t]), c[Uc](e, [t]);
                            }
                          else
                            i[T](
                              "[AUCTION]["
                                .concat(e, "][")
                                .concat(
                                  t.slotDivId,
                                  "]: displayZone called on non-existing slot in auction"
                                )
                            );
                        } else
                          i[T](
                            "[AUCTION]["
                              .concat(e, "][")
                              .concat(
                                t.slotDivId,
                                "]: displayZone called on non-existing auction"
                              )
                          );
                      } else
                        i[T](
                          "[AUCTION]["
                            .concat(e, "][")
                            .concat(
                              t.slotDivId,
                              "]: displayZone called on non-manual display slot"
                            )
                        );
                    }
                  ),
                  pd,
                  function (t) {
                    var n,
                      r = t.slotDivId;
                    if (!t.isAdRequestHeld)
                      return (
                        i[E](
                          "[AUCTION][".concat(
                            r,
                            "]: Release called on a slot that is not held"
                          )
                        ),
                        { needsAuction: !1 }
                      );
                    var o = _d(f.getAuctions(), t);
                    if ((e.clearAdRequestHold(r), !o))
                      return (
                        i[C](
                          "[AUCTION][".concat(
                            r,
                            "]: Hold cleared, but the slot has never been in an auction"
                          )
                        ),
                        { needsAuction: !0 }
                      );
                    var a = f.getAuctions()[o];
                    return ae(
                      null === (n = a.slotStatus[r]) || void 0 === n
                        ? void 0
                        : n.gptRequestTime
                    )
                      ? (i[E](
                          "[AUCTION]["
                            .concat(o, "][")
                            .concat(
                              r,
                              "]: Release after the GPT request was already sent"
                            )
                        ),
                        { needsAuction: !1 })
                      : a.gptRequestSent || ae(a.cancelled)
                      ? (i[C](
                          "[AUCTION]["
                            .concat(o, "][")
                            .concat(r, "]: Sending the held GPT request")
                        ),
                        f.onGptRequest(o, [t]),
                        c[Uc](o, [t]),
                        { needsAuction: !1 })
                      : (i[C](
                          "[AUCTION]["
                            .concat(o, "][")
                            .concat(
                              r,
                              "]: Hold cleared, the in-flight auction will request the slot"
                            )
                        ),
                        { needsAuction: !1 });
                  }
                ),
                bd,
                function (e, t) {
                  var n = e.slotDivId;
                  if (e.isAdRequestHeld) {
                    var r = _d(f.getAuctions(), e);
                    r
                      ? (i[C](
                          "[AUCTION]["
                            .concat(r, "][")
                            .concat(n, "]: Abandoning the held slot because ")
                            .concat(t)
                        ),
                        f.cancelSlotAuction(r, n, t))
                      : i[C](
                          "[AUCTION][".concat(
                            n,
                            "]: Held slot abandoned, it has never been in an auction"
                          )
                        );
                  } else
                    i[E](
                      "[AUCTION][".concat(
                        n,
                        "]: Abandon called on a slot that is not held"
                      )
                    );
                }
              ),
              hd,
              S
            ),
            yd,
            I
          ),
          Sd,
          w
        ),
        Id,
        function () {
          return f;
        }
      )
    );
  }
  function _d(e, t) {
    var n,
      i,
      r = Object.entries(e)
        .filter(function (e) {
          var n;
          return null === (n = b(e, 2)[1].creativeDivIds) || void 0 === n
            ? void 0
            : n.includes(t.slotDivId);
        })
        .sort(function (e, t) {
          var n = b(e, 2)[1];
          return b(t, 2)[1].started - n.started;
        });
    return null !== (i = null === (n = r[0]) || void 0 === n ? void 0 : n[0]) &&
      void 0 !== i
      ? i
      : null;
  }
  var Ed = Symbol(),
    kd = Symbol(),
    Cd = Symbol(),
    Td = Symbol(),
    Ad = Symbol(),
    Rd = Symbol(),
    xd = Symbol(),
    Pd = Symbol(),
    Od = Symbol(),
    Dd = Symbol(),
    Nd = Symbol();
  function zd(e, t, n, i, r, o, a) {
    var s,
      c = [],
      l = {},
      d = [],
      f = null,
      g = null,
      m = !1,
      v = !0;
    function p(t) {
      var n = r[fn]().name,
        i = t.filter(function (t) {
          return o.isSlotEnabledForBreakpoint(t.zoneTemplate, n)
            ? t.currentlyActive
              ? t.zoneTemplate.attributes.afs
                ? (e[A](
                    "[SCHEDULER]: Skipped ".concat(
                      t.slotDivId,
                      " because it is AFS slot"
                    )
                  ),
                  !1)
                : !b(t) ||
                  (e[k](
                    "[SCHEDULER]: Skipped ".concat(
                      t.slotDivId,
                      " because it is already scheduled"
                    )
                  ),
                  !1)
              : (e[A](
                  "[SCHEDULER]: Skipped ".concat(
                    t.slotDivId,
                    " because it is hasn't activated"
                  )
                ),
                !1)
            : (e[k](
                "[SCHEDULER]: Skipped "
                  .concat(
                    t.slotDivId,
                    " because no sizes mapped at the current breakpoint ("
                  )
                  .concat(n, ")")
              ),
              !1);
        });
      if (i.length > 0) {
        var a = i.map(function (e) {
          return e.slotDivId;
        });
        e[A]("[SCHEDULER]: Added ".concat(a, " to auction queue")),
          i.forEach(function (e) {
            return c.push(e);
          });
      }
    }
    function b(e) {
      return (
        c.filter(function (t) {
          return t.slotDivId === e.slotDivId;
        }).length > 0
      );
    }
    function h(e, t) {
      return (e.zoneTemplate.originalZoneTemplateId || e.zoneTemplate.id) === t;
    }
    function y() {
      var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
        s = arguments.length > 1 ? arguments[1] : void 0,
        u = (c = c.filter(function (t) {
          return (
            !i.isDeletedSlot(t.slotDivId) ||
            (e[A](
              "[SCHEDULER]: Removed deleted slot ".concat(
                t.slotDivId,
                " from queue"
              )
            ),
            !1)
          );
        }));
      if (!se(u))
        return (
          e[C]("[SCHEDULER]: Auction will not run because no slots are queued"),
          []
        );
      var l = I();
      if (l.length > 0) {
        if (f) {
          var d = c.map(function (e) {
            return e.slotDivId;
          });
          return (
            e[A](
              "[SCHEDULER] Deferred the auction for "
                .concat(
                  JSON.stringify(d),
                  " because slots missing from the auction block: "
                )
                .concat(JSON.stringify(l))
            ),
            (g = !0),
            []
          );
        }
      } else f && (e[A]("[SCHEDULER]: Auction block cleared, as requirements satisfied "), w());
      var p = n[od](
        u,
        Object.assign(
          {
            maxViewports: m ? void 0 : o.getMaxViewportsFirstAuction(),
            isFirstAuctionOfPage: v,
          },
          t ? { isRefresh: !0, lastGptAuction: s } : { isRefresh: !1 }
        )
      );
      if (!m) {
        var b = r[mn](),
          h = b.offset.y + b.innerHeight,
          y = c.filter(function (e) {
            return (
              !e.isAdRequestHeld && e.zoneDiv.getBoundingClientRect().top < h
            );
          });
        a[cu]("zone_count_above_vp", y.length.toString());
      }
      return (
        (c = c.filter(function (e) {
          return -1 === p.slots.indexOf(e);
        })),
        e[C](
          "[SCHEDULER]: Starting auction with "
            .concat(p.slots.length, " slots, ")
            .concat(c.length, " slots remaining")
        ),
        S(p),
        p.slots.map(function (e) {
          return e.slotDivId;
        })
      );
    }
    function S(n) {
      (m = !0),
        (v = !1),
        t[md](
          n,
          function (t) {
            t === Hl.CANCELLED &&
              !l[n.auctionId] &&
              c.length > 0 &&
              (e[k](
                "[SCHEDULER][".concat(
                  n.auctionId,
                  "]: The auction ended without a GPT request, initiating the next auction"
                )
              ),
              y().length > 0 && (l[n.auctionId] = !0));
          },
          function (t, i) {
            return (function (t, n) {
              n !== Vl.GPT_LOADED ||
                l[t] ||
                ((l[t] = !0),
                c.length > 0 &&
                  (e[k](
                    "[SCHEDULER][".concat(
                      t,
                      "]: The first slot has received a gpt-loaded event, initiating the next auction"
                    )
                  ),
                  y()));
            })(n.auctionId, i);
          }
        );
    }
    function I() {
      return d.filter(function (e) {
        return !(
          (function (e) {
            return (
              void 0 !==
              c.find(function (t) {
                return h(t, e);
              })
            );
          })(e) ||
          (function (e) {
            var t = i.getActiveSlots().find(function (t) {
              return h(t, e);
            });
            return !!t && t.zoneTemplate.attributes.afs;
          })(e)
        );
      });
    }
    function w() {
      (d = []), (g = null), f && clearTimeout(f), (f = null);
    }
    return (
      u(
        u(
          u(
            u(
              u(
                u(
                  u(
                    u(
                      u(
                        u((s = {}), Ed, function (e, t) {
                          p([e]), y(!0, t);
                        }),
                        kd,
                        p
                      ),
                      Cd,
                      b
                    ),
                    Td,
                    y
                  ),
                  Ad,
                  function (t) {
                    var i = n[od]([t], { isRefresh: !1 });
                    e[C](
                      "[SCHEDULER]["
                        .concat(i.auctionId, "]: Forcing auction for ")
                        .concat(t.slotDivId)
                    ),
                      S(i);
                  }
                ),
                Rd,
                function () {
                  w(), (c = []), (v = !0);
                }
              ),
              xd,
              function () {
                c = [];
              }
            ),
            Pd,
            function (t, n) {
              (d = t.filter(function (t) {
                var n = o.getZoneTemplate(t);
                if (!n)
                  return (
                    e[E](
                      "[SLOTS][".concat(
                        t,
                        "]: Excluded from next-auction slot requirement, because the slot does not exist in this tag"
                      )
                    ),
                    !1
                  );
                if (n.excludeFromAuctionBlock)
                  return (
                    e[E](
                      "[SLOTS][".concat(
                        t,
                        "]: Excluded from next-auction slot requirement, because the slot has an activation condition"
                      )
                    ),
                    !1
                  );
                var i = r[fn]().name;
                return (
                  !!o.isSlotEnabledForBreakpoint(n, i) ||
                  (e[A](
                    "[SLOTS]["
                      .concat(
                        t,
                        "]: Excluded from next-auction slot requirement, because it is not enabled at the "
                      )
                      .concat(i, " breakpoint")
                  ),
                  !1)
                );
              })).length > 0
                ? (e[A](
                    "[SCHEDULER]: Enabled auction block. Will not proceed until Zones with FuseIds "
                      .concat(JSON.stringify(d), " are registered, or ")
                      .concat(n, "ms have elapsed")
                  ),
                  (f = setTimeout(function () {
                    g
                      ? (e[E](
                          "[SCHEDULER]: Auction block timeout reached, missing: ".concat(
                            JSON.stringify(I()),
                            ". Running deferred auction"
                          )
                        ),
                        w(),
                        y())
                      : (I().length > 0 &&
                          e[E](
                            "[SCHEDULER]: Auction block timeout reached, missing: ".concat(
                              I()
                            )
                          ),
                        w());
                  }, n)))
                : e[A](
                    "[SCHEDULER]: Did not enable AuctionBlock, because no (valid) slots specified"
                  );
            }
          ),
          Od,
          I
        ),
        Dd,
        function () {
          return m;
        }
      ),
      u(s, Nd, w)
    );
  }
  var Bd = Symbol(),
    Md = Symbol(),
    Ud = Symbol(),
    jd = Symbol(),
    Ld = Symbol(),
    Fd = Symbol(),
    Gd = Symbol(),
    Vd = Symbol(),
    Hd = Symbol();
  var qd = (function (e) {
      function t(e, n, o, a, s, c, u, l, d) {
        var f;
        return (
          r(this, t),
          ((f = i(this, t, [
            e,
            n,
            a,
            s,
            c,
            u,
            d.isRefreshPrebidTimeoutBuffering,
            d.prebidRefreshTimeoutMs,
          ])).triggerAuction = o),
          (f.minOnScreenDuration = l),
          (f.refreshSettings = d),
          (f.CHECK_INTERVAL = 500),
          (f.onScreenDuration = 0),
          (f.hasReceivedImpressionViewable = !1),
          (f.lastImpressionViewableTimestamp = 0),
          (f.impressionViewableEventHandle = function () {
            return f.handleImpressionViewableEvent();
          }),
          f.logger[k](
            "[REFRESH]: ViewportRefreshStrategy initialized for slot "
              .concat(f.slot.slotDivId, ", interval: ")
              .concat(f.refreshInterval)
          ),
          (f.impressionViewableEventStream = f.createFilteredObservable(
            c[Tt],
            e
          )),
          f.impressionViewableEventStream.subscribe(
            f.impressionViewableEventHandle
          ),
          f
        );
      }
      return (
        f(t, e),
        a(t, [
          {
            key: "getInfo",
            value: function () {
              return {
                strategyName: "ViewportRefreshStrategy",
                isRefreshEnabled: this.isRefreshEnabled,
                lastGptRequestTimestamp: this.lastGptRequestTimestamp,
                refreshInterval: this.refreshInterval,
              };
            },
          },
          {
            key: "destroy",
            value: function () {
              this.impressionViewableEventStream.unsubscribe(
                this.impressionViewableEventHandle
              ),
                this.resetCounter(),
                (this.lastImpressionViewableTimestamp = 0),
                h(t, "destroy", this)([]);
            },
          },
          {
            key: "resetCounter",
            value: function () {
              (this.onScreenDuration = 0),
                (this.lastRefreshTimestamp = Date.now()),
                (this.hasReceivedImpressionViewable = !1);
            },
          },
          {
            key: "shouldSkipRefresh",
            value: function () {
              return this.isRefreshEnabled
                ? this.isRefreshCapped(this.refreshSettings)
                  ? (this.logger[C](
                      "[REFRESH]: Not refreshing "
                        .concat(
                          this.slot.slotDivId,
                          " because it reached the max refresh count of "
                        )
                        .concat(this.refreshSettings.maxRefreshCount)
                    ),
                    this.destroy(),
                    !0)
                  : !!this.isRefreshBlocked() ||
                    (!this.slot.isInDom() &&
                      (this.logger[E](
                        "[REFRESH]: Could not refresh ".concat(
                          this.slot.slotDivId,
                          " because a div with that id was not found in the DOM"
                        )
                      ),
                      !0))
                : (this.logger[C](
                    "[REFRESH]: Not refreshing ".concat(
                      this.slot.slotDivId,
                      " because refresh is disabled"
                    )
                  ),
                  !0);
            },
          },
          {
            key: "setRefreshTimer",
            value: function () {
              var e = this,
                t = this.slot.slotDivId;
              this.refreshTimer &&
                (this.logger[E](
                  "[REFRESH]: Refresh timer already set for ".concat(
                    t,
                    ". Clearing it."
                  )
                ),
                clearInterval(this.refreshTimer)),
                (this.refreshTimer = setInterval(function () {
                  e.processRefresh();
                }, this.CHECK_INTERVAL));
            },
          },
          {
            key: "scheduleRefresh",
            value: function (e) {
              this.refreshTimer
                ? this.logger[k](
                    "[REFRESH]: Slot "
                      .concat(
                        this.slot.slotDivId,
                        " is already scheduled. eventName: "
                      )
                      .concat(e)
                  )
                : ((this.lastRefreshTimestamp = Date.now()),
                  this.setRefreshTimer());
            },
          },
          {
            key: "handleSlotRenderEvent",
            value: function () {
              (this.onScreenDuration = 0),
                this.scheduleRefresh("slotRenderEnded");
            },
          },
          {
            key: "handleSlotLoadEvent",
            value: function () {
              (this.onScreenDuration = 0), this.scheduleRefresh("slotOnLoad");
            },
          },
          {
            key: "handleImpressionViewableEvent",
            value: function () {
              var e = this,
                t = Date.now(),
                n = this.lastImpressionViewableTimestamp;
              (this.lastImpressionViewableTimestamp = t),
                (this.hasReceivedImpressionViewable = !0),
                this.logger[k](function () {
                  var i = e.formatElapsedSeconds(t, n);
                  return "[REFRESH]: Received impression viewable event for slot "
                    .concat(e.slot.slotDivId, " (")
                    .concat(i, " since last viewable)");
                });
            },
          },
          {
            key: "getRequestedLogContextExtras",
            value: function (e) {
              return ", ".concat(
                this.formatElapsedSeconds(
                  e,
                  this.lastImpressionViewableTimestamp
                ),
                " since last impression viewable"
              );
            },
          },
          {
            key: "processRefresh",
            value: function () {
              var e = this;
              if (
                !this.isCycleGateClosed() &&
                this.slot.zoneDiv &&
                this.slot.isInView() &&
                ((this.onScreenDuration += this.CHECK_INTERVAL),
                (this.hasReceivedImpressionViewable ||
                  !(this.onScreenDuration < this.minOnScreenDuration)) &&
                  !this.shouldSkipRefresh())
              ) {
                var t = Date.now();
                this.logger[C](function () {
                  return "[REFRESH]: Slot "
                    .concat(
                      e.slot.slotDivId,
                      " meets the conditions durationSinceLastRefresh: "
                    )
                    .concat(t - e.lastRefreshTimestamp, ", onScreenDuration: ")
                    .concat(
                      e.onScreenDuration,
                      ", hasReceivedImpressionViewable: "
                    )
                    .concat(
                      e.hasReceivedImpressionViewable,
                      " and will trigger auction."
                    );
                }),
                  (this.lastRefreshTimestamp = t);
                try {
                  this.triggerAuction(
                    this.slot,
                    this.getLastGptRequestElapsedTime()
                  ),
                    (this.lastAuctionTriggerTimestamp = t);
                } catch (t) {
                  this.logger[E](function () {
                    return "[REFRESH]: "
                      .concat(
                        e.slot.slotDivId,
                        " Refresh triggerAuction failed with "
                      )
                      .concat(JSON.stringify(t));
                  });
                } finally {
                  this.resetCounter();
                }
              }
            },
          },
        ])
      );
    })(Ii),
    Wd = (function (e) {
      function t(e, n, o, a, s, c, u, l, d) {
        var f;
        return (
          r(this, t),
          ((f = i(this, t, [
            e,
            n,
            a,
            s,
            c,
            u,
            d.isRefreshPrebidTimeoutBuffering,
            d.prebidRefreshTimeoutMs,
          ])).triggerAuction = o),
          (f.minOnScreenDuration = l),
          (f.refreshSettings = d),
          (f.lastImpressionViewableTimestamp = 0),
          (f.isCurrentlyVisible = !1),
          (f.lastBecameVisibleTimestamp = 0),
          (f.accumulatedVisibleDurationMs = 0),
          (f.impressionViewableEventHandle = function () {
            return f.handleImpressionViewableEvent();
          }),
          (f.slotVisibilityChangedEventHandle = function (e) {
            return f.handleSlotVisibilityChangedEvent(e);
          }),
          f.logger[k](
            "[REFRESH]: ActiveViewRefreshStrategy initialized for slot "
              .concat(f.slot.slotDivId, ", interval: ")
              .concat(f.refreshInterval, ", minOnScreenDuration: ")
              .concat(f.minOnScreenDuration)
          ),
          (f.impressionViewableEventStream = f.createFilteredObservable(
            c[Tt],
            e
          )),
          f.impressionViewableEventStream.subscribe(
            f.impressionViewableEventHandle
          ),
          (f.slotVisibilityChangedEventStream = f.createFilteredEventObservable(
            c[At],
            e
          )),
          f.slotVisibilityChangedEventStream.subscribe(
            f.slotVisibilityChangedEventHandle
          ),
          f
        );
      }
      return (
        f(t, e),
        a(t, [
          {
            key: "getInfo",
            value: function () {
              return {
                strategyName: "ActiveViewRefreshStrategy",
                isRefreshEnabled: this.isRefreshEnabled,
                lastGptRequestTimestamp: this.lastGptRequestTimestamp,
                refreshInterval: this.refreshInterval,
              };
            },
          },
          {
            key: "destroy",
            value: function () {
              this.impressionViewableEventStream.unsubscribe(
                this.impressionViewableEventHandle
              ),
                this.slotVisibilityChangedEventStream.unsubscribe(
                  this.slotVisibilityChangedEventHandle
                ),
                this.initialWaitTimeout &&
                  (clearTimeout(this.initialWaitTimeout),
                  (this.initialWaitTimeout = null)),
                (this.lastImpressionViewableTimestamp = 0),
                (this.isCurrentlyVisible = !1),
                (this.lastBecameVisibleTimestamp = 0),
                (this.accumulatedVisibleDurationMs = 0),
                h(t, "destroy", this)([]);
            },
          },
          {
            key: "shouldSkipRefresh",
            value: function () {
              return this.isRefreshEnabled
                ? this.isRefreshCapped(this.refreshSettings)
                  ? (this.logger[C](
                      "[REFRESH]: Not refreshing "
                        .concat(
                          this.slot.slotDivId,
                          " because it reached the max refresh count of "
                        )
                        .concat(this.refreshSettings.maxRefreshCount)
                    ),
                    this.destroy(),
                    !0)
                  : !!this.isRefreshBlocked() ||
                    (!this.slot.isInDom() &&
                      (this.logger[E](
                        "[REFRESH]: Could not refresh ".concat(
                          this.slot.slotDivId,
                          " because a div with that id was not found in the DOM"
                        )
                      ),
                      !0))
                : (this.logger[C](
                    "[REFRESH]: Not refreshing ".concat(
                      this.slot.slotDivId,
                      " because refresh is disabled"
                    )
                  ),
                  !0);
            },
          },
          {
            key: "getInitialWaitMs",
            value: function () {
              return Math.max(
                0,
                1e3 * this.refreshInterval - this.getPreFireOffsetMs()
              );
            },
          },
          {
            key: "startInitialWait",
            value: function () {
              var e = this,
                t = this.slot.slotDivId;
              this.initialWaitTimeout &&
                (this.logger[E](
                  "[REFRESH]: Initial wait timeout already set for ".concat(
                    t,
                    ". Clearing it."
                  )
                ),
                clearTimeout(this.initialWaitTimeout)),
                (this.initialWaitTimeout = setTimeout(function () {
                  e.startPolling();
                }, this.getInitialWaitMs()));
            },
          },
          {
            key: "startPolling",
            value: function () {
              var e = this;
              (this.initialWaitTimeout = null),
                this.logger[k](
                  "[REFRESH]: Slot ".concat(
                    this.slot.slotDivId,
                    " initial wait elapsed, starting refresh poll"
                  )
                ),
                (this.refreshTimer = setInterval(function () {
                  e.processRefresh();
                }, t.CHECK_INTERVAL));
            },
          },
          {
            key: "scheduleNextCycle",
            value: function () {
              var e = this;
              this.refreshTimer &&
                (clearInterval(this.refreshTimer), (this.refreshTimer = null)),
                this.initialWaitTimeout &&
                  clearTimeout(this.initialWaitTimeout),
                (this.initialWaitTimeout = setTimeout(function () {
                  e.startPolling();
                }, this.getInitialWaitMs()));
            },
          },
          {
            key: "scheduleRefresh",
            value: function (e) {
              this.refreshTimer || this.initialWaitTimeout
                ? this.logger[k](
                    "[REFRESH]: Slot "
                      .concat(
                        this.slot.slotDivId,
                        " is already scheduled. eventName: "
                      )
                      .concat(e)
                  )
                : ((this.lastRefreshTimestamp = Date.now()),
                  this.startInitialWait());
            },
          },
          {
            key: "handleSlotRenderEvent",
            value: function () {
              this.isCurrentlyVisible &&
                (this.lastBecameVisibleTimestamp = Date.now()),
                this.scheduleRefresh("slotRenderEnded");
            },
          },
          {
            key: "handleSlotLoadEvent",
            value: function () {
              this.isCurrentlyVisible &&
                (this.lastBecameVisibleTimestamp = Date.now()),
                this.scheduleRefresh("slotOnLoad");
            },
          },
          {
            key: "handleImpressionViewableEvent",
            value: function () {
              var e = this,
                t = Date.now(),
                n = this.lastImpressionViewableTimestamp;
              (this.lastImpressionViewableTimestamp = t),
                this.logger[k](function () {
                  var i =
                    n > 0 ? "".concat(((t - n) / 1e3).toFixed(2), "s") : "n/a";
                  return "[REFRESH]: Received impression viewable event for slot "
                    .concat(e.slot.slotDivId, " (")
                    .concat(i, " since last viewable)");
                });
            },
          },
          {
            key: "handleSlotVisibilityChangedEvent",
            value: function (e) {
              var n = e.inViewPercentage >= t.VIEWABLE_THRESHOLD,
                i = this.isCurrentlyVisible,
                r = Date.now();
              n && !i
                ? (this.lastBecameVisibleTimestamp = r)
                : !n &&
                  i &&
                  (this.accumulatedVisibleDurationMs +=
                    r - this.lastBecameVisibleTimestamp),
                (this.isCurrentlyVisible = n),
                n && !i && this.processRefresh();
            },
          },
          {
            key: "getCurrentVisibleDuration",
            value: function () {
              var e = this.isCurrentlyVisible
                ? Date.now() - this.lastBecameVisibleTimestamp
                : 0;
              return this.accumulatedVisibleDurationMs + e;
            },
          },
          {
            key: "processRefresh",
            value: function () {
              var e = this;
              if (
                !this.isCycleGateClosed() &&
                this.isCurrentlyVisible &&
                !(
                  this.lastImpressionViewableTimestamp <=
                    this.lastGptRequestTimestamp ||
                  this.getCurrentVisibleDuration() < this.minOnScreenDuration ||
                  this.shouldSkipRefresh()
                )
              ) {
                var t = Date.now(),
                  n = this.getCurrentVisibleDuration(),
                  i =
                    this.lastImpressionViewableTimestamp > 0
                      ? "".concat(
                          (
                            (t - this.lastImpressionViewableTimestamp) /
                            1e3
                          ).toFixed(2),
                          "s"
                        )
                      : "n/a";
                this.logger[C](function () {
                  return "[REFRESH]: Slot "
                    .concat(
                      e.slot.slotDivId,
                      " meets the conditions durationSinceLastRefresh: "
                    )
                    .concat(
                      t - e.lastRefreshTimestamp,
                      ", accumulatedVisibleDuration: "
                    )
                    .concat(n, ", minOnScreenDuration: ")
                    .concat(e.minOnScreenDuration, ", ")
                    .concat(
                      i,
                      " since last impression viewable and will trigger auction."
                    );
                }),
                  (this.lastRefreshTimestamp = t);
                try {
                  this.triggerAuction(
                    this.slot,
                    this.getLastGptRequestElapsedTime()
                  ),
                    (this.lastAuctionTriggerTimestamp = t);
                } catch (t) {
                  this.logger[E](function () {
                    var n = t instanceof Error ? t.message : JSON.stringify(t);
                    return "[REFRESH]: "
                      .concat(
                        e.slot.slotDivId,
                        " Refresh triggerAuction failed with "
                      )
                      .concat(n);
                  });
                } finally {
                  this.resetVisibilityClock(), this.scheduleNextCycle();
                }
              }
            },
          },
          {
            key: "resetVisibilityClock",
            value: function () {
              (this.accumulatedVisibleDurationMs = 0),
                this.isCurrentlyVisible &&
                  (this.lastBecameVisibleTimestamp = Date.now());
            },
          },
        ])
      );
    })(Ii);
  (Wd.VIEWABLE_THRESHOLD = 50), (Wd.CHECK_INTERVAL = 1e3);
  var Yd = (function () {
      return a(
        function e(t, n) {
          r(this, e),
            (this.slot = t),
            (this.logger = n),
            this.debug(
              "[REFRESH]: NoRefreshStrategy initialized for slot ".concat(
                this.slot.slotDivId
              )
            );
        },
        [
          {
            key: "debug",
            value: function (e) {
              this.logger && this.logger[k](e);
            },
          },
          {
            key: "getInfo",
            value: function () {
              return {
                strategyName: "NoRefreshStrategy",
                isRefreshEnabled: !1,
              };
            },
          },
          {
            key: "destroy",
            value: function () {
              this.debug(
                "[REFRESH]: NoRefreshStrategy destroy called for slot ".concat(
                  this.slot.slotDivId,
                  ", no action taken."
                )
              );
            },
          },
          {
            key: "disableRefresh",
            value: function () {
              this.debug(
                "[REFRESH]: NoRefreshStrategy disableRefresh called for slot ".concat(
                  this.slot.slotDivId,
                  ", no action taken."
                )
              );
            },
          },
          {
            key: "enableRefresh",
            value: function () {
              this.debug(
                "[REFRESH]: NoRefreshStrategy enableRefresh called for slot ".concat(
                  this.slot.slotDivId,
                  ", no action taken."
                )
              );
            },
          },
        ]
      );
    })(),
    Zd = Symbol(),
    Jd = Symbol(),
    Qd = Symbol(),
    Kd = Symbol(),
    Xd = Symbol(),
    $d = Symbol(),
    ef = Symbol();
  function tf(e, t, n, i, r, o) {
    e[C]("[REFRESH]: Initializing RefreshManager");
    var a = {};
    return (
      r[Vt].subscribe(function (s) {
        var c, u;
        a[s.slot.slotDivId] =
          ((c = s.slot),
          ne((u = n.getRefreshInterval(c.zoneTemplate))) && u > 0
            ? n.isActiveViewRefreshEnabled()
              ? (e[k](
                  "[SLOTS]: Using ActiveViewRefreshStrategy for slot ".concat(
                    c.slotDivId
                  )
                ),
                new Wd(
                  c,
                  u,
                  i[Ed].bind(i),
                  e,
                  t,
                  r,
                  o,
                  n.getMinOnScreenDurationMs(),
                  {
                    isRefreshPrebidTimeoutBuffering:
                      n.isRefreshPrebidTimeoutBuffering(),
                    prebidRefreshTimeoutMs: n.getPrebidRefreshTimeoutMs(),
                    isUseRefreshCap: n.isUseRefreshCapEnabled(),
                    maxRefreshCount: n.getMaxRefreshCount(),
                  }
                ))
              : (e[k](
                  "[SLOTS]: Using ViewportRefreshStrategy for slot ".concat(
                    c.slotDivId
                  )
                ),
                new qd(
                  c,
                  u,
                  i[Ed].bind(i),
                  e,
                  t,
                  r,
                  o,
                  n.getMinOnScreenDurationMs(),
                  {
                    isRefreshPrebidTimeoutBuffering:
                      n.isRefreshPrebidTimeoutBuffering(),
                    prebidRefreshTimeoutMs: n.getPrebidRefreshTimeoutMs(),
                    isUseRefreshCap: n.isUseRefreshCapEnabled(),
                    maxRefreshCount: n.getMaxRefreshCount(),
                  }
                ))
            : (e[k](
                "[SLOTS]: Using NoOpRefreshStrategy for slot ".concat(
                  c.slotDivId
                )
              ),
              new Yd(c, e)));
      }),
      r[qt].subscribe(function (e) {
        !(function (e) {
          var t;
          null === (t = a[e]) || void 0 === t || t.destroy(), delete a[e];
        })(e.slotDivId);
      }),
      u(
        u(
          u(
            u(
              u(
                u(
                  u({}, Zd, function (e) {
                    var t;
                    null === (t = a[e]) || void 0 === t || t.disableRefresh();
                  }),
                  Jd,
                  function (e) {
                    var t;
                    null === (t = a[e]) || void 0 === t || t.enableRefresh();
                  }
                ),
                Qd,
                function () {
                  for (var e = 0, t = Object.keys(a); e < t.length; e++) {
                    var n = t[e];
                    a[n].destroy();
                  }
                }
              ),
              Kd,
              function () {
                for (var e = 0, t = Object.keys(a); e < t.length; e++) {
                  var n = t[e];
                  a[n].disableRefresh();
                }
              }
            ),
            Xd,
            function () {
              for (var e = 0, t = Object.keys(a); e < t.length; e++) {
                var n = t[e];
                a[n].enableRefresh();
              }
            }
          ),
          $d,
          function () {
            return Object.entries(a)
              .filter(function (e) {
                return (
                  "NoRefreshStrategy" !== b(e, 2)[1].getInfo().strategyName
                );
              })
              .reduce(function (e, t) {
                var n = b(t, 2),
                  i = n[0],
                  r = n[1],
                  o = Object.assign({}, e);
                return (o[i] = r.getInfo()), o;
              }, {});
          }
        ),
        ef,
        function () {
          Object.keys(a).forEach(function (e) {
            a[e].destroy();
          }),
            (a = {});
        }
      )
    );
  }
  var nf = Symbol(),
    rf = Symbol(),
    of = Symbol(),
    af = Symbol(),
    sf = Symbol(),
    cf = Symbol(),
    uf = Symbol(),
    lf = Symbol(),
    df = Symbol(),
    ff = Symbol(),
    gf = Symbol(),
    mf = Symbol(),
    vf = Symbol(),
    pf = Symbol(),
    bf = Symbol(),
    hf = Symbol();
  function yf(e, t, n, i, r, o, a) {
    var s,
      c = function (e) {
        i[kd](e), g();
      };
    function l(e, t, n) {
      var o = f(r[Il](e), n, t),
        a = o.filter(Ll).filter(function (e) {
          return e.currentlyActive;
        });
      return i[kd](a), o;
    }
    function d(e, t, n) {
      var i = l(e, t, n);
      return g(), i;
    }
    function f(n, i, r) {
      return (
        n.forEach(function (e) {
          t[Bd](e);
        }),
        e[Pl](n, i, r, c)
      );
    }
    function g() {
      return o.isTagInitialised()
        ? i[Td]()
        : (n[A](
            "[CONTROLLER] Deferred the auction start until the tag is initialised"
          ),
          !1);
    }
    return (
      u(
        u(
          u(
            u(
              u(
                u(
                  u(
                    u(u(u((s = {}), nf, l), rf, d), of, function (e, t, n, o) {
                      var a = r[wl](e, t);
                      if (!a) return null;
                      var s = f(a, o, n);
                      return (
                        s.forEach(function (e) {
                          (null == e ? void 0 : e.currentlyActive) &&
                            i[kd]([e]);
                        }),
                        s
                      );
                    }),
                    af,
                    function (e) {
                      t[Ud](e);
                    }
                  ),
                  sf,
                  function (e, t, n, o) {
                    var a = r[_l](e, t);
                    if (a) {
                      var s = f([a], o, n)[0];
                      return (
                        (null == s ? void 0 : s.currentlyActive) && i[kd]([s]),
                        s
                      );
                    }
                  }
                ),
                cf,
                g
              ),
              uf,
              function (t) {
                var r = e.getSlot(t);
                r && r.currentlyActive
                  ? r.isAdRequestHeld
                    ? n[E](
                        "[CONTROLLER]: Could not force auction because slot ".concat(
                          t,
                          " is holding its GAM request"
                        )
                      )
                    : i[Ad](r)
                  : n[E](
                      "[CONTROLLER]: Could not force auction because slot ".concat(
                        t,
                        " not found or is inactive"
                      )
                    );
              }
            ),
            lf,
            function () {
              i[kd](
                e.getActiveSlots().filter(function (e) {
                  return !e.isAdRequestHeld;
                })
              ),
                g();
            }
          ),
          df,
          function () {
            var r =
              arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            n[C]("[CONTROLLER]: resetSlots()"), e[Tl](r), i[Rd](), t[Fd]();
          }
        ),
        ff,
        function (i) {
          t[Gd](i);
          var r = e[Rl](i);
          r
            ? e[xl](r.slotDivId)
            : n[k](
                "[CONTROLLER] Registered slot for zoneDivId ".concat(
                  i,
                  " not found upon deletion"
                )
              );
        }
      ),
      u(
        u(
          u(
            u(
              u(
                u(s, gf, function () {
                  a[Qd]();
                }),
                mf,
                function () {
                  a[Xd]();
                }
              ),
              vf,
              function () {
                return a[$d]();
              }
            ),
            pf,
            function () {
              i[xd](), i[Nd](), a[Qd]();
              var t = e.getActiveSlots();
              i[kd](t), i[Td]();
            }
          ),
          bf,
          function (e, t, i) {
            if (!e)
              return (
                n[E](
                  "[CONTROLLER]: loadSlots() called during initialisation. Translating call to _registerSlots() to avoid reset"
                ),
                void d(!0, !1, t)
              );
            i(), l(!1, !1, t), g();
          }
        ),
        hf,
        function () {
          e.destroySticky();
        }
      )
    );
  }
  var Sf = Symbol();
  function If(e, t, n, i) {
    var r = Object.create(null);
    return (
      i[gt].subscribe(function () {
        r = Object.create(null);
      }),
      u({}, Sf, function (i, o) {
        var a;
        if (!o || "none" === i.via) return !1;
        var s = t.getSlot(i.slotDivId);
        if (!(null == s ? void 0 : s.currentlyActive) || s.isAdRequestHeld)
          return (
            e[k](
              "[HEAVY-AD]: Not re-requesting ".concat(
                i.slotDivId,
                ": slot is gone, inactive or holding its request"
              )
            ),
            !1
          );
        var c = null !== (a = r[i.slotDivId]) && void 0 !== a ? a : 0;
        if (c >= 3)
          return (
            e[k](
              "[HEAVY-AD]: Not re-requesting ".concat(
                i.slotDivId,
                ": per-slot retry budget spent for this pageview"
              )
            ),
            !1
          );
        (r[i.slotDivId] = c + 1), t[Ul](i.slotDivId);
        try {
          return (
            e[k](
              "[HEAVY-AD]: Re-requesting "
                .concat(i.slotDivId, " (attempt ")
                .concat(c + 1, ")")
            ),
            n[uf](i.slotDivId),
            !0
          );
        } catch (n) {
          return (
            t[jl](i.slotDivId),
            e[T](
              "[HEAVY-AD]: Failed to re-request "
                .concat(i.slotDivId, ": ")
                .concat(Gl(n))
            ),
            !1
          );
        }
      })
    );
  }
  var wf = "data-fuse-slot",
    _f = "div[data-fuse]",
    Ef = { slotDivId: void 0, zoneCode: void 0, via: "none" };
  function kf(e, t) {
    var n = e.getSlot(t);
    return (null == n ? void 0 : n.slotDivId) === t ? n : void 0;
  }
  function Cf(e, t, n) {
    var i = e
      ? (function (e, t) {
          var n,
            i,
            r = e.closest(".fuse-slot");
          if (r) {
            var o = r.id ? kf(t, r.id) : void 0;
            return o ? { slot: o, anchor: "fuse-slot" } : void 0;
          }
          var a =
              null === (n = e.closest("[".concat(wf, "]"))) || void 0 === n
                ? void 0
                : n.getAttribute(wf),
            s = a ? kf(t, a) : void 0;
          if (s) return { slot: s, anchor: "slot-attr" };
          var c = null === (i = e.closest(_f)) || void 0 === i ? void 0 : i.id,
            u = c ? t[Rl](c) : void 0;
          return (null == u ? void 0 : u.slotDivId)
            ? { slot: u, anchor: "zone-div-id" }
            : void 0;
        })(e, n)
      : void 0;
    return i
      ? {
          slotDivId: i.slot.slotDivId,
          zoneCode: i.slot.zoneTemplateId,
          via: "".concat(t, ":").concat(i.anchor),
        }
      : Ef;
  }
  function Tf(e, t, n) {
    var i = n.frameId,
      r = n.frameUrl,
      o = i
        ? (function (e, t) {
            var n = e.getElementById(t);
            return "IFRAME" === (null == n ? void 0 : n.tagName) ? n : void 0;
          })(e, i)
        : void 0;
    return o
      ? Cf(o, "frame-id", t)
      : r && "about:blank" !== r
      ? Cf(
          (function (e, t) {
            var n,
              i = e.querySelectorAll("iframe"),
              r = 0;
            return (
              i.forEach(function (e) {
                e.src === t && (r++, (n = e));
              }),
              1 === r && (null == n ? void 0 : n.closest(_f)) ? n : void 0
            );
          })(e, r),
          "iframe-url",
          t
        )
      : Ef;
  }
  var Af = Symbol();
  function Rf(e, t, n, i, r, o, a) {
    var c = !1;
    function l(n, s) {
      if (Yl(n)) {
        var c,
          u,
          l,
          d,
          f,
          g,
          m,
          v,
          p =
            ((c = n.body.message),
            (u = c.trim().slice(0, 2e3)),
            (l = ql.exec(u)),
            (d = (null == l ? void 0 : l[2]) || void 0),
            (f = d ? Jl(d) : void 0),
            (g = (null == l ? void 0 : l[1]) ? Jl(l[1]) : void 0),
            (m = l ? u.slice(0, l.index) : u),
            (v = l
              ? ""
                  .concat(m, "(id=")
                  .concat(null != g ? g : "", ";url=")
                  .concat(null != f ? f : "", ")")
              : u),
            {
              wasRemoved: m.startsWith("Ad was removed"),
              reason: Zl(m),
              frameId: g,
              frameUrl: d,
              reportableFrameUrl: f,
              raw: v.slice(0, 500),
            }),
          b = Tf(t.document, o, p),
          h = b.slotDivId ? a[Un](b.slotDivId) : void 0;
        e[k](function () {
          var e;
          return (
            "[HEAVY-AD]: "
              .concat(p.reason, " intervention (removed=")
              .concat(p.wasRemoved, ") on ") +
            ""
              .concat(
                null !== (e = b.slotDivId) && void 0 !== e
                  ? e
                  : "an unresolved slot",
                " ("
              )
              .concat(b.via, ", refreshes=")
              .concat(null != h ? h : "n/a", ")")
          );
        });
        var y = !s && r[Sf](b, p.wasRemoved);
        i[Ko]({
          raw: p.raw,
          reason: p.reason,
          wasRemoved: p.wasRemoved,
          via: b.via,
          frameId: p.frameId,
          reportableFrameUrl: p.reportableFrameUrl,
          slotId: b.slotDivId,
          zoneCode: b.zoneCode,
          refreshCount: h,
          refreshed: y,
        });
      }
    }
    function d(t, n) {
      try {
        l(t, n);
      } catch (t) {
        e[T](
          "[HEAVY-AD]: Failed to handle intervention report: ".concat(Gl(t))
        );
      }
    }
    function f(t, n) {
      try {
        var i,
          r = s(t);
        try {
          for (r.s(); !(i = r.n()).done; ) {
            d(i.value, n);
          }
        } catch (e) {
          r.e(e);
        } finally {
          r.f();
        }
      } catch (t) {
        e[T]("[HEAVY-AD]: Failed to read intervention reports: ".concat(Gl(t)));
      }
    }
    return u({}, Af, function () {
      if (!c && n.isHeavyAdRefreshEnabled())
        if ("function" == typeof t.ReportingObserver)
          try {
            var i = new t.ReportingObserver(
              function (e) {
                return f(e, !1);
              },
              { buffered: !0, types: ["intervention"] }
            );
            i.observe(),
              (c = !0),
              t.addEventListener("pagehide", function () {
                try {
                  f(i.takeRecords(), !0);
                } catch (t) {
                  e[T](
                    "[HEAVY-AD]: Failed to flush intervention reports on pagehide: ".concat(
                      Gl(t)
                    )
                  );
                }
              });
          } catch (t) {
            e[T](
              "[HEAVY-AD]: Failed to observe intervention reports: ".concat(
                Gl(t)
              )
            );
          }
        else
          e[k](
            "[HEAVY-AD]: ReportingObserver unavailable, heavy ad detection disabled"
          );
    });
  }
  function xf(e, t, n, i, r) {
    t[Wt].subscribe(function (t) {
      var o = t.slot.slotDivId;
      n[pd](t.slot).needsAuction
        ? (e[C](
            "[SLOTS][".concat(
              o,
              "]: Released the held slot, queueing an auction for it"
            )
          ),
          i[kd]([t.slot]),
          r[cf]())
        : e[C](
            "[SLOTS][".concat(o, "]: Released the held slot, no auction needed")
          );
    }),
      t[Yt].subscribe(function (e) {
        n[bd](e.slot, e.reason);
      });
  }
  function Pf(e, t) {
    var n = t;
    return (
      e.immediateOrOnce(function (e) {
        return (n = e);
      }),
      {
        get value() {
          return n;
        },
        asSupplier: function () {
          return function () {
            return n;
          };
        },
      }
    );
  }
  var Of = Symbol(),
    Df = Symbol(),
    Nf = Symbol(),
    zf = Symbol(),
    Bf = Symbol();
  function Mf(e, t) {
    if (!e || !t) return !1;
    var n = new URL(e),
      i = new URL(t);
    return (n.hash = ""), (i.hash = ""), n.toString() == i.toString();
  }
  function Uf(e, t, n, i, r, o, a, s, c) {
    var l = null,
      d = Pf(o[lt]),
      f = null,
      g = !1;
    function m() {
      (g = !0),
        e[A]("[PAGE]: bfcache restore detected, will reset on next pageInit");
    }
    function v() {
      e[A]("[PAGE]: Resetting all page state"),
        n(),
        o[gt].emit({ breakpoint: a().name });
    }
    function p(e) {
      (null == e ? void 0 : e.pageTargets) &&
        r[uu](null == e ? void 0 : e.pageTargets);
    }
    function b(e) {
      return (
        s.getLowDwellPages().filter(function (t) {
          var n = e.match(t);
          return n && n.length > 0;
        }).length > 0
      );
    }
    function h(e, t) {
      var n = Object.assign(
        {
          url: e,
          isPageTransition: t,
          isLowDwellPage: b(e),
          breakpoint: a().name,
        },
        f ? { afsPageParams: f } : {}
      );
      o[ft].emit(n);
    }
    return (
      o[lt].immediateOrOnce(function (e) {
        h(e.tagInitUrl, !1);
      }),
      s.isBfcachePageResetEnabled() &&
        c.addEventListener("pageshow", function (e) {
          e.persisted && m();
        }),
      u(
        u(
          u(
            u(u({}, Of, v), Df, function (n, r, o) {
              var a;
              e[A](function () {
                return "[PAGE]: pageInit('"
                  .concat(n, "', ")
                  .concat(r, ", ")
                  .concat(JSON.stringify(o));
              });
              var c = g;
              g = !1;
              var u,
                m = null === l,
                b = ae(d.value),
                y = !1;
              if (m)
                if (b)
                  if (Mf(n, t)) {
                    if (i[Dd]())
                      return (
                        p(o),
                        void e[E](
                          "[PAGE]: Not resetting, because URL unchanged since tag init"
                        )
                      );
                    e[A](
                      "[PAGE]: Late pageInit() call, will apply PageTargeting and run auction"
                    ),
                      (y = !0),
                      (u = !1);
                  } else
                    e[A](
                      "[PAGE]: First pageInit() call, and URL changed since tag init. Resetting."
                    ),
                      v(),
                      (u = !0);
                else u = !1;
              else if (
                (function (e, t, n) {
                  return n || !Mf(e, t);
                })(n, l, c)
              )
                e[A](
                  "[PAGE]: ".concat(
                    (function (e) {
                      return e ? "bfcache restore detected" : "URL has changed";
                    })(c),
                    ", treating as navigation. Resetting."
                  )
                ),
                  (u = !0),
                  v();
              else {
                if (!(null == o ? void 0 : o.forceReset))
                  return (
                    p(o),
                    void e[E](
                      "[PAGE]: Not resetting, because URL unchanged since last pageInit call"
                    )
                  );
                e[k]("[PAGE]: pageInit call with forceReset=true. Resetting."),
                  (u = !1),
                  v();
              }
              (l = n),
                p(o),
                (null == o ? void 0 : o.blockingFuseIds) &&
                  (function (t, n, r, o) {
                    var a = r ? t : t - o;
                    if (a <= 0)
                      e[A](
                        "[PAGE][pageInit]: Skipped setting auction block, because there is no time left on the timeout"
                      );
                    else {
                      var c = n.map(function (e) {
                        return "".concat(e);
                      });
                      s.isSpaOldBlockingPageInit() || i[Pd](c, a);
                    }
                  })(
                    null !== (a = null == o ? void 0 : o.blockingTimeout) &&
                      void 0 !== a
                      ? a
                      : 2e3,
                    o.blockingFuseIds,
                    u,
                    r
                  ),
                (null == o ? void 0 : o.afsPageParams) && (f = o.afsPageParams),
                b && !y && h(n, !0);
            }),
            Nf,
            function () {
              return ae(l);
            }
          ),
          zf,
          b
        ),
        Bf,
        m
      )
    );
  }
  function jf(e) {
    return {
      getZoneTemplate: function (t) {
        return e.getZoneTemplate(t);
      },
      setDisableWidgetRenderer: function (t) {
        e.getV2CompatOverrides().disableWidgetsRenderer = t;
      },
      setForceSafeFrames: function (t) {
        e.setForceSafeFrames(t);
      },
      isUseBackwardCompatibleNaming: function () {
        return e.isUseBackwardCompatibleNaming();
      },
    };
  }
  function Lf(e, t, n, i, r, o, a, s, c, u, l, d) {
    var f = jf(t);
    function g() {
      e[k]("[APIV3]: registerAll() started");
      var t = n[rf](!0, !1, m);
      e[k](
        "[APIV3]: registerAll() finished, ".concat(t.length, " slots found")
      );
    }
    var m = {
      breakpointSupplierName: function () {
        return c[fn]().name;
      },
      getWindow: function () {
        return u;
      },
      getFuseBot: function () {
        var e,
          n = null === (e = t.getCfConfig()) || void 0 === e ? void 0 : e.bot;
        return n ? Object.assign({}, n) : void 0;
      },
      processNewSlots: function () {
        return g();
      },
      registerAll: g,
      registerZone: function (t) {
        e[k]("[APIV3]: registerZone('".concat(t, "') started"));
        var i = n[of](t, !0, !1, m);
        return i && n[cf](), i;
      },
      queueZone: function (t) {
        return (
          e[k]("[APIV3]: queueZone('".concat(t, "') started")),
          n[of](t, !0, !1, m)
        );
      },
      runAuction: function () {
        return e[k]("[APIV3]: runAuction() started"), n[cf]();
      },
      disableRefreshByZone: function (e) {
        return d[Zd](e);
      },
      enableRefreshByZone: function (e) {
        return d[Jd](e);
      },
      getSlotsForTemplateId: function (e) {
        return i.getSlotsForTemplateId(e);
      },
      setAllowedSafeFrameBidders: function (t) {
        Array.isArray(t) &&
        t.every(function (e) {
          return "string" == typeof e;
        })
          ? (l.setAllowedSafeFrameBidders(t),
            e[k](
              "[APIV3]: The following bidders have been added to safeframe compatible bidders: ".concat(
                t
              )
            ))
          : e[k](
              "[APIV3]: Unable to set allowed safe frame bidders, invalid input"
            );
      },
      destroySticky: function () {
        n[hf]();
      },
      isUseBackwardCompatibleNaming: function () {
        return f.isUseBackwardCompatibleNaming();
      },
      events: s,
      settings: f,
      slotRegistry: i,
      zoneRegistry: r,
      insertConditionFactory: o,
      slotConditionFactory: a,
      viewportInfo: c,
    };
    return m;
  }
  function Ff(e, t, n) {
    return {
      breakpointSupplierName: function () {
        return n[fn]().name;
      },
      settings: jf(e),
      getSlotsForTemplateId: function (e) {
        return t.getSlotsForTemplateId(e);
      },
      viewportInfo: n,
    };
  }
  var Gf = Symbol();
  function Vf(e, t, n, i, r) {
    var o = {};
    return (
      i[Et].subscribe(function (i) {
        var r,
          a = i.slot.getSlotElementId(),
          s = n[Al]()[a],
          c = e.document.getElementById(a);
        if (s) {
          var u = {
              creativeId: i.creativeId,
              advertiserId: i.advertiserId,
              lineItemId: i.lineItemId,
              orderId: i.campaignId,
              respSizes: i.size,
              reqSizes: s.sizeMapping[t().name],
              googleQueryId:
                null !==
                  (r =
                    null == c
                      ? void 0
                      : c.getAttribute("data-google-query-id")) && void 0 !== r
                  ? r
                  : null,
            },
            l = o[a];
          re(l) || 0 == l.length
            ? (o[a] = [u])
            : 1 == l.length
            ? (o[a] = [].concat(y(l), [u]))
            : 2 == l.length && (o[a] = [].concat(y(l.slice(1)), [u]));
        }
      }),
      u({}, Gf, function (t, n) {
        var i = {
          email: null == n ? void 0 : n.email,
          url: e.location.href,
          datetimeStamp: new Date().toLocaleString(),
          slots: o,
        };
        if (null == n ? void 0 : n.authHeader)
          return r(t, {
            method: "POST",
            mode: "cors",
            headers: {
              "Content-Type": "application/json",
              Authorization: n.authHeader,
            },
            body: JSON.stringify(i),
          })
            .then(function () {
              e.alert("Blocking request sent.");
            })
            .catch(function () {
              e.alert(
                "Error occurred while sending blocking request. Please reach out to the customer support team."
              );
            });
        r(t, {
          method: "POST",
          mode: "no-cors",
          headers: {
            "Content-Type": "application/json",
            Authorization: (null == n ? void 0 : n.authHeader) || "",
          },
          body: JSON.stringify(i),
        }),
          e.alert(
            "Blocking request sent. Please reach out to the customer support team to update your bookmarklet"
          );
      })
    );
  }
  var Hf = Symbol();
  function qf() {
    var e = [
      "ix",
      "pubmatic",
      "rubicon",
      "connectad",
      "33across",
      "amx",
      "stroeerCore",
      "nobid",
      "optidigital",
      "vidazoo",
      "adagio",
      "criteo",
      "medianet",
      "onetag",
      "openx",
      "smartadserver",
      "sonobi",
      "sovrn",
      "appnexus",
      "msft",
      "ttd",
    ];
    function t(e, t) {
      var n = e.filter(function (e) {
        return !t.some(function (t) {
          var n = b(t, 2),
            i = n[0],
            r = n[1];
          return i === e[0] && r === e[1];
        });
      });
      return 0 === n.length;
    }
    return u({}, Hf, function (n, i, r, o) {
      return "triplelift" === n.bidder
        ? (function (e, n, i) {
            if (
              !e.params.inventoryCode ||
              !/^.+_\d+x\d+$/.test(e.params.inventoryCode)
            )
              return !0;
            if (((r = i), ("xs" === r || "s" === r) && t(n, [[300, 250]])))
              return !0;
            var r;
            return t(n, [
              [970, 250],
              [300, 600],
            ]);
          })(n, i, r)
        : !!(function (t) {
            return [].concat(e, y(t));
          })(o).includes(n.bidder);
    });
  }
  var Wf = ["account", "contract", "constant", "zone"],
    Yf = ["mandatory", "optional"];
  function Zf(e, t) {
    return "appnexus" === e && Mi(t, "v7") ? "msft" : e;
  }
  function Jf(e, t, n, i, r) {
    var o;
    try {
      var a = Qf(e, n, i, r),
        s = (function (e, t, n) {
          var i, r, o, a;
          try {
            var s;
            try {
              s = Object.assign(Object.assign({}, t.getNetworkParams()), {
                zone:
                  null !==
                    (r =
                      null === (i = e.zoneTemplate) || void 0 === i
                        ? void 0
                        : i.networkZoneParameters) && void 0 !== r
                    ? r
                    : {},
              });
            } catch (t) {
              var c = t instanceof Error ? t.message : JSON.stringify(t),
                u = t instanceof Error ? t.stack : "";
              n[T](
                "[PREBID]["
                  .concat(
                    e.slotDivId,
                    "]: [bidsGenerator.ts]-[getAllLevelParams]: Error getting network params: "
                  )
                  .concat(c, " ")
                  .concat(u)
              ),
                (s = {
                  account: {},
                  contract: {},
                  constant: {},
                  zone:
                    null !==
                      (a =
                        null === (o = e.zoneTemplate) || void 0 === o
                          ? void 0
                          : o.networkZoneParameters) && void 0 !== a
                      ? a
                      : {},
                });
            }
            return (
              n[k](function () {
                return "[PREBID]["
                  .concat(
                    e.slotDivId,
                    "]: [bidsGenerator.ts]-[getAllLevelParams]: slot "
                  )
                  .concat(e.slotDivId, " networkParams: ")
                  .concat(JSON.stringify(s));
              }),
              s
            );
          } catch (t) {
            var l = t instanceof Error ? t.message : JSON.stringify(t),
              d = t instanceof Error ? t.stack : "";
            return (
              n[T](
                "[PREBID]["
                  .concat(
                    e.slotDivId,
                    "]: [bidsGenerator.ts]-[getAllLevelParams]: Failed to get all level params: "
                  )
                  .concat(l, " ")
                  .concat(d)
              ),
              { account: {}, contract: {}, constant: {}, zone: {} }
            );
          }
        })(n, i, r),
        c =
          null !==
            (o = a.reduce(function (e, o) {
              var a, c, u, l;
              try {
                var d = o.network_code,
                  f = i.getAccountCode(),
                  g =
                    f && s.account[o.network_code]
                      ? (function (e, t) {
                          var n = {};
                          return (
                            Object.keys(t).forEach(function (i) {
                              var r = t[i],
                                o = null;
                              if (r) {
                                if ("client" in r) {
                                  var a = r.client.filter(function (t) {
                                    return (
                                      (null == t ? void 0 : t.accountCode) === e
                                    );
                                  });
                                  a.length > 0 && (o = { client: a });
                                } else if ("server" in r) {
                                  var s = r.server.filter(function (t) {
                                    return (
                                      (null == t ? void 0 : t.accountCode) === e
                                    );
                                  });
                                  s.length > 0 && (o = { server: s });
                                } else if ("serverclient" in r) {
                                  var c = r.serverclient.filter(function (t) {
                                    return (
                                      (null == t ? void 0 : t.accountCode) === e
                                    );
                                  });
                                  c.length > 0 && (o = { serverclient: c });
                                }
                                o && Object.keys(o).length > 0 && (n[i] = o);
                              }
                            }),
                            n
                          );
                        })(
                          f,
                          null !== (a = s.account[o.network_code]) &&
                            void 0 !== a
                            ? a
                            : {}
                        )
                      : {},
                  m = {
                    account: g,
                    contract:
                      null !== (c = s.contract[d]) && void 0 !== c ? c : {},
                    constant:
                      null !== (u = s.constant[d]) && void 0 !== u ? u : {},
                    zone: null !== (l = s.zone[d]) && void 0 !== l ? l : {},
                  };
                return (
                  r[k](function () {
                    return "[PREBID]["
                      .concat(
                        n.slotDivId,
                        "]: [bidsGenerator.ts]-[genBidsFromSlots]: slot "
                      )
                      .concat(n.slotDivId, " paramsByNetwork ")
                      .concat(d, ": ")
                      .concat(JSON.stringify(m));
                  }),
                  [].concat(
                    y(e),
                    y(
                      (function (e, t, n, i, r, o, a) {
                        var s;
                        try {
                          var c = n.network_code,
                            u = (
                              null !== (s = n.matched_schemas) && void 0 !== s
                                ? s
                                : []
                            ).reduce(function (n, s) {
                              try {
                                var u = s.bid_type,
                                  l = {};
                                Wf.forEach(function (e) {
                                  Yf.forEach(function (n) {
                                    var r, d;
                                    try {
                                      var f = s.fields;
                                      Object.keys(
                                        null !==
                                          (d =
                                            null ===
                                              (r = null == f ? void 0 : f[e]) ||
                                            void 0 === r
                                              ? void 0
                                              : r[n]) && void 0 !== d
                                          ? d
                                          : []
                                      ).forEach(function (r) {
                                        var s, d, g, m, v, p, b, h;
                                        try {
                                          var y =
                                              null !==
                                                (m =
                                                  null ===
                                                    (g =
                                                      null ===
                                                        (d =
                                                          null ===
                                                            (s =
                                                              null == f
                                                                ? void 0
                                                                : f[e]) ||
                                                          void 0 === s
                                                            ? void 0
                                                            : s[n]) ||
                                                      void 0 === d
                                                        ? void 0
                                                        : d[r]) || void 0 === g
                                                    ? void 0
                                                    : g.renameTo) &&
                                              void 0 !== m
                                                ? m
                                                : r,
                                            S =
                                              null ===
                                                (b =
                                                  null ===
                                                    (p =
                                                      null ===
                                                        (v =
                                                          null == f
                                                            ? void 0
                                                            : f[e]) ||
                                                      void 0 === v
                                                        ? void 0
                                                        : v[n]) || void 0 === p
                                                    ? void 0
                                                    : p[r]) || void 0 === b
                                                ? void 0
                                                : b.defaultValue,
                                            I = null == i ? void 0 : i[e],
                                            w = null == I ? void 0 : I[r],
                                            _ =
                                              null !==
                                                (h =
                                                  null == w ? void 0 : w[u]) &&
                                              void 0 !== h
                                                ? h
                                                : null == w
                                                ? void 0
                                                : w.serverclient;
                                          if (
                                            null == _
                                              ? void 0
                                              : _.parameterValue
                                          )
                                            return void (l[y] =
                                              _.parameterValue);
                                          if (a && Array.isArray(_)) {
                                            var E = _.find(function (e) {
                                              return e.accountCode === a;
                                            });
                                            if (E)
                                              return void (l[y] =
                                                E.parameterValue);
                                          }
                                          S
                                            ? (o[k](
                                                "[PREBID]["
                                                  .concat(
                                                    t.slotDivId,
                                                    "]: [bidsGenerator.ts]-[genBidsFromSlotsByNetwork]: slot "
                                                  )
                                                  .concat(
                                                    t.slotDivId,
                                                    " missing "
                                                  )
                                                  .concat(n, " ")
                                                  .concat(e, " param ")
                                                  .concat(r, " for ")
                                                  .concat(
                                                    c,
                                                    ", so using default value "
                                                  )
                                                  .concat(S)
                                              ),
                                              (l[y] = S))
                                            : o[k](
                                                "[PREBID]["
                                                  .concat(
                                                    t.slotDivId,
                                                    "]: [bidsGenerator.ts]-[genBidsFromSlotsByNetwork]: slot "
                                                  )
                                                  .concat(
                                                    t.slotDivId,
                                                    " missing "
                                                  )
                                                  .concat(n, " ")
                                                  .concat(e, " param ")
                                                  .concat(r, " for ")
                                                  .concat(c)
                                              );
                                        } catch (e) {
                                          var C =
                                              e instanceof Error
                                                ? e.message
                                                : JSON.stringify(e),
                                            A =
                                              e instanceof Error ? e.stack : "";
                                          o[T](
                                            "[PREBID]["
                                              .concat(
                                                t.slotDivId,
                                                "]: [bidsGenerator.ts]-[genBidsFromSlotsByNetwork]: Error processing param "
                                              )
                                              .concat(r, ": ")
                                              .concat(C, " ")
                                              .concat(A)
                                          );
                                        }
                                      });
                                    } catch (e) {
                                      var g =
                                          e instanceof Error
                                            ? e.message
                                            : JSON.stringify(e),
                                        m = e instanceof Error ? e.stack : "";
                                      o[T](
                                        "[PREBID]["
                                          .concat(
                                            t.slotDivId,
                                            "]: [bidsGenerator.ts]-[genBidsFromSlotsByNetwork]: Error processing requirement "
                                          )
                                          .concat(n, ": ")
                                          .concat(g, " ")
                                          .concat(m)
                                      );
                                    }
                                  });
                                });
                                var d = function (e) {
                                  var t = e.indexOf(",");
                                  if (t < 0) return e;
                                  var n = e.indexOf("/", t + 1);
                                  return ""
                                    .concat(e.substring(0, t))
                                    .concat(e.substring(n));
                                };
                                if (
                                  ("pubmatic" === c &&
                                    (Object.keys(i.zone).find(function (e) {
                                      return "adSlot" === e;
                                    }) ||
                                      (l.adSlot = d(t.zoneTemplate.slot))),
                                  eg(s) && !tg(e, t, s, c))
                                )
                                  return n;
                                var f = function (e, t, n) {
                                    var i, o;
                                    return {
                                      bidder: Zf(e, r),
                                      bidSizes:
                                        null !==
                                          (o =
                                            null === (i = n.matched_schema) ||
                                            void 0 === i
                                              ? void 0
                                              : i.sizes) && void 0 !== o
                                          ? o
                                          : [],
                                      params: t,
                                    };
                                  },
                                  g = function (e, t, n) {
                                    return Object.assign(
                                      Object.assign({}, f(e, t, n)),
                                      { bidder: "".concat(e, "_s2s") }
                                    );
                                  },
                                  m = "server" === u ? g(c, l, s) : f(c, l, s);
                                return [].concat(y(n), [m]);
                              } catch (e) {
                                var v =
                                    e instanceof Error
                                      ? e.message
                                      : JSON.stringify(e),
                                  p = e instanceof Error ? e.stack : "";
                                return (
                                  o[T](
                                    "[PREBID]["
                                      .concat(
                                        t.slotDivId,
                                        "]: [bidsGenerator.ts]-[genBidsFromSlotsByNetwork]: Error processing schema: "
                                      )
                                      .concat(v, " ")
                                      .concat(p)
                                  ),
                                  n
                                );
                              }
                            }, []);
                          return (
                            o[k](function () {
                              return "[PREBID]["
                                .concat(
                                  t.slotDivId,
                                  "]: [bidsGenerator.ts]-[genBidsFromSlotsByNetwork]: slot "
                                )
                                .concat(t.slotDivId, " new bids for ")
                                .concat(c, ": ")
                                .concat(JSON.stringify(u));
                            }),
                            u
                          );
                        } catch (e) {
                          var l =
                              e instanceof Error
                                ? e.message
                                : JSON.stringify(e),
                            d = e instanceof Error ? e.stack : "";
                          return (
                            o[T](
                              "[PREBID]["
                                .concat(
                                  t.slotDivId,
                                  "]: [bidsGenerator.ts]-[genBidsFromSlotsByNetwork]: Failed to generate bids for network: "
                                )
                                .concat(l, " ")
                                .concat(d)
                            ),
                            []
                          );
                        }
                      })(t, n, o, m, i.getTagRevision(), r, f)
                    )
                  )
                );
              } catch (t) {
                var v = t instanceof Error ? t.message : JSON.stringify(t),
                  p = t instanceof Error ? t.stack : "";
                return (
                  r[T](
                    "[PREBID]["
                      .concat(
                        n.slotDivId,
                        "]: [bidsGenerator.ts]-[genBidsFromSlots]: Error processing network: "
                      )
                      .concat(v, " ")
                      .concat(p)
                  ),
                  e
                );
              }
            }, [])) && void 0 !== o
            ? o
            : [];
      return (
        r[k](function () {
          return "[PREBID]["
            .concat(
              n.slotDivId,
              "]: [bidsGenerator.ts]-[genBidsFromSlots]: New bids list: "
            )
            .concat(JSON.stringify(c));
        }),
        c
      );
    } catch (e) {
      var u = e instanceof Error ? e.message : JSON.stringify(e),
        l = e instanceof Error ? e.stack : "";
      return (
        r[T](
          "[PREBID]: [bidsGenerator.ts]-[genBidsFromSlots]: Failed to generate bids: "
            .concat(u, " ")
            .concat(l)
        ),
        []
      );
    }
  }
  var Qf = function (e, t, n, i) {
      var r,
        o,
        a =
          null !==
            (o =
              null === (r = t.zoneTemplate) || void 0 === r
                ? void 0
                : r.matchedNetworks) && void 0 !== o
            ? o
            : [];
      try {
        return (
          i[k](function () {
            return "[PREBID]["
              .concat(
                t.slotDivId,
                "]: [bidsGenerator.ts]-[getNetworks]: initial network list: "
              )
              .concat(JSON.stringify(a));
          }),
          i[k](function () {
            return "[PREBID]["
              .concat(
                t.slotDivId,
                "]: [bidsGenerator.ts]-[getNetworks]: allowed bidders in new bids: "
              )
              .concat(n.allowedBiddersInNewBids());
          }),
          (a = Kf(a, n.allowedBiddersInNewBids(), t, i)),
          i[k](function () {
            return "[PREBID]["
              .concat(
                t.slotDivId,
                "]: [bidsGenerator.ts]-[getNetworks]: network list after filter allowed bidders: "
              )
              .concat(JSON.stringify(a));
          }),
          (a = ng(e, a, t, i)),
          i[k](function () {
            return "[PREBID]["
              .concat(
                t.slotDivId,
                "]: [bidsGenerator.ts]-[getNetworks]: network list after filter runtime criteria: "
              )
              .concat(JSON.stringify(a));
          }),
          (a = Xf(a, n.getExcludedNetworksForGeo(), t, i)),
          i[k](function () {
            return "[PREBID]["
              .concat(
                t.slotDivId,
                "]: [bidsGenerator.ts]-[getNetworks]: network list after filter geo exclusions: "
              )
              .concat(JSON.stringify(a));
          }),
          (a = $f(a, n.getSampledBidders(), t, i))
        );
      } catch (e) {
        var s = e instanceof Error ? e.message : JSON.stringify(e),
          c = e instanceof Error ? e.stack : "";
        return (
          i[T](
            "[PREBID]["
              .concat(
                t.slotDivId,
                "]: [bidsGenerator.ts]-[getNetworks]: Failed to get networks: "
              )
              .concat(s, " ")
              .concat(c)
          ),
          a
        );
      }
    },
    Kf = function (e, t, n, i) {
      try {
        return t && 0 !== t.length
          ? (null != e ? e : []).filter(function (e) {
              return (
                (null == e ? void 0 : e.network_code) &&
                t.includes(e.network_code)
              );
            })
          : null != e
          ? e
          : [];
      } catch (e) {
        var r = e instanceof Error ? e.message : JSON.stringify(e),
          o = e instanceof Error ? e.stack : "";
        return (
          i[T](
            "[PREBID]["
              .concat(
                n.slotDivId,
                "]: [bidsGenerator.ts]-[filterNetworksByRuntimeCriteria]: Error filtering networks: "
              )
              .concat(r, " ")
              .concat(o)
          ),
          []
        );
      }
    },
    Xf = function (e, t, n, i) {
      return 0 === t.length
        ? e
        : (i[k](function () {
            return "[PREBID]["
              .concat(
                n.slotDivId,
                "]: [bidsGenerator.ts]-[filterNetworksByGeoExclusions]: Bidders to exclude: "
              )
              .concat(t.join(", "));
          }),
          e.filter(function (e) {
            return !t.includes(e.network_code);
          }));
    },
    $f = function (e, t, n, i) {
      return 0 === t.length
        ? e
        : e.filter(function (e) {
            var r,
              o = t.find(function (t) {
                return t.bidder === e.network_code;
              });
            return (
              !o ||
              ((r = o.sampleRate), 100 * Math.random() < r) ||
              (i[k](function () {
                return "[PREBID]["
                  .concat(
                    n.slotDivId,
                    "]: [bidsGenerator.ts]-[filterNetworksBySampleRate]: dropped "
                  )
                  .concat(o.bidder, " at ")
                  .concat(o.sampleRate, "%");
              }),
              !1)
            );
          });
    },
    eg = function (e) {
      var t, n;
      return (
        null !==
          (n =
            null === (t = e.matched_schema.runtime_criteria) || void 0 === t
              ? void 0
              : t.some(function (e) {
                  return (
                    "is_only_one_bid_allowed_per_page" in e &&
                    !0 === e.is_only_one_bid_allowed_per_page
                  );
                })) &&
        void 0 !== n &&
        n
      );
    },
    tg = function (e, t, n, i) {
      if (!eg(n)) return !1;
      var r = e.find(function (e) {
        var t,
          n = (
            null !== (t = e.zoneTemplate.matchedNetworks) && void 0 !== t
              ? t
              : []
          ).find(function (e) {
            return e.network_code === i;
          });
        return (
          !!n &&
          n.matched_schemas.some(function (e) {
            return eg(e);
          })
        );
      });
      return !r || (null == r ? void 0 : r.slotDivId) === t.slotDivId;
    },
    ng = function (e, t, n, i) {
      try {
        if (!t || 0 === t.length) return t;
        var r = ig(e, n, i);
        i[k](
          "[PREBID]["
            .concat(
              n.slotDivId,
              "]: [bidsGenerator.ts]-[filterNetworksByRuntimeCriteria]: Device is "
            )
            .concat(r ? "desktop" : "mobile")
        );
        var o = t.map(function (t) {
          var o = (t.matched_schemas || []).filter(function (o) {
            var a;
            return (
              !(null === (a = o.matched_schema) || void 0 === a
                ? void 0
                : a.runtime_criteria) ||
              0 === o.matched_schema.runtime_criteria.length ||
              o.matched_schema.runtime_criteria.every(function (a) {
                var s = a.is_desktop;
                if (void 0 !== s && s !== r)
                  return (
                    i[k](
                      "[PREBID]["
                        .concat(
                          n.slotDivId,
                          "]: [bidsGenerator.ts]-[filterNetworksByRuntimeCriteria]: Schema "
                        )
                        .concat(o.matched_schema.schema_name, " for network ")
                        .concat(
                          t.network_code,
                          " filtered out due to is_desktop="
                        )
                        .concat(s, ", current device is_desktop=")
                        .concat(r)
                    ),
                    !1
                  );
                var c = a.is_atf;
                if (c) {
                  var u = rg(e, n, i);
                  if (!u)
                    return (
                      i[k](
                        "[PREBID]["
                          .concat(
                            n.slotDivId,
                            "]: [bidsGenerator.ts]-[filterNetworksByRuntimeCriteria]: Schema "
                          )
                          .concat(o.matched_schema.schema_name, " for network ")
                          .concat(
                            t.network_code,
                            " filtered out due to is_atf="
                          )
                          .concat(c, ", current slot is_atf=")
                          .concat(u)
                      ),
                      !1
                    );
                }
                if (a.is_btf) {
                  var l = rg(e, n, i);
                  if (l)
                    return (
                      i[k](
                        "[PREBID]["
                          .concat(
                            n.slotDivId,
                            "]: [bidsGenerator.ts]-[filterNetworksByRuntimeCriteria]: Schema "
                          )
                          .concat(o.matched_schema.schema_name, " for network ")
                          .concat(
                            t.network_code,
                            " filtered out due to is_btf="
                          )
                          .concat(!c, ", current slot is_btf=")
                          .concat(!l)
                      ),
                      !1
                    );
                }
                return !0;
              })
            );
          });
          return Object.assign(Object.assign({}, t), { matched_schemas: o });
        });
        return o.filter(function (e) {
          return e.matched_schemas && e.matched_schemas.length > 0;
        });
      } catch (e) {
        var a = e instanceof Error ? e.message : JSON.stringify(e),
          s = e instanceof Error ? e.stack : "";
        return (
          i[T](
            "[PREBID]["
              .concat(
                n.slotDivId,
                "]: [bidsGenerator.ts]-[filterNetworksByRuntimeCriteria]: Error filtering networks: "
              )
              .concat(a, " ")
              .concat(s)
          ),
          t
        );
      }
    },
    ig = function (e, t, n) {
      try {
        if (e.navigator) {
          return !/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
            e.navigator.userAgent
          );
        }
        return !0;
      } catch (e) {
        var i = e instanceof Error ? e.message : JSON.stringify(e),
          r = e instanceof Error ? e.stack : "";
        return (
          n[T](
            "[PREBID]["
              .concat(
                t.slotDivId,
                "]: [bidsGenerator.ts]-[isDesktopDevice]: Error checking device: "
              )
              .concat(i, " ")
              .concat(r)
          ),
          !0
        );
      }
    },
    rg = function (e, t, n) {
      return (function (e, t, n, i) {
        if (!t)
          return (
            i[k](
              "[PREBID][".concat(
                n.slotDivId,
                "]: [bidsGenerator.ts]-[isAboveTheFold]: No ad slot element found"
              )
            ),
            !1
          );
        var r = t.offsetParent || t.parentElement,
          o = r ? r.getBoundingClientRect() : { top: 0 },
          a = o.top + t.offsetTop,
          s = e.innerHeight || document.documentElement.clientHeight;
        return (
          i[k](
            "[PREBID]["
              .concat(
                n.slotDivId,
                "]: [bidsGenerator.ts]-[isAboveTheFold]: Ad slot absoluteTop: "
              )
              .concat(o.top, " + ")
              .concat(t.offsetTop, " = ")
              .concat(a, ", viewportHeight: ")
              .concat(s)
          ),
          a < s
        );
      })(e, document.getElementById(t.slotDivId), t, n);
    };
  function og(e, t, n, i, r) {
    var o = {},
      a = [];
    function s(e) {
      return { banner: { sizes: e } };
    }
    function c(e) {
      return {
        native: Object.assign(
          {},
          i.isPrebidV11() ? {} : { sendTargetingKeys: !1 }
        ),
      };
    }
    function u(e) {
      return {
        video: Object.assign(
          Object.assign(
            {},
            {
              context: "outstream",
              playerSize: [640, 480],
              mimes: ["video/mp4"],
              protocols: [2, 3, 4],
              playbackmethod: [2],
              maxduration: 30,
              minduration: 6,
              skip: 1,
              linearity: 2,
              api: [2],
            }
          ),
          e.videoAttributes
        ),
      };
    }
    function l(e, t, n) {
      return r[Hf](e, t, n, a);
    }
    return {
      registerPrebidUnit: function (r) {
        var a =
            i.isBannerPosSignalEnabled() && rg(e, r, n)
              ? { banner: { pos: 1 } }
              : void 0,
          d = (function (e, t, n, r) {
            var o, a;
            return Object.assign(
              Object.assign(
                {
                  code: e.slotDivId,
                  mediaTypes: Object.assign(
                    Object.assign(
                      Object.assign({}, i.isPrebidBannerEnabled() && s(n)),
                      i.isPrebidNativeEnabled() &&
                        (null === (o = e.mediaTypes) || void 0 === o
                          ? void 0
                          : o.includes("native")) &&
                        c()
                    ),
                    i.isPrebidVideoEnabled() &&
                      (null === (a = e.mediaTypes) || void 0 === a
                        ? void 0
                        : a.includes("video")) &&
                      u(e)
                  ),
                },
                void 0 !== r && { ortb2Imp: r }
              ),
              { bids: t }
            );
          })(
            r,
            (function (t) {
              var r,
                a = i.isForceSafeFrames();
              a &&
                n[k](
                  "[PREBID][".concat(
                    t.slotDivId,
                    "]: Safe Frames compatibility filter is enabled"
                  )
                );
              var s = t.sizesHb.map(function (e) {
                  return ki(e);
                }),
                c = Jf(e, Object.values(o), t, i, n)
                  .filter(function (e) {
                    var t = e.bidSizes;
                    return (
                      !(t && t.length > 0) ||
                      (function (e, t) {
                        for (
                          var n = [], i = new Set(t), r = 0, o = e.length;
                          r < o;
                          ++r
                        )
                          i.has(e[r]) && n.push(e[r]);
                        return n;
                      })(s, t).length > 0
                    );
                  })
                  .filter(function (e) {
                    if (!a) return !0;
                    var i = l(e, t.sizesHb, t.breakpoint);
                    return (
                      i ||
                        n[k](
                          "[PREBID]["
                            .concat(t.slotDivId, "]: Bidder ")
                            .concat(
                              e.bidder,
                              " is not compatible with Safe Frames, excluding from the slot"
                            )
                        ),
                      i
                    );
                  });
              if (
                i.isPrebidVideoEnabled() &&
                (null === (r = t.mediaTypes) || void 0 === r
                  ? void 0
                  : r.includes("video"))
              ) {
                var u = {
                  w: 640,
                  h: 480,
                  context: "outstream",
                  language: "en",
                  mimes: ["video/mp4"],
                };
                return c.map(function (e) {
                  return Object.assign(Object.assign({}, e), {
                    params: Object.assign(
                      Object.assign(Object.assign({}, u), e.params),
                      "pubmatic" === e.bidder && {
                        outstreamAU: "renderer_test_pubmatic",
                      }
                    ),
                  });
                });
              }
              return c;
            })(r),
            r.sizesHb,
            a
          );
        n[k](function () {
          return "[PREBID]["
            .concat(r.slotDivId, "]: Registered with mediaTypes: ")
            .concat(JSON.stringify(d.mediaTypes));
        }),
          t.addAdUnits(d),
          (o[r.slotDivId] = r);
      },
      getRegisteredSlot: function (e) {
        return o[e];
      },
      removePrebidUnit: function (e) {
        n[k]("[PREBID][".concat(e.slotDivId, "]: Removing slot")),
          t.removeAdUnit(e.slotDivId),
          delete o[e.slotDivId];
      },
      setAllowedSafeFrameBidders: function (e) {
        a = e;
      },
      isBidCompatible: l,
      getUnrenderedValidBidsFromCache: function (e) {
        var i =
          arguments.length > 1 && void 0 !== arguments[1]
            ? arguments[1]
            : Date.now();
        return t.getBidResponsesForAdUnitCode(e).bids.filter(function (e) {
          return (
            !!e &&
            (function (e, t, n) {
              if ("rendered" === e.status)
                return (
                  null == n ||
                    n[k](function () {
                      return "[PREBID]["
                        .concat(e.adUnitCode, "]: bid ")
                        .concat(e.bidder, " (")
                        .concat(e.adId, ") not renderable: already rendered");
                    }),
                  !1
                );
              var i = 1e3 * e.ttl + e.responseTimestamp;
              return !(
                i <= t &&
                (null == n ||
                  n[k](function () {
                    return "[PREBID]["
                      .concat(e.adUnitCode, "]: bid ")
                      .concat(e.bidder, " (")
                      .concat(e.adId, ") not renderable: TTL lapsed (ttl=")
                      .concat(e.ttl, "s, responseTimestamp=")
                      .concat(e.responseTimestamp, ", expiresAt=")
                      .concat(i, ", now=")
                      .concat(t, ", expired ")
                      .concat(t - i, "ms ago)");
                  }),
                1)
              );
            })(e, i, n)
          );
        });
      },
      registeredSlots: o,
    };
  }
  var ag = Symbol(),
    sg = Symbol(),
    cg = Symbol(),
    ug = Symbol(),
    lg = Symbol(),
    dg = Symbol(),
    fg = M()(function (e) {
      return e
        .register(ag, [j], rl)
        .register(sg, [], qf)
        .register(ug, [ag, L], il)
        .register(lg, [ug], ul)
        .register(cg, [j, ag, L, $i, sg], og)
        .register(dg, [ag, $i, cg, L], ud)
        .export();
    }),
    gg = Symbol(),
    mg = M()(function (e) {
      return e.register(gg, [L, j, na, mu, $i, Kt], fd).export();
    }),
    vg = Symbol();
  function pg(e, t) {
    return u({}, vg, function (n) {
      e[k]("[ADMIRAL] Initialising Start"), t[bi]("admiral_load_start");
      try {
        n(),
          e[k]("[ADMIRAL] Initialising Finish"),
          t[bi]("admiral_load_finish");
      } catch (t) {
        e[T]("[ADMIRAL] Encountered error during evaluation", t, n);
      }
    });
  }
  var bg = Symbol();
  function hg(e, t, n, i, r) {
    var o = n.getAssertiveYieldEntityId() || "7oDcS2a8NXtFyxnDn",
      a = n.getFuseGeo();
    return u({}, bg, function (s) {
      i[bi]("assertiveyield_load_start"),
        t[A]("[INIT]: Initialising AssertiveYield"),
        ba(
          { logger: t, window: e },
          (function (e) {
            return {
              name: "AssertiveYield",
              url: "//".concat(e, ".ay.delivery/"),
              file: "s2s-client-v1.js",
            };
          })(o),
          function () {
            t[A]("[INIT]: AssertiveYield script loaded"),
              i[bi]("assertiveyield_load_finish");
            try {
              (c = n.getTagRevision()),
                (u = n.getPrebidServerBidders().map(function (e) {
                  return Zf(e, c);
                })),
                (l = n.getPrebidClientBidders().map(function (e) {
                  return Zf(e, c);
                })),
                (d = u.filter(function (e) {
                  return !l.includes(e);
                })),
                (f = n.isAllBiddersWithAYEnabled() ? Ql(u, l) : u),
                (g = {
                  orgId: "LiCgEBeRTmRgR6M2n",
                  entityId: o,
                  bidders: f,
                  serverOnlyBidders: d,
                  pbjs: "fusePbjs",
                  continent:
                    a && ["EU", "EU-GDPR"].includes(a.code) ? "EU" : "NA",
                  analytics: !0,
                  aliasRegistry: null,
                  suffix: "_s2s",
                  abPercentage: n.getAssertiveYieldAbPercentage(),
                  customEndpoint: {
                    us: "pbs-publift-us",
                    eu: "pbs-publift-eu",
                  },
                }),
                t[A](function () {
                  return "[INIT]: AssertiveYield config ".concat(
                    JSON.stringify(g)
                  );
                }),
                e.ayS2STag.init(
                  Object.assign(Object.assign({}, g), {
                    callback: function (e) {},
                  })
                );
            } catch (e) {
              return (
                i[bi]("assertiveyield_init_fail"),
                t[E](
                  "[INIT]: AssertiveYield init failed",
                  e instanceof Error ? e.message : String(e)
                ),
                void s(!0)
              );
            }
            var c, u, l, d, f, g;
            t[A](
              "[INIT]: AssertiveYield initialised, waiting for Prebid to run AssertiveYield's queued hook"
            ),
              r[nl](function () {
                return s();
              });
          },
          function () {
            i[bi]("assertiveyield_load_skip"), s(!0);
          }
        );
    });
  }
  var yg = Symbol();
  function Sg(e, t, n, i, r, o) {
    function a(n) {
      t[C](function () {
        return "[GAMERA]: Initialising Gamera. Personalized ads: ".concat(
          JSON.stringify(n.allowPersonalisation)
        );
      }),
        (e.gamera = e.gamera || {}),
        (e.gamera.cmd = e.gamera.cmd || []),
        e.gamera.cmd.push(function () {
          var e = new Event("gamera.consentProceed");
          window.dispatchEvent(e);
        });
    }
    return (
      !n.isCmpRequired() ||
        (n.useCmpReadyEvent() && n.isStrictCmp()) ||
        r[St].subscribe(function (e) {
          "cmp" === e.component &&
            "ready" === e.state._tag &&
            e.state.output.allowPersonalisation &&
            a(e.state.output);
        }),
      u({}, yg, function (s) {
        var c;
        i[bi]("gamera_load_start"),
          t[A]("[INIT]: Loading Gamera"),
          ba(
            { logger: t, window: e },
            ((c = n.isCmpRequired()),
            {
              name: "Gamera",
              url: "//metrics.rapidedge.io/",
              file: "gamera.js?ltv=1&audience=1&tpcs=1&partner=publift".concat(
                c ? "&wait=1" : ""
              ),
              id: "__gamera__",
            }),
            function () {
              var e;
              if (
                (t[A]("[INIT]: Gamera script loaded"),
                i[bi]("gamera_load_finish"),
                n.useCmpReadyEvent())
              )
                t[k](
                  "[GAMERA]: Waiting for CMP ready event before configuring GAMERA"
                ),
                  r[Zt].immediateOrOnce(function (e) {
                    e.allowPersonalisation
                      ? (t[k](
                          "[GAMERA]: CMP is ready and personalisation is allowed"
                        ),
                        a(e),
                        s())
                      : (t[k](
                          "[GAMERA]: CMP is ready and personalisation is NOT allowed"
                        ),
                        s(!0));
                  });
              else if (n.isStrictCmp()) {
                var c = o[Tr].cmp;
                c &&
                "ready" === c._tag &&
                (null === (e = c.output) || void 0 === e
                  ? void 0
                  : e.allowPersonalisation)
                  ? (a(c.output), s())
                  : s(!0);
              } else s();
            }
          );
      })
    );
  }
  var Ig = 1971355384,
    wg = new Set(["GB", "IE", "ES", "FR", "DE"]),
    _g = new Set([
      "US",
      "CA",
      "AU",
      "NZ",
      "JP",
      "SG",
      "TH",
      "PH",
      "MY",
      "KR",
      "MX",
      "BR",
    ]),
    Eg = function (e) {
      return e && wg.has(e.country)
        ? Ig
        : e && _g.has(e.country)
        ? 768420746
        : void 0;
    },
    kg = new Set(["6.251", "6.253"]),
    Cg = Symbol(),
    Tg = Symbol();
  function Ag(e, t, n, i, r) {
    var o,
      a,
      s = Eg(n.getFuseGeo()),
      c = n.getIntentIQVersion(),
      l = n.getIntentIQManualReport(),
      d =
        null !== (o = n.getIntentIQGamParameterName()) && void 0 !== o
          ? o
          : "intent_iq_group",
      f = null !== (a = n.getIntentIQInChrome()) && void 0 !== a && a;
    function g() {
      t[A](function () {
        return "[INIT]: Initialising IntentIQ with config ".concat(
          JSON.stringify({
            partnerId: s,
            version: c,
            manualReport: l,
            gamParameterName: d,
          })
        );
      });
      (e.intentIq_768420746 = new e.IntentIqObject(
        Object.assign(
          Object.assign(
            Object.assign(
              {
                partner: s,
                gamObjectReference: e.googletag,
                pbjs: e.fusePbjs,
                callback: function (e) {
                  i[bi]("intentiq_callback_received");
                  var n = (function (e) {
                    return (
                      "object" === I(e) &&
                      null !== e &&
                      "eids" in e &&
                      Array.isArray(e.eids)
                    );
                  })(e)
                    ? e.eids
                    : [];
                  t[A](
                    "[INTENTIQ]: Callback received with ".concat(
                      n.length,
                      " eids"
                    )
                  ),
                    r[Jt].emit({ eids: n });
                },
                timeoutInMillis: 400,
                ABTestingConfigurationSource: "IIQServer",
                manualWinReportEnabled: l,
                domainName: e.location.hostname,
              },
              f ? {} : { vrBrowserBlackList: ["chrome"] }
            ),
            s === Ig &&
              (function (e) {
                return e === lc || kg.has(null != e ? e : "6.253");
              })(c)
              ? { region: "gdpr" }
              : {}
          ),
          {
            gamParameterName: d,
            shouldSetPPID: !0,
            groupChanged: function (e) {
              t[A](
                "[INTENTIQ]: Group changed event received, intentIQ test group ".concat(
                  e
                )
              );
            },
          }
        )
      )),
        l &&
          (t[A]("[INTENTIQ]: Manual reporting is enabled"),
          r[Lt].subscribe(function (e) {
            return m(e);
          }));
    }
    function m(n) {
      t[A]("[INTENTIQ]: Reporting external win", n, n.adId, n);
      var i = {
        biddingPlatformId: 1,
        partnerAuctionId: n.auctionId,
        bidderCode: n.bidderCode,
        prebidAuctionId: n.auctionId,
        cpm: n.cpm,
        currency: n.currency,
        originalCpm: n.originalCpm,
        originalCurrency: n.originalCurrency,
        status: n.status,
        placementId: n.adUnitCode,
        adtype: "banner",
      };
      e.intentIq_768420746.reportExternalWin(i);
    }
    return u(
      u({}, Cg, function (o) {
        if (
          (i[bi]("intentiq_load_start"),
          t[A](
            "[INIT]: Loading IntentIQ with partner ID "
              .concat(s, ", version ")
              .concat(c, ", manual report: ")
              .concat(l)
          ),
          !s)
        )
          return (
            t[A](
              "[INIT]: IntentIQ geo not in supported regions, skipping initialization"
            ),
            i[bi]("intentiq_load_skip"),
            r[Jt].emit({ skipReason: "unsupported_geo" }),
            void o(!0)
          );
        if (!uc(c))
          return (
            t[E](
              "[INIT]: IntentIQ version format is invalid, skipping initialization"
            ),
            i[bi]("intentiq_load_skip"),
            r[Jt].emit({ skipReason: "invalid_version" }),
            void o(!0)
          );
        var a = function () {
            t[A]("[INIT]: IntentIQ script loaded"),
              i[bi]("intentiq_load_finish"),
              n.useCmpReadyEvent()
                ? (t[k](
                    "[INTENTIQ]: Waiting for CMP ready event before configuring IntentIQ"
                  ),
                  r[Zt].immediateOrOnce(function (e) {
                    g(), o();
                  }))
                : (g(), o());
          },
          u = function () {
            t[E]("[INIT]: Failed to load IntentIQ script (primary + fallback)"),
              i[bi]("intentiq_load_skip"),
              r[Jt].emit({ skipReason: "script_load_failed" }),
              o(!0);
          };
        ba({ logger: t, window: e }, dc(c, s), a, function () {
          t[A]("[INIT]: Failed to load IntentIQ script, loading fallback"),
            ba({ logger: t, window: e }, dc(void 0), a, u);
        });
      }),
      Tg,
      m
    );
  }
  var Rg = Symbol(),
    xg = Symbol();
  function Pg(e, t, n, i) {
    var r = n.enableOptable();
    return u(
      u({}, Rg, function () {
        if (
          (i[bi]("optable_load_start"),
          t[A](
            "[INIT]: Initialising optable with slug ".concat(n.getOptableSlug())
          ),
          !r)
        )
          return (
            t[A]("[INIT]: optable not enabled, skipping initialization"),
            void i[bi]("optable_load_skip")
          );
        (e.optable = e.optable || { cmd: [] }),
          (e.optable.site = n.getOptableSlug()),
          ba(
            { logger: t, window: e },
            {
              name: "Optable",
              url: "//solutions.cdn.optable.co/",
              file: "publift/sdk.js",
            },
            function () {
              t[A]("[INIT]: optable script loaded"),
                i[bi]("optable_load_finish");
            },
            function () {
              t[E]("[INIT]: optable script failed to load"),
                i[bi]("optable_load_fail");
            }
          );
      }),
      xg,
      function (n) {
        var i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
        (e.optable = e.optable || { cmd: [] }),
          e.optable.cmd.push(function () {
            var r = i ? "e:".concat(n) : e.optable.SDK.eid(n);
            t[A]("[OPTABLE]: Setting EID data"),
              e.optable.publift_instance.identify(r);
          });
      }
    );
  }
  var Og = Symbol(),
    Dg = Symbol(),
    Ng = Symbol(),
    zg = Symbol(),
    Bg = Symbol(),
    Mg = Symbol(),
    Ug = M()(function (e) {
      return e
        .register(Og, [j, Kt, L], Pu)
        .register(Dg, [j, L, $i, na, ug], hg)
        .register(Ng, [j, L, $i, na, Kt, ra], Sg)
        .register(zg, [L, na], pg)
        .register(Bg, [j, L, $i, na, Kt], Ag)
        .register(Mg, [j, L, $i, na], Pg)
        .export();
    }),
    jg = Symbol(),
    Lg = Symbol(),
    Fg = Symbol(),
    Gg = Symbol(),
    Vg = Symbol(),
    Hg = Symbol(),
    qg = Symbol(),
    Wg = Symbol(),
    Yg = Symbol(),
    Zg = Symbol(),
    Jg = Symbol(),
    Qg = Symbol(),
    Kg = Symbol(),
    Xg = Symbol(),
    $g = Symbol(),
    em = Symbol(),
    tm = Symbol(),
    nm = Symbol(),
    im = Symbol(),
    rm = Symbol();
  function om(e, t, n) {
    return pr(e, t, n[gr](), "slotInfo");
  }
  function am(e, t, n, i, r, o) {
    return function () {
      t[Iu](), e[jc](), n[Gn](), e[Qc](), i[al](), r[df](), o[su](), t[Iu]();
    };
  }
  function sm(e, t, n, i, r) {
    var o = Pf(t[lt]);
    t[Ft].subscribe(function (t) {
      e[A]("[RESPONSIVE]: Switching page to breakpoint '".concat(t.name, "'")),
        i[al](),
        n[df](!0),
        ae(o.value) ? n[rf](!0, !1, r) : n[nf](!0, !1, r);
    });
  }
  var cm = M()(function (e) {
      return e
        .register(Lg, [L, na, Kt], function (e, t, n) {
          return (function (e, t, n) {
            var i,
              r = [],
              o = {},
              a = {},
              s = {};
            function c(e) {
              return -1 !== r.indexOf(e);
            }
            function l(e) {
              return Object.keys(o)
                .map(function (e) {
                  return o[e];
                })
                .filter(function (t) {
                  return t.zoneDivId == e;
                })
                .shift();
            }
            function d(t) {
              var i = l(t);
              if (!i) return e[T]("[ZONE][".concat(t, "]: Unknown zone")), !1;
              var r = i.zoneInstanceId;
              return (
                !a[r] &&
                ((a[r] = !0),
                n.emit({
                  zoneTemplateId: i.zoneTemplateId,
                  zoneDivId: i.zoneDivId,
                  zoneEventType: "activate_zone_api",
                  instanceId: i.zoneInstanceId,
                  gpid: i.gpid,
                  slotDivId: i.zoneDiv.id,
                }),
                !0)
              );
            }
            function f(t) {
              var n;
              return o[t]
                ? null !== (n = a[t]) && void 0 !== n && n
                : (e[T]("[ZONE][".concat(t, "]: Unknown zone")), !1);
            }
            function g(e) {
              var t;
              return null !== (t = s[e]) && void 0 !== t ? t : 0;
            }
            return (
              u(
                u(
                  u(
                    u(
                      u(
                        u(
                          u(
                            u(
                              u(
                                u((i = {}), Bd, function (n) {
                                  var i = n.zoneInstanceId;
                                  if (!o[i]) {
                                    var s = n.zoneDivId
                                      ? l(n.zoneDivId)
                                      : void 0;
                                    if (s) {
                                      var c = s.zoneDiv,
                                        u = s.zoneInstanceId;
                                      if (u === i)
                                        return void e[T](
                                          "[ZONE][".concat(
                                            u,
                                            "]: Ignoring unexpected re-registration"
                                          )
                                        );
                                      e[E](
                                        "[ZONE]["
                                          .concat(u, "]: Div ")
                                          .concat(
                                            c.id,
                                            " replaced in DOM without pageInit(). Registering "
                                          )
                                          .concat(i)
                                      ),
                                        r.push(u),
                                        delete o[u],
                                        delete a[u];
                                    }
                                    e[A](
                                      "[ZONE]["
                                        .concat(i, "]: Registered with DivId ")
                                        .concat(n.zoneDiv.id)
                                    ),
                                      t[vi]();
                                    var d = {
                                      zoneInstanceId: i,
                                      zoneDiv: n.zoneDiv,
                                      zoneDivId: n.zoneDivId,
                                      zoneTemplateId: n.zoneTemplate.id,
                                      gpid: n.gpid,
                                    };
                                    return (o[i] = d), d;
                                  }
                                  e[T](
                                    "[ZONE][".concat(i, "]: Already registered")
                                  );
                                }),
                                Md,
                                c
                              ),
                              Ud,
                              d
                            ),
                            jd,
                            f
                          ),
                          Ld,
                          function () {
                            return Object.keys(o).map(function (e) {
                              return o[e];
                            });
                          }
                        ),
                        Fd,
                        function () {
                          Object.keys(o).forEach(function (t) {
                            c(t)
                              ? e[k](
                                  "[EVENT]: resetSlots() unit already deleted ".concat(
                                    t
                                  )
                                )
                              : r.push(t);
                          }),
                            (a = {}),
                            (o = {});
                        }
                      ),
                      Gd,
                      function (t) {
                        var n = l(t);
                        n
                          ? c(n.zoneInstanceId)
                            ? e[E]("[ZONE][".concat(t, "]: Deleted zone"))
                            : (delete o[n.zoneInstanceId],
                              r.push(n.zoneInstanceId))
                          : e[E]("[ZONE][".concat(t, "]: Unknown zone"));
                      }
                    ),
                    Vd,
                    g
                  ),
                  Hd,
                  function (e) {
                    s[e] = g(e) + 1;
                  }
                ),
                "isManuallyActivated",
                f
              ),
              u(i, "activateZone", d)
            );
          })(e, t, n[mt]);
        })
        .register(Fg, [L, $i, hn, ku, ra], function (e, t, n, i, r) {
          return (function (e, t, n, i, r) {
            return ad(e, t, n, i, r);
          })(
            e,
            t,
            n,
            function () {
              return i.isLowDwellPage();
            },
            r
          );
        })
        .register(Gg, [L, $i, hn, j], gl)
        .register(Vg, [L, bn, $i], pl)
        .register(em, [j, L, ta], om)
        .register(jg, [L, na, j, fu, $i, Xs, hn, Kt, cg, ug, Og, mu], Fl)
        .register(qg, [jg, ag, gg, L, na, $i, Kt, mu, ia, dg], wd)
        .register(Hg, [L, qg, Fg, jg, hn, $i, vu], zd)
        .register(Zg, [L, na, $i, Hg, Kt, oa], tf)
        .register(Xg, [$i, jg, hn], Ff)
        .register(Jg, [L, j, $i, Gg, na, Xg, Vg, aa], kl)
        .register(Yg, [jg, Lg, L, Hg, Jg, ku, Zg], yf)
        .register(Wg, [L, Kt, qg, Hg, Yg], xf)
        .register(Kg, [L, $i, Yg, jg, Lg, $s, Xs, Kt, hn, j, cg, Zg], Lf)
        .register(rm, [mu, Cu, oa, lg, Yg, vu], am)
        .register(Qg, [L, q, rm, Hg, vu, Kt, yn, $i, j], Uf)
        .register($g, [j, yn, jg, Kt, em], Vf)
        .register(tm, [L, Kt, Yg, lg, Kg], sm)
        .register(im, [L, jg, Yg, Kt], If)
        .register(nm, [L, j, $i, ia, im, jg, oa], Rf)
        .export();
    }),
    um =
      (this && this.__rest) ||
      function (e, t) {
        var n = {};
        for (var i in e)
          Object.prototype.hasOwnProperty.call(e, i) &&
            t.indexOf(i) < 0 &&
            (n[i] = e[i]);
        if (null != e && "function" == typeof Object.getOwnPropertySymbols) {
          var r = 0;
          for (i = Object.getOwnPropertySymbols(e); r < i.length; r++)
            t.indexOf(i[r]) < 0 &&
              Object.prototype.propertyIsEnumerable.call(e, i[r]) &&
              (n[i[r]] = e[i[r]]);
        }
        return n;
      },
    lm = Symbol(),
    dm = Symbol(),
    fm = Symbol(),
    gm = "publift-fuse-afs-injection",
    mm = /^[A-Za-z0-9_,+\-]{1,256}$/;
  function vm(e, t, n, i, r, o, a) {
    var s,
      c = !1,
      l = !1,
      d = null;
    function f() {
      r[ft].subscribe(function (t) {
        var r;
        (l = !1),
          (d =
            null !== (r = t.afsPageParams) && void 0 !== r
              ? r
              : (function () {
                  if ("function" == typeof s)
                    try {
                      var t = s();
                      if (t && t.query)
                        return (
                          e[k](function () {
                            return "[API]: AFS page params handler updated params to ".concat(
                              JSON.stringify(t)
                            );
                          }),
                          t
                        );
                    } catch (t) {
                      e[T]("[API]: Error executing AFS page params handler", t);
                    }
                  try {
                    var r = new RegExp(i.getAfsSettings().urlPattern).exec(
                      n.location.href
                    );
                    if (r)
                      return (
                        e[C]("[AFS]: Page params extracted", r),
                        {
                          query: null == r ? void 0 : r[1],
                          page: (null == r ? void 0 : r[2]) || "1",
                        }
                      );
                  } catch (t) {
                    e[T]("[AFS]: Error extracting page params", t);
                  }
                })()),
          setTimeout(function () {
            return v(!0);
          }, 2e3);
      }),
        r[vt].subscribe(function () {
          return v();
        }),
        r[gt].subscribe(function () {
          var e;
          null == (e = document.getElementById(gm)) || e.remove(), (l = !1);
        });
    }
    function g() {
      return o
        .getActiveSlots()
        .filter(function (e) {
          var t;
          return (
            !0 ===
            (null === (t = e.zoneTemplate.attributes) || void 0 === t
              ? void 0
              : t.afs)
          );
        })
        .map(function (e) {
          return e.zoneTemplate;
        });
    }
    function m(t, r) {
      var o =
          arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
        a = o.page,
        s = o.styleId,
        u = o.channel,
        l = (function (e) {
          return e.enabled, e.urlPattern, um(e, ["enabled", "urlPattern"]);
        })(i.getAfsSettings()),
        d = Object.assign(Object.assign({}, l), {
          query: t,
          adPage: a,
          personalizedAds: c,
          styleId: null != s ? s : l.styleId,
          channel: null != u ? u : l.channel,
        });
      e[C](function () {
        return "[AFS]: Page options ".concat(JSON.stringify(d));
      });
      var f = "var pageOptions = ".concat(JSON.stringify(d), ";"),
        g = r
          .sort(function (e, t) {
            var n, i;
            return (
              Number(
                null === (n = t.afsAttributes) || void 0 === n
                  ? void 0
                  : n.maxTop
              ) -
              Number(
                null === (i = e.afsAttributes) || void 0 === i
                  ? void 0
                  : i.maxTop
              )
            );
          })
          .map(function (t, i) {
            var r,
              o = n.document.querySelector('[data-fuse="'.concat(t.id, '"]'));
            if (o) {
              var a = t.afsAttributes;
              0 !== i &&
                Number(
                  null === (r = t.afsAttributes) || void 0 === r
                    ? void 0
                    : r.maxTop
                ) &&
                (e[E](
                  "[AFS]: Zone ".concat(
                    t.id,
                    " has maxTop set but is not the first zone. maxTop will be ignored"
                  )
                ),
                (a.maxTop = void 0));
              var s = Object.assign(Object.assign({}, t.afsAttributes), {
                  container: o.id,
                }),
                c = "adblock".concat(i + 1);
              return (
                e[C](function () {
                  return "[AFS]["
                    .concat(t.id, "]: Container options ")
                    .concat(JSON.stringify(s));
                }),
                (f += "var ".concat(c, " = ").concat(JSON.stringify(s), ";")),
                c
              );
            }
            e[E]("[AFS]: No container found for zone ".concat(t.id));
          })
          .filter(function (e) {
            return e;
          });
      if (g.length) {
        f += "_googCsa('ads', pageOptions, ".concat(g.join(", "), ");");
        var m = document.createElement("script");
        (m.type = "text/javascript"),
          (m.id = gm),
          (m.innerHTML = f),
          document.head.appendChild(m);
      }
    }
    function v(t) {
      l ||
        ((l = !0),
        e[C]("[AFS]: Inited by ".concat(t ? "timeout" : "auction")),
        p(g(), d));
    }
    function p(t, i) {
      var r = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
      if (t.length)
        if (i) {
          var o = i.query,
            a = i.page,
            s = i.styleId,
            c = i.channel;
          if (o) {
            var u = c;
            c &&
              !mm.test(c) &&
              (e[E]("[AFS]: Dropped invalid channel value: ".concat(c)),
              (u = void 0));
            var l = n.document.getElementById(gm);
            if (l) {
              if (!r) return void e[C]("[AFS]: Already initialized");
              l.remove();
            }
            m(o, t, { page: a, styleId: s, channel: u });
          } else e[C]("[AFS]: No query provided");
        } else e[C]("[AFS]: No page params found. Skip init");
      else e[C]("[AFS]: No zones provided. Skip init");
    }
    return (
      !i.getAfsSettings().enabled ||
        !i.isCmpRequired() ||
        (i.useCmpReadyEvent() && i.isStrictCmp()) ||
        r[St].subscribe(function (t) {
          "cmp" === t.component &&
            "ready" === t.state._tag &&
            t.state.output.allowPersonalisation &&
            ((c = !0),
            e[C](
              "[AFS]: Personalized ads allowed by CMP component init event"
            ));
        }),
      u(
        u(
          u({}, lm, function (o) {
            !(function (i) {
              var r = {
                name: "Afs",
                url: "//www.google.com/adsense/search/",
                file: "ads.js",
                insertSelector: "head",
              };
              t[bi]("afs_load_start");
              var o = n.document,
                a = o.createElement("script");
              (a.type = "text/javascript"),
                (a.innerHTML =
                  "\n    (function(g,o){g[o]=g[o]||function(){(g[o]['q']=g[o]['q']||[]).push(\n      arguments)},g[o]['t']=1*new Date})(window,'_googCsa');\n    "),
                o.querySelector("head").appendChild(a),
                ba({ logger: e, window: n }, r, function () {
                  e[C]("[AFS]: Script loaded"), t[bi]("afs_load_finish"), i();
                });
            })(function () {
              var t;
              if (!i.isCmpRequired())
                return (
                  e[C]("[AFS]: Personalized ads set to true by isCmpRequired"),
                  (c = !0),
                  f(),
                  void o()
                );
              if (i.useCmpReadyEvent())
                return (
                  e[k](
                    "[AFS]: Waiting for CMP ready event before configuring AFS"
                  ),
                  void r[Zt].immediateOrOnce(function (e) {
                    !i.isStrictCmp() || e.allowPersonalisation
                      ? ((c = !0 === e.allowPersonalisation), f(), o())
                      : o(!0);
                  })
                );
              if (i.isStrictCmp()) {
                var n = a[Tr].cmp;
                "ready" === (null == n ? void 0 : n._tag) &&
                (null === (t = n.output) || void 0 === t
                  ? void 0
                  : t.allowPersonalisation)
                  ? ((c = !0), f(), o())
                  : o(!0);
              } else f(), o();
            });
          }),
          dm,
          function (t) {
            e[k](function () {
              return "[API]: resetting with ".concat(JSON.stringify(t));
            }),
              t && (d = t),
              p(g(), d, !0);
          }
        ),
        fm,
        function (t) {
          e[k]("[AFS]: setting extract page params handler"), (s = t);
        }
      )
    );
  }
  var pm = Symbol(),
    bm = M()(function (e) {
      return e.register(pm, [L, na, j, $i, Kt, jg, ra], vm).export();
    }),
    hm = ["optidigital"];
  function ym(e) {
    var t = e.bids,
      n = e.maxRunnerUps;
    if (n <= 0) return [];
    return t
      .filter(function (e) {
        return (
          "banner" === e.mediaType &&
          (function (e) {
            var t =
              "string" == typeof e.bidder ? e.bidder.trim().toLowerCase() : "";
            return (
              t.length > 0 &&
              !hm.some(function (e) {
                return e.toLowerCase() === t;
              })
            );
          })(e)
        );
      })
      .sort(function (e, t) {
        return t.cpm - e.cpm;
      })
      .slice(0, n);
  }
  var Sm = {
    getStyles: function () {
      return "";
    },
    addTrack: function () {},
    requestBuild: function () {},
    teardown: function () {},
    startOrResumeRotation: function () {},
    pauseRotation: function () {},
    stopRotationAndFlushPending: function () {},
    renderBonusSlide: function () {},
  };
  function Im(e) {
    return "."
      .concat(e, " {\n  position: relative;\n}\n.")
      .concat(e, "-button {\n  z-index: 2;\n}\n.")
      .concat(
        e,
        "-carousel-progress {\n  position: absolute;\n  top: 0;\n  left: 0;\n  right: 0;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  gap: 6px;\n  padding-top: 2px;\n  z-index: 1;\n}\n."
      )
      .concat(
        e,
        "-carousel-segment {\n  position: relative;\n  overflow: hidden;\n  width: 45px;\n  height: 4px;\n  background: #d0d0d0;\n  border: 1px solid #c0c0c0;\n  border-radius: 3px;\n  flex-shrink: 0;\n}\n."
      )
      .concat(
        e,
        "-carousel-segment-fill {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  background: #333333;\n  transform: scaleX(0);\n  transform-origin: left;\n}"
      );
  }
  function wm(e, t, n) {
    n.setAttribute("data-targeting-".concat(Ni), "carousel");
    var i = e.ownerDocument.createElement("div");
    (i.className = "".concat(t, "-carousel-progress")), e.appendChild(i);
  }
  function _m(e, t, n, i, r, o) {
    var a,
      s,
      c = !1;
    function u(t, i) {
      try {
        return ym({
          bids: n.getUnrenderedValidBidsFromCache(t, Date.now() + 3e3),
          maxRunnerUps: i,
        });
      } catch (n) {
        return (
          e[k](function () {
            return "[CAROUSEL]["
              .concat(t, "] could not read cached bids: ")
              .concat(String(n));
          }),
          []
        );
      }
    }
    function l(n, i) {
      var r = n.adUnit,
        s = n.adUnitCode,
        c = n.className,
        l = n.refreshIntervalSeconds,
        f = t.document.querySelector(".".concat(c, "-carousel-progress"));
      if (f) {
        null == a || a.stop(), (a = void 0);
        var g = t.document.querySelector(".".concat(c)),
          m = t.document.querySelector(".".concat(c, " .fuse-slot-sticky"));
        if (g)
          for (
            var v = 0,
              p = Array.from(
                g.querySelectorAll(".".concat(c, "-carousel-slide"))
              );
            v < p.length;
            v++
          ) {
            p[v].remove();
          }
        m && (m.style.visibility = "");
        var b = s ? u(s, 3).length : 0,
          h = b <= 1 ? 0 : b - 1;
        if (
          (e[k](function () {
            return "[CAROUSEL]["
              .concat(s, "] ")
              .concat(b, " eligible bid(s); sizing ")
              .concat(h, " bonus slide(s)");
          }),
          s && 0 !== h && g)
        ) {
          f.innerHTML = (function (e) {
            return '<div class="'
              .concat(e, '-carousel-segment"><div class="')
              .concat(e, '-carousel-segment-fill"></div></div>');
          })(c).repeat(h + 1);
          var y = Array.from(
              f.querySelectorAll(".".concat(c, "-carousel-segment"))
            ).map(function (e) {
              return {
                element: e,
                fill: e.querySelector(".".concat(c, "-carousel-segment-fill")),
              };
            }),
            S = (null != l ? l : 0) > 0,
            I = S ? Math.floor((1e3 * l) / (h + 1)) : o;
          a = (function (e, t, n) {
            var i,
              r,
              o,
              a,
              s,
              c,
              u = n.slideOne,
              l = n.renderSlide,
              d = n.segments,
              f = null !== (i = n.durationMs) && void 0 !== i ? i : 1e4,
              g = null !== (r = n.transitionMs) && void 0 !== r ? r : 400,
              m = null !== (o = n.singleCycle) && void 0 !== o && o,
              v = n.onCycleComplete,
              p = d.length,
              b = new Array(p),
              h = new Array(p).fill(!1),
              y = 0,
              S = !1,
              I = !1;
            function w() {
              return h.slice(1).some(function (e) {
                return !e;
              });
            }
            function _(e) {
              (h[e] = !0),
                d[e].element.remove(),
                t[k](
                  "[CAROUSEL] slide ".concat(
                    e + 1,
                    " has no renderable bid; collapsed its segment"
                  )
                );
            }
            function E(t) {
              u && (u.style.visibility = 0 === t ? "" : "hidden");
              for (var n = 1; n < p; n++) {
                var i = b[n];
                i &&
                  ((i.style.transition = "none"),
                  (i.style.display = n === t ? "flex" : "none"),
                  (i.style.transform = "translateX(100%)"));
              }
              for (var r = 0; r < p; r++)
                if (!h[r]) {
                  var o = d[r].fill;
                  (o.style.transition = "none"),
                    (o.style.transform = r < t ? "scaleX(1)" : "scaleX(0)");
                }
              var a = b[t];
              h[t] || d[t].fill.getBoundingClientRect(),
                e.requestAnimationFrame(function () {
                  if (
                    S &&
                    y === t &&
                    (a &&
                      ((a.style.transition = "transform ".concat(g, "ms ease")),
                      (a.style.transform = "translateX(0)")),
                    !h[t])
                  ) {
                    var e = d[t].fill;
                    (e.style.transition = "transform ".concat(f, "ms linear")),
                      (e.style.transform = "scaleX(1)");
                  }
                });
            }
            function C() {
              a = e.setTimeout(P, f);
            }
            function T(e) {
              (y = e), E(e), C();
            }
            function A(t, n) {
              c = t;
              var i = n.querySelector("iframe"),
                r = function () {
                  null == i || i.removeEventListener("load", r),
                    S &&
                      c === t &&
                      ((c = void 0),
                      void 0 !== s && (e.clearTimeout(s), (s = void 0)),
                      T(t));
                };
              null == i || i.addEventListener("load", r),
                (s = e.setTimeout(r, 1e3));
            }
            function R() {
              (y = 0),
                E(0),
                D(),
                t[k](
                  "[CAROUSEL] no eligible bonus slide left; settled on slide 1"
                ),
                null == v || v();
            }
            function x() {
              D(),
                (I = !0),
                t[k](
                  "[CAROUSEL] single cycle complete; holding the last slide until refresh"
                ),
                null == v || v();
            }
            function P() {
              for (var e = 1; e <= p; e++) {
                var t = (y + e) % p;
                if (!h[t]) {
                  if (0 === t)
                    return void (m
                      ? x()
                      : w()
                      ? (T(0), null == v || v())
                      : R());
                  if (b[t]) return void T(t);
                  var n = l(t + 1);
                  if (n) return (b[t] = n), void A(t, n);
                  _(t);
                }
              }
              R();
            }
            function O() {
              void 0 !== a && (e.clearTimeout(a), (a = void 0)),
                void 0 !== s && (e.clearTimeout(s), (s = void 0)),
                (c = void 0);
            }
            function D() {
              (S = !1), O();
            }
            return {
              start: function () {
                S ||
                  I ||
                  p <= 1 ||
                  ((S = !0),
                  T(0),
                  t[k](
                    "[CAROUSEL] rotation started over ".concat(p, " slides")
                  ));
              },
              stop: D,
              pause: O,
              resume: function () {
                S && void 0 === a && (E(y), C());
              },
              isRunning: function () {
                return S;
              },
            };
          })(t, e, {
            slideOne: m,
            renderSlide: function (e) {
              return d({
                slideContainer: g,
                adUnit: r,
                adUnitCode: s,
                className: c,
                slideNumber: e,
              });
            },
            segments: y,
            durationMs: I,
            singleCycle: S,
            onCycleComplete: i,
          });
        } else f.innerHTML = "";
      }
    }
    function d(n) {
      var o,
        a,
        s,
        c,
        l,
        d,
        f = n.slideContainer,
        g = n.adUnit,
        m = n.adUnitCode,
        v = n.className,
        p = n.slideNumber,
        h = b(u(m, 1), 1)[0];
      if (h)
        try {
          ((a = t.document.createElement("div")).className = "".concat(
            v,
            "-carousel-slide"
          )),
            (a.dataset.carouselSlide = String(p)),
            (a.style.cssText =
              "position:absolute;top:0;left:0;width:100%;height:100%;display:none;justify-content:center;align-items:center");
          var y = t.document.createElement("iframe");
          y.setAttribute("scrolling", "no"),
            y.setAttribute("frameborder", "0"),
            y.setAttribute("marginwidth", "0"),
            y.setAttribute("marginheight", "0"),
            (y.style.border = "0"),
            (y.width = String(h.width || "")),
            (y.height = String(h.height || ""));
          var S =
            ((s = f.clientWidth),
            (c = f.clientHeight),
            (l = h.width),
            (d = h.height),
            s > 0 && c > 0 && l > 0 && d > 0 ? Math.min(s / l, c / d, 1) : 1);
          S < 1 && (y.style.transform = "scale(".concat(S, ")")),
            a.appendChild(y),
            f.appendChild(a);
          var I =
            y.contentDocument ||
            (null === (o = y.contentWindow) || void 0 === o
              ? void 0
              : o.document);
          return I
            ? i[sl](I, h.adId, e)
              ? (r[Vo]({ bid: h, adUnit: g, adUnitCode: m, slideNumber: p }),
                e[k](function () {
                  return "[CAROUSEL]["
                    .concat(m, "] rendered runner-up ")
                    .concat(h.bidder, " (")
                    .concat(h.adId, ") on slide ")
                    .concat(p, ": ")
                    .concat(
                      JSON.stringify(
                        (function (e) {
                          return {
                            bidder: e.bidder,
                            adId: e.adId,
                            cpm: e.cpm,
                            mediaType: e.mediaType,
                            status: e.status,
                            ttl: e.ttl,
                            responseTimestamp: e.responseTimestamp,
                            width: e.width,
                            height: e.height,
                          };
                        })(h)
                      )
                    );
                }),
                a)
              : void a.remove()
            : (e[k](
                "[CAROUSEL]["
                  .concat(m, "] no iframe document for slide ")
                  .concat(p, ", skipping")
              ),
              void a.remove());
        } catch (t) {
          return (
            e[k](function () {
              return "[CAROUSEL]["
                .concat(m, "] failed to render slide ")
                .concat(p, ": ")
                .concat(String(t));
            }),
            void (null == a || a.remove())
          );
        }
      else
        e[k](
          "[CAROUSEL]["
            .concat(m, "] no eligible runner-up left for slide ")
            .concat(p, ", skipping")
        );
    }
    function f(t) {
      (c = !1),
        (s = void 0),
        l(t, function () {
          return (function (t) {
            var n = s;
            if (!n)
              return (
                (c = !0),
                void e[k](function () {
                  return "[CAROUSEL][".concat(
                    t,
                    "] cycle complete, ready for the next refresh render"
                  );
                })
              );
            e[k](function () {
              return "[CAROUSEL][".concat(
                t,
                "] cycle complete, executing deferred rebuild"
              );
            }),
              f(n);
          })(t.adUnitCode);
        }),
        t.isRefreshRender && t.canRestartRotation() && g();
    }
    function g() {
      null == a || a.start(), null == a || a.resume();
    }
    return {
      getStyles: Im,
      addTrack: wm,
      requestBuild: function (t) {
        if (t.isRefreshRender && a && a.isRunning() && !c)
          return (
            (s = t),
            void e[k](function () {
              return "[CAROUSEL][".concat(
                t.adUnitCode,
                "] mid-cycle refresh render, deferring rebuild to cycle end"
              );
            })
          );
        f(t);
      },
      teardown: function () {
        null == a || a.stop(), (a = void 0), (s = void 0), (c = !1);
      },
      startOrResumeRotation: g,
      pauseRotation: function () {
        null == a || a.pause();
      },
      stopRotationAndFlushPending: function () {
        null == a || a.stop();
        var t = s;
        t &&
          (e[k](function () {
            return "[CAROUSEL][".concat(
              t.adUnitCode,
              "] closed with a rebuild pending, executing it now"
            );
          }),
          f(t));
      },
      renderBonusSlide: d,
    };
  }
  var Em = Symbol(),
    km = Symbol(),
    Cm = Symbol(),
    Tm = Symbol(),
    Am = Symbol(),
    Rm = Symbol(),
    xm = Symbol(),
    Pm = Symbol(),
    Om = Symbol(),
    Dm = Symbol(),
    Nm = Symbol(),
    zm = Symbol(),
    Bm = Symbol(),
    Mm = Symbol(),
    Um = Symbol(),
    jm = Symbol(),
    Lm = Symbol(),
    Fm = Symbol(),
    Gm = Symbol(),
    Vm = Symbol();
  function Hm(e, t, n, i, r, o, a) {
    var s,
      c = !1,
      l = !1,
      d = !1,
      f = function (n) {
        var i;
        if (!n || !t.useZoneCustomiseH5()) return n;
        var o =
          null !== (i = t.generateZoneTemplate(n.id, r)) && void 0 !== i
            ? i
            : n;
        return (
          e[k](
            "[H5]: zoneCustomiser rewrote ".concat(n.id, " to ").concat(o.id)
          ),
          o
        );
      },
      g = function (e) {
        var t;
        return null !== (t = e.originalZoneTemplateId) && void 0 !== t
          ? t
          : e.id;
      },
      m = function () {
        return t.getFuseSlots().find(function (e) {
          var t = e.attributes;
          return !0 === (null == t ? void 0 : t.interstitial);
        });
      },
      v = function (e) {
        return t.getFuseSlots().find(function (t) {
          var n = t.attributes,
            i = t.slot;
          return !0 === (null == n ? void 0 : n.h5Interstitial) && i === e;
        });
      },
      p = function (e) {
        return t.getFuseSlots().find(function (t) {
          var n = t.attributes,
            i = t.slot;
          return !0 === (null == n ? void 0 : n.rewarded) && i === e;
        });
      },
      b = function (e) {
        var n = t.getFuseSlots().find(function (t) {
          var n = t.attributes,
            i = t.id;
          return !0 === (null == n ? void 0 : n.h5Interstitial) && i === e;
        });
        return (
          n &&
            t.isFuseH5Test() &&
            (n.slot = "/6355419/Travel/Europe/France/Paris"),
          n
        );
      },
      h = function (e) {
        var n = t.getFuseSlots().find(function (t) {
          var n = t.attributes,
            i = t.id;
          return !0 === (null == n ? void 0 : n.rewarded) && i === e;
        });
        return (
          n && t.isFuseH5Test() && (n.slot = "6062/sanghan_rweb_ad_unit"), n
        );
      },
      y = function (e) {
        o[Fc](e.slot), (c = !0);
      },
      S = function (e) {
        o[Vc](e.slot), (l = !0);
      },
      I = function (e) {
        o[qc](e.slot), (d = !0);
      },
      w = function () {
        if (c) e[C]("[INTERSTITIAL]: Already present");
        else {
          e[A]("[INTERSTITIAL]: Initialising");
          var t = m();
          if (t)
            if (null == t ? void 0 : t.injectConditionConfig) {
              var r = n[_s](t.injectConditionConfig, t.id, i, function () {
                y(t);
              });
              r[Is]() ? y(t) : r[ys]();
            } else y(t);
          else e[C]("[INTERSTITIAL]: No interstitial slot configured");
        }
      },
      _ = null,
      E = null,
      R = null,
      x = null,
      P = null,
      O = null,
      D = null,
      N = null,
      z = null,
      B = null,
      M = null,
      U = null;
    a[Rt].subscribe(function (t) {
      var n = t.slot.getAdUnitPath();
      e[k](
        "[H5-INTERSTITIAL]: Received gameManualInterstitialSlotReady event for slot ".concat(
          n
        )
      ),
        (M = t);
      var i = v(n);
      if (i && _ && n === i.slot) {
        var r = g(i);
        e[k]("[H5-INTERSTITIAL]: ready callback for ".concat(r)), _(r);
      }
    }),
      a[xt].subscribe(function (t) {
        var n = t.slot.getAdUnitPath();
        e[k](
          "[H5-INTERSTITIAL]: Received gameManualInterstitialSlotClosed event for slot ".concat(
            n
          )
        );
        var i = v(n);
        if (
          (i &&
            (e[k](
              "[H5-INTERSTITIAL]: Clearing H5 interstitial slot for ".concat(
                i.id
              )
            ),
            o[Hc](i.slot),
            (l = !1)),
          i && E)
        ) {
          var r = g(i);
          e[k]("[H5-INTERSTITIAL]: closed callback for ".concat(r)), E(r);
        }
      }),
      a[Pt].subscribe(function (t) {
        var n = t.slotPath;
        e[k](
          "[H5-INTERSTITIAL]: Received h5InterstitialUnsupported event for slot ".concat(
            n
          )
        );
        var i = v(n);
        if (i && x) {
          var r = g(i);
          e[k]("[H5-INTERSTITIAL]: unsupported callback for ".concat(r)), x(r);
        }
      });
    return (
      a[Ot].subscribe(function (t) {
        var n = t.slot.getAdUnitPath();
        e[k](
          "[REWARDED]: Received rewardedSlotReady event for slot ".concat(n)
        ),
          (U = t);
        var i = p(n);
        if (i && P && n === i.slot) {
          var r = g(i);
          e[k]("[REWARDED]: ready callback for ".concat(r)), P(r);
        }
      }),
      a[Dt].subscribe(function (t) {
        var n = t.slot.getAdUnitPath();
        e[k](
          "[REWARDED]: Received rewardedSlotGranted event for slot ".concat(n)
        );
        var i = p(n);
        if (i && O && n === i.slot) {
          var r = g(i);
          e[k]("[REWARDED]: granted callback for ".concat(r)),
            O(r, t.payload || null);
        }
      }),
      a[Nt].subscribe(function (t) {
        var n = t.slot.getAdUnitPath();
        e[k](
          "[REWARDED]: Received rewardedSlotClosed event for slot ".concat(n)
        );
        var i = p(n);
        if (i && D && n === i.slot) {
          var r = g(i);
          e[k]("[REWARDED]: closed callback for ".concat(r)), D(r);
        }
      }),
      a[zt].subscribe(function (t) {
        var n = t.slot.getAdUnitPath();
        e[k](
          "[REWARDED]: Received rewardedSlotVideoCompleted event for slot ".concat(
            n
          )
        );
        var i = p(n);
        if (i && N && n === i.slot) {
          var r = g(i);
          e[k]("[REWARDED]: video completed callback for ".concat(r)), N(r);
        }
      }),
      a[Et].subscribe(function (t) {
        if (t.isEmpty) {
          var n = t.slot.getAdUnitPath(),
            i = v(n);
          if (i && R) {
            o[Hc](i.slot), (l = !1);
            var r = g(i);
            return (
              e[k]("[H5-INTERSTITIAL]: empty callback for ".concat(r)),
              void R(r)
            );
          }
          var a = p(n);
          if (a && z) {
            o[Wc](a.slot), (d = !1);
            var s = g(a);
            e[k]("[REWARDED]: empty callback for ".concat(s)), z(s);
          }
        }
      }),
      a[Bt].subscribe(function (t) {
        var n = t.slotPath;
        e[k](
          "[REWARDED]: Received rewardedUnsupported event for slot ".concat(n)
        );
        var i = p(n);
        if (i && B) {
          var r = g(i);
          e[k]("[REWARDED]: unsupported callback for ".concat(r)), B(r);
        }
      }),
      u(
        u(
          u(
            u(
              u(
                u(
                  u(
                    u(
                      u(
                        u(
                          (s = {
                            get hasInterstitial() {
                              return c;
                            },
                            get hasH5Interstitial() {
                              return l;
                            },
                            get hasRewarded() {
                              return d;
                            },
                          }),
                          Em,
                          function (n) {
                            t.useCmpReadyEvent()
                              ? (e[k](
                                  "[INTERSTITIAL]: Waiting for CMP ready event before configuring Interstitial"
                                ),
                                a[Zt].immediateOrOnce(function (i) {
                                  e[k](
                                    "[INTERSTITIAL]: CMP ready event received, reconfiguring Interstitial with consent data"
                                  ),
                                    t.isStrictCmp()
                                      ? i.allowPersonalisation
                                        ? (e[k](
                                            "[INTERSTITIAL]: CMP is ready and personalisation is allowed, initialising Interstitial"
                                          ),
                                          w(),
                                          n())
                                        : (e[k](
                                            "[INTERSTITIAL]: CMP is ready and personalisation is NOT allowed, skipping Interstitial initialisation"
                                          ),
                                          n(!0))
                                      : (w(), n());
                                }))
                              : (w(), n());
                          }
                        ),
                        km,
                        function () {
                          if (c) {
                            e[A]("[INTERSTITIAL]: Clearing");
                            var t = m();
                            t && (o[Gc](t.slot), (c = !1));
                          } else
                            e[C]("[INTERSTITIAL]: No interstitial to clear");
                        }
                      ),
                      Cm,
                      function () {
                        return Boolean(m());
                      }
                    ),
                    Tm,
                    w
                  ),
                  Rm,
                  function (r) {
                    var s;
                    (e[A]("[H5-INTERSTITIAL]: Registering via public API", _),
                    _ && E)
                      ? ((s = function (t) {
                          !t &&
                            _ &&
                            b(r) &&
                            (function (t) {
                              if (l) {
                                if (
                                  (e[C]("[H5-INTERSTITIAL]: Already present"),
                                  !M)
                                )
                                  return void e[k](
                                    "[H5-INTERSTITIAL]: No H5 interstitialSlotReady event received yet, cannot clear existing slot"
                                  );
                                e[k](
                                  "[H5-INTERSTITIAL]: Processing previously received H5 interstitialSlotReady event for slot ".concat(
                                    M.slot.getAdUnitPath()
                                  )
                                ),
                                  o[Hc](M.slot.getAdUnitPath());
                              }
                              e[A]("[H5-INTERSTITIAL]: Initialising");
                              var r = f(b(t));
                              if (
                                (e[k](
                                  "[H5-INTERSTITIAL]: Retrieved H5 interstitial slot configuration",
                                  r
                                ),
                                r)
                              )
                                if (
                                  null == r ? void 0 : r.injectConditionConfig
                                ) {
                                  var a = n[_s](
                                    r.injectConditionConfig,
                                    r.id,
                                    i,
                                    function () {
                                      S(r);
                                    }
                                  );
                                  a[Is]() ? S(r) : a[ys]();
                                } else S(r);
                              else
                                e[C](
                                  "[H5-INTERSTITIAL]: No H5 interstitial slot configured"
                                );
                            })(r);
                        }),
                        t.useCmpReadyEvent()
                          ? (e[k](
                              "[H5-INTERSTITIAL]: Waiting for CMP ready event before configuring H5 Interstitial"
                            ),
                            a[Zt].immediateOrOnce(function (n) {
                              e[k](
                                "[H5-INTERSTITIAL]: CMP ready event received, reconfiguring H5 Interstitial with consent data"
                              ),
                                t.isStrictCmp()
                                  ? n.allowPersonalisation
                                    ? (e[k](
                                        "[H5-INTERSTITIAL]: CMP is ready and personalisation is allowed, initialising H5 Interstitial"
                                      ),
                                      s())
                                    : (e[k](
                                        "[H5-INTERSTITIAL]: CMP is ready and personalisation is NOT allowed, skipping H5 Interstitial initialisation"
                                      ),
                                      s(!0))
                                  : s();
                            }))
                          : s())
                      : e[T](
                          "[H5-INTERSTITIAL]: Not all callbacks registered. Call onH5InterstitialReady() and onH5InterstitialClosed() before registerH5Interstitial()"
                        );
                  }
                ),
                xm,
                function () {
                  e[k]("[H5-INTERSTITIAL]: Display called via public API"),
                    null == M || M.makeGameManualInterstitialVisible();
                }
              ),
              Pm,
              function (t) {
                e[k]("[H5-INTERSTITIAL]: Registering ready callback"),
                  null !== _ &&
                    e[T](
                      "[H5-INTERSTITIAL]: onH5InterstitialReady: replacing existing callback — only the latest registration will fire. Register a single dispatcher if you need to fan out."
                    ),
                  (_ = t);
              }
            ),
            Om,
            function (t) {
              e[k]("[H5-INTERSTITIAL]: Registering closed callback"),
                null !== E &&
                  e[T](
                    "[H5-INTERSTITIAL]: onH5InterstitialClosed: replacing existing callback — only the latest registration will fire. Register a single dispatcher if you need to fan out."
                  ),
                (E = t);
            }
          ),
          Dm,
          function (t) {
            e[k]("[H5-INTERSTITIAL]: Registering empty callback"),
              null !== R &&
                e[T](
                  "[H5-INTERSTITIAL]: onH5InterstitialEmpty: replacing existing callback — only the latest registration will fire. Register a single dispatcher if you need to fan out."
                ),
              (R = t);
          }
        ),
        Nm,
        function (t) {
          e[k]("[H5-INTERSTITIAL]: Registering unsupported callback"),
            null !== x &&
              e[T](
                "[H5-INTERSTITIAL]: onH5InterstitialUnsupported: replacing existing callback — only the latest registration will fire. Register a single dispatcher if you need to fan out."
              ),
            (x = t);
        }
      ),
      u(
        u(
          u(
            u(
              u(
                u(
                  u(
                    u(
                      u(
                        u(s, Am, function (t) {
                          if (l) {
                            e[A]("[H5-INTERSTITIAL]: Clearing");
                            var n = f(b(t));
                            n && (o[Hc](n.slot), (l = !1));
                          } else e[C]("[H5-INTERSTITIAL]: No H5 interstitial to clear");
                        }),
                        zm,
                        function (r) {
                          var s;
                          (e[A]("[REWARDED]: Registering via public API", P), P)
                            ? ((s = function (t) {
                                !t &&
                                  P &&
                                  h(r) &&
                                  (function (t) {
                                    if (d) {
                                      if (
                                        (e[C]("[REWARDED]: Already present"),
                                        !U)
                                      )
                                        return void e[k](
                                          "[REWARDED]: No rewardedSlotReady event received yet, cannot clear existing slot"
                                        );
                                      e[k](
                                        "[REWARDED]: Processing previously received rewardedSlotReady event for slot ".concat(
                                          U.slot.getAdUnitPath()
                                        )
                                      ),
                                        o[Wc](U.slot.getAdUnitPath());
                                    }
                                    e[A]("[REWARDED]: Initialising");
                                    var r = f(h(t));
                                    if (r)
                                      if (
                                        null == r
                                          ? void 0
                                          : r.injectConditionConfig
                                      ) {
                                        var a = n[_s](
                                          r.injectConditionConfig,
                                          r.id,
                                          i,
                                          function () {
                                            I(r);
                                          }
                                        );
                                        a[Is]() ? I(r) : a[ys]();
                                      } else I(r);
                                    else
                                      e[C](
                                        "[REWARDED]: No rewarded slot configured"
                                      );
                                  })(r);
                              }),
                              t.useCmpReadyEvent()
                                ? (e[k](
                                    "[REWARDED]: Waiting for CMP ready event before configuring Rewarded"
                                  ),
                                  a[Zt].immediateOrOnce(function (n) {
                                    e[k](
                                      "[REWARDED]: CMP ready event received, reconfiguring Rewarded with consent data"
                                    ),
                                      t.isStrictCmp()
                                        ? n.allowPersonalisation
                                          ? (e[k](
                                              "[REWARDED]: CMP is ready and personalisation is allowed, initialising Rewarded"
                                            ),
                                            s())
                                          : (e[k](
                                              "[REWARDED]: CMP is ready and personalisation is NOT allowed, skipping Rewarded initialisation"
                                            ),
                                            s(!0))
                                        : s();
                                  }))
                                : s())
                            : e[T](
                                "[REWARDED]: No ready callback registered. Call onRewardedReady() before registerRewarded()"
                              );
                        }
                      ),
                      Bm,
                      function () {
                        e[k]("[REWARDED]: Making slot visible via public API"),
                          null == U || U.makeRewardedVisible();
                      }
                    ),
                    Mm,
                    function (t) {
                      e[k]("[REWARDED]: Registering ready callback"),
                        null !== P &&
                          e[T](
                            "[REWARDED]: onRewardedReady: replacing existing callback — only the latest registration will fire. Register a single dispatcher if you need to fan out."
                          ),
                        (P = t);
                    }
                  ),
                  Um,
                  function (t) {
                    e[k]("[REWARDED]: Registering granted callback"),
                      null !== O &&
                        e[T](
                          "[REWARDED]: onRewardedGranted: replacing existing callback — only the latest registration will fire. Register a single dispatcher if you need to fan out."
                        ),
                      (O = t);
                  }
                ),
                jm,
                function (t) {
                  e[k]("[REWARDED]: Registering closed callback"),
                    null !== D &&
                      e[T](
                        "[REWARDED]: onRewardedClosed: replacing existing callback — only the latest registration will fire. Register a single dispatcher if you need to fan out."
                      ),
                    (D = t);
                }
              ),
              Lm,
              function (t) {
                e[k]("[REWARDED]: Registering video completed callback"),
                  null !== N &&
                    e[T](
                      "[REWARDED]: onRewardedVideoCompleted: replacing existing callback — only the latest registration will fire. Register a single dispatcher if you need to fan out."
                    ),
                  (N = t);
              }
            ),
            Fm,
            function (t) {
              e[k]("[REWARDED]: Registering empty callback"),
                null !== z &&
                  e[T](
                    "[REWARDED]: onRewardedEmpty: replacing existing callback — only the latest registration will fire. Register a single dispatcher if you need to fan out."
                  ),
                (z = t);
            }
          ),
          Gm,
          function (t) {
            e[k]("[REWARDED]: Registering unsupported callback"),
              null !== B &&
                e[T](
                  "[REWARDED]: onRewardedUnsupported: replacing existing callback — only the latest registration will fire. Register a single dispatcher if you need to fan out."
                ),
              (B = t);
          }
        ),
        Vm,
        function (t) {
          if (d) {
            e[A]("[REWARDED]: Clearing");
            var n = f(h(t));
            n && (o[Wc](n.slot), (d = !1));
          } else e[C]("[REWARDED]: No rewarded slot to clear");
        }
      )
    );
  }
  var qm = Symbol();
  function Wm(e, t, n, i) {
    return u({}, qm, function () {
      e[A]("[SKINS]: Initialising");
      var r = t.getFuseSlots().filter(function (e) {
          return e.isGumGumSkinZone;
        }),
        o = t.getFuseSlots().filter(function (e) {
          var t;
          return null === (t = e.attributes) || void 0 === t ? void 0 : t.rail;
        });
      r.length &&
        o.length &&
        (e[k]("[SKINS] skins and rails slots found. Attach bidWon listener"),
        i[Lt].subscribe(function (t) {
          if (t.bidderCode === Qi) {
            var i = r.reduce(function (e, t) {
              var i = n.getSlotsForTemplateId(t.id);
              return [].concat(
                y(e),
                y(
                  i.map(function (e) {
                    return e.slotDivId;
                  })
                )
              );
            }, []);
            if (
              i.some(function (e) {
                return e === t.adUnitCode;
              })
            ) {
              e[k]("[SKINS] Handling skins bid won", t);
              var a,
                c = s(o);
              try {
                for (c.s(); !(a = c.n()).done; ) {
                  var u,
                    l = a.value,
                    d = s(n.getSlotsForTemplateId(l.id));
                  try {
                    for (d.s(); !(u = d.n()).done; ) {
                      var f = u.value;
                      e[A](
                        "[SKINS]["
                          .concat(l.id, "] Delete slot ")
                          .concat(f.slotDivId)
                      ),
                        n.deleteSlot(f.slotDivId);
                    }
                  } catch (e) {
                    d.e(e);
                  } finally {
                    d.f();
                  }
                }
              } catch (e) {
                c.e(e);
              } finally {
                c.f();
              }
            }
          }
        }));
    });
  }
  var Ym = "publift-primis-script",
    Zm = "primisPlayer",
    Jm = Symbol(),
    Qm = Symbol();
  function Km(e, t, n, i, r) {
    var o = !1,
      a = !1,
      s = t.getVideoSettings(),
      c = function () {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        if (
          (e[k]("[VIDEO]: VideoManager.initVideo(".concat(t, ")")), s.enabled)
        )
          if ((t && !s.injectedAdUnitId) || (!t && s.injectedAdUnitId))
            e[C](
              "[VIDEO]: Video initVideo skipped -  dynamic: "
                .concat(t, ", injectedAdUnitId: ")
                .concat(s.injectedAdUnitId)
            );
          else if (o) e[C]("[VIDEO]: Video all ready setup");
          else {
            var n = i().name;
            !s.breakpoints || s.breakpoints[n]
              ? ("primis" === s.partner && f(s.placementId), (o = !0))
              : e[C]("[VIDEO]: Not starting video at breakpoint ".concat(n));
          }
      },
      l = function () {
        var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
        e[C]("[VIDEO]: Resetting video"), d(), c(t);
      },
      d = function () {
        s.enabled &&
          o &&
          ("primis" === s.partner && g(),
          (o = !1),
          e[C]("[VIDEO]: Removed video script ".concat(Ym)));
      },
      f = function (i) {
        e[k]("[VIDEO]: VideoManager.setupPrimis(".concat(i, ")"));
        var r = t.getSco(),
          o = r
            ? "&schain=1.0,1!".concat(r.asi, ",").concat(r.sellerId, ",1")
            : "";
        if (s.enabled && s.injectedAdUnitId) {
          var a = '[data-fuse="'.concat(s.injectedAdUnitId, '"]'),
            c = n.document.querySelector(a);
          if (c) {
            var u = n.document.createElement("div");
            (u.id = Zm),
              c.appendChild(u),
              e[k](
                "[VIDEO]: Inserted video div into the DOM with selector ".concat(
                  a
                )
              );
          } else
            e[E](
              "[VIDEO]: Injection video library. Element with selector ".concat(
                a,
                " not found"
              )
            );
        }
        ba(
          { logger: e, window: n },
          {
            name: "Primis",
            url: "//live.primis.tech/live/",
            file: "liveView.php",
            query: "s="
              .concat(i)
              .concat(o, "&playerApiId=publift-primis-video"),
            id: Ym,
            insertSelector:
              s.enabled && s.injectedAdUnitId ? "#".concat(Zm) : "body",
          },
          function () {
            e[C]("[VIDEO]: Primis video loaded");
          }
        );
      },
      g = function () {
        var e, t, i;
        null === (e = n.document.getElementById(Ym)) ||
          void 0 === e ||
          e.remove(),
          null === (t = n.document.getElementById(Zm)) ||
            void 0 === t ||
            t.remove(),
          null ===
            (i = n.document.getElementById("primisPlayerContainerDiv")) ||
            void 0 === i ||
            i.remove();
      };
    return u(
      u({}, Jm, function () {
        e[k]("[VIDEO]: VideoManager.init()"),
          s.enabled &&
            (a ||
              (e[k]("[VIDEO]: Configuring video event handlers"),
              r[Ft].subscribe(function () {
                return l(s.enabled && !!s.injectedAdUnitId);
              }),
              r[ft].subscribe(function () {
                return c();
              }),
              r[gt].subscribe(function () {
                return d();
              }),
              c(),
              (a = !0)));
      }),
      Qm,
      c
    );
  }
  var Xm = (function () {
      return a(
        function e(t, n, i, o, a) {
          r(this, e),
            (this.slot = t),
            (this.logger = n),
            (this.breakpointSupplier = i),
            (this.fuseDivElementFactory = o),
            (this.settings = a);
        },
        [
          {
            key: "getSlotNonFluidSizes",
            value: function () {
              var e,
                t,
                n = this.breakpointSupplier().name;
              return null ===
                (t =
                  null === (e = this.slot.sizeMapping) || void 0 === e
                    ? void 0
                    : e[n]) || void 0 === t
                ? void 0
                : t.filter(function (e) {
                    return "fluid" !== e;
                  });
            },
          },
          {
            key: "getSlotMaxNonFluidHeight",
            value: function () {
              var e = this.getSlotNonFluidSizes(),
                t = e
                  ? e.map(function (e) {
                      return Number(e[1]);
                    })
                  : [];
              return t.length ? Math.max.apply(Math, y(t)) : 0;
            },
          },
          {
            key: "getZoneTemplateId",
            value: function () {
              return this.settings.isUseBackwardCompatibleNaming()
                ? this.slot.gamAdUnitId
                : this.slot.id;
            },
          },
          {
            key: "createSlotElement",
            value: function () {
              return this.fuseDivElementFactory[$t](
                this.getZoneTemplateId(),
                "fuse-slot-".concat(this.type)
              );
            },
          },
          {
            key: "toHTML",
            value: function (e) {
              return this.fuseDivElementFactory[en](e);
            },
          },
          {
            key: "getSlotMaxNonFluidWidth",
            value: function () {
              var e = this.getSlotNonFluidSizes(),
                t = e
                  ? e.map(function (e) {
                      return Number(e[0]);
                    })
                  : [];
              return t.length ? Math.max.apply(Math, y(t)) : 0;
            },
          },
          {
            key: "getLogContext",
            value: function () {
              return "[".concat(this.type, "][").concat(this.slot.id, "]:");
            },
          },
          {
            key: "getClassName",
            value: function () {
              return "publift-widget-".concat(this.slot.id);
            },
          },
          {
            key: "getContainerElement",
            value: function () {
              return document.querySelector(
                ".".concat(this.getClassName(), "-container")
              );
            },
          },
          {
            key: "getStylesElement",
            value: function () {
              return document.querySelector(
                "#".concat(this.getClassName(), "-styles")
              );
            },
          },
          {
            key: "getWidgetElement",
            value: function () {
              return document.querySelector(".".concat(this.getClassName()));
            },
          },
        ]
      );
    })(),
    $m = (function (e) {
      function t() {
        var e;
        return r(this, t), ((e = i(this, t, arguments)).type = "dynamic"), e;
      }
      return (
        f(t, e),
        a(t, [
          {
            key: "getAttributes",
            value: function () {
              var e, t, n, i;
              return Object.assign(
                Object.assign({}, this.slot.dynamicAttributes),
                {
                  skip: Number(
                    (null === (e = this.slot.dynamicAttributes) || void 0 === e
                      ? void 0
                      : e.skip) || 0
                  ),
                  each: Number(
                    (null === (t = this.slot.dynamicAttributes) || void 0 === t
                      ? void 0
                      : t.each) || 0
                  ),
                  incrementEach: Number(
                    (null === (n = this.slot.dynamicAttributes) || void 0 === n
                      ? void 0
                      : n.incrementEach) || 0
                  ),
                  repeatHeight: Number(
                    (null === (i = this.slot.dynamicAttributes) || void 0 === i
                      ? void 0
                      : i.repeatHeight) || 1e3
                  ),
                }
              );
            },
          },
          {
            key: "createElement",
            value: function () {
              var e =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : "",
                t =
                  arguments.length > 1 && void 0 !== arguments[1]
                    ? arguments[1]
                    : "",
                n = this.createSlotElement();
              return (
                e &&
                  e.split(" ").forEach(function (e) {
                    return n.classList.add(e);
                  }),
                t && (n.style.cssText = t),
                n
              );
            },
          },
          {
            key: "getInsertNodes",
            value: function (e) {
              var t = this.getLogContext();
              if (!e)
                return (
                  this.logger[E]("".concat(t, " Selector should be defined")),
                  null
                );
              var n = (function (e, t, n) {
                if (!n)
                  return (
                    t[E](
                      "[WIDGETS] safeQuerySelectorAll selector should be defined"
                    ),
                    null
                  );
                try {
                  return e.querySelectorAll(n);
                } catch (e) {
                  t[T]("[WIDGETS] safeQuerySelectorAll error: ".concat(n));
                }
                return null;
              })(document, this.logger, e);
              return (
                (null == n ? void 0 : n.length)
                  ? this.logger[k](
                      ""
                        .concat(t, " Page has ")
                        .concat(n.length, " elements suitable for selector ")
                        .concat(e)
                    )
                  : this.logger[A](
                      ""
                        .concat(t, " No element with selector ")
                        .concat(e, " found")
                    ),
                n
              );
            },
          },
          {
            key: "notFuseSlot",
            value: function (e) {
              return (
                !e ||
                e.getAttribute("data-fuse") !== this.getZoneTemplateId() ||
                (this.logger[k](
                  "".concat(
                    this.getLogContext(),
                    " Skip insertion cause slot already inserted"
                  )
                ),
                !1)
              );
            },
          },
          {
            key: "filterNodes",
            value: function (e) {
              var t = this.getAttributes(),
                n = t.skip,
                i = t.each,
                r = t.position,
                o = t.incrementEach,
                a = [],
                s = 0,
                c = i;
              return (
                e.forEach(function (e, t) {
                  var i = t + 1;
                  if (n && i <= n) return !1;
                  if ("incontent" !== r && c) {
                    if ((i - n - s) % c !== 0) return !1;
                    o && ((s += c), (c += o));
                  }
                  a.push(e);
                }),
                a
              );
            },
          },
          {
            key: "getZoneDiv",
            value: function (e) {
              return arguments.length > 1 &&
                void 0 !== arguments[1] &&
                arguments[1]
                ? e.querySelector("div[data-fuse]")
                : e;
            },
          },
          {
            key: "insert",
            value: function () {
              var e = this,
                t = this.getAttributes(),
                n = t.selector,
                i = t.position,
                r = t.classNames,
                o = t.css,
                a = t.wrapperContent,
                s = t.repeatHeight,
                c = this.getInsertNodes(n);
              if (!(null == c ? void 0 : c.length))
                return (
                  this.logger[k](
                    "".concat(this.getLogContext(), " Injection skipped")
                  ),
                  []
                );
              var u = 0,
                l = [];
              return (
                this.filterNodes(c).forEach(function (t) {
                  var n = e.createElement(r, o),
                    c = n;
                  a && (n = e.wrapElement(n, a));
                  var d = t.nextElementSibling,
                    f = t.parentNode,
                    g = t.previousElementSibling,
                    m = t.lastElementChild;
                  switch (i) {
                    case "after":
                      e.notFuseSlot(d) && (f.insertBefore(n, d), l.push(c));
                      break;
                    case "before":
                      e.notFuseSlot(g) && (f.insertBefore(n, t), l.push(c));
                      break;
                    case "replace":
                      t.replaceWith(n), l.push(c);
                      break;
                    case "incontent":
                      var v =
                          t.getBoundingClientRect().top +
                          t.getBoundingClientRect().height +
                          document.documentElement.scrollTop,
                        p = Math.floor(v / s);
                      p > u &&
                        ((u = p),
                        e.notFuseSlot(d) && (f.insertBefore(n, d), l.push(c)));
                      break;
                    default:
                      e.notFuseSlot(m) && (t.appendChild(n), l.push(c));
                  }
                }),
                l
              );
            },
          },
          {
            key: "wrapElement",
            value: function (e, t) {
              var n = document.createElement("div");
              return (
                (n.innerHTML = t),
                n.firstElementChild.appendChild(e),
                n.firstElementChild
              );
            },
          },
          {
            key: "delete",
            value: function () {
              var e = document.querySelectorAll(
                '[data-fuse="'.concat(this.getZoneTemplateId(), '"]')
              );
              return (
                e.forEach(function (e) {
                  e.remove();
                }),
                e.length > 0
              );
            },
          },
          {
            key: "hide",
            value: function () {
              throw new Error("Method not implemented.");
            },
          },
          {
            key: "show",
            value: function () {
              throw new Error("Method not implemented.");
            },
          },
          {
            key: "onBreakpointChange",
            value: function () {
              throw new Error("Method not implemented.");
            },
          },
        ])
      );
    })(Xm),
    ev = (function (e) {
      function t(e, n, o, a, s, c, u, l, d) {
        var f;
        return (
          r(this, t),
          ((f = i(this, t, [e, n, o, s, l])).slot = e),
          (f.logger = n),
          (f.breakpointSupplier = o),
          (f.browserWindow = a),
          (f.fuseDivElementFactory = s),
          (f.registerAdRendered = c),
          (f.widgetsRenderer = u),
          (f.settings = l),
          (f.slotTargeting = d),
          (f.type = "interscroller"),
          f
        );
      }
      return (
        f(t, e),
        a(t, [
          {
            key: "getAttributes",
            value: function () {
              return Object.assign(
                {
                  selector: ".adBreak",
                  showBanner: !1,
                  height: "100vh",
                  zIndex: 1e7,
                  top: "auto",
                },
                this.slot.interscrollerAttributes
              );
            },
          },
          {
            key: "getTopOffset",
            value: function () {
              return this.widgetsRenderer.getMiniScrollersTopOffset();
            },
          },
          {
            key: "insert",
            value: function () {
              var e = this,
                t = this.getAttributes(),
                n = t.showBanner,
                i = t.zIndex,
                r = t.top,
                o = t.height,
                a = t.selector,
                s = this.getSlotMaxNonFluidHeight(),
                c = this.createSlotElement(),
                u = this.getClassName(),
                l = n
                  ? '<div class="'.concat(
                      u,
                      '-container-message banner_top">Advertisement</div>'
                    )
                  : "",
                d = this.toHTML(
                  '\n    <div class="'
                    .concat(u, '-container">\n      ')
                    .concat(l, '\n        <div class="')
                    .concat(u, '-scroll-clip">\n          <div class="')
                    .concat(u, ' publift-widget-interscroller">')
                    .concat(
                      c.outerHTML,
                      "</div>\n        </div>\n    </div>\n  "
                    )
                ),
                f = this.toHTML(
                  '\n  <style id="'
                    .concat(u, '-styles">\n  .')
                    .concat(
                      u,
                      "-container {\n    width: 100vw;\n    min-height: "
                    )
                    .concat(o, ";\n    z-index: ")
                    .concat(i, ";\n    position: relative;\n    display: ")
                    .concat(0 === s ? "none" : "block", ";\n  }\n\n  .")
                    .concat(
                      u,
                      "-container-message {\n    position: absolute;\n    background-color: black;\n    color: white;\n    padding: .5em;\n    text-align: center;\n    font-family: sans-serif;\n    width: calc(100% - 1em);\n    z-index: 9999;\n  }\n\n  ."
                    )
                    .concat(
                      u,
                      "-scroll-clip {\n    position: absolute;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    margin: 0;\n    padding: 0;\n    clip-path: inset(0px);\n    clip: rect(0px, auto, auto, 0px);\n    min-height: "
                    )
                    .concat(o, "\n  }\n\n  .")
                    .concat(u, " {\n    position: fixed;\n    top: ")
                    .concat(
                      r ||
                        this.widgetsRenderer.getMiniScrollersTopOffset() + "px",
                      " !important;\n    left: 0;\n    width: 100%;\n    height: 100%;\n    margin: 0;\n    padding: 0;\n    bottom: 0;\n    transform: translateZ(0px);\n  }\n  </style>\n  "
                    )
                ),
                g = document.querySelector("body");
              if (g) {
                var m = zs(document, this.logger, a);
                if (m) {
                  g.insertAdjacentElement("beforeend", f), m.appendChild(d);
                  var v =
                    d.getBoundingClientRect().x - g.getBoundingClientRect().x;
                  return (
                    (d.style.marginLeft = "-".concat(v, "px")),
                    (d.style.marginRight = "-".concat(v, "px")),
                    [c]
                  );
                }
                this.logger[A](
                  ""
                    .concat(
                      this.getLogContext(),
                      " insertionPoint with selector not found: "
                    )
                    .concat(a)
                );
              }
              return (
                this.registerAdRendered(function (t) {
                  if (
                    (e.logger[k](function () {
                      return ""
                        .concat(e.getLogContext(), " gpt event ")
                        .concat(JSON.stringify(t));
                    }),
                    -1 !==
                      t.slot
                        .getSlotElementId()
                        .indexOf(e.getZoneTemplateId()) &&
                      (e.logger[k](
                        "".concat(e.getLogContext(), " gpt event suit")
                      ),
                      t.creativeId && t.size))
                  ) {
                    e.logger[k](
                      ""
                        .concat(e.getLogContext(), " gpt event creative ")
                        .concat(t.size[1])
                    );
                    var n = Number(t.size[1]),
                      i = 0,
                      r = e.slotTargeting[Tc](t.slot);
                    1 === n &&
                      r &&
                      ((i = Ci(r)[1]),
                      e.logger[k](
                        ""
                          .concat(e.getLogContext(), " get height ")
                          .concat(i, " from targeting")
                      )),
                      e.updateWidgetPosition(i || n);
                  }
                }),
                []
              );
            },
          },
          {
            key: "updateWidgetPosition",
            value: function (e) {
              var t = this.getSlotMaxNonFluidHeight(),
                n = this.widgetsRenderer.getMiniScrollersTopOffset(),
                i = (this.browserWindow.innerHeight - (e > 1 ? e : t)) / 2,
                r = n;
              this.logger[k](
                ""
                  .concat(this.getLogContext(), " get top offset ")
                  .concat(r, " for adunit size ")
                  .concat(e, " maxHeight ")
                  .concat(t, " topOffsetCentered ")
                  .concat(i, " topOffsetSettings ")
                  .concat(n)
              ),
                (this.getWidgetElement().style.top = "".concat(r, "px"));
            },
          },
          {
            key: "onBreakpointChange",
            value: function () {
              var e = this.getSlotMaxNonFluidHeight(),
                t = this.getContainerElement();
              t && (t.style.display = 0 === e ? "none" : "block");
            },
          },
          {
            key: "delete",
            value: function () {
              var e = this.getStylesElement(),
                t = this.getContainerElement();
              return !(!e || !t) && (e.remove(), t.remove(), !0);
            },
          },
          {
            key: "hide",
            value: function () {
              return (this.getContainerElement().style.display = "none"), !0;
            },
          },
          {
            key: "show",
            value: function () {
              return (this.getContainerElement().style.display = "block"), !0;
            },
          },
        ])
      );
    })(Xm),
    tv = "fuse-slot-scroll-to-stick",
    nv = "--fuse-scroll-to-stick-width";
  function iv(e, t) {
    if (!e.classList.contains(tv)) {
      for (
        var n = 0, i = Array.from(e.querySelectorAll(".fuse-slot"));
        n < i.length;
        n++
      ) {
        var r = i[n],
          o = t.getComputedStyle(r).width;
        /px$/.test(o) && parseFloat(o) > 0 && r.style.setProperty(nv, o);
      }
      e.classList.add(tv);
    }
  }
  function rv(e) {
    if (e.classList.contains(tv)) {
      e.classList.remove(tv);
      for (
        var t = 0, n = Array.from(e.querySelectorAll(".fuse-slot"));
        t < n.length;
        t++
      ) {
        n[t].style.removeProperty(nv);
      }
    }
  }
  var ov = (function (e) {
    function t(e) {
      var n, o;
      r(this, t);
      var a = e.slot,
        s = e.logger,
        c = e.viewportInfo,
        u = e.browserWindow,
        l = e.fuseDivElementFactory,
        d = e.registerAdRendered,
        f = e.getRefreshIntervalSeconds,
        g = e.settings,
        m = e.refreshManager,
        v = e.slotRegistry,
        p = e.onShowCloseCallback,
        b = e.slotTargeting,
        h = e.waitForCreative,
        y = void 0 === h || h,
        S = e.carousel;
      return (
        ((n = i(this, t, [a, s, c[fn], l, g])).loadingByCreative = !1),
        (n.hiddenForever = !1),
        (n.hasLoadedCreative = !1),
        (n.type = "sticky"),
        (n.barScrollHeight = 0),
        (n.barHeight = 60),
        (n.scrollingHeight = 500),
        (n.scrollCreative = !1),
        (n.creativeHeight = 0),
        (n.scrollOffset = 0),
        (n.scrollPosition = 0),
        (n.scrollMultiplier = 0),
        (n.slotRenderCallbackRegistered = !1),
        (n.viewportInfo = c),
        (n.browserWindow = u),
        (n.registerAdRendered = d),
        (n.getRefreshIntervalSeconds = f),
        (n.refreshManager = m),
        (n.slotRegistry = v),
        (n.onShowCloseCallback = p),
        (n.slotTargeting = b),
        (n.waitForCreative = y),
        (n.carousel = S),
        (n.attributes = n.makeAttributes()),
        (n.scrollCreative =
          (null === (o = n.slot.stickyAttributes) || void 0 === o
            ? void 0
            : o.scrollCreative) || !1),
        (n.scrollableElement = n.getScrollableElement()),
        n.setHeights(0),
        n
      );
    }
    return (
      f(t, e),
      a(t, [
        {
          key: "getScrollableElement",
          value: function () {
            var e, t;
            if (
              null === (e = this.slot.stickyAttributes) || void 0 === e
                ? void 0
                : e.scrollableSelector
            ) {
              var n = zs(
                this.browserWindow.document,
                this.logger,
                null === (t = this.slot.stickyAttributes) || void 0 === t
                  ? void 0
                  : t.scrollableSelector
              );
              if (n) return n;
            }
            return this.browserWindow;
          },
        },
        {
          key: "createWidget",
          value: function (e) {
            var t = this.getClassName();
            return this.toHTML(
              '\n<div class="'
                .concat(t, '-container closed" style="display: ')
                .concat(0 === e ? "none" : "block", '">\n<div class="')
                .concat(t, '-container-background">\n</div>\n  <div class="')
                .concat(
                  t,
                  '-button">\n    <div></div>\n    <div></div>\n  </div>\n  <div class="'
                )
                .concat(t, '">\n  </div>\n</div>\n')
            );
          },
        },
        {
          key: "getHideAtSelector",
          value: function () {
            return this.getAttributes().hideSelector;
          },
        },
        {
          key: "getHideAtElement",
          value: function () {
            var e = this.getHideAtSelector();
            return e ? zs(document, this.logger, e) : null;
          },
        },
        {
          key: "getFixedElement",
          value: function () {
            var e = this.getAttributes().fixedSelector;
            return e ? zs(document, this.logger, e) : null;
          },
        },
        {
          key: "getFixedClass",
          value: function () {
            return "".concat(this.getClassName(), "-fixed");
          },
        },
        {
          key: "getWidgetCloseButtonElement",
          value: function () {
            return document.querySelector(
              ".".concat(this.getClassName(), "-button")
            );
          },
        },
        {
          key: "makeAttributes",
          value: function () {
            var e = Object.assign(
              {
                bgColor: "#EFEFEF",
                bgOpacity: 0.7,
                allowClose: !1,
                buttonColor: "#313131",
                barColor: "#EFEFEF",
                borderWidth: "0px",
                zIndex: 2147483645,
                compact: !1,
              },
              this.slot.stickyAttributes
            );
            return (
              e.compact && ((e.bgOpacity = 1), (e.bgColor = e.barColor)), e
            );
          },
        },
        {
          key: "addContent",
          value: function (e, t) {
            var n = this,
              i = this.getClassName(),
              r = e.querySelector(".".concat(i)),
              o = this.createSlotElement();
            r.appendChild(o),
              this.carousel.addTrack(e, i, o),
              e
                .querySelector(".".concat(i, "-button"))
                .addEventListener("click", function () {
                  e.classList.contains("closed")
                    ? n.onShow()
                    : (n.onClose(), n.carousel.stopRotationAndFlushPending()),
                    clearInterval(n.hideAtElementInterval);
                });
            var a = document.querySelector("body");
            return (
              null == a || a.insertAdjacentElement("beforeend", t),
              null == a || a.insertAdjacentElement("beforeend", e),
              o
            );
          },
        },
        {
          key: "getButtonStyles",
          value: function (e, t, n, i, r) {
            return e
              ? t
                ? "border-radius: 0 0 2px 2px; top: ".concat(n, "px;")
                : "border-radius: 2px 2px 0 0; top: -20px;"
              : t
              ? "border-radius: 2px 2px 0 0; top: ".concat(i - 20 + r, "px;")
              : "border-radius: 0 0 2px 2px; top: 0px;";
          },
        },
        {
          key: "getFixedSelectorStyles",
          value: function (e, t, n, i, r) {
            return t
              ? "."
                  .concat(e, "-fixed {\n  ")
                  .concat(n ? "top" : "bottom", " : ")
                  .concat(i ? r : 0, "px !important;\n}\n")
                  .concat(t, " {\n  transition: ")
                  .concat(n ? "top" : "bottom", " .3s linear;\n}")
              : "";
          },
        },
        {
          key: "createStyles",
          value: function () {
            var e,
              t = this.getAttributes(),
              n = t.zIndex,
              i = t.compact,
              r = t.isTop,
              o = t.isButtonOutside,
              a = t.bgColor,
              s = t.bgOpacity,
              c = t.barColor,
              u = t.allowReopen,
              l = t.buttonColor,
              d = t.fixedSelector,
              f = t.borderWidth,
              g = this.getSlotMaxNonFluidHeight(),
              m = this.getContainerBordersSize(),
              v = this.getContainerBorderSize(),
              p = g + m,
              b = this.getSlotMaxNonFluidWidth() + m,
              h = u && o ? v : 0,
              y = this.getClassName();
            return this.toHTML(
              '\n<style id="'
                .concat(y, '-styles">\n.')
                .concat(y, "-container {\n  direction: ltr;\n  z-index: ")
                .concat(n, ";\n  position: fixed;\n  ")
                .concat(r ? "top: 0" : "bottom: 0", ";\n  width: ")
                .concat(i ? b + "px" : "100%", ";\n  height: ")
                .concat(
                  p,
                  "px;\n  transition: transform .3s linear, height .3s linear;\n  "
                )
                .concat(o ? "" : "overflow: hidden;", "\n  ")
                .concat(
                  i ? "left: 50%; transform: translateX(-50%);" : "left: 0;",
                  "\n}\n\n."
                )
                .concat(y, "-container-background {\n  background-color: ")
                .concat(a, ";\n  opacity: ")
                .concat(
                  s,
                  ";\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  z-index: -1;\n}\n\n."
                )
                .concat(
                  y,
                  "-button {\n  width: 40px;\n  margin-left: 2px;\n  height: 20px;\n  background-color: "
                )
                .concat(
                  c,
                  ";\n  flex-direction: row;\n  justify-content: center;\n  align-items: center;\n  position: absolute;\n  display: none;\n  transition: top .3s linear;\n  "
                )
                .concat(
                  this.getButtonStyles(Boolean(o), Boolean(r), p, g, v),
                  "\n}\n."
                )
                .concat(y, "-button :first-child, .")
                .concat(y, "-button :last-child  {\n  background-color: ")
                .concat(
                  l,
                  ";\n  width: 13px;\n  height: 3px;\n  border-radius: 2px;\n}\n."
                )
                .concat(y, "-button :first-child {\n  transform: rotate(")
                .concat(r ? "-" : "", "30deg) translateX(2px);\n}\n.")
                .concat(y, "-button :last-child {\n  transform: rotate(")
                .concat(r ? "" : "-", "30deg) translateX(-2px);\n}\n.")
                .concat(y, " {\n  width: ")
                .concat(i ? b + "px" : "100%", ";\n  height: ")
                .concat(
                  p,
                  "px;\n  display: flex;\n  justify-content: center;\n  align-items: "
                )
                .concat(
                  this.scrollCreative ? "baseline" : "center",
                  ";\n  transition: transform .3s linear, height .3s linear;\n  border"
                )
                .concat(i ? "" : r ? "-bottom" : "-top", ": ")
                .concat(f, " solid ")
                .concat(c, ";\n  ")
                .concat(
                  (
                    null === (e = this.slot.stickyAttributes) || void 0 === e
                      ? void 0
                      : e.scrollCreative
                  )
                    ? "overflow: hidden"
                    : "",
                  "\n}\n."
                )
                .concat(y, "-container.closed {\n  ")
                .concat(
                  r
                    ? "transform: translateY(-"
                        .concat(p - h, "px)")
                        .concat(i ? " TranslateX(-50%)" : "", ";")
                    : "height: " + h + "px !important;",
                  "\n}\n."
                )
                .concat(y, "-container.closed .")
                .concat(y, "-button {\n  visibility: ")
                .concat(u ? "visible" : "hidden", ";\n  ")
                .concat(u ? "" : "display: none;", "\n}\n.")
                .concat(y, "-container.closed .")
                .concat(y, "-button :first-child {\n  transform: rotate(")
                .concat(r ? "" : "-", "30deg) translateX(2px);\n}\n.")
                .concat(y, "-container.closed .")
                .concat(y, "-button :last-child {\n  transform: rotate(")
                .concat(r ? "-" : "", "30deg) translateX(-2px);\n}\n")
                .concat(this.carousel.getStyles(y), "\n")
                .concat(
                  this.getFixedSelectorStyles(y, d || "", Boolean(r), g, p),
                  "\n</style>\n"
                )
            );
          },
        },
        {
          key: "getContainerBorderSize",
          value: function () {
            var e = this.getAttributes().borderWidth;
            return Number(e.substring(0, e.length - 2));
          },
        },
        {
          key: "getContainerBordersSize",
          value: function () {
            var e = this.getAttributes().compact;
            return this.getContainerBorderSize() * (e ? 2 : 1);
          },
        },
        {
          key: "getAttributes",
          value: function () {
            return this.attributes;
          },
        },
        {
          key: "insert",
          value: function () {
            var e = this;
            this.logger[k]("".concat(this.getLogContext(), " add widget"));
            var t = this.createWidget(this.getSlotMaxNonFluidHeight()),
              n = this.createStyles(),
              i = this.addContent(t, n);
            return (
              this.browserWindow.requestAnimationFrame(function () {
                e.logger[k](
                  ""
                    .concat(
                      e.getLogContext(),
                      " showing on insert with waitForCreative "
                    )
                    .concat(e.waitForCreative)
                ),
                  e.show();
              }),
              this.getHideAtSelector() && this.setHideAtElementListener(),
              this.scrollCreative &&
                this.scrollableElement &&
                this.scrollableElement.addEventListener("scroll", function () {
                  e.updateWidgetPosition();
                }),
              [i]
            );
          },
        },
        {
          key: "getSlotMaxNonFluidHeight",
          value: function () {
            return this.barHeight;
          },
        },
        {
          key: "setHeights",
          value: function (e) {
            this.creativeHeight = e;
            var t = this.getSlotNonFluidSizes(),
              n = (null == t ? void 0 : t.length)
                ? t.map(function (e) {
                    return Number(e[1]);
                  })
                : [0],
              i = this.slot.stickyAttributes.heightCalculationMethod,
              r = n.sort(function (e, t) {
                return t - e;
              });
            if (this.scrollCreative)
              switch (i) {
                case "half_max":
                  this.barHeight = r[0] / 2 + 1;
                  break;
                case "second_max":
                  this.barHeight = r[1] || r[0];
                  break;
                case "min":
                  this.barHeight = Math.min.apply(Math, y(n));
                  break;
                default:
                  this.barHeight = Math.max.apply(Math, y(n));
              }
            else this.barHeight = Math.max.apply(Math, y(n));
            this.barScrollHeight = e ? e - this.barHeight : 0;
          },
        },
        {
          key: "hideAtElementListener",
          value: function () {
            var e = this.getContainerElement(),
              t = this.getHideAtElement(),
              n = this.getAttributes().isHideForever;
            ae(t) &&
              e &&
              (Au(this.viewportInfo[mn](), t, 1, 0)
                ? e.classList.contains("closed") ||
                  (this.hide(), n && clearInterval(this.hideAtElementInterval))
                : e.classList.contains("closed") &&
                  (this.logger[k](
                    ""
                      .concat(
                        this.getLogContext(),
                        " showing from hideAtElementListener with waitForCreative "
                      )
                      .concat(this.waitForCreative)
                  ),
                  this.show()));
          },
        },
        {
          key: "setHideAtElementListener",
          value: function () {
            var e = this;
            this.hideAtElementInterval = setInterval(function () {
              e.hideAtElementListener();
            }, 500);
          },
        },
        {
          key: "isHideSelectorVisible",
          value: function () {
            var e = this.getHideAtElement();
            return !(!e || !Au(this.viewportInfo[mn](), e, 1, 0));
          },
        },
        {
          key: "onBreakpointChange",
          value: function () {
            var e = this.getAttributes().compact,
              t = this.getContainerElement(),
              n = this.getWidgetElement();
            if (n) {
              this.setHeights(0);
              var i = this.barHeight,
                r = this.getSlotMaxNonFluidWidth(),
                o = this.getContainerBordersSize(),
                a = i + o,
                s = r + o;
              (t.style.height = (0 === i ? 0 : a) + "px"),
                (t.style.display = 0 === i ? "none" : "block"),
                e &&
                  i &&
                  ((t.style.width = s + "px"), (n.style.width = r + "px")),
                (n.style.height = i + "px"),
                0 === i || this.isHideSelectorVisible()
                  ? this.updateFixedElement(!0)
                  : this.updateFixedElement(),
                (this.getStylesElement().innerHTML =
                  this.createStyles().innerHTML);
            }
          },
        },
        {
          key: "delete",
          value: function () {
            this.logger[k]("".concat(this.getLogContext(), " delete sticky")),
              this.carousel.teardown();
            var e = this.getStylesElement(),
              t = this.getContainerElement();
            return (
              this.updateFixedElement(!0),
              this.getHideAtSelector() &&
                clearInterval(this.hideAtElementInterval),
              e && e.remove(),
              t && t.remove(),
              !0
            );
          },
        },
        {
          key: "getSlotElement",
          value: function () {
            return document.querySelector(
              ".".concat(this.getClassName(), " .fuse-slot-sticky")
            );
          },
        },
        {
          key: "getScrollY",
          value: function () {
            var e;
            return (
              null === (e = this.slot.stickyAttributes) || void 0 === e
                ? void 0
                : e.scrollableSelector
            )
              ? this.scrollableElement.scrollTop
              : this.scrollableElement.scrollY;
          },
        },
        {
          key: "updateWidgetPosition",
          value: function (e) {
            if (
              this.scrollCreative &&
              this.hasLoadedCreative &&
              this.slot.stickyAttributes
            ) {
              var t = this.slot.stickyAttributes,
                n = t.scrollingHeight,
                i = t.scrollableSelector;
              if (n) {
                var r = n.trim();
                r.includes("vh")
                  ? (this.scrollingHeight = i
                      ? this.scrollableElement.scrollHeight -
                        (this.scrollableElement.offsetHeight || 0)
                      : Number(r.replace("vh", "")) *
                        this.browserWindow.innerHeight)
                  : (this.scrollingHeight = Number(r.replace("px", "")));
              }
              this.scrollMultiplier =
                this.barScrollHeight / this.scrollingHeight;
              var o = this.getScrollY();
              if (
                (this.logger[k](
                  "".concat(
                    this.getLogContext(),
                    " updateWidgetPosition before"
                  ),
                  e,
                  this.creativeHeight,
                  this.barHeight,
                  this.scrollOffset,
                  this.scrollPosition,
                  this.getWidgetElement().style.marginTop,
                  o,
                  this.scrollingHeight
                ),
                e)
              )
                this.getWidgetElement().style.alignItems =
                  this.creativeHeight > this.barHeight
                    ? "baseline"
                    : this.attributes.isTop
                    ? "start"
                    : "end";
              else if (this.creativeHeight > this.barHeight) {
                var a = o - this.scrollPosition,
                  s = a * this.scrollMultiplier;
                (this.scrollOffset += s),
                  this.logger[k](
                    "".concat(
                      this.getLogContext(),
                      " updateWidgetPosition check"
                    ),
                    s,
                    a,
                    this.scrollOffset
                  ),
                  a <= 0
                    ? this.scrollOffset <= 0 && (this.scrollOffset = 0)
                    : this.scrollOffset > this.barScrollHeight &&
                      (this.scrollOffset = this.barScrollHeight),
                  (this.getSlotElement().style.marginTop =
                    "-" + this.scrollOffset + "px"),
                  (this.scrollPosition = o);
              }
              this.logger[k](
                "".concat(this.getLogContext(), " updateWidgetPosition after"),
                e,
                this.creativeHeight,
                this.barHeight,
                this.scrollOffset,
                this.scrollPosition,
                this.getWidgetElement().style.marginTop,
                this.scrollMultiplier,
                this.barScrollHeight
              );
            }
          },
        },
        {
          key: "buildCarousel",
          value: function () {
            var e,
              t = this;
            this.carousel.requestBuild({
              adUnit: this.slot,
              adUnitCode:
                null ===
                  (e = this.slotRegistry.getSlotsForTemplateId(
                    this.slot.id
                  )[0]) || void 0 === e
                  ? void 0
                  : e.slotDivId,
              className: this.getClassName(),
              refreshIntervalSeconds: this.getRefreshIntervalSeconds(),
              isRefreshRender: this.hasLoadedCreative,
              canRestartRotation: function () {
                var e;
                return (
                  !t.isHideSelectorVisible() &&
                  !(null === (e = t.getContainerElement()) || void 0 === e
                    ? void 0
                    : e.classList.contains("closed"))
                );
              },
            });
          },
        },
        {
          key: "show",
          value: function () {
            var e = this,
              t = this.getZoneTemplateId();
            return (
              this.loadingByCreative ||
                (this.waitForCreative && !this.hasLoadedCreative
                  ? ((this.loadingByCreative = !0),
                    this.slotRenderCallbackRegistered ||
                      (this.logger[k](
                        "".concat(
                          this.getLogContext(),
                          " register slotRender callback"
                        )
                      ),
                      this.registerAdRendered(function (n) {
                        if (-1 !== n.slot.getSlotElementId().indexOf(t)) {
                          if (e.scrollCreative && n.size) {
                            var i = Number(n.size[1]),
                              r = 0,
                              o = e.slotTargeting[Tc](n.slot);
                            1 === i &&
                              o &&
                              ((r = Ci(o)[1]),
                              e.logger[k](
                                ""
                                  .concat(e.getLogContext(), " get height ")
                                  .concat(r, " from targeting")
                              )),
                              e.setHeights(r || i),
                              e.updateWidgetPosition(!0);
                          }
                          e.logger[k](
                            ""
                              .concat(
                                e.getLogContext(),
                                " show widget by creative "
                              )
                              .concat(n.slot.getSlotElementId())
                          ),
                            n.isEmpty || e.buildCarousel(),
                            !e.isHideSelectorVisible() && e.loadingByCreative
                              ? e.onShow()
                              : e.logger[k](
                                  ""
                                    .concat(
                                      e.getLogContext(),
                                      " unable to show widget by creative "
                                    )
                                    .concat(
                                      n.slot.getSlotElementId(),
                                      ", isHideSelectorVisible: "
                                    )
                                    .concat(
                                      e.isHideSelectorVisible(),
                                      ", loadingByCreative: "
                                    )
                                    .concat(e.loadingByCreative)
                                ),
                            (e.loadingByCreative = !1),
                            (e.hasLoadedCreative = !0),
                            e.logger[k](
                              ""
                                .concat(e.getLogContext(), " has loaded ")
                                .concat(n.slot.getSlotElementId())
                            );
                        }
                      }),
                      (this.slotRenderCallbackRegistered = !0)))
                  : this.onShow()),
              !0
            );
          },
        },
        {
          key: "onShow",
          value: function () {
            var e = this.getContainerElement();
            if (e) {
              e.classList.remove("closed"), this.updateFixedElement();
              var t,
                n = s(
                  this.slotRegistry.getSlotsForTemplateId(
                    this.getZoneTemplateId()
                  )
                );
              try {
                for (n.s(); !(t = n.n()).done; ) {
                  var i = t.value;
                  i && this.refreshManager[Jd](i.slotDivId);
                }
              } catch (e) {
                n.e(e);
              } finally {
                n.f();
              }
              this.onShowCloseCallback();
              var r = this.getClassName(),
                o = this.getAttributes().allowClose,
                a = e.querySelector(".".concat(r, "-button"));
              a && o && (a.style.display = "flex"),
                this.carousel.startOrResumeRotation();
            }
          },
        },
        {
          key: "onClose",
          value: function () {
            var e = this.getContainerElement();
            if (e) {
              e.classList.add("closed"), this.updateFixedElement(!0);
              var t,
                n = s(
                  this.slotRegistry.getSlotsForTemplateId(
                    this.getZoneTemplateId()
                  )
                );
              try {
                for (n.s(); !(t = n.n()).done; ) {
                  var i = t.value;
                  i && this.refreshManager[Zd](i.slotDivId);
                }
              } catch (e) {
                n.e(e);
              } finally {
                n.f();
              }
              this.onShowCloseCallback();
            }
          },
        },
        {
          key: "hide",
          value: function () {
            return (
              this.logger[k]("".concat(this.getLogContext(), " hiding")),
              this.onClose(),
              this.carousel.pauseRotation(),
              !0
            );
          },
        },
        {
          key: "updateFixedElement",
          value: function () {
            var e =
              arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            this.logger[k](
              ""
                .concat(this.getLogContext(), " updateFixedElement ")
                .concat(e ? "restore" : "update")
            );
            var t = this.getFixedElement();
            if (t) {
              var n = this.getFixedClass();
              e ? t.classList.remove(n) : t.classList.add(n);
            }
          },
        },
      ])
    );
  })(Xm);
  function av(e, t, n, i, r, o, a, c, u, l, d, f, g, m) {
    var v = !1,
      p = [];
    function b() {
      return t.getFuseSlots().filter(function (e) {
        var t;
        return null === (t = e.attributes) || void 0 === t ? void 0 : t.sticky;
      });
    }
    function h() {
      return t.getFuseSlots().filter(function (e) {
        var t;
        return null === (t = e.attributes) || void 0 === t
          ? void 0
          : t.interscroller;
      });
    }
    function y() {
      return t.getFuseSlots().filter(function (e) {
        var t;
        return null === (t = e.attributes) || void 0 === t ? void 0 : t.dynamic;
      });
    }
    function S() {
      return t.getFuseSlots().filter(function (e) {
        var t;
        return null === (t = e.attributes) || void 0 === t
          ? void 0
          : t.scrollToStick;
      });
    }
    function I(e) {
      return null !== document.querySelector('[data-fuse="'.concat(e.id, '"]'));
    }
    function w(e) {
      return (
        p.find(function (t) {
          return t.slot.id === e.id;
        }) || null
      );
    }
    function _(t) {
      var n = w(t);
      return n
        ? (n.delete(), e[k]("[WIDGETS][".concat(t.id, "] Widget deleted")), !0)
        : (e[k]("[WIDGETS][".concat(t.id, "] Widget was not found")), !1);
    }
    function C() {
      return y().concat(h(), b());
    }
    function T() {
      return y().concat(h());
    }
    function R(a) {
      var v;
      e[k]("[WIDGETS][".concat(a.id, "] Inject widget"));
      var b = a.attributes,
        h = b.sticky,
        y = b.interscroller,
        S = b.dynamic,
        _ = w(a),
        C = !1;
      if (h && t.disableYandexSticky())
        e[k](
          "[WIDGETS][".concat(
            a.id,
            "] Skip injection. Yandex sticky is disabled"
          )
        );
      else if ((h || y) && I(a))
        e[k]("[WIDGETS][".concat(a.id, "] Skip injection. DOM element exists"));
      else {
        if (!_) {
          if (h) {
            var T = (function (e, t) {
              var n, i;
              return (
                (e.isStickyCarouselEnabled() ||
                  Boolean(
                    null === (n = t.stickyAttributes) || void 0 === n
                      ? void 0
                      : n.isCarousel
                  )) &&
                !(null === (i = t.stickyAttributes) || void 0 === i
                  ? void 0
                  : i.isTop)
              );
            })(t, a);
            (_ = new ov({
              slot: a,
              logger: e,
              viewportInfo: c,
              browserWindow: u,
              fuseDivElementFactory: f,
              registerAdRendered: function (e) {
                return l[Et].subscribe(e);
              },
              getRefreshIntervalSeconds: function () {
                return t.getRefreshInterval(a);
              },
              settings: t,
              refreshManager: i,
              slotRegistry: n,
              onShowCloseCallback: function () {
                N();
              },
              slotTargeting: g,
              waitForCreative: !t.isYandexEnabled(),
              carousel: T ? m : Sm,
            })),
              (C = Boolean(
                null === (v = a.stickyAttributes) || void 0 === v
                  ? void 0
                  : v.isTop
              ));
          } else if (y)
            _ = new ev(
              a,
              e,
              c[fn],
              u,
              f,
              function (e) {
                return l[Et].subscribe(e);
              },
              B,
              t,
              g
            );
          else {
            if (!S)
              return void e[E](
                "[WIDGETS][".concat(a.id, "] Skip injection of unknown widget")
              );
            e[k](function () {
              return "[WIDGETS]["
                .concat(a.id, "] Injecting dynamic slot with attributes ")
                .concat(JSON.stringify(a.dynamicAttributes));
            }),
              (_ = new $m(a, e, c[fn], f, t));
          }
          p.push(_);
        }
        var A,
          R = _.insert(),
          x = t.getVideoSettings(),
          P = s(R);
        try {
          for (P.s(); !(A = P.n()).done; ) {
            var O = A.value;
            e[k]("[WIDGETS][".concat(O.id, "] Run queueZone")),
              o[of](O.id, !0, !1, r),
              x.enabled &&
                x.injectedAdUnitId &&
                O.id.includes(x.injectedAdUnitId) &&
                d[Qm](!0);
          }
        } catch (e) {
          P.e(e);
        } finally {
          P.f();
        }
        R.length > 0 && o[cf](), C && N();
      }
    }
    function x() {
      var e,
        t = s(C());
      try {
        var n = function () {
          var t = e.value;
          if (t.injectConditionConfig) {
            var n = a[_s](t.injectConditionConfig, t.id, r, function () {
              R(t);
            });
            n[Is]() ? R(t) : n[ys]();
          } else R(t);
        };
        for (t.s(); !(e = t.n()).done; ) n();
      } catch (e) {
        t.e(e);
      } finally {
        t.f();
      }
    }
    function P() {
      !(function () {
        e[k]("[WIDGETS] cleanup"), M.stop();
        var t,
          n = s(C());
        try {
          for (n.s(); !(t = n.n()).done; ) _(t.value);
        } catch (e) {
          n.e(e);
        } finally {
          n.f();
        }
      })(),
        e[k]("[WIDGETS] reset"),
        x(),
        M.start(T(), !0);
    }
    function O() {
      var n,
        i = 0,
        r = t.getTopStickyHeaderSelector();
      if (r) {
        var o = zs(document, e, r);
        o &&
          ((i += o.clientHeight),
          e[k](
            "[WIDGETS] miniscrollers offset set to ".concat(
              i,
              " because of topStickyHeader"
            )
          ));
      }
      var a,
        u = s(b());
      try {
        for (u.s(); !(a = u.n()).done; ) {
          var l = a.value;
          if (
            null === (n = l.stickyAttributes) || void 0 === n ? void 0 : n.isTop
          ) {
            var d = w(l);
            if (
              (null == d ? void 0 : d.getContainerElement()) &&
              !d.getContainerElement().classList.contains("closed")
            ) {
              var f = t.maxSlotHeightForBreakpoint(l, c[fn]().name);
              (i += null != f ? f : 0),
                e[k](
                  "[WIDGETS] miniscrollers offset set to ".concat(
                    i,
                    " because of top sticky"
                  )
                );
            }
          }
        }
      } catch (e) {
        u.e(e);
      } finally {
        u.f();
      }
      return i;
    }
    function D() {
      if (document.getElementById("publift-fuse-styles"))
        e[k]("[WIDGETS] styles already injected");
      else {
        var n = "",
          i = O();
        if (t.isMiniScrollersEnabled()) {
          e[k]("[WIDGETS] inject fuse styles");
          var r =
            "\n      .fuse-slot-mini-scroller .fuse-slot {\n        top: ".concat(
              0 | i,
              "px;\n        position: sticky !important;\n        overflow: hidden !important;\n      }\n      .fuse-slot-mini-scroller {\n        overflow: initial !important;\n        display: block !important;\n      }\n      "
            );
          e[k]("[WIDGETS] injected miniScroller styles"), (n += r);
        }
        (n += "\n    ."
          .concat(tv, " .fuse-slot {\n      z-index: 9999;\n      top: ")
          .concat(0 | i, "px;\n      position: fixed;\n      width: var(")
          .concat(
            nv,
            ");\n      pointer-events: auto;\n    }\n    .publift-widget-interscroller {\n      top: "
          )
          .concat(0 | i, "px;\n    }")),
          f[tn]("publift-fuse-styles", n);
      }
    }
    function N() {
      var e = document.getElementById("publift-fuse-styles");
      e && e.remove(), D();
    }
    function z(e) {
      var t = e.previousElementSibling;
      return t || z(e.parentElement);
    }
    var B = {
        widgets: p,
        getStickySlots: b,
        getInterscrollerSlots: h,
        getDynamicSlots: y,
        getScrollToStickSlots: S,
        getMiniscrollerSlots: function () {
          return t.getFuseSlots().filter(function (e) {
            var t;
            return null === (t = e.attributes) || void 0 === t
              ? void 0
              : t.miniscroller;
          });
        },
        isSlotInjected: I,
        getWidget: w,
        handleBreakpointChange: function () {
          var t = b(),
            n = h();
          e[A](
            "[WIDGETS] onBreakpointChange Stickies: "
              .concat(t.length, " Scrolls: ")
              .concat(n.length)
          );
          var i,
            r = s(t.concat(n));
          try {
            for (r.s(); !(i = r.n()).done; ) {
              var o = w(i.value);
              o && o.onBreakpointChange();
            }
          } catch (e) {
            r.e(e);
          } finally {
            r.f();
          }
        },
        getWidgetSlots: C,
        getWidgetsWithSelector: T,
        cleanupDynamicSlots: function () {
          var e,
            t = s(y());
          try {
            for (t.s(); !(e = t.n()).done; )
              for (
                var n = e.value,
                  i = document.querySelectorAll(
                    '[data-fuse="'.concat(n.id, '"]')
                  ),
                  r = 0,
                  o = Array.from(i);
                r < o.length;
                r++
              ) {
                o[r].remove();
              }
          } catch (e) {
            t.e(e);
          } finally {
            t.f();
          }
        },
        injectWidget: R,
        init: function () {
          e[k]("[WIDGETS] Init"),
            v
              ? e[k](
                  "[WIDGETS] Skipped initialisation as it is already initialised"
                )
              : ((v = !1),
                x(),
                M.start(T()),
                S().length &&
                  (e[k](
                    "[WIDGETS] scrollToStick slots found ".concat(
                      S().length,
                      ". Attach scroll listener"
                    )
                  ),
                  r.getWindow().addEventListener(
                    "scroll",
                    function () {
                      return (function () {
                        e[k]("[WIDGETS] scrollToStickListener");
                        var n,
                          i = S(),
                          o = t.scrollToStickDisableDepth() || 0,
                          a = O(),
                          c = o > 0 && r.getWindow().scrollY > o,
                          l = s(i);
                        try {
                          var d = function () {
                            for (
                              var t = n.value,
                                r = u.document.querySelectorAll(
                                  '[data-fuse="'.concat(t.id, '"]')
                                ),
                                o = 0,
                                s = Array.from(r);
                              o < s.length;
                              o++
                            ) {
                              var l = s[o];
                              if (c) {
                                e[k](
                                  "[WIDGETS][".concat(
                                    t.id,
                                    "] scrollToStick removed by scrollToStickDisableDepth"
                                  )
                                ),
                                  rv(l),
                                  (i = i.filter(function (e) {
                                    return e.id !== t.id;
                                  }));
                                break;
                              }
                              var d = z(l);
                              d &&
                              d.getBoundingClientRect().y +
                                d.getBoundingClientRect().height -
                                a <
                                0
                                ? (e[k](
                                    "[WIDGETS][".concat(
                                      t.id,
                                      "] scrollToStick set"
                                    )
                                  ),
                                  iv(l, u))
                                : (e[k](
                                    "[WIDGETS][".concat(
                                      t.id,
                                      "] scrollToStick removed"
                                    )
                                  ),
                                  rv(l));
                            }
                          };
                          for (l.s(); !(n = l.n()).done; ) d();
                        } catch (e) {
                          l.e(e);
                        } finally {
                          l.f();
                        }
                      })();
                    },
                    !0
                  )),
                D(),
                (v = !0));
        },
        getMiniScrollersTopOffset: O,
        injectFuseStyles: D,
      },
      M = (function (e, t) {
        var n = null,
          i = [],
          r = {
            getStatuses: function () {
              return i;
            },
            start: function (t) {
              (!(
                arguments.length > 1 &&
                void 0 !== arguments[1] &&
                arguments[1]
              ) &&
                i.length) ||
                (e[k]("[WIDGETS][CHECKER] Start to check slots"),
                (i = t
                  .filter(function (e) {
                    var t, n;
                    return (
                      (null === (t = e.dynamicAttributes) || void 0 === t
                        ? void 0
                        : t.selector) ||
                      (null === (n = e.interscrollerAttributes) || void 0 === n
                        ? void 0
                        : n.selector)
                    );
                  })
                  .map(function (e) {
                    var t,
                      n,
                      i =
                        (null === (t = e.dynamicAttributes) || void 0 === t
                          ? void 0
                          : t.selector) ||
                        (null === (n = e.interscrollerAttributes) ||
                        void 0 === n
                          ? void 0
                          : n.selector);
                    return {
                      slot: e,
                      selector: i || "",
                      countSelector: r.countSelector(i),
                      countSlot: r.countSlot(e.id),
                    };
                  })),
                i.length &&
                  (n = setInterval(function () {
                    return r.check();
                  }, 100)));
            },
            stop: function () {
              n && clearInterval(n), (i = []);
            },
            check: function () {
              i.forEach(function (n) {
                var i = n.slot,
                  o = r.countSelector(n.selector),
                  a = r.countSlot(i.id);
                (n.countSelector === o && n.countSlot === a) ||
                  i.injectConditionConfig ||
                  (e[k](
                    "[WIDGETS]["
                      .concat(i.id, '] Injecting by selector "')
                      .concat(n.selector, '" change: selectors ')
                      .concat(o, " slots ")
                      .concat(a)
                  ),
                  t.injectWidget(n.slot),
                  (n.countSelector = r.countSelector(n.selector)),
                  (n.countSlot = r.countSlot(n.slot.id)));
              });
            },
            countSelector: function (t) {
              if (!t)
                return (
                  e[E](
                    "[WIDGETS]: Selector should be defined for countSelector"
                  ),
                  0
                );
              try {
                return document.querySelectorAll(t).length;
              } catch (n) {
                e[E]("[WIDGETS]: Invalid selector for count ".concat(t));
              }
              return 0;
            },
            countSlot: function (e) {
              return document.querySelectorAll('[data-fuse="'.concat(e, '"]'))
                .length;
            },
          };
        return r;
      })(e, B);
    return (
      l[Ft].subscribe(function () {
        return B.handleBreakpointChange();
      }),
      l[ft].subscribe(function (e) {
        e.isPageTransition && P();
      }),
      l[bt].subscribe(function (n) {
        var i = t.getFuseSlots().find(function (e) {
          return e.id === n.zoneTemplateId;
        });
        i
          ? B.getWidget(i) && _(i)
          : e[k](
              "[WIDGETS] Zone template ".concat(n.zoneTemplateId, " not found")
            );
      }),
      (B.widgets = p),
      B
    );
  }
  var sv = Symbol(),
    cv = Symbol(),
    uv = Symbol(),
    lv = Symbol(),
    dv = Symbol(),
    fv = M()(function (e) {
      return e
        .register(dv, [L, j, cg, lg, ia], _m)
        .register(uv, [L, $i, j, yn, Kt], Km)
        .register(lv, [L, $i, jg, Kt], Wm)
        .register(cv, [L, $i, $s, Kg, Xg, mu, Kt], Hm)
        .register(
          sv,
          [L, $i, jg, Zg, Kg, Yg, $s, hn, j, Kt, uv, bn, bu, dv],
          av
        )
        .export();
    });
  var gv = {
    name: "Blockthrough",
    url: "//btloader.com/",
    file: "tag?o=5708166709903360&upapi=true",
  };
  var mv = "e81e688b-e119-4bf8-af5e-9c6af50622c1",
    vv = "39173a60-ed1c-4b18-bff0-7e139e6b7d26",
    pv = function (e, t, n, i, r, o) {
      var a,
        s,
        c,
        u = void 0 === r ? { isPrebidOnly: !1, isPubxEnabled: !1 } : r;
      n[bi]("pubxai_load_start");
      var l = Er(n[ri]());
      i[Ar]("pubxai", l);
      var d = function () {
        e[C](function () {
          return "[PUBXAI]: Script loaded with config: ".concat(
            JSON.stringify(u)
          );
        }),
          n[bi]("pubxai_load_finish"),
          i[Ar]("pubxai", kr(l, n[ri](), {}));
      };
      if (u.isPubxEnabled) {
        var f = null === (a = u.pubxFloorFetch) || void 0 === a || a,
          g = null !== (s = u.pubxOnPercentage) && void 0 !== s ? s : 95,
          m = null !== (c = u.pubxAuctionDelay) && void 0 !== c ? c : 100,
          v = mv,
          p = "fusePbjs",
          b = t,
          h = (b[p] = b[p] || {});
        (h.que = h.que || []),
          (b.__pubx__ = b.__pubx__ || {}),
          (b.__pubx__.pubxFFAlwaysEnabled = f);
        var y = null;
        b.__pubxLoaded__ = Math.random() < g / 100;
        var S = "https://floor.pbxai.com/?pubxId="
            .concat(v)
            .concat(b.__pubxLoaded__ ? "" : "&pbx_e=1", "&page=")
            .concat(b.location.href),
          w = {
            a: [0, 1],
            b: [2, 6],
            c: [7, 11],
            d: [12, 16],
            e: [17, Number.MAX_SAFE_INTEGER],
          },
          _ = function (e, t) {
            for (
              var n = e.bidRequestsCount || 0, i = Object.keys(w), r = 0, o = i;
              r < o.length;
              r++
            ) {
              var a = o[r],
                s = w[a];
              if (n >= s[0] && n <= s[1]) return a;
            }
            return i[i.length - 1];
          },
          E = function (e, t) {
            return e.bidder;
          };
        if (h.que.push === Array.prototype.push && (b.__pubxLoaded__ || f)) {
          var k = t.document.createElement("link");
          (k.rel = "preload"),
            (k.href = S),
            (k.as = "fetch"),
            (k.crossOrigin = ""),
            t.document.head.appendChild(k);
        }
        if (b.__pubxLoaded__)
          try {
            var T = t.localStorage.getItem("pubx:defaults"),
              A = T ? JSON.parse(T) : null,
              R = A ? A.data : y;
            (b.__pubx__.pubxDefaultsAvailable = !0),
              !R || (R && "object" === I(R) && R.expiry < Date.now())
                ? (b.__pubx__.pubxDefaultsAvailable = !1)
                : (y = R);
          } catch (e) {
            b.__pubx__.pubxDefaultsAvailable = !1;
          }
        (f || b.__pubxLoaded__) &&
          h.que.push(function () {
            h.setConfig({
              floors: {
                enforcement: { floorDeals: !0 },
                auctionDelay: m,
                endpoint: { url: S },
                additionalSchemaFields: { rank: _, bidder: E },
                data: y,
              },
            });
          });
        var x = t.document.createElement("script"),
          P = "https://cdn.pbxai.com/"
            .concat(v, ".js?pbxd=")
            .concat(encodeURIComponent(b.location.origin));
        (x.src = P),
          (x.async = !0),
          (x.onload = d),
          t.document.head.appendChild(x);
      } else {
        if (u.isPrebidOnly) {
          var O = t;
          O.fusePbjs = O.fusePbjs || {};
          var D = O.fusePbjs;
          D.que = D.que || [];
          var N = "https://floor.pbxai.com/?pubxId="
            .concat(vv, "&page=")
            .concat(t.location.href);
          if (!D.version) {
            var z = t.document.createElement("link");
            (z.rel = "preload"),
              (z.href = N),
              (z.as = "fetch"),
              (z.crossOrigin = ""),
              t.document.head.appendChild(z);
          }
          var B = null;
          try {
            var M = t.localStorage.getItem("pubx:defaults");
            B = M ? JSON.parse(M).data : null;
          } catch (t) {
            e[C](function () {
              return "[PUBXAI]: Pubx: Error parsing defaults ".concat(
                JSON.stringify(t)
              );
            }),
              (B = null);
          }
          D.que.push(function () {
            D.setConfig({
              floors: {
                enforcement: { floorDeals: !0 },
                auctionDelay: 100,
                endpoint: { url: N },
                data: B,
              },
            });
          });
        }
        ba(
          { logger: e, window: t },
          (function (e, t) {
            return {
              name: "Pubxai",
              url: "//cdn.pbxai.com/",
              file: ""
                .concat(t, ".js?pbxd=")
                .concat(encodeURIComponent(e.location.origin)),
            };
          })(t, u.isPrebidOnly ? vv : mv),
          d
        );
      }
    };
  var bv = [
    "tpc.googlesyndication.com",
    "googleads.g.doubleclick.net",
    "static.doubleclick.net",
  ];
  function hv(e, t) {
    var n = e.createElement("link");
    (n.rel = "preconnect"),
      (n.href = "https://".concat(t)),
      (n.crossOrigin = ""),
      e.head.appendChild(n);
  }
  var yv = /^[a-z0-9.-]+$/i;
  function Sv(e, t) {
    var n = e.createElement("link");
    (n.rel = "preload"), (n.as = "script"), (n.href = t), e.head.appendChild(n);
  }
  function Iv(e, t) {
    try {
      return e.startsWith("//")
        ? new URL("https:".concat(e)).href || null
        : /^[a-z][a-z0-9+.-]*:/i.test(e)
        ? new URL(e).href || null
        : (t.baseURI &&
            /^https?:/i.test(t.baseURI) &&
            new URL(e, t.baseURI).href) ||
          null;
    } catch (e) {
      return null;
    }
  }
  function wv(e) {
    return {
      name: "iiq",
      subscribe: function (t) {
        return e[Jt].immediateOrOnce(function () {
          return t();
        });
      },
    };
  }
  var _v,
    Ev,
    kv = new Set(["ready", "cancelled", "disabled"]);
  function Cv(e, t) {
    return {
      name: "ay",
      subscribe: function (n) {
        if (kv.has(e[Tr].assertiveYield._tag)) n();
        else {
          var i = function (e) {
            "assertiveYield" === e.component &&
              kv.has(e.state._tag) &&
              (t[St].unsubscribe(i), n());
          };
          t[St].subscribe(i);
        }
      },
    };
  }
  function Tv(e, t, n) {
    return [].concat(
      y(e.shouldWaitForIiqCallback() ? [wv(n)] : []),
      y(e.shouldWaitForAyCallback() ? [Cv(t, n)] : [])
    );
  }
  if (
    null === (_v = window.self.fusetag) || void 0 === _v ? void 0 : _v.loading
  ) {
    var Av =
      "[FUSE]: Fusetag is already initialising, and may have been included in the page twice";
    throw (console.error(Av), new Error(Av));
  }
  if (null === (Ev = window.self.fusetag) || void 0 === Ev ? void 0 : Ev.init) {
    var Rv =
      "[FUSE]: Fusetag is already initialised, and may have been included in the page twice";
    throw (console.error(Rv), new Error(Rv));
  }
  var xv = window.self.fusetag || (window.self.fusetag = { que: [] });
  xv.loading = !0;
  var Pv,
    Ov,
    Dv,
    Nv = ((Pv = new Map()),
    (Ov = new Map()),
    (Dv = {
      registerModule: function (e) {
        return e(Ov, !1), Dv;
      },
      resolve: function e(t) {
        if (Pv.has(t)) return Pv.get(t);
        var n = Ov.get(t);
        if (!n) throw new Error("No registered token ".concat(String(t)));
        var i = n.deps,
          r = n.factory,
          o = i.map(function (t) {
            return e(t);
          }),
          a = r.apply(void 0, y(o));
        return Pv.set(t, a), a;
      },
      allTokens: function () {
        return Array.from(Pv.keys());
      },
    }),
    Dv)
      .registerModule(ee)
      .registerModule(st)
      .registerModule(Xt)
      .registerModule(Sn)
      .registerModule(sr)
      .registerModule(da)
      .registerModule(rc)
      .registerModule(rs)
      .registerModule(hu)
      .registerModule(fg)
      .registerModule(mg)
      .registerModule(Ug)
      .registerModule(Tu)
      .registerModule(cm)
      .registerModule(bm)
      .registerModule(fv),
    zv = Nv.resolve(Kt),
    Bv = Nv.resolve(na),
    Mv = Nv.resolve(L),
    Uv = Nv.resolve($i),
    jv = Nv.resolve(ia),
    Lv = Nv.resolve(j),
    Fv = Nv.resolve(ra),
    Gv = Nv.resolve(ku),
    Vv = Nv.resolve(Yg),
    Hv = Nv.resolve(Kg),
    qv = Nv.resolve(sv),
    Wv = Nv.resolve(cv),
    Yv = Nv.resolve(hn),
    Zv = Nv.resolve(mu),
    Jv = Nv.resolve(De),
    Qv = Nv.resolve(Qg),
    Kv = Nv.resolve(pm),
    Xv = Nv.resolve(nm),
    $v = Nv.resolve(Y);
  Nv.resolve(Wg);
  var ep = (function (
    e,
    t,
    n,
    i,
    r,
    o,
    a,
    s,
    c,
    u,
    l,
    d,
    f,
    g,
    m,
    v,
    p,
    b,
    h,
    y,
    S,
    w
  ) {
    var _ = ct(e, "onTagInitialised");
    return {
      enableApi: function (C) {
        e[k]("[INIT]: Enabling Fuse API"),
          (C.fuseUUID = r.getFuseUUID()),
          (C.initialised = !1),
          (C.init = !1),
          (C.getCurrentBreakpoint = p[fn]),
          (C.setBreakpointWidthSelector = (function (e, t) {
            return function (n) {
              var i;
              if ("string" == typeof n && 0 !== n.length) {
                var r = JSON.stringify(n);
                e[k]("[API]: setBreakpointWidthSelector(".concat(r, ")")),
                  t[vn](n);
              } else
                e[T](
                  "[API]: setBreakpointWidthSelector with invalid selector: " +
                    ""
                      .concat(
                        null !== (i = on(n)) && void 0 !== i
                          ? i
                          : "[unstringifiable]",
                        " - "
                      )
                      .concat(I(n))
                );
            };
          })(e, p)),
          (C.pageInit = function (t) {
            return (
              e[k](function () {
                return "[API]: pageInit(".concat(JSON.stringify(t), ")");
              }),
              o[Df](a.location.href, c[ri](), t)
            );
          }),
          (C.registerAll = function () {
            return e[k]("[API]: registerAll()"), t[rf](!0, !1, v);
          }),
          (C.registerZone = function (n) {
            if (n && "string" == typeof n) {
              e[k]("[API]: registerZone('".concat(n, "')"));
              var i = t[of](n, !0, !1, v),
                r =
                  null == i
                    ? void 0
                    : i.map(function (e) {
                        return e.slotDivId;
                      });
              return (
                (null == r ? void 0 : r.length) > 0 && t[cf](),
                null == r ? void 0 : r[0]
              );
            }
            e[T](
              "[API]: registerZone with invalid zoneDivId: "
                .concat(JSON.stringify(n), " - ")
                .concat(I(n))
            );
          }),
          (C.destroyZone = function (n) {
            n && "string" == typeof n
              ? (e[k]("[API]: destroyZone('".concat(n, "')")), t[ff](n))
              : e[T](
                  "[API]: destroyZone with invalid zoneDivId: "
                    .concat(JSON.stringify(n), " - ")
                    .concat(I(n))
                );
          }),
          (C.activateZone = function (n) {
            n && "string" == typeof n
              ? (e[k]("[API]: activateZone('".concat(n, "')")), t[af](n))
              : e[T](
                  "[API]: activateZone with invalid zoneDivId: "
                    .concat(JSON.stringify(n), " - ")
                    .concat(I(n))
                );
          }),
          (C.states = c[Hn]),
          (C.events = c[qn]),
          (C.setTargeting = function (t, n) {
            if ("string" == typeof t) {
              if ("string" == typeof n || Array.isArray(n))
                return (
                  e[k](function () {
                    return "[API]: setTargeting("
                      .concat(t, ", ")
                      .concat(JSON.stringify(n), ")");
                  }),
                  s[cu](t, n)
                );
              e[T](
                "[API]: setTargeting with invalid value: "
                  .concat(JSON.stringify(n), " - ")
                  .concat(I(n))
              );
            } else
              e[T](
                "[API]: setTargeting with invalid key: "
                  .concat(JSON.stringify(t), " - ")
                  .concat(I(t))
              );
          }),
          (C.onSlotRenderEnded = function (e) {
            return l[Et].subscribe(function (t) {
              var n = {
                slotId: t.slot.getSlotElementId(),
                hasCreative: !t.isEmpty,
                gptEvent: t,
              };
              e(n);
            });
          }),
          (C.onTagInitialised = function (e) {
            _.once(e);
          }),
          (C.onSlotsInitialised = function (e) {
            n[Ol]().once(e);
          }),
          (C.onSlotInitialised = function (e) {
            n[zl]().once(e);
          }),
          (C.onSlotViewable = function (e) {
            l[Tt].subscribe(function (t) {
              var n = { slotId: t.slot.getSlotElementId(), gptEvent: t };
              e(n);
            });
          }),
          (C.setAllowRefreshCallback = function (e) {
            n[Nl](e);
          }),
          (C.resetAfs = function (t) {
            e[k](function () {
              return "[API]: resetAfs with params ".concat(JSON.stringify(t));
            }),
              h[dm](t);
          }),
          (C.setAfsExtractPageParams = function (t) {
            e[k]("[API]: setAfsExtractPageParams()"), h[fm](t);
          }),
          (C.destroySticky = function () {
            e[k]("[API]: destroySticky()"), n.destroySticky();
          }),
          (C.privateApi = {
            getWidgetRenderer: function () {
              return f;
            },
            getInitStatus: function () {
              return d.getInitStatus();
            },
            getSlotProblems: function () {
              return c[ti]();
            },
            resetPage: function () {
              return e[k]("[API]: resetPage()"), o[Of]();
            },
            runAuctionAllActiveSlots: function () {
              return e[k]("[API]: runAuctionAllActiveSlots()"), t[lf]();
            },
            setLogLevel: function (t) {
              return e[D](t);
            },
            getLogLevel: function () {
              return e[N]();
            },
            getLogs: function () {
              return e[z]();
            },
            getAuctionState: function () {
              return g[Id]();
            },
            getSlotTestUrls: function () {
              return r.getSlotTestUrls();
            },
            getRegisteredSlots: n[Bl],
            isYandexEnabled: function () {
              return r.isYandexEnabled();
            },
            isPrebidEnabled: function () {
              return r.isPrebidEnabled();
            },
            isCmpEnabled: function () {
              return r.isCmpRequired();
            },
            isUamEnabled: function () {
              return r.isUamEnabled();
            },
            isBlockthroughEnabled: function () {
              return r.isBlockthroughEnabled();
            },
            disableRefreshBySlotId: function (e) {
              return m[Zd](e);
            },
            enableRefreshBySlotId: function (e) {
              return m[Jd](e);
            },
            enableRefresh: function () {
              return e[k]("[API]: enableAllRefresh()"), t[mf]();
            },
            getAllRefresh: function () {
              return m[$d]();
            },
          }),
          (C.loadSlots = function () {
            e[k]("[API]: loadSlots()"),
              t[bf](C.initialised, v, function () {
                return o[Of]();
              });
          }),
          (C.getUnits = function () {
            return n[Dl]();
          }),
          (C.loadSlotById = function (i, r) {
            return (function (i, r) {
              var o;
              e[k]("[API]: loadSlotById(".concat(i, ", ").concat(r, ")")),
                (r ? t[of](r, !0, !0, v) : t[sf]("".concat(i), !0, !0, v)) ||
                  e[k](
                    "[API]: loadSlotById("
                      .concat(i, ", ")
                      .concat(r, ") did not register a slot")
                  ),
                r &&
                  !1 ===
                    (null === (o = n[Rl](r)) || void 0 === o
                      ? void 0
                      : o.currentlyActive) &&
                  (e[k](
                    "[API]: loadSlotById("
                      .concat(i, ", ")
                      .concat(r, ") activate zone")
                  ),
                  t[af](r)),
                t[cf]();
            })(i, r);
          }),
          (C.refreshSlots = function () {
            return e[k]("[API]: refreshSlots()"), t[lf]();
          }),
          (C.refreshSlotByCode = function (n) {
            if (n && "string" == typeof n)
              return e[k]("[API]: refreshSlotByCode(".concat(n, ")")), t[uf](n);
            e[T](
              "[API]: refreshSlotByCode with invalid creativeDivId: "
                .concat(JSON.stringify(n), " - ")
                .concat(I(n))
            );
          }),
          (C.displayZone = function (t) {
            if (
              (e[k]("[API]: displayZone() for ".concat(t)),
              t && "string" == typeof t)
            ) {
              var i = n[Rl](t);
              if (null == i ? void 0 : i.manualDisplay) {
                var r = _d(g[Id]().getAuctions(), i);
                r
                  ? g[vd](r, i)
                  : e[T](
                      "[API]: displayZone() no auction for zone ".concat(
                        i.slotDivId,
                        ", cancelling manual displayZone()"
                      )
                    );
              } else e[T]("[API]: displayZone() with invalid slot");
            } else
              e[T](
                "[API]: displayZone() with invalid zoneDivId: "
                  .concat(JSON.stringify(t), " - ")
                  .concat(I(t))
              );
          }),
          (C.getAdSlotsById = function (t) {
            return (function (t) {
              if (t && ("string" == typeof t || "number" == typeof t))
                return i[nu]("".concat(t));
              e[E](function () {
                var e;
                return "[API]: getAdSlotsById with invalid fuseId: "
                  .concat(
                    null !== (e = on(t)) && void 0 !== e
                      ? e
                      : "[unstringifiable]",
                    " - "
                  )
                  .concat(I(t));
              });
            })(t);
          }),
          (C.processNewSlots = function () {
            return e[k]("[API]: processNewSlots()"), t[rf](!0, !1, v);
          }),
          (C.getTargeting = function () {
            return s[lu]();
          }),
          (C.getAdSlotsByFuseId = C.getAdSlotsById),
          (C.getFuseUnits = C.getUnits),
          (C.loadFuseSlots = C.loadSlots),
          (C.resetSlots = function () {
            return e[k]("[API]: resetSlots()"), o[Of]();
          }),
          (C.resetFuseSlots = function () {
            return e[k]("[API]: resetFuseSlots()"), o[Of]();
          }),
          (C.loadFuseSlotById = C.loadSlotById),
          (C.setSlotTargetingById = function (t, n, r) {
            return (function (t, n, r) {
              !t || ("string" != typeof t && "number" != typeof t)
                ? e[T](
                    "[API]: setSlotTargetingById with invalid fuseId: "
                      .concat(JSON.stringify(t), " - ")
                      .concat(I(t))
                  )
                : "string" == typeof n
                ? "string" == typeof r || Array.isArray(r)
                  ? (e[k](
                      "[API]: setSlotTargetingById("
                        .concat(t, ", ")
                        .concat(n, ", ")
                        .concat(r, ") started")
                    ),
                    i[ou]("".concat(t), n, r))
                  : e[T](
                      "[API]: setSlotTargetingById with invalid value: "
                        .concat(JSON.stringify(r), " - ")
                        .concat(I(r))
                    )
                : e[T](
                    "[API]: setSlotTargetingById with invalid key: "
                      .concat(JSON.stringify(n), " - ")
                      .concat(I(n))
                  );
            })(t, n, r);
          }),
          (C.widgetsRenderer = C.privateApi.getWidgetRenderer()),
          (C.setDefaultTargeting = function () {
            return (
              e[k]("[API]: setDefaultTargeting()"),
              w[Wo]("setDefaultTargeting"),
              u[jc]()
            );
          }),
          (C.disableRefresh = function () {
            return e[k]("[API]: disableRefresh()"), t[gf]();
          }),
          (C.getSlots = function () {
            return n[Al]();
          }),
          (C.getSettings = function () {
            return Object.assign({}, r.getAccountSettings());
          }),
          r.getReportPageInfo() &&
            (C.reportPageInfo = function (t, n) {
              e[k]("[API]: reportPageInfo()", t, n), b[Gf](t, n);
            }),
          (C.setForceSafeFrames = function (t) {
            e[k]("[API]: setForceSafeFrame(".concat(t, ")")),
              r.setForceSafeFrames(t),
              u[Lc]();
          }),
          (C.isForceSafeFrames = function () {
            return r.isForceSafeFrames();
          }),
          (C.getFuseGeo = function () {
            return r.getFuseGeo();
          }),
          (C.setOptableEID = function (t) {
            var n =
              arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            e[k](
              "[API]: setOptableEID(".concat(t, ", isHashed=").concat(n, ")")
            ),
              y[xg](t, n);
          }),
          (C.registerH5Interstitial = function (t) {
            e[k]("[API]: registerH5Interstitial(".concat(t, ")")), S[Rm](t);
          }),
          (C.onH5InterstitialReady = function (t) {
            e[k]("[API]: onH5InterstitialReady()"), S[Pm](t);
          }),
          (C.displayH5Interstitial = function () {
            e[k]("[API]: displayH5Interstitial"), S[xm]();
          }),
          (C.onH5InterstitialClosed = function (t) {
            e[k]("[API]: onH5InterstitialClosed()"), S[Om](t);
          }),
          (C.onH5InterstitialEmpty = function (t) {
            e[k]("[API]: onH5InterstitialEmpty()"), S[Dm](t);
          }),
          (C.onH5InterstitialUnsupported = function (t) {
            e[k]("[API]: onH5InterstitialUnsupported()"), S[Nm](t);
          }),
          (C.registerRewarded = function (t) {
            e[k]("[API]: registerRewarded(".concat(t, ")")), S[zm](t);
          }),
          (C.onRewardedReady = function (t) {
            e[k]("[API]: onRewardedReady()"), S[Mm](t);
          }),
          (C.onRewardedGranted = function (t) {
            e[k]("[API]: onRewardedGranted()"), S[Um](t);
          }),
          (C.onRewardedClosed = function (t) {
            e[k]("[API]: onRewardedClosed()"), S[jm](t);
          }),
          (C.onRewardedVideoCompleted = function (t) {
            e[k]("[API]: onRewardedVideoCompleted()"), S[Lm](t);
          }),
          (C.onRewardedEmpty = function (t) {
            e[k]("[API]: onRewardedEmpty()"), S[Fm](t);
          }),
          (C.onRewardedUnsupported = function (t) {
            e[k]("[API]: onRewardedUnsupported()"), S[Gm](t);
          }),
          (C.displayRewarded = function () {
            e[k]("[API]: displayRewarded()"), S[Bm]();
          });
      },
      tagInitEmitter: _,
    };
  })(
    Mv,
    Vv,
    Nv.resolve(jg),
    Nv.resolve(fu),
    Uv,
    Qv,
    Lv,
    Nv.resolve(vu),
    Bv,
    Zv,
    zv,
    Gv,
    qv,
    Nv.resolve(qg),
    Nv.resolve(Zg),
    Hv,
    Yv,
    Nv.resolve($g),
    Kv,
    Nv.resolve(Mg),
    Nv.resolve(cv),
    jv
  );
  function tp(e, t, n) {
    e
      ? (Mv[k](
          "[INIT]: Running second (".concat(
            t,
            ") docReady auto-scan and auction"
          )
        ),
        Bv[bi]("second_autoscan_".concat(t, "_start")),
        ap(),
        Bv[bi]("second_autoscan_".concat(t, "_finish")),
        Mv[k]("[INIT]: Finished second docReady DOM scan"))
      : Fv[Ar]("docReadyScan", kr(n, Bv[ri](), void 0));
  }
  function np() {
    var e = Lv.document.readyState,
      t = Er(Bv[ri]());
    if ((Fv[Ar]("docReadyScan", t), "complete" === e))
      Mv[A]("[INIT]: Document state is already 'complete'"), tp(!1, e, t);
    else {
      var n = !1;
      "interactive" === e &&
        (Mv[A]("[INIT]: Document state is already 'interactive'"),
        (n = !0),
        tp(!1, e, t));
      !(function (e, t) {
        var n = t.useCookieBotEventListener,
          i = t.browserWindow,
          r = t.logger,
          o = i.document;
        if (n && "function" == typeof i.publift_addEventListener)
          try {
            i.publift_addEventListener.call(o, "readystatechange", e);
          } catch (t) {
            r[T](
              "[INIT]: useCookieBotEventListener: preserved addEventListener threw, falling back to default",
              t
            ),
              o.addEventListener("readystatechange", e);
          }
        else
          n &&
            r[E](
              "[INIT]: useCookieBotEventListener: window.publift_addEventListener not found, falling back to default"
            ),
            o.addEventListener("readystatechange", e);
      })(
        function () {
          var e = Lv.document.readyState;
          Bv[bi]("document_readystatechange_".concat(e)),
            Mv[A](
              "[INIT]: Received document '".concat(e, "' listener callback")
            );
          var i = n;
          (n = !0), tp(i, e, t);
        },
        {
          useCookieBotEventListener: Uv.getUseCookieBotEventListener(),
          browserWindow: Lv,
          logger: Mv,
        }
      );
    }
  }
  function ip(e) {
    return [
      "uam",
      "prebid",
      "gamera",
      "interstitial",
      "intentIQ",
      "afs",
    ].includes(e);
  }
  function rp(e, t, n) {
    var i = ip(t),
      r = function (e) {
        i && Fv[Ar](t, e);
      },
      o = Uv.isStrictCmp();
    if (Uv.isCmpDeterminationEnabled()) {
      var a = function () {
        if (!o)
          return (
            Mv[A](
              "[INIT]: CMP is not in strict mode, continuing initialisation of ".concat(
                t,
                " now"
              )
            ),
            void e(!0)
          );
        var n,
          i =
            "ready" === (n = Fv[Tr].cmp)._tag && n.output.allowPersonalisation;
        Mv[A](
          "[INIT]: CMP ready for "
            .concat(t, " - cmp personalisation = ")
            .concat(i)
        ),
          i
            ? (Mv[A](
                "[INIT]: Personalisation allowed, continuing initialisation of ".concat(
                  t,
                  " now"
                )
              ),
              e(!0))
            : (r({ _tag: "cancelled" }),
              Mv[A](
                "[INIT]: Cancelled ".concat(
                  t,
                  " load because there is no consent in strict CMP mode"
                )
              ));
      };
      if (
        (Mv[A]("[INIT]: CMP is required, checking CMP before load ".concat(t)),
        "ready" !== Fv[Tr].cmp._tag)
      ) {
        if (
          (Mv[A](
            "[INIT]: CMP is required, deferring ".concat(
              t,
              " load until we have consent"
            )
          ),
          r({ _tag: "deferred" }),
          Uv.useCmpReadyEvent())
        )
          return (
            Mv[A](
              "[INIT]: CMP ready event is enabled, waiting for cmp before init ".concat(
                t
              )
            ),
            void e(!0)
          );
        zv[St].subscribe(function (e) {
          var n;
          "cmp" === e.component &&
            "ready" === e.state._tag &&
            ((ip(t) &&
              "deferred" !==
                (null === (n = Fv[Tr][t]) || void 0 === n ? void 0 : n._tag)) ||
              a());
        });
      } else a();
    } else e(!1);
  }
  function op() {
    var e = Er(Bv[ri]());
    Fv[Ar]("gpt", e);
    var t = Jv[de]();
    Oc(Nv.resolve(gu), Mv, Bv, Lv, t, function (t) {
      Fv[Ar]("gpt", kr(e, Bv[ri](), void 0)),
        Zv[Mc](t),
        (function () {
          if (!Nv.resolve(cv)[Cm]())
            return (
              Fv[Ar]("interstitial", { _tag: "disabled" }),
              void Mv[A](
                "[INIT]: Not loading Interstitial because it is disabled"
              )
            );
          rp(function (e) {
            var t = Er(Bv[ri](), e);
            Fv[Ar]("interstitial", t),
              Nv.resolve(cv)[Em](function (e) {
                e
                  ? (Mv[A](
                      "[INIT]: Cancelled Interstitial load because there is no consent in strict CMP mode"
                    ),
                    Fv[Ar]("interstitial", { _tag: "cancelled" }))
                  : Fv[Ar]("interstitial", kr(t, Bv[ri](), void 0));
              });
          }, "interstitial");
        })();
    });
  }
  Mv[C](function () {
    return "[INIT] Initialising with UUID ".concat(Uv.getFuseUUID());
  }),
    jv[$o](),
    jv[Xo](),
    (function (e, t) {
      if (t.isPreconnectHintsEnabled()) {
        var n,
          i,
          r,
          o = (function (e) {
            var t = e.head.querySelectorAll('link[rel~="preconnect"]');
            return Array.from(t).reduce(function (t, n) {
              var i = n.getAttribute("href");
              if (!i) return t;
              var r = (function (e, t) {
                try {
                  return e.startsWith("//")
                    ? new URL("https:".concat(e)).hostname || null
                    : /^[a-z][a-z0-9+.-]*:/i.test(e)
                    ? new URL(e).hostname || null
                    : (t.baseURI &&
                        /^https?:/i.test(t.baseURI) &&
                        new URL(e, t.baseURI).hostname) ||
                      null;
                } catch (e) {
                  return null;
                }
              })(i, e);
              return r && t.add(r.toLowerCase()), t;
            }, new Set());
          })(e),
          a = t.getPreconnectDomains(),
          c = t.isYandexEnabled() ? [] : bv,
          u = s(
            ((i = [].concat(y(a), y(c))),
            (r = new Set(o)),
            i.filter(function (e) {
              if (!((t = e).length <= 253 && yv.test(t))) return !1;
              var t,
                n = e.toLowerCase();
              return !r.has(n) && (r.add(n), !0);
            }))
          );
        try {
          for (u.s(); !(n = u.n()).done; ) {
            hv(e, n.value);
          }
        } catch (e) {
          u.e(e);
        } finally {
          u.f();
        }
      }
    })(Lv.document, Uv),
    (function (e, t, n) {
      if (t.isPreloadHintsEnabled()) {
        var i,
          r = (function (e) {
            var t = e.head.querySelectorAll('link[rel~="preload"]');
            return Array.from(t).reduce(function (t, n) {
              var i = n.getAttribute("href");
              if (!i) return t;
              var r = Iv(i, e);
              return r && t.add(r), t;
            }, new Set());
          })(e),
          o = s(
            (function (e, t) {
              var n = e.isStrictCmpScriptGated(),
                i = e.getEnableIntentIQ() && !n && uc(e.getIntentIQVersion());
              return [].concat(
                y(
                  e.isYandexEnabled()
                    ? []
                    : [
                        {
                          name: "Google Publisher Tag",
                          url: "//securepubads.g.doubleclick.net/tag/js/",
                          file: "gpt.js",
                        },
                      ]
                ),
                y(e.isPrebidEnabled() && !n ? [sc(e, t)] : []),
                y(
                  e.isUamEnabled() && !n
                    ? [
                        {
                          name: "UAM",
                          url: "//c.amazon-adsystem.com/",
                          file: "aax2/apstag.js",
                        },
                      ]
                    : []
                ),
                y(i ? [dc(e.getIntentIQVersion(), Eg(e.getFuseGeo()))] : []),
                y(
                  e.enableOptable()
                    ? [
                        {
                          name: "Optable",
                          url: "//solutions.cdn.optable.co/",
                          file: "publift/sdk.js",
                        },
                      ]
                    : []
                )
              );
            })(t, n)
          );
        try {
          for (o.s(); !(i = o.n()).done; ) {
            var a = pa(i.value),
              c = Iv(a, e);
            (c && r.has(c)) || (c && r.add(c), Sv(e, a));
          }
        } catch (e) {
          o.e(e);
        } finally {
          o.f();
        }
      }
    })(Lv.document, Uv, $v);
  var ap = function () {
    Vv[rf](!0, !1, Hv);
  };
  function sp() {
    Bv[bi]("fuse_bootstrap_start");
    var e = Lv.scrollY;
    ep.enableApi(xv);
    var t = Uv.getTagStartCutoffMs(),
      n = Bv[ri]();
    if (!(re(t) || n < t))
      return (
        Mv[E](
          "[INIT]: Fuse will not show ads because it took ".concat(
            n,
            "ms before it began loading"
          )
        ),
        void Bv[bi]("fuse_bootstrap_finish")
      );
    if (
      (Uv.isCmpRequired()
        ? ("none" !== Uv.getCmpProvider().partner &&
            ac(Jv[le](), "simulate quantcast load delay", Mv, function () {
              Nv.resolve($a)[ha](Uv.getCmpProvider());
            }),
          Nv.resolve(ts)[xa]())
        : Fv[Ar]("cmp", { _tag: "disabled" }),
      Uv.isIframeCmp() && Nv.resolve(ns)[Qa](),
      (function () {
        if (!Uv.isUseGameraEnabled())
          return (
            Fv[Ar]("gamera", { _tag: "disabled" }),
            void Mv[A]("[INIT]: Not loading Gamera because it is disabled")
          );
        rp(function (e) {
          var t = Er(Bv[ri](), e);
          Fv[Ar]("gamera", t),
            Nv.resolve(Ng)[yg](function (e) {
              e
                ? (Mv[A](
                    "[INIT]: Cancelled Gamera load because there is no consent in strict CMP mode"
                  ),
                  Fv[Ar]("gamera", { _tag: "cancelled" }))
                : Fv[Ar]("gamera", kr(t, Bv[ri](), void 0));
            });
        }, "gamera");
      })(),
      Uv.isAdmiralEnabled())
    ) {
      var i = Nv.resolve(Fe);
      Nv.resolve(zg)[vg](i);
    }
    (Uv.isPubxaiEnabled() ||
    Uv.isPubxaiPrebidOnlyEnabled() ||
    Uv.isPubxEnabled()
      ? pv(Mv, Lv, Bv, Fv, {
          isPrebidOnly: Uv.isPubxaiPrebidOnlyEnabled(),
          isPubxEnabled: Uv.isPubxEnabled(),
          pubxOnPercentage: Uv.getPubxOnPercentage(),
          pubxFloorFetch: Uv.getPubxFloorFetch(),
          pubxAuctionDelay: Uv.getPubxAuctionDelay(),
        })
      : Fv[Ar]("pubxai", { _tag: "disabled" }),
    oc(Uv.isIn2wInjection(), function () {
      return (function (e, t, n, i) {
        var r =
            arguments.length > 4 && void 0 !== arguments[4]
              ? arguments[4]
              : 5068036699,
          o =
            arguments.length > 5 && void 0 !== arguments[5]
              ? arguments[5]
              : 0.9,
          a =
            arguments.length > 6 && void 0 !== arguments[6]
              ? arguments[6]
              : "America/Los_Angeles";
        if (ae(e)) {
          n[k](
            "[INIT]: loadIn2WGptHook: advertiserId: "
              .concat(r, ", optRatio: ")
              .concat(o, ", timeZone: ")
              .concat(a)
          );
          try {
            hc(t, n),
              e(
                t,
                [r],
                "intowow_optimized",
                ["false"],
                ["true"],
                [
                  [900, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10],
                  [900, 20, 20, 20, 20, 20],
                ],
                a
              ),
              i[Bc](function (e) {
                var t = Math.random() < o ? "true" : "false";
                e[zc]("intowow_optimized", t);
              });
          } catch (e) {
            n[T](
              "[ERROR]: in2w threw an error during initialisation: ".concat(e)
            );
          }
        } else n[T]("[ERROR]: loadIn2WGptHook - in2wHook is not defined");
      })(
        Nv.resolve(Le),
        Lv,
        Mv,
        Zv,
        Uv.getIn2wAdvertiserId(),
        Uv.getIn2wRatio(),
        Uv.getIn2wAdvertiserTimeZone()
      );
    }),
    oc(Uv.isIn2wSafeframe(), function () {
      Nv.resolve(Og)[xu]();
    }),
    (function () {
      if (!Uv.isPrebidEnabled())
        return (
          Fv[Ar]("prebid", { _tag: "disabled" }),
          void Mv[A]("[INIT]: Not loading Prebid because it is disabled")
        );
      var e = Uv.getPrebidTagStartCutoffMs(),
        t = Bv[ri]();
      re(e) || t < e
        ? rp(function (e) {
            var t = Er(Bv[ri](), e);
            Fv[Ar]("prebid", t);
            var n = Nv.resolve(lg),
              i = Nv.resolve(H),
              r = Nv.resolve(jg);
            n[ol]({
              settings: Uv,
              logger: Mv,
              browserWindow: Lv,
              windowLocation: i,
              packageMajorVersion: $v,
              reporter: Bv,
              pluginStatusStore: Fv,
              qpr: Jv,
              eventHandlers: zv,
              componentLoadCallback: function (e) {
                var t = Fv[Tr].prebid._tag;
                if (
                  (function (e) {
                    return "loading" === e;
                  })(t)
                ) {
                  var n = Bv[ri]() - e,
                    i = Uv.getPrebidDownloadCutoffMs();
                  re(i) || n <= i
                    ? Fv[Ar]("prebid", { _tag: "loaded" })
                    : (Mv[C](
                        "[PREBID]: Not enabling because library took ".concat(
                          n,
                          "ms to download"
                        )
                      ),
                      Fv[Ar]("prebid", { _tag: "cancelled" }));
                } else
                  Mv[k](function () {
                    return "[PREBID]: Skipping late componentLoadCallback because state has already advanced to '".concat(
                      t,
                      "'"
                    );
                  });
              },
              onReadyCallback: function (e) {
                "cancelled" !== Fv[Tr].prebid._tag &&
                  (e
                    ? (Mv[C](
                        "[PREBID]: Initialisation cancelled by prebid because there is no consent in strict CMP mode"
                      ),
                      Fv[Ar]("prebid", { _tag: "cancelled" }))
                    : Fv[Ar]("prebid", kr(t, Bv[ri](), void 0)));
              },
              onPrebidConfigured: function () {
                return r[Ml]();
              },
            });
          }, "prebid")
        : (Fv[Ar]("prebid", { _tag: "cancelled" }),
          Mv[A](
            "[INIT]: Skipping prebid load because fuse took ".concat(
              t,
              "ms to begin loading"
            )
          ));
    })(),
    (function () {
      if (!Uv.isUamEnabled())
        return (
          Fv[Ar]("uam", { _tag: "disabled" }),
          void Mv[A]("[INIT]: Not loading UAM because it is disabled")
        );
      var e = Uv.getUamTagStartCutoffMs(),
        t = Bv[ri]();
      if (!(re(e) || t < e))
        return (
          Fv[Ar]("uam", { _tag: "cancelled" }),
          void Mv[A](
            "[INIT]: Deferring UAM load because fuse took ".concat(
              t,
              "ms to begin loading"
            )
          )
        );
      rp(function (e) {
        ac(Jv[ge](), "simulate uam download delay", Mv, function () {
          var t = Er(Bv[ri](), e);
          Fv[Ar]("uam", t),
            Nv.resolve(gg)[ld](
              Uv.isCmpRequired(),
              function () {
                Fv[Ar]("uam", { _tag: "loaded" });
              },
              function (e) {
                e
                  ? (Fv[Ar]("uam", { _tag: "cancelled" }),
                    Mv[A](
                      "[INIT]: Cancelled UAM load because there is no consent in strict CMP mode"
                    ))
                  : Fv[Ar]("uam", kr(t, Bv[ri](), void 0));
              }
            );
        });
      }, "uam");
    })(),
    Uv.isYandexEnabled()
      ? (Fv[Ar]("gpt", { _tag: "disabled" }),
        (function () {
          var e = Er(Bv[ri]());
          if ((Fv[Ar]("yandex", e), window.yaContextCb))
            Fv[Ar]("yandex", kr(e, Bv[ri](), void 0));
          else {
            var t = Lv.document,
              n = t.createElement("script");
            (n.innerHTML = "window.yaContextCb=window.yaContextCb||[]"),
              t.head.appendChild(n);
            var i = t.createElement("script");
            (i.src = "https://yandex.ru/ads/system/context.js"),
              (i.async = !0),
              t.head.appendChild(i);
            var r = setInterval(function () {
              var t, n;
              (null ===
                (n =
                  null === (t = window.Ya) || void 0 === t
                    ? void 0
                    : t.Context) || void 0 === n
                ? void 0
                : n.AdvManager) &&
                (Fv[Ar]("yandex", kr(e, Bv[ri](), void 0)), clearInterval(r));
            }, 100);
          }
        })())
      : (Fv[Ar]("yandex", { _tag: "disabled" }),
        op(),
        Zv[Bc](function () {
          !(function (e, t, n, i, r) {
            i.isBlockthroughEnabled()
              ? r
                ? (n[bi]("blockthrough_load_start"),
                  ba({ logger: e, window: t }, gv, function () {
                    e[C]("[BLOCKTHROUGH]: Tag loaded"),
                      n[bi]("blockthrough_load_finish");
                  }))
                : e[k](
                    "[INIT]: Skip loading blockthrough because page on XS breakpoint"
                  )
              : e[k](
                  "[INIT]: Skip loading blockthrough because it is not enabled"
                );
          })(Mv, Lv, Bv, Uv, Yv[gn]());
        })),
    (function () {
      if (!Uv.isAssertiveYieldEnabled())
        return (
          Fv[Ar]("assertiveYield", { _tag: "disabled" }),
          void Mv[A](
            "[INIT]: Not loading AssertiveYield because it is disabled"
          )
        );
      var e = Er(Bv[ri](), !1);
      Fv[Ar]("assertiveYield", e),
        Nv.resolve(Dg)[bg](function (t) {
          t
            ? (Mv[A](
                "[INIT]: Cancelled AssertiveYield because its script failed to load or initialise"
              ),
              Fv[Ar]("assertiveYield", { _tag: "cancelled" }))
            : Fv[Ar]("assertiveYield", kr(e, Bv[ri](), void 0));
        });
    })(),
    oc(Uv.isConfiantEnabled(), function () {
      return (function (e, t, n) {
        var i =
            arguments.length > 3 && void 0 !== arguments[3]
              ? arguments[3]
              : "ZVeqITFg3t0RVj7Gh41kEbdx9DA",
          r = arguments.length > 4 ? arguments[4] : void 0;
        t[bi]("confiant_load_start");
        var o = n.confiant || {};
        o[i] = o[i] || { clientSettings: {} };
        var a = o[i].clientSettings || (o[i].clientSettings = {});
        (a.callback = function (t, n, i, r, o, a) {
          e[C](
            "[CONFIANT]: Has blocked the ad: ",
            t,
            n,
            i,
            r,
            o,
            JSON.stringify(a)
          );
        }),
          (a.prebidExcludeBidders = []),
          (a.prebidNameSpace = "fusePbjs"),
          (a.on_prebid_error = function (t) {
            e[C]("[CONFIANT]: failed to scan an ad", t);
          }),
          (a.onRendered = function (t) {
            e[C]("[CONFIANT]: Rendered the ad", t);
          }),
          (n.confiant = o),
          ba(
            { logger: e, window: n },
            (function (e) {
              return {
                name: "Confiant",
                url: "//cdn.confiant-integrations.net/".concat(
                  e,
                  "/gpt_and_prebid/"
                ),
                file: "config.js",
              };
            })(i),
            function () {
              e[C]("[CONFIANT]: Script loaded"),
                t[bi]("confiant_load_finish"),
                r && r();
            }
          );
      })(Mv, Bv, Lv, Uv.getConfiantId());
    }),
    (function (e) {
      var t,
        n = s(Oo);
      try {
        for (n.s(); !(t = n.n()).done; ) {
          var i = t.value;
          i.setup && i.isEnabled(e.settings) && i.setup(e);
        }
      } catch (e) {
        n.e(e);
      } finally {
        n.f();
      }
    })({ browserWindow: Lv, settings: Uv, logger: Mv }),
    (function () {
      if (!Uv.getAfsSettings().enabled)
        return (
          Fv[Ar]("afs", { _tag: "disabled" }),
          void Mv[A]("[INIT]: Not loading AFS because it is disabled")
        );
      rp(function (e) {
        var t = Er(Bv[ri](), e);
        Fv[Ar]("afs", t),
          Kv[lm](function (e) {
            e
              ? (Mv[A](
                  "[INIT]: Cancelled AFS load because there is no consent in strict CMP mode"
                ),
                Fv[Ar]("afs", { _tag: "cancelled" }))
              : Fv[Ar]("afs", kr(t, Bv[ri](), void 0));
          });
      }, "afs");
    })(),
    oc(Uv.isResponsiveEnabled(), function () {
      Mv[A]("[INIT]: Enabling responsive"), Nv.resolve(tm);
    }),
    (function () {
      if (!Uv.getEnableIntentIQ())
        return (
          Fv[Ar]("intentIQ", { _tag: "disabled" }),
          void Mv[A]("[INIT]: Not loading IntentIQ because it is disabled")
        );
      rp(function (e) {
        var t = Er(Bv[ri](), e);
        Fv[Ar]("intentIQ", t),
          Nv.resolve(Bg)[Cg](function (e) {
            e
              ? (Mv[A]("[INIT]: Cancelled IntentIQ"),
                Fv[Ar]("intentIQ", { _tag: "cancelled" }))
              : Fv[Ar]("intentIQ", kr(t, Bv[ri](), void 0));
          });
      }, "intentIQ");
    })(),
    Uv.enableOptable()) && Nv.resolve(Mg)[Rg]();
    Gv.setIsLowDwellPage(Qv[zf](Lv.location.toString()));
    var r = Nv.resolve(je);
    r
      ? (function (e, t, n, i, r, o) {
          try {
            e[C]("[INIT][onFuseLoadCallback] Start"),
              t(n, i, r, o),
              e[k]("[INIT][onFuseLoadCallback] Finish");
          } catch (n) {
            e[T](
              "[INIT][onFuseLoadCallback] Encountered error during evaluation",
              n,
              t
            );
          }
        })(Mv, r, Lv, xv, Uv.getV2CompatOverrides(), Hv)
      : Mv[k]("[INIT]: No custom callback defined"),
      jv[qo](e),
      Uv.isScanDOMOnPageLoad()
        ? np()
        : Fv[Ar]("docReadyScan", { _tag: "disabled" }),
      zv[It].immediateOrOnce(function () {
        Bv[bi]("fuse_queue_start"),
          Nv.resolve(Cu)[_u](),
          Bv[bi]("fuse_queue_finish"),
          Uv.isWidgetRendererEnabled() && qv.init(),
          (xv.initialised = !0),
          (xv.init = !0),
          (xv.loading = !1),
          Bv[bi]("tag_initialised"),
          Gv.setTagInitialised(),
          Xv[Af](),
          (Qv[Nf]() ||
            Uv.isScanDOMOnPageLoad() ||
            Uv.isAutoRegistrationEnabled()) &&
            (Bv[bi]("fuse_trigger_auto_auction_start"),
            Vv[nf](!0, !1, Hv),
            Bv[bi]("fuse_trigger_auto_auction_finish"),
            Uv.isAutoRegistrationEnabled() &&
              (ap(),
              setInterval(function () {
                ap();
              }, 200))),
          Bv[bi]("on_tag_init_event_start"),
          ep.tagInitEmitter.emit({}),
          zv[lt].emit({ tagInitUrl: Lv.location.href }),
          Bv[bi]("on_tag_init_event_finish"),
          (function (e, t) {
            var n = e.signals,
              i = e.reporter,
              r = e.logger,
              o = e.setTimeout;
            if (0 !== n.length) {
              var a = n,
                s = !1,
                c = !0,
                u = function () {
                  s || ((s = !0), t());
                };
              n.forEach(function (e) {
                return i[bi]("".concat(e.name, "_wait_callback_start"));
              }),
                o(function () {
                  s ||
                    (a.forEach(function (e) {
                      return i[bi]("".concat(e.name, "_wait_callback_timeout"));
                    }),
                    r[A](function () {
                      var e = a
                        .map(function (e) {
                          return e.name;
                        })
                        .join(", ");
                      return "[INIT]: First auction gate timed out after "
                        .concat(400, "ms waiting for ")
                        .concat(e);
                    }),
                    u());
                }, 400),
                n.forEach(function (e) {
                  try {
                    e.subscribe(function () {
                      !s &&
                        a.includes(e) &&
                        ((a = a.filter(function (t) {
                          return t !== e;
                        })),
                        i[bi]("".concat(e.name, "_wait_callback_resolved")),
                        0 !== a.length || c || u());
                    });
                  } catch (t) {
                    r[E](
                      "[INIT]: First auction gate signal ".concat(
                        e.name,
                        " failed to subscribe"
                      ),
                      t
                    ),
                      i[bi]("".concat(e.name, "_wait_callback_error"));
                  }
                }),
                (c = !1),
                0 === a.length && u();
            } else t();
          })(
            {
              signals: Tv(Uv, Fv, zv),
              reporter: Bv,
              logger: Mv,
              setTimeout: function (e, t) {
                return Lv.setTimeout(e, t);
              },
            },
            function () {
              return Vv[cf]();
            }
          );
        var e = zv[ft];
        e.subscribe(function () {
          return Wv[Tm]();
        }),
          e.subscribe(function () {
            Mv[k](
              "[PAGE]: Registering slots and running auction after PageInit"
            ),
              Gv.setIsLowDwellPage(Qv[zf](Lv.location.toString())),
              ap();
          }),
          Nv.resolve(uv)[Jm](),
          zv[gt].subscribe(function () {
            Mv[k]("[PAGE]: Received page reset event"), Wv[km]();
          }),
          Nv.resolve(lv)[qm]();
      }),
      Bv[bi]("fuse_bootstrap_finish");
  }
  ac(Jv[ue](), "simulate slow fuse download", Mv, function () {
    return sp();
  });
});
