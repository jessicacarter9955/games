google.maps.__gjsload__("geometry", function (_) {
  var sta = function (a, b) {
      return Math.abs(_.Bk(b - a, -180, 180));
    },
    tta = function (a, b, c, d, e) {
      if (!d) {
        c = sta(a.lng(), c) / sta(a.lng(), b.lng());
        if (!e)
          return (
            (e = Math.sin(_.Oj(a.lat()))),
            (e = Math.log((1 + e) / (1 - e)) / 2),
            (b = Math.sin(_.Oj(b.lat()))),
            _.Pj(
              2 *
                Math.atan(
                  Math.exp(e + c * (Math.log((1 + b) / (1 - b)) / 2 - e))
                ) -
                Math.PI / 2
            )
          );
        a = e.fromLatLngToPoint(a);
        b = e.fromLatLngToPoint(b);
        return e
          .fromPointToLatLng(
            new _.Dm(a.x + c * (b.x - a.x), a.y + c * (b.y - a.y))
          )
          .lat();
      }
      e = _.Oj(a.lat());
      a = _.Oj(a.lng());
      d = _.Oj(b.lat());
      b = _.Oj(b.lng());
      c = _.Oj(c);
      return _.Bk(
        _.Pj(
          Math.atan2(
            Math.sin(e) * Math.cos(d) * Math.sin(c - b) -
              Math.sin(d) * Math.cos(e) * Math.sin(c - a),
            Math.cos(e) * Math.cos(d) * Math.sin(a - b)
          )
        ),
        -90,
        90
      );
    },
    uta = function (a, b) {
      a = new _.nl(a, !1);
      b = new _.nl(b, !1);
      return a.equals(b);
    },
    vta = function (a, b) {
      var c = _.ol(a);
      a = _.pl(a);
      var d = _.ol(b);
      b = _.pl(b);
      return (
        2 *
        Math.asin(
          Math.sqrt(
            Math.pow(Math.sin((c - d) / 2), 2) +
              Math.cos(c) * Math.cos(d) * Math.pow(Math.sin((a - b) / 2), 2)
          )
        )
      );
    },
    AA = function (a, b, c) {
      a = _.rl(a);
      b = _.rl(b);
      c = c || 6378137;
      return vta(a, b) * c;
    },
    yta = function (a, b) {
      b = b || 6378137;
      a instanceof _.an && (a = a.getArray());
      a = (0, _.Iq)(a);
      if (a.length === 0) return 0;
      var c = Array(4),
        d = Array(3),
        e = [1, 0, 0, 0],
        f = Array(3);
      wta(a[a.length - 1], f);
      for (let w = 0; w < a.length; ++w)
        wta(a[w], d), BA(f, d, c), xta(c, e, e), ([f[0], f[1], f[2]] = d);
      var [g, h, k] = f,
        [n, p, r, u] = e;
      return 2 * Math.atan2(g * p + h * r + k * u, n) * (b * b);
    },
    zta = function (a, b) {
      if (isFinite(a)) {
        var c = a % 360;
        a = Math.round(c / 90);
        c -= a * 90;
        if (c === 30 || c === -30) {
          c = Math.sign(c) * 0.5;
          var d = Math.sqrt(0.75);
        } else
          c === 45 || c === -45
            ? ((c = Math.sign(c) * Math.SQRT1_2), (d = Math.SQRT1_2))
            : ((d = (c / 180) * Math.PI), (c = Math.sin(d)), (d = Math.cos(d)));
        switch (a & 3) {
          case 0:
            b[0] = c;
            b[1] = d;
            break;
          case 1:
            b[0] = d;
            b[1] = -c;
            break;
          case 2:
            b[0] = -c;
            b[1] = -d;
            break;
          default:
            (b[0] = -d), (b[1] = c);
        }
      } else (b[0] = NaN), (b[1] = NaN);
    },
    wta = function (a, b) {
      var c = Array(2);
      zta(a.lat(), c);
      var [d, e] = c;
      zta(a.lng(), c);
      var [f, g] = c;
      b[0] = e * g;
      b[1] = e * f;
      b[2] = d;
    },
    xta = function (a, b, c) {
      var d = a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2],
        e = a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1],
        f = a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0];
      c[0] = a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3];
      c[1] = d;
      c[2] = e;
      c[3] = f;
    },
    BA = function (a, b, c) {
      var d = a[0] - b[0],
        e = a[1] - b[1],
        f = a[2] - b[2],
        g = a[0] + b[0],
        h = a[1] + b[1],
        k = a[2] + b[2],
        n = g * g + h * h + k * k,
        p = e * k - f * h;
      f = f * g - d * k;
      d = d * h - e * g;
      e = n * n + p * p + f * f + d * d;
      if (e !== 0)
        (b = Math.sqrt(e)),
          (c[0] = n / b),
          (c[1] = p / b),
          (c[2] = f / b),
          (c[3] = d / b);
      else {
        a: for (n = [a[0] - b[0], a[1] - b[1], a[2] - b[2]], p = 0; p < 3; ++p)
          if (n[p] !== 0) {
            if (n[p] < 0) {
              n = [-n[0], -n[1], -n[2]];
              break a;
            }
            break;
          }
        p = 0;
        for (f = 1; f < n.length; ++f)
          Math.abs(n[f]) < Math.abs(n[p]) && (p = f);
        f = [0, 0, 0];
        f[p] = 1;
        n = [
          n[1] * f[2] - n[2] * f[1],
          n[2] * f[0] - n[0] * f[2],
          n[0] * f[1] - n[1] * f[0],
        ];
        p = Math.hypot(...n);
        n = [n[0] / p, n[1] / p, n[2] / p];
        p = Array(4);
        BA(a, n, p);
        a = Array(4);
        BA(n, b, a);
        xta(a, p, c);
      }
    },
    Ata = function (a, b, c) {
      a = _.rl(a);
      c = c || 1e-9;
      var d = _.Bk(a.lng(), -180, 180),
        e = b instanceof _.Vr,
        f = !!b.get("geodesic"),
        g = b.get("latLngs");
      b = b.get("map");
      b = !f && b ? b.getProjection() : null;
      for (let r = 0, u = g.getLength(); r < u; ++r) {
        let w = g.getAt(r),
          y = w.getLength(),
          A = e ? y : y - 1;
        for (let J = 0; J < A; ++J) {
          var h = w.getAt(J);
          let M = w.getAt((J + 1) % y);
          if (uta(h, a) || uta(M, a)) return !0;
          var k = _.Bk(h.lng(), -180, 180),
            n = _.Bk(M.lng(), -180, 180);
          let T = Math.max(k, n),
            R = Math.min(k, n);
          if (
            (k =
              Math.abs(_.Bk(k - n, -180, 180)) <= 1e-9 &&
              (Math.abs(_.Bk(k - d, -180, 180)) <= c ||
                Math.abs(_.Bk(n - d, -180, 180)) <= c))
          ) {
            k = a.lat();
            n = Math.min(h.lat(), M.lat()) - c;
            var p = Math.max(h.lat(), M.lat()) + c;
            k = k >= n && k <= p;
          }
          if (k) return !0;
          if (T - R > 180 ? d + c >= T || d - c <= R : d + c >= R && d - c <= T)
            if (((h = tta(h, M, d, f, b)), Math.abs(h - a.lat()) < c))
              return !0;
        }
      }
      return !1;
    },
    CA = class {};
  CA.computeSignedArea = yta;
  CA.computeArea = function (a, b) {
    if (
      !(
        a instanceof _.an ||
        Array.isArray(a) ||
        a instanceof _.mm ||
        a instanceof _.hn
      )
    )
      try {
        a = _.om(a);
      } catch (c) {
        try {
          a = new _.hn((0, _.js)(a));
        } catch (d) {
          throw _.Uk(
            "Invalid path passed to computeArea(): " + JSON.stringify(a)
          );
        }
      }
    b = b || 6378137;
    if (a instanceof _.hn) {
      if (a.getRadius() === void 0)
        throw _.Uk(
          "Invalid path passed to computeArea(): Circle is missing radius."
        );
      if (a.getRadius() < 0)
        throw _.Uk(
          "Invalid path passed to computeArea(): Circle must have non-negative radius."
        );
      if (b < 0)
        throw _.Uk(
          "Invalid radiusOfSphere passed to computeArea(): radiusOfSphere must be non-negative."
        );
      if (a.getRadius() > Math.PI * b)
        throw _.Uk(
          "Invalid path passed to computeArea(): Circle must not cover more than 100% of the sphere."
        );
      return 2 * Math.PI * b ** 2 * (1 - Math.cos(a.getRadius() / b));
    }
    if (a instanceof _.mm) {
      if (b < 0)
        throw _.Uk(
          "Invalid radiusOfSphere passed to computeArea(): radiusOfSphere must be non-negative."
        );
      if (a.lat.lo > a.lat.hi)
        throw _.Uk(
          "Invalid path passed to computeArea(): the southern LatLng of a LatLngBounds cannot be more north than the northern LatLng."
        );
      let c =
        2 *
        Math.PI *
        b ** 2 *
        (1 - Math.cos(((a.lat.lo - 90) * Math.PI) / 180));
      c -=
        2 *
        Math.PI *
        b ** 2 *
        (1 - Math.cos(((a.lat.hi - 90) * Math.PI) / 180));
      return (c * Math.abs(a.lng.hi - a.lng.lo)) / 360;
    }
    return Math.abs(yta(a, b));
  };
  CA.computeLength = function (a, b) {
    b = b || 6378137;
    var c = 0;
    a instanceof _.an && (a = a.getArray());
    for (let d = 0, e = a.length - 1; d < e; ++d) c += AA(a[d], a[d + 1], b);
    return c;
  };
  CA.computeDistanceBetween = AA;
  CA.traversePath = function () {
    throw Error(
      "traversePath() is not available in this version of the Maps JavaScript API."
    );
  };
  CA.interpolate = function (a, b, c) {
    a = _.rl(a);
    b = _.rl(b);
    var d = _.ol(a),
      e = _.pl(a),
      f = _.ol(b),
      g = _.pl(b),
      h = Math.cos(d),
      k = Math.cos(f);
    b = vta(a, b);
    var n = Math.sin(b);
    if (n < 1e-6) return new _.nl(a.lat(), a.lng());
    a = Math.sin((1 - c) * b) / n;
    c = Math.sin(c * b) / n;
    b = a * h * Math.cos(e) + c * k * Math.cos(g);
    e = a * h * Math.sin(e) + c * k * Math.sin(g);
    return new _.nl(
      _.Pj(
        Math.atan2(a * Math.sin(d) + c * Math.sin(f), Math.sqrt(b * b + e * e))
      ),
      _.Pj(Math.atan2(e, b))
    );
  };
  CA.computeOffsetOrigin = function (a, b, c, d) {
    a = _.rl(a);
    c = _.Oj(c);
    b /= d || 6378137;
    d = Math.cos(b);
    var e = Math.sin(b) * Math.cos(c);
    b = Math.sin(b) * Math.sin(c);
    c = Math.sin(_.ol(a));
    var f = e * e * d * d + d * d * d * d - d * d * c * c;
    if (f < 0) return null;
    var g = e * c + Math.sqrt(f);
    g /= d * d + e * e;
    var h = (c - e * g) / d;
    g = Math.atan2(h, g);
    if (g < -Math.PI / 2 || g > Math.PI / 2)
      (g = e * c - Math.sqrt(f)), (g = Math.atan2(h, g / (d * d + e * e)));
    if (g < -Math.PI / 2 || g > Math.PI / 2) return null;
    a = _.pl(a) - Math.atan2(b, d * Math.cos(g) - e * Math.sin(g));
    return new _.nl(_.Pj(g), _.Pj(a));
  };
  CA.computeOffset = function (a, b, c, d) {
    a = _.rl(a);
    b /= d || 6378137;
    c = _.Oj(c);
    var e = _.ol(a);
    a = _.pl(a);
    d = Math.cos(b);
    b = Math.sin(b);
    var f = Math.sin(e);
    e = Math.cos(e);
    var g = d * f + b * e * Math.cos(c);
    return new _.nl(
      _.Pj(Math.asin(g)),
      _.Pj(a + Math.atan2(b * e * Math.sin(c), d - f * g))
    );
  };
  CA.computeHeading = function (a, b) {
    a = _.rl(a);
    b = _.rl(b);
    var c = _.ol(a),
      d = _.pl(a);
    a = _.ol(b);
    b = _.pl(b) - d;
    return _.Bk(
      _.Pj(
        Math.atan2(
          Math.sin(b) * Math.cos(a),
          Math.cos(c) * Math.sin(a) - Math.sin(c) * Math.cos(a) * Math.cos(b)
        )
      ),
      -180,
      180
    );
  };
  var DA = class {};
  DA.isLocationOnEdge = Ata;
  DA.containsLocation = function (a, b) {
    a = _.rl(a);
    if (!(b instanceof _.Vr)) {
      if (b instanceof _.hn) {
        var c = b.getCenter();
        var d = b.getRadius();
      } else
        try {
          var e = (0, _.js)(b);
          c = e.center;
          d = e.radius;
        } catch (k) {
          throw _.Uk(
            "Invalid polygon or circle passed to containsLocation()",
            k
          );
        }
      if (!c)
        throw _.Uk(
          "Invalid polygon or circle passed to containsLocation(): Circle is missing center."
        );
      if (d == null)
        throw _.Uk(
          "Invalid polygon or circle passed to containsLocation(): Circle is missing radius."
        );
      if (d < 0)
        throw _.Uk(
          "Invalid polygon or circle passed to containsLocation(): Circle must have non-negative radius."
        );
      return AA(a, c) <= d;
    }
    c = _.Bk(a.lng(), -180, 180);
    d = !!b.get("geodesic");
    e = b.get("latLngs");
    var f = b.get("map");
    f = !d && f ? f.getProjection() : null;
    var g = !1;
    for (let k = 0, n = e.getLength(); k < n; ++k) {
      let p = e.getAt(k);
      for (let r = 0, u = p.getLength(); r < u; ++r) {
        let w = p.getAt(r),
          y = p.getAt((r + 1) % u);
        var h = _.Bk(w.lng(), -180, 180);
        let A = _.Bk(y.lng(), -180, 180),
          J = Math.max(h, A);
        h = Math.min(h, A);
        (J - h > 180 ? c >= J || c < h : c < J && c >= h) &&
          tta(w, y, c, d, f) < a.lat() &&
          (g = !g);
      }
    }
    return g || Ata(a, b);
  };
  var Bta = { encoding: _.ss, spherical: CA, poly: DA };
  _.wa.google.maps.geometry = Bta;
  _.ek("geometry", Bta);
});
