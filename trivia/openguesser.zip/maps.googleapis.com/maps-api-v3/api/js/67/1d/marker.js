google.maps.__gjsload__("marker", function (_) {
  var XWa = function (a, b) {
      var c = _.Sa(b);
      a.Hh.set(c, b);
      a.Ih.Hh();
    },
    YWa = function (a, b) {
      if (a.Ih.has(b)) {
        _.Kl(b, "UPDATE_BASEMAP_COLLISION");
        _.Kl(b, "UPDATE_MARKER_COLLISION");
        _.Kl(b, "REMOVE_COLLISION");
        a.Ih.delete(b);
        var c = a.Jh;
        let d = _.Sa(b);
        c.Hh.has(d) && (c.Hh.delete(d), (b.kq = null), c.Ih.Hh());
        _.Jfa(a.Hh, b);
      }
    },
    ZWa = function (a, b) {
      a.Ih.has(b) ||
        (a.Ih.add(b),
        _.Gl(b, "UPDATE_BASEMAP_COLLISION", () => {
          a.Kh.add(b);
          a.Lh.Kh();
        }),
        _.Gl(b, "UPDATE_MARKER_COLLISION", () => {
          a.Lh.Kh();
        }),
        _.Gl(b, "REMOVE_COLLISION", () => {
          YWa(a, b);
        }),
        XWa(a.Jh, b),
        _.Ifa(a.Hh, b));
    },
    $Wa = function (a, b, c, d) {
      b = _.Hw(a, b, d, (e) => e);
      a = _.Hw(a, c, d, (e) => e);
      return { Gi: b.Gi - a.Gi, Hi: b.Hi - a.Hi, Mi: d };
    },
    aXa = function (a, b) {
      var c = c || [];
      _.qH(
        a,
        (d) => {
          c.push(d);
        },
        (d) => d.containsPoint(b)
      );
      return c;
    },
    bXa = function (a) {
      return `${_.jea(a)}-internal-${a}`;
    },
    cXa = function (a, b) {
      b = (a = a.__e3_) && a[b];
      return !!b && Object.values(b).some((c) => c.bG);
    },
    dXa = function (a, b, c) {
      return new _.Fl(a, `${b}_removed`, c, 0, !1);
    },
    eXa = function (a, b, c) {
      return new _.Fl(a, `${b}_added`, c, 0, !1);
    },
    $M = function (a) {
      return a
        ? _.Jo.has(a)
          ? _.Jo.get(a)
          : a instanceof ShadowRoot
          ? $M(a.host)
          : $M(a.parentNode)
        : null;
    },
    fXa = function (a) {
      var b = 1;
      return () => {
        --b || a();
      };
    },
    aN = function (a) {
      return a instanceof _.jA;
    },
    bN = function (a) {
      return aN(a) ? a.getSize() : a.size;
    },
    gXa = function (a, b) {
      if (!(a && b && a.isConnected && b.isConnected)) return !1;
      a = a.getBoundingClientRect();
      b = b.getBoundingClientRect();
      return !(
        b.x + b.width < a.x - 0 ||
        b.x > a.x + a.width + 0 ||
        b.y + b.height < a.y - 0 ||
        b.y > a.y + a.height + 0
      );
    },
    hXa = function (a, b) {
      _.PD().Hh.load(new _.pG(a), (c) => {
        b(c && c.size);
      });
    },
    iXa = function (a, b) {
      a = a.getBoundingClientRect();
      b = b instanceof Element ? b.getBoundingClientRect() : a;
      return {
        offset: new _.Dm(b.x - a.x, b.y - a.y),
        size: new _.Hm(b.width, b.height),
      };
    },
    cN = function (a) {
      a = new DOMMatrixReadOnly(a.transform);
      return { offsetX: a.m41, offsetY: a.m42 };
    },
    dN = function (a) {
      var b = window.devicePixelRatio || 1;
      return Math.round(a * b) / b;
    },
    jXa = function (a, { clientX: b, clientY: c }) {
      var { height: d, left: e, top: f, width: g } = a.getBoundingClientRect();
      return { oi: dN(b - (e + g / 2)), si: dN(c - (f + d / 2)) };
    },
    kXa = function (a, b) {
      if (!a || !b) return null;
      a = a.getProjection();
      return _.ov(b, a);
    },
    lXa = function (a, b) {
      var c = _.TG(a);
      if (!b || !c) return !1;
      a = Math.abs(c.clientX - b.clientX);
      b = Math.abs(c.clientY - b.clientY);
      return a * a + b * b >= 4;
    },
    eN = function (a, b) {
      if (a.bounds.containsPoint(b.sk))
        if (a.children) for (let c = 0; c < 4; ++c) eN(a.children[c], b);
        else a.items.push(b), a.items.length > 10 && a.depth < 30 && a.split();
    },
    nXa = function (a, b) {
      return new mXa(a, b);
    },
    oXa = function (a, b, c, d) {
      var e = b.fromPointToLatLng(c, !0);
      c = e.lat();
      e = e.lng();
      var f = b.fromPointToLatLng(new _.Dm(a.minX, a.minY), !0);
      a = b.fromPointToLatLng(new _.Dm(a.maxX, a.maxY), !0);
      b = Math.min(f.lat(), a.lat());
      var g = Math.min(f.lng(), a.lng()),
        h = Math.max(f.lat(), a.lat());
      for (f = Math.max(f.lng(), a.lng()); f > 180; )
        (f -= 360), (g -= 360), (e -= 360);
      for (; g < 180; ) {
        a = _.Wm(b, g, h, f);
        let k = new _.nl(c, e, !0);
        d(a, k);
        g += 360;
        f += 360;
        e += 360;
      }
    },
    pXa = function (a, b) {
      var c = [];
      c.push("@-webkit-keyframes ", b, " {\n");
      _.Fb(a.frames, (d) => {
        c.push(d.time * 100 + "% { ");
        c.push(
          "-webkit-transform: translate3d(" + d.translate[0] + "px,",
          d.translate[1] + "px,0); "
        );
        c.push("-webkit-animation-timing-function: ", d.Po, "; ");
        c.push("}\n");
      });
      c.push("}\n");
      return c.join("");
    },
    qXa = function (a, b) {
      for (let c = 0; c < a.frames.length - 1; c++) {
        let d = a.frames[c + 1];
        if (b >= a.frames[c].time && b < d.time) return c;
      }
      return a.frames.length - 1;
    },
    rXa = function (a) {
      if (a.Hh) return a.Hh;
      a.Hh = "_gm" + Math.round(Math.random() * 1e4);
      var b = pXa(a, a.Hh);
      fN ||
        ((fN = _.Rj("style")),
        (fN.type = "text/css"),
        document.querySelectorAll("HEAD")[0].appendChild(fN));
      b = fN.textContent + b;
      b = _.Xj(b);
      fN.textContent = _.Sh(new _.Rh(b));
      return a.Hh;
    },
    sXa = function (a) {
      a = a.get("collisionBehavior");
      return (
        a === "REQUIRED_AND_HIDES_OPTIONAL" ||
        a === "OPTIONAL_AND_HIDES_LOWER_PRIORITY"
      );
    },
    tXa = function (a, b, c = !1) {
      if (!b.get("internalMarker")) {
        _.nk(a, 149055);
        c
          ? _.nk(a, 149060)
          : a instanceof _.gm
          ? _.nk(a, 149057)
          : a instanceof _.Xq &&
            (_.nk(a, 149059), a.get("standAlone") && _.nk(a, 149058));
        c = a.get("styles") || [];
        Array.isArray(c) && c.some((e) => "stylers" in e) && _.nk(a, 174113);
        sXa(b) && _.nk(a, 149062);
        b.get("anchorPoint") && _.nk(a, 149064);
        c = b.get("animation");
        c === 1 && _.nk(a, 149065);
        c === 2 && _.nk(a, 149066);
        b.get("clickable") === !1 &&
          (_.nk(a, 149091), b.get("title") && _.nk(a, 149063));
        b.get("draggable") &&
          (_.nk(a, 149069), b.get("clickable") === !1 && _.nk(a, 149070));
        b.get("visible") === !1 && _.nk(a, 149081);
        b.get("crossOnDrag") && _.nk(a, 149067);
        b.get("cursor") && _.nk(a, 149068);
        b.get("label") && _.nk(a, 149080);
        b.get("title") && _.nk(a, 149090);
        b.get("opacity") != null && _.nk(a, 149082);
        b.get("optimized") === !0
          ? _.nk(a, 149085)
          : b.get("optimized") === !1 && _.nk(a, 149071);
        b.get("zIndex") != null && _.nk(a, 149092);
        c = b.get("icon");
        var d = new gN();
        (d = !c || c === d.icon.url || c.url === d.icon.url)
          ? _.nk(a, 173084)
          : _.nk(a, 173083);
        typeof c === "string"
          ? _.nk(a, 149079)
          : c && c.url != null
          ? (c.anchor && _.nk(a, 149074),
            c.labelOrigin && _.nk(a, 149075),
            c.origin && _.nk(a, 149076),
            c.scaledSize && _.nk(a, 149077),
            c.size && _.nk(a, 149078))
          : c && c.path != null
          ? ((c = c.path),
            c === 0
              ? _.nk(a, 149088)
              : c === 1
              ? _.nk(a, 149072)
              : c === 2
              ? _.nk(a, 149073)
              : c === 3
              ? _.nk(a, 149086)
              : c === 4
              ? _.nk(a, 149087)
              : _.nk(a, 149089))
          : aN(c) && _.nk(a, 149083);
        b.get("shape") && (_.nk(a, 149084), d && _.nk(a, 162762));
        if ((c = b.get("place")))
          c.placeId ? _.nk(a, 149093) : _.nk(a, 149094),
            b.get("attribution") && _.nk(a, 149061);
      }
    },
    vXa = function (a, b, c) {
      uXa(a, c, (d) => {
        a.set(b, d);
        var e = d ? bN(d) : null;
        b === "viewIcon" && d && e && a.Hh && a.Hh(e, d.anchor, d.labelOrigin);
        d = a.get("modelLabel");
        a.set(
          "viewLabel",
          d
            ? {
                text: d.text || d,
                color: _.Fk(d.color, "#000000"),
                fontWeight: _.Fk(d.fontWeight, ""),
                fontSize: _.Fk(d.fontSize, "14px"),
                fontFamily: _.Fk(d.fontFamily, "Roboto,Arial,sans-serif"),
                className: d.className || "",
              }
            : null
        );
      });
    },
    uXa = function (a, b, c) {
      b
        ? aN(b)
          ? c(b)
          : b.path != null
          ? c(a.Ih(b))
          : (_.Gk(b) || (b.size = b.size || b.scaledSize),
            b.size
              ? c(b)
              : (b.url || (b = { url: b }),
                hXa(b.url, (d) => {
                  b.size = d || new _.Hm(24, 24);
                  c(b);
                })))
        : c(null);
    },
    wXa = function (a) {
      var b = a.get("mapPixelBoundsQ"),
        c = a.get("icon"),
        d = a.get("position");
      if (!b || !c || !d) return a.get("visible") !== !1;
      var e = c.anchor || _.Mm,
        f = c.size.width + Math.abs(e.x);
      c = c.size.height + Math.abs(e.y);
      return d.x > b.minX - f &&
        d.y > b.minY - c &&
        d.x < b.maxX + f &&
        d.y < b.maxY + c
        ? a.get("visible") !== !1
        : !1;
    },
    xXa = function (a, b) {
      a.origin = b;
      a.Ih.Hh();
    },
    hN = function (a) {
      a.Hh && (_.mv(a.Hh), (a.Hh = null));
    },
    yXa = function (a, b, c) {
      _.RD(() => {
        a.style.webkitAnimationDuration = c.duration ? c.duration + "ms" : "";
        a.style.webkitAnimationIterationCount = `${c.Do}`;
        a.style.webkitAnimationName = b || "";
      });
    },
    zXa = function () {
      var a = [];
      for (let b = 0; b < iN.length; b++) {
        let c = iN[b];
        c.tick();
        c.Hh || a.push(c);
      }
      iN = a;
      iN.length === 0 && (window.clearInterval(jN), (jN = null));
    },
    kN = function (a) {
      return a ? a.__gm_at || _.Mm : null;
    },
    BXa = function (a, b) {
      var c = 1,
        d = a.animation;
      var e = d.frames[qXa(d, b)];
      var f;
      d = a.animation;
      (f = d.frames[qXa(d, b) + 1]) && (c = (b - e.time) / (f.time - e.time));
      b = kN(a.element);
      d = a.element;
      f
        ? ((c = (0, AXa[e.Po || "linear"])(c)),
          (e = e.translate),
          (f = f.translate),
          (c = new _.Dm(
            Math.round(c * f[0] - c * e[0] + e[0]),
            Math.round(c * f[1] - c * e[1] + e[1])
          )))
        : (c = new _.Dm(e.translate[0], e.translate[1]));
      c = d.__gm_at = c;
      d = c.x - b.x;
      b = c.y - b.y;
      if (d !== 0 || b !== 0)
        (c = a.element),
          (e = new _.Dm(_.OD(c.style.left) || 0, _.OD(c.style.top) || 0)),
          (e.x += d),
          (e.y += b),
          _.ev(c, e);
      _.Sl(a, "tick");
    },
    EXa = function (a, b, c) {
      var d, e;
      if ((e = c.fL !== !1))
        (e = _.no()), (e = e.Hh.Nh || (e.Hh.Mh && _.bu(e.Hh.version, 7)));
      e ? (d = new CXa(a, b, c)) : (d = new DXa(a, b, c));
      d.start();
      return d;
    },
    nN = function (a) {
      a.Lh && (lN(a.wi), a.Lh.release(), (a.Lh = null));
      a.Hh && _.mv(a.Hh);
      a.Hh = null;
      a.Kh && _.mv(a.Kh);
      a.Kh = null;
      mN(a, !0);
      a.elements = [];
    },
    oN = function (a) {
      return a.get("clickable") !== !1;
    },
    mN = function (a, b = !1) {
      a.Qh
        ? (a.Wh = !0)
        : (_.Sl(a, b ? "ELEMENTS_REMOVED" : "CLEAR_TARGET"),
          a.targetElement && _.mv(a.targetElement),
          (a.targetElement = null),
          a.Nh &&
            (a.Nh.unbindAll(),
            a.Nh.release(),
            (a.Nh = null),
            lN(a.Sh),
            (a.Sh = null)),
          a.Vj && a.Vj.remove(),
          a.Oh && a.Oh.remove());
    },
    GXa = function (a, b) {
      var c = a.getIcon();
      if (c) {
        var d = c.url != null;
        a.Hh && a.ii === d && (_.mv(a.Hh), (a.Hh = null));
        a.ii = !d;
        var e;
        d && (e = { hv: () => {} });
        a.Hh = pN(a, b, a.Hh, c, e);
        FXa(a, c, qN(a));
      }
    },
    KXa = function (a) {
      var b = a.getLabel();
      if (b) {
        if (!a.Lh) {
          let e = (a.Lh = new HXa(
            a.getPanes(),
            b,
            a.get("opacity"),
            a.get("visible"),
            a.Vi
          ));
          a.wi = [
            _.Gl(a, "label_changed", () => {
              e.setLabel(a.get("label"));
            }),
            _.Gl(a, "opacity_changed", () => {
              e.setOpacity(a.get("opacity"));
            }),
            _.Gl(a, "panes_changed", () => {
              var f = a.get("panes");
              e.Gn = f;
              hN(e);
              e.Ih.Hh();
            }),
            _.Gl(a, "visible_changed", () => {
              e.setVisible(a.get("visible"));
            }),
          ];
        }
        if ((b = a.getIcon())) {
          var c = a.Hh,
            d = qN(a);
          c = IXa(a, b, d, kN(c) || _.Mm);
          d = bN(b);
          d = b.labelOrigin || new _.Dm(d.width / 2, d.height / 2);
          aN(b) && ((b = b.getSize().width), (d = new _.Dm(b / 2, b / 2)));
          xXa(a.Lh, new _.Dm(c.x + d.x, c.y + d.y));
          a.Lh.setZIndex(JXa(a));
          _.Zn(a.Lh.Ih);
        }
      }
    },
    MXa = function (a) {
      if (!a.Vh) {
        a.Jh && (a.Ph && _.Il(a.Ph), a.Jh.cancel(), (a.Jh = null));
        var b = a.get("animation");
        if ((b = LXa[b])) {
          var c = b.options;
          a.Hh &&
            ((a.Vh = !0),
            a.set("animating", !0),
            (b = EXa(a.Hh, b.icon, c)),
            (a.Jh = b),
            (a.Ph = _.Pl(b, "done", () => {
              a.set("animating", !1);
              a.Jh = null;
              a.set("animation", null);
            })));
        }
      }
    },
    lN = function (a) {
      if (a) for (let b = 0, c = a.length; b < c; b++) _.Il(a[b]);
    },
    qN = function (a) {
      return _.no().transform ? Math.min(1, a.get("scale") || 1) : 1;
    },
    IXa = function (a, b, c, d) {
      var e = a.getPosition(),
        f = bN(b),
        g = (b = rN(b)) ? b.x : f.width / 2;
      a.Zh.x = e.x + d.x - Math.round(g - (g - f.width / 2) * (1 - c));
      b = b ? b.y : f.height;
      a.Zh.y = e.y + d.y - Math.round(b - (b - f.height / 2) * (1 - c));
      return a.Zh;
    },
    JXa = function (a) {
      var b = a.get("zIndex");
      a.zl && (b = 1e6);
      _.Dk(b) || (b = Math.min(a.getPosition().y, 999999));
      return b;
    },
    rN = function (a) {
      return aN(a) ? a.getAnchor() : a.anchor;
    },
    FXa = function (a, b, c) {
      var d = bN(b);
      a.size.width = c * d.width;
      a.size.height = c * d.height;
      a.set("size", a.size);
      var e = a.get("anchorPoint");
      if (!e || e.Hh)
        (b = rN(b)),
          (a.anchorPoint.x = c * (b ? d.width / 2 - b.x : 0)),
          (a.anchorPoint.y = -c * (b ? b.y : d.height)),
          (a.anchorPoint.Hh = !0),
          a.set("anchorPoint", a.anchorPoint);
    },
    pN = function (a, b, c, d, e) {
      if (aN(d)) a = NXa(a, b, c, d);
      else if (d.url != null) {
        let f = d.origin || _.Mm;
        a = a.get("opacity");
        let g = _.Fk(a, 1);
        c
          ? (c.firstChild.__src__ !== d.url && _.rG(c.firstChild, d.url),
            _.tG(c, d.size, f, d.scaledSize),
            (c.firstChild.style.opacity = `${g}`))
          : ((e = e || {}),
            (e.ND = !_.lo.Oh),
            (e.alpha = !0),
            (e.opacity = a),
            (c = _.sG(d.url, null, f, d.size, null, d.scaledSize, e)),
            (c.style.display = "none"),
            b.appendChild(c));
        a = c;
      } else
        (b = c || _.fv("div", b)),
          (b.textContent = ""),
          (c = _.Jv()),
          (e = _.bv(b).createElement("canvas")),
          (e.width = d.size.width * c),
          (e.height = d.size.height * c),
          (e.style.width = _.Jk(d.size.width)),
          (e.style.height = _.Jk(d.size.height)),
          _.oo(b, d.size),
          b.appendChild(e),
          _.ev(e, _.Mm),
          _.ro(e),
          (e = e.getContext("2d")),
          (e.lineCap = e.lineJoin = "round"),
          e.scale(c, c),
          (c = new _.SHa(e)),
          e.beginPath(),
          c.Ki(d.WJ, d.anchor.x, d.anchor.y, d.rotation || 0, d.scale),
          d.fillOpacity &&
            ((e.fillStyle = d.fillColor),
            (e.globalAlpha = d.fillOpacity),
            e.fill()),
          d.strokeWeight &&
            ((e.lineWidth = d.strokeWeight),
            (e.strokeStyle = d.strokeColor),
            (e.globalAlpha = d.strokeOpacity),
            e.stroke()),
          _.bE(b, _.Fk(a.get("opacity"), 1)),
          (a = b);
      c = a;
      c.xB = d;
      return c;
    },
    OXa = function (a, b) {
      (a.Vj && a.Oh && a.element === b) ||
        ((a.element = b),
        a.Vj && a.Vj.remove(),
        a.Oh && a.Oh.remove(),
        (a.Vj = _.bw(b, {
          Am(c) {
            a.Qh++;
            _.Nv(c);
            _.Sl(a, "mousedown", c.Hh);
          },
          Qm(c) {
            a.Qh--;
            !a.Qh &&
              a.Wh &&
              _.QD(
                this,
                () => {
                  a.Wh = !1;
                  mN(a);
                  _.Zn(a.Mh);
                },
                0
              );
            _.Pv(c);
            _.Sl(a, "mouseup", c.Hh);
          },
          km: ({ event: c, ks: d }) => {
            if (a.get("clickable") !== !1 || a.getDraggable())
              _.Pu(c.Hh),
                c.button === 3
                  ? d || (c.button === 3 && _.Sl(a, "rightclick", c.Hh))
                  : d
                  ? _.Sl(a, "dblclick", c.Hh)
                  : (_.Sl(a, "click", c.Hh), _.nk(window, 171150));
          },
          Fw: (c) => {
            _.Qv(c);
            _.Sl(a, "contextmenu", c.Hh);
          },
        })),
        (a.Oh = new _.Lz(b, b, {
          jv(c) {
            _.Sl(a, "mouseout", c);
          },
          kv(c) {
            _.Sl(a, "mouseover", c);
          },
        })));
    },
    NXa = function (a, b, c, d) {
      c = c || _.fv("div", b);
      _.Fo(c);
      b === a.getPanes().overlayMouseTarget
        ? ((b = d.element.cloneNode(!0)), _.bE(b, 0), c.appendChild(b))
        : c.appendChild(d.element);
      b = d.getSize();
      c.style.width = _.Fm(b);
      c.style.height = _.Gm(b);
      c.style.pointerEvents = "none";
      c.style.userSelect = "none";
      _.Pl(d, "changed", () => {
        a.Ih();
      });
      return c;
    },
    sN = function (a) {
      var b = a.marker.get("place");
      a = a.marker.get("position");
      return (b && b.location) || a;
    },
    tN = function (a, b) {
      a.Kh &&
        a.Kh.has(b) &&
        (({ marker: a } = a.Kh.get(b)),
        (b.Yo = PXa(a)),
        b.Yo && (b = a.getMap()) && _.nk(b, 184438));
    },
    RXa = function (a, b) {
      if (a.Kh) {
        var { sI: c, marker: d } = a.Kh.get(b);
        for (let e of QXa)
          c.push(
            eXa(d, e, () => {
              tN(a, b);
            })
          ),
            c.push(
              dXa(d, e, () => {
                !PXa(d) && b.Yo && tN(a, b);
              })
            );
      }
    },
    SXa = function (a) {
      var b = a.Ih.__gm;
      a.Hh.bindTo("mapPixelBounds", b, "pixelBounds");
      a.Hh.bindTo("panningEnabled", a.Ih, "draggable");
      a.Hh.bindTo("panes", b);
    },
    TXa = function (a) {
      var b = a.Ih.__gm;
      _.Gl(a.Ph, "dragging_changed", () => {
        b.set("markerDragging", a.marker.get("dragging"));
      });
      b.set(
        "markerDragging",
        b.get("markerDragging") || a.marker.get("dragging")
      );
    },
    VXa = function (a) {
      a.Mh.push(_.Rl(a.Hh, "panbynow", a.Ih.__gm));
      UXa.forEach((b) => {
        a.Mh.push(
          _.Gl(a.Hh, b, (c) => {
            var d = a.Qh ? sN(a) : a.marker.get("internalPosition");
            c = new _.Mz(d, c, a.Hh.get("position"));
            _.Sl(a.marker, b, c);
          })
        );
      });
    },
    WXa = function (a) {
      var b = () => {
        a.marker.get("place")
          ? a.Hh.set("draggable", !1)
          : a.Hh.set("draggable", !!a.marker.get("draggable"));
      };
      a.Mh.push(_.Gl(a.Ph, "draggable_changed", b));
      a.Mh.push(_.Gl(a.Ph, "place_changed", b));
      b();
    },
    XXa = function (a) {
      a.Mh.push(
        _.Gl(a.Ih, "projection_changed", () => {
          uN(a);
        })
      );
      a.Mh.push(
        _.Gl(a.Ph, "position_changed", () => {
          uN(a);
        })
      );
      a.Mh.push(
        _.Gl(a.Ph, "place_changed", () => {
          uN(a);
        })
      );
    },
    ZXa = function (a) {
      a.Mh.push(
        _.Gl(a.Hh, "dragging_changed", () => {
          if (a.Hh.get("dragging"))
            (a.Th = a.Lh.yp()), a.Th && _.wH(a.Lh, a.Th);
          else {
            a.Th = null;
            a.Uh = null;
            var b = a.Lh.getPosition();
            if (b && ((b = _.kp(b, a.Ih.get("projection"))), (b = YXa(a, b)))) {
              let c = _.ov(b, a.Ih.get("projection"));
              a.marker.get("place") ||
                ((a.Sh = !1), a.marker.set("position", b), (a.Sh = !0));
              a.Lh.setPosition(c);
            }
          }
        })
      );
      a.Mh.push(
        _.Gl(a.Hh, "deltaclientposition_changed", () => {
          var b = a.Hh.get("deltaClientPosition");
          if (b && (a.Th || a.Uh)) {
            var c = a.Uh || a.Th;
            a.Uh = {
              clientX: c.clientX + b.clientX,
              clientY: c.clientY + b.clientY,
            };
            b = a.ki.Tn(a.Uh);
            b = _.kp(b, a.Ih.get("projection"));
            c = a.Uh;
            var d = YXa(a, b);
            d &&
              (a.marker.get("place") ||
                ((a.Sh = !1), a.marker.set("position", d), (a.Sh = !0)),
              d.equals(b) ||
                ((b = _.ov(d, a.Ih.get("projection"))), (c = a.Lh.yp(b))));
            c && _.wH(a.Lh, c);
          }
        })
      );
    },
    $Xa = function (a) {
      if (a.Jh) {
        a.Hh.bindTo("scale", a.Jh);
        a.Hh.bindTo("position", a.Jh, "pixelPosition");
        let b = a.Ih.__gm;
        a.Jh.bindTo("latLngPosition", a.marker, "internalPosition");
        a.Jh.bindTo("focus", a.Ih, "position");
        a.Jh.bindTo("zoom", b);
        a.Jh.bindTo("offset", b);
        a.Jh.bindTo("center", b, "projectionCenterQ");
        a.Jh.bindTo("projection", a.Ih);
      }
    },
    bYa = function (a) {
      if (a.Jh) {
        let b = new aYa(a.Ih instanceof _.Xq);
        b.bindTo("internalPosition", a.Jh, "latLngPosition");
        b.bindTo("place", a.marker);
        b.bindTo("position", a.marker);
        b.bindTo("draggable", a.marker);
        a.Hh.bindTo("draggable", b, "actuallyDraggable");
      }
    },
    uN = function (a) {
      if (a.Sh) {
        var b = sN(a);
        b && a.Lh.setPosition(_.ov(b, a.Ih.get("projection")));
      }
    },
    YXa = function (a, b) {
      var c = a.Ih.__gm.get("snappingCallback");
      return c && (a = c({ latLng: b, overlay: a.marker })) ? a : b;
    },
    PXa = function (a) {
      return QXa.some((b) => cXa(a, b));
    },
    dYa = function (a, b, c) {
      if (b instanceof _.gm) {
        let d = b.__gm;
        Promise.all([d.Ih, d.Jh]).then(([{ ki: e }, f]) => {
          cYa(a, b, c, e, f);
        });
      } else cYa(a, b, c, null);
    },
    cYa = function (a, b, c, d, e = !1) {
      var f = new Map(),
        g = (h) => {
          var k = b instanceof _.gm,
            n = k ? _.ja(h.__gm.zt, "map") : h.__gm.zt.streetView,
            p = n && n.Ih === b,
            r = p !== a.contains(h);
          n &&
            r &&
            (k
              ? (_.ja(h.__gm.zt, "map").dispose(), (h.__gm.zt.map = null))
              : (h.__gm.zt.streetView.dispose(),
                (h.__gm.zt.streetView = null)));
          !a.contains(h) ||
            (!k && h.get("mapOnly")) ||
            p ||
            (b instanceof _.gm
              ? ((k = b.__gm),
                (h.__gm.zt.map = new eYa(h, b, c, _.oH(k, h), d, k.Wh, f)))
              : (h.__gm.zt.streetView = new eYa(
                  h,
                  b,
                  c,
                  _.pk,
                  null,
                  null,
                  null
                )),
            tXa(b, h, e));
        };
      _.Gl(a, "insert", g);
      _.Gl(a, "remove", g);
      a.forEach(g);
    },
    vN = function (a) {
      return (
        _.Jv() /
        (a.webkitBackingStorePixelRatio ||
          a.mozBackingStorePixelRatio ||
          a.msBackingStorePixelRatio ||
          a.oBackingStorePixelRatio ||
          a.backingStorePixelRatio ||
          1)
      );
    },
    fYa = function (a, b, c) {
      a = a.Hh;
      a.width = b;
      a.height = c;
      return a;
    },
    gYa = function (a) {
      var b = [];
      a.gk.forEach((c) => {
        b.push(c);
      });
      b.sort((c, d) => c.zIndex - d.zIndex);
      return b;
    },
    hYa = function (a) {
      var b = gYa(a),
        c = a.getContext(),
        d = vN(c);
      a = a.Xi.size;
      c.clearRect(0, 0, Math.ceil(a.oi * d), Math.ceil(a.si * d));
      b.forEach((e) => {
        c.globalAlpha = _.Fk(e.opacity, 1);
        c.drawImage(
          e.image,
          e.AC,
          e.BC,
          e.zC,
          e.uC,
          Math.round(e.dx * d),
          Math.round(e.dy * d),
          e.Ms * d,
          e.Js * d
        );
      });
    },
    iYa = function (a, b, c) {
      if (c.dx > a || c.dy > b || c.dx + c.Ms < a || c.dy + c.Js < b) a = !1;
      else
        a: {
          var d = c.gz.shape;
          a -= c.dx;
          b -= c.dy;
          if (!d) throw Error("Shape cannot be null.");
          c = d.coords || [];
          switch (d.type.toLowerCase()) {
            case "rect":
              a = c[0] <= a && a <= c[2] && c[1] <= b && b <= c[3];
              break a;
            case "circle":
              d = c[2];
              a -= c[0];
              b -= c[1];
              a = a * a + b * b <= d * d;
              break a;
            default:
              (d = c),
                (c = d.length),
                (d[0] == d[c - 2] && d[1] == d[c - 1]) || d.push(d[0], d[1]),
                (a = _.xGa(a, b, d) != 0);
          }
        }
      return a;
    },
    wN = function (a, b, c, d) {
      var e = b.sk,
        f = a.Ih.get();
      if (!f) return null;
      f = f.Xi.size;
      c = _.xH(a.Jh, e, new _.Dm(c, d));
      if (!c) return null;
      a = new _.Dm(c.cw.Gi * f.oi, c.cw.Hi * f.si);
      var g = [];
      c.Sm.gk.forEach((h) => g.push(h));
      g.sort((h, k) => k.zIndex - h.zIndex);
      c = null;
      for (e = 0; (d = g[e]); ++e) {
        f = d.gz;
        if (f.clickable === !1) continue;
        f = f.ID;
        if (iYa(a.x, a.y, d)) {
          c = f;
          break;
        }
      }
      c && (b.Zk = d);
      return c;
    },
    kYa = function (a, b) {
      if (!b.BE) {
        b.BE = !0;
        var c = _.jp(a.get("projection")),
          d = b.rw;
        if (d) {
          d.dx < -64 || d.dy < -64 || d.dx + d.Ms > 64 || d.dy + d.Js > 64
            ? (_.ao(a.Jh, b), (d = a.Ih.search(_.fr)))
            : ((d = b.latLng),
              (d = new _.Dm(d.lat(), d.lng())),
              (b.sk = d),
              eN(a.Kh, { sk: d, marker: b }),
              (d = aXa(a.Ih, d)));
          for (let f = 0, g = d.length; f < g; ++f) {
            var e = d[f];
            let h = e.Sm || null;
            if ((e = jYa(a, h, e.WK || null, b, c)))
              (b.gk[_.Tl(e)] = e), _.ao(h.gk, e);
          }
        }
      }
    },
    lYa = function (a, b) {
      b.BE &&
        ((b.BE = !1),
        (b.XT = !1),
        a.Jh.contains(b)
          ? a.Jh.remove(b)
          : a.Kh.remove({ sk: b.sk, marker: b }),
        _.yk(b.gk, (c, d) => {
          delete b.gk[c];
          d.Sm.gk.remove(d);
        }));
    },
    mYa = function (a, b) {
      a.tiles[_.Tl(b)] = b;
      var c = { Gi: b.ek.x, Hi: b.ek.y, Mi: b.zoom },
        d = _.jp(a.get("projection")),
        e = _.Gw(a.Xi, c);
      e = new _.Dm(e.Hh, e.Ih);
      var { min: f, max: g } = _.eCa(a.Xi, c, 64 / a.Xi.size.oi);
      c = _.Wm(f.Hh, f.Ih, g.Hh, g.Ih);
      oXa(c, d, e, (h, k) => {
        h.WK = k;
        h.Sm = b;
        b.cL[_.Tl(h)] = h;
        _.pH(a.Ih, h);
        var n = (a.Kh.search(h) || []).map((p) => p.marker);
        a.Jh.forEach((p) => {
          n.push(p);
        });
        for (let p = 0, r = n.length; p < r; ++p) {
          k = n[p];
          let u = jYa(a, b, h.WK, k, d);
          u && ((k.gk[_.Tl(u)] = u), _.ao(b.gk, u));
        }
      });
      b.div && b.gk && a.Lh(b.div, b.gk);
    },
    nYa = function (a, b) {
      b &&
        (delete a.tiles[_.Tl(b)],
        b.gk.forEach((c) => {
          b.gk.remove(c);
          delete c.gz.gk[_.Tl(c)];
        }),
        _.yk(b.cL, (c, d) => {
          a.Ih.remove(d);
        }));
    },
    jYa = function (a, b, c, d, e) {
      if (!(e && c && d.latLng && b)) return null;
      var f = e.fromLatLngToPoint(c);
      c = e.fromLatLngToPoint(d.latLng);
      if (!c || !f) return null;
      e = a.Xi.size;
      a = $Wa(a.Xi, new _.wo(c.x, c.y), new _.wo(f.x, f.y), b.zoom);
      c.x = a.Gi * e.oi;
      c.y = a.Hi * e.si;
      a = d.zIndex;
      _.Dk(a) || (a = c.y);
      a = Math.round(a * 1e3) + (Number(_.Tl(d)) % 1e3);
      f = d.rw;
      b = {
        image: f.image,
        AC: f.AC,
        BC: f.BC,
        zC: f.zC,
        uC: f.uC,
        dx: f.dx + c.x,
        dy: f.dy + c.y,
        Ms: f.Ms,
        Js: f.Js,
        zIndex: a,
        opacity: d.opacity,
        Sm: b,
        gz: d,
      };
      return b.dx > e.oi || b.dy > e.si || b.dx + b.Ms < 0 || b.dy + b.Js < 0
        ? null
        : b;
    },
    oYa = function (a) {
      return typeof a === "string"
        ? (xN.has(a) || xN.set(a, { url: a }), xN.get(a))
        : a;
    },
    uYa = function (a, b, c) {
      var d = new _.Wo(),
        e = new _.Wo(),
        f = new pYa();
      new qYa(a, d, new gN(), f, c);
      var g = _.bv(b.getDiv()).createElement("canvas"),
        h = {};
      a = _.Wm(-100, -300, 100, 300);
      var k = new _.dI(a);
      a = _.Wm(-90, -180, 90, 180);
      var n = nXa(a, (y, A) => y.marker === A.marker),
        p = null,
        r = null,
        u = new _.to(null),
        w = b.__gm;
      w.Ih.then((y) => {
        w.Oh.register(new rYa(h, w, u, y.ki.topology));
        _.cu(y.Qv, (A) => {
          if (A && p !== A.Xi) {
            r && r.unbindAll();
            var J = (p = A.Xi);
            r = new sYa(
              h,
              d,
              e,
              function (M, T) {
                return new tYa(T, new yN(M, T, g, J), M);
              },
              k,
              n,
              p
            );
            r.bindTo("projection", b);
            u.set(r.Hh());
          }
        });
      });
      _.yH(b, u, "markerLayer", -1);
    },
    wYa = function (a) {
      a.Dv ||
        (a.Dv = _.RD(() => {
          a.Dv = 0;
          var b = a.by;
          a.by = {};
          var c = a.Cz;
          for (let d of Object.values(b)) vYa(a, d);
          c &&
            !a.Cz &&
            a.aw.forEach((d) => {
              vYa(a, d);
            });
        }));
    },
    vYa = function (a, b) {
      var c = b.get("place");
      c = c ? c.location : b.get("position");
      b.set("internalPosition", c);
      b.changed = a.kP;
      if (!b.get("animating"))
        if (
          (a.fG.remove(b), !c || b.get("visible") == 0 || (b.__gm && b.__gm.kq))
        )
          a.aw.remove(b);
        else {
          a.Cz && !a.tI && a.aw.getSize() >= 256 && (a.Cz = !1);
          c = b.get("optimized");
          let e = b.get("draggable"),
            f = !!b.get("animation");
          var d = b.get("icon");
          let g = !!d && d.path != null;
          d = aN(d);
          let h = b.get("label") != null;
          a.tI || c == 0 || e || f || g || d || h || (!c && a.Cz)
            ? _.ao(a.aw, b)
            : (a.aw.remove(b), _.ao(a.fG, b));
        }
    },
    xYa = function (a, b) {
      var c = new _.Nn();
      c.onAdd = () => {};
      c.onContextLost = () => {};
      c.onRemove = () => {};
      c.onContextRestored = () => {};
      c.onDraw = ({ transformer: d }) => {
        a.onDraw(d);
      };
      _.Gr.add(c);
      c.setMap(b);
      return c;
    },
    yYa = function (a) {
      a.Nh ||
        (a.Nh = setTimeout(() => {
          var b = [...a.Kh].filter((c) => !c.nr).length;
          b > 0 && a.Li.Zh(a.map, b);
          a.Nh = 0;
        }, 0));
    },
    BYa = function (a, b) {
      a.Lh.has(b) ||
        (a.Lh.add(b),
        _.pv(_.qv(), () => {
          if (a.map) {
            var c = [];
            for (let d of a.Lh) {
              if (!_.ja(d, "map")) continue;
              let e = d.targetElement;
              e.parentNode || c.push(d);
              let f = (d.kq !== !1 && zN(d)) || d.ft,
                g = _.hm(a.map);
              g ||
                (a.Oh ||
                  ((a.Oh = a.Ih.attachShadow({
                    mode: _.jo[166] ? "open" : "closed",
                  })),
                  a.Oh.append(a.Mh, a.Hh)),
                a.Ih.append(e));
              (g && e.parentElement === g) || (!g && e.parentElement === a.Ih)
                ? e.setAttribute("slot", f ? zYa : AYa)
                : (e.style.visibility = f ? "hidden" : "");
              d.ho(!f);
              d.iz = !1;
            }
            a.Lh.clear();
            for (let d of c) d.Ev(!0);
          }
        }));
    },
    CYa = function (a) {
      AN ||
        (AN = new ResizeObserver((b) => {
          for (let c of b)
            c.target.dispatchEvent(
              new CustomEvent("gmp-internal-marker-resize", {
                detail: c.contentRect,
              })
            );
        }));
      AN.observe(a);
    },
    FYa = function (a, b) {
      var c = _.Sa(b),
        d = BN.get(c);
      d || ((d = new DYa(b)), BN.set(c, d));
      b = d;
      EYa(a, b.qp);
      b.Kh.add(a);
      yYa(b);
      CYa(a.targetElement);
    },
    GYa = function (a) {
      a = _.Sa(a);
      (a = BN.get(a)) && a.requestRedraw();
    },
    HYa = function (a, b) {
      b = _.Sa(b);
      (b = BN.get(b)) && BYa(b, a);
    },
    IYa = function (a) {
      var b = 0,
        c = 0;
      for (let d of a)
        switch (d) {
          case "ArrowLeft":
            --b;
            break;
          case "ArrowRight":
            b += 1;
            break;
          case "ArrowDown":
            c += 1;
            break;
          case "ArrowUp":
            --c;
        }
      return { deltaX: b, deltaY: c };
    },
    DN = function (a, b, c = !0) {
      a.Hh.position = a.Uh;
      CN(a, b, c);
    },
    CN = function (a, b, c = !0) {
      b.preventDefault();
      b.stopImmediatePropagation();
      EN(a);
      JYa(a);
      a.Ih && (a.Ih.release(), (a.Ih = null));
      c && FN(a, "dragend", b);
    },
    GN = function (a, b) {
      if (b) {
        a.Jh.style.display = "";
        b = a.Hh.anchorTop || "-100%";
        let c = a.Hh.anchorLeft || "-50%";
        b === "0" && (b = "0px");
        c === "0" && (c = "0px");
        a.Jh.style.left = `calc(-1 * ${c})`;
        a.Jh.style.top = `calc(-1 * ${b})`;
      } else a.Jh.style.display = "none";
    },
    LYa = function (a) {
      a.Jh.style.opacity = "0.5";
      a.Jh.style.position = "absolute";
      GN(a, !1);
      a.Jh.style.transform = "translate(-50%, -50%)";
      a.Jh.style.zIndex = "-1";
      KYa(a);
      var b = a.Hh.cq;
      b.addEventListener("pointerenter", a.ai);
      b.addEventListener("pointerleave", a.ci);
      b.addEventListener("focus", a.ai);
      b.addEventListener("blur", a.ci);
    },
    MYa = function (a, b = !1) {
      return a.Kh ? _.rx : b ? "pointer" : _.Bpa;
    },
    HN = function (a) {
      var b = a.Hh.Yj;
      b && b.appendChild(a.Jh);
    },
    KYa = function (a) {
      a.Jh.children[0]?.remove();
      var b = a.Hh,
        c;
      if (!(c = b.dragIndicator)) {
        if (!b.Xx) {
          let { url: d, scaledSize: e } = new gN().Hh;
          b.Xx = new Image(e.width, e.height);
          b.Xx.src = d;
          b.Xx.alt = "";
        }
        c = b.Xx;
      }
      a.Jh.appendChild(c);
      HN(a);
    },
    OYa = function (a) {
      if (!a.Hh.zD) {
        a.Ih = new _.eI((c, d) => {
          var e = a.Hh;
          e.Zi && _.Sl(e.Zi, "panbynow", c, d);
        });
        _.vH(a.Ih, !0);
        var b = NYa(a.Hh);
        _.uH(a.Ih, b);
        a.Ih.Kh = a.Lh;
      }
    },
    PYa = function (a, b) {
      EN(a);
      a.Lh = !1;
      a.Ih && (a.Ih.Kh = !1);
      a.Mh = a.Hh.yp();
      a.Qh = _.TG(b);
    },
    QYa = function (a, b) {
      var c = _.TG(b);
      if (c) {
        b = c.clientX;
        c = c.clientY;
        var d = b - a.Qh.clientX,
          e = c - a.Qh.clientY;
        a.Qh = { clientX: b, clientY: c };
        b = { clientX: a.Mh.clientX + d, clientY: a.Mh.clientY + e };
        a.Mh = b;
        a.Hh.VF(b);
      }
    },
    FN = function (a, b, c) {
      RYa(a.Hh, b, c);
      a.Hh.cq.dispatchEvent(new Event(`gmp-${b}`, { bubbles: !0 }));
    },
    SYa = function (a, b) {
      a.Mh = a.Hh.yp();
      a.Uh = a.Hh.position;
      a.Qh = _.TG(b);
      a.Kh = !0;
      OYa(a);
      a.Hh.cq.setAttribute("aria-grabbed", "true");
      IN(a.Hh);
      a.Hh.cq.style.zIndex = "2147483647";
      a.Jh.style.opacity = "1";
      GN(a, !0);
      FN(a, "dragstart", b);
    },
    TYa = function (a) {
      a.Lh && (a.Mh = a.Hh.yp());
    },
    JN = function (a) {
      var b = a.ri;
      _.aw !== 2
        ? (b.removeEventListener("pointermove", a.Vh),
          b.removeEventListener("pointerup", a.Oh),
          b.removeEventListener("pointercancel", a.Oh))
        : (b.removeEventListener("touchmove", a.Vh, { passive: !1 }),
          b.removeEventListener("touchend", a.Oh),
          b.removeEventListener("touchcancel", a.Oh),
          b.removeEventListener("touchstart", a.Oh));
      EN(a);
      JYa(a);
      a.Ih && (a.Ih.release(), (a.Ih = null));
    },
    EN = function (a) {
      var b = a.Hh.cq;
      b.removeEventListener("keydown", a.Ai);
      b.removeEventListener("keyup", a.Bi);
      b.removeEventListener("blur", a.wi);
    },
    UYa = function (a) {
      if (a.Th.size === 0) a.Sh = 0;
      else {
        var { deltaX: b, deltaY: c } = IYa(a.Th),
          d = 1;
        _.bH(a.bi) && (d = a.bi.next());
        var e = Math.round(3 * d * b);
        d = Math.round(3 * d * c);
        e === 0 && (e = b);
        d === 0 && (d = c);
        e = { clientX: a.Mh.clientX + e, clientY: a.Mh.clientY + d };
        a.Mh = e;
        a.Hh.VF(e);
        a.Sh = window.setTimeout(() => {
          UYa(a);
        }, 10);
      }
    },
    JYa = function (a) {
      a.Kh = !1;
      a.Lh = !1;
      a.Qh = null;
      a.Mh = null;
      clearTimeout(a.Sh);
      a.Sh = 0;
      a.Uh = null;
      a.Zh = null;
      a.Ph = null;
      var b = a.Hh.cq,
        c = a.Hh.zIndex;
      a.Jh.style.opacity = "0.5";
      b.setAttribute("aria-grabbed", "false");
      b.style.zIndex = c == null ? "" : `${c}`;
      VYa(a.Hh);
    },
    EYa = function (a, b) {
      a.CD = b;
      if (a.yx) {
        var c = a.getAttribute("aria-describedby");
        c = c ? c.split(" ") : [];
        c.push(b);
        a.setAttribute("aria-describedby", c.join(" "));
      }
    },
    zN = function (a) {
      return (
        a.collisionBehavior !== "REQUIRED" &&
        !a.zl &&
        !!_.ja(a, "map") &&
        !!a.position
      );
    },
    NYa = function (a) {
      return a.Zi ? a.Zi.get("pixelBounds") : null;
    },
    IN = function (a) {
      _.Sl(a, "REMOVE_COLLISION");
    },
    VYa = function (a) {
      a.style.cursor = a.wk ? MYa(a.wk, a.Py) : a.Py ? "pointer" : "";
    },
    KN = function (a, b = !1) {
      zN(a) &&
        (a.Zi && ZWa(a.Zi.bi, a),
        _.Sl(a, "UPDATE_MARKER_COLLISION"),
        b && a.nA && _.Sl(a, "UPDATE_BASEMAP_COLLISION"));
    },
    RYa = function (a, b, c) {
      _.Sl(a, b, new _.Mz(a.qr, c, a.Xy ? new _.Dm(a.Xy.oi, a.Xy.si) : null));
    },
    WYa = function (a) {
      a.mp.then(() => {
        _.qp(a, "marker-view");
        a.style.position = "absolute";
        a.style.left = "0px";
      });
    },
    XYa = function (a) {
      if (a.Ao.get("isOpen")) {
        var { width: b } = a.getBoundingClientRect();
        a.Ao.set("anchorPoint", new _.Dm(b ? b / 2 : 0, 0));
      }
    },
    LN = function (a) {
      a.style.pointerEvents = a.FB ? "none" : a.BB ? "auto" : "";
      YYa(a);
    },
    MN = function (a) {
      a.Yo = a.Py || !!a.yx;
    },
    ZYa = function (a, b = !1) {
      if (a.ft || !a.Ml) a.Ao.set("pixelPosition", null);
      else if (a.Ao.get("isOpen"))
        if (b)
          requestAnimationFrame(() => {
            var { offsetX: c, offsetY: d } = cN(a.NA);
            a.Ao.set("pixelPosition", new _.Dm(c, d));
          });
        else {
          let { offsetX: c, offsetY: d } = cN(a.NA);
          a.Ao.set("pixelPosition", new _.Dm(c, d));
        }
    },
    $Ya = function (a, b) {
      var c;
      if ((c = a.wk))
        (c = a.wk), (c = c.Ph && b.timeStamp - c.Ph >= 500 ? !0 : c.Nh);
      if (!c && a.qr) {
        a.gmpDraggable || a.focus();
        RYa(a, "click", b);
        if (a.gmpClickable || _.Hl(a, "gmp-click"))
          (c = new NN()), _.Sl(a, "gmp-click", c), a.dispatchEvent(c);
        a.Li.Oh(b);
      }
    },
    ON = function (a) {
      if (!a.Vj && _.ja(a, "map") && a.Zi) {
        var b = a.BB ? a : a.Yj ?? null;
        b &&
          ((a.aG = !0),
          (a.Vj = _.bw(
            b,
            {
              km: ({ event: c, ks: d }) => {
                a.BB
                  ? (_.Pu(c.Hh), c.button === 3 || d || $Ya(a, c.Hh))
                  : a === c.Hh.target ||
                    a.FB ||
                    (console.debug(
                      'To make AdvancedMarkerElement clickable and provide better accessible experiences, use addListener() to register a "click" event on the AdvancedMarkerElement instance.'
                    ),
                    a.Li.Qh(_.ja(a, "map")));
              },
            },
            a
          )),
          (a.OD = b),
          (a.br = _.Ipa({
            draggable: a.UI,
            YH: new _.cA(_.ja(a, "map"), "gestureHandling"),
            im: a.Zi.An,
            Qr: a,
          })),
          _.cu(a.br, a.wI),
          (a.aG = !1));
      }
    },
    aZa = function (a) {
      a.br?.removeListener(a.wI);
      a.Vj && (a.Vj.remove(), (a.Vj = null));
      a.OD = null;
    },
    YYa = function (a) {
      a.OD !== (a.BB ? a : a.Yj ?? null) && (aZa(a), ON(a));
    },
    PN = function (a) {
      var b = (c) =>
        c.nodeType === Node.TEXT_NODE &&
        c.nodeValue != null &&
        !/\S/.test(c.nodeValue);
      return a.childNodes.length > 0
        ? ([...a.childNodes].every(b) &&
            _.wl(
              _.yn(
                a,
                "AdvancedMarkerElement is displaying empty text content. If you want a pin to appear, make sure to remove any whitespace between the <gmp-advanced-marker> tags."
              )
            ),
          [...a.childNodes])
        : a.fm && a.fm.contains(a.wn)
        ? [a.wn]
        : [];
    },
    bZa = function (a, b, c) {
      if (b && c && (({ altitude: b } = new _.fn(b)), b > 0 || b < 0))
        throw (
          (a.Li.Sh(window),
          _.Uk(
            "Draggable AdvancedMarkerElement with non-zero altitude is not supported"
          ))
        );
    },
    QN = function (a) {
      if (a.Gl) {
        let b = _.Sa(a.Gl),
          c = BN.get(b);
        c && (c.Kh.delete(a), c.isEmpty() && (c.dispose(), BN.delete(b)));
        AN && AN.unobserve(a.targetElement);
        _.Sl(a, "REMOVE_FOCUS");
        _.Sl(a, "REMOVE_COLLISION");
        a.ki && (a.Al && (a.ki.Rm(a.Al), (a.Al = null)), (a.ki = null));
        a.wk && JN(a.wk);
        a.sH?.remove();
        a.vL?.remove();
        a.bK?.remove();
        a.zJ?.remove();
        aZa(a);
        a.Ao.set("map", null);
        a.nA = null;
        a.Zi = null;
        a.Gl = null;
        a.iz = !0;
      }
    },
    RN = function (a) {
      if (a.Zi && !a.zl) {
        var b = a.Zi.Wh;
        b &&
          (a.Yo && a.Ml && !a.kq
            ? a.Ru
              ? b.bi(a)
              : a.mp.then(() => {
                  RN(a);
                })
            : _.Sl(a, "REMOVE_FOCUS"));
      }
    },
    dZa = function (a) {
      var b = a.Zi.get("baseMapType");
      b = b && (!b.mapTypeId || !Object.values(_.vq).includes(b.mapTypeId));
      a.nA = a.fJ && !b;
      if (!a.nr || a.position) a.nA ? GYa(_.ja(a, "map")) : cZa(a);
    },
    eZa = function (a) {
      if (!a.nr) {
        var b = a.Zi.Hh;
        b.RE.then(() => {
          var c = _.Jn(b, "ADVANCED_MARKERS");
          if (!c.isAvailable) {
            a.Zi && a.Zi.Bi();
            for (let d of c.Hh) b.log(d);
            a.Li.Ph(_.ja(a, "map"));
            a.dispose();
          }
        });
      }
    },
    fZa = function (a) {
      a.Li.ai(_.ja(a, "map"));
      a.Li.Kh(_.ja(a, "map"), a.FB);
      if (a.Py) {
        let b = _.Hl(a, "gmp-click");
        a.Li.Ih(_.ja(a, "map"), b);
      }
      a.gmpDraggable && a.Li.Lh(_.ja(a, "map"));
      a.title && a.Li.Mh(_.ja(a, "map"));
      a.zIndex !== null && a.Li.Nh(_.ja(a, "map"));
      a.an() > 0 && a.Li.Hh(_.ja(a, "map"));
      a.Li.Jh(_.ja(a, "map"), a.collisionBehavior);
    },
    SN = function (a, b) {
      a.wk && TYa(a.wk);
      if (b) {
        a.style.transform = `${`translate(${a.anchorLeft || "-50%"}, ${
          a.anchorTop || "-100%"
        })`} ${`translate(${b.x}px, ${b.y}px)`}`;
        let c = a.style.willChange
          ? a.style.willChange.replace(/\s+/g, "").split(",")
          : [];
        c.includes("transform") ||
          _.pv(
            _.qv(),
            () => {
              c.push("transform");
              a.style.willChange = c.join(",");
            },
            a,
            a
          );
      }
      a.PG = b ? Math.round(b.y) : null;
      gZa(a);
      a.Ml = b;
      RN(a);
    },
    gZa = function (a) {
      a.style.zIndex = a.QC != null ? `${a.QC}` : a.PG != null ? `${a.PG}` : "";
    },
    cZa = function (a) {
      var b = kXa(a.Gl, a.qr);
      a.Al
        ? a.Al.setPosition(b, a.an())
        : a.ki &&
          ((b = new _.gI(a.ki.topology, a, b, a.ki, null, a.an(), a.DN)),
          a.ki.lk(b),
          (a.Al = b));
    };
  _.Dm.prototype.PB = _.ha(20, function () {
    return Math.sqrt(this.x * this.x + this.y * this.y);
  });
  var QXa = ["click", "dblclick", "rightclick", "contextmenu"],
    hZa = class extends _.Ul {
      constructor() {
        super();
        this.constraint = 0;
        this.Hh = !1;
      }
      position_changed() {
        this.Hh ||
          ((this.Hh = !0),
          this.set("rawPosition", this.get("position")),
          (this.Hh = !1));
      }
      rawPosition_changed() {
        if (!this.Hh) {
          this.Hh = !0;
          var a = this.set,
            b;
          var c = this.get("rawPosition");
          if (c) {
            (b = this.get("snappingCallback")) && (c = b(c));
            b = c.x;
            c = c.y;
            var d = this.get("referencePosition");
            d &&
              (this.constraint === 2
                ? (b = d.x)
                : this.constraint === 1 && (c = d.y));
            b = new _.Dm(b, c);
          } else b = null;
          a.call(this, "position", b);
          this.Hh = !1;
        }
      }
    },
    iZa = class {
      constructor(a, b, c, d, e = 0, f = 0) {
        this.width = c;
        this.height = d;
        this.offsetX = e;
        this.offsetY = f;
        this.Ih = new Float64Array(2);
        this.Ih[0] = a;
        this.Ih[1] = b;
        this.Hh = new Float32Array(2);
      }
      transform(a) {
        a.ox(1, this.Ih, this.Hh, 0, 0, 0);
        this.Hh[0] += this.offsetX;
        this.Hh[1] += this.offsetY;
      }
      isVisible(a) {
        return (
          this.Hh[0] >= -this.width &&
          this.Hh[0] <= a.width + this.width &&
          this.Hh[1] >= -this.height &&
          this.Hh[1] <= a.height + this.height
        );
      }
      equals(a) {
        return (
          this.Ih[0] === a.Ih[0] &&
          this.Ih[1] === a.Ih[1] &&
          this.width === a.width &&
          this.height === a.height &&
          this.offsetX === a.offsetX &&
          this.offsetY === a.offsetY
        );
      }
      Jh(a) {
        return !(
          this.Hh[0] > a.right ||
          this.Hh[0] + this.width < a.left ||
          this.Hh[1] > a.bottom ||
          this.Hh[1] + this.height < a.top
        );
      }
    },
    mXa = class {
      constructor(a, b, c = 0) {
        this.bounds = a;
        this.Hh = b;
        this.depth = c;
        this.children = null;
        this.items = [];
      }
      remove(a) {
        if (this.bounds.containsPoint(a.sk))
          if (this.children)
            for (let b = 0; b < 4; ++b) this.children[b].remove(a);
          else (a = this.Hh.bind(null, a)), _.iea(this.items, a, 1);
      }
      search(a, b) {
        b = b || [];
        if (!_.Xm(this.bounds, a)) return b;
        if (this.children)
          for (var c = 0; c < 4; ++c) this.children[c].search(a, b);
        else if (this.items)
          for (let d = 0, e = this.items.length; d < e; ++d)
            (c = this.items[d]), a.containsPoint(c.sk) && b.push(c);
        return b;
      }
      split() {
        var a = this.bounds,
          b = [];
        this.children = b;
        var c = [a.minX, (a.minX + a.maxX) / 2, a.maxX];
        a = [a.minY, (a.minY + a.maxY) / 2, a.maxY];
        var d = this.depth + 1;
        for (let e = 0; e < 4; ++e) {
          let f = _.Wm(c[e & 1], a[e >> 1], c[(e & 1) + 1], a[(e >> 1) + 1]);
          b.push(new mXa(f, this.Hh, d));
        }
        b = this.items;
        delete this.items;
        for (let e = 0, f = b.length; e < f; ++e) eN(this, b[e]);
      }
      clear() {
        this.children = null;
        this.items = [];
      }
    };
  var AXa = {
      linear: (a) => a,
      ["ease-out"]: (a) => 1 - Math.pow(a - 1, 2),
      ["ease-in"]: (a) => Math.pow(a, 2),
    },
    TN = class {
      constructor(a) {
        this.frames = a;
        this.Hh = "";
      }
    },
    fN;
  var LXa = {
    [1]: {
      options: { duration: 700, Do: "infinite" },
      icon: new TN([
        { time: 0, translate: [0, 0], Po: "ease-out" },
        { time: 0.5, translate: [0, -20], Po: "ease-in" },
        { time: 1, translate: [0, 0], Po: "ease-out" },
      ]),
    },
    [2]: {
      options: { duration: 500, Do: 1 },
      icon: new TN([
        { time: 0, translate: [0, -500], Po: "ease-in" },
        { time: 0.5, translate: [0, 0], Po: "ease-out" },
        { time: 0.75, translate: [0, -20], Po: "ease-in" },
        { time: 1, translate: [0, 0], Po: "ease-out" },
      ]),
    },
    [3]: {
      options: { duration: 200, PB: 20, Do: 1, fL: !1 },
      icon: new TN([
        { time: 0, translate: [0, 0], Po: "ease-in" },
        { time: 1, translate: [0, -20], Po: "ease-out" },
      ]),
    },
    [4]: {
      options: { duration: 500, PB: 20, Do: 1, fL: !1 },
      icon: new TN([
        { time: 0, translate: [0, -20], Po: "ease-in" },
        { time: 0.5, translate: [0, 0], Po: "ease-out" },
        { time: 0.75, translate: [0, -10], Po: "ease-in" },
        { time: 1, translate: [0, 0], Po: "ease-out" },
      ]),
    },
  };
  var gN = class {
    constructor() {
      this.icon = {
        url: _.Kv("api-3/images/spotlight-poi3", !0),
        scaledSize: new _.Hm(26, 37),
        origin: new _.Dm(0, 0),
        anchor: new _.Dm(13, 37),
        labelOrigin: new _.Dm(13, 14),
      };
      this.Ih = {
        url: _.Kv("api-3/images/spotlight-poi-dotless3", !0),
        scaledSize: new _.Hm(26, 37),
        origin: new _.Dm(0, 0),
        anchor: new _.Dm(13, 37),
        labelOrigin: new _.Dm(13, 14),
      };
      this.Hh = {
        url: _.Kv("api-3/images/drag-cross", !0),
        scaledSize: new _.Hm(13, 11),
        origin: new _.Dm(0, 0),
        anchor: new _.Dm(7, 6),
      };
      this.shape = {
        coords: [
          13, 0, 4, 3.5, 0, 12, 2.75, 21, 13, 37, 23.5, 21, 26, 12, 22, 3.5,
        ],
        type: "poly",
      };
    }
  };
  var jZa = class extends _.Ul {
      constructor(a, b) {
        super();
        this.Ih = a;
        this.Hh = b;
        UN || (UN = new gN());
      }
      changed(a) {
        (a !== "modelIcon" &&
          a !== "modelShape" &&
          a !== "modelCross" &&
          a !== "modelLabel") ||
          _.pv(_.qv(), this.Jh, this, this);
      }
      Jh() {
        var a = this.get("modelIcon"),
          b = this.get("modelLabel");
        vXa(this, "viewIcon", a || (b && UN.Ih) || UN.icon);
        vXa(this, "viewCross", UN.Hh);
        b = this.get("useDefaults");
        var c = this.get("modelShape");
        c || (a && !b) || (c = UN.shape);
        this.get("viewShape") !== c && this.set("viewShape", c);
      }
    },
    UN;
  var kZa = class extends _.Ul {
    constructor() {
      super();
      this.Ih = !1;
      this.Hh = wXa(this);
      this.set("shouldRender", this.Hh);
    }
    changed() {
      if (!this.Ih) {
        var a = wXa(this);
        this.Hh !== a &&
          ((this.Hh = a),
          (this.Ih = !0),
          this.set("shouldRender", this.Hh),
          (this.Ih = !1));
      }
    }
  };
  var aYa = class extends _.Ul {
    constructor(a) {
      super();
      this.Ih = a;
      this.Hh = !1;
    }
    internalPosition_changed() {
      if (!this.Hh) {
        this.Hh = !0;
        var a = this.get("position"),
          b = this.get("internalPosition");
        a &&
          b &&
          !a.equals(b) &&
          this.set("position", this.get("internalPosition"));
        this.Hh = !1;
      }
    }
    draggable_changed() {
      if (!this.Hh) {
        this.Hh = !0;
        if (this.Ih) {
          let a = this.get("place");
          a
            ? this.set("internalPosition", a.location)
            : this.set("internalPosition", this.get("position"));
        }
        this.get("place")
          ? this.set("actuallyDraggable", !1)
          : this.set("actuallyDraggable", this.get("draggable"));
        this.Hh = !1;
      }
    }
    position_changed() {
      this.draggable_changed();
    }
    place_changed() {
      this.draggable_changed();
    }
  };
  var HXa = class {
    constructor(a, b, c, d, e) {
      this.Gn = a;
      this.label = b;
      this.opacity = c;
      this.visible = d;
      this.origin = void 0;
      this.zIndex = 0;
      this.Kh = this.Lh = this.Hh = null;
      this.Ih = new _.Yn(this.Mh, 0, this);
      this.Jh = e;
      this.Gn = a;
      this.label = b;
      this.opacity = c;
      this.visible = d;
    }
    setOpacity(a) {
      this.opacity = a;
      this.Ih.Hh();
    }
    setLabel(a) {
      this.label = a;
      this.Ih.Hh();
    }
    setVisible(a) {
      this.visible = a;
      this.Ih.Hh();
    }
    setZIndex(a) {
      this.zIndex = a;
      this.Ih.Hh();
    }
    release() {
      this.Gn = null;
      hN(this);
    }
    Mh() {
      if (this.Gn && this.label && this.visible !== !1) {
        var a = this.Gn.markerLayer,
          b = this.label;
        this.Hh
          ? a.appendChild(this.Hh)
          : ((this.Hh = document.createElement("div")),
            a.appendChild(this.Hh),
            (this.Hh.style.transform = "translateZ(0)"));
        a = this.Hh;
        this.origin && _.ev(a, this.origin);
        var c = a.firstElementChild;
        c ||
          ((c = document.createElement("div")),
          a.appendChild(c),
          (c.style.height = "100px"),
          (c.style.transform = "translate(-50%, -50px)"),
          (c.style.display = "table"),
          (c.style.borderSpacing = "0"));
        let d = c.firstElementChild;
        d ||
          ((d = document.createElement("div")),
          c.appendChild(d),
          (d.style.display = "table-cell"),
          (d.style.verticalAlign = "middle"),
          (d.style.whiteSpace = "nowrap"),
          (d.style.textAlign = "center"));
        c = d.firstElementChild || _.fv("div", d);
        c.textContent = b.text;
        c.style.color = b.color;
        c.style.fontSize = b.fontSize;
        c.style.fontWeight = b.fontWeight;
        c.style.fontFamily = b.fontFamily;
        c.className = b.className;
        c.setAttribute("aria-hidden", "true");
        if (this.Jh && b !== this.Kh) {
          this.Kh = b;
          let { width: e, height: f } = c.getBoundingClientRect();
          b = new _.Hm(e, f);
          b.equals(this.Lh) || ((this.Lh = b), this.Jh(b));
        }
        _.bE(c, _.Fk(this.opacity, 1));
        _.gv(a, this.zIndex);
      } else hN(this);
    }
  };
  var CXa = class {
    constructor(a, b, c) {
      this.element = a;
      this.animation = b;
      this.options = c;
      this.Ih = !1;
      this.Hh = null;
    }
    start() {
      this.options.Do = this.options.Do || 1;
      this.options.duration = this.options.duration || 1;
      _.Nl(this.element, "webkitAnimationEnd", () => {
        this.Ih = !0;
        _.Sl(this, "done");
      });
      yXa(this.element, rXa(this.animation), this.options);
    }
    cancel() {
      this.Hh && (this.Hh.remove(), (this.Hh = null));
      yXa(this.element, null, {});
      _.Sl(this, "done");
    }
    stop() {
      this.Ih ||
        (this.Hh = _.Nl(this.element, "webkitAnimationIteration", () => {
          this.cancel();
        }));
    }
  };
  var iN = [],
    jN = null,
    DXa = class {
      constructor(a, b, c) {
        this.element = a;
        this.animation = b;
        this.Do = -1;
        this.Hh = !1;
        this.startTime = 0;
        c.Do !== "infinity" && (this.Do = c.Do || 1);
        this.duration = c.duration || 1e3;
      }
      start() {
        iN.push(this);
        jN || (jN = window.setInterval(zXa, 10));
        this.startTime = Date.now();
        this.tick();
      }
      cancel() {
        this.Hh || ((this.Hh = !0), BXa(this, 1), _.Sl(this, "done"));
      }
      stop() {
        this.Hh || (this.Do = 1);
      }
      tick() {
        if (!this.Hh) {
          var a = Date.now();
          BXa(this, (a - this.startTime) / this.duration);
          a >= this.startTime + this.duration &&
            ((this.startTime = Date.now()),
            this.Do !== "infinite" && (this.Do--, this.Do || this.cancel()));
        }
      }
    };
  var lZa = _.wa.DEF_DEBUG_MARKERS,
    VN = class extends _.Ul {
      constructor(a, b, c) {
        super();
        this.Lh = this.Hh = null;
        this.wi = [];
        this.ii = !1;
        this.targetElement = null;
        this.ri = !1;
        this.Kh = null;
        this.elements = [];
        this.Vh = !0;
        this.Qh = 0;
        this.Jh = this.mi = this.Bi = this.Ai = null;
        this.Wh = !1;
        this.element = this.Oh = this.Vj = this.Nh = this.Ph = this.Sh = null;
        this.ai = !1;
        this.Vr = null;
        this.Mh = new _.Yn(() => {
          var d = this.get("panes"),
            e = this.get("scale");
          if (
            !d ||
            !this.getPosition() ||
            this.getVisible() === !1 ||
            (_.Dk(e) && e < 0.1 && !this.zl)
          )
            nN(this);
          else {
            GXa(this, d.markerLayer);
            if (!this.Qh) {
              var f = this.getIcon();
              if (f) {
                var g = f.url;
                e = oN(this);
                var h = this.getDraggable(),
                  k = this.get("title") || "",
                  n = k;
                n || (n = (n = this.getLabel()) ? n.text : "");
                if (e || h || n) {
                  var p = !e && !h && !k,
                    r = aN(f),
                    u = rN(f),
                    w = this.get("shape"),
                    y = bN(f),
                    A = {};
                  if (_.iv())
                    (f = y.width),
                      (y = y.height),
                      (r = new _.Hm(f + 16, y + 16)),
                      (f = {
                        url: _.Iz,
                        size: r,
                        anchor: u
                          ? new _.Dm(u.x + 8, u.y + 8)
                          : new _.Dm(Math.round(f / 2) + 8, y + 8),
                        scaledSize: r,
                      });
                  else {
                    let J = f.scaledSize || y;
                    (_.lo.Lh || _.lo.Hh) && w && ((A.shape = w), (y = J));
                    if (!r || w)
                      f = { url: _.Iz, size: y, anchor: u, scaledSize: J };
                  }
                  u = f.url != null;
                  this.ri === u && mN(this);
                  this.ri = !u;
                  A = this.targetElement = pN(
                    this,
                    this.getPanes().overlayMouseTarget,
                    this.targetElement,
                    f,
                    A
                  );
                  this.targetElement.style.pointerEvents = p ? "none" : "";
                  if ((p = A.querySelector("img")))
                    p.style.removeProperty("position"),
                      p.style.removeProperty("opacity"),
                      p.style.removeProperty("left"),
                      p.style.removeProperty("top");
                  u = A;
                  p = null;
                  (f =
                    u.getAttribute("usemap") ||
                    (u.firstChild && u.firstChild.getAttribute("usemap"))) &&
                    f.length &&
                    (u = _.bv(u).getElementById(f.substring(1))) &&
                    (p = u.firstChild);
                  p &&
                    ((p.tabIndex = -1),
                    (p.style.display = "inline"),
                    (p.style.position = "absolute"),
                    (p.style.left = "0px"),
                    (p.style.top = "0px"));
                  lZa && (A.dataset.debugMarkerImage = g);
                  A = p || A;
                  A.title = k;
                  n && this.Zr().setAttribute("aria-label", n);
                  this.Wz();
                  h &&
                    !this.Nh &&
                    ((g = this.Nh = new _.THa(A, this.Th, this.targetElement)),
                    this.Th
                      ? (g.bindTo("deltaClientPosition", this),
                        g.bindTo("position", this))
                      : g.bindTo("position", this.Uh, "rawPosition"),
                    g.bindTo("containerPixelBounds", this, "mapPixelBounds"),
                    g.bindTo("anchorPoint", this),
                    g.bindTo("size", this),
                    g.bindTo("panningEnabled", this),
                    this.Sh ||
                      (this.Sh = [
                        _.Rl(g, "dragstart", this),
                        _.Rl(g, "drag", this),
                        _.Rl(g, "dragend", this),
                        _.Rl(g, "panbynow", this),
                      ]));
                  g = this.get("cursor") || "pointer";
                  h
                    ? this.Nh.set("draggableCursor", g)
                    : (A.style.cursor = e ? g : "");
                  OXa(this, A);
                }
              }
            }
            d = d.overlayLayer;
            if ((h = e = this.get("cross")))
              (h = this.get("crossOnDrag")),
                h === void 0 && (h = this.get("raiseOnDrag")),
                (h = h !== !1 && this.getDraggable() && this.zl);
            h
              ? (this.Kh = pN(this, d, this.Kh, e))
              : (this.Kh && _.mv(this.Kh), (this.Kh = null));
            this.elements = [this.Hh, this.Kh, this.targetElement];
            KXa(this);
            for (e = 0; e < this.elements.length; ++e)
              if ((h = this.elements[e]))
                (d = h),
                  (g = h.xB),
                  (k = kN(h) || _.Mm),
                  (h = qN(this)),
                  (g = IXa(this, g, h, k)),
                  _.ev(d, g),
                  (g = _.no().transform) &&
                    d.style.setProperty(g, h !== 1 ? `scale(${h}) ` : ""),
                  d && _.gv(d, JXa(this));
            MXa(this);
            for (d = 0; d < this.elements.length; ++d)
              (e = this.elements[d]) && _.$D(e);
            _.Sl(this, "UPDATE_FOCUS");
          }
        }, 0);
        this.bi = a;
        this.Vi = c;
        this.Th = b || !1;
        this.Uh = new hZa();
        this.Uh.bindTo("position", this);
        this.Zh = new _.Dm(0, 0);
        this.size = new _.Hm(0, 0);
        this.anchorPoint = new _.Dm(0, 0);
        this.ei = [
          _.Gl(this, "dragstart", this.Ni),
          _.Gl(this, "dragend", this.Ci),
          _.Gl(this, "panbynow", () => {
            _.Zn(this.Mh);
          }),
        ];
        this.getPosition = _.vm("position");
        this.getPanes = _.vm("panes");
        this.getVisible = _.vm("visible");
        this.getIcon = _.vm("icon");
        this.getLabel = _.vm("label");
      }
      dK() {}
      get Yo() {
        return this.ai;
      }
      set Yo(a) {
        this.ai !== a && ((this.ai = a), _.Sl(this, "UPDATE_FOCUS"));
      }
      get zl() {
        return this.get("dragging");
      }
      panes_changed() {
        nN(this);
        this.Mh.Hh();
      }
      Gq(a) {
        this.set("position", a && new _.Dm(a.oi, a.si));
      }
      pv() {
        this.unbindAll();
        this.set("panes", null);
        this.Jh && this.Jh.stop();
        this.Ph && (_.Il(this.Ph), (this.Ph = null));
        this.Jh = null;
        lN(this.ei);
        this.ei = [];
        nN(this);
        _.Sl(this, "RELEASED");
      }
      ci() {
        var a;
        if (!(a = this.Ai !== oN(this) || this.Bi !== this.getDraggable())) {
          a = this.mi;
          var b = this.get("shape");
          a = !(a == null || b == null
            ? a === b
            : a.type === b.type && _.zD(a.coords, b.coords));
        }
        a &&
          ((this.Ai = oN(this)),
          (this.Bi = this.getDraggable()),
          (this.mi = this.get("shape")),
          mN(this),
          this.Mh.Hh());
      }
      Ih() {
        this.Mh.Hh();
      }
      position_changed() {
        this.Th ? _.Zn(this.Mh) : this.Mh.Hh();
      }
      Zr() {
        return this.targetElement;
      }
      Wz() {
        var a = this.Zr();
        if (a) {
          var b = !!this.get("title");
          b || (b = (b = this.getLabel()) ? !!b.text : !1);
          this.Yo
            ? a.setAttribute("role", "button")
            : b
            ? a.setAttribute("role", "img")
            : a.removeAttribute("role");
        }
      }
      qB(a) {
        _.Sl(this, "click", a);
        _.nk(window, 171149);
      }
      uv() {}
      Pu(a) {
        _.Pu(a);
        _.Sl(this, "click", a);
        _.nk(window, 171150);
      }
      pB() {}
      getDraggable() {
        return !!this.get("draggable");
      }
      Ni() {
        this.set("dragging", !0);
        this.Uh.set("snappingCallback", this.bi);
      }
      Ci() {
        this.Uh.set("snappingCallback", null);
        this.set("dragging", !1);
      }
      animation_changed() {
        this.Vh = !1;
        this.get("animation")
          ? MXa(this)
          : (this.set("animating", !1), this.Jh && this.Jh.stop());
      }
      eJ(a) {
        var b = this.get("markerPosition");
        return this.Vr && b && this.Vr.size ? gXa(a, this.targetElement) : !1;
      }
    };
  _.aa = VN.prototype;
  _.aa.shape_changed = VN.prototype.ci;
  _.aa.clickable_changed = VN.prototype.ci;
  _.aa.draggable_changed = VN.prototype.ci;
  _.aa.cursor_changed = VN.prototype.Ih;
  _.aa.scale_changed = VN.prototype.Ih;
  _.aa.raiseOnDrag_changed = VN.prototype.Ih;
  _.aa.crossOnDrag_changed = VN.prototype.Ih;
  _.aa.zIndex_changed = VN.prototype.Ih;
  _.aa.opacity_changed = VN.prototype.Ih;
  _.aa.title_changed = VN.prototype.Ih;
  _.aa.cross_changed = VN.prototype.Ih;
  _.aa.icon_changed = VN.prototype.Ih;
  _.aa.visible_changed = VN.prototype.Ih;
  _.aa.dragging_changed = VN.prototype.Ih;
  var UXa =
      "click dblclick mouseup mousedown mouseover mouseout rightclick dragstart drag dragend contextmenu".split(
        " "
      ),
    eYa = class {
      constructor(a, b, c, d, e, f, g) {
        this.marker = a;
        this.Ih = b;
        this.ki = e;
        this.Vh = f;
        this.Kh = g;
        this.Sh = !0;
        this.Uh = this.Th = null;
        this.Mh = [];
        this.Qh = b instanceof _.gm;
        f = sN(this);
        b = this.Qh && f ? _.ov(f, b.getProjection()) : null;
        this.Hh = new VN(d, !!this.Qh, (h) => {
          this.Hh.Vr = a.__gm.Vr = { ...a.__gm.Vr, BT: h };
          a.__gm.ZA && a.__gm.ZA();
        });
        _.Gl(this.Hh, "RELEASED", () => {
          var h = this.Hh;
          if (this.Kh && this.Kh.has(h)) {
            ({ sI: h } = this.Kh.get(h));
            for (let k of h) k.remove();
          }
          this.Kh && this.Kh.delete(this.Hh);
        });
        this.Vh &&
          this.Kh &&
          !this.Kh.has(this.Hh) &&
          (this.Kh.set(this.Hh, { marker: this.marker, sI: [] }),
          this.Vh.Vh(this.Hh),
          tN(this, this.Hh),
          RXa(this, this.Hh));
        (this.Lh = this.Qh
          ? new _.gI(e.topology, this.Hh, b, e, () => {
              if (this.Hh.get("dragging") && !this.marker.get("place")) {
                var h = this.Lh.getPosition();
                h &&
                  ((h = _.kp(h, this.Ih.get("projection"))),
                  (this.Sh = !1),
                  this.marker.set("position", h),
                  (this.Sh = !0));
              }
            })
          : null) && e.lk(this.Lh);
        this.Nh = new jZa(c, (h, k, n) => {
          this.Hh.Vr = a.__gm.Vr = {
            ...a.__gm.Vr,
            size: h,
            anchor: k,
            labelOrigin: n,
          };
          a.__gm.ZA && a.__gm.ZA();
        });
        this.Jh = this.Qh ? null : new _.TH();
        this.Oh = this.Qh ? null : new kZa();
        this.Ph = new _.Ul();
        this.Ph.bindTo("position", this.marker);
        this.Ph.bindTo("place", this.marker);
        this.Ph.bindTo("draggable", this.marker);
        this.Ph.bindTo("dragging", this.marker);
        this.Nh.bindTo("modelIcon", this.marker, "icon");
        this.Nh.bindTo("modelLabel", this.marker, "label");
        this.Nh.bindTo("modelCross", this.marker, "cross");
        this.Nh.bindTo("modelShape", this.marker, "shape");
        this.Nh.bindTo("useDefaults", this.marker, "useDefaults");
        this.Hh.bindTo("icon", this.Nh, "viewIcon");
        this.Hh.bindTo("label", this.Nh, "viewLabel");
        this.Hh.bindTo("cross", this.Nh, "viewCross");
        this.Hh.bindTo("shape", this.Nh, "viewShape");
        this.Hh.bindTo("title", this.marker);
        this.Hh.bindTo("cursor", this.marker);
        this.Hh.bindTo("dragging", this.marker);
        this.Hh.bindTo("clickable", this.marker);
        this.Hh.bindTo("zIndex", this.marker);
        this.Hh.bindTo("opacity", this.marker);
        this.Hh.bindTo("anchorPoint", this.marker);
        this.Hh.bindTo("markerPosition", this.marker, "position");
        this.Hh.bindTo("animation", this.marker);
        this.Hh.bindTo("crossOnDrag", this.marker);
        this.Hh.bindTo("raiseOnDrag", this.marker);
        this.Hh.bindTo("animating", this.marker);
        this.Oh || this.Hh.bindTo("visible", this.marker);
        SXa(this);
        TXa(this);
        VXa(this);
        this.Qh
          ? (WXa(this), XXa(this), ZXa(this))
          : ($Xa(this),
            this.Jh &&
              (this.Oh.bindTo("visible", this.marker),
              this.Oh.bindTo("cursor", this.marker),
              this.Oh.bindTo("icon", this.marker),
              this.Oh.bindTo("icon", this.Nh, "viewIcon"),
              this.Oh.bindTo("mapPixelBoundsQ", this.Ih.__gm, "pixelBoundsQ"),
              this.Oh.bindTo("position", this.Jh, "pixelPosition"),
              this.Hh.bindTo("visible", this.Oh, "shouldRender")),
            bYa(this));
      }
      dispose() {
        this.Hh.set("animation", null);
        this.Hh.pv();
        this.ki && this.Lh ? this.ki.Rm(this.Lh) : this.Hh.pv();
        this.Oh && this.Oh.unbindAll();
        this.Jh && this.Jh.unbindAll();
        this.Nh.unbindAll();
        this.Ph.unbindAll();
        this.Mh.forEach(_.Il);
        this.Mh.length = 0;
      }
    };
  var yN = class {
    constructor(a, b, c, d) {
      this.div = a;
      this.gk = b;
      this.Hh = c;
      this.Xi = d;
    }
    getContext() {
      if (!this.context) {
        let a = this.div,
          b = a.ownerDocument.createElement("canvas");
        _.ro(b);
        b.style.position = "absolute";
        b.style.top = b.style.left = "0";
        let c = b.getContext("2d"),
          d = vN(c),
          e = this.Xi.size;
        b.width = Math.ceil(e.oi * d);
        b.height = Math.ceil(e.si * d);
        b.style.width = _.Jk(e.oi);
        b.style.height = _.Jk(e.si);
        a.appendChild(b);
        this.context = c;
      }
      return this.context;
    }
    dH(a) {
      var b = gYa(this),
        c = this.getContext(),
        d = vN(c),
        e = Math.round(a.dx * d),
        f = Math.round(a.dy * d),
        g = Math.ceil(a.Ms * d);
      a = Math.ceil(a.Js * d);
      var h = fYa(this, g, a),
        k = h.getContext("2d");
      k.translate(-e, -f);
      b.forEach((n) => {
        k.globalAlpha = _.Fk(n.opacity, 1);
        k.drawImage(
          n.image,
          n.AC,
          n.BC,
          n.zC,
          n.uC,
          Math.round(n.dx * d),
          Math.round(n.dy * d),
          n.Ms * d,
          n.Js * d
        );
      });
      c.clearRect(e, f, g, a);
      c.globalAlpha = 1;
      c.drawImage(h, e, f);
    }
  };
  yN.prototype.UP = yN.prototype.dH;
  var pYa = class {
    constructor() {
      this.Hh = _.PD().Hh;
    }
    load(a, b) {
      return this.Hh.load(new _.pG(a.url), (c) => {
        if (c) {
          var d = c.size,
            e = a.size || a.scaledSize || d;
          a.size = e;
          var f = a.scaledSize || d,
            g = a.anchor || new _.Dm(e.width / 2, e.height),
            h = f.width / d.width,
            k = f.height / d.height,
            n = a.origin ? a.origin.x / h : 0,
            p = a.origin ? a.origin.y / k : 0,
            r = -g.x;
          g = -g.y;
          var u = e.width / h,
            w = e.width,
            y = e.height / k,
            A = e.height;
          n * h + e.width > f.width && ((u = d.width - n * h), (w = f.width));
          p * k + e.height > f.height &&
            ((y = d.height - p * k), (A = f.height));
          b({
            image: c,
            AC: n,
            BC: p,
            zC: u,
            uC: y,
            dx: r,
            dy: g,
            Ms: w,
            Js: A,
          });
        } else b(null);
      });
    }
    cancel(a) {
      this.Hh.cancel(a);
    }
  };
  var rYa = class {
    constructor(a, b, c, d) {
      this.Hh = b;
      this.Ih = c;
      this.zIndex = 40;
      this.Jh = new _.hI(a, d, c);
    }
    sv(a) {
      return a !== "dragstart" && a !== "drag" && a !== "dragend";
    }
    yv(a, b) {
      return b
        ? wN(this, a, -8, 0) ||
            wN(this, a, 0, -8) ||
            wN(this, a, 8, 0) ||
            wN(this, a, 0, 8)
        : wN(this, a, 0, 0);
    }
    handleEvent(a, b, c) {
      var d = b.Zk;
      if (a === "mouseout")
        this.Hh.set("cursor", ""), this.Hh.set("title", null);
      else if (a === "mouseover") {
        var e = d.gz;
        this.Hh.set("cursor", e.cursor);
        (e = e.title) && this.Hh.set("title", e);
      }
      var f;
      d && a !== "mouseout" ? (f = d.gz.latLng) : (f = b.latLng);
      a === "dblclick" && _.El(b.domEvent);
      _.Sl(c, a, new _.Mz(f, b.domEvent));
    }
  };
  var sYa = class extends _.as {
    constructor(a, b, c, d, e, f, g) {
      super();
      this.tiles = a;
      this.Lh = d;
      this.Jh = c;
      this.Ih = e;
      this.Kh = f;
      this.Xi = g || _.Xz;
      b.Hh = (h) => {
        kYa(this, h);
      };
      b.onRemove = (h) => {
        lYa(this, h);
      };
      b.forEach((h) => {
        kYa(this, h);
      });
    }
    Hh() {
      return { Xi: this.Xi, Yn: 2, Mm: this.Mm.bind(this) };
    }
    Mm(a, b = {}) {
      var c = document.createElement("div"),
        d = this.Xi.size;
      c.style.width = `${d.oi}px`;
      c.style.height = `${d.si}px`;
      c.style.overflow = "hidden";
      a = {
        div: c,
        zoom: a.Mi,
        ek: new _.Dm(a.Gi, a.Hi),
        cL: {},
        gk: new _.Wo(),
      };
      c.Sm = a;
      mYa(this, a);
      var e = !1;
      return {
        Qk: () => c,
        ep: () => e,
        loaded: new Promise((f) => {
          _.Pl(c, "load", () => {
            e = !0;
            f();
          });
        }),
        release: () => {
          var f = c.Sm;
          c.Sm = null;
          nYa(this, f);
          c.textContent = "";
          b.Yk && b.Yk();
        },
      };
    }
  };
  var tYa = class {
    constructor(a, b, c) {
      this.Ih = b;
      this.timeout = null;
      this.Hh = !1;
      this.Jh = 0;
      this.gk = a;
      var d = this;
      a.Hh = (e) => {
        d.os(e, !0);
      };
      a.onRemove = (e) => {
        d.onRemove(e);
      };
      this.div = c;
      a.getSize()
        ? ((this.Hh = !0), this.xq())
        : queueMicrotask(() => {
            _.Sl(c, "load");
          });
    }
    onRemove(a) {
      this.os(a, !1);
    }
    os(a, b) {
      this.Jh++ < 4 ? (b ? this.Ih.dH(a) : this.Ih.UP(a)) : (this.Hh = !0);
      this.timeout || (this.timeout = _.RD(this.xq.bind(this)));
    }
    xq() {
      this.Hh && hYa(this.Ih);
      this.Hh = !1;
      this.timeout = null;
      this.Jh = 0;
      queueMicrotask(() => {
        _.Sl(this.div, "load");
      });
    }
  };
  var qYa = class {
    constructor(a, b, c, d, e) {
      var f = oYa;
      this.markers = a;
      this.Ih = b;
      this.Hh = c;
      this.Lh = f;
      this.Kh = d;
      this.Jh = e;
      this.markers.Hh = (g) => {
        this.Hw(g);
      };
      this.markers.onRemove = (g) => {
        this.uz(g);
      };
    }
    Hw(a) {
      var b = a.get("internalPosition"),
        c = a.get("zIndex"),
        d = a.get("opacity"),
        e = (a.__gm.wB = { ID: a, latLng: b, zIndex: c, opacity: d, gk: {} });
      b = a.get("useDefaults");
      c = a.get("icon");
      var f = a.get("shape") || (c && !b) ? a.get("shape") : this.Hh.shape,
        g = c ? this.Lh(c) : this.Hh.icon,
        h = fXa(() => {
          e === a.__gm.wB && (e.rw || e.PK) && this.Dn(a, e, g, f);
        });
      g.url
        ? this.Kh.load(g, (k) => {
            e.rw = k;
            h();
          })
        : ((e.PK = this.Jh(g)), h());
    }
    uz(a) {
      this.Ih.remove(a.__gm.wB);
      a.__gm.wB = null;
    }
    Dn(a, b, c, d) {
      if (b.rw) {
        c = c.size;
        var e = a.get("anchorPoint");
        if (!e || e.Hh)
          (e = new _.Dm(b.rw.dx + c.width / 2, b.rw.dy)),
            (e.Hh = !0),
            a.set("anchorPoint", e);
      } else c = b.PK.size;
      d
        ? (d.coords = d.coords || d.coord)
        : (d = { type: "rect", coords: [0, 0, c.width, c.height] });
      b.shape = d;
      b.clickable = a.get("clickable");
      b.title = a.get("title") || null;
      b.cursor = a.get("cursor") || "pointer";
      _.ao(this.Ih, b);
    }
  };
  var xN = new Map();
  var mZa = class {
    constructor(a, b, c, d) {
      this.by = {};
      this.Dv = 0;
      this.Cz = !0;
      var e = this;
      this.fG = b;
      this.aw = c;
      this.tI = d;
      var f = {
        animating: 1,
        animation: 1,
        attribution: 1,
        clickable: 1,
        cursor: 1,
        draggable: 1,
        flat: 1,
        icon: 1,
        label: 1,
        opacity: 1,
        optimized: 1,
        place: 1,
        position: 1,
        shape: 1,
        __gmHiddenByCollision: 1,
        title: 1,
        visible: 1,
        zIndex: 1,
      };
      this.kP = function (g) {
        g in f && (delete this.changed, (e.by[_.Tl(this)] = this), wYa(e));
      };
      a.Hh = (g) => {
        e.Hw(g);
      };
      a.onRemove = (g) => {
        e.uz(g);
      };
      a = a.elements;
      for (let g of Object.values(a)) this.Hw(g);
    }
    Hw(a) {
      this.by[_.Tl(a)] = a;
      wYa(this);
    }
    uz(a) {
      delete a.changed;
      delete this.by[_.Tl(a)];
      this.fG.remove(a);
      this.aw.remove(a);
    }
  };
  var NN = class extends Event {
    constructor() {
      super("gmp-click", { bubbles: !0, composed: !0 });
    }
  };
  var nZa = class {
    ai() {}
    Th() {}
    Ih() {}
    Jh() {}
    Kh() {}
    Ph() {}
    Sh() {}
    Nh() {}
    Lh() {}
    Mh() {}
    Qh() {}
    Uh() {}
    Hh() {}
    Vh() {}
    Wh() {}
    ci() {}
    Zh() {}
    Oh() {}
  };
  var oZa = (0,
  _.Wh)`.yNHHyP-marker-view .IPAZAH-content-container\u003e*{pointer-events:none}.yNHHyP-marker-view .IPAZAH-content-container.HJDHPx-interactive\u003e*{pointer-events:auto}\n`;
  var AYa = bXa("visible-gmp-advanced-markers"),
    zYa = bXa("hidden-gmp-advanced-markers"),
    DYa = class {
      constructor(a) {
        this.Li = pZa;
        this.Lq = null;
        this.Qh = !1;
        this.Oh = null;
        this.Nh = 0;
        this.Ph = null;
        this.map = a;
        this.Kh = new Set();
        this.Lh = new Set();
        this.qp = `maps-aria-${_.fm()}`;
        this.Jh = document.createElement("span");
        this.Jh.id = this.qp;
        this.Jh.textContent =
          "To activate drag with keyboard, press Alt + Enter. Once in keyboard drag state, use the arrow keys to move the marker. To complete the drag, press the Enter key. To cancel, press Escape.";
        this.Jh.style.display = "none";
        this.Mh = document.createElement("div");
        this.Hh = document.createElement("div");
        CSS.supports("content-visibility: hidden")
          ? (this.Hh.style.contentVisibility = "hidden")
          : (this.Hh.style.visibility = "hidden");
        var b = document.createElement("slot");
        b.setAttribute("name", AYa);
        this.Mh.appendChild(b);
        b = document.createElement("slot");
        b.setAttribute("name", zYa);
        this.Hh.appendChild(b);
        this.Ih = document.createElement("div");
        this.Ih.append(this.Mh, this.Hh);
        var c = a.__gm;
        this.Uh = c.Xr;
        this.Sh = new Promise((d) => {
          c.Jh.then((e) => {
            this.map && (e && (this.Lq = xYa(this, a)), (this.Qh = !0));
            d();
          });
        });
        _.ws(oZa, this.map.getDiv());
        Promise.all([c.Ih, this.Sh]).then(([{ Gn: d }]) => {
          this.map && d.overlayMouseTarget.append(this.Jh, this.Ih);
          this.Ph = c.addListener("panes_changed", (e) => {
            this.map && e.overlayMouseTarget.append(this.Jh, this.Ih);
          });
        });
      }
      dispose() {
        this.Lq && (this.Lq.setMap(null), (this.Lq = null));
        this.Ph && this.Ph.remove();
        this.Jh.remove();
        this.Hh.remove();
        this.Mh.remove();
        this.Ih.remove();
        this.Hh.textContent = "";
        this.Mh.textContent = "";
        this.Kh.clear();
        this.Lh.clear();
        this.map = null;
      }
      isEmpty() {
        return this.Kh.size === 0;
      }
      requestRedraw() {
        this.Qh
          ? this.Lq && this.Lq.requestRedraw()
          : this.Sh.then(() => {
              this.Lq && this.Lq.requestRedraw();
            });
      }
      onDraw(a) {
        if (this.map) {
          var b = this.Uh.offsetWidth,
            c = this.Uh.offsetHeight,
            d = _.vo(
              this.map.getZoom() || 1,
              this.map.getTilt() || 0,
              this.map.getHeading() || 0
            );
          for (let h of this.Kh.values()) {
            a: {
              var e = h.DO;
              var f = this.map.getCenter();
              if (!e || !f) {
                e = null;
                break a;
              }
              f = _.Bk(f.lng(), -180, 180);
              var g = _.Bk(e.lng, -180, 180);
              f > 0 && g < f - 180
                ? (g += 360)
                : f < 0 && g > f + 180 && (g -= 360);
              e = new _.fn({ altitude: e.altitude, lat: e.lat, lng: g }, !0);
            }
            if (!e) {
              h.Gq(null, d);
              continue;
            }
            f = a.fromLatLngAltitude(e);
            e = g = [0, 0, 0];
            let [k, n, p] = e,
              r = 1 / (f[3] * k + f[7] * n + f[11] * p + f[15]);
            e[0] = (f[0] * k + f[4] * n + f[8] * p + f[12]) * r;
            e[1] = (f[1] * k + f[5] * n + f[9] * p + f[13]) * r;
            e[2] = (f[2] * k + f[6] * n + f[10] * p + f[14]) * r;
            let { sO: u, VQ: w } = { sO: f[14] < 0 && f[15] < 0, VQ: g };
            u
              ? h.Gq(null, d)
              : h.Gq({ oi: dN((w[0] / 2) * b), si: dN((-w[1] / 2) * c) }, d, {
                  oi: b,
                  si: c,
                });
          }
        }
      }
    };
  var BN = new Map(),
    pZa = new (class extends nZa {
      ai(a) {
        a && a && _.nk(a, 181191);
      }
      Th(a) {
        if (a) {
          var b = a.getRenderingType();
          b !== "UNINITIALIZED" && a && _.nk(a, 159713);
          b === "RASTER"
            ? a && _.nk(a, 157416)
            : b === "VECTOR" && a && _.nk(a, 157417);
        }
      }
      Ih(a, b = !1) {
        a && _.nk(a, 158896);
        b && a && _.nk(a, 185214);
      }
      Jh(a, b) {
        b &&
          (b !== "REQUIRED" && a && _.nk(a, 160097),
          b === "REQUIRED_AND_HIDES_OPTIONAL"
            ? a && _.nk(a, 160098)
            : b === "OPTIONAL_AND_HIDES_LOWER_PRIORITY" &&
              a &&
              _.nk(a, 160099));
      }
      Kh(a, b) {
        b ? a && _.nk(a, 159404) : a && _.nk(a, 159405);
      }
      Ph(a) {
        a && _.nk(a, 159484);
      }
      Sh(a) {
        a && _.nk(a, 160438);
      }
      Nh(a) {
        a && _.nk(a, 159521);
      }
      Lh(a) {
        a && _.nk(a, 160103);
      }
      Mh(a) {
        a && _.nk(a, 159805);
      }
      Qh(a) {
        a && _.nk(a, 159490);
      }
      Uh(a) {
        a && _.nk(a, 159812);
      }
      Hh(a) {
        a && _.nk(a, 159609);
      }
      Vh(a) {
        a && _.nk(a, 160122);
      }
      Wh(a) {
        a && _.nk(a, 160106);
      }
      ci(a) {
        a && _.nk(a, 160478);
      }
      Zh(a, b) {
        var c = [
          { threshold: 1e4, Yq: 160636 },
          { threshold: 5e3, Yq: 160635 },
          { threshold: 2e3, Yq: 160634 },
          { threshold: 1e3, Yq: 160633 },
          { threshold: 500, Yq: 160632 },
          { threshold: 200, Yq: 160631 },
          { threshold: 100, Yq: 160630 },
          { threshold: 50, Yq: 159732 },
          { threshold: 10, Yq: 160629 },
          { threshold: 1, Yq: 160628 },
        ];
        for (let { threshold: d, Yq: e } of c)
          if (b >= d) {
            a && _.nk(a, e);
            break;
          }
      }
      Oh(a) {
        window && _.nk(window, a instanceof KeyboardEvent ? 171152 : 171153);
      }
    })(),
    qZa = new nZa(),
    AN = null;
  var rZa = class {
    constructor(a) {
      this.Hh = a;
      this.ri = document;
      this.Lh = this.Kh = !1;
      this.Ph = this.Ih = this.Mh = this.Qh = this.Uh = this.Zh = null;
      this.Sh = 0;
      this.bi = null;
      this.ii = (b) => {
        this.tv(b);
      };
      this.mi = (b) => {
        b.touches.length === 1 && this.tv(b);
      };
      this.ei = (b) => {
        b.preventDefault();
        b.stopImmediatePropagation();
      };
      this.Wh = (b) => {
        if (this.Lh || this.Nh || lXa(b, this.Zh)) this.Nh = !0;
      };
      a = this.Hh.cq;
      a instanceof HTMLElement && (a.style.touchAction = "none");
      _.aw !== 2
        ? (a.addEventListener("pointerdown", this.ii),
          a.addEventListener("pointermove", this.Wh))
        : (a.addEventListener("touchstart", this.mi, { passive: !1 }),
          a.addEventListener("touchmove", this.Wh, { passive: !1 }));
      a.addEventListener("mousedown", this.ei);
      this.Vh = (b) => {
        b.preventDefault();
        b.stopImmediatePropagation();
        this.Lh
          ? PYa(this, b)
          : this.Kh
          ? (QYa(this, b), FN(this, "drag", b))
          : (SYa(this, b), (b = this.Hh), b.Li.ci(_.ja(b, "map")));
      };
      this.Oh = (b) => {
        this.Ph && b.timeStamp - this.Ph >= 500 && (!this.Kh || this.Lh)
          ? (this.Lh
              ? PYa(this, b)
              : (SYa(this, b),
                (b = this.Hh),
                b.Li.Wh(_.ja(b, "map")),
                b.nr && _.Sl(b, "longpressdragstart")),
            (this.Nh = !0))
          : (this.Kh &&
              (this.Lh || this.Nh || lXa(b, this.Zh)) &&
              (this.Nh = !0),
            this.Lh && CN(this, b),
            b.type === "touchend" && GN(this, !1),
            this.Kh
              ? (this.Nh && b.preventDefault(),
                b.stopImmediatePropagation(),
                QYa(this, b),
                JN(this),
                KN(this.Hh, !0),
                FN(this, "dragend", b))
              : JN(this));
      };
      this.Ai = (b) => {
        this.Ci(b);
      };
      this.Bi = (b) => {
        this.Ni(b);
      };
      this.wi = (b) => {
        DN(this, b);
      };
      this.Ci = (b) => {
        if (b.altKey && (_.jx(b) || b.key === _.Tsa)) DN(this, b);
        else if (!b.altKey && _.jx(b)) (this.Nh = !0), CN(this, b);
        else if (_.kx(b) || _.mx(b) || _.lx(b) || _.nx(b))
          b.preventDefault(),
            this.Th.add(b.key),
            this.Sh || ((this.bi = new _.rH(100)), UYa(this)),
            FN(this, "drag", b);
        else if (b.code === "Equal" || b.code === "Minus") {
          var c = this.Hh;
          b = b.code === "Equal" ? 1 : -1;
          let d = kXa(c.Gl, c.qr);
          d && c.ki.uL(b, d);
        }
      };
      this.Ni = (b) => {
        (_.kx(b) || _.mx(b) || _.lx(b) || _.nx(b)) && this.Th.delete(b.key);
      };
      this.ai = () => {
        GN(this, !0);
      };
      this.ci = () => {
        this.Kh || GN(this, !1);
      };
      this.Jh = document.createElement("div");
      LYa(this);
      this.Nh = !1;
      this.Th = new Set();
    }
    Ev(a) {
      this.Ih && _.sH(this.Ih, a);
    }
    tv(a) {
      this.Nh = !1;
      if (this.Hh.gmpDraggable && (a.button === 0 || a.type === "touchstart")) {
        let b = this.Hh.cq;
        b.focus();
        let c = _.bv(a.target) || document;
        this.ri = c;
        _.aw !== 2 || a.preventDefault();
        a.stopImmediatePropagation();
        this.Ph = a.timeStamp;
        _.aw !== 2
          ? (c.addEventListener("pointermove", this.Vh),
            c.addEventListener("pointerup", this.Oh),
            c.addEventListener("pointercancel", this.Oh))
          : (c.addEventListener("touchmove", this.Vh, { passive: !1 }),
            c.addEventListener("touchend", this.Oh),
            c.addEventListener("touchcancel", this.Oh),
            c.addEventListener("touchstart", this.Oh));
        this.Kh || (this.Zh = _.TG(a));
        b.style.cursor = _.rx;
      }
    }
    qB() {
      this.Kh || (this.Nh = !1);
    }
    uv(a) {
      if (this.Hh.gmpDraggable && !this.Lh && !this.Kh) {
        var b = this.Hh.cq;
        b.addEventListener("keydown", this.Ai);
        b.addEventListener("keyup", this.Bi);
        b.addEventListener("blur", this.wi);
        this.Mh = this.Hh.yp();
        this.Uh = this.Hh.position;
        this.Lh = this.Kh = !0;
        OYa(this);
        b = this.Hh.cq;
        b.setAttribute("aria-grabbed", "true");
        IN(this.Hh);
        b.style.zIndex = "2147483647";
        this.Jh.style.opacity = "1";
        FN(this, "dragstart", a);
        a = this.Hh;
        a.Li.Vh(_.ja(a, "map"));
      }
    }
    pB(a, b = !0) {
      this.Lh
        ? DN(this, a, b)
        : this.Kh &&
          ((this.Hh.position = this.Uh),
          a.stopImmediatePropagation(),
          JN(this),
          b && FN(this, "dragend", a));
    }
    zl() {
      return this.Kh;
    }
    dispose() {
      JN(this);
      var a = this.Hh.cq;
      a instanceof HTMLElement && (a.style.touchAction = "");
      _.aw !== 2
        ? (a.removeEventListener("pointerdown", this.ii),
          a.removeEventListener("pointermove", this.Wh))
        : (a.removeEventListener("touchstart", this.mi, { passive: !1 }),
          a.removeEventListener("touchmove", this.Wh, { passive: !1 }));
      a.removeEventListener("mousedown", this.ei);
      a.removeEventListener("pointerenter", this.ai);
      a.removeEventListener("pointerleave", this.ci);
      a.removeEventListener("focus", this.ai);
      a.removeEventListener("blur", this.ci);
      this.Jh.remove();
    }
  };
  var sZa = {
      click:
        "Please use addEventListener('gmp-click', ...) instead of addEventListener('click', ...).",
      drag: "Please use addEventListener('gmp-drag', ...) instead of addEventListener('drag', ...).",
      dragstart:
        "Please use addEventListener('gmp-dragstart', ...) instead of addEventListener('dragstart', ...).",
      dragend:
        "Please use addEventListener('gmp-dragend', ...) instead of addEventListener('dragend', ...).",
    },
    WN = !1,
    XN = class extends _.Er {
      set anchorTop(a) {
        this.oO = _.Hn(this, "anchorTop", _.Fq, a);
        SN(this, this.Ml);
        this.Ev(!0);
      }
      get anchorTop() {
        return this.oO;
      }
      set anchorLeft(a) {
        this.nO = _.Hn(this, "anchorLeft", _.Fq, a);
        SN(this, this.Ml);
        this.Ev(!0);
      }
      get anchorLeft() {
        return this.nO;
      }
      constructor(a = {}) {
        super(a);
        this.Xx = this.OD = this.Vj = this.wk = null;
        this.CD = "";
        this.Bm = this.Xy = this.OG = this.ki = this.Al = this.fm = null;
        this.LG = !1;
        this.OC = null;
        this.AF = this.fJ = this.PC = this.NG = !1;
        this.Zi = this.nA = this.zJ = this.bK = this.vL = this.sH = null;
        this.xx = void 0;
        this.yx = this.MG = !1;
        this.UI = _.uo(!1);
        this.qr = this.zx = this.br = null;
        this.au = "";
        this.Gl = this.PG = this.QC = void 0;
        this.pD = this.qD = !0;
        this.zE = this.aG = !1;
        this.iz = !0;
        document.createElement("div");
        WYa(this);
        this.targetElement = this;
        this.cq = this;
        this.nr = WN;
        Object.defineProperties(this, { nr: { value: WN, writable: !1 } });
        this.Li = this.nr ? qZa : pZa;
        this.addEventListener(
          "focus",
          (e) => {
            this.gE(e);
          },
          { capture: !0 }
        );
        this.addEventListener("gmp-internal-marker-resize", () => {
          XYa(this);
          this.Ev(!0);
        });
        this.wn = new _.jA();
        this.nk = document.createElement("div");
        _.qp(this.nk, "content-container");
        this.fm = document.createElement("slot");
        this.fm.addEventListener("slotchange", () => {
          this.jr();
        });
        this.nk.appendChild(this.fm);
        this.fm.prepend(this.wn);
        this.jr();
        Promise.resolve().then(() => {
          LN(this);
          a.anchorTop && (this.anchorTop = a.anchorTop);
          a.anchorLeft && (this.anchorLeft = a.anchorLeft);
        });
        this.NA = getComputedStyle(this);
        this.DN = (e, f, g) => this.hB(e, f, g);
        var b = () => {
            LN(this);
            MN(this);
            var e = _.Hl(this, "gmp-click");
            this.Li.Ih(_.ja(this, "map"), e);
          },
          c = () => {
            LN(this);
            MN(this);
          },
          d = ["click"];
        d.push("gmp-click");
        for (let e of d) eXa(this, e, b), dXa(this, e, c);
        this.Ao = new _.Ul();
        this.Ao.addListener("isopen_changed", () => {
          ZYa(this);
          XYa(this);
        });
        this.wI = (e) => {
          this.Vj?.Jt(e === "cooperative" || e === "none");
        };
        this.collisionBehavior = a.collisionBehavior;
        a.content != null && (this.content = a.content);
        this.zD = !!a.zD;
        this.gmpClickable = a.gmpClickable;
        this.gmpDraggable = a.gmpDraggable;
        this.position = a.position;
        this.title = a.title ?? "";
        this.zIndex = a.zIndex;
        this.map = _.ja(a, "map");
        this.Ji(a, XN, "AdvancedMarkerElement");
      }
      addEventListener(a, b, c) {
        var d = sZa[a];
        !d || (a === "click" && this.aG) || _.wl(_.yn(this, d));
        super.addEventListener(a, b, c);
      }
      addListener(a, b) {
        _.wl(
          _.yn(
            this,
            "Please use addEventListener with 'gmp-' events instead of addListener."
          )
        );
        return _.Gl(this, a, b);
      }
      gE(a) {
        var b = a.target,
          c = a.relatedTarget;
        if (this !== b)
          if (
            (a.stopPropagation(),
            a.stopImmediatePropagation(),
            console.debug(
              'Focusable child elements in AdvancedMarkerElement are not supported. To make AdvancedMarkerElement focusable, use addListener() to register a "click" event on the AdvancedMarkerElement instance.'
            ),
            this.Li.Uh(_.ja(this, "map")),
            (a = [document.body, ..._.kv(document.body)]),
            (b = a.indexOf(b)),
            (c = a.indexOf(c)),
            b === -1 || c === -1)
          )
            this.focus();
          else
            for (c = b > c ? 1 : -1, b += c; b >= 0 && b < a.length; b += c) {
              let d = a[b];
              if ((this.Yo && d === this) || !this.contains(d)) {
                (d instanceof HTMLElement || d instanceof SVGElement) &&
                  d.focus();
                break;
              }
            }
      }
      qB(a) {
        this.wk && this.wk.qB();
        $Ya(this, a);
      }
      uv(a) {
        this.wk && this.wk.uv(a);
      }
      tv(a) {
        this.wk && this.wk.tv(a);
      }
      rI() {
        return new Promise((a) => {
          if (this.Yo) {
            var b = () => {
              this.isConnected && this.Ml
                ? setTimeout(() => {
                    this.focus();
                    a();
                  }, 0)
                : _.pv(_.qv(), b);
            };
            b();
          }
        });
      }
      Pu() {}
      pB(a) {
        this.wk &&
          (this.wk.pB(a, !this.nr), this.nr && _.Sl(this, "dragcancel"));
      }
      get collisionBehavior() {
        return this.xx;
      }
      set collisionBehavior(a) {
        a = _.Hn(this, "collisionBehavior", _.fl(_.Zk(_.Vq)), a) || "REQUIRED";
        this.collisionBehavior !== a &&
          ((this.xx = a),
          this.Li.Jh(_.ja(this, "map"), this.xx),
          _.ja(this, "map") &&
            (!zN(this) && this.Zi ? YWa(this.Zi.bi, this) : KN(this, !0)));
      }
      get element() {
        return this;
      }
      get FB() {
        return PN(this)[0] === this.wn;
      }
      get content() {
        var a = PN(this);
        a.length > 1 &&
          console.debug(
            "The content getter of AdvancedMarkerElement only returns the first content when there are multiple contents, use childNodes or children to get all the contents."
          );
        return a[0];
      }
      set content(a) {
        a =
          _.Hn(
            this,
            "content",
            _.fl(_.dl([_.Yk(Node, "Node"), _.cl(_.Xk)])),
            a
          ) || this.wn;
        var b = PN(this);
        if (b.length !== 1 || b[0] !== a)
          a !== this.wn
            ? this.replaceChildren(a)
            : a === this.wn && this.replaceChildren(),
            this.jr();
      }
      jr() {
        var a = () => {
          this.fm && !this.fm.contains(this.wn) && this.fm.prepend(this.wn);
          this.Bm = null;
          this.wk && HN(this.wk);
          KN(this, !0);
          LN(this);
        };
        this.Li.Kh(_.ja(this, "map"), this.FB);
        this.mp.then(() => {
          a();
        });
      }
      get dragIndicator() {}
      set dragIndicator(a) {}
      get gmpClickable() {
        return this.MG;
      }
      set gmpClickable(a) {
        a = _.Hn(this, "gmpClickable", _.Gq, a) || !1;
        this.MG !== a && ((this.MG = a), LN(this), MN(this));
      }
      get gmpDraggable() {
        return this.yx;
      }
      set gmpDraggable(a) {
        a = _.Hn(this, "gmpDraggable", _.Gq, a) || !1;
        bZa(this, this.position, a);
        this.UI.set(a);
        this.yx !== a &&
          ((this.yx = a)
            ? (this.Li.Lh(_.ja(this, "map")),
              this.setAttribute("aria-grabbed", "false"),
              EYa(this, this.CD),
              YYa(this),
              (this.wk = new rZa(this)),
              KYa(this.wk))
            : (this.removeAttribute("aria-grabbed"),
              this.dK(this.CD),
              this.wk.dispose(),
              (this.wk = null)),
          LN(this),
          MN(this));
      }
      dK(a) {
        var b = this.getAttribute("aria-describedby");
        b = (b ? b.split(" ") : []).filter((c) => c !== a);
        b.length > 0
          ? this.setAttribute("aria-describedby", b.join(" "))
          : this.removeAttribute("aria-describedby");
      }
      get map() {
        return this.Gl;
      }
      set map(a) {
        this.setMap(a);
        this.Gl &&
          (a = _.hm(this.Gl)) &&
          this.parentElement !== a &&
          a.append(this);
      }
      setMap(a) {
        this.Gl !== a &&
          ((a = _.Hn(this, "map", _.fl(_.Yk(_.gm, "MapsApiMap")), a)),
          a instanceof _.gm && (a = a.RF),
          a && this.isConnected ? QN(this) : this.dispose(),
          (this.Gl = a),
          this.Ao.set("map", this.Gl),
          this.Gl instanceof _.gm
            ? (this.Gl && FYa(this, this.Gl),
              (this.Zi = this.Gl.__gm),
              ON(this),
              (this.sH = this.Gl.addListener("bounds_changed", () => {
                RN(this);
              })),
              (this.vL = this.Gl.addListener("zoom_changed", () => {
                RN(this);
              })),
              (this.bK = this.Gl.addListener("projection_changed", () => {
                RN(this);
              })),
              (this.zJ = this.Gl.addListener("maptypeid_changed", () => {
                dZa(this);
              })),
              Promise.all([this.Zi.Ih, this.Zi.Jh]).then(([b, c]) => {
                this.Gl === _.ja(b, "map") &&
                  ((this.fJ = c),
                  this.Li.Th(_.ja(b, "map")),
                  (c = this.Zi.Hh),
                  this.nr || _.Jn(c, "ADVANCED_MARKERS").isAvailable) &&
                  ((this.ki = b.ki), dZa(this));
              }),
              eZa(this),
              fZa(this))
            : (this.Zi = null));
      }
      get position() {
        return this.zx;
      }
      set position(a) {
        a = (a = _.Hn(this, "position", _.fl(_.gp), a) || null) && new _.fn(a);
        var b = this.zx;
        bZa(this, a, this.gmpDraggable);
        if (b && a) {
          var c = new _.fn(b, !0);
          let d = new _.fn(a, !0);
          c = !c.equals(d);
        } else c = b !== a;
        c &&
          ((this.qr = (this.zx = a) ? new _.nl(a) : null),
          (this.AF = !0),
          a || SN(this, null),
          this.Ao.set("position", this.qr),
          this.Ao.set("map", _.ja(this, "map")),
          this.nA ? GYa(_.ja(this, "map")) : cZa(this),
          this.an() > 0 && this.Li.Hh(_.ja(this, "map")),
          _.tn(this, "position", b));
      }
      get DO() {
        return this.zx;
      }
      get title() {
        return this.au;
      }
      set title(a) {
        a = _.Hn(this, "title", _.Ap, a);
        var b = this.au;
        a !== this.title &&
          ((this.au = a),
          this.title && this.Li.Mh(_.ja(this, "map")),
          this.title === ""
            ? (this.removeAttribute("aria-label"),
              this.removeAttribute("title"))
            : (this.setAttribute("aria-label", this.title),
              this.setAttribute("title", this.title)),
          this.Wz(),
          _.tn(this, "title", b));
      }
      get zIndex() {
        return this.QC;
      }
      set zIndex(a) {
        a = _.Hn(this, "zIndex", _.fl(_.Aq), a);
        this.QC = a == null ? null : a;
        gZa(this);
        this.zIndex !== null && this.Li.Nh(_.ja(this, "map"));
        KN(this);
      }
      get Py() {
        var a = _.Hl(this, "click"),
          b = _.Hl(this, "gmp-click");
        return a || b || !!this.gmpClickable;
      }
      get BB() {
        return this.Py || !!this.gmpDraggable;
      }
      get Yo() {
        return this.LG;
      }
      set Yo(a) {
        VYa(this);
        this.LG !== a && ((this.LG = a), RN(this));
      }
      get ft() {
        return this.PC;
      }
      set ft(a) {
        if (a !== this.PC) {
          if ((this.PC = a)) (this.pD = this.qD = !1), IN(this);
          _.ja(this, "map") && HYa(this, _.ja(this, "map"));
        }
      }
      get kq() {
        return this.OC;
      }
      set kq(a) {
        a && (this.Bm = null);
        a !== this.OC &&
          ((this.OC = a),
          _.ja(this, "map") && HYa(this, _.ja(this, "map")),
          RN(this),
          _.Sl(this, "UPDATE_BASEMAP_COLLISION"));
      }
      Ay() {
        if (!this.Ml) return null;
        if (!this.Bm)
          for (let c of PN(this)) {
            var a = this.NA;
            let { offset: d, size: e } = iXa(this, c);
            var b = cN(a);
            a = b.offsetY + d.y;
            b = b.offsetX + d.x;
            a = _.Wm(b, a, b + e.width, a + e.height);
            this.Bm ? this.Bm.extendByBounds(a) : (this.Bm = a);
          }
        return this.Bm;
      }
      get Ml() {
        return this.OG;
      }
      set Ml(a) {
        var b = this.OG == null && !!a;
        this.OG = a;
        ZYa(this, b);
      }
      an() {
        return this.zx ? this.zx.altitude : 0;
      }
      hB(a, b, c) {
        return this.Gl
          ? (c = _.VEa(this.Gl.getProjection(), this.qr, c))
            ? (a / c) * Math.sin((b * Math.PI) / 180)
            : 0
          : 0;
      }
      Gq(a, b, c) {
        if (a) {
          if (this.wk) {
            b = this.wk;
            var d = b.Hh;
            b =
              (d = d.Zi ? d.Zi.Xr : null) && b.Mh && b.Kh && !b.Lh
                ? jXa(d, b.Mh)
                : null;
          } else b = null;
          b && (a = b);
          this.Xy = a;
          b = this.ft;
          this.ft = !(
            !c ||
            !(
              Math.abs(a.oi) > c.oi / 2 + 512 || Math.abs(a.si) > c.si / 2 + 512
            )
          );
          (b && this.ft) ||
            (this.iz &&
              _.ja(this, "map") &&
              ((c = _.Sa(_.ja(this, "map"))), (c = BN.get(c)) && BYa(c, this)),
            new _.Dm(a.oi, a.si).equals(this.Ml) ||
              (SN(this, new _.Dm(a.oi, a.si)), this.Ev(this.AF)),
            (this.AF = !1),
            (this.pD = this.qD = !0));
        } else (this.ft = !0), (this.Xy = null), SN(this, null);
      }
      Ev(a) {
        this.Bm = null;
        this.wk && this.wk.Ih && this.wk.Ev(this.Ay());
        KN(this, a);
      }
      ho(a) {
        this.NG !== a &&
          ((this.NG = a),
          this.Ao.set("map", this.NG ? _.ja(this, "map") : null));
      }
      kB() {
        if (!zN(this) || this.kq || !PN(this).length) return null;
        var a = _.ja(this, "map").getProjection();
        if (!a) return null;
        a = a.fromLatLngToPoint(this.qr);
        var b = [];
        for (let f of PN(this)) {
          a: {
            var c = f;
            var d = this.Ml;
            var e = this.NA;
            if (!d) {
              d = { size: new _.Hm(0, 0), offset: new _.Dm(0, 0) };
              break a;
            }
            let { size: k, offset: n } = iXa(this, c);
            c = cN(e);
            d = {
              size: k,
              offset: new _.Dm(c.offsetX - d.x + n.x, c.offsetY - d.y + n.y),
            };
          }
          let { size: g, offset: h } = d;
          d = new iZa(a.x, a.y, g.width, g.height, h.x, h.y);
          b.push(d);
        }
        return b;
      }
      pv() {}
      Zr() {
        return this;
      }
      eJ(a) {
        return !this.position || this.OC || this.ft ? !1 : gXa(a, this);
      }
      Wz() {
        var a = this.Zr();
        this.Yo
          ? a.setAttribute("role", "button")
          : this.title
          ? a.setAttribute("role", "img")
          : a.removeAttribute("role");
      }
      get zl() {
        return this.wk ? this.wk.zl() : !1;
      }
      removeElement() {
        SN(this, null);
        IN(this);
        this.qD &&
          this.ki &&
          this.Al &&
          (this.ki.Rm(this.Al), (this.Al = null));
        this.remove();
        this.iz = !0;
      }
      dispose() {
        if (!this.zE) {
          this.zE = !0;
          try {
            this.Gl && (QN(this), this.removeElement());
          } finally {
            this.zE = !1;
          }
        }
      }
      VF(a) {
        {
          let c = this.Zi?.get("projectionController");
          if (this.Zi && a && c) {
            var b = this.Zi.Xr.getBoundingClientRect();
            a = c.fromContainerPixelToLatLng(
              new _.Dm(a.clientX - b.left, a.clientY - b.top)
            );
          } else a = null;
        }
        a && (this.position = a);
      }
      yp() {
        var a = this.Zi?.get("projectionController");
        if (!this.Zi || !a || !this.qr) return null;
        a = a.fromLatLngToContainerPixel(this.qr);
        var b = this.Zi.Xr.getBoundingClientRect();
        return { clientX: a.x + b.left, clientY: a.y + b.top };
      }
      connectedCallback() {
        super.connectedCallback();
        this.Yj.appendChild(this.nk);
        this.wk && HN(this.wk);
        ON(this);
        if (this.isConnected && this.parentNode) {
          let a = $M(this);
          a
            ? this.setMap(a)
            : (QN(this),
              console.error(
                "AdvancedMarkerElement: parent element must be a <gmp-map>."
              ));
        }
      }
      disconnectedCallback() {
        !this.isConnected && this.pD && (this.map = null);
        this.iz = !0;
        super.disconnectedCallback();
      }
    };
  XN.prototype.addListener = XN.prototype.addListener;
  XN.prototype.addEventListener = XN.prototype.addEventListener;
  XN.prototype.constructor = XN.prototype.constructor;
  XN.Pi = { Ri: 181577, Qi: 181576 };
  _.B(
    [
      _.Qo({ Yh: "anchor-top", type: String, di: !0 }),
      _.D("design:type", Object),
      _.D("design:paramtypes", [Object]),
    ],
    XN.prototype,
    "anchorTop",
    null
  );
  _.B(
    [
      _.Qo({ Yh: "anchor-left", type: String, di: !0 }),
      _.D("design:type", Object),
      _.D("design:paramtypes", [Object]),
    ],
    XN.prototype,
    "anchorLeft",
    null
  );
  _.B(
    [
      _.Qo({ Yh: "gmp-clickable", type: Boolean, di: !0 }),
      _.D("design:type", Object),
      _.D("design:paramtypes", [Object]),
    ],
    XN.prototype,
    "gmpClickable",
    null
  );
  _.B(
    [
      _.Qo({ xi: _.hr, Gj: _.XD, di: !0 }),
      _.D("design:type", Object),
      _.D("design:paramtypes", [Object]),
    ],
    XN.prototype,
    "position",
    null
  );
  _.B(
    [
      _.Qo({ xi: { qk: (a) => a || "", Tj: (a) => a || null }, di: !0 }),
      _.D("design:type", String),
      _.D("design:paramtypes", [String]),
    ],
    XN.prototype,
    "title",
    null
  );
  var tZa = !1,
    uZa = class extends XN {
      constructor(a = {}) {
        super(a);
        if (!WN)
          throw Error(
            "InternalUseAdvancedMarkerView is not allowed to be instantiated directly."
          );
      }
    };
  _.Um("gmp-internal-use-am", uZa);
  var YN = {
    Marker: _.Zq,
    CollisionBehavior: _.Vq,
    Animation: _.Ika,
    PM: () => {},
    mD: function (a, b, c) {
      var d = _.QGa();
      if (b instanceof _.Xq) dYa(a, b, d);
      else {
        let e = new _.Wo();
        dYa(e, b, d);
        let f = new _.Wo();
        c || uYa(f, b, d);
        new mZa(a, f, e, c);
      }
    },
    JH: function (a = {}) {
      WN = !0;
      a = new uZa(a);
      WN = !1;
      return a;
    },
    AdvancedMarkerElement: XN,
    PinElement: _.jA,
    AdvancedMarkerClickEvent: NN,
    AdvancedMarkerView: void 0,
    PinView: void 0,
    connectForExplicitThirdPartyLoad: () => {
      var a = {
        AdvancedMarkerElement: XN,
        PinElement: _.jA,
        AdvancedMarkerClickEvent: NN,
        AdvancedMarkerView: void 0,
        PinView: void 0,
      };
      _.Mk(a);
      _.wa.google.maps.marker = a;
      tZa || ((tZa = !0), _.Um("gmp-advanced-marker", XN));
    },
  };
  _.Nk(YN, ["PM", "mD", "JH", "connectForExplicitThirdPartyLoad"]);
  _.Mk(YN);
  _.ek("marker", YN);
});
