google.maps.__gjsload__("search", function (_) {
  var Lwa = function (a) {
      var b = [];
      a.data.forEach((c) => {
        b.push(...Kwa(c));
      });
      return b;
    },
    Kwa = function (a) {
      var b = _.Mm,
        c = -1;
      _.ja(a.tiles, "forEach").call(a.tiles, (e) => {
        e.zoom > c && ((b = e.ek), (c = e.zoom));
      });
      if (c === -1) return [];
      var d = [];
      a.Kh().forEach((e) => {
        e.a && e.a.length >= 2 && d.push(new Mwa(e, b, c));
      });
      return d;
    },
    Nwa = class extends _.Ul {};
  var Owa = { ["1"]: {} },
    Mwa = class {
      constructor(a, b, c) {
        this.Lp = b;
        this.zoom = c;
        this.bounds = this.anchor = null;
        this.Hh = Owa;
        this.source = a;
        this.featureId = this.source.id || "0";
        this.infoWindowOffset =
          (this.source.io || []).length === 2
            ? new google.maps.Point(this.source.io[0], this.source.io[1])
            : null;
      }
      getAnchor() {
        if (!this.anchor) {
          let a = 1 << this.zoom;
          this.anchor = _.kp(
            new _.wo(
              (this.Lp.x * 256 + this.source.a[0]) / a,
              (this.Lp.y * 256 + this.source.a[1]) / a
            )
          ).toJSON();
        }
        return this.anchor;
      }
      getCompleteBounds() {
        return this.getBounds().reduce((a, b) => {
          a.extendByBounds(b);
          return a;
        }, _.Wm(0, 0, 0, 0));
      }
      getBounds() {
        if (this.bounds === null) {
          this.bounds = [];
          let a = this.source.bb || [];
          if (a.length % 4 === 0)
            for (let b = 0; b < a.length; b += 4) {
              let c = this.bounds[this.bounds.length - 1],
                d = _.Wm(a[b], a[b + 1], a[b + 2], a[b + 3]);
              (c && c.equals(d)) || this.bounds.push(d);
            }
        }
        return [...this.bounds];
      }
      getExtendedContent(a) {
        if (this.Hh === Owa)
          try {
            this.Hh = this.source.c ? JSON.parse(this.source.c) : {};
          } catch (b) {
            this.Hh = {};
          }
        return this.Hh[a] ?? {};
      }
      getFeatureName() {
        return this.getExtendedContent("1")?.title ?? null;
      }
      isTransitStation() {
        return this.getExtendedContent("1")?.is_transit_station ?? !1;
      }
    };
  var Pwa = new WeakSet(),
    bC = class extends Nwa {
      constructor(a) {
        super();
        this.setValues(a);
        this.setOptions = (b) => {
          this.setValues(b);
        };
        _.ck("search_impl");
      }
      changed() {
        var a = this,
          b = this.get("map"),
          c = null;
        b &&
          ((c = b.__gm),
          (b = Number(c.get("blockingLayerCount")) || 0),
          c.set("blockingLayerCount", b + 1),
          c.set(
            "disableLabelingHysteresis",
            this.get("disableLabelingHysteresis")
          ),
          c.set("tilePrefetchEnabled", this.get("tilePrefetchEnabled")));
        _.ck("search_impl").then((d) => {
          d.Hh(a);
          c &&
            ((d = Number(c.get("blockingLayerCount")) || 0),
            c.set("blockingLayerCount", d - 1));
        });
      }
      static enableFeatureMapEventsRasterOnly(a) {
        if (_.jo[15]) {
          var b = a.__gm.ei;
          if (!Pwa.has(a)) {
            Pwa.add(a);
            var c = [],
              d = (f, g) => {
                f = Kwa(f);
                f.length && _.Sl(a, g, f);
              },
              e = () => {
                for (; c.length > 0; ) c.pop().remove();
                b.forEach((f) => {
                  if ((f = f.data))
                    c.push(
                      _.Gl(f, "insert", (g) => {
                        d(g, "addfeatures");
                      })
                    ),
                      c.push(
                        _.Gl(f, "remove", (g) => {
                          d(g, "removefeatures");
                        })
                      );
                });
              };
            b.addListener("insert_at", e);
            b.addListener("remove_at", e);
            b.addListener("set_at", e);
            e();
          }
          (() => {
            var f = [];
            b.forEach((g) => {
              f.push(...Lwa(g));
            });
            f.length && _.Sl(a, "addfeatures", f);
          })();
        }
      }
    };
  bC.enableFeatureMapEventsRasterOnly = bC.enableFeatureMapEventsRasterOnly;
  _.xm(bC.prototype, { map: _.Lq });
  _.wa.google.maps.search = { GoogleLayer: bC };
  _.ek("search", {});
});
