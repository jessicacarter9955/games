google.maps.__gjsload__("streetview", function (_) {
  var bP = function (a) {
      return _.H(a, _.KH, 1);
    },
    I2a = function (a, b) {
      return _.jt(a, 1, cP, b);
    },
    J2a = function (a) {
      return _.ff(a, cP, 1);
    },
    K2a = function (a) {
      return _.Cf(a, cP, 2);
    },
    L2a = function (a) {
      _.cg(a, 1, 75);
    },
    M2a = function (a) {
      return _.cg(a, 2, 96);
    },
    N2a = function (a) {
      return _.Nf(a, 3);
    },
    O2a = function (a, b) {
      _.fg(a, 3, b);
    },
    P2a = function (a) {
      return _.Nf(a, 4);
    },
    Q2a = function (a, b) {
      _.fg(a, 4, b);
    },
    R2a = function (a) {
      return _.sD(a, 1);
    },
    dP = function (a) {
      return _.H(a, _.Oy, 1);
    },
    eP = function (a) {
      return _.H(a, S2a, 3);
    },
    T2a = function (a) {
      return _.F(a, 3);
    },
    V2a = function (a) {
      return _.H(a, U2a, 4);
    },
    W2a = function (a) {
      return _.F(a, 4);
    },
    fP = function (a, b) {
      return _.jg(a, 1, b);
    },
    gP = function (a) {
      return _.ag(a, 2, !0);
    },
    hP = function (a) {
      _.jg(a, 3, 2);
    },
    iP = function (a) {
      return _.gf(a, 1, X2a);
    },
    Y2a = function (a) {
      return _.Kf(a, 1);
    },
    Z2a = function (a) {
      return _.ng(a, 1);
    },
    $2a = function (a) {
      return _.Lf(a, 2);
    },
    a3a = function (a) {
      return _.vD(a, 2);
    },
    b3a = function (a) {
      return _.H(a, _.KH, 1);
    },
    c3a = function (a) {
      return _.Cf(a, _.KH, 3);
    },
    d3a = function (a) {
      return _.H(a, _.KH, 6);
    },
    e3a = function (a) {
      return _.H(a, _.KH, 7);
    },
    f3a = function (a) {
      return _.H(a, _.KH, 8);
    },
    jP = function (a) {
      return _.H(a, g3a, 8);
    },
    h3a = function (a) {
      return _.yf(a, kP, 1);
    },
    j3a = function (a) {
      return _.gf(a, 3, i3a);
    },
    lP = function (a, b) {
      return _.nt(a, 1, b);
    },
    l3a = function (a) {
      return _.yf(a, k3a, 11);
    },
    m3a = function (a) {
      return _.I(a, 1);
    },
    mP = function (a) {
      return _.Of(a, 1);
    },
    n3a = function (a) {
      return _.Nf(a, 4);
    },
    o3a = function (a) {
      return _.og(a, 4);
    },
    p3a = function (a) {
      return _.Kf(a, 1);
    },
    r3a = function (a) {
      return _.H(a, q3a, 2);
    },
    nP = function (a, b) {
      return _.jt(a, 1, s3a, b);
    },
    t3a = function (a) {
      return _.Kf(a, 1);
    },
    u3a = function (a) {
      return _.H(a, g3a, 2);
    },
    v3a = function (a) {
      return _.Kf(a, 1);
    },
    pP = function (a) {
      return _.H(a, oP, 2);
    },
    w3a = function (a) {
      return _.H(a, kP, 2);
    },
    x3a = function (a) {
      return _.H(a, kP, 3);
    },
    z3a = function (a) {
      return _.H(a, y3a, 4);
    },
    A3a = function (a) {
      return _.I(a, 1);
    },
    B3a = function (a) {
      return _.Of(a, 2, 1);
    },
    qP = function (a) {
      return _.H(a, _.Oqa, 1);
    },
    rP = function (a) {
      return _.Kf(a, 1);
    },
    C3a = function (a) {
      _.ag(a, 3, !0);
    },
    D3a = function (a, b) {
      _.jg(a, 1, b);
    },
    F3a = function (a) {
      return _.yf(a, E3a, 1);
    },
    sP = function (a) {
      return _.yf(a, G3a, 11);
    },
    I3a = function (a) {
      return _.yf(a, H3a, 9);
    },
    J3a = function (a) {
      return _.yf(a, _.Oy, 1);
    },
    K3a = function (a, b) {
      return a.Hh.Hh(
        a.Ih +
          "/$rpc/google.internal.maps.mapsjs.v1.MapsJsInternalService/SingleImageSearch",
        b,
        {},
        _.msa
      );
    },
    L3a = function (a) {
      var b = Date.now().toString(36);
      return _.hg(a, 7, b.substr(b.length - 6));
    },
    M3a = function (a) {
      return _.ag(a, 11, !1);
    },
    N3a = function (a, b) {
      var c = M3a(L3a(_.jg(a.Ih, 10, b)));
      _.wD(a.Mh, () => {
        a.Nh(c, (d) => {
          if (!a.Lh && ((_.Tu = a.Lh = !0), d.getStatus() === 0)) {
            var e = _.H(d, _.Ko, 6);
            e = _.If(e, 1) != null ? e.getStatus() : _.Jf(d, 3) ? 1 : 3;
            let f = _.yf(d, _.Ko, 6);
            e === 3
              ? _.ax()
              : e === 2 &&
                (_.If(f, 1) != null || _.Yt(f, _.H(d, _.Ko, 6).getStatus()));
            a.Kh(f);
            _.I(d, 4) && _.Lk(_.I(d, 4));
          }
          _.Uu();
        });
      });
    },
    tP = function (a, b) {
      return a < b ? -1 : a > b ? 1 : 0;
    },
    O3a = function (a, b) {
      var c = 0;
      a = _.yD(String(a)).split(".");
      b = _.yD(String(b)).split(".");
      var d = Math.max(a.length, b.length);
      for (let g = 0; c == 0 && g < d; g++) {
        var e = a[g] || "",
          f = b[g] || "";
        do {
          e = /(\d*)(\D*)(.*)/.exec(e) || ["", "", "", ""];
          f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
          if (e[0].length == 0 && f[0].length == 0) break;
          c =
            tP(
              e[1].length == 0 ? 0 : parseInt(e[1], 10),
              f[1].length == 0 ? 0 : parseInt(f[1], 10)
            ) ||
            tP(e[2].length == 0, f[2].length == 0) ||
            tP(e[2], f[2]);
          e = e[3];
          f = f[3];
        } while (c == 0);
      }
      return c;
    },
    uP = function (a) {
      return _.kCa(P3a, a, function () {
        return O3a(_.Yha, a) >= 0;
      });
    },
    vP = function (a, b) {
      a = _.Lu(b, 360) - _.Lu(a, 360);
      a > 180 ? (a -= 360) : a <= -180 && (a = 360 + a);
      return a;
    },
    Q3a = function (a, b, c = !1) {
      return new _.nl(_.Pj(a), _.Pj(b), c);
    },
    wP = function (a, b) {
      return {
        w: a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z,
        x: a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y,
        y: a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
        z: a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w,
      };
    },
    S3a = function (a, b) {
      if (b == 2) return a;
      if (b == 3) return "F:" + a;
      var c = new _.QG();
      _.jg(c, 1, b);
      _.hg(c, 2, a);
      try {
        return _.$b(R3a(c), 3);
      } catch (d) {
        return _.lCa(
          String.fromCharCode(8) +
            String.fromCharCode(b) +
            String.fromCharCode(18) +
            String.fromCharCode(a.length) +
            a
        );
      }
    },
    T3a = function (a, b, c) {
      _.JFa(b, c);
      c = b.items[c];
      var d = _.Kv(b.Hn.url, !b.Hn.Qy, b.Hn.Qy);
      a = _.sG(d, a, c.segment, b.co, b.anchor, b.Hn.size);
      _.ev(a, _.Mm);
      return a;
    },
    U3a = function (a, b) {
      _.YH.delete(a);
      b &&
        (_.YH.set(a, b),
        _.YH.size > 500 &&
          ((a = _.YH.keys().next().value), a !== void 0 && _.YH.delete(a)));
    },
    yP = function (a) {
      _.eG.call(this, a, xP);
      _.wF(a, xP) ||
        _.vF(
          a,
          xP,
          { options: 0 },
          [
            "div",
            ,
            1,
            0,
            [
              " ",
              [
                "div",
                ,
                ,
                12,
                [
                  "",
                  " ",
                  ["div", 576, 1, 1, "Meeuwstraat 6"],
                  " ",
                  ["div", 576, 1, 2, "Ten Boer, The Netherlands"],
                  " ",
                  [
                    "div",
                    576,
                    1,
                    3,
                    [
                      " ",
                      [
                        "a",
                        ,
                        1,
                        4,
                        [" ", ["div", 576, 1, 5, "Simon Zwarts"], " "],
                      ],
                      " ",
                    ],
                  ],
                  " ",
                ],
              ],
              " ",
              [
                "div",
                576,
                1,
                6,
                [" ", ["a", 576, 1, 7, " View on Google Maps "], " "],
              ],
              " ",
              ["div", 576, 1, 8, " <p>Custom Imagery</p> "],
              " ",
              ["div", 576, 1, 9],
              " ",
              [
                "div",
                576,
                1,
                10,
                ["", " ", ["a", 576, 1, 11, [" ", ["div", , , 13], " "]], " "],
              ],
              " ",
            ],
          ],
          [],
          V3a()
        );
    },
    W3a = function (a) {
      return a.pl;
    },
    X3a = function (a) {
      return _.YE(a.options, (b) => _.at(b, 5));
    },
    Y3a = function (a) {
      return a.On;
    },
    Z3a = function (a) {
      return a.Hr;
    },
    $3a = function () {
      return "address.click";
    },
    a4a = function (a) {
      return _.YE(a.options, (b) => _.at(b, 3));
    },
    b4a = function (a) {
      return !_.YE(a.options, (b) => _.at(b, 4));
    },
    c4a = function (a) {
      return _.WE(a.options, "", (b) => _.I(b, 7));
    },
    V3a = function () {
      return [
        ["$t", "t-bDow0pNywiw", "$a", [7, , , , , "gm-iv-address"]],
        [
          "var",
          function (a) {
            return (a.pl = _.YE(a.options, (b) => _.at(b, 5))
              ? ""
              : _.WE(a.options, "", (b) => _.I(b, 1)));
          },
          "$dc",
          [W3a, !1],
          "$a",
          [7, , , , , "gm-iv-short-address-description"],
          "$a",
          [7, , , X3a, , "gm-iv-hidden"],
          "$c",
          [, , W3a],
        ],
        [
          "var",
          function (a) {
            return (a.On = _.YE(a.options, (b) => _.at(b, 5))
              ? ""
              : _.WE(a.options, "", (b) => _.I(b, 2)));
          },
          "$dc",
          [Y3a, !1],
          "$a",
          [7, , , , , "gm-iv-long-address-description"],
          "$a",
          [7, , , X3a, , "gm-iv-hidden"],
          "$c",
          [, , Y3a],
        ],
        [
          "$a",
          [7, , , , , "gm-iv-profile-url"],
          "$a",
          [
            7,
            ,
            ,
            function (a) {
              return !_.YE(a.options, (b) => _.at(b, 5));
            },
            ,
            "gm-iv-hidden",
          ],
        ],
        [
          "$a",
          [
            8,
            1,
            ,
            ,
            function (a) {
              return _.WE(a.options, "", (b) => _.I(b, 5));
            },
            "href",
            ,
            ,
            1,
          ],
          "$a",
          [0, , , , "_blank", "target", , 1],
        ],
        [
          "var",
          function (a) {
            return (a.Hr = _.WE(a.options, "", (b) => _.I(b, 1)));
          },
          "$dc",
          [Z3a, !1],
          "$a",
          [7, , , , , "gm-iv-profile-link"],
          "$c",
          [, , Z3a],
        ],
        [
          "$a",
          [7, , , , , "gm-iv-address-link"],
          "$a",
          [
            7,
            ,
            ,
            function (a) {
              return !_.YE(a.options, (b) => _.at(b, 3));
            },
            ,
            "gm-iv-hidden",
          ],
          "$a",
          [22, , , , $3a, "jsaction"],
        ],
        [
          "$a",
          [
            8,
            1,
            ,
            a4a,
            function (a) {
              return _.WE(a.options, "", (b) => _.I(b, 3));
            },
            "href",
            ,
            ,
            1,
          ],
          "$a",
          [0, , , , "_blank", "target"],
        ],
        [
          "$a",
          [7, , , , , "gm-iv-address-custom"],
          "$a",
          [7, , , a4a, , "gm-iv-hidden"],
        ],
        [
          "$a",
          [7, , , , , "gm-iv-vertical-separator"],
          "$a",
          [7, , , b4a, , "gm-iv-hidden"],
        ],
        [
          "$a",
          [7, , , , , "gm-iv-marker"],
          "$a",
          [7, , , b4a, , "gm-iv-hidden"],
          "$a",
          [22, , , , $3a, "jsaction"],
        ],
        [
          "$a",
          [7, , , , , "gm-iv-marker-link"],
          "$a",
          [
            8,
            1,
            ,
            function (a) {
              return _.YE(a.options, (b) => _.at(b, 4));
            },
            function (a) {
              return _.WE(a.options, "", (b) => _.I(b, 4));
            },
            "href",
            ,
            ,
            1,
          ],
          "$a",
          [
            0,
            ,
            ,
            function (a) {
              return (
                _.YE(a.options, (b) => _.at(b, 7)) &&
                _.WE(a.options, "", (b) => _.I(b, 7)) != ""
              );
            },
            c4a,
            "aria-label",
            ,
            ,
            1,
          ],
          "$a",
          [0, , , , c4a, "title", , , 1],
          "$a",
          [0, , , , "_blank", "target"],
        ],
        ["$a", [7, , , , , "gm-iv-address-description", , 1]],
        [
          "$a",
          [7, , , , , "gm-iv-marker-icon", , 1],
          "$a",
          [7, , , , , "gm-iv-marker-icon-background", , 1],
        ],
      ];
    },
    zP = function (a) {
      var b = a.get("pov"),
        c = a.Ih,
        d = a.get("pano"),
        e = a.get("location");
      b &&
        e &&
        (e.latLng
          ? ((b = _.IFa(b, e.latLng, d, a.Hh)),
            (b = _.hg(c, 3, b)),
            _.hg(b, 7, "Show location on map"))
          : ((b = _.bf(c, 3)), _.hg(b, 7, "")),
        a.Jh.update([c]));
    },
    d4a = function (a) {
      var b = _.oA.dk();
      _.ag(a, 2, b);
    },
    j4a = function (a, b = !1) {
      _.ws(e4a, a, b);
      _.ws(f4a, a);
      _.ws(g4a, a, b);
      _.ws(h4a, a, b);
      _.ws(i4a, a);
    },
    BP = function (a) {
      _.eG.call(this, a, AP);
      _.wF(a, AP) ||
        _.vF(
          a,
          AP,
          { options: 0 },
          [
            "div",
            ,
            1,
            0,
            [" ", ["button", , 1, 1, [" ", ["div", 576, 1, 2], " "]], " "],
          ],
          [],
          k4a()
        );
    },
    l4a = function (a) {
      return _.WE(a.options, "", (b) => b.getTitle());
    },
    k4a = function () {
      return [
        ["$t", "t-_EPk2VOG1I0", "$a", [7, , , , , "gm-iv-container"]],
        [
          "$a",
          [7, , , , , "gm-iv-close", , 1],
          "$a",
          [0, , , , l4a, "aria-label", , , 1],
          "$a",
          [0, , , , l4a, "title", , , 1],
          "$a",
          [0, , , , "button", "type", , 1],
          "$a",
          [
            22,
            ,
            ,
            ,
            function () {
              return "closeControl.click";
            },
            "jsaction",
            ,
            1,
          ],
        ],
        [
          "$a",
          [7, , , , , "gm-iv-back"],
          "$a",
          [
            7,
            ,
            ,
            function (a) {
              return _.WE(a.options, !1, (b) => b.jB());
            },
            ,
            "gm-iv-back-rtl",
          ],
        ],
      ];
    },
    n4a = function () {
      var a = !1;
      _.Zha && uP("27") && (a = !0);
      _.bia && uP("22") && (a = !0);
      _.cia && uP("15.5") && (a = !0);
      (_.$ha || _.aia) && uP("8.4") && (a = !0);
      _.vaa && uP("15") && (a = !0);
      _.Qb && uP("11") && (a = !0);
      var b;
      if ((b = _.Tha)) b = !(O3a(m4a, "10.8.3") >= 0);
      b && (a = !1);
      b = _.mb();
      _.Kp &&
        b &&
        (b.indexOf("WindowsVista") >= 0 || b.indexOf("Windows NT 6.0") >= 0) &&
        (a = !1);
      _.Kp &&
        b &&
        (b.indexOf("WindowsXP") >= 0 ||
          b.indexOf("Windows XP") >= 0 ||
          b.indexOf("Windows NT 5.1") >= 0) &&
        (a = !1);
      b.indexOf("CrOS armv") >= 0 && (a = !1);
      b.indexOf("CrOS i686") >= 0 && (a = !1);
      return a;
    },
    o4a = function (a) {
      var b = a.get("result");
      if (b) {
        var c = b.copyright || "";
        if (a.get("imageDateControl")) {
          var d;
          a: {
            if ((d = b.imageDate))
              if ((d = _.GCa(d))) {
                d = "Image Date: " + d;
                break a;
              }
            d = void 0;
          }
          d && (c && (c += " - "), (c += d));
        }
        a.set("imageDate", b.imageDate);
        a.set("copyright", c);
        a.set("disabled", b.disabled);
        a.set("floorId", b.MD);
        a.set("floors", b.sN);
        a.set("scene", b.mQ);
        a.set("takeDownUrl", b.takeDownUrl);
      }
    },
    CP = function (a, b) {
      var c = a.get("size"),
        d = a.get("zoom"),
        e = a.Nh,
        f = a.worldSize;
      f &&
        c &&
        _.Dk(d) &&
        _.Dk(e) &&
        ((c = _.Ak(
          Math.ceil(
            _.Ou(c.width / (0.25 * Math.pow(2, 1 - d)) / a.tileSize.width)
          ),
          0,
          e
        )),
        (d = a.get("tileZoom")),
        c !== d || b) &&
        ((b = Math.pow(2, c - e)),
        a.set(
          "worldSize",
          new _.Hm(Math.round(f.width * b), Math.round(f.height * b))
        ),
        a.set("tileZoom", c));
    },
    p4a = function (a) {
      a.Ph && a.get("shouldAutoFocus") && a.Hh.focus();
      a.set("shouldAutoFocus", !1);
    },
    q4a = function (a) {
      a.get("pendingFocus") &&
        a.Hh &&
        (a.get("visible")
          ? a.Hh.focus()
          : console.warn(
              "Setting focus on StreetView was ignored. This is most likely due to StreetView not being visible yet."
            ),
        a.set("pendingFocus", !1));
    },
    s4a = async function (a) {
      await DP(a);
      r4a(a);
      a.Hh || ((a.Jh = !1), a.set("motionTracking", !1), (a.Jh = !0));
      EP(a);
    },
    t4a = function (a) {
      var b = a.get("pov");
      if (a.orientation && b) {
        var c = a.orientation;
        let d = c.w * c.w + c.x * c.x + c.y * c.y + c.z * c.z,
          e = _.Oj(b.heading / 2);
        b = _.Oj(b.pitch / 2);
        a.Ih = wP(
          wP(
            { w: Math.cos(e), x: 0, y: 0, z: -Math.sin(e) },
            { w: Math.cos(b), x: Math.sin(b), y: 0, z: 0 }
          ),
          { w: c.w / d, x: -c.x / d, y: -c.y / d, z: -c.z / d }
        );
      }
    },
    DP = async function (a) {
      if (!a.Hh)
        if (a.Mh)
          try {
            (a.Kh = await window.DeviceOrientationEvent.requestPermission()),
              (a.Hh = a.Kh === "granted");
          } catch (b) {
            a.Hh = !1;
          }
        else a.Hh = !0;
    },
    EP = function (a) {
      var b = a.get("enabled"),
        c = a.get("disableDefaultUI");
      b = a.Nh && (b || (b === void 0 && !c));
      a.container.style.display = b ? "" : "none";
      _.Sl(a.container, "resize");
      a.get("motionTracking") != 0 && b
        ? ((a.button.disabled = !1),
          a.button.classList.add("gm-tracking-on"),
          a.button.setAttribute("aria-pressed", "true"),
          (a.icon.src = _.SH["motion_tracking_on.svg"]))
        : ((b = a.Kh === "denied"),
          (a.button.disabled = b),
          a.button.classList.remove("gm-tracking-on"),
          a.button.setAttribute("aria-pressed", "false"),
          (a.icon.src = b
            ? _.SH["motion_tracking_permission_denied.svg"]
            : _.SH["motion_tracking_off.svg"]));
    },
    r4a = function (a) {
      !a.Lh &&
        a.Hh &&
        (_.Ru(window, "deviceorientation", a, a.Oh),
        _.Ru(window, "orientationchange", a, a.Ph),
        (a.Lh = !0));
    },
    v4a = function (a) {
      var b = a.Ih.next(),
        c = a.Lh,
        d = a.Kh();
      u4a(
        a,
        new _.Kr(
          d.heading + (c.heading - d.heading) * (1 - b),
          c.pitch + (d.pitch - c.pitch) * b,
          c.zoom + (d.zoom - c.zoom) * b
        )
      );
      _.bH(a.Ih)
        ? (a.Hh = window.setTimeout(() => {
            v4a(a);
          }, 0))
        : ((a.Hh = 0), a.set("inMotion", !1));
    },
    u4a = function (a, b) {
      a.Mh = !0;
      a.set("pov", b);
      a.Mh = !1;
    },
    w4a = function (a, b, c, d) {
      var e = a.rs,
        f = a.properties,
        g = b.Un();
      g = b.get("standAlone") ? e : g;
      d.SO(a, f, e, g, c, b.controls, b, b.An);
    },
    x4a = function (a) {
      var b = a.__gm;
      a = b.get("innerContainer");
      var c = new _.WH({
        Os: !1,
        Ps: !1,
        ownerElement: a,
        Ww: !1,
        sx: "street_view",
      });
      b = b.get("ariaDescribedBy");
      c.element.id = b;
      c.element.style.display = "none";
      a.appendChild(c.element);
    },
    B4a = function (a) {
      FP(a, "addressControl", 148996, 148997);
      FP(a, "clickToGo", 148999, 149e3);
      FP(a, "disableDefaultUI", 149003, 149004);
      FP(a, "disableDoubleClickZoom", 149005, 149006);
      FP(a, "enableCloseButton", 149007, 149008);
      FP(a, "imageDateControl", 149009, 149010);
      FP(a, "linksControl", 149014, 149015);
      FP(a, "panControl", 149030, 149031);
      FP(a, "scrollwheel", 149032, 149033);
      FP(a, "zoomControl", 149047, 149048);
      GP(a, "addressControlOptions", y4a);
      GP(a, "panControlOptions", z4a);
      GP(a, "zoomControlOptions", A4a);
    },
    FP = function (a, b, c, d) {
      function e() {
        var f = a.get(b);
        f ? _.nk(a, c) : f == 0 && _.nk(a, d);
      }
      _.Gl(a, b.toLowerCase() + "_changed", e);
      e();
    },
    GP = function (a, b, c) {
      function d() {
        var e = a.get(b);
        e && e.position && (e = c[e.position]) && _.nk(a, e);
      }
      _.Gl(a, b.toLowerCase() + "_changed", d);
      d();
    },
    C4a = function (a) {
      var b = [];
      for (let c = 0, d = a.length; c < d; ++c) {
        let e = a[c];
        for (let f = 0, g = e.length; f < g; f += 2)
          b.push(f ? "L" : "M"),
            b.push(Math.round(e[f] * 10) / 10, Math.round(e[f + 1] * 10) / 10);
      }
      return b.join(" ");
    },
    HP = function (a, b, c, d, e) {
      a = a.addElement(b, "path", d, e);
      a.style.pointerEvents = "all";
      c != null && a.setAttribute("d", c);
      b.appendChild(a);
      return a;
    },
    E4a = function (a, b, c, d) {
      if (c) {
        var e = D4a(a);
        e = a.description ? `${e}, ${a.description}` : e;
        b.tabIndex = 0;
        b.setAttribute("aria-label", e);
        b.setAttribute("role", "button");
        b.setAttribute("pano", c);
        b.setAttribute("cursor", "pointer");
        a.ti.push(
          _.Ml(b, "mouseover", () => {
            d.setAttribute("fill", "#CCFFFF");
            a.set("hovering", !0);
          }),
          _.Ml(b, "focus", () => {
            d.setAttribute("fill", "#CCFFFF");
            a.set("hovering", !0);
          }),
          _.Ml(b, "mouseout", () => {
            d.setAttribute("fill", "white");
            a.set("hovering", !1);
          }),
          _.Ml(b, "blur", () => {
            d.setAttribute("fill", "white");
            a.set("hovering", !1);
          })
        );
      }
    },
    D4a = function (a) {
      a = _.Lu(a.heading, 360);
      return a > 22.5 && a < 67.5
        ? "Go Northeast"
        : a >= 67.5 && a <= 122.5
        ? "Go East"
        : a > 122.5 && a < 157.5
        ? "Go Southeast"
        : a >= 157.5 && a <= 202.5
        ? "Go South"
        : a > 202.5 && a < 247.5
        ? "Go Southwest"
        : a >= 247.5 && a <= 292.5
        ? "Go West"
        : a > 292.5 && a < 337.5
        ? "Go Northwest"
        : "Go North";
    },
    F4a = function (a, b) {
      var c = b.target;
      (c = c && c.getAttribute("pano")) &&
        c !== a.get("pano") &&
        (a.set("pano", c),
        _.yl(b),
        _.El(b),
        _.nk(window, b instanceof KeyboardEvent ? 171233 : 171234));
    },
    G4a = function (a) {
      for (let b of a.Ih) b.release();
      a.Ih.length = 0;
      a.Kh.clear();
    },
    H4a = function (a) {
      var b = a.get("size"),
        c = a.get("pov");
      if (b && c && _.Dk(c.pitch)) {
        c = c.pitch;
        let d = 1;
        c > -30 && (d = c - -30 < 80 ? d + Math.tan(_.Oj(c - -30)) : d + 6);
        a.set("center", new _.Dm(b.width / 2, (b.height / 2) * d));
        a.set("yScale", -Math.sin(_.Oj(Math.min(c, -30))) / d);
      }
    },
    I4a = function (a) {
      a.sort((b, c) => {
        b = vP(0, b.heading || 0);
        c = vP(0, c.heading || 0);
        return Math.abs(b) === Math.abs(c) ? b - c : Math.abs(b) - Math.abs(c);
      });
    },
    IP = function (a, b, c, d) {
      if (!_.bt(b)) {
        if (b.clientX !== void 0) {
          var e = _.lo.Hh
            ? new _.Dm(
                b.pageX - window.pageXOffset,
                b.pageY - window.pageYOffset
              )
            : new _.Dm(b.clientX, b.clientY);
          var f = _.WG(a.Qr, null);
          e = new _.Dm(e.x - f.x, e.y - f.y);
        } else e = _.Mm;
        if ((f = a.get("scrollRequiresCtrlKey"))) {
          if (!(b.ctrlKey || b.altKey || b.metaKey || b.buttons)) {
            f.Hh(1);
            return;
          }
          f.Hh(4);
        }
        if (
          !(
            !e ||
            e.x < 0 ||
            e.y < 0 ||
            e.x > a.Qr.clientWidth ||
            e.y > a.Qr.clientHeight
          )
        ) {
          _.Dl(b);
          _.El(b);
          !a.Hh && d && Math.abs(c % d.ny) > 1e-6 && (a.Hh = !0);
          f = Date.now();
          a.Ih = a.Hh && f - a.Lh > 300 ? c : a.Ih + c;
          d && (a.Lh = f);
          var g;
          !(g = f - a.Kh < (a.Hh ? 300 : 200)) &&
            (g = _.lo.Lh) &&
            ((b = b.target) && b.nodeType === 3 && (b = b.parentNode),
            (g = b.tagName === "HTML"));
          g ||
            c === 0 ||
            (a.Hh && Math.abs(a.Ih) < d.Zx) ||
            ((a.Ih = 0), (a.Kh = f), _.Sl(a, "mousewheel", e, c < 0 ? -1 : 1));
        }
      }
    },
    M4a = function () {
      if (_.lo.Uh) {
        if (_.lo.Mh) return J4a;
        if (_.lo.Hh) return K4a;
        if (_.lo.Lh) return L4a;
      }
      return {};
    },
    N4a = function () {
      if (!window.WebGLRenderingContext) return !1;
      if (JP !== null) return JP;
      var a = document.createElement("canvas");
      if (a.getContext) {
        var b = null,
          c = ["webgl", "experimental-webgl", "webkit-3d", "moz-webgl"];
        for (let d = 0; d < c.length; ++d) {
          try {
            b = a.getContext(c[d]);
          } catch (e) {}
          if (b) break;
        }
        a = b;
      } else a = null;
      return (JP = !!a);
    },
    X4a = function (a, b, c, d) {
      var e = (a.Ih = a.Ih || {});
      e.properties || (e.properties = new _.Ul());
      var f = new _.ZH(_.nD(), a.get("client")),
        g = _.fm();
      a.__gm.set("ariaDescribedBy", g);
      O4a(e, a);
      e.properties.set("zoomRange", new _.Jz(0, 4));
      P4a(e, a);
      Q4a(e, a, f, c, d);
      var h = e.rs;
      a.__gm.get("fontLoaded") === void 0 &&
        a.__gm.bindTo("fontLoaded", new _.Wsa(_.bv(h)));
      var k = a.__gm.get("sloTrackingId");
      _.ck("controls").then(
        (p) => {
          var r = a.Un();
          _.ck("util").then(
            (y) => {
              j4a(r, _.oA.dk());
              a.get("standAlone") &&
                (y.CK.Hh(null),
                y.xr.Hh((A) => {
                  p.AK(r, _.I(A, 2) || "http://g.co/dev/maps-no-account");
                }));
            },
            () => {
              _.kk(k, 13);
            }
          );
          var u = new p.XG(h, a.Lt());
          _.Gl(a, "shouldUseRTLControlsChange", () => {
            u.set("isRTL", a.Lt());
          });
          var w = e.properties;
          w4a(e, a, u, p);
          x4a(a);
          w.get("copyright") &&
            a.set("streetViewDataProviders", w.get("copyright"));
          _.Gl(w, "copyright_changed", () => {
            a.set("streetViewDataProviders", w.get("copyright"));
          });
          R4a(e, a);
          S4a(e, a, u);
          T4a(e, a, u);
          U4a(a, u);
          V4a(e, u);
          w.bindTo("layoutBounds", u, "bounds");
          p.cG(a.Un());
        },
        () => {
          _.kk(k, 13);
        }
      );
      _.Gl(a, "closeclick", () => {
        b.set(!1);
      });
      B4a(a);
      a.get("panoProvider")
        ? _.nk(a, 149002)
        : _.Gl(a, "panoprovider_changed", () => {
            a.get("panoProvider") && _.nk(a, 149002);
          });
      var n = a.getPano();
      _.Gl(a, "pano_changed", () => {
        var p = a.getPano();
        n !== p && ((n = p), _.ND(161531));
      });
      _.ND(161531);
      _.nk(a, 149016);
      _.Nl(
        h,
        "mousedown",
        () => {
          _.nk(a, 149011);
        },
        !0
      );
      return new W4a(c, a);
    },
    Q4a = function (a, b, c, d, e) {
      var f = a.div,
        g = new Y4a(),
        h = new Z4a(),
        k = new Z4a(),
        n = new $4a(),
        p = a.properties;
      n.bindTo("povFinal", p);
      g.bindTo("devZoom", b, "zoom");
      g.bindTo("devPov", b, "pov");
      n.bindTo("pov", g, "internalPov");
      k.bindTo("zoomRange", p);
      k.bindTo("zoom", p, "zoomFinal");
      k.bindTo("heading", p, "headingFinal");
      k.bindTo("pov", p, "povFinal");
      k.bindTo("layoutBounds", p);
      k.bindTo("disableDoubleClickZoom", b);
      h.bindTo("zoomRange", p);
      h.bindTo("zoom", p);
      h.bindTo("heading", p);
      h.bindTo("pov", g, "internalPov");
      _.Rl(b.__gm, "pantobounds", k);
      _.Rl(a, "dblclick", k);
      _.UD(f, "contextmenu", k, !0);
      _.Rl(a, "mousewheel", h);
      g = "webgl";
      _.jo[39] && (g = b.get("mode") || g);
      if (b.get("panoProvider")) {
        let r = b.get("panoProvider");
        (r.options && r.options.cors) || (g = "html5");
      }
      c = a.view = a5a(g, f, c, b, d, e);
      d = b.__gm;
      c.bindTo("ariaDescribedBy", d);
      c.bindTo("imageDateControl", b);
      c.bindTo("clickToGo", b);
      c.bindTo("showRoadLabels", b);
      c.bindTo("scrollwheel", b);
      c.bindTo("panoProvider", b);
      c.bindTo("position", b);
      c.bindTo("pov", h);
      c.bindTo("zoom", h);
      c.bindTo("links", b);
      c.bindTo("location", b);
      c.bindTo("copyright", p);
      c.bindTo("pano", b);
      c.bindTo("result", d);
      c.bindTo("inMotion", n);
      c.bindTo("sloTrackingId", d);
      c.bindTo("isHover", d);
      c.bindTo("shouldAutoFocus", d);
      c.bindTo("pendingFocus", d);
      c.bindTo("visible", b);
      b.bindTo("photographerPov", c);
      b.bindTo("status", c, "status", !0);
      b.bindTo("takeDownUrl", c);
      p.get("heading") != null && d.set("heading", p.get("heading"));
      p.bindTo("heading", d);
      p.bindTo("size", c);
      p.bindTo("pov", c);
      p.bindTo("links", c);
      p.bindTo("pano", c);
      p.bindTo("location", c);
      p.bindTo("description", c);
      p.bindTo("floors", c);
      p.bindTo("floorId", c);
      p.bindTo("disabled", c);
      p.bindTo("headingOffset", c);
      p.bindTo("panoyawdeg", c);
      p.bindTo("position", c);
      p.bindTo("projection", c);
      p.bindTo("tiltyawdeg", c);
      p.bindTo("worldSize", c);
      p.bindTo("imageDate", c);
      p.bindTo("time", c);
      n = a.projection;
      d.bindTo("latLngBounds", c);
      n.bindTo("worldSize", c);
      n.bindTo("size", c);
      n.bindTo("projection", c);
      h.bindTo("projection", c);
      h.bindTo("worldSize", c);
      h.bindTo("size", c);
      k.bindTo("projection", c);
      k.bindTo("worldSize", c);
      k.bindTo("size", c);
      _.Rl(c, "iv_renderstable", b);
      _.Rl(b, "resize", c);
      _.Rl(d, "panoramavisible", c);
      _.Rl(a.rs, "resize", c);
      _.UD(window, "resize", c);
      _.UD(a.rs, "keydown", b);
    },
    O4a = function (a, b) {
      var c = b.Un(),
        d = new _.nta({ container: c, XH: b.bq, MH: !1, XF: !1 });
      _.UD(window, "resize", c);
      _.Rl(c, "resize", d.Hh);
      a.div = d.rq;
      a.rs = d.Hh;
      d.mq.style.backgroundColor = c.style.backgroundColor;
      _.gv(d.Hh, 1);
      d.Hh.style.display = b.Hh.get() ? "" : "none";
      _.Gl(b, "visible_changed", () => {
        var e = !!b.getVisible();
        d.Hh.style.display = e ? "" : "none";
        e
          ? (_.Sl(b, "resize"), _.Sl(b.__gm, "panoramavisible"))
          : _.Sl(b.__gm, "panoramahidden");
      });
      b.__gm.set("panes", d.Gn);
      b.__gm.set("innerContainer", d.mq);
      a = new _.cI();
      _.Gl(a, "sizechange", () => {
        _.Sl(d.Hh, "resize");
      });
      d.Hh.appendChild(a.element);
    },
    P4a = function (a, b) {
      function c() {
        b.set(
          "projection",
          d.get("pov") &&
            d.get("position") &&
            d.get("worldSize") &&
            d.get("size") &&
            d
        );
      }
      var d = (a.projection = new b5a());
      d.bindTo("position", b);
      d.bindTo("pov", b);
      d.bindTo("zoom", b);
      a = b.__gm;
      a.set("offset", new _.Hm(0, 0));
      a.set("zoom", 0);
      a.set("projectionTopLeft", new _.Dm(0, 0));
      ["position", "pov", "worldSize", "size"].forEach((e) => {
        _.Gl(d, e.toLowerCase() + "_changed", c);
      });
    },
    R4a = function (a, b) {
      var c = a.div;
      c.style.msTouchAction = c.style.touchAction = "none";
      var d = new c5a(c);
      d.bindTo("enabled", b, "scrollwheel");
      _.Rl(d, "mousewheel", a);
      var e = _.fv("div", c, _.Mm);
      e.className = "gmnoprint";
      _.gv(e, 2);
      _.ck("geometry").then(() => {
        function f() {
          var h = b.get("linksControl"),
            k = b.get("disableDefaultUI");
          (h === void 0 && !k) || h
            ? g.bindTo("links", a.properties)
            : (g.unbind("links"), g.set("links", null));
        }
        var g = (a.linksControl = new d5a(e));
        g.bindTo("pov", a.properties);
        g.bindTo("pano", a.properties);
        g.bindTo("size", a.properties);
        g.bindTo("worldSize", a.properties);
        g.bindTo("pendingPanoramaFocus", b.__gm, "pendingFocus");
        a.view.bindTo("linksHovering", g, "hovering");
        f();
        _.Gl(b, "linkscontrol_changed", f);
        _.Gl(b, "disabledefaultui_changed", f);
      });
    },
    KP = function (a, b) {
      var c = a.get("addressControl");
      a = a.get("disableDefaultUI");
      b.style.display = (c === void 0 && !a) || c ? "" : "none";
      _.Sl(b, "resize");
    },
    LP = function (a, b, c) {
      a = a.get("addressControlOptions");
      b.removeElement(c);
      b.addElement(c, (a && a.position) || 14);
    },
    T4a = function (a, b, c) {
      var d = document.createElement("div");
      KP(b, d);
      LP(b, c, d);
      _.aE(d);
      _.Gl(b, "addresscontrol_changed", _.iD(KP, b, d));
      _.Gl(b, "addresscontroloptions_changed", _.iD(LP, b, c, d));
      _.Gl(b, "disabledefaultui_changed", _.iD(KP, b, d));
      c = new _.XH(yP, { div: d, Dt: _.oA.dk() });
      c = new e5a(c);
      c.bindTo("location", a.properties);
      c.bindTo("pano", a.properties);
      c.bindTo("pov", a.properties);
      c.bindTo("options", b, "addressControlOptions");
      c.bindTo("result", b.__gm);
    },
    f5a = function (a, b, c) {
      a = a.get("motionTrackingControlOptions");
      b.removeElement(c);
      b.addElement(c, (!!a && a.position) || 22);
    },
    S4a = function (a, b, c) {
      if (!a.MM) {
        let d = document.createElement("div");
        d.style.zIndex = "24601";
        d.style.display = "";
        _.Sl(d, "resize");
        LP(b, c, d);
        _.aE(d);
        _.Gl(b, "addresscontroloptions_changed", _.iD(LP, b, c, d));
        a = a.MM = new g5a(new _.XH(BP, { div: d, Dt: b.Lt() }));
        a.bindTo("enableCloseButton", b);
        _.Rl(a, "closeclick", b);
      }
    },
    U4a = function (a, b) {
      var c = document.createElement("div");
      f5a(a, b, c);
      _.Gl(a, "motiontrackingcontroloptions_changed", _.iD(f5a, a, b, c));
      b = a.Un();
      var d = _.uo(!1);
      _.Ml(b, "touchstart", () => {
        d.set(!0);
      });
      _.Ml(b, "touchend", () => {
        d.set(!1);
      });
      c = new h5a(c, d, a.get("controlSize") || 40);
      c.bindTo("enabled", a, "motionTrackingControl");
      c.bindTo("disableDefaultUI", a);
      c.bindTo("pov", a);
      c.bindTo("motionTracking", a);
    },
    V4a = function (a, b) {
      var c = document.createElement("div");
      new i5a(c).bindTo("disabled", a.view);
      b.addElement(c, 13);
    },
    a5a = function (a, b, c, d, e, f) {
      (n4a() && N4a()) || (a = "html5");
      return new j5a(b, c, e, a, f, (g) => {
        _.nk(d, g ? 149013 : 149012);
      });
    },
    l5a = function (a) {
      if (!a.Hh) {
        let b = new _.IHa();
        a.Hh = new k5a(b);
        a.Hh.bindTo("map", a);
      }
      (a = a.get("map")) && _.nk(a, 149001);
    },
    r5a = function (a, b, c) {
      var d = "",
        [e] = K2a(_.H(a, _.Ny, 5));
      if (e?.Ih()) d += "\u00a9 " + bP(e).zi();
      else {
        for (var f = 0; f < J2a(_.H(a, _.Ny, 5)); ++f)
          d += " " + bP(I2a(_.H(a, _.Ny, 5), f)).zi();
        d = d.substring(1);
      }
      var g = new _.nl(
          N2a(dP(pP(_.jt(a, 6, MP, 0)))),
          P2a(dP(pP(_.jt(a, 6, MP, 0))))
        ),
        h =
          d3a(_.H(a, NP, 4)).zi() ||
          e3a(_.H(a, NP, 4)).zi() ||
          b3a(_.H(a, NP, 4)).zi() ||
          f3a(_.H(a, NP, 4)).zi(),
        k = h;
      h ||
        ((f = c3a(_.H(a, NP, 4))),
        f.length && ((k = f[0].zi()), (h = f.map((C) => C.zi()).join(", "))));
      !h && e && (k = h = bP(e).zi());
      f = _.H(a, _.QG, 2);
      f = OP(f);
      h = { latLng: g, shortDescription: k, description: h, pano: f };
      e?.fn() && (h.aK = e.getUrl());
      _.ff(a, m5a, 18) > 0 && (h.UK = _.jt(a, 18, m5a, 0).getUrl());
      var n = 0,
        p = 0;
      e = [];
      var r;
      k = [];
      var u = [],
        w = [],
        y = {};
      y[f] = { lat: g.lat(), lng: g.lng() };
      for (let C = 0; C < _.ff(a, MP, 6); ++C) {
        let ka = _.jt(a, 6, MP, C);
        T2a(pP(ka)) &&
          ((n = eP(pP(ka)).getHeading()),
          (p = eP(pP(ka)).getTilt()),
          eP(pP(ka)));
        W2a(pP(ka)) && (r = String(R2a(V2a(pP(ka)))));
        for (var A = 0; A < _.ff(ka, PP, 7); ++A) {
          var J = p3a(_.jt(ka, 7, PP, A)),
            M = nP(_.H(ka, QP, 4), J);
          J = OP(_.H(M, _.QG, 1));
          var [T] = c3a(_.H(M, NP, 4));
          T = T?.zi() || "";
          var R = new _.nl(N2a(dP(_.H(M, oP, 3))), P2a(dP(_.H(M, oP, 3))));
          o3a(r3a(_.jt(ka, 7, PP, A)))
            ? ((M = n3a(r3a(_.jt(ka, 7, PP, A)))),
              (R = _.pD(g, R)),
              (R = c(g, R, M)))
            : (M = b(g, R));
          y[J] = { lat: R.lat(), lng: R.lng() };
          e.push({ description: T, heading: M, pano: J });
        }
        for (A = 0; A < _.ff(ka, n5a, 8); ++A)
          (J = v3a(_.jt(ka, 8, n5a, A))),
            (J = nP(_.H(ka, QP, 4), J)),
            (T = V2a(_.H(J, oP, 3))),
            k.push({
              bH: _.H(T, _.KH, 4).zi(),
              description: _.H(T, _.KH, 3).zi(),
              MD: String(R2a(T)),
              cC: _.Nf(T, 2),
              rF: OP(_.H(J, _.QG, 1)),
            });
        k.sort((Ga, Oa) => Ga.cC - Oa.cC);
        for (A = 0; A < _.ff(ka, o5a, 13); ++A)
          for (J = _.jt(ka, 13, o5a, A), T = 0; T < _.tD(J, 2); ++T)
            w.push(_.cCa(J, 2, T));
        for (A = 0; A < _.ff(ka, RP, 9); ++A)
          (J = t3a(_.jt(ka, 9, RP, A))),
            (J = nP(_.H(ka, QP, 4), J)),
            (J = OP(_.H(J, _.QG, 1))),
            (T = Y2a(u3a(_.jt(ka, 9, RP, A)))),
            (M = $2a(u3a(_.jt(ka, 9, RP, A)))),
            u.push({ pano: J, xD: new Date(T, M - 1, 1) });
      }
      c = b = "";
      g = 0;
      Z2a(jP(_.H(a, SP, 7))) &&
        ((b = c = Y2a(jP(_.H(a, SP, 7))).toString()),
        a3a(jP(_.H(a, SP, 7))) &&
          ((b += "-"),
          (g = $2a(jP(_.H(a, SP, 7)))),
          g < 10 && (b += "0"),
          (b += `${g}`)));
      u.push({ pano: f, xD: new Date(Number(c), g - 1, 1) });
      u.sort((C, ka) => C.xD.getTime() - ka.xD.getTime());
      c = new _.Hm(x3a(_.H(a, TP, 3)).Yi(), x3a(_.H(a, TP, 3)).Ui());
      g = new _.Hm(w3a(z3a(_.H(a, TP, 3))).Yi(), w3a(z3a(_.H(a, TP, 3))).Ui());
      c = {
        centerHeading: n,
        originHeading: n,
        originPitch: p - 90,
        tileSize: g,
        worldSize: c,
      };
      g = B3a(_.H(a, p5a, 8)) === 1;
      n = A3a(_.H(a, p5a, 8));
      U3a(f, m3a(_.H(a, q5a, 22)));
      return {
        copyright: d,
        imageDate: b,
        location: h,
        links: e,
        tiles: c,
        disabled: !g,
        MD: r,
        dP: y,
        sN: k,
        takeDownUrl: n,
        time: u,
      };
    },
    OP = function (a) {
      var b = a.getId();
      a = _.Of(a, 1);
      return S3a(b, a);
    },
    t5a = function (a, b) {
      var c = new _.Qy();
      s5a(c, b);
      b = _.gf(c, 3, _.Nqa);
      b = _.yf(b, _.QG, 1);
      a = _.RG(a);
      var d = a.getId();
      b = _.hg(b, 2, d);
      a = _.Of(a, 1);
      _.jg(b, 1, a);
      return c;
    },
    u5a = function (a, b, c) {
      var d = new _.Uy();
      s5a(d, c);
      var e = a.sources ? [...a.sources] : a.source ? [a.source] : ["default"];
      hP(gP(fP(iP(sP(_.yf(d, UP, 3))), 2)));
      c ||
        e.includes("google") ||
        (hP(gP(fP(iP(sP(_.yf(d, UP, 3))), 3))),
        hP(gP(fP(iP(sP(_.yf(d, UP, 3))), 10))));
      var f = a.location;
      c = _.Bk(f.lng(), -180, 180);
      f = _.Ak(f.lat(), -90, 90);
      O2a(J3a(_.yf(d, _.Ty, 2)), f);
      Q2a(J3a(_.yf(d, _.Ty, 2)), c);
      var g = _.Ak(a.radius != null ? a.radius : 50, 0, 6378137 * Math.PI);
      _.yf(d, _.Ty, 2).setRadius(g);
      if (isNaN(f) || isNaN(c) || isNaN(g))
        return (
          _.RD(() => {
            b(null, "ZERO_RESULTS");
          }),
          null
        );
      D3a(I3a(_.yf(d, UP, 3)), a.preference === "best" ? 1 : 2);
      e.includes("outdoor") && C3a(F3a(_.yf(d, UP, 3)));
      a.jK && (lP(d.Ih(), 17), L2a(M2a(h3a(j3a(l3a(d.Ih()))))));
      return d;
    },
    s5a = function (a, b) {
      var c = a.Kh();
      _.hg(c, 1, _.jo[43] ? "maps_sv.tactile_lite" : "apiv3");
      b !== void 0 && _.uD(c, 3, "" + b);
      _.iH(_.Uy)(a)
        ? ((b = _.yf(a, UP, 3)), (b = _.yf(b, v5a, 2)))
        : (b = _.yf(a, v5a, 2));
      var [d, e] = _.fk.Ih().Ih().split("-");
      b.Cj(d);
      e && _.hg(b, 2, e);
      b = _.fk.Ih().Kh();
      _.hg(c, 5, b);
      c = _.yf(c, w5a, 11);
      c = _.yf(c, x5a, 1);
      _.ag(c, 1, !!_.jo[56]);
      lP(lP(lP(lP(lP(lP(a.Ih(), 1), 2), 3), 4), 8), 6);
      (c = _.hv()) && a.Mh(c);
    },
    y5a = function (a, b, c, d, e) {
      return (f, g, h) => {
        _.gH(a);
        a && (f = g(f));
        var k = new Promise((n, p) => {
          f = g(f);
          h(
            f,
            (r, u) => {
              a && a(r, u);
              if (u === "OK") n({ data: r });
              else {
                a: switch (u) {
                  case "ZERO_RESULTS":
                    r = new _.Gp(
                      "There are no panoramas found that match the search criteria.",
                      "STREETVIEW_GET_PANORAMA",
                      u
                    );
                    break a;
                  default:
                    r = new _.Hp(
                      "The request could not be successfully processed, yet the exact reason for failure is unknown.",
                      "STREETVIEW_GET_PANORAMA",
                      u
                    );
                }
                p(r);
              }
            },
            b,
            c,
            d,
            e
          );
        });
        return a ? k.catch(() => {}) : k;
      };
    },
    B5a = function (a, b, c, d, e, f) {
      b = y5a(b, c, d, e, f);
      return "pano" in a
        ? b(a, z5a, VP.Lh.bind(VP))
        : b(
            a,
            (g) => {
              try {
                let h = A5a(g);
                if (h.source && h.sources)
                  throw _.Uk('Only one of "source" or "sources" is allowed.');
                return h;
              } catch (h) {
                throw (_.lk(f), h);
              }
            },
            VP.Nh.bind(VP)
          );
    },
    C5a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    D5a = class extends _.K {
      constructor(a) {
        super(a);
      }
      getAttribution() {
        return _.Bf(this, C5a, 4);
      }
      setAttribution(a) {
        return _.Ef(this, C5a, 4, a);
      }
    };
  _.Qy.prototype.Mh = _.ha(52, function (a) {
    _.hg(this, 5, a);
  });
  _.Uy.prototype.Mh = _.ha(51, function (a) {
    _.hg(this, 9, a);
  });
  _.Qy.prototype.Ih = _.ha(50, function () {
    return _.yf(this, D5a, 4);
  });
  _.Uy.prototype.Ih = _.ha(49, function () {
    return _.yf(this, D5a, 4);
  });
  _.Qy.prototype.Kh = _.ha(48, function () {
    return _.yf(this, _.Py, 1);
  });
  _.Uy.prototype.Kh = _.ha(47, function () {
    return _.yf(this, _.Py, 1);
  });
  var E5a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    cP = class extends _.K {
      constructor(a) {
        super(a);
      }
      getName() {
        return _.Bf(this, _.KH, 1);
      }
      Ih() {
        return _.F(this, 1);
      }
      getUrl() {
        return _.I(this, 2);
      }
      setUrl(a) {
        return _.hg(this, 2, a);
      }
      fn() {
        return _.at(this, 2);
      }
    },
    kP = class extends _.K {
      constructor(a) {
        super(a);
      }
      Ui() {
        return _.Kf(this, 1);
      }
      Yi() {
        return _.Kf(this, 2);
      }
    },
    U2a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    S2a = class extends _.K {
      constructor(a) {
        super(a);
      }
      getHeading() {
        return _.Nf(this, 1);
      }
      setHeading(a) {
        return _.fg(this, 1, a);
      }
      getTilt() {
        return _.Nf(this, 2, 90);
      }
      setTilt(a) {
        return _.fg(this, 2, a);
      }
      yo() {
        return _.Nf(this, 3);
      }
    },
    oP = class extends _.K {
      constructor(a) {
        super(a);
      }
      hq() {
        return _.Bf(this, S2a, 3);
      }
    },
    F5a = class extends _.K {
      constructor(a) {
        super(a);
      }
      getLocation() {
        return _.Bf(this, oP, 1);
      }
    },
    X2a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    G3a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    g3a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    NP = class extends _.K {
      constructor(a) {
        super(a);
      }
      getTitle() {
        return _.Bf(this, _.KH, 1);
      }
      setTitle(a) {
        return _.Ef(this, _.KH, 1, a);
      }
    },
    SP = class extends _.K {
      constructor(a) {
        super(a);
      }
      Ih() {
        return _.Of(this, 3);
      }
      Ol(a) {
        return _.jg(this, 3, a);
      }
    },
    v5a = class extends _.K {
      constructor(a) {
        super(a);
      }
      Cj(a) {
        return _.hg(this, 1, a);
      }
      Il() {
        return _.at(this, 1);
      }
    },
    i3a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    k3a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    x5a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    w5a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    q5a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    q3a = class extends _.K {
      constructor(a) {
        super(a);
      }
      getLocation() {
        return _.Of(this, 1);
      }
    },
    PP = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    s3a = class extends _.K {
      constructor(a) {
        super(a);
      }
      Hj() {
        return _.Bf(this, F5a, 2);
      }
      Dm(a) {
        return _.Ef(this, F5a, 2, a);
      }
      getLocation() {
        return _.Bf(this, oP, 3);
      }
    },
    QP = class extends _.K {
      constructor(a) {
        super(a);
      }
      setTarget(a, b) {
        return _.hf(this, 1, s3a, a, b);
      }
    },
    RP = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    n5a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    o5a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    MP = class extends _.K {
      constructor(a) {
        super(a);
      }
      getLocation() {
        return _.Bf(this, oP, 2);
      }
    },
    G5a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    y3a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    TP = class extends _.K {
      constructor(a) {
        super(a);
      }
      getPanorama() {
        return _.Bf(this, G5a, 5);
      }
    },
    p5a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    m5a = class extends _.K {
      constructor(a) {
        super(a);
      }
      getUrl() {
        return _.I(this, 1);
      }
      setUrl(a) {
        return _.hg(this, 1, a);
      }
      fn() {
        return _.at(this, 1);
      }
      getSize() {
        return _.Bf(this, kP, 2);
      }
      setSize(a) {
        return _.Ef(this, kP, 2, a);
      }
    },
    E3a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    H3a = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    UP = class extends _.K {
      constructor(a) {
        super(a);
      }
    },
    P3a = {},
    R3a = _.FD(_.sy);
  _.ab(yP, _.hG);
  yP.prototype.fill = function (a) {
    _.fG(this, 0, a);
  };
  var xP = "t-bDow0pNywiw";
  var H5a = class extends _.K {
    constructor(a) {
      super(a);
    }
  };
  var e5a = class extends _.Ul {
    constructor(a) {
      var b = _.fk.Ih();
      super();
      _.jE();
      this.Ih = new H5a();
      this.Jh = a;
      a.addListener("address.click", "click", (c) => {
        _.nk(window, _.dE(c) ? 171382 : 171381);
      });
      this.Kh = `?hl=${b.Ih().replace("_", "-")}&gl=${b.Kh()}`;
      this.Hh = _.I(b, 15);
    }
    pano_changed() {
      zP(this);
    }
    pov_changed() {
      zP(this);
    }
    location_changed() {
      var a = this.Ih,
        b = this.get("location");
      if (b) {
        _.bf(a, 5);
        b.aK && _.hg(a, 5, b.aK);
        if (b.latLng) {
          var c = `${this.Hh}/@${b.latLng.lat()},${b.latLng.lng()},13z${
            this.Kh
          }`;
          _.hg(a, 4, c);
        } else _.bf(a, 4);
        var d = "Untitled";
        c = "";
        b.description &&
          ((d = b.shortDescription),
          (c = b.description),
          c.indexOf(d) === 0 &&
            ((c = c.slice(d.length)),
            (b = c.match(/^[,.!;\s]*/)),
            (c = c.slice(b[0].length))));
        a = _.hg(a, 1, d || "");
        _.hg(a, 2, c);
        zP(this);
      }
    }
  };
  var I5a = class extends _.K {
    constructor(a) {
      super(a);
    }
    jB() {
      return _.Jf(this, 2);
    }
    getTitle() {
      return _.I(this, 3);
    }
    setTitle(a) {
      return _.hg(this, 3, a);
    }
  };
  var g5a = class extends _.Ul {
    constructor(a) {
      super();
      this.layout = a;
      var b = new I5a();
      d4a(b);
      b.setTitle("Exit the Street View");
      a.update([b]);
      a.addListener("closeControl.click", "click", (c) => {
        _.Sl(this, "closeclick");
        _.nk(window, _.dE(c) ? 171395 : 171394);
      });
    }
    enableCloseButton_changed() {
      var a = !!this.get("enableCloseButton");
      _.ZD(this.layout.div, a);
      _.Sl(this.layout.div, "resize");
    }
  };
  var e4a = (0,
  _.Wh)`.gm-iv-address-description{display:inline-block;min-width:137px;max-width:340px;vertical-align:top;position:relative;padding-right:30px;-webkit-box-sizing:border-box;box-sizing:border-box}.gm-iv-short-address-description{color:#fff;font-weight:700;font-size:12px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;padding-bottom:2px}.gm-iv-long-address-description{color:#ccc;font-weight:400;font-size:11px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;min-width:70px}.gm-iv-vertical-separator{display:inline-block;height:56px;position:absolute;right:28px;top:10px;width:1px;background:-webkit-gradient(linear,left bottom,left top,from(#404040),color-stop(#666),to(#404040));background:-webkit-linear-gradient(bottom,#404040,#666,#404040);background:linear-gradient(0deg,#404040,#666,#404040)}.gm-iv-marker{display:inline-block;height:22px;position:absolute;right:8px;top:27px;width:14px}.gm-iv-marker-icon-background{background-image:url(https://maps.gstatic.com/mapfiles/api-3/images/sv9.png);-webkit-background-size:164px 175px;background-size:164px 175px}.gm-iv-horizontal-separator{height:1px;margin-bottom:6px;margin-left:-8px;margin-right:-8px;background:-webkit-gradient(linear,right top,left top,from(#404040),color-stop(#666),to(#404040));background:-webkit-linear-gradient(right,#404040,#666,#404040);background:linear-gradient(270deg,#404040,#666,#404040)}.gm-iv-address-link{position:absolute;top:48px}.gm-iv-address-custom p{color:#777;text-decoration:none;font-size:11px}.gm-iv-address-link a{color:#aecbfa;text-decoration:none;font-size:11px}.gm-iv-address-link a:hover{text-decoration:underline}.gm-iv-profile-link{color:#fff;font-weight:700;font-size:12px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.gm-iv-profile-url a\u003e.iv-profile-link:hover{text-decoration:underline}.gm-iv-profile-url a{text-decoration:none}@media (-webkit-min-device-pixel-ratio:1.2),(-webkit-min-device-pixel-ratio:1.2083333333333333),(min-resolution:1.2dppx),(min-resolution:116dpi){.gm-iv-marker-icon-background{background-image:url(https://maps.gstatic.com/mapfiles/api-3/images/sv9_hdpi.png)}}.gm-iv-hidden{display:none}sentinel{}\n`;
  var f4a = (0,
  _.Wh)`.gm-iv-address{background-color:#222;opacity:.8;font-family:Roboto,Arial,sans-serif;border-bottom-right-radius:2px;border-top-right-radius:2px;display:inline-block;padding:6px 8px;margin-top:10px;height:56px;-webkit-box-sizing:border-box;box-sizing:border-box}.gm-iv-marker-icon{background-position:-17px -48px;height:22px;overflow:hidden;width:14px}.gm-iv-marker-link:focus\u003e.gm-iv-marker-icon,.gm-iv-marker-link:hover\u003e.gm-iv-marker-icon{background-position:-1px -48px}sentinel{}\n`;
  var g4a = (0,
  _.Wh)`.gm-iv-container{-webkit-box-align:center;-webkit-align-items:center;align-items:center;background-color:#222;border-right:1px solid #666;display:-webkit-box;display:-webkit-flex;display:flex;font-family:Roboto,Arial,sans-serif;margin-top:10px;opacity:.8;width:27px;height:56px}[dir=rtl] .gm-iv-container{border-left:1px solid #666;border-right:none}.gm-iv-close{-webkit-box-align:center;-webkit-align-items:center;align-items:center;background:transparent;border:none;cursor:pointer;display:-webkit-box;display:-webkit-flex;display:flex;height:27px;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;margin:0;outline-offset:-2px;padding:0;width:27px}.gm-iv-back{background:transparent url(https://maps.gstatic.com/mapfiles/api-3/images/sv9.png) no-repeat -2px -73px;-webkit-background-size:164px 175px;background-size:164px 175px;height:12px;width:15px}.gm-iv-close:focus\u003e.gm-iv-back,.gm-iv-close:hover\u003e.gm-iv-back{background-position-x:-39px}.gm-iv-close\u003e.gm-iv-back.gm-iv-back-rtl{background-position-x:-137px}.gm-iv-close:focus\u003e.gm-iv-back.gm-iv-back-rtl,.gm-iv-close:hover\u003e.gm-iv-back.gm-iv-back-rtl{background-position-x:-100px}@media (-webkit-min-device-pixel-ratio:1.2),(-webkit-min-device-pixel-ratio:1.2083333333333333),(min-resolution:1.2dppx),(min-resolution:116dpi){.gm-iv-back{background-image:url(https://maps.gstatic.com/mapfiles/api-3/images/sv9_hdpi.png);background-position-y:-72px}}sentinel{}\n`;
  var h4a = (0,
  _.Wh)`.gm-style .gm-compass-icon{background-image:url(https://maps.gstatic.com/mapfiles/api-3/images/sv9.png);-webkit-background-size:164px 175px;background-size:164px 175px}@media (-webkit-min-device-pixel-ratio:1.2),(-webkit-min-device-pixel-ratio:1.2083333333333333),(min-resolution:1.2dppx),(min-resolution:116dpi){.gm-style .gm-compass-icon{background-image:url(https://maps.gstatic.com/mapfiles/api-3/images/sv9_hdpi.png)}.gm-style.gm-china .gm-compass-icon{background-image:url(http://maps.gstatic.cn/mapfiles/api-3/images/sv9_hdpi.png)}}.gm-compass-background{height:48px;width:48px;overflow:hidden;position:absolute}.gm-compass{position:relative;width:48px;height:48px}.gm-compass-needle{cursor:pointer;background-color:transparent;border:0 none;height:48px;left:14px;overflow:hidden;padding:0;position:absolute;top:0;width:20px}.gm-control-active.gm-compass-needle{-webkit-transform:var(--gm-compass-control-rotation-degree,0);-ms-transform:var(--gm-compass-control-rotation-degree,0);transform:var(--gm-compass-control-rotation-degree,0)}sentinel{}\n`;
  var i4a = (0,
  _.Wh)`.gm-compass-turn{cursor:pointer;background-color:transparent;border:0 none;height:48px;left:0;overflow:hidden;padding:0;position:absolute;top:0;width:14px;z-index:1}.gm-compass-turn-opposite{-ms-transform:scaleX(-1);-ms-transform-origin:24px 0;-moz-transform:scaleX(-1);-moz-transform-origin:24px 0;-webkit-transform:scaleX(-1);-webkit-transform-origin:24px 0;transform:scaleX(-1);transform-origin:24px 0}.gm-compass:hover .gm-compass-arrow-right,.gm-compass:hover .gm-compass-tooltip-text{opacity:1;-webkit-transition-delay:1.5s;transition-delay:1.5s}.gm-compass-tooltip-text{opacity:0;background-color:#222;width:112px;height:23px;line-height:23px;right:58px;top:7px;position:absolute;border:1px solid #ccc;text-align:center;color:#ccc;font-family:Roboto,Arial;font-size:12px;font-weight:700}.gm-compass-arrow-right{opacity:0;width:0;height:0;border-top:7px solid transparent;border-bottom:7px solid transparent;top:16px;position:absolute}.gm-compass-arrow-right-outer{right:52px;border-left:7px solid #ccc}.gm-compass-arrow-right-inner{right:53px;border-left:7px solid #222}sentinel{}\n`;
  _.ab(BP, _.hG);
  BP.prototype.fill = function (a) {
    _.fG(this, 0, a);
  };
  var AP = "t-_EPk2VOG1I0";
  var i5a = class extends _.Ul {
    constructor(a) {
      super();
      _.cv("This image is no longer available", a);
      a.style.color = "white";
      a.style.fontFamily = "Roboto,Arial,sans-serif";
      a.style.backgroundColor = "black";
      a.style.padding = _.Jk(4);
      a.style.border = _.Jk(2) + " solid white";
      _.ro(a);
      _.aE(a);
      this.div = a;
    }
    disabled_changed() {
      this.div.style.display = this.get("disabled") ? "" : "none";
    }
  };
  var m4a = (function () {
    if (_.Kp) {
      var a = /Windows NT ([0-9.]+)/;
      return (a = a.exec(_.mb())) ? a[1] : "0";
    }
    return _.Tha
      ? ((a = /1[0|1][_.][0-9_.]+/),
        (a = a.exec(_.mb())) ? a[0].replace(/_/g, ".") : "10")
      : _.Uha
      ? ((a = /Android\s+([^\);]+)(\)|;)/), (a = a.exec(_.mb())) ? a[1] : "")
      : _.Vha || _.Wha || _.Xha
      ? ((a = /(?:iPhone|CPU)\s+OS\s+(\S+)/),
        (a = a.exec(_.mb())) ? a[1].replace(/_/g, ".") : "")
      : "";
  })();
  var J5a = class extends _.Ul {
    constructor(a) {
      super();
      this.Hh = new _.Zr();
      a && (this.Hh.Hh = a);
    }
    getPanoramaByLocation(a, b, c, d = !1, e = null, f = !1) {
      var g;
      this.set("isHover", d);
      d || (g = _.jk(147648));
      var h = _.mG(this);
      a = { location: a, radius: b };
      f && (a.jK = f);
      c && (a.preference = c);
      a.sources = e;
      _.Vo(
        this.Hh,
        a,
        _.SD((k, n) => {
          _.nG(this, h)
            ? (k && k.disabled && _.lk(g),
              this.set("sloTrackingId", g),
              this.set("result", k),
              this.set("status", n),
              n === "UNKNOWN_ERROR"
                ? _.kk(g, 9)
                : n === "ZERO_RESULTS" && _.lk(g))
            : _.lk(g);
        }),
        g
      );
    }
    getPanoramaById(a) {
      var b = _.jk(247343),
        c = _.mG(this);
      _.Vo(
        this.Hh,
        { pano: a },
        _.SD((d, e) => {
          _.nG(this, c)
            ? (d && d.disabled && _.lk(b),
              this.set("sloTrackingId", b),
              this.set("result", d),
              this.set("status", e),
              e === "UNKNOWN_ERROR"
                ? _.kk(b, 9)
                : e === "ZERO_RESULTS" && _.lk(b))
            : _.lk(b);
        }),
        b
      );
    }
  };
  var L5a = class extends _.Ul {
    constructor(a, b, c) {
      var d = new K5a();
      super();
      this.div = a;
      this.Oh = b;
      this.tileSize = new _.Hm(512, 512);
      this.Nh = 0;
      this.Lh = null;
      this.Jh = new _.Yn(() => {}, 0);
      this.set("projection", d);
      a.style.width = "100%";
      a.style.height = "100%";
      this.Mh();
      _.Ol(this, "resize", this, this.Mh);
      this.Kh = new J5a(c);
      this.Kh.bindTo("result", this, null, !0);
      this.Kh.bindTo("sloTrackingId", this, "sloTrackingId", !0);
      this.bindTo("status", this.Kh, "status", !0);
    }
    Mh() {
      var a = _.po(this.div);
      a.equals(this.getSize()) || this.set("size", a);
    }
    position_changed() {
      var a = this.getPosition();
      if (a) {
        let b = this.getLocation();
        (b && b.latLng === a) || this.Kh.getPanoramaByLocation(a, 50);
        this.set("latLngBounds", _.Zm(a, 275 / 6378137));
      }
    }
    pano_changed() {
      var a = this.getPano(),
        b;
      if (a) {
        let c = this.getLocation();
        (c && c.pano === a) ||
          _.RD(() => {
            var d = this.get("panoProvider");
            d &&
              (b = typeof d === "function" ? d(a) : d.provider(a)) &&
              ((b.mQ = "c"), this.set("result", b));
            b || this.Kh.getPanoramaById(a);
          });
      }
    }
    result_changed() {
      var a = this.get("result");
      a &&
        (this.set("tiles", a.tiles),
        this.set("location", a.location),
        this.set("neighborLocation", a.dP),
        this.set("time", a.time),
        Array.isArray(a.links) || (a.links = []),
        this.set("links", a.links),
        o4a(this));
    }
    imageDateControl_changed() {
      o4a(this);
    }
    tileZoom_changed() {
      this.Jh.Hh();
    }
    tiles_changed() {
      var a = this.get("tiles"),
        b = a && Number(a.centerHeading || a.originHeading);
      this.set("headingOffset", 180 - (b || 0));
      if (a) {
        if (_.Dk(b)) {
          var c = -Number(a.originPitch || 0);
          var d = Number(a.originPitchYaw);
          isNaN(d) || (c *= Math.cos(_.Oj(b - d)));
          c = { heading: b, pitch: c };
        }
        this.tileSize = b = a.tileSize;
        this.worldSize = d = a.worldSize;
        this.Nh =
          b &&
          d &&
          Math.ceil(
            Math.max(_.Ou(d.width / b.width), _.Ou(d.height / b.height))
          );
        this.Lh = a.getTileUrl;
        CP(this, !0);
        this.Jh.Hh();
      }
      this.set("photographerPov", c);
    }
    inMotion_changed() {
      this.get("inMotion") === !1 && this.Jh.Hh();
    }
    zoom_changed() {
      CP(this);
    }
    location_changed() {
      var a = this.getLocation();
      if (a) {
        let b = a.pano,
          c = a.latLng;
        a = a.description;
        b !== this.getPano()
          ? this.get("isHover") || this.set("pano", b)
          : _.lk(this.get("sloTrackingId"));
        c !== this.getPosition() && this.set("position", c);
        a !== this.get("description") && this.set("description", a);
        this.Jh.Hh();
      }
    }
    pov_changed() {
      _.lo.Mh ? _.Zn(this.Jh) : this.Jh.Hh();
    }
    size_changed() {
      CP(this);
      this.Jh.Hh();
    }
    getLocation() {
      return this.get("location");
    }
    getPosition() {
      return this.get("position");
    }
    getPano() {
      return this.get("pano");
    }
    getPov() {
      return this.get("pov");
    }
    getSize() {
      return this.get("size");
    }
    getTileUrl(a, b, c, d) {
      return this.get("disabled")
        ? _.Iz
        : this.Lh
        ? this.Lh(a, b, c, d)
        : `${this.Oh.getTileUrl({
            output: "tile",
            x: c,
            y: d,
            zoom: b,
            rF: a,
          })}&fover=2&onerr=3`;
    }
    zl() {
      return this.get("inMotion");
    }
    disabled_changed() {
      this.div.style.backgroundColor = this.get("disabled") ? "black" : "";
    }
  };
  var K5a = class {
    constructor() {
      this.rG = new _.Dm(0, 0);
      this.SQ = new _.Dm(0, 0);
    }
  };
  var j5a = class extends L5a {
    constructor(a, b, c, d, e, f) {
      super(a, b, e);
      this.Ph = c;
      this.Hh = null;
      this.Ih = !1;
      var g = document.createElement("div");
      g.style.height = "100%";
      g.style.width = "100%";
      a.appendChild(g);
      Promise.all([_.ck("util"), _.ck("imagery_viewer")]).then(
        ([h, k]) => {
          var n = this.get("ariaDescribedBy");
          this.Hh = k.PO(
            g,
            _.Ne(_.fk),
            n,
            this.Qh.bind(this),
            () => {
              this.Ih = !0;
              this.set("pano", this.Hh.getPano());
              this.Ih = !1;
            },
            d,
            () => {
              _.Sl(this, "iv_renderstable");
            },
            f,
            () => {
              _.kk(this.get("sloTrackingId"), 0);
              p4a(this);
              q4a(this);
            },
            () => {
              _.lk(this.get("sloTrackingId"));
            },
            (A) => {
              var J = _.Zu(),
                M = null;
              switch (A) {
                case 0:
                  M = J ? 171446 : 171447;
                  break;
                case 1:
                  M = J ? 171448 : 171449;
                  break;
                case 2:
                  M = J ? 171450 : 171451;
              }
              M && _.nk(window, M);
            },
            !0
          );
          k = this.get("pano");
          n = this.get("pov");
          var p = this.get("clickToGo"),
            r = this.get("showRoadLabels"),
            u = this.get("scrollwheel"),
            w = this.get("panoProvider"),
            y = this.get("neighborLocation");
          _.Gl(this, "resize", () => {
            var A = _.lG(a),
              J = parseFloat(A.width);
            A = parseFloat(A.height);
            isNaN(J) || isNaN(A) || this.Hh.setSize(J, A);
          });
          _.Gl(this, "panoramavisible", () => {
            p4a(this);
          });
          k && this.Hh.setPano(k);
          n && this.Hh.setPov(n);
          y && this.Hh.setNeighborLocation(y);
          this.Hh.enableClickToGo(p !== !1);
          this.Hh.showRoadLabels(r !== !1);
          this.Hh.enableScrollToZoom(u !== !1);
          this.registerPanoProvider(w);
          h.xr.Hh(() => {
            this.Hh.dV();
          });
        },
        () => {
          _.kk(this.get("sloTrackingId"), 13);
        }
      );
    }
    pendingFocus_changed() {
      q4a(this);
    }
    Qh() {
      this.Ih = !0;
      this.set("pov", this.Hh.getPov());
      this.Ih = !1;
    }
    clickToGo_changed() {
      if (!this.Ih && this.Hh) {
        var a = this.get("clickToGo"),
          b = this.get("linksHovering");
        this.Hh.enableClickToGo(a !== !1 && !b);
      }
    }
    showRoadLabels_changed() {
      if (!this.Ih && this.Hh) {
        var a = this.get("showRoadLabels");
        this.Hh.showRoadLabels(a !== !1);
      }
    }
    scrollwheel_changed() {
      if (!this.Ih && this.Hh) {
        var a = this.get("scrollwheel");
        this.Hh.enableScrollToZoom(a !== !1);
      }
    }
    panoProvider_changed() {
      if (!this.Ih && this.Hh) {
        var a = this.get("panoProvider");
        this.registerPanoProvider(a);
      }
    }
    pov_changed() {
      if (!this.Ih && this.Hh) {
        var a = this.get("pov");
        this.Hh.setPov(a);
      }
    }
    linksHovering_changed() {
      if (this.Hh)
        if (this.get("linksHovering")) this.Hh.enableClickToGo(!1);
        else {
          let a = this.get("clickToGo");
          this.Hh.enableClickToGo(a !== !1);
        }
    }
    pano_changed() {
      super.pano_changed();
      var a = this.get("pano");
      !this.Ih && this.Hh && a && this.Hh.setPano(a);
    }
    neighborLocation_changed() {
      var a = this.get("neighborLocation");
      a && this.Hh && this.Hh.setNeighborLocation(a);
    }
    registerPanoProvider(a) {
      var b = () => {},
        c = !0;
      a &&
        (typeof a === "function"
          ? ((b = a), (c = !1))
          : ((b = a.provider), (c = !!a.options.cors)));
      this.Hh.registerPanoProvider(b, c);
    }
  };
  var h5a = class extends _.Ul {
    constructor(a, b, c) {
      super();
      this.container = a;
      this.Sh = b;
      this.Kh = this.Ih = this.orientation = null;
      this.Lh = this.Hh = !1;
      this.Jh = !0;
      this.button = document.createElement("button");
      this.icon = document.createElement("img");
      this.icon.alt = "";
      this.icon.style.width = _.Jk(c);
      this.icon.style.height = _.Jk(c);
      this.button.style.background = "transparent";
      this.button.style.border = "none";
      this.button.style.cursor = "pointer";
      this.button.style.margin = "0";
      this.button.style.padding = "0";
      this.button.style.height = _.Jk(c);
      this.button.style.width = _.Jk(c);
      this.button.type = "button";
      this.button.title = "Toggle motion tracking";
      this.button.setAttribute("aria-label", "Toggle motion tracking");
      this.button.appendChild(this.icon);
      a.appendChild(this.button);
      a.style.backgroundColor = "#222";
      a.style.borderRadius = _.Jk(_.iG(c));
      a.style.marginRight = _.Jk(c >> 2);
      a.style.width = _.Jk(c);
      a.style.height = _.Jk(c);
      _.gv(a, 1);
      _.aE(a);
      _.Ru(this.button, "click", this, this.Qh);
      this.Nh = this.Mh =
        window.DeviceOrientationEvent &&
        typeof window.DeviceOrientationEvent.requestPermission === "function";
      s4a(this);
    }
    pov_changed() {
      t4a(this);
    }
    async motionTracking_changed() {
      this.Jh &&
        (await DP(this),
        this.get("motionTracking") &&
          !this.Hh &&
          ((this.Jh = !1), this.set("motionTracking", !1), (this.Jh = !0)),
        EP(this));
    }
    enabled_changed() {
      EP(this);
    }
    disableDefaultUI_changed() {
      EP(this);
    }
    async Qh(a) {
      await DP(this);
      if (this.Hh) {
        r4a(this);
        let b = this.get("motionTracking") !== !1;
        this.set("motionTracking", !b);
      } else EP(this);
      _.nk(window, _.dE(a) ? 171226 : 171225);
    }
    Oh(a) {
      if (a.alpha != null && a.beta != null && a.gamma != null) {
        this.Nh = !0;
        var b = this.orientation,
          c = _.Oj(a.alpha / 2);
        let d = _.Oj(a.beta / 2);
        a = _.Oj(a.gamma / 2);
        let e = Math.PI / 4,
          f = _.Oj((window.orientation || 0) / 2);
        this.orientation = wP(
          { w: Math.cos(c), x: 0, y: 0, z: Math.sin(c) },
          wP(
            { w: Math.cos(d), x: Math.sin(d), y: 0, z: 0 },
            wP(
              { w: Math.cos(a), x: 0, y: Math.sin(a), z: 0 },
              wP(
                { w: Math.cos(e), x: -Math.sin(e), y: 0, z: 0 },
                { w: Math.cos(f), x: 0, y: Math.sin(f), z: 0 }
              )
            )
          )
        );
        b || EP(this);
        b = this.get("motionTracking") != 0;
        !this.Sh.get() && b && this.Ih
          ? this.orientation &&
            this.Ih &&
            ((c = wP(this.Ih, this.orientation)),
            (b = (Math.atan2(c.x - c.z, c.w + c.y) * 180) / Math.PI),
            (c = (Math.atan2(-c.x - c.z, c.w - c.y) * 180) / Math.PI),
            this.set("pov", {
              heading: _.Lu(b + c, 360),
              pitch: _.LD(vP(c, b), -90, 90),
            }))
          : t4a(this);
      }
    }
    Ph() {
      this.orientation = this.Ih = null;
    }
  };
  var WP = [
      new _.Dm(126, 67),
      new _.Dm(4, 67),
      new _.Dm(63, 9),
      new _.Dm(63, 127),
    ],
    XP = [
      new _.Dm(166, 103),
      new _.Dm(-18, 103),
      new _.Dm(70, -15),
      new _.Dm(70, 215),
    ],
    M5a = class extends _.Ul {
      constructor(a, b, c) {
        super();
        this.Ph = b;
        this.config = c;
        this.Lh = !0;
        this.Jh = new _.Dm(0, 0);
        var d = _.fv("div", a);
        this.div = d;
        d.style.display = "none";
        this.Hh = _.VH.MQ;
        this.Nh = _.VH.OP;
        a = T3a(d, this.Nh, 0);
        _.ev(a, new _.Dm(this.Hh.co.width, this.Hh.co.height));
        b = new _.Dm(5, 5);
        c = new _.Hm(96, 75);
        var e = _.fv("div", a, b, c);
        this.Mh = e;
        e.style.backgroundColor = "#d3d3d3";
        _.gv(e, 1);
        e.style.display = "none";
        e = _.fv("div", a);
        e.style.width = _.Jk(97);
        e.style.bottom = "38px";
        _.gv(e, 1);
        e.style.left = _.Jk(b.x);
        e.style.fontFamily = "Roboto,Arial,sans-serif";
        e.style.fontSize = _.Jk(9);
        e.style.color = "gray";
        e.style.backgroundColor = "white";
        this.Kh = _.cv("", e);
        _.dv(e);
        this.Ih = 3;
        this.Oh = d = T3a(d, this.Hh, this.Ih);
        _.ev(d, WP[this.Ih]);
        this.image = _.qG(null, a, b, c, {
          hv: () => {
            var f = this.get("mode");
            if (f !== void 0 && _.SG(f)) {
              this.Mh.style.display = "none";
              _.bE(this.image, 1);
              this.Lh = !0;
              _.$D(this.div);
              f = this.Kh;
              var g = this.get("description") || "";
              f.textContent = g;
            }
          },
        });
      }
      location_changed() {
        var a = this.get("location");
        this.set("description", a?.shortDescription);
        this.set("panoThumbnailUrl", a?.UK);
        var b = a?.pano;
        a = a?.UK;
        b
          ? (a
              ? ((b = a), _.nk(window, 283921))
              : ((a = _.RG(b)),
                _.Of(a, 1) === 3
                  ? ((b = _.H(this.config, E5a, 25)),
                    (b = `${_.Vf(b, 11, 0)}/${a.getId()}/w96-h75-n-k-no/`))
                  : _.Of(a, 1) === 10
                  ? ((b = _.H(this.config, E5a, 25)),
                    (b = `${_.Vf(b, 11, 0).replace(
                      "http:",
                      "https:"
                    )}/p/${a.getId()}=w96-h75-n-k-no`))
                  : (b = this.Ph("thumbnail", [
                      "w=96",
                      "h=75",
                      "thumbfov=90",
                      "thumb=2",
                      "it=all",
                      `panoid=${b}`,
                    ])),
                _.nk(window, 283920)),
            _.rG(this.image, b))
          : (_.$D(this.Mh), (this.Kh.textContent = "No data available."));
      }
      mode_changed() {
        var a = this.get("mode");
        _.SG(a) || (this.div.style.display = "none");
      }
      pixelPosition_changed() {
        var a = this.get("pixelPosition"),
          b = this.get("pixelBounds");
        if (a && b) {
          var c = 3,
            d = a.x;
          a = a.y;
          var e = XP[3].x,
            f = XP[3].y;
          d < b.minX + e + 30
            ? (c = 1)
            : d > b.maxX + e - this.Nh.co.width - 30
            ? (c = 0)
            : a < b.minY + f - this.Hh.co.height &&
              a < b.maxY - XP[2].y - WP[3].y - this.Hh.co.height &&
              (c = 2);
          c !== this.Ih &&
            ((this.Ih = c),
            (b = this.Hh),
            (e = b.items[0].segment),
            _.tG(
              this.Oh,
              b.co,
              new _.Dm(e.x + b.grid.x * c, e.y + b.grid.y * c),
              b.Hn.size
            ),
            _.ev(this.Oh, WP[c]));
          c = XP[c];
          this.Jh.x = d - c.x;
          this.Jh.y = a - c.y;
          _.ev(this.div, this.Jh);
        }
        this.Lh &&
          ((this.Kh.textContent = "Loading..."),
          _.bE(this.image, 0.25),
          (this.Lh = !1));
      }
    };
  var $4a = class extends _.Ul {
    constructor() {
      super();
      this.Hh = 0;
      this.Lh = null;
      this.Ih = new _.rH(10);
      this.Jh = _.vm("pov");
      this.Nh = _.wm("povFinal");
      this.Kh = _.vm("povFinal");
    }
    pov_changed() {
      this.Mh || this.Nh(this.Jh());
    }
    povFinal_changed() {
      var a = this.Jh(),
        b = this.Kh();
      b &&
        (a &&
        b &&
        a.heading === b.heading &&
        a.pitch === b.pitch &&
        a.zoom === b.zoom
          ? (this.Ih.reset(),
            this.Hh &&
              (window.clearTimeout(this.Hh),
              (this.Hh = 0),
              this.set("inMotion", !1)))
          : (this.Ih.extend(10),
            (this.Lh = this.Jh()),
            this.Hh || (this.set("inMotion", !0), v4a(this))));
    }
  };
  var W4a = class {
    constructor(a, b) {
      this.Jh = a;
      this.Ih = b;
      this.Hh = !1;
    }
    qQ() {
      if (!this.Hh) {
        var a = this.Jh ? 3 : 2;
        this.Hh = !0;
        _.nk(this.Ih, 148998);
        _.ck("util").then((b) => {
          setTimeout(
            () => {
              N3a(b.xr, a);
            },
            _.og(_.fk, 39) ? _.Nf(_.fk, 39) : 5e3
          );
        });
      }
    }
  };
  var y4a = {
      [11]: 148982,
      [10]: 148983,
      [12]: 148984,
      [6]: 148985,
      [4]: 148986,
      [5]: 148987,
      [9]: 148988,
      [8]: 148990,
      [7]: 148991,
      [2]: 148992,
      [13]: 148995,
      [3]: 148993,
      [1]: 148994,
    },
    z4a = {
      [11]: 149017,
      [10]: 149018,
      [12]: 149019,
      [6]: 149020,
      [4]: 149021,
      [5]: 149022,
      [9]: 149023,
      [8]: 149024,
      [7]: 149025,
      [2]: 149026,
      [13]: 149029,
      [3]: 149027,
      [1]: 149028,
    },
    A4a = {
      [11]: 149034,
      [10]: 149035,
      [12]: 149036,
      [6]: 149037,
      [4]: 149038,
      [5]: 149039,
      [9]: 149040,
      [8]: 149042,
      [7]: 149041,
      [2]: 149043,
      [13]: 149046,
      [3]: 149044,
      [1]: 149045,
    };
  var k5a = class extends _.Ul {
    constructor(a) {
      super();
      this.Nj = a;
      this.Hh = null;
    }
    map_changed() {
      var a = this.Nj;
      if (this.Hh) {
        let c = this.Hh.overlayMapTypes;
        for (let d = 0, e = c.getLength(); d < e; ++d)
          if (a == c.getAt(d)) {
            c.removeAt(d);
            break;
          }
        a.unbind("mapHeading");
        a.unbind("tilt");
      }
      var b = (this.Hh = this.get("map"));
      b &&
        b.__gm.Jh.then((c) => {
          this.get("map") === b &&
            b &&
            (c || (a.bindTo("mapHeading", b, "heading"), a.bindTo("tilt", b)),
            a.bindTo("client", b, "svClient"),
            a.Zu !== c && ((a.Zu = c), (a.Ih = _.UG(a))),
            b.overlayMapTypes.push(a));
        });
    }
  };
  var N5a = (0,
  _.Wh)`.SLHIdE-sv-links-control svg\u003epath[pano]{outline:none}.SLHIdE-sv-links-control svg\u003epath[pano]:focus-visible{outline:auto}\n`;
  var O5a = [0, -120, 60, -60, 40, -30, -40, -30, -60, -60, 0, -120],
    P5a = [0, -100, 40, -60, 30, -50, 0, -82, -30, -50, -40, -60];
  var Q5a = class extends _.Ul {
    constructor(a, b) {
      super();
      this.ti = [];
      var c = C4a([O5a]),
        d = C4a([P5a]);
      this.description = b.description || "";
      this.heading = b.heading || 0;
      this.Ih = HP(this, a, d, "black", 0.5);
      this.Hh = HP(this, a, d, "white", 1);
      this.target = HP(this, a, c, "white", 0);
      E4a(this, this.target, b.pano, this.Hh);
    }
    release() {
      for (let a of this.ti) _.Il(a);
      this.ti.length = 0;
      this.Ih && (_.mv(this.Ih), (this.Ih = null));
      this.Hh && (_.mv(this.Hh), (this.Hh = null));
      this.target && (_.mv(this.target), (this.target = null));
    }
    addElement(a, b, c, d) {
      b = _.bv(a).createElementNS("http://www.w3.org/2000/svg", b);
      c &&
        (b.setAttribute("fill", c),
        b.setAttribute("fill-rule", "evenodd"),
        _.Dk(d) && b.setAttribute("fill-opacity", `${d}`));
      b.setAttribute("stroke", "none");
      a.appendChild(b);
      return b;
    }
    setTransform(a, b, c, d, e, f, g, h) {
      a.setAttribute(
        "transform",
        `${`translate(${c} ${d}) `}${e !== 1 ? `scale(1 ${e}) ` : ""}${
          b ? `rotate(${b}) ` : ""
        }${f ? `rotate(${f} ${g} ${h}) ` : ""}`
      );
    }
  };
  var d5a = class extends _.Ul {
    constructor(a) {
      super();
      this.container = a;
      this.Ih = [];
      this.Hh = null;
      this.Lh = this.Nh = !1;
      this.Mh = 0;
      this.container.style.fontFamily = "Roboto,Arial,sans-serif";
      this.Oh = [
        _.Ml(a, "click", (b) => {
          F4a(this, b);
        }),
        _.Ml(a, "keydown", (b) => {
          (b.key !== "Enter" && b.key !== " ") || F4a(this, b);
        }),
      ];
      this.Jh = new _.Yn(() => {
        if (this.Nh) {
          if (this.Hh) {
            var b = this.get("links") || [];
            if (
              (this.Lh =
                this.Hh.contains(document.activeElement) &&
                this.Kh.has(document.activeElement))
            )
              this.Mh = this.Kh.get(document.activeElement).heading;
            G4a(this);
            I4a(b);
            for (var c of b)
              (b = new Q5a(this.Hh, c)),
                b.bindTo("hovering", this),
                this.Ih.push(b),
                b.target && this.Kh.set(b.target, b);
          }
          this.Nh = !1;
        }
        (c = this.Hh && this.Hh.context) &&
          c.clearRect(0, 0, this.Hh.width, this.Hh.height);
        var d = this.get("worldSize"),
          e = this.get("size");
        c = this.get("pov");
        b = this.get("center");
        var f = this.get("yScale");
        if (c && _.Dk(c.heading) && b && _.Dk(f) && e && d)
          for (var g of this.Ih)
            if (g.Ih !== null && g.Hh !== null && g.target !== null) {
              d = g.heading - c.heading;
              e = b.x;
              var h = b.y;
              g.setTransform(g.Ih, d, e, h, f);
              g.setTransform(g.Hh, d, e, h - 3, f);
              g.setTransform(g.target, d, e, h - 3, f);
            }
        if (this.Lh) {
          g = this.Ih[0];
          for (c = 1; c < this.Ih.length; c += 1)
            Math.abs(vP(this.Mh, g.heading)) >
              Math.abs(vP(this.Mh, this.Ih[c].heading)) && (g = this.Ih[c]);
          g?.target ? g.target.focus() : this.set("pendingPanoramaFocus", !0);
          this.Lh = !1;
        }
      }, 0);
      this.set("hovering", !1);
      this.Kh = new Map();
      _.ws(N5a, this.container);
      _.qp(this.container, "sv-links-control");
    }
    release() {
      for (let a of this.Oh) _.Il(a);
      this.Oh.length = 0;
      G4a(this);
    }
    size_changed() {
      var a = this.get("size");
      if (a) {
        var b = this.container;
        let c;
        b.childNodes.length
          ? (c = b.childNodes[0])
          : ((c = _.bv(b).createElementNS("http://www.w3.org/2000/svg", "svg")),
            b.appendChild(c),
            (c.style.position = "absolute"),
            (c.style.top = c.style.left = "0px"),
            c.setAttribute("version", "1.1"));
        c.setAttribute("width", _.Fm(a));
        c.setAttribute("height", _.Gm(a));
        c.setAttribute("viewBox", [0, 0, a.width, a.height].join(" "));
        this.Hh = c;
        this.Hh.style.pointerEvents = "none";
        H4a(this);
      }
      this.Jh.Hh();
    }
    links_changed() {
      this.Nh = !0;
      this.Jh.Hh();
    }
    pov_changed() {
      H4a(this);
      this.Jh.Hh();
    }
    center_changed() {
      this.Jh.Hh();
    }
  };
  var Z4a = class extends _.Ul {
    constructor() {
      super();
      _.Ol(this, "panbyfraction", this, this.Mh);
      _.Ol(this, "panbynow", this, this.Nh);
      _.Ol(this, "pantobounds", this, this.Oh);
      this.Lh = _.wm("zoom");
      this.Jh = _.vm("zoom");
      this.Ph = _.wm("heading");
      this.Kh = _.vm("heading");
      this.Ih = _.wm("pov");
      this.Hh = _.vm("pov");
    }
    zoom_changed() {
      var a = this.Jh();
      if (_.Dk(a) && !isNaN(a)) {
        var b = this.get("zoomRange");
        b = a < b.min ? b.min : a > b.max ? b.max : a;
        a != b
          ? this.Lh(b)
          : ((b = this.Hh()) && b.zoom == a) ||
            this.Ih(new _.Kr(b ? b.heading : 0, b ? b.pitch : 0, a));
      }
    }
    heading_changed() {
      var a = this.Kh();
      if (_.Dk(a) && !isNaN(a)) {
        let b = this.Hh();
        (b && b.heading == a) ||
          this.Ih(new _.Kr(a, b ? b.pitch : 0, b ? b.zoom : 0));
      }
    }
    pov_changed() {
      var a = this.Hh();
      if (a) {
        var b = this.Jh();
        a.zoom != b && this.Lh(a.zoom);
        b = this.Kh();
        a.heading != b && this.Ph(a.heading);
      }
    }
    Mh(a, b) {
      var c = this.Hh();
      this.Ih(new _.Kr(120 * a + c.heading, -40 * b + c.pitch, c.zoom));
    }
    Nh(a, b) {
      var c = this.Hh();
      this.Ih(new _.Kr(5 * a + c.heading, -5 * b + c.pitch, c.zoom));
    }
    Oh(a) {
      var b = this.get("size"),
        c = this.get("layoutBounds") || _.Wm(0, 0, b.width, b.height),
        d = new _.Dm(0, 0);
      a.minY < c.minY
        ? (d.y = c.minY - a.minY)
        : a.maxY > c.maxY && (d.y = c.maxY - a.maxY);
      a.minX < c.minX
        ? (d.x = c.minX - a.minX)
        : a.maxX > c.maxX && (d.x = c.maxX - a.maxX);
      this.get("worldSize");
      this.get("projection");
      a = this.Hh();
      var e = _.Oj(a.pitch),
        f = _.Oj(a.heading);
      c = Math.cos(e);
      e = Math.sin(e);
      var g = Math.cos(f),
        h = Math.sin(f),
        k = b.width / 2;
      f = k * Math.pow(2, a.zoom - 1);
      var n = b.height / 2 - _.Mm.y,
        p = c * f - e * n,
        r = k - _.Mm.x;
      k = g * p + h * r;
      g = g * r - h * p;
      a = new _.Kr(
        _.Pj(Math.atan2(-g, k)),
        _.Pj(Math.atan2(e * f + c * n, Math.sqrt(k * k + g * g))),
        a.zoom
      );
      c = b.width / 2;
      g = c * Math.pow(2, a.zoom - 1);
      f = b.height / 2 - d.y;
      d = c - d.x;
      b = -Math.tan(_.Oj(a.heading));
      h = Math.tan(_.Oj(a.pitch)) * Math.sqrt(1 + Math.pow(b, 2));
      c =
        Math.sqrt(Math.pow(g, 2) + Math.pow(f, 2) + Math.pow(d, 2)) /
        Math.sqrt(1 + Math.pow(h, 2) + Math.pow(b, 2));
      e = -h * c - f;
      n = 2 * g;
      f -= h * c;
      h = n * n - 4 * e * f;
      h < 0 && (h = 0);
      e = e ? (-n + Math.sqrt(h)) / (2 * e) : -f / n;
      g = _.Pj(2 * Math.atan(e));
      e = -b * c - d;
      n = 2 * c;
      f = b * c - d;
      h = n * n - 4 * e * f;
      h < 0 && (h = 0);
      e = e ? (-n + Math.sqrt(h)) / (2 * e) : -f / n;
      d = _.Pj(2 * Math.atan(e));
      b = (d - a.heading) % 360;
      b > 90 && (d = (d - 180) % 360);
      b < -90 && (d = (d + 180) % 360);
      a = new _.Kr(d, g, a.zoom);
      this.Ih(a);
    }
  };
  var Y4a = class extends _.Ul {
    constructor() {
      super();
      this.Hh = !1;
      this.Ih = new _.Yn(() => {
        var a = this.get("devZoom"),
          b = this.get("devPov") || { heading: 0, pitch: 0 };
        this.Hh = !0;
        _.Dk(b.zoom) && !_.Dk(a) && this.set("devZoom", b.zoom);
        _.Dk(b.zoom) || ((a = _.Dk(a) ? a : 1), (b.zoom = a));
        this.set("internalPov", b);
        this.Hh = !1;
      }, 0);
    }
    internalPov_changed() {
      if (!this.Hh && !this.Ih.isActive()) {
        var a = this.get("internalPov"),
          b = this.get("devZoom");
        this.Hh = !0;
        this.set("devPov", a);
        b !== a.zoom && this.set("devZoom", a.zoom);
        this.Hh = !1;
      }
    }
    devPov_changed() {
      this.Hh || this.Ih.Hh();
    }
    devZoom_changed() {
      if (!this.Hh) {
        var a = this.get("devPov");
        a && _.Dk(a.zoom) && (a.zoom = this.get("devZoom"));
        this.Ih.Hh();
      }
    }
  };
  var b5a = class extends _.Ul {
    constructor() {
      super();
      this.kG = !1;
      this.Hh = new _.Dm(0, 0);
    }
    fromLatLngToPoint(a, b = new _.Dm(0, 0)) {
      var c = this.get("worldSize"),
        d = this.get("position"),
        e = this.get("pov"),
        f = this.get("zoom"),
        g = this.Hh,
        h = this.get("projection"),
        k = this.get("size");
      if (!(c && d && e && k && h) || f === void 0) return null;
      a = _.rl(a);
      var n = _.Pj(
        Math.atan2(
          _.Bk(a.lng() - d.lng(), -180, 180) * Math.cos(_.Oj(d.lat())),
          a.lat() - d.lat()
        )
      );
      a = _.Pj(Math.atan2(-3, 0.1 + 6378137 * _.WD(d, a)));
      g.x = (n / 360) * c.width;
      g.y = ((90 - a) / 180) * c.height;
      n = new _.nl(90 - (180 * g.y) / c.height, (360 * g.x) / c.width);
      a = new _.nl(e.pitch, e.heading);
      if (_.$Ba(n, a) >= Math.PI / 2) f = null;
      else {
        h = h.SQ;
        a = (e.pitch / 180) * Math.PI;
        e = _.Bk(_.Oj(e.heading + 0), 0, 2 * Math.PI);
        n = Math.cos(a);
        a = Math.sin(a);
        d = k.width / 2;
        k = k.height / 2;
        let p = (2 * Math.PI * g.x) / c.width;
        c = Math.PI * (0.5 - g.y / c.height);
        f =
          (d * Math.pow(2, f - 1)) /
          (n * Math.cos(c) * Math.cos(e - p) + a * Math.sin(c));
        h.x = d - f * Math.cos(c) * Math.sin(e - p);
        h.y = k - f * (n * Math.sin(c) - a * Math.cos(c) * Math.cos(e - p));
        f = h;
      }
      if (!f) return null;
      b.x = f.x;
      b.y = f.y;
      return b;
    }
    fromPointToLatLng(a, b = !1) {
      var c = this.get("worldSize"),
        d = this.get("position"),
        e = this.get("pov"),
        f = this.get("size"),
        g = this.get("projection");
      if (!(c && d && e && f && g)) return null;
      var h = _.Oj(e.heading + 0);
      var k = Math.cos(_.Oj(e.pitch));
      var n = Math.sin(_.Oj(e.pitch)),
        p = Math.cos(h);
      h = Math.sin(h);
      var r = f.width / 2;
      e = r * Math.pow(2, e.zoom - 1);
      f = f.height / 2 - a.y;
      r -= a.x;
      var u = k * e - n * f;
      a = p * u + h * r;
      h = p * r - h * u;
      p = Math.atan2(-h, a);
      p < 0 && (p += 2 * Math.PI);
      k = Math.atan2(n * e + k * f, Math.sqrt(a * a + h * h));
      g.rG.x = (p * c.width) / (2 * Math.PI);
      g.rG.y = c.height * (0.5 - k / Math.PI);
      k = g.rG;
      g = (k.x / c.width) * 360;
      c = Math.tan(_.Oj(90 - (k.y / c.height) * 180));
      c > -0.01 && (c = -0.01);
      p = (-3 / c - 0.1) / 6378137;
      k = _.Oj(d.lat());
      d = _.Oj(d.lng());
      c = Math.cos(k);
      k = Math.sin(k);
      n = Math.cos(p);
      p = Math.sin(p);
      g = _.Oj(g);
      e = k * n + c * p * Math.cos(g);
      return Q3a(
        Math.asin(e),
        d + Math.atan2(Math.sin(g) * p * c, n - k * e),
        b
      );
    }
  };
  var J4a = {
      wheel0: { ny: 4.000244140625, Zx: 80 },
      mousewheel: { ny: 120, Zx: 250 },
    },
    K4a = { mousewheel: { ny: 12, Zx: 250 } },
    L4a = {
      wheel0: { ny: 0.10000610351625, Zx: 80 },
      MozMousePixelScroll: { ny: 15, Zx: 10 },
    },
    c5a = class extends _.Ul {
      constructor(a) {
        super();
        this.Qr = a;
        this.Ih = this.Lh = this.Kh = 0;
        this.Hh = !1;
        this.Jh = M4a();
        this.ti = null;
      }
      enabled_changed() {
        this.get("enabled") !== !1
          ? this.ti ||
            (this.ti = [
              _.Ru(this.Qr, "wheel", this, this.Mh),
              _.Ru(this.Qr, "mousewheel", this, this.Nh),
              _.Ru(this.Qr, "MozMousePixelScroll", this, this.Oh),
            ])
          : this.ti && (this.ti.forEach(_.Il), (this.ti = null));
      }
      Mh(a) {
        IP(this, a, -a.deltaY, this.Jh[`wheel${a.deltaMode}`]);
      }
      Nh(a, b = 0) {
        b = _.Dk(a.wheelDeltaY)
          ? a.wheelDeltaY
          : _.Dk(a.wheelDelta)
          ? a.wheelDelta
          : b || a.detail;
        IP(this, a, b, this.Jh.mousewheel);
      }
      Oh(a) {
        IP(this, a, -a.detail, this.Jh.MozMousePixelScroll);
      }
    };
  var JP = null;
  var VP = new (class extends _.dA {
      constructor() {
        super();
      }
      Jh() {
        return _.Hz !== _.Fz ? _.Hz : _.Hz.replace("http:", "https:");
      }
      Lh(a, b, c, d, e) {
        a = t5a(a.pano, e);
        a = _.Xg(_.Qy, _.jD(_.Ne(a)));
        this.Hh.getMetadata(a).then(
          (f) => {
            a: {
              f = Array.isArray(f) ? new _.Pqa(f) : (0, _.Qqa)(f.pj());
              let g = "UNKNOWN_ERROR";
              if (_.F(f, 1)) {
                if (
                  rP(_.H(f, _.Sy, 1)) === 0 &&
                  mP(qP(_.jt(f, 2, _.Ry, 0))) === 1
                ) {
                  b(r5a(_.jt(f, 2, _.Ry, 0), c, d), "OK");
                  break a;
                }
                if (
                  rP(_.H(f, _.Sy, 1)) === 5 ||
                  rP(_.H(f, _.Sy, 1)) === 3 ||
                  mP(qP(_.jt(f, 2, _.Ry, 0))) === 2
                )
                  g = "ZERO_RESULTS";
              }
              b(null, g);
            }
          },
          () => {
            b && b(null, "UNKNOWN_ERROR");
          }
        );
      }
      Nh(a, b, c, d, e, f) {
        if ((a = u5a(a, b, e)))
          (a = _.Xg(_.Uy, _.jD(_.Ne(a)))),
            K3a(this.Hh, a).then(
              (g) => {
                try {
                  a: {
                    let h;
                    h = Array.isArray(g) ? new _.Sqa(g) : (0, _.Tqa)(g.pj());
                    g = "UNKNOWN_ERROR";
                    if (_.F(h, 1)) {
                      if (
                        rP(_.H(h, _.Sy, 1)) === 0 &&
                        (mP(qP(_.H(h, _.Ry, 2))) === 1 ||
                          mP(qP(_.H(h, _.Ry, 2))) === 3)
                      ) {
                        b(r5a(_.H(h, _.Ry, 2), c, d), "OK");
                        break a;
                      }
                      if (
                        rP(_.H(h, _.Sy, 1)) === 5 ||
                        mP(qP(_.H(h, _.Ry, 2))) === 2
                      )
                        g = "ZERO_RESULTS";
                    }
                    b(null, g);
                  }
                } catch (h) {
                  _.kk(f, 15);
                }
              },
              () => {
                b && b(null, "UNKNOWN_ERROR");
                _.kk(f, 14);
              }
            );
      }
    })(),
    z5a = _.Wk({ pano: _.Ap }, !1),
    A5a = _.Wk(
      {
        location: _.rl,
        radius: _.Eq,
        preference: _.fl(_.Zk(_.Jka)),
        source: _.fl(_.Zk(_.$r)),
        sources: _.fl(_.al(_.Zk(_.$r), 1)),
        jK: _.Gq,
      },
      !1
    );
  var R5a = class {
    constructor() {
      this.CP = X4a;
      this.JN = B5a;
      this.ML = J5a;
      this.NL = M5a;
      this.jM = l5a;
    }
  };
  _.ek("streetview", new R5a());
});
