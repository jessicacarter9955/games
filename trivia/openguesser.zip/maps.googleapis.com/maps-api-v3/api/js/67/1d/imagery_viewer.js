(function () {
  var p,
    aa = Object.defineProperty,
    ba = globalThis;
  function ca(a, b) {
    if (b)
      a: {
        var c = ba;
        a = a.split(".");
        for (var d = 0; d < a.length - 1; d++) {
          var e = a[d];
          if (!(e in c)) break a;
          c = c[e];
        }
        a = a[a.length - 1];
        d = c[a];
        b = b(d);
        b != d &&
          b != null &&
          aa(c, a, { configurable: !0, writable: !0, value: b });
      }
  }
  ca("Symbol.dispose", function (a) {
    return a ? a : Symbol("Symbol.dispose");
  }); /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var fa = fa || {},
    u = this || self;
  function ia(a, b) {
    a = a.split(".");
    for (var c = u, d; a.length && (d = a.shift()); )
      a.length || b === void 0
        ? c[d] && c[d] !== Object.prototype[d]
          ? (c = c[d])
          : (c = c[d] = {})
        : (c[d] = b);
  }
  function la() {}
  la.get = function () {
    return null;
  };
  function na(a) {
    a = a.split(".");
    for (var b = u, c = 0; c < a.length; c++)
      if (((b = b[a[c]]), b == null)) return null;
    return b;
  }
  function oa(a) {
    var b = typeof a;
    return b != "object" ? b : a ? (Array.isArray(a) ? "array" : b) : "null";
  }
  function pa(a) {
    var b = oa(a);
    return b == "array" || (b == "object" && typeof a.length == "number");
  }
  function ra(a) {
    var b = typeof a;
    return (b == "object" && a != null) || b == "function";
  }
  function sa(a) {
    return (
      (Object.prototype.hasOwnProperty.call(a, ta) && a[ta]) || (a[ta] = ++wa)
    );
  }
  var ta = "closure_uid_" + ((Math.random() * 1e9) >>> 0),
    wa = 0;
  function xa(a, b, c) {
    return a.call.apply(a.bind, arguments);
  }
  function Aa(a, b, c) {
    if (!a) throw Error();
    if (arguments.length > 2) {
      var d = Array.prototype.slice.call(arguments, 2);
      return function () {
        var e = Array.prototype.slice.call(arguments);
        Array.prototype.unshift.apply(e, d);
        return a.apply(b, e);
      };
    }
    return function () {
      return a.apply(b, arguments);
    };
  }
  function Ba(a, b, c) {
    Ba =
      Function.prototype.bind &&
      Function.prototype.bind.toString().indexOf("native code") != -1
        ? xa
        : Aa;
    return Ba.apply(null, arguments);
  }
  function Ca(a, b) {
    var c = Array.prototype.slice.call(arguments, 1);
    return function () {
      var d = c.slice();
      d.push.apply(d, arguments);
      return a.apply(this, d);
    };
  }
  function Da(a) {
    return a;
  }
  function Ea(a, b) {
    function c() {}
    c.prototype = b.prototype;
    a.qa = b.prototype;
    a.prototype = new c();
    a.prototype.constructor = a;
    a.Ui = function (d, e, f) {
      for (
        var g = Array(arguments.length - 2), h = 2;
        h < arguments.length;
        h++
      )
        g[h - 2] = arguments[h];
      return b.prototype[e].apply(d, g);
    };
  }
  function Ga(a, b) {
    if (Error.captureStackTrace) Error.captureStackTrace(this, Ga);
    else {
      let c = Error().stack;
      c && (this.stack = c);
    }
    a && (this.message = String(a));
    b !== void 0 && (this.cause = b);
    this.A = !0;
  }
  Ea(Ga, Error);
  Ga.prototype.name = "CustomError";
  var Ha;
  var Ia = !0,
    Ja,
    Ka;
  function La(a) {
    return (Ka || (Ka = new TextEncoder())).encode(a);
  }
  function Ma(a) {
    u.setTimeout(() => {
      throw a;
    }, 0);
  }
  var Na,
    Oa = na("CLOSURE_FLAGS"),
    Pa = Oa && Oa[748402147];
  Na = Pa != null ? Pa : !0;
  function Ra(a) {
    return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1];
  }
  var Sa = /&/g,
    Ta = /</g,
    Va = />/g,
    Wa = /"/g,
    Xa = /'/g,
    Ya = /\x00/g,
    Za = /[\x00&<>"']/;
  function $a(a, b) {
    return a < b ? -1 : a > b ? 1 : 0;
  }
  function ab() {
    var a = u.navigator;
    return a && (a = a.userAgent) ? a : "";
  }
  function w(a) {
    return ab().indexOf(a) != -1;
  }
  function cb() {
    return w("Trident") || w("MSIE");
  }
  function db() {
    return w("Firefox") || w("FxiOS");
  }
  function eb() {
    return (
      w("Safari") &&
      !(
        fb() ||
        w("Coast") ||
        w("Opera") ||
        w("Edge") ||
        w("Edg/") ||
        w("OPR") ||
        db() ||
        w("Silk") ||
        w("Android")
      )
    );
  }
  function fb() {
    return ((w("Chrome") || w("CriOS")) && !w("Edge")) || w("Silk");
  }
  function jb() {
    return w("Android") && !(fb() || db() || w("Opera") || w("Silk"));
  }
  function kb(a) {
    var b = {};
    a.forEach((c) => {
      b[c[0]] = c[1];
    });
    return (c) => b[c.find((d) => d in b)] || "";
  }
  function mb(a) {
    var b = ab();
    if (a === "Internet Explorer") {
      if (cb())
        if ((a = /rv: *([\d\.]*)/.exec(b)) && a[1]) b = a[1];
        else {
          a = "";
          var c = /MSIE +([\d\.]+)/.exec(b);
          if (c && c[1])
            if (((b = /Trident\/(\d.\d)/.exec(b)), c[1] == "7.0"))
              if (b && b[1])
                switch (b[1]) {
                  case "4.0":
                    a = "8.0";
                    break;
                  case "5.0":
                    a = "9.0";
                    break;
                  case "6.0":
                    a = "10.0";
                    break;
                  case "7.0":
                    a = "11.0";
                }
              else a = "7.0";
            else a = c[1];
          b = a;
        }
      else b = "";
      return b;
    }
    var d = RegExp("([A-Z][\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g");
    c = [];
    for (var e; (e = d.exec(b)); ) c.push([e[1], e[2], e[3] || void 0]);
    b = kb(c);
    switch (a) {
      case "Opera":
        if (w("Opera")) return b(["Version", "Opera"]);
        if (w("OPR")) return b(["OPR"]);
        break;
      case "Microsoft Edge":
        if (w("Edge")) return b(["Edge"]);
        if (w("Edg/")) return b(["Edg"]);
        break;
      case "Chromium":
        if (fb()) return b(["Chrome", "CriOS", "HeadlessChrome"]);
    }
    return (a === "Firefox" && db()) ||
      (a === "Safari" && eb()) ||
      (a === "Android Browser" && jb()) ||
      (a === "Silk" && w("Silk"))
      ? ((b = c[2]) && b[1]) || ""
      : "";
  }
  function nb(a) {
    a = mb(a);
    if (a === "") return NaN;
    a = a.split(".");
    return a.length === 0 ? NaN : Number(a[0]);
  }
  function ob() {
    return w("iPhone") && !w("iPod") && !w("iPad");
  }
  function pb(a) {
    return a[a.length - 1];
  }
  function qb(a, b) {
    if (typeof a === "string")
      return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
    for (let c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
    return -1;
  }
  function rb(a, b) {
    var c = a.length,
      d = typeof a === "string" ? a.split("") : a;
    for (let e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a);
  }
  function tb(a, b) {
    var c = a.length,
      d = typeof a === "string" ? a.split("") : a;
    for (--c; c >= 0; --c) c in d && b.call(void 0, d[c], c, a);
  }
  function vb(a, b) {
    var c = a.length,
      d = [],
      e = 0,
      f = typeof a === "string" ? a.split("") : a;
    for (let g = 0; g < c; g++)
      if (g in f) {
        let h = f[g];
        b.call(void 0, h, g, a) && (d[e++] = h);
      }
    return d;
  }
  function wb(a, b) {
    var c = a.length,
      d = typeof a === "string" ? a.split("") : a;
    for (let e = 0; e < c; e++)
      if (e in d && b.call(void 0, d[e], e, a)) return !0;
    return !1;
  }
  function xb(a, b) {
    b = yb(a, b);
    return b < 0 ? null : typeof a === "string" ? a.charAt(b) : a[b];
  }
  function yb(a, b) {
    var c = a.length,
      d = typeof a === "string" ? a.split("") : a;
    for (let e = 0; e < c; e++)
      if (e in d && b.call(void 0, d[e], e, a)) return e;
    return -1;
  }
  function zb(a, b) {
    b = qb(a, b);
    var c;
    (c = b >= 0) && Bb(a, b);
    return c;
  }
  function Bb(a, b) {
    Array.prototype.splice.call(a, b, 1);
  }
  function Cb(a, b) {
    b = yb(a, b);
    b >= 0 && Bb(a, b);
  }
  function Db(a) {
    var b = a.length;
    if (b > 0) {
      let c = Array(b);
      for (let d = 0; d < b; d++) c[d] = a[d];
      return c;
    }
    return [];
  }
  function Eb(a, b, c, d) {
    Array.prototype.splice.apply(a, Fb(arguments, 1));
  }
  function Fb(a, b, c) {
    return arguments.length <= 2
      ? Array.prototype.slice.call(a, b)
      : Array.prototype.slice.call(a, b, c);
  }
  function Gb(a) {
    var b = Ib;
    return Object.prototype.hasOwnProperty.call(b, 526)
      ? b[526]
      : (b[526] = a(526));
  }
  var Jb = w("Opera"),
    Kb = cb(),
    Lb = w("Edge"),
    Mb =
      w("Gecko") &&
      !(ab().toLowerCase().indexOf("webkit") != -1 && !w("Edge")) &&
      !(w("Trident") || w("MSIE")) &&
      !w("Edge"),
    Nb = ab().toLowerCase().indexOf("webkit") != -1 && !w("Edge"),
    Ob = Nb && w("Mobile"),
    Pb = w("Macintosh"),
    Sb = w("Windows"),
    Tb = w("Linux") || w("CrOS");
  w("Android");
  ob();
  w("iPad");
  w("iPod");
  ob() || w("iPad") || w("iPod");
  ab().toLowerCase().indexOf("kaios");
  function Ub() {
    var a = ab();
    if (Mb) return /rv:([^\);]+)(\)|;)/.exec(a);
    if (Lb) return /Edge\/([\d\.]+)/.exec(a);
    if (Kb) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
    if (Nb) return /WebKit\/(\S+)/.exec(a);
    if (Jb) return /(?:Version)[ \/]?(\S+)/.exec(a);
  }
  var Vb;
  a: {
    let a = "",
      b = Ub();
    b && (a = b ? b[1] : "");
    if (Kb) {
      var Wb;
      let c = u.document;
      Wb = c ? c.documentMode : void 0;
      if (Wb != null && Wb > parseFloat(a)) {
        Vb = String(Wb);
        break a;
      }
    }
    Vb = a;
  }
  var Xb = Vb,
    Ib = {};
  function Yb() {
    return Gb(function () {
      var a = 0,
        b = Ra(String(Xb)).split("."),
        c = Ra("526").split("."),
        d = Math.max(b.length, c.length);
      for (let g = 0; a == 0 && g < d; g++) {
        var e = b[g] || "",
          f = c[g] || "";
        do {
          e = /(\d*)(\D*)(.*)/.exec(e) || ["", "", "", ""];
          f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
          if (e[0].length == 0 && f[0].length == 0) break;
          a =
            $a(
              e[1].length == 0 ? 0 : parseInt(e[1], 10),
              f[1].length == 0 ? 0 : parseInt(f[1], 10)
            ) ||
            $a(e[2].length == 0, f[2].length == 0) ||
            $a(e[2], f[2]);
          e = e[3];
          f = f[3];
        } while (a == 0);
      }
      return a >= 0;
    });
  }
  var Zb = db();
  ob() || w("iPod");
  w("iPad");
  jb();
  var $b = fb(),
    ac = eb() && !(ob() || w("iPad") || w("iPod"));
  var bc = {},
    cc = null;
  function dc(a, b) {
    pa(a);
    b === void 0 && (b = 0);
    ec();
    b = bc[b];
    for (
      var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0;
      e < a.length - 2;
      e += 3
    ) {
      var g = a[e],
        h = a[e + 1],
        k = a[e + 2],
        l = b[g >> 2];
      g = b[((g & 3) << 4) | (h >> 4)];
      h = b[((h & 15) << 2) | (k >> 6)];
      k = b[k & 63];
      c[f++] = "" + l + g + h + k;
    }
    l = 0;
    k = d;
    switch (a.length - e) {
      case 2:
        (l = a[e + 1]), (k = b[(l & 15) << 2] || d);
      case 1:
        (a = a[e]),
          (c[f] = "" + b[a >> 2] + b[((a & 3) << 4) | (l >> 4)] + k + d);
    }
    return c.join("");
  }
  function fc(a) {
    var b = [];
    hc(a, function (c) {
      b.push(c);
    });
    return b;
  }
  function hc(a, b) {
    function c(e) {
      for (; d < a.length; ) {
        let f = a.charAt(d++),
          g = cc[f];
        if (g != null) return g;
        if (!/^[\s\xa0]*$/.test(f))
          throw Error("Unknown base64 encoding at char: " + f);
      }
      return e;
    }
    ec();
    for (var d = 0; ; ) {
      let e = c(-1),
        f = c(0),
        g = c(64),
        h = c(64);
      if (h === 64 && e === -1) break;
      b((e << 2) | (f >> 4));
      g != 64 &&
        (b(((f << 4) & 240) | (g >> 2)), h != 64 && b(((g << 6) & 192) | h));
    }
  }
  function ec() {
    if (!cc) {
      cc = {};
      var a =
          "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
            ""
          ),
        b = ["+/=", "+/", "-_=", "-_.", "-_"];
      for (let c = 0; c < 5; c++) {
        let d = a.concat(b[c].split(""));
        bc[c] = d;
        for (let e = 0; e < d.length; e++) {
          let f = d[e];
          cc[f] === void 0 && (cc[f] = e);
        }
      }
    }
  }
  var ic = /[-_.]/g,
    jc = { "-": "+", _: "/", ".": "=" };
  function mc(a) {
    return jc[a] || "";
  }
  function nc(a) {
    a = ic.test(a) ? a.replace(ic, mc) : a;
    a = atob(a);
    var b = new Uint8Array(a.length);
    for (let c = 0; c < a.length; c++) b[c] = a.charCodeAt(c);
    return b;
  }
  function oc(a) {
    return a != null && a instanceof Uint8Array;
  }
  function pc(a, b) {
    var c = a.length;
    if (c !== b.length) return !1;
    for (let d = 0; d < c; d++) if (a[d] !== b[d]) return !1;
    return !0;
  }
  var qc = {};
  function rc() {
    return sc || (sc = new tc(null, qc));
  }
  function uc(a) {
    var b = a.A;
    if (b == null) a = "";
    else if (typeof b === "string") a = b;
    else {
      let c = "",
        d = 0,
        e = b.length - 10240;
      for (; d < e; )
        c += String.fromCharCode.apply(null, b.subarray(d, (d += 10240)));
      c += String.fromCharCode.apply(null, d ? b.subarray(d) : b);
      b = btoa(c);
      a = a.A = b;
    }
    return a;
  }
  function vc(a) {
    wc(qc);
    var b = a.A;
    b == null ||
      oc(b) ||
      (typeof b === "string" ? (b = nc(b)) : (oa(b), (b = null)));
    return b == null ? b : (a.A = b);
  }
  function xc(a, b) {
    if (!a.A || !b.A || a.A === b.A) return a.A === b.A;
    if (typeof a.A === "string" && typeof b.A === "string") {
      var c = a.A;
      let d = b.A;
      b.A.length > a.A.length && ((d = a.A), (c = b.A));
      if (c.lastIndexOf(d, 0) !== 0) return !1;
      for (b = d.length; b < c.length; b++) if (c[b] !== "=") return !1;
      return !0;
    }
    c = vc(a);
    b = vc(b);
    return pc(c, b);
  }
  function yc(a, b) {
    if (typeof b === "string") b = b ? new tc(b, qc) : rc();
    else if (b instanceof Uint8Array) b = new tc(b, qc);
    else if (!(b instanceof tc)) return !1;
    return xc(a, b);
  }
  var tc = class {
      isEmpty() {
        return this.A == null;
      }
      constructor(a, b) {
        wc(b);
        this.A = a;
        if (a != null && a.length === 0)
          throw Error("ByteString should be constructed with non-empty values");
      }
    },
    sc;
  function wc(a) {
    if (a !== qc) throw Error("illegal external caller");
  }
  function zc(a, b) {
    a.__closure__error__context__984382 ||
      (a.__closure__error__context__984382 = {});
    a.__closure__error__context__984382.severity = b;
  }
  var Ac = void 0;
  function Bc() {
    var a = Error();
    zc(a, "incident");
    Ma(a);
  }
  function Cc(a) {
    a = Error(a);
    zc(a, "warning");
    return a;
  }
  function Dc(a, b) {
    if (a != null) {
      var c = Ac ?? (Ac = {});
      var d = c[a] || 0;
      d >= b || ((c[a] = d + 1), Bc());
    }
  }
  function Ec(a, b = !1) {
    return b && Symbol.for && a
      ? Symbol.for(a)
      : a != null
      ? Symbol(a)
      : Symbol();
  }
  var Fc = Ec(),
    Gc = Ec(),
    Hc = Ec(),
    Ic = Ec(),
    Jc = Ec(),
    Kc = Ec(),
    Lc = Ec("m_m", !0),
    Mc = Ec();
  var x = Ec("jas", !0),
    Nc,
    Oc = [];
  Oc[x] = 7;
  Nc = Object.freeze(Oc);
  function Pc(a, b) {
    a[x] |= b;
  }
  function Qc(a) {
    if (4 & a) return 512 & a ? 512 : 1024 & a ? 1024 : 0;
  }
  function Rc(a, b) {
    var c = 32;
    b && (c |= 2);
    return (a & 16769217) | c;
  }
  function Tc(a, b) {
    2 & b && (a |= 2);
    return a | 1;
  }
  var Uc = {};
  function Vc(a) {
    return a[Lc] === Uc;
  }
  function Wc(a, b) {
    return b === void 0
      ? a.C !== Xc && !!(2 & (a.da[x] | 0))
      : !!(2 & b) && a.C !== Xc;
  }
  var Xc = {};
  function Yc(a, b) {
    a.C = b ? Xc : void 0;
  }
  function Zc(a, b) {
    a.D = b ? Xc : void 0;
  }
  function $c(a, b) {
    if (Wc(a, b)) throw Error();
  }
  function ad(a, b) {
    if (typeof b !== "number" || b < 0 || b >= a.length) throw Error();
  }
  function bd(a, b) {
    if (typeof b !== "number" || b < 0 || b > a.length) throw Error();
  }
  Object.freeze({});
  Object.freeze({});
  function cd(a, b, c) {
    var d = b & 128 ? 0 : -1,
      e = a.length,
      f;
    if ((f = !!e))
      (f = a[e - 1]),
        (f = f != null && typeof f === "object" && f.constructor === Object);
    var g = e + (f ? -1 : 0);
    for (b = b & 128 ? 1 : 0; b < g; b++) c(b - d, a[b]);
    if (f) {
      a = a[e - 1];
      for (let h in a)
        Object.prototype.hasOwnProperty.call(a, h) && !isNaN(h) && c(+h, a[h]);
    }
  }
  var dd = {};
  function ed(a) {
    return a & 128 ? dd : void 0;
  }
  function fd(a) {
    a.mj = !0;
    return a;
  }
  var gd = fd((a) => typeof a === "number"),
    hd = fd((a) => typeof a === "string");
  function id(a) {
    if (hd(a)) {
      if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(a)) throw Error(String(a));
    } else if (gd(a) && !Number.isSafeInteger(a)) throw Error(String(a));
    return BigInt(a);
  }
  var nd = fd((a) => a >= jd && a <= kd),
    jd = BigInt(Number.MIN_SAFE_INTEGER),
    kd = BigInt(Number.MAX_SAFE_INTEGER);
  var od = 0,
    pd = 0,
    qd;
  function rd(a) {
    var b = a >>> 0;
    od = b;
    pd = ((a - b) / 4294967296) >>> 0;
  }
  function sd(a) {
    if (a < 0) {
      rd(0 - a);
      a = od;
      var b = pd;
      b = ~b;
      a ? (a = ~a + 1) : (b += 1);
      let [c, d] = [a, b];
      od = c >>> 0;
      pd = d >>> 0;
    } else rd(a);
  }
  function td(a) {
    var b = qd || (qd = new DataView(new ArrayBuffer(8)));
    b.setFloat32(0, +a, !0);
    pd = 0;
    od = b.getUint32(0, !0);
  }
  function ud(a, b) {
    var c = b * 4294967296 + (a >>> 0);
    return Number.isSafeInteger(c) ? c : vd(a, b);
  }
  function wd(a, b) {
    return id(
      BigInt.asUintN(64, (BigInt(b >>> 0) << BigInt(32)) + BigInt(a >>> 0))
    );
  }
  function xd(a, b) {
    return id(
      BigInt.asIntN(
        64,
        (BigInt.asUintN(32, BigInt(b)) << BigInt(32)) +
          BigInt.asUintN(32, BigInt(a))
      )
    );
  }
  function vd(a, b) {
    b >>>= 0;
    a >>>= 0;
    var c;
    b <= 2097151
      ? (c = "" + (4294967296 * b + a))
      : (c = "" + ((BigInt(b) << BigInt(32)) | BigInt(a)));
    return c;
  }
  function yd() {
    var a = od,
      b = pd,
      c;
    b & 2147483648
      ? (c = "" + ((BigInt(b | 0) << BigInt(32)) | BigInt(a >>> 0)))
      : (c = vd(a, b));
    return c;
  }
  function zd(a) {
    a.length < 16
      ? sd(Number(a))
      : ((a = BigInt(a)),
        (od = Number(a & BigInt(4294967295)) >>> 0),
        (pd = Number((a >> BigInt(32)) & BigInt(4294967295))));
  }
  var Ad = typeof BigInt === "function" ? BigInt.asIntN : void 0,
    Bd = typeof BigInt === "function" ? BigInt.asUintN : void 0,
    Cd = Number.isSafeInteger,
    Dd = Number.isFinite,
    Ed = Math.trunc;
  function Fd(a) {
    if (a == null || typeof a === "number") return a;
    if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a);
  }
  function Gd(a) {
    return a.displayName || a.name || "unknown type name";
  }
  function Hd(a) {
    if (a == null || typeof a === "boolean") return a;
    if (typeof a === "number") return !!a;
  }
  var Id = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
  function Jd(a) {
    switch (typeof a) {
      case "bigint":
        return !0;
      case "number":
        return Dd(a);
      case "string":
        return Id.test(a);
      default:
        return !1;
    }
  }
  function Kd(a) {
    if (!Dd(a)) throw Cc("enum");
    return a | 0;
  }
  function Ld(a) {
    return a == null ? a : Dd(a) ? a | 0 : void 0;
  }
  function Md(a) {
    if (typeof a !== "number") throw Cc("int32");
    if (!Dd(a)) throw Cc("int32");
    return a | 0;
  }
  function Nd(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return Dd(a) ? a | 0 : void 0;
  }
  function Od(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return Dd(a) ? a >>> 0 : void 0;
  }
  function Pd(a) {
    if (!Jd(a)) throw Cc("int64");
    switch (typeof a) {
      case "string":
        return Qd(a);
      case "bigint":
        return id(Ad(64, a));
      default:
        return id(Cd(a) ? a : Rd(a));
    }
  }
  function Sd(a) {
    Jd(a);
    a = Ed(a);
    if (!Cd(a)) {
      sd(a);
      var b = od,
        c = pd;
      if ((a = c & 2147483648))
        (b = (~b + 1) >>> 0), (c = ~c >>> 0), b == 0 && (c = (c + 1) >>> 0);
      b = ud(b, c);
      a = typeof b === "number" ? (a ? -b : b) : a ? "-" + b : b;
    }
    return a;
  }
  function Td(a) {
    Jd(a);
    a = Ed(a);
    (a >= 0 && Cd(a)) || (sd(a), (a = ud(od, pd)));
    return a;
  }
  function Rd(a) {
    Jd(a);
    a = Ed(a);
    Cd(a) ? (a = String(a)) : (sd(a), (a = yd()));
    return a;
  }
  function Ud(a) {
    Jd(a);
    a = Ed(a);
    a >= 0 && Cd(a) ? (a = String(a)) : (sd(a), (a = vd(od, pd)));
    return a;
  }
  function Vd(a) {
    Jd(a);
    var b = Ed(Number(a));
    if (Cd(b)) return String(b);
    b = a.indexOf(".");
    b !== -1 && (a = a.substring(0, b));
    a.indexOf(".");
    b = a.length;
    (a[0] === "-"
      ? b < 20 || (b === 20 && a <= "-9223372036854775808")
      : b < 19 || (b === 19 && a <= "9223372036854775807")) ||
      (zd(a), (a = yd()));
    return a;
  }
  function Qd(a) {
    var b = Ed(Number(a));
    if (Cd(b)) return id(b);
    b = a.indexOf(".");
    b !== -1 && (a = a.substring(0, b));
    return id(Ad(64, BigInt(a)));
  }
  function Wd(a) {
    Jd(a);
    var b = Ed(Number(a));
    if (Cd(b) && b >= 0) return String(b);
    b = a.indexOf(".");
    b !== -1 && (a = a.substring(0, b));
    a.indexOf(".");
    a[0] === "-"
      ? (b = !1)
      : ((b = a.length),
        (b = b < 20 ? !0 : b === 20 && a <= "18446744073709551615"));
    b || (zd(a), (a = vd(od, pd)));
    return a;
  }
  function Xd(a) {
    var b = Ed(Number(a));
    if (Cd(b) && b >= 0) return id(b);
    b = a.indexOf(".");
    b !== -1 && (a = a.substring(0, b));
    return id(Bd(64, BigInt(a)));
  }
  function Yd(a) {
    var b = typeof a;
    if (a == null) return a;
    if (b === "bigint") return id(Ad(64, a));
    if (Jd(a)) return b === "string" ? Qd(a) : id(Cd(a) ? a : Rd(a));
  }
  function Zd(a) {
    if (!Jd(a)) throw Cc("uint64");
    switch (typeof a) {
      case "string":
        return Xd(a);
      case "bigint":
        return id(Bd(64, a));
      default:
        return id(a >= 0 && Cd(a) ? a : Ud(a));
    }
  }
  function $d(a) {
    var b = typeof a;
    if (a == null) return a;
    if (b === "bigint") return id(Bd(64, a));
    if (Jd(a)) return b === "string" ? Xd(a) : id(a >= 0 && Cd(a) ? a : Ud(a));
  }
  function ae(a) {
    if (a == null) return a;
    var b = typeof a;
    if (b === "bigint") return id(Ad(64, a));
    if (Jd(a)) {
      if (b === "string") return Vd(a);
      if (b === "number") return Sd(a);
    }
  }
  function be(a) {
    if (a == null) return a;
    var b = typeof a;
    if (b === "bigint") return id(Bd(64, a));
    if (Jd(a)) {
      if (b === "string") return Wd(a);
      if (b === "number") return Td(a);
    }
  }
  function ce(a) {
    if (typeof a !== "string") throw Error();
    return a;
  }
  function de(a) {
    if (a != null && typeof a !== "string") throw Error();
    return a;
  }
  function ee(a) {
    return a == null || typeof a === "string" ? a : void 0;
  }
  function fe(a, b) {
    if (!(a instanceof b))
      throw Error(
        `Expected instanceof ${Gd(b)} but got ${a && Gd(a.constructor)}`
      );
    return a;
  }
  function ge(a, b, c, d) {
    if (a != null && Vc(a)) return a;
    if (!Array.isArray(a))
      return c ? (d & 2 ? b[Fc] || (b[Fc] = he(b)) : new b()) : void 0;
    c = a[x] | 0;
    d = c | (d & 32) | (d & 2);
    d !== c && (a[x] = d);
    return new b(a);
  }
  function he(a) {
    a = new a();
    Pc(a.da, 34);
    return a;
  }
  var ie = {};
  function je(a) {
    return a;
  }
  function ke(a, b) {
    if (typeof b === "string")
      try {
        b = nc(b);
      } catch (c) {
        return !1;
      }
    return oc(b) && pc(a, b);
  }
  function le(a) {
    switch (a) {
      case "bigint":
      case "string":
      case "number":
        return !0;
      default:
        return !1;
    }
  }
  function oe(a, b) {
    if (Vc(a)) a = a.da;
    else if (!Array.isArray(a)) return !1;
    if (Vc(b)) b = b.da;
    else if (!Array.isArray(b)) return !1;
    return pe(a, b, void 0, 2);
  }
  function qe(a, b) {
    return pe(a, b, void 0, 0);
  }
  function pe(a, b, c, d) {
    if (a === b || (a == null && b == null)) return !0;
    if (a instanceof Map) return a.fi(b, c);
    if (b instanceof Map) return b.fi(a, c);
    if (a == null || b == null) return !1;
    if (a instanceof tc) return yc(a, b);
    if (b instanceof tc) return yc(b, a);
    if (oc(a)) return ke(a, b);
    if (oc(b)) return ke(b, a);
    var e = typeof a,
      f = typeof b;
    if (e !== "object" || f !== "object")
      return Number.isNaN(a) || Number.isNaN(b)
        ? String(a) === String(b)
        : le(e) && le(f)
        ? "" + a === "" + b
        : (e === "boolean" && f === "number") ||
          (e === "number" && f === "boolean")
        ? !a === !b
        : !1;
    if (Vc(a) || Vc(b)) return oe(a, b);
    if (a.constructor != b.constructor) return !1;
    if (a.constructor === Array) {
      var g = a[x] | 0,
        h = b[x] | 0,
        k = a.length,
        l = b.length;
      e = Math.max(k, l);
      f = (g | h | 64) & 128 ? 0 : -1;
      if (d === 1 || (g | h) & 1) d = 1;
      else if ((g | h) & 8192) return re(a, b);
      g = k && a[k - 1];
      h = l && b[l - 1];
      (g != null && typeof g === "object" && g.constructor === Object) ||
        (g = null);
      (h != null && typeof h === "object" && h.constructor === Object) ||
        (h = null);
      k = k - f - +!!g;
      l = l - f - +!!h;
      for (let m = 0; m < e; m++)
        if (!se(m - f, a, g, k, b, h, l, f, c, d)) return !1;
      if (g) for (let m in g) if (!te(g, m, a, g, k, b, h, l, f, c)) return !1;
      if (h)
        for (let m in h)
          if (!((g && m in g) || te(h, m, a, g, k, b, h, l, f, c))) return !1;
      return !0;
    }
    if (a.constructor === Object) return qe([a], [b]);
    throw Error();
  }
  function te(a, b, c, d, e, f, g, h, k, l) {
    if (!Object.prototype.hasOwnProperty.call(a, b)) return !0;
    a = +b;
    return !Number.isFinite(a) || a < e || a < h
      ? !0
      : se(a, c, d, e, f, g, h, k, l, 2);
  }
  function se(a, b, c, d, e, f, g, h, k, l) {
    b = (a < d ? b[a + h] : void 0) ?? c?.[a];
    e = (a < g ? e[a + h] : void 0) ?? f?.[a];
    l = l === 1;
    if (
      (e == null && (!Array.isArray(b) || b.length ? 0 : (b[x] | 0) & 1)) ||
      (b == null && (!Array.isArray(e) || e.length ? 0 : (e[x] | 0) & 1))
    )
      return !0;
    a = l ? k : k?.A(a);
    return pe(b, e, a, 0);
  }
  function ue(a, b) {
    if (!Array.isArray(a) || !Array.isArray(b)) return 0;
    a = "" + a[0];
    b = "" + b[0];
    return a === b ? 0 : a < b ? -1 : 1;
  }
  function re(a, b) {
    if (!Array.isArray(a) || !Array.isArray(b)) return !1;
    a = [...a];
    b = [...b];
    Array.prototype.sort.call(a, ue);
    Array.prototype.sort.call(b, ue);
    var c = a.length,
      d = b.length;
    if (c === 0 && d === 0) return !0;
    for (var e = 0, f = 0; e < c && f < d; ) {
      let g,
        h = a[e];
      if (!Array.isArray(h)) return !1;
      let k = h[0];
      for (; e < c - 1 && qe((g = a[e + 1])[0], k); ) e++, (h = g);
      let l,
        m = b[f];
      if (!Array.isArray(m)) return !1;
      let n = m[0];
      for (; f < d - 1 && qe((l = b[f + 1])[0], n); ) f++, (m = l);
      if (!qe(k, n) || !qe(h[1], m[1])) return !1;
      e++;
      f++;
    }
    return e >= c && f >= d;
  }
  function ve(a) {
    var b = Da(Hc);
    return b ? a[b] : void 0;
  }
  function we(a, b) {
    for (let c in a)
      Object.prototype.hasOwnProperty.call(a, c) && !isNaN(c) && b(a, +c, a[c]);
  }
  function xe(a) {
    var b = new ye();
    we(a, (c, d, e) => {
      b[d] = [...e];
    });
    b.A = a.A;
    return b;
  }
  var ye = class {};
  function ze(a, b, c) {
    if (c) {
      var d;
      ((d = a[Hc] ?? (a[Hc] = new ye()))[b] ?? (d[b] = [])).push(c);
    }
  }
  function Ae(a, b) {
    b < 100 || Dc(Ic, 1);
  }
  function Be(a, b, c, d) {
    var e = d !== void 0;
    d = !!d;
    var f = Da(Hc),
      g;
    !e && f && (g = a[f]) && we(g, Ae);
    f = [];
    var h = a.length;
    g = 4294967295;
    var k = !1,
      l = !!(b & 64),
      m = l ? (b & 128 ? 0 : -1) : void 0;
    if (!(b & 1)) {
      var n = h && a[h - 1];
      n != null && typeof n === "object" && n.constructor === Object
        ? (h--, (g = h))
        : (n = void 0);
      !l ||
        b & 128 ||
        e ||
        ((k = !0), (g = (Ce ?? je)(g - m, m, a, n, void 0) + m));
    }
    b = void 0;
    for (var q = 0; q < h; q++) {
      let r = a[q];
      if (r != null && (r = c(r, d)) != null)
        if (l && q >= g) {
          let t = q - m;
          (b ?? (b = {}))[t] = r;
        } else f[q] = r;
    }
    if (n)
      for (let r in n) {
        if (!Object.prototype.hasOwnProperty.call(n, r)) continue;
        h = n[r];
        if (h == null || (h = c(h, d)) == null) continue;
        q = +r;
        let t;
        l && !Number.isNaN(q) && (t = q + m) < g
          ? (f[t] = h)
          : ((b ?? (b = {}))[r] = h);
      }
    b && (k ? f.push(b) : (f[g] = b));
    e && (c = Da(Hc)) && (a = ve(a)) && a instanceof ye && (f[c] = xe(a));
    return f;
  }
  function De(a) {
    switch (typeof a) {
      case "number":
        return Number.isFinite(a) ? a : "" + a;
      case "bigint":
        return nd(a) ? Number(a) : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          let b = a[x] | 0;
          return a.length === 0 && b & 1 ? void 0 : Be(a, b, De);
        }
        if (a != null && Vc(a)) return Ee(a);
        if (a instanceof tc) return uc(a);
        return;
    }
    return a;
  }
  var Ce;
  function Fe(a, b) {
    if (b) {
      Ce = b == null || b === je || b[Mc] !== ie ? je : b;
      try {
        return Ee(a);
      } finally {
        Ce = void 0;
      }
    }
    return Ee(a);
  }
  function Ee(a) {
    a = a.da;
    return Be(a, a[x] | 0, De);
  }
  var Ge, He;
  function Ie(a) {
    switch (typeof a) {
      case "boolean":
        return Ge || (Ge = [0, void 0, !0]);
      case "number":
        return a > 0
          ? void 0
          : a === 0
          ? He || (He = [0, void 0])
          : [-a, void 0];
      case "string":
        return [0, a];
      case "object":
        return a;
    }
  }
  function Je(a, b) {
    return Ke(a, b[0], b[1]);
  }
  function Ke(a, b, c, d = 0) {
    if (a == null) {
      var e = 32;
      c ? ((a = [c]), (e |= 128)) : (a = []);
      b && (e = (e & -16760833) | ((b & 1023) << 14));
    } else {
      if (!Array.isArray(a)) throw Error("narr");
      e = a[x] | 0;
      if (Na && 1 & e) throw Error("rfarr");
      2048 & e && !(2 & e) && Le();
      if (e & 256) throw Error("farr");
      if (e & 64) return (e | d) !== e && (a[x] = e | d), a;
      if (c && ((e |= 128), c !== a[0])) throw Error("mid");
      a: {
        c = a;
        e |= 64;
        var f = c.length;
        if (f) {
          var g = f - 1;
          let k = c[g];
          if (k != null && typeof k === "object" && k.constructor === Object) {
            b = e & 128 ? 0 : -1;
            g -= b;
            if (g >= 1024) throw Error("pvtlmt");
            for (var h in k) {
              if (!Object.prototype.hasOwnProperty.call(k, h)) continue;
              f = +h;
              if (f < g) (c[f + b] = k[h]), delete k[h];
              else break;
            }
            e = (e & -16760833) | ((g & 1023) << 14);
            break a;
          }
        }
        if (b) {
          h = Math.max(b, f - (e & 128 ? 0 : -1));
          if (h > 1024) throw Error("spvt");
          e = (e & -16760833) | ((h & 1023) << 14);
        }
      }
    }
    a[x] = e | 64 | d;
    return a;
  }
  function Le() {
    if (Na) throw Error("carr");
    Dc(Kc, 5);
  }
  function Me(a, b) {
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      var c = a[x] | 0;
      a.length === 0 && c & 1
        ? (a = void 0)
        : c & 2 ||
          (!b || 4096 & c || 16 & c
            ? (a = Ne(a, c, !1, b && !(c & 16)))
            : (Pc(a, 34), c & 4 && Object.freeze(a)));
      return a;
    }
    if (a != null && Vc(a))
      return (
        (b = a.da),
        (c = b[x] | 0),
        Wc(a, c) ? a : Oe(a, b, c) ? Pe(a, b) : Ne(b, c)
      );
    if (a instanceof tc) return a;
  }
  function Pe(a, b, c) {
    a = new a.constructor(b);
    c && Yc(a, !0);
    Zc(a, !0);
    return a;
  }
  function y(a, b) {
    $c(a);
    if (b.constructor !== a.constructor)
      throw Error("Copy source and target message must have the same type.");
    var c = b.da,
      d = c[x] | 0;
    Oe(b, c, d)
      ? ((a.da = c), Yc(a, !0), Zc(a, !0))
      : ((b = c = Ne(c, d)), Pc(b, 2048), (a.da = b), Yc(a, !1), Zc(a, !1));
  }
  function Ne(a, b, c, d) {
    d ?? (d = !!(34 & b));
    a = Be(a, b, Me, d);
    b = Rc(b, c);
    a[x] = b;
    return a;
  }
  function Qe(a) {
    var b = a.da,
      c = b[x] | 0;
    return Wc(a, c)
      ? Oe(a, b, c)
        ? Pe(a, b, !0)
        : new a.constructor(Ne(b, c, !1))
      : a;
  }
  function Re(a) {
    var b = a.da,
      c = b[x] | 0;
    return Wc(a, c)
      ? a
      : Oe(a, b, c)
      ? Pe(a, b)
      : new a.constructor(Ne(b, c, !0));
  }
  function Se(a) {
    if (a.C !== Xc) return !1;
    var b = a.da;
    b = Ne(b, b[x] | 0);
    Pc(b, 2048);
    a.da = b;
    Yc(a, !1);
    Zc(a, !1);
    return !0;
  }
  function Te(a) {
    Se(a) || $c(a, a.da[x] | 0);
  }
  function Ue(a, b) {
    b === void 0 && (b = a[x] | 0);
    b & 32 && !(b & 4096) && (a[x] = b | 4096);
  }
  function Oe(a, b, c) {
    return c & 2
      ? !0
      : c & 32 && !(c & 4096)
      ? ((b[x] = c | 2), Yc(a, !0), !0)
      : !1;
  }
  var Ve = id(0),
    We = {};
  function Ze(a, b, c, d, e) {
    Object.isExtensible(a);
    b = $e(a.da, b, c, e);
    if (b !== null || (d && a.D !== Xc)) return b;
  }
  function af(a, b, c) {
    return $e(a, b, void 0, c);
  }
  function $e(a, b, c, d) {
    if (b === -1) return null;
    var e = b + (c ? 0 : -1),
      f = a.length - 1;
    if (!(f < 1 + (c ? 0 : -1))) {
      if (e >= f) {
        var g = a[f];
        if (g != null && typeof g === "object" && g.constructor === Object) {
          c = g[b];
          var h = !0;
        } else if (e === f) c = g;
        else return;
      } else c = a[e];
      if (d && c != null) {
        d = d(c);
        if (d == null) return d;
        if (!Object.is(d, c)) return h ? (g[b] = d) : (a[e] = d), d;
      }
      return c;
    }
  }
  function bf(a, b, c) {
    Te(a);
    var d = a.da;
    cf(d, d[x] | 0, b, c);
    return a;
  }
  function cf(a, b, c, d, e) {
    var f = c + (e ? 0 : -1),
      g = a.length - 1;
    if (g >= 1 + (e ? 0 : -1) && f >= g) {
      let h = a[g];
      if (h != null && typeof h === "object" && h.constructor === Object)
        return (h[c] = d), b;
    }
    if (f <= g) return (a[f] = d), b;
    d !== void 0 &&
      ((g = ((b ?? (b = a[x] | 0)) >> 14) & 1023 || 536870912),
      c >= g ? d != null && (a[g + (e ? 0 : -1)] = { [c]: d }) : (a[f] = d));
    return b;
  }
  function z(a, b) {
    a = $e(a.da, b);
    return (a != null && Vc(a)) || Array.isArray(a);
  }
  function df(a, b, c) {
    var d = a.da;
    return ef(a, d, d[x] | 0, b, c, 3).length;
  }
  function ff(a, b, c, d) {
    var e = a.da;
    a = ef(a, e, e[x] | 0, c, b, 3);
    ad(a, d);
    return a[d];
  }
  function gf(a, b, c, d) {
    Te(a);
    var e = a.da;
    a = ef(a, e, e[x] | 0, c, b, 2, void 0, !0);
    ad(a, d);
    c = a[d];
    b = Qe(c);
    c !== b &&
      ((a[d] = b),
      (d = a === Nc ? 7 : a[x] | 0),
      4096 & d || ((a[x] = d | 4096), Ue(e)));
    return b;
  }
  function hf(a, b, c, d, e, f) {
    var g = a.da,
      h = g[x] | 0;
    d = d && d !== 4 ? (d !== 1 && (a ? Wc(a, h) : 2 & h) ? 1 : d) : 4;
    e = !!e || d === 3;
    d === 2 && Se(a) && ((g = a.da), (h = g[x] | 0));
    a = jf(g, b, f);
    var k = a === Nc ? 7 : a[x] | 0,
      l = Tc(k, h),
      m = !(4 & l);
    if (m) {
      let n = 0,
        q = 0;
      for (; n < a.length; n++) {
        let r = c(a[n]);
        r != null && (a[q++] = r);
      }
      q < n && (a.length = q);
      c = (l | 4) & -513;
      l = c &= -1025;
      l &= -4097;
    }
    l !== k && ((a[x] = l), 2 & l && Object.freeze(a));
    return (a = kf(a, l, g, h, b, f, d, m, e));
  }
  function kf(a, b, c, d, e, f, g, h, k) {
    var l = b,
      m = lf(b);
    m &&
      g === 2 &&
      ((a = [...a]),
      (l = 0),
      (b = mf(b, d)),
      (d = cf(c, d, e, a, f)),
      (m = !1));
    m ||
      (g === 1 || (g !== 4 ? 0 : 2 & b || (!(16 & b) && 32 & d))
        ? ((b |=
            !a.length || (h && !(4096 & b)) || (32 & d && !(4096 & b || 16 & b))
              ? 2
              : 256),
          b !== l && (a[x] = b),
          Object.freeze(a))
        : (k || (b |= 16), b !== l && (a[x] = b)));
    2 & b || !(4096 & b || 16 & b) || Ue(c, d);
    return a;
  }
  function jf(a, b, c) {
    a = $e(a, b, c);
    return Array.isArray(a) ? a : Nc;
  }
  function lf(a) {
    return (!!(2 & a) && !!(4 & a)) || !!(256 & a);
  }
  function nf(a) {
    a != null &&
      (typeof a === "string"
        ? (a = a ? new tc(a, qc) : rc())
        : a instanceof tc ||
          (oc(a)
            ? (a instanceof Uint8Array || Array.isArray(a),
              (a = a.length ? new tc(new Uint8Array(a), qc) : rc()))
            : (a = void 0)));
    return a;
  }
  function of(a) {
    a = Ze(a, 3, void 0, void 0, nf);
    return a == null ? rc() : a;
  }
  function pf(a, b, c, d) {
    Te(a);
    var e = a.da,
      f = e[x] | 0;
    if (c == null) return cf(e, f, b), a;
    if (!Array.isArray(c)) throw Cc();
    var g = c === Nc ? 7 : c[x] | 0,
      h = g,
      k = lf(g),
      l = k || Object.isFrozen(c);
    k || (g = 0);
    l || ((c = [...c]), (h = 0), (g = mf(g, f)), (l = !1));
    g |= 5;
    k = Qc(g) ?? 1024;
    g |= k;
    for (let m = 0; m < c.length; m++) {
      let n = c[m],
        q = d(n, k);
      Object.is(n, q) ||
        (l && ((c = [...c]), (h = 0), (g = mf(g, f)), (l = !1)), (c[m] = q));
    }
    g !== h && (l && ((c = [...c]), (g = mf(g, f))), (c[x] = g));
    cf(e, f, b, c);
    return a;
  }
  function qf(a, b, c) {
    if (b & 2) throw Error();
    var d = ed(b),
      e = jf(a, c, d),
      f = e === Nc ? 7 : e[x] | 0,
      g = Tc(f, b);
    if (2 & g || lf(g) || 16 & g)
      g === f || lf(g) || (e[x] = g),
        (e = [...e]),
        (f = 0),
        (g = mf(g, b)),
        cf(a, b, c, e, d);
    g &= -13;
    g !== f && (e[x] = g);
    return e;
  }
  function rf(a, b, c, d) {
    Te(a);
    a = a.da;
    var e = a[x] | 0;
    if (d == null) {
      let f = sf(a);
      if (tf(f, a, e, c) === b) f.set(c, 0);
      else return;
    } else e = uf(a, e, c, b);
    cf(a, e, b, d);
  }
  function vf(a, b, c, d) {
    var e = a[x] | 0,
      f = ed(e);
    e = uf(a, e, c, b, f);
    cf(a, e, b, d, f);
  }
  function sf(a) {
    return a[Gc] ?? (a[Gc] = new Map());
  }
  function uf(a, b, c, d, e) {
    d === 0 || c.includes(d);
    var f = sf(a),
      g = tf(f, a, b, c, e);
    g !== d && (g && (b = cf(a, b, g, void 0, e)), f.set(c, d));
    return b;
  }
  function tf(a, b, c, d, e) {
    var f = a.get(d);
    if (f != null) return f;
    f = 0;
    for (let g = 0; g < d.length; g++) {
      let h = d[g];
      $e(b, h, e) != null && (f !== 0 && (c = cf(b, c, f, void 0, e)), (f = h));
    }
    a.set(d, f);
    return f;
  }
  function A(a, b, c) {
    Te(a);
    a = a.da;
    var d = a[x] | 0,
      e = $e(a, c);
    b = ge(e, b, !0, d);
    b = Qe(b);
    e !== b && ((d = cf(a, d, c, b)), Ue(a, d));
    return b;
  }
  function wf(a, b, c) {
    var d = a[x] | 0,
      e = ed(d),
      f = $e(a, c, e);
    if (f != null && Vc(f)) {
      if (!Wc(f)) return Se(f), f.da;
      var g = f.da;
    } else Array.isArray(f) && ((g = f), d & 2 && Pc(g, 34));
    if (g) {
      let h = g[x] | 0;
      h & 2 && (g = Ne(g, h));
    }
    g = Je(g, b);
    g !== f && cf(a, d, c, g, e);
    return g;
  }
  function xf(a, b, c, d) {
    var e = !1;
    d = af(a, d, (f) => {
      var g = ge(f, c, !1, b);
      e = g !== f && g != null;
      return g;
    });
    if (d != null) return e && !Wc(d) && Ue(a, b), d;
  }
  function B(a, b, c) {
    a = a.da;
    return xf(a, a[x] | 0, b, c) || b[Fc] || (b[Fc] = he(b));
  }
  function yf(a, b, c) {
    var d = a.da,
      e = d[x] | 0;
    b = xf(d, e, b, c);
    if (b == null) return b;
    e = d[x] | 0;
    if (!Wc(a, e)) {
      let f = Qe(b);
      f !== b &&
        (Se(a) && ((d = a.da), (e = d[x] | 0)),
        (b = f),
        (e = cf(d, e, c, b)),
        Ue(d, e));
    }
    return b;
  }
  function ef(a, b, c, d, e, f, g, h, k) {
    f = f && f !== 4 ? (f !== 1 && (a ? Wc(a, c) : 2 & c) ? 1 : f) : 4;
    h = !!h || f === 3;
    var l = !!k && !(a ? Wc(a, c) : 2 & c);
    (f === 2 || l) && a && Se(a) && ((b = a.da), (c = b[x] | 0));
    a = jf(b, e, g);
    var m = a === Nc ? 7 : a[x] | 0,
      n = Tc(m, c);
    if ((k = !(4 & n))) {
      var q = a,
        r = c;
      let t = !!(2 & n);
      t && (r |= 2);
      let v = !t,
        F = !0,
        H = 0,
        I = 0;
      for (; H < q.length; H++) {
        let J = ge(q[H], d, !1, r);
        if (J instanceof d) {
          if (!t) {
            let ja = Wc(J);
            v && (v = !ja);
            F && (F = ja);
          }
          q[I++] = J;
        }
      }
      I < H && (q.length = I);
      n |= 4;
      n = F ? n & -4097 : n | 4096;
      n = v ? n | 8 : n & -9;
    }
    n !== m && ((a[x] = n), 2 & n && Object.freeze(a));
    if (
      l &&
      !(
        8 & n ||
        (!a.length &&
          (f === 1 || (f !== 4 ? 0 : 2 & n || (!(16 & n) && 32 & c))))
      )
    ) {
      lf(n) && ((a = [...a]), (n = mf(n, c)), (c = cf(b, c, e, a, g)));
      d = a;
      l = n;
      for (m = 0; m < d.length; m++)
        (q = d[m]), (n = Qe(q)), q !== n && (d[m] = n);
      l |= 8;
      n = l = d.length ? l | 4096 : l & -4097;
      a[x] = n;
    }
    return (a = kf(a, n, b, c, e, g, f, k, h));
  }
  function zf(a, b, c, d) {
    d != null ? fe(d, b) : (d = void 0);
    bf(a, c, d);
    d && !Wc(d) && Ue(a.da);
    return a;
  }
  function mf(a, b) {
    return (a = (2 & b ? a | 2 : a & -3) & -273);
  }
  function Af(a, b, c, d, e, f, g, h) {
    Te(a);
    b = hf(a, b, f, 2, !0, g);
    f = Qc(b === Nc ? 7 : b[x] | 0) ?? 1024;
    h && bd(b, e);
    e != void 0 ? b.splice(e, h, c(d, f)) : b.push(c(d, f));
    return a;
  }
  function Bf(a, b, c, d, e) {
    Te(a);
    var f = a.da;
    var g = void 0;
    a = ef(a, f, f[x] | 0, c, b, 2, void 0, !0);
    e ? (bd(a, d), fe(g, c)) : (g = g != null ? fe(g, c) : new c());
    d != void 0 ? a.splice(d, e, g) : a.push(g);
    d = c = a === Nc ? 7 : a[x] | 0;
    (e = Wc(g)) ? ((c &= -9), a.length === 1 && (c &= -4097)) : (c |= 4096);
    c !== d && (a[x] = c);
    e || Ue(f);
    return g;
  }
  function Cf(a, b, c) {
    return Ze(a, b, void 0, c, $d);
  }
  function Df(a, b, c) {
    return Nd(Ze(a, b, void 0, c));
  }
  function C(a, b, c = !1) {
    return Hd(Ze(a, b)) ?? c;
  }
  function Ef(a, b, c = 0) {
    return Df(a, b) ?? c;
  }
  function D(a, b, c = 0) {
    return Ze(a, b, void 0, void 0, Fd) ?? c;
  }
  function E(a, b) {
    return ee(Ze(a, b)) ?? "";
  }
  function Ff(a, b, c = 0) {
    return Ld(Ze(a, b)) ?? c;
  }
  function Gf(a, b, c) {
    a = hf(a, b, ee, 3, !0);
    ad(a, c);
    return a[c];
  }
  function Hf(a, b, c) {
    a = hf(a, b, Ld, 3, !0);
    ad(a, c);
    return a[c];
  }
  function If(a, b, c) {
    var d = a.da;
    c = tf(sf(d), d, void 0, c);
    return E(a, c === b ? b : -1);
  }
  function G(a, b) {
    return Hd(Ze(a, b, void 0, We));
  }
  function K(a, b) {
    return Df(a, b, We);
  }
  function Jf(a, b) {
    return Ze(a, b, void 0, We, Yd);
  }
  function Kf(a, b) {
    return Ze(a, b, void 0, We, Fd);
  }
  function Lf(a, b) {
    return ee(Ze(a, b, void 0, We));
  }
  function M(a, b, c) {
    if (c != null && typeof c !== "boolean")
      throw Error(`Expected boolean but got ${oa(c)}: ${c}`);
    return bf(a, b, c);
  }
  function N(a, b, c) {
    return bf(a, b, c == null ? c : Md(c));
  }
  function Mf(a, b, c) {
    if (c != null) {
      if (typeof c !== "number") throw Cc("uint32");
      if (!Dd(c)) throw Cc("uint32");
      c >>>= 0;
    }
    return bf(a, b, c);
  }
  function Nf(a, b, c) {
    bf(a, b, c == null ? c : Pd(c));
  }
  function P(a, b, c) {
    if (c != null && typeof c !== "number")
      throw Error(
        `Value of float/double field must be a number, found ${typeof c}: ${c}`
      );
    return bf(a, b, c);
  }
  function Q(a, b, c) {
    return bf(a, b, de(c));
  }
  function R(a, b, c) {
    return bf(a, b, c == null ? c : Kd(c));
  }
  function Of(a, b, c) {
    Af(a, b, Kd, c, void 0, Ld);
  }
  function Pf(a, b) {
    return Ze(a, b, void 0, void 0, Fd) != null;
  }
  function Rf(a, b) {
    return ee(Ze(a, b)) != null;
  }
  function Sf(a, b) {
    return Ld(Ze(a, b)) != null;
  }
  var Tf = class {
    constructor(a, b, c) {
      this.buffer = a;
      if (c && !b) throw Error();
      this.A = b;
    }
  };
  function Uf(a, b) {
    if (typeof a === "string") return new Tf(nc(a), b);
    if (Array.isArray(a)) return new Tf(new Uint8Array(a), b);
    if (a.constructor === Uint8Array) return new Tf(a, !1);
    if (a.constructor === ArrayBuffer)
      return (a = new Uint8Array(a)), new Tf(a, !1);
    if (a.constructor === tc)
      return (b = vc(a) || new Uint8Array(0)), new Tf(b, !0, a);
    if (a instanceof Uint8Array)
      return (
        (a =
          a.constructor === Uint8Array
            ? a
            : new Uint8Array(a.buffer, a.byteOffset, a.byteLength)),
        new Tf(a, !1)
      );
    throw Error();
  }
  function Vf(a, b) {
    var c = 0,
      d = 0,
      e = 0,
      f = a.B,
      g = a.A;
    do {
      var h = f[g++];
      c |= (h & 127) << e;
      e += 7;
    } while (e < 32 && h & 128);
    if (e > 32)
      for (d |= (h & 127) >> 4, e = 3; e < 32 && h & 128; e += 7)
        (h = f[g++]), (d |= (h & 127) << e);
    Wf(a, g);
    if (!(h & 128)) return b(c >>> 0, d >>> 0);
    throw Error();
  }
  function Xf(a) {
    for (var b = 0, c = a.A, d = c + 10, e = a.B; c < d; ) {
      let f = e[c++];
      b |= f;
      if ((f & 128) === 0) return Wf(a, c), !!(b & 127);
    }
    throw Error();
  }
  function Yf(a) {
    var b = a.B,
      c = a.A,
      d = b[c++],
      e = d & 127;
    if (
      d & 128 &&
      ((d = b[c++]),
      (e |= (d & 127) << 7),
      d & 128 &&
        ((d = b[c++]),
        (e |= (d & 127) << 14),
        d & 128 &&
          ((d = b[c++]),
          (e |= (d & 127) << 21),
          d & 128 &&
            ((d = b[c++]),
            (e |= d << 28),
            d & 128 &&
              b[c++] & 128 &&
              b[c++] & 128 &&
              b[c++] & 128 &&
              b[c++] & 128 &&
              b[c++] & 128))))
    )
      throw Error();
    Wf(a, c);
    return e;
  }
  function Zf(a) {
    var b = a.B,
      c = a.A,
      d = b[c + 0],
      e = b[c + 1],
      f = b[c + 2];
    b = b[c + 3];
    Wf(a, a.A + 4);
    return ((d << 0) | (e << 8) | (f << 16) | (b << 24)) >>> 0;
  }
  function $f(a) {
    var b = Zf(a);
    a = (b >> 31) * 2 + 1;
    var c = (b >>> 23) & 255;
    b &= 8388607;
    return c == 255
      ? b
        ? NaN
        : a * Infinity
      : c == 0
      ? a * 1.401298464324817e-45 * b
      : a * Math.pow(2, c - 150) * (b + 8388608);
  }
  function ag(a) {
    return Yf(a);
  }
  function Wf(a, b) {
    a.A = b;
    if (b > a.C) throw Error();
  }
  function bg(a, b) {
    if (b < 0) throw Error();
    var c = a.A;
    b = c + b;
    if (b > a.C) throw Error();
    a.A = b;
    return c;
  }
  function cg(a, b) {
    if (b == 0) return rc();
    var c = bg(a, b);
    a.af && a.F
      ? (c = a.B.subarray(c, c + b))
      : ((a = a.B),
        (b = c + b),
        (c = c === b ? new Uint8Array(0) : a.slice(c, b)));
    return c.length == 0 ? rc() : new tc(c, qc);
  }
  var dg = class {
      constructor(a, b, c, d) {
        this.B = null;
        this.F = !1;
        this.G = null;
        this.A = this.C = this.D = 0;
        this.init(a, b, c, d);
      }
      init(a, b, c, { af: d = !1, Vf: e = !1 } = {}) {
        this.af = d;
        this.Vf = e;
        a &&
          ((a = Uf(a, this.Vf)),
          (this.B = a.buffer),
          (this.F = a.A),
          (this.G = null),
          (this.D = b || 0),
          (this.C = c !== void 0 ? this.D + c : this.B.length),
          (this.A = this.D));
      }
      clear() {
        this.B = null;
        this.F = !1;
        this.G = null;
        this.A = this.C = this.D = 0;
        this.af = !1;
      }
      getBuffer() {
        if (this.F) throw Error();
        return this.B;
      }
      reset() {
        this.A = this.D;
      }
      getCursor() {
        return this.A;
      }
    },
    eg = [];
  var fg = 0;
  function gg(a, b, c, d) {
    if (hg.length) {
      let e = hg.pop();
      ig(e, d);
      e.A.init(a, b, c, d);
      return e;
    }
    return new jg(a, b, c, d);
  }
  function ig(a, { Cg: b = !1 } = {}) {
    a.Cg = b;
  }
  function kg(a) {
    a.A.clear();
    a.D = -1;
    a.C = -1;
    a.B = -1;
    hg.length < 100 && hg.push(a);
  }
  function lg(a) {
    var b = a.A;
    if (b.A == b.C) return !1;
    a.F = a.A.getCursor();
    b = Yf(a.A) >>> 0;
    var c = b >>> 3,
      d = b & 7;
    if (!(d >= 0 && d <= 5)) throw Error();
    if (c < 1) throw Error();
    a.D = b;
    a.C = c;
    a.B = d;
    return !0;
  }
  function mg(a) {
    try {
      switch (a.B) {
        case 0:
          a.B != 0 ? mg(a) : Xf(a.A);
          break;
        case 1:
          var b = a.A;
          Wf(b, b.A + 8);
          break;
        case 2:
          ng(a);
          break;
        case 5:
          var c = a.A;
          Wf(c, c.A + 4);
          break;
        case 3:
          og();
          let d = a.C;
          try {
            do {
              if (!lg(a)) throw Error();
              if (a.B == 4) {
                if (a.C != d) throw Error();
                break;
              }
              mg(a);
            } while (1);
          } catch (e) {
            if (e instanceof RangeError) throw new SyntaxError();
            throw e;
          } finally {
            fg > 0 && fg--;
          }
          break;
        default:
          throw Error();
      }
    } catch (d) {
      if (d instanceof RangeError) throw new SyntaxError();
      throw d;
    }
  }
  function ng(a) {
    if (a.B != 2) mg(a);
    else {
      var b = Yf(a.A) >>> 0;
      a = a.A;
      Wf(a, a.A + b);
    }
  }
  function og() {
    if (fg >= 100) throw new SyntaxError();
    fg++;
  }
  function pg(a, b) {
    if (!a.Cg) {
      let c = a.A.getCursor() - b;
      a.A.A = b;
      b = cg(a.A, c);
      a.A.getCursor();
      return b;
    }
  }
  function qg(a) {
    var b = a.F;
    mg(a);
    return pg(a, b);
  }
  function rg(a, b, c) {
    var d = a.A.C,
      e = Yf(a.A) >>> 0;
    e = a.A.getCursor() + e;
    var f = e - d;
    f <= 0 &&
      ((a.A.C = e), c(b, a, void 0, void 0, void 0), (f = e - a.A.getCursor()));
    if (f) throw Error();
    a.A.A = e;
    a.A.C = d;
  }
  function sg(a, b) {
    for (var c = 0, d = 0; lg(a) && a.B != 4; )
      a.D !== 16 || c
        ? a.D !== 26 || d
          ? mg(a)
          : c
          ? ((d = -1), rg(a, c, b))
          : ((d = a.F), ng(a))
        : ((c = Yf(a.A) >>> 0), d && ((a.A.A = d), (d = 0)));
    if (a.D !== 12 || !d || !c) throw Error();
  }
  function tg(a) {
    var b = Yf(a.A) >>> 0,
      c = a.A;
    a = bg(c, b);
    var d = c.B;
    (c = Ja) || (c = Ja = new TextDecoder("utf-8", { fatal: !0 }));
    b = a + b;
    d = a === 0 && b === d.length ? d : d.subarray(a, b);
    try {
      var e = c.decode(d);
    } catch (f) {
      if (Ia === void 0) {
        try {
          c.decode(new Uint8Array([128]));
        } catch (g) {}
        try {
          c.decode(new Uint8Array([97])), (Ia = !0);
        } catch (g) {
          Ia = !1;
        }
      }
      !Ia && (Ja = void 0);
      throw f;
    }
    return e;
  }
  function ug(a, b, c) {
    var d = Yf(a.A) >>> 0;
    for (d = a.A.getCursor() + d; a.A.getCursor() < d; ) c.push(b(a.A));
  }
  var jg = class {
      constructor(a, b, c, d) {
        if (eg.length) {
          let e = eg.pop();
          e.init(a, b, c, d);
          a = e;
        } else a = new dg(a, b, c, d);
        this.A = a;
        this.F = this.A.getCursor();
        this.B = this.D = this.C = -1;
        ig(this, d);
      }
      getCursor() {
        return this.A.getCursor();
      }
      getBuffer() {
        return this.A.getBuffer();
      }
      reset() {
        this.A.reset();
        this.F = this.A.getCursor();
        this.B = this.C = this.D = -1;
      }
    },
    hg = [];
  function vg(a) {
    return new wg(a & 4294967295, Math.floor(a / 4294967296));
  }
  function xg(a) {
    if (!a) return yg || (yg = new wg(0, 0));
    if (!/^\d+$/.test(a)) return null;
    zd(a);
    return new wg(od, pd);
  }
  function zg(a) {
    return a.B === 0 ? new wg(0, 1 + ~a.A) : new wg(~a.B + 1, ~a.A);
  }
  var wg = class {
      constructor(a, b) {
        this.B = a >>> 0;
        this.A = b >>> 0;
      }
    },
    yg;
  function Ag(a) {
    return new Bg(a & 4294967295, Math.floor(a / 4294967296));
  }
  var Bg = class {
      constructor(a, b) {
        this.B = a >>> 0;
        this.A = b >>> 0;
      }
    },
    Cg,
    Dg,
    Eg,
    Fg,
    Gg,
    Hg,
    Ig,
    Jg;
  function Kg(a, b, c) {
    if (typeof BigInt64Array !== "undefined")
      return (
        Ig ||
          ((Ig = new BigInt64Array(1)),
          (Jg = new Uint32Array(Ig.buffer)),
          (Ig[0] = BigInt(1)),
          (Hg = Jg[0] === 1)),
        (Ig[0] = a),
        (a = Hg ? 0 : 1),
        new b(Jg[a], Jg[1 - a])
      );
    Gg ||
      ((Dg = BigInt(Number.MIN_SAFE_INTEGER)),
      (Eg = BigInt(Number.MAX_SAFE_INTEGER)),
      (Fg = BigInt(4294967295)),
      (Gg = BigInt(32)));
    if (a >= Dg && a <= Eg) return c(Number(a));
    a = BigInt.asUintN(64, a);
    return new b(Number(a & Fg), Number(a >> Gg));
  }
  function Lg(a, b, c) {
    for (; c > 0 || b > 127; )
      a.A.push((b & 127) | 128),
        (b = ((b >>> 7) | (c << 25)) >>> 0),
        (c >>>= 7);
    a.A.push(b);
  }
  function Mg(a, b) {
    a.A.push((b >>> 0) & 255);
    a.A.push((b >>> 8) & 255);
    a.A.push((b >>> 16) & 255);
    a.A.push((b >>> 24) & 255);
  }
  function Ng(a, b) {
    for (; b > 127; ) a.A.push((b & 127) | 128), (b >>>= 7);
    a.A.push(b);
  }
  function Og(a, b) {
    if (b >= 0) Ng(a, b);
    else {
      for (let c = 0; c < 9; c++) a.A.push((b & 127) | 128), (b >>= 7);
      a.A.push(1);
    }
  }
  var Pg = class {
    constructor() {
      this.A = [];
    }
    length() {
      return this.A.length;
    }
    end() {
      var a = this.A;
      this.A = [];
      return a;
    }
  };
  function Qg(a, b) {
    b.length !== 0 && (a.C.push(b), (a.B += b.length));
  }
  function Rg(a, b, c) {
    Ng(a.A, b * 8 + c);
  }
  function Sg(a, b) {
    Rg(a, b, 2);
    b = a.A.end();
    Qg(a, b);
    b.push(a.B);
    return b;
  }
  function Tg(a, b) {
    var c = b.pop();
    for (c = a.B + a.A.length() - c; c > 127; )
      b.push((c & 127) | 128), (c >>>= 7), a.B++;
    b.push(c);
    a.B++;
  }
  function Ug(a, b, c) {
    c != null && ((c = parseInt(c, 10)), Rg(a, b, 0), Og(a.A, c));
  }
  function Vg(a, b, c) {
    Rg(a, b, 2);
    Ng(a.A, c.length);
    Qg(a, a.A.end());
    Qg(a, c);
  }
  var Wg = class {
    constructor() {
      this.C = [];
      this.B = 0;
      this.A = new Pg();
    }
  };
  function Xg() {
    var a = class {
      constructor() {
        throw Error();
      }
    };
    Object.setPrototypeOf(a, a.prototype);
    return a;
  }
  var Yg = Xg(),
    Zg = Xg(),
    $g = Xg(),
    ah = Xg(),
    bh = Xg(),
    ch = Xg(),
    dh = Xg(),
    eh = Xg(),
    fh = Xg(),
    kh = Xg(),
    lh = Xg(),
    mh = Xg(),
    nh = Xg(),
    oh = Xg(),
    ph = Xg(),
    qh = Xg(),
    rh = Xg(),
    sh = Xg(),
    th = Xg(),
    uh = Xg();
  function vh(a, b) {
    return (
      a === b ||
      (a == null && b == null) ||
      (!(!a || !b) && a instanceof b.constructor && oe(a, b))
    );
  }
  var S = class {
    constructor(a, b) {
      this.da = Ke(a, b, void 0, 2048);
    }
    toJSON() {
      return Fe(this);
    }
    vc(a) {
      return JSON.stringify(Fe(this, a));
    }
    clone() {
      var a = this.da,
        b = a[x] | 0;
      return Oe(this, a, b)
        ? Pe(this, a, !0)
        : new this.constructor(Ne(a, b, !1));
    }
  };
  S.prototype[Lc] = Uc;
  S.prototype.toString = function () {
    return this.da.toString();
  };
  function wh(a, b) {
    y(a, b);
  }
  function xh(a, b) {
    if (b != null) y(a, b);
    else {
      $c(a);
      b = a.da;
      let c = b[x] | 0;
      b = ed(c) ? [b[0]] : [];
      b[x] = Rc(c);
      Pc(b, 2048);
      a.da = b;
      Yc(a, !1);
      Zc(a, !1);
    }
  }
  var yh = class {
    constructor(a, b, c, d) {
      this.C = a;
      this.D = b;
      this.A = c;
      this.B = d;
      a = Da($g);
      (a = !!a && d === a) || ((a = Da(ah)), (a = !!a && d === a));
      this.F = a;
    }
  };
  function zh(a, b) {
    return new yh(a, b, !1, $g);
  }
  function Ah(a, b, c, d, e) {
    b = Bh(b, d);
    b != null && ((c = Sg(a, c)), e(b, a), Tg(a, c));
  }
  var Ch = zh(function (a, b, c, d, e) {
      if (a.B !== 2) return !1;
      rg(a, wf(b, d, c), e);
      return !0;
    }, Ah),
    Dh = zh(function (a, b, c, d, e) {
      if (a.B !== 2) return !1;
      rg(a, wf(b, d, c), e);
      return !0;
    }, Ah),
    Eh = Symbol(),
    Fh = Symbol(),
    Gh = Symbol(),
    Hh = Symbol(),
    Ih = Symbol(),
    Jh = Symbol(),
    Kh,
    Lh;
  function Mh(a, b, c, d) {
    var e = d[a];
    if (e) return e;
    e = {};
    e.bf = d;
    e.mc = Ie(d[0]);
    var f = d[1],
      g = 1;
    f &&
      f.constructor === Object &&
      ((e.extensions = f),
      (f = d[++g]),
      typeof f === "function" &&
        f.length > 0 &&
        ((e.Pg = !0),
        Kh ?? (Kh = f),
        Lh ?? (Lh = d[g + 1]),
        (f = d[(g += 2)])));
    for (var h = {}; f && Nh(f); ) {
      for (var k = 0; k < f.length; k++) h[f[k]] = f;
      f = d[++g];
    }
    for (k = 1; f !== void 0; ) {
      typeof f === "number" && ((k += f), (f = d[++g]));
      let n;
      var l = void 0;
      f instanceof yh ? (n = f) : ((n = Ch), g--);
      if (n?.F) {
        f = d[++g];
        l = d;
        var m = g;
        typeof f === "function" && ((f = f()), (l[m] = f));
        l = f;
      }
      f = d[++g];
      m = k + 1;
      typeof f === "number" && f < 0 && ((m -= f), (f = d[++g]));
      for (; k < m; k++) {
        let q = h[k];
        l ? c(e, k, n, l, q) : b(e, k, n, q);
      }
    }
    return (d[a] = e);
  }
  function Nh(a) {
    return (
      Array.isArray(a) && !!a.length && typeof a[0] === "number" && a[0] > 0
    );
  }
  function Oh(a) {
    return Array.isArray(a) ? (a[0] instanceof yh ? a : [Dh, a]) : [a, void 0];
  }
  function Bh(a, b) {
    if (a instanceof S) return a.da;
    if (Array.isArray(a)) return Je(a, b);
  }
  function Ph(a, b, c, d) {
    var e = c.C;
    a[b] = d ? (f, g, h) => e(f, g, h, d) : e;
  }
  function Qh(a, b, c, d, e) {
    var f = c.C,
      g,
      h;
    a[b] = (k, l, m) =>
      f(k, l, m, h || (h = Mh(Fh, Ph, Qh, d).mc), g || (g = Rh(d)), e);
  }
  function Rh(a) {
    var b = a[Gh];
    if (b != null) return b;
    var c = Mh(Fh, Ph, Qh, a);
    b = c.Pg
      ? (d, e) => Kh(d, e, c)
      : (d, e) => {
          a: {
            og();
            try {
              for (; lg(e) && e.B != 4; ) {
                let h = e.C,
                  k = c[h];
                if (k == null) {
                  let l = c.extensions;
                  if (l) {
                    let m = l[h];
                    if (m) {
                      let n = Sh(m);
                      n != null && (k = c[h] = n);
                    }
                  }
                }
                (k != null && k(e, d, h)) || ze(d, h, qg(e));
              }
              let g = ve(d);
              g && (g.A = c.bf[Jh]);
              var f = !0;
              break a;
            } catch (g) {
              if (g instanceof RangeError) throw new SyntaxError();
              throw g;
            } finally {
              fg > 0 && fg--;
            }
            f = void 0;
          }
          return f;
        };
    a[Gh] = b;
    a[Jh] = Th.bind(a);
    return b;
  }
  function Th(a, b, c, d) {
    var e = this[Fh],
      f = this[Gh],
      g = Je(void 0, e.mc),
      h = ve(a);
    if (h) {
      var k = !1,
        l = e.extensions;
      if (l) {
        e = (m, n, q) => {
          if (q.length !== 0)
            if (l[n])
              for (let r of q) {
                m = gg(r);
                try {
                  (k = !0), f(g, m);
                } finally {
                  kg(m);
                }
              }
            else d?.(a, n, q);
        };
        if (b == null) we(h, e);
        else if (h != null) {
          let m = h[b];
          m && e(h, b, m);
        }
        if (k) {
          let m = a[x] | 0;
          if (m & 2 && m & 2048 && !c?.Bj) throw Error();
          let n = ed(m),
            q = (r, t) => {
              if ($e(a, r, n) != null)
                switch (c?.Aj) {
                  case 1:
                    return;
                  default:
                    throw Error();
                }
              t != null && (m = cf(a, m, r, t, n));
              delete h[r];
            };
          b == null
            ? cd(g, g[x] | 0, (r, t) => {
                q(r, t);
              })
            : q(b, $e(g, b, n));
        }
      }
    }
  }
  function Sh(a) {
    a = Oh(a);
    var b = a[0].C;
    if ((a = a[1])) {
      let c = Rh(a),
        d = Mh(Fh, Ph, Qh, a).mc;
      return (e, f, g) => b(e, f, g, d, c);
    }
    return b;
  }
  function Uh(a, b, c) {
    a[b] = c.D;
  }
  function Vh(a, b, c, d) {
    var e,
      f,
      g = c.D;
    a[b] = (h, k, l) =>
      g(h, k, l, f || (f = Mh(Eh, Uh, Vh, d).mc), e || (e = Wh(d)));
  }
  function Wh(a) {
    var b = a[Hh];
    if (!b) {
      let c = Mh(Eh, Uh, Vh, a);
      b = (d, e) => Xh(d, e, c);
      a[Hh] = b;
    }
    return b;
  }
  function Xh(a, b, c) {
    cd(a, a[x] | 0, (d, e) => {
      if (e != null) {
        var f = Yh(c, d);
        f ? f(b, e, d) : d < 500 || Dc(Jc, 3);
      }
    });
    (a = ve(a)) &&
      we(a, (d, e, f) => {
        Qg(b, b.A.end());
        for (d = 0; d < f.length; d++) Qg(b, vc(f[d]) || new Uint8Array(0));
      });
  }
  function Yh(a, b) {
    var c = a[b];
    if (c) return c;
    if ((c = a.extensions))
      if ((c = c[b])) {
        c = Oh(c);
        var d = c[0].D;
        if ((c = c[1])) {
          let e = Wh(c),
            f = Mh(Eh, Uh, Vh, c).mc;
          c = a.Pg ? Lh(f, e) : (g, h, k) => d(g, h, k, f, e);
        } else c = d;
        return (a[b] = c);
      }
  }
  var Zh = id(0);
  function $h(a, b) {
    if (Array.isArray(b)) {
      var c = b[x] | 0;
      if (c & 4) return b;
      for (var d = 0, e = 0; d < b.length; d++) {
        let f = a(b[d]);
        f != null && (b[e++] = f);
      }
      e < d && (b.length = e);
      a = (c | 5) & -1537;
      a !== c && (b[x] = a);
      a & 2 && Object.freeze(b);
      return b;
    }
  }
  function ai(a, b, c) {
    return new yh(a, b, !1, c);
  }
  function bi(a, b, c) {
    return new yh(a, b, Yg, c);
  }
  function ci(a, b, c) {
    cf(a, a[x] | 0, b, c, ed(a[x] | 0));
  }
  function di(a, b, c) {
    b = ae(b);
    if (b != null && b != null)
      switch ((Rg(a, c, 0), typeof b)) {
        case "number":
          a = a.A;
          sd(b);
          Lg(a, od, pd);
          break;
        case "bigint":
          c = Kg(b, Bg, Ag);
          Lg(a.A, c.B, c.A);
          break;
        default:
          b
            ? /^-?\d+$/.test(b)
              ? (zd(b), (c = new Bg(od, pd)))
              : (c = null)
            : (c = Cg || (Cg = new Bg(0, 0))),
            Lg(a.A, c.B, c.A);
      }
  }
  function ei(a, b, c) {
    b = Nd(b);
    b != null && b != null && (Rg(a, c, 0), Og(a.A, b));
  }
  function fi(a, b, c) {
    b = Hd(b);
    b != null && (Rg(a, c, 0), a.A.A.push(b ? 1 : 0));
  }
  function gi(a, b, c) {
    b = ee(b);
    b != null && Vg(a, c, La(b));
  }
  function hi(a, b, c, d, e) {
    b = Bh(b, d);
    b != null && ((c = Sg(a, c)), e(b, a), Tg(a, c));
  }
  function ii(a, b, c) {
    Ug(a, c, Nd(b));
  }
  function ji(a, b, c) {
    if (a.B !== 0) return !1;
    ci(b, c, Vf(a.A, wd));
    return !0;
  }
  function ki(a, b, c) {
    if (a.B !== 0 && a.B !== 2) return !1;
    b = qf(b, b[x] | 0, c);
    a.B == 2 ? ug(a, ag, b) : b.push(Yf(a.A));
    return !0;
  }
  var li = ai(
      function (a, b, c) {
        if (a.B !== 1) return !1;
        a = a.A;
        var d = a.G;
        d ||
          ((d = a.B),
          (d = a.G = new DataView(d.buffer, d.byteOffset, d.byteLength)));
        d = d.getFloat64(a.A, !0);
        Wf(a, a.A + 8);
        ci(b, c, d);
        return !0;
      },
      function (a, b, c) {
        b = Fd(b);
        b != null &&
          (Rg(a, c, 1),
          (a = a.A),
          (c = qd || (qd = new DataView(new ArrayBuffer(8)))),
          c.setFloat64(0, +b, !0),
          (od = c.getUint32(0, !0)),
          (pd = c.getUint32(4, !0)),
          Mg(a, od),
          Mg(a, pd));
      },
      sh
    ),
    mi = ai(
      function (a, b, c) {
        if (a.B !== 5) return !1;
        ci(b, c, $f(a.A));
        return !0;
      },
      function (a, b, c) {
        b = Fd(b);
        b != null && (Rg(a, c, 5), (a = a.A), td(b), Mg(a, od));
      },
      rh
    ),
    ni = ai(
      function (a, b, c) {
        a.B !== 0 ? (a = !1) : (ci(b, c, Vf(a.A, xd)), (a = !0));
        return a;
      },
      di,
      mh
    ),
    oi = ai(
      function (a, b, c) {
        return ji(a, b, c);
      },
      function (a, b, c) {
        b = be(b);
        if (b != null && b != null)
          switch ((Rg(a, c, 0), (a = a.A), typeof b)) {
            case "number":
              b < 0
                ? ((c = zg(vg(-b))), Lg(a, c.B, c.A))
                : (sd(b), Lg(a, od, pd));
              break;
            case "bigint":
              c = b < BigInt(0) ? zg(Kg(-b, wg, vg)) : Kg(b, wg, vg);
              Lg(a, c.B, c.A);
              break;
            default:
              (c = b.length && b[0] === "-" ? zg(xg(b.substring(1))) : xg(b)),
                Lg(a, c.B, c.A);
          }
      },
      nh
    ),
    pi = ai(
      function (a, b, c) {
        if (a.B !== 0) return !1;
        ci(b, c, Yf(a.A));
        return !0;
      },
      ei,
      dh
    ),
    qi = bi(
      function (a, b, c) {
        if (a.B !== 0 && a.B !== 2) return !1;
        b = qf(b, b[x] | 0, c);
        a.B == 2 ? ug(a, Yf, b) : b.push(Yf(a.A));
        return !0;
      },
      function (a, b, c) {
        b = $h(Nd, b);
        if (b != null)
          for (let g = 0; g < b.length; g++) {
            var d = a,
              e = c,
              f = b[g];
            f != null && (Rg(d, e, 0), Og(d.A, f));
          }
      },
      dh
    ),
    ri = ai(
      function (a, b, c) {
        if (a.B !== 1) b = !1;
        else {
          var d = a.A;
          a = Zf(d);
          d = Zf(d);
          a = wd(a, d);
          ci(b, c, a);
          b = !0;
        }
        return b;
      },
      function (a, b, c) {
        b = be(b);
        if (b != null)
          switch ((Rg(a, c, 1), typeof b)) {
            case "number":
              a = a.A;
              rd(b);
              Mg(a, od);
              Mg(a, pd);
              break;
            case "bigint":
              c = Kg(b, wg, vg);
              a = a.A;
              b = c.A;
              Mg(a, c.B);
              Mg(a, b);
              break;
            default:
              (c = xg(b)), (a = a.A), (b = c.A), Mg(a, c.B), Mg(a, b);
          }
      },
      ph
    ),
    si = ai(
      function (a, b, c) {
        if (a.B !== 5) return !1;
        ci(b, c, Zf(a.A));
        return !0;
      },
      function (a, b, c) {
        b = Od(b);
        b != null && (Rg(a, c, 5), Mg(a.A, b));
      },
      kh
    ),
    ti = ai(
      function (a, b, c) {
        if (a.B !== 0) return !1;
        ci(b, c, Xf(a.A));
        return !0;
      },
      fi,
      bh
    ),
    ui = ai(
      function (a, b, c) {
        if (a.B !== 2) return !1;
        ci(b, c, tg(a));
        return !0;
      },
      gi,
      ch
    ),
    vi = bi(
      function (a, b, c) {
        if (a.B !== 2) return !1;
        a = tg(a);
        qf(b, b[x] | 0, c).push(a);
        return !0;
      },
      function (a, b, c) {
        b = $h(ee, b);
        if (b != null)
          for (let g = 0; g < b.length; g++) {
            var d = a,
              e = c,
              f = b[g];
            f != null && Vg(d, e, La(f));
          }
      },
      ch
    ),
    wi = ai(
      function (a, b, c, d) {
        if (a.B !== 2) return !1;
        vf(b, c, d, tg(a));
        return !0;
      },
      gi,
      ch
    ),
    xi = (function (a, b, c = $g) {
      return new yh(a, b, Yg, c);
    })(
      function (a, b, c, d, e) {
        if (a.B !== 2) return !1;
        d = Je(void 0, d);
        qf(b, b[x] | 0, c).push(d);
        rg(a, d, e);
        return !0;
      },
      function (a, b, c, d, e) {
        if (Array.isArray(b)) {
          for (let f = 0; f < b.length; f++) hi(a, b[f], c, d, e);
          a = b[x] | 0;
          a & 1 || (b[x] = a | 1);
        }
      }
    ),
    yi = zh(function (a, b, c, d, e, f) {
      if (a.B !== 2) return !1;
      var g = b[x] | 0;
      uf(b, g, f, c, ed(g));
      b = wf(b, d, c);
      rg(a, b, e);
      return !0;
    }, hi),
    zi = ai(
      function (a, b, c) {
        if (a.B !== 2) return !1;
        var d = Yf(a.A) >>> 0;
        a = cg(a.A, d);
        ci(b, c, a);
        return !0;
      },
      function (a, b, c) {
        b = b == null || typeof b == "string" || b instanceof tc ? b : void 0;
        b != null && Vg(a, c, Uf(b, !0).buffer);
      },
      th
    ),
    Ai = ai(
      function (a, b, c) {
        if (a.B !== 0) return !1;
        ci(b, c, Yf(a.A));
        return !0;
      },
      ii,
      uh
    ),
    Bi = bi(
      ki,
      function (a, b, c) {
        b = $h(Nd, b);
        if (b != null) for (let d = 0; d < b.length; d++) Ug(a, c, b[d]);
      },
      uh
    ),
    Ci = ai(
      function (a, b, c, d) {
        if (a.B !== 0) return !1;
        vf(b, c, d, Yf(a.A));
        return !0;
      },
      ii,
      uh
    );
  var Di = Symbol(),
    Ei = Symbol();
  function Fi(a) {
    var { [Di]: b, [Ei]: c } = a;
    a = Mh(Ih, Gi, Hi, b);
    a.messageType ?? (a.messageType = c);
    return a;
  }
  function Ii(a) {
    var b = a.Dg ?? (a.Dg = {});
    for (let c in a.extensions) {
      let d = +c;
      if (isNaN(d)) continue;
      if (b[d]) continue;
      let [e, f] = Oh(a.extensions[d]),
        g = f;
      g && typeof g === "function" && (g = g());
      b[d] = g ? new Ji(g, e.B, e.A, !1, g) : new Ki(e.B, e.A);
    }
    return a.Dg;
  }
  function Li(a, b) {
    for (var c in a) isNaN(c) || b(+c, a[c], !1);
    a = Ii(a);
    for (let d in a) (c = +d), isNaN(c) || b(c, a[c], !0);
  }
  function Gi(a, b, c) {
    a[b] = new Ki(c.B, c.A);
  }
  class Ki {
    constructor(a, b) {
      this.qe = a;
      this.Ke = b;
      this.isMap = !1;
    }
  }
  class Ji {
    constructor(a, b, c, d, e) {
      this.bf = a;
      this.qe = b;
      this.Ke = c;
      this.isMap = d;
      this.eh = e;
    }
  }
  function Hi(a, b, c, d) {
    var e = Ie(d[0]);
    e = e ? e === Ge : !1;
    a[b] = new Ji(d, c.B, e ? Yg : c.A, e ? Zg : !1, d);
  }
  function Mi(a, b) {
    var c;
    return () => {
      var d;
      if ((d = c) == null) {
        if (!(a?.prototype instanceof S)) throw Error();
        a[Fc] || (a[Fc] = he(a));
        new a();
        d = c = { [Di]: b, [Ei]: a };
      }
      return d;
    };
  }
  function Ni(a) {
    return (b) => {
      if (b == null || b == "") b = new a();
      else {
        b = JSON.parse(b);
        if (!Array.isArray(b)) throw Error("dnarr");
        Pc(b, 32);
        b = new a(b);
      }
      return b;
    };
  }
  function Oi(a, b) {
    R(a, 1, b);
  }
  function Pi(a, b) {
    Q(a, 2, b);
  }
  var Qi = class extends S {
    constructor(a) {
      super(a);
    }
    Oa() {
      return Ff(this, 1);
    }
    va() {
      return E(this, 2);
    }
  };
  var Ri = [0, Ai, ui];
  var Si = {};
  var Ti = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Ui = [
    -1,
    Si,
    function (a, b, c) {
      og();
      try {
        Array.isArray(a);
        let d = c.extensions;
        for (; lg(b) && b.B != 4; )
          if (b.D === 11) {
            let f = b.F,
              g = !1,
              h;
            sg(b, (k, l) => {
              h = k;
              k = c[h];
              if (k == null) {
                let m = d?.[h];
                if (m) {
                  let n = Rh(m),
                    q = Mh(Fh, Ph, Qh, m).mc;
                  k = c[h] = (r, t, v) => n(wf(t, q, v), r);
                }
              }
              k != null ? k(l, a, h) : ((g = !0), (l.A.A = l.A.C));
            });
            g && ze(a, h, pg(b, f));
          } else ze(a, b.C, qg(b));
        let e = ve(a);
        e && (e.A = c.bf[Jh]);
        return !0;
      } catch (d) {
        if (d instanceof RangeError) throw new SyntaxError();
        throw d;
      } finally {
        fg > 0 && fg--;
      }
    },
    function (a, b) {
      return (c, d, e) => {
        d = Bh(d, a);
        d != null &&
          (Rg(c, 1, 3),
          Rg(c, 2, 0),
          Og(c.A, e),
          (e = Sg(c, 3)),
          b(d, c),
          Tg(c, e),
          Rg(c, 1, 4));
      };
    },
  ];
  var Vi = [0, ri, -1, Ui];
  var Wi = [0, ni, si, -1];
  function Xi(a) {
    return D(a, 2);
  }
  function Yi(a, b) {
    return P(a, 2, b);
  }
  function Zi(a) {
    return D(a, 3);
  }
  function $i(a, b) {
    return P(a, 3, b);
  }
  function aj(a) {
    return D(a, 1);
  }
  function bj(a, b) {
    return P(a, 1, b);
  }
  function cj(a) {
    return Pf(a, 1);
  }
  var dj = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var ej = class extends S {
    constructor(a) {
      super(a);
    }
    Ba() {
      return D(this, 1);
    }
    nb(a) {
      return P(this, 1, a);
    }
    za() {
      return D(this, 2);
    }
    ab(a) {
      return P(this, 2, a);
    }
    Va() {
      return D(this, 3);
    }
    wc(a) {
      P(this, 3, a);
    }
  };
  function fj(a) {
    return Df(a, 1) != null;
  }
  var gj = class extends S {
    constructor(a) {
      super(a);
    }
    S() {
      return Ef(this, 1);
    }
    B(a) {
      return N(this, 1, a);
    }
    R() {
      return Ef(this, 2);
    }
    A(a) {
      return N(this, 2, a);
    }
  };
  function hj(a) {
    return B(a, dj, 1);
  }
  function ij(a) {
    return A(a, dj, 1);
  }
  function jj(a) {
    return B(a, ej, 2);
  }
  function kj(a) {
    return A(a, ej, 2);
  }
  function lj(a) {
    return z(a, 2);
  }
  function mj(a) {
    return B(a, gj, 3);
  }
  function nj(a) {
    return A(a, gj, 3);
  }
  function oj(a) {
    return z(a, 3);
  }
  var U = class extends S {
    constructor(a) {
      super(a);
    }
    Ga() {
      return D(this, 4);
    }
  };
  var pj = class extends S {
    constructor(a) {
      super(a);
    }
    getX() {
      return D(this, 1);
    }
    setX(a) {
      return P(this, 1, a);
    }
    getY() {
      return D(this, 2);
    }
    setY(a) {
      return P(this, 2, a);
    }
  };
  var qj = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var rj = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var sj = class extends S {
    constructor(a) {
      super(a);
    }
    wa() {
      return E(this, 1);
    }
    Dd() {
      return Rf(this, 1);
    }
  };
  var tj = class extends S {
    constructor(a) {
      super(a);
    }
    A() {
      return yf(this, Ti, 2);
    }
  };
  var uj = class extends S {
    constructor(a) {
      super(a);
    }
    xa() {
      return yf(this, rj, 2);
    }
  };
  function vj(a) {
    return B(a, sj, 1);
  }
  function wj(a) {
    return E(a, 2);
  }
  var xj = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var yj = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Bj = class extends S {
    constructor(a) {
      super(a);
    }
    R() {
      return Ef(this, 1);
    }
    A(a) {
      return N(this, 1, a);
    }
    S() {
      return Ef(this, 2);
    }
    B(a) {
      return N(this, 2, a);
    }
  };
  function Cj(a) {
    return D(a, 1);
  }
  var Dj = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function Ej(a) {
    return D(a, 3);
  }
  function Fj(a, b) {
    P(a, 3, b);
  }
  function Gj(a) {
    return D(a, 4);
  }
  function Hj(a, b) {
    P(a, 4, b);
  }
  var Ij = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Jj = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Kj = class extends S {
    constructor(a) {
      super(a);
    }
    Ba() {
      return D(this, 1);
    }
    nb(a) {
      return P(this, 1, a);
    }
    za() {
      return D(this, 2, 90);
    }
    ab(a) {
      return P(this, 2, a);
    }
    Va() {
      return D(this, 3);
    }
    wc(a) {
      P(this, 3, a);
    }
  };
  function Lj(a) {
    return B(a, Ij, 1);
  }
  function Mj(a) {
    return B(a, Kj, 3);
  }
  var Nj = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Oj = class extends S {
    constructor(a) {
      super(a);
    }
    Ga() {
      return D(this, 3);
    }
  };
  var Pj = [0, pi, -1];
  var Qj = [0, 2, li, -1, Ai];
  var Rj = class extends S {
    constructor(a) {
      super(a);
    }
    Oa() {
      return Ff(this, 1);
    }
  };
  function Sj(a) {
    return Bf(a, 1, Rj);
  }
  var Tj = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Uj = [0, xi, [0, Ai, ti, Ai, -2], ti, Pj, ti, -1];
  var Vj = [0, zi, mi, zi, ui, pi];
  var Wj = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function Xj(a) {
    return B(a, sj, 6);
  }
  function Yj(a) {
    return B(a, sj, 7);
  }
  var Zj = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var ak = [0, si, -1];
  function bk(a, b) {
    Q(a, 5, b);
  }
  var ck = class extends S {
    constructor(a) {
      super(a);
    }
    A() {
      return yf(this, Ti, 1);
    }
  };
  var dk = [
    0,
    Vi,
    ui,
    ai(
      function (a, b, c) {
        return ji(a, b, c);
      },
      function (a, b, c) {
        b = be(b);
        if (b != null && b != null)
          switch ((Rg(a, c, 0), typeof b)) {
            case "number":
              a = a.A;
              sd(b);
              Lg(a, od, pd);
              break;
            case "bigint":
              c = Kg(b, wg, vg);
              Lg(a.A, c.B, c.A);
              break;
            default:
              (c = xg(b)), Lg(a.A, c.B, c.A);
          }
      },
      nh
    ),
    [0, xi, ak, xi, Vi, -1, ak, ti, pi],
    ui,
    -1,
    Ai,
  ];
  var ek = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var fk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var gk = (function (a, b) {
      return (c, d) => {
        a: {
          let f = { Vf: !0 };
          d && Object.assign(f, d);
          c = gg(c, void 0, void 0, f);
          try {
            let g = new a(),
              h = g.da;
            Rh(b)(h, c);
            var e = g;
            break a;
          } catch (g) {
            if (g instanceof RangeError) throw new SyntaxError();
            throw g;
          } finally {
            kg(c);
          }
          e = void 0;
        }
        return e;
      };
    })(Qi, Ri),
    hk = (function (a) {
      return (b) => {
        var c = new Wg();
        Xh(b.da, c, Mh(Eh, Uh, Vh, a));
        Qg(c, c.A.end());
        b = new Uint8Array(c.B);
        var d = c.C,
          e = d.length,
          f = 0;
        for (let g = 0; g < e; g++) {
          let h = d[g];
          b.set(h, f);
          f += h.length;
        }
        c.C = [b];
        return b;
      };
    })(Ri);
  var ik = [0, si, -1];
  var jk = class extends S {
    constructor(a) {
      super(a);
    }
    A() {
      return yf(this, Ti, 1);
    }
  };
  var kk = [0, Vi, xi, ik, xi, Vi, -1, ik];
  var lk = Mi(jk, kk);
  var mk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var nk = [0, ui, -2];
  function ok(a) {
    return A(a, ck, 2);
  }
  var pk = class extends S {
    constructor(a) {
      super(a);
    }
    ha() {
      return B(this, Qi, 1);
    }
    jb() {
      return z(this, 1);
    }
  };
  var qk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var rk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function sk(a) {
    return Ff(a, 1);
  }
  var tk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var uk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var vk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var wk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function xk(a) {
    return A(a, Tj, 9);
  }
  var yk = class extends S {
    constructor(a) {
      super(a);
    }
    getComponent(a) {
      return Hf(this, 1, a);
    }
    setComponent(a, b) {
      return Af(this, 1, Kd, b, a, Ld, void 0, 1);
    }
    Hc() {
      return B(this, qk, 4);
    }
  };
  var zk = [0, xi, Pj, ti, xi, [0, Pj, ui, ti, -1]];
  var Ak = [
    0,
    Bi,
    xi,
    [0, Ai],
    Ai,
    [0, pi],
    xi,
    [0, Ai],
    xi,
    [0, Ai],
    1,
    xi,
    [0, Ai, -1],
    Uj,
    [0, Ai, -1, pi],
    zk,
  ];
  var Bk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Ck = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function Dk(a) {
    return A(a, Ck, 11);
  }
  var Ek = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Fk = class extends S {
    constructor(a) {
      super(a);
    }
    getContext() {
      return yf(this, Ek, 1);
    }
  };
  var Gk = [
    0,
    ui,
    Ai,
    ni,
    Ai,
    ui,
    [0, ti, pi, ti],
    Ai,
    [0, [0, 1, ti]],
    ui,
    [
      0,
      ti,
      -3,
      1,
      vi,
      ui,
      [0, [-500, si, -1, 12, Ui, 484, [0, 14, [0, [0, Ai, ui], ti]]], li],
      ti,
    ],
    [0, [0, ti, -1], [0, ti, -1], [0, ti, -1], [0, ti]],
    [0, 1, ti, -2, 2, Ai, 5, ti],
    Wi,
    2,
    [0, ti, zi],
    ni,
    ui,
    [0, ui, -5],
  ];
  var Hk = Mi(Fk, [0, Gk, nk, xi, [0, Ri, dk], Ak, ui]);
  function Ik(a) {
    return E(a, 1);
  }
  var Jk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function Kk(a) {
    return Ff(a, 1);
  }
  var Lk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Mk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function Nk(a) {
    return B(a, Mk, 1);
  }
  var Ok = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Pk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Qk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Rk = class extends S {
    constructor(a) {
      super(a);
    }
    setSize(a) {
      return zf(this, Bj, 1, a);
    }
  };
  var Sk = class extends S {
    constructor(a) {
      super(a);
    }
    getCursor() {
      return yf(this, Rk, 2);
    }
  };
  function Tk(a) {
    return B(a, Nj, 3);
  }
  var Uk = class extends S {
    constructor(a) {
      super(a);
    }
    ha() {
      return B(this, Qi, 1);
    }
    jb() {
      return z(this, 1);
    }
    Xa() {
      return yf(this, Oj, 2);
    }
    oa() {
      return B(this, Oj, 2);
    }
    ja() {
      return A(this, Oj, 2);
    }
    setCamera(a) {
      return zf(this, Oj, 2, a);
    }
  };
  function Vk(a, b) {
    return ff(a, 1, Uk, b);
  }
  var Wk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Xk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Yk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Zk = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function $k(a) {
    return B(a, Nj, 2);
  }
  var al = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var bl = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function cl(a) {
    return A(a, Bj, 1);
  }
  function dl(a) {
    return A(a, Bj, 2);
  }
  var el = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var fl = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function gl(a) {
    return B(a, Bj, 1);
  }
  var hl = class extends S {
    constructor(a) {
      super(a);
    }
    setSize(a) {
      return zf(this, Bj, 1, a);
    }
  };
  function il(a) {
    return df(a, hl, 1);
  }
  function jl(a) {
    return B(a, Bj, 2);
  }
  function kl(a) {
    return A(a, Bj, 2);
  }
  var ll = class extends S {
    constructor(a) {
      super(a);
    }
    jc() {
      return yf(this, Bj, 2);
    }
  };
  function ml(a) {
    return Ff(a, 2);
  }
  function nl(a) {
    return B(a, Bj, 3);
  }
  function ol(a) {
    return A(a, Bj, 3);
  }
  function pl(a) {
    return B(a, ll, 4);
  }
  function ql(a) {
    return A(a, ll, 4);
  }
  function rl(a) {
    return A(a, el, 5);
  }
  var sl = class extends S {
    constructor(a) {
      super(a);
    }
    Oa() {
      return Ff(this, 1);
    }
  };
  var tl = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function ul(a, b) {
    Q(a, 1, b);
  }
  var vl = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var wl = class extends S {
    constructor(a) {
      super(a);
    }
    A() {
      return E(this, 1);
    }
    setSize(a) {
      return zf(this, Bj, 2, a);
    }
  };
  function xl(a) {
    return B(a, Lk, 1);
  }
  function yl(a) {
    return A(a, Qi, 2);
  }
  function zl(a) {
    return B(a, sl, 3);
  }
  function Al(a) {
    return A(a, sl, 3);
  }
  function Bl(a) {
    return B(a, Zj, 4);
  }
  function Cl(a, b) {
    return ff(a, 6, al, b);
  }
  function Dl(a) {
    return df(a, al, 6);
  }
  function El(a) {
    return B(a, fk, 7);
  }
  function Fl(a) {
    return A(a, vl, 8);
  }
  function Gl(a) {
    return B(a, Jk, 22);
  }
  var Hl = class extends S {
    constructor(a) {
      super(a);
    }
    ha() {
      return B(this, Qi, 2);
    }
    jb() {
      return z(this, 2);
    }
    Hc() {
      return B(this, yj, 5);
    }
    Z(a) {
      Bf(this, 15, bl, a, 1);
    }
    A() {
      var a = this.da;
      return ef(this, a, a[x] | 0, wl, 18, void 0, void 0, !1, !0);
    }
  };
  var Il = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Jl = class extends S {
      constructor(a) {
        super(a);
      }
    },
    Kl = Ni(Jl);
  function Ll(a) {
    Of(a, 1, 2);
  }
  var Ml = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function Nl(a) {
    return A(a, Ml, 1);
  }
  var Ol = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function Pl(a) {
    R(a, 1, 2);
  }
  var Ql = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function Rl(a) {
    return A(a, Ol, 1);
  }
  function Sl(a) {
    return A(a, mk, 2);
  }
  function Tl(a) {
    return A(a, Tj, 11);
  }
  function Ul(a) {
    return A(a, Ql, 9);
  }
  var Vl = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Wl = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Xl = class extends S {
    constructor(a) {
      super(a);
    }
    getContext() {
      return yf(this, Ek, 1);
    }
    ha() {
      return B(this, Qi, 5);
    }
    jb() {
      return z(this, 5);
    }
  };
  var Yl = [0, 2, Ai, Bi, vi];
  var Zl = [0, li, -1];
  var $l = [
    0,
    [1, 2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18],
    yi,
    [0, [0, ui], Vi, [0, ui], oi, 2, [0, ui, -2]],
    yi,
    [0, 2, Qj, -1, Ai],
    yi,
    Yl,
    wi,
    -1,
    Ci,
    -1,
    yi,
    Zl,
    1,
    wi,
    -3,
    yi,
    Ri,
    Ci,
    wi,
    -2,
  ];
  var am = [0, Ai, xi, $l, xi, () => am, ui, -1];
  var bm = [
    0,
    [0, [0, Bi], ti, -1, 1, ti, -1, Yl, ti, -1, [0, vi, -1], Zl, ti, -2],
    nk,
    [
      0,
      [2, 5],
      1,
      yi,
      zk,
      1,
      [0, Ai, -1],
      ai(
        function (a, b, c, d) {
          if (a.B !== 0) return !1;
          vf(b, c, d, Xf(a.A));
          return !0;
        },
        fi,
        bh
      ),
      ti,
    ],
    [0, 1, ui, pi],
    3,
    Ui,
    [
      0,
      Ai,
      li,
      -2,
      [0, Ai],
      1,
      ui,
      [0, xi, [0, zi, pi], li, pi, li, ti, li, ti, li],
      ti,
      bi(
        ki,
        function (a, b, c) {
          b = $h(Nd, b);
          if (b != null && b.length) {
            c = Sg(a, c);
            for (let d = 0; d < b.length; d++) Og(a.A, b[d]);
            Tg(a, c);
          }
        },
        uh
      ),
    ],
    ti,
    Uj,
    [0, Ai, ti],
    [0, Bi],
    ti,
    Ai,
    ui,
    pi,
    Bi,
    1,
    [-3, {}, am, xi, [0, $l, ui, -1]],
    [
      0,
      vi,
      pi,
      1,
      vi,
      Vj,
      xi,
      [
        0,
        bi(
          function (a, b, c) {
            if (a.B !== 5 && a.B !== 2) return !1;
            b = qf(b, b[x] | 0, c);
            a.B == 2 ? ug(a, $f, b) : b.push($f(a.A));
            return !0;
          },
          function (a, b, c) {
            b = $h(Fd, b);
            if (b != null && b.length) {
              Rg(a, c, 2);
              Ng(a.A, b.length * 4);
              for (let d = 0; d < b.length; d++) (c = a.A), td(b[d]), Mg(c, od);
            }
          },
          rh
        ),
        Ai,
        ui,
        zi,
        Vj,
      ],
    ],
    [0, Bi],
    [0, Ai, pi, Ai],
    [0, Ai],
    [
      0,
      [
        0,
        ai(
          function (a, b, c) {
            a.B !== 0
              ? (b = !1)
              : ((a = Vf(a.A, xd)), ci(b, c, a === Zh ? void 0 : a), (b = !0));
            return b;
          },
          di,
          mh
        ),
        ai(
          function (a, b, c) {
            if (a.B !== 0) return !1;
            a = Yf(a.A);
            ci(b, c, a === 0 ? void 0 : a);
            return !0;
          },
          ei,
          dh
        ),
      ],
    ],
    ti,
  ];
  var Am = Mi(Xl, [
    0,
    Gk,
    [0, Qj, li, [0, oi, mi, [0, ui, -1], -1], xi, Vi, Qj, ui],
    bm,
    Ak,
    Ri,
    [0],
    kk,
    [0, xi, dk, bm, ui, 1, [0, xi, bm, ti, Ai]],
    ui,
  ]);
  var Bm = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Cm = class extends S {
      constructor(a) {
        super(a);
      }
      Nb() {
        return yf(this, Bm, 4);
      }
      Yd() {
        return z(this, 4);
      }
    },
    Dm = Ni(Cm);
  Si[13258261] = Vi;
  class Em {
    constructor() {
      var a = Fm;
      var b = b || [];
      this.B = a || null;
      this.A = [];
      this.A = this.A.concat(b);
    }
    toString() {
      return "MpJwZc";
    }
  }
  var Fm;
  Fm = "MpJwZc";
  new Em();
  function Gm(a, b, c) {
    for (let d in a) b.call(c, a[d], d, a);
  }
  function Hm(a) {
    var b = 0;
    for (let c in a) b++;
    return b;
  }
  function Im(a) {
    var b = [],
      c = 0;
    for (let d in a) b[c++] = d;
    return b;
  }
  function Jm(a) {
    for (let b in a) return !1;
    return !0;
  }
  function Km(a, b) {
    return a !== null && b in a ? a[b] : void 0;
  }
  var Lm =
    "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(
      " "
    );
  function Mm(a, b) {
    for (let e = 1; e < arguments.length; e++) {
      var c = arguments[e];
      for (d in c) a[d] = c[d];
      for (let f = 0; f < Lm.length; f++) {
        var d = Lm[f];
        Object.prototype.hasOwnProperty.call(c, d) && (a[d] = c[d]);
      }
    }
  }
  function Nm(a) {
    if (typeof a !== "function" && typeof a !== "object") throw Error(void 0);
  }
  sh.Ya = "d";
  rh.Ya = "f";
  dh.Ya = "i";
  mh.Ya = "j";
  eh.Ya = "u";
  nh.Ya = "v";
  bh.Ya = "b";
  uh.Ya = "e";
  ch.Ya = "s";
  th.Ya = "B";
  $g.Ya = "m";
  ah.Ya = "m";
  kh.Ya = "x";
  ph.Ya = "y";
  lh.Ya = "g";
  qh.Ya = "h";
  fh.Ya = "n";
  oh.Ya = "o";
  function Om(a, b) {
    if (b instanceof th) return String(a).replace(Pm, Qm).replace(Rm, "");
    switch (b) {
      case ch:
        return typeof a !== "string" ? void 0 : a;
      case bh:
        return (a = Number(a)), isNaN(a) ? void 0 : a ? 1 : 0;
      case sh:
      case rh:
        return (b = Number(a)), Number.isFinite(b) ? b : a;
      case dh:
      case eh:
      case kh:
      case lh:
      case fh:
      case uh:
        return (b = Number(a)), Number.isFinite(b) ? b : a;
      case mh:
      case nh:
      case ph:
      case qh:
      case oh:
        return isNaN(a) ? void 0 : "" + a;
      default:
        return a;
    }
  }
  function Sm(a) {
    return a.indexOf("*21") !== -1 ? a.replace(Tm, "!") : a;
  }
  function Um(a) {
    var b = a.charCodeAt(0).toString(16),
      c = new RegExp(`(\\*${b})`, "gi");
    b = `*${b}`;
    var d = b.toLowerCase();
    return (e) =>
      e.indexOf(b) !== -1 || e.indexOf(d) !== -1 ? e.replace(c, a) : e;
  }
  var Vm = RegExp("[+/]", "g");
  function Wm(a) {
    return a === "+" ? "-" : "_";
  }
  var Pm = RegExp("[-_]", "g");
  function Qm(a) {
    return a === "-" ? "+" : "/";
  }
  var Rm = RegExp("[.=]+$"),
    Xm = RegExp("(\\*)", "g"),
    Ym = RegExp("(!)", "g"),
    Zm = RegExp("(\\*2[Aa])", "g"),
    Tm = RegExp("(\\*21)", "gi"),
    $m = RegExp("^[-A-Za-z0-9_.!~*() ]*$");
  var an = !1,
    bn = RegExp("^([0-9]+)([a-zB])([\\s\\S]*)");
  function cn(a, b, c, d, e) {
    var f = (a[x] | 0) & 64 ? a : Je(a, b.mc),
      g = f[x] | 0;
    Li(b, (h, k) => {
      var l = $e(f, h, ed(g));
      if (l != null)
        if (k.isMap && l instanceof Map)
          l.forEach((m, n) => {
            e = dn(c, h, k, [n, m], d, e);
          });
        else if (k.Ke)
          for (let m = 0; m < l.length; ++m) e = dn(c, h, k, l[m], d, e);
        else e = dn(c, h, k, l, d, e);
    });
    return e;
  }
  function dn(a, b, c, d, e, f) {
    e[f++] = a === 0 ? "!" : "&";
    e[f++] = b;
    if (c.qe instanceof $g || c.qe instanceof ah)
      (b = en(d)),
        (d = c.Rf ?? (c.Rf = Mh(Ih, Gi, Hi, c.eh))),
        (e[f++] = "m"),
        (e[f++] = 0),
        (c = f),
        (f = cn(en(b), d, a, e, f)),
        (e[c - 1] = (f - c) >> 2);
    else {
      c = c.qe;
      b = c.Ya;
      if (c instanceof ch)
        if (a === 1) d = encodeURIComponent(String(d));
        else {
          a = typeof d === "string" ? d : `${d}`;
          $m.test(a)
            ? (d = !1)
            : ((d = encodeURIComponent(a).replace(/%20/g, "+")),
              (c = d.match(/%[89AB]/gi)),
              (c = a.length + (c ? c.length : 0)),
              (d = 4 * Math.ceil(c / 3) - ((3 - (c % 3)) % 3) < d.length));
          d && (b = "z");
          if (b === "z") {
            d = [];
            c = 0;
            for (let g = 0; g < a.length; g++) {
              let h = a.charCodeAt(g);
              h < 128
                ? (d[c++] = h)
                : (h < 2048
                    ? (d[c++] = (h >> 6) | 192)
                    : ((h & 64512) == 55296 &&
                      g + 1 < a.length &&
                      (a.charCodeAt(g + 1) & 64512) == 56320
                        ? ((h =
                            65536 +
                            ((h & 1023) << 10) +
                            (a.charCodeAt(++g) & 1023)),
                          (d[c++] = (h >> 18) | 240),
                          (d[c++] = ((h >> 12) & 63) | 128))
                        : (d[c++] = (h >> 12) | 224),
                      (d[c++] = ((h >> 6) & 63) | 128)),
                  (d[c++] = (h & 63) | 128));
            }
            a = dc(d, 4);
          } else
            a.indexOf("*") !== -1 && (a = a.replace(Xm, "*2A")),
              a.indexOf("!") !== -1 && (a = a.replace(Ym, "*21"));
          d = a;
        }
      else {
        a = d;
        if (!(c instanceof sh || c instanceof rh))
          if (c instanceof bh) a = a ? 1 : 0;
          else if (c instanceof ch) a = String(a);
          else if (c instanceof th) {
            a instanceof tc ||
              a == null ||
              a instanceof tc ||
              (a = typeof a === "string" ? (a ? new tc(a, qc) : rc()) : void 0);
            if (a == null) throw Error();
            a = uc(a).replace(Vm, Wm).replace(Rm, "");
          } else if (c instanceof eh || c instanceof kh) a = Od(a);
          else if (
            c instanceof dh ||
            c instanceof lh ||
            c instanceof fh ||
            c instanceof uh
          )
            a = Nd(a);
          else if (c instanceof mh || c instanceof oh || c instanceof qh)
            (d = typeof a),
              (a =
                a == null
                  ? a
                  : d === "bigint"
                  ? String(Ad(64, a))
                  : Jd(a)
                  ? d === "string"
                    ? Vd(a)
                    : Sd(a)
                  : void 0);
          else if (c instanceof nh || c instanceof ph)
            (d = typeof a),
              (a =
                a == null
                  ? a
                  : d === "bigint"
                  ? String(Bd(64, a))
                  : Jd(a)
                  ? d === "string"
                    ? Wd(a)
                    : Td(a)
                  : void 0);
        d = a;
      }
      e[f++] = b;
      e[f++] = d;
    }
    return f;
  }
  function fn(a, b, c, d, e, f) {
    d = c + d;
    if (d > e.length) return !1;
    for (var g = Ii(a); c < d; ++c) {
      var h = e[c];
      if (h === "") continue;
      var k = bn.exec(h);
      if (!k) return !1;
      h = parseInt(k[1], 10);
      var l = k[2],
        m = k[3];
      m = f(m);
      if (m.indexOf("*2A") !== -1 || m.indexOf("*2a") !== -1)
        m = m.replace(Zm, "*");
      var n = 0;
      if (l === "m" && ((n = parseInt(m, 10)), isNaN(n) || n < 0)) return !1;
      var q = a[h];
      q || (q = g[h]);
      if (!q) {
        an && Bc();
        l === "m" && (c += n);
        continue;
      }
      k = k[2];
      if (k === "z") {
        k = "s";
        m = fc(m);
        var r = [];
        let H = 0,
          I = 0;
        for (; H < m.length; ) {
          var t = m[H++];
          if (t < 128) r[I++] = String.fromCharCode(t);
          else if (t > 191 && t < 224) {
            var v = m[H++];
            r[I++] = String.fromCharCode(((t & 31) << 6) | (v & 63));
          } else if (t > 239 && t < 365) {
            v = m[H++];
            var F = m[H++];
            let J = m[H++];
            t =
              (((t & 7) << 18) |
                ((v & 63) << 12) |
                ((F & 63) << 6) |
                (J & 63)) -
              65536;
            r[I++] = String.fromCharCode(55296 + (t >> 10));
            r[I++] = String.fromCharCode(56320 + (t & 1023));
          } else
            (v = m[H++]),
              (F = m[H++]),
              (r[I++] = String.fromCharCode(
                ((t & 15) << 12) | ((v & 63) << 6) | (F & 63)
              ));
        }
        m = r.join("");
      }
      r = q.qe;
      if (r.Ya !== k) return !1;
      if (l === "m") {
        l = q.Rf ?? (q.Rf = Mh(Ih, Gi, Hi, q.eh));
        q.Ke
          ? ((m = Je(void 0, l.mc)),
            (q = b),
            (k = m),
            qf(q, q[x] | 0, h).push(k))
          : (m = wf(b, l.mc, h));
        if (!fn(l, m, c + 1, n, e, f)) return !1;
        c += n;
        continue;
      }
      n = Om(m, r);
      q.Ke
        ? qf(b, b[x] | 0, h).push(n)
        : ((q = b[x] | 0), cf(b, q, h, n, ed(q)));
    }
    return !0;
  }
  function gn(a) {
    try {
      return (an = !1), a();
    } finally {
      an = !1;
    }
  }
  function en(a) {
    if (a instanceof S) return a.da;
    if (a instanceof Map) return [...a];
    if (Array.isArray(a)) return a;
    throw Error();
  }
  var hn = RegExp(
      "^((http(s)?):)?\\/\\/((((lh[3-6](-tt|-d[a-g,y,z]|-testonly)?\\.((ggpht)|(googleusercontent)|(google)|(sandbox\\.google)))|(lh7\\-(eu|us|qw|rt|xx|ty)\\.((googleusercontent)|(google)))|((photos|testonly|work)\\.fife\\.usercontent\\.google)|([\\w\\-]+\\.fife\\.usercontent\\.google)|(([1-4]\\.bp\\.blogspot)|(bp[0-3]\\.blogger))|(ccp-lh\\.googleusercontent)|((((cp|ci|gp)[3-6])|(ap[1-2]))\\.(ggpht|googleusercontent))|(gm[1-4]\\.ggpht)|(play-(ti-)?lh\\.googleusercontent)|(gz[0-1]\\.googleusercontent)|(lh3\\-gm\\.google)|(((yt[3-4])|(sp[1-3]))\\.(ggpht|googleusercontent)))\\.com)|(drive\\.google\\.com\\/drive\\-(usercontent|viewer))|(dp[3-6]\\.googleusercontent\\.cn)|(lh[3-6]\\.(googleadsserving\\.cn|xn--9kr7l\\.com))|((photos|drive|contribution)\\-image\\-(dev|qa)(-us|-eu)?(-auth|-cookie)?\\.corp\\.google\\.com)|(photos\\-image\\-dev\\-dl\\-(auth|eu|us)\\.corp\\.google\\.com)|((dev|dev2|dev3|qa|qa2|qa3|qa-red|qa-blue|canary)[-.]lighthouse\\.sandbox\\.google\\.com\\/image)|(image\\-(dev|qa)\\-lighthouse(-auth)?\\.sandbox\\.google\\.com(\\/image)?)|(drive\\-qa\\.corp\\.google\\.com\\/drive\\-(usercontent|viewer))|(docs(\\-(dev|qa)\\.corp)?\\.google\\.com\\/(u\\/[0-9]+\\/)?(docs|sheets|slides|drawings|forms|videos|pictures|brands|email\\-layouts)\\-images\\-(rt|qw|xx|ty))|(docs\\.sandbox\\.google\\.com\\/(u\\/[0-9]+\\/)?(docs|sheets|slides|drawings|forms|videos|pictures|brands)\\-images)|(sites\\.google\\.com\\/(u\\/[0-9]+\\/)?sites(v)?\\-images\\-(rt|qw))|(atari-green-test\\.corp\\.google\\.com\\/(u\\/[0-9]+\\/)?sites(v)?\\-images\\-(rt|qw))|(sites\\.sandbox\\.google\\.com\\/(u\\/[0-9]+\\/)?sites(v)?\\-images))\\/",
      "i"
    ),
    jn = /^(https?:)?\/\/sp[1-4]\.((ggpht)|(googleusercontent))\.com\//i,
    kn =
      /^(https?:)?\/\/(qa(-red|-blue)?|dev2?|image-dev)(-|\.)lighthouse(-auth)?\.sandbox\.google\.com\//i,
    ln =
      /^(https?:)?\/\/lighthouse-(qa(-red|-blue)?|dev2)\.corp\.google\.com\//i;
  function mn(a) {
    return hn.test(a) || jn.test(a) || kn.test(a) || ln.test(a);
  }
  var nn = class extends S {
    constructor(a) {
      super(a);
    }
    setSize(a) {
      return N(this, 1, a);
    }
    S() {
      return K(this, 12);
    }
    B(a) {
      return N(this, 12, a);
    }
    R() {
      return K(this, 13);
    }
    A(a) {
      return N(this, 13, a);
    }
  };
  function on(a) {
    var b = na("window.location.href");
    a == null && (a = 'Unknown Error of type "null/undefined"');
    if (typeof a === "string")
      return {
        message: a,
        name: "Unknown error",
        lineNumber: "Not available",
        fileName: b,
        stack: "Not available",
      };
    var c = !1;
    try {
      var d = a.lineNumber || a.line || "Not available";
    } catch (f) {
      (d = "Not available"), (c = !0);
    }
    try {
      var e = a.fileName || a.filename || a.sourceURL || u.$googDebugFname || b;
    } catch (f) {
      (e = "Not available"), (c = !0);
    }
    b = pn(a);
    return !c && a.lineNumber && a.fileName && a.stack && a.message && a.name
      ? {
          message: a.message,
          name: a.name,
          lineNumber: a.lineNumber,
          fileName: a.fileName,
          stack: b,
        }
      : ((c = a.message),
        c == null &&
          ((c =
            a.constructor && a.constructor instanceof Function
              ? 'Unknown Error of type "' +
                (a.constructor.name ? a.constructor.name : qn(a.constructor)) +
                '"'
              : "Unknown Error of unknown type"),
          typeof a.toString === "function" &&
            Object.prototype.toString !== a.toString &&
            (c += ": " + a.toString())),
        {
          message: c,
          name: a.name || "UnknownError",
          lineNumber: d,
          fileName: e,
          stack: b || "Not available",
        });
  }
  function pn(a, b) {
    b || (b = {});
    b[rn(a)] = !0;
    var c = a.stack || "",
      d = a.cause;
    d &&
      !b[rn(d)] &&
      ((c += "\nCaused by: "),
      (d.stack && d.stack.indexOf(d.toString()) == 0) ||
        (c += typeof d === "string" ? d : d.message + "\n"),
      (c += pn(d, b)));
    a = a.errors;
    if (Array.isArray(a)) {
      d = 1;
      let e;
      for (e = 0; e < a.length && !(d > 4); e++)
        b[rn(a[e])] ||
          ((c += "\nInner error " + d++ + ": "),
          (a[e].stack && a[e].stack.indexOf(a[e].toString()) == 0) ||
            (c += typeof a[e] === "string" ? a[e] : a[e].message + "\n"),
          (c += pn(a[e], b)));
      e < a.length && (c += "\n... " + (a.length - e) + " more inner errors");
    }
    return c;
  }
  function rn(a) {
    var b = "";
    typeof a.toString === "function" && (b = "" + a);
    return b + a.stack;
  }
  function sn(a) {
    var b = Error();
    if (Error.captureStackTrace)
      Error.captureStackTrace(b, a || sn), (b = String(b.stack));
    else {
      try {
        throw b;
      } catch (c) {
        b = c;
      }
      b = (b = b.stack) ? String(b) : null;
    }
    b || (b = tn(a || arguments.callee.caller, []));
    return b;
  }
  function tn(a, b) {
    var c = [];
    if (qb(b, a) >= 0) c.push("[...circular reference...]");
    else if (a && b.length < 50) {
      c.push(qn(a) + "(");
      let e = a.arguments;
      for (let f = 0; e && f < e.length; f++) {
        f > 0 && c.push(", ");
        var d = void 0;
        d = e[f];
        switch (typeof d) {
          case "object":
            d = d ? "object" : "null";
            break;
          case "string":
            break;
          case "number":
            d = String(d);
            break;
          case "boolean":
            d = d ? "true" : "false";
            break;
          case "function":
            d = (d = qn(d)) ? d : "[fn]";
            break;
          default:
            d = typeof d;
        }
        d.length > 40 && (d = d.slice(0, 40) + "...");
        c.push(d);
      }
      b.push(a);
      c.push(")\n");
      try {
        c.push(tn(a.caller, b));
      } catch (f) {
        c.push("[exception trying to get caller]\n");
      }
    } else a ? c.push("[...long stack...]") : c.push("[end]");
    return c.join("");
  }
  function qn(a) {
    if (un[a]) return un[a];
    a = String(a);
    if (!un[a]) {
      let b = /function\s+([^\(]+)/m.exec(a);
      un[a] = b ? b[1] : "[Anonymous]";
    }
    return un[a];
  }
  var un = {}; /*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
  var vn = globalThis.trustedTypes,
    wn;
  function xn() {
    var a = null;
    if (!vn) return a;
    try {
      let b = (c) => c;
      a = vn.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (b) {}
    return a;
  }
  function yn() {
    wn === void 0 && (wn = xn());
    return wn;
  }
  var zn = class {
    constructor(a) {
      this.A = a;
    }
    toString() {
      return this.A + "";
    }
  };
  function An(a) {
    var b = yn();
    a = b ? b.createScriptURL(a) : a;
    return new zn(a);
  }
  function Bn(a) {
    if (a instanceof zn) return a.A;
    throw Error("");
  }
  function Cn(a) {
    return a.toString().indexOf("`") === -1;
  }
  Cn((a) => a``) ||
    Cn((a) => a`\0`) ||
    Cn((a) => a`\n`) ||
    Cn((a) => a`\u0000`);
  var Dn = class {
      constructor(a) {
        this.A = a;
      }
      toString() {
        return this.A;
      }
    },
    En = new Dn("about:invalid#zClosurez");
  function Fn(a) {
    if (a instanceof Dn) return a.A;
    throw Error("");
  }
  class Gn {
    constructor(a) {
      this.Eb = a;
    }
  }
  function Hn(a) {
    return new Gn((b) => b.substr(0, a.length + 1).toLowerCase() === a + ":");
  }
  var In = [
    Hn("data"),
    Hn("http"),
    Hn("https"),
    Hn("mailto"),
    Hn("ftp"),
    new Gn((a) => /^[^:]*([/?#]|$)/.test(a)),
  ];
  function Jn(a, b = In) {
    if (a instanceof Dn) return a;
    for (let c = 0; c < b.length; ++c) {
      let d = b[c];
      if (d instanceof Gn && d.Eb(a)) return new Dn(a);
    }
  }
  var Kn = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  var Ln = class {
    constructor(a) {
      this.A = a;
    }
    toString() {
      return this.A + "";
    }
  };
  function Mn(a) {
    var b = yn();
    a = b ? b.createHTML(a) : a;
    return new Ln(a);
  }
  function Nn(a) {
    if (a instanceof Ln) return a.A;
    throw Error("");
  }
  function On(a, b = document) {
    a = b.querySelector?.(`${a}[nonce]`);
    return a == null ? "" : a.nonce || a.getAttribute("nonce") || "";
  }
  function Pn(a, b) {
    a.src = Bn(b);
    (b = On("script", a.ownerDocument)) && a.setAttribute("nonce", b);
  }
  function Qn(a, b) {
    if (a.nodeType === 1 && /^(script|style)$/i.test(a.tagName))
      throw Error("");
    a.innerHTML = Nn(b);
  }
  var Rn = class {
    constructor(a) {
      this.A = a;
    }
    toString() {
      return this.A;
    }
  };
  function Sn(a) {
    if (a instanceof Rn) return a.A;
    throw Error("");
  }
  function Tn(a) {
    return decodeURIComponent(a.replace(/\+/g, " "));
  }
  function Un(a, b) {
    if (!Number.isFinite(a)) return String(a);
    a = String(a);
    var c = a.indexOf(".");
    c === -1 && (c = a.length);
    var d = a[0] === "-" ? "-" : "";
    d && (a = a.substring(1));
    return d + "0".repeat(Math.max(0, b - c)) + a;
  }
  function Vn() {
    return "background-color".replace(/\-([a-z])/g, function (a, b) {
      return b.toUpperCase();
    });
  }
  function Wn(a) {
    return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function (b, c, d) {
      return c + d.toUpperCase();
    });
  }
  function Xn(a, b) {
    var c = Array.prototype.slice.call(arguments),
      d = c.shift();
    if (typeof d == "undefined")
      throw Error("[goog.string.format] Template required");
    d.replace(
      /%([0\- \+]*)(\d+)?(\.(\d+))?([%sfdiu])/g,
      function (e, f, g, h, k, l, m, n) {
        if (l == "%") return "%";
        var q = c.shift();
        if (typeof q == "undefined")
          throw Error("[goog.string.format] Not enough arguments");
        arguments[0] = q;
        return Yn[l].apply(null, arguments);
      }
    );
  }
  var Yn = {
    s: function (a, b, c) {
      return isNaN(c) || c == "" || a.length >= Number(c)
        ? a
        : (a =
            b.indexOf("-", 0) > -1
              ? a + " ".repeat(Number(c) - a.length)
              : " ".repeat(Number(c) - a.length) + a);
    },
    f: function (a, b, c, d, e) {
      d = a.toString();
      isNaN(e) || e == "" || (d = parseFloat(a).toFixed(e));
      var f =
        Number(a) < 0
          ? "-"
          : b.indexOf("+") >= 0
          ? "+"
          : b.indexOf(" ") >= 0
          ? " "
          : "";
      Number(a) >= 0 && (d = f + d);
      if (isNaN(c) || d.length >= Number(c)) return d;
      d = isNaN(e)
        ? Math.abs(Number(a)).toString()
        : Math.abs(Number(a)).toFixed(e);
      a = Number(c) - d.length - f.length;
      b.indexOf("-", 0) >= 0
        ? (d = f + d + " ".repeat(a))
        : ((b = b.indexOf("0", 0) >= 0 ? "0" : " "), (d = f + b.repeat(a) + d));
      return d;
    },
    d: function (a, b, c, d, e, f, g, h) {
      return Yn.f(parseInt(a, 10), b, c, d, 0, f, g, h);
    },
  };
  Yn.i = Yn.d;
  Yn.u = Yn.d;
  function Zn(a) {
    if (a.kc && typeof a.kc == "function") return a.kc();
    if (
      (typeof Map !== "undefined" && a instanceof Map) ||
      (typeof Set !== "undefined" && a instanceof Set)
    )
      return Array.from(a.values());
    if (typeof a === "string") return a.split("");
    if (pa(a)) {
      var b = [],
        c = a.length;
      for (var d = 0; d < c; d++) b.push(a[d]);
      return b;
    }
    b = [];
    c = 0;
    for (d in a) b[c++] = a[d];
    return b;
  }
  function $n(a) {
    if (a.Ee && typeof a.Ee == "function") return a.Ee();
    if (!a.kc || typeof a.kc != "function") {
      if (typeof Map !== "undefined" && a instanceof Map)
        return Array.from(a.keys());
      if (!(typeof Set !== "undefined" && a instanceof Set)) {
        if (pa(a) || typeof a === "string") {
          let b = [];
          a = a.length;
          for (let c = 0; c < a; c++) b.push(c);
          return b;
        }
        return Im(a);
      }
    }
  }
  function ao(a, b, c) {
    if (a.forEach && typeof a.forEach == "function") a.forEach(b, c);
    else if (pa(a) || typeof a === "string")
      Array.prototype.forEach.call(a, b, c);
    else {
      let d = $n(a),
        e = Zn(a),
        f = e.length;
      for (let g = 0; g < f; g++) b.call(c, e[g], d && d[g], a);
    }
  }
  function bo(a) {
    this.A = void 0;
    this.kb = {};
    if (a) {
      let b = $n(a);
      a = Zn(a);
      for (let c = 0; c < b.length; c++) this.set(b[c], a[c]);
    }
  }
  p = bo.prototype;
  p.set = function (a, b) {
    co(this, a, b, !1);
  };
  p.add = function (a, b) {
    co(this, a, b, !0);
  };
  function co(a, b, c, d) {
    for (let e = 0; e < b.length; e++) {
      let f = b.charAt(e);
      a.kb[f] || (a.kb[f] = new bo());
      a = a.kb[f];
    }
    if (d && a.A !== void 0)
      throw Error('The collection already contains the key "' + b + '"');
    a.A = c;
  }
  function eo(a, b) {
    for (let c = 0; c < b.length; c++)
      if (((a = a.kb[b.charAt(c)]), !a)) return;
    return a;
  }
  p.get = function (a) {
    return (a = eo(this, a)) ? a.A : void 0;
  };
  p.kc = function () {
    var a = [];
    fo(this, a);
    return a;
  };
  function fo(a, b) {
    a.A !== void 0 && b.push(a.A);
    for (let c in a.kb) fo(a.kb[c], b);
  }
  p.Ee = function (a) {
    var b = [];
    if (a) {
      let c = this;
      for (let d = 0; d < a.length; d++) {
        let e = a.charAt(d);
        if (!c.kb[e]) return [];
        c = c.kb[e];
      }
      go(c, a, b);
    } else go(this, "", b);
    return b;
  };
  function go(a, b, c) {
    a.A !== void 0 && c.push(b);
    for (let d in a.kb) go(a.kb[d], b + d, c);
  }
  p.clear = function () {
    this.kb = {};
    this.A = void 0;
  };
  p.remove = function (a) {
    var b = this,
      c = [];
    for (var d = 0; d < a.length; d++) {
      let e = a.charAt(d);
      if (!b.kb[e])
        throw Error('The collection does not have the key "' + a + '"');
      c.push([b, e]);
      b = b.kb[e];
    }
    a = b.A;
    for (delete b.A; c.length > 0; )
      if (((d = c.pop()), (b = d[0]), (d = d[1]), b.kb[d].isEmpty()))
        delete b.kb[d];
      else break;
    return a;
  };
  p.clone = function () {
    return new bo(this);
  };
  p.isEmpty = function () {
    return this.A === void 0 && Jm(this.kb);
  };
  function ho() {
    if (!io) {
      var a = (io = new bo()),
        b;
      for (b in jo) a.add(b, jo[b]);
    }
  }
  var io;
  function V(a, b) {
    this.types = a;
    this.A = b;
  }
  var jo = {
    a: new V(
      [3, 0],
      [
        function (a, b) {
          M(a, 21, b);
        },
        function (a, b) {
          N(a, 56, b);
        },
      ]
    ),
    al: new V(
      [3],
      [
        function (a, b) {
          M(a, 74, b);
        },
      ]
    ),
    b: new V(
      [3, 0],
      [
        function (a, b) {
          M(a, 23, b);
        },
        function (a, b) {
          N(a, 38, b);
        },
      ]
    ),
    ba: new V(
      [0],
      [
        function (a, b) {
          N(a, 85, b);
        },
      ]
    ),
    bc: new V(
      [0],
      [
        function (a, b) {
          N(a, 87, b);
        },
      ]
    ),
    br: new V(
      [0],
      [
        function (a, b) {
          N(a, 86, b);
        },
      ]
    ),
    c: new V(
      [3, 0],
      [
        function (a, b) {
          M(a, 2, b);
        },
        function (a, b) {
          N(a, 39, b);
        },
      ]
    ),
    cc: new V(
      [3],
      [
        function (a, b) {
          M(a, 51, b);
        },
      ]
    ),
    ci: new V(
      [3],
      [
        function (a, b) {
          M(a, 32, b);
        },
      ]
    ),
    ckm: new V(
      [3],
      [
        function (a, b) {
          M(a, 104, b);
        },
      ]
    ),
    cp: new V(
      [0],
      [
        function (a, b) {
          N(a, 92, b);
        },
      ]
    ),
    cr: new V(
      [3],
      [
        function (a, b) {
          M(a, 108, b);
        },
      ]
    ),
    cv: new V(
      [0],
      [
        function (a, b) {
          N(a, 94, b);
        },
      ]
    ),
    d: new V(
      [3],
      [
        function (a, b) {
          M(a, 3, b);
        },
      ]
    ),
    dc: new V(
      [5],
      [
        function (a, b) {
          Q(a, 99, b);
        },
      ]
    ),
    df: new V(
      [3],
      [
        function (a, b) {
          M(a, 80, b);
        },
      ]
    ),
    dv: new V(
      [3],
      [
        function (a, b) {
          M(a, 90, b);
        },
      ]
    ),
    e: new V(
      [0],
      [
        function (a, b) {
          N(a, 15, b);
        },
      ]
    ),
    em: new V(
      [0],
      [
        function (a, b) {
          N(a, 107, b);
        },
      ]
    ),
    f: new V(
      [4],
      [
        function (a, b) {
          Q(a, 16, b);
        },
      ]
    ),
    fg: new V(
      [3],
      [
        function (a, b) {
          M(a, 34, b);
        },
      ]
    ),
    fh: new V(
      [3],
      [
        function (a, b) {
          M(a, 30, b);
        },
      ]
    ),
    fm: new V(
      [3],
      [
        function (a, b) {
          M(a, 84, b);
        },
      ]
    ),
    fo: new V(
      [2],
      [
        function (a, b) {
          P(a, 79, b);
        },
      ]
    ),
    ft: new V(
      [3],
      [
        function (a, b) {
          M(a, 50, b);
        },
      ]
    ),
    fv: new V(
      [3],
      [
        function (a, b) {
          M(a, 31, b);
        },
      ]
    ),
    g: new V(
      [3],
      [
        function (a, b) {
          M(a, 14, b);
        },
      ]
    ),
    gce: new V(
      [4],
      [
        function (a, b) {
          Q(a, 112, b);
        },
      ]
    ),
    gd: new V(
      [3],
      [
        function (a, b) {
          M(a, 83, b);
        },
      ]
    ),
    gm: new V(
      [3],
      [
        function (a, b) {
          M(a, 105, b);
        },
      ]
    ),
    h: new V(
      [3, 0],
      [
        function (a, b) {
          M(a, 4, b);
        },
        function (a, b) {
          a.A(b);
        },
      ]
    ),
    i: new V(
      [3],
      [
        function (a, b) {
          M(a, 22, b);
        },
      ]
    ),
    ic: new V(
      [0],
      [
        function (a, b) {
          N(a, 71, b);
        },
      ]
    ),
    id: new V(
      [3],
      [
        function (a, b) {
          M(a, 70, b);
        },
      ]
    ),
    il: new V(
      [3],
      [
        function (a, b) {
          M(a, 96, b);
        },
      ]
    ),
    ip: new V(
      [3],
      [
        function (a, b) {
          M(a, 54, b);
        },
      ]
    ),
    iv: new V(
      [0],
      [
        function (a, b) {
          Nf(a, 75, b);
        },
      ]
    ),
    j: new V(
      [1],
      [
        function (a, b) {
          bf(a, 29, b == null ? b : Zd(b));
        },
      ]
    ),
    k: new V(
      [3, 0],
      [
        function (a, b) {
          M(a, 17, b);
        },
        function (a, b) {
          N(a, 42, b);
        },
      ]
    ),
    l: new V(
      [0],
      [
        function (a, b) {
          N(a, 44, b);
        },
      ]
    ),
    lf: new V(
      [3],
      [
        function (a, b) {
          M(a, 65, b);
        },
      ]
    ),
    lo: new V(
      [3],
      [
        function (a, b) {
          M(a, 97, b);
        },
      ]
    ),
    lp: new V(
      [4],
      [
        function (a, b) {
          Q(a, 116, b);
        },
      ]
    ),
    m: new V(
      [0],
      [
        function (a, b) {
          N(a, 63, b);
        },
      ]
    ),
    md: new V(
      [3],
      [
        function (a, b) {
          M(a, 91, b);
        },
      ]
    ),
    mm: new V(
      [4],
      [
        function (a, b) {
          Q(a, 81, b);
        },
      ]
    ),
    mo: new V(
      [3],
      [
        function (a, b) {
          M(a, 73, b);
        },
      ]
    ),
    mp: new V(
      [0],
      [
        function (a, b) {
          N(a, 115, b);
        },
      ]
    ),
    mv: new V(
      [3],
      [
        function (a, b) {
          M(a, 66, b);
        },
      ]
    ),
    n: new V(
      [3],
      [
        function (a, b) {
          M(a, 20, b);
        },
      ]
    ),
    nc: new V(
      [3],
      [
        function (a, b) {
          M(a, 55, b);
        },
      ]
    ),
    nd: new V(
      [3],
      [
        function (a, b) {
          M(a, 53, b);
        },
      ]
    ),
    ng: new V(
      [3],
      [
        function (a, b) {
          M(a, 95, b);
        },
      ]
    ),
    ngm: new V(
      [3],
      [
        function (a, b) {
          M(a, 106, b);
        },
      ]
    ),
    no: new V(
      [3],
      [
        function (a, b) {
          M(a, 37, b);
        },
      ]
    ),
    ns: new V(
      [3],
      [
        function (a, b) {
          M(a, 40, b);
        },
      ]
    ),
    nt0: new V(
      [4],
      [
        function (a, b) {
          Q(a, 36, b);
        },
      ]
    ),
    ntm: new V(
      [3],
      [
        function (a, b) {
          M(a, 114, b);
        },
      ]
    ),
    nu: new V(
      [3],
      [
        function (a, b) {
          M(a, 46, b);
        },
      ]
    ),
    nw: new V(
      [3],
      [
        function (a, b) {
          M(a, 48, b);
        },
      ]
    ),
    o: new V(
      [1, 3],
      [
        function (a, b) {
          bf(a, 7, b == null ? b : Zd(b));
        },
        function (a, b) {
          M(a, 27, b);
        },
      ]
    ),
    p: new V(
      [3, 0],
      [
        function (a, b) {
          M(a, 19, b);
        },
        function (a, b) {
          N(a, 43, b);
        },
      ]
    ),
    pa: new V(
      [3],
      [
        function (a, b) {
          M(a, 61, b);
        },
      ]
    ),
    pc: new V(
      [0],
      [
        function (a, b) {
          N(a, 88, b);
        },
      ]
    ),
    pd: new V(
      [3],
      [
        function (a, b) {
          M(a, 60, b);
        },
      ]
    ),
    pf: new V(
      [3],
      [
        function (a, b) {
          M(a, 67, b);
        },
      ]
    ),
    pg: new V(
      [3],
      [
        function (a, b) {
          M(a, 72, b);
        },
      ]
    ),
    pi: new V(
      [2],
      [
        function (a, b) {
          P(a, 76, b);
        },
      ]
    ),
    pp: new V(
      [3],
      [
        function (a, b) {
          M(a, 52, b);
        },
      ]
    ),
    pt: new V(
      [4],
      [
        function (a, b) {
          Q(a, 111, b);
        },
      ]
    ),
    q: new V(
      [4],
      [
        function (a, b) {
          Q(a, 28, b);
        },
      ]
    ),
    r: new V(
      [3, 0],
      [
        function (a, b) {
          M(a, 6, b);
        },
        function (a, b) {
          N(a, 26, b);
        },
      ]
    ),
    ra: new V(
      [3],
      [
        function (a, b) {
          M(a, 103, b);
        },
      ]
    ),
    rf: new V(
      [3],
      [
        function (a, b) {
          M(a, 100, b);
        },
      ]
    ),
    rg: new V(
      [3],
      [
        function (a, b) {
          M(a, 59, b);
        },
      ]
    ),
    rh: new V(
      [3],
      [
        function (a, b) {
          M(a, 49, b);
        },
      ]
    ),
    rj: new V(
      [3],
      [
        function (a, b) {
          M(a, 57, b);
        },
      ]
    ),
    ro: new V(
      [2],
      [
        function (a, b) {
          P(a, 78, b);
        },
      ]
    ),
    rp: new V(
      [3],
      [
        function (a, b) {
          M(a, 58, b);
        },
      ]
    ),
    rw: new V(
      [3],
      [
        function (a, b) {
          M(a, 35, b);
        },
      ]
    ),
    rwa: new V(
      [3],
      [
        function (a, b) {
          M(a, 64, b);
        },
      ]
    ),
    rwu: new V(
      [3],
      [
        function (a, b) {
          M(a, 41, b);
        },
      ]
    ),
    s: new V(
      [3, 0],
      [
        function (a, b) {
          M(a, 33, b);
        },
        function (a, b) {
          a.setSize(b);
        },
      ]
    ),
    sb: new V(
      [0],
      [
        function (a, b) {
          N(a, 110, b);
        },
      ]
    ),
    sc: new V(
      [0],
      [
        function (a, b) {
          N(a, 89, b);
        },
      ]
    ),
    sg: new V(
      [3],
      [
        function (a, b) {
          M(a, 82, b);
        },
      ]
    ),
    sl: new V(
      [0],
      [
        function (a, b) {
          N(a, 109, b);
        },
      ]
    ),
    sm: new V(
      [3],
      [
        function (a, b) {
          M(a, 93, b);
        },
      ]
    ),
    t: new V(
      [4],
      [
        function (a, b) {
          Q(a, 24, b);
        },
      ]
    ),
    tm: new V(
      [3],
      [
        function (a, b) {
          M(a, 113, b);
        },
      ]
    ),
    u: new V(
      [3],
      [
        function (a, b) {
          M(a, 18, b);
        },
      ]
    ),
    ut: new V(
      [3],
      [
        function (a, b) {
          M(a, 45, b);
        },
      ]
    ),
    v: new V(
      [0],
      [
        function (a, b) {
          N(a, 62, b);
        },
      ]
    ),
    vb: new V(
      [0],
      [
        function (a, b) {
          Nf(a, 68, b);
        },
      ]
    ),
    vf: new V(
      [4],
      [
        function (a, b) {
          Q(a, 102, b);
        },
      ]
    ),
    vl: new V(
      [0],
      [
        function (a, b) {
          Nf(a, 69, b);
        },
      ]
    ),
    vm: new V(
      [3],
      [
        function (a, b) {
          M(a, 98, b);
        },
      ]
    ),
    w: new V(
      [0],
      [
        function (a, b) {
          a.B(b);
        },
      ]
    ),
    x: new V(
      [0],
      [
        function (a, b) {
          N(a, 9, b);
        },
      ]
    ),
    y: new V(
      [0],
      [
        function (a, b) {
          N(a, 10, b);
        },
      ]
    ),
    ya: new V(
      [2],
      [
        function (a, b) {
          P(a, 77, b);
        },
      ]
    ),
    z: new V(
      [0],
      [
        function (a, b) {
          N(a, 11, b);
        },
      ]
    ),
  };
  function ko(a, b) {
    Xn("For token '%s': %s", a, b);
  }
  function lo(a, b) {
    var c = new nn(),
      d = new nn();
    if (b == "") a = !0;
    else {
      b = b.split("-");
      for (var e = !0, f = 0; f < b.length; f++) {
        var g = b[f];
        if (g.length == 0) e = !1;
        else {
          var h = g,
            k = !1;
          var l = h;
          var m = h.substring(0, 1);
          m != m.toLowerCase() &&
            ((k = !0), (l = h.substring(0, 1).toLowerCase() + h.substring(1)));
          var n = io;
          for (m = 1; m <= l.length; ++m) {
            var q = n;
            var r = l.substring(0, m);
            q = r.length == 0 ? !q.isEmpty() : !!eo(q, r);
            if (!q) break;
          }
          l =
            m == 1
              ? null
              : (l = n.get(l.substring(0, m - 1)))
              ? {
                  ni: h.substring(0, m - 1),
                  value: h.substring(m - 1),
                  wi: k,
                  attributes: l,
                }
              : null;
          if (l) {
            h = [];
            k = [];
            m = !1;
            for (n = 0; n < l.attributes.types.length; n++) {
              q = l.attributes.types[n];
              var t = l.value;
              r = f;
              if (l.wi && q == 1)
                for (var v = t.length; v < 12 && r < b.length - 1; )
                  (t += "-" + b[r + 1]), (v = t.length), ++r;
              else if (q == 2)
                for (; r < b.length - 1 && b[r + 1].match(/^[\d\.]/); )
                  (t += "-" + b[r + 1]), ++r;
              v = l.attributes.A[n];
              t = mo(a, q)(l.ni, t, c, d, v);
              if (t === null) {
                m = !0;
                f = r;
                break;
              } else h.push(q), k.push(t);
            }
            if (!m)
              for (l = 0; l < k.length; l++)
                (n = h[l]), (t = k[l]), no(a, n)(g, t);
            e = e && m;
          } else e = !1;
        }
      }
      a = e;
    }
    return new oo(c, d, a);
  }
  function po(a, b, c, d, e, f) {
    e(c, b);
    a = a.substring(0, 1);
    f = f(a == a.toUpperCase());
    e(d, f);
  }
  p = ho.prototype;
  p.H = function (a, b, c, d, e) {
    if (b == "") return 0;
    isFinite(b) && (b = String(b));
    b =
      typeof b === "string"
        ? /^\s*-?0x/i.test(b)
          ? parseInt(b, 16)
          : parseInt(b, 10)
        : NaN;
    if (isNaN(b)) return 1;
    po(a, b, c, d, e, Number);
    return null;
  };
  p.C = function (a, b) {
    switch (b) {
      case 1:
        ko(a, "Option value could not be interpreted as an integer.");
        break;
      case 0:
        ko(a, "Missing value for integer option.");
    }
  };
  p.G = function (a, b, c, d, e) {
    if (b == "") return 0;
    var f = Number(b);
    b = f == 0 && /^[\s\xa0]*$/.test(b) ? NaN : f;
    if (isNaN(b)) return 1;
    po(a, b, c, d, e, Number);
    return null;
  };
  p.B = function (a, b) {
    switch (b) {
      case 1:
        ko(a, "Option value could not be interpreted as a float.");
        break;
      case 0:
        ko(a, "Missing value for float option.");
    }
  };
  p.F = function (a, b, c, d, e) {
    if (b != "") return 2;
    po(a, !0, c, d, e, Boolean);
    return null;
  };
  p.A = function (a, b) {
    switch (b) {
      case 2:
        ko(a, "Unexpected value specified for boolean option.");
    }
  };
  p.I = function (a, b, c, d, e) {
    if (b == "") return 0;
    po(a, b, c, d, e, (f) => (f ? "1" : ""));
    return null;
  };
  p.D = function (a, b) {
    switch (b) {
      case 0:
        ko(a, "Missing value for string option.");
    }
  };
  p.J = function (a, b, c, d, e) {
    if (b == "") return 0;
    po(a, b, c, d, e, (f) => (f ? 1 : 0));
    return null;
  };
  function mo(a, b) {
    switch (b) {
      case 0:
        return Ba(a.H, a);
      case 2:
        return Ba(a.G, a);
      case 3:
        return Ba(a.F, a);
      case 4:
        return Ba(a.I, a);
      case 1:
        return Ba(a.J, a);
      default:
        return function () {};
    }
  }
  function no(a, b) {
    switch (b) {
      case 0:
        return Ba(a.C, a);
      case 2:
        return Ba(a.B, a);
      case 3:
        return Ba(a.A, a);
      case 4:
      case 1:
        return Ba(a.D, a);
      default:
        return function () {};
    }
  }
  function oo(a, b, c) {
    this.A = a;
    this.B = b;
    this.C = c;
  }
  oo.prototype.Eb = function () {
    return this.C;
  };
  function qo(a, b) {
    a != null && this.B.apply(this, arguments);
  }
  p = qo.prototype;
  p.A = "";
  p.set = function (a) {
    this.A = "" + a;
  };
  p.B = function (a, b, c) {
    this.A += String(a);
    if (b != null)
      for (let d = 1; d < arguments.length; d++) this.A += arguments[d];
    return this;
  };
  p.clear = function () {
    this.A = "";
  };
  p.toString = function () {
    return this.A;
  };
  function ro(a) {
    this.O = null;
    this.F = [];
    this.D = null;
    so(this, a);
  }
  function to(a) {
    a.O == null && (a.O = new ho());
    return a.O;
  }
  function so(a, b) {
    a.D = b ? (typeof b === "string" ? lo(to(a), b) : b) : lo(to(a), "");
  }
  p = ro.prototype;
  p.I = function (a) {
    a = a || void 0;
    var b = this.D.A;
    a != C(b, 2) && M(b, 2, a);
    return this;
  };
  p.H = function (a) {
    a = a || void 0;
    var b = this.D.A;
    a != G(b, 51) && M(b, 51, a);
    return this;
  };
  p.J = function (a) {
    a = a || void 0;
    var b = this.D.A;
    a != G(b, 32) && M(b, 32, a);
    return this;
  };
  p.A = function (a) {
    var b = this.D,
      c = b.A,
      d = c.R();
    b.B.R();
    a != d && c.A(a);
    return this;
  };
  p.G = function (a) {
    a = a || void 0;
    var b = this.D.A;
    a != C(b, 20) && M(b, 20, a);
    return this;
  };
  p.K = function (a) {
    a = a || void 0;
    var b = this.D.A;
    a != C(b, 19) && M(b, 19, a);
    return this;
  };
  p.M = function (a) {
    a = a || void 0;
    var b = this.D.A;
    a != G(b, 60) && M(b, 60, a);
    return this;
  };
  p.L = function (a) {
    a = a || void 0;
    var b = this.D.A;
    a != C(b, 67) && M(b, 67, a);
    return this;
  };
  p.N = function (a) {
    a = a || void 0;
    var b = this.D.A;
    a != C(b, 52) && M(b, 52, a);
    return this;
  };
  p.setSize = function (a) {
    var b = this.D,
      c = b.A,
      d = K(c, 1);
    K(b.B, 1);
    a != d && c.setSize(a);
    return this;
  };
  p.B = function (a) {
    var b = this.D,
      c = b.A,
      d = c.S();
    b.B.S();
    a != d && c.B(a);
    return this;
  };
  p.ld = function () {
    this.F.length = 0;
    var a = this.D,
      b = a.A;
    a = a.B;
    uo(this, "s", K(b, 1), K(a, 1));
    uo(this, "w", b.S(), a.S());
    X(this, "c", C(b, 2), C(a, 2));
    X(this, "d", C(b, 3), C(a, 3));
    uo(this, "h", b.R(), a.R());
    X(this, "s", G(b, 33), G(a, 33));
    X(this, "h", C(b, 4), C(a, 4));
    X(this, "p", C(b, 19), C(a, 19));
    X(this, "pp", C(b, 52), C(a, 52));
    X(this, "pf", C(b, 67), C(a, 67));
    X(this, "n", C(b, 20), C(a, 20));
    uo(this, "r", K(b, 26), K(a, 26));
    X(this, "r", C(b, 6), C(a, 6));
    X(this, "o", G(b, 27), G(a, 27));
    var c = Cf(b, 7, We);
    vo(this, "o", c, Cf(a, 7, We));
    c = Cf(b, 29, We);
    vo(this, "j", c, Cf(a, 29, We));
    uo(this, "x", K(b, 9), K(a, 9));
    uo(this, "y", K(b, 10), K(a, 10));
    uo(this, "z", K(b, 11), K(a, 11));
    X(this, "g", C(b, 14), C(a, 14));
    uo(this, "e", K(b, 15), K(a, 15));
    vo(this, "f", Lf(b, 16), Lf(a, 16));
    X(this, "k", G(b, 17), G(a, 17));
    X(this, "u", G(b, 18), !0);
    X(this, "ut", G(b, 45), !0);
    X(this, "i", G(b, 22), !0);
    X(this, "a", G(b, 21), G(a, 21));
    X(this, "b", C(b, 23), C(a, 23));
    uo(this, "b", K(b, 38), K(a, 38));
    uo(this, "c", K(b, 39), K(a, 39), 16, 8);
    vo(this, "q", Lf(b, 28), Lf(a, 28));
    X(this, "fh", G(b, 30), G(a, 30));
    X(this, "fv", G(b, 31), G(a, 31));
    X(this, "fg", C(b, 34), C(a, 34));
    X(this, "ci", G(b, 32), G(a, 32));
    vo(this, "t", Lf(b, 24), Lf(a, 24));
    vo(this, "nt0", Lf(b, 36), Lf(a, 36));
    X(this, "rw", C(b, 35), C(a, 35));
    X(this, "rwu", C(b, 41), C(a, 41));
    X(this, "rwa", C(b, 64), C(a, 64));
    X(this, "nw", C(b, 48), C(a, 48));
    X(this, "rh", C(b, 49), C(a, 49));
    X(this, "no", C(b, 37), C(a, 37));
    X(this, "ns", G(b, 40), G(a, 40));
    uo(this, "k", K(b, 42), K(a, 42));
    uo(this, "p", K(b, 43), K(a, 43));
    uo(this, "l", K(b, 44), K(a, 44));
    uo(this, "v", K(b, 62), K(a, 62));
    X(this, "nu", G(b, 46), G(a, 46));
    X(this, "ft", G(b, 50), G(a, 50));
    X(this, "cc", G(b, 51), G(a, 51));
    X(this, "nd", G(b, 53), G(a, 53));
    X(this, "ip", G(b, 54), G(a, 54));
    X(this, "nc", G(b, 55), G(a, 55));
    uo(this, "a", K(b, 56), K(a, 56));
    X(this, "rj", G(b, 57), G(a, 57));
    X(this, "rp", G(b, 58), G(a, 58));
    X(this, "rg", G(b, 59), G(a, 59));
    X(this, "pd", G(b, 60), G(a, 60));
    X(this, "pa", G(b, 61), G(a, 61));
    uo(this, "m", K(b, 63), K(a, 63));
    uo(this, "vb", Jf(b, 68), Jf(a, 68));
    uo(this, "vl", Jf(b, 69), Jf(a, 69));
    X(this, "lf", G(b, 65), G(a, 65));
    X(this, "mv", G(b, 66), G(a, 66));
    X(this, "id", G(b, 70), G(a, 70));
    uo(this, "ic", K(b, 71), !0);
    X(this, "pg", C(b, 72), C(a, 72));
    X(this, "mo", G(b, 73), G(a, 73));
    X(this, "al", G(b, 74), G(a, 74));
    uo(this, "iv", Jf(b, 75), Jf(a, 75));
    uo(this, "pi", Kf(b, 76), Kf(a, 76));
    uo(this, "ya", Kf(b, 77), Kf(a, 77));
    uo(this, "ro", Kf(b, 78), Kf(a, 78));
    uo(this, "fo", Kf(b, 79), Kf(a, 79));
    X(this, "df", G(b, 80), G(a, 80));
    vo(this, "mm", Lf(b, 81), Lf(a, 81));
    X(this, "sg", G(b, 82), G(a, 82));
    X(this, "gd", G(b, 83), G(a, 83));
    X(this, "fm", G(b, 84), G(a, 84));
    uo(this, "ba", K(b, 85), K(a, 85));
    uo(this, "br", K(b, 86), K(a, 86));
    uo(this, "bc", K(b, 87), K(a, 87), 16, 8);
    uo(this, "pc", K(b, 88), K(a, 88), 16, 8);
    uo(this, "sc", K(b, 89), K(a, 89), 16, 8);
    X(this, "dv", G(b, 90), G(a, 90));
    X(this, "md", G(b, 91), G(a, 91));
    uo(this, "cp", K(b, 92), K(a, 92));
    X(this, "sm", G(b, 93), G(a, 93));
    uo(this, "cv", K(b, 94), K(a, 94));
    X(this, "ng", G(b, 95), G(a, 95));
    X(this, "il", G(b, 96), G(a, 96));
    X(this, "lo", G(b, 97), G(a, 97));
    X(this, "vm", G(b, 98), G(a, 98));
    vo(this, "dc", Lf(b, 99), Lf(a, 99));
    X(this, "rf", G(b, 100), G(a, 100));
    vo(this, "vf", Lf(b, 102), Lf(a, 102));
    X(this, "ra", C(b, 103), C(a, 103));
    X(this, "ckm", G(b, 104), G(a, 104));
    X(this, "gm", G(b, 105), G(a, 105));
    X(this, "ngm", G(b, 106), G(a, 106));
    uo(this, "em", K(b, 107), K(a, 107));
    X(this, "cr", G(b, 108), G(a, 108));
    uo(this, "sl", K(b, 109), K(a, 109));
    uo(this, "sb", K(b, 110), K(a, 110));
    vo(this, "pt", Lf(b, 111), Lf(a, 111));
    vo(this, "gce", Lf(b, 112), Lf(a, 112));
    X(this, "tm", G(b, 113), G(a, 113));
    X(this, "ntm", G(b, 114), G(a, 114));
    uo(this, "mp", K(b, 115), K(a, 115));
    vo(this, "lp", Lf(b, 116), !0);
    return this.F.join("-");
  };
  function uo(a, b, c, d, e, f) {
    if (c != null) {
      var g = e == void 0 || (e != 10 && e != 16) ? 10 : e;
      c = Number(c).toString(g);
      e = new qo();
      e.B(g == 16 ? "0x" : "");
      g = e.B;
      if (f == void 0) var h = "";
      else (f -= c.length), f <= 0 ? (h = "") : (h = "0".repeat(f));
      g.call(e, h);
      e.B(c);
      wo(a, b, e.toString(), !!Number(d));
    }
  }
  function X(a, b, c, d) {
    c && wo(a, b, "", !!d);
  }
  function vo(a, b, c, d) {
    c && wo(a, b, String(c), !!Number(d));
  }
  function wo(a, b, c, d) {
    d && (b = b.substring(0, 1).toUpperCase() + b.substring(1));
    a.F.push(b + c);
  }
  function xo(a, b, c) {
    return Math.min(Math.max(a, b), c);
  }
  function yo(a, b) {
    a %= b;
    return a * b < 0 ? a + b : a;
  }
  function zo(a, b, c) {
    return a + c * (b - a);
  }
  function Ao(a) {
    return yo(a, 360);
  }
  function Bo(a) {
    return (a * Math.PI) / 180;
  }
  function Co(a) {
    return (a * 180) / Math.PI;
  }
  function Do(a, b) {
    a = Ao(b) - Ao(a);
    a > 180 ? (a -= 360) : a <= -180 && (a = 360 + a);
    return a;
  }
  function Eo(a, b) {
    this.width = a;
    this.height = b;
  }
  p = Eo.prototype;
  p.clone = function () {
    return new Eo(this.width, this.height);
  };
  p.area = function () {
    return this.width * this.height;
  };
  p.aspectRatio = function () {
    return this.width / this.height;
  };
  p.isEmpty = function () {
    return !this.area();
  };
  p.ceil = function () {
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this;
  };
  p.floor = function () {
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this;
  };
  p.round = function () {
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this;
  };
  p.scale = function (a, b) {
    b = typeof b === "number" ? b : a;
    this.width *= a;
    this.height *= b;
    return this;
  };
  function Fo(a) {
    ro.call(this, a);
  }
  Ea(Fo, ro);
  p = Fo.prototype;
  p.I = function (a) {
    a && Go(this);
    return Fo.qa.I.call(this, a);
  };
  p.A = function (a) {
    a = a == null || a < 0 ? void 0 : a;
    a != null && this.setSize();
    return Fo.qa.A.call(this, a);
  };
  p.J = function (a) {
    a && Go(this);
    return Fo.qa.J.call(this, a);
  };
  p.H = function (a) {
    a && Go(this);
    return Fo.qa.H.call(this, a);
  };
  p.setSize = function (a) {
    ra(a) && (a = Math.max(a.width, a.height));
    a = a == null || a < 0 ? void 0 : a;
    a != null && (this.B(), this.A());
    return Fo.qa.setSize.call(this, a);
  };
  p.K = function (a) {
    a && Go(this);
    return Fo.qa.K.call(this, a);
  };
  p.N = function (a) {
    a && Go(this);
    return Fo.qa.N.call(this, a);
  };
  p.L = function (a) {
    a && Go(this);
    return Fo.qa.L.call(this, a);
  };
  p.G = function (a) {
    a && Go(this);
    return Fo.qa.G.call(this, a);
  };
  p.M = function (a) {
    a && Go(this);
    return Fo.qa.M.call(this, a);
  };
  p.B = function (a) {
    a = a == null || a < 0 ? void 0 : a;
    a != null && this.setSize();
    return Fo.qa.B.call(this, a);
  };
  function Go(a) {
    a.G();
    a.H();
    a.I();
    a.J();
    a.M();
    a.K();
    a.N();
    a.L();
  }
  p.ld = function () {
    var a = this.D.A;
    G(a, 18) || G(a, 45)
      ? K(a, 1) || this.setSize(0)
      : ((a = this.D.A),
        K(a, 1) ||
          a.S() ||
          a.R() ||
          (this.setSize(), this.A(), this.B(), Go(this)));
    return Fo.qa.ld.call(this);
  };
  var Ho = RegExp(
    "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
  );
  function Io(a, b) {
    if (a) {
      a = a.split("&");
      for (let c = 0; c < a.length; c++) {
        let d = a[c].indexOf("="),
          e,
          f = null;
        d >= 0
          ? ((e = a[c].substring(0, d)), (f = a[c].substring(d + 1)))
          : (e = a[c]);
        b(e, f ? Tn(f) : "");
      }
    }
  }
  function Jo(a) {
    var b = a.indexOf("#");
    b < 0 && (b = a.length);
    var c = a.indexOf("?");
    if (c < 0 || c > b) {
      c = b;
      var d = "";
    } else d = a.substring(c + 1, b);
    return [a.slice(0, c), d, a.slice(b)];
  }
  function Ko(a, b) {
    return b ? (a ? a + "&" + b : b) : a;
  }
  function Lo(a, b, c) {
    if (Array.isArray(b))
      for (let d = 0; d < b.length; d++) Lo(a, String(b[d]), c);
    else
      b != null &&
        c.push(a + (b === "" ? "" : "=" + encodeURIComponent(String(b))));
  }
  function Mo(a) {
    var b = [];
    for (let c in a) Lo(c, a[c], b);
    return b.join("&");
  }
  var No = /#|$/;
  function Oo(a) {
    var b = a.search(No),
      c;
    a: {
      for (c = 0; (c = a.indexOf("cid", c)) >= 0 && c < b; ) {
        var d = a.charCodeAt(c - 1);
        if (d == 38 || d == 63)
          if (((d = a.charCodeAt(c + 3)), !d || d == 61 || d == 38 || d == 35))
            break a;
        c += 4;
      }
      c = -1;
    }
    if (c < 0) return null;
    d = a.indexOf("&", c);
    if (d < 0 || d > b) d = b;
    return Tn(a.slice(c + 4, d !== -1 ? d : 0));
  }
  function Po(a, b) {
    a = Jo(a);
    var c = a[1],
      d = [];
    c &&
      c.split("&").forEach(function (e) {
        var f = e.indexOf("=");
        f = f >= 0 ? e.slice(0, f) : e;
        b.hasOwnProperty(f) || d.push(e);
      });
    a[1] = Ko(d.join("&"), Mo(b));
    return a[0] + (a[1] ? "?" + a[1] : "") + a[2];
  }
  function Qo(a, b) {
    this.A = this.I = this.C = "";
    this.G = null;
    this.H = this.F = "";
    this.D = !1;
    var c;
    a instanceof Qo
      ? ((this.D = b !== void 0 ? b : a.D),
        Ro(this, a.C),
        So(this, a.I),
        (this.A = a.A),
        To(this, a.G),
        (this.F = a.getPath()),
        Uo(this, a.B.clone()),
        Vo(this, a.H))
      : a && (c = String(a).match(Ho))
      ? ((this.D = !!b),
        Ro(this, c[1] || "", !0),
        So(this, c[2] || "", !0),
        (this.A = Wo(c[3] || "", !0)),
        To(this, c[4]),
        (this.F = Wo(c[5] || "", !0)),
        Uo(this, c[6] || "", !0),
        Vo(this, c[7] || "", !0))
      : ((this.D = !!b), (this.B = new Xo(null, this.D)));
  }
  Qo.prototype.toString = function () {
    var a = [],
      b = this.C;
    b && a.push(Yo(b, Zo, !0), ":");
    var c = this.A;
    if (c || b == "file")
      a.push("//"),
        (b = this.I) && a.push(Yo(b, Zo, !0), "@"),
        a.push(
          encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")
        ),
        (c = this.G),
        c != null && a.push(":", String(c));
    if ((c = this.getPath()))
      this.A && c.charAt(0) != "/" && a.push("/"),
        a.push(Yo(c, c.charAt(0) == "/" ? $o : ap, !0));
    (c = this.B.toString()) && a.push("?", c);
    (c = this.H) && a.push("#", Yo(c, bp));
    return a.join("");
  };
  Qo.prototype.resolve = function (a) {
    var b = this.clone(),
      c = !!a.C;
    c ? Ro(b, a.C) : (c = !!a.I);
    c ? So(b, a.I) : (c = !!a.A);
    c ? (b.A = a.A) : (c = a.G != null);
    var d = a.getPath();
    if (c) To(b, a.G);
    else if ((c = !!a.F)) {
      if (d.charAt(0) != "/")
        if (this.A && !this.F) d = "/" + d;
        else {
          var e = b.getPath().lastIndexOf("/");
          e != -1 && (d = b.getPath().slice(0, e + 1) + d);
        }
      e = d;
      if (e == ".." || e == ".") d = "";
      else if (e.indexOf("./") != -1 || e.indexOf("/.") != -1) {
        d = e.lastIndexOf("/", 0) == 0;
        e = e.split("/");
        let f = [];
        for (let g = 0; g < e.length; ) {
          let h = e[g++];
          h == "."
            ? d && g == e.length && f.push("")
            : h == ".."
            ? ((f.length > 1 || (f.length == 1 && f[0] != "")) && f.pop(),
              d && g == e.length && f.push(""))
            : (f.push(h), (d = !0));
        }
        d = f.join("/");
      } else d = e;
    }
    c ? (b.F = d) : (c = a.B.toString() !== "");
    c ? Uo(b, a.B.clone()) : (c = !!a.H);
    c && Vo(b, a.H);
    return b;
  };
  Qo.prototype.clone = function () {
    return new Qo(this);
  };
  function Ro(a, b, c) {
    a.C = c ? Wo(b, !0) : b;
    a.C && (a.C = a.C.replace(/:$/, ""));
  }
  function So(a, b, c) {
    a.I = c ? Wo(b) : b;
    return a;
  }
  function To(a, b) {
    if (b) {
      b = Number(b);
      if (isNaN(b) || b < 0) throw Error("Bad port number " + b);
      a.G = b;
    } else a.G = null;
  }
  Qo.prototype.getPath = function () {
    return this.F;
  };
  function Uo(a, b, c) {
    b instanceof Xo
      ? ((a.B = b), cp(a.B, a.D))
      : (c || (b = Yo(b, dp)), (a.B = new Xo(b, a.D)));
    return a;
  }
  function Vo(a, b, c) {
    a.H = c ? Wo(b) : b;
    return a;
  }
  function ep(a, b) {
    return a instanceof Qo ? a.clone() : new Qo(a, b);
  }
  function Wo(a, b) {
    return a
      ? b
        ? decodeURI(a.replace(/%25/g, "%2525"))
        : decodeURIComponent(a)
      : "";
  }
  function Yo(a, b, c) {
    return typeof a === "string"
      ? ((a = encodeURI(a).replace(b, fp)),
        c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")),
        a)
      : null;
  }
  function fp(a) {
    a = a.charCodeAt(0);
    return "%" + ((a >> 4) & 15).toString(16) + (a & 15).toString(16);
  }
  var Zo = /[#\/\?@]/g,
    ap = /[#\?:]/g,
    $o = /[#\?]/g,
    dp = /[#\?@]/g,
    bp = /#/g;
  function Xo(a, b) {
    this.ta = this.A = null;
    this.B = a || null;
    this.C = !!b;
  }
  function gp(a) {
    a.A ||
      ((a.A = new Map()),
      (a.ta = 0),
      a.B &&
        Io(a.B, function (b, c) {
          a.add(Tn(b), c);
        }));
  }
  p = Xo.prototype;
  p.add = function (a, b) {
    gp(this);
    this.B = null;
    a = hp(this, a);
    var c = this.A.get(a);
    c || this.A.set(a, (c = []));
    c.push(b);
    this.ta = this.ta + 1;
    return this;
  };
  p.remove = function (a) {
    gp(this);
    a = hp(this, a);
    return this.A.has(a)
      ? ((this.B = null),
        (this.ta = this.ta - this.A.get(a).length),
        this.A.delete(a))
      : !1;
  };
  p.clear = function () {
    this.A = this.B = null;
    this.ta = 0;
  };
  p.isEmpty = function () {
    gp(this);
    return this.ta == 0;
  };
  function ip(a, b) {
    gp(a);
    b = hp(a, b);
    return a.A.has(b);
  }
  p.forEach = function (a, b) {
    gp(this);
    this.A.forEach(function (c, d) {
      c.forEach(function (e) {
        a.call(b, e, d, this);
      }, this);
    }, this);
  };
  p.Ee = function () {
    gp(this);
    var a = Array.from(this.A.values()),
      b = Array.from(this.A.keys()),
      c = [];
    for (let d = 0; d < b.length; d++) {
      let e = a[d];
      for (let f = 0; f < e.length; f++) c.push(b[d]);
    }
    return c;
  };
  p.kc = function (a) {
    gp(this);
    var b = [];
    if (typeof a === "string")
      ip(this, a) && (b = b.concat(this.A.get(hp(this, a))));
    else {
      a = Array.from(this.A.values());
      for (let c = 0; c < a.length; c++) b = b.concat(a[c]);
    }
    return b;
  };
  p.set = function (a, b) {
    gp(this);
    this.B = null;
    a = hp(this, a);
    ip(this, a) && (this.ta = this.ta - this.A.get(a).length);
    this.A.set(a, [b]);
    this.ta = this.ta + 1;
    return this;
  };
  p.get = function (a, b) {
    if (!a) return b;
    a = this.kc(a);
    return a.length > 0 ? String(a[0]) : b;
  };
  p.toString = function () {
    if (this.B) return this.B;
    if (!this.A) return "";
    var a = [],
      b = Array.from(this.A.keys());
    for (let d = 0; d < b.length; d++) {
      var c = b[d];
      let e = encodeURIComponent(String(c));
      c = this.kc(c);
      for (let f = 0; f < c.length; f++) {
        let g = e;
        c[f] !== "" && (g += "=" + encodeURIComponent(String(c[f])));
        a.push(g);
      }
    }
    return (this.B = a.join("&"));
  };
  p.clone = function () {
    var a = new Xo();
    a.B = this.B;
    this.A && ((a.A = new Map(this.A)), (a.ta = this.ta));
    return a;
  };
  function hp(a, b) {
    b = String(b);
    a.C && (b = b.toLowerCase());
    return b;
  }
  function cp(a, b) {
    b &&
      !a.C &&
      (gp(a),
      (a.B = null),
      a.A.forEach(function (c, d) {
        var e = d.toLowerCase();
        d != e &&
          (this.remove(d),
          this.remove(e),
          c.length > 0 &&
            ((this.B = null),
            this.A.set(hp(this, e), Db(c)),
            (this.ta = this.ta + c.length)));
      }, a));
    a.C = b;
  }
  p.extend = function (a) {
    for (let b = 0; b < arguments.length; b++)
      ao(
        arguments[b],
        function (c, d) {
          this.add(d, c);
        },
        this
      );
  };
  var jp = /^[^\/]*\/\//;
  function kp(a, b = !1) {
    this.C = a;
    this.G = "";
    (a = this.C.match(jp)) && a[0]
      ? ((this.G = a[0]),
        (a = this.G.match(/\w+/)
          ? this.C
          : "http://" + this.C.substring(this.G.length)))
      : (a = "http://" + this.C);
    this.D = ep(a, !0);
    this.K = b;
    this.F = !0;
    this.O = !1;
  }
  function lp(a, b) {
    a.B = a.B ? a.B + ("/" + b) : b;
  }
  function mp(a) {
    if (a.A == void 0) {
      var b = a.D.getPath().substring(1);
      a.B = null;
      if (a.K) {
        a.A = [];
        if ((b.match(/=/g) || []).length > 1) return (a.F = !1), a.A;
        var c = b.indexOf("=");
        c != -1
          ? (a.A.push(b.substr(0, c)), a.A.push(b.substr(c + 1)))
          : a.A.push(b);
        return a.A;
      }
      a.A = b.split("/");
      b = a.A.length;
      b > 2 &&
        a.A[0] == "u" &&
        (lp(a, a.A[0] + "/" + a.A[1]), a.A.shift(), a.A.shift(), (b -= 2));
      if (b == 0 || b == 4 || b > 7) return (a.F = !1), a.A;
      if (b == 2) lp(a, a.A[0]);
      else if (a.A[0] == "image") lp(a, a.A[0]);
      else if (b == 7 || b == 3) return (a.F = !1), a.A;
      if (b <= 3) {
        a.O = !0;
        b == 3 && (lp(a, a.A[1]), a.A.shift(), --b);
        --b;
        c = a.A[b];
        let d = c.indexOf("=");
        d != -1 && ((a.A[b] = c.substr(0, d)), a.A.push(c.substr(d + 1)));
      }
    }
    return a.A;
  }
  kp.prototype.Eb = function () {
    mp(this);
    return this.F;
  };
  function np(a) {
    mp(a);
    return a.O;
  }
  function op(a) {
    mp(a);
    return a.K;
  }
  function pp(a) {
    mp(a);
    a.B == void 0 && (a.B = null);
    return a.B;
  }
  function qp(a) {
    switch (mp(a).length) {
      case 7:
        return !0;
      case 6:
        return pp(a) == null;
      case 5:
        return !1;
      case 3:
        return !0;
      case 2:
        return pp(a) == null;
      case 1:
        return !1;
      default:
        return !1;
    }
  }
  function rp(a, b) {
    if (op(a))
      a: {
        switch (b) {
          case 7:
            b = 0;
            break;
          case 4:
            if (!qp(a)) {
              a = null;
              break a;
            }
            b = 1;
            break;
          default:
            a = null;
            break a;
        }
        a = mp(a)[b];
      }
    else if (np(a))
      a: {
        var c = pp(a) != null ? 1 : 0;
        switch (b) {
          case 6:
            b = 0 + c;
            break;
          case 4:
            if (!qp(a)) {
              a = null;
              break a;
            }
            b = 1 + c;
            break;
          default:
            a = null;
            break a;
        }
        a = mp(a)[b];
      }
    else
      a: {
        c = pp(a) != null ? 1 : 0;
        switch (b) {
          case 0:
            b = 0 + c;
            break;
          case 1:
            b = 1 + c;
            break;
          case 2:
            b = 2 + c;
            break;
          case 3:
            b = 3 + c;
            break;
          case 4:
            if (!qp(a)) {
              a = null;
              break a;
            }
            b = 4 + c;
            break;
          case 5:
            b = qp(a) ? 1 : 0;
            b = 4 + c + b;
            break;
          default:
            a = null;
            break a;
        }
        a = mp(a)[b];
      }
    return a;
  }
  function sp(a, b = !1) {
    return new tp(a, b);
  }
  var up = class {},
    tp = class extends kp {
      constructor(a, b = !1) {
        super(a, b);
      }
    };
  function vp(a, b = !1) {
    this.C = null;
    a instanceof tp ||
      (wp == void 0 && (wp = new up()), (a = sp(a.toString(), b)));
    a = this.C = a;
    a.H == void 0 &&
      (a.V == void 0 && (a.V = rp(a, 4)),
      (b = a.V) || (b = ""),
      (a.H = lo(new ho(), b)));
    ro.call(this, a.H);
    this.T = this.C.G;
    a = this.C;
    b = a.D.G;
    this.P = a.D.A + (b ? ":" + b : "");
    this.V = this.C.D.B.toString();
  }
  Ea(vp, Fo);
  var wp;
  vp.prototype.Eb = function () {
    return this.C.Eb();
  };
  vp.prototype.ld = function () {
    if (!this.C.Eb()) return this.C.C;
    var a = vp.qa.ld.call(this),
      b = [];
    pp(this.C) != null && b.push(pp(this.C));
    var c = op(this.C);
    if (np(this.C)) {
      var d = this.C;
      d.N == void 0 && (d.N = rp(d, 6));
      b.push(d.N + (a ? "=" + a : ""));
    } else if (c) {
      d = b.push;
      var e = this.C;
      e.J === void 0 && (e.J = rp(e, 7));
      d.call(b, e.J);
      a && b.push(a);
    } else
      (d = b.push),
        (e = this.C),
        e.L == void 0 && (e.L = rp(e, 0)),
        d.call(b, e.L),
        (d = b.push),
        (e = this.C),
        e.P == void 0 && (e.P = rp(e, 1)),
        d.call(b, e.P),
        (d = b.push),
        (e = this.C),
        e.M == void 0 && (e.M = rp(e, 2)),
        d.call(b, e.M),
        (d = b.push),
        (e = this.C),
        e.T == void 0 && (e.T = rp(e, 3)),
        d.call(b, e.T),
        a && b.push(a),
        (a = b.push),
        (d = this.C),
        d.I == void 0 && (d.I = rp(d, 5)),
        a.call(b, d.I);
    b = c ? b.join("=") : b.join("/");
    b = ep(this.T + this.P + "/" + b + (this.V ? "?" + this.V : "")).toString();
    b.startsWith("%3a//") && (b = b.replace("%3a//", "://"));
    return b;
  };
  function xp(a, ...b) {
    var c = "";
    for (let d = 0; d < a.length; d++)
      (c += a[d]), d < b.length && (c += Sn(b[d]));
    return new Rn(c);
  }
  function yp(a, b) {
    if (a instanceof Ln) return a;
    a = String(a)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&apos;");
    b?.Of && (a = a.replace(/(^|[\r\n\t ]) /g, "$1&#160;"));
    b?.Nf && (a = a.replace(/(\r\n|\n|\r)/g, "<br>"));
    b?.yj &&
      (a = a.replace(/(\t+)/g, '<span style="white-space:pre">$1</span>'));
    return Mn(a);
  }
  function zp(a) {
    return Ap(a);
  }
  function Ap(a) {
    var b = yp("");
    return Mn(a.map((c) => Nn(yp(c))).join(Nn(b).toString()));
  }
  var Bp = /^[a-z][a-z\d-]*$/i,
    Cp =
      "APPLET BASE EMBED IFRAME LINK MATH META OBJECT SCRIPT STYLE SVG TEMPLATE".split(
        " "
      ),
    Dp = "AREA BR COL COMMAND HR IMG INPUT KEYGEN PARAM SOURCE TRACK WBR".split(
      " "
    ),
    Ep = ["action", "formaction", "href"];
  function Fp(a, b) {
    if (!Bp.test("a")) throw Error("");
    if (Cp.indexOf("A") !== -1) throw Error("");
    var c = "<a";
    a && (c += Gp(a));
    Array.isArray(b) || (b = b === void 0 ? [] : [b]);
    Dp.indexOf("A") !== -1
      ? (c += ">")
      : ((a = zp(b.map((d) => (d instanceof Ln ? d : yp(String(d)))))),
        (c += ">" + a.toString() + "</a>"));
    return Mn(c);
  }
  function Gp(a) {
    var b = "",
      c = Object.keys(a);
    for (let f = 0; f < c.length; f++) {
      var d = c[f],
        e = a[d];
      if (!Bp.test(d)) throw Error("");
      if (e !== void 0 && e !== null) {
        if (/^on./i.test(d)) throw Error("");
        Ep.indexOf(d.toLowerCase()) !== -1 &&
          (e instanceof Dn
            ? (e = e.toString())
            : ((e = String(e)),
              (e = Kn.test(e) ? e : void 0),
              (e = e || "about:invalid#zClosurez")));
        d = `${d}="${yp(String(e))}"`;
        b += " " + d;
      }
    }
    return b;
  }
  "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT"
    .split(" ")
    .concat(["BUTTON", "INPUT"]);
  function Hp(a, b, c, d) {
    function e(g, h) {
      g != null &&
        (Array.isArray(g)
          ? g.forEach((k) => e(k, h))
          : ((b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g)),
            (f = "&")));
    }
    var f = b.length ? "&" : "?";
    d.constructor === Object && (d = Object.entries(d));
    Array.isArray(d) ? d.forEach((g) => e(g[1], g[0])) : d.forEach(e);
    return An(a + b + c);
  }
  var Ip = Symbol("syntheticEvent");
  var Jp =
    typeof AsyncContext !== "undefined" &&
    typeof AsyncContext.Snapshot === "function"
      ? (a) => a && AsyncContext.Snapshot.wrap(a)
      : (a) => a;
  function Kp(a, b) {
    a.D(b);
    a.B < 100 && (a.B++, (b.next = a.A), (a.A = b));
  }
  class Lp {
    constructor(a, b) {
      this.C = a;
      this.D = b;
      this.B = 0;
      this.A = null;
    }
    get() {
      if (this.B > 0) {
        this.B--;
        var a = this.A;
        this.A = a.next;
        a.next = null;
      } else a = this.C();
      return a;
    }
  }
  function Mp(a, b) {
    var c = a;
    b && (c = a.bind(b));
    c = Mp.zi(c);
    Mp.Qh
      ? setTimeout(c, 0)
      : ((c = Mp.ri(c)), Mp.Sg || (Mp.Sg = Mp.bi()), Mp.Sg(c));
  }
  Mp.ri = Jp;
  Mp.Qh = !1;
  Mp.bi = function () {
    if (typeof MessageChannel !== "undefined") {
      let a = new MessageChannel(),
        b = {},
        c = b;
      a.port1.onmessage = function () {
        if (b.next !== void 0) {
          b = b.next;
          let d = b.og;
          b.og = null;
          d();
        }
      };
      return function (d) {
        c.next = { og: d };
        c = c.next;
        a.port2.postMessage(0);
      };
    }
    return function (a) {
      u.setTimeout(a, 0);
    };
  };
  Mp.zi = (a) => a;
  class Np {
    constructor() {
      this.B = this.A = null;
    }
    add(a, b) {
      var c = Op.get();
      c.set(a, b);
      this.B ? (this.B.next = c) : (this.A = c);
      this.B = c;
    }
    remove() {
      var a = null;
      this.A &&
        ((a = this.A),
        (this.A = this.A.next),
        this.A || (this.B = null),
        (a.next = null));
      return a;
    }
  }
  var Op = new Lp(
    () => new Pp(),
    (a) => a.reset()
  );
  class Pp {
    constructor() {
      this.next = this.scope = this.xd = null;
    }
    set(a, b) {
      this.xd = a;
      this.scope = b;
      this.next = null;
    }
    reset() {
      this.next = this.scope = this.xd = null;
    }
  }
  var Qp,
    Rp = !1,
    Sp = new Np(),
    Up = (a, b) => {
      Qp || Tp();
      Rp || (Qp(), (Rp = !0));
      Sp.add(a, b);
    },
    Tp = () => {
      var a = Promise.resolve(void 0);
      Qp = () => {
        a.then(Vp);
      };
    };
  function Vp() {
    for (var a; (a = Sp.remove()); ) {
      try {
        a.xd.call(a.scope);
      } catch (b) {
        Ma(b);
      }
      Kp(Op, a);
    }
    Rp = !1;
  }
  function Wp() {}
  function Xp(a) {
    var b = a;
    return function () {
      if (b) {
        let c = b;
        b = null;
        c();
      }
    };
  }
  function Yp(a) {
    if (!a) return !1;
    try {
      return !!a.$goog_Thenable;
    } catch (b) {
      return !1;
    }
  }
  function Zp(a) {
    this.A = 0;
    this.H = void 0;
    this.D = this.B = this.C = null;
    this.F = this.G = !1;
    if (a != Wp)
      try {
        let b = this;
        a.call(
          void 0,
          function (c) {
            $p(b, 2, c);
          },
          function (c) {
            $p(b, 3, c);
          }
        );
      } catch (b) {
        $p(this, 3, b);
      }
  }
  function aq() {
    this.next = this.context = this.B = this.C = this.A = null;
    this.D = !1;
  }
  aq.prototype.reset = function () {
    this.context = this.B = this.C = this.A = null;
    this.D = !1;
  };
  var bq = new Lp(
    function () {
      return new aq();
    },
    function (a) {
      a.reset();
    }
  );
  function cq(a, b, c) {
    var d = bq.get();
    d.C = a;
    d.B = b;
    d.context = c;
    return d;
  }
  Zp.prototype.then = function (a, b, c) {
    return dq(
      this,
      Jp(typeof a === "function" ? a : null),
      Jp(typeof b === "function" ? b : null),
      c
    );
  };
  Zp.prototype.$goog_Thenable = !0;
  function eq(a, b, c, d) {
    fq(a, cq(b || Wp, c || null, d));
  }
  p = Zp.prototype;
  p.finally = function (a) {
    a = Jp(a);
    return new Zp((b, c) => {
      eq(
        this,
        (d) => {
          a();
          b(d);
        },
        (d) => {
          a();
          c(d);
        }
      );
    });
  };
  p.J = function (a, b) {
    return dq(this, null, Jp(a), b);
  };
  p.catch = Zp.prototype.J;
  p.cancel = function (a) {
    if (this.A == 0) {
      let b = new gq(a);
      Up(function () {
        hq(this, b);
      }, this);
    }
  };
  function hq(a, b) {
    if (a.A == 0)
      if (a.C) {
        var c = a.C;
        if (c.B) {
          var d = 0,
            e = null,
            f = null;
          for (
            let g = c.B;
            g && (g.D || (d++, g.A == a && (e = g), !(e && d > 1)));
            g = g.next
          )
            e || (f = g);
          e &&
            (c.A == 0 && d == 1
              ? hq(c, b)
              : (f
                  ? ((d = f),
                    d.next == c.D && (c.D = d),
                    (d.next = d.next.next))
                  : iq(c),
                jq(c, e, 3, b)));
        }
        a.C = null;
      } else $p(a, 3, b);
  }
  function fq(a, b) {
    a.B || (a.A != 2 && a.A != 3) || kq(a);
    a.D ? (a.D.next = b) : (a.B = b);
    a.D = b;
  }
  function dq(a, b, c, d) {
    var e = cq(null, null, null);
    e.A = new Zp(function (f, g) {
      e.C = b
        ? function (h) {
            try {
              let k = b.call(d, h);
              f(k);
            } catch (k) {
              g(k);
            }
          }
        : f;
      e.B = c
        ? function (h) {
            try {
              let k = c.call(d, h);
              k === void 0 && h instanceof gq ? g(h) : f(k);
            } catch (k) {
              g(k);
            }
          }
        : g;
    });
    e.A.C = a;
    fq(a, e);
    return e.A;
  }
  p.M = function (a) {
    this.A = 0;
    $p(this, 2, a);
  };
  p.K = function (a) {
    this.A = 0;
    $p(this, 3, a);
  };
  function $p(a, b, c) {
    if (a.A == 0) {
      a === c &&
        ((b = 3), (c = new TypeError("Promise cannot resolve to itself")));
      a.A = 1;
      a: {
        var d = c,
          e = a.M,
          f = a.K;
        if (d instanceof Zp) {
          eq(d, e, f, a);
          var g = !0;
        } else if (Yp(d)) d.then(e, f, a), (g = !0);
        else {
          if (ra(d))
            try {
              let h = d.then;
              if (typeof h === "function") {
                lq(d, h, e, f, a);
                g = !0;
                break a;
              }
            } catch (h) {
              f.call(a, h);
              g = !0;
              break a;
            }
          g = !1;
        }
      }
      g ||
        ((a.H = c),
        (a.A = b),
        (a.C = null),
        kq(a),
        b != 3 || c instanceof gq || mq(a, c));
    }
  }
  function lq(a, b, c, d, e) {
    function f(k) {
      h || ((h = !0), d.call(e, k));
    }
    function g(k) {
      h || ((h = !0), c.call(e, k));
    }
    var h = !1;
    try {
      b.call(a, g, f);
    } catch (k) {
      f(k);
    }
  }
  function kq(a) {
    a.G || ((a.G = !0), Up(a.I, a));
  }
  function iq(a) {
    var b = null;
    a.B && ((b = a.B), (a.B = b.next), (b.next = null));
    a.B || (a.D = null);
    return b;
  }
  p.I = function () {
    for (var a; (a = iq(this)); ) jq(this, a, this.A, this.H);
    this.G = !1;
  };
  function jq(a, b, c, d) {
    if (c == 3 && b.B && !b.D) for (; a && a.F; a = a.C) a.F = !1;
    if (b.A) (b.A.C = null), nq(b, c, d);
    else
      try {
        b.D ? b.C.call(b.context) : nq(b, c, d);
      } catch (e) {
        oq.call(null, e);
      }
    Kp(bq, b);
  }
  function nq(a, b, c) {
    b == 2 ? a.C.call(a.context, c) : a.B && a.B.call(a.context, c);
  }
  function mq(a, b) {
    a.F = !0;
    Up(function () {
      a.F && oq.call(null, b);
    });
  }
  var oq = Ma;
  function gq(a) {
    Ga.call(this, a);
    this.A = !1;
  }
  Ea(gq, Ga);
  gq.prototype.name = "cancel"; /*

 Copyright 2005, 2007 Bob Ippolito. All Rights Reserved.
 Copyright The Closure Library Authors.
 SPDX-License-Identifier: MIT
*/
  function pq(a, b) {
    this.H = [];
    this.L = a;
    this.N = b || null;
    this.F = this.C = !1;
    this.B = void 0;
    this.M = this.O = this.J = !1;
    this.I = 0;
    this.A = null;
    this.G = 0;
  }
  p = pq.prototype;
  p.cancel = function (a) {
    if (this.C) this.B instanceof pq && this.B.cancel();
    else {
      if (this.A) {
        let b = this.A;
        delete this.A;
        a ? b.cancel(a) : (b.G--, b.G <= 0 && b.cancel());
      }
      this.L ? this.L.call(this.N, this) : (this.M = !0);
      this.C || this.D(new qq(this));
    }
  };
  p.K = function (a, b) {
    this.J = !1;
    rq(this, a, b);
  };
  function rq(a, b, c) {
    a.C = !0;
    a.B = c;
    a.F = !b;
    sq(a);
  }
  function tq(a) {
    if (a.C) {
      if (!a.M) throw new uq(a);
      a.M = !1;
    }
  }
  p.U = function (a) {
    tq(this);
    rq(this, !0, a);
  };
  p.D = function (a) {
    tq(this);
    rq(this, !1, a);
  };
  p.finally = function (a) {
    return vq(
      new Promise((b, c) => {
        wq(
          this,
          (d) => {
            a();
            b(d);
          },
          (d) => {
            a();
            c(d);
          }
        );
      })
    );
  };
  function wq(a, b, c, d) {
    var e = a.C;
    e || (b === c ? (b = c = Jp(b)) : ((b = Jp(b)), (c = Jp(c))));
    a.H.push([b, c, d]);
    e && sq(a);
  }
  p.then = function (a, b, c) {
    var d,
      e,
      f = new Zp(function (g, h) {
        e = g;
        d = h;
      });
    wq(
      this,
      e,
      function (g) {
        g instanceof qq ? f.cancel() : d(g);
        return xq;
      },
      this
    );
    return f.then(a, b, c);
  };
  pq.prototype.$goog_Thenable = !0;
  pq.prototype.gb = function (a) {
    var b = new pq();
    wq(this, b.U, b.D, b);
    a && ((b.A = this), this.G++);
    return b;
  };
  pq.prototype.isError = function (a) {
    return a instanceof Error;
  };
  function yq(a) {
    return wb(a.H, function (b) {
      return typeof b[1] === "function";
    });
  }
  var xq = {};
  function sq(a) {
    if (a.I && a.C && yq(a)) {
      var b = a.I,
        c = zq[b];
      c && (u.clearTimeout(c.wb), delete zq[b]);
      a.I = 0;
    }
    a.A && (a.A.G--, delete a.A);
    b = a.B;
    for (var d = (c = !1); a.H.length && !a.J; ) {
      var e = a.H.shift(),
        f = e[0];
      let h = e[1];
      e = e[2];
      if ((f = a.F ? h : f))
        try {
          var g = f.call(e || a.N, b);
          g === xq && (g = void 0);
          g !== void 0 &&
            ((a.F = a.F && (g == b || a.isError(g))), (a.B = b = g));
          if (
            Yp(b) ||
            (typeof u.Promise === "function" && b instanceof u.Promise)
          )
            (d = !0), (a.J = !0);
        } catch (k) {
          (b = k), (a.F = !0), yq(a) || (c = !0);
        }
    }
    a.B = b;
    d &&
      ((g = a.K.bind(a, !0)),
      (d = a.K.bind(a, !1)),
      b instanceof pq ? (wq(b, g, d), (b.O = !0)) : b.then(g, d));
    c && ((b = new Aq(b)), (zq[b.wb] = b), (a.I = b.wb));
  }
  function vq(a) {
    var b = new pq();
    a.then(
      function (c) {
        b.U(c);
      },
      function (c) {
        b.D(c);
      }
    );
    return b;
  }
  function uq() {
    Ga.call(this);
  }
  Ea(uq, Ga);
  uq.prototype.message = "Deferred has already fired";
  uq.prototype.name = "AlreadyCalledError";
  function qq() {
    Ga.call(this);
  }
  Ea(qq, Ga);
  qq.prototype.message = "Deferred was canceled";
  qq.prototype.name = "CanceledError";
  function Aq(a) {
    this.wb = u.setTimeout(() => {
      delete zq[this.wb];
      throw this.A;
    }, 0);
    this.A = a;
  }
  var zq = {};
  var Cq = Bq((a) => a.nodeType === 1);
  function Bq(a) {
    var b = globalThis.Element;
    return fd((c) => {
      if (b && c instanceof b) return !0;
      if (c == null) return !1;
      try {
        return a(c);
      } catch {
        return !1;
      }
    });
  } /*

 Copyright 2024 Google, Inc
 SPDX-License-Identifier: MIT
*/
  var Dq = Object.create(null);
  var Eq = ["mouseenter", "mouseleave", "pointerenter", "pointerleave"],
    Fq = ["focus", "blur", "error", "load", "toggle"];
  "click dblclick focusin focusout keydown keyup keypress mouseover mouseout submit touchstart touchend touchmove touchcancel auxclick change compositionstart compositionupdate compositionend beforeinput input select copy cut paste mousedown mouseup wheel contextmenu dragover dragenter dragleave drop dragstart dragend pointerdown pointermove pointerup pointercancel pointerover pointerout gotpointercapture lostpointercapture ended loadedmetadata pagehide pageshow visibilitychange beforematch"
    .split(" ")
    .concat(Fq);
  var Gq =
      typeof navigator !== "undefined" && /Macintosh/.test(navigator.userAgent),
    Hq =
      typeof navigator !== "undefined" &&
      !/Opera/.test(navigator.userAgent) &&
      /WebKit/.test(navigator.userAgent),
    Iq =
      typeof navigator !== "undefined" &&
      !/Opera|WebKit/.test(navigator.userAgent) &&
      /Gecko/.test(navigator.product);
  function Jq(a) {
    if ((a = a.A.eia)) return { name: a[0], element: a[1] };
  }
  var Kq = class {
    constructor(a) {
      this.A = a;
    }
    clone() {
      var a = this.A;
      return new Kq({
        eventType: a.eventType,
        event: a.event,
        targetElement: a.targetElement,
        eic: a.eic,
        eia: a.eia,
        timeStamp: a.timeStamp,
        eirp: a.eirp,
        eiack: a.eiack,
        eir: a.eir,
      });
    }
  };
  var Lq = Object.create(null),
    Mq = /\s*;\s*/,
    Nq = class {
      constructor() {
        ({ Tf: b = !1, ff: a = !0 } = { Tf: !0 });
        var a, b;
        this.ff = !0;
        this.Tf = b;
        this.ff = a;
      }
      B(a) {
        var b;
        if ((b = this.ff && a.eventType === "click"))
          (b = a.event),
            (b =
              (Gq && b.metaKey) ||
              (!Gq && b.ctrlKey) ||
              b.which === 2 ||
              (b.which == null && b.button === 4) ||
              b.shiftKey);
        b && (a.eventType = "clickmod");
      }
      A(a) {
        if (!a.eir) {
          for (var b = a.targetElement; b && b !== a.eic; ) {
            if (b.nodeType === Node.ELEMENT_NODE) {
              var c = b,
                d = a,
                e = c.__jsaction;
              if (!e) {
                var f = c.getAttribute("jsaction");
                if (f) {
                  if (((e = Dq[f]), !e)) {
                    e = Object.create(null);
                    var g = f.split(Mq);
                    for (let k = 0; k < g.length; k++) {
                      var h = g[k];
                      if (!h) continue;
                      let l = h.indexOf(":"),
                        m = l !== -1,
                        n = m ? h.substr(0, l).trim() : "click";
                      h = m ? h.substr(l + 1).trim() : h;
                      e[n] = h;
                    }
                    Dq[f] = e;
                  }
                } else e = Lq;
                c.__jsaction = e;
              }
              e = e[d.eventType];
              e !== void 0 && (d.eia = [e, c]);
            }
            if (a.eia) break;
            a: {
              if ((c = b.__owner)) {
                b = c;
                break a;
              }
              b = b.parentNode;
              b = b?.nodeName === "#document-fragment" ? b?.host ?? null : b;
            }
          }
          if (
            (b = a.eia) &&
            this.Tf &&
            (a.eventType === "mouseenter" ||
              a.eventType === "mouseleave" ||
              a.eventType === "pointerenter" ||
              a.eventType === "pointerleave")
          )
            if (
              ((c = a.event),
              (d = a.eventType),
              (e = b[1]),
              (f = c.relatedTarget),
              !(
                (c.type === "mouseover" && d === "mouseenter") ||
                (c.type === "mouseout" && d === "mouseleave") ||
                (c.type === "pointerover" && d === "pointerenter") ||
                (c.type === "pointerout" && d === "pointerleave")
              ) ||
                (f && (f === e || e.contains(f))))
            )
              a.eia = void 0;
            else {
              c = a.event;
              d = b[1];
              e = {};
              for (let k in c) {
                if (k === "srcElement" || k === "target") continue;
                f = k;
                g = c[f];
                typeof g !== "function" && (e[f] = g);
              }
              e.type =
                c.type === "mouseover"
                  ? "mouseenter"
                  : c.type === "mouseout"
                  ? "mouseleave"
                  : c.type === "pointerover"
                  ? "pointerenter"
                  : "pointerleave";
              e.target = e.srcElement = d;
              e.bubbles = !1;
              e._originalEvent = c;
              a.event = e;
              a.targetElement = b[1];
            }
          a.eir = !0;
        }
      }
    };
  function Oq(a, b) {
    a: {
      if (typeof window.Event === "function")
        try {
          var c = new Event(a, { bubbles: !1, cancelable: !0 });
          break a;
        } catch (d) {}
      c = document.createEvent("Event");
      c.initEvent(a, !1, !0);
    }
    a = c;
    a.X = b;
    return a;
  }
  function Pq() {
    try {
      if (typeof window.EventTarget === "function") return new EventTarget();
    } catch (a) {}
    try {
      return document.createElement("div");
    } catch (a) {}
    return null;
  }
  function Qq(a) {
    return new Rq(
      Jq(a)?.name ?? "",
      Jq(a)?.element ?? null,
      a.A.event,
      a.A.timeStamp,
      a.A.eventType,
      a.A.targetElement
    );
  }
  function Sq(a, b = Qq) {
    return function (c) {
      c = b(c);
      a.call(this, c);
      c.done("main-actionflow-branch");
    };
  }
  function Tq(a, b, c, d) {
    if (Uq) {
      var e = Oq("error", a);
      e.error = b;
      e.gb = c;
      e.Fa = d;
      e.finished = a.G;
      Uq.dispatchEvent(e);
    }
  }
  function Vq(a) {
    if (!Uq) return !0;
    if (a.aa) {
      var b = Oq("abandoned", a);
      a.C.dispatchEvent(b);
      Uq.dispatchEvent(b);
      return !0;
    }
    var c = (b = "");
    for (var d in a.P) a.P.hasOwnProperty(d) && ((c = c + b + d), (b = "|"));
    c && (a.D.dup = c);
    b = Oq("beforedone", a);
    if (!a.C.dispatchEvent(b) || !Uq.dispatchEvent(b)) return !1;
    c = a.D;
    b = [];
    for (let [e, f] of Object.entries(c))
      (d = f),
        (c = encodeURIComponent(e)),
        (d = encodeURIComponent(d).replace(/%7C/g, "|")),
        b.push(c + ":" + d);
    (b = b.join(",")) && (a.H.cad = b);
    a = Oq("done", a);
    return Uq.dispatchEvent(a);
  }
  function Wq(a, b, c) {
    a.G && Tq(a, "extradata");
    a.D[b] = c.toString().replace(/[:;,\s]/g, "_");
  }
  var Rq = class {
      constructor(a, b, c, d, e, f, g = !1) {
        this.C = Pq();
        this.W = [];
        this.T = {};
        this.B = new Map();
        this.P = {};
        this.G = !1;
        this.H = {};
        this.D = {};
        this.Z = this.aa = !1;
        this.ka = () => Date.now();
        this.N = a.replace(Xq, "_");
        this.ga = a;
        this.F = b || null;
        this.hb = c || null;
        this.sa = e || null;
        this.L = f || null;
        !this.L &&
          c &&
          c.target &&
          c.target.nodeType === Node.ELEMENT_NODE &&
          (this.L = c.target);
        g
          ? ((this.ka = () => performance.now()),
            (this.J = d !== void 0 ? d : this.ka()))
          : (this.J = d || this.ka());
        this.ea = this.J;
        this.B.set("main-actionflow-branch", 1);
        c && b && c.type === "click" && this.action(b);
        Yq.push(this);
        this.wb = ++Zq;
        a = Oq("created", this);
        Uq != null && Uq.dispatchEvent(a);
      }
      id() {
        return this.wb;
      }
      K() {
        this.aa = !0;
      }
      Ie() {
        return this.J;
      }
      I(a) {
        this.N = a.replace(Xq, "_");
        this.ga = a;
      }
      Fa(a, b) {
        this.G && Tq(this, "tick", void 0, a);
        b = b ?? {};
        a in this.T && (this.P[a] = !0);
        var c = b.time || this.ka();
        !b.Xh && !b.Yi && c > this.ea && (this.ea = c);
        for (
          var d = c - this.J, e = this.W.length;
          e > 0 && this.W[e - 1][1] > d;

        )
          e--;
        this.W.splice(e, 0, [a, d, b.Xh]);
        this.T[a] = c;
      }
      done(a, b, c) {
        var d = this.B.get(a);
        this.G || d === void 0
          ? Tq(this, "done", a, b)
          : (b && this.Fa(b, c),
            d--,
            this.B.set(a, d),
            d === 0 && this.B.delete(a),
            this.B.size === 0 &&
              Vq(this) &&
              ((this.G = !0),
              (a = Yq.indexOf(this)),
              a !== -1 && Yq.splice(a, 1),
              (this.L = this.hb = this.F = null),
              (this.C = Pq()),
              (this.Z = !0)));
      }
      M() {
        return this.Z;
      }
      gb(a, b, c) {
        this.G && Tq(this, "branch", a, b);
        b && this.Fa(b, c);
        b = this.B.get(a) ?? 0;
        b++;
        this.B.set(a, b);
      }
      branches() {
        return this.B;
      }
      action(a) {
        this.G && Tq(this, "action");
        var b = [],
          c = null,
          d = null,
          e = null,
          f = null;
        $q(a, (g) => {
          var h;
          !g.__oi &&
            g.getAttribute &&
            (g.__oi = g.getAttribute("oi") ?? void 0);
          if ((h = g.__oi))
            b.unshift(h), c || (c = g.getAttribute("jsinstance"));
          e || (d && d !== "1") || (e = g.getAttribute("ved"));
          f || (f = g.getAttribute("vet"));
          d || (d = g.getAttribute("jstrack"));
        });
        f && (this.H.vet = f);
        d &&
          ((this.H.ct = this.N),
          b.length > 0 && Wq(this, "oi", b.join(".")),
          c &&
            ((a = c.charAt(0) === "*" ? Number(c.slice(1)) : Number(c)),
            (this.H.cd = a)),
          d !== "1" && (this.H.ei = d),
          e && (this.H.ved = e));
      }
      flowType() {
        return this.ga;
      }
      U(a, b, c, d) {
        this.gb(b, c);
        var e = this;
        return function (...f) {
          try {
            return a.call(this, ...f);
          } finally {
            e.done(b, d);
          }
        };
      }
      node() {
        return this.F;
      }
      event() {
        return this.hb;
      }
      eventType() {
        return this.sa;
      }
      target() {
        return this.L;
      }
      value(a) {
        if (this.F) {
          if (a in this.F) return this.F[a];
          if (this.F.getAttribute) return this.F.getAttribute(a);
        }
      }
    },
    Yq = [],
    Uq = Pq();
  function $q(a, b) {
    for (; a && a.nodeType === Node.ELEMENT_NODE; a = a.parentNode) b(a);
  }
  var Xq = /[~.,?&-]/g,
    Zq = 0;
  function ar(a, b) {
    a.B.push(b);
    a.A ||
      ((a.A = !0),
      Promise.resolve().then(() => {
        a.A = !1;
        a.Xb(a.B);
      }));
  }
  var br = class {
    constructor(a, { qd: b, Xb: c } = {}) {
      this.C = a;
      this.A = !1;
      this.B = [];
      this.qd = b;
      this.Xb = c;
    }
  };
  var cr = class {
    constructor(a) {
      this.element = a;
      this.A = [];
    }
    addEventListener(a, b, c) {
      var d = this.A,
        e = d.push,
        f = this.element;
      b = b(this.element);
      var g = !1;
      Fq.indexOf(a) >= 0 && (g = !0);
      f.addEventListener(
        a,
        b,
        typeof c === "boolean" ? { capture: g, passive: c } : g
      );
      e.call(d, { eventType: a, handler: b, capture: g, passive: c });
    }
    sd() {
      for (let c = 0; c < this.A.length; c++) {
        var a = this.element,
          b = this.A[c];
        a.removeEventListener
          ? a.removeEventListener(
              b.eventType,
              b.handler,
              typeof b.passive === "boolean"
                ? { capture: b.capture }
                : b.capture
            )
          : a.detachEvent && a.detachEvent(`on${b.eventType}`, b.handler);
      }
      this.A = [];
    }
  };
  function dr(a, b) {
    for (let c = 0; c < a.C.length; c++) a.C[c](b);
  }
  function er(a) {
    var b = [...a.B, ...a.A],
      c = [],
      d = [];
    for (var e = 0; e < a.A.length; ++e) {
      var f = a.A[e];
      fr(f, b) ? (c.push(f), f.sd()) : d.push(f);
    }
    for (e = 0; e < a.B.length; ++e)
      (f = a.B[e]), fr(f, b) ? c.push(f) : (d.push(f), dr(a, f));
    a.A = d;
    a.B = c;
  }
  var gr = class {
    constructor() {
      this.stopPropagation = !1;
      this.A = [];
      this.B = [];
      this.C = [];
    }
    addEventListener(a, b, c) {
      for (let d = 0; d < this.A.length; d++)
        this.A[d].addEventListener(a, b, c);
      this.C.push((d) => {
        d.addEventListener(a, b, c);
      });
    }
    sd() {
      var a = [...this.A, ...this.B];
      for (let b = 0; b < a.length; b++) a[b].sd();
      this.A = [];
      this.B = [];
      this.C = [];
    }
  };
  function fr(a, b) {
    for (let c = 0; c < b.length; ++c)
      if (hr(b[c].element, a.element)) return !0;
    return !1;
  }
  function hr(a, b) {
    if (a === b) return !1;
    for (; a !== b && b.parentNode; ) b = b.parentNode;
    return a === b;
  }
  function ir(a, b) {
    a.la ? a.la(b) : ((b.eirp = !0), a.A?.push(b));
  }
  function jr(a, b) {
    if (!(b in a.B || !a.C || Eq.indexOf(b) >= 0)) {
      var c = (e, f, g) => {
        a.handleEvent(e, f, g);
      };
      a.B[b] = c;
      var d =
        b === "mouseenter"
          ? "mouseover"
          : b === "mouseleave"
          ? "mouseout"
          : b === "pointerenter"
          ? "pointerover"
          : b === "pointerleave"
          ? "pointerout"
          : b;
      if (d !== b) {
        let e = a.D[d] || [];
        e.push(b);
        a.D[d] = e;
      }
      a.C.addEventListener(
        d,
        (e) => (f) => {
          c(b, f, e);
        },
        void 0
      );
    }
  }
  var kr = class {
    constructor(a) {
      this.B = {};
      this.D = {};
      this.la = null;
      this.A = [];
      this.C = a;
    }
    handleEvent(a, b, c) {
      var d = b.target,
        e = Date.now();
      ir(this, {
        eventType: a,
        event: b,
        targetElement: d,
        eic: c,
        timeStamp: e,
        eia: void 0,
        eirp: void 0,
        eiack: void 0,
      });
    }
    handler(a) {
      return this.B[a];
    }
    sd() {
      this.C?.sd();
      this.C = null;
      this.B = {};
      this.D = {};
      this.la = null;
      this.A = [];
    }
    ecrd(a) {
      this.la = a;
      if (this.A?.length) {
        for (a = 0; a < this.A.length; a++) ir(this, this.A[a]);
        this.A = null;
      }
    }
  };
  function lr(a) {
    !a.B &&
      a.Xb &&
      a.A?.length &&
      ((a.B = !0),
      Promise.resolve().then(() => {
        a.B = !1;
        a.Xb(a.A, a);
      }));
  }
  var nr = class {
    constructor() {
      ({
        qd: d,
        Xb: c,
        stopPropagation: b = !1,
        kg: a = !1,
      } = { qd: new Nq(), stopPropagation: !1 });
      var a, b, c, d;
      this.actions = {};
      this.C = new Map();
      this.B = !1;
      this.Xb = c;
      this.la = new br(
        (e) => {
          if (this.C.size) {
            var f = e.clone();
            f.A.eventType === "clickonly" && (f.A.eventType = "click");
            var g = f.A.event;
            f = this.C.get(f.A.eventType);
            let h = !1;
            if (f) for (let k of f) k(g) === !1 && (h = !0);
            h && (g.preventDefault ? g.preventDefault() : (g.returnValue = !1));
          }
          this.kg && mr(e);
          if ((g = Jq(e)))
            this.stopPropagation && mr(e),
              (g = this.actions[g.name]) ? g(e) : this.A?.push(e);
        },
        {
          qd: d,
          Xb: (e) => {
            this.A = e;
            this.Xb?.(this.A, this);
          },
        }
      );
      this.stopPropagation = b;
      this.kg = a;
    }
    re(a, b) {
      delete this.actions[a ? a + "." + b : b];
    }
  };
  function mr(a) {
    if (
      !Iq ||
      (a.A.targetElement.tagName !== "INPUT" &&
        a.A.targetElement.tagName !== "TEXTAREA") ||
      a.A.eventType !== "focus"
    )
      (a = a.A.event), a.stopPropagation && a.stopPropagation();
  }
  function or(a, b) {
    a.ecrd((c) => {
      var d = b.la,
        e = new Kq(c);
      d.qd?.B(c);
      d.qd?.A(c);
      !(c = Jq(e)) ||
        c.element.tagName !== "A" ||
        (e.A.eventType !== "click" && e.A.eventType !== "clickmod") ||
        ((c = e.A.event),
        c.preventDefault ? c.preventDefault() : (c.returnValue = !1));
      d.Xb && e.A.eirp ? ar(d, e) : d.C(e);
    }, 0);
  }
  function pr(a, b) {
    if (document.createEvent) {
      var c = document.createEvent("KeyboardEvent");
      c.initKeyboardEvent
        ? (c.initKeyboardEvent(
            b || a.type,
            !0,
            !0,
            window,
            a.key,
            a.location,
            a.ctrlKey,
            a.altKey,
            a.shiftKey,
            a.metaKey
          ),
          Object.defineProperty(c, "repeat", {
            get: () => a.repeat,
            enumerable: !0,
          }),
          Object.defineProperty(c, "locale", {
            get: () => a.locale,
            enumerable: !0,
          }),
          Hq &&
            a.key &&
            c.key === "" &&
            Object.defineProperty(c, "key", {
              get: () => a.key,
              enumerable: !0,
            }),
          Object.defineProperty(c, "charCode", {
            get: () => a.charCode,
            enumerable: !0,
          }),
          (b = () => a.keyCode),
          Object.defineProperty(c, "keyCode", { get: b, enumerable: !0 }),
          Object.defineProperty(c, "which", { get: b, enumerable: !0 }))
        : c.initKeyEvent(
            b || a.type,
            !0,
            !0,
            window,
            a.ctrlKey,
            a.altKey,
            a.shiftKey,
            a.metaKey,
            a.keyCode,
            a.charCode
          );
    } else
      (c = document.createEventObject()),
        (c.type = b || a.type),
        (c.repeat = a.repeat),
        (c.ctrlKey = a.ctrlKey),
        (c.altKey = a.altKey),
        (c.shiftKey = a.shiftKey),
        (c.metaKey = a.metaKey),
        (c.key = a.key),
        (c.keyCode = a.keyCode),
        (c.charCode = a.charCode);
    c.Me = a.timeStamp;
    return c;
  }
  new Uint8Array(123);
  var qr = {},
    rr = {};
  function sr() {
    throw Error("Do not instantiate directly");
  }
  sr.prototype.A = null;
  sr.prototype.Ia = function () {
    return this.content;
  };
  sr.prototype.toString = function () {
    return this.content;
  };
  sr.prototype.gh = function () {
    if (this.gf !== qr) throw Error("Sanitized content was not of kind HTML.");
    return Mn(this.toString());
  };
  function tr() {
    sr.call(this);
  }
  Ea(tr, sr);
  tr.prototype.gf = qr;
  var ur = (function (a) {
    function b(c) {
      this.content = c;
    }
    b.prototype = a.prototype;
    return function (c, d) {
      c = new b(String(c));
      d !== void 0 && (c.A = d);
      return c;
    };
  })(tr);
  function vr(a) {
    return wr(String(a), () => "").replace(xr, "&lt;");
  }
  var yr = RegExp.prototype.hasOwnProperty("sticky"),
    zr = new RegExp(
      (yr ? "" : "^") + "(?:!|/?([a-zA-Z][a-zA-Z0-9:-]*))",
      yr ? "gy" : "g"
    );
  function wr(a, b) {
    for (var c = [], d = a.length, e = 0, f = [], g, h, k = 0; k < d; ) {
      switch (e) {
        case 0:
          var l = a.indexOf("<", k);
          if (l < 0) {
            if (c.length === 0) return a;
            c.push(a.substring(k));
            k = d;
          } else
            c.push(a.substring(k, l)),
              (h = l),
              (k = l + 1),
              yr
                ? ((zr.lastIndex = k), (l = zr.exec(a)))
                : ((zr.lastIndex = 0), (l = zr.exec(a.substring(k)))),
              l
                ? ((f = ["<", l[0]]), (g = l[1]), (e = 1), (k += l[0].length))
                : c.push("<");
          break;
        case 1:
          l = a.charAt(k++);
          switch (l) {
            case "'":
            case '"':
              let m = a.indexOf(l, k);
              m < 0 ? (k = d) : (f.push(l, a.substring(k, m + 1)), (k = m + 1));
              break;
            case ">":
              f.push(l);
              c.push(b(f.join(""), g));
              e = 0;
              f = [];
              h = g = null;
              break;
            default:
              f.push(l);
          }
          break;
        default:
          throw Error();
      }
      e === 1 &&
        k >= d &&
        ((k = h + 1), c.push("<"), (e = 0), (f = []), (h = g = null));
    }
    return c.join("");
  }
  function Ar(a, b) {
    a = a.replace(/<\//g, "<\\/").replace(/\]\]>/g, "]]\\>");
    return b
      ? a
          .replace(/{/g, " \\{")
          .replace(/}/g, " \\}")
          .replace(/\/\*/g, "/ *")
          .replace(/\\$/, "\\ ")
      : a;
  }
  function Br(a) {
    a != null && a.gf === qr
      ? ((a = vr(a.Ia())), (a = String(a).replace(Cr, Dr)))
      : (a = String(a).replace(Ir, Dr));
    return a;
  }
  var Kr = {
    "\x00": "&#0;",
    "\t": "&#9;",
    "\n": "&#10;",
    "\v": "&#11;",
    "\f": "&#12;",
    "\r": "&#13;",
    " ": "&#32;",
    '"': "&quot;",
    "&": "&amp;",
    "'": "&#39;",
    "-": "&#45;",
    "/": "&#47;",
    "<": "&lt;",
    "=": "&#61;",
    ">": "&gt;",
    "`": "&#96;",
    "\u0085": "&#133;",
    "\u00a0": "&#160;",
    "\u2028": "&#8232;",
    "\u2029": "&#8233;",
  };
  function Dr(a) {
    return Kr[a];
  }
  var Ir = /[\x00\x22\x26\x27\x3c\x3e]/g,
    Cr = /[\x00\x22\x27\x3c\x3e]/g,
    xr = /</g;
  var Lr = class extends S {
    constructor(a) {
      super(a);
    }
  };
  Si[15872052] = [
    0,
    pi,
    -1,
    2,
    pi,
    -4,
    ti,
    pi,
    ri,
    [0, Wi, ni],
    pi,
    [0, qi, pi],
    pi,
  ];
  var Mr = class extends S {
      constructor(a) {
        super(a);
      }
    },
    Nr = [1, 3, 4],
    Or = [2, 5];
  function Pr(a) {
    return A(a, Mr, 1);
  }
  var Qr = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Rr = class extends S {
    constructor(a) {
      super(a);
    }
    Oa() {
      return Ff(this, 1);
    }
    va() {
      return E(this, 2);
    }
  };
  var Sr = class extends S {
    constructor(a) {
      super(a, 233);
    }
    fd(a) {
      R(this, 6, a);
    }
  };
  var Tr = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function Ur(a) {
    return E(a, 1);
  }
  function Vr(a) {
    return E(a, 2);
  }
  var Wr = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Xr = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Yr = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var Zr = {
    ar: "latn",
    "ar-EG": "arab",
    bn: "beng",
    fa: "arabext",
    mr: "deva",
    my: "mymr",
    ne: "deva",
  };
  typeof Intl !== "undefined" &&
    typeof Intl.NumberFormat !== "undefined" &&
    Intl.NumberFormat.supportedLocalesOf(["en".replace("_", "-")]);
  function $r(a, b) {
    b &&
      as(b, (c) => {
        a[c] = b[c];
      });
  }
  function as(a, b) {
    if (a) for (let c in a) a.hasOwnProperty(c) && b(c, a[c]);
  }
  function bs(a) {
    if (a && a.prototype)
      for (let b of Object.getOwnPropertyNames(a.prototype)) {
        let c = Object.getOwnPropertyDescriptor(a.prototype, b);
        c && Object.defineProperty(a.prototype, b, { ...c, enumerable: !0 });
      }
  }
  var cs = class {
    constructor(a, b, c, d) {
      this.tg(a, b, c, d);
    }
    tg(a, b) {
      this.width = a;
      this.height = b;
    }
    toString() {
      return `(${this.width}, ${this.height})`;
    }
    equals(a) {
      return a ? a.width === this.width && a.height === this.height : !1;
    }
  };
  cs.prototype.equals = cs.prototype.equals;
  cs.prototype.toString = cs.prototype.toString;
  cs.prototype.constructor = cs.prototype.constructor;
  (function (a) {
    if (a && a.prototype) {
      var b = (c, d) => {
        var e = a.prototype.tg;
        if (typeof e === "function") return e.apply(c, d);
        throw Error("you must define a constructor_");
      };
      Object.defineProperty(a, "call", {
        value(c, ...d) {
          return this !== a
            ? Function.prototype.call.apply(this, [c, ...d])
            : b(c, d);
        },
        enumerable: !1,
        writable: !0,
        configurable: !0,
      });
      Object.defineProperty(a, "apply", {
        value(c, d) {
          return this !== a
            ? Function.prototype.apply.apply(this, [c, d])
            : b(c, d);
        },
        enumerable: !1,
        writable: !0,
        configurable: !0,
      });
      Object.defineProperty(a, "bind", {
        value(c, ...d) {
          function e(...g) {
            g = d.concat(g);
            return this instanceof e ? new f(...g) : b(c, g);
          }
          if (this !== a) return Function.prototype.bind.apply(this, [c, ...d]);
          var f = this;
          f.prototype && (e.prototype = f.prototype);
          return e;
        },
        enumerable: !1,
        writable: !0,
        configurable: !0,
      });
      bs(a);
    }
  })(cs);
  function ds(a) {
    return C(a, 3);
  }
  var es = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function fs(a) {
    return E(a, 1);
  }
  function gs(a) {
    return E(a, 2);
  }
  var hs = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function is(a) {
    return E(a, 3);
  }
  var js = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function ks(a) {
    return B(a, js, 1);
  }
  function ls(a) {
    return B(a, es, 3);
  }
  var ms = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function ns(a, b) {
    a = A(a.A, js, 1);
    Q(a, 5, b);
  }
  function os(a, b) {
    a = A(a.A, js, 1);
    Af(a, 2, ce, b, void 0, ee);
  }
  function ps(a, b) {
    a = A(a.A, js, 1);
    Af(a, 4, ce, b, void 0, ee);
  }
  function qs(a) {
    a = A(a.A, es, 3);
    M(a, 2, !0);
  }
  function rs(a, b) {
    Q(a.B, 1, b);
  }
  function ss(a, b) {
    Q(a.B, 2, b);
  }
  function ts(a, b) {
    a = A(a.A, Ck, 8);
    a = A(a, Bk, 1);
    M(a, 1, b);
  }
  var us = class {
    constructor() {
      this.C = null;
      var a = new ms();
      this.A = R(a, 4, 98);
      this.B = new mk();
    }
  };
  function vs(a, b) {
    a.F = b;
  }
  function ws(a) {
    return a.headers ? new Map(a.headers) : new Map();
  }
  var xs = class {
    constructor() {
      this.status = 0;
      this.priority = 2;
      this.B = 0;
      this.F = this.D = this.headers = this.methodName = null;
    }
    C(a) {
      this.D = a;
    }
    cancel() {
      if (this.status === 3) return !1;
      var a = !1;
      this.D !== null && (a = this.D()) && (this.status = 3);
      return a;
    }
    start(a) {
      if (this.status !== 0)
        throw Error("Trying to reuse an Rpc object. Status is not INACTIVE");
      this.status = 1;
      this.methodName = a;
    }
    done() {}
    A(a) {
      if (a === 0) throw Error("Trying to set the Rpc status to INACTIVE.");
      this.status = a;
    }
    clone() {
      var a = new xs();
      a.priority = this.priority;
      this.headers && (a.headers = new Map(this.headers));
      return a;
    }
  };
  var ys = class {
    constructor(a, b = null) {
      this.B = a;
      this.A = b;
    }
    send(a, b, c, d) {
      var e = new AbortController();
      d?.C(() => {
        e.abort();
        return !0;
      });
      var f = {
        "Content-Type": "application/json+protobuf",
        Accept: "application/json+protobuf",
      };
      if (d) for (let [g, h] of ws(d)) f[g] = h;
      this.A && (f["X-Goog-Api-Key"] = this.A);
      fetch(this.B, { method: "POST", headers: f, body: a, signal: e.signal })
        .then(async (g) => {
          g.ok ? b(await g.text()) : d?.A(2);
        })
        .catch((g) => {
          g?.name !== "AbortError" && d?.A(2);
        })
        .finally(() => {
          c?.();
        });
    }
  };
  var zs = xp`:root{--t4e3d42d0a1a9e6ca:initial;--td1001393b8945945:initial;--te03d8b6ec525f4b4:initial;--td2e4807cf9d242fe:initial;--t8c8a085cbf3648e0:initial;--t0a540ae3945f2d07:initial;--t66846006bf68c475:initial;--t622c19e8720f65de:initial;--t29584690f8dcb93a:initial;--t2a70666c74ec8d23:initial;--tcc644d3307983d6f:initial;--t6b235b10f5441e2d:initial;--t7a2f2236f53dd54a:initial;--t524e980fd5a66932:initial;--tb509833b3596d641:initial;--t0ef0926f27183a78:initial;--t9c92cbe8e92b79f4:initial;--ta07625c1122320df:initial;--ta2dfb4f47e5932f8:initial;--t8645f1bbfdc95dc0:initial;--t344a5c79f987dc73:initial;--tadd8d54aafe1b344:initial;--ta37b7cf1c497b2de:initial;--tfd29a9b34dcb458b:initial;--tb81c324d0370f7c6:initial;--t3b9f79904082dd00:initial;--t28426e2f5105e2b7:initial;--t908fc5484ed1452d:initial;--t84759c146a624695:initial;--t8367495db485c986:initial;--t5bfded1f61a6f516:initial;--td4bf447d66e7cd1d:initial;--tdf8c25468ef22140:initial;--t0e411425009a5c7e:initial;--t270c498122f5f3cd:initial;--tfa23e99dd7e643db:initial;--t2942d6aa7b83263f:initial;--t30ed7c1450be5af4:initial;--tbf5eb2ddc9a4fa65:initial;--tbaeb7e465259e75e:initial;--tce71f9556eb3b332:initial;--t3c7d8bbf1a8f2de4:initial;--t72293e98cdbf820b:initial;--t5c15aef36210bfe4:initial;--t344dfe0a85df5945:initial;--t0e0ee499b6b703da:initial;--t58e7d324a9d53283:initial;--t6ed8b1e93395a38d:initial;--tbf78ca7905ed4365:initial;--tf5ca1f85df12555b:initial;--t7e308d9d65efea7b:initial;--t2477c147f43096ae:initial;--t5cd2aeae6e5bd293:initial;--t7cbb7697b854692b:initial;--tef6d873f82956433:initial;--tebfbbb84f6b5e5b9:initial;--t6f2ea937da3762cd:initial;--td7c9881a4de36976:initial;--t7ab10821a9a38e07:initial;--tc93164b705392ee5:initial;--tebe6837248261a41:initial;--t3cdbe5bd7a07bede:initial;--t33ec501ef7aa1732:initial;--ta2a4ee4913f8a956:initial;--tab8534ef038aa0fa:initial;--t329638ef3d6ac919:initial;--t0a57a7ae4a33205c:initial;--tf7b40ad5c33244a6:initial;--t4d7e5b15f70139ef:initial;--t5d3b44cda28eaae1:initial;--t2c09520dc82dd8ed:initial;--tf78a03b52584613a:initial;--t5431ff9f1b333bcb:initial;--t22f58786b305bb6f:initial;--t2c6b3f4a99d7dd0b:initial;--t7839770d085b0b4d:initial;--t20e68aae27bed1ec:initial;--t888e1f62a94fdfae:initial;--t03d5eac9e8805344:initial;--tf38af22da2d552cb:initial;--tbfa623749bc8ac63:initial;--t806705902cda9388:initial;--t3ff8f9c93a56e733:initial;--t6157b9e200214dc9:initial;--t3a6553fda362956d:initial;--t15dcf3f93013a7ba:initial;--t94b72732466dbe30:initial;--tbb6c6b1b67f1ea5b:initial;--t7d3d717014590bb4:initial;--tdb59c0d44b2c69d6:initial;--t29a1ef30e579e6cb:initial;--te6f6cc1890fc4750:initial;--t832b84df26af6b12:initial;--t1c2557ed89674134:initial;--t33fcf8ae37f90872:initial;--t1dcccc4783e03e58:initial;--t916e4a7c47841e29:initial;--t8caff653df19629d:initial;--tc9e053af0343ea61:initial;--tb1ade73813c5e5ab:initial;--t0ec7a441bb5a34a6:initial;--t895159822cfc2ce5:initial;--tedd4db81d8bfcdb5:initial;--t2705489ebda31200:initial;--t382c2497976842f2:initial;--t1fe22d166875c35c:initial;--td02fc481451ef23c:initial;--t881cbebb7adf5db0:initial;--tfb0dc11cd41c7f49:initial;--t2daff0a373a361c3:initial;--tbf59280e7a6fcdf8:initial;--tbd69399f0f8015a1:initial;--ta5d6273186b55186:initial;--t25f96c26aad1c4f5:initial;--t108960aded2e62ae:initial;--t98921a3982848eb6:initial;--t8d27b349c95af44f:initial;--t2479ef2801297ce3:initial;--tf218f0cc8e564d7f:initial;--t50a1bf18f0c0392e:initial;--t4c3944ad81a8306d:initial;--te31660884ed46aab:initial;--t32958dd10f7d51af:initial;--t6accc05ac5bb1eff:initial;--t39332736badf4674:initial;--t680aad4497de86ae:initial;--t09d6b33fb13e8489:initial;--t74eb8d880ffc4bda:initial;--t9538fb1696e0a87a:initial;--tf23240eac0acfe84:initial;--t85c4f3a1ab62d94b:initial;--t51c8a96db826900c:initial;--t64f93b81c040e696:initial;--t5493784bc9f378c6:initial;--tde5d76ec8087e7e2:initial;--t8381ad5c2791d681:initial;--t12e0ff1aa954deeb:initial;--t3c7ee2a099a3da6c:initial;--td1ec171a5620a099:initial;--taf2e1ae79348bf2d:initial;--td3ee4c6eb1412b23:initial;--tf7190799071fff3f:initial;--t0beb9a03e2919455:initial;--td08f1f6dec0ac9b1:initial;--tbc971ffe578c918f:initial;--tde4b64446584d028:initial;--tf9dddf7f9e256c99:initial;--t1e3a072f8335ea15:initial;--te90d0950735a8177:initial;--t7cb1742d240eaa32:initial;--tea441ddbe31f0a67:initial;--t8246a2c15373589e:initial;--t6b7fda0e753911b3:initial;--tb9aa52784c619862:initial;--tb10dc9bc98c4440d:initial;--tec22d4c0c9e34788:initial;--te9868d04f1ba663a:initial;--te2f460535a256ffb:initial;--t29ee2da8c1217fb0:initial;--t2ffbb8c3b9cb6cb4:initial;--t468f653057de2dd9:initial;--tfb93870d7246d03c:initial;--t45989b3bcb22f6dd:initial;--t70990749324aca36:initial;--t6d2d91747ffc3f98:initial;--tf7e68e6518cfb3cc:initial;--te229be082e76b81b:initial;--t80e95d977575c16d:initial;--td7c27d8d43c16adb:initial;--t911c2f2ec5ab6c20:initial;--tc73672f34cfb180b:initial;--t7cd2876824e097f2:initial;--t4fe77dafd31bfb98:initial;--t7d1d42f5691a8438:initial;--t166dc8aff19b05cb:initial;--t1af7f8e47944be24:initial;--t82e9122c96d66a2a:initial;--t7a02f642ed355e6e:initial;--t53591bcb459ac6e9:initial;--t6577d7e18cd5bac8:initial;--tf226f3b63d749ba6:initial;--td2d005592644aac8:initial;--t30866cc32fb8f0d4:initial;--t5b35d265ba7ac78d:initial;--t931ee5ce260d19db:initial;--tc27c69e8e46c24f5:initial;--tb2e91b152a81751d:initial;--tef2dc00b8eacd690:initial;--t8ea1fa7fe56354ca:initial;--t94c50809ac36a350:initial;--t13c17fdd6d8a204d:initial;--te999551fb577f524:initial;--tc9342584118b414f:initial;--taa4be36ff7059379:initial;--te19953ebfa2de95c:initial;--te604cf7481f2624c:initial;--tf823bcfc551a96f8:initial;--t5a016e9598bab160:initial;--tbdea95f4163b6088:initial;--tca65991886314e6d:initial;--td5b9bf5019ef3617:initial;--t6c50fcfef830dda7:initial;--t2b2c2cc3fcd67f17:initial;--t34674b112dad6cd5:initial;--tcb58cd0a504642de:initial;--t11336075c072d328:initial;--t81d73f3e2698edd8:initial;--t9b543197ec3917e2:initial;--tc7e4ba9ee853bd99:initial;--t078ee833758ebce6:initial;--t6fd6e48dae1ae2e2:initial;--t9347c1ebf94d8478:initial;--t23818a9024c565e2:initial;--t80a4b4f3e6b468ad:initial;--t76852ee77be24891:initial;--td631f0d3538c6f97:initial;--tc3fb034f8f2e92a2:initial;--te19a65a4756532a5:initial;--t40d1263a5dc0889f:initial;--td72dfbc38f12f498:initial;--ta5e06f0a3067baf1:initial;--tbd9462f131dcad83:initial;--t904406aa11d5ebf4:initial;--te834e28df623be34:initial;--t73b7020e81229b0a:initial;--t6164bcb4f003f424:initial;--t0958a77938946e20:initial;--te42e91b8f2702402:initial;--t82d4faf5b8de0d38:initial;--t2dcce6feebcd219f:initial;--t0c47b322a3909892:initial;--t5ea3ccb33b0ee9c7:initial;--tb4cdd2c94a4c9a33:initial;--t717d8b6eefbfa496:initial;--tc6ee8d8a2d446b92:initial;--t8ec3c193aa3b7831:initial;--tcd55c1964be9fe0d:initial;--ta5a393794e2fa954:initial;--t49292eb1708b1f59:initial;--t8f1974bad8d4fc1f:initial;--t7a4ab0db3fc8475f:initial;--t470baf93bb372c85:initial;--t6bbc2e3f295d4d68:initial;--t77c709c5fff4170a:initial;--t6f1a0e4484ff70e2:initial;--t71aabfa274e23783:initial;--t74616a278b5afe91:initial;--t8583f71512bf0910:initial;--tadac3bcc408f4c35:initial;--t60c6ecba48313128:initial;--t8dca291271aac8f7:initial;--ted93aa1a9bd66491:initial;--t6def6ae5608c97fc:initial;--t39bd715aad1b7b31:initial;--t8e80fd2021b6ae59:initial;--tf3d4da13ad0ad197:initial;--t78a3a8759959b01e:initial;--t454e395cbd7ea4f5:initial;--t82076a04482f6e88:initial;--t705040f1a4491b34:initial;--t3b1a8edba0a7fa29:initial;--tb9bf71293c713114:initial;--t09dc9f6d9d326b58:initial;--t6aee1f0766d1fd0d:initial;--tefa903b07f53b504:initial;--t31c4f1e53de20e9a:initial;--tcdb3959e5fadcdd2:initial;--tb664e82212c3bccc:initial;--t9a31f328106ed9e5:initial;--tc9e7b6773556299a:initial;--te96a9b9871ecb3b2:initial;--tf2b1f40e119f987f:initial;--tb02d87dcc67c305b:initial;--t545ccfe829576a10:initial;--tea2ea0b0208857b3:initial;--t8591073155165637:initial;--t37377c547bc57f75:initial;--t49ea1ae10ca23d7c:initial;--tfd02fa298ac3c2e9:initial;--t2bb4bb353ccdc9bc:initial;--tbc04aae6b019e2c4:initial;--t4cd7f3fb0edb1a5c:initial;--tfaf017024cef75b5:initial;--taa4eeb8bd16fab9f:initial;--t87d5217b9e23b994:initial;--t14f872f9e689f321:initial;--t99854c0b295cdcd0:initial;--tb4c61d8aedd58ae9:initial;--t57e0d1eb4d891ada:initial;--t48fce8ea4c21ee44:initial;--t944bfe6984dd6904:initial;--t5b340f0a892d598a:initial;--t60175fe010ccaf60:initial;--t2110097e9f647d54:initial;--tf60993bb7acf358f:initial;--t2d4c1c7181ada0c2:initial;--t28a8f6582456439d:initial;--ta64e77119895d0a5:initial;--t2c153771025592fb:initial;--tf68e49e68b7efcd1:initial;--t150db0579d037d35:initial;--t8afadb93a7160c91:initial;--t4836223a77e12d09:initial;--tf14af4f428eb900c:initial;--tdc392c0f954451bb:initial;--te298918552000ed2:initial;--tba95d9ffeddf4d24:initial;--td59483778c9968d8:initial;--t514a109504e0a58d:initial;--t607887aab828b431:initial;--t772840d9a3e31c3a:initial;--t990ddb3866890a79:initial;--tfb2050fb48dff7d9:initial;--t41b995405d7a6a52:initial;--t439f0062d041481a:initial;--tc5b04342ebbc8313:initial;--t191274c1fdbddaa9:initial;--t695bf178369c1b34:initial;--t24e983d5a2effaf3:initial;--t2f4c4b4988420773:initial;--te7e2290a567b22c3:initial;--t34f0dce4bcac971e:initial;--t6124fe694ff1be5a:initial;--t5d153b3c14c81857:initial;--t8e3f1cbcd575ae29:initial;--t02320a9adba8a46d:initial;--taa8fd9ca5a0e5aff:initial;--t15119ab90dead445:initial;--td2e68be7dec6d104:initial;--te4a49aa32a6b93f3:initial;--t6d8e79ae61c770b4:initial;--t7374348028e7db7c:initial;--tead3438429c997ac:initial;--t26443d05e983030c:initial;--t7c9ca432ec95f45c:initial;--t398507fba7e3389a:initial;--tde9101ce16335768:initial;--td66c30799fcd019f:initial;--tb8a758dee5f70464:initial;--t03f846cb65ee139f:initial;--t00acce3e8155018e:initial;--t5e3e1a7b68d9f779:initial;--t16358e7e6477feee:initial;--t59ed5e2c247238f1:initial;--tf16adc1c0e3ee1ab:initial;--tfe75c48d1cd7663f:initial;--t4f8ecc2c88a79a00:initial;--t9d0ed8867dcedc3b:initial;--t16f7c3ea11c4fb3b:initial;--ta35398ab466ac4f6:initial;--tf0e598d38f73e0b3:initial;--ta03cbc43ae93f982:initial;--ta8ffba4c3264473e:initial;--ta3a92d9912918d75:initial;--tb62c50d6d8f610fb:initial;--t825160bd354dee0a:initial}:root{--t74616a278b5afe91:#1b1b1b;--t8583f71512bf0910:#1e1f20;--tadac3bcc408f4c35:#131314;--t60c6ecba48313128:#282a2c;--t8dca291271aac8f7:#333537;--ted93aa1a9bd66491:#37393b;--t6def6ae5608c97fc:#3c4851;--t39bd715aad1b7b31:#d3dbe5;--t8e80fd2021b6ae59:#d7e4ef;--tf3d4da13ad0ad197:#dde3ea;--t78a3a8759959b01e:#e9eef6;--t454e395cbd7ea4f5:#f0f4f9;--t82076a04482f6e88:#f8fafd;--t705040f1a4491b34:#041e49;--t3b1a8edba0a7fa29:#062e6f;--tb9bf71293c713114:#0842a0;--t09dc9f6d9d326b58:#0b57d0;--t6aee1f0766d1fd0d:#0c67ee;--tefa903b07f53b504:#1b6ef3;--t31c4f1e53de20e9a:#4c8df6;--tcdb3959e5fadcdd2:#7cacf8;--tb664e82212c3bccc:#a8c7fa;--t9a31f328106ed9e5:#d3e3fd;--tc9e7b6773556299a:#ecf3fe;--te96a9b9871ecb3b2:#fafbff;--tf2b1f40e119f987f:#001d35;--tb02d87dcc67c305b:#035;--t545ccfe829576a10:#214042;--tea2ea0b0208857b3:#004a77;--t8591073155165637:#00639b;--t37377c547bc57f75:#047db7;--t49ea1ae10ca23d7c:#3998d3;--tfd02fa298ac3c2e9:#5ab3f0;--t2bb4bb353ccdc9bc:#7fcfff;--tbc04aae6b019e2c4:#b9e2ff;--t4cd7f3fb0edb1a5c:#c2e7ff;--tfaf017024cef75b5:#dff3ff;--taa4eeb8bd16fab9f:#f7fcff;--t87d5217b9e23b994:#a5dbff}:root{--t99854c0b295cdcd0:#fef2e2;--t2d4c1c7181ada0c2:#d3e3fd;--t2c153771025592fb:#c54105;--t150db0579d037d35:#fff0ef;--t7374348028e7db7c:#d01884;--tf16adc1c0e3ee1ab:#d7e4ef;--t14f872f9e689f321:#9f6108;--tb4c61d8aedd58ae9:#ffdf99;--t57e0d1eb4d891ada:#ffbb29;--t48fce8ea4c21ee44:#5e5e5e;--t944bfe6984dd6904:var(--tb664e82212c3bccc);--t5b340f0a892d598a:#292a2d;--t60175fe010ccaf60:#e3e3e3;--t2110097e9f647d54:var(--t09dc9f6d9d326b58);--tf60993bb7acf358f:var(--t454e395cbd7ea4f5);--t28a8f6582456439d:var(--tb664e82212c3bccc);--ta64e77119895d0a5:#303030;--tf68e49e68b7efcd1:#d32f28;--t8afadb93a7160c91:#ffdad8;--t4836223a77e12d09:#f2f2f2;--tf14af4f428eb900c:var(--tf3d4da13ad0ad197);--tdc392c0f954451bb:#421f00;--te298918552000ed2:#1f1f1f;--tba95d9ffeddf4d24:#ababab;--td59483778c9968d8:#8f8f8f;--t514a109504e0a58d:#fff;--t607887aab828b431:#1f1f1f;--t772840d9a3e31c3a:#fff;--t990ddb3866890a79:#fff;--tfb2050fb48dff7d9:#1f1f1f;--t41b995405d7a6a52:#1f1f1f;--t439f0062d041481a:#5e5e5e;--tc5b04342ebbc8313:#fff;--t191274c1fdbddaa9:#1f1f1f;--t695bf178369c1b34:#fff;--t24e983d5a2effaf3:var(--t09dc9f6d9d326b58);--t2f4c4b4988420773:var(--t705040f1a4491b34);--te7e2290a567b22c3:#1f1f1f;--t34f0dce4bcac971e:#1f1f1f;--t6124fe694ff1be5a:#5e5e5e;--t8e3f1cbcd575ae29:#e3e3e3;--t02320a9adba8a46d:#e3e3e3;--taa8fd9ca5a0e5aff:#c7c7c7;--t15119ab90dead445:#2b7f3f;--td2e68be7dec6d104:#c4eed0;--te4a49aa32a6b93f3:var(--t09dc9f6d9d326b58);--t6d8e79ae61c770b4:var(--tefa903b07f53b504);--tead3438429c997ac:var(--t8591073155165637);--t26443d05e983030c:var(--t09dc9f6d9d326b58);--t7c9ca432ec95f45c:#b3261e;--t398507fba7e3389a:#945700;--tde9101ce16335768:#146c2e;--td66c30799fcd019f:var(--tc9e7b6773556299a);--tb8a758dee5f70464:var(--t9a31f328106ed9e5);--t03f846cb65ee139f:var(--t9a31f328106ed9e5);--t00acce3e8155018e:#ffbb29;--t5e3e1a7b68d9f779:#fff;--t16358e7e6477feee:#fff;--t59ed5e2c247238f1:var(--t454e395cbd7ea4f5);--tfe75c48d1cd7663f:var(--t78a3a8759959b01e);--t4f8ecc2c88a79a00:var(--tf3d4da13ad0ad197);--t9d0ed8867dcedc3b:var(--t82076a04482f6e88);--t16f7c3ea11c4fb3b:#fff;--ta35398ab466ac4f6:var(--t8e80fd2021b6ae59);--tf0e598d38f73e0b3:#fff;--ta03cbc43ae93f982:#fff;--ta8ffba4c3264473e:#fff;--ta3a92d9912918d75:#fff;--tb62c50d6d8f610fb:#fff;--t825160bd354dee0a:var(--te96a9b9871ecb3b2);--t5d153b3c14c81857:var(--te7e2290a567b22c3)}:root{--t7d3d717014590bb4:0px;--t94b72732466dbe30:var(--t59ed5e2c247238f1);--tbb6c6b1b67f1ea5b:transparent}:root{--t916e4a7c47841e29:var(--t16358e7e6477feee);--t8caff653df19629d:var(--te7e2290a567b22c3);--tc9e053af0343ea61:0px;--tb1ade73813c5e5ab:24px;--t0ec7a441bb5a34a6:28px}:root{--tf23240eac0acfe84:1px;--t4c3944ad81a8306d:var(--td59483778c9968d8);--te31660884ed46aab:var(--t60175fe010ccaf60);--t32958dd10f7d51af:var(--t02320a9adba8a46d);--t6accc05ac5bb1eff:var(--t03f846cb65ee139f);--t39332736badf4674:var(--t2f4c4b4988420773);--t680aad4497de86ae:var(--t2f4c4b4988420773);--t09d6b33fb13e8489:var(--t5e3e1a7b68d9f779);--t74eb8d880ffc4bda:var(--te7e2290a567b22c3);--t9538fb1696e0a87a:var(--taa8fd9ca5a0e5aff);--t85c4f3a1ab62d94b:var(--t6124fe694ff1be5a)}:root{--t20e68aae27bed1ec:0px;--tef6d873f82956433:var(--t60175fe010ccaf60);--tebfbbb84f6b5e5b9:var(--td59483778c9968d8);--t6f2ea937da3762cd:var(--t16358e7e6477feee);--td7c9881a4de36976:var(--te7e2290a567b22c3);--t7ab10821a9a38e07:var(--te7e2290a567b22c3);--tc93164b705392ee5:var(--te4a49aa32a6b93f3);--tebe6837248261a41:var(--te4a49aa32a6b93f3);--t3cdbe5bd7a07bede:var(--t03f846cb65ee139f);--t33ec501ef7aa1732:var(--t2f4c4b4988420773);--ta2a4ee4913f8a956:var(--t4836223a77e12d09);--tab8534ef038aa0fa:var(--t41b995405d7a6a52);--t329638ef3d6ac919:var(--te4a49aa32a6b93f3);--t0a57a7ae4a33205c:var(--t6d8e79ae61c770b4);--tf7b40ad5c33244a6:var(--t695bf178369c1b34);--t4d7e5b15f70139ef:var(--t695bf178369c1b34);--t5d3b44cda28eaae1:var(--te4a49aa32a6b93f3);--t2c09520dc82dd8ed:var(--t03f846cb65ee139f);--tf78a03b52584613a:var(--t2f4c4b4988420773);--t5431ff9f1b333bcb:var(--td66c30799fcd019f);--t22f58786b305bb6f:var(--t24e983d5a2effaf3);--t2c6b3f4a99d7dd0b:var(--te4a49aa32a6b93f3);--t7839770d085b0b4d:transparent;--t888e1f62a94fdfae:var(--taa8fd9ca5a0e5aff);--t03d5eac9e8805344:var(--t5e3e1a7b68d9f779);--tf38af22da2d552cb:var(--te7e2290a567b22c3);--tbfa623749bc8ac63:var(--te7e2290a567b22c3);--t806705902cda9388:var(--te4a49aa32a6b93f3);--t3ff8f9c93a56e733:var(--te4a49aa32a6b93f3);--t6157b9e200214dc9:var(--te7e2290a567b22c3);--t3a6553fda362956d:var(--te4a49aa32a6b93f3);--t15dcf3f93013a7ba:var(--te4a49aa32a6b93f3)}:root{--tfb93870d7246d03c:var(--t03f846cb65ee139f);--t45989b3bcb22f6dd:var(--t59ed5e2c247238f1);--t70990749324aca36:var(--te4a49aa32a6b93f3);--t6d2d91747ffc3f98:var(--t6124fe694ff1be5a);--tf7e68e6518cfb3cc:var(--te4a49aa32a6b93f3);--te229be082e76b81b:var(--t6124fe694ff1be5a);--t80e95d977575c16d:var(--te4a49aa32a6b93f3);--td7c27d8d43c16adb:var(--t6124fe694ff1be5a)}:root{--td2d005592644aac8:var(--t16358e7e6477feee);--t30866cc32fb8f0d4:var(--t16358e7e6477feee);--t5b35d265ba7ac78d:var(--te7e2290a567b22c3);--t931ee5ce260d19db:var(--t6124fe694ff1be5a);--tc27c69e8e46c24f5:var(--t41b995405d7a6a52);--tb2e91b152a81751d:var(--t4836223a77e12d09);--tef2dc00b8eacd690:var(--t41b995405d7a6a52);--t8ea1fa7fe56354ca:var(--t439f0062d041481a)}:root{--t6fd6e48dae1ae2e2:var(--t5e3e1a7b68d9f779);--t9347c1ebf94d8478:var(--t6124fe694ff1be5a);--t23818a9024c565e2:var(--t8e3f1cbcd575ae29);--t80a4b4f3e6b468ad:var(--t8e3f1cbcd575ae29);--t76852ee77be24891:var(--te4a49aa32a6b93f3);--td631f0d3538c6f97:var(--te4a49aa32a6b93f3);--tc3fb034f8f2e92a2:var(--ta03cbc43ae93f982);--te19a65a4756532a5:var(--t2f4c4b4988420773);--t40d1263a5dc0889f:var(--t03f846cb65ee139f);--td72dfbc38f12f498:var(--t5e3e1a7b68d9f779)}:root{--t14f872f9e689f321:#e37400;--t99854c0b295cdcd0:#fef7e0;--t48fce8ea4c21ee44:#5f6368;--t944bfe6984dd6904:#8ab4f8;--t5b340f0a892d598a:#2a2b2e;--t60175fe010ccaf60:#f1f3f4;--t2110097e9f647d54:#1a73e8;--ta64e77119895d0a5:#3c4043;--tf68e49e68b7efcd1:#d93025;--t150db0579d037d35:#fce8e6;--t4836223a77e12d09:#f1f3f4;--tdc392c0f954451bb:#fff;--te298918552000ed2:#b05b00;--tba95d9ffeddf4d24:#9aa0a6;--td59483778c9968d8:#bdc1c6;--tfb2050fb48dff7d9:#c5221f;--t41b995405d7a6a52:#202124;--t439f0062d041481a:#70757a;--t191274c1fdbddaa9:#137333;--t24e983d5a2effaf3:#1967d2;--te7e2290a567b22c3:#202124;--t6124fe694ff1be5a:#70757a;--t5d153b3c14c81857:#202124;--t8e3f1cbcd575ae29:#dadce0;--t02320a9adba8a46d:#f1f3f4;--taa8fd9ca5a0e5aff:#dadce0;--t15119ab90dead445:#188038;--td2e68be7dec6d104:#e6f4ea;--te4a49aa32a6b93f3:#1a73e8;--t6d8e79ae61c770b4:#1a73e8;--td66c30799fcd019f:#e8f0fe;--t00acce3e8155018e:#fbbc04;--t825160bd354dee0a:#fff}@supports (background-color:rgb(from #1a73e8 r g b/0.5)){:root{--web-maps-color-state-layer-primary-hover:rgb(from var(--te4a49aa32a6b93f3) r g b / 0.08);--web-maps-color-state-layer-primary-pressed:rgb(from var(--te4a49aa32a6b93f3) r g b / 0.12);--web-maps-color-state-layer-primary-focus:rgb(from var(--te4a49aa32a6b93f3) r g b / 0.12);--web-maps-color-state-layer-primary-hover-and-focus:rgb(from var(--te4a49aa32a6b93f3) r g b / 0.16);--web-maps-color-state-layer-on-constant-dark-hover:rgba(255,255,255,0.078);--web-maps-color-state-layer-on-constant-dark-pressed:rgba(255,255,255,0.122);--web-maps-color-state-layer-on-constant-dark-focus:rgba(255,255,255,0.122);--web-maps-color-state-layer-on-constant-dark-hover-and-focus:rgba(255,255,255,0.161);--web-maps-color-state-layer-on-primary-container-hover:rgb(from var(--t695bf178369c1b34) r g b / 0.08);--web-maps-color-state-layer-on-primary-container-pressed:rgb(from var(--t695bf178369c1b34) r g b / 0.12);--web-maps-color-state-layer-on-primary-container-focus:rgb(from var(--t695bf178369c1b34) r g b / 0.12);--web-maps-color-state-layer-on-primary-container-hover-and-focus:rgb(from var(--t695bf178369c1b34) r g b / 0.16);--web-maps-color-state-layer-on-neutral-container-hover:rgb(from var(--t41b995405d7a6a52) r g b / 0.08);--web-maps-color-state-layer-on-neutral-container-pressed:rgb(from var(--t41b995405d7a6a52) r g b / 0.12);--web-maps-color-state-layer-on-neutral-container-focus:rgb(from var(--t41b995405d7a6a52) r g b / 0.12);--web-maps-color-state-layer-on-neutral-container-hover-and-focus:rgb(from var(--t41b995405d7a6a52) r g b / 0.16);--web-maps-color-state-layer-on-secondary-container-hover:rgb(from var(--t24e983d5a2effaf3) r g b / 0.08);--web-maps-color-state-layer-on-secondary-container-pressed:rgb(from var(--t24e983d5a2effaf3) r g b / 0.12);--web-maps-color-state-layer-on-secondary-container-focus:rgb(from var(--t24e983d5a2effaf3) r g b / 0.12);--web-maps-color-state-layer-on-secondary-container-hover-and-focus:rgb(from var(--t24e983d5a2effaf3) r g b / 0.16);--web-maps-color-state-layer-on-surface-hover:rgb(from var(--te7e2290a567b22c3) r g b / 0.08);--web-maps-color-state-layer-on-surface-pressed:rgb(from var(--te7e2290a567b22c3) r g b / 0.12);--web-maps-color-state-layer-on-surface-focus:rgb(from var(--te7e2290a567b22c3) r g b / 0.12);--web-maps-color-state-layer-on-surface-hover-and-focus:rgb(from var(--te7e2290a567b22c3) r g b / 0.16);--web-maps-color-state-layer-on-askmaps-container-hover:rgba(52,91,241,0.078);--web-maps-color-state-layer-on-askmaps-container-pressed:rgba(52,91,241,0.122);--web-maps-color-state-layer-on-askmaps-container-focus:rgba(52,91,241,0.122);--web-maps-color-state-layer-on-askmaps-container-hover-and-focus:rgba(52,91,241,0.161)}}@supports not (background-color:rgb(from #1a73e8 r g b/0.5)){:root{--web-maps-color-state-layer-on-primary-container-hover:rgba(255,255,255,0.08);--web-maps-color-state-layer-on-primary-container-pressed:rgba(255,255,255,0.12);--web-maps-color-state-layer-on-primary-container-focus:rgba(255,255,255,0.12);--web-maps-color-state-layer-on-primary-container-hover-and-focus:rgba(255,255,255,0.16);--web-maps-color-state-layer-on-secondary-container-hover:rgba(26,115,232,0.08);--web-maps-color-state-layer-on-secondary-container-pressed:rgba(26,115,232,0.12);--web-maps-color-state-layer-on-secondary-container-focus:rgba(26,115,232,0.12);--web-maps-color-state-layer-on-secondary-container-hover-and-focus:rgba(26,115,232,0.16);--web-maps-color-state-layer-on-surface-hover:rgba(31,31,31,0.08);--web-maps-color-state-layer-on-surface-pressed:rgba(31,31,31,0.12);--web-maps-color-state-layer-on-surface-focus:rgba(31,31,31,0.12);--web-maps-color-state-layer-on-surface-hover-and-focus:rgba(31,31,31,0.16)}}.mapsConsumerUiSceneCoreScenecommon__impressCanvas{display:none}.mapsConsumerUiSceneCoreScenecommon__activated.mapsConsumerUiSceneCoreScenecommon__impressCanvas{display:block}.mapsConsumerUiSceneCoreScenecommon__impressIndicator{position:absolute;visibility:hidden}.mapsConsumerUiSceneCoreScenecommon__activated.mapsConsumerUiSceneCoreScenecommon__impressCanvas+.mapsConsumerUiSceneCoreScenecommon__impressIndicator{visibility:inherit;top:50%;left:25px;width:10px;height:10px;background-color:var(--t15119ab90dead445)}.mapsConsumerLibAppPrint__printMode .mapsConsumerUiSceneCoreScenecommon__impressIndicator,.mapsConsumerLibAppPrint__printMode .mapsConsumerUiSceneCoreScenecommon__noprint,.mapsConsumerUiSceneCoreScenecommon__impressCanvas.mapsConsumerUiSceneCoreScenecommon__impressHidden,.mapsConsumerUiSceneCoreScenecommon__impressHidden,.mapsConsumerUiSceneCoreScenecommon__impressIndicator.mapsConsumerUiSceneCoreScenecommon__impressHidden{display:none}.mapsConsumerUiSceneCoreScenecommon__effects{position:absolute;left:0;top:0;z-index:2}.mapsConsumerUiSceneCoreScenecommon__imageryRender{position:absolute;left:0;top:0;z-index:1;background-color:#000}.mapsConsumerLibAppPrint__printMode .mapsConsumerUiSceneCoreScenecommon__imageryRender{position:relative;background:#fff;z-index:4}.mapsImagerySceneScene__root{width:100%;height:100%;overflow:hidden;position:absolute;z-index:0;background-color:#000}.mapsConsumerLibAppKeynav__on .mapsImagerySceneScene__root:focus .mapsImagerySceneScene__focusOutline,.mapsImagerySceneScene__root:focus-visible .mapsImagerySceneScene__focusOutline{border:2px solid var(--te4a49aa32a6b93f3);-webkit-box-sizing:border-box;box-sizing:border-box;height:100%;pointer-events:none;position:absolute;width:100%;z-index:1}.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__root:focus .mapsImagerySceneScene__focusOutline{display:none}.mapsImagerySceneScene__root .widget-scene-imagery-iframe{position:absolute}.mapsImagerySceneScene__canvas{background-color:#000;left:0;outline:none;position:absolute;top:0}.mapsImagerySceneScene__captureCanvas{position:relative;z-index:3}.mapsImagerySceneScene__tileImage3d{-webkit-backface-visibility:hidden;backface-visibility:hidden}.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__captureCanvas{width:100%;height:auto;-webkit-transform:none;-ms-transform:none;transform:none}.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__root{background:#fff;position:static;overflow:visible}.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__canvas{display:block;background:#fff}.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__canvas.mapsConsumerUiSceneCoreScenecommon__noprint{display:none}.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__root .widget-scene-imagery-iframe{position:relative}@media print{.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__root .widget-scene-imagery-iframe{left:50%;-webkit-transform:translateX(-50%);-ms-transform:translateX(-50%);transform:translateX(-50%)}}.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__root .mapsImagerySceneScene__canvas{position:static}.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__captureCanvas~.mapsImagerySceneScene__canvas{display:none}sentinel{}\n`;
  xp`:root{--t4e3d42d0a1a9e6ca:initial;--td1001393b8945945:initial;--te03d8b6ec525f4b4:initial;--td2e4807cf9d242fe:initial;--t8c8a085cbf3648e0:initial;--t0a540ae3945f2d07:initial;--t66846006bf68c475:initial;--t622c19e8720f65de:initial;--t29584690f8dcb93a:initial;--t2a70666c74ec8d23:initial;--tcc644d3307983d6f:initial;--t6b235b10f5441e2d:initial;--t7a2f2236f53dd54a:initial;--t524e980fd5a66932:initial;--tb509833b3596d641:initial;--t0ef0926f27183a78:initial;--t9c92cbe8e92b79f4:initial;--ta07625c1122320df:initial;--ta2dfb4f47e5932f8:initial;--t8645f1bbfdc95dc0:initial;--t344a5c79f987dc73:initial;--tadd8d54aafe1b344:initial;--ta37b7cf1c497b2de:initial;--tfd29a9b34dcb458b:initial;--tb81c324d0370f7c6:initial;--t3b9f79904082dd00:initial;--t28426e2f5105e2b7:initial;--t908fc5484ed1452d:initial;--t84759c146a624695:initial;--t8367495db485c986:initial;--t5bfded1f61a6f516:initial;--td4bf447d66e7cd1d:initial;--tdf8c25468ef22140:initial;--t0e411425009a5c7e:initial;--t270c498122f5f3cd:initial;--tfa23e99dd7e643db:initial;--t2942d6aa7b83263f:initial;--t30ed7c1450be5af4:initial;--tbf5eb2ddc9a4fa65:initial;--tbaeb7e465259e75e:initial;--tce71f9556eb3b332:initial;--t3c7d8bbf1a8f2de4:initial;--t72293e98cdbf820b:initial;--t5c15aef36210bfe4:initial;--t344dfe0a85df5945:initial;--t0e0ee499b6b703da:initial;--t58e7d324a9d53283:initial;--t6ed8b1e93395a38d:initial;--tbf78ca7905ed4365:initial;--tf5ca1f85df12555b:initial;--t7e308d9d65efea7b:initial;--t2477c147f43096ae:initial;--t5cd2aeae6e5bd293:initial;--t7cbb7697b854692b:initial;--tef6d873f82956433:initial;--tebfbbb84f6b5e5b9:initial;--t6f2ea937da3762cd:initial;--td7c9881a4de36976:initial;--t7ab10821a9a38e07:initial;--tc93164b705392ee5:initial;--tebe6837248261a41:initial;--t3cdbe5bd7a07bede:initial;--t33ec501ef7aa1732:initial;--ta2a4ee4913f8a956:initial;--tab8534ef038aa0fa:initial;--t329638ef3d6ac919:initial;--t0a57a7ae4a33205c:initial;--tf7b40ad5c33244a6:initial;--t4d7e5b15f70139ef:initial;--t5d3b44cda28eaae1:initial;--t2c09520dc82dd8ed:initial;--tf78a03b52584613a:initial;--t5431ff9f1b333bcb:initial;--t22f58786b305bb6f:initial;--t2c6b3f4a99d7dd0b:initial;--t7839770d085b0b4d:initial;--t20e68aae27bed1ec:initial;--t888e1f62a94fdfae:initial;--t03d5eac9e8805344:initial;--tf38af22da2d552cb:initial;--tbfa623749bc8ac63:initial;--t806705902cda9388:initial;--t3ff8f9c93a56e733:initial;--t6157b9e200214dc9:initial;--t3a6553fda362956d:initial;--t15dcf3f93013a7ba:initial;--t94b72732466dbe30:initial;--tbb6c6b1b67f1ea5b:initial;--t7d3d717014590bb4:initial;--tdb59c0d44b2c69d6:initial;--t29a1ef30e579e6cb:initial;--te6f6cc1890fc4750:initial;--t832b84df26af6b12:initial;--t1c2557ed89674134:initial;--t33fcf8ae37f90872:initial;--t1dcccc4783e03e58:initial;--t916e4a7c47841e29:initial;--t8caff653df19629d:initial;--tc9e053af0343ea61:initial;--tb1ade73813c5e5ab:initial;--t0ec7a441bb5a34a6:initial;--t895159822cfc2ce5:initial;--tedd4db81d8bfcdb5:initial;--t2705489ebda31200:initial;--t382c2497976842f2:initial;--t1fe22d166875c35c:initial;--td02fc481451ef23c:initial;--t881cbebb7adf5db0:initial;--tfb0dc11cd41c7f49:initial;--t2daff0a373a361c3:initial;--tbf59280e7a6fcdf8:initial;--tbd69399f0f8015a1:initial;--ta5d6273186b55186:initial;--t25f96c26aad1c4f5:initial;--t108960aded2e62ae:initial;--t98921a3982848eb6:initial;--t8d27b349c95af44f:initial;--t2479ef2801297ce3:initial;--tf218f0cc8e564d7f:initial;--t50a1bf18f0c0392e:initial;--t4c3944ad81a8306d:initial;--te31660884ed46aab:initial;--t32958dd10f7d51af:initial;--t6accc05ac5bb1eff:initial;--t39332736badf4674:initial;--t680aad4497de86ae:initial;--t09d6b33fb13e8489:initial;--t74eb8d880ffc4bda:initial;--t9538fb1696e0a87a:initial;--tf23240eac0acfe84:initial;--t85c4f3a1ab62d94b:initial;--t51c8a96db826900c:initial;--t64f93b81c040e696:initial;--t5493784bc9f378c6:initial;--tde5d76ec8087e7e2:initial;--t8381ad5c2791d681:initial;--t12e0ff1aa954deeb:initial;--t3c7ee2a099a3da6c:initial;--td1ec171a5620a099:initial;--taf2e1ae79348bf2d:initial;--td3ee4c6eb1412b23:initial;--tf7190799071fff3f:initial;--t0beb9a03e2919455:initial;--td08f1f6dec0ac9b1:initial;--tbc971ffe578c918f:initial;--tde4b64446584d028:initial;--tf9dddf7f9e256c99:initial;--t1e3a072f8335ea15:initial;--te90d0950735a8177:initial;--t7cb1742d240eaa32:initial;--tea441ddbe31f0a67:initial;--t8246a2c15373589e:initial;--t6b7fda0e753911b3:initial;--tb9aa52784c619862:initial;--tb10dc9bc98c4440d:initial;--tec22d4c0c9e34788:initial;--te9868d04f1ba663a:initial;--te2f460535a256ffb:initial;--t29ee2da8c1217fb0:initial;--t2ffbb8c3b9cb6cb4:initial;--t468f653057de2dd9:initial;--tfb93870d7246d03c:initial;--t45989b3bcb22f6dd:initial;--t70990749324aca36:initial;--t6d2d91747ffc3f98:initial;--tf7e68e6518cfb3cc:initial;--te229be082e76b81b:initial;--t80e95d977575c16d:initial;--td7c27d8d43c16adb:initial;--t911c2f2ec5ab6c20:initial;--tc73672f34cfb180b:initial;--t7cd2876824e097f2:initial;--t4fe77dafd31bfb98:initial;--t7d1d42f5691a8438:initial;--t166dc8aff19b05cb:initial;--t1af7f8e47944be24:initial;--t82e9122c96d66a2a:initial;--t7a02f642ed355e6e:initial;--t53591bcb459ac6e9:initial;--t6577d7e18cd5bac8:initial;--tf226f3b63d749ba6:initial;--td2d005592644aac8:initial;--t30866cc32fb8f0d4:initial;--t5b35d265ba7ac78d:initial;--t931ee5ce260d19db:initial;--tc27c69e8e46c24f5:initial;--tb2e91b152a81751d:initial;--tef2dc00b8eacd690:initial;--t8ea1fa7fe56354ca:initial;--t94c50809ac36a350:initial;--t13c17fdd6d8a204d:initial;--te999551fb577f524:initial;--tc9342584118b414f:initial;--taa4be36ff7059379:initial;--te19953ebfa2de95c:initial;--te604cf7481f2624c:initial;--tf823bcfc551a96f8:initial;--t5a016e9598bab160:initial;--tbdea95f4163b6088:initial;--tca65991886314e6d:initial;--td5b9bf5019ef3617:initial;--t6c50fcfef830dda7:initial;--t2b2c2cc3fcd67f17:initial;--t34674b112dad6cd5:initial;--tcb58cd0a504642de:initial;--t11336075c072d328:initial;--t81d73f3e2698edd8:initial;--t9b543197ec3917e2:initial;--tc7e4ba9ee853bd99:initial;--t078ee833758ebce6:initial;--t6fd6e48dae1ae2e2:initial;--t9347c1ebf94d8478:initial;--t23818a9024c565e2:initial;--t80a4b4f3e6b468ad:initial;--t76852ee77be24891:initial;--td631f0d3538c6f97:initial;--tc3fb034f8f2e92a2:initial;--te19a65a4756532a5:initial;--t40d1263a5dc0889f:initial;--td72dfbc38f12f498:initial;--ta5e06f0a3067baf1:initial;--tbd9462f131dcad83:initial;--t904406aa11d5ebf4:initial;--te834e28df623be34:initial;--t73b7020e81229b0a:initial;--t6164bcb4f003f424:initial;--t0958a77938946e20:initial;--te42e91b8f2702402:initial;--t82d4faf5b8de0d38:initial;--t2dcce6feebcd219f:initial;--t0c47b322a3909892:initial;--t5ea3ccb33b0ee9c7:initial;--tb4cdd2c94a4c9a33:initial;--t717d8b6eefbfa496:initial;--tc6ee8d8a2d446b92:initial;--t8ec3c193aa3b7831:initial;--tcd55c1964be9fe0d:initial;--ta5a393794e2fa954:initial;--t49292eb1708b1f59:initial;--t8f1974bad8d4fc1f:initial;--t7a4ab0db3fc8475f:initial;--t470baf93bb372c85:initial;--t6bbc2e3f295d4d68:initial;--t77c709c5fff4170a:initial;--t6f1a0e4484ff70e2:initial;--t71aabfa274e23783:initial;--t74616a278b5afe91:initial;--t8583f71512bf0910:initial;--tadac3bcc408f4c35:initial;--t60c6ecba48313128:initial;--t8dca291271aac8f7:initial;--ted93aa1a9bd66491:initial;--t6def6ae5608c97fc:initial;--t39bd715aad1b7b31:initial;--t8e80fd2021b6ae59:initial;--tf3d4da13ad0ad197:initial;--t78a3a8759959b01e:initial;--t454e395cbd7ea4f5:initial;--t82076a04482f6e88:initial;--t705040f1a4491b34:initial;--t3b1a8edba0a7fa29:initial;--tb9bf71293c713114:initial;--t09dc9f6d9d326b58:initial;--t6aee1f0766d1fd0d:initial;--tefa903b07f53b504:initial;--t31c4f1e53de20e9a:initial;--tcdb3959e5fadcdd2:initial;--tb664e82212c3bccc:initial;--t9a31f328106ed9e5:initial;--tc9e7b6773556299a:initial;--te96a9b9871ecb3b2:initial;--tf2b1f40e119f987f:initial;--tb02d87dcc67c305b:initial;--t545ccfe829576a10:initial;--tea2ea0b0208857b3:initial;--t8591073155165637:initial;--t37377c547bc57f75:initial;--t49ea1ae10ca23d7c:initial;--tfd02fa298ac3c2e9:initial;--t2bb4bb353ccdc9bc:initial;--tbc04aae6b019e2c4:initial;--t4cd7f3fb0edb1a5c:initial;--tfaf017024cef75b5:initial;--taa4eeb8bd16fab9f:initial;--t87d5217b9e23b994:initial;--t14f872f9e689f321:initial;--t99854c0b295cdcd0:initial;--tb4c61d8aedd58ae9:initial;--t57e0d1eb4d891ada:initial;--t48fce8ea4c21ee44:initial;--t944bfe6984dd6904:initial;--t5b340f0a892d598a:initial;--t60175fe010ccaf60:initial;--t2110097e9f647d54:initial;--tf60993bb7acf358f:initial;--t2d4c1c7181ada0c2:initial;--t28a8f6582456439d:initial;--ta64e77119895d0a5:initial;--t2c153771025592fb:initial;--tf68e49e68b7efcd1:initial;--t150db0579d037d35:initial;--t8afadb93a7160c91:initial;--t4836223a77e12d09:initial;--tf14af4f428eb900c:initial;--tdc392c0f954451bb:initial;--te298918552000ed2:initial;--tba95d9ffeddf4d24:initial;--td59483778c9968d8:initial;--t514a109504e0a58d:initial;--t607887aab828b431:initial;--t772840d9a3e31c3a:initial;--t990ddb3866890a79:initial;--tfb2050fb48dff7d9:initial;--t41b995405d7a6a52:initial;--t439f0062d041481a:initial;--tc5b04342ebbc8313:initial;--t191274c1fdbddaa9:initial;--t695bf178369c1b34:initial;--t24e983d5a2effaf3:initial;--t2f4c4b4988420773:initial;--te7e2290a567b22c3:initial;--t34f0dce4bcac971e:initial;--t6124fe694ff1be5a:initial;--t5d153b3c14c81857:initial;--t8e3f1cbcd575ae29:initial;--t02320a9adba8a46d:initial;--taa8fd9ca5a0e5aff:initial;--t15119ab90dead445:initial;--td2e68be7dec6d104:initial;--te4a49aa32a6b93f3:initial;--t6d8e79ae61c770b4:initial;--t7374348028e7db7c:initial;--tead3438429c997ac:initial;--t26443d05e983030c:initial;--t7c9ca432ec95f45c:initial;--t398507fba7e3389a:initial;--tde9101ce16335768:initial;--td66c30799fcd019f:initial;--tb8a758dee5f70464:initial;--t03f846cb65ee139f:initial;--t00acce3e8155018e:initial;--t5e3e1a7b68d9f779:initial;--t16358e7e6477feee:initial;--t59ed5e2c247238f1:initial;--tf16adc1c0e3ee1ab:initial;--tfe75c48d1cd7663f:initial;--t4f8ecc2c88a79a00:initial;--t9d0ed8867dcedc3b:initial;--t16f7c3ea11c4fb3b:initial;--ta35398ab466ac4f6:initial;--tf0e598d38f73e0b3:initial;--ta03cbc43ae93f982:initial;--ta8ffba4c3264473e:initial;--ta3a92d9912918d75:initial;--tb62c50d6d8f610fb:initial;--t825160bd354dee0a:initial}:root{--t74616a278b5afe91:#1b1b1b;--t8583f71512bf0910:#1e1f20;--tadac3bcc408f4c35:#131314;--t60c6ecba48313128:#282a2c;--t8dca291271aac8f7:#333537;--ted93aa1a9bd66491:#37393b;--t6def6ae5608c97fc:#3c4851;--t39bd715aad1b7b31:#d3dbe5;--t8e80fd2021b6ae59:#d7e4ef;--tf3d4da13ad0ad197:#dde3ea;--t78a3a8759959b01e:#e9eef6;--t454e395cbd7ea4f5:#f0f4f9;--t82076a04482f6e88:#f8fafd;--t705040f1a4491b34:#041e49;--t3b1a8edba0a7fa29:#062e6f;--tb9bf71293c713114:#0842a0;--t09dc9f6d9d326b58:#0b57d0;--t6aee1f0766d1fd0d:#0c67ee;--tefa903b07f53b504:#1b6ef3;--t31c4f1e53de20e9a:#4c8df6;--tcdb3959e5fadcdd2:#7cacf8;--tb664e82212c3bccc:#a8c7fa;--t9a31f328106ed9e5:#d3e3fd;--tc9e7b6773556299a:#ecf3fe;--te96a9b9871ecb3b2:#fafbff;--tf2b1f40e119f987f:#001d35;--tb02d87dcc67c305b:#035;--t545ccfe829576a10:#214042;--tea2ea0b0208857b3:#004a77;--t8591073155165637:#00639b;--t37377c547bc57f75:#047db7;--t49ea1ae10ca23d7c:#3998d3;--tfd02fa298ac3c2e9:#5ab3f0;--t2bb4bb353ccdc9bc:#7fcfff;--tbc04aae6b019e2c4:#b9e2ff;--t4cd7f3fb0edb1a5c:#c2e7ff;--tfaf017024cef75b5:#dff3ff;--taa4eeb8bd16fab9f:#f7fcff;--t87d5217b9e23b994:#a5dbff}:root{--t99854c0b295cdcd0:#fef2e2;--t2d4c1c7181ada0c2:#d3e3fd;--t2c153771025592fb:#c54105;--t150db0579d037d35:#fff0ef;--t7374348028e7db7c:#d01884;--tf16adc1c0e3ee1ab:#d7e4ef;--t14f872f9e689f321:#9f6108;--tb4c61d8aedd58ae9:#ffdf99;--t57e0d1eb4d891ada:#ffbb29;--t48fce8ea4c21ee44:#5e5e5e;--t944bfe6984dd6904:var(--tb664e82212c3bccc);--t5b340f0a892d598a:#292a2d;--t60175fe010ccaf60:#e3e3e3;--t2110097e9f647d54:var(--t09dc9f6d9d326b58);--tf60993bb7acf358f:var(--t454e395cbd7ea4f5);--t28a8f6582456439d:var(--tb664e82212c3bccc);--ta64e77119895d0a5:#303030;--tf68e49e68b7efcd1:#d32f28;--t8afadb93a7160c91:#ffdad8;--t4836223a77e12d09:#f2f2f2;--tf14af4f428eb900c:var(--tf3d4da13ad0ad197);--tdc392c0f954451bb:#421f00;--te298918552000ed2:#1f1f1f;--tba95d9ffeddf4d24:#ababab;--td59483778c9968d8:#8f8f8f;--t514a109504e0a58d:#fff;--t607887aab828b431:#1f1f1f;--t772840d9a3e31c3a:#fff;--t990ddb3866890a79:#fff;--tfb2050fb48dff7d9:#1f1f1f;--t41b995405d7a6a52:#1f1f1f;--t439f0062d041481a:#5e5e5e;--tc5b04342ebbc8313:#fff;--t191274c1fdbddaa9:#1f1f1f;--t695bf178369c1b34:#fff;--t24e983d5a2effaf3:var(--t09dc9f6d9d326b58);--t2f4c4b4988420773:var(--t705040f1a4491b34);--te7e2290a567b22c3:#1f1f1f;--t34f0dce4bcac971e:#1f1f1f;--t6124fe694ff1be5a:#5e5e5e;--t8e3f1cbcd575ae29:#e3e3e3;--t02320a9adba8a46d:#e3e3e3;--taa8fd9ca5a0e5aff:#c7c7c7;--t15119ab90dead445:#2b7f3f;--td2e68be7dec6d104:#c4eed0;--te4a49aa32a6b93f3:var(--t09dc9f6d9d326b58);--t6d8e79ae61c770b4:var(--tefa903b07f53b504);--tead3438429c997ac:var(--t8591073155165637);--t26443d05e983030c:var(--t09dc9f6d9d326b58);--t7c9ca432ec95f45c:#b3261e;--t398507fba7e3389a:#945700;--tde9101ce16335768:#146c2e;--td66c30799fcd019f:var(--tc9e7b6773556299a);--tb8a758dee5f70464:var(--t9a31f328106ed9e5);--t03f846cb65ee139f:var(--t9a31f328106ed9e5);--t00acce3e8155018e:#ffbb29;--t5e3e1a7b68d9f779:#fff;--t16358e7e6477feee:#fff;--t59ed5e2c247238f1:var(--t454e395cbd7ea4f5);--tfe75c48d1cd7663f:var(--t78a3a8759959b01e);--t4f8ecc2c88a79a00:var(--tf3d4da13ad0ad197);--t9d0ed8867dcedc3b:var(--t82076a04482f6e88);--t16f7c3ea11c4fb3b:#fff;--ta35398ab466ac4f6:var(--t8e80fd2021b6ae59);--tf0e598d38f73e0b3:#fff;--ta03cbc43ae93f982:#fff;--ta8ffba4c3264473e:#fff;--ta3a92d9912918d75:#fff;--tb62c50d6d8f610fb:#fff;--t825160bd354dee0a:var(--te96a9b9871ecb3b2);--t5d153b3c14c81857:var(--te7e2290a567b22c3)}:root{--t7d3d717014590bb4:0px;--t94b72732466dbe30:var(--t59ed5e2c247238f1);--tbb6c6b1b67f1ea5b:transparent}:root{--t916e4a7c47841e29:var(--t16358e7e6477feee);--t8caff653df19629d:var(--te7e2290a567b22c3);--tc9e053af0343ea61:0px;--tb1ade73813c5e5ab:24px;--t0ec7a441bb5a34a6:28px}:root{--tf23240eac0acfe84:1px;--t4c3944ad81a8306d:var(--td59483778c9968d8);--te31660884ed46aab:var(--t60175fe010ccaf60);--t32958dd10f7d51af:var(--t02320a9adba8a46d);--t6accc05ac5bb1eff:var(--t03f846cb65ee139f);--t39332736badf4674:var(--t2f4c4b4988420773);--t680aad4497de86ae:var(--t2f4c4b4988420773);--t09d6b33fb13e8489:var(--t5e3e1a7b68d9f779);--t74eb8d880ffc4bda:var(--te7e2290a567b22c3);--t9538fb1696e0a87a:var(--taa8fd9ca5a0e5aff);--t85c4f3a1ab62d94b:var(--t6124fe694ff1be5a)}:root{--t20e68aae27bed1ec:0px;--tef6d873f82956433:var(--t60175fe010ccaf60);--tebfbbb84f6b5e5b9:var(--td59483778c9968d8);--t6f2ea937da3762cd:var(--t16358e7e6477feee);--td7c9881a4de36976:var(--te7e2290a567b22c3);--t7ab10821a9a38e07:var(--te7e2290a567b22c3);--tc93164b705392ee5:var(--te4a49aa32a6b93f3);--tebe6837248261a41:var(--te4a49aa32a6b93f3);--t3cdbe5bd7a07bede:var(--t03f846cb65ee139f);--t33ec501ef7aa1732:var(--t2f4c4b4988420773);--ta2a4ee4913f8a956:var(--t4836223a77e12d09);--tab8534ef038aa0fa:var(--t41b995405d7a6a52);--t329638ef3d6ac919:var(--te4a49aa32a6b93f3);--t0a57a7ae4a33205c:var(--t6d8e79ae61c770b4);--tf7b40ad5c33244a6:var(--t695bf178369c1b34);--t4d7e5b15f70139ef:var(--t695bf178369c1b34);--t5d3b44cda28eaae1:var(--te4a49aa32a6b93f3);--t2c09520dc82dd8ed:var(--t03f846cb65ee139f);--tf78a03b52584613a:var(--t2f4c4b4988420773);--t5431ff9f1b333bcb:var(--td66c30799fcd019f);--t22f58786b305bb6f:var(--t24e983d5a2effaf3);--t2c6b3f4a99d7dd0b:var(--te4a49aa32a6b93f3);--t7839770d085b0b4d:transparent;--t888e1f62a94fdfae:var(--taa8fd9ca5a0e5aff);--t03d5eac9e8805344:var(--t5e3e1a7b68d9f779);--tf38af22da2d552cb:var(--te7e2290a567b22c3);--tbfa623749bc8ac63:var(--te7e2290a567b22c3);--t806705902cda9388:var(--te4a49aa32a6b93f3);--t3ff8f9c93a56e733:var(--te4a49aa32a6b93f3);--t6157b9e200214dc9:var(--te7e2290a567b22c3);--t3a6553fda362956d:var(--te4a49aa32a6b93f3);--t15dcf3f93013a7ba:var(--te4a49aa32a6b93f3)}:root{--tfb93870d7246d03c:var(--t03f846cb65ee139f);--t45989b3bcb22f6dd:var(--t59ed5e2c247238f1);--t70990749324aca36:var(--te4a49aa32a6b93f3);--t6d2d91747ffc3f98:var(--t6124fe694ff1be5a);--tf7e68e6518cfb3cc:var(--te4a49aa32a6b93f3);--te229be082e76b81b:var(--t6124fe694ff1be5a);--t80e95d977575c16d:var(--te4a49aa32a6b93f3);--td7c27d8d43c16adb:var(--t6124fe694ff1be5a)}:root{--td2d005592644aac8:var(--t16358e7e6477feee);--t30866cc32fb8f0d4:var(--t16358e7e6477feee);--t5b35d265ba7ac78d:var(--te7e2290a567b22c3);--t931ee5ce260d19db:var(--t6124fe694ff1be5a);--tc27c69e8e46c24f5:var(--t41b995405d7a6a52);--tb2e91b152a81751d:var(--t4836223a77e12d09);--tef2dc00b8eacd690:var(--t41b995405d7a6a52);--t8ea1fa7fe56354ca:var(--t439f0062d041481a)}:root{--t6fd6e48dae1ae2e2:var(--t5e3e1a7b68d9f779);--t9347c1ebf94d8478:var(--t6124fe694ff1be5a);--t23818a9024c565e2:var(--t8e3f1cbcd575ae29);--t80a4b4f3e6b468ad:var(--t8e3f1cbcd575ae29);--t76852ee77be24891:var(--te4a49aa32a6b93f3);--td631f0d3538c6f97:var(--te4a49aa32a6b93f3);--tc3fb034f8f2e92a2:var(--ta03cbc43ae93f982);--te19a65a4756532a5:var(--t2f4c4b4988420773);--t40d1263a5dc0889f:var(--t03f846cb65ee139f);--td72dfbc38f12f498:var(--t5e3e1a7b68d9f779)}:root{--t14f872f9e689f321:#e37400;--t99854c0b295cdcd0:#fef7e0;--t48fce8ea4c21ee44:#5f6368;--t944bfe6984dd6904:#8ab4f8;--t5b340f0a892d598a:#2a2b2e;--t60175fe010ccaf60:#f1f3f4;--t2110097e9f647d54:#1a73e8;--ta64e77119895d0a5:#3c4043;--tf68e49e68b7efcd1:#d93025;--t150db0579d037d35:#fce8e6;--t4836223a77e12d09:#f1f3f4;--tdc392c0f954451bb:#fff;--te298918552000ed2:#b05b00;--tba95d9ffeddf4d24:#9aa0a6;--td59483778c9968d8:#bdc1c6;--tfb2050fb48dff7d9:#c5221f;--t41b995405d7a6a52:#202124;--t439f0062d041481a:#70757a;--t191274c1fdbddaa9:#137333;--t24e983d5a2effaf3:#1967d2;--te7e2290a567b22c3:#202124;--t6124fe694ff1be5a:#70757a;--t5d153b3c14c81857:#202124;--t8e3f1cbcd575ae29:#dadce0;--t02320a9adba8a46d:#f1f3f4;--taa8fd9ca5a0e5aff:#dadce0;--t15119ab90dead445:#188038;--td2e68be7dec6d104:#e6f4ea;--te4a49aa32a6b93f3:#1a73e8;--t6d8e79ae61c770b4:#1a73e8;--td66c30799fcd019f:#e8f0fe;--t00acce3e8155018e:#fbbc04;--t825160bd354dee0a:#fff}@supports (background-color:rgb(from #1a73e8 r g b/0.5)){:root{--web-maps-color-state-layer-primary-hover:rgb(from var(--te4a49aa32a6b93f3) r g b / 0.08);--web-maps-color-state-layer-primary-pressed:rgb(from var(--te4a49aa32a6b93f3) r g b / 0.12);--web-maps-color-state-layer-primary-focus:rgb(from var(--te4a49aa32a6b93f3) r g b / 0.12);--web-maps-color-state-layer-primary-hover-and-focus:rgb(from var(--te4a49aa32a6b93f3) r g b / 0.16);--web-maps-color-state-layer-on-constant-dark-hover:rgba(255,255,255,0.078);--web-maps-color-state-layer-on-constant-dark-pressed:rgba(255,255,255,0.122);--web-maps-color-state-layer-on-constant-dark-focus:rgba(255,255,255,0.122);--web-maps-color-state-layer-on-constant-dark-hover-and-focus:rgba(255,255,255,0.161);--web-maps-color-state-layer-on-primary-container-hover:rgb(from var(--t695bf178369c1b34) r g b / 0.08);--web-maps-color-state-layer-on-primary-container-pressed:rgb(from var(--t695bf178369c1b34) r g b / 0.12);--web-maps-color-state-layer-on-primary-container-focus:rgb(from var(--t695bf178369c1b34) r g b / 0.12);--web-maps-color-state-layer-on-primary-container-hover-and-focus:rgb(from var(--t695bf178369c1b34) r g b / 0.16);--web-maps-color-state-layer-on-neutral-container-hover:rgb(from var(--t41b995405d7a6a52) r g b / 0.08);--web-maps-color-state-layer-on-neutral-container-pressed:rgb(from var(--t41b995405d7a6a52) r g b / 0.12);--web-maps-color-state-layer-on-neutral-container-focus:rgb(from var(--t41b995405d7a6a52) r g b / 0.12);--web-maps-color-state-layer-on-neutral-container-hover-and-focus:rgb(from var(--t41b995405d7a6a52) r g b / 0.16);--web-maps-color-state-layer-on-secondary-container-hover:rgb(from var(--t24e983d5a2effaf3) r g b / 0.08);--web-maps-color-state-layer-on-secondary-container-pressed:rgb(from var(--t24e983d5a2effaf3) r g b / 0.12);--web-maps-color-state-layer-on-secondary-container-focus:rgb(from var(--t24e983d5a2effaf3) r g b / 0.12);--web-maps-color-state-layer-on-secondary-container-hover-and-focus:rgb(from var(--t24e983d5a2effaf3) r g b / 0.16);--web-maps-color-state-layer-on-surface-hover:rgb(from var(--te7e2290a567b22c3) r g b / 0.08);--web-maps-color-state-layer-on-surface-pressed:rgb(from var(--te7e2290a567b22c3) r g b / 0.12);--web-maps-color-state-layer-on-surface-focus:rgb(from var(--te7e2290a567b22c3) r g b / 0.12);--web-maps-color-state-layer-on-surface-hover-and-focus:rgb(from var(--te7e2290a567b22c3) r g b / 0.16);--web-maps-color-state-layer-on-askmaps-container-hover:rgba(52,91,241,0.078);--web-maps-color-state-layer-on-askmaps-container-pressed:rgba(52,91,241,0.122);--web-maps-color-state-layer-on-askmaps-container-focus:rgba(52,91,241,0.122);--web-maps-color-state-layer-on-askmaps-container-hover-and-focus:rgba(52,91,241,0.161)}}@supports not (background-color:rgb(from #1a73e8 r g b/0.5)){:root{--web-maps-color-state-layer-on-primary-container-hover:rgba(255,255,255,0.08);--web-maps-color-state-layer-on-primary-container-pressed:rgba(255,255,255,0.12);--web-maps-color-state-layer-on-primary-container-focus:rgba(255,255,255,0.12);--web-maps-color-state-layer-on-primary-container-hover-and-focus:rgba(255,255,255,0.16);--web-maps-color-state-layer-on-secondary-container-hover:rgba(26,115,232,0.08);--web-maps-color-state-layer-on-secondary-container-pressed:rgba(26,115,232,0.12);--web-maps-color-state-layer-on-secondary-container-focus:rgba(26,115,232,0.12);--web-maps-color-state-layer-on-secondary-container-hover-and-focus:rgba(26,115,232,0.16);--web-maps-color-state-layer-on-surface-hover:rgba(31,31,31,0.08);--web-maps-color-state-layer-on-surface-pressed:rgba(31,31,31,0.12);--web-maps-color-state-layer-on-surface-focus:rgba(31,31,31,0.12);--web-maps-color-state-layer-on-surface-hover-and-focus:rgba(31,31,31,0.16)}}.mapsConsumerUiSceneCoreScenecommon__impressCanvas{display:none}.mapsConsumerUiSceneCoreScenecommon__activated.mapsConsumerUiSceneCoreScenecommon__impressCanvas{display:block}.mapsConsumerUiSceneCoreScenecommon__impressIndicator{position:absolute;visibility:hidden}.mapsConsumerUiSceneCoreScenecommon__activated.mapsConsumerUiSceneCoreScenecommon__impressCanvas+.mapsConsumerUiSceneCoreScenecommon__impressIndicator{visibility:inherit;top:50%;right:25px;width:10px;height:10px;background-color:var(--t15119ab90dead445)}.mapsConsumerLibAppPrint__printMode .mapsConsumerUiSceneCoreScenecommon__impressIndicator,.mapsConsumerLibAppPrint__printMode .mapsConsumerUiSceneCoreScenecommon__noprint,.mapsConsumerUiSceneCoreScenecommon__impressCanvas.mapsConsumerUiSceneCoreScenecommon__impressHidden,.mapsConsumerUiSceneCoreScenecommon__impressHidden,.mapsConsumerUiSceneCoreScenecommon__impressIndicator.mapsConsumerUiSceneCoreScenecommon__impressHidden{display:none}.mapsConsumerUiSceneCoreScenecommon__effects{position:absolute;left:0;top:0;z-index:2}.mapsConsumerUiSceneCoreScenecommon__imageryRender{position:absolute;right:0;top:0;z-index:1;background-color:#000}.mapsConsumerLibAppPrint__printMode .mapsConsumerUiSceneCoreScenecommon__imageryRender{position:relative;background:#fff;z-index:4}.mapsImagerySceneScene__root{width:100%;height:100%;overflow:hidden;position:absolute;z-index:0;background-color:#000}.mapsConsumerLibAppKeynav__on .mapsImagerySceneScene__root:focus .mapsImagerySceneScene__focusOutline,.mapsImagerySceneScene__root:focus-visible .mapsImagerySceneScene__focusOutline{border:2px solid var(--te4a49aa32a6b93f3);-webkit-box-sizing:border-box;box-sizing:border-box;height:100%;pointer-events:none;position:absolute;width:100%;z-index:1}.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__root:focus .mapsImagerySceneScene__focusOutline{display:none}.mapsImagerySceneScene__root .widget-scene-imagery-iframe{position:absolute}.mapsImagerySceneScene__canvas{background-color:#000;right:0;outline:none;position:absolute;top:0}.mapsImagerySceneScene__captureCanvas{position:relative;z-index:3}.mapsImagerySceneScene__tileImage3d{-webkit-backface-visibility:hidden;backface-visibility:hidden}.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__captureCanvas{width:100%;height:auto;-webkit-transform:none;-ms-transform:none;transform:none}.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__root{background:#fff;position:static;overflow:visible}.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__canvas{display:block;background:#fff}.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__canvas.mapsConsumerUiSceneCoreScenecommon__noprint{display:none}.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__root .widget-scene-imagery-iframe{position:relative}@media print{.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__root .widget-scene-imagery-iframe{right:50%;-webkit-transform:translateX(50%);-ms-transform:translateX(50%);transform:translateX(50%)}}.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__root .mapsImagerySceneScene__canvas{position:static}.mapsConsumerLibAppPrint__printMode .mapsImagerySceneScene__captureCanvas~.mapsImagerySceneScene__canvas{display:none}sentinel{}\n`;
  function As(a, b) {
    this.x = a !== void 0 ? a : 0;
    this.y = b !== void 0 ? b : 0;
  }
  p = As.prototype;
  p.clone = function () {
    return new As(this.x, this.y);
  };
  p.equals = function (a) {
    return (
      a instanceof As &&
      (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    );
  };
  p.ceil = function () {
    this.x = Math.ceil(this.x);
    this.y = Math.ceil(this.y);
    return this;
  };
  p.floor = function () {
    this.x = Math.floor(this.x);
    this.y = Math.floor(this.y);
    return this;
  };
  p.round = function () {
    this.x = Math.round(this.x);
    this.y = Math.round(this.y);
    return this;
  };
  p.translate = function (a, b) {
    a instanceof As
      ? ((this.x += a.x), (this.y += a.y))
      : ((this.x += Number(a)), typeof b === "number" && (this.y += b));
    return this;
  };
  p.scale = function (a, b) {
    b = typeof b === "number" ? b : a;
    this.x *= a;
    this.y *= b;
    return this;
  };
  function Bs(a) {
    return a ? new Cs(Ds(a)) : Ha || (Ha = new Cs());
  }
  function Es(a, b, c, d) {
    a = d || a;
    return (b = b && b != "*" ? String(b).toUpperCase() : "") || c
      ? a.querySelectorAll(b + (c ? "." + c : ""))
      : a.getElementsByTagName("*");
  }
  function Fs(a, b) {
    Gm(b, function (c, d) {
      d == "style"
        ? (a.style.cssText = c)
        : d == "class"
        ? (a.className = c)
        : d == "for"
        ? (a.htmlFor = c)
        : Gs.hasOwnProperty(d)
        ? a.setAttribute(Gs[d], c)
        : d.lastIndexOf("aria-", 0) == 0 || d.lastIndexOf("data-", 0) == 0
        ? a.setAttribute(d, c)
        : (a[d] = c);
    });
  }
  var Gs = {
    cellpadding: "cellPadding",
    cellspacing: "cellSpacing",
    colspan: "colSpan",
    frameborder: "frameBorder",
    height: "height",
    maxlength: "maxLength",
    nonce: "nonce",
    role: "role",
    rowspan: "rowSpan",
    type: "type",
    usemap: "useMap",
    valign: "vAlign",
    width: "width",
  };
  function Hs(a, b, c) {
    return Is(document, arguments);
  }
  function Is(a, b) {
    var c = b[1],
      d = Js(a, String(b[0]));
    c &&
      (typeof c === "string"
        ? (d.className = c)
        : Array.isArray(c)
        ? (d.className = c.join(" "))
        : Fs(d, c));
    b.length > 2 && Ks(a, d, b);
    return d;
  }
  function Ks(a, b, c) {
    function d(e) {
      e && b.appendChild(typeof e === "string" ? a.createTextNode(e) : e);
    }
    for (let e = 2; e < c.length; e++) {
      let f = c[e];
      !pa(f) || (ra(f) && f.nodeType > 0)
        ? d(f)
        : rb(
            f && typeof f.length == "number" && typeof f.item == "function"
              ? Db(f)
              : f,
            d
          );
    }
  }
  function Js(a, b) {
    b = String(b);
    a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
    return a.createElement(b);
  }
  function Ls(a) {
    for (var b; (b = a.firstChild); ) a.removeChild(b);
  }
  function Ms(a) {
    a && a.parentNode && a.parentNode.removeChild(a);
  }
  function Ns(a) {
    return ra(a) && a.nodeType == 1;
  }
  function Os(a, b) {
    return a && b ? a == b || a.contains(b) : !1;
  }
  function Ds(a) {
    return a.nodeType == 9 ? a : a.ownerDocument || a.document;
  }
  function Ps() {
    var a = window;
    return a.devicePixelRatio !== void 0
      ? a.devicePixelRatio
      : a.matchMedia
      ? Qs(3) || Qs(2) || Qs(1.5) || Qs(1) || 0.75
      : 1;
  }
  function Qs(a) {
    return window.matchMedia(
      "(min-resolution: " +
        a +
        "dppx),(min--moz-device-pixel-ratio: " +
        a +
        "),(min-resolution: " +
        a * 96 +
        "dpi)"
    ).matches
      ? a
      : 0;
  }
  function Cs(a) {
    this.A = a || u.document || document;
  }
  p = Cs.prototype;
  p.ia = function () {};
  p.B = function (a, b, c) {
    return Is(this.A, arguments);
  };
  function Rs(a, b) {
    return Js(a.A, b);
  }
  p.appendChild = function (a, b) {
    a.appendChild(b);
  };
  p.isElement = Ns;
  p.contains = Os;
  function Ss(a, b, c, d) {
    this.top = a;
    this.right = b;
    this.bottom = c;
    this.left = d;
  }
  p = Ss.prototype;
  p.S = function () {
    return this.right - this.left;
  };
  p.R = function () {
    return this.bottom - this.top;
  };
  p.clone = function () {
    return new Ss(this.top, this.right, this.bottom, this.left);
  };
  p.contains = function (a) {
    return this && a
      ? a instanceof Ss
        ? a.left >= this.left &&
          a.right <= this.right &&
          a.top >= this.top &&
          a.bottom <= this.bottom
        : a.x >= this.left &&
          a.x <= this.right &&
          a.y >= this.top &&
          a.y <= this.bottom
      : !1;
  };
  p.ceil = function () {
    this.top = Math.ceil(this.top);
    this.right = Math.ceil(this.right);
    this.bottom = Math.ceil(this.bottom);
    this.left = Math.ceil(this.left);
    return this;
  };
  p.floor = function () {
    this.top = Math.floor(this.top);
    this.right = Math.floor(this.right);
    this.bottom = Math.floor(this.bottom);
    this.left = Math.floor(this.left);
    return this;
  };
  p.round = function () {
    this.top = Math.round(this.top);
    this.right = Math.round(this.right);
    this.bottom = Math.round(this.bottom);
    this.left = Math.round(this.left);
    return this;
  };
  p.translate = function (a, b) {
    a instanceof As
      ? ((this.left += a.x),
        (this.right += a.x),
        (this.top += a.y),
        (this.bottom += a.y))
      : ((this.left += a),
        (this.right += a),
        typeof b === "number" && ((this.top += b), (this.bottom += b)));
    return this;
  };
  p.scale = function (a, b) {
    b = typeof b === "number" ? b : a;
    this.left *= a;
    this.right *= a;
    this.top *= b;
    this.bottom *= b;
    return this;
  };
  function Ts(a, b, c, d) {
    this.left = a;
    this.top = b;
    this.width = c;
    this.height = d;
  }
  p = Ts.prototype;
  p.clone = function () {
    return new Ts(this.left, this.top, this.width, this.height);
  };
  p.intersection = function (a) {
    var b = Math.max(this.left, a.left),
      c = Math.min(this.left + this.width, a.left + a.width);
    if (b <= c) {
      let d = Math.max(this.top, a.top);
      a = Math.min(this.top + this.height, a.top + a.height);
      if (d <= a)
        return (
          (this.left = b),
          (this.top = d),
          (this.width = c - b),
          (this.height = a - d),
          !0
        );
    }
    return !1;
  };
  p.difference = function (a) {
    b: {
      var b = Math.max(this.left, a.left);
      var c = Math.min(this.left + this.width, a.left + a.width);
      if (b <= c) {
        var d = Math.max(this.top, a.top),
          e = Math.min(this.top + this.height, a.top + a.height);
        if (d <= e) {
          b = new Ts(b, d, c - b, e - d);
          break b;
        }
      }
      b = null;
    }
    if (b && b.height && b.width) {
      b = [];
      c = this.top;
      d = this.height;
      e = this.left + this.width;
      var f = this.top + this.height,
        g = a.left + a.width,
        h = a.top + a.height;
      a.top > this.top &&
        (b.push(new Ts(this.left, this.top, this.width, a.top - this.top)),
        (c = a.top),
        (d -= a.top - this.top));
      h < f && (b.push(new Ts(this.left, h, this.width, f - h)), (d = h - c));
      a.left > this.left && b.push(new Ts(this.left, c, a.left - this.left, d));
      g < e && b.push(new Ts(g, c, e - g, d));
      a = b;
    } else a = [this.clone()];
    return a;
  };
  p.contains = function (a) {
    return a instanceof As
      ? a.x >= this.left &&
          a.x <= this.left + this.width &&
          a.y >= this.top &&
          a.y <= this.top + this.height
      : this.left <= a.left &&
          this.left + this.width >= a.left + a.width &&
          this.top <= a.top &&
          this.top + this.height >= a.top + a.height;
  };
  p.distance = function (a) {
    var b =
      a.x < this.left
        ? this.left - a.x
        : Math.max(a.x - (this.left + this.width), 0);
    a =
      a.y < this.top
        ? this.top - a.y
        : Math.max(a.y - (this.top + this.height), 0);
    return Math.sqrt(b * b + a * a);
  };
  p.ceil = function () {
    this.left = Math.ceil(this.left);
    this.top = Math.ceil(this.top);
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this;
  };
  p.floor = function () {
    this.left = Math.floor(this.left);
    this.top = Math.floor(this.top);
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this;
  };
  p.round = function () {
    this.left = Math.round(this.left);
    this.top = Math.round(this.top);
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this;
  };
  p.translate = function (a, b) {
    a instanceof As
      ? ((this.left += a.x), (this.top += a.y))
      : ((this.left += a), typeof b === "number" && (this.top += b));
    return this;
  };
  p.scale = function (a, b) {
    b = typeof b === "number" ? b : a;
    this.left *= a;
    this.width *= a;
    this.top *= b;
    this.height *= b;
    return this;
  };
  var Us = /^--.+/,
    Vs = {};
  function Ws(a, b) {
    a: {
      var c = Ds(a);
      if (
        c.defaultView &&
        c.defaultView.getComputedStyle &&
        (c = c.defaultView.getComputedStyle(a, null))
      ) {
        c = c[b] || c.getPropertyValue(b) || "";
        break a;
      }
      c = "";
    }
    return (
      c ||
      (a.currentStyle ? a.currentStyle[b] : null) ||
      (a.style && a.style[b])
    );
  }
  function Xs(a) {
    try {
      return a.getBoundingClientRect();
    } catch (b) {
      return { left: 0, top: 0, right: 0, bottom: 0 };
    }
  }
  function Ys(a, b, c) {
    if (b instanceof Eo) (c = b.height), (b = b.width);
    else if (c == void 0) throw Error("missing height argument");
    a.style.width = Zs(b);
    a.style.height = Zs(c);
  }
  function Zs(a) {
    typeof a == "number" && (a = Math.round(a) + "px");
    return a;
  }
  function $s(a) {
    var b = at;
    if (Ws(a, "display") != "none") return b(a);
    var c = a.style,
      d = c.display,
      e = c.visibility,
      f = c.position;
    c.visibility = "hidden";
    c.position = "absolute";
    c.display = "inline";
    a = b(a);
    c.display = d;
    c.position = f;
    c.visibility = e;
    return a;
  }
  function at(a) {
    var b = a.offsetWidth,
      c = a.offsetHeight,
      d = Nb && !b && !c;
    return (b === void 0 || d) && a.getBoundingClientRect
      ? ((a = Xs(a)), new Eo(a.right - a.left, a.bottom - a.top))
      : new Eo(b, c);
  }
  function bt(a, b) {
    a = a.style;
    "opacity" in a
      ? (a.opacity = b)
      : "MozOpacity" in a
      ? (a.MozOpacity = b)
      : "filter" in a &&
        (a.filter = b === "" ? "" : "alpha(opacity=" + Number(b) * 100 + ")");
  }
  function ct() {
    var a = zs,
      b = Bs(),
      c = Es(b.A, "HEAD")[0];
    if (!c) {
      var d = Es(b.A, "BODY")[0];
      c = b.B("HEAD");
      d.parentNode.insertBefore(c, d);
    }
    d = b.B("STYLE");
    var e;
    (e = On("style", document)) && d.setAttribute("nonce", e);
    a = Sn(a);
    if (u.trustedTypes)
      if ("textContent" in d) d.textContent = a;
      else if (d.nodeType == 3) d.data = String(a);
      else if (d.firstChild && d.firstChild.nodeType == 3) {
        for (; d.lastChild != d.firstChild; ) d.removeChild(d.lastChild);
        d.firstChild.data = String(a);
      } else Ls(d), d.appendChild(Ds(d).createTextNode(String(a)));
    else d.innerHTML = a;
    b.appendChild(c, d);
  }
  function dt(a, b, c, d, e, f, g) {
    var h = b[0];
    b = b[1];
    var k = d[0];
    d = d[1];
    var l = f[0],
      m = f[1],
      n = d - m,
      q = m - b,
      r = b - d;
    f = h * n + k * q + l * r;
    if (f === 0) return !1;
    f = 1 / f;
    n *= f;
    var t = (l - k) * f,
      v = (k * m - l * d) * f;
    q *= f;
    var F = (h - l) * f;
    l = (l * b - h * m) * f;
    r *= f;
    m = (k - h) * f;
    h = (h * d - k * b) * f;
    g[0] = a[0] * n + c[0] * q + e[0] * r;
    g[1] = a[1] * n + c[1] * q + e[1] * r;
    g[2] = 0;
    g[3] = a[0] * t + c[0] * F + e[0] * m;
    g[4] = a[1] * t + c[1] * F + e[1] * m;
    g[5] = 0;
    g[6] = a[0] * v + c[0] * l + e[0] * h;
    g[7] = a[1] * v + c[1] * l + e[1] * h;
    g[8] = 1;
    return !(Math.abs(g[0]) < 1e-6 || Math.abs(g[4]) < 1e-6);
  }
  var ft = class {
    constructor(a) {
      this.label = a;
      this.texture = null;
      this.B = this.C = !1;
      this.A = new Float32Array(8);
    }
    Ka() {
      return this.C;
    }
    Gb() {
      if (!this.Ka() && !this.B) {
        var a = et(this.label.A);
        if (a) {
          this.C = !0;
          {
            let d = a.width,
              e = a.height,
              f = document.createElement("canvas");
            f.width = d;
            if ((f.height = e)) {
              var b = f.getContext("2d"),
                c = 0;
              for (let g = 0; g < d; g += 30) {
                let h = 30;
                g + 30 > d && (h = d - g);
                let k = Math.max(e * (1 - g * 4e-4), 0),
                  l = Math.max(h * (1 - g * 4e-4), 0) * 0.6;
                b.drawImage(a, g, 0, h, e, c, (e - k) / 2, l, k);
                c += l;
              }
            }
            a = f;
          }
          this.texture = a;
          this.A[0] = this.A[1] = 0;
          this.A[2] = 0;
          this.A[3] = 0.5 * this.texture.height;
          this.A[4] = 0.5 * this.texture.width;
          this.A[5] = 0.5 * this.texture.height;
          this.A[6] = 0.5 * this.texture.width;
          this.A[7] = 0;
        } else this.B = !0;
      }
    }
  };
  function gt(a) {
    for (; a.A > a.B; ) {
      let b = a.tail;
      b.B(b.handle);
      a.remove(b.handle);
    }
  }
  function ht(a, b) {
    (b = a.entries[b]) &&
      b.A &&
      ((b.A.next = b.next) ? (b.next.A = b.A) : (a.tail = b.A),
      (b.A = null),
      (b.next = a.head),
      (a.head.A = b),
      (a.head = b));
  }
  var jt = class {
    constructor(a = 0) {
      this.B = a;
      this.C = this.A = 0;
      this.tail = this.head = null;
      this.entries = {};
    }
    add(a, b) {
      if (a > this.B) return -1;
      var c = this.C++;
      b = new it(c, b, a, this.head);
      this.entries[c] = b;
      this.head && (this.head.A = b);
      this.head = b;
      this.A += a;
      this.tail == null && (this.tail = b);
      gt(this);
      return c;
    }
    remove(a) {
      var b = this.entries[a];
      b &&
        (b.A ? (b.A.next = b.next) : (this.head = b.next),
        b.next ? (b.next.A = b.A) : (this.tail = b.A),
        (b.A = b.next = null),
        delete this.entries[a],
        (this.A -= b.size));
    }
    resize(a, b) {
      var c = this.entries[a];
      if (!c) return !1;
      if (b > this.B) return c.B && c.B(a), this.remove(a), !1;
      this.A -= c.size;
      c.size = b;
      this.A += c.size;
      gt(this);
      return a in this.entries;
    }
    contains(a) {
      return a in this.entries;
    }
    clear() {
      for (let a = this.head; a; a = a.next) a.B && a.B(a.handle);
      this.tail = this.head = null;
      this.entries = {};
      this.A = 0;
    }
  };
  class it {
    constructor(a, b, c, d) {
      this.handle = a;
      this.B = b;
      this.size = c;
      this.A = null;
      this.next = d;
    }
  }
  var kt = class {
    constructor(a, b = () => {}) {
      this.C = b;
      this.data = {};
      this.A = {};
      this.B = new jt(a);
    }
    setData(a, b) {
      var c = this.A[a];
      c !== void 0 && c !== -1
        ? ht(this.B, c)
        : ((c = this.B.add(1, () => {
            this.C(a, this.data[a]);
            delete this.A[a];
            delete this.data[a];
          })),
          (this.A[a] = c));
      this.data[a] = b;
    }
    getData(a) {
      var b = this.A[a];
      a = this.data[a];
      b !== void 0 && b !== -1 && ht(this.B, b);
      return a;
    }
    clear() {
      this.B.clear();
      this.data = {};
      this.A = {};
    }
  };
  function lt(a) {
    this.length = a.length || a;
    for (let b = 0; b < this.length; b++) this[b] = a[b] || 0;
  }
  lt.prototype.set = function (a, b) {
    b = b || 0;
    for (let c = 0; c < a.length && b + c < this.length; c++)
      this[b + c] = a[c];
  };
  lt.prototype.toString = Array.prototype.join;
  typeof Float32Array == "undefined" &&
    ((lt.BYTES_PER_ELEMENT = 4),
    (lt.prototype.BYTES_PER_ELEMENT = 4),
    (lt.prototype.set = lt.prototype.set),
    (lt.prototype.toString = lt.prototype.toString),
    ia("Float32Array", lt));
  function mt(a) {
    this.length = a.length || a;
    for (let b = 0; b < this.length; b++) this[b] = a[b] || 0;
  }
  mt.prototype.set = function (a, b) {
    b = b || 0;
    for (let c = 0; c < a.length && b + c < this.length; c++)
      this[b + c] = a[c];
  };
  mt.prototype.toString = Array.prototype.join;
  if (typeof Float64Array == "undefined") {
    try {
      mt.BYTES_PER_ELEMENT = 8;
    } catch (a) {}
    mt.prototype.BYTES_PER_ELEMENT = 8;
    mt.prototype.set = mt.prototype.set;
    mt.prototype.toString = mt.prototype.toString;
    ia("Float64Array", mt);
  }
  function nt(a, b) {
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
  }
  function ot(a, b) {
    var c = pt,
      d = a[0] - c[0],
      e = a[1] - c[1];
    a = a[2] - c[2];
    (c = Math.sqrt(d * d + e * e + a * a))
      ? ((c = 1 / c), (b[0] = d * c), (b[1] = e * c), (b[2] = a * c))
      : (b[0] = b[1] = b[2] = 0);
  }
  function qt(a, b) {
    return a.length == b.length && a[0] == b[0] && a[1] == b[1] && a[2] == b[2];
  }
  function Y() {
    return new Float64Array(3);
  }
  function rt(a, b, c, d) {
    a[0] = b;
    a[1] = c;
    a[2] = d;
    return a;
  }
  function st(a, b) {
    a[0] = b[0];
    a[1] = b[1];
    a[2] = b[2];
  }
  function tt(a, b, c) {
    c[0] = a[0] + b[0];
    c[1] = a[1] + b[1];
    c[2] = a[2] + b[2];
  }
  function ut(a, b, c) {
    c[0] = a[0] - b[0];
    c[1] = a[1] - b[1];
    c[2] = a[2] - b[2];
  }
  function vt(a, b, c) {
    c[0] = a[0] * b;
    c[1] = a[1] * b;
    c[2] = a[2] * b;
  }
  function wt(a) {
    var b = a[0],
      c = a[1];
    a = a[2];
    return Math.sqrt(b * b + c * c + a * a);
  }
  function xt(a, b) {
    var c = a[0],
      d = a[1];
    a = a[2];
    var e = 1 / Math.sqrt(c * c + d * d + a * a);
    b[0] = c * e;
    b[1] = d * e;
    b[2] = a * e;
  }
  function yt(a, b, c) {
    var d = a[0],
      e = a[1];
    a = a[2];
    var f = b[0],
      g = b[1];
    b = b[2];
    c[0] = e * b - a * g;
    c[1] = a * f - d * b;
    c[2] = d * g - e * f;
  }
  function zt(a, b) {
    var c = a[0] - b[0],
      d = a[1] - b[1];
    a = a[2] - b[2];
    return c * c + d * d + a * a;
  }
  function At() {
    return new Float64Array(4);
  }
  function Bt(a, b, c) {
    c[0] = a[0] * b;
    c[1] = a[1] * b;
    c[2] = a[2] * b;
    c[3] = a[3] * b;
  }
  function Ct() {
    return new Float64Array(16);
  }
  function Dt(a, b) {
    a[0] = b[0];
    a[1] = b[1];
    a[2] = b[2];
    a[3] = b[3];
    a[4] = b[4];
    a[5] = b[5];
    a[6] = b[6];
    a[7] = b[7];
    a[8] = b[8];
    a[9] = b[9];
    a[10] = b[10];
    a[11] = b[11];
    a[12] = b[12];
    a[13] = b[13];
    a[14] = b[14];
    a[15] = b[15];
  }
  function Et(a, b) {
    a[0] = b[0];
    a[1] = b[1];
    a[2] = b[2];
    a[3] = b[3];
    a[4] = b[4];
    a[5] = b[5];
    a[6] = b[6];
    a[7] = b[7];
    a[8] = b[8];
    a[9] = b[9];
    a[10] = b[10];
    a[11] = b[11];
    a[12] = b[12];
    a[13] = b[13];
    a[14] = b[14];
    a[15] = b[15];
  }
  function Ft(a, b, c) {
    b *= 4;
    c[0] = a[b];
    c[1] = a[b + 1];
    c[2] = a[b + 2];
    c[3] = a[b + 3];
  }
  function Gt(a, b, c) {
    a[b] = c[0];
    a[b + 4] = c[1];
    a[b + 8] = c[2];
    a[b + 12] = c[3];
  }
  function Ht(a, b, c) {
    c[0] = a[b];
    c[1] = a[b + 4];
    c[2] = a[b + 8];
    c[3] = a[b + 12];
  }
  function It(a) {
    a[0] = 1;
    a[1] = 0;
    a[2] = 0;
    a[3] = 0;
    a[4] = 0;
    a[5] = 1;
    a[6] = 0;
    a[7] = 0;
    a[8] = 0;
    a[9] = 0;
    a[10] = 1;
    a[11] = 0;
    a[12] = 0;
    a[13] = 0;
    a[14] = 0;
    a[15] = 1;
  }
  function Jt(a, b, c) {
    var d = a[0],
      e = a[1],
      f = a[2],
      g = a[3],
      h = a[4],
      k = a[5],
      l = a[6],
      m = a[7],
      n = a[8],
      q = a[9],
      r = a[10],
      t = a[11],
      v = a[12],
      F = a[13],
      H = a[14];
    a = a[15];
    var I = b[0],
      J = b[1],
      ja = b[2],
      ua = b[3],
      ka = b[4],
      ya = b[5],
      ma = b[6],
      L = b[7],
      Fa = b[8],
      ea = b[9],
      za = b[10],
      da = b[11],
      lb = b[12],
      sb = b[13],
      Hb = b[14];
    b = b[15];
    c[0] = d * I + h * J + n * ja + v * ua;
    c[1] = e * I + k * J + q * ja + F * ua;
    c[2] = f * I + l * J + r * ja + H * ua;
    c[3] = g * I + m * J + t * ja + a * ua;
    c[4] = d * ka + h * ya + n * ma + v * L;
    c[5] = e * ka + k * ya + q * ma + F * L;
    c[6] = f * ka + l * ya + r * ma + H * L;
    c[7] = g * ka + m * ya + t * ma + a * L;
    c[8] = d * Fa + h * ea + n * za + v * da;
    c[9] = e * Fa + k * ea + q * za + F * da;
    c[10] = f * Fa + l * ea + r * za + H * da;
    c[11] = g * Fa + m * ea + t * za + a * da;
    c[12] = d * lb + h * sb + n * Hb + v * b;
    c[13] = e * lb + k * sb + q * Hb + F * b;
    c[14] = f * lb + l * sb + r * Hb + H * b;
    c[15] = g * lb + m * sb + t * Hb + a * b;
  }
  function Kt(a, b) {
    var c = a[0],
      d = a[1],
      e = a[2],
      f = a[3],
      g = a[4],
      h = a[5],
      k = a[6],
      l = a[7],
      m = a[8],
      n = a[9],
      q = a[10],
      r = a[11],
      t = a[12],
      v = a[13],
      F = a[14];
    a = a[15];
    var H = c * h - d * g,
      I = c * k - e * g,
      J = c * l - f * g,
      ja = d * k - e * h,
      ua = d * l - f * h,
      ka = e * l - f * k,
      ya = m * v - n * t,
      ma = m * F - q * t,
      L = m * a - r * t,
      Fa = n * F - q * v,
      ea = n * a - r * v,
      za = q * a - r * F,
      da = H * za - I * ea + J * Fa + ja * L - ua * ma + ka * ya;
    da != 0 &&
      ((da = 1 / da),
      (b[0] = (h * za - k * ea + l * Fa) * da),
      (b[1] = (-d * za + e * ea - f * Fa) * da),
      (b[2] = (v * ka - F * ua + a * ja) * da),
      (b[3] = (-n * ka + q * ua - r * ja) * da),
      (b[4] = (-g * za + k * L - l * ma) * da),
      (b[5] = (c * za - e * L + f * ma) * da),
      (b[6] = (-t * ka + F * J - a * I) * da),
      (b[7] = (m * ka - q * J + r * I) * da),
      (b[8] = (g * ea - h * L + l * ya) * da),
      (b[9] = (-c * ea + d * L - f * ya) * da),
      (b[10] = (t * ua - v * J + a * H) * da),
      (b[11] = (-m * ua + n * J - r * H) * da),
      (b[12] = (-g * Fa + h * ma - k * ya) * da),
      (b[13] = (c * Fa - d * ma + e * ya) * da),
      (b[14] = (-t * ja + v * I - F * H) * da),
      (b[15] = (m * ja - n * I + q * H) * da));
  }
  function Lt(a, b, c) {
    var d = b[0],
      e = b[1];
    b = b[2];
    c[0] = d * a[0] + e * a[4] + b * a[8] + a[12];
    c[1] = d * a[1] + e * a[5] + b * a[9] + a[13];
    c[2] = d * a[2] + e * a[6] + b * a[10] + a[14];
  }
  function Mt(a, b, c) {
    var d = b[0],
      e = b[1];
    b = b[2];
    c[0] = d * a[0] + e * a[4] + b * a[8];
    c[1] = d * a[1] + e * a[5] + b * a[9];
    c[2] = d * a[2] + e * a[6] + b * a[10];
  }
  function Nt(a, b, c) {
    var d = b[3],
      e = b[0],
      f = b[1];
    b = b[2];
    c[0] = e * a[0] + f * a[4] + b * a[8] + d * a[12];
    c[1] = e * a[1] + f * a[5] + b * a[9] + d * a[13];
    c[2] = e * a[2] + f * a[6] + b * a[10] + d * a[14];
    c[3] = e * a[3] + f * a[7] + b * a[11] + d * a[15];
  }
  function Ot(a, b, c, d) {
    a[0] = b;
    a[1] = 0;
    a[2] = 0;
    a[3] = 0;
    a[4] = 0;
    a[5] = c;
    a[6] = 0;
    a[7] = 0;
    a[8] = 0;
    a[9] = 0;
    a[10] = d;
    a[11] = 0;
    a[12] = 0;
    a[13] = 0;
    a[14] = 0;
    a[15] = 1;
  }
  function Pt(a, b, c, d, e) {
    var f = b / 2;
    b = e - d;
    var g = Math.sin(f);
    b != 0 &&
      g != 0 &&
      c != 0 &&
      ((f = Math.cos(f) / g),
      (a[0] = f / c),
      (a[1] = 0),
      (a[2] = 0),
      (a[3] = 0),
      (a[4] = 0),
      (a[5] = f),
      (a[6] = 0),
      (a[7] = 0),
      (a[8] = 0),
      (a[9] = 0),
      (a[10] = -(e + d) / b),
      (a[11] = -1),
      (a[12] = 0),
      (a[13] = 0),
      (a[14] = -(2 * d * e) / b),
      (a[15] = 0));
  }
  function Qt(a, b, c, d) {
    var e = Rt[0];
    ut(c, b, e);
    xt(e, e);
    e[3] = 0;
    c = Rt[1];
    yt(e, d, c);
    xt(c, c);
    c[3] = 0;
    d = Rt[2];
    yt(c, e, d);
    xt(d, d);
    d[3] = 0;
    e[0] = -e[0];
    e[1] = -e[1];
    e[2] = -e[2];
    Gt(a, 0, c);
    Gt(a, 1, d);
    Gt(a, 2, e);
    a[3] = 0;
    a[7] = 0;
    a[11] = 0;
    a[15] = 1;
    St(a, -b[0], -b[1], -b[2]);
  }
  function Tt(a, b, c, d) {
    var e = Math.cos(b);
    b = Math.sin(b);
    var f = Math.cos(c);
    c = Math.sin(c);
    var g = Math.cos(d);
    d = Math.sin(d);
    a[0] = e * g - f * b * d;
    a[1] = f * e * d + g * b;
    a[2] = d * c;
    a[3] = 0;
    a[4] = -e * d - g * f * b;
    a[5] = e * f * g - b * d;
    a[6] = g * c;
    a[7] = 0;
    a[8] = c * b;
    a[9] = -e * c;
    a[10] = f;
    a[11] = 0;
    a[12] = 0;
    a[13] = 0;
    a[14] = 0;
    a[15] = 1;
  }
  function St(a, b, c, d) {
    a[12] += a[0] * b + a[4] * c + a[8] * d;
    a[13] += a[1] * b + a[5] * c + a[9] * d;
    a[14] += a[2] * b + a[6] * c + a[10] * d;
    a[15] += a[3] * b + a[7] * c + a[11] * d;
  }
  function Ut(a, b, c, d) {
    a[0] *= b;
    a[1] *= b;
    a[2] *= b;
    a[3] *= b;
    a[4] *= c;
    a[5] *= c;
    a[6] *= c;
    a[7] *= c;
    a[8] *= d;
    a[9] *= d;
    a[10] *= d;
    a[11] *= d;
    a[12] = a[12];
    a[13] = a[13];
    a[14] = a[14];
    a[15] = a[15];
  }
  function Vt(a, b) {
    var c = a[4],
      d = a[5],
      e = a[6],
      f = a[7],
      g = a[8],
      h = a[9],
      k = a[10],
      l = a[11],
      m = Math.cos(b);
    b = Math.sin(b);
    a[4] = c * m + g * b;
    a[5] = d * m + h * b;
    a[6] = e * m + k * b;
    a[7] = f * m + l * b;
    a[8] = c * -b + g * m;
    a[9] = d * -b + h * m;
    a[10] = e * -b + k * m;
    a[11] = f * -b + l * m;
  }
  function Wt(a, b) {
    var c = a[0],
      d = a[1],
      e = a[2],
      f = a[3],
      g = a[8],
      h = a[9],
      k = a[10],
      l = a[11],
      m = Math.cos(b);
    b = Math.sin(b);
    a[0] = c * m + g * -b;
    a[1] = d * m + h * -b;
    a[2] = e * m + k * -b;
    a[3] = f * m + l * -b;
    a[8] = c * b + g * m;
    a[9] = d * b + h * m;
    a[10] = e * b + k * m;
    a[11] = f * b + l * m;
  }
  function Xt(a, b) {
    var c = a[0],
      d = a[1],
      e = a[2],
      f = a[3],
      g = a[4],
      h = a[5],
      k = a[6],
      l = a[7],
      m = Math.cos(b);
    b = Math.sin(b);
    a[0] = c * m + g * b;
    a[1] = d * m + h * b;
    a[2] = e * m + k * b;
    a[3] = f * m + l * b;
    a[4] = c * -b + g * m;
    a[5] = d * -b + h * m;
    a[6] = e * -b + k * m;
    a[7] = f * -b + l * m;
  }
  Y();
  Y();
  var Rt = [At(), At(), At()];
  Ct();
  function Yt(a, b) {
    var c = 2 * Math.atan(Math.exp(a[1])) - Math.PI / 2;
    Zt(a[0], c, a[2] * 6371010 * Math.cos(c), b, 6371010);
  }
  function $t(a, b) {
    var c = a[0],
      d = a[1],
      e = a[2];
    a = Math.atan2(e, Math.sqrt(c * c + d * d));
    e = Math.sqrt(c * c + d * d + e * e) - 6371010;
    b[0] = Math.atan2(d, c);
    b[1] = a;
    b[2] = e;
    c = b[1];
    d = b[2];
    a = Math.sin(c);
    b[1] = 0.5 * Math.log((1 + a) / (1 - a));
    b[2] = d / (Math.cos(c) * 6371010);
  }
  function au(a, b, c, d) {
    a = Bo(a);
    b = Bo(b);
    var e = e || 6371010;
    b = xo(b, -1.48442222974533, 1.48442222974533);
    d[0] = a;
    a = Math.sin(b);
    d[1] = 0.5 * Math.log((1 + a) / (1 - a));
    d[2] = c / (Math.cos(b) * e);
  }
  function bu(a, b, c, d) {
    b = 2 * Math.atan(Math.exp(b)) - Math.PI / 2;
    c = c * 6371010 * Math.cos(b);
    d[0] = a;
    d[1] = b;
    d[2] = c;
  }
  function cu(a) {
    a = Bo(a);
    a = xo(a, -1.48442222974533, 1.48442222974533);
    return 1 / (Math.cos(a) * 6371010);
  }
  function du(a, b, c, d, e) {
    Zt(Bo(a), Bo(b), c, d, e);
  }
  function Zt(a, b, c, d, e) {
    var f = Math.cos(b);
    c += e || 6371010;
    rt(d, c * f * Math.cos(a), c * f * Math.sin(a), c * Math.sin(b));
  }
  var eu = Y(),
    fu = Y(),
    gu = Y(),
    hu = Y(),
    iu = {
      earth: 6371010,
      mars: 3396e3,
      moon: 1737100,
      mercury: 2439700,
      venus: 6051800,
    };
  var ju = class {
    constructor() {
      this.height =
        this.width =
        this.N =
        this.L =
        this.C =
        this.D =
        this.K =
        this.J =
        this.I =
        this.B =
        this.A =
        this.M =
        this.H =
        this.G =
        this.F =
          void 0;
    }
    equals(a) {
      return (
        !!a &&
        this.F === a.F &&
        this.G === a.G &&
        this.H === a.H &&
        this.M === a.M &&
        this.A === a.A &&
        this.B === a.B &&
        this.I === a.I &&
        this.J === a.J &&
        this.K === a.K &&
        this.D === a.D &&
        this.C === a.C &&
        this.L === a.L &&
        this.N === a.N &&
        this.width === a.width &&
        this.height === a.height
      );
    }
  };
  var ku = new ju(),
    lu = Y();
  function mu(a, b) {
    var c = jj(a),
      d = mj(a),
      e = hj(a);
    a = a.Ga();
    ku.F = void 0;
    ku.G = void 0;
    ku.H = void 0;
    ku.L = void 0;
    ku.N = void 0;
    ku.J = -Bo(c.Ba());
    ku.K = Bo(c.za());
    ku.D = -Bo(c.Va());
    ku.C = Bo(a);
    ku.width = d.S();
    ku.height = d.R();
    au(Xi(e), Zi(e), aj(e), lu);
    ku.A = lu[0];
    ku.B = lu[1];
    ku.I = lu[2];
    c = 1 * cu(Zi(e));
    d = Math.abs(lu[2]);
    ku.M = d > c ? d : c;
    nu(b, ku);
    b.vg = 0;
  }
  function ou(a) {
    a && typeof a.dispose == "function" && a.dispose();
  }
  function pu() {
    this.V = this.V;
    this.K = this.K;
  }
  pu.prototype.V = !1;
  pu.prototype.M = function () {
    return this.V;
  };
  pu.prototype.dispose = function () {
    this.V || ((this.V = !0), this.B());
  };
  pu.prototype[Symbol.dispose] = function () {
    this.dispose();
  };
  function qu(a, b) {
    a.V ? b() : (a.K || (a.K = []), a.K.push(b));
  }
  pu.prototype.B = function () {
    if (this.K) for (; this.K.length; ) this.K.shift()();
  };
  function ru(a, b) {
    this.type = a;
    this.currentTarget = this.target = b;
    this.defaultPrevented = this.A = !1;
  }
  ru.prototype.stopPropagation = function () {
    this.A = !0;
  };
  ru.prototype.preventDefault = function () {
    this.defaultPrevented = !0;
  };
  function su(a, b) {
    ru.call(this, a ? a.type : "");
    this.relatedTarget = this.currentTarget = this.target = null;
    this.button =
      this.screenY =
      this.screenX =
      this.clientY =
      this.clientX =
      this.offsetY =
      this.offsetX =
        0;
    this.key = "";
    this.charCode = this.keyCode = 0;
    this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
    this.state = null;
    this.Mc = !1;
    this.pointerId = 0;
    this.pointerType = "";
    this.timeStamp = 0;
    this.hb = null;
    a && this.init(a, b);
  }
  Ea(su, ru);
  su.prototype.init = function (a, b) {
    var c = (this.type = a.type),
      d =
        a.changedTouches && a.changedTouches.length
          ? a.changedTouches[0]
          : null;
    this.target = a.target || a.srcElement;
    this.currentTarget = b;
    b = a.relatedTarget;
    b ||
      (c == "mouseover"
        ? (b = a.fromElement)
        : c == "mouseout" && (b = a.toElement));
    this.relatedTarget = b;
    d
      ? ((this.clientX = d.clientX !== void 0 ? d.clientX : d.pageX),
        (this.clientY = d.clientY !== void 0 ? d.clientY : d.pageY),
        (this.screenX = d.screenX || 0),
        (this.screenY = d.screenY || 0))
      : ((this.offsetX = Nb || a.offsetX !== void 0 ? a.offsetX : a.layerX),
        (this.offsetY = Nb || a.offsetY !== void 0 ? a.offsetY : a.layerY),
        (this.clientX = a.clientX !== void 0 ? a.clientX : a.pageX),
        (this.clientY = a.clientY !== void 0 ? a.clientY : a.pageY),
        (this.screenX = a.screenX || 0),
        (this.screenY = a.screenY || 0));
    this.button = a.button;
    this.keyCode = a.keyCode || 0;
    this.key = a.key || "";
    this.charCode = a.charCode || (c == "keypress" ? a.keyCode : 0);
    this.ctrlKey = a.ctrlKey;
    this.altKey = a.altKey;
    this.shiftKey = a.shiftKey;
    this.metaKey = a.metaKey;
    this.Mc = Pb ? a.metaKey : a.ctrlKey;
    this.pointerId = a.pointerId || 0;
    this.pointerType = a.pointerType;
    this.state = a.state;
    this.timeStamp = a.timeStamp;
    this.hb = a;
    a.defaultPrevented && su.qa.preventDefault.call(this);
  };
  su.prototype.stopPropagation = function () {
    su.qa.stopPropagation.call(this);
    this.hb.stopPropagation
      ? this.hb.stopPropagation()
      : (this.hb.cancelBubble = !0);
  };
  su.prototype.preventDefault = function () {
    su.qa.preventDefault.call(this);
    var a = this.hb;
    a.preventDefault ? a.preventDefault() : (a.returnValue = !1);
  };
  var tu = "closure_listenable_" + ((Math.random() * 1e6) | 0);
  function uu(a) {
    return !(!a || !a[tu]);
  }
  var vu = 0;
  function wu(a, b, c, d, e) {
    this.listener = a;
    this.proxy = null;
    this.src = b;
    this.type = c;
    this.capture = !!d;
    this.handler = e;
    this.key = ++vu;
    this.he = this.Ae = !1;
  }
  function xu(a) {
    a.he = !0;
    a.listener = null;
    a.proxy = null;
    a.src = null;
    a.handler = null;
  }
  function yu(a) {
    this.src = a;
    this.A = {};
    this.B = 0;
  }
  yu.prototype.add = function (a, b, c, d, e) {
    var f = a.toString();
    a = this.A[f];
    a || ((a = this.A[f] = []), this.B++);
    var g = zu(a, b, d, e);
    g > -1
      ? ((b = a[g]), c || (b.Ae = !1))
      : ((b = new wu(b, this.src, f, !!d, e)), (b.Ae = c), a.push(b));
    return b;
  };
  yu.prototype.remove = function (a, b, c, d) {
    a = a.toString();
    if (!(a in this.A)) return !1;
    var e = this.A[a];
    b = zu(e, b, c, d);
    return b > -1
      ? (xu(e[b]), Bb(e, b), e.length == 0 && (delete this.A[a], this.B--), !0)
      : !1;
  };
  function Au(a, b) {
    var c = b.type;
    if (!(c in a.A)) return !1;
    var d = zb(a.A[c], b);
    d && (xu(b), a.A[c].length == 0 && (delete a.A[c], a.B--));
    return d;
  }
  function Bu(a, b, c, d, e) {
    a = a.A[b.toString()];
    b = -1;
    a && (b = zu(a, c, d, e));
    return b > -1 ? a[b] : null;
  }
  function zu(a, b, c, d) {
    for (let e = 0; e < a.length; ++e) {
      let f = a[e];
      if (!f.he && f.listener == b && f.capture == !!c && f.handler == d)
        return e;
    }
    return -1;
  }
  var Cu = "closure_lm_" + ((Math.random() * 1e6) | 0),
    Du = {},
    Eu = 0;
  function Fu(a, b, c, d, e) {
    if (d && d.once) return Gu(a, b, c, d, e);
    if (Array.isArray(b)) {
      for (let f = 0; f < b.length; f++) Fu(a, b[f], c, d, e);
      return null;
    }
    c = Hu(c);
    return uu(a)
      ? a.listen(b, c, ra(d) ? !!d.capture : !!d, e)
      : Iu(a, b, c, !1, d, e);
  }
  function Iu(a, b, c, d, e, f) {
    if (!b) throw Error("Invalid event type");
    var g = ra(e) ? !!e.capture : !!e,
      h = Ju(a);
    h || (a[Cu] = h = new yu(a));
    c = h.add(b, c, d, g, f);
    if (c.proxy) return c;
    d = Ku();
    c.proxy = d;
    d.src = a;
    d.listener = c;
    if (a.addEventListener)
      e === void 0 && (e = !1), a.addEventListener(b.toString(), d, e);
    else if (a.attachEvent) a.attachEvent(Lu(b.toString()), d);
    else if (a.addListener && a.removeListener) a.addListener(d);
    else throw Error("addEventListener and attachEvent are unavailable.");
    Eu++;
    return c;
  }
  function Ku() {
    function a(c) {
      return b.call(a.src, a.listener, c);
    }
    var b = Mu;
    return a;
  }
  function Gu(a, b, c, d, e) {
    if (Array.isArray(b)) {
      for (let f = 0; f < b.length; f++) Gu(a, b[f], c, d, e);
      return null;
    }
    c = Hu(c);
    return uu(a)
      ? a.J.add(String(b), c, !0, ra(d) ? !!d.capture : !!d, e)
      : Iu(a, b, c, !0, d, e);
  }
  function Nu(a, b, c, d, e) {
    if (Array.isArray(b))
      for (let f = 0; f < b.length; f++) Nu(a, b[f], c, d, e);
    else
      (d = ra(d) ? !!d.capture : !!d),
        (c = Hu(c)),
        uu(a)
          ? a.N(b, c, d, e)
          : a && (a = Ju(a)) && (b = Bu(a, b, c, d, e)) && Ou(b);
  }
  function Ou(a) {
    if (typeof a === "number" || !a || a.he) return !1;
    var b = a.src;
    if (uu(b)) return Au(b.J, a);
    var c = a.type,
      d = a.proxy;
    b.removeEventListener
      ? b.removeEventListener(c, d, a.capture)
      : b.detachEvent
      ? b.detachEvent(Lu(c), d)
      : b.addListener && b.removeListener && b.removeListener(d);
    Eu--;
    (c = Ju(b))
      ? (Au(c, a), c.B == 0 && ((c.src = null), (b[Cu] = null)))
      : xu(a);
    return !0;
  }
  function Pu(a) {
    if (a)
      if (uu(a)) Qu(a);
      else if ((a = Ju(a))) {
        var b = 0;
        for (let c in a.A) {
          let d = a.A[c].concat();
          for (let e = 0; e < d.length; ++e) Ou(d[e]) && ++b;
        }
      }
  }
  function Lu(a) {
    return a in Du ? Du[a] : (Du[a] = "on" + a);
  }
  function Mu(a, b) {
    if (a.he) a = !0;
    else {
      b = new su(b, this);
      let c = a.listener,
        d = a.handler || a.src;
      a.Ae && Ou(a);
      a = c.call(d, b);
    }
    return a;
  }
  function Ju(a) {
    a = a[Cu];
    return a instanceof yu ? a : null;
  }
  var Ru = "__closure_events_fn_" + ((Math.random() * 1e9) >>> 0);
  function Hu(a) {
    if (typeof a === "function") return a;
    a[Ru] ||
      (a[Ru] = function (b) {
        return a.handleEvent(b);
      });
    return a[Ru];
  }
  function Su() {
    pu.call(this);
    this.J = new yu(this);
    this.Zc = this;
    this.sa = null;
  }
  Ea(Su, pu);
  Su.prototype[tu] = !0;
  p = Su.prototype;
  p.Ge = function () {
    return this.sa;
  };
  p.Da = function (a) {
    this.sa = a;
  };
  p.addEventListener = function (a, b, c, d) {
    Fu(this, a, b, c, d);
  };
  p.removeEventListener = function (a, b, c, d) {
    Nu(this, a, b, c, d);
  };
  p.dispatchEvent = function (a) {
    var b = this.Ge();
    if (b) {
      var c = [];
      for (var d = 1; b; b = b.Ge()) c.push(b), ++d;
    }
    b = this.Zc;
    d = a.type || a;
    if (typeof a === "string") a = new ru(a, b);
    else if (a instanceof ru) a.target = a.target || b;
    else {
      var e = a;
      a = new ru(d, b);
      Mm(a, e);
    }
    e = !0;
    var f;
    if (c)
      for (f = c.length - 1; !a.A && f >= 0; f--) {
        var g = (a.currentTarget = c[f]);
        e = Tu(g, d, !0, a) && e;
      }
    a.A ||
      ((g = a.currentTarget = b),
      (e = Tu(g, d, !0, a) && e),
      a.A || (e = Tu(g, d, !1, a) && e));
    if (c)
      for (f = 0; !a.A && f < c.length; f++)
        (g = a.currentTarget = c[f]), (e = Tu(g, d, !1, a) && e);
    return e;
  };
  p.B = function () {
    Su.qa.B.call(this);
    Qu(this);
    this.sa = null;
  };
  p.listen = function (a, b, c, d) {
    return this.J.add(String(a), b, !1, c, d);
  };
  p.N = function (a, b, c, d) {
    this.J.remove(String(a), b, c, d);
  };
  function Qu(a, b) {
    if (a.J) {
      a = a.J;
      b = b && b.toString();
      let c = 0;
      for (let d in a.A)
        if (!b || d == b) {
          let e = a.A[d];
          for (let f = 0; f < e.length; f++) ++c, xu(e[f]);
          delete a.A[d];
          a.B--;
        }
    }
  }
  function Tu(a, b, c, d) {
    b = a.J.A[String(b)];
    if (!b) return !0;
    b = b.concat();
    var e = !0;
    for (let f = 0; f < b.length; ++f) {
      let g = b[f];
      if (g && !g.he && g.capture == c) {
        let h = g.listener,
          k = g.handler || g.src;
        g.Ae && Au(a.J, g);
        e = h.call(k, d) !== !1 && e;
      }
    }
    return e && !d.defaultPrevented;
  }
  function Uu(a, b) {
    var c = a.H.getData(b.id());
    c || ((c = a.I(b)), a.H.setData(b.id(), c));
    return c;
  }
  var Vu = class extends Su {
    constructor(a) {
      super();
      this.camera = a;
      this.C = [];
      this.F = [];
      this.H = new kt(8);
    }
    setCamera(a) {
      mu(a, this.camera);
    }
    bd(a) {
      this.C = [];
      for (let b = 0; b < a.length; ++b) a[b] && this.C.push(a[b]);
    }
    Hb(a) {
      this.F.push(a);
    }
    run() {
      this.qc();
      this.D();
    }
    qc() {
      var a;
      for (a = 0; a < this.F.length; ++a) Uu(this, this.F[a]).Gb();
      for (a = 0; a < this.C.length; ++a) Uu(this, this.C[a]).Gb();
    }
    D() {
      for (let a = 0; a < this.C.length; ++a) {
        let b = Uu(this, this.C[a]);
        this.draw(b);
      }
    }
    clear() {
      this.H.clear();
      this.C = [];
      this.F = [];
    }
    Ta() {}
    mb() {
      return null;
    }
    Ib() {}
    Ob() {
      return !0;
    }
  };
  function Wu() {
    return new Float64Array(9);
  }
  function Xu(a, b) {
    var c = a[0],
      d = a[1],
      e = a[2],
      f = a[3],
      g = a[4],
      h = a[5],
      k = a[6],
      l = a[7];
    a = a[8];
    var m = g * a - l * h,
      n = l * e - d * a,
      q = d * h - g * e,
      r = c * m + f * n + k * q;
    r != 0 &&
      ((r = 1 / r),
      (b[0] = m * r),
      (b[3] = (k * h - f * a) * r),
      (b[6] = (f * l - k * g) * r),
      (b[1] = n * r),
      (b[4] = (c * a - k * e) * r),
      (b[7] = (k * d - c * l) * r),
      (b[2] = q * r),
      (b[5] = (f * e - c * h) * r),
      (b[8] = (c * g - f * d) * r));
  }
  function Yu(a, b, c) {
    var d = b[0],
      e = b[1];
    b = b[2];
    c[0] = d * a[0] + e * a[3] + b * a[6];
    c[1] = d * a[1] + e * a[4] + b * a[7];
    c[2] = d * a[2] + e * a[5] + b * a[8];
  }
  function Zu() {
    return new Float32Array(4);
  }
  function $u(a, b, c, d, e) {
    a[0] = b;
    a[1] = c;
    a[2] = d;
    a[3] = e;
    return a;
  }
  function av() {
    return new Float32Array(16);
  }
  function bv(a, b) {
    a[0] = b[0];
    a[1] = b[1];
    a[2] = b[2];
    a[3] = b[3];
    a[4] = b[4];
    a[5] = b[5];
    a[6] = b[6];
    a[7] = b[7];
    a[8] = b[8];
    a[9] = b[9];
    a[10] = b[10];
    a[11] = b[11];
    a[12] = b[12];
    a[13] = b[13];
    a[14] = b[14];
    a[15] = b[15];
  }
  function cv(a, b, c) {
    var d = a[0],
      e = a[1],
      f = a[2],
      g = a[3],
      h = a[4],
      k = a[5],
      l = a[6],
      m = a[7],
      n = a[8],
      q = a[9],
      r = a[10],
      t = a[11],
      v = a[12],
      F = a[13],
      H = a[14];
    a = a[15];
    var I = b[0],
      J = b[1],
      ja = b[2],
      ua = b[3],
      ka = b[4],
      ya = b[5],
      ma = b[6],
      L = b[7],
      Fa = b[8],
      ea = b[9],
      za = b[10],
      da = b[11],
      lb = b[12],
      sb = b[13],
      Hb = b[14];
    b = b[15];
    c[0] = d * I + h * J + n * ja + v * ua;
    c[1] = e * I + k * J + q * ja + F * ua;
    c[2] = f * I + l * J + r * ja + H * ua;
    c[3] = g * I + m * J + t * ja + a * ua;
    c[4] = d * ka + h * ya + n * ma + v * L;
    c[5] = e * ka + k * ya + q * ma + F * L;
    c[6] = f * ka + l * ya + r * ma + H * L;
    c[7] = g * ka + m * ya + t * ma + a * L;
    c[8] = d * Fa + h * ea + n * za + v * da;
    c[9] = e * Fa + k * ea + q * za + F * da;
    c[10] = f * Fa + l * ea + r * za + H * da;
    c[11] = g * Fa + m * ea + t * za + a * da;
    c[12] = d * lb + h * sb + n * Hb + v * b;
    c[13] = e * lb + k * sb + q * Hb + F * b;
    c[14] = f * lb + l * sb + r * Hb + H * b;
    c[15] = g * lb + m * sb + t * Hb + a * b;
  }
  function dv(a, b, c) {
    var d = b[3],
      e = b[0],
      f = b[1];
    b = b[2];
    c[0] = e * a[0] + f * a[4] + b * a[8] + d * a[12];
    c[1] = e * a[1] + f * a[5] + b * a[9] + d * a[13];
    c[2] = e * a[2] + f * a[6] + b * a[10] + d * a[14];
    c[3] = e * a[3] + f * a[7] + b * a[11] + d * a[15];
  }
  function ev(a, b) {
    var c = fv;
    c[0] = 1;
    c[1] = 0;
    c[2] = 0;
    c[3] = 0;
    c[4] = 0;
    c[5] = 1;
    c[6] = 0;
    c[7] = 0;
    c[8] = 0;
    c[9] = 0;
    c[10] = 1;
    c[11] = 0;
    c[12] = a;
    c[13] = b;
    c[14] = 0;
    c[15] = 1;
    return c;
  }
  function gv(a, b) {
    var c = Math.cos(b),
      d = 1 - c;
    b = Math.sin(b);
    a[0] = 0 * d + c;
    a[1] = 0 * d + 1 * b;
    a[2] = 0 * d - 0 * b;
    a[3] = 0;
    a[4] = 0 * d - 1 * b;
    a[5] = 0 * d + c;
    a[6] = 0 * d + 0 * b;
    a[7] = 0;
    a[8] = 0 * d + 0 * b;
    a[9] = 0 * d - 0 * b;
    a[10] = 1 * d + c;
    a[11] = 0;
    a[12] = 0;
    a[13] = 0;
    a[14] = 0;
    a[15] = 1;
  }
  new Float32Array(3);
  new Float32Array(3);
  Zu();
  Zu();
  Zu();
  av();
  function hv() {
    return new Float32Array(2);
  }
  function iv(a, b) {
    a[0] = b[0];
    a[1] = b[1];
  }
  function jv(a, b, c) {
    c[0] = a[0] + b[0];
    c[1] = a[1] + b[1];
  }
  function kv(a, b, c) {
    c[0] = a[0] - b[0];
    c[1] = a[1] - b[1];
  }
  function lv(a, b) {
    var c = a[0] - b[0];
    a = a[1] - b[1];
    return c * c + a * a;
  }
  var tv = class extends Vu {
      constructor(a, b) {
        super(a);
        this.context = b;
        this.G = null;
        this.A = new Ss(0, 0, 0, 0);
        this.canvas = b.canvas;
      }
      D() {
        for (let a = 0; a < this.C.length; ++a) {
          let b = Uu(this, this.C[a]);
          this.draw(b);
        }
      }
      I(a) {
        return new ft(a);
      }
      draw(a) {
        if (a.Ka() && this.G) {
          var b = a.label.vertices,
            c = mv(this.G),
            d = Math.max(1, this.canvas.width - this.A.left - this.A.right),
            e = Math.max(1, this.canvas.height - this.A.bottom - this.A.top),
            f = !1;
          for (let g = 0; g < 4; ++g) {
            $u(nv, b[3 * g], b[3 * g + 1], b[3 * g + 2], 1);
            let h = ov[g];
            dv(c, nv, h);
            let k =
              h[2] < -h[3] ||
              h[1] < -h[3] ||
              h[0] < -h[3] ||
              h[2] > +h[3] ||
              h[1] > +h[3] ||
              h[0] > +h[3];
            f = f || k;
            h[0] = ((h[0] / h[3] + 1) * d) / 2;
            h[1] = ((-h[1] / h[3] + 1) * e) / 2;
            h[0] += this.A.left;
            h[1] += this.A.top;
          }
          f ||
            ((b = a.A),
            (c = pv),
            (d = (b[2] + b[3]) / 2),
            (c[0] = (b[0] + b[1]) / 2),
            (c[1] = d),
            (c = qv),
            (d = b[5]),
            (c[0] = b[4]),
            (c[1] = d),
            (c = rv),
            (d = b[7]),
            (c[0] = b[6]),
            (c[1] = d),
            jv(ov[0], ov[1], nv),
            (nv[0] *= 0.5),
            (nv[1] *= 0.5),
            dt(nv, pv, ov[2], qv, ov[3], rv, sv) &&
              ((b = this.context),
              b.save(),
              b.setTransform(sv[0], sv[1], sv[3], sv[4], sv[6], sv[7]),
              b.drawImage(a.texture, 0, 0),
              b.restore()));
        }
      }
      Ta(a, b, c, d) {
        this.A.top = a || 0;
        this.A.right = b || 0;
        this.A.bottom = c || 0;
        this.A.left = d || 0;
      }
    },
    sv = Wu(),
    pv = hv(),
    qv = hv(),
    rv = hv(),
    nv = Zu(),
    ov = [Zu(), Zu(), Zu(), Zu()];
  function uv() {
    return () => {};
  }
  var vv = [];
  function wv(a, b) {
    var c = vv.length;
    vv.push({ error: a, options: b });
    b = Error("", { cause: a });
    b.message = "~#!#~" + String(c) + "~#!#~" + a.message + "~#!#~";
    throw b;
  }
  function xv() {
    this.origin = new Float64Array(3);
    this.dir = new Float64Array(3);
  }
  xv.prototype.set = function (a, b) {
    var c = this.origin;
    c[0] = a[0];
    c[1] = a[1];
    c[2] = a[2];
    a = this.dir;
    a[0] = b[0];
    a[1] = b[1];
    a[2] = b[2];
  };
  xv.prototype.equals = function (a) {
    return a != null && qt(this.origin, a.origin) && qt(this.dir, a.dir);
  };
  function nu(a, b) {
    var c = !1,
      d = !1,
      e = !1,
      f = !1,
      g = !1;
    b.F !== void 0 && (b.F !== a.cb && ((g = !0), (a.cb = b.F)), (c = !0));
    b.G !== void 0 && (b.G !== a.eb && ((g = !0), (a.eb = b.G)), (c = !0));
    b.H !== void 0 && (b.H !== a.fb && ((g = !0), (a.fb = b.H)), (c = !0));
    b.M !== void 0 && (b.M !== a.Ub && ((g = !0), (a.Ub = b.M)), (d = !0));
    b.A !== void 0 && (b.A !== a.Pa && ((g = !0), (a.Pa = b.A)), (e = !0));
    b.B !== void 0 && (b.B !== a.Qa && ((g = !0), (a.Qa = b.B)), (e = !0));
    b.I !== void 0 && (b.I !== a.Ra && ((g = !0), (a.Ra = b.I)), (e = !0));
    b.J !== void 0 && (b.J !== a.ac && ((g = !0), (a.ac = b.J)), (f = !0));
    b.K !== void 0 && (b.K !== a.H && ((g = !0), (a.H = b.K)), (f = !0));
    b.D !== void 0 && (b.D !== a.G && ((g = !0), (a.G = b.D)), (f = !0));
    b.C !== void 0 && b.C !== a.Kb && ((g = !0), (a.Kb = b.C));
    b.L !== void 0 && b.L !== a.Tb && ((g = !0), (a.Tb = b.L));
    b.N !== void 0 && b.N !== a.Sb && ((g = !0), (a.Sb = b.N));
    b.width !== void 0 &&
      b.width !== a.width &&
      ((g = !0), (a.width = b.width));
    b.height !== void 0 &&
      b.height !== a.height &&
      ((g = !0), (a.height = b.height));
    if (g)
      for (
        !f || c || e || (e = !0),
          !d &&
            e &&
            c &&
            ((b = a.Pa - a.cb),
            (d = a.Qa - a.eb),
            (f = a.Ra - a.fb),
            (a.Ub = Math.sqrt(b * b + d * d + f * f))),
          e &&
            !c &&
            (yv(a, a.B),
            (a.cb = a.Pa + a.B[0]),
            (a.eb = a.Qa + a.B[1]),
            (a.fb = a.Ra + a.B[2])),
          c &&
            !e &&
            (yv(a, a.B),
            (a.Pa = a.cb - a.B[0]),
            (a.Qa = a.eb - a.B[1]),
            (a.Ra = a.fb - a.B[2])),
          a.D = !0,
          a.I++,
          c = 0;
        c < a.F.length;
        c++
      )
        a.F[c]();
  }
  function zv(a, b = new ju()) {
    b.F = a.cb;
    b.G = a.eb;
    b.H = a.fb;
    b.M = a.Ub;
    b.A = a.Pa;
    b.B = a.Qa;
    b.I = a.Ra;
    b.J = a.ac;
    b.K = a.za();
    b.D = a.Va();
    b.C = a.Kb;
    b.L = a.Tb;
    b.N = a.Sb;
    b.width = a.S();
    b.height = a.R();
    return b;
  }
  function Av(a) {
    if (a.D) {
      var b = a.C,
        c = a.Kb,
        d = a.S() / a.R(),
        e = a.Tb,
        f = a.Sb,
        g = c / 2;
      c = f - e;
      var h = Math.sin(g);
      c != 0 &&
        h != 0 &&
        d != 0 &&
        ((g = Math.cos(g) / h),
        (b[0] = g / d),
        (b[1] = 0),
        (b[2] = 0),
        (b[3] = 0),
        (b[4] = 0),
        (b[5] = g),
        (b[6] = 0),
        (b[7] = 0),
        (b[8] = 0),
        (b[9] = 0),
        (b[10] = -(f + e) / c),
        (b[11] = -1),
        (b[12] = 0),
        (b[13] = 0),
        (b[14] = -(2 * e * f) / c),
        (b[15] = 0));
      b = a.N;
      f = -a.Va();
      g = -a.za();
      e = -a.ac;
      d = Math.cos(f);
      f = Math.sin(f);
      c = Math.cos(g);
      g = Math.sin(g);
      h = Math.cos(e);
      e = Math.sin(e);
      b[0] = d * h - c * f * e;
      b[1] = c * d * e + h * f;
      b[2] = e * g;
      b[3] = 0;
      b[4] = -d * e - h * c * f;
      b[5] = d * c * h - f * e;
      b[6] = h * g;
      b[7] = 0;
      b[8] = g * f;
      b[9] = -d * g;
      b[10] = c;
      b[11] = 0;
      b[12] = 0;
      b[13] = 0;
      b[14] = 0;
      b[15] = 1;
      cv(a.C, a.N, a.C);
      b = 1 / a.Ub;
      d = a.C;
      e = b * (a.cb - a.Pa);
      f = b * (a.eb - a.Qa);
      c = b * (a.fb - a.Ra);
      d[12] += d[0] * e + d[4] * f + d[8] * c;
      d[13] += d[1] * e + d[5] * f + d[9] * c;
      d[14] += d[2] * e + d[6] * f + d[10] * c;
      d[15] += d[3] * e + d[7] * f + d[11] * c;
      {
        var k = a.C;
        d = a.K;
        e = k[0];
        f = k[1];
        c = k[2];
        g = k[3];
        h = k[4];
        let m = k[5],
          n = k[6],
          q = k[7],
          r = k[8],
          t = k[9],
          v = k[10],
          F = k[11],
          H = k[12],
          I = k[13],
          J = k[14];
        k = k[15];
        let ja = e * m - f * h,
          ua = e * n - c * h,
          ka = e * q - g * h,
          ya = f * n - c * m,
          ma = f * q - g * m,
          L = c * q - g * n,
          Fa = r * I - t * H,
          ea = r * J - v * H,
          za = r * k - F * H,
          da = t * J - v * I,
          lb = t * k - F * I,
          sb = v * k - F * J;
        var l = ja * sb - ua * lb + ka * da + ya * za - ma * ea + L * Fa;
        l != 0 &&
          ((l = 1 / l),
          (d[0] = (m * sb - n * lb + q * da) * l),
          (d[1] = (-f * sb + c * lb - g * da) * l),
          (d[2] = (I * L - J * ma + k * ya) * l),
          (d[3] = (-t * L + v * ma - F * ya) * l),
          (d[4] = (-h * sb + n * za - q * ea) * l),
          (d[5] = (e * sb - c * za + g * ea) * l),
          (d[6] = (-H * L + J * ka - k * ua) * l),
          (d[7] = (r * L - v * ka + F * ua) * l),
          (d[8] = (h * lb - m * za + q * Fa) * l),
          (d[9] = (-e * lb + f * za - g * Fa) * l),
          (d[10] = (H * ma - I * ka + k * ja) * l),
          (d[11] = (-r * ma + t * ka - F * ja) * l),
          (d[12] = (-h * da + m * ea - n * Fa) * l),
          (d[13] = (e * da - f * ea + c * Fa) * l),
          (d[14] = (-H * ya + I * ua - J * ja) * l),
          (d[15] = (r * ya - t * ua + v * ja) * l));
      }
      d = a.A;
      Ot(d, b, b, b);
      St(d, -a.cb, -a.eb, -a.fb);
      b = Ct();
      Et(b, a.C);
      Jt(b, d, a.J);
      Kt(a.J, a.L);
      a.D = !1;
    }
  }
  function Bv(a, b, c, d) {
    var e = 1 / a.Ub;
    d
      ? ((d = a.M),
        (d[0] = b[0]),
        (d[1] = b[5]),
        (d[2] = b[10]),
        (d[3] = b[15]),
        Ot(c, e * d[0], e * d[1], e * d[2]),
        (d = a.M),
        Ft(b, 3, d),
        (d[0] = e * (d[0] - a.cb)),
        (d[1] = e * (d[1] - a.eb)),
        (d[2] = e * (d[2] - a.fb)),
        (c[12] = d[0]),
        (c[13] = d[1]),
        (c[14] = d[2]),
        (c[15] = d[3]))
      : ((d = a.A), Ot(d, e, e, e), St(d, -a.cb, -a.eb, -a.fb), Jt(d, b, c));
  }
  function Cv(a, b, c = Y()) {
    var d = b[1],
      e = b[2];
    c[0] = (b[0] * 2) / a.S() - 1;
    c[1] = (-d * 2) / a.R() + 1;
    c[2] = e * 2 - 1;
  }
  function Dv(a, b, c, d = new xv()) {
    var e = a.B,
      f = a.Tb,
      g = a.Sb;
    e[0] = b;
    e[1] = c;
    e[2] = g / (g - f);
    Cv(a, e, e);
    e[2] = (g + f) / (g - f);
    b = a.A;
    Av(a);
    Et(b, a.K);
    Lt(a.A, e, d.dir);
    xt(d.dir, d.dir);
    rt(d.origin, a.Pa, a.Qa, a.Ra);
  }
  function Ev(a, b, c = Y()) {
    var d = b[1],
      e = b[2];
    c[0] = (b[0] + 1) * 0.5 * a.S();
    c[1] = (-d + 1) * 0.5 * a.R();
    c[2] = (e + 1) * 0.5;
  }
  function yv(a, b) {
    rt(b, 0, 0, -a.Ub);
    Tt(a.A, a.ac, a.za(), a.Va());
    Mt(a.A, b, b);
  }
  var Fv = class {
    constructor() {
      this.vg = 0;
      this.C = av();
      this.K = av();
      av();
      this.N = av();
      this.J = Ct();
      this.L = Ct();
      Ct();
      Ct();
      this.B = Y();
      this.M = At();
      Y();
      rt(Y(), 1, 1, 1);
      this.A = Ct();
      this.D = !0;
      this.fb = this.eb = this.cb = 0;
      this.Ub = 1;
      this.G = this.H = this.ac = this.Ra = this.Qa = this.Pa = 0;
      this.Kb = 0.4363323129985824;
      this.Tb = 1 / 3;
      this.Sb = Number.MAX_VALUE;
      this.I = this.height = this.width = 1;
      this.F = [];
    }
    clone() {
      var a = new Fv();
      nu(a, zv(this));
      a.I = this.I;
      return a;
    }
    equals(a) {
      return (
        this.cb === a.cb &&
        this.eb === a.eb &&
        this.fb === a.fb &&
        this.Ub === a.Ub &&
        this.Pa === a.Pa &&
        this.Qa === a.Qa &&
        this.Ra === a.Ra &&
        this.ac === a.ac &&
        this.za() === a.za() &&
        this.Va() === a.Va() &&
        this.Kb === a.Kb &&
        this.Tb === a.Tb &&
        this.Sb === a.Sb &&
        this.S() === a.S() &&
        this.R() === a.R()
      );
    }
    za() {
      return this.H;
    }
    Va() {
      return this.G;
    }
    S() {
      return this.width;
    }
    R() {
      return this.height;
    }
    onChange(a) {
      this.F.push(a);
    }
  };
  function Gv(a, b, c) {
    var d = Hv(b),
      e = mv(b),
      f = d.length;
    for (let Qf = 0; Qf < f; ++Qf) {
      var g = a,
        h = d[Qf],
        k = e,
        l = c;
      if (h.Ka()) {
        var m = u.devicePixelRatio || 1,
          n = l.canvas.width - (g.A.left + g.A.right) * m,
          q = l.canvas.height - (g.A.top + g.A.bottom) * m;
        Iv[0] = n / 2;
        Iv[1] = -q / 2;
        Iv[2] = n / 2 + g.A.left * m;
        Iv[3] = q / 2 + g.A.top * m;
        var r = h.Xd().A(),
          t = Jv(h),
          v = h.M,
          F = Kv(h),
          H = F.length / 3,
          I = Lv;
        if (!I || I.length < H * 4) I = Lv = new Float32Array(H * 4);
        for (let gb = 0; gb < H; ++gb)
          $u(Mv, F[3 * gb], F[3 * gb + 1], F[3 * gb + 2], 1),
            dv(k, Mv, Nv),
            (I[4 * gb + 0] = Nv[0]),
            (I[4 * gb + 1] = Nv[1]),
            (I[4 * gb + 2] = Nv[2]),
            (I[4 * gb + 3] = Nv[3]);
        for (let gb = 0; gb < t.length - 2; ++gb) {
          g.D = 0;
          let Ab = t[gb],
            ub = t[gb + 1],
            qa = t[gb + 2];
          if (Ab !== ub && ub !== qa && qa !== Ab) {
            if (gb < t.length - 3) {
              let ha = t[gb + 3];
              if (ub !== ha && ha !== qa) {
                var J = g,
                  ja = Ab,
                  ua = ub,
                  ka = ha,
                  ya = qa,
                  ma = I,
                  L = v,
                  Fa = r,
                  ea = l,
                  za = Iv;
                Ov(ma, ja, Mv);
                Ov(ma, ua, Nv);
                Ov(ma, ka, Pv);
                Ov(ma, ya, Qv);
                let T = Rv(Mv),
                  W = Rv(Nv),
                  O = Rv(Pv),
                  va = Rv(Qv);
                if (!(T & W & O & va))
                  if ((T | W | O | va) & 1)
                    Sv(J, ja, ua, ka, ma, L, Fa, za, ea),
                      Sv(J, ja, ka, ya, ma, L, Fa, za, ea);
                  else {
                    Tv(Mv, za);
                    Tv(Nv, za);
                    Tv(Pv, za);
                    Tv(Qv, za);
                    let bb = Uv(J),
                      Ua = Uv(J),
                      hb = Uv(J),
                      ib = Uv(J);
                    Vv(L, ja, bb);
                    Vv(L, ua, Ua);
                    Vv(L, ka, hb);
                    Vv(L, ya, ib);
                    var da = bb,
                      lb = Ua,
                      sb = hb,
                      Hb = ib,
                      Xe = Mv,
                      Sc = Nv,
                      Qb = Pv,
                      ld = Qv;
                    let me = Uv(J),
                      cm = Uv(J),
                      dm = Uv(J),
                      em = Uv(J);
                    kv(Sc, Xe, me);
                    kv(Qb, Sc, cm);
                    kv(ld, Qb, dm);
                    kv(Xe, ld, em);
                    var zj = dm,
                      md = dm;
                    md[0] = zj[0] * -1;
                    md[1] = zj[1] * -1;
                    jv(me, dm, me);
                    var fm = em,
                      gm = em;
                    gm[0] = fm[0] * -1;
                    gm[1] = fm[1] * -1;
                    jv(cm, em, cm);
                    let Er = Uv(J),
                      Fr = Uv(J),
                      Gr = Uv(J),
                      Hr = Uv(J);
                    var kc = me,
                      lc = cm,
                      gh = Xe,
                      hh = Sc,
                      ih = Qb,
                      jh = ld,
                      hm = Er,
                      im = Fr,
                      jm = Gr,
                      km = Hr;
                    let lm = 1 / (kc[0] * lc[1] - kc[1] * lc[0]),
                      mm = lm * lc[1],
                      nm = lm * -lc[0],
                      om = lm * -kc[1],
                      pm = lm * kc[0],
                      tz = mm * gh[0] + nm * gh[1],
                      uz = om * gh[0] + pm * gh[1],
                      vz = mm * hh[0] + nm * hh[1],
                      wz = om * hh[0] + pm * hh[1],
                      xz = mm * ih[0] + nm * ih[1],
                      yz = om * ih[0] + pm * ih[1],
                      zz = mm * jh[0] + nm * jh[1],
                      Az = om * jh[0] + pm * jh[1],
                      qm = Wv(tz, vz, xz, zz),
                      rm = Wv(uz, wz, yz, Az),
                      sm = Xv(tz, vz, xz, zz),
                      tm = Xv(uz, wz, yz, Az);
                    hm[0] = kc[0] * qm + lc[0] * rm;
                    hm[1] = kc[1] * qm + lc[1] * rm;
                    im[0] = kc[0] * sm + lc[0] * rm;
                    im[1] = kc[1] * sm + lc[1] * rm;
                    jm[0] = kc[0] * sm + lc[0] * tm;
                    jm[1] = kc[1] * sm + lc[1] * tm;
                    km[0] = kc[0] * qm + lc[0] * tm;
                    km[1] = kc[1] * qm + lc[1] * tm;
                    let YJ = Xv(lv(Xe, Er), lv(Sc, Fr), lv(Qb, Gr), lv(ld, Hr));
                    if (dt(Er, da, Fr, lb, Gr, sb, Yv)) {
                      var Aj = Uv(J);
                      Aj[0] = Yv[0] * Hb[0] + Yv[3] * Hb[1] + Yv[6];
                      Aj[1] = Yv[1] * Hb[0] + Yv[4] * Hb[1] + Yv[7];
                      var Jr = lv(Hr, Aj);
                      if (YJ > 4 || Jr > 4)
                        Zv(J, Xe, da, Sc, lb, ld, Hb, Fa, ea),
                          Zv(J, ld, Hb, Sc, lb, Qb, sb, Fa, ea);
                      else {
                        let um = Uv(J),
                          vm = Uv(J),
                          wm = Uv(J),
                          xm = Uv(J);
                        iv(um, Xe);
                        iv(vm, Sc);
                        iv(wm, Qb);
                        iv(xm, ld);
                        var Rb = um,
                          ne = vm,
                          Qa = wm,
                          Ye = xm;
                        let ym = (Rb[0] + ne[0] + Qa[0] + Ye[0]) / 4,
                          zm = (Rb[1] + ne[1] + Qa[1] + Ye[1]) / 4;
                        $v(Rb, ym, zm);
                        $v(ne, ym, zm);
                        $v(Qa, ym, zm);
                        $v(Ye, ym, zm);
                        try {
                          ea.save(),
                            ea.beginPath(),
                            ea.moveTo(um[0], um[1]),
                            ea.lineTo(vm[0], vm[1]),
                            ea.lineTo(wm[0], wm[1]),
                            ea.lineTo(xm[0], xm[1]),
                            ea.closePath(),
                            ea.clip(),
                            ea.setTransform(
                              Yv[0],
                              Yv[1],
                              Yv[3],
                              Yv[4],
                              Yv[6],
                              Yv[7]
                            ),
                            ea.drawImage(Fa, 0, 0),
                            ea.restore();
                        } catch (iT) {
                          let Cz = Error();
                          Cz.message =
                            "drawScreenQuad: Error accessing canvas.";
                          wv(Cz, { errorType: 17 });
                        }
                        ++J.F;
                      }
                    }
                  }
                ++gb;
                continue;
              }
            }
            Sv(g, Ab, ub, qa, I, v, r, Iv, l);
          }
        }
      }
    }
    a.F = 0;
  }
  function Uv(a) {
    a.D === a.G.length && (a.G[a.D] = hv());
    return a.G[a.D++];
  }
  function Sv(a, b, c, d, e, f, g, h, k) {
    var l = Mv,
      m = Nv,
      n = Pv;
    Ov(e, b, l);
    Ov(e, c, m);
    Ov(e, d, n);
    e = Rv(l);
    var q = Rv(m),
      r = Rv(n);
    if (!(e & q & r)) {
      var t = aw,
        v = bw,
        F = cw;
      Vv(f, b, t);
      Vv(f, c, v);
      Vv(f, d, F);
      f = (e & 1) + (q & 1) + (r & 1);
      if (f === 1) {
        for (; !(e & 1); )
          (f = e),
            (e = q),
            (q = r),
            (r = f),
            (f = l),
            (l = m),
            (m = n),
            (n = f),
            (f = t),
            (t = v),
            (v = F),
            (F = f),
            (f = b),
            (b = c),
            (c = d),
            (d = f);
        dw(l, n, Qv, t, F, ew);
        dw(l, m, l, t, v, t);
        Tv(l, h);
        Tv(m, h);
        Tv(n, h);
        Tv(Qv, h);
        Zv(a, l, t, m, v, Qv, ew, g, k);
        Zv(a, m, v, n, F, Qv, ew, g, k);
      } else {
        if (f === 2) {
          for (; e & 1; )
            (f = e),
              (e = q),
              (q = r),
              (r = f),
              (f = l),
              (l = m),
              (m = n),
              (n = f),
              (f = t),
              (t = v),
              (v = F),
              (F = f),
              (f = b),
              (b = c),
              (c = d),
              (d = f);
          dw(l, m, m, t, v, v);
          dw(l, n, n, t, F, F);
        }
        Tv(l, h);
        Tv(m, h);
        Tv(n, h);
        Zv(a, l, t, m, v, n, F, g, k);
      }
    }
  }
  function Zv(a, b, c, d, e, f, g, h, k) {
    if (dt(b, c, d, e, f, g, fw)) {
      c = Uv(a);
      e = Uv(a);
      g = Uv(a);
      iv(c, b);
      iv(e, d);
      iv(g, f);
      b = (c[0] + e[0] + g[0]) / 3;
      d = (c[1] + e[1] + g[1]) / 3;
      $v(c, b, d);
      $v(e, b, d);
      $v(g, b, d);
      try {
        k.save(),
          k.beginPath(),
          k.moveTo(c[0], c[1]),
          k.lineTo(e[0], e[1]),
          k.lineTo(g[0], g[1]),
          k.closePath(),
          k.clip(),
          k.setTransform(fw[0], fw[1], fw[3], fw[4], fw[6], fw[7]),
          k.drawImage(h, 0, 0),
          k.restore();
      } catch (l) {
        (h = Error()),
          (h.message = "drawScreenQuad: Error accessing canvas."),
          wv(h, { errorType: 9 });
      }
      ++a.F;
    }
  }
  var gw = class {
      constructor(a, b) {
        this.context = a;
        this.B = b;
        this.G = [];
        this.F = this.D = 0;
        this.H = "black";
        this.A = new Ss(0, 0, 0, 0);
        this.I = this.B.getContext("2d");
        this.C = new tv(new Fv(), this.context);
      }
      lg() {
        var a = this.context.canvas;
        this.context.clearRect(0, 0, a.width, a.height);
        this.context.fillStyle = this.H;
        this.context.fillRect(0, 0, a.width, a.height);
      }
      jg() {}
      Ce(a, b, c) {
        var d = D(b, 1);
        if (d !== 0) {
          if (d === 1) Gv(this, c, this.context);
          else {
            if (
              this.context.canvas.width !== this.B.width ||
              this.context.canvas.height !== this.B.height
            )
              (this.B.width = this.context.canvas.width),
                (this.B.height = this.context.canvas.height);
            this.I.clearRect(0, 0, this.B.width, this.B.height);
            Gv(this, c, this.I);
            this.context.globalAlpha = d;
            this.context.drawImage(this.B, 0, 0);
            this.context.globalAlpha = 1;
          }
          b = D(b, 5);
          a = a.hc();
          b > 0 && a.length > 0 && (this.C.bd(a), (this.C.G = c), this.C.run());
        }
      }
      Ib(a) {
        this.H = a === 1 ? "white" : "black";
      }
      Ta(a, b, c, d) {
        this.A.top = a;
        this.A.right = b;
        this.A.bottom = c;
        this.A.left = d;
        this.C.Ta(a, b, c, d);
      }
    },
    Iv = Zu(),
    aw = hv(),
    bw = hv(),
    cw = hv(),
    ew = hv(),
    Mv = Zu(),
    Nv = Zu(),
    Pv = Zu(),
    Qv = Zu(),
    Lv = null,
    Yv = Wu(),
    fw = Wu();
  function Ov(a, b, c) {
    $u(c, a[4 * b], a[4 * b + 1], a[4 * b + 2], a[4 * b + 3]);
  }
  function Vv(a, b, c) {
    var d = a[2 * b + 1];
    c[0] = a[2 * b];
    c[1] = d;
  }
  function Rv(a) {
    return (
      ((a[2] < -a[3] ? 1 : 0) << 0) |
      ((a[1] < -a[3] ? 1 : 0) << 1) |
      ((a[0] < -a[3] ? 1 : 0) << 2) |
      ((a[2] > +a[3] ? 1 : 0) << 3) |
      ((a[1] > +a[3] ? 1 : 0) << 4) |
      ((a[0] > +a[3] ? 1 : 0) << 5)
    );
  }
  function Tv(a, b) {
    a[0] = (a[0] / a[3]) * b[0] + b[2];
    a[1] = (a[1] / a[3]) * b[1] + b[3];
  }
  function Xv(a, b, c, d) {
    a = b > a ? b : a;
    a = c > a ? c : a;
    return d > a ? d : a;
  }
  function Wv(a, b, c, d) {
    a = b < a ? b : a;
    a = c < a ? c : a;
    return d < a ? d : a;
  }
  function dw(a, b, c, d, e, f) {
    var g = -a[2] - a[3];
    g /= g - (-b[2] - b[3]);
    var h = a[3],
      k = a[0],
      l = a[1];
    a = a[2];
    c[0] = (b[0] - k) * g + k;
    c[1] = (b[1] - l) * g + l;
    c[2] = (b[2] - a) * g + a;
    c[3] = (b[3] - h) * g + h;
    b = d[0];
    d = d[1];
    f[0] = (e[0] - b) * g + b;
    f[1] = (e[1] - d) * g + d;
  }
  function $v(a, b, c) {
    b = a[0] - b;
    c = a[1] - c;
    var d = Math.sqrt(b * b + c * c);
    d > 1e-6 && ((a[0] += (3 * b) / d), (a[1] += (3 * c) / d));
  }
  function hw(a) {
    return `${a.x}|${a.y}|${a.zoom}`;
  }
  var iw = class {
    constructor(a, b, c, d) {
      this.x = a;
      this.y = b;
      this.zoom = c;
      this.image = d;
      this.D = hw({ x: a, y: b, zoom: c });
    }
    getX() {
      return this.x;
    }
    getY() {
      return this.y;
    }
    ub() {
      return this.image;
    }
    toString() {
      return this.D;
    }
  };
  var jw = class extends iw {
    constructor(a, b, c, d, e) {
      super(a, b, c, d);
      this.C = e;
    }
    A() {
      return null;
    }
    Ka() {
      return !0;
    }
    Gb() {}
  };
  var kw = class extends jw {
    constructor(a, b, c, d, e) {
      super(a, b, c, d, e);
      this.texture = null;
    }
    Ka() {
      return !!this.texture;
    }
    A() {
      return this.texture;
    }
    Gb() {
      if (!this.Ka()) {
        var a = this.ub();
        if (Kb) var b = a;
        else {
          var c = a.width,
            d = a.height;
          b = Js(document, "canvas");
          b.width = c + 2;
          b.height = d + 2;
          try {
            let e = b.getContext("2d");
            e.drawImage(a, 0, 0, c, d, 1, 1, c, d);
            e.drawImage(a, 0, 0, c, 1, 1, 0, c, 1);
            e.drawImage(a, 0, d - 1, c, 1, 1, d + 1, c, 1);
            e.drawImage(b, 1, 0, 1, d + 2, 0, 0, 1, d + 1 + 2);
            e.drawImage(b, c, 0, 1, d + 2, c + 1, 0, 1, d + 1 + 2);
          } catch (e) {
            (a = Error()),
              (a.message = "skirtImage: Error accessing canvas."),
              wv(a, { errorType: 17 });
          }
        }
        this.texture = b;
      }
    }
  };
  var lw = At(),
    mw = At();
  function nw(a) {
    a[0] = a[1] = a[2] = Infinity;
    a[3] = a[4] = a[5] = -Infinity;
  }
  function ow(a, b) {
    var c = !0;
    for (let f = 0; f < 6; ++f) {
      var d = a,
        e = b[f];
      let g = e[3],
        h = e[3];
      for (let k = 0; k < 3; ++k) {
        let l = e[k] < 0,
          m = l ? d[k] : d[3 + k];
        g += e[k] * (l ? d[3 + k] : d[k]);
        h += e[k] * m;
      }
      d = g > 0 ? 1 : h > 0 ? 0 : -1;
      if (d === 1) return 0;
      d === 0 && (c = !1);
    }
    return c ? 2 : 1;
  }
  function pw(a, b, c, d, e, f) {
    nw(e);
    var g = 1 << (d.ob() - c);
    c = d.yb(a);
    a = d.yb(a + g);
    var h = d.zb(b);
    b = d.zb(b + g);
    d.Lb(c, h, qw, 0);
    rw(e, qw, 0, f);
    d.Lb(a, h, qw, 0);
    rw(e, qw, 0, f);
    d.Lb(c, b, qw, 0);
    rw(e, qw, 0, f);
    d.Lb(a, b, qw, 0);
    rw(e, qw, 0, f);
    d.Lb((c + a) / 2, (h + b) / 2, qw, 0);
    rw(e, qw, 0, f);
  }
  var qw = new Float32Array(3);
  function rw(a, b, c, d) {
    var e = b[c],
      f = b[c + 1];
    b = b[c + 2];
    d &&
      ((d = 10 / Math.sqrt(e * e + f * f + b * b)),
      (e *= d),
      (f *= d),
      (b *= d));
    e < a[0] && (a[0] = e);
    f < a[1] && (a[1] = f);
    b < a[2] && (a[2] = b);
    e > a[3] && (a[3] = e);
    f > a[4] && (a[4] = f);
    b > a[5] && (a[5] = b);
  }
  function Jv(a) {
    sw(a);
    return a.O;
  }
  function Kv(a) {
    sw(a);
    return a.D;
  }
  function tw(a, b) {
    var c;
    for (c = a.J; c >= 0; --c) {
      var d = uw(a, c);
      if (d && (!b || d.Ka())) return d;
    }
    d = a.C.xa().ob();
    d = Math.min(d, a.I);
    for (c = a.J + 1; c <= d; ++c) {
      let e = uw(a, c);
      if (e && (!b || e.Ka())) return e;
    }
    return null;
  }
  function uw(a, b) {
    var c = Math.max(0, a.C.xa().ob() - b);
    if ((b = a.C.Nb(a.x >> c, a.y >> c, b))) {
      c = a.W[b.toString()];
      if (!c) {
        c = a.P;
        var d = a.C.xa(),
          e = d.qf(b.zoom);
        let m = b.getX() * e;
        var f = b.getY() * e,
          g = d.yb(m),
          h = d.yb(m + 1);
        var k = d.zb(f);
        var l = d.zb(f + 1);
        h -= g;
        l -= k;
        let n = d.Uc();
        m === Math.floor(n) && (h /= n - Math.floor(n));
        d = d.Gc();
        f === Math.floor(d) && (l /= d - Math.floor(d));
        f = 1 / h / e;
        e = 1 / l / e;
        g *= f;
        k *= e;
        k = $u(Zu(), f, e, -g, -k);
        c = c.call(a, b, k);
        a.W[b.toString()] = c;
      }
      a = c;
    } else a = null;
    return a;
  }
  function sw(a) {
    if (!(a.H && a.D && a.O && a.A))
      if (a.T) {
        var b = a.C.xa();
        a.A || (a.A = new Float64Array(6));
        a.B || (a.B = new Float64Array(6));
        nw(a.A);
        nw(a.B);
        var c = 1 << (b.ob() - a.I);
        let g = c * 7 + 1,
          h = c * 7 + 1;
        a.H = new Float32Array(2 * g * h);
        a.D = new Float32Array(3 * g * h);
        var d = 0,
          e = b.yb(a.x),
          f = b.yb(a.x + c);
        let k = b.zb(a.y);
        c = b.zb(a.y + c);
        for (let l = 0; l < g; ++l) {
          let m = l / (g - 1);
          for (let n = 0; n < h; ++n) {
            let q = zo(e, f, n / (h - 1)),
              r = zo(k, c, m);
            a.H[2 * d] = q;
            a.H[2 * d + 1] = r;
            b.Lb(q, r, a.D, 3 * d);
            rw(a.A, a.D, 3 * d);
            rw(a.B, a.D, 3 * d, !0);
            ++d;
          }
        }
        b = [];
        d = 0;
        for (e = 0; e < g - 1; e++)
          for (
            e > 0 && ((b[d++] = (e + 1) * h - 1), (b[d++] = e * h)), f = 0;
            f < h;
            f++
          )
            (b[d++] = e * h + f), (b[d++] = (e + 1) * h + f);
        a.O = new Uint16Array(b);
      } else vw(a);
  }
  function ww(a) {
    sw(a);
    return a.H;
  }
  function vw(a) {
    var b = a.C.xa(),
      c = b.Lg(a.x, a.y, a.I, a.aa),
      d = Math.round(c[0]) + 1,
      e = Math.round(c[1]) + 1,
      f = Math.round(c[2]) + 1;
    c = [];
    var g = 0;
    for (var h = 0; h < d; ++h) {
      c[h] = [];
      var k = Math.round(zo(e, f, h / (d - 1)));
      for (var l = 0; l < k; ++l) c[h][l] = g++;
    }
    a.A || (a.A = new Float64Array(6));
    a.B || (a.B = new Float64Array(6));
    nw(a.A);
    nw(a.B);
    a.H = new Float32Array(2 * g);
    a.D = new Float32Array(3 * g);
    g = 0;
    k = 1 << (b.ob() - a.I);
    e = b.yb(a.x);
    f = b.yb(a.x + k);
    h = b.zb(a.y);
    k = b.zb(a.y + k);
    for (l = 0; l < d; ++l) {
      let m = l / (d - 1),
        n = c[l].length;
      for (let q = 0; q < n; ++q) {
        let r = zo(e, f, q / (n - 1)),
          t = zo(h, k, m);
        a.H[2 * g] = r;
        a.H[2 * g + 1] = t;
        b.Lb(r, t, a.D, 3 * g);
        rw(a.A, a.D, 3 * g);
        rw(a.B, a.D, 3 * g, !0);
        ++g;
      }
    }
    b = [];
    g = 0;
    for (e = 0; e < d - 1; e++)
      for (
        h = c[e].length,
          k = c[e + 1].length,
          e > 0 && ((b[g++] = c[e][h - 1]), (b[g++] = c[e][0])),
          f = Math.max(h, k),
          h = (h - 1) / (f - 1),
          k = (k - 1) / (f - 1),
          l = 0;
        l < f;
        ++l
      )
        (b[g++] = c[e][Math.round(l * h)]),
          (b[g++] = c[e + 1][Math.round(l * k)]);
    a.O = new Uint16Array(b);
  }
  var xw = class {
    constructor(a, b, c, d, e, f) {
      this.C = a;
      this.W = b;
      this.x = c;
      this.y = d;
      this.I = e;
      this.J = 0;
      this.Fd = 1;
      this.B = this.A = this.O = this.D = this.H = this.V = null;
      this.T = !0;
      this.aa = f || !1;
    }
    getX() {
      return this.x;
    }
    getY() {
      return this.y;
    }
    Z() {
      return this.Fd < 1 && this.Fd > 0;
    }
    Xd() {
      var a = tw(this, !0);
      a && a.zoom !== this.J && (this.V = a);
      return a;
    }
    Ng() {
      if (!this.F()) return !0;
      var a = tw(this);
      return !!a && !a.Ka();
    }
    Gb() {
      this.L();
      var a = tw(this);
      a && a.Gb();
    }
    Gf() {
      this.L();
      var a = tw(this, !0);
      a || (a = tw(this));
      a && a.Gb();
    }
    Ka() {
      if (this.F()) {
        let a = this.Xd();
        return !!a && a.Ka();
      }
      return !1;
    }
    Og() {
      var a = uw(this, this.J);
      return !!a && a.Ka() && this.F();
    }
    F() {
      return !0;
    }
    L() {}
    P(a, b) {
      return new jw(a.getX(), a.getY(), a.zoom, a.ub(), b);
    }
    getBoundingBox() {
      this.A ||
        ((this.A = new Float64Array(6)),
        pw(this.x, this.y, this.I, this.C.xa(), this.A, !1));
      return this.A;
    }
  };
  function yw(a) {
    var b = tw(a, !0);
    if (b && a.G !== b) {
      a.G = b;
      var c = b.C,
        d = b.A();
      b = d.width - 2;
      d = d.height - 2;
      zw[0] = c[0] * b;
      zw[1] = c[1] * d;
      zw[2] = c[2] * b + 1;
      zw[3] = c[3] * d + 1;
      a.T !== !1 && ((a.T = !1), vw(a));
      c = ww(a);
      b = c.length / 2;
      a.M || (a.M = new Float32Array(2 * b));
      a = a.M;
      d = 0;
      for (let e = 0; e < b; ++e, d += 2) {
        let f = c[d + 1];
        a[d] = c[d] * zw[0] + zw[2];
        a[d + 1] = f * zw[1] + zw[3];
      }
    }
  }
  var Aw = class extends xw {
      constructor(a, b, c, d, e) {
        super(a, b, c, d, e, !0);
        this.K = !1;
        this.M = this.G = null;
        this.hash = `${c}:${d}`;
      }
      F() {
        return this.K;
      }
      Ka() {
        return this.F() && !!this.G && this.G.Ka();
      }
      Xd() {
        return this.G;
      }
      Og() {
        var a = uw(this, this.J);
        return this.F() && !!a && a.Ka() && a === this.G;
      }
      Ng() {
        if (!this.F()) return !0;
        var a = tw(this);
        return !!a && !(a.Ka() && a === this.G);
      }
      Gb() {
        super.Gb();
        yw(this);
      }
      Gf() {
        super.Gf();
        yw(this);
      }
      L() {
        this.F() || (this.K = !0);
      }
      toString() {
        return this.hash;
      }
      P(a, b) {
        return new kw(a.getX(), a.getY(), a.zoom, a.ub(), b);
      }
    },
    zw = Zu(),
    Bw = class {
      create(a, b, c, d, e) {
        return new Aw(a, b, c, d, e);
      }
    };
  var Dw = class extends pu {
      constructor(a, b, c) {
        super();
        this.C = a;
        this.qb = b;
        this.D = [];
        this.A = Cw++;
        this.X = c;
      }
      cancel() {
        if (!this.M()) {
          for (let a of this.D) a(this.X);
          this.dispose();
        }
      }
      B() {
        this.X = null;
        this.D.length = 0;
      }
    },
    Cw = 1;
  function Ew() {}
  function Fw() {}
  function Gw() {
    return Hw && typeof Hw.svepoch === "number" ? Hw.svepoch : null;
  }
  var Hw = null;
  function Iw(a) {
    return (b) =>
      new Jw(a, Jq(b)?.name ?? "", Jq(b)?.element ?? null, b.A.event);
  }
  function Kw(a) {
    return a.qb === "application_init";
  }
  function Lw(a) {
    var b = new Jw(Mw(), "on-labels-updated");
    a(b);
    b.done("main-actionflow-branch");
  }
  function Nw(a, b, c) {
    a.gb(b, c);
    var d = !1;
    return (e) => {
      if (d) return !1;
      d = !0;
      a.done(b, e);
      return !0;
    };
  }
  var Jw = class extends Rq {
    constructor(a, b, c, d) {
      super(b, c, d, void 0, null, void 0, Ow());
      this.O = a;
      this.qb = this.V = null;
      this.V = Gu(this.C, "beforedone", () => {
        if (this.qb)
          try {
            let e = Ow() ? u.performance.now() : Date.now();
            console.timeStamp(this.qb, this.Ie(), e, "Flow", "Maps");
          } catch {}
      });
    }
    A(a, b) {
      this.qb = b;
      Wq(this, "an", b);
      this.O.start(a, b, this);
    }
    Te(a, b) {
      this.qb = b;
      Wq(this, "an", b);
      return this.O.Te(this, a, b);
    }
    isActive() {
      return this.O.isActive(this);
    }
    Fa(a, b) {
      var c = b?.time != null || Ow() ? b : { ...b, time: Date.now() };
      super.Fa(a, c);
      if ((c = Pw(a)) && this.N !== "bootstrap_performance_flow")
        try {
          let e = Kw(this) ? (c === "start" ? this.J : this.T[c]) : this.Ie(),
            f = (b ?? null)?.time ?? (Ow() ? u.performance.now() : Date.now());
          if (Kw(this)) var d = `${c}_${a}`;
          else {
            let g = "ActionFlow#" + this.N;
            this.qb && (g += ":" + this.qb);
            d = `${a}_${g}`;
          }
          console.timeStamp(d, e, f, "Flow", "Maps");
        } catch {}
    }
    K() {
      super.K();
      this.V && Ou(this.V);
    }
    I(a) {
      this.flowType();
      super.I(a);
    }
    node() {
      return super.node();
    }
  };
  function Pw(a) {
    switch (a) {
      case "b1":
        return "b0";
      case "ffat":
      case "obd":
        return "ai0";
      case "itl1":
        return "itl0";
      case "pvt":
        return "pvs";
      case "xdi1":
        return "xdi0";
      default:
        return "";
    }
  }
  function Ow() {
    return typeof u.performance?.now === "function";
  }
  function Qw(a, b, c) {
    Gm(a.zg(), (d, e) => {
      Wq(b, c + String(e), String(d));
    });
  }
  function Rw(a, b, c) {
    a.A[c.C][c.qb] = b;
    a.B.set(b.id(), c);
  }
  function Sw(a, b, c) {
    var d = a.B.get(b.id());
    a.B.delete(b.id());
    d && (delete a.A[d.C][d.qb], c && d.cancel(), d.dispose());
  }
  function Tw(a, b) {
    return b.branches().size === 0
      ? (Sw(a, b, !1), null)
      : a.B.get(b.id()) || null;
  }
  function Uw(a, b, c) {
    return (b = a.A[b] && a.A[b][c]) ? Tw(a, b) : null;
  }
  function Vw(a, b, c, d) {
    var e = a.A[b] && a.A[b][c];
    e &&
      (e.branches().size === 0 || e.M() || (e.Fa("int"), Wq(e, "ian", d)),
      Uw(a, b, c),
      Sw(a, e, !0));
  }
  function Ww(a, b, c, d) {
    var e = a.A[b];
    if (!(a.C[b] > c)) {
      for (let f of Object.keys(e))
        (e = Uw(a, b, f)) && e.A < c && Vw(a, b, f, d);
      a.C[b] = c;
    }
  }
  function Xw(a, b, c) {
    return (a = a.F[b]) && !!a.actions[c];
  }
  function Yw(a, b, c) {
    c = { prefix: null, provider: c };
    a.D[b] || (a.D[b] = []);
    a.D[b].push(c);
  }
  var $w = class {
    constructor() {
      var a = {
        init: {
          td: !0,
          Qd: [],
          actions: { application_init: { tags: ["render"] } },
        },
        scene: {
          td: !0,
          Qd: ["transitions"],
          actions: {
            click_scene: { tags: ["render"] },
            move_camera: { tags: ["render", "camera_change"] },
            scroll_zoom: { tags: ["render", "camera_change"] },
          },
        },
        scene_hover: {
          td: !0,
          Qd: [],
          actions: {
            hover_on_map: { tags: [] },
            hover_on_poi: { tags: ["render"] },
          },
        },
        transitions: {
          td: !1,
          Qd: ["scene"],
          actions: {
            clear_map: { tags: ["render"] },
            compose_directions_request: { tags: ["render"] },
            directions_inspect_step: { tags: ["render"] },
            directions_inspect_step_done: { tags: ["render"] },
            get_directions: { tags: ["render"] },
            manual_url_change: { tags: ["render"] },
            search: { tags: ["render", "camera_change"] },
            spotlight_alternate_route: { tags: ["render"] },
            spotlight_implicit_route: { tags: ["render"] },
            spotlight_indoor: { tags: ["render"] },
            spotlight_poi: { tags: ["render"] },
            suggest: { tags: ["render"] },
            switch_map_mode: { tags: ["render"] },
            show_pano: { tags: ["render"] },
          },
        },
      };
      this.F = a;
      this.B = new Map();
      this.A = {};
      this.C = {};
      this.G = {};
      this.D = {};
      this.H = {};
      Gm(a, (b, c) => {
        this.A[c] = {};
        this.C[c] = 0;
      });
    }
    isActive(a) {
      return !!Tw(this, a);
    }
    Te(a, b, c) {
      if (!Xw(this, b, c)) return !1;
      var d = Tw(this, a);
      if (!d) return !1;
      if (d.C === b && d.qb === c) return !0;
      if (this.C[b] > d.A) return !1;
      var e = this.F[b];
      if (e.td) {
        let f = Uw(this, b, c);
        if (f && f.A > d.A) return !1;
      }
      for (let f of e.Qd) Ww(this, f, d.A, c);
      Vw(this, b, c, c);
      d.C = b;
      d.qb = c;
      Rw(this, a, d);
      e.td || Ww(this, b, d.A, c);
      return !0;
    }
    start(a, b, c) {
      if (Xw(this, a, b) && !Tw(this, c)) {
        var d = new Dw(a, b, c),
          e = this.F[a];
        for (let f of e.Qd) Ww(this, f, d.A, b);
        e.td ? Vw(this, a, b, b) : Ww(this, a, d.A, b);
        a = e.actions[b] ? e.actions[b].tags : [];
        for (let f of a) {
          if ((a = this.G[f])) for (let g of a) new Zw(g, f, c);
          if ((a = this.D[f]))
            for (let g of a) {
              let h = g.provider.uf();
              h &&
                Fu(c.C, "beforedone", (k) => {
                  var l = g;
                  k = k.hb;
                  var m = l.prefix;
                  if ((l = l.provider.uf())) (l = l.Ig(h)), Qw(l, k.X, m || "");
                });
            }
          if ((a = this.H[f])) for (let g of a) g.Qi(c);
        }
        Rw(this, c, d);
      }
    }
  };
  function ax(a, b) {
    var c = b.X;
    !a.A &&
      a.B.Ej(c) &&
      ((a.A = !0),
      c.gb(a.Vb),
      a.B.Si(() => {
        a.A = !1;
        c.done(a.Vb);
        c.branches().size === 0 && Ou(a.C);
      }, c));
    a.A && b.preventDefault();
  }
  class Zw {
    constructor(a, b, c) {
      this.B = a;
      this.A = !1;
      this.Vb = "actionmanager.flowgate-" + b;
      this.C = Fu(c.C, "beforedone", (d) => {
        ax(this, d.hb);
      });
    }
  }
  var bx = class extends Jw {
    constructor() {
      super({}, "NULL_FLOW");
      this.K();
      super.done("main-actionflow-branch");
    }
    gb() {}
    done() {}
    A() {}
    Te() {
      return !1;
    }
    isActive() {
      return !1;
    }
  };
  var cx = new Su();
  new Su();
  var dx = null;
  function Mw() {
    dx || (dx = new $w());
    return dx;
  }
  function ex(a, b, c) {
    a = fx(a);
    return Fu(a, b, gx(c), !1);
  }
  function hx(a, b, c, d) {
    if (d instanceof ru) {
      var e = d;
      e.type = b;
    } else e = new ru(b);
    e.C = { event: d, X: c };
    fx(a).dispatchEvent(e);
  }
  function ix(a, b, c) {
    a = fx(a);
    var d = fx(c);
    return Fu(a, b, (e) => {
      d.dispatchEvent(e);
    });
  }
  function fx(a) {
    if (a.dispatchEvent) return a.Ge || (a.Ge = () => null), a;
    a.hg = a.hg || new Su();
    return a.hg;
  }
  function gx(a) {
    return (b) => {
      var c = b.C;
      c
        ? a.call(void 0, c.X, c.event)
        : b instanceof su && b.hb.X instanceof Rq
        ? a.call(void 0, new bx(), b)
        : ((c = new Jw(dx, "event_" + b.type)),
          a.call(void 0, c, b),
          c.done("main-actionflow-branch"));
    };
  }
  var jx = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var kx = Y(),
    lx = new Fv();
  function mx(a) {
    return a ? a.Mb() === 2 || a.Mb() === 3 : !1;
  }
  function nx(a) {
    return a ? a.Mb() === 4 : !1;
  }
  function ox(a, b) {
    if (a.length !== b.length) return !1;
    for (let c = 0; c < a.length; ++c) if (a[c] !== b[c]) return !1;
    return !0;
  }
  function px(a, b) {
    var c = qx;
    a = a || [];
    b = b || [];
    var d = a.length > b.length ? a.length : b.length;
    for (let e = 0; e < d; ++e) if ((a[e] || c) !== (b[e] || c)) return !1;
    return !0;
  }
  function rx(a, b) {
    mu(a, lx);
    kx[0] = b[0] - lx.Pa;
    kx[1] = b[1] - lx.Qa;
    kx[2] = b[2] - lx.Ra;
    b = Co(yo(Math.atan2(kx[0], kx[1]), Math.PI * 2));
    var c = Co(
      Math.atan2(kx[2], Math.sqrt(kx[0] * kx[0] + kx[1] * kx[1])) + Math.PI / 2
    );
    kj(a).nb(b);
    kj(a).ab(c);
  }
  function sx(a, b) {
    for (var c; !(c = a.next()).done; ) b(c.value);
  }
  function tx(a, b) {
    var c = new Set(a);
    sx(b[Symbol.iterator](), (d) => c.delete(d));
    return c;
  }
  function ux(a, b) {
    for (let c of b) a.add(c);
  }
  function vx(a) {
    for (let b = 0; b < a.A.length; ++b) Ou(a.L[b]);
    a.L = [];
  }
  function wx(a) {
    for (var b = Array.from(a.G.values()); b.length > 0; ) {
      var c = b.shift();
      c.Pd();
      c = xx(a, c, qx);
      c.F && (c.F.cancel(), (c.F = null));
      c.J && (c.J.cancel(), (c.J = null));
    }
    a.G.clear();
  }
  function yx(a, b, c, d, e) {
    mx(b) && (C(c, 6) || zx(xx(a, b, c), e));
    b = xx(a, b, c);
    Ax(b, e, a.D);
    b.Hb(a.P, e, d);
  }
  function Bx(a) {
    for (let b = 0; b < a.A.length; ++b) {
      let c = ex(a.A[b], "TileReady", (d) => {
        Cx(a, d);
      });
      a.L.push(c);
    }
  }
  function xx(a, b, c) {
    var d = a.O.getData(b.id());
    d || ((d = a.Z.create(b, c, a.camera)), a.O.setData(b.id(), d));
    d.A = c;
    return d;
  }
  function Dx(a, b) {
    for (let g = 0; g < a.A.length; ++g) {
      var c = a,
        d = a.A[g],
        e = a.C[g],
        f = b;
      mx(d) && (C(e, 6) || zx(xx(c, d, e), f));
    }
  }
  function Cx(a, b) {
    for (let f = 0; f < a.A.length; ++f) {
      var c = a,
        d = b,
        e = a.D;
      let g = xx(c, a.A[f], a.C[f]);
      Ax(g, d, c.D);
      g.Hb(c.P, d, e);
    }
  }
  function Ex(a, b, c) {
    var d = Fx,
      e;
    a: {
      for (e = a.A.length - 1; e >= 0; e--) {
        var f = a.C[e];
        if (Pf(f, 1) && D(f, 1) === 1) break a;
      }
      e = -1;
    }
    if ((f = e !== -1)) {
      {
        let g = a.A[e];
        mx(g)
          ? ((f = a.C[e]),
            Dv(a.camera, b, c, Gx),
            xx(a, g, f).be(Gx, d),
            (f = d.x >= 0 && d.x <= 1 && d.y >= 0 && d.y <= 1))
          : (f = !1);
      }
    }
    return f ? e : -1;
  }
  function Hx(a) {
    var b = a.mb();
    if (b) {
      let c = zv(a.camera),
        d = mj(a.T);
      c.width = Math.max(1, d.S() - b.left - b.right);
      c.height = Math.max(1, d.R() - b.top - b.bottom);
      nu(a.camera, c);
    }
  }
  var Jx = class extends Su {
      constructor(a, b, c, d) {
        super();
        this.I = b;
        this.Z = c;
        this.W = d;
        this.camera = new Fv();
        this.F = !1;
        this.O = new kt(6);
        this.A = [];
        this.C = [];
        this.G = new Set();
        this.L = [];
        this.H = new Ss(0, 0, 0, 0);
        this.T = new U();
        this.D = () => {
          Ix(a);
        };
        this.P = a.A;
      }
      bd(a, b, c) {
        if (!ox(this.A, a) || !px(this.C, c)) {
          this.F = !1;
          vx(this);
          ux(this.G, this.A);
          this.G = tx(this.G, a);
          wx(this);
          this.A = [];
          this.C = [];
          var d = a.length;
          d = d > 6 ? 6 : d;
          for (let e = 0; e < d; ++e) {
            let f = a[e];
            if (nx(f)) continue;
            this.A.push(f);
            let g = qx;
            if (c) {
              let h = c[e];
              h && (g = h);
            }
            this.C.push(g);
            mx(f)
              ? yx(this, f, g, this.D, b)
              : (f.oc(b),
                f.Pb(
                  b.U((h) => {
                    h !== 4 && h !== 0 && yx(this, f, g, this.D, b);
                  }, "br-onready")
                ));
          }
          Bx(this);
        }
      }
      Hb(a, b, c = qx, d) {
        function e() {
          d && d(a);
        }
        nx(a) ||
          (mx(a) || a.oc(b),
          a.Pb(
            b.U((f) => {
              f === 4 ? e() : yx(this, a, c, e, b);
            }, "prepare-onready")
          ));
      }
      run() {
        this.F = !1;
        this.I.lg();
        var a = this.A.length;
        for (var b = 0; b < a; ++b) this.Ce(this.A[b], this.C[b]);
        this.I.jg();
        this.F = !1;
        if (this.A.length !== 0) {
          a = !0;
          for (b = 0; b < this.A.length; ++b) {
            let d = xx(this, this.A[b], this.C[b]);
            a: if (d.C.length === 0) var c = !1;
            else {
              for (c = 0; c < d.C.length; ++c)
                if (!d.C[c].Og()) {
                  c = !1;
                  break a;
                }
              c = !0;
            }
            if (!c || d.Z()) {
              a = !1;
              break;
            }
          }
          this.F = a;
        }
        this.F && this.dispatchEvent(new ru("ViewportReady", this));
      }
      qc(a) {
        Dx(this, a);
        Cx(this, a);
      }
      Ce(a, b) {
        if (mx(a) && D(b, 1) !== 0) {
          var c = xx(this, a, b);
          if (c.H) {
            var d = (Date.now() - c.H) / 400;
            var e = [],
              f = c.I.length;
            for (let g = 0; g < f; g++) {
              let h = c.I[g];
              h.Fd = d;
              d < 1 && e.push(h);
            }
            c.I = e;
            c.I.length || (c.H = 0);
            d = !!c.I.length;
          } else d = !1;
          d && this.D();
          this.I.Ce(a, b, c);
        }
      }
      Xa() {
        return this.camera;
      }
      clear() {
        vx(this);
        ux(this.G, this.A);
        wx(this);
        this.O.clear();
        this.A = [];
        this.C = [];
      }
      Ta(a, b, c, d, e) {
        var f = ls(this.W);
        C(f, 5) &&
          ((this.H.top = a),
          (this.H.right = b),
          (this.H.bottom = c),
          (this.H.left = d),
          this.I.Ta(a, b, c, d),
          Hx(this),
          Dx(this, e),
          Cx(this, e),
          this.D());
      }
      mb() {
        return this.H;
      }
      Ob() {
        return this.F;
      }
      Ib(a) {
        this.I.Ib(a);
      }
      setCamera(a, b) {
        this.F = !1;
        mu(a, this.camera);
        var c = cu(Zi(hj(a))),
          d = zv(this.camera);
        d.M = c * 0.01;
        d.F = void 0;
        d.G = void 0;
        d.H = void 0;
        nu(this.camera, d);
        this.T = a;
        Hx(this);
        Dx(this, b);
        Cx(this, b);
      }
    },
    Kx,
    Lx = new jx();
  Kx = P(Lx, 1, 1);
  var Mx;
  Mx = P(Kx, 5, 1);
  var qx = P(Mx, 2, 0),
    Gx = new xv();
  function Nx() {
    return new Float64Array(2);
  }
  function Ox(a, b, c) {
    var d = (c + 0.5) * a.F;
    c = Math.sin(d);
    d = Math.cos(d);
    b = 1.5 * Math.PI - b * a.D;
    var e = Math.sin(b);
    a.dir[0] = c * Math.cos(b);
    a.dir[1] = c * e;
    a.dir[2] = d;
    return a.dir;
  }
  var Px = class {
    constructor(a, b) {
      this.width = a;
      this.dir = Y();
      this.A = Nx();
      this.B = a / (2 * Math.PI);
      this.D = 1 / this.B;
      this.C = b / Math.PI;
      this.F = 1 / this.C;
    }
    project(a) {
      var b = Math.acos(a[2]) * this.C - 0.5;
      a = (Math.atan2(a[0], a[1]) + Math.PI) * this.B;
      a >= this.width - 0.5 && (a -= this.width);
      this.A[0] = a;
      this.A[1] = b;
      return this.A;
    }
  };
  function Qx(a, b, c) {
    if (!a.A.length) return Rx(a, b, c);
    var d = a.B.project(b);
    var e = d[0];
    d = d[1];
    a.F
      ? ((e = Math.floor(e + 0.5)),
        (d = Math.floor(d + 0.5)),
        e >= a.width ? (e -= a.width) : e < 0 && (e += a.width),
        d >= a.height ? (d -= a.height) : d < 0 && (d += a.height),
        (e = Sx(a.F, a.offset + d * a.width + e) || 0))
      : (e = 0);
    var f = e;
    if (f <= 0) return Rx(a, b, c);
    f *= 4;
    e = a.A[f++];
    d = a.A[f++];
    var g = a.A[f++];
    a = a.A[f++];
    c && ((c[0] = e), (c[1] = d), (c[2] = g));
    return xo(a / (b[0] * e + b[1] * d + b[2] * g), 0.1, 500);
  }
  function Tx(a, b, c, d = new xv()) {
    if (a.width === 0 || a.height === 0 || !a.B) return null;
    b = xo(b, 0, 1);
    c = xo(c, 0, 1);
    b *= a.S() - 1;
    c *= a.R() - 1;
    c = Ox(a.B, b, c);
    a = Qx(a, c, d.dir);
    if (a === 0) return null;
    vt(c, a, d.origin);
    return d;
  }
  function Rx(a, b, c) {
    c && st(c, Ux);
    return a.C === 0 && a.D > 0 && b[2] < 0 ? (-a.D * wt(b)) / b[2] : a.C;
  }
  var Vx = class {
      constructor(a, b, c = [], d, e = 0, f = 0, g = 0) {
        this.width = a;
        this.height = b;
        this.A = c;
        this.F = d;
        this.offset = e;
        this.C = f;
        this.D = g;
        this.B = new Px(a, b);
      }
      S() {
        return this.width;
      }
      R() {
        return this.height;
      }
    },
    Wx = new Vx(512, 512, void 0, void 0, 0, 500);
  new Vx(512, 512, void 0, void 0, 0, 1);
  var Xx = new Vx(512, 512, void 0, void 0, 0, 0, 3),
    Ux = rt(Y(), 0, 0, 1);
  var Zx = class extends Jx {
      Vd(a, b, c) {
        var d = Ex(this, a, b);
        if (d === -1) return null;
        var e = this.A[d];
        d = this.C[d];
        Dv(this.camera, a, b, Yx);
        a = e.xa();
        b = a.Mg;
        e = d.da;
        e = xf(e, e[x] | 0, U, 3);
        return b.call(a, Yx, e, Ze(d, 4, void 0, void 0, Fd), c);
      }
      Tc(a, b) {
        var c = 500;
        for (let d = 0; d < this.A.length; d++) {
          let e = this.A[d].xa().Tc(a, b);
          e < c && (c = e);
        }
        return c;
      }
      Cd() {}
      Ad(a) {
        a[0] = 1;
        a[1] = 179;
      }
      Fe(a, b, c) {
        a = Ex(this, a, b);
        return a === -1 ? null : this.A[a].Ud(Fx, c);
      }
      Ja() {}
    },
    Yx = new xv(),
    Fx = new As();
  function $x(a, b) {
    a.A = b;
    for (ix(a.A, "TileReady", a); a.C.length > 0; ) a.C.shift()();
  }
  var ay = class extends Su {
    constructor() {
      super(...arguments);
      this.A = null;
      this.C = [];
      this.uid = `${sa(this)}`;
    }
    Mb() {
      return this.A ? this.A.Mb() : 0;
    }
    Ia() {
      return this.A ? this.A.Ia() : null;
    }
    Xa() {
      return this.A ? this.A.Xa() : null;
    }
    oc(a) {
      this.A
        ? this.A.oc(a)
        : this.C.push(
            a.U(() => {
              this.A.oc(a);
            }, "dtr-prefetch")
          );
    }
    xa() {
      return this.A ? this.A.xa() : null;
    }
    Rb() {
      this.A
        ? this.A.Rb()
        : this.C.push(() => {
            this.A.Rb();
          });
    }
    Jb(a) {
      this.A
        ? this.A.Jb(a)
        : this.C.push(() => {
            this.A.Jb(a);
          });
    }
    Yd(a) {
      return this.A ? this.A.Yd(a) : !1;
    }
    Nb(a, b, c) {
      return this.A ? this.A.Nb(a, b, c) : null;
    }
    ye(a, b) {
      this.A
        ? this.A.ye(a, b)
        : this.C.push(() => {
            this.A.ye(a, b);
          });
    }
    xe(a, b) {
      this.A
        ? this.A.xe(a, b)
        : this.C.push(() => {
            this.A.xe(a, b);
          });
    }
    Hd(a, b) {
      this.A
        ? this.A.Hd(a, b)
        : this.C.push(
            a.U(() => {
              this.A.Hd(a, b);
            }, "dtr-getconfig")
          );
    }
    Qb(a, b) {
      this.A
        ? this.A.Qb(a, b)
        : this.C.push(
            b.U(() => {
              this.A.Qb(a, b);
            }, "dtr-setconfig")
          );
    }
    je() {
      this.A
        ? this.A.je()
        : this.C.push(() => {
            this.A.je();
          });
    }
    tc(a, b, c, d, e) {
      this.A
        ? this.A.tc(a, b, c, d, e)
        : this.C.push(
            d.U(() => {
              this.A.tc(a, b, c, d, e);
            }, "dtr-getile")
          );
    }
    kd(a, b, c) {
      this.A
        ? this.A.kd(a, b, c)
        : this.C.push(() => {
            this.A.kd(a, b, c);
          });
    }
    oe(a, b, c) {
      this.A
        ? this.A.oe(a, b, c)
        : this.C.push(() => {
            this.A.oe(a, b, c);
          });
    }
    Af() {
      return this.A ? this.A.Af() : !1;
    }
    Pd() {
      this.A
        ? this.A.Pd()
        : this.C.push(() => {
            this.A.Pd();
          });
    }
    Cf() {
      return this.A ? this.A.Cf() : !1;
    }
    Ud(a, b) {
      return this.A ? this.A.Ud(a, b) : null;
    }
    hc() {
      return this.A ? this.A.hc() : [];
    }
    Kd(a) {
      this.A
        ? this.A.Kd(a)
        : this.C.push(() => {
            this.A.Kd(a);
          });
    }
    id() {
      return this.uid;
    }
    Ab() {
      return this.A ? this.A.Ab() : null;
    }
    Pb(a) {
      this.A
        ? this.A.Pb(a)
        : this.C.push(() => {
            this.A.Pb(a);
          });
    }
    He() {
      return this.A?.He() || "";
    }
  };
  var by = class extends ay {
    Za() {
      return this.A?.Za() || null;
    }
    hc() {
      return this.A?.hc() || [];
    }
    Sd() {
      return this.A?.Sd() || null;
    }
    Yb() {
      return this.A?.Yb() || null;
    }
  };
  function cy(a, b, c, d, e) {
    var f = a.zoom + 1;
    if (!(f > d)) {
      var g = 1 << (d - f);
      d = a.x;
      var h = a.x + g,
        k = a.y;
      g = a.y + g;
      dy(a, d, k, f, b, c, e);
      dy(a, h, k, f, b, c, e);
      dy(a, d, g, f, b, c, e);
      dy(a, h, g, f, b, c, e);
    }
  }
  function ey(a, b, c, d, e) {
    if (!(a.zoom >= 3 || a.zoom >= d)) {
      a.children = [];
      cy(a, b, c, d, e);
      for (let f = 0; f < a.children.length; f++) ey(a.children[f], b, c, d, e);
      for (b = 0; b < a.children.length; b++) {
        c = a.children[b].A;
        for (d = 0; d < 3; d++) a.A[d] = Math.min(a.A[d], c[d]);
        for (d = 3; d < 6; d++) a.A[d] = Math.max(a.A[d], c[d]);
      }
    }
  }
  function fy(a, b, c, d, e, f, g, h) {
    if (!ow(a.A, b)) return [];
    var k = h(a.x, a.y);
    k = Math.min(k, f);
    var l = a.B;
    l.J = Math.min(k, l.I);
    if (a.zoom >= k)
      return (
        c &&
          ((c = a.B),
          c.B ||
            ((c.B = new Float64Array(6)), pw(c.x, c.y, c.I, c.C.xa(), c.B, !0)),
          (c = !ow(c.B, b))),
        c ? [] : [a.B]
      );
    a.children.length === 0 && cy(a, d, e, f, g);
    k = [];
    for (l = 0; l < a.children.length; l++)
      k = k.concat(fy(a.children[l], b, c, d, e, f, g, h));
    return k;
  }
  function dy(a, b, c, d, e, f, g) {
    b >= e ||
      c >= f ||
      !(e = g(b, c, d)) ||
      ((b = new gy(b, c, d, e)), a.children.push(b));
  }
  var gy = class {
    constructor(a, b, c, d, e) {
      this.x = a;
      this.y = b;
      this.zoom = c;
      this.B = d;
      this.children = [];
      this.A = e || new Float64Array(d.getBoundingBox());
    }
  };
  var hy = [],
    iy = 1e3 / 30,
    jy = { value: void 0, done: !0 },
    ky = { value: void 0, done: !1 };
  function ly(a) {
    if (a.X) {
      var b = a.X;
      a.X = null;
      a.U();
      b.done("img-patch-prepare");
    }
  }
  var my = class {
      constructor(a, b, c = () => {}) {
        this.A = a;
        this.U = c;
        this.X = b;
        b.gb("img-patch-prepare");
      }
      next() {
        if (!this.X) return jy;
        if (this.A.length === 0) return ly(this), jy;
        var a = this.A.shift();
        this.B(a);
        this.A.length === 0 ? (ly(this), (a = jy)) : (a = ky);
        return a;
      }
      cancel() {
        this.X && ly(this);
      }
      B(a) {
        a.Gb();
      }
    },
    ny = class extends my {
      constructor(a, b, c = () => {}) {
        super(a, b, c);
      }
      B(a) {
        a.Gf();
      }
    };
  function mv(a) {
    oy(a);
    return a.G;
  }
  function Hv(a) {
    oy(a);
    var b = [];
    for (let c = 0; c < a.C.length; ++c) {
      let d = a.C[c];
      d.Ka() && b.push(d);
    }
    return b;
  }
  function Ax(a, b, c) {
    a.J && (a.J.cancel(), (a.J = null));
    oy(a);
    var d = [];
    for (let e = 0; e < a.C.length; ++e) {
      let f = a.C[e];
      f.Ka() || d.push(f);
    }
    if (d.length) for (a = new ny(d, b, c); !a.next().done; );
    else c && c();
  }
  function zx(a, b) {
    oy(a);
    for (let f = 0; f < a.C.length; ++f) {
      let g = a.C[f];
      var c = g,
        d = b;
      let h = c.J;
      var e = Math.max(0, c.C.xa().ob() - h);
      let k = c.x >> e;
      e = c.y >> e;
      c.C.tc(k, e, h, d);
      d = hw({ x: k, y: e, zoom: h });
      c = a;
      c.B.Yd(d) ||
        (c.D[d] || (c.D[d] = []), c.D[d].indexOf(g) === -1 && c.D[d].push(g));
    }
  }
  function py(a, b, c, d) {
    var e = b + c * a.K;
    d >= a.M.length && (a.M[d] = []);
    a.M[d][e] || (a.M[d][e] = a.ga.create(a.B, a.sa, b, c, d));
    return a.M[d][e];
  }
  function qy(a) {
    ex(a.B, "TileReady", (b, c) => {
      b = hw({ x: c.x, y: c.y, zoom: c.zoom });
      if (a.D[b]) {
        c = a.D[b].length;
        for (let d = 0; d < c; d++) {
          let e = a.D[b][d];
          e.Fd === 1 && ((e.Fd = 0), a.I.push(e));
        }
        delete a.D[b];
        !a.H && Object.keys(a.D).length <= 5 && (a.H = Date.now());
      }
    });
  }
  function oy(a) {
    if (!a.Yc) {
      if (!a.B.xa() || !a.B.xa().Yc()) return;
      a.initialize();
    }
    var b = !vh(B(a.W, U, 3), B(a.A, U, 3)) || !a.N;
    if (!a.N || !a.N.equals(a.camera) || b) {
      a.N = a.camera.clone();
      y(a.W, a.A);
      if (b) {
        b = a.B.xa();
        var c;
        z(a.A, 3) && (c = B(a.A, U, 3));
        var d;
        Pf(a.A, 4) && (d = D(a.A, 4));
        b.zd(a.L, c, d);
        Kt(a.L, a.aa);
      }
      c = a.G;
      d = a.camera;
      Bv(d, a.L, d.A);
      bv(c, d.A);
      d = a.camera;
      Av(d);
      cv(d.C, c, a.G);
      c = a.G;
      d = a.B.xa().jh(a.camera);
      d !== 1 &&
        ((b = ev(0.5, 0.5)),
        cv(c, b, c),
        (b = fv),
        (b[0] = d),
        (b[1] = 0),
        (b[2] = 0),
        (b[3] = 0),
        (b[4] = 0),
        (b[5] = d),
        (b[6] = 0),
        (b[7] = 0),
        (b[8] = 0),
        (b[9] = 0),
        (b[10] = 1),
        (b[11] = 0),
        (b[12] = 0),
        (b[13] = 0),
        (b[14] = 0),
        (b[15] = 1),
        cv(c, b, c),
        (b = ev(-0.5, -0.5)),
        cv(c, b, c));
      a.G = c;
      ry(a);
    }
  }
  function ry(a) {
    sy(a);
    var b = a.B instanceof by && ty(a),
      c = a.B.xa();
    a.C = fy(
      a.T,
      uy,
      b,
      a.K,
      a.O,
      c.ob(),
      (d, e, f) => py(a, d, e, f),
      (d, e) => c.qg(d, e, a.camera, a.ea, a.L, ty(a))
    );
  }
  function sy(a) {
    var b = uy;
    Et(vy, a.G);
    a = vy;
    Ht(a, 3, lw);
    lw[0] = -lw[0];
    lw[1] = -lw[1];
    lw[2] = -lw[2];
    lw[3] = -lw[3];
    for (let f = 0; f < 3; f++) {
      var c = f * 2;
      Ht(a, f, mw);
      let g = b[c];
      var d = lw,
        e = mw;
      g[0] = d[0] - e[0];
      g[1] = d[1] - e[1];
      g[2] = d[2] - e[2];
      g[3] = d[3] - e[3];
      Bt(g, 1 / Math.sqrt(g[0] * g[0] + g[1] * g[1] + g[2] * g[2]), g);
      c = b[c + 1];
      d = lw;
      e = mw;
      c[0] = d[0] + e[0];
      c[1] = d[1] + e[1];
      c[2] = d[2] + e[2];
      c[3] = d[3] + e[3];
      Bt(c, 1 / Math.sqrt(c[0] * c[0] + c[1] * c[1] + c[2] * c[2]), c);
    }
  }
  function ty(a) {
    var b = z(a.A, 3) ? hj(B(a.A, U, 3)) : hj(a.B.Xa());
    du(Xi(b), Zi(b), aj(b), wy);
    bu(a.camera.Pa, a.camera.Qa, a.camera.Ra, xy);
    Zt(xy[0], xy[1], xy[2], xy);
    return Math.sqrt(zt(xy, wy)) < 0.01;
  }
  var Ay = class {
      constructor(a, b, c, d) {
        this.B = a;
        this.A = b;
        this.camera = c;
        this.ga = d;
        this.W = new jx();
        this.N = null;
        this.P = this.O = this.V = this.K = 1;
        this.ea = 0;
        this.J = this.F = null;
        this.M = [];
        this.C = [];
        this.G = av();
        this.L = Ct();
        this.aa = Ct();
        this.sa = {};
        this.D = {};
        this.I = [];
        this.H = 0;
        this.Yc = !1;
        this.T = new gy(0, 0, 0, py(this, 0, 0, 0), yy);
        qy(this);
      }
      Hb(a, b, c) {
        this.F && (this.F.cancel(), (this.F = null));
        oy(this);
        var d = [];
        for (let e = 0; e < this.C.length; ++e) {
          let f = this.C[e];
          f.Ng() && d.push(f);
        }
        d.length
          ? ((this.F = new my(d, b, c)),
            zy(a, { iterator: this.F, Fb: 4, Db: 2, priority: 2 }))
          : c && c();
      }
      be(a, b) {
        oy(this);
        var c;
        z(this.A, 3) && (c = B(this.A, U, 3));
        var d;
        Pf(this.A, 4) && (d = D(this.A, 4));
        this.B.xa().be(a, this.aa, b, c, d);
      }
      initialize() {
        var a = this.B.xa();
        this.V = a.Uc();
        this.P = a.Gc();
        this.K = Math.ceil(this.V);
        this.O = Math.ceil(this.P);
        ey(this.T, this.K, this.O, a.ob(), (b, c, d) => py(this, b, c, d));
        this.ea = this.camera.Kb;
        this.Yc = !0;
      }
      Z() {
        return !!this.H;
      }
      Xa() {
        return this.camera.clone();
      }
    },
    yy = new Float64Array(6);
  yy.set([-Infinity, -Infinity, -Infinity, Infinity, Infinity, Infinity]);
  var uy = [At(), At(), At(), At(), At(), At()],
    vy = Ct(),
    fv = av(),
    wy = Y(),
    xy = Y(),
    By = class {
      constructor(a) {
        this.A = a;
      }
      create(a, b, c) {
        return new Ay(a, b, c, this.A);
      }
    };
  var Cy = class extends Zx {
    constructor(a, b, c, d) {
      super(a, new gw(b, c), new By(new Bw()), d);
    }
  };
  var Dy = /(?:^[^@(]*@|\()([^()]+?):(?:(wasm-function\[)|\d+(?::\d+)?\)?$)/,
    Ey = /at ([^ ]+:wasm-function)\[/;
  function Fy(a, b) {
    var c = 0;
    a.forEach((d) => {
      c += d.length;
    });
    b.forEach((d) => {
      c += d.length;
    });
    return 3 * (a.length + b.length) + c * 1.1;
  }
  function Gy(a, b) {
    var c = {},
      d = 0;
    for (let f = 0; f < a.length; ++f) {
      let g = a[f];
      var e = g.match(Ey);
      let h = g.match(Dy),
        k;
      e ? (k = e[1]) : h && (k = h[1] + (h[2] ? ":wasm-function" : ""));
      k &&
        (c[k]
          ? (e = c[k])
          : ((e = ".." + String(d) + ".."), (c[k] = e), b.push(k), d++),
        (a[f] = g.replace(k, e)));
    }
  }
  function Hy(a, b, c) {
    for (var d = Fy(a, b), e = d, f = "", g = null; e > c; ) {
      f = a.pop() || "";
      g = null;
      e = ".." + String(b.length - 1) + "..";
      if (f.indexOf(e) > -1) {
        let h = !1;
        for (let k = a.length - 1; k >= 0; k--)
          if (a[k].indexOf(e) > -1) {
            h = !0;
            break;
          }
        h || (g = b.pop());
      }
      e = Fy(a, b);
    }
    if (Math.ceil(d - e) <= 0) return 0;
    c = Math.floor(c - e);
    c > 3 &&
      ((f = f.length > c ? f.substring(0, c - 3) + "..." : f),
      a.push(f),
      (c -= f.length),
      g && c > 3 && b.push(g.length > c ? g.substring(0, c - 3) + "..." : g));
    return Math.ceil(d - Fy(a, b));
  }
  var Iy = { Ih: 40, zh: 1700 };
  function Jy(a, b, c = document) {
    if (c) {
      var d = Ky(c);
      if (d) {
        var e = () => {
          a(!Ly(c));
        };
        b ? b.listen(c, d, e) : Fu(c, d, e);
      }
    }
  }
  function My(a) {
    var b = Ky(document);
    b &&
      document.addEventListener(
        b,
        () => {
          a(!Ly(document));
        },
        { once: !0 }
      );
  }
  function Ky(a = document) {
    return "hidden" in a
      ? "visibilitychange"
      : "mozHidden" in a
      ? "mozvisibilitychange"
      : "webkitHidden" in a
      ? "webkitvisibilitychange"
      : "visibilityState" in a
      ? "visibilitychange"
      : "";
  }
  function Ly(a = document) {
    return a.visibilityState === "hidden";
  }
  function Ny(a) {
    if (a instanceof Ga && !a.A) return (a.message = "$$suppress$$"), a;
    ra(a) || (a = Error(String(a)));
    return typeof globals !== "undefined" &&
      typeof globals.ErrorHandler !== "undefined"
      ? globals.ErrorHandler.log(a, void 0)
      : a;
  }
  function Oy(a) {
    var b = Py.parseError(a.message);
    a.message = b.errorMessage;
    a.line = Number(a.line);
    var c = b.options;
    c &&
      (c.displayMessage != null && (a.displayMessage = c.displayMessage),
      c.errorType != null && (a.errorType = c.errorType),
      c.glRenderer != null && (a.glRenderer = c.glRenderer),
      c.glErrorCode != null && (a.glErrorCode = c.glErrorCode),
      c.webGlErrors != null &&
        c.webGlErrors.length &&
        (a.webGlErrors = c.webGlErrors),
      c.isContextLost != null && (a.isContextLost = c.isContextLost),
      c.jsVersion != null && (a.jsVersion = c.jsVersion),
      c.wasmHeapSizeBytes != null &&
        (a.wasmHeapSizeBytes = c.wasmHeapSizeBytes),
      c.wasmHeapDeltaBytes != null &&
        (a.wasmHeapDeltaBytes = c.wasmHeapDeltaBytes),
      c.wasmMemoryStats != null &&
        c.wasmMemoryStats.length > 0 &&
        (a.wasmMemoryStats = c.wasmMemoryStats),
      c.width != null && (a.width = c.width),
      c.height != null && (a.height = c.height),
      c.appCrashType != null && (a.appCrashType = c.appCrashType),
      c.appCrashRenderContext != null &&
        (a.appCrashRenderContext = c.appCrashRenderContext),
      c.appCrashTime != null && (a.appCrashTime = c.appCrashTime),
      c.appCrashDuration != null && (a.appCrashDuration = c.appCrashDuration),
      c.appCrashJsVersion != null &&
        (a.appCrashJsVersion = c.appCrashJsVersion));
    a.messageCount = a.count;
    if (b.error?.stack) {
      c = b.error.stack.split("\n");
      var d = Iy.Ih;
      a.stack = [];
      for (let f = 0, g = c.length; f < g && f < d; ++f) {
        var e = c[f].trim();
        e.length > 0 && a.stack.push(e);
      }
      a.stackUrls = [];
      c = a.stack;
      d = a.stackUrls;
      e = Iy.zh - (3 + (a.message || "").length * 1.1);
      Gy(c, d);
      c = Hy(c, d, e);
      a.stackTruncation = c;
    }
    a.error = b.error;
  }
  var Py = {
    parseError: function (a) {
      var b = unescape(a);
      a = null;
      var c = b;
      b = b.split("~#!#~");
      if (b.length === 4) {
        c = Number(b[1]);
        if (c < vv.length) {
          var d = vv[c];
          a = d.error;
          d = d.options;
        }
        c = b[0] + b[2] + b[3];
      }
      return { errorMessage: c, error: a, options: d };
    },
  };
  function Qy(a) {
    try {
      let g = on(a);
      var b = g.fileName;
      b == null && (b = "");
      if (/^https?:\/\//i.test(b)) {
        var c = Jn(b, In) || En,
          d = "view-source:" + Fn(c);
        var e = new Dn(d);
      } else e = Jn("sanitizedviewsrc", In) || En;
      a = e;
      var f = zp([
        yp("Message: " + g.message + "\nUrl: ", { Nf: !0, Of: !0 }),
        Fp({ href: a, target: "_new" }, g.fileName),
        yp(
          "\nLine: " +
            g.lineNumber +
            "\n\nBrowser stack:\n" +
            g.stack +
            "-> [end]\n\nJS stack traversal:\n" +
            sn(void 0) +
            "-> ",
          { Nf: !0, Of: !0 }
        ),
      ]);
    } catch (g) {
      f = yp("Exception trying to expose exception! You win, we lose. " + g, {
        Nf: !0,
        Of: !0,
      });
    }
    return Nn(f).toString();
  }
  la = la || {};
  function Ry(a) {
    switch (a.type) {
      case Sy.A.Ph:
        return "Unauthorized";
      case Sy.A.qh:
        return "Consecutive load failures";
      case Sy.A.TIMEOUT:
        return "Timed out";
      case Sy.A.Dh:
        return "Out of date module id";
      case Sy.A.yh:
        return "Init error";
      default:
        return `Unknown failure type ${a.type}`;
    }
  }
  class Sy extends Error {
    constructor(a, b, c, d, e) {
      super();
      this.name = "ModuleLoadFailure";
      this.type = a;
      this.status = b;
      this.url = d;
      this.cause = e;
      this.message = this.toString();
    }
    toString() {
      return `${Ry(this)} (${this.status != void 0 ? this.status : "?"})`;
    }
  }
  la.Bh = Sy;
  la.Bh.A = { Ph: 0, qh: 1, TIMEOUT: 2, Dh: 3, yh: 4 };
  function Ty(a, b, c) {
    if (a.length === 0) b(c);
    else if (a.length === 0) b(c);
    else {
      var d = a.length,
        e = [],
        f = [],
        g = c.U(b, "delayed:getMultiple");
      b = () => {
        --d || g(c);
      };
      var h = (l) => () => {
          Uy(l, c);
        },
        k = a.length;
      for (let l = 0; l < k; l++) {
        let m = a[l];
        if (!m || m.Ha()) b(c);
        else {
          m.B.push(b);
          let n = Vy(m);
          if (Wy[n]) Uy(m, c);
          else {
            e.push(m);
            f.push(n);
            let q = Xy[n];
            q || (q = Xy[n] = []);
            q.push(h(m));
          }
        }
      }
    }
  }
  function Yy(a, b) {
    a instanceof Em && (a = a.B);
    if (!Zy || !$y)
      if (((Wy[a] = b), (b = Xy[a]))) {
        let c = b.length;
        for (let d = 0; d < c; d++) b[d]();
        delete Xy[a];
      }
  }
  function Uy(a, b) {
    try {
      if (!a.F) {
        let c = Wy[Vy(a)];
        a.F = !0;
        c(
          (d) => {
            a.C = d;
            a.D = [];
            d = "delayed:ready:" + Vy(a);
            b.gb(d);
            try {
              let e = a.B.length;
              for (let f = 0; f < e; f++) a.B[f](b);
              a.B = [];
            } finally {
              b.done(d);
            }
          },
          b,
          ...a.D
        );
      }
    } catch (c) {
      throw (Ew(c.stack || Qy(c)), Ny(c));
    }
  }
  function Vy(a) {
    return a.A instanceof Em ? a.A.B : a.A;
  }
  function az(a, b) {
    var c = a.A.toString();
    bz.has(c)
      ? a.get(() => {}, b)
      : cz.has(c)
      ? cz.get(c).add(a)
      : cz.set(c, new Set([a]));
  }
  var dz = class {
      constructor(a, b = []) {
        this.A = a;
        this.D = b;
        this.C = null;
        this.B = [];
        this.F = !1;
      }
      Ha() {
        return !!this.C;
      }
      onLoad(a, b) {
        this.Ha()
          ? a(this.ka(), b)
          : (this.B.push((c) => {
              a(this.ka(), c);
            }),
            this.A instanceof Em && az(this, b));
      }
      get(a, b) {
        Ty(
          [this],
          (c) => {
            a(this.ka(), c);
          },
          b
        );
      }
      ka() {
        return this.C;
      }
      toString() {
        return `Delayed(${this.A instanceof Em ? this.A.toString() : this.A})`;
      }
    },
    $y = null,
    Zy = !1,
    Xy = {},
    Wy = {},
    bz = new Set(),
    cz = new Map();
  var ez = class extends dz {
    constructor(a, b, c, d) {
      super("CPNR", [...arguments]);
    }
  };
  function fz(a, b, c, d, e, f) {
    b = new Cy(c, d, e, f);
    a(b);
  }
  Y();
  Y();
  Y();
  Y();
  Ct();
  function gz(a, b) {
    var c = hj(a),
      d = hj(b);
    return (
      hz(Zi(c), Zi(d)) &&
      hz(Xi(c), Xi(d)) &&
      hz(aj(c), aj(d), 1) &&
      hz(jj(a).Ba(), jj(b).Ba()) &&
      hz(jj(a).za(), jj(b).za()) &&
      hz(jj(a).Va(), jj(b).Va()) &&
      hz(a.Ga(), b.Ga())
    );
  }
  function hz(a, b, c = 1e-7) {
    return Math.abs(a - b) < c;
  }
  function iz(a, b) {
    if (z(a, 1)) {
      var c = hj(a),
        d = ij(b);
      cj(c) && bj(d, aj(c));
      Pf(c, 3) && $i(d, Zi(c));
      Pf(c, 2) && Yi(d, Xi(c));
    }
    lj(a) &&
      ((c = jj(a)),
      (d = kj(b)),
      Pf(c, 1) && d.nb(c.Ba()),
      Pf(c, 3) && d.wc(c.Va()),
      Pf(c, 2) && d.ab(c.za()));
    Pf(a, 4) && P(b, 4, a.Ga());
  }
  var jz = { bb: 18896 },
    kz = { bb: 18895 },
    lz = { bb: 6176 },
    mz = { bb: 31665 },
    nz = { bb: 5610 },
    oz = { bb: 5611 };
  var pz = {
      wh: ["BC", "AD"],
      uh: ["Before Christ", "Anno Domini"],
      Ch: "JFMAMJJASOND".split(""),
      Kh: "JFMAMJJASOND".split(""),
      Ah: "January February March April May June July August September October November December".split(
        " "
      ),
      Jh: "January February March April May June July August September October November December".split(
        " "
      ),
      Fh: "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" "),
      Mh: "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" "),
      Rh: "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "),
      Oh: "Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "),
      Hh: "Sun Mon Tue Wed Thu Fri Sat".split(" "),
      Nh: "Sun Mon Tue Wed Thu Fri Sat".split(" "),
      Hi: "SMTWTFS".split(""),
      Lh: "SMTWTFS".split(""),
      Gh: ["Q1", "Q2", "Q3", "Q4"],
      Eh: ["1st quarter", "2nd quarter", "3rd quarter", "4th quarter"],
      ph: ["AM", "PM"],
      ag: ["EEEE, MMMM d, y", "MMMM d, y", "MMM d, y", "M/d/yy"],
      gg: [
        "h:mm:ss\u202fa zzzz",
        "h:mm:ss\u202fa z",
        "h:mm:ss\u202fa",
        "h:mm\u202fa",
      ],
      sh: ["{1} 'at' {0}", "{1} 'at' {0}", "{1}, {0}", "{1}, {0}"],
      Xe: 6,
      Mi: [5, 6],
      Ye: 5,
    },
    qz = pz;
  qz = pz;
  function rz(a, b, c, d, e) {
    a = new Date(a, b, c);
    e = e || 0;
    return (
      a.valueOf() +
      ((((d !== void 0 ? d : 3) - e + 7) % 7) -
        ((((a.getDay() + 6) % 7) - e + 7) % 7)) *
        864e5
    );
  }
  function sz(a, b, c) {
    typeof a === "number"
      ? ((this.A = Bz(a, b || 0, c || 1)), Dz(this, c || 1))
      : ra(a)
      ? ((this.A = Bz(a.getFullYear(), a.getMonth(), a.getDate())),
        Dz(this, a.getDate()))
      : ((this.A = new Date(Date.now())),
        (a = this.A.getDate()),
        this.A.setHours(0),
        this.A.setMinutes(0),
        this.A.setSeconds(0),
        this.A.setMilliseconds(0),
        Dz(this, a));
  }
  function Bz(a, b, c) {
    b = new Date(a, b, c);
    a >= 0 && a < 100 && b.setFullYear(b.getFullYear() - 1900);
    return b;
  }
  p = sz.prototype;
  p.C = qz.Xe;
  p.D = qz.Ye;
  p.clone = function () {
    var a = new sz(this.A);
    a.C = this.C;
    a.D = this.D;
    return a;
  };
  p.getFullYear = function () {
    return this.A.getFullYear();
  };
  p.getMonth = function () {
    return this.A.getMonth();
  };
  p.getDate = function () {
    return this.A.getDate();
  };
  p.getTime = function () {
    return this.A.getTime();
  };
  p.getDay = function () {
    return this.A.getDay();
  };
  p.getUTCFullYear = function () {
    return this.A.getUTCFullYear();
  };
  p.getUTCMonth = function () {
    return this.A.getUTCMonth();
  };
  p.getUTCDate = function () {
    return this.A.getUTCDate();
  };
  p.getUTCHours = function () {
    return this.A.getUTCHours();
  };
  p.getUTCMinutes = function () {
    return this.A.getUTCMinutes();
  };
  p.getTimezoneOffset = function () {
    return this.A.getTimezoneOffset();
  };
  p.set = function (a) {
    this.A = new Date(a.getFullYear(), a.getMonth(), a.getDate());
  };
  p.add = function (a) {
    if (a.years || a.months) {
      var b = this.getMonth() + a.months + a.years * 12,
        c = this.getFullYear() + Math.floor(b / 12);
      b %= 12;
      b < 0 && (b += 12);
      a: {
        switch (b) {
          case 1:
            var d = c % 4 != 0 || (c % 100 == 0 && c % 400 != 0) ? 28 : 29;
            break a;
          case 5:
          case 8:
          case 10:
          case 3:
            d = 30;
            break a;
        }
        d = 31;
      }
      d = Math.min(d, this.getDate());
      this.A.setDate(1);
      this.A.setFullYear(c);
      this.A.setMonth(b);
      this.A.setDate(d);
    }
    a.days &&
      ((c = this.getFullYear()),
      (b = c >= 0 && c <= 99 ? -1900 : 0),
      (a = new Date(
        new Date(c, this.getMonth(), this.getDate(), 12).getTime() +
          a.days * 864e5
      )),
      this.A.setDate(1),
      this.A.setFullYear(a.getFullYear() + b),
      this.A.setMonth(a.getMonth()),
      this.A.setDate(a.getDate()),
      Dz(this, a.getDate()));
  };
  p.B = function (a) {
    var b = this.getFullYear(),
      c = b < 0 ? "-" : b >= 1e4 ? "+" : "";
    return (
      [
        c + Un(Math.abs(b), c ? 6 : 4),
        Un(this.getMonth() + 1, 2),
        Un(this.getDate(), 2),
      ].join(a ? "-" : "") + ""
    );
  };
  p.equals = function (a) {
    return !(
      !a ||
      this.getFullYear() != a.getFullYear() ||
      this.getMonth() != a.getMonth() ||
      this.getDate() != a.getDate()
    );
  };
  p.toString = function () {
    return this.B();
  };
  function Dz(a, b) {
    a.getDate() != b &&
      a.A.setUTCHours(a.A.getUTCHours() + (a.getDate() < b ? 1 : -1));
  }
  p.valueOf = function () {
    return this.A.valueOf();
  };
  function Ez(a, b, c, d, e, f, g) {
    this.A =
      typeof a === "number"
        ? new Date(a, b || 0, c || 1, d || 0, e || 0, f || 0, g || 0)
        : new Date(a && a.getTime ? a.getTime() : Date.now());
  }
  Ea(Ez, sz);
  p = Ez.prototype;
  p.getHours = function () {
    return this.A.getHours();
  };
  p.getMinutes = function () {
    return this.A.getMinutes();
  };
  p.getSeconds = function () {
    return this.A.getSeconds();
  };
  p.getMilliseconds = function () {
    return this.A.getMilliseconds();
  };
  p.getUTCHours = function () {
    return this.A.getUTCHours();
  };
  p.getUTCMinutes = function () {
    return this.A.getUTCMinutes();
  };
  p.add = function (a) {
    sz.prototype.add.call(this, a);
    a.hours && this.A.setUTCHours(this.A.getUTCHours() + a.hours);
    a.minutes && this.A.setUTCMinutes(this.A.getUTCMinutes() + a.minutes);
    a.seconds && this.A.setUTCSeconds(this.A.getUTCSeconds() + a.seconds);
  };
  p.B = function (a) {
    var b = sz.prototype.B.call(this, a);
    return a
      ? b +
          "T" +
          Un(this.getHours(), 2) +
          ":" +
          Un(this.getMinutes(), 2) +
          ":" +
          Un(this.getSeconds(), 2)
      : b +
          "T" +
          Un(this.getHours(), 2) +
          Un(this.getMinutes(), 2) +
          Un(this.getSeconds(), 2);
  };
  p.equals = function (a) {
    return this.getTime() == a.getTime();
  };
  p.toString = function () {
    return this.B();
  };
  p.clone = function () {
    var a = new Ez(this.A);
    a.C = this.C;
    a.D = this.D;
    return a;
  };
  function Fz() {}
  function Gz(a) {
    if (typeof a == "number") {
      var b = new Fz();
      b.F = a;
      var c = a;
      if (c == 0) c = "Etc/GMT";
      else {
        var d = ["Etc/GMT", c < 0 ? "-" : "+"];
        c = Math.abs(c);
        d.push(Math.floor(c / 60) % 100);
        c %= 60;
        c != 0 && d.push(":", Un(c, 2));
        c = d.join("");
      }
      b.B = c;
      c = a;
      c == 0
        ? (c = "UTC")
        : ((d = ["UTC", c < 0 ? "+" : "-"]),
          (c = Math.abs(c)),
          d.push(Math.floor(c / 60) % 100),
          (c %= 60),
          c != 0 && d.push(":", c),
          (c = d.join("")));
      a = Hz(a);
      b.D = [c, c];
      b.A = { Ii: a, eg: a };
      b.C = [];
      return b;
    }
    b = new Fz();
    b.B = a.id;
    b.F = -a.std_offset;
    b.D = a.names;
    b.A = a.names_ext;
    b.C = a.transitions;
    return b;
  }
  function Hz(a) {
    var b = ["GMT"];
    b.push(a <= 0 ? "+" : "-");
    a = Math.abs(a);
    b.push(Un(Math.floor(a / 60) % 100, 2), ":", Un(a % 60, 2));
    return b.join("");
  }
  function Iz(a, b) {
    b =
      Date.UTC(
        b.getUTCFullYear(),
        b.getUTCMonth(),
        b.getUTCDate(),
        b.getUTCHours(),
        b.getUTCMinutes()
      ) / 36e5;
    for (var c = 0; c < a.C.length && b >= a.C[c]; ) c += 2;
    return c == 0 ? 0 : a.C[c - 1];
  }
  function Jz(a, b) {
    a = a.F - Iz(a, b);
    return a === -1440 ? 0 : a;
  }
  function Kz(a) {
    this.B = null;
    this.D = a;
    this.C = [];
    typeof a == "number"
      ? Lz(this, a, null)
      : ((this.A = qz), typeof a == "number" ? Mz(this, a) : Nz(this, a));
  }
  var Oz = [
    /^'(?:[^']|'')*('|$)/,
    /^(?:G+|y+|Y+|u+|M+|k+|S+|E+|a+|b+|B+|h+|K+|H+|c+|L+|Q+|d+|m+|s+|v+|V+|w+|z+|Z+)/,
    /^[^'GyYuMkSEabBhKHcLQdmsvVwzZ]+/,
  ];
  function Pz(a) {
    return a.getHours ? a.getHours() : 0;
  }
  function Nz(a, b) {
    for (Qz && (b = b.replace(/\u200f/g, "")); b; ) {
      let c = b;
      for (let d = 0; d < Oz.length; ++d) {
        let e = b.match(Oz[d]);
        if (e) {
          let f = e[0];
          b = b.substring(f.length);
          d == 0 &&
            (f == "''"
              ? (f = "'")
              : ((f = f.substring(1, e[1] == "'" ? f.length - 1 : f.length)),
                (f = f.replace(/''/g, "'"))));
          a.C.push({ text: f, type: d });
          break;
        }
      }
      if (c === b) throw Error("Malformed pattern part: " + b);
    }
  }
  Kz.prototype.format = function (a, b) {
    if (!a) throw Error("The date to format must be non-null.");
    if (this.B) {
      var c = this.B.resolvedOptions().timeZone === "UTC";
      if (Rz || c || b) Lz(this, this.D, b), (Rz = !1);
      return this.B.format(a ? new Date(a.valueOf()) : void 0);
    }
    var d = b ? (a.getTimezoneOffset() - Jz(b, a)) * 6e4 : 0,
      e = (c = d ? new Date(a.getTime() + d) : a);
    b &&
      c.getTimezoneOffset() != a.getTimezoneOffset() &&
      ((e = (c.getTimezoneOffset() - a.getTimezoneOffset()) * 6e4),
      (c = new Date(c.getTime() + e)),
      (d += d > 0 ? -864e5 : 864e5),
      (e = new Date(a.getTime() + d)));
    d = [];
    for (let f = 0; f < this.C.length; ++f) {
      let g = this.C[f].text;
      1 == this.C[f].type ? d.push(Sz(this, g, a, c, e, b)) : d.push(g);
    }
    return d.join("");
  };
  function Lz(a, b, c) {
    var d = { calendar: "gregory" };
    c && (d.timeZone = c.B);
    switch (b) {
      case 0:
        d.dateStyle = "full";
        break;
      case 1:
        d.dateStyle = "long";
        break;
      case 2:
        d.dateStyle = "medium";
        break;
      default:
        d.dateStyle = "short";
        break;
      case 4:
        d.timeStyle = "full";
        break;
      case 5:
        d.timeStyle = "long";
        break;
      case 6:
        d.timeStyle = "medium";
        break;
      case 7:
        d.timeStyle = "short";
        break;
      case 8:
        d.dateStyle = "full";
        d.timeStyle = "full";
        break;
      case 9:
        d.dateStyle = "long";
        d.timeStyle = "long";
        break;
      case 10:
        d.dateStyle = "medium";
        d.timeStyle = "medium";
        break;
      case 11:
        (d.dateStyle = "short"), (d.timeStyle = "short");
    }
    b = "en".replace(/_/g, "-");
    Tz ? (d.numberingSystem = "latn") : b in Zr && (d.numberingSystem = Zr[b]);
    try {
      a.B = new u.Intl.DateTimeFormat(b, d);
    } catch (e) {}
  }
  function Mz(a, b) {
    if (b < 4) var c = a.A.ag[b];
    else if (b < 8) c = a.A.gg[b - 4];
    else if (b < 12)
      (c = a.A.sh[b - 8]),
        (c = c.replace("{1}", a.A.ag[b - 8])),
        (c = c.replace("{0}", a.A.gg[b - 8]));
    else {
      Mz(a, 10);
      return;
    }
    Nz(a, c);
  }
  function Uz(a, b) {
    {
      b = String(b);
      let c = a.A || qz;
      if (c.Uh !== void 0 && !Tz) {
        a = [];
        for (let d = 0; d < b.length; d++) {
          let e = b.charCodeAt(d);
          a.push(
            48 <= e && e <= 57
              ? String.fromCharCode(c.Uh + e - 48)
              : b.charAt(d)
          );
        }
        b = a.join("");
      }
    }
    return b;
  }
  var Tz = !1,
    Rz = !1,
    Qz = !1;
  function Vz(a, b, c, d) {
    c = c.getFullYear();
    c <= 0 && d && (c = 1 - c);
    return Uz(a, Wz(c, b));
  }
  function Wz(a, b) {
    b == 2 && (a %= 100);
    a < 0 && b++;
    return Un(a, b);
  }
  function Xz(a) {
    if (!(a.getHours && a.getSeconds && a.getMinutes))
      throw Error(
        "The date to format has no time (probably a goog.date.Date). Use Date or goog.date.DateTime, or use a pattern without time fields."
      );
  }
  function Yz(a, b) {
    Xz(b);
    b = Pz(b);
    return a.A.ph[b >= 12 && b < 24 ? 1 : 0];
  }
  function Sz(a, b, c, d, e, f) {
    var g = b.length;
    switch (b.charAt(0)) {
      case "G":
        return (
          (c = d.getFullYear() > 0 ? 1 : 0), g >= 4 ? a.A.uh[c] : a.A.wh[c]
        );
      case "y":
        return Vz(a, g, d, !0);
      case "Y":
        return (
          (c = new Date(
            rz(d.getFullYear(), d.getMonth(), d.getDate(), a.A.Ye, a.A.Xe)
          ).getFullYear()),
          g == 2 && (c %= 100),
          Uz(a, Wz(c, g))
        );
      case "u":
        return Vz(a, g, d, !1);
      case "M":
        a: switch (((c = d.getMonth()), g)) {
          case 5:
            g = a.A.Ch[c];
            break a;
          case 4:
            g = a.A.Ah[c];
            break a;
          case 3:
            g = a.A.Fh[c];
            break a;
          default:
            g = Uz(a, Un(c + 1, g));
        }
        return g;
      case "k":
        return Xz(e), Uz(a, Un(Pz(e) || 24, g));
      case "S":
        return Uz(
          a,
          (e.getMilliseconds() / 1e3).toFixed(Math.min(3, g)).slice(2) +
            (g > 3 ? Un(0, g - 3) : "")
        );
      case "E":
        return (c = d.getDay()), g >= 4 ? a.A.Rh[c] : a.A.Hh[c];
      case "a":
        return Yz(a, e);
      case "b":
        return Yz(a, e);
      case "B":
        return Yz(a, e);
      case "h":
        return Xz(e), Uz(a, Un(Pz(e) % 12 || 12, g));
      case "K":
        return Xz(e), Uz(a, Un(Pz(e) % 12, g));
      case "H":
        return Xz(e), Uz(a, Un(Pz(e), g));
      case "c":
        a: switch (((c = d.getDay()), g)) {
          case 5:
            g = a.A.Lh[c];
            break a;
          case 4:
            g = a.A.Oh[c];
            break a;
          case 3:
            g = a.A.Nh[c];
            break a;
          default:
            g = Uz(a, Un(c, 1));
        }
        return g;
      case "L":
        a: switch (((c = d.getMonth()), g)) {
          case 5:
            g = a.A.Kh[c];
            break a;
          case 4:
            g = a.A.Jh[c];
            break a;
          case 3:
            g = a.A.Mh[c];
            break a;
          default:
            g = Uz(a, Un(c + 1, g));
        }
        return g;
      case "Q":
        return (
          (c = Math.floor(d.getMonth() / 3)), g < 4 ? a.A.Gh[c] : a.A.Eh[c]
        );
      case "d":
        return Uz(a, Un(d.getDate(), g));
      case "m":
        return Xz(e), Uz(a, Un(e.getMinutes ? e.getMinutes() : 0, g));
      case "s":
        return Xz(e), Uz(a, Un(e.getSeconds(), g));
      case "v":
        return (f || Gz(c.getTimezoneOffset())).B;
      case "V":
        return (
          (a = f || Gz(c.getTimezoneOffset())),
          g <= 2
            ? a.B
            : Iz(a, c) > 0
            ? a.A.th !== void 0
              ? a.A.th
              : a.A.DST_GENERIC_LOCATION
            : a.A.eg !== void 0
            ? a.A.eg
            : a.A.STD_GENERIC_LOCATION
        );
      case "w":
        return (
          (c = rz(e.getFullYear(), e.getMonth(), e.getDate(), a.A.Ye, a.A.Xe)),
          Uz(
            a,
            Un(
              Math.floor(
                Math.round(
                  (c - new Date(new Date(c).getFullYear(), 0, 1).valueOf()) /
                    864e5
                ) / 7
              ) + 1,
              g
            )
          )
        );
      case "z":
        return (
          (a = f || Gz(c.getTimezoneOffset())),
          g < 4 ? a.D[Iz(a, c) > 0 ? 2 : 0] : a.D[Iz(a, c) > 0 ? 3 : 1]
        );
      case "Z":
        return (
          (b = f || Gz(c.getTimezoneOffset())),
          g < 4
            ? ((g = -Jz(b, c)),
              (a = [g < 0 ? "-" : "+"]),
              (g = Math.abs(g)),
              a.push(Un(Math.floor(g / 60) % 100, 2), Un(g % 60, 2)),
              (g = a.join("")))
            : (g = Uz(a, Hz(Jz(b, c)))),
          g
        );
      default:
        return "";
    }
  }
  var Zz = {
      Ni: "y",
      Oi: "y G",
      Sh: "MMM y",
      Th: "MMMM y",
      Pi: "MM/y",
      Bi: "MMM d",
      Ci: "MMMM dd",
      Ei: "M/d",
      Di: "MMMM d",
      Gi: "MMM d, y",
      Ki: "EEE, MMM d",
      Ji: "EEEE, MMMM d",
      Li: "EEE, MMM d, y",
      Ai: "d",
      Fi: "MMM d, h:mm\u202fa zzzz",
    },
    $z = Zz;
  $z = Zz;
  function aA(a) {
    return bA(a) || cA(a);
  }
  function dA(a) {
    return eA(a) && cA(a) && !bA(a);
  }
  function cA(a) {
    var b = a.Y();
    if (!z(b, 13)) return !1;
    a = a.Y();
    a = B(a, tl, 13);
    return Rf(a, 1) && E(a, 1) !== "";
  }
  function bA(a) {
    var b = zl(a.Y());
    if (Sf(b, 2)) return ml(b) === 2;
    a = fA(a);
    return a === 1 || a === 2 || a === 4 || a === 13 || a === 11 || a === 5;
  }
  function eA(a) {
    var b = zl(a.Y());
    if (Sf(b, 2)) return ml(b) === 3;
    a = fA(a);
    return a === 3 || a === 10 || a === 15 || a === 12 || a === 7 || a === 27;
  }
  function gA(a) {
    a = zl(a.Y());
    return Sf(a, 2) ? ml(a) === 4 : !1;
  }
  function hA(a) {
    a = El(a.Y());
    a = B(a, ek, 6);
    for (let b = 0; b < hf(a, 4, Ld, 3, !0).length; b++)
      if (Hf(a, 4, b) === 9) return !0;
    return !1;
  }
  function iA(a, b) {
    var c = !1;
    if (z(a, 1)) {
      var d = B(a, Nj, 1),
        e = Lj(d);
      if ((e = Pf(e, 3))) (e = Lj(d)), (e = Pf(e, 4));
      e &&
        ((c = Ej(Lj(d))),
        (e = Gj(Lj(d))),
        $i(ij(b), c),
        Yi(ij(b), e),
        (c = !0));
      z(d, 3) &&
        ((d = Mj(d)),
        (c = kj(b)),
        Pf(d, 1) && c.nb(d.Ba()),
        Pf(d, 2) && c.ab(d.za()),
        Pf(d, 3) && c.wc(d.Va()),
        (c = !0));
    }
    Pf(a, 3) && (P(b, 4, a.Ga()), (c = !0));
    z(a, 2) && ((a = B(a, Bj, 2)), nj(b).B(a.S()).A(a.R()), (c = !0));
    return c;
  }
  var jA = new Kz($z.Sh);
  new Kz($z.Th);
  function kA(a) {
    var b = El(a);
    return z(b, 8)
      ? ((a = El(a)),
        (a = B(a, Wj, 8)),
        (b = B(a, sj, 9).wa())
          ? b
          : jA.format(
              new Ez(
                Ef(a, 1),
                Od(Ze(a, 2)) != null ? (Od(Ze(a, 2)) ?? 0) - 1 : void 0,
                Od(Ze(a, 3)),
                Od(Ze(a, 4)),
                Od(Ze(a, 5))
              )
            ))
      : "";
  }
  function lA(a, b) {
    return z(a, 22) && z(b, 22)
      ? ((a = a.Y()),
        (b = b.Y()),
        a.jb() &&
          b.jb() &&
          a.ha().Oa() === b.ha().Oa() &&
          a.ha().va() === b.ha().va())
      : mA(a) && mA(b)
      ? a.va() === b.va()
      : !1;
  }
  function nA(a) {
    var b = "";
    a.Y().jb() ? (b = a.Y().ha().va()) : mA(a) && (b = a.va());
    if (typeof b !== "string") throw Error(`Invalid Photo Id type:${typeof b}`);
    return b;
  }
  function oA(a) {
    return a.Y().jb() ? a.Y().ha().Oa() : Sf(a, 2) ? pA(qA(a)) : 0;
  }
  function pA(a) {
    switch (a) {
      case 0:
        return 2;
      case 1:
        return 4;
      case 4:
        return 3;
      case 9:
        return 8;
      case 7:
        return 1;
      case 8:
        return 5;
      case 10:
        return 10;
      default:
        return 0;
    }
  }
  var rA = class {
    vc(a) {
      a: {
        if ((a = a.params)) if (((a = Mo(a)), a !== "")) break a;
        a = "";
      }
      return a;
    }
  };
  var sA = class {
    constructor() {
      this.params = {};
    }
  };
  function tA(a, b, c) {
    b = b.toString();
    a = a.C.vc(c);
    return b.indexOf("?") === -1 ? `${b}?${a}` : `${b}&${a}`;
  }
  var uA = class {
    constructor(a, b) {
      this.B = a;
      this.C = new rA();
      this.A = b.map((c) => new Qo(c));
    }
    Nb(a, b, c, d, e, f) {
      a = a.Ia();
      if (!a) return () => {};
      var g = Z(a),
        h = nA(g);
      if (!h) return () => {};
      a = new sA();
      a.params.panoid = h;
      a.params.output = "tile";
      a.params.x = `${b}`;
      a.params.y = `${c}`;
      a.params.zoom = `${d}`;
      a.params.nbt = "1";
      a.params.fover = "2";
      (d = Ik(Gl(g.Y()))) && (a.params.pt = d);
      b = this.A[(b + c) % this.A.length];
      e = f.U(e, "cts-get-tile");
      return this.B.ub(tA(this, b, a), e);
    }
    Qb() {}
  };
  var vA = class extends dz {
    constructor(a, b) {
      super("CTS", [...arguments]);
    }
  };
  function wA(a, b, c, d) {
    b = new uA(c, d);
    a(b);
  }
  var xA = Array(256),
    yA = Array(64);
  function Sx(a, b) {
    if (!(b < 0 || b > a.A - 1) && (a = zA(a, b, 1)) && a.length === 1)
      return a[0];
  }
  function zA(a, b, c) {
    var d = Array(c),
      e = 0;
    b += Math.floor(b / 3);
    var f = b - (b % 4);
    c = Math.ceil((c * 4) / 3);
    var g = a.B.length;
    for (g - b < c && (c = g - b); f < b + c; f += 4) {
      var h = e;
      g = f >= b;
      h += g ? 1 : 0;
      let k = f + 1 >= b && h < d.length;
      h += k ? 1 : 0;
      h = f + 2 >= b && h < d.length;
      let l = 0;
      if (g && ((l = yA[a.B.charCodeAt(f + 0)]), l === void 0)) return null;
      let m = 0;
      if (g || k)
        if (((m = yA[a.B.charCodeAt(f + 1)]), m === void 0)) return null;
      let n = 0;
      if (k || h)
        if (((n = yA[a.B.charCodeAt(f + 2)]), n === void 0)) return null;
      let q = 0;
      if (h && ((q = yA[a.B.charCodeAt(f + 3)]), q === void 0)) return null;
      g && l !== 64 && m !== 64 && (d[e++] = (l << 2) | (m >> 4));
      k && m !== 64 && n !== 64 && (d[e++] = ((m << 4) & 240) | (n >> 2));
      h && n !== 64 && q !== 64 && (d[e++] = ((n << 6) & 192) | q);
    }
    d.length = e;
    return d;
  }
  function AA(a, b) {
    if (!(b < 0 || b > a.A - 2 || !(a = zA(a, b, 2)) || a.length < 2))
      return a[0] + (a[1] << 8);
  }
  function BA(a, b, c) {
    if (!a.A) return [];
    var d = c * 4;
    if (b < 0 || b + d > a.A) return [];
    c = Array(c);
    a = zA(a, b, d);
    if (!a) return [];
    for (let e = 0; e < c.length; e++)
      (b = a),
        (d = e * 4),
        (c[e] =
          ((b[d + 3] & 127) | b[d + 2] | b[d + 1] | b[d]) === 0
            ? 0
            : (1 - ((b[d + 3] & 128) >> 6)) *
              (((b[d + 2] | 128) << 16) | (b[d + 1] << 8) | b[d]) *
              xA[((b[d + 3] & 127) << 1) | ((b[d + 2] & 128) >> 7)]);
    return c;
  }
  var CA = class {
    constructor(a) {
      this.B = a;
      this.A = Math.ceil((a.length * 3) / 4);
      if (xA[0] === void 0) {
        for (a = 0; a < xA.length; a++) xA[a] = Math.pow(2, a - 150);
        for (a = 0; a < 65; a++)
          yA[
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.".charCodeAt(
              a
            )
          ] = a;
      }
    }
  };
  var DA = class {};
  var EA = class extends S {
    constructor(a) {
      super(a);
    }
    Vc() {
      return E(this, 2);
    }
    wa() {
      return E(this, 4);
    }
    Dd() {
      return Rf(this, 4);
    }
  };
  function FA(a, b) {
    Q(a, 1, b);
  }
  function GA(a, b) {
    return Q(a, 2, b);
  }
  var HA = class extends S {
    constructor(a) {
      super(a);
    }
    ub() {
      return E(this, 3);
    }
  };
  function IA(a) {
    return A(a, HA, 2);
  }
  var JA = class extends S {
    constructor(a) {
      super(a);
    }
    wa() {
      return E(this, 1);
    }
    Dd() {
      return Rf(this, 1);
    }
  };
  var KA = class extends S {
    constructor(a) {
      super(a);
    }
    A() {
      return E(this, 1);
    }
  };
  function LA(a) {
    return Ff(a, 9);
  }
  var MA = class extends S {
    constructor(a) {
      super(a);
    }
    A() {
      return E(this, 1);
    }
  };
  function NA(a) {
    return B(a, MA, 1);
  }
  var OA = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var PA = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function fA(a) {
    return Ff(a, 3, 1);
  }
  function qA(a) {
    return Ff(a, 2, 99);
  }
  function mA(a) {
    return Rf(a, 1);
  }
  function QA(a) {
    return A(a, Hl, 22);
  }
  function RA(a, b) {
    return R(a, 2, b);
  }
  function SA(a, b) {
    Af(a, 18, ce, b, void 0, ee);
  }
  function TA(a, b) {
    Q(a, 21, b);
  }
  var UA = class extends S {
    constructor(a) {
      super(a);
    }
    Ab() {
      return yf(this, Hl, 22);
    }
    Y() {
      return B(this, Hl, 22);
    }
    Kd(a) {
      zf(this, Hl, 22, a);
    }
    va() {
      return E(this, 1);
    }
    Ed() {
      return Sf(this, 3);
    }
    Hc() {
      return ff(this, 19, JA);
    }
    B() {
      return yf(this, KA, 7);
    }
    Xa() {
      return yf(this, U, 9);
    }
    oa() {
      return B(this, U, 9);
    }
    ja() {
      return A(this, U, 9);
    }
    setCamera(a) {
      return zf(this, U, 9, a);
    }
    A() {
      return yf(this, PA, 30);
    }
  };
  var VA = class extends S {
    constructor(a) {
      super(a);
    }
    wa() {
      return E(this, 4);
    }
    Dd() {
      return Rf(this, 4);
    }
  };
  var WA = class extends S {
    constructor(a) {
      super(a);
    }
    Vc() {
      return E(this, 1);
    }
    jc() {
      return yf(this, gj, 4);
    }
    Xa() {
      return yf(this, U, 9);
    }
    oa() {
      return B(this, U, 9);
    }
    ja() {
      return A(this, U, 9);
    }
    setCamera(a) {
      return zf(this, U, 9, a);
    }
    wa() {
      return E(this, 14);
    }
    Dd() {
      return Rf(this, 14);
    }
  };
  var hB = class {
      constructor() {
        this.N = !1;
        this.A = null;
        this.K = new U();
        this.M = Ct();
        this.O = Ct();
        this.V = this.C = this.F = this.B = this.L = 0;
        this.tileSize = new gj();
        this.D = new gj();
        this.H = new gj();
        this.G = new gj();
        this.I = new gj();
      }
      initialize(a, b) {
        this.A = b;
        this.K = a.oa();
        XA(this.K, this.M);
        Kt(this.M, this.O);
        b = this.tileSize;
        var c = B(a, gj, 4);
        y(b, c);
        b = this.D;
        c = mj(a.oa());
        y(b, c);
        this.F = this.D.S() / this.tileSize.S();
        this.C = this.D.R() / this.tileSize.R();
        this.L = Math.ceil(this.F);
        this.B = Math.ceil(this.C);
        this.V = Od(Ze(a, 6)) ?? 0;
        b = this.I;
        c = B(a, gj, 27);
        y(b, c);
        b = this.H;
        c = B(a, gj, 28);
        y(b, c);
        b = this.G;
        a = B(a, gj, 29);
        y(b, a);
        this.N = !0;
      }
      Yc() {
        return this.N;
      }
      jc() {
        return this.tileSize;
      }
      J() {
        return this.D;
      }
      ob() {
        return this.V;
      }
      Uc() {
        return this.F;
      }
      Gc() {
        return this.C;
      }
      qf(a) {
        return 1 << (this.ob() - a);
      }
      Lg(a, b, c, d) {
        var e = this.qf(c);
        c = Math.min(a + e, this.L);
        e = Math.min(b + e, this.B);
        var f = [],
          g = YA(this.yb(a)),
          h = YA(this.yb(c)),
          k = ZA(this.zb(b)),
          l = ZA(this.zb(e)),
          m = Math.cos(k) * (h - g),
          n = Math.cos(l) * (h - g);
        d = Bo(d ? 8 : 4);
        var q = 1;
        this.B === 1 && (q = Math.max(1, Math.ceil((h - g) / d)));
        f[0] = Math.max(1, Math.ceil((k - l) / d));
        f[1] = Math.max(q, Math.ceil(m / d));
        f[2] = Math.max(q, Math.ceil(n / d));
        f[0] = $A(f[0], e - b);
        f[1] = $A(f[1], c - a);
        f[2] = $A(f[2], c - a);
        b === 0 && (f[1] = f[2]);
        return f;
      }
      Hg() {
        return 0;
      }
      zd(a, b) {
        if (b) {
          var c = new U();
          y(c, this.K);
          iz(b, c);
          XA(c, a);
        } else Dt(a, this.M);
      }
      Jg(a) {
        Dt(a, this.O);
      }
      Tc(a, b) {
        var c = this.A;
        a *= this.A.S();
        b *= this.A.R();
        b = Ox(c.B, a, b);
        c = Qx(c, b);
        c === 0 && (c = 500);
        return c;
      }
      yb(a) {
        var b = this.I.S(),
          c = this.H.S(),
          d = this.G.S(),
          e = 1,
          f = 0;
        b && c && ((e = c / b), d && (f = d / b));
        return f + Math.min(a / this.Uc(), 1) * e;
      }
      zb(a) {
        var b = this.I.R(),
          c = this.H.R(),
          d = this.G.R(),
          e = 1,
          f = 0;
        b && c && ((e = c / b), d && (f = d / b));
        return f + Math.min(a / this.Gc(), 1) * e;
      }
      Lb(a, b, c, d) {
        var e = this.Tc(a, b);
        a = YA(a);
        b = ZA(b);
        c[d + 0] = Math.sin(a) * Math.cos(b) * e;
        c[d + 1] = Math.cos(a) * Math.cos(b) * e;
        c[d + 2] = Math.sin(b) * e;
      }
      qg(a, b, c, d, e, f) {
        d = this.zb(b);
        var g = this.zb(b + 1);
        f
          ? (e = (g - d) * Math.PI)
          : ((f = this.yb(a)),
            (a = this.yb(a + 1)),
            (a = (f + a) / 2),
            this.Lb(a, d, aB, 0),
            this.Lb(a, g, bB, 0),
            (d = bB),
            Lt(e, aB, cB),
            Lt(e, d, dB),
            (cB[0] -= c.Pa),
            (cB[1] -= c.Qa),
            (cB[2] -= c.Ra),
            (dB[0] -= c.Pa),
            (dB[1] -= c.Qa),
            (dB[2] -= c.Ra),
            (e = Math.acos(
              (cB[0] * dB[0] + cB[1] * dB[1] + cB[2] * dB[2]) /
                (wt(cB) * wt(dB))
            )));
        d = c.Kb;
        e = Math.abs(d) > 1e-6 ? (e * c.R()) / d : 0;
        c = this.ob();
        d = this.C - (this.B - 1);
        d < 1 && b === this.B - 1 && (e /= d);
        b = this.jc();
        b = Math.floor(Math.log(b.R() / e) / Math.LN2);
        b = xo(b, 0, c);
        return Math.max(2, c - b);
      }
      be(a, b, c) {
        Mt(b, a.dir, aB);
        xt(aB, aB);
        c.x = Math.atan2(aB[0], aB[1]) / (2 * Math.PI) + 0.5;
        c.y = Math.acos(aB[2]) / Math.PI;
      }
      Mg(a, b, c, d) {
        this.zd(eB, b, c);
        Kt(eB, fB);
        this.be(a, fB, gB);
        a = Tx(this.A, gB.x, gB.y, d);
        if (!a) return null;
        Lt(eB, a.origin, a.origin);
        Mt(eB, a.dir, a.dir);
        xt(a.dir, a.dir);
        return a;
      }
      jh() {
        return 1;
      }
    },
    aB = Y(),
    bB = Y(),
    cB = Y(),
    dB = Y(),
    eB = Ct(),
    fB = Ct(),
    gB = new As();
  function $A(a, b) {
    return Math.ceil(a / b) * b;
  }
  function YA(a) {
    return Math.PI * (2 * a - 1);
  }
  function ZA(a) {
    return Math.PI * (0.5 - a);
  }
  function XA(a, b) {
    var c = new Fv();
    mu(a, c);
    var d = c.Pa,
      e = c.Qa;
    c = c.Ra;
    b[0] = 1;
    b[1] = 0;
    b[2] = 0;
    b[3] = 0;
    b[4] = 0;
    b[5] = 1;
    b[6] = 0;
    b[7] = 0;
    b[8] = 0;
    b[9] = 0;
    b[10] = 1;
    b[11] = 0;
    b[12] = d;
    b[13] = e;
    b[14] = c;
    b[15] = 1;
    d = cu(Zi(hj(a)));
    Ut(b, d, d, d);
    a = jj(a);
    Xt(b, Bo(-a.Ba()));
    Vt(b, Bo(a.za() - 90));
    Wt(b, Bo(a.Va()));
  }
  var jB = class extends hB {
      Lb(a, b, c, d) {
        var e = this.J().S() / this.J().R();
        c[d + 0] = (a - 0.5) * e * 50;
        c[d + 1] = iB * 50;
        c[d + 2] = (0.5 - b) * 50;
      }
    },
    iB = 0.5 / Math.tan(Bo(20));
  function kB(a, b, c) {
    return (a = a.D[b]) ? ((c = ij(c)), y(c, a), !0) : !1;
  }
  var lB = class {
    constructor() {
      this.height = this.width = 0;
      this.A = null;
      this.F = 0;
      this.C = [];
      this.B = {};
      this.D = {};
    }
    initialize(a, b, c, d, e, f, g) {
      this.width = a;
      this.height = b;
      this.A = c;
      this.F = d;
      this.C = e;
      this.D = f;
      this.B = g;
    }
    S() {
      return this.width;
    }
    R() {
      return this.height;
    }
    Vc(a, b) {
      return !this.A || a < 0 || b < 0 || a >= this.width || b >= this.height
        ? ""
        : this.C[Sx(this.A, this.F + (b * this.width + a))] || "";
    }
  };
  function mB(a, b) {
    if (b)
      (b = b.measureText(a)),
        (b = {
          width: b.width,
          we: b.actualBoundingBoxAscent + 6,
          mg: b.actualBoundingBoxDescent + 6,
        });
    else {
      var c = c || "Arial";
      var d = d || 80;
      b = document.createElement("dummyContainer");
      u.document.body.appendChild(b);
      let f = document.createElement("dummyText");
      f.style.fontFamily = c;
      f.style.position = "absolute";
      f.style.top = "-20000px";
      f.style.left = "-20000px";
      f.style.padding = "0";
      f.style.margin = "0";
      f.style.border = "0";
      f.style.whiteSpace = "pre";
      f.style.fontSize = `${d}px`;
      f.appendChild(document.createTextNode(a));
      b.appendChild(f);
      d = Ds(f);
      c = new As(0, 0);
      if (f != (d ? Ds(d) : document).documentElement) {
        a = Xs(f);
        var e = Bs(d).A;
        d = e.scrollingElement
          ? e.scrollingElement
          : Nb || e.compatMode != "CSS1Compat"
          ? e.body || e.documentElement
          : e.documentElement;
        e = e.defaultView;
        d = new As(
          e?.pageXOffset || d.scrollLeft,
          e?.pageYOffset || d.scrollTop
        );
        c.x = a.left + d.x;
        c.y = a.top + d.y;
      }
      a = c;
      c = $s(f);
      a = new Ts(a.x, a.y, c.width, c.height);
      b.removeChild(f);
      u.document.body.removeChild(b);
      b = { width: a.width, we: 0, mg: a.height };
    }
    return b;
  }
  function et(a) {
    a.A || (a.createTexture(), a.draw());
    return a.A;
  }
  function nB(a) {
    a &&
      ((a.fillStyle = "rgba(255, 255, 255, 0.7)"),
      (a.font = "bold 80px Arial"),
      (a.textBaseline = "top"),
      (a.strokeStyle = "rgba(0, 0, 0, 0.15)"),
      (a.lineWidth = 2),
      (a.shadowOffsetX = -1.5),
      (a.shadowOffsetY = -1.5),
      (a.shadowBlur = 4),
      (a.shadowColor = "rgba(0, 0, 0, 0.5)"));
  }
  var qB = class {
    constructor(a) {
      this.text = a;
      this.G = !1;
      this.B = 0;
      this.A = null;
      this.D = this.C = 1;
      this.F = [a];
    }
    createTexture() {
      !this.text ||
        this.text.length < 1 ||
        (this.A = document.createElement("canvas"));
    }
    draw() {
      var a = this.A;
      if (a) {
        var b = a.getContext ? a.getContext("2d") : null;
        nB(b);
        var c = oB(this.text, b);
        this.F = c;
        var d = 0,
          e = c.map((k) => mB(k, b)),
          f = e.map((k) => Math.max(k.we + k.mg, 100)),
          g = f.reduce((k, l) => k + l, 0);
        if ((g & (g - 1)) !== 0) {
          var h = pB(g);
          this.C = g / h;
          g = h;
        }
        a.height = g;
        nB(b);
        g = e[0];
        this.B = d = Math.max(d, g.width);
        (d & (d - 1)) !== 0 && ((h = pB(d)), (this.D = d / h), (d = h));
        a.width = d;
        nB(b);
        b &&
          ((a = g.we),
          b.strokeText(c[0], 0, a),
          b.fillText(c[0], 0, a),
          c[1] &&
            ((this.G = !0),
            (a = f[0] + e[1].we),
            b.strokeText(c[1], 0, a),
            b.fillText(c[1], 0, a)));
      }
    }
    drawText(a) {
      this.text = a;
      this.A || this.createTexture();
      this.draw();
    }
  };
  function pB(a) {
    for (var b = 1; b < a; ) b <<= 1;
    return b;
  }
  function oB(a, b) {
    var c = a.split("\n");
    if (c.length > 1) b = c;
    else {
      c = [];
      let d = "",
        e = a;
      if (mB(a, b).width > 1024) {
        a = a.split(" ");
        let f = 0,
          g = 1;
        for (let h = 0; h < a.length && f < g; h++)
          (d = `${d}${a[h]} `),
            (e = e.substring(a[h].length + 1)),
            (f = mB(d, b).width),
            (g = mB(e, b).width);
      }
      d && c.push(d);
      e && c.push(e);
      b = c;
    }
    return b;
  }
  var tB = class extends Su {
      constructor(a, b, c, d) {
        super();
        this.C = a;
        this.heading = d;
        this.uid = String(sa(this));
        this.A = new qB(c);
        this.vertices = new Float32Array(12);
        et(this.A);
        c = this.A.G ? 2 : 1;
        d = (c * 2) / 1.25 / 80;
        var e = 1.25 * c;
        a = this.vertices;
        a[0] = c;
        a[1] = 7.5;
        a[2] = -3;
        a[3] = -c;
        a[4] = 7.5;
        a[5] = -3;
        a[6] = e;
        a[7] = this.A.B * d + 7.5;
        a[8] = -3;
        a[9] = -e;
        a[10] = this.A.B * d + 7.5;
        a[11] = -3;
        gv(rB, -Bo(b));
        for (d = 0; d < 4; d++) {
          sB[0] = a[3 * d + 0];
          sB[1] = a[3 * d + 1];
          sB[2] = a[3 * d + 2];
          b = rB;
          var f = sB;
          c = sB;
          e = f[0];
          let g = f[1];
          f = f[2];
          c[0] = e * b[0] + g * b[4] + f * b[8];
          c[1] = e * b[1] + g * b[5] + f * b[9];
          c[2] = e * b[2] + g * b[6] + f * b[10];
          a[3 * d + 0] = sB[0];
          a[3 * d + 1] = sB[1];
          a[3 * d + 2] = sB[2];
        }
      }
      Mb() {
        return 2;
      }
      Ia() {
        return null;
      }
      Xa() {
        return null;
      }
      id() {
        return this.uid;
      }
      oc() {}
      Pb(a) {
        a(3);
      }
      xa() {
        return this.C;
      }
      Ba() {
        return this.heading;
      }
    },
    sB = new Float32Array(3),
    rB = av();
  var uB = class extends ru {
    constructor(a, b, c, d) {
      super("TileReady", a);
      this.x = b;
      this.y = c;
      this.zoom = d;
    }
  };
  function vB(a, b) {
    N(a, 15, b);
  }
  var wB = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var xB = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var yB = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var AB = class extends S {
      constructor(a) {
        super(a);
      }
      A() {
        return If(this, 1, zB);
      }
    },
    zB = [1, 2];
  var BB = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var CB = class extends S {
    constructor(a) {
      super(a);
    }
    va() {
      return yf(this, AB, 1);
    }
    getData() {
      return yf(this, BB, 2);
    }
    setData(a) {
      return zf(this, BB, 2, a);
    }
  };
  function Z(a) {
    return B(a, UA, 5);
  }
  function DB(a, b) {
    return R(a, 1, b);
  }
  function EB(a) {
    return A(a, UA, 5);
  }
  function FB(a, b) {
    R(a, 8, b);
  }
  function GB(a) {
    return A(a, CB, 9);
  }
  var HB = class extends S {
    constructor(a) {
      super(a);
    }
    A() {
      return Ff(this, 1);
    }
    Ed() {
      return Sf(this, 1);
    }
  };
  function IB(a, b) {
    if (b !== a.F && (b === 0 || a.F !== 4) && ((a.F = b), mx(a) || nx(a))) {
      b = a.G;
      a.G = [];
      for (let c = 0; c < b.length; ++c) (0, b[c])(a.F);
    }
  }
  function JB(a) {
    if (a.ga) {
      var b = yf(a.content, UA, 5);
      b = b?.B()?.A() || b?.Y().A()[0]?.A() || "";
      mn(b) && ((b = new vp(b)), so(b, ""), (a.W = b.ld()));
    }
  }
  function KB(a, b, c, d) {
    b = hw({ x: b, y: c, zoom: d });
    a.A[b] && delete a.A[b];
  }
  var LB = class extends Su {
    constructor(a, b = !1) {
      super();
      this.aa = a;
      this.ga = b;
      this.F = 0;
      this.tiles = {};
      this.A = {};
      this.uid = String(sa(this));
      this.L = this.I = !1;
      this.content = new HB();
      this.O = null;
      this.G = [];
      this.W = "";
    }
    Mb() {
      return this.F;
    }
    Pb(a) {
      mx(this) || nx(this) ? a(this.F) : this.G.push(a);
    }
    oc(a) {
      this.tc(0, 0, this.xa().Hg(), a, "pfdd");
      this.Hd(a, "pfdd");
    }
    Ia() {
      return this.content;
    }
    Xa() {
      return null;
    }
    Rb() {}
    Jb(a) {
      var b = EB(this.content);
      y(b, a);
      JB(this);
    }
    id() {
      return this.uid;
    }
    Yd(a) {
      return !!this.tiles[a];
    }
    Nb(a, b, c) {
      return this.tiles[hw({ x: a, y: b, zoom: c })] || null;
    }
    ye(a, b) {
      var c = a.toString();
      this.tiles[c] = a;
      this.A[c] && delete this.A[c];
      this.Mb() === 1 && IB(this, 2);
      hx(this, "TileReady", b, new uB(this, a.getX(), a.getY(), a.zoom));
    }
    xe(a, b) {
      var c = a.toString();
      this.tiles[c] = a;
      this.A[c] && delete this.A[c];
      c = this.Mb();
      c === 1 ? (IB(this, 2), IB(this, 3)) : c === 2 && IB(this, 3);
      hx(this, "TileReady", b, new uB(this, a.getX(), a.getY(), a.zoom));
    }
    Hd(a, b) {
      this.I || this.Mb() !== 0 || ((this.I = !0), this.aa.Hd(this, a, b));
    }
    Pd() {
      this.L = !0;
      for (let a of Object.values(this.A)) a();
      IB(this, 0);
      for (this.I = !1; this.G.length; ) this.G.shift()(0);
      this.L = !1;
      this.A = {};
    }
    je() {
      IB(this, 4);
    }
    tc(a, b, c, d, e) {
      var f = hw({ x: a, y: b, zoom: c });
      this.tiles[f] ||
        this.A[f] ||
        (this.A[f] = this.aa.tc(this, a, b, c, d, e));
    }
    kd(a, b, c) {
      KB(this, a, b, c);
    }
    oe(a, b, c) {
      KB(this, a, b, c);
    }
    Af() {
      return Object.keys(this.A).length > 0;
    }
    Cf() {
      return this.L;
    }
    B() {
      super.B();
      this.tiles = {};
      this.Af() && this.Pd();
    }
    Kd(a) {
      this.O = a;
      var b = QA(EB(this.content)),
        c = zl(b);
      xh(b, a);
      if ((a = z(c, 9))) (a = zl(b)), (a = !z(a, 9));
      a && ((b = Al(b)), (b = A(b, fl, 9)), (c = B(c, fl, 9)), y(b, c));
      JB(this);
    }
    Ab() {
      return this.O;
    }
    hc() {
      return [];
    }
    He() {
      return this.W;
    }
  };
  function MB(a) {
    mx(a) ||
      nx(a) ||
      (a.config &&
        a.C &&
        a.D.Yc() &&
        (a.Yd(hw({ x: 0, y: 0, zoom: 0 })) ? IB(a, 2) : IB(a, 1)));
  }
  var QB = class extends LB {
      constructor(a, b, c) {
        super(a, c);
        this.C = this.config = null;
        this.P = new U();
        this.ea = new lB();
        this.H = null;
        this.Z = !1;
        this.T = [];
        this.Jb(b);
        this.D = dA(b) ? new jB() : new hB();
      }
      Xa() {
        return this.P;
      }
      Za() {
        return this.config;
      }
      Ud(a, b) {
        var c = xo(a.y, 0, 1),
          d = Math.round(xo(a.x, 0, 1) * (this.Yb().S() - 1));
        c = Math.round(c * (this.Yb().R() - 1));
        d = this.Yb().Vc(d, c);
        if (!d) return null;
        bf(b, 9);
        Q(b, 1, d);
        if (!kB(this.Yb(), d, b.ja())) return null;
        c = NB;
        (a = Tx(this.Sd(), a.x, a.y, OB))
          ? (this.xa().zd(PB), Lt(PB, a.origin, c), (a = c))
          : (a = null);
        a && rx(b.ja(), a);
        a = this.Yb().B[d];
        switch (a) {
          case 3:
            RA(b, 4);
            break;
          case 8:
            RA(b, 9);
            break;
          case 10:
            RA(b, 10);
            break;
          default:
            RA(b, 0);
        }
        c = 1;
        Z(this.Ia()).Ed() && (c = fA(Z(this.Ia())));
        R(b, 3, c);
        var e = QA(b);
        c = Al(e);
        e = yl(e);
        R(c, 2, 2);
        Q(c, 10, d);
        R(c, 1, a);
        Pi(e, d);
        Oi(e, a);
        return b;
      }
      Pb(a) {
        super.Pb(a);
      }
      Yb() {
        return this.ea;
      }
      Sd() {
        return this.C;
      }
      xa() {
        this.D.Yc() || this.Rb();
        return this.D;
      }
      Rb() {
        if (this.config && this.C) {
          this.D.initialize(this.config, this.C);
          let a = this.T;
          this.T = [];
          for (let b of a) b();
        }
        MB(this);
      }
      hc() {
        if (!this.config) return [];
        if (!this.H) {
          this.H = [];
          let d = df(this.config, VA, 20);
          for (let e = 0; e < d; e++) {
            var a = ff(this.config, 20, VA, e);
            let f = D(a, 1) - D(this.config, 11);
            a: {
              var b = a.wa();
              var c = b.split("/");
              if (c.length === 1) c = b;
              else {
                for (b = 0; b < c.length; ++b) {
                  let g = Ra(c[b]);
                  if (g === this.config.wa()) {
                    c = g;
                    break a;
                  }
                }
                c = Ra(c[0]);
              }
            }
            c && ((a = new tB(this.D, f, c, D(a, 1))), this.H.push(a));
          }
        }
        return this.H;
      }
      Qb(a, b) {
        this.config = a;
        var c = new UA(),
          d = Z(this.Ia());
        y(c, d);
        this.D = dA(c) ? new jB() : new hB();
        d = !1;
        a.Vc() &&
          c.va() !== a.Vc() &&
          ((d = a.Vc()), Q(c, 1, d), Pi(yl(QA(c)), a.Vc()), (d = !0));
        a.Dd() && C(a, 30) && Q(c, 4, a.wa());
        this.Jb(c);
        d
          ? (IB(this, 0), MB(this), this.oe(0, 0, 0), this.tc(0, 0, 0, b))
          : this.Z && IB(this, 4);
        var e;
        Dl(c.Y()) > 0 && (e = Cl(c.Y(), 0));
        if ((b = e)) (b = $k(e)), (b = z(b, 3));
        b &&
          ((e = Mj($k(e))),
          Pf(e, 1) && kj(a.ja()).nb(e.Ba()),
          Pf(e, 2) && kj(a.ja()).ab(e.za()),
          Pf(e, 3) && kj(a.ja()).wc(e.Va()));
        e = this.P;
        b = a.oa();
        y(e, b);
        c = zl(c.Y());
        e = B(c, el, 5);
        z(e, 1) &&
          ((b = B(e, Bj, 1)), A(a, gj, 27).B(b.S()), A(a, gj, 27).A(b.R()));
        z(e, 2) &&
          ((e = B(e, Bj, 2)), A(a, gj, 29).B(e.S()), A(a, gj, 29).A(e.R()));
        z(c, 3) && ((c = nl(c)), A(a, gj, 28).B(c.S()), A(a, gj, 28).A(c.R()));
        C(a, 2) ? IB(this, 4) : this.Rb();
      }
      kd(a, b, c) {
        super.kd(a, b, c);
        a === 0 &&
          b === 0 &&
          c === 0 &&
          (this.config ? IB(this, 4) : (this.Z = !0));
      }
      Ab() {
        return super.Ab();
      }
    },
    OB = new xv(),
    PB = Ct(),
    NB = Y();
  var RB = class extends DA {
    constructor(a) {
      super();
      this.ma = { iterator: this, Fb: 1, Db: 2, priority: 1 };
      this.pano = null;
      this.offset = this.I = this.F = this.H = 0;
      this.B = null;
      this.C = 0;
      this.D = [
        () => {
          if (this.pano)
            if (Sx(this.A, 0) !== 8 || Sx(this.A, 7) !== 8) {
              var b = this.pano;
              b.C = Xx;
              b.Rb();
              this.C = Infinity;
            } else {
              this.I = AA(this.A, 1) || 0;
              this.H = AA(this.A, 3) || 0;
              this.F = AA(this.A, 5) || 0;
              this.offset = b = Sx(this.A, 7) || 0;
              b += this.H * this.F;
              this.B = BA(this.A, b, this.I * 4);
              b = this.B.length;
              for (let c = 0; c < b; ++c) this.B[c] *= -1;
            }
          else this.C = Infinity;
        },
        () => {
          var b = this.pano,
            c = new Vx(this.H, this.F, this.B || void 0, this.A, this.offset);
          b.C = c;
          b.Rb();
        },
      ];
      this.A = new CA(a);
    }
    G(a) {
      this.pano = a;
    }
    next() {
      if (this.C < this.D.length) this.D[this.C++]();
      return { done: this.C >= this.D.length, value: void 0 };
    }
  };
  var SB = class {
    constructor() {
      this.config = null;
      this.B = [];
      this.A = null;
    }
  };
  var TB = null,
    UB = !1;
  function VB(a) {
    return TB ? TB.Vg(a) != null : !1;
  }
  var WB = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var XB = class extends S {
    constructor(a) {
      super(a);
    }
    Xa() {
      return yf(this, U, 1);
    }
    oa() {
      return B(this, U, 1);
    }
    ja() {
      return A(this, U, 1);
    }
    setCamera(a) {
      return zf(this, U, 1, a);
    }
  };
  var YB = class extends S {
    constructor(a) {
      super(a);
    }
    Hc() {
      return B(this, WB, 3);
    }
    jc() {
      return yf(this, gj, 9);
    }
  };
  var ZB = class extends S {
    constructor(a) {
      super(a);
    }
    Hc() {
      return B(this, WB, 2);
    }
  };
  function $B(a) {
    return a === 10 || a === 8 || a === 3;
  }
  function aC(a, b = !1) {
    var c = new WA(),
      d = null,
      e = null,
      f = null,
      g = Bl(a);
    z(g, 6)
      ? ((g = Xj(Bl(a)).wa()), Q(c, 14, g))
      : ((g = Yj(Bl(a)).wa()), Q(c, 14, g));
    for (g = 0; g < Dl(a); ++g) {
      var h = Cl(a, g);
      z(h, 2) &&
        ((f = f || h),
        sk(B(h, tk, 1)) === 2 && (d = h),
        sk(B(h, tk, 1)) === 1 && (e = h));
    }
    f == null && Dl(a) > 0 && (f = Cl(a, 0));
    g = El(a);
    g = hf(g, 4, Ld).includes(1);
    M(c, 30, g);
    e &&
      (bC(e, c, g, b),
      (h = $k(e)),
      $i(A(c, dj, 10), Ej(Lj(h))),
      Yi(A(c, dj, 10), Gj(Lj(h))));
    d && bC(d, c, g, b);
    d || e || !f || bC(f, c, g, b);
    if (z(a, 5)) {
      d = a.Hc();
      b = [];
      for (e = 0; e < df(d, xj, 1); ++e)
        (f = ff(d, 1, xj, e)), b.push(vj(f).wa());
      for (e = 0; e < df(d, xj, 2); ++e)
        (f = ff(d, 2, xj, e)), b.push(vj(f).wa());
      for (e = 0; e < df(d, xj, 3); ++e)
        (f = ff(d, 3, xj, e)), b.push(vj(f).wa());
      df(d, xj, 5) > 0 && ((d = ff(d, 5, xj, 0)), Rf(d, 2) && Q(c, 15, wj(d)));
      b = b.join(" ");
      Q(c, 12, b);
    }
    a.jb() && ((b = a.ha().va()), Q(c, 1, b));
    z(a, 3) &&
      ((b = zl(a)),
      A(c, gj, 4).B(jl(pl(b)).S()),
      A(c, gj, 4).A(jl(pl(b)).R()),
      (d = il(pl(b)) - 1),
      (d = Mf(c, 5, d)),
      (e = il(pl(b)) - 1),
      Mf(d, 6, e),
      z(b, 3) && (nj(c.ja()).B(nl(b).S()), nj(c.ja()).A(nl(b).R())));
    if ((B(c, gj, 4).S() === 0 || B(c, gj, 4).R() === 0) && $B(a.ha().Oa())) {
      A(c, gj, 4).B(512);
      A(c, gj, 4).A(512);
      b = mj(c.oa());
      b = Math.max(b.S(), b.R());
      d = 0;
      for (e = 512; e < b; ) (e <<= 1), d++;
      b = d;
      d = Mf(c, 5, b);
      Mf(d, 6, b);
    }
    a = B(a, vl, 8);
    a = Ff(a, 2, 1);
    M(c, 2, a !== 1);
    return c;
  }
  function cC(a, b) {
    var c = zl(b).Oa();
    c === 4 && R(a, 1, 1);
    $B(c) && R(a, 1, 2);
    z(b, 5) &&
      ((c = b.Hc()),
      df(c, xj, 2) > 0 && ((c = vj(ff(c, 2, xj, 0)).wa()), Q(a, 4, c)));
    c = Bl(b);
    z(c, 6)
      ? ((c = Xj(Bl(b)).wa()), Q(a, 5, c))
      : ((c = Yj(Bl(b)).wa()), Q(a, 5, c));
    b = b.ha().va();
    Q(a, 2, b);
  }
  function dC(a) {
    switch (a) {
      case 1:
        return 7;
      case 2:
        return 0;
      case 3:
        return 4;
      case 8:
        return 9;
      case 10:
        return 10;
      case 4:
        return 1;
      default:
        return 0;
    }
  }
  function bC(a, b, c, d = !1) {
    var e = b.ja(),
      f = $k(a),
      g = new Oj(),
      h = A(g, Nj, 1);
    y(h, f);
    iA(g, e);
    g = jj(e);
    Pf(g, 2) || kj(e).ab(90);
    c = c ? 1.5 : 3;
    cj(hj(e)) || bj(ij(e), c);
    Cj(B(f, Dj, 2))
      ? d
        ? (bj(ij(e), Cj(B(f, Dj, 2))), P(b, 24, c))
        : ((d = Cj(B(f, Dj, 2))), P(b, 24, d))
      : P(b, 24, 3);
    d = Mj(f);
    Pf(d, 1) && ((d = Mj(f).Ba()), P(b, 11, d));
    z(f, 4) &&
      ((d = String), (e = B(f, Jj, 4)), (e = Cf(e, 1) ?? Ve), Q(b, 3, d(e)));
    for (d = 0; d < df(a, Zk, 13); ++d) {
      e = ff(a, 13, Zk, d);
      if (!df(e, Yk, 1)) continue;
      g = ff(e, 1, Yk, 0);
      g = B(g, sj, 3).wa();
      for (h = 0; h < hf(e, 2, Fd, 3, !0).length; ++h) {
        var k = Bf(b, 20, VA);
        RA(A(k, UA, 5), 0);
        var l = A(k, UA, 5);
        R(l, 3, 1);
        l = Q(k, 4, g);
        k = h;
        var m = hf(e, 2, Fd, 3, !0);
        ad(m, k);
        P(l, 1, m[k]);
      }
    }
    for (d = 0; d < df(a, Qk, 7); ++d) {
      e = ff(a, 7, Qk, d);
      if (Df(e, 1) == null) continue;
      e = Ef(e, 1);
      e = Vk(B(a, Wk, 4), e);
      if (!z(e, 3)) continue;
      l = Bf(b, 20, VA);
      g = Ej(Lj(Tk(e)));
      h = Gj(Lj(Tk(e)));
      m = Ej(Lj(f));
      k = Gj(Lj(f));
      m = Bo(m);
      let n = Bo(g);
      k = Bo(h) - Bo(k);
      k > Math.PI ? (k -= 2 * Math.PI) : k < -Math.PI && (k += 2 * Math.PI);
      rt(eu, 0, 0, 1);
      rt(fu, Math.cos(m), 0, Math.sin(m));
      rt(gu, Math.cos(k) * Math.cos(n), Math.sin(k) * Math.cos(n), Math.sin(n));
      yt(gu, fu, hu);
      P(
        l,
        1,
        (360 +
          Co(
            Math.atan2(
              Math.sign(k) * Math.sqrt(hu[0] * hu[0] + hu[2] * hu[2]),
              hu[1]
            )
          )) %
          360
      );
      l = RA(A(l, UA, 5), dC(e.ha().Oa()));
      l = R(l, 3, 1);
      k = e.ha().va();
      l = Q(l, 1, k);
      k = yl(QA(l));
      m = e.ha();
      y(k, m);
      bj(Yi($i(ij(l.ja()), g), h), c);
      g = Tk(e);
      z(g, 3) &&
        kj(l.ja())
          .nb(Mj(Tk(e)).Ba())
          .ab(Mj(Tk(e)).za())
          .wc(Mj(Tk(e)).Va());
    }
    for (f = 0; f < df(a, Xk, 8); ++f) {
      c = ff(a, 8, Xk, f);
      c = Ef(c, 1);
      (d = c < 0) || ((d = B(a, Wk, 4)), (d = df(d, Uk, 1)), (d = c >= d));
      if (d) continue;
      e = Vk(B(a, Wk, 4), c);
      c = Tk(e);
      c = B(c, Jj, 4);
      d = Bf(b, 21, EA);
      e = e.ha().va();
      d = Q(d, 2, e);
      e = String(Cf(c, 1) ?? Ve);
      d = Q(d, 1, e);
      g = Mf(d, 3, D(c, 2));
      z(c, 4) && ((d = g), (e = B(c, sj, 4).wa()), Q(d, 5, e));
      z(c, 3) && ((d = g), (c = B(c, sj, 3).wa()), Q(d, 4, c));
    }
  }
  var eC = class {
    constructor(a, b = !1) {
      this.Lc = a;
      this.A = b;
    }
    Za(a, b) {
      a = new SB();
      a.A = TB.Vg(this.Lc);
      if (a.A) {
        a.config = aC(a.A, this.A);
        var c = new RB("");
        a.B.push(c);
        b(a);
      } else b(null);
    }
  };
  var fC = class extends dz {
    constructor(a, b) {
      super("CUCS", [...arguments]);
    }
  };
  function gC(a, b, c, d) {
    a(new eC(c, d));
  }
  function hC() {
    var a = iC || (iC = new jC());
    return C(a, 15);
  }
  var jC = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var iC;
  function kC(a, b = {}) {
    new lC(a, b);
  }
  function mC(a) {
    a.A.onload = null;
    a.A.onerror = null;
  }
  var lC = class {
    constructor(
      a,
      {
        crossOrigin: b,
        decoding: c = "async",
        li: d,
        onError: e,
        wj: f,
        mi: g = () => {},
        image: h = new Image(),
      }
    ) {
      this.C = this.loaded = !1;
      this.B = null;
      this.onError = e;
      f = f || e;
      this.A = h;
      this.A.decoding = c;
      b != null && nC(a) && (this.A.crossOrigin = b);
      var k;
      d &&
        (k = () => {
          this.A && d(this.A);
        });
      this.A.onload = () => {
        this.loaded = !0;
        var m = this.A;
        m && (mC(this), g(m), this.B && oC(m) && this.B());
        this.C && l();
      };
      var l = () => {
        this.C = !0;
        this.A && f && this.loaded && f(this.A);
      };
      this.A.onerror = () => {
        this.A &&
          (mC(this),
          this.onError && (this.onError(this.A), (this.onError = void 0)));
      };
      this.A.src = a.toString();
      k &&
        ((a = new Promise((m) => {
          this.B = m;
        })),
        this.A.decode && (a = Promise.race([a, this.A.decode()])),
        a.then(k, l));
    }
    cancel() {
      this.A && (mC(this), this.A.removeAttribute("src"), (this.A = null));
    }
  };
  function nC(a) {
    a = Fn(a).match(Ho);
    var b = a[1] === "data",
      c = a[3] === "maps.gstatic.com" && (a[5] || "").startsWith("/tactile/");
    return !!a[3] && !b && !c;
  }
  function oC(a) {
    return (
      !a.decode ||
      (Ly() &&
        !!navigator.userAgentData?.brands.some((b) => b.brand === "Chromium"))
    );
  }
  var pC = class {
    constructor(a) {
      this.A = a;
      this.state = null;
    }
    start(a) {
      this.A(a);
    }
    cancel() {
      return !1;
    }
  };
  var qC = class extends pC {
    constructor(a, b, c = {}) {
      super((d) => {
        kC(a, {
          crossOrigin: c.crossOrigin,
          li: b,
          onError: (e) => {
            d();
            c.onError && c.onError(e);
          },
          mi: () => {
            d();
          },
          image: c.image,
        });
      });
    }
  };
  var rC = class {
    constructor(a, b = hC() ? "use-credentials" : "") {
      this.A = a;
      this.crossOrigin = b === null ? void 0 : b;
    }
    ub(a, b) {
      var c = !1,
        d = (f) => {
          c || (b(f), (c = !0));
        };
      if (!a) return b(null), () => {};
      var e = new qC(Jn(a, In) || En, d, {
        crossOrigin: this.crossOrigin,
        onError: () => void d(),
      });
      this.A.Id(e, 3);
      return () => {
        d();
        this.A.remove(e);
      };
    }
  };
  var sC = class {
    constructor(a, b, c) {
      this.Lc = b;
      this.A = new rC(a, c ? "" : null);
    }
    Nb(a, b, c, d, e, f) {
      a = TB.yi(this.Lc, d, b, c);
      return a ? this.A.ub(a, f.U(e, "custom-pano-tile")) : (e(null), () => {});
    }
    Qb() {}
  };
  var tC = class extends dz {
    constructor(a, b, c) {
      super("CUTS", [...arguments]);
    }
  };
  function uC(a, b, c, d, e) {
    b = new sC(c, d, e);
    a(b);
  }
  var vC = class extends dz {
    constructor(a, b, c, d, e) {
      super("FPSC", [...arguments]);
    }
  };
  var wC = class extends dz {
    constructor(a, b, c) {
      super("FPCS", [...arguments]);
    }
  };
  var xC = class extends dz {
    constructor(a, b, c) {
      super("FPTS", [...arguments]);
    }
  };
  class yC {
    constructor() {
      this.promise = new Promise((a, b) => {
        this.resolve = a;
        this.reject = b;
      });
    }
  }
  function zC(a, b) {
    Ty([a.A, a.C], () => {}, b);
  }
  function AC(a, b, c, d) {
    if (d && d.config) {
      var e = Z(b.Ia()).Y();
      if (BC(e, d)) b.Kd(d.A), b.je();
      else {
        d.A && b.Kd(d.A);
        var f = d.config;
        a.A.get((g, h) => {
          g.Qb(f, h);
        }, c);
        b.Qb(f, c);
        for (c = 0; c < d.B.length; c++) (e = d.B[c]), e.G(b), zy(a.D, e.ma);
      }
    } else b.je();
  }
  var CC = class {
    constructor(a, b, c) {
      this.C = a;
      this.A = b;
      this.D = c;
      this.B = new yC();
    }
    Hd(a, b, c) {
      var d = !!a.He();
      d && this.B.resolve();
      zC(this, b);
      this.C.get((e, f) => {
        e.Za(
          a,
          (g) => {
            c && f.Fa(c);
            AC(this, a, f, g);
            d || this.B.resolve();
          },
          f
        );
      }, b);
    }
    tc(a, b, c, d, e, f) {
      var g = null,
        h = !1;
      zC(this, e);
      this.A.get((k, l) => {
        l.gb("wait-for-gpms");
        this.B.promise.then(() => {
          h ||
            (g = k.Nb(
              a,
              b,
              c,
              d,
              (m, n) => {
                f && l.Fa(f);
                (m = m || void 0)
                  ? n
                    ? a.ye(new iw(b, c, d, m), l)
                    : a.xe(new iw(b, c, d, m), l)
                  : a.Cf()
                  ? a.oe(b, c, d)
                  : a.kd(b, c, d);
              },
              l
            ));
          l.done("wait-for-gpms");
        });
      }, e);
      return () => {
        h = !0;
        g && g();
      };
    }
  };
  function BC(a, b) {
    if (!a.jb() || !b.A || !b.A.jb() || Kk(xl(b.A)) !== 1) return !1;
    b = b.A;
    if (vh(a.ha(), b.ha())) return !1;
    a = zl(a).Oa();
    b = zl(b).Oa();
    return !(a === 9 && b === 2);
  }
  var FC = class {
    constructor(a, b, c) {
      this.C = a;
      this.D = b;
      this.A = c;
      this.B = new kt(5);
    }
    Wd(a) {
      mA(a) || a.Y().ha();
      var b = nA(a),
        c = oA(a);
      if (mn(B(a, KA, 7).A())) {
        b = B(a, KA, 7).A();
        c = DC(b);
        var d = EC(b);
      } else
        mn(b)
          ? ((c = DC(b)), (d = EC(b)))
          : (c !== 10
              ? ((c = this.A[0] + b), (d = "p"))
              : ((c =
                  b.startsWith("AF1Qip") || b.startsWith("AL5jU4")
                    ? `${this.A[0]}p`
                    : `${this.A[0]}gps-csg`),
                (d = b)),
            (b = `${c}/${d}`));
      var e = this.B.getData(b);
      e ||
        ((e = d),
        (d = new xC(this.C, c, e)),
        (c = this.G || new wC(this.C, c, e)),
        (e = new CC(c, d, this.D)),
        this.B.setData(b, e));
      a = new QB(e, a, this.F);
      a.C = Wx;
      a.Rb();
      return a;
    }
    clear() {
      this.B.clear();
    }
  };
  function DC(a) {
    var b = a.lastIndexOf("/");
    return a.substring(0, b);
  }
  function EC(a) {
    var b = a.lastIndexOf("/");
    return a.substring(b + 1);
  }
  var GC = class extends FC {
    constructor(a, b, c, d, e) {
      super(a, b, c);
      this.G = d;
      this.F = e;
    }
  };
  function HC(a, b, c, d, e, f, g) {
    a(new GC(c, d, e, f, g));
  }
  var JC = class {
    constructor() {
      this.config = null;
      this.D = !1;
      this.A = {};
      this.B = {};
    }
    Nb(a, b, c, d, e, f) {
      var g = `x${b}-y${c}-z${d}`;
      return this.D
        ? IC(this, a, b, c, d, e, f)
        : ((this.A[g] = (h) => IC(this, a, b, c, d, e, h)),
          () => {
            g in this.A
              ? delete this.A[g]
              : g in this.B && (this.B[g](), delete this.B[g]);
          });
    }
    Qb(a, b) {
      this.D = !0;
      this.config = a;
      for (let c of Object.keys(this.A)) (a = this.A[c](b)), (this.B[c] = a);
      this.A = {};
    }
    Za() {
      return this.config;
    }
  };
  var KC = class {};
  var MC = class {
    constructor(a, b) {
      this.A = a;
      this.B = b;
    }
    send(a, b, c, d = new xs()) {
      a = new LC(a, b, c || null, d, this.A, this.B);
      this.A.Id(a, d.priority);
    }
  };
  class LC {
    constructor(a, b, c, d, e, f) {
      this.payload = a;
      this.G = b;
      this.H = c;
      this.uc = d;
      this.B = e;
      this.F = f;
      this.C = !1;
      this.A = null;
      this.D = !1;
      this.state = null;
      this.uc.C(() => {
        this.C = !0;
        return this.B.remove(this);
      });
      vs(this.uc, () => {
        this.B.Id(this, this.uc.priority);
      });
    }
    start(a) {
      this.A = this.uc.clone();
      this.A.start(`${this.uc.methodName}.RequestSchedulerChannel`);
      this.A.A(1);
      this.F.send(
        this.payload,
        (b) => {
          this.D = !0;
          this.G(b);
          ++this.uc.B;
        },
        () => {
          this.done(this.H, a);
        },
        this.A
      );
    }
    cancel() {
      return !this.A || (this.D && !this.C) ? !1 : this.A.cancel();
    }
    done(a, b) {
      this.A.done();
      this.uc.A(this.A.status);
      a && a();
      b();
    }
  }
  function NC(a, b) {
    if (b.length === 0) return a.A.slice(0, a.A.length - 1);
    if (b[0] === "?" || b[0] === "&") b = b.slice(1);
    return a.A + b;
  }
  var OC = class {
    constructor(a) {
      this.A = a + (a.indexOf("?") === -1 ? "?" : "&");
    }
  };
  function PC() {
    Su.call(this);
    this.headers = new Map();
    this.C = !1;
    this.A = null;
    this.O = "";
    this.D = this.L = this.G = this.I = !1;
    this.F = null;
    this.H = "";
    this.P = !1;
  }
  Ea(PC, Su);
  var QC = /^https?$/i,
    RC = ["POST", "PUT"];
  p = PC.prototype;
  p.send = function (a, b, c, d) {
    if (this.A)
      throw Error(
        "[goog.net.XhrIo] Object is active with another request=" +
          this.O +
          "; newUri=" +
          a
      );
    if (typeof b === "string") var e = b;
    else b && ((e = b.method), c ?? (c = b.body), d ?? (d = b.headers));
    e = e ? e.toUpperCase() : "GET";
    this.O = a;
    this.I = !1;
    this.C = !0;
    this.A = new XMLHttpRequest();
    this.A.onreadystatechange = Jp(() => this.T());
    try {
      (this.L = !0), this.A.open(e, String(a), !0), (this.L = !1);
    } catch (g) {
      SC(this);
      return;
    }
    a = c || "";
    b = new Map(this.headers);
    if (d)
      if (Object.getPrototypeOf(d) === Object.prototype)
        for (var f in d) b.set(f, d[f]);
      else if (typeof d.keys === "function" && typeof d.get === "function")
        for (let g of d.keys()) b.set(g, d.get(g));
      else throw Error("Unknown input type for opt_headers: " + String(d));
    d = Array.from(b.keys()).find((g) => "content-type" == g.toLowerCase());
    f = u.FormData && a instanceof u.FormData;
    !(qb(RC, e) >= 0) ||
      d ||
      f ||
      b.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
    for (let [g, h] of b) this.A.setRequestHeader(g, h);
    this.H && (this.A.responseType = this.H);
    "withCredentials" in this.A &&
      this.A.withCredentials !== this.P &&
      (this.A.withCredentials = this.P);
    try {
      this.F && (clearTimeout(this.F), (this.F = null)),
        (this.G = !0),
        this.A.send(a),
        (this.G = !1);
    } catch (g) {
      SC(this);
    }
  };
  p.pe = function () {
    typeof fa != "undefined" &&
      this.A &&
      (this.dispatchEvent("timeout"), this.abort(8));
  };
  function SC(a) {
    a.C = !1;
    a.A && ((a.D = !0), a.A.abort(), (a.D = !1));
    TC(a);
    UC(a);
  }
  function TC(a) {
    a.I || ((a.I = !0), a.dispatchEvent("complete"), a.dispatchEvent("error"));
  }
  p.abort = function () {
    this.A &&
      this.C &&
      ((this.C = !1),
      (this.D = !0),
      this.A.abort(),
      (this.D = !1),
      this.dispatchEvent("complete"),
      this.dispatchEvent("abort"),
      UC(this));
  };
  p.B = function () {
    this.A &&
      (this.C && ((this.C = !1), (this.D = !0), this.A.abort(), (this.D = !1)),
      UC(this, !0));
    PC.qa.B.call(this);
  };
  p.T = function () {
    this.M() || (this.L || this.G || this.D ? VC(this) : this.W());
  };
  p.W = function () {
    VC(this);
  };
  function VC(a) {
    if (a.C && typeof fa != "undefined")
      if (a.G && (a.A ? a.A.readyState : 0) == 4) setTimeout(a.T.bind(a), 0);
      else if (
        (a.dispatchEvent("readystatechange"), (a.A ? a.A.readyState : 0) == 4)
      ) {
        a.C = !1;
        try {
          WC(a)
            ? (a.dispatchEvent("complete"), a.dispatchEvent("success"))
            : TC(a);
        } finally {
          UC(a);
        }
      }
  }
  function UC(a, b) {
    if (a.A) {
      a.F && (clearTimeout(a.F), (a.F = null));
      let c = a.A;
      a.A = null;
      b || a.dispatchEvent("ready");
      try {
        c.onreadystatechange = null;
      } catch (d) {}
    }
  }
  p.isActive = function () {
    return !!this.A;
  };
  function WC(a) {
    try {
      var b = (a.A ? a.A.readyState : 0) > 2 ? a.A.status : -1;
    } catch (d) {
      b = -1;
    }
    a: switch (b) {
      case 200:
      case 201:
      case 202:
      case 204:
      case 206:
      case 304:
      case 1223:
        var c = !0;
        break a;
      default:
        c = !1;
    }
    if (!c) {
      if ((b = b === 0))
        (a = String(a.O).match(Ho)[1] || null),
          !a &&
            u.self &&
            u.self.location &&
            (a = u.self.location.protocol.slice(0, -1)),
          (b = !QC.test(a ? a.toLowerCase() : ""));
      c = b;
    }
    return c;
  }
  function XC(a) {
    try {
      if (!a.A) return null;
      if ("response" in a.A) return a.A.response;
      switch (a.H) {
        case "":
        case "text":
          return a.A.responseText;
        case "arraybuffer":
          if ("mozResponseArrayBuffer" in a.A)
            return a.A.mozResponseArrayBuffer;
      }
      return null;
    } catch (b) {
      return null;
    }
  }
  function YC(a, b, c, d) {
    var e = (f) => {
      Pu(c);
      d.status !== 3 && f && b();
    };
    Fu(c, "success", () => {
      e(!0);
    });
    Fu(c, "abort", () => {
      e(!1);
    });
    Fu(c, "error", () => {
      d.A(2);
      e(!0);
    });
    Fu(c, "timeout", () => {
      d.A(2);
      e(!0);
    });
    Fu(c, "readystatechange", () => {
      var f = XC(c);
      WC(c) && (c.A ? c.A.readyState : 0) === 4 && a(f);
    });
  }
  var ZC = class {
    constructor(a) {
      this.A = void 0;
      this.B = typeof a === "string" ? new OC(a) : a;
    }
    send(a, b, c, d = new xs()) {
      c = c || (() => {});
      var e = new PC();
      e.P = !1;
      this.A !== void 0 && (e.H = this.A);
      d.C(() => {
        e.abort();
        return !0;
      });
      YC(b, c, e, d);
      b = Object.fromEntries(ws(d));
      a = NC(this.B, a);
      try {
        e.send(a, void 0, void 0, b);
      } catch (f) {
        if (
          f instanceof Error &&
          f.message.includes("The string did not match the expected pattern")
        ) {
          let g = "The string did not match the expected pattern`";
          ws(d).forEach((h, k) => {
            g += `\n${k}: ${h}`;
          });
          throw Error(g, { cause: f });
        }
        throw f;
      }
    }
  };
  var $C = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var aD = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var bD = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var cD = class extends S {
    constructor(a) {
      super(a);
    }
    S() {
      return Ef(this, 17);
    }
    B(a) {
      return N(this, 17, a);
    }
    R() {
      return Ef(this, 18);
    }
    A(a) {
      return N(this, 18, a);
    }
  };
  var dD = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var eD = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var fD = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function gD(a) {
    return (
      ((a[0] === "0" || a[0] === "2") && a.length > 25) ||
      (a[0] === "1" && !!a.match(/.*p:[^,]+(,.+)*/))
    );
  }
  var hD = class {
    constructor(a, b) {
      this.K = a;
      this.L = b;
    }
    tb() {
      return this.K;
    }
    C() {
      return this.L;
    }
    equals(a) {
      return this.tb() === a.tb() && this.C() === a.C();
    }
  };
  var iD = { bb: 9747 },
    jD = { bb: 11562 },
    kD = { bb: 46458 };
  var lD = class {
    constructor(a, b, c, d, e = (g) => g, f = null) {
      this.C = a;
      this.D = b;
      this.F = c;
      this.methodName = d;
      this.B = e;
      this.A = f;
    }
    send(a, b, c) {
      var d = this.D.vc(a),
        e = c || new xs();
      e.start(this.methodName);
      var f = (k) => {
          try {
            if (e.status !== 3 && (++e.B, e.B === 1)) {
              let l = null;
              try {
                l = this.F.A(k);
              } catch (m) {
                e.A(2), (l = null);
              }
              b(l);
            }
          } catch (l) {
            throw (this.B(l), l);
          }
        },
        g = () => {
          try {
            e.status !== 3 && (e.B === 0 && (e.A(2), b(null)), e.done());
          } catch (k) {
            throw (this.B(k), k);
          }
        },
        h = () => {
          this.C.send(d, f, g, e);
        };
      this.A
        ? this.A.bj({ zj: d }, (k) => {
            for (let { key: l, value: m } of k)
              e.headers || (e.headers = new Map()),
                e.headers.set(l.toLowerCase(), m);
            h();
          })
        : h();
    }
  };
  function IC(a, b, c, d, e, f, g) {
    b = b.He();
    var h = a.Za();
    Nm(WA);
    if (h && (Od(Ze(h, 5)) ?? 0) !== 0) {
      b = new vp(b ? b : `${a.C.toString()}/${a.filename}`);
      var k = b.D;
      let l = k.A;
      h = K(l, 9);
      K(k.B, 9);
      c != h && N(l, 9, c);
      h = b.D;
      k = h.A;
      c = K(k, 10);
      K(h.B, 10);
      d != c && N(k, 10, d);
      c = b.D;
      h = c.A;
      d = K(h, 11);
      K(c.B, 11);
      e != d && N(h, 11, e);
      e = b.ld();
    } else e = b ? `${b}=s2560-no` : `${a.C.toString()}/s2560-no/${a.filename}`;
    f = g.U(f, "fpts-get-tile");
    return a.F.ub(e, f);
  }
  var mD = class extends JC {
    constructor(a, b, c) {
      super();
      this.filename = c;
      this.F = new rC(a);
      this.C = new Qo(b);
    }
  };
  function nD(a, b, c, d, e) {
    b = new mD(c, d, e);
    a(b);
  }
  var oD = class extends dz {
    constructor(a, b, c, d, e, f, g, h) {
      super("GCS", [...arguments]);
    }
  };
  var sD = class extends DA {
      constructor(a) {
        super();
        this.ma = { iterator: this, Fb: 2, Db: 2, priority: 0 };
        this.pano = null;
        this.N = this.B = this.J = this.M = 0;
        this.C = [];
        this.F = [];
        this.D = 0;
        this.H = {};
        this.K = {};
        this.I = [
          () => {
            if (this.pano)
              if (Sx(this.A, 0) !== 8 || Sx(this.A, 7) !== 8) this.D = Infinity;
              else {
                this.B = (AA(this.A, 1) || 1) - 1;
                this.M = AA(this.A, 3) || 0;
                this.J = AA(this.A, 5) || 0;
                var b = Sx(this.A, 7) || 0;
                this.N = b;
                this.C = Array(this.B + 1);
                b += this.M * this.J;
                var c = this.B * 22;
                var d = this.A;
                d = !d.A || b < 0 ? [] : zA(d, b, c) || [];
                b += c;
                this.C[0] = "";
                for (c = 1; c <= this.B; c++) {
                  let e = "";
                  for (let f = 0; f < 22; f++)
                    e += String.fromCharCode(d[(c - 1) * 22 + f] || 0);
                  this.C[c] = e;
                }
                this.F = BA(this.A, b, this.B * 2);
              }
            else this.D = Infinity;
          },
          () => {
            if (this.F.length !== 2 * this.B) this.F.length = 0;
            else {
              var b = this.pano.Za(),
                c = hj(b.oa());
              c = cu(Zi(c));
              gv(pD, -Bo(D(b, 11)));
              for (var d = 0; d < this.B; d++) {
                var e = this.C[d + 1],
                  f = this.F[2 * d + 1],
                  g = qD;
                g[0] = this.F[2 * d];
                g[1] = f;
                g[2] = 0;
                f = pD;
                var h = qD;
                g = qD;
                var k = h[0],
                  l = h[1];
                h = h[2];
                g[0] = k * f[0] + l * f[4] + h * f[8] + f[12];
                g[1] = k * f[1] + l * f[5] + h * f[9] + f[13];
                g[2] = k * f[2] + l * f[6] + h * f[10] + f[14];
                mu(b.oa(), rD);
                f = zv(rD);
                f.A += qD[0] * c;
                f.B += qD[1] * c;
                nu(rD, f);
                f = new U();
                g = rD;
                if (g.vg !== 0) throw Error("Invalid Coordinate System");
                zv(g, ku);
                g = kj(f);
                k = nj(f);
                l = ij(f);
                ku.J !== void 0 && g.nb(Ao(-Co(ku.J)));
                ku.K !== void 0 && g.ab(Ao(Co(ku.K)));
                ku.D !== void 0 && g.wc(Ao(-Co(ku.D)));
                ku.C !== void 0 && P(f, 4, Co(ku.C));
                ku.width !== void 0 && k.B(ku.width);
                ku.height !== void 0 && k.A(ku.height);
                bu(ku.A, ku.B, ku.I, lu);
                lu[0] = Co(lu[0]);
                lu[1] = Co(lu[1]);
                bj($i(Yi(l, lu[0]), lu[1]), lu[2]);
                this.H[e] = hj(f);
                this.K[e] = 2;
              }
              for (c = 0; c < df(b, VA, 20); ++c)
                if (
                  ((d = gf(b, 20, VA, c)),
                  (d = A(d, UA, 5)),
                  (e = nA(d)),
                  (e = this.H[e]))
                )
                  (d = ij(d.ja())), y(d, e);
            }
          },
          () => {
            this.pano
              .Yb()
              .initialize(
                this.M,
                this.J,
                this.A,
                this.N,
                this.C,
                this.H,
                this.K
              );
          },
        ];
        this.A = new CA(a);
      }
      G(a) {
        this.pano = a;
      }
      next() {
        if (this.D < this.I.length) this.I[this.D++]();
        return { done: this.D >= this.I.length, value: void 0 };
      }
    },
    qD = new Float32Array(3),
    pD = av(),
    rD = new Fv();
  var tD = class extends DA {
    constructor(a, b, c, d) {
      super();
      this.width = a;
      this.height = b;
      this.ma = {
        U: () => {
          if (this.pano) {
            var e = this.pano,
              f = new Vx(this.width, this.height, this.A, this.B);
            e.C = f;
            e.Rb();
          }
        },
        Fb: 10,
        Db: 2,
        priority: 1,
      };
      this.pano = null;
      this.A = [];
      for (a = 0; a < df(c, Ok, 1); ++a) {
        b = a * 4;
        let e = Nk(ff(c, 1, Ok, a));
        this.A[b + 0] = -D(e, 1);
        this.A[b + 1] = -D(e, 2);
        this.A[b + 2] = -D(e, 3);
        this.A[b + 3] = -D(e, 4);
      }
      this.B = new CA(d);
    }
    G(a) {
      this.pano = a;
    }
  };
  var uD = class extends DA {
    constructor(a, b, c, d) {
      super();
      this.width = a;
      this.height = b;
      this.ma = {
        U: () => {
          this.pano &&
            this.pano
              .Yb()
              .initialize(
                this.width,
                this.height,
                this.C,
                0,
                this.Lc,
                this.B,
                this.A
              );
        },
        Fb: 11,
        Db: 2,
        priority: 0,
      };
      this.pano = null;
      this.Lc = [];
      this.A = {};
      this.B = {};
      this.C = new CA(d);
      for (a = 0; a < df(c, Uk, 1); ++a)
        (b = Vk(c, a).ha().va()),
          this.Lc.push(b),
          (this.A[b] = Vk(c, a).ha().Oa()),
          (d = Tk(Vk(c, a))),
          (d = bj(
            $i(Yi(new dj(), Gj(Lj(d))), Ej(Lj(d))),
            Cj(B(d, Dj, 2)) || 3
          )),
          (this.B[b] = d);
    }
    G(a) {
      this.pano = a;
    }
  };
  function vD(a) {
    return a
      .replace(/[+/]/g, (b) => (b === "+" ? "-" : "_"))
      .replace(/[.=]+$/, "");
  }
  function wD(a, b) {
    var c = b || {};
    b = c.document || document;
    var d = Bn(a).toString(),
      e = Rs(new Cs(b), "SCRIPT"),
      f = { dh: e, pe: void 0 },
      g = new pq(xD, f),
      h = null,
      k = c.timeout != null ? c.timeout : 5e3;
    k > 0 &&
      ((h = window.setTimeout(function () {
        yD(e, !0);
        g.D(new zD(1, "Timeout reached for loading script " + d));
      }, k)),
      (f.pe = h));
    e.onload = e.onreadystatechange = function () {
      (e.readyState &&
        e.readyState != "loaded" &&
        e.readyState != "complete") ||
        (yD(e, c.Vh || !1, h), g.U(null));
    };
    e.onerror = function () {
      yD(e, !0, h);
      g.D(new zD(0, "Error while loading script " + d));
    };
    f = c.attributes || {};
    Mm(f, { type: "text/javascript", charset: "UTF-8" });
    Fs(e, f);
    Pn(e, a);
    AD(b).appendChild(e);
    return g;
  }
  function AD(a) {
    var b = (a || document).getElementsByTagName("HEAD");
    return b && b.length !== 0 ? b[0] : a.documentElement;
  }
  function xD() {
    if (this && this.dh) {
      let a = this.dh;
      a && a.tagName == "SCRIPT" && yD(a, !0, this.pe);
    }
  }
  function yD(a, b, c) {
    c != null && u.clearTimeout(c);
    a.onload = () => {};
    a.onerror = () => {};
    a.onreadystatechange = () => {};
    b &&
      window.setTimeout(function () {
        Ms(a);
      }, 0);
  }
  function zD(a, b) {
    var c = "Jsloader error (code #" + a + ")";
    b && (c += ": " + b);
    Ga.call(this, c);
    this.code = a;
  }
  Ea(zD, Ga);
  function BD(a) {
    this.A = a;
    this.pe = 5e3;
  }
  var CD = 0;
  BD.prototype.send = function (a, b, c, d) {
    if (a) {
      var e = {};
      for (var f in a) e[f] = a[f];
      a = e;
    } else a = {};
    d = d || "_" + (CD++).toString(36) + Date.now().toString(36);
    e = "_callbacks___" + d;
    b && ((u[e] = DD(d, b)), (a.callback = e));
    b = { timeout: this.pe, Vh: !0 };
    f = this.A;
    e = new Map(Object.entries(a));
    f = Bn(f).toString();
    var g = f.split(/[?#]/),
      h = /[?]/.test(f) ? "?" + g[1] : "";
    e = Hp(g[0], h, /[#]/.test(f) ? "#" + (h ? g[2] : g[1]) : "", e);
    b = wD(e, b);
    wq(b, null, ED(d, a, c));
    return { wb: d, Bg: b };
  };
  BD.prototype.cancel = function (a) {
    a && (a.Bg && a.Bg.cancel(), a.wb && FD(a.wb, !1));
  };
  function ED(a, b, c) {
    return function () {
      FD(a, !1);
      c && c(b);
    };
  }
  function DD(a, b) {
    return function (c) {
      FD(a, !0);
      b.apply(void 0, arguments);
    };
  }
  function FD(a, b) {
    a = "_callbacks___" + a;
    if (u[a])
      if (b)
        try {
          delete u[a];
        } catch (c) {
          u[a] = void 0;
        }
      else u[a] = Wp;
  }
  function GD(a) {
    return An(a === null ? "null" : a === void 0 ? "undefined" : a);
  }
  function HD(a) {
    return new BD(a);
  }
  var ID = class {
    constructor(a) {
      this.A = typeof a === "string" ? new OC(a) : a;
    }
    send(a, b, c = () => {}, d = new xs()) {
      var e = HD(GD(NC(this.A, a))),
        f = !1,
        g = e.send(
          null,
          (h) => {
            d.A(1);
            b(h);
            c();
          },
          () => {
            f || (d.A(2), c());
          }
        );
      d.C(() => {
        f = !0;
        if (g === null) var h = !1;
        else e.cancel(g), (h = !0);
        return h;
      });
    }
  };
  var JD = class {
    constructor(a) {
      this.A = a;
    }
    vc(a) {
      var b = Fi(this.A);
      a = en(a);
      var c = Array(768);
      cn(a, b, 0, c, 0);
      b = c.join("");
      return "pb=" + encodeURIComponent(b).replace(/%20/g, "+");
    }
  };
  var KD = class extends KC {
    constructor(a) {
      super();
      this.B = a;
    }
    A(a) {
      return new this.B(a);
    }
  };
  var LD = class extends KC {
    constructor(a, b) {
      super();
      this.C = a;
      this.B = b;
    }
    A(a) {
      a.substring(0, 5) === ")]}'\n" && (a = a.substring(5));
      try {
        if (!a) throw Error("Empty string is not valid JSPB wire-format data.");
        return this.C(a);
      } catch (b) {
        throw (
          (this.B && this.B(),
          Error("XssiDeserializer parse error.", { cause: b }))
        );
      }
    }
  };
  function MD(a, b, c) {
    var d = Z(b),
      e = new Fk(),
      f = Bf(e, 3, pk);
    if (d.Y().jb()) wh(A(f, Qi, 1), d.Y().ha());
    else {
      Pi(A(f, Qi, 1), nA(d));
      var g = 0;
      switch (qA(Z(b))) {
        case 7:
          g = 1;
          break;
        case 0:
          g = 2;
          break;
        case 4:
          g = 3;
          break;
        case 9:
          g = 8;
          break;
        case 10:
          g = 10;
          break;
        case 1:
          g = 4;
          break;
        default:
          g = ND(fA(d));
      }
      Oi(A(f, Qi, 1), g);
    }
    OD(A(e, yk, 4));
    f = null;
    df(d, OA, 16) > 0 &&
      LA(NA(ff(d, 16, OA, 0))) === 0 &&
      ((f = NA(ff(d, 16, OA, 0)).A()), bk(ok(gf(e, 3, pk, 0)), f));
    wh(A(e, mk, 2), a.locale);
    a.A && wh(Dk(A(e, Ek, 1)), a.A);
    f = A(e, Ek, 1);
    Q(f, 1, a.B);
    (g = Gw()) && Nf(f, 3, g);
    (f = a.F?.()) && Q(e, 5, f);
    var h = new xs();
    h.priority = 3;
    h.F && h.F();
    a.G.send(
      e,
      (k) => {
        var l;
        if ((l = h.status === 1 && k && df(k, Hl, 2)))
          (l = B(k, Il, 1)), (l = Ef(l, 1) === 0);
        !l || (Kk(xl(ff(k, 2, Hl, 0))) !== 1 && Kk(xl(ff(k, 2, Hl, 0))) !== 3)
          ? a.D
            ? PD(a, b, c)
            : ((k = new SB()),
              (l = qA(Z(b))),
              (l !== 9 && l !== 10) ||
                !mA(Z(b)) ||
                ((k.config = new YB()), (k.A = new Hl())),
              c(k))
          : ((k = gf(k, 2, Hl, 0)), QD(k, c, h, d, a.C));
      },
      h
    );
  }
  function PD(a, b, c) {
    var d = Z(b),
      e = new Xl(),
      f = A(e, Ek, 1);
    Q(f, 1, a.B);
    var g = Gw();
    g && Nf(f, 3, g);
    (f = a.F?.()) && Q(e, 9, f);
    f =
      gn(() => {
        var k = d.va(),
          l = lk();
        {
          var m = new (Fi(l).messageType)();
          l = Fi(l);
          var n = k;
          k = en(m);
          let q = Sm,
            r = "!",
            t = n[0];
          if (t < "0" || t > "9")
            (n = n.substring(1)), t !== r && ((r = t), (q = Um(r)));
          n = n.split(r);
          m = fn(l, k, 0, n.length, n, q) ? m : void 0;
        }
        return m;
      }) || new jk();
    z(f, 1)
      ? wh(A(e, jk, 7), f)
      : ((f = A(e, Wl, 2)),
        (b = hj(Z(b).oa())),
        Fj(A(f, Ij, 1), Zi(b)),
        Hj(A(f, Ij, 1), Xi(b)),
        P(f, 2, 50),
        Pl(Ul(A(e, Vl, 3))));
    wh(Sl(A(e, Vl, 3)), a.locale);
    Ll(Nl(Rl(A(e, Vl, 3))));
    b = Tl(A(e, Vl, 3));
    f = Sj(b);
    R(f, 1, 2);
    M(f, 2, !0);
    R(f, 3, 2);
    f = Sj(b);
    R(f, 1, 3);
    M(f, 2, !0);
    R(f, 3, 2);
    a.A && wh(Dk(A(e, Ek, 1)), a.A);
    OD(A(e, yk, 4));
    var h = new xs();
    a.D.send(
      e,
      (k) => {
        k && z(k, 2) ? ((k = A(k, Hl, 2)), QD(k, c, h, d, a.C)) : c(new SB());
      },
      h
    );
  }
  function ND(a) {
    switch (a) {
      case 1:
      case 2:
      case 4:
      case 5:
      case 11:
      case 13:
      case 3:
        return 2;
      case 10:
        return 4;
      case 12:
      case 15:
        return 3;
      case 27:
        return 1;
      default:
        return 0;
    }
  }
  var SD = class {
    constructor(a, b, c, d, e, f, g, h = !1, k, l) {
      this.B = e;
      this.locale = f;
      this.A = g;
      this.C = h;
      this.F = k ? l : void 0;
      this.G = k
        ? new lD(
            new MC(d, k(a)),
            { vc: (m) => m.vc() },
            new LD(Kl, () => {}),
            "GpmsConfigService.getConfig"
          )
        : c
        ? new lD(
            new MC(d, new ID(a)),
            new JD(Hk()),
            new KD(Jl),
            "GpmsConfigService.getConfig"
          )
        : new lD(
            new MC(d, new ZC(a)),
            new JD(Hk()),
            new LD(Kl, () => {}),
            "GpmsConfigService.getConfig"
          );
      this.D = RD(d, b, c, k);
    }
    Za(a, b, c) {
      a = a.Ia();
      MD(this, a, c.U(b, "gcs-get-config"));
    }
  };
  function RD(a, b, c, d) {
    return b
      ? d
        ? new lD(
            new MC(a, d(b)),
            { vc: (e) => e.vc() },
            new LD(Dm, () => {}),
            "GpmsConfigService.getConfig"
          )
        : c
        ? new lD(
            new MC(a, new ID(b)),
            new JD(Am()),
            new KD(Cm),
            "GpmsConfigService.getConfig"
          )
        : new lD(
            new MC(a, new ZC(b)),
            new JD(Am()),
            new LD(Dm, () => {}),
            "GpmsConfigService.getConfig"
          )
      : null;
  }
  function OD(a) {
    Of(a, 1, 1);
    Of(a, 1, 2);
    Of(a, 1, 3);
    Of(a, 1, 4);
    Of(a, 1, 5);
    Of(a, 1, 6);
    Of(a, 1, 8);
    Of(a, 1, 12);
    var b = Bf(a, 2, tk);
    R(b, 1, 1);
    b = A(a, qk, 4);
    N(b, 1, 48);
    b = Bf(a, 6, uk);
    R(b, 1, 1);
    b = Bf(a, 6, uk);
    R(b, 1, 2);
    b = Bf(a, 5, rk);
    R(b, 1, 1);
    b = Bf(a, 5, rk);
    R(b, 1, 2);
    b = Sj(xk(a));
    R(b, 1, 2);
    M(b, 2, !0);
    R(b, 3, 2);
    b = Sj(xk(a));
    R(b, 1, 2);
    M(b, 2, !1);
    R(b, 3, 3);
    b = Sj(xk(a));
    R(b, 1, 3);
    M(b, 2, !0);
    R(b, 3, 2);
    b = Sj(xk(a));
    R(b, 1, 3);
    M(b, 2, !1);
    R(b, 3, 3);
    b = Sj(xk(a));
    R(b, 1, 8);
    M(b, 2, !1);
    R(b, 3, 3);
    b = Sj(xk(a));
    R(b, 1, 1);
    M(b, 2, !1);
    R(b, 3, 3);
    b = Sj(xk(a));
    R(b, 1, 4);
    M(b, 2, !1);
    R(b, 3, 3);
    b = Sj(xk(a));
    R(b, 1, 10);
    M(b, 2, !0);
    R(b, 3, 2);
    b = Sj(xk(a));
    R(b, 1, 10);
    M(b, 2, !1);
    R(b, 3, 3);
    Of(a, 1, 17);
    a = A(a, wk, 11);
    a = Bf(a, 3, vk);
    M(a, 4, !0);
  }
  function QD(a, b, c, d, e = !1) {
    var f = new SB();
    if (c.status === 1 && (Kk(xl(a)) === 1 || Kk(xl(a)) === 3))
      if (((f.A = a), aA(d))) {
        f.config = aC(a, e);
        c = f.B;
        d = c.push;
        a: {
          for (var g = 0; g < Dl(a); ++g) {
            e = Cl(a, g);
            if (!z(e, 6)) continue;
            var h = B(e, Sk, 6);
            if (z(h, 2)) {
              g = B(h, Rk, 2);
              let k = vD(uc(of(g)));
              h = B(h, rk, 1);
              e =
                Ff(h, 1) === 2
                  ? new RB(k)
                  : new tD(B(g, Bj, 1).S(), B(g, Bj, 1).R(), B(e, Pk, 5), k);
              break a;
            }
          }
          e = new RB("");
        }
        d.call(c, e);
        a: {
          for (e = 0; e < Dl(a); ++e) {
            c = Cl(a, e);
            if (!z(c, 6)) continue;
            d = B(c, Sk, 6);
            if (z(d, 4)) {
              a = B(d, Rk, 4);
              e = vD(uc(of(a)));
              d = B(d, uk, 3);
              a =
                Ff(d, 1) === 2
                  ? new sD(e)
                  : new uD(B(a, Bj, 1).S(), B(a, Bj, 1).R(), B(c, Wk, 4), e);
              break a;
            }
          }
          a = null;
        }
        a && f.B.push(a);
      } else if (gA(d))
        (c = new ZB()), (d = A(c, WB, 2)), cC(d, a), (f.config = c);
      else {
        c = new YB();
        d = null;
        for (
          e = 0;
          e < Dl(a) &&
          ((h = Cl(a, e)), !z(h, 2) || ((d = h), sk(B(d, tk, 1)) !== 2));
          ++e
        );
        d &&
          ((h = new Oj()),
          (e = A(h, Nj, 1)),
          (d = $k(d)),
          y(e, d),
          iA(h, A(c, XB, 2).ja()));
        d = zl(a);
        z(d, 3) &&
          ((d = nl(zl(a))),
          (e = A(c, XB, 2).ja()),
          nj(e).B(d.S()),
          nj(e).A(d.R()));
        d = A(c, WB, 3);
        cC(d, a);
        d = zl(a);
        z(d, 4) &&
          zl(a).Oa() !== 2 &&
          ((d = pl(zl(a))),
          (a = A(c, gj, 9)),
          z(d, 2)
            ? a.B(jl(d).S()).A(jl(d).R())
            : a.B(gl(ff(d, 1, hl, 0)).S()).A(gl(ff(d, 1, hl, 0)).R()),
          (a = c),
          (d = il(d) - 1),
          Mf(a, 10, d));
        f.config = c;
      }
    b(f);
  }
  function TD(a, b) {
    Yy("GCS", (c, d, e, f, g, h, k, l, m, n) => {
      d = new SD(e, f, g, h, k, l, m, n, a, b);
      c(d);
    });
  }
  var UD = class extends dz {
    constructor(a, b, c) {
      super("HPNR", [...arguments]);
    }
  };
  function VD(a, b) {
    a.A && (a.A.style.display = b ? "inline" : "none");
  }
  function WD(a) {
    a.A && ((a.A.style.left = `${a.left}px`), (a.A.style.top = `${a.top}px`));
  }
  function XD(a) {
    a.A &&
      ((a.A.style.width = `${a.width}px`),
      (a.A.style.height = `${a.height}px`));
  }
  function YD(a, b, c) {
    a.B = b;
    b = b.ub();
    a.A = c ? b.cloneNode(!0) : b;
    c = a.A;
    typeof c.className == "string"
      ? (c.className = "mapsImagerySceneScene__tileImage3d")
      : c.setAttribute &&
        c.setAttribute("class", "mapsImagerySceneScene__tileImage3d");
    a.C && ((a.C = !1), (a.D = Date.now()));
  }
  function ZD(a) {
    a.A.style.backgroundImage =
      "-webkit-linear-gradient(45deg,#efefef 25%,transparent 25%,transparent 75%,#efefef 75%,#efefef),-webkit-linear-gradient(45deg,#efefef 25%,transparent 25%,transparent 75%,#efefef 75%,#efefef)";
    a.A.style.backgroundColor = "#fff";
    a.A.style.backgroundPosition = "0 0 10px 10px";
    a.A.style.backgroundSize = "21px 21px";
  }
  function $D(a, b, c, d, e) {
    if (a.B && !e) {
      var f = b.Nb(a.x, a.y, a.zoom);
      f && a.B !== f && (a.remove(), YD(a, f, e));
    }
    a.B ||
      ((f = b.Nb(a.x, a.y, a.zoom))
        ? YD(a, f, e)
        : (b.tc(a.x, a.y, a.zoom, d), (a.C = !0)));
    a.A &&
      a.A.parentElement !== c &&
      (c.appendChild(a.A),
      (a.A.style.position = "absolute"),
      (a.A.style.pointerEvents = "none"),
      VD(a, a.visible),
      WD(a),
      XD(a),
      a.Ib &&
        (a.A.complete || a.A.readyState === "complete"
          ? ZD(a)
          : Gu(a.A, ["load", "readystatechange"], () => {
              ZD(a);
            })));
  }
  var aE = class {
    constructor(a, b, c) {
      this.x = a;
      this.y = b;
      this.zoom = c;
      this.visible = this.Ib = !1;
      this.F = -1;
      this.A = this.B = null;
      this.height = this.width = this.top = this.left = 0;
      this.C = !1;
      this.D = 0;
    }
    getX() {
      return this.x;
    }
    getY() {
      return this.y;
    }
    fd(a) {
      this.visible !== a && (VD(this, a), (this.visible = a));
    }
    setPosition(a, b) {
      if (a !== this.left || b !== this.top)
        (this.left = a), (this.top = b), WD(this);
    }
    setSize(a, b) {
      if (a !== this.width || b !== this.height)
        (this.width = a), (this.height = b), XD(this);
    }
    remove() {
      this.A &&
        this.A.parentElement &&
        this.A.parentElement.removeChild(this.A);
    }
  };
  function bE(a, b) {
    b !== a.opacity &&
      ((a.opacity = b),
      bt(a.div, b),
      b > 0 && a.div.parentElement !== a.container
        ? a.container.appendChild(a.div)
        : b === 0 && a.div.parentElement && a.container.removeChild(a.div));
  }
  var cE = class {
    constructor(a, b, c, d) {
      this.container = a;
      this.C = b;
      this.G = c;
      this.J = d;
      this.div = Js(document, "div");
      this.opacity = -1;
      this.tiles = {};
      this.F = [];
      this.D = 0;
      this.div.style.overflow = "hidden";
      this.div.style.position = "absolute";
      this.div.style.width = "inherit";
      this.div.style.height = "inherit";
      var e = d.xa();
      a = e.jc();
      d = a.S() * e.Uc();
      var f = a.R() * e.Gc();
      e = Math.pow(2, e.ob() - b);
      b = Math.pow(2, c - b);
      this.A = d / (e * a.S());
      this.B = f / (e * a.R());
      this.M = Math.ceil(this.A);
      this.I = Math.round(b * a.S());
      this.H = Math.round(b * a.R());
    }
  };
  function dE(a) {
    a.div ||
      ((a.div = Js(document, "div")),
      (a.div.style.overflow = "hidden"),
      (a.div.style.position = "absolute"),
      (a.div.style.width = "inherit"),
      (a.div.style.height = "inherit"));
    return a.div;
  }
  function eE(a, b) {
    var c = Math.round(4 * b),
      d = a.G[c];
    d ||
      ((d = c / 4),
      (b = Math.round(b)),
      (d = a.G[c] = new cE(dE(a), b, d, a.C)));
    return d;
  }
  var hE = class {
      constructor(a) {
        this.C = a;
        this.div = null;
        this.F = Wu();
        this.A = Wu();
        this.G = [];
        this.Rc = Infinity;
        this.B = null;
        this.D = -1;
      }
      update(a, b, c) {
        var d = dE(this);
        d.parentElement !== b && b.appendChild(d);
        var e = this.C.xa(),
          f = mj(a);
        d = f.S();
        var g = f.R(),
          h = jj(a).Ba();
        b = h;
        var k = this.C.Za();
        h = b - D(k, 11);
        k = xo(jj(a).za(), 0, 180);
        b = e.ob();
        a = (xo(a.Ga(), 0, 180) / 180) * e.jc().R() * e.Gc();
        a = b - Math.log(a / f.R()) / Math.LN2;
        b = Math.round(4 * xo(a, 0, b)) / 4;
        a = this.Rc;
        this.Rc = b;
        h = h / 360 + 0.5;
        var l = e.jc(),
          m = l.S() * e.Uc(),
          n = l.R() * e.Gc();
        l = f.S();
        f = f.R();
        var q = Math.pow(2, e.ob() - b);
        e = (q * l) / m;
        m = (q * f) / n;
        n = this.A;
        n[0] = e / l;
        n[1] = 0;
        n[2] = 0;
        n[3] = 0;
        n[4] = m / f;
        n[5] = 0;
        n[6] = 0;
        n[7] = 0;
        n[8] = 1;
        k = 1 - k / 180 - m / 2;
        this.A[6] = h - e / 2;
        this.A[7] = k;
        this.A[8] = 1;
        Xu(this.A, this.F);
        rt(fE, 0, 0, 1);
        rt(gE, d, g, 1);
        Yu(this.A, fE, fE);
        Yu(this.A, gE, gE);
        d = eE(this, b);
        f = fE;
        h = gE;
        ++d.D;
        g = f[1] * d.B;
        k = Math.min(d.B, h[1] * d.B);
        e = (f[0] - Math.floor(f[0])) * d.A;
        l = e + (h[0] - f[0]) * d.A;
        m = l + 1;
        f = !1;
        n = d.C !== d.G;
        h = d.F;
        d.F = [];
        for (q = Math.max(0, Math.floor(g)); q < k; ++q) {
          let v = (q - g) * d.H;
          for (let F = Math.floor(e); F < m; ++F) {
            var r = yo(F, d.M),
              t = F < d.A ? F : r + d.A;
            if (t > l) continue;
            t = (t - e) * d.I;
            let H = hw({ x: r, y: q, zoom: d.C }),
              I = d.tiles[H];
            I || ((I = new aE(r, q, d.C)), (d.tiles[H] = I));
            r = I;
            r.setPosition(t, v);
            r.setSize(d.I, d.H);
            r.fd(!0);
            $D(r, d.J, d.div, c, n);
            a: {
              if (!r.A) {
                t = !1;
                break a;
              }
              t = xo((Date.now() - r.D) / 250, 0, 1);
              bt(r.A, t);
              t = t < 1;
            }
            f = t || f;
            r.F = d.D;
            d.F.push(r);
          }
        }
        for (c = 0; c < h.length; ++c) (g = h[c]), g.F !== d.D && g.fd(!1);
        c = f;
        a !== Infinity &&
          b !== a &&
          ((b = eE(this, a)),
          this.B && this.B.G !== a && bE(this.B, 0),
          (this.D = Date.now()),
          (this.B = b),
          (this.B.div.style.zIndex = "1"),
          (d.div.style.zIndex = "0"));
        this.B &&
          ((a = (Date.now() - this.D) / 250),
          (a = xo(a, 0, 1)),
          bE(this.B, 1 - a),
          a < 1 ? (c = !0) : (this.B = null));
        bE(d, 1);
        return c;
      }
      detach() {
        this.div &&
          this.div.parentElement &&
          this.div.parentElement.removeChild(this.div);
      }
    },
    fE = Y(),
    gE = Y();
  function iE(a, b) {
    var c = a.storage.getData(b.id());
    c || ((c = new hE(b)), a.storage.setData(b.id(), c));
    return c;
  }
  function jE(a, b, c) {
    var d = kE;
    if (a.A.length === 0) return null;
    var e = a.A[0];
    a = iE(a, e);
    rt(d, b, c, 1);
    Yu(a.A, d, d);
    d[0] -= Math.floor(d[0]);
    return e;
  }
  function lE(a) {
    for (let b = 0; b < a.A.length; ++b) Ou(a.D[b]);
    a.D = [];
  }
  var oE = class extends Su {
      constructor(a, b) {
        super();
        this.H = b;
        this.camera = new U();
        this.F = !1;
        this.storage = new kt(5, (c, d) => {
          d.detach();
        });
        this.A = [];
        this.G = 0.5;
        this.D = [];
        this.I = new $w();
        this.C = () => {
          Ix(a);
        };
      }
      setCamera(a) {
        this.camera = a;
        this.C();
      }
      Cd(a, b) {
        if (this.A.length !== 0) {
          var c = this.A[0];
          if (this.A.length !== 0) {
            var d = mj(this.camera).R() * 0.5,
              e = mj(this.camera).S() * 0.5,
              f = iE(this, this.A[0]);
            rt(kE, e, d, 1);
            Yu(f.A, kE, kE);
            this.G = kE[0];
          }
          d = this.G;
          c.xa().Jg(mE);
          $t(a, kE);
          Lt(mE, kE, kE);
          a = kE[0];
          e = kE[1];
          rt(
            kE,
            (Math.atan2(a, e) / Math.PI) * 0.5 + 0.5,
            -Math.atan2(kE[2], Math.sqrt(a * a + e * e)) / Math.PI + 0.5,
            1
          );
          a = kE[0] - d + 0.5;
          a -= Math.floor(a);
          kE[0] = a - 0.5 + d;
          c = iE(this, c);
          Yu(c.F, kE, kE);
          b[0] = kE[0];
          b[1] = kE[1];
        }
      }
      Ad(a) {
        a[0] = 1;
        a[1] = 179;
        if (this.A.length !== 0) {
          var b = this.camera;
          b = iE(this, this.A[0]).A[4] * mj(b).R() * 90;
          a[0] = Math.max(27 + b, 1);
          a[1] = Math.min(156 - b, 179);
          a[0] > a[1] && ((a[0] = (a[0] + a[1]) / 2), (a[1] = a[0]));
        }
      }
      Fe(a, b, c) {
        a = jE(this, a, b);
        if (!a) return null;
        nE.x = kE[0];
        nE.y = kE[1];
        return a.Ud(nE, c);
      }
      Vd(a, b, c) {
        a = jE(this, a, b);
        if (!a) return null;
        if ((b = a.Sd())) {
          c = Tx(b, kE[0], kE[1], c);
          if (!c) return null;
          a.xa().zd(mE);
          Lt(mE, c.origin, c.origin);
          Mt(mE, c.dir, c.dir);
          xt(c.dir, c.dir);
          return c;
        }
        return null;
      }
      Tc(a, b) {
        if (this.A.length > 0) {
          let c = this.A[0];
          if (c.Sd()) return c.xa().Tc(a, b);
        }
        return 500;
      }
      bd(a, b) {
        if (!ox(this.A, a)) {
          lE(this);
          for (var c = 0; c < this.A.length; ++c) {
            var d = this.A[c];
            qb(a, d) === -1 && iE(this, d).detach();
          }
          this.A = [];
          for (c = 0; c < a.length; ++c)
            (d = a[c]),
              bA(Z(d.Ia())) &&
                !nx(d) &&
                (mx(d) || (d.oc(b), d.Pb(this.C)), this.A.push(d));
          for (a = 0; a < this.A.length; ++a)
            (b = ex(this.A[a], "TileReady", this.C)), this.D.push(b);
        }
      }
      Hb() {}
      clear() {
        lE(this);
        this.storage.clear();
        this.A = [];
      }
      Ta() {}
      mb() {
        return null;
      }
      Ib(a) {
        var b = this.H;
        a = a > 0.5 ? "white" : "black";
        var c = Vs["background-color"];
        if (!c) {
          var d = Vn();
          c = d;
          b.style[d] === void 0 &&
            ((d = (Nb ? "Webkit" : Mb ? "Moz" : null) + Wn(d)),
            b.style[d] !== void 0 && (c = d));
          Vs["background-color"] = c;
        }
        c && (Us.test(c) ? b.style.setProperty(c, a) : (b.style[c] = a));
      }
      run() {
        this.update(!0);
      }
      qc() {
        this.update(!1);
      }
      update(a) {
        var b = (this.F = !1),
          c = new Jw(this.I, "render_html4_pano");
        c.K();
        for (let e = 0; e < this.A.length; ++e) {
          var d = this.A[e];
          mx(d) &&
            ((d = iE(this, d)),
            (b = d.update(this.camera, this.H, c) || b),
            eE(d, d.Rc));
        }
        b
          ? a && this.C()
          : ((this.F = !0), this.dispatchEvent(new ru("ViewportReady", this)));
        c.done("main-actionflow-branch");
      }
      Ob() {
        return this.F;
      }
      Ja() {}
    },
    kE = Y(),
    mE = Ct(),
    nE = new As();
  function pE(a, b, c, d) {
    b = new oE(c, d);
    a(b);
  }
  var qE = class extends dz {
    constructor(a, b, c, d) {
      super("SCPI", [...arguments]);
    }
  };
  function rE(a, b) {
    return u.setTimeout(() => {
      try {
        a();
      } catch (c) {
        throw c;
      }
    }, b);
  }
  function sE(a) {
    return u.setInterval(() => {
      try {
        a();
      } catch (b) {
        throw b;
      }
    }, 1e4);
  }
  var tE = class {
    constructor(a) {
      this.U = a;
      this.C = this.B = this.A = null;
      this.D = () => {
        this.C = this.B = null;
        this.A !== null && this.F();
      };
    }
    start(a) {
      this.A = Date.now() + a;
      if (this.B !== null) {
        if (this.A >= this.C) return;
        u.clearTimeout(this.B);
      }
      this.C = this.A;
      this.B = rE(this.D, a);
    }
    cancel() {
      this.A = null;
    }
    F() {
      var a = Date.now();
      a >= this.A - 20
        ? ((this.A = null), (a = this.U), a())
        : ((this.C = this.A), (this.B = rE(this.D, this.A - a)));
    }
  };
  var uE = class {
    constructor(a, b, c) {
      this.duration = a;
      this.C = b;
      this.Vb = c;
      this.A = null;
      this.B = new tE(() => {
        var d = this.A;
        d && ((this.A = null), this.C(d), d.done(this.Vb));
      });
    }
    start(a) {
      this.B.A === null &&
        (a.gb(this.Vb),
        this.A && this.A.done(this.Vb),
        (this.A = a),
        this.B.start(this.duration));
    }
    stop() {
      this.B.cancel();
      this.A && (this.A.done(this.Vb), (this.A = null));
    }
  };
  function vE(a, b, c, d, e, f = !1) {
    var g = B(b, vl, 8);
    g = E(g, 1);
    if (!g) return "";
    var h = {};
    E(e, 1) && (h.hl = E(e, 1));
    E(e, 2) && (h.gl = E(e, 2));
    ml(zl(b)) === 2
      ? a && ((a = jj(a).Ba()), (h.cbp = `1,${Math.floor(a)},,0,0`))
      : c
      ? (h.cid = c)
      : d && (h.fid = d);
    f && (h.has_annotation = 1);
    return Po(g, h);
  }
  function wE(a) {
    if (!a || !z(a, 6)) return null;
    a = B(a, ek, 6);
    var b;
    (b = !z(a, 5)) ||
      ((b = B(a, sj, 5).wa()),
      (b = /^[\s\xa0]*$/.test(b == null ? "" : String(b))));
    return b ? null : B(a, sj, 5).wa();
  }
  function xE(a, b) {
    return Q(a, 1, b);
  }
  var yE = class extends S {
    constructor(a) {
      super(a);
    }
    wa() {
      return E(this, 1);
    }
    Dd() {
      return Rf(this, 1);
    }
  };
  var zE = class extends S {
    constructor(a) {
      super(a);
    }
  };
  function AE(a, b, c, d, e) {
    var f = a.Gd,
      g = a.lb;
    a = [];
    var h = [];
    wh(QA(f), b);
    z(b, 8) &&
      ((c = vE(null, b, c, d, e)), ul(Fl(QA(f)), c), FA(A(g, HA, 13), c));
    c = b.Hc();
    d = El(b);
    for (e = 0; e < df(c, xj, 2); e++) a.push(BE(ff(c, 2, xj, e)));
    for (e = 0; e < df(c, xj, 1); e++) h.push(CE(ff(c, 1, xj, e)));
    df(c, xj, 1) ||
      h.push(xE(new yE(), "Photos are copyrighted by their owners"));
    for (e = 0; e < df(c, xj, 3); e++) h.push(CE(ff(c, 3, xj, e)));
    for (e = 0; e < df(c, xj, 4); e++) {
      var k = ff(c, 4, xj, e);
      C(k, 5, !0) ? h.push(CE(k)) : a.push(BE(k));
    }
    e = Bl(b);
    var l = !1;
    if (df(e, sj, 3)) {
      var m = ff(e, 3, sj, 0).wa();
      l = !0;
    } else dA(f) ? (m = "") : ml(zl(b)) !== 2 && (m = "Untitled");
    k = DE(b);
    var n = !1;
    k || ((k = m), (n = !0));
    m = l && n;
    l = b.ha().Oa();
    l !== 1 &&
      k &&
      (df(c, xj, 5) && wj(ff(c, 5, xj, 0))
        ? ((n = new JA()),
          FA(IA(n), wj(ff(c, 5, xj, 0))),
          GA(IA(n), k),
          a.unshift(n))
        : Q(f, 4, k));
    l === 1 &&
      (k && Q(f, 4, k),
      (c = wE(d)) ? SA(f, c) : hA(f) && SA(f, "From the web"));
    for (m = m ? 1 : 0; m < df(e, sj, 3); m++) SA(f, ff(e, 3, sj, m).wa());
    B(e, sj, 5).wa() && TA(f, B(e, sj, 5).wa());
    (b = kA(b)) && h.unshift(xE(new yE(), "Image capture: " + b));
    bf(g, 12);
    rb(h, (q) => {
      var r = Bf(g, 12, yE);
      y(r, q);
    });
    bf(f, 19);
    rb(a, (q) => {
      var r = Bf(f, 19, JA);
      y(r, q);
    });
  }
  function DE(a) {
    var b;
    (b = Xj(Bl(a)).wa() || Yj(Bl(a)).wa()) ||
      ((b = Bl(a)), (b = B(b, sj, 8).wa()));
    if (b) return b;
    for (let c = 0; c < Dl(a); c++) {
      let d = Cl(a, c);
      for (let e = 0; e < df(d, uj, 10); e++) {
        let f = ff(d, 10, uj, e);
        if ((b = B(f, sj, 3).wa()) && !z(f, 2)) return b;
      }
    }
    return null;
  }
  function EE(a) {
    return vj(a).wa() || (Ff(a, 4) === 1 && "From a Google User") || "";
  }
  function CE(a) {
    var b = new yE(),
      c = EE(a);
    if (Rf(a, 3)) {
      var d = Q(b, 3, E(a, 3));
      Q(d, 6, c);
    } else c && xE(b, c);
    Rf(a, 2) && Q(b, 2, wj(a));
    return b;
  }
  function BE(a) {
    var b = new JA(),
      c = EE(a);
    Rf(a, 2)
      ? (c && GA(IA(b), c),
        FA(IA(b), wj(a)),
        Rf(a, 3) && ((c = IA(b)), Q(c, 3, E(a, 3))))
      : c && Q(b, 1, c);
    return b;
  }
  var FE = {};
  function GE(a, b, c, d) {
    var e = u.setTimeout(() => {
      var f = FE[e];
      delete FE[e];
      try {
        a.call(u, f.X);
      } catch (g) {
        throw Ny(g);
      }
      f.X.done(f.Vb);
    }, b);
    c.gb(d);
    FE[e] = { X: c, Vb: d };
    return e;
  }
  function HE(a) {
    u.clearTimeout(a);
    var b = FE[a];
    b && (b.X.done(b.Vb), delete FE[a]);
  }
  function IE(a, b, c) {
    a.direction === b
      ? (a.A && HE(a.A),
        (a.A = GE(
          (d) => {
            a.cancel(d);
          },
          200,
          c,
          "sceneContZoomTickle"
        )))
      : a.cancel(c);
  }
  var JE = class {
    constructor() {
      this.handle = this.A = this.direction = null;
    }
    start(a, b, c) {
      this.handle = a;
      this.direction = b;
      this.A = GE(
        (d) => {
          this.cancel(d);
        },
        200,
        c,
        "sceneContZoomStart"
      );
    }
    isActive() {
      return !!this.handle;
    }
    cancel(a) {
      this.handle &&
        (this.handle.cancel(a), (this.direction = this.A = this.handle = null));
    }
  };
  var KE = class {
    constructor(a) {
      this.message = a;
    }
    stop() {}
  };
  var NE = class {
      constructor(a, b) {
        this.f = b;
        this.node = null;
        this.A = !1;
        this.B = null;
        this.node = a;
      }
      invoke(a) {
        if (!this.A) {
          var b = this.f;
          a = b(a);
          a === !1 && this.cancel();
          return a;
        }
      }
      cancel() {
        this.A = !0;
      }
      key() {
        return this.B;
      }
      M() {
        return !this.node;
      }
      dispose() {
        this.node && this.N();
        this.node = null;
      }
      listen() {
        if (this.B == null && this.node) {
          this.A = !1;
          this.B = LE++;
          var a = this.node;
          a.C || (a.C = {});
          a.C[this.key()] = this;
          (a = a.A.B) && a.A.push(this);
        }
      }
      N() {
        this.B != null && this.node && (ME(this.node, this.B), (this.B = null));
      }
    },
    LE = 1e5;
  function ME(a, b) {
    if (b !== null && b !== void 0 && (a.C && delete a.C[b], (a = a.A.B))) {
      let c = xb(a.A, (d) => d.key() === b);
      c && (c.cancel(), (a.C = !0));
    }
  }
  function OE(a) {
    a = "PropNode#" + a + "(uint32 id)";
    var b = PE[a];
    (b && PE.hasOwnProperty(a)) || ((b = uv()), (PE[a] = b));
  }
  function QE(a) {
    if (a.B) a.B.C && a.B.B === 0 && RE(a);
    else {
      let b = new SE();
      TE(a, b);
      a.B = b;
    }
  }
  function UE(a, b) {
    if (a.C) for (let c of Object.values(a.C)) c.invoke(b);
    for (let c of Object.values(a.children)) UE(c, b);
  }
  function VE(a, b) {
    a.A = b;
    for (let c of Object.values(a.children)) VE(c, b);
  }
  function WE(a, b) {
    b !== a.parent &&
      (a.parent && delete a.parent.children[a.D],
      (a.parent = b),
      (a.A.B = null),
      VE(a, a),
      b &&
        b.A !== a &&
        ((b.children[a.D] = a), (a.parent = b), (b.A.B = null), VE(a, b.A)));
  }
  function TE(a, b) {
    if (a.C) for (let c of Object.values(a.C)) b.A.push(c);
    for (let c of Object.values(a.children)) TE(c, b);
  }
  function RE(a) {
    a = a.B;
    a.C && a.B === 0 && ((a.A = vb(a.A, (b) => !b.A)), (a.C = !1));
  }
  var YE = class {
    constructor() {
      this.D = XE++;
      this.parent = null;
      this.children = {};
      this.C = null;
      this.A = this;
      this.B = null;
      OE("nodeNotify");
      OE("nodeBatchNotify");
      OE("listener");
      OE("nodeSelfNotify");
      OE("setNodeParent");
      OE("buildTreeListenerCache");
      OE("pruneTreeListenerCache");
    }
  };
  class SE {
    constructor() {
      this.B = 0;
      this.A = [];
      this.C = !1;
    }
  }
  var XE = 1e5,
    PE = {};
  function ZE(a, b, c) {
    var d = a.get() !== b.get();
    WE(a, b);
    a.value = void 0;
    d && UE(a, c);
  }
  function $E(a) {
    return a.get() !== void 0;
  }
  function aF(a, b, c) {
    return new NE(a, (d) => (c ? b.call(c, d) : b(d)));
  }
  var bF = class extends YE {
    constructor(a, b) {
      super();
      this.mutable = a;
      this.value = b;
    }
    unbind(a) {
      var b = this.parent && $E(this);
      WE(this, null);
      b && UE(this, a);
    }
    get() {
      return this.A.value;
    }
    listen(a, b) {
      a = aF(this, a, b);
      a.listen();
      return a;
    }
    set(a, b) {
      a !== this.A.value && ((this.A.value = a), this.notify(b));
    }
    notify(a) {
      QE(this.A);
      var b = this.A.B,
        c = b.A;
      b.B += 1;
      var d = c.length;
      for (let e = 0; e < d; e++) {
        let f = c[e];
        f.A || f.invoke(a);
      }
      --b.B;
    }
  };
  function cF(a) {
    return new bF(!0, a);
  }
  function dF(a) {
    return new bF(!1, a);
  }
  var eF = class {
    constructor() {
      this.lb = cF(new zE());
      this.Ea = dF();
      this.camera = cF();
      this.content = cF();
      this.Cc = dF();
      this.Ic = this.lc = this.keyboard = this.hf = this.Ua = this.aa = null;
    }
    initialize() {}
    ec() {}
    ze() {
      return !1;
    }
    moveTo(a, b, c, d, e) {
      e(d);
      return !1;
    }
    Ag() {}
    Jf(a, b, c) {
      c(!1);
    }
    ah() {
      return !1;
    }
    Yg() {}
    bh() {}
    Kf() {}
    Lf() {}
    Zg() {}
    If() {}
    Xg() {}
    resize() {}
    mf() {
      return "n";
    }
    Sf() {
      return !1;
    }
  };
  function fF(a, b) {
    return gF(a) && a.A() === b.A()
      ? z(a, 5) && z(b, 5)
        ? lA(Z(a), Z(b))
        : vh(a, b)
      : !1;
  }
  function hF(a) {
    return a === 0 || a === 3;
  }
  function iF(a) {
    if (!a) return !1;
    var b = a.A() === 1;
    !b || mA(Z(a)) || Z(a).Y().jb() || ((a = Z(a)), z(a, 9));
    return b;
  }
  function jF(a) {
    if (!a) return !1;
    var b = a.A() === 2;
    b && z(a, 5) && (Z(a).Y().jb() || Z(a));
    return b;
  }
  function gF(a) {
    a = a?.A();
    return a === 1 || a === 2 || a === 4 || a === 5;
  }
  function kF(a, b) {
    var c = !1;
    a.Ed() && (DB(b, a.A()), (c = !0));
    if (z(a, 5)) {
      c = EB(b);
      var d = Z(a);
      y(c, d);
      c = !0;
    }
    z(a, 3) && ((c = A(b, yB, 3)), (d = B(a, yB, 3)), y(c, d), (c = !0));
    z(a, 4) && ((c = A(b, xB, 4)), (d = B(a, xB, 4)), y(c, d), (c = !0));
    Rf(a, 6) && (Q(b, 6, E(a, 6)), (c = !0));
    Hd(Ze(a, 7)) != null && (M(b, 7, C(a, 7)), (c = !0));
    z(a, 9) && ((c = GB(b)), (a = B(a, CB, 9)), y(c, a), (c = !0));
    a: {
      d = Z(b).Y();
      for (let e = 0; e < Dl(d); e++)
        if (((a = Cl(d, e)), df(a, uj, 10) > 0)) {
          a = !0;
          break a;
        }
      a = !1;
    }
    !a && z(b, 9) && (bf(b, 9), (c = !0));
    return c;
  }
  function lF(a) {
    var b = new HB(),
      c = EB(b);
    y(c, a);
    aA(a) ? DB(b, 1) : eA(a) ? DB(b, 2) : gA(a) ? DB(b, 5) : DB(b, 4);
    if (!Sf(a, 2)) {
      {
        c = 99;
        var d = zl(a.Y());
        let e = a.Y().ha();
        Sf(d, 1) ? (c = mF(d.Oa())) : Sf(e, 1) && (c = mF(e.Oa()));
        if (c === 99)
          switch (fA(a)) {
            case 1:
            case 2:
            case 4:
            case 5:
            case 11:
            case 13:
            case 3:
              c = 0;
              break;
            case 10:
              c = 1;
              break;
            case 12:
            case 15:
              c = 4;
              break;
            case 7:
            case 14:
              c = 5;
              break;
            case 27:
              c = 7;
          }
      }
      RA(EB(b), c);
    }
    if (z(a, 22)) {
      a: {
        a = a.Y();
        for (c = 0; c < Dl(a); ++c)
          if (
            ((d = Cl(a, c)),
            z(d, 2) && ((d = Lj($k(Cl(a, c)))), Sf(d, 5) && Ff(d, 5, 1) in nF))
          ) {
            a = nF[Ff(d, 5, 1)];
            break a;
          }
        a = 0;
      }
      a !== 0 && FB(b, a);
    }
    return b;
  }
  function mF(a) {
    switch (a) {
      case 1:
        return 7;
      case 2:
        return 0;
      case 3:
      case 8:
        return 4;
      case 4:
        return 1;
      case 10:
        return 10;
      default:
        return 99;
    }
  }
  var nF = { 1: 1, 2: 2, 3: 3 };
  function oF(a) {
    a %= 360;
    a < -180 ? (a += 360) : a > 180 && (a -= 360);
    return a;
  }
  function pF(a, b) {
    var c = !1;
    if (b && (mj(a).S() !== b.S() || mj(a).R() !== b.R())) {
      c = !0;
      var d = nj(a);
      y(d, b);
    }
    b = 75;
    Pf(a, 4) && (b = xo(a.Ga(), 1, 179));
    b !== a.Ga() && (P(a, 4, b), (c = !0));
    b = jj(a);
    Pf(b, 2) || (kj(a).ab(90), (c = !0));
    a = ij(a);
    b = Zi(a);
    b = b > 90 ? 90 : b < -90 ? -90 : b;
    b !== Zi(a) && ($i(a, b), (c = !0));
    b = oF(Xi(a));
    b !== Xi(a) && (Yi(a, b), (c = !0));
    return c;
  }
  var qF = class {
    constructor() {
      this.left = this.bottom = this.right = this.top = 0;
      this.A = !0;
    }
    clone() {
      var a = new qF();
      a.top = this.top;
      a.right = this.right;
      a.bottom = this.bottom;
      a.left = this.left;
      a.A = this.A;
      return a;
    }
  };
  var rF = class {
    constructor(a = 1) {
      this.A = a;
      this.B = !1;
    }
    copy() {
      var a = new rF();
      a.A = this.A;
      a.B = this.B;
      return a;
    }
  };
  function sF(a, b, c) {
    if (c !== void 0) return c;
    a = mj(a).S() / 2;
    b && (a += b.left / 2 - b.right / 2);
    return a;
  }
  function tF(a) {
    if (!a.N) {
      let b = lF(a.A);
      a.N = a.B.Hb(a.camera, [], b, 1, a.X, (c) => {
        a.L = c;
      });
    }
  }
  var AF = class {
    constructor(a, b, c, d, e, f, g, h) {
      this.M = b;
      this.H = d;
      this.O = e;
      this.K = f;
      this.B = g;
      this.X = h;
      this.D = new jx();
      this.C = new jx();
      this.N = null;
      this.L = !1;
      this.J = 0;
      this.I = a.clone();
      this.F = Z(this.M);
      this.G = c.clone();
      this.A = Z(this.H);
      this.camera = a.clone();
      b = ij(A(this.D, U, 3));
      d = hj(a);
      y(b, d);
      M(this.D, 6, !0);
      b = ij(A(this.C, U, 3));
      a = e ? hj(a) : hj(c);
      y(b, a);
      M(this.C, 6, !0);
    }
    Td() {
      return this.O && !this.K ? 0 : 500;
    }
    de(a) {
      tF(this);
      var b = 2 * Math.max(Math.min(a, 1), 0) - 1;
      b = 0.5 * (b * (2 + b * (b >= 0 ? -1 : 1)) + 1);
      if (!this.O) {
        var c = hj(this.I),
          d = hj(this.G),
          e = ij(this.camera),
          f = Xi(c);
        bj(
          $i(Yi(e, oF(zo(f, f + Do(f, Xi(d)), b))), zo(Zi(c), Zi(d), b)),
          zo(aj(c), aj(d), b)
        );
      }
      c = this.K ? b : 1;
      d = jj(this.I);
      e = jj(this.G);
      f = kj(this.camera);
      var g = d.Ba(),
        h = d.Va(),
        k = Do(h, e.Va());
      f.nb(Ao(g + zo(0, Do(g, e.Ba()), c)))
        .ab(zo(d.za(), e.za(), c))
        .wc(Ao(h + zo(0, k, c)));
      d = this.I.Ga();
      e = this.G.Ga();
      P(this.camera, 4, Math.abs(d - e) <= 1e-6 ? d : zo(d, e, c));
      if (a === 0 || lA(this.F, this.A)) uF(this.B, this.F, this.X);
      else if (a === 1)
        uF(this.B, this.A, this.X),
          (a = this.A.oa()),
          z(a, 1) && ((a = ij(this.camera)), (b = hj(this.A.oa())), y(a, b));
      else if (
        (P(this.D, 1, 1),
        !this.L || a < 0.2
          ? ((this.J = a), P(this.C, 1, 0))
          : ((a = (a - this.J) / (1 - this.J)),
            P(this.C, 1, a),
            dA(this.A) && P(this.D, 1, 1 - a)),
        P(this.D, 5, zo(1, 0, 10 * xo(b, 0, 0.1))),
        (a = zo(0, 1, 10 * (xo(b, 0.9, 1) - 0.9))),
        this.C && P(this.C, 5, a),
        (b = this.B),
        (f = this.F),
        (e = this.A),
        (c = this.X),
        (d = this.D),
        (a = this.C),
        b.A)
      ) {
        if ((b = b.Ja())) (a = a ? D(a, 1) : 1), b.updateTransition(1 - a, a);
      } else
        (f = vF(b, f, c)),
          (e = vF(b, e, c)),
          f && e && (b.ke(f, c, d), (b.jd = e), (b.xc = a), wF(b, c));
      return this.camera;
    }
    ee(a) {
      var b = !lA(Z(this.M), Z(this.H));
      if (a === 0) {
        if (b) {
          a = this.B;
          xF(a.cursor, !1);
          yF(a, !1);
          a = this.B;
          b = this.F;
          var c = this.A;
          zF(a, c, this.X);
          a.Ja()?.startTransition(b, c);
        }
      } else if (a === 1)
        return (
          b &&
            ((a = this.B),
            xF(a.cursor, !a.J),
            yF(a, !0),
            a.Ja()?.endTransition()),
          this.H
        );
      return null;
    }
  };
  var BF = (-2 / 3) * 0.075,
    CF = 1 / (3 * 0.075 * 0.075),
    DF = 1 / (1 + BF),
    EF = class {
      constructor(a, b, c) {
        this.A = c;
        this.B = jj(a).Ba();
        this.camera = a.clone();
        this.C = b ? -1 : 1;
      }
      Td() {
        return 4e3;
      }
      de(a) {
        this.A && (a = a <= 0.075 ? DF * CF * a * a * a : DF * (a + BF));
        a = Ao(this.B + 360 * this.C * a);
        kj(this.camera).nb(a);
        return this.camera;
      }
      ee() {
        return null;
      }
    };
  function FF(a, b, c, d, e, f, g, h) {
    this.A = a;
    this.H = b;
    this.C = c;
    this.F = d;
    this.D = e;
    this.G = f;
    this.B = g;
    this.I = h;
  }
  FF.prototype.clone = function () {
    return new FF(
      this.A,
      this.H,
      this.C,
      this.F,
      this.D,
      this.G,
      this.B,
      this.I
    );
  };
  FF.prototype.equals = function (a) {
    return (
      this.A == a.A &&
      this.H == a.H &&
      this.C == a.C &&
      this.F == a.F &&
      this.D == a.D &&
      this.G == a.G &&
      this.B == a.B &&
      this.I == a.I
    );
  };
  function GF(a, b) {
    if (b == 0) return a.A;
    if (b == 1) return a.B;
    var c = zo(a.A, a.C, b),
      d = zo(a.C, a.D, b);
    a = zo(a.D, a.B, b);
    c = zo(c, d, b);
    d = zo(d, a, b);
    return zo(c, d, b);
  }
  function HF(a, b) {
    if (b == 0) return a.H;
    if (b == 1) return a.I;
    var c = zo(a.H, a.F, b),
      d = zo(a.F, a.G, b);
    a = zo(a.G, a.I, b);
    c = zo(c, d, b);
    d = zo(d, a, b);
    return zo(c, d, b);
  }
  function IF(a, b) {
    var c = (b - a.A) / (a.B - a.A);
    if (c <= 0) return 0;
    if (c >= 1) return 1;
    var d = 0,
      e = 1,
      f = 0;
    for (var g = 0; g < 8; g++) {
      f = GF(a, c);
      let h = (GF(a, c + 1e-6) - f) / 1e-6;
      if (Math.abs(f - b) < 1e-6) return c;
      if (Math.abs(h) < 1e-6) break;
      else f < b ? (d = c) : (e = c), (c -= (f - b) / h);
    }
    for (g = 0; Math.abs(f - b) > 1e-6 && g < 8; g++)
      f < b ? ((d = c), (c = (c + e) / 2)) : ((e = c), (c = (c + d) / 2)),
        (f = GF(a, c));
    return c;
  }
  function JF(a, b, c) {
    a = new FF(0, 0, a, b, c, 1, 1, 1);
    var d = Array(51);
    for (b = 0; b < 51; b++) d[b] = HF(a, IF(a, b / 50));
    return (e) => {
      if (e <= 0) return 0;
      if (e >= 1) return 1;
      var f = e * 50;
      e = Math.floor(f);
      f -= e;
      return d[e] * (1 - f) + d[e + 1] * f;
    };
  }
  JF(0, 0, 0.58);
  var KF = JF(0.52, 0, 0.48),
    LF = JF(0.36, 0.67, 0.533);
  JF(0.24, 0.67, 0.533);
  JF(0.91, 1, 0.82);
  var NF = class {
    constructor(a) {
      var b = MF;
      this.H = LF;
      this.camera = a.clone();
      this.B = Ao(jj(a).za());
      this.A = Ao(jj(a).Ba());
      this.F = Ao(jj(a).Va());
      this.G = Do(this.B, Ao(b.za()));
      this.D = Do(this.F, Ao(b.Va()));
      this.C = Do(this.A, Ao(b.Ba()));
      this.duration = this.C !== 0 || this.D !== 0 || this.G !== 0 ? 650 : 0;
    }
    Td() {
      return this.duration;
    }
    de(a) {
      var b = this.camera,
        c = this.H(a);
      a = Ao(this.A + zo(0, this.C, c));
      var d = Ao(this.B + zo(0, this.G, c));
      c = Ao(this.F + zo(0, this.D, c));
      kj(b).nb(a);
      kj(b).ab(d);
      kj(b).wc(c);
      return b;
    }
    ee() {
      return null;
    }
  };
  function OF(a, b) {
    var c = null,
      d = 90;
    for (let e = 0; e < df(b, VA, 20); e++) {
      let f = ff(b, 20, VA, e);
      if (!mA(B(f, UA, 5))) continue;
      let g = Math.abs(Do(a, D(f, 1)));
      g < d && ((c = f), (d = g));
    }
    if (!c) return null;
    a = new UA();
    c = B(c, UA, 5);
    y(a, c);
    return a;
  }
  var PF = class {
    constructor(a, b, c, d, e) {
      this.A = b;
      this.F = LF;
      this.camera = a.clone();
      this.B = a.Ga();
      this.C = jj(a).Ba();
      var f = (e = e || new Ss(0, 0, 0, 0)),
        g = mj(a),
        h = Math.max(1, g.S() - f.left - f.right),
        k = Math.max(1, g.R() - f.top - f.bottom);
      g = (h / k) * a.Ga();
      k = (h / k) * b;
      c -= h / 2 + f.left;
      this.G = jj(a).Ba() + (c / h) * g - (c / h) * k;
      this.D = jj(a).za();
      h = e;
      e = mj(a).R();
      e = Math.max(1, e - h.top - h.bottom);
      d -= e / 2 + h.top;
      a = jj(a).za() - (d / e) * a.Ga();
      this.H = xo(a + (d / e) * b, 0, 170);
    }
    Td() {
      return (1e3 * Math.abs(this.A - this.B)) / 72;
    }
    de(a) {
      var b = this.F(a);
      a = zo(this.B, this.A, b);
      var c = zo(this.C, this.G, b);
      b = zo(this.D, this.H, b);
      var d = this.camera;
      kj(d).nb(c);
      kj(d).ab(b);
      P(d, 4, a);
      return this.camera;
    }
    ee() {
      return null;
    }
  };
  var QF = class {
    constructor() {
      this.A = [];
      this.B = !1;
    }
    commit(a) {
      this.B = !0;
      var b = this.A;
      for (let c = 0, d = b.length; c < d; c++) {
        let e = b[c];
        e.A || e.invoke(a);
      }
      this.A = [];
      this.B = !1;
    }
  };
  var RF = { bb: 137846 };
  function SF(a) {
    if (Mb) a = TF(a);
    else if (Pb && Nb)
      a: switch (a) {
        case 93:
          a = 91;
          break a;
      }
    return a;
  }
  function TF(a) {
    switch (a) {
      case 61:
        return 187;
      case 59:
        return 186;
      case 173:
        return 189;
      case 224:
        return 91;
      case 0:
        return 224;
      default:
        return a;
    }
  }
  function UF(a, b) {
    Lw((c) => {
      var d = a.content.get();
      if (d) {
        Te(d);
        var e = d.da;
        d = e;
        e = e[x] | 0;
        var f = b;
        if (f == null) cf(d, e, 10);
        else {
          if (!Array.isArray(f)) throw Cc();
          var g = f === Nc ? 7 : f[x] | 0,
            h = g,
            k = lf(g),
            l = k || Object.isFrozen(f),
            m = !0,
            n = !0;
          for (let r = 0; r < f.length; r++) {
            var q = f[r];
            fe(q, CB);
            k || ((q = Wc(q)), m && (m = !q), n && (n = q));
          }
          k || ((g = m ? 13 : 5), (g = n ? g & -4097 : g | 4096));
          (l && g === h) || ((f = [...f]), (h = 0), (g = mf(g, e)));
          g !== h && (f[x] = g);
          e = cf(d, e, 10, f);
          2 & g || !(4096 & g || 16 & g) || Ue(d, e);
        }
        a.content.notify(c);
      }
    });
  }
  function VF(a, b) {
    var c = !1,
      d = b.Ga();
    a = xo(d, 15, WF(a));
    a !== d && ((c = !0), P(b, 4, a));
    return c;
  }
  function WF(a) {
    return (a = a.content.get()) && dA(Z(a)) ? 40 : 90;
  }
  function XF(a, b, c, d, e, f, g = !0) {
    var h = a.camera.get(),
      k = a.content.get();
    YF(a, e);
    if ((c && !fF(k, c)) || b || !c) {
      c &&
        z(c, 9) &&
        (wh(GB(a.content.get()), B(c, CB, 9)), ZF(a), a.content.notify(e));
      var l = new U();
      b && (y(l, b), a.ze(l, mj(h)));
      b || (l = h);
      if (!c || vh(k, c)) {
        if (d.A === 2) {
          y(h, l);
          a.camera.notify(e);
          f(e);
          return;
        }
        c || (c = k);
      }
      b = null;
      k && z(k, 5) && (b = Z(k));
      k = new UA();
      wh(k, Z(c));
      b && lA(b, k) && (uF(a.A, k, e), $F(a, k, e));
      h
        ? ((h = hj(h)), du(Xi(h), Zi(h), aj(h), aG))
        : (aG[0] = aG[1] = aG[2] = 0);
      h = hj(l);
      du(Xi(h), Zi(h), aj(h), bG);
      h = Math.sqrt(zt(aG, bG));
      var m = d.A === 2 || h > 800,
        n = Xp(() => {
          a.Qc(l, c, m, g, f, e);
        });
      if (a.A.A !== null) {
        a.I && a.I.stop();
        let q = new uE(
          750,
          () => {
            a.I = null;
            n();
          },
          "click-to-go"
        );
        q.start(e);
        a.I = q;
        cG(
          a,
          k,
          () => {
            q === a.I && (q.stop(), n());
          },
          e
        );
      } else n();
    } else (d = new HB()), y(d, c), a.content.set(d, e), ZF(a), f(e);
  }
  function YF(a, b) {
    a.C && (a.C.cancel(b), (a.C = null));
    a.F && (a.F.cancel(b), (a.F = null));
    a.D && (a.D.cancel(b), (a.D = null));
    a.B && (a.B.cancel(b), (a.B = null));
    a.G.isActive() && a.G.cancel(b);
  }
  function dG(a, b) {
    var c = a.lb.get();
    Q(c, 1, "");
    Q(c, 3, "");
    a.lb.notify(b);
  }
  function ZF(a) {
    var b = a.content.get();
    b && ((b = z(b, 9) ? B(b, CB, 9) : null), eG(a.A, b));
  }
  function $F(a, b, c) {
    var d = a.A.C;
    if (!d || d.Mb() !== 4) {
      var e = new Qi();
      wh(e, b.Y().ha());
      fG(a);
      cG(
        a,
        b,
        (f, g, h, k) => {
          if (a.isActive) {
            if (f) {
              f = new UA();
              y(f, k);
              if (g) {
                var l = ij(f.ja()),
                  m = hj(g);
                y(l, m);
                l = kj(f.ja());
                g = jj(g);
                y(l, g);
              }
              gG(a, f, h);
              g = f;
              k = k.Y();
              l = a.locale;
              m = { lb: new zE(), Gd: new UA() };
              y(m.Gd, g);
              if (
                k &&
                (z(k, 7) ||
                  z(k, 5) ||
                  z(k, 4) ||
                  z(k, 10) ||
                  k.jb() ||
                  z(k, 3) ||
                  z(k, 9) ||
                  z(k, 1) ||
                  z(k, 8))
              ) {
                if (g && z(g, 12)) {
                  var n = B(g, HA, 12);
                  n = E(n, 1);
                  var q = Oo(n);
                  q ||
                    ((n = decodeURIComponent(n.match(Ho)[6] || "")),
                    (q = Oo(n)));
                  n = q ? q : null;
                } else n = null;
                q = null;
                df(g, OA, 16) > 0 &&
                  LA(NA(ff(g, 16, OA, 0))) === 0 &&
                  (q = NA(ff(g, 16, OA, 0)).A());
                bf(m.Gd, 4);
                bf(m.Gd, 18);
                AE(m, k, n, q, l);
              }
              k = m;
              if ((g = a.content.get())) {
                l = a.lb.get();
                m = null;
                if ((n = z(g, 5))) (n = Z(g)), (n = z(n, 22));
                n && Z(g).Y().jb() && (m = Z(g).Y().ha());
                n = EB(g);
                y(n, k.Gd);
                m && hG(a, m);
                k.lb && y(l, k.lb);
                l = Z(g);
                kF(lF(l), g);
                iG(a);
                if (a.Bb) {
                  g = a.A;
                  k = k.Gd;
                  if ((l = g.C))
                    (m = Z(l.Ia())),
                      lA(m, k),
                      l.Jb(k),
                      (g.J = dA(k)),
                      xF(g.cursor, !g.J),
                      jG(g, h);
                  a.camera.notify(h);
                }
                ZF(a);
                k = new QF();
                g = a.content;
                QE(g.A);
                k.B || k.A.push(...g.A.B.A);
                g = a.lb;
                QE(g.A);
                k.B || k.A.push(...g.A.B.A);
                k.commit(h);
              }
              kG(a, f, h);
            } else
              (f = k.Y()),
                vh(e, f.ha())
                  ? (f = !1)
                  : (g = a.content.get())
                  ? ((l = a.A),
                    Rf(e, 2) &&
                      f.jb() &&
                      !vh(e, f.ha()) &&
                      (n = e.va()) &&
                      !l.Z[n] &&
                      ((q = new UA()), (m = QA(q)), y(m, f), (l.Z[n] = q)),
                    (l = QA(EB(g))),
                    y(l, f),
                    hG(a, e),
                    (f = Z(g)),
                    gG(a, f, h),
                    uF(a.A, f, h),
                    $F(a, f, h),
                    (f = !0))
                  : (f = !1),
                f ||
                  vh(e, k.Y().ha()) ||
                  ((k = new UA()),
                  y(k, b),
                  bf(k, 1),
                  z(k, 22) && ((f = QA(k)), bf(f, 2)),
                  gG(a, k, h));
            a.W = !0;
          }
        },
        c
      );
    }
  }
  function cG(a, b, c, d) {
    a.M = lG(
      a.A,
      b,
      (e, f, g, h) => {
        c(e, f, g, h);
      },
      d
    );
  }
  function mG(a, b) {
    a.F = null;
    var c = a.camera.get(),
      d = a.content.get();
    if (c && d) {
      let e = new U();
      y(e, c);
      hx(a, "user-input-event", b, {
        type: "zoom",
        camera: e,
        contentType: d.A(),
      });
    }
  }
  function nG(a, b, c, d) {
    oG(a, b, c, d, (e) => {
      a.A.cursor.L = e;
    });
  }
  function pG(a, b, c, d) {
    var e = d.event();
    e && nG(a, e, b, c);
    qG(a.A, b, c, d);
    rG(a.A) &&
      (sG(a.A),
      a.ua.stop(),
      tG(
        a.A,
        b,
        c,
        d.U((f) => {
          f || a.ua.start(d);
        }, "ioacbb")
      ));
  }
  function uG(a, b) {
    nG(a, b, b.x, b.y);
  }
  function vG(a, b, c) {
    wG(
      a.A,
      b.x,
      b.y,
      c.U((d) => {
        d && xG(a, d, c);
      }, "gctb")
    );
  }
  function yG(a, b) {
    a.A.Ad(zG);
    b = xo(b, zG[0], zG[1]);
    if (dA(Z(a.content.get()))) {
      var c = a.camera.get().Ga(),
        d = Math.abs(c - 40) + 5;
      let e = jj(Z(a.content.get()).oa()).za();
      c = e - d / 2;
      d = e + d / 2;
      a = jj(a.camera.get()).za();
      d < a && (d = a);
      c > a && (c = a);
      b = xo(b, c, d);
    }
    return b;
  }
  function AG(a, b) {
    if (!dA(Z(a.content.get()))) return b;
    var c = Z(a.content.get()),
      d = zl(c.Y()),
      e = nl(d).S();
    d = nl(d).R();
    e = 2 * Co(Math.atan((e / d) * Math.tan(Bo(20))));
    c = jj(c.oa()).Ba();
    d = a.camera.get();
    var f = mj(d).S(),
      g = mj(d).R();
    e =
      Math.abs(2 * Co(Math.atan((f / g) * Math.tan(Bo(d.Ga() / 2)))) - e) / 2 +
      2.5;
    a = jj(a.camera.get()).Ba();
    a = Math.abs(Do(c, a));
    a > e && (e = a);
    a = Do(c, b);
    Math.abs(a) > e && (b = a < 0 ? Ao(c - e) : Ao(c + e));
    return b;
  }
  function BG(a, b, c) {
    var d = Date.now(),
      e = d - a.Z;
    if (e > 0) {
      var f = a.N,
        g = c - a.L[1];
      let h = Math.exp(-e / 32);
      f[0] = h * f[0] + ((1 - h) * (b - a.L[0])) / e;
      f[1] = h * f[1] + ((1 - h) * g) / e;
    }
    e = a.L;
    e[0] = b;
    e[1] = c;
    a.Z = d;
  }
  function oG(a, b, c, d, e) {
    (b &&
      (b.type === "touchstart" ||
        b.type === "touchmove" ||
        b.type === "touchend" ||
        b.type === "touchcancel" ||
        CG[b.pointerType || ""])) ||
    !a.P
      ? e(!1)
      : tG(a.A, c, d, (f) => {
          e(!f);
        });
  }
  function fG(a) {
    a.M && (a.M.stop(), (a.M = null));
  }
  function DG(a, b, c, d) {
    if (d.Te("scene", "move_camera")) {
      var e = a.camera.get(),
        f = b.ja();
      c ? rx(f, c) : lj(f) || ((c = kj(f)), e ? wh(c, jj(e)) : c.ab(90));
      if ((e = a.content.get()))
        (b = lF(b)),
          wh(GB(b), B(e, CB, 9)),
          Sf(e, 8) && FB(b, Ff(e, 8)),
          a.Qc(f, b, !1, !1, () => {}, d);
    }
  }
  function EG(a, b, c) {
    a.K && ((a = a.K), (b = new FG(a.I, a.H, a, b)), c && (b.A = c), b.Nc());
  }
  function kG(a, b, c) {
    a.V.get((d) => {
      d = d.Jd.yg();
      var e = GG(d, mz),
        f = E(b, 11);
      f && (gD(f), (e.A = new hD("", f)));
      f = new Tr();
      var g = A(f, Rr, 2);
      var h = b.Y().ha().Oa();
      g = R(g, 1, h);
      h = b.Y().ha().va();
      g = Q(g, 2, h);
      h = ml(zl(b.Y()));
      R(g, 3, h);
      e.F = f.clone();
      e = d.G;
      f = e.F;
      a.K = e.ea(lz);
      a.K.F = f.clone();
      a.O = e.ea(RF);
      a.O.F = f.clone();
      d.Nc();
    }, c);
  }
  function xG(a, b, c) {
    c.A("scene", "move_camera");
    fG(a);
    cG(
      a,
      b,
      (d, e, f, g) => {
        d &&
          ((d = new UA()),
          y(d, g),
          dA(b)
            ? lj(d.oa()) && ((g = kj(d.ja())), bf(g, 3))
            : ((g = d.ja()), bf(g, 2)),
          e && ((g = ij(d.ja())), (e = hj(e)), y(g, e)),
          DG(a, d, null, f),
          EG(a, 4));
      },
      c
    );
  }
  function HG(a, b, c, d) {
    a.B && a.B.cancel(c);
    a.C && a.C.cancel(c);
    var e = a.camera.get(),
      f = jj(e).Ba(),
      g = IG(a.A, (b ? f : f + 180) % 360);
    b = a.content.get();
    if (e && b) {
      var h = new U();
      var k = b.A();
    }
    g &&
      (c.A("scene", "move_camera"),
      fG(a),
      cG(
        a,
        g,
        (l, m, n, q) => {
          l &&
            (y(g, q),
            m && ((l = ij(g.ja())), (m = hj(m)), y(l, m)),
            (m = kj(g.ja())),
            (l = jj(a.camera.get())),
            y(m, l),
            DG(a, g, null, n),
            EG(a, 24, d),
            h !== void 0 &&
              k !== void 0 &&
              hx(a, "user-input-event", n, {
                type: "pan",
                camera: h,
                contentType: k,
              }));
        },
        c
      ));
  }
  function JG(a, b, c, d) {
    if (!a.B && !a.D) {
      d.I("pan");
      a.C && a.C.cancel(d);
      var e = a.camera.get(),
        f = a.Cc.get();
      c && d.Fa("pan0");
      c = new EF(e, b, c);
      a.B = f.animate(c, d, (g) => {
        a.B.mh ? ((a.B = null), g.Fa("pan1")) : ((a.B = null), JG(a, b, !1, g));
        var h = a.camera.get(),
          k = a.content.get();
        if (h && k) {
          let l = new U();
          y(l, h);
          hx(a, "user-input-event", g, {
            type: "rotate",
            camera: l,
            contentType: k.A(),
          });
        }
      });
    }
  }
  function KG(a, b, c) {
    if (!a.D && LG(a.A))
      switch (b.keyCode) {
        case 38:
        case 87:
          HG(a, !0, c, 3);
          break;
        case 40:
        case 83:
          HG(a, !1, c, 4);
          break;
        case 37:
        case 65:
          JG(a, !0, !0, c);
          break;
        case 39:
        case 68:
          JG(a, !1, !0, c);
          break;
        case 107:
        case 187:
          a.Nd(1, c, void 0, void 0, !0);
          a.V.get((d) => {
            d.te(nz, 32);
          }, c);
          break;
        case 109:
        case 189:
          a.Nd(-1, c, void 0, void 0, !0),
            a.V.get((d) => {
              d.te(oz, 32);
            }, c);
      }
  }
  function MG(a, b) {
    var c = NG(a.A),
      d = a.camera.get();
    if (d && z(d, 1) && cj(hj(d)) && c && z(c, 1) && cj(hj(c))) {
      var e = aj(hj(d)),
        f = aj(hj(c));
      Math.abs(e - f) > 0.1 &&
        ((d = d.clone()),
        (e = ij(d)),
        (c = hj(c)),
        $i(e, Zi(c)),
        Yi(e, Xi(c)),
        bj(e, f),
        (f = new rF()),
        (f.A = 2),
        XF(a, d, null, f, b, () => {}));
    }
  }
  function gG(a, b, c) {
    var d = a.camera.get();
    if (d) {
      var e = a.content.get(),
        f = Z(e).Y().ha();
      e = kF(lF(b), e);
      hG(a, f);
      e && (ZF(a), a.content.notify(c));
      f = !1;
      e = hj(b.oa());
      if (Zi(hj(d)) !== Zi(e) || Xi(hj(d)) !== Xi(e) || aj(hj(d)) !== aj(e))
        (f = ij(d)), y(f, e), (f = !0);
      dA(b) &&
        ((e = jj(b.oa()).Ba()),
        jj(d).Ba() !== e && (kj(d).nb(e), (f = !0)),
        (e = jj(b.oa()).za()),
        jj(d).za() !== e && (kj(d).ab(e), (f = !0)),
        a.W || (P(d, 4, 40), (f = !0)));
      e = b.Y();
      var g;
      if ((g = Dl(e) > 0)) (g = Cl(e, 0)), (g = z(g, 11));
      g && ((e = Cl(e, 0)), (e = B(e, Oj, 11)), iA(e, d) && (f = !0));
      f && a.camera.notify(c);
      f = a.A.N;
      e = b.Y().ha().va();
      f.J = e;
      y(f.M, d);
      OG(f);
      mA(b) && a.Ea.get() && (iG(a), a.lb.notify(c));
    }
  }
  function hG(a, b) {
    var c = a.content.get();
    if (c) {
      var d = Z(c).Y().ha();
      (a = a.A.Z[b.va()]) &&
        vh(a.Y().ha(), d) &&
        ((c = yl(QA(EB(c)))), y(c, b));
    }
  }
  function iG(a) {
    var b = a.Ea.get(),
      c = a.content.get(),
      d = a.lb.get();
    b &&
      d &&
      c &&
      ((a = vE(b, Z(c).Y(), null, null, a.locale, rG(a.A))),
      FA(A(d, HA, 13), a));
  }
  var XG = class extends eF {
      constructor(a, b, c, d, e) {
        super();
        this.A = a;
        this.Na = b;
        this.locale = c;
        this.V = d;
        this.T = null;
        this.J = !1;
        this.sa = this.ga = this.Da = this.na = 0;
        this.G = new JE();
        this.D = this.F = this.C = null;
        this.H = [];
        this.B = null;
        this.N = Nx();
        this.L = Nx();
        this.Z = Date.now();
        this.isActive = !1;
        this.P = !0;
        this.Ca = !1;
        this.ea = !0;
        this.M = null;
        this.aa = this;
        this.Ua = this;
        this.keyboard = this;
        this.lc = this;
        this.ua = new uE(
          4e3,
          (f) => {
            PG(this.A);
            hx(this, "user-input-event", f, { type: "annotationshidden" });
          },
          "inactivity"
        );
        this.I = null;
        this.W = !1;
        this.O = this.K = null;
        this.A.cursor.L = !1;
        this.camera.listen(this.Sa, this);
        this.Ea.listen(this.ib, this);
        this.Bb = ds(ls(this.Na));
        this.hf = this.A;
        a.vectorTileLabelsEnabled() &&
          QG(
            this.A,
            (f) => {
              UF(this, f);
            },
            e
          );
      }
      initialize(a, b) {
        a = z(b, 9) ? B(b, CB, 9) : null;
        eG(this.A, a);
        this.W = !1;
      }
      ze(a, b) {
        b = pF(a, b || void 0);
        a = VF(this, a);
        return b || a;
      }
      moveTo(a, b, c, d, e) {
        if (this.D) return this.H.push(e), !0;
        var f = this.camera.get(),
          g = this.content.get();
        return b && iF(b) && !lA(Z(b), Z(g)) && c.A === 2
          ? (XF(this, a, b, c, d, e, !1), !0)
          : b && b.A() !== g.A()
          ? c.A !== 2 && this.T.Sf() && hF(b?.A())
            ? (YF(this, d),
              (a = a || f),
              (b = b || g),
              (g = this.Cc.get()),
              bf(a, 2),
              dG(this, d),
              g.transition(a, b, d, e),
              !0)
            : !1
          : (XF(this, a, b, c, d, e), !0);
      }
      Rc() {
        if (!this.camera.get()) return null;
        var a = this.camera.get();
        return a ? Math.log(WF(this) / a.Ga()) / Math.LN2 : null;
      }
      Jc() {
        return this.camera.get() ? Math.log(WF(this) / 15) / Math.LN2 : null;
      }
      hd() {
        return !0;
      }
      Nd(a, b, c, d, e) {
        if (this.ea) {
          var f = this.camera.get(),
            g = this.Cc.get();
          if (a !== 0 && !this.C && !this.D) {
            b.I("zoom");
            var h = f.Ga();
            a = a > 0 ? 0 : 1;
            var k = a === 0 ? 15 : WF(this);
            c = sF(f, this.A.mb(), c);
            d = d !== void 0 ? d : mj(f).R() / 2;
            e
              ? this.G.isActive()
                ? IE(this.G, a, b)
                : ((e = k),
                  e !== h &&
                    ((f = new PF(f, e, c, d, this.A.mb())),
                    (g = g.animate(f, b, (l) => {
                      mG(this, l);
                    })),
                    this.G.start(g, a, b)))
              : (this.G.cancel(b),
                (e = a === 0 ? h / 2 : h * 2),
                (e = a === 0 ? Math.max(k, e) : Math.min(k, e)),
                Math.abs(e - k) <= 10 && (e = k),
                e !== h &&
                  ((f = new PF(f, e, c, d, this.A.mb())),
                  (this.F = g.animate(f, b, (l) => {
                    mG(this, l);
                  }))));
          }
        }
      }
      ue(a, b) {
        if (this.ea) {
          var c = this.camera.get(),
            d = c.Ga();
          d *= Math.pow(2, -a);
          P(c, 4, d);
          VF(this, c) && this.camera.notify(b);
          if ((a = this.content.get()))
            (d = new U()),
              y(d, c),
              hx(this, "user-input-event", b, {
                type: "zoom",
                camera: d,
                contentType: a.A(),
              });
        }
      }
      Yg(a, b) {
        uG(this, a);
        qG(this.A, a.x, a.y, b);
        this.C && (this.C.cancel(b), b.Fa("thp1"));
        LG(this.A) && vG(this, a, b);
      }
      bh(a, b) {
        uG(this, a);
        qG(this.A, a.x, a.y, b);
      }
      Lf(a, b) {
        uG(this, a);
        if (this.J) {
          BG(this, a.x, a.y);
          let f = this.camera.get();
          var c = this.A.mb() || new qF();
          let g = Math.max(1, mj(f).S() - c.left - c.right);
          var d = Math.max(1, mj(f).R() - c.bottom - c.top),
            e = 1 / Math.tan(Bo(f.Ga() / 2));
          d = d / 2 + c.top;
          c = g / 2 + c.left;
          c = Co(
            Math.atan2((a.x - c) / d, e) - Math.atan2((this.na - c) / d, e)
          );
          a = yG(
            this,
            this.sa +
              Co(
                Math.atan2((a.y - d) / d, e) - Math.atan2((this.Da - d) / d, e)
              )
          );
          e = AG(this, Ao(this.ga - c));
          kj(f).ab(a);
          kj(f).nb(e);
          this.camera.notify(b);
        } else qG(this.A, a.x, a.y, b);
      }
      Kf(a, b) {
        uG(this, a);
        b.I("pan");
        this.J = !0;
        b = this.A;
        b.G && b.B.Ha() && b.B.ka().Xi();
        this.na = a.x;
        this.Da = a.y;
        this.ga = jj(this.camera.get()).Ba();
        this.sa = jj(this.camera.get()).za();
        b = this.L;
        var c = a.y;
        b[0] = a.x;
        b[1] = c;
        a = this.N;
        a[0] = 0;
        a[1] = 0;
        this.Z = Date.now();
      }
      Zg(a, b) {
        uG(this, a);
        if (!this.D) {
          var c = this.camera.get();
          BG(this, a.x, a.y);
          if (this.J) {
            var d = -1 * this.N[0],
              e = this.N[1];
            if (Math.sqrt(d * d + e * e) > 0.25) {
              a = this.Cc.get();
              let f = jj(c);
              e = f.za() + 10 * e;
              e = yG(this, e);
              MF.ab(e);
              d = f.Ba() + 10 * d;
              d = AG(this, d);
              MF.nb(d);
              d = new NF(c);
              b.Fa("thp0");
              this.C = a.animate(d, b, (g) => {
                this.C = null;
                g.Fa("thp1");
              });
            }
          }
          this.J = !1;
          RG(this.A);
          if ((a = this.content.get()))
            (d = new U()),
              y(d, c),
              hx(this, "user-input-event", b, {
                type: "rotate",
                camera: d,
                contentType: a.A(),
              });
        }
      }
      Jf(a, b, c, d) {
        this.D && this.D.isPlaying()
          ? c(!1)
          : this.F && this.F.isPlaying()
          ? c(!1)
          : this.C && this.C.isPlaying()
          ? c(!1)
          : this.B && this.B.isPlaying()
          ? c(!1)
          : LG(this.A)
          ? tG(
              this.A,
              a,
              b,
              d.U((e) => {
                if (e) c(!0);
                else if (this.P) {
                  if ((e = this.content.get()))
                    if (((e = Z(e)), cA(e) && eA(e))) {
                      c(!1);
                      return;
                    }
                  c(!!this.A.cursor.A);
                } else c(!1);
              }, "ioacbb")
            )
          : c(!1);
      }
      vd(a) {
        this.P = a;
      }
      enableZoom(a) {
        this.ea = a;
      }
      ah(a) {
        return a;
      }
      If(a, b) {
        uG(this, a);
        this.Jf(
          a.x,
          a.y,
          b.U((c) => {
            if (c) {
              var d = this.A.getCursor();
              d &&
                (qG(this.A, a.x, a.y, b),
                tG(
                  this.A,
                  a.x,
                  a.y,
                  b.U((e) => {
                    if (!e) {
                      let g = new UA();
                      xh(g, this.A.cursor.A);
                      let h = SG(this.A.cursor);
                      if (g) {
                        var f = TG(d);
                        fG(this);
                        cG(
                          this,
                          g,
                          (k, l, m, n) => {
                            k &&
                              (y(g, n),
                              l && ((k = ij(g.ja())), (n = hj(l)), y(k, n)),
                              DG(this, g, h, m),
                              f ? this.O && this.O.click() : EG(this),
                              (k = this.content.get())) &&
                              ((n = new U()),
                              xh(n, l),
                              hx(this, "user-input-event", m, {
                                type: "pan",
                                camera: n,
                                contentType: k.A(),
                              }));
                          },
                          b
                        );
                      }
                    }
                  }, "ioacbb")
                ));
            }
          }, "ccbb"),
          b
        );
      }
      up(a, b) {
        (a.keyCode !== 37 &&
          a.keyCode !== 39 &&
          a.keyCode !== 65 &&
          a.keyCode !== 68) ||
          !this.B ||
          this.B.cancel(b);
      }
      Xg(a, b) {
        uG(this, a);
        this.If(a, b);
      }
      Qc(a, b, c, d, e, f) {
        if (!(this.F || this.C || this.D || this.B) && this.isActive) {
          var g = this.Cc.get();
          if (g) {
            var h = this.camera.get();
            if (h) {
              var k = this.content.get();
              if (k) {
                var l = Z(k),
                  m = Z(b),
                  n = a.clone(),
                  q = dA(l),
                  r = dA(m);
                q && r
                  ? P(n, 4, h.Ga())
                  : this.Ca
                  ? Pf(n, 4) || P(n, 4, h.Ga())
                  : P(n, 4, r ? 40 : 75);
                l = UG(this.A, l, f);
                q = UG(this.A, m, f);
                l != null &&
                  q != null &&
                  l !== 3 &&
                  q !== 3 &&
                  ((l = q - l), (a = aj(hj(a)) + l), bj(ij(n), a));
                b = new AF(h, k, n, b, c, d, this.A, f);
                f.Fa("c2g0");
                this.H.push(e);
                this.D = g.animate(b, f, (t) => {
                  t.Fa("c2g1");
                  this.D = null;
                  $F(this, m, t);
                  for (let v = 0; v < this.H.length; v++) this.H[v](t);
                  this.H = [];
                });
              }
            }
          }
        }
      }
      ec(a, b) {
        this.isActive = !0;
        this.T = a;
        a.Pe(this.A, b);
        this.A.ec(b);
        var c = this.content.get();
        a = this.camera.get();
        var d = EB(c);
        bf(d, 18);
        c = EB(c);
        d = c.ja();
        y(d, a);
        uF(this.A, c, b);
        (d = VG(this.A))
          ? ((c = d.ja()), y(c, a), $F(this, d, b))
          : $F(this, c, b);
      }
      Ag(a) {
        this.isActive = !1;
        YF(this, a);
        fG(this);
        dG(this, a);
        var b = this.content.get();
        if (b) {
          var c = EB(b);
          Q(c, 4, "");
          b = EB(b);
          bf(b, 18);
        }
        WG(this.A, a);
        this.T = null;
      }
      Sa(a) {
        var b = this.camera.get();
        b && this.A.se(b, a);
      }
      ib(a) {
        this.camera.get() &&
          (VG(this.A) &&
            (this.Ea.get() && (iG(this), this.lb.notify(a)), MG(this, a)),
          (a = this.A),
          (a.V = !1),
          Ix(a.F));
      }
      resize(a, b) {
        var c = this.camera.get(),
          d = nj(c);
        y(d, a);
        this.camera.notify(b);
        if ((a = this.content.get()))
          (d = new U()),
            y(d, c),
            hx(this, "user-input-event", b, {
              type: "resize",
              camera: d,
              contentType: a.A(),
            });
      }
      mf() {
        return "pa";
      }
    },
    MF = new ej(),
    zG = Nx(),
    aG = Y(),
    bG = Y(),
    CG = { touch: !0, pen: !0 };
  function YG(a, b, c, d, e, f) {
    c.load("pa", b, (g, h) => {
      a(new XG(g, d, e, f, h));
    });
  }
  var ZG = class extends dz {
    constructor(a, b, c) {
      super("PNI", [...arguments]);
    }
  };
  function $G(a, b, c, d, e) {
    b = new QB(c, d, e);
    a(b);
  }
  var aH = class extends dz {
    constructor(a, b, c, d, e, f, g, h, k) {
      super("SCPR", [...arguments]);
    }
  };
  var bH = class {
    constructor(a) {
      this.A = a;
    }
    stop() {
      var a = this.A;
      a && ((this.A = null), a());
    }
  };
  var cH = class {
    constructor(a, b, c) {
      this.B = a;
      this.A = !0;
      this.camera = b ? b.clone() : null;
      this.content = c ? c.clone() : null;
    }
    Da() {
      return !0;
    }
    commit(a) {
      this.A &&
        ((this.A = !1),
        this.camera && this.B.se(this.camera, a),
        this.content && this.B.Jb(this.content, a));
    }
    cancel() {
      this.A = !1;
    }
    Gg() {
      return "SimpleRenderSequence";
    }
  };
  function dH(a, b) {
    if (a) {
      var c = [];
      a = Z(a).Y();
      for (let e = 0; e < Dl(a); e++) {
        let f = Cl(a, e);
        for (let g = 0; g < df(f, uj, 10); g++) {
          let h = ff(f, 10, uj, g),
            k = B(h, rj, 2);
          var d;
          (d = !b) ||
            ((d = B(h, tj, 1)), (d = !z(d, 2) && !z(d, 1) && z(h, 6)));
          d && (df(k, qj, 2) > 0 || df(k, pj, 1) > 0) && c.push(h);
        }
      }
      b = c;
    } else b = [];
    return b.length > 0;
  }
  Y();
  Y();
  Y();
  Y();
  Y();
  Nx();
  var eH = class extends dz {
    constructor(a, b, c, d, e, f) {
      super("AN", [...arguments]);
    }
  };
  var fH = class {
    constructor(a) {
      var b = new kt(30);
      this.A = a;
      this.cache = b;
    }
    Wd(a, b) {
      var c = nA(a);
      c ||
        ((c = hj(a.oa())),
        (c = Pf(c, 3) && Pf(c, 2) ? `${Zi(c)},${Xi(c)}` : ""));
      if (!c) return null;
      var d = this.cache.getData(c) || null;
      d || ((d = this.A.Wd(a, b)), this.cache.setData(c, d));
      return d;
    }
    clear() {
      this.cache.clear();
    }
  };
  var gH = class extends dz {
    constructor(a, b) {
      super("CPS", [...arguments]);
    }
  };
  var hH = class extends dz {
    constructor(a, b, c) {
      super("FPS", [...arguments]);
    }
  };
  var iH = class extends dz {
    constructor() {
      super("NCS", [...arguments]);
    }
  };
  var jH = class extends dz {
    constructor() {
      super("NTS", [...arguments]);
    }
  };
  var kH = class extends dz {
    constructor(a, b, c, d) {
      super("PTI", [...arguments]);
    }
  };
  var lH = class extends dz {
    constructor(a) {
      super("SPS", [...arguments]);
    }
  };
  var mH = class extends dz {
    constructor(a) {
      super("SPTS", [...arguments]);
    }
  };
  var nH = class extends dz {
    constructor(a, b) {
      super("SVP", [...arguments]);
    }
  };
  var oH = class extends dz {
    constructor(a, b) {
      super("SVT", [...arguments]);
    }
  };
  var pH = class extends ay {
    Za() {
      return this.A ? this.A.Za() : null;
    }
  };
  function qH(a, b) {
    b = b || new Fv();
    var c = a.oa();
    mu(c, b);
    var d = zv(b),
      e = D(a, 2) || 1;
    a = D(a, 3) || e + 1e-6;
    c = cu(Zi(hj(c)));
    d.F = void 0;
    d.G = void 0;
    d.H = void 0;
    d.M = e * c;
    d.L = 1;
    d.N = a / e;
    nu(b, d);
    return b;
  }
  function rH(a, b, c) {
    var d = B(a.G, XB, 2);
    if (!b) return d;
    a = new XB();
    var e = a.ja(),
      f = d.oa();
    y(e, f);
    Pf(d, 2) && P(a, 2, D(d, 2));
    Pf(d, 3) && P(a, 3, D(d, 3));
    c !== void 0 && ((d = P(a, 2, c)), P(d, 3, c + 1e-6));
    iz(b, a.ja());
    return a;
  }
  var xH = class {
      constructor() {
        this.sizes = [];
        this.G = null;
        this.D = Ct();
        this.H = Ct();
        this.C = this.A = !1;
        this.B = this.F = 1;
        this.tileSize = new gj();
        this.I = new gj();
        this.Jc = Math.max(0, this.sizes.length - 1);
      }
      initialize(a) {
        this.G = a;
        if (z(a, 9)) {
          var b = B(a, gj, 9);
          y(this.tileSize, b);
        } else if (oj(B(a, XB, 2).oa()) && !fj(this.tileSize)) {
          b = this.tileSize;
          var c = mj(B(a, XB, 2).oa());
          y(b, c);
        }
        z(a, 9) && oj(B(a, XB, 2).oa())
          ? ((b = mj(B(a, XB, 2).oa())),
            y(this.I, b),
            (this.F = b.S() / this.tileSize.S()),
            (this.B = b.R() / this.tileSize.R()),
            (this.C = !0))
          : ((this.B = this.F = 1), (this.C = !1));
        Od(Ze(a, 10)) != null && (this.Jc = Od(Ze(a, 10)) ?? 0);
        sH(B(a, XB, 2), this.D);
        Kt(this.D, this.H);
        this.A = !0;
      }
      Yc() {
        return this.A;
      }
      Uc() {
        return this.F;
      }
      Gc() {
        return this.B;
      }
      jc() {
        return this.tileSize;
      }
      J() {
        return this.I;
      }
      ob() {
        return this.Jc;
      }
      Lg() {
        var a = [];
        a[0] = a[1] = a[2] = 1;
        return a;
      }
      qf(a) {
        return this.C ? 1 << (this.Jc - a) : 1;
      }
      Hg() {
        a: {
          var a = u.devicePixelRatio || 1;
          for (let b = this.Jc; b > 0; b--)
            if (this.sizes[b] <= 512 * a * 1.2) {
              a = b;
              break a;
            }
          a = 0;
        }
        return a;
      }
      yb(a) {
        return Math.min(a / this.Uc(), 1);
      }
      zb(a) {
        return Math.min(a / this.Gc(), 1);
      }
      Lb(a, b, c, d) {
        c[d + 0] = a;
        c[d + 1] = b;
        c[d + 2] = 1;
      }
      qg(a, b, c, d) {
        b = (c.R() * Math.tan(d / 2)) / Math.tan(c.Kb / 2) / this.B;
        a = this.ob();
        c = this.jc();
        b = Math.floor(Math.log(c.R() / b) / Math.LN2);
        b = xo(b, 0, a);
        return a - b;
      }
      zd(a, b, c) {
        this.A && (b ? ((b = rH(this, b, c)), sH(b, a)) : Dt(a, this.D));
      }
      Jg(a) {
        Dt(a, this.H);
      }
      be(a, b, c, d, e) {
        if (this.A) {
          d = rH(this, d, e);
          d = qH(d, tH);
          e = zv(d);
          Math.round(e.D / (Math.PI / 2)) % 2 &&
            (e.C = 2 * Math.atan((Math.tan(e.C / 2) * e.width) / e.height));
          e.D = 0;
          nu(d, e);
          rt(pt, tH.Pa, tH.Qa, tH.Ra);
          d = a.dir;
          e = a.origin;
          var f = pt;
          if (
            f.length != e.length ||
            f[0] != e[0] ||
            f[1] != e[1] ||
            f[2] != e[2]
          ) {
            e = d = uH;
            f = tH.eb;
            var g = tH.fb;
            e[0] = tH.cb;
            e[1] = f;
            e[2] = g;
            e = vH;
            ot(d, e);
            f = -(nt(a.origin, e) + -nt(e, d)) / nt(a.dir, e);
            d = a.dir;
            e = uH;
            e[0] = d[0] * f;
            e[1] = d[1] * f;
            e[2] = d[2] * f;
            a = a.origin;
            e = d = uH;
            e[0] = a[0] + d[0];
            e[1] = a[1] + d[1];
            e[2] = a[2] + d[2];
            d = vH;
            ot(uH, d);
          }
          st(wH, d);
          wH[3] = 0;
          Nt(b, wH, wH);
          c.x = wH[0] / wH[3];
          c.y = wH[1] / wH[3];
        }
      }
      Mg() {
        return null;
      }
      jh(a) {
        var b = mj(B(this.G, XB, 2).oa());
        b = b.S() / b.R();
        a = a.S() / a.R();
        return Math.min(a / b, 1);
      }
    },
    pt = Y(),
    uH = Y(),
    vH = Y(),
    wH = At(),
    yH = Ct(),
    zH = Ct(),
    tH = new Fv();
  function sH(a, b) {
    It(b);
    a = qH(a);
    Bv(a, b, b, !0);
    Pt(yH, a.Kb, a.S() / a.R(), a.Tb, a.Sb);
    Tt(zH, -a.Va(), -a.za(), -a.ac);
    Jt(yH, zH, yH);
    var c = 1 / a.Ub;
    St(yH, c * (a.cb - a.Pa), c * (a.eb - a.Qa), c * (a.fb - a.Ra));
    Jt(yH, b, b);
    Kt(b, b);
    St(b, -1, 1, -1);
    Ut(b, 2, -2, 2);
  }
  var AH = class extends LB {
    constructor(a, b) {
      super(a);
      this.config = null;
      this.C = new U();
      this.D = new xH();
      this.Jb(b);
    }
    Za() {
      return this.config;
    }
    Xa() {
      return this.C;
    }
    xa() {
      return this.D;
    }
    Ud() {
      return null;
    }
    Rb() {}
    Qb(a) {
      this.config = a;
      var b = new UA(),
        c = Z(this.Ia());
      y(b, c);
      a = a.Hc();
      c = !1;
      !E(b, 4) && E(a, 5) && (Q(b, 4, E(a, 5)), (c = !0));
      if (
        df(b, JA, 19) === 0 &&
        Sf(a, 1) &&
        Ff(a, 1, 1) === 2 &&
        E(a, 3) &&
        E(a, 4)
      ) {
        c = !0;
        let d = GA(IA(Bf(b, 19, JA)), E(b, 4));
        bf(b, 4);
        FA(
          d,
          `https://picasaweb.google.com/lh/sredir?target=PHOTO&uname=${E(
            a,
            3
          )}&id=${E(a, 2)}`
        );
        FA(
          GA(IA(Bf(b, 19, JA)), E(a, 4)),
          "https://picasaweb.google.com/" + E(a, 3)
        );
      }
      c && this.Jb(b);
      IB(this, 3);
    }
    Ab() {
      return super.Ab();
    }
  };
  function BH(a, b, c) {
    var d = UB,
      e = nA(b);
    d = new tC(a.B, e, d);
    e = new fC(e, a.P);
    e = new CC(e, d, a.H);
    a = new ZG(e, b, a.C);
    var f = new by();
    a.get((g) => {
      $x(f, g);
    }, c);
    return f;
  }
  function CH(a) {
    if (!a.M) {
      let b = null,
        c = ks(a.A);
      E(c, 5) && (b = DH(a));
      a.M = new vC(a.B, a.H, hf(c, 4, ee), b, a.C);
    }
    return a.M;
  }
  function EH(a, b, c) {
    var d = ks(a.A);
    d = E(d, 5) ? DH(a) : a.aa;
    fA(b);
    a: {
      let f = zl(b.Y());
      if (Sf(f, 1) && Sf(f, 2))
        switch (f.Oa()) {
          case 1:
            if (ml(f) === 4) c = FH(a);
            else {
              var e;
              if ((e = ml(f) === 3)) (e = B(f, fl, 9)), (e = Rf(e, 1));
              c = e && !hA(b) ? new mH(GH(a)) : HH(a, c);
            }
            break a;
          case 2:
            ml(f) === 3
              ? a.D
                ? (a.O || (a.O = new nH(a.T, is(ks(a.A)))), (c = new mH(a.O)))
                : (a.I ||
                    ((c = a.F),
                    (e = ks(a.A)),
                    (e = hf(e, 2, ee)),
                    (a.I = new gH(c, e))),
                  (c = new mH(a.I)))
              : (c = a.D ? IH(a) : JH(a));
            break a;
          case 10:
          case 8:
          case 3:
            c = ml(f) === 4 ? FH(a) : new mH(GH(a));
            break a;
        }
      e = fA(b);
      c =
        e === 1 || e === 2 || e === 11 || e === 13 || e === 5 || e === 4
          ? a.D
            ? IH(a)
            : JH(a)
          : e === 3
          ? a.D
            ? new mH(IH(a))
            : new mH(JH(a))
          : e === 12 || e === 15
          ? new mH(GH(a))
          : e === 27
          ? HH(a, c)
          : null;
    }
    fA(b);
    return d && c ? new CC(d, c, a.H) : null;
  }
  function FH(a) {
    a.L || (a.L = new jH());
    return a.L;
  }
  function GH(a) {
    if (!a.K) {
      var b = a.F;
      var c = ks(a.A);
      c = hf(c, 4, ee);
      a.K = new hH(b, c, a.C);
    }
    return a.K;
  }
  function HH(a, b) {
    if (!a.G) {
      a.G = new lH(a.B);
      let c = (d) => {
        switch (d.type) {
          case "Success":
            var e = kz;
            break;
          case "Failure":
            e = jz;
        }
        a.Z.te(e);
      };
      a.G.get((d) => {
        Fu(d, "Success", c);
        Fu(d, "Failure", c);
      }, b);
    }
    return a.G;
  }
  function IH(a) {
    a.V || (a.V = new oH(a.T, is(ks(a.A))));
    return a.V;
  }
  function JH(a) {
    if (!a.J) {
      var b = a.F;
      var c = ks(a.A);
      c = hf(c, 2, ee);
      a.J = new vA(b, c);
    }
    return a.J;
  }
  function DH(a) {
    if (!a.N) {
      let b = ks(a.A);
      a.N = new oD(
        E(b, 5),
        E(b, 6),
        C(a.A, 6),
        a.B,
        Rf(a.A, 7) ? E(a.A, 7) : "maps_sv.tactile",
        a.W,
        z(a.A, 8) ? B(a.A, Ck, 8) : null,
        a.P
      );
    }
    return a.N;
  }
  var LH = class {
    constructor(a, b, c, d, e, f, g = !1) {
      this.B = a;
      this.H = b;
      this.A = c;
      this.W = d;
      this.Z = e;
      this.C = f;
      this.P = g;
      this.L =
        this.G =
        this.K =
        this.M =
        this.V =
        this.O =
        this.J =
        this.I =
          null;
      this.aa = new iH();
      this.N = null;
      this.F = new rC(this.B);
      this.T =
        (this.D = !!is(ks(this.A))) && C(this.A, 10)
          ? new rC(this.B, "use-credentials")
          : this.F;
    }
    clear() {}
    Wd(a, b) {
      if (VB(nA(a))) return BH(this, a, b);
      var c = aA(a),
        d = oA(a);
      if (c && $B(d)) {
        c = CH(this);
        let e = new by();
        c.get((f, g) => {
          $x(e, f.Wd(a, g));
        }, b);
        return e;
      }
      d = EH(this, a, b);
      if (!d) return null;
      if (eA(a)) {
        c = new kH(d, a, this.C, KH(a));
        let e = new pH();
        c.get((f) => {
          $x(e, f);
        }, b);
        return e;
      }
      if (c) {
        c = new ZG(d, a, this.C);
        let e = new by();
        c.get((f) => {
          $x(e, f);
        }, b);
        return e;
      }
      return gA(a) ? new AH(d, a) : null;
    }
  };
  function KH(a) {
    var b = zl(a.Y());
    if (Sf(b, 1) && Sf(b, 2))
      switch (b.Oa()) {
        case 2:
          return ml(b) === 3 ? [0, 0, 0, 0, 85, 320, 512, 768, 1024] : [];
        case 1:
        case 8:
        case 3:
        case 10:
          return [1024, 2048, 3072];
      }
    a = fA(a);
    return a === 12 || a === 15
      ? [1024, 2048, 3072]
      : a === 3
      ? [0, 0, 0, 0, 85, 320, 512, 768, 1024]
      : [];
  }
  function MH(a, b, c, d, e, f, g = !1) {
    a = new LH(a, b, c, d, e, f, g);
    return new fH(a);
  }
  function NH(a) {
    return !!xb(a, (b) => {
      var c;
      if ((c = !!b.Ia()))
        (b = Z(b.Ia()))
          ? ((c = zl(b.Y())),
            (b = Sf(c, 1) ? zl(b.Y()).Oa() === 1 : qA(b) === 7))
          : (b = !1),
          (c = b);
      return c;
    });
  }
  function OH(a) {
    if (a.F) return a.F;
    var b = a.C ? a.C : a.D;
    PH(a, b);
    return b;
  }
  function PH(a, b) {
    a.F && a.F !== b && a.F.Ha() && a.F.ka().clear();
    a.F = b;
    b = a.F === a.C;
    a.I &&
      ((a.I.A.style.display = b ? "" : "none"),
      b && a.G && a.G.contains(document.activeElement) && a.I.A.focus());
    if (a.G) {
      a.G.style.display = b ? "none" : "";
      let c = b ? "0" : "100%";
      Ys(a.G, c, c);
      !b && a.I && document.activeElement === a.I.A && a.G.focus();
    }
  }
  var QH = class extends Su {
    constructor(a, b, c, d, e, f) {
      super();
      this.C = b;
      this.I = c;
      this.D = d;
      this.G = e;
      this.H = !1;
      this.T = new U();
      this.A = new Ss(0, 0, 0, 0);
      this.P = 0;
      this.O = !1;
      this.F = null;
      this.L = !1;
      if (this.C)
        this.C.onLoad((g, h) => {
          this.L && (g.qc(h), (this.L = !1));
          Fu(g, "ViewportReady", () => {
            this.C === OH(this) &&
              ((this.H = !0),
              this.dispatchEvent(new ru("ViewportReady", this)));
          });
          this.O && (Ix(a), (this.O = !1));
        }, f);
      if (this.D)
        this.D.onLoad((g, h) => {
          this.L && (g.qc(h), (this.L = !1));
          Fu(g, "ViewportReady", () => {
            this.D === OH(this) &&
              ((this.H = !0),
              this.dispatchEvent(new ru("ViewportReady", this)));
          });
          this.O && (Ix(a), (this.O = !1));
        }, f);
    }
    setCamera(a, b) {
      y(this.T, a);
      OH(this).get((c, d) => {
        c.setCamera(this.T, d);
      }, b);
    }
    bd(a, b, c) {
      if (a.length) {
        var d = NH(a) ? this.D || this.C : this.C || this.D;
        PH(this, d);
        OH(this).get((e, f) => {
          e.setCamera(this.T, f);
          e.Ib(this.P, f);
          e.Ta(this.A.top, this.A.right, this.A.bottom, this.A.left, f);
          e.bd(a, f, c);
        }, b);
      }
    }
    Hb(a, b, c, d) {
      OH(this).get((e, f) => {
        e.Hb(a, f, c, d);
      }, b);
    }
    clear() {
      this.C && this.C.Ha() && this.C.ka().clear();
      this.D && this.D.Ha() && this.D.ka().clear();
    }
    run() {
      this.H = !1;
      var a = OH(this);
      a.Ha() ? a.ka().run() : (this.O = !0);
    }
    qc(a) {
      this.H = !1;
      var b = OH(this);
      b.Ha() ? b.ka().qc(a) : (this.L = !0);
    }
    Ta(a, b, c, d, e) {
      this.A.top = a;
      this.A.right = b;
      this.A.bottom = c;
      this.A.left = d;
      OH(this).get((f, g) => {
        f.Ta(this.A.top, this.A.right, this.A.bottom, this.A.left, g);
        f.run();
      }, e);
    }
    mb() {
      var a = OH(this);
      return a.Ha() ? a.ka().mb() : new Ss(0, 0, 0, 0);
    }
    Ob() {
      return this.H;
    }
    Ib(a, b) {
      this.P = a;
      OH(this).get((c, d) => {
        c.Ib(this.P, d);
      }, b);
    }
  };
  var RH = class extends QH {
    Fe(a, b, c) {
      var d = OH(this);
      return d.Ha() ? d.ka().Fe(a, b, c) : null;
    }
    Vd(a, b, c) {
      var d = OH(this);
      return d.Ha() ? d.ka().Vd(a, b, c) : null;
    }
    Tc(a, b) {
      var c = OH(this);
      return c.Ha() ? c.ka().Tc(a, b) : 500;
    }
    Cd(a, b) {
      var c = OH(this);
      c.Ha() && c.ka().Cd(a, b);
    }
    Ad(a) {
      var b = OH(this);
      b.Ha() ? b.ka().Ad(a) : ((a[0] = 1), (a[1] = 179));
    }
    Ja() {}
  };
  var SH = class extends dz {
    constructor(a, b, c) {
      super("WPNR", [...arguments]);
    }
  };
  function TH(a, b, c, d, e) {
    var f = b.canvas;
    b = b.A;
    c = new SH(a, c, e);
    e = new UD(a, b, e);
    return new RH(a, c, f, e, b, d);
  }
  function UH(a, b, c, d, e) {
    b = b.A;
    e = new UD(a, b, e);
    return new RH(a, c, null, e, b, d);
  }
  function VH(a, b, c, d, e) {
    var f = b.canvas;
    b = b.A;
    c = new ez(a, c, Js(document, "CANVAS"), e);
    e = new UD(a, b, e);
    return new RH(a, c, f, e, b, d);
  }
  function WH(a, b, c, d, e) {
    b = b.canvas;
    e = new UD(a, c, e);
    return new RH(a, null, b, e, c, d);
  }
  var XH = class extends dz {
    constructor(a, b, c, d, e, f, g, h, k, l) {
      super("IPR", [...arguments]);
    }
  };
  function YH(a) {
    for (var b = a.tail; b && (a.A[0] > a.B[0] || a.A[1] > a.B[1]); ) {
      let c = b;
      b = b.A;
      if (
        (a.A[0] > a.B[0] && c.B > 0) ||
        (a.A[1] > a.B[1] && c.C > 0) ||
        (c.B === 0 && c.C === 0)
      )
        c.D && c.D.call(c.F, c.handle, c.item, !1), a.remove(c.handle);
    }
  }
  var $H = class {
    constructor() {
      this.A = [0, 0];
      this.C = 0;
      this.tail = this.head = null;
      this.entries = {};
      this.B = [0, 0];
    }
    add(a, b, c, d, e = null) {
      c = c || 0;
      d = d || 0;
      if (c > this.B[0] || d > this.B[1]) return -1;
      var f = this.C++;
      a = new ZH(f, a, b, e, this.head, c, d);
      this.entries[f] = a;
      this.head && (this.head.A = a);
      this.head = a;
      this.A[0] += c;
      this.A[1] += d;
      this.tail === null && (this.tail = a);
      YH(this);
      return f;
    }
    get(a) {
      return (a = this.entries[a]) ? a.item : void 0;
    }
    remove(a) {
      var b = this.entries[a];
      b &&
        (b.A ? (b.A.next = b.next) : (this.head = b.next),
        b.next ? (b.next.A = b.A) : (this.tail = b.A),
        (b.A = b.next = b.item = null),
        (b.handle = -1),
        delete this.entries[a],
        (this.A[0] -= b.B),
        (this.A[1] -= b.C));
    }
    resize(a, b, c) {
      var d = this.entries[a];
      if (!d) return !1;
      b = b !== void 0 ? b : d.B;
      c = c !== void 0 ? c : d.C;
      if (b > this.B[0] || c > this.B[1])
        return d.D.call(d.F, a, d.item, !1), this.remove(a), !1;
      this.A[0] -= d.B;
      this.A[1] -= d.C;
      d.B = b;
      d.C = c;
      this.A[0] += d.B;
      this.A[1] += d.C;
      YH(this);
      return d.handle !== -1;
    }
    contains(a) {
      return a in this.entries;
    }
    clear() {
      for (; this.head; ) {
        let a = this.head;
        a.D.call(a.F, a.handle, a.item, !0);
        this.remove(a.handle);
      }
      Object.keys(this.entries);
    }
  };
  class ZH {
    constructor(a, b, c, d, e, f, g) {
      this.handle = a;
      this.item = b;
      this.D = c;
      this.F = d;
      this.A = null;
      this.next = e;
      this.B = f;
      this.C = g;
    }
  }
  function aI() {
    var a = new bI(),
      b = new Float32Array(150);
    for (let c = 0; c < 50; c++)
      (b[c * 3 + 0] = Math.sin(Math.PI * 2 * (c / 50))),
        (b[c * 3 + 1] = Math.cos(Math.PI * 2 * (c / 50))),
        (b[c * 3 + 2] = 0);
    a.vertices = b;
    return a;
  }
  function cI() {
    return dI(1, 1, -0.5, -0.5);
  }
  function dI(a, b, c = 0, d = 0) {
    var e = new bI();
    a = new Float32Array([c, d + b, 0, c + a, d + b, 0, c + a, d, 0, c, d, 0]);
    e.vertices = a;
    return e;
  }
  function eI(a) {
    return a.transform.hidden || (a.C[3] === 0 && (!a.A || a.A[3] === 0));
  }
  function fI(a) {
    return a.transform.A;
  }
  function gI(a, b, c, d) {
    var e = hI;
    a: {
      let g = -Infinity,
        h = Infinity;
      var f = -Infinity;
      let k = Infinity;
      if (eI(a)) b = Infinity;
      else {
        Jt(e, fI(a), e);
        for (let l = 0; l < a.vertices.length / 3; l++) {
          iI[0] = a.vertices[3 * l + 0];
          iI[1] = a.vertices[3 * l + 1];
          iI[2] = a.vertices[3 * l + 2];
          iI[3] = 1;
          Nt(e, iI, iI);
          if (iI[3] < 0) {
            b = Infinity;
            break a;
          }
          vt(iI, 1 / iI[3], iI);
          Lt(d, iI, iI);
          iI[0] < h && (h = iI[0]);
          iI[1] < k && (k = iI[1]);
          iI[0] > g && (g = iI[0]);
          iI[1] > f && (f = iI[1]);
        }
        b <= g && b >= h && c <= f && c >= k
          ? ((a = (h + g) / 2),
            (f = (k + f) / 2),
            (b = Math.sqrt((b - a) * (b - a) + (c - f) * (c - f))))
          : (b = Infinity);
      }
    }
    return b < Infinity;
  }
  function jI(a) {
    var b = Y(),
      c = fI(a);
    for (let d = 0; d < a.vertices.length / 3; d++)
      (b[0] = a.vertices[3 * d + 0]),
        (b[1] = a.vertices[3 * d + 1]),
        (b[2] = a.vertices[3 * d + 2]),
        Lt(c, b, b),
        (a.vertices[3 * d + 0] = b[0]),
        (a.vertices[3 * d + 1] = b[1]),
        (a.vertices[3 * d + 2] = b[2]);
    It(fI(a));
  }
  function kI(a, b) {
    for (let c = 0; c < b.length; c++) {
      let d = b[c];
      Jt(fI(d), fI(a), fI(d));
      jI(d);
      d.transform = a.transform;
    }
  }
  function lI(a, b) {
    a.C[0] = b[0];
    a.C[1] = b[1];
    a.C[2] = b[2];
    a.C[3] = b[3];
  }
  function mI(a, b) {
    Ut(fI(a), b, b, b);
  }
  function nI(a, b) {
    var c = a.vertices.length;
    a.D = b.ca.createBuffer();
    a.F = oI(
      b.A,
      () => {
        var d = a.D;
        d && b.deleteBuffer(d);
        a.D = null;
      },
      c
    );
    pI(b, 34962, a.D);
    b.ca.bufferData(34962, a.vertices, 35044);
  }
  var bI = class extends Su {
      constructor() {
        super(...arguments);
        this.vertices = new Float32Array(0);
        this.C = [1, 1, 1, 1];
        this.A = null;
        this.transform = new qI();
        this.F = -1;
        this.D = null;
      }
      lookAt(a, b, c) {
        Qt(fI(this), a, b, c);
        Kt(fI(this), fI(this));
      }
      scale(a, b, c) {
        Ut(fI(this), a, b, c);
      }
      translate(a, b, c) {
        St(fI(this), a, b, c);
      }
      rotate(a, b, c, d) {
        var e = fI(this),
          f = e[0],
          g = e[1],
          h = e[2],
          k = e[3],
          l = e[4],
          m = e[5],
          n = e[6],
          q = e[7],
          r = e[8],
          t = e[9],
          v = e[10],
          F = e[11],
          H = Math.cos(a),
          I = Math.sin(a),
          J = 1 - H;
        a = b * b * J + H;
        var ja = b * c * J + d * I,
          ua = b * d * J - c * I,
          ka = b * c * J - d * I,
          ya = c * c * J + H,
          ma = c * d * J + b * I,
          L = b * d * J + c * I;
        b = c * d * J - b * I;
        d = d * d * J + H;
        e[0] = f * a + l * ja + r * ua;
        e[1] = g * a + m * ja + t * ua;
        e[2] = h * a + n * ja + v * ua;
        e[3] = k * a + q * ja + F * ua;
        e[4] = f * ka + l * ya + r * ma;
        e[5] = g * ka + m * ya + t * ma;
        e[6] = h * ka + n * ya + v * ma;
        e[7] = k * ka + q * ya + F * ma;
        e[8] = f * L + l * b + r * d;
        e[9] = g * L + m * b + t * d;
        e[10] = h * L + n * b + v * d;
        e[11] = k * L + q * b + F * d;
      }
    },
    iI = At();
  class qI {
    constructor() {
      this.hidden = !1;
      var a = Ct();
      a[0] = a[5] = a[10] = a[15] = 1;
      this.A = a;
    }
  }
  function rI(a, b = []) {
    return { ui: a, xi: b };
  }
  function sI(a, b) {
    for (let c of a.xi) sI(c, b);
    for (let c of a.ui) b(c);
  }
  function tI(a) {
    sI(a, (b) => {
      jI(b);
    });
  }
  function uI(a) {
    sI(a, (b) => {
      b.scale(-1, 1, 1);
    });
  }
  function vI(a, b, c, d) {
    sI(a, (e) => {
      e.scale(1.5, 1.5, 1.5);
      e.translate(b, c, 0);
      Xt(fI(e), Bo(d));
    });
  }
  function wI(a) {
    var b = [];
    sI(a, (c) => {
      var d = new bI(),
        e = new Float32Array(Array.from(c.vertices));
      d.vertices = e;
      lI(d, c.C.slice());
      Dt(fI(d), fI(c));
      b.push(d);
    });
    return rI(b);
  }
  function xI(a) {
    var b = new bI();
    a = new Float32Array(a);
    b.vertices = a;
    lI(b, yI);
    return b;
  }
  var yI = [1, 1, 1, 1];
  function zI(a, b, c, d, e) {
    a = Bo(a);
    b = Bo(b);
    var f = b - a,
      g = (b + a) / 2,
      h = f / e / 2,
      k = a,
      l = [],
      m = [c * Math.sin(a), c * Math.cos(a), 0];
    for (let n = 0; n <= e; n++)
      m.push(d * Math.sin(k), d * Math.cos(k), 0), (k += h);
    l.push(xI(m));
    b = [c * Math.sin(b), c * Math.cos(b), 0];
    k = g;
    for (m = 0; m <= e; m++)
      b.push(d * Math.sin(k), d * Math.cos(k), 0), (k += h);
    l.push(xI(b));
    if (c) {
      d = [d * Math.sin(g), d * Math.cos(g), 0];
      f /= e;
      k = a;
      for (a = 0; a <= e; a++)
        d.push(c * Math.sin(k), c * Math.cos(k), 0), (k += f);
      l.push(xI(d));
    }
    return rI(l);
  }
  var AI = Y(),
    BI = Y(),
    CI = Y();
  function DI(a, b) {
    du(Xi(a), Zi(a), 0, AI);
    du(Xi(a), Zi(a) + 1e-5, 0, BI);
    st(CI, AI);
    xt(CI, CI);
    Qt(b, AI, BI, CI);
    Kt(b, b);
  }
  function EI(a) {
    var b = a[0],
      c = a[1],
      d = a[2];
    a = a[3];
    return (
      (a <= 0 ? 1 : 0) |
      ((b > +a ? 1 : 0) << 1) |
      ((b < -a ? 1 : 0) << 2) |
      ((c > +a ? 1 : 0) << 3) |
      ((c < -a ? 1 : 0) << 4) |
      ((d > +a ? 1 : 0) << 5) |
      ((d < -a ? 1 : 0) << 6)
    );
  }
  function FI(a) {
    var b = GI(a.A);
    a = a.name;
    var c = b.J[a];
    c === void 0 && ((c = b.A.getAttribLocation(b.F, a)), (b.J[a] = c));
    return c;
  }
  function HI(a, b) {
    var c = a.A.getContext();
    a = FI(a);
    c.ca.vertexAttribPointer(a, b, 5126, !1, 0, 0);
  }
  var II = class {
    constructor(a, b) {
      this.name = a;
      this.A = b;
    }
  };
  var JI = class {
    constructor() {
      this.K = !1;
      this.D = this.B = null;
    }
    M() {
      return this.K;
    }
    dispose() {
      if (!this.K) {
        this.K = !0;
        this.J();
        if (this.B) {
          for (var a = 0; a < this.B.length; ++a) this.B[a].dispose();
          this.B = null;
        }
        if (this.D) {
          for (a = 0; a < this.D.length; ++a) this.D[a]();
          this.D = null;
        }
      }
    }
    J() {}
  };
  function KI(a) {
    a.D = !0;
    a.J = {};
    a.C = [];
    a.B = [];
    a.G = {};
    var b = a.A.getProgramParameter(a.F, 35718),
      c = 0;
    for (let e = 0; e < b; ++e) {
      let f = a.A.getActiveUniform(a.F, e);
      if (f.name.indexOf("[") >= 0) {
        let g = f.name.substring(0, f.name.indexOf("[")),
          h = f.size;
        a.G[g] = c;
        for (let k = 0; k < h; ++k) {
          var d = c++;
          let l = `${g}[${k}]`;
          a.G[l] = d;
          a.K[d] = h - k;
          a.C[d] = a.A.getUniformLocation(a.F, l);
          a.B[d] = LI(f.type);
        }
      } else
        (d = c++),
          (a.G[f.name] = d),
          (a.K[d] = 0),
          (a.C[d] = a.A.getUniformLocation(a.F, f.name)),
          (a.B[d] = LI(f.type));
    }
  }
  var MI = class {
    constructor(a) {
      this.M = a;
      this.O = [];
      this.I = !1;
      this.D = !0;
      this.C = [];
      this.K = [];
      this.B = [];
      this.G = {};
      this.J = {};
      this.A = a.ca;
      this.F = this.A.createProgram();
    }
    ec() {
      this.M.Dc !== this && ((this.M.Dc = this), this.A.useProgram(this.F));
    }
    Eb() {
      return !this.I && this.A.isProgram(this.F);
    }
    validate() {
      this.A.validateProgram(this.F);
    }
    H(a, b) {
      this.D || KI(this);
      var c = this.C,
        d = this.B,
        e = this.A;
      a !== -1 && b !== d[a] && ((d[a] = b), e.uniform1f(c[a], b));
    }
    N(a, b) {
      this.D || KI(this);
      if (a !== -1) {
        var c = !1,
          d;
        for (d = 0; !c && d < b.length / 2; ++d)
          (c = this.B[a + d]), (c = b[2 * d] !== c[0] || b[2 * d + 1] !== c[1]);
        if (c) {
          for (d = 0; d < b.length / 2; ++d)
            (c = this.B[a + d]), (c[0] = b[2 * d]), (c[1] = b[2 * d + 1]);
          this.A.uniform2fv(this.C[a], b);
        }
      }
    }
    L(a, b) {
      this.D || KI(this);
      if (a !== -1) {
        var c = !1,
          d;
        for (d = 0; !c && d < b.length / 3; ++d)
          (c = this.B[a + d]),
            (c =
              b[3 * d] !== c[0] ||
              b[3 * d + 1] !== c[1] ||
              b[3 * d + 2] !== c[2]);
        if (c) {
          for (d = 0; d < b.length / 3; ++d)
            (c = this.B[a + d]),
              (c[0] = b[3 * d]),
              (c[1] = b[3 * d + 1]),
              (c[2] = b[3 * d + 2]);
          this.A.uniform3fv(this.C[a], b);
        }
      }
    }
  };
  function LI(a) {
    switch (a) {
      case 35670:
        return !1;
      case 5124:
      case 5126:
      case 35678:
      case 35680:
        return 0;
      case 35664:
        return new Float32Array(2);
      case 35667:
        return new Int32Array(2);
      case 35671:
        return [!1, !1];
      case 35665:
        return new Float32Array(3);
      case 35668:
        return new Int32Array(3);
      case 35672:
        return [!1, !1, !1];
      case 35666:
        return new Float32Array(4);
      case 35669:
        return new Int32Array(4);
      case 35673:
        return [!1, !1, !1, !1];
      case 35674:
        return new Float32Array(4);
      case 35675:
        return new Float32Array(9);
      case 35676:
        return new Float32Array(16);
      default:
        return null;
    }
  }
  function NI(a) {
    pu.call(this);
    this.F = a;
    this.A = {};
  }
  Ea(NI, pu);
  var OI = [];
  NI.prototype.listen = function (a, b, c, d) {
    return PI(this, a, b, c, d);
  };
  function PI(a, b, c, d, e, f) {
    Array.isArray(c) || (c && (OI[0] = c.toString()), (c = OI));
    for (let g = 0; g < c.length; g++) {
      let h = Fu(b, c[g], d || a.handleEvent, e || !1, f || a.F || a);
      if (!h) break;
      a.A[h.key] = h;
    }
    return a;
  }
  NI.prototype.N = function (a, b, c, d, e) {
    if (Array.isArray(b))
      for (let f = 0; f < b.length; f++) this.N(a, b[f], c, d, e);
    else
      (c = c || this.handleEvent),
        (d = ra(d) ? !!d.capture : !!d),
        (e = e || this.F || this),
        (c = Hu(c)),
        (d = !!d),
        (b = uu(a)
          ? Bu(a.J, String(b), c, d, e)
          : a
          ? (a = Ju(a))
            ? Bu(a, b, c, d, e)
            : null
          : null),
        b && (Ou(b), delete this.A[b.key]);
  };
  function QI(a) {
    Gm(
      a.A,
      function (b, c) {
        this.A.hasOwnProperty(c) && Ou(b);
      },
      a
    );
    a.A = {};
  }
  NI.prototype.B = function () {
    NI.qa.B.call(this);
    QI(this);
  };
  NI.prototype.handleEvent = function () {
    throw Error("EventHandler.handleEvent not implemented");
  };
  function RI(a, b, c) {
    c = a.ca.createShader(c);
    a.ca.shaderSource(c, b);
    a.ca.compileShader(c);
    return c;
  }
  function GI(a) {
    a.A || SI(a);
    return a.A;
  }
  function SI(a) {
    var b = RI(a.context, a.H, 35633),
      c = RI(a.context, a.F, 35632);
    a.A = new MI(a.context);
    var d = a.A;
    d.O.push(b);
    d.A.attachShader(d.F, b);
    b = a.A;
    b.O.push(c);
    b.A.attachShader(b.F, c);
    a = a.A;
    a.A.linkProgram(a.F);
    a.D = !1;
  }
  var TI = class extends JI {
    constructor(a, b, c) {
      super();
      this.context = a;
      this.H = b;
      this.F = c;
      this.A = null;
      this.C = 0;
      a = new NI();
      this.B || (this.B = []);
      this.B.push(a);
      PI(a, this.context.canvas, "webglcontextrestored", this.G, !1, this);
    }
    G() {
      this.A = null;
    }
    getContext() {
      return this.context;
    }
    Eb() {
      if (this.C === 0) {
        this.A || SI(this);
        var a = this.A;
        this.C = a.A.getProgramParameter(a.F, 35714) ? 1 : -1;
      }
      return this.C === 1;
    }
  };
  function UI(a) {
    var b = GI(a.A);
    a = a.name;
    b.D || KI(b);
    return b.G[a] !== void 0 ? b.G[a] : -1;
  }
  var VI = class {
      constructor(a, b) {
        this.name = a;
        this.A = b;
      }
    },
    WI = class extends VI {
      set(a) {
        var b = GI(this.A),
          c = UI(this);
        b.D || KI(b);
        var d = b.C,
          e = b.B;
        b = b.A;
        if (c !== -1) {
          var f = e[c],
            g = a;
          typeof f === "boolean" && (g = !!a);
          g !== f && ((e[c] = g), b.uniform1i(d[c], a));
        }
      }
    },
    XI = class extends VI {
      set(a) {
        GI(this.A).H(UI(this), a);
      }
    },
    YI = class extends VI {
      set(a, b) {
        var c = GI(this.A),
          d = UI(this);
        c.D || KI(c);
        var e = c.C,
          f = c.A;
        d !== -1 &&
          ((c = c.B[d]), a !== c[0] || b !== c[1]) &&
          ((c[0] = a), (c[1] = b), f.uniform2f(e[d], a, b));
      }
    },
    ZI = class extends VI {
      set(a, b, c) {
        var d = GI(this.A),
          e = UI(this);
        d.D || KI(d);
        var f = d.C,
          g = d.A;
        e !== -1 &&
          ((d = d.B[e]), a !== d[0] || b !== d[1] || c !== d[2]) &&
          ((d[0] = a), (d[1] = b), (d[2] = c), g.uniform3f(f[e], a, b, c));
      }
    };
  function $I(a, b) {
    var c = GI(a.A);
    a = UI(a);
    c.D || KI(c);
    if (a !== -1) {
      var d = !1,
        e;
      for (e = 0; !d && e < b.length / 4; ++e)
        (d = c.B[a + e]),
          (d =
            b[4 * e] !== d[0] ||
            b[4 * e + 1] !== d[1] ||
            b[4 * e + 2] !== d[2] ||
            b[4 * e + 3] !== d[3]);
      if (d) {
        for (e = 0; e < b.length / 4; ++e)
          (d = c.B[a + e]),
            (d[0] = b[4 * e]),
            (d[1] = b[4 * e + 1]),
            (d[2] = b[4 * e + 2]),
            (d[3] = b[4 * e + 3]);
        c.A.uniform4fv(c.C[a], b);
      }
    }
  }
  var aJ = class extends VI {
    set(a, b, c, d) {
      var e = GI(this.A),
        f = UI(this);
      e.D || KI(e);
      var g = e.C,
        h = e.A;
      f !== -1 &&
        ((e = e.B[f]), a !== e[0] || b !== e[1] || c !== e[2] || d !== e[3]) &&
        ((e[0] = a),
        (e[1] = b),
        (e[2] = c),
        (e[3] = d),
        h.uniform4f(g[f], a, b, c, d));
    }
  };
  function bJ(a, b) {
    var c = GI(a.A);
    a = UI(a);
    c.D || KI(c);
    if (a !== -1) {
      var d = !1,
        e;
      for (e = 0; !d && e < b.length / 16; ++e) {
        d = 16 * e;
        var f = c.B[a + e];
        d =
          b[d] !== f[0] ||
          b[d + 1] !== f[1] ||
          b[d + 2] !== f[2] ||
          b[d + 3] !== f[3] ||
          b[d + 4] !== f[4] ||
          b[d + 5] !== f[5] ||
          b[d + 6] !== f[6] ||
          b[d + 7] !== f[7] ||
          b[d + 8] !== f[8] ||
          b[d + 9] !== f[9] ||
          b[d + 10] !== f[10] ||
          b[d + 11] !== f[11] ||
          b[d + 12] !== f[12] ||
          b[d + 13] !== f[13] ||
          b[d + 14] !== f[14] ||
          b[d + 15] !== f[15];
      }
      if (d) {
        for (e = 0; e < b.length / 16; ++e) {
          f = c.B[a + e];
          d = 16 * e;
          for (let g = 0; g < 16; ++g) f[g] = b[d + g];
        }
        c.A.uniformMatrix4fv(c.C[a], !1, b);
      }
    }
  }
  var cJ = class extends VI {};
  var fJ = class extends TI {
      constructor(a) {
        super(
          a,
          "varying vec2 a;varying float b;uniform mat4 matrixClipFromModel;uniform vec2 modelToPixelScale,iconSize;attribute vec3 vert;uniform vec3 pivot;uniform float opacity,texCoordOffset,texCoordScale;void main(){a=.5*vert.xy+.5;a.y=texCoordScale*a.y+texCoordOffset;gl_Position=matrixClipFromModel*vec4(pivot,1);if(gl_Position.z<-gl_Position.w)b=0.;else b=opacity;gl_Position=vec4(gl_Position.x/gl_Position.w+vert.x*modelToPixelScale.x,gl_Position.y/gl_Position.w+vert.y*modelToPixelScale.y,0,1);}",
          "precision highp float;varying vec2 a;varying float b;uniform sampler2D iconSampler;void main(){if(b==0.)discard;gl_FragColor=texture2D(iconSampler,a);gl_FragColor.w*=b;}"
        );
        this.uniforms = new dJ(this);
        this.attributes = new eJ(this);
      }
    },
    dJ = class {
      constructor(a) {
        this.A = new cJ("matrixClipFromModel", a);
        this.C = new YI("modelToPixelScale", a);
        this.D = new ZI("pivot", a);
        this.opacity = new XI("opacity", a);
        this.F = new XI("texCoordOffset", a);
        this.G = new XI("texCoordScale", a);
        this.B = new WI("iconSampler", a);
      }
    },
    eJ = class {
      constructor(a) {
        this.A = new II("vert", a);
      }
    };
  var iJ = class extends TI {
      constructor(a) {
        super(
          a,
          "varying vec4 a;uniform mat4 matrixClipFromModel;uniform vec4 color;attribute vec3 vert;void main(){a=color;gl_Position=matrixClipFromModel*vec4(vert,1);}",
          "precision highp float;varying vec4 a;void main(){gl_FragColor=a;}"
        );
        this.uniforms = new gJ(this);
        this.attributes = new hJ(this);
      }
    },
    gJ = class {
      constructor(a) {
        this.A = new cJ("matrixClipFromModel", a);
        this.color = new aJ("color", a);
      }
    },
    hJ = class {
      constructor(a) {
        this.A = new II("vert", a);
      }
    };
  function jJ(a, b, c, d) {
    var e = a.A;
    try {
      a: {
        try {
          let g = Math.max(c * b, 1),
            h = Math.max(d * b, 1);
          $b || Kb
            ? ((g = Math.round(g)), (h = Math.round(h)))
            : ((g = Math.floor(g)), (h = Math.floor(h)));
          if (e.width === g && e.height === h) {
            var f = !1;
            break a;
          }
          e.width = g;
          e.height = h;
        } catch (g) {
          wv(Error("setCanvasSize: Error accessing canvas.", { cause: g }), {
            errorType: 17,
          });
        }
        f = !0;
      }
      if (f || b !== a.C)
        (e.style.width = `${c}px`), (e.style.height = `${d}px`);
    } finally {
      a.C = b;
    }
  }
  function kJ(a, b, c, d, e, f) {
    if (arguments.length == 6) lJ(this, a, b, c, d, e, f);
    else {
      if (arguments.length != 0) throw Error("Insufficient matrix parameters");
      this.B = this.F = 1;
      this.A = this.C = this.D = this.G = 0;
    }
  }
  p = kJ.prototype;
  p.clone = function () {
    return new kJ(this.B, this.A, this.C, this.F, this.D, this.G);
  };
  function lJ(a, b, c, d, e, f, g) {
    if (
      typeof b !== "number" ||
      typeof c !== "number" ||
      typeof d !== "number" ||
      typeof e !== "number" ||
      typeof f !== "number" ||
      typeof g !== "number"
    )
      throw Error("Invalid transform parameters");
    a.B = b;
    a.A = c;
    a.C = d;
    a.F = e;
    a.D = f;
    a.G = g;
    return a;
  }
  p.scale = function (a, b) {
    this.B *= a;
    this.A *= a;
    this.C *= b;
    this.F *= b;
    return this;
  };
  p.translate = function (a, b) {
    this.D += a * this.B + b * this.C;
    this.G += a * this.A + b * this.F;
    return this;
  };
  p.rotate = function (a, b, c) {
    var d = new kJ(),
      e = Math.cos(a);
    a = Math.sin(a);
    b = lJ(d, e, a, -a, e, b - b * e + c * a, c - b * a - c * e);
    c = this.B;
    d = this.C;
    this.B = b.B * c + b.A * d;
    this.C = b.C * c + b.F * d;
    this.D += b.D * c + b.G * d;
    c = this.A;
    d = this.F;
    this.A = b.B * c + b.A * d;
    this.F = b.C * c + b.F * d;
    this.G += b.D * c + b.G * d;
    return this;
  };
  p.toString = function () {
    return (
      "matrix(" + [this.B, this.A, this.C, this.F, this.D, this.G].join() + ")"
    );
  };
  p.transform = function (a, b, c, d, e) {
    var f = b;
    for (b += 2 * e; f < b; ) {
      e = a[f++];
      let g = a[f++];
      c[d++] = e * this.B + g * this.C + this.D;
      c[d++] = e * this.A + g * this.F + this.G;
    }
  };
  p.equals = function (a) {
    return this === a
      ? !0
      : a
      ? this.B == a.B &&
        this.C == a.C &&
        this.D == a.D &&
        this.A == a.A &&
        this.F == a.F &&
        this.G == a.G
      : !1;
  };
  function mJ() {
    this.size = 80;
    this.A = "Arial";
  }
  function nJ(a, b) {
    Su.call(this);
    this.D = a;
    this.C = b;
    this[tu] = !1;
  }
  Ea(nJ, Su);
  p = nJ.prototype;
  p.C = null;
  p.D = null;
  p.G = null;
  p.ia = function () {
    return this.D;
  };
  p.addEventListener = function (a, b, c, d) {
    Fu(this.D, a, b, c, d);
  };
  p.removeEventListener = function (a, b, c, d) {
    Nu(this.D, a, b, c, d);
  };
  p.B = function () {
    nJ.qa.B.call(this);
    Pu(this.D);
  };
  function oJ(a, b, c, d) {
    nJ.call(this, a, b);
    this.O(c);
    this.L(d);
  }
  Ea(oJ, nJ);
  p = oJ.prototype;
  p.fill = null;
  p.H = null;
  p.L = function (a) {
    this.fill = a;
    this.C.ib(this, a);
  };
  p.aa = function () {
    return this.fill;
  };
  p.O = function (a) {
    this.H = a;
    this.C.Bb(this, a);
  };
  p.ea = function () {
    return this.H;
  };
  function pJ() {}
  function qJ(a, b) {
    nJ.call(this, a, b);
  }
  Ea(qJ, nJ);
  function rJ() {
    this.xb = [];
    this.ta = [];
    this.Cb = [];
  }
  rJ.prototype.Wb = null;
  rJ.prototype.rb = null;
  rJ.prototype.Ld = !0;
  var sJ = [2, 2, 6, 6, 0];
  p = rJ.prototype;
  p.clear = function () {
    this.xb.length = 0;
    this.ta.length = 0;
    this.Cb.length = 0;
    delete this.Wb;
    delete this.rb;
    delete this.Ld;
    return this;
  };
  p.moveTo = function (a, b) {
    pb(this.xb) == 0
      ? (this.Cb.length -= 2)
      : (this.xb.push(0), this.ta.push(1));
    this.Cb.push(a, b);
    this.rb = this.Wb = [a, b];
    return this;
  };
  p.A = function (a) {
    var b = pb(this.xb);
    if (b == null) throw Error("Path cannot start with lineTo");
    b != 1 && (this.xb.push(1), this.ta.push(0));
    for (b = 0; b < arguments.length; b += 2) {
      var c = arguments[b];
      var d = arguments[b + 1];
      this.Cb.push(c, d);
    }
    this.ta[this.ta.length - 1] += b / 2;
    this.rb = [c, d];
    return this;
  };
  p.B = function (a) {
    var b = pb(this.xb);
    if (b == null) throw Error("Path cannot start with curve");
    b != 2 && (this.xb.push(2), this.ta.push(0));
    for (b = 0; b < arguments.length; b += 6) {
      var c = arguments[b + 4];
      var d = arguments[b + 5];
      this.Cb.push(
        arguments[b],
        arguments[b + 1],
        arguments[b + 2],
        arguments[b + 3],
        c,
        d
      );
    }
    this.ta[this.ta.length - 1] += b / 6;
    this.rb = [c, d];
    return this;
  };
  p.close = function () {
    var a = pb(this.xb);
    if (a == null) throw Error("Path cannot start with close");
    a != 4 && (this.xb.push(4), this.ta.push(1), (this.rb = this.Wb));
    return this;
  };
  p.C = function (a, b, c, d) {
    var e = this.rb[0] - a * Math.cos(Bo(c)),
      f = this.rb[1] - b * Math.sin(Bo(c)),
      g = Bo(d);
    d = Math.ceil((Math.abs(g) / Math.PI) * 2);
    g /= d;
    c = Bo(c);
    for (let h = 0; h < d; h++) {
      let k = Math.cos(c),
        l = Math.sin(c),
        m = ((4 / 3) * Math.sin(g / 2)) / (1 + Math.cos(g / 2)),
        n = e + (k - m * l) * a,
        q = f + (l + m * k) * b;
      c += g;
      k = Math.cos(c);
      l = Math.sin(c);
      this.B(
        n,
        q,
        e + (k + m * l) * a,
        f + (l - m * k) * b,
        e + k * a,
        f + l * b
      );
    }
    return this;
  };
  function tJ(a, b) {
    var c = a.Cb,
      d = 0,
      e = a.xb.length;
    for (let f = 0; f < e; f++) {
      let g = a.xb[f],
        h = sJ[g] * a.ta[f];
      b(g, c.slice(d, d + h));
      d += h;
    }
  }
  p.clone = function () {
    var a = new this.constructor();
    a.xb = this.xb.concat();
    a.ta = this.ta.concat();
    a.Cb = this.Cb.concat();
    a.Wb = this.Wb && this.Wb.concat();
    a.rb = this.rb && this.rb.concat();
    a.Ld = this.Ld;
    return a;
  };
  var uJ = {};
  uJ[0] = rJ.prototype.moveTo;
  uJ[1] = rJ.prototype.A;
  uJ[4] = rJ.prototype.close;
  uJ[2] = rJ.prototype.B;
  uJ[3] = rJ.prototype.C;
  function vJ(a) {
    if (a.Ld) return a.clone();
    var b = new rJ();
    tJ(a, function (c, d) {
      uJ[c].apply(b, d);
    });
    return b;
  }
  rJ.prototype.transform = function (a) {
    if (!this.Ld) throw Error("Non-simple path");
    a.transform(this.Cb, 0, this.Cb, 0, this.Cb.length / 2);
    this.Wb && a.transform(this.Wb, 0, this.Wb, 0, 1);
    this.rb && this.Wb != this.rb && a.transform(this.rb, 0, this.rb, 0, 1);
    return this;
  };
  rJ.prototype.isEmpty = function () {
    return this.xb.length == 0;
  };
  function wJ(a, b, c, d) {
    oJ.call(this, a, b, c, d);
  }
  Ea(wJ, oJ);
  function xJ(a, b, c) {
    this.C = a;
    this.A = b;
    this.B = c == null ? 1 : c;
  }
  xJ.prototype.S = function () {
    return this.C;
  };
  xJ.prototype.Fc = function () {
    return this.A;
  };
  function yJ(a, b, c, d) {
    oJ.call(this, a, b, c, d);
  }
  Ea(yJ, oJ);
  function zJ() {}
  zJ.A = void 0;
  zJ.B = function () {
    return zJ.A ? zJ.A : (zJ.A = new zJ());
  };
  zJ.prototype.A = 0;
  function AJ(a) {
    Su.call(this);
    this.P = a || Bs();
    this.wb = null;
    this.Wa = !1;
    this.C = null;
    this.Z = void 0;
    this.I = this.A = this.G = null;
  }
  Ea(AJ, Su);
  p = AJ.prototype;
  p.ad = zJ.B();
  p.va = function () {
    return this.wb || (this.wb = ":" + (this.ad.A++).toString(36));
  };
  p.ia = function () {
    return this.C;
  };
  p.setParent = function (a) {
    if (this == a) throw Error("Unable to set parent component");
    var b;
    if ((b = a && this.G && this.wb)) {
      b = this.G;
      var c = this.wb;
      b = b.I && c ? Km(b.I, c) || null : null;
    }
    if (b && this.G != a) throw Error("Unable to set parent component");
    this.G = a;
    AJ.qa.Da.call(this, a);
  };
  p.Da = function (a) {
    if (this.G && this.G != a) throw Error("Method not supported");
    AJ.qa.Da.call(this, a);
  };
  p.T = function () {
    this.C = Rs(this.P, "DIV");
  };
  p.render = function (a) {
    if (this.Wa) throw Error("Component already rendered");
    this.C || this.T();
    a ? a.insertBefore(this.C, null) : this.P.A.body.appendChild(this.C);
    (this.G && !this.G.Wa) || this.Sc();
  };
  p.Sc = function () {
    this.Wa = !0;
    BJ(this, function (a) {
      !a.Wa && a.ia() && a.Sc();
    });
  };
  p.Rd = function () {
    BJ(this, function (a) {
      a.Wa && a.Rd();
    });
    this.Z && QI(this.Z);
    this.Wa = !1;
  };
  p.B = function () {
    this.Wa && this.Rd();
    this.Z && (this.Z.dispose(), delete this.Z);
    BJ(this, function (a) {
      a.dispose();
    });
    this.C && Ms(this.C);
    this.G = this.C = this.I = this.A = null;
    AJ.qa.B.call(this);
  };
  p.ea = function (a) {
    var b = this.A ? this.A.length : 0;
    if (a.Wa && !this.Wa) throw Error("Component already rendered");
    if (b < 0 || b > (this.A ? this.A.length : 0))
      throw Error("Child component index out of bounds");
    (this.I && this.A) || ((this.I = {}), (this.A = []));
    if (a.G == this) {
      var c = this.I,
        d = a.va();
      c[d] = a;
      zb(this.A, a);
    } else {
      c = this.I;
      d = a.va();
      if (c !== null && d in c)
        throw Error(`The object already contains the key "${d}"`);
      c[d] = a;
    }
    a.setParent(this);
    Eb(this.A, b, 0, a);
    a.Wa && this.Wa && a.G == this
      ? ((c = this.C),
        (c.childNodes[b] || null) != a.ia() &&
          (a.ia().parentElement == c && c.removeChild(a.ia()),
          (b = c.childNodes[b] || null),
          c.insertBefore(a.ia(), b)))
      : this.Wa &&
        !a.Wa &&
        a.C &&
        a.C.parentNode &&
        a.C.parentNode.nodeType == 1 &&
        a.Sc();
  };
  function BJ(a, b) {
    a.A && a.A.forEach(b, void 0);
  }
  p.removeChild = function (a, b) {
    if (a) {
      let d = typeof a === "string" ? a : a.va();
      a = this.I && d ? Km(this.I, d) || null : null;
      if (d && a) {
        var c = this.I;
        d in c && delete c[d];
        zb(this.A, a);
        b && (a.Rd(), a.C && Ms(a.C));
        a.setParent(null);
      }
    }
    if (!a) throw Error("Child is not in parent component");
    return a;
  };
  function CJ(a, b, c, d, e) {
    AJ.call(this, e);
    this.width = a;
    this.height = b;
    this.H = c || null;
    this.O = d || null;
  }
  Ea(CJ, AJ);
  p = CJ.prototype;
  p.D = null;
  p.aa = function (a, b) {
    this.H = a;
    this.O = b;
  };
  p.F = function () {
    if (this.Wa) {
      var a = this.ia();
      a = $s(a);
    } else
      a =
        typeof this.width === "number" && typeof this.height === "number"
          ? new Eo(this.width, this.height)
          : null;
    return a;
  };
  function DJ(a) {
    var b = a.F();
    return b ? b.width / (a.H ? new Eo(a.H, a.O) : a.F()).width : 0;
  }
  p.removeElement = function (a) {
    Ms(a.ia());
  };
  p.drawText = function (a, b, c, d, e, f, g, h, k, l, m) {
    var n = h.size / 2;
    c = g == "bottom" ? c + e - n : g == "center" ? c + e / 2 : c + n;
    return this.Sa(a, b, c, b + d, c, f, h, k, l, m);
  };
  function EJ(a) {
    nJ.call(this, null, a);
    this.A = [];
  }
  Ea(EJ, qJ);
  p = EJ.prototype;
  p.clear = function () {
    this.A.length && ((this.A.length = 0), FJ(this.C));
  };
  p.setSize = function () {};
  p.appendChild = function (a) {
    this.A.push(a);
  };
  p.draw = function () {
    var a = this.A.length;
    for (let b = 0; b < a; b++) GJ(this.C, this.A[b]);
  };
  p.removeElement = function (a) {
    Cb(this.A, function (b) {
      return b.A ? (b.removeElement(a), !1) : b === a;
    });
  };
  function HJ(a, b, c, d, e) {
    oJ.call(this, a, b, d, e);
    this.I(c);
  }
  Ea(HJ, wJ);
  HJ.prototype.F = !1;
  HJ.prototype.I = function (a) {
    this.P = a.Ld ? a : vJ(a);
    this.F && FJ(this.C);
  };
  HJ.prototype.draw = function (a) {
    this.F = !0;
    a.beginPath();
    tJ(this.P, function (b, c) {
      switch (b) {
        case 0:
          a.moveTo(c[0], c[1]);
          break;
        case 1:
          for (b = 0; b < c.length; b += 2) a.lineTo(c[b], c[b + 1]);
          break;
        case 2:
          for (b = 0; b < c.length; b += 6)
            a.bezierCurveTo(
              c[b],
              c[b + 1],
              c[b + 2],
              c[b + 3],
              c[b + 4],
              c[b + 5]
            );
          break;
        case 3:
          throw Error("Canvas paths cannot contain arcs");
        case 4:
          a.closePath();
      }
    });
  };
  function IJ(a, b, c, d, e, f, g, h, k, l) {
    var m = Hs("DIV", {
      style: "display:table;position:absolute;padding:0;margin:0;border:0",
    });
    oJ.call(this, m, a, k, l);
    this.I = b;
    this.P = c;
    this.ga = d;
    this.T = e;
    this.na = f;
    this.W = g || "left";
    this.Z = h;
    this.F = Hs("DIV", {
      style: "display:table-cell;padding: 0;margin: 0;border: 0",
    });
    c = this.P;
    h = this.T;
    d = this.ga;
    e = this.na;
    k = this.W;
    f = this.Z;
    b = this.ia().style;
    g = DJ(this.C);
    l = this.C;
    var n = l.F();
    l = n ? n.height / (l.H ? new Eo(l.H, l.O) : l.F()).height : 0;
    c == h
      ? ((b.lineHeight = "90%"),
        (this.F.style.verticalAlign =
          k == "center"
            ? "middle"
            : k == "left"
            ? d < e
              ? "top"
              : "bottom"
            : d < e
            ? "bottom"
            : "top"),
        (b.textAlign = "center"),
        (h = f.size * g),
        (b.top = Math.round(Math.min(d, e) * l) + "px"),
        (b.left = Math.round((c - h / 2) * g) + "px"),
        (b.width = Math.round(h) + "px"),
        (b.height = Math.abs(d - e) * l + "px"),
        (b.fontSize = f.size * 0.6 * l + "pt"))
      : ((b.lineHeight = "100%"),
        (this.F.style.verticalAlign = "top"),
        (b.textAlign = k),
        (b.top = Math.round(((d + e) / 2 - (f.size * 2) / 3) * l) + "px"),
        (b.left = Math.round(c * g) + "px"),
        (b.width = Math.round(Math.abs(h - c) * g) + "px"),
        (b.height = "auto"),
        (b.fontSize = f.size * l + "pt"));
    b.fontWeight = "normal";
    b.fontStyle = "normal";
    b.fontFamily = f.A;
    c = this.fill;
    b.color = c.Fc() || c.Fg();
    JJ(this);
    a.ia().appendChild(m);
    m.appendChild(this.F);
  }
  Ea(IJ, yJ);
  IJ.prototype.L = function (a) {
    this.fill = a;
    var b = this.ia();
    b && (b.style.color = a.Fc() || a.Fg());
  };
  IJ.prototype.O = function () {};
  IJ.prototype.draw = function () {};
  function JJ(a) {
    if (a.P == a.T) {
      var b = a.I.split("")
        .map(function (c) {
          Za.test(c) &&
            (c.indexOf("&") != -1 && (c = c.replace(Sa, "&amp;")),
            c.indexOf("<") != -1 && (c = c.replace(Ta, "&lt;")),
            c.indexOf(">") != -1 && (c = c.replace(Va, "&gt;")),
            c.indexOf('"') != -1 && (c = c.replace(Wa, "&quot;")),
            c.indexOf("'") != -1 && (c = c.replace(Xa, "&#39;")),
            c.indexOf("\x00") != -1 && (c = c.replace(Ya, "&#0;")));
          return c;
        })
        .join("<br>");
      b = Mn(b);
      Qn(a.F, b);
    } else Qn(a.F, yp(a.I));
  }
  function KJ(a, b) {
    this.B = a;
    this.A = b == null ? 1 : b;
  }
  Ea(KJ, pJ);
  KJ.prototype.Fc = function () {
    return this.B;
  };
  function LJ(a, b, c, d, e) {
    CJ.call(this, a, b, c, d, e);
  }
  Ea(LJ, CJ);
  p = LJ.prototype;
  p.ib = function () {
    FJ(this);
  };
  p.Bb = function () {
    FJ(this);
  };
  p.na = function () {
    FJ(this);
  };
  function MJ(a, b) {
    a = a.getContext();
    a.save();
    b = b.G ? b.G.clone() : new kJ();
    var c = b.D,
      d = b.G;
    (c || d) && a.translate(c, d);
    (b = b.A) && a.rotate(Math.asin(b));
  }
  p.T = function () {
    var a = this.P.B("DIV", { style: "position:relative;overflow:hidden" });
    this.C = a;
    this.W = this.P.B("CANVAS");
    a.appendChild(this.W);
    this.ga = this.D = new EJ(this);
    this.ua = 0;
    NJ(this);
  };
  p.getContext = function () {
    this.ia() || this.T();
    this.L || ((this.L = this.W.getContext("2d")), this.L.save());
    return this.L;
  };
  p.aa = function (a, b) {
    LJ.qa.aa.apply(this, arguments);
    FJ(this);
  };
  p.setSize = function (a, b) {
    this.width = a;
    this.height = b;
    NJ(this);
    FJ(this);
  };
  p.F = function () {
    var a = this.width,
      b = this.height,
      c = typeof a === "string" && a.indexOf("%") != -1,
      d = typeof b === "string" && b.indexOf("%") != -1;
    if (!this.Wa && (c || d)) return null;
    if (c) {
      var e = this.ia().parentNode;
      var f = $s(e);
      a = (parseFloat(a) * f.width) / 100;
    }
    d &&
      ((e = e || this.ia().parentNode),
      (f = f || $s(e)),
      (b = (parseFloat(b) * f.height) / 100));
    return new Eo(a, b);
  };
  function NJ(a) {
    Ys(a.ia(), a.width, a.height);
    var b = a.F();
    b &&
      (Ys(a.W, b.width, b.height),
      (a.W.width = b.width),
      (a.W.height = b.height),
      (a.L = null));
  }
  p.reset = function () {
    var a = this.getContext();
    a.restore();
    var b = this.F();
    b.width && b.height && a.clearRect(0, 0, b.width, b.height);
    a.save();
  };
  p.clear = function () {
    this.reset();
    this.D.clear();
    for (var a = this.ia(); a.childNodes.length > 1; )
      a.removeChild(a.lastChild);
  };
  function FJ(a) {
    if (!a.Ca && a.Wa) {
      a.reset();
      if (a.H) {
        let b = a.F();
        a.getContext().scale(b.width / a.H, b.height / a.O);
      }
      MJ(a, a.D);
      a.D.draw(a.L);
      a.getContext().restore();
    }
  }
  function GJ(a, b) {
    if (!(b instanceof IJ)) {
      var c = a.getContext();
      MJ(a, b);
      if (b.aa && b.ea) {
        var d = b.fill;
        if (d)
          if (d instanceof KJ)
            d.A != 0 &&
              ((c.globalAlpha = d.A),
              (c.fillStyle = d.Fc()),
              b.draw(c),
              c.fill(),
              (c.globalAlpha = 1));
          else {
            let e = c.createLinearGradient(d.fj(), d.hj(), d.gj(), d.ij());
            e.addColorStop(0, d.Fg());
            e.addColorStop(1, d.cj());
            c.fillStyle = e;
            b.draw(c);
            c.fill();
          }
        if ((d = b.H))
          b.draw(c),
            (c.strokeStyle = d.Fc()),
            (b = d.S()),
            typeof b === "string" &&
              b.indexOf("px") != -1 &&
              (b = parseFloat(b) / DJ(a)),
            (c.lineWidth = b),
            c.stroke();
      } else b.draw(c);
      a.getContext().restore();
    }
  }
  function OJ(a, b, c) {
    c = c || a.D;
    c.appendChild(b);
    !a.Wa || a.ua || (c != a.D && c != a.ga) || GJ(a, b);
  }
  p.Sa = function (a, b, c, d, e, f, g, h, k, l) {
    a = new IJ(this, a, b, c, d, e, f, g, h, k);
    OJ(this, a, l);
    return a;
  };
  p.Na = function (a, b, c) {
    a = new HJ(null, this, a, b, c);
    OJ(this, a);
  };
  p.B = function () {
    this.L = null;
    LJ.qa.B.call(this);
  };
  p.Sc = function () {
    var a = this.F();
    LJ.qa.Sc.call(this);
    a || (NJ(this), this.dispatchEvent("resize"));
    FJ(this);
  };
  p.removeElement = function (a) {
    a && (this.D.removeElement(a), FJ(this));
  };
  function PJ(a, b) {
    nJ.call(this, a, b);
  }
  Ea(PJ, qJ);
  PJ.prototype.clear = function () {
    Ls(this.ia());
  };
  PJ.prototype.setSize = function (a, b) {
    QJ(this.ia(), { width: a, height: b });
  };
  function RJ(a, b, c, d) {
    oJ.call(this, a, b, c, d);
  }
  Ea(RJ, wJ);
  RJ.prototype.I = function (a) {
    QJ(this.ia(), { d: SJ(a) });
  };
  function TJ(a, b, c, d) {
    oJ.call(this, a, b, c, d);
  }
  Ea(TJ, yJ);
  function UJ(a, b) {
    Su.call(this);
    this.D = a || 1;
    this.C = b || u;
    this.F = () => {
      if (this.enabled) {
        let c = Date.now() - this.G;
        c > 0 && c < this.D * 0.8
          ? (this.A = this.C.setTimeout(this.F, this.D - c))
          : (this.A && (this.C.clearTimeout(this.A), (this.A = null)),
            this.dispatchEvent("tick"),
            this.enabled && (this.stop(), this.start()));
      }
    };
    this.G = Date.now();
  }
  Ea(UJ, Su);
  p = UJ.prototype;
  p.enabled = !1;
  p.A = null;
  p.setInterval = function (a) {
    this.D = a;
    this.A && this.enabled
      ? (this.stop(), this.start())
      : this.A && this.stop();
  };
  p.start = function () {
    this.enabled = !0;
    this.A ||
      ((this.A = this.C.setTimeout(this.F, this.D)), (this.G = Date.now()));
  };
  p.stop = function () {
    this.enabled = !1;
    this.A && (this.C.clearTimeout(this.A), (this.A = null));
  };
  p.B = function () {
    UJ.qa.B.call(this);
    this.stop();
    delete this.C;
  };
  function VJ(a, b, c, d, e) {
    CJ.call(this, a, b, c, d, e);
    this.Ca = {};
    this.ua = Nb && !Yb();
    this.L = new NI(this);
  }
  var WJ;
  Ea(VJ, CJ);
  function XJ(a, b, c) {
    a = a.P.A.createElementNS("http://www.w3.org/2000/svg", b);
    c && QJ(a, c);
    return a;
  }
  function QJ(a, b) {
    for (let c in b) a.setAttribute(c, b[c]);
  }
  p = VJ.prototype;
  p.ib = function (a, b) {
    a = a.ia();
    b instanceof KJ
      ? (a.setAttribute("fill", b.Fc()), a.setAttribute("fill-opacity", b.A))
      : a.setAttribute("fill", "none");
  };
  p.Bb = function (a, b) {
    a = a.ia();
    b
      ? (a.setAttribute("stroke", b.Fc()),
        a.setAttribute("stroke-opacity", b.B),
        (b = b.S()),
        typeof b === "string" && b.indexOf("px") != -1
          ? a.setAttribute("stroke-width", parseFloat(b) / DJ(this))
          : a.setAttribute("stroke-width", b))
      : a.setAttribute("stroke", "none");
  };
  p.na = function (a, b) {
    b = [b.B, b.A, b.C, b.F, b.D, b.G].join();
    a.ia().setAttribute("transform", "matrix(" + b + ")");
  };
  p.T = function () {
    var a = XJ(this, "svg", {
        width: this.width,
        height: this.height,
        overflow: "hidden",
      }),
      b = XJ(this, "g");
    this.ga = XJ(this, "defs");
    this.D = new PJ(b, this);
    a.appendChild(this.ga);
    a.appendChild(b);
    this.C = a;
    ZJ(this);
  };
  p.aa = function (a, b) {
    VJ.qa.aa.apply(this, arguments);
    ZJ(this);
  };
  function ZJ(a) {
    a.H &&
      (a.ia().setAttribute("preserveAspectRatio", "none"),
      a.ua
        ? a.W()
        : a
            .ia()
            .setAttribute("viewBox", "0 0 " + (a.H ? a.H + " " + a.O : "")));
  }
  p.W = function () {
    if (this.Wa) {
      var a = this.F();
      if (a.width == 0) this.ia().style.visibility = "hidden";
      else {
        this.ia().style.visibility = "";
        var b = a.width / this.H;
        a = a.height / this.O;
        this.D.ia().setAttribute(
          "transform",
          "scale(" + b + " " + a + ") translate(0 0)"
        );
      }
    }
  };
  p.setSize = function (a, b) {
    Ys(this.ia(), a, b);
  };
  p.F = function () {
    if (!Mb) {
      if (this.Wa) {
        var a = this.ia();
        a = $s(a);
      } else a = VJ.qa.F.call(this);
      return a;
    }
    a = this.width;
    var b = this.height,
      c = typeof a === "string" && a.indexOf("%") != -1,
      d = typeof b === "string" && b.indexOf("%") != -1;
    if (!this.Wa && (c || d)) return null;
    if (c) {
      var e = this.ia().parentNode;
      var f = $s(e);
      a = (parseFloat(a) * f.width) / 100;
    }
    d &&
      ((e = e || this.ia().parentNode),
      (f = f || $s(e)),
      (b = (parseFloat(b) * f.height) / 100));
    return new Eo(a, b);
  };
  p.clear = function () {
    this.D.clear();
    Ls(this.ga);
    this.Ca = {};
  };
  p.Sa = function (a, b, c, d, e, f, g, h, k, l) {
    var m = Math.round(Ao(Co(Math.atan2(e - c, d - b))));
    d -= b;
    e -= c;
    e = Math.round(Math.sqrt(d * d + e * e));
    d = g.size;
    g = { "font-family": g.A, "font-size": d };
    d = Math.round(c - d / 2 + Math.round(d * 0.85));
    var n = b;
    f == "center"
      ? ((n += Math.round(e / 2)), (g["text-anchor"] = "middle"))
      : f == "right" && ((n += e), (g["text-anchor"] = "end"));
    g.x = n;
    g.y = d;
    m != 0 && (g.transform = "rotate(" + m + " " + b + " " + c + ")");
    b = XJ(this, "text", g);
    b.appendChild(this.P.A.createTextNode(a));
    h == null &&
      Mb &&
      Pb &&
      ((a = "black"), k instanceof KJ && (a = k.Fc()), (h = new xJ(1, a)));
    k = new TJ(b, this, h, k);
    (l || this.D).ia().appendChild(k.ia());
    return k;
  };
  p.Na = function (a, b, c) {
    a = XJ(this, "path", { d: SJ(a) });
    b = new RJ(a, this, b, c);
    this.D.ia().appendChild(b.ia());
  };
  function SJ(a) {
    var b = [];
    tJ(a, function (c, d) {
      switch (c) {
        case 0:
          b.push("M");
          Array.prototype.push.apply(b, d);
          break;
        case 1:
          b.push("L");
          Array.prototype.push.apply(b, d);
          break;
        case 2:
          b.push("C");
          Array.prototype.push.apply(b, d);
          break;
        case 3:
          c = d[3];
          b.push(
            "A",
            d[0],
            d[1],
            0,
            Math.abs(c) > 180 ? 1 : 0,
            c > 0 ? 1 : 0,
            d[4],
            d[5]
          );
          break;
        case 4:
          b.push("Z");
      }
    });
    return b.join(" ");
  }
  p.Sc = function () {
    var a = this.F();
    VJ.qa.Sc.call(this);
    a || this.dispatchEvent("resize");
    if (this.ua) {
      a = this.width;
      let b = this.height;
      typeof a == "string" &&
        a.indexOf("%") != -1 &&
        typeof b == "string" &&
        b.indexOf("%") != -1 &&
        this.L.listen($J(), "tick", this.W);
      this.W();
    }
  };
  p.Rd = function () {
    VJ.qa.Rd.call(this);
    this.ua && this.L.N($J(), "tick", this.W);
  };
  p.B = function () {
    delete this.Ca;
    delete this.ga;
    delete this.D;
    this.L.dispose();
    delete this.L;
    VJ.qa.B.call(this);
  };
  function $J() {
    WJ || ((WJ = new UJ(400)), WJ.start());
    return WJ;
  }
  function aK(a, b) {
    for (let c = 0; c < b.length; c++) a.add(b[c]);
  }
  function bK(a) {
    return `rgba(${Math.floor(a[0] * 255)},${Math.floor(
      a[1] * 255
    )},${Math.floor(a[2] * 255)},${a[3]})`;
  }
  function cK(a) {
    var b = a.substring(5, a.length - 1).split(",");
    a = [];
    for (let c = 0; c < b.length; c++) a.push(+b[c]);
    for (b = 0; b < 3; b++) a[b] /= 255;
    return a;
  }
  function dK(a) {
    a = a.toString(16);
    return a.length === 1 ? `0${a}` : a;
  }
  function eK(a) {
    return `#${dK(Math.floor(a[0] * 255))}${dK(Math.floor(a[1] * 255))}${dK(
      Math.floor(a[2] * 255)
    )}`;
  }
  function fK(a, b, c, d) {
    var e = a.V;
    c.length !== 0 && (c = []);
    var f = !1;
    for (let g = 0; g < b.vertices.length / 3; g++) {
      let h = a.M;
      h[0] = b.vertices[3 * g + 0];
      h[1] = b.vertices[3 * g + 1];
      h[2] = b.vertices[3 * g + 2];
      Lt(fI(b), h, h);
      let k = a.L;
      d(h, k);
      c.push(k[0]);
      c.push(k[1]);
      f = k[0] > e || f;
    }
    return !f;
  }
  function gK(a, b, c, d) {
    var e = a.V,
      f = b.xa(),
      g = a.J;
    f.zd(g);
    var h = a.Da,
      k = b.vertices.length;
    for (f = 6; f < k; f++) h[f - 3] = b.vertices[f];
    for (f = 0; f < 3; f++) h[f] = (b.vertices[f] + b.vertices[f + 3]) / 2;
    f = !1;
    k = h.length / 3;
    for (var l = 0; l < k; l++) {
      var m = a.M;
      m[0] = h[3 * l + 0];
      m[1] = h[3 * l + 1];
      m[2] = h[3 * l + 2];
      Lt(g, m, m);
      Yt(m, m);
      var n = a.L;
      d(m, n);
      c[3 * l + 0] = n[0];
      c[3 * l + 1] = n[1];
      c[3 * l + 2] = 1;
      f = n[0] > e || f;
    }
    d = et(b.A);
    b = d.height / 1.25;
    d = d.width;
    a = a.Da;
    a[0] = 0;
    a[1] = 0 + b / 2;
    a[2] = 1;
    a[3] = 0 + d;
    a[4] = 0 + b;
    a[5] = 1;
    a[6] = 0 + d;
    a[7] = 0;
    a[8] = 1;
    Xu(a, a);
    b = c[0];
    d = c[1];
    e = c[2];
    g = c[3];
    h = c[4];
    k = c[5];
    l = c[6];
    m = c[7];
    n = c[8];
    var q = a[0],
      r = a[1],
      t = a[2],
      v = a[3],
      F = a[4],
      H = a[5],
      I = a[6],
      J = a[7];
    a = a[8];
    c[0] = b * q + g * r + l * t;
    c[1] = d * q + h * r + m * t;
    c[2] = e * q + k * r + n * t;
    c[3] = b * v + g * F + l * H;
    c[4] = d * v + h * F + m * H;
    c[5] = e * v + k * F + n * H;
    c[6] = b * I + g * J + l * a;
    c[7] = d * I + h * J + m * a;
    c[8] = e * I + k * J + n * a;
    return !f;
  }
  var lK = class {
    constructor() {
      this.A = [];
      this.H = Ct();
      this.view = Ct();
      this.K = Ct();
      this.canvas = this.F = this.N = this.G = this.D = null;
      this.C = [];
      this.B = [];
      this.ea = this.ga = this.aa = this.font = null;
      this.I = 1;
      this.V = Infinity;
      this.T = this.W = -1;
      this.P = Ct();
      this.J = Ct();
      this.na = Wu();
      this.Da = Wu();
      this.sa = av();
      this.M = Y();
      this.ua = Y();
      this.Na = Y();
      this.L = Nx();
      this.O = At();
      this.Sa = At();
      this.Ca = new rJ();
      var a = cK("rgba(255, 255, 255, 0.7)"),
        b = cK("rgba(0, 0, 0, 0.15)"),
        c = cK("rgba(0, 0, 0, 0.5)");
      this.aa = new KJ(eK(a), a[3]);
      this.ga = new xJ(2, eK(b), b[3]);
      this.font = new mJ();
      this.ea = new KJ(eK(c), c[3]);
    }
    add(a) {
      this.A.push(a);
      jI(a);
    }
    addIcon(a) {
      this.B.push(a);
    }
    clearIcons() {
      this.B = [];
    }
    Z(a) {
      this.C = a;
    }
    render(a, b, c, d) {
      var e = (d = d || new Ss(0, 0, 0, 0)),
        f = a.Tb,
        g = a.Sb,
        h = a.R() / 2,
        k = a.S() / 2,
        l = this.K,
        m = -h,
        n = (g - f) / 2,
        q = k + e.left,
        r = h + e.top;
      l[0] = k;
      l[1] = 0;
      l[2] = 0;
      l[3] = 0;
      l[4] = 0;
      l[5] = m;
      l[6] = 0;
      l[7] = 0;
      l[8] = 0;
      l[9] = 0;
      l[10] = n;
      l[11] = 0;
      l[12] = q;
      l[13] = r;
      l[14] = (g + f) / 2;
      l[15] = 1;
      var t = this.M,
        v = this.ua,
        F = this.Na;
      rt(t, a.Pa, a.Qa, a.Ra);
      rt(v, a.cb, a.eb, a.fb);
      Yt(t, t);
      Yt(v, v);
      xt(t, F);
      Qt(this.view, t, v, F);
      var H = a.S() / a.R();
      Pt(this.H, a.Kb, H, a.Tb, a.Sb);
      Jt(this.H, this.view, this.P);
      if (b.C) {
        var I = b.C;
        let Ab = u.devicePixelRatio || 1,
          ub = this.J;
        for (let qa = 0; qa < this.A.length; qa++) {
          let ha = this.A[qa];
          if (eI(ha)) continue;
          Jt(this.H, this.view, ub);
          Jt(ub, fI(ha), ub);
          a: {
            var J = ha.vertices;
            let O = this.O;
            for (let va = 0; va < J.length; va += 3)
              if (
                ((O[0] = J[va + 0]),
                (O[1] = J[va + 1]),
                (O[2] = J[va + 2]),
                (O[3] = 1),
                Nt(ub, O, O),
                (EI(O) & 6) !== 0)
              ) {
                var ja = !1;
                break a;
              }
            ja = !0;
          }
          if (!ja) continue;
          let T = this.O;
          I.beginPath();
          for (let O = 0; O < ha.vertices.length / 3; O++)
            (T[0] = ha.vertices[3 * O + 0]),
              (T[1] = ha.vertices[3 * O + 1]),
              (T[2] = ha.vertices[3 * O + 2]),
              (T[3] = 1),
              Nt(ub, T, T),
              vt(T, 1 / T[3], T),
              Lt(this.K, T, T),
              vt(T, Ab, T),
              O === 0 ? I.moveTo(T[0], T[1]) : I.lineTo(T[0], T[1]);
          I.closePath();
          I.fillStyle = bK(ha.C);
          I.fill();
          let W = ha.A;
          W && ((I.strokeStyle = bK(W)), I.stroke());
        }
        if (this.B.length !== 0 && this.I !== 0) {
          I.globalAlpha = this.I;
          var ua = this.J;
          Jt(this.H, this.view, ua);
          for (let qa = 0; qa < this.B.length; qa++) {
            let ha = this.B[qa],
              T = ha.ub(),
              W = this.O,
              O = ha.A(),
              va = this.Sa;
            var ka = va,
              ya = O[1],
              ma = O[2];
            ka[0] = O[0];
            ka[1] = ya;
            ka[2] = ma;
            ka[3] = 1;
            Nt(ua, va, W);
            let bb = !1;
            (EI(W) & 6) !== 0 && (bb = !0);
            vt(W, 1 / W[3], W);
            Lt(this.K, W, W);
            if (!bb && T) {
              let Ua = ha.D(),
                hb = Ab * ha.C(),
                ib = Ab * ha.B();
              W[0] = W[0] * Ab - hb / 2;
              W[1] = W[1] * Ab - ib / 2;
              I.drawImage(
                T,
                Ua.left,
                Ua.top,
                Ua.right - Ua.left,
                Ua.bottom - Ua.top,
                W[0],
                W[1],
                hb,
                ib
              );
            }
          }
          I.globalAlpha = 1;
        }
      } else if (b.A) {
        var L = b.A,
          Fa = d;
        if (!L.isContextLost()) {
          L.clear(256);
          hK(L, 2884);
          hK(L, 2929);
          L.state.F(3042, !0);
          L.state.O(770, 771, 1, 771);
          this.D || (this.D = new iJ(L));
          GI(this.D).ec();
          let Ab = FI(this.D.attributes.A);
          L.state.H(Ab, !0);
          for (let qa = 0; qa < this.A.length; qa++) {
            var ea = this.A[qa],
              za = L;
            za.A.contains(ea.F) ? iK(za.A, ea.F) : nI(ea, za);
          }
          var da = u.devicePixelRatio || 1,
            lb = Fa.left * da,
            sb = Fa.bottom * da,
            Hb = a.S() * da,
            Xe = a.R() * da;
          jK(L);
          L.state.N(lb, sb, Hb, Xe);
          var Sc = this.J;
          for (let qa = 0; qa < this.A.length; qa++) {
            let ha = this.A[qa];
            if (eI(ha)) continue;
            let T = this.D;
            Jt(this.H, this.view, Sc);
            Jt(Sc, fI(ha), Sc);
            let W = this.sa;
            bv(W, Sc);
            bJ(T.uniforms.A, W);
            $I(T.uniforms.color, ha.C);
            iK(L.A, ha.F);
            pI(L, 34962, ha.D);
            HI(T.attributes.A, 3);
            L.ca.drawArrays(6, 0, ha.vertices.length / 3);
            let O = ha.A;
            O &&
              ($I(T.uniforms.color, O),
              L.ca.drawArrays(2, 0, ha.vertices.length / 3));
          }
          if (this.B.length !== 0) {
            this.G || (this.G = new fJ(L));
            GI(this.G).ec();
            var Qb = this.M;
            rt(Qb, a.Pa, a.Qa, a.Ra);
            Yt(Qb, Qb);
            var ld = this.J;
            Jt(this.H, this.view, ld);
            St(ld, Qb[0], Qb[1], Qb[2]);
            var zj = this.sa;
            bv(zj, ld);
            bJ(this.G.uniforms.A, zj);
            this.G.uniforms.opacity.set(this.I);
            if (this.N) pI(L, 34962, this.N);
            else {
              this.N = L.ca.createBuffer();
              pI(L, 34962, this.N);
              let qa = new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]);
              L.ca.bufferData(34962, qa, 35044);
            }
            var md = this.G,
              fm = FI(md.attributes.A);
            L.ca.vertexAttribPointer(fm, 2, 5126, !1, 0, 0);
            var gm = FI(md.attributes.A);
            L.state.H(gm, !0);
            md.uniforms.B.set(0);
            for (let qa = 0; qa < this.B.length; qa++) {
              let ha = this.B[qa],
                T = ha.A(),
                W = ha.F(L),
                O = ha.C(),
                va = ha.B();
              if (W) {
                var kc = L,
                  lc = UI(md.uniforms.D),
                  gh = [T[0] - Qb[0], T[1] - Qb[1], T[2] - Qb[2]];
                let bb = kc.Dc;
                bb && bb.L && bb.L(lc, gh);
                var hh = L,
                  ih = UI(md.uniforms.C),
                  jh = [O / a.S(), va / a.R()];
                let Ua = hh.Dc;
                Ua && Ua.N && Ua.N(ih, jh);
                var hm = L,
                  im = UI(md.uniforms.F),
                  jm = ha.G();
                let hb = hm.Dc;
                hb && hb.H && hb.H(im, jm);
                var km = L,
                  Aj = UI(md.uniforms.G),
                  Jr = ha.H();
                let ib = km.Dc;
                ib && ib.H && ib.H(Aj, Jr);
                L.state.J(33984);
                L.bindTexture(3553, W);
                L.ca.drawArrays(5, 0, 4);
              }
            }
            kK(L, FI(md.attributes.A));
          }
          let ub = FI(this.D.attributes.A);
          kK(L, ub);
          hK(L, 3042);
        }
      } else if (b.D && c) {
        var Rb = b.D;
        let Ab = this.M,
          ub = this.ua;
        rt(Ab, a.Pa, a.Qa, a.Ra);
        rt(ub, a.cb, a.eb, a.fb);
        Yt(Ab, Ab);
        Yt(ub, ub);
        vt(Ab, 2, Ab);
        ut(Ab, ub, ub);
        let qa = this.L;
        c(ub, qa);
        let ha = Math.abs(a.S() / 2 - qa[0]) * 2;
        qa[0] < a.S() / 2 && (qa[0] += ha);
        this.V = qa[0] - ha * 0.1;
        if (this.A.length !== 0 || this.C.length !== 0 || this.B.length !== 0) {
          var ne;
          this.canvas ||
            ((this.canvas = Js(document, "canvas")),
            (this.canvas.style.position = "absolute"),
            (this.canvas.style.zIndex = "2"),
            Rb.appendChild(this.canvas));
          if (
            this.canvas.width !== Rb.clientWidth ||
            this.canvas.height !== Rb.clientHeight
          )
            (this.canvas.width = Rb.clientWidth),
              (this.canvas.height = Rb.clientHeight);
          var Qa =
            (ne = this.canvas) && ne.getContext ? ne.getContext("2d") : null;
          if (Qa) {
            Qa.save();
            Qa.setTransform(1, 0, 0, 1, 0, 0);
            Qa.clearRect(0, 0, ne.width, ne.height);
            Qa.restore();
            for (let T = 0; T < this.C.length; T++) {
              let W = this.C[T],
                O = this.na;
              gK(this, W, O, c) &&
                (Qa.save(),
                Qa.transform(O[0], O[1], O[3], O[4], O[6], O[7]),
                Qa.drawImage(et(W.A), 0, 0),
                Qa.restore());
            }
            Qa.save();
            Qa.setTransform(1, 0, 0, 1, 0, 0);
            for (let T = 0; T < this.A.length; T++) {
              let W = this.A[T];
              if (eI(W)) continue;
              let O = [];
              if (!fK(this, W, O, c)) continue;
              Qa.beginPath();
              Qa.moveTo(O[0], O[1]);
              for (let bb = 1; bb < O.length / 2; bb++)
                Qa.lineTo(O[bb * 2], O[bb * 2 + 1]);
              Qa.closePath();
              Qa.fillStyle = bK(W.C);
              Qa.fill();
              let va = W.A;
              va && ((Qa.strokeStyle = bK(va)), Qa.stroke());
            }
            Qa.restore();
            if (this.I !== 0) {
              Qa.globalAlpha = this.I;
              for (let T = 0; T < this.B.length; T++) {
                let W = this.B[T],
                  O = W.A(),
                  va = this.L;
                c(O, va);
                let bb = W.ub();
                if (bb) {
                  let Ua = W.D(),
                    hb = W.C(),
                    ib = W.B();
                  va[0] -= hb / 2;
                  va[1] -= ib / 2;
                  Qa.drawImage(
                    bb,
                    Ua.left,
                    Ua.top,
                    Ua.right - Ua.left,
                    Ua.bottom - Ua.top,
                    va[0],
                    va[1],
                    hb,
                    ib
                  );
                }
              }
              Qa.globalAlpha = 1;
            }
          } else {
            if (!this.F) {
              let T;
              Nb && Ob
                ? (T = new LJ("100%", "100%", void 0, void 0, void 0))
                : (T = new VJ("100%", "100%", void 0, void 0, void 0));
              T.T();
              this.F = T;
              let W = this.F.ia();
              W.style.position = "absolute";
              W.style.zIndex = "1";
              W.setAttribute("pointer-events", "none");
              this.F.render(Rb);
            }
            if (this.W !== Rb.clientWidth || this.T !== Rb.clientHeight)
              this.F.aa(Rb.clientWidth, Rb.clientHeight),
                (this.W = Rb.clientWidth),
                (this.T = Rb.clientHeight);
            var Ye = this.F;
            Ye.clear();
            for (let T = 0; T < this.C.length; T++) {
              let W = this.C[T],
                O = this.na;
              if (!gK(this, W, O, c)) continue;
              let va = new kJ(O[0], O[1], O[3], O[4], O[6], O[7]),
                bb = new kJ(O[0], O[1], O[3], O[4], O[6] + -1.5, O[7] + 0),
                Ua = et(W.A).height / 1.25,
                hb = W.A.F;
              for (let ib = 0; ib < hb.length; ++ib) {
                var Qf = Ye.drawText(
                  hb[ib],
                  0,
                  (Ua / hb.length) * ib,
                  1,
                  1,
                  "left",
                  "top",
                  this.font,
                  null,
                  this.ea
                );
                Qf.G = bb.clone();
                Qf.C.na(Qf, bb);
                var gb = Ye.drawText(
                  hb[ib],
                  0,
                  (Ua / hb.length) * ib,
                  1,
                  1,
                  "left",
                  "top",
                  this.font,
                  this.ga,
                  this.aa
                );
                gb.G = va.clone();
                gb.C.na(gb, va);
              }
            }
            for (let T = 0; T < this.A.length; T++) {
              let W = this.A[T];
              if (eI(W)) continue;
              let O = [];
              if (!fK(this, W, O, c)) continue;
              let va = this.Ca;
              va.clear();
              va.moveTo(O[0], O[1]);
              for (let me = 1; me < O.length / 2; me++)
                va.A(O[me * 2], O[me * 2 + 1]);
              va.close();
              let bb = W.C,
                Ua = new KJ(eK(bb), bb[3]),
                hb = W.A,
                ib = null;
              hb && (ib = new xJ(1, eK(hb), hb[3]));
              Ye.Na(va, ib, Ua);
            }
          }
        }
      } else throw Error(`ShapeLayer: invalid context: ${b}`);
    }
  };
  function OG(a) {
    a.enabled = a.C !== 0 && !!a.B && a.B === a.J;
    a.enabled && mK(a);
  }
  function nK(a) {
    a.D && a.D.showRouteArrow(a.C, a.F, a.G, a.B);
  }
  function mK(a) {
    if (!a.context.B) {
      a.A || (a.A = new lK());
      a.A.A = [];
      var b = oK(a);
      sI(b, (c) => {
        a.A.add(c);
      });
      pK(a, b);
    }
  }
  function oK(a) {
    var b = qK[a.C];
    if (!b) return rI([]);
    var c = [],
      d = a.F === 2,
      e;
    b.forEach((f) => {
      var g = f.ma;
      switch (f.type) {
        case 0:
          f = dI(0.6875, 0.25, 0, 0.4375);
          lI(f, yI);
          f.translate(0, -0.1875, 0);
          Xt(fI(f), Bo(45));
          var h = dI(0.25, 0.6875, 0.4375, 0);
          lI(h, yI);
          h.translate(0, -0.1875, 0);
          Xt(fI(h), Bo(45));
          var k = dI(0.25, 0.4375, -0.125, 0);
          lI(k, yI);
          e = rI([f, k, h]);
          break;
        case 3:
          f = dI(0.25, g.length, -0.125, 0);
          lI(f, yI);
          e = rI([f]);
          break;
        case 1:
          e = zI(g.Md, g.wd, 0, 0.25, 8);
          break;
        case 2:
          e = zI(g.Md, g.wd, 0.1875, 0.4375, 16);
          break;
        case 4:
          (f = Bo(g.di)),
            (h = dI(0.25, g.length, -0.125, -g.length)),
            Xt(fI(h), f),
            (k = dI(0.25, g.length, -0.125, -g.length)),
            Xt(fI(k), -f),
            (e = rI([h, k]));
      }
      c.push(e);
      tI(e);
      d && uI(e);
      vI(e, g.La, g.Ma, g.angle || 0);
    });
    a = rI([], c);
    b = wI(a);
    sI(b, (f) => {
      lI(f, rK);
      f.scale(1.05, 1.05, 1);
      f.translate(-0.02, 0, -0.02);
    });
    return rI([], [b, a]);
  }
  function pK(a, b) {
    var c = Bo(-a.G);
    DI(hj(a.M), sK);
    sI(b, (d) => {
      Wt(fI(d), c);
      d.translate(0, -1, -8);
      Vt(fI(d), Bo(-90));
      d = fI(d);
      Jt(sK, d, d);
    });
  }
  var tK = class {
      constructor(a, b) {
        this.H = a;
        this.context = b;
        this.I = new Fv();
        this.A = null;
        this.K = (c, d) => {
          this.H.Cd(c, d);
        };
        this.B = this.J = "";
        this.M = new U();
        this.G = this.C = this.F = 0;
        this.enabled = !1;
        this.D = null;
      }
      Qb(a) {
        this.B = a.lj;
        this.F = a.direction;
        this.C = a.type;
        this.G = a.heading;
        OG(this);
        nK(this);
      }
      le(a) {
        this.D = a;
        nK(this);
      }
      run() {
        this.enabled &&
          !this.context.B &&
          this.A.render(this.I, this.context, this.K, this.H.mb());
      }
      setCamera(a) {
        this.enabled && mu(a, this.I);
      }
    },
    rK = [0, 0, 0, 0.9],
    sK = Ct(),
    uK = Bo(24),
    vK = Bo(50),
    wK = Bo(145),
    qK = {
      [0]: [],
      [1]: [
        { type: 3, ma: { angle: 0, La: 0, Ma: 0, length: 1.175 } },
        { type: 0, ma: { angle: 0, La: 0, Ma: 1.175 } },
      ],
      [2]: [
        {
          type: 4,
          ma: { La: 0, Ma: Math.cos(uK) * 0.85625, di: 24, length: 0 },
        },
        {
          type: 3,
          ma: { angle: 0, La: 0, Ma: Math.cos(uK) * 0.85625, length: 0.5 },
        },
        { type: 0, ma: { angle: 0, La: 0, Ma: Math.cos(uK) * 0.85625 + 0.5 } },
      ],
      [3]: [
        { type: 3, ma: { angle: 0, La: 0, Ma: 0, length: 0.85625 } },
        { type: 1, ma: { Md: 0, wd: 90, La: -0.125, Ma: 0.85625 } },
        { type: 3, ma: { angle: 90, La: -0.125, Ma: 0.98125, length: 0.5 } },
        { type: 0, ma: { angle: 90, La: -0.625, Ma: 0.98125 } },
      ],
      [4]: [
        { type: 3, ma: { angle: 0, La: 0, Ma: 0, length: 1.175 } },
        { type: 1, ma: { Md: 90, wd: -55, La: -0.125, Ma: 1.175 } },
        {
          type: 3,
          ma: {
            angle: 145,
            La: -0.125 + Math.cos(wK) * 0.125,
            Ma: 0.125 * Math.sin(wK) + 1.175,
            length: 0.65,
          },
        },
        {
          type: 0,
          ma: {
            angle: 145,
            La: -0.125 + Math.cos(wK) * 0.125 - Math.sin(wK) * 0.65,
            Ma: 0.125 * Math.sin(wK) + 1.175 + Math.cos(wK) * 0.65,
          },
        },
      ],
      [5]: [
        { type: 3, ma: { angle: 0, La: 0, Ma: 0, length: 0.85625 } },
        { type: 1, ma: { Md: 90, wd: 40, La: -0.125, Ma: 0.85625 } },
        {
          type: 3,
          ma: {
            angle: 50,
            La: -0.125 + Math.cos(vK) * 0.125,
            Ma: 0.125 * Math.sin(vK) + 0.85625,
            length: 0.5,
          },
        },
        {
          type: 0,
          ma: {
            angle: 50,
            La: -0.125 + Math.cos(vK) * 0.125 - Math.sin(vK) * 0.5,
            Ma: 0.125 * Math.sin(vK) + 0.85625 + Math.cos(vK) * 0.5,
          },
        },
      ],
      [9]: [
        { type: 3, ma: { angle: 0, La: 0, Ma: 0, length: 1.525 } },
        { type: 2, ma: { Md: 0, wd: 90, La: -0.3125, Ma: 1.525 } },
        {
          type: 3,
          ma: { angle: 90, La: -0.3125, Ma: 1.8375, length: 0.85625 },
        },
        { type: 2, ma: { Md: 0, wd: -90, La: -1.16875, Ma: 1.525 } },
        { type: 3, ma: { angle: 180, La: -1.48125, Ma: 1.525, length: 0.725 } },
        { type: 0, ma: { angle: 180, La: -1.48125, Ma: 1.525 - 0.725 } },
      ],
    };
  qK[6] = qK[3];
  qK[7] = qK[3];
  qK[8] = qK[3];
  function xK(a, b, c, d) {
    var e = null;
    if (a.F)
      a.F.getNavigationArrowTargetAt(b, c, (f) => {
        if (f)
          for (let g of a.B) {
            let h = g.target;
            if (h.va() === f) {
              e = h;
              break;
            }
          }
        d(e);
      });
    else {
      let f = a.D.K;
      for (let g = 0; g < a.B.length; g++)
        if ((Dt(hI, a.D.P), gI(a.B[g].shape, b, c, f))) {
          e = a.B[g].target;
          break;
        }
      d(e);
    }
  }
  var AK = class {
      constructor(a, b) {
        this.G = a;
        this.context = b;
        this.A = new Fv();
        this.D = new lK();
        this.C = null;
        this.H = (c, d) => {
          this.G.Cd(c, d);
        };
        this.B = [];
        this.F = null;
      }
      run() {
        this.B.length !== 0 &&
          this.D.render(this.A, this.context, this.H, this.G.mb());
      }
      setCamera(a) {
        mu(a, this.A);
        var b = this.A.Pa,
          c = this.A.Qa,
          d = this.A.cb,
          e = this.A.eb,
          f = this.A.fb - this.A.Ra,
          g = d - b,
          h = e - c,
          k = f - 0,
          l = Ct(),
          m = Y(),
          n = Y();
        rt(m, b, c, 0);
        Yt(m, m);
        rt(n, d, e, f);
        Yt(n, n);
        xt(m, yK);
        Qt(l, m, n, yK);
        Kt(l, l);
        Ft(l, 2, zK);
        Ft(l, 1, yK);
        vt(zK, 240 / a.Ga(), zK);
        vt(yK, 0.5, yK);
        tt(m, zK, m);
        tt(m, yK, m);
        $t(m, m);
        a = zv(this.A);
        a.A = m[0];
        a.B = m[1];
        a.I = m[2];
        a.F = m[0] + g;
        a.G = m[1] + h;
        a.H = m[2] + k;
        nu(this.A, a);
      }
      ke(a) {
        if (a && !(this.C && a.Ab() && vh(a.Ab().ha(), this.C.Ab().ha()))) {
          var b = a.Za();
          if (b) {
            this.C = a;
            this.B = [];
            this.D.A = [];
            DI(hj(b.oa()), hI);
            a = df(b, VA, 20);
            for (let g = 0; g < a; g++) {
              let h = ff(b, 20, VA, g);
              if (!mA(B(h, UA, 5))) continue;
              var c = [
                  0, 0, 0, 1, 0.6, 0, 1, 0, 0, 0, -0.6, 0, -1, 0, 0, -1, 0.6, 0,
                ],
                d = new bI();
              lI(d, [0.9, 0.9, 0.9, 1]);
              var e = d,
                f = new Float32Array(c);
              e.vertices = f;
              Vt(fI(d), Math.PI / 2);
              mI(d, 0.15);
              f = new bI();
              lI(f, [0, 0, 0, 0.6]);
              e = f;
              c = new Float32Array(c);
              e.vertices = c;
              Vt(fI(f), Math.PI / 2);
              mI(f, 0.15);
              f.translate(0, 0, 0.15);
              d = [f, d];
              c = new bI();
              kI(c, d);
              aK(this.D, d);
              e = D(h, 1);
              Dt(fI(c), hI);
              lj(this.C.Xa()) &&
                ((f = jj(this.C.Xa()).Ba()),
                Wt(fI(c), Bo(-f)),
                Vt(fI(c), Bo(45)),
                Wt(fI(c), Bo(f)));
              Wt(fI(c), Bo(-e));
              c.translate(0, 0, -0.35);
              for (c = 0; c < d.length; c++)
                this.B.push({ shape: d[c], target: B(h, UA, 5) });
            }
          }
        }
      }
      le(a) {
        this.F = a;
      }
    },
    zK = Y(),
    yK = Y(),
    hI = Ct();
  function BK(a) {
    var b = new bI();
    lI(b, [0, 0, 0, 0.4]);
    var c = new Float32Array([
      0, 0, 0, 1, 1, 0, 1, 0, 0, 0, -1, 0, -1, 0, 0, -1, 1, 0,
    ]);
    b.vertices = c;
    b.translate(0, 0, 0.01);
    mI(b, 0.5);
    c = aI();
    lI(c, [0, 0, 0, 0.1]);
    c.translate(0, 0, 0.001);
    mI(c, 0.92);
    var d = aI();
    lI(d, [1, 1, 1, 0.4]);
    Vt(fI(d), Math.PI / 2);
    kI(d, [c, b]);
    aK(a, [d, c, b]);
    return d;
  }
  function CK(a, b, c, d) {
    bu(a[0], a[1], a[2], DK);
    DK[0] = Co(DK[0]);
    DK[1] = Co(DK[1]);
    vt(b, cu(DK[1]), d);
    tt(a, d, d);
    Yt(d, d);
    ut(d, c, d);
    xt(d, d);
  }
  function TG(a) {
    a = a.enabled && a.M ? a.C.dir : null;
    return !!a && a[2] <= 0.85 && a[2] >= -0.85;
  }
  function xF(a, b) {
    (a.enabled = b) ? EK(a, a.D.S() / 2, a.D.R() / 2) : Ix(a.V);
    FK(a);
  }
  function GK(a) {
    var b = cI();
    lI(b, [1, 1, 1, 0.4]);
    var c = [0, 0, 0, 0.4];
    b.A || (b.A = [1, 1, 1, 1]);
    b.A[0] = c[0];
    b.A[1] = c[1];
    b.A[2] = c[2];
    b.A[3] = c[3];
    Vt(fI(b), Math.PI / 2);
    b.scale(3.23606798, 2, 1);
    a.add(b);
    return b;
  }
  function HK(a) {
    var b = [0, 0, 0, 0.1],
      c = [1, 1, 1, 0.3],
      d = cI();
    lI(d, b);
    d.scale(1.9, 0.15, 1);
    var e = cI();
    lI(e, b);
    e.translate(0, 0.5125, 0);
    e.scale(0.15, 0.875, 1);
    var f = cI();
    lI(f, b);
    f.translate(0, -0.5125, 0);
    f.scale(0.15, 0.875, 1);
    b = cI();
    lI(b, c);
    b.scale(2, 0.25, 1);
    b.translate(0, 0, 0.001);
    var g = cI();
    lI(g, c);
    g.translate(0, 0.5625, 0.001);
    g.scale(0.25, 0.875, 1);
    var h = cI();
    lI(h, c);
    h.translate(0, -0.5625, 0.001);
    h.scale(0.25, 0.875, 1);
    c = [d, e, f, b, g, h];
    aK(a, c);
    a = new bI();
    Vt(fI(a), Math.PI / 2);
    Xt(fI(a), Math.PI / 4);
    kI(a, c);
    return a;
  }
  function EK(a, b, c) {
    a.x = b;
    a.y = c;
    var d = a.x,
      e = a.y,
      f = a.G;
    c = !1;
    b = !!f.Vd(d, e, a.C);
    var g = IK(a.C.dir),
      h = a.na;
    f !== void 0 && f.Fe(d, e, h)
      ? (a.A || (a.A = new UA()),
        y(a.A, h),
        mx(a.B) && g && lA(a.A, Z(a.B.Ia())) && (c = !0))
      : (c = !0);
    e = a.B && a.B.Za();
    a.F = !!e && C(e, 30);
    c &&
      a.B &&
      (e
        ? ((c = Ao(-Co(a.D.ac))),
          (a.A = OF(c, e)),
          a.A &&
            ((d = a.A.ja()),
            (f = a.A.va()),
            JK(a, d),
            kB(a.B.Yb(), f, d),
            (f = hj(e.oa())),
            (e = c),
            (c = f),
            (d = ij(d)),
            Pf(d, 2) ||
              Pf(d, 3) ||
              ((e = (e * Math.PI) / 180),
              (f = Math.sin(e)),
              (g = 180 / Math.PI / 6371010),
              (h = g / Math.cos(Zi(c))),
              Yi($i(d, Zi(c) + 40 * g * Math.cos(e)), Xi(c) + 40 * h * f))))
        : (a.A = null));
    a.A && JK(a, a.A.ja());
    a.M = !!a.A && b;
    Ix(a.V);
  }
  function FK(a) {
    if (a.N) for (let b of a.P) b.Je && b.Je.fd(a.enabled && !eI(b.Uf));
  }
  function SG(a) {
    return a.O ? a.lookAt : null;
  }
  function JK(a, b) {
    mx(a.B) &&
      (((a.O = !1), TG(a))
        ? a.C.origin && ((a.O = !0), st(a.lookAt, a.C.origin))
        : bf(b, 2));
  }
  var LK = class {
      constructor(a, b, c) {
        this.V = a;
        this.G = b;
        this.context = c;
        this.D = new Fv();
        this.enabled = !0;
        this.F = this.M = !1;
        this.C = new xv();
        this.lookAt = Y();
        this.O = !1;
        this.W = new xv();
        this.y = this.x = 0;
        this.A = this.B = null;
        this.L = !0;
        this.sa = Y();
        this.ea = Y();
        this.Da = Y();
        this.Ca = Y();
        this.ga = Y();
        this.ua = Y();
        this.na = new UA();
        this.I = this.J = this.H = null;
        this.P = [];
        this.N = !1;
        this.aa = (d, e) => {
          this.G.Cd(d, e);
        };
        a = new lK();
        this.T = BK(a);
        this.Z = GK(a);
        this.target = HK(a);
        this.K = a;
      }
      setCamera(a) {
        mu(a, this.D);
      }
      run() {
        if (this.enabled) {
          {
            var a = this.B,
              b = a && a.Za();
            var c = this.target;
            let r = this.Z,
              t = this.T;
            r.transform.hidden = !0;
            t.transform.hidden = !0;
            var d = this.C.origin;
            let v = this.C.dir;
            var e = this.A && this.A.oa();
            if (mx(a) && e && d && v) {
              this.K && this.K.Z(a.hc());
              a = this.sa;
              var f = this.ea,
                g = this.ga,
                h = this.Da,
                k = this.ua,
                l = this.Ca,
                m = hj(b.oa());
              du(Xi(m), Zi(m), aj(m), a);
              e = hj(e);
              au(Xi(e), Zi(e), aj(e) - D(b, 24), h);
              let F = this.G;
              b = this.D;
              var n = Y();
              let H = b.M;
              H[0] = h[0];
              H[1] = h[1];
              H[2] = h[2];
              H[3] = 1;
              var q = b.A;
              Av(b);
              Dt(q, b.J);
              Nt(b.A, H, H);
              q = 1 / H[3];
              H[0] *= q;
              H[1] *= q;
              H[2] *= q;
              Ev(b, H, n);
              F !== void 0
                ? (F.Vd(n[0], n[1], this.W),
                  (b = this.W.dir),
                  rt(k, b[0], b[1], b[2]),
                  IK(k) || rt(k, 0, 0, 1))
                : rt(k, 0, 0, 1);
              Yt(h, h);
              Yt(d, f);
              CK(d, v, f, g);
              CK(d, k, f, k);
              xt(f, l);
              IK(this.enabled && this.M ? this.C.dir : null)
                ? (ut(h, a, KK),
                  yt(KK, l, DK),
                  yt(g, DK, KK),
                  tt(KK, f, KK),
                  t.lookAt(f, KK, l),
                  this.H && this.H.update(f, this.F ? 0.4 : 1, m, e, null),
                  this.F && Ut(fI(t), 0.4, 0.4, 0.4),
                  eA(Z(this.B.Ia())) || (t.transform.hidden = !1))
                : TG(this) &&
                  (r.lookAt(f, g, l),
                  (d = Math.sqrt(zt(f, a))),
                  (d = xo(this.F ? 0.4 : 1, d / 5, d / 50)),
                  Ut(fI(r), d, d, d),
                  (r.transform.hidden = !1),
                  this.J && this.J.update(f, d, m, null, g));
              c.transform.hidden = !1;
              this.L ||
                ((r.transform.hidden = !0),
                (t.transform.hidden = !0),
                (c.transform.hidden = !0));
              ut(h, a, KK);
              yt(KK, l, DK);
              yt(k, DK, KK);
              tt(KK, h, KK);
              c.lookAt(h, KK, l);
              this.F && Ut(fI(c), 0.4, 0.4, 0.4);
              this.I && this.I.update(h, this.F ? 0.4 : 1, m, null, null, 45);
              c = !0;
            } else c = !1;
          }
          c &&
            !this.N &&
            this.K.render(this.D, this.context, this.aa, this.G.mb());
          FK(this);
        }
      }
      le(a) {
        this.N = !0;
        this.H = a.getCursor(1);
        this.J = a.getCursor(2);
        this.I = a.getCursor(3);
        this.P = [
          { Uf: this.T, Je: this.H },
          { Uf: this.Z, Je: this.J },
          { Uf: this.target, Je: this.I },
        ];
      }
      clear() {
        this.A = this.B = null;
      }
    },
    DK = Y(),
    KK = Y();
  function IK(a) {
    return !!a && a[2] > 0.85;
  }
  var MK = class {
    constructor(a) {
      this.A = a;
      this.B = [];
    }
    addEventListener(a, b) {
      this.B.push({ type: a, listener: b });
      this.A.addEventListener(a, b, !1);
    }
    removeEventListener(a, b) {
      for (let c = 0; c < this.B.length; c++)
        if (b === this.B[c].listener && a === this.B[c].type) {
          this.B.splice(c, 1);
          break;
        }
      this.A.removeEventListener(a, b, !1);
    }
    dispatchEvent(a) {
      var b = 0;
      for (let c = 0; c < this.B.length; c++)
        if (a.type === this.B[c].type) {
          let d = this.B[c].listener;
          typeof d === "function" ? d(a) && b++ : d.handleEvent(a) && b++;
        }
      return !!b;
    }
    dispose() {
      [...this.B].forEach((a) => {
        this.removeEventListener(a.type, a.listener);
      });
    }
  };
  var NK = class extends MK {
    constructor(a = Js(document, "CANVAS")) {
      super(a);
      this.C = 1;
    }
    D() {
      return this.A;
    }
  };
  var OK = class {
    constructor() {
      this.A = this.preserveDrawingBuffer = !1;
    }
  };
  var PK = 0;
  function QK(a = new OK()) {
    a = {
      alpha: !0,
      stencil: !0,
      preserveDrawingBuffer: a.preserveDrawingBuffer,
      failIfMajorPerformanceCaveat: !a.A && !0,
    };
    nb("Firefox") <= 24 && (a.preserveDrawingBuffer = !0);
    return a;
  }
  function RK(a, b = new OK()) {
    var c = QK(b),
      d = SK,
      e = d(a, c, b);
    if (
      !e &&
      c.failIfMajorPerformanceCaveat &&
      ((c.failIfMajorPerformanceCaveat = !1), d(a, c, b))
    )
      return (PK = 10), null;
    if (!e || !e.getExtension || !e.getParameter) return (PK = 1), null;
    e.getExtension("WEBGL_debug_renderer_info")
      ? ((TK = e.getParameter(37446)), (UK = VK()))
      : (UK = TK = null);
    e.getExtension("WEBGL_compressed_texture_astc");
    c =
      typeof WebGL2RenderingContext !== "undefined" &&
      e instanceof WebGL2RenderingContext;
    if (e.drawingBufferWidth !== a.width || e.drawingBufferHeight !== a.height)
      return (PK = 2), null;
    if (e.getParameter(35660) < 4) return (PK = 3), null;
    e.getParameter(3379);
    if (e.getShaderPrecisionFormat(35632, 36338).precision < 23)
      return (PK = 4), null;
    a = UK;
    d = TK;
    d = d == null ? null : !(d.indexOf("ANGLE Metal") < 0);
    if (cb() && !a) return (PK = 8), null;
    if (
      !b.A &&
      a &&
      ((a === "Intel Q45" && (cb() || db())) ||
        (c && a.startsWith("AMD") && fb() && w("Macintosh") && !d) ||
        WK.indexOf(a) !== -1)
    )
      return (PK = 5), null;
    PK = 0;
    return e;
  }
  var TK, UK;
  function SK(a, b) {
    var c = null,
      d = ["webgl", "experimental-webgl", "moz-webgl"];
    for (let e of d) {
      try {
        c = a.getContext(e, b);
      } catch (f) {}
      if (c) return c;
    }
    return null;
  }
  function VK() {
    var a = TK;
    if (a === void 0) return null;
    a = a.toLowerCase();
    var b = a.match(/angle \((.*)\)/);
    b && ((a = b[1]), (a = a.replace(/\s*direct3d.*$/, "")));
    a = a.replace(/\s*\([^\)]*wddm[^\)]*\)/, "");
    if (
      (b = a.indexOf("swiftshader") < 0 ? null : "swiftshader") ||
      (b = a.indexOf("llvmpipe") < 0 ? null : "llvmpipe")
    )
      return b;
    var c = a;
    c.indexOf("intel") < 0
      ? (b = null)
      : ((b = ["Intel"]),
        c.indexOf("mobile") >= 0 && b.push("Mobile"),
        (c.indexOf("gma") >= 0 ||
          c.indexOf("graphics media accelerator") >= 0) &&
          b.push("GMA"),
        c.indexOf("haswell") >= 0
          ? b.push("Haswell")
          : c.indexOf("ivy") >= 0
          ? b.push("HD 4000")
          : c.indexOf("sandy") >= 0
          ? b.push("HD 3000")
          : c.indexOf("ironlake") >= 0
          ? b.push("HD")
          : (c.indexOf("hd") >= 0 && b.push("HD"),
            (c = c.match(XK)) && b.push(c[1].toUpperCase())),
        (b = b.join(" ")));
    if (b) return b;
    b = a;
    if (
      b.indexOf("nvidia") < 0 &&
      b.indexOf("quadro") < 0 &&
      b.indexOf("geforce") < 0 &&
      b.indexOf("nvs") < 0
    )
      b = null;
    else {
      c = ["nVidia"];
      b.indexOf("geforce") >= 0 && c.push("geForce");
      b.indexOf("quadro") >= 0 && c.push("Quadro");
      b.indexOf("nvs") >= 0 && c.push("NVS");
      b.match(/\bion\b/) && c.push("ION");
      b.match(/gtx\b/)
        ? c.push("GTX")
        : b.match(/gts\b/)
        ? c.push("GTS")
        : b.match(/gt\b/)
        ? c.push("GT")
        : b.match(/gs\b/)
        ? c.push("GS")
        : b.match(/ge\b/)
        ? c.push("GE")
        : b.match(/fx\b/) && c.push("FX");
      var d = b.match(XK);
      d && c.push(d[1].toUpperCase().replace("GS", ""));
      b.indexOf("titan") >= 0
        ? c.push("TITAN")
        : b.indexOf("ti") >= 0 && c.push("Ti");
      b = c.join(" ");
    }
    if (b) return b;
    c = a;
    c.indexOf("amd") < 0 &&
    c.indexOf("ati") < 0 &&
    c.indexOf("radeon") < 0 &&
    c.indexOf("firegl") < 0 &&
    c.indexOf("firepro") < 0
      ? (b = null)
      : ((b = ["AMD"]),
        c.indexOf("mobil") >= 0 && b.push("Mobility"),
        (d = c.indexOf("radeon")),
        d >= 0 && b.push("Radeon"),
        c.indexOf("firepro") >= 0
          ? b.push("FirePro")
          : c.indexOf("firegl") >= 0 && b.push("FireGL"),
        c.indexOf("hd") >= 0 && b.push("HD"),
        (c = (d >= 0 ? c.substring(d) : c).match(XK)) &&
          b.push(c[1].toUpperCase().replace("HD", "")),
        (b = b.join(" ")));
    if (b) return b;
    c = a;
    c.indexOf("qualcomm") < 0
      ? (b = null)
      : ((b = ["Qualcomm"]),
        c.indexOf("adreno") >= 0 && b.push("Adreno"),
        (c = c.match(XK)) && b.push(c[1].toUpperCase()),
        (b = b.join(" ")));
    return b ? b : a.substring(0, 100);
  }
  var XK = /([a-z0-9]*\d+[a-z0-9]*)/,
    WK =
      "swiftshader;software adapter;llvmpipe;microsoft basic render driver;vmware svga 3d;Intel 965GM;Intel B43;Intel G41;Intel G45;Intel G965;Intel GMA 3600;Intel Mobile 4;Intel Mobile 45;Intel Mobile 965;Qualcomm Adreno 680".split(
        ";"
      );
  function YK(a) {
    a.context === null && (a.context = a.F(a.A));
    return a.context;
  }
  var ZK = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var $K = (function (a) {
    var b = !1,
      c;
    return function () {
      b || ((c = a()), (b = !0));
      return c;
    };
  })(() => {
    var a = ["fontBoundingBoxAscent", "fontBoundingBoxDescent"];
    return (
      typeof TextMetrics === "function" &&
      a.every((b) => TextMetrics.prototype.hasOwnProperty(b))
    );
  });
  function aL(a) {
    var b = { Id: void 0 },
      c = new bL();
    c.Mf = !!b.Mf && !b.Id;
    c.postMessage = (d, e) => {
      a.postMessage(d, e || []);
    };
    a.onmessage = (d) => {
      cL(c, d.data, b.Id);
    };
  }
  function cL(a, b, c = dL) {
    var d = (f) => {
        try {
          f();
        } catch (g) {
          a.postMessage({
            command: 8,
            requestId: b.requestId,
            payload: { result: -1, resultMessage: g.message },
          });
        }
      },
      e = (f) => {
        c(() => {
          d(f);
        });
      };
    d(() => {
      switch (b.command) {
        case 1:
          eL(a, "lftmr0");
          fL(a, b, () => {
            e(() => {
              gL(a, b.requestId, b.payload.style);
              hL(
                a,
                b.requestId,
                b.payload.onlyWidths,
                b.payload.texts,
                b.payload.style.lineWidth || 0
              );
              eL(a, "lftmr1");
            });
          });
          break;
        case 11:
          eL(a, "lftmr0");
          fL(a, b, () => {
            var g = new Float32Array(b.payload.length * 9),
              h = b.payload.reduce((q, r) => q + r.glyphs.length, 0),
              k = new Float32Array(h * 7),
              l = b.payload,
              m = 0,
              n = (h = 0);
            for (let q of l) {
              let r = h,
                t = n;
              h += 9;
              n += q.glyphs.length * 7;
              e(() => {
                gL(a, b.requestId, q.style);
                a.getFontAndTextMetrics(
                  b.requestId,
                  q,
                  q.style.lineWidth || 0,
                  g,
                  r,
                  k,
                  t
                );
                m++;
                m === l.length &&
                  (eL(a, "lftmr1"),
                  a.postMessage(
                    {
                      command: 12,
                      requestId: b.requestId,
                      payload: { textMeasurements: g, glyphMeasurements: k },
                    },
                    [g.buffer, k.buffer]
                  ));
              });
            }
          });
          break;
        case 2:
          a.prepareFont(b.requestId, b.payload.font, b.payload.text, b.command);
          break;
        case 9:
          fL(a, b, () => {
            e(() => {
              gL(a, b.requestId, b.payload.style);
              a.getFontInfo(b.requestId);
            });
          });
          break;
        case 3:
          a.destroyCanvas(b.requestId);
          break;
        case 4:
          e(() => {
            a.createCanvas(b.requestId, b.payload.size.x, b.payload.size.y);
          });
          break;
        case 5:
          eL(a, "lfdr0");
          let f = performance.now();
          fL(a, b, () => {
            for (let g of b.payload.commands)
              e(() => {
                var h = b.requestId;
                switch (g.type) {
                  case 1:
                    gL(a, h, g.payload.style);
                    a.drawText(
                      h,
                      g.payload.text,
                      g.payload.pos.x,
                      g.payload.pos.y,
                      g.payload.horizontalAlignment,
                      g.payload.verticalAlignment,
                      g.payload.style.lineWidth ?? 0,
                      g.payload.horizontalRenderScale
                    );
                    break;
                  case 2:
                    gL(a, h, g.payload.style);
                    a.drawRoundedRect(
                      h,
                      g.payload.cornerRadius.x,
                      g.payload.cornerRadius.y,
                      g.payload.pos.x,
                      g.payload.pos.y,
                      g.payload.size.x,
                      g.payload.size.y
                    );
                    break;
                  case 3:
                    a.clearRect(
                      h,
                      g.payload.pos.x,
                      g.payload.pos.y,
                      g.payload.size.x,
                      g.payload.size.y
                    );
                }
              });
            e(() => {
              a.requestDraw(b.requestId, f, b.payload.textureId);
            });
          });
          break;
        case 13:
          a.featureFlags = { ...a.featureFlags, ...b.payload.featureFlags };
          a.postMessage({
            command: 8,
            requestId: b.requestId,
            payload: { result: 0, resultMessage: "" },
          });
          break;
        case 15:
          iL(a, b);
      }
    });
  }
  function eL(a, b) {
    a.featureFlags.enableLabelerTimingTicks &&
      !jL.has(b) &&
      (jL.add(b), performance.mark(b));
  }
  function fL(a, b, c) {
    if (a.Mf) c();
    else {
      var d = new Map(),
        e = (g, h) => {
          d.set(`${g}::${h}`, { font: g, text: h });
        };
      if (b.command === 1)
        b.payload.style.font &&
          e(b.payload.style.font, b.payload.texts.join(""));
      else if (b.command === 5)
        for (var f of b.payload.commands)
          f.type === 1 &&
            f.payload.style.font &&
            e(f.payload.style.font, f.payload.text);
      else if (b.command === 9)
        b.payload.style.font && e(b.payload.style.font, " ");
      else if (b.command === 11)
        for (let g of b.payload)
          g.style.font && e(g.style.font, g.text + g.glyphs.join(""));
      e = [];
      f = d.values();
      for (let g of f) e.push(kL(a, g.font, g.text, b.command));
      e.length ? Promise.allSettled(e).finally(c) : c();
    }
  }
  function gL(a, b, c) {
    b = b.sourceId;
    var d = a.D.get(b),
      e = c.locale || "",
      f = c.font || "",
      g = c.letterSpacing || "",
      h = c.strokeStyle || "";
    c = c.fillStyle || "";
    if (
      !d ||
      d.font !== f ||
      d.letterSpacing !== g ||
      d.strokeStyle !== h ||
      d.fillStyle !== c ||
      d.locale !== e
    ) {
      var k = a.getContext(b);
      (d && d.locale === e) ||
        (k.canvas instanceof HTMLCanvasElement && (k.canvas.lang = e),
        "lang" in k && (k.lang = e));
      (d && d.font === f) || (k.font = f);
      (d && d.letterSpacing === g) || (k.letterSpacing = g);
      (d && d.strokeStyle === h) || (k.strokeStyle = h);
      (d && d.fillStyle === c) || (k.fillStyle = c);
      a.D.set(b, {
        locale: e,
        font: f,
        letterSpacing: g,
        strokeStyle: h,
        fillStyle: c,
      });
    }
  }
  function hL(a, b, c, d, e) {
    var f = c ? (k, l) => [a.B(k, l).width] : (k, l) => lL(a.B(k, l), e);
    c = c ? 1 : 7;
    var g = new Float32Array(d.length * c),
      h = a.getContext(b.sourceId);
    h.textAlign = "left";
    h.textBaseline = "alphabetic";
    h.direction = mL(d.join("")) ? "rtl" : "ltr";
    for (let k = 0; k < d.length; k++) g.set(f(h, d[k]), k * c);
    a.postMessage({ command: 6, requestId: b, payload: { measurements: g } }, [
      g.buffer,
    ]);
  }
  function iL(a, b) {
    if (b.texts) for (let c of b.texts) a.F.delete(c);
  }
  function kL(a, b, c, d) {
    var e = u.fonts || u.document?.fonts;
    if (!e) return Promise.resolve();
    eL(a, "lffr0");
    var f = performance.now(),
      g = () => {
        eL(a, "lffr1");
        if (a.featureFlags.enableLabelPrepProfileLogging)
          try {
            performance.measure(
              `${d === 5 ? "Load Font (Draw)" : "Load Font (Non-Draw)"}`,
              { start: f }
            );
          } catch (h) {}
      };
    return c && c.length > 0 ? e.load(b, c).then(g) : e.load(b).then(g);
  }
  function lL(a, b) {
    var c = Math.max(a.actualBoundingBoxDescent, a.fontBoundingBoxDescent);
    return [
      -a.actualBoundingBoxLeft,
      -a.actualBoundingBoxDescent,
      a.actualBoundingBoxLeft + a.actualBoundingBoxRight + b,
      a.actualBoundingBoxAscent + a.actualBoundingBoxDescent + b,
      a.width,
      -c,
      Math.max(a.actualBoundingBoxAscent, a.fontBoundingBoxAscent) + c + b,
    ];
  }
  function nL(a, b, c, d, e) {
    var f = performance.now(),
      g = [];
    for (let h = 0; h < d.length; h += 4) {
      let [k, l, m, n] = d.slice(h, h + 4);
      g.push(
        createImageBitmap(c, k, l, m, n, {
          premultiplyAlpha: "none",
          colorSpaceConversion: "none",
        })
      );
    }
    Promise.all(g).then((h) => {
      if (a.featureFlags.enableLabelPrepProfileLogging)
        try {
          performance.measure(
            "Label Prep: GetGlyphs: Render Text: Upload Pixels to GlTexture",
            { start: f }
          );
        } catch (l) {}
      var k = Uint32Array.from(d);
      a.postMessage(
        {
          command: 14,
          requestId: b,
          payload: { dirtyRects: k, bitmaps: h, textureId: e },
        },
        [...h, k.buffer]
      );
    });
  }
  function oL(a, b, c, d) {
    var e = performance.now();
    createImageBitmap(c, {
      premultiplyAlpha: "none",
      colorSpaceConversion: "none",
    }).then((f) => {
      if (a.featureFlags.enableLabelPrepProfileLogging)
        try {
          performance.measure(
            "Label Prep: GetGlyphs: Render Text: Upload Pixels to GlTexture",
            { start: e }
          );
        } catch (h) {}
      var g = new Uint32Array([0, 0, c.width, c.height]);
      a.postMessage(
        {
          command: 14,
          requestId: b,
          payload: { dirtyRects: g, bitmaps: [f], textureId: d },
        },
        [f, g.buffer]
      );
    });
  }
  var bL = class {
      constructor() {
        this.C = new Map();
        this.A = new Map();
        this.D = new Map();
        this.F = new Map();
        this.postMessage = () => {};
        this.Mf = !1;
        this.featureFlags = {};
        this.B = $K()
          ? (a, b) => {
              var c = performance.now();
              a = a.measureText(b);
              if (this.featureFlags.enableLabelPrepProfileLogging)
                try {
                  performance.measure("Measure Text", { start: c });
                } catch (d) {}
              return {
                width: a.width,
                actualBoundingBoxLeft: a.actualBoundingBoxLeft,
                actualBoundingBoxRight: a.actualBoundingBoxRight,
                fontBoundingBoxAscent: a.fontBoundingBoxAscent,
                fontBoundingBoxDescent: a.fontBoundingBoxDescent,
                actualBoundingBoxAscent: a.actualBoundingBoxAscent,
                actualBoundingBoxDescent: Math.ceil(a.actualBoundingBoxDescent),
              };
            }
          : (a, b) => {
              var c = performance.now();
              a = a.measureText(b);
              if (this.featureFlags.enableLabelPrepProfileLogging)
                try {
                  performance.measure("Measure Text", { start: c });
                } catch (d) {}
              return {
                width: a.width,
                actualBoundingBoxLeft: a.actualBoundingBoxLeft,
                actualBoundingBoxRight: a.actualBoundingBoxRight,
                fontBoundingBoxAscent: a.actualBoundingBoxAscent,
                fontBoundingBoxDescent: a.actualBoundingBoxDescent,
                actualBoundingBoxAscent: a.actualBoundingBoxAscent,
                actualBoundingBoxDescent: Math.ceil(a.actualBoundingBoxDescent),
              };
            };
      }
      prepareFont(a, b, c, d) {
        (u.fonts || u.document?.fonts)?.size === 0
          ? this.postMessage({
              command: 8,
              requestId: a,
              payload: { result: 0, resultMessage: "" },
            })
          : kL(this, b, c, d)
              .then(() => {
                this.postMessage({
                  command: 8,
                  requestId: a,
                  payload: { result: 0, resultMessage: "" },
                });
              })
              .catch((e) => {
                this.postMessage({
                  command: 8,
                  requestId: a,
                  payload: { result: -1, resultMessage: e.message },
                });
              });
      }
      getFontInfo(a) {
        var b = this.getContext(a.sourceId);
        b.textAlign = "left";
        b.textBaseline = "alphabetic";
        b.direction = "ltr";
        b = this.B(b, "");
        b = new Float32Array([
          -b.fontBoundingBoxAscent,
          b.fontBoundingBoxDescent,
        ]);
        this.postMessage({ command: 10, requestId: a, payload: { result: b } });
      }
      getFontAndTextMetrics(a, b, c, d, e, f, g) {
        var h = this.getContext(a.sourceId);
        h.textAlign = "left";
        h.textBaseline = "alphabetic";
        h.direction = mL(b.text + b.glyphs.join("")) ? "rtl" : "ltr";
        var k = this.B(h, b.text);
        a = lL(k, c);
        if (b.glyphs.length >= 1) {
          let l = 0;
          for (let m of b.glyphs) {
            b = this.F.get(m);
            b || ((b = new Map()), this.F.set(m, b));
            let n = `${h.font}|${h.letterSpacing || ""}|${h.direction || ""}`,
              q = b.get(n);
            q || ((q = this.B(h, m)), b.set(n, q));
            b = q;
            l += b.width;
            b = lL(b, c);
            f.set(b, g);
            g += b.length;
          }
          a[4] = l;
        }
        c = [-k.fontBoundingBoxAscent, k.fontBoundingBoxDescent];
        d.set(a, e);
        e += a.length;
        d.set(c, e);
      }
      createCanvas(a, b, c) {
        if (typeof OffscreenCanvas === "undefined") {
          var d = document.createElement("canvas");
          d.width = b;
          d.height = c;
        } else d = new OffscreenCanvas(b, c);
        this.C.set(a.sourceId, d);
        this.D.delete(a.sourceId);
      }
      requestDraw(a, b, c) {
        var d = this.C.get(a.sourceId);
        if (d) {
          var e = this.A.get(a.sourceId);
          var f = !this.featureFlags.enableWasmCanvasGlTexture;
          if (e) {
            if (e.length === 0) throw Error("Rects array cannot be empty.");
            if (e.length % 4 !== 0)
              throw Error(
                `Rects array length must be a multiple of 4, got ${e.length}.`
              );
            var g = [];
            for (var h = 0; h < e.length; h += 4) {
              var k = e[h + 2],
                l = e[h + 3];
              if (k < 0 || l < 0)
                throw Error(
                  `Invalid rect dimensions at index ${h}: width ${k}, height ${l} (must be non-negative).`
                );
              if (k === 0 || l === 0) continue;
              let m = e[h],
                n = e[h + 1];
              k = m + k;
              l = n + l;
              let q;
              do {
                q = !1;
                for (let r = 0; r < g.length; r += 4) {
                  let t = g[r],
                    v = g[r + 1],
                    F = t + g[r + 2],
                    H = v + g[r + 3];
                  if (!(k + 16 < t || m - 16 > F || l + 16 < v || n - 16 > H)) {
                    m = Math.min(m, t);
                    n = Math.min(n, v);
                    k = Math.max(k, F);
                    l = Math.max(l, H);
                    g.splice(r, 4);
                    q = !0;
                    break;
                  }
                }
              } while (q);
              g.push(m, n, k - m, l - n);
            }
            e = 0;
            for (h = 0; h < g.length; h += 4) e += g[h + 2] * g[h + 3] * 4;
            if (c !== void 0 && c !== 0) nL(this, a, d, g, c);
            else {
              d = d.getContext("2d", { willReadFrequently: f });
              f = new Uint8ClampedArray(e);
              c = 0;
              e = performance.now();
              for (h = 0; h < g.length; h += 4) {
                let [m, n, q, r] = g.slice(h, h + 4);
                f.set(d.getImageData(m, n, q, r).data, c);
                c += q * r * 4;
              }
              if (this.featureFlags.enableLabelPrepProfileLogging)
                try {
                  performance.measure(
                    "Label Prep: GetGlyphs: Render Text: Extract Pixels",
                    { start: e }
                  );
                } catch (m) {}
              d = Uint32Array.from(g);
              this.postMessage(
                {
                  command: 7,
                  requestId: a,
                  payload: { data: f, dirtyRects: d },
                },
                [f.buffer, d.buffer]
              );
            }
            this.A.delete(a.sourceId);
          } else if (c !== void 0 && c !== 0) oL(this, a, d, c);
          else {
            c = performance.now();
            f = d
              .getContext("2d", { willReadFrequently: f })
              .getImageData(0, 0, d.width, d.height).data;
            if (this.featureFlags.enableLabelPrepProfileLogging)
              try {
                performance.measure(
                  "Label Prep: GetGlyphs: Render Text: Extract Pixels",
                  { start: c }
                );
              } catch (m) {}
            d = new Uint32Array([0, 0, d.width, d.height]);
            this.postMessage(
              { command: 7, requestId: a, payload: { data: f, dirtyRects: d } },
              [f.buffer, d.buffer]
            );
          }
          eL(this, "lfdr1");
          if (b !== void 0 && this.featureFlags.enableLabelPrepProfileLogging)
            try {
              performance.measure("Label Prep: GetGlyphs: Render Text", {
                start: b,
              });
            } catch (m) {}
        } else
          this.postMessage({
            command: 8,
            requestId: a,
            payload: {
              result: -1,
              resultMessage: `The canvas for ${a.sourceId} is not found.`,
            },
          });
      }
      destroyCanvas(a) {
        this.C.delete(a.sourceId);
        this.A.delete(a.sourceId);
        this.D.delete(a.sourceId);
      }
      drawRoundedRect(a, b, c, d, e, f, g) {
        a = this.getContext(a.sourceId);
        a.beginPath();
        a.roundRect(d, e, f, g, { x: b, y: c });
        a.fill();
      }
      drawText(a, b, c, d, e, f, g, h) {
        c /= h;
        var k = this.getContext(a.sourceId, h);
        k.direction = mL(b) ? "rtl" : "ltr";
        switch (e) {
          default:
            k.textAlign = "left";
            break;
          case 1:
            k.textAlign = "center";
            break;
          case 4:
          case 2:
            k.textAlign = "right";
        }
        switch (f) {
          case 0:
            k.textBaseline = "top";
            break;
          case 1:
            k.textBaseline = "middle";
            break;
          default:
            k.textBaseline = "alphabetic";
            break;
          case 3:
            k.textBaseline = "bottom";
        }
        var l = this.B(k, b),
          m = g / 2;
        if (e === 3 || e === 4 || f === 4 || f === 5 || f === 6) {
          switch (e) {
            case 3:
              c += l.actualBoundingBoxLeft + m;
              break;
            case 4:
              c -= l.actualBoundingBoxRight + m;
          }
          switch (f) {
            case 4:
              d += l.actualBoundingBoxAscent + m;
              break;
            case 5:
              d -= l.actualBoundingBoxDescent + m;
              break;
            case 6:
              d +=
                Math.max(l.fontBoundingBoxAscent, l.actualBoundingBoxAscent) +
                m;
          }
        }
        e = performance.now();
        g > 0 && ((k.lineWidth = g), k.strokeText(b, c, d));
        k.fillText(b, c, d);
        if (this.featureFlags.enableLabelPrepProfileLogging)
          try {
            performance.measure("Label Prep: GetGlyphs: Render Text: Draw", {
              start: e,
            });
          } catch (n) {}
        f === 6 &&
          ((k = this.C.get(a.sourceId)),
          (b = Math.max(
            0,
            Math.floor(c - l.actualBoundingBoxLeft - m) * h - 2
          )),
          (f = Math.max(0, Math.floor(d - l.actualBoundingBoxAscent - g) - 2)),
          (c =
            Math.min(
              k.width,
              Math.ceil(c + l.actualBoundingBoxRight + m) * h + 2
            ) - b),
          (d =
            Math.min(
              k.height,
              Math.ceil(d + l.actualBoundingBoxDescent + g) + 2
            ) - f),
          c !== 0 &&
            d !== 0 &&
            (this.A.has(a.sourceId) || this.A.set(a.sourceId, []),
            this.A.get(a.sourceId).push(b, f, c, d)));
      }
      clearRect(a, b, c, d, e) {
        this.getContext(a.sourceId).clearRect(b, c, d, e);
        this.featureFlags.enableWasmCanvasGlTexture &&
          (this.A.has(a.sourceId) || this.A.set(a.sourceId, []),
          this.A.get(a.sourceId).push(b, c, d, e));
      }
      getContext(a, b = 1) {
        var c = this.C.get(a);
        if (!c) throw Error(`The canvas for ${a} does not exist.`);
        a = c.getContext("2d", {
          willReadFrequently: !this.featureFlags.enableWasmCanvasGlTexture,
        });
        a.setTransform(b, 0, 0, 1, 0, 0);
        a.lineJoin = "round";
        return a;
      }
    },
    jL = new Set();
  function mL(a) {
    for (let b = 0; b < a.length; ++b) {
      let c = a.charCodeAt(b);
      if (c >= 1424 && c < 1792) return !0;
    }
    return !1;
  }
  function dL(a) {
    a();
  }
  function pL() {
    var a = new MessageChannel();
    aL(a.port1);
    return a.port2;
  }
  function qL(a, b, c, d, e, f, g, h, k, l = !1, m = null) {
    m = new rL(a, d, m);
    m.init(a, b, c, d, e, f, g, h, null, l, !1, k);
    return m;
  }
  function uF(a, b, c) {
    var d = vF(a, b, c);
    d &&
      (a.ke(d, c),
      (a.jd = null),
      (a.xc = void 0),
      (a.J = dA(b)),
      xF(a.cursor, !a.J),
      wF(a, c),
      sL(
        a,
        b,
        (e, f) => {
          a.M.ke(a.C);
          e && f.Fa("vrp");
        },
        c
      ));
  }
  function QG(a, b, c) {
    a.A &&
      a.A.get((d) => {
        d.Ja()?.Bd()?.Dj(b);
      }, c);
  }
  function eG(a, b) {
    a.ea = b;
    if (a.G && a.B.Ha()) a.B.ka().setActive(b);
    else if ((a = a.Ja()?.Bd())) (b = b?.va()?.A()), a.selectLabel(b ?? "");
  }
  function qG(a, b, c, d) {
    c = tL(a, b, c);
    b = c[0];
    c = c[1];
    EK(a.cursor, b, c);
    var e = a.cursor.A;
    e && (e = e.clone());
    !a.H || !a.W || (e && vh(a.W, e)) || (HE(a.H), (a.H = 0));
    !a.H &&
      e &&
      ((a.W = e),
      (a.H = GE(
        () => {
          (e = a.cursor.A) && vh(a.W, e) && vF(a, e, d).oc(d);
          a.H = 0;
        },
        250,
        d,
        "prd-update-cursor"
      )));
  }
  function rG(a) {
    var b = !1,
      c = a.Ja()?.Bd();
    c && (b = c.jj());
    return a.G || b;
  }
  function sG(a) {
    a.G && a.B.Ha() && sG(a.B.ka());
    a.Ja()?.Bd()?.Fj();
  }
  function tG(a, b, c, d) {
    a.G && a.B.Ha()
      ? tG(a.B.ka(), b, c, d)
      : (a = a.Ja()?.Bd())
      ? a.qj(b, c, d)
      : d(!1);
  }
  function LG(a) {
    return a.A === null || !!a.O?.C();
  }
  function RG(a) {
    a.G && a.B.Ha() && a.B.ka().aj();
  }
  function lG(a, b, c, d) {
    function e(g, h, k, l) {
      if (l) {
        var m = QA(f);
        y(m, l);
      }
      c(g, h, k, f);
    }
    var f = b.clone();
    return uL(a, f, e, e, !0, d);
  }
  function wG(a, b, c, d) {
    c = tL(a, b, c);
    b = c[0];
    c = c[1];
    a.J ? xK(a.M, b, c, d) : d(null);
  }
  function IG(a, b) {
    return (a = a.C.Za()) && df(a, VA, 20) ? OF(b, a) : null;
  }
  function UG(a, b, c) {
    if (b && !a.A) {
      a = vF(a, b, c);
      if ((b = mx(a))) (b = a.Za()), (b = Pf(b, 24));
      if (b) return (a = a.Za()), D(a, 24);
    }
    return null;
  }
  function VG(a) {
    return a.C ? ((a = a.C.Ia()) ? EB(a) : null) : null;
  }
  function WG(a, b) {
    a.isActive = !1;
    vL(a);
    a.L = new uE(
      15e3,
      () => {
        a.C = null;
        a.K = void 0;
        a.jd = null;
        a.xc = void 0;
        a.I && a.I();
        a.aa.clear();
        a.D.clear();
        a.cursor.clear();
      },
      "clear-pano-render-cache"
    );
    a.L.start(b);
    a.H && (HE(a.H), (a.H = 0));
    a.A &&
      a.A.get((c) => {
        c.Ja().ti(!1);
      }, b);
  }
  function NG(a) {
    return a.C ? a.C.Xa() : null;
  }
  function PG(a) {
    a.G && a.B.Ha() && PG(a.B.ka());
    a.Ja()?.Bd()?.kj();
  }
  function wL(a, b, c, d, e, f, g, h) {
    var k = null,
      l = b.A,
      m = B(d, ms, 99);
    c.C && a.ib
      ? (k = VH(a.F, b, c.C, h, m))
      : c.B && c.B !== null && YK(c.B) !== null
      ? ((d = e && a.vectorTileLabelsEnabled() ? pL() : null),
        (a.P = c.B),
        (e = new XH(
          a.F,
          c.B,
          e,
          () => {},
          f,
          d,
          new ZK(),
          g,
          m,
          a.vectorTileLabelsEnabled()
        )),
        (a.A = e),
        (k = UH(a.F, b, e, h, m)))
      : c.A && Ff(d, 21, 1) === 1
      ? (k = TH(a.F, b, c.A, h, m))
      : l && (k = WH(a.F, b, l, h, m));
    c.D = l || c.D;
    return k;
  }
  function xL(a, b, c) {
    if (a.A) {
      let d = Nw(c, "impress-renderer-loading", "irl0"),
        e = a.O || new yL(() => {});
      a.O = e;
      a.A.get((f) => {
        if ((f = f.Ja())) {
          let g = B(b, ms, 99),
            h = ks(g);
          f.updateTileUrlTemplates(is(h), Gf(h, 4, 0));
          f.setFetchTileWithCredentials(C(g, 10));
          f.Cj(() => {
            Ix(a.F);
          });
          f.Ri([a.M, a.cursor, a.N, e]);
          f.setLabelUpdatingEnabled(a.ua);
          d("irl1");
        }
      }, c);
      setTimeout(() => {
        d("irlt");
      }, 3e4);
    } else c.Fa("wglfb");
  }
  function tL(a, b, c) {
    return (a = a.mb()) ? [b - a.left, c - a.top] : [b, c];
  }
  function jG(a, b) {
    a.G = a.Sa && dH(a.C.Ia(), a.ga);
    a.G &&
      a.B.get((c, d) => {
        c.ke(a.C);
        c.setActive(a.ea);
        d.Fa("arp");
        Ix(a.F);
        a.A
          ? a.A.get((e) => {
              c.le(e.Ja());
            }, b)
          : c.le(null);
      }, b);
  }
  function zL(a) {
    if (a.G && a.B.Ha()) {
      let b = a.B.ka();
      b.run();
      b.setActive(a.ea);
    }
  }
  function vL(a) {
    a.L && a.L.stop();
    a.L = null;
  }
  function wF(a, b) {
    var c = [],
      d = [];
    if (a.C) {
      a.K || ((a.K = new jx()), P(a.K, 1, 1));
      var e = a.C,
        f = a.K;
      e && (c.push(e), a.sa ? P(f, 5, 1) : P(f, 5, 0), d.push(f));
    }
    a.jd &&
      (a.xc || ((a.xc = new jx()), P(a.xc, 1, 1)),
      (e = a.jd),
      (f = a.xc),
      e && (c.push(e), a.sa ? P(f, 5, 1) : P(f, 5, 0), d.push(f)));
    a.D.bd(c, b, d);
    Ix(a.F);
  }
  function sL(a, b, c, d) {
    uL(
      a,
      b,
      function (e, f, g) {
        if (a.D.Ob()) c(e, g);
        else {
          g.gb("pano-wait-for-content");
          let h = Gu(a.D, "ViewportReady", () => {
            a.I = null;
            c(e, g);
            g.done("pano-wait-for-content");
          });
          a.I && a.I();
          a.I = () => {
            Ou(h);
            a.I = null;
            g.done("pano-wait-for-content");
          };
        }
      },
      function (e, f, g) {
        c(e, g);
      },
      !1,
      d
    );
  }
  function yF(a, b) {
    a.ua = b;
    a.B.Ha() && a.B.ka().Qe(b);
    a.Ja()?.setLabelUpdatingEnabled(b);
  }
  function zF(a, b, c) {
    if (a.A) {
      var d = vF(a, b, c);
      d?.Pb(() => {
        a.A && AL(a, b, d, !0, c);
      });
    }
  }
  function vF(a, b, c) {
    if (!b) return null;
    var d = a.aa,
      e = d.Wd,
      f = nA(b);
    (a = e.call(d, f ? a.Z[f] || b : b, c)) && a.oc(c);
    return a;
  }
  function uL(a, b, c, d, e, f) {
    if (!b) return d(!1, null, f, null), new KE();
    var g = vF(a, b, f);
    if (!g) return d(!1, null, f, null), new KE();
    if (a.A && !e) {
      let k = a.Ja();
      k ? ((k.jd = b), (k.xc = void 0)) : (a.na = b);
    }
    var h = !1;
    g.Pb(
      f.U((k) => {
        h || k === 0
          ? d(!1, null, f, null)
          : k === 4
          ? d(!1, null, f, g.Ab())
          : (a.A && !e && AL(a, b, g, e, f), c(!0, g.Xa(), f, g.Ab()));
      }, "pano-wait-for-content")
    );
    return new bH(() => {
      h = !0;
    });
  }
  function AL(a, b, c, d, e) {
    a.A.get((f) => {
      var g = f.Ja();
      if (g) {
        a.na === b && ((g.jd = b), (g.xc = void 0), (a.na = null));
        f = b.clone();
        xh(QA(f), c.Ab());
        let h = Nw(e, "impress-pano-loading", "ipl0");
        g.loadPano(
          f,
          c,
          dA(f),
          d,
          (k) => {
            a.O
              ? (g.dj(e.U(() => {}, "gmub")),
                h(k ? "ipl1" : "iptf"),
                a.O.onPanoLoaded(),
                k || c.kd(0, 0, 0))
              : h("iptf");
          },
          () => {
            h("iplc");
          }
        );
        setTimeout(() => {
          h("iplt");
        }, 3e4);
      }
    }, e);
  }
  var rL = class {
    constructor(a, b, c = null) {
      this.F = a;
      this.Ca = c;
      this.aa = null;
      this.sa = !0;
      this.D = this.Da = null;
      this.isActive = this.V = !1;
      this.N = this.M = this.cursor = null;
      this.J = !1;
      this.W = null;
      this.H = 0;
      this.C = this.B = null;
      this.G = !1;
      this.K = void 0;
      this.jd = null;
      this.xc = void 0;
      this.I = this.L = this.T = null;
      this.ua = !0;
      this.ea = null;
      this.Z = {};
      this.O = this.na = this.camera = this.P = this.A = null;
      this.ib = Ff(b, 21, 1) === 2;
      a = ls(B(b, ms, 99));
      this.ga = (this.Na = ds(a) && !C(a, 4)) || this.vectorTileLabelsEnabled();
      this.Sa = ds(a);
    }
    sf() {
      return this.F;
    }
    Xa() {
      return this.camera;
    }
    init(a, b, c, d, e, f, g, h, k, l, m, n) {
      this.Da = b;
      var q = B(d, ms, 99);
      this.aa = MH(f, a.A, q, e, g, l, this.vectorTileLabelsEnabled());
      this.D = b = wL(this, b, c, d, k, m, h, n);
      this.cursor = new LK(a, this.D, c);
      this.M = new AK(b, c);
      this.N = new tK(b, c);
      xL(this, d, n);
      !this.P && this.vectorTileLabelsEnabled() && (this.ga = this.Na);
      this.B = new eH(b, c, a, g, h, this.ga);
    }
    getCursor() {
      return this.cursor;
    }
    ke(a, b, c) {
      if (this.C) {
        Qu(this.C, "TileReady");
        for (let d of this.C.hc()) d.A.A = null;
      }
      this.C = a;
      this.C.listen("TileReady", () => {});
      this.K = c;
      this.cursor.clear();
      this.cursor.B = a;
      jG(this, b);
    }
    detect(a, b, c) {
      var d = NG(this);
      if (d)
        if (this.G && this.B.Ha()) this.B.ka().ai(a, b, d, c);
        else {
          var e = this.Ja()?.Bd();
          e ? e.ai(a, b, d, c) : c(null);
        }
      else c(null);
    }
    run() {
      this.D.run();
      this.cursor.run();
      this.J && this.M.run();
      this.Ca && this.Ca.run();
      this.N.run();
      zL(this);
      return this.A !== null
        ? this.Ja() && this.P
          ? this.P.A
          : null
        : this.Da?.B() ?? null;
    }
    me(a, b) {
      this.sa = a;
      wF(this, b);
    }
    Ib(a, b) {
      this.D.Ib(a, b);
      Ix(this.F);
    }
    Gg() {
      return "pa";
    }
    Ja() {
      return this.A && this.A.Ha() ? this.A.ka().Ja() : null;
    }
    ef(a) {
      a("");
    }
    se(a, b) {
      this.camera = a;
      y(BL, a);
      pF(BL);
      var c = CL(mj(a), this.D.mb());
      this.cursor.setCamera(c);
      this.M.setCamera(c);
      this.N.setCamera(c);
      this.G &&
        this.B.get((d) => {
          d.setCamera(c);
        }, b);
      this.D.setCamera(BL, b);
      this.V = !0;
      Ix(this.F);
    }
    Df() {
      return !0;
    }
    Hb(a, b, c, d, e, f) {
      function g() {
        f && !k && ((k = !0), f(!h, e));
      }
      a = Z(c);
      a = vF(this, a, e);
      var h = !1,
        k = !1;
      d !== 2 && d !== 3 ? g() : a ? this.D.Hb(a, e, void 0, g) : g();
      return new bH(() => {
        h = !0;
        g();
      });
    }
    vectorTileLabelsEnabled() {
      return !1;
    }
    render(a, b, c) {
      if (b) {
        let e = Z(b).clone();
        if (!z(e, 9) && a) {
          var d = e.ja();
          y(d, a);
        }
        uF(this, e, c);
      }
      this.T && this.T.cancel();
      return (this.T = new cH(this, a, b));
    }
    Ta(a, b, c, d, e, f) {
      this.D.Ta(a, b, c, d, f);
      this.camera && (this.se(this.camera, f), (this.V = !1));
      zL(this);
    }
    mb() {
      return this.D.mb();
    }
    Jb() {}
    Ob() {
      if (!this.C) return !0;
      if (!this.isActive) return !1;
      var a = this.C.Mb();
      if (a === 4) return !0;
      if (this.A) return (a = this.Ja()), !this.V && !!a && a.rc.Ob();
      a = a === 2 || a === 3;
      return this.D.Ob() && !this.V && a;
    }
    ec(a) {
      this.isActive = !0;
      vL(this);
      this.A &&
        this.A.get((b) => {
          b.Ja().ti(!0);
        }, a);
    }
    Ad(a) {
      this.D.Ad(a);
    }
    qc(a) {
      this.D.qc(a);
    }
    hd() {
      return !0;
    }
  };
  class yL {
    constructor(a) {
      this.A = a;
      this.B = !1;
    }
    le() {
      this.B = !0;
    }
    C() {
      return this.B;
    }
    onPanoLoaded() {
      if (this.A) {
        let a = this.A;
        this.A = null;
        a();
      }
    }
  }
  var BL = new U();
  function CL(a, b) {
    var c = BL;
    if (!b) return c;
    c = c.clone();
    nj(c)
      .B(Math.max(1, a.S() - b.left - b.right))
      .A(Math.max(1, a.R() - b.top - b.bottom));
    return c;
  }
  function DL(a, b, c, d, e, f, g, h, k, l, m) {
    d.getContext((n, q) => {
      a(qL(c, d, n, e, f, g, h, k, q, l, m));
    }, b);
  }
  var EL = class {
    constructor(a, b) {
      this.la = a;
      this.B = [];
      this.A = new Set();
      this.elements = Array.isArray(b) ? b : [b];
    }
    Zb(a) {
      this.la.Zb(a);
      if (a !== null && (this.A.delete(a), this.A.size === 0)) {
        a = this.B;
        this.B = [];
        for (let c of a) {
          a = this.la.yd();
          c.sd();
          var b = !1;
          for (let d = 0; d < a.A.length; ++d)
            if (a.A[d] === c) {
              a.A.splice(d, 1);
              b = !0;
              break;
            }
          if (!b)
            for (b = 0; b < a.B.length; ++b)
              if (a.B[b] === c) {
                a.B.splice(b, 1);
                break;
              }
          a.stopPropagation || er(a);
        }
      }
    }
    Oc(a, b, c, d) {
      return this.la.Oc(a, b, c, d);
    }
    pb(a, b, c, d, e, f) {
      a = this.la.pb(a, b, c, d, e, f);
      if (a !== null) {
        if (this.A.size === 0)
          for (b = 0; b < this.elements.length; b++) {
            a: {
              c = this.la.yd();
              d = this.elements[b];
              for (e = 0; e < c.A.length; e++)
                if (d === c.A[e].element) {
                  c = c.A[e];
                  break a;
                }
              d = new cr(d);
              if (c.stopPropagation) dr(c, d), c.A.push(d);
              else {
                b: {
                  for (e = 0; e < c.A.length; e++)
                    if (hr(c.A[e].element, d.element)) {
                      e = !0;
                      break b;
                    }
                  e = !1;
                }
                if (e) {
                  c.B.push(d);
                  c = d;
                  break a;
                }
                dr(c, d);
                c.A.push(d);
                er(c);
              }
              c = d;
            }
            this.B.push(c);
          }
        this.A.add(a);
      }
      return a;
    }
    yd() {
      return this.la.yd();
    }
  };
  var FL = class {
    constructor() {
      this.Z = !1;
      this.L = null;
    }
    dispose(a) {
      this.Z || ((this.Z = !0), this.G(a));
    }
    M() {
      return this.Z;
    }
    G(a) {
      if (this.L) {
        for (let b = this.L.length - 1; b >= 0; b--) this.L[b](a);
        this.L = null;
      }
    }
  };
  var GL = class extends FL {
    constructor(a) {
      super();
      this.la = a;
      this.A = new Set();
    }
    G(a) {
      super.G(a);
      a = this.A;
      this.A = new Set();
      for (let b of a) this.la.Zb(b);
    }
    Zb(a) {
      this.A.delete(a) && this.la.Zb(a);
    }
    Oc(a, b, c, d) {
      a = this.la.Oc(a, b, c, d);
      a != null && this.A.add(a);
      return a;
    }
    pb(a, b, c, d, e, f) {
      if (this.M()) return null;
      a = this.la.pb(a, b, c, d, e, f);
      a != null && this.A.add(a);
      return a;
    }
    yd() {
      return this.la.yd();
    }
  };
  var HL = "dragstart drag dragend keypress keydown keyup".split(" ");
  var IL = class {
    constructor(a, b, c, d, e, f, g, h, k, l = []) {
      this.D = a;
      this.A = b;
      this.C = c;
      this.B = d;
      this.Ac = e;
      this.Bc = f;
      this.I = g;
      this.F = h;
      this.H = k;
      this.G = l;
    }
    Ig(a) {
      var b = a.I,
        c;
      this.G &&
        (c = this.G.map((d, e) => ({
          ji: d.ji,
          hi: d.hi,
          count: d.count - a.G[e].count,
        })));
      return new IL(
        this.D - a.D,
        this.A - a.A,
        this.C - a.C,
        this.B - a.B,
        this.Ac - a.Ac,
        this.Bc - a.Bc,
        b,
        this.F,
        this.H,
        c
      );
    }
    zg() {
      var a = this.B * 0.001;
      var b = Math.max(this.C - this.A, 0),
        c = this.D / this.A;
      var d = JL(this.A / a);
      a = JL(b / a);
      var e = c < 0.05;
      var f = {};
      f.cf = this.A.toString();
      f.tf = this.C.toString();
      isNaN(d) || (f.fps = d.toFixed(1));
      f.df = b.toFixed(0);
      isNaN(a) || (f.dfps = a.toFixed(1));
      !isNaN(c) && isFinite(c) && (f.ms = (e ? 1 : 0).toFixed());
      this.F != null && (f.pr = this.F.toFixed(2).toString());
      this.H != null && (f.wr = this.H);
      f.crt = this.B.toString();
      f.tr = this.Ac.toString();
      f.tp = this.Bc.toString();
      f.fsd = this.I.toFixed(2).toString();
      return f;
    }
    Eb() {
      return (
        this.D >= 0 &&
        this.A >= 0 &&
        this.C >= 0 &&
        this.B >= 0 &&
        this.Ac >= 0 &&
        this.Bc >= 0
      );
    }
  };
  function JL(a) {
    return a === Infinity ? 0 : a;
  }
  var KL = class {
    constructor(a) {
      this.A = a;
    }
    uf() {
      var a = this.A,
        b = this.A.ie;
      return new IL(
        a.Ug,
        a.ug,
        Math.floor(a.ve / iy),
        a.ve,
        b.Ac,
        b.Bc,
        Math.sqrt(a.Od - a.rd * a.rd),
        u.devicePixelRatio || 1,
        UK || void 0
      );
    }
  };
  var LL = class {
      constructor(a, b, c) {
        this.id = a;
        this.name = b;
        this.title = c;
        this.A = iu[b] || 6371010;
      }
    },
    ML = [];
  var NL = class {
    constructor(a, b, c = 0, d = 0) {
      this.location = a;
      this.A = b;
      this.distance = c;
      this.altitude = d;
    }
    Ig(a) {
      if (!this.location || !a.location) return new NL(null, this.A);
      var b = a.location,
        c = this.location,
        d = Y(),
        e = Zi(b),
        f = Xi(b);
      b = Y();
      var g = Zi(c);
      c = Xi(c);
      du(f, e, 0, d, 1);
      du(c, g, 0, b, 1);
      e = this.A;
      ML.length > 0 ||
        ((ML[0] = null),
        (ML[1] = new LL(1, "earth", "Earth")),
        (ML[2] = new LL(2, "moon", "Moon")),
        (ML[3] = new LL(3, "mars", "Mars")),
        (ML[5] = new LL(5, "mercury", "Mercury")),
        (ML[6] = new LL(6, "venus", "Venus")),
        (ML[4] = new LL(4, "iss", "International Space Station")),
        (ML[11] = new LL(11, "ceres", "Ceres")),
        (ML[12] = new LL(12, "pluto", "Pluto")),
        (ML[17] = new LL(17, "vesta", "Vesta")),
        (ML[18] = new LL(18, "io", "Io")),
        (ML[19] = new LL(19, "europa", "Europa")),
        (ML[20] = new LL(20, "ganymede", "Ganymede")),
        (ML[21] = new LL(21, "callisto", "Callisto")),
        (ML[22] = new LL(22, "mimas", "Mimas")),
        (ML[23] = new LL(23, "enceladus", "Enceladus")),
        (ML[24] = new LL(24, "tethys", "Tethys")),
        (ML[25] = new LL(25, "dione", "Dione")),
        (ML[26] = new LL(26, "rhea", "Rhea")),
        (ML[27] = new LL(27, "titan", "Titan")),
        (ML[28] = new LL(28, "iapetus", "Iapetus")),
        (ML[29] = new LL(29, "charon", "Charon")));
      e = ML[e] || null;
      return new NL(
        this.location,
        this.A,
        (e ? e.A : 6371010) *
          Math.acos(b[0] * d[0] + b[1] * d[1] + b[2] * d[2]),
        aj(this.location) - aj(a.location)
      );
    }
    zg() {
      var a = {};
      if (this.location === null) return a;
      a.sca = String(Math.round(this.altitude));
      a.scm = String(Math.round(this.distance));
      return a;
    }
  };
  var OL = class {
    constructor(a) {
      this.Ea = a;
      this.content = dF();
    }
    uf() {
      if (this.content.get()) {
        var a = this.content.get();
        a = Ff(a, 8);
      } else a = 1;
      return this.Ea.get() ? new NL(hj(this.Ea.get()), a) : new NL(null, a);
    }
  };
  var PL = null;
  function QL(a, b) {
    Uq &&
      (PL ||
        ((PL = []),
        Fu(Uq, "beforedone", (c) => {
          c = c.hb;
          var d = PL,
            e = d.length;
          for (let g = 0; g < e; g++) {
            let h = d[g].key;
            var f = d[g].value;
            (f = typeof f === "function" ? f(c.X) : f) &&
              !c.X.D[h] &&
              Wq(c.X, h, f);
          }
        })),
      PL.push({ key: a, value: b }));
  }
  function RL(a) {
    var b = {
        x: a.x,
        y: a.y,
        Ve: 0,
        type: a.type,
        ctrlKey: a.ctrlKey,
        shiftKey: a.shiftKey,
        Mc: a.Mc,
        button: a.button,
      },
      c = null;
    a.touches && a.touches.length > 0
      ? (c = a.touches)
      : a.changedTouches &&
        a.changedTouches.length > 0 &&
        (c = a.changedTouches);
    if (a.pointerType) var d = a.pointerType;
    else a instanceof su && a.hb.pointerType && (d = a.hb.pointerType);
    b.pointerType = d;
    if (c) {
      a = c[0];
      var e = c[c.length - 1],
        f = a.target;
      c = a.clientX - f.clientLeft;
      a = a.clientY - f.clientTop;
      d = e.clientX - f.clientLeft;
      e = e.clientY - f.clientTop;
      f = d - c;
      let g = e - a;
      b.x = (c + d) / 2;
      b.y = (a + e) / 2;
      b.Ve = Math.sqrt(f * f + g * g);
    }
    return b;
  }
  function SL(a, b) {
    a.B[b] || ((a.actions += b + ";"), (a.B[b] = !0));
  }
  var UL = class {
    constructor(a, b, c, d) {
      this.ef = a;
      this.A = b;
      this.F = c;
      this.D = d;
      this.Fb = 22;
      this.Db = 6;
      this.priority = 0;
      this.C = this.Hf = !1;
      this.B = {};
      this.actions = "";
    }
    U() {
      Ly()
        ? My(() => {
            this.Hf = !1;
            zy(this.A, this);
          })
        : TL(this.A)
        ? ((this.Hf = !0), zy(this.A, this))
        : this.ef((a, b) => {
            if (a) {
              a = "invalid-render-detected+" + this.actions + "+" + a;
              let d = void 0;
              var c = a.match(/glError:(\d+)/);
              c && (d = +c[1]);
              a += "+" + this.D;
              (c = UK || void 0) && (a += "+" + c);
              c = globals.ErrorHandler.ne;
              a = c(a, {
                errorType: 5,
                glRenderer: TK ?? void 0,
                glErrorCode: d,
              });
              Oy(a);
              this.F.Ef(a, b);
            }
            this.C = !1;
            this.B = {};
            this.actions = "";
          });
    }
  };
  var VL = class extends ru {
    constructor(a, b) {
      var c = Date.now();
      super("RenderComplete", a);
      this.startTime = b;
      this.endTime = c;
    }
  };
  function WL(a, b) {
    var c = a.O;
    SL(c, b);
    c.C ||
      ((c.C = !0),
      XL(a, () => {
        zy(a.C.A, c);
      }));
  }
  function XL(a, b) {
    a.Ob() ? b() : a.B ? a.B.push(b) : (a.B = [b]);
  }
  var ZL = class extends FL {
      constructor(a, b, c, d, e) {
        super();
        this.C = a;
        this.H = this.B = this.A = null;
        this.frameCount = 0;
        this.F = this.J = !1;
        this.I = cF(!1);
        this.D = new NI(this);
        PI(this.D, a, "RenderComplete", this.K, !1, this);
        YL++;
        this.O = new UL(
          (f) => {
            this.A?.ef((g) => {
              var h = new Jw(d, "render_check");
              this.I.set(!!g, h);
              f(g, h);
              h.done("main-actionflow-branch");
            });
          },
          this.C.A,
          e,
          c ? "GL" : "2D"
        );
        b.then((f) => {
          f.A &&
            this.D.listen(f.A, "webglcontextrestored", () => {
              WL(this, "contextrestored");
              Ix(a);
            });
        });
        this.N = sE(() => {
          WL(this, "timer");
        });
      }
      sf() {
        return this.C;
      }
      Pe(a) {
        if (a !== this.A && (this.A = a) && this.C.C !== a) {
          var b = this.C;
          b.C = a;
          Ix(b);
        }
      }
      ib(a, b) {
        b = b && this.F && !a;
        this.F = a;
        b && this.K();
      }
      Ob() {
        return this.F || !this.A ? !1 : this.A.Ob();
      }
      Df() {
        return this.A ? this.A.Df() : !1;
      }
      K() {
        var a = this.Ob(),
          b = this.Df();
        this.J !== a && (this.J = a) && performance.now();
        if (this.B && a) {
          a = this.B;
          this.B = null;
          for (let c of a) c();
        }
        if (this.H && b) {
          b = this.H;
          this.H = null;
          for (let c of b) c();
        }
      }
      G() {
        this.D.dispose();
        u.clearInterval(this.N);
      }
    },
    YL = 1;
  function $L(a, b, c, d) {
    d
      ? aM(
          new bM(
            a.A,
            d,
            a.C,
            () => {
              cM(a.B, (e) => {
                $L(a, b, c, e);
              });
            },
            b
          )
        )
      : c();
  }
  var gM = class {
    constructor(a, b) {
      this.A = a;
      this.C = b;
      this.B = this.animation = null;
    }
    animate(a, b, c) {
      var d = b.U((e, f) => {
        this.animation = null;
        var g = this.A,
          h = g.camera.get(),
          k = g.Ea.get();
        y(k, h);
        g.B.start(e);
        g.H.x = -1;
        g.H.y = -1;
        dM(g.C, g.H);
        g.H.x >= 0 && g.H.y >= 0 && g.A.lc && pG(g.A.lc, g.H.x, g.H.y, e);
        c(e, f);
      }, "animation-");
      this.animation = new bM(this.A, a, this.C, d, b);
      eM(this.A);
      aM(this.animation);
      return this.animation;
    }
    transition(a, b, c) {
      this.B = a;
      var d = b.U(
        () => {
          this.B = null;
          var e = this.A,
            f = e.camera.get(),
            g = e.Ea.get();
          y(g, f);
          dM(e.C);
          e.Bb = !1;
          c(b);
        },
        "transition-default-",
        a.Ie(),
        "df1"
      );
      fM(this.A);
      cM(a, (e) => {
        $L(this, b, d, e);
      });
    }
    Ta(a, b) {
      this.B && this.B.Ta(a, b);
    }
  };
  function aM(a) {
    if (!a.A) {
      a.A = !0;
      var b = a.B;
      let d = new hM(a, a.animation.Td());
      var c = b.D;
      c = c.C && c.J ? c.N : c.now();
      d.startTime = c;
      b.A.push(d);
      iM(a, 0);
      Ly() ? b.stop(a, !0) : jM(b);
    }
  }
  function kM(a, b) {
    a.A && ((a.A = !1), (a.mh = b), a.B.stop(a), a.D(a.X, a));
  }
  function iM(a, b) {
    var c = a.animation.de(b);
    c && a.C.se(c, a.X);
    (c = a.animation.ee(b)) && a.C.Jb(c, a.X);
    b === 1 && kM(a, !1);
  }
  class bM {
    constructor(a, b, c, d, e) {
      this.C = a;
      this.animation = b;
      this.B = c;
      this.D = d;
      this.X = e;
      this.mh = this.A = !1;
    }
    cancel() {
      kM(this, !0);
    }
    isPlaying() {
      return this.A;
    }
  }
  var lM = class extends eF {
    constructor() {
      super(...arguments);
      this.Ua = this;
    }
    moveTo() {
      return !1;
    }
    resize(a, b) {
      var c = this.camera.get();
      c && ((c = nj(c)), y(c, a), this.camera.notify(b));
    }
    Nd() {}
    ue() {}
    Rc() {
      return 0;
    }
    Jc() {
      return 0;
    }
    hd() {
      return !1;
    }
  };
  var mM = class {
    constructor(a, b, c, d) {
      a.clone();
      this.B = c.clone();
      b.clone();
      this.A = d.clone();
    }
  };
  var nM = class extends ru {
    constructor(a, b) {
      super("RenderStart", a);
      this.startTime = b;
    }
  };
  function Ix(a) {
    a.C && oM(a);
  }
  function pM(a, b) {
    Jy(
      (c) => {
        c && Ix(a);
      },
      a.F,
      b
    );
  }
  function oM(a) {
    a.D ||
      (qM(a.A, {
        render: () => {
          a.render();
        },
        Fb: 2,
        Db: 3,
      }),
      (a.D = !0));
  }
  var rM = class extends Su {
    constructor(a, b, c = !1) {
      super();
      this.A = a;
      this.H = c;
      this.F = new NI(this);
      this.G = this.C = null;
      this.D = !1;
      qu(this, Ca(ou, this.F));
      pM(this, b);
    }
    render() {
      this.D = !1;
      if (!this.M() && this.C) {
        var a = Date.now();
        this.dispatchEvent(new nM(this, a));
        var b = this.C?.run();
        b && (this.G = b);
        this.dispatchEvent(new VL(this, a));
        this.H && Ix(this);
      }
    }
  };
  function sM(a, b) {
    this.x = a;
    this.y = b;
  }
  Ea(sM, As);
  p = sM.prototype;
  p.clone = function () {
    return new sM(this.x, this.y);
  };
  p.scale = As.prototype.scale;
  p.invert = function () {
    this.x = -this.x;
    this.y = -this.y;
    return this;
  };
  p.normalize = function () {
    return this.scale(1 / Math.hypot(this.x, this.y));
  };
  p.add = function (a) {
    this.x += a.x;
    this.y += a.y;
    return this;
  };
  p.rotate = function (a) {
    var b = Math.cos(a);
    a = Math.sin(a);
    var c = this.y * b + this.x * a;
    this.x = this.x * b - this.y * a;
    this.y = c;
    return this;
  };
  p.equals = function (a) {
    return this === a
      ? !0
      : a instanceof sM && !!a && this.x == a.x && this.y == a.y;
  };
  function eM(a) {
    a.B.stop();
    a.C.A++;
  }
  function fM(a) {
    a.Bb = !0;
    a.B.stop();
    a.C.A++;
  }
  function tM(a, b) {
    a.context.then((c) => {
      var d = c.A?.O()?.D();
      c = [d, c.B?.D(), void 0];
      for (let e of c) {
        if (!e) continue;
        c = e.classList;
        c.toggle(
          "mapsConsumerUiSceneCoreScenecommon__activated",
          e === b && e !== d
        );
        c.toggle("mapsConsumerUiSceneCoreScenecommon__noprint", e !== b);
      }
    });
  }
  function uM(a, b) {
    var c = a.width.get();
    a = a.height.get();
    nj(b).B(c).A(a);
  }
  function vM(a, b) {
    uM(a, b);
    a = a.content.get();
    hF(a?.A()) && P(b, 4, 13.1);
  }
  function wM(a, b) {
    var c = new gj().B(a.width.get() || 0).A(a.height.get() || 0);
    a.view.resize(c, b);
    a.context.then((e) => {
      e.A &&
        ((e = e.A.ca),
        a.Oe(
          !(
            e.drawingBufferWidth === e.canvas.width &&
            e.drawingBufferHeight === e.canvas.height
          ),
          b
        ));
    });
    if (a.Da()) {
      var d = mj(a.camera.get());
      if (d.S() !== c.S() || d.R() !== c.R())
        Fw(`Resize from (${d.S()}, ${d.R()}) to (${c.S()}, ${c.R()})`),
          (d = a.Ea.get()),
          wh(nj(d), c),
          a.A.resize(c, b),
          WL(a.rc, "resize");
    }
  }
  function xM(a, b, c, d, e, f) {
    d && yM(a, a.F, null, null, e);
    a.O += 1;
    var g = a.O,
      h = c.clone(),
      k = b.clone();
    a.ad.load(
      c,
      (l, m) => {
        if (a.O === g) {
          a.na = !0;
          var n = a.content.get() || new HB();
          y(n, h);
          yM(a, l, k, n, m);
          d || (a.C.Qe(!0), e.Fa("scnd"), e.C.dispatchEvent(new Event("scnd")));
          a.na = !1;
        }
        f(m);
      },
      e
    );
  }
  function yM(a, b, c, d, e) {
    if (b !== a.A) {
      a.rc.ib(!1, !1);
      var f = a.A;
      f.Ag(e);
      Ou(a.ae);
      a.A = b;
      b.initialize(c, d, e);
      a.ae = ix(a.A, "user-input-event", a.target);
      f !== a.F &&
        (f.Cc.unbind(e),
        f.Ea.unbind(e),
        f.camera.unbind(e),
        f.content.unbind(e));
      f !== a.F && a.lb.unbind(e);
      b !== a.F &&
        (ZE(b.Cc, a.Cc, e),
        ZE(b.Ea, a.Ea, e),
        ZE(b.camera, a.camera, e),
        ZE(b.content, a.content, e));
      d && zM(a.content, d, e);
      c &&
        ((d = a.width.get()),
        (f = a.height.get()),
        (d = new gj().B(d).A(f)),
        c
          ? (b.ze(c, d),
            uM(a, c),
            $E(a.camera)
              ? ((d = a.camera.get()), y(d, c), a.camera.notify(e))
              : a.camera.set(c.clone(), e),
            $E(a.Ea) || a.Ea.set(c.clone(), e))
          : ((c = a.camera.get()),
            b.ze(c, d) && (uM(a, c), a.camera.notify(e))));
      b !== a.F && ZE(a.lb, b.lb, e);
      b.ec(a, e);
      a.Ua.notify(e);
      a.T.notify(e);
      a.Ic.notify(e);
      b !== a.F ? a.B.start(e) : a.B.stop();
      Kw(e) &&
        (e.D.drv || Wq(e, "drv", b.mf()),
        e.D.sph || Wq(e, "sph", a.K.get() ? "1" : "0"),
        e.D.rdv || Wq(e, "rdv", a.ea));
    }
  }
  function AM(a, b, c, d, e, f) {
    a.ga = b;
    a.sa = c;
    a.J = d;
    BM(a, e, f);
  }
  function BM(a, b, c) {
    a.content.get();
    var d = ++a.ce;
    a.A.Jf(
      a.ga,
      a.sa,
      b.U((e) => {
        a.ce === d && CM(a, e, b, c);
      }, "ccbb"),
      b
    );
  }
  function CM(a, b, c, d) {
    var e = a.A.hf;
    a.A.ah(a.J)
      ? a.cursor.set("move", c)
      : b
      ? a.cursor.set("pointer", c)
      : d !== void 0 || e
      ? (a.cursor.get() !== "pointer" && a.cursor.set("auto", c),
        a.C.A === 0 &&
          (d === void 0
            ? e.detect(
                a.ga,
                a.sa,
                c.U((f) => {
                  DM(a, f, c);
                }, "scene.feature-detection-branch")
              )
            : DM(a, d, c)))
      : a.cursor.set("auto", c);
  }
  function DM(a, b, c) {
    b && b.nj() ? a.cursor.set("pointer", c) : a.cursor.set("auto", c);
  }
  function EM(a, b, c) {
    if (a.A.Ic) return EM(a.A.Ic, b, c);
    a = c || new sM(0, 0);
    a.x = 0;
    a.y = 0;
    return a;
  }
  function FM(a, b, c, d) {
    a.Ca = !0;
    a.W.transition(b, d, (e) => {
      var f = a.camera.get(),
        g = a.content.get();
      a.ad.load(
        g,
        (h, k) => {
          a.Ca = !1;
          yM(a, h, f, g, k);
          c(k);
        },
        e
      );
    });
  }
  var HM = class extends FL {
      constructor(a, b, c, d, e, f, g, h, k, l, m, n, q) {
        super();
        this.ad = a;
        this.Ue = b;
        this.context = d;
        this.C = f;
        this.target = k;
        this.view = n;
        this.Oe = q;
        this.camera = cF();
        this.Ua = cF(this);
        this.T = cF(this);
        this.I = cF(!1);
        this.content = cF();
        this.N = cF();
        this.Cc = dF(this);
        this.na = this.Ca = this.Bb = !1;
        this.Kc = dF(this);
        this.Ic = cF(this);
        this.width = dF();
        this.height = dF();
        this.margin = dF();
        this.Ea = cF();
        this.V = new U();
        this.Zd = new HB();
        this.Na = null;
        this.O = 0;
        this.P = dF();
        this.K = dF();
        this.A = this.F = new lM();
        this.cursor = cF();
        this.tabIndex = cF(0);
        this.lb = cF();
        this.J = !1;
        this.sa = this.ga = 0;
        this.aa = !1;
        this.Sa = this.ua = null;
        this.ea = "n";
        this.D = 0;
        this.Zc = new uE(
          500,
          () => {
            this.D = 0;
          },
          "accumulatedScrollResetFuse"
        );
        this.B = new uE(
          100,
          (r) => {
            var t = this.camera.get(),
              v = this.Ea.get();
            this.A === this.F
              ? (this.B.stop(), this.B.start(r))
              : (y(v, t), this.Ea.notify(r));
          },
          "stableCameraUpdaterFuse"
        );
        this.H = new sM(-1, -1);
        this.ae = null;
        this.ce = 0;
        this.camera.listen(this.Le, this);
        this.content.listen(this.Ne, this);
        QL("sc", () =>
          this.content.get() ? String(this.content.get().A()) : ""
        );
        this.rc = new ZL(c, d, e, h, m);
        ZE(this.I, this.rc.I, l);
        this.margin.listen(this.Ta, this);
        ZE(this.A.camera, this.camera, l);
        QL("drv", () => this.A.mf());
        QL("sph", () => (this.K.get() ? "1" : "0"));
        QL("rdv", () => this.ea);
        this.W = new gM(this, g);
        c.listen("RenderComplete", (r) => {
          tM(this, r.target.G);
        });
      }
      nf() {
        return this.lb;
      }
      G(a) {
        this.rc.dispose(a);
      }
      Pe(a, b) {
        this.ea = a?.Gg() || "n";
        this.rc.Pe(a);
        this.Ta(b);
      }
      ib(a) {
        this.rc.ib(a, !0);
      }
      Sf() {
        return this.A.Sf();
      }
      se(a, b) {
        var c = this.camera.get();
        y(c, a);
        uM(this, c);
        this.camera.notify(b);
      }
      Jb(a, b) {
        var c = this.content.get();
        y(c, a);
        this.content.notify(b);
      }
      Zh() {
        return this.A.hf;
      }
      Da() {
        return $E(this.camera) && $E(this.content);
      }
      We(a, b) {
        a.gb("stableViewport");
        XL(this.rc, () => {
          b(a);
          a.done("stableViewport");
        });
      }
      moveTo(a, b, c, d, e = () => {}) {
        if (b?.A() === 4) return e(d), !1;
        c = c ? c.copy() : new rF();
        if (this.Bb || this.Ca || this.na) return e(d), !1;
        var f = d.U(
          () => {
            e(d);
          },
          "moveTo",
          "mt0",
          "mt1"
        );
        b && Wq(d, "sc", String(b.A()));
        var g = this.Da();
        if (!g) {
          if (!b)
            if (this.Na) b = this.Na;
            else return f(), !1;
          this.Na = b.clone();
          if (!a) return zM(this.content, b, d), f(), !0;
        }
        var h = this.content.get(),
          k = this.camera.get();
        g || h || (h = new HB());
        g || k || ((k = new U()), vM(this, k));
        a && gz(k, a) && (a = null);
        b && vh(h, b) && (b = null);
        if (!a && !b && !c.B) return f(), !1;
        a && (y(this.V, a), (a = this.V), oj(this.V) || uM(this, this.V));
        b && (y(this.Zd, b), (b = this.Zd));
        if (jF(h) || jF(b)) c.A = 2;
        !d.isActive() &&
          h &&
          b &&
          h.Ed() &&
          b.Ed() &&
          h.A() !== b.A() &&
          d.A("transitions", "switch_map_mode");
        b && gF(h) && gF(b);
        this.C.A++;
        var l = () => {
          f();
          dM(this.C);
        };
        zM(this.N, b || h, d);
        if (g && !c.B && this.A.moveTo(a, b, c, d, l)) return !0;
        xM(this, a || k, b || h, g, d, l);
        return !0;
      }
      ue(a, b, c, d) {
        this.A.Ua &&
          (b.isActive() || b.A("scene", "scroll_zoom"),
          this.A.Ua.ue(a, b, c, d));
      }
      Nd(a, b, c, d, e) {
        this.A.Ua &&
          (b.isActive() || b.A("scene", "scroll_zoom"),
          this.A.Ua.Nd(a, b, c, d, e));
      }
      Rc() {
        return this.A.Ua ? this.A.Ua.Rc() : null;
      }
      Jc() {
        return this.A.Ua ? this.A.Ua.Jc() : null;
      }
      hd() {
        return this.A.Ua ? this.A.Ua.hd() : !1;
      }
      Le(a) {
        var b = this.content.get();
        if (hF(b?.A()) && (b = this.camera.get()) && b && z(b, 1)) {
          var c = hj(b);
          if (Pf(c, 3) && Pf(c, 2) && cj(c)) {
            var d = Zi(c);
            d < -90 ||
              d > 90 ||
              isNaN(d) ||
              ((d = Xi(c)),
              d < -180 ||
                d > 180 ||
                isNaN(d) ||
                ((c = aj(c)),
                c < -10898 ||
                  isNaN(c) ||
                  !Pf(b, 4) ||
                  ((c = b.Ga()),
                  c < 1 ||
                    c > 179 ||
                    isNaN(c) ||
                    !oj(b) ||
                    ((c = mj(b)),
                    !fj(c) ||
                      Df(c, 2) == null ||
                      c.S() < 1 ||
                      c.R() < 1 ||
                      isNaN(c.S()) ||
                      isNaN(c.R()) ||
                      !lj(b) ||
                      jj(b)))));
          }
        }
        b = this.W;
        b.animation || b.B || this.aa || (this.B.stop(), this.B.start(a));
        BM(this, a);
      }
      Ne(a) {
        var b = this.content.get();
        b && zM(this.N, b, a);
      }
      Ta(a) {
        var b = this.margin.get();
        if (b) {
          this.W.Ta(b, a);
          var c = this.rc.A;
          c && c.Ta(b.top, b.right, b.bottom, b.left, b.A, a);
        }
      }
      animate(a, b, c) {
        return this.W.animate(a, b, c);
      }
      transition(a, b, c, d) {
        var e = this.camera.get(),
          f = this.content.get(),
          g = new mM(e, f, a, b);
        yM(this, this.F, null, null, c);
        this.Pe(null, c);
        BM(this, c);
        this.context.then(
          c.U(() => {
            this.Ue.load(g, c, (h, k) => {
              var l = this.margin.get();
              l && h.Ta(l, k);
              GM(k, (m) => {
                FM(this, h, d, m);
              });
            });
          }, "transition_getContext")
        );
      }
    },
    IM = 1 / 6;
  function zM(a, b, c) {
    if ($E(a)) {
      var d = a.get();
      y(d, b);
      a.notify(c);
    } else a.set(b.clone(), c);
  }
  function JM(a) {
    for (let g = a.container.firstChild; g; g = g.nextSibling)
      if (g.nodeType === Node.ELEMENT_NODE) {
        var b = a,
          c = g,
          d = c.__tai;
        if (!d || !d.fixed) {
          a: {
            var e = d.tj;
            var f = KM;
            b = b.A.get();
            if (!b) {
              f = !1;
              break a;
            }
            e = bj($i(Yi(LM, e[0]), e[1]), e[2]);
            EM(b, e, MM);
            f[0] = MM.x;
            f[1] = MM.y;
            f = !0;
          }
          f
            ? ((e = d.Ti),
              (c.style.display = "block"),
              (d = NM(KM[0] - e[0])),
              (f = NM(KM[1] - e[1])),
              (e = e[2]),
              d.toString().indexOf("e") === -1 && f.toString().indexOf("e"),
              (c.style.transform = `translateZ(0) translate(${d}px,${f}px) scale(${e})`))
            : (c.style.display = "none");
        }
      }
  }
  var OM = class {
      constructor(a) {
        this.container = a;
      }
      detach(a) {
        a.parentNode === this.container && Ms(a);
      }
    },
    KM = Nx();
  Y();
  function NM(a) {
    var b = u.devicePixelRatio || 1;
    return Math.round(a * b) / b;
  }
  var PM = class extends OM {
      constructor() {
        super(...arguments);
        this.B = dF();
        this.A = dF();
        this.C = !1;
      }
      bind(a, b, c) {
        ZE(this.B, a, c);
        ZE(this.A, b, c);
        this.B.listen(this.D, this);
        this.A.listen(this.F, this);
      }
      D(a) {
        this.B.get() &&
          this.A.get() &&
          !this.C &&
          ((this.C = !0),
          GE(
            () => {
              this.C = !1;
              JM(this);
            },
            0,
            a,
            "effect-surface-camera-update"
          ));
      }
      F() {
        this.B.get() && this.A.get() && !this.C && JM(this);
      }
    },
    LM = new dj(),
    MM = new sM(0, 0);
  function QM(a, b, c, d, e, f) {
    var g = a.G;
    f || (b !== "drag" && b !== "dragstart" && b !== "dragend") || (f = 0);
    if (!RM(a, b, c, d, f)) {
      let h = f || null;
      c = (k, l) => {
        SM(a, b, h, k, l);
      };
      e = e
        ? a.la.Oc(b, null, c, f)
        : a.la.pb(a.namespace, a.action, b, null, c, f);
      c = a.B[b];
      c || ((c = {}), (a.B[b] = c));
      c[h || "null"] = e;
    }
    return g;
  }
  function RM(a, b, c, d, e) {
    var f = e || null,
      g = a.A[b];
    g || ((g = {}), (a.A[b] = g));
    var h = g[f || "null"];
    e = !!h;
    h || ((h = []), (g[f || "null"] = h));
    b = new TM(b, f, c, d);
    h.push(b);
    c = a.G++;
    a.D[c] = b;
    return e;
  }
  function SM(a, b, c, d, e) {
    a.enabled &&
      (d.gb("scene-async-event-handler"),
      a.F || ((a.F = !0), qM(a.H, a)),
      b === "scrollwheel" &&
        e.Se !== void 0 &&
        e.Qf !== void 0 &&
        Math.abs(e.Se) >= Math.abs(e.Qf) &&
        (e.preventDefault(), (e.returnValue = !1)),
      a.C.push(new UM(b, c, e, d)));
  }
  var VM = class {
    constructor(a, b, c, d) {
      this.la = a;
      this.namespace = b;
      this.action = c;
      this.H = d;
      this.Fb = 24;
      this.Db = 6;
      this.input = () => {
        this.F = !1;
        var e = this.C;
        this.C = [];
        for (let g = 0; g < e.length; ++g) {
          let h = e[g],
            k = this.A[h.type][h.qualifier || "null"];
          if (k && k.length > 0) {
            var f = g + 1 < e.length ? e[g + 1] : null;
            f =
              f &&
              f.type === h.type &&
              f.qualifier === h.qualifier &&
              (f.event == null ||
                h.event == null ||
                f.event.type === h.event.type);
            for (let l = 0; l < k.length; ++l) {
              let m = k[l];
              (f && m.A) || m.handler(h.X, h.event);
            }
          }
          h.X.done("scene-async-event-handler");
        }
      };
      this.F = !1;
      this.C = [];
      this.A = {};
      this.D = {};
      this.B = {};
      this.G = 0;
      this.enabled = !0;
    }
    Qe(a) {
      this.enabled = a;
    }
    pb(a, b, c, d) {
      return QM(this, a, b, c, !1, d);
    }
    Oc(a, b, c, d) {
      return QM(this, a, b, c, !0, d);
    }
    Zb(a) {
      var b = this.D[a];
      if (b) {
        var c = b.eventType,
          d = b.qualifier,
          e = this.A[c][d || "null"];
        for (let f = 0; f < e.length; ++f)
          if (e[f] === b) {
            e.splice(f, 1);
            break;
          }
        e.length === 0 &&
          (delete this.A[c][d || "null"],
          Hm(this.A[c]) === 0 && delete this.A[c],
          delete this.D[a],
          this.la.Zb(this.B[c][d || "null"]),
          delete this.B[c][d || "null"],
          Hm(this.B[c]) === 0 && delete this.B[c]);
      }
    }
  };
  class UM {
    constructor(a, b, c, d) {
      this.type = a;
      this.qualifier = b;
      this.event = c;
      this.X = d;
    }
  }
  class TM {
    constructor(a, b, c, d) {
      this.eventType = a;
      this.qualifier = b;
      this.A = c;
      this.handler = d;
    }
  }
  var WM = class {
    constructor(a, b, c, d) {
      this.cause = a;
      this.eventType = b;
      this.A = c;
      this.X = d;
      this.defaultPrevented = this.B = !1;
    }
    claim() {
      this.B || (this.B = !0);
    }
    preventDefault() {
      this.defaultPrevented = !0;
    }
  };
  var XM = "ptrdown ptrhover ptrout ptrup dragstart drag dragend".split(" ");
  function dM(a, b) {
    a.A !== 0 && (a.A > 0 && a.A--, b && ((b.x = a.C.x), (b.y = a.C.y)));
  }
  function YM(a) {
    for (let b of XM)
      a.H.pb(b, !0, (c, d) => {
        ZM(a, b, c, d);
      });
  }
  function ZM(a, b, c, d) {
    if (a.enabled) {
      if (b === "ptrhover" && ((a.C.x = d.x), (a.C.y = d.y), a.A !== 0)) return;
      var e = a.G?.Zh(),
        f = c.U((g) => {
          $M(a, b, d, g, c);
        }, "feature-event-handler");
      if (e && aN.has(b)) {
        let g = {};
        a.B.push(g);
        e.detect(
          d.x,
          d.y,
          (h) => {
            g.zf = () => void f(h);
            bN(a);
          },
          b === "ptrhover"
        );
      } else a.B.push({ zf: () => void f(null) }), bN(a);
    }
  }
  function $M(a, b, c, d, e) {
    a.D = !0;
    c = new WM(c, b, d, e);
    e = d ? d.ej() : cN;
    d = [];
    for (let f = 0; f < e.length; ++f) {
      let g = a.handlers[`${b}:${e[f]}`];
      g && d.push(...g);
    }
    d.sort((f, g) => f.A - g.A);
    for (b = 0; b < d.length; ++b) d[b].handler(c);
    a.D = !1;
  }
  function bN(a) {
    for (; a.B.length && a.B[0].zf; ) a.B[0].zf(), a.B.shift();
  }
  var dN = class {
      constructor(a) {
        this.H = a;
        this.enabled = !0;
        this.G = null;
        this.handlers = {};
        this.B = [];
        this.F = {};
        this.I = this.M = 0;
        this.J = -1;
        this.A = 0;
        this.D = !1;
        this.C = new sM(-1, -1);
        YM(this);
      }
      Qe(a) {
        this.enabled = a;
      }
      re(a) {
        var b = this.F[a];
        if (b) {
          var c = `${b.eventType}:0`,
            d = this.handlers[c];
          for (let e = 0; e < d.length; ++e)
            if (b === d[e]) {
              this.D && ((d = d.slice()), (this.handlers[c] = d));
              d.splice(e, 1);
              break;
            }
          delete this.F[a];
        }
      }
    },
    aN = new Set(["ptrdown", "ptrhover", "ptrup"]),
    cN = [1, 0];
  class eN {
    constructor(a, b, c, d) {
      this.eventType = a;
      this.handler = b;
      this.A = c;
      this.id = d;
    }
  }
  function fN(a) {
    return a.button === 0 && !(Pb && a.ctrlKey);
  }
  function gN(a, b) {
    return [a.N(), "[", a.T, "]: ", b].join("");
  }
  function hN(a, b, c) {
    var d = a.H,
      e = a.P;
    a = d.M++;
    e = e ? d.J-- : d.I++;
    c = new eN(b, c, e, a);
    d.F[a] = c;
    b = `${b}:0`;
    e = d.handlers[b];
    e
      ? d.D && ((e = e.slice()), (d.handlers[b] = e))
      : ((e = []), (d.handlers[b] = e));
    e.push(c);
    return a;
  }
  function iN(a, b, c) {
    b = hN(a, b, c);
    a.O.push(b);
  }
  var kN = class extends FL {
      constructor(a, b, c = !1, d) {
        super();
        this.H = a;
        this.I = b;
        this.P = c;
        this.W = d;
        this.O = [];
        this.B = this.C = !1;
        this.T = ++jN;
      }
      initialize() {
        this.W !== void 0 && gN(this, "Gesture recognizer constructed:");
        this.J();
        this.I.register(this);
      }
      lock() {
        this.B || (this.reset(), (this.B = !0));
      }
      unlock() {
        this.B && (this.B = !1);
      }
      G() {
        for (let a = 0; a < this.O.length; ++a) this.H.re(this.O[a]);
        this.O.length = 0;
        this.reset();
        this.I.unregister(this);
      }
      claim(a) {
        if (this.C) return !1;
        !a.B && this.I.claim(this) && (a.claim(), (this.C = !0));
        return this.C;
      }
      release() {
        this.C && ((this.C = !1), this.I.release(this));
      }
      reset() {
        this.C && this.release();
      }
    },
    jN = 0;
  function lN(a) {
    a.K = null;
    a.F = null;
    a.D !== null && (HE(a.D), (a.D = null));
    a.A = !1;
  }
  function mN(a, b) {
    b = b.cause;
    switch (a.button) {
      case 0:
        return fN(b);
      case 1:
        return b.button === 2 || (b.button === 0 && !fN(b));
      default:
        return !1;
    }
  }
  function nN(a, b) {
    a.D = GE(
      () => {
        a.A = !1;
      },
      250,
      b,
      "sceneDblClick"
    );
  }
  var oN = class extends kN {
    constructor(a, b, c, d, e, f = !1) {
      super(a, b, f, e);
      this.V = c;
      this.button = d;
      this.handler = e;
      this.K = null;
      this.A = !1;
      this.D = this.F = null;
      this.initialize();
    }
    N() {
      return "double-click-recognizer";
    }
    J() {
      iN(this, "ptrdown", (a) => {
        var b = a.cause.type === "touchstart";
        if (mN(this, a) || b)
          this.F && lN(this),
            this.A
              ? (gN(this, "start of second click in double-click."),
                (this.A = !1),
                (this.F = a.cause))
              : (gN(this, "start of single-click; starting timer."),
                (this.A = !0),
                nN(this, a.X),
                (this.K = a.A));
      });
      iN(this, "dragstart", (a) => {
        this.Wc(a);
      });
      iN(this, "ptrup", (a) => {
        var b = a.cause.type === "touchend";
        if ((mN(this, a) || b) && this.F)
          if (a.B || this.B)
            gN(this, "event or stream already claimed; skipping."), lN(this);
          else {
            b = new Jw(this.V, "click_2");
            var c = new WM(a.cause, a.eventType, this.K, b);
            gN(this, "calling handleDoubleClick");
            var d = this.handler.controller;
            let e = c.A,
              f = c.cause;
            c = c.X;
            c.A("scene", "click_scene");
            AM(d, f.x, f.y, d.J, c, e);
            d.A.Xg(RL(f), c);
            b.done("main-actionflow-branch");
            gN(this, "claiming event per handler request.");
            this.claim(a);
            lN(this);
            this.reset();
          }
      });
    }
    Wc() {
      gN(this, "resetting due to dragStart");
      lN(this);
    }
  };
  var pN = class extends kN {
    constructor(a, b, c) {
      super(a, b, !1, c);
      this.handler = c;
      this.K = this.F = !1;
      this.A = this.D = null;
      this.initialize();
    }
    N() {
      return "drag-recognizer";
    }
    J() {
      iN(this, "ptrdown", (a) => {
        if (this.B) gN(this, "locked; ignoring POINTERDOWN.");
        else if (((a = a.cause), a.type !== "mousedown" || a.button === 0))
          this.K = this.F = !0;
      });
      iN(this, "ptrup", (a) => {
        a = a.cause;
        if (a.type !== "mouseup" || a.button === 0)
          this.F &&
            gN(this, "POINTERUP received w/out DRAG. Calling drag cancel."),
            this.reset();
      });
      iN(this, "dragstart", (a) => {
        this.Wc(a);
      });
    }
    reset() {
      super.reset();
      this.K = this.F = !1;
      this.D && (this.H.re(this.D), (this.D = null));
      this.A && (this.H.re(this.A), (this.A = null));
    }
    Wc(a) {
      this.B
        ? Fw(gN(this, "locked; ignoring DRAGSTART."))
        : this.F &&
          ((this.F = !1),
          this.K &&
            !a.B &&
            (Fw(
              gN(this, "claiming DRAGSTART event and registry input stream.")
            ),
            (this.D = hN(this, "drag", (b) => {
              this.xf(b);
            })),
            (this.A = hN(this, "dragend", (b) => {
              this.yf(b);
            })),
            this.D === null || this.A === null
              ? this.reset()
              : ((this.K = !1), this.claim(a), this.handler.Wc(a))));
    }
    xf(a) {
      this.B
        ? gN(this, "locked; ignoring DRAG.")
        : this.C && (this.handler.xf(a), a.claim());
    }
    yf(a) {
      this.B
        ? gN(this, "locked; ignoring DRAGEND.")
        : (this.C &&
            (gN(this, "Invoking handleDragEnd and releasing input stream."),
            a.claim(),
            this.handler.yf(a)),
          this.reset());
    }
  };
  function qN(a) {
    a.reset();
    a.K != null && (HE(a.K), (a.K = null));
    a.D = !1;
    a.A = null;
    a.F = null;
  }
  function rN(a, b) {
    b = b.cause;
    switch (a.button) {
      case 0:
        return fN(b);
      case 1:
        return b.button === 2 || (b.button === 0 && !fN(b));
      default:
        return !1;
    }
  }
  function sN(a, b) {
    a.K = GE(
      () => {
        a.D = !1;
        if (a.F && a.A) {
          if (!a.F.B && !a.B) {
            var c = tN(a, a.A, a.F);
            gN(a, "calling handleExclusiveClick within timeout");
            uN(a.handler, c) && a.claim(a.F);
            c.X.done("main-actionflow-branch");
          }
          qN(a);
        } else gN(a, "timeout expired but click not finished.");
      },
      250,
      b,
      "sceneExclusiveClick"
    );
  }
  function tN(a, b, c) {
    a = new Jw(a.V, "click_1");
    return new WM(b.cause, c.eventType, b.A, a);
  }
  var vN = class extends kN {
    constructor(a, b, c, d) {
      super(a, b, !1, d);
      this.V = c;
      this.button = 0;
      this.handler = d;
      this.F = this.A = null;
      this.D = !1;
      this.K = null;
      this.initialize();
    }
    N() {
      return "exclusive-click-recognizer";
    }
    J() {
      iN(this, "ptrdown", (a) => {
        rN(this, a) &&
          (this.A && !this.D && qN(this),
          this.D
            ? (gN(this, "start of double-click; resetting timer and flag."),
              qN(this))
            : (gN(this, "start of single-click; setting flag and timer."),
              (this.D = !0),
              sN(this, a.X),
              (this.A = a)));
      });
      iN(this, "dragstart", (a) => {
        this.Wc(a);
      });
      iN(this, "ptrup", (a) => {
        if (rN(this, a))
          if (this.A)
            if (this.D) this.F = a;
            else {
              if (!a.B && !this.B) {
                var b = tN(this, this.A, a);
                gN(this, "calling handleExclusiveClick after long click");
                uN(this.handler, b) && this.claim(a);
                b.X.done("main-actionflow-branch");
              }
              qN(this);
            }
          else gN(this, "received POINTERUP by itself; skipping."), qN(this);
      });
    }
    Wc() {
      this.A && (gN(this, "resetting due to dragStart"), qN(this));
    }
  };
  var xN = class extends kN {
    constructor(a, b, c) {
      super(a, b, !1, c);
      this.handler = c;
      this.A = null;
      this.initialize();
    }
    N() {
      return "hover-recognizer";
    }
    J() {
      iN(this, "ptrhover", (a) => {
        a: {
          let e = a.A;
          var b = !e && !0;
          var c = !(!e || !e.Ed());
          c = b || c;
          var d = e && this.A && this.A.equals(e);
          b = (b = !this.A && c) || (!!this.A && c && !d);
          c = this.A && (!e || !d);
          d = this.A && e && d;
          let f = b || c;
          if (c) {
            gN(this, "Calling handleHoverEnd");
            if (a.defaultPrevented) break a;
            this.A = null;
          }
          b &&
            (a.X.isActive() || a.X.A("scene_hover", "hover_on_map"),
            gN(this, "Calling handleHoverStart"),
            (this.A = e),
            wN(this.handler, a));
          d && gN(this, "Calling handleHoverMove");
          f && gN(this, "Calling handleHoverChange");
        }
      });
      iN(this, "ptrdown", (a) => {
        this.A &&
          (gN(this, "Calling handleHoverEnd due to pointer down"),
          a.defaultPrevented || (this.A = null));
      });
      iN(this, "ptrout", (a) => {
        !this.B &&
          this.A &&
          (gN(this, "Calling handleHoverEnd due to pointer out"),
          a.defaultPrevented || (this.A = null));
      });
      iN(this, "ptrup", (a) => {
        gN(this, "Calling handleHoverStart due to pointer up");
        this.A = a.A;
        wN(this.handler, a);
      });
    }
  };
  function yN(a, b, c = !1, d = 0) {
    b = new oN(a.C, a, a.D, d, b, c);
    a.A && b.lock();
    return b;
  }
  var zN = class {
    constructor(a, b) {
      this.C = a;
      this.D = b;
      this.B = [];
      this.A = null;
    }
    claim(a) {
      if (this.A || !(qb(this.B, a) >= 0)) return !1;
      for (let b = 0; b < this.B.length; ++b) {
        let c = this.B[b];
        c !== a && c.lock();
      }
      this.A = a;
      return !0;
    }
    release(a) {
      if (!this.A || this.A !== a) return !1;
      for (let b = 0; b < this.B.length; ++b) {
        let c = this.B[b];
        c !== a && c.unlock();
      }
      this.A = null;
      return !0;
    }
    register(a) {
      qb(this.B, a) >= 0 || this.B.push(a);
    }
    unregister(a) {
      zb(this.B, a);
    }
  };
  function AN(a) {
    return (a = a.content.get()) && !gF(a)
      ? "Map \u00b7 Use arrow keys to pan the map." +
          (a?.A() === 3
            ? ""
            : " \u00b7 Get details about a place by pressing its corresponding number key.")
      : jF(a)
      ? "Photo"
      : iF(a)
      ? "Street View"
      : a?.A() === 5
      ? "Video"
      : "Main Display";
  }
  function BN(a) {
    a.Xc &&
      (a.A.pb("ptrdown", !1, (b, c) => {
        a.controller.A.Yg(RL(c), b);
      }),
      a.A.pb("ptrup", !1, (b, c) => {
        a.controller.A.bh(RL(c), b);
      }),
      a.A.pb("ptrin", !0, (b, c) => {
        var d = a.controller;
        d.A.lc &&
          ((d = d.A.lc),
          (c = RL(c)),
          uG(d, c),
          xF(d.A.getCursor(), !0),
          qG(d.A, c.x, c.y, b));
      }),
      a.A.pb("ptrout", !0, (b, c) => {
        b = a.controller;
        b.A.lc &&
          ((b = b.A.lc), uG(b, RL(c)), (c = b.A.getCursor()), xF(c, !1));
      }),
      CN(a),
      DN(a, 38),
      DN(a, 40),
      DN(a, 37),
      DN(a, 39),
      DN(a, 32),
      DN(a, 65),
      DN(a, 68),
      DN(a, 83),
      DN(a, 87),
      DN(a, 78),
      DN(a, 85),
      DN(a, 82),
      DN(a, 97),
      DN(a, 98),
      DN(a, 99),
      DN(a, 100),
      DN(a, 101),
      DN(a, 102),
      DN(a, 103),
      DN(a, 104),
      DN(a, 105),
      DN(a, 107),
      DN(a, 109),
      DN(a, 49),
      DN(a, 50),
      DN(a, 51),
      DN(a, 52),
      DN(a, 53),
      DN(a, 54),
      DN(a, 55),
      DN(a, 56),
      DN(a, 57),
      DN(a, 187),
      DN(a, 189),
      EN(a, 91, !0),
      EN(a, 17, !0),
      EN(a, 38, !1),
      EN(a, 40, !1),
      EN(a, 37, !1),
      EN(a, 39, !1),
      EN(a, 65, !1),
      EN(a, 68, !1),
      EN(a, 83, !1),
      EN(a, 87, !1));
    RM(a.A, "resize", !0, (b) => {
      wM(a.controller, b);
    });
    a.la.pb(a.namespace, a.action, "contextmenu", null, (b, c) => {
      c.preventDefault();
    });
  }
  function CN(a) {
    a.B ||
      (a.B = a.A.pb("scrollwheel", !0, (b, c) => {
        var d = a.controller;
        if (
          !((c.Yh && !d.hd()) || Math.abs(c.Se) < Math.abs(c.Qf) || c.Se === 0)
        ) {
          AM(d, c.x, c.y, d.J, b);
          document.body.focus();
          var e = c.ki;
          Math.abs(e) > 1 && (e = zo(e < 0 ? -1 : 1, e, IM));
          d.hd()
            ? (e = c.ctrlKey ? -e : -e / 4)
            : (e && Math.sign(e) !== Math.sign(d.D) && (d.D = 0),
              (d.D += e),
              d.Zc.stop(),
              d.Zc.start(b),
              Math.abs(d.D) >= 1
                ? ((e = d.D > 0 ? -1 : 1), (d.D -= Math.sign(d.D)))
                : (e = 0));
          e !== 0 && d.Nd(e, b, c.x, c.y, !0);
        }
      }));
  }
  function DN(a, b) {
    a.A.pb(
      "keydown",
      !1,
      (c, d) => {
        var e = a.controller;
        ((d.ctrlKey || d.metaKey || d.altKey) && !d.shiftKey) ||
          !e.A.keyboard ||
          KG(e.A.keyboard, d, c);
      },
      b
    );
  }
  function EN(a, b, c) {
    c
      ? a.A.Oc(
          "keyup",
          !1,
          (d, e) => {
            var f = a.controller;
            f.A.keyboard && f.A.keyboard.up(e, d);
          },
          b
        )
      : a.A.pb(
          "keyup",
          !1,
          (d, e) => {
            var f = a.controller;
            f.A.keyboard && f.A.keyboard.up(e, d);
          },
          b
        );
  }
  function FN(a, b) {
    if (a && b) {
      a = a.A;
      a.id = b.id;
      a.className = b.className;
      let c = b.parentNode;
      c && c.replaceChild(a, b);
    }
  }
  var LN = class extends FL {
    constructor(a, b, c, d, e, f, g, h, k, l, m, n, q, r, t) {
      super();
      this.view = e;
      this.width = cF();
      this.height = cF();
      this.camera = dF();
      this.Ea = dF();
      this.content = dF();
      this.N = dF();
      this.P = dF();
      this.K = dF();
      this.Ic = dF();
      this.Kc = dF();
      this.aa = dF();
      this.Ua = dF();
      this.T = dF();
      this.I = dF(!1);
      this.margin = dF();
      this.ariaLabel = cF();
      this.Ca = cF();
      this.B = this.H = this.F = this.canvas = null;
      this.width.listen(this.J, this);
      this.height.listen(this.J, this);
      this.content.listen(this.O, this);
      this.W = GN(c) === 1;
      a: switch (GN(c)) {
        case 1:
          e = 1;
          break a;
        case 2:
          e = 2;
          break a;
        default:
          e = 3;
      }
      this.D = dF(e);
      this.la = new GL(f);
      Yw(k, "render", new KL(g));
      e = new OL(this.Ea);
      ZE(e.content, this.content, m);
      Yw(k, "camera_change", e);
      this.Xc = C(b, 1);
      this.namespace = E(b, 82) || "scene";
      this.action = E(b, 83) || "viewport";
      this.A = f = new VM(f, this.namespace, this.action, g);
      this.rootElement = this.view.initialize({
        action: this.action,
        fc: E(b, 97),
        role: E(b, 96) || "application",
        Xc: this.Xc,
        label: AN(this),
        namespace: this.namespace,
      });
      a.appendChild(this.rootElement);
      e = (a || document).getElementsByTagName("CANVAS");
      var v = e[0];
      this.canvas = c.canvas;
      FN(this.canvas, v);
      v = iC || (iC = new jC());
      C(v, 4) && ((this.F = null), FN(this.F, e[1]));
      v = iC || (iC = new jC());
      C(v, 5) && ((this.H = null), FN(this.H, e[2]));
      e = Es(
        document,
        "DIV",
        "mapsConsumerUiSceneCoreScenecommon__imageryRender",
        a
      );
      (c = c.A) &&
        e.length === 1 &&
        ((v = e[0]),
        (c.id = v.id),
        (c.className = v.className),
        (e = e[0]),
        (v = e.parentNode) && v.replaceChild(c, e));
      c = null;
      a = Es(document, "DIV", "mapsConsumerUiSceneCoreScenecommon__effects", a);
      a.length === 1 && (c = a[0]);
      this.na = new PM(c || Js(document, "DIV"));
      this.na.bind(this.camera, this.Ic, m);
      b = C(b, 3) && !C(b, 8) && this.D.get() === 1;
      b = cF(!!b);
      ZE(this.P, b, m);
      this.C = new dN(f);
      this.C.Qe(!1);
      this.od = new zN(this.C, k);
      this.V = r.sf() || new rM(g);
      this.controller = new HM(
        q,
        t,
        this.V,
        d,
        this.W,
        this.C,
        h,
        k,
        this,
        m,
        l,
        this.view,
        n
      );
      ZE(this.controller.margin, this.margin, m);
      ZE(this.view.ariaLabel, this.ariaLabel, m);
      ZE(this.view.cursor, this.controller.cursor, m);
      ZE(this.view.tabIndex, this.controller.tabIndex, m);
      ZE(this.controller.width, this.width, m);
      ZE(this.controller.height, this.height, m);
      ZE(this.controller.P, this.P, m);
      ZE(this.controller.K, this.K, m);
      ZE(this.camera, this.controller.camera, m);
      ZE(this.Ca, this.controller.camera, m);
      ZE(this.Ea, this.controller.Ea, m);
      ZE(this.content, this.controller.content, m);
      ZE(this.N, this.controller.N, m);
      ZE(this.Ic, this.controller.Ic, m);
      ZE(this.Kc, this.controller.Kc, m);
      ZE(this.aa, dF(this.controller), m);
      ZE(this.Ua, this.controller.Ua, m);
      ZE(this.T, this.controller.T, m);
      ZE(this.I, this.controller.I, m);
      BN(this);
      this.C.G = this.controller;
      d = this.od;
      g = new pN(d.C, d, new HN(this.controller));
      d.A && g.lock();
      this.ea = g;
      d = this.od;
      g = new xN(d.C, d, new IN(this.controller));
      d.A && g.lock();
      this.ua = g;
      d = this.od;
      g = new vN(d.C, d, d.D, new JN(this.controller));
      d.A && g.lock();
      this.Da = g;
      d = new KN(this.controller);
      this.ga = yN(this.od, d, void 0, 0);
      this.sa = yN(this.od, d, void 0, 1);
    }
    jf(a) {
      a ? CN(this) : this.B && (this.A.Zb(this.B), (this.B = null));
    }
    focus() {
      this.rootElement.focus();
    }
    nf() {
      return this.controller.nf();
    }
    G(a) {
      this.la.dispose(a);
      this.controller.dispose(a);
      this.ea.dispose(a);
      this.ua.dispose(a);
      this.Da.dispose(a);
      this.ga.dispose(a);
      this.sa.dispose(a);
    }
    J(a) {
      SM(this.A, "resize", null, a, {
        type: "resize",
        target: null,
        preventDefault() {},
        stopPropagation() {},
      });
    }
    O(a) {
      this.ariaLabel.set(AN(this), a);
    }
  };
  class HN {
    constructor(a) {
      this.controller = a;
    }
    Wc(a) {
      var b = this.controller,
        c = a.cause,
        d = a.X;
      b.aa = !0;
      b.B.stop();
      d.A("scene", "move_camera");
      d.Fa("dr0");
      d.gb("dragging-branch");
      AM(b, c.x, c.y, !0, d, a.A);
      b.C.A++;
      a = RL(c);
      b.A.Kf(a, d);
      b.Sa = a;
      b.ua = a;
    }
    xf(a) {
      var b = this.controller,
        c = a.cause,
        d = RL(c);
      if (c.touches) {
        if (((a = a.X), b.A.Ua))
          if (d.type === "touchstart" || d.type === "touchend") b.A.Kf(d, a);
          else {
            if ((c = d.Ve))
              if (b.hd()) {
                let e = b.ua.Ve;
                Math.abs(c - e) > 1 &&
                  b.A.Ua.ue(Math.log(c / e) / Math.log(2), a, d.x, d.y);
              } else if ((c = Math.round(Math.log(c / b.Sa.Ve) / Math.log(2))))
                b.A.Ua.ue(c, a, d.x, d.y), (b.Sa = d);
            b.A.Lf(d, a);
          }
      } else b.A.Lf(d, a.X);
      b.ua = d;
    }
    yf(a) {
      var b = this.controller,
        c = a.cause,
        d = a.X;
      b.aa = !1;
      b.B.start(d);
      dM(b.C);
      b.A.Zg(RL(c), d);
      AM(b, c.x, c.y, !1, d, a.A);
      d.Fa("dr1");
      d.done("dragging-branch");
    }
  }
  function wN(a, b) {
    a = a.controller;
    var c = b.cause,
      d = b.X;
    AM(a, c.x, c.y, a.J, d, b.A);
    a.A.lc && ((b = RL(c)), pG(a.A.lc, b.x, b.y, d));
  }
  class IN {
    constructor(a) {
      this.controller = a;
    }
  }
  function uN(a, b) {
    a = a.controller;
    var c = a.content.get();
    if (!c || hF(c?.A())) b = !1;
    else {
      c = b.cause;
      var d = b.X;
      d.A("scene", "click_scene");
      AM(a, c.x, c.y, a.J, d, b.A);
      a.A.If(RL(c), d);
      b = !0;
    }
    return b;
  }
  class JN {
    constructor(a) {
      this.controller = a;
    }
  }
  class KN {
    constructor(a) {
      this.controller = a;
    }
  }
  function MN(a) {
    var b = dF(0);
    b.listen(a.H, a);
    return b;
  }
  function NN(a) {
    var b = dF();
    b.listen(a.H, a);
    return b;
  }
  var ON = class {
    constructor(a, b) {
      this.J = a;
      this.Db = 6;
      this.Fb = b;
      this.C = !1;
      this.B = [];
    }
    H(a) {
      a.gb("maps-consumer-kvo-view-redraw-later");
      this.B.push(a);
      this.C ||
        ((this.C = !0),
        qM(this.J, {
          Fb: this.Fb,
          Db: this.Db,
          render: () => {
            this.C = !1;
            var b = this.B;
            this.B = [];
            this.G();
            for (let c of b) c.done("maps-consumer-kvo-view-redraw-later");
          },
        }));
    }
  };
  var PN = class extends S {
    constructor(a) {
      super(a);
    }
    getCursor() {
      return E(this, 1);
    }
  }; /*
 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  function QN(a) {
    var b = a || RN;
    a = b.context;
    b = b.Gj;
    var c = E(a, 4) + "." + E(a, 5);
    var d =
      '<div class="' +
      Br("mapsImagerySceneScene__root") +
      " " +
      Br("widget-scene") +
      '"' +
      (E(a, 9) ? ' aria-describedby="' + Br(E(a, 9)) + '"' : "") +
      ' aria-label="' +
      Br(E(a, 6)) +
      '" role="' +
      Br(E(a, 8)) +
      '" style="cursor:';
    var e = a.getCursor();
    e =
      e != null && e.gf === rr
        ? Ar(e.Ia(), !1)
        : e == null
        ? ""
        : e instanceof Rn
        ? Ar(Sn(e), !1)
        : Ar(String(e), !0);
    a =
      d +
      Br(e) +
      '" tabindex="' +
      Br(Ef(a, 7)) +
      '" jsaction="' +
      Br(
        C(a, 2)
          ? "click: " +
              c +
              ";dblclick: " +
              c +
              ";mousedown: " +
              c +
              ";mousemove: " +
              c +
              ";mouseup: " +
              c +
              ";mouseover: " +
              c +
              ";mouseout: " +
              c +
              ";touchstart: " +
              c +
              ";touchmove: " +
              c +
              ";touchend: " +
              c +
              ";pointerdown: " +
              c +
              ";pointermove: " +
              c +
              ";pointerup: " +
              c +
              ";pointercancel: " +
              c +
              ";MSPointerDown: " +
              c +
              ";MSPointerMove: " +
              c +
              ";MSPointerUp: " +
              c +
              ";MSPointerCancel: " +
              c +
              ";contextmenu: " +
              c +
              ";keydown: " +
              c +
              ";keyup: " +
              c +
              ";wheel: " +
              c +
              ";mousewheel: " +
              c +
              ";DOMMouseScroll: " +
              c +
              ";"
          : ""
      ) +
      '"' +
      (b != null ? " ssk='" + Br("6:WAywEe" + b) + "'" : "") +
      '><canvas class="' +
      Br("mapsImagerySceneScene__canvas") +
      " " +
      Br("widget-scene-canvas") +
      '"></canvas><canvas class="' +
      Br("mapsImagerySceneScene__canvas") +
      " " +
      Br("widget-scene-canvas") +
      " " +
      Br("mapsConsumerUiSceneCoreScenecommon__impressCanvas") +
      " " +
      Br("mapsConsumerUiSceneCoreScenecommon__noprint") +
      " " +
      Br("mapsConsumerUiSceneCoreScenecommon__impressHidden") +
      '"></canvas><canvas class="' +
      Br("mapsImagerySceneScene__canvas") +
      " " +
      Br("widget-scene-canvas") +
      " " +
      Br("mapsConsumerUiSceneCoreScenecommon__impressCanvas") +
      " " +
      Br("mapsConsumerUiSceneCoreScenecommon__noprint") +
      " " +
      Br("mapsConsumerUiSceneCoreScenecommon__impressHidden") +
      '"></canvas><div class="' +
      Br("mapsConsumerUiSceneCoreScenecommon__impressIndicator") +
      " " +
      Br("mapsConsumerUiSceneCoreScenecommon__impressHidden") +
      '"></div><div class="' +
      Br("mapsConsumerUiSceneCoreScenecommon__imageryRender") +
      " " +
      Br("widget-scene-imagery-render") +
      '"></div><div class="' +
      Br("mapsConsumerUiSceneCoreScenecommon__effects") +
      " " +
      Br("mapsConsumerLibAppPrint__noprint") +
      '"></div><div class="' +
      Br("mapsImagerySceneScene__focusOutline") +
      '"></div></div>';
    c = ur(a);
    a: {
      a = Bs();
      b = c && c.si ? c.si() : null;
      if (!b) {
        b: if (ra(c)) {
          if (c.gh) {
            var f = c.gh();
            if (f instanceof Ln) break b;
          }
          f = yp("zSoyz");
        } else f = yp(String(c));
        b = Rs(a, "DIV");
        b.innerHTML = Nn(f);
        f = b.childNodes;
      }
      if (f.length == 1 && ((c = f[0]), c.nodeType == 1)) {
        f = c;
        break a;
      }
      b || ((b = Rs(a, "DIV")), b.append(...f));
      f = b;
    }
    return f;
  }
  var RN = {};
  var SN = class extends ON {
    constructor(a, b, c) {
      super(b, 104);
      this.I = a;
      this.D = c;
      this.ariaLabel = NN(this);
      this.cursor = NN(this);
      this.tabIndex = MN(this);
      this.F = new gj();
      this.A = document.createElement("div");
      this.context = new PN();
      a = this.I.A;
      a.width === 0 && (a.width = 1);
      a.height === 0 && (a.height = 1);
    }
    initialize(a = {}) {
      a.action && Q(this.context, 5, a.action);
      a.fc && Q(this.context, 9, a.fc);
      a.Xc !== void 0 && M(this.context, 2, a.Xc);
      a.label && Q(this.context, 6, a.label);
      a.namespace && Q(this.context, 4, a.namespace);
      a.role && Q(this.context, 8, a.role);
      return (this.A = QN({ context: this.context }));
    }
    resize(a) {
      this.F = a;
      jJ(this.I, u.devicePixelRatio || 1, this.F.S(), this.F.R());
    }
    G() {
      this.A.setAttribute("aria-label", this.ariaLabel.get() || "");
      this.A.style.cursor = this.cursor.get() || "";
      this.A.setAttribute("tabindex", `${this.tabIndex.get() || 0}`);
    }
  };
  var TN = class extends dz {
    constructor(a, b, c, d, e, f, g, h, k, l) {
      super("SCW", [...arguments]);
    }
  };
  var UN = class extends ON {
    constructor(a) {
      super(a, 105);
      this.ariaLabel = NN(this);
      this.cursor = NN(this);
      this.tabIndex = MN(this);
      this.A = document.createElement("div");
      this.context = new PN();
    }
    initialize(a = {}) {
      a.action && Q(this.context, 5, a.action);
      a.fc && Q(this.context, 9, a.fc);
      a.Xc !== void 0 && M(this.context, 2, a.Xc);
      a.label && Q(this.context, 6, a.label);
      a.namespace && Q(this.context, 4, a.namespace);
      a.role && Q(this.context, 8, a.role);
      return (this.A = QN({ context: this.context }));
    }
    G() {
      this.A.setAttribute("aria-label", this.ariaLabel.get() || "");
      this.A.style.cursor = this.cursor.get() || "";
      this.A.setAttribute("tabindex", `${this.tabIndex.get() || 0}`);
    }
    resize() {}
  };
  function cM(a, b) {
    a.A ? b(null) : ((a.A = !0), b(new VN(a.config)));
  }
  function GM(a, b) {
    b(a);
  }
  var WN = class {
    constructor(a) {
      this.config = a;
      this.A = !1;
    }
    Ta() {}
    Ie() {
      return "df0";
    }
  };
  class VN {
    constructor(a) {
      this.config = a;
      a = A(this.config.A, yB, 3);
      M(a, 1, !1);
    }
    Td() {
      return 0;
    }
    de() {
      return this.config.B;
    }
    ee() {
      return this.config.A;
    }
  }
  var XN = class {
    load(a, b, c) {
      b.Fa("tdfl0");
      c(new WN(a), b);
      b.Fa("tdfl1");
      return new KE("Unable to stop load of the transition.");
    }
  };
  function YN(a, b, c, d, e, f, g, h, k, l, m, n) {
    k.getContext(function (q, r) {
      if (Ff(d, 21, 1) !== 3 && !q.A && !q.C)
        throw Error("Could not build a rendering context for the scene.");
      var t = k.canvas;
      t = t ? new SN(t, f, q.A ? 1 : q.C ? 2 : 3) : new UN(f);
      var v = new XN();
      q = new LN(
        c,
        d,
        k,
        Promise.resolve(q),
        t,
        new EL(e, c),
        f,
        g,
        h,
        l,
        r,
        () => {},
        m,
        n,
        v
      );
      a(q);
    }, b);
    Ff(d, 21, 1);
  }
  function ZN(a, b, c) {
    var d = c.x,
      e = c.y,
      f = c.zoom,
      g = c.oi,
      h = new sA();
    h.params.panoid = c.Lc;
    h.params.x = `${d}`;
    h.params.y = `${e}`;
    h.params.zoom = `${f}`;
    h.params.nbt = "1";
    h.params.fover = "2";
    g && (h.params.pt = g);
    (c = Gw()) && (h.params["context.epoch_override"] = String(c));
    a = a.toString();
    b = b.vc(h);
    return a.indexOf("?") === -1 ? `${a}?${b}` : `${a}&${b}`;
  }
  var $N = class {
    constructor(a, b) {
      this.B = a;
      this.C = new rA();
      a = new Qo(b);
      a.F = "/v1/tile";
      this.A = a;
    }
    Nb(a, b, c, d, e, f) {
      a = a.Ia();
      if (!a) return () => {};
      var g = Z(a);
      a = nA(g);
      if (!a) return () => {};
      g = Ik(Gl(g.Y()));
      e = f.U(e, "svt-get-tile");
      return this.B.ub(
        ZN(this.A, this.C, { Lc: a, x: b, y: c, zoom: d, oi: g }),
        e
      );
    }
    Qb() {}
  };
  function aO(a, b, c, d) {
    b = new $N(c, d);
    a(b);
  }
  var dO = class extends TI {
      constructor(a) {
        super(
          a,
          "const float f=3.1415926;varying vec3 a;uniform vec4 b;attribute vec3 c;attribute vec2 d;uniform mat4 e;void main(){vec4 g=vec4(c,1);gl_Position=e*g;a=vec3(d.xy*b.xy+b.zw,1);a*=length(c);}",
          "precision highp float;const float h=3.1415926;varying vec3 a;uniform vec4 b;uniform float f;uniform sampler2D g;void main(){vec4 i=vec4(texture2DProj(g,a).rgb,f);gl_FragColor=i;}"
        );
        this.uniforms = new bO(this);
        this.attributes = new cO(this);
      }
    },
    bO = class {
      constructor(a) {
        this.A = new aJ("b", a);
        this.B = new cJ("e", a);
        this.alpha = new XI("f", a);
        this.sampler = new WI("g", a);
      }
    },
    cO = class {
      constructor(a) {
        this.B = new II("c", a);
        this.A = new II("d", a);
      }
    };
  var gO = class extends TI {
      constructor(a) {
        super(
          a,
          "attribute vec3 a;attribute vec2 b;uniform mat4 c;varying vec3 d;void main(){gl_Position=c*vec4(a,1);d=vec3(b.xy,1);}",
          "precision mediump float;uniform float e;uniform sampler2D f;varying vec3 d;void main(){vec4 g=texture2DProj(f,d);gl_FragColor=vec4(g.rgb,g.a*e);}"
        );
        this.uniforms = new eO(this);
        this.attributes = new fO(this);
      }
    },
    eO = class {
      constructor(a) {
        this.A = new cJ("c", a);
        this.opacity = new XI("e", a);
        this.sampler = new WI("f", a);
      }
    },
    fO = class {
      constructor(a) {
        this.position = new II("a", a);
        this.A = new II("b", a);
      }
    };
  function hO(a, b) {
    if (!b) return iO(a);
    try {
      var c = jO(a, 3553);
      kO(c, b.width, b.height);
      let d = c.target === 34067 ? c.D : c.target;
      c.bind();
      lO(c, b.width);
      c.B.texImage2D(d, 0, 6408, 6408, 5121, b);
      c.state.K(3317);
    } catch (d) {
      return u.console && u.console.log(d), iO(a);
    }
    return b.width * b.height * 4;
  }
  function iO(a) {
    var b = new Uint8Array([0, 0, 0, 0]);
    a = jO(a, 3553);
    kO(a, 1, 1);
    var c = a.target === 34067 ? a.D : a.target;
    a.bind();
    lO(a, 1);
    a.B.texImage2D(c, 0, 6408, 1, 1, 0, 6408, 5121, b);
    a.state.K(3317);
    return 4;
  }
  function mO(a, b) {
    return a.context.A.contains(b) ? (iK(a.context.A, b), !0) : !1;
  }
  var oO = class {
    constructor(a, b) {
      this.label = a;
      this.context = b;
      this.A = this.B = this.C = -1;
    }
    Ka() {
      return (
        this.context.A.contains(this.C) &&
        this.context.A.contains(this.B) &&
        this.context.A.contains(this.A)
      );
    }
    Gb() {
      if (!mO(this, this.C)) {
        var a = this.label.vertices,
          b = this.context.ca.createBuffer(),
          c = this.context.A;
        this.C = c.cache.add(b, c.L, 4 * a.length, 0);
        pI(this.context, 34962, b);
        this.context.ca.bufferData(34962, a, 35044);
      }
      mO(this, this.B) ||
        ((c = this.label.A),
        (c = [0, c.C, 0, 0, c.D, c.C, c.D, 0]),
        (b = this.context.ca.createBuffer()),
        (a = this.context.A),
        (this.B = a.cache.add(b, a.L, 4 * c.length, 0)),
        pI(this.context, 34962, b),
        (a = this.context),
        (c = new Float32Array(c)),
        a.ca.bufferData(34962, c, 35044));
      if (!mO(this, this.A)) {
        c = this.context.createTexture();
        this.context.bindTexture(3553, c);
        this.context.texParameteri(3553, 10241, 9985);
        this.context.texParameteri(3553, 10240, 9729);
        this.context.texParameteri(3553, 10242, 33071);
        this.context.texParameteri(3553, 10243, 33071);
        a = hO(this.context, et(this.label.A));
        b = Math.round((a * 4) / 3);
        a = jO(this.context, 3553);
        if (a.target === 34067) for (let d = 0; d < 6; ++d);
        a.bind();
        a.B.generateMipmap(a.target);
        this.A = nO(this.context.A, c, b);
      }
    }
  };
  var pO = class extends Vu {
    constructor(a, b) {
      super(a);
      this.context = b;
      this.G = null;
      this.L = 1;
      this.A = new gO(b);
    }
    D() {
      var a = this.context;
      a.state.L(!1);
      hK(a, 2884);
      a.state.F(3042, !0);
      hK(a, 2929);
      hK(a, 2960);
      hK(a, 3089);
      super.D();
      a.state.L(!0);
    }
    I(a) {
      return new oO(a, this.context);
    }
    draw(a) {
      if (a.Ka() && this.G) {
        var b = this.context;
        iK(a.context.A, a.C);
        var c = a.context.A.getBuffer(a.C) || null;
        iK(a.context.A, a.B);
        var d = a.context.A.getBuffer(a.B) || null;
        let e = this.context,
          f = this.A;
        GI(f).ec();
        f.uniforms.sampler.set(0);
        f.uniforms.opacity.set(this.L);
        let g = FI(f.attributes.position),
          h = FI(f.attributes.A);
        e.state.H(g, !0);
        e.state.H(h, !0);
        pI(e, 34962, c);
        HI(f.attributes.position, 3);
        pI(e, 34962, d);
        HI(f.attributes.A, 2);
        bJ(this.A.uniforms.A, mv(this.G));
        pI(b, 34962, c);
        b.state.J(33984);
        c = b.bindTexture;
        iK(a.context.A, a.A);
        a = a.context.A.cache.get(a.A);
        c.call(b, 3553, a || null);
        b.ca.drawArrays(5, 0, 4);
        kK(b, FI(this.A.attributes.position));
        kK(b, FI(this.A.attributes.A));
      }
    }
  };
  var qO = class extends jw {
    constructor(a, b, c, d, e, f) {
      super(a, b, c, d, e);
      this.context = f;
      this.B = -1;
    }
    A() {
      iK(this.context.A, this.B);
      return this.context.A.cache.get(this.B) || null;
    }
    Ka() {
      return this.context.A.contains(this.B);
    }
    Gb() {
      this.Ka() ? iK(this.context.A, this.B) : this.Hb();
    }
    Hb() {
      var a = this.context.createTexture();
      this.context.bindTexture(3553, a);
      this.context.texParameteri(3553, 10241, 9729);
      this.context.texParameteri(3553, 10240, 9729);
      this.context.texParameteri(3553, 10242, 33071);
      this.context.texParameteri(3553, 10243, 33071);
      var b = hO(this.context, this.ub());
      this.B = nO(this.context.A, a, b);
    }
  };
  function rO(a) {
    var b = ww(a);
    a.K = a.context.ca.createBuffer();
    var c = Jv(a);
    a.M = a.context.ca.createBuffer();
    var d = b.byteLength + c.byteLength,
      e = a.C instanceof by,
      f = null;
    e &&
      ((f = Kv(a)), (a.N = a.context.ca.createBuffer()), (d += f.byteLength));
    a.G = oI(
      a.context.A,
      () => {
        e && a.N && a.context.deleteBuffer(a.N);
        a.K && a.context.deleteBuffer(a.K);
        a.M && a.context.deleteBuffer(a.M);
        a.N = a.M = a.K = null;
        a.G = -1;
      },
      d
    );
    e && (pI(a.context, 34962, a.N), a.context.ca.bufferData(34962, f, 35044));
    pI(a.context, 34962, a.K);
    a.context.ca.bufferData(34962, b, 35044);
    pI(a.context, 34963, a.M);
    a.context.ca.bufferData(34963, c, 35044);
  }
  var sO = class extends xw {
      constructor(a, b, c, d, e, f) {
        super(a, b, c, d, e);
        this.context = f;
        this.G = -1;
        this.M = this.K = this.N = null;
      }
      F() {
        return this.context.A.contains(this.G);
      }
      L() {
        this.context.A.contains(this.G) ? iK(this.context.A, this.G) : rO(this);
      }
      P(a, b) {
        return new qO(a.getX(), a.getY(), a.zoom, a.ub(), b, this.context);
      }
    },
    tO = class {
      constructor(a) {
        this.context = a;
      }
      create(a, b, c, d, e) {
        return new sO(a, b, c, d, e, this.context);
      }
    };
  var wO = class extends TI {
      constructor(a) {
        super(
          a,
          "attribute vec2 a;uniform vec4 b;uniform mat4 c;varying vec2 d;void main(){gl_Position=c*vec4(a.x,a.y,1,1);d=a.xy*b.xy+b.zw;}",
          "precision highp float;uniform float e,f;uniform sampler2D g;varying vec2 d;float j(){if(f==0.)return 1.;else{vec2 h=abs(d-.5)-.5+f;return 1.-length(max(h,0.))/f;}}void main(){vec4 h=texture2D(g,d);float i=j();gl_FragColor=vec4(h.rgb,e*i);}"
        );
        this.uniforms = new uO(this);
        this.attributes = new vO(this);
      }
    },
    uO = class {
      constructor(a) {
        this.A = new aJ("b", a);
        this.B = new cJ("c", a);
        this.alpha = new XI("e", a);
        this.C = new XI("f", a);
        this.sampler = new WI("g", a);
      }
    },
    vO = class {
      constructor(a) {
        this.A = new II("a", a);
      }
    };
  var xO = class {
    constructor(a) {
      this.context = a;
      this.B = 0;
      this.A = new Ss(0, 0, 0, 0);
      this.D = new dO(this.context);
      this.F = new wO(this.context);
      this.C = new pO(new Fv(), this.context);
    }
    lg() {
      this.context.C.H(null);
      this.context.state.ea(1029);
      this.context.depthFunc(515);
      this.context.state.L(!0);
      hK(this.context, 3089);
      hK(this.context, 2960);
      for (var a = 0; a < 8; ++a) kK(this.context, a);
      this.context.state.F(3042, !0);
      this.context.state.F(2884, !0);
      this.context.state.F(2929, !0);
      this.context.state.O(770, 771, 1, 771);
      var b = this.context.canvas.A,
        c = u.devicePixelRatio || 1;
      a = this.context;
      var d = this.A.left * c,
        e = this.A.bottom * c,
        f = b.width - (this.A.left + this.A.right) * c;
      b = b.height - (this.A.top + this.A.bottom) * c;
      jK(a);
      a.state.N(d, e, f, b);
      this.context.clearColor(this.B, this.B, this.B, 1);
      this.context.clear(16640);
    }
    jg() {
      var a = this.context.canvas.A,
        b = this.context,
        c = a.width;
      a = a.height;
      jK(b);
      b.state.N(0, 0, c, a);
    }
    Ce(a, b, c) {
      if (D(b, 1) !== 0 && !this.context.isContextLost()) {
        this.context.clear(256);
        var d = a instanceof by,
          e = d ? this.D : this.F;
        GI(e).ec();
        bJ(e.uniforms.B, mv(c));
        e.uniforms.alpha.set(D(b, 1));
        e.uniforms.sampler.set(0);
        var f = -1;
        d && ((f = FI(e.attributes.B)), this.context.state.H(f, !0));
        var g = FI(e.attributes.A);
        this.context.state.H(g, !0);
        e.uniforms.C && e.uniforms.C.set(D(b, 2));
        let q = Hv(c);
        this.context.state.J(33984);
        let r = q.length;
        for (let t = 0; t < r; ++t) {
          var h = a;
          var k = q[t],
            l = b;
          if (k.Ka()) {
            if (h instanceof by) {
              var m = this.context;
              iK(k.context.A, k.G);
              h = k.N;
              pI(m, 34962, h);
              HI(e.attributes.B, 3);
            }
            m = this.context;
            iK(k.context.A, k.G);
            h = k.K;
            pI(m, 34962, h);
            HI(e.attributes.A, 2);
            m = this.context;
            iK(k.context.A, k.G);
            h = k.M;
            pI(m, 34963, h);
            h = Jv(k);
            l = D(l, 1);
            m = k.Fd;
            k.V || k.Xd();
            var n = k.V;
            if (m < 1 && n) {
              m = KF(m);
              let v = n.A();
              this.context.bindTexture(3553, v);
              $I(e.uniforms.A, n.C);
              e.uniforms.alpha.set(l);
              this.context.ca.drawElements(5, h.length, 5123, 0);
            }
            k = k.Xd();
            n = k.A();
            this.context.bindTexture(3553, n);
            $I(e.uniforms.A, k.C);
            e.uniforms.alpha.set(l * m);
            this.context.ca.drawElements(5, h.length, 5123, 0);
          }
        }
        e.uniforms.alpha.set(D(b, 1));
        kK(this.context, g);
        d && kK(this.context, f);
        b = D(b, 5);
        a = a.hc();
        b > 0 &&
          a.length > 0 &&
          (this.C.bd(a), (this.C.G = c), (this.C.L = b), this.C.run());
      }
    }
    Ib(a) {
      this.B = a;
    }
    Ta(a, b, c, d) {
      this.A.top = a;
      this.A.right = b;
      this.A.bottom = c;
      this.A.left = d;
    }
  };
  var yO = class extends Zx {
    constructor(a, b, c) {
      super(a, new xO(b), new By(new tO(b)), c);
    }
  };
  function zO(a, b, c, d, e) {
    b = new yO(c, d, e);
    a(b);
  }
  function AO(a, b) {
    R(a, 14, b);
  }
  var BO = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var CO;
  function DO(a, b, c) {
    a.A[b] = c;
  }
  var EO = class {
    constructor() {
      this.A = {};
    }
    load(a, b, c) {
      var d;
      a?.A() === 0
        ? (d = 0)
        : a?.A() === 3
        ? (d = 3)
        : iF(a)
        ? (d = 1)
        : jF(a)
        ? (d = 2)
        : a?.A() === 5
        ? (d = 5)
        : a?.A() === 4 && (d = 4);
      this.A[d].load(a, b, c);
    }
  };
  var FO = class extends dz {
    constructor(a, b, c, d, e, f) {
      super("SCIR", [...arguments]);
    }
  };
  var GO = class extends dz {
    constructor(a, b, c, d, e, f) {
      super("SCVR", [...arguments]);
    }
  };
  function HO(a, b, c) {
    var d = a.F.pa;
    if (d)
      if (d.Ha()) b(d.ka());
      else
        d.onLoad((e) => {
          b(e);
        }, c);
    else
      a.load("pa", c, (e) => {
        b(e);
      });
  }
  var IO = class {
    constructor(a, b, c, d, e, f, g, h, k = null) {
      this.config = a;
      this.locale = b;
      this.B = c;
      this.D = d;
      this.C = f;
      this.G = g;
      this.H = h;
      this.Be = k;
      this.F = {};
      this.A = new rM(e, void 0, C(a, 56));
    }
    load(a, b, c) {
      var d = this.F[a];
      if (d) d.onLoad(c, b);
      else {
        if (a === "pa") {
          b.Fa("pard0");
          var e = "pard1";
          var f = new aH(
            this.A,
            this.B,
            this.config,
            this.locale,
            this.D,
            this.C,
            this.G,
            this.H,
            this.Be
          );
        } else
          a === "ph"
            ? (b.Fa("phrd0"),
              (e = "phrd1"),
              (f = new FO(
                this.A,
                this.B,
                this.config,
                this.locale,
                this.D,
                this.C
              )))
            : a === "vd" &&
              (b.Fa("vdrd0"),
              (e = "vdrd1"),
              (f = new GO(
                this.A,
                this.B,
                this.config,
                this.locale,
                this.D,
                this.C
              )));
        this.F[a] = f;
        f.get((g, h) => {
          h.Fa(e);
          c(g, h);
        }, b);
      }
      return new KE("Unable to stop load of delayed render drivers.");
    }
    sf() {
      return this.A;
    }
  };
  var JO = class {
    constructor(a, b, c, d, e = () => {}) {
      this.F = a;
      this.locale = b;
      this.G = c;
      this.D = d;
      this.C = e;
      this.B = this.A = null;
    }
    load(a, b, c) {
      this.A
        ? (b(this.A, c), this.C(this.A))
        : (this.B || (this.B = new qE(this.G, this.F, this.locale, this.D)),
          this.B.get((d, e) => {
            this.A = d;
            b(this.A, e);
            this.C(this.A);
          }, c));
    }
  };
  var KO = class extends dz {
    constructor(a, b, c, d) {
      super("SCHI", [...arguments]);
    }
  };
  var LO = class {
    constructor(a, b, c) {
      this.locale = a;
      this.C = b;
      this.B = c;
      this.A = null;
    }
    load(a, b, c) {
      this.A || (this.A = new KO(this.C, this.locale, this.B, !0));
      this.A.get((d, e) => {
        b(d, e);
      }, c);
    }
  };
  var MO = class extends dz {
    constructor(a, b) {
      super("SCVI", [...arguments]);
    }
  };
  var NO = class {
    constructor(a, b) {
      this.locale = a;
      this.B = b;
      this.A = null;
    }
    load(a, b, c) {
      this.A || (this.A = new MO(this.B, this.locale));
      this.A.get((d, e) => {
        b(d, e);
      }, c);
    }
  };
  var OO = class extends S {
    constructor(a) {
      super(a);
    }
    Ia() {
      return yf(this, HB, 1);
    }
    Xa() {
      return yf(this, U, 2);
    }
    oa() {
      return B(this, U, 2);
    }
    ja() {
      return A(this, U, 2);
    }
    setCamera(a) {
      return zf(this, U, 2, a);
    }
  };
  var PO = class extends dz {
    constructor(a, b, c, d, e, f) {
      super("FP", [...arguments]);
    }
  };
  var QO = class {
    wg() {
      return "invalidSessionEventId";
    }
    xg() {
      return {};
    }
    yg() {
      return {};
    }
  };
  function RO(a, b, c) {
    var d = c ? c : new Jw(SO, "buff_pass_logger");
    b.get((e) => {
      a.A = e;
      e = a.B.length;
      for (let f = 0; f < e; f++) {
        let g = a.B[f];
        g.ii(a.A).apply(a.A, g.args);
        g.X && g.X.done("bpl-branch");
      }
      a.B.length = 0;
      a.C = null;
      c || d.done("main-actionflow-branch");
    }, d);
  }
  function TO(a, b, c) {
    a.B.length ? RO(a, b, c) : (a.C = b);
  }
  var UO = class {
      constructor() {
        this.Jd = new QO();
        this.C = this.A = null;
        this.B = [];
      }
      handle(a, b, c) {
        this.A
          ? a(this.A).apply(this.A, b)
          : (c && c.gb("bpl-branch"),
            this.B.push({ ii: a, args: b, X: c }),
            this.C && RO(this, this.C));
      }
      Ef(a, b) {
        this.handle((c) => c.Ef, arguments, b);
        return !0;
      }
      te(a, b, c) {
        this.handle((d) => d.te, arguments, null);
      }
    },
    SO = new $w();
  var WO = class {
    constructor() {
      this.A = new VO();
    }
    Ha() {
      return !0;
    }
    get(a, b) {
      a(this.A, b);
    }
    ka() {
      return this.A;
    }
    onLoad(a, b) {
      this.get(a, b);
    }
  };
  function XO(a, b) {
    if (a.C) throw Error("LogEvent has already been reported!");
    a.J = b;
  }
  function YO(a, b) {
    if (a.C) throw Error("LogEvent has already been reported!");
    a.I = b;
  }
  var ZO = class {
    constructor(a, b) {
      this.D = a;
      this.H = b;
      this.C = !1;
      this.I = this.J = null;
      this.M = b.wg();
    }
    tb() {
      return this.M;
    }
    Nc(a) {
      if (this.C) throw Error("LogEvent has already been reported!");
      this.C = !0;
      var b = new fD(),
        c = this.F(b) || [];
      var d = A(b, wB, 29);
      d = Q(d, 17, this.M);
      this.J && Q(d, 1, this.J);
      this.I && Q(d, 9, this.I);
      E(d, 9) || E(d, 1) || gD(E(d, 2));
      a ? y(a, d) : this.D.Nc(b);
      for (let e of c) e.Nc();
    }
  };
  function $O(a, b, c = {}) {
    a.error = b;
    a.Re = c.Re || null;
    a.De = c.De || null;
    a.message = b.message;
    a.errorType = 1;
  }
  var cP = class extends ZO {
    constructor(
      a,
      b,
      c,
      {
        glRenderer: d = null,
        glErrorCode: e = null,
        webGlErrors: f = null,
        isContextLost: g = null,
        jsVersion: h = null,
        Bf: k = null,
        wasmHeapSizeBytes: l = null,
        wasmHeapDeltaBytes: m = null,
        wasmMemoryStats: n = null,
        width: q = null,
        height: r = null,
        appCrashType: t = null,
        appCrashRenderContext: v = null,
        appCrashTime: F = null,
        appCrashDuration: H = null,
        appCrashJsVersion: I = null,
      } = {}
    ) {
      super(a, b);
      this.G = c;
      this.count = 1;
      this.message = "";
      this.appCrashJsVersion =
        this.appCrashDuration =
        this.appCrashTime =
        this.appCrashRenderContext =
        this.appCrashType =
        this.height =
        this.width =
        this.wasmMemoryStats =
        this.wasmHeapDeltaBytes =
        this.wasmHeapSizeBytes =
        this.isContextLost =
        this.webGlErrors =
        this.glErrorCode =
        this.glRenderer =
        this.De =
        this.Re =
        this.error =
        this.errorType =
          null;
      this.glRenderer = d;
      this.glErrorCode = e;
      this.webGlErrors = f;
      this.isContextLost = g;
      this.wasmHeapSizeBytes = l;
      this.wasmHeapDeltaBytes = m;
      this.wasmMemoryStats = n;
      this.width = q;
      this.height = r;
      this.appCrashType = t;
      this.appCrashRenderContext = v;
      this.appCrashTime = F;
      this.appCrashDuration = H;
      this.appCrashJsVersion = I;
      this.Bf = k;
      this.jsVersion = h;
    }
    B(a) {
      this.width = a;
    }
    A(a) {
      this.height = a;
    }
    F(a) {
      vB(A(a, wB, 29), this.G.bb);
      R(a, 2, 6);
      this.count !== 1 && N(a, 7, this.count);
      a = A(a, cD, 9);
      this.message && Q(a, 1, this.message);
      if (this.De) {
        var b = A(a, aD, 12);
        y(b, this.De);
      }
      if (
        this.error &&
        ((b = on(this.error)),
        b.stack === "Not available" && (b.stack = sn(this.Re)),
        Q(a, 2, (String(b.fileName) || "Not available").substring(0, 400)),
        (b = b.lineNumber),
        typeof b === "number" && N(a, 3, b),
        (b = this.error),
        typeof b.stack === "string")
      ) {
        var c = aP(b.stack);
        b = [];
        var d = c;
        var e = b,
          f = 1700 - (3 + this.error.message.length * 1.1);
        Gy(d, e);
        (d = Hy(d, e, f)) && N(a, 9, d);
        c = pf(a, 4, c, ce);
        pf(c, 10, b, ce);
      }
      this.errorType !== null && R(a, 8, this.errorType);
      (b = navigator.deviceMemory) && P(a, 21, b);
      this.glRenderer && Q(a, 14, this.glRenderer);
      bP(this.glErrorCode) && ((b = A(a, bD, 26)), N(b, 1, this.glErrorCode));
      this.webGlErrors &&
        this.webGlErrors.length &&
        pf(a, 22, this.webGlErrors, Md);
      this.isContextLost != null && M(a, 19, this.isContextLost);
      this.Bf && Q(a, 11, this.Bf);
      this.jsVersion && Q(a, 6, this.jsVersion);
      bP(this.wasmHeapSizeBytes) &&
        ((b = Math.round(this.wasmHeapSizeBytes)),
        bf(a, 15, b == null ? b : Pd(b)));
      bP(this.wasmHeapDeltaBytes) &&
        ((b = Math.round(this.wasmHeapDeltaBytes)),
        bf(a, 16, b == null ? b : Pd(b)));
      this.wasmMemoryStats &&
        this.wasmMemoryStats.length > 0 &&
        pf(a, 20, this.wasmMemoryStats, Md);
      bP(this.width) && a.B(Math.round(this.width));
      bP(this.height) && a.A(Math.round(this.height));
      this.appCrashType && ((b = A(a, $C, 25)), R(b, 1, this.appCrashType));
      this.appCrashRenderContext &&
        ((b = A(a, $C, 25)), R(b, 2, this.appCrashRenderContext));
      bP(this.appCrashTime) &&
        ((b = A(a, $C, 25)), Nf(b, 3, this.appCrashTime));
      bP(this.appCrashDuration) &&
        ((b = A(a, $C, 25)), Nf(b, 4, this.appCrashDuration));
      this.appCrashJsVersion &&
        ((a = A(a, $C, 25)), Q(a, 5, this.appCrashJsVersion));
      return null;
    }
  };
  function aP(a) {
    return a
      .split("\n")
      .map((b) => b.trim())
      .filter((b) => b.length > 0)
      .filter((b, c) => c < 40);
  }
  function bP(a) {
    return typeof a === "number" && isFinite(a);
  }
  var dP = class extends hD {
      constructor(a, b, c) {
        super(a, "");
        this.index = b;
        this.D = c;
        this.children = [];
        this.Wg = null;
        this.Ze = 0;
        this.ud = null;
      }
      parent() {
        return this.Wg;
      }
      bb() {
        return this.D ? this.D.bb : null;
      }
      G() {
        var a = new Sr();
        this.D && this.D.bb !== 12877 && N(a, 1, this.D.bb);
        this.ud !== null && N(a, 3, this.ud);
        for (let b of this.children) Af(a, 4, Md, b.index, void 0, Nd);
        return a;
      }
      C() {
        var a = this.J(),
          b = this.tb(),
          c = [];
        Df(a, 1) != null && c.push("i:" + Ef(a, 1, -1));
        Df(a, 2) != null && c.push("t:" + Ef(a, 2));
        Df(a, 8) != null && c.push("y:" + Ef(a, 8));
        Df(a, 5) != null && c.push("e:" + Ef(a, 5, -1));
        Df(a, 6) != null && c.push("r:" + Ef(a, 6, -1));
        Df(a, 7) != null && c.push("s:" + Ef(a, 7));
        b && c.push("p:" + b);
        return "1" + c.join(",");
      }
      J() {
        var a = new Lr();
        a = N(a, 1, this.index);
        var b = this.bb();
        b !== null && N(a, 2, b);
        this.ud !== null && N(a, 5, this.ud);
        return a;
      }
    },
    eP = class {
      constructor(a, b, c) {
        this.A = a;
        this.parent = b;
        this.B = c;
      }
    };
  var fP = class extends ZO {
    constructor(a, b, c, d) {
      super(a, b);
      this.A = c;
      this.target = d;
      this.clone = null;
    }
    F(a) {
      vB(A(a, wB, 29), 27626);
      R(a, 2, this.A);
      a = A(a, dD, 20);
      a = Q(a, 1, this.target.tb());
      var b = this.target.C();
      a = Q(a, 2, b);
      this.clone !== null &&
        ((a = Q(a, 3, this.clone.tb())), (b = this.clone.C()), Q(a, 4, b));
      return null;
    }
  };
  function gP(a, b, c, d) {
    var e = a.map((f) => f.event);
    a = a.map((f) => {
      var g = f.A;
      f = new fP(b, c, 22, f.parent);
      f.clone = g;
      XO(f, d);
      YO(f, d);
      return f;
    });
    return [...e, ...a];
  }
  var hP = class {
    constructor(a, b, c, d) {
      this.parent = b;
      this.event = c;
      this.A = d;
      XO(c, a.tb());
      YO(c, a.tb());
    }
  };
  var FG = class extends ZO {
    constructor(a, b, c, d) {
      super(a, b);
      this.B = c;
      this.G = d;
      this.K = [];
      this.A = null;
    }
    F(a) {
      a = A(a, wB, 29);
      a = Q(a, 1, this.B.tb());
      var b = this.B.C();
      a = Q(a, 2, b);
      this.G !== void 0 && R(a, 12, this.G);
      this.A !== null && R(a, 13, this.A);
      for (let c of this.K) Of(a, 18, c);
      return null;
    }
  };
  var iP = class extends dP {
    constructor(a, b, c, d, e, f) {
      super(c.tb(), d, e);
      this.I = a;
      this.H = b;
      this.M = c;
      this.N = f;
      this.F = this.B = this.A = this.resultIndex = null;
    }
    ea(a) {
      var b = this.N(a, this);
      a = b.A;
      var c = b.parent;
      c
        ? (b.B
            ? ((b = c.children.length + c.Ze), (c.Ze += 1))
            : ((b = c.children.length), c.children.push(a), (a.Wg = c)),
          (a.ud = b))
        : (a.ud = 0);
      return a;
    }
    redirect() {
      return null;
    }
    isVisible() {
      return !this.B || this.B === 3;
    }
    visible() {
      return this.B;
    }
    fd(a) {
      if (a === 0 ? this.B : this.B !== a) {
        var b = null;
        switch (a) {
          case 0:
            this.M.C && (b = 14);
            break;
          case 1:
            this.M.C && (b = 15);
            break;
          case 3:
            this.M.C && (b = 15);
        }
        this.B = a || null;
        b !== null &&
          ((a = new fP(this.I, this.H, b, this)), YO(a, this.tb()), a.Nc());
      }
    }
    J() {
      var a = super.J();
      this.resultIndex !== null && N(a, 6, this.resultIndex);
      return a;
    }
    G() {
      var a = super.G();
      if (this.A) {
        var b = Pr(A(a, Qr, 232));
        this.A.tb() && rf(b, 4, Nr, de(this.A.tb()));
        var c = this.A.C();
        rf(b, 5, Or, de(c));
      }
      this.B !== null && this.B !== 0 && a.fd(this.B);
      return a;
    }
    click(a) {
      var b = new FG(this.I, this.H, this);
      b.Nc(a);
      return b;
    }
  };
  function GG(a, b) {
    if (a.G) throw Error("Only one visual element root is allowed per Event!");
    a.G = jP(a, b, null).A;
    return a.G;
  }
  function jP(a, b, c) {
    if (a.C) throw Error("ImpressionEvent cannot accept new VisualElements!");
    if (a.A.length >= 7) {
      var d = new kP(a.D, a.H, kD);
      b = GG(d, b);
      a.B.push(new hP(a, c, d, b));
      return new eP(b, c, !0);
    }
    d = new iP(a.D, a.H, a, a.A.length, b, (e, f) => jP(a, e, f));
    a.A.push(d);
    return new eP(d, c, !1);
  }
  function lP(a) {
    tb(a.A, (b) => {
      mP(a, b);
    });
  }
  function mP(a, b) {
    var c = b.G();
    if (hf(c, 4, Nd, 3, !0).length) {
      c = hf(c, 4, Nd).map((g) => a.A[g]);
      var d = c[0].A,
        e = c.every((g) => nP(d, g.A)),
        f = b.A;
      e && !f && d && (f = b.A = d);
      for (let g of c) nP(f, g.A) && (g.A = null);
    }
  }
  var kP = class extends ZO {
    constructor(a, b, c = iD) {
      super(a, b);
      this.K = c;
      this.A = [];
      this.B = [];
      this.G = null;
    }
    Eb() {
      for (let a of this.A) if (a.bb() && a.bb() !== 12877) return !0;
      for (let a of this.B) if (a.event.Eb()) return !0;
      return !1;
    }
    F(a) {
      vB(A(a, wB, 29), this.K.bb);
      for (let c of this.B) {
        let d = c.A;
        var b = c.parent;
        if (!d.A) {
          let e = oP(b, (f) => !!f.A);
          e && (d.A = e.A);
        }
        d.visible() === null &&
          ((b = oP(b, (e) => e.visible() !== null)),
          b !== null && d.fd(b.visible()));
      }
      lP(this);
      for (let c of this.A) pP(c, a);
      this.Eb();
      return gP(this.B, this.D, this.H, this.tb());
    }
  };
  function pP(a, b) {
    var c = a.F,
      d = df(b, Sr, 27);
    if (c) {
      var e = Bf(b, 47, eD);
      d = N(e, 1, d);
      d = A(d, Tr, 2);
      y(d, c);
    }
    b = Bf(b, 27, Sr);
    a = a.G();
    y(b, a);
    a = B(b, Qr, 232);
    a = B(a, Mr, 1);
    If(a, 4, Nr) &&
      If(a, 5, Or) &&
      gD(If(a, 5, Or)) &&
      ((a = Pr(A(b, Qr, 232))), rf(a, 4, Nr));
  }
  function oP(a, b) {
    for (; a; a = a.parent()) if (b(a)) return a;
    return null;
  }
  function nP(a, b) {
    return a === b || !!(a && b && a.equals(b));
  }
  var qP = class {
    constructor(a) {
      this.A = a;
      this.version = void 0;
      this.B = 0;
    }
    xg(a) {
      a = new cP(this.A, this, a, this.version);
      XO(a, "kei");
      return a;
    }
    yg() {
      var a = new kP(this.A, this);
      XO(a, "kei");
      return a;
    }
    wg() {
      return `kei:${++this.B}`;
    }
  };
  var VO = class {
    constructor() {
      this.Jd = new qP(this);
    }
    Nc() {}
    te() {}
    Ef() {
      return !0;
    }
  };
  var rP = class extends dz {
    constructor(a) {
      super("OPH", [...arguments]);
    }
  };
  var sP = class extends dz {
    constructor(a, b, c) {
      super("ZMW", [...arguments]);
    }
  };
  function tP(a) {
    for (var b = uP; b; ) {
      if (b.D === a) return b;
      b = b.H;
    }
    return (uP = new vP(a));
  }
  function jM(a) {
    a.F || ((a.F = !0), qM(a.D, a.G));
  }
  var vP = class {
    constructor(a) {
      var b = uP;
      this.D = a;
      this.H = b;
      this.A = [];
      this.B = [];
      this.C = [];
      this.G = {
        Fb: 5,
        Db: 3,
        animation: (c) => {
          this.F = !1;
          var d = [],
            e = this.A;
          this.A = this.B;
          this.B = e;
          var f;
          for (f = 0; f < e.length; f++) {
            var g = e[f],
              h = (c - g.startTime) * g.D;
            h >= 1
              ? (iM(g.animation, 1),
                g.A++,
                g.A >= 1
                  ? (d.push(f), (g.B = !0))
                  : (iM(g.animation, 0), (g.startTime = c)))
              : h > 0 && iM(g.animation, h);
          }
          c = d.length;
          g = e.length;
          for (f = c - 1; f >= 0; f--) e[d[f]] = e[--g];
          e.length = g;
          c = this.C.length;
          for (f = 0; f < c; f++)
            for (d = this.C[f], h = g - 1; h >= 0; h--)
              if (e[h].animation === d.animation) {
                d.C && !d.B && iM(d.animation, 1);
                e[h] = e[--g];
                break;
              }
          e.length = g;
          for (f = this.C.length = 0; f < g; f++) this.A.push(e[f]);
          this.B.length = 0;
          g > 0 && jM(this);
        },
      };
      this.F = !1;
    }
    stop(a, b) {
      var c;
      for (c = 0; c < this.A.length; c++)
        if (this.A[c].animation === a) {
          b && iM(a, 1);
          this.A[c] = this.A[this.A.length - 1];
          this.A.pop();
          return;
        }
      for (c = 0; c < this.B.length; c++) {
        let d = this.B[c];
        if (d.animation === a) {
          this.C.push(d);
          b && (d.C = !0);
          break;
        }
      }
    }
  };
  class hM {
    constructor(a, b) {
      this.animation = a;
      this.A = this.startTime = 0;
      this.B = this.C = !1;
      this.D = 1 / b;
    }
  }
  var uP = null;
  function wP() {
    this.A = [];
    this.B = [];
  }
  function xP(a, b) {
    a.B.push(b);
  }
  function yP(a) {
    a.A.length === 0 && ((a.A = a.B), a.A.reverse(), (a.B = []));
    return a.A.pop();
  }
  p = wP.prototype;
  p.isEmpty = function () {
    return this.A.length === 0 && this.B.length === 0;
  };
  p.clear = function () {
    this.A = [];
    this.B = [];
  };
  p.contains = function (a) {
    return qb(this.A, a) >= 0 || qb(this.B, a) >= 0;
  };
  p.remove = function (a) {
    var b = this.A;
    b: {
      var c = b.length - 1;
      c < 0 && (c = Math.max(0, b.length + c));
      if (typeof b === "string")
        c = typeof a !== "string" || a.length != 1 ? -1 : b.lastIndexOf(a, c);
      else {
        for (; c >= 0; c--) if (c in b && b[c] === a) break b;
        c = -1;
      }
    }
    c >= 0 ? (Bb(b, c), (b = !0)) : (b = !1);
    return b || zb(this.B, a);
  };
  p.kc = function () {
    var a = [];
    for (var b = this.A.length - 1; b >= 0; --b) a.push(this.A[b]);
    b = this.B.length;
    for (let c = 0; c < b; ++c) a.push(this.B[c]);
    return a;
  };
  var zP = { pan: 0, rotate: 1, zoom: 2 };
  function AP(a, b, c, d, e, f) {
    var g = new EO();
    b = new JO(b, c, d, e, (h) => {
      BP(a, h);
    });
    a.ea = b;
    g.A[1] = b;
    DO(g, 2, new LO(c, d, f));
    DO(g, 5, new NO(c, d));
    return g;
  }
  function CP(a, b, c) {
    var d = new PO(b, a.la, a.T, a.G, fs(B(a.L, hs, 2)), gs(B(a.L, hs, 2)));
    Ty(
      [d, a.D],
      () => {
        var e = a.D.ka();
        d.ka().bind(e.nf(), e.content, c);
      },
      c
    );
  }
  function DP(a, b, c) {
    var d = new sP(b, a.la, a.G);
    Ty(
      [d, a.D],
      (e) => {
        var f = d.ka(),
          g = a.D.ka();
        f.bind(g.camera, g.Ua, g.content, e);
      },
      c
    );
  }
  function EP(a, b) {
    a.D.onLoad((c, d) => {
      new rP(c.od).get((e, f) => {
        e.bind(a.camera, a.I, c.Kc, f);
      }, d);
    }, b);
  }
  function FP(a, b) {
    var c = a.ga,
      d = c.clientWidth;
    c = c.clientHeight;
    a.na.canvas && jJ(a.na.canvas, Ps(), d, c);
    a.width.set(d, b);
    a.height.set(c, b);
  }
  function GP(a, b) {
    a.D.onLoad((c, d) => {
      a.A = c;
      ZE(a.A.width, a.width, d);
      ZE(a.A.height, a.height, d);
      ZE(a.camera, a.A.camera, d);
      ZE(a.Ea, a.A.Ea, d);
      ZE(a.I, a.A.content, d);
      for (c = 0; c < a.H.length; ++c) a.A.Kc.get().We(a.H[c].X, a.H[c].U);
      a.H.length = 0;
      FP(a, d);
    }, b);
  }
  function HP(a, b) {
    TB = a;
    UB = b;
  }
  function BP(a, b) {
    a.F.Qc !== null && b.vd(a.F.Qc);
    a.F.zoom !== null && b.enableZoom(a.F.zoom);
    var c = ls(a.L);
    b.Ca = C(c, 2);
    a.F = { Qc: null, zoom: null };
    ex(b, "user-input-event", (d, e) => {
      a.dispatchEvent(new ru("UserInput", { inputType: zP[e.type] }));
    });
  }
  function IP(a, b, c, d) {
    if (a.aa) xP(a.Z, { view: b, X: c });
    else {
      z(b, 1) && (a.aa = !0);
      var e = () => {
        d && d(c);
        z(b, 1) && (a.aa = !1);
        if (!a.Z.isEmpty()) {
          let h = yP(a.Z);
          IP(a, h.view, h.X);
        }
      };
      if (!z(b, 1) && z(b, 2)) {
        var f = a.A.camera.get();
        if (f) {
          var g = new U();
          y(g, f);
          iz(b.oa(), g);
          a.A.Kc.get().moveTo(g, a.I.get() || null, JP(Ff(b, 3, 2)), c, e);
        }
      } else
        KP(B(b, HB, 1)) &&
          ((f = new OO()),
          y(f, b),
          (g = f.ja()),
          (oj(g) && fj(mj(g))) ||
            (nj(g).B(a.width.get() || 1), nj(g).A(a.height.get() || 1)),
          LP(a, f, c, e));
    }
  }
  function LP(a, b, c, d) {
    var e = new U(),
      f = b.oa();
    y(e, f);
    FP(a, c);
    a.A.Kc.get().moveTo(e, B(b, HB, 1), JP(Ff(b, 3, 2)), c, d);
  }
  var OP = class extends Su {
    constructor(a, b, c) {
      super();
      this.L = a;
      this.na = c;
      this.C = Mw();
      this.width = cF();
      this.height = cF();
      this.O = new UO();
      this.ea = null;
      this.F = { Qc: null, zoom: null };
      this.A = null;
      this.camera = dF();
      this.Ea = dF();
      this.aa = !1;
      this.I = dF();
      this.P = null;
      this.H = [];
      this.Z = new wP();
      var d = new Jw(this.C, "application");
      AO(CO || (CO = new BO()), Ff(a, 4));
      this.ga = c.container;
      Ps() > 1 &&
        document.body.classList.add("mapsConsumerLibAppResolution__high");
      this.G = c.A;
      this.la = c.la;
      this.Sa = c.B;
      var e = tP(this.G);
      this.T = new WO();
      TO(this.O, this.T, d);
      var f = MP(c, a),
        g = NP(c);
      this.W = new IO(f, b, g, this.Sa, this.G, this.O, e, C(a, 9), c.Be);
      a = AP(this, a, b, this.W, this.T, this.O);
      this.D = new TN(
        this.ga,
        f,
        this.la,
        this.G,
        e,
        this.C,
        g,
        this.O,
        a,
        this.W
      );
      this.camera.listen(this.ua, this);
      this.Ea.listen(this.Na, this);
      this.I.listen(this.Ca, this);
      c.kf && CP(this, c.kf, d);
      c.zoom && DP(this, c.zoom, d);
      ds(ls(this.L)) && EP(this, d);
      Fu(
        u,
        "resize",
        () => {
          var h = new Jw(this.C, "resize");
          FP(this, h);
          h.done("main-actionflow-branch");
        },
        !1,
        this
      );
      GP(this, d);
      FP(this, d);
      d.done("main-actionflow-branch");
    }
    focus() {
      this.A && this.A.focus();
    }
    Xa() {
      var a = this.A && this.A.camera.get();
      a || (a = new U());
      return a;
    }
    view(a, b) {
      if (z(a, 1) || z(a, 2)) {
        var c = new Jw(this.C, "move_camera");
        this.D.get((d, e) => {
          this.A = d;
          IP(this, a, e, b);
        }, c);
        c.done("main-actionflow-branch");
      }
    }
    jf(a) {
      var b = new Jw(this.C, "scrollwheel_enable");
      this.D.get(() => {
        this.A.jf(a);
      }, b);
      b.done("main-actionflow-branch");
    }
    vd(a) {
      var b = this.ea.A;
      b ? b.vd(a) : (this.F.Qc = a);
    }
    enableZoom(a) {
      var b = this.ea.A;
      b ? b.enableZoom(a) : (this.F.zoom = a);
    }
    setSize(a, b) {
      Ys(this.ga, a, b);
      a = new Jw(this.C, "resize");
      FP(this, a);
      a.done("main-actionflow-branch");
    }
    ua() {
      var a = this.camera.get();
      a || (a = new U());
      this.dispatchEvent(new ru("CameraChanged", a));
    }
    me(a) {
      var b = new Jw(this.C, "show_road_labels");
      HO(
        this.W,
        (c) => {
          c.me(a, b);
        },
        b
      );
      b.done("main-actionflow-branch");
    }
    Na() {
      var a = this.Ea.get();
      a || (a = new U());
      this.dispatchEvent(new ru("StableCameraChanged", a));
    }
    Ca() {
      var a = this.I.get();
      a &&
        ((a = Z(a)),
        (this.P && a && fA(this.P) === fA(a) && lA(this.P, a)) ||
          ((this.P = a.clone()),
          this.dispatchEvent(new ru("PhotoChanged", a))));
    }
    We(a, b = new Jw(this.C, "wait_for_render")) {
      this.A
        ? this.A.Kc.get().We(b, a)
        : this.H.push({ X: b, U: b.U(a, "viewer-wait-for-stable") });
    }
  };
  function KP(a) {
    return jF(a) || iF(a) || a?.A() === 3 || a?.A() === 5;
  }
  function JP(a) {
    switch (a) {
      case 1:
        return new rF(1);
      case 3:
        return new rF(3);
    }
    return new rF(2);
  }
  function PP(a, b, c) {
    a = new OP(a, b, c);
    b = new Jw(a.C, "application");
    FP(a, b);
    b.done("main-actionflow-branch");
    return a;
  }
  var QP = class {};
  function RP(a, b, c = !1, d) {
    $y || (($y = new QP()), (Zy = !1));
    Yy("CPNR", fz);
    Yy("CUTS", uC);
    Yy("CUCS", gC);
    Yy("CTS", wA);
    Yy("FPSC", HC);
    Yy("FPTS", nD);
    if (c) {
      let e = a.C;
      TD((f) => new ys(f, e), d);
    } else TD();
    Yy("HPNR", pE);
    Yy("SCPI", YG);
    Yy("PNI", $G);
    Yy("SCPR", DL);
    Yy("SCW", YN);
    Yy("SVT", aO);
    Yy("WPNR", zO);
    return PP(Re(a.A), Re(a.B), b);
  }
  var SP = class {
    constructor(a, b, c) {
      this.heading = a;
      a = Math.max(b, -90);
      this.pitch = a = Math.min(a, 90);
      this.zoom = Math.max(0, c);
    }
  };
  function TP(a) {
    a.handled = !0;
  }
  var UP = new Set(["touchstart", "touchmove", "wheel", "mousewheel"]);
  function VP(a, b) {
    var c = [];
    if (a) {
      var d = (d = a.__e3_) && d[b];
      d = !!d && !Jm(d);
    } else d = !1;
    if (d) {
      a = a.__e3_ || {};
      if (b) b = a[b] || {};
      else {
        b = {};
        for (e of Object.values(a)) $r(b, e);
      }
      var e = b;
      for (let f of Object.keys(e))
        (b = e[f]) && b.handler.apply(b.instance, c);
    }
  }
  function WP(a, b) {
    a.__e3_ || (a.__e3_ = {});
    a = a.__e3_;
    a[b] || (a[b] = {});
    return a[b];
  }
  class XP {
    constructor(a, b) {
      this.instance = a;
      this.A = b;
      this.handler = TP;
      this.id = ++YP;
      WP(a, b)[this.id] = this;
      VP(this.instance, `${this.A}_added`);
    }
    remove() {
      if (this.instance) {
        if (this.instance.removeEventListener) {
          let a = { capture: !1 };
          UP.has(this.A) && (a.passive = !1);
          this.instance.removeEventListener(this.A, this.handler, a);
        }
        delete WP(this.instance, this.A)[this.id];
        VP(this.instance, `${this.A}_removed`);
        this.handler = this.instance = null;
      }
    }
  }
  var YP = 0;
  function ZP(a) {
    var b = new Qi();
    if (a.substring(0, 2) == "F:") {
      var c = a.substring(2);
      Oi(b, 3);
      Pi(b, c);
    } else if (a.match("^[-_A-Za-z0-9]{21}[AQgw]$")) Oi(b, 2), Pi(b, a);
    else
      try {
        (c = fc(a)), (b = gk(c));
      } catch (d) {}
    b.va() == "" && (Oi(b, 2), Pi(b, a));
    return b;
  }
  function $P(a, b) {
    if (b == 2) return a;
    if (b == 3) return "F:" + a;
    var c = new Qi();
    Oi(c, b);
    Pi(c, a);
    try {
      return dc(hk(c), 3);
    } catch (d) {
      return u.btoa(
        String.fromCharCode(8) +
          String.fromCharCode(b) +
          String.fromCharCode(18) +
          String.fromCharCode(a.length) +
          a
      );
    }
  }
  var aQ = class {
    A() {
      return null;
    }
    D() {
      return null;
    }
    B() {}
    J() {}
    C() {}
  };
  var bQ = class extends aQ {
    constructor(a, b) {
      super();
      this.G = a;
      this.U = b;
      this.F = {
        hashchange: "hashchange",
        resize: "resize",
        load: "load",
        unload: "unload",
        beforeunload: "beforeunload",
      };
      (a = Ky()) && (this.F[a] = "visibilitychange");
    }
    D() {
      var a = { popstate: ["popstate"], error: ["error"] };
      Gm(this.F, (b, c) => {
        a[b] || (a[b] = []);
        a[b].push(c);
      });
      return a;
    }
    J(a) {
      Oy(a);
      var b = new Jw(this.G, "error");
      a.message !== "$$suppress$$" && this.U("error", b, a);
      b.done("main-actionflow-branch");
    }
    C(a) {
      var b = a.type,
        c = new Jw(this.G, b);
      b === "popstate"
        ? this.U("popstate", c, a)
        : this.F[b] &&
          ((b = this.F[b]),
          b === "visibilitychange"
            ? this.U(b, c, {
                type: a.type,
                target: a.target,
                hidden: Ly(),
                stopPropagation() {
                  a.stopPropagation();
                },
                preventDefault() {
                  a.preventDefault();
                },
              })
            : this.U(b, c, a));
      c.done("main-actionflow-branch");
    }
  };
  var cQ = class extends aQ {
    constructor(a) {
      super();
      this.U = a;
    }
    A() {
      return {
        copy: { Aa: ["copy"], global: null },
        cut: { Aa: ["cut"], global: null },
      };
    }
    B(a, b) {
      b.event();
      var c = b.event().type;
      c === "copy"
        ? this.dispatchEvent(a, "copy", b)
        : c === "cut" && this.dispatchEvent(a, "cut", b);
    }
    dispatchEvent(a, b, c) {
      this.U(a, b, c, c.event());
    }
  };
  function dQ(a, b, c, d) {
    b = sa(b);
    d = d ? 1 : -1;
    var e = c.length;
    for (let g = 0; g < e; ++g) {
      var f = c[g];
      f = a.A[f] = a.A[f] || new Map();
      let h = (f.get(b) || 0) + d;
      f.set(b, h);
    }
  }
  function eQ(a, b, c) {
    b = sa(b);
    return !!a.A[c] && (a.A[c].get(b) || 0) > 0;
  }
  function fQ(a) {
    var b = [];
    for (let c of Object.keys(a.A)) {
      let d = a.A[c];
      if (d)
        for (let e of d.values())
          if (e > 0) {
            b.push(c);
            break;
          }
    }
    return new Set(b);
  }
  var gQ = class {
    constructor() {
      this.A = {};
    }
  };
  var hQ = class extends aQ {
    constructor(a) {
      super();
      this.U = a;
    }
    A() {
      return { customwiz: { Aa: ["customwiz"], global: null } };
    }
    B(a, b) {
      b.event();
      this.U(a, "customwiz", b, b.event());
    }
  };
  function iQ(a) {
    var b = new nr();
    b.Xb = jQ;
    or(a, b);
    return b;
  }
  var kQ = class {
    constructor(a, b, c, d = iQ(b), e = Iw(c)) {
      this.C = a;
      this.B = d;
      this.Eg = e;
      this.A = {};
      for (let f of a)
        if ((a = f.A()))
          for (let g of Object.keys(a)) {
            c = a[g].Aa;
            for (let h of c) jr(b, h);
          }
    }
    Wf(a, b, c) {
      if (a !== "") {
        var d = this.A[a];
        d || (d = this.A[a] = new gQ());
        for (let f of this.C) {
          var e = f.A();
          e && (e = e[b]) && e.Aa && dQ(d, f, e.Aa, c);
        }
        if (fQ(d).size) {
          if (!this.B.actions.hasOwnProperty(a)) {
            b = this.B;
            a = { [a]: Sq(this.D, this.Eg) };
            for (let [f, g] of Object.entries(a))
              (a = f),
                (c = g),
                (c = this ? c.bind(this) : c),
                (b.actions[a] = c);
            lr(b);
          }
        } else this.B.re("", a);
      }
    }
    D(a) {
      if (a)
        try {
          let b = a.flowType(),
            c = a.event(),
            d = c.type;
          c[Ip] && (d = "customwiz");
          let e = this.A[b];
          for (let f of this.C) eQ(e, f, d) && f.B(b, a);
        } catch (b) {
          throw Ny(b);
        }
    }
  };
  function jQ(a, b) {
    if (a.length !== 0) {
      var c = a[a.length - 1];
      if (b.actions.hasOwnProperty(Jq(c)?.name ?? "")) {
        b = c.A.targetElement;
        var d = c.A.event;
        c = c.A.eventType;
        let f;
        f = d.type === "_custom" ? "_custom" : c || d.type;
        if (f === "keypress" || f === "keydown" || f === "keyup") c = pr(d, c);
        else if (
          f === "click" ||
          f === "dblclick" ||
          f === "mousedown" ||
          f === "mouseover" ||
          f === "mouseout" ||
          f === "mousemove"
        ) {
          if (document.createEvent) {
            var e = document.createEvent("MouseEvent");
            e.initMouseEvent(
              c || d.type,
              !0,
              !0,
              window,
              d.detail || 1,
              d.screenX || 0,
              d.screenY || 0,
              d.clientX || 0,
              d.clientY || 0,
              d.ctrlKey || !1,
              d.altKey || !1,
              d.shiftKey || !1,
              d.metaKey || !1,
              d.button || 0,
              d.relatedTarget || null
            );
          } else
            (e = document.createEventObject()),
              (e.type = c || d.type),
              (e.clientX = d.clientX),
              (e.clientY = d.clientY),
              (e.button = d.button),
              (e.detail = d.detail),
              (e.ctrlKey = d.ctrlKey),
              (e.altKey = d.altKey),
              (e.shiftKey = d.shiftKey),
              (e.metaKey = d.metaKey);
          e.Me = d.timeStamp;
          c = e;
        } else if (
          f === "focus" ||
          f === "blur" ||
          f === "focusin" ||
          f === "focusout" ||
          f === "scroll"
        )
          document.createEvent
            ? ((e = document.createEvent("UIEvent")),
              e.initUIEvent(
                c || d.type,
                d.bubbles !== void 0 ? d.bubbles : !0,
                d.cancelable || !1,
                d.view || window,
                d.detail || 0
              ))
            : ((e = document.createEventObject()),
              (e.type = c || d.type),
              (e.bubbles = d.bubbles !== void 0 ? d.bubbles : !0),
              (e.cancelable = d.cancelable || !1),
              (e.view = d.view || window),
              (e.detail = d.detail || 0)),
            (e.relatedTarget = d.relatedTarget || null),
            (e.Me = d.timeStamp),
            (c = e);
        else if (f === "_custom") {
          c = {
            _type: c,
            type: c,
            data: d.detail.data,
            Hj: d.detail.triggeringEvent,
          };
          try {
            (e = document.createEvent("CustomEvent")),
              e.initCustomEvent("_custom", !0, !1, c);
          } catch (g) {
            (e = document.createEvent("HTMLEvents")),
              e.initEvent("_custom", !0, !1),
              (e.detail = c);
          }
          c = e;
          c.Me = d.timeStamp;
        } else
          document.createEvent
            ? ((e = document.createEvent("Event")),
              e.initEvent(c || d.type, !0, !0))
            : ((e = document.createEventObject()), (e.type = c || d.type)),
            (e.Me = d.timeStamp),
            (c = e);
        d = c;
        b.dispatchEvent ? b.dispatchEvent(d) : b.fireEvent("on" + d.type, d);
        a.length = 0;
      }
    }
  }
  var lQ = class extends aQ {
    constructor(a) {
      super();
      this.U = a;
    }
    A() {
      return { ["dnd-dragstart"]: { Aa: ["dragstart"], global: null } };
    }
    B(a, b) {
      b.event();
      var c = b.event().type;
      if (c === "dragstart") {
        let d = b.event();
        this.U(a, "dnd-dragstart", b, {
          type: c,
          target: d.target,
          setData(e, f) {
            d.dataTransfer.setData(e, f);
          },
          preventDefault() {
            d.preventDefault();
          },
          stopPropagation() {
            d.stopPropagation();
          },
        });
      }
    }
  };
  var mQ = class extends aQ {
    constructor(a) {
      super();
      this.U = a;
    }
    A() {
      return {
        focus: { Aa: ["focus"], global: null },
        focusin: { Aa: ["focusin"], global: null },
        focusout: { Aa: ["focusout"], global: null },
        blur: { Aa: ["blur"], global: null },
      };
    }
    B(a, b) {
      b.event();
      var c = b.event().type;
      c === "focus"
        ? this.dispatchEvent(a, "focus", b)
        : c === "focusin"
        ? this.dispatchEvent(a, "focusin", b)
        : c === "focusout"
        ? this.dispatchEvent(a, "focusout", b)
        : c === "blur" && this.dispatchEvent(a, "blur", b);
    }
    dispatchEvent(a, b, c) {
      var d = c.event();
      this.U(a, b, c, {
        target: d.target,
        type: d.type,
        relatedTarget: d.relatedTarget,
        preventDefault() {
          d.preventDefault();
        },
        stopPropagation() {
          d.stopPropagation();
        },
      });
    }
  };
  var nQ = class extends aQ {
    constructor(a) {
      super();
      this.U = a;
    }
    A() {
      return {
        change: { Aa: ["change"], global: null },
        input: { Aa: ["input"], global: null },
        submit: { Aa: ["submit"], global: null },
      };
    }
    B(a, b) {
      b.event();
      var c = b.event().type;
      c === "change"
        ? this.dispatchEvent(a, "change", b)
        : c === "input"
        ? this.dispatchEvent(a, "input", b)
        : c === "submit" && this.dispatchEvent(a, "submit", b);
    }
    dispatchEvent(a, b, c) {
      this.U(a, b, c, c.event());
    }
  };
  function oQ(a) {
    var b =
      typeof globals !== "undefined" &&
      typeof globals.ErrorHandler !== "undefined" &&
      globals.ErrorHandler.listen;
    return b
      ? (b((c) => {
          pQ(a, c);
        }),
        !0)
      : !1;
  }
  function qQ(a, b, c) {
    for (let d of a.H) (eQ(a.D, d, b) || eQ(a.C, d, b)) && c(d);
  }
  function pQ(a, b) {
    qQ(a, "error", (c) => {
      c.J(b);
    });
  }
  var sQ = class extends NI {
    constructor(a, b = u) {
      super();
      this.H = a;
      this.wf = b;
      this.D = new gQ();
      this.C = new gQ();
      this.I = oQ(this);
    }
    Wf(a, b, c) {
      var d = a === "",
        e = d ? this.C : this.D,
        f = d ? this.D : this.C;
      a = fQ(f);
      for (let k of this.H) {
        a: {
          var g = k;
          var h = b;
          if (d) {
            h = (g = g.D()) ? g[h] : void 0;
            break a;
          }
          h = (g = g.A()) && g[h] ? g[h].global : void 0;
        }
        h && dQ(f, k, h, c);
      }
      b = fQ(f);
      e = fQ(e);
      c = rQ(rQ(a, b), e);
      a = rQ(rQ(b, a), e);
      for (let k of c)
        (k === "error" && this.I) || this.N(this.wf, k, this.G, !0, this);
      for (let k of a)
        (k === "error" && this.I) || PI(this, this.wf, k, this.G, !0, this);
    }
    G(a) {
      try {
        qQ(this, a.type, (b) => {
          b.C(a);
        });
      } catch (b) {
        throw Ny(b);
      }
    }
  };
  function rQ(a, b) {
    a = new Set(a);
    for (let c of b) a.delete(c);
    return a;
  }
  var tQ = {},
    uQ = {};
  function vQ(a) {
    return a === "keypress" || a === "keydown" || a === "keyup";
  }
  var yQ = class extends aQ {
    constructor(a, b, c) {
      super();
      this.F = a;
      this.H = b;
      this.G = c;
    }
    D() {
      return { keypress: ["keypress"], keydown: ["keydown"], keyup: ["keyup"] };
    }
    A() {
      return {
        keypress: { Aa: ["keypress"], global: null },
        keydown: { Aa: ["keydown"], global: null },
        keyup: { Aa: ["keyup"], global: null },
      };
    }
    C(a) {
      if (a && vQ(a.type)) {
        let b = wQ(a),
          c = new Jw(this.F, b);
        a = xQ(a);
        this.G(b, c, a, a.keyCode);
        c.done("main-actionflow-branch");
      }
    }
    B(a, b) {
      b.event();
      var c = b.event();
      if (c && vQ(c.type)) {
        let d = xQ(c);
        this.H(a, wQ(c), b, d, d.keyCode);
      }
    }
  };
  function wQ(a) {
    switch (a.type) {
      case "keypress":
        return "keypress";
      case "keydown":
        return "keydown";
      case "keyup":
        return "keyup";
    }
  }
  function xQ(a) {
    return {
      target: a.target,
      type: a.type,
      keyCode: SF(a.keyCode),
      shiftKey: a.shiftKey,
      ctrlKey: a.ctrlKey,
      altKey: a.altKey,
      metaKey: a.metaKey,
      xj: a,
      preventDefault() {
        a.preventDefault();
      },
      stopPropagation() {
        a.stopPropagation();
      },
    };
  }
  var zQ = class {
    constructor() {
      this.A = u.performance?.now || null;
    }
    getTime() {
      return this.A.call(u.performance);
    }
  };
  function AQ(a, b) {
    b
      ? ((BQ.x = a.clientX - b.left), (BQ.y = a.clientY - b.top))
      : ((b = a.target),
        (b = (
          b.nodeType !== Node.ELEMENT_NODE && b.parentNode ? b.parentNode : b
        ).getBoundingClientRect()),
        (BQ.x = a.clientX - b.left),
        (BQ.y = a.clientY - b.top));
    return BQ;
  }
  function CQ(a) {
    a.getAttribute("tabindex") || (a.tabIndex = -1);
    a.focus();
  }
  var BQ = new As();
  function DQ(a, b, c, d, e) {
    a.B ||
      ((a.I = b),
      (a.J = e),
      (a.F = e.getBoundingClientRect()),
      (b = AQ(d, a.F)),
      (a.G = a.C = b.x),
      (a.H = a.D = b.y),
      (a.B = !0),
      (a.X = new Jw(a.M, a.I)),
      a.dispatchEvent(c, "dragpointerdown", a.G, a.H, d));
  }
  var FQ = class {
    constructor(a, b) {
      this.M = a;
      this.U = b;
      this.A = !1;
      this.X = null;
      this.B = !1;
      this.I = "";
      this.D = this.C = 0;
      this.F = this.J = null;
      this.H = this.G = 0;
    }
    move(a, b) {
      if (this.B) {
        var c = EQ(a) ? 15 : 2,
          d = AQ(b, this.F);
        this.dispatchEvent(a, "dragpointermove", d.x, d.y, b);
        !this.A &&
          (Math.abs(this.G - d.x) > c || Math.abs(this.H - d.y) > c) &&
          ((this.A = !0),
          this.dispatchEvent(a, "dragstart", this.G, this.H, b));
        this.A &&
          (this.dispatchEvent(a, "drag", d.x, d.y, b),
          (this.C = d.x),
          (this.D = d.y));
      }
    }
    release(a, b) {
      if (!this.B) return !1;
      var c = this.C,
        d = this.D;
      b && ((d = AQ(b, this.F)), (c = d.x), (d = d.y));
      this.A && this.dispatchEvent(a, "dragend", c, d, b);
      this.X && this.X.done("main-actionflow-branch");
      this.X = null;
      a = this.A;
      this.A = this.B = !1;
      return a;
    }
    dispatchEvent(a, b, c, d, e) {
      var f = this.X;
      try {
        (a.x = c), (a.y = d);
      } catch (g) {}
      a.dx = c - this.C;
      a.dy = d - this.D;
      EQ(a) || (a.target = this.J);
      e || (e = a);
      a.Ij = Math.round(e.clientX);
      a.Jj = Math.round(e.clientY);
      this.U(this.I, b, f, a);
    }
  };
  function EQ(a) {
    return (
      a.type === "touchstart" ||
      a.type === "touchmove" ||
      a.type === "touchend" ||
      a.type === "touchcancel"
    );
  }
  var GQ = class extends aQ {
    constructor(a, b) {
      super();
      this.U = b;
      this.G = !1;
      this.F = [];
      this.F.push(
        new FQ(a, (c, d, e, f) => {
          this.U(c, d, e, f, 0);
        })
      );
    }
    A() {
      var a = { Aa: ["mousedown"], global: ["mousemove", "mouseup"] };
      return {
        dragstart: a,
        drag: a,
        dragend: a,
        dragpointerdown: a,
        dragpointermove: a,
      };
    }
    C(a) {
      this.handleEvent(a);
    }
    B(a, b) {
      b.event();
      var c = new su(b.event());
      this.handleEvent(c, a, b);
    }
    handleEvent(a, b, c) {
      if (a.type === "mousedown") {
        var d = a.hb;
        CQ(d.target);
        d.preventDefault?.();
        (d = this.F[d.button]) && DQ(d, b, a, a, c.node());
      } else if (a.type === "mousemove")
        for (b = this.F.length, c = 0; c < b; ++c) this.F[c].move(a, a);
      else
        a.type === "mouseup" &&
          ((d = this.F[a.button]), (this.G = !!d && d.release(a, a)));
    }
  };
  function HQ() {
    return u.PointerEvent !== void 0;
  }
  function IQ() {
    var a = null;
    HQ() && (a = new JQ());
    return a;
  }
  function KQ(a, b) {
    var c = a.A.findIndex((e) => e.identifier === b.pointerId),
      d = new LQ(b);
    c === -1 ? a.A.push(d) : (a.A[c] = d);
    return d;
  }
  function MQ(a, b, c, d) {
    return {
      type: b,
      touches: [...a.A],
      changedTouches: [c],
      target: d.target,
      currentTarget: d.currentTarget,
      preventDefault: () => {
        d.preventDefault();
      },
      stopPropagation: () => {
        d.stopPropagation();
      },
    };
  }
  function NQ(a, b) {
    if (b.pointerType === "touch") {
      var c = b.target;
      if (c.releasePointerCapture !== void 0)
        try {
          c.releasePointerCapture(b.pointerId);
        } catch (d) {}
      c = a.A.findIndex((d) => d.identifier === b.pointerId);
      if (c !== -1) return Bb(a.A, c), MQ(a, "touchend", new LQ(b), b);
    }
    return null;
  }
  function OQ(a, b) {
    switch (b.type) {
      case "pointerdown":
        if (b.pointerType === "touch") {
          var c = b.target;
          c.setPointerCapture !== void 0 && c.setPointerCapture(b.pointerId);
          c = KQ(a, b);
          a = MQ(a, "touchstart", c, b);
        } else a = null;
        return a;
      case "pointermove":
        return (
          b.pointerType === "touch"
            ? ((c = KQ(a, b)), (a = MQ(a, "touchmove", c, b)))
            : (a = null),
          a
        );
      case "pointerup":
      case "pointercancel":
        return NQ(a, b);
    }
    return null;
  }
  var JQ = class {
    constructor() {
      this.A = [];
    }
  };
  class LQ {
    constructor(a) {
      this.rotationAngle = this.radiusY = this.radiusX = 0;
      this.identifier = a.pointerId;
      this.screenX = a.screenX;
      this.screenY = a.screenY;
      this.clientX = a.clientX;
      this.clientY = a.clientY;
      this.pageX = a.pageX;
      this.pageY = a.pageY;
      this.force = a.pressure;
      this.target = a.target;
    }
  }
  var PQ = u.TouchEvent !== void 0 && HQ();
  function QQ(a, b) {
    if (b.type === "mousedown") return !0;
    var c;
    if ((c = PQ)) {
      c = b.timeStamp;
      var d = a.G;
      c = d != null && Math.abs(c - d) < 100;
    }
    if (c || b.type !== "touchstart")
      return b.type === "pointerdown" && b.pointerType === "touch"
        ? ((a.G = b.timeStamp), b.isPrimary)
        : !1;
    a.G = null;
    return b.touches.length === 1;
  }
  function RQ(a, b) {
    if (b.type === "mouseup") return !0;
    var c;
    if ((c = PQ)) {
      c = b.timeStamp;
      var d = a.H;
      c = d != null && Math.abs(c - d) < 100;
    }
    if (c || b.type !== "touchend")
      return b.type === "pointerup" && b.pointerType === "touch"
        ? ((a.H = b.timeStamp), b.isPrimary)
        : !1;
    a.H = null;
    return b.touches.length === 0;
  }
  var SQ = class extends aQ {
    constructor(a, b) {
      super();
      this.U = a;
      this.I = b;
      this.F = !1;
      this.H = this.G = null;
    }
    A() {
      return {
        auxclick: { Aa: ["auxclick"], global: null },
        click: { Aa: ["click"], global: null },
        dblclick: { Aa: ["dblclick"], global: null },
        ptrdown: {
          Aa: ["mousedown", "touchstart", "pointerdown"],
          global: null,
        },
        ptrhover: { Aa: ["mousemove"], global: ["mousedown", "mouseup"] },
        ptrup: {
          Aa: ["mouseup", "touchend", "pointerup", "pointercancel"],
          global: null,
        },
        contextmenu: { Aa: ["contextmenu"], global: null },
      };
    }
    C(a) {
      a = a.type;
      a === "mousedown" ? (this.F = !0) : a === "mouseup" && (this.F = !1);
    }
    B(a, b) {
      b.event();
      var c = b.event(),
        d = c.type;
      d === "click"
        ? this.I.G
          ? ((this.I.G = !1), b.event().stopPropagation())
          : this.dispatchEvent(a, "click", b)
        : d === "auxclick"
        ? this.dispatchEvent(a, "auxclick", b)
        : d === "dblclick"
        ? this.dispatchEvent(a, "dblclick", b)
        : QQ(this, c)
        ? this.dispatchEvent(a, "ptrdown", b)
        : d !== "mousemove" || this.F
        ? RQ(this, c)
          ? this.dispatchEvent(a, "ptrup", b)
          : d === "contextmenu" && this.dispatchEvent(a, "contextmenu", b)
        : this.dispatchEvent(a, "ptrhover", b);
    }
    Qg() {
      return this.F;
    }
    dispatchEvent(a, b, c) {
      var d = c.node();
      if (d) {
        var e = c.event();
        var f = new su(e);
        if (e.type === "touchstart" || e.type === "touchend") {
          let g = e.touches;
          g.length === 0 && (g = e.changedTouches);
          [e] = g;
          f.clientX = e.clientX;
          f.clientY = e.clientY;
          f.screenX = e.screenX;
          f.screenY = e.screenY;
        }
        d = AQ(f, d.getBoundingClientRect());
        f.x = d.x;
        f.y = d.y;
        f.button = f.button;
        f.ctrlKey = f.ctrlKey;
        this.U(a, b, c, f);
      }
    }
  };
  function TQ(a, b, c, d, e) {
    return {
      x: UQ(c) ? c.x : 0,
      y: UQ(c) ? c.y : 0,
      button: 0,
      ctrlKey: UQ(c) ? c.ctrlKey : !1,
      shiftKey: UQ(c) ? c.shiftKey : !1,
      Mc: UQ(c) ? (Pb ? c.metaKey : c.ctrlKey) : !1,
      type: c.type,
      target: c.target,
      vj: d,
      uj: e,
      Qg: a.H.Qg(),
      oj: () => VQ(b, e),
      pj: () => VQ(b, d),
      preventDefault: () => {
        c.preventDefault();
      },
      stopPropagation: () => {
        c.stopPropagation();
      },
    };
  }
  var WQ = class extends aQ {
    constructor(a, b, c, d) {
      super();
      this.U = a;
      this.H = b;
      this.F = c;
      this.G = d;
    }
    D() {
      return { ptrin: ["mouseover"], ptrout: ["mouseout"] };
    }
    A() {
      return {
        ptrin: { Aa: ["mouseover"], global: null },
        ptrout: { Aa: ["mouseout"], global: null },
      };
    }
    C(a) {
      var b = a.hb;
      if (b) {
        if (b.type === "mouseover") {
          a = "ptrin";
          var c = b.relatedTarget || null;
          var d = b.target;
        } else if (b.type === "mouseout")
          (a = "ptrout"), (c = b.target), (d = b.relatedTarget || null);
        else return;
        var e = new Jw(
          this.F,
          a,
          b.target instanceof Element ? b.target : void 0,
          b
        );
        b = TQ(this, e, b, c, d);
        this.G(a, e, b);
        e.done("main-actionflow-branch");
      }
    }
    B(a, b) {
      var c = b.event();
      c.type === "mouseover"
        ? this.dispatchEvent(a, "ptrin", b, c.relatedTarget || null, c.target)
        : c.type === "mouseout" &&
          this.dispatchEvent(a, "ptrout", b, c.target, c.relatedTarget || null);
    }
    dispatchEvent(a, b, c, d, e) {
      var f = c.event();
      this.U(a, b, c, TQ(this, c, f, d, e));
    }
  };
  function UQ(a) {
    return a.type === "mouseover" || a.type === "mouseout";
  }
  function VQ(a, b) {
    a = a.node();
    return !(!a || (b && Os(a, b)));
  }
  var XQ = class extends aQ {
    constructor(a, b, c) {
      super();
      this.F = a;
      this.U = b;
      this.G = c;
    }
    D() {
      return { scroll: ["scroll"] };
    }
    A() {
      return { scroll: { Aa: ["scroll"], global: null } };
    }
    C(a) {
      if (a.type === "scroll") {
        let b = new Jw(this.F, "scroll");
        this.G("scroll", b, a);
        b.done("main-actionflow-branch");
      }
    }
    B(a, b) {
      b.event();
      b.event().type === "scroll" && this.dispatchEvent(a, b);
    }
    dispatchEvent(a, b) {
      this.U(a, "scroll", b, b.event());
    }
  };
  var ZQ = class {
    constructor() {
      this.A = [];
      this.B = !1;
    }
    filter(a) {
      if (!($b || ac || Zb)) return !1;
      a = new YQ(Date.now(), a.B);
      if (this.A.length > 0) {
        var b = this.A[this.A.length - 1],
          c = a.A < 0 !== b.A < 0;
        if (a.timestamp - b.timestamp > 100 || c) this.A.length = 0;
      }
      this.A.push(a);
      this.A.length > 10 && this.A.shift();
      if (this.A.length < 3) this.B = !1;
      else {
        {
          a = this.A;
          let f = a.length;
          if (f < 2) a = NaN;
          else {
            b = [0, 0, 0, 0, 0];
            c = a[0].timestamp - 100;
            var d;
            for (let g = 0; g < f; g++) {
              var e = a[g].timestamp - c;
              if ((d = Math.abs(a[g].A)))
                (b[0] += e),
                  (b[1] += d),
                  (b[2] += e * e),
                  (b[3] += e * d),
                  (b[4] += d * d);
            }
            a =
              b[1] / f -
              (((f * b[3] - b[0] * b[1]) / (f * b[2] - b[0] * b[0])) * b[0]) /
                f;
          }
        }
        this.B = this.B ? a > 0 : a > 15;
      }
      return this.B;
    }
  };
  class YQ {
    constructor(a, b) {
      this.timestamp = a;
      this.A = b;
    }
  }
  var aR = class {
    constructor() {
      this.A = $Q();
    }
    normalize(a) {
      return a / this.A;
    }
  };
  function $Q() {
    if (Sb) {
      if ($b || Jb) return 100;
      if (Zb) return 45;
      if (Kb) return 49.95;
    } else if (Pb) {
      if (!($b || Jb || ac) && Zb) return 20;
    } else if (Tb) {
      if ($b || Jb) return 53;
      if (Zb) return 45;
    }
    return 50;
  }
  class bR extends su {
    constructor(a, b, c, d, e) {
      super(a);
      this.type = "wheel";
      this.deltaMode = b;
      this.deltaX = c;
      this.deltaY = d;
      this.deltaZ = e;
      a = 1;
      switch (b) {
        case 2:
          a *= 450;
          break;
        case 1:
          a *= 15;
      }
      this.D = this.deltaX * a;
      this.B = this.deltaY * a;
    }
  }
  function cR(a, b) {
    Su.call(this);
    this.A = a;
    a = Ns(this.A) ? this.A : this.A.body;
    this.D = !!a && "rtl" == Ws(a, "direction");
    this.C = Fu(this.A, dR(), this, b);
  }
  Ea(cR, Su);
  function dR() {
    return Mb || $b ? "wheel" : Mb ? "DOMMouseScroll" : "mousewheel";
  }
  cR.prototype.handleEvent = function (a) {
    var b = 0,
      c = 0,
      d = 0,
      e = 0;
    a = a.hb;
    a.type == "wheel"
      ? ((b = a.deltaMode), (c = a.deltaX), (d = a.deltaY), (e = a.deltaZ))
      : a.type == "mousewheel"
      ? a.wheelDeltaX !== void 0
        ? ((c = -a.wheelDeltaX), (d = -a.wheelDeltaY))
        : (d = -a.wheelDelta)
      : ((b = 1),
        a.axis !== void 0 && a.axis === a.HORIZONTAL_AXIS
          ? (c = a.detail)
          : (d = a.detail));
    this.D && (c = -c);
    b = new bR(a, b, c, d, e);
    this.dispatchEvent(b);
  };
  cR.prototype.B = function () {
    cR.qa.B.call(this);
    Ou(this.C);
    this.C = null;
  };
  function eR(a, b) {
    var c = new su(b.event());
    a.G.handleEvent(c);
    var d = a.F;
    b = AQ(c, b.node().getBoundingClientRect());
    return {
      type: c.type,
      Mc: c.Mc,
      x: b.x,
      y: b.y,
      button: c.button,
      Qf: d.D,
      Se: d.B,
      ki: a.H.normalize(d.B),
      ctrlKey: d.ctrlKey,
      shiftKey: c.shiftKey,
      Yh: a.I.filter(d),
      target: c.target,
      preventDefault: () => {
        c.preventDefault();
      },
      stopPropagation: () => {
        c.stopPropagation();
      },
    };
  }
  var fR = class extends aQ {
    constructor(a) {
      super();
      this.U = a;
      this.G = new cR(new Su());
      this.F = null;
      this.I = new ZQ();
      this.H = new aR();
      this.G.listen("wheel", (b) => {
        this.F = b;
      });
    }
    A() {
      return { scrollwheel: { Aa: [dR()], global: null } };
    }
    B(a, b) {
      var c = eR(this, b);
      this.U(a, "scrollwheel", b, c);
    }
  };
  var gR = class extends aQ {
    constructor(a, b, { preventDefault: c = !1 } = {}) {
      super();
      this.U = b;
      this.G = IQ();
      this.F = new FQ(a, (d, e, f, g) => {
        this.U(d, e, f, g, 0);
      });
      this.preventDefault = c;
    }
    A() {
      var a = ["touchstart", "touchmove", "touchend", "touchcancel"];
      HQ() &&
        (a = a.concat([
          "pointerdown",
          "pointermove",
          "pointerup",
          "pointercancel",
        ]));
      a = { Aa: a, global: null };
      return {
        dragstart: a,
        drag: a,
        dragend: a,
        dragpointerdown: a,
        dragpointermove: a,
      };
    }
    B(a, b) {
      b.event();
      var c = b.event();
      if (this.G) {
        var d = c.type;
        if (
          d === "pointerdown" ||
          d === "pointermove" ||
          d === "pointerup" ||
          d === "pointercancel"
        )
          if (((c = OQ(this.G, c)), !c)) return;
      }
      d = c.type;
      this.preventDefault && c.preventDefault();
      if (d === "touchstart") {
        [d] = c.touches;
        let e = c.target;
        this.preventDefault && e && Cq(e) && CQ(e);
        DQ(this.F, a, c, d, b.node());
        this.F.move(c, d);
      } else if (d === "touchmove") ([a] = c.touches), this.F.move(c, a);
      else if (d === "touchcancel" || d === "touchend")
        ([d] = c.touches),
          d
            ? this.F.move(c, d)
            : ((d = c.changedTouches?.[Symbol.iterator]().next().value),
              this.F.release(c, d) || this.dispatchEvent(a, "click", b));
    }
    dispatchEvent(a, b, c) {
      var d = c.node();
      if (d) {
        var e = new su(c.event());
        d = AQ(e, d.getBoundingClientRect());
        this.U(a, b, c, {
          type: e.type,
          Mc: e.Mc,
          target: e.target,
          ctrlKey: e.ctrlKey,
          shiftKey: e.shiftKey,
          x: d.x,
          y: d.y,
          button: e.button,
          preventDefault: () => {
            e.preventDefault();
          },
          stopPropagation: () => {
            e.stopPropagation();
          },
        });
      }
    }
  };
  function hR(a, b, c, d = !1) {
    var e = [],
      f = new GQ(a, b);
    e.push(f);
    e.push(new gR(a, b, { preventDefault: d }));
    d = new SQ(b, f);
    e.push(d);
    e.push(new WQ(b, d, a, c));
    e.push(new bQ(a, c));
    e.push(new fR(b));
    e.push(new mQ(b));
    e.push(new nQ(b));
    e.push(new yQ(a, b, c));
    e.push(new XQ(a, b, c));
    e.push(new cQ(b));
    e.push(new lQ(b));
    e.push(new hQ(b));
    return e;
  }
  function iR(a, b, c, d, e, f = null) {
    {
      let g = a.C;
      g[b] && g[b][c]
        ? ((b = g[b][c]), (f = b[String(f)] || b.all_others || b["null"]))
        : (f = null);
    }
    f &&
      ((b = 0),
      a.F && (b = a.F.getTime()),
      f.scope ? f.xd.call(f.scope, d, e) : f.xd(d, e),
      a.F &&
        ((a = a.F.getTime() - b),
        a < 0.75 ||
          ((d = sa(d)),
          uQ[d] === void 0 && tQ[d] === void 0
            ? ((uQ[d] = a), (tQ[d] = 1))
            : uQ[d] !== void 0 &&
              tQ[d] !== void 0 &&
              ((uQ[d] += a), tQ[d]++))));
  }
  function jR(a, b, c) {
    a.Jd && ((a = a.Jd.xg(jD)), $O(a, b, { Re: c }), a.Nc());
  }
  function kR(a, b, c, d, e, f) {
    a.B(b, c, f);
    var g = a.C;
    g[b] = g[b] || {};
    g[b][c] = g[b][c] || {};
    g[b][c][String(f)] = { xd: e, scope: d };
    d = a.D.length;
    for (e = 0; e < d; ++e) a.D[e].Wf(b, c, !0);
    d = ++lR;
    a.G[d] = { qb: b, eventType: c, qualifier: f };
    return d;
  }
  function mR(a, b, c) {
    !a.H &&
      a.Jd &&
      ((a.H = !0),
      jR(a, b, c),
      setTimeout(() => {
        a.H = !1;
      }, 0));
  }
  var nR = class {
      constructor(a, b, c, { Wh: d = hR, wf: e, la: f, Eg: g } = {}) {
        this.M = a;
        this.F = u.performance?.now ? new zQ() : null;
        this.I = new Set();
        this.J = new Set();
        this.C = {};
        this.H = !1;
        this.G = {};
        this.Jd = null;
        Uq &&
          ex(Uq, "beforedone", (h) => {
            var k = sa(h);
            tQ[k] &&
              (Wq(h, "lhc", tQ[k].toString()),
              Wq(h, "lht", uQ[k].toFixed(3).toString()),
              delete tQ[k],
              delete uQ[k]);
          });
        this.A = d(
          c,
          (h, k, l, m, n) => {
            iR(this, h, k, l, m, n);
          },
          (h, k, l, m) => {
            iR(this, "", h, k, l, m);
          }
        );
        this.D = [new kQ(this.A, b, c, f, g), new sQ(this.A, e)];
        a = this.A.length;
        for (b = 0; b < a; ++b) {
          if ((c = this.A[b].A())) for (let h of Im(c)) this.I.add(h);
          if ((c = this.A[b].D())) for (let h of Im(c)) this.J.add(h);
        }
      }
      Zb(a) {
        var b = this.G[a];
        if (b) {
          var c = b.qb,
            d = b.eventType;
          b = b.qualifier;
          delete this.G[a];
          a = this.C;
          a[c]
            ? a[c][d]
              ? (a[c][d][String(b)] && delete a[c][d][String(b)],
                Jm(a[c][d]) && (delete a[c][d], Jm(a[c]) && delete a[c]))
              : jR(
                  this,
                  Error(
                    `Cannot remove eventHandlers for ${c} type ${d}, eventHandlers[${c}][${d}] is ${a[c][d]}`
                  ),
                  this.Zb
                )
            : jR(
                this,
                Error(
                  `Cannot remove eventHandlers for ${c}, eventHandlers[${c}] is ${a[c]}`
                ),
                this.Zb
              );
          a = this.D.length;
          for (b = 0; b < a; ++b) this.D[b].Wf(c, d, !1);
        }
      }
      Oc(a, b, c, d = null) {
        return this.J.has(a) ? kR(this, "", a, b, c, d) : null;
      }
      pb(a, b, c, d, e, f = null) {
        return this.I.has(c) ? kR(this, a ? a + "." + b : b, c, d, e, f) : null;
      }
      B(a, b, c) {
        var d = this.C;
        a: {
          var e = HL.length;
          for (let f = 0; f < e; ++f)
            if (b === HL[f]) {
              e = !0;
              break a;
            }
          e = !1;
        }
        e || c === null
          ? d[a] && d[a][b] && d[a][b][String(c)]
            ? mR(
                this,
                Error(
                  `Cannot overwrite an existing '${a}' handler for event type ${b} with qualifier ${c}; the existing one must be removed first.`
                ),
                this.B
              )
            : c !== null && d[a] && d[a][b] && d[a][b]["null"]
            ? jR(
                this,
                Error(
                  `An unqualified ${a} handler for this event type ${b} already exists, which captures all events of the specified type, including the ones that would be captured by this qualified handler.`
                ),
                this.B
              )
            : c === null &&
              d[a] &&
              d[a][b] &&
              jR(
                this,
                Error(
                  `A qualified ${a} handler for this event type ${b} already exists, which captures a subset of the events that would be captured by this unqualified handler.`
                ),
                this.B
              )
          : jR(
              this,
              Error(
                "The specified EventType does not use qualifiers; please omit the qualifier."
              ),
              this.B
            );
      }
      yd() {
        return this.M;
      }
    },
    lR = 0;
  var oR = class extends S {
    constructor(a) {
      super(a);
    }
  };
  var pR = class {
    constructor(a, b, c) {
      this.A = a;
      this.C = b;
      this.D = c;
      this.B = null;
    }
  };
  var qR = class {
    constructor() {
      this.A = this.canvas = null;
    }
  };
  function GN(a) {
    if (a.context.A) return 1;
    if (a.context.C) return 2;
    if (a.context.D) return 3;
  }
  var rR = class extends qR {
    constructor(a, b) {
      super();
      this.context = a;
      this.canvas = b;
    }
    getContext(a, b) {
      a(this.context, b);
    }
    B() {
      return this.canvas ? this.canvas.A : null;
    }
  };
  function sR(a, b, c) {
    c = Math.floor(c);
    a.A[c] || (a.A[c] = new wP());
    xP(a.A[c], b);
    if (a.C === void 0 || c < a.C) a.C = c;
    if (a.B === void 0 || c > a.B) a.B = c;
  }
  function tR(a) {
    a: {
      if (a.B !== void 0 && a.C !== void 0)
        for (let b = a.B; b >= a.C; b--)
          if (a.A[b] && !a.A[b].isEmpty()) {
            a = a.A[b];
            break a;
          }
      a = null;
    }
    return a ? yP(a) : void 0;
  }
  function uR(a) {
    if (a.B === void 0 || a.C === void 0) return -1;
    for (let b = a.B; b >= a.C; b--) if (a.A[b] && !a.A[b].isEmpty()) return b;
    return -1;
  }
  var vR = class {
    constructor() {
      this.A = {};
      this.B = this.C = void 0;
    }
    remove(a) {
      if (this.B !== void 0 && this.C !== void 0)
        for (
          let b = this.B;
          b >= this.C && (!this.A[b] || !this.A[b].remove(a));
          b--
        );
    }
  };
  function wR(a, b, c) {
    b.priority = c;
    xR(a, b, !0);
    sR(a.D, b, c);
  }
  function yR(a, b) {
    a.A[b.priority] && zb(a.A[b.priority], b);
    a.setActive(b, !1);
    a.C === 0 && a.B !== -1 && (u.clearTimeout(a.B), (a.B = -1));
  }
  function zR(a) {
    var b = uR(a.D);
    if (b !== -1) {
      var c = 0;
      b === 2 ? (c = 1) : b === 3 && (c = 2);
      if (a.G == null || a.G < c)
        (a.G = c),
          zy(a.I, {
            iterator: new AR(
              () => {
                for (var d = 0; d < 4 && BR(a); ++d) {
                  var e = a;
                  for (var f = tR(e.D); f && !f.C; ) f = tR(e.D);
                  f ? (xR(e, f, !1), (e = f)) : (e = null);
                  if (!e) break;
                  CR(a, e);
                }
                for (d = 3; d >= 1 && !(a.A[d] && a.A[d].length > 0); d--);
                for (e = 1; e <= 3; e++)
                  if (e < d && (f = a.F[e]) && f.length > 0)
                    for (; f.length > 0; ) {
                      let g = f.pop();
                      g.B = !1;
                      g.A.cancel();
                      wR(a, g, e);
                    }
              },
              () => BR(a),
              () => {
                a.G = null;
              }
            ),
            priority: c,
            uc: !0,
            Fb: 3,
            Db: 3,
          });
    }
  }
  function BR(a) {
    var b = uR(a.D) !== -1;
    a = a.C < 24;
    return b && a;
  }
  function CR(a, b) {
    DR(a, b, b.priority);
    b.A.start(() => {
      ER(a, b);
    });
  }
  function DR(a, b, c) {
    a.A[c] ? a.A[c].push(b) : (a.A[c] = [b]);
    b.startTime = Date.now();
    a.setActive(b, !0);
    b.priority = c;
    a.B === -1 && FR(a);
  }
  function ER(a, b) {
    b &&
      (b.active ? yR(a, b) : b.B && (zb(a.F[b.priority], b), (b.B = !1)),
      (b.A.state = null));
    zR(a);
  }
  function xR(a, b, c) {
    b.C = c;
    a.H += c ? 1 : -1;
  }
  function FR(a) {
    a.B = u.setTimeout(() => {
      if (a.C > 0 && a.B !== -1) {
        var b = Date.now();
        let e = [];
        for (var c = 1; c <= 3; c++) {
          var d = a.A[c];
          if (d)
            for (let f = 0; f < d.length; ++f) {
              let g = d[f];
              b - g.startTime >= 1e4 && e.push(g);
            }
        }
        for (d = 0; d < e.length; ++d)
          (b = a),
            (c = e[d]),
            yR(b, c),
            b.F[c.priority] ? b.F[c.priority].push(c) : (b.F[c.priority] = [c]),
            (c.B = !0),
            zR(b);
        a.C > 0 ? FR(a) : (a.B = -1);
      }
    }, 1e4);
  }
  var HR = class {
      constructor(a) {
        this.I = a;
        this.C = 0;
        this.A = [];
        this.H = 0;
        this.D = new vR();
        this.F = {};
        this.B = -1;
        this.G = null;
      }
      Id(a, b) {
        var c = a.state;
        if (!c || c.priority !== b) {
          if (c)
            a: if (((a = c), a.C)) {
              c = this.D;
              var d = Math.floor(b);
              for (var e = c.B; e >= c.C; e--)
                if (c.A[e] && c.A[e].remove(a)) {
                  sR(c, a, d);
                  break;
                }
              a.priority = b;
            } else {
              if (a.active) {
                c = b > a.priority;
                d = this.H === 0;
                e = uR(this.D) <= b;
                if (c || d || e) {
                  yR(this, a);
                  DR(this, a, b);
                  break a;
                }
                this.remove(a.A) && wR(this, a, b);
              }
              a.B && (this.remove(a.A), wR(this, a, b));
            }
          else (c = new GR(a, b)), (a.state = c), wR(this, c, b);
          if (this.C === 24)
            for (a = !1, c = 1; c < b; c++) {
              if (this.A[c] && this.A[c].length > 0)
                for (d = this.A[c], e = d.length - 1; d[e]; e--) {
                  let f = d[e];
                  if (f.A.cancel()) {
                    a = !0;
                    f.A.state && yR(this, f);
                    wR(this, f, c);
                    break;
                  }
                }
              if (a) break;
            }
          zR(this);
        }
      }
      remove(a) {
        var b = a.state,
          c = !1;
        if (b && (b.active || b.B)) {
          if (a.cancel() || b.B) ER(this, b), (c = !0);
        } else b && b.C && (xR(this, b, !1), (c = !0));
        c && (a.state = null);
        return c;
      }
      setActive(a, b) {
        a.active = b;
        this.C += b ? 1 : -1;
      }
    },
    GR = class {
      constructor(a, b) {
        this.A = a;
        this.priority = b;
        this.B = this.active = this.C = !1;
        this.startTime = 0;
      }
    };
  class AR {
    constructor(a, b, c) {
      this.B = a;
      this.A = b;
      this.C = c;
    }
    next() {
      this.B();
      var a = !this.A();
      a && this.C();
      return { done: a, value: void 0 };
    }
  }
  function IR() {
    var a = { ge: Date.now },
      b = a.Zi || document;
    if (b) {
      var c = !Ly(b);
      var d = (e) => {
        Jy(e, void 0, b);
      };
    } else (c = !0), (d = () => {});
    return new JR(a, c, d);
  }
  function KR(a, b) {
    a.U = b;
  }
  class JR {
    constructor({ ge: a = Date.now, Ff: b = 5e3 }, c, d) {
      this.A = Infinity;
      this.U = null;
      this.animate = c;
      this.Ff = b;
      this.ge = a;
      this.A = this.animate ? Infinity : this.ge() + this.Ff;
      d((e) => {
        this.A = (this.animate = e) ? Infinity : this.ge() + this.Ff;
        this.U && this.U(e);
      });
    }
  }
  function LR(a) {
    a.C = !0;
    try {
      a.Pf();
    } finally {
      a.D && ((a.A && a.Pc.animate) || MR(a)), (a.C = !1);
    }
  }
  function MR(a) {
    var b;
    if ((b = !a.B)) (b = a.Pc), (b = !(b.ge() > b.A));
    b && (a.Rg(a.G), (a.B = !0));
  }
  function NR(a) {
    a.Pc.animate
      ? a.A || a.B || (a.requestAnimationFrame.call(u, a.H), (a.A = !0))
      : MR(a);
  }
  function OR(a) {
    ac ? NR(a) : a.C ? (a.D = !0) : (a.Pc.animate && a.A) || MR(a);
  }
  var QR = class {
    constructor(a = {}) {
      this.C = this.D = !1;
      this.F = null;
      this.H = () => {
        this.A = !1;
        LR(this);
      };
      this.G = () => {
        this.D = this.B = !1;
        LR(this);
      };
      this.B = this.A = !1;
      this.requestAnimationFrame = a.requestAnimationFrame || PR();
      this.Rg = a.Rg || Mp;
      this.Pc = a.Pc || IR();
      KR(this.Pc, (b) => {
        b && !this.A && MR(this);
      });
    }
    Pf() {
      this.F.Pf();
    }
  };
  function PR() {
    return (
      u.requestAnimationFrame ||
      u.webkitRequestAnimationFrame ||
      u.mozRequestAnimationFrame ||
      u.oRequestAnimationFrame ||
      u.msRequestAnimationFrame ||
      ((a) => {
        u.setTimeout(a, 16);
      })
    );
  }
  var RR = class {
    constructor(a = 0, b = 0) {
      this.Ac = a;
      this.Bc = b;
    }
    clone() {
      return new RR(this.Ac, this.Bc);
    }
  };
  function zy(a, b) {
    var c = new SR(b);
    b.Hf
      ? (a.M.push({ gi: c, priority: b.priority }), OR(a.Ec))
      : (a.A[TR(b.priority, !!b.uc)].push(c), a.C || OR(a.Ec));
  }
  function TL(a) {
    if (a.G.length > 0 || a.D.length > 0 || a.F.length > 0) return !0;
    for (let b = TR(1, !1); b <= 5; b++) if (a.A[b].length) return !0;
    return !1;
  }
  function qM(a, b) {
    b.input ? a.F.push(b) : b.animation ? a.D.push(b) : b.render && a.G.push(b);
    NR(a.Ec);
  }
  function UR(a, b) {
    var c = a.now(),
      d = a.D;
    a.D = [];
    a.N = b;
    var e = d.length;
    for (let f = 0; f < e; f++) {
      let g = d[f];
      a.now();
      g.animation(b);
    }
    VR(a, c);
  }
  function WR(a, b) {
    var c = a.now(),
      d = b - a.K;
    if (a.J) {
      var e = 1e3 / d;
      d > iy && a.Ug++;
      a.rd *= 0.7;
      a.rd += 0.3 * e;
      a.Od *= 0.7;
      a.Od += 0.3 * e * e;
      a.ug++;
      a.ve += d;
    }
    a.K = b;
    b = a.G;
    a.G = [];
    d = b.length;
    for (e = 0; e < d; e++) {
      let f = b[e];
      a.now();
      f.render();
    }
    VR(a, c);
  }
  function YR(a, b, c) {
    var d = a.now();
    if (a.H && a.now() >= c) return !1;
    var e = a.A[b];
    if (e.length === 0) return !0;
    for (var f = [], g = !1, h = 0; h < e.length && !g; h++)
      for (var k = e[h]; ; ) {
        let n = k.ma;
        if (!n) break;
        var l = a.now();
        if (a.H && l >= c) {
          g = !0;
          f.push(h);
          break;
        }
        a.now();
        l = !0;
        try {
          if (n.U) n.U();
          else {
            var m = n.iterator.next();
            m.value && !m.done
              ? (m.value.then(() => {
                  zy(a, n);
                }),
                (l = !0))
              : (l = !!m.done);
          }
        } finally {
          l && (k.ma = null), (a.H = !0);
        }
        if (l) break;
      }
    a.ie.Bc += a.now() - d;
    d = [];
    for (k = 0; k < f.length; k++) (m = e[f[k]]) && m.ma && d.push(m);
    if (g) return (a.A[b] = d.concat(e.slice(h - 1))), !1;
    a.A[b] = d;
    return a.now() < c;
  }
  function VR(a, b) {
    a.ie.Ac += a.now() - b;
  }
  function ZR(a, b, c) {
    a = b + a.I - 3;
    c -= a;
    c > 0 && (a += Math.ceil(c / $R) * $R);
    return a;
  }
  var bS = class {
    constructor() {
      ({
        Ec: e,
        Tg: d = !1,
        ig: c = !0,
        now: b = (u.performance &&
          u.performance.now &&
          (() => u.performance.now())) ||
          Date.now,
        Pc: a,
      } = {});
      var a, b, c, d, e;
      this.I = $R;
      this.Ug = this.ug = this.K = this.Od = this.rd = this.B = 0;
      this.ie = new RR();
      this.H = this.C = !1;
      this.F = [];
      this.D = [];
      this.G = [];
      this.A = [[], [], [], [], [], []];
      this.M = [];
      this.J = !1;
      this.ve = 0;
      this.now = b;
      this.Ec = e || new QR({ Pc: a });
      this.Ec.F = this;
      this.N = this.now();
      this.Tg = d;
      this.ig = c;
      hy.push(this);
    }
    Pf() {
      var a = this.now();
      this.C = !0;
      var b = this.M;
      if (b.length > 0) {
        for (let f = 0; f < b.length; f++)
          this.A[TR(b[f].priority, !1)].push(b[f].gi), this.C || OR(this.Ec);
        this.M = [];
      }
      try {
        let f = this.now(),
          g = this.F;
        this.F = [];
        let h = g.length;
        for (b = 0; b < h; b++) {
          let k = g[b];
          this.now();
          k.input();
        }
        VR(this, f);
        if (this.Tg) {
          UR(this, a);
          WR(this, a);
          var c = Infinity;
        } else {
          if (this.ig)
            if (a - this.K < this.I - (6 + this.B)) var d = a + this.I - 3;
            else {
              UR(this, a);
              WR(this, a);
              var e = this.now();
              this.B *= 0.97;
              this.B += 0.03 * (e - a);
              let k = Math.ceil((1 / $R) * (this.B + 3 + 6)) * $R;
              k = k < $R ? $R : k;
              this.I = k = k > aS ? aS : k;
              d = ZR(this, a, e);
            }
          else {
            UR(this, a);
            WR(this, a);
            let k = this.now();
            d = ZR(this, a, k);
          }
          c = d;
        }
        this.H = !1;
        for (a = 5; a >= 0 && YR(this, a, c); a--);
      } finally {
        (this.C = !1),
          (c = this.G.length > 0 || this.D.length > 0 || this.F.length > 0),
          (a =
            this.A[5].length > 0 ||
            this.A[4].length > 0 ||
            this.A[3].length > 0 ||
            this.A[2].length > 0 ||
            this.A[1].length > 0 ||
            this.A[0].length > 0),
          c ? NR(this.Ec) : a && OR(this.Ec),
          (this.J = a || c);
      }
    }
  };
  class SR {
    constructor(a) {
      this.ma = a;
      this.ma.U
        ? (a = null)
        : ((a = this.ma),
          (a = a.iterator ? a.iterator : a.sj[Symbol.iterator]()));
      this.iterator = a;
    }
  }
  var $R = 1e3 / 60,
    aS = 1e4 / 60;
  function TR(a, b) {
    a *= 2;
    b && (a += 1);
    return a;
  }
  function MP(a, b) {
    var c = new oR();
    c = M(c, 1, !0);
    b = zf(c, ms, 99, b);
    c = a.getContext();
    c.A ? R(b, 21, 1) : c.C ? R(b, 21, 2) : c.D && R(b, 21, 3);
    b = Q(b, 82, a.container.id);
    b = Q(b, 83, "viewport");
    b = Q(b, 96, a.role);
    a = Q(b, 97, a.fc);
    return Re(a);
  }
  function NP(a) {
    var b = Js(document, "div");
    b.style.width = "100%";
    b.style.height = "100%";
    a = new rR(a.getContext(), a.canvas);
    a.A = b;
    return a;
  }
  var eS = class {
    constructor(
      a,
      b,
      c,
      {
        kf: d = null,
        zoom: e = null,
        Be: f = null,
        role: g = "",
        fc: h = "",
      } = {}
    ) {
      this.container = a;
      this.canvas = b;
      this.context = c;
      this.A = new bS();
      this.la = cS();
      this.B = new HR(this.A);
      this.kf = d || null;
      this.zoom = e || null;
      dS(this.la);
      this.Be = f || null;
      this.role = g || "";
      this.fc = h || "";
    }
    getContext() {
      return this.context;
    }
  };
  function cS() {
    var a = new gr(),
      b = new kr(a),
      c = Mw();
    return new nR(a, b, c, { Wh: (d, e, f) => hR(d, e, f, !0) });
  }
  function dS(a) {
    a.Oc("beforeunload", null, (b) => {
      hx(cx, "beforeunload", b);
    });
  }
  var fS = class {
    constructor() {
      this.D = this.C = this.B = this.arrayBuffer = void 0;
      this.yc = [];
      this.zc = [];
    }
    clear() {
      this.M();
      this.K();
      this.N();
      this.L();
      for (let a = 31; a >= 0; --a) this.O(a), this.V(a);
    }
    apply(a) {
      a.arrayBuffer !== void 0 &&
        a.arrayBuffer !== this.arrayBuffer &&
        this.F(a.arrayBuffer);
      a.B !== void 0 && a.B !== this.B && this.G(a.B);
      a.C !== void 0 && a.C !== this.C && this.H(a.C);
      a.D !== void 0 && a.D !== this.D && this.I(a.D);
      for (let b = 31; b >= 0; --b)
        a.yc[b] !== void 0 && a.yc[b] !== this.yc[b] && this.dd(b, a.yc[b]),
          a.zc[b] !== void 0 && a.zc[b] !== this.zc[b] && this.ed(b, a.zc[b]);
    }
    Kg() {
      return 32;
    }
    F(a) {
      this.arrayBuffer = a;
    }
    M() {
      this.arrayBuffer = void 0;
    }
    G(a) {
      this.B = a;
    }
    K() {
      this.B = void 0;
    }
    H(a) {
      this.C = a;
    }
    N() {
      this.C = void 0;
    }
    I(a) {
      this.D = a;
    }
    L() {
      this.D = void 0;
    }
    dd(a, b) {
      this.yc[a] = b;
    }
    O(a) {
      delete this.yc[a];
    }
    ed(a, b) {
      this.zc[a] = b;
    }
    V(a) {
      delete this.zc[a];
    }
  };
  function kO(a, b, c) {
    if (b !== a.width || c !== a.height || 6408 !== a.format || 5121 !== a.type)
      (a.width = b), (a.height = c);
  }
  function lO(a, b) {
    b *= gS[6408] * hS[5121];
    if (b % 4 !== 0) {
      var c = 1;
      b % 2 === 0 && (c = 2);
      a.state.G(3317, c);
    }
  }
  var iS = class {
      constructor(a, b, c) {
        this.B = a;
        this.state = b;
        this.C = c;
        this.J = this.H = 10497;
        this.G = 9986;
        this.F = 9729;
        this.A = 0;
        this.target = 3553;
        this.type = this.format = this.height = this.width = 0;
        this.I = this.isPowerOfTwo = !1;
        this.D = 34069;
        this.texture = this.B.createTexture();
      }
      bind() {
        this.target === 3553
          ? this.C.dd(this.A, this)
          : this.C.ed(this.A, this);
      }
      unbind() {
        this.target === 3553
          ? this.C.yc[this.A] === this && this.C.dd(this.A, null)
          : this.C.zc[this.A] === this && this.C.ed(this.A, null);
      }
      deleteTexture() {
        var a = this.state.M();
        for (let b = 0; b <= this.C.Kg(); ++b)
          this.A !== b && (this.A = b), this.unbind();
        this.I = !0;
        this.B.deleteTexture(this.texture);
        this.state.J(a);
      }
      S() {
        return this.width;
      }
      R() {
        return this.height;
      }
    },
    gS = { [6408]: 4, [6407]: 3, [6410]: 2, [6409]: 1, [6406]: 1 },
    hS = { [5121]: 1, [5126]: 4, [32819]: 2, [33635]: 2, [32820]: 2 };
  var jS = class extends fS {
    constructor(a, b) {
      super();
      this.P = b;
      this.A = a;
      this.J = Math.min(32, a.getParameter(35661));
      a = this.A;
      this.A = null;
      this.clear();
      this.A = a;
    }
    F(a) {
      this.arrayBuffer !== a &&
        (super.F(a), this.A && this.A.bindBuffer(34962, a));
    }
    M() {
      this.F(null);
    }
    G(a) {
      this.B !== a && (super.G(a), this.A && this.A.bindBuffer(34963, a));
    }
    K() {
      this.G(null);
    }
    H(a) {
      this.C !== a && (super.H(a), this.A && this.A.bindFramebuffer(36160, a));
    }
    N() {
      this.H(null);
    }
    I(a) {
      this.D !== a && (super.I(a), this.A && this.A.bindRenderbuffer(36161, a));
    }
    L() {
      this.I(null);
    }
    dd(a, b) {
      a < this.J && this.P.J(33984 + a);
      this.yc[a] !== b &&
        (super.dd(a, b),
        this.A &&
          (b
            ? this.A.bindTexture(3553, b.texture)
            : this.A.bindTexture(3553, null)));
    }
    O(a) {
      this.dd(a, null);
    }
    ed(a, b) {
      a < this.J && this.P.J(33984 + a);
      this.zc[a] !== b &&
        (super.ed(a, b),
        this.A &&
          (b
            ? this.A.bindTexture(34067, b.texture)
            : this.A.bindTexture(34067, null)));
    }
    V(a) {
      this.ed(a, null);
    }
    Kg() {
      return this.J - 1;
    }
  };
  function kS(a, b) {
    a = a.C[0 + lS[b]];
    if (a !== 0) return a === 2;
  }
  function mS(a, b) {
    return a.C[0 + lS[b]] > 0;
  }
  function nS(a, b) {
    a = b ? a.B[15] : a.B[14];
    if (a !== 65535) return a;
  }
  function oS(a) {
    a = a.B[20];
    if (a !== 65535) return a;
  }
  function pS(a) {
    a = a.A[17];
    if (!(a < 0)) return a;
  }
  function qS(a) {
    if (a.C[76] === 1) return a.dg[18];
  }
  function rS(a, b, c, d, e) {
    return (
      a.C[80] === (b ? 2 : 1) &&
      a.C[81] === (c ? 2 : 1) &&
      a.C[82] === (d ? 2 : 1) &&
      a.C[83] === (e ? 2 : 1)
    );
  }
  function sS(a) {
    a = a.C[84];
    if (a !== 0) return a === 2;
  }
  function tS(a) {
    a = a.B[64];
    if (a !== 65535) return a;
  }
  function uS(a) {
    a = a.B[vS];
    if (a !== 65535) return a;
  }
  function wS(a) {
    a = a.A[xS];
    if (!(a < 0)) return a;
  }
  function yS(a, b) {
    a = a.C[zS + b];
    if (a !== 0) return a === 2;
  }
  function AS(a, b) {
    a = a.B[BS + CS[b]];
    if (a !== 65535) return a;
  }
  function DS(a, b) {
    return a.B[BS + CS[b]] !== 65535;
  }
  function ES(a) {
    a = a.B[GS];
    if (a !== 65535) return a;
  }
  var LS = class {
      constructor() {
        this.Z = new ArrayBuffer(HS);
        this.C = new Uint8Array(this.Z);
        this.B = new Uint16Array(this.Z);
        this.dg = new Uint32Array(this.Z);
        this.D = new Int32Array(this.Z);
        this.A = new Float32Array(this.Z);
        this.clear();
      }
      clear() {
        this.I(3042);
        this.I(2884);
        this.I(2929);
        this.I(3024);
        this.I(32823);
        this.I(32926);
        this.I(32928);
        this.I(3089);
        this.I(2960);
        this.Zc();
        this.ad();
        this.Zd();
        this.Ue();
        this.Yf();
        this.ae();
        this.ce();
        this.Le();
        this.Ne();
        this.hh();
        this.ih();
        this.Zf();
        this.cg();
        this.Oe();
        this.kh();
        this.oh();
        this.Xf();
        for (let a = 0; a < 32; ++a) this.bg(a);
        this.Bb();
        this.K(3317);
        this.K(3333);
        this.K(37440);
        this.K(37441);
        this.K(37443);
        this.nh(33170);
      }
      apply(a) {
        mS(a, 3042) &&
          kS(a, 3042) !== kS(this, 3042) &&
          this.F(3042, kS(a, 3042));
        mS(a, 2884) &&
          kS(a, 2884) !== kS(this, 2884) &&
          this.F(2884, kS(a, 2884));
        mS(a, 2929) &&
          kS(a, 2929) !== kS(this, 2929) &&
          this.F(2929, kS(a, 2929));
        mS(a, 3024) &&
          kS(a, 3024) !== kS(this, 3024) &&
          this.F(3024, kS(a, 3024));
        mS(a, 32823) &&
          kS(a, 32823) !== kS(this, 32823) &&
          this.F(32823, kS(a, 32823));
        mS(a, 32926) &&
          kS(a, 32926) !== kS(this, 32926) &&
          this.F(32926, kS(a, 32926));
        mS(a, 32928) &&
          kS(a, 32928) !== kS(this, 32928) &&
          this.F(32928, kS(a, 32928));
        mS(a, 3089) &&
          kS(a, 3089) !== kS(this, 3089) &&
          this.F(3089, kS(a, 3089));
        mS(a, 2960) &&
          kS(a, 2960) !== kS(this, 2960) &&
          this.F(2960, kS(a, 2960));
        if (a.A[3] >= 0) {
          var b = a.A[3],
            c = a.A[4],
            d = a.A[5],
            e = a.A[6];
          (this.A[3] === b &&
            this.A[4] === c &&
            this.A[5] === d &&
            this.A[6] === e) ||
            this.na(b, c, d, e);
        }
        a.B[14] === 65535 ||
          (nS(this, !1) === nS(a, !1) && nS(this, !0) === nS(a, !0)) ||
          ((b = nS(a, !1)),
          (c = nS(a, !0)),
          c === b && (c = void 0),
          this.aa(b, c));
        a.B[16] !== 65535 &&
          ((b = a.B[16]),
          (c = a.B[17]),
          (d = a.B[18]),
          (e = a.B[19]),
          this.B[16] !== b ||
            this.B[17] !== c ||
            this.B[18] !== d ||
            this.B[19] !== e) &&
          (d === b && e === c && (e = d = void 0), this.O(b, c, d, e));
        a.B[20] !== 65535 && oS(a) !== oS(this) && this.P(oS(a));
        a.C[48] > 0 &&
          ((b = a.A[11]),
          (c = a.C[48] === 2),
          (this.A[11] === b && this.C[48] === (c ? 2 : 1)) || this.ib(b, c));
        a.A[13] >= 0 &&
          ((b = a.A[13]),
          (c = a.A[14]),
          (d = a.A[15]),
          (e = a.A[16]),
          (this.A[13] === b &&
            this.A[14] === c &&
            this.A[15] === d &&
            this.A[16] === e) ||
            this.V(b, c, d, e));
        a.A[17] >= 0 && pS(a) !== pS(this) && this.Da(pS(a));
        a.C[76] === 1 && qS(a) !== qS(this) && this.ua(qS(a));
        a.C[80] > 0 &&
          ((b = a.C[80] === 2),
          (c = a.C[81] === 2),
          (d = a.C[82] === 2),
          (e = a.C[83] === 2),
          rS(this, b, c, d, e) || this.Ca(b, c, d, e));
        a.C[84] > 0 && sS(a) !== sS(this) && this.L(sS(a));
        a.A[22] >= 0 &&
          ((b = a.A[22]),
          (c = a.A[23]),
          (this.A[22] === b && this.A[23] === c) || this.Na(b, c));
        a.D[26] >= 0 &&
          ((b = a.D[24]),
          (c = a.D[25]),
          (d = a.D[26]),
          (e = a.D[27]),
          (this.D[24] === b &&
            this.D[25] === c &&
            this.D[26] === d &&
            this.D[27] === e) ||
            this.sa(b, c, d, e));
        a.D[30] >= 0 &&
          ((b = a.D[28]),
          (c = a.D[29]),
          (d = a.D[30]),
          (e = a.D[31]),
          (this.D[28] === b &&
            this.D[29] === c &&
            this.D[30] === d &&
            this.D[31] === e) ||
            this.N(b, c, d, e));
        a.B[64] !== 65535 && tS(a) !== tS(this) && this.ea(tS(a));
        a.B[vS] !== 65535 && uS(a) !== uS(this) && this.ga(uS(a));
        a.A[xS] > 0 && wS(a) !== wS(this) && this.T(wS(a));
        a.C[IS] > 0 &&
          ((b = a.A[JS]),
          (c = a.A[JS + 1]),
          (this.C[IS] > 0 && this.A[JS] === b && this.A[JS + 1] === c) ||
            this.W(b, c));
        for (b = 0; b < 32; ++b)
          a.C[zS + b] > 0 && yS(a, b) !== yS(this, b) && this.H(b, yS(a, b));
        a.B[KS] !== 65535 && a.M() !== this.M() && this.J(a.M());
        DS(a, 3317) &&
          AS(a, 3317) !== AS(this, 3317) &&
          this.G(3317, AS(a, 3317));
        DS(a, 3333) &&
          AS(a, 3333) !== AS(this, 3333) &&
          this.G(3333, AS(a, 3333));
        DS(a, 37440) &&
          AS(a, 37440) !== AS(this, 37440) &&
          this.G(37440, AS(a, 37440));
        DS(a, 37441) &&
          AS(a, 37441) !== AS(this, 37441) &&
          this.G(37441, AS(a, 37441));
        DS(a, 37443) &&
          AS(a, 37443) !== AS(this, 37443) &&
          this.G(37443, AS(a, 37443));
        a.B[GS] !== 65535 && ES(a) !== ES(this) && this.Sa(33170, ES(a));
      }
      F(a, b) {
        this.C[0 + lS[a]] = b ? 2 : 1;
      }
      I(a) {
        this.C[0 + lS[a]] = 0;
      }
      na(a, b, c, d) {
        this.A[3] = a;
        this.A[4] = b;
        this.A[5] = c;
        this.A[6] = d;
      }
      Zc() {
        this.A[3] = -1;
        this.A[4] = -1;
        this.A[5] = -1;
        this.A[6] = -1;
      }
      aa(a, b) {
        this.B[14] = a;
        this.B[15] = b || a;
      }
      ad() {
        this.B[14] = 65535;
        this.B[15] = 65535;
      }
      O(a, b, c, d) {
        this.B[16] = a;
        this.B[17] = b;
        d = d === void 0 ? b : d;
        this.B[18] = c === void 0 ? a : c;
        this.B[19] = d;
      }
      Zd() {
        this.B[16] = 65535;
        this.B[17] = 65535;
        this.B[18] = 65535;
        this.B[19] = 65535;
      }
      P(a) {
        this.B[20] = a;
      }
      Ue() {
        this.B[20] = 65535;
      }
      ib(a, b) {
        this.A[11] = a;
        this.C[48] = b ? 2 : 1;
      }
      Yf() {
        this.C[48] = 0;
      }
      V(a, b, c, d) {
        this.A[13] = a;
        this.A[14] = b;
        this.A[15] = c;
        this.A[16] = d;
      }
      ae() {
        this.A[13] = -1;
        this.A[14] = -1;
        this.A[15] = -1;
        this.A[16] = -1;
      }
      Da(a) {
        this.A[17] = a;
      }
      ce() {
        this.A[17] = -1;
      }
      ua(a) {
        this.dg[18] = a;
        this.C[76] = 1;
      }
      Le() {
        this.C[76] = 0;
      }
      Ca(a, b, c, d) {
        this.C[80] = a ? 2 : 1;
        this.C[81] = b ? 2 : 1;
        this.C[82] = c ? 2 : 1;
        this.C[83] = d ? 2 : 1;
      }
      Ne() {
        this.C[80] = 0;
        this.C[81] = 0;
        this.C[82] = 0;
        this.C[83] = 0;
      }
      L(a) {
        this.C[84] = a ? 2 : 1;
      }
      hh() {
        this.C[84] = 0;
      }
      Na(a, b) {
        this.A[22] = a;
        this.A[23] = b;
      }
      ih() {
        this.A[22] = -1;
        this.A[23] = -1;
      }
      sa(a, b, c, d) {
        this.D[24] = a;
        this.D[25] = b;
        this.D[26] = c;
        this.D[27] = d;
      }
      Zf() {
        this.D[26] = -1;
        this.D[27] = -1;
      }
      N(a, b, c, d) {
        this.D[28] = a;
        this.D[29] = b;
        this.D[30] = c;
        this.D[31] = d;
      }
      cg() {
        this.D[30] = -1;
        this.D[31] = -1;
      }
      ea(a) {
        this.B[64] = a;
      }
      Oe() {
        this.B[64] = 65535;
      }
      ga(a) {
        this.B[vS] = a;
      }
      kh() {
        this.B[vS] = 65535;
      }
      T(a) {
        this.A[xS] = a;
      }
      oh() {
        this.A[xS] = -1;
      }
      W(a, b) {
        this.A[JS] = a;
        this.A[JS + 1] = b;
        this.C[IS] = 1;
      }
      Xf() {
        this.C[IS] = 0;
      }
      H(a, b) {
        this.C[zS + a] = b ? 2 : 1;
      }
      bg(a) {
        this.C[zS + a] = 0;
      }
      J(a) {
        this.B[KS] = a;
      }
      M() {
        var a = this.B[KS];
        if (a !== 65535) return a;
      }
      Bb() {
        this.B[KS] = 65535;
      }
      G(a, b) {
        this.B[BS + CS[a]] = b;
      }
      K(a) {
        this.B[BS + CS[a]] = 65535;
      }
      Sa(a, b) {
        this.B[GS] = b;
      }
      nh() {
        this.B[GS] = 65535;
      }
    },
    lS = [];
  lS[3042] = 0;
  lS[2884] = 1;
  lS[2929] = 2;
  lS[3024] = 3;
  lS[32823] = 4;
  lS[32926] = 5;
  lS[32928] = 6;
  lS[3089] = 7;
  lS[2960] = 8;
  var MS = 136,
    vS = 66,
    NS = MS + 4,
    xS = MS / 4,
    zS = NS + 12,
    JS = NS / 4,
    IS = NS + 8,
    OS = zS + 32,
    PS = OS + 4,
    KS = OS / 2,
    CS = [];
  CS[3317] = 0;
  CS[3333] = 1;
  CS[37440] = 2;
  CS[37441] = 3;
  CS[37443] = 4;
  var QS = PS + 12,
    BS = PS / 2,
    HS = QS + 4,
    GS = QS / 2;
  var RS = class extends LS {
    constructor(a) {
      super();
      this.context = a;
      a.scissor(0, 0, 0, 0);
      a.viewport(0, 0, 0, 0);
      a.enableVertexAttribArray(0);
    }
    F(a, b) {
      if (kS(this, a) !== b) {
        super.F(a, b);
        var c = this.context;
        c && (b ? c.enable(a) : c.disable(a));
      }
    }
    I(a) {
      a === 3024 ? this.F(a, !0) : this.F(a, !1);
    }
    na(a, b, c, d) {
      if (
        this.A[3] !== a ||
        this.A[4] !== b ||
        this.A[5] !== c ||
        this.A[6] !== d
      ) {
        super.na(a, b, c, d);
        var e = this.context;
        e && e.blendColor(a, b, c, d);
      }
    }
    Zc() {
      this.na(0, 0, 0, 0);
    }
    aa(a, b) {
      var c = b === void 0 ? a : b;
      if (nS(this, !1) !== a || nS(this, !0) !== c)
        super.aa(a, b),
          (b = this.context) &&
            (c === a ? b.blendEquation(a) : b.blendEquationSeparate(a, c));
    }
    ad() {
      this.aa(32774);
    }
    O(a, b, c, d) {
      var e = c === void 0 ? a : c,
        f = d === void 0 ? b : d;
      if (
        this.B[16] !== a ||
        this.B[17] !== b ||
        this.B[18] !== e ||
        this.B[19] !== f
      )
        super.O(a, b, c, d),
          (c = this.context) &&
            (e === a && f === b
              ? c.blendFunc(a, b)
              : c.blendFuncSeparate(a, b, e, f));
    }
    Zd() {
      this.O(1, 0);
    }
    P(a) {
      if (oS(this) !== a) {
        super.P(a);
        var b = this.context;
        b && b.depthFunc(a);
      }
    }
    Ue() {
      this.P(513);
    }
    ib(a, b) {
      if (this.A[11] !== a || this.C[48] !== (b ? 2 : 1)) {
        super.ib(a, b);
        var c = this.context;
        c && c.sampleCoverage(a, b);
      }
    }
    Yf() {
      this.ib(1, !1);
    }
    V(a, b, c, d) {
      if (
        this.A[13] !== a ||
        this.A[14] !== b ||
        this.A[15] !== c ||
        this.A[16] !== d
      ) {
        super.V(a, b, c, d);
        var e = this.context;
        e && e.clearColor(a, b, c, d);
      }
    }
    ae() {
      this.V(0, 0, 0, 0);
    }
    Da(a) {
      if (pS(this) !== a) {
        super.Da(a);
        var b = this.context;
        b && b.clearDepth(a);
      }
    }
    ce() {
      this.Da(1);
    }
    ua(a) {
      if (qS(this) !== a) {
        super.ua(a);
        var b = this.context;
        b && b.clearStencil(a);
      }
    }
    Le() {
      this.ua(0);
    }
    Ca(a, b, c, d) {
      if (!rS(this, a, b, c, d)) {
        super.Ca(a, b, c, d);
        var e = this.context;
        e && e.colorMask(a, b, c, d);
      }
    }
    Ne() {
      this.Ca(!0, !0, !0, !0);
    }
    L(a) {
      if (sS(this) !== a) {
        super.L(a);
        var b = this.context;
        b && b.depthMask(a);
      }
    }
    hh() {
      this.L(!0);
    }
    Na(a, b) {
      if (this.A[22] !== a || this.A[23] !== b) {
        super.Na(a, b);
        var c = this.context;
        c && c.depthRange(a, b);
      }
    }
    ih() {
      this.Na(0, 1);
    }
    sa(a, b, c, d) {
      if (
        this.D[24] !== a ||
        this.D[25] !== b ||
        this.D[26] !== c ||
        this.D[27] !== d
      ) {
        super.sa(a, b, c, d);
        var e = this.context;
        e && e.scissor(a, b, c, d);
      }
    }
    Zf() {
      this.sa(0, 0, 0, 0);
    }
    N(a, b, c, d) {
      if (
        this.D[28] !== a ||
        this.D[29] !== b ||
        this.D[30] !== c ||
        this.D[31] !== d
      ) {
        super.N(a, b, c, d);
        var e = this.context;
        e && e.viewport(a, b, c, d);
      }
    }
    cg() {
      this.N(0, 0, 0, 0);
    }
    ea(a) {
      if (tS(this) !== a) {
        super.ea(a);
        var b = this.context;
        b && b.cullFace(a);
      }
    }
    Oe() {
      this.ea(1029);
    }
    ga(a) {
      if (uS(this) !== a) {
        super.ga(a);
        var b = this.context;
        b && b.frontFace(a);
      }
    }
    kh() {
      this.ga(2305);
    }
    T(a) {
      if (wS(this) !== a) {
        super.T(a);
        var b = this.context;
        b && b.lineWidth(a);
      }
    }
    oh() {
      this.T(1);
    }
    W(a, b) {
      if (!(this.C[IS] > 0) || this.A[JS] !== a || this.A[JS + 1] !== b) {
        super.W(a, b);
        var c = this.context;
        c && c.polygonOffset(a, b);
      }
    }
    Xf() {
      this.W(0, 0);
    }
    H(a, b) {
      var c = this.context;
      yS(this, a) !== b &&
        (super.H(a, b),
        c &&
          (b ? c.enableVertexAttribArray(a) : c.disableVertexAttribArray(a)));
    }
    bg(a) {
      this.H(a, !1);
    }
    M() {
      return super.M();
    }
    J(a) {
      this.M() !== a && this.xh(a);
    }
    xh(a) {
      super.J.call(this, a);
      var b = this.context;
      b && b.activeTexture(a);
    }
    Bb() {
      this.J(33984);
    }
    G(a, b) {
      if (AS(this, a) !== b) {
        super.G(a, b);
        var c = this.context;
        c && c.pixelStorei(a, b);
      }
    }
    K(a) {
      switch (a) {
        case 3317:
        case 3333:
          this.G(a, 4);
          break;
        case 37440:
        case 37441:
          this.G(a, 0);
          break;
        default:
          this.G(a, 37444);
      }
    }
    Sa(a, b) {
      if (ES(this) !== b) {
        super.Sa(a, b);
        var c = this.context;
        c && c.hint(a, b);
      }
    }
    nh(a) {
      this.Sa(a, 4352);
    }
  };
  function iK(a, b) {
    a = a.cache;
    (b = a.entries[b]) &&
      b.A &&
      ((b.A.next = b.next) ? (b.next.A = b.A) : (a.tail = b.A),
      (b.A = null),
      (b.next = a.head),
      (a.head.A = b),
      (a.head = b));
  }
  function oI(a, b, c) {
    return a.cache.add(null, b, c, void 0);
  }
  function nO(a, b, c) {
    return a.cache.add(b, a.P, c, 1);
  }
  function SS(a, b, c, d) {
    var e = a.cache.entries[c];
    a.F += e && e.B;
    c = a.cache.entries[c];
    a.G += c && c.C;
    b.push(d);
    (a.F >= a.O || a.G >= a.V) && TS(a);
  }
  function US(a) {
    var b = (0.75 * a.H + 0.25 * a.N) * 100;
    b = Math.max(96e6, b);
    var c = Math.max(200, a.H * 0.002);
    a.O = b * 0.1;
    a.V = c * 0.1;
    a = a.cache;
    a.B[0] = b !== void 0 ? b : a.B[0];
    a.B[1] = c !== void 0 ? c : a.B[1];
    YH(a);
  }
  function TS(a) {
    for (var b = 0; b < a.A.length; b++) a.context.deleteBuffer(a.A[b]);
    for (b = 0; b < a.C.length; b++) a.context.deleteTexture(a.C[b]);
    for (b = 0; b < a.I.length; b++) a.context.deleteRenderbuffer(a.I[b]);
    a.F = 0;
    a.G = 0;
    a.A.splice(0, a.A.length);
    a.C.splice(0, a.C.length);
    a.I.splice(0, a.I.length);
  }
  var VS = class extends JI {
    constructor(a) {
      super();
      this.context = a;
      this.cache = new $H();
      this.G = this.V = this.F = this.O = this.H = this.N = 0;
      this.A = [];
      this.C = [];
      this.I = [];
      this.P = (b, c) => {
        SS(this, this.C, b, c);
      };
      this.L = (b, c) => {
        SS(this, this.A, b, c);
      };
      US(this);
    }
    J() {
      this.clear();
      TS(this);
      super.J();
    }
    contains(a) {
      return this.cache.contains(a);
    }
    resize(a, b, c) {
      return this.cache.resize(a, b, c);
    }
    clear() {
      this.cache.clear();
    }
    remove(a) {
      this.cache.remove(a);
    }
    getBuffer(a) {
      return this.cache.get(a);
    }
    createTexture(a) {
      var b = this.context,
        c = b.createTexture();
      b.bindTexture(3553, c);
      b.texParameteri(3553, 10241, a);
      b.texParameteri(3553, 10240, a);
      b.texParameteri(3553, 10242, 33071);
      b.texParameteri(3553, 10243, 33071);
      return nO(this, c, 0);
    }
  };
  var WS = class extends Ga {
    constructor(a) {
      super(a);
      this.name = "LostContextError";
    }
  };
  function pI(a, b, c) {
    b === 34962 ? a.C.F(c) : a.C.G(c);
  }
  function hK(a, b) {
    a.state.F(b, !1);
  }
  function kK(a, b) {
    a.state.H(b, !1);
  }
  function XS(a, b) {
    switch (b) {
      case 32873:
        break;
      case 34068:
        break;
      case 35725:
        break;
      default:
        if (a.ca.getParameter(b) === null && a.isContextLost())
          throw new WS("getParameter");
    }
  }
  function jK(a) {
    var b =
        (a.ca.drawingBufferWidth || a.canvas.A.width) *
        (a.ca.drawingBufferHeight || a.canvas.A.height),
      c = a.canvas.C;
    a = a.A;
    c = b / (c * c);
    if (b !== a.N || c !== a.H) (a.N = b), (a.H = c), US(a);
  }
  function jO(a, b) {
    var c = a.state.M() - 33984;
    b === 3553
      ? ((a = a.C.yc[c]), a.target !== 3553 && (a.target = 3553))
      : ((a = a.C.zc[c]),
        a.target !== 34067 && (a.target = 34067),
        b !== 34067 && (a.D = b));
    return a;
  }
  function YS(a) {
    if (a.D !== void 0) return !!a.D;
    if (nb("Chromium") <= 29) {
      var b = a.ca.getSupportedExtensions();
      if (!b && a.isContextLost()) throw new WS("getSupportedExtensions");
      for (let c = 0; c < b.length; c++)
        for (let d = 0; d < ZS.length; d++)
          if (b[c] === ZS[d] && ((a.D = a.ca.getExtension(ZS[d])), a.D))
            return !0;
    } else
      for (b = 0; b < ZS.length; b++)
        if (((a.D = a.ca.getExtension(ZS[b])), a.D)) return !0;
    a.D = null;
    return !1;
  }
  function $S(a) {
    a.A.clear();
    a.Dc = null;
    a.C.clear();
    a.state.clear();
  }
  var bT = class extends Su {
      constructor(a, b) {
        super();
        this.canvas = a;
        this.ca = b;
        this.id = aT++;
        this.Dc = null;
        this.antialias = this.I = this.G = this.F = this.H = this.D = void 0;
        this.state = new RS(this.ca);
        this.C = new jS(this.ca, this.state);
        this.L = new NI(this);
        qu(this, Ca(ou, this.L));
        this.A = new VS(this);
        qu(this, Ca(ou, this.A));
        XS(this, 3379);
        XS(this, 34076);
        PI(this.L, a, "webglcontextlost", this.P, !1, this);
        PI(this.L, a, "webglcontextrestored", this.T, !1, this);
        jK(this);
      }
      va() {
        return this.id;
      }
      B() {
        this.Dc = null;
        this.ca.useProgram(null);
        super.B();
      }
      O() {
        return this.canvas;
      }
      blendEquation(a) {
        this.state.aa(a);
      }
      clearColor(a, b, c, d) {
        this.state.V(a, b, c, d);
      }
      depthFunc(a) {
        this.state.P(a);
      }
      frontFace(a) {
        this.state.ga(a);
      }
      lineWidth(a) {
        this.state.T(a);
      }
      polygonOffset(a, b) {
        this.state.W(a, b);
      }
      bindTexture(a, b) {
        var c = this.state.M() - 33984;
        b && (b.target !== a && (b.target = a), b.A !== c && (b.A = c));
        a === 3553 ? this.C.dd(c, b) : this.C.ed(c, b);
      }
      isContextLost() {
        return this.ca.isContextLost();
      }
      clear(a) {
        this.ca.clear(a);
      }
      createTexture() {
        return new iS(this.ca, this.state, this.C);
      }
      deleteBuffer(a) {
        this.ca.deleteBuffer(a);
      }
      deleteRenderbuffer(a) {
        this.ca.deleteRenderbuffer(a);
      }
      deleteTexture(a) {
        a && a.deleteTexture();
      }
      flush() {
        this.ca.flush();
      }
      texParameteri(a, b, c) {
        a = jO(this, a);
        switch (b) {
          case 10241:
            a.G !== c &&
              (a.bind(), a.B.texParameteri(a.target, 10241, c), (a.G = c));
            break;
          case 10240:
            a.F !== c &&
              (a.bind(), a.B.texParameteri(a.target, 10240, c), (a.F = c));
            break;
          case 10242:
            a.H !== c &&
              (a.bind(), a.B.texParameteri(a.target, 10242, c), (a.H = c));
            break;
          case 10243:
            a.J !== c &&
              (a.bind(), a.B.texParameteri(a.target, 10243, c), (a.J = c));
        }
      }
      P(a) {
        a.preventDefault();
        $S(this);
        Date.now();
        super.dispatchEvent("webglcontextlost");
      }
      T() {
        $S(this);
        if (this.D && ((this.D = void 0), !YS(this)))
          throw Error("Lost compressed textures extension.");
        if (this.H) {
          this.H = void 0;
          if (this.H !== void 0) var a = !!this.H;
          else {
            if ((a = this.ca.getExtension("OES_texture_float"))) {
              let b = this.ca.getExtension("OES_texture_float_linear"),
                c = this.ca.getExtension("WEBGL_color_buffer_float");
              if (b == null || c == null) a = null;
            }
            this.H = a;
            a = !!a;
          }
          if (!a) throw Error("Lost texture float extension.");
        }
        if (
          this.F &&
          ((this.F = void 0),
          this.F === void 0 &&
            (this.F = this.ca.getExtension("WEBGL_depth_texture")),
          !this.F)
        )
          throw Error("Lost depth texture extension.");
        this.G !== void 0 &&
          ((this.G = void 0),
          this.G === void 0 &&
            ((w("Windows") && nb("Chromium") <= 29) ||
            (w("Windows") && nb("Firefox") <= 26)
              ? (this.G = null)
              : (this.G = this.ca.getExtension("ANGLE_instanced_arrays"))));
        this.I !== void 0 &&
          ((this.I = void 0),
          this.I === void 0 &&
            (this.I = this.ca.getExtension("OES_vertex_array_object")));
        Date.now();
        super.dispatchEvent("webglcontextrestored");
      }
    },
    aT = 0,
    ZS = [
      "WEBGL_compressed_texture_s3tc",
      "WEBKIT_WEBGL_compressed_texture_s3tc",
      "MOZ_WEBGL_compressed_texture_s3tc",
    ];
  function cT(a, b) {
    b = dT(a.A, b);
    return new bT(a, b);
  }
  var eT = class extends Error {};
  function dT(a, b = new OK()) {
    a = RK(a, b);
    if (!a)
      throw (
        ((a = PK),
        new eT(`Could not find a 3d context, error: ${a}`, { cause: a }))
      );
    return a;
  }
  function fT(a, b) {
    a.B ||
      ((a.D = !0),
      (b = b.target),
      Nm(U),
      (a.C = new SP(
        jj(b).Ba(),
        jj(b).za() - 90,
        1 - Math.log(Math.tan(Bo(b.Ga()) / 2) / a.J) / Math.log(2)
      )),
      a.Z(),
      (a.D = !1));
  }
  function gT(a, b) {
    if (!a.B) {
      var c = b.target;
      Nm(UA);
      c.Y().jb() &&
        ((b = c.Y().ha().va()),
        (c = c.Y().ha().Oa()),
        (b = $P(b, c)),
        b !== a.G && ((a.D = !0), (a.F = b), a.ua(), (a.G = b), (a.D = !1)));
    }
  }
  var hT = class {
    constructor(a, b, c, d, e, f, g, h, k, l, m, n = !1) {
      this.V = c;
      this.F = this.G = "";
      this.H = {};
      this.B = this.D = !1;
      this.M = n;
      this.Z = d;
      this.ua = e;
      var q = document.createElement("div");
      this.K = q;
      a.appendChild(q);
      q.style.height = q.style.width = "100%";
      this.O = c = document.createElement("canvas");
      this.P = a;
      this.Ca = k;
      this.aa = l;
      this.I = m;
      a = new NK(c);
      l = k = null;
      if (f !== "html5" && f !== "html4")
        try {
          if (f === "webgl") k = cT(a);
          else if (f === "webgl_debug") {
            var r = new OK();
            r.preserveDrawingBuffer = !0;
            r.A = !0;
            k = cT(a, r);
          }
        } catch (v) {
          c.parentElement && c.parentElement.removeChild(c),
            (k = null),
            (c = this.O = document.createElement("canvas")),
            (a = new NK(c));
        }
      this.N = !!k;
      h && h(this.N);
      k || f === "html4" || (l = c.getContext("2d"));
      f = new eS(q, a, new pR(k, l, q), { fc: this.V, role: "region" });
      this.W = h = new us();
      b = new Yr(b);
      r = new Set();
      for (a = 0; a < hf(b, 9, Ld, 3, !0).length; ++a) r.add(Hf(b, 9, a));
      var t = E(b, 45) === "origin";
      this.T = () => {
        if (t) var v = window.location.origin;
        else
          (v = Vo(
            So(
              ep(
                (u.document?.location && u.document?.location.href) ||
                  u.location?.href
              ),
              ""
            ),
            ""
          )),
            (v = Uo(v, "").toString());
        return v;
      };
      a = B(b, Xr, 25);
      k = E(a, 9);
      l = r.has(43) ? "maps_sv.tactile_lite" : "apiv3";
      Q(h.A, 7, l);
      k = k.replace("http:", "https:");
      if (this.M) {
        if (
          ((k = k.replace(
            "/maps/api/js/GeoPhotoService.GetMetadata",
            "/$rpc/google.internal.maps.mapsjs.v1.MapsJsInternalService/GetMetadata"
          )),
          (m = E(b, 17)))
        )
          h.C = m;
      } else M(h.A, 6, !0);
      ns(h, k);
      os(h, E(a, 12) + "?cb_client=" + l);
      k = hf(a, 11, ee, 3, !0).length;
      for (l = 0; l < k; ++l) ps(h, Gf(a, 11, l));
      M(h.A, 9, !0);
      qs(h);
      rs(h, Ur(B(b, Wr, 3)));
      ss(h, Vr(B(b, Wr, 3)));
      ts(h, r.has(56));
      ct();
      this.A = RP(h, f, this.M, this.T);
      g &&
        this.A.We(() => {
          g();
        });
      this.sa = b = new NI();
      b.listen(this.A, "CameraChanged", (v) => {
        fT(this, v);
      });
      b.listen(this.A, "PhotoChanged", (v) => {
        gT(this, v);
      });
      b.listen(this.A, "UserInput", (v) => {
        this.I && this.I(v.target.inputType);
      });
      "touchstart touchmove touchend mousedown mousemove mouseup pointerdown pointermove pointerup MSPointerDown MSPointerMove MSPointerUp click"
        .split(" ")
        .forEach((v) => {
          if (q.addEventListener) {
            let F = { capture: !1 };
            UP.has(v) && (F.passive = !1);
            q.addEventListener(v, TP, F);
          }
          new XP(q, v);
        });
      this.C = new SP(0, 0, 0);
      this.J = c.height / c.width;
    }
    L() {
      if (!this.D) {
        var a = new OO(),
          b = a.ja(),
          c = !1,
          d = this.F;
        if (d && this.G !== this.F) {
          this.H[d] &&
            (R(a, 3, 3),
            $i(ij(b), this.H[d].lat),
            Yi(ij(b), this.H[d].lng),
            bj(ij(b), 3));
          c = EB(DB(A(a, HB, 1), 1));
          let e = ZP(d);
          Pi(yl(QA(c)), e.va());
          Oi(yl(QA(c)), e.Oa());
          c = !0;
          this.G = d;
        }
        this.C &&
          (P(b, 4, Co(Math.atan(Math.pow(2, 1 - this.C.zoom) * this.J) * 2)),
          kj(b)
            .nb(this.C.heading)
            .ab(this.C.pitch + 90),
          (c = !0));
        c
          ? this.A.view(a, () => {
              this.Ca();
            })
          : this.aa();
      }
      this.B = !1;
    }
    setSize(a, b) {
      this.A.setSize(a, b);
      this.J = b / a;
    }
    ea() {
      var a = this.O,
        b = document.createElement("div");
      b.innerText = "For development purposes only";
      b.style.cssText =
        "position:absolute;pointer-events:none;transform:translate(-50%,-50%);z-index:1000;top:50%;color:white;font-size:20px;left:50%;background-color:rgba(0,0,0,0.3);padding:5px;border-radius:3px;text-align:center;";
      this.P.insertBefore(b, this.P.firstChild);
      a.style.filter = "invert(1)";
      a.style.filter || (a.style.opacity = "0.2");
      setInterval(() => {
        var c = getComputedStyle(a);
        c.filter.indexOf("invert(1)") < 0 &&
          c.opacity !== "0.2" &&
          a.parentElement &&
          a.parentElement.removeChild(a);
      }, 3e3);
    }
    vd(a) {
      this.A.vd(a);
    }
    focus() {
      this.A.focus();
    }
    me(a) {
      this.A.me(a);
    }
    ga(a) {
      this.A.jf(a);
      this.A.enableZoom(a);
    }
    Na(a, b) {
      if (this.N && a && !b) {
        var c = document.createElement("canvas"),
          d = c.getContext("2d");
        this.K.textContent = "";
        c = new eS(this.K, new NK(c), new pR(null, d, this.K), {
          fc: this.V,
          role: "region",
        });
        d = this.sa;
        QI(d);
        this.A = RP(this.W, c, this.M, this.T);
        d.listen(this.A, "CameraChanged", (e) => {
          fT(this, e);
        });
        d.listen(this.A, "PhotoChanged", (e) => {
          gT(this, e);
        });
        d.listen(this.A, "UserInput", (e) => {
          this.I && this.I(e.target.inputType);
        });
        this.N = !1;
        this.L();
      }
      HP(
        {
          Vg: (e) => {
            if (!a) return null;
            var f = a(e);
            if (f) {
              var g = f.tiles.worldSize.width;
              let m = f.tiles.worldSize.height;
              var h = g,
                k = m;
              f.tiles.imageSize &&
                ((h = f.tiles.imageSize.width), (k = f.tiles.imageSize.height));
              let n = 0,
                q = 0;
              f.tiles.imagePosition &&
                ((n = f.tiles.imagePosition.x), (q = f.tiles.imagePosition.y));
              let r = f.tiles.tileSize.width,
                t = f.tiles.tileSize.height,
                v = new Hl();
              Pi(yl(v), e);
              Oi(yl(v), 2);
              var l = Al(v);
              Q(l, 10, e);
              e = Al(v);
              R(e, 1, 2);
              e = Al(v);
              R(e, 2, 2);
              kl(ql(Al(v))).A(t);
              kl(ql(Al(v))).B(r);
              ol(Al(v)).A(k);
              ol(Al(v)).B(h);
              cl(rl(Al(v))).A(m);
              cl(rl(Al(v))).B(g);
              dl(rl(Al(v))).B(n);
              dl(rl(Al(v))).A(q);
              for (g = [{ width: h, height: k }]; h > r || k > t; )
                (h = (h + 1) >> 1),
                  (k = (k + 1) >> 1),
                  g.push({ width: h, height: k });
              for (h = g.length - 1; h >= 0; --h)
                (k = ql(Al(v))),
                  (k = Bf(k, 1, hl)),
                  A(k, Bj, 1).B(g[h].width).A(g[h].height);
              k = Bf(v, 6, al);
              h = A(k, tk, 1);
              R(h, 1, 1);
              h = A(k, Nj, 2);
              A(h, Kj, 3)
                .nb(f.tiles.centerHeading)
                .ab(f.tiles.Wi || 90)
                .wc(f.tiles.Vi || 0);
              f = v;
            } else f = null;
            return f;
          },
          yi: function (e, f, g, h) {
            return a(e).tiles.getTileUrl(e, f, g, h);
          },
        },
        !!b
      );
    }
    Da() {
      return this.C;
    }
    Bb(a) {
      this.C = a;
      this.B || (Up(this.L, this), (this.B = !0));
    }
    na() {
      return this.F;
    }
    ib(a) {
      this.F = a;
      this.B || (Up(this.L, this), (this.B = !0));
    }
    Sa(a) {
      this.H = a;
    }
  };
  hT.prototype.setSize = hT.prototype.setSize;
  hT.prototype.dV = hT.prototype.ea;
  hT.prototype.enableClickToGo = hT.prototype.vd;
  hT.prototype.focus = hT.prototype.focus;
  hT.prototype.showRoadLabels = hT.prototype.me;
  hT.prototype.enableScrollToZoom = hT.prototype.ga;
  hT.prototype.registerPanoProvider = hT.prototype.Na;
  hT.prototype.getPov = hT.prototype.Da;
  hT.prototype.setPov = hT.prototype.Bb;
  hT.prototype.getPano = hT.prototype.na;
  hT.prototype.setPano = hT.prototype.ib;
  hT.prototype.setNeighborLocation = hT.prototype.Sa;
  ia(
    "google.maps.internal.iv",
    function (a, b, c, d, e, f, g, h, k, l, m, n = !1) {
      return new hT(a, b, c, d, e, f, g, h, k, l, m, n);
    }
  );
}.call(this));
google.maps.__gjsload__("imagery_viewer", function (_) {
  var Cta = class {},
    EA = window.google;
  Cta.prototype.PO = EA.maps.internal && EA.maps.internal.iv;
  delete EA.maps.internal;
  _.ek("imagery_viewer", new Cta());
});
