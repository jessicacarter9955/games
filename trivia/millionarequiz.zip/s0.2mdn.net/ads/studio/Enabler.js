(function () {
  var DEPS_GRAPH = {
    enablermodule: [],
    configurablemodule: ["enablermodule"],
    gdnmodule: ["enablermodule"],
    layoutsmodule: ["enablermodule"],
    videomodule: ["enablermodule"],
    layoutsfillermodule: ["enablermodule", "layoutsmodule"],
    rad_ui_videomodule: ["videomodule"],
    $weak$: [
      "configurablemodule",
      "enablermodule",
      "gdnmodule",
      "layoutsfillermodule",
      "layoutsmodule",
      "rad_ui_videomodule",
      "videomodule",
    ],
  };
  window.STUDIO_SDK_START = +new Date();
  var h,
    aa = function (a) {
      var b = 0;
      return function () {
        return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
      };
    },
    ba =
      typeof Object.defineProperties == "function"
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          },
    ca = function (a) {
      a = [
        "object" == typeof globalThis && globalThis,
        a,
        "object" == typeof window && window,
        "object" == typeof self && self,
        "object" == typeof global && global,
      ];
      for (var b = 0; b < a.length; ++b) {
        var c = a[b];
        if (c && c.Math == Math) return c;
      }
      throw Error("Cannot find global object");
    },
    da = ca(this),
    l = function (a, b) {
      if (b)
        a: {
          var c = da;
          a = a.split(".");
          for (var d = 0; d < a.length - 1; d++) {
            var e = a[d];
            if (!(e in c)) break a;
            c = c[e];
          }
          a = a[a.length - 1];
          d = c[a];
          b = b(d);
          b != d &&
            b != null &&
            ba(c, a, { configurable: !0, writable: !0, value: b });
        }
    };
  l("Symbol", function (a) {
    if (a) return a;
    var b = function (f, g) {
      this.g = f;
      ba(this, "description", { configurable: !0, writable: !0, value: g });
    };
    b.prototype.toString = function () {
      return this.g;
    };
    var c = "jscomp_symbol_" + ((Math.random() * 1e9) >>> 0) + "_",
      d = 0,
      e = function (f) {
        if (this instanceof e)
          throw new TypeError("Symbol is not a constructor");
        return new b(c + (f || "") + "_" + d++, f);
      };
    return e;
  });
  l("Symbol.iterator", function (a) {
    if (a) return a;
    a = Symbol("Symbol.iterator");
    for (
      var b =
          "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(
            " "
          ),
        c = 0;
      c < b.length;
      c++
    ) {
      var d = da[b[c]];
      typeof d === "function" &&
        typeof d.prototype[a] != "function" &&
        ba(d.prototype, a, {
          configurable: !0,
          writable: !0,
          value: function () {
            return ea(aa(this));
          },
        });
    }
    return a;
  });
  var ea = function (a) {
      a = { next: a };
      a[Symbol.iterator] = function () {
        return this;
      };
      return a;
    },
    fa =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            var b = function () {};
            b.prototype = a;
            return new b();
          },
    ha;
  if (typeof Object.setPrototypeOf == "function") ha = Object.setPrototypeOf;
  else {
    var ia;
    a: {
      var ja = { a: !0 },
        ka = {};
      try {
        ka.__proto__ = ja;
        ia = ka.a;
        break a;
      } catch (a) {}
      ia = !1;
    }
    ha = ia
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var la = ha,
    n = function (a, b) {
      a.prototype = fa(b.prototype);
      a.prototype.constructor = a;
      if (la) la(a, b);
      else
        for (var c in b)
          if (c != "prototype")
            if (Object.defineProperties) {
              var d = Object.getOwnPropertyDescriptor(b, c);
              d && Object.defineProperty(a, c, d);
            } else a[c] = b[c];
      a.R = b.prototype;
    },
    ma = function (a) {
      var b =
        typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
      if (b) return b.call(a);
      if (typeof a.length == "number") return { next: aa(a) };
      throw Error(String(a) + " is not an iterable or ArrayLike");
    },
    na = function (a) {
      if (!(a instanceof Array)) {
        a = ma(a);
        for (var b, c = []; !(b = a.next()).done; ) c.push(b.value);
        a = c;
      }
      return a;
    },
    pa = function (a) {
      return oa(a, a);
    },
    oa = function (a, b) {
      a.raw = b;
      Object.freeze && (Object.freeze(a), Object.freeze(b));
      return a;
    },
    ra = function (a, b) {
      return Object.prototype.hasOwnProperty.call(a, b);
    },
    sa =
      typeof Object.assign == "function"
        ? Object.assign
        : function (a, b) {
            if (a == null) throw new TypeError("No nullish arg");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
              var d = arguments[c];
              if (d) for (var e in d) ra(d, e) && (a[e] = d[e]);
            }
            return a;
          };
  l("Object.assign", function (a) {
    return a || sa;
  });
  var ua = function () {
      this.v = !1;
      this.h = null;
      this.o = void 0;
      this.g = 1;
      this.B = this.l = 0;
      this.j = null;
    },
    va = function (a) {
      if (a.v) throw new TypeError("Generator is already running");
      a.v = !0;
    };
  ua.prototype.A = function (a) {
    this.o = a;
  };
  var wa = function (a, b) {
    a.j = { yc: b, He: !0 };
    a.g = a.l || a.B;
  };
  ua.prototype.return = function (a) {
    this.j = { return: a };
    this.g = this.B;
  };
  var xa = function (a, b, c) {
      a.g = c;
      return { value: b };
    },
    ya = function (a) {
      a.l = 0;
      var b = a.j.yc;
      a.j = null;
      return b;
    },
    za = function (a) {
      this.g = new ua();
      this.h = a;
    },
    Ca = function (a, b) {
      va(a.g);
      var c = a.g.h;
      if (c)
        return Aa(
          a,
          "return" in c
            ? c["return"]
            : function (d) {
                return { value: d, done: !0 };
              },
          b,
          a.g.return
        );
      a.g.return(b);
      return Ba(a);
    },
    Aa = function (a, b, c, d) {
      try {
        var e = b.call(a.g.h, c);
        if (!(e instanceof Object))
          throw new TypeError("Iterator result " + e + " is not an object");
        if (!e.done) return (a.g.v = !1), e;
        var f = e.value;
      } catch (g) {
        return (a.g.h = null), wa(a.g, g), Ba(a);
      }
      a.g.h = null;
      d.call(a.g, f);
      return Ba(a);
    },
    Ba = function (a) {
      for (; a.g.g; )
        try {
          var b = a.h(a.g);
          if (b) return (a.g.v = !1), { value: b.value, done: !1 };
        } catch (c) {
          (a.g.o = void 0), wa(a.g, c);
        }
      a.g.v = !1;
      if (a.g.j) {
        b = a.g.j;
        a.g.j = null;
        if (b.He) throw b.yc;
        return { value: b.return, done: !0 };
      }
      return { value: void 0, done: !0 };
    },
    Da = function (a) {
      this.next = function (b) {
        va(a.g);
        a.g.h ? (b = Aa(a, a.g.h.next, b, a.g.A)) : (a.g.A(b), (b = Ba(a)));
        return b;
      };
      this.throw = function (b) {
        va(a.g);
        a.g.h
          ? (b = Aa(a, a.g.h["throw"], b, a.g.A))
          : (wa(a.g, b), (b = Ba(a)));
        return b;
      };
      this.return = function (b) {
        return Ca(a, b);
      };
      this[Symbol.iterator] = function () {
        return this;
      };
    },
    Ea = function (a) {
      function b(d) {
        return a.next(d);
      }
      function c(d) {
        return a.throw(d);
      }
      return new Promise(function (d, e) {
        function f(g) {
          g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e);
        }
        f(a.next());
      });
    },
    Fa = function (a) {
      return Ea(new Da(new za(a)));
    },
    Ga = function () {
      for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
        b[c - a] = arguments[c];
      return b;
    };
  l("globalThis", function (a) {
    return a || da;
  });
  l("Reflect.setPrototypeOf", function (a) {
    return a
      ? a
      : la
      ? function (b, c) {
          try {
            return la(b, c), !0;
          } catch (d) {
            return !1;
          }
        }
      : null;
  });
  l("Promise", function (a) {
    function b() {
      this.g = null;
    }
    function c(g) {
      return g instanceof e
        ? g
        : new e(function (k) {
            k(g);
          });
    }
    if (a) return a;
    b.prototype.h = function (g) {
      if (this.g == null) {
        this.g = [];
        var k = this;
        this.j(function () {
          k.v();
        });
      }
      this.g.push(g);
    };
    var d = da.setTimeout;
    b.prototype.j = function (g) {
      d(g, 0);
    };
    b.prototype.v = function () {
      for (; this.g && this.g.length; ) {
        var g = this.g;
        this.g = [];
        for (var k = 0; k < g.length; ++k) {
          var m = g[k];
          g[k] = null;
          try {
            m();
          } catch (p) {
            this.l(p);
          }
        }
      }
      this.g = null;
    };
    b.prototype.l = function (g) {
      this.j(function () {
        throw g;
      });
    };
    var e = function (g) {
      this.g = 0;
      this.j = void 0;
      this.h = [];
      this.A = !1;
      var k = this.l();
      try {
        g(k.resolve, k.reject);
      } catch (m) {
        k.reject(m);
      }
    };
    e.prototype.l = function () {
      function g(p) {
        return function (t) {
          m || ((m = !0), p.call(k, t));
        };
      }
      var k = this,
        m = !1;
      return { resolve: g(this.ga), reject: g(this.v) };
    };
    e.prototype.ga = function (g) {
      if (g === this)
        this.v(new TypeError("A Promise cannot resolve to itself"));
      else if (g instanceof e) this.J(g);
      else {
        a: switch (typeof g) {
          case "object":
            var k = g != null;
            break a;
          case "function":
            k = !0;
            break a;
          default:
            k = !1;
        }
        k ? this.Z(g) : this.o(g);
      }
    };
    e.prototype.Z = function (g) {
      var k = void 0;
      try {
        k = g.then;
      } catch (m) {
        this.v(m);
        return;
      }
      typeof k == "function" ? this.I(k, g) : this.o(g);
    };
    e.prototype.v = function (g) {
      this.B(2, g);
    };
    e.prototype.o = function (g) {
      this.B(1, g);
    };
    e.prototype.B = function (g, k) {
      if (this.g != 0)
        throw Error(
          "Cannot settle(" +
            g +
            ", " +
            k +
            "): Promise already settled in state" +
            this.g
        );
      this.g = g;
      this.j = k;
      this.g === 2 && this.G();
      this.C();
    };
    e.prototype.G = function () {
      var g = this;
      d(function () {
        if (g.F()) {
          var k = da.console;
          typeof k !== "undefined" && k.error(g.j);
        }
      }, 1);
    };
    e.prototype.F = function () {
      if (this.A) return !1;
      var g = da.CustomEvent,
        k = da.Event,
        m = da.dispatchEvent;
      if (typeof m === "undefined") return !0;
      typeof g === "function"
        ? (g = new g("unhandledrejection", { cancelable: !0 }))
        : typeof k === "function"
        ? (g = new k("unhandledrejection", { cancelable: !0 }))
        : ((g = da.document.createEvent("CustomEvent")),
          g.initCustomEvent("unhandledrejection", !1, !0, g));
      g.promise = this;
      g.reason = this.j;
      return m(g);
    };
    e.prototype.C = function () {
      if (this.h != null) {
        for (var g = 0; g < this.h.length; ++g) f.h(this.h[g]);
        this.h = null;
      }
    };
    var f = new b();
    e.prototype.J = function (g) {
      var k = this.l();
      g.qb(k.resolve, k.reject);
    };
    e.prototype.I = function (g, k) {
      var m = this.l();
      try {
        g.call(k, m.resolve, m.reject);
      } catch (p) {
        m.reject(p);
      }
    };
    e.prototype.then = function (g, k) {
      function m(w, E) {
        return typeof w == "function"
          ? function (qa) {
              try {
                p(w(qa));
              } catch (ta) {
                t(ta);
              }
            }
          : E;
      }
      var p,
        t,
        u = new e(function (w, E) {
          p = w;
          t = E;
        });
      this.qb(m(g, p), m(k, t));
      return u;
    };
    e.prototype.catch = function (g) {
      return this.then(void 0, g);
    };
    e.prototype.qb = function (g, k) {
      function m() {
        switch (p.g) {
          case 1:
            g(p.j);
            break;
          case 2:
            k(p.j);
            break;
          default:
            throw Error("Unexpected state: " + p.g);
        }
      }
      var p = this;
      this.h == null ? f.h(m) : this.h.push(m);
      this.A = !0;
    };
    e.resolve = c;
    e.reject = function (g) {
      return new e(function (k, m) {
        m(g);
      });
    };
    e.race = function (g) {
      return new e(function (k, m) {
        for (var p = ma(g), t = p.next(); !t.done; t = p.next())
          c(t.value).qb(k, m);
      });
    };
    e.all = function (g) {
      var k = ma(g),
        m = k.next();
      return m.done
        ? c([])
        : new e(function (p, t) {
            function u(qa) {
              return function (ta) {
                w[qa] = ta;
                E--;
                E == 0 && p(w);
              };
            }
            var w = [],
              E = 0;
            do
              w.push(void 0),
                E++,
                c(m.value).qb(u(w.length - 1), t),
                (m = k.next());
            while (!m.done);
          });
    };
    return e;
  });
  l("Object.setPrototypeOf", function (a) {
    return a || la;
  });
  l("Symbol.dispose", function (a) {
    return a ? a : Symbol("Symbol.dispose");
  });
  var Ha = function (a, b, c) {
    a instanceof String && (a = String(a));
    for (var d = a.length, e = 0; e < d; e++) {
      var f = a[e];
      if (b.call(c, f, e, a)) return { Nc: e, vd: f };
    }
    return { Nc: -1, vd: void 0 };
  };
  l("Array.prototype.find", function (a) {
    return a
      ? a
      : function (b, c) {
          return Ha(this, b, c).vd;
        };
  });
  l("WeakMap", function (a) {
    function b() {}
    function c(m) {
      var p = typeof m;
      return (p === "object" && m !== null) || p === "function";
    }
    function d(m) {
      if (!ra(m, f)) {
        var p = new b();
        ba(m, f, { value: p });
      }
    }
    function e(m) {
      var p = Object[m];
      p &&
        (Object[m] = function (t) {
          if (t instanceof b) return t;
          Object.isExtensible(t) && d(t);
          return p(t);
        });
    }
    if (
      (function () {
        if (!a || !Object.seal) return !1;
        try {
          var m = Object.seal({}),
            p = Object.seal({}),
            t = new a([
              [m, 2],
              [p, 3],
            ]);
          if (t.get(m) != 2 || t.get(p) != 3) return !1;
          t.delete(m);
          t.set(p, 4);
          return !t.has(m) && t.get(p) == 4;
        } catch (u) {
          return !1;
        }
      })()
    )
      return a;
    var f = "$jscomp_hidden_" + Math.random();
    e("freeze");
    e("preventExtensions");
    e("seal");
    var g = 0,
      k = function (m) {
        this.g = (g += Math.random() + 1).toString();
        if (m) {
          m = ma(m);
          for (var p; !(p = m.next()).done; )
            (p = p.value), this.set(p[0], p[1]);
        }
      };
    k.prototype.set = function (m, p) {
      if (!c(m)) throw Error("Invalid WeakMap key");
      d(m);
      if (!ra(m, f)) throw Error("WeakMap key fail: " + m);
      m[f][this.g] = p;
      return this;
    };
    k.prototype.get = function (m) {
      return c(m) && ra(m, f) ? m[f][this.g] : void 0;
    };
    k.prototype.has = function (m) {
      return c(m) && ra(m, f) && ra(m[f], this.g);
    };
    k.prototype.delete = function (m) {
      return c(m) && ra(m, f) && ra(m[f], this.g) ? delete m[f][this.g] : !1;
    };
    return k;
  });
  l("Map", function (a) {
    if (
      (function () {
        if (
          !a ||
          typeof a != "function" ||
          !a.prototype.entries ||
          typeof Object.seal != "function"
        )
          return !1;
        try {
          var k = Object.seal({ x: 4 }),
            m = new a(ma([[k, "s"]]));
          if (
            m.get(k) != "s" ||
            m.size != 1 ||
            m.get({ x: 4 }) ||
            m.set({ x: 4 }, "t") != m ||
            m.size != 2
          )
            return !1;
          var p = m.entries(),
            t = p.next();
          if (t.done || t.value[0] != k || t.value[1] != "s") return !1;
          t = p.next();
          return t.done ||
            t.value[0].x != 4 ||
            t.value[1] != "t" ||
            !p.next().done
            ? !1
            : !0;
        } catch (u) {
          return !1;
        }
      })()
    )
      return a;
    var b = new WeakMap(),
      c = function (k) {
        this[0] = {};
        this[1] = f();
        this.size = 0;
        if (k) {
          k = ma(k);
          for (var m; !(m = k.next()).done; )
            (m = m.value), this.set(m[0], m[1]);
        }
      };
    c.prototype.set = function (k, m) {
      k = k === 0 ? 0 : k;
      var p = d(this, k);
      p.list || (p.list = this[0][p.id] = []);
      p.entry
        ? (p.entry.value = m)
        : ((p.entry = {
            next: this[1],
            ra: this[1].ra,
            head: this[1],
            key: k,
            value: m,
          }),
          p.list.push(p.entry),
          (this[1].ra.next = p.entry),
          (this[1].ra = p.entry),
          this.size++);
      return this;
    };
    c.prototype.delete = function (k) {
      k = d(this, k);
      return k.entry && k.list
        ? (k.list.splice(k.index, 1),
          k.list.length || delete this[0][k.id],
          (k.entry.ra.next = k.entry.next),
          (k.entry.next.ra = k.entry.ra),
          (k.entry.head = null),
          this.size--,
          !0)
        : !1;
    };
    c.prototype.clear = function () {
      this[0] = {};
      this[1] = this[1].ra = f();
      this.size = 0;
    };
    c.prototype.has = function (k) {
      return !!d(this, k).entry;
    };
    c.prototype.get = function (k) {
      return (k = d(this, k).entry) && k.value;
    };
    c.prototype.entries = function () {
      return e(this, function (k) {
        return [k.key, k.value];
      });
    };
    c.prototype.keys = function () {
      return e(this, function (k) {
        return k.key;
      });
    };
    c.prototype.values = function () {
      return e(this, function (k) {
        return k.value;
      });
    };
    c.prototype.forEach = function (k, m) {
      for (var p = this.entries(), t; !(t = p.next()).done; )
        (t = t.value), k.call(m, t[1], t[0], this);
    };
    c.prototype[Symbol.iterator] = c.prototype.entries;
    var d = function (k, m) {
        var p = m && typeof m;
        p == "object" || p == "function"
          ? b.has(m)
            ? (p = b.get(m))
            : ((p = "" + ++g), b.set(m, p))
          : (p = "p_" + m);
        var t = k[0][p];
        if (t && ra(k[0], p))
          for (k = 0; k < t.length; k++) {
            var u = t[k];
            if ((m !== m && u.key !== u.key) || m === u.key)
              return { id: p, list: t, index: k, entry: u };
          }
        return { id: p, list: t, index: -1, entry: void 0 };
      },
      e = function (k, m) {
        var p = k[1];
        return ea(function () {
          if (p) {
            for (; p.head != k[1]; ) p = p.ra;
            for (; p.next != p.head; )
              return (p = p.next), { done: !1, value: m(p) };
            p = null;
          }
          return { done: !0, value: void 0 };
        });
      },
      f = function () {
        var k = {};
        return (k.ra = k.next = k.head = k);
      },
      g = 0;
    return c;
  });
  l("Set", function (a) {
    if (
      (function () {
        if (
          !a ||
          typeof a != "function" ||
          !a.prototype.entries ||
          typeof Object.seal != "function"
        )
          return !1;
        try {
          var c = Object.seal({ x: 4 }),
            d = new a(ma([c]));
          if (
            !d.has(c) ||
            d.size != 1 ||
            d.add(c) != d ||
            d.size != 1 ||
            d.add({ x: 4 }) != d ||
            d.size != 2
          )
            return !1;
          var e = d.entries(),
            f = e.next();
          if (f.done || f.value[0] != c || f.value[1] != c) return !1;
          f = e.next();
          return f.done ||
            f.value[0] == c ||
            f.value[0].x != 4 ||
            f.value[1] != f.value[0]
            ? !1
            : e.next().done;
        } catch (g) {
          return !1;
        }
      })()
    )
      return a;
    var b = function (c) {
      this.g = new Map();
      if (c) {
        c = ma(c);
        for (var d; !(d = c.next()).done; ) this.add(d.value);
      }
      this.size = this.g.size;
    };
    b.prototype.add = function (c) {
      c = c === 0 ? 0 : c;
      this.g.set(c, c);
      this.size = this.g.size;
      return this;
    };
    b.prototype.delete = function (c) {
      c = this.g.delete(c);
      this.size = this.g.size;
      return c;
    };
    b.prototype.clear = function () {
      this.g.clear();
      this.size = 0;
    };
    b.prototype.has = function (c) {
      return this.g.has(c);
    };
    b.prototype.entries = function () {
      return this.g.entries();
    };
    b.prototype.values = function () {
      return this.g.values();
    };
    b.prototype.keys = b.prototype.values;
    b.prototype[Symbol.iterator] = b.prototype.values;
    b.prototype.forEach = function (c, d) {
      var e = this;
      this.g.forEach(function (f) {
        return c.call(d, f, f, e);
      });
    };
    return b;
  });
  l("Math.log2", function (a) {
    return a
      ? a
      : function (b) {
          return Math.log(b) / Math.LN2;
        };
  });
  l("Object.values", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) ra(b, d) && c.push(b[d]);
          return c;
        };
  });
  l("Object.is", function (a) {
    return a
      ? a
      : function (b, c) {
          return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c;
        };
  });
  l("Array.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = this;
          d instanceof String && (d = String(d));
          var e = d.length;
          c = c || 0;
          for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
            var f = d[c];
            if (f === b || Object.is(f, b)) return !0;
          }
          return !1;
        };
  });
  var Ia = function (a, b, c) {
    if (a == null)
      throw new TypeError(
        "The 'this' value for String.prototype." +
          c +
          " must not be null or undefined"
      );
    if (b instanceof RegExp)
      throw new TypeError(
        "First argument to String.prototype." +
          c +
          " must not be a regular expression"
      );
    return a + "";
  };
  l("String.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          return Ia(this, b, "includes").indexOf(b, c || 0) !== -1;
        };
  });
  l("Array.from", function (a) {
    return a
      ? a
      : function (b, c, d) {
          c =
            c != null
              ? c
              : function (k) {
                  return k;
                };
          var e = [],
            f =
              typeof Symbol != "undefined" &&
              Symbol.iterator &&
              b[Symbol.iterator];
          if (typeof f == "function") {
            b = f.call(b);
            for (var g = 0; !(f = b.next()).done; )
              e.push(c.call(d, f.value, g++));
          } else
            for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
          return e;
        };
  });
  l("Object.entries", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) ra(b, d) && c.push([d, b[d]]);
          return c;
        };
  });
  l("Number.isFinite", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b !== "number"
            ? !1
            : !isNaN(b) && b !== Infinity && b !== -Infinity;
        };
  });
  l("Number.MAX_SAFE_INTEGER", function () {
    return 9007199254740991;
  });
  l("Number.MIN_SAFE_INTEGER", function () {
    return -9007199254740991;
  });
  l("String.prototype.startsWith", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = Ia(this, b, "startsWith");
          b += "";
          var e = d.length,
            f = b.length;
          c = Math.max(0, Math.min(c | 0, d.length));
          for (var g = 0; g < f && c < e; ) if (d[c++] != b[g++]) return !1;
          return g >= f;
        };
  });
  l("String.prototype.endsWith", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = Ia(this, b, "endsWith");
          b += "";
          c === void 0 && (c = d.length);
          c = Math.max(0, Math.min(c | 0, d.length));
          for (var e = b.length; e > 0 && c > 0; )
            if (d[--c] != b[--e]) return !1;
          return e <= 0;
        };
  });
  var Ja = function (a, b) {
    a instanceof String && (a += "");
    var c = 0,
      d = !1,
      e = {
        next: function () {
          if (!d && c < a.length) {
            var f = c++;
            return { value: b(f, a[f]), done: !1 };
          }
          d = !0;
          return { done: !0, value: void 0 };
        },
      };
    e[Symbol.iterator] = function () {
      return e;
    };
    return e;
  };
  l("Array.prototype.entries", function (a) {
    return a
      ? a
      : function () {
          return Ja(this, function (b, c) {
            return [b, c];
          });
        };
  });
  l("Number.isNaN", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b === "number" && isNaN(b);
        };
  });
  l("Array.prototype.keys", function (a) {
    return a
      ? a
      : function () {
          return Ja(this, function (b) {
            return b;
          });
        };
  });
  l("Array.prototype.values", function (a) {
    return a
      ? a
      : function () {
          return Ja(this, function (b, c) {
            return c;
          });
        };
  });
  l("Array.prototype.fill", function (a) {
    return a
      ? a
      : function (b, c, d) {
          var e = this.length || 0;
          c < 0 && (c = Math.max(0, e + c));
          if (d == null || d > e) d = e;
          d = Number(d);
          d < 0 && (d = Math.max(0, e + d));
          for (c = Number(c || 0); c < d; c++) this[c] = b;
          return this;
        };
  });
  var Ka = function (a) {
    return a ? a : Array.prototype.fill;
  };
  l("Int8Array.prototype.fill", Ka);
  l("Uint8Array.prototype.fill", Ka);
  l("Uint8ClampedArray.prototype.fill", Ka);
  l("Int16Array.prototype.fill", Ka);
  l("Uint16Array.prototype.fill", Ka);
  l("Int32Array.prototype.fill", Ka);
  l("Uint32Array.prototype.fill", Ka);
  l("Float32Array.prototype.fill", Ka);
  l("Float64Array.prototype.fill", Ka);
  l("Array.prototype.findIndex", function (a) {
    return a
      ? a
      : function (b, c) {
          return Ha(this, b, c).Nc;
        };
  }); /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var q = this || self,
    r = function (a, b, c) {
      a = a.split(".");
      c = c || q;
      for (var d; a.length && (d = a.shift()); )
        a.length || b === void 0
          ? c[d] && c[d] !== Object.prototype[d]
            ? (c = c[d])
            : (c = c[d] = {})
          : (c[d] = b);
    },
    Ma = function (a, b) {
      var c = La("CLOSURE_FLAGS");
      a = c && c[a];
      return a != null ? a : b;
    },
    La = function (a, b) {
      a = a.split(".");
      b = b || q;
      for (var c = 0; c < a.length; c++)
        if (((b = b[a[c]]), b == null)) return null;
      return b;
    },
    Na = function () {
      throw Error("unimplemented abstract method");
    },
    Oa = function (a) {
      a.Ga = void 0;
      a.tb = function () {
        return a.Ga ? a.Ga : (a.Ga = new a());
      };
    },
    Pa = function (a) {
      var b = typeof a;
      return b != "object" ? b : a ? (Array.isArray(a) ? "array" : b) : "null";
    },
    Qa = function (a) {
      var b = Pa(a);
      return b == "array" || (b == "object" && typeof a.length == "number");
    },
    v = function (a) {
      var b = typeof a;
      return (b == "object" && a != null) || b == "function";
    },
    Ta = function (a) {
      return (
        (Object.prototype.hasOwnProperty.call(a, Ra) && a[Ra]) || (a[Ra] = ++Sa)
      );
    },
    Ra = "closure_uid_" + ((Math.random() * 1e9) >>> 0),
    Sa = 0,
    Ua = function (a, b, c) {
      return a.call.apply(a.bind, arguments);
    },
    Va = function (a, b, c) {
      if (!a) throw Error();
      if (arguments.length > 2) {
        var d = Array.prototype.slice.call(arguments, 2);
        return function () {
          var e = Array.prototype.slice.call(arguments);
          Array.prototype.unshift.apply(e, d);
          return a.apply(b, e);
        };
      }
      return function () {
        return a.apply(b, arguments);
      };
    },
    x = function (a, b, c) {
      x =
        Function.prototype.bind &&
        Function.prototype.bind.toString().indexOf("native code") != -1
          ? Ua
          : Va;
      return x.apply(null, arguments);
    },
    Wa = function (a, b) {
      var c = Array.prototype.slice.call(arguments, 1);
      return function () {
        var d = c.slice();
        d.push.apply(d, arguments);
        return a.apply(this, d);
      };
    },
    Xa = function () {
      return Date.now();
    },
    Ya = function (a) {
      return a;
    },
    y = function (a, b) {
      function c() {}
      c.prototype = b.prototype;
      a.R = b.prototype;
      a.prototype = new c();
      a.prototype.constructor = a;
      a.Gg = function (d, e, f) {
        for (
          var g = Array(arguments.length - 2), k = 2;
          k < arguments.length;
          k++
        )
          g[k - 2] = arguments[k];
        return b.prototype[e].apply(d, g);
      };
    };
  function Za(a, b) {
    if (Error.captureStackTrace) Error.captureStackTrace(this, Za);
    else {
      var c = Error().stack;
      c && (this.stack = c);
    }
    a && (this.message = String(a));
    b !== void 0 && (this.cause = b);
  }
  y(Za, Error);
  Za.prototype.name = "CustomError";
  var $a;
  function ab(a, b) {
    a = a.split("%s");
    for (var c = "", d = a.length - 1, e = 0; e < d; e++)
      c += a[e] + (e < b.length ? b[e] : "%s");
    Za.call(this, c + a[d]);
  }
  y(ab, Za);
  ab.prototype.name = "AssertionError";
  function bb(a, b, c, d) {
    var e = "Assertion failed";
    if (c) {
      e += ": " + c;
      var f = d;
    } else a && ((e += ": " + a), (f = b));
    throw new ab("" + e, f || []);
  }
  var z = function (a, b, c) {
      a || bb("", null, b, Array.prototype.slice.call(arguments, 2));
      return a;
    },
    A = function (a, b, c) {
      a == null &&
        bb(
          "Expected to exist: %s.",
          [a],
          b,
          Array.prototype.slice.call(arguments, 2)
        );
      return a;
    },
    cb = function (a, b) {
      throw new ab(
        "Failure" + (a ? ": " + a : ""),
        Array.prototype.slice.call(arguments, 1)
      );
    },
    db = function (a, b, c) {
      typeof a !== "number" &&
        bb(
          "Expected number but got %s: %s.",
          [Pa(a), a],
          b,
          Array.prototype.slice.call(arguments, 2)
        );
      return a;
    },
    fb = function (a, b, c) {
      typeof a !== "function" &&
        bb(
          "Expected function but got %s: %s.",
          [Pa(a), a],
          b,
          Array.prototype.slice.call(arguments, 2)
        );
    },
    B = function (a, b, c) {
      Array.isArray(a) ||
        bb(
          "Expected array but got %s: %s.",
          [Pa(a), a],
          b,
          Array.prototype.slice.call(arguments, 2)
        );
      return a;
    },
    hb = function (a, b, c, d) {
      a instanceof b ||
        bb(
          "Expected instanceof %s but got %s.",
          [gb(b), gb(a)],
          c,
          Array.prototype.slice.call(arguments, 3)
        );
    };
  function gb(a) {
    return a instanceof Function
      ? a.displayName || a.name || "unknown type name"
      : a instanceof Object
      ? a.constructor.displayName ||
        a.constructor.name ||
        Object.prototype.toString.call(a)
      : a === null
      ? "null"
      : typeof a;
  }
  function ib(a) {
    q.setTimeout(function () {
      throw a;
    }, 0);
  }
  function jb(a, b) {
    return a.lastIndexOf(b, 0) == 0;
  }
  function kb(a) {
    return /^[\s\xa0]*$/.test(a);
  }
  var lb = String.prototype.trim
      ? function (a) {
          return a.trim();
        }
      : function (a) {
          return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1];
        },
    mb = /&/g,
    nb = /</g,
    ob = />/g,
    pb = /"/g,
    qb = /'/g,
    rb = /\x00/g,
    sb = /[\x00&<>"']/;
  function tb(a, b) {
    return a.indexOf(b) != -1;
  }
  function ub(a, b) {
    var c = 0;
    a = lb(String(a)).split(".");
    b = lb(String(b)).split(".");
    for (var d = Math.max(a.length, b.length), e = 0; c == 0 && e < d; e++) {
      var f = a[e] || "",
        g = b[e] || "";
      do {
        f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
        g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
        if (f[0].length == 0 && g[0].length == 0) break;
        c =
          vb(
            f[1].length == 0 ? 0 : parseInt(f[1], 10),
            g[1].length == 0 ? 0 : parseInt(g[1], 10)
          ) ||
          vb(f[2].length == 0, g[2].length == 0) ||
          vb(f[2], g[2]);
        f = f[3];
        g = g[3];
      } while (c == 0);
    }
    return c;
  }
  function vb(a, b) {
    return a < b ? -1 : a > b ? 1 : 0;
  }
  var wb = Ma(610401301, !1),
    xb = Ma(1331761403, !1),
    yb = Ma(748402147, Ma(1, !0));
  function zb() {
    var a = q.navigator;
    return a && (a = a.userAgent) ? a : "";
  }
  var Ab,
    Bb = q.navigator;
  Ab = Bb ? Bb.userAgentData || null : null;
  function Cb(a) {
    if (!wb || !Ab) return !1;
    for (var b = 0; b < Ab.brands.length; b++) {
      var c = Ab.brands[b].brand;
      if (c && tb(c, a)) return !0;
    }
    return !1;
  }
  function C(a) {
    return tb(zb(), a);
  }
  function Db() {
    return wb ? !!Ab && Ab.brands.length > 0 : !1;
  }
  function Eb() {
    return Db() ? !1 : C("Opera");
  }
  function Fb() {
    return Db() ? !1 : C("Trident") || C("MSIE");
  }
  function Gb() {
    return C("Firefox") || C("FxiOS");
  }
  function Hb() {
    return Db()
      ? Cb("Chromium")
      : ((C("Chrome") || C("CriOS")) && !(Db() ? 0 : C("Edge"))) || C("Silk");
  }
  function Ib() {
    var a = zb();
    if (Fb()) {
      var b = /rv: *([\d\.]*)/.exec(a);
      if (b && b[1]) a = b[1];
      else {
        b = "";
        var c = /MSIE +([\d\.]+)/.exec(a);
        if (c && c[1])
          if (((a = /Trident\/(\d.\d)/.exec(a)), c[1] == "7.0"))
            if (a && a[1])
              switch (a[1]) {
                case "4.0":
                  b = "8.0";
                  break;
                case "5.0":
                  b = "9.0";
                  break;
                case "6.0":
                  b = "10.0";
                  break;
                case "7.0":
                  b = "11.0";
              }
            else b = "7.0";
          else b = c[1];
        a = b;
      }
    } else a = "";
    return a;
  }
  function Jb() {
    if (Db()) {
      var a = Ab.brands.find(function (b) {
        return b.brand === "Internet Explorer";
      });
      if (!a || !a.version) return NaN;
      a = a.version.split(".");
    } else {
      a = Ib();
      if (a === "") return NaN;
      a = a.split(".");
    }
    return a.length === 0 ? NaN : Number(a[0]);
  }
  function Kb() {
    return C("iPhone") && !C("iPod") && !C("iPad");
  }
  function Lb() {
    return Kb() || C("iPad") || C("iPod");
  }
  var Mb = Array.prototype.indexOf
      ? function (a, b) {
          z(a.length != null);
          return Array.prototype.indexOf.call(a, b, void 0);
        }
      : function (a, b) {
          if (typeof a === "string")
            return typeof b !== "string" || b.length != 1
              ? -1
              : a.indexOf(b, 0);
          for (var c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
          return -1;
        },
    D = Array.prototype.forEach
      ? function (a, b, c) {
          z(a.length != null);
          Array.prototype.forEach.call(a, b, c);
        }
      : function (a, b, c) {
          for (
            var d = a.length,
              e = typeof a === "string" ? a.split("") : a,
              f = 0;
            f < d;
            f++
          )
            f in e && b.call(c, e[f], f, a);
        },
    Nb = Array.prototype.filter
      ? function (a, b, c) {
          z(a.length != null);
          return Array.prototype.filter.call(a, b, c);
        }
      : function (a, b, c) {
          for (
            var d = a.length,
              e = [],
              f = 0,
              g = typeof a === "string" ? a.split("") : a,
              k = 0;
            k < d;
            k++
          )
            if (k in g) {
              var m = g[k];
              b.call(c, m, k, a) && (e[f++] = m);
            }
          return e;
        },
    Ob = Array.prototype.map
      ? function (a, b) {
          z(a.length != null);
          return Array.prototype.map.call(a, b, void 0);
        }
      : function (a, b) {
          for (
            var c = a.length,
              d = Array(c),
              e = typeof a === "string" ? a.split("") : a,
              f = 0;
            f < c;
            f++
          )
            f in e && (d[f] = b.call(void 0, e[f], f, a));
          return d;
        },
    Pb = Array.prototype.some
      ? function (a, b, c) {
          z(a.length != null);
          return Array.prototype.some.call(a, b, c);
        }
      : function (a, b, c) {
          for (
            var d = a.length,
              e = typeof a === "string" ? a.split("") : a,
              f = 0;
            f < d;
            f++
          )
            if (f in e && b.call(c, e[f], f, a)) return !0;
          return !1;
        };
  function Qb(a) {
    var b = q.performance.getEntriesByType("resource");
    a = Rb(b, a);
    return a < 0 ? null : typeof b === "string" ? b.charAt(a) : b[a];
  }
  function Rb(a, b) {
    for (
      var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0;
      e < c;
      e++
    )
      if (e in d && b.call(void 0, d[e], e, a)) return e;
    return -1;
  }
  function Sb(a, b) {
    b = Mb(a, b);
    var c;
    (c = b >= 0) && Tb(a, b);
    return c;
  }
  function Tb(a, b) {
    z(a.length != null);
    Array.prototype.splice.call(a, b, 1);
  }
  function Ub(a) {
    return Array.prototype.concat.apply([], arguments);
  }
  function Vb(a) {
    var b = a.length;
    if (b > 0) {
      for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
      return c;
    }
    return [];
  }
  function Wb(a, b) {
    for (var c = 1; c < arguments.length; c++) {
      var d = arguments[c];
      if (Qa(d)) {
        var e = a.length || 0,
          f = d.length || 0;
        a.length = e + f;
        for (var g = 0; g < f; g++) a[e + g] = d[g];
      } else a.push(d);
    }
  }
  function Xb(a, b, c, d) {
    z(a.length != null);
    Array.prototype.splice.apply(a, Yb(arguments, 1));
  }
  function Yb(a, b, c) {
    z(a.length != null);
    return arguments.length <= 2
      ? Array.prototype.slice.call(a, b)
      : Array.prototype.slice.call(a, b, c);
  }
  function Zb(a, b) {
    a.sort(b || $b);
  }
  function ac(a, b) {
    for (var c = Array(a.length), d = 0; d < a.length; d++)
      c[d] = { index: d, value: a[d] };
    var e = b || $b;
    Zb(c, function (f, g) {
      return e(f.value, g.value) || f.index - g.index;
    });
    for (b = 0; b < a.length; b++) a[b] = c[b].value;
  }
  function $b(a, b) {
    return a > b ? 1 : a < b ? -1 : 0;
  }
  var bc = function (a) {
    bc[" "](a);
    return a;
  };
  bc[" "] = function () {};
  var cc = Eb(),
    dc = Fb(),
    ec = C("Edge"),
    fc =
      C("Gecko") &&
      !(tb(zb().toLowerCase(), "webkit") && !C("Edge")) &&
      !(C("Trident") || C("MSIE")) &&
      !C("Edge"),
    hc = tb(zb().toLowerCase(), "webkit") && !C("Edge"),
    ic;
  a: {
    var jc = "",
      kc = (function () {
        var a = zb();
        if (fc) return /rv:([^\);]+)(\)|;)/.exec(a);
        if (ec) return /Edge\/([\d\.]+)/.exec(a);
        if (dc) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
        if (hc) return /WebKit\/(\S+)/.exec(a);
        if (cc) return /(?:Version)[ \/]?(\S+)/.exec(a);
      })();
    kc && (jc = kc ? kc[1] : "");
    if (dc) {
      var lc,
        mc = q.document;
      lc = mc ? mc.documentMode : void 0;
      if (lc != null && lc > parseFloat(jc)) {
        ic = String(lc);
        break a;
      }
    }
    ic = jc;
  }
  var nc = ic;
  var oc = Gb(),
    pc = Kb() || C("iPod"),
    qc = C("iPad"),
    rc = C("Android") && !(Hb() || Gb() || Eb() || C("Silk")),
    sc = Hb(),
    tc =
      C("Safari") &&
      !(
        Hb() ||
        (Db() ? 0 : C("Coast")) ||
        Eb() ||
        (Db() ? 0 : C("Edge")) ||
        (Db() ? Cb("Microsoft Edge") : C("Edg/")) ||
        (Db() ? Cb("Opera") : C("OPR")) ||
        Gb() ||
        C("Silk") ||
        C("Android")
      ) &&
      !Lb();
  var uc = typeof structuredClone != "undefined";
  function vc(a, b) {
    a.__closure__error__context__984382 ||
      (a.__closure__error__context__984382 = {});
    a.__closure__error__context__984382.severity = b;
  }
  var wc = {};
  var xc = typeof Symbol === "function" && typeof Symbol() === "symbol";
  function yc(a, b, c) {
    return typeof Symbol === "function" && typeof Symbol() === "symbol"
      ? (c === void 0 ? 0 : c) && Symbol.for && a
        ? Symbol.for(a)
        : a != null
        ? Symbol(a)
        : Symbol()
      : b;
  }
  var zc = yc("jas", void 0, !0),
    Ac = yc("unknownBinaryFields", Symbol()),
    Bc = yc("unknownBinaryThrottleKey", "0ubs"),
    Cc = yc("m_m", "Kg", !0),
    Dc = yc("validPivotSelector", "vps");
  z(
    Math.round(
      Math.log2(
        Math.max.apply(
          Math,
          na(
            Object.values({
              pg: 1,
              og: 2,
              ng: 4,
              tg: 8,
              Fg: 16,
              rg: 32,
              Of: 64,
              jg: 128,
              ag: 256,
              Bg: 512,
              hg: 1024,
              kg: 2048,
              sg: 4096,
            })
          )
        )
      )
    ) === 12
  );
  var Ec = { Ee: { value: 0, configurable: !0, writable: !0, enumerable: !1 } },
    Fc = Object.defineProperties,
    F = xc ? A(zc) : "Ee",
    Gc,
    Hc = [];
  Ic(Hc, 7);
  Gc = Object.freeze(Hc);
  function Jc(a, b) {
    z((b & 8388607) === b);
    B(a, "state is only maintained on arrays.");
    xc || F in a || Fc(a, Ec);
    a[F] |= b;
  }
  function Ic(a, b) {
    z((b & 8388607) === b);
    B(a, "state is only maintained on arrays.");
    xc || F in a || Fc(a, Ec);
    a[F] = b;
  }
  function G(a, b, c) {
    (c === void 0 || !c || b & 2048) &&
      z(b & 64, "state for messages must be constructed");
    z(
      (b & 5) === 0,
      "state for messages should not contain repeated field state"
    );
    if (b & 64) {
      z(b & 64);
      c = (b >> 13) & 1023 || 536870912;
      var d = a.length;
      z(b & 64);
      z(
        c + (b & 128 ? 0 : -1) >= d - 1,
        "pivot %s is pointing at an index earlier than the last index of the array, length: %s",
        c,
        d
      );
      b & 128 &&
        z(
          typeof a[0] === "string",
          "arrays with a message_id bit must have a string in the first position, got: %s",
          a[0]
        );
    }
  }
  function Kc(a, b) {
    db(b);
    z(
      (b > 0 && b <= 1023) || 536870912 === b,
      "pivot must be in the range [1, 1024) or NO_PIVOT got %s",
      b
    );
    return (a & -8380417) | ((b & 1023) << 13);
  }
  var Lc = Object.getOwnPropertyDescriptor(Array.prototype, "Me");
  Object.defineProperties(Array.prototype, {
    Me: {
      get: function () {
        var a = Mc(this);
        return Lc ? Lc.get.call(this) + "|" + a : a;
      },
      configurable: !0,
      enumerable: !1,
    },
  });
  function Mc(a) {
    function b(e, f) {
      e & c && d.push(f);
    }
    var c = B(a, "state is only maintained on arrays.")[F] | 0,
      d = [];
    b(1, "IS_REPEATED_FIELD");
    b(2, "IS_IMMUTABLE_ARRAY");
    b(4, "IS_API_FORMATTED");
    b(512, "STRING_FORMATTED");
    b(1024, "GBIGINT_FORMATTED");
    b(1024, "BINARY");
    b(8, "ONLY_MUTABLE_VALUES");
    b(16, "UNFROZEN_SHARED");
    b(32, "MUTABLE_REFERENCES_ARE_OWNED");
    b(64, "CONSTRUCTED");
    b(128, "HAS_MESSAGE_ID");
    b(256, "FROZEN_ARRAY");
    b(2048, "HAS_WRAPPER");
    b(4096, "MUTABLE_SUBSTRUCTURES");
    c & 64 &&
      (z(c & 64),
      (a = (c >> 13) & 1023 || 536870912),
      a !== 536870912 && d.push("pivot: " + a));
    return d.join(",");
  }
  var H = xc && Math.random() < 0.5,
    Nc = H ? Symbol() : void 0,
    Oc,
    Pc = typeof Cc === "symbol",
    Qc = {};
  function I(a) {
    var b = a[Cc],
      c = b === Qc;
    z(!Oc || c === a instanceof Oc);
    if (Pc && b && !c) throw Error("multiple jspb runtimes detected");
    return c;
  }
  function Rc(a, b) {
    db(a);
    z(a > 0);
    z(b === 0 || b === -1);
    return a + b;
  }
  function Sc(a) {
    z(void 0 === Tc || !0);
    return a + -1;
  }
  function Uc(a, b) {
    db(a);
    z(a >= 0);
    z(b === 0 || b === -1);
    return a - b;
  }
  function Vc(a, b) {
    if (b === void 0) {
      if ((b = !Wc(a)))
        z(I(a)),
          (a = H ? a[A(Nc)] : a.g),
          (b = B(a, "state is only maintained on arrays.")[F] | 0),
          G(a, b),
          (b = !!(2 & b));
      return b;
    }
    z(I(a));
    var c = H ? a[A(Nc)] : a.g;
    var d = B(c, "state is only maintained on arrays.")[F] | 0;
    G(c, d);
    z(b === d);
    return !!(2 & b) && !Wc(a);
  }
  var Xc = {};
  function Wc(a) {
    var b = a.h,
      c;
    (c = !b) ||
      (z(I(a)),
      (a = H ? a[A(Nc)] : a.g),
      (c = B(a, "state is only maintained on arrays.")[F] | 0),
      G(a, c),
      (c = !!(2 & c)));
    z(c);
    z(b === void 0 || b === Xc);
    return b === Xc;
  }
  function Yc(a, b) {
    z(I(a));
    var c = H ? a[A(Nc)] : a.g;
    var d = B(c, "state is only maintained on arrays.")[F] | 0;
    G(c, d);
    z(b === !!(2 & d));
    a.h = b ? Xc : void 0;
  }
  var Zc = Symbol("exempted jspb subclass"),
    $c =
      typeof Symbol != "undefined" && typeof Symbol.hasInstance != "undefined";
  function ad() {}
  function bd(a, b) {
    var c = B(a);
    c = B(c, "state is only maintained on arrays.")[F] | 0;
    b || z(!((c & 2 && c & 4) || c & 256) || Object.isFrozen(a));
    cd(a);
  }
  function cd(a) {
    a = B(a, "state is only maintained on arrays.")[F] | 0;
    var b = a & 4,
      c = (512 & a ? 1 : 0) + (1024 & a ? 1 : 0);
    z(
      (b && c <= 1) || (!b && c === 0),
      "Expected at most 1 type-specific formatting bit, but got " +
        c +
        " with state: " +
        a
    );
  }
  var Tc = {};
  function dd(a) {
    a = B(a, "state is only maintained on arrays.")[F] | 0;
    z(a & 64);
    a & 128 ? z(void 0 === Tc) : z(!0);
  }
  function ed(a, b) {
    b = b === void 0 ? new Set() : b;
    if (b.has(a)) return "(Recursive reference)";
    switch (typeof a) {
      case "object":
        if (a) {
          var c = Object.getPrototypeOf(a);
          switch (c) {
            case Map.prototype:
            case Set.prototype:
            case Array.prototype:
              b.add(a);
              var d =
                "[" +
                Array.from(a, function (e) {
                  return ed(e, b);
                }).join(", ") +
                "]";
              b.delete(a);
              c !== Array.prototype && (d = fd(c.constructor) + "(" + d + ")");
              return d;
            case Object.prototype:
              return (
                b.add(a),
                (c =
                  "{" +
                  Object.entries(a)
                    .map(function (e) {
                      var f = ma(e);
                      e = f.next().value;
                      f = f.next().value;
                      return e + ": " + ed(f, b);
                    })
                    .join(", ") +
                  "}"),
                b.delete(a),
                c
              );
            default:
              return (
                (d = "Object"),
                c && c.constructor && (d = fd(c.constructor)),
                typeof a.toString === "function" &&
                a.toString !== Object.prototype.toString
                  ? d + "(" + String(a) + ")"
                  : "(object " + d + ")"
              );
          }
        }
        break;
      case "function":
        return "function " + fd(a);
      case "number":
        if (!Number.isFinite(a)) return String(a);
        break;
      case "bigint":
        return a.toString(10) + "n";
      case "symbol":
        return a.toString();
    }
    return JSON.stringify(a);
  }
  function fd(a) {
    var b = a.displayName;
    return (b && typeof b === "string") ||
      ((b = a.name) && typeof b === "string")
      ? b
      : (a = /function\s+([^\(]+)/m.exec(String(a)))
      ? a[1]
      : "(Anonymous)";
  }
  function gd(a, b) {
    var c = hd,
      d = [];
    id(b, a, d) ||
      jd.apply(
        null,
        [void 0, c, "Guard " + b.Lc().trim() + " failed:"].concat(
          na(d.reverse())
        )
      );
  }
  function kd(a, b) {
    a.Jg = !0;
    a.Lc =
      typeof b === "function"
        ? b
        : function () {
            return b;
          };
    return a;
  }
  function id(a, b, c) {
    var d = a(b, c);
    d ||
      ld(c, function () {
        var e = "";
        e.length > 0 && (e += ": ");
        return e + "Expected " + a.Lc().trim() + ", got " + ed(b);
      });
    return d;
  }
  function ld(a, b) {
    a == null || a.push((typeof b === "function" ? b() : b).trim());
  }
  var hd = void 0;
  function md(a) {
    return typeof a === "function" ? a() : a;
  }
  function jd() {
    throw Error(
      Ga.apply(0, arguments)
        .map(md)
        .filter(Boolean)
        .join("\n")
        .trim()
        .replace(/:$/, "")
    );
  }
  var nd = kd(function (a) {
      return typeof a === "string";
    }, "string"),
    od = kd(function (a) {
      return typeof a === "bigint";
    }, "bigint");
  var pd = typeof q.BigInt === "function" && typeof q.BigInt(0) === "bigint";
  var vd = kd(function (a) {
      if (pd)
        return gd(qd, od), gd(rd, od), (a = BigInt(a)), a >= qd && a <= rd;
      gd(a, nd);
      return a[0] === "-" ? sd(a, td) : sd(a, ud);
    }, "isSafeInt52"),
    td = Number.MIN_SAFE_INTEGER.toString(),
    qd = pd ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
    ud = Number.MAX_SAFE_INTEGER.toString(),
    rd = pd ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;
  function sd(a, b) {
    if (a.length > b.length) return !1;
    if (a.length < b.length || a === b) return !0;
    for (var c = 0; c < a.length; c++) {
      var d = a[c],
        e = b[c];
      if (d > e) return !1;
      if (d < e) return !0;
    }
    c = hd;
    jd(
      "Assertion fail:",
      "isInRange weird case. Value was: " + a + ". Boundary was: " + b + "." ||
        c
    );
  }
  var wd = Number.isFinite;
  function xd(a) {
    if (!wd(a))
      throw (
        ((a = Error(
          "Expected enum as finite number but got " + Pa(a) + ": " + a
        )),
        vc(a, "warning"),
        a)
      );
    return a | 0;
  }
  function yd(a) {
    return a;
  }
  yd[Dc] = {};
  function zd(a) {
    return a;
  }
  var Ad = function () {
    throw Error("please construct maps as mutable then call toImmutable");
  };
  if ($c) {
    var Bd = function () {
        throw Error(
          "Cannot perform instanceof checks on ImmutableMap: please use isImmutableMap or isMutableMap to assert on the mutability of a map. See go/jspb-api-gotchas#immutable-classes for more information"
        );
      },
      Cd = {};
    Object.defineProperties(
      Ad,
      ((Cd[Symbol.hasInstance] = {
        value: Bd,
        configurable: !1,
        writable: !1,
        enumerable: !1,
      }),
      Cd)
    );
    z(
      Ad[Symbol.hasInstance] === Bd,
      "defineProperties did not work: was it monkey-patched?"
    );
  }
  function Dd(a, b) {
    if (!(b < 100) && Bc != null) {
      var c;
      a = (c = wc) != null ? c : (wc = {});
      c = a[Bc] || 0;
      c >= 1 ||
        ((a[Bc] = c + 1), (b = Error("0ubs:" + b)), vc(b, "incident"), ib(b));
    }
  }
  function Ed(a, b, c, d, e) {
    var f = d !== void 0;
    d = !!d;
    var g = Ya(Ac),
      k;
    !f && xc && g && (k = a[g]) && k.Ig(Dd);
    g = [];
    var m = a.length;
    k = 4294967295;
    var p = !1,
      t = !!(b & 64);
    if (t) {
      z(b & 64);
      var u = b & 128 ? 0 : -1;
    } else u = void 0;
    if (!(b & 1)) {
      var w = m && a[m - 1];
      w != null && typeof w === "object" && w.constructor === Object
        ? (m--, (k = m))
        : (w = void 0);
      if (t && !(b & 128) && !f) {
        p = !0;
        var E;
        b = (E = Fd) != null ? E : yd;
        k = Rc(b(Uc(k, A(u)), A(u), a, w, e), A(u));
      }
    }
    e = void 0;
    for (E = 0; E < m; E++)
      if (((b = a[E]), b != null && (b = c(b, d)) != null))
        if (t && E >= k) {
          Gd();
          var qa = Uc(E, A(u)),
            ta = void 0;
          ((ta = e) != null ? ta : (e = {}))[qa] = b;
        } else g[E] = b;
    if (w)
      for (var eb in w)
        (m = w[eb]),
          m != null &&
            (m = c(m, d)) != null &&
            ((E = +eb),
            (b = void 0),
            t && !Number.isNaN(E) && (b = Rc(E, A(u))) < k
              ? (Gd(), (g[A(b)] = m))
              : ((E = void 0), (((E = e) != null ? E : (e = {}))[eb] = m)));
    e && (p ? g.push(e) : (z(k < 4294967295), (g[k] = e)));
    f && Ya(Ac) && (B(g), B(a), z(g[Ac] === void 0), Ya(Ac) && B(a));
    return g;
  }
  function Hd(a) {
    A(a);
    switch (typeof a) {
      case "number":
        return Number.isFinite(a) ? a : "" + a;
      case "bigint":
        return vd(a) ? Number(a) : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          bd(a);
          var b = B(a, "state is only maintained on arrays.")[F] | 0;
          return a.length === 0 && b & 1 ? void 0 : Ed(a, b, Hd);
        }
        if (a != null && I(a)) return Id(a);
        z(!(a instanceof Uint8Array));
        return;
    }
    return a;
  }
  var Jd = uc
      ? structuredClone
      : function (a) {
          B(a);
          return Ed(a, 0, Hd);
        },
    Fd;
  function Kd(a) {
    z(!Fd);
    return Id(a);
  }
  function Id(a) {
    z(I(a));
    var b = H ? a[A(Nc)] : a.g;
    var c = B(b, "state is only maintained on arrays.")[F] | 0;
    G(b, c);
    return Ed(b, c, Hd, void 0, a.constructor);
  }
  function Gd() {
    var a,
      b = (a = Fd) != null ? a : yd;
    z(b !== zd);
  }
  var Ld = new WeakMap();
  function Md(a) {
    if (a != null)
      if (Array.isArray(a)) Nd(a);
      else if (a instanceof Uint8Array)
        uc
          ? structuredClone(a, { transfer: [a.buffer] })
          : a.fill(97, 0, a.length);
      else if (typeof a === "object") {
        for (var b in a) {
          var c = a[b];
          a.hasOwnProperty(b) && (delete a[b], Md(c));
        }
        Object.defineProperty(a, "dontUseThisItBelongsToJspb", {
          enumerable: !0,
          get: Od,
        });
        a.toJSON = Od;
        Pd && Object.setPrototypeOf(a, Pd);
        Object.freeze(a);
      }
  }
  var Pd;
  if (typeof Proxy !== "undefined") {
    var Qd = Od;
    Pd = new Proxy(
      {},
      {
        getPrototypeOf: Qd,
        setPrototypeOf: Qd,
        isExtensible: Qd,
        preventExtensions: Qd,
        getOwnPropertyDescriptor: Qd,
        defineProperty: Qd,
        has: Qd,
        get: Qd,
        set: Qd,
        deleteProperty: Qd,
        apply: Qd,
        construct: Qd,
      }
    );
  }
  function Nd(a) {
    for (var b = 0; b < a.length; b++) Md(a[b]);
    if (!Object.isExtensible(a))
      throw Error("cannot transfer a frozen or sealed array");
    a.length = 1;
    a[0] = Od;
    a.toJSON = Od;
    Pd && Object.setPrototypeOf(a, Pd);
    Object.freeze(a);
  }
  function Od() {
    throw Error(
      "this array or object is owned by JSPB and should not be reused, did you mean to copy it with copyJspbArray? See go/jspb-api-gotchas#construct_from_array"
    );
  }
  function Rd(a, b, c) {
    var d = d === void 0 ? 0 : d;
    if (a != null)
      for (var e = 0; e < a.length; e++) {
        var f = a[e];
        Array.isArray(f) && bd(f);
      }
    if (a == null)
      (f = 32), c ? ((a = [c]), (f |= 128)) : (a = []), b && (f = Kc(f, b));
    else {
      if (!Array.isArray(a))
        throw Error(
          "data passed to JSPB constructors must be an Array, got '" +
            JSON.stringify(a) +
            "' a " +
            Pa(a)
        );
      f = B(a, "state is only maintained on arrays.")[F] | 0;
      if (yb && 1 & f)
        throw Error(
          "Array passed to JSPB constructor is a repeated field array that belongs to another proto instance."
        );
      2048 & f && !(2 & f) && Sd();
      if (Object.isFrozen(a) || !Object.isExtensible(a) || Object.isSealed(a))
        throw Error("data passed to JSPB constructors must be mutable");
      if (f & 256) throw Error("farr");
      if (f & 64) return d !== 0 || f & 2048 || Ic(a, (f |= 2048)), G(a, f), a;
      if (c && ((f |= 128), c !== a[0]))
        throw Error(
          'Expected message to have a message id: "' +
            c +
            '" in the array, got: ' +
            JSON.stringify(a[0]) +
            " a " +
            Pa(a[0]) +
            ", are you parsing with the wrong proto?"
        );
      a: {
        e = a;
        c = f | 64;
        var g = e.length;
        if (g) {
          var k = g - 1;
          f = e[k];
          if (f != null && typeof f === "object" && f.constructor === Object) {
            z(c & 64);
            b = c & 128 ? 0 : -1;
            g = Uc(k, b);
            if (g >= 1024)
              throw Error(
                "Found a message with a sparse object at fieldNumber " +
                  g +
                  " is >= the limit 1024"
              );
            for (var m in f)
              (k = +m),
                k < g &&
                  ((k = Rc(k, b)), z(e[k] == null), (e[k] = f[m]), delete f[m]);
            f = Kc(c, g);
            break a;
          }
        }
        if (b) {
          m = Math;
          e = m.max;
          z(c & 64);
          m = e.call(m, b, Uc(g, c & 128 ? 0 : -1));
          if (m > 1024)
            throw Error(
              "a message was constructed with an array of length " +
                g +
                " which is longer than 1024, are you using a supported serializer?"
            );
          f = Kc(c, m);
        } else f = c;
      }
    }
    f |= 64;
    d === 0 && (f |= 2048);
    Ic(a, f);
    return a;
  }
  function Sd() {
    if (yb)
      throw Error(
        "Array passed to JSPB constructor already belongs to another JSPB proto instance"
      );
  }
  function Td(a) {
    z(!(2 & a));
    z(!(2048 & a));
    return !(4096 & a) && !(16 & a);
  }
  function Ud(a, b) {
    A(a);
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      bd(a);
      var c = B(a, "state is only maintained on arrays.")[F] | 0;
      a.length === 0 && c & 1
        ? (a = void 0)
        : c & 2 ||
          (b && Td(c)
            ? (Jc(a, 34), c & 4 && Object.freeze(a))
            : (a = Vd(a, c, !1, b && !(c & 16))));
      return a;
    }
    if (a != null && I(a))
      return (
        z(a != null && I(a)),
        z(I(a)),
        (b = H ? a[A(Nc)] : a.g),
        (c = B(b, "state is only maintained on arrays.")[F] | 0),
        G(b, c),
        Vc(a, c) ? a : Wd(a, b, c) ? Xd(a, b) : Vd(b, c)
      );
    z(!(a instanceof Uint8Array));
  }
  function Xd(a, b, c) {
    a = new a.constructor(b);
    c && Yc(a, !0);
    a.j = Xc;
    return a;
  }
  function Vd(a, b, c, d) {
    z(b === (B(a, "state is only maintained on arrays.")[F] | 0));
    d != null || (d = !!(34 & b));
    a = Ed(a, b, Ud, d);
    d = 32;
    c && (d |= 2);
    b = (b & 8380609) | d;
    Ic(a, b);
    return a;
  }
  function Yd(a) {
    if (!Wc(a)) return !1;
    z(I(a));
    var b = H ? a[A(Nc)] : a.g;
    var c = B(b, "state is only maintained on arrays.")[F] | 0;
    G(b, c);
    z(c & 2);
    b = Vd(b, c);
    Jc(b, 2048);
    z(I(a));
    B(b);
    H ? (a[A(Nc)] = b) : (a.g = b);
    Yc(a, !1);
    a.j = void 0;
    return !0;
  }
  function Zd(a) {
    var b;
    if ((b = !Yd(a))) {
      z(I(a));
      b = H ? a[A(Nc)] : a.g;
      var c = B(b, "state is only maintained on arrays.")[F] | 0;
      G(b, c);
      b = Vc(a, c);
    }
    if (b) throw Error("Cannot mutate an immutable Message");
  }
  function $d(a, b) {
    if (b === void 0)
      (b = B(a, "state is only maintained on arrays.")[F] | 0), G(a, b, !0);
    else {
      var c = B(a, "state is only maintained on arrays.")[F] | 0;
      G(a, c, !0);
      z(b === c);
    }
    z(!(b & 2));
    b & 32 && !(b & 4096) && Ic(a, b | 4096);
  }
  function Wd(a, b, c) {
    return Zc && a[Zc]
      ? !1
      : c & 2
      ? !0
      : c & 32 && !(c & 4096)
      ? (Ic(b, c | 2), Yc(a, !0), !0)
      : !1;
  }
  var ae = function (a, b, c) {
    dd(a);
    if (b === -1) return null;
    var d = Sc(b),
      e = B(a, "state is only maintained on arrays.")[F] | 0;
    z(e & 64);
    z(d === Rc(b, e & 128 ? 0 : -1));
    z(d >= 0);
    e = a.length - 1;
    if (!(e < Sc(1))) {
      if (d >= e) {
        var f = a[e];
        if (f != null && typeof f === "object" && f.constructor === Object) {
          e = f[b];
          var g = !0;
        } else if (d === e) e = f;
        else return;
      } else e = a[d];
      if (c && e != null) {
        c = c(e);
        if (c == null) return c;
        if (!Object.is(c, e)) return g ? (f[b] = c) : (a[d] = c), c;
      }
      return e;
    }
  };
  function be(a, b, c, d) {
    dd(a);
    var e = Sc(c),
      f = B(a, "state is only maintained on arrays.")[F] | 0;
    z(f & 64);
    z(e === Rc(c, f & 128 ? 0 : -1));
    z(e >= 0);
    f = a.length - 1;
    if (f >= Sc(1) && e >= f) {
      var g = a[f];
      if (g != null && typeof g === "object" && g.constructor === Object)
        return (g[c] = d), b;
    }
    if (e <= f) return (a[e] = d), b;
    d !== void 0 &&
      ((f = b) == null &&
        ((b = B(a, "state is only maintained on arrays.")[F] | 0),
        G(a, b),
        (f = b)),
      z(f & 64),
      (f = (f >> 13) & 1023 || 536870912),
      c >= f
        ? (z(f !== 536870912),
          d != null && ((e = {}), (a[Sc(f)] = ((e[c] = d), e))))
        : (a[e] = d));
    return b;
  }
  function ce(a, b) {
    if (!a) return a;
    z((B(b, "state is only maintained on arrays.")[F] | 0) & 2 ? Vc(a) : !0);
    return a;
  }
  function de(a) {
    return (!!(2 & a) && !!(4 & a)) || !!(256 & a);
  }
  function ee(a, b, c) {
    var d = !1,
      e = ae(a, 1, function (f) {
        if (f != null && I(f)) var g = f;
        else if (Array.isArray(f)) {
          g = B(f, "state is only maintained on arrays.")[F] | 0;
          var k = g | (b & 32);
          k |= b & 2;
          k !== g && Ic(f, k);
          g = new c(f);
        } else g = void 0;
        d = g !== f && g != null;
        return g;
      });
    if (e != null) return d && !Vc(e) && $d(a, b), ce(e, a);
  }
  var fe = function (a, b) {
    z(I(a));
    var c = H ? a[A(Nc)] : a.g;
    var d = B(c, "state is only maintained on arrays.")[F] | 0;
    G(c, d);
    b = ee(c, d, b);
    if (b == null) return b;
    d = B(c, "state is only maintained on arrays.")[F] | 0;
    G(c, d);
    if (!Vc(a, d)) {
      var e = b;
      z(I(e));
      var f = H ? e[A(Nc)] : e.g;
      var g = B(f, "state is only maintained on arrays.")[F] | 0;
      G(f, g);
      e = Vc(e, g)
        ? Wd(e, f, g)
          ? Xd(e, f, !0)
          : new e.constructor(Vd(f, g, !1))
        : e;
      e !== b &&
        (Yd(a) &&
          (z(I(a)),
          (c = H ? a[A(Nc)] : a.g),
          (a = B(c, "state is only maintained on arrays.")[F] | 0),
          G(c, a),
          (d = a)),
        (b = e),
        (d = be(c, d, 1, b)),
        $d(c, d));
    }
    return ce(b, c);
  };
  function ge(a, b) {
    return (a = (2 & b ? a | 2 : a & -3) & -273);
  }
  z(!0);
  var he = function (a, b, c) {
    this.preventPassingToStructuredClone = ad;
    hb(this, he, "The message constructor should only be used by subclasses");
    z(
      this.constructor !== he,
      "Message is an abstract class and cannot be directly constructed"
    );
    a = Rd(a, b, c);
    z(I(this));
    B(a);
    H ? (this[A(Nc)] = a) : (this.g = a);
    z(I(this));
    a = H ? this[A(Nc)] : this.g;
    b = B(a, "state is only maintained on arrays.")[F] | 0;
    G(a, b);
    z(b & 64);
    z(b & 2048);
  };
  he.prototype.toJSON = function () {
    return Kd(this);
  };
  Oc = he;
  he.prototype[Cc] = Qc;
  he.prototype.toString = function () {
    z(I(this));
    return (H ? this[A(Nc)] : this.g).toString();
  };
  function ie(a, b) {
    if (b == null) return new a();
    if (Ld.get(b)) throw Error("this array was already transferred");
    if (!Array.isArray(b)) throw Error("must be an array");
    if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b))
      throw Error("arrays passed to jspb constructors must be mutable");
    var c = b;
    b = Jd(b);
    Nd(c);
    Ld.set(c, b);
    Jc(b, 32);
    a = new a(b);
    hb(a, he);
    return a;
  }
  function je(a) {
    if (a instanceof he) return a.constructor.g;
  }
  (function () {
    var a = q.jspbGetTypeName;
    q.jspbGetTypeName = a
      ? function (b) {
          return a(b) || je(b);
        }
      : je;
  })();
  var ke = he;
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (
    a,
    b
  ) {
    return a + b;
  });
  [
    2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
    2, 2, 2, 2, 2, 2, 2,
  ].reduce(function (a, b) {
    return a + b;
  });
  [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce(function (a, b) {
    return a + b;
  });
  function le(a, b, c) {
    for (var d in a) b.call(c, a[d], d, a);
  }
  function me(a, b) {
    for (var c in a) if (b.call(void 0, a[c], c, a)) return !0;
    return !1;
  }
  function ne(a) {
    var b = 0,
      c;
    for (c in a) b++;
    return b;
  }
  function oe(a) {
    var b = [],
      c = 0,
      d;
    for (d in a) b[c++] = a[d];
    return b;
  }
  function pe(a, b) {
    var c = Qa(b),
      d = c ? b : arguments;
    for (c = c ? 0 : 1; c < d.length; c++) {
      if (a == null) return;
      a = a[d[c]];
    }
    return a;
  }
  function qe(a, b) {
    return a !== null && b in a ? a[b] : void 0;
  }
  function re(a, b, c) {
    b in a || (a[b] = c);
  }
  function se(a) {
    var b = {},
      c;
    for (c in a) b[c] = a[c];
    return b;
  }
  var te =
    "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(
      " "
    );
  function ue(a, b) {
    for (var c, d, e = 1; e < arguments.length; e++) {
      d = arguments[e];
      for (c in d) a[c] = d[c];
      for (var f = 0; f < te.length; f++)
        (c = te[f]),
          Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c]);
    }
  }
  var ve =
    Object.freeze ||
    function (a) {
      return a;
    };
  var we = function (a, b) {
    this.name = a;
    this.value = b;
  };
  we.prototype.toString = function () {
    return this.name;
  };
  var xe = new we("OFF", Infinity),
    ye = new we("SHOUT", 1200),
    ze = new we("SEVERE", 1e3),
    Ae = new we("WARNING", 900),
    Be = new we("INFO", 800),
    Ce = new we("CONFIG", 700),
    De = new we("FINE", 500),
    Ee = new we("FINER", 400),
    Fe = new we("FINEST", 300),
    Ge = new we("ALL", 0),
    He = [xe, ye, ze, Ae, Be, Ce, De, Ee, Fe, Ge],
    Ie = null,
    Je = function () {
      this.clear();
    },
    Ke;
  Je.prototype.clear = function () {};
  var Le = function (a, b, c) {
    this.g = void 0;
    this.reset(a || xe, b, c, void 0, void 0);
  };
  Le.prototype.reset = function (a, b, c, d) {
    this.j = d || Xa();
    this.l = a;
    this.v = b;
    this.h = c;
    this.g = void 0;
  };
  var Me = function (a, b) {
      this.level = null;
      this.h = [];
      this.parent = (b === void 0 ? null : b) || null;
      this.j = [];
      this.g = {
        getName: function () {
          return a;
        },
      };
    },
    Ne = function (a) {
      if (a.level) return a.level;
      if (a.parent) return Ne(a.parent);
      cb("Root logger has no level set.");
      return xe;
    },
    Oe = function (a, b) {
      for (; a; )
        a.h.forEach(function (c) {
          c(b);
        }),
          (a = a.parent);
    },
    Pe = function () {
      this.entries = {};
      var a = new Me("");
      a.level = Ce;
      this.entries[""] = a;
    },
    Qe,
    Re = function (a, b) {
      var c = a.entries[b];
      if (c) return c;
      c = Re(a, b.slice(0, Math.max(b.lastIndexOf("."), 0)));
      var d = new Me(b, c);
      a.entries[b] = d;
      c.j.push(d);
      return d;
    },
    Se = function () {
      Qe || (Qe = new Pe());
      return Qe;
    },
    Te = function (a) {
      return Re(Se(), a).g;
    },
    Ue = function (a, b) {
      a && (Re(Se(), a.getName()).level = b);
    },
    Ve = function (a, b, c, d) {
      var e;
      if ((e = a))
        if ((e = a && b)) {
          e = b.value;
          var f = a ? Ne(Re(Se(), a.getName())) : xe;
          e = e >= f.value;
        }
      e &&
        ((b = b || xe),
        (e = Re(Se(), a.getName())),
        typeof c === "function" && (c = c()),
        Ke || (Ke = new Je()),
        (a = a.getName()),
        (a = new Le(b, c, a)),
        (a.g = d),
        Oe(e, a));
    },
    We = function (a, b) {
      a && Ve(a, ze, b);
    },
    J = function (a, b, c) {
      a && Ve(a, Ae, b, c);
    },
    K = function (a, b) {
      a && Ve(a, Be, b);
    },
    Xe = function (a, b) {
      a && Ve(a, De, b);
    };
  Te("contentads.shared.adtech.iabtcfv2.js.PublisherTcCodec");
  Te("contentads.shared.adtech.iabtcfv2.js.TcfCoreStringCodec");
  var Ye = function (a) {
    ke.call(this, a);
  };
  n(Ye, ke);
  var Ze = function (a) {
    var b = new Ye();
    Zd(b);
    var c = !0;
    z(I(b));
    var d = H ? b[A(Nc)] : b.g;
    var e = B(d, "state is only maintained on arrays.")[F] | 0;
    G(d, e);
    var f = e;
    e = Vc(b, f) ? 1 : 2;
    c = !!c || e === 3;
    e === 2 &&
      Yd(b) &&
      (z(I(b)),
      (d = H ? b[A(Nc)] : b.g),
      (f = B(d, "state is only maintained on arrays.")[F] | 0),
      G(d, f));
    b = ae(d, 1);
    var g = Array.isArray(b) ? b : Gc;
    var k = g === Gc ? 7 : B(g, "state is only maintained on arrays.")[F] | 0;
    b = k;
    2 & f && (b |= 2);
    var m = b | 1;
    cd(g);
    b = 4 & m ? !1 : !0;
    if (b) {
      4 & m &&
        ((g = Array.prototype.slice.call(g)),
        (k = 0),
        (m = ge(m, f)),
        (f = A(be(d, f, 1, g))));
      for (var p = 0, t = 0; p < g.length; p++) {
        var u = g[p];
        u = u == null ? u : wd(u) ? u | 0 : void 0;
        u != null && (g[t++] = u);
      }
      t < p && (g.length = t);
      m = (m | 4) & -513;
      m &= -1025;
      m &= -4097;
    }
    m !== k && (Ic(g, m), 2 & m && Object.freeze(g));
    k = m;
    m = d;
    t = c;
    p = k;
    e === 1 || (e !== 4 ? 0 : 2 & k || (!(16 & k) && 32 & f))
      ? de(k) ||
        ((e = !g.length || (b && !(4096 & k)) || (!!(32 & f) && Td(k))),
        (k |= e ? 2 : 256),
        k !== p && Ic(g, k),
        Object.freeze(g))
      : (e === 2 &&
          de(k) &&
          ((g = Array.prototype.slice.call(g)),
          (p = 0),
          (k = ge(k, f)),
          (f = A(be(m, f, 1, g)))),
        de(k) || (t || (k |= 16), k !== p && Ic(g, k)));
    2 & k || Td(k) || $d(m, f);
    cd(g);
    if (!c) {
      c = g;
      var w = w === void 0 ? !1 : w;
      bd(c, w);
      e = B(c, "state is only maintained on arrays.")[F] | 0;
      z(e & 1);
      w ||
        (z(Object.isFrozen(c) || e & 16),
        z(
          (B(d, "state is only maintained on arrays.")[F] | 0) & 2
            ? Object.isFrozen(c)
            : !0
        ));
    }
    w = g;
    if (Array.isArray(a))
      for (d = a.length, c = 0; c < d; c++) w.push(xd(a[c]));
    else
      for (a = ma(a), d = a.next(); !d.done; d = a.next()) w.push(xd(d.value));
    cd(w);
  };
  Ye.g =
    "com.google.android.libraries.ads.mobile.sdk.internal.consent.ConsentAllowlist";
  function $e(a) {
    var b = !1;
    b = b === void 0 ? !1 : b;
    var c = c === void 0 ? q : c;
    for (var d = 0; c && d++ < 40; ) {
      var e;
      if (!(e = b))
        try {
          var f;
          if ((f = !!c && c.location.href != null))
            b: {
              try {
                bc(c.foo);
                f = !0;
                break b;
              } catch (k) {}
              f = !1;
            }
          e = f;
        } catch (k) {
          e = !1;
        }
      if (e && a(c)) break;
      a: {
        try {
          var g = c.parent;
          if (g && g != c) {
            c = g;
            break a;
          }
        } catch (k) {}
        c = null;
      }
    }
  }
  var af = function () {}; /*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
  var bf = {};
  function cf() {
    if (bf !== bf) throw Error("Bad secret");
  }
  var df = globalThis.trustedTypes,
    ef;
  function ff() {
    var a = null;
    if (!df) return a;
    try {
      var b = function (c) {
        return c;
      };
      a = df.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (c) {
      throw c;
    }
    return a;
  }
  function gf() {
    ef === void 0 && (ef = ff());
    return ef;
  }
  var hf = function (a) {
    cf();
    this.g = a;
  };
  hf.prototype.toString = function () {
    return this.g + "";
  };
  function jf(a) {
    var b = gf();
    a = b ? b.createScriptURL(a) : a;
    return new hf(a);
  }
  function kf(a) {
    if (a instanceof hf) return a.g;
    throw Error("Unexpected type when unwrapping TrustedResourceUrl");
  }
  var lf = pa([""]),
    mf = oa(["\x00"], ["\\0"]),
    nf = oa(["\n"], ["\\n"]),
    of = oa(["\x00"], ["\\u0000"]),
    pf = pa([""]),
    qf = oa(["\x00"], ["\\0"]),
    rf = oa(["\n"], ["\\n"]),
    sf = oa(["\x00"], ["\\u0000"]);
  function tf(a, b) {
    if (
      !Array.isArray(a) ||
      !Array.isArray(a.raw) ||
      a.length !== a.raw.length ||
      (!uf && a === a.raw) ||
      !((uf && !vf) || wf(a)) ||
      b + 1 !== a.length
    )
      throw new TypeError(
        "\n    ############################## ERROR ##############################\n\n    It looks like you are trying to call a template tag function (fn`...`)\n    using the normal function syntax (fn(...)), which is not supported.\n\n    The functions in the safevalues library are not designed to be called\n    like normal functions, and doing so invalidates the security guarantees\n    that safevalues provides.\n\n    If you are stuck and not sure how to proceed, please reach out to us\n    instead through:\n     - go/ise-hardening-yaqs (preferred) // LINE-INTERNAL\n     - g/ise-hardening // LINE-INTERNAL\n     - https://github.com/google/safevalues/issues\n\n    ############################## ERROR ##############################"
      );
  }
  function wf(a) {
    return Object.isFrozen(a) && Object.isFrozen(a.raw);
  }
  function xf(a) {
    return a.toString().indexOf("`") === -1;
  }
  var uf =
      xf(function (a) {
        return a(lf);
      }) ||
      xf(function (a) {
        return a(mf);
      }) ||
      xf(function (a) {
        return a(nf);
      }) ||
      xf(function (a) {
        return a(of);
      }),
    vf = wf(pf) && wf(qf) && wf(rf) && wf(sf);
  var yf = function (a) {
    cf();
    this.g = a;
  };
  yf.prototype.toString = function () {
    return this.g;
  };
  new yf("about:blank");
  var zf = new yf("about:invalid#zClosurez");
  function Af(a) {
    if (a instanceof yf) return a.g;
    throw Error(
      "Unexpected type when unwrapping SafeUrl, got '" +
        a +
        "' of type '" +
        typeof a +
        "'"
    );
  }
  var Bf = function (a) {
    this.Le = a;
  };
  function Cf(a) {
    return new Bf(function (b) {
      return b.substr(0, a.length + 1).toLowerCase() === a + ":";
    });
  }
  var Ef = [
      Cf("data"),
      Cf("http"),
      Cf("https"),
      Cf("mailto"),
      Cf("ftp"),
      new Bf(function (a) {
        return /^[^:]*([/?#]|$)/.test(a);
      }),
    ],
    Ff = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  function Gf(a) {
    if (a instanceof yf) a = Af(a);
    else {
      var b = !Ff.test(a);
      b && Hf(a);
      a = b ? void 0 : a;
    }
    return a;
  }
  var If = [],
    Hf = function () {};
  Jf(function (a) {
    console.warn("A URL with content '" + a + "' was sanitized away.");
  });
  function Jf(a) {
    If.indexOf(a) === -1 && If.push(a);
    Hf = function (b) {
      If.forEach(function (c) {
        c(b);
      });
    };
  }
  var Kf = function (a) {
    cf();
    this.g = a;
  };
  Kf.prototype.toString = function () {
    return this.g + "";
  };
  function Lf(a, b, c, d) {
    b = Gf(b);
    return b !== void 0 ? a.open(b, c, d) : null;
  }
  function Mf(a, b) {
    b = b === void 0 ? document : b;
    var c, d;
    b = (d = (c = b).querySelector) == null ? void 0 : d.call(c, a + "[nonce]");
    return b == null ? "" : b.nonce || b.getAttribute("nonce") || "";
  }
  function Nf(a, b) {
    a.src = kf(b);
    (b = Mf("script", a.ownerDocument)) && a.setAttribute("nonce", b);
  }
  var Of = function (a) {
    cf();
    this.g = a;
  };
  Of.prototype.toString = function () {
    return this.g;
  };
  function Pf(a) {
    if (typeof a !== "string" || a.trim() === "")
      throw Error(
        "Calls to uncheckedconversion functions must go through security review. A justification must be provided to capture what security assumptions are being made. See go/unchecked-conversions"
      );
  }
  var Qf = function (a) {
      return decodeURIComponent(a.replace(/\+/g, " "));
    },
    Rf = function (a, b) {
      var c = a;
      0 < a.length && b > 0 && (c = a.slice(0, 0) + a.slice(0 + b));
      return c;
    },
    Sf = function (a) {
      return a == null ? "" : String(a);
    },
    Tf = function (a) {
      for (var b = 0, c = 0; c < a.length; ++c)
        b = (31 * b + a.charCodeAt(c)) >>> 0;
      return b;
    },
    Uf = function (a) {
      return String(a).replace(/\-([a-z])/g, function (b, c) {
        return c.toUpperCase();
      });
    },
    Vf = function (a) {
      return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function (b, c, d) {
        return c + d.toUpperCase();
      });
    };
  function Wf(a) {
    var b = Ga.apply(1, arguments);
    tf(a, b.length);
    for (var c = a[0], d = 0; d < a.length - 1; d++)
      (c += String(b[d])), (c += a[d + 1]);
    b = document.implementation.createHTMLDocument("");
    d = b.createElement("style");
    b.head.appendChild(d);
    b = d.sheet;
    b.insertRule(c, 0);
    if (b.cssRules.length !== 1)
      throw Error(
        "safeStyleRule can be used to construct only 1 CSSStyleRule at a time. Use the concatStyle function to create sheet with several rules. Tried to parse: " +
          c +
          ("which has " +
            b.cssRules.length +
            " rules: " +
            b.cssRules[0].cssText +
            " #$% " +
            b.cssRules[1].cssText +
            ".")
      );
    b = b.cssRules[0];
    if (!(b instanceof CSSStyleRule))
      throw Error(
        "safeStyleRule can be used to construct a CSSStyleRule. @-rules should be constructed with the safeStyleSheet builder. Tried to parse: " +
          c
      );
    c = b.cssText.replace(/</g, "\\3C ");
    return new Of(c);
  }
  function Xf(a) {
    var b = Ga.apply(1, arguments);
    tf(a, b.length);
    if (b.length === 0) return jf(a[0]);
    var c = a[0].toLowerCase();
    if (/^data:/.test(c))
      throw Error(
        "Data URLs cannot have expressions in the template literal input."
      );
    if (/^https:\/\//.test(c) || /^\/\//.test(c)) {
      var d = c.indexOf("//") + 2;
      var e = c.indexOf("/", d);
      if (e <= d)
        throw Error(
          "Can't interpolate data in a url's origin, Please make sure to fully specify the origin, terminated with '/'."
        );
      d = c.substring(d, e);
      if (!/^[0-9a-z.:-]+$/i.test(d))
        throw Error("The origin contains unsupported characters.");
      if (!/^[^:]*(:[0-9]+)?$/i.test(d)) throw Error("Invalid port number.");
      if (!/(^|\.)[a-z][^.]*$/i.test(d))
        throw Error("The top-level domain must start with a letter.");
      d = !0;
    } else d = !1;
    if (!d)
      if (/^\//.test(c))
        if (c === "/" || (c.length > 1 && c[1] !== "/" && c[1] !== "\\"))
          d = !0;
        else throw Error("The path start in the url is invalid.");
      else d = !1;
    if (!(d = d || RegExp("^[^:\\s\\\\/]+/").test(c)))
      if (/^about:blank/.test(c)) {
        if (c !== "about:blank" && !/^about:blank#/.test(c))
          throw Error("The about url is invalid.");
        d = !0;
      } else d = !1;
    if (!d)
      throw Error(
        "Trying to interpolate expressions in an unsupported url format."
      );
    c = a[0];
    for (d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
    return jf(c);
  }
  function Yf(a, b, c, d) {
    function e(g, k) {
      g != null &&
        (Array.isArray(g)
          ? g.forEach(function (m) {
              return e(m, k);
            })
          : ((b += f + encodeURIComponent(k) + "=" + encodeURIComponent(g)),
            (f = "&")));
    }
    var f = b.length ? "&" : "?";
    d.constructor === Object && (d = Object.entries(d));
    Array.isArray(d)
      ? d.forEach(function (g) {
          return e(g[1], g[0]);
        })
      : d.forEach(e);
    return jf(a + b + c);
  }
  var Zf = function (a, b) {
    b = b === void 0 ? document : b;
    return b.createElement(String(a).toLowerCase());
  };
  var $f = (function () {
    if (!q.addEventListener || !Object.defineProperty) return !1;
    var a = !1,
      b = Object.defineProperty({}, "passive", {
        get: function () {
          a = !0;
        },
      });
    try {
      var c = function () {};
      q.addEventListener("test", c, b);
      q.removeEventListener("test", c, b);
    } catch (d) {}
    return a;
  })();
  var ag = function (a, b) {
    this.width = a;
    this.height = b;
  };
  h = ag.prototype;
  h.toString = function () {
    return "(" + this.width + " x " + this.height + ")";
  };
  h.aspectRatio = function () {
    return this.width / this.height;
  };
  h.ceil = function () {
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this;
  };
  h.floor = function () {
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this;
  };
  h.round = function () {
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this;
  };
  var dg = function (a) {
      return a ? new bg(cg(a)) : $a || ($a = new bg());
    },
    fg = function (a, b) {
      le(b, function (c, d) {
        d == "style"
          ? (a.style.cssText = c)
          : d == "class"
          ? (a.className = c)
          : d == "for"
          ? (a.htmlFor = c)
          : eg.hasOwnProperty(d)
          ? a.setAttribute(eg[d], c)
          : jb(d, "aria-") || jb(d, "data-")
          ? a.setAttribute(d, c)
          : (a[d] = c);
      });
    },
    eg = {
      cellpadding: "cellPadding",
      cellspacing: "cellSpacing",
      colspan: "colSpan",
      frameborder: "frameBorder",
      height: "height",
      maxlength: "maxLength",
      nonce: "nonce",
      role: "role",
      rowspan: "rowSpan",
      type: "type",
      usemap: "useMap",
      valign: "vAlign",
      width: "width",
    },
    gg = function () {
      var a = window.document;
      a = a.compatMode == "CSS1Compat" ? a.documentElement : a.body;
      return new ag(a.clientWidth, a.clientHeight);
    },
    ig = function (a, b, c) {
      return hg(document, arguments);
    },
    hg = function (a, b) {
      var c = b[1],
        d = jg(a, String(b[0]));
      c &&
        (typeof c === "string"
          ? (d.className = c)
          : Array.isArray(c)
          ? (d.className = c.join(" "))
          : fg(d, c));
      b.length > 2 && kg(a, d, b, 2);
      return d;
    },
    kg = function (a, b, c, d) {
      function e(k) {
        k && b.appendChild(typeof k === "string" ? a.createTextNode(k) : k);
      }
      for (; d < c.length; d++) {
        var f = c[d];
        if (!Qa(f) || (v(f) && f.nodeType > 0)) e(f);
        else {
          a: {
            if (f && typeof f.length == "number") {
              if (v(f)) {
                var g =
                  typeof f.item == "function" || typeof f.item == "string";
                break a;
              }
              if (typeof f === "function") {
                g = typeof f.item == "function";
                break a;
              }
            }
            g = !1;
          }
          D(g ? Vb(f) : f, e);
        }
      }
    },
    jg = function (a, b) {
      b = String(b);
      a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
      return a.createElement(b);
    },
    lg = function (a, b) {
      z(
        a != null && b != null,
        "goog.dom.appendChild expects non-null arguments"
      );
      a.appendChild(b);
    },
    mg = function (a, b) {
      kg(cg(a), a, arguments, 1);
    },
    ng = function (a) {
      for (var b; (b = a.firstChild); ) a.removeChild(b);
    },
    og = function (a) {
      return a && a.parentNode ? a.parentNode.removeChild(a) : null;
    },
    cg = function (a) {
      z(a, "Node cannot be null or undefined.");
      return a.nodeType == 9 ? a : a.ownerDocument || a.document;
    },
    pg = function (a, b) {
      a && (a = a.parentNode);
      for (var c = 0; a; ) {
        z(a.name != "parentNode");
        if (b(a)) return a;
        a = a.parentNode;
        c++;
      }
      return null;
    },
    bg = function (a) {
      this.g = a || q.document || document;
    };
  bg.prototype.getElement = function (a) {
    var b = this.g;
    return typeof a === "string" ? b.getElementById(a) : a;
  };
  var qg = function (a, b) {
    a = a.g;
    return (b = b && b != "*" ? String(b).toUpperCase() : "")
      ? a.querySelectorAll(b + "")
      : a.getElementsByTagName("*");
  };
  bg.prototype.h = function (a, b, c) {
    return hg(this.g, arguments);
  };
  var rg = function (a, b) {
    return jg(a.g, b);
  };
  bg.prototype.j = lg;
  bg.prototype.contains = function (a, b) {
    if (!a || !b) return !1;
    if (a.contains && b.nodeType == 1) return a == b || a.contains(b);
    if (typeof a.compareDocumentPosition != "undefined")
      return a == b || !!(a.compareDocumentPosition(b) & 16);
    for (; b && a != b; ) b = b.parentNode;
    return b == a;
  };
  var tg = function (a, b, c) {
      if (typeof b === "string") (b = sg(a, b)) && (a.style[b] = c);
      else
        for (var d in b) {
          c = a;
          var e = b[d],
            f = sg(c, d);
          f && (c.style[f] = e);
        }
    },
    ug = {},
    sg = function (a, b) {
      var c = ug[b];
      if (!c) {
        var d = Uf(b);
        c = d;
        a.style[d] === void 0 &&
          ((d = (hc ? "Webkit" : fc ? "Moz" : null) + Vf(d)),
          a.style[d] !== void 0 && (c = d));
        ug[b] = c;
      }
      return c;
    },
    vg = function (a) {
      typeof a == "number" && (a = Math.round(a) + "px");
      return a;
    },
    wg = function (a) {
      var b = a.offsetWidth,
        c = a.offsetHeight,
        d = hc && !b && !c;
      if ((b === void 0 || d) && a.getBoundingClientRect) {
        try {
          var e = a.getBoundingClientRect();
        } catch (f) {
          e = { left: 0, top: 0, right: 0, bottom: 0 };
        }
        a = e;
        return new ag(a.right - a.left, a.bottom - a.top);
      }
      return new ag(b, c);
    },
    xg = function (a) {
      var b = dg(),
        c = qg(b, "HEAD")[0];
      if (!c) {
        var d = qg(b, "BODY")[0];
        c = b.h("HEAD");
        d.parentNode.insertBefore(c, d);
      }
      d = b.h("STYLE");
      var e;
      (e = Mf("style", document)) && d.setAttribute("nonce", e);
      if (a instanceof Of) a = a.g;
      else
        throw Error(
          "Unexpected type when unwrapping SafeStyleSheet, got '" +
            a +
            "' of type '" +
            typeof a +
            "'"
        );
      if (q.trustedTypes)
        if (
          (z(
            d != null,
            "goog.dom.setTextContent expects a non-null value for node"
          ),
          "textContent" in d)
        )
          d.textContent = a;
        else if (d.nodeType == 3) d.data = String(a);
        else if (d.firstChild && d.firstChild.nodeType == 3) {
          for (; d.lastChild != d.firstChild; ) d.removeChild(z(d.lastChild));
          d.firstChild.data = String(a);
        } else ng(d), (e = cg(d)), d.appendChild(e.createTextNode(String(a)));
      else d.innerHTML = a;
      b.j(c, d);
      return d;
    },
    yg = function (a) {
      og(a.ownerNode || a.owningElement || a);
    },
    zg = function (a) {
      a = a.style;
      a.position = "relative";
      a.display = "inline-block";
    };
  function Ag(a, b) {
    typeof a.addEventListener === "function" &&
      a.addEventListener.call(a, "load", b, !1);
  }
  function Bg(a) {
    a && typeof a.dispose == "function" && a.dispose();
  }
  function Cg(a) {
    for (var b = 0, c = arguments.length; b < c; ++b) {
      var d = arguments[b];
      Qa(d) ? Cg.apply(null, d) : Bg(d);
    }
  }
  var L = function () {
    this.ga = this.ga;
    this.Z = this.Z;
  };
  L.prototype.ga = !1;
  L.prototype.isDisposed = function () {
    return this.ga;
  };
  L.prototype.dispose = function () {
    this.ga || ((this.ga = !0), this.D());
  };
  L.prototype[Symbol.dispose] = function () {
    this.dispose();
  };
  var Dg = function (a, b) {
    b = Wa(Bg, b);
    a.ga ? b() : (a.Z || (a.Z = []), a.Z.push(b));
  };
  L.prototype.D = function () {
    if (this.Z) for (; this.Z.length; ) this.Z.shift()();
  };
  var Eg = function (a, b, c, d, e, f, g) {
      var k = "";
      a && (k += a + ":");
      c && ((k += "//"), b && (k += b + "@"), (k += c), d && (k += ":" + d));
      e && (k += e);
      f && (k += "?" + f);
      g && (k += "#" + g);
      return k;
    },
    Fg = RegExp(
      "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
    ),
    Gg = function (a) {
      var b = a.indexOf("#");
      return b < 0 ? null : a.slice(b + 1);
    },
    Hg = function (a) {
      a = a.match(Fg);
      return Eg(a[1], a[2], a[3], a[4]);
    },
    Ig = function (a, b) {
      if (a) {
        a = a.split("&");
        for (var c = 0; c < a.length; c++) {
          var d = a[c].indexOf("="),
            e = null;
          if (d >= 0) {
            var f = a[c].substring(0, d);
            e = a[c].substring(d + 1);
          } else f = a[c];
          b(f, e ? Qf(e) : "");
        }
      }
    },
    Jg = /#|$/,
    Kg = function (a, b) {
      var c = a.search(Jg);
      a: {
        var d = 0;
        for (var e = b.length; (d = a.indexOf(b, d)) >= 0 && d < c; ) {
          var f = a.charCodeAt(d - 1);
          if (f == 38 || f == 63)
            if (
              ((f = a.charCodeAt(d + e)), !f || f == 61 || f == 38 || f == 35)
            )
              break a;
          d += e + 1;
        }
        d = -1;
      }
      if (d < 0) return null;
      e = a.indexOf("&", d);
      if (e < 0 || e > c) e = c;
      d += b.length + 1;
      return Qf(a.slice(d, e !== -1 ? e : 0));
    };
  Ze([1, 8, 9, 10, 11, 12, 2, 3, 4, 5, 15, 16, 19, 20, 21, 23]);
  Ze([1, 6, 7, 9, 10, 11, 12, 2, 3, 4, 5, 13, 14, 18, 19, 20, 21, 23]);
  Ze([1, 6, 7, 9, 10, 11, 12, 22, 2, 3, 4, 5, 13, 14, 17, 18, 19, 20, 21, 23]);
  new Ye();
  var Lg = function (a) {
      return a.W && typeof a.W == "function"
        ? a.W()
        : Qa(a) || typeof a === "string"
        ? a.length
        : ne(a);
    },
    Mg = function (a) {
      if (a.Y && typeof a.Y == "function") return a.Y();
      if (
        (typeof Map !== "undefined" && a instanceof Map) ||
        (typeof Set !== "undefined" && a instanceof Set)
      )
        return Array.from(a.values());
      if (typeof a === "string") return a.split("");
      if (Qa(a)) {
        for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
        return b;
      }
      return oe(a);
    },
    Ng = function (a) {
      if (a.Ea && typeof a.Ea == "function") return a.Ea();
      if (!a.Y || typeof a.Y != "function") {
        if (typeof Map !== "undefined" && a instanceof Map)
          return Array.from(a.keys());
        if (!(typeof Set !== "undefined" && a instanceof Set)) {
          if (Qa(a) || typeof a === "string") {
            var b = [];
            a = a.length;
            for (var c = 0; c < a; c++) b.push(c);
            return b;
          }
          b = [];
          c = 0;
          for (var d in a) b[c++] = d;
          return b;
        }
      }
    },
    Og = function (a, b) {
      if (a.contains && typeof a.contains == "function") a = a.contains(b);
      else if (a.Wa && typeof a.Wa == "function") a = a.Wa(b);
      else if (Qa(a) || typeof a === "string") a = Mb(a, b) >= 0;
      else
        a: {
          for (var c in a)
            if (a[c] == b) {
              a = !0;
              break a;
            }
          a = !1;
        }
      return a;
    },
    Pg = function (a, b, c) {
      if (typeof a.every == "function") return a.every(b, c);
      if (Qa(a) || typeof a === "string")
        return Array.prototype.every.call(a, b, c);
      for (var d = Ng(a), e = Mg(a), f = e.length, g = 0; g < f; g++)
        if (!b.call(c, e[g], d && d[g], a)) return !1;
      return !0;
    };
  var Qg = function (a) {
    this.j = this.A = this.l = "";
    this.B = null;
    this.o = this.g = "";
    this.v = !1;
    var b;
    a instanceof Qg
      ? ((this.v = a.v),
        Rg(this, a.l),
        (this.A = a.A),
        (this.j = a.j),
        Sg(this, a.B),
        (this.g = a.g),
        Tg(this, Ug(a.h)),
        (this.o = a.o))
      : a && (b = String(a).match(Fg))
      ? ((this.v = !1),
        Rg(this, b[1] || "", !0),
        (this.A = Vg(b[2] || "")),
        (this.j = Vg(b[3] || "", !0)),
        Sg(this, b[4]),
        (this.g = Vg(b[5] || "", !0)),
        Tg(this, b[6] || "", !0),
        (this.o = Vg(b[7] || "")))
      : ((this.v = !1), (this.h = new Wg(null, this.v)));
  };
  Qg.prototype.toString = function () {
    var a = [],
      b = this.l;
    b && a.push(Xg(b, Yg, !0), ":");
    var c = this.j;
    if (c || b == "file")
      a.push("//"),
        (b = this.A) && a.push(Xg(b, Yg, !0), "@"),
        a.push(
          encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")
        ),
        (c = this.B),
        c != null && a.push(":", String(c));
    if ((c = this.g))
      this.j && c.charAt(0) != "/" && a.push("/"),
        a.push(Xg(c, c.charAt(0) == "/" ? Zg : $g, !0));
    (c = this.h.toString()) && a.push("?", c);
    (c = this.o) && a.push("#", Xg(c, ah));
    return a.join("");
  };
  Qg.prototype.resolve = function (a) {
    var b = new Qg(this),
      c = !!a.l;
    c ? Rg(b, a.l) : (c = !!a.A);
    c ? (b.A = a.A) : (c = !!a.j);
    c ? (b.j = a.j) : (c = a.B != null);
    var d = a.g;
    if (c) Sg(b, a.B);
    else if ((c = !!a.g)) {
      if (d.charAt(0) != "/")
        if (this.j && !this.g) d = "/" + d;
        else {
          var e = b.g.lastIndexOf("/");
          e != -1 && (d = b.g.slice(0, e + 1) + d);
        }
      e = d;
      if (e == ".." || e == ".") d = "";
      else if (tb(e, "./") || tb(e, "/.")) {
        d = jb(e, "/");
        e = e.split("/");
        for (var f = [], g = 0; g < e.length; ) {
          var k = e[g++];
          k == "."
            ? d && g == e.length && f.push("")
            : k == ".."
            ? ((f.length > 1 || (f.length == 1 && f[0] != "")) && f.pop(),
              d && g == e.length && f.push(""))
            : (f.push(k), (d = !0));
        }
        d = f.join("/");
      } else d = e;
    }
    c ? (b.g = d) : (c = a.h.toString() !== "");
    c ? Tg(b, Ug(a.h)) : (c = !!a.o);
    c && (b.o = a.o);
    return b;
  };
  var Rg = function (a, b, c) {
      a.l = c ? Vg(b, !0) : b;
      a.l && (a.l = a.l.replace(/:$/, ""));
    },
    Sg = function (a, b) {
      if (b) {
        b = Number(b);
        if (isNaN(b) || b < 0) throw Error("Bad port number " + b);
        a.B = b;
      } else a.B = null;
    },
    Tg = function (a, b, c) {
      b instanceof Wg
        ? ((a.h = b), bh(a.h, a.v))
        : (c || (b = Xg(b, ch)), (a.h = new Wg(b, a.v)));
    },
    Vg = function (a, b) {
      return a
        ? b
          ? decodeURI(a.replace(/%25/g, "%2525"))
          : decodeURIComponent(a)
        : "";
    },
    Xg = function (a, b, c) {
      return typeof a === "string"
        ? ((a = encodeURI(a).replace(b, dh)),
          c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")),
          a)
        : null;
    },
    dh = function (a) {
      a = a.charCodeAt(0);
      return "%" + ((a >> 4) & 15).toString(16) + (a & 15).toString(16);
    },
    Yg = /[#\/\?@]/g,
    $g = /[#\?:]/g,
    Zg = /[#\?]/g,
    ch = /[#\?@]/g,
    ah = /#/g,
    Wg = function (a, b) {
      this.h = this.g = null;
      this.j = a || null;
      this.l = !!b;
    },
    eh = function (a) {
      a.g ||
        ((a.g = new Map()),
        (a.h = 0),
        a.j &&
          Ig(a.j, function (b, c) {
            a.add(Qf(b), c);
          }));
    };
  Wg.prototype.W = function () {
    eh(this);
    return this.h;
  };
  Wg.prototype.add = function (a, b) {
    eh(this);
    this.j = null;
    a = fh(this, a);
    var c = this.g.get(a);
    c || this.g.set(a, (c = []));
    c.push(b);
    this.h = db(this.h) + 1;
    return this;
  };
  var gh = function (a, b) {
    eh(a);
    b = fh(a, b);
    a.g.has(b) &&
      ((a.j = null), (a.h = db(a.h) - a.g.get(b).length), a.g.delete(b));
  };
  h = Wg.prototype;
  h.clear = function () {
    this.g = this.j = null;
    this.h = 0;
  };
  h.ia = function (a) {
    eh(this);
    a = fh(this, a);
    return this.g.has(a);
  };
  h.Wa = function (a) {
    var b = this.Y();
    return Mb(b, a) >= 0;
  };
  h.forEach = function (a, b) {
    eh(this);
    this.g.forEach(function (c, d) {
      c.forEach(function (e) {
        a.call(b, e, d, this);
      }, this);
    }, this);
  };
  h.Ea = function () {
    eh(this);
    for (
      var a = Array.from(this.g.values()),
        b = Array.from(this.g.keys()),
        c = [],
        d = 0;
      d < b.length;
      d++
    )
      for (var e = a[d], f = 0; f < e.length; f++) c.push(b[d]);
    return c;
  };
  h.Y = function (a) {
    eh(this);
    var b = [];
    if (typeof a === "string")
      this.ia(a) && (b = b.concat(this.g.get(fh(this, a))));
    else {
      a = Array.from(this.g.values());
      for (var c = 0; c < a.length; c++) b = b.concat(a[c]);
    }
    return b;
  };
  h.set = function (a, b) {
    eh(this);
    this.j = null;
    a = fh(this, a);
    this.ia(a) && (this.h = db(this.h) - this.g.get(a).length);
    this.g.set(a, [b]);
    this.h = db(this.h) + 1;
    return this;
  };
  h.get = function (a, b) {
    if (!a) return b;
    a = this.Y(a);
    return a.length > 0 ? String(a[0]) : b;
  };
  h.toString = function () {
    if (this.j) return this.j;
    if (!this.g) return "";
    for (var a = [], b = Array.from(this.g.keys()), c = 0; c < b.length; c++) {
      var d = b[c],
        e = encodeURIComponent(String(d));
      d = this.Y(d);
      for (var f = 0; f < d.length; f++) {
        var g = e;
        d[f] !== "" && (g += "=" + encodeURIComponent(String(d[f])));
        a.push(g);
      }
    }
    return (this.j = a.join("&"));
  };
  var Ug = function (a) {
      var b = new Wg();
      b.j = a.j;
      a.g && ((b.g = new Map(a.g)), (b.h = a.h));
      return b;
    },
    fh = function (a, b) {
      b = String(b);
      a.l && (b = b.toLowerCase());
      return b;
    },
    bh = function (a, b) {
      b &&
        !a.l &&
        (eh(a),
        (a.j = null),
        a.g.forEach(function (c, d) {
          var e = d.toLowerCase();
          d != e &&
            (gh(this, d),
            gh(this, e),
            c.length > 0 &&
              ((this.j = null),
              this.g.set(fh(this, e), Vb(c)),
              (this.h = db(this.h) + c.length)));
        }, a));
      a.l = b;
    };
  var hh,
    ih,
    jh,
    kh,
    lh,
    mh,
    nh = function () {
      return q.navigator ? q.navigator.userAgent : "";
    },
    oh = function (a) {
      return tb(nh(), a);
    },
    ph = oh("(iPad") || oh("(Macintosh") || oh("(iPod") || oh("(iPhone"),
    qh = oh("Android"),
    rh = function () {
      if (hh === void 0) {
        var a = /Android\s+([0-9.]+)/.exec(nh());
        hh = a && a.length == 2 ? a[1] : "";
      }
      return hh;
    },
    sh = function () {
      if (jh === void 0) {
        if (ph) {
          var a = oh("Safari");
          var b = new Qg(window.location.href).h.Y("js");
          a: {
            if ((b = b.length ? b[0] : "") && jb(b, "afma-")) {
              var c = b.lastIndexOf("v");
              if (
                c > -1 &&
                (b = b
                  .substr(c + 1)
                  .match(/^(\d+\.\d+\.\d+|^\d+\.\d+|^\d+)(-.*)?$/))
              ) {
                b = b[1];
                break a;
              }
            }
            b = "0.0.0";
          }
          if (!a || b !== "0.0.0") return (jh = !0);
        }
        jh = !1;
      }
      return jh;
    },
    th = function () {
      kh === void 0 && (kh = oh("afma-sdk-a") ? !0 : !1);
      return kh;
    },
    uh = function () {
      lh === void 0 && (lh = sh() || th());
      return lh;
    },
    wh = function (a) {
      var b = vh();
      return b ? ub(b, a) >= 0 : !1;
    },
    xh = function () {
      var a = vh();
      if (!a) return !1;
      a = lb(a).split(".");
      return a.length != 3 ? !1 : a[0].length < 5;
    },
    vh = function () {
      if (mh === void 0)
        if (th()) {
          var a = nh().match(/afma\-sdk\-a\-v\.?([\d+\.]+)/);
          mh = a ? a[1] : "";
        } else mh = "";
      return mh;
    };
  var yh = function (a, b) {
    this.o = Math.random() < a;
    this.A = b;
    this.h = null;
    this.v = "";
  };
  yh.prototype.isActive = function () {
    return this.o;
  };
  yh.prototype.j = function () {
    return this.isActive() && null !== this.h
      ? (
          this.A +
          "//pagead2.googlesyndication.com/pagead/gen_204/?id=" +
          this.h +
          this.v
        ).substring(0, 2e3)
      : "";
  };
  var zh = function () {},
    Ch = function (a) {
      Ah = a | 6;
      Bh(Ah);
    },
    Bh = function (a) {
      Dh(a, 2, 1);
      Dh(a, 1, 2);
      Dh(a, 4, 8);
      Dh(a, 8, 4);
      Dh(a, 128, 64);
      Dh(a, 64, 128);
      Dh(a, 256, 2);
    },
    Dh = function (a, b, c) {
      (a & b) == b && ((Ah |= b), (Ah &= ~c));
    };
  r("studio.common.Environment", zh);
  zh.Type = {
    LIVE: 1,
    LOCAL: 2,
    BROWSER: 4,
    IN_APP: 8,
    LAYOUTS_PREVIEW: 16,
    CREATIVE_TOOLSET: 32,
    RENDERING_STUDIO: 64,
    RENDERING_TEST: 128,
    PREVIEW: 256,
  };
  var Ah = 6;
  zh.addType = function (a) {
    Ah |= a;
    Bh(a);
  };
  zh.setType = Ch;
  var Eh = function (a) {
    return (Ah & a) == a;
  };
  zh.hasType = Eh;
  zh.getValue = function () {
    return Ah;
  };
  var Fh = function (a, b) {
    yh.call(this, a, b);
    this.l = this.g = null;
    this.h = "rmad_mod";
  };
  n(Fh, yh);
  Fh.prototype.j = function () {
    return null !== this.g && null !== this.l
      ? ((this.v = "&status=" + this.g + "&type=" + this.l),
        yh.prototype.j.call(this))
      : "";
  };
  var Gh = { Qf: "dcm", Cg: "studio", Mf: "clicktag" };
  var Hh = function () {
    this.g = Te("studio.sdk");
  };
  h = Hh.prototype;
  h.log = function (a, b) {
    Ve(this.g, a, b);
  };
  h.tf = function (a) {
    Ve(this.g, ye, a);
  };
  h.eb = function (a) {
    We(this.g, a);
  };
  h.P = function (a) {
    J(this.g, a);
  };
  h.info = function (a) {
    K(this.g, a);
  };
  h.config = function (a) {
    Ve(this.g, Ce, a);
  };
  h.Qa = function (a) {
    Xe(this.g, a);
  };
  h.he = function (a) {
    Ve(this.g, Ee, a);
  };
  h.ie = function (a) {
    Ve(this.g, Fe, a);
  };
  var M = new Hh();
  r("studio.sdk.logger", M);
  r("studio.sdk.logger.setLevel", function (a, b) {
    Ue(a, b);
  });
  r("studio.sdk.logger.Level.OFF", xe);
  r("studio.sdk.logger.Level.SHOUT", ye);
  r("studio.sdk.logger.Level.SEVERE", ze);
  r("studio.sdk.logger.Level.WARNING", Ae);
  r("studio.sdk.logger.Level.INFO", Be);
  r("studio.sdk.logger.Level.CONFIG", Ce);
  r("studio.sdk.logger.Level.FINE", De);
  r("studio.sdk.logger.Level.FINER", Ee);
  r("studio.sdk.logger.Level.FINEST", Fe);
  r("studio.sdk.logger.Level.ALL", Ge);
  r("studio.sdk.logger.log", M.log);
  r("studio.sdk.logger.shout", M.tf);
  r("studio.sdk.logger.severe", M.eb);
  r("studio.sdk.logger.warning", M.P);
  r("studio.sdk.logger.info", M.info);
  r("studio.sdk.logger.config", M.config);
  r("studio.sdk.logger.fine", M.Qa);
  r("studio.sdk.logger.finer", M.he);
  r("studio.sdk.logger.finest", M.ie);
  var Ih = {
    ENABLER: "enabler",
    DCM_ENABLER: "dcmenabler",
    SSR_ENABLER: "ssrenabler",
    CLICK_TAG_ENABLER: "clicktagenabler",
    ENABLER_LOADER: "enablerloader",
    DCM_ENABLER_LOADER: "dcmenablerloader",
    CLICK_TAG_ENABLER_LOADER: "clicktagenablerloader",
    VIDEO: "video",
    CONFIGURABLE: "configurable",
    CONFIGURABLE_FILLER: "configurablefiller",
    LAYOUTS: "layouts",
    FILLER: "layoutsfiller",
    RAD_VIDEO: "rad_ui_video",
    GDN: "gdn",
  };
  r("studio.module.ModuleId", Ih);
  var Jh =
    typeof AsyncContext !== "undefined" &&
    typeof AsyncContext.Snapshot === "function"
      ? function (a) {
          return a && AsyncContext.Snapshot.wrap(a);
        }
      : function (a) {
          return a;
        };
  var Kh = function (a, b) {
    this.j = a;
    this.l = b;
    this.h = 0;
    this.g = null;
  };
  Kh.prototype.get = function () {
    if (this.h > 0) {
      this.h--;
      var a = this.g;
      this.g = a.next;
      a.next = null;
    } else a = this.j();
    return a;
  };
  var Lh = function (a, b) {
    a.l(b);
    a.h < 100 && (a.h++, (b.next = a.g), (a.g = b));
  };
  var Mh = function () {
    this.h = this.g = null;
  };
  Mh.prototype.add = function (a, b) {
    var c = Nh.get();
    c.set(a, b);
    this.h ? (this.h.next = c) : (z(!this.g), (this.g = c));
    this.h = c;
  };
  var Ph = function () {
      var a = Oh,
        b = null;
      a.g &&
        ((b = a.g), (a.g = a.g.next), a.g || (a.h = null), (b.next = null));
      return b;
    },
    Nh = new Kh(
      function () {
        return new Qh();
      },
      function (a) {
        return a.reset();
      }
    ),
    Qh = function () {
      this.next = this.scope = this.g = null;
    };
  Qh.prototype.set = function (a, b) {
    this.g = a;
    this.scope = b;
    this.next = null;
  };
  Qh.prototype.reset = function () {
    this.next = this.scope = this.g = null;
  };
  var Rh =
      q.console && q.console.createTask
        ? q.console.createTask.bind(q.console)
        : void 0,
    Sh = Rh ? Symbol("consoleTask") : void 0;
  function Th(a, b) {
    function c() {
      var k = Ga.apply(0, arguments),
        m = this;
      return g.run(function () {
        return a.call.apply(a, [m].concat(na(k)));
      });
    }
    b = b === void 0 ? "anonymous" : b;
    if (Sh && a[Sh]) return a;
    var d = a,
      e,
      f = (e = Uh) == null ? void 0 : e();
    a = function () {
      var k = Ga.apply(0, arguments),
        m,
        p = (m = Uh) == null ? void 0 : m();
      if (f !== p)
        throw Error(
          b +
            " was scheduled in '" +
            f +
            "' but called in '" +
            p +
            "'.\nMake sure your test awaits all async calls.\n\nTIP: To help investigate, debug the test in Chrome and look at the async portion\nof the call stack to see what originally scheduled the callback.  Then, make the\ntest wait for the relevant asynchronous work to finish."
        );
      return d.call.apply(d, [this].concat(na(k)));
    };
    if (!Rh) return a;
    var g = Rh(a.name || b);
    c[A(Sh)] = g;
    return c;
  }
  var Uh;
  var Vh,
    Wh = !1,
    Oh = new Mh(),
    Yh = function (a, b) {
      a = Th(a, "goog.async.run");
      Vh || Xh();
      Wh || (Vh(), (Wh = !0));
      Oh.add(a, b);
    },
    Xh = function () {
      var a = Promise.resolve(void 0);
      Vh = function () {
        a.then(Zh);
      };
    };
  function Zh() {
    for (var a; (a = Ph()); ) {
      try {
        a.g.call(a.scope);
      } catch (b) {
        ib(b);
      }
      Lh(Nh, a);
    }
    Wh = !1;
  }
  var $h = function (a) {
    if (!a) return !1;
    try {
      return !!a.$goog_Thenable;
    } catch (b) {
      return !1;
    }
  };
  var ci = function (a) {
      this.g = 0;
      this.A = void 0;
      this.l = this.h = this.j = null;
      this.v = this.o = !1;
      if (a != af)
        try {
          var b = this;
          a.call(
            void 0,
            function (c) {
              ai(b, 2, c);
            },
            function (c) {
              if (!(c instanceof bi))
                try {
                  if (c instanceof Error) throw c;
                  throw Error("Promise rejected.");
                } catch (d) {}
              ai(b, 3, c);
            }
          );
        } catch (c) {
          ai(this, 3, c);
        }
    },
    di = function () {
      this.next = this.context = this.j = this.h = this.g = null;
      this.l = !1;
    };
  di.prototype.reset = function () {
    this.context = this.j = this.h = this.g = null;
    this.l = !1;
  };
  var ei = new Kh(
      function () {
        return new di();
      },
      function (a) {
        a.reset();
      }
    ),
    fi = function (a, b, c) {
      var d = ei.get();
      d.h = a;
      d.j = b;
      d.context = c;
      return d;
    },
    gi = function (a) {
      if (a instanceof ci) return a;
      var b = new ci(af);
      ai(b, 2, a);
      return b;
    },
    hi = function (a) {
      return new ci(function (b, c) {
        c(a);
      });
    },
    ji = function (a, b, c) {
      ii(a, b, c, null) || Yh(Wa(b, a));
    },
    ki = function (a) {
      return new ci(function (b, c) {
        var d = a.length,
          e = [];
        if (d)
          for (
            var f = function (p, t) {
                d--;
                e[p] = t;
                d == 0 && b(e);
              },
              g = function (p) {
                c(p);
              },
              k,
              m = 0;
            m < a.length;
            m++
          )
            (k = a[m]), ji(k, Wa(f, m), g);
        else b(e);
      });
    };
  ci.prototype.then = function (a, b, c) {
    a != null && fb(a, "opt_onFulfilled should be a function.");
    b != null &&
      fb(
        b,
        "opt_onRejected should be a function. Did you pass opt_context as the second argument instead of the third?"
      );
    return li(
      this,
      Jh(typeof a === "function" ? a : null),
      Jh(typeof b === "function" ? b : null),
      c
    );
  };
  ci.prototype.$goog_Thenable = !0;
  var mi = function (a, b) {
    return li(a, null, Jh(b));
  };
  ci.prototype.cancel = function (a) {
    if (this.g == 0) {
      var b = new bi(a);
      Yh(function () {
        ni(this, b);
      }, this);
    }
  };
  var ni = function (a, b) {
      if (a.g == 0)
        if (a.j) {
          var c = a.j;
          if (c.h) {
            for (
              var d = 0, e = null, f = null, g = c.h;
              g && (g.l || (d++, g.g == a && (e = g), !(e && d > 1)));
              g = g.next
            )
              e || (f = g);
            e &&
              (c.g == 0 && d == 1
                ? ni(c, b)
                : (f
                    ? ((d = f),
                      z(c.h),
                      z(d != null),
                      d.next == c.l && (c.l = d),
                      (d.next = d.next.next))
                    : oi(c),
                  pi(c, e, 3, b)));
          }
          a.j = null;
        } else ai(a, 3, b);
    },
    ri = function (a, b) {
      a.h || (a.g != 2 && a.g != 3) || qi(a);
      z(b.h != null);
      a.l ? (a.l.next = b) : (a.h = b);
      a.l = b;
    },
    li = function (a, b, c, d) {
      b && (b = Th(b, "goog.Promise.then"));
      c && (c = Th(c, "goog.Promise.then"));
      var e = fi(null, null, null);
      e.g = new ci(function (f, g) {
        e.h = b
          ? function (k) {
              try {
                var m = b.call(d, k);
                f(m);
              } catch (p) {
                g(p);
              }
            }
          : f;
        e.j = c
          ? function (k) {
              try {
                var m = c.call(d, k);
                m === void 0 && k instanceof bi ? g(k) : f(m);
              } catch (p) {
                g(p);
              }
            }
          : g;
      });
      e.g.j = a;
      ri(a, e);
      return e.g;
    };
  ci.prototype.C = function (a) {
    z(this.g == 1);
    this.g = 0;
    ai(this, 2, a);
  };
  ci.prototype.F = function (a) {
    z(this.g == 1);
    this.g = 0;
    ai(this, 3, a);
  };
  var ai = function (a, b, c) {
      a.g == 0 &&
        (a === c &&
          ((b = 3), (c = new TypeError("Promise cannot resolve to itself"))),
        (a.g = 1),
        ii(c, a.C, a.F, a) ||
          ((a.A = c),
          (a.g = b),
          (a.j = null),
          qi(a),
          b != 3 || c instanceof bi || si(a, c)));
    },
    ii = function (a, b, c, d) {
      if (a instanceof ci)
        return (
          b != null && fb(b, "opt_onFulfilled should be a function."),
          c != null &&
            fb(
              c,
              "opt_onRejected should be a function. Did you pass opt_context as the second argument instead of the third?"
            ),
          ri(a, fi(b || af, c || null, d)),
          !0
        );
      if ($h(a)) return a.then(b, c, d), !0;
      if (v(a))
        try {
          var e = a.then;
          if (typeof e === "function") return ti(a, e, b, c, d), !0;
        } catch (f) {
          return c.call(d, f), !0;
        }
      return !1;
    },
    ti = function (a, b, c, d, e) {
      var f = !1,
        g = function (m) {
          f || ((f = !0), c.call(e, m));
        },
        k = function (m) {
          f || ((f = !0), d.call(e, m));
        };
      try {
        b.call(a, g, k);
      } catch (m) {
        k(m);
      }
    },
    qi = function (a) {
      a.o || ((a.o = !0), Yh(a.B, a));
    },
    oi = function (a) {
      var b = null;
      a.h && ((b = a.h), (a.h = b.next), (b.next = null));
      a.h || (a.l = null);
      b != null && z(b.h != null);
      return b;
    };
  ci.prototype.B = function () {
    for (var a; (a = oi(this)); ) pi(this, a, this.g, this.A);
    this.o = !1;
  };
  var pi = function (a, b, c, d) {
      if (c == 3 && b.j && !b.l) for (; a && a.v; a = a.j) a.v = !1;
      if (b.g) (b.g.j = null), ui(b, c, d);
      else
        try {
          b.l ? b.h.call(b.context) : ui(b, c, d);
        } catch (e) {
          vi.call(null, e);
        }
      Lh(ei, b);
    },
    ui = function (a, b, c) {
      b == 2 ? a.h.call(a.context, c) : a.j && a.j.call(a.context, c);
    },
    si = function (a, b) {
      a.v = !0;
      Yh(function () {
        a.v && vi.call(null, b);
      });
    },
    vi = ib,
    bi = function (a) {
      Za.call(this, a);
    };
  y(bi, Za);
  bi.prototype.name = "cancel"; /*

 Copyright 2005, 2007 Bob Ippolito. All Rights Reserved.
 Copyright The Closure Library Authors.
 SPDX-License-Identifier: MIT
*/
  var N = function (a, b) {
    this.A = [];
    this.J = a;
    this.G = b || null;
    this.l = this.g = !1;
    this.j = void 0;
    this.F = this.Z = this.C = !1;
    this.B = 0;
    this.h = null;
    this.v = 0;
  };
  N.prototype.cancel = function (a) {
    if (this.g) this.j instanceof N && this.j.cancel();
    else {
      if (this.h) {
        var b = this.h;
        delete this.h;
        a ? b.cancel(a) : (b.v--, b.v <= 0 && b.cancel());
      }
      this.J ? this.J.call(this.G, this) : (this.F = !0);
      this.g || this.o(new wi(this));
    }
  };
  N.prototype.ga = function (a, b) {
    this.C = !1;
    xi(this, a, b);
  };
  var xi = function (a, b, c) {
      a.g = !0;
      a.j = c;
      a.l = !b;
      yi(a);
    },
    Ai = function (a) {
      if (a.g) {
        if (!a.F) throw new zi(a);
        a.F = !1;
      }
    };
  N.prototype.callback = function (a) {
    Ai(this);
    Bi(a);
    xi(this, !0, a);
  };
  N.prototype.o = function (a) {
    Ai(this);
    Bi(a);
    xi(this, !1, a);
  };
  var Bi = function (a) {
      z(
        !(a instanceof N),
        "An execution sequence may not be initiated with a blocking Deferred."
      );
    },
    Di = function (a, b, c) {
      Ci(a, b, null, c);
    },
    Ci = function (a, b, c, d) {
      z(!a.Z, "Blocking Deferreds can not be re-used");
      var e = a.g;
      e || (b === c ? (b = c = Jh(b)) : ((b = Jh(b)), (c = Jh(c))));
      a.A.push([b, c, d]);
      e && yi(a);
    };
  N.prototype.then = function (a, b, c) {
    var d,
      e,
      f = new ci(function (g, k) {
        e = g;
        d = k;
      });
    Ci(
      this,
      e,
      function (g) {
        g instanceof wi ? f.cancel() : d(g);
        return Ei;
      },
      this
    );
    return f.then(a, b, c);
  };
  N.prototype.$goog_Thenable = !0;
  var Fi = function (a, b) {
    b instanceof N
      ? Di(a, x(b.I, b))
      : Di(a, function () {
          return b;
        });
  };
  N.prototype.I = function (a) {
    var b = new N();
    Ci(this, b.callback, b.o, b);
    a && ((b.h = this), this.v++);
    return b;
  };
  var Gi = function (a) {
      return Pb(a.A, function (b) {
        return typeof b[1] === "function";
      });
    },
    Ei = {},
    yi = function (a) {
      if (a.B && a.g && Gi(a)) {
        var b = a.B,
          c = Hi[b];
        c && (q.clearTimeout(c.g), delete Hi[b]);
        a.B = 0;
      }
      a.h && (a.h.v--, delete a.h);
      b = a.j;
      for (var d = (c = !1); a.A.length && !a.C; ) {
        var e = a.A.shift(),
          f = e[0],
          g = e[1];
        e = e[2];
        if ((f = a.l ? g : f))
          try {
            var k = f.call(e || a.G, b);
            k === Ei && (k = void 0);
            k !== void 0 &&
              ((a.l = a.l && (k == b || k instanceof Error)), (a.j = b = k));
            if (
              $h(b) ||
              (typeof q.Promise === "function" && b instanceof q.Promise)
            )
              (d = !0), (a.C = !0);
          } catch (m) {
            (b = m), (a.l = !0), Gi(a) || (c = !0);
          }
      }
      a.j = b;
      d &&
        ((k = x(a.ga, a, !0)),
        (d = x(a.ga, a, !1)),
        b instanceof N ? (Ci(b, k, d), (b.Z = !0)) : b.then(k, d));
      c && ((b = new Ii(b)), (Hi[b.g] = b), (a.B = b.g));
    },
    zi = function () {
      Za.call(this);
    };
  y(zi, Za);
  zi.prototype.message = "Deferred has already fired";
  zi.prototype.name = "AlreadyCalledError";
  var wi = function () {
    Za.call(this);
  };
  y(wi, Za);
  wi.prototype.message = "Deferred was canceled";
  wi.prototype.name = "CanceledError";
  var Ii = function (a) {
    this.g = q.setTimeout(x(this.j, this), 0);
    this.h = a;
  };
  Ii.prototype.j = function () {
    z(Hi[this.g], "Cannot throw an error that is not scheduled.");
    delete Hi[this.g];
    throw this.h;
  };
  var Hi = {};
  var Oi = function (a) {
      var b = {},
        c = b.document || document,
        d = kf(a).toString(),
        e = rg(new bg(c), "SCRIPT"),
        f = { nd: e, ud: void 0 },
        g = new N(Ki, f),
        k = null,
        m = b.timeout != null ? b.timeout : 5e3;
      m > 0 &&
        ((k = window.setTimeout(function () {
          Li(e, !0);
          g.o(new Mi(1, "Timeout reached for loading script " + d));
        }, m)),
        (f.ud = k));
      e.onload = e.onreadystatechange = function () {
        (e.readyState &&
          e.readyState != "loaded" &&
          e.readyState != "complete") ||
          (Li(e, b.Hg || !1, k), g.callback(null));
      };
      e.onerror = function () {
        Li(e, !0, k);
        g.o(new Mi(0, "Error while loading script " + d));
      };
      f = b.attributes || {};
      ue(f, { type: "text/javascript", charset: "UTF-8" });
      fg(e, f);
      Nf(e, a);
      Ni(c).appendChild(e);
      return g;
    },
    Ni = function (a) {
      var b;
      return (b = (a || document).getElementsByTagName("HEAD")) &&
        b.length !== 0
        ? b[0]
        : a.documentElement;
    },
    Ki = function () {
      if (this && this.nd) {
        var a = this.nd;
        a && a.tagName == "SCRIPT" && Li(a, !0, this.ud);
      }
    },
    Li = function (a, b, c) {
      c != null && q.clearTimeout(c);
      a.onload = function () {};
      a.onerror = function () {};
      a.onreadystatechange = function () {};
      b &&
        window.setTimeout(function () {
          og(a);
        }, 0);
    },
    Mi = function (a, b) {
      var c = "Jsloader error (code #" + a + ")";
      b && (c += ": " + b);
      Za.call(this, c);
      this.code = a;
    };
  y(Mi, Za);
  var Pi = function (a, b) {
    this.g = a[q.Symbol.iterator]();
    this.h = b;
  };
  Pi.prototype[Symbol.iterator] = function () {
    return this;
  };
  Pi.prototype.next = function () {
    var a = this.g.next();
    return {
      value: a.done ? void 0 : this.h.call(void 0, a.value),
      done: a.done,
    };
  };
  var Qi = function (a, b) {
    return new Pi(a, b);
  };
  var Ri = function () {};
  Ri.prototype.next = function () {
    return Si;
  };
  var Si = ve({ done: !0, value: void 0 });
  Ri.prototype.xa = function () {
    return this;
  };
  var Wi = function (a) {
      if (a instanceof Ti || a instanceof Ui || a instanceof Vi) return a;
      if (typeof a.next == "function")
        return new Ti(function () {
          return a;
        });
      if (typeof a[Symbol.iterator] == "function")
        return new Ti(function () {
          return a[Symbol.iterator]();
        });
      if (typeof a.xa == "function")
        return new Ti(function () {
          return a.xa();
        });
      throw Error("Not an iterator or iterable.");
    },
    Ti = function (a) {
      this.g = a;
    };
  Ti.prototype.xa = function () {
    return new Ui(this.g());
  };
  Ti.prototype[Symbol.iterator] = function () {
    return new Vi(this.g());
  };
  Ti.prototype.h = function () {
    return new Vi(this.g());
  };
  var Ui = function (a) {
    this.g = a;
  };
  n(Ui, Ri);
  Ui.prototype.next = function () {
    return this.g.next();
  };
  Ui.prototype[Symbol.iterator] = function () {
    return new Vi(this.g);
  };
  Ui.prototype.h = function () {
    return new Vi(this.g);
  };
  var Vi = function (a) {
    Ti.call(this, function () {
      return a;
    });
    this.j = a;
  };
  n(Vi, Ti);
  Vi.prototype.next = function () {
    return this.j.next();
  };
  var O = function (a, b) {
    this.h = {};
    this.g = [];
    this.j = this.size = 0;
    var c = arguments.length;
    if (c > 1) {
      if (c % 2) throw Error("Uneven number of arguments");
      for (var d = 0; d < c; d += 2) this.set(arguments[d], arguments[d + 1]);
    } else if (a)
      if (a instanceof O)
        for (c = a.Ea(), d = 0; d < c.length; d++) this.set(c[d], a.get(c[d]));
      else for (d in a) this.set(d, a[d]);
  };
  h = O.prototype;
  h.W = function () {
    return this.size;
  };
  h.Y = function () {
    Xi(this);
    for (var a = [], b = 0; b < this.g.length; b++) a.push(this.h[this.g[b]]);
    return a;
  };
  h.Ea = function () {
    Xi(this);
    return this.g.concat();
  };
  h.ia = function (a) {
    return this.has(a);
  };
  h.has = function (a) {
    return Yi(this.h, a);
  };
  h.Wa = function (a) {
    for (var b = 0; b < this.g.length; b++) {
      var c = this.g[b];
      if (Yi(this.h, c) && this.h[c] == a) return !0;
    }
    return !1;
  };
  h.equals = function (a, b) {
    if (this === a) return !0;
    if (this.size != a.W()) return !1;
    b = b || Zi;
    Xi(this);
    for (var c, d = 0; (c = this.g[d]); d++)
      if (!b(this.get(c), a.get(c))) return !1;
    return !0;
  };
  var Zi = function (a, b) {
    return a === b;
  };
  O.prototype.clear = function () {
    this.h = {};
    this.j = this.size = this.g.length = 0;
  };
  O.prototype.delete = function (a) {
    return Yi(this.h, a)
      ? (delete this.h[a],
        --this.size,
        this.j++,
        this.g.length > 2 * this.size && Xi(this),
        !0)
      : !1;
  };
  var Xi = function (a) {
    if (a.size != a.g.length) {
      for (var b = 0, c = 0; b < a.g.length; ) {
        var d = a.g[b];
        Yi(a.h, d) && (a.g[c++] = d);
        b++;
      }
      a.g.length = c;
    }
    if (a.size != a.g.length) {
      b = {};
      for (d = c = 0; c < a.g.length; ) {
        var e = a.g[c];
        Yi(b, e) || ((a.g[d++] = e), (b[e] = 1));
        c++;
      }
      a.g.length = d;
    }
  };
  h = O.prototype;
  h.get = function (a, b) {
    return Yi(this.h, a) ? this.h[a] : b;
  };
  h.set = function (a, b) {
    Yi(this.h, a) || ((this.size += 1), this.g.push(a), this.j++);
    this.h[a] = b;
  };
  h.forEach = function (a, b) {
    for (var c = this.Ea(), d = 0; d < c.length; d++) {
      var e = c[d],
        f = this.get(e);
      a.call(b, f, e, this);
    }
  };
  h.keys = function () {
    return Wi(this.xa(!0)).h();
  };
  h.values = function () {
    return Wi(this.xa(!1)).h();
  };
  h.entries = function () {
    var a = this;
    return Qi(this.keys(), function (b) {
      return [b, a.get(b)];
    });
  };
  h.xa = function (a) {
    Xi(this);
    var b = 0,
      c = this.j,
      d = this,
      e = new Ri();
    e.next = function () {
      if (c != d.j)
        throw Error("The map has changed since the iterator was created");
      if (b >= d.g.length) return Si;
      var f = d.g[b++];
      return { value: a ? f : d.h[f], done: !1 };
    };
    return e;
  };
  var Yi = function (a, b) {
    return Object.prototype.hasOwnProperty.call(a, b);
  };
  var $i = function (a, b) {
    this.type = a;
    this.g = this.target = b;
    this.defaultPrevented = this.h = !1;
  };
  $i.prototype.stopPropagation = function () {
    this.h = !0;
  };
  $i.prototype.j = function () {
    this.defaultPrevented = !0;
  };
  var aj = function (a) {
    a.j();
  };
  var bj = function (a, b) {
    $i.call(this, a ? a.type : "");
    this.relatedTarget = this.g = this.target = null;
    this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0;
    this.key = "";
    this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
    this.state = null;
    this.pointerId = 0;
    this.pointerType = "";
    this.timeStamp = 0;
    this.ba = null;
    a && this.init(a, b);
  };
  y(bj, $i);
  bj.prototype.init = function (a, b) {
    var c = (this.type = a.type),
      d =
        a.changedTouches && a.changedTouches.length
          ? a.changedTouches[0]
          : null;
    this.target = a.target || a.srcElement;
    this.g = b;
    b = a.relatedTarget;
    b ||
      (c == "mouseover"
        ? (b = a.fromElement)
        : c == "mouseout" && (b = a.toElement));
    this.relatedTarget = b;
    d
      ? ((this.clientX = d.clientX !== void 0 ? d.clientX : d.pageX),
        (this.clientY = d.clientY !== void 0 ? d.clientY : d.pageY),
        (this.screenX = d.screenX || 0),
        (this.screenY = d.screenY || 0))
      : ((this.clientX = a.clientX !== void 0 ? a.clientX : a.pageX),
        (this.clientY = a.clientY !== void 0 ? a.clientY : a.pageY),
        (this.screenX = a.screenX || 0),
        (this.screenY = a.screenY || 0));
    this.button = a.button;
    this.key = a.key || "";
    this.ctrlKey = a.ctrlKey;
    this.altKey = a.altKey;
    this.shiftKey = a.shiftKey;
    this.metaKey = a.metaKey;
    this.pointerId = a.pointerId || 0;
    this.pointerType = a.pointerType;
    this.state = a.state;
    this.timeStamp = a.timeStamp;
    this.ba = a;
    a.defaultPrevented && bj.R.j.call(this);
  };
  bj.prototype.stopPropagation = function () {
    bj.R.stopPropagation.call(this);
    this.ba.stopPropagation
      ? this.ba.stopPropagation()
      : (this.ba.cancelBubble = !0);
  };
  bj.prototype.j = function () {
    bj.R.j.call(this);
    var a = this.ba;
    a.preventDefault ? a.preventDefault() : (a.returnValue = !1);
  };
  bj.prototype.me = function () {
    return this.ba;
  };
  var cj = "closure_listenable_" + ((Math.random() * 1e6) | 0),
    dj = function (a) {
      return !(!a || !a[cj]);
    };
  var ej = 0;
  var fj = function (a, b, c, d, e) {
      this.listener = a;
      this.proxy = null;
      this.src = b;
      this.type = c;
      this.capture = !!d;
      this.handler = e;
      this.key = ++ej;
      this.cb = this.pb = !1;
    },
    gj = function (a) {
      a.cb = !0;
      a.listener = null;
      a.proxy = null;
      a.src = null;
      a.handler = null;
    };
  function hj(a) {
    this.src = a;
    this.g = {};
    this.h = 0;
  }
  hj.prototype.add = function (a, b, c, d, e) {
    var f = a.toString();
    a = this.g[f];
    a || ((a = this.g[f] = []), this.h++);
    var g = ij(a, b, d, e);
    g > -1
      ? ((b = a[g]), c || (b.pb = !1))
      : ((b = new fj(b, this.src, f, !!d, e)), (b.pb = c), a.push(b));
    return b;
  };
  var jj = function (a, b) {
      var c = b.type;
      if (!(c in a.g)) return !1;
      var d = Sb(a.g[c], b);
      d && (gj(b), a.g[c].length == 0 && (delete a.g[c], a.h--));
      return d;
    },
    kj = function (a, b) {
      b = b && b.toString();
      var c = 0,
        d;
      for (d in a.g)
        if (!b || d == b) {
          for (var e = a.g[d], f = 0; f < e.length; f++) ++c, gj(e[f]);
          delete a.g[d];
          a.h--;
        }
    },
    lj = function (a, b, c, d, e) {
      a = a.g[b.toString()];
      b = -1;
      a && (b = ij(a, c, d, e));
      return b > -1 ? a[b] : null;
    },
    mj = function (a, b) {
      var c = b !== void 0,
        d = c ? b.toString() : "";
      return me(a.g, function (e) {
        for (var f = 0; f < e.length; ++f) if (!c || e[f].type == d) return !0;
        return !1;
      });
    },
    ij = function (a, b, c, d) {
      for (var e = 0; e < a.length; ++e) {
        var f = a[e];
        if (!f.cb && f.listener == b && f.capture == !!c && f.handler == d)
          return e;
      }
      return -1;
    };
  var nj = "closure_lm_" + ((Math.random() * 1e6) | 0),
    oj = {},
    pj = 0,
    rj = function (a, b, c, d, e) {
      if (d && d.once) return qj(a, b, c, d, e);
      if (Array.isArray(b)) {
        for (var f = 0; f < b.length; f++) rj(a, b[f], c, d, e);
        return null;
      }
      c = sj(c);
      return dj(a)
        ? a.Ja(b, c, v(d) ? !!d.capture : !!d, e)
        : tj(a, b, c, !1, d, e);
    },
    tj = function (a, b, c, d, e, f) {
      if (!b) throw Error("Invalid event type");
      var g = v(e) ? !!e.capture : !!e,
        k = uj(a);
      k || (a[nj] = k = new hj(a));
      c = k.add(b, c, d, g, f);
      if (c.proxy) return c;
      d = vj();
      c.proxy = d;
      d.src = a;
      d.listener = c;
      if (a.addEventListener)
        $f || (e = g),
          e === void 0 && (e = !1),
          a.addEventListener(b.toString(), d, e);
      else if (a.attachEvent) a.attachEvent(wj(b.toString()), d);
      else if (a.addListener && a.removeListener)
        z(b === "change", "MediaQueryList only has a change event"),
          a.addListener(d);
      else throw Error("addEventListener and attachEvent are unavailable.");
      pj++;
      return c;
    },
    vj = function () {
      var a = xj,
        b = function (c) {
          return a.call(b.src, b.listener, c);
        };
      return b;
    },
    qj = function (a, b, c, d, e) {
      if (Array.isArray(b)) {
        for (var f = 0; f < b.length; f++) qj(a, b[f], c, d, e);
        return null;
      }
      c = sj(c);
      return dj(a)
        ? a.v.add(String(b), c, !0, v(d) ? !!d.capture : !!d, e)
        : tj(a, b, c, !0, d, e);
    },
    yj = function (a, b, c, d, e) {
      if (Array.isArray(b))
        for (var f = 0; f < b.length; f++) yj(a, b[f], c, d, e);
      else
        (d = v(d) ? !!d.capture : !!d),
          (c = sj(c)),
          dj(a)
            ? a.Sa(b, c, d, e)
            : a && (a = uj(a)) && (b = lj(a, b, c, d, e)) && zj(b);
    },
    zj = function (a) {
      if (typeof a === "number" || !a || a.cb) return !1;
      var b = a.src;
      if (dj(b)) return jj(b.v, a);
      var c = a.type,
        d = a.proxy;
      b.removeEventListener
        ? b.removeEventListener(c, d, a.capture)
        : b.detachEvent
        ? b.detachEvent(wj(c), d)
        : b.addListener && b.removeListener && b.removeListener(d);
      pj--;
      (c = uj(b))
        ? (jj(c, a), c.h == 0 && ((c.src = null), (b[nj] = null)))
        : gj(a);
      return !0;
    },
    Aj = function (a, b, c, d, e) {
      c = sj(c);
      d = !!d;
      return dj(a)
        ? lj(a.v, String(b), c, d, e)
        : a
        ? (a = uj(a))
          ? lj(a, b, c, d, e)
          : null
        : null;
    },
    Bj = function (a, b) {
      if (dj(a)) return mj(a.v, b !== void 0 ? String(b) : void 0);
      a = uj(a);
      return !!a && mj(a, b);
    },
    wj = function (a) {
      return a in oj ? oj[a] : (oj[a] = "on" + a);
    },
    xj = function (a, b) {
      if (a.cb) a = !0;
      else {
        b = new bj(b, this);
        var c = a.listener,
          d = a.handler || a.src;
        a.pb && zj(a);
        a = c.call(d, b);
      }
      return a;
    },
    uj = function (a) {
      a = a[nj];
      return a instanceof hj ? a : null;
    },
    Cj = "__closure_events_fn_" + ((Math.random() * 1e9) >>> 0),
    sj = function (a) {
      z(a, "Listener can not be null.");
      if (typeof a === "function") return a;
      z(a.handleEvent, "An object listener must have handleEvent method.");
      a[Cj] ||
        (a[Cj] = function (b) {
          return a.handleEvent(b);
        });
      return a[Cj];
    };
  var P = function () {
    L.call(this);
    this.v = new hj(this);
    this.kf = this;
    this.mb = null;
  };
  y(P, L);
  P.prototype[cj] = !0;
  h = P.prototype;
  h.ac = function (a) {
    this.mb = a;
  };
  h.addEventListener = function (a, b, c, d) {
    rj(this, a, b, c, d);
  };
  h.removeEventListener = function (a, b, c, d) {
    yj(this, a, b, c, d);
  };
  h.dispatchEvent = function (a) {
    Dj(this);
    var b = this.mb;
    if (b) {
      var c = [];
      for (var d = 1; b; b = b.mb) c.push(b), z(++d < 1e3, "infinite loop");
    }
    b = this.kf;
    d = a.type || a;
    if (typeof a === "string") a = new $i(a, b);
    else if (a instanceof $i) a.target = a.target || b;
    else {
      var e = a;
      a = new $i(d, b);
      ue(a, e);
    }
    e = !0;
    var f;
    if (c)
      for (f = c.length - 1; !a.h && f >= 0; f--) {
        var g = (a.g = c[f]);
        e = Ej(g, d, !0, a) && e;
      }
    a.h ||
      ((g = a.g = b),
      (e = Ej(g, d, !0, a) && e),
      a.h || (e = Ej(g, d, !1, a) && e));
    if (c)
      for (f = 0; !a.h && f < c.length; f++)
        (g = a.g = c[f]), (e = Ej(g, d, !1, a) && e);
    return e;
  };
  h.D = function () {
    P.R.D.call(this);
    this.v && kj(this.v);
    this.mb = null;
  };
  h.Ja = function (a, b, c, d) {
    Dj(this);
    return this.v.add(String(a), b, !1, c, d);
  };
  h.Sa = function (a, b, c, d) {
    var e = this.v;
    a = String(a).toString();
    if (a in e.g) {
      var f = e.g[a];
      b = ij(f, b, c, d);
      b > -1
        ? (gj(f[b]),
          Tb(f, b),
          f.length == 0 && (delete e.g[a], e.h--),
          (e = !0))
        : (e = !1);
    } else e = !1;
    return e;
  };
  var Ej = function (a, b, c, d) {
      b = a.v.g[String(b)];
      if (!b) return !0;
      b = b.concat();
      for (var e = !0, f = 0; f < b.length; ++f) {
        var g = b[f];
        if (g && !g.cb && g.capture == c) {
          var k = g.listener,
            m = g.handler || g.src;
          g.pb && jj(a.v, g);
          e = k.call(m, d) !== !1 && e;
        }
      }
      return e && !d.defaultPrevented;
    },
    Dj = function (a) {
      z(
        a.v,
        "Event target is not initialized. Did you call the superclass (goog.events.EventTarget) constructor?"
      );
    };
  var Fj = function (a, b) {
    P.call(this);
    this.h = a || 1;
    this.g = b || q;
    this.j = x(this.xf, this);
    this.l = Xa();
  };
  y(Fj, P);
  h = Fj.prototype;
  h.Ka = !1;
  h.ja = null;
  h.setInterval = function (a) {
    this.h = a;
    this.ja && this.Ka ? (this.stop(), this.start()) : this.ja && this.stop();
  };
  h.xf = function () {
    if (this.Ka) {
      var a = Xa() - this.l;
      a > 0 && a < this.h * 0.8
        ? (this.ja = this.g.setTimeout(this.j, this.h - a))
        : (this.ja && (this.g.clearTimeout(this.ja), (this.ja = null)),
          this.dispatchEvent("tick"),
          this.Ka && (this.stop(), this.start()));
    }
  };
  h.start = function () {
    this.Ka = !0;
    this.ja || ((this.ja = this.g.setTimeout(this.j, this.h)), (this.l = Xa()));
  };
  h.stop = function () {
    this.Ka = !1;
    this.ja && (this.g.clearTimeout(this.ja), (this.ja = null));
  };
  h.D = function () {
    Fj.R.D.call(this);
    this.stop();
    delete this.g;
  };
  var Gj = function (a, b, c) {
    if (typeof a === "function") c && (a = x(a, c));
    else if (a && typeof a.handleEvent == "function") a = x(a.handleEvent, a);
    else throw Error("Invalid listener argument");
    return Number(b) > 2147483647 ? -1 : q.setTimeout(a, b || 0);
  };
  function Hj(a) {
    a = a === null ? "null" : a === void 0 ? "undefined" : a;
    if (typeof a !== "string") throw Error("Expected a string");
    return jf(a);
  }
  var Ij = {},
    Jj = {},
    Kj = new Fh(0.001, "");
  Kj.g = "load";
  var Lj = new Fh(0.1, "");
  Lj.g = "fail";
  var Mj = new O();
  Mj.set("enabler", "enabler");
  Mj.set("dcmenabler", "dcm");
  Mj.set("video", "vid");
  Mj.set("configurable", "cfg");
  Mj.set("configurablefiller", "cfg_fill");
  Mj.set("layouts", "lay");
  Mj.set("layoutsfiller", "lay_fill");
  Mj.set("gdn", "gdn");
  Mj.set("rad_ui_video", "rad");
  var Nj = function (a) {
      a = Ij[a];
      return a !== void 0 && a >= 1;
    },
    Oj = function (a) {
      a: {
        var b = document.getElementsByTagName("script");
        for (var c = 0; c < b.length; c++) {
          var d = b[c];
          if (d.src || d.getAttribute("src"))
            if (((d = d.src || d.getAttribute("src")), /Enabler/.test(d))) {
              b = d.substring(0, d.lastIndexOf("/") + 1);
              break a;
            }
        }
        b = "";
      }
      return [b, "dev_studio_01_262_", [a, "module"].join(""), ".js"].join("");
    };
  r(
    "goog.exportSymbol",
    function (a, b, c) {
      r(a, b, c);
    },
    this
  );
  var Pj = function (a) {
      a +=
        "goog.exportSymbol('studioLoader.context.evalInContext', " +
        Pj.toString() +
        ");";
      eval(a);
    },
    Qj = function (a, b) {
      b = Mj.get(b) || "unknown";
      a.l = b;
      a = a.j();
      !kb(a) && Eh(1) && (jg(document, "IMG").src = a);
    },
    Rj = function (a) {
      Ij[a] = 2;
      Qj(Kj, a);
      for (var b = Oj(a), c = Oi(Hj(b)), d = 0; d < 2; ++d)
        c = c.then(void 0, function () {
          return Oi(Hj(b));
        });
      return c.then(
        function () {
          Ij[a] = 3;
        },
        function () {
          Qj(Lj, a);
          return hi();
        }
      );
    },
    Sj = function (a) {
      if (Nj(a)) return Jj[a];
      Ij[a] = 1;
      for (
        var b = [],
          c = DEPS_GRAPH ? DEPS_GRAPH[[a, "module"].join("")] : [],
          d = c.length - 1;
        d >= 0;
        d--
      ) {
        var e = c[d].replace(/module$/, "");
        if (e == a) break;
        Nj(e) ? b.push(Jj[e]) : b.push(Sj(e));
      }
      b = ki(b).then(function () {
        return Rj(a);
      });
      return (Jj[a] = b);
    },
    Tj = function (a, b) {
      a = Sj(a);
      typeof b === "function" && (a = a.then(b));
      a = a.then(
        function () {},
        function () {}
      );
    };
  r("studioLoader.context.evalInContext", Pj);
  var Uj = pa(["https://tpc.googlesyndication.com/sodar/", ".js"]),
    Vj = pa(["https://ep2.adtrafficquality.google/sodar/", ".js"]),
    Wj = pa(["https://www.google.com/recaptcha/api2/aframe"]);
  Xf(Wj);
  function Xj(a) {
    var b = window,
      c = !0;
    c = c === void 0 ? !1 : c;
    new Promise(function (d, e) {
      function f() {
        g.onload = null;
        g.onerror = null;
        var k;
        (k = g.parentElement) == null || k.removeChild(g);
      }
      var g = b.document.createElement("script");
      g.onload = function () {
        f();
        d();
      };
      g.onerror = function () {
        f();
        e(void 0);
      };
      g.type = "text/javascript";
      Nf(g, a);
      c && b.document.readyState !== "complete"
        ? Ag(b, function () {
            b.document.body.appendChild(g);
          })
        : b.document.body.appendChild(g);
    });
  }
  var Yj = {},
    Zj =
      ((Yj["internal-error"] = -1),
      (Yj["non-recoverable-error"] = -2),
      (Yj["api-disabled-by-application"] = -3),
      (Yj["invalid-argument"] = -4),
      (Yj["token-provider-invalid"] = -5),
      Yj),
    ak = function () {
      this.qa = !1;
    },
    bk,
    ck = function () {
      bk || (bk = new ak());
      return bk;
    },
    dk = function (a) {
      var b;
      Fa(function (c) {
        if (c.g == 1)
          return (
            (c.l = 2),
            xa(
              c,
              window.android.webview.getExperimentalMediaIntegrityTokenProvider(
                { cloudProjectNumber: 187810013193 }
              ),
              4
            )
          );
        if (c.g != 2) (a.h = c.o), (a.g = void 0), (c.g = 0), (c.l = 0);
        else {
          b = ya(c);
          var d = 0;
          b.mediaIntegrityErrorName
            ? d || (d = Zj[b.mediaIntegrityErrorName])
            : b.code && (d = b.code());
          a.g = d;
          c.g = 0;
        }
      });
    };
  function ek(a) {
    var b, c, d, e, f, g, k, m;
    return Fa(function (p) {
      switch (p.g) {
        case 1:
          return (
            (b = a.Aa
              ? "https://ep1.adtrafficquality.google/getconfig/sodar"
              : "https://pagead2.googlesyndication.com/getconfig/sodar"),
            (c = b + "?sv=200&tid=" + a.g + ("&tv=" + a.h + "&st=") + a.Ha),
            (d = void 0),
            (p.l = 2),
            xa(p, fk(c), 4)
          );
        case 4:
          d = p.o;
          p.g = 3;
          p.l = 0;
          break;
        case 2:
          ya(p);
        case 3:
          if (!d) return p.return(void 0);
          e = a.yb || d.sodar_query_id;
          f = d.rc_enable !== void 0 ? d.rc_enable : "n";
          g = d.bg_snapshot_delay_ms === void 0 ? "0" : d.bg_snapshot_delay_ms;
          k = d.is_gen_204 === void 0 ? "1" : d.is_gen_204;
          return e && d.bg_hash_basename && d.bg_binary
            ? ((m = {
                context: a.j,
                Yd: d.bg_hash_basename,
                Xd: d.bg_binary,
                Pe: a.g + "_" + a.h,
                yb: e,
                Ha: a.Ha,
                wb: f,
                Db: g,
                ub: k,
                Aa: a.Aa,
              }),
              a.qa ? p.return(Object.assign({}, m, { qa: !0 })) : p.return(m))
            : p.return(void 0);
      }
    });
  }
  var fk = function (a) {
    return new Promise(function (b, c) {
      var d = new XMLHttpRequest();
      d.onreadystatechange = function () {
        d.readyState === d.DONE &&
          (d.status >= 200 && d.status < 300
            ? b(JSON.parse(d.responseText))
            : c());
      };
      d.open("GET", a, !0);
      d.send();
    });
  };
  function gk() {
    var a = hk(),
      b;
    Fa(function (c) {
      if (c.g == 1) {
        if (a.qa) {
          ck().qa = !0;
          var d = ck();
          window.android &&
            window.android.webview &&
            window.android.webview.getExperimentalMediaIntegrityTokenProvider &&
            d.qa &&
            dk(d);
        }
        return xa(c, ek(a), 2);
      }
      if ((b = c.o)) {
        d = b;
        var e = "sodar2";
        e = e === void 0 ? "sodar2" : e;
        var f = window,
          g = f.GoogleGcLKhOms;
        (g && typeof g.push === "function") || (g = f.GoogleGcLKhOms = []);
        var k = {};
        k =
          ((k._ctx_ = d.context),
          (k._bgv_ = d.Yd),
          (k._bgp_ = d.Xd),
          (k._li_ = d.Pe),
          (k._jk_ = d.yb),
          (k._st_ = d.Ha),
          (k._rc_ = d.wb),
          (k._dl_ = d.Db),
          (k._g2_ = d.ub),
          (k._atqg_ = d.Aa === void 0 ? "0" : d.Aa ? "1" : "0"),
          k);
        if (d.qa) {
          var m = {};
          g.push(Object.assign({}, k, ((m._wvp_ = "1"), m)));
        } else g.push(k);
        if ((g = f.GoogleDX5YKUSk)) (f.GoogleDX5YKUSk = void 0), g[1]();
        d = d.Aa ? Xf(Vj, e) : Xf(Uj, e);
        Xj(d);
      }
      return c.return(b);
    });
  }
  var ik = function (a) {
      this.g = a.g;
      this.h = a.h;
      this.j = a.j;
      this.yb = a.yb;
      this.Ha = a.Ha;
      this.wb = a.wb;
      this.Db = a.Db;
      this.ub = a.ub;
      this.Aa = a.Aa;
      this.qa = a.qa;
    },
    jk = function () {
      this.g = "xfad";
      this.h = "01_262";
      this.j = "cr";
      this.Ha = "env";
      this.wb = "n";
      this.Db = "0";
      this.ub = "1";
      this.qa = this.Aa = !1;
    },
    hk = function () {
      var a = new jk();
      a.Ha = "int";
      return new ik(a);
    };
  var kk = function (a) {
    ke.call(this, a);
  };
  n(kk, ke);
  kk.g = "adsense.rum.Parameters";
  var lk = function (a) {
    ke.call(this, a);
  };
  n(lk, ke);
  lk.g = "adsense.rum.Config";
  var nk = function (a) {
      this.g = new O();
      this.size = 0;
      a && mk(this, a);
    },
    ok = function (a) {
      var b = typeof a;
      return (b == "object" && a) || b == "function"
        ? "o" + Ta(a)
        : b.slice(0, 1) + a;
    };
  nk.prototype.W = function () {
    return this.g.size;
  };
  nk.prototype.add = function (a) {
    this.g.set(ok(a), a);
    this.size = this.g.size;
  };
  var mk = function (a, b) {
    b = Mg(b);
    for (var c = b.length, d = 0; d < c; d++) a.add(b[d]);
    a.size = a.g.size;
  };
  h = nk.prototype;
  h.delete = function (a) {
    var b = this.g;
    a = ok(a);
    b = b.delete(a);
    this.size = this.g.size;
    return b;
  };
  h.clear = function () {
    this.g.clear();
    this.size = 0;
  };
  h.has = function (a) {
    return this.g.ia(ok(a));
  };
  h.contains = function (a) {
    return this.g.ia(ok(a));
  };
  h.Y = function () {
    return this.g.Y();
  };
  h.values = function () {
    return this.g.values();
  };
  h.equals = function (a) {
    return this.W() == Lg(a) && pk(this, a);
  };
  var pk = function (a, b) {
    var c = Lg(b);
    if (a.W() > c) return !1;
    !(b instanceof nk) && c > 5 && (b = new nk(b));
    return Pg(a, function (d) {
      return Og(b, d);
    });
  };
  nk.prototype.xa = function () {
    return this.g.xa(!1);
  };
  nk.prototype[Symbol.iterator] = function () {
    return this.values();
  };
  r("studio.common.Feature.Type", {
    vg: 1,
    SDK_EVENT_FORWARDER: 2,
    RL_EVENT_FORWARDER: 3,
  });
  var qk = new nk();
  r("studio.common.Feature.hasFeature", function (a) {
    return qk.has(a);
  });
  r("studio.common.Feature.hasFeatures", function (a) {
    return Pg(a, qk.contains, qk);
  });
  var rk = function (a, b) {
      this.h = a;
      this.g = b != null ? b : 0;
    },
    sk = function () {
      var a = window;
      return a.innerWidth > a.innerHeight ? "landscape" : "portrait";
    },
    tk = function () {
      return "onorientationchange" in window;
    };
  rk.prototype.ue = function () {
    return this.h;
  };
  rk.prototype.te = function () {
    return this.g;
  };
  rk.prototype.toString = function () {
    return this.h;
  };
  r("studio.common.Orientation", rk);
  rk.prototype.getDegrees = rk.prototype.te;
  rk.prototype.getMode = rk.prototype.ue;
  rk.Mode = { PORTRAIT: "portrait", LANDSCAPE: "landscape" };
  function uk(a, b) {
    return b ? a.replace("[rm_exit_id]", b) : a;
  }
  function vk(a) {
    kb(Sf(a)) ||
      "market" != (a.match(Fg)[1] || null) ||
      ((a = a.match(Fg)),
      (a =
        "https://play.google.com/store/apps/details" +
        Eg(null, null, null, null, a[5], a[6], a[7])));
    return a;
  }
  var wk = {
    CREATIVETOOLSET_CONFIG: "creativeToolsetConfig",
    CREATIVETOOLSET_INTERNALS: "creativeToolsetInternals",
    CREATIVETOOLSET_INTERNALS_GEN204: "creativeToolsetInternalsGen204",
    CREATIVE_REPORTER: "creativeReporter",
    CREATIVE_INNOVATION: "gcreativeinnovation",
    GOOGLE_AFMA_SUPPORT: "googleAfmaSupport",
  };
  r("studio.common.WhitelistedExternalObject", wk);
  var xk = {};
  var Q = function (a) {
    L.call(this);
    this.A = a;
    this.j = {};
  };
  y(Q, L);
  var yk = [],
    R = function (a, b, c, d, e, f) {
      Array.isArray(c) || (c && (yk[0] = c.toString()), (c = yk));
      for (var g = 0; g < c.length; g++) {
        var k = rj(b, c[g], d || a.handleEvent, e || !1, f || a.A || a);
        if (!k) break;
        a.j[k.key] = k;
      }
    },
    zk = function (a, b, c, d, e, f) {
      if (Array.isArray(c))
        for (var g = 0; g < c.length; g++) zk(a, b, c[g], d, e, f);
      else
        (b = qj(b, c, d || a.handleEvent, e, f || a.A || a)) &&
          (a.j[b.key] = b);
    },
    Ak = function (a, b, c, d, e, f) {
      if (Array.isArray(c))
        for (var g = 0; g < c.length; g++) Ak(a, b, c[g], d, e, f);
      else if (
        (b = Aj(
          b,
          c,
          d || a.handleEvent,
          v(e) ? !!e.capture : !!e,
          f || a.A || a
        ))
      )
        zj(b), delete a.j[b.key];
    },
    Bk = function (a) {
      le(
        a.j,
        function (b, c) {
          this.j.hasOwnProperty(c) && zj(b);
        },
        a
      );
      a.j = {};
    };
  Q.prototype.D = function () {
    Q.R.D.call(this);
    Bk(this);
  };
  Q.prototype.handleEvent = function () {
    throw Error("EventHandler.handleEvent not implemented");
  };
  var Ck = { 1: "NativeMessagingTransport" },
    Dk = ["pu", "lru", "pru", "lpu", "ppu"],
    Fk = function () {
      for (var a = 10, b = Ek, c = b.length, d = ""; a-- > 0; )
        d += b.charAt(Math.floor(Math.random() * c));
      return d;
    },
    Ek = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
    S = Te("goog.net.xpc");
  var Gk = function (a) {
    L.call(this);
    this.j = a || dg();
  };
  y(Gk, L);
  Gk.prototype.J = 0;
  Gk.prototype.getName = function () {
    return Ck[String(this.J)] || "";
  };
  var Hk = function (a, b) {
    Gk.call(this, b);
    this.g = a;
    this.F = new Q(this);
    Dg(this, this.F);
    this.A = new Fj(100, this.j.g.defaultView);
    Dg(this, this.A);
    this.l = new N();
    this.v = new N();
    this.h = new N();
    this.C = Fk();
    this.B = null;
    this.o = {};
    this.I = this.g.name;
    this.g.fb(this.g.name + "_" + this.g.ea());
    this.G = !1;
    Fi(this.h, this.l);
    Fi(this.h, this.v);
    Di(this.h, this.Cd, this);
    this.h.callback(!0);
    R(this.F, this.A, "tick", this.cc);
    K(S, "DirectTransport created. role=" + this.g.ea());
  };
  n(Hk, Gk);
  var Kk = function (a) {
    var b = new Ik(a.channelName, a.service, a.payload);
    a = b.g;
    var c = b.j;
    b = b.h;
    Xe(
      S,
      "messageReceived: channel=" + a + ", service=" + c + ", payload=" + b
    );
    var d = xk[a];
    if (d) return d.sa(c, b), !0;
    d = Jk(b)[0];
    for (var e in xk) {
      var f = xk[e];
      if (f.ea() == 1 && !f.isConnected() && c == "tp" && d == "SETUP")
        return f.fb(a), f.sa(c, b), !0;
    }
    K(S, "channel name mismatch; message ignored.");
    return !1;
  };
  h = Hk.prototype;
  h.Eb = function (a) {
    a = Jk(a);
    var b = a[1];
    switch (a[0]) {
      case "SETUP_ACK":
        this.l.g || this.l.callback(!0);
        break;
      case "SETUP":
        this.U("tp", "SETUP_ACK"),
          this.v.g || this.v.callback(!0),
          this.B != null &&
            this.B != b &&
            (K(S, "Sending SETUP and changing peer ID to: " + b),
            this.U("tp", "SETUP," + this.C)),
          (this.B = b);
    }
  };
  h.connect = function () {
    var a = this.j.g.defaultView;
    if (a) {
      var b = Ta(a);
      (Lk[b] || 0) == 0 &&
        La("crosswindowmessaging.channel", a) == null &&
        r("crosswindowmessaging.channel", Kk, a);
      Lk[b]++;
      this.G = !0;
      this.cc();
    } else Xe(S, "connect(): no window to initialize.");
  };
  h.cc = function () {
    this.g.isConnected()
      ? this.A.stop()
      : (this.A.start(), this.U("tp", "SETUP," + this.C));
  };
  h.U = function (a, b) {
    this.g.aa
      ? ((a = new Ik(this.I + "_" + (this.g.ea() == 0 ? 1 : 0), a, b)),
        this.g.g.directSyncMode
          ? this.zc(a)
          : (this.o[Ta(a)] = Gj(x(this.zc, this, a), 0)))
      : Xe(S, "send(): window not ready");
  };
  h.zc = function (a) {
    var b = Ta(a);
    this.o[b] && delete this.o[b];
    try {
      var c = La("crosswindowmessaging.channel", this.g.aa);
    } catch (d) {
      J(S, "Can't access other window, ignoring.", d);
      return;
    }
    if (c === null) J(S, "Peer window had no global function.");
    else
      try {
        c({ channelName: a.g, service: a.j, payload: a.h }),
          K(
            S,
            "send(): channelName=" + a.g + " service=" + a.j + " payload=" + a.h
          );
      } catch (d) {
        J(S, "Error performing call, ignoring.", d);
      }
  };
  h.Cd = function () {
    Mk(this.g, 0);
  };
  h.D = function () {
    if (this.G) {
      var a = this.j.g.defaultView,
        b = Ta(a);
      --Lk[b] == 1 && r("crosswindowmessaging.channel", null, a);
    }
    this.o &&
      (le(this.o, function (c) {
        q.clearTimeout(c);
      }),
      (this.o = null));
    this.l && (this.l.cancel(), delete this.l);
    this.v && (this.v.cancel(), delete this.v);
    this.h && (this.h.cancel(), delete this.h);
    Gk.prototype.D.call(this);
  };
  var Jk = function (a) {
      a = a.split(",");
      a[1] = a[1] || null;
      return a;
    },
    Lk = {};
  Hk.prototype.J = 2;
  var Ik = function (a, b, c) {
    this.g = a;
    this.j = b;
    this.h = c;
  };
  var Nk = function (a, b, c, d, e) {
    Gk.call(this, c);
    this.l = a;
    this.h = e || 2;
    z(this.h >= 1);
    z(this.h <= 2);
    this.N = b || "*";
    this.I = new Q(this);
    this.B = new Fj(100, this.j.g.defaultView);
    this.F = !!d;
    this.o = new N();
    this.A = new N();
    this.v = new N();
    this.la = Fk();
    this.G = null;
    this.F
      ? this.l.ea() == 1
        ? Fi(this.v, this.o)
        : Fi(this.v, this.A)
      : (Fi(this.v, this.o), this.h == 2 && Fi(this.v, this.A));
    Di(this.v, this.pa, this);
    this.v.callback(!0);
    z(!0, "Major version must be an integer");
    this.wa = Jb() <= 10;
    R(this.I, this.B, "tick", this.X);
    K(
      S,
      "NativeMessagingTransport created.  protocolVersion=" +
        this.h +
        ", oneSidedHandshake=" +
        this.F +
        ", role=" +
        this.l.ea()
    );
  };
  n(Nk, Gk);
  var Pk = function (a) {
    var b = a.ba.data;
    if (typeof b !== "string") return !1;
    var c = b.indexOf("|"),
      d = b.indexOf(":");
    if (c == -1 || d == -1) return !1;
    var e = b.substring(0, c);
    c = b.substring(c + 1, d);
    b = b.substring(d + 1);
    Xe(
      S,
      "messageReceived: channel=" + e + ", service=" + c + ", payload=" + b
    );
    if ((d = xk[e])) return d.sa(c, b, a.ba.origin), !0;
    d = Ok(b)[0];
    for (var f in xk) {
      var g = xk[f];
      if (
        g.ea() == 1 &&
        !g.isConnected() &&
        c == "tp" &&
        (d == "SETUP" || d == "SETUP_NTPV2") &&
        g.Za(a.ba.origin)
      )
        return g.fb(e), g.sa(c, b), !0;
    }
    K(S, 'channel name mismatch; message ignored"');
    return !1;
  };
  Nk.prototype.Eb = function (a) {
    var b = Ok(a);
    a = b[1];
    switch (b[0]) {
      case "SETUP_ACK":
        Qk(this, 1);
        this.o.g || this.o.callback(!0);
        break;
      case "SETUP_ACK_NTPV2":
        this.h == 2 && (Qk(this, 2), this.o.g || this.o.callback(!0));
        break;
      case "SETUP":
        Qk(this, 1);
        Rk(this, 1);
        break;
      case "SETUP_NTPV2":
        this.h == 2 &&
          ((b = this.g),
          Qk(this, 2),
          Rk(this, 2),
          (b != 1 && this.G == null) ||
            this.G == a ||
            (K(S, "Sending SETUP and changing peer ID to: " + a), Sk(this)),
          (this.G = a));
    }
  };
  var Sk = function (a) {
      z(!(a.h == 1 && a.g == 2));
      a.h != 2 || (a.g != null && a.g != 2) || a.U("tp", "SETUP_NTPV2," + a.la);
      (a.g != null && a.g != 1) || a.U("tp", "SETUP");
    },
    Rk = function (a, b) {
      z(a.h != 1 || b != 2, "Shouldn't try to send a v2 setup ack in v1 mode.");
      if (a.h != 2 || (a.g != null && a.g != 2) || b != 2) {
        if ((a.g != null && a.g != 1) || b != 1) return;
        a.U("tp", "SETUP_ACK");
      } else a.U("tp", "SETUP_ACK_NTPV2");
      a.A.g || a.A.callback(!0);
    },
    Qk = function (a, b) {
      b > a.g && (a.g = b);
      a.g == 1 && (a.A.g || a.F || a.A.callback(!0), (a.G = null));
    };
  Nk.prototype.connect = function () {
    var a = this.j.g.defaultView,
      b = Ta(a),
      c = Tk[b];
    typeof c !== "number" && (c = 0);
    c == 0 && rj(a.postMessage ? a : a.document, "message", Pk, !1, Nk);
    Tk[b] = c + 1;
    this.S = !0;
    this.X();
  };
  Nk.prototype.X = function () {
    var a = this.l.ea() == 0;
    (this.F && a) || this.l.isConnected() || this.isDisposed()
      ? this.B.stop()
      : (this.B.start(), Sk(this));
  };
  var Uk = function (a, b, c) {
    var d = a.l.aa,
      e = a.l.name;
    a.C = 0;
    try {
      var f = d.postMessage ? d : d.document;
      f.postMessage
        ? (f.postMessage(e + "|" + b + ":" + c, a.N),
          Xe(
            S,
            "send(): service=" + b + " payload=" + c + " to hostname=" + a.N
          ))
        : J(S, "Peer window had no postMessage function.");
    } catch (g) {
      J(S, "Error performing postMessage, ignoring.", g);
    }
  };
  Nk.prototype.U = function (a, b) {
    var c = this;
    this.l.aa
      ? this.wa
        ? (this.C = Gj(function () {
            return void Uk(c, a, b);
          }, 0))
        : Uk(this, a, b)
      : Xe(S, "send(): window not ready");
  };
  Nk.prototype.pa = function () {
    Mk(this.l, this.h == 1 || this.g == 1 ? 200 : void 0);
  };
  Nk.prototype.D = function () {
    if (this.S) {
      var a = this.j.g.defaultView;
      if (a) {
        var b = Ta(a),
          c = Tk[b];
        Tk[b] = c - 1;
        c === 1 && yj(a.postMessage ? a : a.document, "message", Pk, !1, Nk);
      }
    }
    this.C && (q.clearTimeout(this.C), (this.C = 0));
    Bg(this.I);
    delete this.I;
    Bg(this.B);
    delete this.B;
    this.o.cancel();
    delete this.o;
    this.A.cancel();
    delete this.A;
    this.v.cancel();
    delete this.v;
    delete this.U;
    Gk.prototype.D.call(this);
  };
  var Ok = function (a) {
    a = a.split(",");
    a[1] = a[1] || null;
    return a;
  };
  Nk.prototype.g = null;
  Nk.prototype.S = !1;
  Nk.prototype.J = 1;
  var Tk = {};
  Nk.prototype.C = 0;
  function Vk(a, b, c) {
    L.call(this);
    this.g = a;
    this.j = b || 0;
    this.h = c;
    this.l = x(this.fe, this);
  }
  y(Vk, L);
  h = Vk.prototype;
  h.Ta = 0;
  h.D = function () {
    Vk.R.D.call(this);
    this.stop();
    delete this.g;
    delete this.h;
  };
  h.start = function (a) {
    this.stop();
    this.Ta = Gj(this.l, a !== void 0 ? a : this.j);
  };
  h.stop = function () {
    this.isActive() && q.clearTimeout(this.Ta);
    this.Ta = 0;
  };
  h.isActive = function () {
    return this.Ta != 0;
  };
  h.fe = function () {
    this.Ta = 0;
    this.g && this.g.call(this.h);
  };
  var Yk = function (a) {
      var b = [];
      Wk(new Xk(), a, b);
      return b.join("");
    },
    Xk = function () {},
    Wk = function (a, b, c) {
      if (b == null) c.push("null");
      else {
        if (typeof b == "object") {
          if (Array.isArray(b)) {
            var d = b;
            b = d.length;
            c.push("[");
            for (var e = "", f = 0; f < b; f++)
              c.push(e), Wk(a, d[f], c), (e = ",");
            c.push("]");
            return;
          }
          if (
            b instanceof String ||
            b instanceof Number ||
            b instanceof Boolean
          )
            b = b.valueOf();
          else {
            c.push("{");
            e = "";
            for (d in b)
              Object.prototype.hasOwnProperty.call(b, d) &&
                ((f = b[d]),
                typeof f != "function" &&
                  (c.push(e), Zk(d, c), c.push(":"), Wk(a, f, c), (e = ",")));
            c.push("}");
            return;
          }
        }
        switch (typeof b) {
          case "string":
            Zk(b, c);
            break;
          case "number":
            c.push(isFinite(b) && !isNaN(b) ? String(b) : "null");
            break;
          case "boolean":
            c.push(String(b));
            break;
          case "function":
            c.push("null");
            break;
          default:
            throw Error("Unknown type: " + typeof b);
        }
      }
    },
    $k = {
      '"': '\\"',
      "\\": "\\\\",
      "/": "\\/",
      "\b": "\\b",
      "\f": "\\f",
      "\n": "\\n",
      "\r": "\\r",
      "\t": "\\t",
      "\v": "\\u000b",
    },
    al = /\uffff/.test("\uffff")
      ? /[\\"\x00-\x1f\x7f-\uffff]/g
      : /[\\"\x00-\x1f\x7f-\xff]/g,
    Zk = function (a, b) {
      b.push(
        '"',
        a.replace(al, function (c) {
          var d = $k[c];
          d ||
            ((d = "\\u" + (c.charCodeAt(0) | 65536).toString(16).slice(1)),
            ($k[c] = d));
          return d;
        }),
        '"'
      );
    };
  var bl = function () {
    L.call(this);
    this.A = {};
  };
  y(bl, L);
  h = bl.prototype;
  h.dc = Te("goog.messaging.AbstractChannel");
  h.connect = function (a) {
    a && a();
  };
  h.isConnected = function () {
    return !0;
  };
  h.hb = function (a, b, c) {
    this.A[a] = { callback: b, Zc: !!c };
  };
  h.jd = function (a) {
    this.o = a;
  };
  var cl = function (a, b, c) {
    var d = a.A[b];
    d ||
      (a.o
        ? (d = { callback: Wa(a.o, b), Zc: v(c) })
        : (J(a.dc, 'Unknown service name "' + b + '"'), (d = null)));
    if (d) {
      a: {
        var e = d.Zc;
        if (e && typeof c === "string")
          try {
            var f = JSON.parse(c);
            break a;
          } catch (g) {
            J(a.dc, "Expected JSON payload for " + b + ', was "' + c + '"');
            f = null;
            break a;
          }
        else if (!e && typeof c !== "string") {
          f = Yk(c);
          break a;
        }
        f = c;
      }
      a = f;
      a != null && d.callback(a);
    }
  };
  bl.prototype.D = function () {
    bl.R.D.call(this);
    delete this.A;
    delete this.o;
  };
  var el = function (a, b) {
    bl.call(this);
    for (var c, d = 0; (c = Dk[d]); d++)
      if (c in a && !/^https?:\/\//.test(a[c]))
        throw Error("URI " + a[c] + " is invalid for field " + c);
    this.g = a;
    this.name = this.g.cn || Fk();
    this.j = b || dg();
    this.l = [];
    this.v = new Q(this);
    a.lpu = a.lpu || Hg(this.j.g.defaultView.location.href) + "/robots.txt";
    a.ppu = a.ppu || Hg(a.pu || "") + "/robots.txt";
    xk[this.name] = this;
    Aj(window, "unload", dl) || qj(window, "unload", dl);
    K(S, "CrossPageChannel created: " + this.name);
  };
  n(el, bl);
  el.prototype.isConnected = function () {
    return this.La == 2;
  };
  el.prototype.connect = function (a) {
    this.h = a || function () {};
    this.La == 3 && (this.La = 1);
    this.Ba ? Di(this.Ba, this.B) : this.B();
  };
  el.prototype.B = function () {
    K(S, "continueConnection_()");
    this.Ba = null;
    this.g.ifrid && (this.gb = this.j.getElement(this.g.ifrid));
    if (this.gb) {
      var a = this.gb.contentWindow;
      a || (a = window.frames[this.g.ifrid]);
      this.aa = a;
    }
    if (!this.aa) {
      if (window == window.top)
        throw Error(
          "CrossPageChannel: Can't connect, peer window-object not set."
        );
      this.aa = window.parent;
    }
    if (!this.ha) {
      this.g.tp ||
        (this.g.tp =
          typeof document.postMessage === "function" ||
          typeof window.postMessage === "function" ||
          (dc && window.postMessage)
            ? 1
            : 0);
      if (typeof this.g.tp === "function")
        this.ha = new this.g.tp(this, this.j);
      else
        switch (this.g.tp) {
          case 1:
            this.ha = new Nk(
              this,
              this.g.ph,
              this.j,
              !!this.g.osh,
              this.g.nativeProtocolVersion || 2
            );
            break;
          case 2:
            if ((a = this.aa))
              try {
                a = window.document.domain == this.aa.document.domain;
              } catch (b) {
                a = !1;
              }
            a
              ? (this.ha = new Hk(this, this.j))
              : K(
                  S,
                  "DirectTransport not supported for this window, peer window in different security context or not set yet."
                );
        }
      if (this.ha) K(S, "Transport created: " + this.ha.getName());
      else
        throw Error(
          "CrossPageChannel: No suitable transport found! You may try injecting a Transport constructor directly via the channel config object."
        );
    }
    for (this.ha.connect(); this.l.length > 0; ) this.l.shift()();
  };
  el.prototype.close = function () {
    this.Ba && (this.Ba.cancel(), (this.Ba = null));
    this.l.length = 0;
    Bk(this.v);
    this.La = 3;
    Bg(this.ha);
    this.h = this.ha = null;
    Bg(this.ta);
    this.ta = null;
    K(S, 'Channel "' + this.name + '" closed');
  };
  var Mk = function (a, b) {
    a.isConnected() ||
      (a.ta && a.ta.isActive()) ||
      ((a.La = 2),
      K(S, 'Channel "' + a.name + '" connected'),
      Bg(a.ta),
      b !== void 0
        ? ((a.ta = new Vk(a.h, b)), a.ta.start())
        : ((a.ta = null), a.h()));
  };
  h = el.prototype;
  h.Ua = function (a, b) {
    if (this.isConnected()) {
      try {
        var c = !!this.aa && !this.aa.closed;
      } catch (e) {
        c = !1;
      }
      if (c) {
        v(b) && (b = Yk(b));
        c = this.ha;
        var d = c.U;
        fl.test(a) && (a = "%" + a);
        a = a.replace(/[%:|]/g, encodeURIComponent);
        d.call(c, a, b);
      } else We(S, "Peer has disappeared."), this.close();
    } else We(S, "Can't send. Channel not connected.");
  };
  h.sa = function (a, b, c) {
    this.Ba
      ? this.l.push(x(this.sa, this, a, b, c))
      : this.Za(c)
      ? this.isDisposed() || this.La == 3
        ? J(S, "CrossPageChannel::xpcDeliver(): Channel closed.")
        : a && a != "tp"
        ? this.isConnected()
          ? ((a = a.replace(/%[0-9a-f]{2}/gi, decodeURIComponent)),
            (a = gl.test(a) ? a.substring(1) : a),
            cl(this, a, b))
          : K(S, "CrossPageChannel::xpcDeliver(): Not connected.")
        : this.ha.Eb(b)
      : J(S, 'Message received from unapproved origin "' + c + '" - rejected.');
  };
  h.ea = function () {
    var a = this.g.role;
    return typeof a === "number" ? a : window.parent == this.aa ? 1 : 0;
  };
  h.fb = function (a) {
    Xe(S, "changing channel name to " + a);
    delete xk[this.name];
    this.name = a;
    xk[a] = this;
  };
  h.Za = function (a) {
    var b = this.g.ph;
    return kb(Sf(a)) || kb(Sf(b)) || a == this.g.ph;
  };
  h.D = function () {
    this.close();
    this.gb = this.aa = null;
    delete xk[this.name];
    Bg(this.v);
    delete this.v;
    bl.prototype.D.call(this);
  };
  var dl = function () {
      for (var a in xk) Bg(xk[a]);
    },
    fl = RegExp("^%*tp$"),
    gl = RegExp("^%+tp$");
  h = el.prototype;
  h.ta = null;
  h.Ba = null;
  h.ha = null;
  h.La = 1;
  h.aa = null;
  h.gb = null;
  var hl = {
      Rf: "devicemotion",
      Sf: "deviceorientation",
      lg: "hostpageScroll",
      Wf: "enterViewport",
      Xf: "exitViewport",
      Jf: "adLocation",
    },
    il = {},
    jl;
  for (jl in hl) il[hl[jl]] = !0;
  var T = function (a) {
    $i.call(this, a);
  };
  n(T, $i);
  T.prototype.da = function (a, b) {
    this[a] = b;
    return this;
  };
  r("studio.events.StudioEvent", T);
  T.prototype.addProperty = T.prototype.da;
  T.INIT = "init";
  T.VISIBLE = "visible";
  T.HIDDEN = "hidden";
  T.VISIBILITY_CHANGE = "visibilityChange";
  T.VISIBILITY_CHANGE_WITH_INFO = "visibilityChangeWithInfo";
  T.EXIT = "exit";
  T.INTERACTION = "interaction";
  T.PAGE_LOADED = "pageLoaded";
  T.ORIENTATION = "orientation";
  T.ABOUT_TO_EXPAND = "aboutToExpand";
  T.EXPAND_START = "expandStart";
  T.EXPAND_FAILED = "expandFailed";
  T.EXPAND_FINISH = "expandFinish";
  T.COLLAPSE_START = "collapseStart";
  T.COLLAPSE_FINISH = "collapseFinish";
  T.COLLAPSE = "collapse";
  T.FULLSCREEN_SUPPORT = "fullscreenSupport";
  T.HOSTPAGE_FEATURES_LOADED = "hostpageFeaturesLoaded";
  T.FULLSCREEN_DIMENSIONS = "fullscreenDimensions";
  T.FULLSCREEN_EXPAND_START = "fullscreenExpandStart";
  T.FULLSCREEN_EXPAND_FINISH = "fullscreenExpandFinish";
  T.FULLSCREEN_COLLAPSE_START = "fullscreenCollapseStart";
  T.FULLSCREEN_COLLAPSE_FINISH = "fullscreenCollapseFinish";
  T.HOSTPAGE_SCROLL = "hostpageScroll";
  T.OPTIONAL_HOSTPAGE_SCROLL = "optHostpageScroll";
  T.SCROLL_INTERACTION = "scrollInteraction";
  T.ENTER_VIEWPORT = "enterViewport";
  T.OPTIONAL_ENTER_VIEWPORT = "optEnterViewport";
  T.EXIT_VIEWPORT = "exitViewport";
  T.OPTIONAL_EXIT_VIEWPORT = "optExitViewport";
  T.VIDEO_START = "videoStart";
  var kl = {},
    ll =
      ((kl.optHostpageScroll = "hostpageScroll"),
      (kl.optEnterViewport = "enterViewport"),
      (kl.optExitViewport = "exitViewport"),
      kl);
  var ml = function () {
    Q.call(this);
    this.g = new Map();
    this.l = this.o = !1;
    this.h = this.v = null;
    this.g.set("nx", null);
    this.g.set("ny", null);
    this.g.set("dim", null);
  };
  n(ml, Q);
  ml.prototype.B = function () {
    return (
      Ga.apply(0, arguments).reduce(function (a, b) {
        return a + b.length;
      }, 0) < 2040
    );
  };
  var nl = function () {
      var a = gg();
      return a.width + "x" + a.height;
    },
    ol = function (a) {
      a.h || (a.h = window.GoogleA13IjpGc);
      return a.h && typeof a.h.snapshotSync === "function"
        ? a.h.snapshotSync()
        : null;
    };
  ml.prototype.C = function (a) {
    var b = a.clientX,
      c = a.clientY;
    a.changedTouches &&
      a.changedTouches[0] &&
      ((b = a.changedTouches[0].clientX), (c = a.changedTouches[0].clientY));
    this.g.set("nx", Math.round(b));
    this.g.set("ny", Math.round(c));
    this.l && (this.v = ol(this));
  };
  ml.prototype.D = function () {
    this.o = !1;
    Q.prototype.D.call(this);
  };
  var pl = function (a) {
    this.g = a;
  };
  pl.prototype.toString = function () {
    return (this.g & 2 ? "b" : "t") + (this.g & 1 ? "r" : "l");
  };
  r("google3.javascript.ads.studio.common.mde.Direction.Direction", pl);
  pl.Corner = { Dg: 0, Eg: 1, Kf: 2, Lf: 3 };
  var ql = { TL: new pl(0), TR: new pl(1), BL: new pl(2), BR: new pl(3) },
    rl = oe(ql);
  var sl = {
      Ag: "startExpandInternal",
      zg: "startCollapseInternal",
      Zf: "finishCollapseInternal",
      If: "aboutToExpandInternal",
      wg: "setAdVisibleInternal",
      xg: "setAdParameters",
      Tf: "dispatchEvent",
      yg: "setParameter",
      ig: "getParameter",
      gg: "fullscreenSupportInternal",
      dg: "fullscreenDimensionsInternal",
      fg: "fullscreenExpandStartInternal",
      eg: "fullscreenExpandFinishInternal",
      cg: "fullscreenCollapseStartInternal",
      bg: "fullscreenCollapseFinishInternal",
      mg: "invokeOnAllVideos",
      qg: "livePreviewChannel",
      Uf: "dispatchPageLoaded",
    },
    tl = {},
    ul;
  for (ul in sl) tl[sl[ul]] = !0;
  var vl = [
    /s0(qa)?\.2mdn\.net/,
    /^.*\.(prod|corp)\.google\.com/,
    /localhost/,
    /tpc\.googlesyndication\.com/,
    /secureframe\.doubleclick\.net/,
    /imasdk\.googleapis\.com/,
    /^.*dot-expandable-ad-tool\.appspot\.com/,
  ];
  function wl() {
    var a = location.hostname;
    return Eh(2) && !Eh(16)
      ? !1
      : Pb(vl, function (b) {
          return b.test(a);
        });
  }
  var xl = function (a) {
    L.call(this);
    this.h = a;
    this.g = {};
    this.h.jd(x(this.l, this));
  };
  y(xl, L);
  xl.prototype.j = Te("goog.messaging.MultiChannel");
  var zl = function (a, b) {
    if (b.indexOf(":") != -1)
      throw Error('Virtual channel name "' + b + '" should not contain colons');
    if (b in a.g)
      throw Error(
        'Virtual channel "' + b + '" was already created for this multichannel.'
      );
    var c = new yl(a, b);
    return (a.g[b] = c);
  };
  xl.prototype.l = function (a, b) {
    var c = a.match(/^([^:]*):(.*)/);
    if (c) {
      var d = c[1];
      a = c[2];
      d in this.g
        ? (c = this.g[d])
          ? c.j
            ? c.j(a, b)
            : J(
                this.j,
                'Service "' +
                  a +
                  '" is not registered on virtual channel "' +
                  d +
                  '"'
              )
          : J(
              this.j,
              'Virtual channel "' +
                d +
                ' has been disposed, but a message was received for it: "' +
                a +
                '"'
            )
        : J(
            this.j,
            'Virtual channel "' +
              d +
              ' does not exist, but a message was received for it: "' +
              a +
              '"'
          );
    } else
      J(
        this.j,
        'Invalid service name "' + a + '": no virtual channel specified'
      );
  };
  xl.prototype.D = function () {
    le(this.g, function (a) {
      Bg(a);
    });
    Bg(this.h);
    delete this.g;
    delete this.h;
  };
  var yl = function (a, b) {
    L.call(this);
    this.h = a;
    this.g = b;
  };
  y(yl, L);
  h = yl.prototype;
  h.Dd = Te("goog.messaging.MultiChannel.VirtualChannel");
  h.connect = function (a) {
    a && a();
  };
  h.isConnected = function () {
    return !0;
  };
  h.hb = function (a, b, c) {
    this.h.h.hb(this.g + ":" + a, x(this.wc, this, b), c);
  };
  h.jd = function (a) {
    this.j = x(this.wc, this, a);
  };
  h.Ua = function (a, b) {
    if (this.isDisposed())
      throw Error("#send called for disposed VirtualChannel.");
    this.h.h.Ua(this.g + ":" + a, b);
  };
  h.wc = function (a, b) {
    this.isDisposed()
      ? J(
          this.Dd,
          'Virtual channel "' +
            this.g +
            '" received  a message after being disposed.'
        )
      : a.apply({}, Array.prototype.slice.call(arguments, 1));
  };
  h.D = function () {
    this.h = this.h.g[this.g] = null;
  };
  function Al(a) {
    L.call(this);
    this.h = new xl(a);
    this.l = {};
    this.j = zl(this.h, "private");
    this.A = zl(this.h, "public");
    this.j.hb("mics", x(this.I, this), !0);
  }
  y(Al, L);
  Al.prototype.N = 0;
  Al.prototype.F = Te("goog.messaging.RespondingChannel");
  Al.prototype.D = function () {
    Bg(this.h);
    delete this.h;
    delete this.A;
    delete this.j;
  };
  var Bl = function (a, b, c, d) {
    var e = a.N++;
    a.l[e] = d;
    d = { signature: e };
    d.data = c;
    a.A.Ua(b, d);
  };
  Al.prototype.I = function (a) {
    var b = a.signature;
    a = a.data;
    b in this.l
      ? ((0, this.l[b])(a), delete this.l[b])
      : J(this.F, "Received signature is invalid");
  };
  var Cl = function (a, b, c) {
    a.A.hb(b, x(a.J, a, c), !0);
  };
  Al.prototype.J = function (a, b) {
    a = a(b.data);
    var c = b.signature;
    gi(a).then(
      x(function (d) {
        var e = {};
        e.data = d;
        e.signature = c;
        this.j && this.j.Ua("mics", e);
      }, this)
    );
  };
  var Dl = function (a, b) {
    var c = this;
    a = a === void 0 ? "" : a;
    b = b === void 0 ? null : b;
    this.g = this.o = this.B = null;
    this.C = !1;
    var d = {},
      e = 1,
      f = window.parent;
    if (b != null)
      switch (b) {
        case 3:
          f = window;
        case 2:
          e = 2;
          d.directSyncMode = !0;
          break;
        case 4:
          f = window.parent.frames["goog-messaging-iframe"];
      }
    d.tp = e;
    d.role = 1;
    d.nativeProtocolVersion = 2;
    a && (d.cn = a);
    Ue(Te("goog.net.xpc"), xe);
    this.v = new el(d);
    this.v.aa = f;
    Al.call(this, this.v);
    Cl(this, "general", function (g) {
      a: {
        var k = g.methodName;
        g = g.args;
        if (k in tl) {
          if (c.g) {
            M.Qa("Invoking method: " + k + " with args: " + g.join(", "));
            var m = c.g[k];
            typeof m !== "function" &&
              ((m = c.g.defaultMessageHandler), (g = [k, g]));
            if (typeof m === "function") {
              k = m.apply(c.g, g);
              break a;
            }
          }
          k = null;
        } else k = void 0;
      }
      return k;
    });
  };
  y(Dl, Al);
  Dl.prototype.connect = function (a) {
    this.C || wl()
      ? this.o
        ? ((this.B = Xa()), this.v.connect(x(this.G, this, a)))
        : M.eb("You must call setAssetUrl before connecting.")
      : M.Qa(
          "This class should only listen to messages when served by the rendering libraries."
        );
  };
  Dl.prototype.G = function (a) {
    U(this, "conduitInitialized", [this.o, Array.from(qk.values())]);
    var b = { version: "01_262" };
    b.x = window.STUDIO_SDK_START || null;
    b.c = this.B;
    b.t = Xa();
    U(this, "recordTimings", [b]);
    a && a();
  };
  var U = function (a, b, c, d) {
    var e = {};
    e.methodName = b;
    e.args = c && Array.isArray(c) ? c : [];
    Bl(a, "general", e, d || function () {});
  };
  r("studio.sdk.ContainerState", {
    COLLAPSING: "collapsing",
    COLLAPSED: "collapsed",
    EXPANDING: "expanding",
    EXPANDED: "expanded",
    FS_COLLAPSING: "fs_collapsing",
    FS_EXPANDING: "fs_expanding",
    FS_EXPANDED: "fs_expanded",
  });
  var El = { NONE: 0, LOG_ONLY: 1 };
  r("studio.sdk.ExitFlag", El);
  El.NONE = 0;
  El.LOG_ONLY = 1;
  var Fl = {
    GET_CURRENT_POSITION: "getCurrentPosition",
    GET_DEFAULT_POSITION: "getDefaultPosition",
    GET_SCREEN_SIZE: "getScreenSize",
    CREATE_CALENDAR_EVENT: "createCalendarEvent",
    GET_MAX_SIZE: "getMaxSize",
    PLAY_VIDEO: "playVideo",
    STORE_PICTURE: "storePicture",
    SUPPORTS: "supports",
    USE_CUSTOM_CLOSE: "useCustomClose",
  };
  r("studio.sdk.MraidMethod", Fl);
  var Gl = function () {};
  r("studio.sdk.IEnabler", Gl);
  h = Gl.prototype;
  h.od = function () {};
  h.reportManualClose = function () {};
  h.kd = function () {};
  h.qd = function () {};
  h.pd = function () {};
  h.isVisible = function () {};
  h.na = function () {};
  h.isPageLoaded = function () {};
  h.isInitialized = function () {};
  h.rc = function () {};
  h.getParameter = function () {};
  h.exit = function () {};
  h.Rb = function () {};
  h.Dc = function () {};
  h.counter = function () {};
  h.startTimer = function () {};
  h.stopTimer = function () {};
  h.Fc = function () {};
  h.Ic = function () {};
  h.Bb = function () {};
  h.Ub = function () {};
  h.Ra = function () {};
  h.Tb = function () {};
  h.close = function () {};
  h.Xa = function () {};
  h.ab = function () {};
  h.addEventListener = function () {};
  h.removeEventListener = function () {};
  h.hd = function () {};
  h.gd = function () {};
  h.ld = function () {};
  h.Cc = function () {};
  h.Yb = function () {};
  h.Bc = function () {};
  h.Kc = function () {};
  h.Qc = function () {};
  function Hl(a, b) {
    return (
      "The " +
      a +
      " method has been deprecated. As an alternative please use: " +
      b +
      "."
    );
  }
  function Il(a, b) {
    return 'Custom event "' + a + '" of type "' + b + '" invoked.';
  }
  var Jl = function (a) {
      this.g = a;
      this.h = "";
    },
    Ml = function (a, b, c) {
      for (var d = c.split("&"), e = 0; e < d.length; e++) {
        var f = d[e].split("=");
        if (f.length > 1 && f[0].length && f[1].length) {
          var g = decodeURIComponent(f[0]);
          f = decodeURIComponent(f[1]);
          a.g.set(g, f);
        }
      }
      if (a.g != null && a.g.ia("exitEvents")) {
        d = {};
        e = a.g.get("exitEvents").toString();
        g = e.split("{DELIM}");
        for (f = 0; f < g.length; f++) {
          var k = g[f];
          tb(e, "%2C") && (k = unescape(k));
          var m = {};
          k = k.split(",");
          for (var p = 0; p < k.length; p++)
            if (Kl.test(k[p])) {
              k[p].replace(Ll, "%25$1!");
              var t = k[p].split(":"),
                u = t.shift();
              m[u] = unescape(t.join(":"));
            }
          d[m.name] = m;
        }
        b.exitEvents = d;
      }
      a.h = c;
    };
  Jl.prototype.get = function (a, b) {
    return this.g.get(a, b);
  };
  Jl.prototype.set = function (a, b) {
    return this.g.set(a, b);
  };
  Jl.prototype.ia = function (a) {
    return this.g.ia(a);
  };
  var Kl = /:/,
    Ll = /%(.+)!/;
  var Nl = function (a) {
      this.g = {};
      this.h = new Jl(a);
    },
    Ol = function (a, b, c, d) {
      var e = c;
      d == "Number"
        ? (e = parseInt(c, 10))
        : d == "Boolean" && (e = c.toLowerCase() == "true" || c == "1");
      a.g[b] = e;
    },
    Pl = function (a, b) {
      try {
        var c = JSON.parse(b);
        c != null && ue(a.g, c);
        var d = {};
        le(
          a.g,
          function (e, f) {
            e &&
              !v(e) &&
              ((f = decodeURIComponent(f)), (e = decodeURIComponent(e)));
            f && e && (d[f] = e);
          },
          a
        );
        a.g = d;
      } catch (e) {
        Ml(a.h, a.g, b);
      }
    },
    Ql = function (a, b) {
      var c = a.g;
      return (c !== null && b in c) || a.h.ia(b);
    };
  Nl.prototype.getParameter = function (a, b) {
    var c = this.g;
    return c !== null && a in c ? qe(this.g, a) : this.h.get(a, b);
  };
  Nl.prototype.T = function (a) {
    a = parseInt(this.getParameter(a), 10);
    return isNaN(a) ? null : a;
  };
  Nl.prototype.ca = function (a) {
    a = this.getParameter(a);
    return kb(Sf(a)) ? null : a.toString();
  };
  var Rl = function (a) {
    return (a = a.exec(zb())) ? a[1] : "";
  };
  (function () {
    if (oc) return Rl(/Firefox\/([0-9.]+)/);
    if (dc || ec || cc) return nc;
    if (sc) {
      if (
        Lb() ||
        (wb && Ab && Ab.platform ? Ab.platform === "macOS" : C("Macintosh"))
      ) {
        var a = Rl(/CriOS\/([0-9.]+)/);
        if (a) return a;
      }
      return Rl(/Chrome\/([0-9.]+)/);
    }
    if (tc && !Lb()) return Rl(/Version\/([0-9.]+)/);
    if (pc || qc) {
      if ((a = /Version\/(\S+).*Mobile\/(\S+)/.exec(zb())))
        return a[1] + "." + a[2];
    } else if (rc)
      return (a = Rl(/Android\s+([0-9.]+)/)) ? a : Rl(/Version\/([0-9.]+)/);
    return "";
  })();
  var Sl = function () {
      this.g = !1;
      this.l = [];
    },
    Tl = function (a, b, c) {
      a.h ? U(a.h, b, c) : a.l.push({ type: b, Wd: c });
    },
    Ul = function (a, b, c, d, e, f) {
      Tl(a, f ? "logEventFlushCounters" : "logEvent", [b, c, a.j, !!d, !!e]);
    },
    Wl = function (a) {
      a.g || (Ul(a, "Count", "INTERACTIVE_IMPRESSION"), (a.g = !0), Vl(a));
    },
    Vl = function (a) {
      Tl(a, "flushCounters", [a.j]);
    };
  Sl.prototype.la = function (a, b, c) {
    Tl(this, "logVideoEvent", [a, escape(b), c]);
  };
  var Xl = function (a) {
    Q.call(this);
    this.B = a;
    this.g = this.l = null;
    this.G = !1;
    this.h = null;
    this.v = !1;
    this.o = -1;
    this.C = 0;
  };
  n(Xl, Q);
  Xl.prototype.Vb = function () {
    return this.G;
  };
  Xl.prototype.I = function () {
    this.C = 1;
    this.g && (this.g.stop(), this.g.start());
  };
  Xl.prototype.J = function () {
    this.C = 0;
    this.g && this.g.stop();
  };
  Xl.prototype.F = function () {
    this.B.getParameter("isMouseOver") == "1" || this.C == 1
      ? this.v ||
        ((this.G = !0),
        this.o < 1
          ? (this.o = Xa())
          : 1e3 < Xa() - this.o &&
            ((this.v = !0),
            this.B.dispatchEvent(new T("interaction")),
            U(this.B.H, "setTimerAdjustment", ["INTERACTION_TIMER", -1e3, 0]),
            this.l && (Ul(this.l, "Start", "INTERACTION_TIMER"), Wl(this.l))))
      : (this.v && Yl(this), (this.o = -1));
  };
  var Yl = function (a) {
    a.v = !1;
    a.l && Ul(a.l, "Stop", "INTERACTION_TIMER");
  };
  Xl.prototype.D = function () {
    this.v && Yl(this);
    Cg(this.h, this.g);
    Q.prototype.D.call(this);
  };
  var Zl = function () {
      return new Qg(
        (window.STUDIO_ORIGINAL_ASSET_URL
          ? window.STUDIO_ORIGINAL_ASSET_URL
          : window.location.href
        ).replace(/%(?![A-Fa-f0-9][A-Fa-f0-9])/g, "%25")
      );
    },
    $l = function (a) {
      a && Ch(parseInt(a, 10) || 0);
    };
  var am = function (a) {
    this.g = a;
  };
  am.prototype.j = function (a) {
    return (null === this.g || this.g.canPlayType) && jb(a, "video/");
  };
  am.prototype.h = function (a) {
    return this.g ? "probably" == this.g.canPlayType(a.toLowerCase()) : !1;
  };
  function bm(a) {
    this.g = a;
  }
  bm.prototype.j = function (a) {
    return "image/webp" == a.toLowerCase();
  };
  bm.prototype.h = function (a) {
    if (!this.g) return !1;
    a = a.toLowerCase();
    return jb(this.g.toDataURL(a), "data:" + a);
  };
  var cm = function (a) {
    ke.call(this, a);
  };
  n(cm, ke);
  cm.g = "tagging.common.timing.RumReplicationConfig";
  var dm = pa(["https://securepubads.g.doubleclick.net/pagead/js/rum.js"]);
  function em() {
    this.g = Xa();
  }
  var fm = null;
  em.prototype.set = function (a) {
    this.g = a;
  };
  em.prototype.reset = function () {
    this.set(Xa());
  };
  em.prototype.get = function () {
    return this.g;
  };
  var gm = function (a) {
    this.l = a || "";
    fm || (fm = new em());
    this.v = fm;
  };
  gm.prototype.g = !0;
  gm.prototype.h = !0;
  gm.prototype.j = !1;
  var hm = function (a) {
      return a < 10 ? "0" + a : String(a);
    },
    im = function (a) {
      gm.call(this, a);
    };
  y(im, gm);
  var jm = function (a, b) {
    var c = [];
    c.push(a.l, " ");
    if (a.h) {
      var d = new Date(b.j);
      c.push(
        "[",
        hm(d.getFullYear() - 2e3) +
          hm(d.getMonth() + 1) +
          hm(d.getDate()) +
          " " +
          hm(d.getHours()) +
          ":" +
          hm(d.getMinutes()) +
          ":" +
          hm(d.getSeconds()) +
          "." +
          hm(Math.floor(d.getMilliseconds() / 10)),
        "] "
      );
    }
    d = c.push;
    var e = a.v.get();
    e = (b.j - e) / 1e3;
    var f = e.toFixed(3),
      g = 0;
    if (e < 1) g = 2;
    else for (; e < 100; ) g++, (e *= 10);
    for (; g-- > 0; ) f = " " + f;
    d.call(c, "[", f, "s] ");
    c.push("[", b.h, "] ");
    c.push(b.v);
    a.j &&
      ((b = b.g),
      b !== void 0 && c.push("\n", b instanceof Error ? b.message : String(b)));
    a.g && c.push("\n");
    return c.join("");
  };
  var km = function () {
      this.v = x(this.j, this);
      this.g = new im();
      this.g.h = !1;
      this.g.j = !1;
      this.h = this.g.g = !1;
      this.l = {};
    },
    mm = function () {
      var a = lm;
      if (1 != a.h) {
        var b = Re(Se(), "").g,
          c = a.v;
        b && Re(Se(), b.getName()).h.push(c);
        a.h = !0;
      }
    };
  km.prototype.j = function (a) {
    function b(f) {
      if (f) {
        if (f.value >= ze.value) return "error";
        if (f.value >= Ae.value) return "warn";
        if (f.value >= Ce.value) return "log";
      }
      return "debug";
    }
    if (!this.l[a.h]) {
      var c = jm(this.g, a),
        d = nm;
      if (d) {
        var e = b(a.l);
        om(d, e, c, a.g);
      }
    }
  };
  var lm = null,
    nm = q.console,
    pm = function () {
      lm || (lm = new km());
      q.location && q.location.href.indexOf("Debug=true") != -1 && mm();
    },
    om = function (a, b, c, d) {
      if (a[b]) a[b](c, d === void 0 ? "" : d);
      else a.log(c, d === void 0 ? "" : d);
    };
  var qm = pa([
      "body {\n    position: relative;\n    margin-left: ",
      "px !important;\n    margin-top: ",
      "px !important;\n  }",
    ]),
    rm = pa([""]),
    V = function (a) {
      window.AdobeEdge = window.AdobeEdge || {};
      window.AdobeEdge.bootstrapLoading = !0;
      q.console && (pm(), mm());
      M.info("");
      if (a != sm)
        return (
          M.eb(
            "You must access the enabler instance using studio.Enabler.getInstance(); or Enabler and not create a duplicate instance."
          ),
          !1
        );
      P.call(this);
      this.C = {};
      this.o = {};
      this.I = new rk(sk(), tk() ? window.orientation : 0);
      this.N = new Q(this);
      this.nb = !1;
      this.G = null;
      this.j = "collapsed";
      this.Kb = !1;
      this.wa = null;
      this.Ef = 0;
      this.lb = {};
      this.pa = null;
      this.Jb = !1;
      this.S = new N();
      this.l = null;
      this.Ib = [];
      this.Oa = {};
      this.Mb = [];
      this.h = new Sl();
      this.X = new Xl(this);
      a = ig("CANVAS");
      (a.getContext && a.getContext("2d")) || (a = null);
      this.Ad = new bm(a);
      (a = ig("VIDEO")) || (a = null);
      this.bd = new am(a);
      this.g = new Nl(tm(this));
      a = this.F = new ml();
      a.o = !0;
      R(a, document.body || window, "mousedown", a.C, {
        capture: !0,
        passive: !0,
      });
      R(a, document.body || window, "touchstart", a.C, {
        capture: !0,
        passive: !0,
      });
      this.qc = {};
    };
  y(V, P);
  r("studio.Enabler", V);
  var um = ["c"],
    sm = Math.random(),
    vm = !1,
    wm = null,
    xm = function () {
      wm || (wm = new V(sm));
      return wm;
    };
  V.getInstance = xm;
  h = V.prototype;
  h.fd = -1;
  h.Ob = null;
  h.ec = null;
  h.bc = null;
  h.rd = !0;
  h.Fb = !1;
  h.Pa = !1;
  h.cd = !1;
  h.fc = !1;
  h.Da = null;
  h.Gb = null;
  h.ya = null;
  h.H = null;
  var ym = function (a) {
      a.bc || (a.bc = Zl());
      return a.bc;
    },
    tm = function (a) {
      var b = ym(a).h;
      (a = Gg(ym(a).toString())) &&
        Ig(a, function (c, d) {
          um.indexOf(c) > -1 && b.set(c, d);
        });
      return b;
    };
  V.prototype.init = function () {
    if (!this.Fb) {
      var a = this.g.getParameter("e", null);
      $l(a);
      a = this.T("leftOffset") || 0;
      var b = this.T("topOffset") || 0;
      (a == 0 && b == 0) || zm(this, a, b);
      a = this.Jc("ssr");
      b = [ym(this).l, "://", ym(this).j, ym(this).g].join("");
      qk.clear();
      mk(qk, [1, 2]);
      this.H = new Dl(this.g.getParameter("c", void 0), this.g.T("t"));
      Dg(this, this.H);
      this.H.g = this;
      this.H.o = b.split("?")[0];
      this.H.C = a;
      this.na() ||
        ((a = 1e3),
        vm && (a = 0),
        (this.Da = Am(this, this.yf, "a", a)),
        (a = 2e3),
        (b = 2500),
        vm && (b = a = 0),
        Am(this, this.nc, "b", a),
        Am(this, Wa(this.Lb, !0), "c", b),
        R(this.N, window, ["resize", "orientationchange"], this.Sc),
        this.Sc());
      this.H.connect();
    }
  };
  var Bm = function (a) {
      return !!Ql(a.g, "newton_ot2_token");
    },
    Cm = function (a) {
      if (/Chrome/.test(window.navigator.userAgent)) {
        var b = String(a.g.getParameter("newton_ot2_token"));
        $e(function (c) {
          c = c.document;
          if (b && c.head) {
            var d = Zf("META");
            c.head.appendChild(d);
            d.httpEquiv = "origin-trial";
            d.content = b;
          }
          return !1;
        });
      }
    },
    Fm = function (a) {
      a.Fb = !0;
      a.Gb = a.Hc();
      a.ya = a.Gc();
      if (a.H) {
        var b = a.h,
          c = a.Gb;
        b.h = a.H;
        b.j = c;
        for (c = Vb(b.l); c.length; ) {
          var d = c.shift();
          Tl(b, d.type, d.Wd);
        }
      }
      a.g.getParameter("clickN") == null && Ol(a.g, "clickN", 1);
      a.rd = a.g.getParameter("ise") != "true";
      b = a.g.getParameter("e", null);
      b != null && $l(b);
      b = a.T("leftOffset") || 0;
      c = a.T("topOffset") || 0;
      (b == 0 && c == 0) || zm(a, b, c);
      a.o = a.g.getParameter("exitEvents", {});
      Ql(a.g, "assets") &&
        ((b = a.g.getParameter("assets").toString()), Dm(a, b));
      b = a.g.getParameter("features", []);
      mk(qk, b);
      a.X.l = a.h;
      b = a.X;
      Eh(2) &&
        (R(b, document.body || window, "mouseover", b.I),
        R(b, document.body || window, "mouseout", b.J));
      window.ontouchstart !== void 0 &&
        ((b.g = new Fj(1e3)),
        R(b, b.g, "tick", b.J),
        R(b, document, ["touchstart", "touchmove"], b.I));
      b.h && (Ak(b, b.h, "tick", b.F), b.h.dispose());
      b.h = new Fj(80);
      R(b, b.h, "tick", b.F);
      b.h.start();
      Em(a);
      if ((b = a.getParameter("layoutsConfig"))) a.ec = JSON.parse(String(b));
      if ((b = a.getParameter("experiments"))) a.qc = JSON.parse(String(b));
      if ((b = a.getParameter("rum_config")))
        try {
          var e = JSON.parse(String(b));
          b = window;
          if (!b.google_rum_config && e) {
            var f = ie(cm, Jd(e)),
              g = fe(f, lk);
            if (g) {
              var k = fe(g, kk);
              if (k) {
                b.google_timing_url =
                  "https://securepubads.g.doubleclick.net/pagead/js/rum.js";
                var m = xd(3);
                Zd(k);
                z(I(k));
                var p = H ? k[A(Nc)] : k.g;
                var t = B(p, "state is only maintained on arrays.")[F] | 0;
                G(p, t);
                be(p, t, 2, m === 0 ? void 0 : m);
                var u = Kd(g);
                b.google_rum_config = u;
                var w = w === void 0 ? !1 : w;
                z(Object.isExtensible(f));
                z(I(f));
                var E = H ? f[A(Nc)] : f.g;
                var qa = ae(E, 3);
                var ta = qa !== null ? qa : void 0;
                var eb =
                  ta == null || typeof ta === "boolean"
                    ? ta
                    : typeof ta === "number"
                    ? !!ta
                    : void 0;
                b.google_measure_js_timing = eb != null ? eb : w;
                var Fn = b.document,
                  fs = Xf(dm),
                  Ji = Zf("SCRIPT", Fn);
                Nf(Ji, fs);
                var Df = Fn.getElementsByTagName("script")[0];
                if (Df && Df.parentNode) {
                  Df.parentNode.insertBefore(Ji, Df);
                  var Gn = Ji;
                } else Gn = null;
                Gn ||
                  ((b.google_timing_url = void 0),
                  (b.google_rum_config = void 0),
                  (b.google_measure_js_timing = void 0));
              }
            }
          }
        } catch (gs) {}
      a.dispatchEvent(new T("init"));
      a.S.g || a.S.callback();
      e = a.F;
      e.l = !!a.qc.add_sodar_interaction_signals;
      if (e.l)
        try {
          gk();
        } catch (gs) {}
      Bm(a) && Cm(a);
    };
  V.prototype.pf = function (a) {
    typeof a === "number"
      ? ((this.fd = a), M.info("enabler.setProfileId set to: " + a))
      : M.info("enabler.setProfileId invalid profile id value: " + a);
  };
  V.prototype.setProfileId = V.prototype.pf;
  V.prototype.we = function () {
    return this.fd;
  };
  V.prototype.getProfileId = V.prototype.we;
  V.prototype.lf = function (a) {
    v(a)
      ? ((this.Ob = a), this.isInitialized() && Em(this))
      : M.info("enabler.setDevDynamicContent invalid dcData value: " + a);
  };
  V.prototype.setDevDynamicContent = V.prototype.lf;
  var Em = function (a) {
    if (a.ca("dcData") != null || a.Ob)
      window.dynamicContent = a.ca("dcData") != null ? a.sb() : a.Ob;
  };
  V.prototype.sb = function () {
    var a = this.getParameter("dcData");
    return a ? JSON.parse(String(a)) : null;
  };
  V.prototype.getDynamicDataPayload = V.prototype.sb;
  V.prototype.Fa = function () {
    return this.ec;
  };
  V.prototype.getLayoutsConfig = V.prototype.Fa;
  V.prototype.Gf = function () {
    return this.g.h.h || Yk(this.g);
  };
  V.prototype.getAdParameters = V.prototype.Gf;
  V.prototype.zd = function (a) {
    Pl(this.g, a);
    this.Da && zj(this.Da);
    Fm(this);
    M.info("Asset properties have been set by host.");
  };
  V.prototype.setAdParameters = V.prototype.zd;
  V.prototype.yf = function () {
    this.Da && zj(this.Da);
    M.info(
      "Using default ad parameters in test environment. Simulating local events."
    );
    Fm(this);
  };
  V.setRushSimulatedLocalEvents = function (a) {
    vm = !!a;
    if (a && wm) {
      a = wm;
      for (var b = 0; b < a.Ib.length; ++b) a.dispatchEvent(a.Ib[b]);
    }
  };
  var Am = function (a, b, c, d) {
    d = d != null ? d : 0;
    a.Ib.push(c);
    Gj(
      function () {
        this.dispatchEvent(c);
      },
      d,
      a
    );
    return qj(a, c, b, !1, a);
  };
  V.prototype.Sc = function () {
    var a = sk(),
      b = this.I.g;
    if (this.I.h != a || (tk() && this.I.g != window.orientation)) {
      tk() && (b = window.orientation);
      var c = new T("orientation");
      c.da("mode", a);
      c.da("degrees", b);
      this.dispatchEvent(c);
    }
  };
  V.prototype.B = function (a, b, c) {
    if (!this.na()) {
      var d = x.apply(
        this,
        [a, this].concat(Array.prototype.slice.call(arguments, 2))
      );
      Gj(d, b);
    }
  };
  var Dm = function (a, b) {
    b.length > 0 && b.indexOf("=") == -1 && (b = decodeURIComponent(b));
    b = b.split("&");
    if (!(b.length <= 2 && b[0] == ""))
      for (var c = 0; c < b.length; c++) {
        var d = b[c].split("=");
        a.C[d[0].toLowerCase()] = unescape(d[1]);
      }
  };
  V.prototype.A = function () {
    Vl(this.h);
  };
  V.prototype.reportActivitiesImmediately = V.prototype.A;
  var Gm = function (a) {
      a.h && Wl(a.h);
    },
    Hm = function (a, b) {
      var c = a.g.getParameter("click", ""),
        d = parseInt(a.g.getParameter("clickN"), 10);
      a = a.g.getParameter("thirdPartyClickRedirect", "");
      a: {
        var e = c;
        c = b;
        if (!kb(Sf(e))) {
          e = uk(e, null);
          if (!jb(b, e)) break a;
          c = Rf(c, e.length);
        }
        a && ((c = decodeURIComponent(c)), jb(c, a) && (c = Rf(c, a.length)));
        if (!kb(Sf(e)) && e.indexOf("?") > -1)
          for (b = typeof d === "number" ? d : 1, d = 0; d < b; d++)
            c = unescape(c);
        b = c;
      }
      return b;
    },
    Im = function (a, b, c, d) {
      var e = [];
      rc && e.push("fullscreen");
      e.push("attributionsrc");
      Lf(window, b, c, e.join(","));
      d && a.A();
    },
    Jm = function (a, b, c, d) {
      var e = {};
      e.target = c;
      rc && (e.fullscreen = !0);
      e || (e = {});
      c = window;
      if (b instanceof yf) var f = b;
      else {
        f = typeof b.href != "undefined" ? b.href : String(b);
        var g = g === void 0 ? Ef : g;
        b: if (((g = g === void 0 ? Ef : g), f instanceof yf)) g = f;
        else {
          for (var k = 0; k < g.length; ++k) {
            var m = g[k];
            if (m instanceof Bf && m.Le(f)) {
              g = new yf(f);
              break b;
            }
          }
          g = void 0;
        }
        g === void 0 && Hf(f.toString());
        f = g || zf;
      }
      k = self.crossOriginIsolated !== void 0;
      g = "strict-origin-when-cross-origin";
      window.Request && (g = new Request("/").referrerPolicy);
      m = e.noreferrer;
      if (k && m && g === "unsafe-url")
        throw Error(
          "Cannot use the noreferrer option on a page that sets a referrer-policy of `unsafe-url` in modern browsers!"
        );
      g = m && !k;
      b = e.target || b.target;
      m = [];
      var p = [],
        t = !1;
      for (w in e) {
        var u = e[w];
        switch (w) {
          case "width":
          case "height":
          case "top":
          case "left":
            m.push(w + "=" + u);
            break;
          case "target":
            break;
          case "noopener":
          case "noreferrer":
            u ? p.push(w) : ((t = !0), p.push(w + "=false"));
            break;
          case "attributionsrc":
            m.push(w + (u ? "=" + u : ""));
            break;
          default:
            m.push(w + "=" + (u ? 1 : 0));
        }
      }
      var w =
        b !== void 0 && !["_blank", "_self", "_top", "_parent", ""].includes(b);
      w = Gb() && w;
      if (xb && k && m.length === 0 && p.length > 0 && !w && !t)
        p.length === 2 && (p = ["noreferrer"]), Lf(c, f, b, p[0]);
      else if (
        ((w = m.join(",")),
        Lb() && c.navigator && c.navigator.standalone && b && b != "_self")
      )
        (w = jg(document, "A")),
          (f = Gf(f)),
          f !== void 0 && (w.href = f),
          (w.target = b),
          g && (w.rel = "noreferrer"),
          ((e = e.attributionsrc) || e === "") &&
            w.setAttribute("attributionsrc", e),
          (e = document.createEvent("MouseEvent")),
          e.initMouseEvent("click", !0, !0, c, 1),
          w.dispatchEvent(e);
      else if (g) {
        if (
          ((c = Lf(c, "", b, w)),
          (e = Af(f)),
          c &&
            ((c.opener = null),
            e === "" && (e = "javascript:''"),
            sb.test(e) &&
              (e.indexOf("&") != -1 && (e = e.replace(mb, "&amp;")),
              e.indexOf("<") != -1 && (e = e.replace(nb, "&lt;")),
              e.indexOf(">") != -1 && (e = e.replace(ob, "&gt;")),
              e.indexOf('"') != -1 && (e = e.replace(pb, "&quot;")),
              e.indexOf("'") != -1 && (e = e.replace(qb, "&#39;")),
              e.indexOf("\x00") != -1 && (e = e.replace(rb, "&#0;"))),
            (e =
              '<meta name="referrer" content="no-referrer"><meta http-equiv="refresh" content="0; url=' +
              e +
              '">'),
            Pf("b/12014412, meta tag with sanitized URL"),
            (e = (w = gf()) ? w.createHTML(e) : e),
            (e = new Kf(e)),
            (c = c.document) && c.write))
        ) {
          w = c.write;
          if (e instanceof Kf) e = e.g;
          else throw Error("Unexpected type when unwrapping SafeHtml");
          w.call(c, e);
          c.close();
        }
      } else
        (c = Lf(c, f, b, w)) && e.noopener && (c.opener = null),
          c && e.noreferrer && (c.opener = null);
      d && a.A();
    },
    Km = function (a, b, c, d, e) {
      U(a.H, e ? "logExitFlushEventsOpenPopup" : "launchExit", [
        "Count",
        b,
        a.Gb,
        !1,
        c,
        null,
        d,
      ]);
    },
    Mm = function (a, b, c, d) {
      if (kb(Sf(b))) M.info("There was a problem with the exit call.");
      else if (a.isInitialized()) {
        var e = d !== void 0 ? d : 0;
        d = (a.o[b] && a.o[b].target) || "_blank";
        var f;
        if ((f = !Eh(8)))
          (f = a.g.getParameter("click", "")),
            (f = !(
              tb(f, "[rm_exit_id]") &&
              a.o[b] != null &&
              a.o[b].reportingId != null &&
              !kb(a.o[b].reportingId)
            ));
        e = !(e & 1);
        var g = a.g.getParameter("click", ""),
          k = a.F;
        if (k.o) {
          var m = g;
          k.g.set("dim", nl());
          for (var p = "", t = ma(k.g), u = t.next(); !u.done; u = t.next()) {
            var w = ma(u.value);
            u = w.next().value;
            w = w.next().value;
            p = w == null ? p + "&" + u + "=" : p + "&" + u + "=" + w;
          }
          k.l &&
            ((t = "bg="),
            typeof k.v === "string" && k.B(m, p, t, k.v) && (t = "" + t + k.v),
            (p = p + "&" + t));
          m = p;
          p = g.toLowerCase().indexOf("&adurl=");
          p > -1 && k.B(g, m) && (g = g.substr(0, p) + m + g.substr(p));
        }
        if (e) {
          if (a.o[b])
            if (Eh(8)) Km(a, b, c, g, !0);
            else {
              var E = vk(c);
              E = Lm(a, E, g, b);
              var qa;
              Bm(a) &&
              ((qa = document.featurePolicy) == null
                ? 0
                : qa.allowedFeatures().includes("attribution-reporting"))
                ? Im(a, E, d, !f)
                : Jm(a, E, d, !f);
            }
          else
            c &&
              (a.na() && Eh(8)
                ? Km(a, b, c, g, !1)
                : ((f = vk(c)),
                  (f = Lm(a, f, g, null)),
                  Bm(a) &&
                  ((E = document.featurePolicy) == null
                    ? 0
                    : E.allowedFeatures().includes("attribution-reporting"))
                    ? Im(a, f, d, !0)
                    : Jm(a, f, d, !0),
                  (f = !1)));
          a.g.ca("turtlex_ad_signals") &&
            ((d = a.F),
            (d = { x: d.g.get("nx"), y: d.g.get("ny") }),
            (qa = nl()),
            (E = ol(a.F)),
            U(a.H, "TURTLEX_AD_CLICKED", [
              {
                reportingId: a.o[b].reportingId,
                clickX: d.x,
                clickY: d.y,
                creativeDims: qa,
                bgResponse: E,
              },
            ]));
        }
        f && Ul(a.h, "Count", b, !0, !0, !0);
        U(a.H, "AD_CLICKED");
        d = new T("exit");
        d.da("id", b);
        d.da("url", c);
        a.dispatchEvent(d);
        M.info('Exit "' + b + '" invoked.');
      }
    },
    Nm = function (a, b, c, d, e) {
      a = a.o[b];
      c = !d && a && a.url ? a.url : c;
      e == null || kb(Sf(e))
        ? (e = c)
        : (e += "")
        ? ((d = c.indexOf("#")),
          d < 0 && (d = c.length),
          (a = c.indexOf("?")),
          a < 0 || a > d ? ((a = d), (b = "")) : (b = c.substring(a + 1, d)),
          (c = [c.slice(0, a), b, c.slice(d)]),
          (d = c[1]),
          (c[1] = e ? (d ? d + "&" + e : e) : d),
          (e = c[0] + (c[1] ? "?" + c[1] : "") + c[2]))
        : (e = c);
      return e;
    },
    Lm = function (a, b, c, d) {
      var e = null;
      d && ((e = a.o[d]), (e = e.reportingId != null ? e.reportingId : null));
      b = b || "";
      d = a.g.getParameter("thirdPartyClickRedirect", "");
      a = parseInt(a.g.getParameter("clickN"), 10);
      if (!kb(Sf(c)) && c.indexOf("?") > -1) {
        a = typeof a === "number" ? a : 1;
        for (var f = 0; f < a; f++) b = encodeURIComponent(b);
      }
      e && ((c = uk(c, e)), (b = d ? encodeURIComponent(d + b) : b));
      return c + b;
    };
  V.prototype.reportManualClose = function () {
    M.info("Ad was closed by user action.");
    Ul(this.h, "Count", "EVENT_MANUAL_CLOSE");
  };
  V.prototype.reportManualClose = V.prototype.reportManualClose;
  V.prototype.kd = function () {
    Ul(this.h, "Count", "ENGAGEMENT", !1, !1, !1);
    this.A();
  };
  V.prototype.reportEngagement = V.prototype.kd;
  var Om = function (a, b, c) {
      var d = b;
      d.length > 100 && (d = d.substr(0, 100));
      U(a.H, "reportCustomVariable", [escape(d), c]);
      M.info('Custom string "' + b + '" recorded.');
    },
    zm = function (a, b, c) {
      if (a.na() && !Eh(8)) {
        a.pa && yg(a.pa);
        if (!(b = Wf(qm, -b, -c))) {
          tf(rm, 0);
          b = rm[0];
          if (/</.test(b))
            throw Error(
              "'<' character is forbidden in styleSheet string: " + b
            );
          b = new Of(b);
        }
        a.pa = xg(b);
      }
    };
  V.prototype.Ye = function (a, b, c) {
    Ol(this.g, a, b, c);
  };
  V.prototype.setParameter = V.prototype.Ye;
  V.prototype.nc = function () {
    this.dispatchEvent(new T("pageLoaded"));
  };
  V.prototype.dispatchPageLoaded = V.prototype.nc;
  V.prototype.dispatchEvent = function (a) {
    this.Oa[a.type] = (this.Oa[a.type] || 0) + 1;
    switch (a.type) {
      case "pageLoaded":
        window.AdobeEdge != null &&
          typeof window.AdobeEdge.loadResources === "function" &&
          window.AdobeEdge.loadResources();
        this.cd = !0;
        break;
      case "orientation":
        (this.I.h = a.mode), (this.I.g = a.degrees);
    }
    return V.R.dispatchEvent.call(this, a);
  };
  V.prototype.dispatchEvent = V.prototype.dispatchEvent;
  V.prototype.Lb = function (a) {
    (this.fc = a) && !this.Oa.visible
      ? (window.AdobeEdge != null &&
          typeof window.AdobeEdge.playWhenReady === "function" &&
          window.AdobeEdge.playWhenReady(),
        this.rd && Ul(this.h, "Start", "DISPLAY_TIMER"),
        this.dispatchEvent(new T("visible")))
      : this.Oa.hidden || this.dispatchEvent(new T("hidden"));
    this.dispatchEvent(new T("visibilityChange"));
  };
  V.prototype.setAdVisibleInternal = V.prototype.Lb;
  V.prototype.Ff = function () {
    this.Lb(!0);
  };
  V.prototype.dispatchAdVisible = V.prototype.Ff;
  V.prototype.od = function (a, b, c, d, e, f) {
    if (c || d)
      this.G || (this.G = {}), (this.G.width = c), (this.G.height = d);
    e != null && (this.nb = !!e);
    f != null && Ol(this.g, "isMultiDirectional", f ? "true" : "false");
  };
  V.prototype.setExpandingPixelOffsets = V.prototype.od;
  V.prototype.qd = function (a) {
    this.nb = !!a;
  };
  V.prototype.setStartExpanded = V.prototype.qd;
  V.prototype.pd = function (a) {
    Ol(this.g, "isMultiDirectional", a ? "true" : "false");
  };
  V.prototype.setIsMultiDirectional = V.prototype.pd;
  V.prototype.sf = function (a) {
    U(this.H, "invokeMraidMethod", ["useCustomClose", [a]]);
    this.Jb = a == 0;
  };
  V.prototype.setUseCustomClose = V.prototype.sf;
  V.prototype.mf = function () {};
  V.prototype.setFloatingPixelDimensions = V.prototype.mf;
  V.prototype.isVisible = function () {
    return this.fc;
  };
  V.prototype.isVisible = V.prototype.isVisible;
  V.prototype.na = function () {
    return Eh(1);
  };
  V.prototype.isServingInLiveEnvironment = V.prototype.na;
  V.prototype.isPageLoaded = function () {
    return this.cd;
  };
  V.prototype.isPageLoaded = V.prototype.isPageLoaded;
  V.prototype.isInitialized = function () {
    return this.Fb;
  };
  V.prototype.isInitialized = V.prototype.isInitialized;
  V.prototype.rc = function (a) {
    typeof a === "function" && Di(this.S, a);
  };
  V.prototype.callAfterInitialized = V.prototype.rc;
  V.prototype.getParameter = function (a) {
    return this.g.getParameter(a, null);
  };
  V.prototype.getParameter = V.prototype.getParameter;
  V.prototype.getParameter = V.prototype.getParameter;
  V.prototype.T = function (a) {
    return this.g.T(a);
  };
  V.prototype.getParameterAsInteger = V.prototype.T;
  V.prototype.Jc = function (a) {
    a = this.g.ca(a);
    return a != void 0 && (a.toLowerCase() == "true" || a == "1");
  };
  V.prototype.getParameterAsBoolean = V.prototype.Jc;
  V.prototype.ca = function (a) {
    return this.g.ca(a);
  };
  V.prototype.getParameterAsNullableString = V.prototype.ca;
  V.prototype.exit = function (a, b, c) {
    b !== void 0 && (b = Hm(this, b));
    Gm(this);
    Mm(this, a, Nm(this, a, b, !1), c);
  };
  V.prototype.exit = V.prototype.exit;
  V.prototype.Rb = function (a, b, c) {
    b = Hm(this, b);
    Gm(this);
    Mm(this, a, Nm(this, a, b, !0), c);
  };
  V.prototype.exitOverride = V.prototype.Rb;
  V.prototype.ge = function (a, b, c, d, e) {
    e && !e.pIndex && (e.pIndex = c);
    b = Hm(this, b);
    Gm(this);
    Mm(this, a, Nm(this, a, b, !0), d);
  };
  V.prototype.dynamicExit = V.prototype.ge;
  V.prototype.Sb = function (a, b) {
    Mm(this, a, Nm(this, a, void 0, void 0, b || ""));
  };
  V.prototype.exitQueryString = V.prototype.Sb;
  V.prototype.Dc = function (a) {
    return Lm(this, a, this.g.getParameter("click", ""), null);
  };
  V.prototype.formExitUrlFromOverride = V.prototype.Dc;
  V.prototype.counter = function (a, b) {
    M.info('Counter "' + a + '" invoked.');
    Ul(this.h, "Count", a, b, !0);
    M.Qa(Il(a, "Count"));
  };
  V.prototype.counter = V.prototype.counter;
  V.prototype.startTimer = function (a) {
    M.info('Timer "' + a + '" started.');
    Ul(this.h, "Start", a, void 0, !0);
    M.Qa(Il(a, "Start"));
  };
  V.prototype.startTimer = V.prototype.startTimer;
  V.prototype.stopTimer = function (a) {
    M.info('Timer "' + a + '" stopped.');
    Ul(this.h, "Stop", a, void 0, !0);
    M.Qa(Il(a, "Stop"));
  };
  V.prototype.stopTimer = V.prototype.stopTimer;
  V.prototype.ff = function (a) {
    M.P(
      Hl(
        "Enabler.reportCustomImpressionVariable(postString)",
        "Enabler.reportCustomVariableCount1(customString)"
      )
    );
    Om(this, a, 1);
  };
  V.prototype.reportCustomImpressionVariable = V.prototype.ff;
  V.prototype.gf = function (a) {
    Om(this, a, 1);
  };
  V.prototype.reportCustomVariableCount1 = V.prototype.gf;
  V.prototype.ef = function (a) {
    M.P(
      Hl(
        "Enabler.reportCustomClickVariable(postString)",
        "Enabler.reportCustomVariableCount1(customString)"
      )
    );
    Om(this, a, 2);
  };
  V.prototype.reportCustomClickVariable = V.prototype.ef;
  V.prototype.hf = function (a) {
    Om(this, a, 2);
  };
  V.prototype.reportCustomVariableCount2 = V.prototype.hf;
  V.prototype.Fc = function () {
    return this.j;
  };
  V.prototype.getContainerState = V.prototype.Fc;
  V.prototype.Ic = function () {
    return this.wa;
  };
  V.prototype.getExpandDirection = V.prototype.Ic;
  V.prototype.qf = function (a) {
    this.Kb || U(this.H, "setResponsiveBehavior", [a ? 2 : 0, 2]);
  };
  V.prototype.setResponsiveExpanding = V.prototype.qf;
  V.prototype.rf = function (a, b) {
    U(this.H, "responsiveResize", [a, b]);
  };
  V.prototype.setResponsiveSize = V.prototype.rf;
  V.prototype.Bb = function () {
    if (this.j != "collapsed")
      M.P(
        "Enabler.requestExpand() should not be invoked unless the creative is in the collapsed state."
      );
    else {
      Bj(this, "expandStart") ||
        M.P(
          "Please implement the expansion via event handlers:\nEnabler.addEventListener(\n    studio.events.StudioEvent.EXPAND_START,\n    function() {/* expand action */});"
        );
      this.Kb = !0;
      var a = [this.ya];
      this.G && a.push(this.G);
      U(this.H, "expandRequested", a);
      Pm(this, this.Ra);
      this.B(this.Xc, 0);
    }
  };
  V.prototype.requestExpand = V.prototype.Bb;
  var Pm = function (a, b) {
      if (!a.na() && a.Jb) {
        var c = document.getElementsByTagName("body")[0],
          d = ig("IMG", {
            width: "15",
            height: "15",
            border: "0",
            src: "http://s0.2mdn.net/ads/studio/close.png",
          });
        a.l = {
          callback: b,
          element: ig(
            "DIV",
            {
              style:
                "position: absolute;right: 5px;top: 5px;width: 15px;height: 15px;cursor: pointer;",
            },
            d
          ),
        };
        R(a.N, a.l.element, "click", b);
        mg(c, a.l.element);
      }
    },
    Qm = function (a) {
      a.l &&
        (og(a.l.element),
        Ak(a.N, a.l.element, "click", a.l.callback),
        (a.l.element = null),
        (a.l.callback = null),
        (a.l = null));
    };
  V.prototype.Ze = function () {
    this.dispatchEvent(new T("aboutToExpand"));
  };
  V.prototype.aboutToExpandInternal = V.prototype.Ze;
  V.prototype.Xc = function (a) {
    a && (a = ql[a.toString().toUpperCase()]);
    var b = 0,
      c = 0;
    this.getParameter("isMultiDirectional") == "true" &&
      a &&
      (a.g & 2 && (c = this.T("topOffset")),
      a.g & 1 && (b = this.T("leftOffset")));
    zm(this, b === null ? 0 : b, c === null ? 0 : c);
    a
      ? (this.wa = a)
      : (this.wa =
          this.na() || this.getParameter("isMultiDirectional") != "true"
            ? null
            : rl[this.Ef++ % rl.length]);
    this.nb ||
      (Ul(this.h, "Start", "EXPAND_TIMER"),
      Gm(this),
      this.Pa || (this.A(), (this.Pa = !0)));
    this.nb = !1;
    this.j = "expanding";
    a = new T("expandStart");
    a.da("direction", this.wa);
    this.dispatchEvent(a);
  };
  V.prototype.startExpandInternal = V.prototype.Xc;
  V.prototype.Ub = function () {
    this.j != "expanding"
      ? M.P(
          "You must first call Enabler.requestExpand() to initiate the expansion and then call Enabler.finishExpand() when the expand animation has  finished. Cancelling expansion..."
        )
      : (U(this.H, "expandFinished", [this.ya]),
        (this.j = "expanded"),
        M.info("The creative has expanded."),
        this.dispatchEvent(new T("expandFinish")));
  };
  V.prototype.finishExpand = V.prototype.Ub;
  V.prototype.expand = function (a, b) {
    M.P(
      "The Enabler.expand() method has been deprecated. As an alternative please use: Enabler.requestExpand()."
    );
    zm(this, 0, 0);
    var c = [this.ya];
    b && c.push(b);
    this.Jb = !!b && b.useCustomClose == 0;
    U(this.H, "expandAsset", c);
    a || (Ul(this.h, "Start", "EXPAND_TIMER"), Gm(this));
    this.Pa || (this.A(), (this.Pa = !0));
    M.info("The creative has expanded.");
  };
  V.prototype.expand = V.prototype.expand;
  V.prototype.Ra = function () {
    this.j != "expanded" &&
      M.P(
        "Enabler.requestCollapse() should not be invoked unless the creative is in the expanded state."
      );
    Qm(this);
    Bj(this, "collapseStart") ||
      M.P(
        "Please implement collapse via event handlers:\nEnabler.addEventListener(\n    studio.events.StudioEvent.COLLAPSE_START,\n    function() {/* Begin collapse animation */});"
      );
    U(this.H, "collapseRequested", [this.ya]);
    this.B(this.Wc, 0);
  };
  V.prototype.requestCollapse = V.prototype.Ra;
  V.prototype.Wc = function () {
    this.j = "collapsing";
    this.dispatchEvent(new T("collapseStart"));
  };
  V.prototype.startCollapseInternal = V.prototype.Wc;
  V.prototype.Tb = function () {
    this.j != "collapsing"
      ? M.P(
          "You must first call Enabler.requestCollapse() to initiate the collapse and then call Enabler.finishCollapse() when the collapse animation has  finished. Cancelling collapse..."
        )
      : (U(this.H, "collapseFinished", [this.ya]), this.B(this.sc, 0));
  };
  V.prototype.finishCollapse = V.prototype.Tb;
  V.prototype.sc = function () {
    var a = this.T("leftOffset") || 0,
      b = this.T("topOffset") || 0;
    zm(this, a, b);
    Ul(this.h, "Stop", "EXPAND_TIMER");
    this.j = "collapsed";
    M.info("The creative has collapsed.");
    this.dispatchEvent(new T("collapseFinish"));
  };
  V.prototype.finishCollapseInternal = V.prototype.sc;
  V.prototype.collapse = function () {
    M.P(
      "The Enabler.collapse() method has been deprecated. As an alternative please use: Enabler.requestCollapse()."
    );
    Bj(this, "collapse") ||
      M.P(
        "Please implement collapse via event handlers:\nEnabler.addEventListener(\n    studio.events.StudioEvent.COLLAPSE_START,\n    function() {/* Begin collapse animation */});"
      );
    var a = this.T("leftOffset") || 0,
      b = this.T("topOffset") || 0;
    zm(this, a, b);
    U(this.H, "collapseAsset", [this.ya]);
    this.dispatchEvent(new T("collapse"));
    Ul(this.h, "Stop", "EXPAND_TIMER");
  };
  V.prototype.collapse = V.prototype.collapse;
  V.prototype.close = function () {
    this.X.dispose();
    U(this.H, "tellAssetHide", [this.ya]);
    M.info(
      "Closing ad. If this was invoked by a user action, call Enabler.reportManualClose() as well."
    );
  };
  V.prototype.close = V.prototype.close;
  V.prototype.Zd = function () {};
  V.prototype.closeCompanion = V.prototype.Zd;
  V.prototype.ee = function () {};
  V.prototype.displayCompanion = V.prototype.ee;
  V.prototype.se = function () {
    return this.ca("sn");
  };
  V.prototype.getDartSiteName = V.prototype.se;
  V.prototype.re = function () {
    return this.T("sid");
  };
  V.prototype.getDartSiteId = V.prototype.re;
  V.prototype.oe = function () {
    return this.T("aid");
  };
  V.prototype.getDartAdId = V.prototype.oe;
  V.prototype.qe = function () {
    return this.T("pid");
  };
  V.prototype.getDartPageId = V.prototype.qe;
  V.prototype.Hc = function () {
    return this.ca("rid");
  };
  V.prototype.getDartRenderingId = V.prototype.Hc;
  V.prototype.pe = function () {
    return this.T("cid");
  };
  V.prototype.getDartCreativeId = V.prototype.pe;
  V.prototype.Gc = function () {
    return this.ca("varName");
  };
  V.prototype.getDartAssetId = V.prototype.Gc;
  V.prototype.ze = function () {
    return this.ca("ct");
  };
  V.prototype.getUserCountry = V.prototype.ze;
  V.prototype.Be = function () {
    return this.ca("st");
  };
  V.prototype.getUserState = V.prototype.Be;
  V.prototype.Ce = function () {
    return this.ca("zp");
  };
  V.prototype.getUserZipCode = V.prototype.Ce;
  V.prototype.ye = function () {
    var a = this.T("bw");
    return a != null ? a : 0;
  };
  V.prototype.getUserBandwidth = V.prototype.ye;
  V.prototype.xe = function () {
    return this.ca("ac");
  };
  V.prototype.getUserAreaCode = V.prototype.xe;
  V.prototype.Ae = function () {
    return this.T("dma");
  };
  V.prototype.getUserDMACode = V.prototype.Ae;
  V.prototype.getFilename = function (a) {
    M.P(
      "The method: Enabler.getFilename(filename) has been deprecated. As an alternative please use: Enabler.getUrl(filename)."
    );
    return this.Xa(a);
  };
  V.prototype.getFilename = V.prototype.getFilename;
  V.prototype.Xa = function (a) {
    var b = a.toLowerCase(),
      c = b.slice(b.lastIndexOf("/") + 1),
      d = encodeURIComponent(c),
      e = this.C[c];
    e =
      (e =
        (e =
          (e = (e = e || this.C["pro_" + c]) || this.C[b]) ||
          this.C["pro_" + b]) || this.C[d]) || this.C["pro_" + d];
    return e != null ? e : a;
  };
  V.prototype.getUrl = V.prototype.Xa;
  V.prototype.ve = function () {
    return this.I;
  };
  V.prototype.getOrientation = V.prototype.ve;
  V.prototype.la = function (a, b, c) {
    this.h.la(a, b, c);
    M.info('Video "' + b + '" dispatching "' + c + '" event.');
  };
  V.prototype.wd = function (a, b) {
    if (a)
      for (var c = 0; c < this.Mb.length; ++c) {
        var d = this.Mb[c];
        if (d != null)
          switch (a) {
            case "changevolume":
              b != null && (b > 0 && (d.muted = !1), (d.volume = b));
              break;
            case "pause":
              d.pause();
              break;
            case "resume":
              d.play();
          }
      }
  };
  V.prototype.invokeOnAllVideos = V.prototype.wd;
  V.prototype.Tc = function (a) {
    a != null && this.Mb.push(a);
  };
  V.prototype.registerVideoElements = V.prototype.Tc;
  V.prototype.Oe = function (a, b) {
    a = Oi(Hj(a));
    b != null && Di(a, b);
  };
  V.prototype.loadScript = V.prototype.Oe;
  V.prototype.ab = function (a, b) {
    Og(Ih, a)
      ? Di(this.S, Wa(Tj, a, b))
      : M.eb("There is no module called " + a + ".");
  };
  V.prototype.loadModule = V.prototype.ab;
  V.prototype.Ne = function (a, b) {
    for (var c = a.length, d = 0; d < a.length; ++d)
      this.ab(a[d], function () {
        --c == 0 && b();
      });
  };
  V.prototype.loadModules = V.prototype.Ne;
  V.prototype.Pc = function (a) {
    M.info('Dispatching function invocation "' + a + '" on parent.');
    U(this.H, "invokeExternalJSFunction", [escape(a)]);
  };
  V.prototype.invokeExternalJsFunction = V.prototype.Pc;
  V.prototype.Qc = function (a, b, c) {
    a in Fl ||
      M.P(
        'The mraid method "' +
          a +
          "\" isn't allowed to be invoked, please use one of the corresponding Enabler methods."
      );
    var d = 'Method "' + a + '" invoked';
    b && (d += 'with arguments "' + b.join(",") + '"');
    M.info(d + ".");
    U(this.H, "invokeMraidMethod", [a, b], c);
  };
  V.prototype.invokeMraidMethod = V.prototype.Qc;
  V.prototype.Hf = function () {
    M.P("The method: Enabler.invokeAdMobMethod has been deprecated.");
  };
  V.prototype.invokeAdMobMethod = V.prototype.Hf;
  V.prototype.J = function (a, b, c, d) {
    Og(wk, a)
      ? U(this.H, "invokeExternalJSFunctionWithReturn", [a, b, c], d)
      : M.eb(
          'The whitelist global object "' +
            a +
            "\" isn't whitelisted, please only call methods on one of the existing whitelisted objects."
        );
  };
  V.prototype.invokeExternalJsFunctionWithReturn = V.prototype.J;
  V.prototype.xd = function (a, b) {
    M.info("Dispatching function invocation openUrl on parent.");
    U(this.H, "invokeUrlOpen", [a], b);
  };
  V.prototype.invokeUrlOpen = V.prototype.xd;
  V.prototype.D = function () {
    this.pa && yg(this.pa);
    this.Da && zj(this.Da);
    Cg(this.X, this.h, this.N, this.S, this.F);
    delete this.lb;
    V.R.D.call(this);
  };
  V.prototype.addEventListener = function (a, b, c, d, e) {
    a = ll[a.toString()] || a;
    if (a.toString() in il) {
      if (!this.na()) {
        e = b;
        typeof b === "function" &&
          (e = function (f) {
            f.me ? b(f.ba) : b(f);
          });
        R(this.N, window, a, e, c, d);
        return;
      }
      U(this.H, "registerEventTypeListenerForType", [a, e]);
    }
    a == "hostpageFeaturesLoaded" && U(this.H, "getHostpageFeatures", [a]);
    rj(this, a, b, c, d);
  };
  V.prototype.addEventListener = V.prototype.addEventListener;
  V.prototype.removeEventListener = function (a, b, c, d) {
    yj(this, a, b, c, d);
  };
  V.prototype.removeEventListener = V.prototype.removeEventListener;
  V.prototype.Nb = function (a, b) {
    this.lb[a] = b;
  };
  V.prototype.addMessageHandler = V.prototype.Nb;
  V.prototype.cf = function (a) {
    delete this.lb[a];
  };
  V.prototype.removeMessageHandler = V.prototype.cf;
  V.prototype.Bf = function (a, b) {
    a = this.lb[a];
    typeof a === "function" && a.apply(null, b);
  };
  V.prototype.defaultMessageHandler = V.prototype.Bf;
  V.prototype.hd = function () {
    Bj(this, "fullscreenSupport") ||
      M.P(
        "Please implement an event handler in order to receive support status:\nEnabler.addEventListener(\n    studio.events.StudioEvent.FULLSCREEN_SUPPORT,\n    function() {/* query event for fullscreen status */});"
      );
    U(this.H, "isFullscreenSupported");
    this.B(this.Rc, 0, !0);
  };
  V.prototype.queryFullscreenSupport = V.prototype.hd;
  V.prototype.gd = function () {
    Bj(this, "fullscreenDimensions") ||
      M.P(
        "Please implement an event handler in order to receive dimensions:\nEnabler.addEventListener(\n    studio.events.StudioEvent.FULLSCREEN_DIMENSIONS,\n    function() {/* query event for fullscreen dimensions */});"
      );
    U(this.H, "queryFullscreenDimensions");
    if (!this.na()) {
      var a = gg();
      this.B(this.Ec, 0, a.width, a.height);
    }
  };
  V.prototype.queryFullscreenDimensions = V.prototype.gd;
  V.prototype.ld = function (a, b) {
    if (this.j != "collapsed")
      M.P(
        "Enabler.requestFullscreenExpand() should not be invoked unless the  creative is in the collapsed state."
      );
    else {
      Bj(this, "fullscreenExpandStart") ||
        M.P(
          "Please implement the fullscreen expansion via event handlers:\nEnabler.addEventListener(\n    studio.events.StudioEvent.FULLSCREEN_EXPAND_START,\n    function() {/* expand action */});"
        );
      this.Kb = !0;
      var c = [];
      a && b && (c = [a, b]);
      U(this.H, "fullscreenExpandRequested", c);
      Pm(this, this.Yb);
      this.B(this.Oc, 0, a, b);
    }
  };
  V.prototype.requestFullscreenExpand = V.prototype.ld;
  V.prototype.Cc = function () {
    this.j != "fs_expanding"
      ? M.P(
          "You must first call Enabler.requestFullscreenExpand() to initiate the expansion and then call Enabler.finishFullscreenExpand() when the expand animation has finished. Cancelling expansion..."
        )
      : (U(this.H, "fullscreenExpandFinished"),
        M.info("The creative has expanded."),
        this.B(this.Mc, 0));
  };
  V.prototype.finishFullscreenExpand = V.prototype.Cc;
  V.prototype.Yb = function () {
    this.j != "fs_expanded"
      ? M.P(
          "Enabler.requestFullscreenCollapse() should not be invoked unless the  creative is in the fullscreen state."
        )
      : (Bj(this, "fullscreenCollapseStart") ||
          M.P(
            "Please implement fullscreen collapse via event handlers:\nEnabler.addEventListener(\n    studio.events.StudioEvent.FULLSCREEN_COLLAPSE_START,\n    function() {/* Begin collapse animation */});"
          ),
        Qm(this),
        U(this.H, "fullscreenCollapseRequested"),
        this.B(this.Ac, 0));
  };
  V.prototype.requestFullscreenCollapse = V.prototype.Yb;
  V.prototype.Bc = function () {
    this.j != "fs_collapsing"
      ? M.P(
          "You must first call Enabler.requestFullscreenCollapse() to initiate the collapse and then call Enabler.finishFullscreenCollapse() when the collapse animation has finished. Cancelling collapse..."
        )
      : (U(this.H, "fullscreenCollapseFinished"), this.B(this.xc, 0));
  };
  V.prototype.finishFullscreenCollapse = V.prototype.Bc;
  V.prototype.af = function (a) {
    U(this.H, "registerChargeableEventName", [a]);
  };
  V.prototype.registerChargeableEventName = V.prototype.af;
  V.prototype.Vb = function () {
    return this.X.Vb();
  };
  V.prototype.hasUserInteracted = V.prototype.Vb;
  V.prototype.Rc = function (a) {
    var b = new T("fullscreenSupport");
    b.da("supported", a);
    this.dispatchEvent(b);
  };
  V.prototype.fullscreenSupportInternal = V.prototype.Rc;
  V.prototype.Ec = function (a, b) {
    var c = new T("fullscreenDimensions");
    a != void 0 && b != void 0 && (c.da("width", a), c.da("height", b));
    this.dispatchEvent(c);
  };
  V.prototype.fullscreenDimensionsInternal = V.prototype.Ec;
  V.prototype.Oc = function (a, b, c, d) {
    Ul(this.h, "Start", "EXPAND_TIMER");
    Gm(this);
    this.Pa || (this.A(), (this.Pa = !0));
    this.j = "fs_expanding";
    var e = new T("fullscreenExpandStart");
    e.da("width", a);
    e.da("height", b);
    e.da("left", c);
    e.da("top", d);
    this.dispatchEvent(e);
  };
  V.prototype.fullscreenExpandStartInternal = V.prototype.Oc;
  V.prototype.Mc = function () {
    this.j = "fs_expanded";
    this.dispatchEvent(new T("fullscreenExpandFinish"));
  };
  V.prototype.fullscreenExpandFinishInternal = V.prototype.Mc;
  V.prototype.Ac = function () {
    this.j = "fs_collapsing";
    this.dispatchEvent(new T("fullscreenCollapseStart"));
  };
  V.prototype.fullscreenCollapseStartInternal = V.prototype.Ac;
  V.prototype.xc = function () {
    Ul(this.h, "Stop", "EXPAND_TIMER");
    this.j = "collapsed";
    this.dispatchEvent(new T("fullscreenCollapseFinish"));
  };
  V.prototype.fullscreenCollapseFinishInternal = V.prototype.xc;
  V.prototype.vf = function () {
    return this.Ad.h("image/webp");
  };
  V.prototype.canRenderWebpImages = V.prototype.vf;
  V.prototype.Yc = function (a) {
    return this.bd.j(a) ? this.bd.h(a) : !1;
  };
  V.prototype.supportsVideoFormat = V.prototype.Yc;
  V.prototype.nf = function () {
    return this;
  };
  V.prototype.setHint = V.prototype.nf;
  V.prototype.Kc = function () {
    a: {
      for (a in Gh)
        if (Gh[a] == "studio") {
          var a = "studio";
          break a;
        }
      a = null;
    }
    return a || "studio";
  };
  V.prototype.getSdk = V.prototype.Kc;
  var Rm = xm();
  r("Enabler", Rm);
  xm().init();
  Ij.enabler = 3;
  var Sm = [],
    Tm = function (a) {
      z(
        !Object.isSealed(a),
        "Cannot use getInstance() with a sealed constructor."
      );
      var b = "Ga";
      if (a.Ga && a.hasOwnProperty(b)) return a.Ga;
      Sm.push(a);
      var c = new a();
      a.Ga = c;
      z(a.hasOwnProperty(b), "Could not instantiate singleton.");
      return c;
    };
  function W() {
    P.call(this);
    this.g = "loading";
    this.h = q.Enabler;
    this.h.isInitialized() ? this.j() : rj(this.h, "init", this.j, !1, this);
  }
  y(W, P);
  W.prototype.l = function () {
    return this.g;
  };
  W.prototype.getState = W.prototype.l;
  W.prototype.A = function () {
    return "1.0";
  };
  W.prototype.getVersion = W.prototype.A;
  W.prototype.open = function () {
    this.h.exit("MRAID default exit");
  };
  W.prototype.open = W.prototype.open;
  W.prototype.close = function () {
    this.g == "expanded"
      ? (this.h.Ra(), (this.g = "default"), this.dispatchEvent("stateChange"))
      : this.g == "default" &&
        ((this.g = "hidden"),
        this.h.close(),
        this.dispatchEvent("stateChange"));
  };
  W.prototype.close = W.prototype.close;
  W.prototype.B = function () {
    return this.h.isVisible();
  };
  W.prototype.isViewable = W.prototype.B;
  W.prototype.expand = function () {
    this.g == "default" &&
      (this.h.Bb(), (this.g = "expanded"), this.dispatchEvent("stateChange"));
  };
  W.prototype.expand = W.prototype.expand;
  W.prototype.j = function () {
    this.g = "default";
    rj(this.h, "collapseStart", this.o, !1, this);
    this.dispatchEvent("ready");
  };
  W.prototype.o = function () {
    this.g == "expanded" &&
      ((this.g = "default"), this.dispatchEvent("stateChange"));
  };
  if (!window.mraid) {
    var Um = Tm(W);
    r("mraid", Um);
  }
  r("studio.sdk.hint.ExpansionMode", {
    NORMAL: "normal",
    LIGHTBOX: "lightbox",
  });
  r("studio.sdk.hint.ExpansionTrigger", {
    ON_CLICK: "onClick",
    ON_HOVER: "onHover",
  });
  r("studio.sdk.hint.Hint", {
    EXPANSION_MODE: "expansionMode",
    EXPANSION_TRIGGER: "expansionTrigger",
  });
  function Vm(a) {
    return "Config type " + a + " does not exist";
  }
  function Wm(a) {
    return (
      "Unable to parse a type for value with JavaScript type " +
      Pa(a) +
      ': "' +
      a +
      '"'
    );
  }
  function Xm(a, b) {
    return (
      "Cannot handle description for property " + b + " on type " + a + "."
    );
  }
  function Ym(a, b) {
    return (
      "Array property " +
      b +
      " on type " +
      a +
      " must have at least one element."
    );
  }
  function Zm(a, b) {
    return "Invalid type for value of property " + b + " on type " + a + ".";
  }
  function $m(a, b) {
    return (
      "No value specified for non-optional property " +
      b +
      " on type " +
      a +
      "."
    );
  }
  function an(a, b) {
    return "Property " + b + " does not exist on type " + a + ".";
  }
  function bn(a, b) {
    return "Property " + b + " is not an array on type " + a + ".";
  }
  function cn(a, b, c, d) {
    return (
      "Property " +
      b +
      " on type " +
      a +
      " has length " +
      c +
      ", but invalid index " +
      d +
      " was requested."
    );
  }
  function dn(a) {
    return "The optional property " + a + " must be a reference";
  }
  var en = function () {},
    fn = function (a) {
      var b = xm();
      b.isInitialized() ? a(b) : b.v.add("init", Wa(a, b), !0, void 0, void 0);
    },
    gn = function () {
      return new ci(function (a) {
        var b = xm();
        b.isInitialized()
          ? a(b)
          : b.v.add("init", Wa(a, b), !0, void 0, void 0);
      });
    };
  r("studio.utils.EnablerAccessor", en);
  en.loadModuleWhenReady = function (a, b) {
    fn(function (c) {
      c.ab(a, b);
    });
  };
  en.getInitializedEnabler = gn;
  en.getInitializedEnablerByCallback = fn;
})();
