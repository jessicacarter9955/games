!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "95510fb7-903e-57d7-b457-b3c8616971ac"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `07b9fe9a-b841-413e-ae51-fa79a7edc545`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-07b9fe9a-b841-413e-ae51-fa79a7edc545`));
  } catch {}
})();
import {
  Jt as e,
  Xt as t,
  _t as n,
  fn as r,
  gn as i,
  gt as a,
  lt as o,
  on as s,
  pt as c,
  rt as l,
  un as u,
  wn as d,
  yn as f,
} from "../../bundle.js";
var p = d(f()),
  m = u(),
  h = d(a()),
  g = {
    content: `_content_2j574_7`,
    close: `_close_2j574_13`,
    closeIcon: `_closeIcon_2j574_34`,
    body: `_body_2j574_38`,
    preview: `_preview_2j574_48`,
    previewImage: `_previewImage_2j574_53`,
    title: `_title_2j574_58`,
    description: `_description_2j574_63`,
    actions: `_actions_2j574_69`,
    button: `_button_2j574_75`,
  },
  _ = i();
function v(e) {
  t.getInstance().sendEvent({
    type: `notificationAction`,
    notificationSource: `chrome-pointer-warning`,
    action: e,
  });
}
var y = `PointerKey_count`,
  b = `PointerKey_lastTime`,
  x = p.lazy(() => r(() => import(`../../bundle.js`), [], import.meta.url)),
  S = () => {
    let t = (0, m.c)(10),
      [r, i] = p.useState(!1),
      a = s().device?.browser,
      u;
    t[0] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((u = () => {
          v(`closed`), i(!1);
        }),
        (t[0] = u))
      : (u = t[0]);
    let d = u,
      f;
    t[1] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((f = () => {
          i(!1), v(`ignored`);
        }),
        (t[1] = f))
      : (f = t[1]);
    let S = f,
      C;
    t[2] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((C = () => {
          i(!1), v(`continue`);
        }),
        (t[2] = C))
      : (C = t[2]);
    let w = C,
      T,
      E;
    t[3] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((T = () => {
          let t = async function () {
              let t = s().device?.browser,
                n = t?.name === `Chrome`,
                r = t?.name === `Opera`,
                a = n && t.major && parseInt(t.major) >= 131,
                o = r && t.major && parseInt(t.major) >= 118;
              if (
                (a || o) &&
                (await navigator.permissions.query({ name: `pointer-lock` }))
                  .state === `denied`
              ) {
                let n = `${t?.name?.toLowerCase()}${y}`,
                  r = `${t?.name?.toLowerCase()}${b}`,
                  a = e.Instance.getItem(n) ?? `1`,
                  o = e.Instance.getItem(r),
                  s = Date.now() - 3e5,
                  c = o ? new Date(o).getTime() : 0;
                Number.parseInt(a) <= 5 &&
                  c < s &&
                  (e.Instance.setItem(n, `${Number.parseInt(a) + 1}`),
                  e.Instance.setItem(r, `${new Date()}`),
                  v(`shown`),
                  i(!0));
              }
            },
            n = (0, h.default)(async () => {
              try {
                await t();
              } catch (e) {
                console.error(e);
              }
            }, 300);
          return n(), () => n.cancel();
        }),
        (E = []),
        (t[3] = T),
        (t[4] = E))
      : ((T = t[3]), (E = t[4])),
      p.useEffect(T, E);
    let D =
      a?.name === `Chrome`
        ? `chrome_pointer_permissions_v2.png`
        : `opera_pointer_permissions.png`;
    if (r) {
      let e;
      t[5] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((e = (0, _.jsx)(`button`, {
            type: `button`,
            className: g.close,
            onClick: d,
            children: (0, _.jsx)(c, {
              name: `close`,
              size: 20,
              className: g.closeIcon,
            }),
          })),
          (t[5] = e))
        : (e = t[5]);
      let r;
      t[6] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((r = (0, _.jsxs)(`div`, {
            className: g.body,
            children: [
              (0, _.jsx)(`div`, {
                className: g.preview,
                children: (0, _.jsx)(`img`, {
                  src: n(D, { quality: 100 }),
                  alt: `Mouse permissions disabled`,
                  className: g.previewImage,
                }),
              }),
              (0, _.jsx)(`h2`, {
                className: g.title,
                children: `Mouse permissions disabled`,
              }),
              (0, _.jsx)(`p`, {
                className: g.description,
                children: `To ensure all games run smoothly, CrazyGames needs browser permission to lock your mouse.`,
              }),
            ],
          })),
          (t[6] = r))
        : (r = t[6]);
      let i;
      t[7] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((i = (0, _.jsxs)(`div`, {
            className: g.actions,
            children: [
              (0, _.jsx)(l, {
                variant: `outlined`,
                color: `white`,
                height: 34,
                className: g.button,
                onClick: S,
                children: `Ignore`,
              }),
              (0, _.jsx)(l, {
                variant: `contained`,
                height: 34,
                className: g.button,
                onClick: w,
                children: `Done`,
              }),
            ],
          })),
          (t[7] = i))
        : (i = t[7]);
      let a;
      return (
        t[8] === r
          ? (a = t[9])
          : ((a = (0, _.jsx)(p.Suspense, {
              children: (0, _.jsx)(x, {
                hideBackdrop: !0,
                children: (0, _.jsxs)(o, {
                  className: g.content,
                  children: [e, r, i],
                }),
              }),
            })),
            (t[8] = r),
            (t[9] = a)),
        a
      );
    }
    return null;
  };
export { S as default };
//# debugId=95510fb7-903e-57d7-b457-b3c8616971ac
