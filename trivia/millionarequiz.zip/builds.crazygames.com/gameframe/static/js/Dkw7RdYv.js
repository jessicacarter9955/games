!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "b379f365-27a2-521e-96c3-5ab7cca46cf4"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `70b6c165-7894-4871-a4dc-e97067bea47e`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-70b6c165-7894-4871-a4dc-e97067bea47e`));
  } catch {}
})();
import { Kt as e, xn as t } from "../../bundle.js";
var n = 0.01,
  r = class {
    constructor() {
      t(this, `lastReportedProgress`, void 0),
        t(this, `currentProgress`, 0),
        t(this, `passedFirstIncrement`, !1);
    }
    trackLoadStarted() {
      e.trackProgress(0), (this.lastReportedProgress = 0), e.gameStartLoad();
    }
    trackProgress(t) {
      if (t <= this.currentProgress) return this.currentProgress;
      this.currentProgress = t;
      let r = Math.floor(t * 10) / 10;
      return (
        r !== 1 &&
          t > 0 &&
          (!this.passedFirstIncrement && t >= 0.01 && t < 0.1
            ? ((this.passedFirstIncrement = !0),
              e.trackProgress(n),
              (this.lastReportedProgress = t))
            : ((!this.lastReportedProgress && t > 0.1) ||
                (this.lastReportedProgress &&
                  t > this.lastReportedProgress + 0.1)) &&
              (e.trackProgress(r), (this.lastReportedProgress = t))),
        t
      );
    }
    trackLoadFinished() {
      this.lastReportedProgress !== 1 &&
        ((this.lastReportedProgress = 1), e.trackProgress(1), e.loadFinished());
    }
  };
export { r as t };
//# debugId=b379f365-27a2-521e-96c3-5ab7cca46cf4
