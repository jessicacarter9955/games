!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "2509146d-ac11-56c1-a986-8aaafbe8a2e2"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `656ce7b5-d83a-4450-90cc-1bd97c0f81e6`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-656ce7b5-d83a-4450-90cc-1bd97c0f81e6`));
  } catch {}
})();
import {
  a as e,
  c as t,
  i as n,
  n as r,
  o as i,
  r as a,
  t as o,
} from "./BV51Sc2-.js";
import {
  $ as s,
  E as c,
  It as l,
  Kt as u,
  Pt as d,
  Sn as f,
  Wt as p,
  Xt as m,
  Y as h,
  Yt as g,
  _n as _,
  a as v,
  at as y,
  dn as b,
  et as x,
  fn as S,
  gn as C,
  hn as w,
  ht as T,
  i as E,
  jt as D,
  ln as O,
  mn as k,
  nt as A,
  ot as j,
  pt as M,
  rn as N,
  rt as P,
  un as F,
  vn as I,
  w as L,
  wn as R,
  xn as z,
  y as ee,
  yn as te,
} from "../../bundle.js";
import { t as B } from "./Cv4pZRH12.js";
var V = R(te()),
  H = F(),
  ne = {
    inviteButton: `_inviteButton_1sjys_7`,
    isActive: `_isActive_1sjys_7`,
    "horizontal-shaking": `_horizontal-shaking_1sjys_1`,
  },
  U = C(),
  re = () => {
    let e = (0, H.c)(7),
      {
        showInviteButton: t,
        inviteButtonActive: n,
        inviteLink: r,
        onInviteButtonClick: i,
      } = V.useContext(ee),
      { gameLoadStatus: a } = V.useContext(D),
      o = a === `GAME_LOADED`,
      s = r;
    if (!o) return null;
    let c;
    e[0] !== n || e[1] !== s || e[2] !== i || e[3] !== t
      ? ((c =
          (t || n) &&
          (0, U.jsx)(h, {
            size: `xs`,
            icon: { position: `left`, code: `friends` },
            label: _._(`inviteFriends.footer.button`),
            "data-testid": `footer-invite-button`,
            disabled: !s,
            onClick: i,
            className: T(ne.inviteButton, n && s && ne.isActive),
          })),
        (e[0] = n),
        (e[1] = s),
        (e[2] = i),
        (e[3] = t),
        (e[4] = c))
      : (c = e[4]);
    let l;
    return (
      e[5] === c
        ? (l = e[6])
        : ((l = (0, U.jsx)(U.Fragment, { children: c })),
          (e[5] = c),
          (e[6] = l)),
      l
    );
  },
  W = {
    root: `_root_8ak83_7`,
    closeIcon: `_closeIcon_8ak83_20`,
    action: `_action_8ak83_26`,
    tooltip: `_tooltip_8ak83_31`,
  },
  ie = (e) => {
    let t = (0, H.c)(15),
      { enabled: n, onExit: r } = e,
      { disableFullscreen: i, isFullscreen: a } = V.useContext(c),
      o;
    t[0] !== i || t[1] !== a || t[2] !== r
      ? ((o = function () {
          a && i(), u.feedback(`dislike`), r();
        }),
        (t[0] = i),
        (t[1] = a),
        (t[2] = r),
        (t[3] = o))
      : (o = t[3]);
    let s = o,
      l;
    t[4] === r
      ? (l = t[5])
      : ((l = function () {
          r(), d();
        }),
        (t[4] = r),
        (t[5] = l));
    let f = l;
    if (!n) return null;
    let p;
    t[6] === f
      ? (p = t[7])
      : ((p = (0, U.jsx)(M, {
          name: `close`,
          className: W.closeIcon,
          onClick: f,
        })),
        (t[6] = f),
        (t[7] = p));
    let m;
    t[8] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((m = (0, U.jsx)(y, { id: `dislikeFeedback.title` })), (t[8] = m))
      : (m = t[8]);
    let h;
    t[9] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((h = (0, U.jsx)(y, { id: `dislikeFeedback.action` })), (t[9] = h))
      : (h = t[9]);
    let g;
    t[10] === s
      ? (g = t[11])
      : ((g = (0, U.jsx)(P, {
          variant: `contained`,
          className: W.action,
          onClick: s,
          children: h,
        })),
        (t[10] = s),
        (t[11] = g));
    let _;
    return (
      t[12] !== p || t[13] !== g
        ? ((_ = (0, U.jsxs)(`div`, {
            className: W.root,
            onMouseDown: ae,
            children: [p, m, g],
          })),
          (t[12] = p),
          (t[13] = g),
          (t[14] = _))
        : (_ = t[14]),
      _
    );
  };
function ae(e) {
  e.stopPropagation(), e.preventDefault();
}
var oe = (e) => {
    let n = (0, H.c)(25),
      { initialRating: r } = e,
      [i, a] = V.useState(r),
      { vote: o, setVote: c } = V.useContext(E),
      [l, f] = V.useState(!1),
      p,
      m;
    if (n[0] !== r || n[1] !== c || n[2] !== o) {
      (m = () => {
        o === v.POSITIVE ? e(v.CANCEL) : e(v.POSITIVE), d();
      }),
        (p = async () => {
          o === v.NEGATIVE ? e(v.CANCEL) : e(v.NEGATIVE), d();
        });
      let e = (e) => {
        c(e);
        bb10: switch (e) {
          case v.NEGATIVE:
            u.dislike(),
              a({ upVotes: r.upVotes, downVotes: r.downVotes + 1 }),
              f(!0);
            break bb10;
          case v.POSITIVE:
            u.like(),
              a({ upVotes: r.upVotes + 1, downVotes: r.downVotes }),
              f(!1);
            break bb10;
          case v.CANCEL:
            u.neutral(),
              a({ upVotes: r.upVotes, downVotes: r.downVotes }),
              f(!1);
        }
      };
      (n[0] = r), (n[1] = c), (n[2] = o), (n[3] = p), (n[4] = m);
    } else (p = n[3]), (m = n[4]);
    let h;
    n[5] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((h = (0, U.jsx)(y, { id: `tooltip.like` })), (n[5] = h))
      : (h = n[5]);
    let g;
    n[6] === i.upVotes
      ? (g = n[7])
      : ((g = isNaN(i.upVotes)
          ? void 0
          : _.number(i.upVotes, { notation: `compact` })),
        (n[6] = i.upVotes),
        (n[7] = g));
    let b = o === v.POSITIVE,
      S = o === v.POSITIVE ? `success` : void 0,
      C;
    n[8] !== m || n[9] !== g || n[10] !== b || n[11] !== S
      ? ((C = (0, U.jsx)(s, {
          title: h,
          placement: `top`,
          tooltipClassName: W.tooltip,
          children: (0, U.jsx)(t, {
            icon: `like`,
            label: g,
            onClick: m,
            isActive: b,
            status: S,
            segment: `start`,
            testId: `footer-like-button`,
          }),
        })),
        (n[8] = m),
        (n[9] = g),
        (n[10] = b),
        (n[11] = S),
        (n[12] = C))
      : (C = n[12]);
    let w;
    n[13] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((w = (0, U.jsx)(y, { id: `tooltip.dislike` })), (n[13] = w))
      : (w = n[13]);
    let T = o === v.NEGATIVE,
      D = o === v.NEGATIVE ? `error` : void 0,
      O;
    n[14] !== p || n[15] !== T || n[16] !== D
      ? ((O = (0, U.jsx)(s, {
          title: w,
          placement: `top`,
          tooltipClassName: W.tooltip,
          children: (0, U.jsx)(t, {
            icon: `dislike`,
            onClick: p,
            isActive: T,
            status: D,
            segment: `end`,
            testId: `footer-dislike-button`,
          }),
        })),
        (n[14] = p),
        (n[15] = T),
        (n[16] = D),
        (n[17] = O))
      : (O = n[17]);
    let k;
    n[18] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((k = () => {
          f(!1);
        }),
        (n[18] = k))
      : (k = n[18]);
    let A;
    n[19] === l
      ? (A = n[20])
      : ((A = (0, U.jsx)(ie, { enabled: l, onExit: k })),
        (n[19] = l),
        (n[20] = A));
    let j;
    return (
      n[21] !== A || n[22] !== C || n[23] !== O
        ? ((j = (0, U.jsxs)(`div`, {
            className: x.ratingGroup,
            children: [C, O, A],
          })),
          (n[21] = A),
          (n[22] = C),
          (n[23] = O),
          (n[24] = j))
        : (j = n[24]),
      j
    );
  },
  G = R(I()),
  K = {
    popper: `_popper_fcxgd_15`,
    positioned: `_positioned_fcxgd_21`,
    content: `_content_fcxgd_25`,
    arrow: `_arrow_fcxgd_35`,
    timerBar: `_timerBar_fcxgd_49`,
    "timer-grow": `_timer-grow_fcxgd_1`,
  },
  se = 3,
  ce = 8,
  le = (e) => {
    let t = (0, H.c)(29),
      {
        anchorElement: n,
        open: r,
        onAutoClose: i,
        children: a,
        duration: o,
      } = e,
      [s, c] = (0, V.useState)(null),
      l = (0, V.useRef)(null),
      u = o || se,
      d,
      f;
    t[0] !== i || t[1] !== r || t[2] !== u
      ? ((d = () => {
          if (!r) return;
          let e = setTimeout(() => {
            i();
          }, u * 1e3);
          return () => {
            window.clearTimeout(e);
          };
        }),
        (f = [r, i, u]),
        (t[0] = i),
        (t[1] = r),
        (t[2] = u),
        (t[3] = d),
        (t[4] = f))
      : ((d = t[3]), (f = t[4])),
      (0, V.useEffect)(d, f);
    let p;
    t[5] === n
      ? (p = t[6])
      : ((p = () => {
          if (!n || !l.current) return;
          let e = n.getBoundingClientRect(),
            t = l.current.getBoundingClientRect(),
            r = e.left + e.width / 2 - t.width / 2,
            i = Math.max(0, window.innerWidth - t.width);
          c({ top: e.top - t.height - ce, left: Math.min(Math.max(r, 0), i) });
        }),
        (t[5] = n),
        (t[6] = p));
    let m = p,
      h,
      g;
    if (
      (t[7] !== n || t[8] !== r || t[9] !== m
        ? ((h = () => {
            if (!(!r || !n))
              return (
                m(),
                window.addEventListener(`scroll`, m, !0),
                window.addEventListener(`resize`, m),
                () => {
                  window.removeEventListener(`scroll`, m, !0),
                    window.removeEventListener(`resize`, m);
                }
              );
          }),
          (g = [r, n, m]),
          (t[7] = n),
          (t[8] = r),
          (t[9] = m),
          (t[10] = h),
          (t[11] = g))
        : ((h = t[10]), (g = t[11])),
      (0, V.useLayoutEffect)(h, g),
      !r || !n)
    )
      return null;
    let _ = s && K.positioned,
      v;
    t[12] === _
      ? (v = t[13])
      : ((v = T(K.popper, _)), (t[12] = _), (t[13] = v));
    let y = s?.top ?? 0,
      b = s?.left ?? 0,
      x;
    t[14] !== y || t[15] !== b
      ? ((x = { top: y, left: b }), (t[14] = y), (t[15] = b), (t[16] = x))
      : (x = t[16]);
    let S = `${u}s`,
      C;
    t[17] === S
      ? (C = t[18])
      : ((C = { "--timer-duration": S }), (t[17] = S), (t[18] = C));
    let w = C,
      E;
    t[19] === w
      ? (E = t[20])
      : ((E = (0, U.jsx)(`div`, { className: K.timerBar, style: w })),
        (t[19] = w),
        (t[20] = E));
    let D;
    t[21] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((D = (0, U.jsx)(`div`, { className: K.arrow })), (t[21] = D))
      : (D = t[21]);
    let O;
    t[22] !== a || t[23] !== E
      ? ((O = (0, U.jsxs)(`div`, {
          className: K.content,
          children: [E, a, D],
        })),
        (t[22] = a),
        (t[23] = E),
        (t[24] = O))
      : (O = t[24]);
    let k;
    return (
      t[25] !== x || t[26] !== O || t[27] !== v
        ? ((k = (0, G.createPortal)(
            (0, U.jsx)(`div`, { ref: l, className: v, style: x, children: O }),
            document.body
          )),
          (t[25] = x),
          (t[26] = O),
          (t[27] = v),
          (t[28] = k))
        : (k = t[28]),
      k
    );
  },
  ue = () => {
    let e = (0, H.c)(23),
      [n, r] = (0, V.useState)(!1),
      { isFullscreen: i } = (0, V.useContext)(c),
      {
        accountId: a,
        isFavouriteGame: o,
        removeFromFavourite: u,
        addToFavourite: f,
      } = (0, V.useContext)(l),
      [p, h] = (0, V.useState)(null),
      g;
    e[0] !== a || e[1] !== f || e[2] !== o || e[3] !== i || e[4] !== u
      ? ((g = () => {
          if (!a && i) {
            r(!0), d();
            return;
          }
          o
            ? (u(), m.getInstance().userAction(`footer`, `favourite`, `remove`))
            : (f(), m.getInstance().userAction(`footer`, `favourite`, `add`)),
            a && d();
        }),
        (e[0] = a),
        (e[1] = f),
        (e[2] = o),
        (e[3] = i),
        (e[4] = u),
        (e[5] = g))
      : (g = e[5]);
    let _ = g,
      v;
    e[6] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((v = () => {
          r(!1);
        }),
        (e[6] = v))
      : (v = e[6]);
    let b = v,
      x;
    e[7] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((x = (0, U.jsx)(y, { id: `popper.signInToFavourite` })), (e[7] = x))
      : (x = e[7]);
    let S;
    e[8] !== n || e[9] !== p
      ? ((S = (0, U.jsx)(le, {
          anchorElement: p,
          open: n,
          duration: 2,
          onAutoClose: b,
          children: x,
        })),
        (e[8] = n),
        (e[9] = p),
        (e[10] = S))
      : (S = e[10]);
    let C = o ? `tooltip.removeFromFavorite` : `tooltip.addToFavorite`,
      w;
    e[11] === C
      ? (w = e[12])
      : ((w = (0, U.jsx)(y, { id: C })), (e[11] = C), (e[12] = w));
    let T = o ? `saved` : `save`,
      E = !!o,
      D;
    e[13] !== _ || e[14] !== T || e[15] !== E
      ? ((D = (0, U.jsx)(t, {
          icon: T,
          onClick: _,
          ref: h,
          isActive: E,
          testId: `footer-favorite-button`,
        })),
        (e[13] = _),
        (e[14] = T),
        (e[15] = E),
        (e[16] = D))
      : (D = e[16]);
    let O;
    e[17] !== w || e[18] !== D
      ? ((O = (0, U.jsx)(s, { title: w, placement: `top`, children: D })),
        (e[17] = w),
        (e[18] = D),
        (e[19] = O))
      : (O = e[19]);
    let k;
    return (
      e[20] !== S || e[21] !== O
        ? ((k = (0, U.jsxs)(U.Fragment, { children: [S, O] })),
          (e[20] = S),
          (e[21] = O),
          (e[22] = k))
        : (k = e[22]),
      k
    );
  },
  q = {
    popup: `_popup_uu1hz_1`,
    title: `_title_uu1hz_21`,
    text: `_text_uu1hz_27`,
    button: `_button_uu1hz_32`,
  },
  de = 8,
  J = 8;
function fe(e) {
  let t = (0, H.c)(9),
    n = V.useRef(null),
    [r, i] = V.useState(null),
    a;
  t[0] === e
    ? (a = t[1])
    : ((a = () => {
        if (!e || !n.current) return;
        let t = e.getBoundingClientRect(),
          r = n.current.getBoundingClientRect(),
          a = Math.min(
            Math.max(t.right - r.width, J),
            window.innerWidth - r.width - J
          );
        i({ top: Math.max(t.top - r.height - de, J), left: a });
      }),
      (t[0] = e),
      (t[1] = a));
  let o = a,
    s,
    c;
  t[2] === o
    ? ((s = t[3]), (c = t[4]))
    : ((s = () => (
        o(),
        window.addEventListener(`resize`, o),
        () => {
          window.removeEventListener(`resize`, o);
        }
      )),
      (c = [o]),
      (t[2] = o),
      (t[3] = s),
      (t[4] = c)),
    V.useLayoutEffect(s, c);
  let l;
  t[5] === r
    ? (l = t[6])
    : ((l = r
        ? { "--popup-top": `${r.top}px`, "--popup-left": `${r.left}px` }
        : void 0),
      (t[5] = r),
      (t[6] = l));
  let u = l,
    d;
  return (
    t[7] === u
      ? (d = t[8])
      : ((d = { ref: n, style: u }), (t[7] = u), (t[8] = d)),
    d
  );
}
var pe = (e) => {
  let t = (0, H.c)(11),
    { anchorElement: n, onGotIt: r } = e,
    { i18n: i } = w(),
    { ref: a, style: o } = fe(n),
    s;
  t[0] === Symbol.for(`react.memo_cache_sentinel`)
    ? ((s = (0, U.jsx)(`h2`, {
        id: `footer-notifications-blocked-popup-title`,
        className: q.title,
        children: (0, U.jsx)(y, { id: `gameNotificationsBlockedPopup.title` }),
      })),
      (t[0] = s))
    : (s = t[0]);
  let c;
  t[1] === Symbol.for(`react.memo_cache_sentinel`)
    ? ((c = (0, U.jsx)(`p`, {
        className: q.text,
        children: (0, U.jsx)(y, { id: `gameNotificationsBlockedPopup.text` }),
      })),
      (t[1] = c))
    : (c = t[1]);
  let l;
  t[2] === i
    ? (l = t[3])
    : ((l = i._(`gameNotificationsBlockedPopup.gotIt`)),
      (t[2] = i),
      (t[3] = l));
  let u;
  t[4] !== r || t[5] !== l
    ? ((u = (0, U.jsx)(h, {
        label: l,
        tone: `green`,
        size: `m`,
        className: q.button,
        onClick: r,
      })),
      (t[4] = r),
      (t[5] = l),
      (t[6] = u))
    : (u = t[6]);
  let d;
  return (
    t[7] !== a || t[8] !== o || t[9] !== u
      ? ((d = (0, G.createPortal)(
          (0, U.jsxs)(`div`, {
            ref: a,
            role: `dialog`,
            "aria-labelledby": `footer-notifications-blocked-popup-title`,
            "data-testid": `footer-notifications-blocked-popup`,
            className: q.popup,
            style: o,
            onMouseDown: me,
            children: [s, c, u],
          }),
          document.body
        )),
        (t[7] = a),
        (t[8] = o),
        (t[9] = u),
        (t[10] = d))
      : (d = t[10]),
    d
  );
};
function me(e) {
  e.stopPropagation(), e.preventDefault();
}
var Y = {
    card: `_card_14lhv_1`,
    title: `_title_14lhv_20`,
    toggleRow: `_toggleRow_14lhv_26`,
    switch: `_switch_14lhv_34`,
    switchOn: `_switchOn_14lhv_47`,
    switchThumb: `_switchThumb_14lhv_51`,
    actions: `_actions_14lhv_65`,
    button: `_button_14lhv_71`,
    manageButton: `_manageButton_14lhv_75`,
  },
  he = (e) => {
    let t = (0, H.c)(40),
      {
        anchorElement: n,
        enabled: r,
        onToggle: i,
        onManageAllGames: a,
        onClose: o,
      } = e,
      { i18n: s } = w(),
      { ref: c, style: l } = fe(n),
      u;
    t[0] === o
      ? (u = t[1])
      : ((u = (e) => {
          e.target === e.currentTarget && o();
        }),
        (t[0] = o),
        (t[1] = u));
    let d;
    t[2] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((d = (0, U.jsx)(`h2`, {
          id: `footer-notifications-modal-title`,
          className: Y.title,
          children: (0, U.jsx)(y, { id: `gameNotificationsModal.title` }),
        })),
        (t[2] = d))
      : (d = t[2]);
    let f;
    t[3] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((f = (0, U.jsx)(`span`, {
          children: (0, U.jsx)(y, { id: `gameNotificationsModal.toggle` }),
        })),
        (t[3] = f))
      : (f = t[3]);
    let p;
    t[4] === s
      ? (p = t[5])
      : ((p = s._(`gameNotificationsModal.toggle`)), (t[4] = s), (t[5] = p));
    let m = r && Y.switchOn,
      g;
    t[6] === m ? (g = t[7]) : ((g = T(Y.switch, m)), (t[6] = m), (t[7] = g));
    let _;
    t[8] !== r || t[9] !== i
      ? ((_ = () => i(!r)), (t[8] = r), (t[9] = i), (t[10] = _))
      : (_ = t[10]);
    let v;
    t[11] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((v = (0, U.jsx)(`span`, { className: Y.switchThumb })), (t[11] = v))
      : (v = t[11]);
    let b;
    t[12] !== r || t[13] !== p || t[14] !== g || t[15] !== _
      ? ((b = (0, U.jsxs)(`div`, {
          className: Y.toggleRow,
          children: [
            f,
            (0, U.jsx)(`button`, {
              type: `button`,
              role: `switch`,
              "aria-checked": r,
              "aria-label": p,
              className: g,
              onClick: _,
              children: v,
            }),
          ],
        })),
        (t[12] = r),
        (t[13] = p),
        (t[14] = g),
        (t[15] = _),
        (t[16] = b))
      : (b = t[16]);
    let x;
    t[17] === s
      ? (x = t[18])
      : ((x = s._(`gameNotificationsModal.manageAllGames`)),
        (t[17] = s),
        (t[18] = x));
    let S, C;
    t[19] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((S = { position: `right`, code: `arrow_forward` }),
        (C = T(Y.button, Y.manageButton)),
        (t[19] = S),
        (t[20] = C))
      : ((S = t[19]), (C = t[20]));
    let E;
    t[21] !== a || t[22] !== x
      ? ((E = (0, U.jsx)(h, {
          label: x,
          tone: `alphaWhite`,
          size: `m`,
          icon: S,
          className: C,
          onClick: a,
        })),
        (t[21] = a),
        (t[22] = x),
        (t[23] = E))
      : (E = t[23]);
    let D;
    t[24] === s
      ? (D = t[25])
      : ((D = s._(`gameNotificationsModal.close`)), (t[24] = s), (t[25] = D));
    let O;
    t[26] !== o || t[27] !== D
      ? ((O = (0, U.jsx)(h, {
          label: D,
          tone: `green`,
          size: `m`,
          className: Y.button,
          onClick: o,
        })),
        (t[26] = o),
        (t[27] = D),
        (t[28] = O))
      : (O = t[28]);
    let k;
    t[29] !== E || t[30] !== O
      ? ((k = (0, U.jsxs)(`div`, { className: Y.actions, children: [E, O] })),
        (t[29] = E),
        (t[30] = O),
        (t[31] = k))
      : (k = t[31]);
    let A;
    t[32] !== c || t[33] !== l || t[34] !== k || t[35] !== b
      ? ((A = (0, U.jsxs)(`div`, {
          ref: c,
          style: l,
          className: Y.card,
          role: `dialog`,
          "aria-modal": `true`,
          "aria-labelledby": `footer-notifications-modal-title`,
          onMouseDown: ge,
          children: [d, b, k],
        })),
        (t[32] = c),
        (t[33] = l),
        (t[34] = k),
        (t[35] = b),
        (t[36] = A))
      : (A = t[36]);
    let M;
    return (
      t[37] !== u || t[38] !== A
        ? ((M = (0, U.jsx)(j, { hideBackdrop: !0, onClick: u, children: A })),
          (t[37] = u),
          (t[38] = A),
          (t[39] = M))
        : (M = t[39]),
      M
    );
  };
function ge(e) {
  e.stopPropagation(), e.preventDefault();
}
var X = {
    popup: `_popup_lobb1_1`,
    title: `_title_lobb1_21`,
    text: `_text_lobb1_27`,
    actions: `_actions_lobb1_32`,
  },
  _e = (e) => {
    let t = (0, H.c)(33),
      { anchorElement: n, promptType: r, onAnswer: i } = e,
      { i18n: a } = w(),
      { ref: s, style: c } = fe(n),
      l,
      u;
    t[0] === r
      ? ((l = t[1]), (u = t[2]))
      : ((l = () => {
          o(`shown`, r);
        }),
        (u = [r]),
        (t[0] = r),
        (t[1] = l),
        (t[2] = u)),
      V.useEffect(l, u);
    let d;
    t[3] !== i || t[4] !== r
      ? ((d = (e) => {
          o(e ? `accepted` : `declined`, r), i(e);
        }),
        (t[3] = i),
        (t[4] = r),
        (t[5] = d))
      : (d = t[5]);
    let f = d,
      p = `gameNotificationsPrompt.${r}.title`,
      m;
    t[6] === p
      ? (m = t[7])
      : ((m = (0, U.jsx)(`h2`, {
          id: `footer-notifications-prompt-title`,
          className: X.title,
          children: (0, U.jsx)(y, { id: p }),
        })),
        (t[6] = p),
        (t[7] = m));
    let g = `gameNotificationsPrompt.${r}.text`,
      _;
    t[8] === g
      ? (_ = t[9])
      : ((_ = (0, U.jsx)(`p`, {
          className: X.text,
          children: (0, U.jsx)(y, { id: g }),
        })),
        (t[8] = g),
        (t[9] = _));
    let v;
    t[10] === a
      ? (v = t[11])
      : ((v = a._(`gameNotificationsPrompt.remindMe`)),
        (t[10] = a),
        (t[11] = v));
    let b;
    t[12] === f ? (b = t[13]) : ((b = () => f(!0)), (t[12] = f), (t[13] = b));
    let x;
    t[14] !== v || t[15] !== b
      ? ((x = (0, U.jsx)(h, {
          label: v,
          tone: `green`,
          size: `m`,
          onClick: b,
        })),
        (t[14] = v),
        (t[15] = b),
        (t[16] = x))
      : (x = t[16]);
    let S;
    t[17] === a
      ? (S = t[18])
      : ((S = a._(`gameNotificationsPrompt.notNow`)), (t[17] = a), (t[18] = S));
    let C;
    t[19] === f ? (C = t[20]) : ((C = () => f(!1)), (t[19] = f), (t[20] = C));
    let T;
    t[21] !== S || t[22] !== C
      ? ((T = (0, U.jsx)(h, {
          label: S,
          tone: `alphaWhite`,
          size: `m`,
          onClick: C,
        })),
        (t[21] = S),
        (t[22] = C),
        (t[23] = T))
      : (T = t[23]);
    let E;
    t[24] !== x || t[25] !== T
      ? ((E = (0, U.jsxs)(`div`, { className: X.actions, children: [x, T] })),
        (t[24] = x),
        (t[25] = T),
        (t[26] = E))
      : (E = t[26]);
    let D;
    return (
      t[27] !== s || t[28] !== c || t[29] !== E || t[30] !== m || t[31] !== _
        ? ((D = (0, G.createPortal)(
            (0, U.jsxs)(`div`, {
              ref: s,
              role: `dialog`,
              "aria-labelledby": `footer-notifications-prompt-title`,
              "data-testid": `footer-notifications-prompt`,
              className: X.popup,
              style: c,
              onMouseDown: ve,
              children: [m, _, E],
            }),
            document.body
          )),
          (t[27] = s),
          (t[28] = c),
          (t[29] = E),
          (t[30] = m),
          (t[31] = _),
          (t[32] = D))
        : (D = t[32]),
      D
    );
  };
function ve(e) {
  e.stopPropagation(), e.preventDefault();
}
var ye = () => {
    let e = (0, H.c)(35),
      {
        gameNotificationsStatus: i,
        gameNotificationPrompt: o,
        answerGameNotificationPrompt: c,
        setGameNotifications: u,
        openGameNotificationPreferences: f,
      } = (0, V.useContext)(l),
      [p, m] = V.useState(!1),
      [h, g] = V.useState(!1),
      [_, v] = V.useState(null),
      b;
    e[0] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((b = () => {
          m(!1), d();
        }),
        (e[0] = b))
      : (b = e[0]);
    let x = b,
      S;
    e[1] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((S = () => {
          g(!1), d();
        }),
        (e[1] = S))
      : (S = e[1]);
    let C = S,
      w = i === `blocked`,
      T = h && w;
    if (!i) return null;
    let E = o && i === `off` && !p,
      D = i === `on`,
      O;
    e[2] !== i || e[3] !== w || e[4] !== T
      ? ((O = () => {
          if ((r(i, `gameframe`), w)) {
            T ? g(!1) : (g(!0), a(`shown`));
            return;
          }
          m(!0);
        }),
        (e[2] = i),
        (e[3] = w),
        (e[4] = T),
        (e[5] = O))
      : (O = e[5]);
    let k = O,
      A = D ? `tooltip.gameNotificationsOn` : `tooltip.gameNotificationsOff`,
      j;
    e[6] === A
      ? (j = e[7])
      : ((j = (0, U.jsx)(y, { id: A })), (e[6] = A), (e[7] = j));
    let M;
    e[8] === i
      ? (M = e[9])
      : ((M = (0, U.jsx)(n, { status: i })), (e[8] = i), (e[9] = M));
    let N;
    e[10] !== k || e[11] !== M
      ? ((N = (0, U.jsx)(t, {
          ref: v,
          onClick: k,
          testId: `footer-notifications-button`,
          children: M,
        })),
        (e[10] = k),
        (e[11] = M),
        (e[12] = N))
      : (N = e[12]);
    let P;
    e[13] !== j || e[14] !== N
      ? ((P = (0, U.jsx)(s, { title: j, placement: `top`, children: N })),
        (e[13] = j),
        (e[14] = N),
        (e[15] = P))
      : (P = e[15]);
    let F;
    e[16] !== _ || e[17] !== T
      ? ((F =
          T &&
          (0, U.jsx)(pe, {
            anchorElement: _,
            onGotIt: () => {
              a(`gotIt`), C();
            },
          })),
        (e[16] = _),
        (e[17] = T),
        (e[18] = F))
      : (F = e[18]);
    let I;
    e[19] !== c || e[20] !== _ || e[21] !== o || e[22] !== E
      ? ((I =
          E &&
          (0, U.jsx)(_e, {
            anchorElement: _,
            promptType: o,
            onAnswer: (e) => {
              c(e), d();
            },
          })),
        (e[19] = c),
        (e[20] = _),
        (e[21] = o),
        (e[22] = E),
        (e[23] = I))
      : (I = e[23]);
    let L;
    e[24] !== _ || e[25] !== D || e[26] !== p || e[27] !== f || e[28] !== u
      ? ((L =
          p &&
          (0, G.createPortal)(
            (0, U.jsx)(he, {
              anchorElement: _,
              enabled: D,
              onToggle: (e) => {
                u(e);
              },
              onManageAllGames: () => {
                m(!1), f();
              },
              onClose: x,
            }),
            document.body
          )),
        (e[24] = _),
        (e[25] = D),
        (e[26] = p),
        (e[27] = f),
        (e[28] = u),
        (e[29] = L))
      : (L = e[29]);
    let R;
    return (
      e[30] !== L || e[31] !== P || e[32] !== F || e[33] !== I
        ? ((R = (0, U.jsxs)(U.Fragment, { children: [P, F, I, L] })),
          (e[30] = L),
          (e[31] = P),
          (e[32] = F),
          (e[33] = I),
          (e[34] = R))
        : (R = e[34]),
      R
    );
  },
  Z = {
    root: `_root_17g1v_7`,
    rootWithMouse: `_rootWithMouse_17g1v_12`,
    textOnlyContainer: `_textOnlyContainer_17g1v_17`,
    keyboardContainer: `_keyboardContainer_17g1v_42`,
    keyboardKey: `_keyboardKey_17g1v_63`,
    activeKey: `_activeKey_17g1v_76`,
    comboKeyContainer: `_comboKeyContainer_17g1v_80`,
    arrowKey: `_arrowKey_17g1v_101`,
    keyboardLabel: `_keyboardLabel_17g1v_113`,
    keyboardRow: `_keyboardRow_17g1v_118`,
    oddRow: `_oddRow_17g1v_133`,
    keyboardCell: `_keyboardCell_17g1v_137`,
    activeLabel: `_activeLabel_17g1v_151`,
    controlsHeader: `_controlsHeader_17g1v_155`,
    headerRow: `_headerRow_17g1v_162`,
    mouseBody: `_mouseBody_17g1v_163`,
    mouseControlRow: `_mouseControlRow_17g1v_164`,
    headerMouse: `_headerMouse_17g1v_170`,
    headerKeyboard: `_headerKeyboard_17g1v_174`,
    headerDividerCell: `_headerDividerCell_17g1v_178`,
    headerDivider: `_headerDivider_17g1v_178`,
    mouseRoot: `_mouseRoot_17g1v_186`,
    mouseGraphic: `_mouseGraphic_17g1v_199`,
    mouseLabels: `_mouseLabels_17g1v_200`,
    active: `_active_17g1v_76`,
    kids: `_kids_17g1v_218`,
    mouseControlCell: `_mouseControlCell_17g1v_222`,
    mouseButton: `_mouseButton_17g1v_226`,
    mouseBorder: `_mouseBorder_17g1v_230`,
    activeMouseButton: `_activeMouseButton_17g1v_234`,
    mouseMiddleDivider: `_mouseMiddleDivider_17g1v_239`,
    mouseLabel: `_mouseLabel_17g1v_200`,
  },
  be = (e) => {
    let t = (0, H.c)(6),
      { type: n, pressedKey: r } = e,
      i;
    t[0] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((i = [
          { key: `&#9650;`, pressedKey: `arrowup` },
          { key: `&#9664;`, pressedKey: `arrowleft` },
          { key: `&#9660;`, pressedKey: `arrowdown` },
          { key: `&#9654;`, pressedKey: `arrowright` },
        ]),
        (t[0] = i))
      : (i = t[0]);
    let a = i,
      o;
    t[1] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((o = [
          { key: `W`, pressedKey: `w` },
          { key: `A`, pressedKey: `a` },
          { key: `S`, pressedKey: `s` },
          { key: `D`, pressedKey: `d` },
        ]),
        (t[1] = o))
      : (o = t[1]);
    let s = o;
    if (n !== `arrows` && n !== `wasd`) return null;
    let c = n === `arrows` ? a : s,
      l;
    return (
      t[2] !== c || t[3] !== r || t[4] !== n
        ? ((l = (0, U.jsx)(`div`, {
            children: (0, U.jsx)(`div`, {
              className: Z.comboKeyContainer,
              children: c.map((e, t) =>
                (0, U.jsx)(
                  `div`,
                  {
                    className: T(
                      Z.keyboardKey,
                      n === `arrows` && Z.arrowKey,
                      r === e.pressedKey && Z.activeKey
                    ),
                    dangerouslySetInnerHTML: { __html: e.key },
                  },
                  t
                )
              ),
            }),
          })),
          (t[2] = c),
          (t[3] = r),
          (t[4] = n),
          (t[5] = l))
        : (l = t[5]),
      l
    );
  },
  xe = class extends V.Component {
    constructor(e) {
      super(e),
        z(this, `handleKeyboardEvent`, (e) => {
          this.setState({
            pressedKey: e && e.type === `keydown` ? e.key.toLowerCase() : null,
          });
        }),
        z(
          this,
          `checkPressedKey`,
          (e) =>
            this.state.pressedKey !== null &&
            (this.state.pressedKey === e ||
              (this.state.pressedKey.includes(`arrow`) && e.includes(`arrow`)))
        ),
        z(this, `checkedPressedKeys`, (e) =>
          e.some((e) => this.checkPressedKey(e.toLowerCase()))
        ),
        z(this, `convertLabelToSymbol`, (e) => {
          if (e.toLowerCase().includes(`arrow`))
            switch (e.toLowerCase()) {
              case `arrowup`:
                return `&#9650;`;
              case `arrowdown`:
                return `&#9660;`;
              case `arrowleft`:
                return `&#9664;`;
              case `arrowright`:
                return `&#9654;`;
              default:
                return e;
            }
          return e;
        }),
        (this.state = { pressedKey: null });
    }
    componentDidMount() {
      this.props.detectPressedKeys &&
        (document.addEventListener(`keydown`, this.handleKeyboardEvent, !1),
        document.addEventListener(`keyup`, this.handleKeyboardEvent, !1));
    }
    componentWillUnmount() {
      this.props.detectPressedKeys &&
        (document.removeEventListener(`keydown`, this.handleKeyboardEvent, !1),
        document.removeEventListener(`keyup`, this.handleKeyboardEvent, !1));
    }
    render() {
      let { controls: e, hasMouse: t, locale: n } = this.props;
      return (0, U.jsxs)(`div`, {
        className: T(Z.root, t && Z.rootWithMouse),
        children: [
          (0, U.jsxs)(`div`, {
            className: Z.headerRow,
            children: [
              (0, U.jsx)(`div`, {
                className: Z.headerKeyboard,
                children: (0, U.jsx)(`div`, {
                  className: Z.controlsHeader,
                  children: (0, U.jsx)(y, { id: `gameControls.keyboard` }),
                }),
              }),
              (0, U.jsx)(`div`, {
                className: Z.headerDividerCell,
                children: (0, U.jsx)(`hr`, { className: Z.headerDivider }),
              }),
            ],
          }),
          (0, U.jsx)(`div`, {
            className: Z.keyboardContainer,
            children: e.map((e, t) => {
              let r = n || `en_US`,
                i = e.label[r] || e.label.en_US || ``;
              return (0, U.jsxs)(
                `div`,
                {
                  className: T(Z.keyboardRow, t % 2 && Z.oddRow),
                  children: [
                    (0, U.jsx)(`div`, {
                      className: Z.keyboardCell,
                      children: e.keys.map((e, t) =>
                        e.toLowerCase() === `wasd` ||
                        e.toLowerCase() === `arrows`
                          ? (0, U.jsx)(
                              be,
                              {
                                type: e.toLowerCase(),
                                pressedKey: this.state.pressedKey,
                              },
                              t
                            )
                          : (0, U.jsx)(
                              `div`,
                              {
                                className: T(
                                  Z.keyboardKey,
                                  this.state.pressedKey &&
                                    this.checkPressedKey(e.toLowerCase()) &&
                                    Z.activeKey
                                ),
                                dangerouslySetInnerHTML: {
                                  __html: this.convertLabelToSymbol(e),
                                },
                              },
                              t
                            )
                      ),
                    }),
                    (0, U.jsx)(`div`, {
                      className: T(
                        Z.keyboardCell,
                        Z.keyboardLabel,
                        e.keys.some((e) =>
                          this.checkPressedKey(e.toLowerCase())
                        ) && Z.activeLabel
                      ),
                      children: i,
                    }),
                  ],
                },
                t
              );
            }),
          }),
        ],
      });
    }
  },
  Se = (e) => {
    let t = (0, H.c)(50),
      n = e.height,
      r;
    t[0] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((r = (0, U.jsx)(`path`, {
          id: `MouseSvgBorder`,
          className: Z.mouseBorder,
          d: `M76 53.438v23.46c0 19.356-16.2 35.192-36 35.192S4 96.254 4 76.899V39.1C4 20.44 19.062 5.054 37.889 3.977c.699-.04 1.402-.067 2.11-.067.635 0 1.264.017 1.89.049 18.93.969 34.11 16.406 34.11 35.142v14.337zM40 0c-.708 0-1.412.02-2.111.055C16.81 1.132-.001 18.234-.001 39.101v37.797c0 9.616 3.57 18.43 9.48 25.248 7.343 8.47 18.3 13.854 30.52 13.854 22.057 0 40-17.54 40-39.101V39.1C80 18.16 63.072 1.015 41.89.047A41.248 41.248 0 0 0 39.999 0z`,
        })),
        (t[0] = r))
      : (r = t[0]);
    let i = e.hasRight ? 1 : 0.5,
      a = e.hasRight && Z.activeMouseButton,
      o;
    t[1] === a
      ? (o = t[2])
      : ((o = T(Z.mouseButton, a)), (t[1] = a), (t[2] = o));
    let s;
    t[3] === e
      ? (s = t[4])
      : ((s = e.hasRight ? () => e.mouseEnter(`right`) : void 0),
        (t[3] = e),
        (t[4] = s));
    let c;
    t[5] === e
      ? (c = t[6])
      : ((c = e.hasRight ? () => e.mouseLeave() : void 0),
        (t[5] = e),
        (t[6] = c));
    let l;
    t[7] !== i || t[8] !== o || t[9] !== s || t[10] !== c
      ? ((l = (0, U.jsx)(`path`, {
          id: `MouseSvgRightButton`,
          opacity: i,
          className: o,
          d: `M41 8v23.156c4.56.87 8.008 4.733 8.008 9.355V54H72V39.524C72 22.735 58.263 8.969 41 8`,
          onMouseEnter: s,
          onMouseLeave: c,
        })),
        (t[7] = i),
        (t[8] = o),
        (t[9] = s),
        (t[10] = c),
        (t[11] = l))
      : (l = t[11]);
    let u = e.hasLeft ? 1 : 0.5,
      d = e.hasLeft && Z.activeMouseButton,
      f;
    t[12] === d
      ? (f = t[13])
      : ((f = T(Z.mouseButton, d)), (t[12] = d), (t[13] = f));
    let p;
    t[14] === e
      ? (p = t[15])
      : ((p = e.hasLeft ? () => e.mouseEnter(`left`) : void 0),
        (t[14] = e),
        (t[15] = p));
    let m;
    t[16] === e
      ? (m = t[17])
      : ((m = e.hasLeft ? () => e.mouseLeave() : void 0),
        (t[16] = e),
        (t[17] = m));
    let h;
    t[18] !== f || t[19] !== p || t[20] !== m || t[21] !== u
      ? ((h = (0, U.jsx)(`path`, {
          id: `MouseSvgLeftButton`,
          opacity: u,
          className: f,
          d: `M37 8C20.832 9.078 8 22.798 8 39.519V54h21.67V40.506c0-4.546 3.141-8.354 7.33-9.308V8z`,
          onMouseEnter: p,
          onMouseLeave: m,
        })),
        (t[18] = f),
        (t[19] = p),
        (t[20] = m),
        (t[21] = u),
        (t[22] = h))
      : (h = t[22]);
    let g = e.hasMiddle ? 1 : 0.5,
      _ = e.hasMiddle && Z.activeMouseButton,
      v;
    t[23] === _
      ? (v = t[24])
      : ((v = T(Z.mouseButton, _)), (t[23] = _), (t[24] = v));
    let y;
    t[25] === e
      ? (y = t[26])
      : ((y = e.hasMiddle ? () => e.mouseEnter(`middle`) : void 0),
        (t[25] = e),
        (t[26] = y));
    let b;
    t[27] === e
      ? (b = t[28])
      : ((b = e.hasMiddle ? () => e.mouseLeave() : void 0),
        (t[27] = e),
        (t[28] = b));
    let x, S;
    t[29] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((x = (0, U.jsx)(`path`, {
          d: `M39.5 35c-3.033 0-5.5 2.04-5.5 4.547V53.453C34 55.96 36.467 58 39.5 58s5.5-2.04 5.5-4.547V39.547C45 37.04 42.533 35 39.5 35`,
        })),
        (S = (0, U.jsx)(`path`, {
          className: Z.mouseMiddleDivider,
          strokeLinecap: `square`,
          d: `M40 68V51.5`,
        })),
        (t[29] = x),
        (t[30] = S))
      : ((x = t[29]), (S = t[30]));
    let C;
    t[31] !== g || t[32] !== v || t[33] !== y || t[34] !== b
      ? ((C = (0, U.jsxs)(`g`, {
          fillRule: `evenodd`,
          id: `MouseSvgMiddleButton`,
          opacity: g,
          className: v,
          onMouseEnter: y,
          onMouseLeave: b,
          children: [x, S],
        })),
        (t[31] = g),
        (t[32] = v),
        (t[33] = y),
        (t[34] = b),
        (t[35] = C))
      : (C = t[35]);
    let w;
    t[36] === e.hasLeft
      ? (w = t[37])
      : ((w =
          e.hasLeft &&
          (0, U.jsx)(`text`, {
            className: Z.mouseLabel,
            children: (0, U.jsx)(`tspan`, {
              x: `21.322`,
              y: `32`,
              children: `1`,
            }),
          })),
        (t[36] = e.hasLeft),
        (t[37] = w));
    let E;
    t[38] === e.hasRight
      ? (E = t[39])
      : ((E =
          e.hasRight &&
          (0, U.jsx)(`text`, {
            className: Z.mouseLabel,
            children: (0, U.jsx)(`tspan`, {
              x: `51.6`,
              y: `32`,
              children: `2`,
            }),
          })),
        (t[38] = e.hasRight),
        (t[39] = E));
    let D;
    t[40] === e.hasMiddle
      ? (D = t[41])
      : ((D =
          e.hasMiddle &&
          (0, U.jsx)(`text`, {
            className: Z.mouseLabel,
            children: (0, U.jsx)(`tspan`, {
              x: `36.873`,
              y: `83`,
              children: `3`,
            }),
          })),
        (t[40] = e.hasMiddle),
        (t[41] = D));
    let O;
    return (
      t[42] !== e.height ||
      t[43] !== h ||
      t[44] !== C ||
      t[45] !== w ||
      t[46] !== E ||
      t[47] !== D ||
      t[48] !== l
        ? ((O = (0, U.jsxs)(`svg`, {
            xmlns: `http://www.w3.org/2000/svg`,
            width: `80`,
            height: n,
            viewBox: `0 0 80 116`,
            children: [r, l, h, C, w, E, D],
          })),
          (t[42] = e.height),
          (t[43] = h),
          (t[44] = C),
          (t[45] = w),
          (t[46] = E),
          (t[47] = D),
          (t[48] = l),
          (t[49] = O))
        : (O = t[49]),
      O
    );
  },
  Ce = class extends V.Component {
    constructor(e) {
      super(e),
        z(this, `mouseEnterMouseControls`, (e) => {
          this.setState({ hoveredButton: e });
        }),
        z(this, `mouseLeaveMouseControls`, () => {
          this.setState({ hoveredButton: null });
        }),
        z(this, `mouseEnterLabelControls`, (e) => {
          this.setState({ hoveredLabel: e });
        }),
        z(this, `mouseLeaveLabelControls`, () => {
          this.setState({ hoveredLabel: null });
        }),
        (this.state = { hoveredButton: null, hoveredLabel: null });
    }
    render() {
      let { controls: e, locale: t } = this.props;
      return (0, U.jsxs)(`div`, {
        className: T(Z.mouseRoot, { [Z.kids]: g() }),
        children: [
          (0, U.jsxs)(`div`, {
            className: Z.headerRow,
            children: [
              (0, U.jsx)(`div`, {
                className: Z.headerMouse,
                children: (0, U.jsx)(`div`, {
                  className: Z.controlsHeader,
                  children: (0, U.jsx)(y, { id: `gameControls.mouse` }),
                }),
              }),
              (0, U.jsx)(`div`, {
                className: Z.headerDividerCell,
                children: (0, U.jsx)(`hr`, { className: Z.headerDivider }),
              }),
            ],
          }),
          (0, U.jsxs)(`div`, {
            className: Z.mouseBody,
            children: [
              (0, U.jsx)(`div`, {
                className: Z.mouseGraphic,
                children: (0, U.jsx)(Se, {
                  height: `100%`,
                  active: this.state.hoveredLabel,
                  hasLeft: !!e.left,
                  hasRight: !!e.right,
                  hasMiddle: !!e.middle,
                  mouseEnter: this.mouseEnterMouseControls,
                  mouseLeave: this.mouseLeaveMouseControls,
                }),
              }),
              (0, U.jsx)(`div`, {
                className: Z.mouseLabels,
                children: Object.keys(e).map((n) => {
                  let r = t || `en_US`,
                    i = e[n],
                    a = (f(i) && (i[r] || i.en_US)) || ``,
                    o = this.state.hoveredButton === n;
                  return (0, U.jsxs)(
                    `div`,
                    {
                      className: T(Z.mouseControlRow, o && Z.active),
                      onMouseEnter: () => this.mouseEnterLabelControls(n),
                      onMouseLeave: this.mouseLeaveLabelControls,
                      children: [
                        (0, U.jsx)(`div`, {
                          className: Z.mouseControlCell,
                          children: this.convertLabelToNumber(n),
                        }),
                        (0, U.jsx)(`div`, {
                          className: Z.mouseControlCell,
                          children: a,
                        }),
                      ],
                    },
                    n
                  );
                }),
              }),
            ],
          }),
        ],
      });
    }
    convertLabelToNumber(e) {
      switch (e) {
        case `right`:
          return 2;
        case `middle`:
          return 3;
        default:
          return 1;
      }
    }
  };
function we(e, t, n) {
  let r = (0, H.c)(5),
    i = (0, V.useRef)(null),
    a,
    o;
  return (
    r[0] !== e || r[1] !== n || r[2] !== t
      ? ((a = () => {
          if (!e) return;
          let r = (e) => {
            let r = e.target;
            r instanceof Node &&
              (i.current?.contains(r) ||
                (n &&
                  e
                    .composedPath()
                    .some((e) => e instanceof Element && e.matches(n))) ||
                t(e));
          };
          return (
            document.addEventListener(`mousedown`, r),
            document.addEventListener(`touchstart`, r),
            () => {
              document.removeEventListener(`mousedown`, r),
                document.removeEventListener(`touchstart`, r);
            }
          );
        }),
        (o = [e, t, n]),
        (r[0] = e),
        (r[1] = n),
        (r[2] = t),
        (r[3] = a),
        (r[4] = o))
      : ((a = r[3]), (o = r[4])),
    (0, V.useEffect)(a, o),
    i
  );
}
var Q = {
    root: `_root_19uqz_23`,
    "slide-up": `_slide-up_19uqz_1`,
    entered: `_entered_19uqz_38`,
    exiting: `_exiting_19uqz_42`,
    "slide-down": `_slide-down_19uqz_1`,
    surface: `_surface_19uqz_46`,
    closeButton: `_closeButton_19uqz_55`,
    closeAtTop: `_closeAtTop_19uqz_71`,
    closeIcon: `_closeIcon_19uqz_75`,
    backdrop: `_backdrop_19uqz_79`,
  },
  Te = (e) => {
    let t = (0, H.c)(9),
      { controls: n } = e,
      r;
    t[0] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((r = b.getLocale()), (t[0] = r))
      : (r = t[0]);
    let i = r,
      a;
    t[1] === n.mouse
      ? (a = t[2])
      : ((a = n.mouse && (0, U.jsx)(Ce, { controls: n.mouse, locale: i })),
        (t[1] = n.mouse),
        (t[2] = a));
    let o;
    t[3] !== n.keyboard || t[4] !== n.mouse
      ? ((o =
          n.keyboard &&
          (0, U.jsx)(xe, {
            controls: n.keyboard,
            detectPressedKeys: !1,
            hasMouse: !!n.mouse,
            locale: i,
          })),
        (t[3] = n.keyboard),
        (t[4] = n.mouse),
        (t[5] = o))
      : (o = t[5]);
    let s;
    return (
      t[6] !== a || t[7] !== o
        ? ((s = (0, U.jsxs)(U.Fragment, { children: [a, o] })),
          (t[6] = a),
          (t[7] = o),
          (t[8] = s))
        : (s = t[8]),
      s
    );
  },
  Ee = (e) => {
    let t = (0, H.c)(32),
      {
        controls: n,
        close: r,
        showControlsEntered: i,
        exiting: a,
        onEntered: o,
      } = e,
      s;
    t[0] !== n.keyboard || t[1] !== n.mouse
      ? ((s = () => n.mouse !== void 0 || n.keyboard !== void 0),
        (t[0] = n.keyboard),
        (t[1] = n.mouse),
        (t[2] = s))
      : (s = t[2]);
    let c = s,
      l;
    t[3] !== n.text || t[4] !== c
      ? ((l = () => !c() && !!n.text), (t[3] = n.text), (t[4] = c), (t[5] = l))
      : (l = t[5]);
    let u = l,
      d;
    t[6] === r
      ? (d = t[7])
      : ((d = () => {
          r?.();
        }),
        (t[6] = r),
        (t[7] = d));
    let f = we(!0, d, `#game-controls-toggle-button`),
      p = i && Q.entered,
      m = a && Q.exiting,
      h;
    t[8] !== p || t[9] !== m
      ? ((h = T(Q.root, p, m)), (t[8] = p), (t[9] = m), (t[10] = h))
      : (h = t[10]);
    let g;
    t[11] !== a || t[12] !== o
      ? ((g = (e) => {
          e.target === e.currentTarget && !a && o?.();
        }),
        (t[11] = a),
        (t[12] = o),
        (t[13] = g))
      : (g = t[13]);
    let _;
    t[14] !== r || t[15] !== u
      ? ((_ =
          r &&
          (0, U.jsx)(`button`, {
            type: `button`,
            onClick: r,
            className: T(Q.closeButton, u() && Q.closeAtTop),
            children: (0, U.jsx)(M, {
              name: `close`,
              size: 24,
              className: Q.closeIcon,
            }),
          })),
        (t[14] = r),
        (t[15] = u),
        (t[16] = _))
      : (_ = t[16]);
    let v;
    t[17] !== n || t[18] !== c
      ? ((v = c() && (0, U.jsx)(Te, { controls: n })),
        (t[17] = n),
        (t[18] = c),
        (t[19] = v))
      : (v = t[19]);
    let y;
    t[20] !== n.text || t[21] !== u
      ? ((y =
          u() &&
          (0, U.jsx)(`div`, {
            className: Z.textOnlyContainer,
            children: (0, U.jsx)(`div`, {
              dangerouslySetInnerHTML: { __html: n.text },
              onMouseDown: Oe,
            }),
          })),
        (t[20] = n.text),
        (t[21] = u),
        (t[22] = y))
      : (y = t[22]);
    let b;
    t[23] !== y || t[24] !== v
      ? ((b = (0, U.jsxs)(`div`, {
          className: Q.surface,
          onMouseDown: De,
          children: [v, y],
        })),
        (t[23] = y),
        (t[24] = v),
        (t[25] = b))
      : (b = t[25]);
    let x;
    return (
      t[26] !== f || t[27] !== b || t[28] !== h || t[29] !== g || t[30] !== _
        ? ((x = (0, U.jsxs)(`div`, {
            ref: f,
            id: `game-controls`,
            className: h,
            onAnimationEnd: g,
            children: [_, b],
          })),
          (t[26] = f),
          (t[27] = b),
          (t[28] = h),
          (t[29] = g),
          (t[30] = _),
          (t[31] = x))
        : (x = t[31]),
      x
    );
  };
function De(e) {
  e.stopPropagation(), e.preventDefault();
}
function Oe(e) {
  e.stopPropagation(), e.preventDefault();
}
var ke = V.memo(() => {
    let e = (0, H.c)(19),
      [n, r] = V.useState(!1),
      [i, a] = V.useState(!1),
      { mounted: o, exiting: c } = L(n),
      l;
    e[0] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((l = N()), (e[0] = l))
      : (l = e[0]);
    let u = l,
      f,
      p;
    e[1] === n
      ? ((f = e[2]), (p = e[3]))
      : ((f = () => {
          n || a(!1);
        }),
        (p = [n]),
        (e[1] = n),
        (e[2] = f),
        (e[3] = p)),
      V.useEffect(f, p);
    let h;
    e[4] !== c || e[5] !== o || e[6] !== i
      ? ((h = () => {
          if (!o) return null;
          let { controls: e } = u;
          return (0, U.jsxs)(U.Fragment, {
            children: [
              (0, U.jsx)(Ee, {
                close: () => {
                  r(!1), a(!1), d();
                },
                controls: e,
                showControlsEntered: i,
                exiting: c,
                onEntered: () => a(!0),
              }),
              i && (0, U.jsx)(`div`, { className: Q.backdrop }),
            ],
          });
        }),
        (e[4] = c),
        (e[5] = o),
        (e[6] = i),
        (e[7] = h))
      : (h = e[7]);
    let g = h,
      _;
    e[8] === n
      ? (_ = e[9])
      : ((_ = () => {
          let e = !n;
          r(e),
            m
              .getInstance()
              .userAction(`footer`, `controls`, e ? `open` : `close`);
        }),
        (e[8] = n),
        (e[9] = _));
    let v = _,
      b;
    e[10] === g ? (b = e[11]) : ((b = g()), (e[10] = g), (e[11] = b));
    let x;
    e[12] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((x = (0, U.jsx)(y, { id: `tooltip.gameControls` })), (e[12] = x))
      : (x = e[12]);
    let S;
    e[13] !== n || e[14] !== v
      ? ((S = (0, U.jsx)(s, {
          title: x,
          placement: `top`,
          children: (0, U.jsx)(t, {
            icon: `controls`,
            onClick: v,
            isActive: n,
            id: `game-controls-toggle-button`,
          }),
        })),
        (e[13] = n),
        (e[14] = v),
        (e[15] = S))
      : (S = e[15]);
    let C;
    return (
      e[16] !== b || e[17] !== S
        ? ((C = (0, U.jsxs)(U.Fragment, { children: [b, S] })),
          (e[16] = b),
          (e[17] = S),
          (e[18] = C))
        : (C = e[18]),
      C
    );
  }),
  Ae = V.memo(() => {
    let e = (0, H.c)(6),
      { isFullscreen: n, disableFullscreen: r } = V.useContext(c),
      i;
    e[0] !== r || e[1] !== n
      ? ((i = () => {
          n && r(), u.feedback(`feedbackButton`);
        }),
        (e[0] = r),
        (e[1] = n),
        (e[2] = i))
      : (i = e[2]);
    let a = i,
      o;
    e[3] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((o = (0, U.jsx)(y, { id: `tooltip.feedback` })), (e[3] = o))
      : (o = e[3]);
    let l;
    return (
      e[4] === a
        ? (l = e[5])
        : ((l = (0, U.jsx)(U.Fragment, {
            children: (0, U.jsx)(s, {
              title: o,
              placement: `top`,
              children: (0, U.jsx)(t, {
                icon: `feedback`,
                onClick: a,
                testId: `footer-feedback-button`,
              }),
            }),
          })),
          (e[4] = a),
          (e[5] = l)),
      l
    );
  }),
  je = V.memo(() => {
    let e = (0, H.c)(5),
      {
        isFullscreen: n,
        disableFullscreen: r,
        requestFullscreen: i,
      } = V.useContext(c),
      a,
      o;
    if (e[0] !== r || e[1] !== n || e[2] !== i) {
      o = Symbol.for(`react.early_return_sentinel`);
      bb0: {
        let e = N(),
          c = () => {
            let { fullscreen: t } = e;
            return t && t !== `NOT_SUPPORTED`;
          };
        if (!c()) {
          o = null;
          break bb0;
        }
        a = c()
          ? (0, U.jsx)(s, {
              title: (0, U.jsx)(y, {
                id: n ? `tooltip.exitFullScreen` : `tooltip.fullScreen`,
              }),
              placement: `top`,
              children: (0, U.jsx)(t, {
                icon: n ? `reduce` : `expand`,
                onClick: () => {
                  m
                    .getInstance()
                    .userAction(`footer`, `fullscreen`, n ? `exit` : `enter`),
                    n ? r() : i();
                },
                testId: `footer-fullscreen-button`,
              }),
            })
          : null;
      }
      (e[0] = r), (e[1] = n), (e[2] = i), (e[3] = a), (e[4] = o);
    } else (a = e[3]), (o = e[4]);
    return o === Symbol.for(`react.early_return_sentinel`) ? a : o;
  }),
  Me = V.lazy(() => S(() => import(`./4-8aHQbz2.js`), [], import.meta.url)),
  Ne = (e) => {
    let t = (0, H.c)(27),
      { close: n, slideEntered: r, exiting: i, onEntered: a } = e,
      o;
    t[0] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((o = N()), (t[0] = o))
      : (o = t[0]);
    let s = o,
      c;
    t[1] === n
      ? (c = t[2])
      : ((c = () => {
          n?.();
        }),
        (t[1] = n),
        (t[2] = c));
    let l = we(!0, c, `#qr-modal-toggle-button`),
      u;
    bb0: {
      if (!r && !i) {
        u = null;
        break bb0;
      }
      let e;
      if (t[3] === Symbol.for(`react.memo_cache_sentinel`)) {
        let n = new URL(s.gameLink),
          r = n.searchParams.get(`gameBuildId`);
        (n.search = ``),
          r && n.searchParams.set(`gameBuildId`, r),
          n.searchParams.set(`utm_source`, `mobile-qr-code`),
          n.searchParams.set(`force_app_banner`, `true`),
          (e = n.toString()),
          (t[3] = e);
      } else e = t[3];
      u = e;
    }
    let d = u,
      f = r && Q.entered,
      p = i && Q.exiting,
      m;
    t[4] !== f || t[5] !== p
      ? ((m = T(Q.root, f, p)), (t[4] = f), (t[5] = p), (t[6] = m))
      : (m = t[6]);
    let h;
    t[7] !== i || t[8] !== a
      ? ((h = (e) => {
          e.target === e.currentTarget && !i && a?.();
        }),
        (t[7] = i),
        (t[8] = a),
        (t[9] = h))
      : (h = t[9]);
    let g;
    t[10] === n
      ? (g = t[11])
      : ((g =
          n &&
          (0, U.jsx)(`button`, {
            type: `button`,
            onClick: n,
            className: T(Q.closeButton, Q.closeAtTop),
            children: (0, U.jsx)(M, {
              name: `close`,
              size: 24,
              className: Q.closeIcon,
            }),
          })),
        (t[10] = n),
        (t[11] = g));
    let _;
    t[12] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((_ = (0, U.jsx)(A, { tone: `neutral`, className: B.progress })),
        (t[12] = _))
      : (_ = t[12]);
    let v;
    t[13] === d
      ? (v = t[14])
      : ((v = d && (0, U.jsx)(Me, { link: d })), (t[13] = d), (t[14] = v));
    let y;
    t[15] === v
      ? (y = t[16])
      : ((y = (0, U.jsx)(`div`, {
          className: B.code,
          children: (0, U.jsx)(V.Suspense, { fallback: _, children: v }),
        })),
        (t[15] = v),
        (t[16] = y));
    let b;
    t[17] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((b = (0, U.jsx)(`div`, {
          className: B.title,
          children: (0, U.jsx)(k, { id: `qrMobileModal.title` }),
        })),
        (t[17] = b))
      : (b = t[17]);
    let x;
    t[18] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((x = (0, U.jsx)(`div`, {
          className: B.subtitle,
          children: (0, U.jsx)(k, {
            id: `qrMobileModal.subtitle`,
            values: {
              gameTitle: (0, U.jsx)(`span`, {
                className: B.gameTitle,
                children: s.gameName,
              }),
            },
          }),
        })),
        (t[18] = x))
      : (x = t[18]);
    let S;
    t[19] === y
      ? (S = t[20])
      : ((S = (0, U.jsx)(`div`, {
          className: Q.surface,
          children: (0, U.jsxs)(`div`, {
            className: B.container,
            onMouseDown: Pe,
            children: [y, b, x],
          }),
        })),
        (t[19] = y),
        (t[20] = S));
    let C;
    return (
      t[21] !== l || t[22] !== S || t[23] !== m || t[24] !== h || t[25] !== g
        ? ((C = (0, U.jsxs)(`div`, {
            ref: l,
            className: m,
            id: `qr-modal`,
            onAnimationEnd: h,
            children: [g, S],
          })),
          (t[21] = l),
          (t[22] = S),
          (t[23] = m),
          (t[24] = h),
          (t[25] = g),
          (t[26] = C))
        : (C = t[26]),
      C
    );
  };
function Pe(e) {
  e.stopPropagation(), e.preventDefault();
}
var $ = (e, t) => {
    m.getInstance().sendEvent({
      type: `modal`,
      campaign: `PlayOnApp`,
      action: e,
      target: `playOnApp_gameframe`,
      clickOrigin: t,
    });
  },
  Fe = V.memo(() => {
    let e = (0, H.c)(22),
      [n, r] = V.useState(!1),
      [i, a] = V.useState(!1),
      { mounted: o, exiting: c } = L(n),
      l,
      u;
    e[0] === n
      ? ((l = e[1]), (u = e[2]))
      : ((l = () => {
          n || a(!1);
        }),
        (u = [n]),
        (e[0] = n),
        (e[1] = l),
        (e[2] = u)),
      V.useEffect(l, u);
    let f, p;
    e[3] === n
      ? ((f = e[4]), (p = e[5]))
      : ((f = () => {
          let e = (e) => {
            e.data?.type === `showQrCodePopup` &&
              !n &&
              (r(!0), $(`clicked`, `gameframe`));
          };
          return (
            window.addEventListener(`message`, e),
            () => {
              window.removeEventListener(`message`, e);
            }
          );
        }),
        (p = [n]),
        (e[3] = n),
        (e[4] = f),
        (e[5] = p)),
      V.useEffect(f, p);
    let m;
    e[6] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((m = () => {
          r(!1), a(!1), d(), $(`closed`, `playOnApp_gameframe`);
        }),
        (e[6] = m))
      : (m = e[6]);
    let h = m,
      g;
    e[7] !== c || e[8] !== o || e[9] !== i
      ? ((g = () =>
          o
            ? (0, U.jsxs)(U.Fragment, {
                children: [
                  (0, U.jsx)(Ne, {
                    close: h,
                    slideEntered: i,
                    exiting: c,
                    onEntered: () => a(!0),
                  }),
                  i &&
                    (0, U.jsx)(`div`, {
                      className: Q.backdrop,
                      id: `qr-modal-backdrop`,
                    }),
                ],
              })
            : null),
        (e[7] = c),
        (e[8] = o),
        (e[9] = i),
        (e[10] = g))
      : (g = e[10]);
    let _ = g,
      v;
    e[11] === n
      ? (v = e[12])
      : ((v = () => {
          n ? $(`closed`, `playOnApp_gameframe`) : $(`clicked`, `gameframe`),
            r(!n);
        }),
        (e[11] = n),
        (e[12] = v));
    let b = v,
      x;
    e[13] === _ ? (x = e[14]) : ((x = _()), (e[13] = _), (e[14] = x));
    let S;
    e[15] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((S = (0, U.jsx)(y, { id: `tooltip.QRPlayOnMobile` })), (e[15] = S))
      : (S = e[15]);
    let C;
    e[16] !== n || e[17] !== b
      ? ((C = (0, U.jsx)(s, {
          title: S,
          placement: `top`,
          children: (0, U.jsx)(t, {
            icon: `phone`,
            onClick: b,
            isActive: n,
            id: `qr-modal-toggle-button`,
          }),
        })),
        (e[16] = n),
        (e[17] = b),
        (e[18] = C))
      : (C = e[18]);
    let w;
    return (
      e[19] !== x || e[20] !== C
        ? ((w = (0, U.jsxs)(U.Fragment, { children: [x, C] })),
          (e[19] = x),
          (e[20] = C),
          (e[21] = w))
        : (w = e[21]),
      w
    );
  }),
  Ie = V.memo((t) => {
    let n = (0, H.c)(23),
      { initialRating: r } = t,
      a;
    n[0] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((a = p.isEmbeddedExternally()), (n[0] = a))
      : (a = n[0]);
    let o = a,
      s,
      c,
      l,
      u,
      d,
      f,
      m;
    if (n[1] !== r) {
      let e = N(),
        t = () =>
          e.source === `standalone-qa` || e.source === `qa` ? !1 : !g() && !o,
        a;
      n[9] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((a = () => !g() && !o), (n[9] = a))
        : (a = n[9]);
      let p = a;
      (s = x.toolbar),
        n[10] === Symbol.for(`react.memo_cache_sentinel`)
          ? ((c = (0, U.jsx)(re, {})), (n[10] = c))
          : (c = n[10]),
        (l =
          t() &&
          (0, U.jsxs)(U.Fragment, {
            children: [
              (0, U.jsx)(oe, { initialRating: r }),
              (0, U.jsx)(ue, {}),
              (0, U.jsx)(ye, {}),
            ],
          })),
        n[11] === Symbol.for(`react.memo_cache_sentinel`)
          ? ((u = (0, U.jsx)(i, {})),
            (d = p() && (0, U.jsx)(Ae, {})),
            (n[11] = u),
            (n[12] = d))
          : ((u = n[11]), (d = n[12])),
        (f =
          !g() &&
          e.controls &&
          Object.keys(e.controls).length > 0 &&
          (0, U.jsx)(ke, {})),
        (m =
          !O() && (e.androidFriendly || e.iosFriendly) && (0, U.jsx)(Fe, {})),
        (n[1] = r),
        (n[2] = s),
        (n[3] = c),
        (n[4] = l),
        (n[5] = u),
        (n[6] = d),
        (n[7] = f),
        (n[8] = m);
    } else
      (s = n[2]),
        (c = n[3]),
        (l = n[4]),
        (u = n[5]),
        (d = n[6]),
        (f = n[7]),
        (m = n[8]);
    let h, _;
    n[13] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((_ = (0, U.jsx)(e, {})),
        (h = (0, U.jsx)(je, {})),
        (n[13] = h),
        (n[14] = _))
      : ((h = n[13]), (_ = n[14]));
    let v;
    return (
      n[15] !== s ||
      n[16] !== c ||
      n[17] !== l ||
      n[18] !== u ||
      n[19] !== d ||
      n[20] !== f ||
      n[21] !== m
        ? ((v = (0, U.jsxs)(`div`, {
            className: s,
            children: [c, l, u, d, f, m, _, h],
          })),
          (n[15] = s),
          (n[16] = c),
          (n[17] = l),
          (n[18] = u),
          (n[19] = d),
          (n[20] = f),
          (n[21] = m),
          (n[22] = v))
        : (v = n[22]),
      v
    );
  });
export { Ie as default };
//# debugId=2509146d-ac11-56c1-a986-8aaafbe8a2e2
