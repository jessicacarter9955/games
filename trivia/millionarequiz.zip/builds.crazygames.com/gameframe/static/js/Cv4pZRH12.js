!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "4657eff5-035f-56ad-8051-f86247281830"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `d9f44024-cf43-4a64-8e73-15a137c2f45c`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-d9f44024-cf43-4a64-8e73-15a137c2f45c`));
  } catch {}
})();
var e = {
  container: `_container_1u730_7`,
  code: `_code_1u730_28`,
  canvas: `_canvas_1u730_38`,
  progress: `_progress_1u730_42`,
  title: `_title_1u730_46`,
  subtitle: `_subtitle_1u730_54`,
  gameTitle: `_gameTitle_1u730_61`,
};
export { e as t };
//# debugId=4657eff5-035f-56ad-8051-f86247281830
