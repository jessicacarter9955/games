!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "779eb931-585a-5041-8390-153844adb9de"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `cda3cb98-2132-4de6-a8e8-8a9a2e8550cf`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-cda3cb98-2132-4de6-a8e8-8a9a2e8550cf`));
  } catch {}
})();
import {
  G as e,
  U as t,
  gn as n,
  it as r,
  un as i,
  yn as a,
} from "../../bundle.js";
var o = i();
a();
var s = n(),
  c = (n) => {
    let i = (0, o.c)(7),
      { warning: a, close: c, showCrazyLogo: l } = n,
      u = l === void 0 ? !0 : l,
      d;
    i[0] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((d = e()), (i[0] = d))
      : (d = i[0]);
    let f;
    i[1] !== c || i[2] !== a
      ? ((f = (0, s.jsx)(t, { close: c, warning: a })),
        (i[1] = c),
        (i[2] = a),
        (i[3] = f))
      : (f = i[3]);
    let p;
    return (
      i[4] !== u || i[5] !== f
        ? ((p = (0, s.jsx)(r, {
            showCrazyLogo: u,
            showGDPRNotice: d,
            children: f,
          })),
          (i[4] = u),
          (i[5] = f),
          (i[6] = p))
        : (p = i[6]),
      p
    );
  };
export { c as t };
//# debugId=779eb931-585a-5041-8390-153844adb9de
