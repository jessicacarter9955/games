!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "784ef0e3-4446-50a1-a16a-47387832bbe2"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `35db4335-b306-4275-9455-34a51706c5aa`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-35db4335-b306-4275-9455-34a51706c5aa`));
  } catch {}
})();
var e = {
  adsTxtMissingDomains:
    `bulletforcegame.com,onlineguru.ru,gamevui.vn,hitoikigame.com,ddz7.com,101bestgamesonline.com,game01.ru,madalinstuntcars2.com,naya1.com,gamepegasus.com,hoopgame.net,8fat.com,uhappygame.com,townden.com,gameslist.com,playground.ru,baixaki.com.br,allmathsgames.com,cda.pl,bgflash.com,spelle.nl,juga.es,gameitnow.com,joga.pt,spelle.be,leerspellen.nl,leerspellen.be,playground.ru,xn--250-dkl4k3bxi1d.com,bullet-force.io,webgames.cz,webgames.sk,bulletforce.org,arcadespot.com,jogalo.com,playgame.io,granny-games.com,oyundedem.com,twoplayergames.org,rekoroyun.com,minikoyuncu.org,topergame.com,friv-2017.com,gamekudo.com,slope-game.com,juegosfriv2018.net,1friv.info,run3freegame.com,kizi.com,2kik.ru,friv2019.com.br,jeux-gratuits.com,a10.com,spelletjes.nl,jeux.fr,gioco.it,gry.pl,spela.se,ojogos.com.br,juegos.com,gamesgames.com,games.co.uk,ourgames.ru,permainan.co.id,oyunskor.com,girlsgogames.com,girlsgogames.de,girlsgogames.fr,juegosdechicas.com,girlsgogames.it,girlsgogames.co.uk,girlsgogames.ru,girlsgogames.co.id,jeu.fr,spel.nl,spielen.com,games.co.id,agame.com,flashgames.ru,giochi.it,mousebreaker.com,1v1-battle.com,1v1battle.co,vengeio.online,ultrapixelsurvive.com,brawlhalla.online,taming-io.co,vengeio.online,jeuxgratuitjeux.com,krunkeronline.com,cookieclickercity.com`.split(
      `,`
    ),
  blacklistedDomains:
    `spiel1.com,freegames66.com,royagames.com,kdata1.com,kbhgames.com,www.gameshaha.net,gamasexual.com,spiele10.de,pokicom.com,fogames.com,jogosonlinewx.com.br,gameplaf.com,run3html5.com,gr.sgames.org,www.fnafgiochi.club,joy.land,flashstart.de,www.juegosfriv3.link,gamerdam.com,sgames.org,www.webgames.cz,www.webgames.sk,www.gameshaha.net,www.yupi.io,www.joy.land,www.frivonline.club,www.101games.it,trefoilkingdom.com,www.newkidsgames.org,www.spielenspiel.com,www.fnafgiochi.club,crazygames.cc,www.spiele10.de,vitalitygames.com,www.brightestgames.com,gameplaf.com,www.racecargamesonline.info,flashstart.de,it.joy.land,friv.games,www.1001paixnidia.eu,www.friv100.icu,www.juegosfriv2020.club,51h5.online,ucrazygames.com,run3.io,learntofly3hacked.com,buildnowgg.co,playminigames.ru,filesusr.com,jshell.net,1v1-battle.com,1v1battle.co,cookieclicker2.io,cookie-clicker2.com,cookieclicker.co,clickerheroes.co,smash-karts.com,rocketbotroyale.co,planetclicker2.com,retrobowl-unblocked.com,chainsaw-dance.com,realmohaodfree.space,cookieclicker3.com,2player.co,snowrider3d.com,dinosaur-game.io,geometrydash-free.com,geometrydash.io,snake-game.io,eggycar.co,wordwipe.io,gombis.com,gombis.it,gombis.pl,gombis.fr,oyun101.com,kiz10.com,paperio2.online,igre.games,game-game.pl,game-game.hu,game-game.pl,game-game.si,game-game.com,game-game.com.de,game-game.it,game-game.ro,1001games.io,bitlifeonline.com,brawlhalla.online,coreballgame.com,crosswordle.cc,dordle.app,dordle.online,draw-car.com,drift-hunters.com,fallguyss.co,fnaf2.online,fnf2.io,heardlegame.app,hellowordl.io,latimescrossword.co,melonplayground.co,nytspellingbee.org,pizzatower.io,playwordlegame.co,pokedle.io,poppy-playtime.co,sedecordle.io,skribblio.co,slitherio.online,slope-game.net,tetris-unblocked.co,wafflegame.co,weavergame.io,weaverwordle.com,wordhurdle.co,wordle-unlimited.app,wordle.bz,wordlegameorg.com,wordlewebsite.com,frivwtf.com,schoolpass247.github.io,gcafe.vn,spacewaves.io,space-waves.io,doodleroad.com,kizgame.com,evowars.org,more-games.xyz,sandboxcity.net,fragen.cc,igru.com.ua`.split(
      `,`
    ),
};
export { e as gameframeConfigData };
//# debugId=784ef0e3-4446-50a1-a16a-47387832bbe2
