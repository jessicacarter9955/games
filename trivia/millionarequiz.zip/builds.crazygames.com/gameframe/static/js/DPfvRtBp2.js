!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "8599cf36-bb92-5f8a-bcc5-5b5f1e73d935"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `9437cac0-cb6f-4b15-9ea6-dd10e4044e7b`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-9437cac0-cb6f-4b15-9ea6-dd10e4044e7b`));
  } catch {}
})();
import {
  Ct as e,
  It as t,
  Jt as n,
  Rt as r,
  St as i,
  Tt as a,
  Xt as o,
  _ as s,
  _t as c,
  at as l,
  b as u,
  bt as d,
  ct as f,
  g as p,
  gn as m,
  h,
  ht as g,
  jt as _,
  l as v,
  ln as y,
  lt as b,
  ot as x,
  pt as S,
  rn as C,
  rt as w,
  sn as T,
  un as E,
  v as D,
  vt as O,
  wn as k,
  x as A,
  xt as j,
  yn as M,
  yt as N,
} from "../../bundle.js";
var P = k(M()),
  F = E(),
  I = {
    content: `_content_lue6p_7`,
    closeIcon: `_closeIcon_lue6p_13`,
    title: `_title_lue6p_17`,
    body: `_body_lue6p_26`,
    actions: `_actions_lue6p_32`,
    button: `_button_lue6p_38`,
  },
  L = m(),
  R = (e) => {
    let t = (0, F.c)(19),
      { title: n, body: r, action: i } = e,
      a;
    t[0] === i ? (a = t[1]) : ((a = () => i(!1)), (t[0] = i), (t[1] = a));
    let o;
    t[2] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((o = (0, L.jsx)(S, {
          name: `close`,
          size: 20,
          className: I.closeIcon,
        })),
        (t[2] = o))
      : (o = t[2]);
    let s;
    t[3] === a
      ? (s = t[4])
      : ((s = (0, L.jsx)(f, { onClick: a, children: o })),
        (t[3] = a),
        (t[4] = s));
    let c;
    t[5] === n
      ? (c = t[6])
      : ((c = (0, L.jsx)(`h2`, { className: I.title, children: n })),
        (t[5] = n),
        (t[6] = c));
    let u;
    t[7] === r
      ? (u = t[8])
      : ((u = (0, L.jsx)(`p`, { className: I.body, children: r })),
        (t[7] = r),
        (t[8] = u));
    let d;
    t[9] === i ? (d = t[10]) : ((d = () => i(!1)), (t[9] = i), (t[10] = d));
    let p;
    t[11] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((p = (0, L.jsx)(l, { id: `aps.tooltip.button` })), (t[11] = p))
      : (p = t[11]);
    let m;
    t[12] === d
      ? (m = t[13])
      : ((m = (0, L.jsx)(`div`, {
          className: I.actions,
          children: (0, L.jsx)(w, {
            variant: `contained`,
            color: `purple`,
            height: 40,
            className: I.button,
            onClick: d,
            children: p,
          }),
        })),
        (t[12] = d),
        (t[13] = m));
    let h;
    return (
      t[14] !== s || t[15] !== c || t[16] !== u || t[17] !== m
        ? ((h = (0, L.jsx)(x, {
            children: (0, L.jsxs)(b, {
              className: I.content,
              children: [s, c, u, m],
            }),
          })),
          (t[14] = s),
          (t[15] = c),
          (t[16] = u),
          (t[17] = m),
          (t[18] = h))
        : (h = t[18]),
      h
    );
  },
  z = () => {
    let e = (0, F.c)(4),
      { accountId: n } = (0, P.useContext)(t),
      { gameLoadStatus: r } = (0, P.useContext)(_),
      [i, a] = P.useState(!1);
    if (!n || r !== `NOT_STARTED`) return null;
    if (i) {
      let t;
      return (
        e[0] === Symbol.for(`react.memo_cache_sentinel`)
          ? ((t = (0, L.jsx)(R, {
              title: (0, L.jsx)(l, { id: `aps.tooltip.crazyAccount.title` }),
              body: (0, L.jsx)(l, { id: `aps.tooltip.crazyAccount.body` }),
              action: a,
            })),
            (e[0] = t))
          : (t = e[0]),
        t
      );
    }
    let o;
    e[1] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((o = g(D.info, D.infoSuccess)), (e[1] = o))
      : (o = e[1]);
    let s;
    e[2] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((s = (0, L.jsx)(`div`, {
          children: (0, L.jsx)(l, {
            id: `aps.info.base`,
            values: {
              highlight: (0, L.jsx)(`span`, {
                className: D.highlightSuccess,
                children: (0, L.jsx)(l, { id: `aps.info.base.enabled` }),
              }),
            },
          }),
        })),
        (e[2] = s))
      : (s = e[2]);
    let c;
    return (
      e[3] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((c = (0, L.jsx)(`div`, {
            className: D.wrapper,
            children: (0, L.jsxs)(`div`, {
              className: o,
              children: [
                s,
                (0, L.jsx)(S, {
                  name: `question-bubble`,
                  size: 16,
                  className: D.questionBubble,
                  onClick: () => a(!0),
                }),
              ],
            }),
          })),
          (e[3] = c))
        : (c = e[3]),
      c
    );
  },
  B = (e) => {
    let t = (0, F.c)(15),
      { onContinueAsGuest: n, onLogin: r } = e,
      i;
    t[0] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((i = C()), (t[0] = i))
      : (i = t[0]);
    let { gameName: a } = i,
      o;
    t[1] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((o = (0, L.jsx)(`div`, { className: v.welcomeBackOverlay })),
        (t[1] = o))
      : (o = t[1]);
    let s;
    t[2] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((s = (0, L.jsx)(`div`, {
          className: v.welcomeBackZiggy,
          children: (0, L.jsx)(`img`, {
            src: c(`gameframe/ziggy.svg`, { width: 100 }),
            alt: `ziggy`,
          }),
        })),
        (t[2] = s))
      : (s = t[2]);
    let u;
    t[3] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((u = (0, L.jsx)(`div`, {
          className: v.welcomeBackTitle,
          children: (0, L.jsx)(l, { id: `aps.welcomeback.title` }),
        })),
        (t[3] = u))
      : (u = t[3]);
    let d;
    t[4] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((d = (0, L.jsxs)(`div`, {
          className: v.welcomeBackText,
          children: [
            u,
            (0, L.jsx)(`div`, {
              className: v.welcomeBackMessage,
              children: (0, L.jsx)(l, {
                id: `aps.welcomeback.subtitle`,
                values: {
                  game: (0, L.jsx)(`span`, {
                    className: v.welcomeBackGameName,
                    children: a,
                  }),
                },
              }),
            }),
          ],
        })),
        (t[4] = d))
      : (d = t[4]);
    let f;
    t[5] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((f = g(v.welcomeBackButton, v.welcomeBackGuest)), (t[5] = f))
      : (f = t[5]);
    let p;
    t[6] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((p = (0, L.jsx)(l, { id: `aps.welcomeback.asguest` })), (t[6] = p))
      : (p = t[6]);
    let m;
    t[7] === n
      ? (m = t[8])
      : ((m = (0, L.jsx)(w, {
          className: f,
          variant: `contained`,
          color: `grey`,
          height: 50,
          onClick: n,
          children: p,
        })),
        (t[7] = n),
        (t[8] = m));
    let h;
    t[9] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((h = (0, L.jsx)(l, { id: `aps.welcomeback.login` })), (t[9] = h))
      : (h = t[9]);
    let _;
    t[10] === r
      ? (_ = t[11])
      : ((_ = (0, L.jsx)(w, {
          className: v.welcomeBackButton,
          variant: `contained`,
          color: `purple`,
          height: 50,
          onClick: r,
          children: h,
        })),
        (t[10] = r),
        (t[11] = _));
    let y;
    return (
      t[12] !== _ || t[13] !== m
        ? ((y = (0, L.jsxs)(L.Fragment, {
            children: [
              o,
              (0, L.jsx)(`div`, {
                className: v.welcomeBackContainer,
                children: (0, L.jsxs)(`div`, {
                  className: v.welcomeBackShell,
                  children: [
                    s,
                    (0, L.jsxs)(`div`, {
                      className: v.welcomeBackPanel,
                      children: [
                        d,
                        (0, L.jsxs)(`div`, {
                          className: v.welcomeBackActions,
                          children: [m, _],
                        }),
                      ],
                    }),
                  ],
                }),
              }),
            ],
          })),
          (t[12] = _),
          (t[13] = m),
          (t[14] = y))
        : (y = t[14]),
      y
    );
  },
  V = 2,
  H = 7,
  U = 1440 * 60 * 1e3,
  W = `apsnotice_hidden_day`;
function G(e) {
  o.getInstance().sendEvent({
    type: `notificationAction`,
    notificationSource: `dont-lose-progress`,
    action: e,
  });
}
var K = () => {
    let { gameLoadStatus: e } = (0, P.useContext)(_),
      { gfInit: t } = (0, P.useContext)(A),
      {
        shouldShowWelcomeBack: i,
        canShowSplashNotice: a,
        reportWelcomeBackGuestNoticeAction: o,
      } = (0, P.useContext)(u),
      { isAppTrueFullscreen: c } = h(),
      d = y(),
      f = (0, P.useRef)(null),
      m = T(),
      [v, b] = (0, P.useState)(!1),
      [x, S] = (0, P.useState)(!1),
      [C, E] = (0, P.useState)(!1),
      [O] = (0, P.useState)(() => Date.now()),
      k = n.Instance.getItem(W),
      j = k ? O - Number(k) : null,
      M = !v && !(j && j < U),
      N = M && e === `GAME_LOADED`,
      F = M && a,
      I = s(`aps-login-pill`, p.apsLoginPill, N),
      R = (e) => {
        e.stopPropagation(), e.preventDefault(), b(!0);
        let t = Date.now();
        n.Instance.setItem(W, `${t}`);
      };
    P.useEffect(() => {
      let e;
      if (!d || !m) return;
      let t = new IntersectionObserver(([t]) => {
        t.isIntersecting &&
          !e &&
          (e = window.setTimeout(() => {
            S(!0);
          }, V * 1e3));
      });
      return (
        f && f.current && t.observe(f.current),
        function () {
          t.disconnect(), e && window.clearTimeout(e);
        }
      );
    }, [d, f, e, I]),
      P.useEffect(() => {
        if (!x) return;
        let e = window.setTimeout(() => {
          S(!1), b(!0);
        }, H * 1e3);
        return () => {
          window.clearTimeout(e);
        };
      }, [x]),
      P.useEffect(() => {
        if (!F) return;
        let e = window.setTimeout(() => {
          b(!0);
        }, (V + H) * 1e3);
        return () => {
          window.clearTimeout(e);
        };
      }, [F]);
    let z = (0, P.useRef)(!1);
    P.useEffect(() => {
      z.current ||
        !t ||
        !m ||
        (t.state === `success` &&
          t.data.wasUserLoggedIn &&
          ((z.current = !0), G(`shown`)));
    }, [t, m]);
    let K = () => {
      r(!0);
    };
    return i && !C
      ? (0, L.jsx)(B, {
          onContinueAsGuest: () => {
            E(!0), o(`ignored`);
          },
          onLogin: () => {
            r(!0), E(!0), o(`login`);
          },
        })
      : F
      ? (0, L.jsx)(`div`, {
          className: g(D.loginSplash, {
            [D.loginSplashPadded]: d,
            [D.inAppTrueFullscreen]: c,
          }),
          onClick: K,
          children: (0, L.jsxs)(`div`, {
            className: D.loginActions,
            children: [
              (0, L.jsx)(l, { id: `aps.splash.loginPrompt` }),
              (0, L.jsx)(w, {
                variant: `outlined`,
                color: `white`,
                height: 32,
                onClick: R,
                className: D.loginClose,
                children: (0, L.jsx)(l, { id: `aps.info.loginPrompt.close` }),
              }),
              (0, L.jsx)(w, {
                variant: `contained`,
                color: `white`,
                height: 32,
                onClick: K,
                children: (0, L.jsx)(l, { id: `aps.info.loginPrompt.cta` }),
              }),
            ],
          }),
        })
      : N && I
      ? (0, L.jsx)(`div`, {
          className: g(
            D.mobileLogin,
            x ? D.mobileLoginVisible : D.mobileLoginPending,
            { [D.inAppTrueFullscreen]: c }
          ),
          ref: f,
          children: (0, L.jsxs)(`div`, {
            children: [
              (0, L.jsx)(l, { id: `aps.info.loginPrompt` }),
              (0, L.jsxs)(`div`, {
                children: [
                  (0, L.jsx)(w, {
                    variant: `outlined`,
                    color: `white`,
                    height: 28,
                    onClick: R,
                    children: (0, L.jsx)(l, {
                      id: `aps.info.loginPrompt.close`,
                    }),
                  }),
                  (0, L.jsx)(w, {
                    variant: `contained`,
                    color: `white`,
                    height: 28,
                    onClick: K,
                    className: D.loginCta,
                    children: (0, L.jsx)(l, { id: `aps.info.loginPrompt.cta` }),
                  }),
                ],
              }),
            ],
          }),
        })
      : null;
  },
  q = () => {
    let e = (0, F.c)(3),
      { gameLoadStatus: t } = (0, P.useContext)(_),
      n = y(),
      [r, i] = P.useState(!1);
    if (t !== `NOT_STARTED` || n) return null;
    if (r) {
      let t;
      return (
        e[0] === Symbol.for(`react.memo_cache_sentinel`)
          ? ((t = (0, L.jsx)(R, {
              title: (0, L.jsx)(l, { id: `aps.tooltip.account.title` }),
              body: (0, L.jsx)(l, { id: `aps.tooltip.account.body` }),
              action: i,
            })),
            (e[0] = t))
          : (t = e[0]),
        t
      );
    }
    let a;
    e[1] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((a = (0, L.jsx)(`div`, {
          children: (0, L.jsx)(l, {
            id: `aps.info.ingame`,
            values: {
              highlight: (0, L.jsx)(`span`, {
                className: D.highlightWarning,
                children: (0, L.jsx)(l, { id: `aps.info.ingame.highlight` }),
              }),
            },
          }),
        })),
        (e[1] = a))
      : (a = e[1]);
    let o;
    return (
      e[2] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((o = (0, L.jsx)(`div`, {
            className: D.wrapper,
            children: (0, L.jsxs)(`div`, {
              className: D.info,
              children: [
                a,
                (0, L.jsx)(S, {
                  name: `question-bubble`,
                  size: 16,
                  className: D.questionBubble,
                  onClick: () => i(!0),
                }),
              ],
            }),
          })),
          (e[2] = o))
        : (o = e[2]),
      o
    );
  },
  J = () => {
    let e = (0, F.c)(3),
      { gameLoadStatus: t } = (0, P.useContext)(_),
      [n, r] = P.useState(!1);
    if (t !== `NOT_STARTED`) return null;
    if (n) {
      let t;
      return (
        e[0] === Symbol.for(`react.memo_cache_sentinel`)
          ? ((t = (0, L.jsx)(R, {
              title: (0, L.jsx)(l, { id: `aps.tooltip.locally.title` }),
              body: (0, L.jsx)(l, { id: `aps.tooltip.locally.body` }),
              action: r,
            })),
            (e[0] = t))
          : (t = e[0]),
        t
      );
    }
    let i;
    e[1] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((i = (0, L.jsx)(`div`, {
          children: (0, L.jsx)(l, {
            id: `aps.info.base`,
            values: {
              highlight: (0, L.jsx)(`span`, {
                className: D.highlightWarning,
                children: (0, L.jsx)(l, { id: `aps.info.base.local` }),
              }),
            },
          }),
        })),
        (e[1] = i))
      : (i = e[1]);
    let a;
    return (
      e[2] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((a = (0, L.jsx)(`div`, {
            className: D.wrapper,
            children: (0, L.jsxs)(`div`, {
              className: D.info,
              children: [
                i,
                (0, L.jsx)(S, {
                  name: `question-bubble`,
                  size: 16,
                  className: D.questionBubble,
                  onClick: () => r(!0),
                }),
              ],
            }),
          })),
          (e[2] = a))
        : (a = e[2]),
      a
    );
  },
  Y = () => {
    let t = C().loader,
      n = a[t];
    return d()
      ? n.type === `unity` && n.supportsAps
        ? e()
        : n.type === `other` && n.supportsIFrameApsLoader
        ? j()
        : t === `ruffle`
        ? i()
        : !1
      : !1;
  },
  X = () => {
    let e = (0, F.c)(4),
      { accountId: n, hasUserLoaded: r } = (0, P.useContext)(t);
    if (C().gameStatus === `unavailable`) return null;
    let i = N(),
      a = O();
    if (i === `ingame`) {
      let t;
      return (
        e[0] === Symbol.for(`react.memo_cache_sentinel`)
          ? ((t = (0, L.jsx)(q, {})), (e[0] = t))
          : (t = e[0]),
        t
      );
    }
    if (i === `local`) {
      let t;
      return (
        e[1] === Symbol.for(`react.memo_cache_sentinel`)
          ? ((t = (0, L.jsx)(J, {})), (e[1] = t))
          : (t = e[1]),
        t
      );
    }
    if (i === `cloud`) {
      if (!r || (a === `aps` && !Y())) return null;
      if (n) {
        let t;
        return (
          e[2] === Symbol.for(`react.memo_cache_sentinel`)
            ? ((t = (0, L.jsx)(z, {})), (e[2] = t))
            : (t = e[2]),
          t
        );
      }
      let t;
      return (
        e[3] === Symbol.for(`react.memo_cache_sentinel`)
          ? ((t = (0, L.jsx)(K, {})), (e[3] = t))
          : (t = e[3]),
        t
      );
    }
    return null;
  };
export { X as default };
//# debugId=8599cf36-bb92-5f8a-bcc5-5b5f1e73d935
