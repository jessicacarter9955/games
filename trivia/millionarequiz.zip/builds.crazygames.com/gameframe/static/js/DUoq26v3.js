!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "12648465-e8e9-5908-be8a-45c33dfdc53c"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `ade30fc1-4a33-429d-89a4-4a33f64cacef`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-ade30fc1-4a33-429d-89a4-4a33f64cacef`));
  } catch {}
})();
import {
  D as e,
  Dt as t,
  Ht as n,
  Lt as r,
  O as i,
  Ot as a,
  T as o,
  Zt as s,
  en as c,
  gn as l,
  k as u,
  kt as d,
  ln as f,
  n as p,
  nn as m,
  r as h,
  rn as g,
  wn as _,
  xn as v,
  yn as y,
} from "../../bundle.js";
import { t as b } from "./kpsB5uDx.js";
import { t as x } from "./Dkw7RdYv.js";
var S = _(y()),
  C = l(),
  w = o(
    u(
      i(
        class extends S.Component {
          constructor(e) {
            super(e),
              v(this, `config`, void 0),
              v(this, `options`, void 0),
              v(this, `progressTracker`, void 0),
              v(this, `iframe`, null),
              v(this, `detachRenderScale`, null),
              v(this, `processMessage`, (e) => {
                let { type: t } = e.data;
                t === `focusStealAttempt` && this.focusOnIframe();
              }),
              v(this, `onIframeLoad`, () => {
                this.progressTracker.trackLoadFinished(),
                  this.onLoad(),
                  this.focusOnIframe();
              }),
              v(this, `disableIframe`, () => {
                this.iframe &&=
                  (this.detachRenderScale?.(),
                  (this.detachRenderScale = null),
                  this.iframe.remove(),
                  null);
              }),
              v(this, `restartGame`, () => {
                window.location.reload();
              }),
              v(this, `onLoad`, () => {
                this.state.state !== `loaded` &&
                  (this.setState({ state: `loaded` }),
                  setTimeout(() => {
                    this.setState({ showLoadingBar: !1 });
                  }, 600),
                  this.props.onLoadFinished(),
                  p());
              }),
              v(this, `onFullscreenClose`, async () => {
                this.startLoading();
              }),
              v(this, `onAdFinished`, () => {
                this.focusOnIframe();
              }),
              (this.config = g()),
              (this.options = this.config.loaderOptions),
              (this.state = { state: `checking`, showLoadingBar: !1 }),
              (this.progressTracker = new x());
          }
          componentDidMount() {
            let e = f();
            this.config.fullscreen === `REQUIRED` &&
            !e &&
            !this.props.isFullscreen
              ? this.setState({ state: `fullscreen` })
              : this.startLoading(),
              n().addAdFinishedListener(this.onAdFinished),
              window.addEventListener(`message`, this.processMessage);
          }
          componentWillUnmount() {
            n().removeAdFinishedListener(this.onAdFinished),
              h(),
              this.detachRenderScale?.(),
              (this.detachRenderScale = null);
          }
          componentDidUpdate(e) {
            e.isFullscreen !== this.props.isFullscreen && this.focusOnIframe(),
              !e.isGameDisabled && this.props.isGameDisabled
                ? this.disableIframe()
                : e.isGameDisabled &&
                  !this.props.isGameDisabled &&
                  this.restartGame();
          }
          renderForState() {
            let { state: e } = this.state;
            switch (e) {
              case `checking`:
                return this.renderChecking();
              case `fullscreen`:
                return this.renderFullscreenOverlay();
              case `loaded`:
                return this.renderLoaded();
              default:
                throw Error(`[IFrameLoader] unexpected state ${e}`);
            }
          }
          render() {
            return (0, C.jsxs)(C.Fragment, {
              children: [
                this.renderForState(),
                this.state.showLoadingBar && this.renderLoading(),
              ],
            });
          }
          renderChecking() {
            return (0, C.jsx)(e, { showProgress: !1 });
          }
          renderFullscreenOverlay() {
            return (0, C.jsx)(b, {
              warning: `force-fullscreen`,
              close: this.onFullscreenClose,
            });
          }
          renderLoading() {
            return (0, C.jsx)(e, { showProgress: !1 });
          }
          renderLoaded() {
            return null;
          }
          loadIframe() {
            if (this.props.isGameDisabled) return;
            let { scrolling: e } = this.options,
              { sandbox: n } = this.config,
              r = document.createElement(`iframe`);
            (r.id = t),
              (r.src = this.getIframeUrl()),
              (r.onload = this.onIframeLoad),
              (r.style.border = `0`),
              (r.style.outline = `0`),
              (r.style.backgroundColor = `var(--neutral-0)`),
              e && r.setAttribute(`scrolling`, e),
              (r.style.width = `10px`),
              (r.style.height = `10px`),
              (r.style.minWidth = `100%`),
              (r.style.minHeight = `100%`),
              r.setAttribute(
                `allow`,
                d({
                  src: r.src,
                  extra: this.config.allowWebCam ? [`camera`] : [],
                })
              ),
              r.setAttribute(`webkitallowfullscreen`, `true`),
              r.setAttribute(`mozallowfullscreen`, `true`),
              r.setAttribute(`msallowfullscreen`, `true`),
              r.setAttribute(`allowfullscreen`, `true`),
              r.setAttribute(`data-testid`, `inner-iframe`),
              n && (r.setAttribute(`sandbox`, ``), r.sandbox.add(...a)),
              (this.iframe = r),
              m().appendChild(r),
              c() && (this.detachRenderScale = s(r));
          }
          async startLoading() {
            this.setState({ showLoadingBar: !0 });
            try {
              await r.Instance.waitForAPS();
            } catch {
            } finally {
              this.loadIframe(),
                this.progressTracker.trackLoadStarted(),
                setTimeout(() => {
                  this.onLoad();
                }, 10 * 1e3);
            }
          }
          getIframeUrl() {
            let e = new URL(this.options.url);
            return (
              new URLSearchParams(window.location.search).forEach((t, n) => {
                n !== `v` && e.searchParams.append(n, t);
              }),
              e.toString()
            );
          }
          focusOnIframe() {
            this.iframe &&
              this.iframe.contentWindow &&
              this.iframe.contentWindow.focus(),
              window.getSelection()?.removeAllRanges();
          }
        }
      )
    )
  );
export { w as default };
//# debugId=12648465-e8e9-5908-be8a-45c33dfdc53c
