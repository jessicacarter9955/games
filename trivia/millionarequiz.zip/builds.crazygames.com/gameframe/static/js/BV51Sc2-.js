!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "59c3d8c7-0144-5611-85d3-86509c615456"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `25f2de77-96a4-4188-9dd9-5bc2d70654ef`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-25f2de77-96a4-4188-9dd9-5bc2d70654ef`));
  } catch {}
})();
import {
  $ as e,
  At as t,
  Bt as n,
  Dt as r,
  E as i,
  It as a,
  J as o,
  Kt as s,
  Q as c,
  Ut as l,
  X as u,
  Xt as d,
  _n as f,
  at as p,
  d as m,
  et as h,
  f as g,
  gn as _,
  ht as v,
  jt as y,
  m as b,
  p as x,
  pt as S,
  rn as C,
  u as w,
  un as T,
  vt as E,
  wn as D,
  wt as O,
  yn as k,
} from "../../bundle.js";
function A(e, t, n) {
  let [r, i] = m(n?.in, e, t),
    a = j(r, i),
    o = Math.abs(w(r, i));
  r.setDate(r.getDate() - a * o);
  let s = a * (o - Number(j(r, i) === -a));
  return s === 0 ? 0 : s;
}
function j(e, t) {
  let n =
    e.getFullYear() - t.getFullYear() ||
    e.getMonth() - t.getMonth() ||
    e.getDate() - t.getDate() ||
    e.getHours() - t.getHours() ||
    e.getMinutes() - t.getMinutes() ||
    e.getSeconds() - t.getSeconds() ||
    e.getMilliseconds() - t.getMilliseconds();
  return n < 0 ? -1 : n > 0 ? 1 : n;
}
function M(e) {
  return (t) => {
    let n = (e ? Math[e] : Math.trunc)(t);
    return n === 0 ? 0 : n;
  };
}
function N(e, t, n) {
  let [r, i] = m(n?.in, e, t),
    a = (r - +i) / x;
  return M(n?.roundingMethod)(a);
}
function P(e, t) {
  return g(e) - +g(t);
}
function F(e, t, n) {
  let r = P(e, t) / b;
  return M(n?.roundingMethod)(r);
}
function I(e, t, n) {
  let r = P(e, t) / 1e3;
  return M(n?.roundingMethod)(r);
}
var L = D(k()),
  R = T(),
  z = {
    footerButton: `_footerButton_1xewu_1`,
    isInert: `_isInert_1xewu_24`,
    isActive: `_isActive_1xewu_34`,
    footerButtonLabel: `_footerButtonLabel_1xewu_50`,
    footerButtonIcon: `_footerButtonIcon_1xewu_53`,
    spin: `_spin_1xewu_53`,
    rotate: `_rotate_1xewu_1`,
    "footerButton--start": `_footerButton--start_1xewu_56`,
    "footerButton--end": `_footerButton--end_1xewu_60`,
    "footerButton--success": `_footerButton--success_1xewu_64`,
    "footerButton--warning": `_footerButton--warning_1xewu_67`,
    "footerButton--error": `_footerButton--error_1xewu_70`,
  },
  B = _();
function V() {
  document.getElementById(r)?.contentWindow?.focus();
}
var H = L.forwardRef((e, t) => {
    let n = (0, R.c)(22),
      {
        icon: r,
        children: i,
        label: a,
        onClick: o,
        isActive: s,
        status: c,
        spinIcon: l,
        segment: d,
        isInert: f,
        disabled: p,
        testId: m,
        id: h,
      } = e,
      g = c && z[`footerButton--${c}`],
      _ = d && z[`footerButton--${d}`],
      y = s && z.isActive,
      b = f && z.isInert,
      x;
    n[0] !== g || n[1] !== _ || n[2] !== y || n[3] !== b
      ? ((x = v(z.footerButton, g, _, y, b)),
        (n[0] = g),
        (n[1] = _),
        (n[2] = y),
        (n[3] = b),
        (n[4] = x))
      : (x = n[4]);
    let S;
    n[5] === o
      ? (S = n[6])
      : ((S = (e) => {
          o(e), e.currentTarget.blur(), V();
        }),
        (n[5] = o),
        (n[6] = S));
    let C;
    n[7] !== i || n[8] !== r || n[9] !== l
      ? ((C =
          i ??
          (r &&
            (0, B.jsx)(u, {
              name: r,
              size: `small`,
              className: v(z.footerButtonIcon, l && z.spin),
            }))),
        (n[7] = i),
        (n[8] = r),
        (n[9] = l),
        (n[10] = C))
      : (C = n[10]);
    let w;
    n[11] === a
      ? (w = n[12])
      : ((w =
          a != null &&
          (0, B.jsx)(`span`, { className: z.footerButtonLabel, children: a })),
        (n[11] = a),
        (n[12] = w));
    let T;
    return (
      n[13] !== p ||
      n[14] !== h ||
      n[15] !== t ||
      n[16] !== x ||
      n[17] !== S ||
      n[18] !== C ||
      n[19] !== w ||
      n[20] !== m
        ? ((T = (0, B.jsxs)(`button`, {
            type: `button`,
            "data-testid": m,
            id: h,
            className: x,
            ref: t,
            onClick: S,
            disabled: p,
            children: [C, w],
          })),
          (n[13] = p),
          (n[14] = h),
          (n[15] = t),
          (n[16] = x),
          (n[17] = S),
          (n[18] = C),
          (n[19] = w),
          (n[20] = m),
          (n[21] = T))
        : (T = n[21]),
      T
    );
  }),
  U = {
    root: `_root_pbyrb_7`,
    button: `_button_pbyrb_14`,
    landscape: `_landscape_pbyrb_29`,
    inert: `_inert_pbyrb_32`,
    icon: `_icon_pbyrb_37`,
    success: `_success_pbyrb_43`,
    warning: `_warning_pbyrb_46`,
    error: `_error_pbyrb_49`,
    spin: `_spin_pbyrb_61`,
    rotate: `_rotate_pbyrb_1`,
  },
  W = (e) => {
    let t = (0, R.c)(17),
      {
        icon: n,
        children: r,
        iconSize: i,
        onClick: a,
        tone: o,
        spinIcon: s,
        landscape: c,
        inert: l,
        disabled: u,
        testId: d,
      } = e,
      f = c && U.landscape,
      p = l && U.inert,
      m;
    t[0] !== f || t[1] !== p
      ? ((m = v(U.button, f, p)), (t[0] = f), (t[1] = p), (t[2] = m))
      : (m = t[2]);
    let h;
    t[3] === a
      ? (h = t[4])
      : ((h = (e) => {
          a(e), e.currentTarget.blur(), V();
        }),
        (t[3] = a),
        (t[4] = h));
    let g;
    t[5] !== r || t[6] !== n || t[7] !== i || t[8] !== s || t[9] !== o
      ? ((g =
          r ??
          (n &&
            (0, B.jsx)(S, {
              name: n,
              size: i,
              className: v(U.icon, o && U[o], s && U.spin),
            }))),
        (t[5] = r),
        (t[6] = n),
        (t[7] = i),
        (t[8] = s),
        (t[9] = o),
        (t[10] = g))
      : (g = t[10]);
    let _;
    return (
      t[11] !== u || t[12] !== m || t[13] !== h || t[14] !== g || t[15] !== d
        ? ((_ = (0, B.jsx)(`div`, {
            className: U.root,
            children: (0, B.jsx)(`button`, {
              type: `button`,
              "data-testid": d,
              className: m,
              onClick: h,
              disabled: u,
              children: g,
            }),
          })),
          (t[11] = u),
          (t[12] = m),
          (t[13] = h),
          (t[14] = g),
          (t[15] = d),
          (t[16] = _))
        : (_ = t[16]),
      _
    );
  };
function G(e) {
  let t = (0, R.c)(3),
    [n, r] = (0, L.useState)(K),
    [i, a] = (0, L.useState)(e);
  i !== e && (a(e), e && r(new Date()));
  let o, s;
  return (
    t[0] === e
      ? ((o = t[1]), (s = t[2]))
      : ((o = () => {
          if (!e) return;
          let t = window.setInterval(() => {
            r(new Date());
          }, 1e3);
          return () => window.clearInterval(t);
        }),
        (s = [e]),
        (t[0] = e),
        (t[1] = o),
        (t[2] = s)),
    (0, L.useEffect)(o, s),
    n
  );
}
function K() {
  return new Date();
}
var q = {
  default: `cloud-default`,
  offline: `cloud-offline`,
  issue: `cloud-issue`,
  uploaded: `cloud-uploaded`,
  syncing: `refresh`,
};
function J(e) {
  switch (e) {
    case `success`:
      return `cloud_check`;
    case `warning`:
    case `error`:
      return `cloud_error`;
    default:
      return `cloud`;
  }
}
function Y(e, t) {
  let n = I(e, t);
  if (n < 60)
    return n === 1
      ? f._(`secondAgo`, { value: n })
      : f._(`secondsAgo`, { value: n });
  if (n < 3600) {
    let n = F(e, t);
    return n === 1
      ? f._(`minuteAgo`, { value: n })
      : f._(`minutesAgo`, { value: n });
  }
  if (n < 3600 * 24) {
    let n = N(e, t);
    return n === 1
      ? f._(`hourAgo`, { value: n })
      : f._(`hoursAgo`, { value: n });
  }
  let r = A(e, t);
  return r === 1 ? f._(`dayAgo`, { value: r }) : f._(`daysAgo`, { value: r });
}
var X = (e) => {
    let r = (0, R.c)(21),
      { isMobileBar: o, isLandscape: u } = e,
      { iconsStatus: d, progressSyncHandler: p } = L.useContext(t),
      { accountId: m } = L.useContext(a),
      [h, g] = (0, L.useState)(!1),
      { isFullscreen: _, disableFullscreen: v } = L.useContext(i),
      y = E(),
      b = G(h);
    if ((y === `unknown` || p === `none`) && !O()) return null;
    let x;
    r[0] !== m ||
    r[1] !== b ||
    r[2] !== d.lastSaveAt ||
    r[3] !== d.lastSyncType ||
    r[4] !== d.status
      ? ((x = () => {
          let e = ``,
            t = ``,
            n,
            r = `default`;
          if (l())
            return (
              (e = f._(`progressSyncIndicator.offline.title`)),
              {
                tooltipTitleText: e,
                tooltipSubtitleText: ``,
                buttonStatus: n,
                cloudState: `offline`,
                inert: !0,
              }
            );
          if (!m)
            return (
              (e = f._(`progressSyncIndicator.noUser`)),
              {
                tooltipTitleText: e,
                tooltipSubtitleText: ``,
                buttonStatus: `error`,
                cloudState: `issue`,
              }
            );
          bb19: switch (d.status) {
            case `none`:
              e = f._(`progressSyncIndicator.loadNotStarted`);
              break bb19;
            case `ingameautologin`:
              e = f._(`progressSyncIndicator.ingameautologin`);
              break bb19;
            case `syncing`:
              (e = f._(
                d.lastSyncType === `save`
                  ? `progressSyncIndicator.saving`
                  : `progressSyncIndicator.loading`
              )),
                (r = `syncing`);
              break bb19;
            case `synced-success`:
              (n = `success`), (r = `uploaded`);
              break bb19;
            case `synced-warning`:
              d.lastSyncType === `load`
                ? (r = `syncing`)
                : ((e = f._(`progressSyncIndicator.warning.title`)),
                  (n = `warning`),
                  (r = `issue`),
                  d.lastSaveAt &&
                    (t = `${f._(`progressSyncIndicator.lastProgressSave`)} ${Y(
                      b,
                      d.lastSaveAt
                    )}`));
              break bb19;
            case `synced-error`:
              (e = f._(`progressSyncIndicator.error.title`)),
                (n = `error`),
                (r = `issue`),
                d.lastSaveAt &&
                  (t = `${f._(`progressSyncIndicator.lastProgressSave`)} ${Y(
                    b,
                    d.lastSaveAt
                  )}
`);
              break bb19;
            case `synced`:
              if (((r = `uploaded`), d.lastSyncType === `load`))
                if (d.lastSaveAt)
                  try {
                    e = f._(`progressSyncIndicator.lastProgressLoad`, {
                      time: f.date(d.lastSaveAt, {
                        month: `short`,
                        day: `2-digit`,
                        hour: `numeric`,
                        minute: `numeric`,
                        hour12: !1,
                      }),
                    });
                  } catch (e) {
                    console.error(`Failed to format tooltip title text`, e);
                  }
                else e = f._(`progressSyncIndicator.noProgress`);
              d.lastSyncType === `save` &&
                d.lastSaveAt &&
                (e = `${f._(`progressSyncIndicator.progressSaved`)} ${Y(
                  b,
                  d.lastSaveAt
                )}`);
          }
          return {
            tooltipTitleText: e,
            tooltipSubtitleText: t,
            buttonStatus: n,
            cloudState: r,
          };
        }),
        (r[0] = m),
        (r[1] = b),
        (r[2] = d.lastSaveAt),
        (r[3] = d.lastSyncType),
        (r[4] = d.status),
        (r[5] = x))
      : (x = r[5]);
    let S = x,
      C,
      w;
    if (
      r[6] !== m ||
      r[7] !== S ||
      r[8] !== v ||
      r[9] !== d ||
      r[10] !== _ ||
      r[11] !== u ||
      r[12] !== o
    ) {
      C = S();
      let e = () => {
          if (!C.inert) {
            if (
              (n.Instance.isFullscreen() && n.Instance.exitFullscreen(),
              _ && v(),
              s.exitFullscreen(),
              !m)
            ) {
              s.showLoginDrawer(`progressSyncIndicator`, `Gfprogressicon`);
              return;
            }
            d.status !== `syncing` && s.openProgressStatusDrawer(d);
          }
        },
        t = C.cloudState === `syncing`,
        i = d.status === `syncing`;
      (w = o
        ? (0, B.jsx)(W, {
            icon: q[C.cloudState],
            spinIcon: t,
            tone: C.buttonStatus,
            inert: C.inert,
            landscape: u,
            disabled: i,
            onClick: e,
            testId: `footer-progress-sync-indicator-button`,
          })
        : (0, B.jsx)(H, {
            icon: t ? `updated` : J(C.buttonStatus),
            spinIcon: t,
            status: C.buttonStatus,
            isInert: C.inert,
            disabled: i,
            onClick: e,
            testId: `footer-progress-sync-indicator-button`,
          })),
        (r[6] = m),
        (r[7] = S),
        (r[8] = v),
        (r[9] = d),
        (r[10] = _),
        (r[11] = u),
        (r[12] = o),
        (r[13] = C),
        (r[14] = w);
    } else (C = r[13]), (w = r[14]);
    let T = w;
    if (C.tooltipTitleText) {
      let e, t;
      r[15] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((e = () => g(!0)), (t = () => g(!1)), (r[15] = e), (r[16] = t))
        : ((e = r[15]), (t = r[16]));
      let n;
      return (
        r[17] !== T ||
        r[18] !== C.tooltipSubtitleText ||
        r[19] !== C.tooltipTitleText
          ? ((n = (0, B.jsx)(c, {
              titleText: C.tooltipTitleText,
              subtitleText: C.tooltipSubtitleText,
              onOpen: e,
              onClose: t,
              children: T,
            })),
            (r[17] = T),
            (r[18] = C.tooltipSubtitleText),
            (r[19] = C.tooltipTitleText),
            (r[20] = n))
          : (n = r[20]),
        n
      );
    } else return T;
  },
  Z = L.memo((t) => {
    let n = (0, R.c)(26),
      { isMobileBar: r, isLandscape: i } = t,
      a;
    n[0] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((a = C()), (n[0] = a))
      : (a = n[0]);
    let c = a,
      { gameLoadStatus: l } = L.useContext(y),
      { platformMuted: u, appAudioMuteSupported: d, setPlatformMuted: f } = o(),
      m,
      h;
    if (
      (n[1] !== l || n[2] !== u
        ? ((m = () => {
            c.platformAudioMuteSupported &&
              l === `GAME_LOADED` &&
              u &&
              s.sendMuteAudioMessageToGameIframe(u);
          }),
          (h = [l, u, c]),
          (n[1] = l),
          (n[2] = u),
          (n[3] = m),
          (n[4] = h))
        : ((m = n[3]), (h = n[4])),
      L.useEffect(m, h),
      !c || (!c.platformAudioMuteSupported && !d))
    )
      return null;
    let g;
    n[5] === f
      ? (g = n[6])
      : ((g = () => {
          f(!1), s.toggleMute(!1);
        }),
        (n[5] = f),
        (n[6] = g));
    let _ = g,
      v;
    n[7] === f
      ? (v = n[8])
      : ((v = () => {
          f(!0), s.toggleMute(!0);
        }),
        (n[7] = f),
        (n[8] = v));
    let b = v,
      x;
    n[9] !== b || n[10] !== u || n[11] !== _
      ? ((x = () => (u ? _() : b())),
        (n[9] = b),
        (n[10] = u),
        (n[11] = _),
        (n[12] = x))
      : (x = n[12]);
    let S = x;
    if (r) {
      let e = u ? `volume-off` : `volume-on`,
        t;
      return (
        n[13] !== i || n[14] !== e || n[15] !== S
          ? ((t = (0, B.jsx)(W, {
              icon: e,
              landscape: i,
              onClick: S,
              testId: `footer-mute-button`,
            })),
            (n[13] = i),
            (n[14] = e),
            (n[15] = S),
            (n[16] = t))
          : (t = n[16]),
        t
      );
    }
    let w = u ? `tooltip.unmute` : `tooltip.mute`,
      T;
    n[17] === w
      ? (T = n[18])
      : ((T = (0, B.jsx)(p, { id: w })), (n[17] = w), (n[18] = T));
    let E = u ? `mute` : `unmute`,
      D = !!u,
      O;
    n[19] !== E || n[20] !== D || n[21] !== S
      ? ((O = (0, B.jsx)(H, {
          icon: E,
          isActive: D,
          onClick: S,
          testId: `footer-mute-button`,
        })),
        (n[19] = E),
        (n[20] = D),
        (n[21] = S),
        (n[22] = O))
      : (O = n[22]);
    let k;
    return (
      n[23] !== O || n[24] !== T
        ? ((k = (0, B.jsx)(e, { title: T, placement: `top`, children: O })),
          (n[23] = O),
          (n[24] = T),
          (n[25] = k))
        : (k = n[25]),
      k
    );
  }),
  Q = (e) => {
    let t = (0, R.c)(11),
      { status: n, compact: r } = e,
      i = r ? `xsmall` : `small`,
      a;
    t[0] === i
      ? (a = t[1])
      : ((a = (0, B.jsx)(u, { name: `notifications`, size: i })),
        (t[0] = i),
        (t[1] = a));
    let o;
    t[2] !== r || t[3] !== n
      ? ((o =
          n === `on` &&
          (0, B.jsx)(`span`, {
            className: v(
              h.notificationsBadge,
              r && h.notificationsBadgeCompact
            ),
            "data-testid": `footer-notifications-badge`,
            children: (0, B.jsx)(u, { name: `check`, size: `custom` }),
          })),
        (t[2] = r),
        (t[3] = n),
        (t[4] = o))
      : (o = t[4]);
    let s;
    t[5] === n
      ? (s = t[6])
      : ((s =
          n === `blocked` &&
          (0, B.jsx)(`span`, {
            className: h.notificationsSlash,
            "data-testid": `footer-notifications-blocked`,
          })),
        (t[5] = n),
        (t[6] = s));
    let c;
    return (
      t[7] !== a || t[8] !== o || t[9] !== s
        ? ((c = (0, B.jsxs)(`div`, {
            className: h.notificationsInner,
            children: [a, o, s],
          })),
          (t[7] = a),
          (t[8] = o),
          (t[9] = s),
          (t[10] = c))
        : (c = t[10]),
      c
    );
  },
  $ = (e, t) => {
    let n = {
      type: `modal`,
      campaign: `GameNotifications`,
      target: `bell`,
      action: `clicked`,
      clickOrigin: t,
      message: e,
    };
    d.getInstance().sendEvent(n);
  },
  ee = (e) => {
    let t = {
      type: `modal`,
      campaign: `GameNotifications`,
      target: `unblockNotificationsPopup`,
      action: e,
      clickOrigin: `gameframe`,
    };
    d.getInstance().sendEvent(t);
  },
  te = (e, t) => {
    let n = {
      type: `modal`,
      campaign: `GameNotifications`,
      target: `notificationPrompt`,
      action: e,
      clickOrigin: `gameframe`,
      message: t,
    };
    d.getInstance().sendEvent(n);
  };
export { Z as a, H as c, Q as i, $ as n, X as o, ee as r, W as s, te as t };
//# debugId=59c3d8c7-0144-5611-85d3-86509c615456
