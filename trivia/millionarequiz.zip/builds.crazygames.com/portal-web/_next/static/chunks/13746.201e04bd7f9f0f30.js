!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (null != n) for (var o in n) n.hasOwnProperty(o) && (e[o] = n[o]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "0c76ceb8-24fc-4736-8704-62667a9003f6"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-0c76ceb8-24fc-4736-8704-62667a9003f6"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [13746],
    {
      845: (e, t, n) => {
        "use strict";
        n.d(t, { U: () => l });
        var o = n(75155),
          a = n(55729),
          i = n(74532),
          r = n(81631),
          c = n(7377);
        function l() {
          let e,
            t = (0, o.c)(3),
            n = (0, c.A)(),
            { countryCode: l } = (0, a.useContext)(i.A),
            s = "true" === n[r.Q2];
          return (
            t[0] !== l || t[1] !== s
              ? ((e = (0, r.D_)(l, s)), (t[0] = l), (t[1] = s), (t[2] = e))
              : (e = t[2]),
            e
          );
        }
      },
      2610: (e) => {
        e.exports = {
          flame: "FlameSvg_flame__MvlLF",
          layer: "FlameSvg_layer__Hj_SL",
          flick: "FlameSvg_flick__b5jp_",
          tongue: "FlameSvg_tongue__TS_mZ",
          core: "FlameSvg_core__o_143",
        };
      },
      5875: (e, t, n) => {
        "use strict";
        n.d(t, { l: () => a });
        var o = n(55729);
        function a() {
          return [...o.useId()].reduce(
            (e, t) => (31 * e + t.charCodeAt(0)) % 1300,
            7
          );
        }
      },
      6958: (e, t, n) => {
        "use strict";
        n.d(t, { Xz: () => y, z$: () => g, Ay: () => p });
        var o = n(6029),
          a = n(55729),
          i = n(50212),
          r = n(93800),
          c = n(41272),
          l = n(71237),
          s = n(14886),
          u = n(94618),
          d = n(42832),
          _ = n.n(d);
        let m = a.memo((e) => {
          let { isActive: t, icon: n, activeIcon: d } = e,
            { loadingUser: m, userTokenExists: y } = a.useContext(s.R),
            { user: g, loading: h } = l.Jd();
          return (m && !y) || h
            ? (0, o.jsx)("span", { className: _().profileAvatarSkeleton })
            : g && g.profile.avatar
            ? (0, o.jsx)(c.A, {
                src: (0, u.Ay)(g.profile.avatar, { width: 26, height: 26 }),
                srcSet: (0, u.Wn)(g.profile.avatar, { width: 26, height: 26 }),
                alt: "",
                "aria-hidden": "true",
                noMargin: !0,
                className: (0, i.A)(
                  _().profileAvatar,
                  t && _().profileAvatarActive
                ),
              })
            : (0, o.jsx)(r.A, { name: t ? d : n, size: 24 });
        });
        m.displayName = "BottomNavigationProfileIcon";
        let y = "bottom-nav-login-button",
          g = "bottom-nav-mygames-button",
          h = a.memo((e) => {
            let { item: t, isActive: n, isGuest: c, onTap: l } = e,
              s = (0, a.useCallback)(
                (e) => {
                  e.preventDefault(), l(t);
                },
                [t, l]
              );
            return (0, o.jsxs)("a", {
              className: (0, i.A)(_().navItem, n && _().isActive),
              href: t.href || "#",
              onClick: s,
              "aria-label": t.label,
              "aria-current": n ? "page" : void 0,
              id:
                "profile" === t.id
                  ? c
                    ? y
                    : void 0
                  : "myGames" === t.id
                  ? g
                  : void 0,
              "data-testid": `bottom-nav-${t.id.toLowerCase()}`,
              children: [
                (0, o.jsxs)("span", {
                  className: _().navItemIcon,
                  children: [
                    "profile" === t.id
                      ? (0, o.jsx)(m, {
                          isActive: n,
                          icon: t.icon,
                          activeIcon: t.activeIcon,
                        })
                      : (0, o.jsx)(r.A, {
                          name: n ? t.activeIcon : t.icon,
                          size: 24,
                        }),
                    t.badge?.show &&
                      "count" === t.badge.variant &&
                      (t.badge.count ?? 0) > 0 &&
                      (0, o.jsx)("span", {
                        className: (0, i.A)(_().badge, _().badgeCount),
                        children: t.badge.count,
                      }),
                    t.badge?.show &&
                      "dot" === t.badge.variant &&
                      (0, o.jsx)("span", {
                        className: (0, i.A)(_().badge, _().badgeDot),
                      }),
                  ],
                }),
                (0, o.jsx)("span", {
                  className: _().navItemLabel,
                  children: t.label,
                }),
              ],
            });
          });
        h.displayName = "BottomNavigationItem";
        let p = h;
      },
      7377: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => i });
        var o = n(75155),
          a = n(81278);
        n(55729);
        let i = function () {
          let e = (0, o.c)(3);
          (0, a.useRouter)();
          {
            let t;
            return (
              e[2] === Symbol.for("react.memo_cache_sentinel")
                ? ((t = { ...window.__NEXT_DATA__.props.queryParameters }),
                  (e[2] = t))
                : (t = e[2]),
              t
            );
          }
        };
      },
      9008: (e) => {
        e.exports = {
          czyButton: "AnchoredNudge_czyButton__chOsG",
          "czyButton--contained--purple":
            "AnchoredNudge_czyButton--contained--purple__Z0U6p",
          "czyButton--contained--white":
            "AnchoredNudge_czyButton--contained--white__dufro",
          "czyButton--contained--grey":
            "AnchoredNudge_czyButton--contained--grey__9b_Z4",
          "czyButton--contained--warning":
            "AnchoredNudge_czyButton--contained--warning__J4x6p",
          "czyButton--contained--alert":
            "AnchoredNudge_czyButton--contained--alert__cYdyG",
          "czyButton--contained--success":
            "AnchoredNudge_czyButton--contained--success__79N14",
          "czyButton--contained--black":
            "AnchoredNudge_czyButton--contained--black__VNAHl",
          "czyButton--contained--green-gradient":
            "AnchoredNudge_czyButton--contained--green-gradient__qYF1M",
          "czyButton--contained--animated-green-gradient":
            "AnchoredNudge_czyButton--contained--animated-green-gradient__RIuSX",
          "scroll-gradient": "AnchoredNudge_scroll-gradient__pcM_4",
          "czyButton--outlined--purple":
            "AnchoredNudge_czyButton--outlined--purple__Tu1xu",
          "czyButton--link--purple":
            "AnchoredNudge_czyButton--link--purple__rPKAc",
          "czyButton--outlined--white":
            "AnchoredNudge_czyButton--outlined--white__BzHzO",
          "czyButton--link--white":
            "AnchoredNudge_czyButton--link--white__Xr8QY",
          "czyButton--outlined--grey":
            "AnchoredNudge_czyButton--outlined--grey__Tddxo",
          "czyButton--link--grey": "AnchoredNudge_czyButton--link--grey__QNRfL",
          "czyButton--outlined--warning":
            "AnchoredNudge_czyButton--outlined--warning__Zj9mt",
          "czyButton--link--warning":
            "AnchoredNudge_czyButton--link--warning__0ndK4",
          "czyButton--outlined--alert":
            "AnchoredNudge_czyButton--outlined--alert__CkILd",
          "czyButton--link--alert":
            "AnchoredNudge_czyButton--link--alert__akeAT",
          "czyButton--outlined--success":
            "AnchoredNudge_czyButton--outlined--success__ax6Nj",
          "czyButton--link--success":
            "AnchoredNudge_czyButton--link--success__PbY_2",
          "czyButton--outlined": "AnchoredNudge_czyButton--outlined__3S5A4",
          "czyButton--disabled": "AnchoredNudge_czyButton--disabled__gJWjB",
          "czyButton--height50": "AnchoredNudge_czyButton--height50__49UJZ",
          "czyButton--height34": "AnchoredNudge_czyButton--height34__sp3DR",
          "czyButton--height28": "AnchoredNudge_czyButton--height28__I3EXx",
          "czyButton--fullWidth": "AnchoredNudge_czyButton--fullWidth__85mvZ",
          "czyButton--headerIcon": "AnchoredNudge_czyButton--headerIcon__rz2HU",
          "czyButton--headerIcon--desktop":
            "AnchoredNudge_czyButton--headerIcon--desktop__0_guG",
          "czyButton--headerIcon--mobile":
            "AnchoredNudge_czyButton--headerIcon--mobile__2SgRC",
          "czyButton--headerIcon--withLabel":
            "AnchoredNudge_czyButton--headerIcon--withLabel__wL9qU",
          nudge: "AnchoredNudge_nudge__YKF3L",
          clickable: "AnchoredNudge_clickable__QHn_f",
          content: "AnchoredNudge_content__uBixt",
          title: "AnchoredNudge_title__mAB7v",
          body: "AnchoredNudge_body__jkLGF",
          close: "AnchoredNudge_close__QpCy_",
        };
      },
      13281: (e, t, n) => {
        "use strict";
        var o = Object.create
          ? function (e, t, n, o) {
              void 0 === o && (o = n);
              var a = Object.getOwnPropertyDescriptor(t, n);
              (!a ||
                ("get" in a ? !t.__esModule : a.writable || a.configurable)) &&
                (a = {
                  enumerable: !0,
                  get: function () {
                    return t[n];
                  },
                }),
                Object.defineProperty(e, o, a);
            }
          : function (e, t, n, o) {
              void 0 === o && (o = n), (e[o] = t[n]);
            };
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.ExternalPayment = void 0);
        let a = n(34651);
        var i = n(32687);
        for (var r in i)
          "default" === r ||
            Object.prototype.hasOwnProperty.call(t, r) ||
            o(t, i, r);
        t.ExternalPayment = (0, a.registerPlugin)("ExternalPayment", {
          web: () =>
            n
              .e(93607)
              .then(n.bind(n, 93607))
              .then((e) => new e.ExternalPaymentWeb()),
        });
      },
      14469: (e) => {
        e.exports = {
          offlineDownloadWrapper:
            "MobileGameActions_offlineDownloadWrapper__wsGp3",
          addToHomescreenWrapper:
            "MobileGameActions_addToHomescreenWrapper__KffAF",
          czyButton: "MobileGameActions_czyButton__1_iKD",
          "czyButton--contained--purple":
            "MobileGameActions_czyButton--contained--purple__BWDda",
          "czyButton--contained--white":
            "MobileGameActions_czyButton--contained--white__LHyFD",
          "czyButton--contained--grey":
            "MobileGameActions_czyButton--contained--grey__5nkR5",
          "czyButton--contained--warning":
            "MobileGameActions_czyButton--contained--warning__wq66r",
          "czyButton--contained--alert":
            "MobileGameActions_czyButton--contained--alert__YqzDs",
          "czyButton--contained--success":
            "MobileGameActions_czyButton--contained--success__k_8T_",
          "czyButton--contained--black":
            "MobileGameActions_czyButton--contained--black__2KRmm",
          "czyButton--contained--green-gradient":
            "MobileGameActions_czyButton--contained--green-gradient__un0_8",
          "czyButton--contained--animated-green-gradient":
            "MobileGameActions_czyButton--contained--animated-green-gradient__ekFgN",
          "scroll-gradient": "MobileGameActions_scroll-gradient__S9CzR",
          "czyButton--outlined--purple":
            "MobileGameActions_czyButton--outlined--purple__BwRpR",
          "czyButton--link--purple":
            "MobileGameActions_czyButton--link--purple__BxAN_",
          "czyButton--outlined--white":
            "MobileGameActions_czyButton--outlined--white__wldLE",
          "czyButton--link--white":
            "MobileGameActions_czyButton--link--white__N340a",
          "czyButton--outlined--grey":
            "MobileGameActions_czyButton--outlined--grey__02hiJ",
          "czyButton--link--grey":
            "MobileGameActions_czyButton--link--grey__r_2Rj",
          "czyButton--outlined--warning":
            "MobileGameActions_czyButton--outlined--warning__aYhwu",
          "czyButton--link--warning":
            "MobileGameActions_czyButton--link--warning__58JIK",
          "czyButton--outlined--alert":
            "MobileGameActions_czyButton--outlined--alert__gMIpw",
          "czyButton--link--alert":
            "MobileGameActions_czyButton--link--alert___s5DH",
          "czyButton--outlined--success":
            "MobileGameActions_czyButton--outlined--success___8H9X",
          "czyButton--link--success":
            "MobileGameActions_czyButton--link--success__cBGmP",
          "czyButton--outlined": "MobileGameActions_czyButton--outlined__MtI4J",
          "czyButton--disabled": "MobileGameActions_czyButton--disabled__XLYwh",
          "czyButton--height50": "MobileGameActions_czyButton--height50__cBkJg",
          "czyButton--height34": "MobileGameActions_czyButton--height34__CMSTs",
          "czyButton--height28": "MobileGameActions_czyButton--height28__sdOBp",
          "czyButton--fullWidth":
            "MobileGameActions_czyButton--fullWidth__xm6yX",
          "czyButton--headerIcon":
            "MobileGameActions_czyButton--headerIcon__TH5hg",
          "czyButton--headerIcon--desktop":
            "MobileGameActions_czyButton--headerIcon--desktop__COUhn",
          "czyButton--headerIcon--mobile":
            "MobileGameActions_czyButton--headerIcon--mobile__ht7p4",
          "czyButton--headerIcon--withLabel":
            "MobileGameActions_czyButton--headerIcon--withLabel__8UHOd",
          actionsContainer: "MobileGameActions_actionsContainer__QJn8I",
          noVotingButtons: "MobileGameActions_noVotingButtons__Oh7zr",
          voteButtonsContainer: "MobileGameActions_voteButtonsContainer__2Ijdh",
          gameActionsButton: "MobileGameActions_gameActionsButton__yMf3j",
          isClicked: "MobileGameActions_isClicked__5KsL3",
          label: "MobileGameActions_label__TPl1T",
          like: "MobileGameActions_like__yJnZt",
          dislike: "MobileGameActions_dislike__W421J",
          isFeedback: "MobileGameActions_isFeedback__Ay_0J",
          isDownloaded: "MobileGameActions_isDownloaded__kdzsN",
          isPending: "MobileGameActions_isPending__jm13i",
          isFailed: "MobileGameActions_isFailed__V0yHc",
          isHighlighted: "MobileGameActions_isHighlighted__tkDmE",
          offlineDownloadProgress:
            "MobileGameActions_offlineDownloadProgress__pvV3k",
          offlineDownloadHint: "MobileGameActions_offlineDownloadHint__T_W51",
          offlineDownloadConfirmation:
            "MobileGameActions_offlineDownloadConfirmation__LjMzY",
          thumbDownIcon: "MobileGameActions_thumbDownIcon__5uMwh",
          thumbUpIcon: "MobileGameActions_thumbUpIcon__kfYXN",
          gameFooterLinkButton: "MobileGameActions_gameFooterLinkButton__o1bW9",
          feedbackLabel: "MobileGameActions_feedbackLabel__5942Q",
          favouriteWrapper: "MobileGameActions_favouriteWrapper__c9LZ2",
          addToHomescreenPopup: "MobileGameActions_addToHomescreenPopup__8Xoel",
          addToHomescreenTitle: "MobileGameActions_addToHomescreenTitle__JhyYb",
          addToHomescreenSubtitle:
            "MobileGameActions_addToHomescreenSubtitle__XmA_K",
          addToHomescreenClose: "MobileGameActions_addToHomescreenClose__sySOl",
          favouriteBookmark: "MobileGameActions_favouriteBookmark__7x7f3",
          isStaticFavourite: "MobileGameActions_isStaticFavourite__fKBvi",
          rest: "MobileGameActions_rest__Xn5gW",
          bubble: "MobileGameActions_bubble__xeqbb",
          sparkles: "MobileGameActions_sparkles__OnIXJ",
        };
      },
      15383: (e, t, n) => {
        "use strict";
        n.d(t, { k: () => u });
        var o = n(75155),
          a = n(55729),
          i = n(98417),
          r = n(71684),
          c = n(4230),
          l = n(50293);
        let s = new Map();
        function u(e) {
          let t,
            n,
            u,
            _,
            m,
            y = (0, o.c)(11),
            g = (0, a.useContext)(c.A),
            { api: h } = (0, a.useContext)(r.A).services;
          y[0] !== g
            ? ((t = (0, l.Dw)(g)), (y[0] = g), (y[1] = t))
            : (t = y[1]);
          let p = t;
          y[2] === Symbol.for("react.memo_cache_sentinel")
            ? ((n = []), (y[2] = n))
            : (n = y[2]);
          let [B, z] = (0, a.useState)(n),
            [f, b] = (0, a.useState)(e),
            [v, w] = (0, a.useState)(e);
          return (
            e !== v && (w(e), b(e)),
            y[3] !== h || y[4] !== p || y[5] !== e
              ? ((u = () => {
                  if (!e) return;
                  let t = !1,
                    n = s.get(p),
                    o =
                      (0, i.O)(n) && Date.now() - n.fetchedAt < 36e5
                        ? n.request
                        : void 0;
                  return (
                    (0, i.O)(o) ||
                      ((o = h
                        .getBasicLaunchGames(p)
                        .then(d)
                        .catch((e) => {
                          throw (s.delete(p), e);
                        })),
                      s.set(p, { fetchedAt: Date.now(), request: o })),
                    o
                      .then((e) => {
                        t || (z(e), b(!1));
                      })
                      .catch(() => {
                        t || (z([]), b(!1));
                      }),
                    () => {
                      t = !0;
                    }
                  );
                }),
                (_ = [e, p, h]),
                (y[3] = h),
                (y[4] = p),
                (y[5] = e),
                (y[6] = u),
                (y[7] = _))
              : ((u = y[6]), (_ = y[7])),
            (0, a.useEffect)(u, _),
            y[8] !== B || y[9] !== f
              ? ((m = { games: B, isLoading: f }),
                (y[8] = B),
                (y[9] = f),
                (y[10] = m))
              : (m = y[10]),
            m
          );
        }
        function d(e) {
          return e.games.items;
        }
      },
      15742: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => G });
        var o = n(6029),
          a = n(75155),
          i = n(55729),
          r = n(50293),
          c = n(4230),
          l = n(96991),
          s = n(16661),
          u = n(90258),
          d = n(79942),
          _ = n(71855),
          m = n(46571),
          y = n(74198),
          g = n(71024),
          h = n.n(g),
          p = n(81278),
          B = n(71684),
          z = n(49188),
          f = n.n(z);
        let b = h()(
            () =>
              Promise.all([n.e(56448), n.e(95271), n.e(93381)]).then(
                n.bind(n, 93381)
              ),
            {
              loadableGenerated: { webpack: () => [93381] },
              loading: () => null,
              ssr: !1,
            }
          ),
          v = (e) => {
            let t,
              n,
              l,
              s,
              u,
              d,
              _,
              m,
              y,
              g,
              h = (0, a.c)(25),
              { game: z } = e,
              { gameService: v } = (0, i.useContext)(B.A).services,
              w = i.useContext(c.A),
              [k, A] = (0, i.useState)(!1),
              [S, x] = (0, i.useState)(!1);
            h[0] === Symbol.for("react.memo_cache_sentinel")
              ? ((t = []), (h[0] = t))
              : (t = h[0]);
            let [I, N] = (0, i.useState)(t);
            h[1] === Symbol.for("react.memo_cache_sentinel")
              ? ((n = {}), (h[1] = n))
              : (n = h[1]);
            let [G, C] = (0, i.useState)(n),
              [T, P] = i.useState(!1);
            h[2] === Symbol.for("react.memo_cache_sentinel")
              ? ((l = () => {
                  let e = () => P(!1);
                  return (
                    p.Router.events.on("routeChangeStart", e),
                    function () {
                      p.Router.events.off("routeChangeStart", e);
                    }
                  );
                }),
                (s = []),
                (h[2] = l),
                (h[3] = s))
              : ((l = h[2]), (s = h[3])),
              i.useEffect(l, s),
              h[4] !== w || h[5] !== z.developerId || h[6] !== v
                ? ((u = async () => {
                    if (!z.developerId) return;
                    x(!0);
                    let { games: e, publicProfile: t } = await v.developerData(
                      z.developerId,
                      (0, r.Dw)(w)
                    );
                    x(!1), A(!0), N(e), C(t);
                  }),
                  (h[4] = w),
                  (h[5] = z.developerId),
                  (h[6] = v),
                  (h[7] = u))
                : (u = h[7]);
            let j = u;
            h[8] !== j || h[9] !== S || h[10] !== k
              ? ((d = () => {
                  P(!0), k || S || j();
                }),
                (h[8] = j),
                (h[9] = S),
                (h[10] = k),
                (h[11] = d))
              : (d = h[11]);
            let L = d;
            h[12] === Symbol.for("react.memo_cache_sentinel")
              ? ((_ = () => P(!1)), (h[12] = _))
              : (_ = h[12]);
            let F = _;
            return z.developerId
              ? (h[13] !== z.developer || h[14] !== L
                  ? ((m = (0, o.jsx)("div", {
                      className: f().styledDevName,
                      onClick: L,
                      "data-testid": "game-dev-info",
                      children: z.developer,
                    })),
                    (h[13] = z.developer),
                    (h[14] = L),
                    (h[15] = m))
                  : (m = h[15]),
                h[16] !== I ||
                h[17] !== z.developer ||
                h[18] !== S ||
                h[19] !== G ||
                h[20] !== T
                  ? ((y =
                      T &&
                      (0, o.jsx)(b, {
                        gamesIsLoading: S,
                        games: I,
                        developerName: z.developer || "Game developer",
                        publicProfile: G,
                        onClose: F,
                      })),
                    (h[16] = I),
                    (h[17] = z.developer),
                    (h[18] = S),
                    (h[19] = G),
                    (h[20] = T),
                    (h[21] = y))
                  : (y = h[21]),
                h[22] !== m || h[23] !== y
                  ? ((g = (0, o.jsxs)("div", { children: [m, y] })),
                    (h[22] = m),
                    (h[23] = y),
                    (h[24] = g))
                  : (g = h[24]),
                g)
              : null;
          };
        var w = n(56729),
          k = n.n(w);
        let A = (e) => {
          let t,
            n,
            i,
            r,
            c,
            l = (0, a.c)(13),
            { rating: s, totalVotes: u } = e,
            { i18n: _ } = (0, d.uB)();
          l[0] !== _ || l[1] !== s
            ? ((t = (0, m.A)(_, s, { minimumFractionDigits: 1 })),
              (l[0] = _),
              (l[1] = s),
              (l[2] = t))
            : (t = l[2]);
          let y = t;
          return (
            l[3] !== y
              ? ((n = (0, o.jsx)("span", {
                  className: k().rating,
                  children: y,
                })),
                (l[3] = y),
                (l[4] = n))
              : (n = l[4]),
            l[5] !== _ || l[6] !== u
              ? ((i = _._("game.totalVotes", { count: u })),
                (l[5] = _),
                (l[6] = u),
                (l[7] = i))
              : (i = l[7]),
            l[8] !== i
              ? ((r = (0, o.jsx)("span", {
                  className: k().totalVotes,
                  children: i,
                })),
                (l[8] = i),
                (l[9] = r))
              : (r = l[9]),
            l[10] !== n || l[11] !== r
              ? ((c = (0, o.jsxs)("div", {
                  className: k().gameRating,
                  children: [n, r],
                })),
                (l[10] = n),
                (l[11] = r),
                (l[12] = c))
              : (c = l[12]),
            c
          );
        };
        var S = n(92995),
          x = n.n(S);
        let I = (e) => {
          let t,
            n,
            r,
            c = (0, a.c)(67),
            { game: l } = e,
            { locale: s } = i.useContext(y.A),
            { i18n: u } = (0, d.uB)(),
            g = "enabled" === (0, _.U)("czyExpHideVotesDetail");
          if (
            c[0] !== l.androidAppFriendly ||
            c[1] !== l.androidFriendly ||
            c[2] !== l.appStoreUrl ||
            c[3] !== l.iosAppFriendly ||
            c[4] !== l.iosFriendly ||
            c[5] !== l.msnStoreUrl ||
            c[6] !== l.playStoreUrl ||
            c[7] !== l.steamStoreUrl ||
            c[8] !== u
          ) {
            if (((t = []), l.iosFriendly || l.androidFriendly)) {
              let e;
              c[10] !== u
                ? ((e = u._({ id: "game.platform.browser.all" })),
                  (c[10] = u),
                  (c[11] = e))
                : (e = c[11]),
                t.push(e);
            } else {
              let e;
              c[12] !== u
                ? ((e = u._({ id: "game.platform.browser.desktop" })),
                  (c[12] = u),
                  (c[13] = e))
                : (e = c[13]),
                t.push(e);
            }
            if (l.iosAppFriendly || l.androidAppFriendly) {
              let e, n;
              c[14] !== l.androidAppFriendly || c[15] !== l.iosAppFriendly
                ? ((e = []),
                  l.iosAppFriendly && e.push("iOS"),
                  l.androidAppFriendly && e.push("Android"),
                  (c[14] = l.androidAppFriendly),
                  (c[15] = l.iosAppFriendly),
                  (c[16] = e))
                : (e = c[16]),
                c[17] !== e || c[18] !== u
                  ? ((n = u._("game.platform.crazyGamesApp", {
                      platforms: e.join(", "),
                    })),
                    (c[17] = e),
                    (c[18] = u),
                    (c[19] = n))
                  : (n = c[19]),
                t.push(n);
            }
            if (l.appStoreUrl || l.playStoreUrl || l.msnStoreUrl) {
              let e;
              c[20] !== l.appStoreUrl ||
              c[21] !== l.msnStoreUrl ||
              c[22] !== l.playStoreUrl
                ? ((e = []),
                  l.appStoreUrl && e.push("iOS"),
                  l.playStoreUrl && e.push("Android"),
                  l.msnStoreUrl && e.push("MSN"),
                  (c[20] = l.appStoreUrl),
                  (c[21] = l.msnStoreUrl),
                  (c[22] = l.playStoreUrl),
                  (c[23] = e))
                : (e = c[23]),
                t.push(`App Store (${e.join(", ")})`);
            }
            l.steamStoreUrl && t.push("Steam"),
              (c[0] = l.androidAppFriendly),
              (c[1] = l.androidFriendly),
              (c[2] = l.appStoreUrl),
              (c[3] = l.iosAppFriendly),
              (c[4] = l.iosFriendly),
              (c[5] = l.msnStoreUrl),
              (c[6] = l.playStoreUrl),
              (c[7] = l.steamStoreUrl),
              (c[8] = u),
              (c[9] = t);
          } else t = c[9];
          if (
            c[24] !== l ||
            c[25] !== g ||
            c[26] !== u ||
            c[27] !== s ||
            c[28] !== t
          ) {
            let e,
              a,
              i,
              r,
              _,
              y,
              h,
              p,
              B,
              z,
              f,
              b,
              w,
              k = new Intl.DateTimeFormat(s, {
                year: "numeric",
                month: "long",
              }),
              S = null;
            l.addedOn && (S = k.format(new Date(l.addedOn)));
            let I = null;
            !l.addedOn &&
              l.basicLaunchOn &&
              (I = k.format(new Date(l.basicLaunchOn)));
            let N = null;
            l.lastFileUpdatedOn &&
              (N = k.format(new Date(l.lastFileUpdatedOn))),
              c[30] !== l.upvotes || c[31] !== u
                ? ((e = (0, m.A)(u, l.upvotes, { notation: "compact" })),
                  (c[30] = l.upvotes),
                  (c[31] = u),
                  (c[32] = e))
                : (e = c[32]);
            let G = e;
            c[33] !== l.downvotes || c[34] !== u
              ? ((a = (0, m.A)(u, l.downvotes, { notation: "compact" })),
                (c[33] = l.downvotes),
                (c[34] = u),
                (c[35] = a))
              : (a = c[35]);
            let C = a,
              T = l.upvotes + l.downvotes;
            if (
              (c[36] === Symbol.for("react.memo_cache_sentinel")
                ? ((i = (0, o.jsx)(d.x6, { id: "game.developer" })),
                  (c[36] = i))
                : (i = c[36]),
              c[37] !== l
                ? ((r =
                    l.developerId && l.developer
                      ? (0, o.jsx)(v, { game: l })
                      : null),
                  (c[37] = l),
                  (c[38] = r))
                : (r = c[38]),
              c[39] === Symbol.for("react.memo_cache_sentinel")
                ? ((_ = (0, o.jsx)(d.x6, { id: "game.rating" })), (c[39] = _))
                : (_ = c[39]),
              c[40] !== l.rating || c[41] !== T
                ? ((y = (0, o.jsx)(A, { rating: l.rating, totalVotes: T })),
                  (c[40] = l.rating),
                  (c[41] = T),
                  (c[42] = y))
                : (y = c[42]),
              c[43] === Symbol.for("react.memo_cache_sentinel")
                ? ((h = (0, o.jsx)(d.x6, { id: "game.votes" })), (c[43] = h))
                : (h = c[43]),
              c[44] !== C || c[45] !== g || c[46] !== G
                ? ((p = g
                    ? null
                    : (0, o.jsx)(d.x6, {
                        id: "game.votes.cast",
                        values: { likes: G, dislikes: C },
                      })),
                  (c[44] = C),
                  (c[45] = g),
                  (c[46] = G),
                  (c[47] = p))
                : (p = c[47]),
              c[48] === Symbol.for("react.memo_cache_sentinel")
                ? ((B = (0, o.jsx)(d.x6, { id: "game.released" })), (c[48] = B))
                : (B = c[48]),
              c[49] === Symbol.for("react.memo_cache_sentinel")
                ? ((z = (0, o.jsx)(d.x6, { id: "game.lastUpdated" })),
                  (c[49] = z))
                : (z = c[49]),
              c[50] === Symbol.for("react.memo_cache_sentinel")
                ? ((f = (0, o.jsx)(d.x6, { id: "game.gameEngine" })),
                  (c[50] = f))
                : (f = c[50]),
              c[51] !== t.length
                ? ((b =
                    1 === t.length
                      ? (0, o.jsx)(d.x6, { id: "game.platform" })
                      : (0, o.jsx)(d.x6, { id: "game.platforms" })),
                  (c[51] = t.length),
                  (c[52] = b))
                : (b = c[52]),
              (n = [
                { label: i, content: r },
                { label: _, content: y },
                { label: h, content: p },
                {
                  label: B,
                  content:
                    "BASIC_LAUNCH" === l.status
                      ? (0, o.jsxs)(o.Fragment, {
                          children: [
                            I,
                            " (",
                            (0, o.jsx)(d.x6, { id: "game.prerelease" }),
                            ")",
                          ],
                        })
                      : S,
                },
                { label: z, content: N },
                {
                  label: f,
                  content: l.loaderTypeLabel ? l.loaderTypeLabel : l.loaderType,
                },
                { label: b, content: t.join(", ") },
              ]),
              l.orientation)
            ) {
              let e;
              c[53] === Symbol.for("react.memo_cache_sentinel")
                ? ((e = (0, o.jsx)(d.x6, { id: "game.orientation" })),
                  (c[53] = e))
                : (e = c[53]),
                n.push({
                  label: e,
                  content: (function (e) {
                    switch (e) {
                      case "PORTRAIT":
                        return (0, o.jsx)(d.x6, {
                          id: "game.orientation.portrait",
                        });
                      case "LANDSCAPE":
                        return (0, o.jsx)(d.x6, {
                          id: "game.orientation.landscape",
                        });
                      case "BOTH":
                        return (0, o.jsx)(d.x6, {
                          id: "game.orientation.both",
                        });
                    }
                  })(l.orientation),
                });
            }
            if (
              l.externalLinks &&
              (l.externalLinks.wikipedia || l.externalLinks.fandom)
            ) {
              let e, t, a, i;
              c[54] === Symbol.for("react.memo_cache_sentinel")
                ? ((e = (0, o.jsx)(d.x6, { id: "game.wikipages" })),
                  (c[54] = e))
                : (e = c[54]),
                c[55] !== l.externalLinks?.wikipedia
                  ? ((t = l.externalLinks?.wikipedia
                      ? (0, o.jsx)("a", {
                          href: l.externalLinks?.wikipedia,
                          target: "_blank",
                          children: "Wikipedia",
                        })
                      : ""),
                    (c[55] = l.externalLinks?.wikipedia),
                    (c[56] = t))
                  : (t = c[56]);
              let r =
                l.externalLinks?.wikipedia && l.externalLinks?.fandom
                  ? " - "
                  : "";
              c[57] !== l.externalLinks?.fandom
                ? ((a = l.externalLinks?.fandom
                    ? (0, o.jsx)("a", {
                        href: l.externalLinks?.fandom,
                        target: "_blank",
                        children: "Fandom",
                      })
                    : ""),
                  (c[57] = l.externalLinks?.fandom),
                  (c[58] = a))
                : (a = c[58]),
                c[59] !== t || c[60] !== r || c[61] !== a
                  ? ((i = (0, o.jsxs)("div", {
                      className: x().wikiLinks,
                      children: [t, r, a],
                    })),
                    (c[59] = t),
                    (c[60] = r),
                    (c[61] = a),
                    (c[62] = i))
                  : (i = c[62]),
                n.push({ label: e, content: i });
            }
            c[63] !== l.customFields
              ? ((w = l.customFields || {}),
                (c[63] = l.customFields),
                (c[64] = w))
              : (w = c[64]);
            let P = w;
            Object.keys(P).forEach((e) => {
              P[e] &&
                n.push({
                  label: (0, o.jsx)("span", { children: e }),
                  content: (0, o.jsx)("span", {
                    dangerouslySetInnerHTML: { __html: P[e] },
                  }),
                });
            }),
              (c[24] = l),
              (c[25] = g),
              (c[26] = u),
              (c[27] = s),
              (c[28] = t),
              (c[29] = n);
          } else n = c[29];
          return (
            c[65] !== n
              ? ((r = (0, o.jsx)("dl", {
                  className: x().gameSummaryTable,
                  children: n.map(N),
                })),
                (c[65] = n),
                (c[66] = r))
              : (r = c[66]),
            r
          );
        };
        function N(e, t) {
          return e.content
            ? (0, o.jsxs)(
                i.Fragment,
                {
                  children: [
                    (0, o.jsx)("dt", {
                      className: x().gameTableRowHeader,
                      children: e.label,
                    }),
                    (0, o.jsx)("dd", {
                      className: x().gameTableRowContent,
                      children: e.content,
                    }),
                  ],
                },
                t
              )
            : null;
        }
        let G = (e) => {
          let t,
            n,
            d,
            _,
            m,
            y,
            g = (0, a.c)(17),
            { game: h } = e,
            p = i.useContext(c.A);
          g[0] !== h ? ((t = { game: h }), (g[0] = h), (g[1] = t)) : (t = g[1]),
            (0, s.b)(t);
          let { name: B } = h;
          return (
            g[2] !== h.hierarchy || g[3] !== B
              ? ((n = (0, o.jsx)(l.A, {
                  hierarchy: h.hierarchy,
                  currentLabel: B,
                  className: f().breadcrumbs,
                  dataTestId: "breadcrumbs",
                })),
                (g[2] = h.hierarchy),
                (g[3] = B),
                (g[4] = n))
              : (n = g[4]),
            g[5] !== B
              ? ((d = (0, o.jsx)("h1", { className: f().title, children: B })),
                (g[5] = B),
                (g[6] = d))
              : (d = g[6]),
            g[7] !== p || g[8] !== h
              ? ((_ =
                  (0, r.xl)(p) &&
                  (0, o.jsx)("div", {
                    className: f().gameUnderTitle,
                    children: (0, o.jsx)(u.A, { game: h }),
                  })),
                (g[7] = p),
                (g[8] = h),
                (g[9] = _))
              : (_ = g[9]),
            g[10] !== h
              ? ((m = (0, o.jsx)(I, { game: h })), (g[10] = h), (g[11] = m))
              : (m = g[11]),
            g[12] !== n || g[13] !== d || g[14] !== _ || g[15] !== m
              ? ((y = (0, o.jsxs)(o.Fragment, { children: [n, d, _, m] })),
                (g[12] = n),
                (g[13] = d),
                (g[14] = _),
                (g[15] = m),
                (g[16] = y))
              : (y = g[16]),
            y
          );
        };
      },
      16316: (e, t, n) => {
        "use strict";
        function o(e) {
          let t = e.allowWebCam || e.isPreview ? "camera;" : "";
          return `autoplay; payment; fullscreen; microphone; focus-without-user-activation *; screen-wake-lock; gamepad; clipboard-read; clipboard-write; accelerometer; gyroscope; keyboard-map; ${t}`;
        }
        n.d(t, { e: () => o });
      },
      16472: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => G });
        var o = n(6029),
          a = n(75155),
          i = n(55729),
          r = n(77650),
          c = n(79942),
          l = n(98542),
          s = n(50212),
          u = n(93800),
          d = n(68006),
          _ = n(9008),
          m = n.n(_);
        let y = (e) => {
          let t,
            n,
            i,
            r,
            c,
            l,
            _,
            y,
            g = (0, a.c)(25),
            {
              anchorEl: h,
              open: p,
              placement: B,
              media: z,
              title: f,
              body: b,
              ariaLabel: v,
              closeLabel: w,
              onClick: k,
              onClose: A,
            } = e,
            S = k && m().clickable;
          return (
            g[0] !== S
              ? ((t = (0, s.A)(m().nudge, S)), (g[0] = S), (g[1] = t))
              : (t = g[1]),
            g[2] !== f
              ? ((n = (0, o.jsx)("div", { className: m().title, children: f })),
                (g[2] = f),
                (g[3] = n))
              : (n = g[3]),
            g[4] !== b
              ? ((i = (0, o.jsx)("div", { className: m().body, children: b })),
                (g[4] = b),
                (g[5] = i))
              : (i = g[5]),
            g[6] !== n || g[7] !== i
              ? ((r = (0, o.jsxs)("div", {
                  className: m().content,
                  children: [n, i],
                })),
                (g[6] = n),
                (g[7] = i),
                (g[8] = r))
              : (r = g[8]),
            g[9] !== A
              ? ((c = (e) => {
                  e.stopPropagation(), A();
                }),
                (g[9] = A),
                (g[10] = c))
              : (c = g[10]),
            g[11] === Symbol.for("react.memo_cache_sentinel")
              ? ((l = (0, o.jsx)(u.A, { name: "close" })), (g[11] = l))
              : (l = g[11]),
            g[12] !== w || g[13] !== c
              ? ((_ = (0, o.jsx)("button", {
                  type: "button",
                  className: m().close,
                  "aria-label": w,
                  onClick: c,
                  children: l,
                })),
                (g[12] = w),
                (g[13] = c),
                (g[14] = _))
              : (_ = g[14]),
            g[15] !== h ||
            g[16] !== v ||
            g[17] !== z ||
            g[18] !== k ||
            g[19] !== p ||
            g[20] !== B ||
            g[21] !== t ||
            g[22] !== r ||
            g[23] !== _
              ? ((y = (0, o.jsxs)(d.A, {
                  anchorEl: h,
                  open: p,
                  placement: B,
                  className: t,
                  role: "dialog",
                  "aria-label": v,
                  onClick: k,
                  children: [z, r, _],
                })),
                (g[15] = h),
                (g[16] = v),
                (g[17] = z),
                (g[18] = k),
                (g[19] = p),
                (g[20] = B),
                (g[21] = t),
                (g[22] = r),
                (g[23] = _),
                (g[24] = y))
              : (y = g[24]),
            y
          );
        };
        var g = n(94618);
        let h = (e) => {
          let t,
            n,
            i = (0, a.c)(3),
            { className: r } = e;
          return (
            i[0] === Symbol.for("react.memo_cache_sentinel")
              ? ((t = (0, g.Ay)("progress-save-nudge-badge.svg", {}, !1)),
                (i[0] = t))
              : (t = i[0]),
            i[1] !== r
              ? ((n = (0, o.jsx)("img", {
                  className: r,
                  src: t,
                  width: 32,
                  height: 32,
                  alt: "",
                })),
                (i[1] = r),
                (i[2] = n))
              : (n = i[2]),
            n
          );
        };
        var p = n(14886),
          B = n(4230),
          z = n(50293),
          f = n(45364),
          b = n(1584),
          v = n(6958),
          w = n(34283),
          k = n(71684);
        let A = n(28478).A.LocalStorage,
          S = "czy_progress_save_nudge_dismiss_at",
          x = "progress-save-nudge";
        var I = n(40705),
          N = n.n(I);
        let G = (e) => {
          let t,
            n,
            s,
            u,
            d,
            _,
            m,
            g,
            I = (0, a.c)(16),
            { game: G } = e,
            {
              open: C,
              anchorEl: T,
              placement: P,
              onDismiss: j,
              onLoginClick: L,
            } = (function (e) {
              let { user: t } = i.useContext(p.R),
                n = i.useContext(B.A),
                { mountedTime: o } = i.useContext(b.T),
                { crazyAnalyticsService: a } = i.useContext(k.A).services,
                r = (0, z.xl)(n),
                c = !t && "cloud" === e.userProgressionSaveMessage,
                [l, s] = i.useState(!1),
                [u, d] = i.useState(null),
                [_, m] = i.useState("bottom"),
                y = i.useRef({
                  eligible: c,
                  desktop: r,
                  mountedTime: o,
                  hasShown: !1,
                }),
                g = i.useRef(e.id);
              i.useEffect(() => {
                g.current !== e.id &&
                  ((g.current = e.id), (y.current.hasShown = !1), s(!1)),
                  (y.current.eligible = c),
                  (y.current.desktop = r),
                  (y.current.mountedTime = o);
              }, [c, r, o, e.id]);
              let h = i.useCallback(() => {
                  if (y.current.desktop) {
                    let e = document.getElementById(w.F);
                    return e ? { el: e, placement: "bottom" } : null;
                  }
                  let e = document.getElementById(v.Xz);
                  if (e) return { el: e, placement: "top" };
                  let t = document.getElementById(w.F);
                  return t ? { el: t, placement: "bottom" } : null;
                }, []),
                I = i.useCallback(
                  () =>
                    y.current.mountedTime
                      ? Date.now() - y.current.mountedTime
                      : 0,
                  []
                ),
                N = i.useCallback(() => {
                  var e;
                  let t,
                    n,
                    o = y.current;
                  if (
                    !o.eligible ||
                    o.hasShown ||
                    ((e = Date.now()),
                    (null !==
                      (n = Number.isFinite(
                        (t = parseInt(A.getItem(S) || "", 10))
                      )
                        ? t
                        : null) &&
                      e - n < 2592e5) ||
                      18e4 > I())
                  )
                    return;
                  let i = h();
                  i &&
                    ((o.hasShown = !0),
                    d(i.el),
                    m(i.placement),
                    s(!0),
                    a.notificationActionEvent(x, "shown"));
                }, [a, h, I]),
                [G, C] = i.useState(t);
              t !== G && (C(t), t && s(!1)),
                i.useEffect(() => {
                  if (!u) return;
                  let e = () => s(!1);
                  return (
                    u.addEventListener("click", e),
                    () => u.removeEventListener("click", e)
                  );
                }, [u]),
                i.useEffect(() => {
                  let e;
                  if (!c) return;
                  let t = () => {
                    f.A.isFullscreen() || f.A.isFakeFullscreen() || N();
                  };
                  if (
                    (f.A.addFullscreenListener(t),
                    f.A.addFakeFullscreenListener(t),
                    r)
                  ) {
                    let t = Math.max(0, 18e4 - I());
                    e = window.setTimeout(() => {
                      f.A.isFullscreen() || f.A.isFakeFullscreen() || N();
                    }, t);
                  }
                  return () => {
                    f.A.removeFullscreenListener(t),
                      f.A.removeFakeFullscreenListener(t),
                      void 0 !== e && window.clearTimeout(e);
                  };
                }, [c, r, o, N, I]);
              let T = i.useCallback(() => {
                  var e;
                  (e = Date.now()),
                    A.setItem(S, String(e)),
                    a.notificationActionEvent(x, "ignored"),
                    s(!1);
                }, [a]),
                P = i.useCallback(() => {
                  a.notificationActionEvent(x, "clicked"), u?.click(), s(!1);
                }, [u, a]);
              return {
                open: l && c,
                anchorEl: u,
                placement: _,
                onDismiss: T,
                onLoginClick: P,
              };
            })(G);
          return (
            I[0] !== G
              ? ((t =
                  G.cover &&
                  (0, o.jsx)(l.A, {
                    game: G,
                    width: 64,
                    height: 64,
                    greyedOut: !1,
                    staticLayout: !0,
                    forceAspectRatio: "square",
                    eagerLoading: !0,
                    className: N().thumb,
                  })),
                (I[0] = G),
                (I[1] = t))
              : (t = I[1]),
            I[2] === Symbol.for("react.memo_cache_sentinel")
              ? ((n = (0, o.jsx)(h, { className: N().badge })), (I[2] = n))
              : (n = I[2]),
            I[3] !== t
              ? ((s = (0, o.jsxs)("div", {
                  className: N().thumbWrap,
                  children: [t, n],
                })),
                (I[3] = t),
                (I[4] = s))
              : (s = I[4]),
            I[5] === Symbol.for("react.memo_cache_sentinel")
              ? ((u = (0, o.jsx)(c.x6, { id: "game.progressNudge.title" })),
                (d = (0, o.jsxs)(o.Fragment, {
                  children: [
                    (0, o.jsx)(c.x6, { id: "game.progressNudge.body1" }),
                    (0, o.jsx)("br", {}),
                    (0, o.jsx)(c.x6, { id: "game.progressNudge.body2" }),
                  ],
                })),
                (_ = r.Ru._("game.progressNudge.title")),
                (m = r.Ru._("game.progressNudge.close")),
                (I[5] = u),
                (I[6] = d),
                (I[7] = _),
                (I[8] = m))
              : ((u = I[5]), (d = I[6]), (_ = I[7]), (m = I[8])),
            I[9] !== T ||
            I[10] !== j ||
            I[11] !== L ||
            I[12] !== C ||
            I[13] !== P ||
            I[14] !== s
              ? ((g = (0, o.jsx)(y, {
                  anchorEl: T,
                  open: C,
                  placement: P,
                  media: s,
                  title: u,
                  body: d,
                  ariaLabel: _,
                  closeLabel: m,
                  onClick: L,
                  onClose: j,
                })),
                (I[9] = T),
                (I[10] = j),
                (I[11] = L),
                (I[12] = C),
                (I[13] = P),
                (I[14] = s),
                (I[15] = g))
              : (g = I[15]),
            g
          );
        };
      },
      16661: (e, t, n) => {
        "use strict";
        n.d(t, { b: () => g });
        var o = n(75155),
          a = n(55729),
          i = n(89964),
          r = n(57784),
          c = n(14886),
          l = n(8026),
          s = n(93389),
          u = n(43038),
          d = n(71237),
          _ = n(4230),
          m = n(28478),
          y = n(71684);
        function g(e) {
          let t,
            n,
            g,
            h,
            p,
            B,
            z,
            f,
            b,
            v,
            w = (0, o.c)(46),
            { game: k, onVote: A, setDislikeFeedbackEnabled: S } = e,
            { routeHelper: x } = (0, a.useContext)(s.A),
            { services: I } = (0, a.useContext)(y.A),
            N = a.useContext(_.A),
            { user: G } = (0, a.useContext)(c.R);
          w[0] !== k.slug
            ? ((t = (0, u.OC)(k.slug)), (w[0] = k.slug), (w[1] = t))
            : (t = w[1]);
          let C = t,
            { updateVote: T } = d.XI(),
            P = d.BJ(),
            j = d.tO(),
            { vote: L, loading: F } = (0, l.Z)(k),
            [M, E] = (0, a.useState)(r.i.CANCEL);
          w[2] !== C || w[3] !== G
            ? ((n = (e) => {
                if (!G) {
                  let t = m.A.LocalStorage;
                  e === r.i.CANCEL ? t.removeItem(C) : t.setItem(C, `${e}`);
                }
              }),
              (w[2] = C),
              (w[3] = G),
              (w[4] = n))
            : (n = w[4]);
          let O = n;
          w[5] !== N ||
          w[6] !== k.id ||
          w[7] !== A ||
          w[8] !== O ||
          w[9] !== I ||
          w[10] !== S
            ? ((g = async (e) => {
                O(e),
                  I.crazyAnalyticsService.gameVote(e),
                  E(e),
                  S && S(e === r.i.NEGATIVE),
                  A && A(e);
                try {
                  await I.gameService.voteById(k.id, e, N);
                } catch (e) {
                  console.error("[GameContainerTools] error while voting", e);
                }
              }),
              (w[5] = N),
              (w[6] = k.id),
              (w[7] = A),
              (w[8] = O),
              (w[9] = I),
              (w[10] = S),
              (w[11] = g))
            : (g = w[11]);
          let D = g;
          w[12] !== P || w[13] !== k || w[14] !== D
            ? ((h = async () => {
                try {
                  await P({
                    ...k,
                    iosFriendly: !0,
                    androidFriendly: !0,
                    gameThumbLabels: [],
                    playedTime: null,
                  });
                } catch (e) {
                  console.error("[UserLiked] error while adding to liked", e);
                }
                await D(r.i.POSITIVE);
              }),
              (w[12] = P),
              (w[13] = k),
              (w[14] = D),
              (w[15] = h))
            : (h = w[15]);
          let U = h;
          w[16] !== k || w[17] !== T || w[18] !== D
            ? ((p = async () => {
                await Promise.allSettled([T(k, r.i.NEGATIVE), D(r.i.NEGATIVE)]);
              }),
              (w[16] = k),
              (w[17] = T),
              (w[18] = D),
              (w[19] = p))
            : (p = w[19]);
          let R = p;
          w[20] !== k || w[21] !== j || w[22] !== T || w[23] !== D
            ? ((B = async () => {
                try {
                  await j(k.id);
                } catch (e) {
                  console.error(
                    "[UserLiked] error while removing from liked",
                    e
                  );
                }
                T(k, r.i.CANCEL), D(r.i.CANCEL);
              }),
              (w[20] = k),
              (w[21] = j),
              (w[22] = T),
              (w[23] = D),
              (w[24] = B))
            : (B = w[24]);
          let W = B;
          w[25] !== L || w[26] !== F
            ? ((z = { serverVote: L, serverVoteLoading: F }),
              (w[25] = L),
              (w[26] = F),
              (w[27] = z))
            : (z = w[27]);
          let [H, q] = (0, a.useState)(z);
          return (
            (H.serverVote !== L || H.serverVoteLoading !== F) &&
              (q({ serverVote: L, serverVoteLoading: F }), F || E(L)),
            w[28] !== R ||
            w[29] !== k.desktopUrl ||
            w[30] !== W ||
            w[31] !== x ||
            w[32] !== U
              ? ((f = () => {
                  let e = (e) => {
                    if (
                      e.data &&
                      e.data.type === i.x &&
                      x.isMessageFromGameframe(e, k.desktopUrl)
                    )
                      switch (e.data.event) {
                        case "like":
                          U();
                          break;
                        case "dislike":
                          R();
                          break;
                        case "neutral":
                          W();
                      }
                  };
                  return (
                    window.addEventListener("message", e),
                    () => window.removeEventListener("message", e)
                  );
                }),
                (w[28] = R),
                (w[29] = k.desktopUrl),
                (w[30] = W),
                (w[31] = x),
                (w[32] = U),
                (w[33] = f))
              : (f = w[33]),
            w[34] !== R ||
            w[35] !== k ||
            w[36] !== W ||
            w[37] !== x ||
            w[38] !== U
              ? ((b = [k, x, U, R, W]),
                (w[34] = R),
                (w[35] = k),
                (w[36] = W),
                (w[37] = x),
                (w[38] = U),
                (w[39] = b))
              : (b = w[39]),
            (0, a.useEffect)(f, b),
            w[40] !== R ||
            w[41] !== W ||
            w[42] !== F ||
            w[43] !== U ||
            w[44] !== M
              ? ((v = {
                  upVote: U,
                  downVote: R,
                  neutralVote: W,
                  vote: M,
                  loading: F,
                }),
                (w[40] = R),
                (w[41] = W),
                (w[42] = F),
                (w[43] = U),
                (w[44] = M),
                (w[45] = v))
              : (v = w[45]),
            v
          );
        }
      },
      24542: (e) => {
        e.exports = {
          bubble: "AnchoredBubble_bubble__aPpCX",
          shown: "AnchoredBubble_shown__IEOsk",
          pointsUp: "AnchoredBubble_pointsUp__jzLnV",
          pointsDown: "AnchoredBubble_pointsDown__9kM52",
          arrow: "AnchoredBubble_arrow__a0mUP",
        };
      },
      26165: (e, t, n) => {
        "use strict";
        function o(e, t) {
          let n = Array.isArray(e) ? e[0] : e;
          return (
            "true" === n || !0 === n || ("false" !== n && !1 !== n && 1 === t)
          );
        }
        n.d(t, { d: () => o });
      },
      27066: (e, t, n) => {
        "use strict";
        n.d(t, { Z: () => o, _: () => a });
        let o = 440,
          a = 315;
      },
      27096: (e, t, n) => {
        "use strict";
        n.d(t, { j: () => V });
        var o = n(55729),
          a = n(62927),
          i = n(10945),
          r = n(74339),
          c = n(39328),
          l = n(46871),
          s = n(78192),
          u = n(98417),
          d = n(71727),
          _ = n(9690),
          m = n(14886),
          y = n(10614),
          g = n(75681),
          h = n(28478),
          p = n(76097),
          B = n(59517),
          z = n(42191),
          f = n(89722),
          b = n(71855),
          v = n(66050),
          w = n(8026),
          k = n(48431),
          A = n(93389),
          S = n(43038),
          x = n(39481),
          I = n(71237),
          N = n(33165),
          G = n(46996),
          C = n(1584),
          T = n(22463),
          P = n(61827),
          j = n(56341),
          L = n(71684),
          F = n(15325),
          M = n(12423),
          E = n(33052),
          O = n(59701),
          D = n(77257),
          U = n(37288),
          R = n(86381);
        async function W(e, t, n, o, a, i) {
          let r = e.isPreview ?? !1,
            c = e.id,
            l = a.readQuery({
              query: R.B8,
              variables: { gameIds: [e.id], isPreview: e.isPreview ?? !1 },
            }),
            s = l?.me?.currentSeasonScoresForGames?.find(
              (t) => t.gameId === e.id
            ),
            d = s?.score;
          if (
            (0, u.O)(e.leaderboardOptions) &&
            (0, u.O)(n) &&
            (0, u.O)(d) &&
            (0, u.O)(e.leaderboardOptions.isIncremental) &&
            !e.leaderboardOptions.isIncremental
          ) {
            var _;
            let t,
              o = parseFloat(d);
            if (
              ((_ = e.leaderboardOptions.scoreSorting),
              (t =
                Math.abs(o) >= 0x1000000
                  ? 11920928955078125e-23 * Math.abs(o)
                  : 0),
              "DESC" === _ ? n <= o - t : n >= o + t)
            )
              return;
          }
          let m = await a.mutate({
            mutation: U.iV,
            fetchPolicy: "no-cache",
            variables: {
              input: {
                gameId: c,
                encryptedScore: t,
                requestId: o,
                isPreview: r,
              },
            },
            context: { queryDeduplication: !1 },
            refetchQueries: [
              { query: R.B8, variables: { gameIds: [c], isPreview: r } },
              { query: R.pz, variables: { gameId: c } },
            ],
            awaitRefetchQueries: !0,
          });
          if (m.data?.submitScore) {
            let e = a.readQuery({
                query: R.B8,
                variables: { gameIds: [c], isPreview: r },
              }),
              t = e?.me?.currentSeasonScoresForGames?.find(
                (e) => e.gameId === c
              );
            if (t) {
              let e = t.score;
              if (d && d === e) return;
              let n = parseFloat(e);
              i.leaderboardEvent("gamepage", "scoreupdated", {
                score: {
                  value: n,
                  globalRank: t.overallRank,
                  countryRank: t.countryRank,
                  friendsRank: t.friendsRank,
                },
              }),
                (function (e, t, n, o) {
                  let { overallRank: a, score: i, scoreForNextBadge: r } = o;
                  if (!(0, u.O)(a) || ((0, u.O)(n) && a >= n)) return;
                  let c = e.readQuery({
                    query: R.pz,
                    variables: { gameId: t },
                  })?.totalPlayers;
                  c &&
                    (0, D.t)({
                      gameId: t,
                      score: i,
                      oldRank: n,
                      newRank: a,
                      totalPlayers: c,
                      scoreForNextBadge: r,
                    });
                })(a, c, s?.overallRank ?? null, t);
            }
          }
        }
        async function H(e, t, n, o, a) {
          try {
            let i = await a.mutate({
              mutation: U.Pe,
              fetchPolicy: "no-cache",
              variables: {
                input: {
                  gameId: e,
                  encryptedScore: n,
                  requestId: o,
                  isPreview: t,
                },
              },
              errorPolicy: "all",
              context: { queryDeduplication: !1 },
            });
            if (!i.data?.submitGuestScore) return;
            let r = i.data.submitGuestScore.awardId;
            return null === r ? null : r;
          } catch (e) {
            console.error("Failed to validate guest score:", e);
            return;
          }
        }
        async function q(e, t, n, o, a) {
          let i = e.id,
            r = (0, E.Ss)(i),
            c = h.A.LocalStorage.getItem(r),
            l = e.isPreview ?? !1;
          if ((0, u.O)(c) && (0, u.O)(n)) {
            let { score: t } = JSON.parse(c);
            if (
              (0, u.O)(t) &&
              !isNaN(t) &&
              (0, u.O)(e.leaderboardOptions) &&
              (0, u.O)(e.leaderboardOptions.isIncremental) &&
              !e.leaderboardOptions.isIncremental &&
              !("DESC" === e.leaderboardOptions.scoreSorting ? n > t : n < t)
            )
              return;
          }
          let s = await H(i, l, t, o, a),
            d = {
              gameId: i,
              encryptedScore: t,
              score: n,
              timestamp: new Date().toISOString(),
            };
          h.A.LocalStorage.setItem(r, JSON.stringify(d)),
            (0, u.O)(s) && (0, O.N)({ gameId: i, awardId: s });
        }
        var Z = n(31211),
          J = n(78779),
          K = n(41136),
          X = n(96532),
          Q = n(20490);
        function V(e) {
          let { user: t } = (0, o.useContext)(m.R),
            n = (0, o.useContext)(G.d),
            { openDrawer: E } = (0, o.useContext)(N.lv),
            O = (0, f.t)(),
            D = (0, g.x)(),
            { isSubscribed: U, subscribe: R } = (0, y.A)(),
            H = I.fr(),
            V = I.T0(),
            Y = I.SO(),
            { services: $ } = (0, o.useContext)(L.A),
            { routeHelper: ee } = (0, o.useContext)(A.A),
            {
              setProgressIconStatus: et,
              resetGameInvites: en,
              setGameInviteLink: eo,
              gameInviteLink: ea,
              mountedTime: ei,
              setMultiplayerRoom: er,
              setJoinRoomListenerCount: ec,
              setGameContext: el,
            } = (0, o.useContext)(C.T),
            { crazyRouterChange: es } = (0, o.useContext)(P.Gl),
            eu = (0, i.m)(),
            { user: ed } = I.Jd(),
            e_ = (0, v.t)(),
            [em] = I.BX(),
            [ey] = I.tv(),
            { vote: eg } = (0, w.Z)(e),
            eh = (0, S.hO)(e.slug),
            { addWarning: ep } = (0, j.A)(),
            eB = (0, b.U)("czyExpDisableInterstitialsFirst12h_CZY_18471"),
            ez = (0, B.AQ)(e.slug),
            ef = (0, z.i)("UPGFConnector"),
            eb = (0, J.x)(),
            ev = (0, o.useRef)(!1),
            ew = (0, o.useRef)(void 0);
          (0, o.useEffect)(() => {
            x.q7.isTutorialCompleted().then((e) => {
              ev.current = e;
            }),
              x.Gl.getTimestamp().then((e) => {
                ew.current = e;
              });
          }, []);
          let ek = (t) => {
              n.openFeedbackDrawer("game", {
                feedbackSource: t,
                gameFeedbackOptions: { game: e, mountedTime: ei || void 0 },
              });
            },
            eA = async (t, n, o) => {
              if ((!e.isPreview && !e.hasLeaderboard) || !e.leaderboardOptions)
                return void console.error(
                  "Score submission is not allowed: leaderboard not enabled or leaderboard options not defined"
                );
              let a = (0, u.O)(ed);
              if (a && !ed.privacy.enableLeaderboards) return;
              let i = await eu
                .query({
                  query: F.Op,
                  variables: { gameId: e.id, isPreview: e.isPreview },
                })
                .then((e) => e.data)
                .catch(() => void 0);
              if ((0, u.O)(i) && !(0, u.O)(i.currentLeaderboardSeason))
                return void console.warn(
                  "Score submission skipped: the leaderboard has no active season"
                );
              try {
                a
                  ? await W(e, t, n, o, eu, $.crazyAnalyticsService)
                  : await q(e, t, n, o, eu);
              } catch (e) {
                ep(e.message);
              }
            };
          return {
            handleRequestGfInit: async (n) => {
              let o = await (0, l.getAppAudioMuted)(),
                a = (0, k.JK)()
                  ? await (0, p.z)(() => c.e.isAllowed()).catch(() => void 0)
                  : void 0,
                i = !!JSON.parse(h.A.LocalStorage.getItem(Z.r_) || "false"),
                r = !!JSON.parse(h.A.LocalStorage.getItem(Z.zW) || "false"),
                s = t?.email || void 0,
                u = t ? eg : eh,
                d = $.gamesPlayedService.getPlayTime(e.slug) > 0,
                _ = {
                  type: "gfInit",
                  data: {
                    userId: $.crazyAnalyticsService.getUserId(),
                    userAccountAvailable: !0,
                    userExpected: i,
                    wasUserLoggedIn: r,
                    email: s,
                    vote: u,
                    applicationType: (0, k.D8)(),
                    pageVisitId: $.crazyAnalyticsService.getPageVisitId(),
                    appTrueFullscreenTutorialCompleted: ev.current,
                    appTrueFullscreen: eb?.isAppTrueFullscreenRef.current ?? !1,
                    totalGamesPlayedInSession:
                      $.gamesPlayedService.getTotalGamesPlayedInSessionForNextGame(),
                    playedGameBefore: d,
                    appAudioMuted: o,
                    storeAvailable: !(0, k.JK)() || a?.allowed === !0 || ez,
                  },
                };
              n.source?.postMessage(_, "*");
            },
            handleSessionStart: (e) => {
              $.experimentService.registerGameframeExperiments(
                e.data.experiments
              );
            },
            handleRequestToFavouriteGame: (n) => {
              t ? H(e) : E("myGames-favourite");
            },
            handleRequestToUnFavouriteGame: (n) => {
              t ? V(e.id) : E("myGames");
            },
            handleSetGameNotifications: async (t) => {
              let { enabled: n } = t.data;
              try {
                if (n && D && !U && !(await R())) return;
                await O(e.id, n, "gameframe");
              } catch (e) {
                console.error("Updating the game notifications failed", e);
              }
            },
            handleOpenGameNotificationPreferences: (e) => {
              E("gameNotificationPreferences", {
                clickOrigin: "gameNotificationsModal",
              });
            },
            handleForwardToUpGraphql: async (e) => {
              let {
                requestType: t,
                rawGraphqlString: n,
                variables: o,
                fetchPolicy: i,
                errorPolicy: r = "all",
                callbackId: c,
              } = e.data;
              try {
                let l = (0, _.qg)(n);
                if ("query" === t) {
                  let t = await eu.query({
                      query: l,
                      variables: o,
                      fetchPolicy: i,
                      errorPolicy: r,
                    }),
                    n = t.errors ?? (t.error ? [t.error] : void 0),
                    s = {
                      resultData: t.data,
                      errors: n,
                      networkStatus: n?.length ? a.pT.error : a.pT.ready,
                      callbackId: c,
                    };
                  e.source?.postMessage(
                    { type: "forwardToUpGraphqlResponse", data: s },
                    "*"
                  );
                } else if ("mutation" === t) {
                  let t = await eu.mutate({
                      mutation: l,
                      fetchPolicy: "no-cache",
                      variables: o,
                      errorPolicy: r,
                      context: { queryDeduplication: !1 },
                    }),
                    n = { resultData: t.data, errors: t.errors, callbackId: c };
                  e.source?.postMessage(
                    { type: "forwardToUpGraphqlResponse", data: n },
                    "*"
                  );
                }
              } catch (n) {
                ef.persist.error("[UPGFConnector]", { error: (0, d.M)(n) });
                let t = {
                  resultData: null,
                  errors: [n.message ? n.message : JSON.stringify(n)],
                  callbackId: c,
                };
                e.source?.postMessage(
                  { type: "forwardToUpGraphqlResponse", data: t },
                  "*"
                );
              }
            },
            handleRedirectToHomepage: (e) => {
              es(ee.homePageLink().href);
            },
            handleRefreshGamePage: (e) => {
              let { query: t } = e.data;
              (0, K.OM)({ query: t });
            },
            handleBrowserBack: (e) => {
              window.history.back();
            },
            handleOpenProgressStatusDrawer: (e) => {
              et(e.data.progressIconStatus), E("progressStatus");
            },
            handleFeedback: (e) => {
              let t = e.data.source;
              "dislike" === t
                ? ek("gfDislikeFeedback")
                : "feedbackButton" === t
                ? ek("gfFeedback")
                : (console.error("Missing feedback event source from GF"),
                  ek("unknown"));
            },
            handleShowInviteButton: (n) => {
              if (!t) return;
              let o = n.data;
              try {
                window.history.replaceState(
                  {
                    ...window.history.state,
                    as: o.inviteUrl,
                    url: o.inviteUrl,
                  },
                  "",
                  o.inviteUrl
                );
              } catch (e) {
                console.error(e);
              }
              eo(o.inviteUrl),
                $.crazyAnalyticsService.gameInteractionEvent({
                  method: "join",
                  origin: "game",
                  action: "broadcast",
                  target: null,
                  targetStatus: null,
                  targetGameId: e.id,
                });
            },
            handleHideInviteButton: (n) => {
              t &&
                ea &&
                (en(),
                eo(null),
                $.crazyAnalyticsService.gameInteractionEvent({
                  method: "join",
                  origin: "game",
                  action: "expire",
                  target: null,
                  targetStatus: null,
                  targetGameId: e.id,
                }));
            },
            handleShowFriendsDrawer: (e) => {
              t
                ? E("friends", { clickOrigin: "noRewardAltInviteFriends" })
                : E("friendsGuest", {
                    clickOrigin: "noRewardAltInviteFriends",
                  }),
                $.crazyAnalyticsService.sendModalEvent(
                  "noRewardAltCTA",
                  "open",
                  "invite_friends",
                  "noRewardAltInviteFriends"
                );
            },
            handleShowEditProfileDrawer: (e) => {
              E("editProfile"),
                $.crazyAnalyticsService.sendModalEvent(
                  "noRewardAltCTA",
                  "open",
                  "complete_profile",
                  "noRewardAltCompleteProfile"
                );
            },
            handleShowLoginDrawer: (e) => {
              let t = e.data;
              E("signIn", { clickOrigin: t.clickOrigin }),
                $.crazyAnalyticsService.sendModalEvent(
                  t.source,
                  "open",
                  "login",
                  t.clickOrigin
                );
            },
            handleAfterPlayNow: (e) => {
              e_();
            },
            handleTriggerPlayOnApp: (e) => {
              E("openApp", { clickOrigin: e.data.source });
            },
            handleNativeVideo: async (e) => {
              var t, n;
              let o = e.data;
              if (
                "midroll" === o.videoType &&
                ((t = eB),
                (n = ew.current),
                "disabled" !== t &&
                  r.Capacitor.isNativePlatform() &&
                  (0, u.O)(n) &&
                  Date.now() - n < 432e5)
              ) {
                $.crazyAnalyticsService.userAction(
                  "ads",
                  "interstitial_opportunity_skipped"
                ),
                  o.play &&
                    Q.S?.window.postMessage(
                      {
                        type: "NativeAdEvent",
                        data: { action: "onAdFinished" },
                      },
                      "*"
                    );
                return;
              }
              if (o.play) {
                let e = await (0, X.N5)(o.videoType, o.muted);
                "rewarded" === o.videoType &&
                  "skippedOffline" === e &&
                  (0, T.L)();
              } else await (0, X.Hc)(o.videoType);
            },
            handleCompleteProfile: async (e) => {
              let { gender: t, birthday: n } = e.data;
              t && (await em(t)), n && (await ey(n));
            },
            handleSubmitScore: async (e) => {
              let { encryptedScore: t, score: n, requestId: o } = e.data;
              (0, u.O)(n) ||
                ep("submitScore was called without a plain score value"),
                await eA(t, n, o);
            },
            handleGtagEvent: (e) => {
              let t = e.data;
              "event" === t.command &&
                $.analyticsService.trackGAEvent({
                  eventAction: t.targetId,
                  eventCategory: t.parameters?.event_category || "gameframe",
                  eventLabel: t.parameters?.event_label,
                  eventValue: t.parameters?.value,
                  additionalFields: t.parameters,
                });
            },
            handlePointerLockChanged: (e) => {
              e.data.isLocked
                ? (document.body.style.overflow = "hidden")
                : (document.body.style.overflow = "");
            },
            handleUpdateMultiplayerRoomData: (t) => {
              let { roomId: n, isJoinable: o, inviteParams: a } = t.data,
                i = !!o,
                r = a ?? null;
              if (null !== r && "object" != typeof r)
                throw Error("inviteParams must be an object or null");
              let c =
                "string" == typeof n || "number" == typeof n ? `${n}` : "";
              if (
                (er(
                  c.trim()
                    ? { roomId: c, isJoinable: i, inviteParams: r }
                    : null
                ),
                i)
              ) {
                let t = ee.gamePageShareLink(e.slug);
                e.isPreview && (t = (0, s.KE)(window.location.href)),
                  eo(
                    (0, s.lJ)({ gameLink: t, params: r, invitedById: ed?.id })
                  );
              } else eo(null);
            },
            handleLeftMultiplayerRoom: (e) => {
              er(null), eo(null);
            },
            handleOnJoinRoomListenerChange: (e) => {
              ec(e.data.count);
            },
            handleOfflineGetGameData: (e) => {
              throw Error("Not yet implemented: offlineGetGameData");
            },
            handleOfflineReplaceGameData: (e) => {
              throw Error("Not yet implemented: offlineReplaceGameData");
            },
            handleOfflineClearGameData: (e) => {
              throw Error("Not yet implemented: offlineClearGameData");
            },
            handleOfflineFetchSdkGameData: (e) => {
              throw Error("Not yet implemented: offlineFetchSdkGameData");
            },
            handleOfflineSaveSdkGameData: (e) => {
              throw Error("Not yet implemented: offlineSaveSdkGameData");
            },
            handleReportGameCompletedPercentage: async (n) => {
              let { percentage: o } = n.data;
              if ((0, u.O)(t))
                try {
                  await eu.mutate({
                    mutation: M.$P,
                    fetchPolicy: "no-cache",
                    variables: { input: { gameId: e.id, percentage: o } },
                  });
                } catch (e) {
                  console.error("Error reporting game completed percentage", e);
                }
            },
            handleSurveyAnswerSubmitted: (e) => {
              let { questionId: t, value: n } = e.data;
              Y(t, n);
            },
            handleSetGameContext: (e) => {
              let t = e.data.context;
              JSON.stringify(t).length > 1e3 || el(t);
            },
          };
        }
      },
      28333: (e) => {
        e.exports = {
          czyButton: "BackToTop_czyButton__PsVUI",
          "czyButton--contained--purple":
            "BackToTop_czyButton--contained--purple__sep0a",
          "czyButton--contained--white":
            "BackToTop_czyButton--contained--white__KXZTZ",
          "czyButton--contained--grey":
            "BackToTop_czyButton--contained--grey__vFssL",
          "czyButton--contained--warning":
            "BackToTop_czyButton--contained--warning__yLOkq",
          "czyButton--contained--alert":
            "BackToTop_czyButton--contained--alert___1CLJ",
          "czyButton--contained--success":
            "BackToTop_czyButton--contained--success__K_8B1",
          "czyButton--contained--black":
            "BackToTop_czyButton--contained--black__7Xto3",
          "czyButton--contained--green-gradient":
            "BackToTop_czyButton--contained--green-gradient__95YUB",
          "czyButton--contained--animated-green-gradient":
            "BackToTop_czyButton--contained--animated-green-gradient__PeFP3",
          "scroll-gradient": "BackToTop_scroll-gradient__qnskQ",
          "czyButton--outlined--purple":
            "BackToTop_czyButton--outlined--purple__DU_TH",
          "czyButton--link--purple": "BackToTop_czyButton--link--purple__aH9pJ",
          "czyButton--outlined--white":
            "BackToTop_czyButton--outlined--white__AA7nr",
          "czyButton--link--white": "BackToTop_czyButton--link--white__cjX_S",
          "czyButton--outlined--grey":
            "BackToTop_czyButton--outlined--grey__FkiZy",
          "czyButton--link--grey": "BackToTop_czyButton--link--grey__dCUkl",
          "czyButton--outlined--warning":
            "BackToTop_czyButton--outlined--warning__x_LK0",
          "czyButton--link--warning":
            "BackToTop_czyButton--link--warning__smnpW",
          "czyButton--outlined--alert":
            "BackToTop_czyButton--outlined--alert__lVrPu",
          "czyButton--link--alert": "BackToTop_czyButton--link--alert__U3rfr",
          "czyButton--outlined--success":
            "BackToTop_czyButton--outlined--success__MAXvr",
          "czyButton--link--success":
            "BackToTop_czyButton--link--success__kQAzW",
          "czyButton--outlined": "BackToTop_czyButton--outlined__2jNma",
          "czyButton--disabled": "BackToTop_czyButton--disabled__xFYdC",
          "czyButton--height50": "BackToTop_czyButton--height50__ubjZH",
          "czyButton--height34": "BackToTop_czyButton--height34__lUz0n",
          "czyButton--height28": "BackToTop_czyButton--height28__bDFmO",
          "czyButton--fullWidth": "BackToTop_czyButton--fullWidth__o_f5_",
          "czyButton--headerIcon": "BackToTop_czyButton--headerIcon__zU1uO",
          "czyButton--headerIcon--desktop":
            "BackToTop_czyButton--headerIcon--desktop__6_ey1",
          "czyButton--headerIcon--mobile":
            "BackToTop_czyButton--headerIcon--mobile__i4xZ1",
          "czyButton--headerIcon--withLabel":
            "BackToTop_czyButton--headerIcon--withLabel__txOvp",
          buttonContainer: "BackToTop_buttonContainer__GQast",
          center: "BackToTop_center__l50Lu",
          hide: "BackToTop_hide__qS9u6",
          bounce: "BackToTop_bounce__6Cps5",
          playAnimation: "BackToTop_playAnimation__lIo7n",
        };
      },
      28967: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => r });
        var o = n(50293),
          a = n(45364);
        let i = [
            "#9258e3",
            "#d58939",
            "#09ffea",
            "#ffef4b",
            "#4bd3ff",
            "#ff4bde",
            "#a399f4",
            "#f27b3e",
            "#5dff4b",
            "#ffea4b",
            "#09ffea",
            "#ffa62a",
          ],
          r = async function (e) {
            let t =
                arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
              r =
                arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
              c =
                arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
            if ((a.A.isFullscreen() && !c) || (0, o.Kg)(e)) return;
            let l = await n.e(74461).then(n.bind(n, 74461)),
              s = l.default || l,
              u = s.create(void 0, { resize: !0, useWorker: !0 });
            if (r && !t) {
              let e = ["#FF6B1A", "#9D4EDD", "#000000", "#FFA500"],
                t = s.shapeFromPath({
                  path: "M0 -10 L2.5 -2.5 L10 0 L2.5 2.5 L0 10 L-2.5 2.5 L-10 0 L-2.5 -2.5 Z",
                }),
                n = s.shapeFromPath({
                  path: "M0 -8 C-4 -8 -6 -6 -6 -2 L-6 6 L-4 4 L-2 6 L0 4 L2 6 L4 4 L6 6 L6 -2 C6 -6 4 -8 0 -8 Z",
                }),
                o = s.shapeFromPath({
                  path: "M0 0 L-2 -2 C-4 -3 -6 -2 -8 0 C-6 1 -5 2 -3 2 L-1 1 L-1 3 L1 3 L1 1 L3 2 C5 2 6 1 8 0 C6 -2 4 -3 2 -2 Z",
                });
              u({
                particleCount: 80,
                angle: 60,
                spread: 70,
                origin: { x: 0 },
                colors: e,
                shapes: [t, n, o],
                scalar: 1.2,
                zIndex: 1405,
              }),
                u({
                  particleCount: 80,
                  angle: 120,
                  spread: 70,
                  origin: { x: 1 },
                  colors: e,
                  shapes: [t, n, o],
                  scalar: 1.2,
                  zIndex: 1405,
                });
            } else if (t) {
              let e = s.shapeFromText({ text: "\uD83C\uDFC6", scalar: 5 });
              u({
                particleCount: 30,
                spread: 130,
                origin: { x: 0 },
                shapes: [e],
                scalar: 5,
                zIndex: 1405,
              }),
                u({
                  particleCount: 30,
                  spread: 130,
                  origin: { x: 1 },
                  shapes: [e],
                  scalar: 5,
                  zIndex: 1405,
                });
            } else
              u({
                particleCount: 100,
                angle: 60,
                spread: 65,
                origin: { x: 0 },
                colors: i,
                zIndex: 1405,
              }),
                u({
                  particleCount: 100,
                  angle: 120,
                  spread: 65,
                  origin: { x: 1 },
                  colors: i,
                  zIndex: 1405,
                });
          };
      },
      29457: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => r });
        var o = n(6029),
          a = n(75155),
          i = n(55729);
        let r = (e) => {
          let t,
            n,
            r,
            c,
            l,
            s = (0, a.c)(9);
          s[0] !== e
            ? (({ buildSource: t, overrideSource: r, ...n } = e),
              (s[0] = e),
              (s[1] = t),
              (s[2] = n),
              (s[3] = r))
            : ((t = s[1]), (n = s[2]), (r = s[3])),
            s[4] !== t ? ((c = () => t()), (s[4] = t), (s[5] = c)) : (c = s[5]);
          let [u] = i.useState(c),
            d = r ?? u;
          return (
            s[6] !== n || s[7] !== d
              ? ((l = (0, o.jsx)("iframe", { ...n, src: d })),
                (s[6] = n),
                (s[7] = d),
                (s[8] = l))
              : (l = s[8]),
            l
          );
        };
      },
      30561: (e) => {
        e.exports = {
          title: "LastUpdated_title__DRGO4",
          date: "LastUpdated_date__RC_Te",
        };
      },
      32687: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 });
      },
      33052: (e, t) => {
        "use strict";
        (t.Ss = t.hl = t.Z4 = void 0),
          (t.Z4 = 24),
          (t.hl = "guest_score_"),
          (t.Ss = (e) => `${t.hl}${e}`);
      },
      37288: (e, t, n) => {
        "use strict";
        n.d(t, { Pe: () => i, f0: () => r, iV: () => a });
        var o = n(96301);
        let a = o.X1,
          i = o.Pw,
          r = o.mt;
      },
      39328: (e, t, n) => {
        "use strict";
        t.e = void 0;
        var o = n(13281);
        Object.defineProperty(t, "e", {
          enumerable: !0,
          get: function () {
            return o.ExternalPayment;
          },
        });
      },
      40705: (e) => {
        e.exports = {
          czyButton: "ProgressSaveNudge_czyButton__aKwXb",
          "czyButton--contained--purple":
            "ProgressSaveNudge_czyButton--contained--purple__3MAqU",
          "czyButton--contained--white":
            "ProgressSaveNudge_czyButton--contained--white__gGBO8",
          "czyButton--contained--grey":
            "ProgressSaveNudge_czyButton--contained--grey__c_IXQ",
          "czyButton--contained--warning":
            "ProgressSaveNudge_czyButton--contained--warning__BzwLP",
          "czyButton--contained--alert":
            "ProgressSaveNudge_czyButton--contained--alert__N_JAX",
          "czyButton--contained--success":
            "ProgressSaveNudge_czyButton--contained--success__M1zEi",
          "czyButton--contained--black":
            "ProgressSaveNudge_czyButton--contained--black__aLtDi",
          "czyButton--contained--green-gradient":
            "ProgressSaveNudge_czyButton--contained--green-gradient__f9A40",
          "czyButton--contained--animated-green-gradient":
            "ProgressSaveNudge_czyButton--contained--animated-green-gradient__CME3b",
          "scroll-gradient": "ProgressSaveNudge_scroll-gradient__X702T",
          "czyButton--outlined--purple":
            "ProgressSaveNudge_czyButton--outlined--purple__oyXeo",
          "czyButton--link--purple":
            "ProgressSaveNudge_czyButton--link--purple__rbDKN",
          "czyButton--outlined--white":
            "ProgressSaveNudge_czyButton--outlined--white__5OkUq",
          "czyButton--link--white":
            "ProgressSaveNudge_czyButton--link--white__DZ7LQ",
          "czyButton--outlined--grey":
            "ProgressSaveNudge_czyButton--outlined--grey__dZ6sv",
          "czyButton--link--grey":
            "ProgressSaveNudge_czyButton--link--grey__uOMIT",
          "czyButton--outlined--warning":
            "ProgressSaveNudge_czyButton--outlined--warning___BV5b",
          "czyButton--link--warning":
            "ProgressSaveNudge_czyButton--link--warning__WaN3w",
          "czyButton--outlined--alert":
            "ProgressSaveNudge_czyButton--outlined--alert__GMdW8",
          "czyButton--link--alert":
            "ProgressSaveNudge_czyButton--link--alert__v27DR",
          "czyButton--outlined--success":
            "ProgressSaveNudge_czyButton--outlined--success__9grt7",
          "czyButton--link--success":
            "ProgressSaveNudge_czyButton--link--success__M_vk5",
          "czyButton--outlined": "ProgressSaveNudge_czyButton--outlined__aU7KU",
          "czyButton--disabled": "ProgressSaveNudge_czyButton--disabled__oMKe5",
          "czyButton--height50": "ProgressSaveNudge_czyButton--height50__c5Jus",
          "czyButton--height34": "ProgressSaveNudge_czyButton--height34__os_vg",
          "czyButton--height28": "ProgressSaveNudge_czyButton--height28__srRh6",
          "czyButton--fullWidth":
            "ProgressSaveNudge_czyButton--fullWidth__G3WEm",
          "czyButton--headerIcon":
            "ProgressSaveNudge_czyButton--headerIcon__Ungeh",
          "czyButton--headerIcon--desktop":
            "ProgressSaveNudge_czyButton--headerIcon--desktop__iaeZN",
          "czyButton--headerIcon--mobile":
            "ProgressSaveNudge_czyButton--headerIcon--mobile__Ko5Fl",
          "czyButton--headerIcon--withLabel":
            "ProgressSaveNudge_czyButton--headerIcon--withLabel__0RmFI",
          thumbWrap: "ProgressSaveNudge_thumbWrap__bYink",
          thumb: "ProgressSaveNudge_thumb__wWXtA",
          badge: "ProgressSaveNudge_badge__YJUUT",
        };
      },
      41232: (e) => {
        e.exports = {
          chip: "DailyStreakChip_chip__D9bkf",
          flame: "DailyStreakChip_flame__aaf1m",
        };
      },
      42191: (e, t, n) => {
        "use strict";
        n.d(t, { i: () => i });
        var o = n(55729),
          a = n(30815);
        function i(e) {
          let { createClientSideLogger: t } = o.useContext(a.p);
          return o.useMemo(() => t(e), [t, e]);
        }
      },
      42832: (e) => {
        e.exports = {
          czyButton: "BottomNavigation_czyButton__c_z5y",
          "czyButton--contained--purple":
            "BottomNavigation_czyButton--contained--purple__efvDY",
          "czyButton--contained--white":
            "BottomNavigation_czyButton--contained--white__LxR4h",
          "czyButton--contained--grey":
            "BottomNavigation_czyButton--contained--grey__raLyh",
          "czyButton--contained--warning":
            "BottomNavigation_czyButton--contained--warning__N71sm",
          "czyButton--contained--alert":
            "BottomNavigation_czyButton--contained--alert__g5zj0",
          "czyButton--contained--success":
            "BottomNavigation_czyButton--contained--success__SzsCh",
          "czyButton--contained--black":
            "BottomNavigation_czyButton--contained--black__ZP_iQ",
          "czyButton--contained--green-gradient":
            "BottomNavigation_czyButton--contained--green-gradient__78H3X",
          "czyButton--contained--animated-green-gradient":
            "BottomNavigation_czyButton--contained--animated-green-gradient__UKlww",
          "scroll-gradient": "BottomNavigation_scroll-gradient__93dSq",
          "czyButton--outlined--purple":
            "BottomNavigation_czyButton--outlined--purple__x58Ox",
          "czyButton--link--purple":
            "BottomNavigation_czyButton--link--purple__y6UsA",
          "czyButton--outlined--white":
            "BottomNavigation_czyButton--outlined--white__Pd86u",
          "czyButton--link--white":
            "BottomNavigation_czyButton--link--white__4K_8q",
          "czyButton--outlined--grey":
            "BottomNavigation_czyButton--outlined--grey__79KlQ",
          "czyButton--link--grey":
            "BottomNavigation_czyButton--link--grey__c6y5f",
          "czyButton--outlined--warning":
            "BottomNavigation_czyButton--outlined--warning__RRTul",
          "czyButton--link--warning":
            "BottomNavigation_czyButton--link--warning__U2LWQ",
          "czyButton--outlined--alert":
            "BottomNavigation_czyButton--outlined--alert__dWLjl",
          "czyButton--link--alert":
            "BottomNavigation_czyButton--link--alert__Cncv0",
          "czyButton--outlined--success":
            "BottomNavigation_czyButton--outlined--success__Jy4ie",
          "czyButton--link--success":
            "BottomNavigation_czyButton--link--success__I0syi",
          "czyButton--outlined": "BottomNavigation_czyButton--outlined__vi5F_",
          "czyButton--disabled": "BottomNavigation_czyButton--disabled__bc9_x",
          "czyButton--height50": "BottomNavigation_czyButton--height50__4_DiR",
          "czyButton--height34": "BottomNavigation_czyButton--height34__zCQG6",
          "czyButton--height28": "BottomNavigation_czyButton--height28__597ey",
          "czyButton--fullWidth":
            "BottomNavigation_czyButton--fullWidth__qR_FA",
          "czyButton--headerIcon":
            "BottomNavigation_czyButton--headerIcon__9koem",
          "czyButton--headerIcon--desktop":
            "BottomNavigation_czyButton--headerIcon--desktop__mFHUc",
          "czyButton--headerIcon--mobile":
            "BottomNavigation_czyButton--headerIcon--mobile__I0gTH",
          "czyButton--headerIcon--withLabel":
            "BottomNavigation_czyButton--headerIcon--withLabel__fW8gc",
          root: "BottomNavigation_root__89wJI",
          navItems: "BottomNavigation_navItems__5_uRj",
          navItem: "BottomNavigation_navItem__BI3ju",
          isActive: "BottomNavigation_isActive__KG5Iz",
          navItemIcon: "BottomNavigation_navItemIcon__i2ueC",
          navItemLabel: "BottomNavigation_navItemLabel__OeX3p",
          badge: "BottomNavigation_badge__GQeGf",
          badgeCount: "BottomNavigation_badgeCount__Tpj_u",
          badgeDot: "BottomNavigation_badgeDot__exxwN",
          profileAvatar: "BottomNavigation_profileAvatar__AjPvi",
          profileAvatarActive: "BottomNavigation_profileAvatarActive__QFNXW",
          profileAvatarSkeleton:
            "BottomNavigation_profileAvatarSkeleton__qh62X",
          "profile-avatar-pulse":
            "BottomNavigation_profile-avatar-pulse__hsQ_o",
        };
      },
      47953: (e) => {
        e.exports = { greenPill: "dailyGames_greenPill__Tj5jb" };
      },
      49188: (e) => {
        e.exports = {
          czyButton: "GameInfo_czyButton__NFG6H",
          "czyButton--contained--purple":
            "GameInfo_czyButton--contained--purple__TO3WA",
          "czyButton--contained--white":
            "GameInfo_czyButton--contained--white__7qHFR",
          "czyButton--contained--grey":
            "GameInfo_czyButton--contained--grey__XGRHJ",
          "czyButton--contained--warning":
            "GameInfo_czyButton--contained--warning__faGhK",
          "czyButton--contained--alert":
            "GameInfo_czyButton--contained--alert__4hxyi",
          "czyButton--contained--success":
            "GameInfo_czyButton--contained--success__3s95V",
          "czyButton--contained--black":
            "GameInfo_czyButton--contained--black__7m0R4",
          "czyButton--contained--green-gradient":
            "GameInfo_czyButton--contained--green-gradient__5PFk2",
          "czyButton--contained--animated-green-gradient":
            "GameInfo_czyButton--contained--animated-green-gradient__nRuKy",
          "scroll-gradient": "GameInfo_scroll-gradient__GUsYu",
          "czyButton--outlined--purple":
            "GameInfo_czyButton--outlined--purple__NP8_g",
          "czyButton--link--purple": "GameInfo_czyButton--link--purple__ut6qp",
          "czyButton--outlined--white":
            "GameInfo_czyButton--outlined--white__r7Yo9",
          "czyButton--link--white": "GameInfo_czyButton--link--white__W_aCf",
          "czyButton--outlined--grey":
            "GameInfo_czyButton--outlined--grey__kZSWS",
          "czyButton--link--grey": "GameInfo_czyButton--link--grey__SNPYH",
          "czyButton--outlined--warning":
            "GameInfo_czyButton--outlined--warning__bXjnY",
          "czyButton--link--warning":
            "GameInfo_czyButton--link--warning__WfaQZ",
          "czyButton--outlined--alert":
            "GameInfo_czyButton--outlined--alert__dPEvu",
          "czyButton--link--alert": "GameInfo_czyButton--link--alert__2ZOjZ",
          "czyButton--outlined--success":
            "GameInfo_czyButton--outlined--success__pLR6t",
          "czyButton--link--success":
            "GameInfo_czyButton--link--success__g89RT",
          "czyButton--outlined": "GameInfo_czyButton--outlined__8zDQZ",
          "czyButton--disabled": "GameInfo_czyButton--disabled__E36sl",
          "czyButton--height50": "GameInfo_czyButton--height50__NJLzC",
          "czyButton--height34": "GameInfo_czyButton--height34__OrOqv",
          "czyButton--height28": "GameInfo_czyButton--height28__a_Trd",
          "czyButton--fullWidth": "GameInfo_czyButton--fullWidth__t38xW",
          "czyButton--headerIcon": "GameInfo_czyButton--headerIcon__rLosj",
          "czyButton--headerIcon--desktop":
            "GameInfo_czyButton--headerIcon--desktop__KxU6Y",
          "czyButton--headerIcon--mobile":
            "GameInfo_czyButton--headerIcon--mobile__9sSka",
          "czyButton--headerIcon--withLabel":
            "GameInfo_czyButton--headerIcon--withLabel___osU7",
          gameInfoStoreButtonsContainer:
            "GameInfo_gameInfoStoreButtonsContainer__snbxi",
          breadcrumbs: "GameInfo_breadcrumbs___GWXw",
          title: "GameInfo_title__wNgxj",
          styledHtmlDiv: "GameInfo_styledHtmlDiv__Zg2EY",
          marginBlockEnd1: "GameInfo_marginBlockEnd1__CZiMD",
          faqTitle: "GameInfo_faqTitle__3P3c2",
          gameUnderTitle: "GameInfo_gameUnderTitle__EyUXF",
          gameSeriesContainer: "GameInfo_gameSeriesContainer__imjgi",
          styledDevName: "GameInfo_styledDevName__MnwFN",
          gameInfo: "GameInfo_gameInfo__2UItk",
          isDesktop: "GameInfo_isDesktop__KqJ3d",
          isMobile: "GameInfo_isMobile___Uz1d",
          secondMpuContainer: "GameInfo_secondMpuContainer__xiGbJ",
          top: "GameInfo_top__7H_Pq",
          leftColumn: "GameInfo_leftColumn__vMTeN",
          adsLeaderboard: "GameInfo_adsLeaderboard__BdiYx",
          gameInfoTopSection: "GameInfo_gameInfoTopSection__xKLGy",
          rightColumn: "GameInfo_rightColumn__hExHC",
          roundedCornersContainer: "GameInfo_roundedCornersContainer__D5D_p",
          removeTopPadding: "GameInfo_removeTopPadding__hI61b",
          gameRatingDislikePopup: "GameInfo_gameRatingDislikePopup__6ZPqW",
          closeIcon: "GameInfo_closeIcon__JCp1X",
        };
      },
      52268: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => r });
        var o = n(55729),
          a = n(45364),
          i = n(71684);
        let r = () => {
          let e = o.useContext(i.A).services;
          return (
            o.useEffect(() => {
              let t = () => {
                a.A.isFakeFullscreen() || a.A.isFullscreen()
                  ? e.crazyAnalyticsService.displayEvent("fullscreen", "enter")
                  : e.crazyAnalyticsService.displayEvent("fullscreen", "exit");
              };
              return (
                a.A.addFullscreenListener(t),
                a.A.addFakeFullscreenListener(t),
                () => {
                  a.A.removeFullscreenListener(t),
                    a.A.removeFakeFullscreenListener(t);
                }
              );
            }, [e.crazyAnalyticsService]),
            null
          );
        };
      },
      52359: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => d });
        var o = n(6029),
          a = n(75155);
        n(55729);
        var i = n(79942),
          r = n(70930),
          c = n(86907),
          l = n.n(c),
          s = n(49188),
          u = n.n(s);
        let d = (e) => {
          let t,
            n,
            c = (0, a.c)(3),
            { game: s } = e,
            { gamesInSeries: d } = s;
          return 0 === d.length
            ? null
            : (c[0] === Symbol.for("react.memo_cache_sentinel")
                ? ((t = (0, o.jsx)("h3", {
                    children: (0, o.jsx)(i.x6, { id: "game.series.title" }),
                  })),
                  (c[0] = t))
                : (t = c[0]),
              c[1] !== d
                ? ((n = (0, o.jsxs)("div", {
                    className: u().gameSeriesContainer,
                    children: [
                      t,
                      (0, o.jsx)(r.A, { className: l().fullWidth, games: d }),
                    ],
                  })),
                  (c[1] = d),
                  (c[2] = n))
                : (n = c[2]),
              n);
        };
      },
      54596: (e, t, n) => {
        "use strict";
        n.d(t, { z: () => s });
        var o = n(75155),
          a = n(81631),
          i = n(79361),
          r = n(15383),
          c = n(845);
        function l(e) {
          return {
            id: e.id,
            name: e.name,
            slug: e.slug,
            cover: e.cover,
            covers: e.covers ?? void 0,
            videos: e.videos,
            status: e.status,
            iosFriendly: e.iosFriendly,
            androidFriendly: e.androidFriendly,
            gameThumbLabels: e.gameThumbLabels,
            activeArtworkExperiment: e.activeArtworkExperiment,
          };
        }
        function s(e, t, n) {
          let s,
            u,
            d = (0, o.c)(10),
            _ = (0, c.U)() && !e && !t,
            { games: m, isLoading: y } = (0, r.k)(_);
          e: {
            let e;
            if (!_) {
              let e;
              d[0] === Symbol.for("react.memo_cache_sentinel")
                ? ((e = []), (d[0] = e))
                : (e = d[0]),
                (s = e);
              break e;
            }
            if (d[1] !== n || d[2] !== m) {
              let t;
              d[4] !== n
                ? ((t = (e) => e.id !== n), (d[4] = n), (d[5] = t))
                : (t = d[5]);
              let o = m.filter(t);
              (e = (0, a._L)(o, a.PV.length, (0, i.S5)()?.categoryId).map(l)),
                (d[1] = n),
                (d[2] = m),
                (d[3] = e);
            } else e = d[3];
            s = e;
          }
          let g = s,
            h = _ && y;
          return (
            d[6] !== _ || d[7] !== g || d[8] !== h
              ? ((u = { games: g, enabled: _, isInjecting: h }),
                (d[6] = _),
                (d[7] = g),
                (d[8] = h),
                (d[9] = u))
              : (u = d[9]),
            u
          );
        }
      },
      56341: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => o });
        let o = (0, n(65317).v)()((e) => ({
          sdkInitialized: !1,
          SDKInfo: null,
          detectedSDKFunctionality: new Set(),
          warnings: [],
          addDetectedSdkFunctionality: (t) =>
            e((e) => {
              let n = new Set(e.detectedSDKFunctionality);
              return n.add(t), { detectedSDKFunctionality: n };
            }),
          setSdkInitialized: (t) =>
            e(() => ({ sdkInitialized: !0, SDKInfo: t })),
          addWarning: (t) =>
            e((e) =>
              e.warnings.includes(t) ? e : { warnings: [...e.warnings, t] }
            ),
        }));
      },
      56729: (e) => {
        e.exports = {
          gameRating: "GameRating_gameRating__WaU7a",
          totalVotes: "GameRating_totalVotes__uYan_",
        };
      },
      58163: (e, t, n) => {
        "use strict";
        let o;
        n.d(t, { H: () => s, Qe: () => l });
        var a = n(37983),
          i = n(74339),
          r = n(68401);
        async function c() {
          if (
            !(
              i.Capacitor.isNativePlatform() &&
              i.Capacitor.isPluginAvailable("ExternalPayment")
            )
          )
            return !1;
          let { version: e } = await a.App.getInfo();
          return (0, r.x)(e, "1.7.11");
        }
        function l() {
          return (o ??= c().catch(() => !1));
        }
        function s() {
          return "ios" === i.Capacitor.getPlatform()
            ? "czyExpClientInAppPurchaseAlternativeBillingIOSUS"
            : "czyExpClientInAppPurchaseAlternativeBillingAndroid";
        }
      },
      59701: (e, t, n) => {
        "use strict";
        n.d(t, { N: () => a, S: () => i });
        let o = new Set();
        function a(e) {
          o.forEach((t) => {
            t(e);
          });
        }
        function i(e) {
          return (
            o.add(e),
            () => {
              o.delete(e);
            }
          );
        }
      },
      60788: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => d });
        var o = n(6029),
          a = n(75155);
        n(55729);
        var i = n(77650),
          r = n(50212),
          c = n(64420),
          l = n(5875),
          s = n(41232),
          u = n.n(s);
        let d = (e) => {
          let t,
            n,
            s,
            d,
            _,
            m = (0, a.c)(13),
            { streak: y, className: g } = e,
            h = (0, l.l)();
          return (
            m[0] !== g
              ? ((t = (0, r.A)(u().chip, g)), (m[0] = g), (m[1] = t))
              : (t = m[1]),
            m[2] !== y
              ? ((n = i.Ru._({
                  id: "common.dailyGames.streakDays",
                  values: { count: y },
                })),
                (m[2] = y),
                (m[3] = n))
              : (n = m[3]),
            m[4] !== h
              ? ((s = (0, o.jsx)(c.A, {
                  className: u().flame,
                  lit: !0,
                  offsetMs: h,
                })),
                (m[4] = h),
                (m[5] = s))
              : (s = m[5]),
            m[6] !== y
              ? ((d = (0, o.jsx)("span", { "aria-hidden": !0, children: y })),
                (m[6] = y),
                (m[7] = d))
              : (d = m[7]),
            m[8] !== t || m[9] !== n || m[10] !== s || m[11] !== d
              ? ((_ = (0, o.jsxs)("span", {
                  className: t,
                  "aria-label": n,
                  children: [s, d],
                })),
                (m[8] = t),
                (m[9] = n),
                (m[10] = s),
                (m[11] = d),
                (m[12] = _))
              : (_ = m[12]),
            _
          );
        };
      },
      62879: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => b });
        var o = n(6029),
          a = n(75155),
          i = n(55729),
          r = n(79942),
          c = n(50212),
          l = n(71024),
          s = n.n(l);
        let u = (e) => {
          let t = (0, a.c)(10),
            { content: n, style: i, className: r, children: c } = e;
          if (n) {
            let e, a;
            return (
              t[0] !== n
                ? ((e = { __html: n }), (t[0] = n), (t[1] = e))
                : (e = t[1]),
              t[2] !== r || t[3] !== i || t[4] !== e
                ? ((a = (0, o.jsx)("div", {
                    className: r,
                    dangerouslySetInnerHTML: e,
                    style: i,
                  })),
                  (t[2] = r),
                  (t[3] = i),
                  (t[4] = e),
                  (t[5] = a))
                : (a = t[5]),
              a
            );
          }
          if (!c) return null;
          {
            let e;
            return (
              t[6] !== c || t[7] !== r || t[8] !== i
                ? ((e = (0, o.jsx)("div", {
                    className: r,
                    style: i,
                    children: c,
                  })),
                  (t[6] = c),
                  (t[7] = r),
                  (t[8] = i),
                  (t[9] = e))
                : (e = t[9]),
              e
            );
          }
        };
        var d = n(30561),
          _ = n.n(d);
        let m = (e) => {
          let t,
            n,
            i,
            c = (0, a.c)(6),
            { lastFileUpdatedOn: l } = e,
            { i18n: s } = (0, r.uB)();
          return (
            c[0] === Symbol.for("react.memo_cache_sentinel")
              ? ((t = (0, o.jsx)("h3", {
                  className: _().title,
                  children: (0, o.jsx)(r.x6, { id: "game.lastUpdated" }),
                })),
                (c[0] = t))
              : (t = c[0]),
            c[1] !== s || c[2] !== l
              ? ((n = s.date(l, {
                  year: "numeric",
                  month: "short",
                  day: "2-digit",
                  timeZone: "UTC",
                })),
                (c[1] = s),
                (c[2] = l),
                (c[3] = n))
              : (n = c[3]),
            c[4] !== n
              ? ((i = (0, o.jsxs)(o.Fragment, {
                  children: [
                    t,
                    (0, o.jsx)("p", { className: _().date, children: n }),
                  ],
                })),
                (c[4] = n),
                (c[5] = i))
              : (i = c[5]),
            i
          );
        };
        var y = n(50293),
          g = n(4230),
          h = n(27066);
        let p = () => {
          let e,
            t = (0, a.c)(3),
            n = i.useContext(g.A),
            r = (0, y.xl)(n),
            c = r ? h.Z : "100%",
            l = r ? h._ : "calc(100vw * 315/560)";
          return (
            t[0] !== l || t[1] !== c
              ? ((e = (0, o.jsx)("div", { style: { width: c, height: l } })),
                (t[0] = l),
                (t[1] = c),
                (t[2] = e))
              : (e = t[2]),
            e
          );
        };
        var B = n(49188),
          z = n.n(B);
        let f = s()(
            () => Promise.all([n.e(73167), n.e(68846)]).then(n.bind(n, 68846)),
            {
              loadableGenerated: { webpack: () => [68846] },
              loading: () => (0, o.jsx)(p, {}),
              ssr: !1,
            }
          ),
          b = (e) => {
            let t,
              n,
              i,
              l,
              s,
              d,
              _,
              y,
              g,
              h = (0, a.c)(22),
              { game: p } = e,
              { descriptionFirst: B, descriptionRest: b, controls: w } = p,
              k = B || "",
              A = b || "";
            h[0] !== p.faq
              ? ((t = p.faq || []), (h[0] = p.faq), (h[1] = t))
              : (t = h[1]);
            let S = t;
            return (
              h[2] === Symbol.for("react.memo_cache_sentinel")
                ? ((n = (0, c.A)(
                    z().styledHtmlDiv,
                    z().marginBlockEnd1,
                    "gameDescription_first"
                  )),
                  (h[2] = n))
                : (n = h[2]),
              h[3] !== k
                ? ((i = (0, o.jsx)(u, { className: n, content: k })),
                  (h[3] = k),
                  (h[4] = i))
                : (i = h[4]),
              h[5] !== A
                ? ((l =
                    A.length > 0 &&
                    (0, o.jsx)(u, {
                      className: z().styledHtmlDiv,
                      content: A,
                    })),
                  (h[5] = A),
                  (h[6] = l))
                : (l = h[6]),
              h[7] !== p.lastFileUpdatedOn
                ? ((s =
                    p.lastFileUpdatedOn &&
                    (0, o.jsx)(m, {
                      lastFileUpdatedOn: new Date(p.lastFileUpdatedOn),
                    })),
                  (h[7] = p.lastFileUpdatedOn),
                  (h[8] = s))
                : (s = h[8]),
              h[9] !== w
                ? ((d =
                    w &&
                    (0, o.jsx)(u, {
                      className: z().styledHtmlDiv,
                      content: w,
                    })),
                  (h[9] = w),
                  (h[10] = d))
                : (d = h[10]),
              h[11] !== S
                ? ((_ =
                    S.length > 0 &&
                    (0, o.jsxs)(o.Fragment, {
                      children: [
                        (0, o.jsx)("h2", {
                          className: z().faqTitle,
                          children: (0, o.jsx)(r.x6, {
                            id: "game.info.faq.title",
                          }),
                        }),
                        (0, o.jsx)(u, {
                          className: (0, c.A)(
                            z().styledHtmlDiv,
                            z().marginBlockEnd1
                          ),
                          children: S.map(v),
                        }),
                      ],
                    })),
                  (h[11] = S),
                  (h[12] = _))
                : (_ = h[12]),
              h[13] !== p.videoUrl
                ? ((y =
                    p.videoUrl &&
                    (0, o.jsx)(o.Fragment, {
                      children: (0, o.jsxs)(u, {
                        className: z().styledHtmlDiv,
                        children: [
                          (0, o.jsx)("h2", {
                            className: z().marginBlockEnd1,
                            children: (0, o.jsx)(r.x6, {
                              id: "game.info.video.title",
                            }),
                          }),
                          (0, o.jsx)(f, {
                            videoId: p.videoUrl,
                            playLabel: "YouTube video player",
                          }),
                        ],
                      }),
                    })),
                  (h[13] = p.videoUrl),
                  (h[14] = y))
                : (y = h[14]),
              h[15] !== i ||
              h[16] !== l ||
              h[17] !== s ||
              h[18] !== d ||
              h[19] !== _ ||
              h[20] !== y
                ? ((g = (0, o.jsxs)(o.Fragment, {
                    children: [i, l, s, d, _, y],
                  })),
                  (h[15] = i),
                  (h[16] = l),
                  (h[17] = s),
                  (h[18] = d),
                  (h[19] = _),
                  (h[20] = y),
                  (h[21] = g))
                : (g = h[21]),
              g
            );
          };
        function v(e) {
          return (0, o.jsxs)(
            "div",
            {
              children: [
                (0, o.jsx)("h3", { children: e.q }),
                (0, o.jsx)("div", { dangerouslySetInnerHTML: { __html: e.a } }),
              ],
            },
            e.q
          );
        }
      },
      64420: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => _ });
        var o = n(6029),
          a = n(75155);
        n(55729);
        var i = n(50212),
          r = n(2610),
          c = n.n(r);
        let l = { outline: "#f47621", core: "#f8b229" },
          s = { outline: "#b9bdc6", core: "#e6e8ec" },
          u = { calm: 1, fast: 0.65 },
          d = (e) => {
            let t,
              n,
              r,
              l = (0, a.c)(7),
              { className: s, children: u } = e;
            return (
              l[0] !== s
                ? ((t = (0, i.A)(c().layer, s)), (l[0] = s), (l[1] = t))
                : (t = l[1]),
              l[2] !== u
                ? ((n = (0, o.jsx)("svg", {
                    viewBox: "0 0 100 120",
                    focusable: "false",
                    children: u,
                  })),
                  (l[2] = u),
                  (l[3] = n))
                : (n = l[3]),
              l[4] !== t || l[5] !== n
                ? ((r = (0, o.jsx)("span", { className: t, children: n })),
                  (l[4] = t),
                  (l[5] = n),
                  (l[6] = r))
                : (r = l[6]),
              r
            );
          },
          _ = (e) => {
            let t,
              n,
              r,
              _,
              m,
              y,
              g,
              h,
              p = (0, a.c)(23),
              {
                lit: B,
                speed: z,
                offsetMs: f,
                className: b,
                bodyClassName: v,
              } = e,
              w = B ? l : s,
              k = `-${void 0 === f ? 0 : f}ms`,
              A = u[void 0 === z ? "calm" : z];
            p[0] !== k || p[1] !== A
              ? ((t = { "--flame-offset": k, "--flame-speed": A }),
                (p[0] = k),
                (p[1] = A),
                (p[2] = t))
              : (t = p[2]);
            let S = t;
            return (
              p[3] !== b
                ? ((n = (0, i.A)(c().flame, b)), (p[3] = b), (p[4] = n))
                : (n = p[4]),
              p[5] !== w.outline
                ? ((r = (0, o.jsx)("path", {
                    d: "M50 118C46 118.2 43.2 117.5 40 116.5C36.8 115.5 33.7 113.8 31 112C28.3 110.2 26.2 108.3 24 106C21.8 103.7 19.7 100.8 18 98C16.3 95.2 14.8 92 14 89C13.2 86 13.1 83.2 13 80C12.9 76.8 13.2 73.2 13.5 70C13.8 66.8 14.3 64 15 61C15.7 58 16.5 54.7 17.5 52C18.5 49.3 19.6 46.9 21 45C22.4 43.1 24.2 41.4 26 40.5C27.8 39.6 30 39.3 32 39.5C34 39.7 36 40.6 38 41.5C40 42.4 41.7 43.7 44 45C46.3 46.3 48.3 47.8 52 49.5C55.7 51.2 61.3 53.1 66 55C70.7 56.9 76.7 58.7 80 61C83.3 63.3 84.6 66.2 85.8 69C87 71.8 87.1 75 87.2 78C87.3 81 87.4 83.7 86.5 87C85.6 90.3 83.9 94.7 82 98C80.1 101.3 78 104.2 75 107C72 109.8 68.2 113.2 64 115C59.8 116.8 54 117.8 50 118Z",
                    fill: w.outline,
                  })),
                  (p[5] = w.outline),
                  (p[6] = r))
                : (r = p[6]),
              p[7] !== v || p[8] !== r
                ? ((_ = (0, o.jsx)(d, { className: v, children: r })),
                  (p[7] = v),
                  (p[8] = r),
                  (p[9] = _))
                : (_ = p[9]),
              p[10] !== w.outline
                ? ((m = (0, o.jsx)(d, {
                    className: c().flick,
                    children: (0, o.jsx)("path", {
                      d: "M17.5 56C15.9 54.3 18 49.8 18.5 47C19 44.2 19.7 41.3 20.5 39C21.3 36.7 22.4 34.5 23.5 33C24.6 31.6 25.8 30.5 27 30.3C28.2 30.1 29.8 31 31 31.8C32.2 32.6 33.4 33.9 34.5 35C35.6 36.1 36.7 37.3 37.5 38.5C38.3 39.7 39.6 40.1 39.5 42C39.4 43.9 38.9 47.5 37 50C35.1 52.5 31.2 56 28 57C24.8 58 19.1 57.7 17.5 56Z",
                      fill: w.outline,
                    }),
                  })),
                  (p[10] = w.outline),
                  (p[11] = m))
                : (m = p[11]),
              p[12] !== w.outline
                ? ((y = (0, o.jsx)(d, {
                    className: c().tongue,
                    children: (0, o.jsx)("path", {
                      d: "M37.5 44C37.2 41.7 38 41.2 38.5 40C39 38.8 39.8 37.8 40.5 36.5C41.2 35.2 42.2 33.7 43 32C43.8 30.3 44.2 28.6 45 26.5C45.8 24.4 46.4 21.6 47.5 19.5C48.6 17.4 49.9 15.2 51.5 13.8C53.1 12.4 55.2 11.1 57 11C58.8 10.9 60.8 11.7 62.5 13C64.2 14.3 65.4 16.7 67 19C68.6 21.3 70.3 24.1 72 27C73.7 29.9 75.5 33.5 77 36.5C78.5 39.5 79.8 42.2 81 45C82.2 47.8 83.2 50.3 84 53C84.8 55.7 85.1 58.2 85.5 61C85.9 63.8 86.3 67 86.5 69.5C86.7 72 87 73.9 86.6 76C86.2 78.1 85.8 80.8 84 82C82.2 83.2 79.3 83.7 76 83C72.7 82.3 68.3 80.8 64 78C59.7 75.2 54 70 50 66C46 62 42.1 57.7 40 54C37.9 50.3 37.8 46.3 37.5 44Z",
                      fill: w.outline,
                    }),
                  })),
                  (p[12] = w.outline),
                  (p[13] = y))
                : (y = p[13]),
              p[14] !== w.core
                ? ((g = (0, o.jsx)(d, {
                    className: c().core,
                    children: (0, o.jsx)("ellipse", {
                      cx: "49.7",
                      cy: "81.2",
                      rx: "29.6",
                      ry: "31.7",
                      fill: w.core,
                    }),
                  })),
                  (p[14] = w.core),
                  (p[15] = g))
                : (g = p[15]),
              p[16] !== S ||
              p[17] !== y ||
              p[18] !== g ||
              p[19] !== n ||
              p[20] !== _ ||
              p[21] !== m
                ? ((h = (0, o.jsxs)("span", {
                    className: n,
                    style: S,
                    "aria-hidden": !0,
                    children: [_, m, y, g],
                  })),
                  (p[16] = S),
                  (p[17] = y),
                  (p[18] = g),
                  (p[19] = n),
                  (p[20] = _),
                  (p[21] = m),
                  (p[22] = h))
                : (h = p[22]),
              h
            );
          };
      },
      68006: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => u });
        var o = n(6029),
          a = n(75155),
          i = n(55729),
          r = n(50212),
          c = n(56760),
          l = n(24542),
          s = n.n(l);
        let u = (e) => {
          let t,
            n,
            l,
            u,
            d,
            _,
            m,
            y,
            g,
            h = (0, a.c)(31),
            {
              anchorEl: p,
              open: B,
              placement: z,
              gap: f,
              className: b,
              role: v,
              "aria-label": w,
              onClick: k,
              children: A,
            } = e,
            S = void 0 === f ? 12 : f,
            x = i.useRef(null),
            I = i.useRef(void 0),
            [N, G] = i.useState(null);
          h[0] !== p || h[1] !== S || h[2] !== z
            ? ((t = () => {
                if (!p) return null;
                let e = p.getBoundingClientRect(),
                  t = x.current?.offsetWidth || 300,
                  n = e.left + e.width / 2,
                  o = Math.max(16, window.innerWidth - t - 16),
                  a = Math.min(Math.max(n - t / 2, 16), o),
                  i = Math.min(Math.max(n - a, 28), t - 28);
                return "bottom" === z
                  ? { left: a, top: e.bottom + S, arrowLeft: i }
                  : {
                      left: a,
                      bottom: window.innerHeight - e.top + S,
                      arrowLeft: i,
                    };
              }),
              (h[0] = p),
              (h[1] = S),
              (h[2] = z),
              (h[3] = t))
            : (t = h[3]);
          let C = t,
            [T, P] = i.useState(B),
            [j, L] = i.useState(!1),
            [F, M] = i.useState(B);
          B !== F && (M(B), B ? P(!0) : L(!1)),
            h[4] !== B
              ? ((n = () => {
                  if (!B) {
                    let e = window.setTimeout(() => P(!1), 200);
                    return () => window.clearTimeout(e);
                  }
                  let e = window.requestAnimationFrame(() => L(!0));
                  return () => window.cancelAnimationFrame(e);
                }),
                (l = [B]),
                (h[4] = B),
                (h[5] = n),
                (h[6] = l))
              : ((n = h[5]), (l = h[6])),
            i.useEffect(n, l);
          let E = B || T,
            O = B && j,
            [D, U] = i.useState(p),
            [R, W] = i.useState(E);
          if (
            ((p !== D || E !== R) && (U(p), W(E), (p && E) || G(null)),
            h[7] !== p || h[8] !== C || h[9] !== E
              ? ((u = () => {
                  if (!p || !E) return;
                  let e = () => {
                    void 0 === I.current &&
                      (I.current = window.requestAnimationFrame(() => {
                        (I.current = void 0), G(C());
                      }));
                  };
                  return (
                    e(),
                    window.addEventListener("scroll", e, !0),
                    window.addEventListener("resize", e),
                    () => {
                      window.removeEventListener("scroll", e, !0),
                        window.removeEventListener("resize", e),
                        void 0 !== I.current &&
                          (window.cancelAnimationFrame(I.current),
                          (I.current = void 0));
                    }
                  );
                }),
                (d = [p, E, C]),
                (h[7] = p),
                (h[8] = C),
                (h[9] = E),
                (h[10] = u),
                (h[11] = d))
              : ((u = h[10]), (d = h[11])),
            i.useEffect(u, d),
            !p || !E || "u" < typeof document)
          )
            return null;
          let H = "bottom" === z ? s().pointsUp : s().pointsDown,
            q = O && N && s().shown;
          h[12] !== b || h[13] !== H || h[14] !== q
            ? ((_ = (0, r.A)(s().bubble, H, q, b)),
              (h[12] = b),
              (h[13] = H),
              (h[14] = q),
              (h[15] = _))
            : (_ = h[15]);
          let Z = N?.left ?? 0,
            J = N?.top,
            K = N?.bottom,
            X = N ? "visible" : "hidden";
          h[16] !== Z || h[17] !== J || h[18] !== K || h[19] !== X
            ? ((m = { left: Z, top: J, bottom: K, visibility: X }),
              (h[16] = Z),
              (h[17] = J),
              (h[18] = K),
              (h[19] = X),
              (h[20] = m))
            : (m = h[20]);
          let Q = N?.arrowLeft;
          return (
            h[21] !== Q
              ? ((y = (0, o.jsx)("span", {
                  className: s().arrow,
                  style: { left: Q },
                })),
                (h[21] = Q),
                (h[22] = y))
              : (y = h[22]),
            h[23] !== w ||
            h[24] !== A ||
            h[25] !== k ||
            h[26] !== v ||
            h[27] !== m ||
            h[28] !== y ||
            h[29] !== _
              ? ((g = (0, c.createPortal)(
                  (0, o.jsxs)("div", {
                    ref: x,
                    className: _,
                    style: m,
                    role: v,
                    "aria-label": w,
                    onClick: k,
                    children: [y, A],
                  }),
                  document.body
                )),
                (h[23] = w),
                (h[24] = A),
                (h[25] = k),
                (h[26] = v),
                (h[27] = m),
                (h[28] = y),
                (h[29] = _),
                (h[30] = g))
              : (g = h[30]),
            g
          );
        };
      },
      75403: (e, t, n) => {
        "use strict";
        n.d(t, { z: () => i });
        var o = n(16074),
          a = n(98417);
        function i(e, t, n) {
          let i = { type: o.k8 };
          (0, a.O)(e) && e.postMessage(i, "*"),
            (0, a.O)(t) && t.postMessage(i, "*"),
            (0, a.O)(n) && n.postMessage(i, "*");
        }
      },
      76097: (e, t, n) => {
        "use strict";
        n.d(t, { z: () => a });
        var o = n(58163);
        async function a(e) {
          if (await (0, o.Qe)()) return e();
        }
      },
      76318: (e) => {
        e.exports = {
          breadcrumbsList: "Breadcrumbs_breadcrumbsList__dpjjn",
          breadcrumbsItem: "Breadcrumbs_breadcrumbsItem__EDZD9",
          isCurrent: "Breadcrumbs_isCurrent__VuWK6",
          separator: "Breadcrumbs_separator__Ii92U",
        };
      },
      77257: (e, t, n) => {
        "use strict";
        n.d(t, { m: () => i, t: () => a });
        let o = new Set();
        function a(e) {
          o.forEach((t) => {
            t(e);
          });
        }
        function i(e) {
          return (
            o.add(e),
            () => {
              o.delete(e);
            }
          );
        }
      },
      78718: (e, t, n) => {
        "use strict";
        n.d(t, { Y: () => a, m: () => i });
        var o = n(71855);
        function a() {
          return "enabled" === (0, o.U)("czyExpIncreasedLeaderboardProminance")
            ? 176
            : 185;
        }
        function i(e) {
          return (e.hasLeaderboard || e.isPreview) && e.leaderboardOptions;
        }
      },
      84040: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => l });
        var o = n(55729),
          a = n(71237),
          i = n(4230),
          r = n(71684),
          c = n(74532);
        let l = () => {
          let { modelService: e, experimentService: t } = o.useContext(
              r.A
            ).services,
            n = o.useContext(i.A),
            { countryCode: l } = o.useContext(c.A),
            { clusterMap: s } = a.lF(),
            u = o.useRef(s);
          return (
            o.useEffect(() => {
              u.current = s;
            }, [s]),
            {
              getModelGames: o.useCallback(
                async (o) => {
                  let { numGames: a, gameId: i, place: r } = o,
                    c = o.forceModelName ?? t.getModelName(r);
                  return e.getRelatedModelGames(c, n, l, u.current, {
                    place: r,
                    gameId: i,
                    page: 1,
                    size: a,
                  });
                },
                [n, l, t, e]
              ),
            }
          );
        };
      },
      84921: (e) => {
        e.exports = {
          czyButton: "gamePage_common_czyButton__OEJCg",
          "czyButton--contained--purple":
            "gamePage_common_czyButton--contained--purple__l1rBr",
          "czyButton--contained--white":
            "gamePage_common_czyButton--contained--white__2uY10",
          "czyButton--contained--grey":
            "gamePage_common_czyButton--contained--grey__1DOjt",
          "czyButton--contained--warning":
            "gamePage_common_czyButton--contained--warning__n1WLx",
          "czyButton--contained--alert":
            "gamePage_common_czyButton--contained--alert__p6_8R",
          "czyButton--contained--success":
            "gamePage_common_czyButton--contained--success__7WrU9",
          "czyButton--contained--black":
            "gamePage_common_czyButton--contained--black__oBdCE",
          "czyButton--contained--green-gradient":
            "gamePage_common_czyButton--contained--green-gradient__UKS1F",
          "czyButton--contained--animated-green-gradient":
            "gamePage_common_czyButton--contained--animated-green-gradient__tyk_s",
          "scroll-gradient": "gamePage_common_scroll-gradient__eCYcB",
          "czyButton--outlined--purple":
            "gamePage_common_czyButton--outlined--purple__j2Z2N",
          "czyButton--link--purple":
            "gamePage_common_czyButton--link--purple__ve_RX",
          "czyButton--outlined--white":
            "gamePage_common_czyButton--outlined--white__tkUd_",
          "czyButton--link--white":
            "gamePage_common_czyButton--link--white__oTYWa",
          "czyButton--outlined--grey":
            "gamePage_common_czyButton--outlined--grey__x_8TF",
          "czyButton--link--grey":
            "gamePage_common_czyButton--link--grey__KkNz8",
          "czyButton--outlined--warning":
            "gamePage_common_czyButton--outlined--warning__7YW8n",
          "czyButton--link--warning":
            "gamePage_common_czyButton--link--warning__zTUnD",
          "czyButton--outlined--alert":
            "gamePage_common_czyButton--outlined--alert___TxUC",
          "czyButton--link--alert":
            "gamePage_common_czyButton--link--alert__pokiu",
          "czyButton--outlined--success":
            "gamePage_common_czyButton--outlined--success__uj03D",
          "czyButton--link--success":
            "gamePage_common_czyButton--link--success__ZQKuo",
          "czyButton--outlined": "gamePage_common_czyButton--outlined__7ByvT",
          "czyButton--disabled": "gamePage_common_czyButton--disabled__yaRpM",
          "czyButton--height50": "gamePage_common_czyButton--height50__7z9Ab",
          "czyButton--height34": "gamePage_common_czyButton--height34__oYaY0",
          "czyButton--height28": "gamePage_common_czyButton--height28__zAAHe",
          "czyButton--fullWidth": "gamePage_common_czyButton--fullWidth__c1bvb",
          "czyButton--headerIcon":
            "gamePage_common_czyButton--headerIcon___xSIi",
          "czyButton--headerIcon--desktop":
            "gamePage_common_czyButton--headerIcon--desktop__v2MjK",
          "czyButton--headerIcon--mobile":
            "gamePage_common_czyButton--headerIcon--mobile__lLc4O",
          "czyButton--headerIcon--withLabel":
            "gamePage_common_czyButton--headerIcon--withLabel__HZ3WJ",
          infoContainer: "gamePage_common_infoContainer__94uaG",
          gameGrid: "gamePage_common_gameGrid__jTVRK",
        };
      },
      87222: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => s });
        var o = n(6029),
          a = n(75155);
        n(55729);
        var i = n(94618),
          r = n(87473),
          c = n(49188),
          l = n.n(c);
        let s = (e) => {
          let t,
            n,
            i,
            c,
            s,
            d = (0, a.c)(15),
            { game: _ } = e,
            {
              appStoreUrl: m,
              playStoreUrl: y,
              steamStoreUrl: g,
              msnStoreUrl: h,
            } = _,
            p = "ios" === (0, r.t)(),
            B = u;
          return (
            d[0] !== m
              ? ((t = B("store-logos/apple-store.png", "Apple Store Logo", m)),
                (d[0] = m),
                (d[1] = t))
              : (t = d[1]),
            d[2] !== p || d[3] !== y
              ? ((n =
                  !p &&
                  B(
                    "store-logos/google-store-button.png",
                    "Google Play Logo",
                    y
                  )),
                (d[2] = p),
                (d[3] = y),
                (d[4] = n))
              : (n = d[4]),
            d[5] !== p || d[6] !== g
              ? ((i =
                  !p &&
                  B("store-logos/steam-button.png", "Steam Store Logo", g)),
                (d[5] = p),
                (d[6] = g),
                (d[7] = i))
              : (i = d[7]),
            d[8] !== h
              ? ((c = B(
                  "store-logos/msn-store-button.png",
                  "MSN Store Logo",
                  h
                )),
                (d[8] = h),
                (d[9] = c))
              : (c = d[9]),
            d[10] !== t || d[11] !== n || d[12] !== i || d[13] !== c
              ? ((s = (0, o.jsxs)("div", {
                  className: l().gameInfoStoreButtonsContainer,
                  children: [t, n, i, c],
                })),
                (d[10] = t),
                (d[11] = n),
                (d[12] = i),
                (d[13] = c),
                (d[14] = s))
              : (s = d[14]),
            s
          );
        };
        function u(e, t, n) {
          return n
            ? (0, o.jsx)("a", {
                href: n,
                target: "_blank",
                rel: "noreferrer nofollow noopener",
                children: (0, o.jsx)("img", { src: (0, i.Ay)(e), alt: t }),
              })
            : null;
        }
      },
      87473: (e, t, n) => {
        "use strict";
        n.d(t, { t: () => r });
        var o = n(55729),
          a = n(74339);
        let i = () => () => {};
        function r() {
          return (0, o.useSyncExternalStore)(i, l, c);
        }
        function c() {
          return "web";
        }
        function l() {
          return a.Capacitor.getPlatform();
        }
      },
      89722: (e, t, n) => {
        "use strict";
        n.d(t, { t: () => s });
        var o = n(75155),
          a = n(55729),
          i = n(10945),
          r = n(7234),
          c = n(71684),
          l = n(86381);
        function s() {
          let e,
            t,
            n,
            s,
            u = (0, o.c)(4),
            [d] = (0, r.n)(l.vI),
            _ =
              ((n = (0, o.c)(2)),
              (s = (0, i.m)()),
              n[0] !== s
                ? ((t = (e) =>
                    s.readQuery({ query: l.u$, variables: { gameId: e } })
                      ?.gameNotificationPreferencesForGame ??
                    s
                      .readQuery({ query: l.h4 })
                      ?.gameNotificationPreferences.find(
                        (t) => t.gameId === e
                      )),
                  (n[0] = s),
                  (n[1] = t))
                : (t = n[1]),
              t),
            { crazyAnalyticsService: m } = a.useContext(c.A).services;
          return (
            u[0] !== m || u[1] !== _ || u[2] !== d
              ? ((e = async (e, t, n) => {
                  let o = _(e);
                  await d({
                    variables: { input: { gameId: e, enabled: t } },
                    optimisticResponse: o && {
                      setGameNotificationsEnabled: {
                        ...o,
                        types: o.types.map((e) => ({ ...e, enabled: t })),
                      },
                    },
                  }),
                    m.sendGameNotificationsSubscriptionEvent({
                      action: t ? "subscribed" : "unsubscribed",
                      target: e,
                      clickOrigin: n,
                    });
                }),
                (u[0] = m),
                (u[1] = _),
                (u[2] = d),
                (u[3] = e))
              : (e = u[3]),
            e
          );
        }
      },
      90135: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => g });
        var o = n(6029),
          a = n(75155),
          i = n(55729),
          r = n(97324),
          c = n(79942),
          l = n(50212),
          s = n(50293),
          u = n(4230),
          d = n(71684),
          _ = n(8552),
          m = n(28333),
          y = n.n(m);
        let g = (e) => {
          let t,
            n,
            m,
            g,
            h,
            p,
            B,
            z,
            f,
            b,
            v,
            w,
            k,
            A = (0, a.c)(29),
            {
              height: S,
              onClick: x,
              playAnimation: I,
              addDelayTimeMs: N,
              center: G,
            } = e,
            C = void 0 !== I && I,
            { i18n: T } = (0, c.uB)(),
            [P, j] = i.useState(0),
            [L, F] = i.useState(!1),
            [, M] = i.useTransition(),
            E = i.useContext(u.A),
            { isBackToTopEnabled: O, isBackToTopVisible: D } = i.useContext(
              _.R
            ),
            { crazyAnalyticsService: U } = i.useContext(d.A).services;
          A[0] !== N
            ? ((t = () => {
                let e,
                  t = () => {
                    e && window.clearTimeout(e),
                      (e = window.setTimeout(() => {
                        M(() => {
                          j(window.scrollY), F(!1);
                        });
                      }, N));
                  },
                  n = "onscrollend" in window;
                return (
                  n
                    ? window.addEventListener("scrollend", t, { passive: !0 })
                    : window.addEventListener("scroll", t, { passive: !0 }),
                  function () {
                    n
                      ? window.removeEventListener("scrollend", t)
                      : window.removeEventListener("scroll", t),
                      e && window.clearTimeout(e);
                  }
                );
              }),
              (n = [N]),
              (A[0] = N),
              (A[1] = t),
              (A[2] = n))
            : ((t = A[1]), (n = A[2])),
            i.useEffect(t, n),
            A[3] !== L
              ? ((m = () => {
                  if (!("onscrollend" in window) || L) return;
                  let e = () => {
                    M(() => {
                      F(!0);
                    });
                  };
                  return (
                    window.addEventListener("scroll", e, { passive: !0 }),
                    function () {
                      window.removeEventListener("scroll", e);
                    }
                  );
                }),
                (g = [L]),
                (A[3] = L),
                (A[4] = m),
                (A[5] = g))
              : ((m = A[4]), (g = A[5])),
            i.useEffect(m, g),
            A[6] !== U || A[7] !== x
              ? ((h = () => {
                  window.scrollTo({ top: 0, left: 0, behavior: "smooth" }),
                    U.userAction("navigation", "back-to-game"),
                    x && x();
                }),
                (A[6] = U),
                (A[7] = x),
                (A[8] = h))
              : (h = A[8]);
          let R = h;
          if (P < S || !O || !D) return null;
          A[9] !== E || A[10] !== C
            ? ((p = C && (0, s.xl)(E)), (A[9] = E), (A[10] = C), (A[11] = p))
            : (p = A[11]);
          let W = p,
            H = L && y().hide,
            q = G && y().center;
          A[12] !== H || A[13] !== q
            ? ((B = (0, l.A)(y().buttonContainer, H, q)),
              (A[12] = H),
              (A[13] = q),
              (A[14] = B))
            : (B = A[14]);
          let Z = !L && W && y().playAnimation;
          return (
            A[15] !== Z
              ? ((z = (0, l.A)(y().bounce, Z)), (A[15] = Z), (A[16] = z))
              : (z = A[16]),
            A[17] === Symbol.for("react.memo_cache_sentinel")
              ? ((f = { position: "left", code: "arrow_up" }), (A[17] = f))
              : (f = A[17]),
            A[18] !== T
              ? ((b = T._("game.backToGame")), (A[18] = T), (A[19] = b))
              : (b = A[19]),
            A[20] !== R || A[21] !== b
              ? ((v = (0, o.jsx)(r.$, {
                  tone: "purple",
                  icon: f,
                  label: b,
                  onClick: R,
                  "data-testid": "back-to-top",
                })),
                (A[20] = R),
                (A[21] = b),
                (A[22] = v))
              : (v = A[22]),
            A[23] !== z || A[24] !== v
              ? ((w = (0, o.jsx)("div", { className: z, children: v })),
                (A[23] = z),
                (A[24] = v),
                (A[25] = w))
              : (w = A[25]),
            A[26] !== B || A[27] !== w
              ? ((k = (0, o.jsx)("div", { className: B, children: w })),
                (A[26] = B),
                (A[27] = w),
                (A[28] = k))
              : (k = A[28]),
            k
          );
        };
      },
      90258: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => z });
        var o = n(6029),
          a = n(75155),
          i = n(55729),
          r = n(89964),
          c = n(79942),
          l = n(71024),
          s = n.n(l),
          u = n(50293),
          d = n(93389),
          _ = n(4230),
          m = n(93800),
          y = n(71684),
          g = n(37434),
          h = n(14469),
          p = n.n(h);
        let B = s()(
            () =>
              Promise.all([n.e(62005), n.e(47383), n.e(73992), n.e(3029)]).then(
                n.bind(n, 3029)
              ),
            { loadableGenerated: { webpack: () => [3029] } }
          ),
          z = (e) => {
            let t,
              n,
              l,
              s,
              h,
              z,
              v,
              w,
              k,
              A,
              S = (0, a.c)(26),
              { game: x } = e,
              [I, N] = (0, i.useState)(!1),
              { routeHelper: G } = i.useContext(d.A),
              C = i.useContext(_.A);
            S[0] !== C
              ? ((t = (0, u.xl)(C)), (S[0] = C), (S[1] = t))
              : (t = S[1]);
            let T = t,
              { crazyAnalyticsService: P } = i.useContext(y.A).services;
            S[2] !== P || S[3] !== x.name || S[4] !== T || S[5] !== G
              ? ((n = async () => {
                  P.sendModalEvent(
                    "share_game",
                    "open",
                    "share_game",
                    "share_game_button"
                  );
                  let e = { title: x.name, url: G.getCanonicalCurrentUrl() },
                    t =
                      !T &&
                      window.navigator.canShare &&
                      window.navigator.canShare(e);
                  if (window.navigator.share && t)
                    try {
                      await window.navigator.share(e);
                    } catch (e) {
                      console.log("User has aborted share", e);
                    }
                  else N(!0);
                }),
                (S[2] = P),
                (S[3] = x.name),
                (S[4] = T),
                (S[5] = G),
                (S[6] = n))
              : (n = S[6]);
            let j = n;
            S[7] === Symbol.for("react.memo_cache_sentinel")
              ? ((l = () => {
                  N(!1);
                }),
                (S[7] = l))
              : (l = S[7]);
            let L = l;
            S[8] !== x.desktopUrl || S[9] !== j || S[10] !== G
              ? ((s = (e) => {
                  !e.data ||
                    e.data.type !== r.x ||
                    (G.isMessageFromGameframe(e, x.desktopUrl) &&
                      "share" === e.data.event &&
                      j());
                }),
                (S[8] = x.desktopUrl),
                (S[9] = j),
                (S[10] = G),
                (S[11] = s))
              : (s = S[11]);
            let F = s;
            S[12] !== F
              ? ((h = () => (
                  window.addEventListener("message", F),
                  () => {
                    window.removeEventListener("message", F);
                  }
                )),
                (z = [F]),
                (S[12] = F),
                (S[13] = h),
                (S[14] = z))
              : ((h = S[13]), (z = S[14])),
              (0, i.useEffect)(h, z),
              S[15] !== x || S[16] !== I
                ? ((v = () =>
                    I ? (0, o.jsx)(B, { game: x, onClose: L }) : null),
                  (S[15] = x),
                  (S[16] = I),
                  (S[17] = v))
                : (v = S[17]);
            let M = v;
            return (
              S[18] !== T || S[19] !== j
                ? ((w = T
                    ? (0, o.jsxs)(g.A, {
                        onClick: () => {
                          j().catch(f);
                        },
                        variant: T ? "contained" : "link",
                        color: T ? "grey" : "white",
                        height: 34,
                        dataTestId: "game-share-button",
                        children: [
                          (0, o.jsx)(m.A, { name: "share" }),
                          (0, o.jsx)("span", {
                            children: (0, o.jsx)(c.x6, {
                              id: "game.share.button",
                            }),
                          }),
                        ],
                      })
                    : (0, o.jsx)(g.A, {
                        className: p().gameActionsButton,
                        onClick: () => {
                          j().catch(b);
                        },
                        variant: T ? "contained" : "link",
                        color: T ? "grey" : "white",
                        height: 34,
                        dataTestId: "game-share-button",
                        children: (0, o.jsx)(m.A, { name: "share" }),
                      })),
                  (S[18] = T),
                  (S[19] = j),
                  (S[20] = w))
                : (w = S[20]),
              S[21] !== M ? ((k = M()), (S[21] = M), (S[22] = k)) : (k = S[22]),
              S[23] !== w || S[24] !== k
                ? ((A = (0, o.jsxs)(o.Fragment, { children: [w, k] })),
                  (S[23] = w),
                  (S[24] = k),
                  (S[25] = A))
                : (A = S[25]),
              A
            );
          };
        function f(e) {
          console.error("Open modal failed", e);
        }
        function b(e) {
          console.error("Open modal failed", e);
        }
      },
      92995: (e) => {
        e.exports = {
          czyButton: "GameSummary_czyButton__afHu5",
          "czyButton--contained--purple":
            "GameSummary_czyButton--contained--purple__GB2jG",
          "czyButton--contained--white":
            "GameSummary_czyButton--contained--white__6QD2J",
          "czyButton--contained--grey":
            "GameSummary_czyButton--contained--grey__CXoe4",
          "czyButton--contained--warning":
            "GameSummary_czyButton--contained--warning___SZLP",
          "czyButton--contained--alert":
            "GameSummary_czyButton--contained--alert__aZP5k",
          "czyButton--contained--success":
            "GameSummary_czyButton--contained--success__ndlmS",
          "czyButton--contained--black":
            "GameSummary_czyButton--contained--black__uBgrS",
          "czyButton--contained--green-gradient":
            "GameSummary_czyButton--contained--green-gradient__JOjLz",
          "czyButton--contained--animated-green-gradient":
            "GameSummary_czyButton--contained--animated-green-gradient__9xd4u",
          "scroll-gradient": "GameSummary_scroll-gradient__zbvwu",
          "czyButton--outlined--purple":
            "GameSummary_czyButton--outlined--purple__3XMr6",
          "czyButton--link--purple":
            "GameSummary_czyButton--link--purple__rUMUn",
          "czyButton--outlined--white":
            "GameSummary_czyButton--outlined--white__FS_S6",
          "czyButton--link--white": "GameSummary_czyButton--link--white__hl8P4",
          "czyButton--outlined--grey":
            "GameSummary_czyButton--outlined--grey__gOrTz",
          "czyButton--link--grey": "GameSummary_czyButton--link--grey__y5Qs0",
          "czyButton--outlined--warning":
            "GameSummary_czyButton--outlined--warning__VLAwQ",
          "czyButton--link--warning":
            "GameSummary_czyButton--link--warning__PHyFn",
          "czyButton--outlined--alert":
            "GameSummary_czyButton--outlined--alert__p8QzU",
          "czyButton--link--alert": "GameSummary_czyButton--link--alert__SJ77y",
          "czyButton--outlined--success":
            "GameSummary_czyButton--outlined--success__XAEn_",
          "czyButton--link--success":
            "GameSummary_czyButton--link--success__FZQ__",
          "czyButton--outlined": "GameSummary_czyButton--outlined__2wLvr",
          "czyButton--disabled": "GameSummary_czyButton--disabled__vUA3S",
          "czyButton--height50": "GameSummary_czyButton--height50__EBMFj",
          "czyButton--height34": "GameSummary_czyButton--height34__GnILZ",
          "czyButton--height28": "GameSummary_czyButton--height28__3kvwX",
          "czyButton--fullWidth": "GameSummary_czyButton--fullWidth__5N8nj",
          "czyButton--headerIcon": "GameSummary_czyButton--headerIcon__GqIZ0",
          "czyButton--headerIcon--desktop":
            "GameSummary_czyButton--headerIcon--desktop__rTQNZ",
          "czyButton--headerIcon--mobile":
            "GameSummary_czyButton--headerIcon--mobile__2Wlpw",
          "czyButton--headerIcon--withLabel":
            "GameSummary_czyButton--headerIcon--withLabel__lEAEz",
          gameSummaryTable: "GameSummary_gameSummaryTable__KxE9A",
          gameTableRowHeader: "GameSummary_gameTableRowHeader__qmvU_",
          gameTableRowContent: "GameSummary_gameTableRowContent__RW5fE",
          wikiLinks: "GameSummary_wikiLinks__xu_24",
        };
      },
      94448: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => o });
        let o = function (e) {
          if (e.sandbox) {
            let t =
              "allow-forms allow-modals allow-orientation-lock allow-pointer-lock allow-presentation allow-scripts allow-same-origin allow-downloads ";
            return (
              e.disallowSandboxPopups ||
                (t += " allow-popups allow-popups-to-escape-sandbox"),
              t
            );
          }
        };
      },
      96991: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => p });
        var o = n(6029),
          a = n(75155),
          i = n(55729),
          r = n(32994),
          c = n(8420),
          l = n(50212),
          s = n(76318),
          u = n.n(s);
        function d(e) {
          let t,
            n,
            i,
            s,
            d,
            _,
            m,
            y,
            g,
            h,
            p,
            B = (0, a.c)(27);
          B[0] !== e
            ? (({
                items: n,
                onNavigate: i,
                onPrefetch: s,
                prefetch: _,
                className: t,
                "aria-label": m,
                ...d
              } = e),
              (B[0] = e),
              (B[1] = t),
              (B[2] = n),
              (B[3] = i),
              (B[4] = s),
              (B[5] = d),
              (B[6] = _),
              (B[7] = m))
            : ((t = B[1]),
              (n = B[2]),
              (i = B[3]),
              (s = B[4]),
              (d = B[5]),
              (_ = B[6]),
              (m = B[7]));
          let z = void 0 !== _ && _,
            f = void 0 === m ? "Breadcrumb" : m;
          if (
            (B[8] !== t
              ? ((y = (0, l.A)(u().breadcrumbs, t)), (B[8] = t), (B[9] = y))
              : (y = B[9]),
            B[10] !== n || B[11] !== i || B[12] !== s || B[13] !== z)
          ) {
            let e;
            B[15] !== n.length || B[16] !== i || B[17] !== s || B[18] !== z
              ? ((e = (e, t) => {
                  let { label: a, href: l, onClick: d, prefetch: _ } = e,
                    m = void 0 === _ ? z : _,
                    y = t === n.length - 1;
                  return (0, o.jsxs)(
                    "li",
                    {
                      className: u().breadcrumbsItem,
                      children: [
                        y || void 0 === l
                          ? (0, o.jsx)("span", {
                              className: u().isCurrent,
                              "aria-current": y ? "page" : void 0,
                              children: a,
                            })
                          : (0, o.jsx)(c.N, {
                              href: l,
                              onClick: d,
                              onNavigate: i,
                              onPrefetch: s,
                              prefetch: m,
                              children: a,
                            }),
                        !y &&
                          (0, o.jsx)(r.I, {
                            className: u().separator,
                            name: "chevron_right",
                            size: "xsmall",
                          }),
                      ],
                    },
                    t
                  );
                }),
                (B[15] = n.length),
                (B[16] = i),
                (B[17] = s),
                (B[18] = z),
                (B[19] = e))
              : (e = B[19]),
              (g = n.map(e)),
              (B[10] = n),
              (B[11] = i),
              (B[12] = s),
              (B[13] = z),
              (B[14] = g);
          } else g = B[14];
          return (
            B[20] !== g
              ? ((h = (0, o.jsx)("ol", {
                  className: u().breadcrumbsList,
                  children: g,
                })),
                (B[20] = g),
                (B[21] = h))
              : (h = B[21]),
            B[22] !== f || B[23] !== d || B[24] !== y || B[25] !== h
              ? ((p = (0, o.jsx)("nav", {
                  ...d,
                  "aria-label": f,
                  className: y,
                  children: h,
                })),
                (B[22] = f),
                (B[23] = d),
                (B[24] = y),
                (B[25] = h),
                (B[26] = p))
              : (p = B[26]),
            p
          );
        }
        var _ = n(79942),
          m = n(93389),
          y = n(27932),
          g = n(47004),
          h = n(85036);
        let p = (e) => {
          let t,
            n,
            r,
            c,
            l,
            s = (0, a.c)(11),
            { hierarchy: u, currentLabel: p, className: B, dataTestId: z } = e,
            { routeHelper: f } = i.useContext(m.A),
            { i18n: b } = (0, _.uB)(),
            { handleNavigate: v, handlePrefetch: w } = (0, y.i)();
          s[0] !== b
            ? ((t = b._("common.header.games")), (s[0] = b), (s[1] = t))
            : (t = s[1]),
            s[2] !== f
              ? ((n = f.homePageLink()), (s[2] = f), (s[3] = n))
              : (n = s[3]),
            s[4] !== t || s[5] !== n.href
              ? ((r = { label: t, href: n.href, prefetch: !1 }),
                (s[4] = t),
                (s[5] = n.href),
                (s[6] = r))
              : (r = s[6]),
            s[7] !== f
              ? ((c = (e) => {
                  let { name: t, enSlug: n, isCategory: o } = e;
                  return {
                    label: t,
                    href: (0, h.Ox)(f, n, o),
                    onClick: (0, h.YA)(n) ? g.on : void 0,
                  };
                }),
                (s[7] = f),
                (s[8] = c))
              : (c = s[8]),
            s[9] !== p
              ? ((l = void 0 === p ? [] : [{ label: p }]),
                (s[9] = p),
                (s[10] = l))
              : (l = s[10]);
          let k = [r, ...(void 0 === u ? [] : u).map(c), ...l];
          return (0, o.jsx)(d, {
            className: B,
            "data-testid": z,
            items: k,
            onNavigate: v,
            onPrefetch: w,
            prefetch: !0,
          });
        };
      },
    },
  ]);
