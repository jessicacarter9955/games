!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (null != n) for (var o in n) n.hasOwnProperty(o) && (e[o] = n[o]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "008e4ea5-1431-45db-9a22-9b6a99c04c51"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-008e4ea5-1431-45db-9a22-9b6a99c04c51"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [11591, 76683],
    {
      10862: (e, t, n) => {
        "use strict";
        n.d(t, { Ff: () => i, oq: () => s, po: () => c });
        let o = null,
          r = new Set();
        function s(e) {
          return (null === o || o === e) && ((o = e), !0);
        }
        function c(e) {
          o === e && ((o = null), r.forEach((e) => e()));
        }
        function i(e) {
          return (
            r.add(e),
            () => {
              r.delete(e);
            }
          );
        }
      },
      11591: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => _ });
        var o = n(6029),
          r = n(75155);
        n(55729);
        var s = n(50212),
          c = n(56760),
          i = n(69386),
          l = n(85893),
          a = n(82026),
          d = n.n(a);
        let _ = (e) => {
          let t,
            n,
            a,
            _,
            u = (0, r.c)(12),
            { open: f, blurred: m, onClose: p, children: y, className: h } = e;
          if (((0, i.K)(f), !f)) return null;
          let z = void 0 !== m && m && d().blurred;
          if (
            (u[0] !== h || u[1] !== z
              ? ((t = (0, s.A)(d().modal, z, h)),
                (u[0] = h),
                (u[1] = z),
                (u[2] = t))
              : (t = u[2]),
            u[3] !== p || u[4] !== f
              ? ((n = (0, o.jsx)(l.k, { open: f, onClick: p })),
                (u[3] = p),
                (u[4] = f),
                (u[5] = n))
              : (n = u[5]),
            u[6] !== y
              ? ((a = (0, o.jsx)("div", {
                  className: d().modalContent,
                  children: y,
                })),
                (u[6] = y),
                (u[7] = a))
              : (a = u[7]),
            u[8] !== t || u[9] !== n || u[10] !== a)
          ) {
            let e = (0, o.jsxs)("div", { className: t, children: [n, a] });
            (_ = (0, c.createPortal)(e, document.body)),
              (u[8] = t),
              (u[9] = n),
              (u[10] = a),
              (u[11] = _);
          } else _ = u[11];
          return _;
        };
      },
      17151: (e) => {
        e.exports = {
          czyButton: "AdFreeOfferSessionPrompt_czyButton__U4p1K",
          "czyButton--contained--purple":
            "AdFreeOfferSessionPrompt_czyButton--contained--purple__l1okn",
          "czyButton--contained--white":
            "AdFreeOfferSessionPrompt_czyButton--contained--white__fDcrY",
          "czyButton--contained--grey":
            "AdFreeOfferSessionPrompt_czyButton--contained--grey__pF1xd",
          "czyButton--contained--warning":
            "AdFreeOfferSessionPrompt_czyButton--contained--warning__gOdOT",
          "czyButton--contained--alert":
            "AdFreeOfferSessionPrompt_czyButton--contained--alert__1XZo0",
          "czyButton--contained--success":
            "AdFreeOfferSessionPrompt_czyButton--contained--success__TGlUH",
          "czyButton--contained--black":
            "AdFreeOfferSessionPrompt_czyButton--contained--black__7tNvO",
          "czyButton--contained--green-gradient":
            "AdFreeOfferSessionPrompt_czyButton--contained--green-gradient__hP_Ql",
          "czyButton--contained--animated-green-gradient":
            "AdFreeOfferSessionPrompt_czyButton--contained--animated-green-gradient__cR6Xx",
          "scroll-gradient": "AdFreeOfferSessionPrompt_scroll-gradient__TP9Jt",
          "czyButton--outlined--purple":
            "AdFreeOfferSessionPrompt_czyButton--outlined--purple__x5Zhq",
          "czyButton--link--purple":
            "AdFreeOfferSessionPrompt_czyButton--link--purple__ozEr9",
          "czyButton--outlined--white":
            "AdFreeOfferSessionPrompt_czyButton--outlined--white__w4pZN",
          "czyButton--link--white":
            "AdFreeOfferSessionPrompt_czyButton--link--white___oUS5",
          "czyButton--outlined--grey":
            "AdFreeOfferSessionPrompt_czyButton--outlined--grey___xKll",
          "czyButton--link--grey":
            "AdFreeOfferSessionPrompt_czyButton--link--grey__e8LZ3",
          "czyButton--outlined--warning":
            "AdFreeOfferSessionPrompt_czyButton--outlined--warning__rBBdc",
          "czyButton--link--warning":
            "AdFreeOfferSessionPrompt_czyButton--link--warning__cc_xz",
          "czyButton--outlined--alert":
            "AdFreeOfferSessionPrompt_czyButton--outlined--alert__t_gDH",
          "czyButton--link--alert":
            "AdFreeOfferSessionPrompt_czyButton--link--alert__JPXgB",
          "czyButton--outlined--success":
            "AdFreeOfferSessionPrompt_czyButton--outlined--success__hzVyv",
          "czyButton--link--success":
            "AdFreeOfferSessionPrompt_czyButton--link--success__KrX23",
          "czyButton--outlined":
            "AdFreeOfferSessionPrompt_czyButton--outlined__JaAoJ",
          "czyButton--disabled":
            "AdFreeOfferSessionPrompt_czyButton--disabled__gzufU",
          "czyButton--height50":
            "AdFreeOfferSessionPrompt_czyButton--height50__5ktLn",
          "czyButton--height34":
            "AdFreeOfferSessionPrompt_czyButton--height34__MWi_b",
          "czyButton--height28":
            "AdFreeOfferSessionPrompt_czyButton--height28__q7b3g",
          "czyButton--fullWidth":
            "AdFreeOfferSessionPrompt_czyButton--fullWidth__jzB24",
          "czyButton--headerIcon":
            "AdFreeOfferSessionPrompt_czyButton--headerIcon__ddI40",
          "czyButton--headerIcon--desktop":
            "AdFreeOfferSessionPrompt_czyButton--headerIcon--desktop__CfFVx",
          "czyButton--headerIcon--mobile":
            "AdFreeOfferSessionPrompt_czyButton--headerIcon--mobile__CMQTf",
          "czyButton--headerIcon--withLabel":
            "AdFreeOfferSessionPrompt_czyButton--headerIcon--withLabel__aHMuU",
          modalContainer: "AdFreeOfferSessionPrompt_modalContainer__iPx0K",
          prompt: "AdFreeOfferSessionPrompt_prompt__6rqNx",
          illustration: "AdFreeOfferSessionPrompt_illustration__3a1p_",
          copy: "AdFreeOfferSessionPrompt_copy__fS6WB",
          title: "AdFreeOfferSessionPrompt_title__fpsiT",
          description: "AdFreeOfferSessionPrompt_description__H9cEs",
          actions: "AdFreeOfferSessionPrompt_actions__qSn11",
          dontShowAgain: "AdFreeOfferSessionPrompt_dontShowAgain___UgLK",
        };
      },
      76683: (e, t, n) => {
        "use strict";
        n.r(t), n.d(t, { default: () => w });
        var o = n(6029),
          r = n(75155),
          s = n(55729),
          c = n(97324),
          i = n(77650),
          l = n(79942),
          a = n(71024),
          d = n.n(a),
          _ = n(71855),
          u = n(94618),
          f = n(83576),
          m = n(11591),
          p = n(4230),
          y = n(50293),
          h = n(14886),
          z = n(45364),
          B = n(71684),
          A = n(10862),
          F = n(43461),
          S = n(56919);
        let g = "ad-free-session-prompt",
          x = !1;
        function b() {
          return (0, A.po)(g);
        }
        var P = n(17151),
          O = n.n(P);
        let k = d()(
            () =>
              Promise.all([
                n.e(38332),
                n.e(64323),
                n.e(16688),
                n.e(28930),
              ]).then(n.bind(n, 28930)),
            {
              loadableGenerated: { webpack: () => [28930] },
              loading: () => null,
              ssr: !1,
            }
          ),
          w = () => {
            let e,
              t,
              n,
              a,
              d,
              P,
              w,
              C,
              j,
              v,
              N,
              I,
              L,
              M,
              E,
              D = (0, r.c)(31),
              K = (0, _.U)("czyExpClientAdFree_CZY_21530"),
              U = "disabled" === K ? null : K,
              {
                promptOpen: T,
                offerOpen: q,
                onGoAdFree: H,
                onDismiss: R,
                onOfferClose: W,
              } = (function (e) {
                let t,
                  n,
                  o,
                  c,
                  i,
                  l,
                  a,
                  d,
                  _,
                  u,
                  f,
                  m = (0, r.c)(25),
                  { loadingUser: P } = s.useContext(h.R),
                  { crazyAnalyticsService: O } = s.useContext(B.A).services,
                  k = s.useContext(p.A),
                  w = (0, S.Q)(e, "session_prompt"),
                  [C, j] = s.useState(!1),
                  [v, N] = s.useState(!1),
                  I = s.useRef(!1);
                m[0] !== k
                  ? ((t = (0, y.Fr)(k)), (m[0] = k), (m[1] = t))
                  : (t = m[1]);
                let L = t;
                m[2] !== O || m[3] !== L || m[4] !== P || m[5] !== e
                  ? ((n = () => {
                      if (!e || P) return;
                      let t = !1,
                        n = null,
                        o = window.matchMedia("(orientation: landscape)"),
                        r = () => {
                          t ||
                            null === n ||
                            (L && o.matches) ||
                            (!(z.A.isFullscreen() || z.A.isFakeFullscreen()) &&
                              (0, A.oq)(g) &&
                              ((0, F.Nl)(n, Date.now()), (n = null), j(!0)));
                        };
                      if (!x) {
                        x = !0;
                        let e = O.getSessionCount();
                        ((0, F.HX)() ||
                          (0, F.PQ)((0, F.Lh)(), e, Date.now())) &&
                          ((n = e), r());
                      }
                      z.A.addFullscreenListener(r),
                        z.A.addFakeFullscreenListener(r);
                      let s = (0, A.Ff)(r);
                      return () => {
                        (t = !0),
                          z.A.removeFullscreenListener(r),
                          z.A.removeFakeFullscreenListener(r),
                          s();
                      };
                    }),
                    (o = [e, P, O, L]),
                    (m[2] = O),
                    (m[3] = L),
                    (m[4] = P),
                    (m[5] = e),
                    (m[6] = n),
                    (m[7] = o))
                  : ((n = m[6]), (o = m[7])),
                  s.useEffect(n, o),
                  m[8] !== C
                    ? ((c = () => {
                        if (C) return b;
                      }),
                      (i = [C]),
                      (m[8] = C),
                      (m[9] = c),
                      (m[10] = i))
                    : ((c = m[9]), (i = m[10])),
                  s.useEffect(c, i),
                  m[11] !== C || m[12] !== w
                    ? ((l = () => {
                        C &&
                          !I.current &&
                          ((I.current = !0), w("shown", "entry_point"));
                      }),
                      (a = [C, w]),
                      (m[11] = C),
                      (m[12] = w),
                      (m[13] = l),
                      (m[14] = a))
                    : ((l = m[13]), (a = m[14])),
                  s.useEffect(l, a),
                  m[15] !== w
                    ? ((d = () => {
                        w("clicked", "entry_point"), j(!1), N(!0);
                      }),
                      (m[15] = w),
                      (m[16] = d))
                    : (d = m[16]);
                let M = d;
                m[17] !== w
                  ? ((_ = (e) => {
                      e && (0, F.iS)(),
                        w("closed", e ? "dont_show_again" : "ignore"),
                        j(!1);
                    }),
                    (m[17] = w),
                    (m[18] = _))
                  : (_ = m[18]);
                let E = _;
                return (
                  m[19] === Symbol.for("react.memo_cache_sentinel")
                    ? ((u = () => N(!1)), (m[19] = u))
                    : (u = m[19]),
                  m[20] !== v || m[21] !== E || m[22] !== M || m[23] !== C
                    ? ((f = {
                        promptOpen: C,
                        offerOpen: v,
                        onGoAdFree: M,
                        onDismiss: E,
                        onOfferClose: u,
                      }),
                      (m[20] = v),
                      (m[21] = E),
                      (m[22] = M),
                      (m[23] = C),
                      (m[24] = f))
                    : (f = m[24]),
                  f
                );
              })(U),
              [X, Z] = s.useState(!1);
            if (q && U) {
              let e;
              return (
                D[0] !== W || D[1] !== U
                  ? ((e = (0, o.jsx)(k, {
                      variant: U,
                      entryPoint: "session_prompt",
                      onClose: W,
                    })),
                    (D[0] = W),
                    (D[1] = U),
                    (D[2] = e))
                  : (e = D[2]),
                e
              );
            }
            if (!T) return null;
            D[3] !== X || D[4] !== R
              ? ((e = () => R(X)), (D[3] = X), (D[4] = R), (D[5] = e))
              : (e = D[5]);
            let J = e;
            return (
              D[6] === Symbol.for("react.memo_cache_sentinel")
                ? ((t = (0, o.jsx)("img", {
                    className: O().illustration,
                    src: (0, u.Ay)("ad-free-offer.png", { width: 400 }),
                    alt: "",
                  })),
                  (D[6] = t))
                : (t = D[6]),
              D[7] === Symbol.for("react.memo_cache_sentinel")
                ? ((n = (0, o.jsx)("h2", {
                    className: O().title,
                    children: (0, o.jsx)(l.x6, {
                      id: "common.adFreeOffer.title",
                    }),
                  })),
                  (D[7] = n))
                : (n = D[7]),
              D[8] === Symbol.for("react.memo_cache_sentinel")
                ? ((a = (0, o.jsxs)("div", {
                    className: O().copy,
                    children: [
                      n,
                      (0, o.jsx)("p", {
                        className: O().description,
                        children: (0, o.jsx)(l.x6, {
                          id: "common.adFreeOffer.prompt.description",
                        }),
                      }),
                    ],
                  })),
                  (D[8] = a))
                : (a = D[8]),
              D[9] === Symbol.for("react.memo_cache_sentinel")
                ? ((d = i.Ru._("common.adFreeOffer.prompt.goAdFree")),
                  (D[9] = d))
                : (d = D[9]),
              D[10] !== H
                ? ((P = (0, o.jsx)(c.$, {
                    label: d,
                    size: "m",
                    tone: "white",
                    onClick: H,
                  })),
                  (D[10] = H),
                  (D[11] = P))
                : (P = D[11]),
              D[12] === Symbol.for("react.memo_cache_sentinel")
                ? ((w = i.Ru._("common.adFreeOffer.prompt.ignore")),
                  (D[12] = w))
                : (w = D[12]),
              D[13] !== J
                ? ((C = (0, o.jsx)(c.$, {
                    label: w,
                    size: "m",
                    tone: "alphaWhite",
                    onClick: J,
                  })),
                  (D[13] = J),
                  (D[14] = C))
                : (C = D[14]),
              D[15] !== P || D[16] !== C
                ? ((j = (0, o.jsxs)("div", {
                    className: O().actions,
                    children: [P, C],
                  })),
                  (D[15] = P),
                  (D[16] = C),
                  (D[17] = j))
                : (j = D[17]),
              D[18] === Symbol.for("react.memo_cache_sentinel")
                ? ((v = (e) => Z(e.target.checked)), (D[18] = v))
                : (v = D[18]),
              D[19] !== X
                ? ((N = (0, o.jsx)(f.A, { checked: X, onChange: v })),
                  (D[19] = X),
                  (D[20] = N))
                : (N = D[20]),
              D[21] === Symbol.for("react.memo_cache_sentinel")
                ? ((I = (0, o.jsx)(l.x6, {
                    id: "common.adFreeOffer.prompt.dontShowAgain",
                  })),
                  (D[21] = I))
                : (I = D[21]),
              D[22] !== N
                ? ((L = (0, o.jsxs)("label", {
                    className: O().dontShowAgain,
                    children: [N, I],
                  })),
                  (D[22] = N),
                  (D[23] = L))
                : (L = D[23]),
              D[24] !== t || D[25] !== L || D[26] !== j
                ? ((M = (0, o.jsxs)("section", {
                    className: O().prompt,
                    children: [t, a, j, L],
                  })),
                  (D[24] = t),
                  (D[25] = L),
                  (D[26] = j),
                  (D[27] = M))
                : (M = D[27]),
              D[28] !== J || D[29] !== M
                ? ((E = (0, o.jsx)(m.A, {
                    open: !0,
                    blurred: !0,
                    onClose: J,
                    className: O().modalContainer,
                    children: M,
                  })),
                  (D[28] = J),
                  (D[29] = M),
                  (D[30] = E))
                : (E = D[30]),
              E
            );
          };
      },
      82880: (e) => {
        e.exports = {
          root: "Checkbox_root__P7HDL",
          input: "Checkbox_input__8xpFL",
          icon: "Checkbox_icon__cfxCj",
          box: "Checkbox_box__nLxYz",
          check: "Checkbox_check__cU8Bn",
          success: "Checkbox_success__rmjwK",
        };
      },
      83576: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => a });
        var o = n(6029),
          r = n(55729),
          s = n(50212),
          c = n(82880),
          i = n.n(c);
        let l = r.forwardRef((e, t) => {
          let { className: n, color: r = "default", ...c } = e;
          return (0, o.jsxs)("span", {
            className: (0, s.A)(i().root, i()[r]),
            children: [
              (0, o.jsx)("input", {
                ref: t,
                type: "checkbox",
                className: (0, s.A)(i().input, n),
                ...c,
              }),
              (0, o.jsxs)("svg", {
                className: i().icon,
                viewBox: "0 0 24 24",
                "aria-hidden": "true",
                children: [
                  (0, o.jsx)("rect", {
                    x: "3.5",
                    y: "3.5",
                    width: "17",
                    height: "17",
                    rx: "3",
                    className: i().box,
                  }),
                  (0, o.jsx)("path", {
                    d: "M7 12.5l3 3 7-7",
                    className: i().check,
                  }),
                ],
              }),
            ],
          });
        });
        l.displayName = "Checkbox";
        let a = l;
      },
    },
  ]);
