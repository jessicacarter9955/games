!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var o = arguments[t];
          if (null != o) for (var n in o) o.hasOwnProperty(n) && (e[n] = o[n]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "179bd79e-b1d3-477a-8f36-d82bbf1d4072"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-179bd79e-b1d3-477a-8f36-d82bbf1d4072"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [23504],
    {
      10862: (e, t, o) => {
        "use strict";
        o.d(t, { Ff: () => d, oq: () => s, po: () => r });
        let n = null,
          i = new Set();
        function s(e) {
          return (null === n || n === e) && ((n = e), !0);
        }
        function r(e) {
          n === e && ((n = null), i.forEach((e) => e()));
        }
        function d(e) {
          return (
            i.add(e),
            () => {
              i.delete(e);
            }
          );
        }
      },
      23504: (e, t, o) => {
        "use strict";
        o.r(t), o.d(t, { default: () => x });
        var n = o(6029),
          i = o(75155),
          s = o(55729),
          r = o(77650),
          d = o(79942),
          a = o(8023),
          u = o(54944),
          l = o(71855),
          c = o(14886),
          g = o(45364),
          _ = o(71684),
          y = o(10862),
          m = o(46887);
        let f = o(28478).A.LocalStorage,
          v = "czy_odi_survey_nudge_shown",
          b = {
            survey1: "https://form.typeform.com/to/oNHJk6JE",
            survey2: "https://form.typeform.com/to/ofpgJAP4",
            survey3: "https://form.typeform.com/to/yxFCkYLh",
            survey4: "https://form.typeform.com/to/U58DjIuy",
            survey5: "https://form.typeform.com/to/oisz4k9c",
            survey6: "https://form.typeform.com/to/akOdHu8F",
          },
          h = "odi-survey-nudge";
        function p() {
          return (0, y.po)(h);
        }
        var N = o(41053),
          w = o.n(N);
        let x = () => {
          let e,
            t,
            o,
            N,
            x,
            S = (0, i.c)(9),
            {
              open: A,
              onTakeSurvey: j,
              onClose: Z,
            } = (function () {
              let e,
                t,
                o,
                n,
                r,
                d,
                a,
                u,
                N = (0, i.c)(18),
                { user: w, loadingUser: x } = s.useContext(c.R),
                { crazyAnalyticsService: S } = s.useContext(_.A).services,
                A = (0, l.U)("czyExpClientOdiSurveyVariant_CZY_21372");
              N[0] === Symbol.for("react.memo_cache_sentinel")
                ? ((e = window.location.search.includes("forceOdiSurveyNudge")),
                  (N[0] = e))
                : (e = N[0]);
              let j = e,
                Z = !x && !w && (j || "disabled" !== A),
                [E, I] = s.useState(!1),
                k = s.useRef(!1);
              E && !Z && I(!1),
                N[1] !== S || N[2] !== Z
                  ? ((t = () => {
                      if (!Z) return;
                      let e = !1,
                        t = () => {
                          var t;
                          let o;
                          !e ||
                            k.current ||
                            (!j &&
                              (null !== f.getItem(v) ||
                                ((t = Date.now()),
                                Number.isFinite(
                                  (o = parseInt(
                                    m.A.get("_czyFirstSeen") || "",
                                    10
                                  ))
                                ) && !(t - o >= 864e5)))) ||
                            (!(g.A.isFullscreen() || g.A.isFakeFullscreen()) &&
                              (0, y.oq)(h) &&
                              ((k.current = !0),
                              f.setItem(v, String(Date.now())),
                              I(!0),
                              S.notificationActionEvent(h, "shown")));
                        },
                        o = window.setTimeout(() => {
                          (e = !0), t();
                        }, 1e4 * !j);
                      g.A.addFullscreenListener(t),
                        g.A.addFakeFullscreenListener(t);
                      let n = (0, y.Ff)(t);
                      return () => {
                        window.clearTimeout(o),
                          g.A.removeFullscreenListener(t),
                          g.A.removeFakeFullscreenListener(t),
                          n();
                      };
                    }),
                    (o = [Z, j, S]),
                    (N[1] = S),
                    (N[2] = Z),
                    (N[3] = t),
                    (N[4] = o))
                  : ((t = N[3]), (o = N[4])),
                s.useEffect(t, o),
                N[5] !== E
                  ? ((n = () => {
                      if (E) return p;
                    }),
                    (r = [E]),
                    (N[5] = E),
                    (N[6] = n),
                    (N[7] = r))
                  : ((n = N[6]), (r = N[7])),
                s.useEffect(n, r),
                N[8] !== S || N[9] !== A || N[10] !== w?.uid
                  ? ((d = () => {
                      var e, t;
                      let o;
                      S.notificationActionEvent(h, "clicked"),
                        window.open(
                          ((e = w?.uid ?? ""),
                          (t = S.getUserId()),
                          (o = "disabled" === A ? b.survey1 : b[A]),
                          `${o}#accountid=${encodeURIComponent(
                            e
                          )}&userid=${encodeURIComponent(t)}`),
                          "_blank",
                          "noopener"
                        ),
                        I(!1);
                    }),
                    (N[8] = S),
                    (N[9] = A),
                    (N[10] = w?.uid),
                    (N[11] = d))
                  : (d = N[11]);
              let C = d;
              N[12] !== S
                ? ((a = (e) => {
                    S.notificationActionEvent(
                      h,
                      "timeout" === e ? "ignored" : "closed"
                    ),
                      I(!1);
                  }),
                  (N[12] = S),
                  (N[13] = a))
                : (a = N[13]);
              let F = a;
              return (
                N[14] !== F || N[15] !== C || N[16] !== E
                  ? ((u = { open: E, onTakeSurvey: C, onClose: F }),
                    (N[14] = F),
                    (N[15] = C),
                    (N[16] = E),
                    (N[17] = u))
                  : (u = N[17]),
                u
              );
            })(),
            E = (0, a.d)();
          S[0] === Symbol.for("react.memo_cache_sentinel")
            ? ((e = (0, n.jsx)(d.x6, { id: "common.odiSurveyNudge.title" })),
              (t = (0, n.jsx)(d.x6, { id: "common.odiSurveyNudge.body" })),
              (o = (0, n.jsx)(d.x6, { id: "common.odiSurveyNudge.action" })),
              (N = r.Ru._("common.odiSurveyNudge.close")),
              (S[0] = e),
              (S[1] = t),
              (S[2] = o),
              (S[3] = N))
            : ((e = S[0]), (t = S[1]), (o = S[2]), (N = S[3]));
          let I = E ? w().aboveBottomNavigation : void 0;
          return (
            S[4] !== Z || S[5] !== j || S[6] !== A || S[7] !== I
              ? ((x = (0, n.jsx)(u.A, {
                  open: A,
                  title: e,
                  body: t,
                  actionLabel: o,
                  closeLabel: N,
                  className: I,
                  onAction: j,
                  onClose: Z,
                })),
                (S[4] = Z),
                (S[5] = j),
                (S[6] = A),
                (S[7] = I),
                (S[8] = x))
              : (x = S[8]),
            x
          );
        };
      },
      41053: (e) => {
        e.exports = {
          aboveBottomNavigation: "OdiSurveyNudge_aboveBottomNavigation__5rTJx",
        };
      },
      54944: (e, t, o) => {
        "use strict";
        o.d(t, { A: () => _ });
        var n = o(6029),
          i = o(75155),
          s = o(55729),
          r = o(50212),
          d = o(56760),
          a = o(94618),
          u = o(93800),
          l = o(95848),
          c = o.n(l);
        let g = "crazygames/ziggy_nudge3x.png",
          _ = (e) => {
            let t,
              o,
              l,
              _,
              y,
              m,
              f,
              v,
              b,
              h,
              p,
              N,
              w,
              x,
              S,
              A,
              j,
              Z,
              E,
              I = (0, i.c)(48),
              {
                open: k,
                title: C,
                body: F,
                actionLabel: z,
                actionIcon: L,
                closeLabel: M,
                autoCloseMs: B,
                className: R,
                onAction: D,
                onClose: T,
              } = e,
              O = s.useId(),
              [H, U] = s.useState(k),
              [q, J] = s.useState(k);
            if (
              (k !== q && (J(k), k && U(!0)),
              I[0] !== k
                ? ((t = () => {
                    if (k) return;
                    let e = window.setTimeout(() => U(!1), 200);
                    return () => window.clearTimeout(e);
                  }),
                  (o = [k]),
                  (I[0] = k),
                  (I[1] = t),
                  (I[2] = o))
                : ((t = I[1]), (o = I[2])),
              s.useEffect(t, o),
              !H || "u" < typeof document)
            )
              return null;
            let V = !k && c().leaving;
            I[3] !== R || I[4] !== V
              ? ((l = (0, r.A)(c().nudge, V, R)),
                (I[3] = R),
                (I[4] = V),
                (I[5] = l))
              : (l = I[5]);
            let P = `${void 0 === B ? 2e4 : B}ms`;
            I[6] !== P
              ? ((_ = {
                  "--nudge-auto-close-duration": P,
                  "--nudge-transition-duration": "200ms",
                }),
                (I[6] = P),
                (I[7] = _))
              : (_ = I[7]);
            let $ = _;
            return (
              I[8] !== C || I[9] !== O
                ? ((y = (0, n.jsx)("div", {
                    id: O,
                    className: c().title,
                    children: C,
                  })),
                  (I[8] = C),
                  (I[9] = O),
                  (I[10] = y))
                : (y = I[10]),
              I[11] !== F
                ? ((m = (0, n.jsx)("div", {
                    className: c().body,
                    children: F,
                  })),
                  (I[11] = F),
                  (I[12] = m))
                : (m = I[12]),
              I[13] !== m || I[14] !== y
                ? ((f = (0, n.jsxs)("div", {
                    className: c().text,
                    children: [y, m],
                  })),
                  (I[13] = m),
                  (I[14] = y),
                  (I[15] = f))
                : (f = I[15]),
              I[16] !== L
                ? ((v = L && (0, n.jsx)(u.A, { name: L, size: 20 })),
                  (I[16] = L),
                  (I[17] = v))
                : (v = I[17]),
              I[18] !== z
                ? ((b = (0, n.jsx)("span", { children: z })),
                  (I[18] = z),
                  (I[19] = b))
                : (b = I[19]),
              I[20] !== D || I[21] !== v || I[22] !== b
                ? ((h = (0, n.jsxs)("button", {
                    type: "button",
                    className: c().action,
                    onClick: D,
                    children: [v, b],
                  })),
                  (I[20] = D),
                  (I[21] = v),
                  (I[22] = b),
                  (I[23] = h))
                : (h = I[23]),
              I[24] !== f || I[25] !== h
                ? ((p = (0, n.jsxs)("div", {
                    className: c().bubble,
                    children: [f, h],
                  })),
                  (I[24] = f),
                  (I[25] = h),
                  (I[26] = p))
                : (p = I[26]),
              I[27] === Symbol.for("react.memo_cache_sentinel")
                ? ((N = (0, n.jsx)("svg", {
                    className: c().tail,
                    width: "26",
                    height: "13",
                    viewBox: "0 0 25.7783 12.9639",
                    "aria-hidden": !0,
                    children: (0, n.jsx)("path", {
                      d: "M25.7783 0C22.7099 4.3149 16.3804 12.13 12.9082 12.9531V12.9629C12.902 12.9615 12.8959 12.9594 12.8896 12.958C12.8821 12.9597 12.8747 12.9622 12.8672 12.9639V12.9521C9.39437 12.1253 3.06752 4.31366 0 0H25.7783Z",
                    }),
                  })),
                  (I[27] = N))
                : (N = I[27]),
              I[28] !== p
                ? ((w = (0, n.jsxs)("div", {
                    className: c().speech,
                    children: [p, N],
                  })),
                  (I[28] = p),
                  (I[29] = w))
                : (w = I[29]),
              I[30] !== T
                ? ((x = () => T("dismissed")), (I[30] = T), (I[31] = x))
                : (x = I[31]),
              I[32] !== T || I[33] !== k
                ? ((S = (0, n.jsx)("svg", {
                    className: c().countdown,
                    viewBox: "0 0 30 30",
                    "aria-hidden": !0,
                    children: (0, n.jsx)("circle", {
                      className: c().countdownRing,
                      cx: "15",
                      cy: "15",
                      r: "12",
                      pathLength: 100,
                      onAnimationEnd: () => {
                        k && T("timeout");
                      },
                    }),
                  })),
                  (I[32] = T),
                  (I[33] = k),
                  (I[34] = S))
                : (S = I[34]),
              I[35] === Symbol.for("react.memo_cache_sentinel")
                ? ((A = (0, n.jsx)(u.A, {
                    name: "close",
                    className: c().closeIcon,
                  })),
                  (I[35] = A))
                : (A = I[35]),
              I[36] !== M || I[37] !== x || I[38] !== S
                ? ((j = (0, n.jsxs)("button", {
                    type: "button",
                    className: c().close,
                    "aria-label": M,
                    onClick: x,
                    children: [S, A],
                  })),
                  (I[36] = M),
                  (I[37] = x),
                  (I[38] = S),
                  (I[39] = j))
                : (j = I[39]),
              I[40] === Symbol.for("react.memo_cache_sentinel")
                ? ((Z = (0, n.jsx)("img", {
                    className: c().ziggy,
                    src: (0, a.Ay)(g, { width: 153 }),
                    srcSet: (0, a.Wn)(g, { width: 153 }),
                    width: 153,
                    height: 111,
                    alt: "",
                  })),
                  (I[40] = Z))
                : (Z = I[40]),
              I[41] !== w ||
              I[42] !== j ||
              I[43] !== Z ||
              I[44] !== l ||
              I[45] !== $ ||
              I[46] !== O
                ? ((E = (0, d.createPortal)(
                    (0, n.jsxs)("div", {
                      className: l,
                      role: "dialog",
                      "aria-labelledby": O,
                      style: $,
                      children: [w, j, Z],
                    }),
                    document.body
                  )),
                  (I[41] = w),
                  (I[42] = j),
                  (I[43] = Z),
                  (I[44] = l),
                  (I[45] = $),
                  (I[46] = O),
                  (I[47] = E))
                : (E = I[47]),
              E
            );
          };
      },
      95848: (e) => {
        e.exports = {
          nudge: "ZiggyNudge_nudge__Hr6EJ",
          "nudge-enter": "ZiggyNudge_nudge-enter__e1VRF",
          leaving: "ZiggyNudge_leaving__s_TOI",
          "nudge-leave": "ZiggyNudge_nudge-leave__7qVlB",
          speech: "ZiggyNudge_speech___HOo3",
          bubble: "ZiggyNudge_bubble__ES82b",
          text: "ZiggyNudge_text__Ee_LI",
          title: "ZiggyNudge_title__NaEz3",
          body: "ZiggyNudge_body__ZgC_6",
          action: "ZiggyNudge_action__dgUoI",
          tail: "ZiggyNudge_tail__fibSq",
          close: "ZiggyNudge_close__xqem1",
          closeIcon: "ZiggyNudge_closeIcon__HNDZu",
          countdown: "ZiggyNudge_countdown__a6rBS",
          countdownRing: "ZiggyNudge_countdownRing__gB_vQ",
          "nudge-countdown": "ZiggyNudge_nudge-countdown__SEeGv",
          ziggy: "ZiggyNudge_ziggy__vp6ly",
        };
      },
    },
  ]);
