!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var i = arguments[t];
          if (null != i) for (var s in i) i.hasOwnProperty(s) && (e[s] = i[s]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "fc5a7f67-fd59-410d-9d0b-3a5ff971f396"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-fc5a7f67-fd59-410d-9d0b-3a5ff971f396"));
  } catch (e) {}
})();
("use strict");
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [18789, 99203],
  {
    952: (e, t, i) => {
      i.d(t, { A: () => h });
      var s = i(6029),
        n = i(75155);
      i(55729);
      var r = i(55654),
        a = i(95669),
        d = i.n(a),
        o = i(13246),
        l = i(61411);
      let h = (e) => {
        let t,
          i,
          r,
          a,
          l,
          h,
          m,
          g,
          f = (0, n.c)(21),
          {
            title: p,
            metaDescription: v,
            canonical: b,
            alternatives: w,
            children: y,
          } = e;
        f[0] !== w
          ? ((t = void 0 === w ? [] : w), (f[0] = w), (f[1] = t))
          : (t = f[1]);
        let A = t;
        f[2] !== A ? ((i = A.find(u)), (f[2] = A), (f[3] = i)) : (i = f[3]);
        let C = i,
          B = "development" === o.A.Instance.environment,
          R = `${B ? "\uD83E\uDD99 - " : ""}${p}`;
        return (
          f[4] !== R
            ? ((r = (0, s.jsx)("title", { children: R })),
              (f[4] = R),
              (f[5] = r))
            : (r = f[5]),
          f[6] !== v
            ? ((a = (0, s.jsx)("meta", { name: "description", content: v })),
              (f[6] = v),
              (f[7] = a))
            : (a = f[7]),
          f[8] !== b
            ? ((l = b && (0, s.jsx)("link", { rel: "canonical", href: b })),
              (f[8] = b),
              (f[9] = l))
            : (l = f[9]),
          f[10] !== A
            ? ((h = A.map(c)), (f[10] = A), (f[11] = h))
            : (h = f[11]),
          f[12] !== C
            ? ((m =
                C &&
                (0, s.jsx)("link", {
                  rel: "alternate",
                  href: C.href,
                  hrefLang: "x-default",
                })),
              (f[12] = C),
              (f[13] = m))
            : (m = f[13]),
          f[14] !== y ||
          f[15] !== r ||
          f[16] !== a ||
          f[17] !== l ||
          f[18] !== h ||
          f[19] !== m
            ? ((g = (0, s.jsxs)(d(), { children: [r, a, l, h, m, y] })),
              (f[14] = y),
              (f[15] = r),
              (f[16] = a),
              (f[17] = l),
              (f[18] = h),
              (f[19] = m),
              (f[20] = g))
            : (g = f[20]),
          g
        );
      };
      function u(e) {
        let { locale: t } = e;
        return t === l.Xn;
      }
      function c(e) {
        let { href: t, locale: i } = e,
          n = (0, r.lR)((0, l.qz)(i));
        return (0, s.jsx)(
          "link",
          { rel: "alternate", hrefLang: n, href: t },
          n
        );
      }
    },
    16074: (e, t, i) => {
      i.d(t, { Bm: () => d, Yr: () => a, k8: () => s });
      let s = "cmpInstalled";
      Object.values({
        ix: "138241895930",
        pubmatic: "138241896683",
        rubicon: "138241885337",
        ozone: "138520313072",
        ttd: "138516025707",
        nexx360: "138520677054",
        medianet: "138526849982",
        kargo: "138580341083",
        equativ: "138558968808",
        msft: "138542222315",
        aps: "138562020128",
      }).filter((e) => null !== e);
      let n = {
          ix: 0x10f2aca74,
          pubmatic: 0x10f2acb7c,
          rubicon: 0x10a0a673b,
          ozone: 0x1572280da,
          ttd: 0x131edef83,
          nexx360: 0x15bbef69b,
          medianet: 0x15dc901ca,
          kargo: 0x16f0ca91c,
          equativ: 0x16a311131,
          msft: 0x163ce5988,
          aps: 0x110594060,
        },
        r = n.aps;
      function a(e, t) {
        if (t.empty) return null;
        if (t.houseAd) return "house";
        if (e === r) return "amazon";
        for (let [t, i] of Object.entries(n)) if (i === e) return t;
        return "google";
      }
      let d = [
        "army",
        "battle-royale",
        "battleship",
        "bloody",
        "bomberman",
        "cannon",
        "first-person-shooter",
        "gta",
        "gun",
        "horde-survival",
        "hunting",
        "jump-scare",
        "killing",
        "mmo",
        "police",
        "scary",
        "shooting",
        "sniper",
        "soldier",
        "surgery",
        "survive",
        "tank",
        "third-person-shooter",
        "war",
      ];
    },
    18019: (e, t, i) => {
      var s;
      i.d(t, { R: () => n });
      let n =
        (((s = {}).LeaderboardBelowGameRefresh = "div-gpt-ad-1590672385835-0"),
        (s.RightMpuRefresh = "div-gpt-ad-1590672182999-0"),
        (s.SecondLeaderboardBelowGameRefresh = "div-gpt-ad-1724075559578-0"),
        (s.SecondMpuBelowGameRefresh = "div-gpt-ad-1731941770755-0"),
        s);
      Object.values(n);
    },
    18789: (e, t, i) => {
      i.d(t, { A: () => d });
      var s = i(6029),
        n = i(75155),
        r = i(55729),
        a = i(71684);
      let d = function (e) {
        return (t) => {
          let i,
            d = (0, n.c)(3),
            { services: o } = r.useContext(a.A);
          return (
            d[0] !== t || d[1] !== o
              ? ((i = (0, s.jsx)(e, { services: o, ...t })),
                (d[0] = t),
                (d[1] = o),
                (d[2] = i))
              : (i = d[2]),
            i
          );
        };
      };
    },
    36173: (e, t, i) => {
      i.d(t, { R: () => l });
      var s = i(75155),
        n = i(55729),
        r = i(89964),
        a = i(71684);
      let d = null;
      var o = i(1584);
      let l = (e) => {
        let t,
          i,
          l = (0, s.c)(11),
          { game: h } = e,
          {
            setPlayingGame: u,
            setIsPlaying: c,
            resetGameInvites: m,
            setGameInviteLink: g,
            setMultiplayerRoom: f,
            setJoinRoomListenerCount: p,
            setGameContext: v,
          } = n.useContext(o.T),
          b = n.useRef(!1),
          { setIsGamePlayStarted: w } = (() => {
            let e,
              t,
              i,
              o,
              l,
              h,
              u,
              c,
              m = (0, s.c)(13),
              [g, f] = (0, n.useState)(!1),
              [p, v] = (0, n.useState)(!0),
              { crazyAnalyticsService: b } = n.useContext(a.A).services,
              w = (0, n.useRef)(!1);
            m[0] !== b
              ? ((e = () => {
                  if (null === d) return;
                  let e = Date.now() - d;
                  if (e > 7e3)
                    w.current ||
                      (console.warn("Gameframe heartbeat is late"),
                      b.trackGenericError("gameframeHeartbeatIsLate", {
                        tooLateInMs: e ?? null,
                      }),
                      (w.current = !0));
                  else w.current && (w.current = !1);
                }),
                (m[0] = b),
                (m[1] = e))
              : (e = m[1]);
            let y = e;
            return (
              m[2] !== g || m[3] !== p
                ? ((t = function () {
                    let e = (e) => {
                      !e.data ||
                        e.data.type !== r.x ||
                        "gameframeHeartbeat" !== e.data.event ||
                        (g && p && (d = Date.now()));
                    };
                    return (
                      window.addEventListener("message", e),
                      function () {
                        window.removeEventListener("message", e), (d = null);
                      }
                    );
                  }),
                  (i = [g, p]),
                  (m[2] = g),
                  (m[3] = p),
                  (m[4] = t),
                  (m[5] = i))
                : ((t = m[4]), (i = m[5])),
              (0, n.useEffect)(t, i),
              m[6] !== y || m[7] !== g
                ? ((o = function () {
                    if (!g) return;
                    let e = window.setInterval(y, 7e3);
                    return () => {
                      window.clearInterval(e);
                    };
                  }),
                  (l = [g, y]),
                  (m[6] = y),
                  (m[7] = g),
                  (m[8] = o),
                  (m[9] = l))
                : ((o = m[8]), (l = m[9])),
              (0, n.useEffect)(o, l),
              m[10] === Symbol.for("react.memo_cache_sentinel")
                ? ((h = function () {
                    let e = () => {
                      v(!document.hidden), document.hidden && (d = null);
                    };
                    return (
                      document.addEventListener("visibilitychange", e),
                      () => {
                        document.removeEventListener("visibilitychange", e);
                      }
                    );
                  }),
                  (u = []),
                  (m[10] = h),
                  (m[11] = u))
                : ((h = m[10]), (u = m[11])),
              (0, n.useEffect)(h, u),
              m[12] === Symbol.for("react.memo_cache_sentinel")
                ? ((c = { setIsGamePlayStarted: f }), (m[12] = c))
                : (c = m[12]),
              c
            );
          })();
        return (
          l[0] !== h ||
          l[1] !== m ||
          l[2] !== v ||
          l[3] !== g ||
          l[4] !== w ||
          l[5] !== c ||
          l[6] !== p ||
          l[7] !== f ||
          l[8] !== u
            ? ((t = () => {
                if (!h) return;
                u(h);
                let e = (e) => {
                  e.data &&
                    e.data.type === r.x &&
                    ("gameLoaded" !== e.data.event ||
                      b.current ||
                      ((b.current = !0), c(!0), w(!0)));
                };
                return (
                  window.addEventListener("message", e),
                  () => {
                    window.removeEventListener("message", e),
                      u(null),
                      c(!1),
                      g(null),
                      f(null),
                      p(0),
                      v(null),
                      m(),
                      (b.current = !1),
                      w(!1);
                  }
                );
              }),
              (i = [h, m, g, c, u, f, p, v, w]),
              (l[0] = h),
              (l[1] = m),
              (l[2] = v),
              (l[3] = g),
              (l[4] = w),
              (l[5] = c),
              (l[6] = p),
              (l[7] = f),
              (l[8] = u),
              (l[9] = t),
              (l[10] = i))
            : ((t = l[9]), (i = l[10])),
          n.useEffect(t, i),
          null
        );
      };
    },
    45018: (e, t, i) => {
      i.d(t, { j: () => r });
      var s = i(79173),
        n = i(50293);
      function r(e, t, i) {
        var r, a;
        let d = !(0, n.xl)(t) && !e.iosFriendly && !e.androidFriendly;
        return (
          !!i.shouldDisableAds() ||
          "UNAVAILABLE" === e.status ||
          !!d ||
          !((r = {
            isBot: (0, s.Wk)(),
            isKids: !!e.isKids,
            launchFlow: "BASIC_LAUNCH" === e.status ? "basic" : "full",
            isApp: !1,
            isDesktop: (0, n.xl)(t),
            isOfflineGaming: !1,
            disableBanners: !1,
            disableMidgameAds: !1,
            disableRewardedAds: !1,
          }),
          (a = "portalBanner"),
          r.isBot
            ? { allowed: !1, reason: "Bot, based on the User Agent" }
            : r.isKids
            ? { allowed: !1, reason: "Kids mode, where we don't show ads" }
            : (!(function (e) {
                switch (e) {
                  case "basic":
                    return !1;
                  case "full":
                    return !0;
                }
              })(r.launchFlow),
              r.isApp && !0 && !0
                ? {
                    allowed: !1,
                    reason: `${a} ads are disabled on the mobile apps`,
                  }
                : !r.isDesktop
                ? { allowed: !1, reason: "Portal banners only run on desktop" }
                : r.isOfflineGaming && !0
                ? {
                    allowed: !1,
                    reason:
                      "Only rewarded ads are available during offline play",
                  }
                : { allowed: !0 })).allowed
        );
      }
    },
    60402: (e, t, i) => {
      i.d(t, { F: () => r });
      var s = i(98417),
        n = i(78354);
      function r(e) {
        if (!(0, s.O)(e)) return null;
        let t = e
          .trim()
          .toLowerCase()
          .replace(/\+[^@]*@/g, "@");
        return (0, n.j)(t) ? null : t;
      }
    },
    60574: (e, t, i) => {
      i.d(t, { C$: () => c, H7: () => u, jU: () => m, sZ: () => g });
      var s = i(8660),
        n = i(67989),
        r = i(60402),
        a = i(78354),
        d = i(98417),
        o = i(72232),
        l = i(28478);
      let h = "czy_user_identity";
      function u() {
        if ("u" < typeof document) return;
        if ("true" !== (0, o.R)(s.j)) return void g();
        let e = l.A.LocalStorage.getItem(h) ?? "";
        if ((0, a.j)(e)) return;
        let t = ((e) => {
          try {
            let t = JSON.parse(e),
              i = (0, r.F)(t.email);
            return (0, a.y)(t.userId) && (0, d.O)(i)
              ? { userId: t.userId, email: i }
              : null;
          } catch {
            return null;
          }
        })(e);
        return (0, d.O)(t) ? t : void g();
      }
      function c(e, t) {
        let i = (0, r.F)(t);
        (0, a.y)(e) && (0, d.O)(i)
          ? l.A.LocalStorage.setItem(h, JSON.stringify({ userId: e, email: i }))
          : g();
      }
      function m() {
        let e = u();
        return (0, d.O)(e) ? { [n.RU]: e.email } : {};
      }
      function g() {
        l.A.LocalStorage.removeItem(h);
      }
    },
    86313: (e, t, i) => {
      i.d(t, { g: () => em, A: () => ef });
      var s,
        n,
        r,
        a,
        d = i(6029),
        o = i(55729),
        l = i(98417);
      function h(e) {
        let t = e.filter((e) => (0, l.O)(e));
        if (0 !== t.length) return Math.min(...t);
      }
      var u = i(16074);
      let c = { firstRequestMs: 2400, subsequentRequestsMs: 2e3 },
        m = { numberOfRequestsWithoutBid: 5, resetIntervalMs: 9e5 },
        g = {
          minVisibleRatio: 0.5,
          minTimeInViewMs: 1e4,
          minTimeInViewMsExperiment: 5e3,
        },
        f = {
          regular: {
            minTimeBetweenRefreshesMs: 3e4,
            maxTimeBetweenRefreshesMs: 51e3,
            minTimeInDomMs: 2e4,
          },
          highlyAffectedSystems: {
            minTimeBetweenRefreshesMs: 3e4,
            maxTimeBetweenRefreshesMs: 15e4,
            minTimeInDomMs: 2e4,
          },
          holidayModeMaxTimeBetweenRefreshesMs: 3e4,
          lowEndDevices: { minDelayAfterPageLoadToStartRefreshingMs: 45e3 },
        };
      var p = i(86587);
      let v = [
        { width: 1910, height: 970 },
        { width: 1360, height: 660 },
        { width: 1370, height: 650 },
        { width: 1370, height: 620 },
        { width: 1530, height: 750 },
        { width: 1360, height: 650 },
        { width: 1910, height: 940 },
        { width: 1370, height: 660 },
        { width: 1360, height: 630 },
        { width: 1080, height: 710 },
        { width: 1920, height: 970 },
        { width: 1360, height: 620 },
        { width: 1910, height: 960 },
        { width: 1370, height: 670 },
        { width: 1530, height: 710 },
        { width: 1910, height: 930 },
        { width: 1370, height: 630 },
        { width: 1920, height: 940 },
        { width: 390, height: 660 },
      ];
      var b = i(78354);
      let w = [
          "online games",
          "free games",
          "browser games",
          "html5 games",
          "web games",
          "casual games",
          "action games",
          "multiplayer games",
          "puzzle games",
          "mobile-friendly games",
          "instant play",
        ],
        y = { id: "crazygames", name: "CrazyGames", domain: "crazygames.com" },
        A = ["680"];
      var C = i(79899),
        B = i(75651),
        R = i(55654),
        E = i(60402),
        T = i(36002),
        L = i(98172);
      let I = i(13246).A.Instance.data.gtag.gadsId,
        k = null;
      var U = i(48431),
        M = i(75155),
        O = i(14886),
        x = i(51196),
        S = i(18789),
        F = i(62131),
        P = i(90949),
        D = i(95946),
        V = i(18699),
        q = i(61411),
        H = i(20867),
        _ = i(60574),
        z = i(45364);
      class G {
        constructor(e) {
          (this.id = e),
            (this.previousTimeInView = 0),
            (this.isInView = !1),
            (this.isInFocus = !0),
            (this.isHidden = !1),
            (this.inViewSince = Date.now()),
            (this.inDOMSince = this.inViewSince);
        }
        setHidden(e) {
          this.isHidden = e;
        }
        canRefresh(e, t) {
          return this.canRefreshWithReason(e, t).canRefresh;
        }
        canRefreshWithReason(e, t) {
          return this.isInView
            ? this.isInFocus
              ? this.totalTimeInView() < e
                ? {
                    canRefresh: !1,
                    reason: "Ad unit hasn't been in view long enough",
                  }
                : this.totalTimeInDOM() < t
                ? {
                    canRefresh: !1,
                    reason: "Ad unit hasn't been in DOM long enough",
                  }
                : { canRefresh: !0 }
              : { canRefresh: !1, reason: "Page doesn't have focus" }
            : { canRefresh: !1, reason: "Unit not in view" };
        }
        refreshed() {
          (this.previousTimeInView = 0),
            (this.inViewSince = Date.now()),
            (this.inDOMSince = this.inViewSince);
        }
        cameIntoView() {
          (this.isInView = !0), (this.inViewSince = Date.now());
        }
        removedFromView() {
          (this.isInView = !1), this.updateTimeInView();
        }
        pageLostFocus() {
          (this.isInFocus = !1), this.isInView && this.updateTimeInView();
        }
        pageRegainedFocus() {
          (this.isInFocus = !0),
            this.isInView && (this.inViewSince = Date.now());
        }
        updateTimeInView() {
          let e = Date.now() - this.inViewSince;
          (this.previousTimeInView += e), (this.inViewSince = Date.now());
        }
        totalTimeInDOM() {
          return Date.now() - this.inDOMSince;
        }
        totalTimeInView() {
          return this.isInView
            ? this.previousTimeInView + Date.now() - this.inViewSince
            : this.previousTimeInView;
        }
      }
      class j {
        constructor(e, t) {
          (this.viewportThreshold = e),
            (this.minimumTimeInViewInMs = t),
            (this.handleVisibilityChange = () => {
              let e =
                  void 0 !== this.hiddenKey &&
                  this.isHidden(document, this.hiddenKey),
                t = z.A.isFullscreen() || z.A.isFakeFullscreen();
              e || t ? this.pageLostFocus() : this.pageRegainedFocus();
            }),
            (this.handleFullscreenChange = () => {
              z.A.isFullscreen() || z.A.isFakeFullscreen()
                ? this.pageLostFocus()
                : this.pageRegainedFocus();
            }),
            (this.adUnits = []),
            (this.hiddenKey = this.calculateHiddenKey(document)),
            (this.observer = this.createObserver()),
            this.installEventListeners(),
            (this.pageFocusChangeCallBacks = []),
            (this.ioCallbackPending = []),
            (this.ioCallbackPendingPromise = null),
            (this.ioCallbackPendingResolve = null);
        }
        calculateHiddenKey(e) {
          return void 0 !== e.hidden
            ? "hidden"
            : this.hasMsHiddenKey(e)
            ? "msHidden"
            : this.hasWebkitHiddenKey(e)
            ? "webkitHidden"
            : void 0;
        }
        getVisibilityChangeKey(e) {
          switch (e) {
            case "hidden":
              return "visibilitychange";
            case "msHidden":
              return "msvisibilitychange";
            case "webkitHidden":
              return "webkitvisibilitychange";
          }
        }
        addElement(e) {
          if (this.adUnits.find((t) => t.id === e)) return;
          let t = this.getElementById(e);
          if (!t) return;
          this.ioCallbackPending.push(e), this.adUnits.push(new G(e));
          let i = t.parentElement;
          i && this.observer.observe(i);
        }
        removeElement(e, t) {
          (this.adUnits = this.adUnits.filter((t) => t.id !== e)),
            t && t.parentElement && this.observer.unobserve(t.parentElement),
            this.removeWaitingForCallbackElement(e);
        }
        addPageFocusChangeCallback(e) {
          this.pageFocusChangeCallBacks.push(e);
        }
        stop() {
          (this.adUnits = []),
            (this.pageFocusChangeCallBacks = []),
            this.observer.disconnect(),
            this.removeEventListeners();
        }
        waitForObservedUnitsCallbacks() {
          return (
            this.ioCallbackPendingPromise ||
              (this.ioCallbackPendingPromise = new Promise((e) => {
                (this.ioCallbackPendingResolve = e),
                  0 === this.ioCallbackPending.length && e();
              })),
            this.ioCallbackPendingPromise
          );
        }
        isUnitHidden(e) {
          let t = this.adUnits.find((t) => t.id === e);
          return t ? (t.isHidden ? "hidden" : "visible") : "unknown";
        }
        canUnitRefreshWithReason(e, t) {
          let i = this.adUnits.find((t) => t.id === e);
          return i
            ? i.canRefreshWithReason(this.minimumTimeInViewInMs, t)
            : { canRefresh: !0, unknownUnit: !0 };
        }
        refreshedUnits(e) {
          e.map((e) => this.getObservedUnit(e)).map((e) => e.refreshed());
        }
        intersectionCallback(e) {
          e.forEach((e) => {
            let t = e.target.firstElementChild;
            if (t) {
              let i = t.id,
                s = this.getObservedUnit(i);
              e.intersectionRatio >= this.viewportThreshold
                ? s.cameIntoView()
                : s.removedFromView(),
                s.setHidden(this.isEntryHidden(e)),
                this.removeWaitingForCallbackElement(i);
            }
          });
        }
        isEntryHidden(e) {
          let { boundingClientRect: t } = e;
          return this.isBoundingRectHidden(t);
        }
        isBoundingRectHidden(e) {
          return 0 === e.height && 0 === e.width;
        }
        getElementById(e) {
          let t = document.getElementById(e);
          return (
            t ||
            (console.error(`[AdObserver] could not find element with id ${e}`),
            null)
          );
        }
        getObservedUnit(e) {
          let t = this.adUnits.find((t) => t.id === e);
          if (!t) throw Error(`[AdObserver] observed unit ${e} not found`);
          return t;
        }
        pageLostFocus() {
          this.adUnits.map((e) => e.pageLostFocus()), this.invokeCallBacks(!1);
        }
        pageRegainedFocus() {
          this.adUnits.map((e) => e.pageRegainedFocus()),
            this.invokeCallBacks(!0);
        }
        invokeCallBacks(e) {
          this.pageFocusChangeCallBacks.forEach((t) => t(e));
        }
        createObserver() {
          return new IntersectionObserver(
            (e, t) => {
              this.intersectionCallback(e);
            },
            { threshold: [this.viewportThreshold] }
          );
        }
        installEventListeners() {
          void 0 !== this.hiddenKey &&
            document.addEventListener(
              this.getVisibilityChangeKey(this.hiddenKey),
              this.handleVisibilityChange
            ),
            this.installFullscreenListener();
        }
        removeEventListeners() {
          void 0 !== this.hiddenKey &&
            document.removeEventListener(
              this.getVisibilityChangeKey(this.hiddenKey),
              this.handleVisibilityChange
            ),
            this.removeFullscreenListeners();
        }
        installFullscreenListener() {
          z.A.addFullscreenListener(this.handleFullscreenChange),
            z.A.addFakeFullscreenListener(this.handleFullscreenChange);
        }
        removeFullscreenListeners() {
          z.A.removeFullscreenListener(this.handleFullscreenChange),
            z.A.removeFakeFullscreenListener(this.handleFullscreenChange);
        }
        removeWaitingForCallbackElement(e) {
          (this.ioCallbackPending = this.ioCallbackPending.filter(
            (t) => t !== e
          )),
            0 === this.ioCallbackPending.length &&
              this.ioCallbackPendingResolve &&
              (this.ioCallbackPendingResolve(),
              (this.ioCallbackPendingResolve = null));
        }
        isHidden(e, t) {
          switch (t) {
            case "hidden":
              return e.hidden;
            case "msHidden":
              return !!this.hasMsHiddenKey(e) && e.msHidden;
            case "webkitHidden":
              return !!this.hasWebkitHiddenKey(e) && e.webkitHidden;
          }
        }
        hasMsHiddenKey(e) {
          return "boolean" == typeof e.msHidden;
        }
        hasWebkitHiddenKey(e) {
          return "boolean" == typeof e.webkitHidden;
        }
      }
      var W = i(89147),
        K = i(50293),
        $ = i(89964);
      let N = (e, t) => {
        let i = setTimeout(e, t);
        return () => clearTimeout(i);
      };
      var Y = class {
          constructor(e, t, i = {}) {
            (this.disposed = !1),
              (this.timerFactory = i.timerFactory ?? N),
              (this.once = i.once ?? !1),
              (this.timerPeriod = e),
              (this.onEvent = t),
              (this.timeRemaining = 0);
          }
          restart() {
            this.disposed ||
              (this.clearCurrent(), this.startTimer(this.timerPeriod));
          }
          startTimer(e) {
            let t = () => {
              (this.timerDisposer = void 0), this.fire();
            };
            (this.timerDisposer = this.timerFactory(t, e)),
              (this.timeStarted = this.now()),
              (this.currentTimeout = e);
          }
          pause() {
            if (this.disposed || !this.isRunning()) return;
            this.clearCurrent();
            let e = this.now() - this.timeStarted;
            this.timeRemaining = this.currentTimeout - e;
          }
          resume(e) {
            if (this.disposed || this.isRunning()) return;
            let t = void 0 !== e ? e : this.timeRemaining;
            t <= 0
              ? ((this.timeRemaining = this.currentTimeout),
                this.fire(),
                this.isRunning() || this.restart())
              : this.startTimer(t);
          }
          dispose() {
            (this.disposed = !0), this.clearCurrent();
          }
          fire() {
            this.onEvent(), this.once && this.dispose();
          }
          clearCurrent() {
            void 0 !== this.timerDisposer &&
              (this.timerDisposer(), (this.timerDisposer = void 0));
          }
          isRunning() {
            return void 0 !== this.timerDisposer;
          }
          now() {
            return Date.now();
          }
        },
        J = i(18262);
      class Z {
        constructor(e, t, i) {
          (this.timeOfLastRefresh = 0),
            (this.timeOfMount = 0),
            (this.eventHandlerMemory = { gamePlayStarted: !1 }),
            (this.handleMessageEvent = (e) => {
              if (!e.data || e.data.type !== $.x) return;
              let t = this.convertToRefreshTimerEvent(e.data);
              this.handleEvent(t);
            }),
            (this.handleEvent = (e) => {
              let t = (function (e, t, i, s, n, r, a, d) {
                if ("timerTriggered" === e)
                  return n - s >= 0.9 * a.minimumTimeBetweenRefreshes
                    ? { type: "refresh", reason: "Timer triggered" }
                    : { type: "ignore" };
                if (!t) {
                  switch (r.type) {
                    case "startOnMount":
                      return "componentMounted" === e
                        ? { type: "restartTimer" }
                        : { type: "ignore" };
                    case "waitUntilAfterGameLoading":
                      if (
                        "gameFinishedLoading" === e ||
                        "gameLoadingStateResponseSuccess" === e
                      ) {
                        let e = n - i,
                          t = r.minimumWaitTimeAfterPageLoad;
                        if (e >= t)
                          return {
                            type: "refresh",
                            reason: "After game loading",
                          };
                        return {
                          type: "resumeTimer",
                          customTimeout: Math.max(0, t - e),
                        };
                      }
                  }
                  return { type: "ignore" };
                }
                switch (e) {
                  case "gameplayStart":
                    if (d.gamePlayStarted) break;
                    return (d.gamePlayStarted = !0), { type: "restartTimer" };
                  case "adFinished":
                  case "adError":
                  case "rewardedAd":
                  case "midgameAd":
                  case "gameplayStop":
                    if (!d.gamePlayStarted) break;
                    if (
                      ((d.gamePlayStarted = !1),
                      n - s >= a.minimumTimeBetweenRefreshes)
                    )
                      return {
                        type: "refresh",
                        reason: `Game event received: ${e}`,
                      };
                }
                return { type: "ignore" };
              })(
                e,
                this.timer.isRunning(),
                this.timeOfMount,
                this.timeOfLastRefresh,
                Date.now(),
                this.startMomentConfig,
                this.refreshConfig,
                this.eventHandlerMemory
              );
              this.onAction(t);
            }),
            (this.refreshAds = e),
            (this.timer = new Y(i.maximumTimeBetweenRefreshes, () =>
              this.handleEvent("timerTriggered")
            )),
            (this.startMomentConfig = t),
            (this.refreshConfig = i);
        }
        refresh(e) {
          this.refreshAds(e)
            ? ((this.timeOfLastRefresh = Date.now()), this.timer.restart())
            : this.timer.resume();
        }
        handleExternalEvent(e) {
          switch (e.type) {
            case "focusChanged":
              return (
                e.hasFocus
                  ? this.onAction({ type: "resumeTimer" })
                  : this.onAction({ type: "pauseTimer" }),
                !0
              );
            case "initialAdsRequestFinished":
              return (
                "startOnMount" === this.startMomentConfig.type &&
                  this.onAction({ type: "restartTimer" }),
                !0
              );
            case "mounted":
              return this.init(), this.handleEvent("componentMounted"), !0;
            case "willUnmount":
              return this.dispose(), !0;
          }
        }
        getMinimumTimeInDOMBeforeRefresh() {
          return this.refreshConfig.minimumTimeInDOM;
        }
        init() {
          window.addEventListener("message", this.handleMessageEvent),
            "waitUntilAfterGameLoading" === this.startMomentConfig.type &&
              (0, J.y)()?.contentWindow?.postMessage(
                "check-loading-state",
                "*"
              ),
            (this.timeOfMount = Date.now());
        }
        dispose() {
          this.timer.dispose(),
            window.removeEventListener("message", this.handleMessageEvent);
        }
        onAction(e) {
          switch (e.type) {
            case "restartTimer":
              return this.timer.restart(), !0;
            case "pauseTimer":
              return this.timer.pause(), !0;
            case "resumeTimer":
              return this.timer.resume(), !0;
            case "refresh":
              return this.refresh(e.reason), !0;
            case "ignore":
              return !0;
          }
        }
        convertToRefreshTimerEvent(e) {
          return "gameLoadingStateResponse" === e.event
            ? e.success
              ? "gameLoadingStateResponseSuccess"
              : "gameLoadingStateResponseFailure"
            : e.event;
        }
      }
      let Q = f,
        X = [{ browsers: ["safari"], os: [] }];
      function ee(e) {
        return e ? e.toLowerCase().replace(/\s/g, "") : "unknown";
      }
      var et = i(70155),
        ei = i(71684),
        es = i(74532);
      let en = (e) => {
        let t,
          i,
          s = (0, M.c)(5),
          { dispatch: n } = e,
          r = (0, o.useContext)(ei.A).services.adUnitService,
          { countryCode: a } = (0, o.useContext)(es.A);
        return (
          s[0] !== r || s[1] !== a || s[2] !== n
            ? ((t = () => {
                void 0 !== r &&
                  r
                    .getAdUnitsConfig(a)
                    .then((e) => n({ type: "adsConfigLoaded", config: e }));
              }),
              (i = [n, r, a]),
              (s[0] = r),
              (s[1] = a),
              (s[2] = n),
              (s[3] = t),
              (s[4] = i))
            : ((t = s[3]), (i = s[4])),
          (0, o.useEffect)(t, i),
          null
        );
      };
      var er = i(51579);
      let ea = (e) => {
          let { dispatch: t } = e;
          return (
            o.useEffect(() => {
              let e = () => t({ type: "consentGiven" }),
                i = (0, er.b)();
              return i.addConsentListener(e), () => i.removeConsentListener(e);
            }, [t]),
            null
          );
        },
        ed = (e) => {
          let t = o.useRef(!1),
            i = e.state.adsLibraryLoaded && e.state.adsConfigLoaded,
            s = e.state.userInfo.countryCode,
            { locale: n, dispatch: r, deviceType: a } = e;
          return (
            o.useEffect(() => {
              if (t.current || !i) return;
              let e = window.CrazygamesAds;
              if (((t.current = !0), (0, l.O)(e?.hasEnabledBidders))) {
                let t = e.hasEnabledBidders;
                (async () => {
                  r({
                    type: "enabledBannerBiddersLoaded",
                    hasEnabledBannerBidders: await t("banner"),
                  });
                })().catch(() =>
                  r({
                    type: "enabledBannerBiddersLoaded",
                    hasEnabledBannerBidders: !0,
                  })
                );
              } else
                r({
                  type: "enabledBannerBiddersLoaded",
                  hasEnabledBannerBidders: !0,
                });
            }, [n, s, a, i, r]),
            null
          );
        },
        eo = (e) => {
          let t,
            i,
            s = (0, M.c)(8),
            {
              pageUrlHelper: n,
              dispatch: r,
              resetLibrary: a,
              adsLoaderContext: d,
            } = e,
            [h] = (0, o.useState)(a),
            u = (0, o.useContext)(ei.A).services,
            c = (0, o.useRef)(!1),
            m = d.adsLoader,
            g = d.initAds;
          return (
            s[0] !== m ||
            s[1] !== r ||
            s[2] !== g ||
            s[3] !== n ||
            s[4] !== h ||
            s[5] !== u
              ? ((t = () => {
                  let e = () => {
                    let e = window;
                    if (
                      (h &&
                        (0, l.O)(e.CrazygamesAds) &&
                        e.CrazygamesAds.reset(),
                      !c.current)
                    ) {
                      try {
                        g(),
                          u.crazyAnalyticsService.adsFinishedLoading(),
                          u.analyticsService.checkAdblock();
                      } catch {
                        console.debug(
                          "Failed to initialize ads, likely due to an adblocker."
                        ),
                          u.analyticsService.detectedAdblock();
                      }
                      c.current = !0;
                    }
                    r({ type: "adsLibraryLoaded" });
                  };
                  return (
                    m.loadCrazyAds(n),
                    m.addLoadListener(e),
                    () => m.removeLoadListener(e)
                  );
                }),
                (i = [n, r, h, u, m, g]),
                (s[0] = m),
                (s[1] = r),
                (s[2] = g),
                (s[3] = n),
                (s[4] = h),
                (s[5] = u),
                (s[6] = t),
                (s[7] = i))
              : ((t = s[6]), (i = s[7])),
            o.useEffect(t, i),
            null
          );
        };
      var el = i(7846);
      class eh {
        constructor(e) {
          (this.adsLibraryLoaded = !1),
            (this.adsConfigLoaded = !1),
            (this.enabledBannerBiddersLoaded = !1),
            (this.consent = !1),
            (this.config = null),
            (this.hasEnabledBannerBidders = null),
            (this.userInfo = (0, el.d)()),
            e(this.userInfo.countryCode) || this.onConsentGiven();
        }
        handleAction(e) {
          switch (e.type) {
            case "adsLibraryLoaded":
              return this.onAdsLibraryLoaded();
            case "adsConfigLoaded":
              return this.onAdsConfigLoaded(e);
            case "consentGiven":
              return this.onConsentGiven();
            case "enabledBannerBiddersLoaded":
              return this.onEnabledBannerBiddersLoaded(e);
          }
        }
        retrieveState() {
          return this.adsLibraryLoaded &&
            this.adsConfigLoaded &&
            this.enabledBannerBiddersLoaded &&
            this.consent &&
            null !== this.config &&
            null !== this.userInfo &&
            null !== this.hasEnabledBannerBidders
            ? {
                ready: !0,
                adsLibraryLoaded: this.adsLibraryLoaded,
                enabledBannerBiddersLoaded: this.enabledBannerBiddersLoaded,
                adsConfigLoaded: this.adsConfigLoaded,
                userInfo: this.userInfo,
                config: this.config,
                consent: !0,
                hasEnabledBannerBidders: this.hasEnabledBannerBidders,
              }
            : {
                ready: !1,
                adsLibraryLoaded: this.adsLibraryLoaded,
                enabledBannerBiddersLoaded: this.enabledBannerBiddersLoaded,
                adsConfigLoaded: this.adsConfigLoaded,
                userInfo: this.userInfo,
                config: this.config,
                consent: this.consent,
                hasEnabledBannerBidders: this.hasEnabledBannerBidders,
              };
        }
        onAdsLibraryLoaded() {
          return (this.adsLibraryLoaded = !0), this.retrieveState();
        }
        onAdsConfigLoaded(e) {
          return (
            (this.adsConfigLoaded = !0),
            (this.config = e.config),
            this.retrieveState()
          );
        }
        onConsentGiven() {
          return (this.consent = !0), this.retrieveState();
        }
        onEnabledBannerBiddersLoaded(e) {
          return (
            (this.enabledBannerBiddersLoaded = !0),
            (this.hasEnabledBannerBidders = e.hasEnabledBannerBidders),
            this.retrieveState()
          );
        }
      }
      class eu {
        constructor(e) {
          (this.bidderAttemptsWithoutBid = {}),
            (this.biddersToDisable = {}),
            (this.onRequestAdsResult = (e, t, i) => {
              if (i)
                for (let s of e.codes ?? []) {
                  let n = this.extractEnabledBiddersForAdUnitFromRequest(
                    s,
                    e,
                    t
                  );
                  this.updateBidderAttemptsWithoutBid(s, i, n),
                    delete this.biddersToDisable[s];
                }
            }),
            (this.getBiddersToDisable = (e) => {
              let t = this.bidderAttemptsWithoutBid[e];
              if (!this.biddersToDisable[e])
                if (t) {
                  let i = Object.keys(t).filter((e) => {
                    let i = t[e];
                    return void 0 !== i && i >= this.numberOfBidAttempts;
                  });
                  this.biddersToDisable[e] = i;
                } else this.biddersToDisable[e] = [];
              return this.biddersToDisable[e];
            }),
            (this.reset = () => {
              (this.bidderAttemptsWithoutBid = {}),
                (this.biddersToDisable = {});
            }),
            (this.getCurrentNumberOfAttemptsWithoutBid = (e, t) => {
              let i = this.bidderAttemptsWithoutBid[e];
              if (void 0 === i) return 0;
              let s = i[t];
              return void 0 === s ? 0 : s;
            }),
            (this.numberOfBidAttempts = e);
        }
        extractEnabledBiddersForAdUnitFromRequest(e, t, i) {
          let s = {};
          return (
            (i.bidders || []).forEach((e) => {
              s[e.bidder] = { ...e };
            }),
            (t.units.find((t) => t.adUnit.code === e)?.bidders || []).forEach(
              (e) => {
                s[e.bidder] = { ...s[e.bidder], ...e };
              }
            ),
            Object.values(s)
              .filter((e) => e.enabled && "google" !== e.bidder)
              .map((e) => e.bidder)
          );
        }
        updateBidderAttemptsWithoutBid(e, t, i) {
          let s = this.bidderAttemptsWithoutBid[e] || {},
            n = t[e],
            r = (n?.bids ?? []).map((e) => e.bidder);
          i.forEach((e) => {
            r.includes(e) ? (s[e] = 0) : (s[e] = (s[e] || 0) + 1);
          }),
            (this.bidderAttemptsWithoutBid[e] = s);
        }
      }
      function ec() {
        throw Error("[AdContext] No Advertising Context");
      }
      let em = o.createContext({
        addAdUnit: (e) => ec(),
        removeAdUnit: (e, t) => ec(),
      });
      class eg extends o.Component {
        static #e = (this.isFirstRequest = !0);
        constructor(e) {
          super(e),
            (this.refreshTimer = void 0),
            (this.userId = null),
            (this.disabledBidderTracker = new eu(m.numberOfRequestsWithoutBid)),
            (this.resetBiddersToDisableInterval = 0),
            (this.previousBannerEvents = new Map()),
            (this.dispatchLoadingAction = (e) => {
              if (!this.mounted) return;
              let t = this.advertisingLoadingModel.handleAction(e);
              this.setState({ loadingModelState: t });
            }),
            (this.addAdUnit = (e) => {
              !this.adUnits.find((t) => t.id === e.id) &&
                (this.adUnits.push(e),
                this.observer && this.adConfig && this.addUnitToObserver(e));
            }),
            (this.removeAdUnit = (e, t) => {
              (this.adUnits = this.adUnits.filter((t) => t.id !== e.id)),
                this.observer &&
                  this.adConfig &&
                  this.removeUnitFromObserver(e, t);
            }),
            (this.requestAndRenderAds = (e) => {
              let t,
                i = (0, T.A)(),
                s = new Date().getTime(),
                n = new Map();
              this.adUnits.forEach((t) => {
                n.set(t.id, {
                  event: {
                    requestId: i,
                    adUnit: t.id,
                    requestTime: s,
                    requestReason: e,
                    pageVisitId: this.pageVisitId,
                  },
                  fired: !1,
                });
              });
              let r = this.observer;
              if (!(0, l.O)(r)) {
                for (let e of (this.adUnits.forEach((e) => {
                  let t = n.get(e.id)?.event;
                  this.updatePortalBannerAdsEvent(t, {
                    issue: { type: "error", issue: "No ad unit observer" },
                  });
                }),
                n.keys()))
                  this.firePortalBannerAdsEvent(e, n);
                return !1;
              }
              let a = this.getRefreshTimer();
              (t = this.firstPageRequest
                ? this.adUnits.map((e) => {
                    switch (r.isUnitHidden(e.id)) {
                      case "hidden":
                        return {
                          adUnit: e,
                          included: !1,
                          reason: "First request: unit is hidden",
                        };
                      case "visible":
                        return { adUnit: e, included: !0 };
                      case "unknown":
                        return {
                          adUnit: e,
                          included: !1,
                          reason:
                            "First request: unit is unknown to the observer",
                        };
                    }
                  })
                : (0, l.O)(a)
                ? this.adUnits.map((e) => {
                    let t = r.canUnitRefreshWithReason(
                      e.id,
                      a.getMinimumTimeInDOMBeforeRefresh()
                    );
                    if (!t.canRefresh)
                      return { adUnit: e, included: !1, reason: t.reason };
                    if (!0 === t.unknownUnit) {
                      let t = n.get(e.id);
                      this.updatePortalBannerAdsEvent(t?.event, {
                        issue: {
                          type: "warning",
                          issue: "Unit is unknown to the observer",
                        },
                      });
                    }
                    return { adUnit: e, included: !0 };
                  })
                : this.adUnits.map((e) => ({
                    adUnit: e,
                    included: !1,
                    reason:
                      "Refresh helper doesn't exist and not first page request",
                  })))
                .filter((e) => !e.included)
                .forEach((e) => {
                  let t = n.get(e.adUnit.id);
                  this.updatePortalBannerAdsEvent(t?.event, {
                    skipPhase: "auction",
                    skipReason: e.reason,
                  }),
                    this.firePortalBannerAdsEvent(e.adUnit.id, n);
                });
              let d = t
                  .filter((e) => e.included)
                  .map((e) => e.adUnit)
                  .map((e) => e.id),
                { validUnits: o, invalidUnits: u } =
                  this.adUnitsRequestConfig();
              if (
                (u.forEach((e) => {
                  let t = n.get(e.unit.id);
                  this.updatePortalBannerAdsEvent(t?.event, {
                    issue: { type: "error", issue: e.reason },
                  }),
                    this.firePortalBannerAdsEvent(e.unit.id, n),
                    e.unit.onRender(!0);
                }),
                0 === o.length || 0 === d.length)
              ) {
                for (let e of n.keys()) this.firePortalBannerAdsEvent(e, n);
                return !0;
              }
              let c = window.CrazygamesAds;
              if (!(0, l.O)(c)) {
                for (let e of (o.forEach((e) => {
                  let { bannerUnit: t, unit: i } = e,
                    s = n.get(t.adUnit.code);
                  this.updatePortalBannerAdsEvent(s?.event, {
                    issue: {
                      type: "error",
                      issue: "Rafvertizing failed to load",
                    },
                  }),
                    i.onRender(!0);
                }),
                n.keys()))
                  this.firePortalBannerAdsEvent(e, n);
                return !1;
              }
              let m = { units: o.map((e) => e.bannerUnit), codes: d },
                g = this.requestAdsOptions(),
                f = (0, l.O)(g.user?.email);
              return (
                c
                  .requestOnly(m, g)
                  .then(async (e) => {
                    if (!this.mounted) return;
                    let t = c.getConsentInformation(
                      this.state.loadingModelState.userInfo.countryCode
                    ).state;
                    for (let i of (e.skippedAdUnits.forEach((e) => {
                      let t = n.get(e.adUnitId);
                      this.updatePortalBannerAdsEvent(t?.event, {
                        skipPhase: "auction",
                        skipReason: e.reason,
                      });
                    }),
                    n.keys())) {
                      let s = (function (e, t, i, s) {
                        return (function (e, t, i, s) {
                          let n = (function (e, t) {
                              if (!(0, l.O)(e)) return;
                              let i = e.adUnits.filter((e) => t(e.id));
                              if (0 === i.length) return;
                              let s = i.length > 1;
                              return {
                                auctionId: e.auctionId,
                                auctionTimedOut: e.timedOut,
                                floor: h(i.map((e) => e.floor)),
                                bidders: i.flatMap((e) => e.bidders),
                                disabledBidders: Array.from(
                                  new Set(i.flatMap((e) => e.disabledBidders))
                                ),
                                noBidBidders: i.flatMap((e) => e.noBidsBidders),
                                timedOutBidders: i.flatMap(
                                  (e) => e.timedOutBidders
                                ),
                                bids: i.flatMap((e) =>
                                  e.bids.map((t) =>
                                    s ? { ...t, adUnitId: e.id } : t
                                  )
                                ),
                                rejectedBids: i.flatMap((e) =>
                                  e.rejectedBids.map((t) =>
                                    s ? { ...t, adUnitId: e.id } : t
                                  )
                                ),
                                duration: e.duration,
                              };
                            })(e.prebidAuctionInformation, s),
                            r = (function (e, t) {
                              if (!(0, l.O)(e)) return;
                              let i = e.adUnits.filter((e) => t(e.id));
                              if (0 === i.length) return;
                              let s = i.length > 1;
                              return {
                                floor: h(i.map((e) => e.floor)),
                                bids: i.flatMap((e) =>
                                  e.bids.map((t) =>
                                    s ? { ...t, adUnitId: e.id } : t
                                  )
                                ),
                                auctionTimedOut: e.timedOut,
                              };
                            })(e.amazonAuctionInformation, s);
                          if ((0, l.O)(n) || (0, l.O)(r))
                            return {
                              hasEmail: t,
                              consent: i,
                              prebid: n,
                              amazon: r,
                              bidCache: (function (e, t) {
                                let i = Object.entries(e ?? {}).filter((e) => {
                                  let [i] = e;
                                  return t(i);
                                });
                                if (0 !== i.length)
                                  return i.map((e) => {
                                    let [t, i] = e;
                                    return {
                                      adUnitId: t,
                                      bids: i.bids,
                                      highestCpm: (0, l.y)(i.highestCpm),
                                      medianCpm: (0, l.y)(i.medianCpm),
                                    };
                                  });
                              })(e.bidCacheInformation, s),
                            };
                        })(t, i, s, (t) => t === e);
                      })(i, e, f, t);
                      (0, l.O)(s) &&
                        this.updatePortalBannerAdsEvent(n.get(i)?.event, {
                          auctionInfo: s,
                        });
                    }
                    let i = this.renderAds(d, n);
                    (0, l.O)(e) &&
                      this.disabledBidderTracker.onRequestAdsResult(
                        m,
                        g,
                        e.requestAdsResult
                      ),
                      await i;
                  })
                  .catch((e) => console.error(e)),
                this.firstPageRequest &&
                  ((this.firstPageRequest = !1),
                  (eg.isFirstRequest = !1),
                  this.getRefreshTimer()?.handleExternalEvent({
                    type: "initialAdsRequestFinished",
                  })),
                !0
              );
            }),
            (this.pageFocusChangeCallback = (e) => {
              this.mounted &&
                this.getRefreshTimer()?.handleExternalEvent({
                  type: "focusChanged",
                  hasFocus: e,
                });
            }),
            (this.adUnits = []),
            "enabled" ===
            e.getResolvedExperimentValue(
              "czyExpClientBannerMinTimeInView_CZY_22047"
            )
              ? (this.timeInViewInMs = g.minTimeInViewMsExperiment)
              : (this.timeInViewInMs = g.minTimeInViewMs),
            (this.viewPortThreshold = g.minVisibleRatio),
            (this.observer = null),
            (this.advertisingLoadingModel = new eh(
              (e) => (0, F.A)(e, this.props.pageUrlHelper) && (0, B.NJ)(e)
            )),
            (this.state = {
              loadingModelState: this.advertisingLoadingModel.retrieveState(),
            }),
            (this.disabled = this.props.disabled),
            (this.pageVisitId =
              this.props.services.crazyAnalyticsService.getPageVisitId());
        }
        componentDidMount() {
          (this.mounted = !0),
            (this.observer = new j(
              this.viewPortThreshold,
              this.timeInViewInMs
            )),
            (this.firstPageRequest = !0),
            (this.resetBiddersToDisableInterval = window.setInterval(() => {
              this.resetBiddersToDisable();
            }, m.resetIntervalMs)),
            this.props.services.crazyAnalyticsService
              .analyticsInfo()
              .then((e) => {
                this.userId = e.userId;
              });
        }
        componentWillUnmount() {
          (this.mounted = !1),
            this.getRefreshTimer()?.handleExternalEvent({
              type: "willUnmount",
            }),
            this.observer && (this.observer.stop(), (this.observer = null));
          let e = window;
          e.CrazygamesAds &&
            e.CrazygamesAds.nextPage &&
            e.CrazygamesAds.nextPage(),
            window.clearInterval(this.resetBiddersToDisableInterval);
        }
        componentDidUpdate(e, t, i) {
          let s = this.state.loadingModelState;
          if (s.ready && !(0, l.O)(this.adConfig)) {
            if (((this.adConfig = s.config), !s.hasEnabledBannerBidders))
              return;
            this.initRefreshTimer(),
              this.addUnitsToObserver(),
              this.toRequestAds("component mounted and ready");
          }
        }
        render() {
          return (0, d.jsxs)(d.Fragment, {
            children: [
              !this.disabled &&
                (0, d.jsxs)(d.Fragment, {
                  children: [
                    (0, d.jsx)(eo, {
                      dispatch: this.dispatchLoadingAction,
                      pageUrlHelper: this.props.pageUrlHelper,
                      resetLibrary: !eg.isFirstRequest,
                      adsLoaderContext: this.props.adsLoaderContext,
                    }),
                    (0, d.jsx)(en, { dispatch: this.dispatchLoadingAction }),
                    (0, d.jsx)(ea, { dispatch: this.dispatchLoadingAction }),
                    (0, d.jsx)(ed, {
                      dispatch: this.dispatchLoadingAction,
                      state: this.state.loadingModelState,
                      locale: (0, q.qz)(this.props.locale),
                      deviceType: this.props.device.deviceType,
                    }),
                  ],
                }),
              (0, d.jsx)(em.Provider, {
                value: {
                  addAdUnit: this.addAdUnit,
                  removeAdUnit: this.removeAdUnit,
                },
                children: this.props.children,
              }),
            ],
          });
        }
        async toRequestAds(e) {
          await this.requestAds(e), this.mounted && this.addObserverCallbacks();
        }
        async requestAds(e) {
          if (
            0 !== this.adUnitsRequestConfig().validUnits.length &&
            (await this.observer.waitForObservedUnitsCallbacks(), this.mounted)
          )
            return this.requestAndRenderAds(e);
        }
        updatePortalBannerAdsEvent(e, t) {
          if ((0, l.O)(e))
            for (let i of Object.keys(t))
              if ("issue" === i)
                ((0, l.O)(e.issue) &&
                  ("warning" !== e.issue.type || t.issue?.type !== "error")) ||
                  (e.issue = t.issue);
              else if ("skipPhase" === i || "skipReason" === i)
                (0, l.O)(e.skipReason) ||
                  (0, l.O)(e.skipPhase) ||
                  ((e.skipPhase = t.skipPhase), (e.skipReason = t.skipReason));
              else if ("auctionInfo" === i)
                (0, l.O)(e.auctionInfo)
                  ? (0, l.O)(t.auctionInfo) &&
                    (e.auctionInfo = { ...e.auctionInfo, ...t.auctionInfo })
                  : (e.auctionInfo = t.auctionInfo);
              else {
                let s = t[i];
                (0, l.O)(s) && (e[i] = s);
              }
        }
        firePortalBannerAdsEvent(e, t) {
          let i = t.get(e);
          if (!(0, l.O)(i)) return;
          let { event: s, fired: n } = i;
          if (n) return;
          let r = this.previousBannerEvents.get(e)?.event;
          ((0, l.O)(s.skipReason) &&
            s.skipReason === r?.skipReason &&
            s.skipPhase === r?.skipPhase) ||
            this.props.services.crazyAnalyticsService.portalBannerEvent(s),
            (i.fired = !0),
            this.previousBannerEvents.set(e, i);
        }
        requestAdsOptions() {
          var e, t, i, s, n;
          let r,
            a,
            { dollarRate: d, ...o } = this.adConfig.advertising,
            l = this.getTimeout(),
            h = this.adConfig.bidders.map((e) =>
              this.mapApiConfigToBidderConfig(e)
            ),
            c = this.getUserDetails(),
            m = window.location.origin + window.location.pathname,
            g =
              ((e = {
                name: this.props.advertisingGame.gameName,
                tagSlugs: this.props.advertisingGame.tagsSlug,
                upvotes: this.props.advertisingGame.numLikes,
              }),
              (t = (0, R.lR)((0, q.qz)(this.props.locale))),
              (i = this.props.advertisingGame.categoryName),
              (s = this.props.advertisingGame.categoryEnSlug),
              (r = (e.tagSlugs || []).filter((e) => -1 === u.Bm.indexOf(e))),
              (a = {
                title: e.name,
                url: m ?? window.location.href,
                context: 2,
                userrating: `${e.upvotes}`,
                sourcerelationship: 1,
                keywords: r.join(","),
                language: t,
                cattax: 9,
                cat: A,
                contentrating: "E",
                qagmediarating: 2,
                prodq: 1,
                livestream: 0,
                network: y,
              }),
              (0, b.y)(i) && (a.genre = i),
              (0, b.y)(s) &&
                ((a.channel = { id: s, domain: y.domain }),
                (0, b.y)(i) && (a.channel.name = `CrazyGames — ${i}`)),
              {
                page: m,
                content: a,
                name: "CrazyGames",
                keywords: w.join(","),
              }),
            f = {
              game_slug: (n = {
                slug: this.props.advertisingGame.gameSlug,
                tagSlugs: this.props.advertisingGame.tagsSlug,
                categorySlug: this.props.advertisingGame.categoryEnSlug,
              }).slug,
              tags_slug: n.tagSlugs,
              category_slug: n.categorySlug,
            };
          return {
            ...o,
            bidders: h,
            timeout: l,
            user: c,
            pageUrl: m,
            ortb2Site: g,
            categoryName: this.props.advertisingGame.categoryName,
            dealTargeting: f,
          };
        }
        async renderAds(e, t) {
          try {
            let i = this.renderAdsOptions(e, t),
              s = window.CrazygamesAds;
            (0, l.O)(s) && (await s.render(e, i));
          } catch (e) {
            console.error(e);
          }
        }
        renderAdsOptions(e, t) {
          let i = this.adConfig.bidders.find((e) => "google" === e.id),
            s = i
              ? {
                  googleBidder: {
                    ...this.mapApiConfigToBidderConfig(i),
                    enabled: !0,
                  },
                }
              : {},
            n = {};
          return (
            e.forEach((e) => {
              (0, W.z)(e)
                ? (n[e] = { clearSlotIfEmpty: !0 })
                : (n[e] = { clearSlotIfEmpty: !1 });
            }),
            {
              gam: this.gamKeys(),
              banner: {
                callback: (e) => {
                  let {
                      minPrice: i,
                      code: s,
                      empty: n,
                      type: r,
                      houseAd: a,
                    } = e,
                    d = t.get(s);
                  if ("UnitRendered" === r) {
                    var o, h;
                    let t = this.props.services,
                      r = a || n ? 0 : i;
                    (o = {
                      analyticsService: t.analyticsService,
                      crazyAnalyticsService: t.crazyAnalyticsService,
                    }),
                      (h = {
                        value: r,
                        gameSlug: this.props.advertisingGame.gameSlug,
                      }),
                      null === k &&
                        (k = {
                          timeoutId: window.setTimeout(() => {
                            for (let e in (o.crazyAnalyticsService.bannerAdConversion(
                              k?.totalValue || 0
                            ),
                            k?.valueByGame))
                              o.analyticsService.trackAdConversion({
                                gameSlug: e,
                                value: k?.valueByGame[e] ?? 0,
                              });
                            !(function () {
                              if ("u" < typeof gtag || !k || !k.totalValue)
                                return;
                              let e = k.totalValue;
                              gtag("event", "conversion", {
                                send_to: `${I}/${L.R}`,
                                value: e,
                                currency: "EUR",
                              }),
                                gtag("event", "conversion", {
                                  send_to: `${I}/${L.i}`,
                                  value: e / 1e3,
                                  currency: "EUR",
                                });
                            })(),
                              (k = null);
                          }, 1e3),
                          totalValue: 0,
                          valueByGame: {},
                        }),
                      (k.totalValue = k.totalValue + h.value),
                      (k.valueByGame[h.gameSlug] =
                        (k.valueByGame[h.gameSlug] || 0) + h.value);
                    let c = this.adUnits.find((e) => e.id === s);
                    void 0 !== c && c.onRender(n),
                      this.updatePortalBannerAdsEvent(d?.event, {
                        renderInfo: (function (e) {
                          let {
                              minPrice: t,
                              empty: i,
                              houseAd: s,
                              impressionCount: n,
                              advertiserId: r,
                              lineItemId: a,
                            } = e,
                            d = (0, u.Yr)(r, { houseAd: s, empty: i });
                          return {
                            minCpm: s || i ? void 0 : t,
                            empty: i,
                            houseAd: s,
                            impressionCount: n,
                            advertiserId: (0, l.O)(r) ? `${r}` : null,
                            advertiserName: d,
                            lineItemId: (0, l.O)(a) ? `${a}` : null,
                          };
                        })(e),
                      });
                  } else
                    this.updatePortalBannerAdsEvent(d?.event, {
                      skipPhase: "render",
                      skipReason: e.reason,
                    });
                  this.firePortalBannerAdsEvent(s, t);
                },
                unitOptions: n,
              },
              ...s,
            }
          );
        }
        getTimeout() {
          return eg.isFirstRequest ? c.firstRequestMs : c.subsequentRequestsMs;
        }
        mapApiConfigToBidderConfig(e) {
          let t = { bidder: e.id, ...e.config };
          return "adsense" === e.id
            ? { ...t, enabled: !1 }
            : { enabled: !0, ...t };
        }
        adUnitsRequestConfig() {
          let e = [],
            t = [];
          for (let i of this.adUnits) {
            let s = this.getUnitDefinition(i.id);
            if (!(0, l.O)(s)) {
              console.error(`[Advertising] Unexpected id ${i.id}`),
                t.push({ unit: i, reason: "No unit definition found" });
              continue;
            }
            let n = this.disabledBidderTracker.getBiddersToDisable(i.id),
              r = s.config.request.bidders.map((e) =>
                n.includes(e.bidder) || "adsense" === e.bidder
                  ? { ...e, enabled: !1 }
                  : e
              );
            e.push({
              bannerUnit: {
                adType: "portalBanner",
                adUnit: { mediaTypes: s.definition.mediaTypes, code: i.id },
                slotId: s.definition.slotId,
                ...s.config.request,
                bidders: r,
              },
              unit: i,
            });
          }
          return { validUnits: e, invalidUnits: t };
        }
        addUnitsToObserver() {
          this.adUnits.forEach((e) => {
            this.addUnitToObserver(e);
          });
        }
        addObserverCallbacks() {
          this.observer.addPageFocusChangeCallback(
            this.pageFocusChangeCallback
          );
        }
        addUnitToObserver(e) {
          this.getUnitDefinition(e.id)
            ? this.observer.addElement(e.id)
            : console.error("Missing definition", e.id);
        }
        removeUnitFromObserver(e, t) {
          let i = this.getUnitDefinition(e.id);
          i
            ? i.definition.refresh && this.observer.removeElement(e.id, t)
            : console.error("Missing definition", e.id);
        }
        gamKeys() {
          var e;
          let { pageUrlHelper: t, advertisingGame: i } = this.props,
            { gameSlug: s, tagsSlug: n, categoryEnSlug: r, loader: a } = i;
          return {
            ...(function (e, t, i, s, n, r, a, d, o, h, u, c, m) {
              var g;
              let f;
              if ((0, l.O)(n)) {
                let e = new Date(n.date),
                  t = e.getUTCDate().toString().padStart(2, "0"),
                  i = (e.getUTCMonth() + 1).toString().padStart(2, "0"),
                  s = e.getUTCFullYear().toString().slice(-2);
                f = `${n.adGroup}_${t}_${i}_${s}`;
              }
              return {
                domain: e,
                category_slug: t,
                game_slug: i,
                tags_slug: s.length > 0 ? s : void 0,
                adgroup_acqdate: f,
                os: r,
                device: a,
                tgps: Math.min(d, 128).toString(),
                locale: (0, l.O)(o) ? o.replace("_", "-") : void 0,
                logged_in: `${h}`,
                network_speed:
                  ((g = u),
                  (0, l.O)(g)
                    ? g > 10
                      ? "10"
                      : g < 0
                      ? "0"
                      : g.toFixed(0)
                    : "unknown"),
                browser_size: (function () {
                  let e = window.innerWidth,
                    t = window.innerHeight,
                    i = v.find((i) => i.width === e && i.height === t);
                  if ((0, l.O)(i)) {
                    var s;
                    return (s = i), `${s.width}x${s.height}`;
                  }
                })(),
                game_technology: c,
                pwa: `${m}`,
              };
            })(
              t.routeData.hostname,
              r,
              s,
              n,
              (0, H.$x)(),
              (function (e) {
                if (!e) return "unknown";
                switch (e) {
                  case p.f.android:
                    return "android";
                  case p.f.ios:
                    return "ios";
                  case p.f.windows:
                    return "windows";
                  case p.f.macos:
                    return "macos";
                  case p.f.linux:
                    return "linux";
                  case p.f.chromeos:
                    return "chromiumos";
                  case p.f.other:
                    return "other";
                }
              })(this.props.device.os),
              !(e = this.props.device.deviceType) ? "unknown" : e,
              this.props.services.gamesPlayedService.getTotalGamesPlayedInSession(),
              (0, q.qz)(this.props.locale),
              this.isLoggedIn(),
              (function () {
                try {
                  return window.navigator.connection?.downlink;
                } catch {
                  return;
                }
              })(),
              a,
              (0, U.Mu)()
            ),
            ...(0, C.gQ)(this.props.getConfigCatValue, {
              operatingSystem: this.props.device.os,
              browser: this.props.device.browser?.name,
            }),
          };
        }
        isLoggedIn() {
          return !!this.props.userContext.user;
        }
        getUnitDefinition(e) {
          return this.adConfig.units.find((t) => t.id === e);
        }
        getRefreshTimer() {
          return (
            (0, l.O)(this.refreshTimer) || this.initRefreshTimer(),
            this.refreshTimer
          );
        }
        initRefreshTimer() {
          var e, t, i, s;
          if (
            !this.state.loadingModelState.ready ||
            (0, l.O)(this.refreshTimer)
          )
            return;
          let n = this.requestAndRenderAds;
          (this.refreshTimer =
            ((e = this.props.device.os),
            (t = this.props.device.browser?.name),
            (i = this.props.device),
            (s =
              "enabled" ===
              this.props.getResolvedExperimentValue(
                "czyExpClientAdsHolidayMode_CZY_21360"
              )),
            new Z(
              n,
              (0, K.Kg)(i)
                ? {
                    type: "waitUntilAfterGameLoading",
                    minimumWaitTimeAfterPageLoad:
                      Q.lowEndDevices.minDelayAfterPageLoadToStartRefreshingMs,
                  }
                : { type: "startOnMount" },
              (function (e, t) {
                let i =
                    arguments.length > 2 &&
                    void 0 !== arguments[2] &&
                    arguments[2],
                  s = (function (e, t) {
                    let i = ee(e),
                      s = ee(t);
                    for (let e of X) {
                      let t = 0 === e.browsers.length || e.browsers.includes(s),
                        n = 0 === e.os.length || e.os.includes(i);
                      if (t && n) return !0;
                    }
                    return !1;
                  })(e, t),
                  n = s ? Q.highlyAffectedSystems : Q.regular,
                  r = i && !s ? Q.holidayModeMaxTimeBetweenRefreshesMs : 1 / 0;
                return {
                  minimumTimeBetweenRefreshes: Math.min(
                    n.minTimeBetweenRefreshesMs,
                    r
                  ),
                  maximumTimeBetweenRefreshes: Math.min(
                    n.maxTimeBetweenRefreshesMs,
                    r
                  ),
                  minimumTimeInDOM: n.minTimeInDomMs,
                };
              })(e, t, s)
            ))),
            this.refreshTimer.handleExternalEvent({ type: "mounted" }),
            this.firstPageRequest ||
              this.refreshTimer.handleExternalEvent({
                type: "initialAdsRequestFinished",
              });
        }
        getUserEmail() {
          let { user: e, loadingUser: t } = this.props.userContext;
          return t ? (0, _.H7)()?.email ?? null : (0, E.F)(e?.email);
        }
        getUserDetails() {
          return { email: this.getUserEmail(), id: this.userId };
        }
        resetBiddersToDisable() {
          this.disabledBidderTracker.reset();
        }
      }
      let ef =
        ((r = (0, S.A)(
          ((n = (0, P.A)(
            ((s = (e) => {
              let t,
                i = (0, M.c)(3),
                s = o.useContext(et.B);
              return (
                i[0] !== s || i[1] !== e
                  ? ((t = (0, d.jsx)(eg, { adsLoaderContext: s, ...e })),
                    (i[0] = s),
                    (i[1] = e),
                    (i[2] = t))
                  : (t = i[2]),
                t
              );
            }),
            (e) => {
              let t,
                i = (0, M.c)(3),
                n = o.useContext(O.R);
              return (
                i[0] !== e || i[1] !== n
                  ? ((t = (0, d.jsx)(s, { userContext: n, ...e })),
                    (i[0] = e),
                    (i[1] = n),
                    (i[2] = t))
                  : (t = i[2]),
                t
              );
            })
          )),
          (e) => {
            let t,
              i = (0, M.c)(3),
              { pageUrlHelper: s } = o.useContext(x.e);
            return (
              i[0] !== s || i[1] !== e
                ? ((t = (0, d.jsx)(n, { pageUrlHelper: s, ...e })),
                  (i[0] = s),
                  (i[1] = e),
                  (i[2] = t))
                : (t = i[2]),
              t
            );
          })
        )),
        (a = (e) => {
          let t,
            i,
            s = (0, M.c)(5),
            n = (0, D.x)();
          s[0] !== n
            ? ((t = (e) => (0, V.y_)(e, n(e))), (s[0] = n), (s[1] = t))
            : (t = s[1]);
          let a = t;
          return (
            s[2] !== a || s[3] !== e
              ? ((i = (0, d.jsx)(r, { getResolvedExperimentValue: a, ...e })),
                (s[2] = a),
                (s[3] = e),
                (s[4] = i))
              : (i = s[4]),
            i
          );
        }),
        (e) => {
          let t,
            i = (0, M.c)(3),
            s = (0, D.x)();
          return (
            i[0] !== s || i[1] !== e
              ? ((t = (0, d.jsx)(a, { getConfigCatValue: s, ...e })),
                (i[0] = s),
                (i[1] = e),
                (i[2] = t))
              : (t = i[2]),
            t
          );
        });
    },
    89147: (e, t, i) => {
      i.d(t, { z: () => n });
      var s = i(18019);
      function n(e) {
        switch (e) {
          case s.R.RightMpuRefresh:
          case s.R.LeaderboardBelowGameRefresh:
          case s.R.SecondLeaderboardBelowGameRefresh:
            return !0;
          case s.R.SecondMpuBelowGameRefresh:
            return !1;
          default:
            throw Error(`Unknown ad unit id: ${e}`);
        }
      }
    },
    90949: (e, t, i) => {
      i.d(t, { A: () => d });
      var s = i(6029),
        n = i(75155),
        r = i(55729),
        a = i(4230);
      let d = function (e) {
        return (t) => {
          let i,
            d = (0, n.c)(3),
            o = r.useContext(a.A);
          return (
            d[0] !== o || d[1] !== t
              ? ((i = (0, s.jsx)(e, { device: o, ...t })),
                (d[0] = o),
                (d[1] = t),
                (d[2] = i))
              : (i = d[2]),
            i
          );
        };
      };
    },
  },
]);
