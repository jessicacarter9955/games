!(function () {
  try {
    var t =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (t._sentryModuleMetadata = t._sentryModuleMetadata || {}),
      (t._sentryModuleMetadata[new t.Error().stack] = (function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];
          if (null != n) for (var a in n) n.hasOwnProperty(a) && (t[a] = n[a]);
        }
        return t;
      })({}, t._sentryModuleMetadata[new t.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var e = new t.Error().stack;
    e &&
      ((t._sentryDebugIds = t._sentryDebugIds || {}),
      (t._sentryDebugIds[e] = "b93e909f-5a69-4b94-acef-a2c15fa0dda6"),
      (t._sentryDebugIdIdentifier =
        "sentry-dbid-b93e909f-5a69-4b94-acef-a2c15fa0dda6"));
  } catch (t) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [33297],
    {
      3470: (t, e, n) => {
        "use strict";
        n.d(e, { A: () => d });
        var a = n(6029),
          i = n(75155);
        n(55729);
        var o = n(79942),
          c = n(50212),
          r = n(46571),
          _ = n(85036),
          u = n(29425),
          l = n.n(u);
        let d = (t) => {
          let e,
            n,
            u,
            d,
            y,
            g,
            s = (0, i.c)(18),
            { tag: z, animateTextOnHover: B, onClick: h, dataTestId: T } = t,
            G = void 0 === B || B,
            { name: k, isCategory: m, gamesCount: p } = z,
            { i18n: f } = (0, o.uB)(),
            b = z.enSlug;
          return (
            s[0] === Symbol.for("react.memo_cache_sentinel")
              ? ((e = (0, c.A)(l().tagPillContainer, "tagPill")), (s[0] = e))
              : (e = s[0]),
            s[1] !== G
              ? ((n = (0, c.A)({ [l().animateTextOnHover]: G })),
                (s[1] = G),
                (s[2] = n))
              : (n = s[2]),
            s[3] !== k || s[4] !== n
              ? ((u = (0, a.jsx)("p", { className: n, children: k })),
                (s[3] = k),
                (s[4] = n),
                (s[5] = u))
              : (u = s[5]),
            s[6] !== p || s[7] !== f
              ? ((d = p && (0, a.jsx)("span", { children: (0, r.A)(f, p) })),
                (s[6] = p),
                (s[7] = f),
                (s[8] = d))
              : (d = s[8]),
            s[9] !== T || s[10] !== u || s[11] !== d
              ? ((y = (0, a.jsxs)("div", {
                  className: e,
                  "data-testid": T,
                  children: [u, d],
                })),
                (s[9] = T),
                (s[10] = u),
                (s[11] = d),
                (s[12] = y))
              : (y = s[12]),
            s[13] !== m || s[14] !== h || s[15] !== b || s[16] !== y
              ? ((g = (0, a.jsx)(_.Ay, {
                  slug: b,
                  isCategory: m,
                  onClick: h,
                  children: y,
                })),
                (s[13] = m),
                (s[14] = h),
                (s[15] = b),
                (s[16] = y),
                (s[17] = g))
              : (g = s[17]),
            g
          );
        };
      },
      8420: (t, e, n) => {
        "use strict";
        n.d(e, { N: () => s });
        var a = n(6029),
          i = n(75155),
          o = n(55729),
          c = n(50212),
          r = n(10204),
          _ = n.n(r);
        let u = new Set();
        function l(t, e, n) {
          !e || u.has(t) || (u.add(t), e(t, n));
        }
        function d(t, e, n) {
          return (0, c.A)(_().link, _()[`link--${t}`], _()[`link--${e}`], n);
        }
        function y(t) {
          let e,
            n,
            c,
            r,
            _,
            u,
            y,
            g,
            s,
            z,
            B,
            h,
            T,
            G,
            k,
            m,
            p,
            f,
            b,
            w = (0, i.c)(43);
          w[0] !== t
            ? (({
                href: c,
                tone: z,
                size: B,
                onNavigate: u,
                onPrefetch: y,
                prefetch: h,
                className: n,
                onClick: r,
                onMouseEnter: _,
                onTouchStart: g,
                children: e,
                ...s
              } = t),
              (w[0] = t),
              (w[1] = e),
              (w[2] = n),
              (w[3] = c),
              (w[4] = r),
              (w[5] = _),
              (w[6] = u),
              (w[7] = y),
              (w[8] = g),
              (w[9] = s),
              (w[10] = z),
              (w[11] = B),
              (w[12] = h))
            : ((e = w[1]),
              (n = w[2]),
              (c = w[3]),
              (r = w[4]),
              (_ = w[5]),
              (u = w[6]),
              (y = w[7]),
              (g = w[8]),
              (s = w[9]),
              (z = w[10]),
              (B = w[11]),
              (h = w[12]));
          let v = void 0 === z ? "neutral" : z,
            x = void 0 === B ? "m" : B,
            I = void 0 !== h && h;
          w[13] !== c || w[14] !== y || w[15] !== I
            ? ((T = () => {
                I && l(c, y, { priority: !1 });
              }),
              (G = [c, I, y]),
              (w[13] = c),
              (w[14] = y),
              (w[15] = I),
              (w[16] = T),
              (w[17] = G))
            : ((T = w[16]), (G = w[17])),
            (0, o.useEffect)(T, G),
            w[18] !== c || w[19] !== r || w[20] !== u
              ? ((k = (t) => {
                  let e;
                  r?.(t),
                    !u ||
                      t.defaultPrevented ||
                      ((e = t.currentTarget.getAttribute("target")) &&
                        "_self" !== e) ||
                      t.metaKey ||
                      t.ctrlKey ||
                      t.shiftKey ||
                      t.altKey ||
                      1 === t.button ||
                      (t.preventDefault(), u(c));
                }),
                (w[18] = c),
                (w[19] = r),
                (w[20] = u),
                (w[21] = k))
              : (k = w[21]);
          let C = k;
          w[22] !== c || w[23] !== _ || w[24] !== y
            ? ((m = (t) => {
                _?.(t), l(c, y, { priority: !0 });
              }),
              (w[22] = c),
              (w[23] = _),
              (w[24] = y),
              (w[25] = m))
            : (m = w[25]);
          let N = m;
          w[26] !== c || w[27] !== y || w[28] !== g || w[29] !== I
            ? ((p = (t) => {
                g?.(t), I && l(c, y, { priority: !0 });
              }),
              (w[26] = c),
              (w[27] = y),
              (w[28] = g),
              (w[29] = I),
              (w[30] = p))
            : (p = w[30]);
          let A = p;
          return (
            w[31] !== n || w[32] !== x || w[33] !== v
              ? ((f = d(v, x, n)),
                (w[31] = n),
                (w[32] = x),
                (w[33] = v),
                (w[34] = f))
              : (f = w[34]),
            w[35] !== e ||
            w[36] !== C ||
            w[37] !== N ||
            w[38] !== A ||
            w[39] !== c ||
            w[40] !== s ||
            w[41] !== f
              ? ((b = (0, a.jsx)("a", {
                  ...s,
                  href: c,
                  className: f,
                  onClick: C,
                  onMouseEnter: N,
                  onTouchStart: A,
                  children: e,
                })),
                (w[35] = e),
                (w[36] = C),
                (w[37] = N),
                (w[38] = A),
                (w[39] = c),
                (w[40] = s),
                (w[41] = f),
                (w[42] = b))
              : (b = w[42]),
            b
          );
        }
        function g(t) {
          let e,
            n,
            o,
            r,
            u,
            l,
            y,
            g,
            s = (0, i.c)(16);
          s[0] !== t
            ? (({
                tone: r,
                size: u,
                type: l,
                className: n,
                children: e,
                ...o
              } = t),
              (s[0] = t),
              (s[1] = e),
              (s[2] = n),
              (s[3] = o),
              (s[4] = r),
              (s[5] = u),
              (s[6] = l))
            : ((e = s[1]),
              (n = s[2]),
              (o = s[3]),
              (r = s[4]),
              (u = s[5]),
              (l = s[6]));
          let z = void 0 === r ? "neutral" : r,
            B = void 0 === u ? "m" : u,
            h = void 0 === l ? "button" : l;
          return (
            s[7] !== n || s[8] !== B || s[9] !== z
              ? ((y = d(z, B, (0, c.A)(_()["link--button"], n))),
                (s[7] = n),
                (s[8] = B),
                (s[9] = z),
                (s[10] = y))
              : (y = s[10]),
            s[11] !== e || s[12] !== o || s[13] !== y || s[14] !== h
              ? ((g = (0, a.jsx)("button", {
                  ...o,
                  type: h,
                  className: y,
                  children: e,
                })),
                (s[11] = e),
                (s[12] = o),
                (s[13] = y),
                (s[14] = h),
                (s[15] = g))
              : (g = s[15]),
            g
          );
        }
        function s(t) {
          let e,
            n = (0, i.c)(4);
          if (void 0 === t.href) {
            let e;
            return (
              n[0] !== t
                ? ((e = (0, a.jsx)(g, { ...t })), (n[0] = t), (n[1] = e))
                : (e = n[1]),
              e
            );
          }
          return (
            n[2] !== t
              ? ((e = (0, a.jsx)(y, { ...t })), (n[2] = t), (n[3] = e))
              : (e = n[3]),
            e
          );
        }
      },
      10204: (t) => {
        t.exports = {
          link: "Link_link__KqNZP",
          "link--button": "Link_link--button__aXtjL",
          "link--s": "Link_link--s__2RNCq",
          "link--m": "Link_link--m__PYNMO",
          "link--l": "Link_link--l__erZKM",
          "link--neutral": "Link_link--neutral__xiSU_",
          "link--green": "Link_link--green__Xiofl",
        };
      },
      27932: (t, e, n) => {
        "use strict";
        n.d(e, { i: () => u });
        var a = n(75155),
          i = n(55729),
          o = n(81278),
          c = n(61827),
          r = n(90930),
          _ = n(40369);
        let u = () => {
          let t,
            e,
            n,
            u,
            d = (0, a.c)(10),
            { crazyRouterChange: y } = i.useContext(c.Gl),
            g = i.useContext(r.o);
          d[0] !== g
            ? ((t = (0, _.Ay)(g)), (d[0] = g), (d[1] = t))
            : (t = d[1]);
          let s = t,
            z = (0, o.useRouter)();
          d[2] !== s || d[3] !== y
            ? ((e = (t) => y(t, void 0, void 0, void 0, s)),
              (d[2] = s),
              (d[3] = y),
              (d[4] = e))
            : (e = d[4]);
          let B = e;
          d[5] !== z
            ? ((n = (t, e) => {
                let { priority: n } = e;
                z?.prefetch(t, void 0, { priority: n }).catch(l);
              }),
              (d[5] = z),
              (d[6] = n))
            : (n = d[6]);
          let h = n;
          return (
            d[7] !== B || d[8] !== h
              ? ((u = { handleNavigate: B, handlePrefetch: h }),
                (d[7] = B),
                (d[8] = h),
                (d[9] = u))
              : (u = d[9]),
            u
          );
        };
        function l() {}
      },
      29425: (t) => {
        t.exports = {
          czyButton: "TagGrid_czyButton__NO8Na",
          "czyButton--contained--purple":
            "TagGrid_czyButton--contained--purple__WxWU_",
          "czyButton--contained--white":
            "TagGrid_czyButton--contained--white__7S6xP",
          "czyButton--contained--grey":
            "TagGrid_czyButton--contained--grey__AlByq",
          "czyButton--contained--warning":
            "TagGrid_czyButton--contained--warning__Fexuw",
          "czyButton--contained--alert":
            "TagGrid_czyButton--contained--alert__Z33Kf",
          "czyButton--contained--success":
            "TagGrid_czyButton--contained--success__LZmA7",
          "czyButton--contained--black":
            "TagGrid_czyButton--contained--black__ANTn7",
          "czyButton--contained--green-gradient":
            "TagGrid_czyButton--contained--green-gradient__4ngd8",
          "czyButton--contained--animated-green-gradient":
            "TagGrid_czyButton--contained--animated-green-gradient__Y_mXy",
          "scroll-gradient": "TagGrid_scroll-gradient__txAlV",
          "czyButton--outlined--purple":
            "TagGrid_czyButton--outlined--purple__7N0Bx",
          "czyButton--link--purple": "TagGrid_czyButton--link--purple__PD1OV",
          "czyButton--outlined--white":
            "TagGrid_czyButton--outlined--white__TsIn9",
          "czyButton--link--white": "TagGrid_czyButton--link--white__A6N9D",
          "czyButton--outlined--grey":
            "TagGrid_czyButton--outlined--grey__GUrAs",
          "czyButton--link--grey": "TagGrid_czyButton--link--grey__PMya5",
          "czyButton--outlined--warning":
            "TagGrid_czyButton--outlined--warning__DBl8p",
          "czyButton--link--warning": "TagGrid_czyButton--link--warning__Z_m3Q",
          "czyButton--outlined--alert":
            "TagGrid_czyButton--outlined--alert__ilUKr",
          "czyButton--link--alert": "TagGrid_czyButton--link--alert__zf1C_",
          "czyButton--outlined--success":
            "TagGrid_czyButton--outlined--success___8kg1",
          "czyButton--link--success": "TagGrid_czyButton--link--success__tyybh",
          "czyButton--outlined": "TagGrid_czyButton--outlined__1DOee",
          "czyButton--disabled": "TagGrid_czyButton--disabled__fYIvp",
          "czyButton--height50": "TagGrid_czyButton--height50__MtHsY",
          "czyButton--height34": "TagGrid_czyButton--height34__oy9d2",
          "czyButton--height28": "TagGrid_czyButton--height28__5muYj",
          "czyButton--fullWidth": "TagGrid_czyButton--fullWidth__YLE_O",
          "czyButton--headerIcon": "TagGrid_czyButton--headerIcon__dNj9z",
          "czyButton--headerIcon--desktop":
            "TagGrid_czyButton--headerIcon--desktop__DXYOV",
          "czyButton--headerIcon--mobile":
            "TagGrid_czyButton--headerIcon--mobile__grohh",
          "czyButton--headerIcon--withLabel":
            "TagGrid_czyButton--headerIcon--withLabel__iMllw",
          tagPillContainer: "TagGrid_tagPillContainer__rY0CY",
          animateTextOnHover: "TagGrid_animateTextOnHover__El9hM",
          tagContainer: "TagGrid_tagContainer__HkVSQ",
          allowOverflow: "TagGrid_allowOverflow__W_ba5",
          tagSection: "TagGrid_tagSection__kZjuM",
          title: "TagGrid_title__T09an",
          tagItem: "TagGrid_tagItem__wiRtz",
          skeleton: "TagGrid_skeleton__cpr9i",
          skeletonDesktop: "TagGrid_skeletonDesktop__queb3",
          skeletonMobile: "TagGrid_skeletonMobile__RFYcn",
        };
      },
      49517: (t) => {
        t.exports = {
          czyButton: "GameTags_czyButton__pU0rF",
          "czyButton--contained--purple":
            "GameTags_czyButton--contained--purple__XrGM0",
          "czyButton--contained--white":
            "GameTags_czyButton--contained--white__obUde",
          "czyButton--contained--grey":
            "GameTags_czyButton--contained--grey__Ar1Tn",
          "czyButton--contained--warning":
            "GameTags_czyButton--contained--warning__fLIDH",
          "czyButton--contained--alert":
            "GameTags_czyButton--contained--alert__ih8Mf",
          "czyButton--contained--success":
            "GameTags_czyButton--contained--success__pvJk2",
          "czyButton--contained--black":
            "GameTags_czyButton--contained--black__Ji5Rm",
          "czyButton--contained--green-gradient":
            "GameTags_czyButton--contained--green-gradient__NuxvG",
          "czyButton--contained--animated-green-gradient":
            "GameTags_czyButton--contained--animated-green-gradient__ZUN7E",
          "scroll-gradient": "GameTags_scroll-gradient__GUftR",
          "czyButton--outlined--purple":
            "GameTags_czyButton--outlined--purple__Ye49z",
          "czyButton--link--purple": "GameTags_czyButton--link--purple__Ci68D",
          "czyButton--outlined--white":
            "GameTags_czyButton--outlined--white__bmeCK",
          "czyButton--link--white": "GameTags_czyButton--link--white__BpG3M",
          "czyButton--outlined--grey":
            "GameTags_czyButton--outlined--grey__WSGva",
          "czyButton--link--grey": "GameTags_czyButton--link--grey__ZddJm",
          "czyButton--outlined--warning":
            "GameTags_czyButton--outlined--warning__SHvnV",
          "czyButton--link--warning":
            "GameTags_czyButton--link--warning__JFsNW",
          "czyButton--outlined--alert":
            "GameTags_czyButton--outlined--alert__jeSTj",
          "czyButton--link--alert": "GameTags_czyButton--link--alert__wJ59D",
          "czyButton--outlined--success":
            "GameTags_czyButton--outlined--success__qv8nO",
          "czyButton--link--success":
            "GameTags_czyButton--link--success__1Kxta",
          "czyButton--outlined": "GameTags_czyButton--outlined__q96bY",
          "czyButton--disabled": "GameTags_czyButton--disabled__Bcsic",
          "czyButton--height50": "GameTags_czyButton--height50__53I28",
          "czyButton--height34": "GameTags_czyButton--height34__W7KJj",
          "czyButton--height28": "GameTags_czyButton--height28__C6IWb",
          "czyButton--fullWidth": "GameTags_czyButton--fullWidth__th0Bf",
          "czyButton--headerIcon": "GameTags_czyButton--headerIcon__UkexN",
          "czyButton--headerIcon--desktop":
            "GameTags_czyButton--headerIcon--desktop__Jz04g",
          "czyButton--headerIcon--mobile":
            "GameTags_czyButton--headerIcon--mobile__gJ0iE",
          "czyButton--headerIcon--withLabel":
            "GameTags_czyButton--headerIcon--withLabel__tAcYG",
          gameTagChipContainer: "GameTags_gameTagChipContainer__F5xPO",
        };
      },
      55678: (t, e, n) => {
        "use strict";
        n.d(e, { A: () => _ });
        var a = n(6029),
          i = n(75155);
        n(55729);
        var o = n(3470),
          c = n(49517),
          r = n.n(c);
        let _ = (t) => {
          let e,
            n,
            c = (0, i.c)(8),
            { tags: _, onTagClick: u, dataTestId: l } = t;
          if (c[0] !== u || c[1] !== _) {
            let t;
            c[3] !== u
              ? ((t = (t, e) =>
                  (0, a.jsx)(
                    o.A,
                    {
                      tag: t,
                      animateTextOnHover: !1,
                      onClick: u ? () => u(t, e) : void 0,
                      dataTestId: `tag-pill-${t.enSlug}`,
                    },
                    t.slug
                  )),
                (c[3] = u),
                (c[4] = t))
              : (t = c[4]),
              (e = _.map(t)),
              (c[0] = u),
              (c[1] = _),
              (c[2] = e);
          } else e = c[2];
          return (
            c[5] !== l || c[6] !== e
              ? ((n = (0, a.jsx)("div", {
                  className: r().gameTagChipContainer,
                  "data-testid": l,
                  children: e,
                })),
                (c[5] = l),
                (c[6] = e),
                (c[7] = n))
              : (n = c[7]),
            n
          );
        };
      },
      85036: (t, e, n) => {
        "use strict";
        n.d(e, { Ay: () => y, Ox: () => d, YA: () => l });
        var a = n(6029),
          i = n(75155),
          o = n(55729),
          c = n(8420),
          r = n(93389),
          _ = n(27932),
          u = n(47004);
        let l = (t) => u.M5.includes(t) || "multiplayer" === t,
          d = (t, e, n) =>
            u.M5.includes(e)
              ? t.multiplayerPageLink("2-player").href
              : "multiplayer" === e
              ? t.multiplayerPageLink("multiplayer").href
              : t.tagOrCategoryPageDirectLink(e, !!n, {}).href,
          y = (t) => {
            let e,
              n,
              y,
              g,
              s = (0, i.c)(18),
              {
                slug: z,
                isCategory: B,
                children: h,
                className: T,
                tone: G,
                onClick: k,
              } = t,
              { routeHelper: m } = o.useContext(r.A),
              { handleNavigate: p, handlePrefetch: f } = (0, _.i)();
            s[0] !== k
              ? ((e = (t) => {
                  (0, u.on)(), k?.(t);
                }),
                (s[0] = k),
                (s[1] = e))
              : (e = s[1]);
            let b = e;
            return (
              s[2] !== B || s[3] !== m || s[4] !== z
                ? ((n = d(m, z, B)),
                  (s[2] = B),
                  (s[3] = m),
                  (s[4] = z),
                  (s[5] = n))
                : (n = s[5]),
              s[6] !== b || s[7] !== k || s[8] !== z
                ? ((y = l(z) ? b : k),
                  (s[6] = b),
                  (s[7] = k),
                  (s[8] = z),
                  (s[9] = y))
                : (y = s[9]),
              s[10] !== h ||
              s[11] !== T ||
              s[12] !== p ||
              s[13] !== f ||
              s[14] !== n ||
              s[15] !== y ||
              s[16] !== G
                ? ((g = (0, a.jsx)(c.N, {
                    href: n,
                    prefetch: !0,
                    tone: G,
                    className: T,
                    onClick: y,
                    onNavigate: p,
                    onPrefetch: f,
                    children: h,
                  })),
                  (s[10] = h),
                  (s[11] = T),
                  (s[12] = p),
                  (s[13] = f),
                  (s[14] = n),
                  (s[15] = y),
                  (s[16] = G),
                  (s[17] = g))
                : (g = s[17]),
              g
            );
          };
      },
    },
  ]);
