!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (null != n) for (var a in n) n.hasOwnProperty(a) && (e[a] = n[a]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "d63fb4e2-20c1-4b80-9c6e-d88c348d806f"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-d63fb4e2-20c1-4b80-9c6e-d88c348d806f"));
  } catch (e) {}
})();
("use strict");
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [32627],
  {
    32627: (e, t, n) => {
      n.d(t, { A: () => W });
      var a = n(6029),
        r = n(75155),
        s = n(55729),
        o = n(50212),
        l = n(89922),
        d = n(52461),
        i = n(69395),
        c = n(15490);
      function u(e) {
        return e();
      }
      var m = n(79942),
        v = n(96967),
        g = n.n(v),
        h = n(4230),
        f = n(34302),
        y = n(47883),
        b = n(90930),
        p = n(82638),
        w = n(37916),
        x = n(40369),
        j = n(94618),
        A = n(37817),
        C = n(71684),
        I = n(37434),
        E = n(33738),
        L = n(52711),
        M = n(83582),
        S = n(99521),
        k = n(82207),
        _ = n(59958),
        N = n(20636),
        T = n.n(N);
      let P = s.memo((e) => {
          let {
              game: t,
              width: n,
              loading: r,
              enableInstantJoin: l,
              autoplayOnlyCentered: d,
              removeThumbLabels: i,
              allowVideo: u = !0,
            } = e,
            { game: v, artworkId: N, artworkExperimentId: P } = (0, y.F)(t),
            O = (0, y.m)(),
            R = v.covers && v.covers["1x1"] ? v.covers["1x1"] : v.cover,
            { gameService: D } = s.useContext(C.A).services,
            G = s.useContext(h.A),
            [W, V] = s.useState(!1),
            [q, F] = s.useState(!1),
            [J, K] = s.useState(!1),
            [z, B] = s.useState(!1),
            [H, U] = s.useState(!1),
            Q = s.useRef(null),
            X = s.useContext(p.g).addViewedGames,
            Y = (0, x.Ay)(s.useContext(b.o)),
            Z = s.useRef(null),
            $ = s.useCallback(() => {
              v && D.prefetchGameData(v, G);
            }, [v, D, G]);
          s.useEffect(() => {
            let e;
            return (
              Q &&
                Q.current &&
                ((e = Q.current),
                L.A.get().observe(Q.current, () => {
                  L.A.get().unobserve(e), X(v.id, Y), V(!0);
                })),
              () => {
                e && L.A.get().unobserve(e);
              }
            );
          }, [v.id, X, Y]),
            (0, f.A)({
              gameId: v.id,
              artworkId: N,
              artworkExperimentId: P,
              enabled: W,
            });
          let ee = s.useMemo(() => g()(() => F(!1), 150), []);
          s.useEffect(() => {
            let e = new IntersectionObserver(
              (e) => {
                let [t] = e,
                  n = window.innerHeight,
                  a =
                    (t.boundingClientRect.top + t.boundingClientRect.bottom) /
                    2,
                  r = 0.3 * n,
                  s = t.intersectionRatio >= 0.4;
                t.isIntersecting && s ? (ee.clear(), F(!0)) : ee(),
                  !J &&
                    t.isIntersecting &&
                    (!d || (a > n / 2 - r && a < n / 2 + r)) &&
                    (K(!0), (0, c.requestIdleCallback)($));
              },
              d
                ? {
                    root: null,
                    rootMargin: "-30% 0px -30% 0px",
                    threshold: 0.5,
                  }
                : { threshold: [0, 0.4, 1] }
            );
            return (
              Q && Q.current && e.observe(Q.current),
              () => {
                e.disconnect();
              }
            );
          }, [r, Q, J, $, d, ee]);
          let et = (0, k.V)(v),
            en = u && H && q && n && !r && !et,
            ea = n && v.cover && O,
            er = q && en && z && H,
            es = i
              ? v.gameThumbLabels?.filter((e) => !i.includes(e)) ?? []
              : v.gameThumbLabels;
          return (0, a.jsx)(E.A, {
            slug: v.slug,
            ref: Z,
            isInstantJoin: l,
            "data-testid": w.y7,
            children: (0, a.jsxs)("div", {
              className: (0, o.A)(
                T().instantThumb,
                T().isLarge,
                et && T().greyedOut
              ),
              children: [
                (0, a.jsxs)("div", {
                  ref: Q,
                  className: T().gameThumbArea,
                  children: [
                    (0, a.jsx)(S.A, { game: v }),
                    ea &&
                      (0, a.jsx)("img", {
                        className: (0, o.A)(T().mainImage, er && T().fadeOut),
                        src: (0, j.Ay)(v.cover, { width: n }),
                        alt: v.name,
                        srcSet: (0, j.Wn)(v.cover, { width: n }),
                        onLoad: () => U(!0),
                      }),
                    (0, a.jsx)("div", { className: T().largeThumbPlaceholder }),
                    en &&
                      (0, a.jsx)(_.A, {
                        videoWidth: n,
                        game: v,
                        onCanPlayThrough: () => B(!0),
                      }),
                    !r &&
                      z &&
                      (0, a.jsxs)("div", {
                        className: T().bottomContainer,
                        children: [
                          (0, a.jsx)("img", {
                            src: (0, j.Ay)(R, { width: 50 }),
                            srcSet: (0, j.Wn)(R, { width: 50 }),
                            alt: v.name,
                          }),
                          (0, a.jsxs)("div", {
                            style: { maxWidth: "calc(100% - 114px)" },
                            children: [
                              (0, a.jsx)("div", {
                                className: T().gameNameContainer,
                                children: v.name,
                              }),
                              (0, a.jsx)("div", {
                                style: { color: "var(--alpha-white-a60)" },
                                children: v.categoryName,
                              }),
                            ],
                          }),
                          (0, a.jsx)(I.A, {
                            variant: "contained",
                            color: "purple",
                            children: (0, a.jsx)(m.x6, {
                              id: "common.instant.play",
                            }),
                          }),
                        ],
                      }),
                  ],
                }),
                (0, a.jsx)(M.default, {
                  videoPlaying: !1,
                  gameThumbLabels: es,
                }),
                (0, a.jsx)(A.A, { gameId: v.id }),
              ],
            }),
          });
        }),
        O = s.memo(() =>
          (0, a.jsx)("div", {
            style: {
              width: "100%",
              borderRadius: 16,
              position: "relative",
              overflow: "hidden",
              aspectRatio: "400 / 224",
              background: "var(--neutral-800)",
            },
          })
        );
      var R = n(74914),
        D = n(29256),
        G = n.n(D);
      let W = (e) => {
        let t,
          n,
          m,
          v,
          g,
          h = (0, r.c)(32),
          {
            games: f,
            loading: y,
            expectedSize: b,
            enableInstantJoin: p,
            customOrigin: w,
            autoplayOnlyCentered: x,
            overlapInOrientationChange: j,
            className: A,
            removeThumbLabels: C,
            videoDeferStrategy: I,
          } = e,
          { innerWidth: E } = s.useContext(R.w),
          L = (0, i.A)(),
          M = ((e) => {
            let t,
              n,
              a = (0, r.c)(3),
              [o, l] = (0, s.useState)(!1);
            return (
              a[0] !== e
                ? ((t = () => {
                    let t,
                      n = !1,
                      a = () => {
                        n || l(!0);
                      },
                      r = [];
                    if ("dom-content-loaded" === e)
                      if ("loading" !== document.readyState) a();
                      else {
                        let e = () => a();
                        document.addEventListener("DOMContentLoaded", e, {
                          once: !0,
                        }),
                          r.push(() =>
                            document.removeEventListener("DOMContentLoaded", e)
                          );
                      }
                    else if ("document-interactive" === e)
                      if ("loading" !== document.readyState) a();
                      else {
                        let e = () => {
                          ("interactive" === document.readyState ||
                            "complete" === document.readyState) &&
                            (document.removeEventListener(
                              "readystatechange",
                              e
                            ),
                            a());
                        };
                        document.addEventListener("readystatechange", e),
                          r.push(() =>
                            document.removeEventListener("readystatechange", e)
                          );
                      }
                    else if ("window-load" === e)
                      if ("complete" === document.readyState) a();
                      else {
                        let e = () => a();
                        window.addEventListener("load", e, { once: !0 }),
                          r.push(() => window.removeEventListener("load", e));
                      }
                    else {
                      let e = () => {
                        t = (0, c.requestIdleCallback)(() => a(), {
                          timeout: 3e3,
                        });
                      };
                      if ("complete" === document.readyState) e();
                      else {
                        let t = () => e();
                        window.addEventListener("load", t, { once: !0 }),
                          r.push(() => window.removeEventListener("load", t));
                      }
                      r.push(() => {
                        void 0 !== t && (0, c.cancelIdleCallback)(t);
                      });
                    }
                    return () => {
                      (n = !0), r.forEach(u);
                    };
                  }),
                  (n = [e]),
                  (a[0] = e),
                  (a[1] = t),
                  (a[2] = n))
                : ((t = a[1]), (n = a[2])),
              (0, s.useEffect)(t, n),
              o
            );
          })(void 0 === I ? "window-load" : I);
        h[0] !== E || h[1] !== L
          ? ((t = () => {
              if (E) return L ? Math.ceil(E / 2) : Math.ceil(E);
            }),
            (h[0] = E),
            (h[1] = L),
            (h[2] = t))
          : (t = h[2]);
        let S = t,
          k = j && G().overlapInOrientationChange;
        if (
          (h[3] !== A || h[4] !== k
            ? ((n = (0, o.A)(G().instantGridContainer, G().largeGrid, k, A)),
              (h[3] = A),
              (h[4] = k),
              (h[5] = n))
            : (n = h[5]),
          h[6] !== b || h[7] !== f.length
            ? ((m = 0 === f.length && (0, l.K)(b).map(V)),
              (h[6] = b),
              (h[7] = f.length),
              (h[8] = m))
            : (m = h[8]),
          h[9] !== M ||
            h[10] !== x ||
            h[11] !== w ||
            h[12] !== p ||
            h[13] !== f ||
            h[14] !== S ||
            h[15] !== L ||
            h[16] !== y ||
            h[17] !== C)
        ) {
          let e;
          h[19] !== M ||
          h[20] !== x ||
          h[21] !== w ||
          h[22] !== p ||
          h[23] !== S ||
          h[24] !== L ||
          h[25] !== y ||
          h[26] !== C
            ? ((e = (e, t) =>
                e.loading
                  ? (0, a.jsx)(O, {}, t)
                  : (0, a.jsx)(
                      d.x,
                      {
                        newClickOrigin: w || "instantLarge",
                        children: (0, a.jsx)(P, {
                          game: e,
                          width: S(),
                          loading: y || e.loading,
                          enableInstantJoin: p,
                          autoplayOnlyCentered: !L && x,
                          removeThumbLabels: C,
                          allowVideo: M,
                        }),
                      },
                      e.slug
                    )),
              (h[19] = M),
              (h[20] = x),
              (h[21] = w),
              (h[22] = p),
              (h[23] = S),
              (h[24] = L),
              (h[25] = y),
              (h[26] = C),
              (h[27] = e))
            : (e = h[27]),
            (v = f.map(e)),
            (h[9] = M),
            (h[10] = x),
            (h[11] = w),
            (h[12] = p),
            (h[13] = f),
            (h[14] = S),
            (h[15] = L),
            (h[16] = y),
            (h[17] = C),
            (h[18] = v);
        } else v = h[18];
        return (
          h[28] !== n || h[29] !== m || h[30] !== v
            ? ((g = (0, a.jsxs)("div", { className: n, children: [m, v] })),
              (h[28] = n),
              (h[29] = m),
              (h[30] = v),
              (h[31] = g))
            : (g = h[31]),
          g
        );
      };
      function V(e) {
        return (0, a.jsx)(O, {}, e);
      }
    },
    59958: (e, t, n) => {
      n.d(t, { A: () => i });
      var a = n(6029),
        r = n(55729),
        s = n(47883),
        o = n(94618),
        l = n(84376);
      let d = r.forwardRef((e, t) => {
          let {
              game: n,
              videoHeight: d,
              videoWidth: i,
              style: c,
              onCanPlayThrough: u,
              isPortrait: m,
              className: v,
              preload: g = "none",
            } = e,
            { game: h } = (0, s.F)(n),
            f = (0, s.m)(),
            y = r.useMemo(() => (d ? { height: d } : { width: i }), [d, i]),
            { videoUrl: b, poster: p } = r.useMemo(() => {
              let e = (0, l.A)(h, y, m);
              if (!e) return { videoUrl: null, poster: void 0 };
              let t = h.covers
                ? m
                  ? h.covers["2x3"]
                  : h.covers["16x9"]
                : h.cover;
              return { videoUrl: e, poster: t ? (0, o.Ay)(t, y) : void 0 };
            }, [h, m, y]);
          return b && f
            ? (0, a.jsx)("video", {
                ref: t,
                loop: !0,
                autoPlay: !0,
                preload: g,
                muted: !0,
                playsInline: !0,
                onCanPlayThrough: u,
                style: c,
                className: v,
                disableRemotePlayback: !0,
                disablePictureInPicture: !0,
                poster: p,
                draggable: !1,
                children: (0, a.jsx)("source", { src: b, type: "video/mp4" }),
              })
            : null;
        }),
        i = r.memo(d);
    },
  },
]);
