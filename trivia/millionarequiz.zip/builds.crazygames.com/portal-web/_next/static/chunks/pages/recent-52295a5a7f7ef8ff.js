!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (null != n) for (var c in n) n.hasOwnProperty(c) && (e[c] = n[c]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "e818bdbf-09e9-4399-a964-0a23c9d8f597"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-e818bdbf-09e9-4399-a964-0a23c9d8f597"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [56689],
    {
      12015: (e, t, n) => {
        (window.__NEXT_P = window.__NEXT_P || []).push([
          "/recent",
          function () {
            return n(20973);
          },
        ]);
      },
      20973: (e, t, n) => {
        "use strict";
        n.r(t), n.d(t, { default: () => C });
        var c = n(6029),
          o = n(75155),
          a = n(55729),
          i = n(79942),
          r = n(23033),
          _ = n(12097),
          u = n(952),
          l = n(77650),
          s = n(50212),
          d = n(14886),
          y = n(52461),
          g = n(50293),
          B = n(4230),
          z = n(33165),
          h = n(70930),
          P = n(93800),
          p = n(77515),
          R = n(65233),
          k = n(86907),
          m = n.n(k),
          w = n(26094),
          f = n.n(w);
        let b = () => {
          let e,
            t,
            n,
            r,
            _,
            u,
            k,
            w,
            b,
            x = (0, o.c)(20),
            v = a.useContext(B.A),
            { openDrawer: I } = a.useContext(z.lv),
            { user: j, loadingUser: C, userTokenExists: D } = a.useContext(d.R),
            { recent: A, loading: E } = a.useContext(R.oJ),
            L = !((C && !D) || E) && A.length > 0 ? A : null,
            [N, M] = a.useState(L);
          L && L !== N && M(L),
            x[0] !== I
              ? ((e = () => {
                  I("myGames");
                }),
                (x[0] = I),
                (x[1] = e))
              : (e = x[1]),
            x[2] !== j
              ? ((t =
                  !j &&
                  (0, c.jsx)("div", {
                    className: f().favoritesLinkContainer,
                    children: (0, c.jsx)(i.x6, {
                      id: "recent.createAccount.subtitle",
                      values: {
                        addLink: (0, c.jsxs)("span", {
                          children: [
                            (0, c.jsx)(P.A, { name: "heart" }),
                            (0, c.jsx)(i.x6, {
                              id: "recent.createAccount.link",
                            }),
                          ],
                        }),
                      },
                    }),
                  })),
                (x[2] = j),
                (x[3] = t))
              : (t = x[3]),
            x[4] !== e || x[5] !== t
              ? ((n = (0, c.jsx)("div", {
                  className: f().noUserPrompt,
                  onClick: e,
                  children: t,
                })),
                (x[4] = e),
                (x[5] = t),
                (x[6] = n))
              : (n = x[6]);
          let T = n;
          x[7] !== v
            ? ((r = (0, s.A)(f().root, { [f().isDesktop]: (0, g.xl)(v) })),
              (x[7] = v),
              (x[8] = r))
            : (r = x[8]),
            x[9] === Symbol.for("react.memo_cache_sentinel")
              ? ((_ = l.Ru._({ id: "common.menu.recent" })), (x[9] = _))
              : (_ = x[9]);
          let W = j ? void 0 : T;
          return (
            x[10] !== W
              ? ((u = (0, c.jsx)(p.A, { title: _, titleRightSlogan: W })),
                (x[10] = W),
                (x[11] = u))
              : (u = x[11]),
            x[12] !== N
              ? ((k =
                  N &&
                  (0, c.jsx)(y.x, {
                    newClickOrigin: "recent",
                    children: (0, c.jsx)(h.A, {
                      games: N,
                      justifyContent: "center",
                      className: m().fullWidth,
                    }),
                  })),
                (x[12] = N),
                (x[13] = k))
              : (k = x[13]),
            x[14] !== k
              ? ((w = (0, c.jsx)("div", {
                  className: f().content,
                  children: (0, c.jsx)("div", {
                    className: f().gridWrapper,
                    children: k,
                  }),
                })),
                (x[14] = k),
                (x[15] = w))
              : (w = x[15]),
            x[16] !== r || x[17] !== u || x[18] !== w
              ? ((b = (0, c.jsxs)("div", { className: r, children: [u, w] })),
                (x[16] = r),
                (x[17] = u),
                (x[18] = w),
                (x[19] = b))
              : (b = x[19]),
            b
          );
        };
        var x = n(20183),
          v = n(93389),
          I = n(66670);
        let j = (e) => {
          let t,
            n,
            r,
            _,
            l,
            s,
            d = (0, o.c)(14),
            { alternatives: y } = e,
            { i18n: g } = (0, i.uB)(),
            { routeHelper: B } = (0, a.useContext)(v.A);
          d[0] !== B
            ? ((t = B.recentPageCanonical()), (d[0] = B), (d[1] = t))
            : (t = d[1]);
          let z = t;
          return (
            d[2] !== g
              ? ((n = g._({ id: "recent.head.title" })), (d[2] = g), (d[3] = n))
              : (n = d[3]),
            d[4] !== g
              ? ((r = g._({ id: "recent.head.metaDescription" })),
                (d[4] = g),
                (d[5] = r))
              : (r = d[5]),
            d[6] !== y || d[7] !== z || d[8] !== n || d[9] !== r
              ? ((_ = (0, c.jsx)(u.A, {
                  canonical: z,
                  alternatives: y,
                  title: n,
                  metaDescription: r,
                })),
                (d[6] = y),
                (d[7] = z),
                (d[8] = n),
                (d[9] = r),
                (d[10] = _))
              : (_ = d[10]),
            d[11] === Symbol.for("react.memo_cache_sentinel")
              ? ((l = (0, c.jsx)(b, {})), (d[11] = l))
              : (l = d[11]),
            d[12] !== _
              ? ((s = (0, c.jsxs)(c.Fragment, { children: [_, l] })),
                (d[12] = _),
                (d[13] = s))
              : (s = d[13]),
            s
          );
        };
        j.getInitialProps = async (e) => {
          let { routeDataService: t } = (0, _.V)(e),
            n = await t.getRouteProviderData("recent");
          return { alternatives: (0, r.T5)(n) };
        };
        let C = (0, x.A)("recent")((0, I.A)(j));
      },
      26094: (e) => {
        e.exports = {
          czyButton: "RecentPage_czyButton__tc4um",
          "czyButton--contained--purple":
            "RecentPage_czyButton--contained--purple__IO01U",
          "czyButton--contained--white":
            "RecentPage_czyButton--contained--white__dhb9F",
          "czyButton--contained--grey":
            "RecentPage_czyButton--contained--grey__7WcQP",
          "czyButton--contained--warning":
            "RecentPage_czyButton--contained--warning__g1lHp",
          "czyButton--contained--alert":
            "RecentPage_czyButton--contained--alert__L_kh1",
          "czyButton--contained--success":
            "RecentPage_czyButton--contained--success__ZtXrI",
          "czyButton--contained--black":
            "RecentPage_czyButton--contained--black__b8KTT",
          "czyButton--contained--green-gradient":
            "RecentPage_czyButton--contained--green-gradient__RnosG",
          "czyButton--contained--animated-green-gradient":
            "RecentPage_czyButton--contained--animated-green-gradient__yXD_Z",
          "scroll-gradient": "RecentPage_scroll-gradient__TkDqD",
          "czyButton--outlined--purple":
            "RecentPage_czyButton--outlined--purple__Jds2J",
          "czyButton--link--purple":
            "RecentPage_czyButton--link--purple__VJ52x",
          "czyButton--outlined--white":
            "RecentPage_czyButton--outlined--white__7O5rd",
          "czyButton--link--white": "RecentPage_czyButton--link--white__uQ2fe",
          "czyButton--outlined--grey":
            "RecentPage_czyButton--outlined--grey__VP2K5",
          "czyButton--link--grey": "RecentPage_czyButton--link--grey__IR0Uo",
          "czyButton--outlined--warning":
            "RecentPage_czyButton--outlined--warning__P5k8L",
          "czyButton--link--warning":
            "RecentPage_czyButton--link--warning__CFSlm",
          "czyButton--outlined--alert":
            "RecentPage_czyButton--outlined--alert__f7yCw",
          "czyButton--link--alert": "RecentPage_czyButton--link--alert__EEsYL",
          "czyButton--outlined--success":
            "RecentPage_czyButton--outlined--success__JPT8a",
          "czyButton--link--success":
            "RecentPage_czyButton--link--success__lawc4",
          "czyButton--outlined": "RecentPage_czyButton--outlined__QOJ2W",
          "czyButton--disabled": "RecentPage_czyButton--disabled__mqkYo",
          "czyButton--height50": "RecentPage_czyButton--height50__HebIh",
          "czyButton--height34": "RecentPage_czyButton--height34__YGxLp",
          "czyButton--height28": "RecentPage_czyButton--height28__hA23R",
          "czyButton--fullWidth": "RecentPage_czyButton--fullWidth__M_rcp",
          "czyButton--headerIcon": "RecentPage_czyButton--headerIcon__doLY6",
          "czyButton--headerIcon--desktop":
            "RecentPage_czyButton--headerIcon--desktop__qY_Em",
          "czyButton--headerIcon--mobile":
            "RecentPage_czyButton--headerIcon--mobile__lPDTG",
          "czyButton--headerIcon--withLabel":
            "RecentPage_czyButton--headerIcon--withLabel__DGWan",
          root: "RecentPage_root__8Irvh",
          isDesktop: "RecentPage_isDesktop__IeHge",
          favoritesLinkContainer: "RecentPage_favoritesLinkContainer___vQt9",
          noUserPrompt: "RecentPage_noUserPrompt__FXBqw",
          content: "RecentPage_content__W2JMp",
          gridWrapper: "RecentPage_gridWrapper__uDvG7",
        };
      },
    },
    (e) => {
      e.O(
        0,
        [6847, 5869, 89247, 88823, 67088, 67473, 46593, 90636, 38792],
        () => e((e.s = 12015))
      ),
        (_N_E = e.O());
    },
  ]);
