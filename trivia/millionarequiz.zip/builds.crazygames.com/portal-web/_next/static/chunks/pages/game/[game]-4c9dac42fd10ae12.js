!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var a = arguments[t];
          if (null != a) for (var r in a) a.hasOwnProperty(r) && (e[r] = a[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "5d5d392f-f055-4c0a-ac42-570854bbe672"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-5d5d392f-f055-4c0a-ac42-570854bbe672"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [28939, 82335],
    {
      23033: (e, t, a) => {
        "use strict";
        a.d(t, {
          $Y: () => x,
          AJ: () => y,
          CZ: () => b,
          EJ: () => A,
          H_: () => f,
          Qe: () => S,
          Qh: () => m,
          Qq: () => g,
          SF: () => w,
          T5: () => h,
          a1: () => _,
          dq: () => d,
          hA: () => T,
          uA: () => v,
          wN: () => P,
          xV: () => E,
        });
        var r = a(14278),
          n = a(4801),
          i = a(72224),
          o = a(13246),
          s = a(61411),
          l = a(57212),
          c = a(87295),
          u = a(79430);
        function d() {
          return o.A.Instance.data.domains
            .map((e) => {
              let t = "en-US" === (0, s.cy)(e.host),
                a = { ...i.a },
                r = new n.A(a).generateHome();
              if (!r) return null;
              let o = (0, u.A)(e.host, r.href, {
                isMainDomain: t,
                locale: e.locale,
              }).toString();
              return { locale: e.locale, href: o.toString(), host: e.host };
            })
            .filter((e) => !!e);
        }
        function g(e) {
          return R((e) => e.generateCompetitions(), {}, e, "competitions");
        }
        function m(e) {
          return R((e) => e.generateScholarship(), {}, e, "scholarship");
        }
        function p(e) {
          return D((t) => t.generatePaginatedUpdatedGames({ page: e }), {});
        }
        function h(e) {
          return R((e) => e.generateRecent(), {}, e, "recent");
        }
        function y() {
          return D((e) => e.generateOriginals(), {});
        }
        function f(e) {
          return R((e) => e.generateTags(), {}, e, "tags");
        }
        function w(e, t) {
          return D((e, t) => e.generateLeaderboards(t), {
            page: e,
            sorting: t,
          });
        }
        function v(e, t) {
          return R((e, t) => e.generateGame(t), { slug: e }, t, "game");
        }
        function P(e) {
          return R((e) => e.generatePrivacyPolicy(), {}, e, "privacyPolicy");
        }
        function A(e) {
          return R(
            (e) => e.generateTermsAndConditions(),
            {},
            e,
            "termsAndConditions"
          );
        }
        function S(e) {
          return R((e) => e.generateSearch(), {}, e, "search");
        }
        function T(e) {
          return D((t) => t.generateProfilePage(e), {});
        }
        async function b(e, t, a, r) {
          if (t && "hot" === t)
            return D((e) => e.generatePaginatedHotGames({ page: 1 }), {});
          switch (e) {
            case c.QI:
              return R(
                (e) => e.generatePaginatedNewGames({ page: r }),
                {},
                await a.getRouteProviderData("newGames"),
                "newGames"
              );
            case c.F3:
              return p(r);
            default:
              return console.warn(`unexpected sorting in games ${e}`), p(r);
          }
        }
        async function x(e, t, a) {
          if (e.isCategory) {
            let r = await t.getRouteProviderData("category");
            return R(
              (e, t) => e.generateCategory(t),
              { slugTrl: e.slug, page: a },
              r,
              "category"
            );
          }
          {
            let r = await t.getRouteProviderData("tag");
            return R(
              (e, t) => e.generateTag(t),
              { slugTrl: e.slug, page: a },
              r,
              "tag"
            );
          }
        }
        function _(e, t, a) {
          return D((t, a) => t.generateMultiplayerWithTag(a, e.slug), {
            page: t,
            sorting: a,
          });
        }
        function E(e) {
          return D((t) => t.generateAllGames(e), {});
        }
        function R(e, t, a, r) {
          var l;
          let c;
          return ((l = a),
          (c = o.A.Instance.data.domains),
          l.map((e) => ({
            domain: c.find((t) => (0, s.qz)(t.locale) === e.locale),
            routeData: e,
          })))
            .map((a) => {
              let o = a.domain,
                l = "en-US" === (0, s.cy)(o.host),
                c = o.locale,
                d = {
                  ...i.a,
                  [r]: a.routeData.route,
                  locale: a.routeData.locale,
                },
                g = e(new n.A(d), t);
              if (!g || !a.domain) return null;
              let m = (0, u.A)(a.domain.host, g.href, {
                isMainDomain: l,
                locale: c,
              }).toString();
              return {
                locale: a.domain.locale,
                href: m.toString(),
                host: a.domain.host,
              };
            })
            .filter((e) => !!e);
        }
        function D(e, t) {
          let a = o.A.Instance.data.domains;
          return r.Y.map((r) => {
            let o = a.find((e) => e.locale === r);
            if (!o) return null;
            let c = "en-US" === (0, s.cy)(o.host),
              d = { ...i.a, locale: l.Ec[r].serverLocale },
              g = e(new n.A(d), t);
            if (!g) return null;
            let m = (0, u.A)(o.host, g.href, {
              isMainDomain: c,
              locale: r,
            }).toString();
            return { locale: o.locale, href: m.toString(), host: o.host };
          }).filter((e) => !!e);
        }
      },
      26356: (e, t, a) => {
        "use strict";
        a.r(t), a.d(t, { default: () => q });
        var r = a(6029),
          n = a(75155),
          i = a(55729),
          o = a(18699),
          s = a(98417),
          l = a(79942),
          c = a(71024),
          u = a.n(c),
          d = a(81278),
          g = a.n(d),
          m = a(86313),
          p = a(45018),
          h = a(33770),
          y = a(13246),
          f = a(36173),
          w = a(952),
          v = a(80123),
          P = a(58107),
          A = a(41645),
          S = a(60092),
          T = a(93389),
          b = a(71543);
        let x = (e) => {
          let t,
            a,
            o,
            s,
            c = (0, n.c)(10),
            { structuredData: u } = e,
            { i18n: d } = (0, l.uB)(),
            { routeHelper: g } = i.useContext(T.A);
          return u
            ? (c[0] !== d || c[1] !== g || c[2] !== u
                ? ((a = "application/ld+json"),
                  (t = JSON.stringify([{ ...u, isPartOf: (0, b.Xr)(d, g) }])),
                  (c[0] = d),
                  (c[1] = g),
                  (c[2] = u),
                  (c[3] = t),
                  (c[4] = a))
                : ((t = c[3]), (a = c[4])),
              c[5] !== t
                ? ((o = { __html: t }), (c[5] = t), (c[6] = o))
                : (o = c[6]),
              c[7] !== a || c[8] !== o
                ? ((s = (0, r.jsx)("script", {
                    type: a,
                    dangerouslySetInnerHTML: o,
                  })),
                  (c[7] = a),
                  (c[8] = o),
                  (c[9] = s))
                : (s = c[9]),
              s)
            : null;
        };
        var _ = a(51196),
          E = a(91831),
          R = a(23033),
          D = a(4230),
          j = a(50293),
          I = a(4699),
          C = a(78029),
          L = a(65889),
          k = a(61411),
          G = a(20183),
          M = a(15583),
          U = a(87295),
          O = a(66670),
          H = a(12097);
        let N = u()(
            () =>
              Promise.all([
                a.e(62005),
                a.e(38332),
                a.e(64323),
                a.e(21451),
                a.e(87108),
                a.e(34873),
                a.e(7694),
                a.e(13e3),
                a.e(9690),
                a.e(33297),
                a.e(13746),
                a.e(86092),
              ]).then(a.bind(a, 70642)),
            {
              loadableGenerated: { webpack: () => [70642] },
              loading: () => null,
              ssr: !0,
            }
          ),
          z = u()(
            () =>
              Promise.all([
                a.e(62005),
                a.e(87108),
                a.e(21451),
                a.e(38332),
                a.e(64323),
                a.e(34873),
                a.e(27239),
                a.e(9690),
                a.e(65597),
                a.e(8603),
                a.e(3601),
                a.e(39565),
                a.e(33297),
                a.e(13746),
                a.e(54840),
                a.e(92511),
              ]).then(a.bind(a, 24795)),
            {
              loadableGenerated: { webpack: () => [24795] },
              loading: () => null,
              ssr: !0,
            }
          );
        {
          let e,
            t = (0, j.nO)();
          (0, s.O)(t) &&
            ((e = (0, C.BM)(
              Object.fromEntries(new URLSearchParams(window.location.search))
            )),
            "enabled" ===
              (0, o.y_)(
                "czyExpClientGamePagePreload",
                e.czyExpClientGamePagePreload
              )) &&
            ((0, j.PS)(t)
              ? Promise.all([
                  a.e(62005),
                  a.e(38332),
                  a.e(64323),
                  a.e(21451),
                  a.e(87108),
                  a.e(34873),
                  a.e(7694),
                  a.e(13e3),
                  a.e(9690),
                  a.e(33297),
                  a.e(13746),
                  a.e(86092),
                ]).then(a.bind(a, 70642))
              : Promise.all([
                  a.e(62005),
                  a.e(87108),
                  a.e(21451),
                  a.e(38332),
                  a.e(64323),
                  a.e(34873),
                  a.e(27239),
                  a.e(9690),
                  a.e(65597),
                  a.e(8603),
                  a.e(3601),
                  a.e(39565),
                  a.e(33297),
                  a.e(13746),
                  a.e(54840),
                  a.e(92511),
                ]).then(a.bind(a, 24795))
            ).catch(() => {});
        }
        let F = (e) => {
          let t,
            a,
            o,
            s,
            c,
            u,
            d,
            g,
            h,
            P,
            A,
            b,
            R,
            C,
            L,
            k,
            G,
            M,
            U,
            O,
            H,
            F,
            q = (0, n.c)(80),
            {
              game: Q,
              related: B,
              alternatives: J,
              isCrawler: K,
              locale: $,
              gamePlayerArm: X,
            } = e,
            { routeHelper: Y } = (0, i.useContext)(T.A),
            Z = (0, i.useContext)(D.A),
            { pageUrlHelper: ee } = (0, i.useContext)(_.e),
            et = (0, l.uB)();
          q[0] !== Q.id
            ? ((t = () => ((0, I.I)({ gameId: Q.id }), W)),
              (a = [Q.id]),
              (q[0] = Q.id),
              (q[1] = t),
              (q[2] = a))
            : ((t = q[1]), (a = q[2])),
            (0, i.useEffect)(t, a);
          let ea = Q.category?.name || "";
          if (
            q[3] !== Q.metaDescription ||
            q[4] !== Q.name ||
            q[5] !== Q.pageTitle ||
            q[6] !== et ||
            q[7] !== ea
          ) {
            let e,
              t = { name: Q.name, category: ea };
            q[10] !== Q.name || q[11] !== Q.pageTitle || q[12] !== et
              ? ((e = Q.pageTitle
                  ? Q.pageTitle
                  : et._("game.head.title", { name: Q.name })),
                (q[10] = Q.name),
                (q[11] = Q.pageTitle),
                (q[12] = et),
                (q[13] = e))
              : (e = q[13]),
              (s = e),
              (o =
                Q.metaDescription ||
                et._("game.head.metaDescriptionFallback", t)),
              (q[3] = Q.metaDescription),
              (q[4] = Q.name),
              (q[5] = Q.pageTitle),
              (q[6] = et),
              (q[7] = ea),
              (q[8] = o),
              (q[9] = s);
          } else (o = q[8]), (s = q[9]);
          let er = o;
          q[14] !== Q.slug || q[15] !== Y
            ? ((c = Y.gameCanonical(Q.slug)),
              (q[14] = Q.slug),
              (q[15] = Y),
              (q[16] = c))
            : (c = q[16]);
          let en = c,
            ei = y.A.Instance.data.advertizing.domain;
          q[17] !== Z || q[18] !== Q || q[19] !== ee
            ? ((u = (0, p.j)(Q, Z, ee)),
              (q[17] = Z),
              (q[18] = Q),
              (q[19] = ee),
              (q[20] = u))
            : (u = q[20]);
          let eo = u;
          q[21] !== Q.tags
            ? ((d = Q.tags.map(V)), (q[21] = Q.tags), (q[22] = d))
            : (d = q[22]);
          let es = d;
          q[23] !== Q.customStructuredData
            ? ((g = () => {
                if (Q.customStructuredData)
                  return (0, r.jsx)("script", {
                    type: "application/ld+json",
                    dangerouslySetInnerHTML: { __html: Q.customStructuredData },
                  });
              }),
              (q[23] = Q.customStructuredData),
              (q[24] = g))
            : (g = q[24]);
          let el = g,
            ec = X ?? null,
            eu = Q.slug,
            ed = Q.category?.enSlug,
            eg = Q.category?.name;
          q[25] !== Q.loaderType ||
          q[26] !== Q.name ||
          q[27] !== Q.slug ||
          q[28] !== Q.upvotes ||
          q[29] !== ed ||
          q[30] !== eg ||
          q[31] !== es
            ? ((h = {
                gameName: Q.name,
                gameSlug: Q.slug,
                categoryEnSlug: ed,
                categoryName: eg,
                tagsSlug: es,
                numLikes: Q.upvotes,
                loader: Q.loaderType,
              }),
              (q[25] = Q.loaderType),
              (q[26] = Q.name),
              (q[27] = Q.slug),
              (q[28] = Q.upvotes),
              (q[29] = ed),
              (q[30] = eg),
              (q[31] = es),
              (q[32] = h))
            : (h = q[32]),
            q[33] === Symbol.for("react.memo_cache_sentinel")
              ? ((P = {}), (q[33] = P))
              : (P = q[33]),
            q[34] !== Q.name
              ? ((A = (0, r.jsx)("meta", {
                  name: "apple-mobile-web-app-title",
                  content: Q.name,
                })),
                (q[34] = Q.name),
                (q[35] = A))
              : (A = q[35]),
            q[36] !== Q.status
              ? ((b =
                  ("BASIC_LAUNCH" === Q.status || "DRAFT" === Q.status) &&
                  (0, r.jsx)("meta", { name: "robots", content: "noindex" })),
                (q[36] = Q.status),
                (q[37] = b))
              : (b = q[37]),
            q[38] === Symbol.for("react.memo_cache_sentinel")
              ? ((R = (0, r.jsx)("link", { rel: "preconnect", href: ei })),
                (q[38] = R))
              : (R = q[38]),
            q[39] !== el
              ? ((C = el()), (q[39] = el), (q[40] = C))
              : (C = q[40]),
            q[41] !== J ||
            q[42] !== en ||
            q[43] !== er ||
            q[44] !== A ||
            q[45] !== b ||
            q[46] !== C ||
            q[47] !== s
              ? ((L = (0, r.jsxs)(w.A, {
                  title: s,
                  metaDescription: er,
                  canonical: en,
                  alternatives: J,
                  children: [A, b, R, C],
                })),
                (q[41] = J),
                (q[42] = en),
                (q[43] = er),
                (q[44] = A),
                (q[45] = b),
                (q[46] = C),
                (q[47] = s),
                (q[48] = L))
              : (L = q[48]),
            q[49] !== Q.structuredData
              ? ((k = (0, r.jsx)(x, { structuredData: Q.structuredData })),
                (q[49] = Q.structuredData),
                (q[50] = k))
              : (k = q[50]);
          let em = Q.cover ?? void 0;
          q[51] !== en || q[52] !== er || q[53] !== em || q[54] !== s
            ? ((G = (0, r.jsx)(E.A, {
                canonical: en,
                title: s,
                description: er,
                imageUrl: em,
                imageQuality: 100,
                type: "game",
              })),
              (q[51] = en),
              (q[52] = er),
              (q[53] = em),
              (q[54] = s),
              (q[55] = G))
            : (G = q[55]),
            q[56] !== Z || q[57] !== Q || q[58] !== K || q[59] !== B
              ? ((M = (0, j.PS)(Z)
                  ? (0, r.jsx)(N, {
                      game: Q,
                      crawlerData: { isCrawler: K, games: B },
                    })
                  : (0, r.jsx)(z, {
                      game: Q,
                      crawlerData: { isCrawler: K, games: B },
                    })),
                (q[56] = Z),
                (q[57] = Q),
                (q[58] = K),
                (q[59] = B),
                (q[60] = M))
              : (M = q[60]),
            q[61] !== eo ||
            q[62] !== Q.slug ||
            q[63] !== $ ||
            q[64] !== h ||
            q[65] !== L ||
            q[66] !== k ||
            q[67] !== G ||
            q[68] !== M
              ? ((U = (0, r.jsxs)(
                  m.A,
                  {
                    locale: $,
                    advertisingGame: h,
                    disabled: eo,
                    edgeExperiments: P,
                    children: [L, k, G, M],
                  },
                  eu
                )),
                (q[61] = eo),
                (q[62] = Q.slug),
                (q[63] = $),
                (q[64] = h),
                (q[65] = L),
                (q[66] = k),
                (q[67] = G),
                (q[68] = M),
                (q[69] = U))
              : (U = q[69]);
          let ep = `gametracking-${Q.slug}`;
          return (
            q[70] !== Q || q[71] !== ep
              ? ((O = (0, r.jsx)(S.A, { game: Q }, ep)),
                (q[70] = Q),
                (q[71] = ep),
                (q[72] = O))
              : (O = q[72]),
            q[73] !== Q
              ? ((H = (0, r.jsx)(f.R, { game: Q })), (q[73] = Q), (q[74] = H))
              : (H = q[74]),
            q[75] !== U || q[76] !== O || q[77] !== H || q[78] !== ec
              ? ((F = (0, r.jsxs)(v.d.Provider, {
                  value: ec,
                  children: [U, O, H],
                })),
                (q[75] = U),
                (q[76] = O),
                (q[77] = H),
                (q[78] = ec),
                (q[79] = F))
              : (F = q[79]),
            F
          );
        };
        F.getInitialProps = async (e) => {
          let t = (0, k.JK)(e),
            a = (e, t, a) => {
              let r = e.category?.enSlug;
              return e.collection
                ? t.tagPageDirectLink(e.collection, { returnRelative: a })
                : e.category
                ? t.categoryPageDirectLink(r, { returnRelative: a })
                : t.homePageLink();
            },
            {
              pageService: r,
              routeDataService: n,
              crawlerService: i,
            } = (0, H.V)(e),
            o = e.query[U.xL],
            s = (0, j.hz)(e),
            l = (0, j.Gz)(s) ? L.fU : L.TS,
            [{ game: c }, u] = await Promise.all([
              r.gamePage(o, s),
              n.getRouteProviderData("game"),
            ]),
            { res: d } = e;
          if ("ARCHIVED" === c.status) {
            let r = await n.getLocaleRouteProviderData(t),
              i = M.A.createFromContext(e, r);
            if (d) {
              let e = a(c, i, !1);
              d.writeHead(302, { Location: e.href }), d.end();
            } else {
              let e = a(c, i, !0);
              await g().push(e.href, e.href);
            }
          }
          d &&
            (d.setHeader(
              "Cache-Control",
              (0, h.H9)({ staleWhileRevalidate: 3600 })
            ),
            c.isKids &&
              (d.writeHead(302, {
                Location: `${y.A.Instance.data.kids}/game/${c.slug}`,
              }),
              d.end()));
          let m = (0, R.uA)(c.slug, u),
            p = "true" === e.query[U.pr],
            f = {
              game: c,
              numRelatedGames: l,
              alternatives: m,
              isCrawler: p,
              locale: t,
            },
            w = p ? null : (0, P.c)(o, s, e.query);
          return ("gameplayer" === w &&
            null !== (0, A.mW)(c) &&
            (f.gamePlayerArm = w),
          "gameframe-ssr" !== w ||
            !e.req ||
            c.isPreview ||
            c.activeArtworkExperiment ||
            (f.gamePlayerArm = w),
          p)
            ? await i.replaceGamePageForCrawler(f, s)
            : f;
        };
        let q = (0, G.A)("game")((0, O.A)(F));
        function W() {
          return (0, I.I)({ gameId: null });
        }
        function V(e) {
          return e.enSlug || e.slug;
        }
      },
      39160: (e, t, a) => {
        "use strict";
        var r = Object.create
          ? function (e, t, a, r) {
              void 0 === r && (r = a);
              var n = Object.getOwnPropertyDescriptor(t, a);
              (!n ||
                ("get" in n ? !t.__esModule : n.writable || n.configurable)) &&
                (n = {
                  enumerable: !0,
                  get: function () {
                    return t[a];
                  },
                }),
                Object.defineProperty(e, r, n);
            }
          : function (e, t, a, r) {
              void 0 === r && (r = a), (e[r] = t[a]);
            };
        Object.defineProperty(t, "__esModule", { value: !0 });
        var n = a(41022);
        for (var i in n)
          "default" === i ||
            Object.prototype.hasOwnProperty.call(t, i) ||
            r(t, n, i);
      },
      41022: (e, t, a) => {
        "use strict";
        a.r(t), a.d(t, { InAppReview: () => r });
        let r = (0, a(34651).registerPlugin)("InAppReview", {
          web: () =>
            a
              .e(46296)
              .then(a.bind(a, 46296))
              .then((e) => new e.InAppReviewWeb()),
        });
      },
      41645: (e, t, a) => {
        "use strict";
        a.d(t, { JR: () => s, KG: () => c, Lz: () => l, mW: () => o });
        var r = a(79899),
          n = a(66424),
          i = a(18699);
        function o(e) {
          if (
            "html5" !== e.loaderType ||
            !e.loaderConfig ||
            !("url" in e.loaderConfig)
          )
            return null;
          let { url: t } = e.loaderConfig;
          return "string" == typeof t && t.length > 0 ? t : null;
        }
        function s(e, t) {
          let a = new URL(e);
          return (
            new URL(t).searchParams.forEach((e, t) => {
              "v" !== t && a.searchParams.append(t, e);
            }),
            a.toString()
          );
        }
        function l() {
          let e = {};
          return (
            (0, i.VS)()
              .filter((e) => e.startsWith("czyExpClient"))
              .forEach((t) => {
                if ((0, n.Hn)(t)) {
                  let { defaultValue: a, otherValues: r } = (0, n.bY)(t);
                  e[t] = [a, ...r];
                } else if ((0, r.H)(t)) {
                  let { defaultValue: a, otherValues: n } = (0, r.BK)(t);
                  e[t] = [a, ...n].map((e) => e.configCatValue);
                } else e[t] = null;
              }),
            e
          );
        }
        function c(e, t) {
          let a = new URL(e),
            r = new URL(t),
            n = a.origin + a.pathname === r.origin + r.pathname ? [] : ["path"];
          return (
            new Set([
              ...a.searchParams.keys(),
              ...r.searchParams.keys(),
            ]).forEach((e) => {
              a.searchParams.get(e) !== r.searchParams.get(e) && n.push(e);
            }),
            n.sort()
          );
        }
      },
      60092: (e, t, a) => {
        "use strict";
        a.d(t, { A: () => x });
        var r = a(6029),
          n = a(55729),
          i = a(89964),
          o = a(17802),
          s = a(79361),
          l = a(69933),
          c = a(18789),
          u = a(65233),
          d = a(56611),
          g = a(75155),
          m = a(74339),
          p = a(39160),
          h = a(14886),
          y = a(95815),
          f = a(49955),
          w = a(28478),
          v = a(71684);
        let P = (e) => {
          let t,
            a,
            r,
            i,
            o,
            s,
            l,
            c,
            d,
            P,
            b,
            x,
            _ = (0, g.c)(28),
            { gameId: E } = e,
            { services: R } = n.useContext(v.A),
            { user: D } = n.useContext(h.R),
            { syncPlayedTime: j } = n.useContext(u.oJ),
            [I] = n.useState(A);
          _[0] === Symbol.for("react.memo_cache_sentinel")
            ? ((t = Object.fromEntries(f.Ll.map(S))), (_[0] = t))
            : (t = _[0]);
          let C = n.useRef(t),
            L = n.useRef(!1),
            k = T,
            { gamesPlayedService: G, analyticsService: M } = R;
          _[1] !== j
            ? ((a = () => () => {
                j();
              }),
              (_[1] = j),
              (_[2] = a))
            : (a = _[2]),
            _[3] !== E || _[4] !== j
              ? ((r = [j, E]), (_[3] = E), (_[4] = j), (_[5] = r))
              : (r = _[5]),
            n.useEffect(a, r),
            _[6] !== M || _[7] !== E || _[8] !== I
              ? ((i = () => {
                  let e = Math.round((Date.now() - I) / 1e3);
                  f.Ll.forEach((t) => {
                    e >= 60 * t &&
                      !C.current[t] &&
                      (M.trackSessionPlaytimeRanges(E, t), (C.current[t] = !0));
                  });
                }),
                (_[6] = M),
                (_[7] = E),
                (_[8] = I),
                (_[9] = i))
              : (i = _[9]);
          let U = i;
          _[10] !== E || _[11] !== G || _[12] !== I || _[13] !== D
            ? ((o = () => {
                if (!D) return;
                let e = Math.round((Date.now() - I) / 1e3);
                G.handlePlayedTimeForUPSync(E, e);
              }),
              (_[10] = E),
              (_[11] = G),
              (_[12] = I),
              (_[13] = D),
              (_[14] = o))
            : (o = _[14]);
          let O = o;
          _[15] !== I
            ? ((s = () => {
                Math.round((Date.now() - I) / 1e3) >= 300 &&
                  !k() &&
                  (L.current = !0);
              }),
              (_[15] = I),
              (_[16] = s))
            : (s = _[16]);
          let H = s;
          return (
            _[17] === Symbol.for("react.memo_cache_sentinel")
              ? ((l = () => () => {
                  L.current &&
                    !k() &&
                    (0, y.so)() &&
                    (m.Capacitor.isNativePlatform() &&
                      p.InAppReview.requestReview(),
                    (function () {
                      w.A.LocalStorage.setItem(
                        "IN_APP_REVIEW_REQUESTED",
                        "true"
                      );
                    })());
                }),
                (c = []),
                (_[17] = l),
                (_[18] = c))
              : ((l = _[17]), (c = _[18])),
            n.useEffect(l, c),
            _[19] !== O || _[20] !== D
              ? ((P = () => {
                  D && O();
                }),
                (d = [D, O]),
                (_[19] = O),
                (_[20] = D),
                (_[21] = d),
                (_[22] = P))
              : ((d = _[21]), (P = _[22])),
            n.useEffect(P, d),
            _[23] !== U || _[24] !== O || _[25] !== H
              ? ((b = () => {
                  let e = null,
                    t = () => {
                      e = window.setInterval(() => {
                        O(), U();
                      }, f.sB);
                    },
                    a = () => {
                      document.hidden
                        ? e && (window.clearInterval(e), O(), U(), (e = null))
                        : t();
                    };
                  return (
                    t(),
                    document.addEventListener("visibilitychange", a),
                    function () {
                      document.removeEventListener("visibilitychange", a),
                        e && window.clearInterval(e);
                    }
                  );
                }),
                (x = [U, O, H]),
                (_[23] = U),
                (_[24] = O),
                (_[25] = H),
                (_[26] = b),
                (_[27] = x))
              : ((b = _[26]), (x = _[27])),
            n.useEffect(b, x),
            null
          );
        };
        function A() {
          return Date.now();
        }
        function S(e) {
          return [e, !1];
        }
        function T() {
          return "true" === w.A.LocalStorage.getItem("IN_APP_REVIEW_REQUESTED");
        }
        class b extends n.Component {
          constructor(e) {
            super(e),
              (this.addToRecentTimeout = null),
              (this.gameStartTime = 0),
              (this.pageUnload = () => {
                this.savePlayedGameTime();
              }),
              (this.processMessage = (e) => {
                if (e.data && e.data.type === i.x)
                  switch (e.data.event) {
                    case "afterPlayNow":
                    case "gameStartLoad":
                      break;
                    case "gameLoaded": {
                      let { gfVersion: t, loadedAt: a } = e.data;
                      this.handlePlayerStartedPlaying(t, a);
                      return;
                    }
                  }
              }),
              (this.delayedAddToRecent = () => {
                (0, o.Vc)("Game Add To Recent");
                let { game: e, userRecent: t } = this.props;
                t.addToRecent({
                  id: e.id,
                  slug: e.slug,
                  name: e.name,
                  cover: e.cover ?? "",
                  covers: e.covers ?? void 0,
                  videos: e.videos ?? {},
                  status: e.status,
                  iosFriendly: !!e.iosFriendly,
                  androidFriendly: !!e.androidFriendly,
                  gameThumbLabels: [],
                  activeArtworkExperiment: e.activeArtworkExperiment,
                  playedTime: 45,
                });
              }),
              (this.state = { trackTime: !1 });
          }
          render() {
            let { game: e } = this.props,
              { trackTime: t } = this.state;
            return t && (0, r.jsx)(P, { gameId: e.id });
          }
          componentDidMount() {
            let { services: e, game: t, isOfflineGaming: a } = this.props;
            a || e.crazyAnalyticsService.gamePageLoaded(t.id, t.buildId ?? ""),
              window.addEventListener("message", this.processMessage),
              window.addEventListener("pagehide", this.pageUnload);
          }
          componentWillUnmount() {
            this.savePlayedGameTime(),
              this.clearGameTracking(),
              window.removeEventListener("pagehide", this.pageUnload),
              window.removeEventListener("message", this.processMessage),
              this.props.services.crazyAnalyticsService.gamePageExited();
          }
          handlePlayerStartedPlaying(e, t) {
            (0, o.Vc)("Game Loaded"),
              this.setGameTracking(e, t),
              this.addToRecent();
          }
          addToRecent() {
            this.addToRecentTimeout = window.setTimeout(
              this.delayedAddToRecent,
              45e3
            );
          }
          setGameTracking(e, t) {
            let { services: a, game: r, isOfflineGaming: n } = this.props,
              { gamesPlayedService: i, crazyAnalyticsService: o } = a;
            i.startedPlayingGame(r), (this.gameStartTime = Date.now());
            let s = (0, d.SS)(r.slug)?.numPlays || 1;
            o.playingStarts({
              gfVersion: e,
              gameId: r.id,
              buildId: r.buildId,
              numPlays: s,
              offlineGaming: n,
              time: t,
            }),
              (0, d.A8)(r.slug),
              this.setState({ trackTime: !0 });
          }
          savePlayedGameTime() {
            let { game: e, services: t } = this.props;
            if (this.gameStartTime) {
              let a = Math.min(27e5, Date.now() - this.gameStartTime);
              t.gamesPlayedService.trackPlayedTime(e.slug, a),
                (0, s.Pq)({ id: e.id, categoryId: e.category?.id }, a);
            }
          }
          clearGameTracking() {
            this.addToRecentTimeout &&
              window.clearTimeout(this.addToRecentTimeout),
              this.setState({ trackTime: !1 });
          }
        }
        let x = (0, c.A)((0, u.QR)((0, l.A)(b)));
      },
      69933: (e, t, a) => {
        "use strict";
        a.d(t, { A: () => s });
        var r = a(6029),
          n = a(75155),
          i = a(55729),
          o = a(60362);
        let s = function (e) {
          return (t) => {
            let a,
              s = (0, n.c)(3),
              l = i.useContext(o.H);
            return (
              s[0] !== l || s[1] !== t
                ? ((a = (0, r.jsx)(e, { experiment: l, ...t })),
                  (s[0] = l),
                  (s[1] = t),
                  (s[2] = a))
                : (a = s[2]),
              a
            );
          };
        };
      },
      72224: (e, t, a) => {
        "use strict";
        a.d(t, { a: () => n, c: () => r });
        let r = [
            "newGames",
            "tags",
            "category",
            "tag",
            "game",
            "termsAndConditions",
            "informationForParents",
            "privacyPolicy",
            "recent",
            "search",
            "scholarship",
            "competitions",
          ],
          n = {
            newGames: { old: "", new: "" },
            tags: { old: "", new: "" },
            category: { old: "", new: "" },
            tag: { old: "", new: "" },
            game: { old: "", new: "" },
            termsAndConditions: { old: "", new: "" },
            privacyPolicy: { old: "", new: "" },
            recent: { old: "", new: "" },
            search: { old: "", new: "" },
            locale: { old: "", new: "" },
          };
      },
      80123: (e, t, a) => {
        "use strict";
        a.d(t, { d: () => r });
        let r = a(55729).createContext(null);
      },
      91831: (e, t, a) => {
        "use strict";
        a.d(t, { A: () => d });
        var r = a(6029),
          n = a(75155),
          i = a(55729),
          o = a(95669),
          s = a.n(o),
          l = a(61411),
          c = a(94618),
          u = a(74198);
        let d = (e) => {
          let t,
            a,
            o,
            d,
            g,
            m,
            p,
            h,
            y,
            f,
            w,
            v,
            P,
            A,
            S,
            T,
            b,
            x,
            _ = (0, n.c)(49),
            {
              canonical: E,
              title: R,
              description: D,
              imageUrl: j,
              imageWidth: I,
              imageHeight: C,
              imageQuality: L,
              type: k,
            } = e,
            G = void 0 === j ? "crazygames/share.png" : j,
            M = void 0 === I ? 1200 : I,
            U = void 0 === C ? 630 : C,
            { locale: O } = i.useContext(u.A);
          _[0] !== U || _[1] !== L || _[2] !== G || _[3] !== M
            ? ((t = (0, c.Ay)(G, {
                width: M,
                height: U,
                fit: "crop",
                quality: L,
              })),
              (_[0] = U),
              (_[1] = L),
              (_[2] = G),
              (_[3] = M),
              (_[4] = t))
            : (t = _[4]);
          let H = t;
          return (
            _[5] !== E
              ? ((a = (0, r.jsx)("meta", { property: "og:url", content: E })),
                (_[5] = E),
                (_[6] = a))
              : (a = _[6]),
            _[7] !== R
              ? ((o = (0, r.jsx)("meta", { property: "og:title", content: R })),
                (_[7] = R),
                (_[8] = o))
              : (o = _[8]),
            _[9] !== D
              ? ((d = (0, r.jsx)("meta", {
                  property: "og:description",
                  content: D,
                })),
                (_[9] = D),
                (_[10] = d))
              : (d = _[10]),
            _[11] !== O
              ? ((g = (0, l.qz)(O)), (_[11] = O), (_[12] = g))
              : (g = _[12]),
            _[13] !== g
              ? ((m = (0, r.jsx)("meta", {
                  property: "og:locale",
                  content: g,
                })),
                (_[13] = g),
                (_[14] = m))
              : (m = _[14]),
            _[15] !== H
              ? ((p = (0, r.jsx)("meta", { property: "og:image", content: H })),
                (_[15] = H),
                (_[16] = p))
              : (p = _[16]),
            _[17] !== M
              ? ((h = M.toString()), (_[17] = M), (_[18] = h))
              : (h = _[18]),
            _[19] !== h
              ? ((y = (0, r.jsx)("meta", {
                  property: "og:image:width",
                  content: h,
                })),
                (_[19] = h),
                (_[20] = y))
              : (y = _[20]),
            _[21] !== U
              ? ((f = U.toString()), (_[21] = U), (_[22] = f))
              : (f = _[22]),
            _[23] !== f
              ? ((w = (0, r.jsx)("meta", {
                  property: "og:image:height",
                  content: f,
                })),
                (_[23] = f),
                (_[24] = w))
              : (w = _[24]),
            _[25] !== k
              ? ((v =
                  k && (0, r.jsx)("meta", { property: "og:type", content: k })),
                (_[25] = k),
                (_[26] = v))
              : (v = _[26]),
            _[27] === Symbol.for("react.memo_cache_sentinel")
              ? ((P = (0, r.jsx)("meta", {
                  property: "twitter:card",
                  content: "summary_large_image",
                })),
                (_[27] = P))
              : (P = _[27]),
            _[28] !== E
              ? ((A = (0, r.jsx)("meta", {
                  property: "twitter:url",
                  content: E,
                })),
                (_[28] = E),
                (_[29] = A))
              : (A = _[29]),
            _[30] !== R
              ? ((S = (0, r.jsx)("meta", {
                  property: "twitter:title",
                  content: R,
                })),
                (_[30] = R),
                (_[31] = S))
              : (S = _[31]),
            _[32] !== D
              ? ((T = (0, r.jsx)("meta", {
                  property: "twitter:description",
                  content: D,
                })),
                (_[32] = D),
                (_[33] = T))
              : (T = _[33]),
            _[34] !== H
              ? ((b = (0, r.jsx)("meta", {
                  property: "twitter:image",
                  content: H,
                })),
                (_[34] = H),
                (_[35] = b))
              : (b = _[35]),
            _[36] !== p ||
            _[37] !== y ||
            _[38] !== w ||
            _[39] !== v ||
            _[40] !== A ||
            _[41] !== S ||
            _[42] !== T ||
            _[43] !== b ||
            _[44] !== a ||
            _[45] !== o ||
            _[46] !== d ||
            _[47] !== m
              ? ((x = (0, r.jsxs)(s(), {
                  children: [a, o, d, m, p, y, w, v, P, A, S, T, b],
                })),
                (_[36] = p),
                (_[37] = y),
                (_[38] = w),
                (_[39] = v),
                (_[40] = A),
                (_[41] = S),
                (_[42] = T),
                (_[43] = b),
                (_[44] = a),
                (_[45] = o),
                (_[46] = d),
                (_[47] = m),
                (_[48] = x))
              : (x = _[48]),
            x
          );
        };
      },
      99161: (e, t, a) => {
        (window.__NEXT_P = window.__NEXT_P || []).push([
          "/game/[game]",
          function () {
            return a(26356);
          },
        ]);
      },
    },
    (e) => {
      e.O(0, [6847, 5869, 89247, 88823, 99203, 46593, 90636, 38792], () =>
        e((e.s = 99161))
      ),
        (_N_E = e.O());
    },
  ]);
