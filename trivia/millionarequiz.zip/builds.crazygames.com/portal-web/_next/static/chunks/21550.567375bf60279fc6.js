!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var n = 1; n < arguments.length; n++) {
          var t = arguments[n];
          if (null != t) for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "d64e5d0d-d09f-412f-bb08-3c3e67f5e7ed"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-d64e5d0d-d09f-412f-bb08-3c3e67f5e7ed"));
  } catch (e) {}
})();
("use strict");
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [21550],
  {
    21550: (e, n, t) => {
      t.r(n), t.d(n, { Network: () => i, NetworkWeb: () => r });
      var o = t(34651);
      function a() {
        let e =
            window.navigator.connection ||
            window.navigator.mozConnection ||
            window.navigator.webkitConnection,
          n = "unknown",
          t = e ? e.type || e.effectiveType : null;
        if (t && "string" == typeof t)
          switch (t) {
            case "bluetooth":
            case "cellular":
            case "slow-2g":
            case "2g":
            case "3g":
              n = "cellular";
              break;
            case "none":
              n = "none";
              break;
            case "ethernet":
            case "wifi":
            case "wimax":
            case "4g":
              n = "wifi";
              break;
            case "other":
            case "unknown":
              n = "unknown";
          }
        return n;
      }
      class r extends o.WebPlugin {
        constructor() {
          super(),
            (this.handleOnline = () => {
              let e = a();
              this.notifyListeners("networkStatusChange", {
                connected: !0,
                connectionType: e,
              });
            }),
            (this.handleOffline = () => {
              this.notifyListeners("networkStatusChange", {
                connected: !1,
                connectionType: "none",
              });
            }),
            "u" > typeof window &&
              (window.addEventListener("online", this.handleOnline),
              window.addEventListener("offline", this.handleOffline));
        }
        async getStatus() {
          if (!window.navigator)
            throw this.unavailable(
              "Browser does not support the Network Information API"
            );
          let e = window.navigator.onLine,
            n = a();
          return { connected: e, connectionType: e ? n : "none" };
        }
      }
      let i = new r();
    },
  },
]);
