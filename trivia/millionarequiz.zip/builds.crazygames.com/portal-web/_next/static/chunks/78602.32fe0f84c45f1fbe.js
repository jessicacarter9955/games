!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var n = 1; n < arguments.length; n++) {
          var t = arguments[n];
          if (null != t) for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "d7c5a870-4f9c-468c-b96a-3a5209436fa1"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-d7c5a870-4f9c-468c-b96a-3a5209436fa1"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [11591, 78602],
    {
      10862: (e, n, t) => {
        "use strict";
        t.d(n, { Ff: () => s, oq: () => l, po: () => a });
        let o = null,
          r = new Set();
        function l(e) {
          return (null === o || o === e) && ((o = e), !0);
        }
        function a(e) {
          o === e && ((o = null), r.forEach((e) => e()));
        }
        function s(e) {
          return (
            r.add(e),
            () => {
              r.delete(e);
            }
          );
        }
      },
      11591: (e, n, t) => {
        "use strict";
        t.d(n, { A: () => u });
        var o = t(6029),
          r = t(75155);
        t(55729);
        var l = t(50212),
          a = t(56760),
          s = t(69386),
          i = t(85893),
          c = t(82026),
          d = t.n(c);
        let u = (e) => {
          let n,
            t,
            c,
            u,
            p = (0, r.c)(12),
            { open: f, blurred: _, onClose: m, children: I, className: h } = e;
          if (((0, s.K)(f), !f)) return null;
          let M = void 0 !== _ && _ && d().blurred;
          if (
            (p[0] !== h || p[1] !== M
              ? ((n = (0, l.A)(d().modal, M, h)),
                (p[0] = h),
                (p[1] = M),
                (p[2] = n))
              : (n = p[2]),
            p[3] !== m || p[4] !== f
              ? ((t = (0, o.jsx)(i.k, { open: f, onClick: m })),
                (p[3] = m),
                (p[4] = f),
                (p[5] = t))
              : (t = p[5]),
            p[6] !== I
              ? ((c = (0, o.jsx)("div", {
                  className: d().modalContent,
                  children: I,
                })),
                (p[6] = I),
                (p[7] = c))
              : (c = p[7]),
            p[8] !== n || p[9] !== t || p[10] !== c)
          ) {
            let e = (0, o.jsxs)("div", { className: n, children: [t, c] });
            (u = (0, a.createPortal)(e, document.body)),
              (p[8] = n),
              (p[9] = t),
              (p[10] = c),
              (p[11] = u);
          } else u = p[11];
          return u;
        };
      },
      77506: (e) => {
        e.exports = {
          optInModalContainer: "SuprSendOptInModal_optInModalContainer__FSksa",
          isTransparent: "SuprSendOptInModal_isTransparent__rqopY",
          optInModalIcon: "SuprSendOptInModal_optInModalIcon__AsCi1",
          optInModalTitle: "SuprSendOptInModal_optInModalTitle__jSPkF",
          optInModalDescription:
            "SuprSendOptInModal_optInModalDescription__V5_Xv",
          optInModalActions: "SuprSendOptInModal_optInModalActions__jsK_l",
          optInModalError: "SuprSendOptInModal_optInModalError__9usE_",
        };
      },
      78602: (e, n, t) => {
        "use strict";
        t.r(n), t.d(n, { default: () => w });
        var o = t(6029),
          r = t(75155),
          l = t(55729),
          a = t(79942),
          s = t(37434),
          i = t(94618),
          c = t(62273),
          d = t(11591),
          u = t(71855),
          p = t(14886),
          f = t(4230),
          _ = t(45364),
          m = t(71684),
          I = t(44884),
          h = t(10862);
        let M = t(28478).A.LocalStorage,
          y = "czy_guest_push_opt_in_shown";
        function v() {
          return "Notification" in window ? window.Notification : void 0;
        }
        async function x() {
          let e = v();
          if (!e) return "default";
          try {
            return await e.requestPermission();
          } catch (e) {
            return (
              console.warn("requestNotificationPermission failed", e), "default"
            );
          }
        }
        let S = "push-notification-OptIn-guest";
        function g() {
          return (0, h.po)(S);
        }
        var A = t(77506),
          b = t.n(A);
        let w = () => {
          let e,
            n,
            t,
            A,
            w,
            j,
            k,
            C,
            E,
            F,
            N,
            O,
            D,
            P = (0, r.c)(26),
            {
              open: T,
              waitingForBrowser: q,
              onAllow: L,
              onDismiss: z,
            } = (function () {
              let e,
                n,
                t,
                o,
                a,
                s,
                i,
                c,
                d = (0, r.c)(21),
                { user: A, loadingUser: b } = l.useContext(p.R),
                { crazyAnalyticsService: w } = l.useContext(m.A).services,
                j = l.useContext(f.A),
                k =
                  "enabled" ===
                  (0, u.U)("czyExpClientGuestPushOptIn_CZY_22362");
              d[0] !== j || d[1] !== k || d[2] !== b || d[3] !== A
                ? ((e = !b && !A && k && (0, I.$K)(j)),
                  (d[0] = j),
                  (d[1] = k),
                  (d[2] = b),
                  (d[3] = A),
                  (d[4] = e))
                : (e = d[4]);
              let C = e,
                [E, F] = l.useState(!1),
                [N, O] = l.useState(!1),
                D = l.useRef(!1);
              !E || C || N || F(!1),
                d[5] !== w || d[6] !== C
                  ? ((n = () => {
                      if (!C) return;
                      let e = !1,
                        n = !1,
                        t = () => {
                          e ||
                            !n ||
                            D.current ||
                            v()?.permission !== "default" ||
                            null !== M.getItem(y) ||
                            !w.hasPreviousSession() ||
                            (!(_.A.isFullscreen() || _.A.isFakeFullscreen()) &&
                              (0, h.oq)(S) &&
                              ((D.current = !0),
                              M.setItem(y, String(Date.now())),
                              F(!0),
                              w.notificationActionEvent(S, "shown")));
                        };
                      (0, I.NY)().then((e) => {
                        (n = e), t();
                      }),
                        _.A.addFullscreenListener(t),
                        _.A.addFakeFullscreenListener(t);
                      let o = (0, h.Ff)(t);
                      return () => {
                        (e = !0),
                          _.A.removeFullscreenListener(t),
                          _.A.removeFakeFullscreenListener(t),
                          o();
                      };
                    }),
                    (t = [C, w]),
                    (d[5] = w),
                    (d[6] = C),
                    (d[7] = n),
                    (d[8] = t))
                  : ((n = d[7]), (t = d[8])),
                l.useEffect(n, t),
                d[9] !== E
                  ? ((o = () => {
                      if (E) return g;
                    }),
                    (a = [E]),
                    (d[9] = E),
                    (d[10] = o),
                    (d[11] = a))
                  : ((o = d[10]), (a = d[11])),
                l.useEffect(o, a),
                d[12] !== w
                  ? ((s = async () => {
                      w.notificationActionEvent(S, "clicked"),
                        O(!0),
                        "granted" === (await x()) &&
                          w.notificationActionEvent(S, "accepted"),
                        O(!1),
                        F(!1);
                    }),
                    (d[12] = w),
                    (d[13] = s))
                  : (s = d[13]);
              let P = s;
              d[14] !== w
                ? ((i = () => {
                    w.notificationActionEvent(S, "ignored"), F(!1);
                  }),
                  (d[14] = w),
                  (d[15] = i))
                : (i = d[15]);
              let T = i;
              return (
                d[16] !== P || d[17] !== T || d[18] !== E || d[19] !== N
                  ? ((c = {
                      open: E,
                      waitingForBrowser: N,
                      onAllow: P,
                      onDismiss: T,
                    }),
                    (d[16] = P),
                    (d[17] = T),
                    (d[18] = E),
                    (d[19] = N),
                    (d[20] = c))
                  : (c = d[20]),
                c
              );
            })();
          if (!T) return null;
          let K = !q;
          return (
            P[0] === Symbol.for("react.memo_cache_sentinel")
              ? ((e = (0, o.jsx)("figure", {
                  className: b().optInModalIcon,
                  children: (0, o.jsx)("img", {
                    src: (0, i.Ay)("crazygames/bell-icon.png", {}, !1),
                    alt: "Bell icon",
                  }),
                })),
                (P[0] = e))
              : (e = P[0]),
            P[1] === Symbol.for("react.memo_cache_sentinel")
              ? ((n = (0, o.jsx)("h2", {
                  className: b().optInModalTitle,
                  children: (0, o.jsx)(a.x6, {
                    id: "common.suprsend.optInModal.title",
                  }),
                })),
                (P[1] = n))
              : (n = P[1]),
            P[2] === Symbol.for("react.memo_cache_sentinel")
              ? ((t = (0, o.jsx)("p", {
                  className: b().optInModalDescription,
                  children: (0, o.jsx)(a.x6, {
                    id: "common.suprsend.optInModal.description",
                  }),
                })),
                (P[2] = t))
              : (t = P[2]),
            P[3] === Symbol.for("react.memo_cache_sentinel")
              ? ((A = (0, o.jsx)(a.x6, {
                  id: "common.suprsend.optInModal.dismiss",
                })),
                (P[3] = A))
              : (A = P[3]),
            P[4] !== z
              ? ((w = (0, o.jsx)(s.A, {
                  variant: "outlined",
                  color: "white",
                  height: 50,
                  onClick: z,
                  children: A,
                })),
                (P[4] = z),
                (P[5] = w))
              : (w = P[5]),
            P[6] !== L
              ? ((j = () => void L()), (P[6] = L), (P[7] = j))
              : (j = P[7]),
            P[8] === Symbol.for("react.memo_cache_sentinel")
              ? ((k = (0, o.jsx)(a.x6, {
                  id: "common.suprsend.optInModal.allow",
                })),
                (P[8] = k))
              : (k = P[8]),
            P[9] !== j
              ? ((C = (0, o.jsx)(s.A, {
                  variant: "contained",
                  color: "purple",
                  height: 50,
                  onClick: j,
                  children: k,
                })),
                (P[9] = j),
                (P[10] = C))
              : (C = P[10]),
            P[11] !== w || P[12] !== C
              ? ((E = (0, o.jsxs)("div", {
                  className: b().optInModalActions,
                  children: [w, C],
                })),
                (P[11] = w),
                (P[12] = C),
                (P[13] = E))
              : (E = P[13]),
            P[14] !== e || P[15] !== E
              ? ((F = (0, o.jsxs)("div", {
                  className: b().optInModalContainer,
                  children: [e, n, t, E],
                })),
                (P[14] = e),
                (P[15] = E),
                (P[16] = F))
              : (F = P[16]),
            P[17] !== z || P[18] !== K || P[19] !== F
              ? ((N = (0, o.jsx)(d.A, { open: K, onClose: z, children: F })),
                (P[17] = z),
                (P[18] = K),
                (P[19] = F),
                (P[20] = N))
              : (N = P[20]),
            P[21] !== q
              ? ((O = q && (0, o.jsx)(c.A, {})), (P[21] = q), (P[22] = O))
              : (O = P[22]),
            P[23] !== N || P[24] !== O
              ? ((D = (0, o.jsxs)(o.Fragment, { children: [N, O] })),
                (P[23] = N),
                (P[24] = O),
                (P[25] = D))
              : (D = P[25]),
            D
          );
        };
      },
    },
  ]);
