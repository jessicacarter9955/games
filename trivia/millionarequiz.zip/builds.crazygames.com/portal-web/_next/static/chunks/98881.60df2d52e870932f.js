!(function () {
  try {
    var t =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (t._sentryModuleMetadata = t._sentryModuleMetadata || {}),
      (t._sentryModuleMetadata[new t.Error().stack] = (function (t) {
        for (var e = 1; e < arguments.length; e++) {
          var n = arguments[e];
          if (null != n) for (var o in n) n.hasOwnProperty(o) && (t[o] = n[o]);
        }
        return t;
      })({}, t._sentryModuleMetadata[new t.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var e = new t.Error().stack;
    e &&
      ((t._sentryDebugIds = t._sentryDebugIds || {}),
      (t._sentryDebugIds[e] = "cd6d4eef-4e34-4701-a6c3-f019506ca7da"),
      (t._sentryDebugIdIdentifier =
        "sentry-dbid-cd6d4eef-4e34-4701-a6c3-f019506ca7da"));
  } catch (t) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [98881],
    {
      17939: (t, e, n) => {
        "use strict";
        n.d(e, { OA: () => l, oE: () => r }), n(75155), n(55729);
        var o = n(78192),
          i = n(98417);
        n(93389);
        var a = n(61682);
        function c(t) {
          let e = new URL(t);
          e.searchParams.delete(o.w2), e.searchParams.delete(o.eG);
          let n = e.pathname.split("/").filter(Boolean)[1];
          return (
            (0, a.jz)().forEach((t) => e.searchParams.delete(t)),
            e.searchParams.sort(),
            n + "?" + e.searchParams.toString()
          );
        }
        function r(t, e) {
          if (!(0, i.O)(t.playingGame?.id) || t.playingGame?.id !== e?.gameId)
            return !1;
          if (
            (0, i.O)(t.multiplayerRoom?.roomId) &&
            (0, i.O)(e?.multiplayerRoom?.roomId)
          )
            return t.multiplayerRoom?.roomId === e?.multiplayerRoom?.roomId;
          if ((0, i.O)(t.gameInviteLink) && (0, i.O)(e?.joinUrl)) {
            var n, o;
            return (n = t.gameInviteLink), (o = e.joinUrl), c(n) === c(o);
          }
          return !1;
        }
        function l(t, e) {
          let n = { inLobby: [], notInLobby: [] };
          return (
            t.forEach((t) => {
              r(e, t.gameStatus) ? n.inLobby.push(t) : n.notInLobby.push(t);
            }),
            n
          );
        }
      },
      19115: (t, e) => {
        "use strict";
        (e.GK = e.Ye = e.qM = e.Wy = e._l = void 0),
          (e._l = "GAME_INVITE"),
          (e.Wy = "GAME_LEADERBOARD_INVITE"),
          (e.qM = "FRIEND_REQUEST"),
          (e.Ye = "FRIEND_REQUEST_ACCEPTED"),
          (e.GK = "GAME_LEADERBOARD_BEATEN");
      },
      20166: (t) => {
        t.exports = {
          czyButton: "snackbarLoader_czyButton__3ohav",
          "czyButton--contained--purple":
            "snackbarLoader_czyButton--contained--purple__rOctu",
          "czyButton--contained--white":
            "snackbarLoader_czyButton--contained--white__V2dQc",
          "czyButton--contained--grey":
            "snackbarLoader_czyButton--contained--grey__X2gGI",
          "czyButton--contained--warning":
            "snackbarLoader_czyButton--contained--warning__9xWkU",
          "czyButton--contained--alert":
            "snackbarLoader_czyButton--contained--alert__4X3dN",
          "czyButton--contained--success":
            "snackbarLoader_czyButton--contained--success__P5JPy",
          "czyButton--contained--black":
            "snackbarLoader_czyButton--contained--black__DrToV",
          "czyButton--contained--green-gradient":
            "snackbarLoader_czyButton--contained--green-gradient__wTFe5",
          "czyButton--contained--animated-green-gradient":
            "snackbarLoader_czyButton--contained--animated-green-gradient__zZ7sz",
          "scroll-gradient": "snackbarLoader_scroll-gradient__D2ddh",
          "czyButton--outlined--purple":
            "snackbarLoader_czyButton--outlined--purple___hXhk",
          "czyButton--link--purple":
            "snackbarLoader_czyButton--link--purple__M7uzC",
          "czyButton--outlined--white":
            "snackbarLoader_czyButton--outlined--white__1ouEn",
          "czyButton--link--white":
            "snackbarLoader_czyButton--link--white__ISUNy",
          "czyButton--outlined--grey":
            "snackbarLoader_czyButton--outlined--grey__FMzoi",
          "czyButton--link--grey":
            "snackbarLoader_czyButton--link--grey__fXINs",
          "czyButton--outlined--warning":
            "snackbarLoader_czyButton--outlined--warning__4IrgT",
          "czyButton--link--warning":
            "snackbarLoader_czyButton--link--warning__UICXb",
          "czyButton--outlined--alert":
            "snackbarLoader_czyButton--outlined--alert__Dqogk",
          "czyButton--link--alert":
            "snackbarLoader_czyButton--link--alert__RVKt3",
          "czyButton--outlined--success":
            "snackbarLoader_czyButton--outlined--success__yFvat",
          "czyButton--link--success":
            "snackbarLoader_czyButton--link--success__JQ5vj",
          "czyButton--outlined": "snackbarLoader_czyButton--outlined__KIF5w",
          "czyButton--disabled": "snackbarLoader_czyButton--disabled__f_Iud",
          "czyButton--height50": "snackbarLoader_czyButton--height50__9RyEq",
          "czyButton--height34": "snackbarLoader_czyButton--height34__fJCsb",
          "czyButton--height28": "snackbarLoader_czyButton--height28__HPQ6_",
          "czyButton--fullWidth": "snackbarLoader_czyButton--fullWidth__RGQ7h",
          "czyButton--headerIcon":
            "snackbarLoader_czyButton--headerIcon__2hRvH",
          "czyButton--headerIcon--desktop":
            "snackbarLoader_czyButton--headerIcon--desktop___t6iV",
          "czyButton--headerIcon--mobile":
            "snackbarLoader_czyButton--headerIcon--mobile__dhs1u",
          "czyButton--headerIcon--withLabel":
            "snackbarLoader_czyButton--headerIcon--withLabel__9TsFf",
          containerRoot: "snackbarLoader_containerRoot__ZQekq",
          isPlaying: "snackbarLoader_isPlaying__X72s7",
          containerAnchorOriginTopLeft:
            "snackbarLoader_containerAnchorOriginTopLeft__sy30v",
        };
      },
      37706: (t) => {
        t.exports = {
          czyButton: "CoolNotificationDesktop_czyButton__tNsXL",
          "czyButton--contained--purple":
            "CoolNotificationDesktop_czyButton--contained--purple___j1Z8",
          "czyButton--contained--white":
            "CoolNotificationDesktop_czyButton--contained--white__ItGfF",
          "czyButton--contained--grey":
            "CoolNotificationDesktop_czyButton--contained--grey__iYZha",
          "czyButton--contained--warning":
            "CoolNotificationDesktop_czyButton--contained--warning__CT8gw",
          "czyButton--contained--alert":
            "CoolNotificationDesktop_czyButton--contained--alert__ehzQM",
          "czyButton--contained--success":
            "CoolNotificationDesktop_czyButton--contained--success___RQ8T",
          "czyButton--contained--black":
            "CoolNotificationDesktop_czyButton--contained--black__V03Dk",
          "czyButton--contained--green-gradient":
            "CoolNotificationDesktop_czyButton--contained--green-gradient__FCWYs",
          "czyButton--contained--animated-green-gradient":
            "CoolNotificationDesktop_czyButton--contained--animated-green-gradient__9TQFG",
          "scroll-gradient": "CoolNotificationDesktop_scroll-gradient__UbS9D",
          "czyButton--outlined--purple":
            "CoolNotificationDesktop_czyButton--outlined--purple__Y9289",
          "czyButton--link--purple":
            "CoolNotificationDesktop_czyButton--link--purple__gJqN8",
          "czyButton--outlined--white":
            "CoolNotificationDesktop_czyButton--outlined--white__BNTPP",
          "czyButton--link--white":
            "CoolNotificationDesktop_czyButton--link--white__Lkbk0",
          "czyButton--outlined--grey":
            "CoolNotificationDesktop_czyButton--outlined--grey__vpM5e",
          "czyButton--link--grey":
            "CoolNotificationDesktop_czyButton--link--grey__fa_dV",
          "czyButton--outlined--warning":
            "CoolNotificationDesktop_czyButton--outlined--warning__wPgAK",
          "czyButton--link--warning":
            "CoolNotificationDesktop_czyButton--link--warning__5AuM5",
          "czyButton--outlined--alert":
            "CoolNotificationDesktop_czyButton--outlined--alert___Tvfz",
          "czyButton--link--alert":
            "CoolNotificationDesktop_czyButton--link--alert__4Qww1",
          "czyButton--outlined--success":
            "CoolNotificationDesktop_czyButton--outlined--success__43hjI",
          "czyButton--link--success":
            "CoolNotificationDesktop_czyButton--link--success__Ew37V",
          "czyButton--outlined":
            "CoolNotificationDesktop_czyButton--outlined__Nk3Wl",
          "czyButton--disabled":
            "CoolNotificationDesktop_czyButton--disabled__cv8W7",
          "czyButton--height50":
            "CoolNotificationDesktop_czyButton--height50__7pZuB",
          "czyButton--height34":
            "CoolNotificationDesktop_czyButton--height34__mzIJB",
          "czyButton--height28":
            "CoolNotificationDesktop_czyButton--height28__7xjuB",
          "czyButton--fullWidth":
            "CoolNotificationDesktop_czyButton--fullWidth__Adv0m",
          "czyButton--headerIcon":
            "CoolNotificationDesktop_czyButton--headerIcon__M9YXC",
          "czyButton--headerIcon--desktop":
            "CoolNotificationDesktop_czyButton--headerIcon--desktop__UTZDT",
          "czyButton--headerIcon--mobile":
            "CoolNotificationDesktop_czyButton--headerIcon--mobile__0GhgU",
          "czyButton--headerIcon--withLabel":
            "CoolNotificationDesktop_czyButton--headerIcon--withLabel__rh0_v",
          snackbarContent: "CoolNotificationDesktop_snackbarContent___VuC5",
          closeContainer: "CoolNotificationDesktop_closeContainer__XHgLy",
          avatarContainer: "CoolNotificationDesktop_avatarContainer__7iIHK",
          avatar: "CoolNotificationDesktop_avatar__GqA5R",
          circle: "CoolNotificationDesktop_circle__AmXy3",
          square: "CoolNotificationDesktop_square__2465e",
          textContainer: "CoolNotificationDesktop_textContainer__L_ybm",
          title: "CoolNotificationDesktop_title___g2t1",
          message: "CoolNotificationDesktop_message__fSXzH",
          buttonContainer: "CoolNotificationDesktop_buttonContainer__FVB1_",
          countdownBar: "CoolNotificationDesktop_countdownBar__zAGTm",
          "countdown-progress":
            "CoolNotificationDesktop_countdown-progress__ej_JT",
          paused: "CoolNotificationDesktop_paused__CNPOm",
        };
      },
      55739: (t, e, n) => {
        "use strict";
        n.d(e, { A: () => r });
        var o = n(75155),
          i = n(78192),
          a = n(18262);
        let c = (t) => {
            (0, a.y)()?.contentWindow?.postMessage(
              { type: "callJoinRoomListener", params: t },
              "*"
            );
          },
          r = () => {
            let t,
              e = (0, o.c)(1);
            return (
              e[0] === Symbol.for("react.memo_cache_sentinel")
                ? ((t = {
                    sendJoinRoomEvent: l,
                    sendJoinRoomEventWithParams: s,
                  }),
                  (e[0] = t))
                : (t = e[0]),
              t
            );
          };
        function l(t) {
          c(
            (function (t) {
              try {
                let e = new URL(t),
                  n = {};
                return (
                  e.searchParams.forEach((t, e) => {
                    n[e] = t;
                  }),
                  delete n.czy_invite,
                  delete n.utm_source,
                  (0, i.kJ)(n)
                );
              } catch (t) {
                return (
                  console.error(
                    "Failed to parse invite URL, returning {} params",
                    t
                  ),
                  {}
                );
              }
            })(t)
          );
        }
        function s(t) {
          c(t);
        }
      },
      60352: (t, e, n) => {
        "use strict";
        n.d(e, { A: () => f });
        var o = n(75155),
          i = n(19115),
          a = n(6029),
          c = n(79942),
          r = n(55729),
          l = n(93389),
          s = n(61827),
          u = n(71237),
          d = n(71684),
          _ = n(78576);
        let y = () => {
          let t,
            e,
            n,
            i = (0, o.c)(9),
            { routeHelper: a } = (0, r.useContext)(l.A),
            { crazyAnalyticsService: c } = (0, r.useContext)(d.A).services,
            { joinGame: s } = (0, _.A)();
          i[0] !== c || i[1] !== s || i[2] !== a
            ? ((t = (t, e, n, o, i, r) => {
                let l = a.localizedJoinUrl(e, n).href || n;
                c.gameInteractionEvent({
                  method: "invite",
                  origin:
                    "snackbar" === i
                      ? "popupNotification"
                      : "notificationDrawer",
                  action: void 0 === r ? "accept" : r,
                  target: o,
                  targetStatus: null,
                  targetGameId: t,
                }),
                  s({ joinUrl: l, gameSlug: e });
              }),
              (i[0] = c),
              (i[1] = s),
              (i[2] = a),
              (i[3] = t))
            : (t = i[3]);
          let u = t;
          i[4] !== c
            ? ((e = (t, e, n) => {
                c.gameInteractionEvent({
                  method: "invite",
                  origin:
                    "snackbar" === n
                      ? "popupNotification"
                      : "notificationDrawer",
                  action: "decline",
                  target: e,
                  targetStatus: null,
                  targetGameId: t,
                });
              }),
              (i[4] = c),
              (i[5] = e))
            : (e = i[5]);
          let y = e;
          return (
            i[6] !== u || i[7] !== y
              ? ((n = { onSuprsendAcceptClick: u, onSuprsendDeclineClick: y }),
                (i[6] = u),
                (i[7] = y),
                (i[8] = n))
              : (n = i[8]),
            n
          );
        };
        function f() {
          let t,
            e,
            n,
            _,
            f,
            m,
            g = (0, o.c)(16),
            p = (function () {
              let { crazyAnalyticsService: t } = r.useContext(d.A).services,
                [e] = u.zn(),
                [n] = u.SS();
              return r.useMemo(
                () => ({
                  accept: async (n, o) => {
                    (await e(n)) &&
                      t.friendRequestEvent({
                        action: "accept",
                        target: n,
                        origin:
                          "snackbar" === o
                            ? "friendRequestPopup"
                            : "notificationDrawer",
                      });
                  },
                  decline: async (e, o) => {
                    (await n(e)) &&
                      t.friendRequestEvent({
                        action: "decline",
                        target: e,
                        origin:
                          "snackbar" === o
                            ? "friendRequestPopup"
                            : "notificationDrawer",
                      });
                  },
                }),
                [e, n, t]
              );
            })(),
            h = (function () {
              let t,
                e,
                n,
                i = (0, o.c)(7),
                { onSuprsendAcceptClick: a, onSuprsendDeclineClick: c } = y();
              return (
                i[0] !== a
                  ? ((t = (t) => {
                      let {
                        gameId: e,
                        slug: n,
                        joinUrl: o,
                        fromUserId: i,
                        origin: c,
                      } = t;
                      return a(e, n, o, i, c);
                    }),
                    (i[0] = a),
                    (i[1] = t))
                  : (t = i[1]),
                i[2] !== c
                  ? ((e = (t) => {
                      let { gameId: e, fromUserId: n, origin: o } = t;
                      return c(e, n, o);
                    }),
                    (i[2] = c),
                    (i[3] = e))
                  : (e = i[3]),
                i[4] !== t || i[5] !== e
                  ? ((n = { accept: t, decline: e }),
                    (i[4] = t),
                    (i[5] = e),
                    (i[6] = n))
                  : (n = i[6]),
                n
              );
            })(),
            z = (function () {
              let t,
                e,
                n,
                i = (0, o.c)(8),
                { onSuprsendAcceptClick: a, onSuprsendDeclineClick: c } = y(),
                { routeHelper: s } = r.useContext(l.A);
              return (
                i[0] !== a || i[1] !== s
                  ? ((t = (t, e) => {
                      let {
                        gameId: n,
                        slug: o,
                        joinUrl: i,
                        fromUserId: c,
                        origin: r,
                      } = t;
                      return a(n, o, i ?? s.gamePageLink(o).href, c, r, e);
                    }),
                    (i[0] = a),
                    (i[1] = s),
                    (i[2] = t))
                  : (t = i[2]),
                i[3] !== c
                  ? ((e = (t) => {
                      let { gameId: e, fromUserId: n, origin: o } = t;
                      return c(e, n, o);
                    }),
                    (i[3] = c),
                    (i[4] = e))
                  : (e = i[4]),
                i[5] !== t || i[6] !== e
                  ? ((n = { accept: t, decline: e }),
                    (i[5] = t),
                    (i[6] = e),
                    (i[7] = n))
                  : (n = i[7]),
                n
              );
            })(),
            B = (function () {
              let { routeHelper: t } = r.useContext(l.A),
                { crazyRouterChange: e } = r.useContext(s.Gl),
                n = r.useMemo(() => t.tagPageDirectLink("multiplayer"), [t]);
              return r.useMemo(
                () => ({
                  accept: () => {
                    window.open(n.href, "_blank");
                  },
                }),
                [n, e]
              );
            })();
          return (
            g[0] !== p
              ? ((t = (t) =>
                  (function (t, e) {
                    let {
                      data: n,
                      title: o,
                      message: i,
                      avatar: r,
                      origin: l,
                    } = e;
                    return {
                      title: o ?? "",
                      message: i,
                      thumbnail: { url: r, altText: "Avatar", shape: "circle" },
                      snackbarVariant: "cool",
                      notificationPreferenceType: "interactiveNotifications",
                      actions: [
                        {
                          id: "accept",
                          dataTestId: "toast-friend-request-accept",
                          label: (0, a.jsx)(c.x6, {
                            id: "friends.upDrawer.notifications.accept",
                          }),
                          run: () => t.accept(n.from.senderId, l),
                        },
                        {
                          id: "decline",
                          dataTestId: "toast-friend-request-decline",
                          label: (0, a.jsx)(c.x6, {
                            id: "friends.upDrawer.notifications.decline",
                          }),
                          run: () => t.decline(n.from.senderId, l),
                        },
                      ],
                    };
                  })(p, t)),
                (g[0] = p),
                (g[1] = t))
              : (t = g[1]),
            g[2] !== h
              ? ((e = (t) =>
                  (function (t, e) {
                    let { data: n, title: o, message: i, origin: r } = e;
                    return {
                      title: o ?? "",
                      message: i,
                      mainCtaColor: "animated-green-gradient",
                      thumbnail: {
                        url: n.game.gameCover,
                        altText: n.game.gameName,
                        shape: "square",
                      },
                      snackbarVariant: "cool",
                      notificationPreferenceType: "interactiveNotifications",
                      suppressDuringMobileGameplay: !0,
                      actions: [
                        {
                          id: "accept",
                          dataTestId: "toast-game-invite-accept",
                          label: (0, a.jsx)(c.x6, {
                            id: "friends.popup.receiveGameInvite.accept",
                          }),
                          run: () =>
                            t.accept({
                              gameId: n.game.gameId,
                              slug: n.game.gameSlug,
                              joinUrl: n.game.joinUrl,
                              fromUserId: n.from.userId,
                              origin: r,
                            }),
                        },
                        {
                          id: "decline",
                          dataTestId: "toast-game-invite-decline",
                          label: (0, a.jsx)(c.x6, {
                            id: "friends.popup.receiveGameInvite.decline",
                          }),
                          run: () =>
                            t.decline({
                              gameId: n.game.gameId,
                              slug: n.game.gameSlug,
                              joinUrl: n.game.joinUrl,
                              fromUserId: n.from.userId,
                              origin: r,
                            }),
                        },
                      ],
                    };
                  })(h, t)),
                (g[2] = h),
                (g[3] = e))
              : (e = g[3]),
            g[4] !== z
              ? ((n = (t) =>
                  (function (t, e) {
                    let { data: n, title: o, message: i, origin: r } = e;
                    return {
                      title: o ?? "",
                      message: i,
                      mainCtaColor: "animated-green-gradient",
                      thumbnail: {
                        url: n.game.gameCover,
                        altText: n.game.gameName,
                        shape: "square",
                      },
                      snackbarVariant: "cool",
                      notificationPreferenceType: "interactiveNotifications",
                      suppressDuringMobileGameplay: !0,
                      actions: [
                        {
                          id: "accept",
                          dataTestId: "toast-leaderboard-challenge-accept",
                          label: (0, a.jsx)(c.x6, {
                            id: "friends.popup.receiveGameInviteLeaderboard.accept",
                          }),
                          run: () =>
                            t.accept({
                              gameId: n.game.gameId,
                              slug: n.game.gameSlug,
                              joinUrl: n.game.joinUrl,
                              fromUserId: n.from.userId,
                              origin: r,
                            }),
                        },
                        {
                          id: "decline",
                          dataTestId: "toast-leaderboard-challenge-decline",
                          label: (0, a.jsx)(c.x6, {
                            id: "friends.popup.receiveGameInvite.decline",
                          }),
                          run: () =>
                            t.decline({
                              gameId: n.game.gameId,
                              slug: n.game.gameSlug,
                              joinUrl: n.game.joinUrl,
                              fromUserId: n.from.userId,
                              origin: r,
                            }),
                        },
                      ],
                    };
                  })(z, t)),
                (g[4] = z),
                (g[5] = n))
              : (n = g[5]),
            g[6] !== z
              ? ((_ = (t) =>
                  (function (t, e) {
                    let { data: n, title: o, message: i, origin: r } = e;
                    return {
                      title: o ?? "",
                      message: i,
                      mainCtaColor: "animated-green-gradient",
                      thumbnail: {
                        url: n.game.gameCover,
                        altText: n.game.gameName,
                        shape: "square",
                      },
                      snackbarVariant: "cool",
                      notificationPreferenceType: "informationalNotifications",
                      suppressDuringMobileGameplay: !0,
                      actions: [
                        {
                          id: "play",
                          dataTestId: "toast-leaderboard-challenge-beaten-play",
                          label: (0, a.jsx)(c.x6, {
                            id: "friends.popup.receiveGameInviteLeaderboard.accept",
                          }),
                          run: () =>
                            t.accept(
                              {
                                gameId: n.game.gameId,
                                slug: n.game.gameSlug,
                                joinUrl: n.game.joinUrl,
                                fromUserId: n.from.userId,
                                origin: r,
                              },
                              "play"
                            ),
                        },
                      ],
                    };
                  })(z, t)),
                (g[6] = z),
                (g[7] = _))
              : (_ = g[7]),
            g[8] !== B
              ? ((f = (t) =>
                  (function (t, e) {
                    let { title: n, message: o, avatar: i } = e;
                    return {
                      title: n ?? "",
                      message: o,
                      thumbnail: { url: i, altText: "Avatar", shape: "circle" },
                      snackbarVariant: "cool",
                      notificationPreferenceType: "informationalNotifications",
                      actions: [
                        {
                          id: "accept",
                          dataTestId: "toast-friend-request-accepted-play",
                          label: (0, a.jsx)(c.x6, {
                            id: "friends.upDrawer.notifications.playTogether",
                          }),
                          run: () => t.accept(),
                        },
                      ],
                    };
                  })(B, t)),
                (g[8] = B),
                (g[9] = f))
              : (f = g[9]),
            g[10] !== t ||
            g[11] !== e ||
            g[12] !== n ||
            g[13] !== _ ||
            g[14] !== f
              ? ((m = {
                  [i.qM]: t,
                  [i._l]: e,
                  [i.Wy]: n,
                  [i.GK]: _,
                  [i.Ye]: f,
                }),
                (g[10] = t),
                (g[11] = e),
                (g[12] = n),
                (g[13] = _),
                (g[14] = f),
                (g[15] = m))
              : (m = g[15]),
            m
          );
        }
      },
      64878: (t) => {
        t.exports = {
          czyButton: "CoolNotificationMobile_czyButton__MvnET",
          "czyButton--contained--purple":
            "CoolNotificationMobile_czyButton--contained--purple__NgSlD",
          "czyButton--contained--white":
            "CoolNotificationMobile_czyButton--contained--white__TsUCM",
          "czyButton--contained--grey":
            "CoolNotificationMobile_czyButton--contained--grey__KXDlo",
          "czyButton--contained--warning":
            "CoolNotificationMobile_czyButton--contained--warning__s0V47",
          "czyButton--contained--alert":
            "CoolNotificationMobile_czyButton--contained--alert__0pH6T",
          "czyButton--contained--success":
            "CoolNotificationMobile_czyButton--contained--success__qTGiR",
          "czyButton--contained--black":
            "CoolNotificationMobile_czyButton--contained--black__e6brb",
          "czyButton--contained--green-gradient":
            "CoolNotificationMobile_czyButton--contained--green-gradient__iGing",
          "czyButton--contained--animated-green-gradient":
            "CoolNotificationMobile_czyButton--contained--animated-green-gradient___dy9O",
          "scroll-gradient": "CoolNotificationMobile_scroll-gradient__mhrY4",
          "czyButton--outlined--purple":
            "CoolNotificationMobile_czyButton--outlined--purple__N0E_u",
          "czyButton--link--purple":
            "CoolNotificationMobile_czyButton--link--purple__66PIl",
          "czyButton--outlined--white":
            "CoolNotificationMobile_czyButton--outlined--white___W1vX",
          "czyButton--link--white":
            "CoolNotificationMobile_czyButton--link--white__MfJo_",
          "czyButton--outlined--grey":
            "CoolNotificationMobile_czyButton--outlined--grey__HwFmN",
          "czyButton--link--grey":
            "CoolNotificationMobile_czyButton--link--grey__Z42LN",
          "czyButton--outlined--warning":
            "CoolNotificationMobile_czyButton--outlined--warning__lRvg3",
          "czyButton--link--warning":
            "CoolNotificationMobile_czyButton--link--warning__0pp8P",
          "czyButton--outlined--alert":
            "CoolNotificationMobile_czyButton--outlined--alert__u_bVT",
          "czyButton--link--alert":
            "CoolNotificationMobile_czyButton--link--alert__ul3WQ",
          "czyButton--outlined--success":
            "CoolNotificationMobile_czyButton--outlined--success__Vlxtw",
          "czyButton--link--success":
            "CoolNotificationMobile_czyButton--link--success__D675x",
          "czyButton--outlined":
            "CoolNotificationMobile_czyButton--outlined__psMJ4",
          "czyButton--disabled":
            "CoolNotificationMobile_czyButton--disabled__lnqLP",
          "czyButton--height50":
            "CoolNotificationMobile_czyButton--height50__YHDS6",
          "czyButton--height34":
            "CoolNotificationMobile_czyButton--height34__Or6vp",
          "czyButton--height28":
            "CoolNotificationMobile_czyButton--height28__mKvUC",
          "czyButton--fullWidth":
            "CoolNotificationMobile_czyButton--fullWidth__qSX8m",
          "czyButton--headerIcon":
            "CoolNotificationMobile_czyButton--headerIcon__KzjZq",
          "czyButton--headerIcon--desktop":
            "CoolNotificationMobile_czyButton--headerIcon--desktop__CbX8w",
          "czyButton--headerIcon--mobile":
            "CoolNotificationMobile_czyButton--headerIcon--mobile__S0PWC",
          "czyButton--headerIcon--withLabel":
            "CoolNotificationMobile_czyButton--headerIcon--withLabel__Mcxvf",
          snackbarContent: "CoolNotificationMobile_snackbarContent__Ipigg",
          closeContainer: "CoolNotificationMobile_closeContainer__RiJZ2",
          avatarContainer: "CoolNotificationMobile_avatarContainer___1EC_",
          avatar: "CoolNotificationMobile_avatar__lAP5z",
          circle: "CoolNotificationMobile_circle__kOPlS",
          square: "CoolNotificationMobile_square__Y7bzo",
          textContainer: "CoolNotificationMobile_textContainer__OsJZd",
          acceptHandler: "CoolNotificationMobile_acceptHandler__pABxw",
        };
      },
      78576: (t, e, n) => {
        "use strict";
        n.d(e, { A: () => u });
        var o = n(75155),
          i = n(55729),
          a = n(98417),
          c = n(1584),
          r = n(41136),
          l = n(61827),
          s = n(55739);
        let u = () => {
          let t,
            e,
            n = (0, o.c)(7),
            { joinRoomListenerCount: u, playingGame: _ } = (0, i.useContext)(
              c.T
            ),
            { crazyRouterChange: y } = (0, i.useContext)(l.Gl),
            { sendJoinRoomEvent: f } = (0, s.A)();
          n[0] !== y || n[1] !== u || n[2] !== _?.slug || n[3] !== f
            ? ((t = (t) => {
                let { joinUrl: e, gameSlug: n, newTab: o } = t;
                if (o) return window.open(e, "_blank"), "newTab";
                if ((0, a.O)(n) && _?.slug === n) {
                  if (u > 0) f(e);
                  else {
                    (0, r.OM)({
                      query: ((t) => {
                        try {
                          let e = {};
                          return (
                            new URL(
                              t,
                              window.location.href
                            ).searchParams.forEach((t, n) => {
                              e[n] = t;
                            }),
                            e
                          );
                        } catch (e) {
                          return (
                            console.error(
                              `Failed to read the invite params of ${t}`,
                              e
                            ),
                            {}
                          );
                        }
                      })(e),
                    });
                    try {
                      window.history.replaceState(
                        { ...window.history.state, as: e, url: e },
                        "",
                        e
                      );
                    } catch (t) {
                      console.error(
                        `Failed to show the join URL ${e} in the address bar`,
                        t
                      );
                    }
                  }
                  return "joinedInPlace";
                }
                return y(e).catch(d), "navigated";
              }),
              (n[0] = y),
              (n[1] = u),
              (n[2] = _?.slug),
              (n[3] = f),
              (n[4] = t))
            : (t = n[4]);
          let m = t;
          return (
            n[5] !== m
              ? ((e = { joinGame: m }), (n[5] = m), (n[6] = e))
              : (e = n[6]),
            e
          );
        };
        function d(t) {
          return console.error("Navigating to the joined game failed", t);
        }
      },
      81126: (t) => {
        t.exports = {
          czyButton: "CalmNotification_czyButton__P6qsu",
          "czyButton--contained--purple":
            "CalmNotification_czyButton--contained--purple__VZHrb",
          "czyButton--contained--white":
            "CalmNotification_czyButton--contained--white___QhtD",
          "czyButton--contained--grey":
            "CalmNotification_czyButton--contained--grey__odXR6",
          "czyButton--contained--warning":
            "CalmNotification_czyButton--contained--warning__17TxR",
          "czyButton--contained--alert":
            "CalmNotification_czyButton--contained--alert__XUrsC",
          "czyButton--contained--success":
            "CalmNotification_czyButton--contained--success__T4Acw",
          "czyButton--contained--black":
            "CalmNotification_czyButton--contained--black__AGof3",
          "czyButton--contained--green-gradient":
            "CalmNotification_czyButton--contained--green-gradient__0F_KY",
          "czyButton--contained--animated-green-gradient":
            "CalmNotification_czyButton--contained--animated-green-gradient__ro7Uj",
          "scroll-gradient": "CalmNotification_scroll-gradient___tbrh",
          "czyButton--outlined--purple":
            "CalmNotification_czyButton--outlined--purple__idjJ6",
          "czyButton--link--purple":
            "CalmNotification_czyButton--link--purple__O6n18",
          "czyButton--outlined--white":
            "CalmNotification_czyButton--outlined--white__1go_N",
          "czyButton--link--white":
            "CalmNotification_czyButton--link--white__fdII0",
          "czyButton--outlined--grey":
            "CalmNotification_czyButton--outlined--grey__pDulv",
          "czyButton--link--grey":
            "CalmNotification_czyButton--link--grey__3bNw9",
          "czyButton--outlined--warning":
            "CalmNotification_czyButton--outlined--warning__OvU_h",
          "czyButton--link--warning":
            "CalmNotification_czyButton--link--warning__ykXYu",
          "czyButton--outlined--alert":
            "CalmNotification_czyButton--outlined--alert__2EZz0",
          "czyButton--link--alert":
            "CalmNotification_czyButton--link--alert__UM6kd",
          "czyButton--outlined--success":
            "CalmNotification_czyButton--outlined--success__y1p9c",
          "czyButton--link--success":
            "CalmNotification_czyButton--link--success__Rw08z",
          "czyButton--outlined": "CalmNotification_czyButton--outlined__opLO0",
          "czyButton--disabled": "CalmNotification_czyButton--disabled__dK9RC",
          "czyButton--height50": "CalmNotification_czyButton--height50__6QZUL",
          "czyButton--height34": "CalmNotification_czyButton--height34__pidZE",
          "czyButton--height28": "CalmNotification_czyButton--height28__qYu3f",
          "czyButton--fullWidth":
            "CalmNotification_czyButton--fullWidth__XDiO9",
          "czyButton--headerIcon":
            "CalmNotification_czyButton--headerIcon__Au7Kg",
          "czyButton--headerIcon--desktop":
            "CalmNotification_czyButton--headerIcon--desktop__ACA6B",
          "czyButton--headerIcon--mobile":
            "CalmNotification_czyButton--headerIcon--mobile___n7Hd",
          "czyButton--headerIcon--withLabel":
            "CalmNotification_czyButton--headerIcon--withLabel__p1bBN",
          snackbarContentHidden:
            "CalmNotification_snackbarContentHidden__ngQUy",
          snackbarContent: "CalmNotification_snackbarContent__8u2U5",
          icon: "CalmNotification_icon__Irf9C",
          message: "CalmNotification_message__CKUda",
        };
      },
      90431: (t, e, n) => {
        "use strict";
        n.d(e, { L: () => o });
        let o = (t) => {
          if (t.extra_data)
            try {
              return JSON.parse(t.extra_data);
            } catch (e) {
              console.error(
                "Error while parsing json for notification with message ",
                t
              );
              return;
            }
        };
      },
      90781: (t, e, n) => {
        "use strict";
        n.d(e, { V: () => o });
        let o = (t, e, n, o) => {
          let i = t[e];
          return i?.({ data: n, ...o });
        };
      },
      98881: (t, e, n) => {
        "use strict";
        n.r(e), n.d(e, { default: () => ti });
        var o = n(6029),
          i = n(75155),
          a = n(55729),
          c = n(50599),
          r = n(50212),
          l = n(33652),
          s = n(1584),
          u = n(50190),
          d = n(50293),
          _ = n(4230),
          y = n(81126),
          f = n.n(y);
        let m = a.forwardRef((t, e) => {
          let { icon: n, message: i, style: c } = t,
            r = a.useContext(_.A),
            s = (0, d.xl)(r) ? f().snackbarContent : f().snackbarContentHidden;
          return (0, o.jsx)(l.Zv, {
            ref: e,
            role: "alert",
            className: s,
            style: c,
            children:
              (0, d.xl)(r) &&
              (0, o.jsxs)(o.Fragment, {
                children: [
                  (0, o.jsx)("div", { className: f().icon, children: n }),
                  (0, o.jsx)("div", { className: f().message, children: i }),
                ],
              }),
          });
        });
        var g = n(63877),
          p = n.n(g),
          h = n(80638),
          z = n(13246),
          B = n(94618),
          C = n(93800),
          b = n(37434),
          k = n(92036),
          N = n(37706),
          v = n.n(N);
        let I = `${z.A.Instance.data.files}crazygames-portal/sounds/notification.mp3`,
          w = a.forwardRef((t, e) => {
            let {
                id: n,
                thumbnailData: i,
                mainCtaColor: c,
                secondaryCtaColor: s,
                title: u,
                message: d,
                accept: _,
                decline: y,
                style: f,
              } = t,
              { closeSnackbar: m } = (0, l.dh)(),
              [g] = (0, h.A)(I, { volume: 0.6 }),
              { paused: z, setPaused: N } = a.useContext(k.$),
              w = a.useCallback(() => {
                m(n);
              }, [n, m]),
              x = a.useCallback(() => {
                y?.onAction && y.onAction(), m(n);
              }, [n, m, y]),
              j = a.useCallback(() => {
                _?.onAction && _.onAction(), m(n);
              }, [n, m, _]),
              D = a.useCallback(() => {
                z || N(!0);
              }, [z, N]),
              L = a.useCallback(() => {
                z && N(!1);
              }, [z, N]);
            return (
              a.useEffect(() => {
                g && g();
              }, [g]),
              (0, o.jsxs)(l.Zv, {
                ref: e,
                role: "alert",
                className: (0, r.A)(v().snackbarContent, { [v().paused]: z }),
                style: f,
                onMouseEnter: D,
                onMouseLeave: L,
                children: [
                  (0, o.jsx)("div", {
                    className: v().closeContainer,
                    onClick: w,
                    children: (0, o.jsx)(C.A, { name: "close" }),
                  }),
                  (0, o.jsxs)("div", {
                    className: v().avatarContainer,
                    children: [
                      (0, o.jsx)("img", {
                        src: (0, B.Ay)(i?.url, { width: 50, height: 50 }),
                        alt: i ? i.altText : "Avatar",
                        srcSet: (0, B.Wn)(i?.url || "", {
                          width: 50,
                          height: 50,
                        }),
                        className: `${v().avatar} ${i && v()[i.shape]}`,
                      }),
                      (0, o.jsx)("div", {
                        className: v().textContainer,
                        children:
                          "string" == typeof d
                            ? (0, o.jsxs)(o.Fragment, {
                                children: [
                                  (0, o.jsx)(p(), {
                                    components: {
                                      p: (t) => {
                                        let { node: e, ...n } = t;
                                        return (0, o.jsx)("div", { ...n });
                                      },
                                    },
                                    children: u,
                                  }),
                                  (0, o.jsx)(p(), {
                                    components: {
                                      p: (t) => {
                                        let { node: e, ...n } = t;
                                        return (0, o.jsx)("div", { ...n });
                                      },
                                    },
                                    children: d,
                                  }),
                                ],
                              })
                            : (0, o.jsxs)(o.Fragment, {
                                children: [
                                  (0, o.jsx)("div", {
                                    className: v().title,
                                    children: u,
                                  }),
                                  (0, o.jsx)("div", {
                                    className: v().message,
                                    children: d,
                                  }),
                                ],
                              }),
                      }),
                    ],
                  }),
                  (0, o.jsxs)("div", {
                    className: v().buttonContainer,
                    children: [
                      y &&
                        (0, o.jsx)(b.A, {
                          dataTestId: y.dataTestId,
                          variant: "contained",
                          height: 34,
                          color: s,
                          onClick: x,
                          children: y.element,
                        }),
                      (0, o.jsx)(b.A, {
                        dataTestId: _.dataTestId,
                        variant: "contained",
                        color: c,
                        height: 34,
                        onClick: j,
                        children: _.element,
                      }),
                    ],
                  }),
                  (0, o.jsx)("div", {
                    className: v().countdownBar,
                    style: { animationDuration: "10000ms" },
                    onAnimationEnd: w,
                  }),
                ],
              })
            );
          });
        var x = n(64878),
          j = n.n(x);
        let D = a.forwardRef((t, e) => {
          let {
              id: n,
              thumbnailData: i,
              mainCtaColor: c,
              title: r,
              message: s,
              accept: u,
              style: d,
            } = t,
            { closeSnackbar: _ } = (0, l.dh)(),
            y = a.useCallback(() => {
              _(n);
            }, [n, _]),
            f = a.useCallback(() => {
              u?.onAction && u.onAction(), _(n);
            }, [n, _, u]);
          return (
            a.useEffect(() => {
              let t = setTimeout(() => {
                _(n);
              }, 3e3);
              return () => clearTimeout(t);
            }, [_, n]),
            (0, o.jsxs)(l.Zv, {
              ref: e,
              role: "alert",
              className: j().snackbarContent,
              style: d,
              children: [
                (0, o.jsx)("div", {
                  className: j().closeContainer,
                  onClick: y,
                  children: (0, o.jsx)(C.A, { name: "close" }),
                }),
                (0, o.jsx)("div", {
                  className: j().avatarContainer,
                  children: (0, o.jsx)("img", {
                    src: (0, B.Ay)(i?.url, { width: 30, height: 30 }),
                    alt: i ? i.altText : "Avatar",
                    srcSet: (0, B.Wn)(i?.url || "", { width: 30, height: 30 }),
                    className: `${j().avatar} ${i && j()[i.shape]}`,
                  }),
                }),
                (0, o.jsxs)("div", {
                  className: j().textContainer,
                  children: [r, " ", s],
                }),
                u.hideOnMobile
                  ? (0, o.jsx)("div", {
                      "data-testid": u.dataTestId,
                      className: j().acceptHandler,
                      onClick: f,
                    })
                  : (0, o.jsx)("div", {
                      className: j().buttonContainer,
                      children: (0, o.jsx)(b.A, {
                        dataTestId: u.dataTestId,
                        variant: "contained",
                        color: c,
                        height: 34,
                        onClick: f,
                        children: u.element,
                      }),
                    }),
              ],
            })
          );
        });
        var L = n(20166),
          M = n.n(L);
        let T = (t) => {
          let e,
            n,
            c,
            y,
            f = (0, i.c)(14),
            { children: g } = t,
            p = (0, u.A)(),
            h = a.useContext(_.A),
            { isPlaying: z } = a.useContext(s.T);
          if (!p) {
            let t;
            return (
              f[0] !== g
                ? ((t = (0, o.jsx)(o.Fragment, { children: g })),
                  (f[0] = g),
                  (f[1] = t))
                : (t = f[1]),
              t
            );
          }
          let B = (0, d.xl)(h) ? w : D;
          f[2] !== h
            ? ((e = (0, d.xl)(h)
                ? { vertical: "bottom", horizontal: "right" }
                : { vertical: "top", horizontal: "left" }),
              (f[2] = h),
              (f[3] = e))
            : (e = f[3]);
          let C = e;
          f[4] !== h || f[5] !== z
            ? ((n = (0, d.xl)(h)
                ? void 0
                : {
                    containerRoot: (0, r.A)(
                      M().containerRoot,
                      z && M().isPlaying
                    ),
                    containerAnchorOriginTopLeft:
                      M().containerAnchorOriginTopLeft,
                  }),
              (f[4] = h),
              (f[5] = z),
              (f[6] = n))
            : (n = f[6]);
          let b = n;
          return (
            f[7] !== B
              ? ((c = {
                  userportalCoolNotification: B,
                  userportalCalmNotification: m,
                }),
                (f[7] = B),
                (f[8] = c))
              : (c = f[8]),
            f[9] !== C || f[10] !== g || f[11] !== b || f[12] !== c
              ? ((y = (0, o.jsx)(l.n, {
                  Components: c,
                  anchorOrigin: C,
                  classes: b,
                  children: g,
                })),
                (f[9] = C),
                (f[10] = g),
                (f[11] = b),
                (f[12] = c),
                (f[13] = y))
              : (y = f[13]),
            y
          );
        };
        var A = n(98417),
          E = n(88047),
          U = n(71237);
        let R = () => {
            let t,
              e,
              n,
              o = (0, i.c)(5),
              { enqueueSnackbar: c } = (0, l.dh)();
            o[0] === Symbol.for("react.memo_cache_sentinel")
              ? ((t = new Set()), (o[0] = t))
              : (t = o[0]);
            let r = (0, a.useRef)(t);
            o[1] !== c
              ? ((e = (t) => {
                  let { message: e, icon: n, debounce: o } = t;
                  !(o?.key && r.current.has(o.key)) &&
                    (c(e, {
                      variant: "userportalCalmNotification",
                      autoHideDuration: 1e4,
                      disableWindowBlurListener: !0,
                      icon: n,
                    }),
                    o &&
                      (r.current.add(o.key),
                      setTimeout(() => {
                        r.current.delete(o.key);
                      }, o.interval)));
                }),
                (o[1] = c),
                (o[2] = e))
              : (e = o[2]);
            let s = e;
            return (
              o[3] !== s
                ? ((n = { enqueueSnackbar: s }), (o[3] = s), (o[4] = n))
                : (n = o[4]),
              n
            );
          },
          S = () => {
            let t,
              e,
              n = (0, i.c)(4),
              { enqueueSnackbar: o } = (0, l.dh)();
            n[0] !== o
              ? ((t = (t) => {
                  let {
                    thumbnailData: e,
                    mainCtaColor: n,
                    secondaryCtaColor: i,
                    title: a,
                    message: c,
                    accept: r,
                    decline: l,
                    key: s,
                    preventDuplicate: u,
                  } = t;
                  return o(c, {
                    variant: "userportalCoolNotification",
                    persist: !0,
                    title: a,
                    thumbnailData: void 0 === e ? { shape: "circle" } : e,
                    mainCtaColor: void 0 === n ? "purple" : n,
                    secondaryCtaColor: void 0 === i ? "grey" : i,
                    accept: r,
                    decline: l,
                    key: void 0 === s ? void 0 : s,
                    preventDuplicate: void 0 !== u && u,
                  });
                }),
                (n[0] = o),
                (n[1] = t))
              : (t = n[1]);
            let a = t;
            return (
              n[2] !== a
                ? ((e = { enqueueSnackbar: a }), (n[2] = a), (n[3] = e))
                : (e = n[3]),
              e
            );
          };
        var P = n(60352),
          O = n(90781),
          q = n(90431);
        let G = () => {
          let t,
            e,
            n,
            o,
            c,
            r = (0, i.c)(17),
            l = a.useContext(_.A),
            { isPlaying: u } = a.useContext(s.T),
            y = (0, E.nq)(),
            { settings: f } = U.Qg(),
            m = !!f?.notificationPreferences?.informationalNotifications,
            g = !!f?.notificationPreferences?.interactiveNotifications,
            { enqueueSnackbar: p } = S(),
            { enqueueSnackbar: h } = R();
          r[0] !== l || r[1] !== u
            ? ((t = u && (0, d.Gz)(l)), (r[0] = l), (r[1] = u), (r[2] = t))
            : (t = r[2]);
          let z = t,
            B = (0, P.A)();
          r[3] !== B ||
          r[4] !== m ||
          r[5] !== g ||
          r[6] !== h ||
          r[7] !== p ||
          r[8] !== y ||
          r[9] !== z
            ? ((e = (t, e, n, o, i, a, c) => {
                let r = void 0 === c ? "snackbar" : c,
                  l = (0, O.V)(B, t, e, {
                    title: i,
                    message: o,
                    avatar: a,
                    origin: r,
                  });
                (0, A.O)(l) &&
                  (("informationalNotifications" ===
                    l.notificationPreferenceType &&
                    !m) ||
                    ("interactiveNotifications" ===
                      l.notificationPreferenceType &&
                      !g) ||
                    ("snackbar" === r && l.suppressDuringMobileGameplay && z) ||
                    (function (t, e, n) {
                      let { enqueueCool: o, enqueueCalm: i } = e,
                        a = "calm" === t.snackbarVariant ? i : o,
                        c = t.actions[0],
                        r = t.actions[1];
                      a({
                        title: t.title ?? "",
                        message: t.message,
                        thumbnailData: t.thumbnail
                          ? {
                              url: t.thumbnail.url,
                              altText: t.thumbnail.altText,
                              shape: t.thumbnail.shape,
                            }
                          : void 0,
                        mainCtaColor: t.mainCtaColor,
                        accept: c
                          ? {
                              element: c.label,
                              dataTestId: c.dataTestId,
                              onAction: () => {
                                c.run(), n();
                              },
                            }
                          : void 0,
                        decline: r
                          ? {
                              element: r.label,
                              dataTestId: r.dataTestId,
                              onAction: () => {
                                r.run(), n();
                              },
                            }
                          : void 0,
                      });
                    })(l, { enqueueCool: p, enqueueCalm: h }, () => {
                      y?.markAsInteracted(n);
                    }));
              }),
              (r[3] = B),
              (r[4] = m),
              (r[5] = g),
              (r[6] = h),
              (r[7] = p),
              (r[8] = y),
              (r[9] = z),
              (r[10] = e))
            : (e = r[10]);
          let C = e;
          r[11] !== C
            ? ((n = (t) => {
                let e = (0, q.L)(t.message);
                e &&
                  e.showInAppSnackbar &&
                  C(
                    e.notificationType,
                    e.notificationData,
                    t.n_id,
                    t.message.text,
                    t.message.header,
                    t.message.avatar?.avatar_url,
                    "snackbar"
                  );
              }),
              (r[11] = C),
              (r[12] = n))
            : (n = r[12]);
          let b = n;
          return (
            r[13] !== y || r[14] !== b
              ? ((o = () => {
                  if (!y) return;
                  let t = (t) => {
                    t.message.extra_data && b(t), y.markAsSeen(t.n_id);
                  };
                  return (
                    y.emitter.on("feed.new_notification", t),
                    () => {
                      y.emitter.off("feed.new_notification", t);
                    }
                  );
                }),
                (c = [y, b]),
                (r[13] = y),
                (r[14] = b),
                (r[15] = o),
                (r[16] = c))
              : ((o = r[15]), (c = r[16])),
            (0, a.useEffect)(o, c),
            null
          );
        };
        var W = n(89964),
          F = n(33165);
        let V = () => (
          (() => {
            let t,
              e,
              n = (0, i.c)(4),
              { openDrawer: o } = (0, a.useContext)(F.lv),
              { setGameInviteLink: c } = a.useContext(s.T);
            n[0] !== o || n[1] !== c
              ? ((t = () => {
                  let t = (t) => {
                    if (!t.data || t.data.type !== W.x) return;
                    let e = t.data;
                    "inviteButtonClick" === e.event
                      ? (c(e.url),
                        o("inviteFriends", {
                          clickOrigin: "gameframeInviteFriendsButton",
                        }))
                      : "exitButtonWithInviteClick" === e.event && c(e.url);
                  };
                  return (
                    window.addEventListener("message", t),
                    () => {
                      window.removeEventListener("message", t);
                    }
                  );
                }),
                (e = [o, c]),
                (n[0] = o),
                (n[1] = c),
                (n[2] = t),
                (n[3] = e))
              : ((t = n[2]), (e = n[3])),
              a.useEffect(t, e);
          })(),
          null
        );
        var J = n(14886),
          Q = n(79942);
        let X = (t) => {
          let e,
            n,
            r,
            l = (0, i.c)(9),
            { friendId: s, sharesLiveGameActivity: u } = t,
            { settings: d } = U.Qg(),
            _ = d?.notificationPreferences?.informationalNotifications !== !1,
            { enqueueSnackbar: y } = R();
          l[0] === Symbol.for("react.memo_cache_sentinel")
            ? ((e = { skip: !0 }), (l[0] = e))
            : (e = l[0]);
          let { userProfile: f, refetch: m } = U.YC(s, void 0, e),
            g = a.useRef(null);
          l[1] !== _ || l[2] !== y || l[3] !== s || l[4] !== m || l[5] !== f
            ? ((n = async () => {
                if (!_) return;
                let t = f;
                if (!t) {
                  g.current ||
                    (g.current = m({ id: s, token: void 0 }).finally(() => {
                      g.current = null;
                    }));
                  let e = await g.current;
                  t = e?.data?.user;
                }
                t &&
                  y({
                    debounce: { interval: 2e4, key: `friend-online-${s}` },
                    message: (0, o.jsx)(Q.x6, {
                      id: "friends.notifications.friendIsOnline",
                      values: {
                        username: (0, o.jsx)("span", {
                          style: { fontWeight: 700 },
                          children: t.username,
                        }),
                      },
                    }),
                    icon: (0, o.jsx)("span", { children: "\uD83D\uDC4B" }),
                  });
              }),
              (l[1] = _),
              (l[2] = y),
              (l[3] = s),
              (l[4] = m),
              (l[5] = f),
              (l[6] = n))
            : (n = l[6]);
          let p = n;
          return (
            l[7] !== p
              ? ((r = () => {
                  p().catch(H);
                }),
                (l[7] = p),
                (l[8] = r))
              : (r = l[8]),
            c.ee(s, r, !u),
            null
          );
        };
        function H(t) {
          console.error("onUserOnline failed", t);
        }
        var Z = n(54673),
          Y = n(17939),
          $ = n(93389),
          K = n(71684),
          tt = n(78576);
        let te = (t) => {
            let e,
              n,
              r,
              l,
              u = (0, i.c)(18),
              { userId: d, sharesLiveGameActivity: _ } = t,
              { settings: y } = U.Qg(),
              f = y?.notificationPreferences?.informationalNotifications !== !1,
              { userProfile: m, hasFetchedProfile: g } = ((t, e) => {
                let [n, o] = a.useState(!1),
                  { userProfile: i } = U.YC(t, void 0, { skip: !e || n }),
                  [c, r] = a.useState(i);
                return (
                  i && i !== c && (r(i), o(!0)),
                  { userProfile: c, hasFetchedProfile: n }
                );
              })(d, f),
              p = a.useContext(s.T),
              { enqueueSnackbar: h } = S(),
              { enqueueSnackbar: z } = R(),
              { onAcceptClick: B } = (() => {
                let t,
                  e,
                  n = (0, i.c)(6),
                  { routeHelper: o } = a.useContext($.A),
                  { crazyAnalyticsService: c } = a.useContext(K.A).services,
                  { joinGame: r } = (0, tt.A)();
                n[0] !== c || n[1] !== r || n[2] !== o
                  ? ((t = (t, e) => {
                      var n;
                      let i = (0, A.O)(t.gameSlug)
                        ? o.localizedJoinUrl(t.gameSlug, t.joinUrl)
                        : { href: t.joinUrl, as: t.joinUrl };
                      t.gameId &&
                        c.gameInteractionEvent({
                          method: "friendJoinable",
                          origin: "popupNotification",
                          action: "send",
                          target: t.userId,
                          targetStatus: null,
                          targetGameId: t.gameId,
                        }),
                        ("joinedInPlace" ===
                          r({ joinUrl: i.href, gameSlug: t.gameSlug }) ||
                          ((n = i.href), window.location.href === n)) &&
                          e?.();
                    }),
                    (n[0] = c),
                    (n[1] = r),
                    (n[2] = o),
                    (n[3] = t))
                  : (t = n[3]);
                let l = t;
                return (
                  n[4] !== l
                    ? ((e = { onAcceptClick: l }), (n[4] = l), (n[5] = e))
                    : (e = n[5]),
                  e
                );
              })();
            u[0] === Symbol.for("react.memo_cache_sentinel")
              ? ((e = new Map()), (u[0] = e))
              : (e = u[0]);
            let C = a.useRef(e),
              b = a.useRef(!1);
            u[1] !== z || u[2] !== p || u[3] !== m?.username
              ? ((n = (t) => {
                  let e = m?.username || "";
                  if (!(0, Y.oE)(p, t.gameStatus)) {
                    b.current = !1;
                    return;
                  }
                  if (!b.current) {
                    (b.current = !0),
                      z({
                        message: (0, o.jsx)(Q.x6, {
                          id: "friends.popup.friendJoinedYourLobby.text",
                          values: {
                            username: (0, o.jsx)("span", {
                              style: { fontWeight: 700 },
                              children: e,
                            }),
                          },
                        }),
                        icon: (0, o.jsx)("span", { children: "\uD83D\uDE4C" }),
                        debounce: {
                          interval: 1e4,
                          key: `joined-lobby-${t.userId}-${t.gameStatus?.gameId}`,
                        },
                      });
                    return;
                  }
                }),
                (u[1] = z),
                (u[2] = p),
                (u[3] = m?.username),
                (u[4] = n))
              : (n = u[4]);
            let k = n;
            u[5] !== h ||
            u[6] !== p ||
            u[7] !== B ||
            u[8] !== d ||
            u[9] !== m?.profile?.avatar ||
            u[10] !== m?.username
              ? ((r = (t) => {
                  let e = t.gameStatus;
                  if (!e || (0, Y.oE)(p, e)) return;
                  let {
                    joinUrl: n,
                    gameSlug: i,
                    gameName: a,
                    gameId: c,
                    gameCover: r,
                  } = e;
                  if (
                    !(0, A.O)(n) ||
                    !(0, A.O)(i) ||
                    !(0, A.O)(a) ||
                    !(0, A.O)(c) ||
                    !(0, A.O)(r)
                  )
                    return;
                  let l = m?.profile?.avatar || "",
                    s = m?.username || "",
                    u = e.multiplayerRoom?.roomId ?? c,
                    _ = `${d}:${c}:${u}`;
                  C.current.set(_, n),
                    (0, Z.qW)({ userId: d, gameId: c, roomKey: u }) &&
                      h({
                        key: _,
                        preventDuplicate: !0,
                        message: (0, o.jsx)(Q.x6, {
                          id: "friends.popup.friendJoinable.text",
                          values: {
                            gameName: (0, o.jsx)("span", {
                              style: { fontWeight: 700 },
                              children: a,
                            }),
                          },
                        }),
                        title: s,
                        thumbnailData: { shape: "square", url: r, altText: a },
                        mainCtaColor: "animated-green-gradient",
                        accept: {
                          element: (0, o.jsx)(Q.x6, {
                            id: "friends.popup.friendJoinable.button",
                          }),
                          onAction: () => {
                            B({
                              username: s,
                              joinUrl: C.current.get(_) ?? n,
                              avatar: l,
                              gameSlug: i,
                              gameId: c,
                              userId: d,
                              gameName: a,
                            });
                          },
                          hideOnMobile: !1,
                          dataTestId: "toast-friend-joinable-join",
                        },
                      });
                }),
                (u[5] = h),
                (u[6] = p),
                (u[7] = B),
                (u[8] = d),
                (u[9] = m?.profile?.avatar),
                (u[10] = m?.username),
                (u[11] = r))
              : (r = u[11]);
            let N = r;
            u[12] !== f ||
            u[13] !== N ||
            u[14] !== k ||
            u[15] !== g ||
            u[16] !== m
              ? ((l = (t) => {
                  g && m && f && (k(t), N(t));
                }),
                (u[12] = f),
                (u[13] = N),
                (u[14] = k),
                (u[15] = g),
                (u[16] = m),
                (u[17] = l))
              : (l = u[17]);
            let v = l;
            return c.MT(d, v, !_), null;
          },
          tn = () => {
            let t,
              e,
              n = (0, i.c)(7),
              { settings: r } = U.Qg(),
              l = c.l$(!0),
              s = r?.notificationPreferences?.interactiveNotifications !== !1;
            if (n[0] !== s || n[1] !== l) {
              let e;
              n[3] !== s
                ? ((e = (t) => {
                    let e = t.privacy?.shareLiveGameActivity ?? !0;
                    return (0, o.jsxs)(
                      a.Fragment,
                      {
                        children: [
                          s &&
                            (0, o.jsx)(o.Fragment, {
                              children: (0, o.jsx)(te, {
                                userId: t.id,
                                sharesLiveGameActivity: e,
                              }),
                            }),
                          (0, o.jsx)(
                            X,
                            { friendId: t.id, sharesLiveGameActivity: e },
                            t.id
                          ),
                        ],
                      },
                      t.id
                    );
                  }),
                  (n[3] = s),
                  (n[4] = e))
                : (e = n[4]),
                (t = l.map(e)),
                (n[0] = s),
                (n[1] = l),
                (n[2] = t);
            } else t = n[2];
            return (
              n[5] !== t
                ? ((e = (0, o.jsx)(o.Fragment, { children: t })),
                  (n[5] = t),
                  (n[6] = e))
                : (e = n[6]),
              e
            );
          },
          to = () => {
            let t,
              e = (0, i.c)(1),
              { user: n } = a.useContext(J.R);
            return n
              ? (e[0] === Symbol.for("react.memo_cache_sentinel")
                  ? ((t = (0, o.jsx)(tn, {})), (e[0] = t))
                  : (t = e[0]),
                t)
              : null;
          },
          ti = () => {
            let t,
              e = (0, i.c)(1);
            return (
              c.$v(!0),
              e[0] === Symbol.for("react.memo_cache_sentinel")
                ? ((t = (0, o.jsxs)(T, {
                    children: [
                      (0, o.jsx)(G, {}),
                      (0, o.jsx)(V, {}),
                      (0, o.jsx)(to, {}),
                    ],
                  })),
                  (e[0] = t))
                : (t = e[0]),
              t
            );
          };
      },
    },
  ]);
