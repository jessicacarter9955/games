!(function () {
  try {
    var n =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (n._sentryModuleMetadata = n._sentryModuleMetadata || {}),
      (n._sentryModuleMetadata[new n.Error().stack] = (function (n) {
        for (var e = 1; e < arguments.length; e++) {
          var t = arguments[e];
          if (null != t) for (var r in t) t.hasOwnProperty(r) && (n[r] = t[r]);
        }
        return n;
      })({}, n._sentryModuleMetadata[new n.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var e = new n.Error().stack;
    e &&
      ((n._sentryDebugIds = n._sentryDebugIds || {}),
      (n._sentryDebugIds[e] = "b27895cd-1c8a-49c7-9301-d15b650744e8"),
      (n._sentryDebugIdIdentifier =
        "sentry-dbid-b27895cd-1c8a-49c7-9301-d15b650744e8"));
  } catch (n) {}
})();
("use strict");
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [80957],
  {
    33652: (n, e, t) => {
      t.d(e, { Zv: () => nd, n: () => nS, dh: () => nO });
      var r,
        i,
        o,
        a,
        s,
        u,
        c = t(55729),
        l = t(56760);
      let d = function () {
          for (var n, e, t = 0, r = ""; t < arguments.length; )
            (n = arguments[t++]) &&
              (e = (function n(e) {
                var t,
                  r,
                  i = "";
                if ("string" == typeof e || "number" == typeof e) i += e;
                else if ("object" == typeof e)
                  if (Array.isArray(e))
                    for (t = 0; t < e.length; t++)
                      e[t] && (r = n(e[t])) && (i && (i += " "), (i += r));
                  else for (t in e) e[t] && (i && (i += " "), (i += t));
                return i;
              })(n)) &&
              (r && (r += " "), (r += e));
          return r;
        },
        f = { data: "" },
        p = /(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,
        m = /\/\*[^]*?\*\/|  +/g,
        h = /\n+/g,
        g = (n, e) => {
          let t = "",
            r = "",
            i = "";
          for (let o in n) {
            let a = n[o];
            "@" == o[0]
              ? "i" == o[1]
                ? (t = o + " " + a + ";")
                : (r +=
                    "f" == o[1]
                      ? g(a, o)
                      : o + "{" + g(a, "k" == o[1] ? "" : e) + "}")
              : "object" == typeof a
              ? (r += g(
                  a,
                  e
                    ? e.replace(/([^,])+/g, (n) =>
                        o.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g, (e) =>
                          /&/.test(e) ? e.replace(/&/g, n) : n ? n + " " + e : e
                        )
                      )
                    : o
                ))
              : null != a &&
                ((o =
                  "-" == o[1] ? o : o.replace(/[A-Z]/g, "-$&").toLowerCase()),
                (i += g.p ? g.p(o, a) : o + ":" + a + ";"));
          }
          return t + (e && i ? e + "{" + i + "}" : i) + r;
        },
        v = {},
        b = (n) => {
          if ("object" == typeof n) {
            let e = "";
            for (let t in n) e += t + b(n[t]);
            return e;
          }
          return n;
        };
      function E(n) {
        let e,
          t,
          r = this || {},
          i = n.call ? n(r.p) : n;
        return ((n, e, t, r, i) => {
          var o;
          let a = b(n),
            s =
              v[a] ||
              (v[a] = ((n) => {
                let e = 0,
                  t = 11;
                for (; e < n.length; ) t = (101 * t + n.charCodeAt(e++)) >>> 0;
                return "go" + t;
              })(a));
          if (!v[s]) {
            let e =
              a !== n
                ? n
                : ((n) => {
                    let e,
                      t,
                      r = [{}];
                    for (; (e = p.exec(n.replace(m, ""))); )
                      e[4]
                        ? r.shift()
                        : e[3]
                        ? ((t = e[3].replace(h, " ").trim()),
                          r.unshift((r[0][t] = r[0][t] || {})))
                        : (r[0][e[1]] = e[2].replace(h, " ").trim());
                    return r[0];
                  })(n);
            v[s] = g(i ? { ["@keyframes " + s]: e } : e, t ? "" : "." + s);
          }
          let u = t && v.g;
          return (
            t && (v.g = v[s]),
            (o = v[s]),
            u
              ? (e.data = e.data.replace(u, o))
              : -1 === e.data.indexOf(o) &&
                (e.data = r ? o + e.data : e.data + o),
            s
          );
        })(
          i.unshift
            ? i.raw
              ? ((e = [].slice.call(arguments, 1)),
                (t = r.p),
                i.reduce((n, r, i) => {
                  let o = e[i];
                  if (o && o.call) {
                    let n = o(t),
                      e =
                        (n && n.props && n.props.className) ||
                        (/^go/.test(n) && n);
                    o = e
                      ? "." + e
                      : n && "object" == typeof n
                      ? n.props
                        ? ""
                        : g(n, "")
                      : !1 === n
                      ? ""
                      : n;
                  }
                  return n + r + (null == o ? "" : o);
                }, ""))
              : i.reduce(
                  (n, e) => Object.assign(n, e && e.call ? e(r.p) : e),
                  {}
                )
            : i,
          ((n) => {
            if ("object" == typeof window) {
              let e =
                (n ? n.querySelector("#_goober") : window._goober) ||
                Object.assign(document.createElement("style"), {
                  innerHTML: " ",
                  id: "_goober",
                });
              return (
                (e.nonce = window.__nonce__),
                e.parentNode || (n || document.head).appendChild(e),
                e.firstChild
              );
            }
            return n || f;
          })(r.target),
          r.g,
          r.o,
          r.k
        );
      }
      function x(n, e) {
        for (var t = 0; t < e.length; t++) {
          var r = e[t];
          (r.enumerable = r.enumerable || !1),
            (r.configurable = !0),
            "value" in r && (r.writable = !0),
            Object.defineProperty(n, r.key, r);
        }
      }
      function y(n, e, t) {
        return e && x(n.prototype, e), t && x(n, t), n;
      }
      function k() {
        return (k =
          Object.assign ||
          function (n) {
            for (var e = 1; e < arguments.length; e++) {
              var t = arguments[e];
              for (var r in t)
                Object.prototype.hasOwnProperty.call(t, r) && (n[r] = t[r]);
            }
            return n;
          }).apply(this, arguments);
      }
      function w(n, e) {
        (n.prototype = Object.create(e.prototype)),
          (n.prototype.constructor = n),
          (n.__proto__ = e);
      }
      function C(n, e) {
        if (null == n) return {};
        var t,
          r,
          i = {},
          o = Object.keys(n);
        for (r = 0; r < o.length; r++)
          (t = o[r]), e.indexOf(t) >= 0 || (i[t] = n[t]);
        return i;
      }
      function S(n) {
        if (void 0 === n)
          throw ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return n;
      }
      E.bind({ g: 1 }), E.bind({ k: 1 });
      var O = function () {
          return "";
        },
        T = c.createContext({ enqueueSnackbar: O, closeSnackbar: O }),
        L = "@media (max-width:599.95px)",
        D = "@media (min-width:600px)",
        M = function (n) {
          return n.charAt(0).toUpperCase() + n.slice(1);
        },
        R = function (n) {
          return "" + M(n.vertical) + M(n.horizontal);
        },
        N = function (n) {
          return !!n || 0 === n;
        },
        j = "unmounted",
        H = "exited",
        P = "entering",
        _ = "entered",
        q = "exiting",
        A = (function (n) {
          function e(e) {
            var t,
              r = n.call(this, e) || this,
              i = e.appear;
            return (
              (r.appearStatus = null),
              e.in
                ? i
                  ? ((t = H), (r.appearStatus = P))
                  : (t = _)
                : (t = e.unmountOnExit || e.mountOnEnter ? j : H),
              (r.state = { status: t }),
              (r.nextCallback = null),
              r
            );
          }
          w(e, n),
            (e.getDerivedStateFromProps = function (n, e) {
              return n.in && e.status === j ? { status: H } : null;
            });
          var t = e.prototype;
          return (
            (t.componentDidMount = function () {
              this.updateStatus(!0, this.appearStatus);
            }),
            (t.componentDidUpdate = function (n) {
              var e = null;
              if (n !== this.props) {
                var t = this.state.status;
                this.props.in
                  ? t !== P && t !== _ && (e = P)
                  : (t === P || t === _) && (e = q);
              }
              this.updateStatus(!1, e);
            }),
            (t.componentWillUnmount = function () {
              this.cancelNextCallback();
            }),
            (t.getTimeouts = function () {
              var n = this.props.timeout,
                e = n,
                t = n;
              return (
                null != n &&
                  "number" != typeof n &&
                  "string" != typeof n &&
                  ((t = n.exit), (e = n.enter)),
                { exit: t, enter: e }
              );
            }),
            (t.updateStatus = function (n, e) {
              void 0 === n && (n = !1),
                null !== e
                  ? (this.cancelNextCallback(),
                    e === P ? this.performEnter(n) : this.performExit())
                  : this.props.unmountOnExit &&
                    this.state.status === H &&
                    this.setState({ status: j });
            }),
            (t.performEnter = function (n) {
              var e = this,
                t = this.props.enter,
                r = this.getTimeouts();
              n || t
                ? (this.props.onEnter && this.props.onEnter(this.node, n),
                  this.safeSetState({ status: P }, function () {
                    e.props.onEntering && e.props.onEntering(e.node, n),
                      e.onTransitionEnd(r.enter, function () {
                        e.safeSetState({ status: _ }, function () {
                          e.props.onEntered && e.props.onEntered(e.node, n);
                        });
                      });
                  }))
                : this.safeSetState({ status: _ }, function () {
                    e.props.onEntered && e.props.onEntered(e.node, n);
                  });
            }),
            (t.performExit = function () {
              var n = this,
                e = this.props.exit,
                t = this.getTimeouts();
              e
                ? (this.props.onExit && this.props.onExit(this.node),
                  this.safeSetState({ status: q }, function () {
                    n.props.onExiting && n.props.onExiting(n.node),
                      n.onTransitionEnd(t.exit, function () {
                        n.safeSetState({ status: H }, function () {
                          n.props.onExited && n.props.onExited(n.node);
                        });
                      });
                  }))
                : this.safeSetState({ status: H }, function () {
                    n.props.onExited && n.props.onExited(n.node);
                  });
            }),
            (t.cancelNextCallback = function () {
              null !== this.nextCallback &&
                this.nextCallback.cancel &&
                (this.nextCallback.cancel(), (this.nextCallback = null));
            }),
            (t.safeSetState = function (n, e) {
              (e = this.setNextCallback(e)), this.setState(n, e);
            }),
            (t.setNextCallback = function (n) {
              var e = this,
                t = !0;
              return (
                (this.nextCallback = function () {
                  t && ((t = !1), (e.nextCallback = null), n());
                }),
                (this.nextCallback.cancel = function () {
                  t = !1;
                }),
                this.nextCallback
              );
            }),
            (t.onTransitionEnd = function (n, e) {
              this.setNextCallback(e);
              var t = null == n && !this.props.addEndListener;
              !this.node || t
                ? setTimeout(this.nextCallback, 0)
                : (this.props.addEndListener &&
                    this.props.addEndListener(this.node, this.nextCallback),
                  null != n && setTimeout(this.nextCallback, n));
            }),
            (t.render = function () {
              var n = this.state.status;
              if (n === j) return null;
              var e = this.props;
              return (0, e.children)(
                n,
                C(e, [
                  "children",
                  "in",
                  "mountOnEnter",
                  "unmountOnExit",
                  "appear",
                  "enter",
                  "exit",
                  "timeout",
                  "addEndListener",
                  "onEnter",
                  "onEntering",
                  "onEntered",
                  "onExit",
                  "onExiting",
                  "onExited",
                  "nodeRef",
                ])
              );
            }),
            y(e, [
              {
                key: "node",
                get: function () {
                  var n,
                    e = null == (n = this.props.nodeRef) ? void 0 : n.current;
                  if (!e)
                    throw Error(
                      "notistack - Custom snackbar is not refForwarding"
                    );
                  return e;
                },
              },
            ]),
            e
          );
        })(c.Component);
      function I() {}
      function V(n, e) {
        "function" == typeof n ? n(e) : n && (n.current = e);
      }
      function z(n, e) {
        return (0, c.useMemo)(
          function () {
            return null == n && null == e
              ? null
              : function (t) {
                  V(n, t), V(e, t);
                };
          },
          [n, e]
        );
      }
      function W(n) {
        var e = n.timeout,
          t = n.style,
          r = void 0 === t ? {} : t,
          i = n.mode;
        return {
          duration: "object" == typeof e ? e[i] || 0 : e,
          easing: r.transitionTimingFunction,
          delay: r.transitionDelay,
        };
      }
      A.defaultProps = {
        in: !1,
        mountOnEnter: !1,
        unmountOnExit: !1,
        appear: !1,
        enter: !0,
        exit: !0,
        onEnter: I,
        onEntering: I,
        onEntered: I,
        onExit: I,
        onExiting: I,
        onExited: I,
      };
      var B = function (n) {
          n.scrollTop = n.scrollTop;
        },
        F = function (n) {
          return Math.round(n) + "ms";
        };
      function Z(n, e) {
        void 0 === n && (n = ["all"]);
        var t = e || {},
          r = t.duration,
          i = void 0 === r ? 300 : r,
          o = t.easing,
          a = void 0 === o ? "cubic-bezier(0.4, 0, 0.2, 1)" : o,
          s = t.delay,
          u = void 0 === s ? 0 : s;
        return (Array.isArray(n) ? n : [n])
          .map(function (n) {
            return (
              n +
              " " +
              ("string" == typeof i ? i : F(i)) +
              " " +
              a +
              " " +
              ("string" == typeof u ? u : F(u))
            );
          })
          .join(",");
      }
      function X(n) {
        return ((n && n.ownerDocument) || document).defaultView || window;
      }
      function Q(n, e) {
        if (e) {
          var t = (function (n, e) {
            var t,
              r = e.getBoundingClientRect(),
              i = X(e);
            if (e.fakeTransform) t = e.fakeTransform;
            else {
              var o = i.getComputedStyle(e);
              t =
                o.getPropertyValue("-webkit-transform") ||
                o.getPropertyValue("transform");
            }
            var a = 0,
              s = 0;
            if (t && "none" !== t && "string" == typeof t) {
              var u = t.split("(")[1].split(")")[0].split(",");
              (a = parseInt(u[4], 10)), (s = parseInt(u[5], 10));
            }
            switch (n) {
              case "left":
                return "translateX(" + (i.innerWidth + a - r.left) + "px)";
              case "right":
                return "translateX(-" + (r.left + r.width - a) + "px)";
              case "up":
                return "translateY(" + (i.innerHeight + s - r.top) + "px)";
              default:
                return "translateY(-" + (r.top + r.height - s) + "px)";
            }
          })(n, e);
          t && ((e.style.webkitTransform = t), (e.style.transform = t));
        }
      }
      var U = (0, c.forwardRef)(function (n, e) {
        var t = n.children,
          r = n.direction,
          i = void 0 === r ? "down" : r,
          o = n.in,
          a = n.style,
          s = n.timeout,
          u = void 0 === s ? 0 : s,
          l = n.onEnter,
          d = n.onEntered,
          f = n.onExit,
          p = n.onExited,
          m = C(n, [
            "children",
            "direction",
            "in",
            "style",
            "timeout",
            "onEnter",
            "onEntered",
            "onExit",
            "onExited",
          ]),
          h = (0, c.useRef)(null),
          g = z(t.ref, h),
          v = z(g, e),
          b = (0, c.useCallback)(
            function () {
              h.current && Q(i, h.current);
            },
            [i]
          );
        return (
          (0, c.useEffect)(
            function () {
              if (!o && "down" !== i && "right" !== i) {
                var n = (function (n, e) {
                    var t;
                    function r() {
                      for (
                        var r = this, i = arguments.length, o = Array(i), a = 0;
                        a < i;
                        a++
                      )
                        o[a] = arguments[a];
                      clearTimeout(t),
                        (t = setTimeout(function () {
                          n.apply(r, o);
                        }, e));
                    }
                    return (
                      void 0 === e && (e = 166),
                      (r.clear = function () {
                        clearTimeout(t);
                      }),
                      r
                    );
                  })(function () {
                    h.current && Q(i, h.current);
                  }),
                  e = X(h.current);
                return (
                  e.addEventListener("resize", n),
                  function () {
                    n.clear(), e.removeEventListener("resize", n);
                  }
                );
              }
            },
            [i, o]
          ),
          (0, c.useEffect)(
            function () {
              o || b();
            },
            [o, b]
          ),
          (0, c.createElement)(
            A,
            Object.assign(
              {
                appear: !0,
                nodeRef: h,
                onEnter: function (n, e) {
                  Q(i, n), B(n), l && l(n, e);
                },
                onEntered: d,
                onEntering: function (n) {
                  var e =
                      (null == a ? void 0 : a.transitionTimingFunction) ||
                      "cubic-bezier(0.0, 0, 0.2, 1)",
                    t = W({
                      timeout: u,
                      mode: "enter",
                      style: k({}, a, { transitionTimingFunction: e }),
                    });
                  (n.style.webkitTransition = Z("-webkit-transform", t)),
                    (n.style.transition = Z("transform", t)),
                    (n.style.webkitTransform = "none"),
                    (n.style.transform = "none");
                },
                onExit: function (n) {
                  var e =
                      (null == a ? void 0 : a.transitionTimingFunction) ||
                      "cubic-bezier(0.4, 0, 0.6, 1)",
                    t = W({
                      timeout: u,
                      mode: "exit",
                      style: k({}, a, { transitionTimingFunction: e }),
                    });
                  (n.style.webkitTransition = Z("-webkit-transform", t)),
                    (n.style.transition = Z("transform", t)),
                    Q(i, n),
                    f && f(n);
                },
                onExited: function (n) {
                  (n.style.webkitTransition = ""),
                    (n.style.transition = ""),
                    p && p(n);
                },
                in: o,
                timeout: u,
              },
              m
            ),
            function (n, e) {
              return (0, c.cloneElement)(
                t,
                k(
                  {
                    ref: v,
                    style: k(
                      { visibility: "exited" !== n || o ? void 0 : "hidden" },
                      a,
                      {},
                      t.props.style
                    ),
                  },
                  e
                )
              );
            }
          )
        );
      });
      U.displayName = "Slide";
      var G = function (n) {
          return c.createElement(
            "svg",
            Object.assign(
              {
                viewBox: "0 0 24 24",
                focusable: "false",
                style: {
                  fontSize: 20,
                  marginInlineEnd: 8,
                  userSelect: "none",
                  width: "1em",
                  height: "1em",
                  display: "inline-block",
                  fill: "currentColor",
                  flexShrink: 0,
                },
              },
              n
            )
          );
        },
        Y = {
          maxSnack: 3,
          persist: !1,
          hideIconVariant: !1,
          disableWindowBlurListener: !1,
          variant: "default",
          autoHideDuration: 5e3,
          iconVariant: {
            default: void 0,
            success: c.createElement(function () {
              return c.createElement(
                G,
                null,
                c.createElement("path", {
                  d: "M12 2C6.5 2 2 6.5 2 12S6.5 22 12 22 22 17.5 22 12 17.5 2 12 2M10 17L5 12L6.41\n        10.59L10 14.17L17.59 6.58L19 8L10 17Z",
                })
              );
            }, null),
            warning: c.createElement(function () {
              return c.createElement(
                G,
                null,
                c.createElement("path", {
                  d: "M13,14H11V10H13M13,18H11V16H13M1,21H23L12,2L1,21Z",
                })
              );
            }, null),
            error: c.createElement(function () {
              return c.createElement(
                G,
                null,
                c.createElement("path", {
                  d: "M12,2C17.53,2 22,6.47 22,12C22,17.53 17.53,22 12,22C6.47,22 2,17.53 2,12C2,\n        6.47 6.47,2 12,2M15.59,7L12,10.59L8.41,7L7,8.41L10.59,12L7,15.59L8.41,17L12,\n        13.41L15.59,17L17,15.59L13.41,12L17,8.41L15.59,7Z",
                })
              );
            }, null),
            info: c.createElement(function () {
              return c.createElement(
                G,
                null,
                c.createElement("path", {
                  d: "M13,9H11V7H13M13,17H11V11H13M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,\n        0 22,12A10,10 0 0,0 12,2Z",
                })
              );
            }, null),
          },
          anchorOrigin: { vertical: "bottom", horizontal: "left" },
          TransitionComponent: U,
          transitionDuration: { enter: 225, exit: 195 },
        },
        K = function (n, e) {
          var t = function (n) {
            return "number" == typeof n || null === n;
          };
          return t(n) ? n : t(e) ? e : Y.autoHideDuration;
        },
        $ = function (n, e) {
          var t = function (n, e) {
            return e.some(function (e) {
              return typeof n === e;
            });
          };
          return t(n, ["string", "number"])
            ? n
            : t(n, ["object"])
            ? k({}, Y.transitionDuration, {}, t(e, ["object"]) && e, {}, n)
            : t(e, ["string", "number"])
            ? e
            : t(e, ["object"])
            ? k({}, Y.transitionDuration, {}, e)
            : Y.transitionDuration;
        };
      function J(n) {
        return Object.entries(n).reduce(function (n, e) {
          var t,
            r = e[0],
            i = e[1];
          return k({}, n, (((t = {})[r] = E(i)), t));
        }, {});
      }
      var nn = "notistack-CollapseWrapper",
        ne = J({ root: { height: 0 }, entered: { height: "auto" } }),
        nt = (0, c.forwardRef)(function (n, e) {
          var t = n.children,
            r = n.in,
            i = n.onExited,
            o = (0, c.useRef)(null),
            a = (0, c.useRef)(null),
            s = z(e, a),
            u = function () {
              return o.current ? o.current.clientHeight : 0;
            };
          return (0, c.createElement)(
            A,
            {
              in: r,
              unmountOnExit: !0,
              onEnter: function (n) {
                n.style.height = "0px";
              },
              onEntered: function (n) {
                n.style.height = "auto";
              },
              onEntering: function (n) {
                var e = u(),
                  t = W({ timeout: 175, mode: "enter" }),
                  r = t.duration,
                  i = t.easing;
                (n.style.transitionDuration =
                  "string" == typeof r ? r : r + "ms"),
                  (n.style.height = e + "px"),
                  (n.style.transitionTimingFunction = i || "");
              },
              onExit: function (n) {
                n.style.height = u() + "px";
              },
              onExited: i,
              onExiting: function (n) {
                B(n);
                var e = W({ timeout: 175, mode: "exit" }),
                  t = e.duration,
                  r = e.easing;
                (n.style.transitionDuration =
                  "string" == typeof t ? t : t + "ms"),
                  (n.style.height = "0px"),
                  (n.style.transitionTimingFunction = r || "");
              },
              nodeRef: a,
              timeout: 175,
            },
            function (n, e) {
              return (0, c.createElement)(
                "div",
                Object.assign(
                  {
                    ref: s,
                    className: d(ne.root, "entered" === n && ne.entered),
                    style: k(
                      {
                        pointerEvents: "all",
                        overflow: "hidden",
                        minHeight: "0px",
                        transition: Z("height"),
                      },
                      "entered" === n && { overflow: "visible" },
                      {},
                      "exited" === n && !r && { visibility: "hidden" }
                    ),
                  },
                  e
                ),
                (0, c.createElement)(
                  "div",
                  {
                    ref: o,
                    className: nn,
                    style: { display: "flex", width: "100%" },
                  },
                  t
                )
              );
            }
          );
        });
      nt.displayName = "Collapse";
      var nr = { right: "left", left: "right", bottom: "up", top: "down" },
        ni = function (n) {
          void 0 === n && (n = {});
          var e = {
            containerRoot: !0,
            containerAnchorOriginTopCenter: !0,
            containerAnchorOriginBottomCenter: !0,
            containerAnchorOriginTopRight: !0,
            containerAnchorOriginBottomRight: !0,
            containerAnchorOriginTopLeft: !0,
            containerAnchorOriginBottomLeft: !0,
          };
          return Object.keys(n)
            .filter(function (n) {
              return !e[n];
            })
            .reduce(function (e, t) {
              var r;
              return k({}, e, (((r = {})[t] = n[t]), r));
            }, {});
        },
        no = function () {};
      function na(n, e) {
        return n.reduce(function (n, t) {
          return null == t
            ? n
            : function () {
                for (var r = arguments.length, i = Array(r), o = 0; o < r; o++)
                  i[o] = arguments[o];
                var a = [].concat(i);
                e && -1 === a.indexOf(e) && a.push(e),
                  n.apply(this, a),
                  t.apply(this, a);
              };
        }, no);
      }
      var ns = "u" > typeof window ? c.useLayoutEffect : c.useEffect;
      function nu(n) {
        var e = (0, c.useRef)(n);
        return (
          ns(function () {
            e.current = n;
          }),
          (0, c.useCallback)(function () {
            return e.current.apply(void 0, arguments);
          }, [])
        );
      }
      var nc = (0, c.forwardRef)(function (n, e) {
        var t = n.children,
          r = n.className,
          i = n.autoHideDuration,
          o = n.disableWindowBlurListener,
          a = void 0 !== o && o,
          s = n.onClose,
          u = n.id,
          l = n.open,
          f = n.SnackbarProps,
          p = void 0 === f ? {} : f,
          m = (0, c.useRef)(),
          h = nu(function () {
            s && s.apply(void 0, arguments);
          }),
          g = nu(function (n) {
            s &&
              null != n &&
              (m.current && clearTimeout(m.current),
              (m.current = setTimeout(function () {
                h(null, "timeout", u);
              }, n)));
          });
        (0, c.useEffect)(
          function () {
            return (
              l && g(i),
              function () {
                m.current && clearTimeout(m.current);
              }
            );
          },
          [l, i, g]
        );
        var v = function () {
            m.current && clearTimeout(m.current);
          },
          b = (0, c.useCallback)(
            function () {
              null != i && g(0.5 * i);
            },
            [i, g]
          );
        return (
          (0, c.useEffect)(
            function () {
              if (!a && l)
                return (
                  window.addEventListener("focus", b),
                  window.addEventListener("blur", v),
                  function () {
                    window.removeEventListener("focus", b),
                      window.removeEventListener("blur", v);
                  }
                );
            },
            [a, b, l]
          ),
          (0, c.createElement)(
            "div",
            Object.assign({ ref: e }, p, {
              className: d("notistack-Snackbar", r),
              onMouseEnter: function (n) {
                p.onMouseEnter && p.onMouseEnter(n), v();
              },
              onMouseLeave: function (n) {
                p.onMouseLeave && p.onMouseLeave(n), b();
              },
            }),
            t
          )
        );
      });
      nc.displayName = "Snackbar";
      var nl = J({
          root:
            (((r = { display: "flex", flexWrap: "wrap", flexGrow: 1 })[D] = {
              flexGrow: "initial",
              minWidth: "288px",
            }),
            r),
        }),
        nd = (0, c.forwardRef)(function (n, e) {
          var t = n.className,
            r = C(n, ["className"]);
          return c.createElement(
            "div",
            Object.assign({ ref: e, className: d(nl.root, t) }, r)
          );
        });
      nd.displayName = "SnackbarContent";
      var nf = J({
          root: {
            backgroundColor: "#313131",
            fontSize: "0.875rem",
            lineHeight: 1.43,
            letterSpacing: "0.01071em",
            color: "#fff",
            alignItems: "center",
            padding: "6px 16px",
            borderRadius: "4px",
            boxShadow:
              "0px 3px 5px -1px rgba(0,0,0,0.2),0px 6px 10px 0px rgba(0,0,0,0.14),0px 1px 18px 0px rgba(0,0,0,0.12)",
          },
          lessPadding: { paddingLeft: "20px" },
          default: { backgroundColor: "#313131" },
          success: { backgroundColor: "#43a047" },
          error: { backgroundColor: "#d32f2f" },
          warning: { backgroundColor: "#ff9800" },
          info: { backgroundColor: "#2196f3" },
          message: { display: "flex", alignItems: "center", padding: "8px 0" },
          action: {
            display: "flex",
            alignItems: "center",
            marginLeft: "auto",
            paddingLeft: "16px",
            marginRight: "-8px",
          },
        }),
        np = "notistack-snackbar",
        nm = (0, c.forwardRef)(function (n, e) {
          var t = n.id,
            r = n.message,
            i = n.action,
            o = n.iconVariant,
            a = n.variant,
            s = n.hideIconVariant,
            u = n.style,
            l = n.className,
            f = o[a],
            p = i;
          return (
            "function" == typeof p && (p = p(t)),
            c.createElement(
              nd,
              {
                ref: e,
                role: "alert",
                "aria-describedby": np,
                style: u,
                className: d(
                  "notistack-MuiContent",
                  "notistack-MuiContent-" + a,
                  nf.root,
                  nf[a],
                  l,
                  !s && f && nf.lessPadding
                ),
              },
              c.createElement(
                "div",
                { id: np, className: nf.message },
                s ? null : f,
                r
              ),
              p && c.createElement("div", { className: nf.action }, p)
            )
          );
        });
      nm.displayName = "MaterialDesignContent";
      var nh = (0, c.memo)(nm),
        ng = J({
          wrappedRoot: {
            width: "100%",
            position: "relative",
            transform: "translateX(0)",
            top: 0,
            right: 0,
            bottom: 0,
            left: 0,
            minWidth: "288px",
          },
        }),
        nv = function (n) {
          var e,
            t = (0, c.useRef)(),
            r = (0, c.useState)(!0),
            i = r[0],
            o = r[1],
            a = na([n.snack.onClose, n.onClose]),
            s = (0, c.useCallback)(function () {
              t.current = setTimeout(function () {
                o(function (n) {
                  return !n;
                });
              }, 125);
            }, []);
          (0, c.useEffect)(function () {
            return function () {
              t.current && clearTimeout(t.current);
            };
          }, []);
          var u = n.snack,
            l = n.classes,
            f = n.Component,
            p = (0, c.useMemo)(
              function () {
                return ni(l);
              },
              [l]
            ),
            m = u.open,
            h = u.SnackbarProps,
            g = u.TransitionComponent,
            v = u.TransitionProps,
            b = u.transitionDuration,
            E = u.disableWindowBlurListener,
            x = u.content,
            y = C(u, [
              "open",
              "SnackbarProps",
              "TransitionComponent",
              "TransitionProps",
              "transitionDuration",
              "disableWindowBlurListener",
              "content",
              "entered",
              "requestClose",
              "onEnter",
              "onEntered",
              "onExit",
              "onExited",
            ]),
            w = k(
              {
                direction:
                  "center" !== (e = y.anchorOrigin).horizontal
                    ? nr[e.horizontal]
                    : nr[e.vertical],
                timeout: b,
              },
              v
            ),
            S = x;
          "function" == typeof S && (S = S(y.id, y.message));
          var O = ["onEnter", "onEntered", "onExit", "onExited"].reduce(
            function (e, t) {
              var r;
              return k(
                {},
                e,
                (((r = {})[t] = na([n.snack[t], n[t]], y.id)), r)
              );
            },
            {}
          );
          return c.createElement(
            nt,
            { in: i, onExited: O.onExited },
            c.createElement(
              nc,
              {
                open: m,
                id: y.id,
                disableWindowBlurListener: E,
                autoHideDuration: y.autoHideDuration,
                className: d(
                  ng.wrappedRoot,
                  p.root,
                  p["anchorOrigin" + R(y.anchorOrigin)]
                ),
                SnackbarProps: h,
                onClose: a,
              },
              c.createElement(
                g,
                Object.assign({}, w, {
                  appear: !0,
                  in: m,
                  onExit: O.onExit,
                  onExited: s,
                  onEnter: O.onEnter,
                  onEntered: na(
                    [
                      O.onEntered,
                      function () {
                        n.snack.requestClose &&
                          a(null, "instructed", n.snack.id);
                      },
                    ],
                    y.id
                  ),
                }),
                S ||
                  c.createElement(void 0 === f ? nh : f, Object.assign({}, y))
              )
            )
          );
        },
        nb = 20,
        nE = 6,
        nx = 2,
        ny = "." + nn,
        nk = J({
          root:
            (((i = {
              boxSizing: "border-box",
              display: "flex",
              maxHeight: "100%",
              position: "fixed",
              zIndex: 1400,
              height: "auto",
              width: "auto",
              transition: Z(["top", "right", "bottom", "left", "max-width"], {
                duration: 300,
                easing: "ease",
              }),
              pointerEvents: "none",
            })[ny] = {
              padding: nE + "px 0px",
              transition: "padding 300ms ease 0ms",
            }),
            (i.maxWidth = "calc(100% - " + 2 * nb + "px)"),
            (i[L] = { width: "100%", maxWidth: "calc(100% - 32px)" }),
            i),
          rootDense: (((o = {})[ny] = { padding: nx + "px 0px" }), o),
          top: { top: nb - nE + "px", flexDirection: "column" },
          bottom: { bottom: nb - nE + "px", flexDirection: "column-reverse" },
          left:
            (((a = { left: nb + "px" })[D] = { alignItems: "flex-start" }),
            (a[L] = { left: "16px" }),
            a),
          right:
            (((s = { right: nb + "px" })[D] = { alignItems: "flex-end" }),
            (s[L] = { right: "16px" }),
            s),
          center:
            (((u = { left: "50%", transform: "translateX(-50%)" })[D] = {
              alignItems: "center",
            }),
            u),
        }),
        nw = (0, c.memo)(function (n) {
          var e = n.classes,
            t = void 0 === e ? {} : e,
            r = n.anchorOrigin,
            i = n.dense,
            o = n.children,
            a = d(
              "notistack-SnackbarContainer",
              nk[r.vertical],
              nk[r.horizontal],
              nk.root,
              t.containerRoot,
              t["containerAnchorOrigin" + R(r)],
              i && nk.rootDense
            );
          return c.createElement("div", { className: a }, o);
        }),
        nC = function (n) {
          return !("string" == typeof n || (0, c.isValidElement)(n));
        },
        nS = (function (n) {
          function e(e) {
            var t;
            return (
              ((t = n.call(this, e) || this).enqueueSnackbar = function (n, e) {
                if ((void 0 === e && (e = {}), null == n))
                  throw Error("enqueueSnackbar called with invalid argument");
                var r,
                  i = nC(n) ? n : e,
                  o = nC(n) ? n.message : n,
                  a = i.key,
                  s = i.preventDuplicate,
                  u = C(i, ["key", "preventDuplicate"]),
                  c = N(a),
                  l = c ? a : new Date().getTime() + Math.random(),
                  f =
                    ((r = t.props),
                    function (n, e) {
                      return (void 0 === e && (e = !1), e)
                        ? k({}, Y[n], {}, r[n], {}, u[n])
                        : "autoHideDuration" === n
                        ? K(u.autoHideDuration, r.autoHideDuration)
                        : "transitionDuration" === n
                        ? $(u.transitionDuration, r.transitionDuration)
                        : u[n] || r[n] || Y[n];
                    }),
                  p = k({ id: l }, u, {
                    message: o,
                    open: !0,
                    entered: !1,
                    requestClose: !1,
                    persist: f("persist"),
                    action: f("action"),
                    content: f("content"),
                    variant: f("variant"),
                    anchorOrigin: f("anchorOrigin"),
                    disableWindowBlurListener: f("disableWindowBlurListener"),
                    autoHideDuration: f("autoHideDuration"),
                    hideIconVariant: f("hideIconVariant"),
                    TransitionComponent: f("TransitionComponent"),
                    transitionDuration: f("transitionDuration"),
                    TransitionProps: f("TransitionProps", !0),
                    iconVariant: f("iconVariant", !0),
                    style: f("style", !0),
                    SnackbarProps: f("SnackbarProps", !0),
                    className: d(t.props.className, u.className),
                  });
                return (
                  p.persist && (p.autoHideDuration = void 0),
                  t.setState(function (n) {
                    if ((void 0 === s && t.props.preventDuplicate) || s) {
                      var e = function (n) {
                          return c ? n.id === l : n.message === o;
                        },
                        r = n.queue.findIndex(e) > -1,
                        i = n.snacks.findIndex(e) > -1;
                      if (r || i) return n;
                    }
                    return t.handleDisplaySnack(
                      k({}, n, { queue: [].concat(n.queue, [p]) })
                    );
                  }),
                  l
                );
              }),
              (t.handleDisplaySnack = function (n) {
                return n.snacks.length >= t.maxSnack
                  ? t.handleDismissOldest(n)
                  : t.processQueue(n);
              }),
              (t.processQueue = function (n) {
                var e = n.queue,
                  t = n.snacks;
                return e.length > 0
                  ? k({}, n, {
                      snacks: [].concat(t, [e[0]]),
                      queue: e.slice(1, e.length),
                    })
                  : n;
              }),
              (t.handleDismissOldest = function (n) {
                if (
                  n.snacks.some(function (n) {
                    return !n.open || n.requestClose;
                  })
                )
                  return n;
                var e = !1,
                  r = !1;
                n.snacks.reduce(function (n, e) {
                  return n + (e.open && e.persist ? 1 : 0);
                }, 0) === t.maxSnack && (r = !0);
                var i = n.snacks.map(function (n) {
                  return e || (n.persist && !r)
                    ? k({}, n)
                    : ((e = !0), n.entered)
                    ? (n.onClose && n.onClose(null, "maxsnack", n.id),
                      t.props.onClose &&
                        t.props.onClose(null, "maxsnack", n.id),
                      k({}, n, { open: !1 }))
                    : k({}, n, { requestClose: !0 });
                });
                return k({}, n, { snacks: i });
              }),
              (t.handleEnteredSnack = function (n, e, r) {
                if (!N(r))
                  throw Error(
                    "handleEnteredSnack Cannot be called with undefined key"
                  );
                t.setState(function (n) {
                  return {
                    snacks: n.snacks.map(function (n) {
                      return n.id === r ? k({}, n, { entered: !0 }) : k({}, n);
                    }),
                  };
                });
              }),
              (t.handleCloseSnack = function (n, e, r) {
                t.props.onClose && t.props.onClose(n, e, r);
                var i = void 0 === r;
                t.setState(function (n) {
                  var e = n.snacks,
                    t = n.queue;
                  return {
                    snacks: e.map(function (n) {
                      return i || n.id === r
                        ? n.entered
                          ? k({}, n, { open: !1 })
                          : k({}, n, { requestClose: !0 })
                        : k({}, n);
                    }),
                    queue: t.filter(function (n) {
                      return n.id !== r;
                    }),
                  };
                });
              }),
              (t.closeSnackbar = function (n) {
                var e = t.state.snacks.find(function (e) {
                  return e.id === n;
                });
                N(n) && e && e.onClose && e.onClose(null, "instructed", n),
                  t.handleCloseSnack(null, "instructed", n);
              }),
              (t.handleExitedSnack = function (n, e) {
                if (!N(e))
                  throw Error(
                    "handleExitedSnack Cannot be called with undefined key"
                  );
                t.setState(function (n) {
                  var r = t.processQueue(
                    k({}, n, {
                      snacks: n.snacks.filter(function (n) {
                        return n.id !== e;
                      }),
                    })
                  );
                  return 0 === r.queue.length ? r : t.handleDismissOldest(r);
                });
              }),
              t.enqueueSnackbar,
              t.closeSnackbar,
              (t.state = {
                snacks: [],
                queue: [],
                contextValue: {
                  enqueueSnackbar: t.enqueueSnackbar.bind(S(t)),
                  closeSnackbar: t.closeSnackbar.bind(S(t)),
                },
              }),
              t
            );
          }
          return (
            w(e, n),
            (e.prototype.render = function () {
              var n = this,
                e = this.state.contextValue,
                t = this.props,
                r = t.domRoot,
                i = t.children,
                o = t.dense,
                a = void 0 !== o && o,
                s = t.Components,
                u = void 0 === s ? {} : s,
                d = t.classes,
                f = this.state.snacks.reduce(function (n, e) {
                  var t,
                    r = R(e.anchorOrigin),
                    i = n[r] || [];
                  return k({}, n, (((t = {})[r] = [].concat(i, [e])), t));
                }, {}),
                p = Object.keys(f).map(function (e) {
                  var t = f[e],
                    r = t[0];
                  return c.createElement(
                    nw,
                    {
                      key: e,
                      dense: a,
                      anchorOrigin: r.anchorOrigin,
                      classes: d,
                    },
                    t.map(function (e) {
                      return c.createElement(nv, {
                        key: e.id,
                        snack: e,
                        classes: d,
                        Component: u[e.variant],
                        onClose: n.handleCloseSnack,
                        onEnter: n.props.onEnter,
                        onExit: n.props.onExit,
                        onExited: na(
                          [n.handleExitedSnack, n.props.onExited],
                          e.id
                        ),
                        onEntered: na(
                          [n.handleEnteredSnack, n.props.onEntered],
                          e.id
                        ),
                      });
                    })
                  );
                });
              return c.createElement(
                T.Provider,
                { value: e },
                i,
                r ? (0, l.createPortal)(p, r) : p
              );
            }),
            y(e, [
              {
                key: "maxSnack",
                get: function () {
                  return this.props.maxSnack || Y.maxSnack;
                },
              },
            ]),
            e
          );
        })(c.Component),
        nO = function () {
          return (0, c.useContext)(T);
        };
    },
    80638: (n, e, t) => {
      t.d(e, { A: () => o });
      var r = t(55729);
      function i() {
        return (i =
          Object.assign ||
          function (n) {
            for (var e = 1; e < arguments.length; e++) {
              var t = arguments[e];
              for (var r in t)
                Object.prototype.hasOwnProperty.call(t, r) && (n[r] = t[r]);
            }
            return n;
          }).apply(this, arguments);
      }
      let o = function (n, e) {
        void 0 === e && (e = {});
        var o = e,
          a = o.volume,
          s = void 0 === a ? 1 : a,
          u = o.playbackRate,
          c = void 0 === u ? 1 : u,
          l = o.soundEnabled,
          d = void 0 === l || l,
          f = o.interrupt,
          p = void 0 !== f && f,
          m = o.onload,
          h = (function (n, e) {
            if (null == n) return {};
            var t,
              r,
              i = {},
              o = Object.keys(n);
            for (r = 0; r < o.length; r++)
              e.indexOf((t = o[r])) >= 0 || (i[t] = n[t]);
            return i;
          })(o, [
            "volume",
            "playbackRate",
            "soundEnabled",
            "interrupt",
            "onload",
          ]),
          g = r.useRef(null),
          v = r.useRef(!1),
          b = r.useState(!1),
          E = b[0],
          x = b[1],
          y = r.useState(null),
          k = y[0],
          w = y[1],
          C = r.useState(null),
          S = C[0],
          O = C[1],
          T = function () {
            "function" == typeof m && m.call(this),
              v.current && w(1e3 * this.duration());
          };
        (0, r.useEffect)(function () {
          return (
            t
              .e(44281)
              .then(t.t.bind(t, 44281, 23))
              .then(function (e) {
                v.current ||
                  ((g.current = e.Howl),
                  (v.current = !0),
                  O(
                    new g.current(
                      i({ src: [n], volume: s, rate: c, onload: T }, h)
                    )
                  ));
              }),
            function () {
              v.current = !1;
            }
          );
        }, []),
          r.useEffect(
            function () {
              g.current &&
                S &&
                O(new g.current(i({ src: [n], volume: s, onload: T }, h)));
            },
            [n]
          ),
          r.useEffect(
            function () {
              S && (S.volume(s), S.rate(c));
            },
            [s, c]
          );
        var L = r.useCallback(
            function (n) {
              void 0 === n && (n = {}),
                S &&
                  (d || n.forceSoundEnabled) &&
                  (p && S.stop(),
                  n.playbackRate && S.rate(n.playbackRate),
                  S.play(n.id),
                  v.current &&
                    S.once("end", function () {
                      S.playing() || x(!1);
                    }),
                  v.current && x(!0));
            },
            [S, d, p]
          ),
          D = r.useCallback(
            function (n) {
              S && (S.stop(n), v.current && x(!1));
            },
            [S]
          ),
          M = r.useCallback(
            function (n) {
              S && (S.pause(n), v.current && x(!1));
            },
            [S]
          );
        return [L, { sound: S, stop: D, pause: M, isPlaying: E, duration: k }];
      };
    },
  },
]);
