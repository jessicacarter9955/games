!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var i = arguments[t];
          if (null != i) for (var n in i) i.hasOwnProperty(n) && (e[n] = i[n]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "9359a7d4-ce11-4c12-98a2-0c02d9ae622e"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-9359a7d4-ce11-4c12-98a2-0c02d9ae622e"));
  } catch (e) {}
})();
("use strict");
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [9690],
  {
    7078: (e, t, i) => {
      i.d(t, { g: () => s });
      var n = i(49331);
      let r = /\r\n|[\n\r]/g;
      function s(e, t) {
        let i = 0,
          s = 1;
        for (let o of e.body.matchAll(r)) {
          if (("number" == typeof o.index || (0, n.V)(!1), o.index >= t)) break;
          (i = o.index + o[0].length), (s += 1);
        }
        return { line: s, column: t + 1 - i };
      }
    },
    9690: (e, t, i) => {
      i.d(t, {
        qg: () => u,
        u8: () => E,
        Ng: () => T,
        Mb: () => f,
        $x: () => d,
      });
      var n = i(98136),
        r = i(19723),
        s = i(90809),
        o = i(45858),
        a = i(14693),
        h = i(84896),
        l = i(12754);
      class c {
        line = 1;
        lineStart = 0;
        constructor(e) {
          const t = new r.ou(l.Y.SOF, 0, 0, 0, 0);
          (this.source = e), (this.lastToken = t), (this.token = t);
        }
        get [Symbol.toStringTag]() {
          return "SchemaCoordinateLexer";
        }
        advance() {
          return (this.lastToken = this.token), (this.token = this.lookahead());
        }
        lookahead() {
          let e = this.token;
          if (e.kind !== l.Y.EOF) {
            let t = (function (e, t) {
              let i = e.source.body,
                r = i.length;
              if (t < r) {
                let r = i.charCodeAt(t);
                switch (r) {
                  case 46:
                    return (0, a.Ey)(e, l.Y.DOT, t, t + 1);
                  case 40:
                    return (0, a.Ey)(e, l.Y.PAREN_L, t, t + 1);
                  case 41:
                    return (0, a.Ey)(e, l.Y.PAREN_R, t, t + 1);
                  case 58:
                    return (0, a.Ey)(e, l.Y.COLON, t, t + 1);
                  case 64:
                    return (0, a.Ey)(e, l.Y.AT, t, t + 1);
                }
                if ((0, h.un)(r)) return (0, a.MQ)(e, t);
                throw (0, n.I)(
                  e.source,
                  t,
                  `Invalid character: ${(0, a.qA)(e, t)}.`
                );
              }
              return (0, a.Ey)(e, l.Y.EOF, r, r);
            })(this, e.end);
            (e.next = t), (t.prev = e), (e = t);
          }
          return e;
        }
      }
      var p = i(42728);
      function u(e, t) {
        let i = new N(e, t),
          n = i.parseDocument();
        return (
          Object.defineProperty(n, "tokenCount", {
            enumerable: !1,
            value: i.tokenCount,
          }),
          n
        );
      }
      function d(e, t) {
        let i = new N(e, t);
        i.expectToken(l.Y.SOF);
        let n = i.parseValueLiteral(!1);
        return i.expectToken(l.Y.EOF), n;
      }
      function E(e, t) {
        let i = new N(e, t);
        i.expectToken(l.Y.SOF);
        let n = i.parseConstValueLiteral();
        return i.expectToken(l.Y.EOF), n;
      }
      function f(e, t) {
        let i = new N(e, t);
        i.expectToken(l.Y.SOF);
        let n = i.parseTypeReference();
        return i.expectToken(l.Y.EOF), n;
      }
      function T(e) {
        let t = new c((0, p._)(e) ? e : new p.k(e)),
          i = new N(e, { lexer: t });
        i.expectToken(l.Y.SOF);
        let n = i.parseSchemaCoordinate();
        return i.expectToken(l.Y.EOF), n;
      }
      class N {
        constructor(e, t = {}) {
          const { lexer: i, ...n } = t;
          if (i) this._lexer = i;
          else {
            const t = (0, p._)(e) ? e : new p.k(e);
            this._lexer = new a.JG(t);
          }
          (this._options = n), (this._tokenCounter = 0);
        }
        get tokenCount() {
          return this._tokenCounter;
        }
        parseName() {
          let e = this.expectToken(l.Y.NAME);
          return this.node(e, { kind: o.b.NAME, value: e.value });
        }
        parseDocument() {
          return this.node(this._lexer.token, {
            kind: o.b.DOCUMENT,
            definitions: this.many(l.Y.SOF, this.parseDefinition, l.Y.EOF),
          });
        }
        parseDefinition() {
          if (this.peek(l.Y.BRACE_L)) return this.parseOperationDefinition();
          let e = this.peekDescription(),
            t = e ? this._lexer.lookahead() : this._lexer.token;
          if (e && t.kind === l.Y.BRACE_L)
            throw (0, n.I)(
              this._lexer.source,
              this._lexer.token.start,
              "Unexpected description, descriptions are not supported on shorthand queries."
            );
          if (t.kind === l.Y.NAME) {
            switch (t.value) {
              case "schema":
                return this.parseSchemaDefinition();
              case "scalar":
                return this.parseScalarTypeDefinition();
              case "type":
                return this.parseObjectTypeDefinition();
              case "interface":
                return this.parseInterfaceTypeDefinition();
              case "union":
                return this.parseUnionTypeDefinition();
              case "enum":
                return this.parseEnumTypeDefinition();
              case "input":
                return this.parseInputObjectTypeDefinition();
              case "directive":
                return this.parseDirectiveDefinition();
            }
            switch (t.value) {
              case "query":
              case "mutation":
              case "subscription":
                return this.parseOperationDefinition();
              case "fragment":
                return this.parseFragmentDefinition();
            }
            if (e)
              throw (0, n.I)(
                this._lexer.source,
                this._lexer.token.start,
                "Unexpected description, only GraphQL definitions support descriptions."
              );
            if ("extend" === t.value) return this.parseTypeSystemExtension();
          }
          throw this.unexpected(t);
        }
        parseOperationDefinition() {
          let e,
            t = this._lexer.token;
          if (this.peek(l.Y.BRACE_L))
            return this.node(t, {
              kind: o.b.OPERATION_DEFINITION,
              operation: r.cE.QUERY,
              description: void 0,
              name: void 0,
              variableDefinitions: [],
              directives: [],
              selectionSet: this.parseSelectionSet(),
            });
          let i = this.parseDescription(),
            n = this.parseOperationType();
          return (
            this.peek(l.Y.NAME) && (e = this.parseName()),
            this.node(t, {
              kind: o.b.OPERATION_DEFINITION,
              operation: n,
              description: i,
              name: e,
              variableDefinitions: this.parseVariableDefinitions(),
              directives: this.parseDirectives(!1),
              selectionSet: this.parseSelectionSet(),
            })
          );
        }
        parseOperationType() {
          let e = this.expectToken(l.Y.NAME);
          switch (e.value) {
            case "query":
              return r.cE.QUERY;
            case "mutation":
              return r.cE.MUTATION;
            case "subscription":
              return r.cE.SUBSCRIPTION;
          }
          throw this.unexpected(e);
        }
        parseVariableDefinitions() {
          return this.optionalMany(
            l.Y.PAREN_L,
            this.parseVariableDefinition,
            l.Y.PAREN_R
          );
        }
        parseVariableDefinition() {
          return this.node(this._lexer.token, {
            kind: o.b.VARIABLE_DEFINITION,
            description: this.parseDescription(),
            variable: this.parseVariable(),
            type: (this.expectToken(l.Y.COLON), this.parseTypeReference()),
            defaultValue: this.expectOptionalToken(l.Y.EQUALS)
              ? this.parseConstValueLiteral()
              : void 0,
            directives: this.parseConstDirectives(),
          });
        }
        parseVariable() {
          let e = this._lexer.token;
          return (
            this.expectToken(l.Y.DOLLAR),
            this.node(e, { kind: o.b.VARIABLE, name: this.parseName() })
          );
        }
        parseSelectionSet() {
          return this.node(this._lexer.token, {
            kind: o.b.SELECTION_SET,
            selections: this.many(
              l.Y.BRACE_L,
              this.parseSelection,
              l.Y.BRACE_R
            ),
          });
        }
        parseSelection() {
          return this.peek(l.Y.SPREAD)
            ? this.parseFragment()
            : this.parseField();
        }
        parseField() {
          let e,
            t,
            i = this._lexer.token,
            n = this.parseName();
          return (
            this.expectOptionalToken(l.Y.COLON)
              ? ((e = n), (t = this.parseName()))
              : (t = n),
            this.node(i, {
              kind: o.b.FIELD,
              alias: e,
              name: t,
              arguments: this.parseArguments(!1),
              directives: this.parseDirectives(!1),
              selectionSet: this.peek(l.Y.BRACE_L)
                ? this.parseSelectionSet()
                : void 0,
            })
          );
        }
        parseArguments(e) {
          let t = e ? this.parseConstArgument : this.parseArgument;
          return this.optionalMany(l.Y.PAREN_L, t, l.Y.PAREN_R);
        }
        parseArgument(e = !1) {
          let t = this._lexer.token,
            i = this.parseName();
          return (
            this.expectToken(l.Y.COLON),
            this.node(t, {
              kind: o.b.ARGUMENT,
              name: i,
              value: this.parseValueLiteral(e),
            })
          );
        }
        parseConstArgument() {
          return this.parseArgument(!0);
        }
        parseFragment() {
          let e = this._lexer.token;
          this.expectToken(l.Y.SPREAD);
          let t = this.expectOptionalKeyword("on");
          return !t && this.peek(l.Y.NAME)
            ? this.node(e, {
                kind: o.b.FRAGMENT_SPREAD,
                name: this.parseFragmentName(),
                directives: this.parseDirectives(!1),
              })
            : this.node(e, {
                kind: o.b.INLINE_FRAGMENT,
                typeCondition: t ? this.parseNamedType() : void 0,
                directives: this.parseDirectives(!1),
                selectionSet: this.parseSelectionSet(),
              });
        }
        parseFragmentDefinition() {
          let e = this._lexer.token,
            t = this.parseDescription();
          return (this.expectKeyword("fragment"),
          !0 === this._options.allowLegacyFragmentVariables)
            ? this.node(e, {
                kind: o.b.FRAGMENT_DEFINITION,
                description: t,
                name: this.parseFragmentName(),
                variableDefinitions: this.parseVariableDefinitions(),
                typeCondition:
                  (this.expectKeyword("on"), this.parseNamedType()),
                directives: this.parseDirectives(!1),
                selectionSet: this.parseSelectionSet(),
              })
            : this.node(e, {
                kind: o.b.FRAGMENT_DEFINITION,
                description: t,
                name: this.parseFragmentName(),
                typeCondition:
                  (this.expectKeyword("on"), this.parseNamedType()),
                directives: this.parseDirectives(!1),
                selectionSet: this.parseSelectionSet(),
              });
        }
        parseFragmentName() {
          if ("on" === this._lexer.token.value) throw this.unexpected();
          return this.parseName();
        }
        parseValueLiteral(e) {
          let t = this._lexer.token;
          switch (t.kind) {
            case l.Y.BRACKET_L:
              return this.parseList(e);
            case l.Y.BRACE_L:
              return this.parseObject(e);
            case l.Y.INT:
              return (
                this.advanceLexer(),
                this.node(t, { kind: o.b.INT, value: t.value })
              );
            case l.Y.FLOAT:
              return (
                this.advanceLexer(),
                this.node(t, { kind: o.b.FLOAT, value: t.value })
              );
            case l.Y.STRING:
            case l.Y.BLOCK_STRING:
              return this.parseStringLiteral();
            case l.Y.NAME:
              switch ((this.advanceLexer(), t.value)) {
                case "true":
                  return this.node(t, { kind: o.b.BOOLEAN, value: !0 });
                case "false":
                  return this.node(t, { kind: o.b.BOOLEAN, value: !1 });
                case "null":
                  return this.node(t, { kind: o.b.NULL });
                default:
                  return this.node(t, { kind: o.b.ENUM, value: t.value });
              }
            case l.Y.DOLLAR:
              if (e) {
                if (
                  (this.expectToken(l.Y.DOLLAR),
                  this._lexer.token.kind === l.Y.NAME)
                ) {
                  let e = this._lexer.token.value;
                  throw (0, n.I)(
                    this._lexer.source,
                    t.start,
                    `Unexpected variable "$${e}" in constant value.`
                  );
                }
                throw this.unexpected(t);
              }
              return this.parseVariable();
            default:
              throw this.unexpected();
          }
        }
        parseConstValueLiteral() {
          return this.parseValueLiteral(!0);
        }
        parseStringLiteral() {
          let e = this._lexer.token;
          return (
            this.advanceLexer(),
            this.node(e, {
              kind: o.b.STRING,
              value: e.value,
              block: e.kind === l.Y.BLOCK_STRING,
            })
          );
        }
        parseList(e) {
          let t = () => this.parseValueLiteral(e);
          return this.node(this._lexer.token, {
            kind: o.b.LIST,
            values: this.any(l.Y.BRACKET_L, t, l.Y.BRACKET_R),
          });
        }
        parseObject(e) {
          let t = () => this.parseObjectField(e);
          return this.node(this._lexer.token, {
            kind: o.b.OBJECT,
            fields: this.any(l.Y.BRACE_L, t, l.Y.BRACE_R),
          });
        }
        parseObjectField(e) {
          let t = this._lexer.token,
            i = this.parseName();
          return (
            this.expectToken(l.Y.COLON),
            this.node(t, {
              kind: o.b.OBJECT_FIELD,
              name: i,
              value: this.parseValueLiteral(e),
            })
          );
        }
        parseDirectives(e) {
          let t = [];
          for (; this.peek(l.Y.AT); ) t.push(this.parseDirective(e));
          return t;
        }
        parseConstDirectives() {
          return this.parseDirectives(!0);
        }
        parseDirective(e) {
          let t = this._lexer.token;
          return (
            this.expectToken(l.Y.AT),
            this.node(t, {
              kind: o.b.DIRECTIVE,
              name: this.parseName(),
              arguments: this.parseArguments(e),
            })
          );
        }
        parseTypeReference() {
          let e,
            t = this._lexer.token;
          if (this.expectOptionalToken(l.Y.BRACKET_L)) {
            let i = this.parseTypeReference();
            this.expectToken(l.Y.BRACKET_R),
              (e = this.node(t, { kind: o.b.LIST_TYPE, type: i }));
          } else e = this.parseNamedType();
          return this.expectOptionalToken(l.Y.BANG)
            ? this.node(t, { kind: o.b.NON_NULL_TYPE, type: e })
            : e;
        }
        parseNamedType() {
          return this.node(this._lexer.token, {
            kind: o.b.NAMED_TYPE,
            name: this.parseName(),
          });
        }
        peekDescription() {
          return this.peek(l.Y.STRING) || this.peek(l.Y.BLOCK_STRING);
        }
        parseDescription() {
          if (this.peekDescription()) return this.parseStringLiteral();
        }
        parseSchemaDefinition() {
          let e = this._lexer.token,
            t = this.parseDescription();
          this.expectKeyword("schema");
          let i = this.parseConstDirectives(),
            n = this.many(
              l.Y.BRACE_L,
              this.parseOperationTypeDefinition,
              l.Y.BRACE_R
            );
          return this.node(e, {
            kind: o.b.SCHEMA_DEFINITION,
            description: t,
            directives: i,
            operationTypes: n,
          });
        }
        parseOperationTypeDefinition() {
          let e = this._lexer.token,
            t = this.parseOperationType();
          this.expectToken(l.Y.COLON);
          let i = this.parseNamedType();
          return this.node(e, {
            kind: o.b.OPERATION_TYPE_DEFINITION,
            operation: t,
            type: i,
          });
        }
        parseScalarTypeDefinition() {
          let e = this._lexer.token,
            t = this.parseDescription();
          this.expectKeyword("scalar");
          let i = this.parseName(),
            n = this.parseConstDirectives();
          return this.node(e, {
            kind: o.b.SCALAR_TYPE_DEFINITION,
            description: t,
            name: i,
            directives: n,
          });
        }
        parseObjectTypeDefinition() {
          let e = this._lexer.token,
            t = this.parseDescription();
          this.expectKeyword("type");
          let i = this.parseName(),
            n = this.parseImplementsInterfaces(),
            r = this.parseConstDirectives(),
            s = this.parseFieldsDefinition();
          return this.node(e, {
            kind: o.b.OBJECT_TYPE_DEFINITION,
            description: t,
            name: i,
            interfaces: n,
            directives: r,
            fields: s,
          });
        }
        parseImplementsInterfaces() {
          return this.expectOptionalKeyword("implements")
            ? this.delimitedMany(l.Y.AMP, this.parseNamedType)
            : [];
        }
        parseFieldsDefinition() {
          return this.optionalMany(
            l.Y.BRACE_L,
            this.parseFieldDefinition,
            l.Y.BRACE_R
          );
        }
        parseFieldDefinition() {
          let e = this._lexer.token,
            t = this.parseDescription(),
            i = this.parseName(),
            n = this.parseArgumentDefs();
          this.expectToken(l.Y.COLON);
          let r = this.parseTypeReference(),
            s = this.parseConstDirectives();
          return this.node(e, {
            kind: o.b.FIELD_DEFINITION,
            description: t,
            name: i,
            arguments: n,
            type: r,
            directives: s,
          });
        }
        parseArgumentDefs() {
          return this.optionalMany(
            l.Y.PAREN_L,
            this.parseInputValueDef,
            l.Y.PAREN_R
          );
        }
        parseInputValueDef() {
          let e,
            t = this._lexer.token,
            i = this.parseDescription(),
            n = this.parseName();
          this.expectToken(l.Y.COLON);
          let r = this.parseTypeReference();
          this.expectOptionalToken(l.Y.EQUALS) &&
            (e = this.parseConstValueLiteral());
          let s = this.parseConstDirectives();
          return this.node(t, {
            kind: o.b.INPUT_VALUE_DEFINITION,
            description: i,
            name: n,
            type: r,
            defaultValue: e,
            directives: s,
          });
        }
        parseInterfaceTypeDefinition() {
          let e = this._lexer.token,
            t = this.parseDescription();
          this.expectKeyword("interface");
          let i = this.parseName(),
            n = this.parseImplementsInterfaces(),
            r = this.parseConstDirectives(),
            s = this.parseFieldsDefinition();
          return this.node(e, {
            kind: o.b.INTERFACE_TYPE_DEFINITION,
            description: t,
            name: i,
            interfaces: n,
            directives: r,
            fields: s,
          });
        }
        parseUnionTypeDefinition() {
          let e = this._lexer.token,
            t = this.parseDescription();
          this.expectKeyword("union");
          let i = this.parseName(),
            n = this.parseConstDirectives(),
            r = this.parseUnionMemberTypes();
          return this.node(e, {
            kind: o.b.UNION_TYPE_DEFINITION,
            description: t,
            name: i,
            directives: n,
            types: r,
          });
        }
        parseUnionMemberTypes() {
          return this.expectOptionalToken(l.Y.EQUALS)
            ? this.delimitedMany(l.Y.PIPE, this.parseNamedType)
            : [];
        }
        parseEnumTypeDefinition() {
          let e = this._lexer.token,
            t = this.parseDescription();
          this.expectKeyword("enum");
          let i = this.parseName(),
            n = this.parseConstDirectives(),
            r = this.parseEnumValuesDefinition();
          return this.node(e, {
            kind: o.b.ENUM_TYPE_DEFINITION,
            description: t,
            name: i,
            directives: n,
            values: r,
          });
        }
        parseEnumValuesDefinition() {
          return this.optionalMany(
            l.Y.BRACE_L,
            this.parseEnumValueDefinition,
            l.Y.BRACE_R
          );
        }
        parseEnumValueDefinition() {
          let e = this._lexer.token,
            t = this.parseDescription(),
            i = this.parseEnumValueName(),
            n = this.parseConstDirectives();
          return this.node(e, {
            kind: o.b.ENUM_VALUE_DEFINITION,
            description: t,
            name: i,
            directives: n,
          });
        }
        parseEnumValueName() {
          if (
            "true" === this._lexer.token.value ||
            "false" === this._lexer.token.value ||
            "null" === this._lexer.token.value
          )
            throw (0, n.I)(
              this._lexer.source,
              this._lexer.token.start,
              `${I(
                this._lexer.token
              )} is reserved and cannot be used for an enum value.`
            );
          return this.parseName();
        }
        parseInputObjectTypeDefinition() {
          let e = this._lexer.token,
            t = this.parseDescription();
          this.expectKeyword("input");
          let i = this.parseName(),
            n = this.parseConstDirectives(),
            r = this.parseInputFieldsDefinition();
          return this.node(e, {
            kind: o.b.INPUT_OBJECT_TYPE_DEFINITION,
            description: t,
            name: i,
            directives: n,
            fields: r,
          });
        }
        parseInputFieldsDefinition() {
          return this.optionalMany(
            l.Y.BRACE_L,
            this.parseInputValueDef,
            l.Y.BRACE_R
          );
        }
        parseTypeSystemExtension() {
          let e = this._lexer.lookahead();
          if (e.kind === l.Y.NAME)
            switch (e.value) {
              case "schema":
                return this.parseSchemaExtension();
              case "scalar":
                return this.parseScalarTypeExtension();
              case "type":
                return this.parseObjectTypeExtension();
              case "interface":
                return this.parseInterfaceTypeExtension();
              case "union":
                return this.parseUnionTypeExtension();
              case "enum":
                return this.parseEnumTypeExtension();
              case "input":
                return this.parseInputObjectTypeExtension();
              case "directive":
                if (this._options.experimentalDirectivesOnDirectiveDefinitions)
                  return this.parseDirectiveDefinitionExtension();
            }
          throw this.unexpected(e);
        }
        parseSchemaExtension() {
          let e = this._lexer.token;
          this.expectKeyword("extend"), this.expectKeyword("schema");
          let t = this.parseConstDirectives(),
            i = this.optionalMany(
              l.Y.BRACE_L,
              this.parseOperationTypeDefinition,
              l.Y.BRACE_R
            );
          if (0 === t.length && 0 === i.length) throw this.unexpected();
          return this.node(e, {
            kind: o.b.SCHEMA_EXTENSION,
            directives: t,
            operationTypes: i,
          });
        }
        parseScalarTypeExtension() {
          let e = this._lexer.token;
          this.expectKeyword("extend"), this.expectKeyword("scalar");
          let t = this.parseName(),
            i = this.parseConstDirectives();
          if (0 === i.length) throw this.unexpected();
          return this.node(e, {
            kind: o.b.SCALAR_TYPE_EXTENSION,
            name: t,
            directives: i,
          });
        }
        parseObjectTypeExtension() {
          let e = this._lexer.token;
          this.expectKeyword("extend"), this.expectKeyword("type");
          let t = this.parseName(),
            i = this.parseImplementsInterfaces(),
            n = this.parseConstDirectives(),
            r = this.parseFieldsDefinition();
          if (0 === i.length && 0 === n.length && 0 === r.length)
            throw this.unexpected();
          return this.node(e, {
            kind: o.b.OBJECT_TYPE_EXTENSION,
            name: t,
            interfaces: i,
            directives: n,
            fields: r,
          });
        }
        parseInterfaceTypeExtension() {
          let e = this._lexer.token;
          this.expectKeyword("extend"), this.expectKeyword("interface");
          let t = this.parseName(),
            i = this.parseImplementsInterfaces(),
            n = this.parseConstDirectives(),
            r = this.parseFieldsDefinition();
          if (0 === i.length && 0 === n.length && 0 === r.length)
            throw this.unexpected();
          return this.node(e, {
            kind: o.b.INTERFACE_TYPE_EXTENSION,
            name: t,
            interfaces: i,
            directives: n,
            fields: r,
          });
        }
        parseUnionTypeExtension() {
          let e = this._lexer.token;
          this.expectKeyword("extend"), this.expectKeyword("union");
          let t = this.parseName(),
            i = this.parseConstDirectives(),
            n = this.parseUnionMemberTypes();
          if (0 === i.length && 0 === n.length) throw this.unexpected();
          return this.node(e, {
            kind: o.b.UNION_TYPE_EXTENSION,
            name: t,
            directives: i,
            types: n,
          });
        }
        parseEnumTypeExtension() {
          let e = this._lexer.token;
          this.expectKeyword("extend"), this.expectKeyword("enum");
          let t = this.parseName(),
            i = this.parseConstDirectives(),
            n = this.parseEnumValuesDefinition();
          if (0 === i.length && 0 === n.length) throw this.unexpected();
          return this.node(e, {
            kind: o.b.ENUM_TYPE_EXTENSION,
            name: t,
            directives: i,
            values: n,
          });
        }
        parseInputObjectTypeExtension() {
          let e = this._lexer.token;
          this.expectKeyword("extend"), this.expectKeyword("input");
          let t = this.parseName(),
            i = this.parseConstDirectives(),
            n = this.parseInputFieldsDefinition();
          if (0 === i.length && 0 === n.length) throw this.unexpected();
          return this.node(e, {
            kind: o.b.INPUT_OBJECT_TYPE_EXTENSION,
            name: t,
            directives: i,
            fields: n,
          });
        }
        parseDirectiveDefinitionExtension() {
          let e = this._lexer.token;
          this.expectKeyword("extend"),
            this.expectKeyword("directive"),
            this.expectToken(l.Y.AT);
          let t = this.parseName(),
            i = this.parseConstDirectives();
          if (0 === i.length) throw this.unexpected();
          return this.node(e, {
            kind: o.b.DIRECTIVE_EXTENSION,
            name: t,
            directives: i,
          });
        }
        parseDirectiveDefinition() {
          let e = this._lexer.token,
            t = this.parseDescription();
          this.expectKeyword("directive"), this.expectToken(l.Y.AT);
          let i = this.parseName(),
            n = this.parseArgumentDefs(),
            r = this._options.experimentalDirectivesOnDirectiveDefinitions
              ? this.parseConstDirectives()
              : [],
            s = this.expectOptionalKeyword("repeatable");
          this.expectKeyword("on");
          let a = this.parseDirectiveLocations();
          return this.node(e, {
            kind: o.b.DIRECTIVE_DEFINITION,
            description: t,
            name: i,
            arguments: n,
            directives: r,
            repeatable: s,
            locations: a,
          });
        }
        parseDirectiveLocations() {
          return this.delimitedMany(l.Y.PIPE, this.parseDirectiveLocation);
        }
        parseDirectiveLocation() {
          let e = this._lexer.token,
            t = this.parseName();
          if (Object.prototype.hasOwnProperty.call(s.H, t.value)) return t;
          throw this.unexpected(e);
        }
        parseSchemaCoordinate() {
          let e,
            t,
            i = this._lexer.token,
            n = this.expectOptionalToken(l.Y.AT),
            r = this.parseName();
          return (!n &&
            this.expectOptionalToken(l.Y.DOT) &&
            (e = this.parseName()),
          (n || e) &&
            this.expectOptionalToken(l.Y.PAREN_L) &&
            ((t = this.parseName()),
            this.expectToken(l.Y.COLON),
            this.expectToken(l.Y.PAREN_R)),
          n)
            ? t
              ? this.node(i, {
                  kind: o.b.DIRECTIVE_ARGUMENT_COORDINATE,
                  name: r,
                  argumentName: t,
                })
              : this.node(i, { kind: o.b.DIRECTIVE_COORDINATE, name: r })
            : e
            ? t
              ? this.node(i, {
                  kind: o.b.ARGUMENT_COORDINATE,
                  name: r,
                  fieldName: e,
                  argumentName: t,
                })
              : this.node(i, {
                  kind: o.b.MEMBER_COORDINATE,
                  name: r,
                  memberName: e,
                })
            : this.node(i, { kind: o.b.TYPE_COORDINATE, name: r });
        }
        node(e, t) {
          return (
            !0 !== this._options.noLocation &&
              (t.loc = new r.aZ(e, this._lexer.lastToken, this._lexer.source)),
            t
          );
        }
        peek(e) {
          return this._lexer.token.kind === e;
        }
        expectToken(e) {
          let t = this._lexer.token;
          if (t.kind === e) return this.advanceLexer(), t;
          throw (0, n.I)(
            this._lexer.source,
            t.start,
            `Expected ${k(e)}, found ${I(t)}.`
          );
        }
        expectOptionalToken(e) {
          return this._lexer.token.kind === e && (this.advanceLexer(), !0);
        }
        expectKeyword(e) {
          let t = this._lexer.token;
          if (t.kind === l.Y.NAME && t.value === e) this.advanceLexer();
          else
            throw (0, n.I)(
              this._lexer.source,
              t.start,
              `Expected "${e}", found ${I(t)}.`
            );
        }
        expectOptionalKeyword(e) {
          let t = this._lexer.token;
          return (
            t.kind === l.Y.NAME && t.value === e && (this.advanceLexer(), !0)
          );
        }
        unexpected(e) {
          let t = null != e ? e : this._lexer.token;
          return (0, n.I)(this._lexer.source, t.start, `Unexpected ${I(t)}.`);
        }
        any(e, t, i) {
          this.expectToken(e);
          let n = [];
          for (; !this.expectOptionalToken(i); ) n.push(t.call(this));
          return n;
        }
        optionalMany(e, t, i) {
          if (this.expectOptionalToken(e)) {
            let e = [];
            do e.push(t.call(this));
            while (!this.expectOptionalToken(i));
            return e;
          }
          return [];
        }
        many(e, t, i) {
          this.expectToken(e);
          let n = [];
          do n.push(t.call(this));
          while (!this.expectOptionalToken(i));
          return n;
        }
        delimitedMany(e, t) {
          this.expectOptionalToken(e);
          let i = [];
          do i.push(t.call(this));
          while (this.expectOptionalToken(e));
          return i;
        }
        advanceLexer() {
          let { maxTokens: e } = this._options,
            t = this._lexer.advance();
          if (
            t.kind !== l.Y.EOF &&
            (++this._tokenCounter, void 0 !== e && this._tokenCounter > e)
          )
            throw (0, n.I)(
              this._lexer.source,
              t.start,
              `Document contains more that ${e} tokens. Parsing aborted.`
            );
        }
      }
      function I(e) {
        let t = e.value;
        return k(e.kind) + (null != t ? ` "${t}"` : "");
      }
      function k(e) {
        return (0, a.Z_)(e) ? `"${e}"` : e;
      }
    },
    12754: (e, t, i) => {
      var n, r;
      i.d(t, { Y: () => n }),
        ((r = n || (n = {})).SOF = "<SOF>"),
        (r.EOF = "<EOF>"),
        (r.BANG = "!"),
        (r.DOLLAR = "$"),
        (r.AMP = "&"),
        (r.PAREN_L = "("),
        (r.PAREN_R = ")"),
        (r.DOT = "."),
        (r.SPREAD = "..."),
        (r.COLON = ":"),
        (r.EQUALS = "="),
        (r.AT = "@"),
        (r.BRACKET_L = "["),
        (r.BRACKET_R = "]"),
        (r.BRACE_L = "{"),
        (r.PIPE = "|"),
        (r.BRACE_R = "}"),
        (r.NAME = "Name"),
        (r.INT = "Int"),
        (r.FLOAT = "Float"),
        (r.STRING = "String"),
        (r.BLOCK_STRING = "BlockString"),
        (r.COMMENT = "Comment");
    },
    14693: (e, t, i) => {
      i.d(t, {
        Ey: () => f,
        JG: () => h,
        MQ: () => k,
        Z_: () => l,
        qA: () => E,
      });
      var n = i(98136),
        r = i(19723),
        s = i(6299),
        o = i(84896),
        a = i(12754);
      class h {
        constructor(e) {
          const t = new r.ou(a.Y.SOF, 0, 0, 0, 0);
          (this.source = e),
            (this.lastToken = t),
            (this.token = t),
            (this.line = 1),
            (this.lineStart = 0);
        }
        get [Symbol.toStringTag]() {
          return "Lexer";
        }
        advance() {
          return (this.lastToken = this.token), (this.token = this.lookahead());
        }
        lookahead() {
          let e = this.token;
          if (e.kind !== a.Y.EOF)
            do
              if (e.next) e = e.next;
              else {
                let t = (function (e, t) {
                  let i = e.source.body,
                    r = i.length,
                    h = t;
                  for (; h < r; ) {
                    let t = i.charCodeAt(h);
                    switch (t) {
                      case 65279:
                      case 9:
                      case 32:
                      case 44:
                        ++h;
                        continue;
                      case 10:
                        ++h, ++e.line, (e.lineStart = h);
                        continue;
                      case 13:
                        10 === i.charCodeAt(h + 1) ? (h += 2) : ++h,
                          ++e.line,
                          (e.lineStart = h);
                        continue;
                      case 35:
                        return (function (e, t) {
                          let i = e.source.body,
                            n = i.length,
                            r = t + 1;
                          for (; r < n; ) {
                            let e = i.charCodeAt(r);
                            if (10 === e || 13 === e) break;
                            if (c(e)) ++r;
                            else if (p(i, r)) r += 2;
                            else break;
                          }
                          return f(e, a.Y.COMMENT, t, r, i.slice(t + 1, r));
                        })(e, h);
                      case 33:
                        return f(e, a.Y.BANG, h, h + 1);
                      case 36:
                        return f(e, a.Y.DOLLAR, h, h + 1);
                      case 38:
                        return f(e, a.Y.AMP, h, h + 1);
                      case 40:
                        return f(e, a.Y.PAREN_L, h, h + 1);
                      case 41:
                        return f(e, a.Y.PAREN_R, h, h + 1);
                      case 46:
                        if (
                          46 === i.charCodeAt(h + 1) &&
                          46 === i.charCodeAt(h + 2)
                        )
                          return f(e, a.Y.SPREAD, h, h + 3);
                        break;
                      case 58:
                        return f(e, a.Y.COLON, h, h + 1);
                      case 61:
                        return f(e, a.Y.EQUALS, h, h + 1);
                      case 64:
                        return f(e, a.Y.AT, h, h + 1);
                      case 91:
                        return f(e, a.Y.BRACKET_L, h, h + 1);
                      case 93:
                        return f(e, a.Y.BRACKET_R, h, h + 1);
                      case 123:
                        return f(e, a.Y.BRACE_L, h, h + 1);
                      case 124:
                        return f(e, a.Y.PIPE, h, h + 1);
                      case 125:
                        return f(e, a.Y.BRACE_R, h, h + 1);
                      case 34:
                        if (
                          34 === i.charCodeAt(h + 1) &&
                          34 === i.charCodeAt(h + 2)
                        )
                          return (function (e, t) {
                            let i = e.source.body,
                              r = i.length,
                              o = e.lineStart,
                              h = t + 3,
                              l = h,
                              u = "",
                              d = [];
                            for (; h < r; ) {
                              let r = i.charCodeAt(h);
                              if (
                                34 === r &&
                                34 === i.charCodeAt(h + 1) &&
                                34 === i.charCodeAt(h + 2)
                              ) {
                                (u += i.slice(l, h)), d.push(u);
                                let n = f(
                                  e,
                                  a.Y.BLOCK_STRING,
                                  t,
                                  h + 3,
                                  (0, s.OC)(d).join("\n")
                                );
                                return (
                                  (e.line += d.length - 1), (e.lineStart = o), n
                                );
                              }
                              if (
                                92 === r &&
                                34 === i.charCodeAt(h + 1) &&
                                34 === i.charCodeAt(h + 2) &&
                                34 === i.charCodeAt(h + 3)
                              ) {
                                (u += i.slice(l, h)), (l = h + 1), (h += 4);
                                continue;
                              }
                              if (10 === r || 13 === r) {
                                (u += i.slice(l, h)),
                                  d.push(u),
                                  13 === r && 10 === i.charCodeAt(h + 1)
                                    ? (h += 2)
                                    : ++h,
                                  (u = ""),
                                  (l = h),
                                  (o = h);
                                continue;
                              }
                              if (c(r)) ++h;
                              else if (p(i, h)) h += 2;
                              else
                                throw (0, n.I)(
                                  e.source,
                                  h,
                                  `Invalid character within String: ${E(e, h)}.`
                                );
                            }
                            throw (0, n.I)(e.source, h, "Unterminated string.");
                          })(e, h);
                        return (function (e, t) {
                          let i = e.source.body,
                            r = i.length,
                            s = t + 1,
                            o = s,
                            h = "";
                          for (; s < r; ) {
                            let r = i.charCodeAt(s);
                            if (34 === r)
                              return (
                                (h += i.slice(o, s)),
                                f(e, a.Y.STRING, t, s + 1, h)
                              );
                            if (92 === r) {
                              h += i.slice(o, s);
                              let t =
                                117 === i.charCodeAt(s + 1)
                                  ? 123 === i.charCodeAt(s + 2)
                                    ? (function (e, t) {
                                        let i = e.source.body,
                                          r = 0,
                                          s = 3;
                                        for (; s < 12; ) {
                                          let e = i.charCodeAt(t + s++);
                                          if (125 === e) {
                                            if (s < 5 || !c(r)) break;
                                            return {
                                              value: String.fromCodePoint(r),
                                              size: s,
                                            };
                                          }
                                          if ((r = (r << 4) | I(e)) < 0) break;
                                        }
                                        throw (0, n.I)(
                                          e.source,
                                          t,
                                          `Invalid Unicode escape sequence: "${i.slice(
                                            t,
                                            t + s
                                          )}".`
                                        );
                                      })(e, s)
                                    : (function (e, t) {
                                        let i = e.source.body,
                                          r = N(i, t + 2);
                                        if (c(r))
                                          return {
                                            value: String.fromCodePoint(r),
                                            size: 6,
                                          };
                                        if (
                                          u(r) &&
                                          92 === i.charCodeAt(t + 6) &&
                                          117 === i.charCodeAt(t + 7)
                                        ) {
                                          let e = N(i, t + 8);
                                          if (d(e))
                                            return {
                                              value: String.fromCodePoint(r, e),
                                              size: 12,
                                            };
                                        }
                                        throw (0, n.I)(
                                          e.source,
                                          t,
                                          `Invalid Unicode escape sequence: "${i.slice(
                                            t,
                                            t + 6
                                          )}".`
                                        );
                                      })(e, s)
                                  : (function (e, t) {
                                      let i = e.source.body;
                                      switch (i.charCodeAt(t + 1)) {
                                        case 34:
                                          return { value: '"', size: 2 };
                                        case 92:
                                          return { value: "\\", size: 2 };
                                        case 47:
                                          return { value: "/", size: 2 };
                                        case 98:
                                          return { value: "\b", size: 2 };
                                        case 102:
                                          return { value: "\f", size: 2 };
                                        case 110:
                                          return { value: "\n", size: 2 };
                                        case 114:
                                          return { value: "\r", size: 2 };
                                        case 116:
                                          return { value: "	", size: 2 };
                                      }
                                      throw (0, n.I)(
                                        e.source,
                                        t,
                                        `Invalid character escape sequence: "${i.slice(
                                          t,
                                          t + 2
                                        )}".`
                                      );
                                    })(e, s);
                              (h += t.value), (s += t.size), (o = s);
                              continue;
                            }
                            if (10 === r || 13 === r) break;
                            if (c(r)) ++s;
                            else if (p(i, s)) s += 2;
                            else
                              throw (0, n.I)(
                                e.source,
                                s,
                                `Invalid character within String: ${E(e, s)}.`
                              );
                          }
                          throw (0, n.I)(e.source, s, "Unterminated string.");
                        })(e, h);
                    }
                    if ((0, o.yp)(t) || 45 === t)
                      return (function (e, t, i) {
                        let r = e.source.body,
                          s = t,
                          h = i,
                          l = !1;
                        if ((45 === h && (h = r.charCodeAt(++s)), 48 === h)) {
                          if (((h = r.charCodeAt(++s)), (0, o.yp)(h)))
                            throw (0, n.I)(
                              e.source,
                              s,
                              `Invalid number, unexpected digit after 0: ${E(
                                e,
                                s
                              )}.`
                            );
                        } else (s = T(e, s, h)), (h = r.charCodeAt(s));
                        if (
                          (46 === h &&
                            ((l = !0),
                            (h = r.charCodeAt(++s)),
                            (s = T(e, s, h)),
                            (h = r.charCodeAt(s))),
                          (69 === h || 101 === h) &&
                            ((l = !0),
                            (43 === (h = r.charCodeAt(++s)) || 45 === h) &&
                              (h = r.charCodeAt(++s)),
                            (s = T(e, s, h)),
                            (h = r.charCodeAt(s))),
                          46 === h || (0, o.un)(h))
                        )
                          throw (0, n.I)(
                            e.source,
                            s,
                            `Invalid number, expected digit but got: ${E(
                              e,
                              s
                            )}.`
                          );
                        return f(
                          e,
                          l ? a.Y.FLOAT : a.Y.INT,
                          t,
                          s,
                          r.slice(t, s)
                        );
                      })(e, h, t);
                    if ((0, o.un)(t)) return k(e, h);
                    throw (0, n.I)(
                      e.source,
                      h,
                      39 === t
                        ? "Unexpected single quote character ('), did you mean to use a double quote (\")?"
                        : c(t) || p(i, h)
                        ? `Unexpected character: ${E(e, h)}.`
                        : `Invalid character: ${E(e, h)}.`
                    );
                  }
                  return f(e, a.Y.EOF, r, r);
                })(this, e.end);
                (e.next = t), (t.prev = e), (e = t);
              }
            while (e.kind === a.Y.COMMENT);
          return e;
        }
      }
      function l(e) {
        return (
          e === a.Y.BANG ||
          e === a.Y.DOLLAR ||
          e === a.Y.AMP ||
          e === a.Y.PAREN_L ||
          e === a.Y.PAREN_R ||
          e === a.Y.DOT ||
          e === a.Y.SPREAD ||
          e === a.Y.COLON ||
          e === a.Y.EQUALS ||
          e === a.Y.AT ||
          e === a.Y.BRACKET_L ||
          e === a.Y.BRACKET_R ||
          e === a.Y.BRACE_L ||
          e === a.Y.PIPE ||
          e === a.Y.BRACE_R
        );
      }
      function c(e) {
        return (e >= 0 && e <= 55295) || (e >= 57344 && e <= 1114111);
      }
      function p(e, t) {
        return u(e.charCodeAt(t)) && d(e.charCodeAt(t + 1));
      }
      function u(e) {
        return e >= 55296 && e <= 56319;
      }
      function d(e) {
        return e >= 56320 && e <= 57343;
      }
      function E(e, t) {
        let i = e.source.body.codePointAt(t);
        if (void 0 === i) return a.Y.EOF;
        if (i >= 32 && i <= 126) {
          let e = String.fromCodePoint(i);
          return '"' === e ? "'\"'" : `"${e}"`;
        }
        return "U+" + i.toString(16).toUpperCase().padStart(4, "0");
      }
      function f(e, t, i, n, s) {
        let o = e.line,
          a = 1 + i - e.lineStart;
        return new r.ou(t, i, n, o, a, s);
      }
      function T(e, t, i) {
        if (!(0, o.yp)(i))
          throw (0, n.I)(
            e.source,
            t,
            `Invalid number, expected digit but got: ${E(e, t)}.`
          );
        let r = e.source.body,
          s = t + 1;
        for (; (0, o.yp)(r.charCodeAt(s)); ) ++s;
        return s;
      }
      function N(e, t) {
        return (
          (I(e.charCodeAt(t)) << 12) |
          (I(e.charCodeAt(t + 1)) << 8) |
          (I(e.charCodeAt(t + 2)) << 4) |
          I(e.charCodeAt(t + 3))
        );
      }
      function I(e) {
        return e >= 48 && e <= 57
          ? e - 48
          : e >= 65 && e <= 70
          ? e - 55
          : e >= 97 && e <= 102
          ? e - 87
          : -1;
      }
      function k(e, t) {
        let i = e.source.body,
          n = i.length,
          r = t + 1;
        for (; r < n; ) {
          let e = i.charCodeAt(r);
          if ((0, o.xr)(e)) ++r;
          else break;
        }
        return f(e, a.Y.NAME, t, r, i.slice(t, r));
      }
    },
    28090: (e, t, i) => {
      i.d(t, { Wk: () => l, eO: () => o, yJ: () => h });
      var n = i(43487),
        r = i(7078),
        s = i(92143);
      class o extends Error {
        constructor(e, ...t) {
          var i, s, h;
          const {
            nodes: l,
            source: c,
            positions: p,
            path: u,
            originalError: d,
            extensions: E,
          } = (function (e) {
            let t = e[0];
            return null == t || "kind" in t || "length" in t
              ? {
                  nodes: t,
                  source: e[1],
                  positions: e[2],
                  path: e[3],
                  originalError: e[4],
                  extensions: e[5],
                }
              : t;
          })(t);
          super(e),
            (this.name = "GraphQLError"),
            (this.path = null != u ? u : void 0),
            (this.originalError = null != d ? d : void 0),
            (this.nodes = a(Array.isArray(l) ? l : l ? [l] : void 0));
          const f = a(
            null == (i = this.nodes)
              ? void 0
              : i.map((e) => e.loc).filter((e) => null != e)
          );
          (this.source =
            null != c
              ? c
              : null == f || null == (s = f[0])
              ? void 0
              : s.source),
            (this.positions =
              null != p ? p : null == f ? void 0 : f.map((e) => e.start)),
            (this.locations =
              p && c
                ? p.map((e) => (0, r.g)(c, e))
                : null == f
                ? void 0
                : f.map((e) => (0, r.g)(e.source, e.start)));
          const T = (0, n.Z)(null == d ? void 0 : d.extensions)
            ? null == d
              ? void 0
              : d.extensions
            : void 0;
          (this.extensions =
            null != (h = null != E ? E : T) ? h : Object.create(null)),
            Object.defineProperties(this, {
              message: { writable: !0, enumerable: !0 },
              name: { enumerable: !1 },
              nodes: { enumerable: !1 },
              source: { enumerable: !1 },
              positions: { enumerable: !1 },
              originalError: { enumerable: !1 },
            }),
            null != d && d.stack
              ? Object.defineProperty(this, "stack", {
                  value: d.stack,
                  writable: !0,
                  configurable: !0,
                })
              : Error.captureStackTrace
              ? Error.captureStackTrace(this, o)
              : Object.defineProperty(this, "stack", {
                  value: Error().stack,
                  writable: !0,
                  configurable: !0,
                });
        }
        get [Symbol.toStringTag]() {
          return "GraphQLError";
        }
        toString() {
          let e = this.message;
          if (this.nodes)
            for (let t of this.nodes) t.loc && (e += "\n\n" + (0, s.V)(t.loc));
          else if (this.source && this.locations)
            for (let t of this.locations)
              e += "\n\n" + (0, s.C)(this.source, t);
          return e;
        }
        toJSON() {
          let e = { message: this.message };
          return (
            null != this.locations && (e.locations = this.locations),
            null != this.path && (e.path = this.path),
            null != this.extensions &&
              Object.keys(this.extensions).length > 0 &&
              (e.extensions = this.extensions),
            e
          );
        }
      }
      function a(e) {
        return void 0 === e || 0 === e.length ? void 0 : e;
      }
      function h(e) {
        return e.toString();
      }
      function l(e) {
        return e.toJSON();
      }
    },
    42728: (e, t, i) => {
      i.d(t, { _: () => a, k: () => o });
      var n = i(71960),
        r = i(59583),
        s = i(43685);
      class o {
        constructor(e, t = "GraphQL request", i = { line: 1, column: 1 }) {
          "string" == typeof e ||
            (0, n.U)(!1, `Body must be a string. Received: ${(0, r.N)(e)}.`),
            (this.body = e),
            (this.name = t),
            (this.locationOffset = i),
            this.locationOffset.line > 0 ||
              (0, n.U)(
                !1,
                "line in locationOffset is 1-indexed and must be positive."
              ),
            this.locationOffset.column > 0 ||
              (0, n.U)(
                !1,
                "column in locationOffset is 1-indexed and must be positive."
              );
        }
        get [Symbol.toStringTag]() {
          return "Source";
        }
      }
      function a(e) {
        return (0, s.h)(e, o);
      }
    },
    43487: (e, t, i) => {
      i.d(t, { Z: () => n });
      function n(e) {
        return "object" == typeof e && null !== e;
      }
    },
    43685: (e, t, i) => {
      i.d(t, { h: () => r });
      var n = i(59583);
      let r =
        globalThis.process && 1
          ? function (e, t) {
              return e instanceof t;
            }
          : function (e, t) {
              if (e instanceof t) return !0;
              if ("object" == typeof e && null !== e) {
                var i;
                let r = t.prototype[Symbol.toStringTag];
                if (
                  r ===
                  (Symbol.toStringTag in e
                    ? e[Symbol.toStringTag]
                    : null == (i = e.constructor)
                    ? void 0
                    : i.name)
                ) {
                  let t = (0, n.N)(e);
                  throw Error(`Cannot use ${r} "${t}" from another module or realm.

Ensure that there is only one instance of "graphql" in the node_modules
directory. If different versions of "graphql" are the dependencies of other
relied on modules, use "resolutions" to ensure only one version is installed.

https://yarnpkg.com/en/docs/selective-version-resolutions

Duplicate "graphql" modules cannot be used at the same time since different
versions may have different capabilities and behavior. The data from one
version used in the function from another could produce confusing and
spurious results.`);
                }
              }
              return !1;
            };
    },
    49331: (e, t, i) => {
      i.d(t, { V: () => n });
      function n(e, t) {
        if (!e) throw Error(null != t ? t : "Unexpected invariant triggered.");
      }
    },
    90809: (e, t, i) => {
      var n, r;
      i.d(t, { H: () => n }),
        ((r = n || (n = {})).QUERY = "QUERY"),
        (r.MUTATION = "MUTATION"),
        (r.SUBSCRIPTION = "SUBSCRIPTION"),
        (r.FIELD = "FIELD"),
        (r.FRAGMENT_DEFINITION = "FRAGMENT_DEFINITION"),
        (r.FRAGMENT_SPREAD = "FRAGMENT_SPREAD"),
        (r.INLINE_FRAGMENT = "INLINE_FRAGMENT"),
        (r.VARIABLE_DEFINITION = "VARIABLE_DEFINITION"),
        (r.SCHEMA = "SCHEMA"),
        (r.SCALAR = "SCALAR"),
        (r.OBJECT = "OBJECT"),
        (r.FIELD_DEFINITION = "FIELD_DEFINITION"),
        (r.ARGUMENT_DEFINITION = "ARGUMENT_DEFINITION"),
        (r.INTERFACE = "INTERFACE"),
        (r.UNION = "UNION"),
        (r.ENUM = "ENUM"),
        (r.ENUM_VALUE = "ENUM_VALUE"),
        (r.INPUT_OBJECT = "INPUT_OBJECT"),
        (r.INPUT_FIELD_DEFINITION = "INPUT_FIELD_DEFINITION"),
        (r.DIRECTIVE_DEFINITION = "DIRECTIVE_DEFINITION");
    },
    92143: (e, t, i) => {
      i.d(t, { C: () => s, V: () => r });
      var n = i(7078);
      function r(e) {
        return s(e.source, (0, n.g)(e.source, e.start));
      }
      function s(e, t) {
        let i = e.locationOffset.column - 1,
          n = "".padStart(i) + e.body,
          r = t.line - 1,
          s = e.locationOffset.line - 1,
          a = t.line + s,
          h = 1 === t.line ? i : 0,
          l = t.column + h,
          c = `${e.name}:${a}:${l}
`,
          p = n.split(/\r\n|[\n\r]/g),
          u = p[r];
        if (u.length > 120) {
          let e = Math.floor(l / 80),
            t = [];
          for (let e = 0; e < u.length; e += 80) t.push(u.slice(e, e + 80));
          return (
            c +
            o([
              [`${a} |`, t[0]],
              ...t.slice(1, e + 1).map((e) => ["|", e]),
              ["|", "^".padStart(l % 80)],
              ["|", t[e + 1]],
            ])
          );
        }
        return (
          c +
          o([
            [`${a - 1} |`, p[r - 1]],
            [`${a} |`, u],
            ["|", "^".padStart(l)],
            [`${a + 1} |`, p[r + 1]],
          ])
        );
      }
      function o(e) {
        let t = e.filter(([e, t]) => void 0 !== t),
          i = Math.max(...t.map(([e]) => e.length));
        return t.map(([e, t]) => e.padStart(i) + (t ? " " + t : "")).join("\n");
      }
    },
    98136: (e, t, i) => {
      i.d(t, { I: () => r });
      var n = i(28090);
      function r(e, t, i) {
        return new n.eO(`Syntax Error: ${i}`, { source: e, positions: [t] });
      }
    },
  },
]);
