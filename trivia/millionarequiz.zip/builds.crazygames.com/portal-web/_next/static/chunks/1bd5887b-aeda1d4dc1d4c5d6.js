!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var i = arguments[t];
          if (null != i) for (var n in i) i.hasOwnProperty(n) && (e[n] = i[n]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "cc908979-7c6f-4364-907e-a6d3d3d0f1ec"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-cc908979-7c6f-4364-907e-a6d3d3d0f1ec"));
  } catch (e) {}
})();
("use strict");
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [6308],
  {
    61252: (e, t, i) => {
      i.d(t, {
        $: () => ty,
        A: () => d,
        B: () => ig,
        C: () => iI,
        D: () => i_,
        E: () => iv,
        F: () => c,
        G: () => iT,
        H: () => m,
        I: () => f,
        J: () => I,
        K: () => eY,
        L: () => eZ,
        M: () => e0,
        N: () => tn,
        O: () => h,
        P: () => na,
        Q: () => ts,
        R: () => i8,
        S: () => u,
        T: () => n6,
        U: () => th,
        V: () => e_,
        W: () => tm,
        X: () => t_,
        Y: () => tv,
        Z: () => tT,
        _: () => tI,
        a: () => iM,
        a0: () => tw,
        a1: () => tR,
        a2: () => tU,
        a3: () => tF,
        a4: () => tV,
        a5: () => tH,
        a6: () => tG,
        a7: () => t$,
        a8: () => tB,
        a9: () => tJ,
        aa: () => tY,
        ab: () => tZ,
        ac: () => tQ,
        ad: () => tX,
        ae: () => t0,
        af: () => t1,
        ag: () => t2,
        ah: () => t6,
        ai: () => t4,
        aj: () => td,
        ak: () => tp,
        al: () => t5,
        am: () => t8,
        an: () => t7,
        ao: () => X,
        ap: () => ee,
        aq: () => tb,
        ar: () => ic,
        as: () => ec,
        at: () => iw,
        au: () => iR,
        b: () => ib,
        c: () => iF,
        d: () => nm,
        e: () => ng,
        f: () => nf,
        g: () => nS,
        h: () => nN,
        i: () => i0,
        j: () => nR,
        k: () => nb,
        l: () => nt,
        m: () => n0,
        n: () => n2,
        o: () => n9,
        p: () => rn,
        q: () => l,
        r: () => ni,
        s: () => ne,
        t: () => il,
        u: () => nr,
        v: () => iu,
        w: () => ih,
        x: () => id,
        y: () => ip,
        z: () => im,
      });
      var n,
        r = i(11286),
        s = i(23390),
        a = i(42402),
        o = i(68381);
      let c = { PHONE: "phone", TOTP: "totp" },
        l = {
          FACEBOOK: "facebook.com",
          GITHUB: "github.com",
          GOOGLE: "google.com",
          PASSWORD: "password",
          PHONE: "phone",
          TWITTER: "twitter.com",
        },
        u = {
          EMAIL_LINK: "emailLink",
          EMAIL_PASSWORD: "password",
          FACEBOOK: "facebook.com",
          GITHUB: "github.com",
          GOOGLE: "google.com",
          PHONE: "phone",
          TWITTER: "twitter.com",
        },
        h = {
          LINK: "link",
          REAUTHENTICATE: "reauthenticate",
          SIGN_IN: "signIn",
        },
        d = {
          EMAIL_SIGNIN: "EMAIL_SIGNIN",
          PASSWORD_RESET: "PASSWORD_RESET",
          RECOVER_EMAIL: "RECOVER_EMAIL",
          REVERT_SECOND_FACTOR_ADDITION: "REVERT_SECOND_FACTOR_ADDITION",
          VERIFY_AND_CHANGE_EMAIL: "VERIFY_AND_CHANGE_EMAIL",
          VERIFY_EMAIL: "VERIFY_EMAIL",
        };
      function p() {
        return {
          "dependent-sdk-initialized-before-auth":
            "Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK.",
        };
      }
      let m = function () {
          return {
            "admin-restricted-operation":
              "This operation is restricted to administrators only.",
            "argument-error": "",
            "app-not-authorized":
              "This app, identified by the domain where it's hosted, is not authorized to use Firebase Authentication with the provided API key. Review your key configuration in the Google API console.",
            "app-not-installed":
              "The requested mobile application corresponding to the identifier (Android package name or iOS bundle ID) provided is not installed on this device.",
            "captcha-check-failed":
              "The reCAPTCHA response token provided is either invalid, expired, already used or the domain associated with it does not match the list of whitelisted domains.",
            "code-expired":
              "The SMS code has expired. Please re-send the verification code to try again.",
            "cordova-not-ready": "Cordova framework is not ready.",
            "cors-unsupported": "This browser is not supported.",
            "credential-already-in-use":
              "This credential is already associated with a different user account.",
            "custom-token-mismatch":
              "The custom token corresponds to a different audience.",
            "requires-recent-login":
              "This operation is sensitive and requires recent authentication. Log in again before retrying this request.",
            "dependent-sdk-initialized-before-auth":
              "Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK.",
            "dynamic-link-not-activated":
              "Please activate Dynamic Links in the Firebase Console and agree to the terms and conditions.",
            "email-change-needs-verification":
              "Multi-factor users must always have a verified email.",
            "email-already-in-use":
              "The email address is already in use by another account.",
            "emulator-config-failed":
              'Auth instance has already been used to make a network call. Auth can no longer be configured to use the emulator. Try calling "connectAuthEmulator()" sooner.',
            "expired-action-code": "The action code has expired.",
            "cancelled-popup-request":
              "This operation has been cancelled due to another conflicting popup being opened.",
            "internal-error": "An internal AuthError has occurred.",
            "invalid-app-credential":
              "The phone verification request contains an invalid application verifier. The reCAPTCHA token response is either invalid or expired.",
            "invalid-app-id":
              "The mobile app identifier is not registered for the current project.",
            "invalid-user-token":
              "This user's credential isn't valid for this project. This can happen if the user's token has been tampered with, or if the user isn't for the project associated with this API key.",
            "invalid-auth-event": "An internal AuthError has occurred.",
            "invalid-verification-code":
              "The SMS verification code used to create the phone auth credential is invalid. Please resend the verification code sms and be sure to use the verification code provided by the user.",
            "invalid-continue-uri":
              "The continue URL provided in the request is invalid.",
            "invalid-cordova-configuration":
              "The following Cordova plugins must be installed to enable OAuth sign-in: cordova-plugin-buildinfo, cordova-universal-links-plugin, cordova-plugin-browsertab, cordova-plugin-inappbrowser and cordova-plugin-customurlscheme.",
            "invalid-custom-token":
              "The custom token format is incorrect. Please check the documentation.",
            "invalid-dynamic-link-domain":
              "The provided dynamic link domain is not configured or authorized for the current project.",
            "invalid-email": "The email address is badly formatted.",
            "invalid-emulator-scheme":
              "Emulator URL must start with a valid scheme (http:// or https://).",
            "invalid-api-key":
              "Your API key is invalid, please check you have copied it correctly.",
            "invalid-cert-hash":
              "The SHA-1 certificate hash provided is invalid.",
            "invalid-credential":
              "The supplied auth credential is incorrect, malformed or has expired.",
            "invalid-message-payload":
              "The email template corresponding to this action contains invalid characters in its message. Please fix by going to the Auth email templates section in the Firebase Console.",
            "invalid-multi-factor-session":
              "The request does not contain a valid proof of first factor successful sign-in.",
            "invalid-oauth-provider":
              "EmailAuthProvider is not supported for this operation. This operation only supports OAuth providers.",
            "invalid-oauth-client-id":
              "The OAuth client ID provided is either invalid or does not match the specified API key.",
            "unauthorized-domain":
              "This domain is not authorized for OAuth operations for your Firebase project. Edit the list of authorized domains from the Firebase console.",
            "invalid-action-code":
              "The action code is invalid. This can happen if the code is malformed, expired, or has already been used.",
            "wrong-password":
              "The password is invalid or the user does not have a password.",
            "invalid-persistence-type":
              "The specified persistence type is invalid. It can only be local, session or none.",
            "invalid-phone-number":
              "The format of the phone number provided is incorrect. Please enter the phone number in a format that can be parsed into E.164 format. E.164 phone numbers are written in the format [+][country code][subscriber number including area code].",
            "invalid-provider-id": "The specified provider ID is invalid.",
            "invalid-recipient-email":
              "The email corresponding to this action failed to send as the provided recipient email address is invalid.",
            "invalid-sender":
              "The email template corresponding to this action contains an invalid sender email or name. Please fix by going to the Auth email templates section in the Firebase Console.",
            "invalid-verification-id":
              "The verification ID used to create the phone auth credential is invalid.",
            "invalid-tenant-id": "The Auth instance's tenant ID is invalid.",
            "login-blocked":
              "Login blocked by user-provided method: {$originalMessage}",
            "missing-android-pkg-name":
              "An Android Package Name must be provided if the Android App is required to be installed.",
            "auth-domain-config-required":
              "Be sure to include authDomain when calling firebase.initializeApp(), by following the instructions in the Firebase console.",
            "missing-app-credential":
              "The phone verification request is missing an application verifier assertion. A reCAPTCHA response token needs to be provided.",
            "missing-verification-code":
              "The phone auth credential was created with an empty SMS verification code.",
            "missing-continue-uri":
              "A continue URL must be provided in the request.",
            "missing-iframe-start": "An internal AuthError has occurred.",
            "missing-ios-bundle-id":
              "An iOS Bundle ID must be provided if an App Store ID is provided.",
            "missing-or-invalid-nonce":
              "The request does not contain a valid nonce. This can occur if the SHA-256 hash of the provided raw nonce does not match the hashed nonce in the ID token payload.",
            "missing-password": "A non-empty password must be provided",
            "missing-multi-factor-info":
              "No second factor identifier is provided.",
            "missing-multi-factor-session":
              "The request is missing proof of first factor successful sign-in.",
            "missing-phone-number":
              "To send verification codes, provide a phone number for the recipient.",
            "missing-verification-id":
              "The phone auth credential was created with an empty verification ID.",
            "app-deleted": "This instance of FirebaseApp has been deleted.",
            "multi-factor-info-not-found":
              "The user does not have a second factor matching the identifier provided.",
            "multi-factor-auth-required":
              "Proof of ownership of a second factor is required to complete sign-in.",
            "account-exists-with-different-credential":
              "An account already exists with the same email address but different sign-in credentials. Sign in using a provider associated with this email address.",
            "network-request-failed":
              "A network AuthError (such as timeout, interrupted connection or unreachable host) has occurred.",
            "no-auth-event": "An internal AuthError has occurred.",
            "no-such-provider":
              "User was not linked to an account with the given provider.",
            "null-user":
              "A null user object was provided as the argument for an operation which requires a non-null user object.",
            "operation-not-allowed":
              "The given sign-in provider is disabled for this Firebase project. Enable it in the Firebase console, under the sign-in method tab of the Auth section.",
            "operation-not-supported-in-this-environment":
              'This operation is not supported in the environment this application is running on. "location.protocol" must be http, https or chrome-extension and web storage must be enabled.',
            "popup-blocked":
              "Unable to establish a connection with the popup. It may have been blocked by the browser.",
            "popup-closed-by-user":
              "The popup has been closed by the user before finalizing the operation.",
            "provider-already-linked":
              "User can only be linked to one identity for the given provider.",
            "quota-exceeded":
              "The project's quota for this operation has been exceeded.",
            "redirect-cancelled-by-user":
              "The redirect operation has been cancelled by the user before finalizing.",
            "redirect-operation-pending":
              "A redirect sign-in operation is already pending.",
            "rejected-credential":
              "The request contains malformed or mismatching credentials.",
            "second-factor-already-in-use":
              "The second factor is already enrolled on this account.",
            "maximum-second-factor-count-exceeded":
              "The maximum allowed number of second factors on a user has been exceeded.",
            "tenant-id-mismatch":
              "The provided tenant ID does not match the Auth instance's tenant ID",
            timeout: "The operation has timed out.",
            "user-token-expired":
              "The user's credential is no longer valid. The user must sign in again.",
            "too-many-requests":
              "We have blocked all requests from this device due to unusual activity. Try again later.",
            "unauthorized-continue-uri":
              "The domain of the continue URL is not whitelisted.  Please whitelist the domain in the Firebase console.",
            "unsupported-first-factor":
              "Enrolling a second factor or signing in with a multi-factor account requires sign-in with a supported first factor.",
            "unsupported-persistence-type":
              "The current environment does not support the specified persistence type.",
            "unsupported-tenant-operation":
              "This operation is not supported in a multi-tenant context.",
            "unverified-email": "The operation requires a verified email.",
            "user-cancelled":
              "The user did not grant your application the permissions it requested.",
            "user-not-found":
              "There is no user record corresponding to this identifier. The user may have been deleted.",
            "user-disabled":
              "The user account has been disabled by an administrator.",
            "user-mismatch":
              "The supplied credentials do not correspond to the previously signed in user.",
            "user-signed-out": "",
            "weak-password": "The password must be 6 characters long or more.",
            "web-storage-unsupported":
              "This browser is not supported or 3rd party cookies and data may be disabled.",
            "already-initialized":
              "initializeAuth() has already been called with different options. To avoid this error, call initializeAuth() with the same options as when it was originally called, or call getAuth() to return the already initialized instance.",
            "missing-recaptcha-token":
              "The reCAPTCHA token is missing when sending request to the backend.",
            "invalid-recaptcha-token":
              "The reCAPTCHA token is invalid when sending request to the backend.",
            "invalid-recaptcha-action":
              "The reCAPTCHA action is invalid when sending request to the backend.",
            "recaptcha-not-enabled":
              "reCAPTCHA Enterprise integration is not enabled for this project.",
            "missing-client-type":
              "The reCAPTCHA client type is missing when sending request to the backend.",
            "missing-recaptcha-version":
              "The reCAPTCHA version is missing when sending request to the backend.",
            "invalid-req-type": "Invalid request parameters.",
            "invalid-recaptcha-version":
              "The reCAPTCHA version is invalid when sending request to the backend.",
            "unsupported-password-policy-schema-version":
              "The password policy received from the backend uses a schema version that is not supported by this version of the Firebase SDK.",
            "password-does-not-meet-requirements":
              "The password does not meet the requirements.",
            "invalid-hosting-link-domain":
              "The provided Hosting link domain is not configured in Firebase Hosting or is not owned by the current project. This cannot be a default Hosting domain (`web.app` or `firebaseapp.com`).",
          };
        },
        f = p,
        g = new s.FA("auth", "Firebase", p()),
        I = {
          ADMIN_ONLY_OPERATION: "auth/admin-restricted-operation",
          ARGUMENT_ERROR: "auth/argument-error",
          APP_NOT_AUTHORIZED: "auth/app-not-authorized",
          APP_NOT_INSTALLED: "auth/app-not-installed",
          CAPTCHA_CHECK_FAILED: "auth/captcha-check-failed",
          CODE_EXPIRED: "auth/code-expired",
          CORDOVA_NOT_READY: "auth/cordova-not-ready",
          CORS_UNSUPPORTED: "auth/cors-unsupported",
          CREDENTIAL_ALREADY_IN_USE: "auth/credential-already-in-use",
          CREDENTIAL_MISMATCH: "auth/custom-token-mismatch",
          CREDENTIAL_TOO_OLD_LOGIN_AGAIN: "auth/requires-recent-login",
          DEPENDENT_SDK_INIT_BEFORE_AUTH:
            "auth/dependent-sdk-initialized-before-auth",
          DYNAMIC_LINK_NOT_ACTIVATED: "auth/dynamic-link-not-activated",
          EMAIL_CHANGE_NEEDS_VERIFICATION:
            "auth/email-change-needs-verification",
          EMAIL_EXISTS: "auth/email-already-in-use",
          EMULATOR_CONFIG_FAILED: "auth/emulator-config-failed",
          EXPIRED_OOB_CODE: "auth/expired-action-code",
          EXPIRED_POPUP_REQUEST: "auth/cancelled-popup-request",
          INTERNAL_ERROR: "auth/internal-error",
          INVALID_API_KEY: "auth/invalid-api-key",
          INVALID_APP_CREDENTIAL: "auth/invalid-app-credential",
          INVALID_APP_ID: "auth/invalid-app-id",
          INVALID_AUTH: "auth/invalid-user-token",
          INVALID_AUTH_EVENT: "auth/invalid-auth-event",
          INVALID_CERT_HASH: "auth/invalid-cert-hash",
          INVALID_CODE: "auth/invalid-verification-code",
          INVALID_CONTINUE_URI: "auth/invalid-continue-uri",
          INVALID_CORDOVA_CONFIGURATION: "auth/invalid-cordova-configuration",
          INVALID_CUSTOM_TOKEN: "auth/invalid-custom-token",
          INVALID_DYNAMIC_LINK_DOMAIN: "auth/invalid-dynamic-link-domain",
          INVALID_EMAIL: "auth/invalid-email",
          INVALID_EMULATOR_SCHEME: "auth/invalid-emulator-scheme",
          INVALID_IDP_RESPONSE: "auth/invalid-credential",
          INVALID_LOGIN_CREDENTIALS: "auth/invalid-credential",
          INVALID_MESSAGE_PAYLOAD: "auth/invalid-message-payload",
          INVALID_MFA_SESSION: "auth/invalid-multi-factor-session",
          INVALID_OAUTH_CLIENT_ID: "auth/invalid-oauth-client-id",
          INVALID_OAUTH_PROVIDER: "auth/invalid-oauth-provider",
          INVALID_OOB_CODE: "auth/invalid-action-code",
          INVALID_ORIGIN: "auth/unauthorized-domain",
          INVALID_PASSWORD: "auth/wrong-password",
          INVALID_PERSISTENCE: "auth/invalid-persistence-type",
          INVALID_PHONE_NUMBER: "auth/invalid-phone-number",
          INVALID_PROVIDER_ID: "auth/invalid-provider-id",
          INVALID_RECIPIENT_EMAIL: "auth/invalid-recipient-email",
          INVALID_SENDER: "auth/invalid-sender",
          INVALID_SESSION_INFO: "auth/invalid-verification-id",
          INVALID_TENANT_ID: "auth/invalid-tenant-id",
          MFA_INFO_NOT_FOUND: "auth/multi-factor-info-not-found",
          MFA_REQUIRED: "auth/multi-factor-auth-required",
          MISSING_ANDROID_PACKAGE_NAME: "auth/missing-android-pkg-name",
          MISSING_APP_CREDENTIAL: "auth/missing-app-credential",
          MISSING_AUTH_DOMAIN: "auth/auth-domain-config-required",
          MISSING_CODE: "auth/missing-verification-code",
          MISSING_CONTINUE_URI: "auth/missing-continue-uri",
          MISSING_IFRAME_START: "auth/missing-iframe-start",
          MISSING_IOS_BUNDLE_ID: "auth/missing-ios-bundle-id",
          MISSING_OR_INVALID_NONCE: "auth/missing-or-invalid-nonce",
          MISSING_MFA_INFO: "auth/missing-multi-factor-info",
          MISSING_MFA_SESSION: "auth/missing-multi-factor-session",
          MISSING_PHONE_NUMBER: "auth/missing-phone-number",
          MISSING_PASSWORD: "auth/missing-password",
          MISSING_SESSION_INFO: "auth/missing-verification-id",
          MODULE_DESTROYED: "auth/app-deleted",
          NEED_CONFIRMATION: "auth/account-exists-with-different-credential",
          NETWORK_REQUEST_FAILED: "auth/network-request-failed",
          NULL_USER: "auth/null-user",
          NO_AUTH_EVENT: "auth/no-auth-event",
          NO_SUCH_PROVIDER: "auth/no-such-provider",
          OPERATION_NOT_ALLOWED: "auth/operation-not-allowed",
          OPERATION_NOT_SUPPORTED:
            "auth/operation-not-supported-in-this-environment",
          POPUP_BLOCKED: "auth/popup-blocked",
          POPUP_CLOSED_BY_USER: "auth/popup-closed-by-user",
          PROVIDER_ALREADY_LINKED: "auth/provider-already-linked",
          QUOTA_EXCEEDED: "auth/quota-exceeded",
          REDIRECT_CANCELLED_BY_USER: "auth/redirect-cancelled-by-user",
          REDIRECT_OPERATION_PENDING: "auth/redirect-operation-pending",
          REJECTED_CREDENTIAL: "auth/rejected-credential",
          SECOND_FACTOR_ALREADY_ENROLLED: "auth/second-factor-already-in-use",
          SECOND_FACTOR_LIMIT_EXCEEDED:
            "auth/maximum-second-factor-count-exceeded",
          TENANT_ID_MISMATCH: "auth/tenant-id-mismatch",
          TIMEOUT: "auth/timeout",
          TOKEN_EXPIRED: "auth/user-token-expired",
          TOO_MANY_ATTEMPTS_TRY_LATER: "auth/too-many-requests",
          UNAUTHORIZED_DOMAIN: "auth/unauthorized-continue-uri",
          UNSUPPORTED_FIRST_FACTOR: "auth/unsupported-first-factor",
          UNSUPPORTED_PERSISTENCE: "auth/unsupported-persistence-type",
          UNSUPPORTED_TENANT_OPERATION: "auth/unsupported-tenant-operation",
          UNVERIFIED_EMAIL: "auth/unverified-email",
          USER_CANCELLED: "auth/user-cancelled",
          USER_DELETED: "auth/user-not-found",
          USER_DISABLED: "auth/user-disabled",
          USER_MISMATCH: "auth/user-mismatch",
          USER_SIGNED_OUT: "auth/user-signed-out",
          WEAK_PASSWORD: "auth/weak-password",
          WEB_STORAGE_UNSUPPORTED: "auth/web-storage-unsupported",
          ALREADY_INITIALIZED: "auth/already-initialized",
          RECAPTCHA_NOT_ENABLED: "auth/recaptcha-not-enabled",
          MISSING_RECAPTCHA_TOKEN: "auth/missing-recaptcha-token",
          INVALID_RECAPTCHA_TOKEN: "auth/invalid-recaptcha-token",
          INVALID_RECAPTCHA_ACTION: "auth/invalid-recaptcha-action",
          MISSING_CLIENT_TYPE: "auth/missing-client-type",
          MISSING_RECAPTCHA_VERSION: "auth/missing-recaptcha-version",
          INVALID_RECAPTCHA_VERSION: "auth/invalid-recaptcha-version",
          INVALID_REQ_TYPE: "auth/invalid-req-type",
          INVALID_HOSTING_LINK_DOMAIN: "auth/invalid-hosting-link-domain",
        },
        _ = new a.Vy("@firebase/auth");
      function v(e, ...t) {
        _.logLevel <= a.$b.ERROR && _.error(`Auth (${r.MF}): ${e}`, ...t);
      }
      function T(e, ...t) {
        throw S(e, ...t);
      }
      function E(e, ...t) {
        return S(e, ...t);
      }
      function y(e, t, i) {
        let n = { ...f(), [t]: i };
        return new s.FA("auth", "Firebase", n).create(t, { appName: e.name });
      }
      function w(e) {
        return y(
          e,
          "operation-not-supported-in-this-environment",
          "Operations that alter the current user are not supported in conjunction with FirebaseServerApp"
        );
      }
      function A(e, t, i) {
        if (!(t instanceof i))
          throw (
            (i.name !== t.constructor.name && T(e, "argument-error"),
            y(
              e,
              "argument-error",
              `Type of ${t.constructor.name} does not match expected instance.Did you pass a reference from a different Auth SDK?`
            ))
          );
      }
      function S(e, ...t) {
        if ("string" != typeof e) {
          let i = t[0],
            n = [...t.slice(1)];
          return (
            n[0] && (n[0].appName = e.name), e._errorFactory.create(i, ...n)
          );
        }
        return g.create(e, ...t);
      }
      function k(e, t, ...i) {
        if (!e) throw S(t, ...i);
      }
      function R(e) {
        let t = "INTERNAL ASSERTION FAILED: " + e;
        throw (v(t), Error(t));
      }
      function P() {
        return ("u" > typeof self && self.location?.href) || "";
      }
      function N() {
        return "http:" === O() || "https:" === O();
      }
      function O() {
        return ("u" > typeof self && self.location?.protocol) || null;
      }
      class b {
        constructor(e, t) {
          (this.shortDelay = e),
            (this.longDelay = t),
            (function (e, t) {
              e || R(t);
            })(t > e, "Short delay should be less than long delay!"),
            (this.isMobile = (0, s.jZ)() || (0, s.lV)());
        }
        get() {
          return !(
            "u" > typeof navigator &&
            navigator &&
            "onLine" in navigator &&
            "boolean" == typeof navigator.onLine &&
            (N() || (0, s.sr)() || "connection" in navigator)
          ) || navigator.onLine
            ? this.isMobile
              ? this.longDelay
              : this.shortDelay
            : Math.min(5e3, this.shortDelay);
        }
      }
      function C(e, t) {
        var i, n;
        (i = e.emulator), (n = "Emulator should always be set here"), i || R(n);
        let { url: r } = e.emulator;
        return t ? `${r}${t.startsWith("/") ? t.slice(1) : t}` : r;
      }
      class D {
        static initialize(e, t, i) {
          (this.fetchImpl = e),
            t && (this.headersImpl = t),
            i && (this.responseImpl = i);
        }
        static fetch() {
          return this.fetchImpl
            ? this.fetchImpl
            : "u" > typeof self && "fetch" in self
            ? self.fetch
            : "u" > typeof globalThis && globalThis.fetch
            ? globalThis.fetch
            : "u" > typeof fetch
            ? fetch
            : void R(
                "Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill"
              );
        }
        static headers() {
          return this.headersImpl
            ? this.headersImpl
            : "u" > typeof self && "Headers" in self
            ? self.Headers
            : "u" > typeof globalThis && globalThis.Headers
            ? globalThis.Headers
            : "u" > typeof Headers
            ? Headers
            : void R(
                "Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill"
              );
        }
        static response() {
          return this.responseImpl
            ? this.responseImpl
            : "u" > typeof self && "Response" in self
            ? self.Response
            : "u" > typeof globalThis && globalThis.Response
            ? globalThis.Response
            : "u" > typeof Response
            ? Response
            : void R(
                "Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill"
              );
        }
      }
      let L = {
          CREDENTIAL_MISMATCH: "custom-token-mismatch",
          MISSING_CUSTOM_TOKEN: "internal-error",
          INVALID_IDENTIFIER: "invalid-email",
          MISSING_CONTINUE_URI: "internal-error",
          INVALID_PASSWORD: "wrong-password",
          MISSING_PASSWORD: "missing-password",
          INVALID_LOGIN_CREDENTIALS: "invalid-credential",
          EMAIL_EXISTS: "email-already-in-use",
          PASSWORD_LOGIN_DISABLED: "operation-not-allowed",
          INVALID_IDP_RESPONSE: "invalid-credential",
          INVALID_PENDING_TOKEN: "invalid-credential",
          FEDERATED_USER_ID_ALREADY_LINKED: "credential-already-in-use",
          MISSING_REQ_TYPE: "internal-error",
          EMAIL_NOT_FOUND: "user-not-found",
          RESET_PASSWORD_EXCEED_LIMIT: "too-many-requests",
          EXPIRED_OOB_CODE: "expired-action-code",
          INVALID_OOB_CODE: "invalid-action-code",
          MISSING_OOB_CODE: "internal-error",
          CREDENTIAL_TOO_OLD_LOGIN_AGAIN: "requires-recent-login",
          INVALID_ID_TOKEN: "invalid-user-token",
          TOKEN_EXPIRED: "user-token-expired",
          USER_NOT_FOUND: "user-token-expired",
          TOO_MANY_ATTEMPTS_TRY_LATER: "too-many-requests",
          PASSWORD_DOES_NOT_MEET_REQUIREMENTS:
            "password-does-not-meet-requirements",
          INVALID_CODE: "invalid-verification-code",
          INVALID_SESSION_INFO: "invalid-verification-id",
          INVALID_TEMPORARY_PROOF: "invalid-credential",
          MISSING_SESSION_INFO: "missing-verification-id",
          SESSION_EXPIRED: "code-expired",
          MISSING_ANDROID_PACKAGE_NAME: "missing-android-pkg-name",
          UNAUTHORIZED_DOMAIN: "unauthorized-continue-uri",
          INVALID_OAUTH_CLIENT_ID: "invalid-oauth-client-id",
          ADMIN_ONLY_OPERATION: "admin-restricted-operation",
          INVALID_MFA_PENDING_CREDENTIAL: "invalid-multi-factor-session",
          MFA_ENROLLMENT_NOT_FOUND: "multi-factor-info-not-found",
          MISSING_MFA_ENROLLMENT_ID: "missing-multi-factor-info",
          MISSING_MFA_PENDING_CREDENTIAL: "missing-multi-factor-session",
          SECOND_FACTOR_EXISTS: "second-factor-already-in-use",
          SECOND_FACTOR_LIMIT_EXCEEDED: "maximum-second-factor-count-exceeded",
          BLOCKING_FUNCTION_ERROR_RESPONSE: "internal-error",
          RECAPTCHA_NOT_ENABLED: "recaptcha-not-enabled",
          MISSING_RECAPTCHA_TOKEN: "missing-recaptcha-token",
          INVALID_RECAPTCHA_TOKEN: "invalid-recaptcha-token",
          INVALID_RECAPTCHA_ACTION: "invalid-recaptcha-action",
          MISSING_CLIENT_TYPE: "missing-client-type",
          MISSING_RECAPTCHA_VERSION: "missing-recaptcha-version",
          INVALID_RECAPTCHA_VERSION: "invalid-recaptcha-version",
          INVALID_REQ_TYPE: "invalid-req-type",
        },
        M = [
          "/v1/accounts:signInWithCustomToken",
          "/v1/accounts:signInWithEmailLink",
          "/v1/accounts:signInWithIdp",
          "/v1/accounts:signInWithPassword",
          "/v1/accounts:signInWithPhoneNumber",
          "/v1/token",
        ],
        U = new b(3e4, 6e4);
      function F(e, t) {
        return e.tenantId && !t.tenantId ? { ...t, tenantId: e.tenantId } : t;
      }
      async function V(e, t, i, n, r = {}) {
        return x(e, r, async () => {
          let r = {},
            a = {};
          n && ("GET" === t ? (a = n) : (r = { body: JSON.stringify(n) }));
          let o = (0, s.Am)({ key: e.config.apiKey, ...a }).slice(1),
            c = await e._getAdditionalHeaders();
          (c["Content-Type"] = "application/json"),
            e.languageCode && (c["X-Firebase-Locale"] = e.languageCode);
          let l = { method: t, headers: c, ...r };
          return (
            (0, s.c1)() || (l.referrerPolicy = "no-referrer"),
            e.emulatorConfig &&
              (0, s.zJ)(e.emulatorConfig.host) &&
              (l.credentials = "include"),
            D.fetch()(await K(e, e.config.apiHost, i, o), l)
          );
        });
      }
      async function x(e, t, i) {
        e._canInitEmulator = !1;
        let n = { ...L, ...t };
        try {
          let t = new j(e),
            r = await Promise.race([i(), t.promise]);
          t.clearNetworkTimeout();
          let s = await r.json();
          if ("needConfirmation" in s)
            throw q(e, "account-exists-with-different-credential", s);
          if (r.ok && !("errorMessage" in s)) return s;
          {
            let [t, i] = (r.ok ? s.errorMessage : s.error.message).split(" : ");
            if ("FEDERATED_USER_ID_ALREADY_LINKED" === t)
              throw q(e, "credential-already-in-use", s);
            if ("EMAIL_EXISTS" === t) throw q(e, "email-already-in-use", s);
            if ("USER_DISABLED" === t) throw q(e, "user-disabled", s);
            let a = n[t] || t.toLowerCase().replace(/[_\s]+/g, "-");
            if (i) throw y(e, a, i);
            T(e, a);
          }
        } catch (t) {
          if (t instanceof s.g) throw t;
          T(e, "network-request-failed", { message: String(t) });
        }
      }
      async function H(e, t, i, n, r = {}) {
        let s = await V(e, t, i, n, r);
        return (
          "mfaPendingCredential" in s &&
            T(e, "multi-factor-auth-required", { _serverResponse: s }),
          s
        );
      }
      async function K(e, t, i, n) {
        let r = `${t}${i}?${n}`,
          s = e.config.emulator
            ? C(e.config, r)
            : `${e.config.apiScheme}://${r}`;
        return M.includes(i) &&
          (await e._persistenceManagerAvailable,
          "COOKIE" === e._getPersistenceType())
          ? e._getPersistence()._getFinalTarget(s).toString()
          : s;
      }
      class j {
        clearNetworkTimeout() {
          clearTimeout(this.timer);
        }
        constructor(e) {
          (this.auth = e),
            (this.timer = null),
            (this.promise = new Promise((e, t) => {
              this.timer = setTimeout(
                () => t(E(this.auth, "network-request-failed")),
                U.get()
              );
            }));
        }
      }
      function q(e, t, i) {
        let n = { appName: e.name };
        i.email && (n.email = i.email),
          i.phoneNumber && (n.phoneNumber = i.phoneNumber);
        let r = E(e, t, n);
        return (r.customData._tokenResponse = i), r;
      }
      function W(e) {
        return void 0 !== e && void 0 !== e.getResponse;
      }
      function z(e) {
        return void 0 !== e && void 0 !== e.enterprise;
      }
      class G {
        constructor(e) {
          if (
            ((this.siteKey = ""),
            (this.recaptchaEnforcementState = []),
            void 0 === e.recaptchaKey)
          )
            throw Error("recaptchaKey undefined");
          (this.siteKey = e.recaptchaKey.split("/")[3]),
            (this.recaptchaEnforcementState = e.recaptchaEnforcementState);
        }
        getProviderEnforcementState(e) {
          if (
            !this.recaptchaEnforcementState ||
            0 === this.recaptchaEnforcementState.length
          )
            return null;
          for (let t of this.recaptchaEnforcementState)
            if (t.provider && t.provider === e)
              switch (t.enforcementState) {
                case "ENFORCE":
                  return "ENFORCE";
                case "AUDIT":
                  return "AUDIT";
                case "OFF":
                  return "OFF";
                default:
                  return "ENFORCEMENT_STATE_UNSPECIFIED";
              }
          return null;
        }
        isProviderEnabled(e) {
          return (
            "ENFORCE" === this.getProviderEnforcementState(e) ||
            "AUDIT" === this.getProviderEnforcementState(e)
          );
        }
        isAnyProviderEnabled() {
          return (
            this.isProviderEnabled("EMAIL_PASSWORD_PROVIDER") ||
            this.isProviderEnabled("PHONE_PROVIDER")
          );
        }
      }
      async function $(e) {
        return (
          (await V(e, "GET", "/v1/recaptchaParams")).recaptchaSiteKey || ""
        );
      }
      async function B(e, t) {
        return V(e, "GET", "/v2/recaptchaConfig", F(e, t));
      }
      async function J(e, t) {
        return V(e, "POST", "/v1/accounts:delete", t);
      }
      async function Y(e, t) {
        return V(e, "POST", "/v1/accounts:update", t);
      }
      async function Z(e, t) {
        return V(e, "POST", "/v1/accounts:lookup", t);
      }
      function Q(e) {
        if (e)
          try {
            let t = new Date(Number(e));
            if (!isNaN(t.getTime())) return t.toUTCString();
          } catch (e) {}
      }
      function X(e, t = !1) {
        return (0, s.Ku)(e).getIdToken(t);
      }
      async function ee(e, t = !1) {
        let i = (0, s.Ku)(e),
          n = await i.getIdToken(t),
          r = ei(n);
        k(r && r.exp && r.auth_time && r.iat, i.auth, "internal-error");
        let a = "object" == typeof r.firebase ? r.firebase : void 0,
          o = a?.sign_in_provider;
        return {
          claims: r,
          token: n,
          authTime: Q(et(r.auth_time)),
          issuedAtTime: Q(et(r.iat)),
          expirationTime: Q(et(r.exp)),
          signInProvider: o || null,
          signInSecondFactor: a?.sign_in_second_factor || null,
        };
      }
      function et(e) {
        return 1e3 * Number(e);
      }
      function ei(e) {
        let [t, i, n] = e.split(".");
        if (void 0 === t || void 0 === i || void 0 === n)
          return v("JWT malformed, contained fewer than 3 sections"), null;
        try {
          let e = (0, s.u)(i);
          if (!e) return v("Failed to decode base64 JWT payload"), null;
          return JSON.parse(e);
        } catch (e) {
          return (
            v("Caught error parsing JWT payload as JSON", e?.toString()), null
          );
        }
      }
      function en(e) {
        let t = ei(e);
        return (
          k(t, "internal-error"),
          k(void 0 !== t.exp, "internal-error"),
          k(void 0 !== t.iat, "internal-error"),
          Number(t.exp) - Number(t.iat)
        );
      }
      async function er(e, t, i = !1) {
        if (i) return t;
        try {
          return await t;
        } catch (t) {
          throw (
            (t instanceof s.g &&
              (function ({ code: e }) {
                return (
                  "auth/user-disabled" === e || "auth/user-token-expired" === e
                );
              })(t) &&
              e.auth.currentUser === e &&
              (await e.auth.signOut()),
            t)
          );
        }
      }
      class es {
        constructor(e) {
          (this.user = e),
            (this.isRunning = !1),
            (this.timerId = null),
            (this.errorBackoff = 3e4);
        }
        _start() {
          this.isRunning || ((this.isRunning = !0), this.schedule());
        }
        _stop() {
          this.isRunning &&
            ((this.isRunning = !1),
            null !== this.timerId && clearTimeout(this.timerId));
        }
        getInterval(e) {
          if (!e)
            return (
              (this.errorBackoff = 3e4),
              Math.max(
                0,
                (this.user.stsTokenManager.expirationTime ?? 0) -
                  Date.now() -
                  3e5
              )
            );
          {
            let e = this.errorBackoff;
            return (
              (this.errorBackoff = Math.min(2 * this.errorBackoff, 96e4)), e
            );
          }
        }
        schedule(e = !1) {
          if (!this.isRunning) return;
          let t = this.getInterval(e);
          this.timerId = setTimeout(async () => {
            await this.iteration();
          }, t);
        }
        async iteration() {
          try {
            await this.user.getIdToken(!0);
          } catch (e) {
            e?.code === "auth/network-request-failed" && this.schedule(!0);
            return;
          }
          this.schedule();
        }
      }
      class ea {
        constructor(e, t) {
          (this.createdAt = e), (this.lastLoginAt = t), this._initializeTime();
        }
        _initializeTime() {
          (this.lastSignInTime = Q(this.lastLoginAt)),
            (this.creationTime = Q(this.createdAt));
        }
        _copy(e) {
          (this.createdAt = e.createdAt),
            (this.lastLoginAt = e.lastLoginAt),
            this._initializeTime();
        }
        toJSON() {
          return { createdAt: this.createdAt, lastLoginAt: this.lastLoginAt };
        }
      }
      async function eo(e) {
        var t, i;
        let n = e.auth,
          r = await e.getIdToken(),
          s = await er(e, Z(n, { idToken: r }));
        k(s?.users.length, n, "internal-error");
        let a = s.users[0];
        e._notifyReloadListener(a);
        let o = a.providerUserInfo?.length ? el(a.providerUserInfo) : [],
          c =
            ((t = e.providerData),
            (i = o),
            [
              ...t.filter((e) => !i.some((t) => t.providerId === e.providerId)),
              ...i,
            ]),
          l = e.isAnonymous,
          u = !(e.email && a.passwordHash) && !c?.length;
        Object.assign(e, {
          uid: a.localId,
          displayName: a.displayName || null,
          photoURL: a.photoUrl || null,
          email: a.email || null,
          emailVerified: a.emailVerified || !1,
          phoneNumber: a.phoneNumber || null,
          tenantId: a.tenantId || null,
          providerData: c,
          metadata: new ea(a.createdAt, a.lastLoginAt),
          isAnonymous: !!l && u,
        });
      }
      async function ec(e) {
        let t = (0, s.Ku)(e);
        await eo(t),
          await t.auth._persistUserIfCurrent(t),
          t.auth._notifyListenersIfCurrent(t);
      }
      function el(e) {
        return e.map(({ providerId: e, ...t }) => ({
          providerId: e,
          uid: t.rawId || "",
          displayName: t.displayName || null,
          email: t.email || null,
          phoneNumber: t.phoneNumber || null,
          photoURL: t.photoUrl || null,
        }));
      }
      async function eu(e, t) {
        let i = await x(e, {}, async () => {
          let i = (0, s.Am)({
              grant_type: "refresh_token",
              refresh_token: t,
            }).slice(1),
            { tokenApiHost: n, apiKey: r } = e.config,
            a = await K(e, n, "/v1/token", `key=${r}`),
            o = await e._getAdditionalHeaders();
          o["Content-Type"] = "application/x-www-form-urlencoded";
          let c = { method: "POST", headers: o, body: i };
          return (
            e.emulatorConfig &&
              (0, s.zJ)(e.emulatorConfig.host) &&
              (c.credentials = "include"),
            D.fetch()(a, c)
          );
        });
        return {
          accessToken: i.access_token,
          expiresIn: i.expires_in,
          refreshToken: i.refresh_token,
        };
      }
      async function eh(e, t) {
        return V(e, "POST", "/v2/accounts:revokeToken", F(e, t));
      }
      class ed {
        constructor() {
          (this.refreshToken = null),
            (this.accessToken = null),
            (this.expirationTime = null);
        }
        get isExpired() {
          return !this.expirationTime || Date.now() > this.expirationTime - 3e4;
        }
        updateFromServerResponse(e) {
          k(e.idToken, "internal-error"),
            k(void 0 !== e.idToken, "internal-error"),
            k(void 0 !== e.refreshToken, "internal-error");
          let t =
            "expiresIn" in e && void 0 !== e.expiresIn
              ? Number(e.expiresIn)
              : en(e.idToken);
          this.updateTokensAndExpiration(e.idToken, e.refreshToken, t);
        }
        updateFromIdToken(e) {
          k(0 !== e.length, "internal-error");
          let t = en(e);
          this.updateTokensAndExpiration(e, null, t);
        }
        async getToken(e, t = !1) {
          return t || !this.accessToken || this.isExpired
            ? (k(this.refreshToken, e, "user-token-expired"), this.refreshToken)
              ? (await this.refresh(e, this.refreshToken), this.accessToken)
              : null
            : this.accessToken;
        }
        clearRefreshToken() {
          this.refreshToken = null;
        }
        async refresh(e, t) {
          let {
            accessToken: i,
            refreshToken: n,
            expiresIn: r,
          } = await eu(e, t);
          this.updateTokensAndExpiration(i, n, Number(r));
        }
        updateTokensAndExpiration(e, t, i) {
          (this.refreshToken = t || null),
            (this.accessToken = e || null),
            (this.expirationTime = Date.now() + 1e3 * i);
        }
        static fromJSON(e, t) {
          let { refreshToken: i, accessToken: n, expirationTime: r } = t,
            s = new ed();
          return (
            i &&
              (k("string" == typeof i, "internal-error", { appName: e }),
              (s.refreshToken = i)),
            n &&
              (k("string" == typeof n, "internal-error", { appName: e }),
              (s.accessToken = n)),
            r &&
              (k("number" == typeof r, "internal-error", { appName: e }),
              (s.expirationTime = r)),
            s
          );
        }
        toJSON() {
          return {
            refreshToken: this.refreshToken,
            accessToken: this.accessToken,
            expirationTime: this.expirationTime,
          };
        }
        _assign(e) {
          (this.accessToken = e.accessToken),
            (this.refreshToken = e.refreshToken),
            (this.expirationTime = e.expirationTime);
        }
        _clone() {
          return Object.assign(new ed(), this.toJSON());
        }
        _performRefresh() {
          return R("not implemented");
        }
      }
      function ep(e, t) {
        k("string" == typeof e || void 0 === e, "internal-error", {
          appName: t,
        });
      }
      class em {
        constructor({ uid: e, auth: t, stsTokenManager: i, ...n }) {
          (this.providerId = "firebase"),
            (this.proactiveRefresh = new es(this)),
            (this.reloadUserInfo = null),
            (this.reloadListener = null),
            (this.uid = e),
            (this.auth = t),
            (this.stsTokenManager = i),
            (this.accessToken = i.accessToken),
            (this.displayName = n.displayName || null),
            (this.email = n.email || null),
            (this.emailVerified = n.emailVerified || !1),
            (this.phoneNumber = n.phoneNumber || null),
            (this.photoURL = n.photoURL || null),
            (this.isAnonymous = n.isAnonymous || !1),
            (this.tenantId = n.tenantId || null),
            (this.providerData = n.providerData ? [...n.providerData] : []),
            (this.metadata = new ea(
              n.createdAt || void 0,
              n.lastLoginAt || void 0
            ));
        }
        async getIdToken(e) {
          let t = await er(this, this.stsTokenManager.getToken(this.auth, e));
          return (
            k(t, this.auth, "internal-error"),
            this.accessToken !== t &&
              ((this.accessToken = t),
              await this.auth._persistUserIfCurrent(this),
              this.auth._notifyListenersIfCurrent(this)),
            t
          );
        }
        getIdTokenResult(e) {
          return ee(this, e);
        }
        reload() {
          return ec(this);
        }
        _assign(e) {
          this !== e &&
            (k(this.uid === e.uid, this.auth, "internal-error"),
            (this.displayName = e.displayName),
            (this.photoURL = e.photoURL),
            (this.email = e.email),
            (this.emailVerified = e.emailVerified),
            (this.phoneNumber = e.phoneNumber),
            (this.isAnonymous = e.isAnonymous),
            (this.tenantId = e.tenantId),
            (this.providerData = e.providerData.map((e) => ({ ...e }))),
            this.metadata._copy(e.metadata),
            this.stsTokenManager._assign(e.stsTokenManager));
        }
        _clone(e) {
          let t = new em({
            ...this,
            auth: e,
            stsTokenManager: this.stsTokenManager._clone(),
          });
          return t.metadata._copy(this.metadata), t;
        }
        _onReload(e) {
          k(!this.reloadListener, this.auth, "internal-error"),
            (this.reloadListener = e),
            this.reloadUserInfo &&
              (this._notifyReloadListener(this.reloadUserInfo),
              (this.reloadUserInfo = null));
        }
        _notifyReloadListener(e) {
          this.reloadListener
            ? this.reloadListener(e)
            : (this.reloadUserInfo = e);
        }
        _startProactiveRefresh() {
          this.proactiveRefresh._start();
        }
        _stopProactiveRefresh() {
          this.proactiveRefresh._stop();
        }
        async _updateTokensIfNecessary(e, t = !1) {
          let i = !1;
          e.idToken &&
            e.idToken !== this.stsTokenManager.accessToken &&
            (this.stsTokenManager.updateFromServerResponse(e), (i = !0)),
            t && (await eo(this)),
            await this.auth._persistUserIfCurrent(this),
            i && this.auth._notifyListenersIfCurrent(this);
        }
        async delete() {
          if ((0, r.xZ)(this.auth.app)) return Promise.reject(w(this.auth));
          let e = await this.getIdToken();
          return (
            await er(this, J(this.auth, { idToken: e })),
            this.stsTokenManager.clearRefreshToken(),
            this.auth.signOut()
          );
        }
        toJSON() {
          return {
            uid: this.uid,
            email: this.email || void 0,
            emailVerified: this.emailVerified,
            displayName: this.displayName || void 0,
            isAnonymous: this.isAnonymous,
            photoURL: this.photoURL || void 0,
            phoneNumber: this.phoneNumber || void 0,
            tenantId: this.tenantId || void 0,
            providerData: this.providerData.map((e) => ({ ...e })),
            stsTokenManager: this.stsTokenManager.toJSON(),
            _redirectEventId: this._redirectEventId,
            ...this.metadata.toJSON(),
            apiKey: this.auth.config.apiKey,
            appName: this.auth.name,
          };
        }
        get refreshToken() {
          return this.stsTokenManager.refreshToken || "";
        }
        static _fromJSON(e, t) {
          let i = t.displayName ?? void 0,
            n = t.email ?? void 0,
            r = t.phoneNumber ?? void 0,
            s = t.photoURL ?? void 0,
            a = t.tenantId ?? void 0,
            o = t._redirectEventId ?? void 0,
            c = t.createdAt ?? void 0,
            l = t.lastLoginAt ?? void 0,
            {
              uid: u,
              emailVerified: h,
              isAnonymous: d,
              providerData: p,
              stsTokenManager: m,
            } = t;
          k(u && m, e, "internal-error");
          let f = ed.fromJSON(this.name, m);
          k("string" == typeof u, e, "internal-error"),
            ep(i, e.name),
            ep(n, e.name),
            k("boolean" == typeof h, e, "internal-error"),
            k("boolean" == typeof d, e, "internal-error"),
            ep(r, e.name),
            ep(s, e.name),
            ep(a, e.name),
            ep(o, e.name),
            ep(c, e.name),
            ep(l, e.name);
          let g = new em({
            uid: u,
            auth: e,
            email: n,
            emailVerified: h,
            displayName: i,
            isAnonymous: d,
            photoURL: s,
            phoneNumber: r,
            tenantId: a,
            stsTokenManager: f,
            createdAt: c,
            lastLoginAt: l,
          });
          return (
            p &&
              Array.isArray(p) &&
              (g.providerData = p.map((e) => ({ ...e }))),
            o && (g._redirectEventId = o),
            g
          );
        }
        static async _fromIdTokenResponse(e, t, i = !1) {
          let n = new ed();
          n.updateFromServerResponse(t);
          let r = new em({
            uid: t.localId,
            auth: e,
            stsTokenManager: n,
            isAnonymous: i,
          });
          return await eo(r), r;
        }
        static async _fromGetAccountInfoResponse(e, t, i) {
          let n = t.users[0];
          k(void 0 !== n.localId, "internal-error");
          let r = void 0 !== n.providerUserInfo ? el(n.providerUserInfo) : [],
            s = !(n.email && n.passwordHash) && !r?.length,
            a = new ed();
          a.updateFromIdToken(i);
          let o = new em({
            uid: n.localId,
            auth: e,
            stsTokenManager: a,
            isAnonymous: s,
          });
          return (
            Object.assign(o, {
              uid: n.localId,
              displayName: n.displayName || null,
              photoURL: n.photoUrl || null,
              email: n.email || null,
              emailVerified: n.emailVerified || !1,
              phoneNumber: n.phoneNumber || null,
              tenantId: n.tenantId || null,
              providerData: r,
              metadata: new ea(n.createdAt, n.lastLoginAt),
              isAnonymous: !(n.email && n.passwordHash) && !r?.length,
            }),
            o
          );
        }
      }
      let ef = new Map();
      function eg(e) {
        var t, i;
        (t = "Expected a class definition"), e instanceof Function || R(t);
        let n = ef.get(e);
        return (
          n
            ? ((i = "Instance stored in cache mismatched with class"),
              n instanceof e || R(i))
            : ((n = new e()), ef.set(e, n)),
          n
        );
      }
      class eI {
        constructor() {
          (this.type = "NONE"), (this.storage = {});
        }
        async _isAvailable() {
          return !0;
        }
        async _set(e, t) {
          this.storage[e] = t;
        }
        async _get(e) {
          let t = this.storage[e];
          return void 0 === t ? null : t;
        }
        async _remove(e) {
          delete this.storage[e];
        }
        _addListener(e, t) {}
        _removeListener(e, t) {}
      }
      eI.type = "NONE";
      let e_ = eI;
      function ev(e, t, i) {
        return `firebase:${e}:${t}:${i}`;
      }
      class eT {
        constructor(e, t, i) {
          (this.persistence = e), (this.auth = t), (this.userKey = i);
          const { config: n, name: r } = this.auth;
          (this.fullUserKey = ev(this.userKey, n.apiKey, r)),
            (this.fullPersistenceKey = ev("persistence", n.apiKey, r)),
            (this.boundEventHandler = t._onStorageEvent.bind(t)),
            this.persistence._addListener(
              this.fullUserKey,
              this.boundEventHandler
            );
        }
        setCurrentUser(e) {
          return this.persistence._set(this.fullUserKey, e.toJSON());
        }
        async getCurrentUser() {
          let e = await this.persistence._get(this.fullUserKey);
          if (!e) return null;
          if ("string" == typeof e) {
            let t = await Z(this.auth, { idToken: e }).catch(() => void 0);
            return t ? em._fromGetAccountInfoResponse(this.auth, t, e) : null;
          }
          return em._fromJSON(this.auth, e);
        }
        removeCurrentUser() {
          return this.persistence._remove(this.fullUserKey);
        }
        savePersistenceForRedirect() {
          return this.persistence._set(
            this.fullPersistenceKey,
            this.persistence.type
          );
        }
        async setPersistence(e) {
          if (this.persistence === e) return;
          let t = await this.getCurrentUser();
          if ((await this.removeCurrentUser(), (this.persistence = e), t))
            return this.setCurrentUser(t);
        }
        delete() {
          this.persistence._removeListener(
            this.fullUserKey,
            this.boundEventHandler
          );
        }
        static async create(e, t, i = "authUser") {
          if (!t.length) return new eT(eg(e_), e, i);
          let n = (
              await Promise.all(
                t.map(async (e) => {
                  if (await e._isAvailable()) return e;
                })
              )
            ).filter((e) => e),
            r = n[0] || eg(e_),
            s = ev(i, e.config.apiKey, e.name),
            a = null;
          for (let i of t)
            try {
              let t = await i._get(s);
              if (t) {
                let n;
                if ("string" == typeof t) {
                  let i = await Z(e, { idToken: t }).catch(() => void 0);
                  if (!i) break;
                  n = await em._fromGetAccountInfoResponse(e, i, t);
                } else n = em._fromJSON(e, t);
                i !== r && (a = n), (r = i);
                break;
              }
            } catch {}
          let o = n.filter((e) => e._shouldAllowMigration);
          return (
            r._shouldAllowMigration &&
              o.length &&
              ((r = o[0]),
              a && (await r._set(s, a.toJSON())),
              await Promise.all(
                t.map(async (e) => {
                  if (e !== r)
                    try {
                      await e._remove(s);
                    } catch {}
                })
              )),
            new eT(r, e, i)
          );
        }
      }
      function eE(e) {
        let t = e.toLowerCase();
        if (t.includes("opera/") || t.includes("opr/") || t.includes("opios/"))
          return "Opera";
        {
          if (eS(t)) return "IEMobile";
          if (t.includes("msie") || t.includes("trident/")) return "IE";
          if (t.includes("edge/")) return "Edge";
          if (ey(t)) return "Firefox";
          if (t.includes("silk/")) return "Silk";
          if (eR(t)) return "Blackberry";
          if (eP(t)) return "Webos";
          if (ew(t)) return "Safari";
          if ((t.includes("chrome/") || eA(t)) && !t.includes("edge/"))
            return "Chrome";
          if (ek(t)) return "Android";
          let i = e.match(/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/);
          if (i?.length === 2) return i[1];
        }
        return "Other";
      }
      function ey(e = (0, s.ZQ)()) {
        return /firefox\//i.test(e);
      }
      function ew(e = (0, s.ZQ)()) {
        let t = e.toLowerCase();
        return (
          t.includes("safari/") &&
          !t.includes("chrome/") &&
          !t.includes("crios/") &&
          !t.includes("android")
        );
      }
      function eA(e = (0, s.ZQ)()) {
        return /crios\//i.test(e);
      }
      function eS(e = (0, s.ZQ)()) {
        return /iemobile/i.test(e);
      }
      function ek(e = (0, s.ZQ)()) {
        return /android/i.test(e);
      }
      function eR(e = (0, s.ZQ)()) {
        return /blackberry/i.test(e);
      }
      function eP(e = (0, s.ZQ)()) {
        return /webos/i.test(e);
      }
      function eN(e = (0, s.ZQ)()) {
        return (
          /iphone|ipad|ipod/i.test(e) ||
          (/macintosh/i.test(e) && /mobile/i.test(e))
        );
      }
      function eO(e = (0, s.ZQ)()) {
        return (
          eN(e) || ek(e) || eP(e) || eR(e) || /windows phone/i.test(e) || eS(e)
        );
      }
      function eb(e, t = []) {
        let i;
        switch (e) {
          case "Browser":
            i = eE((0, s.ZQ)());
            break;
          case "Worker":
            i = `${eE((0, s.ZQ)())}-${e}`;
            break;
          default:
            i = e;
        }
        let n = t.length ? t.join(",") : "FirebaseCore-web";
        return `${i}/JsCore/${r.MF}/${n}`;
      }
      class eC {
        constructor(e) {
          (this.auth = e), (this.queue = []);
        }
        pushCallback(e, t) {
          let i = (t) =>
            new Promise((i, n) => {
              try {
                let n = e(t);
                i(n);
              } catch (e) {
                n(e);
              }
            });
          (i.onAbort = t), this.queue.push(i);
          let n = this.queue.length - 1;
          return () => {
            this.queue[n] = () => Promise.resolve();
          };
        }
        async runMiddleware(e) {
          if (this.auth.currentUser === e) return;
          let t = [];
          try {
            for (let i of this.queue)
              await i(e), i.onAbort && t.push(i.onAbort);
          } catch (e) {
            for (let e of (t.reverse(), t))
              try {
                e();
              } catch (e) {}
            throw this.auth._errorFactory.create("login-blocked", {
              originalMessage: e?.message,
            });
          }
        }
      }
      async function eD(e, t = {}) {
        return V(e, "GET", "/v2/passwordPolicy", F(e, t));
      }
      class eL {
        constructor(e) {
          const t = e.customStrengthOptions;
          (this.customStrengthOptions = {}),
            (this.customStrengthOptions.minPasswordLength =
              t.minPasswordLength ?? 6),
            t.maxPasswordLength &&
              (this.customStrengthOptions.maxPasswordLength =
                t.maxPasswordLength),
            void 0 !== t.containsLowercaseCharacter &&
              (this.customStrengthOptions.containsLowercaseLetter =
                t.containsLowercaseCharacter),
            void 0 !== t.containsUppercaseCharacter &&
              (this.customStrengthOptions.containsUppercaseLetter =
                t.containsUppercaseCharacter),
            void 0 !== t.containsNumericCharacter &&
              (this.customStrengthOptions.containsNumericCharacter =
                t.containsNumericCharacter),
            void 0 !== t.containsNonAlphanumericCharacter &&
              (this.customStrengthOptions.containsNonAlphanumericCharacter =
                t.containsNonAlphanumericCharacter),
            (this.enforcementState = e.enforcementState),
            "ENFORCEMENT_STATE_UNSPECIFIED" === this.enforcementState &&
              (this.enforcementState = "OFF"),
            (this.allowedNonAlphanumericCharacters =
              e.allowedNonAlphanumericCharacters?.join("") ?? ""),
            (this.forceUpgradeOnSignin = e.forceUpgradeOnSignin ?? !1),
            (this.schemaVersion = e.schemaVersion);
        }
        validatePassword(e) {
          let t = { isValid: !0, passwordPolicy: this };
          return (
            this.validatePasswordLengthOptions(e, t),
            this.validatePasswordCharacterOptions(e, t),
            t.isValid && (t.isValid = t.meetsMinPasswordLength ?? !0),
            t.isValid && (t.isValid = t.meetsMaxPasswordLength ?? !0),
            t.isValid && (t.isValid = t.containsLowercaseLetter ?? !0),
            t.isValid && (t.isValid = t.containsUppercaseLetter ?? !0),
            t.isValid && (t.isValid = t.containsNumericCharacter ?? !0),
            t.isValid && (t.isValid = t.containsNonAlphanumericCharacter ?? !0),
            t
          );
        }
        validatePasswordLengthOptions(e, t) {
          let i = this.customStrengthOptions.minPasswordLength,
            n = this.customStrengthOptions.maxPasswordLength;
          i && (t.meetsMinPasswordLength = e.length >= i),
            n && (t.meetsMaxPasswordLength = e.length <= n);
        }
        validatePasswordCharacterOptions(e, t) {
          let i;
          this.updatePasswordCharacterOptionsStatuses(t, !1, !1, !1, !1);
          for (let n = 0; n < e.length; n++)
            (i = e.charAt(n)),
              this.updatePasswordCharacterOptionsStatuses(
                t,
                i >= "a" && i <= "z",
                i >= "A" && i <= "Z",
                i >= "0" && i <= "9",
                this.allowedNonAlphanumericCharacters.includes(i)
              );
        }
        updatePasswordCharacterOptionsStatuses(e, t, i, n, r) {
          this.customStrengthOptions.containsLowercaseLetter &&
            (e.containsLowercaseLetter || (e.containsLowercaseLetter = t)),
            this.customStrengthOptions.containsUppercaseLetter &&
              (e.containsUppercaseLetter || (e.containsUppercaseLetter = i)),
            this.customStrengthOptions.containsNumericCharacter &&
              (e.containsNumericCharacter || (e.containsNumericCharacter = n)),
            this.customStrengthOptions.containsNonAlphanumericCharacter &&
              (e.containsNonAlphanumericCharacter ||
                (e.containsNonAlphanumericCharacter = r));
        }
      }
      class eM {
        constructor(e, t, i, n) {
          (this.app = e),
            (this.heartbeatServiceProvider = t),
            (this.appCheckServiceProvider = i),
            (this.config = n),
            (this.currentUser = null),
            (this.emulatorConfig = null),
            (this.operations = Promise.resolve()),
            (this.authStateSubscription = new eF(this)),
            (this.idTokenSubscription = new eF(this)),
            (this.beforeStateQueue = new eC(this)),
            (this.redirectUser = null),
            (this.isProactiveRefreshEnabled = !1),
            (this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION = 1),
            (this._canInitEmulator = !0),
            (this._isInitialized = !1),
            (this._deleted = !1),
            (this._initializationPromise = null),
            (this._popupRedirectResolver = null),
            (this._errorFactory = g),
            (this._agentRecaptchaConfig = null),
            (this._tenantRecaptchaConfigs = {}),
            (this._projectPasswordPolicy = null),
            (this._tenantPasswordPolicies = {}),
            (this._resolvePersistenceManagerAvailable = void 0),
            (this.lastNotifiedUid = void 0),
            (this.languageCode = null),
            (this.tenantId = null),
            (this.settings = { appVerificationDisabledForTesting: !1 }),
            (this.frameworks = []),
            (this.name = e.name),
            (this.clientVersion = n.sdkClientVersion),
            (this._persistenceManagerAvailable = new Promise(
              (e) => (this._resolvePersistenceManagerAvailable = e)
            ));
        }
        _initializeWithPersistence(e, t) {
          return (
            t && (this._popupRedirectResolver = eg(t)),
            (this._initializationPromise = this.queue(async () => {
              if (!this._deleted) {
                if (
                  ((this.persistenceManager = await eT.create(this, e)),
                  this._resolvePersistenceManagerAvailable?.(),
                  !this._deleted)
                ) {
                  if (this._popupRedirectResolver?._shouldInitProactively)
                    try {
                      await this._popupRedirectResolver._initialize(this);
                    } catch (e) {}
                  await this.initializeCurrentUser(t),
                    (this.lastNotifiedUid = this.currentUser?.uid || null),
                    this._deleted || (this._isInitialized = !0);
                }
              }
            })),
            this._initializationPromise
          );
        }
        async _onStorageEvent() {
          if (this._deleted) return;
          let e = await this.assertedPersistence.getCurrentUser();
          if (this.currentUser || e) {
            if (this.currentUser && e && this.currentUser.uid === e.uid) {
              this._currentUser._assign(e), await this.currentUser.getIdToken();
              return;
            }
            await this._updateCurrentUser(e, !0);
          }
        }
        async initializeCurrentUserFromIdToken(e) {
          try {
            let t = await Z(this, { idToken: e }),
              i = await em._fromGetAccountInfoResponse(this, t, e);
            await this.directlySetCurrentUser(i);
          } catch (e) {
            console.warn(
              "FirebaseServerApp could not login user with provided authIdToken: ",
              e
            ),
              await this.directlySetCurrentUser(null);
          }
        }
        async initializeCurrentUser(e) {
          if ((0, r.xZ)(this.app)) {
            let e = this.app.settings.authIdToken;
            return e
              ? new Promise((t) => {
                  setTimeout(() =>
                    this.initializeCurrentUserFromIdToken(e).then(t, t)
                  );
                })
              : this.directlySetCurrentUser(null);
          }
          let t = await this.assertedPersistence.getCurrentUser(),
            i = t,
            n = !1;
          if (e && this.config.authDomain) {
            await this.getOrInitRedirectPersistenceManager();
            let t = this.redirectUser?._redirectEventId,
              r = i?._redirectEventId,
              s = await this.tryRedirectSignIn(e);
            (!t || t === r) && s?.user && ((i = s.user), (n = !0));
          }
          if (!i) return this.directlySetCurrentUser(null);
          if (!i._redirectEventId) {
            if (n)
              try {
                await this.beforeStateQueue.runMiddleware(i);
              } catch (e) {
                (i = t),
                  this._popupRedirectResolver._overrideRedirectResult(
                    this,
                    () => Promise.reject(e)
                  );
              }
            return i
              ? this.reloadAndSetCurrentUserOrClear(i)
              : this.directlySetCurrentUser(null);
          }
          return (k(this._popupRedirectResolver, this, "argument-error"),
          await this.getOrInitRedirectPersistenceManager(),
          this.redirectUser &&
            this.redirectUser._redirectEventId === i._redirectEventId)
            ? this.directlySetCurrentUser(i)
            : this.reloadAndSetCurrentUserOrClear(i);
        }
        async tryRedirectSignIn(e) {
          let t = null;
          try {
            t = await this._popupRedirectResolver._completeRedirectFn(
              this,
              e,
              !0
            );
          } catch (e) {
            await this._setRedirectUser(null);
          }
          return t;
        }
        async reloadAndSetCurrentUserOrClear(e) {
          try {
            await eo(e);
          } catch (e) {
            if (e?.code !== "auth/network-request-failed")
              return this.directlySetCurrentUser(null);
          }
          return this.directlySetCurrentUser(e);
        }
        useDeviceLanguage() {
          this.languageCode = (function () {
            if ("u" < typeof navigator) return null;
            let e = navigator;
            return (e.languages && e.languages[0]) || e.language || null;
          })();
        }
        async _delete() {
          this._deleted = !0;
        }
        async updateCurrentUser(e) {
          if ((0, r.xZ)(this.app)) return Promise.reject(w(this));
          let t = e ? (0, s.Ku)(e) : null;
          return (
            t &&
              k(
                t.auth.config.apiKey === this.config.apiKey,
                this,
                "invalid-user-token"
              ),
            this._updateCurrentUser(t && t._clone(this))
          );
        }
        async _updateCurrentUser(e, t = !1) {
          if (!this._deleted)
            return (
              e && k(this.tenantId === e.tenantId, this, "tenant-id-mismatch"),
              t || (await this.beforeStateQueue.runMiddleware(e)),
              this.queue(async () => {
                await this.directlySetCurrentUser(e),
                  this.notifyAuthListeners();
              })
            );
        }
        async signOut() {
          return (0, r.xZ)(this.app)
            ? Promise.reject(w(this))
            : (await this.beforeStateQueue.runMiddleware(null),
              (this.redirectPersistenceManager ||
                this._popupRedirectResolver) &&
                (await this._setRedirectUser(null)),
              this._updateCurrentUser(null, !0));
        }
        setPersistence(e) {
          return (0, r.xZ)(this.app)
            ? Promise.reject(w(this))
            : this.queue(async () => {
                await this.assertedPersistence.setPersistence(eg(e));
              });
        }
        _getRecaptchaConfig() {
          return null == this.tenantId
            ? this._agentRecaptchaConfig
            : this._tenantRecaptchaConfigs[this.tenantId];
        }
        async validatePassword(e) {
          this._getPasswordPolicyInternal() ||
            (await this._updatePasswordPolicy());
          let t = this._getPasswordPolicyInternal();
          return t.schemaVersion !==
            this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION
            ? Promise.reject(
                this._errorFactory.create(
                  "unsupported-password-policy-schema-version",
                  {}
                )
              )
            : t.validatePassword(e);
        }
        _getPasswordPolicyInternal() {
          return null === this.tenantId
            ? this._projectPasswordPolicy
            : this._tenantPasswordPolicies[this.tenantId];
        }
        async _updatePasswordPolicy() {
          let e = new eL(await eD(this));
          null === this.tenantId
            ? (this._projectPasswordPolicy = e)
            : (this._tenantPasswordPolicies[this.tenantId] = e);
        }
        _getPersistenceType() {
          return this.assertedPersistence.persistence.type;
        }
        _getPersistence() {
          return this.assertedPersistence.persistence;
        }
        _updateErrorMap(e) {
          this._errorFactory = new s.FA("auth", "Firebase", e());
        }
        onAuthStateChanged(e, t, i) {
          return this.registerStateListener(
            this.authStateSubscription,
            e,
            t,
            i
          );
        }
        beforeAuthStateChanged(e, t) {
          return this.beforeStateQueue.pushCallback(e, t);
        }
        onIdTokenChanged(e, t, i) {
          return this.registerStateListener(this.idTokenSubscription, e, t, i);
        }
        authStateReady() {
          return new Promise((e, t) => {
            if (this.currentUser) e();
            else {
              let i = this.onAuthStateChanged(() => {
                i(), e();
              }, t);
            }
          });
        }
        async revokeAccessToken(e) {
          if (this.currentUser) {
            let t = {
              providerId: "apple.com",
              tokenType: "ACCESS_TOKEN",
              token: e,
              idToken: await this.currentUser.getIdToken(),
            };
            null != this.tenantId && (t.tenantId = this.tenantId),
              await eh(this, t);
          }
        }
        toJSON() {
          return {
            apiKey: this.config.apiKey,
            authDomain: this.config.authDomain,
            appName: this.name,
            currentUser: this._currentUser?.toJSON(),
          };
        }
        async _setRedirectUser(e, t) {
          let i = await this.getOrInitRedirectPersistenceManager(t);
          return null === e ? i.removeCurrentUser() : i.setCurrentUser(e);
        }
        async getOrInitRedirectPersistenceManager(e) {
          if (!this.redirectPersistenceManager) {
            let t = (e && eg(e)) || this._popupRedirectResolver;
            k(t, this, "argument-error"),
              (this.redirectPersistenceManager = await eT.create(
                this,
                [eg(t._redirectPersistence)],
                "redirectUser"
              )),
              (this.redirectUser =
                await this.redirectPersistenceManager.getCurrentUser());
          }
          return this.redirectPersistenceManager;
        }
        async _redirectUserForId(e) {
          return (this._isInitialized && (await this.queue(async () => {})),
          this._currentUser?._redirectEventId === e)
            ? this._currentUser
            : this.redirectUser?._redirectEventId === e
            ? this.redirectUser
            : null;
        }
        async _persistUserIfCurrent(e) {
          if (e === this.currentUser)
            return this.queue(async () => this.directlySetCurrentUser(e));
        }
        _notifyListenersIfCurrent(e) {
          e === this.currentUser && this.notifyAuthListeners();
        }
        _key() {
          return `${this.config.authDomain}:${this.config.apiKey}:${this.name}`;
        }
        _startProactiveRefresh() {
          (this.isProactiveRefreshEnabled = !0),
            this.currentUser && this._currentUser._startProactiveRefresh();
        }
        _stopProactiveRefresh() {
          (this.isProactiveRefreshEnabled = !1),
            this.currentUser && this._currentUser._stopProactiveRefresh();
        }
        get _currentUser() {
          return this.currentUser;
        }
        notifyAuthListeners() {
          if (!this._isInitialized) return;
          this.idTokenSubscription.next(this.currentUser);
          let e = this.currentUser?.uid ?? null;
          this.lastNotifiedUid !== e &&
            ((this.lastNotifiedUid = e),
            this.authStateSubscription.next(this.currentUser));
        }
        registerStateListener(e, t, i, n) {
          if (this._deleted) return () => {};
          let r = "function" == typeof t ? t : t.next.bind(t),
            s = !1,
            a = this._isInitialized
              ? Promise.resolve()
              : this._initializationPromise;
          if (
            (k(a, this, "internal-error"),
            a.then(() => {
              s || r(this.currentUser);
            }),
            "function" == typeof t)
          ) {
            let r = e.addObserver(t, i, n);
            return () => {
              (s = !0), r();
            };
          }
          {
            let i = e.addObserver(t);
            return () => {
              (s = !0), i();
            };
          }
        }
        async directlySetCurrentUser(e) {
          this.currentUser &&
            this.currentUser !== e &&
            this._currentUser._stopProactiveRefresh(),
            e && this.isProactiveRefreshEnabled && e._startProactiveRefresh(),
            (this.currentUser = e),
            e
              ? await this.assertedPersistence.setCurrentUser(e)
              : await this.assertedPersistence.removeCurrentUser();
        }
        queue(e) {
          return (
            (this.operations = this.operations.then(e, e)), this.operations
          );
        }
        get assertedPersistence() {
          return (
            k(this.persistenceManager, this, "internal-error"),
            this.persistenceManager
          );
        }
        _logFramework(e) {
          !e ||
            this.frameworks.includes(e) ||
            (this.frameworks.push(e),
            this.frameworks.sort(),
            (this.clientVersion = eb(
              this.config.clientPlatform,
              this._getFrameworks()
            )));
        }
        _getFrameworks() {
          return this.frameworks;
        }
        async _getAdditionalHeaders() {
          let e = { "X-Client-Version": this.clientVersion };
          this.app.options.appId &&
            (e["X-Firebase-gmpid"] = this.app.options.appId);
          let t = await this.heartbeatServiceProvider
            .getImmediate({ optional: !0 })
            ?.getHeartbeatsHeader();
          t && (e["X-Firebase-Client"] = t);
          let i = await this._getAppCheckToken();
          return i && (e["X-Firebase-AppCheck"] = i), e;
        }
        async _getAppCheckToken() {
          if ((0, r.xZ)(this.app) && this.app.settings.appCheckToken)
            return this.app.settings.appCheckToken;
          let e = await this.appCheckServiceProvider
            .getImmediate({ optional: !0 })
            ?.getToken();
          return (
            e?.error &&
              (function (e, ...t) {
                _.logLevel <= a.$b.WARN && _.warn(`Auth (${r.MF}): ${e}`, ...t);
              })(`Error while retrieving App Check token: ${e.error}`),
            e?.token
          );
        }
      }
      function eU(e) {
        return (0, s.Ku)(e);
      }
      class eF {
        constructor(e) {
          (this.auth = e),
            (this.observer = null),
            (this.addObserver = (0, s.tD)((e) => (this.observer = e)));
        }
        get next() {
          return (
            k(this.observer, this.auth, "internal-error"),
            this.observer.next.bind(this.observer)
          );
        }
      }
      let eV = {
        async loadJS() {
          throw Error("Unable to load external scripts");
        },
        recaptchaV2Script: "",
        recaptchaEnterpriseScript: "",
        gapiScript: "",
      };
      function ex(e) {
        return eV.loadJS(e);
      }
      function eH(e) {
        return `__${e}${Math.floor(1e6 * Math.random())}`;
      }
      class eK {
        constructor(e) {
          (this.auth = e), (this.counter = 1e12), (this._widgets = new Map());
        }
        render(e, t) {
          let i = this.counter;
          return (
            this._widgets.set(i, new eW(e, this.auth.name, t || {})),
            this.counter++,
            i
          );
        }
        reset(e) {
          let t = e || 1e12;
          this._widgets.get(t)?.delete(), this._widgets.delete(t);
        }
        getResponse(e) {
          return this._widgets.get(e || 1e12)?.getResponse() || "";
        }
        async execute(e) {
          return this._widgets.get(e || 1e12)?.execute(), "";
        }
      }
      class ej {
        constructor() {
          this.enterprise = new eq();
        }
        ready(e) {
          e();
        }
        execute(e, t) {
          return Promise.resolve("token");
        }
        render(e, t) {
          return "";
        }
      }
      class eq {
        ready(e) {
          e();
        }
        execute(e, t) {
          return Promise.resolve("token");
        }
        render(e, t) {
          return "";
        }
      }
      class eW {
        constructor(e, t, i) {
          (this.params = i),
            (this.timerId = null),
            (this.deleted = !1),
            (this.responseToken = null),
            (this.clickHandler = () => {
              this.execute();
            });
          const n = "string" == typeof e ? document.getElementById(e) : e;
          k(n, "argument-error", { appName: t }),
            (this.container = n),
            (this.isVisible = "invisible" !== this.params.size),
            this.isVisible
              ? this.execute()
              : this.container.addEventListener("click", this.clickHandler);
        }
        getResponse() {
          return this.checkIfDeleted(), this.responseToken;
        }
        delete() {
          this.checkIfDeleted(),
            (this.deleted = !0),
            this.timerId && (clearTimeout(this.timerId), (this.timerId = null)),
            this.container.removeEventListener("click", this.clickHandler);
        }
        execute() {
          this.checkIfDeleted(),
            this.timerId ||
              (this.timerId = window.setTimeout(() => {
                this.responseToken = (function () {
                  let e = [],
                    t =
                      "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
                  for (let i = 0; i < 50; i++)
                    e.push(t.charAt(Math.floor(Math.random() * t.length)));
                  return e.join("");
                })();
                let { callback: e, "expired-callback": t } = this.params;
                if (e)
                  try {
                    e(this.responseToken);
                  } catch (e) {}
                this.timerId = window.setTimeout(() => {
                  if (((this.timerId = null), (this.responseToken = null), t))
                    try {
                      t();
                    } catch (e) {}
                  this.isVisible && this.execute();
                }, 6e4);
              }, 500));
        }
        checkIfDeleted() {
          if (this.deleted) throw Error("reCAPTCHA mock was already deleted!");
        }
      }
      let ez = "NO_RECAPTCHA";
      class eG {
        constructor(e) {
          (this.type = "recaptcha-enterprise"), (this.auth = eU(e));
        }
        async verify(e = "verify", t = !1) {
          async function i(e) {
            if (!t) {
              if (null == e.tenantId && null != e._agentRecaptchaConfig)
                return e._agentRecaptchaConfig.siteKey;
              if (
                null != e.tenantId &&
                void 0 !== e._tenantRecaptchaConfigs[e.tenantId]
              )
                return e._tenantRecaptchaConfigs[e.tenantId].siteKey;
            }
            return new Promise(async (t, i) => {
              B(e, {
                clientType: "CLIENT_TYPE_WEB",
                version: "RECAPTCHA_ENTERPRISE",
              })
                .then((n) => {
                  if (void 0 === n.recaptchaKey)
                    i(Error("recaptcha Enterprise site key undefined"));
                  else {
                    let i = new G(n);
                    return (
                      null == e.tenantId
                        ? (e._agentRecaptchaConfig = i)
                        : (e._tenantRecaptchaConfigs[e.tenantId] = i),
                      t(i.siteKey)
                    );
                  }
                })
                .catch((e) => {
                  i(e);
                });
            });
          }
          function n(t, i, n) {
            let r = window.grecaptcha;
            z(r)
              ? r.enterprise.ready(() => {
                  r.enterprise
                    .execute(t, { action: e })
                    .then((e) => {
                      i(e);
                    })
                    .catch(() => {
                      i(ez);
                    });
                })
              : n(Error("No reCAPTCHA enterprise script loaded."));
          }
          return this.auth.settings.appVerificationDisabledForTesting
            ? new ej().execute("siteKey", { action: "verify" })
            : new Promise((e, r) => {
                i(this.auth)
                  .then((i) => {
                    if (!t && z(window.grecaptcha)) n(i, e, r);
                    else {
                      if ("u" < typeof window)
                        return void r(
                          Error(
                            "RecaptchaVerifier is only supported in browser"
                          )
                        );
                      let t = eV.recaptchaEnterpriseScript;
                      0 !== t.length && (t += i),
                        ex(t)
                          .then(() => {
                            n(i, e, r);
                          })
                          .catch((e) => {
                            r(e);
                          });
                    }
                  })
                  .catch((e) => {
                    r(e);
                  });
              });
        }
      }
      async function e$(e, t, i, n = !1, r = !1) {
        let s,
          a = new eG(e);
        if (r) s = ez;
        else
          try {
            s = await a.verify(i);
          } catch (e) {
            s = await a.verify(i, !0);
          }
        let o = { ...t };
        if ("mfaSmsEnrollment" === i || "mfaSmsSignIn" === i) {
          if ("phoneEnrollmentInfo" in o) {
            let e = o.phoneEnrollmentInfo.phoneNumber,
              t = o.phoneEnrollmentInfo.recaptchaToken;
            Object.assign(o, {
              phoneEnrollmentInfo: {
                phoneNumber: e,
                recaptchaToken: t,
                captchaResponse: s,
                clientType: "CLIENT_TYPE_WEB",
                recaptchaVersion: "RECAPTCHA_ENTERPRISE",
              },
            });
          } else if ("phoneSignInInfo" in o) {
            let e = o.phoneSignInInfo.recaptchaToken;
            Object.assign(o, {
              phoneSignInInfo: {
                recaptchaToken: e,
                captchaResponse: s,
                clientType: "CLIENT_TYPE_WEB",
                recaptchaVersion: "RECAPTCHA_ENTERPRISE",
              },
            });
          }
          return o;
        }
        return (
          n
            ? Object.assign(o, { captchaResp: s })
            : Object.assign(o, { captchaResponse: s }),
          Object.assign(o, { clientType: "CLIENT_TYPE_WEB" }),
          Object.assign(o, { recaptchaVersion: "RECAPTCHA_ENTERPRISE" }),
          o
        );
      }
      async function eB(e, t, i, n, r) {
        if ("EMAIL_PASSWORD_PROVIDER" === r)
          if (
            !e
              ._getRecaptchaConfig()
              ?.isProviderEnabled("EMAIL_PASSWORD_PROVIDER")
          )
            return n(e, t).catch(async (r) => {
              if ("auth/missing-recaptcha-token" !== r.code)
                return Promise.reject(r);
              {
                console.log(
                  `${i} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`
                );
                let r = await e$(e, t, i, "getOobCode" === i);
                return n(e, r);
              }
            });
          else {
            let r = await e$(e, t, i, "getOobCode" === i);
            return n(e, r);
          }
        if ("PHONE_PROVIDER" !== r)
          return Promise.reject(r + " provider is not supported.");
        if (e._getRecaptchaConfig()?.isProviderEnabled("PHONE_PROVIDER")) {
          let r = await e$(e, t, i);
          return n(e, r).catch(async (r) => {
            if (
              e
                ._getRecaptchaConfig()
                ?.getProviderEnforcementState("PHONE_PROVIDER") === "AUDIT" &&
              ("auth/missing-recaptcha-token" === r.code ||
                "auth/invalid-app-credential" === r.code)
            ) {
              console.log(
                `Failed to verify with reCAPTCHA Enterprise. Automatically triggering the reCAPTCHA v2 flow to complete the ${i} flow.`
              );
              let r = await e$(e, t, i, !1, !0);
              return n(e, r);
            }
            return Promise.reject(r);
          });
        }
        {
          let r = await e$(e, t, i, !1, !0);
          return n(e, r);
        }
      }
      async function eJ(e) {
        let t = eU(e),
          i = new G(
            await B(t, {
              clientType: "CLIENT_TYPE_WEB",
              version: "RECAPTCHA_ENTERPRISE",
            })
          );
        null == t.tenantId
          ? (t._agentRecaptchaConfig = i)
          : (t._tenantRecaptchaConfigs[t.tenantId] = i),
          i.isAnyProviderEnabled() && new eG(t).verify();
      }
      function eY(e, t) {
        let i = (0, r.j6)(e, "auth");
        if (i.isInitialized()) {
          let e = i.getImmediate(),
            n = i.getOptions();
          if ((0, s.bD)(n, t ?? {})) return e;
          T(e, "already-initialized");
        }
        return i.initialize({ options: t });
      }
      function eZ(e, t, i) {
        let n = eU(e);
        k(/^https?:\/\//.test(t), n, "invalid-emulator-scheme");
        let r = !!i?.disableWarnings,
          a = eQ(t),
          { host: o, port: c } = (function (e) {
            let t = eQ(e),
              i = /(\/\/)?([^?#/]+)/.exec(e.substr(t.length));
            if (!i) return { host: "", port: null };
            let n = i[2].split("@").pop() || "",
              r = /^(\[[^\]]+\])(:|$)/.exec(n);
            if (r) {
              let e = r[1];
              return { host: e, port: eX(n.substr(e.length + 1)) };
            }
            {
              let [e, t] = n.split(":");
              return { host: e, port: eX(t) };
            }
          })(t),
          l = null === c ? "" : `:${c}`,
          u = { url: `${a}//${o}${l}/` },
          h = Object.freeze({
            host: o,
            port: c,
            protocol: a.replace(":", ""),
            options: Object.freeze({ disableWarnings: r }),
          });
        if (!n._canInitEmulator) {
          k(n.config.emulator && n.emulatorConfig, n, "emulator-config-failed"),
            k(
              (0, s.bD)(u, n.config.emulator) && (0, s.bD)(h, n.emulatorConfig),
              n,
              "emulator-config-failed"
            );
          return;
        }
        (n.config.emulator = u),
          (n.emulatorConfig = h),
          (n.settings.appVerificationDisabledForTesting = !0),
          (0, s.zJ)(o)
            ? ((0, s.gE)(`${a}//${o}${l}`), (0, s.P1)("Auth", !0))
            : r ||
              (function () {
                function e() {
                  let e = document.createElement("p"),
                    t = e.style;
                  (e.innerText =
                    "Running in emulator mode. Do not use with production credentials."),
                    (t.position = "fixed"),
                    (t.width = "100%"),
                    (t.backgroundColor = "#ffffff"),
                    (t.border = ".1em solid #000000"),
                    (t.color = "#b50000"),
                    (t.bottom = "0px"),
                    (t.left = "0px"),
                    (t.margin = "0px"),
                    (t.zIndex = "10000"),
                    (t.textAlign = "center"),
                    e.classList.add("firebase-emulator-warning"),
                    document.body.appendChild(e);
                }
                "u" > typeof console &&
                  "function" == typeof console.info &&
                  console.info(
                    "WARNING: You are using the Auth Emulator, which is intended for local testing only.  Do not use with production credentials."
                  ),
                  "u" > typeof window &&
                    "u" > typeof document &&
                    ("loading" === document.readyState
                      ? window.addEventListener("DOMContentLoaded", e)
                      : e());
              })();
      }
      function eQ(e) {
        let t = e.indexOf(":");
        return t < 0 ? "" : e.substr(0, t + 1);
      }
      function eX(e) {
        if (!e) return null;
        let t = Number(e);
        return isNaN(t) ? null : t;
      }
      class e0 {
        constructor(e, t) {
          (this.providerId = e), (this.signInMethod = t);
        }
        toJSON() {
          return R("not implemented");
        }
        _getIdTokenResponse(e) {
          return R("not implemented");
        }
        _linkToIdToken(e, t) {
          return R("not implemented");
        }
        _getReauthenticationResolver(e) {
          return R("not implemented");
        }
      }
      async function e1(e, t) {
        return V(e, "POST", "/v1/accounts:resetPassword", F(e, t));
      }
      async function e3(e, t) {
        return V(e, "POST", "/v1/accounts:update", t);
      }
      async function e2(e, t) {
        return V(e, "POST", "/v1/accounts:signUp", t);
      }
      async function e6(e, t) {
        return V(e, "POST", "/v1/accounts:update", F(e, t));
      }
      async function e4(e, t) {
        return H(e, "POST", "/v1/accounts:signInWithPassword", F(e, t));
      }
      async function e9(e, t) {
        return V(e, "POST", "/v1/accounts:sendOobCode", F(e, t));
      }
      async function e5(e, t) {
        return e9(e, t);
      }
      async function e8(e, t) {
        return e9(e, t);
      }
      async function e7(e, t) {
        return e9(e, t);
      }
      async function te(e, t) {
        return e9(e, t);
      }
      async function tt(e, t) {
        return H(e, "POST", "/v1/accounts:signInWithEmailLink", F(e, t));
      }
      async function ti(e, t) {
        return H(e, "POST", "/v1/accounts:signInWithEmailLink", F(e, t));
      }
      class tn extends e0 {
        constructor(e, t, i, n = null) {
          super("password", i),
            (this._email = e),
            (this._password = t),
            (this._tenantId = n);
        }
        static _fromEmailAndPassword(e, t) {
          return new tn(e, t, "password");
        }
        static _fromEmailAndCode(e, t, i = null) {
          return new tn(e, t, "emailLink", i);
        }
        toJSON() {
          return {
            email: this._email,
            password: this._password,
            signInMethod: this.signInMethod,
            tenantId: this._tenantId,
          };
        }
        static fromJSON(e) {
          let t = "string" == typeof e ? JSON.parse(e) : e;
          if (t?.email && t?.password) {
            if ("password" === t.signInMethod)
              return this._fromEmailAndPassword(t.email, t.password);
            else if ("emailLink" === t.signInMethod)
              return this._fromEmailAndCode(t.email, t.password, t.tenantId);
          }
          return null;
        }
        async _getIdTokenResponse(e) {
          switch (this.signInMethod) {
            case "password":
              return eB(
                e,
                {
                  returnSecureToken: !0,
                  email: this._email,
                  password: this._password,
                  clientType: "CLIENT_TYPE_WEB",
                },
                "signInWithPassword",
                e4,
                "EMAIL_PASSWORD_PROVIDER"
              );
            case "emailLink":
              return tt(e, { email: this._email, oobCode: this._password });
            default:
              T(e, "internal-error");
          }
        }
        async _linkToIdToken(e, t) {
          switch (this.signInMethod) {
            case "password":
              return eB(
                e,
                {
                  idToken: t,
                  returnSecureToken: !0,
                  email: this._email,
                  password: this._password,
                  clientType: "CLIENT_TYPE_WEB",
                },
                "signUpPassword",
                e2,
                "EMAIL_PASSWORD_PROVIDER"
              );
            case "emailLink":
              return ti(e, {
                idToken: t,
                email: this._email,
                oobCode: this._password,
              });
            default:
              T(e, "internal-error");
          }
        }
        _getReauthenticationResolver(e) {
          return this._getIdTokenResponse(e);
        }
      }
      async function tr(e, t) {
        return H(e, "POST", "/v1/accounts:signInWithIdp", F(e, t));
      }
      class ts extends e0 {
        constructor() {
          super(...arguments), (this.pendingToken = null);
        }
        static _fromParams(e) {
          let t = new ts(e.providerId, e.signInMethod);
          return (
            e.idToken || e.accessToken
              ? (e.idToken && (t.idToken = e.idToken),
                e.accessToken && (t.accessToken = e.accessToken),
                e.nonce && !e.pendingToken && (t.nonce = e.nonce),
                e.pendingToken && (t.pendingToken = e.pendingToken))
              : e.oauthToken && e.oauthTokenSecret
              ? ((t.accessToken = e.oauthToken),
                (t.secret = e.oauthTokenSecret))
              : T("argument-error"),
            t
          );
        }
        toJSON() {
          return {
            idToken: this.idToken,
            accessToken: this.accessToken,
            secret: this.secret,
            nonce: this.nonce,
            pendingToken: this.pendingToken,
            providerId: this.providerId,
            signInMethod: this.signInMethod,
          };
        }
        static fromJSON(e) {
          let {
            providerId: t,
            signInMethod: i,
            ...n
          } = "string" == typeof e ? JSON.parse(e) : e;
          if (!t || !i) return null;
          let r = new ts(t, i);
          return (
            (r.idToken = n.idToken || void 0),
            (r.accessToken = n.accessToken || void 0),
            (r.secret = n.secret),
            (r.nonce = n.nonce),
            (r.pendingToken = n.pendingToken || null),
            r
          );
        }
        _getIdTokenResponse(e) {
          return tr(e, this.buildRequest());
        }
        _linkToIdToken(e, t) {
          let i = this.buildRequest();
          return (i.idToken = t), tr(e, i);
        }
        _getReauthenticationResolver(e) {
          let t = this.buildRequest();
          return (t.autoCreate = !1), tr(e, t);
        }
        buildRequest() {
          let e = { requestUri: "http://localhost", returnSecureToken: !0 };
          if (this.pendingToken) e.pendingToken = this.pendingToken;
          else {
            let t = {};
            this.idToken && (t.id_token = this.idToken),
              this.accessToken && (t.access_token = this.accessToken),
              this.secret && (t.oauth_token_secret = this.secret),
              (t.providerId = this.providerId),
              this.nonce && !this.pendingToken && (t.nonce = this.nonce),
              (e.postBody = (0, s.Am)(t));
          }
          return e;
        }
      }
      async function ta(e, t) {
        return V(e, "POST", "/v1/accounts:sendVerificationCode", F(e, t));
      }
      async function to(e, t) {
        return H(e, "POST", "/v1/accounts:signInWithPhoneNumber", F(e, t));
      }
      async function tc(e, t) {
        let i = await H(
          e,
          "POST",
          "/v1/accounts:signInWithPhoneNumber",
          F(e, t)
        );
        if (i.temporaryProof)
          throw q(e, "account-exists-with-different-credential", i);
        return i;
      }
      let tl = { USER_NOT_FOUND: "user-not-found" };
      async function tu(e, t) {
        return H(
          e,
          "POST",
          "/v1/accounts:signInWithPhoneNumber",
          F(e, { ...t, operation: "REAUTH" }),
          tl
        );
      }
      class th extends e0 {
        constructor(e) {
          super("phone", "phone"), (this.params = e);
        }
        static _fromVerification(e, t) {
          return new th({ verificationId: e, verificationCode: t });
        }
        static _fromTokenResponse(e, t) {
          return new th({ phoneNumber: e, temporaryProof: t });
        }
        _getIdTokenResponse(e) {
          return to(e, this._makeVerificationRequest());
        }
        _linkToIdToken(e, t) {
          return tc(e, { idToken: t, ...this._makeVerificationRequest() });
        }
        _getReauthenticationResolver(e) {
          return tu(e, this._makeVerificationRequest());
        }
        _makeVerificationRequest() {
          let {
            temporaryProof: e,
            phoneNumber: t,
            verificationId: i,
            verificationCode: n,
          } = this.params;
          return e && t
            ? { temporaryProof: e, phoneNumber: t }
            : { sessionInfo: i, code: n };
        }
        toJSON() {
          let e = { providerId: this.providerId };
          return (
            this.params.phoneNumber &&
              (e.phoneNumber = this.params.phoneNumber),
            this.params.temporaryProof &&
              (e.temporaryProof = this.params.temporaryProof),
            this.params.verificationCode &&
              (e.verificationCode = this.params.verificationCode),
            this.params.verificationId &&
              (e.verificationId = this.params.verificationId),
            e
          );
        }
        static fromJSON(e) {
          "string" == typeof e && (e = JSON.parse(e));
          let {
            verificationId: t,
            verificationCode: i,
            phoneNumber: n,
            temporaryProof: r,
          } = e;
          return i || t || n || r
            ? new th({
                verificationId: t,
                verificationCode: i,
                phoneNumber: n,
                temporaryProof: r,
              })
            : null;
        }
      }
      class td {
        constructor(e) {
          const t = (0, s.I9)((0, s.hp)(e)),
            i = t.apiKey ?? null,
            n = t.oobCode ?? null,
            r = (function (e) {
              switch (e) {
                case "recoverEmail":
                  return "RECOVER_EMAIL";
                case "resetPassword":
                  return "PASSWORD_RESET";
                case "signIn":
                  return "EMAIL_SIGNIN";
                case "verifyEmail":
                  return "VERIFY_EMAIL";
                case "verifyAndChangeEmail":
                  return "VERIFY_AND_CHANGE_EMAIL";
                case "revertSecondFactorAddition":
                  return "REVERT_SECOND_FACTOR_ADDITION";
                default:
                  return null;
              }
            })(t.mode ?? null);
          k(i && n && r, "argument-error"),
            (this.apiKey = i),
            (this.operation = r),
            (this.code = n),
            (this.continueUrl = t.continueUrl ?? null),
            (this.languageCode = t.lang ?? null),
            (this.tenantId = t.tenantId ?? null);
        }
        static parseLink(e) {
          let t,
            i,
            n,
            r =
              ((i = (t = (0, s.I9)((0, s.hp)(e)).link)
                ? (0, s.I9)((0, s.hp)(t)).deep_link_id
                : null),
              ((n = (0, s.I9)((0, s.hp)(e)).deep_link_id)
                ? (0, s.I9)((0, s.hp)(n)).link
                : null) ||
                n ||
                i ||
                t ||
                e);
          try {
            return new td(r);
          } catch {
            return null;
          }
        }
      }
      function tp(e) {
        return td.parseLink(e);
      }
      class tm {
        constructor() {
          this.providerId = tm.PROVIDER_ID;
        }
        static credential(e, t) {
          return tn._fromEmailAndPassword(e, t);
        }
        static credentialWithLink(e, t) {
          let i = td.parseLink(t);
          return (
            k(i, "argument-error"), tn._fromEmailAndCode(e, i.code, i.tenantId)
          );
        }
      }
      (tm.PROVIDER_ID = "password"),
        (tm.EMAIL_PASSWORD_SIGN_IN_METHOD = "password"),
        (tm.EMAIL_LINK_SIGN_IN_METHOD = "emailLink");
      class tf {
        constructor(e) {
          (this.providerId = e),
            (this.defaultLanguageCode = null),
            (this.customParameters = {});
        }
        setDefaultLanguage(e) {
          this.defaultLanguageCode = e;
        }
        setCustomParameters(e) {
          return (this.customParameters = e), this;
        }
        getCustomParameters() {
          return this.customParameters;
        }
      }
      class tg extends tf {
        constructor() {
          super(...arguments), (this.scopes = []);
        }
        addScope(e) {
          return this.scopes.includes(e) || this.scopes.push(e), this;
        }
        getScopes() {
          return [...this.scopes];
        }
      }
      class tI extends tg {
        static credentialFromJSON(e) {
          let t = "string" == typeof e ? JSON.parse(e) : e;
          return (
            k("providerId" in t && "signInMethod" in t, "argument-error"),
            ts._fromParams(t)
          );
        }
        credential(e) {
          return this._credential({ ...e, nonce: e.rawNonce });
        }
        _credential(e) {
          return (
            k(e.idToken || e.accessToken, "argument-error"),
            ts._fromParams({
              ...e,
              providerId: this.providerId,
              signInMethod: this.providerId,
            })
          );
        }
        static credentialFromResult(e) {
          return tI.oauthCredentialFromTaggedObject(e);
        }
        static credentialFromError(e) {
          return tI.oauthCredentialFromTaggedObject(e.customData || {});
        }
        static oauthCredentialFromTaggedObject({ _tokenResponse: e }) {
          if (!e) return null;
          let {
            oauthIdToken: t,
            oauthAccessToken: i,
            oauthTokenSecret: n,
            pendingToken: r,
            nonce: s,
            providerId: a,
          } = e;
          if ((!i && !n && !t && !r) || !a) return null;
          try {
            return new tI(a)._credential({
              idToken: t,
              accessToken: i,
              nonce: s,
              pendingToken: r,
            });
          } catch (e) {
            return null;
          }
        }
      }
      class t_ extends tg {
        constructor() {
          super("facebook.com");
        }
        static credential(e) {
          return ts._fromParams({
            providerId: t_.PROVIDER_ID,
            signInMethod: t_.FACEBOOK_SIGN_IN_METHOD,
            accessToken: e,
          });
        }
        static credentialFromResult(e) {
          return t_.credentialFromTaggedObject(e);
        }
        static credentialFromError(e) {
          return t_.credentialFromTaggedObject(e.customData || {});
        }
        static credentialFromTaggedObject({ _tokenResponse: e }) {
          if (!e || !("oauthAccessToken" in e) || !e.oauthAccessToken)
            return null;
          try {
            return t_.credential(e.oauthAccessToken);
          } catch {
            return null;
          }
        }
      }
      (t_.FACEBOOK_SIGN_IN_METHOD = "facebook.com"),
        (t_.PROVIDER_ID = "facebook.com");
      class tv extends tg {
        constructor() {
          super("google.com"), this.addScope("profile");
        }
        static credential(e, t) {
          return ts._fromParams({
            providerId: tv.PROVIDER_ID,
            signInMethod: tv.GOOGLE_SIGN_IN_METHOD,
            idToken: e,
            accessToken: t,
          });
        }
        static credentialFromResult(e) {
          return tv.credentialFromTaggedObject(e);
        }
        static credentialFromError(e) {
          return tv.credentialFromTaggedObject(e.customData || {});
        }
        static credentialFromTaggedObject({ _tokenResponse: e }) {
          if (!e) return null;
          let { oauthIdToken: t, oauthAccessToken: i } = e;
          if (!t && !i) return null;
          try {
            return tv.credential(t, i);
          } catch {
            return null;
          }
        }
      }
      (tv.GOOGLE_SIGN_IN_METHOD = "google.com"),
        (tv.PROVIDER_ID = "google.com");
      class tT extends tg {
        constructor() {
          super("github.com");
        }
        static credential(e) {
          return ts._fromParams({
            providerId: tT.PROVIDER_ID,
            signInMethod: tT.GITHUB_SIGN_IN_METHOD,
            accessToken: e,
          });
        }
        static credentialFromResult(e) {
          return tT.credentialFromTaggedObject(e);
        }
        static credentialFromError(e) {
          return tT.credentialFromTaggedObject(e.customData || {});
        }
        static credentialFromTaggedObject({ _tokenResponse: e }) {
          if (!e || !("oauthAccessToken" in e) || !e.oauthAccessToken)
            return null;
          try {
            return tT.credential(e.oauthAccessToken);
          } catch {
            return null;
          }
        }
      }
      (tT.GITHUB_SIGN_IN_METHOD = "github.com"),
        (tT.PROVIDER_ID = "github.com");
      class tE extends e0 {
        constructor(e, t) {
          super(e, e), (this.pendingToken = t);
        }
        _getIdTokenResponse(e) {
          return tr(e, this.buildRequest());
        }
        _linkToIdToken(e, t) {
          let i = this.buildRequest();
          return (i.idToken = t), tr(e, i);
        }
        _getReauthenticationResolver(e) {
          let t = this.buildRequest();
          return (t.autoCreate = !1), tr(e, t);
        }
        toJSON() {
          return {
            signInMethod: this.signInMethod,
            providerId: this.providerId,
            pendingToken: this.pendingToken,
          };
        }
        static fromJSON(e) {
          let {
            providerId: t,
            signInMethod: i,
            pendingToken: n,
          } = "string" == typeof e ? JSON.parse(e) : e;
          return t && i && n && t === i ? new tE(t, n) : null;
        }
        static _create(e, t) {
          return new tE(e, t);
        }
        buildRequest() {
          return {
            requestUri: "http://localhost",
            returnSecureToken: !0,
            pendingToken: this.pendingToken,
          };
        }
      }
      class ty extends tf {
        constructor(e) {
          k(e.startsWith("saml."), "argument-error"), super(e);
        }
        static credentialFromResult(e) {
          return ty.samlCredentialFromTaggedObject(e);
        }
        static credentialFromError(e) {
          return ty.samlCredentialFromTaggedObject(e.customData || {});
        }
        static credentialFromJSON(e) {
          let t = tE.fromJSON(e);
          return k(t, "argument-error"), t;
        }
        static samlCredentialFromTaggedObject({ _tokenResponse: e }) {
          if (!e) return null;
          let { pendingToken: t, providerId: i } = e;
          if (!t || !i) return null;
          try {
            return tE._create(i, t);
          } catch (e) {
            return null;
          }
        }
      }
      class tw extends tg {
        constructor() {
          super("twitter.com");
        }
        static credential(e, t) {
          return ts._fromParams({
            providerId: tw.PROVIDER_ID,
            signInMethod: tw.TWITTER_SIGN_IN_METHOD,
            oauthToken: e,
            oauthTokenSecret: t,
          });
        }
        static credentialFromResult(e) {
          return tw.credentialFromTaggedObject(e);
        }
        static credentialFromError(e) {
          return tw.credentialFromTaggedObject(e.customData || {});
        }
        static credentialFromTaggedObject({ _tokenResponse: e }) {
          if (!e) return null;
          let { oauthAccessToken: t, oauthTokenSecret: i } = e;
          if (!t || !i) return null;
          try {
            return tw.credential(t, i);
          } catch {
            return null;
          }
        }
      }
      async function tA(e, t) {
        return H(e, "POST", "/v1/accounts:signUp", F(e, t));
      }
      (tw.TWITTER_SIGN_IN_METHOD = "twitter.com"),
        (tw.PROVIDER_ID = "twitter.com");
      class tS {
        constructor(e) {
          (this.user = e.user),
            (this.providerId = e.providerId),
            (this._tokenResponse = e._tokenResponse),
            (this.operationType = e.operationType);
        }
        static async _fromIdTokenResponse(e, t, i, n = !1) {
          return new tS({
            user: await em._fromIdTokenResponse(e, i, n),
            providerId: tk(i),
            _tokenResponse: i,
            operationType: t,
          });
        }
        static async _forOperation(e, t, i) {
          return (
            await e._updateTokensIfNecessary(i, !0),
            new tS({
              user: e,
              providerId: tk(i),
              _tokenResponse: i,
              operationType: t,
            })
          );
        }
      }
      function tk(e) {
        return e.providerId
          ? e.providerId
          : "phoneNumber" in e
          ? "phone"
          : null;
      }
      async function tR(e) {
        if ((0, r.xZ)(e.app)) return Promise.reject(w(e));
        let t = eU(e);
        if ((await t._initializationPromise, t.currentUser?.isAnonymous))
          return new tS({
            user: t.currentUser,
            providerId: null,
            operationType: "signIn",
          });
        let i = await tA(t, { returnSecureToken: !0 }),
          n = await tS._fromIdTokenResponse(t, "signIn", i, !0);
        return await t._updateCurrentUser(n.user), n;
      }
      class tP extends s.g {
        constructor(e, t, i, n) {
          super(t.code, t.message),
            (this.operationType = i),
            (this.user = n),
            Object.setPrototypeOf(this, tP.prototype),
            (this.customData = {
              appName: e.name,
              tenantId: e.tenantId ?? void 0,
              _serverResponse: t.customData._serverResponse,
              operationType: i,
            });
        }
        static _fromErrorAndOperation(e, t, i, n) {
          return new tP(e, t, i, n);
        }
      }
      function tN(e, t, i, n) {
        return (
          "reauthenticate" === t
            ? i._getReauthenticationResolver(e)
            : i._getIdTokenResponse(e)
        ).catch((i) => {
          if ("auth/multi-factor-auth-required" === i.code)
            throw tP._fromErrorAndOperation(e, i, t, n);
          throw i;
        });
      }
      function tO(e) {
        return new Set(e.map(({ providerId: e }) => e).filter((e) => !!e));
      }
      async function tb(e, t) {
        let i = (0, s.Ku)(e);
        await tD(!0, i, t);
        let { providerUserInfo: n } = await Y(i.auth, {
            idToken: await i.getIdToken(),
            deleteProvider: [t],
          }),
          r = tO(n || []);
        return (
          (i.providerData = i.providerData.filter((e) => r.has(e.providerId))),
          r.has("phone") || (i.phoneNumber = null),
          await i.auth._persistUserIfCurrent(i),
          i
        );
      }
      async function tC(e, t, i = !1) {
        let n = await er(e, t._linkToIdToken(e.auth, await e.getIdToken()), i);
        return tS._forOperation(e, "link", n);
      }
      async function tD(e, t, i) {
        await eo(t),
          k(
            tO(t.providerData).has(i) === e,
            t.auth,
            !1 === e ? "provider-already-linked" : "no-such-provider"
          );
      }
      async function tL(e, t, i = !1) {
        let { auth: n } = e;
        if ((0, r.xZ)(n.app)) return Promise.reject(w(n));
        let s = "reauthenticate";
        try {
          let r = await er(e, tN(n, s, t, e), i);
          k(r.idToken, n, "internal-error");
          let a = ei(r.idToken);
          k(a, n, "internal-error");
          let { sub: o } = a;
          return k(e.uid === o, n, "user-mismatch"), tS._forOperation(e, s, r);
        } catch (e) {
          throw (e?.code === "auth/user-not-found" && T(n, "user-mismatch"), e);
        }
      }
      async function tM(e, t, i = !1) {
        if ((0, r.xZ)(e.app)) return Promise.reject(w(e));
        let n = "signIn",
          s = await tN(e, n, t),
          a = await tS._fromIdTokenResponse(e, n, s);
        return i || (await e._updateCurrentUser(a.user)), a;
      }
      async function tU(e, t) {
        return tM(eU(e), t);
      }
      async function tF(e, t) {
        let i = (0, s.Ku)(e);
        return await tD(!1, i, t.providerId), tC(i, t);
      }
      async function tV(e, t) {
        return tL((0, s.Ku)(e), t);
      }
      async function tx(e, t) {
        return H(e, "POST", "/v1/accounts:signInWithCustomToken", F(e, t));
      }
      async function tH(e, t) {
        if ((0, r.xZ)(e.app)) return Promise.reject(w(e));
        let i = eU(e),
          n = await tx(i, { token: t, returnSecureToken: !0 }),
          s = await tS._fromIdTokenResponse(i, "signIn", n);
        return await i._updateCurrentUser(s.user), s;
      }
      class tK {
        constructor(e, t) {
          (this.factorId = e),
            (this.uid = t.mfaEnrollmentId),
            (this.enrollmentTime = new Date(t.enrolledAt).toUTCString()),
            (this.displayName = t.displayName);
        }
        static _fromServerResponse(e, t) {
          return "phoneInfo" in t
            ? tj._fromServerResponse(e, t)
            : "totpInfo" in t
            ? tq._fromServerResponse(e, t)
            : T(e, "internal-error");
        }
      }
      class tj extends tK {
        constructor(e) {
          super("phone", e), (this.phoneNumber = e.phoneInfo);
        }
        static _fromServerResponse(e, t) {
          return new tj(t);
        }
      }
      class tq extends tK {
        constructor(e) {
          super("totp", e);
        }
        static _fromServerResponse(e, t) {
          return new tq(t);
        }
      }
      function tW(e, t, i) {
        k(i.url?.length > 0, e, "invalid-continue-uri"),
          k(
            void 0 === i.dynamicLinkDomain || i.dynamicLinkDomain.length > 0,
            e,
            "invalid-dynamic-link-domain"
          ),
          k(
            void 0 === i.linkDomain || i.linkDomain.length > 0,
            e,
            "invalid-hosting-link-domain"
          ),
          (t.continueUrl = i.url),
          (t.dynamicLinkDomain = i.dynamicLinkDomain),
          (t.linkDomain = i.linkDomain),
          (t.canHandleCodeInApp = i.handleCodeInApp),
          i.iOS &&
            (k(i.iOS.bundleId.length > 0, e, "missing-ios-bundle-id"),
            (t.iOSBundleId = i.iOS.bundleId)),
          i.android &&
            (k(i.android.packageName.length > 0, e, "missing-android-pkg-name"),
            (t.androidInstallApp = i.android.installApp),
            (t.androidMinimumVersionCode = i.android.minimumVersion),
            (t.androidPackageName = i.android.packageName));
      }
      async function tz(e) {
        let t = eU(e);
        t._getPasswordPolicyInternal() && (await t._updatePasswordPolicy());
      }
      async function tG(e, t, i) {
        let n = eU(e),
          r = {
            requestType: "PASSWORD_RESET",
            email: t,
            clientType: "CLIENT_TYPE_WEB",
          };
        i && tW(n, r, i),
          await eB(n, r, "getOobCode", e8, "EMAIL_PASSWORD_PROVIDER");
      }
      async function t$(e, t, i) {
        await e1((0, s.Ku)(e), { oobCode: t, newPassword: i }).catch(
          async (t) => {
            throw (
              ("auth/password-does-not-meet-requirements" === t.code && tz(e),
              t)
            );
          }
        );
      }
      async function tB(e, t) {
        await e6((0, s.Ku)(e), { oobCode: t });
      }
      async function tJ(e, t) {
        let i = (0, s.Ku)(e),
          n = await e1(i, { oobCode: t }),
          r = n.requestType;
        switch ((k(r, i, "internal-error"), r)) {
          case "EMAIL_SIGNIN":
            break;
          case "VERIFY_AND_CHANGE_EMAIL":
            k(n.newEmail, i, "internal-error");
            break;
          case "REVERT_SECOND_FACTOR_ADDITION":
            k(n.mfaInfo, i, "internal-error");
          default:
            k(n.email, i, "internal-error");
        }
        let a = null;
        return (
          n.mfaInfo && (a = tK._fromServerResponse(eU(i), n.mfaInfo)),
          {
            data: {
              email:
                ("VERIFY_AND_CHANGE_EMAIL" === n.requestType
                  ? n.newEmail
                  : n.email) || null,
              previousEmail:
                ("VERIFY_AND_CHANGE_EMAIL" === n.requestType
                  ? n.email
                  : n.newEmail) || null,
              multiFactorInfo: a,
            },
            operation: r,
          }
        );
      }
      async function tY(e, t) {
        let { data: i } = await tJ((0, s.Ku)(e), t);
        return i.email;
      }
      async function tZ(e, t, i) {
        if ((0, r.xZ)(e.app)) return Promise.reject(w(e));
        let n = eU(e),
          s = eB(
            n,
            {
              returnSecureToken: !0,
              email: t,
              password: i,
              clientType: "CLIENT_TYPE_WEB",
            },
            "signUpPassword",
            tA,
            "EMAIL_PASSWORD_PROVIDER"
          ),
          a = await s.catch((t) => {
            throw (
              ("auth/password-does-not-meet-requirements" === t.code && tz(e),
              t)
            );
          }),
          o = await tS._fromIdTokenResponse(n, "signIn", a);
        return await n._updateCurrentUser(o.user), o;
      }
      function tQ(e, t, i) {
        return (0, r.xZ)(e.app)
          ? Promise.reject(w(e))
          : tU((0, s.Ku)(e), tm.credential(t, i)).catch(async (t) => {
              throw (
                ("auth/password-does-not-meet-requirements" === t.code && tz(e),
                t)
              );
            });
      }
      async function tX(e, t, i) {
        let n = eU(e),
          r = {
            requestType: "EMAIL_SIGNIN",
            email: t,
            clientType: "CLIENT_TYPE_WEB",
          };
        k(i.handleCodeInApp, n, "argument-error"),
          i && tW(n, r, i),
          await eB(n, r, "getOobCode", e7, "EMAIL_PASSWORD_PROVIDER");
      }
      function t0(e, t) {
        let i = td.parseLink(t);
        return i?.operation === "EMAIL_SIGNIN";
      }
      async function t1(e, t, i) {
        if ((0, r.xZ)(e.app)) return Promise.reject(w(e));
        let n = (0, s.Ku)(e),
          a = tm.credentialWithLink(t, i || P());
        return (
          k(a._tenantId === (n.tenantId || null), n, "tenant-id-mismatch"),
          tU(n, a)
        );
      }
      async function t3(e, t) {
        return V(e, "POST", "/v1/accounts:createAuthUri", F(e, t));
      }
      async function t2(e, t) {
        let i = N() ? P() : "http://localhost",
          { signinMethods: n } = await t3((0, s.Ku)(e), {
            identifier: t,
            continueUri: i,
          });
        return n || [];
      }
      async function t6(e, t) {
        let i = (0, s.Ku)(e),
          n = { requestType: "VERIFY_EMAIL", idToken: await e.getIdToken() };
        t && tW(i.auth, n, t);
        let { email: r } = await e5(i.auth, n);
        r !== e.email && (await e.reload());
      }
      async function t4(e, t, i) {
        let n = (0, s.Ku)(e),
          r = {
            requestType: "VERIFY_AND_CHANGE_EMAIL",
            idToken: await e.getIdToken(),
            newEmail: t,
          };
        i && tW(n.auth, r, i);
        let { email: a } = await te(n.auth, r);
        a !== e.email && (await e.reload());
      }
      async function t9(e, t) {
        return V(e, "POST", "/v1/accounts:update", t);
      }
      async function t5(e, { displayName: t, photoURL: i }) {
        if (void 0 === t && void 0 === i) return;
        let n = (0, s.Ku)(e),
          r = await n.getIdToken(),
          a = await er(
            n,
            t9(n.auth, {
              idToken: r,
              displayName: t,
              photoUrl: i,
              returnSecureToken: !0,
            })
          );
        (n.displayName = a.displayName || null),
          (n.photoURL = a.photoUrl || null);
        let o = n.providerData.find(({ providerId: e }) => "password" === e);
        o && ((o.displayName = n.displayName), (o.photoURL = n.photoURL)),
          await n._updateTokensIfNecessary(a);
      }
      function t8(e, t) {
        let i = (0, s.Ku)(e);
        return (0, r.xZ)(i.auth.app)
          ? Promise.reject(w(i.auth))
          : ie(i, t, null);
      }
      function t7(e, t) {
        return ie((0, s.Ku)(e), null, t);
      }
      async function ie(e, t, i) {
        let { auth: n } = e,
          r = { idToken: await e.getIdToken(), returnSecureToken: !0 };
        t && (r.email = t), i && (r.password = i);
        let s = await er(e, e3(n, r));
        await e._updateTokensIfNecessary(s, !0);
      }
      class it {
        constructor(e, t, i = {}) {
          (this.isNewUser = e), (this.providerId = t), (this.profile = i);
        }
      }
      class ii extends it {
        constructor(e, t, i, n) {
          super(e, t, i), (this.username = n);
        }
      }
      class ir extends it {
        constructor(e, t) {
          super(e, "facebook.com", t);
        }
      }
      class is extends ii {
        constructor(e, t) {
          super(
            e,
            "github.com",
            t,
            "string" == typeof t?.login ? t?.login : null
          );
        }
      }
      class ia extends it {
        constructor(e, t) {
          super(e, "google.com", t);
        }
      }
      class io extends ii {
        constructor(e, t, i) {
          super(e, "twitter.com", t, i);
        }
      }
      function ic(e) {
        let { user: t, _tokenResponse: i } = e;
        return t.isAnonymous && !i
          ? { providerId: null, isNewUser: !1, profile: null }
          : (function (e) {
              if (!e) return null;
              let { providerId: t } = e,
                i = e.rawUserInfo ? JSON.parse(e.rawUserInfo) : {},
                n =
                  e.isNewUser ||
                  "identitytoolkit#SignupNewUserResponse" === e.kind;
              if (!t && e?.idToken) {
                let t = ei(e.idToken)?.firebase?.sign_in_provider;
                if (t)
                  return new it(
                    n,
                    "anonymous" !== t && "custom" !== t ? t : null
                  );
              }
              if (!t) return null;
              switch (t) {
                case "facebook.com":
                  return new ir(n, i);
                case "github.com":
                  return new is(n, i);
                case "google.com":
                  return new ia(n, i);
                case "twitter.com":
                  return new io(n, i, e.screenName || null);
                case "custom":
                case "anonymous":
                  return new it(n, null);
                default:
                  return new it(n, t, i);
              }
            })(i);
      }
      function il(e, t) {
        return (0, s.Ku)(e).setPersistence(t);
      }
      function iu(e) {
        return eJ(e);
      }
      async function ih(e, t) {
        return eU(e).validatePassword(t);
      }
      function id(e, t, i, n) {
        return (0, s.Ku)(e).onIdTokenChanged(t, i, n);
      }
      function ip(e, t, i) {
        return (0, s.Ku)(e).beforeAuthStateChanged(t, i);
      }
      function im(e, t, i, n) {
        return (0, s.Ku)(e).onAuthStateChanged(t, i, n);
      }
      function ig(e) {
        (0, s.Ku)(e).useDeviceLanguage();
      }
      function iI(e, t) {
        return (0, s.Ku)(e).updateCurrentUser(t);
      }
      function i_(e) {
        return (0, s.Ku)(e).signOut();
      }
      function iv(e, t) {
        return eU(e).revokeAccessToken(t);
      }
      async function iT(e) {
        return (0, s.Ku)(e).delete();
      }
      class iE {
        constructor(e, t, i) {
          (this.type = e), (this.credential = t), (this.user = i);
        }
        static _fromIdtoken(e, t) {
          return new iE("enroll", e, t);
        }
        static _fromMfaPendingCredential(e) {
          return new iE("signin", e);
        }
        toJSON() {
          return {
            multiFactorSession: {
              ["enroll" === this.type ? "idToken" : "pendingCredential"]:
                this.credential,
            },
          };
        }
        static fromJSON(e) {
          if (e?.multiFactorSession) {
            if (e.multiFactorSession?.pendingCredential)
              return iE._fromMfaPendingCredential(
                e.multiFactorSession.pendingCredential
              );
            else if (e.multiFactorSession?.idToken)
              return iE._fromIdtoken(e.multiFactorSession.idToken);
          }
          return null;
        }
      }
      class iy {
        constructor(e, t, i) {
          (this.session = e), (this.hints = t), (this.signInResolver = i);
        }
        static _fromError(e, t) {
          let i = eU(e),
            n = t.customData._serverResponse,
            r = (n.mfaInfo || []).map((e) => tK._fromServerResponse(i, e));
          k(n.mfaPendingCredential, i, "internal-error");
          let s = iE._fromMfaPendingCredential(n.mfaPendingCredential);
          return new iy(s, r, async (e) => {
            let r = await e._process(i, s);
            delete n.mfaInfo, delete n.mfaPendingCredential;
            let a = { ...n, idToken: r.idToken, refreshToken: r.refreshToken };
            switch (t.operationType) {
              case "signIn":
                let o = await tS._fromIdTokenResponse(i, t.operationType, a);
                return await i._updateCurrentUser(o.user), o;
              case "reauthenticate":
                return (
                  k(t.user, i, "internal-error"),
                  tS._forOperation(t.user, t.operationType, a)
                );
              default:
                T(i, "internal-error");
            }
          });
        }
        async resolveSignIn(e) {
          return this.signInResolver(e);
        }
      }
      function iw(e, t) {
        let i = (0, s.Ku)(e);
        return (
          k(t.customData.operationType, i, "argument-error"),
          k(
            t.customData._serverResponse?.mfaPendingCredential,
            i,
            "argument-error"
          ),
          iy._fromError(i, t)
        );
      }
      function iA(e, t) {
        return V(e, "POST", "/v2/accounts/mfaEnrollment:start", F(e, t));
      }
      class iS {
        constructor(e) {
          (this.user = e),
            (this.enrolledFactors = []),
            e._onReload((t) => {
              t.mfaInfo &&
                (this.enrolledFactors = t.mfaInfo.map((t) =>
                  tK._fromServerResponse(e.auth, t)
                ));
            });
        }
        static _fromUser(e) {
          return new iS(e);
        }
        async getSession() {
          return iE._fromIdtoken(await this.user.getIdToken(), this.user);
        }
        async enroll(e, t) {
          let i = await this.getSession(),
            n = await er(this.user, e._process(this.user.auth, i, t));
          return (
            await this.user._updateTokensIfNecessary(n), this.user.reload()
          );
        }
        async unenroll(e) {
          let t = "string" == typeof e ? e : e.uid,
            i = await this.user.getIdToken();
          try {
            var n, r;
            let e = await er(
              this.user,
              ((n = this.user.auth),
              (r = { idToken: i, mfaEnrollmentId: t }),
              V(n, "POST", "/v2/accounts/mfaEnrollment:withdraw", F(n, r)))
            );
            (this.enrolledFactors = this.enrolledFactors.filter(
              ({ uid: e }) => e !== t
            )),
              await this.user._updateTokensIfNecessary(e),
              await this.user.reload();
          } catch (e) {
            throw e;
          }
        }
      }
      let ik = new WeakMap();
      function iR(e) {
        let t = (0, s.Ku)(e);
        return ik.has(t) || ik.set(t, iS._fromUser(t)), ik.get(t);
      }
      let iP = "__sak";
      class iN {
        constructor(e, t) {
          (this.storageRetriever = e), (this.type = t);
        }
        _isAvailable() {
          try {
            if (!this.storage) return Promise.resolve(!1);
            return (
              this.storage.setItem(iP, "1"),
              this.storage.removeItem(iP),
              Promise.resolve(!0)
            );
          } catch {
            return Promise.resolve(!1);
          }
        }
        _set(e, t) {
          return this.storage.setItem(e, JSON.stringify(t)), Promise.resolve();
        }
        _get(e) {
          let t = this.storage.getItem(e);
          return Promise.resolve(t ? JSON.parse(t) : null);
        }
        _remove(e) {
          return this.storage.removeItem(e), Promise.resolve();
        }
        get storage() {
          return this.storageRetriever();
        }
      }
      class iO extends iN {
        constructor() {
          super(() => window.localStorage, "LOCAL"),
            (this.boundEventHandler = (e, t) => this.onStorageEvent(e, t)),
            (this.listeners = {}),
            (this.localCache = {}),
            (this.pollTimer = null),
            (this.fallbackToPolling = eO()),
            (this._shouldAllowMigration = !0);
        }
        forAllChangedKeys(e) {
          for (let t of Object.keys(this.listeners)) {
            let i = this.storage.getItem(t),
              n = this.localCache[t];
            i !== n && e(t, n, i);
          }
        }
        onStorageEvent(e, t = !1) {
          if (!e.key)
            return void this.forAllChangedKeys((e, t, i) => {
              this.notifyListeners(e, i);
            });
          let i = e.key;
          t ? this.detachListener() : this.stopPolling();
          let n = () => {
              let e = this.storage.getItem(i);
              (t || this.localCache[i] !== e) && this.notifyListeners(i, e);
            },
            r = this.storage.getItem(i);
          (0, s.lT)() &&
          10 === document.documentMode &&
          r !== e.newValue &&
          e.newValue !== e.oldValue
            ? setTimeout(n, 10)
            : n();
        }
        notifyListeners(e, t) {
          this.localCache[e] = t;
          let i = this.listeners[e];
          if (i) for (let e of Array.from(i)) e(t ? JSON.parse(t) : t);
        }
        startPolling() {
          this.stopPolling(),
            (this.pollTimer = setInterval(() => {
              this.forAllChangedKeys((e, t, i) => {
                this.onStorageEvent(
                  new StorageEvent("storage", {
                    key: e,
                    oldValue: t,
                    newValue: i,
                  }),
                  !0
                );
              });
            }, 1e3));
        }
        stopPolling() {
          this.pollTimer &&
            (clearInterval(this.pollTimer), (this.pollTimer = null));
        }
        attachListener() {
          window.addEventListener("storage", this.boundEventHandler);
        }
        detachListener() {
          window.removeEventListener("storage", this.boundEventHandler);
        }
        _addListener(e, t) {
          0 === Object.keys(this.listeners).length &&
            (this.fallbackToPolling
              ? this.startPolling()
              : this.attachListener()),
            this.listeners[e] ||
              ((this.listeners[e] = new Set()),
              (this.localCache[e] = this.storage.getItem(e))),
            this.listeners[e].add(t);
        }
        _removeListener(e, t) {
          this.listeners[e] &&
            (this.listeners[e].delete(t),
            0 === this.listeners[e].size && delete this.listeners[e]),
            0 === Object.keys(this.listeners).length &&
              (this.detachListener(), this.stopPolling());
        }
        async _set(e, t) {
          await super._set(e, t), (this.localCache[e] = JSON.stringify(t));
        }
        async _get(e) {
          let t = await super._get(e);
          return (this.localCache[e] = JSON.stringify(t)), t;
        }
        async _remove(e) {
          await super._remove(e), delete this.localCache[e];
        }
      }
      iO.type = "LOCAL";
      let ib = iO;
      function iC(e) {
        let t = e.replace(/[\\^$.*+?()[\]{}|]/g, "\\$&"),
          i = RegExp(`${t}=([^;]+)`);
        return document.cookie.match(i)?.[1] ?? null;
      }
      function iD(e) {
        let t = "http:" === window.location.protocol;
        return `${t ? "__dev_" : "__HOST-"}FIREBASE_${e.split(":")[3]}`;
      }
      class iL {
        constructor() {
          (this.type = "COOKIE"), (this.listenerUnsubscribes = new Map());
        }
        _getFinalTarget(e) {
          let t = new URL(`${window.location.origin}/__cookies__`);
          return t.searchParams.set("finalTarget", e), t;
        }
        async _isAvailable() {
          return (
            !(
              ("boolean" == typeof isSecureContext && !isSecureContext) ||
              "u" < typeof navigator ||
              "u" < typeof document
            ) &&
            (navigator.cookieEnabled ?? !0)
          );
        }
        async _set(e, t) {}
        async _get(e) {
          if (!this._isAvailable()) return null;
          let t = iD(e);
          if (window.cookieStore) {
            let e = await window.cookieStore.get(t);
            return e?.value;
          }
          return iC(t);
        }
        async _remove(e) {
          if (!this._isAvailable() || !(await this._get(e))) return;
          let t = iD(e);
          (document.cookie = `${t}=;Max-Age=34560000;Partitioned;Secure;SameSite=Strict;Path=/;Priority=High`),
            await fetch("/__cookies__", { method: "DELETE" }).catch(
              () => void 0
            );
        }
        _addListener(e, t) {
          if (!this._isAvailable()) return;
          let i = iD(e);
          if (window.cookieStore) {
            let e = (e) => {
              let n = e.changed.find((e) => e.name === i);
              n && t(n.value), e.deleted.find((e) => e.name === i) && t(null);
            };
            return (
              this.listenerUnsubscribes.set(t, () =>
                window.cookieStore.removeEventListener("change", e)
              ),
              window.cookieStore.addEventListener("change", e)
            );
          }
          let n = iC(i),
            r = setInterval(() => {
              let e = iC(i);
              e !== n && (t(e), (n = e));
            }, 1e3);
          this.listenerUnsubscribes.set(t, () => clearInterval(r));
        }
        _removeListener(e, t) {
          let i = this.listenerUnsubscribes.get(t);
          i && (i(), this.listenerUnsubscribes.delete(t));
        }
      }
      iL.type = "COOKIE";
      let iM = iL;
      class iU extends iN {
        constructor() {
          super(() => window.sessionStorage, "SESSION");
        }
        _addListener(e, t) {}
        _removeListener(e, t) {}
      }
      iU.type = "SESSION";
      let iF = iU;
      class iV {
        constructor(e) {
          (this.eventTarget = e),
            (this.handlersMap = {}),
            (this.boundEventHandler = this.handleEvent.bind(this));
        }
        static _getInstance(e) {
          let t = this.receivers.find((t) => t.isListeningto(e));
          if (t) return t;
          let i = new iV(e);
          return this.receivers.push(i), i;
        }
        isListeningto(e) {
          return this.eventTarget === e;
        }
        async handleEvent(e) {
          let { eventId: t, eventType: i, data: n } = e.data,
            r = this.handlersMap[i];
          if (!r?.size) return;
          e.ports[0].postMessage({ status: "ack", eventId: t, eventType: i });
          let s = Array.from(r).map(async (t) => t(e.origin, n)),
            a = await Promise.all(
              s.map(async (e) => {
                try {
                  let t = await e;
                  return { fulfilled: !0, value: t };
                } catch (e) {
                  return { fulfilled: !1, reason: e };
                }
              })
            );
          e.ports[0].postMessage({
            status: "done",
            eventId: t,
            eventType: i,
            response: a,
          });
        }
        _subscribe(e, t) {
          0 === Object.keys(this.handlersMap).length &&
            this.eventTarget.addEventListener(
              "message",
              this.boundEventHandler
            ),
            this.handlersMap[e] || (this.handlersMap[e] = new Set()),
            this.handlersMap[e].add(t);
        }
        _unsubscribe(e, t) {
          this.handlersMap[e] && t && this.handlersMap[e].delete(t),
            (t && 0 !== this.handlersMap[e].size) || delete this.handlersMap[e],
            0 === Object.keys(this.handlersMap).length &&
              this.eventTarget.removeEventListener(
                "message",
                this.boundEventHandler
              );
        }
      }
      function ix(e = "", t = 10) {
        let i = "";
        for (let e = 0; e < t; e++) i += Math.floor(10 * Math.random());
        return e + i;
      }
      iV.receivers = [];
      class iH {
        constructor(e) {
          (this.target = e), (this.handlers = new Set());
        }
        removeMessageHandler(e) {
          e.messageChannel &&
            (e.messageChannel.port1.removeEventListener("message", e.onMessage),
            e.messageChannel.port1.close()),
            this.handlers.delete(e);
        }
        async _send(e, t, i = 50) {
          let n,
            r,
            s = "u" > typeof MessageChannel ? new MessageChannel() : null;
          if (!s) throw Error("connection_unavailable");
          return new Promise((a, o) => {
            let c = ix("", 20);
            s.port1.start();
            let l = setTimeout(() => {
              o(Error("unsupported_event"));
            }, i);
            (r = {
              messageChannel: s,
              onMessage(e) {
                if (e.data.eventId === c)
                  switch (e.data.status) {
                    case "ack":
                      clearTimeout(l),
                        (n = setTimeout(() => {
                          o(Error("timeout"));
                        }, 3e3));
                      break;
                    case "done":
                      clearTimeout(n), a(e.data.response);
                      break;
                    default:
                      clearTimeout(l),
                        clearTimeout(n),
                        o(Error("invalid_response"));
                  }
              },
            }),
              this.handlers.add(r),
              s.port1.addEventListener("message", r.onMessage),
              this.target.postMessage({ eventType: e, eventId: c, data: t }, [
                s.port2,
              ]);
          }).finally(() => {
            r && this.removeMessageHandler(r);
          });
        }
      }
      function iK() {
        return window;
      }
      function ij() {
        return (
          void 0 !== iK().WorkerGlobalScope &&
          "function" == typeof iK().importScripts
        );
      }
      async function iq() {
        if (!navigator?.serviceWorker) return null;
        try {
          return (await navigator.serviceWorker.ready).active;
        } catch {
          return null;
        }
      }
      let iW = "firebaseLocalStorageDb",
        iz = "firebaseLocalStorage",
        iG = "fbase_key";
      class i$ {
        constructor(e) {
          this.request = e;
        }
        toPromise() {
          return new Promise((e, t) => {
            this.request.addEventListener("success", () => {
              e(this.request.result);
            }),
              this.request.addEventListener("error", () => {
                t(this.request.error);
              });
          });
        }
      }
      function iB(e, t) {
        return e
          .transaction([iz], t ? "readwrite" : "readonly")
          .objectStore(iz);
      }
      function iJ() {
        let e = indexedDB.open(iW, 1);
        return new Promise((t, i) => {
          e.addEventListener("error", () => {
            i(e.error);
          }),
            e.addEventListener("upgradeneeded", () => {
              let t = e.result;
              try {
                t.createObjectStore(iz, { keyPath: iG });
              } catch (e) {
                i(e);
              }
            }),
            e.addEventListener("success", async () => {
              let i = e.result;
              i.objectStoreNames.contains(iz)
                ? t(i)
                : (i.close(),
                  await new i$(indexedDB.deleteDatabase(iW)).toPromise(),
                  t(await iJ()));
            });
        });
      }
      async function iY(e, t, i) {
        return new i$(iB(e, !0).put({ [iG]: t, value: i })).toPromise();
      }
      async function iZ(e, t) {
        let i = iB(e, !1).get(t),
          n = await new i$(i).toPromise();
        return void 0 === n ? null : n.value;
      }
      function iQ(e, t) {
        return new i$(iB(e, !0).delete(t)).toPromise();
      }
      class iX {
        constructor() {
          (this.type = "LOCAL"),
            (this._shouldAllowMigration = !0),
            (this.listeners = {}),
            (this.localCache = {}),
            (this.pollTimer = null),
            (this.pendingWrites = 0),
            (this.receiver = null),
            (this.sender = null),
            (this.serviceWorkerReceiverAvailable = !1),
            (this.activeServiceWorker = null),
            (this._workerInitializationPromise =
              this.initializeServiceWorkerMessaging().then(
                () => {},
                () => {}
              ));
        }
        async _openDb() {
          return this.db || (this.db = await iJ()), this.db;
        }
        async _withRetries(e) {
          let t = 0;
          for (;;)
            try {
              let t = await this._openDb();
              return await e(t);
            } catch (e) {
              if (t++ > 3) throw e;
              this.db && (this.db.close(), (this.db = void 0));
            }
        }
        async initializeServiceWorkerMessaging() {
          return ij() ? this.initializeReceiver() : this.initializeSender();
        }
        async initializeReceiver() {
          (this.receiver = iV._getInstance(ij() ? self : null)),
            this.receiver._subscribe("keyChanged", async (e, t) => ({
              keyProcessed: (await this._poll()).includes(t.key),
            })),
            this.receiver._subscribe("ping", async (e, t) => ["keyChanged"]);
        }
        async initializeSender() {
          if (
            ((this.activeServiceWorker = await iq()), !this.activeServiceWorker)
          )
            return;
          this.sender = new iH(this.activeServiceWorker);
          let e = await this.sender._send("ping", {}, 800);
          e &&
            e[0]?.fulfilled &&
            e[0]?.value.includes("keyChanged") &&
            (this.serviceWorkerReceiverAvailable = !0);
        }
        async notifyServiceWorker(e) {
          if (
            this.sender &&
            this.activeServiceWorker &&
            (navigator?.serviceWorker?.controller || null) ===
              this.activeServiceWorker
          )
            try {
              await this.sender._send(
                "keyChanged",
                { key: e },
                this.serviceWorkerReceiverAvailable ? 800 : 50
              );
            } catch {}
        }
        async _isAvailable() {
          try {
            if (!indexedDB) return !1;
            let e = await iJ();
            return await iY(e, iP, "1"), await iQ(e, iP), !0;
          } catch {}
          return !1;
        }
        async _withPendingWrite(e) {
          this.pendingWrites++;
          try {
            await e();
          } finally {
            this.pendingWrites--;
          }
        }
        async _set(e, t) {
          return this._withPendingWrite(
            async () => (
              await this._withRetries((i) => iY(i, e, t)),
              (this.localCache[e] = t),
              this.notifyServiceWorker(e)
            )
          );
        }
        async _get(e) {
          let t = await this._withRetries((t) => iZ(t, e));
          return (this.localCache[e] = t), t;
        }
        async _remove(e) {
          return this._withPendingWrite(
            async () => (
              await this._withRetries((t) => iQ(t, e)),
              delete this.localCache[e],
              this.notifyServiceWorker(e)
            )
          );
        }
        async _poll() {
          let e = await this._withRetries((e) =>
            new i$(iB(e, !1).getAll()).toPromise()
          );
          if (!e || 0 !== this.pendingWrites) return [];
          let t = [],
            i = new Set();
          if (0 !== e.length)
            for (let { fbase_key: n, value: r } of e)
              i.add(n),
                JSON.stringify(this.localCache[n]) !== JSON.stringify(r) &&
                  (this.notifyListeners(n, r), t.push(n));
          for (let e of Object.keys(this.localCache))
            this.localCache[e] &&
              !i.has(e) &&
              (this.notifyListeners(e, null), t.push(e));
          return t;
        }
        notifyListeners(e, t) {
          this.localCache[e] = t;
          let i = this.listeners[e];
          if (i) for (let e of Array.from(i)) e(t);
        }
        startPolling() {
          this.stopPolling(),
            (this.pollTimer = setInterval(async () => this._poll(), 800));
        }
        stopPolling() {
          this.pollTimer &&
            (clearInterval(this.pollTimer), (this.pollTimer = null));
        }
        _addListener(e, t) {
          0 === Object.keys(this.listeners).length && this.startPolling(),
            this.listeners[e] ||
              ((this.listeners[e] = new Set()), this._get(e)),
            this.listeners[e].add(t);
        }
        _removeListener(e, t) {
          this.listeners[e] &&
            (this.listeners[e].delete(t),
            0 === this.listeners[e].size && delete this.listeners[e]),
            0 === Object.keys(this.listeners).length && this.stopPolling();
        }
      }
      iX.type = "LOCAL";
      let i0 = iX;
      function i1(e, t) {
        return V(e, "POST", "/v2/accounts/mfaSignIn:start", F(e, t));
      }
      let i3 = eH("rcb"),
        i2 = new b(3e4, 6e4);
      class i6 {
        constructor() {
          (this.hostLanguage = ""),
            (this.counter = 0),
            (this.librarySeparatelyLoaded = !!iK().grecaptcha?.render);
        }
        load(e, t = "") {
          var i;
          return (k(
            (i = t).length <= 6 && /^\s*[a-zA-Z0-9\-]*\s*$/.test(i),
            e,
            "argument-error"
          ),
          this.shouldResolveImmediately(t) && W(iK().grecaptcha))
            ? Promise.resolve(iK().grecaptcha)
            : new Promise((i, n) => {
                let r = iK().setTimeout(() => {
                  n(E(e, "network-request-failed"));
                }, i2.get());
                (iK()[i3] = () => {
                  iK().clearTimeout(r), delete iK()[i3];
                  let s = iK().grecaptcha;
                  if (!s || !W(s)) return void n(E(e, "internal-error"));
                  let a = s.render;
                  (s.render = (e, t) => {
                    let i = a(e, t);
                    return this.counter++, i;
                  }),
                    (this.hostLanguage = t),
                    i(s);
                }),
                  ex(
                    `${eV.recaptchaV2Script}?${(0, s.Am)({
                      onload: i3,
                      render: "explicit",
                      hl: t,
                    })}`
                  ).catch(() => {
                    clearTimeout(r), n(E(e, "internal-error"));
                  });
              });
        }
        clearedOneInstance() {
          this.counter--;
        }
        shouldResolveImmediately(e) {
          return (
            !!iK().grecaptcha?.render &&
            (e === this.hostLanguage ||
              this.counter > 0 ||
              this.librarySeparatelyLoaded)
          );
        }
      }
      class i4 {
        async load(e) {
          return new eK(e);
        }
        clearedOneInstance() {}
      }
      let i9 = "recaptcha",
        i5 = { theme: "light", type: "image" };
      class i8 {
        constructor(e, t, i = { ...i5 }) {
          (this.parameters = i),
            (this.type = i9),
            (this.destroyed = !1),
            (this.widgetId = null),
            (this.tokenChangeListeners = new Set()),
            (this.renderPromise = null),
            (this.recaptcha = null),
            (this.auth = eU(e)),
            (this.isInvisible = "invisible" === this.parameters.size),
            k(
              "u" > typeof document,
              this.auth,
              "operation-not-supported-in-this-environment"
            );
          const n = "string" == typeof t ? document.getElementById(t) : t;
          k(n, this.auth, "argument-error"),
            (this.container = n),
            (this.parameters.callback = this.makeTokenCallback(
              this.parameters.callback
            )),
            (this._recaptchaLoader = this.auth.settings
              .appVerificationDisabledForTesting
              ? new i4()
              : new i6()),
            this.validateStartingState();
        }
        async verify() {
          this.assertNotDestroyed();
          let e = await this.render(),
            t = this.getAssertedRecaptcha(),
            i = t.getResponse(e);
          return (
            i ||
            new Promise((i) => {
              let n = (e) => {
                e && (this.tokenChangeListeners.delete(n), i(e));
              };
              this.tokenChangeListeners.add(n),
                this.isInvisible && t.execute(e);
            })
          );
        }
        render() {
          try {
            this.assertNotDestroyed();
          } catch (e) {
            return Promise.reject(e);
          }
          return (
            this.renderPromise ||
              (this.renderPromise = this.makeRenderPromise().catch((e) => {
                throw ((this.renderPromise = null), e);
              })),
            this.renderPromise
          );
        }
        _reset() {
          this.assertNotDestroyed(),
            null !== this.widgetId &&
              this.getAssertedRecaptcha().reset(this.widgetId);
        }
        clear() {
          this.assertNotDestroyed(),
            (this.destroyed = !0),
            this._recaptchaLoader.clearedOneInstance(),
            this.isInvisible ||
              this.container.childNodes.forEach((e) => {
                this.container.removeChild(e);
              });
        }
        validateStartingState() {
          k(!this.parameters.sitekey, this.auth, "argument-error"),
            k(
              this.isInvisible || !this.container.hasChildNodes(),
              this.auth,
              "argument-error"
            ),
            k(
              "u" > typeof document,
              this.auth,
              "operation-not-supported-in-this-environment"
            );
        }
        makeTokenCallback(e) {
          return (t) => {
            if (
              (this.tokenChangeListeners.forEach((e) => e(t)),
              "function" == typeof e)
            )
              e(t);
            else if ("string" == typeof e) {
              let i = iK()[e];
              "function" == typeof i && i(t);
            }
          };
        }
        assertNotDestroyed() {
          k(!this.destroyed, this.auth, "internal-error");
        }
        async makeRenderPromise() {
          if ((await this.init(), !this.widgetId)) {
            let e = this.container;
            if (!this.isInvisible) {
              let t = document.createElement("div");
              e.appendChild(t), (e = t);
            }
            this.widgetId = this.getAssertedRecaptcha().render(
              e,
              this.parameters
            );
          }
          return this.widgetId;
        }
        async init() {
          let e;
          k(N() && !ij(), this.auth, "internal-error"),
            await ((e = null),
            new Promise((t) => {
              "complete" === document.readyState
                ? t()
                : ((e = () => t()), window.addEventListener("load", e));
            }).catch((t) => {
              throw (e && window.removeEventListener("load", e), t);
            })),
            (this.recaptcha = await this._recaptchaLoader.load(
              this.auth,
              this.auth.languageCode || void 0
            ));
          let t = await $(this.auth);
          k(t, this.auth, "internal-error"), (this.parameters.sitekey = t);
        }
        getAssertedRecaptcha() {
          return k(this.recaptcha, this.auth, "internal-error"), this.recaptcha;
        }
      }
      class i7 {
        constructor(e, t) {
          (this.verificationId = e), (this.onConfirmation = t);
        }
        confirm(e) {
          let t = th._fromVerification(this.verificationId, e);
          return this.onConfirmation(t);
        }
      }
      async function ne(e, t, i) {
        if ((0, r.xZ)(e.app)) return Promise.reject(w(e));
        let n = eU(e);
        return new i7(await nn(n, t, (0, s.Ku)(i)), (e) => tU(n, e));
      }
      async function nt(e, t, i) {
        let n = (0, s.Ku)(e);
        return (
          await tD(!1, n, "phone"),
          new i7(await nn(n.auth, t, (0, s.Ku)(i)), (e) => tF(n, e))
        );
      }
      async function ni(e, t, i) {
        let n = (0, s.Ku)(e);
        return (0, r.xZ)(n.auth.app)
          ? Promise.reject(w(n.auth))
          : new i7(await nn(n.auth, t, (0, s.Ku)(i)), (e) => tV(n, e));
      }
      async function nn(e, t, i) {
        if (!e._getRecaptchaConfig())
          try {
            await eJ(e);
          } catch (e) {
            console.log(
              "Failed to initialize reCAPTCHA Enterprise config. Triggering the reCAPTCHA v2 verification."
            );
          }
        try {
          let n;
          if (
            ((n = "string" == typeof t ? { phoneNumber: t } : t),
            "session" in n)
          ) {
            let t = n.session;
            if ("phoneNumber" in n) {
              k("enroll" === t.type, e, "internal-error");
              let r = {
                  idToken: t.credential,
                  phoneEnrollmentInfo: {
                    phoneNumber: n.phoneNumber,
                    clientType: "CLIENT_TYPE_WEB",
                  },
                },
                s = async (e, t) => {
                  if (t.phoneEnrollmentInfo.captchaResponse === ez) {
                    k(i?.type === i9, e, "argument-error");
                    let n = await ns(e, t, i);
                    return iA(e, n);
                  }
                  return iA(e, t);
                },
                a = eB(e, r, "mfaSmsEnrollment", s, "PHONE_PROVIDER");
              return (await a.catch((e) => Promise.reject(e))).phoneSessionInfo
                .sessionInfo;
            }
            {
              k("signin" === t.type, e, "internal-error");
              let r = n.multiFactorHint?.uid || n.multiFactorUid;
              k(r, e, "missing-multi-factor-info");
              let s = {
                  mfaPendingCredential: t.credential,
                  mfaEnrollmentId: r,
                  phoneSignInInfo: { clientType: "CLIENT_TYPE_WEB" },
                },
                a = async (e, t) => {
                  if (t.phoneSignInInfo.captchaResponse === ez) {
                    k(i?.type === i9, e, "argument-error");
                    let n = await ns(e, t, i);
                    return i1(e, n);
                  }
                  return i1(e, t);
                },
                o = eB(e, s, "mfaSmsSignIn", a, "PHONE_PROVIDER");
              return (await o.catch((e) => Promise.reject(e))).phoneResponseInfo
                .sessionInfo;
            }
          }
          {
            let t = {
                phoneNumber: n.phoneNumber,
                clientType: "CLIENT_TYPE_WEB",
              },
              r = async (e, t) => {
                if (t.captchaResponse === ez) {
                  k(i?.type === i9, e, "argument-error");
                  let n = await ns(e, t, i);
                  return ta(e, n);
                }
                return ta(e, t);
              },
              s = eB(e, t, "sendVerificationCode", r, "PHONE_PROVIDER");
            return (await s.catch((e) => Promise.reject(e))).sessionInfo;
          }
        } finally {
          i?._reset();
        }
      }
      async function nr(e, t) {
        let i = (0, s.Ku)(e);
        if ((0, r.xZ)(i.auth.app)) return Promise.reject(w(i.auth));
        await tC(i, t);
      }
      async function ns(e, t, i) {
        k(i.type === i9, e, "argument-error");
        let n = await i.verify();
        k("string" == typeof n, e, "argument-error");
        let r = { ...t };
        if ("phoneEnrollmentInfo" in r) {
          let e = r.phoneEnrollmentInfo.phoneNumber,
            t = r.phoneEnrollmentInfo.captchaResponse,
            i = r.phoneEnrollmentInfo.clientType,
            s = r.phoneEnrollmentInfo.recaptchaVersion;
          return (
            Object.assign(r, {
              phoneEnrollmentInfo: {
                phoneNumber: e,
                recaptchaToken: n,
                captchaResponse: t,
                clientType: i,
                recaptchaVersion: s,
              },
            }),
            r
          );
        }
        if (!("phoneSignInInfo" in r))
          return Object.assign(r, { recaptchaToken: n }), r;
        {
          let e = r.phoneSignInInfo.captchaResponse,
            t = r.phoneSignInInfo.clientType,
            i = r.phoneSignInInfo.recaptchaVersion;
          return (
            Object.assign(r, {
              phoneSignInInfo: {
                recaptchaToken: n,
                captchaResponse: e,
                clientType: t,
                recaptchaVersion: i,
              },
            }),
            r
          );
        }
      }
      class na {
        constructor(e) {
          (this.providerId = na.PROVIDER_ID), (this.auth = eU(e));
        }
        verifyPhoneNumber(e, t) {
          return nn(this.auth, e, (0, s.Ku)(t));
        }
        static credential(e, t) {
          return th._fromVerification(e, t);
        }
        static credentialFromResult(e) {
          return na.credentialFromTaggedObject(e);
        }
        static credentialFromError(e) {
          return na.credentialFromTaggedObject(e.customData || {});
        }
        static credentialFromTaggedObject({ _tokenResponse: e }) {
          if (!e) return null;
          let { phoneNumber: t, temporaryProof: i } = e;
          return t && i ? th._fromTokenResponse(t, i) : null;
        }
      }
      function no(e, t) {
        return t
          ? eg(t)
          : (k(e._popupRedirectResolver, e, "argument-error"),
            e._popupRedirectResolver);
      }
      (na.PROVIDER_ID = "phone"), (na.PHONE_SIGN_IN_METHOD = "phone");
      class nc extends e0 {
        constructor(e) {
          super("custom", "custom"), (this.params = e);
        }
        _getIdTokenResponse(e) {
          return tr(e, this._buildIdpRequest());
        }
        _linkToIdToken(e, t) {
          return tr(e, this._buildIdpRequest(t));
        }
        _getReauthenticationResolver(e) {
          return tr(e, this._buildIdpRequest());
        }
        _buildIdpRequest(e) {
          let t = {
            requestUri: this.params.requestUri,
            sessionId: this.params.sessionId,
            postBody: this.params.postBody,
            tenantId: this.params.tenantId,
            pendingToken: this.params.pendingToken,
            returnSecureToken: !0,
            returnIdpCredential: !0,
          };
          return e && (t.idToken = e), t;
        }
      }
      function nl(e) {
        return tM(e.auth, new nc(e), e.bypassAuthState);
      }
      function nu(e) {
        let { auth: t, user: i } = e;
        return k(i, t, "internal-error"), tL(i, new nc(e), e.bypassAuthState);
      }
      async function nh(e) {
        let { auth: t, user: i } = e;
        return k(i, t, "internal-error"), tC(i, new nc(e), e.bypassAuthState);
      }
      class nd {
        constructor(e, t, i, n, r = !1) {
          (this.auth = e),
            (this.resolver = i),
            (this.user = n),
            (this.bypassAuthState = r),
            (this.pendingPromise = null),
            (this.eventManager = null),
            (this.filter = Array.isArray(t) ? t : [t]);
        }
        execute() {
          return new Promise(async (e, t) => {
            this.pendingPromise = { resolve: e, reject: t };
            try {
              (this.eventManager = await this.resolver._initialize(this.auth)),
                await this.onExecution(),
                this.eventManager.registerConsumer(this);
            } catch (e) {
              this.reject(e);
            }
          });
        }
        async onAuthEvent(e) {
          let {
            urlResponse: t,
            sessionId: i,
            postBody: n,
            tenantId: r,
            error: s,
            type: a,
          } = e;
          if (s) return void this.reject(s);
          let o = {
            auth: this.auth,
            requestUri: t,
            sessionId: i,
            tenantId: r || void 0,
            postBody: n || void 0,
            user: this.user,
            bypassAuthState: this.bypassAuthState,
          };
          try {
            this.resolve(await this.getIdpTask(a)(o));
          } catch (e) {
            this.reject(e);
          }
        }
        onError(e) {
          this.reject(e);
        }
        getIdpTask(e) {
          switch (e) {
            case "signInViaPopup":
            case "signInViaRedirect":
              return nl;
            case "linkViaPopup":
            case "linkViaRedirect":
              return nh;
            case "reauthViaPopup":
            case "reauthViaRedirect":
              return nu;
            default:
              T(this.auth, "internal-error");
          }
        }
        resolve(e) {
          var t, i;
          (t = this.pendingPromise),
            (i = "Pending promise was never set"),
            t || R(i),
            this.pendingPromise.resolve(e),
            this.unregisterAndCleanUp();
        }
        reject(e) {
          var t, i;
          (t = this.pendingPromise),
            (i = "Pending promise was never set"),
            t || R(i),
            this.pendingPromise.reject(e),
            this.unregisterAndCleanUp();
        }
        unregisterAndCleanUp() {
          this.eventManager && this.eventManager.unregisterConsumer(this),
            (this.pendingPromise = null),
            this.cleanUp();
        }
      }
      let np = new b(2e3, 1e4);
      async function nm(e, t, i) {
        if ((0, r.xZ)(e.app))
          return Promise.reject(
            E(e, "operation-not-supported-in-this-environment")
          );
        let n = eU(e);
        A(e, t, tf);
        let s = no(n, i);
        return new nI(n, "signInViaPopup", t, s).executeNotNull();
      }
      async function nf(e, t, i) {
        let n = (0, s.Ku)(e);
        if ((0, r.xZ)(n.auth.app))
          return Promise.reject(
            E(n.auth, "operation-not-supported-in-this-environment")
          );
        A(n.auth, t, tf);
        let a = no(n.auth, i);
        return new nI(n.auth, "reauthViaPopup", t, a, n).executeNotNull();
      }
      async function ng(e, t, i) {
        let n = (0, s.Ku)(e);
        A(n.auth, t, tf);
        let r = no(n.auth, i);
        return new nI(n.auth, "linkViaPopup", t, r, n).executeNotNull();
      }
      class nI extends nd {
        constructor(e, t, i, n, r) {
          super(e, t, n, r),
            (this.provider = i),
            (this.authWindow = null),
            (this.pollId = null),
            nI.currentPopupAction && nI.currentPopupAction.cancel(),
            (nI.currentPopupAction = this);
        }
        async executeNotNull() {
          let e = await this.execute();
          return k(e, this.auth, "internal-error"), e;
        }
        async onExecution() {
          var e, t;
          (e = 1 === this.filter.length),
            (t = "Popup operations only handle one event"),
            e || R(t);
          let i = ix();
          (this.authWindow = await this.resolver._openPopup(
            this.auth,
            this.provider,
            this.filter[0],
            i
          )),
            (this.authWindow.associatedEvent = i),
            this.resolver._originValidation(this.auth).catch((e) => {
              this.reject(e);
            }),
            this.resolver._isIframeWebStorageSupported(this.auth, (e) => {
              e || this.reject(E(this.auth, "web-storage-unsupported"));
            }),
            this.pollUserCancellation();
        }
        get eventId() {
          return this.authWindow?.associatedEvent || null;
        }
        cancel() {
          this.reject(E(this.auth, "cancelled-popup-request"));
        }
        cleanUp() {
          this.authWindow && this.authWindow.close(),
            this.pollId && window.clearTimeout(this.pollId),
            (this.authWindow = null),
            (this.pollId = null),
            (nI.currentPopupAction = null);
        }
        pollUserCancellation() {
          let e = () => {
            if (this.authWindow?.window?.closed) {
              this.pollId = window.setTimeout(() => {
                (this.pollId = null),
                  this.reject(E(this.auth, "popup-closed-by-user"));
              }, 8e3);
              return;
            }
            this.pollId = window.setTimeout(e, np.get());
          };
          e();
        }
      }
      nI.currentPopupAction = null;
      let n_ = new Map();
      class nv extends nd {
        constructor(e, t, i = !1) {
          super(
            e,
            [
              "signInViaRedirect",
              "linkViaRedirect",
              "reauthViaRedirect",
              "unknown",
            ],
            t,
            void 0,
            i
          ),
            (this.eventId = null);
        }
        async execute() {
          let e = n_.get(this.auth._key());
          if (!e) {
            try {
              let t = (await nT(this.resolver, this.auth))
                ? await super.execute()
                : null;
              e = () => Promise.resolve(t);
            } catch (t) {
              e = () => Promise.reject(t);
            }
            n_.set(this.auth._key(), e);
          }
          return (
            this.bypassAuthState ||
              n_.set(this.auth._key(), () => Promise.resolve(null)),
            e()
          );
        }
        async onAuthEvent(e) {
          if ("signInViaRedirect" === e.type) return super.onAuthEvent(e);
          if ("unknown" === e.type) return void this.resolve(null);
          if (e.eventId) {
            let t = await this.auth._redirectUserForId(e.eventId);
            if (t) return (this.user = t), super.onAuthEvent(e);
            this.resolve(null);
          }
        }
        async onExecution() {}
        cleanUp() {}
      }
      async function nT(e, t) {
        let i = nA(t),
          n = nw(e);
        if (!(await n._isAvailable())) return !1;
        let r = (await n._get(i)) === "true";
        return await n._remove(i), r;
      }
      async function nE(e, t) {
        return nw(e)._set(nA(t), "true");
      }
      function ny(e, t) {
        n_.set(e._key(), t);
      }
      function nw(e) {
        return eg(e._redirectPersistence);
      }
      function nA(e) {
        return ev("pendingRedirect", e.config.apiKey, e.name);
      }
      function nS(e, t, i) {
        return nk(e, t, i);
      }
      async function nk(e, t, i) {
        if ((0, r.xZ)(e.app)) return Promise.reject(w(e));
        let n = eU(e);
        A(e, t, tf), await n._initializationPromise;
        let s = no(n, i);
        return await nE(s, n), s._openRedirect(n, t, "signInViaRedirect");
      }
      function nR(e, t, i) {
        return nP(e, t, i);
      }
      async function nP(e, t, i) {
        let n = (0, s.Ku)(e);
        if ((A(n.auth, t, tf), (0, r.xZ)(n.auth.app)))
          return Promise.reject(w(n.auth));
        await n.auth._initializationPromise;
        let a = no(n.auth, i);
        await nE(a, n.auth);
        let o = await nD(n);
        return a._openRedirect(n.auth, t, "reauthViaRedirect", o);
      }
      function nN(e, t, i) {
        return nO(e, t, i);
      }
      async function nO(e, t, i) {
        let n = (0, s.Ku)(e);
        A(n.auth, t, tf), await n.auth._initializationPromise;
        let r = no(n.auth, i);
        await tD(!1, n, t.providerId), await nE(r, n.auth);
        let a = await nD(n);
        return r._openRedirect(n.auth, t, "linkViaRedirect", a);
      }
      async function nb(e, t) {
        return await eU(e)._initializationPromise, nC(e, t, !1);
      }
      async function nC(e, t, i = !1) {
        if ((0, r.xZ)(e.app)) return Promise.reject(w(e));
        let n = eU(e),
          s = no(n, t),
          a = new nv(n, s, i),
          o = await a.execute();
        return (
          o &&
            !i &&
            (delete o.user._redirectEventId,
            await n._persistUserIfCurrent(o.user),
            await n._setRedirectUser(null, t)),
          o
        );
      }
      async function nD(e) {
        let t = ix(`${e.uid}:::`);
        return (
          (e._redirectEventId = t),
          await e.auth._setRedirectUser(e),
          await e.auth._persistUserIfCurrent(e),
          t
        );
      }
      class nL {
        constructor(e) {
          (this.auth = e),
            (this.cachedEventUids = new Set()),
            (this.consumers = new Set()),
            (this.queuedRedirectEvent = null),
            (this.hasHandledPotentialRedirect = !1),
            (this.lastProcessedEventTime = Date.now());
        }
        registerConsumer(e) {
          this.consumers.add(e),
            this.queuedRedirectEvent &&
              this.isEventForConsumer(this.queuedRedirectEvent, e) &&
              (this.sendToConsumer(this.queuedRedirectEvent, e),
              this.saveEventToCache(this.queuedRedirectEvent),
              (this.queuedRedirectEvent = null));
        }
        unregisterConsumer(e) {
          this.consumers.delete(e);
        }
        onEvent(e) {
          if (this.hasEventBeenHandled(e)) return !1;
          let t = !1;
          return (
            this.consumers.forEach((i) => {
              this.isEventForConsumer(e, i) &&
                ((t = !0), this.sendToConsumer(e, i), this.saveEventToCache(e));
            }),
            this.hasHandledPotentialRedirect ||
              !(function (e) {
                switch (e.type) {
                  case "signInViaRedirect":
                  case "linkViaRedirect":
                  case "reauthViaRedirect":
                    return !0;
                  case "unknown":
                    return nU(e);
                  default:
                    return !1;
                }
              })(e) ||
              ((this.hasHandledPotentialRedirect = !0),
              t || ((this.queuedRedirectEvent = e), (t = !0))),
            t
          );
        }
        sendToConsumer(e, t) {
          if (e.error && !nU(e)) {
            let i = e.error.code?.split("auth/")[1] || "internal-error";
            t.onError(E(this.auth, i));
          } else t.onAuthEvent(e);
        }
        isEventForConsumer(e, t) {
          let i =
            null === t.eventId || (!!e.eventId && e.eventId === t.eventId);
          return t.filter.includes(e.type) && i;
        }
        hasEventBeenHandled(e) {
          return (
            Date.now() - this.lastProcessedEventTime >= 6e5 &&
              this.cachedEventUids.clear(),
            this.cachedEventUids.has(nM(e))
          );
        }
        saveEventToCache(e) {
          this.cachedEventUids.add(nM(e)),
            (this.lastProcessedEventTime = Date.now());
        }
      }
      function nM(e) {
        return [e.type, e.eventId, e.sessionId, e.tenantId]
          .filter((e) => e)
          .join("-");
      }
      function nU({ type: e, error: t }) {
        return "unknown" === e && t?.code === "auth/no-auth-event";
      }
      async function nF(e, t = {}) {
        return V(e, "GET", "/v1/projects", t);
      }
      let nV = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,
        nx = /^https?/;
      async function nH(e) {
        if (e.config.emulator) return;
        let { authorizedDomains: t } = await nF(e);
        for (let e of t)
          try {
            if (
              (function (e) {
                let t = P(),
                  { protocol: i, hostname: n } = new URL(t);
                if (e.startsWith("chrome-extension://")) {
                  let r = new URL(e);
                  return "" === r.hostname && "" === n
                    ? "chrome-extension:" === i &&
                        e.replace("chrome-extension://", "") ===
                          t.replace("chrome-extension://", "")
                    : "chrome-extension:" === i && r.hostname === n;
                }
                if (!nx.test(i)) return !1;
                if (nV.test(e)) return n === e;
                let r = e.replace(/\./g, "\\.");
                return RegExp("^(.+\\." + r + "|" + r + ")$", "i").test(n);
              })(e)
            )
              return;
          } catch {}
        T(e, "unauthorized-domain");
      }
      let nK = new b(3e4, 6e4);
      function nj() {
        let e = iK().___jsl;
        if (e?.H) {
          for (let t of Object.keys(e.H))
            if (
              ((e.H[t].r = e.H[t].r || []),
              (e.H[t].L = e.H[t].L || []),
              (e.H[t].r = [...e.H[t].L]),
              e.CP)
            )
              for (let t = 0; t < e.CP.length; t++) e.CP[t] = null;
        }
      }
      let nq = null,
        nW = new b(5e3, 15e3),
        nz = {
          style: {
            position: "absolute",
            top: "-100px",
            width: "1px",
            height: "1px",
          },
          "aria-hidden": "true",
          tabindex: "-1",
        },
        nG = new Map([
          ["identitytoolkit.googleapis.com", "p"],
          ["staging-identitytoolkit.sandbox.googleapis.com", "s"],
          ["test-identitytoolkit.sandbox.googleapis.com", "t"],
        ]);
      async function n$(e) {
        let t,
          i,
          n,
          a,
          o,
          c = await (nq =
            nq ||
            new Promise((t, i) => {
              function n() {
                nj(),
                  gapi.load("gapi.iframes", {
                    callback: () => {
                      t(gapi.iframes.getContext());
                    },
                    ontimeout: () => {
                      nj(), i(E(e, "network-request-failed"));
                    },
                    timeout: nK.get(),
                  });
              }
              if (iK().gapi?.iframes?.Iframe) t(gapi.iframes.getContext());
              else if (iK().gapi?.load) n();
              else {
                let t = eH("iframefcb");
                return (
                  (iK()[t] = () => {
                    gapi.load ? n() : i(E(e, "network-request-failed"));
                  }),
                  ex(`${eV.gapiScript}?onload=${t}`).catch((e) => i(e))
                );
              }
            }).catch((e) => {
              throw ((nq = null), e);
            })),
          l = iK().gapi;
        return (
          k(l, e, "internal-error"),
          c.open(
            {
              where: document.body,
              url:
                (k((t = e.config).authDomain, e, "auth-domain-config-required"),
                (i = t.emulator
                  ? C(t, "emulator/auth/iframe")
                  : `https://${e.config.authDomain}/__/auth/iframe`),
                (n = { apiKey: t.apiKey, appName: e.name, v: r.MF }),
                (a = nG.get(e.config.apiHost)) && (n.eid = a),
                (o = e._getFrameworks()).length && (n.fw = o.join(",")),
                `${i}?${(0, s.Am)(n).slice(1)}`),
              messageHandlersFilter: l.iframes.CROSS_ORIGIN_IFRAMES_FILTER,
              attributes: nz,
              dontclear: !0,
            },
            (t) =>
              new Promise(async (i, n) => {
                await t.restyle({ setHideOnLeave: !1 });
                let r = E(e, "network-request-failed"),
                  s = iK().setTimeout(() => {
                    n(r);
                  }, nW.get());
                function a() {
                  iK().clearTimeout(s), i(t);
                }
                t.ping(a).then(a, () => {
                  n(r);
                });
              })
          )
        );
      }
      let nB = {
        location: "yes",
        resizable: "yes",
        statusbar: "yes",
        toolbar: "no",
      };
      class nJ {
        constructor(e) {
          (this.window = e), (this.associatedEvent = null);
        }
        close() {
          if (this.window)
            try {
              this.window.close();
            } catch (e) {}
        }
      }
      let nY = encodeURIComponent("fac");
      async function nZ(e, t, i, n, a, o) {
        k(e.config.authDomain, e, "auth-domain-config-required"),
          k(e.config.apiKey, e, "invalid-api-key");
        let c = {
          apiKey: e.config.apiKey,
          appName: e.name,
          authType: i,
          redirectUrl: n,
          v: r.MF,
          eventId: a,
        };
        if (t instanceof tf)
          for (let [i, n] of (t.setDefaultLanguage(e.languageCode),
          (c.providerId = t.providerId || ""),
          (0, s.Im)(t.getCustomParameters()) ||
            (c.customParameters = JSON.stringify(t.getCustomParameters())),
          Object.entries(o || {})))
            c[i] = n;
        if (t instanceof tg) {
          let e = t.getScopes().filter((e) => "" !== e);
          e.length > 0 && (c.scopes = e.join(","));
        }
        for (let t of (e.tenantId && (c.tid = e.tenantId), Object.keys(c)))
          void 0 === c[t] && delete c[t];
        let l = await e._getAppCheckToken(),
          u = l ? `#${nY}=${encodeURIComponent(l)}` : "";
        return `${(function ({ config: e }) {
          return e.emulator
            ? C(e, "emulator/auth/handler")
            : `https://${e.authDomain}/__/auth/handler`;
        })(e)}?${(0, s.Am)(c).slice(1)}${u}`;
      }
      let nQ = "webStorageSupport";
      class nX {
        constructor() {
          (this.eventManagers = {}),
            (this.iframes = {}),
            (this.originValidationPromises = {}),
            (this._redirectPersistence = iF),
            (this._completeRedirectFn = nC),
            (this._overrideRedirectResult = ny);
        }
        async _openPopup(e, t, i, n) {
          var r, a;
          (r = this.eventManagers[e._key()]?.manager),
            (a = "_initialize() not called before _openPopup()"),
            r || R(a);
          let o = await nZ(e, t, i, P(), n);
          return (function (e, t, i, n = 500, r = 600) {
            let a = Math.max((window.screen.availHeight - r) / 2, 0).toString(),
              o = Math.max((window.screen.availWidth - n) / 2, 0).toString(),
              c = "",
              l = {
                ...nB,
                width: n.toString(),
                height: r.toString(),
                top: a,
                left: o,
              },
              u = (0, s.ZQ)().toLowerCase();
            i && (c = eA(u) ? "_blank" : i),
              ey(u) && ((t = t || "http://localhost"), (l.scrollbars = "yes"));
            let h = Object.entries(l).reduce(
              (e, [t, i]) => `${e}${t}=${i},`,
              ""
            );
            if (
              (function (e = (0, s.ZQ)()) {
                return eN(e) && !!window.navigator?.standalone;
              })(u) &&
              "_self" !== c
            ) {
              var d, p;
              let e, i;
              return (
                (d = t || ""),
                (p = c),
                ((e = document.createElement("a")).href = d),
                (e.target = p),
                (i = document.createEvent("MouseEvent")).initMouseEvent(
                  "click",
                  !0,
                  !0,
                  window,
                  1,
                  0,
                  0,
                  0,
                  0,
                  !1,
                  !1,
                  !1,
                  !1,
                  1,
                  null
                ),
                e.dispatchEvent(i),
                new nJ(null)
              );
            }
            let m = window.open(t || "", c, h);
            k(m, e, "popup-blocked");
            try {
              m.focus();
            } catch (e) {}
            return new nJ(m);
          })(e, o, ix());
        }
        async _openRedirect(e, t, i, n) {
          var r;
          return (
            await this._originValidation(e),
            (r = await nZ(e, t, i, P(), n)),
            (iK().location.href = r),
            new Promise(() => {})
          );
        }
        _initialize(e) {
          let t = e._key();
          if (this.eventManagers[t]) {
            var i;
            let { manager: e, promise: n } = this.eventManagers[t];
            return e
              ? Promise.resolve(e)
              : ((i = "If manager is not set, promise should be"),
                n || R(i),
                n);
          }
          let n = this.initAndGetManager(e);
          return (
            (this.eventManagers[t] = { promise: n }),
            n.catch(() => {
              delete this.eventManagers[t];
            }),
            n
          );
        }
        async initAndGetManager(e) {
          let t = await n$(e),
            i = new nL(e);
          return (
            t.register(
              "authEvent",
              (t) => (
                k(t?.authEvent, e, "invalid-auth-event"),
                { status: i.onEvent(t.authEvent) ? "ACK" : "ERROR" }
              ),
              gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER
            ),
            (this.eventManagers[e._key()] = { manager: i }),
            (this.iframes[e._key()] = t),
            i
          );
        }
        _isIframeWebStorageSupported(e, t) {
          this.iframes[e._key()].send(
            nQ,
            { type: nQ },
            (i) => {
              let n = i?.[0]?.[nQ];
              void 0 !== n && t(!!n), T(e, "internal-error");
            },
            gapi.iframes.CROSS_ORIGIN_IFRAMES_FILTER
          );
        }
        _originValidation(e) {
          let t = e._key();
          return (
            this.originValidationPromises[t] ||
              (this.originValidationPromises[t] = nH(e)),
            this.originValidationPromises[t]
          );
        }
        get _shouldInitProactively() {
          return eO() || ew() || eN();
        }
      }
      let n0 = nX;
      class n1 {
        constructor(e) {
          this.factorId = e;
        }
        _process(e, t, i) {
          switch (t.type) {
            case "enroll":
              return this._finalizeEnroll(e, t.credential, i);
            case "signin":
              return this._finalizeSignIn(e, t.credential);
            default:
              return R("unexpected MultiFactorSessionType");
          }
        }
      }
      class n3 extends n1 {
        constructor(e) {
          super("phone"), (this.credential = e);
        }
        static _fromCredential(e) {
          return new n3(e);
        }
        _finalizeEnroll(e, t, i) {
          return V(
            e,
            "POST",
            "/v2/accounts/mfaEnrollment:finalize",
            F(e, {
              idToken: t,
              displayName: i,
              phoneVerificationInfo: this.credential._makeVerificationRequest(),
            })
          );
        }
        _finalizeSignIn(e, t) {
          return V(
            e,
            "POST",
            "/v2/accounts/mfaSignIn:finalize",
            F(e, {
              mfaPendingCredential: t,
              phoneVerificationInfo: this.credential._makeVerificationRequest(),
            })
          );
        }
      }
      class n2 {
        static assertion(e) {
          return n3._fromCredential(e);
        }
      }
      n2.FACTOR_ID = "phone";
      class n6 {
        static assertionForEnrollment(e, t) {
          return n4._fromSecret(e, t);
        }
        static assertionForSignIn(e, t) {
          return n4._fromEnrollmentId(e, t);
        }
        static async generateSecret(e) {
          var t;
          k(void 0 !== e.user?.auth, "internal-error");
          let i = await V(
            (t = e.user.auth),
            "POST",
            "/v2/accounts/mfaEnrollment:start",
            F(t, { idToken: e.credential, totpEnrollmentInfo: {} })
          );
          return n9._fromStartTotpMfaEnrollmentResponse(i, e.user.auth);
        }
      }
      n6.FACTOR_ID = "totp";
      class n4 extends n1 {
        constructor(e, t, i) {
          super("totp"),
            (this.otp = e),
            (this.enrollmentId = t),
            (this.secret = i);
        }
        static _fromSecret(e, t) {
          return new n4(t, void 0, e);
        }
        static _fromEnrollmentId(e, t) {
          return new n4(t, e);
        }
        async _finalizeEnroll(e, t, i) {
          return (
            k(void 0 !== this.secret, e, "argument-error"),
            V(
              e,
              "POST",
              "/v2/accounts/mfaEnrollment:finalize",
              F(e, {
                idToken: t,
                displayName: i,
                totpVerificationInfo: this.secret._makeTotpVerificationInfo(
                  this.otp
                ),
              })
            )
          );
        }
        async _finalizeSignIn(e, t) {
          k(
            void 0 !== this.enrollmentId && void 0 !== this.otp,
            e,
            "argument-error"
          );
          let i = { verificationCode: this.otp };
          return V(
            e,
            "POST",
            "/v2/accounts/mfaSignIn:finalize",
            F(e, {
              mfaPendingCredential: t,
              mfaEnrollmentId: this.enrollmentId,
              totpVerificationInfo: i,
            })
          );
        }
      }
      class n9 {
        constructor(e, t, i, n, r, s, a) {
          (this.sessionInfo = s),
            (this.auth = a),
            (this.secretKey = e),
            (this.hashingAlgorithm = t),
            (this.codeLength = i),
            (this.codeIntervalSeconds = n),
            (this.enrollmentCompletionDeadline = r);
        }
        static _fromStartTotpMfaEnrollmentResponse(e, t) {
          return new n9(
            e.totpSessionInfo.sharedSecretKey,
            e.totpSessionInfo.hashingAlgorithm,
            e.totpSessionInfo.verificationCodeLength,
            e.totpSessionInfo.periodSec,
            new Date(e.totpSessionInfo.finalizeEnrollmentTime).toUTCString(),
            e.totpSessionInfo.sessionInfo,
            t
          );
        }
        _makeTotpVerificationInfo(e) {
          return { sessionInfo: this.sessionInfo, verificationCode: e };
        }
        generateQrCodeUrl(e, t) {
          let i = !1;
          return (
            (n5(e) || n5(t)) && (i = !0),
            i &&
              (n5(e) && (e = this.auth.currentUser?.email || "unknownuser"),
              n5(t) && (t = this.auth.name)),
            `otpauth://totp/${t}:${e}?secret=${this.secretKey}&issuer=${t}&algorithm=${this.hashingAlgorithm}&digits=${this.codeLength}`
          );
        }
      }
      function n5(e) {
        return void 0 === e || e?.length === 0;
      }
      var n8 = "@firebase/auth",
        n7 = "1.12.0";
      class re {
        constructor(e) {
          (this.auth = e), (this.internalListeners = new Map());
        }
        getUid() {
          return (
            this.assertAuthConfigured(), this.auth.currentUser?.uid || null
          );
        }
        async getToken(e) {
          return (this.assertAuthConfigured(),
          await this.auth._initializationPromise,
          this.auth.currentUser)
            ? { accessToken: await this.auth.currentUser.getIdToken(e) }
            : null;
        }
        addAuthTokenListener(e) {
          if ((this.assertAuthConfigured(), this.internalListeners.has(e)))
            return;
          let t = this.auth.onIdTokenChanged((t) => {
            e(t?.stsTokenManager.accessToken || null);
          });
          this.internalListeners.set(e, t), this.updateProactiveRefresh();
        }
        removeAuthTokenListener(e) {
          this.assertAuthConfigured();
          let t = this.internalListeners.get(e);
          t &&
            (this.internalListeners.delete(e),
            t(),
            this.updateProactiveRefresh());
        }
        assertAuthConfigured() {
          k(
            this.auth._initializationPromise,
            "dependent-sdk-initialized-before-auth"
          );
        }
        updateProactiveRefresh() {
          this.internalListeners.size > 0
            ? this.auth._startProactiveRefresh()
            : this.auth._stopProactiveRefresh();
        }
      }
      let rt = (0, s.XA)("authIdTokenMaxAge") || 300,
        ri = null;
      function rn(e = (0, r.Sx)()) {
        let t = (0, r.j6)(e, "auth");
        if (t.isInitialized()) return t.getImmediate();
        let i = eY(e, { popupRedirectResolver: n0, persistence: [i0, ib, iF] }),
          n = (0, s.XA)("authTokenSyncURL");
        if (n && "boolean" == typeof isSecureContext && isSecureContext) {
          let e = new URL(n, location.origin);
          if (location.origin === e.origin) {
            let t,
              n =
                ((t = e.toString()),
                async (e) => {
                  let i = e && (await e.getIdTokenResult()),
                    n =
                      i &&
                      (new Date().getTime() - Date.parse(i.issuedAtTime)) / 1e3;
                  if (n && n > rt) return;
                  let r = i?.token;
                  ri !== r &&
                    ((ri = r),
                    await fetch(t, {
                      method: r ? "POST" : "DELETE",
                      headers: r ? { Authorization: `Bearer ${r}` } : {},
                    }));
                });
            ip(i, n, () => n(i.currentUser)), id(i, (e) => n(e));
          }
        }
        let a = (0, s.Tj)("auth");
        return a && eZ(i, `http://${a}`), i;
      }
      (eV = {
        loadJS: (e) =>
          new Promise((t, i) => {
            let n = document.createElement("script");
            n.setAttribute("src", e),
              (n.onload = t),
              (n.onerror = (e) => {
                let t = E("internal-error");
                (t.customData = e), i(t);
              }),
              (n.type = "text/javascript"),
              (n.charset = "UTF-8"),
              (
                document.getElementsByTagName("head")?.[0] ?? document
              ).appendChild(n);
          }),
        gapiScript: "https://apis.google.com/js/api.js",
        recaptchaV2Script: "https://www.google.com/recaptcha/api.js",
        recaptchaEnterpriseScript:
          "https://www.google.com/recaptcha/enterprise.js?render=",
      }),
        (n = "Browser"),
        (0, r.om)(
          new o.uA(
            "auth",
            (e, { options: t }) => {
              let i,
                r,
                s = e.getProvider("app").getImmediate(),
                a = e.getProvider("heartbeat"),
                o = e.getProvider("app-check-internal"),
                { apiKey: c, authDomain: l } = s.options;
              k(c && !c.includes(":"), "invalid-api-key", { appName: s.name });
              let u = new eM(s, a, o, {
                apiKey: c,
                authDomain: l,
                clientPlatform: n,
                apiHost: "identitytoolkit.googleapis.com",
                tokenApiHost: "securetoken.googleapis.com",
                apiScheme: "https",
                sdkClientVersion: eb(n),
              });
              return (
                (r = (Array.isArray((i = t?.persistence || [])) ? i : [i]).map(
                  eg
                )),
                t?.errorMap && u._updateErrorMap(t.errorMap),
                u._initializeWithPersistence(r, t?.popupRedirectResolver),
                u
              );
            },
            "PUBLIC"
          )
            .setInstantiationMode("EXPLICIT")
            .setInstanceCreatedCallback((e, t, i) => {
              e.getProvider("auth-internal").initialize();
            })
        ),
        (0, r.om)(
          new o.uA(
            "auth-internal",
            (e) => new re(eU(e.getProvider("auth").getImmediate())),
            "PRIVATE"
          ).setInstantiationMode("EXPLICIT")
        ),
        (0, r.KO)(
          n8,
          n7,
          (function (e) {
            switch (e) {
              case "Node":
                return "node";
              case "ReactNative":
                return "rn";
              case "Worker":
                return "webworker";
              case "Cordova":
                return "cordova";
              case "WebExtension":
                return "web-extension";
              default:
                return;
            }
          })(n)
        ),
        (0, r.KO)(n8, n7, "esm2020");
    },
  },
]);
