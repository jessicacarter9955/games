!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var n = 1; n < arguments.length; n++) {
          var t = arguments[n];
          if (null != t) for (var r in t) t.hasOwnProperty(r) && (e[r] = t[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "1239a9f4-5a57-499e-993b-d41b7f07cd71"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-1239a9f4-5a57-499e-993b-d41b7f07cd71"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [63877],
    {
      148: (e) => {
        "use strict";
        e.exports = function (e) {
          return null == e ? [] : "length" in e ? e : [e];
        };
      },
      1050: (e) => {
        let n = ["http", "https", "mailto", "tel"];
        e.exports = function (e) {
          let t = (e || "").trim(),
            r = t.charAt(0);
          if ("#" === r || "/" === r) return t;
          let i = t.indexOf(":");
          if (-1 === i) return t;
          let o = -1;
          for (; ++o < n.length; ) {
            let e = n[o];
            if (i === e.length && t.slice(0, e.length).toLowerCase() === e)
              return t;
          }
          return (-1 !== (o = t.indexOf("?")) && i > o) ||
            (-1 !== (o = t.indexOf("#")) && i > o)
            ? t
            : "javascript:void(0)";
        };
      },
      1490: (e) => {
        "use strict";
        e.exports = JSON.parse(
          '{"classId":"classID","dataType":"datatype","itemId":"itemID","strokeDashArray":"strokeDasharray","strokeDashOffset":"strokeDashoffset","strokeLineCap":"strokeLinecap","strokeLineJoin":"strokeLinejoin","strokeMiterLimit":"strokeMiterlimit","typeOf":"typeof","xLinkActuate":"xlinkActuate","xLinkArcRole":"xlinkArcrole","xLinkHref":"xlinkHref","xLinkRole":"xlinkRole","xLinkShow":"xlinkShow","xLinkTitle":"xlinkTitle","xLinkType":"xlinkType","xmlnsXLink":"xmlnsXlink"}'
        );
      },
      2988: (e, n, t) => {
        "use strict";
        var r = t(95358);
        function i() {}
        (e.exports = l),
          (i.prototype = Error.prototype),
          (l.prototype = new i());
        var o = l.prototype;
        function l(e, n, t) {
          var i, o, l, u, a;
          "string" == typeof n && ((t = n), (n = null)),
            (a = [null, null]),
            "string" == typeof (l = t) &&
              (-1 === (u = l.indexOf(":"))
                ? (a[1] = l)
                : ((a[0] = l.slice(0, u)), (a[1] = l.slice(u + 1)))),
            (i = r(n) || "1:1"),
            (o = {
              start: { line: null, column: null },
              end: { line: null, column: null },
            }),
            n && n.position && (n = n.position),
            n && (n.start ? ((o = n), (n = n.start)) : (o.start = n)),
            e.stack && ((this.stack = e.stack), (e = e.message)),
            (this.message = e),
            (this.name = i),
            (this.reason = e),
            (this.line = n ? n.line : null),
            (this.column = n ? n.column : null),
            (this.location = o),
            (this.source = parts[0]),
            (this.ruleId = parts[1]);
        }
        (o.file = ""),
          (o.name = ""),
          (o.reason = ""),
          (o.message = ""),
          (o.stack = ""),
          (o.fatal = null),
          (o.column = null),
          (o.line = null);
      },
      3389: (e) => {
        "use strict";
        e.exports = (e) => {
          if ("[object Object]" !== Object.prototype.toString.call(e))
            return !1;
          let n = Object.getPrototypeOf(e);
          return null === n || n === Object.prototype;
        };
      },
      4140: (e) => {
        "use strict";
        e.exports = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED";
      },
      4235: (e, n, t) => {
        "use strict";
        var r = t(10124),
          i = t(46399),
          o = t(74058),
          l = r.boolean,
          u = r.overloadedBoolean,
          a = r.booleanish,
          s = r.number,
          c = r.spaceSeparated,
          f = r.commaSeparated;
        e.exports = i({
          space: "html",
          attributes: {
            acceptcharset: "accept-charset",
            classname: "class",
            htmlfor: "for",
            httpequiv: "http-equiv",
          },
          transform: o,
          mustUseProperty: ["checked", "multiple", "muted", "selected"],
          properties: {
            abbr: null,
            accept: f,
            acceptCharset: c,
            accessKey: c,
            action: null,
            allow: null,
            allowFullScreen: l,
            allowPaymentRequest: l,
            allowUserMedia: l,
            alt: null,
            as: null,
            async: l,
            autoCapitalize: null,
            autoComplete: c,
            autoFocus: l,
            autoPlay: l,
            capture: l,
            charSet: null,
            checked: l,
            cite: null,
            className: c,
            cols: s,
            colSpan: null,
            content: null,
            contentEditable: a,
            controls: l,
            controlsList: c,
            coords: s | f,
            crossOrigin: null,
            data: null,
            dateTime: null,
            decoding: null,
            default: l,
            defer: l,
            dir: null,
            dirName: null,
            disabled: l,
            download: u,
            draggable: a,
            encType: null,
            enterKeyHint: null,
            form: null,
            formAction: null,
            formEncType: null,
            formMethod: null,
            formNoValidate: l,
            formTarget: null,
            headers: c,
            height: s,
            hidden: l,
            high: s,
            href: null,
            hrefLang: null,
            htmlFor: c,
            httpEquiv: c,
            id: null,
            imageSizes: null,
            imageSrcSet: f,
            inputMode: null,
            integrity: null,
            is: null,
            isMap: l,
            itemId: null,
            itemProp: c,
            itemRef: c,
            itemScope: l,
            itemType: c,
            kind: null,
            label: null,
            lang: null,
            language: null,
            list: null,
            loading: null,
            loop: l,
            low: s,
            manifest: null,
            max: null,
            maxLength: s,
            media: null,
            method: null,
            min: null,
            minLength: s,
            multiple: l,
            muted: l,
            name: null,
            nonce: null,
            noModule: l,
            noValidate: l,
            onAbort: null,
            onAfterPrint: null,
            onAuxClick: null,
            onBeforePrint: null,
            onBeforeUnload: null,
            onBlur: null,
            onCancel: null,
            onCanPlay: null,
            onCanPlayThrough: null,
            onChange: null,
            onClick: null,
            onClose: null,
            onContextMenu: null,
            onCopy: null,
            onCueChange: null,
            onCut: null,
            onDblClick: null,
            onDrag: null,
            onDragEnd: null,
            onDragEnter: null,
            onDragExit: null,
            onDragLeave: null,
            onDragOver: null,
            onDragStart: null,
            onDrop: null,
            onDurationChange: null,
            onEmptied: null,
            onEnded: null,
            onError: null,
            onFocus: null,
            onFormData: null,
            onHashChange: null,
            onInput: null,
            onInvalid: null,
            onKeyDown: null,
            onKeyPress: null,
            onKeyUp: null,
            onLanguageChange: null,
            onLoad: null,
            onLoadedData: null,
            onLoadedMetadata: null,
            onLoadEnd: null,
            onLoadStart: null,
            onMessage: null,
            onMessageError: null,
            onMouseDown: null,
            onMouseEnter: null,
            onMouseLeave: null,
            onMouseMove: null,
            onMouseOut: null,
            onMouseOver: null,
            onMouseUp: null,
            onOffline: null,
            onOnline: null,
            onPageHide: null,
            onPageShow: null,
            onPaste: null,
            onPause: null,
            onPlay: null,
            onPlaying: null,
            onPopState: null,
            onProgress: null,
            onRateChange: null,
            onRejectionHandled: null,
            onReset: null,
            onResize: null,
            onScroll: null,
            onSecurityPolicyViolation: null,
            onSeeked: null,
            onSeeking: null,
            onSelect: null,
            onSlotChange: null,
            onStalled: null,
            onStorage: null,
            onSubmit: null,
            onSuspend: null,
            onTimeUpdate: null,
            onToggle: null,
            onUnhandledRejection: null,
            onUnload: null,
            onVolumeChange: null,
            onWaiting: null,
            onWheel: null,
            open: l,
            optimum: s,
            pattern: null,
            ping: c,
            placeholder: null,
            playsInline: l,
            poster: null,
            preload: null,
            readOnly: l,
            referrerPolicy: null,
            rel: c,
            required: l,
            reversed: l,
            rows: s,
            rowSpan: s,
            sandbox: c,
            scope: null,
            scoped: l,
            seamless: l,
            selected: l,
            shape: null,
            size: s,
            sizes: null,
            slot: null,
            span: s,
            spellCheck: a,
            src: null,
            srcDoc: null,
            srcLang: null,
            srcSet: f,
            start: s,
            step: null,
            style: null,
            tabIndex: s,
            target: null,
            title: null,
            translate: null,
            type: null,
            typeMustMatch: l,
            useMap: null,
            value: a,
            width: s,
            wrap: null,
            align: null,
            aLink: null,
            archive: c,
            axis: null,
            background: null,
            bgColor: null,
            border: s,
            borderColor: null,
            bottomMargin: s,
            cellPadding: null,
            cellSpacing: null,
            char: null,
            charOff: null,
            classId: null,
            clear: null,
            code: null,
            codeBase: null,
            codeType: null,
            color: null,
            compact: l,
            declare: l,
            event: null,
            face: null,
            frame: null,
            frameBorder: null,
            hSpace: s,
            leftMargin: s,
            link: null,
            longDesc: null,
            lowSrc: null,
            marginHeight: s,
            marginWidth: s,
            noResize: l,
            noHref: l,
            noShade: l,
            noWrap: l,
            object: null,
            profile: null,
            prompt: null,
            rev: null,
            rightMargin: s,
            rules: null,
            scheme: null,
            scrolling: a,
            standby: null,
            summary: null,
            text: null,
            topMargin: s,
            valueType: null,
            version: null,
            vAlign: null,
            vLink: null,
            vSpace: s,
            allowTransparency: null,
            autoCorrect: null,
            autoSave: null,
            disablePictureInPicture: l,
            disableRemotePlayback: l,
            prefix: null,
            property: null,
            results: s,
            security: null,
            unselectable: null,
          },
        });
      },
      5154: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          return e(n, "blockquote", r(i(e, n), !0));
        };
        var r = t(12721),
          i = t(73684);
      },
      6013: (e, n, t) => {
        "use strict";
        var r = t(25842);
        e.exports = function (e, n) {
          var t;
          return (
            (t = (function (e) {
              var n = {};
              if (!e || !e.type)
                throw Error("mdast-util-definitions expected node");
              return (
                r(e, "definition", function (e) {
                  var t = o(e.identifier);
                  i.call(n, t) || (n[t] = e);
                }),
                n
              );
            })(e)),
            function (e) {
              var n = e && o(e);
              return n && i.call(t, n) ? t[n] : null;
            }
          );
        };
        var i = {}.hasOwnProperty;
        function o(e) {
          return e.toUpperCase();
        }
      },
      6495: (e, n, t) => {
        "use strict";
        e.exports = function (e, n, t) {
          var u,
            a = n && n.type;
          if (!a) throw Error("Expected node, got `" + n + "`");
          return (
            "function" ==
              typeof (u = o.call(e.handlers, a)
                ? e.handlers[a]
                : e.passThrough && e.passThrough.indexOf(a) > -1
                ? l
                : e.unknownHandler)
              ? u
              : function (e, n) {
                  var t, l;
                  return ((l = (t = n).data || {}),
                  !(
                    o.call(l, "hName") ||
                    o.call(l, "hProperties") ||
                    o.call(l, "hChildren")
                  ) && "value" in t)
                    ? e.augment(n, r("text", n.value))
                    : e(n, "div", i(e, n));
                }
          )(e, n, t);
        };
        var r = t(69921),
          i = t(73684),
          o = {}.hasOwnProperty;
        function l(e, n) {
          var t;
          return n.children
            ? (((t = Object.assign({}, n)).children = i(e, n)), t)
            : n;
        }
      },
      6694: (e, n, t) => {
        "use strict";
        e.exports = t(46399)({
          space: "xlink",
          transform: function (e, n) {
            return "xlink:" + n.slice(5).toLowerCase();
          },
          properties: {
            xLinkActuate: null,
            xLinkArcRole: null,
            xLinkHref: null,
            xLinkRole: null,
            xLinkShow: null,
            xLinkTitle: null,
            xLinkType: null,
          },
        });
      },
      8979: (e, n, t) => {
        "use strict";
        e.exports = function (e, n, t) {
          var l,
            u,
            a,
            s = i(e, n),
            c = s[0],
            f = t
              ? (function (e) {
                  for (
                    var n = e.spread, t = e.children, r = t.length, i = -1;
                    !n && ++i < r;

                  )
                    n = o(t[i]);
                  return n;
                })(t)
              : o(n),
            p = {},
            d = [];
          for (
            "boolean" == typeof n.checked &&
              ((c && "p" === c.tagName) ||
                ((c = e(null, "p", [])), s.unshift(c)),
              c.children.length > 0 && c.children.unshift(r("text", " ")),
              c.children.unshift(
                e(null, "input", {
                  type: "checkbox",
                  checked: n.checked,
                  disabled: !0,
                })
              ),
              (p.className = ["task-list-item"])),
              l = s.length,
              u = -1;
            ++u < l;

          )
            (a = s[u]),
              (f || 0 !== u || "p" !== a.tagName) && d.push(r("text", "\n")),
              "p" !== a.tagName || f ? d.push(a) : (d = d.concat(a.children));
          return (
            l && (f || "p" !== a.tagName) && d.push(r("text", "\n")),
            e(n, "li", p, d)
          );
        };
        var r = t(69921),
          i = t(73684);
        function o(e) {
          var n = e.spread;
          return null == n ? e.children.length > 1 : n;
        }
      },
      10101: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          var t,
            l = e.definition(n.identifier);
          return l
            ? ((t = { href: r(l.url || "") }),
              null !== l.title && void 0 !== l.title && (t.title = l.title),
              e(n, "a", t, o(e, n)))
            : i(e, n);
        };
        var r = t(37910),
          i = t(27371),
          o = t(73684);
      },
      10124: (e, n) => {
        "use strict";
        var t = 0;
        function r() {
          return Math.pow(2, ++t);
        }
        (n.boolean = r()),
          (n.booleanish = r()),
          (n.overloadedBoolean = r()),
          (n.number = r()),
          (n.spaceSeparated = r()),
          (n.commaSeparated = r()),
          (n.commaOrSpaceSeparated = r());
      },
      10312: (e, n, t) => {
        "use strict";
        e.exports = function (e, n, t) {
          return (
            "string" != typeof n && ((t = n), (n = void 0)),
            (function (e) {
              var n = (function (e, n) {
                  for (var t = -1; ++t < n.length; )
                    !(function (e, n) {
                      var t, r;
                      for (t in n)
                        (r = o.call(e, t) ? e[t] : (e[t] = {})),
                          "canContainEols" === t || "transforms" === t
                            ? (e[t] = [].concat(r, n[t]))
                            : Object.assign(r, n[t]);
                    })(e, n[t]);
                  return e;
                })(
                  {
                    transforms: [],
                    canContainEols: [
                      "emphasis",
                      "fragment",
                      "heading",
                      "paragraph",
                      "strong",
                    ],
                    enter: {
                      autolink: d(P),
                      autolinkProtocol: y,
                      autolinkEmail: y,
                      atxHeading: d(E),
                      blockQuote: d(function () {
                        return { type: "blockquote", children: [] };
                      }),
                      characterEscape: y,
                      characterReference: y,
                      codeFenced: d(w),
                      codeFencedFenceInfo: h,
                      codeFencedFenceMeta: h,
                      codeIndented: d(w, h),
                      codeText: d(function () {
                        return { type: "inlineCode", value: "" };
                      }, h),
                      codeTextData: y,
                      data: y,
                      codeFlowValue: y,
                      definition: d(function () {
                        return {
                          type: "definition",
                          identifier: "",
                          label: null,
                          title: null,
                          url: "",
                        };
                      }),
                      definitionDestinationString: h,
                      definitionLabelString: h,
                      definitionTitleString: h,
                      emphasis: d(function () {
                        return { type: "emphasis", children: [] };
                      }),
                      hardBreakEscape: d(C),
                      hardBreakTrailing: d(C),
                      htmlFlow: d(F, h),
                      htmlFlowData: y,
                      htmlText: d(F, h),
                      htmlTextData: y,
                      image: d(function () {
                        return {
                          type: "image",
                          title: null,
                          url: "",
                          alt: null,
                        };
                      }),
                      label: h,
                      link: d(P),
                      listItem: d(function (e) {
                        return {
                          type: "listItem",
                          spread: e._spread,
                          checked: null,
                          children: [],
                        };
                      }),
                      listItemValue: function (e) {
                        t.expectingFirstListItemValue &&
                          ((this.stack[this.stack.length - 2].start = parseInt(
                            this.sliceSerialize(e),
                            10
                          )),
                          (t.expectingFirstListItemValue = void 0));
                      },
                      listOrdered: d(T, function () {
                        t.expectingFirstListItemValue = !0;
                      }),
                      listUnordered: d(T),
                      paragraph: d(function () {
                        return { type: "paragraph", children: [] };
                      }),
                      reference: function () {
                        t.referenceType = "collapsed";
                      },
                      referenceString: h,
                      resourceDestinationString: h,
                      resourceTitleString: h,
                      setextHeading: d(E),
                      strong: d(function () {
                        return { type: "strong", children: [] };
                      }),
                      thematicBreak: d(function () {
                        return { type: "thematicBreak" };
                      }),
                    },
                    exit: {
                      atxHeading: g(),
                      atxHeadingSequence: function (e) {
                        this.stack[this.stack.length - 1].depth ||
                          (this.stack[this.stack.length - 1].depth =
                            this.sliceSerialize(e).length);
                      },
                      autolink: g(),
                      autolinkEmail: function (e) {
                        k.call(this, e),
                          (this.stack[this.stack.length - 1].url =
                            "mailto:" + this.sliceSerialize(e));
                      },
                      autolinkProtocol: function (e) {
                        k.call(this, e),
                          (this.stack[this.stack.length - 1].url =
                            this.sliceSerialize(e));
                      },
                      blockQuote: g(),
                      characterEscapeValue: k,
                      characterReferenceMarkerHexadecimal: S,
                      characterReferenceMarkerNumeric: S,
                      characterReferenceValue: function (e) {
                        var n,
                          r,
                          i = this.sliceSerialize(e),
                          o = t.characterReferenceType;
                        o
                          ? ((n = u(
                              i,
                              "characterReferenceMarkerNumeric" === o ? 10 : 16
                            )),
                            (t.characterReferenceType = void 0))
                          : (n = f(i)),
                          (r = this.stack.pop()),
                          (r.value += n),
                          (r.position.end = c(e.end));
                      },
                      codeFenced: g(function () {
                        var e = this.resume();
                        (this.stack[this.stack.length - 1].value = e.replace(
                          /^(\r?\n|\r)|(\r?\n|\r)$/g,
                          ""
                        )),
                          (t.flowCodeInside = void 0);
                      }),
                      codeFencedFence: function () {
                        !t.flowCodeInside &&
                          (this.buffer(), (t.flowCodeInside = !0));
                      },
                      codeFencedFenceInfo: function () {
                        var e = this.resume();
                        this.stack[this.stack.length - 1].lang = e;
                      },
                      codeFencedFenceMeta: function () {
                        var e = this.resume();
                        this.stack[this.stack.length - 1].meta = e;
                      },
                      codeFlowValue: k,
                      codeIndented: g(function () {
                        var e = this.resume();
                        this.stack[this.stack.length - 1].value = e;
                      }),
                      codeText: g(function () {
                        var e = this.resume();
                        this.stack[this.stack.length - 1].value = e;
                      }),
                      codeTextData: k,
                      data: k,
                      definition: g(),
                      definitionDestinationString: function () {
                        var e = this.resume();
                        this.stack[this.stack.length - 1].url = e;
                      },
                      definitionLabelString: function (e) {
                        var n = this.resume();
                        (this.stack[this.stack.length - 1].label = n),
                          (this.stack[this.stack.length - 1].identifier = l(
                            this.sliceSerialize(e)
                          ).toLowerCase());
                      },
                      definitionTitleString: function () {
                        var e = this.resume();
                        this.stack[this.stack.length - 1].title = e;
                      },
                      emphasis: g(),
                      hardBreakEscape: g(b),
                      hardBreakTrailing: g(b),
                      htmlFlow: g(function () {
                        var e = this.resume();
                        this.stack[this.stack.length - 1].value = e;
                      }),
                      htmlFlowData: k,
                      htmlText: g(function () {
                        var e = this.resume();
                        this.stack[this.stack.length - 1].value = e;
                      }),
                      htmlTextData: k,
                      image: g(function () {
                        var e = this.stack[this.stack.length - 1];
                        t.inReference
                          ? ((e.type += "Reference"),
                            (e.referenceType = t.referenceType || "shortcut"),
                            delete e.url,
                            delete e.title)
                          : (delete e.identifier,
                            delete e.label,
                            delete e.referenceType),
                          (t.referenceType = void 0);
                      }),
                      label: function () {
                        var e = this.stack[this.stack.length - 1],
                          n = this.resume();
                        (this.stack[this.stack.length - 1].label = n),
                          (t.inReference = !0),
                          "link" === this.stack[this.stack.length - 1].type
                            ? (this.stack[this.stack.length - 1].children =
                                e.children)
                            : (this.stack[this.stack.length - 1].alt = n);
                      },
                      labelText: function (e) {
                        this.stack[this.stack.length - 2].identifier = l(
                          this.sliceSerialize(e)
                        ).toLowerCase();
                      },
                      lineEnding: function (e) {
                        var r = this.stack[this.stack.length - 1];
                        if (t.atHardBreak) {
                          (r.children[r.children.length - 1].position.end = c(
                            e.end
                          )),
                            (t.atHardBreak = void 0);
                          return;
                        }
                        !t.setextHeadingSlurpLineEnding &&
                          n.canContainEols.indexOf(r.type) > -1 &&
                          (y.call(this, e), k.call(this, e));
                      },
                      link: g(function () {
                        var e = this.stack[this.stack.length - 1];
                        t.inReference
                          ? ((e.type += "Reference"),
                            (e.referenceType = t.referenceType || "shortcut"),
                            delete e.url,
                            delete e.title)
                          : (delete e.identifier,
                            delete e.label,
                            delete e.referenceType),
                          (t.referenceType = void 0);
                      }),
                      listItem: g(),
                      listOrdered: g(),
                      listUnordered: g(),
                      paragraph: g(),
                      referenceString: function (e) {
                        var n = this.resume();
                        (this.stack[this.stack.length - 1].label = n),
                          (this.stack[this.stack.length - 1].identifier = l(
                            this.sliceSerialize(e)
                          ).toLowerCase()),
                          (t.referenceType = "full");
                      },
                      resourceDestinationString: function () {
                        var e = this.resume();
                        this.stack[this.stack.length - 1].url = e;
                      },
                      resourceTitleString: function () {
                        var e = this.resume();
                        this.stack[this.stack.length - 1].title = e;
                      },
                      resource: function () {
                        t.inReference = void 0;
                      },
                      setextHeading: g(function () {
                        t.setextHeadingSlurpLineEnding = void 0;
                      }),
                      setextHeadingLineSequence: function (e) {
                        this.stack[this.stack.length - 1].depth =
                          61 === this.sliceSerialize(e).charCodeAt(0) ? 1 : 2;
                      },
                      setextHeadingText: function () {
                        t.setextHeadingSlurpLineEnding = !0;
                      },
                      strong: g(),
                      thematicBreak: g(),
                    },
                  },
                  (e || {}).mdastExtensions || []
                ),
                t = {};
              return function (e) {
                for (
                  var t,
                    r,
                    l = { type: "root", children: [] },
                    u = [],
                    f = [],
                    d = -1,
                    g = {
                      stack: [l],
                      tokenStack: u,
                      config: n,
                      enter: m,
                      exit: v,
                      buffer: h,
                      resume: x,
                      setData: a,
                      getData: s,
                    };
                  ++d < e.length;

                )
                  ("listOrdered" === e[d][1].type ||
                    "listUnordered" === e[d][1].type) &&
                    ("enter" === e[d][0]
                      ? f.push(d)
                      : (d = (function (e, n, t) {
                          for (
                            var r, i, o, l, u, a, s, f = n - 1, p = -1, d = !1;
                            ++f <= t;

                          )
                            if (
                              ("listUnordered" === (u = e[f])[1].type ||
                              "listOrdered" === u[1].type ||
                              "blockQuote" === u[1].type
                                ? ("enter" === u[0] ? p++ : p--, (s = void 0))
                                : "lineEndingBlank" === u[1].type
                                ? "enter" === u[0] &&
                                  (!r || s || p || a || (a = f), (s = void 0))
                                : "linePrefix" === u[1].type ||
                                  "listItemValue" === u[1].type ||
                                  "listItemMarker" === u[1].type ||
                                  "listItemPrefix" === u[1].type ||
                                  "listItemPrefixWhitespace" === u[1].type ||
                                  (s = void 0),
                              (!p &&
                                "enter" === u[0] &&
                                "listItemPrefix" === u[1].type) ||
                                (-1 === p &&
                                  "exit" === u[0] &&
                                  ("listUnordered" === u[1].type ||
                                    "listOrdered" === u[1].type)))
                            ) {
                              if (r) {
                                for (i = f, o = void 0; i--; )
                                  if (
                                    "lineEnding" === (l = e[i])[1].type ||
                                    "lineEndingBlank" === l[1].type
                                  ) {
                                    if ("exit" === l[0]) continue;
                                    o &&
                                      ((e[o][1].type = "lineEndingBlank"),
                                      (d = !0)),
                                      (l[1].type = "lineEnding"),
                                      (o = i);
                                  } else if (
                                    "linePrefix" === l[1].type ||
                                    "blockQuotePrefix" === l[1].type ||
                                    "blockQuotePrefixWhitespace" ===
                                      l[1].type ||
                                    "blockQuoteMarker" === l[1].type ||
                                    "listItemIndent" === l[1].type
                                  );
                                  else break;
                                a && (!o || a < o) && (r._spread = !0),
                                  (r.end = c(o ? e[o][1].start : u[1].end)),
                                  e.splice(o || f, 0, ["exit", r, u[2]]),
                                  f++,
                                  t++;
                              }
                              "listItemPrefix" === u[1].type &&
                                ((r = {
                                  type: "listItem",
                                  _spread: !1,
                                  start: c(u[1].start),
                                }),
                                e.splice(f, 0, ["enter", r, u[2]]),
                                f++,
                                t++,
                                (a = void 0),
                                (s = !0));
                            }
                          return (e[n][1]._spread = d), t;
                        })(e, (r = f.pop(d)), d)));
                for (d = -1; ++d < e.length; )
                  (t = n[e[d][0]]),
                    o.call(t, e[d][1].type) &&
                      t[e[d][1].type].call(
                        i({ sliceSerialize: e[d][2].sliceSerialize }, g),
                        e[d][1]
                      );
                if (u.length)
                  throw Error(
                    "Cannot close document, a token (`" +
                      u[u.length - 1].type +
                      "`, " +
                      p({
                        start: u[u.length - 1].start,
                        end: u[u.length - 1].end,
                      }) +
                      ") is still open"
                  );
                for (
                  l.position = {
                    start: c(
                      e.length
                        ? e[0][1].start
                        : { line: 1, column: 1, offset: 0 }
                    ),
                    end: c(
                      e.length
                        ? e[e.length - 2][1].end
                        : { line: 1, column: 1, offset: 0 }
                    ),
                  },
                    d = -1;
                  ++d < n.transforms.length;

                )
                  l = n.transforms[d](l) || l;
                return l;
              };
              function a(e, n) {
                t[e] = n;
              }
              function s(e) {
                return t[e];
              }
              function c(e) {
                return { line: e.line, column: e.column, offset: e.offset };
              }
              function d(e, n) {
                return function (t) {
                  m.call(this, e(t), t), n && n.call(this, t);
                };
              }
              function h() {
                this.stack.push({ type: "fragment", children: [] });
              }
              function m(e, n) {
                return (
                  this.stack[this.stack.length - 1].children.push(e),
                  this.stack.push(e),
                  this.tokenStack.push(n),
                  (e.position = { start: c(n.start) }),
                  e
                );
              }
              function g(e) {
                return function (n) {
                  e && e.call(this, n), v.call(this, n);
                };
              }
              function v(e) {
                var n = this.stack.pop(),
                  t = this.tokenStack.pop();
                if (t) {
                  if (t.type !== e.type)
                    throw Error(
                      "Cannot close `" +
                        e.type +
                        "` (" +
                        p({ start: e.start, end: e.end }) +
                        "): a different token (`" +
                        t.type +
                        "`, " +
                        p({ start: t.start, end: t.end }) +
                        ") is open"
                    );
                } else
                  throw Error(
                    "Cannot close `" +
                      e.type +
                      "` (" +
                      p({ start: e.start, end: e.end }) +
                      "): it’s not open"
                  );
                return (n.position.end = c(e.end)), n;
              }
              function x() {
                return r(this.stack.pop());
              }
              function y(e) {
                var n = this.stack[this.stack.length - 1].children,
                  t = n[n.length - 1];
                (t && "text" === t.type) ||
                  (((t = { type: "text", value: "" }).position = {
                    start: c(e.start),
                  }),
                  this.stack[this.stack.length - 1].children.push(t)),
                  this.stack.push(t);
              }
              function k(e) {
                var n = this.stack.pop();
                (n.value += this.sliceSerialize(e)),
                  (n.position.end = c(e.end));
              }
              function b() {
                t.atHardBreak = !0;
              }
              function S(e) {
                t.characterReferenceType = e.type;
              }
              function w() {
                return { type: "code", lang: null, meta: null, value: "" };
              }
              function E() {
                return { type: "heading", depth: void 0, children: [] };
              }
              function C() {
                return { type: "break" };
              }
              function F() {
                return { type: "html", value: "" };
              }
              function P() {
                return { type: "link", title: null, url: "", children: [] };
              }
              function T(e) {
                return {
                  type: "list",
                  ordered: "listOrdered" === e.type,
                  start: null,
                  spread: e._spread,
                  children: [],
                };
              }
            })(t)(c(a(t).document().write(s()(e, n, !0))))
          );
        };
        var r = t(80582),
          i = t(52334),
          o = t(27954),
          l = t(36898),
          u = t(29605),
          a = t(33693),
          s = t(99268),
          c = t(89493),
          f = t(94661),
          p = t(95358);
      },
      11927: (e) => {
        e.exports = function (e) {
          return (
            null != e &&
            null != e.constructor &&
            "function" == typeof e.constructor.isBuffer &&
            e.constructor.isBuffer(e)
          );
        };
      },
      12721: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          var t = [],
            i = -1,
            o = e.length;
          for (n && t.push(r("text", "\n")); ++i < o; )
            i && t.push(r("text", "\n")), t.push(e[i]);
          return n && e.length > 0 && t.push(r("text", "\n")), t;
        };
        var r = t(69921);
      },
      13125: (e, n, t) => {
        "use strict";
        var r = t(77272),
          i = t(22552);
        e.exports = function (e, n, t, o, l, u) {
          var a,
            s = this,
            c = 0;
          return function (n) {
            return (
              e.enter(o), e.enter(l), e.consume(n), e.exit(l), e.enter(u), f
            );
          };
          function f(i) {
            return null === i ||
              91 === i ||
              (93 === i && !a) ||
              (94 === i &&
                !c &&
                "_hiddenFootnoteSupport" in s.parser.constructs) ||
              c > 999
              ? t(i)
              : 93 === i
              ? (e.exit(u), e.enter(l), e.consume(i), e.exit(l), e.exit(o), n)
              : r(i)
              ? (e.enter("lineEnding"), e.consume(i), e.exit("lineEnding"), f)
              : (e.enter("chunkString", { contentType: "string" }), p(i));
          }
          function p(n) {
            return null === n || 91 === n || 93 === n || r(n) || c++ > 999
              ? (e.exit("chunkString"), f(n))
              : (e.consume(n), (a = a || !i(n)), 92 === n ? d : p);
          }
          function d(n) {
            return 91 === n || 92 === n || 93 === n
              ? (e.consume(n), c++, p)
              : p(n);
          }
        };
      },
      13716: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          var t,
            i = n.value ? n.value + "\n" : "",
            o = n.lang && n.lang.match(/^[^ \t]+(?=[ \t]|$)/),
            l = {};
          return (
            o && (l.className = ["language-" + o]),
            (t = e(n, "code", l, [r("text", i)])),
            n.meta && (t.data = { meta: n.meta }),
            e(n.position, "pre", [t])
          );
        };
        var r = t(69921);
      },
      16525: (e, n, t) => {
        "use strict";
        var r = t(52334);
        e.exports = function (e) {
          return r({}, e);
        };
      },
      16651: (e, n, t) => {
        "use strict";
        function r() {
          return null;
        }
        e.exports = {
          blockquote: t(5154),
          break: t(19704),
          code: t(13716),
          delete: t(66250),
          emphasis: t(36903),
          footnoteReference: t(90641),
          footnote: t(49613),
          heading: t(70961),
          html: t(97832),
          imageReference: t(70158),
          image: t(77858),
          inlineCode: t(40470),
          linkReference: t(10101),
          link: t(25113),
          listItem: t(8979),
          list: t(93469),
          paragraph: t(72801),
          root: t(97833),
          strong: t(66230),
          table: t(72295),
          text: t(20182),
          thematicBreak: t(36256),
          toml: r,
          yaml: r,
          definition: r,
          footnoteDefinition: r,
        };
      },
      17319: (e) => {
        "use strict";
        e.exports = [
          "address",
          "article",
          "aside",
          "base",
          "basefont",
          "blockquote",
          "body",
          "caption",
          "center",
          "col",
          "colgroup",
          "dd",
          "details",
          "dialog",
          "dir",
          "div",
          "dl",
          "dt",
          "fieldset",
          "figcaption",
          "figure",
          "footer",
          "form",
          "frame",
          "frameset",
          "h1",
          "h2",
          "h3",
          "h4",
          "h5",
          "h6",
          "head",
          "header",
          "hr",
          "html",
          "iframe",
          "legend",
          "li",
          "link",
          "main",
          "menu",
          "menuitem",
          "nav",
          "noframes",
          "ol",
          "optgroup",
          "option",
          "p",
          "param",
          "section",
          "source",
          "summary",
          "table",
          "tbody",
          "td",
          "tfoot",
          "th",
          "thead",
          "title",
          "tr",
          "track",
          "ul",
        ];
      },
      18425: (e, n, t) => {
        "use strict";
        var r = t(24547);
        (e.exports = o), (o.wrap = r);
        var i = [].slice;
        function o() {
          var e = [],
            n = {};
          return (
            (n.run = function () {
              var n = -1,
                t = i.call(arguments, 0, -1),
                o = arguments[arguments.length - 1];
              if ("function" != typeof o)
                throw Error("Expected function as last argument, not " + o);
              function l(u) {
                var a = e[++n],
                  s = i.call(arguments, 0),
                  c = s.slice(1),
                  f = t.length,
                  p = -1;
                if (u) return void o(u);
                for (; ++p < f; )
                  (null === c[p] || void 0 === c[p]) && (c[p] = t[p]);
                (t = c),
                  a ? r(a, l).apply(null, t) : o.apply(null, [null].concat(t));
              }
              l.apply(null, [null].concat(t));
            }),
            (n.use = function (t) {
              if ("function" != typeof t)
                throw Error("Expected `fn` to be a function, not " + t);
              return e.push(t), n;
            }),
            n
          );
        }
      },
      19704: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          return [e(n, "br"), r("text", "\n")];
        };
        var r = t(69921);
      },
      19852: (e) => {
        "use strict";
        e.exports = String.fromCharCode;
      },
      19947: (e, n, t) => {
        "use strict";
        var r = t(46665),
          i = t(6694);
        e.exports = r([t(85999), i, t(98920), t(42419), t(4235)]);
      },
      20182: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          return e.augment(
            n,
            r("text", String(n.value).replace(/[ \t]*(\r?\n|\r)[ \t]*/g, "$1"))
          );
        };
        var r = t(69921);
      },
      20187: (e) => {
        "use strict";
        e.exports = function (e, n, t) {
          for (var r, i = [], o = -1; ++o < e.length; )
            (r = e[o].resolveAll) &&
              0 > i.indexOf(r) &&
              ((n = r(n, t)), i.push(r));
          return n;
        };
      },
      20979: (e, n, t) => {
        "use strict";
        var r = t(27797),
          i = t(57301),
          o = t(77272);
        e.exports = function (e, n, t, l, u, a, s, c, f) {
          var p = f || 1 / 0,
            d = 0;
          return function (n) {
            return 60 === n
              ? (e.enter(l), e.enter(u), e.enter(a), e.consume(n), e.exit(a), h)
              : r(n) || 41 === n
              ? t(n)
              : (e.enter(l),
                e.enter(s),
                e.enter(c),
                e.enter("chunkString", { contentType: "string" }),
                v(n));
          };
          function h(t) {
            return 62 === t
              ? (e.enter(a), e.consume(t), e.exit(a), e.exit(u), e.exit(l), n)
              : (e.enter(c),
                e.enter("chunkString", { contentType: "string" }),
                m(t));
          }
          function m(n) {
            return 62 === n
              ? (e.exit("chunkString"), e.exit(c), h(n))
              : null === n || 60 === n || o(n)
              ? t(n)
              : (e.consume(n), 92 === n ? g : m);
          }
          function g(n) {
            return 60 === n || 62 === n || 92 === n ? (e.consume(n), m) : m(n);
          }
          function v(o) {
            return 40 === o
              ? ++d > p
                ? t(o)
                : (e.consume(o), v)
              : 41 === o
              ? d--
                ? (e.consume(o), v)
                : (e.exit("chunkString"), e.exit(c), e.exit(s), e.exit(l), n(o))
              : null === o || i(o)
              ? d
                ? t(o)
                : (e.exit("chunkString"), e.exit(c), e.exit(s), e.exit(l), n(o))
              : r(o)
              ? t(o)
              : (e.consume(o), 92 === o ? x : v);
          }
          function x(n) {
            return 40 === n || 41 === n || 92 === n ? (e.consume(n), v) : v(n);
          }
        };
      },
      22016: (e) => {
        "use strict";
        e.exports = t;
        var n = t.prototype;
        function t(e, n, t) {
          (this.property = e), (this.normal = n), t && (this.space = t);
        }
        (n.space = null), (n.normal = {}), (n.property = {});
      },
      22176: (e, n, t) => {
        "use strict";
        var r = t(19852);
        e.exports = function (e) {
          for (var n, t, i, o = -1, l = []; ++o < e.length; ) {
            if ("string" == typeof (n = e[o])) t = n;
            else if (-5 === n) t = "\r";
            else if (-4 === n) t = "\n";
            else if (-3 === n) t = "\r\n";
            else if (-2 === n) t = "	";
            else if (-1 === n) {
              if (i) continue;
              t = " ";
            } else t = r(n);
            (i = -2 === n), l.push(t);
          }
          return l.join("");
        };
      },
      22552: (e) => {
        "use strict";
        e.exports = function (e) {
          return -2 === e || -1 === e || 32 === e;
        };
      },
      24152: (e) => {
        "use strict";
        e.exports = function (e, n) {
          var t,
            r = n.start._index,
            i = n.start._bufferIndex,
            o = n.end._index,
            l = n.end._bufferIndex;
          return (
            r === o
              ? (t = [e[r].slice(i, l)])
              : ((t = e.slice(r, o)),
                i > -1 && (t[0] = t[0].slice(i)),
                l > 0 && t.push(e[o].slice(0, l))),
            t
          );
        };
      },
      24208: (e, n, t) => {
        "use strict";
        Object.defineProperty(n, "__esModule", { value: !0 });
        var r = t(93794),
          i = t(47306),
          o = t(83435),
          l = t(73460),
          u = t(92629),
          a = t(25095),
          s = t(60291),
          c = t(42439),
          f = t(74503),
          p = t(94397),
          d = t(43689),
          h = t(87604),
          m = t(36940),
          g = t(99399),
          v = t(49798),
          x = t(42767),
          y = t(50986),
          k = t(91534),
          b = t(26992),
          S = t(53186),
          w = t(28149),
          E = { null: [i, r.resolver] };
        (n.contentInitial = { 91: p }),
          (n.disable = { null: [] }),
          (n.document = {
            42: b,
            43: b,
            45: b,
            48: b,
            49: b,
            50: b,
            51: b,
            52: b,
            53: b,
            54: b,
            55: b,
            56: b,
            57: b,
            62: l,
          }),
          (n.flow = {
            35: h,
            42: w,
            45: [S, w],
            60: m,
            61: S,
            95: w,
            96: s,
            126: s,
          }),
          (n.flowInitial = { "-2": c, "-1": c, 32: c }),
          (n.insideSpan = E),
          (n.string = { 38: a, 92: u }),
          (n.text = {
            "-5": k,
            "-4": k,
            "-3": k,
            33: x,
            38: a,
            42: i,
            60: [o, g],
            91: y,
            92: [d, u],
            93: v,
            95: i,
            96: f,
          });
      },
      24547: (e) => {
        "use strict";
        var n = [].slice;
        e.exports = function (e, t) {
          var r;
          return function () {
            var t,
              l = n.call(arguments, 0),
              u = e.length > l.length;
            u && l.push(i);
            try {
              t = e.apply(null, l);
            } catch (e) {
              if (u && r) throw e;
              return i(e);
            }
            u ||
              (t && "function" == typeof t.then
                ? t.then(o, i)
                : t instanceof Error
                ? i(t)
                : o(t));
          };
          function i() {
            r || ((r = !0), t.apply(null, arguments));
          }
          function o(e) {
            i(null, e);
          }
        };
      },
      24969: (e, n, t) => {
        "use strict";
        var r = t(22552);
        e.exports = function (e, n, t, i) {
          var o = i ? i - 1 : 1 / 0,
            l = 0;
          return function (i) {
            return r(i)
              ? (e.enter(t),
                (function i(u) {
                  return r(u) && l++ < o
                    ? (e.consume(u), i)
                    : (e.exit(t), n(u));
                })(i))
              : n(i);
          };
        };
      },
      25095: (e, n, t) => {
        "use strict";
        var r = t(94661),
          i = t(85683),
          o = t(84029),
          l = t(44813),
          u = r && "object" == typeof r && "default" in r ? r : { default: r };
        e.exports = {
          name: "characterReference",
          tokenize: function (e, n, t) {
            var r,
              a,
              s = this,
              c = 0;
            return function (n) {
              return (
                e.enter("characterReference"),
                e.enter("characterReferenceMarker"),
                e.consume(n),
                e.exit("characterReferenceMarker"),
                f
              );
            };
            function f(n) {
              return 35 === n
                ? (e.enter("characterReferenceMarkerNumeric"),
                  e.consume(n),
                  e.exit("characterReferenceMarkerNumeric"),
                  p)
                : (e.enter("characterReferenceValue"), (r = 31), (a = i), d(n));
            }
            function p(n) {
              return 88 === n || 120 === n
                ? (e.enter("characterReferenceMarkerHexadecimal"),
                  e.consume(n),
                  e.exit("characterReferenceMarkerHexadecimal"),
                  e.enter("characterReferenceValue"),
                  (r = 6),
                  (a = l),
                  d)
                : (e.enter("characterReferenceValue"), (r = 7), (a = o), d(n));
            }
            function d(o) {
              var l;
              return 59 === o && c
                ? ((l = e.exit("characterReferenceValue")),
                  a !== i || u.default(s.sliceSerialize(l)))
                  ? (e.enter("characterReferenceMarker"),
                    e.consume(o),
                    e.exit("characterReferenceMarker"),
                    e.exit("characterReference"),
                    n)
                  : t(o)
                : a(o) && c++ < r
                ? (e.consume(o), d)
                : t(o);
            }
          },
        };
      },
      25113: (e, n, t) => {
        "use strict";
        var r = t(37910),
          i = t(73684);
        e.exports = function (e, n) {
          var t = { href: r(n.url) };
          return (
            null !== n.title && void 0 !== n.title && (t.title = n.title),
            e(n, "a", t, i(e, n))
          );
        };
      },
      25468: (e, n) => {
        "use strict";
        n.cwd = function () {
          return "/";
        };
      },
      25842: (e, n, t) => {
        "use strict";
        e.exports = u;
        var r = t(76818),
          i = r.CONTINUE,
          o = r.SKIP,
          l = r.EXIT;
        function u(e, n, t, i) {
          "function" == typeof n &&
            "function" != typeof t &&
            ((i = t), (t = n), (n = null)),
            r(
              e,
              n,
              function (e, n) {
                var r = n[n.length - 1],
                  i = r ? r.children.indexOf(e) : null;
                return t(e, i, r);
              },
              i
            );
        }
        (u.CONTINUE = i), (u.SKIP = o), (u.EXIT = l);
      },
      26992: (e, n, t) => {
        "use strict";
        var r = t(84029),
          i = t(22552),
          o = t(96143),
          l = t(89779),
          u = t(24969),
          a = t(48335),
          s = t(28149),
          c = {
            name: "list",
            tokenize: function (e, n, t) {
              var u = this,
                c = o(u.events, "linePrefix"),
                p = 0;
              return function (n) {
                var i =
                  u.containerState.type ||
                  (42 === n || 43 === n || 45 === n
                    ? "listUnordered"
                    : "listOrdered");
                if (
                  "listUnordered" === i
                    ? !u.containerState.marker || n === u.containerState.marker
                    : r(n)
                ) {
                  if (
                    (u.containerState.type ||
                      ((u.containerState.type = i),
                      e.enter(i, { _container: !0 })),
                    "listUnordered" === i)
                  )
                    return (
                      e.enter("listItemPrefix"),
                      42 === n || 45 === n ? e.check(s, t, d)(n) : d(n)
                    );
                  if (!u.interrupt || 49 === n)
                    return (
                      e.enter("listItemPrefix"),
                      e.enter("listItemValue"),
                      (function n(i) {
                        return r(i) && ++p < 10
                          ? (e.consume(i), n)
                          : (!u.interrupt || p < 2) &&
                            (u.containerState.marker
                              ? i === u.containerState.marker
                              : 41 === i || 46 === i)
                          ? (e.exit("listItemValue"), d(i))
                          : t(i);
                      })(n)
                    );
                }
                return t(n);
              };
              function d(n) {
                return (
                  e.enter("listItemMarker"),
                  e.consume(n),
                  e.exit("listItemMarker"),
                  (u.containerState.marker = u.containerState.marker || n),
                  e.check(a, u.interrupt ? t : h, e.attempt(f, g, m))
                );
              }
              function h(e) {
                return (u.containerState.initialBlankLine = !0), c++, g(e);
              }
              function m(n) {
                return i(n)
                  ? (e.enter("listItemPrefixWhitespace"),
                    e.consume(n),
                    e.exit("listItemPrefixWhitespace"),
                    g)
                  : t(n);
              }
              function g(t) {
                return (
                  (u.containerState.size =
                    c + l(u.sliceStream(e.exit("listItemPrefix")))),
                  n(t)
                );
              }
            },
            continuation: {
              tokenize: function (e, n, t) {
                var r = this;
                return (
                  (r.containerState._closeFlow = void 0),
                  e.check(
                    a,
                    function (t) {
                      return (
                        (r.containerState.furtherBlankLines =
                          r.containerState.furtherBlankLines ||
                          r.containerState.initialBlankLine),
                        u(e, n, "listItemIndent", r.containerState.size + 1)(t)
                      );
                    },
                    function (t) {
                      return r.containerState.furtherBlankLines || !i(t)
                        ? ((r.containerState.furtherBlankLines =
                            r.containerState.initialBlankLine =
                              void 0),
                          o(t))
                        : ((r.containerState.furtherBlankLines =
                            r.containerState.initialBlankLine =
                              void 0),
                          e.attempt(p, n, o)(t));
                    }
                  )
                );
                function o(i) {
                  return (
                    (r.containerState._closeFlow = !0),
                    (r.interrupt = void 0),
                    u(
                      e,
                      e.attempt(c, n, t),
                      "linePrefix",
                      r.parser.constructs.disable.null.indexOf("codeIndented") >
                        -1
                        ? void 0
                        : 4
                    )(i)
                  );
                }
              },
            },
            exit: function (e) {
              e.exit(this.containerState.type);
            },
          },
          f = {
            tokenize: function (e, n, t) {
              var r = this;
              return u(
                e,
                function (e) {
                  return i(e) || !o(r.events, "listItemPrefixWhitespace")
                    ? t(e)
                    : n(e);
                },
                "listItemPrefixWhitespace",
                r.parser.constructs.disable.null.indexOf("codeIndented") > -1
                  ? void 0
                  : 5
              );
            },
            partial: !0,
          },
          p = {
            tokenize: function (e, n, t) {
              var r = this;
              return u(
                e,
                function (e) {
                  return o(r.events, "listItemIndent") === r.containerState.size
                    ? n(e)
                    : t(e);
                },
                "listItemIndent",
                r.containerState.size + 1
              );
            },
            partial: !0,
          };
        e.exports = c;
      },
      27371: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          var t,
            o,
            l,
            u = n.referenceType,
            a = "]";
          return ("collapsed" === u
            ? (a += "[]")
            : "full" === u && (a += "[" + (n.label || n.identifier) + "]"),
          "imageReference" === n.type)
            ? r("text", "![" + n.alt + a)
            : ((o = (t = i(e, n))[0]) && "text" === o.type
                ? (o.value = "[" + o.value)
                : t.unshift(r("text", "[")),
              (l = t[t.length - 1]) && "text" === l.type
                ? (l.value += a)
                : t.push(r("text", a)),
              t);
        };
        var r = t(69921),
          i = t(73684);
      },
      27797: (e) => {
        "use strict";
        e.exports = function (e) {
          return e < 32 || 127 === e;
        };
      },
      27954: (e) => {
        "use strict";
        e.exports = {}.hasOwnProperty;
      },
      28149: (e, n, t) => {
        "use strict";
        var r = t(77272),
          i = t(22552),
          o = t(24969);
        e.exports = {
          name: "thematicBreak",
          tokenize: function (e, n, t) {
            var l,
              u = 0;
            return function (a) {
              return (
                e.enter("thematicBreak"),
                (l = a),
                (function a(s) {
                  return s === l
                    ? (e.enter("thematicBreakSequence"),
                      (function n(t) {
                        return t === l
                          ? (e.consume(t), u++, n)
                          : (e.exit("thematicBreakSequence"), a(t));
                      })(s))
                    : i(s)
                    ? o(e, a, "whitespace")(s)
                    : u < 3 || (null !== s && !r(s))
                    ? t(s)
                    : (e.exit("thematicBreak"), n(s));
                })(a)
              );
            };
          },
        };
      },
      28215: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          var t = (function (e, n) {
              var t = n || {};
              void 0 === t.allowDangerousHTML ||
                p ||
                ((p = !0),
                console.warn(
                  "mdast-util-to-hast: deprecation: `allowDangerousHTML` is nonstandard, use `allowDangerousHtml` instead"
                ));
              var r = t.allowDangerousHtml || t.allowDangerousHTML,
                a = {};
              return (
                (d.dangerous = r),
                (d.definition = u(e)),
                (d.footnoteById = a),
                (d.footnoteOrder = []),
                (d.augment = s),
                (d.handlers = Object.assign({}, c, t.handlers)),
                (d.unknownHandler = t.unknownHandler),
                (d.passThrough = t.passThrough),
                i(e, "footnoteDefinition", function (e) {
                  var n = String(e.identifier).toUpperCase();
                  f.call(a, n) || (a[n] = e);
                }),
                d
              );
              function s(e, n) {
                var t, r;
                return (
                  e &&
                    e.data &&
                    ((t = e.data).hName &&
                      ("element" !== n.type &&
                        (n = {
                          type: "element",
                          tagName: "",
                          properties: {},
                          children: [],
                        }),
                      (n.tagName = t.hName)),
                    "element" === n.type &&
                      t.hProperties &&
                      (n.properties = Object.assign(
                        {},
                        n.properties,
                        t.hProperties
                      )),
                    n.children && t.hChildren && (n.children = t.hChildren)),
                  l((r = e && e.position ? e : { position: e })) ||
                    (n.position = { start: o.start(r), end: o.end(r) }),
                  n
                );
              }
              function d(e, n, t, r) {
                return (
                  null == r &&
                    "object" == typeof t &&
                    "length" in t &&
                    ((r = t), (t = {})),
                  s(e, {
                    type: "element",
                    tagName: n,
                    properties: t || {},
                    children: r || [],
                  })
                );
              }
            })(e, n),
            d = a(t, e),
            h = s(t);
          return h && (d.children = d.children.concat(r("text", "\n"), h)), d;
        };
        var r = t(69921),
          i = t(25842),
          o = t(42370),
          l = t(36456),
          u = t(6013),
          a = t(6495),
          s = t(87102),
          c = t(16651),
          f = {}.hasOwnProperty,
          p = !1;
      },
      28305: (e, n, t) => {
        "use strict";
        e.exports = t(57453);
      },
      28392: (e) => {
        "use strict";
        var n = Object.prototype.hasOwnProperty,
          t = Object.prototype.toString,
          r = Object.defineProperty,
          i = Object.getOwnPropertyDescriptor,
          o = function (e) {
            return "function" == typeof Array.isArray
              ? Array.isArray(e)
              : "[object Array]" === t.call(e);
          },
          l = function (e) {
            if (!e || "[object Object]" !== t.call(e)) return !1;
            var r,
              i = n.call(e, "constructor"),
              o =
                e.constructor &&
                e.constructor.prototype &&
                n.call(e.constructor.prototype, "isPrototypeOf");
            if (e.constructor && !i && !o) return !1;
            for (r in e);
            return void 0 === r || n.call(e, r);
          },
          u = function (e, n) {
            r && "__proto__" === n.name
              ? r(e, n.name, {
                  enumerable: !0,
                  configurable: !0,
                  value: n.newValue,
                  writable: !0,
                })
              : (e[n.name] = n.newValue);
          },
          a = function (e, t) {
            if ("__proto__" === t) {
              if (!n.call(e, t)) return;
              else if (i) return i(e, t).value;
            }
            return e[t];
          };
        e.exports = function e() {
          var n,
            t,
            r,
            i,
            s,
            c,
            f = arguments[0],
            p = 1,
            d = arguments.length,
            h = !1;
          for (
            "boolean" == typeof f &&
              ((h = f), (f = arguments[1] || {}), (p = 2)),
              (null == f || ("object" != typeof f && "function" != typeof f)) &&
                (f = {});
            p < d;
            ++p
          )
            if (((n = arguments[p]), null != n))
              for (t in n)
                (r = a(f, t)),
                  f !== (i = a(n, t)) &&
                    (h && i && (l(i) || (s = o(i)))
                      ? (s
                          ? ((s = !1), (c = r && o(r) ? r : []))
                          : (c = r && l(r) ? r : {}),
                        u(f, { name: t, newValue: e(h, c, i) }))
                      : void 0 !== i && u(f, { name: t, newValue: i }));
          return f;
        };
      },
      29605: (e, n, t) => {
        "use strict";
        var r = t(19852);
        e.exports = function (e, n) {
          var t = parseInt(e, n);
          return t < 9 ||
            11 === t ||
            (t > 13 && t < 32) ||
            (t > 126 && t < 160) ||
            (t > 55295 && t < 57344) ||
            (t > 64975 && t < 65008) ||
            (65535 & t) == 65535 ||
            (65535 & t) == 65534 ||
            t > 1114111
            ? "�"
            : r(t);
        };
      },
      33693: (e, n, t) => {
        "use strict";
        var r = t(72674),
          i = t(71372),
          o = t(53253),
          l = t(93794),
          u = t(69397),
          a = t(95751),
          s = t(148),
          c = t(24208);
        e.exports = function (e) {
          var n = {
            defined: [],
            constructs: u([c].concat(s((e || {}).extensions))),
            content: t(r),
            document: t(i),
            flow: t(o),
            string: t(l.string),
            text: t(l.text),
          };
          return n;
          function t(e) {
            return function (t) {
              return a(n, e, t);
            };
          }
        };
      },
      36256: (e) => {
        "use strict";
        e.exports = function (e, n) {
          return e(n, "hr");
        };
      },
      36456: (e) => {
        "use strict";
        e.exports = function (e) {
          return (
            !e ||
            !e.position ||
            !e.position.start ||
            !e.position.start.line ||
            !e.position.start.column ||
            !e.position.end ||
            !e.position.end.line ||
            !e.position.end.column
          );
        };
      },
      36898: (e) => {
        "use strict";
        e.exports = function (e) {
          return e
            .replace(/[\t\n\r ]+/g, " ")
            .replace(/^ | $/g, "")
            .toLowerCase()
            .toUpperCase();
        };
      },
      36903: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          return e(n, "em", r(e, n));
        };
        var r = t(73684);
      },
      36940: (e, n, t) => {
        "use strict";
        var r = t(77144),
          i = t(85683),
          o = t(77272),
          l = t(57301),
          u = t(22552),
          a = t(19852),
          s = t(17319),
          c = t(50092),
          f = t(48335),
          p = {
            tokenize: function (e, n, t) {
              return function (r) {
                return (
                  e.exit("htmlFlowData"),
                  e.enter("lineEndingBlank"),
                  e.consume(r),
                  e.exit("lineEndingBlank"),
                  e.attempt(f, n, t)
                );
              };
            },
            partial: !0,
          };
        e.exports = {
          name: "htmlFlow",
          tokenize: function (e, n, t) {
            var f,
              d,
              h,
              m,
              g,
              v = this;
            return function (n) {
              return (
                e.enter("htmlFlow"), e.enter("htmlFlowData"), e.consume(n), x
              );
            };
            function x(i) {
              return 33 === i
                ? (e.consume(i), y)
                : 47 === i
                ? (e.consume(i), S)
                : 63 === i
                ? (e.consume(i), (f = 3), v.interrupt ? n : j)
                : r(i)
                ? (e.consume(i), (h = a(i)), (d = !0), w)
                : t(i);
            }
            function y(i) {
              return 45 === i
                ? (e.consume(i), (f = 2), k)
                : 91 === i
                ? (e.consume(i), (f = 5), (h = "CDATA["), (m = 0), b)
                : r(i)
                ? (e.consume(i), (f = 4), v.interrupt ? n : j)
                : t(i);
            }
            function k(r) {
              return 45 === r ? (e.consume(r), v.interrupt ? n : j) : t(r);
            }
            function b(r) {
              return r === h.charCodeAt(m++)
                ? (e.consume(r), m === h.length ? (v.interrupt ? n : M) : b)
                : t(r);
            }
            function S(n) {
              return r(n) ? (e.consume(n), (h = a(n)), w) : t(n);
            }
            function w(r) {
              if (null === r || 47 === r || 62 === r || l(r))
                return 47 !== r && d && c.indexOf(h.toLowerCase()) > -1
                  ? ((f = 1), v.interrupt ? n(r) : M(r))
                  : s.indexOf(h.toLowerCase()) > -1
                  ? ((f = 6), 47 === r)
                    ? (e.consume(r), E)
                    : v.interrupt
                    ? n(r)
                    : M(r)
                  : ((f = 7),
                    v.interrupt
                      ? t(r)
                      : d
                      ? C(r)
                      : (function n(t) {
                          return u(t) ? (e.consume(t), n) : D(t);
                        })(r));
              return 45 === r || i(r) ? (e.consume(r), (h += a(r)), w) : t(r);
            }
            function E(r) {
              return 62 === r ? (e.consume(r), v.interrupt ? n : M) : t(r);
            }
            function C(n) {
              return 47 === n
                ? (e.consume(n), D)
                : 58 === n || 95 === n || r(n)
                ? (e.consume(n), F)
                : u(n)
                ? (e.consume(n), C)
                : D(n);
            }
            function F(n) {
              return 45 === n || 46 === n || 58 === n || 95 === n || i(n)
                ? (e.consume(n), F)
                : P(n);
            }
            function P(n) {
              return 61 === n
                ? (e.consume(n), T)
                : u(n)
                ? (e.consume(n), P)
                : C(n);
            }
            function T(n) {
              return null === n || 60 === n || 61 === n || 62 === n || 96 === n
                ? t(n)
                : 34 === n || 39 === n
                ? (e.consume(n), (g = n), A)
                : u(n)
                ? (e.consume(n), T)
                : ((g = void 0),
                  (function n(t) {
                    return null === t ||
                      34 === t ||
                      39 === t ||
                      60 === t ||
                      61 === t ||
                      62 === t ||
                      96 === t ||
                      l(t)
                      ? P(t)
                      : (e.consume(t), n);
                  })(n));
            }
            function A(n) {
              return n === g
                ? (e.consume(n), O)
                : null === n || o(n)
                ? t(n)
                : (e.consume(n), A);
            }
            function O(e) {
              return 47 === e || 62 === e || u(e) ? C(e) : t(e);
            }
            function D(n) {
              return 62 === n ? (e.consume(n), I) : t(n);
            }
            function I(n) {
              return u(n)
                ? (e.consume(n), I)
                : null === n || o(n)
                ? M(n)
                : t(n);
            }
            function M(n) {
              return 45 === n && 2 === f
                ? (e.consume(n), z)
                : 60 === n && 1 === f
                ? (e.consume(n), _)
                : 62 === n && 4 === f
                ? (e.consume(n), H)
                : 63 === n && 3 === f
                ? (e.consume(n), j)
                : 93 === n && 5 === f
                ? (e.consume(n), R)
                : o(n) && (6 === f || 7 === f)
                ? e.check(p, H, L)(n)
                : null === n || o(n)
                ? L(n)
                : (e.consume(n), M);
            }
            function L(n) {
              return (
                e.exit("htmlFlowData"),
                (function n(t) {
                  return null === t
                    ? U(t)
                    : o(t)
                    ? (e.enter("lineEnding"),
                      e.consume(t),
                      e.exit("lineEnding"),
                      n)
                    : (e.enter("htmlFlowData"), M(t));
                })(n)
              );
            }
            function z(n) {
              return 45 === n ? (e.consume(n), j) : M(n);
            }
            function _(n) {
              return 47 === n ? (e.consume(n), (h = ""), B) : M(n);
            }
            function B(n) {
              return 62 === n && c.indexOf(h.toLowerCase()) > -1
                ? (e.consume(n), H)
                : r(n) && h.length < 8
                ? (e.consume(n), (h += a(n)), B)
                : M(n);
            }
            function R(n) {
              return 93 === n ? (e.consume(n), j) : M(n);
            }
            function j(n) {
              return 62 === n ? (e.consume(n), H) : M(n);
            }
            function H(n) {
              return null === n || o(n)
                ? (e.exit("htmlFlowData"), U(n))
                : (e.consume(n), H);
            }
            function U(t) {
              return e.exit("htmlFlow"), n(t);
            }
          },
          resolveTo: function (e) {
            for (
              var n = e.length;
              n-- && ("enter" !== e[n][0] || "htmlFlow" !== e[n][1].type);

            );
            return (
              n > 1 &&
                "linePrefix" === e[n - 2][1].type &&
                ((e[n][1].start = e[n - 2][1].start),
                (e[n + 1][1].start = e[n - 2][1].start),
                e.splice(n - 2, 2)),
              e
            );
          },
          concrete: !0,
        };
      },
      37910: (e) => {
        "use strict";
        var n = {};
        function t(e, r, i) {
          var o,
            l,
            u,
            a,
            s,
            c = "";
          for (
            "string" != typeof r && ((i = r), (r = t.defaultChars)),
              void 0 === i && (i = !0),
              s = (function (e) {
                var t,
                  r,
                  i = n[e];
                if (i) return i;
                for (t = 0, i = n[e] = []; t < 128; t++)
                  (r = String.fromCharCode(t)),
                    /^[0-9a-z]$/i.test(r)
                      ? i.push(r)
                      : i.push(
                          "%" + ("0" + t.toString(16).toUpperCase()).slice(-2)
                        );
                for (t = 0; t < e.length; t++) i[e.charCodeAt(t)] = e[t];
                return i;
              })(r),
              o = 0,
              l = e.length;
            o < l;
            o++
          ) {
            if (
              ((u = e.charCodeAt(o)),
              i &&
                37 === u &&
                o + 2 < l &&
                /^[0-9a-f]{2}$/i.test(e.slice(o + 1, o + 3)))
            ) {
              (c += e.slice(o, o + 3)), (o += 2);
              continue;
            }
            if (u < 128) {
              c += s[u];
              continue;
            }
            if (u >= 55296 && u <= 57343) {
              if (
                u >= 55296 &&
                u <= 56319 &&
                o + 1 < l &&
                (a = e.charCodeAt(o + 1)) >= 56320 &&
                a <= 57343
              ) {
                (c += encodeURIComponent(e[o] + e[o + 1])), o++;
                continue;
              }
              c += "%EF%BF%BD";
              continue;
            }
            c += encodeURIComponent(e[o]);
          }
          return c;
        }
        (t.defaultChars = ";/?:@&=+$,-_.!~*'()#"),
          (t.componentChars = "-_.!~*'()"),
          (e.exports = t);
      },
      39029: (e, n, t) => {
        "use strict";
        var r = t(77272),
          i = t(24969);
        e.exports = function (e, n, t, o, l, u) {
          var a;
          return function (n) {
            return (
              e.enter(o),
              e.enter(l),
              e.consume(n),
              e.exit(l),
              (a = 40 === n ? 41 : n),
              s
            );
          };
          function s(t) {
            return t === a
              ? (e.enter(l), e.consume(t), e.exit(l), e.exit(o), n)
              : (e.enter(u), c(t));
          }
          function c(n) {
            return n === a
              ? (e.exit(u), s(a))
              : null === n
              ? t(n)
              : r(n)
              ? (e.enter("lineEnding"),
                e.consume(n),
                e.exit("lineEnding"),
                i(e, c, "linePrefix"))
              : (e.enter("chunkString", { contentType: "string" }), f(n));
          }
          function f(n) {
            return n === a || null === n || r(n)
              ? (e.exit("chunkString"), c(n))
              : (e.consume(n), 92 === n ? p : f);
          }
          function p(n) {
            return n === a || 92 === n ? (e.consume(n), f) : f(n);
          }
        };
      },
      39115: (e, n, t) => {
        "use strict";
        e.exports = t(28215);
      },
      39427: (e, n, t) => {
        "use strict";
        var r = t(19852);
        e.exports = function (e) {
          return function (n) {
            return e.test(r(n));
          };
        };
      },
      40148: (e, n, t) => {
        "use strict";
        var r = t(57983);
        e.exports = function (e, n, t, i) {
          var o,
            l = e.length,
            u = 0;
          if (
            ((n = n < 0 ? (-n > l ? 0 : l + n) : n > l ? l : n),
            (t = t > 0 ? t : 0),
            i.length < 1e4)
          )
            (o = Array.from(i)).unshift(n, t), r.apply(e, o);
          else
            for (t && r.apply(e, [n, t]); u < i.length; )
              (o = i.slice(u, u + 1e4)).unshift(n, 0),
                r.apply(e, o),
                (u += 1e4),
                (n += 1e4);
        };
      },
      40285: (e) => {
        e.exports = function (e) {
          return (
            null != e &&
            null != e.constructor &&
            "function" == typeof e.constructor.isBuffer &&
            e.constructor.isBuffer(e)
          );
        };
      },
      40470: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          var t = n.value.replace(/\r?\n|\r/g, " ");
          return e(n, "code", [r("text", t)]);
        };
        var r = t(69921);
      },
      41588: (e, n, t) => {
        "use strict";
        var r = t(98360),
          i = t(11927),
          o = t(28392),
          l = t(3389),
          u = t(18425),
          a = t(95318);
        e.exports = (function e() {
          var n,
            t = [],
            i = u(),
            x = {},
            y = -1;
          return (
            (k.data = function (e, t) {
              return "string" == typeof e
                ? 2 == arguments.length
                  ? (m("data", n), (x[e] = t), k)
                  : (c.call(x, e) && x[e]) || null
                : e
                ? (m("data", n), (x = e), k)
                : x;
            }),
            (k.freeze = b),
            (k.attachers = t),
            (k.use = function (e) {
              var r;
              if ((m("use", n), null == e));
              else if ("function" == typeof e) a.apply(null, arguments);
              else if ("object" == typeof e) "length" in e ? u(e) : i(e);
              else throw Error("Expected usable value, not `" + e + "`");
              return r && (x.settings = o(x.settings || {}, r)), k;
              function i(e) {
                u(e.plugins), e.settings && (r = o(r || {}, e.settings));
              }
              function u(e) {
                var n = -1;
                if (null == e);
                else if ("object" == typeof e && "length" in e)
                  for (; ++n < e.length; ) {
                    var t = e[n];
                    if ("function" == typeof t) a(t);
                    else if ("object" == typeof t)
                      "length" in t ? a.apply(null, t) : i(t);
                    else throw Error("Expected usable value, not `" + t + "`");
                  }
                else throw Error("Expected a list of plugins, not `" + e + "`");
              }
              function a(e, n) {
                var r = (function (e) {
                  for (var n = -1; ++n < t.length; )
                    if (t[n][0] === e) return t[n];
                })(e);
                r
                  ? (l(r[1]) && l(n) && (n = o(!0, r[1], n)), (r[1] = n))
                  : t.push(s.call(arguments));
              }
            }),
            (k.parse = function (e) {
              var n,
                t = a(e);
              return (b(), d("parse", (n = k.Parser)), p(n, "parse"))
                ? new n(String(t), t).parse()
                : n(String(t), t);
            }),
            (k.stringify = function (e, n) {
              var t,
                r = a(n);
              return (b(),
              h("stringify", (t = k.Compiler)),
              g(e),
              p(t, "compile"))
                ? new t(e, r).compile()
                : t(e, r);
            }),
            (k.run = S),
            (k.runSync = function (e, n) {
              var t, i;
              return (
                S(e, n, function (e, n) {
                  (i = !0), (t = n), r(e);
                }),
                v("runSync", "run", i),
                t
              );
            }),
            (k.process = w),
            (k.processSync = function (e) {
              var n, t;
              return (
                b(),
                d("processSync", k.Parser),
                h("processSync", k.Compiler),
                w((n = a(e)), function (e) {
                  (t = !0), r(e);
                }),
                v("processSync", "process", t),
                n
              );
            }),
            k
          );
          function k() {
            for (var n = e(), r = -1; ++r < t.length; ) n.use.apply(null, t[r]);
            return n.data(o(!0, {}, x)), n;
          }
          function b() {
            var e, r;
            if (n) return k;
            for (; ++y < t.length; )
              !1 !== (e = t[y])[1] &&
                (!0 === e[1] && (e[1] = void 0),
                "function" == typeof (r = e[0].apply(k, e.slice(1))) &&
                  i.use(r));
            return (n = !0), (y = 1 / 0), k;
          }
          function S(e, n, t) {
            if (
              (g(e),
              b(),
              t || "function" != typeof n || ((t = n), (n = null)),
              !t)
            )
              return new Promise(r);
            function r(r, o) {
              i.run(e, a(n), function (n, i, l) {
                (i = i || e), n ? o(n) : r ? r(i) : t(null, i, l);
              });
            }
            r(null, t);
          }
          function w(e, n) {
            if ((b(), d("process", k.Parser), h("process", k.Compiler), !n))
              return new Promise(t);
            function t(t, r) {
              var i = a(e);
              f.run(k, { file: i }, function (e) {
                e ? r(e) : t ? t(i) : n(null, i);
              });
            }
            t(null, n);
          }
        })().freeze();
        var s = [].slice,
          c = {}.hasOwnProperty,
          f = u()
            .use(function (e, n) {
              n.tree = e.parse(n.file);
            })
            .use(function (e, n, t) {
              e.run(n.tree, n.file, function (e, r, i) {
                e ? t(e) : ((n.tree = r), (n.file = i), t());
              });
            })
            .use(function (e, n) {
              var t = e.stringify(n.tree, n.file);
              null == t ||
                ("string" == typeof t || i(t)
                  ? ("value" in n.file && (n.file.value = t),
                    (n.file.contents = t))
                  : (n.file.result = t));
            });
        function p(e, n) {
          return (
            "function" == typeof e &&
            e.prototype &&
            ((function (e) {
              var n;
              for (n in e) return !0;
              return !1;
            })(e.prototype) ||
              n in e.prototype)
          );
        }
        function d(e, n) {
          if ("function" != typeof n)
            throw Error("Cannot `" + e + "` without `Parser`");
        }
        function h(e, n) {
          if ("function" != typeof n)
            throw Error("Cannot `" + e + "` without `Compiler`");
        }
        function m(e, n) {
          if (n)
            throw Error(
              "Cannot invoke `" +
                e +
                "` on a frozen processor.\nCreate a new processor first, by invoking it: use `processor()` instead of `processor`."
            );
        }
        function g(e) {
          if (!e || "string" != typeof e.type)
            throw Error("Expected node, got `" + e + "`");
        }
        function v(e, n, t) {
          if (!t)
            throw Error("`" + e + "` finished async. Use `" + n + "` instead");
        }
      },
      42370: (e) => {
        "use strict";
        var n = i("start"),
          t = i("end");
        function r(e) {
          return { start: n(e), end: t(e) };
        }
        function i(e) {
          return (n.displayName = e), n;
          function n(n) {
            var t = (n && n.position && n.position[e]) || {};
            return {
              line: t.line || null,
              column: t.column || null,
              offset: isNaN(t.offset) ? null : t.offset,
            };
          }
        }
        (e.exports = r), (r.start = n), (r.end = t);
      },
      42419: (e, n, t) => {
        "use strict";
        var r = t(10124),
          i = t(46399),
          o = r.booleanish,
          l = r.number,
          u = r.spaceSeparated;
        e.exports = i({
          transform: function (e, n) {
            return "role" === n ? n : "aria-" + n.slice(4).toLowerCase();
          },
          properties: {
            ariaActiveDescendant: null,
            ariaAtomic: o,
            ariaAutoComplete: null,
            ariaBusy: o,
            ariaChecked: o,
            ariaColCount: l,
            ariaColIndex: l,
            ariaColSpan: l,
            ariaControls: u,
            ariaCurrent: null,
            ariaDescribedBy: u,
            ariaDetails: null,
            ariaDisabled: o,
            ariaDropEffect: u,
            ariaErrorMessage: null,
            ariaExpanded: o,
            ariaFlowTo: u,
            ariaGrabbed: o,
            ariaHasPopup: null,
            ariaHidden: o,
            ariaInvalid: null,
            ariaKeyShortcuts: null,
            ariaLabel: null,
            ariaLabelledBy: u,
            ariaLevel: l,
            ariaLive: null,
            ariaModal: o,
            ariaMultiLine: o,
            ariaMultiSelectable: o,
            ariaOrientation: null,
            ariaOwns: u,
            ariaPlaceholder: null,
            ariaPosInSet: l,
            ariaPressed: o,
            ariaReadOnly: o,
            ariaRelevant: null,
            ariaRequired: o,
            ariaRoleDescription: u,
            ariaRowCount: l,
            ariaRowIndex: l,
            ariaRowSpan: l,
            ariaSelected: o,
            ariaSetSize: l,
            ariaSort: null,
            ariaValueMax: l,
            ariaValueMin: l,
            ariaValueNow: l,
            ariaValueText: null,
            role: null,
          },
        });
      },
      42439: (e, n, t) => {
        "use strict";
        var r = t(77272),
          i = t(40148),
          o = t(96143),
          l = t(24969),
          u = {
            tokenize: function (e, n, t) {
              var i = this;
              return l(
                e,
                function u(a) {
                  return r(a)
                    ? (e.enter("lineEnding"),
                      e.consume(a),
                      e.exit("lineEnding"),
                      l(e, u, "linePrefix", 5))
                    : 4 > o(i.events, "linePrefix")
                    ? t(a)
                    : n(a);
                },
                "linePrefix",
                5
              );
            },
            partial: !0,
          };
        e.exports = {
          name: "codeIndented",
          tokenize: function (e, n, t) {
            return e.attempt(
              u,
              function t(i) {
                return null === i
                  ? n(i)
                  : r(i)
                  ? e.attempt(u, t, n)(i)
                  : (e.enter("codeFlowValue"),
                    (function n(i) {
                      return null === i || r(i)
                        ? (e.exit("codeFlowValue"), t(i))
                        : (e.consume(i), n);
                    })(i));
              },
              t
            );
          },
          resolve: function (e, n) {
            var t = {
              type: "codeIndented",
              start: e[0][1].start,
              end: e[e.length - 1][1].end,
            };
            return (
              i(e, 0, 0, [["enter", t, n]]),
              i(e, e.length, 0, [["exit", t, n]]),
              e
            );
          },
        };
      },
      42767: (e, n, t) => {
        "use strict";
        e.exports = {
          name: "labelStartImage",
          tokenize: function (e, n, t) {
            var r = this;
            return function (n) {
              return (
                e.enter("labelImage"),
                e.enter("labelImageMarker"),
                e.consume(n),
                e.exit("labelImageMarker"),
                i
              );
            };
            function i(n) {
              return 91 === n
                ? (e.enter("labelMarker"),
                  e.consume(n),
                  e.exit("labelMarker"),
                  e.exit("labelImage"),
                  o)
                : t(n);
            }
            function o(e) {
              return 94 === e && "_hiddenFootnoteSupport" in r.parser.constructs
                ? t(e)
                : n(e);
            }
          },
          resolveAll: t(49798).resolveAll,
        };
      },
      43689: (e, n, t) => {
        "use strict";
        var r = t(77272);
        e.exports = {
          name: "hardBreakEscape",
          tokenize: function (e, n, t) {
            return function (n) {
              return (
                e.enter("hardBreakEscape"),
                e.enter("escapeMarker"),
                e.consume(n),
                i
              );
            };
            function i(i) {
              return r(i)
                ? (e.exit("escapeMarker"), e.exit("hardBreakEscape"), n(i))
                : t(i);
            }
          },
        };
      },
      43935: (e) => {
        e.exports = function (e) {
          return e;
        };
      },
      44813: (e, n, t) => {
        "use strict";
        e.exports = t(39427)(/[\dA-Fa-f]/);
      },
      46399: (e, n, t) => {
        "use strict";
        var r = t(65857),
          i = t(22016),
          o = t(65079);
        e.exports = function (e) {
          var n,
            t,
            l = e.space,
            u = e.mustUseProperty || [],
            a = e.attributes || {},
            s = e.properties,
            c = e.transform,
            f = {},
            p = {};
          for (n in s)
            (t = new o(n, c(a, n), s[n], l)),
              -1 !== u.indexOf(n) && (t.mustUseProperty = !0),
              (f[n] = t),
              (p[r(n)] = n),
              (p[r(t.attribute)] = n);
          return new i(f, p, l);
        };
      },
      46665: (e, n, t) => {
        "use strict";
        var r = t(75031),
          i = t(22016);
        e.exports = function (e) {
          for (var n, t, o = e.length, l = [], u = [], a = -1; ++a < o; )
            (n = e[a]), l.push(n.property), u.push(n.normal), (t = n.space);
          return new i(r.apply(null, l), r.apply(null, u), t);
        };
      },
      47306: (e, n, t) => {
        "use strict";
        var r = t(65759),
          i = t(40148),
          o = t(70955),
          l = t(73349),
          u = t(20187),
          a = t(16525);
        e.exports = {
          name: "attention",
          tokenize: function (e, n) {
            var t,
              r = o(this.previous);
            return function (i) {
              return (
                e.enter("attentionSequence"),
                (t = i),
                (function i(l) {
                  var u, a, s, c;
                  return l === t
                    ? (e.consume(l), i)
                    : ((u = e.exit("attentionSequence")),
                      (s = !(a = o(l)) || (2 === a && r)),
                      (c = !r || (2 === r && a)),
                      (u._open = 42 === t ? s : s && (r || !c)),
                      (u._close = 42 === t ? c : c && (a || !s)),
                      n(l));
                })(i)
              );
            };
          },
          resolveAll: function (e, n) {
            for (var t, o, s, c, f, p, d, h, m = -1; ++m < e.length; )
              if (
                "enter" === e[m][0] &&
                "attentionSequence" === e[m][1].type &&
                e[m][1]._close
              ) {
                for (t = m; t--; )
                  if (
                    "exit" === e[t][0] &&
                    "attentionSequence" === e[t][1].type &&
                    e[t][1]._open &&
                    n.sliceSerialize(e[t][1]).charCodeAt(0) ===
                      n.sliceSerialize(e[m][1]).charCodeAt(0)
                  ) {
                    if (
                      (e[t][1]._close || e[m][1]._open) &&
                      (e[m][1].end.offset - e[m][1].start.offset) % 3 &&
                      !(
                        (e[t][1].end.offset -
                          e[t][1].start.offset +
                          e[m][1].end.offset -
                          e[m][1].start.offset) %
                        3
                      )
                    )
                      continue;
                    (c = {
                      type:
                        (p =
                          e[t][1].end.offset - e[t][1].start.offset > 1 &&
                          e[m][1].end.offset - e[m][1].start.offset > 1
                            ? 2
                            : 1) > 1
                          ? "strongSequence"
                          : "emphasisSequence",
                      start: l(a(e[t][1].end), -p),
                      end: a(e[t][1].end),
                    }),
                      (f = {
                        type: p > 1 ? "strongSequence" : "emphasisSequence",
                        start: a(e[m][1].start),
                        end: l(a(e[m][1].start), p),
                      }),
                      (s = {
                        type: p > 1 ? "strongText" : "emphasisText",
                        start: a(e[t][1].end),
                        end: a(e[m][1].start),
                      }),
                      (o = {
                        type: p > 1 ? "strong" : "emphasis",
                        start: a(c.start),
                        end: a(f.end),
                      }),
                      (e[t][1].end = a(c.start)),
                      (e[m][1].start = a(f.end)),
                      (d = []),
                      e[t][1].end.offset - e[t][1].start.offset &&
                        (d = r(d, [
                          ["enter", e[t][1], n],
                          ["exit", e[t][1], n],
                        ])),
                      (d = r(d, [
                        ["enter", o, n],
                        ["enter", c, n],
                        ["exit", c, n],
                        ["enter", s, n],
                      ])),
                      (d = r(
                        d,
                        u(
                          n.parser.constructs.insideSpan.null,
                          e.slice(t + 1, m),
                          n
                        )
                      )),
                      (d = r(d, [
                        ["exit", s, n],
                        ["enter", f, n],
                        ["exit", f, n],
                        ["exit", o, n],
                      ])),
                      e[m][1].end.offset - e[m][1].start.offset
                        ? ((h = 2),
                          (d = r(d, [
                            ["enter", e[m][1], n],
                            ["exit", e[m][1], n],
                          ])))
                        : (h = 0),
                      i(e, t - 1, m - t + 3, d),
                      (m = t + d.length - h - 2);
                    break;
                  }
              }
            for (m = -1; ++m < e.length; )
              "attentionSequence" === e[m][1].type && (e[m][1].type = "data");
            return e;
          },
        };
      },
      47383: (e) => {
        "use strict";
        e.exports = function (e, n) {
          return n in e ? e[n] : n;
        };
      },
      48335: (e, n, t) => {
        "use strict";
        var r = t(77272),
          i = t(24969);
        e.exports = {
          tokenize: function (e, n, t) {
            return i(
              e,
              function (e) {
                return null === e || r(e) ? n(e) : t(e);
              },
              "linePrefix"
            );
          },
          partial: !0,
        };
      },
      49105: (e, n, t) => {
        "use strict";
        var r = t(65857),
          i = t(65079),
          o = t(91815),
          l = "data";
        e.exports = function (e, n) {
          var t,
            p,
            d,
            h = r(n),
            m = n,
            g = o;
          return h in e.normal
            ? e.property[e.normal[h]]
            : (h.length > 4 &&
                h.slice(0, 4) === l &&
                u.test(n) &&
                ("-" === n.charAt(4)
                  ? (m =
                      l +
                      (t = n.slice(5).replace(a, f)).charAt(0).toUpperCase() +
                      t.slice(1))
                  : ((d = (p = n).slice(4)),
                    (n = a.test(d)
                      ? p
                      : ("-" !== (d = d.replace(s, c)).charAt(0) &&
                          (d = "-" + d),
                        l + d))),
                (g = i)),
              new g(m, n));
        };
        var u = /^data[-\w.:]+$/i,
          a = /-[a-z]/g,
          s = /[A-Z]/g;
        function c(e) {
          return "-" + e.toLowerCase();
        }
        function f(e) {
          return e.charAt(1).toUpperCase();
        }
      },
      49613: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          for (var t = e.footnoteById, i = e.footnoteOrder, o = 1; o in t; )
            o++;
          return (
            (o = String(o)),
            i.push(o),
            (t[o] = {
              type: "footnoteDefinition",
              identifier: o,
              children: [{ type: "paragraph", children: n.children }],
              position: n.position,
            }),
            r(e, {
              type: "footnoteReference",
              identifier: o,
              position: n.position,
            })
          );
        };
        var r = t(90641);
      },
      49798: (e, n, t) => {
        "use strict";
        var r = t(57301),
          i = t(65759),
          o = t(40148),
          l = t(36898),
          u = t(20187),
          a = t(16525),
          s = t(20979),
          c = t(13125),
          f = t(39029),
          p = t(64876),
          d = {
            tokenize: function (e, n, t) {
              return function (n) {
                return (
                  e.enter("resource"),
                  e.enter("resourceMarker"),
                  e.consume(n),
                  e.exit("resourceMarker"),
                  p(e, i)
                );
              };
              function i(n) {
                return 41 === n
                  ? u(n)
                  : s(
                      e,
                      o,
                      t,
                      "resourceDestination",
                      "resourceDestinationLiteral",
                      "resourceDestinationLiteralMarker",
                      "resourceDestinationRaw",
                      "resourceDestinationString",
                      3
                    )(n);
              }
              function o(n) {
                return r(n) ? p(e, l)(n) : u(n);
              }
              function l(n) {
                return 34 === n || 39 === n || 40 === n
                  ? f(
                      e,
                      p(e, u),
                      t,
                      "resourceTitle",
                      "resourceTitleMarker",
                      "resourceTitleString"
                    )(n)
                  : u(n);
              }
              function u(r) {
                return 41 === r
                  ? (e.enter("resourceMarker"),
                    e.consume(r),
                    e.exit("resourceMarker"),
                    e.exit("resource"),
                    n)
                  : t(r);
              }
            },
          },
          h = {
            tokenize: function (e, n, t) {
              var r = this;
              return function (n) {
                return c.call(
                  r,
                  e,
                  i,
                  t,
                  "reference",
                  "referenceMarker",
                  "referenceString"
                )(n);
              };
              function i(e) {
                return 0 >
                  r.parser.defined.indexOf(
                    l(
                      r
                        .sliceSerialize(r.events[r.events.length - 1][1])
                        .slice(1, -1)
                    )
                  )
                  ? t(e)
                  : n(e);
              }
            },
          },
          m = {
            tokenize: function (e, n, t) {
              return function (n) {
                return (
                  e.enter("reference"),
                  e.enter("referenceMarker"),
                  e.consume(n),
                  e.exit("referenceMarker"),
                  r
                );
              };
              function r(r) {
                return 93 === r
                  ? (e.enter("referenceMarker"),
                    e.consume(r),
                    e.exit("referenceMarker"),
                    e.exit("reference"),
                    n)
                  : t(r);
              }
            },
          };
        e.exports = {
          name: "labelEnd",
          tokenize: function (e, n, t) {
            for (var r, i, o = this, u = o.events.length; u--; )
              if (
                ("labelImage" === o.events[u][1].type ||
                  "labelLink" === o.events[u][1].type) &&
                !o.events[u][1]._balanced
              ) {
                r = o.events[u][1];
                break;
              }
            return function (n) {
              return r
                ? r._inactive
                  ? s(n)
                  : ((i =
                      o.parser.defined.indexOf(
                        l(o.sliceSerialize({ start: r.end, end: o.now() }))
                      ) > -1),
                    e.enter("labelEnd"),
                    e.enter("labelMarker"),
                    e.consume(n),
                    e.exit("labelMarker"),
                    e.exit("labelEnd"),
                    a)
                : t(n);
            };
            function a(t) {
              return 40 === t
                ? e.attempt(d, n, i ? n : s)(t)
                : 91 === t
                ? e.attempt(h, n, i ? e.attempt(m, n, s) : s)(t)
                : i
                ? n(t)
                : s(t);
            }
            function s(e) {
              return (r._balanced = !0), t(e);
            }
          },
          resolveTo: function (e, n) {
            for (var t, r, l, s, c, f, p, d = e.length, h = 0; d--; )
              if (((s = e[d][1]), c)) {
                if (
                  "link" === s.type ||
                  ("labelLink" === s.type && s._inactive)
                )
                  break;
                "enter" === e[d][0] &&
                  "labelLink" === s.type &&
                  (s._inactive = !0);
              } else if (f) {
                if (
                  "enter" === e[d][0] &&
                  ("labelImage" === s.type || "labelLink" === s.type) &&
                  !s._balanced &&
                  ((c = d), "labelLink" !== s.type)
                ) {
                  h = 2;
                  break;
                }
              } else "labelEnd" === s.type && (f = d);
            return (
              (t = {
                type: "labelLink" === e[c][1].type ? "link" : "image",
                start: a(e[c][1].start),
                end: a(e[e.length - 1][1].end),
              }),
              (r = {
                type: "label",
                start: a(e[c][1].start),
                end: a(e[f][1].end),
              }),
              (l = {
                type: "labelText",
                start: a(e[c + h + 2][1].end),
                end: a(e[f - 2][1].start),
              }),
              (p = i(
                (p = [
                  ["enter", t, n],
                  ["enter", r, n],
                ]),
                e.slice(c + 1, c + h + 3)
              )),
              (p = i(p, [["enter", l, n]])),
              (p = i(
                p,
                u(
                  n.parser.constructs.insideSpan.null,
                  e.slice(c + h + 4, f - 3),
                  n
                )
              )),
              (p = i(p, [["exit", l, n], e[f - 2], e[f - 1], ["exit", r, n]])),
              (p = i(p, e.slice(f + 1))),
              (p = i(p, [["exit", t, n]])),
              o(e, c, e.length, p),
              e
            );
          },
          resolveAll: function (e) {
            for (var n, t = -1; ++t < e.length; )
              !(n = e[t][1])._used &&
                ("labelImage" === n.type ||
                  "labelLink" === n.type ||
                  "labelEnd" === n.type) &&
                (e.splice(t + 1, "labelImage" === n.type ? 4 : 2),
                (n.type = "data"),
                t++);
            return e;
          },
        };
      },
      50038: (e, n, t) => {
        "use strict";
        var r = t(2988),
          i = t(87905);
        (e.exports = i),
          (i.prototype.message = function (e, n, t) {
            var i = new r(e, n, t);
            return (
              this.path &&
                ((i.name = this.path + ":" + i.name), (i.file = this.path)),
              (i.fatal = !1),
              this.messages.push(i),
              i
            );
          }),
          (i.prototype.info = function () {
            var e = this.message.apply(this, arguments);
            return (e.fatal = null), e;
          }),
          (i.prototype.fail = function () {
            var e = this.message.apply(this, arguments);
            throw ((e.fatal = !0), e);
          });
      },
      50092: (e) => {
        "use strict";
        e.exports = ["pre", "script", "style", "textarea"];
      },
      50986: (e, n, t) => {
        "use strict";
        e.exports = {
          name: "labelStartLink",
          tokenize: function (e, n, t) {
            var r = this;
            return function (n) {
              return (
                e.enter("labelLink"),
                e.enter("labelMarker"),
                e.consume(n),
                e.exit("labelMarker"),
                e.exit("labelLink"),
                i
              );
            };
            function i(e) {
              return 94 === e && "_hiddenFootnoteSupport" in r.parser.constructs
                ? t(e)
                : n(e);
            }
          },
          resolveAll: t(49798).resolveAll,
        };
      },
      51495: (e, n) => {
        "use strict";
        function t(e) {
          if ("string" != typeof e)
            throw TypeError(
              "Path must be a string. Received " + JSON.stringify(e)
            );
        }
        (n.basename = function (e, n) {
          var r,
            i,
            o,
            l,
            u = 0,
            a = -1;
          if (void 0 !== n && "string" != typeof n)
            throw TypeError('"ext" argument must be a string');
          if (
            (t(e),
            (r = e.length),
            void 0 === n || !n.length || n.length > e.length)
          ) {
            for (; r--; )
              if (47 === e.charCodeAt(r)) {
                if (o) {
                  u = r + 1;
                  break;
                }
              } else a < 0 && ((o = !0), (a = r + 1));
            return a < 0 ? "" : e.slice(u, a);
          }
          if (n === e) return "";
          for (i = -1, l = n.length - 1; r--; )
            if (47 === e.charCodeAt(r)) {
              if (o) {
                u = r + 1;
                break;
              }
            } else
              i < 0 && ((o = !0), (i = r + 1)),
                l > -1 &&
                  (e.charCodeAt(r) === n.charCodeAt(l--)
                    ? l < 0 && (a = r)
                    : ((l = -1), (a = i)));
          return u === a ? (a = i) : a < 0 && (a = e.length), e.slice(u, a);
        }),
          (n.dirname = function (e) {
            var n, r, i;
            if ((t(e), !e.length)) return ".";
            for (n = -1, i = e.length; --i; )
              if (47 === e.charCodeAt(i)) {
                if (r) {
                  n = i;
                  break;
                }
              } else r || (r = !0);
            return n < 0
              ? 47 === e.charCodeAt(0)
                ? "/"
                : "."
              : 1 === n && 47 === e.charCodeAt(0)
              ? "//"
              : e.slice(0, n);
          }),
          (n.extname = function (e) {
            var n,
              r,
              i,
              o = -1,
              l = 0,
              u = -1,
              a = 0;
            for (t(e), i = e.length; i--; ) {
              if (47 === (r = e.charCodeAt(i))) {
                if (n) {
                  l = i + 1;
                  break;
                }
                continue;
              }
              u < 0 && ((n = !0), (u = i + 1)),
                46 === r
                  ? o < 0
                    ? (o = i)
                    : 1 !== a && (a = 1)
                  : o > -1 && (a = -1);
            }
            return o < 0 ||
              u < 0 ||
              0 === a ||
              (1 === a && o === u - 1 && o === l + 1)
              ? ""
              : e.slice(o, u);
          }),
          (n.join = function () {
            for (var e, n, r, i, o = -1; ++o < arguments.length; )
              t(arguments[o]),
                arguments[o] &&
                  (i = void 0 === i ? arguments[o] : i + "/" + arguments[o]);
            return void 0 === i
              ? "."
              : (t((e = i)),
                (n = 47 === e.charCodeAt(0)),
                (r = (function (e, n) {
                  for (
                    var t, r, i = "", o = 0, l = -1, u = 0, a = -1;
                    ++a <= e.length;

                  ) {
                    if (a < e.length) t = e.charCodeAt(a);
                    else if (47 === t) break;
                    else t = 47;
                    if (47 === t) {
                      if (l === a - 1 || 1 === u);
                      else if (l !== a - 1 && 2 === u) {
                        if (
                          i.length < 2 ||
                          2 !== o ||
                          46 !== i.charCodeAt(i.length - 1) ||
                          46 !== i.charCodeAt(i.length - 2)
                        ) {
                          if (i.length > 2) {
                            if ((r = i.lastIndexOf("/")) !== i.length - 1) {
                              r < 0
                                ? ((i = ""), (o = 0))
                                : (o =
                                    (i = i.slice(0, r)).length -
                                    1 -
                                    i.lastIndexOf("/")),
                                (l = a),
                                (u = 0);
                              continue;
                            }
                          } else if (i.length) {
                            (i = ""), (o = 0), (l = a), (u = 0);
                            continue;
                          }
                        }
                        n && ((i = i.length ? i + "/.." : ".."), (o = 2));
                      } else
                        i.length
                          ? (i += "/" + e.slice(l + 1, a))
                          : (i = e.slice(l + 1, a)),
                          (o = a - l - 1);
                      (l = a), (u = 0);
                    } else 46 === t && u > -1 ? u++ : (u = -1);
                  }
                  return i;
                })(e, !n)).length ||
                  n ||
                  (r = "."),
                r.length && 47 === e.charCodeAt(e.length - 1) && (r += "/"),
                n ? "/" + r : r);
          }),
          (n.sep = "/");
      },
      52334: (e) => {
        "use strict";
        e.exports = Object.assign;
      },
      52929: (e, n, t) => {
        "use strict";
        e.exports = t(39427)(/\s/);
      },
      53186: (e, n, t) => {
        "use strict";
        var r = t(77272),
          i = t(16525),
          o = t(24969);
        e.exports = {
          name: "setextUnderline",
          tokenize: function (e, n, t) {
            for (var i, l, u = this, a = u.events.length; a--; )
              if (
                "lineEnding" !== u.events[a][1].type &&
                "linePrefix" !== u.events[a][1].type &&
                "content" !== u.events[a][1].type
              ) {
                l = "paragraph" === u.events[a][1].type;
                break;
              }
            return function (n) {
              return !u.lazy && (u.interrupt || l)
                ? (e.enter("setextHeadingLine"),
                  e.enter("setextHeadingLineSequence"),
                  (i = n),
                  (function n(t) {
                    return t === i
                      ? (e.consume(t), n)
                      : (e.exit("setextHeadingLineSequence"),
                        o(e, s, "lineSuffix")(t));
                  })(n))
                : t(n);
            };
            function s(i) {
              return null === i || r(i)
                ? (e.exit("setextHeadingLine"), n(i))
                : t(i);
            }
          },
          resolveTo: function (e, n) {
            for (var t, r, o, l, u = e.length; u--; )
              if ("enter" === e[u][0]) {
                if ("content" === e[u][1].type) {
                  t = u;
                  break;
                }
                "paragraph" === e[u][1].type && (r = u);
              } else
                "content" === e[u][1].type && e.splice(u, 1),
                  o || "definition" !== e[u][1].type || (o = u);
            return (
              (l = {
                type: "setextHeading",
                start: i(e[r][1].start),
                end: i(e[e.length - 1][1].end),
              }),
              (e[r][1].type = "setextHeadingText"),
              o
                ? (e.splice(r, 0, ["enter", l, n]),
                  e.splice(o + 1, 0, ["exit", e[t][1], n]),
                  (e[t][1].end = i(e[o][1].end)))
                : (e[t][1] = l),
              e.push(["exit", l, n]),
              e
            );
          },
        };
      },
      53253: (e, n, t) => {
        "use strict";
        Object.defineProperty(n, "__esModule", { value: !0 });
        var r = t(84181),
          i = t(24969),
          o = t(48335);
        n.tokenize = function (e) {
          var n = this,
            t = e.attempt(
              o,
              function (r) {
                return null === r
                  ? void e.consume(r)
                  : (e.enter("lineEndingBlank"),
                    e.consume(r),
                    e.exit("lineEndingBlank"),
                    (n.currentConstruct = void 0),
                    t);
              },
              e.attempt(
                this.parser.constructs.flowInitial,
                l,
                i(
                  e,
                  e.attempt(this.parser.constructs.flow, l, e.attempt(r, l)),
                  "linePrefix"
                )
              )
            );
          return t;
          function l(r) {
            return null === r
              ? void e.consume(r)
              : (e.enter("lineEnding"),
                e.consume(r),
                e.exit("lineEnding"),
                (n.currentConstruct = void 0),
                t);
          }
        };
      },
      53322: (e) => {
        "use strict";
        function n() {
          return !0;
        }
        e.exports = function e(t) {
          var r, i;
          if (null == t) return n;
          if ("string" == typeof t) {
            return (
              (r = t),
              function (e) {
                return !!(e && e.type === r);
              }
            );
          }
          if ("object" == typeof t) {
            return "length" in t
              ? (function (n) {
                  for (var t = [], r = -1; ++r < n.length; ) t[r] = e(n[r]);
                  return function () {
                    for (var e = -1; ++e < t.length; )
                      if (t[e].apply(this, arguments)) return !0;
                    return !1;
                  };
                })(t)
              : ((i = t),
                function (e) {
                  var n;
                  for (n in i) if (e[n] !== i[n]) return !1;
                  return !0;
                });
          }
          if ("function" == typeof t) return t;
          throw Error("Expected function, string, or object as test");
        };
      },
      56121: (e, n, t) => {
        e.exports = t(61847)();
      },
      57301: (e) => {
        "use strict";
        e.exports = function (e) {
          return e < 0 || 32 === e;
        };
      },
      57453: (e, n) => {
        "use strict";
        var t = 60103,
          r = 60106,
          i = 60107,
          o = 60108,
          l = 60114,
          u = 60109,
          a = 60110,
          s = 60112,
          c = 60113,
          f = 60120,
          p = 60115,
          d = 60116,
          h = 60121,
          m = 60122,
          g = 60117,
          v = 60129,
          x = 60131;
        if ("function" == typeof Symbol && Symbol.for) {
          var y = Symbol.for;
          (t = y("react.element")),
            (r = y("react.portal")),
            (i = y("react.fragment")),
            (o = y("react.strict_mode")),
            (l = y("react.profiler")),
            (u = y("react.provider")),
            (a = y("react.context")),
            (s = y("react.forward_ref")),
            (c = y("react.suspense")),
            (f = y("react.suspense_list")),
            (p = y("react.memo")),
            (d = y("react.lazy")),
            (h = y("react.block")),
            (m = y("react.server.block")),
            (g = y("react.fundamental")),
            (v = y("react.debug_trace_mode")),
            (x = y("react.legacy_hidden"));
        }
        function k(e) {
          if ("object" == typeof e && null !== e) {
            var n = e.$$typeof;
            switch (n) {
              case t:
                switch ((e = e.type)) {
                  case i:
                  case l:
                  case o:
                  case c:
                  case f:
                    return e;
                  default:
                    switch ((e = e && e.$$typeof)) {
                      case a:
                      case s:
                      case d:
                      case p:
                      case u:
                        return e;
                      default:
                        return n;
                    }
                }
              case r:
                return n;
            }
          }
        }
        var b = u,
          S = t,
          w = s,
          E = i,
          C = d,
          F = p,
          P = r,
          T = l,
          A = o,
          O = c;
        (n.ContextConsumer = a),
          (n.ContextProvider = b),
          (n.Element = S),
          (n.ForwardRef = w),
          (n.Fragment = E),
          (n.Lazy = C),
          (n.Memo = F),
          (n.Portal = P),
          (n.Profiler = T),
          (n.StrictMode = A),
          (n.Suspense = O),
          (n.isAsyncMode = function () {
            return !1;
          }),
          (n.isConcurrentMode = function () {
            return !1;
          }),
          (n.isContextConsumer = function (e) {
            return k(e) === a;
          }),
          (n.isContextProvider = function (e) {
            return k(e) === u;
          }),
          (n.isElement = function (e) {
            return "object" == typeof e && null !== e && e.$$typeof === t;
          }),
          (n.isForwardRef = function (e) {
            return k(e) === s;
          }),
          (n.isFragment = function (e) {
            return k(e) === i;
          }),
          (n.isLazy = function (e) {
            return k(e) === d;
          }),
          (n.isMemo = function (e) {
            return k(e) === p;
          }),
          (n.isPortal = function (e) {
            return k(e) === r;
          }),
          (n.isProfiler = function (e) {
            return k(e) === l;
          }),
          (n.isStrictMode = function (e) {
            return k(e) === o;
          }),
          (n.isSuspense = function (e) {
            return k(e) === c;
          }),
          (n.isValidElementType = function (e) {
            return (
              "string" == typeof e ||
              "function" == typeof e ||
              e === i ||
              e === l ||
              e === v ||
              e === o ||
              e === c ||
              e === f ||
              e === x ||
              ("object" == typeof e &&
                null !== e &&
                (e.$$typeof === d ||
                  e.$$typeof === p ||
                  e.$$typeof === u ||
                  e.$$typeof === a ||
                  e.$$typeof === s ||
                  e.$$typeof === g ||
                  e.$$typeof === h ||
                  e[0] === m)) ||
              !1
            );
          }),
          (n.typeOf = k);
      },
      57983: (e) => {
        "use strict";
        e.exports = [].splice;
      },
      60049: (e) => {
        "use strict";
        e.exports =
          /[!-\/:-@\[-`\{-~\xA1\xA7\xAB\xB6\xB7\xBB\xBF\u037E\u0387\u055A-\u055F\u0589\u058A\u05BE\u05C0\u05C3\u05C6\u05F3\u05F4\u0609\u060A\u060C\u060D\u061B\u061E\u061F\u066A-\u066D\u06D4\u0700-\u070D\u07F7-\u07F9\u0830-\u083E\u085E\u0964\u0965\u0970\u09FD\u0A76\u0AF0\u0C77\u0C84\u0DF4\u0E4F\u0E5A\u0E5B\u0F04-\u0F12\u0F14\u0F3A-\u0F3D\u0F85\u0FD0-\u0FD4\u0FD9\u0FDA\u104A-\u104F\u10FB\u1360-\u1368\u1400\u166E\u169B\u169C\u16EB-\u16ED\u1735\u1736\u17D4-\u17D6\u17D8-\u17DA\u1800-\u180A\u1944\u1945\u1A1E\u1A1F\u1AA0-\u1AA6\u1AA8-\u1AAD\u1B5A-\u1B60\u1BFC-\u1BFF\u1C3B-\u1C3F\u1C7E\u1C7F\u1CC0-\u1CC7\u1CD3\u2010-\u2027\u2030-\u2043\u2045-\u2051\u2053-\u205E\u207D\u207E\u208D\u208E\u2308-\u230B\u2329\u232A\u2768-\u2775\u27C5\u27C6\u27E6-\u27EF\u2983-\u2998\u29D8-\u29DB\u29FC\u29FD\u2CF9-\u2CFC\u2CFE\u2CFF\u2D70\u2E00-\u2E2E\u2E30-\u2E4F\u2E52\u3001-\u3003\u3008-\u3011\u3014-\u301F\u3030\u303D\u30A0\u30FB\uA4FE\uA4FF\uA60D-\uA60F\uA673\uA67E\uA6F2-\uA6F7\uA874-\uA877\uA8CE\uA8CF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA95F\uA9C1-\uA9CD\uA9DE\uA9DF\uAA5C-\uAA5F\uAADE\uAADF\uAAF0\uAAF1\uABEB\uFD3E\uFD3F\uFE10-\uFE19\uFE30-\uFE52\uFE54-\uFE61\uFE63\uFE68\uFE6A\uFE6B\uFF01-\uFF03\uFF05-\uFF0A\uFF0C-\uFF0F\uFF1A\uFF1B\uFF1F\uFF20\uFF3B-\uFF3D\uFF3F\uFF5B\uFF5D\uFF5F-\uFF65]/;
      },
      60291: (e, n, t) => {
        "use strict";
        var r = t(77272),
          i = t(57301),
          o = t(96143),
          l = t(24969);
        e.exports = {
          name: "codeFenced",
          tokenize: function (e, n, t) {
            var u,
              a = this,
              s = {
                tokenize: function (e, n, t) {
                  var i = 0;
                  return l(
                    e,
                    function (n) {
                      return (
                        e.enter("codeFencedFence"),
                        e.enter("codeFencedFenceSequence"),
                        (function n(r) {
                          return r === u
                            ? (e.consume(r), i++, n)
                            : i < f
                            ? t(r)
                            : (e.exit("codeFencedFenceSequence"),
                              l(e, o, "whitespace")(r));
                        })(n)
                      );
                    },
                    "linePrefix",
                    this.parser.constructs.disable.null.indexOf(
                      "codeIndented"
                    ) > -1
                      ? void 0
                      : 4
                  );
                  function o(i) {
                    return null === i || r(i)
                      ? (e.exit("codeFencedFence"), n(i))
                      : t(i);
                  }
                },
                partial: !0,
              },
              c = o(this.events, "linePrefix"),
              f = 0;
            return function (n) {
              return (
                e.enter("codeFenced"),
                e.enter("codeFencedFence"),
                e.enter("codeFencedFenceSequence"),
                (u = n),
                (function n(r) {
                  return r === u
                    ? (e.consume(r), f++, n)
                    : (e.exit("codeFencedFenceSequence"),
                      f < 3 ? t(r) : l(e, p, "whitespace")(r));
                })(n)
              );
            };
            function p(n) {
              return null === n || r(n)
                ? h(n)
                : (e.enter("codeFencedFenceInfo"),
                  e.enter("chunkString", { contentType: "string" }),
                  (function n(r) {
                    return null === r || i(r)
                      ? (e.exit("chunkString"),
                        e.exit("codeFencedFenceInfo"),
                        l(e, d, "whitespace")(r))
                      : 96 === r && r === u
                      ? t(r)
                      : (e.consume(r), n);
                  })(n));
            }
            function d(n) {
              return null === n || r(n)
                ? h(n)
                : (e.enter("codeFencedFenceMeta"),
                  e.enter("chunkString", { contentType: "string" }),
                  (function n(i) {
                    return null === i || r(i)
                      ? (e.exit("chunkString"),
                        e.exit("codeFencedFenceMeta"),
                        h(i))
                      : 96 === i && i === u
                      ? t(i)
                      : (e.consume(i), n);
                  })(n));
            }
            function h(t) {
              return (
                e.exit("codeFencedFence"),
                a.interrupt
                  ? n(t)
                  : (function n(t) {
                      return null === t
                        ? m(t)
                        : r(t)
                        ? (e.enter("lineEnding"),
                          e.consume(t),
                          e.exit("lineEnding"),
                          e.attempt(s, m, c ? l(e, n, "linePrefix", c + 1) : n))
                        : (e.enter("codeFlowValue"),
                          (function t(i) {
                            return null === i || r(i)
                              ? (e.exit("codeFlowValue"), n(i))
                              : (e.consume(i), t);
                          })(t));
                    })(t)
              );
            }
            function m(t) {
              return e.exit("codeFenced"), n(t);
            }
          },
          concrete: !0,
        };
      },
      61482: (e, n) => {
        "use strict";
        (n.parse = function (e) {
          for (
            var n,
              t = [],
              r = String(e || ""),
              i = r.indexOf(","),
              o = 0,
              l = !1;
            !l;

          )
            -1 === i && ((i = r.length), (l = !0)),
              ((n = r.slice(o, i).trim()) || !l) && t.push(n),
              (o = i + 1),
              (i = r.indexOf(",", o));
          return t;
        }),
          (n.stringify = function (e, n) {
            var t = n || {},
              r = !1 === t.padLeft ? "" : " ",
              i = t.padRight ? " " : "";
            return (
              "" === e[e.length - 1] && (e = e.concat("")),
              e.join(i + "," + r).trim()
            );
          });
      },
      61847: (e, n, t) => {
        "use strict";
        var r = t(4140);
        function i() {}
        function o() {}
        (o.resetWarningCache = i),
          (e.exports = function () {
            function e(e, n, t, i, o, l) {
              if (l !== r) {
                var u = Error(
                  "Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types"
                );
                throw ((u.name = "Invariant Violation"), u);
              }
            }
            function n() {
              return e;
            }
            e.isRequired = e;
            var t = {
              array: e,
              bigint: e,
              bool: e,
              func: e,
              number: e,
              object: e,
              string: e,
              symbol: e,
              any: e,
              arrayOf: n,
              element: e,
              elementType: e,
              instanceOf: n,
              node: e,
              objectOf: n,
              oneOf: n,
              oneOfType: n,
              shape: n,
              exact: n,
              checkPropTypes: o,
              resetWarningCache: i,
            };
            return (t.PropTypes = t), t;
          });
      },
      63877: (e, n, t) => {
        "use strict";
        let r = t(55729),
          i = t(95318),
          o = t(41588),
          l = t(87042),
          u = t(78712),
          a = t(56121),
          s = t(19947),
          c = t(74788),
          f = t(1050),
          p = t(68762).i;
        e.exports = m;
        let d = {}.hasOwnProperty,
          h = {
            renderers: {
              to: "components",
              id: "change-renderers-to-components",
            },
            astPlugins: { id: "remove-buggy-html-in-markdown-parser" },
            allowDangerousHtml: { id: "remove-buggy-html-in-markdown-parser" },
            escapeHtml: { id: "remove-buggy-html-in-markdown-parser" },
            source: { to: "children", id: "change-source-to-children" },
            allowNode: {
              to: "allowElement",
              id: "replace-allownode-allowedtypes-and-disallowedtypes",
            },
            allowedTypes: {
              to: "allowedElements",
              id: "replace-allownode-allowedtypes-and-disallowedtypes",
            },
            disallowedTypes: {
              to: "disallowedElements",
              id: "replace-allownode-allowedtypes-and-disallowedtypes",
            },
            includeNodeIndex: {
              to: "includeElementIndex",
              id: "change-includenodeindex-to-includeelementindex",
            },
          };
        function m(e) {
          let n;
          for (let n in h)
            if (d.call(h, n) && d.call(e, n)) {
              let e = h[n];
              console.warn(
                `[react-markdown] Warning: please ${
                  e.to ? `use \`${e.to}\` instead of` : "remove"
                } \`${n}\` (see <https://github.com/remarkjs/react-markdown/blob/main/changelog.md#${
                  e.id
                }> for more info)`
              ),
                delete h[n];
            }
          let t = o()
            .use(l)
            .use(e.remarkPlugins || e.plugins || [])
            .use(u, { allowDangerousHtml: !0 })
            .use(e.rehypePlugins || [])
            .use(c, e);
          "string" == typeof e.children
            ? (n = i(e.children))
            : (void 0 !== e.children &&
                null !== e.children &&
                console.warn(
                  `[react-markdown] Warning: please pass a string as \`children\` (not: \`${e.children}\`)`
                ),
              (n = i()));
          let a = t.runSync(t.parse(n), n);
          if ("root" !== a.type) throw TypeError("Expected a `root` node");
          let f = r.createElement(
            r.Fragment,
            {},
            p({ options: e, schema: s, listDepth: 0 }, a)
          );
          return (
            e.className &&
              (f = r.createElement("div", { className: e.className }, f)),
            f
          );
        }
        (m.defaultProps = { transformLinkUri: f }),
          (m.propTypes = {
            children: a.string,
            className: a.string,
            allowElement: a.func,
            allowedElements: a.arrayOf(a.string),
            disallowedElements: a.arrayOf(a.string),
            unwrapDisallowed: a.bool,
            remarkPlugins: a.arrayOf(
              a.oneOfType([
                a.object,
                a.func,
                a.arrayOf(a.oneOfType([a.object, a.func])),
              ])
            ),
            rehypePlugins: a.arrayOf(
              a.oneOfType([
                a.object,
                a.func,
                a.arrayOf(a.oneOfType([a.object, a.func])),
              ])
            ),
            sourcePos: a.bool,
            rawSourcePos: a.bool,
            skipHtml: a.bool,
            includeElementIndex: a.bool,
            transformLinkUri: a.oneOfType([a.func, a.bool]),
            linkTarget: a.oneOfType([a.func, a.string]),
            transformImageUri: a.func,
            components: a.object,
          }),
          (m.uriTransformer = f);
      },
      64733: (e, n, t) => {
        "use strict";
        e.exports = t(10312);
      },
      64876: (e, n, t) => {
        "use strict";
        var r = t(77272),
          i = t(22552),
          o = t(24969);
        e.exports = function (e, n) {
          var t;
          return function l(u) {
            return r(u)
              ? (e.enter("lineEnding"),
                e.consume(u),
                e.exit("lineEnding"),
                (t = !0),
                l)
              : i(u)
              ? o(e, l, t ? "linePrefix" : "lineSuffix")(u)
              : n(u);
          };
        };
      },
      65079: (e, n, t) => {
        "use strict";
        var r = t(91815),
          i = t(10124);
        (e.exports = u), (u.prototype = new r()), (u.prototype.defined = !0);
        var o = [
            "boolean",
            "booleanish",
            "overloadedBoolean",
            "number",
            "commaSeparated",
            "spaceSeparated",
            "commaOrSpaceSeparated",
          ],
          l = o.length;
        function u(e, n, t, u) {
          var a,
            s,
            c,
            f,
            p,
            d,
            h = -1;
          for (
            a = this, (s = u) && (a.space = s), r.call(this, e, n);
            ++h < l;

          ) {
            (c = this), (f = d = o[h]), (p = (t & i[d]) === i[d]) && (c[f] = p);
          }
        }
      },
      65759: (e, n, t) => {
        "use strict";
        var r = t(40148);
        e.exports = function (e, n) {
          return e.length ? (r(e, e.length, 0, n), e) : n;
        };
      },
      65857: (e) => {
        "use strict";
        e.exports = function (e) {
          return e.toLowerCase();
        };
      },
      66230: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          return e(n, "strong", r(e, n));
        };
        var r = t(73684);
      },
      66250: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          return e(n, "del", r(e, n));
        };
        var r = t(73684);
      },
      66404: (e, n, t) => {
        "use strict";
        var r = t(10124),
          i = t(46399),
          o = t(47383),
          l = r.boolean,
          u = r.number,
          a = r.spaceSeparated,
          s = r.commaSeparated,
          c = r.commaOrSpaceSeparated;
        e.exports = i({
          space: "svg",
          attributes: {
            accentHeight: "accent-height",
            alignmentBaseline: "alignment-baseline",
            arabicForm: "arabic-form",
            baselineShift: "baseline-shift",
            capHeight: "cap-height",
            className: "class",
            clipPath: "clip-path",
            clipRule: "clip-rule",
            colorInterpolation: "color-interpolation",
            colorInterpolationFilters: "color-interpolation-filters",
            colorProfile: "color-profile",
            colorRendering: "color-rendering",
            crossOrigin: "crossorigin",
            dataType: "datatype",
            dominantBaseline: "dominant-baseline",
            enableBackground: "enable-background",
            fillOpacity: "fill-opacity",
            fillRule: "fill-rule",
            floodColor: "flood-color",
            floodOpacity: "flood-opacity",
            fontFamily: "font-family",
            fontSize: "font-size",
            fontSizeAdjust: "font-size-adjust",
            fontStretch: "font-stretch",
            fontStyle: "font-style",
            fontVariant: "font-variant",
            fontWeight: "font-weight",
            glyphName: "glyph-name",
            glyphOrientationHorizontal: "glyph-orientation-horizontal",
            glyphOrientationVertical: "glyph-orientation-vertical",
            hrefLang: "hreflang",
            horizAdvX: "horiz-adv-x",
            horizOriginX: "horiz-origin-x",
            horizOriginY: "horiz-origin-y",
            imageRendering: "image-rendering",
            letterSpacing: "letter-spacing",
            lightingColor: "lighting-color",
            markerEnd: "marker-end",
            markerMid: "marker-mid",
            markerStart: "marker-start",
            navDown: "nav-down",
            navDownLeft: "nav-down-left",
            navDownRight: "nav-down-right",
            navLeft: "nav-left",
            navNext: "nav-next",
            navPrev: "nav-prev",
            navRight: "nav-right",
            navUp: "nav-up",
            navUpLeft: "nav-up-left",
            navUpRight: "nav-up-right",
            onAbort: "onabort",
            onActivate: "onactivate",
            onAfterPrint: "onafterprint",
            onBeforePrint: "onbeforeprint",
            onBegin: "onbegin",
            onCancel: "oncancel",
            onCanPlay: "oncanplay",
            onCanPlayThrough: "oncanplaythrough",
            onChange: "onchange",
            onClick: "onclick",
            onClose: "onclose",
            onCopy: "oncopy",
            onCueChange: "oncuechange",
            onCut: "oncut",
            onDblClick: "ondblclick",
            onDrag: "ondrag",
            onDragEnd: "ondragend",
            onDragEnter: "ondragenter",
            onDragExit: "ondragexit",
            onDragLeave: "ondragleave",
            onDragOver: "ondragover",
            onDragStart: "ondragstart",
            onDrop: "ondrop",
            onDurationChange: "ondurationchange",
            onEmptied: "onemptied",
            onEnd: "onend",
            onEnded: "onended",
            onError: "onerror",
            onFocus: "onfocus",
            onFocusIn: "onfocusin",
            onFocusOut: "onfocusout",
            onHashChange: "onhashchange",
            onInput: "oninput",
            onInvalid: "oninvalid",
            onKeyDown: "onkeydown",
            onKeyPress: "onkeypress",
            onKeyUp: "onkeyup",
            onLoad: "onload",
            onLoadedData: "onloadeddata",
            onLoadedMetadata: "onloadedmetadata",
            onLoadStart: "onloadstart",
            onMessage: "onmessage",
            onMouseDown: "onmousedown",
            onMouseEnter: "onmouseenter",
            onMouseLeave: "onmouseleave",
            onMouseMove: "onmousemove",
            onMouseOut: "onmouseout",
            onMouseOver: "onmouseover",
            onMouseUp: "onmouseup",
            onMouseWheel: "onmousewheel",
            onOffline: "onoffline",
            onOnline: "ononline",
            onPageHide: "onpagehide",
            onPageShow: "onpageshow",
            onPaste: "onpaste",
            onPause: "onpause",
            onPlay: "onplay",
            onPlaying: "onplaying",
            onPopState: "onpopstate",
            onProgress: "onprogress",
            onRateChange: "onratechange",
            onRepeat: "onrepeat",
            onReset: "onreset",
            onResize: "onresize",
            onScroll: "onscroll",
            onSeeked: "onseeked",
            onSeeking: "onseeking",
            onSelect: "onselect",
            onShow: "onshow",
            onStalled: "onstalled",
            onStorage: "onstorage",
            onSubmit: "onsubmit",
            onSuspend: "onsuspend",
            onTimeUpdate: "ontimeupdate",
            onToggle: "ontoggle",
            onUnload: "onunload",
            onVolumeChange: "onvolumechange",
            onWaiting: "onwaiting",
            onZoom: "onzoom",
            overlinePosition: "overline-position",
            overlineThickness: "overline-thickness",
            paintOrder: "paint-order",
            panose1: "panose-1",
            pointerEvents: "pointer-events",
            referrerPolicy: "referrerpolicy",
            renderingIntent: "rendering-intent",
            shapeRendering: "shape-rendering",
            stopColor: "stop-color",
            stopOpacity: "stop-opacity",
            strikethroughPosition: "strikethrough-position",
            strikethroughThickness: "strikethrough-thickness",
            strokeDashArray: "stroke-dasharray",
            strokeDashOffset: "stroke-dashoffset",
            strokeLineCap: "stroke-linecap",
            strokeLineJoin: "stroke-linejoin",
            strokeMiterLimit: "stroke-miterlimit",
            strokeOpacity: "stroke-opacity",
            strokeWidth: "stroke-width",
            tabIndex: "tabindex",
            textAnchor: "text-anchor",
            textDecoration: "text-decoration",
            textRendering: "text-rendering",
            typeOf: "typeof",
            underlinePosition: "underline-position",
            underlineThickness: "underline-thickness",
            unicodeBidi: "unicode-bidi",
            unicodeRange: "unicode-range",
            unitsPerEm: "units-per-em",
            vAlphabetic: "v-alphabetic",
            vHanging: "v-hanging",
            vIdeographic: "v-ideographic",
            vMathematical: "v-mathematical",
            vectorEffect: "vector-effect",
            vertAdvY: "vert-adv-y",
            vertOriginX: "vert-origin-x",
            vertOriginY: "vert-origin-y",
            wordSpacing: "word-spacing",
            writingMode: "writing-mode",
            xHeight: "x-height",
            playbackOrder: "playbackorder",
            timelineBegin: "timelinebegin",
          },
          transform: o,
          properties: {
            about: c,
            accentHeight: u,
            accumulate: null,
            additive: null,
            alignmentBaseline: null,
            alphabetic: u,
            amplitude: u,
            arabicForm: null,
            ascent: u,
            attributeName: null,
            attributeType: null,
            azimuth: u,
            bandwidth: null,
            baselineShift: null,
            baseFrequency: null,
            baseProfile: null,
            bbox: null,
            begin: null,
            bias: u,
            by: null,
            calcMode: null,
            capHeight: u,
            className: a,
            clip: null,
            clipPath: null,
            clipPathUnits: null,
            clipRule: null,
            color: null,
            colorInterpolation: null,
            colorInterpolationFilters: null,
            colorProfile: null,
            colorRendering: null,
            content: null,
            contentScriptType: null,
            contentStyleType: null,
            crossOrigin: null,
            cursor: null,
            cx: null,
            cy: null,
            d: null,
            dataType: null,
            defaultAction: null,
            descent: u,
            diffuseConstant: u,
            direction: null,
            display: null,
            dur: null,
            divisor: u,
            dominantBaseline: null,
            download: l,
            dx: null,
            dy: null,
            edgeMode: null,
            editable: null,
            elevation: u,
            enableBackground: null,
            end: null,
            event: null,
            exponent: u,
            externalResourcesRequired: null,
            fill: null,
            fillOpacity: u,
            fillRule: null,
            filter: null,
            filterRes: null,
            filterUnits: null,
            floodColor: null,
            floodOpacity: null,
            focusable: null,
            focusHighlight: null,
            fontFamily: null,
            fontSize: null,
            fontSizeAdjust: null,
            fontStretch: null,
            fontStyle: null,
            fontVariant: null,
            fontWeight: null,
            format: null,
            fr: null,
            from: null,
            fx: null,
            fy: null,
            g1: s,
            g2: s,
            glyphName: s,
            glyphOrientationHorizontal: null,
            glyphOrientationVertical: null,
            glyphRef: null,
            gradientTransform: null,
            gradientUnits: null,
            handler: null,
            hanging: u,
            hatchContentUnits: null,
            hatchUnits: null,
            height: null,
            href: null,
            hrefLang: null,
            horizAdvX: u,
            horizOriginX: u,
            horizOriginY: u,
            id: null,
            ideographic: u,
            imageRendering: null,
            initialVisibility: null,
            in: null,
            in2: null,
            intercept: u,
            k: u,
            k1: u,
            k2: u,
            k3: u,
            k4: u,
            kernelMatrix: c,
            kernelUnitLength: null,
            keyPoints: null,
            keySplines: null,
            keyTimes: null,
            kerning: null,
            lang: null,
            lengthAdjust: null,
            letterSpacing: null,
            lightingColor: null,
            limitingConeAngle: u,
            local: null,
            markerEnd: null,
            markerMid: null,
            markerStart: null,
            markerHeight: null,
            markerUnits: null,
            markerWidth: null,
            mask: null,
            maskContentUnits: null,
            maskUnits: null,
            mathematical: null,
            max: null,
            media: null,
            mediaCharacterEncoding: null,
            mediaContentEncodings: null,
            mediaSize: u,
            mediaTime: null,
            method: null,
            min: null,
            mode: null,
            name: null,
            navDown: null,
            navDownLeft: null,
            navDownRight: null,
            navLeft: null,
            navNext: null,
            navPrev: null,
            navRight: null,
            navUp: null,
            navUpLeft: null,
            navUpRight: null,
            numOctaves: null,
            observer: null,
            offset: null,
            onAbort: null,
            onActivate: null,
            onAfterPrint: null,
            onBeforePrint: null,
            onBegin: null,
            onCancel: null,
            onCanPlay: null,
            onCanPlayThrough: null,
            onChange: null,
            onClick: null,
            onClose: null,
            onCopy: null,
            onCueChange: null,
            onCut: null,
            onDblClick: null,
            onDrag: null,
            onDragEnd: null,
            onDragEnter: null,
            onDragExit: null,
            onDragLeave: null,
            onDragOver: null,
            onDragStart: null,
            onDrop: null,
            onDurationChange: null,
            onEmptied: null,
            onEnd: null,
            onEnded: null,
            onError: null,
            onFocus: null,
            onFocusIn: null,
            onFocusOut: null,
            onHashChange: null,
            onInput: null,
            onInvalid: null,
            onKeyDown: null,
            onKeyPress: null,
            onKeyUp: null,
            onLoad: null,
            onLoadedData: null,
            onLoadedMetadata: null,
            onLoadStart: null,
            onMessage: null,
            onMouseDown: null,
            onMouseEnter: null,
            onMouseLeave: null,
            onMouseMove: null,
            onMouseOut: null,
            onMouseOver: null,
            onMouseUp: null,
            onMouseWheel: null,
            onOffline: null,
            onOnline: null,
            onPageHide: null,
            onPageShow: null,
            onPaste: null,
            onPause: null,
            onPlay: null,
            onPlaying: null,
            onPopState: null,
            onProgress: null,
            onRateChange: null,
            onRepeat: null,
            onReset: null,
            onResize: null,
            onScroll: null,
            onSeeked: null,
            onSeeking: null,
            onSelect: null,
            onShow: null,
            onStalled: null,
            onStorage: null,
            onSubmit: null,
            onSuspend: null,
            onTimeUpdate: null,
            onToggle: null,
            onUnload: null,
            onVolumeChange: null,
            onWaiting: null,
            onZoom: null,
            opacity: null,
            operator: null,
            order: null,
            orient: null,
            orientation: null,
            origin: null,
            overflow: null,
            overlay: null,
            overlinePosition: u,
            overlineThickness: u,
            paintOrder: null,
            panose1: null,
            path: null,
            pathLength: u,
            patternContentUnits: null,
            patternTransform: null,
            patternUnits: null,
            phase: null,
            ping: a,
            pitch: null,
            playbackOrder: null,
            pointerEvents: null,
            points: null,
            pointsAtX: u,
            pointsAtY: u,
            pointsAtZ: u,
            preserveAlpha: null,
            preserveAspectRatio: null,
            primitiveUnits: null,
            propagate: null,
            property: c,
            r: null,
            radius: null,
            referrerPolicy: null,
            refX: null,
            refY: null,
            rel: c,
            rev: c,
            renderingIntent: null,
            repeatCount: null,
            repeatDur: null,
            requiredExtensions: c,
            requiredFeatures: c,
            requiredFonts: c,
            requiredFormats: c,
            resource: null,
            restart: null,
            result: null,
            rotate: null,
            rx: null,
            ry: null,
            scale: null,
            seed: null,
            shapeRendering: null,
            side: null,
            slope: null,
            snapshotTime: null,
            specularConstant: u,
            specularExponent: u,
            spreadMethod: null,
            spacing: null,
            startOffset: null,
            stdDeviation: null,
            stemh: null,
            stemv: null,
            stitchTiles: null,
            stopColor: null,
            stopOpacity: null,
            strikethroughPosition: u,
            strikethroughThickness: u,
            string: null,
            stroke: null,
            strokeDashArray: c,
            strokeDashOffset: null,
            strokeLineCap: null,
            strokeLineJoin: null,
            strokeMiterLimit: u,
            strokeOpacity: u,
            strokeWidth: null,
            style: null,
            surfaceScale: u,
            syncBehavior: null,
            syncBehaviorDefault: null,
            syncMaster: null,
            syncTolerance: null,
            syncToleranceDefault: null,
            systemLanguage: c,
            tabIndex: u,
            tableValues: null,
            target: null,
            targetX: u,
            targetY: u,
            textAnchor: null,
            textDecoration: null,
            textRendering: null,
            textLength: null,
            timelineBegin: null,
            title: null,
            transformBehavior: null,
            type: null,
            typeOf: c,
            to: null,
            transform: null,
            u1: null,
            u2: null,
            underlinePosition: u,
            underlineThickness: u,
            unicode: null,
            unicodeBidi: null,
            unicodeRange: null,
            unitsPerEm: u,
            values: null,
            vAlphabetic: u,
            vMathematical: u,
            vectorEffect: null,
            vHanging: u,
            vIdeographic: u,
            version: null,
            vertAdvY: u,
            vertOriginX: u,
            vertOriginY: u,
            viewBox: null,
            viewTarget: null,
            visibility: null,
            width: null,
            widths: null,
            wordSpacing: null,
            writingMode: null,
            x: null,
            x1: null,
            x2: null,
            xChannelSelector: null,
            xHeight: u,
            y: null,
            y1: null,
            y2: null,
            yChannelSelector: null,
            z: null,
            zoomAndPan: null,
          },
        });
      },
      66572: (e, n, t) => {
        "use strict";
        e.exports = t(39427)(/[!-/:-@[-`{-~]/);
      },
      68762: (e, n, t) => {
        "use strict";
        let r = t(55729),
          i = t(28305),
          o = t(76932),
          l = t(49105),
          u = t(1490),
          a = t(94889),
          s = t(61482),
          c = t(91129);
        n.i = d;
        let f = {}.hasOwnProperty,
          p = new Set(["table", "thead", "tbody", "tfoot", "tr"]);
        function d(e, n) {
          let t,
            g = [],
            v = -1;
          for (; ++v < n.children.length; )
            "element" === (t = n.children[v]).type
              ? g.push(
                  (function (e, n, t, p) {
                    var g;
                    let v,
                      x = e.options,
                      y = e.schema,
                      k = n.tagName,
                      b = {};
                    if (
                      ("html" === y.space && "svg" === k && (e.schema = o),
                      n.properties)
                    )
                      for (v in n.properties)
                        f.call(n.properties, v) &&
                          (function (e, n, t, r) {
                            let i = l(r.schema, n),
                              o = t;
                            null != o &&
                              o == o &&
                              (o &&
                                "object" == typeof o &&
                                "length" in o &&
                                (o = (i.commaSeparated ? s : a).stringify(o)),
                              "style" === i.property &&
                                "string" == typeof o &&
                                (o = (function (e) {
                                  let n = {};
                                  try {
                                    c(e, function (e, t) {
                                      n[
                                        ("-ms-" === e.slice(0, 4)
                                          ? `ms-${e.slice(4)}`
                                          : e
                                        ).replace(/-([a-z])/g, m)
                                      ] = t;
                                    });
                                  } catch (e) {}
                                  return n;
                                })(o)),
                              i.space && i.property
                                ? (e[
                                    f.call(u, i.property)
                                      ? u[i.property]
                                      : i.property
                                  ] = o)
                                : i.attribute && (e[i.attribute] = o));
                          })(b, v, n.properties[v], e);
                    ("ol" === k || "ul" === k) && e.listDepth++;
                    let S = d(e, n);
                    ("ol" === k || "ul" === k) && e.listDepth--, (e.schema = y);
                    let w = n.position || {
                        start: { line: null, column: null, offset: null },
                        end: { line: null, column: null, offset: null },
                      },
                      E =
                        x.components && f.call(x.components, k)
                          ? x.components[k]
                          : k,
                      C = "string" == typeof E || E === r.Fragment;
                    if (!i.isValidElementType(E))
                      throw TypeError(
                        `Component for name \`${k}\` not defined or is not renderable`
                      );
                    if (
                      ((b.key = [k, w.start.line, w.start.column, t].join("-")),
                      "a" === k &&
                        x.linkTarget &&
                        (b.target =
                          "function" == typeof x.linkTarget
                            ? x.linkTarget(b.href, n.children, b.title)
                            : x.linkTarget),
                      "a" === k &&
                        x.transformLinkUri &&
                        (b.href = x.transformLinkUri(
                          b.href,
                          n.children,
                          b.title
                        )),
                      C ||
                        "code" !== k ||
                        "element" !== p.type ||
                        "pre" === p.tagName ||
                        (b.inline = !0),
                      C ||
                        ("h1" !== k &&
                          "h2" !== k &&
                          "h3" !== k &&
                          "h4" !== k &&
                          "h5" !== k &&
                          "h6" !== k) ||
                        (b.level = parseInt(k.charAt(1), 10)),
                      "img" === k &&
                        x.transformImageUri &&
                        (b.src = x.transformImageUri(b.src, b.alt, b.title)),
                      !C && "li" === k && "element" === p.type)
                    ) {
                      let e = (function (e) {
                        let n = -1;
                        for (; ++n < e.children.length; ) {
                          let t = e.children[n];
                          if ("element" === t.type && "input" === t.tagName)
                            return t;
                        }
                        return null;
                      })(n);
                      (b.checked =
                        e && e.properties ? !!e.properties.checked : null),
                        (b.index = h(p, n)),
                        (b.ordered = "ol" === p.tagName);
                    }
                    return (
                      C ||
                        ("ol" !== k && "ul" !== k) ||
                        ((b.ordered = "ol" === k), (b.depth = e.listDepth)),
                      ("td" === k || "th" === k) &&
                        (b.align &&
                          (b.style || (b.style = {}),
                          (b.style.textAlign = b.align),
                          delete b.align),
                        C || (b.isHeader = "th" === k)),
                      C ||
                        "tr" !== k ||
                        "element" !== p.type ||
                        (b.isHeader = "thead" === p.tagName),
                      x.sourcePos &&
                        (b["data-sourcepos"] = [
                          (g = w).start.line,
                          ":",
                          g.start.column,
                          "-",
                          g.end.line,
                          ":",
                          g.end.column,
                        ]
                          .map((e) => String(e))
                          .join("")),
                      !C && x.rawSourcePos && (b.sourcePosition = n.position),
                      !C &&
                        x.includeElementIndex &&
                        ((b.index = h(p, n)), (b.siblingCount = h(p))),
                      C || (b.node = n),
                      S.length > 0
                        ? r.createElement(E, b, S)
                        : r.createElement(E, b)
                    );
                  })(e, t, v, n)
                )
              : "text" === t.type
              ? ("element" === n.type &&
                  p.has(n.tagName) &&
                  "\n" === t.value) ||
                g.push(t.value)
              : "raw" !== t.type || e.options.skipHtml || g.push(t.value);
          return g;
        }
        function h(e, n) {
          let t = -1,
            r = 0;
          for (; ++t < e.children.length && e.children[t] !== n; )
            "element" === e.children[t].type && r++;
          return r;
        }
        function m(e, n) {
          return n.toUpperCase();
        }
      },
      69397: (e, n, t) => {
        "use strict";
        var r = t(27954),
          i = t(40148),
          o = t(148);
        e.exports = function (e) {
          for (var n = {}, t = -1; ++t < e.length; )
            !(function (e, n) {
              var t, l, u, a;
              for (t in n)
                for (a in ((l = r.call(e, t) ? e[t] : (e[t] = {})), (u = n[t])))
                  l[a] = (function (e, n) {
                    for (var t = -1, r = []; ++t < e.length; )
                      ("after" === e[t].add ? n : r).push(e[t]);
                    return i(n, 0, 0, r), n;
                  })(o(u[a]), r.call(l, a) ? l[a] : []);
            })(n, e[t]);
          return n;
        };
      },
      69921: (e) => {
        "use strict";
        e.exports = function (e, n, t) {
          var r;
          return (
            null == t &&
              ("object" != typeof n || Array.isArray(n)) &&
              ((t = n), (n = {})),
            (r = Object.assign({ type: String(e) }, n)),
            Array.isArray(t)
              ? (r.children = t)
              : null != t && (r.value = String(t)),
            r
          );
        };
      },
      70158: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          var t,
            o = e.definition(n.identifier);
          return o
            ? ((t = { src: r(o.url || ""), alt: n.alt }),
              null !== o.title && void 0 !== o.title && (t.title = o.title),
              e(n, "img", t))
            : i(e, n);
        };
        var r = t(37910),
          i = t(27371);
      },
      70955: (e, n, t) => {
        "use strict";
        var r = t(57301),
          i = t(75124),
          o = t(52929);
        e.exports = function (e) {
          return null === e || r(e) || o(e) ? 1 : i(e) ? 2 : void 0;
        };
      },
      70961: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          return e(n, "h" + n.depth, r(e, n));
        };
        var r = t(73684);
      },
      71372: (e, n, t) => {
        "use strict";
        Object.defineProperty(n, "__esModule", { value: !0 });
        var r = t(77272),
          i = t(24969),
          o = t(48335),
          l = {
            tokenize: function (e, n, t) {
              return i(
                e,
                e.attempt(this.parser.constructs.document, n, t),
                "linePrefix",
                this.parser.constructs.disable.null.indexOf("codeIndented") > -1
                  ? void 0
                  : 4
              );
            },
          },
          u = {
            tokenize: function (e, n, t) {
              return i(
                e,
                e.lazy(this.parser.constructs.flow, n, t),
                "linePrefix",
                this.parser.constructs.disable.null.indexOf("codeIndented") > -1
                  ? void 0
                  : 4
              );
            },
          };
        n.tokenize = function (e) {
          var n,
            t,
            i,
            a = this,
            s = [],
            c = 0,
            f = {
              tokenize: function (e, r) {
                var i = 0;
                return (n = {}), c;
                function c(r) {
                  return i < s.length
                    ? ((a.containerState = s[i][1]),
                      e.attempt(s[i][0].continuation, f, p)(r))
                    : t.currentConstruct && t.currentConstruct.concrete
                    ? ((n.flowContinue = !0), m(r))
                    : ((a.interrupt =
                        t.currentConstruct && t.currentConstruct.interruptible),
                      (a.containerState = {}),
                      e.attempt(l, h, m)(r));
                }
                function f(e) {
                  return i++, a.containerState._closeFlow ? h(e) : c(e);
                }
                function p(n) {
                  return t.currentConstruct && t.currentConstruct.lazy
                    ? ((a.containerState = {}),
                      e.attempt(l, h, e.attempt(u, h, e.check(o, h, d)))(n))
                    : h(n);
                }
                function d(e) {
                  return (
                    (i = s.length), (n.lazy = !0), (n.flowContinue = !0), m(e)
                  );
                }
                function h(e) {
                  return (n.flowEnd = !0), m(e);
                }
                function m(e) {
                  return (
                    (n.continued = i),
                    (a.interrupt = a.containerState = void 0),
                    r(e)
                  );
                }
              },
              partial: !0,
            };
          return p;
          function p(n) {
            return c < s.length
              ? ((a.containerState = s[c][1]),
                e.attempt(s[c][0].continuation, d, h)(n))
              : h(n);
          }
          function d(e) {
            return c++, p(e);
          }
          function h(r) {
            return n && n.flowContinue
              ? g(r)
              : ((a.interrupt =
                  t && t.currentConstruct && t.currentConstruct.interruptible),
                (a.containerState = {}),
                e.attempt(l, m, g)(r));
          }
          function m(e) {
            return (
              s.push([a.currentConstruct, a.containerState]),
              (a.containerState = void 0),
              h(e)
            );
          }
          function g(n) {
            if (null === n) {
              y(0, !0), e.consume(n);
              return;
            }
            return (
              (t = t || a.parser.flow(a.now())),
              e.enter("chunkFlow", {
                contentType: "flow",
                previous: i,
                _tokenizer: t,
              }),
              (function n(t) {
                return null === t
                  ? (x(e.exit("chunkFlow")), g(t))
                  : r(t)
                  ? (e.consume(t), x(e.exit("chunkFlow")), e.check(f, v))
                  : (e.consume(t), n);
              })(n)
            );
          }
          function v(e) {
            return y(n.continued, n && n.flowEnd), (c = 0), p(e);
          }
          function x(e) {
            i && (i.next = e),
              (i = e),
              (t.lazy = n && n.lazy),
              t.defineSkip(e.start),
              t.write(a.sliceStream(e));
          }
          function y(n, r) {
            var o = s.length;
            for (t && r && (t.write([null]), (i = t = void 0)); o-- > n; )
              (a.containerState = s[o][1]), s[o][0].exit.call(a, e);
            s.length = n;
          }
        };
      },
      72295: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          for (
            var t,
              l,
              u,
              a,
              s,
              c = n.children,
              f = c.length,
              p = n.align || [],
              d = p.length,
              h = [];
            f--;

          ) {
            for (
              l = c[f].children,
                a = 0 === f ? "th" : "td",
                t = d || l.length,
                u = [];
              t--;

            )
              (s = l[t]), (u[t] = e(s, a, { align: p[t] }, s ? o(e, s) : []));
            h[f] = e(c[f], "tr", i(u, !0));
          }
          return e(
            n,
            "table",
            i(
              [e(h[0].position, "thead", i([h[0]], !0))].concat(
                h[1]
                  ? e(
                      { start: r.start(h[1]), end: r.end(h[h.length - 1]) },
                      "tbody",
                      i(h.slice(1), !0)
                    )
                  : []
              ),
              !0
            )
          );
        };
        var r = t(42370),
          i = t(12721),
          o = t(73684);
      },
      72674: (e, n, t) => {
        "use strict";
        Object.defineProperty(n, "__esModule", { value: !0 });
        var r = t(77272),
          i = t(24969);
        n.tokenize = function (e) {
          var n,
            t = e.attempt(
              this.parser.constructs.contentInitial,
              function (n) {
                return null === n
                  ? void e.consume(n)
                  : (e.enter("lineEnding"),
                    e.consume(n),
                    e.exit("lineEnding"),
                    i(e, t, "linePrefix"));
              },
              function (t) {
                return (
                  e.enter("paragraph"),
                  (function t(i) {
                    var o = e.enter("chunkText", {
                      contentType: "text",
                      previous: n,
                    });
                    return (
                      n && (n.next = o),
                      (n = o),
                      (function n(i) {
                        if (null === i) {
                          e.exit("chunkText"),
                            e.exit("paragraph"),
                            e.consume(i);
                          return;
                        }
                        return r(i)
                          ? (e.consume(i), e.exit("chunkText"), t)
                          : (e.consume(i), n);
                      })(i)
                    );
                  })(t)
                );
              }
            );
          return t;
        };
      },
      72801: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          return e(n, "p", r(e, n));
        };
        var r = t(73684);
      },
      73349: (e) => {
        "use strict";
        e.exports = function (e, n) {
          return (e.column += n), (e.offset += n), (e._bufferIndex += n), e;
        };
      },
      73460: (e, n, t) => {
        "use strict";
        var r = t(22552),
          i = t(24969),
          o = {
            name: "blockQuote",
            tokenize: function (e, n, t) {
              var i = this;
              return function (n) {
                return 62 === n
                  ? (i.containerState.open ||
                      (e.enter("blockQuote", { _container: !0 }),
                      (i.containerState.open = !0)),
                    e.enter("blockQuotePrefix"),
                    e.enter("blockQuoteMarker"),
                    e.consume(n),
                    e.exit("blockQuoteMarker"),
                    o)
                  : t(n);
              };
              function o(t) {
                return r(t)
                  ? (e.enter("blockQuotePrefixWhitespace"),
                    e.consume(t),
                    e.exit("blockQuotePrefixWhitespace"),
                    e.exit("blockQuotePrefix"),
                    n)
                  : (e.exit("blockQuotePrefix"), n(t));
              }
            },
            continuation: {
              tokenize: function (e, n, t) {
                return i(
                  e,
                  e.attempt(o, n, t),
                  "linePrefix",
                  this.parser.constructs.disable.null.indexOf("codeIndented") >
                    -1
                    ? void 0
                    : 4
                );
              },
            },
            exit: function (e) {
              e.exit("blockQuote");
            },
          };
        e.exports = o;
      },
      73684: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          for (
            var t, i, o = n.children || [], l = o.length, u = [], a = -1;
            ++a < l;

          )
            (t = r(e, o[a], n)) &&
              (a &&
                "break" === o[a - 1].type &&
                (t.value && (t.value = t.value.replace(/^\s+/, "")),
                (i = t.children && t.children[0]) &&
                  i.value &&
                  (i.value = i.value.replace(/^\s+/, ""))),
              (u = u.concat(t)));
          return u;
        };
        var r = t(6495);
      },
      74058: (e, n, t) => {
        "use strict";
        var r = t(47383);
        e.exports = function (e, n) {
          return r(e, n.toLowerCase());
        };
      },
      74503: (e, n, t) => {
        "use strict";
        var r = t(77272);
        e.exports = {
          name: "codeText",
          tokenize: function (e, n, t) {
            var i,
              o,
              l = 0;
            return function (n) {
              return (
                e.enter("codeText"),
                e.enter("codeTextSequence"),
                (function n(t) {
                  return 96 === t
                    ? (e.consume(t), l++, n)
                    : (e.exit("codeTextSequence"), u(t));
                })(n)
              );
            };
            function u(s) {
              return null === s
                ? t(s)
                : 96 === s
                ? ((o = e.enter("codeTextSequence")),
                  (i = 0),
                  (function t(r) {
                    return 96 === r
                      ? (e.consume(r), i++, t)
                      : i === l
                      ? (e.exit("codeTextSequence"), e.exit("codeText"), n(r))
                      : ((o.type = "codeTextData"), a(r));
                  })(s))
                : 32 === s
                ? (e.enter("space"), e.consume(s), e.exit("space"), u)
                : r(s)
                ? (e.enter("lineEnding"), e.consume(s), e.exit("lineEnding"), u)
                : (e.enter("codeTextData"), a(s));
            }
            function a(n) {
              return null === n || 32 === n || 96 === n || r(n)
                ? (e.exit("codeTextData"), u(n))
                : (e.consume(n), a);
            }
          },
          resolve: function (e) {
            var n,
              t,
              r = e.length - 4,
              i = 3;
            if (
              ("lineEnding" === e[3][1].type || "space" === e[i][1].type) &&
              ("lineEnding" === e[r][1].type || "space" === e[r][1].type)
            ) {
              for (n = i; ++n < r; )
                if ("codeTextData" === e[n][1].type) {
                  (e[r][1].type = e[i][1].type = "codeTextPadding"),
                    (i += 2),
                    (r -= 2);
                  break;
                }
            }
            for (n = i - 1, r++; ++n <= r; )
              void 0 === t
                ? n !== r && "lineEnding" !== e[n][1].type && (t = n)
                : (n === r || "lineEnding" === e[n][1].type) &&
                  ((e[t][1].type = "codeTextData"),
                  n !== t + 2 &&
                    ((e[t][1].end = e[n - 1][1].end),
                    e.splice(t + 2, n - t - 2),
                    (r -= n - t - 2),
                    (n = t + 2)),
                  (t = void 0));
            return e;
          },
          previous: function (e) {
            return (
              96 !== e ||
              "characterEscape" === this.events[this.events.length - 1][1].type
            );
          },
        };
      },
      74788: (e, n, t) => {
        let r = t(25842);
        e.exports = function (e) {
          if (e.allowedElements && e.disallowedElements)
            throw TypeError(
              "Only one of `allowedElements` and `disallowedElements` should be defined"
            );
          if (e.allowedElements || e.disallowedElements || e.allowElement)
            return (e) => {
              r(e, "element", n);
            };
          function n(n, t, r) {
            let i;
            if (
              (e.allowedElements
                ? (i = !e.allowedElements.includes(n.tagName))
                : e.disallowedElements &&
                  (i = e.disallowedElements.includes(n.tagName)),
              !i &&
                e.allowElement &&
                "number" == typeof t &&
                (i = !e.allowElement(n, t, r)),
              i && "number" == typeof t)
            )
              return (
                e.unwrapDisallowed && n.children
                  ? r.children.splice(t, 1, ...n.children)
                  : r.children.splice(t, 1),
                t
              );
          }
        };
      },
      75031: (e) => {
        e.exports = function () {
          for (var e = {}, t = 0; t < arguments.length; t++) {
            var r = arguments[t];
            for (var i in r) n.call(r, i) && (e[i] = r[i]);
          }
          return e;
        };
        var n = Object.prototype.hasOwnProperty;
      },
      75124: (e, n, t) => {
        "use strict";
        var r = t(60049);
        e.exports = t(39427)(r);
      },
      75646: (e, n, t) => {
        "use strict";
        var r = t(52334),
          i = t(40148),
          o = t(16525);
        e.exports = function (e) {
          for (var n, t, l, u, a, s, c, f = {}, p = -1; ++p < e.length; ) {
            for (; p in f; ) p = f[p];
            if (
              ((n = e[p]),
              p &&
                "chunkFlow" === n[1].type &&
                "listItemPrefix" === e[p - 1][1].type &&
                ((l = 0) < (s = n[1]._tokenizer.events).length &&
                  "lineEndingBlank" === s[l][1].type &&
                  (l += 2),
                l < s.length && "content" === s[l][1].type))
            )
              for (; ++l < s.length && "content" !== s[l][1].type; )
                "chunkText" === s[l][1].type &&
                  ((s[l][1].isInFirstContentOfListItem = !0), l++);
            if ("enter" === n[0])
              n[1].contentType &&
                (r(
                  f,
                  (function (e, n) {
                    for (
                      var t,
                        r,
                        o,
                        l,
                        u,
                        a,
                        s = e[n][1],
                        c = e[n][2],
                        f = n - 1,
                        p = [],
                        d = s._tokenizer || c.parser[s.contentType](s.start),
                        h = d.events,
                        m = [],
                        g = {};
                      s;

                    ) {
                      for (; e[++f][1] !== s; );
                      p.push(f),
                        !s._tokenizer &&
                          ((t = c.sliceStream(s)),
                          s.next || t.push(null),
                          r && d.defineSkip(s.start),
                          s.isInFirstContentOfListItem &&
                            (d._gfmTasklistFirstContentOfListItem = !0),
                          d.write(t),
                          s.isInFirstContentOfListItem &&
                            (d._gfmTasklistFirstContentOfListItem = void 0)),
                        (r = s),
                        (s = s.next);
                    }
                    for (s = r, o = h.length; o--; )
                      "enter" === h[o][0]
                        ? (l = !0)
                        : l &&
                          h[o][1].type === h[o - 1][1].type &&
                          h[o][1].start.line !== h[o][1].end.line &&
                          (v(h.slice(o + 1, u)),
                          (s._tokenizer = s.next = void 0),
                          (s = s.previous),
                          (u = o + 1));
                    for (
                      d.events = s._tokenizer = s.next = void 0,
                        v(h.slice(0, u)),
                        o = -1,
                        a = 0;
                      ++o < m.length;

                    )
                      (g[a + m[o][0]] = a + m[o][1]),
                        (a += m[o][1] - m[o][0] - 1);
                    return g;
                    function v(n) {
                      var t = p.pop();
                      m.unshift([t, t + n.length - 1]), i(e, t, 2, n);
                    }
                  })(e, p)
                ),
                (p = f[p]),
                (c = !0));
            else if (n[1]._container || n[1]._movePreviousLineEndings) {
              for (l = p, t = void 0; l--; )
                if (
                  "lineEnding" === (u = e[l])[1].type ||
                  "lineEndingBlank" === u[1].type
                )
                  "enter" === u[0] &&
                    (t && (e[t][1].type = "lineEndingBlank"),
                    (u[1].type = "lineEnding"),
                    (t = l));
                else break;
              t &&
                ((n[1].end = o(e[t][1].start)),
                (a = e.slice(t, p)).unshift(n),
                i(e, t, p - t + 1, a));
            }
          }
          return !c;
        };
      },
      76818: (e, n, t) => {
        "use strict";
        e.exports = l;
        var r = t(53322),
          i = t(43935),
          o = "skip";
        function l(e, n, t, l) {
          var u, a;
          "function" == typeof n &&
            "function" != typeof t &&
            ((l = t), (t = n), (n = null)),
            (a = r(n)),
            (u = l ? -1 : 1),
            (function e(r, s, c) {
              var f,
                p = "object" == typeof r && null !== r ? r : {};
              return (
                "string" == typeof p.type &&
                  ((f =
                    "string" == typeof p.tagName
                      ? p.tagName
                      : "string" == typeof p.name
                      ? p.name
                      : void 0),
                  (d.displayName =
                    "node (" + i(p.type + (f ? "<" + f + ">" : "")) + ")")),
                d
              );
              function d() {
                var i,
                  f,
                  p,
                  d = c.concat(r),
                  h = [];
                if (
                  (!n || a(r, s, c[c.length - 1] || null)) &&
                  !1 ===
                    (h =
                      null !== (i = t(r, c)) &&
                      "object" == typeof i &&
                      "length" in i
                        ? i
                        : "number" == typeof i
                        ? [!0, i]
                        : [i])[0]
                )
                  return h;
                if (r.children && h[0] !== o)
                  for (
                    p = (l ? r.children.length : -1) + u;
                    p > -1 && p < r.children.length;

                  ) {
                    if (!1 === (f = e(r.children[p], p, d)())[0]) return f;
                    p = "number" == typeof f[1] ? f[1] : p + u;
                  }
                return h;
              }
            })(e, null, [])();
        }
        (l.CONTINUE = !0), (l.SKIP = o), (l.EXIT = !1);
      },
      76932: (e, n, t) => {
        "use strict";
        var r = t(46665),
          i = t(6694);
        e.exports = r([t(85999), i, t(98920), t(42419), t(66404)]);
      },
      77144: (e, n, t) => {
        "use strict";
        e.exports = t(39427)(/[A-Za-z]/);
      },
      77272: (e) => {
        "use strict";
        e.exports = function (e) {
          return e < -2;
        };
      },
      77858: (e, n, t) => {
        "use strict";
        var r = t(37910);
        e.exports = function (e, n) {
          var t = { src: r(n.url), alt: n.alt };
          return (
            null !== n.title && void 0 !== n.title && (t.title = n.title),
            e(n, "img", t)
          );
        };
      },
      78712: (e, n, t) => {
        "use strict";
        var r = t(39115);
        e.exports = function (e, n) {
          var t, i, o;
          return (
            e && !e.process && ((n = e), (e = null)),
            e
              ? ((t = e),
                (i = n),
                function (e, n, o) {
                  t.run(r(e, i), n, function (e) {
                    o(e);
                  });
                })
              : ((o = n),
                function (e) {
                  return r(e, o);
                })
          );
        };
      },
      80582: (e) => {
        "use strict";
        function n(e) {
          return (
            (e &&
              (e.value ||
                e.alt ||
                e.title ||
                ("children" in e && t(e.children)) ||
                ("length" in e && t(e)))) ||
            ""
          );
        }
        function t(e) {
          for (var t = [], r = -1; ++r < e.length; ) t[r] = n(e[r]);
          return t.join("");
        }
        e.exports = n;
      },
      83435: (e, n, t) => {
        "use strict";
        var r = t(77144),
          i = t(85683),
          o = t(83912),
          l = t(27797);
        e.exports = {
          name: "autolink",
          tokenize: function (e, n, t) {
            var u = 1;
            return function (n) {
              return (
                e.enter("autolink"),
                e.enter("autolinkMarker"),
                e.consume(n),
                e.exit("autolinkMarker"),
                e.enter("autolinkProtocol"),
                a
              );
            };
            function a(n) {
              return r(n) ? (e.consume(n), s) : o(n) ? f(n) : t(n);
            }
            function s(n) {
              return 43 === n || 45 === n || 46 === n || i(n)
                ? (function n(t) {
                    return 58 === t
                      ? (e.consume(t), c)
                      : (43 === t || 45 === t || 46 === t || i(t)) && u++ < 32
                      ? (e.consume(t), n)
                      : f(t);
                  })(n)
                : f(n);
            }
            function c(n) {
              return 62 === n
                ? (e.exit("autolinkProtocol"), d(n))
                : 32 === n || 60 === n || l(n)
                ? t(n)
                : (e.consume(n), c);
            }
            function f(n) {
              return 64 === n
                ? (e.consume(n), (u = 0), p)
                : o(n)
                ? (e.consume(n), f)
                : t(n);
            }
            function p(n) {
              return i(n)
                ? (function n(r) {
                    return 46 === r
                      ? (e.consume(r), (u = 0), p)
                      : 62 === r
                      ? ((e.exit("autolinkProtocol").type = "autolinkEmail"),
                        d(r))
                      : (function r(o) {
                          return (45 === o || i(o)) && u++ < 63
                            ? (e.consume(o), 45 === o ? r : n)
                            : t(o);
                        })(r);
                  })(n)
                : t(n);
            }
            function d(t) {
              return (
                e.enter("autolinkMarker"),
                e.consume(t),
                e.exit("autolinkMarker"),
                e.exit("autolink"),
                n
              );
            }
          },
        };
      },
      83912: (e, n, t) => {
        "use strict";
        e.exports = t(39427)(/[#-'*+\--9=?A-Z^-~]/);
      },
      84029: (e, n, t) => {
        "use strict";
        e.exports = t(39427)(/\d/);
      },
      84181: (e, n, t) => {
        "use strict";
        var r = t(77272),
          i = t(96143),
          o = t(75646),
          l = t(24969),
          u = {
            tokenize: function (e, n, t) {
              var o = this;
              return function (n) {
                return (
                  e.enter("lineEnding"),
                  e.consume(n),
                  e.exit("lineEnding"),
                  l(e, u, "linePrefix")
                );
              };
              function u(l) {
                return null === l || r(l)
                  ? t(l)
                  : o.parser.constructs.disable.null.indexOf("codeIndented") >
                      -1 || 4 > i(o.events, "linePrefix")
                  ? e.interrupt(o.parser.constructs.flow, t, n)(l)
                  : n(l);
              }
            },
            partial: !0,
          };
        e.exports = {
          tokenize: function (e, n) {
            var t;
            return function (n) {
              return (
                e.enter("content"),
                (t = e.enter("chunkContent", { contentType: "content" })),
                i(n)
              );
            };
            function i(n) {
              return null === n
                ? o(n)
                : r(n)
                ? e.check(u, l, o)(n)
                : (e.consume(n), i);
            }
            function o(t) {
              return e.exit("chunkContent"), e.exit("content"), n(t);
            }
            function l(n) {
              return (
                e.consume(n),
                e.exit("chunkContent"),
                (t = t.next =
                  e.enter("chunkContent", {
                    contentType: "content",
                    previous: t,
                  })),
                i
              );
            }
          },
          resolve: function (e) {
            return o(e), e;
          },
          interruptible: !0,
          lazy: !0,
        };
      },
      85683: (e, n, t) => {
        "use strict";
        e.exports = t(39427)(/[\dA-Za-z]/);
      },
      85999: (e, n, t) => {
        "use strict";
        e.exports = t(46399)({
          space: "xml",
          transform: function (e, n) {
            return "xml:" + n.slice(3).toLowerCase();
          },
          properties: { xmlLang: null, xmlBase: null, xmlSpace: null },
        });
      },
      87042: (e, n, t) => {
        "use strict";
        e.exports = function (e) {
          var n = this;
          this.Parser = function (t) {
            return r(
              t,
              Object.assign({}, n.data("settings"), e, {
                extensions: n.data("micromarkExtensions") || [],
                mdastExtensions: n.data("fromMarkdownExtensions") || [],
              })
            );
          };
        };
        var r = t(64733);
      },
      87102: (e, n, t) => {
        "use strict";
        e.exports = function (e) {
          for (
            var n,
              t,
              l,
              u,
              a = e.footnoteById,
              s = e.footnoteOrder,
              c = s.length,
              f = -1,
              p = [];
            ++f < c;

          )
            (n = a[s[f].toUpperCase()]) &&
              ((u = (l = n.children.concat())[l.length - 1]),
              (t = {
                type: "link",
                url: "#fnref-" + n.identifier,
                data: { hProperties: { className: ["footnote-backref"] } },
                children: [{ type: "text", value: "↩" }],
              }),
              (u && "paragraph" === u.type) ||
                ((u = { type: "paragraph", children: [] }), l.push(u)),
              u.children.push(t),
              p.push({
                type: "listItem",
                data: { hProperties: { id: "fn-" + n.identifier } },
                children: l,
                position: n.position,
              }));
          return 0 === p.length
            ? null
            : e(
                null,
                "div",
                { className: ["footnotes"] },
                o([r(e), i(e, { type: "list", ordered: !0, children: p })], !0)
              );
        };
        var r = t(36256),
          i = t(93469),
          o = t(12721);
      },
      87604: (e, n, t) => {
        "use strict";
        var r = t(77272),
          i = t(57301),
          o = t(22552),
          l = t(40148),
          u = t(24969);
        e.exports = {
          name: "headingAtx",
          tokenize: function (e, n, t) {
            var l = this,
              a = 0;
            return function (s) {
              return (
                e.enter("atxHeading"),
                e.enter("atxHeadingSequence"),
                (function s(c) {
                  return 35 === c && a++ < 6
                    ? (e.consume(c), s)
                    : null === c || i(c)
                    ? (e.exit("atxHeadingSequence"),
                      l.interrupt
                        ? n(c)
                        : (function t(l) {
                            return 35 === l
                              ? (e.enter("atxHeadingSequence"),
                                (function n(r) {
                                  return 35 === r
                                    ? (e.consume(r), n)
                                    : (e.exit("atxHeadingSequence"), t(r));
                                })(l))
                              : null === l || r(l)
                              ? (e.exit("atxHeading"), n(l))
                              : o(l)
                              ? u(e, t, "whitespace")(l)
                              : (e.enter("atxHeadingText"),
                                (function n(r) {
                                  return null === r || 35 === r || i(r)
                                    ? (e.exit("atxHeadingText"), t(r))
                                    : (e.consume(r), n);
                                })(l));
                          })(c))
                    : t(c);
                })(s)
              );
            };
          },
          resolve: function (e, n) {
            var t,
              r,
              i = e.length - 2,
              o = 3;
            return (
              "whitespace" === e[3][1].type && (o += 2),
              i - 2 > o && "whitespace" === e[i][1].type && (i -= 2),
              "atxHeadingSequence" === e[i][1].type &&
                (o === i - 1 ||
                  (i - 4 > o && "whitespace" === e[i - 2][1].type)) &&
                (i -= o + 1 === i ? 2 : 4),
              i > o &&
                ((t = {
                  type: "atxHeadingText",
                  start: e[o][1].start,
                  end: e[i][1].end,
                }),
                (r = {
                  type: "chunkText",
                  start: e[o][1].start,
                  end: e[i][1].end,
                  contentType: "text",
                }),
                l(e, o, i - o + 1, [
                  ["enter", t, n],
                  ["enter", r, n],
                  ["exit", r, n],
                  ["exit", t, n],
                ])),
              e
            );
          },
        };
      },
      87905: (e, n, t) => {
        "use strict";
        var r = t(51495),
          i = t(25468),
          o = t(40285);
        e.exports = a;
        var l = {}.hasOwnProperty,
          u = ["history", "path", "basename", "stem", "extname", "dirname"];
        function a(e) {
          var n, t;
          if (e) {
            if ("string" == typeof e || o(e)) e = { contents: e };
            else if ("message" in e && "messages" in e) return e;
          } else e = {};
          if (!(this instanceof a)) return new a(e);
          for (
            this.data = {},
              this.messages = [],
              this.history = [],
              this.cwd = i.cwd(),
              t = -1;
            ++t < u.length;

          )
            (n = u[t]), l.call(e, n) && (this[n] = e[n]);
          for (n in e) 0 > u.indexOf(n) && (this[n] = e[n]);
        }
        function s(e, n) {
          if (e && e.indexOf(r.sep) > -1)
            throw Error(
              "`" + n + "` cannot be a path: did not expect `" + r.sep + "`"
            );
        }
        function c(e, n) {
          if (!e) throw Error("`" + n + "` cannot be empty");
        }
        function f(e, n) {
          if (!e)
            throw Error("Setting `" + n + "` requires `path` to be set too");
        }
        (a.prototype.toString = function (e) {
          return (this.contents || "").toString(e);
        }),
          Object.defineProperty(a.prototype, "path", {
            get: function () {
              return this.history[this.history.length - 1];
            },
            set: function (e) {
              c(e, "path"), this.path !== e && this.history.push(e);
            },
          }),
          Object.defineProperty(a.prototype, "dirname", {
            get: function () {
              return "string" == typeof this.path
                ? r.dirname(this.path)
                : void 0;
            },
            set: function (e) {
              f(this.path, "dirname"),
                (this.path = r.join(e || "", this.basename));
            },
          }),
          Object.defineProperty(a.prototype, "basename", {
            get: function () {
              return "string" == typeof this.path
                ? r.basename(this.path)
                : void 0;
            },
            set: function (e) {
              c(e, "basename"),
                s(e, "basename"),
                (this.path = r.join(this.dirname || "", e));
            },
          }),
          Object.defineProperty(a.prototype, "extname", {
            get: function () {
              return "string" == typeof this.path
                ? r.extname(this.path)
                : void 0;
            },
            set: function (e) {
              if ((s(e, "extname"), f(this.path, "extname"), e)) {
                if (46 !== e.charCodeAt(0))
                  throw Error("`extname` must start with `.`");
                if (e.indexOf(".", 1) > -1)
                  throw Error("`extname` cannot contain multiple dots");
              }
              this.path = r.join(this.dirname, this.stem + (e || ""));
            },
          }),
          Object.defineProperty(a.prototype, "stem", {
            get: function () {
              return "string" == typeof this.path
                ? r.basename(this.path, this.extname)
                : void 0;
            },
            set: function (e) {
              c(e, "stem"),
                s(e, "stem"),
                (this.path = r.join(
                  this.dirname || "",
                  e + (this.extname || "")
                ));
            },
          });
      },
      89493: (e, n, t) => {
        "use strict";
        var r = t(75646);
        e.exports = function (e) {
          for (; !r(e); );
          return e;
        };
      },
      89779: (e) => {
        "use strict";
        e.exports = function (e) {
          for (var n = -1, t = 0; ++n < e.length; )
            t += "string" == typeof e[n] ? e[n].length : 1;
          return t;
        };
      },
      90641: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          var t = e.footnoteOrder,
            i = String(n.identifier);
          return (
            -1 === t.indexOf(i) && t.push(i),
            e(n.position, "sup", { id: "fnref-" + i }, [
              e(n, "a", { href: "#fn-" + i, className: ["footnote-ref"] }, [
                r("text", n.label || i),
              ]),
            ])
          );
        };
        var r = t(69921);
      },
      91129: (e, n, t) => {
        var r = t(93409);
        e.exports = function (e, n) {
          var t,
            i,
            o,
            l = null;
          if (!e || "string" != typeof e) return l;
          for (
            var u = r(e), a = "function" == typeof n, s = 0, c = u.length;
            s < c;
            s++
          )
            (i = (t = u[s]).property),
              (o = t.value),
              a ? n(i, o, t) : o && (l || (l = {}), (l[i] = o));
          return l;
        };
      },
      91534: (e, n, t) => {
        "use strict";
        var r = t(24969);
        e.exports = {
          name: "lineEnding",
          tokenize: function (e, n) {
            return function (t) {
              return (
                e.enter("lineEnding"),
                e.consume(t),
                e.exit("lineEnding"),
                r(e, n, "linePrefix")
              );
            };
          },
        };
      },
      91815: (e) => {
        "use strict";
        e.exports = t;
        var n = t.prototype;
        function t(e, n) {
          (this.property = e), (this.attribute = n);
        }
        (n.space = null),
          (n.attribute = null),
          (n.property = null),
          (n.boolean = !1),
          (n.booleanish = !1),
          (n.overloadedBoolean = !1),
          (n.number = !1),
          (n.commaSeparated = !1),
          (n.spaceSeparated = !1),
          (n.commaOrSpaceSeparated = !1),
          (n.mustUseProperty = !1),
          (n.defined = !1);
      },
      92629: (e, n, t) => {
        "use strict";
        var r = t(66572);
        e.exports = {
          name: "characterEscape",
          tokenize: function (e, n, t) {
            return function (n) {
              return (
                e.enter("characterEscape"),
                e.enter("escapeMarker"),
                e.consume(n),
                e.exit("escapeMarker"),
                i
              );
            };
            function i(i) {
              return r(i)
                ? (e.enter("characterEscapeValue"),
                  e.consume(i),
                  e.exit("characterEscapeValue"),
                  e.exit("characterEscape"),
                  n)
                : t(i);
            }
          },
        };
      },
      93409: (e) => {
        var n = /\/\*[^*]*\*+([^/*][^*]*\*+)*\//g,
          t = /\n/g,
          r = /^\s*/,
          i = /^(\*?[-#/*\\\w]+(\[[0-9a-z_-]+\])?)\s*/,
          o = /^:\s*/,
          l = /^((?:'(?:\\'|.)*?'|"(?:\\"|.)*?"|\([^)]*?\)|[^};])+)/,
          u = /^[;\s]*/,
          a = /^\s+|\s+$/g;
        function s(e) {
          return e ? e.replace(a, "") : "";
        }
        e.exports = function (e, a) {
          if ("string" != typeof e)
            throw TypeError("First argument must be a string");
          if (!e) return [];
          a = a || {};
          var c = 1,
            f = 1;
          function p(e) {
            var n = e.match(t);
            n && (c += n.length);
            var r = e.lastIndexOf("\n");
            f = ~r ? e.length - r : f + e.length;
          }
          function d() {
            var e = { line: c, column: f };
            return function (n) {
              return (n.position = new h(e)), v(r), n;
            };
          }
          function h(e) {
            (this.start = e),
              (this.end = { line: c, column: f }),
              (this.source = a.source);
          }
          h.prototype.content = e;
          var m = [];
          function g(n) {
            var t = Error(a.source + ":" + c + ":" + f + ": " + n);
            if (
              ((t.reason = n),
              (t.filename = a.source),
              (t.line = c),
              (t.column = f),
              (t.source = e),
              a.silent)
            )
              m.push(t);
            else throw t;
          }
          function v(n) {
            var t = n.exec(e);
            if (t) {
              var r = t[0];
              return p(r), (e = e.slice(r.length)), t;
            }
          }
          function x(e) {
            var n;
            for (e = e || []; (n = y()); ) !1 !== n && e.push(n);
            return e;
          }
          function y() {
            var n = d();
            if ("/" == e.charAt(0) && "*" == e.charAt(1)) {
              for (
                var t = 2;
                "" != e.charAt(t) &&
                ("*" != e.charAt(t) || "/" != e.charAt(t + 1));

              )
                ++t;
              if (((t += 2), "" === e.charAt(t - 1)))
                return g("End of comment missing");
              var r = e.slice(2, t - 2);
              return (
                (f += 2),
                p(r),
                (e = e.slice(t)),
                (f += 2),
                n({ type: "comment", comment: r })
              );
            }
          }
          v(r);
          var k,
            b = [];
          for (
            x(b);
            (k = (function () {
              var e = d(),
                t = v(i);
              if (t) {
                if ((y(), !v(o))) return g("property missing ':'");
                var r = v(l),
                  a = e({
                    type: "declaration",
                    property: s(t[0].replace(n, "")),
                    value: r ? s(r[0].replace(n, "")) : "",
                  });
                return v(u), a;
              }
            })());

          )
            !1 !== k && (b.push(k), x(b));
          return b;
        };
      },
      93469: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          var t,
            o,
            l = {},
            u = n.ordered ? "ol" : "ul",
            a = -1;
          for (
            "number" == typeof n.start && 1 !== n.start && (l.start = n.start),
              o = (t = i(e, n)).length;
            ++a < o;

          )
            if (
              t[a].properties.className &&
              -1 !== t[a].properties.className.indexOf("task-list-item")
            ) {
              l.className = ["contains-task-list"];
              break;
            }
          return e(n, u, l, r(t, !0));
        };
        var r = t(12721),
          i = t(73684);
      },
      93794: (e, n, t) => {
        "use strict";
        Object.defineProperty(n, "__esModule", { value: !0 });
        var r = t(52334),
          i = t(16525),
          o = u("text"),
          l = u("string");
        function u(e) {
          return {
            tokenize: function (n) {
              var t = this,
                r = this.parser.constructs[e],
                i = n.attempt(r, o, l);
              return o;
              function o(e) {
                return a(e) ? i(e) : l(e);
              }
              function l(e) {
                return null === e
                  ? void n.consume(e)
                  : (n.enter("data"), n.consume(e), u);
              }
              function u(e) {
                return a(e) ? (n.exit("data"), i(e)) : (n.consume(e), u);
              }
              function a(e) {
                var n = r[e],
                  i = -1;
                if (null === e) return !0;
                if (n) {
                  for (; ++i < n.length; )
                    if (!n[i].previous || n[i].previous.call(t, t.previous))
                      return !0;
                }
              }
            },
            resolveAll: a("text" === e ? s : void 0),
          };
        }
        function a(e) {
          return function (n, t) {
            for (var r, i = -1; ++i <= n.length; )
              void 0 === r
                ? n[i] && "data" === n[i][1].type && ((r = i), i++)
                : (n[i] && "data" === n[i][1].type) ||
                  (i !== r + 2 &&
                    ((n[r][1].end = n[i - 1][1].end),
                    n.splice(r + 2, i - r - 2),
                    (i = r + 2)),
                  (r = void 0));
            return e ? e(n, t) : n;
          };
        }
        function s(e, n) {
          for (var t, o, l, u, a, s, c, f, p = -1; ++p <= e.length; )
            if (
              (p === e.length || "lineEnding" === e[p][1].type) &&
              "data" === e[p - 1][1].type
            ) {
              for (
                o = e[p - 1][1],
                  u = (t = n.sliceStream(o)).length,
                  a = -1,
                  s = 0,
                  c = void 0;
                u--;

              )
                if ("string" == typeof (l = t[u])) {
                  for (a = l.length; 32 === l.charCodeAt(a - 1); ) s++, a--;
                  if (a) break;
                  a = -1;
                } else if (-2 === l) (c = !0), s++;
                else if (-1 === l);
                else {
                  u++;
                  break;
                }
              s &&
                ((f = {
                  type:
                    p === e.length || c || s < 2
                      ? "lineSuffix"
                      : "hardBreakTrailing",
                  start: {
                    line: o.end.line,
                    column: o.end.column - s,
                    offset: o.end.offset - s,
                    _index: o.start._index + u,
                    _bufferIndex: u ? a : o.start._bufferIndex + a,
                  },
                  end: i(o.end),
                }),
                (o.end = i(f.start)),
                o.start.offset === o.end.offset
                  ? r(o, f)
                  : (e.splice(p, 0, ["enter", f, n], ["exit", f, n]),
                    (p += 2))),
                p++;
            }
          return e;
        }
        (n.resolver = { resolveAll: a() }), (n.string = l), (n.text = o);
      },
      94397: (e, n, t) => {
        "use strict";
        var r = t(77272),
          i = t(57301),
          o = t(36898),
          l = t(20979),
          u = t(13125),
          a = t(24969),
          s = t(64876),
          c = t(39029),
          f = {
            tokenize: function (e, n, t) {
              return function (n) {
                return i(n) ? s(e, o)(n) : t(n);
              };
              function o(n) {
                return 34 === n || 39 === n || 40 === n
                  ? c(
                      e,
                      a(e, l, "whitespace"),
                      t,
                      "definitionTitle",
                      "definitionTitleMarker",
                      "definitionTitleString"
                    )(n)
                  : t(n);
              }
              function l(e) {
                return null === e || r(e) ? n(e) : t(e);
              }
            },
            partial: !0,
          };
        e.exports = {
          name: "definition",
          tokenize: function (e, n, t) {
            var i,
              c = this;
            return function (n) {
              return (
                e.enter("definition"),
                u.call(
                  c,
                  e,
                  p,
                  t,
                  "definitionLabel",
                  "definitionLabelMarker",
                  "definitionLabelString"
                )(n)
              );
            };
            function p(n) {
              return ((i = o(
                c.sliceSerialize(c.events[c.events.length - 1][1]).slice(1, -1)
              )),
              58 === n)
                ? (e.enter("definitionMarker"),
                  e.consume(n),
                  e.exit("definitionMarker"),
                  s(
                    e,
                    l(
                      e,
                      e.attempt(
                        f,
                        a(e, d, "whitespace"),
                        a(e, d, "whitespace")
                      ),
                      t,
                      "definitionDestination",
                      "definitionDestinationLiteral",
                      "definitionDestinationLiteralMarker",
                      "definitionDestinationRaw",
                      "definitionDestinationString"
                    )
                  ))
                : t(n);
            }
            function d(o) {
              return null === o || r(o)
                ? (e.exit("definition"),
                  0 > c.parser.defined.indexOf(i) && c.parser.defined.push(i),
                  n(o))
                : t(o);
            }
          },
        };
      },
      94661: (e) => {
        "use strict";
        var n;
        e.exports = function (e) {
          var t,
            r = "&" + e + ";";
          return (
            ((n = n || document.createElement("i")).innerHTML = r),
            (59 !== (t = n.textContent).charCodeAt(t.length - 1) ||
              "semi" === e) &&
              t !== r &&
              t
          );
        };
      },
      94889: (e, n) => {
        "use strict";
        (n.parse = function (e) {
          var n = String(e || "").trim();
          return "" === n ? [] : n.split(t);
        }),
          (n.stringify = function (e) {
            return e.join(" ").trim();
          });
        var t = /[ \t\n\r\f]+/g;
      },
      95318: (e, n, t) => {
        "use strict";
        e.exports = t(50038);
      },
      95358: (e) => {
        "use strict";
        var n = {}.hasOwnProperty;
        function t(e) {
          return (
            (e && "object" == typeof e) || (e = {}),
            i(e.line) + ":" + i(e.column)
          );
        }
        function r(e) {
          return (
            (e && "object" == typeof e) || (e = {}), t(e.start) + "-" + t(e.end)
          );
        }
        function i(e) {
          return e && "number" == typeof e ? e : 1;
        }
        e.exports = function (e) {
          return e && "object" == typeof e
            ? n.call(e, "position") || n.call(e, "type")
              ? r(e.position)
              : n.call(e, "start") || n.call(e, "end")
              ? r(e)
              : n.call(e, "line") || n.call(e, "column")
              ? t(e)
              : ""
            : "";
        };
      },
      95751: (e, n, t) => {
        "use strict";
        var r = t(52334),
          i = t(77272),
          o = t(65759),
          l = t(40148),
          u = t(148),
          a = t(20187),
          s = t(22176),
          c = t(16525),
          f = t(24152);
        e.exports = function (e, n, t) {
          var p = t ? c(t) : { line: 1, column: 1, offset: 0 },
            d = {},
            h = [],
            m = [],
            g = [],
            v = {
              consume: function (e) {
                i(e)
                  ? (p.line++,
                    (p.column = 1),
                    (p.offset += -3 === e ? 2 : 1),
                    C())
                  : -1 !== e && (p.column++, p.offset++),
                  p._bufferIndex < 0
                    ? p._index++
                    : (p._bufferIndex++,
                      p._bufferIndex === m[p._index].length &&
                        ((p._bufferIndex = -1), p._index++)),
                  (x.previous = e);
              },
              enter: function (e, n) {
                var t = n || {};
                return (
                  (t.type = e),
                  (t.start = b()),
                  x.events.push(["enter", t, x]),
                  g.push(t),
                  t
                );
              },
              exit: function (e) {
                var n = g.pop();
                return (n.end = b()), x.events.push(["exit", n, x]), n;
              },
              attempt: w(function (e, n) {
                E(e, n.from);
              }),
              check: w(S),
              interrupt: w(S, { interrupt: !0 }),
              lazy: w(S, { lazy: !0 }),
            },
            x = {
              previous: null,
              events: [],
              parser: e,
              sliceStream: k,
              sliceSerialize: function (e) {
                return s(k(e));
              },
              now: b,
              defineSkip: function (e) {
                (d[e.line] = e.column), C();
              },
              write: function (e) {
                return ((m = o(m, e)),
                (function () {
                  for (var e, n, t; p._index < m.length; )
                    if ("string" == typeof (n = m[p._index]))
                      for (
                        e = p._index,
                          p._bufferIndex < 0 && (p._bufferIndex = 0);
                        p._index === e && p._bufferIndex < n.length;

                      ) {
                        (t = n.charCodeAt(p._bufferIndex)), (y = y(t));
                      }
                    else y = y(n);
                })(),
                null !== m[m.length - 1])
                  ? []
                  : (E(n, 0), (x.events = a(h, x.events, x)), x.events);
              },
            },
            y = n.tokenize.call(x, v);
          return (
            n.resolveAll && h.push(n), (p._index = 0), (p._bufferIndex = -1), x
          );
          function k(e) {
            return f(m, e);
          }
          function b() {
            return c(p);
          }
          function S(e, n) {
            n.restore();
          }
          function w(e, n) {
            return function (t, i, o) {
              var l, a, s, c;
              return t.tokenize || "length" in t
                ? f(u(t))
                : function (e) {
                    return e in t || null in t
                      ? f(t.null ? u(t[e]).concat(u(t.null)) : t[e])(e)
                      : o(e);
                  };
              function f(e) {
                return (l = e), d(e[(a = 0)]);
              }
              function d(e) {
                return function (t) {
                  var i, o, l, u, a;
                  return ((i = b()),
                  (o = x.previous),
                  (l = x.currentConstruct),
                  (u = x.events.length),
                  (a = Array.from(g)),
                  (c = {
                    restore: function () {
                      (p = i),
                        (x.previous = o),
                        (x.currentConstruct = l),
                        (x.events.length = u),
                        (g = a),
                        C();
                    },
                    from: u,
                  }),
                  (s = e),
                  e.partial || (x.currentConstruct = e),
                  e.name &&
                    x.parser.constructs.disable.null.indexOf(e.name) > -1)
                    ? m()
                    : e.tokenize.call(n ? r({}, x, n) : x, v, h, m)(t);
                };
              }
              function h(n) {
                return e(s, c), i;
              }
              function m(e) {
                return (c.restore(), ++a < l.length) ? d(l[a]) : o;
              }
            };
          }
          function E(e, n) {
            e.resolveAll && 0 > h.indexOf(e) && h.push(e),
              e.resolve &&
                l(
                  x.events,
                  n,
                  x.events.length - n,
                  e.resolve(x.events.slice(n), x)
                ),
              e.resolveTo && (x.events = e.resolveTo(x.events, x));
          }
          function C() {
            p.line in d &&
              p.column < 2 &&
              ((p.column = d[p.line]), (p.offset += d[p.line] - 1));
          }
        };
      },
      96143: (e, n, t) => {
        "use strict";
        var r = t(89779);
        e.exports = function (e, n) {
          var t = e[e.length - 1];
          return t && t[1].type === n ? r(t[2].sliceStream(t[1])) : 0;
        };
      },
      97832: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          return e.dangerous ? e.augment(n, r("raw", n.value)) : null;
        };
        var r = t(69921);
      },
      97833: (e, n, t) => {
        "use strict";
        e.exports = function (e, n) {
          return e.augment(n, r("root", i(o(e, n))));
        };
        var r = t(69921),
          i = t(12721),
          o = t(73684);
      },
      98360: (e) => {
        "use strict";
        e.exports = function (e) {
          if (e) throw e;
        };
      },
      98920: (e, n, t) => {
        "use strict";
        e.exports = t(46399)({
          space: "xmlns",
          attributes: { xmlnsxlink: "xmlns:xlink" },
          transform: t(74058),
          properties: { xmlns: null, xmlnsXLink: null },
        });
      },
      99268: (e) => {
        "use strict";
        var n = /[\0\t\n\r]/g;
        e.exports = function () {
          var e,
            t = !0,
            r = 1,
            i = "";
          return function (o, l, u) {
            var a,
              s,
              c,
              f,
              p,
              d = [];
            for (
              o = i + o.toString(l),
                c = 0,
                i = "",
                t && (65279 === o.charCodeAt(0) && c++, (t = void 0));
              c < o.length;

            ) {
              if (
                ((n.lastIndex = c),
                (f = (a = n.exec(o)) ? a.index : o.length),
                (p = o.charCodeAt(f)),
                !a)
              ) {
                i = o.slice(c);
                break;
              }
              if (10 === p && c === f && e) d.push(-3), (e = void 0);
              else if (
                (e && (d.push(-5), (e = void 0)),
                c < f && (d.push(o.slice(c, f)), (r += f - c)),
                0 === p)
              )
                d.push(65533), r++;
              else if (9 === p)
                for (s = 4 * Math.ceil(r / 4), d.push(-2); r++ < s; )
                  d.push(-1);
              else 10 === p ? d.push(-4) : (e = !0), (r = 1);
              c = f + 1;
            }
            return u && (e && d.push(-5), i && d.push(i), d.push(null)), d;
          };
        };
      },
      99399: (e, n, t) => {
        "use strict";
        var r = t(77144),
          i = t(85683),
          o = t(77272),
          l = t(57301),
          u = t(22552),
          a = t(24969);
        e.exports = {
          name: "htmlText",
          tokenize: function (e, n, t) {
            var s,
              c,
              f,
              p,
              d = this;
            return function (n) {
              return (
                e.enter("htmlText"), e.enter("htmlTextData"), e.consume(n), h
              );
            };
            function h(n) {
              return 33 === n
                ? (e.consume(n), m)
                : 47 === n
                ? (e.consume(n), T)
                : 63 === n
                ? (e.consume(n), F)
                : r(n)
                ? (e.consume(n), O)
                : t(n);
            }
            function m(n) {
              return 45 === n
                ? (e.consume(n), g)
                : 91 === n
                ? (e.consume(n), (c = "CDATA["), (f = 0), b)
                : r(n)
                ? (e.consume(n), C)
                : t(n);
            }
            function g(n) {
              return 45 === n ? (e.consume(n), v) : t(n);
            }
            function v(n) {
              return null === n || 62 === n
                ? t(n)
                : 45 === n
                ? (e.consume(n), x)
                : y(n);
            }
            function x(e) {
              return null === e || 62 === e ? t(e) : y(e);
            }
            function y(n) {
              return null === n
                ? t(n)
                : 45 === n
                ? (e.consume(n), k)
                : o(n)
                ? ((p = y), B(n))
                : (e.consume(n), y);
            }
            function k(n) {
              return 45 === n ? (e.consume(n), j) : y(n);
            }
            function b(n) {
              return n === c.charCodeAt(f++)
                ? (e.consume(n), f === c.length ? S : b)
                : t(n);
            }
            function S(n) {
              return null === n
                ? t(n)
                : 93 === n
                ? (e.consume(n), w)
                : o(n)
                ? ((p = S), B(n))
                : (e.consume(n), S);
            }
            function w(n) {
              return 93 === n ? (e.consume(n), E) : S(n);
            }
            function E(n) {
              return 62 === n ? j(n) : 93 === n ? (e.consume(n), E) : S(n);
            }
            function C(n) {
              return null === n || 62 === n
                ? j(n)
                : o(n)
                ? ((p = C), B(n))
                : (e.consume(n), C);
            }
            function F(n) {
              return null === n
                ? t(n)
                : 63 === n
                ? (e.consume(n), P)
                : o(n)
                ? ((p = F), B(n))
                : (e.consume(n), F);
            }
            function P(e) {
              return 62 === e ? j(e) : F(e);
            }
            function T(n) {
              return r(n) ? (e.consume(n), A) : t(n);
            }
            function A(n) {
              return 45 === n || i(n)
                ? (e.consume(n), A)
                : (function n(t) {
                    return o(t)
                      ? ((p = n), B(t))
                      : u(t)
                      ? (e.consume(t), n)
                      : j(t);
                  })(n);
            }
            function O(n) {
              return 45 === n || i(n)
                ? (e.consume(n), O)
                : 47 === n || 62 === n || l(n)
                ? D(n)
                : t(n);
            }
            function D(n) {
              return 47 === n
                ? (e.consume(n), j)
                : 58 === n || 95 === n || r(n)
                ? (e.consume(n), I)
                : o(n)
                ? ((p = D), B(n))
                : u(n)
                ? (e.consume(n), D)
                : j(n);
            }
            function I(n) {
              return 45 === n || 46 === n || 58 === n || 95 === n || i(n)
                ? (e.consume(n), I)
                : (function n(t) {
                    return 61 === t
                      ? (e.consume(t), M)
                      : o(t)
                      ? ((p = n), B(t))
                      : u(t)
                      ? (e.consume(t), n)
                      : D(t);
                  })(n);
            }
            function M(n) {
              return null === n || 60 === n || 61 === n || 62 === n || 96 === n
                ? t(n)
                : 34 === n || 39 === n
                ? (e.consume(n), (s = n), L)
                : o(n)
                ? ((p = M), B(n))
                : u(n)
                ? (e.consume(n), M)
                : (e.consume(n), (s = void 0), _);
            }
            function L(n) {
              return n === s
                ? (e.consume(n), z)
                : null === n
                ? t(n)
                : o(n)
                ? ((p = L), B(n))
                : (e.consume(n), L);
            }
            function z(e) {
              return 62 === e || 47 === e || l(e) ? D(e) : t(e);
            }
            function _(n) {
              return null === n ||
                34 === n ||
                39 === n ||
                60 === n ||
                61 === n ||
                96 === n
                ? t(n)
                : 62 === n || l(n)
                ? D(n)
                : (e.consume(n), _);
            }
            function B(n) {
              return (
                e.exit("htmlTextData"),
                e.enter("lineEnding"),
                e.consume(n),
                e.exit("lineEnding"),
                a(
                  e,
                  R,
                  "linePrefix",
                  d.parser.constructs.disable.null.indexOf("codeIndented") > -1
                    ? void 0
                    : 4
                )
              );
            }
            function R(n) {
              return e.enter("htmlTextData"), p(n);
            }
            function j(r) {
              return 62 === r
                ? (e.consume(r), e.exit("htmlTextData"), e.exit("htmlText"), n)
                : t(r);
            }
          },
        };
      },
    },
  ]);
