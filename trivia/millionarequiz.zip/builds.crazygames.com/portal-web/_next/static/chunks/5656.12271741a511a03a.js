!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var o = 1; o < arguments.length; o++) {
          var a = arguments[o];
          if (null != a) for (var n in a) a.hasOwnProperty(n) && (e[n] = a[n]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var o = new e.Error().stack;
    o &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[o] = "b078234f-3297-4a57-a24c-fd9c95ef30ed"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-b078234f-3297-4a57-a24c-fd9c95ef30ed"));
  } catch (e) {}
})();
("use strict");
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [5656],
  {
    5656: (e) => {
      e.exports = {
        messages: JSON.parse(
          '{"games.becauseYouPlayed.title":["Because you played ",["gameName"]],"games.discoveryOnboarding.categories.heading":["What are you in the mood for?"],"games.discoveryOnboarding.categories.subheading":["Pick 1-3 categories that feel most like you. We\'ll update your top picks on the homepage."],"games.discoveryOnboarding.counter":[["count"]," of ",["max"]," selected"],"games.discoveryOnboarding.counterAtLimit":[["count"]," of ",["max"]," selected \xb7 that\'s the maximum"],"games.discoveryOnboarding.counterWithMin":[["count"]," of ",["max"]," selected \xb7 pick at least ",["min"]],"games.discoveryOnboarding.cta":["Build my list"],"games.discoveryOnboarding.games.subheading":["Pick 3-5 games that catch your eye. We\'ll update your top picks on the homepage."],"games.discoveryOnboarding.option.action-fighting":["Action & Fighting"],"games.discoveryOnboarding.option.adventure-horror":["Adventure & Horror"],"games.discoveryOnboarding.option.board-card":["Board & Card"],"games.discoveryOnboarding.option.brainy":["Word & Puzzle"],"games.discoveryOnboarding.option.click-manage":["Click & Manage"],"games.discoveryOnboarding.option.dress-up-beauty":["Dress-up & Beauty"],"games.discoveryOnboarding.option.idle-clicker":["Idle & Clicker"],"games.discoveryOnboarding.option.match-merge":["Match & Merge"],"games.discoveryOnboarding.option.meme-bloxy":["Meme & Bloxy"],"games.discoveryOnboarding.option.play-with-friends":["Play with friends"],"games.discoveryOnboarding.option.quick-arcade-fun":["Quick arcade fun"],"games.discoveryOnboarding.option.racing-driving":["Racing & Driving"],"games.discoveryOnboarding.option.shooting":["Shooting"],"games.discoveryOnboarding.option.sports":["Sports"],"games.discoveryOnboarding.option.strategy-adventure":["Strategy & adventure"],"games.discoveryOnboarding.option.strategy-defense":["Strategy & Defense"],"games.discoveryOnboarding.option.train-your-brain":["Word & Puzzle"],"games.discoveryOnboarding.option.tycoon-farming":["Tycoon & Farming"],"games.discoveryOnboarding.optionSubtitle.brainy":["Quizzes, words, board, card"],"games.discoveryOnboarding.optionSubtitle.click-manage":["Idle, tycoon, management"],"games.discoveryOnboarding.optionSubtitle.play-with-friends":["Online & 2-player"],"games.discoveryOnboarding.optionSubtitle.sports":["Pool, basketball, football"],"games.discoveryOnboarding.optionSubtitle.strategy-adventure":["Conquer, defend, explore"],"games.discoveryOnboarding.skip":["Skip for now"],"games.discoveryOnboarding.takeover.categories.heading":["What do you love playing?"],"games.discoveryOnboarding.takeover.categories.subheading":["Pick your favorite game categories and we\'ll find your next favorites!"],"games.discoveryOnboarding.takeover.counter":[["count"]," of ",["max"]," selected"],"games.discoveryOnboarding.takeover.cta":["Show my games"],"games.discoveryOnboarding.takeover.gridLabel":["Game categories"],"games.discoveryOnboarding.takeover.intents.heading":["What\'s your mood?"],"games.discoveryOnboarding.takeover.intents.subheading":["We\'ll find you a selection of games you\'ll love!"],"games.discoveryOnboarding.takeover.limitReached":["Maximum ",["max"],". Remove one first"],"games.discoveryOnboarding.takeover.or":["OR"],"games.discoveryOnboarding.takeover.skip":["Don\'t personalize anything"],"games.discoveryOnboarding.takeover.skipSubtitle":["Show me the most popular games: racing, action, shooting, arcade … and more!"],"games.discoveryOnboarding.title":["See more of what you love \uD83C\uDFAF"],"games.empty.homepage":["homepage"],"games.empty.title":["Uh-oh, there are no games here. Maybe you can check out the games on our ",["homepageLink"]],"games.featured.title":["Featured games"],"games.halloweenBanner.text":["Subscribe now to our YouTube for a <0>spooky avatar</0> gift on Oct 27"],"games.hot.description":["On fire right now. These games are blowing up in the last 24 hours — jump in before everyone else does."],"games.hot.metaDescription":["Check Out the Best Games on CrazyGames According to Our Users: Try Them Now!"],"games.hot.metaTitle":["Hot Games This Month on CrazyGames"],"games.hot.title":["Hot Games"],"games.new.title":["New games"],"games.offlineContentCard.dismissButton":["Close"],"games.offlineContentCard.downloadButton":["Download games"],"games.offlineContentCard.header":["Going offline?"],"games.offlineContentCard.subHeader":["Download games & play anytime, anywhere!"],"games.offlineGamesBanner.cta":["Get the App"],"games.offlineGamesBanner.headline":["Play <0>offline</0>"],"games.offlineGamesBanner.subtitle":["Flight mode, bad Wi-Fi? Play through it all."],"games.onboardingResults.allTab":["All picks"],"games.onboardingResults.eyebrow":["Your starting lineup"],"games.onboardingResults.headingPrefix":["Because you love"],"games.onboardingResults.lastNameSeparator":[" & "],"games.onboardingResults.nameSeparator":[", "],"games.onboardingResults.subheading":["Hand-picked to get you started. Your feed keeps learning as you play."],"games.originals.play":["Play"],"games.recent.title":["Continue playing"],"games.recentCarousel.done":["Done"],"games.recentCarousel.edit":["Edit"],"games.recommended.title":["Our top games"],"games.recommendedCarousel.title":["Recommended"],"games.recommendedForYou.title":["Top picks for you"],"games.recommendedForYou.titleFirstSession":["Top games in ",["countryFlag"]," today"],"games.recommendedForYou.titleFirstSessionNoCountry":["Top games today"],"games.seo.learnmore":["Learn more"],"games.title.page":["Page"],"games.topRecentPromotionalBanner.surpriseElement":["Surprise me!"],"games.updated.title":["Recently updated games"],"games.weeklyFeatured.title":["Recommended this week"]}'
        ),
      };
    },
  },
]);
