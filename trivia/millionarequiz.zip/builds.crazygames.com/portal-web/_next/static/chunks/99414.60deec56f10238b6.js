!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var n = 1; n < arguments.length; n++) {
          var t = arguments[n];
          if (null != t) for (var o in t) t.hasOwnProperty(o) && (e[o] = t[o]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "2c2658c0-09c3-4076-ab62-f47b31686a18"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-2c2658c0-09c3-4076-ab62-f47b31686a18"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [11591, 99414],
    {
      11591: (e, n, t) => {
        "use strict";
        t.d(n, { A: () => p });
        var o = t(6029),
          a = t(75155);
        t(55729);
        var s = t(50212),
          r = t(56760),
          l = t(69386),
          i = t(85893),
          d = t(82026),
          c = t.n(d);
        let p = (e) => {
          let n,
            t,
            d,
            p,
            u = (0, a.c)(12),
            { open: I, blurred: _, onClose: M, children: f, className: m } = e;
          if (((0, l.K)(I), !I)) return null;
          let h = void 0 !== _ && _ && c().blurred;
          if (
            (u[0] !== m || u[1] !== h
              ? ((n = (0, s.A)(c().modal, h, m)),
                (u[0] = m),
                (u[1] = h),
                (u[2] = n))
              : (n = u[2]),
            u[3] !== M || u[4] !== I
              ? ((t = (0, o.jsx)(i.k, { open: I, onClick: M })),
                (u[3] = M),
                (u[4] = I),
                (u[5] = t))
              : (t = u[5]),
            u[6] !== f
              ? ((d = (0, o.jsx)("div", {
                  className: c().modalContent,
                  children: f,
                })),
                (u[6] = f),
                (u[7] = d))
              : (d = u[7]),
            u[8] !== n || u[9] !== t || u[10] !== d)
          ) {
            let e = (0, o.jsxs)("div", { className: n, children: [t, d] });
            (p = (0, r.createPortal)(e, document.body)),
              (u[8] = n),
              (u[9] = t),
              (u[10] = d),
              (u[11] = p);
          } else p = u[11];
          return p;
        };
      },
      77506: (e) => {
        e.exports = {
          optInModalContainer: "SuprSendOptInModal_optInModalContainer__FSksa",
          isTransparent: "SuprSendOptInModal_isTransparent__rqopY",
          optInModalIcon: "SuprSendOptInModal_optInModalIcon__AsCi1",
          optInModalTitle: "SuprSendOptInModal_optInModalTitle__jSPkF",
          optInModalDescription:
            "SuprSendOptInModal_optInModalDescription__V5_Xv",
          optInModalActions: "SuprSendOptInModal_optInModalActions__jsK_l",
          optInModalError: "SuprSendOptInModal_optInModalError__9usE_",
        };
      },
      99414: (e, n, t) => {
        "use strict";
        t.r(n), t.d(n, { default: () => v });
        var o = t(6029),
          a = t(55729),
          s = t(7842),
          r = t(79942),
          l = t(50212),
          i = t(14886),
          d = t(28478),
          c = t(37434),
          p = t(4230),
          u = t(94618),
          I = t(93800),
          _ = t(71684),
          M = t(11591),
          f = t(10614),
          m = t(44884),
          h = t(62273),
          x = t(77506),
          g = t.n(x);
        let y = "push-notification-OptIn",
          j = "ss_allowing",
          v = () => {
            let { crazyAnalyticsService: e } = (0, a.useContext)(_.A).services,
              { user: n, isNewUser: t } = (0, a.useContext)(i.R),
              x = (0, a.useContext)(p.A),
              v = (0, m.$K)(x),
              {
                isSubscribed: b,
                loading: w,
                getNotificationPermission: A,
                subscribe: S,
              } = (0, f.A)(),
              [E, C] = a.useState(!1),
              [k, N] = a.useState(!1),
              [D, O] = a.useState(!1),
              [T, P] = a.useState(!1),
              z = d.A.LocalStorage,
              K = z.getItem("ss_distinct_id"),
              F = `ss_shown_${K}`,
              Y = z.getItem(F),
              B = z.getItem(j);
            a.useEffect(() => {
              (async () => {
                v &&
                ("true" !== Y || B) &&
                n &&
                "no" === t &&
                !w &&
                (await (0, m.NY)())
                  ? N(!b)
                  : N(!1);
              })();
            }, [Y, B, n, v, t, b, w]),
              a.useEffect(() => {
                k && e.notificationActionEvent(y, "shown");
              }, [e, k, z]);
            let $ = () => {
                e.notificationActionEvent(y, "ignored"),
                  N(!1),
                  z.setItem(F, "true");
              },
              q = async () => {
                if ("denied" === A()) return void P(!0);
                z.setItem(F, "true"), z.setItem(j, "true"), C(!0);
                try {
                  if (!(await (0, m.NY)())) return;
                  "default" === A() && O(!0),
                    (await S()) && e.notificationActionEvent(y, "accepted");
                } catch (e) {
                  console.warn("handleEnable: ", e);
                } finally {
                  z.removeItem(j), O(!1), C(!1), N(!1);
                }
              };
            return k
              ? (0, o.jsxs)(o.Fragment, {
                  children: [
                    (0, o.jsx)(M.A, {
                      open: !D,
                      onClose: $,
                      children: (0, o.jsxs)("div", {
                        className: (0, l.A)(g().optInModalContainer),
                        children: [
                          (0, o.jsx)("figure", {
                            className: g().optInModalIcon,
                            children: (0, o.jsx)("img", {
                              src: (0, u.Ay)(
                                "crazygames/bell-icon.png",
                                {},
                                !1
                              ),
                              alt: "Bell icon",
                            }),
                          }),
                          (0, o.jsx)("h2", {
                            className: g().optInModalTitle,
                            children: (0, o.jsx)(r.x6, {
                              id: "common.suprsend.optInModal.title",
                            }),
                          }),
                          (0, o.jsx)("p", {
                            className: g().optInModalDescription,
                            children: (0, o.jsx)(r.x6, {
                              id: "common.suprsend.optInModal.description",
                            }),
                          }),
                          (0, o.jsxs)("div", {
                            className: g().optInModalActions,
                            children: [
                              (0, o.jsx)(c.A, {
                                variant: "outlined",
                                color: "white",
                                height: 50,
                                onClick: () => $(),
                                children: (0, o.jsx)(r.x6, {
                                  id: "common.suprsend.optInModal.dismiss",
                                }),
                              }),
                              (0, o.jsx)(c.A, {
                                variant: "contained",
                                color: E ? "grey" : "purple",
                                height: 50,
                                onClick: () => q(),
                                disabled: !!E,
                                children:
                                  E && "granted" === A()
                                    ? (0, o.jsx)(s.y, {
                                        size: "small",
                                        tone: "neutral",
                                      })
                                    : (0, o.jsx)(r.x6, {
                                        id: "common.suprsend.optInModal.allow",
                                      }),
                              }),
                            ],
                          }),
                          T &&
                            (0, o.jsxs)("div", {
                              className: g().optInModalError,
                              children: [
                                (0, o.jsx)(I.A, { name: "warning", size: 16 }),
                                (0, o.jsx)("span", {
                                  children: (0, o.jsx)(r.x6, {
                                    id: "friends.upDrawer.notificationPreferences.pushNotificationsDenied",
                                  }),
                                }),
                              ],
                            }),
                        ],
                      }),
                    }),
                    D && (0, o.jsx)(h.A, {}),
                  ],
                })
              : null;
          };
      },
    },
  ]);
