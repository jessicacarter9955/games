!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var a = arguments[t];
          if (null != a) for (var r in a) a.hasOwnProperty(r) && (e[r] = a[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "a2c16d22-861d-4279-b1dc-7cba38d20b0c"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-a2c16d22-861d-4279-b1dc-7cba38d20b0c"));
  } catch (e) {}
})();
("use strict");
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
  [8603],
  {
    298: (e, t, a) => {
      a.d(t, {
        d9: () => y,
        lT: () => d,
        ny: () => p,
        readCatalogCoverBaseUrl: () => h,
        syncCatalogCovers: () => f,
      });
      var r = a(74339),
        i = a(16614),
        o = a(85707),
        n = a(94618),
        l = a(81465),
        s = a(78956);
      let d = Math.ceil(400 / 3);
      function c(e, t, a) {
        if (!e) return;
        let r = Math.min(window.devicePixelRatio || 1, 2);
        return (
          (0, n.Ay)(e, {
            quality: n.qw[Math.round(r)],
            width: t,
            format: "png",
            dpr: r,
            ...a,
          }) || void 0
        );
      }
      function m(e) {
        return e?.["1x1"]
          ? c(e["1x1"], d)
          : c(e?.["16x9"], d, { height: d, fit: "cover" });
      }
      async function u(e, t) {
        e && (await i.FileTransfer.downloadFile({ url: e, path: t }));
      }
      function p(e) {
        return [
          { url: m(e.covers), path: `${(0, s.PL)(e.gameSlug)}/${s.gh}` },
          {
            url: c(e.covers["16x9"], 196),
            path: `${(0, s.PL)(e.gameSlug)}/${s.l4}`,
          },
        ].filter((e) => !!e.url);
      }
      async function y(e) {
        let { uri: t } = await o.Filesystem.getUri({
          path: (0, s.PL)(e.gameSlug),
          directory: o.Directory.Data,
        });
        await u(m(e.covers), `${t}/${s.gh}`),
          await u(c(e.covers["16x9"], 196), `${t}/${s.l4}`);
      }
      async function f(e) {
        let t = await (0, l.f)(s.x2, o.Directory.Data),
          a = new Set(t.map((e) => (0, s.Nh)(e.name))),
          r = new Set(e.map((e) => e.gameSlug));
        await o.Filesystem.mkdir({
          path: s.x2,
          directory: o.Directory.Data,
          recursive: !0,
        }).catch(() => void 0);
        let { uri: i } = await o.Filesystem.getUri({
          path: s.x2,
          directory: o.Directory.Data,
        });
        for (let t of e)
          if (!a.has(t.gameSlug))
            try {
              await u(m(t.covers), `${i}/${(0, s.b9)(t.gameSlug)}`);
            } catch (e) {
              console.warn(
                `[OfflineCovers] caching the catalog cover of "${t.gameSlug}" failed:`,
                e
              );
            }
        for (let e of t)
          r.has((0, s.Nh)(e.name)) ||
            (await o.Filesystem.deleteFile({
              path: `${s.x2}/${e.name}`,
              directory: o.Directory.Data,
            }).catch((t) =>
              console.warn(
                `[OfflineCovers] dropping the stale catalog cover "${e.name}" failed:`,
                t
              )
            ));
      }
      async function h() {
        let { uri: e } = await o.Filesystem.getUri({
          path: s.x2,
          directory: o.Directory.Data,
        });
        return r.Capacitor.convertFileSrc(e);
      }
    },
    8603: (e, t, a) => {
      let r;
      a.r(t),
        a.d(t, {
          GAME_FILES_DIR: () => h.dp,
          SDK_VERSIONS: () => C,
          applyOfflineBase: () => A,
          deleteAllOfflineGames: () => X,
          deleteGame: () => W,
          deleteSupersededBuilds: () => Z,
          discardFailedDownload: () => q,
          downloadGame: () => K,
          finalizeGameDownload: () => J,
          getOfflineLauncherUrl: () => v,
          invalidateDownloadedGamesCache: () => ea,
          isUnityLoader: () => b,
          localPathFor: () => h.yX,
          peekDownloadedGames: () => er,
          prepareGameDownload: () => G,
          readDownloadedGames: () => ei,
          refreshSharedFiles: () => H,
          sweepPartialDownloads: () => Q,
        });
      var i = a(20754),
        o = a(74339),
        n = a(16614),
        l = a(85707),
        s = a(64844),
        d = a(54731),
        c = a(13246),
        m = a(61411),
        u = a(57897),
        p = a(69542),
        y = a(298),
        f = a(81465),
        h = a(78956);
      let w = "offline-gameframe-launcher.html",
        g = `${h.Ut}/${w}`;
      async function D() {
        try {
          let e = await fetch(`${window.location.origin}/${w}`);
          if (!e.ok)
            throw Error(
              `Failed to fetch offline launcher: ${e.status} ${e.statusText}`
            );
          let t = await e.text();
          await l.Filesystem.writeFile({
            path: g,
            data: (0, u.Ii)(t),
            directory: l.Directory.Data,
            recursive: !0,
          });
        } catch (e) {
          if (await (0, f.s)(g, l.Directory.Data)) return;
          throw e;
        }
      }
      async function v(e) {
        await D();
        let { uri: t } = await l.Filesystem.getUri({
            path: g,
            directory: l.Directory.Data,
          }),
          a = new URL(o.Capacitor.convertFileSrc(t));
        return (a.hostname = `${e}.${a.hostname}`), a.toString();
      }
      var F = a(15992);
      let $ = {
        5.4: "unity/unity54",
        5.6: "unity/unity56",
        2020: "unity/unity2020",
      };
      function b(e) {
        return !!e && e in F.yl && "unity" === F.yl[e].type;
      }
      function L(e) {
        if (!e) return null;
        let t = F.yl[e];
        return "unity" !== t.type ? null : $[t.unityLoaderType];
      }
      let S = "__OFFLINE_BASE__";
      async function U(e, t, a) {
        let r = await fetch(e);
        if (!r.ok)
          throw Error(`Failed to fetch ${e}: ${r.status} ${r.statusText}`);
        let i = await r.arrayBuffer();
        await l.Filesystem.writeFile({
          path: `${a}/${t}`,
          data: (0, u.nk)(new Uint8Array(i)),
          directory: l.Directory.Data,
          recursive: !0,
        });
      }
      async function k(e, t, a) {
        let r =
            arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : U,
          i = async (e) => {
            if ("string" == typeof e) {
              let i = (function (e, t) {
                let a;
                try {
                  a = new URL(e).pathname;
                } catch {
                  return null;
                }
                let r = a.split("/").filter(Boolean),
                  i = r.indexOf(t),
                  o = i + 2;
                return -1 === i || r.length < o ? null : r.slice(o).join("/");
              })(e, t);
              if ("" === i) return S;
              if (null !== i) return `${S}/${i}`;
              if (/^https?:\/\//i.test(e)) {
                let t = new URL(e).pathname.split("/").pop() || "asset",
                  i = `offline-shared/${t}`;
                return await r(e, i, a), `${S}/${i}`;
              }
              return e;
            }
            return Array.isArray(e)
              ? Promise.all(e.map(i))
              : e && "object" == typeof e
              ? Object.fromEntries(
                  await Promise.all(
                    Object.entries(e).map(async (e) => {
                      let [t, a] = e;
                      return [t, await i(a)];
                    })
                  )
                )
              : e;
          };
        return i(e);
      }
      function A(e, t) {
        let a = (e) =>
          "string" == typeof e
            ? e.split(S).join(t)
            : Array.isArray(e)
            ? e.map(a)
            : e && "object" == typeof e
            ? Object.fromEntries(
                Object.entries(e).map((e) => {
                  let [t, r] = e;
                  return [t, a(r)];
                })
              )
            : e;
        return a(e);
      }
      function R(e, t) {
        return `https://${e}.${c.A.Instance.data.gameFiles}/${t}/${e}.html`;
      }
      function I(e, t) {
        if (!e.trim())
          throw Error(`Unity loader page fetch returned an empty body (${t})`);
      }
      async function O(e, t, a) {
        let r = R(e, t),
          i = await o.CapacitorHttp.get({ url: r, responseType: "text" }),
          n = String(i.data ?? "");
        if (i.status < 200 || i.status >= 300)
          throw Error(`Unity loader page fetch failed: ${i.status}`);
        I(n, r),
          await l.Filesystem.writeFile({
            path: `${a}/index.html`,
            data: (0, u.Ii)(n),
            directory: l.Directory.Data,
          });
      }
      let C = [
          {
            filename: "crazygames-sdk-v1.js",
            url: "https://sdk.crazygames.com/crazygames-sdk-v1.js",
            path: `${h.Ut}/crazygames-sdk-v1.js`,
          },
          {
            filename: "crazygames-sdk-v2.js",
            url: "https://sdk.crazygames.com/crazygames-sdk-v2.js",
            path: `${h.Ut}/crazygames-sdk-v2.js`,
          },
          {
            filename: "crazygames-sdk-v3.js",
            url: "https://sdk.crazygames.com/crazygames-sdk-v3.js",
            path: `${h.Ut}/crazygames-sdk-v3.js`,
          },
          {
            filename: "Construct3CrazySDK-v3.js",
            url: "https://sdk.crazygames.com/Construct3CrazySDK-v3.js",
            path: `${h.Ut}/Construct3CrazySDK-v3.js`,
          },
        ],
        z = "offline-game-info.json",
        P = `${h.Ut}/sdk-last-modified.json`;
      async function N() {
        if (!(await (0, f.s)(P, l.Directory.Data))) return {};
        try {
          let { data: e } = await l.Filesystem.readFile({
            path: P,
            directory: l.Directory.Data,
          });
          return JSON.parse((0, u.YU)(e));
        } catch {
          return {};
        }
      }
      async function j(e) {
        await l.Filesystem.writeFile({
          path: P,
          data: (0, u.Ii)(JSON.stringify(e)),
          directory: l.Directory.Data,
        });
      }
      async function _(e) {
        let t = await fetch(e.url, { cache: "no-cache" });
        if (!t.ok) throw Error(`Fetch failed: ${t.status} ${t.statusText}`);
        let a = await t.arrayBuffer(),
          r = `${e.path}.tmp`;
        return (
          await l.Filesystem.writeFile({
            path: r,
            data: (0, u.nk)(new Uint8Array(a)),
            directory: l.Directory.Data,
          }),
          await l.Filesystem.rename({
            from: r,
            to: e.path,
            directory: l.Directory.Data,
          }),
          t.headers.get("last-modified")
        );
      }
      async function x(e, t) {
        let a = await fetch(e.url, { method: "HEAD", cache: "no-store" });
        if (!a.ok) throw Error(`HEAD failed: ${a.status} ${a.statusText}`);
        let r = a.headers.get("last-modified");
        return !!r && r === t;
      }
      async function E(e) {
        let t,
          a = new Set(
            (await (0, f.f)(h.Ut, l.Directory.Data)).map((e) => e.name)
          ),
          r = await N(),
          i = C.filter((e) => !a.has(e.filename)),
          o = [
            ...i,
            ...(
              await Promise.all(
                C.filter((e) => a.has(e.filename)).map(async (e) => {
                  try {
                    return (await x(e, r[e.filename])) ? null : e;
                  } catch (t) {
                    return (
                      console.warn(
                        `[OfflineGameStore] checking ${e.filename} failed:`,
                        t
                      ),
                      null
                    );
                  }
                })
              )
            ).filter((e) => null !== e),
          ];
        if (0 === o.length) return;
        e?.("Downloading SDKs…", "sdks"),
          (await (0, f.s)(h.Ut, l.Directory.Data)) ||
            (await l.Filesystem.mkdir({
              path: h.Ut,
              directory: l.Directory.Data,
              recursive: !0,
            }));
        let n = await Promise.allSettled(
          o.map(async (e) => {
            let t = await _(e);
            t ? (r[e.filename] = t) : delete r[e.filename];
          })
        );
        if (
          (await j(r),
          n.forEach((e, a) => {
            if ("fulfilled" === e.status) return;
            let r = o[a];
            i.includes(r)
              ? (t ??= e.reason)
              : console.warn(
                  `[OfflineGameStore] downloading ${r.filename} failed:`,
                  e.reason
                );
          }),
          t)
        )
          throw t;
      }
      let B = null;
      function T(e) {
        return (B ??= E(e).finally(() => {
          B = null;
        }));
      }
      async function H() {
        0 !== (await ei()).length && (await T());
      }
      async function M(e) {
        let t;
        await l.Filesystem.writeFile({
          path: `${e}/offlinegame-sw.js`,
          data: (0, u.Ii)(
            ((t = JSON.stringify(
              Object.fromEntries(C.map((e) => [e.url, e.filename]))
            )),
            `self.addEventListener('install',function(){self.skipWaiting();});self.addEventListener('activate',function(e){e.waitUntil(self.clients.claim());});var SDK_MAP=${t};self.addEventListener('fetch',function(e){var f=SDK_MAP[e.request.url];if(f){e.respondWith(fetch(new URL('../../../shared/'+f,self.location.href).href).then(function(r){return new Response(r.body,{status:r.status,headers:new Headers({'Content-Type':'application/javascript'})});}));}});`)
          ),
          directory: l.Directory.Data,
        });
      }
      async function G(e) {
        await D();
        let t = `${c.A.Instance.data.api}/${d.m}/${m.Jh}/games/${e.gameSlug}/gameframe?buildId=${e.buildId}`,
          a = await fetch(t);
        if (!a.ok)
          throw Error(
            `Gameframe config fetch failed: ${a.status} ${a.statusText}`
          );
        let r = await a.json(),
          i = (0, y.ny)(e).map((e) => ({ ...e, stage: "covers" }));
        for (let e of C)
          (await (0, f.s)(e.path, l.Directory.Data)) ||
            i.push({ url: e.url, path: e.path, stage: "sdks" });
        let o = (0, h.yX)(e),
          n = L(r.loader);
        return (
          n &&
            (i.push({
              url: R(e.gameSlug, n),
              path: `${o}/index.html`,
              stage: "unity_page",
            }),
            (r.loaderOptions = await k(
              r.loaderOptions,
              e.gameSlug,
              o,
              (e, t) => (
                i.push({ url: e, path: `${o}/${t}`, stage: "unity_files" }),
                Promise.resolve()
              )
            ))),
          { build: e, loadOptions: r, files: i }
        );
      }
      async function J(e, t, a) {
        let r =
            arguments.length > 3 && void 0 !== arguments[3]
              ? arguments[3]
              : () => void 0,
          { build: o, loadOptions: n } = e,
          s = (0, h.yX)(o),
          d = `${(0, h.yX)({ gameSlug: o.gameSlug, buildId: o.buildId })}/`,
          c = a.map((e) =>
            e.installPath.startsWith(d)
              ? { ...e, installPath: `${s}/${e.installPath.slice(d.length)}` }
              : e
          ),
          m = L(n.loader);
        if (m) {
          r("unity_page");
          let e = c.find((e) => {
            let { installPath: t } = e;
            return t === `${s}/index.html`;
          });
          if (!e) throw Error("The downloaded Unity loader page is missing.");
          let { data: t } = await l.Filesystem.readFile({
            path: e.source,
            directory: l.Directory.Data,
            encoding: l.Encoding.UTF8,
          });
          I("string" == typeof t ? t : await t.text(), R(o.gameSlug, m));
        }
        r("extract"),
          (await (0, f.s)(s, l.Directory.Data)) &&
            (await l.Filesystem.rmdir({
              path: s,
              directory: l.Directory.Data,
              recursive: !0,
            })),
          await l.Filesystem.mkdir({
            path: s,
            directory: l.Directory.Data,
            recursive: !0,
          });
        let [{ uri: p }, { uri: y }] = await Promise.all([
          l.Filesystem.getUri({ path: t, directory: l.Directory.Data }),
          l.Filesystem.getUri({ path: s, directory: l.Directory.Data }),
        ]);
        for (let { source: e, installPath: t } of (await i.CapacitorZip.unzip({
          source: p.replace(/^file:\/\//, ""),
          destination: y.replace(/^file:\/\//, ""),
        }),
        c)) {
          if (
            (r(
              t.startsWith(`${h.Ut}/`)
                ? "sdks"
                : t.startsWith(`${s}/`)
                ? "unity_files"
                : "covers"
            ),
            t.startsWith(`${h.Ut}/`) && (await (0, f.s)(t, l.Directory.Data)))
          )
            continue;
          let a = t.slice(0, t.lastIndexOf("/"));
          (await (0, f.s)(a, l.Directory.Data)) ||
            (await l.Filesystem.mkdir({
              path: a,
              directory: l.Directory.Data,
              recursive: !0,
            })),
            await l.Filesystem.copy({
              from: e,
              to: t,
              directory: l.Directory.Data,
              toDirectory: l.Directory.Data,
            });
        }
        r("config"), await M(s);
        let w = {
          buildId: o.buildId,
          gameId: o.gameId,
          gameSlug: o.gameSlug,
          gameName: o.gameName,
          loadOptions: n,
          zipUrl: o.zipUrl,
          downloadedAt: Date.now(),
        };
        await l.Filesystem.writeFile({
          path: `${s}/${z}`,
          data: (0, u.Ii)(JSON.stringify(w)),
          directory: l.Directory.Data,
        }),
          ea();
      }
      async function K(e, t, a) {
        await T(t), await D();
        let r = (0, h.yX)(e),
          o = `${e.buildId}.zip`;
        t("Downloading…", "zip");
        let { uri: s } = await l.Filesystem.getUri({
          path: o,
          directory: l.Directory.Cache,
        });
        (await (0, f.s)(o, l.Directory.Cache)) &&
          (await l.Filesystem.deleteFile({
            path: o,
            directory: l.Directory.Cache,
          }));
        let p = a
          ? await n.FileTransfer.addListener("progress", (t) => {
              let { url: r, bytes: i, contentLength: o } = t,
                n = o || e.zipSize || 0;
              r === e.zipUrl && n > 0 && a(Math.min(i / n, 1));
            })
          : void 0;
        try {
          await n.FileTransfer.downloadFile({
            url: e.zipUrl,
            path: s,
            progress: !!a,
            connectTimeout: 1e4,
            readTimeout: 1e4,
          });
        } finally {
          await p?.remove();
        }
        t("Extracting…", "extract"),
          (await (0, f.s)(r, l.Directory.Data)) &&
            (await l.Filesystem.rmdir({
              path: r,
              directory: l.Directory.Data,
              recursive: !0,
            })),
          await l.Filesystem.mkdir({
            path: r,
            directory: l.Directory.Data,
            recursive: !0,
          });
        let { uri: w } = await l.Filesystem.getUri({
          path: r,
          directory: l.Directory.Data,
        });
        console.log("[GameBuild] unzipping", s, "→", w),
          await i.CapacitorZip.unzip({
            source: s.replace(/^file:\/\//, ""),
            destination: w.replace(/^file:\/\//, ""),
          }),
          console.log("[GameBuild] unzip complete for", e.gameSlug),
          await l.Filesystem.deleteFile({
            path: o,
            directory: l.Directory.Cache,
          }).catch(() => void 0),
          t("Fetching game config…", "config");
        let g = `${c.A.Instance.data.api}/${d.m}/${m.Jh}/games/${e.gameSlug}/gameframe?buildId=${e.buildId}`,
          v = await fetch(g);
        if (!v.ok)
          throw Error(
            `Gameframe config fetch failed: ${v.status} ${v.statusText}`
          );
        let F = await v.json(),
          $ = L(F.loader);
        $ &&
          (t("Fetching Unity loader page…", "unity_page"),
          await O(e.gameSlug, $, r),
          t("Preparing Unity files…", "unity_files"),
          (F.loaderOptions = await k(F.loaderOptions, e.gameSlug, r))),
          await M(r),
          t("Fetching covers…", "covers"),
          await (0, y.d9)(e);
        let b = {
          buildId: e.buildId,
          gameId: e.gameId,
          gameSlug: e.gameSlug,
          gameName: e.gameName,
          loadOptions: F,
          zipUrl: e.zipUrl,
          downloadedAt: Date.now(),
        };
        await l.Filesystem.writeFile({
          path: `${r}/${z}`,
          data: (0, u.Ii)(JSON.stringify(b)),
          directory: l.Directory.Data,
        }),
          ea();
      }
      async function W(e) {
        await l.Filesystem.rmdir({
          path: (0, h.PL)(e),
          directory: l.Directory.Data,
          recursive: !0,
        }),
          ea();
      }
      async function X() {
        await Promise.all(
          h.Z.map(async (e) => {
            (await (0, f.s)(e, l.Directory.Data).catch(() => !0)) &&
              (await l.Filesystem.rmdir({
                path: e,
                directory: l.Directory.Data,
                recursive: !0,
              }).catch((t) =>
                console.warn(
                  `[deleteAllOfflineGames] removing "${e}" failed:`,
                  t
                )
              ));
          })
        ),
          ea();
      }
      async function Z() {
        let e = new Map((await (0, p.Nc)()).map((e) => [e.gameId, e.zipUrl])),
          t = new Map(),
          a = [];
        for (let r of await ei()) {
          let i = t.get(r.gameId);
          i
            ? (0, h.P)(r, i, e.get(r.gameId))
              ? (a.push(i), t.set(r.gameId, r))
              : a.push(r)
            : t.set(r.gameId, r);
        }
        let r = !1;
        for (let e of a) {
          let t = (0, h.yX)(e);
          await l.Filesystem.rmdir({
            path: t,
            directory: l.Directory.Data,
            recursive: !0,
          }).catch((e) =>
            console.warn(`[deleteSupersededBuilds] removing "${t}" failed:`, e)
          ),
            (r = !0),
            console.log(`[deleteSupersededBuilds] removed "${t}"`);
        }
        r && ea();
      }
      async function q(e) {
        let t = (0, h.yX)(e);
        (await (0, f.s)(`${t}/${z}`, l.Directory.Data).catch(() => !0)) ||
          (await l.Filesystem.rmdir({
            path: t,
            directory: l.Directory.Data,
            recursive: !0,
          }).catch((e) =>
            console.warn(
              `[discardFailedDownload] removing the unfinished build "${t}" failed:`,
              e
            )
          ),
          console.log(
            `[discardFailedDownload] removed unfinished build "${t}"`
          ));
        let a = `${e.buildId}.zip`;
        (await (0, f.s)(a, l.Directory.Cache).catch(() => !1)) &&
          (await l.Filesystem.deleteFile({
            path: a,
            directory: l.Directory.Cache,
          }).catch((e) =>
            console.warn(
              `[discardFailedDownload] removing the abandoned zip "${a}" failed:`,
              e
            )
          ),
          console.log(`[discardFailedDownload] removed abandoned zip "${a}"`));
      }
      async function Y() {
        for (let e of await (0, f.f)(h.dp, l.Directory.Data)) {
          if ("directory" !== e.type) continue;
          let t = `${h.dp}/${e.name}`;
          for (let a of await (0, f.f)(t, l.Directory.Data)) {
            if ("directory" !== a.type) continue;
            let r = `${t}/${a.name}`;
            (await (0, f.s)(`${r}/${z}`, l.Directory.Data)) ||
              (await l.Filesystem.rmdir({
                path: r,
                directory: l.Directory.Data,
                recursive: !0,
              }).catch(() => void 0),
              console.log(
                `[sweepPartialDownloads] removed unfinished build "${e.name}/${a.name}"`
              ));
          }
        }
        for (let e of (await s.LiveUpdate.isSyncing()
          .then((e) => {
            let { syncing: t } = e;
            return t;
          })
          .catch(() => !1))
          ? []
          : await (0, f.f)("", l.Directory.Cache))
          "directory" !== e.type &&
            e.name.endsWith(".zip") &&
            (await l.Filesystem.deleteFile({
              path: e.name,
              directory: l.Directory.Cache,
            }).catch((t) =>
              console.warn(
                `[sweepPartialDownloads] removing the abandoned zip "${e.name}" failed:`,
                t
              )
            ),
            console.log(
              `[sweepPartialDownloads] removed abandoned zip "${e.name}"`
            ));
        ea();
      }
      let V = null;
      function Q() {
        return (V ??= Y().finally(() => {
          V = null;
        }));
      }
      async function ee(e, t) {
        let a,
          r = (0, h.PL)(e);
        try {
          a = (
            await l.Filesystem.readdir({ path: r, directory: l.Directory.Data })
          ).files;
        } catch (t) {
          return (
            console.warn(
              `[readDownloadedGames] could not list the builds of "${e}":`,
              t
            ),
            []
          );
        }
        return (
          await Promise.all(
            a
              .filter((e) => "directory" === e.type)
              .map(async (a) => {
                try {
                  let { data: e } = await l.Filesystem.readFile({
                    path: `${r}/${a.name}/${z}`,
                    directory: l.Directory.Data,
                  });
                  return { ...JSON.parse((0, u.YU)(e)), ...t };
                } catch {
                  return (
                    console.warn(
                      `[readDownloadedGames] no metadata file for "${e}/${a.name}" — old download or incomplete, skip`
                    ),
                    null
                  );
                }
              })
          )
        ).filter((e) => null !== e);
      }
      async function et() {
        let e = await (0, f.f)(h.dp, l.Directory.Data);
        return (
          await Promise.all(
            e
              .filter((e) => "directory" === e.type)
              .map((e) =>
                ee(e.name, {
                  coverSrc: o.Capacitor.convertFileSrc(`${e.uri}/${h.gh}`),
                  loadingCoverSrc: o.Capacitor.convertFileSrc(
                    `${e.uri}/${h.l4}`
                  ),
                })
              )
          )
        )
          .flat()
          .sort((e, t) => t.downloadedAt - e.downloadedAt);
      }
      function ea() {
        r = void 0;
      }
      function er() {
        return r?.entries;
      }
      function ei() {
        if (r) return r.promise;
        let e = {
          promise: et().then(
            (t) => ((e.entries = t), t),
            (t) => (
              console.warn(
                "[readDownloadedGames] could not read the downloaded games:",
                t
              ),
              r === e && ea(),
              []
            )
          ),
        };
        return (r = e), e.promise;
      }
    },
    15992: (e, t, a) => {
      a.d(t, { yl: () => r });
      let r = {
        iframe: {
          type: "other",
          id: "iframe",
          name: "Externally hosted (iframe)",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !1,
          isRecommendedLoader: !0,
          isNonRecommendedLoader: !1,
          supportsIFrameApsLoader: !0,
          withDataSave: !0,
        },
        html5: {
          type: "other",
          id: "html5",
          name: "HTML5",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !1,
          isRecommendedLoader: !0,
          isNonRecommendedLoader: !1,
          supportsIFrameApsLoader: !0,
          withDataSave: !0,
        },
        external: {
          type: "other",
          id: "external",
          name: "External",
          limitedAdminUpdate: !0,
          hasHtml5Fallback: !1,
          isRecommendedLoader: !1,
          isNonRecommendedLoader: !1,
          supportsIFrameApsLoader: !1,
          withDataSave: !1,
        },
        ruffle: {
          type: "other",
          id: "ruffle",
          name: "Ruffle",
          limitedAdminUpdate: !0,
          hasHtml5Fallback: !1,
          isRecommendedLoader: !1,
          isNonRecommendedLoader: !1,
          supportsIFrameApsLoader: !1,
          withDataSave: !1,
        },
        flash: {
          type: "other",
          id: "flash",
          name: "Flash",
          limitedAdminUpdate: !0,
          hasHtml5Fallback: !1,
          isRecommendedLoader: !1,
          isNonRecommendedLoader: !1,
          supportsIFrameApsLoader: !1,
          withDataSave: !1,
        },
        fake: {
          type: "other",
          id: "fake",
          name: "Fake",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !1,
          isRecommendedLoader: !1,
          isNonRecommendedLoader: !1,
          supportsIFrameApsLoader: !1,
          withDataSave: !1,
        },
        error: {
          type: "other",
          id: "error",
          name: "Error",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !1,
          isRecommendedLoader: !1,
          isNonRecommendedLoader: !1,
          supportsIFrameApsLoader: !1,
          withDataSave: !1,
        },
        unity6: {
          type: "unity",
          id: "unity6",
          name: "Unity 6",
          withDataSave: !0,
          withSitelock: !0,
          unityLoaderType: "2020",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !1,
          isRecommendedLoader: !0,
          isNonRecommendedLoader: !1,
          supportsCustomBuild: !0,
          supportsBanners: !0,
          supportsAps: !0,
        },
        unity2023: {
          type: "unity",
          id: "unity2023",
          name: "Unity 2023",
          withDataSave: !0,
          withSitelock: !0,
          unityLoaderType: "2020",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !1,
          isRecommendedLoader: !1,
          isNonRecommendedLoader: !0,
          supportsCustomBuild: !1,
          supportsBanners: !0,
          supportsAps: !0,
        },
        unity2022: {
          type: "unity",
          id: "unity2022",
          name: "Unity 2022",
          withDataSave: !0,
          withSitelock: !0,
          unityLoaderType: "2020",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !1,
          isRecommendedLoader: !0,
          isNonRecommendedLoader: !1,
          supportsCustomBuild: !1,
          supportsBanners: !0,
          supportsAps: !0,
        },
        unity2021: {
          type: "unity",
          id: "unity2021",
          name: "Unity 2021",
          withDataSave: !0,
          withSitelock: !0,
          unityLoaderType: "2020",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !1,
          isRecommendedLoader: !1,
          isNonRecommendedLoader: !0,
          supportsCustomBuild: !1,
          supportsBanners: !0,
          supportsAps: !0,
        },
        unity2020: {
          type: "unity",
          id: "unity2020",
          name: "Unity 2020",
          withDataSave: !0,
          withSitelock: !0,
          unityLoaderType: "2020",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !1,
          isRecommendedLoader: !1,
          isNonRecommendedLoader: !0,
          supportsCustomBuild: !1,
          supportsBanners: !0,
          supportsAps: !0,
        },
        unity2019: {
          type: "unity",
          id: "unity2019",
          name: "Unity 2019",
          withDataSave: !0,
          withSitelock: !0,
          unityLoaderType: "5.6",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !1,
          isRecommendedLoader: !1,
          isNonRecommendedLoader: !0,
          supportsCustomBuild: !1,
          supportsBanners: !0,
          supportsAps: !0,
        },
        unity2018: {
          type: "unity",
          id: "unity2018",
          name: "Unity 2018",
          withDataSave: !0,
          withSitelock: !0,
          unityLoaderType: "5.6",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !1,
          isRecommendedLoader: !1,
          isNonRecommendedLoader: !0,
          supportsCustomBuild: !1,
          supportsBanners: !0,
          supportsAps: !0,
        },
        unity2017: {
          type: "unity",
          id: "unity2017",
          name: "Unity 2017",
          withDataSave: !0,
          withSitelock: !0,
          unityLoaderType: "5.6",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !1,
          isRecommendedLoader: !1,
          isNonRecommendedLoader: !0,
          supportsCustomBuild: !1,
          supportsBanners: !0,
          supportsAps: !0,
        },
        "5.6.x": {
          type: "unity",
          id: "5.6.x",
          name: "Unity 5.6",
          withDataSave: !0,
          withSitelock: !0,
          unityLoaderType: "5.6",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !1,
          isRecommendedLoader: !1,
          isNonRecommendedLoader: !0,
          supportsCustomBuild: !1,
          supportsBanners: !0,
          supportsAps: !0,
        },
        "5.4.x": {
          type: "unity",
          id: "5.4.x",
          name: "Unity 5.4",
          withDataSave: !1,
          withSitelock: !1,
          unityLoaderType: "5.4",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !1,
          isRecommendedLoader: !1,
          isNonRecommendedLoader: !1,
          supportsCustomBuild: !1,
          supportsBanners: !1,
          supportsAps: !1,
        },
        godot: {
          type: "other",
          id: "godot",
          name: "Godot",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !0,
          isRecommendedLoader: !0,
          isNonRecommendedLoader: !1,
          supportsIFrameApsLoader: !0,
          withDataSave: !0,
        },
        defold: {
          type: "other",
          id: "defold",
          name: "Defold",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !0,
          isRecommendedLoader: !0,
          isNonRecommendedLoader: !1,
          supportsIFrameApsLoader: !0,
          withDataSave: !0,
        },
        gamemaker: {
          type: "other",
          id: "gamemaker",
          name: "GameMaker",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !0,
          isRecommendedLoader: !0,
          isNonRecommendedLoader: !1,
          supportsIFrameApsLoader: !0,
          withDataSave: !0,
        },
        gdevelop: {
          type: "other",
          id: "gdevelop",
          name: "GDevelop",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !0,
          isRecommendedLoader: !0,
          isNonRecommendedLoader: !1,
          supportsIFrameApsLoader: !0,
          withDataSave: !0,
        },
        cocos: {
          type: "other",
          id: "cocos",
          name: "Cocos",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !0,
          isRecommendedLoader: !0,
          isNonRecommendedLoader: !1,
          supportsIFrameApsLoader: !0,
          withDataSave: !0,
        },
        playcanvas: {
          type: "other",
          id: "playcanvas",
          name: "PlayCanvas",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !0,
          isRecommendedLoader: !0,
          isNonRecommendedLoader: !1,
          supportsIFrameApsLoader: !0,
          withDataSave: !0,
        },
        unreal: {
          type: "other",
          id: "unreal",
          name: "Unreal",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !0,
          isRecommendedLoader: !0,
          isNonRecommendedLoader: !1,
          supportsIFrameApsLoader: !0,
          withDataSave: !0,
        },
        construct: {
          type: "other",
          id: "construct",
          name: "Construct",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !0,
          isRecommendedLoader: !0,
          isNonRecommendedLoader: !1,
          supportsIFrameApsLoader: !0,
          withDataSave: !0,
        },
        layaair: {
          type: "other",
          id: "layaair",
          name: "LayaAir",
          limitedAdminUpdate: !1,
          hasHtml5Fallback: !0,
          isRecommendedLoader: !0,
          isNonRecommendedLoader: !1,
          supportsIFrameApsLoader: !0,
          withDataSave: !0,
        },
      };
    },
    16614: (e, t, a) => {
      var r = Object.create
        ? function (e, t, a, r) {
            void 0 === r && (r = a);
            var i = Object.getOwnPropertyDescriptor(t, a);
            (!i ||
              ("get" in i ? !t.__esModule : i.writable || i.configurable)) &&
              (i = {
                enumerable: !0,
                get: function () {
                  return t[a];
                },
              }),
              Object.defineProperty(e, r, i);
          }
        : function (e, t, a, r) {
            void 0 === r && (r = a), (e[r] = t[a]);
          };
      Object.defineProperty(t, "__esModule", { value: !0 });
      var i = a(16186);
      for (var o in i)
        "default" === o ||
          Object.prototype.hasOwnProperty.call(t, o) ||
          r(t, i, o);
    },
    20754: (e, t, a) => {
      var r = Object.create
        ? function (e, t, a, r) {
            void 0 === r && (r = a);
            var i = Object.getOwnPropertyDescriptor(t, a);
            (!i ||
              ("get" in i ? !t.__esModule : i.writable || i.configurable)) &&
              (i = {
                enumerable: !0,
                get: function () {
                  return t[a];
                },
              }),
              Object.defineProperty(e, r, i);
          }
        : function (e, t, a, r) {
            void 0 === r && (r = a), (e[r] = t[a]);
          };
      Object.defineProperty(t, "__esModule", { value: !0 });
      var i = a(34046);
      for (var o in i)
        "default" === o ||
          Object.prototype.hasOwnProperty.call(t, o) ||
          r(t, i, o);
    },
    57897: (e, t, a) => {
      function r(e) {
        let t = "";
        for (let a = 0; a < e.length; a += 8192)
          t += String.fromCharCode(...e.subarray(a, a + 8192));
        return btoa(t);
      }
      function i(e) {
        return r(new TextEncoder().encode(e));
      }
      function o(e) {
        let t = atob(e);
        return new TextDecoder().decode(
          Uint8Array.from(t, (e) => e.charCodeAt(0))
        );
      }
      a.d(t, { Ii: () => i, YU: () => o, nk: () => r });
    },
    78956: (e, t, a) => {
      a.d(t, {
        Nh: () => h,
        P: () => c,
        PL: () => s,
        Ut: () => o,
        W7: () => r,
        Z: () => l,
        b9: () => y,
        dp: () => i,
        gh: () => m,
        l4: () => u,
        oC: () => w,
        rO: () => f,
        so: () => n,
        un: () => g,
        x2: () => p,
        yX: () => d,
      });
      let r = "offline-games",
        i = `${r}/game-files`,
        o = `${r}/shared`,
        n = `${r}/downloads`,
        l = [i, o, n];
      function s(e) {
        return `${i}/${e}`;
      }
      function d(e) {
        return `${s(e.gameSlug)}/${
          void 0 === e.zipUrl
            ? e.buildId
            : e.zipUrl
                .slice(e.zipUrl.lastIndexOf("/") + 1)
                .replace(/\.zip$/, "")
        }`;
      }
      function c(e, t, a) {
        let r = void 0 !== a && e.zipUrl === a;
        return r !== (void 0 !== a && t.zipUrl === a)
          ? r
          : e.downloadedAt > t.downloadedAt;
      }
      let m = "cover.png",
        u = "loading-cover.png",
        p = `${r}/catalog-covers`;
      function y(e) {
        return `${e}.png`;
      }
      function f(e, t) {
        return `${e}/${y(t)}`;
      }
      function h(e) {
        return e.replace(/\.png$/, "");
      }
      let w = `${r}/profile`;
      function g(e, t) {
        return `${w}/${e}/avatar.${t}`;
      }
    },
    81465: (e, t, a) => {
      a.d(t, { f: () => o, s: () => n });
      var r = a(85707);
      function i(e) {
        return e?.code === "OS-PLUG-FILE-0008";
      }
      async function o(e, t) {
        try {
          return (await r.Filesystem.readdir({ path: e, directory: t })).files;
        } catch (e) {
          if (i(e)) return [];
          throw e;
        }
      }
      async function n(e, t) {
        try {
          return await r.Filesystem.stat({ path: e, directory: t }), !0;
        } catch (e) {
          if (i(e)) return !1;
          throw e;
        }
      }
    },
    85707: (e, t, a) => {
      var r = Object.create
        ? function (e, t, a, r) {
            void 0 === r && (r = a);
            var i = Object.getOwnPropertyDescriptor(t, a);
            (!i ||
              ("get" in i ? !t.__esModule : i.writable || i.configurable)) &&
              (i = {
                enumerable: !0,
                get: function () {
                  return t[a];
                },
              }),
              Object.defineProperty(e, r, i);
          }
        : function (e, t, a, r) {
            void 0 === r && (r = a), (e[r] = t[a]);
          };
      Object.defineProperty(t, "__esModule", { value: !0 });
      var i = a(3992);
      for (var o in i)
        "default" === o ||
          Object.prototype.hasOwnProperty.call(t, o) ||
          r(t, i, o);
    },
  },
]);
