!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (null != n) for (var a in n) n.hasOwnProperty(a) && (e[a] = n[a]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "87364d88-0be4-4cfd-bbab-4c45eb42500b"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-87364d88-0be4-4cfd-bbab-4c45eb42500b"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [54135],
    {
      10862: (e, t, n) => {
        "use strict";
        n.d(t, { Ff: () => r, oq: () => i, po: () => s });
        let a = null,
          o = new Set();
        function i(e) {
          return (null === a || a === e) && ((a = e), !0);
        }
        function s(e) {
          a === e && ((a = null), o.forEach((e) => e()));
        }
        function r(e) {
          return (
            o.add(e),
            () => {
              o.delete(e);
            }
          );
        }
      },
      28967: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => s });
        var a = n(50293),
          o = n(45364);
        let i = [
            "#9258e3",
            "#d58939",
            "#09ffea",
            "#ffef4b",
            "#4bd3ff",
            "#ff4bde",
            "#a399f4",
            "#f27b3e",
            "#5dff4b",
            "#ffea4b",
            "#09ffea",
            "#ffa62a",
          ],
          s = async function (e) {
            let t =
                arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
              s =
                arguments.length > 2 && void 0 !== arguments[2] && arguments[2],
              r =
                arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
            if ((o.A.isFullscreen() && !r) || (0, a.Kg)(e)) return;
            let l = await n.e(74461).then(n.bind(n, 74461)),
              c = l.default || l,
              d = c.create(void 0, { resize: !0, useWorker: !0 });
            if (s && !t) {
              let e = ["#FF6B1A", "#9D4EDD", "#000000", "#FFA500"],
                t = c.shapeFromPath({
                  path: "M0 -10 L2.5 -2.5 L10 0 L2.5 2.5 L0 10 L-2.5 2.5 L-10 0 L-2.5 -2.5 Z",
                }),
                n = c.shapeFromPath({
                  path: "M0 -8 C-4 -8 -6 -6 -6 -2 L-6 6 L-4 4 L-2 6 L0 4 L2 6 L4 4 L6 6 L6 -2 C6 -6 4 -8 0 -8 Z",
                }),
                a = c.shapeFromPath({
                  path: "M0 0 L-2 -2 C-4 -3 -6 -2 -8 0 C-6 1 -5 2 -3 2 L-1 1 L-1 3 L1 3 L1 1 L3 2 C5 2 6 1 8 0 C6 -2 4 -3 2 -2 Z",
                });
              d({
                particleCount: 80,
                angle: 60,
                spread: 70,
                origin: { x: 0 },
                colors: e,
                shapes: [t, n, a],
                scalar: 1.2,
                zIndex: 1405,
              }),
                d({
                  particleCount: 80,
                  angle: 120,
                  spread: 70,
                  origin: { x: 1 },
                  colors: e,
                  shapes: [t, n, a],
                  scalar: 1.2,
                  zIndex: 1405,
                });
            } else if (t) {
              let e = c.shapeFromText({ text: "\uD83C\uDFC6", scalar: 5 });
              d({
                particleCount: 30,
                spread: 130,
                origin: { x: 0 },
                shapes: [e],
                scalar: 5,
                zIndex: 1405,
              }),
                d({
                  particleCount: 30,
                  spread: 130,
                  origin: { x: 1 },
                  shapes: [e],
                  scalar: 5,
                  zIndex: 1405,
                });
            } else
              d({
                particleCount: 100,
                angle: 60,
                spread: 65,
                origin: { x: 0 },
                colors: i,
                zIndex: 1405,
              }),
                d({
                  particleCount: 100,
                  angle: 120,
                  spread: 65,
                  origin: { x: 1 },
                  colors: i,
                  zIndex: 1405,
                });
          };
      },
      34489: (e) => {
        e.exports = {
          aboveBottomNavigation:
            "CelebrationNudge_aboveBottomNavigation__Ow1_a",
        };
      },
      54135: (e, t, n) => {
        "use strict";
        n.r(t), n.d(t, { default: () => p });
        var a = n(6029),
          o = n(75155),
          i = n(55729),
          s = n(77650),
          r = n(79942),
          l = n(8023),
          c = n(54944),
          d = n(4230),
          u = n(45364),
          g = n(28967),
          _ = n(71684),
          b = n(10862),
          y = n(74021),
          f = n(3540);
        let m = {
          birthday: "birthday-nudge",
          anniversary: "anniversary-nudge",
        };
        function h(e) {
          console.error(e);
        }
        var x = n(34489),
          v = n.n(x);
        let p = () => {
          let e,
            t,
            n,
            x,
            p,
            N = (0, o.c)(14),
            {
              open: w,
              occasion: L,
              years: A,
              username: C,
              onAction: j,
              onClose: Z,
            } = (function () {
              let e,
                t,
                n,
                a,
                s,
                r,
                l,
                c = (0, o.c)(24),
                {
                  occasion: x,
                  forced: v,
                  years: p,
                  username: N,
                  userId: w,
                } = (0, f.v)(),
                { crazyAnalyticsService: L } = i.useContext(_.A).services,
                A = i.useContext(d.A),
                [C, j] = i.useState(!1),
                Z = i.useRef(!1);
              C && !x && j(!1),
                c[0] !== L ||
                c[1] !== A ||
                c[2] !== v ||
                c[3] !== x ||
                c[4] !== w
                  ? ((e = () => {
                      if (!x) return;
                      let e = m[x],
                        t = !1,
                        n = () => {
                          !t ||
                            Z.current ||
                            !w ||
                            (!v && (0, y.Am)(x, w, new Date())) ||
                            (!(u.A.isFullscreen() || u.A.isFakeFullscreen()) &&
                              (0, b.oq)(e) &&
                              ((Z.current = !0),
                              (0, y.Lx)(x, w, new Date()),
                              j(!0),
                              L.notificationActionEvent(e, "shown"),
                              (0, g.A)(A).catch(h)));
                        },
                        a = window.setTimeout(
                          () => {
                            (t = !0), n();
                          },
                          v ? 0 : y.Yr
                        );
                      u.A.addFullscreenListener(n),
                        u.A.addFakeFullscreenListener(n);
                      let o = (0, b.Ff)(n);
                      return () => {
                        window.clearTimeout(a),
                          u.A.removeFullscreenListener(n),
                          u.A.removeFakeFullscreenListener(n),
                          o();
                      };
                    }),
                    (t = [x, v, L, A, w]),
                    (c[0] = L),
                    (c[1] = A),
                    (c[2] = v),
                    (c[3] = x),
                    (c[4] = w),
                    (c[5] = e),
                    (c[6] = t))
                  : ((e = c[5]), (t = c[6])),
                i.useEffect(e, t),
                c[7] !== x || c[8] !== C
                  ? ((n = () => {
                      if (!C || !x) return;
                      let e = m[x];
                      return () => (0, b.po)(e);
                    }),
                    (a = [C, x]),
                    (c[7] = x),
                    (c[8] = C),
                    (c[9] = n),
                    (c[10] = a))
                  : ((n = c[9]), (a = c[10])),
                i.useEffect(n, a),
                c[11] !== L || c[12] !== x
                  ? ((s = () => {
                      x && L.notificationActionEvent(m[x], "clicked"), j(!1);
                    }),
                    (c[11] = L),
                    (c[12] = x),
                    (c[13] = s))
                  : (s = c[13]);
              let F = s;
              c[14] !== L || c[15] !== x
                ? ((r = (e) => {
                    x &&
                      L.notificationActionEvent(
                        m[x],
                        "timeout" === e ? "ignored" : "closed"
                      ),
                      j(!1);
                  }),
                  (c[14] = L),
                  (c[15] = x),
                  (c[16] = r))
                : (r = c[16]);
              let E = r;
              return (
                c[17] !== x ||
                c[18] !== F ||
                c[19] !== E ||
                c[20] !== C ||
                c[21] !== N ||
                c[22] !== p
                  ? ((l = {
                      open: C,
                      occasion: x,
                      years: p,
                      username: N,
                      onAction: F,
                      onClose: E,
                    }),
                    (c[17] = x),
                    (c[18] = F),
                    (c[19] = E),
                    (c[20] = C),
                    (c[21] = N),
                    (c[22] = p),
                    (c[23] = l))
                  : (l = c[23]),
                l
              );
            })(),
            F = (0, l.d)(),
            E = "anniversary" === L;
          N[0] !== E || N[1] !== C || N[2] !== A
            ? ((e = E
                ? (0, a.jsx)(r.x6, {
                    id: "common.celebrationNudge.anniversary.title",
                    values: { username: C, years: A },
                  })
                : (0, a.jsxs)(a.Fragment, {
                    children: [
                      (0, a.jsx)(r.x6, {
                        id: "common.celebrationNudge.birthday.title",
                      }),
                      "\xa0\uD83C\uDF89",
                    ],
                  })),
              (t = E
                ? (0, a.jsx)(r.x6, {
                    id: "common.celebrationNudge.anniversary.body",
                    values: { username: C, years: A },
                  })
                : (0, a.jsx)(r.x6, {
                    id: "common.celebrationNudge.birthday.body",
                    values: { username: C },
                  })),
              (N[0] = E),
              (N[1] = C),
              (N[2] = A),
              (N[3] = e),
              (N[4] = t))
            : ((e = N[3]), (t = N[4])),
            N[5] === Symbol.for("react.memo_cache_sentinel")
              ? ((n = (0, a.jsx)(r.x6, {
                  id: "common.celebrationNudge.action",
                })),
                (N[5] = n))
              : (n = N[5]),
            N[6] === Symbol.for("react.memo_cache_sentinel")
              ? ((x = s.Ru._("common.celebrationNudge.close")), (N[6] = x))
              : (x = N[6]);
          let I = F ? v().aboveBottomNavigation : void 0;
          return (
            N[7] !== j ||
            N[8] !== Z ||
            N[9] !== w ||
            N[10] !== e ||
            N[11] !== t ||
            N[12] !== I
              ? ((p = (0, a.jsx)(c.A, {
                  open: w,
                  title: e,
                  body: t,
                  actionLabel: n,
                  actionIcon: "play-triangle",
                  closeLabel: x,
                  className: I,
                  onAction: j,
                  onClose: Z,
                })),
                (N[7] = j),
                (N[8] = Z),
                (N[9] = w),
                (N[10] = e),
                (N[11] = t),
                (N[12] = I),
                (N[13] = p))
              : (p = N[13]),
            p
          );
        };
      },
      54944: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => _ });
        var a = n(6029),
          o = n(75155),
          i = n(55729),
          s = n(50212),
          r = n(56760),
          l = n(94618),
          c = n(93800),
          d = n(95848),
          u = n.n(d);
        let g = "crazygames/ziggy_nudge3x.png",
          _ = (e) => {
            let t,
              n,
              d,
              _,
              b,
              y,
              f,
              m,
              h,
              x,
              v,
              p,
              N,
              w,
              L,
              A,
              C,
              j,
              Z,
              F = (0, o.c)(48),
              {
                open: E,
                title: I,
                body: z,
                actionLabel: k,
                actionIcon: S,
                closeLabel: M,
                autoCloseMs: B,
                className: D,
                onAction: T,
                onClose: P,
              } = e,
              R = i.useId(),
              [q, H] = i.useState(E),
              [O, V] = i.useState(E);
            if (
              (E !== O && (V(E), E && H(!0)),
              F[0] !== E
                ? ((t = () => {
                    if (E) return;
                    let e = window.setTimeout(() => H(!1), 200);
                    return () => window.clearTimeout(e);
                  }),
                  (n = [E]),
                  (F[0] = E),
                  (F[1] = t),
                  (F[2] = n))
                : ((t = F[1]), (n = F[2])),
              i.useEffect(t, n),
              !q || "u" < typeof document)
            )
              return null;
            let K = !E && u().leaving;
            F[3] !== D || F[4] !== K
              ? ((d = (0, s.A)(u().nudge, K, D)),
                (F[3] = D),
                (F[4] = K),
                (F[5] = d))
              : (d = F[5]);
            let W = `${void 0 === B ? 2e4 : B}ms`;
            F[6] !== W
              ? ((_ = {
                  "--nudge-auto-close-duration": W,
                  "--nudge-transition-duration": "200ms",
                }),
                (F[6] = W),
                (F[7] = _))
              : (_ = F[7]);
            let G = _;
            return (
              F[8] !== I || F[9] !== R
                ? ((b = (0, a.jsx)("div", {
                    id: R,
                    className: u().title,
                    children: I,
                  })),
                  (F[8] = I),
                  (F[9] = R),
                  (F[10] = b))
                : (b = F[10]),
              F[11] !== z
                ? ((y = (0, a.jsx)("div", {
                    className: u().body,
                    children: z,
                  })),
                  (F[11] = z),
                  (F[12] = y))
                : (y = F[12]),
              F[13] !== y || F[14] !== b
                ? ((f = (0, a.jsxs)("div", {
                    className: u().text,
                    children: [b, y],
                  })),
                  (F[13] = y),
                  (F[14] = b),
                  (F[15] = f))
                : (f = F[15]),
              F[16] !== S
                ? ((m = S && (0, a.jsx)(c.A, { name: S, size: 20 })),
                  (F[16] = S),
                  (F[17] = m))
                : (m = F[17]),
              F[18] !== k
                ? ((h = (0, a.jsx)("span", { children: k })),
                  (F[18] = k),
                  (F[19] = h))
                : (h = F[19]),
              F[20] !== T || F[21] !== m || F[22] !== h
                ? ((x = (0, a.jsxs)("button", {
                    type: "button",
                    className: u().action,
                    onClick: T,
                    children: [m, h],
                  })),
                  (F[20] = T),
                  (F[21] = m),
                  (F[22] = h),
                  (F[23] = x))
                : (x = F[23]),
              F[24] !== f || F[25] !== x
                ? ((v = (0, a.jsxs)("div", {
                    className: u().bubble,
                    children: [f, x],
                  })),
                  (F[24] = f),
                  (F[25] = x),
                  (F[26] = v))
                : (v = F[26]),
              F[27] === Symbol.for("react.memo_cache_sentinel")
                ? ((p = (0, a.jsx)("svg", {
                    className: u().tail,
                    width: "26",
                    height: "13",
                    viewBox: "0 0 25.7783 12.9639",
                    "aria-hidden": !0,
                    children: (0, a.jsx)("path", {
                      d: "M25.7783 0C22.7099 4.3149 16.3804 12.13 12.9082 12.9531V12.9629C12.902 12.9615 12.8959 12.9594 12.8896 12.958C12.8821 12.9597 12.8747 12.9622 12.8672 12.9639V12.9521C9.39437 12.1253 3.06752 4.31366 0 0H25.7783Z",
                    }),
                  })),
                  (F[27] = p))
                : (p = F[27]),
              F[28] !== v
                ? ((N = (0, a.jsxs)("div", {
                    className: u().speech,
                    children: [v, p],
                  })),
                  (F[28] = v),
                  (F[29] = N))
                : (N = F[29]),
              F[30] !== P
                ? ((w = () => P("dismissed")), (F[30] = P), (F[31] = w))
                : (w = F[31]),
              F[32] !== P || F[33] !== E
                ? ((L = (0, a.jsx)("svg", {
                    className: u().countdown,
                    viewBox: "0 0 30 30",
                    "aria-hidden": !0,
                    children: (0, a.jsx)("circle", {
                      className: u().countdownRing,
                      cx: "15",
                      cy: "15",
                      r: "12",
                      pathLength: 100,
                      onAnimationEnd: () => {
                        E && P("timeout");
                      },
                    }),
                  })),
                  (F[32] = P),
                  (F[33] = E),
                  (F[34] = L))
                : (L = F[34]),
              F[35] === Symbol.for("react.memo_cache_sentinel")
                ? ((A = (0, a.jsx)(c.A, {
                    name: "close",
                    className: u().closeIcon,
                  })),
                  (F[35] = A))
                : (A = F[35]),
              F[36] !== M || F[37] !== w || F[38] !== L
                ? ((C = (0, a.jsxs)("button", {
                    type: "button",
                    className: u().close,
                    "aria-label": M,
                    onClick: w,
                    children: [L, A],
                  })),
                  (F[36] = M),
                  (F[37] = w),
                  (F[38] = L),
                  (F[39] = C))
                : (C = F[39]),
              F[40] === Symbol.for("react.memo_cache_sentinel")
                ? ((j = (0, a.jsx)("img", {
                    className: u().ziggy,
                    src: (0, l.Ay)(g, { width: 153 }),
                    srcSet: (0, l.Wn)(g, { width: 153 }),
                    width: 153,
                    height: 111,
                    alt: "",
                  })),
                  (F[40] = j))
                : (j = F[40]),
              F[41] !== N ||
              F[42] !== C ||
              F[43] !== j ||
              F[44] !== d ||
              F[45] !== G ||
              F[46] !== R
                ? ((Z = (0, r.createPortal)(
                    (0, a.jsxs)("div", {
                      className: d,
                      role: "dialog",
                      "aria-labelledby": R,
                      style: G,
                      children: [N, C, j],
                    }),
                    document.body
                  )),
                  (F[41] = N),
                  (F[42] = C),
                  (F[43] = j),
                  (F[44] = d),
                  (F[45] = G),
                  (F[46] = R),
                  (F[47] = Z))
                : (Z = F[47]),
              Z
            );
          };
      },
      95848: (e) => {
        e.exports = {
          nudge: "ZiggyNudge_nudge__Hr6EJ",
          "nudge-enter": "ZiggyNudge_nudge-enter__e1VRF",
          leaving: "ZiggyNudge_leaving__s_TOI",
          "nudge-leave": "ZiggyNudge_nudge-leave__7qVlB",
          speech: "ZiggyNudge_speech___HOo3",
          bubble: "ZiggyNudge_bubble__ES82b",
          text: "ZiggyNudge_text__Ee_LI",
          title: "ZiggyNudge_title__NaEz3",
          body: "ZiggyNudge_body__ZgC_6",
          action: "ZiggyNudge_action__dgUoI",
          tail: "ZiggyNudge_tail__fibSq",
          close: "ZiggyNudge_close__xqem1",
          closeIcon: "ZiggyNudge_closeIcon__HNDZu",
          countdown: "ZiggyNudge_countdown__a6rBS",
          countdownRing: "ZiggyNudge_countdownRing__gB_vQ",
          "nudge-countdown": "ZiggyNudge_nudge-countdown__SEeGv",
          ziggy: "ZiggyNudge_ziggy__vp6ly",
        };
      },
    },
  ]);
