!(function () {
  try {
    var e =
      "u" > typeof window
        ? window
        : "u" > typeof global
        ? global
        : "u" > typeof globalThis
        ? globalThis
        : "u" > typeof self
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (null != n) for (var a in n) n.hasOwnProperty(a) && (e[a] = n[a]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-portal": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "59f78b89-e4dd-470c-a663-58f2cba0d472"),
      (e._sentryDebugIdIdentifier =
        "sentry-dbid-59f78b89-e4dd-470c-a663-58f2cba0d472"));
  } catch (e) {}
})(),
  (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [49181, 86092],
    {
      3495: (e) => {
        e.exports = {
          gameContainerDesktopRoot:
            "GameContainerDesktop_gameContainerDesktopRoot__qvoxU",
          gameContainer: "GameContainerDesktop_gameContainer__TT_xK",
          gameIframe: "GameContainerDesktop_gameIframe__6GEYI",
          iframeLoading: "GameContainerDesktop_iframeLoading__cy9LG",
        };
      },
      22463: (e, t, n) => {
        "use strict";
        n.d(t, { L: () => s, v: () => c });
        var a = n(55729);
        let r = new Set(),
          l = !1,
          i = null;
        function o() {
          r.forEach((e) => e());
        }
        function s() {
          console.log(
            "[offlineAdMessageStore] showOfflineRewardedAdMessage() called — triggering toast"
          ),
            i && clearTimeout(i),
            (i = setTimeout(() => {
              (l = !1), (i = null), o();
            }, 4e3)),
            l || ((l = !0), o());
        }
        function d(e) {
          return (
            r.add(e),
            () => {
              r.delete(e);
            }
          );
        }
        function c() {
          return (0, a.useSyncExternalStore)(d, m, u);
        }
        function u() {
          return !1;
        }
        function m() {
          return l;
        }
      },
      35081: (e) => {
        e.exports = {
          czyButton: "AdUnit_czyButton__VfkFq",
          "czyButton--contained--purple":
            "AdUnit_czyButton--contained--purple__voBXC",
          "czyButton--contained--white":
            "AdUnit_czyButton--contained--white__k2A9P",
          "czyButton--contained--grey":
            "AdUnit_czyButton--contained--grey__4XyB6",
          "czyButton--contained--warning":
            "AdUnit_czyButton--contained--warning__n6K1B",
          "czyButton--contained--alert":
            "AdUnit_czyButton--contained--alert__I8I4C",
          "czyButton--contained--success":
            "AdUnit_czyButton--contained--success__f7DGM",
          "czyButton--contained--black":
            "AdUnit_czyButton--contained--black__gCaQV",
          "czyButton--contained--green-gradient":
            "AdUnit_czyButton--contained--green-gradient__kSob9",
          "czyButton--contained--animated-green-gradient":
            "AdUnit_czyButton--contained--animated-green-gradient__4dLQb",
          "scroll-gradient": "AdUnit_scroll-gradient__kdLyA",
          "czyButton--outlined--purple":
            "AdUnit_czyButton--outlined--purple__wetQ0",
          "czyButton--link--purple": "AdUnit_czyButton--link--purple__pZ2zl",
          "czyButton--outlined--white":
            "AdUnit_czyButton--outlined--white__c54pa",
          "czyButton--link--white": "AdUnit_czyButton--link--white__Im23U",
          "czyButton--outlined--grey":
            "AdUnit_czyButton--outlined--grey__mIDlb",
          "czyButton--link--grey": "AdUnit_czyButton--link--grey__AhXmb",
          "czyButton--outlined--warning":
            "AdUnit_czyButton--outlined--warning__EoPir",
          "czyButton--link--warning": "AdUnit_czyButton--link--warning__HAxPm",
          "czyButton--outlined--alert":
            "AdUnit_czyButton--outlined--alert__drksZ",
          "czyButton--link--alert": "AdUnit_czyButton--link--alert__57TEu",
          "czyButton--outlined--success":
            "AdUnit_czyButton--outlined--success__0lU53",
          "czyButton--link--success": "AdUnit_czyButton--link--success__lmj_h",
          "czyButton--outlined": "AdUnit_czyButton--outlined__GiMYZ",
          "czyButton--disabled": "AdUnit_czyButton--disabled__raKC9",
          "czyButton--height50": "AdUnit_czyButton--height50__gZ18m",
          "czyButton--height34": "AdUnit_czyButton--height34__7t5me",
          "czyButton--height28": "AdUnit_czyButton--height28__ywrcI",
          "czyButton--fullWidth": "AdUnit_czyButton--fullWidth___2bRc",
          "czyButton--headerIcon": "AdUnit_czyButton--headerIcon__DNaJ8",
          "czyButton--headerIcon--desktop":
            "AdUnit_czyButton--headerIcon--desktop__xhCBv",
          "czyButton--headerIcon--mobile":
            "AdUnit_czyButton--headerIcon--mobile__HccLa",
          "czyButton--headerIcon--withLabel":
            "AdUnit_czyButton--headerIcon--withLabel__N8XfV",
          adUnitRoot: "AdUnit_adUnitRoot__QUPaT",
          adUnitPaper: "AdUnit_adUnitPaper__hyYgu",
          innerWrapper: "AdUnit_innerWrapper__wpS4D",
          adSlot: "AdUnit_adSlot__JJinj",
          adWrapper: "AdUnit_adWrapper__OIK0n",
          adBlockWarning: "AdUnit_adBlockWarning___3c3B",
          alternativeAdWrapper: "AdUnit_alternativeAdWrapper__ylHEj",
          label: "AdUnit_label__E6Sg3",
          labelVertical: "AdUnit_labelVertical__iqLlA",
        };
      },
      42500: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => _ });
        var a = n(6029),
          r = n(75155),
          l = n(55729),
          i = n(32994),
          o = n(77650),
          s = n(50212),
          d = n(37522);
        let c = (e) => e.toString().padStart(2, "0");
        var u = n(86268),
          m = n.n(u);
        let _ = (e) => {
          let t,
            n,
            u,
            _,
            g,
            y = (0, r.c)(11),
            { nextResetAt: h, className: p } = e,
            f = (function (e) {
              let t,
                n,
                a,
                [r, i] = l.useState(null);
              return (l.useEffect(() => {
                let e = () => i(Date.now()),
                  t = window.setTimeout(e, 0),
                  n = window.setInterval(e, 1e3);
                return () => {
                  window.clearTimeout(t), window.clearInterval(n);
                };
              }, []),
              null === r)
                ? null
                : ((n = Math.floor(
                    (t = Math.max(
                      0,
                      Math.floor(
                        ((e ? new Date(e) : (0, d.qA)(new Date(r))).getTime() -
                          r) /
                          1e3
                      )
                    )) / 3600
                  )),
                  (a = Math.floor((t % 3600) / 60)),
                  `${c(n)}:${c(a)}:${c(t % 60)}`);
            })(h);
          y[0] !== p
            ? ((t = (0, s.A)(m().countdown, p)), (y[0] = p), (y[1] = t))
            : (t = y[1]),
            y[2] !== f
              ? ((n = f
                  ? o.Ru._({
                      id: "common.dailyGames.resetsIn",
                      values: { time: f },
                    })
                  : void 0),
                (y[2] = f),
                (y[3] = n))
              : (n = y[3]),
            y[4] === Symbol.for("react.memo_cache_sentinel")
              ? ((u = (0, a.jsx)(i.I, {
                  name: "hourglass",
                  size: "custom",
                  className: m().hourglass,
                })),
                (y[4] = u))
              : (u = y[4]);
          let v = f ?? "--:--:--";
          return (
            y[5] !== v
              ? ((_ = (0, a.jsx)("span", {
                  className: m().time,
                  "aria-hidden": !0,
                  children: v,
                })),
                (y[5] = v),
                (y[6] = _))
              : (_ = y[6]),
            y[7] !== t || y[8] !== n || y[9] !== _
              ? ((g = (0, a.jsxs)("span", {
                  className: t,
                  role: "timer",
                  "aria-label": n,
                  children: [u, _],
                })),
                (y[7] = t),
                (y[8] = n),
                (y[9] = _),
                (y[10] = g))
              : (g = y[10]),
            g
          );
        };
      },
      46195: (e) => {
        e.exports = {
          czyButton: "GamePageDesktop_czyButton__gSwRs",
          "czyButton--contained--purple":
            "GamePageDesktop_czyButton--contained--purple__GIWws",
          "czyButton--contained--white":
            "GamePageDesktop_czyButton--contained--white__z2COm",
          "czyButton--contained--grey":
            "GamePageDesktop_czyButton--contained--grey__gBra2",
          "czyButton--contained--warning":
            "GamePageDesktop_czyButton--contained--warning__wENuO",
          "czyButton--contained--alert":
            "GamePageDesktop_czyButton--contained--alert__aN2rt",
          "czyButton--contained--success":
            "GamePageDesktop_czyButton--contained--success__Nb2OR",
          "czyButton--contained--black":
            "GamePageDesktop_czyButton--contained--black__0G_md",
          "czyButton--contained--green-gradient":
            "GamePageDesktop_czyButton--contained--green-gradient__VNxSU",
          "czyButton--contained--animated-green-gradient":
            "GamePageDesktop_czyButton--contained--animated-green-gradient__DXtQ1",
          "scroll-gradient": "GamePageDesktop_scroll-gradient__yD_GK",
          "czyButton--outlined--purple":
            "GamePageDesktop_czyButton--outlined--purple__DFWpc",
          "czyButton--link--purple":
            "GamePageDesktop_czyButton--link--purple___A_Rd",
          "czyButton--outlined--white":
            "GamePageDesktop_czyButton--outlined--white__d7zMQ",
          "czyButton--link--white":
            "GamePageDesktop_czyButton--link--white__kuYdH",
          "czyButton--outlined--grey":
            "GamePageDesktop_czyButton--outlined--grey__t_4M3",
          "czyButton--link--grey":
            "GamePageDesktop_czyButton--link--grey__jzD1X",
          "czyButton--outlined--warning":
            "GamePageDesktop_czyButton--outlined--warning__z1bhw",
          "czyButton--link--warning":
            "GamePageDesktop_czyButton--link--warning__8wdhP",
          "czyButton--outlined--alert":
            "GamePageDesktop_czyButton--outlined--alert__vsB7x",
          "czyButton--link--alert":
            "GamePageDesktop_czyButton--link--alert__vKYCk",
          "czyButton--outlined--success":
            "GamePageDesktop_czyButton--outlined--success__gZG4M",
          "czyButton--link--success":
            "GamePageDesktop_czyButton--link--success__JLVit",
          "czyButton--outlined": "GamePageDesktop_czyButton--outlined__FxhK7",
          "czyButton--disabled": "GamePageDesktop_czyButton--disabled__HBR8h",
          "czyButton--height50": "GamePageDesktop_czyButton--height50___asZ_",
          "czyButton--height34": "GamePageDesktop_czyButton--height34__Zf73G",
          "czyButton--height28": "GamePageDesktop_czyButton--height28__Qr_gH",
          "czyButton--fullWidth": "GamePageDesktop_czyButton--fullWidth__DfReJ",
          "czyButton--headerIcon":
            "GamePageDesktop_czyButton--headerIcon__zd9hv",
          "czyButton--headerIcon--desktop":
            "GamePageDesktop_czyButton--headerIcon--desktop__w3uVv",
          "czyButton--headerIcon--mobile":
            "GamePageDesktop_czyButton--headerIcon--mobile__vguLm",
          "czyButton--headerIcon--withLabel":
            "GamePageDesktop_czyButton--headerIcon--withLabel__TOaQ4",
          main: "GamePageDesktop_main__fSalE",
          mainContainer: "GamePageDesktop_mainContainer__QMRhB",
          gfContainer: "GamePageDesktop_gfContainer__ywzsh",
          gfAspectRatioContainer:
            "GamePageDesktop_gfAspectRatioContainer__f_hUp",
          adsLeaderboardContainer:
            "GamePageDesktop_adsLeaderboardContainer__whKOl",
          adsLeaderboard: "GamePageDesktop_adsLeaderboard__m0C8d",
          gameInfoContainer: "GamePageDesktop_gameInfoContainer__SwKQu",
          dailyGamesSidebar: "GamePageDesktop_dailyGamesSidebar__5qHi4",
          showMoreIndicatorDesktop:
            "GamePageDesktop_showMoreIndicatorDesktop__ii_Z_",
          hidden: "GamePageDesktop_hidden__jtqKL",
          underGameContainerGrid:
            "GamePageDesktop_underGameContainerGrid__cdhNC",
          underGameContainerGamesWrapper:
            "GamePageDesktop_underGameContainerGamesWrapper__Rahgf",
          showMoreButton: "GamePageDesktop_showMoreButton__xWgfT",
          rightSidebar: "GamePageDesktop_rightSidebar__QgTMJ",
          rightMpuContainer: "GamePageDesktop_rightMpuContainer__tFXsw",
          rightGridContainer: "GamePageDesktop_rightGridContainer__qJUvH",
          scrollable: "GamePageDesktop_scrollable__SdiLU",
          isScrolling: "GamePageDesktop_isScrolling__v9jVS",
          showMoreButtonDesktop: "GamePageDesktop_showMoreButtonDesktop__nw_lD",
          playNextTitle: "GamePageDesktop_playNextTitle__mvetU",
        };
      },
      59458: (e, t, n) => {
        "use strict";
        (t._H = i),
          (t.uw = function (e, t) {
            switch (e) {
              case "gold":
                return t ? t._("common.leaderboard.rank.1st") : "1st";
              case "silver":
                return t ? t._("common.leaderboard.rank.2nd") : "2nd";
              case "bronze":
                return t ? t._("common.leaderboard.rank.3rd") : "3rd";
              case "level_4":
                return "Crazy";
              case "level_5":
                return "Master";
              case "level_6":
                return "Pro";
              default:
                return "Rookie";
            }
          }),
          (t.Vy = function (e) {
            switch (e) {
              case "gold":
                return "1";
              case "silver":
                return "2";
              case "bronze":
                return "3";
              case "level_4":
                return "1%";
              case "level_5":
                return "5%";
              case "level_6":
                return "10%";
              default:
                return "90%";
            }
          }),
          (t.lL = function (e, t) {
            if (!(0, a.isDefined)(e) || e < 1) return null;
            let n = Math.max(1, Math.floor(t || 0)),
              o = Math.max(1, Math.floor(e || 1)),
              s = Math.min(o, n),
              d = s !== o || n !== t,
              c = i(s, n),
              u = (function (e, t) {
                let n = r.BADGE_ORDER.indexOf(e);
                if (n <= 0) return null;
                let a = Math.max(1, Math.floor(t));
                for (let e = n - 1; e >= 0; e--) {
                  let t = r.BADGE_ORDER[e];
                  if (
                    "gold" === t ||
                    "silver" === t ||
                    "bronze" === t ||
                    l(t, a) > 3
                  )
                    return t;
                }
                return null;
              })(c, n),
              m = u ? l(u, n) : null,
              _ = null;
            if (u && null !== m) {
              let e = l(c, n),
                t = e - m;
              _ =
                t > 0
                  ? Math.floor(100 * Math.max(0, Math.min(1, (e - s) / t)))
                  : 100 * (s <= m);
            }
            return {
              currentBadge: c,
              nextBadge: u,
              nextBadgeMinRank: m,
              progressToNext: _,
              _clamped: d,
            };
          }),
          (t.ns = function (e) {
            let t = Math.max(1, Math.floor(e || 0));
            return {
              level_4: Math.ceil(t * r.PERCENT_THRESHOLDS.level_4),
              level_5: Math.ceil(t * r.PERCENT_THRESHOLDS.level_5),
              level_6: Math.ceil(t * r.PERCENT_THRESHOLDS.level_6),
            };
          });
        let a = n(8725),
          r = n(97429);
        function l(e, t) {
          return "gold" === e
            ? 1
            : "silver" === e
            ? 2
            : "bronze" === e
            ? 3
            : Math.ceil(Math.max(1, Math.floor(t)) * r.PERCENT_THRESHOLDS[e]);
        }
        function i(e, t) {
          let n = Math.max(1, Math.floor(t || 0)),
            a = Math.min(Math.max(1, Math.floor(e || 1)), n);
          return 1 === a
            ? "gold"
            : 2 === a
            ? "silver"
            : 3 === a
            ? "bronze"
            : a <= l("level_4", n)
            ? "level_4"
            : a <= l("level_5", n)
            ? "level_5"
            : a <= l("level_6", n)
            ? "level_6"
            : "default";
        }
      },
      63811: (e, t, n) => {
        "use strict";
        function a() {
          return {
            blurredVideo: null,
            original: null,
            portraitOriginal: null,
            portraitSizes: [],
            sizes: [],
          };
        }
        n.d(t, { R: () => a });
      },
      64258: (e, t, n) => {
        "use strict";
        n.d(t, { Pe: () => c, s9: () => d, tf: () => s, w1: () => o });
        var a = n(59458),
          r = n(98417),
          l = n(77502);
        let i = new Set(["bronze", "silver", "gold"]),
          o = (e) => i.has(e);
        function s(e, t) {
          var n, i, s, d;
          let c = (0, l.pn)(e.score);
          if (!(0, r.O)(c)) return null;
          let u = (0, a._H)(e.newRank, e.totalPlayers),
            m = "level_4" === u || o(u),
            _ = m ? null : e.scoreForNextBadge;
          return {
            score: c,
            countFromRank: e.oldRank ?? Math.max(e.totalPlayers, e.newRank),
            newRank: e.newRank,
            ranksUp: (0, r.O)(e.oldRank) ? e.oldRank - e.newRank : null,
            currentBadge: u,
            isLastDivision: m,
            topPercent: o((n = u))
              ? (0, a.Vy)("level_4")
              : (0, a.Vy)("default" === n ? null : n),
            nextDivisionScore: _,
            progress: (0, r.O)(_)
              ? ((i = c),
                (s = _),
                (d = t),
                s <= 0 || i <= 0
                  ? 0
                  : Math.min(1, Math.max(0, "ASC" === d ? s / i : i / s)))
              : null,
          };
        }
        function d(e) {
          return (
            !!(0, r.O)(e.oldRank) &&
            (0, a._H)(e.oldRank, e.totalPlayers) !==
              (0, a._H)(e.newRank, e.totalPlayers)
          );
        }
        function c(e, t) {
          return (0, r.O)(e) && t - e < 15e4;
        }
      },
      66036: (e, t, n) => {
        "use strict";
        n.d(t, { P: () => l, jK: () => o, ps: () => i, un: () => d });
        var a = n(87295),
          r = n(18262);
        let l = "data-game-player-src",
          i = "data-game-player-experiments",
          o = "data-game-player-hold-messages",
          s = `(function () {
  var w = window;
  if (w.__czyGamePlayerBoot) return;
  var GAME_ID = '${r.u}';
  var SRC_ATTRIBUTE = '${l}';
  var EXPERIMENTS_ATTRIBUTE = '${i}';
  var HOLD_MESSAGES_ATTRIBUTE = '${o}';
  var CLIENT_ONLY_PARAMS = ${JSON.stringify(a.N)};

  // Same rule as portal's getIsFirstSessionForGameFrame with getSessionCount.
  function isFirstSession() {
    var param = new URLSearchParams(location.search).get('isFirstSession');
    if (param === 'true') return true;
    if (param === 'false') return false;
    var stored = null;
    try { stored = localStorage.getItem('_sessionCount'); } catch (e) {}
    return (stored ? parseInt(stored) : 1) === 1;
  }

  // The browser-only parts of the URL: client-only query params and experiments, and the first session.
  function completeUrl(base, accepted) {
    var url = new URL(base);
    var pageParams = new URLSearchParams(location.search);
    CLIENT_ONLY_PARAMS.forEach(function (key) {
      if (pageParams.has(key)) url.searchParams.set(key, pageParams.get(key));
    });
    var experiments = w.czyExperiments || {};
    Object.keys(accepted).forEach(function (key) {
      var value = experiments[key];
      var values = accepted[key];
      if (typeof value === 'string' && value !== '' && !url.searchParams.has(key) && (values === null || values.indexOf(value) !== -1)) {
        url.searchParams.set(key, value);
      }
    });
    if (!url.searchParams.has('isFirstSession') && isFirstSession()) {
      url.searchParams.set('isFirstSession', 'true');
    }
    return url.toString();
  }

  function boot() {
    var frame = document.getElementById(GAME_ID);
    var existing = w.__czyGamePlayer;
    if (existing) {
      if (existing.frame === frame) return existing;
      existing.dispose();
    }
    if (!frame || !frame.getAttribute(SRC_ATTRIBUTE)) return null;
    var accepted = {};
    try { accepted = JSON.parse(frame.getAttribute(EXPERIMENTS_ATTRIBUTE) || '{}'); } catch (e) {}

    var player = {
      frame: frame,
      srcSetAt: null,
      loadedAt: null,
      listener: null,
      disposeTimer: null,
      held: frame.hasAttribute(HOLD_MESSAGES_ATTRIBUTE) ? [] : null,
      // Called with 'srcSet' or 'loaded', and immediately for whatever already happened.
      attach: function (listener) {
        clearTimeout(player.disposeTimer);
        player.listener = listener;
        if (player.srcSetAt !== null) listener('srcSet');
        if (player.loadedAt !== null) listener('loaded');
      },
      // Hands the held messages to portal's listeners, in order and as if just received, then lets new ones through.
      drain: function () {
        var held = player.held;
        if (!held) return;
        player.held = null;
        w.removeEventListener('message', hold, true);
        held.forEach(function (m) {
          var data = m.data;
          if (data.event === 'gameLoaded' && data.loadedAt == null) {
            data = Object.assign({}, data, { loadedAt: Math.round(performance.timeOrigin + m.at) });
          }
          w.dispatchEvent(new MessageEvent('message', { data: data, origin: m.origin, source: m.source }));
        });
      },
      // Deferred, so an immediate remount (React StrictMode) keeps the running game.
      release: function () {
        player.listener = null;
        player.disposeTimer = setTimeout(player.dispose, 0);
      },
      dispose: function () {
        clearTimeout(player.disposeTimer);
        player.listener = null;
        player.held = null;
        frame.removeEventListener('load', onLoad);
        w.removeEventListener('message', hold, true);
        if (w.__czyGamePlayer === player) delete w.__czyGamePlayer;
      },
    };
    w.__czyGamePlayer = player;

    // The gameframe sends some messages once only; before portal hydrates nothing would hear them.
    function hold(event) {
      if (!player.held || event.source !== frame.contentWindow || !event.data || event.data.type !== 'GFEvent') return;
      event.stopImmediatePropagation();
      player.held.push({ data: event.data, origin: event.origin, source: event.source, at: performance.now() });
    }
    if (player.held) w.addEventListener('message', hold, true);

    function onLoad() {
      if (player.srcSetAt === null || player.loadedAt !== null) return;
      // While the HTML is parsed, the frame's initial about:blank load can still arrive after src is set.
      // The game is cross-origin, so reading its location throws.
      try {
        if (frame.contentWindow.location.href === 'about:blank') return;
      } catch (e) {}
      player.loadedAt = performance.now();
      if (player.listener) player.listener('loaded');
    }
    frame.addEventListener('load', onLoad);

    // Chrome drops a src set in the same task the parser inserted the iframe, so it is set one task later.
    setTimeout(function () {
      if (w.__czyGamePlayer !== player) return;
      frame.src = completeUrl(frame.getAttribute(SRC_ATTRIBUTE), accepted);
      player.srcSetAt = performance.now();
      if (player.listener) player.listener('srcSet');
    }, 0);
    return player;
  }

  w.__czyGamePlayerBoot = boot;

  if (document.readyState === 'loading') {
    var observer = new MutationObserver(function () {
      if (document.getElementById(GAME_ID)) {
        observer.disconnect();
        boot();
      }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    document.addEventListener('DOMContentLoaded', function () { observer.disconnect(); });
  }
})();`;
        function d() {
          if (!window.__czyGamePlayerBoot) {
            let e = document.createElement("script");
            (e.text = s), document.head.appendChild(e), e.remove();
          }
          return window.__czyGamePlayerBoot?.() ?? null;
        }
      },
      70642: (e, t, n) => {
        "use strict";
        n.r(t), n.d(t, { default: () => tx });
        var a = n(6029),
          r = n(75155),
          l = n(55729),
          i = n(18019),
          o = n(98417),
          s = n(71024),
          d = n.n(s),
          c = n(63811),
          u = n(81631),
          m = n(52461),
          _ = n(65889),
          g = n(54596),
          y = n(67988),
          h = n(13184),
          p = n(79942),
          f = n(50212),
          v = n(14886),
          b = n(71684),
          w = n(94618),
          z = n(78339),
          x = n.n(z);
        let A = (e) => {
          let t,
            n,
            l,
            i,
            o,
            s,
            d,
            c,
            u = (0, r.c)(18),
            { width: m, height: _ } = e;
          u[0] === Symbol.for("react.memo_cache_sentinel")
            ? ((t = (0, w.Ay)("chestfrown.svg")), (u[0] = t))
            : (t = u[0]);
          let g = t,
            y = m && _ ? m / _ : 1,
            h = (0, p.uB)();
          u[1] !== h
            ? ((n = h._("game.adUnitPlaceholder.title")),
              (u[1] = h),
              (u[2] = n))
            : (n = u[2]);
          let v = n,
            b = v.length > 46 ? 15 : 20,
            z = y > 2 && x().wide;
          u[3] !== z
            ? ((l = (0, f.A)(x().adUnitPlaceholder, z)), (u[3] = z), (u[4] = l))
            : (l = u[4]),
            u[5] !== _ || u[6] !== m
              ? ((i = { width: m, height: _ }),
                (u[5] = _),
                (u[6] = m),
                (u[7] = i))
              : (i = u[7]),
            u[8] === Symbol.for("react.memo_cache_sentinel")
              ? ((o = (0, a.jsx)("img", { alt: "Adblock detected", src: g })),
                (u[8] = o))
              : (o = u[8]);
          let A = x()[`fontSize${b}`];
          return (
            u[9] !== A
              ? ((s = (0, f.A)(x().placeholderTitle, A)),
                (u[9] = A),
                (u[10] = s))
              : (s = u[10]),
            u[11] !== s || u[12] !== v
              ? ((d = (0, a.jsx)("div", { className: s, children: v })),
                (u[11] = s),
                (u[12] = v),
                (u[13] = d))
              : (d = u[13]),
            u[14] !== l || u[15] !== i || u[16] !== d
              ? ((c = (0, a.jsxs)("div", {
                  className: l,
                  style: i,
                  children: [o, d],
                })),
                (u[14] = l),
                (u[15] = i),
                (u[16] = d),
                (u[17] = c))
              : (c = u[17]),
            c
          );
        };
        var S = n(89147),
          B = n(86313),
          k = n(35081),
          P = n.n(k);
        let j = d()(() => n.e(49378).then(n.bind(n, 49378)), {
            loadableGenerated: { webpack: () => [49378] },
            loading: () => null,
            ssr: !1,
          }),
          D = d()(() => n.e(16790).then(n.bind(n, 16790)), {
            loadableGenerated: { webpack: () => [16790] },
            loading: () => null,
            ssr: !1,
          }),
          E = {
            [i.R.LeaderboardBelowGameRefresh]: "ad-unit-leaderboard",
            [i.R.RightMpuRefresh]: "ad-unit-right-mpu",
            [i.R.SecondLeaderboardBelowGameRefresh]:
              "ad-unit-second-leaderboard",
            [i.R.SecondMpuBelowGameRefresh]: "ad-unit-second-mpu",
          },
          C = (e) => {
            let t,
              n,
              i,
              s,
              d,
              c,
              u,
              m,
              _,
              g,
              y,
              h,
              w,
              z,
              x = (0, r.c)(49),
              {
                id: k,
                width: C,
                height: G,
                align: U,
                className: R,
                customLabelStyle: N,
                customPaperStyle: L,
                customAdWrapperStyle: I,
                verticalLabel: T,
                addAdBlockWarning: M,
              } = e,
              O = void 0 === R ? "" : R,
              [F, W] = l.useState(null),
              { user: H, loadingUser: K } = l.useContext(v.R),
              { addAdUnit: V, removeAdUnit: Q } = l.useContext(B.g),
              q = l.useRef(null),
              { analyticsService: $ } = l.useContext(b.A).services,
              Y = $.getHasAdblock(),
              [X, J] = l.useState(null);
            x[0] !== K || x[1] !== H
              ? ((t = () => {
                  K || J(Math.floor(Math.random() * ((0, o.O)(H) ? 1 : 2)) + 1);
                }),
                (n = [H, K]),
                (x[0] = K),
                (x[1] = H),
                (x[2] = t),
                (x[3] = n))
              : ((t = x[2]), (n = x[3])),
              l.useEffect(t, n),
              x[4] !== V || x[5] !== k || x[6] !== Q
                ? ((i = () => {
                    let e = !0,
                      t = {
                        id: k,
                        onRender: (t) => {
                          e && W(!t);
                        },
                      };
                    V(t);
                    let n = q.current;
                    return function () {
                      (e = !1), Q(t, n);
                    };
                  }),
                  (s = [k, V, Q]),
                  (x[4] = V),
                  (x[5] = k),
                  (x[6] = Q),
                  (x[7] = i),
                  (x[8] = s))
                : ((i = x[7]), (s = x[8])),
              l.useEffect(i, s);
            let Z = U || "center",
              ee = `${C}px`,
              et = `${G}px`;
            x[9] !== Z || x[10] !== ee || x[11] !== et
              ? ((d = {
                  "--ad-unit-width": ee,
                  "--ad-unit-height": et,
                  "--ad-unit-text-align": Z,
                }),
                (x[9] = Z),
                (x[10] = ee),
                (x[11] = et),
                (x[12] = d))
              : (d = x[12]);
            let en = d;
            x[13] !== G || x[14] !== C
              ? ((c = (e) => {
                  switch (e) {
                    case 1:
                    default:
                      return (0, a.jsx)(j, { width: C, height: G });
                    case 2:
                      return (0, a.jsx)(D, { width: C, height: G });
                  }
                }),
                (x[13] = G),
                (x[14] = C),
                (x[15] = c))
              : (c = x[15]);
            let ea = c,
              er = M && Y && !1 === F,
              el = (0, S.z)(k) && !1 === F && !er && null !== X,
              ei = !el && !er && F;
            x[16] !== O
              ? ((u = (0, f.A)(P().adUnitRoot, O)), (x[16] = O), (x[17] = u))
              : (u = x[17]);
            let eo = E[k];
            x[18] !== N || x[19] !== ei || x[20] !== T
              ? ((m =
                  ei &&
                  (0, a.jsx)("div", {
                    className: (0, f.A)(P().label, T && P().labelVertical),
                    style: N,
                    children: (0, a.jsx)(p.x6, {
                      id: "common.advertisement.label",
                    }),
                  })),
                (x[18] = N),
                (x[19] = ei),
                (x[20] = T),
                (x[21] = m))
              : (m = x[21]);
            let es = P(),
              ed = P(),
              ec = (0, f.A)(
                P().adSlot,
                F
                  ? (0, f.A)(P().adWrapper, M && Y && P().adBlockWarning)
                  : P().alternativeAdWrapper
              ),
              eu = F ? I : void 0;
            return (
              x[22] !== k || x[23] !== ec || x[24] !== eu
                ? ((_ = (0, a.jsx)("div", {
                    className: ec,
                    ref: q,
                    id: k,
                    style: eu,
                  })),
                  (x[22] = k),
                  (x[23] = ec),
                  (x[24] = eu),
                  (x[25] = _))
                : (_ = x[25]),
              x[26] !== G || x[27] !== er || x[28] !== C
                ? ((g = er && (0, a.jsx)(A, { width: C, height: G })),
                  (x[26] = G),
                  (x[27] = er),
                  (x[28] = C),
                  (x[29] = g))
                : (g = x[29]),
              x[30] !== X || x[31] !== ea || x[32] !== el
                ? ((y = el && ea(X)),
                  (x[30] = X),
                  (x[31] = ea),
                  (x[32] = el),
                  (x[33] = y))
                : (y = x[33]),
              x[34] !== ed.innerWrapper ||
              x[35] !== _ ||
              x[36] !== g ||
              x[37] !== y
                ? ((h = (0, a.jsxs)("div", {
                    className: ed.innerWrapper,
                    children: [_, g, y],
                  })),
                  (x[34] = ed.innerWrapper),
                  (x[35] = _),
                  (x[36] = g),
                  (x[37] = y),
                  (x[38] = h))
                : (h = x[38]),
              x[39] !== L || x[40] !== es.adUnitPaper || x[41] !== h
                ? ((w = (0, a.jsx)("div", {
                    className: es.adUnitPaper,
                    style: L,
                    children: h,
                  })),
                  (x[39] = L),
                  (x[40] = es.adUnitPaper),
                  (x[41] = h),
                  (x[42] = w))
                : (w = x[42]),
              x[43] !== en ||
              x[44] !== u ||
              x[45] !== eo ||
              x[46] !== m ||
              x[47] !== w
                ? ((z = (0, a.jsxs)("div", {
                    className: u,
                    style: en,
                    "data-testid": eo,
                    children: [m, w],
                  })),
                  (x[43] = en),
                  (x[44] = u),
                  (x[45] = eo),
                  (x[46] = m),
                  (x[47] = w),
                  (x[48] = z))
                : (z = x[48]),
              z
            );
          },
          G = (e) => {
            let t,
              n,
              l,
              i = (0, r.c)(7),
              { breakpoints: o } = (0, y.D)();
            i[0] !== o
              ? ((t = o.up("gp_x6")), (i[0] = o), (i[1] = t))
              : (t = i[1]);
            let s = (0, h.A)(t) ? -3 : -10;
            return (
              i[2] !== s
                ? ((n = { bottom: s, left: 5, transform: "none" }),
                  (i[2] = s),
                  (i[3] = n))
                : (n = i[3]),
              i[4] !== e || i[5] !== n
                ? ((l = (0, a.jsx)(C, {
                    width: 728,
                    height: 90,
                    align: "left",
                    customLabelStyle: n,
                    verticalLabel: !0,
                    ...e,
                  })),
                  (i[4] = e),
                  (i[5] = n),
                  (i[6] = l))
                : (l = i[6]),
              l
            );
          },
          U = (e) => {
            let t,
              n = (0, r.c)(2),
              { game: l, children: i } = e;
            return "UNAVAILABLE" === l.status
              ? null
              : (n[0] !== i
                  ? ((t = (0, a.jsx)(a.Fragment, { children: i })),
                    (n[0] = i),
                    (n[1] = t))
                  : (t = n[1]),
                t);
          };
        var R = n(90135),
          N = n(84040);
        let L = (e) => {
          let t,
            n,
            l = (0, r.c)(3);
          return (
            l[0] === Symbol.for("react.memo_cache_sentinel")
              ? ((t = { right: 355, top: -3 }), (l[0] = t))
              : (t = l[0]),
            l[1] !== e
              ? ((n = (0, a.jsx)(C, {
                  id: i.R.SecondMpuBelowGameRefresh,
                  width: 300,
                  height: 250,
                  customLabelStyle: t,
                  ...e,
                })),
                (l[1] = e),
                (l[2] = n))
              : (n = l[2]),
            n
          );
        };
        var I = n(55678),
          T = n(62879),
          M = n(87222),
          O = n(15742),
          F = n(52359),
          W = n(49188),
          H = n.n(W);
        let K = (e) => {
          let t,
            n,
            l,
            o,
            s,
            d,
            c,
            u,
            m,
            _,
            g,
            y,
            h,
            p,
            v = (0, r.c)(33),
            { game: b } = e,
            {
              gamesInSeries: w,
              appStoreUrl: z,
              playStoreUrl: x,
              steamStoreUrl: A,
              msnStoreUrl: S,
            } = b;
          v[0] !== b.category
            ? ((t = b.category ? { ...b.category, isCategory: !0 } : void 0),
              (v[0] = b.category),
              (v[1] = t))
            : (t = v[1]);
          let B = t,
            k = !!z || !!x || !!A || !!S,
            P = w && w.length > 0;
          return (
            v[2] === Symbol.for("react.memo_cache_sentinel")
              ? ((n = (0, f.A)(H().gameInfo, H().isDesktop)), (v[2] = n))
              : (n = v[2]),
            v[3] === Symbol.for("react.memo_cache_sentinel")
              ? ((l = (0, a.jsx)(G, {
                  id: i.R.SecondLeaderboardBelowGameRefresh,
                  verticalLabel: !0,
                  addAdBlockWarning: !0,
                  customLabelStyle: {
                    left: -14,
                    top: 75,
                    transformOrigin: "left",
                  },
                  customAdWrapperStyle: {
                    boxShadow: "inset 0px 0px 0px 1px var(--neutral-800)",
                    background:
                      "color-mix(in srgb, var(--cloud-40) 10%, transparent)",
                  },
                })),
                (v[3] = l))
              : (l = v[3]),
            v[4] !== b
              ? ((o = (0, a.jsx)("div", {
                  className: H().adsLeaderboard,
                  children: (0, a.jsx)(U, { game: b, children: l }),
                })),
                (v[4] = b),
                (v[5] = o))
              : (o = v[5]),
            v[6] !== b
              ? ((s = (0, a.jsx)(O.A, { game: b })), (v[6] = b), (v[7] = s))
              : (s = v[7]),
            v[8] !== B || v[9] !== b.tags
              ? ((d = (0, a.jsx)(I.A, {
                  tags: B ? [B, ...b.tags] : [...b.tags],
                  dataTestId: "game-tags",
                })),
                (v[8] = B),
                (v[9] = b.tags),
                (v[10] = d))
              : (d = v[10]),
            v[11] !== s || v[12] !== d
              ? ((c = (0, a.jsxs)("div", {
                  className: H().gameInfoTopSection,
                  children: [s, d],
                })),
                (v[11] = s),
                (v[12] = d),
                (v[13] = c))
              : (c = v[13]),
            v[14] !== o || v[15] !== c
              ? ((u = (0, a.jsxs)("div", {
                  className: H().leftColumn,
                  children: [o, c],
                })),
                (v[14] = o),
                (v[15] = c),
                (v[16] = u))
              : (u = v[16]),
            v[17] === Symbol.for("react.memo_cache_sentinel")
              ? ((m = (0, a.jsx)(L, {
                  customLabelStyle: {
                    height: 0,
                    transform: "translate(0,250px)",
                  },
                  customAdWrapperStyle: {
                    boxShadow: "inset 0px 0px 0px 1px var(--neutral-800)",
                    background:
                      "color-mix(in srgb, var(--cloud-40) 10%, transparent)",
                  },
                })),
                (v[17] = m))
              : (m = v[17]),
            v[18] !== b
              ? ((_ = (0, a.jsx)("div", {
                  className: H().rightColumn,
                  children: (0, a.jsx)(U, { game: b, children: m }),
                })),
                (v[18] = b),
                (v[19] = _))
              : (_ = v[19]),
            v[20] !== _ || v[21] !== u
              ? ((g = (0, a.jsxs)("div", {
                  className: H().top,
                  children: [u, _],
                })),
                (v[20] = _),
                (v[21] = u),
                (v[22] = g))
              : (g = v[22]),
            v[23] !== b
              ? ((y = (0, a.jsx)("div", {
                  className: H().roundedCornersContainer,
                  children: (0, a.jsx)(T.A, { game: b }),
                })),
                (v[23] = b),
                (v[24] = y))
              : (y = v[24]),
            v[25] !== b || v[26] !== P || v[27] !== k
              ? ((h =
                  P || k
                    ? (0, a.jsxs)("div", {
                        className: (0, f.A)(
                          H().roundedCornersContainer,
                          H().removeTopPadding
                        ),
                        children: [
                          P && (0, a.jsx)(F.A, { game: b }),
                          k && (0, a.jsx)(M.A, { game: b }),
                        ],
                      })
                    : null),
                (v[25] = b),
                (v[26] = P),
                (v[27] = k),
                (v[28] = h))
              : (h = v[28]),
            v[29] !== g || v[30] !== y || v[31] !== h
              ? ((p = (0, a.jsx)(a.Fragment, {
                  children: (0, a.jsxs)("div", {
                    className: n,
                    children: [g, y, h],
                  }),
                })),
                (v[29] = g),
                (v[30] = y),
                (v[31] = h),
                (v[32] = p))
              : (p = v[32]),
            p
          );
        };
        var V = n(78718),
          Q = n(18262);
        function q(e, t) {
          return e === t
            ? "game"
            : null === e ||
              e === document.body ||
              e === document.documentElement
            ? "page"
            : "other";
        }
        let $ = "focusStealAttempt";
        function Y(e, t) {
          let n = e;
          for (; n; ) {
            if ("IFRAME" === n.tagName && n.id.includes(t)) return !0;
            n = n.parentElement;
          }
          return !1;
        }
        let X = () => (
          l.useEffect(() => {
            let e = null;
            function t(t) {
              t.target && "focus" in t.target && (e = t.target);
            }
            function n(t) {
              setTimeout(() => {
                if (Y(document.activeElement, Q.u)) {
                  e = (0, Q.y)();
                  return;
                }
                if (Y(document.activeElement, "google_ads_iframe")) {
                  let t = e ?? (0, Q.y)();
                  t && t.focus();
                  return;
                }
                e =
                  t.relatedTarget && "focus" in t.relatedTarget
                    ? t.relatedTarget
                    : null;
              });
            }
            let a = !1,
              r = 0;
            function l() {
              r = Date.now();
            }
            document.addEventListener("focus", t, !0),
              document.addEventListener("blur", n, !0),
              document.addEventListener("pointerdown", l, !0),
              document.addEventListener("keydown", l, !0);
            let i = null;
            return (
              (i = window.setInterval(() => {
                let e = (0, Q.y)();
                if (e) {
                  var t, n, l;
                  let i = document.activeElement;
                  i?.id?.includes("google_ads_iframe") &&
                    e.contentWindow?.postMessage({ type: $ }, "*");
                  let o = q(i, e);
                  (t = a),
                    (n = document.hasFocus()),
                    (l = Date.now() - r),
                    t &&
                      "page" === o &&
                      n &&
                      l > 200 &&
                      (e.focus(),
                      e.contentWindow?.postMessage({ type: $ }, "*")),
                    (a = "game" === q(document.activeElement, e));
                }
              }, 32)),
              function () {
                i && window.clearInterval(i),
                  document.removeEventListener("focus", t, !0),
                  document.removeEventListener("blur", n, !0),
                  document.removeEventListener("pointerdown", l, !0),
                  document.removeEventListener("keydown", l, !0);
              }
            );
          }, []),
          null
        );
        var J = n(27096),
          Z = n(89964),
          ee = n(28528),
          et = n(7842),
          en = n(81278),
          ea = n(60574),
          er = n(51579),
          el = n(75403),
          ei = n(45018),
          eo = n(60362),
          es = n(71855),
          ed = n(50190),
          ec = n(34302),
          eu = n(47883),
          em = n(87295),
          e_ = n(93389),
          eg = n(68406),
          ey = n(4230),
          eh = n(45364),
          ep = n(50113),
          ef = n(28478),
          ev = n(15325),
          eb = n(77257),
          ew = n(64258);
        let ez = (e) => `rankProgressOverlayShownAt_${e}`,
          ex = d()(
            () =>
              Promise.all([n.e(73940), n.e(11119), n.e(87808)]).then(
                n.bind(n, 87808)
              ),
            {
              loadableGenerated: { webpack: () => [87808] },
              loading: () => null,
              ssr: !1,
            }
          ),
          eA = (e) => {
            let t,
              n,
              i = (0, r.c)(9),
              { game: s, onClose: d } = e,
              {
                view: c,
                neighbours: u,
                close: m,
              } = (function (e) {
                let t,
                  n,
                  a,
                  i,
                  s,
                  d,
                  c,
                  u = (0, r.c)(22),
                  m =
                    "enabled" ===
                    (0, es.U)("czyExpClientLbRankProgress_CZY_21923"),
                  { services: _ } = l.useContext(b.A),
                  [g, y] = l.useState(null),
                  h = e.leaderboardOptions?.scoreSorting,
                  p = e.isPreview ?? !1;
                u[0] !== m ||
                u[1] !== e.id ||
                u[2] !== _.crazyAnalyticsService ||
                u[3] !== h
                  ? ((t = () => {
                      if (m && h)
                        return (0, eb.m)((t) => {
                          var n;
                          let a,
                            r = Date.now();
                          if (
                            t.gameId !== e.id ||
                            (!(0, ew.s9)(t) &&
                              (0, ew.Pe)(
                                ((n = t.gameId),
                                Number.isFinite(
                                  (a = Number(
                                    ef.A.SessionStorage.getItem(ez(n))
                                  ))
                                ) && a > 0
                                  ? a
                                  : null),
                                r
                              ))
                          )
                            return;
                          let l = (0, ew.tf)(t, h);
                          l &&
                            (ef.A.SessionStorage.setItem(
                              ez(t.gameId),
                              String(r)
                            ),
                            _.crazyAnalyticsService.leaderboardEvent(
                              "gamepage",
                              "rankprogressviewed",
                              {
                                score: {
                                  value: l.score,
                                  globalRank: l.newRank,
                                  countryRank: null,
                                  friendsRank: null,
                                },
                              }
                            ),
                            y(l));
                        });
                    }),
                    (n = [m, h, e.id, _.crazyAnalyticsService]),
                    (u[0] = m),
                    (u[1] = e.id),
                    (u[2] = _.crazyAnalyticsService),
                    (u[3] = h),
                    (u[4] = t),
                    (u[5] = n))
                  : ((t = u[4]), (n = u[5])),
                  l.useEffect(t, n),
                  u[6] !== e.id || u[7] !== p
                    ? ((a = { gameId: e.id, isPreview: p }),
                      (u[6] = e.id),
                      (u[7] = p),
                      (u[8] = a))
                    : (a = u[8]);
                let f = !g?.isLastDivision;
                u[9] !== a || u[10] !== f
                  ? ((i = { variables: a, fetchPolicy: "no-cache", skip: f }),
                    (u[9] = a),
                    (u[10] = f),
                    (u[11] = i))
                  : (i = u[11]);
                let { data: v, error: w } = (0, ep.IT)(ev.Pf, i);
                u[12] !== v?.me?.globalLeaderboardNeighbourhood ||
                u[13] !== w ||
                u[14] !== g?.isLastDivision
                  ? ((s = g?.isLastDivision
                      ? w
                        ? []
                        : v?.me?.globalLeaderboardNeighbourhood?.filter(o.O) ??
                          null
                      : null),
                    (u[12] = v?.me?.globalLeaderboardNeighbourhood),
                    (u[13] = w),
                    (u[14] = g?.isLastDivision),
                    (u[15] = s))
                  : (s = u[15]);
                let z = s;
                u[16] !== _.crazyAnalyticsService
                  ? ((d = () => {
                      _.crazyAnalyticsService.leaderboardEvent(
                        "gamepage",
                        "rankprogressclosed"
                      ),
                        y(null);
                    }),
                    (u[16] = _.crazyAnalyticsService),
                    (u[17] = d))
                  : (d = u[17]);
                let x = d;
                return (
                  u[18] !== x || u[19] !== z || u[20] !== g
                    ? ((c = { view: g, neighbours: z, close: x }),
                      (u[18] = x),
                      (u[19] = z),
                      (u[20] = g),
                      (u[21] = c))
                    : (c = u[21]),
                  c
                );
              })(s),
              _ = s.leaderboardOptions?.scoreLabel;
            i[0] !== m || i[1] !== d
              ? ((t = () => {
                  m(), d();
                }),
                (i[0] = m),
                (i[1] = d),
                (i[2] = t))
              : (t = i[2]);
            let g = t;
            if (!c || !_) return null;
            let y = `${c.newRank}-${c.score}`;
            return (
              i[3] !== g || i[4] !== u || i[5] !== _ || i[6] !== y || i[7] !== c
                ? ((n = (0, a.jsx)(
                    ex,
                    { view: c, scoreLabel: _, neighbours: u, onClose: g },
                    y
                  )),
                  (i[3] = g),
                  (i[4] = u),
                  (i[5] = _),
                  (i[6] = y),
                  (i[7] = c),
                  (i[8] = n))
                : (n = i[8]),
              n
            );
          };
        var eS = n(16472),
          eB = n(88748),
          ek = n(51196),
          eP = n(41645),
          ej = n(66036),
          eD = n(28967),
          eE = n(52268),
          eC = n(26165),
          eG = n(94448),
          eU = n(16316),
          eR = n(41136),
          eN = n(29457);
        let eL = {
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            overflow: "hidden",
          },
          eI = {
            width: "100%",
            height: "100%",
            transformOrigin: "0 0",
            transform: "none",
          };
        var eT = n(3495),
          eM = n.n(eT);
        let eO = (e) => {
          let t,
            n,
            i,
            o,
            s,
            d,
            c,
            u,
            m,
            _,
            g,
            y,
            h,
            p,
            v,
            w,
            z,
            x,
            A,
            S,
            B,
            k,
            P,
            j,
            D,
            E,
            C,
            G,
            U,
            R,
            N,
            L,
            I,
            T,
            M,
            O,
            F = (0, r.c)(83),
            { game: W, waitForQATool: H, serverRendered: K } = e,
            q = void 0 !== K && K,
            { arm: $, artworkId: Y, artworkExperimentId: X } = (0, eu.F)(W),
            J = l.useRef(null),
            ep = l.useRef(null),
            ef = l.useRef(null),
            ev = l.useRef(!1),
            eb = (0, ed.A)(),
            [ew, ez] = l.useState(!1),
            ex = ew
              ? "disabled"
              : q || (eb && !(void 0 !== H && H))
              ? "enabled"
              : "loading",
            eT = "enabled" === ex;
          F[0] !== X || F[1] !== Y || F[2] !== W.id || F[3] !== eT
            ? ((t = {
                gameId: W.id,
                artworkId: Y,
                artworkExperimentId: X,
                enabled: eT,
              }),
              (F[0] = X),
              (F[1] = Y),
              (F[2] = W.id),
              (F[3] = eT),
              (F[4] = t))
            : (t = F[4]),
            (0, ec.A)(t);
          let { routeHelper: eO } = l.useContext(e_.A),
            { pageUrlHelper: eK } = l.useContext(ek.e),
            { services: eV } = l.useContext(b.A),
            eQ = l.useContext(ey.A),
            eq = (0, eg.E)(),
            e$ =
              "enabled" ===
              (0, es.U)("czyExpClientHappyTimeFullscreen_CZY_21067"),
            eY = l.useContext(eo.H);
          F[5] !== $ ||
          F[6] !== eQ ||
          F[7] !== eY ||
          F[8] !== W ||
          F[9] !== eK ||
          F[10] !== eO ||
          F[11] !== eV.crazyAnalyticsService
            ? ((n = (e, t) => {
                let n = void 0 !== t && t,
                  a = eV.crazyAnalyticsService.getSessionCount(),
                  r = !n && (0, eC.d)(eK.routeData.query?.isFirstSession, a),
                  l = eK.getPreviewBuildId(),
                  i = eO.gameIframeUrl(
                    W.desktopUrl,
                    {
                      ...(n
                        ? eK.filteredQueryParams()
                        : eK.queryParamsForGameframe()),
                      ...(r && { isFirstSession: r }),
                      ...(W.isPreview && { isPreview: !0 }),
                      ...(W.isPreview && l && { gameBuildId: l }),
                      ...("variant" === $ && { [em.mt]: $ }),
                      ...((0, ei.j)(W, eQ, eK) && { [ee._]: "true" }),
                      ...(void 0 === e ? {} : e),
                    },
                    eY,
                    n ? {} : { ...(0, ea.jU)() }
                  );
                return W.isPreview ? (0, eB.qP)(i, (0, eB.P4)()) : i;
              }),
              (F[5] = $),
              (F[6] = eQ),
              (F[7] = eY),
              (F[8] = W),
              (F[9] = eK),
              (F[10] = eO),
              (F[11] = eV.crazyAnalyticsService),
              (F[12] = n))
            : (n = F[12]);
          let eX = n;
          F[13] !== eX
            ? ((i = (e) => {
                let { query: t } = e;
                ep.current && (0, eR.V2)(ep.current, eX(t ?? {}));
              }),
              (F[13] = eX),
              (F[14] = i))
            : (i = F[14]);
          let eJ = i,
            eZ = l.useRef(eJ),
            e0 = l.useRef(eX);
          F[15] !== eX || F[16] !== eJ
            ? ((o = () => {
                (eZ.current = eJ), (e0.current = eX);
              }),
              (F[15] = eX),
              (F[16] = eJ),
              (F[17] = o))
            : (o = F[17]),
            l.useEffect(o),
            F[18] === Symbol.for("react.memo_cache_sentinel")
              ? ((s = () => (0, eR.oF)((e) => eZ.current(e))),
                (d = []),
                (F[18] = s),
                (F[19] = d))
              : ((s = F[18]), (d = F[19])),
            l.useEffect(s, d),
            F[20] !== eX || F[21] !== q
              ? ((c = () =>
                  q
                    ? {
                        url: eX({}, !0),
                        experiments: JSON.stringify((0, eP.Lz)()),
                      }
                    : null),
                (F[20] = eX),
                (F[21] = q),
                (F[22] = c))
              : (c = F[22]);
          let [e1] = l.useState(c);
          F[23] !== q || F[24] !== eV.crazyAnalyticsService
            ? ((u = () => {
                if (!q) return;
                let e = (0, ej.un)();
                if (!e) return;
                e.attach(eF);
                let t = window.setTimeout(() => {
                  e.drain();
                  let t = ep.current?.getAttribute("src"),
                    n = t ? (0, eP.KG)(t, e0.current()) : [];
                  n.length > 0 &&
                    eV.crazyAnalyticsService.trackGenericError(
                      "gameframeSsrSrcMismatch",
                      { keys: n }
                    );
                }, 0);
                return () => {
                  clearTimeout(t), e.release();
                };
              }),
              (F[23] = q),
              (F[24] = eV.crazyAnalyticsService),
              (F[25] = u))
            : (u = F[25]),
            F[26] !== q || F[27] !== eV
              ? ((m = [q, eV]), (F[26] = q), (F[27] = eV), (F[28] = m))
              : (m = F[28]),
            l.useEffect(u, m);
          let { wrapperStyle: e2, iframeStyle: e3 } = (function (e) {
            let [t, n] = l.useState(eI);
            return (
              l.useEffect(() => {
                let t = e.current;
                if (!t) return;
                let a = () => {
                  let e = t.clientWidth,
                    a = t.clientHeight,
                    r = a <= 0 ? 1 : Math.max(1, a / 2160);
                  r <= 1
                    ? n(eI)
                    : n({
                        width: `${Math.ceil(e / r)}px`,
                        height: `${Math.ceil(a / r)}px`,
                        transformOrigin: "0 0",
                        transform: `scale(${r})`,
                      });
                };
                a();
                let r = new ResizeObserver(a);
                r.observe(t);
                let l = ["fullscreenchange", "webkitfullscreenchange"];
                return (
                  l.forEach((e) => document.addEventListener(e, a)),
                  () => {
                    r.disconnect(),
                      l.forEach((e) => document.removeEventListener(e, a));
                  }
                );
              }, [e]),
              { wrapperStyle: eL, iframeStyle: t }
            );
          })(ef);
          F[29] === Symbol.for("react.memo_cache_sentinel")
            ? ((_ = () => {
                let e = ep.current;
                e &&
                  !document.hidden &&
                  setTimeout(() => {
                    window.focus(),
                      e.focus(),
                      e.contentWindow?.focus(),
                      e.contentWindow?.postMessage(
                        { type: "focusStealAttempt" },
                        "*"
                      );
                  }, 0);
              }),
              (F[29] = _))
            : (_ = F[29]);
          let e4 = _;
          return (
            F[30] === Symbol.for("react.memo_cache_sentinel")
              ? ((g = () => {
                  let e = (e) => {
                    let t = new URL(e, window.location.href);
                    window.location.pathname !== t.pathname && ez(!0);
                  };
                  return (
                    en.Router.events.on("routeChangeStart", e),
                    function () {
                      en.Router.events.off("routeChangeStart", e);
                    }
                  );
                }),
                (y = []),
                (F[30] = g),
                (F[31] = y))
              : ((g = F[30]), (y = F[31])),
            l.useEffect(g, y),
            F[32] !== eQ ||
            F[33] !== W.desktopUrl ||
            F[34] !== e$ ||
            F[35] !== eq ||
            F[36] !== eO
              ? ((h = () => {
                  let e = (e) => {
                    let t;
                    if (!e.data || e.data.type !== Z.x || !e.origin) return;
                    try {
                      t = new URL(e.origin);
                    } catch {
                      return;
                    }
                    let n = eO.isMessageFromGameframe(e, W.desktopUrl),
                      a = t.hostname === window.location.hostname;
                    if (n || a)
                      switch (e.data.event) {
                        case "happytime":
                          (0, eD.A)(eQ, !1, eq, e$).catch(eW);
                          break;
                        case "inviteLink": {
                          let t = e.data.url;
                          try {
                            window.history.replaceState(
                              { ...window.history.state, as: t, url: t },
                              "",
                              t
                            );
                          } catch (e) {
                            console.error(e);
                          }
                          break;
                        }
                        case "exitFullscreen":
                          eh.A.exitNativeFullscreen();
                          break;
                        case "requestFullscreen":
                          (ev.current = !0),
                            document.documentElement
                              .requestFullscreen()
                              .then(() => {
                                ep.current?.contentWindow?.postMessage(
                                  { type: "fullscreenActivated" },
                                  "*"
                                );
                              })
                              .catch(() => {
                                ev.current = !1;
                              });
                      }
                  };
                  return (
                    window.addEventListener("message", e),
                    function () {
                      window.removeEventListener("message", e);
                    }
                  );
                }),
                (p = [W.desktopUrl, eQ, eq, eO, e$]),
                (F[32] = eQ),
                (F[33] = W.desktopUrl),
                (F[34] = e$),
                (F[35] = eq),
                (F[36] = eO),
                (F[37] = h),
                (F[38] = p))
              : ((h = F[37]), (p = F[38])),
            l.useEffect(h, p),
            F[39] === Symbol.for("react.memo_cache_sentinel")
              ? ((v = () => {
                  let e = () => {
                    !document.fullscreenElement &&
                      ev.current &&
                      ((ev.current = !1),
                      ep.current?.contentWindow?.postMessage(
                        { type: "fullscreenDeactivated" },
                        "*"
                      ),
                      requestAnimationFrame(eH));
                  };
                  return (
                    document.addEventListener("fullscreenchange", e),
                    () => document.removeEventListener("fullscreenchange", e)
                  );
                }),
                (w = []),
                (F[39] = v),
                (F[40] = w))
              : ((v = F[39]), (w = F[40])),
            l.useEffect(v, w),
            F[41] === Symbol.for("react.memo_cache_sentinel")
              ? ((z = () => {
                  let e = () => {
                    (0, el.z)(
                      window,
                      ep.current?.contentWindow,
                      (0, Q.y)()?.contentWindow
                    );
                  };
                  return (
                    (0, er.b)().addInstallListener(e),
                    function () {
                      (0, er.b)().removeInstallListener(e);
                    }
                  );
                }),
                (x = []),
                (F[41] = z),
                (F[42] = x))
              : ((z = F[41]), (x = F[42])),
            l.useEffect(z, x),
            F[43] !== ex
              ? ((A = function () {
                  "enabled" !== ex || document.hidden || e4();
                }),
                (S = [e4, ex]),
                (F[43] = ex),
                (F[44] = A),
                (F[45] = S))
              : ((A = F[44]), (S = F[45])),
            l.useEffect(A, S),
            F[46] === Symbol.for("react.memo_cache_sentinel")
              ? ((B = function () {
                  let e = () => {
                    document.hidden || e4();
                  };
                  return (
                    document.addEventListener("visibilitychange", e),
                    () => document.removeEventListener("visibilitychange", e)
                  );
                }),
                (k = [e4]),
                (F[46] = B),
                (F[47] = k))
              : ((B = F[46]), (k = F[47])),
            l.useEffect(B, k),
            F[48] !== eX ||
            F[49] !== W ||
            F[50] !== ex ||
            F[51] !== e3 ||
            F[52] !== e1 ||
            F[53] !== e2
              ? ((G = eM().gameContainerDesktopRoot),
                (U = "game-container"),
                F[61] === Symbol.for("react.memo_cache_sentinel")
                  ? ((E = (0, f.A)("GameContainer", eM().gameContainer)),
                    (F[61] = E))
                  : (E = F[61]),
                (C = J),
                (P = ef),
                (j = e2),
                (D = (() => {
                  if ("disabled" === ex) return null;
                  if ("loading" === ex)
                    return (0, a.jsx)("div", {
                      className: eM().iframeLoading,
                      children: (0, a.jsx)(et.y, { tone: "neutral" }),
                    });
                  let e = (0, eG.A)(W),
                    t = { importance: "high" },
                    n = W.descriptionFirst
                      ? `${W.descriptionFirst} ${W.descriptionRest}`
                      : null,
                    r = n ? { dangerouslySetInnerHTML: { __html: n } } : {},
                    l = (0, eU.e)(W);
                  return e1
                    ? (0, a.jsx)(
                        "iframe",
                        {
                          [ej.P]: e1.url,
                          [ej.ps]: e1.experiments,
                          [ej.jK]: "",
                          id: Q.u,
                          "data-testid": "game-iframe",
                          title: W.name,
                          scrolling: "no",
                          allow: l,
                          allowFullScreen: !0,
                          ref: ep,
                          sandbox: e,
                          loading: "eager",
                          ...t,
                          ...r,
                          "data-hj-allow-iframe": !0,
                          className: eM().gameIframe,
                          style: e3,
                          suppressHydrationWarning: !0,
                        },
                        W.slug
                      )
                    : (0, a.jsx)(
                        eN.A,
                        {
                          buildSource: eX,
                          id: Q.u,
                          "data-testid": "game-iframe",
                          title: W.name,
                          scrolling: "no",
                          allow: l,
                          allowFullScreen: !0,
                          ref: ep,
                          sandbox: e,
                          loading: "eager",
                          ...t,
                          ...r,
                          "data-hj-allow-iframe": !0,
                          className: eM().gameIframe,
                          style: e3,
                        },
                        W.slug
                      );
                })()),
                (F[48] = eX),
                (F[49] = W),
                (F[50] = ex),
                (F[51] = e3),
                (F[52] = e1),
                (F[53] = e2),
                (F[54] = P),
                (F[55] = j),
                (F[56] = D),
                (F[57] = E),
                (F[58] = C),
                (F[59] = G),
                (F[60] = U))
              : ((P = F[54]),
                (j = F[55]),
                (D = F[56]),
                (E = F[57]),
                (C = F[58]),
                (G = F[59]),
                (U = F[60])),
            F[62] !== P || F[63] !== j || F[64] !== D
              ? ((R = (0, a.jsx)("div", { ref: P, style: j, children: D })),
                (F[62] = P),
                (F[63] = j),
                (F[64] = D),
                (F[65] = R))
              : (R = F[65]),
            F[66] !== W
              ? ((N = (0, V.m)(W) && (0, a.jsx)(eA, { game: W, onClose: e4 })),
                (F[66] = W),
                (F[67] = N))
              : (N = F[67]),
            F[68] !== E || F[69] !== C || F[70] !== R || F[71] !== N
              ? ((L = (0, a.jsxs)("div", {
                  className: E,
                  ref: C,
                  children: [R, N],
                })),
                (F[68] = E),
                (F[69] = C),
                (F[70] = R),
                (F[71] = N),
                (F[72] = L))
              : (L = F[72]),
            F[73] !== G || F[74] !== U || F[75] !== L
              ? ((I = (0, a.jsx)("div", {
                  className: G,
                  "data-testid": U,
                  children: L,
                })),
                (F[73] = G),
                (F[74] = U),
                (F[75] = L),
                (F[76] = I))
              : (I = F[76]),
            F[77] === Symbol.for("react.memo_cache_sentinel")
              ? ((T = (0, a.jsx)(eE.A, {})), (F[77] = T))
              : (T = F[77]),
            F[78] !== W
              ? ((M = (0, a.jsx)(eS.A, { game: W })), (F[78] = W), (F[79] = M))
              : (M = F[79]),
            F[80] !== I || F[81] !== M
              ? ((O = (0, a.jsxs)(a.Fragment, { children: [I, T, M] })),
                (F[80] = I),
                (F[81] = M),
                (F[82] = O))
              : (O = F[82]),
            O
          );
        };
        function eF() {}
        function eW(e) {
          console.error(e);
        }
        function eH() {
          return window.scrollTo(0, 0);
        }
        var eK = n(20490),
          eV = n(80123);
        let eQ = d()(
            () =>
              Promise.all([n.e(80580), n.e(67297), n.e(59598)]).then(
                n.bind(n, 59598)
              ),
            { loadableGenerated: { webpack: () => [59598] } }
          ),
          eq = (e) => {
            let t,
              n,
              i,
              o = (0, r.c)(12),
              { game: s, waitForQATool: d } = e,
              c = (0, J.j)(s),
              u = l.useContext(eV.d);
            if ("gameplayer" === u) {
              let e;
              return (
                o[0] !== s
                  ? ((e = (0, a.jsx)(eQ, { game: s })), (o[0] = s), (o[1] = e))
                  : (e = o[1]),
                e
              );
            }
            let m = "gameframe-ssr" === u;
            return (
              o[2] !== s || o[3] !== m || o[4] !== d
                ? ((t = (0, a.jsx)(eO, {
                    game: s,
                    waitForQATool: d,
                    serverRendered: m,
                  })),
                  (o[2] = s),
                  (o[3] = m),
                  (o[4] = d),
                  (o[5] = t))
                : (t = o[5]),
              o[6] !== s || o[7] !== c
                ? ((n = (0, a.jsx)(eK.A, { game: s, handlers: c })),
                  (o[6] = s),
                  (o[7] = c),
                  (o[8] = n))
                : (n = o[8]),
              o[9] !== t || o[10] !== n
                ? ((i = (0, a.jsxs)(a.Fragment, { children: [t, n] })),
                  (o[9] = t),
                  (o[10] = n),
                  (o[11] = i))
                : (i = o[11]),
              i
            );
          };
        var e$ = n(93800),
          eY = n(37434),
          eX = n(70930),
          eJ = n(84921),
          eZ = n.n(eJ);
        let e0 = (e) => {
          let t,
            n,
            l,
            i = (0, r.c)(14),
            {
              displayedGames: o,
              start: s,
              end: d,
              options: c,
              className: u,
              twoColumnHoverScale: m,
            } = e,
            _ = void 0 === s ? 0 : s;
          i[0] !== c
            ? ((t = void 0 === c ? {} : c), (i[0] = c), (i[1] = t))
            : (t = i[1]);
          let g = t,
            y = d || o.length;
          i[2] !== o || i[3] !== y || i[4] !== _
            ? ((n = o.slice(_, y)),
              (i[2] = o),
              (i[3] = y),
              (i[4] = _),
              (i[5] = n))
            : (n = i[5]);
          let h = n;
          return (
            i[6] !== u ||
            i[7] !== o ||
            i[8] !== g ||
            i[9] !== y ||
            i[10] !== h.length ||
            i[11] !== _ ||
            i[12] !== m
              ? ((l =
                  h.length === y - _
                    ? (0, a.jsx)(eX.A, {
                        className: (0, f.A)(eZ().gameGrid, u),
                        games: o.slice(_, y),
                        justifyContent: "center",
                        slidesToLoadEagerly: g.slidesToLoadEagerly,
                        customStyles: g.customStyles,
                        twoColumnHoverScale: m,
                      })
                    : null),
                (i[6] = u),
                (i[7] = o),
                (i[8] = g),
                (i[9] = y),
                (i[10] = h.length),
                (i[11] = _),
                (i[12] = m),
                (i[13] = l))
              : (l = i[13]),
            l
          );
        };
        var e1 = n(46195),
          e2 = n.n(e1);
        let e3 = (e) => {
            let t,
              n,
              i,
              o,
              s,
              d,
              c,
              u,
              _ = (0, r.c)(19),
              { related: g } = e,
              [y, h] = l.useState(!1),
              f = l.useRef(null);
            _[0] !== g || _[1] !== y
              ? ((t = y ? g : g.slice(0, 12)),
                (_[0] = g),
                (_[1] = y),
                (_[2] = t))
              : (t = _[2]);
            let v = t;
            _[3] === Symbol.for("react.memo_cache_sentinel")
              ? ((n = (0, a.jsx)("div", {
                  className: e2().playNextTitle,
                  children: (0, a.jsx)(p.x6, { id: "game.related.playNext" }),
                })),
                (_[3] = n))
              : (n = _[3]),
              _[4] !== v
                ? ((i = (0, a.jsxs)("div", {
                    className: e2().underGameContainerGamesWrapper,
                    children: [
                      n,
                      (0, a.jsx)(m.x, {
                        newClickOrigin: "gamePage-related",
                        children: (0, a.jsx)(e0, { displayedGames: v }),
                      }),
                    ],
                  })),
                  (_[4] = v),
                  (_[5] = i))
                : (i = _[5]),
              _[6] !== y
                ? ((o = y
                    ? () => {
                        document
                          .getElementById("gamePageMainContainer")
                          ?.scrollIntoView(),
                          h(!1);
                      }
                    : () => h(!0)),
                  (_[6] = y),
                  (_[7] = o))
                : (o = _[7]);
            let b = y ? "minus" : "plus";
            return (
              _[8] !== b
                ? ((s = (0, a.jsx)(e$.A, { name: b })), (_[8] = b), (_[9] = s))
                : (s = _[9]),
              _[10] !== y
                ? ((d = y
                    ? (0, a.jsx)(p.x6, { id: "common.showLess" })
                    : (0, a.jsx)(p.x6, { id: "common.showMore" })),
                  (_[10] = y),
                  (_[11] = d))
                : (d = _[11]),
              _[12] !== o || _[13] !== s || _[14] !== d
                ? ((c = (0, a.jsxs)(eY.A, {
                    variant: "contained",
                    color: "purple",
                    height: 50,
                    className: e2().showMoreButton,
                    onClick: o,
                    children: [s, d],
                  })),
                  (_[12] = o),
                  (_[13] = s),
                  (_[14] = d),
                  (_[15] = c))
                : (c = _[15]),
              _[16] !== i || _[17] !== c
                ? ((u = (0, a.jsxs)("div", {
                    className: e2().underGameContainerGrid,
                    ref: f,
                    children: [i, c],
                  })),
                  (_[16] = i),
                  (_[17] = c),
                  (_[18] = u))
                : (u = _[18]),
              u
            );
          },
          e4 = (e) => {
            let t,
              n,
              l = (0, r.c)(3);
            return (
              l[0] === Symbol.for("react.memo_cache_sentinel")
                ? ((t = { right: 355, top: -3 }), (l[0] = t))
                : (t = l[0]),
              l[1] !== e
                ? ((n = (0, a.jsx)(C, {
                    id: i.R.RightMpuRefresh,
                    width: 300,
                    height: 250,
                    customLabelStyle: t,
                    ...e,
                  })),
                  (l[1] = e),
                  (l[2] = n))
                : (n = l[2]),
              n
            );
          };
        var e5 = n(83072),
          e6 = n(32994),
          e8 = n(77650),
          e7 = n(80638),
          e9 = n(13246),
          te = n(76436),
          tt = n(33738),
          tn = n(42500),
          ta = n(20561),
          tr = n(12869),
          tl = n(34556),
          ti = n(60788),
          to = n(47953),
          ts = n.n(to),
          td = n(75864),
          tc = n.n(td);
        let tu = `${e9.A.Instance.data.files}crazygames-portal/sounds/whoosh.mp3`,
          tm = (e) => {
            let t,
              n,
              l,
              i,
              o = (0, r.c)(11),
              { entry: s, size: d, done: c } = e,
              u = tc()[d],
              m = c && tc().thumbDone;
            return (
              o[0] !== u || o[1] !== m
                ? ((t = (0, f.A)(tc().thumb, u, m)),
                  (o[0] = u),
                  (o[1] = m),
                  (o[2] = t))
                : (t = o[2]),
              o[3] !== s.game
                ? ((n =
                    s.game &&
                    (0, a.jsx)("img", {
                      src: (0, w.Ay)(s.game.covers?.["1x1"] || s.game.cover, {
                        width: 120,
                      }),
                      alt: "",
                    })),
                  (o[3] = s.game),
                  (o[4] = n))
                : (n = o[4]),
              o[5] !== c
                ? ((l =
                    c &&
                    (0, a.jsx)("span", {
                      className: tc().check,
                      children: (0, a.jsx)(e6.I, {
                        name: "check",
                        size: "custom",
                      }),
                    })),
                  (o[5] = c),
                  (o[6] = l))
                : (l = o[6]),
              o[7] !== t || o[8] !== n || o[9] !== l
                ? ((i = (0, a.jsxs)("span", {
                    className: t,
                    children: [n, l],
                  })),
                  (o[7] = t),
                  (o[8] = n),
                  (o[9] = l),
                  (o[10] = i))
                : (i = o[10]),
              i
            );
          },
          t_ = (e) => {
            let t,
              n,
              l,
              i = (0, r.c)(7),
              { entry: o } = e,
              s = o.game?.name;
            return (
              i[0] !== s
                ? ((t = (0, a.jsx)("span", {
                    className: tc().name,
                    children: s,
                  })),
                  (i[0] = s),
                  (i[1] = t))
                : (t = i[1]),
              i[2] !== o.daily.currentStreak
                ? ((n = (0, a.jsx)(ti.A, { streak: o.daily.currentStreak })),
                  (i[2] = o.daily.currentStreak),
                  (i[3] = n))
                : (n = i[3]),
              i[4] !== t || i[5] !== n
                ? ((l = (0, a.jsxs)("span", {
                    className: tc().text,
                    children: [t, n],
                  })),
                  (i[4] = t),
                  (i[5] = n),
                  (i[6] = l))
                : (l = i[6]),
              l
            );
          },
          tg = (e) => {
            let t,
              n = (0, r.c)(4),
              { entry: l, className: i, children: o } = e;
            return (
              n[0] !== o || n[1] !== i || n[2] !== l.game
                ? ((t = l.game
                    ? (0, a.jsx)(tt.A, {
                        slug: l.game.slug,
                        className: i,
                        launchSource: "dailyPuzzle",
                        children: o,
                      })
                    : (0, a.jsx)("div", { className: i, children: o })),
                  (n[0] = o),
                  (n[1] = i),
                  (n[2] = l.game),
                  (n[3] = t))
                : (t = n[3]),
              t
            );
          },
          ty = (e) => {
            let t,
              n,
              i,
              o,
              s,
              d,
              c = (0, r.c)(41),
              { currentGameId: u } = e,
              {
                entries: m,
                solvedCount: _,
                total: g,
                nextResetAt: y,
                getEntry: h,
              } = (0, tr.A)(),
              v = (0, tl.l)(u),
              b = (0, te.G)(),
              { capture: w } = b;
            c[0] !== u || c[1] !== h
              ? ((t = h(u)?.daily.completed),
                (c[0] = u),
                (c[1] = h),
                (c[2] = t))
              : (t = c[2]);
            let z = !!t,
              [x, A] = l.useState(z),
              [S, B] = l.useState(null);
            z !== x && (A(z), B(z ? "completing" : null)),
              c[3] === Symbol.for("react.memo_cache_sentinel")
                ? ((n = { volume: 0.6 }), (c[3] = n))
                : (n = c[3]);
            let [k] = (0, e7.A)(tu, n);
            c[4] !== w || c[5] !== k
              ? ((i = () => {
                  w(), B("settled"), k();
                }),
                (c[4] = w),
                (c[5] = k),
                (c[6] = i))
              : (i = c[6]);
            let P = l.useEffectEvent(i);
            if (
              (c[7] !== S || c[8] !== P
                ? ((o = () => {
                    if ("completing" === S) {
                      let e = window.setTimeout(() => P(), 600);
                      return () => window.clearTimeout(e);
                    }
                    if ("settled" === S) {
                      let e = window.setTimeout(() => B(null), 1800);
                      return () => window.clearTimeout(e);
                    }
                  }),
                  (c[7] = S),
                  (c[8] = P),
                  (c[9] = o))
                : (o = c[9]),
              c[10] !== S ? ((s = [S]), (c[10] = S), (c[11] = s)) : (s = c[11]),
              l.useEffect(o, s),
              c[12] !== b ||
                c[13] !== u ||
                c[14] !== m ||
                c[15] !== y ||
                c[16] !== v ||
                c[17] !== S ||
                c[18] !== _ ||
                c[19] !== g)
            ) {
              let e,
                t,
                n,
                r,
                l,
                i,
                o,
                s,
                {
                  top: h,
                  toPlay: w,
                  completed: z,
                  highlightedGameId: x,
                } = (function (e, t, n) {
                  let a = e.find((e) => e.daily.gameId === t),
                    r = "completing" === n,
                    l = (e) => !e.daily.completed || (r && e === a),
                    i = e.filter(l),
                    o = e.filter((e) => !l(e));
                  if (a && i.includes(a)) {
                    let e = i.filter((e) => e !== a);
                    return {
                      top: {
                        kind: r ? "justCompleted" : "nowPlaying",
                        entry: a,
                      },
                      toPlay: e,
                      completed: o,
                      highlightedGameId: r ? e[0]?.daily.gameId : void 0,
                    };
                  }
                  let [s, ...d] = i;
                  return {
                    top: s ? { kind: "upNext", entry: s } : null,
                    toPlay: d,
                    completed: o,
                    highlightedGameId: "settled" === n ? t : void 0,
                  };
                })(m, u, S),
                A = h?.kind === "nowPlaying" ? _ : -1;
              if (
                (c[21] === Symbol.for("react.memo_cache_sentinel")
                  ? ((e = e8.Ru._({ id: "common.dailyGames.title" })),
                    (c[21] = e))
                  : (e = c[21]),
                c[22] === Symbol.for("react.memo_cache_sentinel")
                  ? ((t = (0, a.jsx)("h2", {
                      className: tc().title,
                      children: (0, a.jsx)(p.x6, {
                        id: "common.dailyGames.title",
                      }),
                    })),
                    (c[22] = t))
                  : (t = c[22]),
                c[23] !== y
                  ? ((n = (0, a.jsxs)("div", {
                      className: tc().header,
                      children: [
                        t,
                        (0, a.jsx)(tn.A, {
                          nextResetAt: y,
                          className: tc().countdown,
                        }),
                      ],
                    })),
                    (c[23] = y),
                    (c[24] = n))
                  : (n = c[24]),
                c[25] !== A || c[26] !== _ || c[27] !== g)
              ) {
                let e;
                c[29] !== A || c[30] !== _
                  ? ((e = (e, t) =>
                      (0, a.jsx)(
                        "span",
                        {
                          className: (0, f.A)(
                            tc().segment,
                            t < _ && tc().segmentDone,
                            t === A && tc().segmentPlaying
                          ),
                        },
                        t
                      )),
                    (c[29] = A),
                    (c[30] = _),
                    (c[31] = e))
                  : (e = c[31]),
                  (r = (0, a.jsx)("span", {
                    className: tc().segments,
                    "aria-hidden": !0,
                    children: Array.from({ length: g }, e),
                  })),
                  (c[25] = A),
                  (c[26] = _),
                  (c[27] = g),
                  (c[28] = r);
              } else r = c[28];
              c[32] !== _ || c[33] !== g
                ? ((l = { solved: _, total: g }),
                  (c[32] = _),
                  (c[33] = g),
                  (c[34] = l))
                : (l = c[34]),
                c[35] === Symbol.for("react.memo_cache_sentinel")
                  ? ((i = { 0: (0, a.jsx)("strong", {}) }), (c[35] = i))
                  : (i = c[35]),
                c[36] !== l
                  ? ((o = (0, a.jsx)("span", {
                      className: tc().progressLabel,
                      children: (0, a.jsx)(p.x6, {
                        id: "common.dailyGames.progress",
                        values: l,
                        components: i,
                      }),
                    })),
                    (c[36] = l),
                    (c[37] = o))
                  : (o = c[37]),
                c[38] !== r || c[39] !== o
                  ? ((s = (0, a.jsxs)("div", {
                      className: tc().progress,
                      children: [r, o],
                    })),
                    (c[38] = r),
                    (c[39] = o),
                    (c[40] = s))
                  : (s = c[40]),
                (d = (0, a.jsxs)("aside", {
                  className: tc().sidebar,
                  "aria-label": e,
                  children: [
                    n,
                    s,
                    h?.kind === "upNext"
                      ? (0, a.jsxs)(a.Fragment, {
                          children: [
                            (0, a.jsx)("h3", {
                              className: (0, f.A)(
                                tc().sectionTitle,
                                tc().upNextTitle
                              ),
                              children: (0, a.jsx)(p.x6, {
                                id: "common.dailyGames.upNext",
                              }),
                            }),
                            (0, a.jsx)("div", {
                              ref: b.ref(h.entry.daily.gameId),
                              children: (0, a.jsx)(tg, {
                                entry: h.entry,
                                className: tc().upNextCard,
                                children: (0, a.jsxs)("span", {
                                  className: tc().cardContent,
                                  children: [
                                    (0, a.jsxs)("span", {
                                      className: tc().row,
                                      children: [
                                        (0, a.jsx)(tm, {
                                          entry: h.entry,
                                          size: "large",
                                        }),
                                        (0, a.jsx)(t_, { entry: h.entry }),
                                      ],
                                    }),
                                    (0, a.jsx)("span", {
                                      className: (0, f.A)(
                                        ts().greenPill,
                                        tc().solveNow
                                      ),
                                      children: (0, a.jsx)(p.x6, {
                                        id: "common.dailyGames.solveNow",
                                      }),
                                    }),
                                  ],
                                }),
                              }),
                            }),
                          ],
                        })
                      : h &&
                        (0, a.jsxs)(a.Fragment, {
                          children: [
                            (0, a.jsx)("h3", {
                              className: (0, f.A)(
                                tc().sectionTitle,
                                tc().nowPlayingTitle
                              ),
                              children: (0, a.jsx)(p.x6, {
                                id: "common.dailyGames.nowPlaying",
                              }),
                            }),
                            (0, a.jsxs)("div", {
                              ref: b.ref(h.entry.daily.gameId),
                              className: (0, f.A)(
                                tc().nowPlayingCard,
                                "justCompleted" === h.kind && tc().justCompleted
                              ),
                              children: [
                                (0, a.jsxs)("div", {
                                  className: tc().nowPlayingRow,
                                  children: [
                                    (0, a.jsx)(tm, {
                                      entry: h.entry,
                                      size: "large",
                                      done: "justCompleted" === h.kind,
                                    }),
                                    (0, a.jsx)(t_, { entry: h.entry }),
                                  ],
                                }),
                                v &&
                                  "nowPlaying" === h.kind &&
                                  (0, a.jsxs)("div", {
                                    className: tc().notCompleted,
                                    "data-testid":
                                      "daily-sidebar-not-completed",
                                    children: [
                                      (0, a.jsx)(e6.I, {
                                        name: "warning",
                                        className: tc().notCompletedIcon,
                                      }),
                                      (0, a.jsxs)("span", {
                                        children: [
                                          (0, a.jsx)(p.x6, {
                                            id: "common.dailyGames.notCompleted",
                                          }),
                                          " ",
                                          (0, a.jsx)("button", {
                                            type: "button",
                                            className: tc().retry,
                                            onClick: ta.y,
                                            "data-testid":
                                              "daily-sidebar-retry",
                                            children: (0, a.jsx)(p.x6, {
                                              id: "common.dailyGames.tryAgain",
                                            }),
                                          }),
                                        ],
                                      }),
                                    ],
                                  }),
                              ],
                            }),
                          ],
                        }),
                    w.length > 0 &&
                      (0, a.jsxs)(a.Fragment, {
                        children: [
                          (0, a.jsxs)("h3", {
                            className: tc().sectionTitle,
                            children: [
                              (0, a.jsx)(p.x6, {
                                id: "common.dailyGames.toPlay",
                              }),
                              (0, a.jsx)("span", {
                                className: tc().sectionCount,
                                children: (0, a.jsx)(p.x6, {
                                  id: "common.dailyGames.left",
                                  values: { count: w.length },
                                }),
                              }),
                            ],
                          }),
                          (0, a.jsx)("ul", {
                            className: (0, f.A)(tc().list, tc().toPlayList),
                            children: w.map((e) =>
                              (0, a.jsx)(
                                "li",
                                {
                                  ref: b.ref(e.daily.gameId),
                                  children: (0, a.jsx)(tg, {
                                    entry: e,
                                    className: (0, f.A)(
                                      tc().listRow,
                                      e.daily.gameId === x && tc().highlightNext
                                    ),
                                    children: (0, a.jsxs)("span", {
                                      className: tc().row,
                                      children: [
                                        (0, a.jsx)(tm, {
                                          entry: e,
                                          size: "small",
                                        }),
                                        (0, a.jsx)(t_, { entry: e }),
                                        (0, a.jsx)("span", {
                                          className: ts().greenPill,
                                          children: (0, a.jsx)(p.x6, {
                                            id: "common.dailyGames.solveShort",
                                          }),
                                        }),
                                      ],
                                    }),
                                  }),
                                },
                                e.daily.gameId
                              )
                            ),
                          }),
                        ],
                      }),
                    z.length > 0 &&
                      (0, a.jsxs)(a.Fragment, {
                        children: [
                          (0, a.jsxs)("h3", {
                            className: tc().sectionTitle,
                            children: [
                              (0, a.jsx)(p.x6, {
                                id: "common.dailyGames.completed",
                              }),
                              (0, a.jsx)("span", {
                                className: tc().sectionCount,
                                children: (0, a.jsx)(p.x6, {
                                  id: "common.dailyGames.completedCount",
                                  values: { solved: z.length, total: g },
                                }),
                              }),
                            ],
                          }),
                          (0, a.jsx)("ul", {
                            className: (0, f.A)(tc().list, tc().completedList),
                            children: z.map((e) =>
                              (0, a.jsx)(
                                "li",
                                {
                                  ref: b.ref(e.daily.gameId),
                                  children: (0, a.jsx)(tg, {
                                    entry: e,
                                    className: (0, f.A)(
                                      tc().listRow,
                                      tc().completedRow,
                                      e.daily.gameId === x && tc().highlightDone
                                    ),
                                    children: (0, a.jsxs)("span", {
                                      className: tc().row,
                                      children: [
                                        (0, a.jsx)(tm, {
                                          entry: e,
                                          size: "small",
                                          done: !0,
                                        }),
                                        (0, a.jsx)(t_, { entry: e }),
                                        (0, a.jsx)("span", {
                                          className: tc().replay,
                                          children: (0, a.jsx)(e6.I, {
                                            name: "play",
                                          }),
                                        }),
                                      ],
                                    }),
                                  }),
                                },
                                e.daily.gameId
                              )
                            ),
                          }),
                        ],
                      }),
                  ],
                })),
                (c[12] = b),
                (c[13] = u),
                (c[14] = m),
                (c[15] = y),
                (c[16] = v),
                (c[17] = S),
                (c[18] = _),
                (c[19] = g),
                (c[20] = d);
            } else d = c[20];
            return d;
          },
          th = (e) => {
            let t,
              n,
              i,
              o,
              s,
              d,
              c,
              u,
              m = (0, r.c)(15),
              { scrollContainerRef: _, pinnedTopRef: g } = e,
              [y, h] = l.useState(!0);
            m[0] !== _
              ? ((t = () => {
                  let e = _?.current,
                    t = e ?? window,
                    n = () => {
                      let t = e
                        ? e.scrollTop + e.clientHeight < e.scrollHeight - 50
                        : 0 === window.scrollY;
                      h((e) => (t !== e ? t : e));
                    };
                  return (
                    n(),
                    t.addEventListener("scroll", n, { passive: !0 }),
                    () => {
                      t.removeEventListener("scroll", n);
                    }
                  );
                }),
                (n = [_]),
                (m[0] = _),
                (m[1] = t),
                (m[2] = n))
              : ((t = m[1]), (n = m[2])),
              l.useEffect(t, n),
              m[3] !== g || m[4] !== _
                ? ((i = (e) => {
                    e.stopPropagation();
                    let t = _?.current;
                    if (!t)
                      return void window.scrollBy({
                        top: 400,
                        behavior: "smooth",
                      });
                    let n = t.clientHeight - (g?.current?.offsetHeight ?? 0);
                    t.scrollBy({
                      top: Math.max(n - 120, n / 2),
                      behavior: "smooth",
                    });
                  }),
                  (m[3] = g),
                  (m[4] = _),
                  (m[5] = i))
                : (i = m[5]);
            let v = i,
              b = !y && e2().hidden;
            return (
              m[6] !== b
                ? ((o = (0, f.A)(e2().showMoreIndicatorDesktop, b)),
                  (m[6] = b),
                  (m[7] = o))
                : (o = m[7]),
              m[8] === Symbol.for("react.memo_cache_sentinel")
                ? ((s = (0, a.jsx)(e$.A, { name: "arrow-simple-down" })),
                  (d = (0, a.jsx)(p.x6, { id: "game.viewMore" })),
                  (m[8] = s),
                  (m[9] = d))
                : ((s = m[8]), (d = m[9])),
              m[10] !== v
                ? ((c = (0, a.jsxs)(eY.A, {
                    className: e2().showMoreButtonDesktop,
                    variant: "contained",
                    onClick: v,
                    children: [s, d],
                  })),
                  (m[10] = v),
                  (m[11] = c))
                : (c = m[11]),
              m[12] !== o || m[13] !== c
                ? ((u = (0, a.jsx)("div", { className: o, children: c })),
                  (m[12] = o),
                  (m[13] = c),
                  (m[14] = u))
                : (u = m[14]),
              u
            );
          },
          tp = () => {
            let e,
              t = (0, r.c)(2),
              n = (0, V.Y)();
            return (
              t[0] !== n
                ? ((e = (0, a.jsx)("div", { style: { height: n } })),
                  (t[0] = n),
                  (t[1] = e))
                : (e = t[1]),
              e
            );
          },
          tf = d()(
            () =>
              Promise.all([
                n.e(73940),
                n.e(110),
                n.e(8272),
                n.e(17698),
                n.e(59160),
                n.e(65527),
                n.e(37239),
              ]).then(n.bind(n, 65527)),
            {
              loadableGenerated: { webpack: () => [65527] },
              ssr: !1,
              loading: () => (0, a.jsx)(tp, {}),
            }
          ),
          tv = (e) => {
            let t,
              n,
              i,
              o,
              s,
              d,
              c,
              u,
              _,
              g,
              v,
              b = (0, r.c)(27),
              { game: w, related: z } = e,
              x =
                "enabled" ===
                (0, es.U)("czyExpGamePageScrollableSidebar_CZY_21338b"),
              { breakpoints: A } = (0, y.D)();
            b[0] !== A
              ? ((t = A.up("lg")), (b[0] = A), (b[1] = t))
              : (t = b[1]);
            let S = (0, h.A)(t),
              B = x && S,
              k = l.useRef(null),
              P = l.useRef(null),
              j = (0, e5.r)(w);
            if (
              (b[2] !== B
                ? ((n = () => {
                    let e,
                      t = k.current;
                    if (!B || !t) return;
                    let n = () => {
                      t.classList.add(e2().isScrolling),
                        clearTimeout(e),
                        (e = setTimeout(
                          () => t.classList.remove(e2().isScrolling),
                          150
                        ));
                    };
                    return (
                      t.addEventListener("scroll", n, { passive: !0 }),
                      () => {
                        t.removeEventListener("scroll", n),
                          clearTimeout(e),
                          t.classList.remove(e2().isScrolling);
                      }
                    );
                  }),
                  (i = [B]),
                  (b[2] = B),
                  (b[3] = n),
                  (b[4] = i))
                : ((n = b[3]), (i = b[4])),
              l.useEffect(n, i),
              j)
            ) {
              let e, t;
              return (
                b[5] === Symbol.for("react.memo_cache_sentinel")
                  ? ((e = (0, f.A)(e2().rightSidebar, e2().dailyGamesSidebar)),
                    (b[5] = e))
                  : (e = b[5]),
                b[6] !== w.id
                  ? ((t = (0, a.jsx)("div", {
                      className: e,
                      children: (0, a.jsx)(ty, { currentGameId: w.id }),
                    })),
                    (b[6] = w.id),
                    (b[7] = t))
                  : (t = b[7]),
                t
              );
            }
            let D = x && e2().scrollable;
            return (
              b[8] !== D
                ? ((o = (0, f.A)(e2().rightSidebar, D)), (b[8] = D), (b[9] = o))
                : (o = b[9]),
              b[10] !== w
                ? ((s =
                    (0, V.m)(w) &&
                    (0, a.jsx)(tf, { game: w, position: "right-column" })),
                  (b[10] = w),
                  (b[11] = s))
                : (s = b[11]),
              b[12] === Symbol.for("react.memo_cache_sentinel")
                ? ((d = (0, a.jsx)(e4, {
                    verticalLabel: !0,
                    addAdBlockWarning: !0,
                    customLabelStyle: {
                      marginLeft: 0,
                      transform: "translate(0)",
                      right: "0",
                      top: 255,
                    },
                    customAdWrapperStyle: {
                      boxShadow: "inset 0px 0px 0px 1px var(--neutral-800)",
                      background:
                        "color-mix(in srgb, var(--cloud-40) 10%, transparent)",
                    },
                  })),
                  (b[12] = d))
                : (d = b[12]),
              b[13] !== w
                ? ((c = (0, a.jsx)("div", {
                    className: e2().rightMpuContainer,
                    ref: P,
                    children: (0, a.jsx)(U, { game: w, children: d }),
                  })),
                  (b[13] = w),
                  (b[14] = c))
                : (c = b[14]),
              b[15] === Symbol.for("react.memo_cache_sentinel")
                ? ((u = (0, a.jsx)("div", {
                    className: e2().playNextTitle,
                    children: (0, a.jsx)(p.x6, { id: "game.related.playNext" }),
                  })),
                  (b[15] = u))
                : (u = b[15]),
              b[16] !== z
                ? ((_ = (0, a.jsxs)("div", {
                    className: e2().rightGridContainer,
                    children: [
                      u,
                      (0, a.jsx)(m.x, {
                        newClickOrigin: "gamePage-related",
                        children: (0, a.jsx)(e0, {
                          displayedGames: z,
                          twoColumnHoverScale: !0,
                          className: "game-page-related-grid",
                        }),
                      }),
                    ],
                  })),
                  (b[16] = z),
                  (b[17] = _))
                : (_ = b[17]),
              b[18] !== w.isPreview || b[19] !== B
                ? ((g =
                    !w.isPreview &&
                    (0, a.jsx)(th, {
                      scrollContainerRef: B ? k : void 0,
                      pinnedTopRef: P,
                    })),
                  (b[18] = w.isPreview),
                  (b[19] = B),
                  (b[20] = g))
                : (g = b[20]),
              b[21] !== _ ||
              b[22] !== g ||
              b[23] !== o ||
              b[24] !== s ||
              b[25] !== c
                ? ((v = (0, a.jsxs)("div", {
                    className: o,
                    ref: k,
                    children: [s, c, _, g],
                  })),
                  (b[21] = _),
                  (b[22] = g),
                  (b[23] = o),
                  (b[24] = s),
                  (b[25] = c),
                  (b[26] = v))
                : (v = b[26]),
              v
            );
          },
          tb = d()(
            () =>
              Promise.all([
                n.e(80580),
                n.e(56448),
                n.e(64773),
                n.e(60700),
              ]).then(n.bind(n, 60700)),
            {
              loadableGenerated: { webpack: () => [60700] },
              loading: () => null,
              ssr: !1,
            }
          ),
          tw = d()(
            () =>
              Promise.all([
                n.e(80580),
                n.e(56448),
                n.e(62005),
                n.e(42886),
                n.e(92179),
                n.e(12039),
              ]).then(n.bind(n, 12039)),
            {
              loadableGenerated: { webpack: () => [12039] },
              loading: () => null,
              ssr: !1,
            }
          ),
          tz = d()(
            () =>
              Promise.all([
                n.e(73940),
                n.e(110),
                n.e(8272),
                n.e(17698),
                n.e(59160),
                n.e(65527),
                n.e(37239),
              ]).then(n.bind(n, 65527)),
            {
              loadableGenerated: { webpack: () => [65527] },
              ssr: !1,
              loading: () => (0, a.jsx)("div", { style: { height: "99px" } }),
            }
          ),
          tx = (e) => {
            let t,
              n,
              s,
              d,
              c,
              y,
              h,
              p,
              f,
              v,
              b,
              w,
              z,
              x,
              A,
              S,
              B,
              k,
              P,
              j,
              D,
              E = (0, r.c)(58),
              {
                game: C,
                previewSubmission: L,
                previewBuild: I,
                isQaTool: T,
                disableSubmitQA: M,
                submissionBlocked: O,
                crawlerData: F,
              } = e;
            E[0] !== T || E[1] !== I || E[2] !== L
              ? ((t = T && (0, o.O)(L) && (0, o.O)(I)),
                (E[0] = T),
                (E[1] = I),
                (E[2] = L),
                (E[3] = t))
              : (t = E[3]);
            let W = t,
              [H, Q] = l.useState(!1);
            E[4] === Symbol.for("react.memo_cache_sentinel")
              ? ((n = () => Q(!0)), (E[4] = n))
              : (n = E[4]);
            let q = n,
              { games: $, isInjecting: Y } = (0, g.z)(
                F?.isCrawler ?? !1,
                !0 === C.isPreview,
                C.id
              );
            E[5] === Symbol.for("react.memo_cache_sentinel")
              ? ((s = Array.from({ length: _.TS }, tA)), (E[5] = s))
              : (s = E[5]);
            let J = s;
            E[6] !== F?.games || E[7] !== F?.isCrawler || E[8] !== C.isPreview
              ? ((d = () =>
                  F?.isCrawler ? F?.games ?? [] : !0 === C.isPreview ? [] : J),
                (E[6] = F?.games),
                (E[7] = F?.isCrawler),
                (E[8] = C.isPreview),
                (E[9] = d))
              : (d = E[9]);
            let [Z, ee] = l.useState(d),
              { getModelGames: et } = (0, N.A)();
            E[10] !== C.id || E[11] !== C.isPreview || E[12] !== et
              ? ((c = () => {
                  let e = async () => {
                    let e = await et({
                      gameId: C.id,
                      numGames: _.TS,
                      place: "gamePage",
                    });
                    e &&
                      ee(
                        e.items.length % 2 == 0 ? e.items : e.items.slice(0, -1)
                      );
                  };
                  C.isPreview || e();
                }),
                (y = [et, ee, C.isPreview, C.id]),
                (E[10] = C.id),
                (E[11] = C.isPreview),
                (E[12] = et),
                (E[13] = c),
                (E[14] = y))
              : ((c = E[13]), (y = E[14])),
              l.useEffect(c, y);
            let en = Z.some(tS);
            e: {
              let e;
              if (en || Y) {
                h = J;
                break e;
              }
              E[15] !== $ || E[16] !== Z
                ? ((e = (0, u.cY)(Z, $, u.PV)),
                  (E[15] = $),
                  (E[16] = Z),
                  (E[17] = e))
                : (e = E[17]),
                (h = e);
            }
            let ea = h,
              er = W && !H;
            return (
              E[18] !== C || E[19] !== er
                ? ((p = (0, a.jsx)("div", {
                    className: e2().gfContainer,
                    children: (0, a.jsx)("div", {
                      className: e2().gfAspectRatioContainer,
                      children: (0, a.jsx)(eq, { game: C, waitForQATool: er }),
                    }),
                  })),
                  (E[18] = C),
                  (E[19] = er),
                  (E[20] = p))
                : (p = E[20]),
              E[21] !== C || E[22] !== L
                ? ((f = L && (0, a.jsx)(tw, { game: C })),
                  (E[21] = C),
                  (E[22] = L),
                  (E[23] = f))
                : (f = E[23]),
              E[24] !== C
                ? ((v =
                    (0, V.m)(C) &&
                    (0, a.jsx)(tz, { game: C, position: "under-gameframe" })),
                  (E[24] = C),
                  (E[25] = v))
                : (v = E[25]),
              E[26] === Symbol.for("react.memo_cache_sentinel")
                ? ((b = (0, a.jsx)(G, {
                    id: i.R.LeaderboardBelowGameRefresh,
                    verticalLabel: !0,
                    addAdBlockWarning: !0,
                    customLabelStyle: {
                      transform: "none",
                      right: -19,
                      writingMode: "vertical-lr",
                      top: 3,
                    },
                    customAdWrapperStyle: {
                      boxShadow: "inset 0px 0px 0px 1px var(--neutral-800)",
                      background:
                        "color-mix(in srgb, var(--cloud-40) 10%, transparent)",
                    },
                  })),
                  (E[26] = b))
                : (b = E[26]),
              E[27] !== C
                ? ((w = (0, a.jsx)("div", {
                    className: e2().adsLeaderboardContainer,
                    children: (0, a.jsx)("div", {
                      className: e2().adsLeaderboard,
                      children: (0, a.jsx)(U, { game: C, children: b }),
                    }),
                  })),
                  (E[27] = C),
                  (E[28] = w))
                : (w = E[28]),
              E[29] !== ea
                ? ((z = (0, a.jsx)(e3, { related: ea })),
                  (E[29] = ea),
                  (E[30] = z))
                : (z = E[30]),
              E[31] !== C
                ? ((x = (0, a.jsx)("div", {
                    className: e2().gameInfoContainer,
                    children: (0, a.jsx)(m.x, {
                      newClickOrigin: "gamePage",
                      children: (0, a.jsx)(K, { game: C }),
                    }),
                  })),
                  (E[31] = C),
                  (E[32] = x))
                : (x = E[32]),
              E[33] !== f ||
              E[34] !== v ||
              E[35] !== w ||
              E[36] !== z ||
              E[37] !== x ||
              E[38] !== p
                ? ((A = (0, a.jsxs)("div", {
                    className: e2().mainContainer,
                    id: "gamePageMainContainer",
                    children: [p, f, v, w, z, x],
                  })),
                  (E[33] = f),
                  (E[34] = v),
                  (E[35] = w),
                  (E[36] = z),
                  (E[37] = x),
                  (E[38] = p),
                  (E[39] = A))
                : (A = E[39]),
              E[40] !== C || E[41] !== ea
                ? ((S = (0, a.jsx)(tv, { game: C, related: ea })),
                  (E[40] = C),
                  (E[41] = ea),
                  (E[42] = S))
                : (S = E[42]),
              E[43] === Symbol.for("react.memo_cache_sentinel")
                ? ((B = (0, a.jsx)(R.A, {
                    height: 50,
                    playAnimation: !0,
                    addDelayTimeMs: 1e3,
                    center: !0,
                  })),
                  (E[43] = B))
                : (B = E[43]),
              E[44] !== M ||
              E[45] !== C ||
              E[46] !== I ||
              E[47] !== L ||
              E[48] !== W ||
              E[49] !== O
                ? ((k =
                    W &&
                    (0, a.jsx)(tb, {
                      submission: L,
                      build: I,
                      disableSubmitQA: M,
                      submissionBlocked: O,
                      game: C,
                      onReady: q,
                    })),
                  (E[44] = M),
                  (E[45] = C),
                  (E[46] = I),
                  (E[47] = L),
                  (E[48] = W),
                  (E[49] = O),
                  (E[50] = k))
                : (k = E[50]),
              E[51] !== A || E[52] !== S || E[53] !== k
                ? ((P = (0, a.jsxs)("div", {
                    className: e2().main,
                    children: [A, S, B, k],
                  })),
                  (E[51] = A),
                  (E[52] = S),
                  (E[53] = k),
                  (E[54] = P))
                : (P = E[54]),
              E[55] === Symbol.for("react.memo_cache_sentinel")
                ? ((j = (0, a.jsx)(X, {})), (E[55] = j))
                : (j = E[55]),
              E[56] !== P
                ? ((D = (0, a.jsxs)(a.Fragment, { children: [P, j] })),
                  (E[56] = P),
                  (E[57] = D))
                : (D = E[57]),
              D
            );
          };
        function tA(e, t) {
          return {
            id: `${t}`,
            name: `loading-${t}`,
            slug: `loading-${t}`,
            cover: void 0,
            videos: (0, c.R)(),
            status: "PUBLISHED",
            loading: !0,
          };
        }
        function tS(e) {
          return e.loading;
        }
      },
      75864: (e) => {
        e.exports = {
          sidebar: "DailyPuzzlesSidebar_sidebar__V4xgg",
          header: "DailyPuzzlesSidebar_header__TUwu5",
          title: "DailyPuzzlesSidebar_title__n_Bh7",
          countdown: "DailyPuzzlesSidebar_countdown__9SU3F",
          progress: "DailyPuzzlesSidebar_progress__XhhRU",
          segments: "DailyPuzzlesSidebar_segments__Ia9DM",
          segment: "DailyPuzzlesSidebar_segment__gTmop",
          segmentDone: "DailyPuzzlesSidebar_segmentDone__2mRFG",
          segmentPlaying: "DailyPuzzlesSidebar_segmentPlaying__YXo3D",
          "segment-sweep": "DailyPuzzlesSidebar_segment-sweep__HQess",
          progressLabel: "DailyPuzzlesSidebar_progressLabel__5UrZy",
          sectionTitle: "DailyPuzzlesSidebar_sectionTitle___QMU5",
          nowPlayingTitle: "DailyPuzzlesSidebar_nowPlayingTitle__lP0YI",
          upNextTitle: "DailyPuzzlesSidebar_upNextTitle__InqLd",
          sectionCount: "DailyPuzzlesSidebar_sectionCount__oquZ7",
          row: "DailyPuzzlesSidebar_row__LKIRi",
          thumb: "DailyPuzzlesSidebar_thumb__ueDoj",
          large: "DailyPuzzlesSidebar_large__ky_DO",
          small: "DailyPuzzlesSidebar_small__Np80U",
          thumbDone: "DailyPuzzlesSidebar_thumbDone__gXfYE",
          check: "DailyPuzzlesSidebar_check__lwDkM",
          justCompleted: "DailyPuzzlesSidebar_justCompleted__rr9rH",
          pop: "DailyPuzzlesSidebar_pop__79fzK",
          text: "DailyPuzzlesSidebar_text__DYqQr",
          name: "DailyPuzzlesSidebar_name__VLDh9",
          nowPlayingCard: "DailyPuzzlesSidebar_nowPlayingCard__daj93",
          nowPlayingRow: "DailyPuzzlesSidebar_nowPlayingRow__tyBbT",
          notCompleted: "DailyPuzzlesSidebar_notCompleted__CBm2E",
          notCompletedIcon: "DailyPuzzlesSidebar_notCompletedIcon__buy4_",
          retry: "DailyPuzzlesSidebar_retry__8lAtH",
          upNextCard: "DailyPuzzlesSidebar_upNextCard__86Ui7",
          cardContent: "DailyPuzzlesSidebar_cardContent__Dwxtn",
          solveNow: "DailyPuzzlesSidebar_solveNow__QJ_AX",
          list: "DailyPuzzlesSidebar_list__xRX0q",
          toPlayList: "DailyPuzzlesSidebar_toPlayList__unQtT",
          completedList: "DailyPuzzlesSidebar_completedList__Mjw8K",
          listRow: "DailyPuzzlesSidebar_listRow__Lm8Cr",
          completedRow: "DailyPuzzlesSidebar_completedRow__oIxKU",
          highlightNext: "DailyPuzzlesSidebar_highlightNext__bzWH7",
          highlightDone: "DailyPuzzlesSidebar_highlightDone__06xwO",
          replay: "DailyPuzzlesSidebar_replay__xgmoM",
        };
      },
      76436: (e, t, n) => {
        "use strict";
        n.d(t, { G: () => r });
        var a = n(55729);
        function r() {
          let e = a.useRef(new Map()),
            t = a.useRef(null),
            n = a.useCallback(() => {
              t.current = new Map(
                [...e.current].map((e) => {
                  let [t, n] = e;
                  return [t, n.getBoundingClientRect().top];
                })
              );
            }, []);
          return (
            a.useLayoutEffect(() => {
              if (!t.current) return;
              let n = t.current;
              (t.current = null),
                e.current.forEach((e, t) => {
                  let a = n.get(t);
                  if (void 0 === a) return;
                  let r = a - e.getBoundingClientRect().top;
                  0 !== r &&
                    e.animate(
                      [
                        { transform: `translateY(${r}px)` },
                        { transform: "none" },
                      ],
                      { duration: 250, easing: "cubic-bezier(0.16, 1, 0.3, 1)" }
                    );
                });
            }),
            {
              capture: n,
              ref: (t) => (n) => {
                n ? e.current.set(t, n) : e.current.delete(t);
              },
            }
          );
        }
      },
      77502: (e, t, n) => {
        "use strict";
        n.d(t, { EI: () => o, Pj: () => i, pn: () => l });
        var a = n(98417),
          r = n(46571);
        function l(e) {
          if (!(0, a.O)(e)) return null;
          let t = parseFloat(e);
          return Number.isNaN(t) ? null : t;
        }
        function i(e, t) {
          return (0, r.A)(e, t, { maximumFractionDigits: 2 });
        }
        function o(e, t) {
          let n = l(t);
          return (0, a.O)(n) ? i(e, n) : null;
        }
      },
      78339: (e) => {
        e.exports = {
          czyButton: "AdUnitAlternatives_czyButton___umGt",
          "czyButton--contained--purple":
            "AdUnitAlternatives_czyButton--contained--purple__4F1q1",
          "czyButton--contained--white":
            "AdUnitAlternatives_czyButton--contained--white__cv2cs",
          "czyButton--contained--grey":
            "AdUnitAlternatives_czyButton--contained--grey__tDD9t",
          "czyButton--contained--warning":
            "AdUnitAlternatives_czyButton--contained--warning__tMRcH",
          "czyButton--contained--alert":
            "AdUnitAlternatives_czyButton--contained--alert__nV_uV",
          "czyButton--contained--success":
            "AdUnitAlternatives_czyButton--contained--success__SJzZ4",
          "czyButton--contained--black":
            "AdUnitAlternatives_czyButton--contained--black__f89W6",
          "czyButton--contained--green-gradient":
            "AdUnitAlternatives_czyButton--contained--green-gradient__IEWo_",
          "czyButton--contained--animated-green-gradient":
            "AdUnitAlternatives_czyButton--contained--animated-green-gradient__4jpmK",
          "scroll-gradient": "AdUnitAlternatives_scroll-gradient__Xdf6z",
          "czyButton--outlined--purple":
            "AdUnitAlternatives_czyButton--outlined--purple__FVzXi",
          "czyButton--link--purple":
            "AdUnitAlternatives_czyButton--link--purple__telH_",
          "czyButton--outlined--white":
            "AdUnitAlternatives_czyButton--outlined--white__K2O2Y",
          "czyButton--link--white":
            "AdUnitAlternatives_czyButton--link--white__p8fXK",
          "czyButton--outlined--grey":
            "AdUnitAlternatives_czyButton--outlined--grey__pOazL",
          "czyButton--link--grey":
            "AdUnitAlternatives_czyButton--link--grey__4Tixr",
          "czyButton--outlined--warning":
            "AdUnitAlternatives_czyButton--outlined--warning__4G6j3",
          "czyButton--link--warning":
            "AdUnitAlternatives_czyButton--link--warning__a_utS",
          "czyButton--outlined--alert":
            "AdUnitAlternatives_czyButton--outlined--alert__vzUDK",
          "czyButton--link--alert":
            "AdUnitAlternatives_czyButton--link--alert__DITfG",
          "czyButton--outlined--success":
            "AdUnitAlternatives_czyButton--outlined--success__6uGLa",
          "czyButton--link--success":
            "AdUnitAlternatives_czyButton--link--success__nUHrh",
          "czyButton--outlined":
            "AdUnitAlternatives_czyButton--outlined__AeTzs",
          "czyButton--disabled":
            "AdUnitAlternatives_czyButton--disabled__hJi8Y",
          "czyButton--height50":
            "AdUnitAlternatives_czyButton--height50__OwbQU",
          "czyButton--height34":
            "AdUnitAlternatives_czyButton--height34__n4GBJ",
          "czyButton--height28":
            "AdUnitAlternatives_czyButton--height28__0LEbG",
          "czyButton--fullWidth":
            "AdUnitAlternatives_czyButton--fullWidth__PzSkC",
          "czyButton--headerIcon":
            "AdUnitAlternatives_czyButton--headerIcon__CZ_Kn",
          "czyButton--headerIcon--desktop":
            "AdUnitAlternatives_czyButton--headerIcon--desktop__4s_Bq",
          "czyButton--headerIcon--mobile":
            "AdUnitAlternatives_czyButton--headerIcon--mobile__DB7fB",
          "czyButton--headerIcon--withLabel":
            "AdUnitAlternatives_czyButton--headerIcon--withLabel__Cb_7C",
          adUnitPlaceholder: "AdUnitAlternatives_adUnitPlaceholder__XsD6j",
          wide: "AdUnitAlternatives_wide__28zVb",
          placeholderTitle: "AdUnitAlternatives_placeholderTitle__KVaAM",
          fontSize15: "AdUnitAlternatives_fontSize15__LZsbR",
          fontSize20: "AdUnitAlternatives_fontSize20__QAGk8",
          placeholderSubtitle: "AdUnitAlternatives_placeholderSubtitle__bKUf5",
          adUnitAlternative: "AdUnitAlternatives_adUnitAlternative___KK86",
          image: "AdUnitAlternatives_image__HbCbx",
          fontSize28: "AdUnitAlternatives_fontSize28__00cXM",
          secondLayout: "AdUnitAlternatives_secondLayout__3s3G4",
          iconButton: "AdUnitAlternatives_iconButton__RhOan",
          horBackground: "AdUnitAlternatives_horBackground__c87fr",
          squareBackground: "AdUnitAlternatives_squareBackground__cCUGh",
        };
      },
      80638: (e, t, n) => {
        "use strict";
        n.d(t, { A: () => l });
        var a = n(55729);
        function r() {
          return (r =
            Object.assign ||
            function (e) {
              for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                for (var a in n)
                  Object.prototype.hasOwnProperty.call(n, a) && (e[a] = n[a]);
              }
              return e;
            }).apply(this, arguments);
        }
        let l = function (e, t) {
          void 0 === t && (t = {});
          var l = t,
            i = l.volume,
            o = void 0 === i ? 1 : i,
            s = l.playbackRate,
            d = void 0 === s ? 1 : s,
            c = l.soundEnabled,
            u = void 0 === c || c,
            m = l.interrupt,
            _ = void 0 !== m && m,
            g = l.onload,
            y = (function (e, t) {
              if (null == e) return {};
              var n,
                a,
                r = {},
                l = Object.keys(e);
              for (a = 0; a < l.length; a++)
                t.indexOf((n = l[a])) >= 0 || (r[n] = e[n]);
              return r;
            })(l, [
              "volume",
              "playbackRate",
              "soundEnabled",
              "interrupt",
              "onload",
            ]),
            h = a.useRef(null),
            p = a.useRef(!1),
            f = a.useState(!1),
            v = f[0],
            b = f[1],
            w = a.useState(null),
            z = w[0],
            x = w[1],
            A = a.useState(null),
            S = A[0],
            B = A[1],
            k = function () {
              "function" == typeof g && g.call(this),
                p.current && x(1e3 * this.duration());
            };
          (0, a.useEffect)(function () {
            return (
              n
                .e(44281)
                .then(n.t.bind(n, 44281, 23))
                .then(function (t) {
                  p.current ||
                    ((h.current = t.Howl),
                    (p.current = !0),
                    B(
                      new h.current(
                        r({ src: [e], volume: o, rate: d, onload: k }, y)
                      )
                    ));
                }),
              function () {
                p.current = !1;
              }
            );
          }, []),
            a.useEffect(
              function () {
                h.current &&
                  S &&
                  B(new h.current(r({ src: [e], volume: o, onload: k }, y)));
              },
              [e]
            ),
            a.useEffect(
              function () {
                S && (S.volume(o), S.rate(d));
              },
              [o, d]
            );
          var P = a.useCallback(
              function (e) {
                void 0 === e && (e = {}),
                  S &&
                    (u || e.forceSoundEnabled) &&
                    (_ && S.stop(),
                    e.playbackRate && S.rate(e.playbackRate),
                    S.play(e.id),
                    p.current &&
                      S.once("end", function () {
                        S.playing() || b(!1);
                      }),
                    p.current && b(!0));
              },
              [S, u, _]
            ),
            j = a.useCallback(
              function (e) {
                S && (S.stop(e), p.current && b(!1));
              },
              [S]
            ),
            D = a.useCallback(
              function (e) {
                S && (S.pause(e), p.current && b(!1));
              },
              [S]
            );
          return [
            P,
            { sound: S, stop: j, pause: D, isPlaying: v, duration: z },
          ];
        };
      },
      86268: (e) => {
        e.exports = {
          countdown: "DailyResetCountdown_countdown__KJ5YH",
          time: "DailyResetCountdown_time__fpfQ5",
          hourglass: "DailyResetCountdown_hourglass__kjc7m",
        };
      },
      88748: (e, t, n) => {
        "use strict";
        n.d(t, { P4: () => i, VG: () => r, qP: () => l });
        var a = n(23942);
        let r = {
          limitAdFrequency: {
            label: "Limit midroll frequency",
            defaultAdmin: !1,
            defaultDev: !0,
            tooltip:
              "On CrazyGames we limit midrolls in favor of UX. Toggle to show every midroll.",
          },
          testAds: {
            label: "Include test ads",
            defaultAdmin: !0,
            defaultDev: !0,
            tooltip: "Show test ads instead of real ads.",
          },
          secretSkipVideoAndFallback: {
            label: "Skip video and fallback ads",
            defaultAdmin: !1,
            defaultDev: !1,
            tooltip: "Skip rewarded/midroll ads.",
          },
          enableUnityCache: {
            label: "Enable Unity Cache",
            defaultAdmin: !1,
            defaultDev: !1,
            tooltip:
              "Get Unity files from local cache; should be 'false' when measuring initial download size.",
          },
          instantJoin: {
            label: "Instant Multiplayer",
            defaultAdmin: !1,
            defaultDev: !1,
            tooltip:
              "Start the game as party host with 'instant multiplayer' setting.",
          },
          disableChat: {
            label: "Disable Chat setting",
            defaultAdmin: !1,
            defaultDev: !1,
            tooltip:
              "Start the game with user setting to disable chat enabled.",
          },
          sdkFailMode: {
            label: "Throw SDK Error",
            defaultAdmin: !1,
            defaultDev: !1,
            tooltip:
              "Force all SDK methods to throw errors, even those that don't usually throw. Example: for testing rewarded ad errors.",
          },
          sdk_debug: {
            label: "SDK Debug",
            defaultAdmin: !0,
            defaultDev: !0,
            tooltip: "Enable SDK debug logging.",
          },
        };
        function l(e, t) {
          let n = new URL(e, window.location.origin);
          return (
            Object.entries(t).forEach((e) => {
              let [a] = e;
              return n.searchParams.set(a, `${t[a]}`);
            }),
            n.toString()
          );
        }
        function i() {
          let e = new URLSearchParams(window.location.search),
            t = "admin" === e.get(a.S),
            n = {};
          Object.entries(r).forEach((e) => {
            let [a, r] = e;
            n[a] = t ? r.defaultAdmin : r.defaultDev;
          });
          let l = e.get("initialDisableChatQaOption");
          null !== l && (n.disableChat = "true" === l);
          let i = e.get("initialInstantMultiplayerQaOption");
          return null !== i && (n.instantJoin = "true" === i), n;
        }
      },
      97429: (e, t) => {
        "use strict";
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.BADGE_ORDER =
            t.PERCENT_THRESHOLDS =
            t.SEASON_END_AWARDS_CONFIG =
            t.PODIUM_AWARDS =
              void 0),
          (t.PODIUM_AWARDS = [
            { position: 1, name: "gold" },
            { position: 2, name: "silver" },
            { position: 3, name: "bronze" },
          ]);
        let n = { percentage: 0.01, name: "level_4" },
          a = { percentage: 0.05, name: "level_5" },
          r = { percentage: 0.1, name: "level_6" };
        (t.SEASON_END_AWARDS_CONFIG = [n, a, r]),
          (t.PERCENT_THRESHOLDS = {
            level_4: n.percentage,
            level_5: a.percentage,
            level_6: r.percentage,
            default: 1,
          }),
          (t.BADGE_ORDER = [
            "gold",
            "silver",
            "bronze",
            "level_4",
            "level_5",
            "level_6",
            "default",
          ]);
      },
    },
  ]);
