(function () {
  "use strict";
  var h,
    aa = Object.defineProperty;
  function ba(a) {
    a = [
      "object" == typeof globalThis && globalThis,
      a,
      "object" == typeof window && window,
      "object" == typeof self && self,
      "object" == typeof global && global,
    ];
    for (var b = 0; b < a.length; ++b) {
      var c = a[b];
      if (c && c.Math == Math) return c;
    }
    throw Error("Cannot find global object");
  }
  var ca = ba(this);
  function da(a, b) {
    if (b)
      a: {
        var c = ca;
        a = a.split(".");
        for (var d = 0; d < a.length - 1; d++) {
          var e = a[d];
          if (!(e in c)) break a;
          c = c[e];
        }
        a = a[a.length - 1];
        d = c[a];
        b = b(d);
        b != d &&
          b != null &&
          aa(c, a, { configurable: !0, writable: !0, value: b });
      }
  }
  da("globalThis", function (a) {
    return a || ca;
  });
  da("Symbol.dispose", function (a) {
    return a ? a : Symbol("Symbol.dispose");
  }); /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var q = this || self;
  function u(a) {
    var b = typeof a;
    return (b == "object" && a != null) || b == "function";
  }
  function ea(a, b) {
    var c = Array.prototype.slice.call(arguments, 1);
    return function () {
      var d = c.slice();
      d.push.apply(d, arguments);
      return a.apply(this, d);
    };
  }
  function v(a, b) {
    function c() {}
    c.prototype = b.prototype;
    a.L = b.prototype;
    a.prototype = new c();
    a.prototype.constructor = a;
    a.U = function (d, e, f) {
      for (
        var g = Array(arguments.length - 2), l = 2;
        l < arguments.length;
        l++
      )
        g[l - 2] = arguments[l];
      return b.prototype[e].apply(d, g);
    };
  }
  function fa(a) {
    q.setTimeout(() => {
      throw a;
    }, 0);
  }
  var ha, w;
  a: {
    for (var ia = ["CLOSURE_FLAGS"], ja = q, ka = 0; ka < ia.length; ka++)
      if (((ja = ja[ia[ka]]), ja == null)) {
        w = null;
        break a;
      }
    w = ja;
  }
  var la = w && w[748402147];
  ha = la != null ? la : !0;
  function x() {
    var a = q.navigator;
    return a && (a = a.userAgent) ? a : "";
  }
  function ma(a, b) {
    b = Array.prototype.indexOf.call(a, b, void 0);
    var c;
    (c = b >= 0) && Array.prototype.splice.call(a, b, 1);
    return c;
  }
  var na =
      x().indexOf("Gecko") != -1 &&
      !(
        x().toLowerCase().indexOf("webkit") != -1 && x().indexOf("Edge") == -1
      ) &&
      !(x().indexOf("Trident") != -1 || x().indexOf("MSIE") != -1) &&
      x().indexOf("Edge") == -1,
    oa = x().toLowerCase().indexOf("webkit") != -1 && x().indexOf("Edge") == -1;
  function pa(a, b) {
    a.__closure__error__context__984382 ||
      (a.__closure__error__context__984382 = {});
    a.__closure__error__context__984382.severity = b;
  }
  var qa = void 0;
  function ra(a) {
    a = Error(a);
    pa(a, "warning");
    return a;
  }
  function sa(a, b = !1) {
    return b && Symbol.for && a
      ? Symbol.for(a)
      : a != null
      ? Symbol(a)
      : Symbol();
  }
  var ta = sa(),
    ua = sa("m_m", !0);
  var y = sa("jas", !0);
  var va = {};
  function wa(a, b) {
    return b === void 0
      ? a.i !== z && !!(2 & (a.H[y] | 0))
      : !!(2 & b) && a.i !== z;
  }
  var z = {};
  var xa = typeof q.BigInt === "function" && typeof q.BigInt(0) === "bigint";
  var ya = Number.MIN_SAFE_INTEGER.toString(),
    za = xa ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
    Aa = Number.MAX_SAFE_INTEGER.toString(),
    Ba = xa ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;
  function Ca(a, b) {
    if (a.length > b.length) return !1;
    if (a.length < b.length || a === b) return !0;
    for (let c = 0; c < a.length; c++) {
      let d = a[c],
        e = b[c];
      if (d > e) return !1;
      if (d < e) return !0;
    }
  }
  var Da = Number.isFinite;
  function Ea(a) {
    if (typeof a !== "boolean") {
      var b = typeof a;
      throw Error(
        `Expected boolean but got ${
          b != "object" ? b : a ? (Array.isArray(a) ? "array" : b) : "null"
        }: ${a}`
      );
    }
    return a;
  }
  function A(a) {
    if (a != null) {
      if (!Da(a)) throw ra("enum");
      a |= 0;
    }
    return a;
  }
  function Fa(a) {
    if (typeof a !== "number") throw ra("int32");
    if (!Da(a)) throw ra("int32");
    return a | 0;
  }
  function Ga(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return Da(a) ? a | 0 : void 0;
  }
  function Ha(a) {
    if (a != null && typeof a !== "string") throw Error();
    return a;
  }
  function Ia(a) {
    return a;
  }
  function Ja(a, b, c, d) {
    var e = d !== void 0;
    d = !!d;
    var f = [],
      g = a.length,
      l = 4294967295,
      t = !1,
      k = !!(b & 64),
      n = k ? (b & 128 ? 0 : -1) : void 0;
    if (!(b & 1)) {
      var r = g && a[g - 1];
      r != null && typeof r === "object" && r.constructor === Object
        ? (g--, (l = g))
        : (r = void 0);
      if (k && !(b & 128) && !e) {
        t = !0;
        var m;
        l = ((m = Ka) != null ? m : Ia)(l - n, n, a, r, void 0) + n;
      }
    }
    b = void 0;
    for (e = 0; e < g; e++)
      if (((m = a[e]), m != null && (m = c(m, d)) != null))
        if (k && e >= l) {
          let p = e - n,
            C;
          ((C = b) != null ? C : (b = {}))[p] = m;
        } else f[e] = m;
    if (r)
      for (let p in r) {
        a = r[p];
        if (a == null || (a = c(a, d)) == null) continue;
        g = +p;
        let C;
        if (k && !Number.isNaN(g) && (C = g + n) < l) f[C] = a;
        else {
          let hb;
          ((hb = b) != null ? hb : (b = {}))[p] = a;
        }
      }
    b && (t ? f.push(b) : (f[l] = b));
    return f;
  }
  function La(a) {
    switch (typeof a) {
      case "number":
        return Number.isFinite(a) ? a : "" + a;
      case "bigint":
        return (xa ? a >= za && a <= Ba : a[0] === "-" ? Ca(a, ya) : Ca(a, Aa))
          ? Number(a)
          : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          let b = a[y] | 0;
          return a.length === 0 && b & 1 ? void 0 : Ja(a, b, La);
        }
        if (a != null && a[ua] === va) return B(a);
        return;
    }
    return a;
  }
  var Ka;
  function B(a) {
    a = a.H;
    return Ja(a, a[y] | 0, La);
  }
  function Ma(a, b, c, d = 0) {
    if (a == null) {
      var e = 32;
      c ? ((a = [c]), (e |= 128)) : (a = []);
      b && (e = (e & -16760833) | ((b & 1023) << 14));
    } else {
      if (!Array.isArray(a)) throw Error("narr");
      e = a[y] | 0;
      if (ha && 1 & e) throw Error("rfarr");
      2048 & e && !(2 & e) && Na();
      if (e & 256) throw Error("farr");
      if (e & 64) return (e | d) !== e && (a[y] = e | d), a;
      if (c && ((e |= 128), c !== a[0])) throw Error("mid");
      a: {
        c = a;
        e |= 64;
        var f = c.length;
        if (f) {
          var g = f - 1;
          let t = c[g];
          if (t != null && typeof t === "object" && t.constructor === Object) {
            b = e & 128 ? 0 : -1;
            g -= b;
            if (g >= 1024) throw Error("pvtlmt");
            for (var l in t)
              if (((f = +l), f < g)) (c[f + b] = t[l]), delete t[l];
              else break;
            e = (e & -16760833) | ((g & 1023) << 14);
            break a;
          }
        }
        if (b) {
          l = Math.max(b, f - (e & 128 ? 0 : -1));
          if (l > 1024) throw Error("spvt");
          e = (e & -16760833) | ((l & 1023) << 14);
        }
      }
    }
    a[y] = e | 64 | d;
    return a;
  }
  function Na() {
    if (ha) throw Error("carr");
    if (ta != null) {
      var a;
      var b = (a = qa) != null ? a : (qa = {});
      a = b[ta] || 0;
      a >= 5 || ((b[ta] = a + 1), (b = Error()), pa(b, "incident"), fa(b));
    }
  }
  function Oa(a, b) {
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      var c = a[y] | 0;
      a.length === 0 && c & 1
        ? (a = void 0)
        : c & 2 ||
          (!b || 4096 & c || 16 & c
            ? (a = Pa(a, c, !1, b && !(c & 16)))
            : ((a[y] |= 34), c & 4 && Object.freeze(a)));
      return a;
    }
    if (a != null && a[ua] === va) {
      c = a.H;
      let d = c[y] | 0;
      wa(a, d) ||
        (d & 2
          ? (b = !0)
          : !(d & 32) || d & 4096
          ? (b = !1)
          : ((c[y] = d | 2), (a.i = z), (b = !0)),
        b ? ((a = new a.constructor(c)), (a.o = z)) : (a = Pa(c, d)));
      return a;
    }
  }
  function Pa(a, b, c, d) {
    d != null || (d = !!(34 & b));
    a = Ja(a, b, Oa, d);
    d = 32;
    c && (d |= 2);
    b = (b & 16769217) | d;
    a[y] = b;
    return a;
  }
  function Qa(a) {
    if (a.i === z) {
      var b = a.H;
      b = Pa(b, b[y] | 0);
      b[y] |= 2048;
      a.H = b;
      a.i = void 0;
      a.o = void 0;
      b = !0;
    } else b = !1;
    if (!b && wa(a, a.H[y] | 0)) throw Error();
  }
  function D(a, b) {
    a: {
      var c = a.H;
      if (b === -1) b = null;
      else {
        a = b + -1;
        var d = c.length - 1;
        if (d < 0) b = void 0;
        else if (a >= d)
          if (
            ((c = c[d]),
            c != null && typeof c === "object" && c.constructor === Object)
          )
            b = c[b];
          else if (a === d) b = c;
          else {
            b = void 0;
            break a;
          }
        else b = c[a];
      }
    }
    if (b !== null) return b;
  }
  function E(a, b, c) {
    Qa(a);
    var d = a.H;
    Ra(d, d[y] | 0, b, c);
    return a;
  }
  function Ra(a, b, c, d) {
    var e = c + -1,
      f = a.length - 1;
    if (f >= 0 && e >= f) {
      let g = a[f];
      if (g != null && typeof g === "object" && g.constructor === Object) {
        g[c] = d;
        return;
      }
    }
    e <= f
      ? (a[e] = d)
      : d !== void 0 &&
        ((b = ((b != null ? b : a[y] | 0) >> 14) & 1023 || 536870912),
        c >= b ? d != null && (a[b + -1] = { [c]: d }) : (a[e] = d));
  }
  function F(a, b, c, d) {
    Qa(a);
    var e = a.H;
    Ra(e, e[y] | 0, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
    return a;
  }
  function G(a, b, c) {
    c == null && (c = void 0);
    E(a, b, c);
    if (c && !wa(c)) {
      b = a.H;
      var d;
      d === void 0 && (d = b[y] | 0);
      d & 32 && !(d & 4096) && (b[y] = d | 4096);
    }
    return a;
  }
  function Sa(a, b) {
    a = D(a, b);
    return a == null || typeof a === "boolean"
      ? a
      : typeof a === "number"
      ? !!a
      : void 0;
  }
  function H(a, b) {
    var c;
    return (c = Sa(a, b)) != null ? c : !1;
  }
  function Ta(a, b) {
    var c;
    return (c = Ga(D(a, b))) != null ? c : 0;
  }
  function I(a, b) {
    a = D(a, b);
    a = a == null || typeof a === "string" ? a : void 0;
    return a != null ? a : "";
  }
  function J(a, b, c = 0) {
    a = D(a, b);
    a = a == null ? a : Da(a) ? a | 0 : void 0;
    return a != null ? a : c;
  }
  function K(a, b, c) {
    return E(a, b, c == null ? c : Ea(c));
  }
  function L(a, b, c) {
    return F(a, b, c == null ? c : Ea(c), !1);
  }
  function M(a, b, c) {
    return F(a, b, Ha(c), "");
  }
  var N = class {
    constructor(a) {
      this.H = Ma(a, void 0, void 0, 2048);
    }
    toJSON() {
      return B(this);
    }
  };
  N.prototype[ua] = va;
  N.prototype.toString = function () {
    return this.H.toString();
  };
  var Ua = class extends N {}; /*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
  var Va = globalThis.trustedTypes,
    Wa;
  function Xa() {
    var a = null;
    if (!Va) return a;
    try {
      let b = (c) => c;
      a = Va.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (b) {}
    return a;
  }
  var Ya = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  var Za = class {
    constructor(a) {
      this.i = a;
    }
    toString() {
      return this.i + "";
    }
  };
  function $a(a) {
    var b;
    Wa === void 0 && (Wa = Xa());
    a = (b = Wa) ? b.createHTML(a) : a;
    return new Za(a);
  }
  function ab(a) {
    if (a instanceof Za) return a.i;
    throw Error("");
  }
  function bb(a) {
    return String(a).replace(/\-([a-z])/g, function (b, c) {
      return c.toUpperCase();
    });
  }
  function cb(a) {
    return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function (b, c, d) {
      return c + d.toUpperCase();
    });
  }
  function db(a) {
    return a instanceof Za
      ? a
      : $a(
          String(a)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&apos;")
        );
  }
  function eb(a) {
    return fb(a);
  }
  function fb(a) {
    var b = db("");
    return $a(a.map((c) => ab(db(c))).join(ab(b).toString()));
  }
  var gb = /^[a-z][a-z\d-]*$/i,
    ib =
      "APPLET BASE EMBED IFRAME LINK MATH META OBJECT SCRIPT STYLE SVG TEMPLATE".split(
        " "
      ),
    jb = "AREA BR COL COMMAND HR IMG INPUT KEYGEN PARAM SOURCE TRACK WBR".split(
      " "
    ),
    kb = ["action", "formaction", "href"];
  function lb(a) {
    var b;
    if (!gb.test("div")) throw Error("");
    if (ib.indexOf("DIV") !== -1) throw Error("");
    var c = "<div";
    a && (c += mb(a));
    Array.isArray(b) || (b = b === void 0 ? [] : [b]);
    jb.indexOf("DIV") !== -1
      ? (c += ">")
      : ((a = eb(b.map((d) => (d instanceof Za ? d : db(String(d)))))),
        (c += ">" + a.toString() + "</div>"));
    return $a(c);
  }
  function mb(a) {
    var b = "",
      c = Object.keys(a);
    for (let f = 0; f < c.length; f++) {
      var d = c[f],
        e = a[d];
      if (!gb.test(d)) throw Error("");
      if (e !== void 0 && e !== null) {
        if (/^on./i.test(d)) throw Error("");
        kb.indexOf(d.toLowerCase()) !== -1 &&
          ((e = String(e)),
          (e = Ya.test(e) ? e : void 0),
          (e = e || "about:invalid#zClosurez"));
        d = `${d}="${db(String(e))}"`;
        b += " " + d;
      }
    }
    return b;
  }
  var nb =
    "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(
      " "
    );
  function ob(a, b) {
    for (let e = 1; e < arguments.length; e++) {
      var c = arguments[e];
      for (d in c) a[d] = c[d];
      for (let f = 0; f < nb.length; f++) {
        var d = nb[f];
        Object.prototype.hasOwnProperty.call(c, d) && (a[d] = c[d]);
      }
    }
  }
  function O(a, b, c) {
    if (typeof b === "string") pb(a, c, b);
    else for (let d in b) pb(a, b[d], d);
  }
  var qb = /^--.+/;
  function pb(a, b, c) {
    (c = rb(a, c)) &&
      (qb.test(c) ? a.style.setProperty(c, b) : (a.style[c] = b));
  }
  var sb = {};
  function rb(a, b) {
    var c = sb[b];
    if (!c) {
      var d = bb(b);
      c = d;
      a.style[d] === void 0 &&
        ((d = (oa ? "Webkit" : na ? "Moz" : null) + cb(d)),
        a.style[d] !== void 0 && (c = d));
      sb[b] = c;
    }
    return c;
  }
  function tb(a) {
    var b = a.offsetWidth,
      c = a.offsetHeight;
    c = oa && !b && !c;
    if ((b === void 0 || c) && a.getBoundingClientRect)
      try {
        a.getBoundingClientRect();
      } catch (d) {}
  }
  var ub = class extends N {};
  function vb(a) {
    return a.id === "mys-meta" ? a : a.querySelector("#mys-meta");
  }
  function wb(a, b, c, d = 0) {
    var e = a.getElementsByTagName("META");
    for (let f = 0; f < e.length; ++f)
      if (
        e[f].getAttribute("name") === b &&
        e[f].getAttribute("index") === d.toString()
      ) {
        e[f].setAttribute("content", c);
        return;
      }
    e = document.createElement("META");
    e.setAttribute("name", b);
    e.setAttribute("content", c);
    e.setAttribute("index", d.toString());
    b = vb(a);
    b ||
      ((b = document.createElement("div")),
      (b.id = "mys-meta"),
      (b.style.position = "absolute"),
      (b.style.display = "none"),
      a.appendChild(b));
    a = b;
    a.appendChild(e);
  }
  function xb(a) {
    switch (a) {
      case "aci":
        return 1;
      case "aci_feed":
        return 2;
      case "ace":
        return 3;
      case "ace_feed":
        return 4;
      case "rda":
        return 5;
      case "ulc":
        return 6;
      case "ssc":
        return 7;
      case "trv":
        return 8;
      case "t4a":
        return 9;
      case "vac":
        return 10;
      case "bumper":
        return 11;
      case "nonskip":
        return 12;
      case "vact4a":
        return 13;
      case "vacosv":
        return 14;
      case "rtb":
        return 15;
      case "demand_gen_video":
        return 16;
      case "t1_or_pmax_osv":
        return 17;
      default:
        return 0;
    }
  }
  function yb(a) {
    switch (a) {
      case 1:
        return "wi";
      case 2:
        return "ce";
      case 3:
        return "3g";
      case 6:
        return "4g";
      case 4:
        return "ed";
      default:
        return "un";
    }
  }
  function zb(a, b, c) {
    var d = b.l()[0];
    var e = b.m();
    var f,
      g = (f = d.v()) == null ? void 0 : f.l();
    f = (g == null ? 0 : H(g, 44)) ? g : new ub();
    M(f, 4, I(e, 4));
    L(f, 108, !1);
    var l = f,
      t = J(e, 3);
    E(l, 9, A(t));
    M(
      f,
      10,
      H(e, 56)
        ? "googleads.g.doubleclick-cn.net"
        : "googleads.g.doubleclick.net"
    );
    I(f, 25) || ((l = I(e, 104)) && M(f, 25, l));
    if ((l = b.u())) {
      (t = l.C().get("pubLocalizedAdCounterMsg")) && M(f, 52, t);
      var k, n;
      t = f;
      var r = (k = l.l()) != null ? k : !1;
      k = L(t, 8, r);
      l = (n = l.m()) != null ? n : !1;
      L(k, 142, l);
    }
    if (g == null ? 0 : H(g, 44)) c(b, f);
    else {
      g = d.C().m();
      n = f;
      k = g.m();
      n = G(n, 96, k);
      k = g.l();
      n = G(n, 97, k);
      k = g.v();
      G(n, 98, k);
      n = f;
      k = g.B();
      L(n, 113, k);
      n = f;
      k = g.C();
      n = K(n, 95, k);
      k = g.F();
      K(n, 94, k);
      n = d.l();
      k = f;
      l = Ta(e, 1);
      k = F(k, 1, l == null ? l : Fa(l), 0);
      l = Ta(e, 2);
      k = F(k, 2, l == null ? l : Fa(l), 0);
      k = M(k, 3, I(e, 13));
      k = L(k, 93, H(e, 5) && !H(e, 80));
      l = n.u();
      k = M(k, 46, l);
      l = g.D();
      K(k, 64, l);
      d = d.m();
      k = f;
      l = d.l();
      k = L(k, 34, l);
      d = d.m();
      L(k, 35, d);
      d = f;
      k = J(e, 53);
      d = F(d, 65, k == null ? k : Fa(k), 0);
      d = M(d, 26, I(e, 79) || "");
      k = yb(J(e, 82, 1)) || "";
      d = M(d, 27, k);
      d = M(d, 28, I(e, 60) || "");
      d = M(d, 29, I(e, 61) || "");
      k = String(n.m()) || "";
      d = M(d, 6, k);
      k = String(n.l()) || "";
      d = M(d, 7, k);
      k = g.A();
      d = K(d, 71, k);
      k = n.C();
      d = M(d, 19, k);
      n = n.F();
      M(d, 20, n);
      switch (J(e, 81)) {
        case 1:
          E(f, 57, A(1));
          break;
        case 2:
          E(f, 57, A(2));
          break;
        default:
          E(f, 57, A(0));
      }
      d = f;
      n = xb(g.I());
      F(d, 43, A(n), 0);
      d = f;
      n = g.G();
      d = G(d, 5, n);
      g = g.u();
      E(d, 105, Ha(g));
      c(b, f);
      c = K(f, 81, Sa(e, 72));
      g = Ga(D(e, 74));
      c = E(c, 83, g == null ? g : Fa(g));
      K(c, 85, H(e, 75));
    }
    e = f;
    wb(a.body, "video_config", JSON.stringify(B(e)));
    f = [];
    for (var m of b.l()) (c = m.u()) && f.push(c);
    m = a.body;
    for (c = 0; c < f.length; ++c)
      wb(m, "video_fields", JSON.stringify(B(f[c])), c);
    m = J(e, 9);
    if (m === 2 || m === 3)
      (b = b.l()[0].F() || new Ua()),
        wb(a.body, "rewarded_fields", JSON.stringify(B(b)));
  }
  function Ab(a) {
    a = a.body.getElementsByClassName("x-layout");
    if (typeof window.getComputedStyle !== "function") return a ? a[0] : null;
    for (let b of a)
      if (
        (a = b.parentElement) &&
        window.getComputedStyle(a).display !== "none"
      )
        return b;
    return null;
  }
  var Bb = class {
    constructor(a) {
      this.body = a;
    }
    dispatchEvent(a, b) {
      this.body.dispatchEvent(new CustomEvent(a, { detail: b }));
    }
  };
  var Cb = class extends N {};
  function Db(a) {
    var b = new Cb(),
      c = J(a.i, 19);
    c === 2 && (a.m.F() || (c = 1));
    F(b, 2, A(c), 0);
    c = G(b, 1, a.i);
    c = L(c, 4, H(a.i, 21));
    var d = a.l.l();
    c = G(c, 12, d);
    d = J(a.i, 94);
    c = F(c, 18, A(d), 0);
    c = L(c, 19, H(a.i, 92));
    d = J(a.i, 100);
    F(c, 20, A(d), 0);
    if ((c = a.l.m()))
      c.C() && ((d = c.l()), G(b, 10, d)), (c = c.m()) && G(b, 14, c);
    a = a.m.l() || !1;
    L(b, 16, a);
    return b;
  }
  class Eb {
    constructor(a) {
      this.i = a.m();
      this.l = a.C();
      this.m = a.F();
    }
  }
  var Fb;
  var Gb = class {
    enabledChannel() {}
    setSlice() {}
    setData() {}
    send() {}
    setDataAndSend() {}
    tick() {}
    populateServerPingbackOutput() {}
    flush() {
      return [];
    }
  };
  var Hb = class {
    constructor(a, b) {
      this.G = a;
      this.body = b;
      this.pingback = Fb || new Gb();
      this.runtime = {};
      this.context = new Bb(b);
      this.uid = (a = vb(b)) ? a.getAttribute("data-1") || "" : "";
      this.pingback.enabledChannel(1);
    }
    getConfig() {
      return new Cb();
    }
    o() {}
    l() {}
  };
  var Ib = class {
    constructor() {
      this.i = typeof mys !== "undefined" ? mys.pingback : void 0;
      this.l = 0;
    }
    enabledChannel(a) {
      this.l = a;
      var b;
      (b = this.i) == null || b.tick(43, this.l);
    }
    setSlice(a, b) {
      var c;
      (c = this.i) == null || c.setAttribute(a, b);
    }
    setData(a, b) {
      var c;
      (c = this.i) == null || c.setData(a, b, this.l);
    }
    send(a) {
      var b;
      (b = this.i) == null || b.send(a);
    }
    setDataAndSend(a, b) {
      if (this.i) {
        for (let c in a) a.hasOwnProperty(c) && this.i.setData(c, a[c], this.l);
        this.i.send(b);
      }
    }
    tick(a, b) {
      var c;
      (c = this.i) == null || c.tick(a, this.l, b);
    }
    populateServerPingbackOutput() {}
    flush() {
      return [];
    }
  };
  class Jb {
    constructor(a, b, c) {
      this.body = c;
      this.i = new a(b, c);
      var d;
      if (
        (a =
          (d = this.body.querySelector('meta[name="runtime_data"]')) == null
            ? void 0
            : d.content)
      )
        try {
          let e = JSON.parse(a);
          e && typeof e === "object" && Object.assign(this.i.runtime, e);
        } catch (e) {}
    }
    get uid() {
      return this.i.uid;
    }
    b0() {
      this.i.o();
    }
    b1() {}
    b2() {
      this.i.l();
    }
    b3() {}
    b4() {}
    b5() {}
  }
  function Kb(a) {
    this.i = a;
  }
  Kb.prototype.toString = function () {
    return this.i;
  };
  var Lb = [];
  function P(a) {
    a = new Kb(a);
    Lb.push(a);
    return a;
  }
  var Q = P("imalib_instrumentation");
  P("simid_video_addon_pause");
  P("simid_video_addon_play");
  P("simid_video_addon_stop");
  P("request_resize");
  P("video_creative_resize_result");
  P("ui_ad_clicked");
  P("ui_endcard_impression");
  P("ui_replay_icon_clicked");
  P("ui_skip_to_endcard_clicked");
  P("ui_continue_button_clicked");
  var Mb = P("ui_play_pause_clicked");
  P("ui_play_resume_clicked");
  var Nb = P("ui_play_pause_hidden"),
    Ob = P("ui_play_pause_shown");
  P("ui_mute_button_clicked");
  P("ui_show_skip_button");
  P("ui_show_close_button");
  var Pb = P("ui_skip_shown"),
    Qb = P("ui_skip_clicked"),
    Rb = P("ui_learn_more_clicked"),
    Sb = P("ui_learn_more_clicked_force_player_handles"),
    Tb = P("ui_learn_more_with_url_clicked"),
    Ub = P("ui_author_icon_clicked"),
    Vb = P("ui_ad_author_clicked"),
    Wb = P("ui_ad_title_clicked"),
    Xb = P("ui_endcard_author_clicked"),
    Yb = P("ui_endcard_title_clicked");
  P("ui_wta_clicked");
  P("ui_cta_clicked");
  P("ui_close_countdown_complete");
  P("update_action_title");
  var Zb = P("video_time_update");
  P("accumulated_video_time");
  P("animate_time_update");
  P("video_reward_granted");
  var $b = P("video_show_endcard");
  P("video_player_end");
  var ac = P("video_player_pause");
  P("video_player_play_attempted");
  var bc = P("video_player_play");
  P("video_player_volume_change");
  P("video_player_media_loaded");
  P("video_player_start");
  var cc = P("video_player_focus_ui_element");
  P("video_player_can_play_through");
  P("video_player_stalled");
  P("video_player_waiting");
  P("video_error");
  P("request_cta_url_for_qr");
  P("receive_cta_for_qr");
  P("och_click");
  P("close_ad");
  var dc = P("request_change_ad_duration_v2"),
    ec = P("ad_duration_change_result_v2");
  P("navigate_to_url");
  P("ui_unblock_back_button");
  P("video_enable_skip");
  function fc(a) {
    a && typeof a.dispose == "function" && a.dispose();
  }
  function R() {
    this.F = this.F;
    this.C = this.C;
  }
  R.prototype.F = !1;
  R.prototype.dispose = function () {
    this.F || ((this.F = !0), this.l());
  };
  R.prototype[Symbol.dispose] = function () {
    this.dispose();
  };
  function hc(a, b) {
    a.F ? b() : (a.C || (a.C = []), a.C.push(b));
  }
  R.prototype.l = function () {
    if (this.C) for (; this.C.length; ) this.C.shift()();
  };
  class ic {
    constructor(a, b) {
      this.m = a;
      this.o = b;
      this.l = 0;
      this.i = null;
    }
    get() {
      if (this.l > 0) {
        this.l--;
        var a = this.i;
        this.i = a.next;
        a.next = null;
      } else a = this.m();
      return a;
    }
    put(a) {
      this.o(a);
      this.l < 100 && (this.l++, (a.next = this.i), (this.i = a));
    }
  }
  function jc() {
    var a = kc,
      b = null;
    a.i && ((b = a.i), (a.i = a.i.next), a.i || (a.l = null), (b.next = null));
    return b;
  }
  class lc {
    constructor() {
      this.l = this.i = null;
    }
    add(a, b) {
      var c = mc.get();
      c.set(a, b);
      this.l ? (this.l.next = c) : (this.i = c);
      this.l = c;
    }
  }
  var mc = new ic(
    () => new nc(),
    (a) => a.reset()
  );
  class nc {
    constructor() {
      this.next = this.i = this.l = null;
    }
    set(a, b) {
      this.l = a;
      this.i = b;
      this.next = null;
    }
    reset() {
      this.next = this.i = this.l = null;
    }
  }
  var oc,
    pc = !1,
    kc = new lc(),
    rc = (a) => {
      oc || qc();
      pc || (oc(), (pc = !0));
      kc.add(a, void 0);
    },
    qc = () => {
      var a = Promise.resolve(void 0);
      oc = () => {
        a.then(sc);
      };
    };
  function sc() {
    for (var a; (a = jc()); ) {
      try {
        a.l.call(a.i);
      } catch (b) {
        fa(b);
      }
      mc.put(a);
    }
    pc = !1;
  }
  function tc(a) {
    R.call(this);
    this.A = 1;
    this.o = [];
    this.u = 0;
    this.i = [];
    this.m = {};
    this.D = !!a;
  }
  v(tc, R);
  h = tc.prototype;
  h.subscribe = function (a, b, c) {
    var d = this.m[a];
    d || (d = this.m[a] = []);
    var e = this.A;
    this.i[e] = a;
    this.i[e + 1] = b;
    this.i[e + 2] = c;
    this.A = e + 3;
    d.push(e);
    return e;
  };
  h.unsubscribe = function (a, b, c) {
    if ((a = this.m[a])) {
      let d = this.i;
      if (
        (a = a.find(function (e) {
          return d[e + 1] == b && d[e + 2] == c;
        }))
      )
        return this.v(a);
    }
    return !1;
  };
  h.v = function (a) {
    var b = this.i[a];
    if (b) {
      let c = this.m[b];
      this.u != 0
        ? (this.o.push(a), (this.i[a + 1] = () => {}))
        : (c && ma(c, a),
          delete this.i[a],
          delete this.i[a + 1],
          delete this.i[a + 2]);
    }
    return !!b;
  };
  h.B = function (a, b) {
    var c = this.m[a];
    if (c) {
      let e = Array(arguments.length - 1);
      var d = arguments.length;
      let f;
      for (f = 1; f < d; f++) e[f - 1] = arguments[f];
      if (this.D)
        for (f = 0; f < c.length; f++)
          (d = c[f]), uc(this.i[d + 1], this.i[d + 2], e);
      else {
        this.u++;
        try {
          for (f = 0, d = c.length; f < d && !this.F; f++) {
            let g = c[f];
            this.i[g + 1].apply(this.i[g + 2], e);
          }
        } finally {
          if ((this.u--, this.o.length > 0 && this.u == 0))
            for (; (c = this.o.pop()); ) this.v(c);
        }
      }
      return f != 0;
    }
    return !1;
  };
  function uc(a, b, c) {
    rc(function () {
      a.apply(b, c);
    });
  }
  h.clear = function (a) {
    if (a) {
      let b = this.m[a];
      b && (b.forEach(this.v, this), delete this.m[a]);
    } else (this.i.length = 0), (this.m = {});
  };
  h.l = function () {
    tc.L.l.call(this);
    this.clear();
    this.o.length = 0;
  };
  function S(a) {
    R.call(this);
    this.m = new tc(a);
    hc(this, ea(fc, this.m));
  }
  v(S, R);
  S.prototype.subscribe = function (a, b, c) {
    return this.m.subscribe(a.toString(), b, c);
  };
  S.prototype.unsubscribe = function (a, b, c) {
    return this.m.unsubscribe(a.toString(), b, c);
  };
  S.prototype.i = function (a, b) {
    return this.m.B(a.toString(), b);
  };
  S.prototype.clear = function (a) {
    this.m.clear(a !== void 0 ? a.toString() : void 0);
  }; /*

Math.uuid.js (v1.4)
http://www.broofa.com
mailto:robert@broofa.com
Copyright (c) 2010 Robert Kieffer
Dual licensed under the MIT and GPL licenses.
*/
  var vc =
    "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split("");
  function wc(a) {
    var b;
    (b = a.o) == null ||
      b.addEventListener("LIMA_TYPED_PUBSUB_EVENT_IDENTIFIER", (c) => {
        a.handleEvent(c);
      });
  }
  var xc = class extends S {
    constructor(a = null) {
      super();
      this.o = a;
      a = Array(36);
      for (var b = 0, c, d = 0; d < 36; d++)
        d == 8 || d == 13 || d == 18 || d == 23
          ? (a[d] = "-")
          : d == 14
          ? (a[d] = "4")
          : (b <= 2 && (b = (33554432 + Math.random() * 16777216) | 0),
            (c = b & 15),
            (b >>= 4),
            (a[d] = vc[d == 19 ? (c & 3) | 8 : c]));
      this.uuid = a.join("");
      this.o && wc(this);
    }
    handleEvent(a) {
      if (a instanceof CustomEvent && (a = a.detail) && a.uuid !== this.uuid) {
        a: {
          for (b of Lb) if (b.toString() === a.topicData.topic) break a;
          var b = null;
        }
        b &&
          (a.topicData.payloadData === "null"
            ? super.i(b, null)
            : a.topicData.payloadData === "false"
            ? super.i(b, !1)
            : ((a = a.topicData.payloadData),
              (a = a === "" ? null : JSON.parse(a)) && super.i(b, a)));
      }
    }
    i(a, b) {
      if (this.o) {
        var c = JSON.stringify(b);
        c = new CustomEvent("LIMA_TYPED_PUBSUB_EVENT_IDENTIFIER", {
          detail: {
            uuid: this.uuid,
            topicData: { topic: a.toString(), payloadData: c },
          },
        });
        this.o.dispatchEvent(c);
      }
      return super.i(a, b);
    }
  };
  function yc(a) {
    if (a.isVariableDurationAllowed()) {
      var b = +a.runtime.adDurationMs;
      if (!a.D && b > 0) {
        a.D = !0;
        b = b / 1e3 + 5;
        let c;
        (c = a.i) == null || c.subscribe(ec, () => {});
        let d;
        (d = a.i) == null || d.i(dc, { duration: b });
      }
    }
  }
  var zc = class extends Hb {
    constructor() {
      super(...arguments);
      this.i = null;
      this.C = [];
      this.D = !1;
    }
    getConfig(a) {
      zb(this.context, a, (b, c) => {
        M(c, 49, ".product-video");
      });
      return Db(new Eb(a));
    }
    o() {
      var a = document.getElementById("mys-content");
      a && !this.i && (this.i = new xc(a));
    }
    l() {
      super.l();
      var a = this.body.querySelector("#mys-content");
      a && ((a.style.height = "100%"), (a.style.width = "100%"));
      for (let b of this.C) b.v(this.G, this.body);
    }
    isVariableDurationAllowed() {
      var a, b, c;
      if (typeof mys === "undefined") var d = null;
      else {
        var e,
          f =
            (d = mys) == null
              ? void 0
              : (e = d.addon) == null
              ? void 0
              : e.getSimidCoreAddon;
        d = f ? f() : null;
      }
      return (c =
        (a = d) == null
          ? void 0
          : (b = a.isVariableDurationAllowed) == null
          ? void 0
          : b.call(a)) != null
        ? c
        : !0;
    }
  };
  function T(a, b, c, d) {
    a.m && (a.m.subscribe(b, c, d), hc(a, () => a.m.unsubscribe(b, c, d)));
  }
  var Ac = class extends R {
    constructor(a, b = !1) {
      super();
      this.m = a;
      b &&
        T(
          this,
          Zb,
          (c) => {
            this.R(c);
          },
          this
        );
    }
    v() {}
    R() {}
    unsubscribe(a, b, c) {
      this.m && this.m.unsubscribe(a, b, c);
    }
  };
  function U(a, b) {
    this.type = a;
    this.i = this.target = b;
    this.defaultPrevented = !1;
  }
  U.prototype.l = function () {
    this.defaultPrevented = !0;
  };
  function V(a, b) {
    U.call(this, a ? a.type : "");
    this.relatedTarget = this.i = this.target = null;
    this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0;
    this.key = "";
    this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
    this.state = null;
    this.pointerId = 0;
    this.pointerType = "";
    this.m = null;
    a && this.init(a, b);
  }
  v(V, U);
  V.prototype.init = function (a, b) {
    var c = (this.type = a.type),
      d =
        a.changedTouches && a.changedTouches.length
          ? a.changedTouches[0]
          : null;
    this.target = a.target || a.srcElement;
    this.i = b;
    b = a.relatedTarget;
    b ||
      (c == "mouseover"
        ? (b = a.fromElement)
        : c == "mouseout" && (b = a.toElement));
    this.relatedTarget = b;
    d
      ? ((this.clientX = d.clientX !== void 0 ? d.clientX : d.pageX),
        (this.clientY = d.clientY !== void 0 ? d.clientY : d.pageY),
        (this.screenX = d.screenX || 0),
        (this.screenY = d.screenY || 0))
      : ((this.clientX = a.clientX !== void 0 ? a.clientX : a.pageX),
        (this.clientY = a.clientY !== void 0 ? a.clientY : a.pageY),
        (this.screenX = a.screenX || 0),
        (this.screenY = a.screenY || 0));
    this.button = a.button;
    this.key = a.key || "";
    this.ctrlKey = a.ctrlKey;
    this.altKey = a.altKey;
    this.shiftKey = a.shiftKey;
    this.metaKey = a.metaKey;
    this.pointerId = a.pointerId || 0;
    this.pointerType = a.pointerType;
    this.state = a.state;
    this.m = a;
    a.defaultPrevented && V.L.l.call(this);
  };
  V.prototype.l = function () {
    V.L.l.call(this);
    var a = this.m;
    a.preventDefault ? a.preventDefault() : (a.returnValue = !1);
  };
  var W = "closure_listenable_" + ((Math.random() * 1e6) | 0);
  var Bc = 0;
  function Cc(a, b, c, d, e) {
    this.listener = a;
    this.proxy = null;
    this.src = b;
    this.type = c;
    this.capture = !!d;
    this.handler = e;
    this.key = ++Bc;
    this.M = this.N = !1;
  }
  function Dc(a) {
    a.M = !0;
    a.listener = null;
    a.proxy = null;
    a.src = null;
    a.handler = null;
  }
  function Ec(a) {
    this.src = a;
    this.i = {};
    this.l = 0;
  }
  Ec.prototype.add = function (a, b, c, d, e) {
    var f = a.toString();
    a = this.i[f];
    a || ((a = this.i[f] = []), this.l++);
    var g = Fc(a, b, d, e);
    g > -1
      ? ((b = a[g]), c || (b.N = !1))
      : ((b = new Cc(b, this.src, f, !!d, e)), (b.N = c), a.push(b));
    return b;
  };
  function Gc(a, b) {
    var c = b.type;
    c in a.i &&
      ma(a.i[c], b) &&
      (Dc(b), a.i[c].length == 0 && (delete a.i[c], a.l--));
  }
  function Fc(a, b, c, d) {
    for (let e = 0; e < a.length; ++e) {
      let f = a[e];
      if (!f.M && f.listener == b && f.capture == !!c && f.handler == d)
        return e;
    }
    return -1;
  }
  var Hc = "closure_lm_" + ((Math.random() * 1e6) | 0),
    Ic = {},
    Jc = 0;
  function Kc(a, b, c, d, e) {
    if (d && d.once) Lc(a, b, c, d, e);
    else if (Array.isArray(b))
      for (let f = 0; f < b.length; f++) Kc(a, b[f], c, d, e);
    else
      (c = Mc(c)),
        a && a[W]
          ? a.listen(b, c, u(d) ? !!d.capture : !!d, e)
          : Nc(a, b, c, !1, d, e);
  }
  function Nc(a, b, c, d, e, f) {
    if (!b) throw Error("Invalid event type");
    var g = u(e) ? !!e.capture : !!e,
      l = Oc(a);
    l || (a[Hc] = l = new Ec(a));
    c = l.add(b, c, d, g, f);
    if (!c.proxy) {
      d = Pc();
      c.proxy = d;
      d.src = a;
      d.listener = c;
      if (a.addEventListener)
        e === void 0 && (e = !1), a.addEventListener(b.toString(), d, e);
      else if (a.attachEvent) a.attachEvent(Qc(b.toString()), d);
      else if (a.addListener && a.removeListener) a.addListener(d);
      else throw Error("addEventListener and attachEvent are unavailable.");
      Jc++;
    }
  }
  function Pc() {
    function a(c) {
      return b.call(a.src, a.listener, c);
    }
    var b = Rc;
    return a;
  }
  function Lc(a, b, c, d, e) {
    if (Array.isArray(b))
      for (let f = 0; f < b.length; f++) Lc(a, b[f], c, d, e);
    else
      (c = Mc(c)),
        a && a[W]
          ? a.i.add(String(b), c, !0, u(d) ? !!d.capture : !!d, e)
          : Nc(a, b, c, !0, d, e);
  }
  function Sc(a, b, c, d, e) {
    if (Array.isArray(b))
      for (let f = 0; f < b.length; f++) Sc(a, b[f], c, d, e);
    else
      ((d = u(d) ? !!d.capture : !!d), (c = Mc(c)), a && a[W])
        ? a.unlisten(b, c, d, e)
        : a &&
          (a = Oc(a)) &&
          ((b = a.i[b.toString()]),
          (a = -1),
          b && (a = Fc(b, c, d, e)),
          (c = a > -1 ? b[a] : null) && Tc(c));
  }
  function Tc(a) {
    if (typeof a !== "number" && a && !a.M) {
      var b = a.src;
      if (b && b[W]) Gc(b.i, a);
      else {
        var c = a.type,
          d = a.proxy;
        b.removeEventListener
          ? b.removeEventListener(c, d, a.capture)
          : b.detachEvent
          ? b.detachEvent(Qc(c), d)
          : b.addListener && b.removeListener && b.removeListener(d);
        Jc--;
        (c = Oc(b))
          ? (Gc(c, a), c.l == 0 && ((c.src = null), (b[Hc] = null)))
          : Dc(a);
      }
    }
  }
  function Qc(a) {
    return a in Ic ? Ic[a] : (Ic[a] = "on" + a);
  }
  function Rc(a, b) {
    if (a.M) a = !0;
    else {
      b = new V(b, this);
      let c = a.listener,
        d = a.handler || a.src;
      a.N && Tc(a);
      a = c.call(d, b);
    }
    return a;
  }
  function Oc(a) {
    a = a[Hc];
    return a instanceof Ec ? a : null;
  }
  var Uc = "__closure_events_fn_" + ((Math.random() * 1e9) >>> 0);
  function Mc(a) {
    if (typeof a === "function") return a;
    a[Uc] ||
      (a[Uc] = function (b) {
        return a.handleEvent(b);
      });
    return a[Uc];
  }
  function X() {
    R.call(this);
    this.i = new Ec(this);
    this.D = this;
    this.u = null;
  }
  v(X, R);
  X.prototype[W] = !0;
  h = X.prototype;
  h.addEventListener = function (a, b, c, d) {
    Kc(this, a, b, c, d);
  };
  h.removeEventListener = function (a, b, c, d) {
    Sc(this, a, b, c, d);
  };
  h.dispatchEvent = function (a) {
    var b,
      c = this.u;
    if (c) for (b = []; c; c = c.u) b.push(c);
    c = this.D;
    var d = a.type || a;
    if (typeof a === "string") a = new U(a, c);
    else if (a instanceof U) a.target = a.target || c;
    else {
      var e = a;
      a = new U(d, c);
      ob(a, e);
    }
    e = !0;
    var f;
    if (b)
      for (f = b.length - 1; f >= 0; f--) {
        var g = (a.i = b[f]);
        e = Vc(g, d, !0, a) && e;
      }
    g = a.i = c;
    e = Vc(g, d, !0, a) && e;
    e = Vc(g, d, !1, a) && e;
    if (b)
      for (f = 0; f < b.length; f++)
        (g = a.i = b[f]), (e = Vc(g, d, !1, a) && e);
    return e;
  };
  h.l = function () {
    X.L.l.call(this);
    if (this.i) {
      var a = this.i;
      let b = 0;
      for (let c in a.i) {
        let d = a.i[c];
        for (let e = 0; e < d.length; e++) ++b, Dc(d[e]);
        delete a.i[c];
        a.l--;
      }
    }
    this.u = null;
  };
  h.listen = function (a, b, c, d) {
    return this.i.add(String(a), b, !1, c, d);
  };
  h.unlisten = function (a, b, c, d) {
    {
      var e = this.i;
      let f = String(a).toString();
      f in e.i
        ? ((a = e.i[f]),
          (b = Fc(a, b, c, d)),
          b > -1
            ? (Dc(a[b]),
              Array.prototype.splice.call(a, b, 1),
              a.length == 0 && (delete e.i[f], e.l--),
              (e = !0))
            : (e = !1))
        : (e = !1);
    }
    return e;
  };
  function Vc(a, b, c, d) {
    b = a.i.i[String(b)];
    if (!b) return !0;
    b = b.concat();
    var e = !0;
    for (let f = 0; f < b.length; ++f) {
      let g = b[f];
      if (g && !g.M && g.capture == c) {
        let l = g.listener,
          t = g.handler || g.src;
        g.N && Gc(a.i, g);
        e = l.call(t, d) !== !1 && e;
      }
    }
    return e && !d.defaultPrevented;
  }
  function Wc(a, b, c) {
    if (typeof a === "function") c && (a = a.bind(c));
    else if (a && typeof a.handleEvent == "function") a = a.handleEvent.bind(a);
    else throw Error("Invalid listener argument");
    return Number(b) > 2147483647 ? -1 : q.setTimeout(a, b || 0);
  }
  function Xc(a, b, c) {
    R.call(this);
    this.m = a;
    this.v = b || 0;
    this.o = c;
    this.u = () => Yc(this);
  }
  v(Xc, R);
  h = Xc.prototype;
  h.i = 0;
  h.l = function () {
    Xc.L.l.call(this);
    this.stop();
    delete this.m;
    delete this.o;
  };
  h.start = function (a) {
    this.stop();
    this.i = Wc(this.u, a !== void 0 ? a : this.v);
  };
  function Y(a) {
    a.isActive() || a.start(void 0);
  }
  h.stop = function () {
    this.isActive() && q.clearTimeout(this.i);
    this.i = 0;
  };
  h.isActive = function () {
    return this.i != 0;
  };
  function Yc(a) {
    a.i = 0;
    a.m && a.m.call(a.o);
  }
  function Zc(a) {
    a.i &&
      (a.i.removeEventListener("click", a.G),
      a.i.removeEventListener("pointerenter", a.I),
      a.i.removeEventListener("pointerover", a.K),
      a.i.removeEventListener("pointerleave", a.J));
  }
  function $c(a, b) {
    if (a.i && a.i.closest(".instream-ui")) {
      let c = a.i.closest(".x-layout");
      c ? c.appendChild(a.i) : b.appendChild(a.i);
    }
  }
  function ad(a, b) {
    a.D &&
      a.B &&
      ((a.D.style.display = b ? "" : "none"),
      (a.B.style.display = b ? "none" : ""));
  }
  var bd = class extends Ac {
    constructor(a) {
      super(a, !1);
      this.A = !1;
      this.B = this.D = this.i = null;
      this.G = (b) => {
        b.stopPropagation();
        this.m.i(Mb, !this.A);
        this.o.stop();
        Y(this.o);
      };
      this.I = (b) => {
        b.pointerType === "mouse" && (this.show(), this.o.stop(), Y(this.o));
      };
      this.K = (b) => {
        b.pointerType === "mouse" && (this.show(), this.o.stop(), Y(this.o));
      };
      this.J = (b) => {
        b.pointerType === "mouse" && ((b = this.o), b.stop(), Yc(b));
      };
      this.u = !this.A;
      this.o = new Xc(() => void this.hide(), 2e3);
    }
    v(a, b) {
      super.v(a, b);
      Zc(this);
      this.i = b.querySelector(".play-pause-control");
      this.D = b.querySelector(".play-icon");
      this.B = b.querySelector(".pause-icon");
      $c(this, b);
      T(
        this,
        ac,
        () => {
          ad(this, !0);
          this.A = !0;
          this.show();
          Y(this.o);
        },
        this
      );
      T(
        this,
        bc,
        () => {
          ad(this, !1);
          this.A = !1;
          Y(this.o);
        },
        this
      );
      this.i &&
        (this.i.addEventListener("click", this.G),
        this.i.addEventListener("pointerenter", this.I),
        this.i.addEventListener("pointerover", this.K),
        this.i.addEventListener("pointerleave", this.J));
      ad(this, !1);
      this.hide();
    }
    show() {
      this.u ||
        ((this.u = !0),
        this.m.i(Ob, null),
        this.i && this.i.classList.add("fade-in"));
    }
    hide() {
      this.u &&
        ((this.u = !1),
        this.m.i(Nb, null),
        this.i && this.i.classList.remove("fade-in"));
    }
    l() {
      Zc(this);
      super.l();
    }
  };
  function cd(a) {
    a = Math.round(a < 0 ? 0 : a);
    return `${a >= 3600 ? `${Math.floor(a / 3600)}:` : ""}${
      Math.floor(a / 60) % 60 < 10 && a >= 3600 ? "0" : ""
    }${Math.floor(a / 60) % 60}:${
      Math.floor(a % 60) < 10 ? "0" : ""
    }${Math.floor(a % 60)}`;
  }
  function dd() {
    X.call(this);
    this.o = 0;
    this.endTime = this.startTime = null;
  }
  v(dd, X);
  dd.prototype.onResume = function () {
    this.dispatchEvent("resume");
  };
  function ed(a, b) {
    Array.isArray(b) || (b = [b]);
    b = b.map(function (c) {
      return typeof c === "string"
        ? c
        : c.T + " " + c.duration + "s " + c.timing + " " + c.delay + "s";
    });
    O(a, "transition", b.join(","));
  }
  var fd = (function (a) {
    var b = !1,
      c;
    return function () {
      b || ((c = a()), (b = !0));
      return c;
    };
  })(function () {
    var a = document;
    var b = "DIV";
    a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
    b = a.createElement(b);
    a = oa ? "-webkit" : na ? "-moz" : null;
    var c = "transition:opacity 1s linear;";
    a && (c += a + "-transition:opacity 1s linear;");
    a = lb({ style: c });
    if (b.nodeType === 1 && /^(script|style)$/i.test(b.tagName))
      throw Error("");
    b.innerHTML = ab(a);
    b = b.firstChild;
    a = b.style[bb("transition")];
    return (
      (typeof a !== "undefined" ? a : b.style[rb(b, "transition")] || "") != ""
    );
  });
  function Z(a, b, c, d, e) {
    dd.call(this);
    this.m = a;
    this.G = b;
    this.I = c;
    this.A = d;
    this.K = Array.isArray(e) ? e : [e];
  }
  v(Z, dd);
  h = Z.prototype;
  h.play = function () {
    if (this.o == 1) return !1;
    this.dispatchEvent("begin");
    this.dispatchEvent("play");
    this.startTime = Date.now();
    this.o = 1;
    if (fd()) return O(this.m, this.I), (this.B = Wc(this.J, void 0, this)), !0;
    this.v(!1);
    return !1;
  };
  h.J = function () {
    var a = this.m;
    b: {
      var b = a.nodeType == 9 ? a : a.ownerDocument || a.document;
      if (
        b.defaultView &&
        b.defaultView.getComputedStyle &&
        (b = b.defaultView.getComputedStyle(a, null))
      ) {
        b = b.display || b.getPropertyValue("display") || "";
        break b;
      }
      b = "";
    }
    if (
      (b ||
        (a.currentStyle ? a.currentStyle.display : null) ||
        (a.style && a.style.display)) != "none"
    )
      tb(a);
    else {
      b = a.style;
      var c = b.display,
        d = b.visibility,
        e = b.position;
      b.visibility = "hidden";
      b.position = "absolute";
      b.display = "inline";
      tb(a);
      b.display = c;
      b.position = e;
      b.visibility = d;
    }
    ed(this.m, this.K);
    O(this.m, this.A);
    this.B = Wc(this.v.bind(this, !1), this.G * 1e3);
  };
  h.stop = function () {
    this.o == 1 && this.v(!0);
  };
  h.v = function (a) {
    O(this.m, "transition", "");
    q.clearTimeout(this.B);
    O(this.m, this.A);
    this.endTime = Date.now();
    this.o = 0;
    a ? this.dispatchEvent("stop") : this.dispatchEvent("finish");
    this.dispatchEvent("end");
  };
  h.l = function () {
    this.stop();
    Z.L.l.call(this);
  };
  h.pause = function () {};
  function gd(a) {
    return new Z(
      a,
      0.5,
      { opacity: 0 },
      { opacity: 1 },
      { T: "opacity", duration: 0.5, timing: "ease-out", delay: 0 }
    );
  }
  function hd(a) {
    var b;
    (b = a.B) == null || b.removeEventListener("click", a.P);
    var c;
    (c = a.G) == null || c.removeEventListener("click", a.O);
  }
  function id(a) {
    a.o && ((a.o.style.display = "none"), (a.o.style.opacity = "0"));
  }
  function jd(a, b) {
    if (!(a.u < 0)) {
      b = Math.ceil(a.u - b);
      var c = b.toString();
      b >= 60 && (c = cd(b));
      a.J && (a.J.textContent = c);
    }
  }
  function kd(a) {
    a.K || (a.m.i(Pb, null), (a.K = !0));
  }
  function ld(a) {
    if (a.A) {
      let b,
        c = (b = a.D) == null ? void 0 : b.dataset.countdownSeconds;
      a.A.style.animation = `skip-progress ${c}s linear forwards`;
    }
  }
  var md = class extends Ac {
    constructor(a, b = 5) {
      super(a, !0);
      this.u = b;
      this.A =
        this.I =
        this.D =
        this.B =
        this.o =
        this.J =
        this.G =
        this.i =
          null;
      this.K = !1;
      this.P = (c) => {
        c.stopPropagation();
        this.state === 3 && this.m.i(Qb, "user_click");
      };
      this.O = (c) => {
        c.stopPropagation();
      };
      switch (this.u) {
        case 0:
          this.state = 3;
          break;
        case -1:
          this.state = 4;
          break;
        default:
          this.state = 1;
      }
    }
    v(a, b) {
      super.v(a, b);
      hd(this);
      this.i = document.querySelector(".preskip-button-container");
      this.G = document.querySelector(".preskip-button");
      this.J = document.querySelector(".preskip-button-text");
      this.o = document.querySelector(".skip-button-container");
      this.B = document.querySelector(".skip-button");
      this.D = document.querySelector(".countdown");
      this.I = document.querySelector(".fg");
      this.A = document.querySelector(".skip-fg");
      if (this.state === 4) this.i && (this.i.style.display = "none"), id(this);
      else {
        var c;
        (c = this.m) == null ||
          c.subscribe(Zb, (d) => {
            this.D &&
              d.durationSeconds > 0 &&
              ((d = Math.ceil(d.durationSeconds - d.currentTimeSeconds)),
              (this.D.textContent = d > 60 ? cd(d) : d.toString()));
          });
        this.B &&
          (this.B.addEventListener("click", this.P),
          T(
            this,
            cc,
            () => {
              var d;
              (d = this.B) == null || d.focus();
            },
            this
          ),
          this.I &&
            (T(
              this,
              ac,
              () => {
                var d;
                (d = this.I) == null || d.classList.add("animation-paused");
                var e;
                (e = this.A) == null || e.classList.add("animation-paused");
              },
              this
            ),
            T(
              this,
              bc,
              () => {
                var d;
                (d = this.I) == null || d.classList.remove("animation-paused");
                var e;
                (e = this.A) == null || e.classList.remove("animation-paused");
              },
              this
            )));
        this.G && this.G.addEventListener("click", this.O);
        this.state !== 2 && this.i && (this.i.style.display = "none");
        jd(this, 0);
        this.state === 3 ? kd(this) : id(this);
      }
    }
    R(a) {
      if (
        !(
          !a ||
          a.durationSeconds <= 0 ||
          this.u < 0 ||
          this.u >= a.durationSeconds ||
          this.state === 3
        )
      ) {
        if (a.currentTimeSeconds <= this.u)
          this.state !== 2 &&
            (jd(this, 0),
            this.i && (gd(this.i).play(), (this.i.style.display = ""))),
            (this.state = 2);
        else {
          if (this.i && this.o) {
            this.o.style.display = "";
            let b = new Z(
                this.i,
                0.5,
                { opacity: 1, visibility: "shown" },
                { opacity: 0.9, visibility: "hidden" },
                { T: "opacity", duration: 0.5, timing: "ease-out", delay: 0 }
              ),
              c = gd(this.o);
            b.play();
            c.play();
            ld(this);
          } else
            !this.i &&
              this.o &&
              ((this.o.style.display = ""), gd(this.o).play(), ld(this));
          this.state = 3;
          kd(this);
        }
        this.state === 2 && jd(this, a.currentTimeSeconds);
      }
    }
    l() {
      hd(this);
      super.l();
    }
  };
  function nd(a) {
    var b;
    (b = a.i) == null ||
      b.subscribe(Zb, (r) => {
        var m,
          p,
          C =
            (p =
              (m = Ab(a.context)) == null
                ? void 0
                : m.querySelector(".countdown-container")) == null
              ? void 0
              : p.firstElementChild;
        C &&
          r.durationSeconds > 0 &&
          ((m = cd(r.durationSeconds - r.currentTimeSeconds)),
          (C.textContent = m.toString()));
        !a.m && r.currentTimeSeconds > 5 && ((a.m = !0), od(a, !0));
      });
    var c;
    (c = a.i) == null ||
      c.subscribe(ac, () => {
        a.m && od(a, !1);
      });
    var d;
    (d = a.i) == null ||
      d.subscribe(bc, () => {
        a.m && od(a, !0);
      });
    var e;
    (e = a.i) == null ||
      e.subscribe($b, () => {
        a.runtime.shouldShowEndCard &&
          (a.v && a.v.classList.remove("hidden"),
          a.u && a.u.classList.remove("hidden"),
          a.B && a.B.classList.add("hidden"));
      });
    b = Ab(a.context);
    var f;
    (f =
      b == null
        ? void 0
        : b.querySelector(".top-bar-text-container .headline")) == null ||
      f.addEventListener("click", (r) => {
        r.stopPropagation();
        var m;
        (m = a.i) == null || m.i(Wb, null);
        var p;
        (p = a.i) == null || p.i(Q, { type: "TimingEvent", key: "smd_clk_t" });
      });
    var g;
    (g =
      b == null
        ? void 0
        : b.querySelector(".top-bar-text-container .description")) == null ||
      g.addEventListener("click", (r) => {
        r.stopPropagation();
        var m;
        (m = a.i) == null || m.i(Vb, null);
        var p;
        (p = a.i) == null || p.i(Q, { type: "TimingEvent", key: "smd_clk_a" });
      });
    var l;
    (l = b == null ? void 0 : b.querySelector(".channel-icon-container")) ==
      null ||
      l.addEventListener("click", (r) => {
        r.stopPropagation();
        var m;
        (m = a.i) == null || m.i(Ub, null);
        var p;
        (p = a.i) == null || p.i(Q, { type: "TimingEvent", key: "smd_clk_i" });
      });
    var t;
    (t = b == null ? void 0 : b.querySelector(".clickthrough-button")) ==
      null ||
      t.addEventListener("click", (r) => {
        r.stopPropagation();
        if (a.runtime.forceSimidPlayerHandlesClickthrough) {
          let m;
          (m = a.i) == null || m.i(Sb, null);
          let p;
          (p = a.i) == null ||
            p.i(Q, { type: "TimingEvent", key: "smd_clk_c_fph" });
        } else if (a.runtime.clickthroughUri) {
          let m;
          (m = a.i) == null || m.i(Tb, a.runtime.clickthroughUri);
          let p;
          (p = a.i) == null ||
            p.i(Q, { type: "TimingEvent", key: "smd_clku_c" });
        } else {
          let m;
          (m = a.i) == null || m.i(Rb, null);
          let p;
          (p = a.i) == null ||
            p.i(Q, { type: "TimingEvent", key: "smd_clk_c" });
        }
      });
    var k;
    (k = b == null ? void 0 : b.querySelector(".end-card-info .headline")) ==
      null ||
      k.addEventListener("click", (r) => {
        r.stopPropagation();
        var m;
        (m = a.i) == null || m.i(Yb, null);
        var p;
        (p = a.i) == null ||
          p.i(Q, { type: "TimingEvent", key: "smd_clk_e_t" });
      });
    var n;
    (n = b == null ? void 0 : b.querySelector(".end-card-info .description")) ==
      null ||
      n.addEventListener("click", (r) => {
        r.stopPropagation();
        var m;
        (m = a.i) == null || m.i(Xb, null);
        var p;
        (p = a.i) == null ||
          p.i(Q, { type: "TimingEvent", key: "smd_clk_e_a" });
      });
  }
  function od(a, b) {
    a.A && a.A.classList.toggle("collapsed", b);
    a.F && a.F.classList.toggle("collapsed", b);
  }
  var pd = class extends zc {
    constructor() {
      super(...arguments);
      this.m = !1;
      this.B = this.u = this.v = this.F = this.A = null;
    }
    o() {
      super.o();
      if (this.i) {
        if (this.runtime.disableSkip) {
          var a = new md(this.i, -1);
          this.C.push(a);
        } else (a = new md(this.i)), this.C.push(a);
        a = new bd(this.i);
        this.C.push(a);
      }
    }
    l() {
      super.l();
      var a = document.body.querySelector("#mys-content");
      a && ((a.style.height = "100%"), (a.style.width = "100%"));
      (a = document.body.querySelector("#instream-landscape")) &&
        a.parentElement &&
        ((a.parentElement.style.height = "100%"),
        (a.parentElement.style.width = "100%"));
      if ((a = Ab(this.context)))
        (this.A = a.querySelector(".top-bar") || null),
          (this.F = a.querySelector(".bottom-bar") || null),
          (this.v = a.querySelector("#end-card-info") || null),
          (this.u = a.querySelector("#end-card-image") || null),
          (this.B = a.querySelector("#top-bar-text") || null);
      nd(this);
      this.runtime.shouldShowEndCard && yc(this);
    }
  };
  (function (a, b) {
    Fb = new Ib();
    var c,
      d,
      e,
      f,
      g =
        (f = (e = (d = (c = window).mys) != null ? d : (c.mys = {})).designs) !=
        null
          ? f
          : (e.designs = new Map());
    class l extends Jb {
      constructor(t, k) {
        super(b, t, k);
      }
    }
    g.set(a, l);
  })("simid/trueview_instream", class extends pd {});
}.call(this));
