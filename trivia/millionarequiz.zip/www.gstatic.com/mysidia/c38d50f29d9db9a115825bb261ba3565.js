(function () {
  "use strict";
  var l,
    aa = Object.defineProperty;
  function ba(a) {
    a = [
      "object" == typeof globalThis && globalThis,
      a,
      "object" == typeof window && window,
      "object" == typeof self && self,
      "object" == typeof global && global,
    ];
    for (var b = 0; b < a.length; ++b) {
      var c = a[b];
      if (c && c.Math == Math) return c;
    }
    throw Error("Cannot find global object");
  }
  var ca = ba(this);
  function da(a, b) {
    if (b)
      a: {
        var c = ca;
        a = a.split(".");
        for (var d = 0; d < a.length - 1; d++) {
          var e = a[d];
          if (!(e in c)) break a;
          c = c[e];
        }
        a = a[a.length - 1];
        d = c[a];
        b = b(d);
        b != d &&
          b != null &&
          aa(c, a, { configurable: !0, writable: !0, value: b });
      }
  }
  da("globalThis", function (a) {
    return a || ca;
  });
  da("Symbol.dispose", function (a) {
    return a ? a : Symbol("Symbol.dispose");
  });
  da("Object.fromEntries", function (a) {
    return a
      ? a
      : function (b) {
          var c = {};
          if (!(Symbol.iterator in b))
            throw new TypeError("" + b + " is not iterable");
          b = b[Symbol.iterator].call(b);
          for (var d = b.next(); !d.done; d = b.next()) {
            d = d.value;
            if (Object(d) !== d)
              throw new TypeError(
                "iterable for fromEntries should yield objects"
              );
            Object.defineProperty(c, d[0], {
              value: d[1],
              writable: !0,
              enumerable: !0,
              configurable: !0,
            });
          }
          return c;
        };
  }); /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var n = this || self;
  function ea(a) {
    var b = typeof a;
    return (b == "object" && a != null) || b == "function";
  }
  function fa(a, b) {
    var c = Array.prototype.slice.call(arguments, 1);
    return function () {
      var d = c.slice();
      d.push.apply(d, arguments);
      return a.apply(this, d);
    };
  }
  function ha(a, b) {
    function c() {}
    c.prototype = b.prototype;
    a.V = b.prototype;
    a.prototype = new c();
    a.prototype.constructor = a;
    a.sb = function (d, e, f) {
      for (
        var g = Array(arguments.length - 2), h = 2;
        h < arguments.length;
        h++
      )
        g[h - 2] = arguments[h];
      return b.prototype[e].apply(d, g);
    };
  }
  function ia(a) {
    n.setTimeout(() => {
      throw a;
    }, 0);
  }
  var ja, ka;
  a: {
    for (var la = ["CLOSURE_FLAGS"], ma = n, na = 0; na < la.length; na++)
      if (((ma = ma[la[na]]), ma == null)) {
        ka = null;
        break a;
      }
    ka = ma;
  }
  var oa = ka && ka[748402147];
  ja = oa != null ? oa : !0;
  function pa(a, b) {
    Array.prototype.forEach.call(a, b, void 0);
  }
  function qa(a, b) {
    b = Array.prototype.indexOf.call(a, b, void 0);
    var c;
    (c = b >= 0) && Array.prototype.splice.call(a, b, 1);
    return c;
  }
  function ra(a) {
    ra[" "](a);
    return a;
  }
  ra[" "] = function () {};
  var sa = {},
    ta = null;
  function ua(a, b) {
    a.__closure__error__context__984382 ||
      (a.__closure__error__context__984382 = {});
    a.__closure__error__context__984382.severity = b;
  }
  var va = void 0;
  function wa(a) {
    a = Error(a);
    ua(a, "warning");
    return a;
  }
  function xa() {
    return typeof BigInt === "function";
  }
  function ya(a, b = !1) {
    return b && Symbol.for && a
      ? Symbol.for(a)
      : a != null
      ? Symbol(a)
      : Symbol();
  }
  var za = ya(),
    Aa = ya(),
    Ba = ya(),
    Ca = ya("m_m", !0),
    Da = ya();
  var r = ya("jas", !0),
    Ea,
    Fa = [];
  Fa[r] = 7;
  Ea = Object.freeze(Fa);
  function Ga(a, b) {
    2 & b && (a |= 2);
    return a | 1;
  }
  var Ha = {};
  function t(a, b) {
    return b === void 0
      ? a.h !== Ia && !!(2 & (a.B[r] | 0))
      : !!(2 & b) && a.h !== Ia;
  }
  var Ia = {};
  Object.freeze({});
  Object.freeze({});
  function u(a, b) {
    var c = Ja;
    if (!b(a)) {
      var d, e;
      b =
        (e =
          (d = typeof c === "function" ? c() : c) == null
            ? void 0
            : d.concat("\n")) != null
          ? e
          : "";
      throw Error(b + String(a));
    }
  }
  function v(a) {
    a.tb = !0;
    return a;
  }
  var Ja = void 0;
  var w = v((a) => typeof a === "number"),
    z = v((a) => typeof a === "string"),
    A = v((a) => typeof a === "boolean"),
    B = v((a) => a === null),
    C = v((a) => a === void 0);
  function D(a) {
    return v((b) => {
      for (let c in a) if (b === a[c] && !/^[0-9]+$/.test(c)) return !0;
      return !1;
    });
  }
  var Ka = v((a) => !!a && (typeof a === "object" || typeof a === "function"));
  function E(a) {
    return v((b) => {
      if (!Ka(b)) return !1;
      for (let [c, d] of Object.entries(a)) {
        let e = c,
          f = d;
        if (!(e in b)) {
          if (f.ta === !0) continue;
          return !1;
        }
        if (!f(b[e])) return !1;
      }
      return !0;
    });
  }
  function F(a) {
    return La(v((b, c) => (b === void 0 ? !0 : a(b, c))));
  }
  function La(a) {
    a.ta = !0;
    return a;
  }
  var Ma = v(() => !0),
    Na = v((a) => Array.isArray(a));
  function Oa() {
    return v((a) => {
      if (!Ka(a) || Na(a)) return !1;
      var b = Object.getPrototypeOf(a);
      for (
        b = b === Object.prototype || b == null;
        a && a !== Object.prototype;
        a = Object.getPrototypeOf(a)
      )
        for (let c of Reflect.ownKeys(a))
          if ((b || !Object.prototype.hasOwnProperty(c)) && z(c) && !Ma(a[c]))
            return !1;
      return !0;
    });
  }
  function G(...a) {
    return v((b) => a.some((c) => c(b)));
  }
  var Pa = typeof n.BigInt === "function" && typeof n.BigInt(0) === "bigint";
  function I(a) {
    var b = a;
    if (z(b)) {
      if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(b)) throw Error(String(b));
    } else if (w(b) && !Number.isSafeInteger(b)) throw Error(String(b));
    return Pa
      ? BigInt(a)
      : (a = A(a) ? (a ? "1" : "0") : z(a) ? a.trim() || "0" : String(a));
  }
  var Va = v((a) =>
      Pa ? a >= Qa && a <= Ra : a[0] === "-" ? Sa(a, Ta) : Sa(a, Ua)
    ),
    Ta = Number.MIN_SAFE_INTEGER.toString(),
    Qa = Pa ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
    Ua = Number.MAX_SAFE_INTEGER.toString(),
    Ra = Pa ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;
  function Sa(a, b) {
    if (a.length > b.length) return !1;
    if (a.length < b.length || a === b) return !0;
    for (let c = 0; c < a.length; c++) {
      let d = a[c],
        e = b[c];
      if (d > e) return !1;
      if (d < e) return !0;
    }
  }
  var J = 0,
    K = 0;
  function Wa(a) {
    var b = a >>> 0;
    J = b;
    K = ((a - b) / 4294967296) >>> 0;
  }
  function Xa(a) {
    if (a < 0) {
      Wa(-a);
      let [b, c] = Ya(J, K);
      J = b >>> 0;
      K = c >>> 0;
    } else Wa(a);
  }
  function Za(a, b) {
    b >>>= 0;
    a >>>= 0;
    if (b <= 2097151) var c = "" + (4294967296 * b + a);
    else
      xa()
        ? (c = "" + ((BigInt(b) << BigInt(32)) | BigInt(a)))
        : ((c = ((a >>> 24) | (b << 8)) & 16777215),
          (b = (b >> 16) & 65535),
          (a = (a & 16777215) + c * 6777216 + b * 6710656),
          (c += b * 8147497),
          (b *= 2),
          a >= 1e7 && ((c += (a / 1e7) >>> 0), (a %= 1e7)),
          c >= 1e7 && ((b += (c / 1e7) >>> 0), (c %= 1e7)),
          (c = b + $a(c) + $a(a)));
    return c;
  }
  function $a(a) {
    a = String(a);
    return "0000000".slice(a.length) + a;
  }
  function ab() {
    var a = J,
      b = K;
    if (b & 2147483648)
      if (xa()) a = "" + ((BigInt(b | 0) << BigInt(32)) | BigInt(a >>> 0));
      else {
        let [c, d] = Ya(a, b);
        a = "-" + Za(c, d);
      }
    else a = Za(a, b);
    return a;
  }
  function Ya(a, b) {
    b = ~b;
    a ? (a = ~a + 1) : (b += 1);
    return [a, b];
  }
  function bb(a, b = `unexpected value ${a}!`) {
    throw Error(b);
  }
  var db = typeof BigInt === "function" ? BigInt.asIntN : void 0,
    eb = Number.isSafeInteger,
    fb = Number.isFinite,
    gb = Math.trunc,
    hb = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
  function ib(a) {
    switch (typeof a) {
      case "bigint":
        return !0;
      case "number":
        return fb(a);
      case "string":
        return hb.test(a);
      default:
        return !1;
    }
  }
  function jb(a) {
    if (typeof a !== "number") throw wa("int32");
    if (!fb(a)) throw wa("int32");
    return a | 0;
  }
  function kb(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return fb(a) ? a | 0 : void 0;
  }
  function lb(a) {
    var b = void 0;
    b != null || (b = 1024);
    if (!ib(a)) throw wa("int64");
    var c = typeof a;
    switch (b) {
      case 512:
        switch (c) {
          case "string":
            return mb(a);
          case "bigint":
            return String(db(64, a));
          default:
            return nb(a);
        }
      case 1024:
        switch (c) {
          case "string":
            return ob(a);
          case "bigint":
            return I(db(64, a));
          default:
            return I(eb(a) ? a : nb(a));
        }
      case 0:
        switch (c) {
          case "string":
            return mb(a);
          case "bigint":
            return I(db(64, a));
          default:
            a = gb(a);
            if (!eb(a)) {
              Xa(a);
              b = J;
              c = K;
              if ((a = c & 2147483648))
                (b = (~b + 1) >>> 0),
                  (c = ~c >>> 0),
                  b == 0 && (c = (c + 1) >>> 0);
              let d = c * 4294967296 + (b >>> 0);
              b = Number.isSafeInteger(d) ? d : Za(b, c);
              a = typeof b === "number" ? (a ? -b : b) : a ? "-" + b : b;
            }
            return a;
        }
      default:
        return bb(b, "Unknown format requested type for int64");
    }
  }
  function pb(a) {
    var b = a.length;
    if (
      a[0] === "-"
        ? b < 20 || (b === 20 && a <= "-9223372036854775808")
        : b < 19 || (b === 19 && a <= "9223372036854775807")
    )
      return a;
    if (a.length < 16) Xa(Number(a));
    else if (xa())
      (a = BigInt(a)),
        (J = Number(a & BigInt(4294967295)) >>> 0),
        (K = Number((a >> BigInt(32)) & BigInt(4294967295)));
    else {
      b = +(a[0] === "-");
      K = J = 0;
      let c = a.length;
      for (let d = b, e = ((c - b) % 6) + b; e <= c; d = e, e += 6) {
        let f = Number(a.slice(d, e));
        K *= 1e6;
        J = J * 1e6 + f;
        J >= 4294967296 &&
          ((K += Math.trunc(J / 4294967296)), (K >>>= 0), (J >>>= 0));
      }
      if (b) {
        let [d, e] = Ya(J, K);
        J = d;
        K = e;
      }
    }
    return ab();
  }
  function nb(a) {
    a = gb(a);
    eb(a) ? (a = String(a)) : (Xa(a), (a = ab()));
    return a;
  }
  function mb(a) {
    var b = gb(Number(a));
    if (eb(b)) return String(b);
    b = a.indexOf(".");
    b !== -1 && (a = a.substring(0, b));
    return pb(a);
  }
  function ob(a) {
    var b = gb(Number(a));
    if (eb(b)) return I(b);
    b = a.indexOf(".");
    b !== -1 && (a = a.substring(0, b));
    return xa() ? I(db(64, BigInt(a))) : I(pb(a));
  }
  function qb(a) {
    var b = typeof a;
    if (a == null) return a;
    if (b === "bigint") return I(db(64, a));
    if (ib(a)) return b === "string" ? ob(a) : I(eb(a) ? a : nb(a));
  }
  function L(a) {
    if (a != null && typeof a !== "string") throw Error();
    return a;
  }
  function rb(a, b, c, d) {
    if (a != null && a[Ca] === Ha) return a;
    if (!Array.isArray(a))
      return (
        c
          ? d & 2
            ? ((a = b[za]) ||
                ((d = new b()), (a = d.B), (a[r] |= 34), (a = b[za] = d)),
              (b = a))
            : (b = new b())
          : (b = void 0),
        b
      );
    c = a[r] | 0;
    d = c | (d & 32) | (d & 2);
    d !== c && (a[r] = d);
    return new b(a);
  }
  var sb = {};
  function tb(a) {
    return a;
  }
  function ub(a, b, c, d) {
    var e = d !== void 0;
    d = !!d;
    var f = [],
      g = a.length,
      h = 4294967295,
      k = !1,
      p = !!(b & 64),
      m = p ? (b & 128 ? 0 : -1) : void 0;
    if (!(b & 1)) {
      var q = g && a[g - 1];
      q != null && typeof q === "object" && q.constructor === Object
        ? (g--, (h = g))
        : (q = void 0);
      if (p && !(b & 128) && !e) {
        k = !0;
        var x;
        h = ((x = vb) != null ? x : tb)(h - m, m, a, q, void 0) + m;
      }
    }
    b = void 0;
    for (e = 0; e < g; e++)
      if (((x = a[e]), x != null && (x = c(x, d)) != null))
        if (p && e >= h) {
          let y = e - m,
            H;
          ((H = b) != null ? H : (b = {}))[y] = x;
        } else f[e] = x;
    if (q)
      for (let y in q) {
        a = q[y];
        if (a == null || (a = c(a, d)) == null) continue;
        g = +y;
        let H;
        if (p && !Number.isNaN(g) && (H = g + m) < h) f[H] = a;
        else {
          let N;
          ((N = b) != null ? N : (b = {}))[y] = a;
        }
      }
    b && (k ? f.push(b) : (f[h] = b));
    return f;
  }
  function wb(a) {
    switch (typeof a) {
      case "number":
        return Number.isFinite(a) ? a : "" + a;
      case "bigint":
        return Va(a) ? Number(a) : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          let b = a[r] | 0;
          return a.length === 0 && b & 1 ? void 0 : ub(a, b, wb);
        }
        if (a != null && a[Ca] === Ha) return xb(a);
        return;
    }
    return a;
  }
  var vb;
  function yb(a, b) {
    if (b) {
      vb = b == null || b === tb || b[Da] !== sb ? tb : b;
      try {
        return xb(a);
      } finally {
        vb = void 0;
      }
    }
    return xb(a);
  }
  function xb(a) {
    a = a.B;
    return ub(a, a[r] | 0, wb);
  }
  function zb(a, b, c, d = 0) {
    if (a == null) {
      var e = 32;
      c ? ((a = [c]), (e |= 128)) : (a = []);
      b && (e = (e & -16760833) | ((b & 1023) << 14));
    } else {
      if (!Array.isArray(a)) throw Error("narr");
      e = a[r] | 0;
      if (ja && 1 & e) throw Error("rfarr");
      2048 & e && !(2 & e) && Ab();
      if (e & 256) throw Error("farr");
      if (e & 64) return (e | d) !== e && (a[r] = e | d), a;
      if (c && ((e |= 128), c !== a[0])) throw Error("mid");
      a: {
        c = a;
        e |= 64;
        var f = c.length;
        if (f) {
          var g = f - 1;
          let k = c[g];
          if (k != null && typeof k === "object" && k.constructor === Object) {
            b = e & 128 ? 0 : -1;
            g -= b;
            if (g >= 1024) throw Error("pvtlmt");
            for (var h in k)
              if (((f = +h), f < g)) (c[f + b] = k[h]), delete k[h];
              else break;
            e = (e & -16760833) | ((g & 1023) << 14);
            break a;
          }
        }
        if (b) {
          h = Math.max(b, f - (e & 128 ? 0 : -1));
          if (h > 1024) throw Error("spvt");
          e = (e & -16760833) | ((h & 1023) << 14);
        }
      }
    }
    a[r] = e | 64 | d;
    return a;
  }
  function Ab() {
    if (ja) throw Error("carr");
    if (Ba != null) {
      var a;
      var b = (a = va) != null ? a : (va = {});
      a = b[Ba] || 0;
      a >= 5 || ((b[Ba] = a + 1), (b = Error()), ua(b, "incident"), ia(b));
    }
  }
  function Bb(a, b) {
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      var c = a[r] | 0;
      a.length === 0 && c & 1
        ? (a = void 0)
        : c & 2 ||
          (!b || 4096 & c || 16 & c
            ? (a = Cb(a, c, !1, b && !(c & 16)))
            : ((a[r] |= 34), c & 4 && Object.freeze(a)));
      return a;
    }
    if (a != null && a[Ca] === Ha)
      return (
        (b = a.B),
        (c = b[r] | 0),
        t(a, c) ? a : Db(a, b, c) ? Eb(a, b) : Cb(b, c)
      );
  }
  function Eb(a, b, c) {
    a = new a.constructor(b);
    c && (a.h = Ia);
    a.o = Ia;
    return a;
  }
  function Cb(a, b, c, d) {
    d != null || (d = !!(34 & b));
    a = ub(a, b, Bb, d);
    d = 32;
    c && (d |= 2);
    b = (b & 16769217) | d;
    a[r] = b;
    return a;
  }
  function Fb(a) {
    var b = a.B,
      c = b[r] | 0;
    return t(a, c)
      ? Db(a, b, c)
        ? Eb(a, b, !0)
        : new a.constructor(Cb(b, c, !1))
      : a;
  }
  function Gb(a) {
    if (a.h !== Ia) return !1;
    var b = a.B;
    b = Cb(b, b[r] | 0);
    b[r] |= 2048;
    a.B = b;
    a.h = void 0;
    a.o = void 0;
    return !0;
  }
  function M(a) {
    if (!Gb(a) && t(a, a.B[r] | 0)) throw Error();
  }
  function Hb(a, b) {
    b === void 0 && (b = a[r] | 0);
    b & 32 && !(b & 4096) && (a[r] = b | 4096);
  }
  function Db(a, b, c) {
    return c & 2
      ? !0
      : c & 32 && !(c & 4096)
      ? ((b[r] = c | 2), (a.h = Ia), !0)
      : !1;
  }
  var Ib = I(0);
  function Jb(a, b, c, d) {
    a = Kb(a.B, b, c, d);
    if (a !== null) return a;
  }
  function Kb(a, b, c, d) {
    if (b === -1) return null;
    var e = b + (c ? 0 : -1),
      f = a.length - 1;
    if (!(f < 1 + (c ? 0 : -1))) {
      if (e >= f) {
        var g = a[f];
        if (g != null && typeof g === "object" && g.constructor === Object) {
          c = g[b];
          var h = !0;
        } else if (e === f) c = g;
        else return;
      } else c = a[e];
      if (d && c != null) {
        d = d(c);
        if (d == null) return d;
        if (!Object.is(d, c)) return h ? (g[b] = d) : (a[e] = d), d;
      }
      return c;
    }
  }
  function O(a, b, c) {
    M(a);
    var d = a.B;
    P(d, d[r] | 0, b, c);
    return a;
  }
  function P(a, b, c, d) {
    var e = c + -1,
      f = a.length - 1;
    if (f >= 0 && e >= f) {
      let g = a[f];
      if (g != null && typeof g === "object" && g.constructor === Object)
        return (g[c] = d), b;
    }
    if (e <= f) return (a[e] = d), b;
    if (d !== void 0) {
      let g;
      f = (((g = b) != null ? g : (b = a[r] | 0)) >> 14) & 1023 || 536870912;
      c >= f ? d != null && (a[f + -1] = { [c]: d }) : (a[e] = d);
    }
    return b;
  }
  function Lb(a, b, c, d) {
    var e = a.B,
      f = e[r] | 0;
    c = c && c !== 4 ? (c !== 1 && (a ? t(a, f) : 2 & f) ? 1 : c) : 4;
    d = !!d || c === 3;
    c === 2 && Gb(a) && ((e = a.B), (f = e[r] | 0));
    a = Mb(e, b);
    var g = a === Ea ? 7 : a[r] | 0,
      h = Ga(g, f);
    var k = !(4 & h);
    if (k) {
      let p = 0,
        m = 0;
      for (; p < a.length; p++) {
        let q = kb(a[p]);
        q != null && (a[m++] = q);
      }
      m < p && (a.length = m);
      h = (h | 4) & -513;
      h &= -1025;
      h &= -4097;
    }
    h !== g && ((a[r] = h), 2 & h && Object.freeze(a));
    return (a = Nb(a, h, e, f, b, c, k, d));
  }
  function Nb(a, b, c, d, e, f, g, h) {
    var k = b,
      p = Ob(b);
    p &&
      f === 2 &&
      ((a = [...a]), (k = 0), (b = Pb(b, d)), (d = P(c, d, e, a)), (p = !1));
    p ||
      (f === 1 || (f !== 4 ? 0 : 2 & b || (!(16 & b) && 32 & d))
        ? ((b |=
            !a.length || (g && !(4096 & b)) || (32 & d && !(4096 & b || 16 & b))
              ? 2
              : 256),
          b !== k && (a[r] = b),
          Object.freeze(a))
        : (h || (b |= 16), b !== k && (a[r] = b)));
    2 & b || !(4096 & b || 16 & b) || Hb(c, d);
    return a;
  }
  function Mb(a, b) {
    a = Kb(a, b);
    return Array.isArray(a) ? a : Ea;
  }
  function Ob(a) {
    return (!!(2 & a) && !!(4 & a)) || !!(256 & a);
  }
  function Qb(a, b, c, d) {
    M(a);
    var e = a.B;
    P(e, e[r] | 0, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
    return a;
  }
  function Rb(a, b, c) {
    var d = Ub;
    M(a);
    a = a.B;
    var e = a[r] | 0;
    if (c == null) {
      var f = Vb(a);
      if (Wb(f, a, e, d) === b) f.set(d, 0);
      else return;
    } else {
      f = Vb(a);
      let g = Wb(f, a, e, d);
      g !== b && (g && (e = P(a, e, g)), f.set(d, b));
    }
    P(a, e, b, c);
  }
  function Vb(a) {
    var b;
    return (b = a[Aa]) != null ? b : (a[Aa] = new Map());
  }
  function Wb(a, b, c, d) {
    var e = a.get(d);
    if (e != null) return e;
    e = 0;
    for (let f = 0; f < d.length; f++) {
      let g = d[f];
      Kb(b, g) != null && (e !== 0 && (c = P(b, c, e)), (e = g));
    }
    a.set(d, e);
    return e;
  }
  function Xb(a, b, c, d, e, f, g, h) {
    f = f && f !== 4 ? (f !== 1 && (a ? t(a, c) : 2 & c) ? 1 : f) : 4;
    g = !!g || f === 3;
    var k = !!h && !(a ? t(a, c) : 2 & c);
    (f === 2 || k) && a && Gb(a) && ((b = a.B), (c = b[r] | 0));
    a = Mb(b, e);
    var p = a === Ea ? 7 : a[r] | 0,
      m = Ga(p, c);
    if ((h = !(4 & m))) {
      var q = a,
        x = c;
      let y = !!(2 & m);
      y && (x |= 2);
      let H = !y,
        N = !0,
        cb = 0,
        Sb = 0;
      for (; cb < q.length; cb++) {
        let Tb = rb(q[cb], d, !1, x);
        if (Tb instanceof d) {
          if (!y) {
            let Xc = t(Tb);
            H && (H = !Xc);
            N && (N = Xc);
          }
          q[Sb++] = Tb;
        }
      }
      Sb < cb && (q.length = Sb);
      m |= 4;
      m = N ? m & -4097 : m | 4096;
      m = H ? m | 8 : m & -9;
    }
    m !== p && ((a[r] = m), 2 & m && Object.freeze(a));
    if (
      k &&
      !(
        8 & m ||
        (!a.length &&
          (f === 1 || (f !== 4 ? 0 : 2 & m || (!(16 & m) && 32 & c))))
      )
    ) {
      Ob(m) && ((a = [...a]), (m = Pb(m, c)), (c = P(b, c, e, a)));
      d = a;
      k = m;
      for (p = 0; p < d.length; p++)
        (q = d[p]), (m = Fb(q)), q !== m && (d[p] = m);
      k |= 8;
      m = k = d.length ? k | 4096 : k & -4097;
      a[r] = m;
    }
    return (a = Nb(a, m, b, c, e, f, h, g));
  }
  function Yb(a, b, c) {
    var d = a.B;
    return Xb(a, d, d[r] | 0, b, c, void 0, !1, !0);
  }
  function Zb(a, b, c) {
    M(a);
    a = a.B;
    var d = a[r] | 0;
    if (c == null) P(a, d, b);
    else {
      var e = c === Ea ? 7 : c[r] | 0,
        f = e,
        g = Ob(e),
        h = g || Object.isFrozen(c),
        k = !0,
        p = !0;
      for (let q = 0; q < c.length; q++) {
        var m = c[q];
        g || ((m = t(m)), k && (k = !m), p && (p = m));
      }
      g || ((e = k ? 13 : 5), (e = p ? e & -4097 : e | 4096));
      (h && e === f) || ((c = [...c]), (f = 0), (e = Pb(e, d)));
      e !== f && (c[r] = e);
      d = P(a, d, b, c);
      2 & e || !(4096 & e || 16 & e) || Hb(a, d);
    }
  }
  function Pb(a, b) {
    return (a = (2 & b ? a | 2 : a & -3) & -273);
  }
  function $b(a, b, c, d) {
    M(a);
    var e = a.B;
    a = Xb(a, e, e[r] | 0, c, b, 2, !0);
    d = d != null ? d : new c();
    a.push(d);
    b = c = a === Ea ? 7 : a[r] | 0;
    (d = t(d)) ? ((c &= -9), a.length === 1 && (c &= -4097)) : (c |= 4096);
    c !== b && (a[r] = c);
    d || Hb(e);
  }
  function ac(a) {
    a = kb(Jb(a, 22));
    return a != null ? a : 0;
  }
  function bc(a, b) {
    a = Jb(a, b, void 0, qb);
    return a != null ? a : Ib;
  }
  function cc(a, b) {
    a = Jb(a, b);
    a = a == null || typeof a === "string" ? a : void 0;
    return a != null ? a : "";
  }
  function dc(a, b, c) {
    return O(a, b, c == null ? c : lb(c));
  }
  var Q = class {
    constructor(a) {
      this.B = zb(a, void 0, void 0, 2048);
    }
    toJSON() {
      return yb(this);
    }
    da(a) {
      return JSON.stringify(yb(this, a));
    }
  };
  Q.prototype[Ca] = Ha;
  Q.prototype.toString = function () {
    return this.B.toString();
  };
  var ec = class extends Q {};
  var fc = class {
    constructor(a) {
      var b = { context: 358, id: "jserror" };
      this.error = a;
      this.meta = {};
      this.context = b.context;
      this.msg = b.message || "";
      this.id = b.id || "jserror";
    }
  };
  function hc(a, b) {
    if (a)
      for (let c in a)
        Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a);
  }
  function ic(a) {
    try {
      var b;
      if ((b = !!a && a.location.href != null))
        a: {
          try {
            ra(a.foo);
            b = !0;
            break a;
          } catch (c) {}
          b = !1;
        }
      return b;
    } catch (c) {
      return !1;
    }
  }
  function jc(a) {
    function b() {
      d = n.setTimeout(c, 1e3);
      var g = f;
      f = [];
      a.apply(void 0, g);
    }
    function c() {
      d = 0;
      e && ((e = !1), b());
    }
    var d = 0,
      e = !1,
      f = [];
    return function (g) {
      f = arguments;
      d ? (e = !0) : b();
    };
  } /*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
  var kc = globalThis.trustedTypes,
    lc;
  function mc() {
    var a = null;
    if (!kc) return a;
    try {
      let b = (c) => c;
      a = kc.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (b) {}
    return a;
  }
  var nc = class {
    constructor(a) {
      this.h = a;
    }
    toString() {
      return this.h + "";
    }
  };
  function oc(a) {
    var b;
    lc === void 0 && (lc = mc());
    a = (b = lc) ? b.createScriptURL(a) : a;
    return new nc(a);
  }
  var R = class {
      constructor(a) {
        this.h = a;
      }
      toString() {
        return this.h;
      }
    },
    pc = new R("about:invalid#zClosurez");
  class qc {
    constructor(a) {
      this.ua = a;
    }
  }
  function rc(a) {
    return new qc((b) => b.substr(0, a.length + 1).toLowerCase() === a + ":");
  }
  var sc = [
    rc("data"),
    rc("http"),
    rc("https"),
    rc("mailto"),
    rc("ftp"),
    new qc((a) => /^[^:]*([/?#]|$)/.test(a)),
  ];
  function tc(a, b = sc) {
    if (a instanceof R) return a;
    for (let c = 0; c < b.length; ++c) {
      let d = b[c];
      if (d instanceof qc && d.ua(a)) return new R(a);
    }
  }
  var uc = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  function vc(a = document) {
    var b,
      c = (b = a.querySelector) == null ? void 0 : b.call(a, "script[nonce]");
    return c == null ? "" : c.nonce || c.getAttribute("nonce") || "";
  }
  function wc(a, ...b) {
    if (b.length === 0) return oc(a[0]);
    var c = a[0];
    for (let d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
    return oc(c);
  }
  function xc(a, b = document) {
    return b.createElement(String(a).toLowerCase());
  }
  function yc(a, b, c) {
    for (let d in a) b.call(c, a[d], d, a);
  }
  function zc(a, b) {
    for (let c in a) if (b.call(void 0, a[c], c, a)) return !0;
    return !1;
  }
  function Ac(a) {
    for (let b in a) delete a[b];
  }
  var Bc =
    "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(
      " "
    );
  function Cc(a, b) {
    for (let e = 1; e < arguments.length; e++) {
      var c = arguments[e];
      for (d in c) a[d] = c[d];
      for (let f = 0; f < Bc.length; f++) {
        var d = Bc[f];
        Object.prototype.hasOwnProperty.call(c, d) && (a[d] = c[d]);
      }
    }
  }
  function Dc(a, b, c, d) {
    this.left = a;
    this.top = b;
    this.width = c;
    this.height = d;
  }
  Dc.prototype.ceil = function () {
    this.left = Math.ceil(this.left);
    this.top = Math.ceil(this.top);
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this;
  };
  Dc.prototype.floor = function () {
    this.left = Math.floor(this.left);
    this.top = Math.floor(this.top);
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this;
  };
  Dc.prototype.round = function () {
    this.left = Math.round(this.left);
    this.top = Math.round(this.top);
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this;
  };
  function Ec(a, b, c) {
    typeof a.addEventListener === "function" && a.addEventListener(b, c, !1);
  }
  function Fc(a, b, c) {
    typeof a.removeEventListener === "function" &&
      a.removeEventListener(b, c, !1);
  }
  function Gc(a, b, c = null, d = !1, e = !1) {
    Hc(a, b, c, d, e);
  }
  function Hc(a, b, c, d, e = !1) {
    a.google_image_requests || (a.google_image_requests = []);
    var f = xc("IMG", a.document);
    if (c || d) {
      let g = (h) => {
        c && c(h);
        d && qa(a.google_image_requests, f);
        Fc(f, "load", g);
        Fc(f, "error", g);
      };
      Ec(f, "load", g);
      Ec(f, "error", g);
    }
    e && (f.attributionSrc = "");
    f.src = b;
    a.google_image_requests.push(f);
  }
  function Ic({ la: a = !1 } = {}) {
    return a
      ? "connect.pagead2.googlesyndication.com"
      : "pagead2.googlesyndication.com";
  }
  function Jc(a) {
    ({ ub: c = !1, la: b = !1 } = {});
    var b,
      c,
      d = `https://${Ic({ la: b })}/pagead/gen_204?id=rcs_internal`;
    hc(a, (e, f) => {
      if (e || e === 0) d += `&${f}=${encodeURIComponent(String(e))}`;
    });
    Kc(d, c);
  }
  function Kc(a, b = !1) {
    var c = window;
    c.fetch
      ? c.fetch(a, {
          keepalive: !0,
          credentials: "include",
          redirect: "follow",
          method: "get",
          mode: "no-cors",
        })
      : Gc(c, a, void 0, b, !1);
  }
  function Lc(a, b) {
    try {
      let c = (d) => [{ [d.ya]: d.va }];
      return JSON.stringify([
        a.filter((d) => d.ka).map(c),
        yb(b),
        a.filter((d) => !d.ka).map(c),
      ]);
    } catch (c) {
      return Mc(c, b), "";
    }
  }
  function Mc(a, b) {
    try {
      var c = a instanceof Error ? a : Error(String(a));
      let g = c.toString();
      c.name && g.indexOf(c.name) == -1 && (g += ": " + c.name);
      c.message && g.indexOf(c.message) == -1 && (g += ": " + c.message);
      if (c.stack)
        a: {
          var d = c.stack;
          a = g;
          try {
            d.indexOf(a) == -1 && (d = a + "\n" + d);
            let h;
            for (; d != h; )
              (h = d),
                (d = d.replace(
                  RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"),
                  "$1"
                ));
            g = d.replace(RegExp("\n *", "g"), "\n");
            break a;
          } catch (h) {
            g = a;
            break a;
          }
          g = void 0;
        }
      d = g;
      var e = Jb(b, 1);
      var f = e == null ? e : fb(e) ? e | 0 : void 0;
      Jc({ m: d, b: (f != null ? f : 0) || null, v: cc(b, 2) || null });
    } catch (g) {}
  }
  function Nc(a) {
    if (a.l) {
      var b = a.j,
        c = Set;
      var d = Lb(a.j, 3);
      {
        c = [...new c([...d, ...a.l()])];
        M(b);
        let g = b.B,
          h = g[r] | 0;
        if (c == null) P(g, h, 3);
        else {
          d = b = c === Ea ? 7 : c[r] | 0;
          var e = Ob(b),
            f = e || Object.isFrozen(c);
          e || (b = 0);
          f || ((c = [...c]), (d = 0), (b = Pb(b, h)), (f = !1));
          b |= 5;
          e = 4 & b ? (512 & b ? 512 : 1024 & b ? 1024 : 0) : void 0;
          b |= e != null ? e : 1024;
          for (e = 0; e < c.length; e++) {
            let k = c[e],
              p = jb(k);
            Object.is(k, p) ||
              (f && ((c = [...c]), (d = 0), (b = Pb(b, h)), (f = !1)),
              (c[e] = p));
          }
          b !== d && (f && ((c = [...c]), (b = Pb(b, h))), (c[r] = b));
          P(g, h, 3, c);
        }
      }
    }
    a = a.j;
    c = a.B;
    b = c[r] | 0;
    return t(a, b)
      ? a
      : Db(a, c, b)
      ? Eb(a, c)
      : new a.constructor(Cb(c, b, !0));
  }
  var Oc = class {
    constructor(a, b, c) {
      this.l = c;
      c = new ec();
      if (a != null) {
        if (!fb(a)) throw wa("enum");
        a |= 0;
      }
      a = Qb(c, 1, a, 0);
      this.j = Qb(a, 2, L(b), "");
    }
  };
  function Pc(a) {
    var b = new CompressionStream("gzip"),
      c = new Response(b.readable).arrayBuffer(),
      d = b.writable.getWriter(),
      e = typeof a === "string" ? new TextEncoder().encode(a) : a;
    return d.ready
      .then(() => d.write(e))
      .then(() => d.close())
      .then(() => c)
      .then((f) => new Uint8Array(f));
  }
  function Qc(a, b) {
    return O(a, 5, b == null ? b : jb(b));
  }
  function Rc(a, b) {
    return dc(a, 2, b);
  }
  var Sc = class extends Q {
      getValue() {
        return bc(this, 2);
      }
      clearValue() {
        return O(this, 2);
      }
      A() {
        return bc(this, 6);
      }
    },
    Ub = [1, 8, 9, 11];
  function Tc(a, b) {
    dc(a, 24, b);
  }
  var Uc = class extends Q {};
  function Vc(a, b) {
    return O(a, 1, L(b));
  }
  function Wc(a, b) {
    return O(a, 2, L(b));
  }
  var Yc = class extends Q {
    getValue() {
      return cc(this, 2);
    }
    clearValue() {
      return O(this, 2);
    }
  };
  function Zc(a, b) {
    return O(a, 22, b == null ? b : jb(b));
  }
  var $c = class extends Q {
    j() {
      return Yb(this, Yc, 28);
    }
    l(a) {
      Zb(this, 28, a);
    }
    i(a) {
      $b(this, 28, Yc, a);
    }
  };
  function ad(a, b) {
    $b(a, 2, Sc, b);
  }
  function bd(a) {
    {
      M(a);
      let b = a.B,
        c = b[r] | 0;
      a = Kb(b, 12);
      let d = rb(a, Uc, !0, c);
      d = Fb(d);
      a !== d && ((c = P(b, c, 12, d)), Hb(b, c));
      a = d;
    }
    return a;
  }
  function cd(a) {
    return Yb(a, $c, 3);
  }
  function dd(a, b) {
    $b(a, 3, $c, b);
  }
  var ed = class extends Q {
    j() {
      return Yb(this, Yc, 11);
    }
    l(a) {
      Zb(this, 11, a);
    }
    i(a) {
      $b(this, 11, Yc, a);
    }
  };
  class fd extends Oc {
    constructor() {
      super(...arguments);
    }
  }
  function gd(a, ...b) {
    hd(a, ...b.map((c) => ({ ka: !0, ya: 30, va: yb(c) })));
  }
  var id = class extends fd {};
  function jd(a, b) {
    globalThis
      .fetch(a, {
        method: "POST",
        body: b,
        keepalive: b.length < 65536,
        credentials: "omit",
        mode: "no-cors",
        redirect: "follow",
      })
      .catch(() => {});
  }
  function kd(a, b, c = 1, d = !1) {
    if (d) {
      d = typeof CompressionStream === "function";
      var e = b.length > 1024;
      typeof document !== "undefined" &&
      document.visibilityState !== "hidden" &&
      d &&
      e
        ? Pc(b)
            .then((f) => {
              var g = c === 1 ? 5 : 6,
                h;
              h === void 0 && (h = 0);
              if (!ta) {
                ta = {};
                var k =
                    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
                      ""
                    ),
                  p = ["+/=", "+/", "-_=", "-_.", "-_"];
                for (var m = 0; m < 5; m++) {
                  var q = k.concat(p[m].split(""));
                  sa[m] = q;
                  for (var x = 0; x < q.length; x++) {
                    var y = q[x];
                    ta[y] === void 0 && (ta[y] = x);
                  }
                }
              }
              h = sa[h];
              k = Array(Math.floor(f.length / 3));
              p = h[64] || "";
              for (m = q = 0; q < f.length - 2; q += 3) {
                var H = f[q],
                  N = f[q + 1];
                y = f[q + 2];
                x = h[H >> 2];
                H = h[((H & 3) << 4) | (N >> 4)];
                N = h[((N & 15) << 2) | (y >> 6)];
                y = h[y & 63];
                k[m++] = x + H + N + y;
              }
              x = 0;
              y = p;
              switch (f.length - q) {
                case 2:
                  (x = f[q + 1]), (y = h[(x & 15) << 2] || p);
                case 1:
                  (f = f[q]),
                    (k[m] = h[f >> 2] + h[((f & 3) << 4) | (x >> 4)] + y + p);
              }
              jd(`${a}?e=${g}`, k.join(""));
            })
            .catch(() => {
              jd(`${a}?e=${c}`, b);
            })
        : jd(`${a}?e=${c}`, b);
    } else jd(`${a}?e=${c}`, b);
  }
  function hd(a, ...b) {
    try {
      a.h.push(...b),
        a.h.length >= 100 && ld(a),
        a.h.length &&
          a.i === null &&
          (a.i = setTimeout(() => {
            ld(a);
          }, 1e3));
    } catch (c) {
      Mc(c, Nc(a));
    }
  }
  function ld(a) {
    a.i !== null && (clearTimeout(a.i), (a.i = null));
    if (a.h.length) {
      var b = Lc(a.h, Nc(a));
      a.o("https://pagead2.googlesyndication.com/pagead/ping", b, 1, !1);
      a.h = [];
    }
  }
  var md = class extends id {
      constructor() {
        super(19, "1.0", void 0);
        this.o = kd;
        this.h = [];
        this.i = null;
      }
    },
    nd = class extends md {};
  var od = /^((market|itms|intent|itms-appss):\/\/)/i;
  var pd = class {
    constructor(a, b) {
      this.id = a;
      this.title = b;
    }
  };
  var qd = class {
    constructor(a, b, c = !1, d = !1) {
      this.id = a;
      this.isTrueView = c;
      this.title = b;
      this.h = !d;
    }
  };
  var rd = class {
    constructor() {
      this.l = !1;
    }
    disable() {}
    W() {}
    ia() {}
    K() {}
    R() {
      return !1;
    }
  };
  function sd(a = n) {
    var b = a.context || a.AMP_CONTEXT_DATA;
    if (!b)
      try {
        b = a.parent.context || a.parent.AMP_CONTEXT_DATA;
      } catch (e) {}
    var c, d;
    return ((c = b) == null ? 0 : c.pageViewId) &&
      ((d = b) == null ? 0 : d.canonicalUrl)
      ? b
      : null;
  }
  function td() {
    var a = sd(window);
    if (a) {
      if (a) {
        var b = a.pageViewId;
        a = a.clientId;
        z(a) && (b += a.replace(/\D/g, "").substring(0, 6));
      } else b = null;
      return +b;
    }
    for (a = b = window; b && b !== b.parent; )
      (b = b.parent), ic(b) && (a = b);
    b = a;
    a = b.google_global_correlator;
    a ||
      (b.google_global_correlator = a =
        1 + Math.floor(Math.random() * 8796093022208));
    return a;
  }
  function ud(a, b) {
    var c = vd[7] || "google_ps_7";
    a = a.S;
    var d = a[c];
    return d === void 0 ? ((a[c] = b()), a[c]) : d;
  }
  function wd(a) {
    var b = td();
    return ud(a, () => b);
  }
  var xd = class {
      constructor() {
        this.S = {};
      }
    },
    yd = null,
    vd = {
      [8]: "google_prev_ad_formats_by_region",
      [9]: "google_prev_ad_slotnames_by_region",
    };
  function zd(a, b) {
    if (
      !(
        Math.random() > 0.01 ||
        ((b.error && b.meta && b.id) || (b = new fc(b)),
        (n.google_js_errors = n.google_js_errors || []),
        n.google_js_errors.push(b),
        n.error_rep_loaded)
      )
    ) {
      var c = n.document;
      b = xc("SCRIPT", c);
      a = a.h;
      if (a instanceof nc) a = a.h;
      else throw Error("");
      b.src = a;
      (a = vc(b.ownerDocument)) && b.setAttribute("nonce", a);
      (c = c.getElementsByTagName("script")[0]) &&
        c.parentNode &&
        c.parentNode.insertBefore(b, c);
      n.error_rep_loaded = !0;
    }
  }
  var Ad = class {
    constructor() {
      this.h = wc`https://pagead2.googlesyndication.com/pagead/js/err_rep.js`;
    }
  };
  function Bd(a) {
    var b;
    a.visibilityState
      ? (b = "visibilitychange")
      : a.mozVisibilityState
      ? (b = "mozvisibilitychange")
      : a.webkitVisibilityState && (b = "webkitvisibilitychange");
    return b;
  }
  var Cd = null;
  function Dd() {
    var a = n.performance;
    return a && a.now && a.timing
      ? Math.floor(a.now() + a.timing.navigationStart)
      : Date.now();
  }
  function Ed() {
    var a = n.performance;
    return a && a.now ? a.now() : null;
  }
  var Fd = class {
    constructor(a, b) {
      var c = Ed() || Dd();
      this.label = a;
      this.type = b;
      this.value = c;
      this.duration = 0;
      this.taskId = this.slotId = void 0;
      this.uniqueId = Math.random();
    }
  };
  var S = n.performance,
    Gd = !!(S && S.mark && S.measure && S.clearMarks),
    Hd = (function (a) {
      var b = !1,
        c;
      return function () {
        b || ((c = a()), (b = !0));
        return c;
      };
    })(() => {
      var a;
      if ((a = Gd)) {
        var b;
        a = window;
        if (Cd === null) {
          Cd = "";
          try {
            let c = "";
            try {
              c = a.top.location.hash;
            } catch (d) {
              c = a.location.hash;
            }
            c && (Cd = (b = c.match(/\bdeid=([\d,]+)/)) ? b[1] : "");
          } catch (c) {}
        }
        b = Cd;
        a = !!b.indexOf && b.indexOf("1337") >= 0;
      }
      return a;
    });
  function Id(a) {
    a &&
      S &&
      Hd() &&
      (S.clearMarks(`goog_${a.label}_${a.uniqueId}_start`),
      S.clearMarks(`goog_${a.label}_${a.uniqueId}_end`));
  }
  var Jd = class {
    constructor() {
      this.o = [];
      this.h = n;
      this.l = Hd() || Math.random() < 1;
    }
    disable() {
      this.l = !1;
      this.o !== this.h.google_js_reporting_queue &&
        (Hd() && pa(this.o, Id), (this.o.length = 0));
    }
    L(a) {
      !this.l || this.o.length > 2048 || this.o.push(a);
    }
    start(a, b) {
      if (!this.l) return null;
      a = new Fd(a, b);
      b = `goog_${a.label}_${a.uniqueId}_start`;
      S && Hd() && S.mark(b);
      return a;
    }
    end(a) {
      if (this.l && w(a.value)) {
        a.duration = (Ed() || Dd()) - a.value;
        var b = `goog_${a.label}_${a.uniqueId}_end`;
        S && Hd() && S.mark(b);
        this.L(a);
      }
    }
  };
  function Kd(a) {
    a = a._google_rum_ns_ = a._google_rum_ns_ || {};
    return (a.pq = a.pq || []);
  }
  function Ld(a, b, c) {
    hc(b, (d, e) => {
      var f = c && c[e];
      (!d && d !== 0) ||
        f ||
        ((a += `&${encodeURIComponent(e)}=${encodeURIComponent(String(d))}`),
        c && (c[e] = !0));
    });
    return a;
  }
  function Md(a, b, c, d = !0) {
    var e = a.j();
    if (!d) {
      let f = e.findIndex((g) => cc(g, 1) === b);
      if (f !== -1) {
        Wc(e[f], c);
        c = e.filter((g, h) => h <= f || cc(g, 1) !== b);
        a.l(c);
        return;
      }
    }
    a.i(Wc(Vc(new Yc(), b), c));
  }
  function Nd(a, b, c, d = !0) {
    if (b !== "ec")
      switch (b) {
        case "c":
          O(a, 1, L(c));
          break;
        case "e":
          c.split(",")
            .map(Number)
            .filter((f) => !isNaN(f))
            .forEach((f) => {
              M(a);
              Lb(a, 7, 2, !0).push(jb(f));
            });
          break;
        default:
          var e = b.lastIndexOf(".");
          if (e !== -1) {
            let f = b.substring(0, e);
            e = b.substring(e + 1);
            if (e !== "") {
              let g = Number(e);
              if (!isNaN(g)) {
                b = cd(a).find((h) => ac(h) === g);
                b || ((b = Zc(new $c(), g)), dd(a, b));
                f === "qqid" ? O(b, 63, L(c)) : Md(b, f, c, d);
                break;
              }
            }
          }
          Md(a, b, c, d);
      }
  }
  function T(a) {
    if (a.R()) {
      var b = new Ad();
      if (a.namespace === "pagead")
        try {
          Od(a);
        } catch (c) {
          zd(b, c);
        }
      if (U(a)) {
        try {
          a.i && a.sendBeacon(a.report);
        } catch (c) {
          zd(b, c);
        }
        a.report = {};
        a.i = 0;
      }
      a.D === Infinity && a.disable();
      a.o.length = 0;
      a.h.clearTimeout(a.H);
      a.H = 0;
    }
  }
  function U(a) {
    return a.namespace !== "pagead";
  }
  function Pd(a, b) {
    var c = `met.${b.type}`,
      d = w(b.value) ? Math.round(b.value).toString(36) : b.value,
      e = Math.round(b.duration);
    Qd(
      a,
      c,
      `${b.label}` +
        (b.slotId != null ? `_${b.slotId}` : "") +
        `.${d}` +
        (e > 0 ? `_${e.toString(36)}` : "") +
        (b.taskId != null ? `__${Math.round(b.taskId).toString(36)}` : ""),
      !0,
      "~"
    );
  }
  function Rd(a, b) {
    var c = Rc(Qc(new Sc(), b.type), Math.round(Number(b.value)));
    a.namespace && O(c, 3, L(a.namespace));
    isFinite(b.duration) && dc(c, 6, Math.round(b.duration));
    b.taskId != null && dc(c, 13, b.taskId);
    var d = Number(b.label),
      e = isFinite(d);
    switch (b.type) {
      case 1:
        d === 24 && Tc(bd(Sd(a)), Math.round(Number(b.value)));
        return;
      case 3:
      case 13:
        e ? Rb(c, 9, d == null ? d : jb(d)) : Rb(c, 1, L(String(b.label)));
        break;
      case 2:
        e ? Rb(c, 8, d == null ? d : jb(d)) : Rb(c, 1, L(String(b.label)));
        break;
      case 9:
        e ? Rb(c, 11, d == null ? d : jb(d)) : Rb(c, 1, L(String(b.label)));
        break;
      default:
        Rb(c, 1, L(String(b.label)));
    }
    b.slotId != null
      ? ((d = cd(Sd(a)).find((f) => ac(f) === b.slotId)),
        d || ((d = Zc(new $c(), b.slotId)), dd(Sd(a), d)),
        $b(d, 2, Sc, c))
      : ad(Sd(a), c);
  }
  function Td(a) {
    a.K("puid", `${(a.D + 1).toString(36)}~${Date.now().toString(36)}`);
  }
  function Ud(a) {
    a.h.document.readyState === "complete"
      ? a.h.setTimeout(() => {
          T(a);
        }, 0)
      : Ec(a.h, "load", a.O);
    var b = Bd(a.h.document);
    typeof b !== "undefined" && Ec(a.h, b, a.sa);
    Ec(a.h, "pagehide", a.P);
  }
  function Sd(a) {
    a.C || (a.C = new ed());
    return a.C;
  }
  function Qd(a, b, c, d, e = "") {
    var f = Vd(a, b, c, d, e);
    a.j + a.i + f > 8e3 && (T(a), (f = b.length + c.length + 2));
    Wd(a, b, c, d, e);
    a.i += f;
    a.j + a.i >= 6e3 && T(a);
  }
  function Vd(a, b, c, d, e = "") {
    return a.report[b] == null
      ? b.length + c.length + 2
      : d
      ? c.length + e.length
      : c.length - a.report[b].length;
  }
  function Wd(a, b, c, d, e = "") {
    a.report[b] = d && a.report[b] != null ? a.report[b] + `${e}${c}` : c;
  }
  function Od(a) {
    var b = a.h,
      c = b.google_timing_params;
    if (!a.C) {
      let e =
          c &&
          Object.keys(c).some((g) => {
            var h = c[g];
            return g !== "ec" && (h || h === 0);
          }),
        f = a.A.some(([g, h]) => g !== "ec" && !!h);
      if (!e && !f) return;
    }
    U(a) || a.D++;
    var d = Sd(a);
    hc(a.u, (e, f) => {
      e && Nd(d, f, e);
    });
    c &&
      (hc(c, (e, f) => {
        (e || e === 0) && Nd(d, f, String(e));
      }),
      U(a) || (b.google_timing_params = void 0));
    a.A.forEach(([e, f]) => {
      f && Nd(d, e, f);
    });
    U(a) || (a.A.length = 0);
    gd(Xd(a), d);
    U(a) || Td(a);
    a.C = void 0;
  }
  function Yd(a, b) {
    var c = `${a.protocol}//${a.domain}${a.path}ima`,
      d = {};
    c = Ld(c, a.u, d);
    c = Ld(c, b, d);
    b = a.h;
    b.google_timing_params &&
      ((c = Ld(c, b.google_timing_params, d)),
      (b.google_timing_params = void 0));
    pa(a.A, (e) => {
      var [f, g] = e;
      c = Ld(c, { [f]: g });
    });
    a.A.length = 0;
    return c;
  }
  function Xd(a) {
    if (!a.G) {
      let b = a.h;
      b.google_rum_rcs_pinger || (b.google_rum_rcs_pinger = new nd());
      a.G = b.google_rum_rcs_pinger;
    }
    return a.G;
  }
  var Zd = class extends Jd {
    constructor() {
      super();
      this.protocol = "https:";
      this.domain = "pagead2.googlesyndication.com";
      this.path = "/pagead/gen_204?id=";
      this.D = 0;
      this.u = {};
      this.I = {};
      this.qa = [];
      this.report = {};
      this.i = 0;
      this.A = [];
      var a = (this.path + "ima").match(/[?&]s=([^&]*)/);
      this.namespace = a ? a[1] : "";
      a = this.h.navigator;
      this.ga = !(this.domain !== "csi.gstatic.com" || !a || !a.sendBeacon);
      (this.h.performance && this.h.performance.now) || this.K("dat", 1);
      a && a.deviceMemory && this.K("dmc", a.deviceMemory);
      this.h === this.h.top && this.K("top", 1);
      this.O = () => {
        this.h.setTimeout(() => {
          T(this);
        }, 1100);
      };
      this.P = () => {
        for (var c of this.qa)
          try {
            c();
          } catch (f) {}
        c = this.h;
        var d = {};
        if (typeof window.CustomEvent === "function")
          var e = new CustomEvent("rum_blp", d);
        else
          (e = document.createEvent("CustomEvent")),
            e.initCustomEvent("rum_blp", !!d.bubbles, !!d.cancelable, d.detail);
        c.dispatchEvent(e);
        T(this);
        this.G instanceof md && ld(this.G);
      };
      this.ra = jc(() => {
        T(this);
      });
      this.sa = () => {
        var c = this.h.document;
        (c.hidden != null
          ? c.hidden
          : c.mozHidden != null
          ? c.mozHidden
          : c.webkitHidden != null && c.webkitHidden) && this.ra();
      };
      this.H = this.h.setTimeout(() => {
        T(this);
      }, 5e3);
      this.j = 60;
      pa(this.o, (c) => {
        U(this) && Pd(this, c);
        this.namespace === "pagead" && Rd(this, c);
      });
      a = Kd(this.h);
      var b = (...c) => {
        var d = c[0];
        c = d[0];
        d = d[1];
        var e = c.length + d.length + 2;
        U(this) && this.j + this.i + e > 8e3 && T(this);
        this.A.push([c, d]);
        U(this) && ((this.i += e), this.j + this.i >= 6e3 && T(this));
        return 0;
      };
      pa(a, (c) => b(c));
      a.length = 0;
      a.push = b;
      Td(this);
      Ud(this);
    }
    K(a, b) {
      b = String(b);
      this.j =
        this.u[a] != null
          ? this.j + (b.length - this.u[a].length)
          : this.j + (a.length + b.length + 2);
      this.u[a] = b;
    }
    ia(a) {
      return this.u[a];
    }
    W(a, b) {
      var c = `${a}=${b}`;
      this.I[c] ||
        (this.namespace === "pagead" && a !== "ec" && Nd(Sd(this), a, b, !1),
        U(this) && Qd(this, a, b, !1),
        c.length < 1e3 && (this.I[c] = !0));
    }
    R() {
      return this.l && !1;
    }
    sendBeacon(a) {
      this.D++;
      a = Yd(this, a);
      var b = !1;
      try {
        b = !!(
          this.ga &&
          this.h.navigator &&
          this.h.navigator.sendBeacon(a, null)
        );
      } catch (c) {
        this.ga = !1;
      }
      b || Gc(this.h, a);
      Td(this);
    }
    L(a) {
      this.l &&
        this.D < Infinity &&
        (super.L(a),
        U(this) && Pd(this, a),
        this.namespace === "pagead" && Rd(this, a));
    }
    disable() {
      super.disable();
      this.h.clearTimeout(this.H);
      this.i = this.H = 0;
      this.report = {};
      this.C = void 0;
      Ac(this.I);
      Ac(this.u);
      Fc(this.h, "load", this.O);
      Fc(this.h, "pagehide", this.P);
    }
  };
  var $d = class {
    constructor() {
      this.h =
        typeof window !== "undefined" && typeof window.document !== "undefined"
          ? new Zd()
          : new rd();
      if (yd) var a = yd;
      else {
        a = ((a = sd()) ? (ic(a.master) ? a.master : null) : null) || window;
        var b = a.google_persistent_state_async;
        a =
          b != null &&
          typeof b == "object" &&
          b.S != null &&
          typeof b.S == "object"
            ? (yd = b)
            : (a.google_persistent_state_async = yd = new xd());
      }
      a = wd(a);
      a != null && this.h.K("c", a);
      a = Math.floor(Number(this.h.ia("c")) / 2);
      a != null && this.h.K("slotId", a);
    }
    W(a, b) {
      b != null && this.h.W(a, b);
    }
  };
  var ae = RegExp(
    "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
  );
  function be(a, b) {
    if (a) {
      a = a.split("&");
      for (let c = 0; c < a.length; c++) {
        let d = a[c].indexOf("="),
          e,
          f = null;
        d >= 0
          ? ((e = a[c].substring(0, d)), (f = a[c].substring(d + 1)))
          : (e = a[c]);
        b(e, f ? decodeURIComponent(f.replace(/\+/g, " ")) : "");
      }
    }
  }
  function ce(a) {
    this.i = this.A = this.h = "";
    this.C = null;
    this.u = this.j = "";
    this.o = !1;
    var b;
    a instanceof ce
      ? ((this.o = a.o),
        de(this, a.h),
        (this.A = a.A),
        (this.i = a.i),
        ee(this, a.C),
        (this.j = a.j),
        fe(this, ge(a.l)),
        (this.u = a.u))
      : a && (b = String(a).match(ae))
      ? ((this.o = !1),
        de(this, b[1] || "", !0),
        (this.A = he(b[2] || "")),
        (this.i = he(b[3] || "", !0)),
        ee(this, b[4]),
        (this.j = he(b[5] || "", !0)),
        fe(this, b[6] || "", !0),
        (this.u = he(b[7] || "")))
      : ((this.o = !1), (this.l = new ie(null, this.o)));
  }
  ce.prototype.toString = function () {
    var a = [],
      b = this.h;
    b && a.push(je(b, ke, !0), ":");
    var c = this.i;
    if (c || b == "file")
      a.push("//"),
        (b = this.A) && a.push(je(b, ke, !0), "@"),
        a.push(
          encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")
        ),
        (c = this.C),
        c != null && a.push(":", String(c));
    if ((c = this.j))
      this.i && c.charAt(0) != "/" && a.push("/"),
        a.push(je(c, c.charAt(0) == "/" ? le : me, !0));
    (c = this.l.toString()) && a.push("?", c);
    (c = this.u) && a.push("#", je(c, ne));
    return a.join("");
  };
  ce.prototype.resolve = function (a) {
    var b = new ce(this),
      c = !!a.h;
    c ? de(b, a.h) : (c = !!a.A);
    c ? (b.A = a.A) : (c = !!a.i);
    c ? (b.i = a.i) : (c = a.C != null);
    var d = a.j;
    if (c) ee(b, a.C);
    else if ((c = !!a.j)) {
      if (d.charAt(0) != "/")
        if (this.i && !this.j) d = "/" + d;
        else {
          var e = b.j.lastIndexOf("/");
          e != -1 && (d = b.j.slice(0, e + 1) + d);
        }
      e = d;
      if (e == ".." || e == ".") d = "";
      else if (e.indexOf("./") != -1 || e.indexOf("/.") != -1) {
        d = e.lastIndexOf("/", 0) == 0;
        e = e.split("/");
        let f = [];
        for (let g = 0; g < e.length; ) {
          let h = e[g++];
          h == "."
            ? d && g == e.length && f.push("")
            : h == ".."
            ? ((f.length > 1 || (f.length == 1 && f[0] != "")) && f.pop(),
              d && g == e.length && f.push(""))
            : (f.push(h), (d = !0));
        }
        d = f.join("/");
      } else d = e;
    }
    c ? (b.j = d) : (c = a.l.toString() !== "");
    c ? fe(b, ge(a.l)) : (c = !!a.u);
    c && (b.u = a.u);
    return b;
  };
  function de(a, b, c) {
    a.h = c ? he(b, !0) : b;
    a.h && (a.h = a.h.replace(/:$/, ""));
  }
  function ee(a, b) {
    if (b) {
      b = Number(b);
      if (isNaN(b) || b < 0) throw Error("Bad port number " + b);
      a.C = b;
    } else a.C = null;
  }
  function fe(a, b, c) {
    b instanceof ie
      ? ((a.l = b), oe(a.l, a.o))
      : (c || (b = je(b, pe)), (a.l = new ie(b, a.o)));
  }
  function he(a, b) {
    return a
      ? b
        ? decodeURI(a.replace(/%25/g, "%2525"))
        : decodeURIComponent(a)
      : "";
  }
  function je(a, b, c) {
    return typeof a === "string"
      ? ((a = encodeURI(a).replace(b, qe)),
        c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")),
        a)
      : null;
  }
  function qe(a) {
    a = a.charCodeAt(0);
    return "%" + ((a >> 4) & 15).toString(16) + (a & 15).toString(16);
  }
  var ke = /[#\/\?@]/g,
    me = /[#\?:]/g,
    le = /[#\?]/g,
    pe = /[#\?@]/g,
    ne = /#/g;
  function ie(a, b) {
    this.i = this.h = null;
    this.j = a || null;
    this.l = !!b;
  }
  function re(a) {
    a.h ||
      ((a.h = new Map()),
      (a.i = 0),
      a.j &&
        be(a.j, function (b, c) {
          a.add(decodeURIComponent(b.replace(/\+/g, " ")), c);
        }));
  }
  l = ie.prototype;
  l.add = function (a, b) {
    re(this);
    this.j = null;
    a = se(this, a);
    var c = this.h.get(a);
    c || this.h.set(a, (c = []));
    c.push(b);
    this.i += 1;
    return this;
  };
  function te(a, b) {
    re(a);
    b = se(a, b);
    a.h.has(b) && ((a.j = null), (a.i -= a.h.get(b).length), a.h.delete(b));
  }
  l.clear = function () {
    this.h = this.j = null;
    this.i = 0;
  };
  function ue(a, b) {
    re(a);
    b = se(a, b);
    return a.h.has(b);
  }
  l.forEach = function (a, b) {
    re(this);
    this.h.forEach(function (c, d) {
      c.forEach(function (e) {
        a.call(b, e, d, this);
      }, this);
    }, this);
  };
  function ve(a, b) {
    re(a);
    var c = [];
    if (typeof b === "string") ue(a, b) && (c = c.concat(a.h.get(se(a, b))));
    else
      for (a = Array.from(a.h.values()), b = 0; b < a.length; b++)
        c = c.concat(a[b]);
    return c;
  }
  l.set = function (a, b) {
    re(this);
    this.j = null;
    a = se(this, a);
    ue(this, a) && (this.i -= this.h.get(a).length);
    this.h.set(a, [b]);
    this.i += 1;
    return this;
  };
  l.get = function (a, b) {
    if (!a) return b;
    a = ve(this, a);
    return a.length > 0 ? String(a[0]) : b;
  };
  l.toString = function () {
    if (this.j) return this.j;
    if (!this.h) return "";
    var a = [],
      b = Array.from(this.h.keys());
    for (let d = 0; d < b.length; d++) {
      var c = b[d];
      let e = encodeURIComponent(String(c));
      c = ve(this, c);
      for (let f = 0; f < c.length; f++) {
        let g = e;
        c[f] !== "" && (g += "=" + encodeURIComponent(String(c[f])));
        a.push(g);
      }
    }
    return (this.j = a.join("&"));
  };
  function ge(a) {
    var b = new ie();
    b.j = a.j;
    a.h && ((b.h = new Map(a.h)), (b.i = a.i));
    return b;
  }
  function se(a, b) {
    b = String(b);
    a.l && (b = b.toLowerCase());
    return b;
  }
  function oe(a, b) {
    b &&
      !a.l &&
      (re(a),
      (a.j = null),
      a.h.forEach(function (c, d) {
        var e = d.toLowerCase();
        if (d != e && (te(this, d), te(this, e), c.length > 0)) {
          this.j = null;
          d = this.h;
          var f = d.set;
          e = se(this, e);
          var g = c.length;
          if (g > 0) {
            let h = Array(g);
            for (let k = 0; k < g; k++) h[k] = c[k];
            g = h;
          } else g = [];
          f.call(d, e, g);
          this.i += c.length;
        }
      }, a));
    a.l = b;
  }
  var we =
      "ad.doubleclick.net bid.g.doubleclick.net ggpht.com google.co.uk google.com googleads.g.doubleclick.net googleads4.g.doubleclick.net googleadservices.com googlesyndication.com googleusercontent.com gstatic.com gvt1.com prod.google.com pubads.g.doubleclick.net s0.2mdn.net static.doubleclick.net surveys.g.doubleclick.net youtube.com ytimg.com".split(
        " "
      ),
    xe = ["c.googlesyndication.com"];
  function ye(a) {
    var b = typeof window !== "undefined" ? window : void 0;
    var c;
    b: {
      if ((c = n.navigator)) if ((c = c.userAgent)) break b;
      c = "";
    }
    b =
      c.toLowerCase().indexOf("appletv") == -1 &&
      c.toLowerCase().indexOf("apple tv") == -1 &&
      c.toLowerCase().indexOf("cfnetwork") == -1 &&
      c.toLowerCase().indexOf("tvos") == -1 &&
      b != null &&
      b.location
        ? b.location.protocol
        : "https";
    c = !1;
    a == null ||
    !a.startsWith("http") ||
    (a == null ? 0 : a.startsWith("https"))
      ? (c = !1)
      : ze(a, xe)
      ? (c = !1)
      : b.includes("https") && ze(a, we) && (c = !0);
    c &&
      ((a = new ce(a)),
      (b = "ca"),
      $d.ca && $d.hasOwnProperty(b)
        ? (b = $d.ca)
        : ((b = new $d()), ($d.ca = b)),
      b.W("htp", "1"),
      de(a, "https"),
      (a = a.toString()));
    a = new ce(a);
    a.h || de(a, "http");
    return a.toString();
  }
  function ze(a, b) {
    return new RegExp(
      "^https?://([a-z0-9-]{1,63}\\.)*(" +
        b.join("|").replace(/\./g, "\\.") +
        ")(:[0-9]+)?([/?#]|$)",
      "i"
    ).test(a);
  }
  function Ae(a) {
    a = new ce(a);
    var b = a.i;
    if (a.h !== "http" && a.h !== "https") a = !1;
    else if (b.indexOf(".") === -1 || b.match(/^[\.0-9]*$/)) a = !1;
    else
      a: {
        try {
          decodeURIComponent(a.toString().replace(/\+/g, " "));
        } catch (c) {
          a = !1;
          break a;
        }
        a = !0;
      }
    return a;
  }
  function Be(a) {
    this.h = a;
  }
  Be.prototype.toString = function () {
    return this.h;
  };
  var Ce = [];
  function V(a) {
    a = new Be(a);
    Ce.push(a);
    return a;
  }
  var W = V("imalib_instrumentation"),
    De = V("simid_video_addon_pause"),
    Ee = V("simid_video_addon_play"),
    Fe = V("simid_video_addon_stop"),
    Ge = V("request_resize"),
    He = V("video_creative_resize_result");
  V("ui_ad_clicked");
  V("ui_endcard_impression");
  V("ui_replay_icon_clicked");
  V("ui_skip_to_endcard_clicked");
  V("ui_continue_button_clicked");
  var Ie = V("ui_play_pause_clicked");
  V("ui_play_resume_clicked");
  V("ui_play_pause_hidden");
  V("ui_play_pause_shown");
  var Je = V("ui_mute_button_clicked");
  V("ui_show_skip_button");
  V("ui_show_close_button");
  var Ke = V("ui_skip_shown"),
    Le = V("ui_skip_clicked"),
    Me = V("ui_learn_more_clicked"),
    Ne = V("ui_learn_more_clicked_force_player_handles"),
    Oe = V("ui_learn_more_with_url_clicked"),
    Pe = V("ui_author_icon_clicked"),
    Qe = V("ui_ad_author_clicked"),
    Re = V("ui_ad_title_clicked"),
    Se = V("ui_endcard_author_clicked"),
    Te = V("ui_endcard_title_clicked"),
    Ue = V("ui_wta_clicked"),
    Ve = V("ui_cta_clicked"),
    We = new Be("ui_close_button_clicked");
  V("ui_close_countdown_complete");
  var Xe = new Be("ui_vast_icon_clicked"),
    Ye = V("update_action_title"),
    Ze = class {
      constructor(a, b) {
        this.currentTimeSeconds = a;
        this.durationSeconds = b;
        this.accumulatedPodTimeSeconds =
          this.totalAds =
          this.adPosition =
          this.bufferedTimeSeconds =
            null;
      }
    },
    $e = V("video_time_update");
  V("accumulated_video_time");
  V("animate_time_update");
  V("video_reward_granted");
  var af = V("video_show_endcard"),
    bf = V("video_player_end"),
    cf = V("video_player_pause");
  V("video_player_play_attempted");
  var df = V("video_player_play"),
    ef = V("video_player_volume_change");
  V("video_player_media_loaded");
  V("video_player_start");
  var ff = V("video_player_focus_ui_element");
  V("video_player_can_play_through");
  V("video_player_stalled");
  V("video_player_waiting");
  V("video_error");
  var gf = V("request_cta_url_for_qr"),
    hf = V("receive_cta_for_qr"),
    jf = V("och_click");
  V("close_ad");
  var kf = V("request_change_ad_duration_v2"),
    lf = V("ad_duration_change_result_v2");
  V("navigate_to_url");
  V("ui_unblock_back_button");
  function mf(a) {
    a && typeof a.dispose == "function" && a.dispose();
  }
  function X() {
    this.l = this.l;
    this.o = this.o;
  }
  X.prototype.l = !1;
  X.prototype.dispose = function () {
    this.l || ((this.l = !0), this.J());
  };
  X.prototype[Symbol.dispose] = function () {
    this.dispose();
  };
  function nf(a, b) {
    a.l ? b() : (a.o || (a.o = []), a.o.push(b));
  }
  X.prototype.J = function () {
    if (this.o) for (; this.o.length; ) this.o.shift()();
  };
  class of {
    constructor(a, b) {
      this.j = a;
      this.l = b;
      this.i = 0;
      this.h = null;
    }
    get() {
      if (this.i > 0) {
        this.i--;
        var a = this.h;
        this.h = a.next;
        a.next = null;
      } else a = this.j();
      return a;
    }
  }
  function pf() {
    var a = qf,
      b = null;
    a.h && ((b = a.h), (a.h = a.h.next), a.h || (a.i = null), (b.next = null));
    return b;
  }
  class rf {
    constructor() {
      this.i = this.h = null;
    }
    add(a, b) {
      var c = sf.get();
      c.set(a, b);
      this.i ? (this.i.next = c) : (this.h = c);
      this.i = c;
    }
  }
  var sf = new of(
    () => new tf(),
    (a) => a.reset()
  );
  class tf {
    constructor() {
      this.next = this.h = this.i = null;
    }
    set(a, b) {
      this.i = a;
      this.h = b;
      this.next = null;
    }
    reset() {
      this.next = this.h = this.i = null;
    }
  }
  var uf,
    vf = !1,
    qf = new rf(),
    xf = (a) => {
      uf || wf();
      vf || (uf(), (vf = !0));
      qf.add(a, void 0);
    },
    wf = () => {
      var a = Promise.resolve(void 0);
      uf = () => {
        a.then(yf);
      };
    };
  function yf() {
    for (var a; (a = pf()); ) {
      try {
        a.i.call(a.h);
      } catch (c) {
        ia(c);
      }
      var b = sf;
      b.l(a);
      b.i < 100 && (b.i++, (a.next = b.h), (b.h = a));
    }
    vf = !1;
  }
  function zf(a) {
    X.call(this);
    this.A = 1;
    this.j = [];
    this.u = 0;
    this.h = [];
    this.i = {};
    this.C = !!a;
  }
  ha(zf, X);
  l = zf.prototype;
  l.subscribe = function (a, b, c) {
    var d = this.i[a];
    d || (d = this.i[a] = []);
    var e = this.A;
    this.h[e] = a;
    this.h[e + 1] = b;
    this.h[e + 2] = c;
    this.A = e + 3;
    d.push(e);
    return e;
  };
  l.unsubscribe = function (a, b, c) {
    if ((a = this.i[a])) {
      let d = this.h;
      if (
        (a = a.find(function (e) {
          return d[e + 1] == b && d[e + 2] == c;
        }))
      )
        return this.ba(a);
    }
    return !1;
  };
  l.ba = function (a) {
    var b = this.h[a];
    if (b) {
      let c = this.i[b];
      this.u != 0
        ? (this.j.push(a), (this.h[a + 1] = () => {}))
        : (c && qa(c, a),
          delete this.h[a],
          delete this.h[a + 1],
          delete this.h[a + 2]);
    }
    return !!b;
  };
  l.oa = function (a, b) {
    var c = this.i[a];
    if (c) {
      let e = Array(arguments.length - 1);
      var d = arguments.length;
      let f;
      for (f = 1; f < d; f++) e[f - 1] = arguments[f];
      if (this.C)
        for (f = 0; f < c.length; f++)
          (d = c[f]), Af(this.h[d + 1], this.h[d + 2], e);
      else {
        this.u++;
        try {
          for (f = 0, d = c.length; f < d && !this.l; f++) {
            let g = c[f];
            this.h[g + 1].apply(this.h[g + 2], e);
          }
        } finally {
          if ((this.u--, this.j.length > 0 && this.u == 0))
            for (; (c = this.j.pop()); ) this.ba(c);
        }
      }
      return f != 0;
    }
    return !1;
  };
  function Af(a, b, c) {
    xf(function () {
      a.apply(b, c);
    });
  }
  l.clear = function (a) {
    if (a) {
      let b = this.i[a];
      b && (b.forEach(this.ba, this), delete this.i[a]);
    } else (this.h.length = 0), (this.i = {});
  };
  l.J = function () {
    zf.V.J.call(this);
    this.clear();
    this.j.length = 0;
  };
  function Bf(a) {
    X.call(this);
    this.j = new zf(a);
    nf(this, fa(mf, this.j));
  }
  ha(Bf, X);
  Bf.prototype.subscribe = function (a, b, c) {
    return this.j.subscribe(a.toString(), b, c);
  };
  Bf.prototype.unsubscribe = function (a, b, c) {
    return this.j.unsubscribe(a.toString(), b, c);
  };
  Bf.prototype.h = function (a, b) {
    return this.j.oa(a.toString(), b);
  };
  Bf.prototype.clear = function (a) {
    this.j.clear(a !== void 0 ? a.toString() : void 0);
  }; /*

Math.uuid.js (v1.4)
http://www.broofa.com
mailto:robert@broofa.com
Copyright (c) 2010 Robert Kieffer
Dual licensed under the MIT and GPL licenses.
*/
  var Cf =
    "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz".split("");
  function Df() {
    for (var a = Array(36), b = 0, c, d = 0; d < 36; d++)
      d == 8 || d == 13 || d == 18 || d == 23
        ? (a[d] = "-")
        : d == 14
        ? (a[d] = "4")
        : (b <= 2 && (b = (33554432 + Math.random() * 16777216) | 0),
          (c = b & 15),
          (b >>= 4),
          (a[d] = Cf[d == 19 ? (c & 3) | 8 : c]));
    return a.join("");
  }
  function Ef(a) {
    var b;
    (b = a.i) == null ||
      b.addEventListener("LIMA_TYPED_PUBSUB_EVENT_IDENTIFIER", (c) => {
        a.handleEvent(c);
      });
  }
  var Ff = class extends Bf {
    constructor() {
      super();
      this.i = null;
      this.uuid = Df();
      this.i && Ef(this);
    }
    handleEvent(a) {
      if (a instanceof CustomEvent && (a = a.detail) && a.uuid !== this.uuid) {
        a: {
          for (b of Ce) if (b.toString() === a.topicData.topic) break a;
          var b = null;
        }
        b &&
          (a.topicData.payloadData === "null"
            ? super.h(b, null)
            : a.topicData.payloadData === "false"
            ? super.h(b, !1)
            : ((a = a.topicData.payloadData),
              (a = a === "" ? null : JSON.parse(a)) && super.h(b, a)));
      }
    }
    h(a, b) {
      if (this.i) {
        var c = JSON.stringify(b);
        c = new CustomEvent("LIMA_TYPED_PUBSUB_EVENT_IDENTIFIER", {
          detail: {
            uuid: this.uuid,
            topicData: { topic: a.toString(), payloadData: c },
          },
        });
        this.i.dispatchEvent(c);
      }
      return super.h(a, b);
    }
  };
  var Gf = {
      Ga: "SIMID:Media:durationchange",
      Ha: "SIMID:Media:ended",
      ERROR: "SIMID:Media:error",
      Qa: "SIMID:Media:pause",
      Ra: "SIMID:Media:play",
      Ta: "SIMID:Media:playing",
      kb: "SIMID:Media:seeked",
      lb: "SIMID:Media:seeking",
      mb: "SIMID:Media:stalled",
      ob: "SIMID:Media:timeupdate",
      rb: "SIMID:Media:volumechange",
    },
    Hf = {
      ib: "SIMID:Player:resize",
      INIT: "SIMID:Player:init",
      nb: "SIMID:Player:startCreative",
      za: "SIMID:Player:adSkipped",
      Aa: "SIMID:Player:adStopped",
      Ba: "SIMID:Player:appBackgrounded",
      Ca: "SIMID:Player:appForegrounded",
      na: "SIMID:Player:fatalError",
      pa: "SIMID:Player:log",
      Ia: "SIMID:Player:focusIn",
      Ja: "SIMID:Player:focusOut",
    },
    If = D(Gf),
    Jf = D(Hf);
  var Kf = class {
    constructor(a) {
      this.adParameters = a.adParameters;
      this.clickThruUri = a.clickThruUri || null;
      this.clickThruUrl = a.clickThruUrl || null;
    }
  };
  var Y = class {
    constructor(a = {}) {
      this.adParameters = a.adParameters;
      this.clickThruUri = a.clickThruUri;
      this.clickThruUrl = a.clickThruUrl;
      this.creativeWidth = a.creativeWidth;
      this.creativeHeight = a.creativeHeight;
      this.creativeX = a.creativeX;
      this.creativeY = a.creativeY;
      this.code = a.code;
      this.currentTime = a.currentTime;
      this.duration = a.duration;
      this.errorCode = a.errorCode;
      this.errorMessage = a.errorMessage;
      this.fullscreen = a.fullscreen;
      this.fullscreenAllowed = a.fullscreenAllowed;
      this.message = a.message;
      this.muted = a.muted;
      this.navigationSupport = a.navigationSupport;
      this.M = a.M;
      this.N = a.N;
      this.skippableState = a.skippableState;
      this.trackingUrls = a.trackingUrls;
      this.uri = a.uri;
      this.variableDurationAllowed = a.variableDurationAllowed;
      this.version = a.version;
      this.videoHeight = a.videoHeight;
      this.videoWidth = a.videoWidth;
      this.videoX = a.videoX;
      this.videoY = a.videoY;
      this.volume = a.volume;
      this.url = a.url;
      this.focusAllowed = a.focusAllowed;
    }
  };
  var Lf = E({ x: w, y: w, width: w, height: w }),
    Mf = E({ errorCode: F(G(w, C, B)), message: F(G(z, C, B)) }),
    Nf = E({
      currentSrc: F(G(z, C, B)),
      currentTime: F(G(w, C, B)),
      duration: F(G(w, C, B)),
      ended: F(G(A, C, B)),
      muted: F(G(A, C, B)),
      paused: F(G(A, C, B)),
      volume: F(G(w, C, B)),
      fullscreen: F(G(A, C, B)),
    }),
    Of = E({
      environmentData: E({
        videoDimensions: Lf,
        creativeDimensions: Lf,
        fullscreen: A,
        fullscreenAllowed: A,
        variableDurationAllowed: A,
        skippableState: D({
          fa: "adHandles",
          Oa: "notSkippable",
          ha: "playerHandles",
        }),
        skipoffset: F(G(z, C, B)),
        version: z,
        muted: F(G(A, C, B)),
        volume: F(G(w, C, B)),
        siteUrl: F(G(z, C, B)),
        appId: F(G(z, C, B)),
        useragent: F(G(z, C, B)),
        deviceId: F(G(z, C, B)),
        navigationSupport: F(
          G(
            D({ fa: "adHandles", Pa: "notSupported", ha: "playerHandles" }),
            C,
            B
          )
        ),
        closeButtonSupport: F(
          G(D({ fa: "adHandles", ha: "playerHandles" }), C, B)
        ),
        nonlinearDuration: F(G(w, C, B)),
        focusAllowed: F(G(A, C, B)),
      }),
      creativeData: E({
        adParameters: z,
        clickThruUrl: F(G(z, C, B)),
        clickThruUri: F(G(z, C, B)),
      }),
    }),
    Pf = E({ errorCode: w, errorMessage: F(G(z, C, B)) }),
    Qf = E({ duration: w }),
    Rf = E({ currentTime: w }),
    Sf = E({ volume: w, muted: A }),
    Tf = E({
      code: D({
        pb: 0,
        qb: 1,
        Ma: 2,
        Sa: 3,
        Fa: 4,
        Na: 5,
        0: "UNSPECIFIED",
        1: "USER_INITIATED",
        2: "MEDIA_PLAYBACK_COMPLETE",
        3: "PLAYER_INITATED",
        4: "CREATIVE_INITIATED",
        5: "NONLINEAR_DURATION_COMPLETED",
      }),
    }),
    Uf = E({ message: z }),
    Vf = E({
      type: G(
        D({ Ea: "createSession", jb: "resolve", Ua: "reject" }),
        D({
          Da: "SIMID:Creative:clickThru",
          na: "SIMID:Creative:fatalError",
          Ka: "SIMID:Creative:getMediaState",
          pa: "SIMID:Creative:log",
          Va: "SIMID:Creative:reportTracking",
          Wa: "SIMID:Creative:requestChangeAdDuration",
          Xa: "SIMID:Creative:requestChangeVolume",
          Ya: "SIMID:Creative:requestExitFullscreen",
          ab: "SIMID:Creative:requestFullscreen",
          cb: "SIMID:Creative:requestPause",
          eb: "SIMID:Creative:requestPlay",
          fb: "SIMID:Creative:requestResize",
          gb: "SIMID:Creative:requestSkip",
          hb: "SIMID:Creative:requestStop",
          bb: "SIMID:Creative:requestNavigation",
          La: "SIMID:Creative:handleSkipShown",
          Za: "SIMID:Creative:requestFocus",
        }),
        If,
        Jf
      ),
      sessionId: z,
      messageId: w,
      args: F(G(Oa(), C, B)),
    }),
    Wf = E({ messageId: w, value: F(G(Oa(), C, B)) });
  function Xf(a, b) {
    switch (a) {
      case "SIMID:Player:fatalError":
        u(b, Pf);
        var c;
        return new Y({
          errorCode: b.errorCode,
          errorMessage: (c = b.errorMessage) != null ? c : void 0,
        });
      case "SIMID:Media:durationchange":
        return u(b, Qf), new Y({ duration: b.duration });
      case "SIMID:Media:timeupdate":
        return u(b, Rf), new Y({ currentTime: b.currentTime });
      case "SIMID:Media:volumechange":
        return u(b, Sf), new Y({ volume: b.volume, muted: b.muted });
      case "SIMID:Player:adStopped":
        return u(b, Tf), new Y({ code: b.code });
      case "SIMID:Player:init":
        u(b, Of);
        a = b.environmentData;
        b = b.creativeData;
        c = a.videoDimensions;
        let d = a.creativeDimensions,
          e,
          f,
          g,
          h,
          k,
          p;
        return new Y({
          adParameters: b.adParameters,
          clickThruUri: (e = b.clickThruUri) != null ? e : void 0,
          clickThruUrl: (f = b.clickThruUrl) != null ? f : void 0,
          videoHeight: c.height,
          videoWidth: c.width,
          videoX: c.x,
          videoY: c.y,
          creativeHeight: d.height,
          creativeWidth: d.width,
          creativeX: d.x,
          creativeY: d.y,
          fullscreen: a.fullscreen,
          fullscreenAllowed: a.fullscreenAllowed,
          variableDurationAllowed: a.variableDurationAllowed,
          skippableState: a.skippableState,
          version: a.version,
          muted: (g = a.muted) != null ? g : void 0,
          volume: (h = a.volume) != null ? h : void 0,
          navigationSupport: (k = a.navigationSupport) != null ? k : void 0,
          focusAllowed: (p = a.focusAllowed) != null ? p : void 0,
        });
      case "SIMID:Player:log":
        return u(b, Uf), new Y({ message: b.message });
    }
    return new Y();
  }
  var Yf = class {
    da(a, b) {
      var c = {};
      switch (a) {
        case "SIMID:Creative:requestNavigation":
          c.uri = b.uri;
          break;
        case "SIMID:Creative:fatalError":
          c.code = b.code;
          break;
        case "SIMID:Creative:reportTracking":
          c.trackingUrls = b.trackingUrls;
          break;
        case "SIMID:Creative:requestChangeAdDuration":
          c.duration = b.duration;
          break;
        case "SIMID:Creative:requestChangeVolume":
          c.volume = b.volume;
          c.muted = b.muted;
          break;
        case "SIMID:Creative:requestResize":
          a = {
            x: b.creativeX,
            y: b.creativeY,
            width: b.creativeWidth,
            height: b.creativeHeight,
          };
          c.videoDimensions = {
            x: b.videoX,
            y: b.videoY,
            width: b.videoWidth,
            height: b.videoHeight,
          };
          c.creativeDimensions = a;
          c.fullscreen = b.fullscreen;
          break;
        case "SIMID:Creative:log":
          c.message = b.message;
      }
      return c;
    }
  };
  function Zf(a, b) {
    this.type = a;
    this.h = this.target = b;
    this.defaultPrevented = !1;
  }
  Zf.prototype.i = function () {
    this.defaultPrevented = !0;
  };
  var $f = class extends Zf {
    constructor(a, b, c) {
      super(a.type);
      this.resolve = b;
      this.reject = c;
      this.args = a.args;
      this.sessionId = a.sessionId;
    }
  };
  var ag = class {
    constructor(a, b, c, d) {
      this.type = a;
      this.messageId = b;
      this.sessionId = c;
      this.args = d;
    }
  };
  function bg(a, b) {
    Zf.call(this, a ? a.type : "");
    this.relatedTarget = this.h = this.target = null;
    this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0;
    this.key = "";
    this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
    this.state = null;
    this.pointerId = 0;
    this.pointerType = "";
    this.j = null;
    a && this.init(a, b);
  }
  ha(bg, Zf);
  bg.prototype.init = function (a, b) {
    var c = (this.type = a.type),
      d =
        a.changedTouches && a.changedTouches.length
          ? a.changedTouches[0]
          : null;
    this.target = a.target || a.srcElement;
    this.h = b;
    b = a.relatedTarget;
    b ||
      (c == "mouseover"
        ? (b = a.fromElement)
        : c == "mouseout" && (b = a.toElement));
    this.relatedTarget = b;
    d
      ? ((this.clientX = d.clientX !== void 0 ? d.clientX : d.pageX),
        (this.clientY = d.clientY !== void 0 ? d.clientY : d.pageY),
        (this.screenX = d.screenX || 0),
        (this.screenY = d.screenY || 0))
      : ((this.clientX = a.clientX !== void 0 ? a.clientX : a.pageX),
        (this.clientY = a.clientY !== void 0 ? a.clientY : a.pageY),
        (this.screenX = a.screenX || 0),
        (this.screenY = a.screenY || 0));
    this.button = a.button;
    this.key = a.key || "";
    this.ctrlKey = a.ctrlKey;
    this.altKey = a.altKey;
    this.shiftKey = a.shiftKey;
    this.metaKey = a.metaKey;
    this.pointerId = a.pointerId || 0;
    this.pointerType = a.pointerType;
    this.state = a.state;
    this.j = a;
    a.defaultPrevented && bg.V.i.call(this);
  };
  bg.prototype.i = function () {
    bg.V.i.call(this);
    var a = this.j;
    a.preventDefault ? a.preventDefault() : (a.returnValue = !1);
  };
  var cg = "closure_listenable_" + ((Math.random() * 1e6) | 0);
  function dg(a) {
    return !(!a || !a[cg]);
  }
  var eg = 0;
  function fg(a, b, c, d, e) {
    this.listener = a;
    this.proxy = null;
    this.src = b;
    this.type = c;
    this.capture = !!d;
    this.handler = e;
    this.key = ++eg;
    this.U = this.X = !1;
  }
  function gg(a) {
    a.U = !0;
    a.listener = null;
    a.proxy = null;
    a.src = null;
    a.handler = null;
  }
  function hg(a) {
    this.src = a;
    this.h = {};
    this.i = 0;
  }
  hg.prototype.add = function (a, b, c, d, e) {
    var f = a.toString();
    a = this.h[f];
    a || ((a = this.h[f] = []), this.i++);
    var g = ig(a, b, d, e);
    g > -1
      ? ((b = a[g]), c || (b.X = !1))
      : ((b = new fg(b, this.src, f, !!d, e)), (b.X = c), a.push(b));
    return b;
  };
  function jg(a, b) {
    var c = b.type;
    c in a.h &&
      qa(a.h[c], b) &&
      (gg(b), a.h[c].length == 0 && (delete a.h[c], a.i--));
  }
  hg.prototype.T = function (a, b, c, d) {
    a = this.h[a.toString()];
    var e = -1;
    a && (e = ig(a, b, c, d));
    return e > -1 ? a[e] : null;
  };
  hg.prototype.hasListener = function (a, b) {
    var c = a !== void 0,
      d = c ? a.toString() : "",
      e = b !== void 0;
    return zc(this.h, function (f) {
      for (let g = 0; g < f.length; ++g)
        if (!((c && f[g].type != d) || (e && f[g].capture != b))) return !0;
      return !1;
    });
  };
  function ig(a, b, c, d) {
    for (let e = 0; e < a.length; ++e) {
      let f = a[e];
      if (!f.U && f.listener == b && f.capture == !!c && f.handler == d)
        return e;
    }
    return -1;
  }
  var kg = "closure_lm_" + ((Math.random() * 1e6) | 0),
    lg = {},
    mg = 0;
  function ng(a, b, c, d, e) {
    if (d && d.once) return og(a, b, c, d, e);
    if (Array.isArray(b)) {
      for (let f = 0; f < b.length; f++) ng(a, b[f], c, d, e);
      return null;
    }
    c = pg(c);
    return dg(a)
      ? a.listen(b, c, ea(d) ? !!d.capture : !!d, e)
      : qg(a, b, c, !1, d, e);
  }
  function qg(a, b, c, d, e, f) {
    if (!b) throw Error("Invalid event type");
    var g = ea(e) ? !!e.capture : !!e,
      h = rg(a);
    h || (a[kg] = h = new hg(a));
    c = h.add(b, c, d, g, f);
    if (c.proxy) return c;
    d = sg();
    c.proxy = d;
    d.src = a;
    d.listener = c;
    if (a.addEventListener)
      e === void 0 && (e = !1), a.addEventListener(b.toString(), d, e);
    else if (a.attachEvent) a.attachEvent(tg(b.toString()), d);
    else if (a.addListener && a.removeListener) a.addListener(d);
    else throw Error("addEventListener and attachEvent are unavailable.");
    mg++;
    return c;
  }
  function sg() {
    function a(c) {
      return b.call(a.src, a.listener, c);
    }
    var b = ug;
    return a;
  }
  function og(a, b, c, d, e) {
    if (Array.isArray(b)) {
      for (let f = 0; f < b.length; f++) og(a, b[f], c, d, e);
      return null;
    }
    c = pg(c);
    return dg(a)
      ? a.ja(b, c, ea(d) ? !!d.capture : !!d, e)
      : qg(a, b, c, !0, d, e);
  }
  function vg(a, b, c, d, e) {
    if (Array.isArray(b))
      for (let f = 0; f < b.length; f++) vg(a, b[f], c, d, e);
    else
      (d = ea(d) ? !!d.capture : !!d),
        (c = pg(c)),
        dg(a)
          ? a.ea(b, c, d, e)
          : a && (a = rg(a)) && (b = a.T(b, c, d, e)) && wg(b);
  }
  function wg(a) {
    if (typeof a !== "number" && a && !a.U) {
      var b = a.src;
      if (dg(b)) jg(b.F, a);
      else {
        var c = a.type,
          d = a.proxy;
        b.removeEventListener
          ? b.removeEventListener(c, d, a.capture)
          : b.detachEvent
          ? b.detachEvent(tg(c), d)
          : b.addListener && b.removeListener && b.removeListener(d);
        mg--;
        (c = rg(b))
          ? (jg(c, a), c.i == 0 && ((c.src = null), (b[kg] = null)))
          : gg(a);
      }
    }
  }
  function tg(a) {
    return a in lg ? lg[a] : (lg[a] = "on" + a);
  }
  function ug(a, b) {
    if (a.U) a = !0;
    else {
      b = new bg(b, this);
      let c = a.listener,
        d = a.handler || a.src;
      a.X && wg(a);
      a = c.call(d, b);
    }
    return a;
  }
  function rg(a) {
    a = a[kg];
    return a instanceof hg ? a : null;
  }
  var xg = "__closure_events_fn_" + ((Math.random() * 1e9) >>> 0);
  function pg(a) {
    if (typeof a === "function") return a;
    a[xg] ||
      (a[xg] = function (b) {
        return a.handleEvent(b);
      });
    return a[xg];
  }
  function yg(a) {
    X.call(this);
    this.i = a;
    this.h = {};
  }
  ha(yg, X);
  var zg = [];
  l = yg.prototype;
  l.listen = function (a, b, c, d) {
    Array.isArray(b) || (b && (zg[0] = b.toString()), (b = zg));
    for (let e = 0; e < b.length; e++) {
      let f = ng(a, b[e], c || this.handleEvent, d || !1, this.i || this);
      if (!f) break;
      this.h[f.key] = f;
    }
    return this;
  };
  l.ja = function (a, b, c, d) {
    return Ag(this, a, b, c, d);
  };
  function Ag(a, b, c, d, e, f) {
    if (Array.isArray(c))
      for (let g = 0; g < c.length; g++) Ag(a, b, c[g], d, e, f);
    else {
      b = og(b, c, d || a.handleEvent, e, f || a.i || a);
      if (!b) return a;
      a.h[b.key] = b;
    }
    return a;
  }
  l.ea = function (a, b, c, d, e) {
    if (Array.isArray(b))
      for (let f = 0; f < b.length; f++) this.ea(a, b[f], c, d, e);
    else
      (c = c || this.handleEvent),
        (d = ea(d) ? !!d.capture : !!d),
        (e = e || this.i || this),
        (c = pg(c)),
        (d = !!d),
        (b = dg(a)
          ? a.T(b, c, d, e)
          : a
          ? (a = rg(a))
            ? a.T(b, c, d, e)
            : null
          : null),
        b && (wg(b), delete this.h[b.key]);
  };
  function Bg(a) {
    yc(
      a.h,
      function (b, c) {
        this.h.hasOwnProperty(c) && wg(b);
      },
      a
    );
    a.h = {};
  }
  l.J = function () {
    yg.V.J.call(this);
    Bg(this);
  };
  l.handleEvent = function () {
    throw Error("EventHandler.handleEvent not implemented");
  };
  function Cg() {
    X.call(this);
    this.F = new hg(this);
    this.D = this;
    this.u = null;
  }
  ha(Cg, X);
  Cg.prototype[cg] = !0;
  l = Cg.prototype;
  l.addEventListener = function (a, b, c, d) {
    ng(this, a, b, c, d);
  };
  l.removeEventListener = function (a, b, c, d) {
    vg(this, a, b, c, d);
  };
  l.dispatchEvent = function (a) {
    var b,
      c = this.u;
    if (c) for (b = []; c; c = c.u) b.push(c);
    c = this.D;
    var d = a.type || a;
    if (typeof a === "string") a = new Zf(a, c);
    else if (a instanceof Zf) a.target = a.target || c;
    else {
      var e = a;
      a = new Zf(d, c);
      Cc(a, e);
    }
    e = !0;
    var f;
    if (b)
      for (f = b.length - 1; f >= 0; f--) {
        var g = (a.h = b[f]);
        e = Dg(g, d, !0, a) && e;
      }
    g = a.h = c;
    e = Dg(g, d, !0, a) && e;
    e = Dg(g, d, !1, a) && e;
    if (b)
      for (f = 0; f < b.length; f++)
        (g = a.h = b[f]), (e = Dg(g, d, !1, a) && e);
    return e;
  };
  l.J = function () {
    Cg.V.J.call(this);
    if (this.F) {
      var a = this.F;
      let b = 0;
      for (let c in a.h) {
        let d = a.h[c];
        for (let e = 0; e < d.length; e++) ++b, gg(d[e]);
        delete a.h[c];
        a.i--;
      }
    }
    this.u = null;
  };
  l.listen = function (a, b, c, d) {
    return this.F.add(String(a), b, !1, c, d);
  };
  l.ja = function (a, b, c, d) {
    return this.F.add(String(a), b, !0, c, d);
  };
  l.ea = function (a, b, c, d) {
    {
      var e = this.F;
      let f = String(a).toString();
      f in e.h &&
        ((a = e.h[f]),
        (b = ig(a, b, c, d)),
        b > -1 &&
          (gg(a[b]),
          Array.prototype.splice.call(a, b, 1),
          a.length == 0 && (delete e.h[f], e.i--)));
    }
  };
  function Dg(a, b, c, d) {
    b = a.F.h[String(b)];
    if (!b) return !0;
    b = b.concat();
    var e = !0;
    for (let f = 0; f < b.length; ++f) {
      let g = b[f];
      if (g && !g.U && g.capture == c) {
        let h = g.listener,
          k = g.handler || g.src;
        g.X && jg(a.F, g);
        e = h.call(k, d) !== !1 && e;
      }
    }
    return e && !d.defaultPrevented;
  }
  l.T = function (a, b, c, d) {
    return this.F.T(String(a), b, c, d);
  };
  l.hasListener = function (a, b) {
    return this.F.hasListener(a !== void 0 ? String(a) : void 0, b);
  };
  class Eg {
    constructor() {
      this.promise = new Promise((a, b) => {
        this.resolve = a;
        this.reject = b;
      });
    }
  }
  var Fg = Oa();
  function Gg(a) {
    a = a == null ? void 0 : a.data;
    if (!z(a)) return null;
    try {
      var b = JSON.parse(a);
    } catch (c) {
      return null;
    }
    return Fg(b) ? b : null;
  }
  function Hg(a, { Z: b, aa: c }) {
    a.Z = b;
    a.aa = c;
    a.j.listen(window, "message", (d) => {
      a: {
        d = d.j;
        var e = a.Z();
        if ((e = e ? e === d.source : !1))
          (e = Gg(d)),
            (e = !(e == null || e.sendingInstanceId == null
              ? 0
              : a.i.Y && e.sendingInstanceId === a.A));
        if (e) {
          var f = Gg(d);
          if (Vf(f)) {
            d = f.type;
            e = f.sessionId;
            var g = f.args;
            f = f.messageId;
            if (e === a.sessionId || d === "createSession")
              if (d !== "createSession" || a.sessionId == null) {
                var h = null;
                try {
                  if (d === "resolve" || d === "reject")
                    if (Wf(g)) {
                      var k;
                      h = new Y({
                        N: g.messageId,
                        M: (k = g.value) != null ? k : void 0,
                      });
                    } else h = null;
                  else h = Xf(d, g != null ? g : {});
                } catch (m) {
                  if (m.cause === 1210) {
                    var p = JSON.stringify({
                      type: "TimingEvent",
                      key: "smd_ss_nfo_init",
                    });
                    a.sendMessage("SIMID:Creative:log", new Y({ message: p }));
                    p = JSON.stringify({
                      type: "OneShotParameter",
                      key: "smd_ss_nfo_init_r",
                      value: m.message,
                    });
                    a.sendMessage("SIMID:Creative:log", new Y({ message: p }));
                    break a;
                  }
                  throw m;
                }
                if (h)
                  switch (
                    (d === "SIMID:Player:init" &&
                      ((k = JSON.stringify({
                        type: "TimingEvent",
                        key: "smd_ss_so_init",
                      })),
                      a.sendMessage(
                        "SIMID:Creative:log",
                        new Y({ message: k })
                      )),
                    (k = new ag(d, f, e, h)),
                    k.type)
                  ) {
                    case "resolve":
                    case "reject":
                      b: if ((e = k.args.N))
                        if (
                          ((d = (p = k.args.M) != null ? p : {}),
                          a.h.has(e) && ((p = a.h.get(e)), p != null))
                        ) {
                          if (k.type === "resolve") p.resolve(d);
                          else if (k.type === "reject") {
                            try {
                              u(d, Mf);
                            } catch (m) {
                              p.reject({
                                errorCode: 1211,
                                message:
                                  "Failed to deserialize reject message arguments.",
                              });
                              break b;
                            }
                            p.reject(d);
                          }
                          a.h.delete(e);
                        }
                      break;
                    case "createSession":
                      a.sessionId = k.sessionId;
                      a.resolve(k.messageId);
                      a.C.resolve();
                      break;
                    default:
                      Ig(a, k);
                  }
                else
                  a.reject(f, {
                    errorCode: 1211,
                    message: "Invalid message arguments.",
                  });
              }
          }
        }
      }
    });
  }
  async function Jg(a, b, c) {
    await a.C.promise;
    b !== "SIMID:Player:init" && (await Promise.resolve());
    return a.l ? {} : Kg(a, b, c);
  }
  function Kg(a, b, c) {
    var d = a.H++,
      e = {};
    e.type = b;
    e.sessionId = a.sessionId;
    a.i.Y && (e.sendingInstanceId = a.A);
    e.messageId = d;
    e.timestamp = Date.now();
    e.args =
      b === "resolve" || b === "reject"
        ? { messageId: c.N, value: c.M }
        : a.I.da(b, c);
    c = a.aa();
    if (!c) throw Error("Target window is null.");
    c.postMessage(JSON.stringify(e), "*");
    return a.G.includes(b)
      ? ((b = new Eg()), a.h.set(d, b), b.promise)
      : Promise.resolve({});
  }
  function Ig(a, b) {
    a.dispatchEvent(
      new $f(
        b,
        (c = {}) => void a.resolve(b.messageId, c),
        (c) => void a.reject(b.messageId, c)
      )
    );
  }
  var Mg = class extends Cg {
    constructor() {
      var a = { Y: !0 },
        b = new Yf(),
        c = Lg;
      super();
      this.I = b;
      this.G = c;
      this.sessionId = null;
      this.H = 1;
      this.C = new Eg();
      this.i = { Y: !!a.Y, ma: !!a.ma };
      this.aa = () => window;
      this.Z = () => window;
      this.j = new yg(this);
      nf(this, fa(mf, this.j));
      this.h = new Map();
      this.A = Df();
    }
    sendMessage(a, b = new Y()) {
      if (this.i.ma) {
        if (this.l) return Promise.resolve({});
        if (this.sessionId == null) {
          if (If(a)) return Promise.resolve({});
          if (Jf(a)) return Jg(this, a, b);
        }
      }
      return Kg(this, a, b);
    }
    resolve(a, b = {}) {
      this.sendMessage("resolve", new Y({ N: a, M: b }));
    }
    reject(a, b) {
      this.sendMessage("reject", new Y({ N: a, M: b }));
    }
  };
  var Lg =
    "SIMID:Creative:getMediaState SIMID:Creative:reportTracking SIMID:Creative:requestChangeVolume SIMID:Creative:requestExitFullscreen SIMID:Creative:requestFullscreen SIMID:Creative:requestResize SIMID:Creative:requestSkip SIMID:Creative:requestStop SIMID:Creative:requestPause SIMID:Creative:requestPlay SIMID:Creative:requestChangeAdDuration SIMID:Creative:requestNavigation SIMID:Creative:requestFocus createSession".split(
      " "
    );
  function Ng(a) {
    var b = Df(),
      c = a.protocol;
    c.sessionId = b;
    return c.sendMessage("createSession").then(a.h.resolve).catch(a.h.reject);
  }
  async function Z(a, b, c) {
    await a.h.promise;
    return a.protocol.sendMessage(b, c);
  }
  function Og(a) {
    Z(a, "SIMID:Creative:clickThru");
  }
  function Pg(a) {
    return Z(a, "SIMID:Creative:requestPause");
  }
  function Qg(a) {
    return Z(a, "SIMID:Creative:requestSkip");
  }
  var Rg = class extends Cg {
    constructor(a = window.parent) {
      super();
      this.protocol = new Mg();
      nf(this, fa(mf, this.protocol));
      Hg(this.protocol, { Z: () => a, aa: () => a });
      [...Object.values(Hf), ...Object.values(Gf)].forEach((b) => {
        this.protocol.listen(b, (c) => this.dispatchEvent(c));
      });
      this.h = new Eg();
    }
    log(a) {
      return Z(this, "SIMID:Creative:log", new Y({ message: a }));
    }
    requestResize(a) {
      return Z(this, "SIMID:Creative:requestResize", new Y(a));
    }
  };
  var Sg = class {
    constructor(a) {
      this.videoDimensions = new Dc(
        a.videoX,
        a.videoY,
        a.videoWidth,
        a.videoHeight
      );
      this.creativeDimensions = new Dc(
        a.creativeX,
        a.creativeY,
        a.creativeWidth,
        a.creativeHeight
      );
      this.fullscreen = a.fullscreen;
      this.fullscreenAllowed = a.fullscreenAllowed;
      this.variableDurationAllowed = a.variableDurationAllowed;
      this.skippableState = a.skippableState;
      this.version = a.version;
      this.navigationSupport = a.navigationSupport || "adHandles";
      var b;
      this.focusAllowed = (b = a.focusAllowed) != null ? b : !1;
    }
  };
  function Tg(a) {
    u(a, Nf);
    a = Object.fromEntries(Object.entries(a).filter(([, b]) => b !== null));
    return new Ug(a);
  }
  var Ug = class {
    constructor({
      currentSrc: a = null,
      currentTime: b = -1,
      duration: c = -1,
      ended: d = !1,
      fullscreen: e = !1,
      muted: f = !1,
      paused: g = !1,
      volume: h = 1,
    } = {}) {
      this.currentSrc = a;
      this.currentTime = b;
      this.duration = c;
      this.ended = d;
      this.fullscreen = e;
      this.muted = f;
      this.paused = g;
      this.volume = h;
    }
    da() {
      return {
        currentSrc: this.currentSrc,
        currentTime: this.currentTime,
        duration: this.duration,
        ended: this.ended,
        muted: this.muted,
        paused: this.paused,
        volume: this.volume,
        fullscreen: this.fullscreen,
      };
    }
  };
  async function Vg(a) {
    var b = await Z(a.j, "SIMID:Creative:getMediaState");
    try {
      a.i = Tg(b);
    } catch (c) {}
  }
  function Wg(a) {
    Bg(a.h);
    a.h.listen(a.j, "SIMID:Player:init", (b) => {
      a.i.fullscreen = b.args.fullscreen;
      b.args.muted != null && (a.i.muted = b.args.muted);
      b.args.volume != null && (a.i.volume = b.args.volume);
    });
    a.h.listen(a.j, "SIMID:Player:startCreative", () => {
      a.dispatchEvent("start");
    });
    a.h.listen(a.j, "SIMID:Player:fatalError", () => {
      a.dispatchEvent("error");
    });
    a.h.listen(a.j, "SIMID:Player:adSkipped", () => {
      a.dispatchEvent("skip");
    });
    a.h.listen(a.j, "SIMID:Media:durationchange", (b) => {
      a.i.duration = b.args.duration;
      a.dispatchEvent("durationChange");
    });
    a.h.listen(a.j, "SIMID:Media:ended", () => {
      a.i.ended = !0;
      a.dispatchEvent("end");
    });
    a.h.listen(a.j, "SIMID:Media:error", () => {
      a.dispatchEvent("error");
    });
    a.h.listen(a.j, "SIMID:Media:pause", () => {
      a.i.paused = !0;
      a.dispatchEvent("pause");
    });
    a.h.listen(a.j, "SIMID:Media:play", () => {
      a.i.paused = !1;
      a.dispatchEvent("play");
    });
    a.h.listen(a.j, "SIMID:Media:playing", () => {
      a.dispatchEvent("playing");
    });
    a.h.listen(a.j, "SIMID:Media:seeked", () => {
      a.dispatchEvent("seeked");
    });
    a.h.listen(a.j, "SIMID:Media:seeking", () => {
      a.dispatchEvent("seeking");
    });
    a.h.listen(a.j, "SIMID:Media:timeupdate", (b) => {
      a.i.currentTime = b.args.currentTime;
      a.dispatchEvent("timeUpdate");
    });
    a.h.listen(a.j, "SIMID:Media:volumechange", (b) => {
      a.i.volume = b.args.volume;
      a.i.muted = b.args.muted;
      a.dispatchEvent("volumeChange");
    });
    Vg(a);
  }
  var Xg = class extends Cg {
    constructor(a) {
      super();
      this.j = a;
      this.h = new yg(this);
      nf(this, fa(mf, this.h));
      this.i = new Ug();
    }
    getCurrentTime() {
      return this.i.currentTime;
    }
    A() {
      return this.i.duration;
    }
  };
  function Yg(a) {
    a.i.listen("SIMID:Player:init", (b) => void a.u(b));
    a.i.listen("SIMID:Player:startCreative", (b) => void a.A(b));
    a.i.listen("SIMID:Player:fatalError", (b) => {
      b.resolve();
    });
    a.i.listen("SIMID:Player:adStopped", (b) => void a.O(b));
    a.i.listen("SIMID:Player:adSkipped", (b) => {
      b.resolve();
    });
    a.i.listen("SIMID:Player:appForegrounded", (b) => void a.C(b));
    a.i.listen("SIMID:Player:log", (b) => {
      b.args.message === "pp" && a.log("cr");
      b.resolve();
    });
    a.i.listen("SIMID:Player:focusIn", (b) => {
      b.resolve();
    });
    a.i.listen("SIMID:Player:focusOut", (b) => {
      b.resolve();
    });
    a.j.listen("durationChange", () => {});
    a.j.listen("end", () => void a.I());
    a.j.listen("error", () => {});
    a.j.listen("pause", () => void a.D());
    a.j.listen("play", () => void a.G());
    a.j.listen("playing", () => {});
    a.j.listen("seeked", () => {});
    a.j.listen("seeking", () => {});
    a.j.listen("timeUpdate", () => void a.H());
    a.j.listen("volumeChange", () => void a.L());
  }
  function Zg() {
    var a = $g.h;
    Yg(a);
    Ng(a.i).then(() => void Wg(a.j));
  }
  function ah(a, b, c) {
    var d = a.environmentData;
    if (d == null)
      Promise.reject(
        Error(`Environment data is null, cannot navigate to URL: ${b}`)
      );
    else if (((d = d.navigationSupport), d === "playerHandles" || c))
      Z(a.i, "SIMID:Creative:requestNavigation", new Y({ uri: b }));
    else if (d === "adHandles") {
      if (!/^[\s\xa0]*$/.test(b == null ? "" : String(b))) {
        c = b instanceof R || !od.test(b) ? b : new R(b);
        c = c instanceof R ? c : tc(b, sc) || pc;
        b = window;
        if (c instanceof R)
          if (c instanceof R) c = c.h;
          else throw Error("");
        else c = uc.test(c) ? c : void 0;
        c !== void 0 && b.open(c, "_blank", void 0);
      }
      Pg(a.i);
      Promise.resolve({});
    } else {
      var e;
      Promise.reject(
        Error(
          `Navigation support "${
            (e = a.environmentData) == null ? void 0 : e.navigationSupport
          }" unrecognized.`
        )
      );
    }
  }
  var bh = class {
    constructor() {
      var a = new Rg(window.parent);
      this.i = a;
      this.environmentData = this.creativeData = null;
      this.j = new Xg(a);
    }
    u(a) {
      this.creativeData = new Kf(a.args);
      this.environmentData = new Sg(a.args);
      a.resolve();
    }
    A(a) {
      a.resolve();
    }
    O(a) {
      a.resolve();
    }
    C(a) {
      a.resolve();
    }
    I() {}
    D() {}
    G() {}
    H() {}
    L() {}
    log(a) {
      this.i.log(a);
    }
  };
  function ch(a, b = !1) {
    if (a == null) return null;
    var c = new ce("//www.youtube.com/watch"),
      d = c.l;
    d.set("v", a);
    d.set("feature", b ? "trueview-instream" : "instream");
    fe(c, d);
    return c.toString();
  }
  function dh(a) {
    a.h.subscribe(Le, (b) => {
      b === "qr_code_scan" ? a.pingback.tick("ssfs") : a.pingback.tick("ssfc");
      Qg(a.i);
    });
    a.h.subscribe(Ke, () => void Z(a.i, "SIMID:Creative:handleSkipShown"));
    a.h.subscribe(We, () => void Qg(a.i));
    a.h.subscribe(Ie, () => {
      a.j.i.paused ? Z(a.i, "SIMID:Creative:requestPlay") : Pg(a.i);
    });
    a.h.subscribe(Me, () => void eh(a, !1));
    a.h.subscribe(Ne, () => void eh(a, !0));
    a.h.subscribe(Oe, (b) => void eh(a, !1, b));
    a.h.subscribe(Pe, () => {
      a.l ? eh(a, !1) : fh(a);
    });
    a.h.subscribe(Qe, () => {
      a.l ? eh(a, !1) : fh(a);
    });
    a.h.subscribe(Re, () => {
      a.l ? eh(a, !1) : gh(a);
    });
    a.h.subscribe(Se, () => {
      a.l ? eh(a, !1) : fh(a);
    });
    a.h.subscribe(Te, () => {
      a.l ? eh(a, !1) : gh(a);
    });
    a.h.subscribe(Xe, () => {});
    a.h.subscribe(Ue, () => {});
    a.h.subscribe(Ve, () => {});
    a.h.subscribe(De, () => void Pg(a.i));
    a.h.subscribe(Ee, () => void Z(a.i, "SIMID:Creative:requestPlay"));
    a.h.subscribe(Fe, () => void Z(a.i, "SIMID:Creative:requestStop"));
    a.h.subscribe(
      Je,
      ({ volume: b, muted: c }) =>
        void Z(
          a.i,
          "SIMID:Creative:requestChangeVolume",
          new Y({ volume: b, muted: c })
        )
    );
    a.h.subscribe(W, (b) => void hh(a, b));
    a.h.subscribe(Ge, (b) => {
      hh(a, { type: "TimingEvent", key: "sma_r_resize_attempt" });
      ih(a, a.i.requestResize.bind(a.i), b, He, {
        xa: () => {
          hh(a, { type: "TimingEvent", key: "sma_r_resize_success" });
        },
        wa: () => {
          hh(a, { type: "TimingEvent", key: "sma_r_resize_failure" });
        },
      });
    });
    a.h.subscribe(gf, () => {
      a.h.h(hf, a.clickThruUri);
    });
    a.h.h(hf, a.clickThruUri);
    a.h.subscribe(jf, () => {
      Og(a.i);
    });
    a.h.subscribe(kf, (b) => {
      ih(
        a,
        (c) =>
          Z(
            a.i,
            "SIMID:Creative:requestChangeAdDuration",
            new Y({ duration: c.duration })
          ),
        b,
        lf
      );
    });
  }
  function eh(a, b, c) {
    if (a.environmentData)
      switch (a.environmentData.navigationSupport) {
        case "adHandles":
          let d;
          (d = a.h) == null ||
            d.h(W, { type: "TimingEvent", key: "sma_r_nav_ct_ah" });
          break;
        case "playerHandles":
          let e;
          (e = a.h) == null ||
            e.h(W, { type: "TimingEvent", key: "sma_r_nav_ct_ph" });
          break;
        default:
          let f;
          (f = a.h) == null ||
            f.h(W, { type: "TimingEvent", key: "sma_r_nav_ct_u" });
      }
    else {
      let d;
      (d = a.h) == null ||
        d.h(W, { type: "TimingEvent", key: "sma_r_nav_ct_ned" });
    }
    if (c) {
      if (!Ae(c)) {
        let e;
        (e = a.h) == null ||
          e.h(W, {
            type: "TimingEvent",
            key: "sma_r_nav_ct_invalid_override_uri",
          });
      }
      if (!c.includes("aclk")) {
        let e;
        (e = a.h) == null ||
          e.h(W, {
            type: "TimingEvent",
            key: "sma_r_nav_ct_override_uri_no_aclk",
          });
      }
      ah(a, c, b);
      Og(a.i);
      let d;
      (d = a.h) == null ||
        d.h(W, { type: "TimingEvent", key: "sma_r_nav_ct_with_override_url" });
    } else if (a.clickThruUri) {
      if (!Ae(a.clickThruUri)) {
        let e;
        (e = a.h) == null ||
          e.h(W, { type: "TimingEvent", key: "sma_r_nav_ct_invalid_uri" });
      }
      if (!a.clickThruUri.includes("aclk")) {
        let e;
        (e = a.h) == null ||
          e.h(W, { type: "TimingEvent", key: "sma_r_nav_ct_uri_no_aclk" });
      }
      ah(a, a.clickThruUri, b);
      Og(a.i);
      let d;
      (d = a.h) == null || d.h(W, { type: "TimingEvent", key: "sma_r_nav_ct" });
    } else {
      let d;
      (d = a.h) == null ||
        d.h(W, { type: "TimingEvent", key: "sma_r_nav_ct_no_uri" });
    }
  }
  function fh(a) {
    if (a.o && a.o.h && a.R) {
      var b = a.R.id;
      b = b == null ? "" : String(b);
      b = /^[\s\xa0]*$/.test(b)
        ? null
        : "//www.youtube.com/channel/" +
          (b.lastIndexOf("UC", 0) == 0 && b.length == 24 ? b : "UC" + b);
      if (b) {
        ah(a, ye(b), !1);
        let c;
        (c = a.h) == null ||
          c.h(W, { type: "TimingEvent", key: "sma_r_nav_yt_c" });
      }
    }
  }
  function gh(a) {
    if (a.o && a.o.h) {
      var b = ch(a.o.id, a.isSkippable);
      if (b) {
        ah(a, ye(b), !1);
        let c;
        (c = a.h) == null ||
          c.h(W, { type: "TimingEvent", key: "sma_r_nav_yt_v" });
      }
    }
  }
  function hh(a, b) {
    (b = JSON.stringify(b)) && a.i.log(b);
  }
  function ih(a, b, c, d, e = {}) {
    var f = c && typeof c === "object" ? c : {};
    b(c)
      .then(() => {
        var g;
        (g = e.xa) == null || g.call(e);
        var h;
        (h = a.h) == null || h.h(d, Object.assign({}, f, { success: !0 }));
      })
      .catch(() => {
        var g;
        (g = e.wa) == null || g.call(e);
        var h;
        (h = a.h) == null || h.h(d, Object.assign({}, f, { success: !1 }));
      });
  }
  function jh(a) {
    a.P.promise.then(() => {
      var b;
      (b = a.body) == null || b.classList.add("afma-on-show");
    });
  }
  var kh = class extends bh {
    constructor(a) {
      super();
      this.pingback = a;
      this.h = new Ff();
      this.P = new Eg();
      this.l = !1;
    }
    isVariableDurationAllowed() {
      var a, b;
      return (b =
        (a = this.environmentData) == null
          ? void 0
          : a.variableDurationAllowed) != null
        ? b
        : !0;
    }
    close() {
      Qg(this.i);
    }
    u(a) {
      super.u(a);
      if (a.args.adParameters) {
        let e = JSON.parse(a.args.adParameters);
        this.o = new qd(
          e.youtubeVideoId,
          e.title,
          e.isTrueView,
          e.isVideoUnlisted
        );
        this.R = new pd(e.channelId, e.channelTitle);
        this.isSkippable = e.isSkippable;
        a = JSON.parse(a.args.adParameters);
        if (a.infoCards && a.infoCards.length > 0)
          for (let f of a.infoCards)
            if (((a = f), a.showInCta && a.actionTargetUrl)) {
              this.clickThruUri = a.actionTargetUrl;
              let g;
              (g = this.h) == null ||
                g.h(W, { type: "TimingEvent", key: "sma_ct_ic" });
              this.l = !0;
              a.actionTitle && this.h.h(Ye, a.actionTitle);
              break;
            }
      }
      var b, c;
      this.clickThruUri =
        ((b = this.creativeData) == null ? void 0 : b.clickThruUri) ||
        ((c = this.creativeData) == null ? void 0 : c.clickThruUrl) ||
        this.clickThruUri ||
        void 0;
      var d;
      if ((d = this.creativeData) == null ? 0 : d.clickThruUri) {
        let e;
        (e = this.h) == null ||
          e.h(W, { type: "TimingEvent", key: "sma_ct_cd_uri" });
      } else {
        let e;
        if ((e = this.creativeData) == null ? 0 : e.clickThruUrl) {
          let f;
          (f = this.h) == null ||
            f.h(W, { type: "TimingEvent", key: "sma_ct_cd_url" });
        }
      }
      dh(this);
    }
    H() {
      var a = new Ze(this.j.getCurrentTime(), this.j.A());
      this.h.h($e, a);
    }
    O(a) {
      a.args.code !== 2 && a.resolve();
    }
    I() {
      this.h.h(bf, null);
      this.h.h(af, null);
    }
    D() {
      this.h.h(cf, null);
    }
    G() {
      this.h.h(df, null);
    }
    L() {
      this.h.h(ef, { volume: this.j.i.volume, muted: this.j.i.muted });
    }
    C(a) {
      this.h.h(ff, null);
      super.C(a);
    }
    A(a) {
      super.A(a);
      jh(this);
    }
  };
  var mh = class {
    constructor() {
      this.body = lh;
    }
    dispatchEvent(a, b) {
      this.body.dispatchEvent(new CustomEvent(a, { detail: b }));
    }
  };
  var nh = class {
    constructor() {
      this.h = typeof mys !== "undefined" ? mys.pingback : void 0;
      this.i = 0;
    }
    enabledChannel(a) {
      this.i = a;
      var b;
      (b = this.h) == null || b.tick(43, this.i);
    }
    setSlice(a, b) {
      var c;
      (c = this.h) == null || c.setAttribute(a, b);
    }
    setData(a, b) {
      var c;
      (c = this.h) == null || c.setData(a, b, this.i);
    }
    send(a) {
      var b;
      (b = this.h) == null || b.send(a);
    }
    setDataAndSend(a, b) {
      if (this.h) {
        for (let c in a) a.hasOwnProperty(c) && this.h.setData(c, a[c], this.i);
        this.h.send(b);
      }
    }
    tick(a, b) {
      var c;
      (c = this.h) == null || c.tick(a, this.i, b);
    }
    populateServerPingbackOutput() {}
    flush() {
      return [];
    }
  };
  var oh = class {
    constructor() {
      this.i = !1;
      var a = new nh();
      a.enabledChannel(27);
      this.h = new kh(a);
    }
    isVariableDurationAllowed() {
      return this.h.isVariableDurationAllowed();
    }
    close() {
      this.h.close();
    }
  };
  var lh = document.getElementById("mys-content"),
    $g = new oh();
  if (!$g.i) {
    var ph = $g.h,
      qh = new mh();
    ph.body = lh;
    ph.P.resolve(qh);
    var rh = $g.h.h,
      sh = lh;
    rh.i || ((rh.i = sh), Ef(rh));
    Zg();
    $g.i = !0;
  }
  for (
    var th = () => $g, uh = ["mys", "addon", "getSimidCoreAddon"], vh = n, wh;
    uh.length && (wh = uh.shift());

  )
    uh.length || th === void 0
      ? vh[wh] && vh[wh] !== Object.prototype[wh]
        ? (vh = vh[wh])
        : (vh = vh[wh] = {})
      : (vh[wh] = th);
}.call(this));
