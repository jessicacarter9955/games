(function () {
  "use strict";
  var n,
    ca =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            function b() {}
            b.prototype = a;
            return new b();
          },
    da =
      typeof Object.defineProperties == "function"
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          };
  function ea(a) {
    a = [
      "object" == typeof globalThis && globalThis,
      a,
      "object" == typeof window && window,
      "object" == typeof self && self,
      "object" == typeof global && global,
    ];
    for (var b = 0; b < a.length; ++b) {
      var c = a[b];
      if (c && c.Math == Math) return c;
    }
    throw Error("Cannot find global object");
  }
  var fa = ea(this);
  function p(a, b) {
    if (b)
      a: {
        var c = fa;
        a = a.split(".");
        for (var d = 0; d < a.length - 1; d++) {
          var e = a[d];
          if (!(e in c)) break a;
          c = c[e];
        }
        a = a[a.length - 1];
        d = c[a];
        b = b(d);
        b != d &&
          b != null &&
          da(c, a, { configurable: !0, writable: !0, value: b });
      }
  }
  var ha = (function () {
      function a() {
        function c() {}
        new c();
        Reflect.construct(c, [], function () {});
        return new c() instanceof c;
      }
      if (typeof Reflect != "undefined" && Reflect.construct) {
        if (a()) return Reflect.construct;
        var b = Reflect.construct;
        return function (c, d, e) {
          c = b(c, d);
          e && Reflect.setPrototypeOf(c, e.prototype);
          return c;
        };
      }
      return function (c, d, e) {
        e === void 0 && (e = c);
        e = ca(e.prototype || Object.prototype);
        return Function.prototype.apply.call(c, e, d) || e;
      };
    })(),
    ia;
  if (typeof Object.setPrototypeOf == "function") ia = Object.setPrototypeOf;
  else {
    var ja;
    a: {
      var ka = { a: !0 },
        la = {};
      try {
        la.__proto__ = ka;
        ja = la.a;
        break a;
      } catch (a) {}
      ja = !1;
    }
    ia = ja
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var r = ia;
  function u(a, b) {
    a.prototype = ca(b.prototype);
    a.prototype.constructor = a;
    if (r) r(a, b);
    else
      for (var c in b)
        if (c != "prototype")
          if (Object.defineProperties) {
            var d = Object.getOwnPropertyDescriptor(b, c);
            d && Object.defineProperty(a, c, d);
          } else a[c] = b[c];
    a.J = b.prototype;
  }
  function ma(a) {
    var b = 0;
    return function () {
      return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
    };
  }
  function v(a) {
    var b =
      typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
    if (b) return b.call(a);
    if (typeof a.length == "number") return { next: ma(a) };
    throw Error(String(a) + " is not an iterable or ArrayLike");
  }
  function w(a, b) {
    var c;
    b && !b.done && (c = a["return"]) && c.call(a);
  }
  p("Reflect", function (a) {
    return a ? a : {};
  });
  p("Reflect.construct", function () {
    return ha;
  });
  p("Reflect.setPrototypeOf", function (a) {
    return a
      ? a
      : r
      ? function (b, c) {
          try {
            return r(b, c), !0;
          } catch (d) {
            return !1;
          }
        }
      : null;
  });
  p("Symbol", function (a) {
    function b(f) {
      if (this instanceof b) throw new TypeError("Symbol is not a constructor");
      return new c(d + (f || "") + "_" + e++, f);
    }
    function c(f, h) {
      this.h = f;
      da(this, "description", { configurable: !0, writable: !0, value: h });
    }
    if (a) return a;
    c.prototype.toString = function () {
      return this.h;
    };
    var d = "jscomp_symbol_" + ((Math.random() * 1e9) >>> 0) + "_",
      e = 0;
    return b;
  });
  p("Symbol.iterator", function (a) {
    if (a) return a;
    a = Symbol("Symbol.iterator");
    da(Array.prototype, a, {
      configurable: !0,
      writable: !0,
      value: function () {
        return na(ma(this));
      },
    });
    return a;
  });
  function na(a) {
    var b =
        (typeof Iterator != "undefined" &&
        Iterator.prototype &&
        !Iterator.prototype.next
          ? Iterator.prototype
          : null) || Object.prototype,
      c = ca(b);
    c.next = a;
    b[Symbol.iterator] ||
      (c[Symbol.iterator] = function () {
        return this;
      });
    return c;
  }
  p("Object.setPrototypeOf", function (a) {
    return a || r;
  });
  function x(a, b) {
    return Object.prototype.hasOwnProperty.call(a, b);
  }
  p("WeakMap", function (a) {
    function b(k) {
      this.h = (g += Math.random() + 1).toString();
      if (k) {
        k = v(k);
        for (var l; !(l = k.next()).done; ) (l = l.value), this.set(l[0], l[1]);
      }
    }
    function c() {}
    function d(k) {
      var l = typeof k;
      return (l === "object" && k !== null) || l === "function";
    }
    function e(k) {
      if (!x(k, h)) {
        var l = new c();
        da(k, h, { value: l });
      }
    }
    function f(k) {
      var l = Object[k];
      l &&
        (Object[k] = function (m) {
          if (m instanceof c) return m;
          Object.isExtensible(m) && e(m);
          return l(m);
        });
    }
    if (
      (function () {
        if (!a || !Object.seal) return !1;
        try {
          var k = Object.seal({}),
            l = Object.seal({}),
            m = new a([
              [k, 2],
              [l, 3],
            ]);
          if (m.get(k) != 2 || m.get(l) != 3) return !1;
          m.delete(k);
          m.set(l, 4);
          return !m.has(k) && m.get(l) == 4;
        } catch (q) {
          return !1;
        }
      })()
    )
      return a;
    var h = "$jscomp_hidden_" + Math.random();
    f("freeze");
    f("preventExtensions");
    f("seal");
    var g = 0;
    b.prototype.set = function (k, l) {
      if (!d(k)) throw Error("Invalid WeakMap key");
      e(k);
      if (!x(k, h)) throw Error("WeakMap key fail: " + k);
      k[h][this.h] = l;
      return this;
    };
    b.prototype.get = function (k) {
      return d(k) && x(k, h) ? k[h][this.h] : void 0;
    };
    b.prototype.has = function (k) {
      return d(k) && x(k, h) && x(k[h], this.h);
    };
    b.prototype.delete = function (k) {
      return d(k) && x(k, h) && x(k[h], this.h) ? delete k[h][this.h] : !1;
    };
    return b;
  });
  p("Map", function (a) {
    function b() {
      var g = {};
      return (g.l = g.next = g.head = g);
    }
    function c(g, k) {
      var l = g[1];
      return na(function () {
        if (l) {
          for (; l.head != g[1]; ) l = l.l;
          for (; l.next != l.head; )
            return (l = l.next), { done: !1, value: k(l) };
          l = null;
        }
        return { done: !0, value: void 0 };
      });
    }
    function d(g, k) {
      var l = k && typeof k;
      l == "object" || l == "function"
        ? f.has(k)
          ? (l = f.get(k))
          : ((l = "" + ++h), f.set(k, l))
        : (l = "p_" + k);
      var m = g[0][l];
      if (m && x(g[0], l))
        for (g = 0; g < m.length; g++) {
          var q = m[g];
          if ((k !== k && q.key !== q.key) || k === q.key)
            return { id: l, list: m, index: g, entry: q };
        }
      return { id: l, list: m, index: -1, entry: void 0 };
    }
    function e(g) {
      this[0] = {};
      this[1] = b();
      this.size = 0;
      if (g) {
        g = v(g);
        for (var k; !(k = g.next()).done; ) (k = k.value), this.set(k[0], k[1]);
      }
    }
    if (
      (function () {
        if (
          !a ||
          typeof a != "function" ||
          !a.prototype.entries ||
          typeof Object.seal != "function"
        )
          return !1;
        try {
          var g = Object.seal({ x: 4 }),
            k = new a(v([[g, "s"]]));
          if (
            k.get(g) != "s" ||
            k.size != 1 ||
            k.get({ x: 4 }) ||
            k.set({ x: 4 }, "t") != k ||
            k.size != 2
          )
            return !1;
          var l = k.entries(),
            m = l.next();
          if (m.done || m.value[0] != g || m.value[1] != "s") return !1;
          m = l.next();
          return !(
            m.done ||
            m.value[0].x != 4 ||
            m.value[1] != "t" ||
            !l.next().done
          );
        } catch (q) {
          return !1;
        }
      })()
    )
      return a;
    var f = new WeakMap();
    e.prototype.set = function (g, k) {
      g = g === 0 ? 0 : g;
      var l = d(this, g);
      l.list || (l.list = this[0][l.id] = []);
      l.entry
        ? (l.entry.value = k)
        : ((l.entry = {
            next: this[1],
            l: this[1].l,
            head: this[1],
            key: g,
            value: k,
          }),
          l.list.push(l.entry),
          (this[1].l.next = l.entry),
          (this[1].l = l.entry),
          this.size++);
      return this;
    };
    e.prototype.delete = function (g) {
      g = d(this, g);
      return g.entry && g.list
        ? (g.list.splice(g.index, 1),
          g.list.length || delete this[0][g.id],
          (g.entry.l.next = g.entry.next),
          (g.entry.next.l = g.entry.l),
          (g.entry.head = null),
          this.size--,
          !0)
        : !1;
    };
    e.prototype.clear = function () {
      this[0] = {};
      this[1] = this[1].l = b();
      this.size = 0;
    };
    e.prototype.has = function (g) {
      return !!d(this, g).entry;
    };
    e.prototype.get = function (g) {
      return (g = d(this, g).entry) && g.value;
    };
    e.prototype.entries = function () {
      return c(this, function (g) {
        return [g.key, g.value];
      });
    };
    e.prototype.keys = function () {
      return c(this, function (g) {
        return g.key;
      });
    };
    e.prototype.values = function () {
      return c(this, function (g) {
        return g.value;
      });
    };
    e.prototype.forEach = function (g, k) {
      for (var l = this.entries(), m; !(m = l.next()).done; )
        (m = m.value), g.call(k, m[1], m[0], this);
    };
    e.prototype[Symbol.iterator] = e.prototype.entries;
    var h = 0;
    return e;
  });
  function oa(a) {
    if (Object(a) !== a) throw new TypeError("Expected an object");
    return a;
  }
  function pa(a, b, c) {
    oa(a);
    if (typeof b != "function") {
      try {
        var d = a["return"];
        typeof d == "function" && d.call(a);
      } catch (h) {}
      throw new TypeError("callback must be a function");
    }
    b = a.next;
    d = 0;
    for (var e; !(e = oa(b.call(a))).done; ) {
      try {
        var f = c(e.value, d++);
      } catch (h) {
        try {
          w(a, e);
        } catch (g) {}
        throw h;
      }
      if (f) {
        c = a["return"];
        c != null && oa(c.call(a));
        break;
      }
    }
  }
  p("Object.values", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) x(b, d) && c.push(b[d]);
          return c;
        };
  });
  p("Object.is", function (a) {
    return a
      ? a
      : function (b, c) {
          return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c;
        };
  });
  p("Array.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = this;
          d instanceof String && (d = String(d));
          var e = d.length;
          c = c || 0;
          for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
            var f = d[c];
            if (f === b || Object.is(f, b)) return !0;
          }
          return !1;
        };
  });
  p("String.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          if (this == null)
            throw new TypeError(
              "The 'this' value for String.prototype.includes must not be null or undefined"
            );
          if (b instanceof RegExp)
            throw new TypeError(
              "First argument to String.prototype.includes must not be a regular expression"
            );
          return this.indexOf(b, c || 0) !== -1;
        };
  });
  p("Array.from", function (a) {
    return a
      ? a
      : function (b, c, d) {
          c =
            c != null
              ? c
              : function (g) {
                  return g;
                };
          var e = [],
            f =
              typeof Symbol != "undefined" &&
              Symbol.iterator &&
              b[Symbol.iterator];
          if (typeof f == "function") {
            b = f.call(b);
            for (var h = 0; !(f = b.next()).done; )
              e.push(c.call(d, f.value, h++));
          } else
            for (f = b.length, h = 0; h < f; h++) e.push(c.call(d, b[h], h));
          return e;
        };
  });
  p("Object.entries", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) x(b, d) && c.push([d, b[d]]);
          return c;
        };
  });
  p("Number.isFinite", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b !== "number"
            ? !1
            : !isNaN(b) && b !== Infinity && b !== -Infinity;
        };
  });
  p("Number.MAX_SAFE_INTEGER", function () {
    return 9007199254740991;
  });
  p("Number.MIN_SAFE_INTEGER", function () {
    return -9007199254740991;
  });
  function qa(a, b) {
    a instanceof String && (a += "");
    var c = 0,
      d = !1;
    return na(function () {
      if (!d && c < a.length) {
        var e = c++;
        return { value: b(e, a[e]), done: !1 };
      }
      d = !0;
      return { done: !0, value: void 0 };
    });
  }
  p("Array.prototype.entries", function (a) {
    return a
      ? a
      : function () {
          return qa(this, function (b, c) {
            return [b, c];
          });
        };
  });
  p("Number.isNaN", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b === "number" && isNaN(b);
        };
  });
  p("Array.prototype.keys", function (a) {
    return a
      ? a
      : function () {
          return qa(this, function (b) {
            return b;
          });
        };
  });
  p("Array.prototype.values", function (a) {
    return a
      ? a
      : function () {
          return qa(this, function (b, c) {
            return c;
          });
        };
  });
  p("Iterator.prototype.forEach", function (a) {
    return (
      a ||
      function (b) {
        pa(this, b, function (c, d) {
          b(c, d);
        });
      }
    );
  }); /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var y = this || self;
  function ra(a) {
    return a;
  }
  var sa,
    ta = typeof String.prototype.isWellFormed === "function",
    ua = typeof TextEncoder !== "undefined";
  function va(a) {
    y.setTimeout(function () {
      throw a;
    }, 0);
  }
  var wa, xa;
  a: {
    for (var ya = ["CLOSURE_FLAGS"], za = y, Aa = 0; Aa < ya.length; Aa++)
      if (((za = za[ya[Aa]]), za == null)) {
        xa = null;
        break a;
      }
    xa = za;
  }
  var Ba = xa && xa[748402147];
  wa = Ba != null ? Ba : !0;
  var Ca = Array.prototype.indexOf
    ? function (a, b) {
        return Array.prototype.indexOf.call(a, b, void 0);
      }
    : function (a, b) {
        if (typeof a === "string")
          return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
        return -1;
      };
  function Da(a) {
    Da[" "](a);
    return a;
  }
  Da[" "] = function () {};
  var Ea = {},
    Fa = null;
  function Ga(a) {
    var b = 2;
    b === void 0 && (b = 0);
    if (!Fa) {
      Fa = {};
      for (
        var c =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
              ""
            ),
          d = ["+/=", "+/", "-_=", "-_.", "-_"],
          e = 0;
        e < 5;
        e++
      ) {
        var f = c.concat(d[e].split(""));
        Ea[e] = f;
        for (var h = 0; h < f.length; h++) {
          var g = f[h];
          Fa[g] === void 0 && (Fa[g] = h);
        }
      }
    }
    b = Ea[b];
    c = Array(Math.floor(a.length / 3));
    d = b[64] || "";
    for (e = f = 0; f < a.length - 2; f += 3) {
      var k = a[f],
        l = a[f + 1];
      g = a[f + 2];
      h = b[k >> 2];
      k = b[((k & 3) << 4) | (l >> 4)];
      l = b[((l & 15) << 2) | (g >> 6)];
      g = b[g & 63];
      c[e++] = h + k + l + g;
    }
    h = 0;
    g = d;
    switch (a.length - f) {
      case 2:
        (h = a[f + 1]), (g = b[(h & 15) << 2] || d);
      case 1:
        (a = a[f]), (c[e] = b[a >> 2] + b[((a & 3) << 4) | (h >> 4)] + g + d);
    }
    return c.join("");
  }
  function Ha(a, b) {
    a.__closure__error__context__984382 ||
      (a.__closure__error__context__984382 = {});
    a.__closure__error__context__984382.severity = b;
  }
  var Ia = void 0;
  function Ja(a) {
    a = Error(a);
    Ha(a, "warning");
    return a;
  }
  function Ka(a, b) {
    if (a != null) {
      var c;
      var d = (c = Ia) != null ? c : (Ia = {});
      c = d[a] || 0;
      c >= b || ((d[a] = c + 1), (a = Error()), Ha(a, "incident"), va(a));
    }
  }
  var La = typeof Symbol === "function" && typeof Symbol() === "symbol";
  function A(a, b, c) {
    return typeof Symbol === "function" && typeof Symbol() === "symbol"
      ? (c === void 0 ? 0 : c) && Symbol.for && a
        ? Symbol.for(a)
        : a != null
        ? Symbol(a)
        : Symbol()
      : b;
  }
  var Ma = A("jas", void 0, !0),
    Na = A(void 0, "0di"),
    B = A(void 0, "1oa"),
    Oa = A(void 0, "0ubsb"),
    Pa = A(void 0, "0actk"),
    D = A("m_m", "I", !0);
  var Qa = { F: { value: 0, configurable: !0, writable: !0, enumerable: !1 } },
    Ra = Object.defineProperties,
    F = La ? Ma : "F",
    Sa,
    Ta = [];
  G(Ta, 7);
  Sa = Object.freeze(Ta);
  function H(a, b) {
    La || F in a || Ra(a, Qa);
    a[F] |= b;
  }
  function G(a, b) {
    La || F in a || Ra(a, Qa);
    a[F] = b;
  }
  function I(a) {
    H(a, 34);
    return a;
  }
  function Ua(a) {
    H(a, 8192);
    return a;
  }
  function Va(a) {
    H(a, 32);
    return a;
  }
  var J = {};
  function K(a, b) {
    return b === void 0
      ? a.h !== L && !!(2 & (a.i[F] | 0))
      : !!(2 & b) && a.h !== L;
  }
  var L = {};
  function Wa(a, b, c) {
    this.h = a;
    this.j = b;
    this.u = c;
  }
  Wa.prototype.next = function () {
    var a = this.h.next();
    a.done || (a.value = this.j.call(this.u, a.value));
    return a;
  };
  Wa.prototype[Symbol.iterator] = function () {
    return this;
  };
  Object.freeze({});
  function Xa(a, b, c) {
    var d = b & 128 ? 0 : -1,
      e = a.length,
      f;
    if ((f = !!e))
      (f = a[e - 1]),
        (f = f != null && typeof f === "object" && f.constructor === Object);
    var h = e + (f ? -1 : 0);
    for (b = b & 128 ? 1 : 0; b < h; b++) c(b - d, a[b]);
    if (f) {
      a = a[e - 1];
      for (var g in a) !isNaN(g) && c(+g, a[g]);
    }
  }
  var Ya = typeof y.BigInt === "function" && typeof y.BigInt(0) === "bigint";
  var Za = Number.MIN_SAFE_INTEGER.toString(),
    $a = Ya ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
    ab = Number.MAX_SAFE_INTEGER.toString(),
    bb = Ya ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;
  function cb(a, b) {
    if (a.length > b.length) return !1;
    if (a.length < b.length || a === b) return !0;
    for (var c = 0; c < a.length; c++) {
      var d = a[c],
        e = b[c];
      if (d > e) return !1;
      if (d < e) return !0;
    }
  }
  var db = 0,
    eb = 0,
    fb;
  var gb = Number.isFinite;
  function hb(a) {
    if (typeof a !== "number")
      throw Error(
        "Value of float/double field must be a number, found " +
          typeof a +
          ": " +
          a
      );
    return a;
  }
  function ib(a) {
    if (a == null || typeof a === "number") return a;
    if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a);
  }
  function jb(a) {
    if (typeof a !== "number") throw Ja("int32");
    if (!gb(a)) throw Ja("int32");
    return a | 0;
  }
  function kb(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return gb(a) ? a | 0 : void 0;
  }
  function lb(a) {
    return a == null || typeof a === "string" ? a : void 0;
  }
  function mb(a, b, c, d) {
    if (a != null && a[D] === J) return a;
    if (!Array.isArray(a))
      return (
        c
          ? d & 2
            ? ((a = b[Na]) || ((a = new b()), I(a.i), (a = b[Na] = a)), (b = a))
            : (b = new b())
          : (b = void 0),
        b
      );
    c = a[F] | 0;
    d = c | (d & 32) | (d & 2);
    d !== c && G(a, d);
    return new b(a);
  }
  function nb(a, b, c) {
    a = b ? jb(a) : kb(a);
    return a == null ? (c ? 0 : void 0) : a | 0;
  }
  function ob(a) {
    return a;
  }
  var pb = {},
    qb = (function () {
      try {
        var a = function () {
          return ha(Map, [], this.constructor);
        };
        u(a, Map);
        Da(new a());
        return !1;
      } catch (b) {
        return !0;
      }
    })();
  function M() {
    this.h = new Map();
  }
  n = M.prototype;
  n.get = function (a) {
    return this.h.get(a);
  };
  n.set = function (a, b) {
    this.h.set(a, b);
    this.size = this.h.size;
    return this;
  };
  n.delete = function (a) {
    a = this.h.delete(a);
    this.size = this.h.size;
    return a;
  };
  n.clear = function () {
    this.h.clear();
    this.size = this.h.size;
  };
  n.has = function (a) {
    return this.h.has(a);
  };
  n.entries = function () {
    return this.h.entries();
  };
  n.keys = function () {
    return this.h.keys();
  };
  n.values = function () {
    return this.h.values();
  };
  n.forEach = function (a, b) {
    return this.h.forEach(a, b);
  };
  M.prototype[Symbol.iterator] = function () {
    return this.entries();
  };
  var N = (function () {
    function a() {
      return ha(Map, [], this.constructor);
    }
    if (qb)
      return (
        Object.setPrototypeOf(M.prototype, Map.prototype),
        Object.defineProperties(M.prototype, {
          size: { value: 0, configurable: !0, enumerable: !0, writable: !0 },
        }),
        M
      );
    u(a, Map);
    return a;
  })();
  function rb(a) {
    return a;
  }
  function O(a, b, c, d) {
    c = c === void 0 ? rb : c;
    d = d === void 0 ? rb : d;
    var e = N.call(this) || this;
    e.m = a[F] | 0;
    e.o = b;
    e.v = c;
    e.B = e.o ? sb : d;
    for (var f = 0; f < a.length; f++) {
      var h = a[f],
        g = c(h[0], !1, !0),
        k = h[1];
      b
        ? k === void 0 && (k = null)
        : (k = d(h[1], !1, !0, void 0, void 0, e.m));
      N.prototype.set.call(e, g, k);
    }
    return e;
  }
  u(O, N);
  function tb(a) {
    if (a.m & 2) throw Error("Cannot mutate an immutable Map");
  }
  function ub(a, b) {
    return Ua(Array.from(N.prototype.entries.call(a), b));
  }
  n = O.prototype;
  n.clear = function () {
    tb(this);
    N.prototype.clear.call(this);
  };
  n.delete = function (a) {
    tb(this);
    return N.prototype.delete.call(this, this.v(a, !0, !1));
  };
  n.entries = function () {
    if (this.o) {
      var a = N.prototype.keys.call(this);
      a = new Wa(a, vb, this);
    } else a = N.prototype.entries.call(this);
    return a;
  };
  n.values = function () {
    if (this.o) {
      var a = N.prototype.keys.call(this);
      a = new Wa(a, O.prototype.get, this);
    } else a = N.prototype.values.call(this);
    return a;
  };
  n.forEach = function (a, b) {
    this.o
      ? N.prototype.forEach.call(this, function (c, d, e) {
          a.call(b, e.get(d), d, e);
        })
      : N.prototype.forEach.call(this, a, b);
  };
  n.set = function (a, b) {
    tb(this);
    a = this.v(a, !0, !1);
    return a == null
      ? this
      : b == null
      ? (N.prototype.delete.call(this, a), this)
      : N.prototype.set.call(this, a, this.B(b, !0, !0, this.o, !1, this.m));
  };
  n.has = function (a) {
    return N.prototype.has.call(this, this.v(a, !1, !1));
  };
  n.get = function (a) {
    a = this.v(a, !1, !1);
    var b = N.prototype.get.call(this, a);
    if (b !== void 0) {
      var c = this.o;
      return c
        ? ((c = this.B(b, !1, !0, c, this.C, this.m)),
          c !== b && N.prototype.set.call(this, a, c),
          c)
        : b;
    }
  };
  O.prototype[Symbol.iterator] = function () {
    return this.entries();
  };
  O.prototype.toJSON = void 0;
  function sb(a, b, c, d, e, f) {
    a = mb(a, d, c, f);
    e && (a = wb(a));
    return a;
  }
  function vb(a) {
    return [a, this.get(a)];
  }
  var xb;
  function yb() {
    return xb || (xb = new O(I([]), void 0, void 0, void 0, pb));
  }
  function zb(a, b, c, d) {
    var e = d !== void 0;
    d = !!d;
    var f = [],
      h = a.length,
      g = 4294967295,
      k = !1,
      l = !!(b & 64),
      m = l ? (b & 128 ? 0 : -1) : void 0;
    if (!(b & 1)) {
      var q = h && a[h - 1];
      q != null && typeof q === "object" && q.constructor === Object
        ? (h--, (g = h))
        : (q = void 0);
      if (l && !(b & 128) && !e) {
        k = !0;
        var t;
        g = ((t = Ab) != null ? t : ob)(g - m, m, a, q, void 0) + m;
      }
    }
    b = void 0;
    for (e = 0; e < h; e++)
      if (((t = a[e]), t != null && (t = c(t, d)) != null))
        if (l && e >= g) {
          var E = e - m,
            C = void 0;
          ((C = b) != null ? C : (b = {}))[E] = t;
        } else f[e] = t;
    if (q)
      for (var z in q)
        (a = q[z]),
          a != null &&
            (a = c(a, d)) != null &&
            ((h = +z),
            (e = void 0),
            l && !Number.isNaN(h) && (e = h + m) < g
              ? (f[e] = a)
              : ((h = void 0), (((h = b) != null ? h : (b = {}))[z] = a)));
    b && (k ? f.push(b) : (f[g] = b));
    return f;
  }
  function Bb(a) {
    a[0] = Cb(a[0]);
    a[1] = Cb(a[1]);
    return a;
  }
  function Cb(a) {
    switch (typeof a) {
      case "number":
        return Number.isFinite(a) ? a : "" + a;
      case "bigint":
        return (Ya ? a >= $a && a <= bb : a[0] === "-" ? cb(a, Za) : cb(a, ab))
          ? Number(a)
          : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          var b = a[F] | 0;
          return a.length === 0 && b & 1 ? void 0 : zb(a, b, Cb);
        }
        if (a != null && a[D] === J) return Db(a);
        if (a instanceof O) return (a = a.size !== 0 ? ub(a, Bb) : void 0), a;
        return;
    }
    return a;
  }
  var Ab;
  function Db(a) {
    a = a.i;
    return zb(a, a[F] | 0, Cb);
  }
  var Eb, Fb;
  function Gb(a) {
    switch (typeof a) {
      case "boolean":
        return Eb || (Eb = [0, void 0, !0]);
      case "number":
        return a > 0
          ? void 0
          : a === 0
          ? Fb || (Fb = [0, void 0])
          : [-a, void 0];
      case "string":
        return [0, a];
      case "object":
        return a;
    }
  }
  function P(a, b, c, d) {
    d = d === void 0 ? 0 : d;
    if (a == null) {
      var e = 32;
      c ? ((a = [c]), (e |= 128)) : (a = []);
      b && (e = (e & -16760833) | ((b & 1023) << 14));
    } else {
      if (!Array.isArray(a)) throw Error("narr");
      e = a[F] | 0;
      if (wa && 1 & e) throw Error("rfarr");
      2048 & e && !(2 & e) && Hb();
      if (e & 256) throw Error("farr");
      if (e & 64) return (e | d) !== e && G(a, e | d), a;
      if (c && ((e |= 128), c !== a[0])) throw Error("mid");
      a: {
        c = a;
        e |= 64;
        var f = c.length;
        if (f) {
          var h = f - 1,
            g = c[h];
          if (g != null && typeof g === "object" && g.constructor === Object) {
            b = e & 128 ? 0 : -1;
            h -= b;
            if (h >= 1024) throw Error("pvtlmt");
            for (var k in g)
              (f = +k), f < h && ((c[f + b] = g[k]), delete g[k]);
            e = (e & -16760833) | ((h & 1023) << 14);
            break a;
          }
        }
        if (b) {
          k = Math.max(b, f - (e & 128 ? 0 : -1));
          if (k > 1024) throw Error("spvt");
          e = (e & -16760833) | ((k & 1023) << 14);
        }
      }
    }
    G(a, e | 64 | d);
    return a;
  }
  function Hb() {
    if (wa) throw Error("carr");
    Ka(Pa, 5);
  }
  function Ib(a, b) {
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      var c = a[F] | 0;
      return a.length === 0 && c & 1 ? void 0 : Jb(a, c, b);
    }
    if (a != null && a[D] === J) return Kb(a);
    if (a instanceof O) {
      b = a.m;
      if (b & 2) return a;
      if (a.size) {
        c = I(ub(a));
        if (a.o)
          for (a = 0; a < c.length; a++) {
            var d = c[a],
              e = d[1];
            e == null || typeof e !== "object"
              ? (e = void 0)
              : e != null && e[D] === J
              ? (e = Kb(e))
              : Array.isArray(e)
              ? (e = Jb(e, e[F] | 0, !!(b & 32)))
              : (e = void 0);
            d[1] = e;
          }
        return c;
      }
    }
  }
  function Jb(a, b, c) {
    if (b & 2) return a;
    !c || 4096 & b || 16 & b
      ? (a = Q(a, b, !1, c && !(b & 16)))
      : (H(a, 34), b & 4 && Object.freeze(a));
    return a;
  }
  function Lb(a, b, c) {
    a = new a.constructor(b);
    c && (a.h = L);
    a.j = L;
    return a;
  }
  function Kb(a) {
    var b = a.i,
      c = b[F] | 0;
    return K(a, c) ? a : Mb(a, b, c) ? Lb(a, b) : Q(b, c);
  }
  function Nb(a) {
    var b = a.i,
      c = b[F] | 0;
    return Mb(a, b, c) ? Lb(a, b, !0) : new a.constructor(Q(b, c, !1));
  }
  function Q(a, b, c, d) {
    d != null || (d = !!(34 & b));
    a = zb(a, b, Ib, d);
    d = 32;
    c && (d |= 2);
    b = (b & 16769217) | d;
    G(a, b);
    return a;
  }
  function wb(a) {
    var b = a.i,
      c = b[F] | 0;
    return K(a, c)
      ? Mb(a, b, c)
        ? Lb(a, b, !0)
        : new a.constructor(Q(b, c, !1))
      : a;
  }
  function Ob(a) {
    if (a.h !== L) return !1;
    var b = a.i;
    b = Q(b, b[F] | 0);
    H(b, 2048);
    a.i = b;
    a.h = void 0;
    a.j = void 0;
    return !0;
  }
  function R(a) {
    if (!Ob(a) && K(a, a.i[F] | 0)) throw Error();
  }
  function Pb(a, b) {
    b === void 0 && (b = a[F] | 0);
    b & 32 && !(b & 4096) && G(a, b | 4096);
  }
  function Mb(a, b, c) {
    return c & 2
      ? !0
      : c & 32 && !(c & 4096)
      ? (G(b, c | 2), (a.h = L), !0)
      : !1;
  }
  function Qb(a, b, c, d) {
    a = S(a.i, b, c, d);
    if (a !== null) return a;
  }
  function S(a, b, c, d) {
    if (b === -1) return null;
    var e = b + (c ? 0 : -1),
      f = a.length - 1;
    if (!(f < 1 + (c ? 0 : -1))) {
      if (e >= f) {
        var h = a[f];
        if (h != null && typeof h === "object" && h.constructor === Object) {
          c = h[b];
          var g = !0;
        } else if (e === f) c = h;
        else return;
      } else c = a[e];
      if (d && c != null) {
        d = d(c);
        if (d == null) return d;
        if (!Object.is(d, c)) return g ? (h[b] = d) : (a[e] = d), d;
      }
      return c;
    }
  }
  function Rb(a, b, c) {
    R(a);
    a = a.i;
    T(a, a[F] | 0, b, c);
  }
  function T(a, b, c, d) {
    var e = c + -1,
      f = a.length - 1;
    if (f >= 0 && e >= f) {
      var h = a[f];
      if (h != null && typeof h === "object" && h.constructor === Object)
        return (h[c] = d), b;
    }
    if (e <= f) return (a[e] = d), b;
    if (d !== void 0) {
      var g;
      f = (((g = b) != null ? g : (b = a[F] | 0)) >> 14) & 1023 || 536870912;
      c >= f
        ? d != null && ((e = {}), (a[f + -1] = ((e[c] = d), e)))
        : (a[e] = d);
    }
    return b;
  }
  function U(a) {
    var b = Sb;
    var c = a.i;
    var d = c[F] | 0;
    var e = K(a, d);
    a: {
      !e && Ob(a) && ((c = a.i), (d = c[F] | 0));
      var f = S(c, 3);
      a = !1;
      if (f == null) {
        if (e) {
          c = yb();
          break a;
        }
        f = [];
      } else if (f.constructor === O)
        if (f.m & 2 && !e) f = ub(f);
        else {
          c = f;
          break a;
        }
      else Array.isArray(f) ? (a = !!((f[F] | 0) & 2)) : (f = []);
      if (e) {
        if (!f.length) {
          c = yb();
          break a;
        }
        a || ((a = !0), I(f));
      } else if (a) {
        a = !1;
        Ua(f);
        f = Array.prototype.slice.call(f);
        for (var h = 0; h < f.length; h++) {
          var g = (f[h] = Array.prototype.slice.call(f[h]));
          Array.isArray(g[1]) && (g[1] = I(g[1]));
        }
        f = Ua(f);
      }
      !a && d & 32 && Va(f);
      f = new O(f, b, nb, void 0);
      d = T(c, d, 3, f);
      a || Pb(c, d);
      c = f;
    }
    !e && b && (c.C = !0);
    return c;
  }
  function Ub(a, b) {
    R(a);
    var c = a.i;
    Vb(c, c[F] | 0, b, 0);
    return a;
  }
  function Wb(a, b, c, d) {
    R(a);
    a = a.i;
    var e = a[F] | 0;
    if (d == null) {
      var f = Xb(a);
      if (Yb(f, a, e, c) === b) f.set(c, 0);
      else return;
    } else e = Vb(a, e, c, b);
    T(a, e, b, d);
  }
  function Zb(a, b) {
    a = a.i;
    var c = V;
    return Yb(Xb(a), a, void 0, c) === b ? b : -1;
  }
  function Xb(a) {
    if (La) {
      var b;
      return (b = a[B]) != null ? b : (a[B] = new Map());
    }
    if (B in a) return a[B];
    b = new Map();
    Object.defineProperty(a, B, { value: b });
    return b;
  }
  function Vb(a, b, c, d) {
    var e = Xb(a),
      f = Yb(e, a, b, c);
    f !== d && (f && (b = T(a, b, f)), e.set(c, d));
    return b;
  }
  function Yb(a, b, c, d) {
    var e = a.get(d);
    if (e != null) return e;
    for (var f = (e = 0); f < d.length; f++) {
      var h = d[f];
      S(b, h) != null && (e !== 0 && (c = T(b, c, e)), (e = h));
    }
    a.set(d, e);
    return e;
  }
  function $b(a, b, c, d, e, f, h) {
    e = e && e !== 4 ? (e !== 1 && (a ? K(a, c) : 2 & c) ? 1 : e) : 4;
    f = !!f || e === 3;
    var g = !!h && !(a ? K(a, c) : 2 & c);
    (e === 2 || g) && a && Ob(a) && ((b = a.i), (c = b[F] | 0));
    a = S(b, 1);
    h = Array.isArray(a) ? a : Sa;
    var k = h === Sa ? 7 : h[F] | 0;
    a = k;
    2 & c && (a |= 2);
    var l = a | 1;
    if ((a = !(4 & l))) {
      var m = h,
        q = c,
        t = !!(2 & l);
      t && (q |= 2);
      for (var E = !t, C = !0, z = 0, aa = 0; z < m.length; z++) {
        var ba = mb(m[z], d, !1, q);
        if (ba instanceof d) {
          if (!t) {
            var Tb = K(ba);
            E && (E = !Tb);
            C && (C = Tb);
          }
          m[aa++] = ba;
        }
      }
      aa < z && (m.length = aa);
      l |= 4;
      l = C ? l & -4097 : l | 4096;
      l = E ? l | 8 : l & -9;
    }
    l !== k && (G(h, l), 2 & l && Object.freeze(h));
    if (
      g &&
      !(
        8 & l ||
        (!h.length &&
          (e === 1 || (e !== 4 ? 0 : 2 & l || (!(16 & l) && 32 & c))))
      )
    ) {
      if ((2 & l && 4 & l) || 256 & l)
        (h = Array.prototype.slice.call(h)),
          (l = ac(l, c)),
          (c = T(b, c, 1, h));
      d = h;
      g = l;
      for (k = 0; k < d.length; k++)
        (m = d[k]), (l = wb(m)), m !== l && (d[k] = l);
      g |= 8;
      l = g = d.length ? g | 4096 : g & -4097;
      G(h, l);
    }
    d = h;
    g = h = l;
    (k = (!!(2 & h) && !!(4 & h)) || !!(256 & h)) &&
      e === 2 &&
      ((d = Array.prototype.slice.call(d)),
      (g = 0),
      (h = ac(h, c)),
      (c = T(b, c, 1, d)),
      (k = !1));
    k ||
      (e === 1 || (e !== 4 ? 0 : 2 & h || (!(16 & h) && 32 & c))
        ? ((h |=
            !d.length || (a && !(4096 & h)) || (32 & c && !(4096 & h || 16 & h))
              ? 2
              : 256),
          h !== g && G(d, h),
          Object.freeze(d))
        : (f || (h |= 16), h !== g && G(d, h)));
    2 & h || !(4096 & h || 16 & h) || Pb(b, c);
    return d;
  }
  function ac(a, b) {
    var c;
    2 & b ? (c = a | 2) : (c = a & -3);
    a = c;
    return a & -273;
  }
  function bc(a, b) {
    var c = cc;
    R(a);
    var d = a.i;
    a = $b(a, d, d[F] | 0, c, 2, !0);
    b = b != null ? b : new c();
    a.push(b);
    var e = (c = a === Sa ? 7 : a[F] | 0);
    (b = K(b)) ? ((c &= -9), a.length === 1 && (c &= -4097)) : (c |= 4096);
    c !== e && G(a, c);
    b || Pb(d);
  }
  function dc(a) {
    var b = b === void 0 ? 0 : b;
    a = kb(Qb(a, 6));
    return a != null ? a : b;
  }
  function ec(a, b, c, d) {
    if (d != null && typeof d !== "string") throw Error();
    Wb(a, b, c, d);
  }
  function fc() {
    this.h = [];
  }
  fc.prototype.length = function () {
    return this.h.length;
  };
  fc.prototype.end = function () {
    var a = this.h;
    this.h = [];
    return a;
  };
  function W(a, b) {
    for (; b > 127; ) a.h.push((b & 127) | 128), (b >>>= 7);
    a.h.push(b);
  }
  function hc(a, b) {
    if (b >= 0) W(a, b);
    else {
      for (var c = 0; c < 9; c++) a.h.push((b & 127) | 128), (b >>= 7);
      a.h.push(1);
    }
  }
  function ic(a, b) {
    a.h.push((b >>> 0) & 255);
    a.h.push((b >>> 8) & 255);
    a.h.push((b >>> 16) & 255);
    a.h.push((b >>> 24) & 255);
  }
  function jc() {
    this.u = [];
    this.j = 0;
    this.h = new fc();
  }
  function kc(a, b) {
    b.length !== 0 && (a.u.push(b), (a.j += b.length));
  }
  function lc(a, b, c, d) {
    if (c != null) {
      W(a.h, b * 8 + 2);
      b = a.h.end();
      kc(a, b);
      b.push(a.j);
      d(c, a);
      c = b.pop();
      for (c = a.j + a.h.length() - c; c > 127; )
        b.push((c & 127) | 128), (c >>>= 7), a.j++;
      b.push(c);
      a.j++;
    }
  }
  function mc() {
    function a() {
      throw Error();
    }
    Object.setPrototypeOf(a, a.prototype);
    return a;
  }
  var nc = mc(),
    oc = mc(),
    pc = mc(),
    qc = mc(),
    rc = mc();
  function X(a, b, c) {
    this.i = P(a, b, c, 2048);
  }
  X.prototype.toJSON = function () {
    var a = Db(this);
    return a;
  };
  X.prototype[D] = J;
  X.prototype.toString = function () {
    return this.i.toString();
  };
  function sc(a, b) {
    this.h = a;
    a = ra(nc);
    this.j = (!!a && b === a) || !1;
  }
  function tc(a) {
    var b = b === void 0 ? nc : b;
    return new sc(a, b);
  }
  function uc(a, b, c, d, e) {
    lc(a, c, vc(b, d), e);
  }
  var wc = tc(uc),
    xc = tc(uc),
    yc = Symbol(),
    zc = Symbol(),
    Ac,
    Bc;
  function Cc(a) {
    var b = Dc,
      c = Ec,
      d = a[yc];
    if (d) return d;
    d = {};
    d.H = a;
    d.A = Gb(a[0]);
    var e = a[1],
      f = 1;
    e &&
      e.constructor === Object &&
      ((d.D = e),
      (e = a[++f]),
      typeof e === "function" &&
        e.length > 0 &&
        ((d.G = !0),
        Ac != null || (Ac = e),
        Bc != null || (Bc = a[f + 1]),
        (e = a[(f += 2)])));
    for (
      var h = {};
      e && Array.isArray(e) && e.length && typeof e[0] === "number" && e[0] > 0;

    ) {
      for (var g = 0; g < e.length; g++) h[e[g]] = e;
      e = a[++f];
    }
    for (g = 1; e !== void 0; ) {
      typeof e === "number" && ((g += e), (e = a[++f]));
      var k = void 0;
      if (e instanceof sc) var l = e;
      else (l = wc), f--;
      e = void 0;
      if ((e = l) == null ? 0 : e.j) {
        e = a[++f];
        k = a;
        var m = f;
        typeof e === "function" && ((e = e()), (k[m] = e));
        k = e;
      }
      e = a[++f];
      m = g + 1;
      typeof e === "number" && e < 0 && ((m -= e), (e = a[++f]));
      for (; g < m; g++) {
        var q = h[g];
        k ? c(d, g, l, k, q) : b(d, g, l, q);
      }
    }
    return (a[yc] = d);
  }
  function vc(a, b) {
    if (a instanceof X) return a.i;
    if (Array.isArray(a)) return P(a, b[0], b[1]);
  }
  function Dc(a, b, c) {
    a[b] = c.h;
  }
  function Ec(a, b, c, d) {
    var e,
      f,
      h = c.h;
    a[b] = function (g, k, l) {
      return h(g, k, l, f || (f = Cc(d).A), e || (e = Fc(d)));
    };
  }
  function Fc(a) {
    var b = a[zc];
    if (!b) {
      var c = Cc(a);
      b = function (d, e) {
        return Gc(d, e, c);
      };
      a[zc] = b;
    }
    return b;
  }
  function Gc(a, b, c) {
    Xa(a, a[F] | 0, function (d, e) {
      if (e != null) {
        var f = Hc(c, d);
        f ? f(b, e, d) : d < 500 || Ka(Oa, 3);
      }
    });
  }
  function Hc(a, b) {
    var c = a[b];
    if (c) return c;
    if ((c = a.D))
      if ((c = c[b])) {
        c = Array.isArray(c) ? (c[0] instanceof sc ? c : [xc, c]) : [c, void 0];
        var d = c[0].h;
        if ((c = c[1])) {
          var e = Fc(c),
            f = Cc(c).A;
          c = a.G
            ? Bc(f, e)
            : function (h, g, k) {
                return d(h, g, k, f, e);
              };
        } else c = d;
        return (a[b] = c);
      }
  }
  function Ic(a, b) {
    return new sc(a, b);
  }
  var Jc = tc(function (a, b, c, d, e) {
      if (b instanceof O)
        b.forEach(function (g, k) {
          g = P([k, g], d[0], d[1]);
          lc(a, c, g, e);
        });
      else if (Array.isArray(b)) {
        for (var f = 0; f < b.length; f++) {
          var h = b[f];
          Array.isArray(h) && lc(a, c, P(h, d[0], d[1]), e);
        }
        Ua(b);
      }
    }),
    Kc = Ic(function (a, b, c) {
      b = ib(b);
      b != null &&
        (W(a.h, c * 8 + 1),
        (a = a.h),
        (c = fb || (fb = new DataView(new ArrayBuffer(8)))),
        c.setFloat64(0, +b, !0),
        (db = c.getUint32(0, !0)),
        (eb = c.getUint32(4, !0)),
        ic(a, db),
        ic(a, eb));
    }, qc),
    Lc = Ic(function (a, b, c) {
      b = kb(b);
      b != null && b != null && (W(a.h, c * 8), hc(a.h, b));
    }, pc),
    Mc = Ic(function (a, b, c) {
      b = lb(b);
      if (b != null) {
        var d = !1;
        d = d === void 0 ? !1 : d;
        if (ua) {
          if (
            d &&
            (ta
              ? !b.isWellFormed()
              : /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(
                  b
                ))
          )
            throw Error("Found an unpaired surrogate");
          b = (sa || (sa = new TextEncoder())).encode(b);
        } else {
          for (
            var e = 0, f = new Uint8Array(3 * b.length), h = 0;
            h < b.length;
            h++
          ) {
            var g = b.charCodeAt(h);
            if (g < 128) f[e++] = g;
            else {
              if (g < 2048) f[e++] = (g >> 6) | 192;
              else {
                if (g >= 55296 && g <= 57343) {
                  if (g <= 56319 && h < b.length) {
                    var k = b.charCodeAt(++h);
                    if (k >= 56320 && k <= 57343) {
                      g = (g - 55296) * 1024 + k - 56320 + 65536;
                      f[e++] = (g >> 18) | 240;
                      f[e++] = ((g >> 12) & 63) | 128;
                      f[e++] = ((g >> 6) & 63) | 128;
                      f[e++] = (g & 63) | 128;
                      continue;
                    } else h--;
                  }
                  if (d) throw Error("Found an unpaired surrogate");
                  g = 65533;
                }
                f[e++] = (g >> 12) | 224;
                f[e++] = ((g >> 6) & 63) | 128;
              }
              f[e++] = (g & 63) | 128;
            }
          }
          b = e === f.length ? f : f.subarray(0, e);
        }
        W(a.h, c * 8 + 2);
        W(a.h, b.length);
        kc(a, a.h.end());
        kc(a, b);
      }
    }, oc),
    Nc,
    Oc = void 0;
  Oc = Oc === void 0 ? nc : Oc;
  Nc = new sc(function (a, b, c, d, e) {
    if (Array.isArray(b)) {
      for (var f = 0; f < b.length; f++) {
        var h = e;
        lc(a, c, vc(b[f], d), h);
      }
      a = b[F] | 0;
      a & 1 || G(b, a | 1);
    }
  }, Oc);
  var Pc = Ic(function (a, b, c) {
    b = kb(b);
    b != null && ((b = parseInt(b, 10)), W(a.h, c * 8), hc(a.h, b));
  }, rc);
  function cc(a) {
    this.i = P(a, void 0, void 0, 2048);
  }
  u(cc, X);
  cc.prototype.clearValue = function () {
    return Ub(this, Qc);
  };
  var Rc = [1, 2, 3],
    Qc = [4, 5];
  var Sc = [0, Rc, Qc, Pc, -1, Mc, Kc, Mc, Lc];
  function Sb(a) {
    this.i = P(a, void 0, void 0, 2048);
  }
  u(Sb, X);
  Sb.prototype.clearValue = function () {
    return Ub(this, V);
  };
  var V = [1, 2];
  var Tc = [0, V, Kc, Mc];
  function Uc(a) {
    this.i = P(a, void 0, void 0, 2048);
  }
  u(Uc, X);
  function Vc(a) {
    var b = a.i;
    return $b(a, b, b[F] | 0, cc, void 0, !1, !0);
  }
  var Wc = (function (a) {
    return function (b) {
      if (b == null || b == "") b = new a();
      else {
        b = JSON.parse(b);
        if (!Array.isArray(b)) throw Error("dnarr");
        b = new a(Va(b));
      }
      return b;
    };
  })(Uc);
  var Xc = (function (a) {
    return function (b) {
      var c = new jc();
      Gc(b.i, c, Cc(a));
      kc(c, c.h.end());
      b = new Uint8Array(c.j);
      for (var d = c.u, e = d.length, f = 0, h = 0; h < e; h++) {
        var g = d[h];
        b.set(g, f);
        f += g.length;
      }
      c.u = [b];
      return b;
    };
  })([0, Nc, Sc, 1, Jc, [!0, Lc, Tc]]);
  function Yc(a) {
    a = a === void 0 ? document : a;
    return a.createElement("img");
  }
  function Zc(a, b, c, d) {
    d = d === void 0 ? !1 : d;
    a.google_image_requests || (a.google_image_requests = []);
    var e = Yc(a.document);
    if (c) {
      var f = function () {
        if (c) {
          var h = a.google_image_requests,
            g = Ca(h, e);
          g >= 0 && Array.prototype.splice.call(h, g, 1);
        }
        typeof e.removeEventListener === "function" &&
          e.removeEventListener("load", f, !1);
        typeof e.removeEventListener === "function" &&
          e.removeEventListener("error", f, !1);
      };
      typeof e.addEventListener === "function" &&
        e.addEventListener("load", f, !1);
      typeof e.addEventListener === "function" &&
        e.addEventListener("error", f, !1);
    }
    d && (e.attributionSrc = "");
    e.src = b;
    a.google_image_requests.push(e);
  }
  function $c(a) {
    a = "https://pagead2.googlesyndication.com/pagead/gen_204?id=mys&d=" + a;
    var b = window;
    var c = c === void 0 ? !1 : c;
    var d = d === void 0 ? !1 : d;
    b.fetch
      ? ((c = {
          keepalive: !0,
          credentials: "include",
          redirect: "follow",
          method: "get",
          mode: "no-cors",
        }),
        d &&
          ((c.mode = "cors"),
          "setAttributionReporting" in XMLHttpRequest.prototype
            ? (c.attributionReporting = {
                eventSourceEligible: "true",
                triggerEligible: "false",
              })
            : (c.headers = {
                "Attribution-Reporting-Eligible": "event-source",
              })),
        b.fetch(a, c))
      : Zc(b, a, c === void 0 ? !1 : c, d === void 0 ? !1 : d);
  }
  function ad(a) {
    if (typeof mys === "undefined") return !1;
    var b, c;
    return (c = (b = mys.pingbackChannels) == null ? void 0 : b.includes(a)) !=
      null
      ? c
      : !1;
  }
  function bd(a, b, c) {
    var d = new cc();
    if (typeof a === "number") {
      if (a != null) {
        if (!gb(a)) throw Ja("enum");
        a |= 0;
      }
      Wb(d, 2, Rc, a);
    } else ec(d, 3, Rc, a);
    typeof b === "number"
      ? Wb(d, 4, Qc, b == null ? b : hb(b))
      : ec(d, 5, Qc, b);
    Rb(d, 6, c == null ? c : jb(c));
    return d;
  }
  function cd(a) {
    var b = new Sb();
    typeof a === "number" ? Wb(b, 1, V, a == null ? a : hb(a)) : ec(b, 2, V, a);
    return b;
  }
  function dd() {
    this.j = Date.now();
    this.h = new Uc();
  }
  n = dd.prototype;
  n.init = function (a, b, c, d, e, f) {
    if (d) {
      b = v(d);
      d = b.next();
      try {
        for (; !d.done; d = b.next()) {
          var h = v(d.value),
            g = h.next().value,
            k = h.next().value;
          this.setSlice(g, k);
        }
      } finally {
        w(b, d);
      }
    }
    a && this.setSlice(10, a);
    c && this.setSlice(11, c);
    e && this.setSlice(12, e);
    if (f) {
      a = v(f);
      c = a.next();
      try {
        for (; !c.done; c = a.next()) {
          var l = v(c.value),
            m = l.next().value,
            q = l.next().value,
            t = l.next().value;
          this.setData(m, q, t);
        }
      } finally {
        w(a, c);
      }
    }
    l = Nb(this.h);
    Rb(this.h, 1);
    ed(l);
  };
  n.init2 = function (a, b) {
    if (a) {
      a = v(a);
      var c = a.next();
      try {
        for (; !c.done; c = a.next()) {
          var d = v(c.value),
            e = d.next().value,
            f = d.next().value;
          this.setSlice(e, f);
        }
      } finally {
        w(a, c);
      }
    }
    if (b) {
      b = v(b);
      d = b.next();
      try {
        for (; !d.done; d = b.next()) {
          var h = v(d.value),
            g = h.next().value,
            k = h.next().value,
            l = h.next().value;
          this.setData(g, k, l);
        }
      } finally {
        w(b, d);
      }
    }
    h = Nb(this.h);
    Rb(this.h, 1);
    ed(h);
  };
  n.rely = function (a) {
    a = Wc(a);
    var b = this.h;
    R(b);
    b = b.i;
    var c = b[F] | 0,
      d = S(b, 3);
    d instanceof O && !(d instanceof O && d.m & 2)
      ? d.clear()
      : d != null && T(b, c, 3);
    b = v(U(a));
    c = b.next();
    try {
      for (; !c.done; c = b.next()) {
        var e = v(c.value),
          f = e.next().value,
          h = e.next().value;
        d = f;
        var g = h;
        U(this.h).set(d, Nb(g));
      }
    } finally {
      w(b, c);
    }
    ed(a);
  };
  function ed(a) {
    var b = Vc(a);
    if (b.length !== 0) {
      var c = 100;
      b = v(b);
      var d = b.next();
      try {
        for (; !d.done; d = b.next())
          if (dc(d.value) === 1) {
            c = 0;
            break;
          }
      } finally {
        w(b, d);
      }
      document.readyState === "complete"
        ? fd(a, c)
        : window.addEventListener("load", function () {
            fd(a, c);
          });
    }
  }
  n.getBaseTime = function () {
    return this.j;
  };
  n.getSlices = function () {
    var a = new Map(),
      b = v(U(this.h)),
      c = b.next();
    try {
      for (; !c.done; c = b.next()) {
        var d = v(c.value),
          e = d.next().value,
          f = d.next().value,
          h = e,
          g = f,
          k = g,
          l = Zb(g, 1);
        if (Qb(k, l, void 0, ib) != null) {
          k = a;
          var m = k.set,
            q = void 0,
            t = g,
            E = Zb(g, 1);
          var C = (q = Qb(t, E, void 0, ib)) != null ? q : 0;
          m.call(k, h, C);
        } else {
          k = a;
          var z = k.set;
          q = void 0;
          t = g;
          var aa = Zb(g, 2);
          var ba = (q = lb(Qb(t, aa))) != null ? q : "";
          z.call(k, h, ba);
        }
      }
    } finally {
      w(b, c);
    }
    return a;
  };
  n.setSlice = function (a, b) {
    U(this.h).set(a, cd(b));
  };
  n.tick = function (a, b, c) {
    if (ad(b)) {
      var d = this.h;
      a = bd(a, Date.now() - this.j, b);
      bc(d, a);
      this.send(c);
    }
  };
  n.setData = function (a, b, c) {
    if (ad(c)) {
      var d = this.h;
      a = bd(a, b, c);
      bc(d, a);
    }
  };
  n.setAttribute = function (a, b) {
    var c = U(this.h);
    typeof a === "number" && c.set(a, cd(b));
  };
  n.send = function (a) {
    var b = Vc(this.h);
    if (b.length) {
      var c = Nb(this.h);
      Rb(this.h, 1);
      if (a == null) {
        a = !1;
        b = v(b);
        var d = b.next();
        try {
          for (; !d.done; d = b.next())
            if (dc(d.value) === 1) {
              a = !0;
              break;
            }
        } finally {
          w(b, d);
        }
        a = a ? 0 : 100;
      }
      fd(c, a);
    }
  };
  n.report = function (a) {
    $c(a);
  };
  function fd(a, b) {
    b <= 0
      ? $c(Ga(Xc(a)))
      : setTimeout(function () {
          $c(Ga(Xc(a)));
        }, b);
  }
  if (typeof mys === "undefined" || !mys.pingback)
    for (
      var gd = new dd(), hd = ["mys", "pingback"], Y = y, Z;
      hd.length && (Z = hd.shift());

    )
      hd.length || gd === void 0
        ? Y[Z] && Y[Z] !== Object.prototype[Z]
          ? (Y = Y[Z])
          : (Y = Y[Z] = {})
        : (Y[Z] = gd);
}.call(this));
