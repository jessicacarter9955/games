(() => {
  "use strict";
  var e = {
    28(e) {
      var t = TypeError;
      e.exports = function (e) {
        if ("string" == typeof e) return e;
        throw new t("Argument is not a string");
      };
    },
    960(e) {
      var t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
        n = t + "+/",
        r = t + "-_",
        i = function (e) {
          for (var t = {}, n = 0; n < 64; n++) t[e.charAt(n)] = n;
          return t;
        };
      e.exports = { i2c: n, c2i: i(n), i2cUrl: r, c2iUrl: i(r) };
    },
    224(e) {
      e.exports = function (e, t) {
        return { value: e, done: t };
      };
    },
    578(e) {
      var t = TypeError;
      e.exports = function (e) {
        if (e > 9007199254740991) throw new t("Maximum allowed index exceeded");
        return e;
      };
    },
    213(e) {
      var t = TypeError;
      e.exports = function (e) {
        var n = e && e.alphabet;
        if (void 0 === n || "base64" === n || "base64url" === n)
          return n || "base64";
        throw new t("Incorrect `alphabet` option");
      };
    },
    2(e) {
      e.exports = function (e) {
        return { iterator: e, next: e.next, done: !1 };
      };
    },
    318(e) {
      e.exports = function (e) {
        return null == e;
      };
    },
    475(e) {
      e.exports = function (e, t) {
        var n = "function" == typeof Iterator && Iterator.prototype[e];
        if (n)
          try {
            n.call({ next: null }, t).next();
          } catch (e) {
            return !0;
          }
      };
    },
    164(e) {
      e.exports = {};
    },
    142(e) {
      var t = Math.ceil,
        n = Math.floor;
      e.exports =
        Math.trunc ||
        function (e) {
          var r = +e;
          return (r > 0 ? n : t)(r);
        };
    },
    156(e, t) {
      t.f = Object.getOwnPropertySymbols;
    },
    509(e, t, n) {
      var r = n(318),
        i = TypeError;
      e.exports = function (e) {
        if (r(e)) throw new i("Can't call method on " + e);
        return e;
      };
    },
    420(e) {
      e.exports = function (e) {
        try {
          var t = new Set(),
            n = {
              size: 0,
              has: function () {
                return !0;
              },
              keys: function () {
                return Object.defineProperty({}, "next", {
                  get: function () {
                    return (
                      t.clear(),
                      t.add(4),
                      function () {
                        return { done: !0 };
                      }
                    );
                  },
                });
              },
            },
            r = t[e](n);
          return 1 === r.size && 4 === r.values().next().value;
        } catch (e) {
          return !1;
        }
      };
    },
    579(e, t, n) {
      var r = n(744),
        i = n(611),
        o = RangeError;
      e.exports = function (e) {
        if (void 0 === e) return 0;
        var t = r(e),
          n = i(t);
        if (t !== n) throw new o("Wrong length or index");
        return n;
      };
    },
    744(e, t, n) {
      var r = n(142);
      e.exports = function (e) {
        var t = +e;
        return t != t || 0 === t ? 0 : r(t);
      };
    },
    611(e, t, n) {
      var r = n(744),
        i = Math.min;
      e.exports = function (e) {
        var t = r(e);
        return t > 0 ? i(t, 9007199254740991) : 0;
      };
    },
    628(e, t, n) {
      var r = n(509),
        i = Object;
      e.exports = function (e) {
        return i(r(e));
      };
    },
    445(e) {
      var t = TypeError;
      e.exports = function (e, n) {
        if (e < n) throw new t("Not enough arguments");
        return e;
      };
    },
  };
  const t = {};
  function n(r) {
    const i = t[r];
    if (void 0 !== i) return i.exports;
    const o = (t[r] = { exports: {} });
    return e[r](o, o.exports, n), o.exports;
  }
  (n.m = e),
    (n.cw = (e) => {
      var t;
      return () => {
        if (e) {
          var n = e;
          (e = 0), (t = { exports: {} }), n.call(t.exports, t, t.exports);
        }
        return t.exports;
      };
    }),
    (() => {
      const e = Object.getPrototypeOf;
      let t;
      n.t = function (r, i) {
        if ((1 & i && (r = this(r)), 8 & i)) return r;
        if ("object" == typeof r && r) {
          if (4 & i && r.__esModule) return r;
          if (16 & i && "function" == typeof r.then) return r;
        }
        const o = Object.create(null);
        n.r(o);
        const s = {};
        t ||= [null, e({}), e([]), e(e)];
        for (
          var a = 2 & i && r;
          ("object" == typeof a || "function" == typeof a) && !~t.indexOf(a);
          a = e(a)
        )
          Object.getOwnPropertyNames(a).forEach((e) => (s[e] = () => r[e]));
        return (s.default = () => r), n.d(o, s), o;
      };
    })(),
    (n.d = (e, t) => {
      for (var r in t)
        n.o(t, r) &&
          !n.o(e, r) &&
          Object.defineProperty(e, r, { enumerable: !0, get: t[r] });
    }),
    (n.f = {}),
    (n.e = (e) =>
      Promise.all(Object.keys(n.f).reduce((t, r) => (n.f[r](e, t), t), []))),
    (n.u = (e) => e + ".bundle.js"),
    (n.o = (e, t) => Object.hasOwn(e, t)),
    (() => {
      const e = {},
        t = "@crazygames/ads:";
      n.l = (r, i, o, s) => {
        if (e[r]) return void e[r].push(i);
        let a, c;
        if (void 0 !== o) {
          const e = document.getElementsByTagName("script");
          for (var d = 0; d < e.length; d++) {
            const n = e[d];
            if (
              n.getAttribute("src") == r ||
              n.getAttribute("data-webpack") == t + o
            ) {
              a = n;
              break;
            }
          }
        }
        a ||
          ((c = !0),
          (a = document.createElement("script")),
          (a.charset = "utf-8"),
          n.nc && a.setAttribute("nonce", n.nc),
          a.setAttribute("data-webpack", t + o),
          (a.src = r)),
          (e[r] = [i]);
        const u = (t, n) => {
            (a.onerror = a.onload = null), clearTimeout(l);
            const i = e[r];
            if (
              (delete e[r],
              a.parentNode?.removeChild(a),
              i?.forEach((e) => e(n)),
              t)
            )
              return t(n);
          },
          l = setTimeout(
            u.bind(null, void 0, { type: "timeout", target: a }),
            12e4
          );
        (a.onerror = u.bind(null, a.onerror)),
          (a.onload = u.bind(null, a.onload)),
          c && document.head.appendChild(a);
      };
    })(),
    (n.r = (e) => {
      Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
        Object.defineProperty(e, "__esModule", { value: !0 });
    }),
    (n.dn = (e) => {
      var t = Object.getOwnPropertyDescriptor(e, "name");
      (!t || (!t.writable && t.configurable)) &&
        Object.defineProperty(e, "name", {
          value: "default",
          configurable: !0,
        });
    }),
    (() => {
      let e;
      globalThis.importScripts && (e = globalThis.location + "");
      const t = globalThis.document;
      if (
        !e &&
        t &&
        ("SCRIPT" === t.currentScript?.tagName.toUpperCase() &&
          (e = t.currentScript.src),
        !e)
      ) {
        const n = t.getElementsByTagName("script");
        if (n.length) {
          let t = n.length - 1;
          for (; t > -1 && (!e || !/^https?:/.test(e)); ) e = n[t--].src;
        }
      }
      if (!e)
        throw new Error(
          "Automatic publicPath is not supported in this browser"
        );
      (e = e.replace(/^blob:|[?#].*$/g, "").replace(/\/[^/]+$/, "/")),
        (n.p = e);
    })(),
    (() => {
      const e = { 792: 0 };
      n.f.j = (t, r) => {
        let i = n.o(e, t) ? e[t] : void 0;
        if (0 !== i)
          if (i) r.push(i[2]);
          else {
            const o = new Promise((n, r) => (i = e[t] = [n, r]));
            r.push((i[2] = o));
            const s = new Error(),
              a = (r) => {
                if (n.o(e, t) && ((i = e[t]), 0 !== i && (e[t] = void 0), i)) {
                  const e = r && ("load" === r.type ? "missing" : r.type),
                    n = r && r.target && r.target.src;
                  (s.message =
                    "Loading chunk " + t + " failed.\n(" + e + ": " + n + ")"),
                    (s.name = "ChunkLoadError"),
                    (s.type = e),
                    (s.request = n),
                    (s.event = r),
                    i[1](s);
                }
              };
            n.l(n.p + n.u(t), a, "chunk-" + t, t);
          }
      };
      const t = (t, r) => {
          let [i, o, s] = r;
          var a,
            c,
            d = 0;
          if (i.some((t) => 0 !== e[t])) {
            for (a in o) n.o(o, a) && (n.m[a] = o[a]);
            if (s) s(n);
          }
          for (t && t(r); d < i.length; d++)
            (c = i[d]), n.o(e, c) && e[c] && e[c][0](), (e[c] = 0);
        },
        r = (globalThis.webpackChunk_crazygames_ads ||= []);
      r.forEach(t.bind(null, 0)), (r.push = t.bind(null, r.push.bind(r)));
    })();
  var r = n.cw(function (e, t) {
      var n = ve(),
        r = Et(),
        i = TypeError;
      e.exports = function (e) {
        if (n(e)) return e;
        throw new i(r(e) + " is not a function");
      };
    }),
    i = n.cw(function (e, t) {
      var n = we(),
        r = String,
        i = TypeError;
      e.exports = function (e) {
        if (n(e)) return e;
        throw new i("Can't set " + r(e) + " as a prototype");
      };
    }),
    o = n.cw(function (e, t) {
      var n = nt().has;
      e.exports = function (e) {
        return n(e), e;
      };
    }),
    s = () => n(28),
    a = n.cw(function (e, t) {
      var n = Ut(),
        r = Le(),
        i = De().f,
        o = n("unscopables"),
        s = Array.prototype;
      void 0 === s[o] && i(s, o, { configurable: !0, value: r(null) }),
        (e.exports = function (e) {
          s[o][e] = !0;
        });
    }),
    c = n.cw(function (e, t) {
      var n = qe(),
        r = TypeError;
      e.exports = function (e, t) {
        if (n(t, e)) return e;
        throw new r("Incorrect invocation");
      };
    }),
    d = n.cw(function (e, t) {
      var n = Ce(),
        r = String,
        i = TypeError;
      e.exports = function (e) {
        if (void 0 === e || n(e)) return e;
        throw new i(r(e) + " is not an object or undefined");
      };
    }),
    u = n.cw(function (e, t) {
      var n = Ce(),
        r = String,
        i = TypeError;
      e.exports = function (e) {
        if (n(e)) return e;
        throw new i(r(e) + " is not an object");
      };
    }),
    l = n.cw(function (e, t) {
      var n = I(),
        r = TypeError;
      e.exports = function (e) {
        if ("Uint8Array" === n(e)) return e;
        throw new r("Argument is not an Uint8Array");
      };
    }),
    p = n.cw(function (e, t) {
      e.exports =
        "undefined" != typeof ArrayBuffer && "undefined" != typeof DataView;
    }),
    f = n.cw(function (e, t) {
      var n = ae(),
        r = W(),
        i = S(),
        o = n.ArrayBuffer,
        s = n.TypeError;
      e.exports =
        (o && r(o.prototype, "byteLength", "get")) ||
        function (e) {
          if ("ArrayBuffer" !== i(e)) throw new s("ArrayBuffer expected");
          return e.byteLength;
        };
    }),
    h = n.cw(function (e, t) {
      var n = ae(),
        r = p(),
        i = f(),
        o = n.DataView;
      e.exports = function (e) {
        if (!r || 0 !== i(e)) return !1;
        try {
          return new o(e), !1;
        } catch (e) {
          return !0;
        }
      };
    }),
    m = n.cw(function (e, t) {
      var n = h(),
        r = TypeError;
      e.exports = function (e) {
        if (n(e)) throw new r("ArrayBuffer is detached");
        return e;
      };
    }),
    g = n.cw(function (e, t) {
      var n = ae(),
        r = Y(),
        i = W(),
        o = At(),
        s = m(),
        a = f(),
        c = O(),
        d = gt(),
        u = n.structuredClone,
        l = n.ArrayBuffer,
        p = n.DataView,
        h = Math.max,
        g = Math.min,
        b = l.prototype,
        v = p.prototype,
        y = r(b.slice),
        A = i(b, "resizable", "get"),
        C = i(b, "maxByteLength", "get"),
        w = r(v.getInt8),
        S = r(v.setInt8);
      e.exports =
        (d || c) &&
        function (e, t, n) {
          var r,
            i = a(e),
            f = void 0 === t ? i : o(t),
            m = !A || !A(e);
          if ((s(e), d && ((e = u(e, { transfer: [e] })), i === f && (n || m))))
            return e;
          if (i >= f && (!n || m)) r = y(e, 0, f);
          else {
            var b = n && !m && C ? { maxByteLength: h(f, C(e)) } : void 0;
            r = new l(f, b);
            for (var v = new p(e), I = new p(r), _ = g(f, i), k = 0; k < _; k++)
              S(I, k, w(v, k));
          }
          return d || c(e), r;
        };
    }),
    b = n.cw(function (e, t) {
      var n,
        r,
        i,
        o = p(),
        s = M(),
        a = ae(),
        c = ve(),
        d = Ce(),
        u = ce(),
        l = I(),
        f = Et(),
        h = P(),
        m = T(),
        g = x(),
        b = qe(),
        v = $e(),
        y = We(),
        A = Ut(),
        C = xt(),
        w = he(),
        S = w.enforce,
        _ = w.get,
        k = a.Int8Array,
        B = k && k.prototype,
        E = a.Uint8ClampedArray,
        R = E && E.prototype,
        z = k && v(k),
        O = B && v(B),
        F = Object.prototype,
        U = a.TypeError,
        N = A("toStringTag"),
        L = C("TYPED_ARRAY_TAG"),
        j = "TypedArrayConstructor",
        D = o && !!y && "Opera" !== l(a.opera),
        V = !1,
        G = {
          Int8Array: 1,
          Uint8Array: 1,
          Uint8ClampedArray: 1,
          Int16Array: 2,
          Uint16Array: 2,
          Int32Array: 4,
          Uint32Array: 4,
          Float32Array: 4,
          Float64Array: 8,
        },
        $ = { BigInt64Array: 8, BigUint64Array: 8 },
        q = function (e) {
          var t = v(e);
          if (d(t)) {
            var n = _(t);
            return n && u(n, j) ? n[j] : q(t);
          }
        },
        Z = function (e) {
          if (!d(e)) return !1;
          var t = l(e);
          return u(G, t) || u($, t);
        };
      for (n in G) (i = (r = a[n]) && r.prototype) ? (S(i)[j] = r) : (D = !1);
      for (n in $) (i = (r = a[n]) && r.prototype) && (S(i)[j] = r);
      if (
        (!D || !c(z) || z === Function.prototype) &&
        ((z = function () {
          throw new U("Incorrect invocation");
        }),
        D)
      )
        for (n in G) a[n] && y(a[n], z);
      if ((!D || !O || O === F) && ((O = z.prototype), D))
        for (n in G) a[n] && y(a[n].prototype, O);
      if ((D && v(R) !== O && y(R, O), s && !u(O, N)))
        for (n in ((V = !0),
        g(O, N, {
          configurable: !0,
          get: function () {
            return d(this) ? this[L] : void 0;
          },
        }),
        G))
          a[n] && h(a[n].prototype, L, n);
      e.exports = {
        NATIVE_ARRAY_BUFFER_VIEWS: D,
        TYPED_ARRAY_TAG: V && L,
        aTypedArray: function (e) {
          if (Z(e)) return e;
          throw new U("Target is not a typed array");
        },
        aTypedArrayConstructor: function (e) {
          if (c(e) && (!y || b(z, e))) return e;
          throw new U(f(e) + " is not a typed array constructor");
        },
        exportTypedArrayMethod: function (e, t, n, r) {
          if (s) {
            if (n)
              for (var i in G) {
                var o = a[i];
                if (o && u(o.prototype, e))
                  try {
                    delete o.prototype[e];
                  } catch (n) {
                    try {
                      o.prototype[e] = t;
                    } catch (e) {}
                  }
              }
            (O[e] && !n) || m(O, e, n ? t : (D && B[e]) || t, r);
          }
        },
        exportTypedArrayStaticMethod: function (e, t, n) {
          var r, i;
          if (s) {
            if (y) {
              if (n)
                for (r in G)
                  if ((i = a[r]) && u(i, e))
                    try {
                      delete i[e];
                    } catch (e) {}
              if (z[e] && !n) return;
              try {
                return m(z, e, n ? t : (D && z[e]) || t);
              } catch (e) {}
            }
            for (r in G) !(i = a[r]) || (i[e] && !n) || m(i, e, t);
          }
        },
        getTypedArrayConstructor: q,
        isView: function (e) {
          if (!d(e)) return !1;
          var t = l(e);
          return "DataView" === t || u(G, t) || u($, t);
        },
        isTypedArray: Z,
        TypedArray: z,
        TypedArrayPrototype: O,
      };
    }),
    v = n.cw(function (e, t) {
      var n = Oe();
      e.exports = function (e, t, r) {
        for (
          var i = 0, o = arguments.length > 2 ? r : n(t), s = new e(o);
          o > i;

        )
          s[i] = t[i++];
        return s;
      };
    }),
    y = n.cw(function (e, t) {
      var n = Ct(),
        r = vt(),
        i = Oe(),
        o = function (e) {
          return function (t, o, s) {
            var a = n(t),
              c = i(a);
            if (0 === c) return !e && -1;
            var d,
              u = r(s, c);
            if (e && o != o) {
              for (; c > u; ) if ((d = a[u++]) != d) return !0;
            } else
              for (; c > u; u++)
                if ((e || u in a) && a[u] === o) return e || u || 0;
            return !e && -1;
          };
        };
      e.exports = { m: o(!0), q: o(!1) };
    }),
    A = n.cw(function (e, t) {
      var n = M(),
        r = ge(),
        i = TypeError,
        o = Object.getOwnPropertyDescriptor,
        s =
          n &&
          !(function () {
            if (void 0 !== this) return !0;
            try {
              Object.defineProperty([], "length", { writable: !1 }).length = 1;
            } catch (e) {
              return e instanceof TypeError;
            }
          })();
      e.exports = s
        ? function (e, t) {
            if (r(e) && !o(e, "length").writable)
              throw new i("Cannot set read only .length");
            return (e.length = t);
          }
        : function (e, t) {
            return (e.length = t);
          };
    }),
    C = n.cw(function (e, t) {
      var n = Y();
      e.exports = n([].slice);
    }),
    w = n.cw(function (e, t) {
      var n = u(),
        r = Ee();
      e.exports = function (e, t, i, o) {
        try {
          return o ? t(n(i)[0], i[1]) : t(i);
        } catch (t) {
          r(e, "throw", t);
        }
      };
    }),
    S = n.cw(function (e, t) {
      var n = Y(),
        r = n({}.toString),
        i = n("".slice);
      e.exports = function (e) {
        return i(r(e), 8, -1);
      };
    }),
    I = n.cw(function (e, t) {
      var n = Pt(),
        r = ve(),
        i = S(),
        o = Ut()("toStringTag"),
        s = Object,
        a =
          "Arguments" ===
          i(
            (function () {
              return arguments;
            })()
          );
      e.exports = n
        ? i
        : function (e) {
            var t, n, c;
            return void 0 === e
              ? "Undefined"
              : null === e
              ? "Null"
              : "string" ==
                typeof (n = (function (e, t) {
                  try {
                    return e[t];
                  } catch (e) {}
                })((t = s(e)), o))
              ? n
              : a
              ? i(t)
              : "Object" === (c = i(t)) && r(t.callee)
              ? "Arguments"
              : c;
          };
    }),
    _ = n.cw(function (e, t) {
      var n = ce(),
        r = Ye(),
        i = Ve(),
        o = De();
      e.exports = function (e, t, s) {
        for (var a = r(t), c = o.f, d = i.f, u = 0; u < a.length; u++) {
          var l = a[u];
          n(e, l) || (s && n(s, l)) || c(e, l, d(t, l));
        }
      };
    }),
    k = n.cw(function (e, t) {
      var n = G();
      e.exports = !n(function () {
        function e() {}
        return (
          (e.prototype.constructor = null),
          Object.getPrototypeOf(new e()) !== e.prototype
        );
      });
    }),
    P = n.cw(function (e, t) {
      var n = M(),
        r = De(),
        i = B();
      e.exports = n
        ? function (e, t, n) {
            return r.f(e, t, i(1, n));
          }
        : function (e, t, n) {
            return (e[t] = n), e;
          };
    }),
    B = n.cw(function (e, t) {
      e.exports = function (e, t) {
        return {
          enumerable: !(1 & e),
          configurable: !(2 & e),
          writable: !(4 & e),
          value: t,
        };
      };
    }),
    E = n.cw(function (e, t) {
      var n = M(),
        r = De(),
        i = B();
      e.exports = function (e, t, o) {
        n ? r.f(e, t, i(0, o)) : (e[t] = o);
      };
    }),
    x = n.cw(function (e, t) {
      var n = Fe(),
        r = De();
      e.exports = function (e, t, i) {
        return (
          i.get && n(i.get, t, { getter: !0 }),
          i.set && n(i.set, t, { setter: !0 }),
          r.f(e, t, i)
        );
      };
    }),
    T = n.cw(function (e, t) {
      var n = ve(),
        r = De(),
        i = Fe(),
        o = z();
      e.exports = function (e, t, s, a) {
        a || (a = {});
        var c = a.enumerable,
          d = void 0 !== a.name ? a.name : t;
        if ((n(s) && i(s, d, a), a.global)) c ? (e[t] = s) : o(t, s);
        else {
          try {
            a.unsafe ? e[t] && (c = !0) : delete e[t];
          } catch (e) {}
          c
            ? (e[t] = s)
            : r.f(e, t, {
                value: s,
                enumerable: !1,
                configurable: !a.nonConfigurable,
                writable: !a.nonWritable,
              });
        }
        return e;
      };
    }),
    R = n.cw(function (e, t) {
      var n = T();
      e.exports = function (e, t, r) {
        for (var i in t) n(e, i, t[i], r);
        return e;
      };
    }),
    z = n.cw(function (e, t) {
      var n = ae(),
        r = Object.defineProperty;
      e.exports = function (e, t) {
        try {
          r(n, e, { value: t, configurable: !0, writable: !0 });
        } catch (r) {
          n[e] = t;
        }
        return t;
      };
    }),
    M = n.cw(function (e, t) {
      var n = G();
      e.exports = !n(function () {
        return (
          7 !==
          Object.defineProperty({}, 1, {
            get: function () {
              return 7;
            },
          })[1]
        );
      });
    }),
    O = n.cw(function (e, t) {
      var n,
        r,
        i,
        o,
        s = ae(),
        a = X(),
        c = gt(),
        d = s.structuredClone,
        u = s.ArrayBuffer,
        l = s.MessageChannel,
        p = !1;
      if (c)
        p = function (e) {
          d(e, { transfer: [e] });
        };
      else if (u)
        try {
          l || ((n = a("worker_threads")) && (l = n.MessageChannel)),
            l &&
              ((r = new l()),
              (i = new u(2)),
              (o = function (e) {
                r.port1.postMessage(null, [e]);
              }),
              2 === i.byteLength && (o(i), 0 === i.byteLength && (p = o)));
        } catch (e) {}
      e.exports = p;
    }),
    F = n.cw(function (e, t) {
      var n = ae(),
        r = Ce(),
        i = n.document,
        o = r(i) && r(i.createElement);
      e.exports = function (e) {
        return o ? i.createElement(e) : {};
      };
    }),
    U = n.cw(function (e, t) {
      e.exports = [
        "constructor",
        "hasOwnProperty",
        "isPrototypeOf",
        "propertyIsEnumerable",
        "toLocaleString",
        "toString",
        "valueOf",
      ];
    }),
    N = n.cw(function (e, t) {
      var n = D();
      e.exports = "NODE" === n;
    }),
    L = n.cw(function (e, t) {
      var n = ae().navigator,
        r = n && n.userAgent;
      e.exports = r ? String(r) : "";
    }),
    j = n.cw(function (e, t) {
      var n,
        r,
        i = ae(),
        o = L(),
        s = i.process,
        a = i.Deno,
        c = (s && s.versions) || (a && a.version),
        d = c && c.v8;
      d && (r = (n = d.split("."))[0] > 0 && n[0] < 4 ? 1 : +(n[0] + n[1])),
        !r &&
          o &&
          (!(n = o.match(/Edge\/(\d+)/)) || n[1] >= 74) &&
          (n = o.match(/Chrome\/(\d+)/)) &&
          (r = +n[1]),
        (e.exports = r);
    }),
    D = n.cw(function (e, t) {
      var n = ae(),
        r = L(),
        i = S(),
        o = function (e) {
          return r.slice(0, e.length) === e;
        };
      e.exports = o("Bun/")
        ? "BUN"
        : o("Cloudflare-Workers")
        ? "CLOUDFLARE"
        : o("Deno/")
        ? "DENO"
        : o("Node.js/")
        ? "NODE"
        : n.Bun && "string" == typeof Bun.version
        ? "BUN"
        : n.Deno && "object" == typeof Deno.version
        ? "DENO"
        : "process" === i(n.process)
        ? "NODE"
        : n.window && n.document
        ? "BROWSER"
        : "REST";
    }),
    V = n.cw(function (e, t) {
      var n = ae(),
        r = Ve().f,
        i = P(),
        o = T(),
        s = z(),
        a = _(),
        c = ye();
      e.exports = function (e, t) {
        var d,
          u,
          l,
          p,
          f,
          h = e.target,
          m = e.global,
          g = e.stat;
        if ((d = m ? n : g ? n[h] || s(h, {}) : n[h] && n[h].prototype))
          for (u in t) {
            if (
              ((p = t[u]),
              (l = e.dontCallGetSet ? (f = r(d, u)) && f.value : d[u]),
              !c(m ? u : h + (g ? "." : "#") + u, e.forced) && void 0 !== l)
            ) {
              if (typeof p == typeof l) continue;
              a(p, l);
            }
            (e.sham || (l && l.sham)) && i(p, "sham", !0), o(d, u, p, e);
          }
      };
    }),
    G = n.cw(function (e, t) {
      e.exports = function (e) {
        try {
          return !!e();
        } catch (e) {
          return !0;
        }
      };
    }),
    $ = n.cw(function (e, t) {
      var n = Z(),
        r = Function.prototype,
        i = r.apply,
        o = r.call;
      e.exports =
        ("object" == typeof Reflect && Reflect.apply) ||
        (n
          ? o.bind(i)
          : function () {
              return o.apply(i, arguments);
            });
    }),
    q = n.cw(function (e, t) {
      var n = J(),
        i = r(),
        o = Z(),
        s = n(n.bind);
      e.exports = function (e, t) {
        return (
          i(e),
          void 0 === t
            ? e
            : o
            ? s(e, t)
            : function () {
                return e.apply(t, arguments);
              }
        );
      };
    }),
    Z = n.cw(function (e, t) {
      var n = G();
      e.exports = !n(function () {
        var e = function () {}.bind();
        return "function" != typeof e || e.hasOwnProperty("prototype");
      });
    }),
    K = n.cw(function (e, t) {
      var n = Z(),
        r = Function.prototype.call;
      e.exports = n
        ? r.bind(r)
        : function () {
            return r.apply(r, arguments);
          };
    }),
    H = n.cw(function (e, t) {
      var n = M(),
        r = ce(),
        i = Function.prototype,
        o = n && Object.getOwnPropertyDescriptor,
        s = r(i, "name"),
        a = s && (!n || (n && o(i, "name").configurable));
      e.exports = { i2: a };
    }),
    W = n.cw(function (e, t) {
      var n = Y(),
        i = r();
      e.exports = function (e, t, r) {
        try {
          return n(i(Object.getOwnPropertyDescriptor(e, t)[r]));
        } catch (e) {}
      };
    }),
    J = n.cw(function (e, t) {
      var n = S(),
        r = Y();
      e.exports = function (e) {
        if ("Function" === n(e)) return r(e);
      };
    }),
    Y = n.cw(function (e, t) {
      var n = Z(),
        r = Function.prototype,
        i = r.call,
        o = n && r.bind.bind(i, i);
      e.exports = n
        ? o
        : function (e) {
            return function () {
              return i.apply(e, arguments);
            };
          };
    }),
    Q = () => n(213),
    X = n.cw(function (e, t) {
      var n = ae(),
        r = N();
      e.exports = function (e) {
        if (r) {
          try {
            return n.process.getBuiltinModule(e);
          } catch (e) {}
          try {
            return Function('return require("' + e + '")')();
          } catch (e) {}
        }
      };
    }),
    ee = n.cw(function (e, t) {
      var n = ae(),
        r = ve();
      e.exports = function (e, t) {
        return arguments.length < 2
          ? ((i = n[e]), r(i) ? i : void 0)
          : n[e] && n[e][t];
        var i;
      };
    }),
    te = () => n(2),
    ne = n.cw(function (e, t) {
      var n = K(),
        r = u(),
        i = te(),
        o = re();
      e.exports = function (e, t) {
        (t && "string" == typeof e) || r(e);
        var s = o(e);
        return i(r(void 0 !== s ? n(s, e) : e));
      };
    }),
    re = n.cw(function (e, t) {
      var n = I(),
        r = oe(),
        i = Ae(),
        o = Bn(),
        s = Ut()("iterator");
      e.exports = function (e) {
        if (!i(e)) return r(e, s) || r(e, "@@iterator") || o[n(e)];
      };
    }),
    ie = n.cw(function (e, t) {
      var n = K(),
        i = r(),
        o = u(),
        s = Et(),
        a = re(),
        c = TypeError;
      e.exports = function (e, t) {
        var r = arguments.length < 2 ? a(e) : t;
        if (i(r)) return o(n(r, e));
        throw new c(s(e) + " is not iterable");
      };
    }),
    oe = n.cw(function (e, t) {
      var n = r(),
        i = Ae();
      e.exports = function (e, t) {
        var r = e[t];
        return i(r) ? void 0 : n(r);
      };
    }),
    se = n.cw(function (e, t) {
      var n = r(),
        i = u(),
        o = K(),
        s = wt(),
        a = te(),
        c = "Invalid size",
        d = RangeError,
        l = TypeError,
        p = Math.max,
        f = function (e, t) {
          (this.set = e),
            (this.size = p(t, 0)),
            (this.has = n(e.has)),
            (this.keys = n(e.keys));
        };
      (f.prototype = {
        getIterator: function () {
          return a(i(o(this.keys, this.set)));
        },
        includes: function (e) {
          return o(this.has, this.set, e);
        },
      }),
        (e.exports = function (e) {
          i(e);
          var t = +e.size;
          if (t != t) throw new l(c);
          var n = s(t);
          if (n < 0) throw new d(c);
          return new f(e, n);
        });
    }),
    ae = n.cw(function (e, t) {
      var n = function (e) {
        return e && e.Math === Math && e;
      };
      e.exports =
        n("object" == typeof globalThis && globalThis) ||
        n("object" == typeof window && window) ||
        n("object" == typeof self && self) ||
        n("object" == typeof globalThis && globalThis) ||
        n("object" == typeof this && this) ||
        (function () {
          return this;
        })() ||
        Function("return this")();
    }),
    ce = n.cw(function (e, t) {
      var n = Y(),
        r = It(),
        i = n({}.hasOwnProperty);
      e.exports =
        Object.hasOwn ||
        function (e, t) {
          return i(r(e), t);
        };
    }),
    de = n.cw(function (e, t) {
      e.exports = {};
    }),
    ue = n.cw(function (e, t) {
      var n = ee();
      e.exports = n("document", "documentElement");
    }),
    le = n.cw(function (e, t) {
      var n = M(),
        r = G(),
        i = F();
      e.exports =
        !n &&
        !r(function () {
          return (
            7 !==
            Object.defineProperty(i("div"), "a", {
              get: function () {
                return 7;
              },
            }).a
          );
        });
    }),
    pe = n.cw(function (e, t) {
      var n = Y(),
        r = G(),
        i = S(),
        o = Object,
        s = n("".split);
      e.exports = r(function () {
        return !o("z").propertyIsEnumerable(0);
      })
        ? function (e) {
            return "String" === i(e) ? s(e, "") : o(e);
          }
        : o;
    }),
    fe = n.cw(function (e, t) {
      var n = Y(),
        r = ve(),
        i = ht(),
        o = n(Function.toString);
      r(i.inspectSource) ||
        (i.inspectSource = function (e) {
          return o(e);
        }),
        (e.exports = i.inspectSource);
    }),
    he = n.cw(function (e, t) {
      var n,
        r,
        i,
        o = Ft(),
        s = ae(),
        a = Ce(),
        c = P(),
        d = ce(),
        u = ht(),
        l = ft(),
        p = de(),
        f = "Object already initialized",
        h = s.TypeError,
        m = s.WeakMap;
      if (o || u.state) {
        var g = u.state || (u.state = new m());
        (g.get = g.get),
          (g.has = g.has),
          (g.set = g.set),
          (n = function (e, t) {
            if (g.has(e)) throw new h(f);
            return (t.facade = e), g.set(e, t), t;
          }),
          (r = function (e) {
            return g.get(e) || {};
          }),
          (i = function (e) {
            return g.has(e);
          });
      } else {
        var b = l("state");
        (p[b] = !0),
          (n = function (e, t) {
            if (d(e, b)) throw new h(f);
            return (t.facade = e), c(e, b, t), t;
          }),
          (r = function (e) {
            return d(e, b) ? e[b] : {};
          }),
          (i = function (e) {
            return d(e, b);
          });
      }
      e.exports = {
        set: n,
        get: r,
        has: i,
        enforce: function (e) {
          return i(e) ? r(e) : n(e, {});
        },
        getterFor: function (e) {
          return function (t) {
            var n;
            if (!a(t) || (n = r(t)).type !== e)
              throw new h("Incompatible receiver, " + e + " required");
            return n;
          };
        },
      };
    }),
    me = n.cw(function (e, t) {
      var n = Ut(),
        r = Bn(),
        i = n("iterator"),
        o = Array.prototype;
      e.exports = function (e) {
        return void 0 !== e && (r.Array === e || o[i] === e);
      };
    }),
    ge = n.cw(function (e, t) {
      var n = S();
      e.exports =
        Array.isArray ||
        function (e) {
          return "Array" === n(e);
        };
    }),
    be = n.cw(function (e, t) {
      var n = I();
      e.exports = function (e) {
        var t = n(e);
        return "BigInt64Array" === t || "BigUint64Array" === t;
      };
    }),
    ve = n.cw(function (e, t) {
      var n = "object" == typeof document && document.all;
      e.exports =
        void 0 === n && void 0 !== n
          ? function (e) {
              return "function" == typeof e || e === n;
            }
          : function (e) {
              return "function" == typeof e;
            };
    }),
    ye = n.cw(function (e, t) {
      var n = G(),
        r = ve(),
        i = /#|\.prototype\./,
        o = function (e, t) {
          var i = a[s(e)];
          return i === d || (i !== c && (r(t) ? n(t) : !!t));
        },
        s = (o.normalize = function (e) {
          return String(e).replace(i, ".").toLowerCase();
        }),
        a = (o.data = {}),
        c = (o.NATIVE = "N"),
        d = (o.POLYFILL = "P");
      e.exports = o;
    }),
    Ae = () => n(318),
    Ce = n.cw(function (e, t) {
      var n = ve();
      e.exports = function (e) {
        return "object" == typeof e ? null !== e : n(e);
      };
    }),
    we = n.cw(function (e, t) {
      var n = Ce();
      e.exports = function (e) {
        return n(e) || null === e;
      };
    }),
    Se = n.cw(function (e, t) {
      e.exports = !1;
    }),
    Ie = n.cw(function (e, t) {
      var n = Ce(),
        r = he().get;
      e.exports = function (e) {
        if (!n(e)) return !1;
        var t = r(e);
        return !!t && "RawJSON" === t.type;
      };
    }),
    _e = n.cw(function (e, t) {
      var n = ee(),
        r = ve(),
        i = qe(),
        o = zt(),
        s = Object;
      e.exports = o
        ? function (e) {
            return "symbol" == typeof e;
          }
        : function (e) {
            var t = n("Symbol");
            return r(t) && i(t.prototype, s(e));
          };
    }),
    ke = n.cw(function (e, t) {
      var n = K();
      e.exports = function (e, t, r) {
        for (
          var i, o, s = r ? e : e.iterator, a = e.next;
          !(i = n(a, s)).done;

        )
          if (void 0 !== (o = t(i.value))) return o;
      };
    }),
    Pe = n.cw(function (e, t) {
      var n = q(),
        r = K(),
        i = u(),
        o = Et(),
        s = me(),
        a = Oe(),
        c = qe(),
        d = ie(),
        l = re(),
        p = Ee(),
        f = TypeError,
        h = function (e, t) {
          (this.stopped = e), (this.result = t);
        },
        m = h.prototype;
      e.exports = function (e, t, u) {
        var g,
          b,
          v,
          y,
          A,
          C,
          w,
          S = u && u.that,
          I = !(!u || !u.AS_ENTRIES),
          _ = !(!u || !u.IS_RECORD),
          k = !(!u || !u.IS_ITERATOR),
          P = !(!u || !u.INTERRUPTED),
          B = n(t, S),
          E = function (e) {
            var t = g;
            return (g = void 0), t && p(t, "normal"), new h(!0, e);
          },
          x = function (e) {
            return I
              ? (i(e), P ? B(e[0], e[1], E) : B(e[0], e[1]))
              : P
              ? B(e, E)
              : B(e);
          };
        if (_) g = e.iterator;
        else if (k) g = e;
        else {
          if (!(b = l(e))) throw new f(o(e) + " is not iterable");
          if (s(b)) {
            for (v = 0, y = a(e); y > v; v++)
              if ((A = x(e[v])) && c(m, A)) return A;
            return new h(!1);
          }
          g = d(e, b);
        }
        for (C = _ ? e.next : g.next; !(w = r(C, g)).done; ) {
          var T = w.value;
          try {
            A = x(T);
          } catch (e) {
            if (!g) throw e;
            p(g, "throw", e);
          }
          if ("object" == typeof A && A && c(m, A)) return A;
        }
        return new h(!1);
      };
    }),
    Be = n.cw(function (e, t) {
      var n = Ee();
      e.exports = function (e, t, r) {
        for (var i = e.length - 1; i >= 0; i--)
          if (void 0 !== e[i])
            try {
              r = n(e[i].iterator, t, r);
            } catch (e) {
              (t = "throw"), (r = e);
            }
        if ("throw" === t) throw r;
        return r;
      };
    }),
    Ee = n.cw(function (e, t) {
      var n = K(),
        r = u(),
        i = oe();
      e.exports = function (e, t, o) {
        var s, a;
        r(e);
        try {
          if (!(s = i(e, "return"))) {
            if ("throw" === t) throw o;
            return o;
          }
          s = n(s, e);
        } catch (e) {
          (a = !0), (s = e);
        }
        if ("throw" === t) throw o;
        if (a) throw s;
        return r(s), o;
      };
    }),
    xe = n.cw(function (e, t) {
      var r = K(),
        i = Le(),
        o = P(),
        s = R(),
        a = Ut(),
        c = he(),
        d = oe(),
        u = ze().H,
        l = n(224),
        p = Ee(),
        f = Be(),
        h = a("toStringTag"),
        m = "IteratorHelper",
        g = "WrapForValidIterator",
        b = "normal",
        v = "throw",
        y = c.set,
        A = function (e) {
          var t = c.getterFor(e ? g : m);
          return s(i(u), {
            next: function () {
              var n = t(this);
              if (e) return n.nextHandler();
              if (n.done) return l(void 0, !0);
              try {
                var r = n.nextHandler();
                return n.returnHandlerResult ? r : l(r, n.done);
              } catch (e) {
                throw ((n.done = !0), e);
              }
            },
            return: function () {
              var n = t(this),
                i = n.iterator,
                o = n.done;
              if (((n.done = !0), e)) {
                var s = d(i, "return");
                return s ? r(s, i) : l(void 0, !0);
              }
              if (o) return l(void 0, !0);
              if (n.inner)
                try {
                  p(n.inner.iterator, b);
                } catch (e) {
                  return p(i, v, e);
                }
              if (n.openIters)
                try {
                  f(n.openIters, b);
                } catch (e) {
                  if (i) return p(i, v, e);
                  throw e;
                }
              return i && p(i, b), l(void 0, !0);
            },
          });
        },
        C = A(!0),
        w = A(!1);
      o(w, h, "Iterator Helper"),
        (e.exports = function (e, t, n) {
          var r = function (r, i) {
            i ? ((i.iterator = r.iterator), (i.next = r.next)) : (i = r),
              (i.type = t ? g : m),
              (i.returnHandlerResult = !!n),
              (i.nextHandler = e),
              (i.counter = 0),
              (i.done = !1),
              y(this, i);
          };
          return (r.prototype = t ? C : w), r;
        });
    }),
    Te = () => n(475),
    Re = n.cw(function (e, t) {
      var n = ae();
      e.exports = function (e, t) {
        var r = n.Iterator,
          i = r && r.prototype,
          o = i && i[e],
          s = !1;
        if (o)
          try {
            o.call(
              {
                next: function () {
                  return { done: !0 };
                },
                return: function () {
                  s = !0;
                },
              },
              -1
            );
          } catch (e) {
            e instanceof t || (s = !1);
          }
        if (!s) return o;
      };
    }),
    ze = n.cw(function (e, t) {
      var n,
        r,
        i,
        o = G(),
        s = ve(),
        a = Ce(),
        c = Le(),
        d = $e(),
        u = T(),
        l = Ut(),
        p = Se(),
        f = l("iterator");
      [].keys &&
        "next" in (i = [].keys()) &&
        (r = d(d(i))) !== Object.prototype &&
        (n = r),
        !a(n) ||
        o(function () {
          var e = {};
          return n[f].call(e) !== e;
        })
          ? (n = {})
          : p && (n = c(n)),
        s(n[f]) ||
          u(n, f, function () {
            return this;
          }),
        (e.exports = { H: n });
    }),
    Me = () => n(164),
    Oe = n.cw(function (e, t) {
      var n = St();
      e.exports = function (e) {
        return n(e.length);
      };
    }),
    Fe = n.cw(function (e, t) {
      var n = Y(),
        r = G(),
        i = ve(),
        o = ce(),
        s = M(),
        a = H().i2,
        c = fe(),
        d = he(),
        u = d.enforce,
        l = d.get,
        p = String,
        f = Object.defineProperty,
        h = n("".slice),
        m = n("".replace),
        g = n([].join),
        b =
          s &&
          !r(function () {
            return 8 !== f(function () {}, "length", { value: 8 }).length;
          }),
        v = String(String).split("String"),
        y = (e.exports = function (e, t, n) {
          "Symbol(" === h(p(t), 0, 7) &&
            (t = "[" + m(p(t), /^Symbol\(([^)]*)\).*$/, "$1") + "]"),
            n && n.getter && (t = "get " + t),
            n && n.setter && (t = "set " + t),
            (!o(e, "name") || (a && e.name !== t)) &&
              (s ? f(e, "name", { value: t, configurable: !0 }) : (e.name = t)),
            b &&
              n &&
              o(n, "arity") &&
              e.length !== n.arity &&
              f(e, "length", { value: n.arity });
          try {
            n && o(n, "constructor") && n.constructor
              ? s && f(e, "prototype", { writable: !1 })
              : e.prototype && (e.prototype = void 0);
          } catch (e) {}
          var r = u(e);
          return (
            o(r, "source") || (r.source = g(v, "string" == typeof t ? t : "")),
            e
          );
        });
      Function.prototype.toString = y(function () {
        return (i(this) && l(this).source) || c(this);
      }, "toString");
    }),
    Ue = n.cw(function (e, t) {
      var n = Y(),
        r = Map.prototype;
      e.exports = {
        Map,
        set: n(r.set),
        get: n(r.get),
        has: n(r.has),
        remove: n(r.delete),
        proto: r,
      };
    }),
    Ne = n.cw(function (e, t) {
      var n = G();
      e.exports = !n(function () {
        var e = "9007199254740993",
          t = JSON.rawJSON(e);
        return !JSON.isRawJSON(t) || JSON.stringify(t) !== e;
      });
    }),
    Le = n.cw(function (e, t) {
      var n,
        r = u(),
        i = je(),
        o = U(),
        s = de(),
        a = ue(),
        c = F(),
        d = ft(),
        l = "prototype",
        p = "script",
        f = d("IE_PROTO"),
        h = function () {},
        m = function (e) {
          return "<" + p + ">" + e + "</" + p + ">";
        },
        g = function (e) {
          e.write(m("")), e.close();
          var t = e.parentWindow.Object;
          return (e = null), t;
        },
        b = function () {
          try {
            n = new ActiveXObject("htmlfile");
          } catch (e) {}
          var e, t, r;
          b =
            "undefined" != typeof document
              ? document.domain && n
                ? g(n)
                : ((t = c("iframe")),
                  (r = "java" + p + ":"),
                  (t.style.display = "none"),
                  a.appendChild(t),
                  (t.src = String(r)),
                  (e = t.contentWindow.document).open(),
                  e.write(m("document.F=Object")),
                  e.close(),
                  e.F)
              : g(n);
          for (var i = o.length; i--; ) delete b[l][o[i]];
          return b();
        };
      (s[f] = !0),
        (e.exports =
          Object.create ||
          function (e, t) {
            var n;
            return (
              null !== e
                ? ((h[l] = r(e)), (n = new h()), (h[l] = null), (n[f] = e))
                : (n = b()),
              void 0 === t ? n : i.f(n, t)
            );
          });
    }),
    je = n.cw(function (e, t) {
      var n = M(),
        r = Mt(),
        i = De(),
        o = u(),
        s = Ct(),
        a = Ke();
      t.f =
        n && !r
          ? Object.defineProperties
          : function (e, t) {
              o(e);
              for (var n, r = s(t), c = a(t), d = c.length, u = 0; d > u; )
                i.f(e, (n = c[u++]), r[n]);
              return e;
            };
    }),
    De = n.cw(function (e, t) {
      var n = M(),
        r = le(),
        i = Mt(),
        o = u(),
        s = kt(),
        a = TypeError,
        c = Object.defineProperty,
        d = Object.getOwnPropertyDescriptor,
        l = "enumerable",
        p = "configurable",
        f = "writable";
      t.f = n
        ? i
          ? function (e, t, n) {
              if (
                (o(e),
                (t = s(t)),
                o(n),
                "function" == typeof e &&
                  "prototype" === t &&
                  "value" in n &&
                  f in n &&
                  !n[f])
              ) {
                var r = d(e, t);
                r &&
                  r[f] &&
                  ((e[t] = n.value),
                  (n = {
                    configurable: p in n ? n[p] : r[p],
                    enumerable: l in n ? n[l] : r[l],
                    writable: !1,
                  }));
              }
              return c(e, t, n);
            }
          : c
        : function (e, t, n) {
            if ((o(e), (t = s(t)), o(n), r))
              try {
                return c(e, t, n);
              } catch (e) {}
            if ("get" in n || "set" in n)
              throw new a("Accessors not supported");
            return "value" in n && (e[t] = n.value), e;
          };
    }),
    Ve = n.cw(function (e, t) {
      var n = M(),
        r = K(),
        i = He(),
        o = B(),
        s = Ct(),
        a = kt(),
        c = ce(),
        d = le(),
        u = Object.getOwnPropertyDescriptor;
      t.f = n
        ? u
        : function (e, t) {
            if (((e = s(e)), (t = a(t)), d))
              try {
                return u(e, t);
              } catch (e) {}
            if (c(e, t)) return o(!r(i.f, e, t), e[t]);
          };
    }),
    Ge = n.cw(function (e, t) {
      var n = Ze(),
        r = U().concat("length", "prototype");
      t.f =
        Object.getOwnPropertyNames ||
        function (e) {
          return n(e, r);
        };
    }),
    $e = n.cw(function (e, t) {
      var n = ce(),
        r = ve(),
        i = It(),
        o = ft(),
        s = k(),
        a = o("IE_PROTO"),
        c = Object,
        d = c.prototype;
      e.exports = s
        ? c.getPrototypeOf
        : function (e) {
            var t = i(e);
            if (n(t, a)) return t[a];
            var o = t.constructor;
            return r(o) && t instanceof o
              ? o.prototype
              : t instanceof c
              ? d
              : null;
          };
    }),
    qe = n.cw(function (e, t) {
      var n = Y();
      e.exports = n({}.isPrototypeOf);
    }),
    Ze = n.cw(function (e, t) {
      var n = Y(),
        r = ce(),
        i = Ct(),
        o = y().q,
        s = de(),
        a = n([].push);
      e.exports = function (e, t) {
        var n,
          c = i(e),
          d = 0,
          u = [];
        for (n in c) !r(s, n) && r(c, n) && a(u, n);
        for (; t.length > d; ) r(c, (n = t[d++])) && (~o(u, n) || a(u, n));
        return u;
      };
    }),
    Ke = n.cw(function (e, t) {
      var n = Ze(),
        r = U();
      e.exports =
        Object.keys ||
        function (e) {
          return n(e, r);
        };
    }),
    He = n.cw(function (e, t) {
      var n = {}.propertyIsEnumerable,
        r = Object.getOwnPropertyDescriptor,
        i = r && !n.call({ 1: 2 }, 1);
      t.f = i
        ? function (e) {
            var t = r(this, e);
            return !!t && t.enumerable;
          }
        : n;
    }),
    We = n.cw(function (e, t) {
      var n = W(),
        r = Ce(),
        o = Xe(),
        s = i();
      e.exports =
        Object.setPrototypeOf ||
        ("__proto__" in {}
          ? (function () {
              var e,
                t = !1,
                i = {};
              try {
                (e = n(Object.prototype, "__proto__", "set"))(i, []),
                  (t = i instanceof Array);
              } catch (e) {}
              return function (n, i) {
                return (
                  o(n), s(i), r(n) ? (t ? e(n, i) : (n.__proto__ = i), n) : n
                );
              };
            })()
          : void 0);
    }),
    Je = n.cw(function (e, t) {
      var n = K(),
        r = ve(),
        i = Ce(),
        o = TypeError;
      e.exports = function (e, t) {
        var s, a;
        if ("string" === t && r((s = e.toString)) && !i((a = n(s, e))))
          return a;
        if (r((s = e.valueOf)) && !i((a = n(s, e)))) return a;
        if ("string" !== t && r((s = e.toString)) && !i((a = n(s, e))))
          return a;
        throw new o("Can't convert object to primitive value");
      };
    }),
    Ye = n.cw(function (e, t) {
      var n = ee(),
        r = Y(),
        i = Ge(),
        o = Pn(),
        s = u(),
        a = r([].concat);
      e.exports =
        n("Reflect", "ownKeys") ||
        function (e) {
          var t = i.f(s(e)),
            n = o.f;
          return n ? a(t, n(e)) : t;
        };
    }),
    Qe = n.cw(function (e, t) {
      var n = Y(),
        r = ce(),
        i = SyntaxError,
        o = parseInt,
        s = String.fromCharCode,
        a = n("".charAt),
        c = n("".slice),
        d = n(/./.exec),
        u = {
          '\\"': '"',
          "\\\\": "\\",
          "\\/": "/",
          "\\b": "\b",
          "\\f": "\f",
          "\\n": "\n",
          "\\r": "\r",
          "\\t": "\t",
        },
        l = /^[\da-f]{4}$/i,
        p = /^[\u0000-\u001F]$/;
      e.exports = function (e, t) {
        for (var n = !0, f = ""; t < e.length; ) {
          var h = a(e, t);
          if ("\\" === h) {
            var m = c(e, t, t + 2);
            if (r(u, m)) (f += u[m]), (t += 2);
            else {
              if ("\\u" !== m)
                throw new i('Unknown escape sequence: "' + m + '"');
              var g = c(e, (t += 2), t + 4);
              if (!d(l, g)) throw new i("Bad Unicode escape at: " + t);
              (f += s(o(g, 16))), (t += 4);
            }
          } else {
            if ('"' === h) {
              (n = !1), t++;
              break;
            }
            if (d(p, h))
              throw new i("Bad control character in string literal at: " + t);
            (f += h), t++;
          }
        }
        if (n) throw new i("Unterminated string at: " + t);
        return { value: f, end: t };
      };
    }),
    Xe = () => n(509),
    et = n.cw(function (e, t) {
      var n = nt(),
        r = at(),
        i = n.Set,
        o = n.add;
      e.exports = function (e) {
        var t = new i();
        return (
          r(e, function (e) {
            o(t, e);
          }),
          t
        );
      };
    }),
    tt = n.cw(function (e, t) {
      var n = o(),
        r = nt(),
        i = et(),
        s = ut(),
        a = se(),
        c = at(),
        d = ke(),
        u = r.has,
        l = r.remove;
      e.exports = function (e) {
        var t = n(this),
          r = a(e),
          o = i(t);
        return (
          s(o) <= r.size
            ? c(o, function (e) {
                r.includes(e) && l(o, e);
              })
            : d(r.getIterator(), function (e) {
                u(o, e) && l(o, e);
              }),
          o
        );
      };
    }),
    nt = n.cw(function (e, t) {
      var n = Y(),
        r = Set.prototype;
      e.exports = {
        Set,
        add: n(r.add),
        has: n(r.has),
        remove: n(r.delete),
        proto: r,
      };
    }),
    rt = n.cw(function (e, t) {
      var n = o(),
        r = nt(),
        i = ut(),
        s = se(),
        a = at(),
        c = ke(),
        d = r.Set,
        u = r.add,
        l = r.has;
      e.exports = function (e) {
        var t = n(this),
          r = s(e),
          o = new d();
        return (
          i(t) > r.size
            ? c(r.getIterator(), function (e) {
                l(t, e) && u(o, e);
              })
            : a(t, function (e) {
                r.includes(e) && u(o, e);
              }),
          o
        );
      };
    }),
    it = n.cw(function (e, t) {
      var n = o(),
        r = nt().has,
        i = ut(),
        s = se(),
        a = at(),
        c = ke(),
        d = Ee();
      e.exports = function (e) {
        var t = n(this),
          o = s(e);
        if (i(t) <= o.size)
          return (
            !1 !==
            a(
              t,
              function (e) {
                if (o.includes(e)) return !1;
              },
              !0
            )
          );
        var u = o.getIterator();
        return (
          !1 !==
          c(u, function (e) {
            if (r(t, e)) return d(u.iterator, "normal", !1);
          })
        );
      };
    }),
    ot = n.cw(function (e, t) {
      var n = o(),
        r = ut(),
        i = at(),
        s = se();
      e.exports = function (e) {
        var t = n(this),
          o = s(e);
        return (
          !(r(t) > o.size) &&
          !1 !==
            i(
              t,
              function (e) {
                if (!o.includes(e)) return !1;
              },
              !0
            )
        );
      };
    }),
    st = n.cw(function (e, t) {
      var n = o(),
        r = nt().has,
        i = ut(),
        s = se(),
        a = ke(),
        c = Ee();
      e.exports = function (e) {
        var t = n(this),
          o = s(e);
        if (i(t) < o.size) return !1;
        var d = o.getIterator();
        return (
          !1 !==
          a(d, function (e) {
            if (!r(t, e)) return c(d.iterator, "normal", !1);
          })
        );
      };
    }),
    at = n.cw(function (e, t) {
      var n = Y(),
        r = ke(),
        i = nt(),
        o = i.Set,
        s = i.proto,
        a = n(s.forEach),
        c = n(s.keys),
        d = c(new o()).next;
      e.exports = function (e, t, n) {
        return n ? r({ iterator: c(e), next: d }, t) : a(e, t);
      };
    }),
    ct = n.cw(function (e, t) {
      var n = ee(),
        r = function (e) {
          return {
            size: e,
            has: function () {
              return !1;
            },
            keys: function () {
              return {
                next: function () {
                  return { done: !0 };
                },
              };
            },
          };
        },
        i = function (e) {
          return {
            size: e,
            has: function () {
              return !0;
            },
            keys: function () {
              throw new Error("e");
            },
          };
        };
      e.exports = function (e, t) {
        var o = n("Set");
        try {
          new o()[e](r(0));
          try {
            return new o()[e](r(-1)), !1;
          } catch (n) {
            if (!t) return !0;
            try {
              return new o()[e](i(-1 / 0)), !1;
            } catch (n) {
              return t(new o([1, 2])[e](i(1 / 0)));
            }
          }
        } catch (e) {
          return !1;
        }
      };
    }),
    dt = () => n(420),
    ut = n.cw(function (e, t) {
      var n = W(),
        r = nt();
      e.exports =
        n(r.proto, "size", "get") ||
        function (e) {
          return e.size;
        };
    }),
    lt = n.cw(function (e, t) {
      var n = o(),
        r = nt(),
        i = et(),
        s = se(),
        a = ke(),
        c = r.add,
        d = r.has,
        u = r.remove;
      e.exports = function (e) {
        var t = n(this),
          r = s(e).getIterator(),
          o = i(t);
        return (
          a(r, function (e) {
            d(t, e) ? u(o, e) : c(o, e);
          }),
          o
        );
      };
    }),
    pt = n.cw(function (e, t) {
      var n = o(),
        r = nt().add,
        i = et(),
        s = se(),
        a = ke();
      e.exports = function (e) {
        var t = n(this),
          o = s(e).getIterator(),
          c = i(t);
        return (
          a(o, function (e) {
            r(c, e);
          }),
          c
        );
      };
    }),
    ft = n.cw(function (e, t) {
      var n = mt(),
        r = xt(),
        i = n("keys");
      e.exports = function (e) {
        return i[e] || (i[e] = r(e));
      };
    }),
    ht = n.cw(function (e, t) {
      var n = Se(),
        r = ae(),
        i = z(),
        o = "__core-js_shared__",
        s = (e.exports = r[o] || i(o, {}));
      (s.versions || (s.versions = [])).push({
        version: "3.49.0",
        mode: n ? "pure" : "global",
        copyright:
          "© 2013–2025 Denis Pushkarev (zloirock.ru), 2025–2026 CoreJS Company (core-js.io). All rights reserved.",
        license: "https://github.com/zloirock/core-js/blob/v3.49.0/LICENSE",
        source: "https://github.com/zloirock/core-js",
      });
    }),
    mt = n.cw(function (e, t) {
      var n = ht();
      e.exports = function (e, t) {
        return n[e] || (n[e] = t || {});
      };
    }),
    gt = n.cw(function (e, t) {
      var n = ae(),
        r = G(),
        i = j(),
        o = D(),
        s = n.structuredClone;
      e.exports =
        !!s &&
        !r(function () {
          if (
            ("DENO" === o && i > 92) ||
            ("NODE" === o && i > 94) ||
            ("BROWSER" === o && i > 97)
          )
            return !1;
          var e = new ArrayBuffer(8),
            t = s(e, { transfer: [e] });
          return 0 !== e.byteLength || 8 !== t.byteLength;
        });
    }),
    bt = n.cw(function (e, t) {
      var n = j(),
        r = G(),
        i = ae().String;
      e.exports =
        !!Object.getOwnPropertySymbols &&
        !r(function () {
          var e = Symbol("symbol detection");
          return (
            !i(e) ||
            !(Object(e) instanceof Symbol) ||
            (!Symbol.sham && n && n < 41)
          );
        });
    }),
    vt = n.cw(function (e, t) {
      var n = wt(),
        r = Math.max,
        i = Math.min;
      e.exports = function (e, t) {
        var o = n(e);
        return o < 0 ? r(o + t, 0) : i(o, t);
      };
    }),
    yt = n.cw(function (e, t) {
      var n = _t(),
        r = TypeError;
      e.exports = function (e) {
        var t = n(e, "number");
        if ("number" == typeof t) throw new r("Can't convert number to bigint");
        return BigInt(t);
      };
    }),
    At = () => n(579),
    Ct = n.cw(function (e, t) {
      var n = pe(),
        r = Xe();
      e.exports = function (e) {
        return n(r(e));
      };
    }),
    wt = () => n(744),
    St = () => n(611),
    It = () => n(628),
    _t = n.cw(function (e, t) {
      var n = K(),
        r = Ce(),
        i = _e(),
        o = oe(),
        s = Je(),
        a = Ut(),
        c = TypeError,
        d = a("toPrimitive");
      e.exports = function (e, t) {
        if (!r(e) || i(e)) return e;
        var a,
          u = o(e, d);
        if (u) {
          if (
            (void 0 === t && (t = "default"), (a = n(u, e, t)), !r(a) || i(a))
          )
            return a;
          throw new c("Can't convert object to primitive value");
        }
        return void 0 === t && (t = "number"), s(e, t);
      };
    }),
    kt = n.cw(function (e, t) {
      var n = _t(),
        r = _e();
      e.exports = function (e) {
        var t = n(e, "string");
        return r(t) ? t : t + "";
      };
    }),
    Pt = n.cw(function (e, t) {
      var n = {};
      (n[Ut()("toStringTag")] = "z"), (e.exports = "[object z]" === String(n));
    }),
    Bt = n.cw(function (e, t) {
      var n = I(),
        r = String;
      e.exports = function (e) {
        if ("Symbol" === n(e))
          throw new TypeError("Cannot convert a Symbol value to a string");
        return r(e);
      };
    }),
    Et = n.cw(function (e, t) {
      var n = String;
      e.exports = function (e) {
        try {
          return n(e);
        } catch (e) {
          return "Object";
        }
      };
    }),
    xt = n.cw(function (e, t) {
      var n = Y(),
        r = 0,
        i = Math.random(),
        o = n((1.1).toString);
      e.exports = function (e) {
        return "Symbol(" + (void 0 === e ? "" : e) + ")_" + o(++r + i, 36);
      };
    }),
    Tt = n.cw(function (e, t) {
      var n = ae(),
        r = Y(),
        i = d(),
        o = s(),
        a = ce(),
        c = kr(),
        u = Q(),
        l = m(),
        p = c.c2i,
        f = c.c2iUrl,
        h = n.SyntaxError,
        g = n.TypeError,
        b = r("".charAt),
        v = function (e, t) {
          for (var n = e.length; t < n; t++) {
            var r = b(e, t);
            if (
              " " !== r &&
              "\t" !== r &&
              "\n" !== r &&
              "\f" !== r &&
              "\r" !== r
            )
              break;
          }
          return t;
        },
        y = function (e, t, n) {
          var r = e.length;
          r < 4 && (e += 2 === r ? "AA" : "A");
          var i =
              (t[b(e, 0)] << 18) +
              (t[b(e, 1)] << 12) +
              (t[b(e, 2)] << 6) +
              t[b(e, 3)],
            o = [(i >> 16) & 255, (i >> 8) & 255, 255 & i];
          if (2 === r) {
            if (n && 0 !== o[1]) throw new h("Extra bits");
            return [o[0]];
          }
          if (3 === r) {
            if (n && 0 !== o[2]) throw new h("Extra bits");
            return [o[0], o[1]];
          }
          return o;
        },
        A = function (e, t, n) {
          for (var r = t.length, i = 0; i < r; i++) e[n + i] = t[i];
          return n + r;
        };
      e.exports = function (e, t, n, r) {
        o(e), i(t);
        var s = "base64" === u(t) ? p : f,
          c = t ? t.lastChunkHandling : void 0;
        if (
          (void 0 === c && (c = "loose"),
          "loose" !== c && "strict" !== c && "stop-before-partial" !== c)
        )
          throw new g("Incorrect `lastChunkHandling` option");
        n && l(n.buffer);
        var d = e.length,
          m = n || [],
          C = 0,
          w = 0,
          S = "",
          I = 0;
        if (r)
          for (;;) {
            if ((I = v(e, I)) === d) {
              if (S.length > 0) {
                if ("stop-before-partial" === c) break;
                if ("loose" !== c) throw new h("Missing padding");
                if (1 === S.length)
                  throw new h(
                    "Malformed padding: exactly one additional character"
                  );
                C = A(m, y(S, s, !1), C);
              }
              w = d;
              break;
            }
            var _ = b(e, I);
            if ((++I, "=" === _)) {
              if (S.length < 2) throw new h("Padding is too early");
              if (((I = v(e, I)), 2 === S.length)) {
                if (I === d) {
                  if ("stop-before-partial" === c) break;
                  throw new h("Malformed padding: only one =");
                }
                "=" === b(e, I) && (++I, (I = v(e, I)));
              }
              if (I < d) throw new h("Unexpected character after padding");
              (C = A(m, y(S, s, "strict" === c), C)), (w = d);
              break;
            }
            if (!a(s, _)) throw new h("Unexpected character");
            var k = r - C;
            if ((1 === k && 2 === S.length) || (2 === k && 3 === S.length))
              break;
            if (
              4 === (S += _).length &&
              ((C = A(m, y(S, s, !1), C)), (S = ""), (w = I), C === r)
            )
              break;
          }
        return { bytes: m, read: w, written: C };
      };
    }),
    Rt = n.cw(function (e, t) {
      var n = ae(),
        r = Y(),
        i = n.Uint8Array,
        o = n.SyntaxError,
        s = Math.min,
        a = r("".match);
      e.exports = function (e, t) {
        var n = e.length;
        if (n % 2 != 0)
          throw new o("String should be an even number of characters");
        for (
          var r = t ? s(t.length, n / 2) : n / 2,
            c = t || new i(r),
            d = a(e, /.{2}/g),
            u = 0;
          u < r;
          u++
        ) {
          var l = +("0x" + d[u] + "0");
          if (l != l) throw new o("String should only contain hex characters");
          c[u] = l >> 4;
        }
        return { bytes: c, read: u << 1 };
      };
    }),
    zt = n.cw(function (e, t) {
      var n = bt();
      e.exports = n && !Symbol.sham && "symbol" == typeof Symbol.iterator;
    }),
    Mt = n.cw(function (e, t) {
      var n = M(),
        r = G();
      e.exports =
        n &&
        r(function () {
          return (
            42 !==
            Object.defineProperty(function () {}, "prototype", {
              value: 42,
              writable: !1,
            }).prototype
          );
        });
    }),
    Ot = () => n(445),
    Ft = n.cw(function (e, t) {
      var n = ae(),
        r = ve(),
        i = n.WeakMap;
      e.exports = r(i) && /native code/.test(String(i));
    }),
    Ut = n.cw(function (e, t) {
      var n = ae(),
        r = mt(),
        i = ce(),
        o = xt(),
        s = bt(),
        a = zt(),
        c = n.Symbol,
        d = r("wks"),
        u = a ? c.for || c : (c && c.withoutSetter) || o;
      e.exports = function (e) {
        return i(d, e) || (d[e] = s && i(c, e) ? c[e] : u("Symbol." + e)), d[e];
      };
    }),
    Nt = n.cw(function (e, t) {
      var n = M(),
        r = x(),
        i = h(),
        o = ArrayBuffer.prototype;
      n &&
        !("detached" in o) &&
        r(o, "detached", {
          configurable: !0,
          get: function () {
            return i(this);
          },
        });
    }),
    Lt = n.cw(function (e, t) {
      var n = V(),
        r = g();
      r &&
        n(
          { target: "ArrayBuffer", proto: !0 },
          {
            transferToFixedLength: function () {
              return r(this, arguments.length ? arguments[0] : void 0, !1);
            },
          }
        );
    }),
    jt = n.cw(function (e, t) {
      var n = V(),
        r = g();
      r &&
        n(
          { target: "ArrayBuffer", proto: !0 },
          {
            transfer: function () {
              return r(this, arguments.length ? arguments[0] : void 0, !0);
            },
          }
        );
    }),
    Dt = n.cw(function (e, t) {
      var n = V(),
        r = y().m,
        i = G(),
        o = a(),
        s = i(function () {
          return !Array(1).includes();
        }),
        c = i(function () {
          return [, 1].includes(void 0, 1);
        });
      n(
        { target: "Array", proto: !0, forced: s || c },
        {
          includes: function (e) {
            return r(this, e, arguments.length > 1 ? arguments[1] : void 0);
          },
        }
      ),
        o("includes");
    }),
    Vt = n.cw(function (e, t) {
      var r = V(),
        i = It(),
        o = Oe(),
        s = A(),
        a = n(578);
      r(
        {
          target: "Array",
          proto: !0,
          arity: 1,
          forced:
            G()(function () {
              return 4294967297 !== [].push.call({ length: 4294967296 }, 1);
            }) ||
            !(function () {
              try {
                Object.defineProperty([], "length", { writable: !1 }).push();
              } catch (e) {
                return e instanceof TypeError;
              }
            })(),
        },
        {
          push: function (e) {
            var t = i(this),
              n = o(t),
              r = arguments.length;
            a(n + r);
            for (var c = 0; c < r; c++) (t[n] = arguments[c]), n++;
            return s(t, n), n;
          },
        }
      );
    }),
    Gt = n.cw(function (e, t) {
      var n = V(),
        r = ae(),
        i = c(),
        o = u(),
        s = ve(),
        a = $e(),
        d = x(),
        l = E(),
        p = G(),
        f = ce(),
        h = Ut(),
        m = ze().H,
        g = M(),
        b = Se(),
        v = "constructor",
        y = "Iterator",
        A = h("toStringTag"),
        C = TypeError,
        w = r[y],
        S =
          b ||
          !s(w) ||
          w.prototype !== m ||
          !p(function () {
            w({});
          }),
        I = function () {
          if ((i(this, m), a(this) === m))
            throw new C("Abstract class Iterator not directly constructable");
        },
        _ = function (e, t) {
          g
            ? d(m, e, {
                configurable: !0,
                get: function () {
                  return t;
                },
                set: function (t) {
                  if ((o(this), this === m))
                    throw new C("You can't redefine this property");
                  f(this, e) ? (this[e] = t) : l(this, e, t);
                },
              })
            : (m[e] = t);
        };
      f(m, A) || _(A, y),
        (!S && f(m, v) && m[v] !== Object) || _(v, I),
        (I.prototype = m),
        n({ global: !0, constructor: !0, forced: S }, { Iterator: I });
    }),
    $t = n.cw(function (e, t) {
      var n = V(),
        i = K(),
        o = Pe(),
        s = r(),
        a = u(),
        c = te(),
        d = Ee(),
        l = Re()("every", TypeError);
      n(
        { target: "Iterator", proto: !0, real: !0, forced: l },
        {
          every: function (e) {
            a(this);
            try {
              s(e);
            } catch (e) {
              d(this, "throw", e);
            }
            if (l) return i(l, this, e);
            var t = c(this),
              n = 0;
            return !o(
              t,
              function (t, r) {
                if (!e(t, n++)) return r();
              },
              { IS_RECORD: !0, INTERRUPTED: !0 }
            ).stopped;
          },
        }
      );
    }),
    qt = n.cw(function (e, t) {
      var n = V(),
        i = K(),
        o = r(),
        s = u(),
        a = te(),
        c = xe(),
        d = w(),
        l = Se(),
        p = Ee(),
        f = Te(),
        h = Re(),
        m = !l && !f("filter", function () {}),
        g = !l && !m && h("filter", TypeError),
        b = l || m || g,
        v = c(function () {
          for (
            var e, t, n = this.iterator, r = this.predicate, o = this.next;
            ;

          ) {
            if (((e = s(i(o, n))), (this.done = !!e.done))) return;
            if (((t = e.value), d(n, r, [t, this.counter++], !0))) return t;
          }
        });
      n(
        { target: "Iterator", proto: !0, real: !0, forced: b },
        {
          filter: function (e) {
            s(this);
            try {
              o(e);
            } catch (e) {
              p(this, "throw", e);
            }
            return g ? i(g, this, e) : new v(a(this), { predicate: e });
          },
        }
      );
    }),
    Zt = n.cw(function (e, t) {
      var n = V(),
        i = K(),
        o = Pe(),
        s = r(),
        a = u(),
        c = te(),
        d = Ee(),
        l = Re()("find", TypeError);
      n(
        { target: "Iterator", proto: !0, real: !0, forced: l },
        {
          find: function (e) {
            a(this);
            try {
              s(e);
            } catch (e) {
              d(this, "throw", e);
            }
            if (l) return i(l, this, e);
            var t = c(this),
              n = 0;
            return o(
              t,
              function (t, r) {
                if (e(t, n++)) return r(t);
              },
              { IS_RECORD: !0, INTERRUPTED: !0 }
            ).result;
          },
        }
      );
    }),
    Kt = n.cw(function (e, t) {
      var n = V(),
        i = K(),
        o = r(),
        s = u(),
        a = te(),
        c = ne(),
        d = xe(),
        l = Ee(),
        p = Se(),
        f = Te(),
        h = Re();
      var m = !p && !f("flatMap", function () {}),
        g = !p && !m && h("flatMap", TypeError),
        b =
          p ||
          m ||
          g ||
          (function () {
            try {
              var e = Iterator.prototype.flatMap.call(
                new Map([[4, 5]]).entries(),
                function (e) {
                  return e;
                }
              );
              e.next(), e.return();
            } catch (e) {
              return !0;
            }
          })(),
        v = d(function () {
          for (var e, t, n = this.iterator, r = this.mapper; ; ) {
            if ((t = this.inner))
              try {
                if (!(e = s(i(t.next, t.iterator))).done) return e.value;
                this.inner = null;
              } catch (e) {
                l(n, "throw", e);
              }
            if (((e = s(i(this.next, n))), (this.done = !!e.done))) return;
            try {
              this.inner = c(r(e.value, this.counter++), !1);
            } catch (e) {
              l(n, "throw", e);
            }
          }
        });
      n(
        { target: "Iterator", proto: !0, real: !0, forced: b },
        {
          flatMap: function (e) {
            s(this);
            try {
              o(e);
            } catch (e) {
              l(this, "throw", e);
            }
            return g
              ? i(g, this, e)
              : new v(a(this), { mapper: e, inner: null });
          },
        }
      );
    }),
    Ht = n.cw(function (e, t) {
      var n = V(),
        i = K(),
        o = Pe(),
        s = r(),
        a = u(),
        c = te(),
        d = Ee(),
        l = Re()("forEach", TypeError);
      n(
        { target: "Iterator", proto: !0, real: !0, forced: l },
        {
          forEach: function (e) {
            a(this);
            try {
              s(e);
            } catch (e) {
              d(this, "throw", e);
            }
            if (l) return i(l, this, e);
            var t = c(this),
              n = 0;
            o(
              t,
              function (t) {
                e(t, n++);
              },
              { IS_RECORD: !0 }
            );
          },
        }
      );
    }),
    Wt = n.cw(function (e, t) {
      var n = V(),
        i = K(),
        o = r(),
        s = u(),
        a = te(),
        c = xe(),
        d = w(),
        l = Ee(),
        p = Te(),
        f = Re(),
        h = Se(),
        m = !h && !p("map", function () {}),
        g = !h && !m && f("map", TypeError),
        b = h || m || g,
        v = c(function () {
          var e = this.iterator,
            t = s(i(this.next, e));
          if (!(this.done = !!t.done))
            return d(e, this.mapper, [t.value, this.counter++], !0);
        });
      n(
        { target: "Iterator", proto: !0, real: !0, forced: b },
        {
          map: function (e) {
            s(this);
            try {
              o(e);
            } catch (e) {
              l(this, "throw", e);
            }
            return g ? i(g, this, e) : new v(a(this), { mapper: e });
          },
        }
      );
    }),
    Jt = n.cw(function (e, t) {
      var n = V(),
        i = Pe(),
        o = r(),
        s = u(),
        a = te(),
        c = Ee(),
        d = Re(),
        l = $(),
        p = G(),
        f = TypeError,
        h = p(function () {
          [].keys().reduce(function () {}, void 0);
        }),
        m = !h && d("reduce", f);
      n(
        { target: "Iterator", proto: !0, real: !0, forced: h || m },
        {
          reduce: function (e) {
            s(this);
            try {
              o(e);
            } catch (e) {
              c(this, "throw", e);
            }
            var t = arguments.length < 2,
              n = t ? void 0 : arguments[1];
            if (m) return l(m, this, t ? [e] : [e, n]);
            var r = a(this),
              d = 0;
            if (
              (i(
                r,
                function (r) {
                  t ? ((t = !1), (n = r)) : (n = e(n, r, d)), d++;
                },
                { IS_RECORD: !0 }
              ),
              t)
            )
              throw new f("Reduce of empty iterator with no initial value");
            return n;
          },
        }
      );
    }),
    Yt = n.cw(function (e, t) {
      var n = V(),
        i = K(),
        o = Pe(),
        s = r(),
        a = u(),
        c = te(),
        d = Ee(),
        l = Re()("some", TypeError);
      n(
        { target: "Iterator", proto: !0, real: !0, forced: l },
        {
          some: function (e) {
            a(this);
            try {
              s(e);
            } catch (e) {
              d(this, "throw", e);
            }
            if (l) return i(l, this, e);
            var t = c(this),
              n = 0;
            return o(
              t,
              function (t, r) {
                if (e(t, n++)) return r();
              },
              { IS_RECORD: !0, INTERRUPTED: !0 }
            ).stopped;
          },
        }
      );
    }),
    Qt = n.cw(function (e, t) {
      var n = V(),
        r = M(),
        i = ae(),
        o = ee(),
        s = Y(),
        a = K(),
        c = ve(),
        d = Ce(),
        u = ge(),
        l = ce(),
        p = Bt(),
        f = Oe(),
        h = E(),
        m = G(),
        g = Qe(),
        b = bt(),
        v = i.JSON,
        y = i.Number,
        A = i.SyntaxError,
        C = v && v.parse,
        w = o("Object", "keys"),
        S = Object.getOwnPropertyDescriptor,
        I = s("".charAt),
        _ = s("".slice),
        k = s(/./.exec),
        P = s([].push),
        B = /^\d$/,
        x = /^[1-9]$/,
        T = /^[\d-]$/,
        R = /^[\t\n\r ]$/,
        z = function (e, t, n, r) {
          var i,
            o,
            s,
            c,
            p,
            h = e[t],
            m = r && h === r.value,
            g = m && "string" == typeof r.source ? { source: r.source } : {};
          if (d(h)) {
            var b = u(h),
              v = m ? r.nodes : b ? [] : {};
            if (b)
              for (i = v.length, s = f(h), c = 0; c < s; c++)
                O(h, c, z(h, "" + c, n, c < i ? v[c] : void 0));
            else
              for (o = w(h), s = f(o), c = 0; c < s; c++)
                (p = o[c]), O(h, p, z(h, p, n, l(v, p) ? v[p] : void 0));
          }
          return a(n, e, t, h, g);
        },
        O = function (e, t, n) {
          if (r) {
            var i = S(e, t);
            if (i && !i.configurable) return;
          }
          void 0 === n ? delete e[t] : h(e, t, n);
        },
        F = function (e, t, n, r) {
          (this.value = e), (this.end = t), (this.source = n), (this.nodes = r);
        },
        U = function (e, t) {
          (this.source = e), (this.index = t);
        };
      U.prototype = {
        fork: function (e) {
          return new U(this.source, e);
        },
        parse: function () {
          var e = this.source,
            t = this.skip(R, this.index),
            n = this.fork(t),
            r = I(e, t);
          if (k(T, r)) return n.number();
          switch (r) {
            case "{":
              return n.object();
            case "[":
              return n.array();
            case '"':
              return n.string();
            case "t":
              return n.keyword(!0);
            case "f":
              return n.keyword(!1);
            case "n":
              return n.keyword(null);
          }
          throw new A('Unexpected character: "' + r + '" at: ' + t);
        },
        node: function (e, t, n, r, i) {
          return new F(t, r, e ? null : _(this.source, n, r), i);
        },
        object: function () {
          for (
            var e = this.source,
              t = this.index + 1,
              n = !1,
              r = {},
              i = {},
              o = !1;
            t < e.length;

          ) {
            if (((t = this.until(['"', "}"], t)), "}" === I(e, t) && !n)) {
              t++, (o = !0);
              break;
            }
            var s = this.fork(t).string(),
              a = s.value;
            (t = s.end),
              (t = this.until([":"], t) + 1),
              (t = this.skip(R, t)),
              (s = this.fork(t).parse()),
              h(i, a, s),
              h(r, a, s.value),
              (t = this.until([",", "}"], s.end));
            var c = I(e, t);
            if ("," === c) (n = !0), t++;
            else if ("}" === c) {
              t++, (o = !0);
              break;
            }
          }
          if (!o) throw new A("Unterminated object at: " + t);
          return this.node(1, r, this.index, t, i);
        },
        array: function () {
          for (
            var e = this.source,
              t = this.index + 1,
              n = !1,
              r = [],
              i = [],
              o = !1;
            t < e.length;

          ) {
            if (((t = this.skip(R, t)), "]" === I(e, t) && !n)) {
              t++, (o = !0);
              break;
            }
            var s = this.fork(t).parse();
            if (
              (P(i, s),
              P(r, s.value),
              (t = this.until([",", "]"], s.end)),
              "," === I(e, t))
            )
              (n = !0), t++;
            else if ("]" === I(e, t)) {
              t++, (o = !0);
              break;
            }
          }
          if (!o) throw new A("Unterminated array at: " + t);
          return this.node(1, r, this.index, t, i);
        },
        string: function () {
          var e = this.index,
            t = g(this.source, this.index + 1);
          return this.node(0, t.value, e, t.end);
        },
        number: function () {
          var e = this.source,
            t = this.index,
            n = t;
          if (("-" === I(e, n) && n++, "0" === I(e, n))) n++;
          else {
            if (!k(x, I(e, n))) throw new A("Failed to parse number at: " + n);
            n = this.skip(B, n + 1);
          }
          if ("." === I(e, n)) {
            var r = n + 1;
            if (r === (n = this.skip(B, r)))
              throw new A("Failed to parse number's fraction at: " + n);
          }
          if (
            ("e" === I(e, n) || "E" === I(e, n)) &&
            (n++,
            ("+" !== I(e, n) && "-" !== I(e, n)) || n++,
            n === (n = this.skip(B, n)))
          )
            throw new A("Failed to parse number's exponent value at: " + n);
          return this.node(0, y(_(e, t, n)), t, n);
        },
        keyword: function (e) {
          var t = "" + e,
            n = this.index,
            r = n + t.length;
          if (_(this.source, n, r) !== t)
            throw new A("Failed to parse value at: " + n);
          return this.node(0, e, n, r);
        },
        skip: function (e, t) {
          for (var n = this.source; t < n.length && k(e, I(n, t)); t++);
          return t;
        },
        until: function (e, t) {
          t = this.skip(R, t);
          for (var n = I(this.source, t), r = 0; r < e.length; r++)
            if (e[r] === n) return t;
          throw new A('Unexpected character: "' + n + '" at: ' + t);
        },
      };
      var N = m(function () {
          var e,
            t = "9007199254740993";
          return (
            C(t, function (t, n, r) {
              e = r.source;
            }),
            e !== t
          );
        }),
        L =
          b &&
          !m(function () {
            return 1 / C("-0 \t") != -1 / 0;
          });
      n(
        { target: "JSON", stat: !0, forced: N },
        {
          parse: function (e, t) {
            return L && !c(t)
              ? C(e)
              : (function (e, t) {
                  e = p(e);
                  var n = new U(e, 0, ""),
                    r = n.parse(),
                    i = r.value,
                    o = n.skip(R, r.end);
                  if (o < e.length)
                    throw new A(
                      'Unexpected extra character: "' +
                        I(e, o) +
                        '" after the parsed data at: ' +
                        o
                    );
                  return c(t) ? z({ "": i }, "", t, r) : i;
                })(e, t);
          },
        }
      );
    }),
    Xt = n.cw(function (e, t) {
      var n = V(),
        r = ee(),
        i = $(),
        o = K(),
        s = Y(),
        a = G(),
        c = ge(),
        d = ve(),
        u = Ie(),
        l = _e(),
        p = S(),
        f = Bt(),
        h = C(),
        m = Qe(),
        g = xt(),
        b = bt(),
        v = Ne(),
        y = String,
        A = r("JSON", "stringify"),
        w = s(/./.exec),
        I = s("".charAt),
        _ = s("".charCodeAt),
        k = s("".replace),
        P = s("".slice),
        B = s([].push),
        E = s((1.1).toString),
        x = /[\uD800-\uDFFF]/g,
        T = /^[\uD800-\uDBFF]$/,
        R = /^[\uDC00-\uDFFF]$/,
        z = g(),
        M = z.length,
        O =
          !b ||
          a(function () {
            var e = r("Symbol")("stringify detection");
            return (
              "[null]" !== A([e]) ||
              "{}" !== A({ a: e }) ||
              "{}" !== A(Object(e))
            );
          }),
        F = a(function () {
          return (
            '"\\udf06\\ud834"' !== A("\udf06\ud834") ||
            '"\\udead"' !== A("\udead")
          );
        }),
        U = O
          ? function (e, t) {
              var n = h(arguments),
                r = L(t);
              if (d(r) || (void 0 !== e && !l(e)))
                return (
                  (n[1] = function (e, t) {
                    if ((d(r) && (t = o(r, this, y(e), t)), !l(t))) return t;
                  }),
                  i(A, null, n)
                );
            }
          : A,
        N = function (e, t, n) {
          var r = I(n, t - 1),
            i = I(n, t + 1);
          return (w(T, e) && !w(R, i)) || (w(R, e) && !w(T, r))
            ? "\\u" + E(_(e, 0), 16)
            : e;
        },
        L = function (e) {
          if (d(e)) return e;
          if (c(e)) {
            for (var t = e.length, n = [], r = 0; r < t; r++) {
              var i = e[r];
              "string" == typeof i
                ? B(n, i)
                : ("number" != typeof i &&
                    "Number" !== p(i) &&
                    "String" !== p(i)) ||
                  B(n, f(i));
            }
            var o = n.length,
              s = !0;
            return function (e, t) {
              if (s) return (s = !1), t;
              if (c(this)) return t;
              for (var r = 0; r < o; r++) if (n[r] === e) return t;
            };
          }
        };
      A &&
        n(
          { target: "JSON", stat: !0, arity: 3, forced: O || F || !v },
          {
            stringify: function (e, t, n) {
              var r = L(t),
                i = [],
                s = U(
                  e,
                  function (e, t) {
                    var n = d(r) ? o(r, this, y(e), t) : t;
                    return !v && u(n) ? z + (B(i, n.rawJSON) - 1) : n;
                  },
                  n
                );
              if ("string" != typeof s) return s;
              if ((F && (s = k(s, x, N)), v)) return s;
              for (var a = "", c = s.length, l = 0; l < c; l++) {
                var p = I(s, l);
                if ('"' === p) {
                  var f = m(s, ++l).end - 1,
                    h = P(s, l, f);
                  (a += P(h, 0, M) === z ? i[P(h, M)] : '"' + h + '"'), (l = f);
                } else a += p;
              }
              return a;
            },
          }
        );
    }),
    en = n.cw(function (e, t) {
      var n = V(),
        i = r(),
        o = Ue(),
        s = Se(),
        a = o.get,
        c = o.has,
        d = o.set;
      n(
        { target: "Map", proto: !0, real: !0, forced: s },
        {
          getOrInsertComputed: function (e, t) {
            var n = c(this, e);
            if ((i(t), n)) return a(this, e);
            0 === e && 1 / e == -1 / 0 && (e = 0);
            var r = t(e);
            return d(this, e, r), r;
          },
        }
      );
    }),
    tn = n.cw(function (e, t) {
      var n = V(),
        r = Ue(),
        i = Se(),
        o = r.get,
        s = r.has,
        a = r.set;
      n(
        { target: "Map", proto: !0, real: !0, forced: i },
        {
          getOrInsert: function (e, t) {
            return s(this, e) ? o(this, e) : (a(this, e, t), t);
          },
        }
      );
    }),
    nn = n.cw(function (e, t) {
      var n = V(),
        r = tt(),
        i = G();
      n(
        {
          target: "Set",
          proto: !0,
          real: !0,
          forced:
            !ct()("difference", function (e) {
              return 0 === e.size;
            }) ||
            i(function () {
              var e = {
                  size: 1,
                  has: function () {
                    return !0;
                  },
                  keys: function () {
                    var e = 0;
                    return {
                      next: function () {
                        var n = e++ > 1;
                        return t.has(1) && t.clear(), { done: n, value: 2 };
                      },
                    };
                  },
                },
                t = new Set([1, 2, 3, 4]);
              return 3 !== t.difference(e).size;
            }),
        },
        { difference: r }
      );
    }),
    rn = n.cw(function (e, t) {
      var n = V(),
        r = G(),
        i = rt();
      n(
        {
          target: "Set",
          proto: !0,
          real: !0,
          forced:
            !ct()("intersection", function (e) {
              return 2 === e.size && e.has(1) && e.has(2);
            }) ||
            r(function () {
              return (
                "3,2" !==
                String(
                  Array.from(new Set([1, 2, 3]).intersection(new Set([3, 2])))
                )
              );
            }),
        },
        { intersection: i }
      );
    }),
    on = n.cw(function (e, t) {
      var n = V(),
        r = it();
      n(
        {
          target: "Set",
          proto: !0,
          real: !0,
          forced: !ct()("isDisjointFrom", function (e) {
            return !e;
          }),
        },
        { isDisjointFrom: r }
      );
    }),
    sn = n.cw(function (e, t) {
      var n = V(),
        r = ot();
      n(
        {
          target: "Set",
          proto: !0,
          real: !0,
          forced: !ct()("isSubsetOf", function (e) {
            return e;
          }),
        },
        { isSubsetOf: r }
      );
    }),
    an = n.cw(function (e, t) {
      var n = V(),
        r = st();
      n(
        {
          target: "Set",
          proto: !0,
          real: !0,
          forced: !ct()("isSupersetOf", function (e) {
            return !e;
          }),
        },
        { isSupersetOf: r }
      );
    }),
    cn = n.cw(function (e, t) {
      var n = V(),
        r = lt(),
        i = dt();
      n(
        {
          target: "Set",
          proto: !0,
          real: !0,
          forced: !ct()("symmetricDifference") || !i("symmetricDifference"),
        },
        { symmetricDifference: r }
      );
    }),
    dn = n.cw(function (e, t) {
      var n = V(),
        r = pt(),
        i = dt();
      n(
        {
          target: "Set",
          proto: !0,
          real: !0,
          forced: !ct()("union") || !i("union"),
        },
        { union: r }
      );
    }),
    un = n.cw(function (e, t) {
      var n = Oe(),
        r = b(),
        i = r.aTypedArray,
        o = r.exportTypedArrayMethod,
        s = r.getTypedArrayConstructor;
      o("toReversed", function () {
        for (var e = i(this), t = n(e), r = new (s(e))(t), o = 0; o < t; o++)
          r[o] = e[t - o - 1];
        return r;
      });
    }),
    ln = n.cw(function (e, t) {
      var n = b(),
        i = Y(),
        o = r(),
        s = v(),
        a = n.aTypedArray,
        c = n.getTypedArrayConstructor,
        d = n.exportTypedArrayMethod,
        u = i(n.TypedArrayPrototype.sort);
      d("toSorted", function (e) {
        void 0 !== e && o(e);
        var t = a(this),
          n = s(c(t), t);
        return u(n, e);
      });
    }),
    pn = n.cw(function (e, t) {
      var n = b(),
        r = be(),
        i = Oe(),
        o = wt(),
        s = yt(),
        a = n.aTypedArray,
        c = n.getTypedArrayConstructor,
        d = n.exportTypedArrayMethod,
        u = RangeError,
        l = (function () {
          try {
            new Int8Array(1).with(2, {
              valueOf: function () {
                throw 8;
              },
            });
          } catch (e) {
            return 8 === e;
          }
        })(),
        p =
          l &&
          (function () {
            try {
              new Int8Array(1).with(-0.5, 1);
            } catch (e) {
              return !0;
            }
          })();
      d(
        "with",
        {
          with: function (e, t) {
            var n = a(this),
              d = i(n),
              l = o(e),
              p = l < 0 ? d + l : l,
              f = r(n) ? s(t) : +t;
            if (p >= d || p < 0) throw new u("Incorrect index");
            for (var h = new (c(n))(d), m = 0; m < d; m++)
              h[m] = m === p ? f : n[m];
            return h;
          },
        }.with,
        !l || p
      );
    }),
    fn = n.cw(function (e, t) {
      var n = V(),
        r = ae(),
        i = Tt(),
        o = l(),
        s = r.Uint8Array,
        a =
          !s ||
          !s.prototype.setFromBase64 ||
          !(function () {
            var e = new s([255, 255, 255, 255, 255]);
            try {
              return void e.setFromBase64("", null);
            } catch (e) {}
            try {
              return void e.setFromBase64("a");
            } catch (e) {}
            try {
              e.setFromBase64("MjYyZg===");
            } catch (t) {
              return (
                50 === e[0] &&
                54 === e[1] &&
                50 === e[2] &&
                255 === e[3] &&
                255 === e[4]
              );
            }
          })();
      s &&
        n(
          { target: "Uint8Array", proto: !0, forced: a },
          {
            setFromBase64: function (e) {
              o(this);
              var t = i(
                e,
                arguments.length > 1 ? arguments[1] : void 0,
                this,
                this.length
              );
              return { read: t.read, written: t.written };
            },
          }
        );
    }),
    hn = n.cw(function (e, t) {
      var n = V(),
        r = ae(),
        i = s(),
        o = l(),
        a = m(),
        c = Rt();
      r.Uint8Array &&
        n(
          {
            target: "Uint8Array",
            proto: !0,
            forced: (function () {
              try {
                var e = new ArrayBuffer(16, { maxByteLength: 1024 });
                new Uint8Array(e).setFromHex("cafed00d");
              } catch (e) {
                return !0;
              }
            })(),
          },
          {
            setFromHex: function (e) {
              o(this), i(e), a(this.buffer);
              var t = c(e, this).read;
              return { read: t, written: t / 2 };
            },
          }
        );
    }),
    mn = n.cw(function (e, t) {
      var n = V(),
        r = ae(),
        i = Y(),
        o = d(),
        s = l(),
        a = m(),
        c = kr(),
        u = Q(),
        p = c.i2c,
        f = c.i2cUrl,
        h = i("".charAt),
        g = r.Uint8Array,
        b =
          !g ||
          !g.prototype.toBase64 ||
          !(function () {
            try {
              new g().toBase64(null);
            } catch (e) {
              return !0;
            }
          })();
      g &&
        n(
          { target: "Uint8Array", proto: !0, forced: b },
          {
            toBase64: function () {
              var e = s(this),
                t = arguments.length ? o(arguments[0]) : void 0,
                n = "base64" === u(t) ? p : f,
                r = !!t && !!t.omitPadding;
              a(this.buffer);
              for (
                var i,
                  c = "",
                  d = 0,
                  l = e.length,
                  m = function (e) {
                    return h(n, (i >> (6 * e)) & 63);
                  };
                d + 2 < l;
                d += 3
              )
                (i = (e[d] << 16) + (e[d + 1] << 8) + e[d + 2]),
                  (c += m(3) + m(2) + m(1) + m(0));
              return (
                d + 2 === l
                  ? ((i = (e[d] << 16) + (e[d + 1] << 8)),
                    (c += m(3) + m(2) + m(1) + (r ? "" : "=")))
                  : d + 1 === l &&
                    ((i = e[d] << 16), (c += m(3) + m(2) + (r ? "" : "=="))),
                c
              );
            },
          }
        );
    }),
    gn = n.cw(function (e, t) {
      var n = V(),
        r = ae(),
        i = Y(),
        o = l(),
        s = m(),
        a = i((1.1).toString),
        c = i([].join),
        d = Array,
        u = r.Uint8Array,
        p =
          !u ||
          !u.prototype.toHex ||
          !(function () {
            try {
              return (
                "ffffffffffffffff" ===
                new u([255, 255, 255, 255, 255, 255, 255, 255]).toHex()
              );
            } catch (e) {
              return !1;
            }
          })();
      u &&
        n(
          { target: "Uint8Array", proto: !0, forced: p },
          {
            toHex: function () {
              o(this), s(this.buffer);
              for (var e = d(this.length), t = 0, n = this.length; t < n; t++) {
                var r = a(this[t], 16);
                e[t] = 1 === r.length ? "0" + r : r;
              }
              return c(e, "");
            },
          }
        );
    }),
    bn = n.cw(function (e, t) {
      Qt();
    }),
    vn = n.cw(function (e, t) {
      en();
    }),
    yn = n.cw(function (e, t) {
      tn();
    }),
    An = n.cw(function (e, t) {
      fn();
    }),
    Cn = n.cw(function (e, t) {
      hn();
    }),
    wn = n.cw(function (e, t) {
      mn();
    }),
    Sn = n.cw(function (e, t) {
      gn();
    }),
    In = n.cw(function (e, t) {
      var n = T(),
        r = Y(),
        i = Bt(),
        o = Ot(),
        s = URLSearchParams,
        a = s.prototype,
        c = r(a.append),
        d = r(a.delete),
        u = r(a.forEach),
        l = r([].push),
        p = new s("a=1&a=2&b=3");
      p.delete("a", 1),
        p.delete("b", void 0),
        p + "" != "a=2" &&
          n(
            a,
            "delete",
            function (e) {
              var t = arguments.length,
                n = t < 2 ? void 0 : arguments[1];
              if (t && void 0 === n) return d(this, e);
              var r = [];
              u(this, function (e, t) {
                l(r, { key: t, value: e });
              }),
                o(t, 1);
              for (var s, a = i(e), p = i(n), f = 0, h = r.length; f < h; )
                d(this, (s = r[f]).key), f++;
              for (f = 0; f < h; )
                ((s = r[f++]).key === a && s.value === p) ||
                  c(this, s.key, s.value);
            },
            { enumerable: !0, unsafe: !0 }
          );
    }),
    _n = n.cw(function (e, t) {
      var n = T(),
        r = Y(),
        i = Bt(),
        o = Ot(),
        s = URLSearchParams,
        a = s.prototype,
        c = r(a.getAll),
        d = r(a.has),
        u = new s("a=1");
      (!u.has("a", 2) && u.has("a", void 0)) ||
        n(
          a,
          "has",
          function (e) {
            var t = arguments.length,
              n = t < 2 ? void 0 : arguments[1];
            if (t && void 0 === n) return d(this, e);
            var r = c(this, e);
            o(t, 1);
            for (var s = i(n), a = 0; a < r.length; )
              if (r[a++] === s) return !0;
            return !1;
          },
          { enumerable: !0, unsafe: !0 }
        );
    }),
    kn = n.cw(function (e, t) {
      var n = M(),
        r = Y(),
        i = x(),
        o = URLSearchParams.prototype,
        s = r(o.forEach);
      n &&
        !("size" in o) &&
        i(o, "size", {
          get: function () {
            var e = 0;
            return (
              s(this, function () {
                e++;
              }),
              e
            );
          },
          configurable: !0,
          enumerable: !0,
        });
    });
  function Pn() {
    return Pn.c || (Pn.c = n.t(n(156), 2));
  }
  function Bn() {
    return Bn.c || (Bn.c = n.t(Me(), 2));
  }
  Vt(), Gt(), Wt(), Yt(), Xt(), yn(), vn();
  const En = {
      advertising: {
        bidders: {
          rubicon: { bidder: "rubicon", accountId: "16980", siteId: "152672" },
          msft: { bidder: "msft" },
          ix: { bidder: "ix" },
          pubmatic: { bidder: "pubmatic", publisherId: "156561" },
          amazon: {
            bidder: "amazon",
            pubID: "9e9bffbc-66c5-4b5b-89aa-4d839e05ce3a",
            adServer: "googletag",
          },
          adsense: { bidder: "adsense", client: "ca-pub-8415986145297288" },
          equativ: { bidder: "equativ", networkId: 3888 },
          aps: { bidder: "aps" },
          google: { bidder: "google" },
          ozone: {
            bidder: "ozone",
            siteId: "1500000645",
            publisherId: "OZONECG00001",
          },
          ttd: {
            bidder: "ttd",
            supplySourceId: "direct9hdbp5v4",
            publisherId: "1",
          },
          nexx360: { bidder: "nexx360" },
          kargo: { bidder: "kargo" },
          medianet: { bidder: "medianet", cid: "8CUYL2RS6" },
        },
      },
      houseAds: { advertiserIds: [134924547] },
    },
    xn = En.houseAds;
  function Tn() {
    return En.advertising.bidders.amazon.pubID;
  }
  function Rn(e) {
    return null != e;
  }
  class zn {
    static instance = void 0;
    static getInstance() {
      return Rn(this.instance) || (this.instance = new zn()), this.instance;
    }
    static reset() {
      this.instance = void 0;
    }
    prebidFullyLoaded = !1;
    constructor() {
      const e = window;
      (e.pbjs = e.pbjs || { que: [] }),
        (e.pbjs.que = e.pbjs.que || []),
        e.pbjs.que.push(() => {
          this.prebidFullyLoaded = !0;
        });
    }
    getPbjsOrThrow() {
      if (!this.prebidFullyLoaded) throw new Error("Prebid is still loading");
      return window.pbjs;
    }
    getPbjs() {
      if (this.prebidFullyLoaded) return this.getPbjsOrThrow();
    }
    getPbjsQueue() {
      return window.pbjs;
    }
  }
  function Mn() {
    return zn.getInstance().getPbjsQueue();
  }
  function On() {
    return zn.getInstance().getPbjs();
  }
  function Fn() {
    return zn.getInstance().getPbjsOrThrow();
  }
  class Un {
    static instance = void 0;
    static getInstance() {
      return Rn(this.instance) || (this.instance = new Un()), this.instance;
    }
    googletagFullyLoaded = !1;
    constructor() {
      const e = window;
      (e.googletag = e.googletag || { cmd: [] }),
        (e.googletag.cmd = e.googletag.cmd || []),
        e.googletag.cmd.push(() => {
          this.googletagFullyLoaded = !0;
        });
    }
    getGoogletagOrThrow() {
      if (!this.googletagFullyLoaded)
        throw new Error("googletag is still loading");
      return window.googletag;
    }
    getGoogletag() {
      if (this.googletagFullyLoaded) return this.getGoogletagOrThrow();
    }
    getGoogletagCmd() {
      return window.googletag;
    }
  }
  function Nn() {
    return Un.getInstance().getGoogletagCmd();
  }
  function Ln() {
    return Un.getInstance().getGoogletag();
  }
  function jn() {
    return Un.getInstance().getGoogletagOrThrow();
  }
  function Dn() {
    return Vn.getInstance().getApsTag();
  }
  class Vn {
    static instance = void 0;
    static getInstance() {
      return Rn(this.instance) || (this.instance = new Vn()), this.instance;
    }
    constructor() {
      var e = this;
      this.accountId = Tn();
      const t = window,
        n = (function () {
          let n =
            arguments.length > 0 && void 0 !== arguments[0]
              ? arguments[0]
              : e.accountId;
          (t._aps = t._aps || new Map()),
            t._aps.has(n) ||
              t._aps.set(n, {
                queue: [],
                store: new Map([["listeners", new Map()]]),
              });
          const r = {
            accountID: n,
            record: function (e, n) {
              return new Promise((r, i) => {
                t._aps
                  .get(this.accountID)
                  .queue.push(
                    new CustomEvent(e, {
                      detail: { ...n, resolve: r, reject: i },
                    })
                  );
              });
            },
            read: function (e) {
              return (
                this.record("bootstrap/store/willRead", { name: e }),
                t._aps.get(this.accountID).store.get(e)
              );
            },
            run: function (e, n) {
              t._aps.get("_system")?.store.get("listeners")?.has(e)
                ? this.record(e, n)
                : this.record("bootstrap/run/willDrop", { name: e, detail: n });
            },
            react: function (e, n) {
              t._aps.get(this.accountID).store.get("listeners").set(e, n),
                this.record("bootstrap/react/didExecute", { name: e });
            },
          };
          return r.record("bootstrap/version/declare", { version: 5 }), r;
        })();
      (t.aps = t.aps || n),
        (function () {
          const e = window.aps;
          (function () {
            let t =
              arguments.length > 0 && void 0 !== arguments[0]
                ? arguments[0]
                : e;
            (window.apstag = window.apstag || {
              init: function (e, n) {
                t.record("legacy/init/enqueue", { config: e, callback: n });
              },
              fetchBids: function (e, n) {
                t.record("legacy/fetchBids/enqueue", {
                  bidConfig: e,
                  callback: n,
                });
              },
              setDisplayBids: function () {
                t.run("legacy/setDisplayBids/enqueue", { arguments });
              },
              targetingKeys: function () {
                return t.read("legacy/targetingKeys") ?? [];
              },
              rpa: function (e, n, r) {
                t.record("legacy/rpa/enqueue", {
                  tokenConfig: e,
                  callback: n,
                  setCookie: r,
                });
              },
              upa: function (e, n, r) {
                t.record("legacy/upa/enqueue", {
                  tokenConfig: e,
                  callback: n,
                  setCookie: r,
                });
              },
              dpa: function (e) {
                t.record("legacy/dpa/enqueue", { callback: e });
              },
            }),
              t.record("bootstrapExtAPStag/version/declare", { version: 1 });
          })(),
            (function () {
              let t =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : e;
              (window.apstag = {
                ...window.apstag,
                queue: {
                  push: function (e) {
                    t.record("legacy/queue/push", { callback: e });
                  },
                },
              }),
                t.record("bootstrapExtQueue/version/declare", { version: 1 });
            })(),
            (function () {
              let t =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : e;
              (window.apstag = {
                ...window.apstag,
                customPlacements: function () {
                  return {
                    hint: function (e, n, r) {
                      t.record("customPlacement/hint/define", {
                        id: e,
                        isDefault: n,
                        hintMetadata: r,
                      });
                    },
                    enable: function () {
                      t.record("customPlacement/service/enable");
                    },
                    addEventListener: function (e, n) {
                      if ("PlacementResponse" !== e)
                        throw new Error("Unsupported event type");
                      t.react("customPlacement/placement/didRespond", n);
                    },
                  };
                },
              }),
                t.record("bootstrapExtASR/version/declare", { version: 1 });
            })(),
            (function () {
              let t =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : e;
              (window.apstag = {
                ...window.apstag,
                nativeContent: function () {
                  return {
                    enable: function () {
                      t.record("nativeCommerceAds/service/enable");
                    },
                    registerHook: function (e, n) {
                      if ("nativeCommerceAds.updateClickUrl" !== e)
                        throw new Error("Unsupported event type");
                      t.react("nativeCommerceAds/clickUrl/update", (e) => ({
                        status: "completed",
                        value: { url: n(e?.detail?.url, e?.detail?.element) },
                      }));
                    },
                  };
                },
              }),
                t.record("bootstrapExtNCA/version/declare", { version: 1 });
            })();
        })();
    }
    getApsTag() {
      return window.apstag;
    }
  }
  class Gn {
    static instance = void 0;
    constructor() {
      const e = window;
      e.adsbygoogle = e.adsbygoogle || [];
    }
    static getInstance() {
      return Rn(this.instance) || (this.instance = new Gn()), this.instance;
    }
    getAdsenseWindow() {
      return window.adsbygoogle;
    }
  }
  Dt(), qt(), Jt(), In(), _n(), kn();
  const $n = "_enabled";
  const qn = new (class {
      constructor() {
        this.debugEnabled = this.isDebugEnabled();
      }
      debug(e) {
        if (this.debugEnabled) {
          for (
            var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1;
            r < t;
            r++
          )
            n[r - 1] = arguments[r];
          console.log(e, ...n);
        }
      }
      log(e) {
        for (
          var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1;
          r < t;
          r++
        )
          n[r - 1] = arguments[r];
        console.log(e, ...n);
      }
      warn(e) {
        for (
          var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1;
          r < t;
          r++
        )
          n[r - 1] = arguments[r];
        console.warn(e, ...n);
      }
      error(e) {
        for (
          var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1;
          r < t;
          r++
        )
          n[r - 1] = arguments[r];
        console.error(e, ...n);
      }
      isDebugEnabled() {
        return !(window.location.search.indexOf("raf_debug=true") < 0);
      }
    })(),
    Zn = qn;
  Zt(), Ht();
  const Kn = "num_disabled_prebid",
    Hn = "num_disabled_amazon",
    Wn = "bidders_enabled",
    Jn = "bidders_disabled",
    Yn = "idproviders_enabled",
    Qn = "idproviders_disabled",
    Xn = "cmp",
    er = "impression_number",
    tr = "pf",
    nr = "pubf",
    rr = "hch",
    ir = "mch",
    or = "bic",
    sr = "amznactt",
    ar = "amznbid",
    cr = "amzniid",
    dr = "amznp",
    ur = "amznsz",
    lr = "cmpInstalled",
    pr = [
      "ix",
      "rubicon",
      "pubmatic",
      "ozone",
      "ttd",
      "nexx360",
      "medianet",
      "equativ",
      "msft",
      "aps",
      "kargo",
    ],
    fr = ["google", "amazon", "adsense", ...pr],
    hr = "AADummyBidder",
    mr = [
      "criteo",
      "unifiedId",
      "id5Id",
      "sharedId",
      "lotamePanoramaId",
      "hadronId",
      "pubProvidedId",
      "uid2",
      "liveIntentId",
      "identityLink",
      "pairId",
      "33acrossId",
      "euid",
      "publinkId",
    ],
    gr = "AADummyIdProvider",
    br = Object.values({
      ix: "138241895930",
      pubmatic: "138241896683",
      rubicon: "138241885337",
      ozone: "138520313072",
      ttd: "138516025707",
      nexx360: "138520677054",
      medianet: "138526849982",
      kargo: "138580341083",
      equativ: "138558968808",
      msft: "138542222315",
      aps: "138562020128",
    }).filter((e) => null !== e),
    vr = [
      "138340379973",
      "138340379976",
      "138340320638",
      "138340379970",
      "138340320629",
      "138340320635",
      "138340379967",
      "138340379961",
      "138340379964",
      "138340320632",
    ],
    yr = {
      ix: 4549429876,
      pubmatic: 4549430140,
      rubicon: 4463421243,
      ozone: 5756846298,
      ttd: 5132644227,
      nexx360: 5834208923,
      medianet: 5868421578,
      kargo: 6158067996,
      equativ: 6076567857,
      msft: 5969435016,
      aps: 4569251936,
    },
    Ar = yr.aps;
  const Cr = class {
    disabledBidder = null;
    actualCandidates = [];
    constructor(e, t) {
      if (Rn(t))
        Zn.warn(
          "[IncrementalBidderTest] Testing info should only be used for testing purposes"
        ),
          (this.candidates = t.candidates),
          (this.disabledBidder = t.disabledBidder);
      else {
        (this.candidates = [...pr, "amazon", hr, ...e]),
          this.actualCandidates.push(hr);
        const t = 0.005 * this.candidates.length;
        Math.random() < t &&
          (this.disabledBidder =
            this.candidates[
              Math.floor(Math.random() * this.candidates.length)
            ]);
      }
      const n = this.getForcedDisabledBidder(this.candidates);
      Rn(n)
        ? ((this.disabledBidder = n),
          Zn.debug(
            `Incremental bidder test forced disabled bidder via search param: ${this.disabledBidder}`
          ))
        : Zn.debug(
            `Incremental bidder test initialized with disabled bidder: ${this.disabledBidder}`
          );
    }
    getForcedDisabledBidder(e) {
      const t = new URLSearchParams(window.location.search).get(
        "force_disabled_bidder"
      );
      return Rn(t) ? e.find((e) => e === t) ?? null : null;
    }
    isBidderDisabled(e) {
      return this.disabledBidder === e;
    }
    addToActualCandidates(e) {
      this.candidates.includes(e) && this.actualCandidates.push(e);
    }
    getGamKeys() {
      const e = {},
        t = [],
        n = [];
      return (
        this.actualCandidates.forEach((e) => {
          this.isBidderDisabled(e) ? n.push(e) : t.push(e);
        }),
        t.length > 0 && (e[Wn] = t),
        n.length > 0 && (e[Jn] = n),
        e
      );
    }
  };
  function wr(e, t) {
    const n = new Set();
    if ((Rn(e.country) && e.country.forEach((e) => n.add(e)), Rn(e.region)))
      for (const r of e.region) {
        const e = t[r];
        Rn(e) && e.countries.forEach((e) => n.add(e));
      }
    if (Rn(e.partialRegion))
      for (const r of e.partialRegion) {
        const e = t[r.region];
        Rn(e) &&
          e.countries
            .filter((e) => !r.excluded_countries.includes(e))
            .forEach((e) => n.add(e));
      }
    if (0 !== n.size) return [...n];
  }
  function Sr(e) {
    const t = e.regions ?? {};
    return Object.entries(e.bidders).reduce(
      (e, [n, r]) => (
        "comment" === n ||
          (e[n] = (function (e, t) {
            return {
              rules: e.rules.map((n) => Ir(n, e.cost, e.discrepancy, t)),
            };
          })(r, t)),
        e
      ),
      {}
    );
  }
  function Ir(e, t, n, r) {
    return {
      enabled: e.enabled,
      gamKey: e.gamKey,
      cost: _r(e.cost, t, 0),
      discrepancy: _r(e.discrepancy, n, 0),
      conditions: Rn(e.conditions)
        ? {
            country: wr(e.conditions, r),
            adFormat: e.conditions.adFormat,
            browser: e.conditions.browser,
            device: e.conditions.device,
            locale: e.conditions.locale,
          }
        : void 0,
    };
  }
  function _r(e, t, n) {
    return Rn(e) ? e : Rn(t) ? t : n;
  }
  function kr() {
    return kr.c || (kr.c = n.t(n(960), 2));
  }
  async function Pr(e) {
    const t = new TextEncoder().encode(e),
      n = await crypto.subtle.digest("SHA-256", t);
    return Array.from(new Uint8Array(n))
      .map((e) => e.toString(16).padStart(2, "0"))
      .join("");
  }
  Nt(), jt(), Lt(), un(), ln(), pn(), An(), Cn(), wn(), Sn();
  class Br {
    static instance = null;
    static getInstance() {
      return Rn(this.instance) || (this.instance = new Br()), this.instance;
    }
    _clientInfo = {};
    _email = void 0;
    _emailHash = void 0;
    _userId = void 0;
    _userIdHash = void 0;
    _emailListeners = [];
    _userIdListeners = [];
    constructor() {}
    initClientInfo(e) {
      (this._clientInfo = e),
        (function (e) {
          const t = [];
          Rn(e.country) || t.push("country");
          Rn(e.device) || t.push("device");
          Rn(e.locale) || t.push("locale");
          Rn(e.browser) || t.push("browser");
          t.length > 0 && Zn.warn(`Missing client info: ${t.join(", ")}.`);
        })(this._clientInfo);
    }
    async updateEmail(e) {
      const t = this.email;
      (this._email = Rn(e) ? e : void 0),
        t !== e &&
          ((this._emailHash = Rn(e) ? await Pr(e) : void 0),
          this._emailListeners.forEach((e) => e(t, this.email)));
    }
    async updateUserId(e) {
      const t = this.userId;
      (this._userId = Rn(e) ? e : void 0),
        t !== e &&
          ((this._userIdHash = Rn(e) ? await Pr(e) : void 0),
          this._userIdListeners.forEach((e) => e(t, this.userId)));
    }
    get clientInfo() {
      return this._clientInfo;
    }
    get email() {
      return this._email;
    }
    get emailHash() {
      return this._emailHash;
    }
    get userId() {
      return this._userId;
    }
    get userIdHash() {
      return this._userIdHash;
    }
    get emailListenerCount() {
      return this._emailListeners.length;
    }
    get userIdListenerCount() {
      return this._userIdListeners.length;
    }
    addEmailListenerAndInvoke(e) {
      this._emailListeners.push(e), e(void 0, this.email);
    }
    removeEmailListener(e) {
      this._emailListeners = this._emailListeners.filter((t) => t !== e);
    }
    addUserIdListenerAndInvoke(e) {
      this._userIdListeners.push(e), e(void 0, this.userId);
    }
    removeUserIdListener(e) {
      this._userIdListeners = this._userIdListeners.filter((t) => t !== e);
    }
  }
  function Er() {
    return Br.getInstance().clientInfo.country;
  }
  const xr = {
      name: "Argentina",
      isoCode: "AR",
      iso3Code: "ARG",
      gdprApplicable: !1,
      continent: "South America",
      euMember: !1,
      tier: 4,
    },
    Tr = {
      name: "Australia",
      isoCode: "AU",
      iso3Code: "AUS",
      gdprApplicable: !1,
      continent: "Oceania",
      euMember: !1,
      tier: 2,
    },
    Rr = {
      name: "Austria",
      isoCode: "AT",
      iso3Code: "AUT",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 2,
    },
    zr = {
      name: "Belgium",
      isoCode: "BE",
      iso3Code: "BEL",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 2,
    },
    Mr = {
      name: "Belize",
      isoCode: "BZ",
      iso3Code: "BLZ",
      gdprApplicable: !1,
      continent: "North America",
      euMember: !1,
      tier: 4,
    },
    Or = {
      name: "Bolivia",
      isoCode: "BO",
      iso3Code: "BOL",
      gdprApplicable: !1,
      continent: "South America",
      euMember: !1,
      tier: 4,
    },
    Fr = {
      name: "Brazil",
      isoCode: "BR",
      iso3Code: "BRA",
      gdprApplicable: !0,
      continent: "South America",
      euMember: !1,
      tier: 3,
    },
    Ur = {
      name: "Bulgaria",
      isoCode: "BG",
      iso3Code: "BGR",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 4,
    },
    Nr = {
      name: "Canada",
      isoCode: "CA",
      iso3Code: "CAN",
      gdprApplicable: !1,
      continent: "North America",
      euMember: !1,
      tier: 2,
    },
    Lr = {
      name: "Chile",
      isoCode: "CL",
      iso3Code: "CHL",
      gdprApplicable: !1,
      continent: "South America",
      euMember: !1,
      tier: 4,
    },
    jr = {
      name: "Colombia",
      isoCode: "CO",
      iso3Code: "COL",
      gdprApplicable: !1,
      continent: "South America",
      euMember: !1,
      tier: 4,
    },
    Dr = {
      name: "Costa Rica",
      isoCode: "CR",
      iso3Code: "CRI",
      gdprApplicable: !1,
      continent: "North America",
      euMember: !1,
      tier: 4,
    },
    Vr = {
      name: "Croatia",
      isoCode: "HR",
      iso3Code: "HRV",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 4,
    },
    Gr = {
      name: "Cuba",
      isoCode: "CU",
      iso3Code: "CUB",
      gdprApplicable: !1,
      continent: "North America",
      euMember: !1,
      tier: 4,
    },
    $r = {
      name: "Cyprus",
      isoCode: "CY",
      iso3Code: "CYP",
      gdprApplicable: !0,
      continent: "Asia",
      euMember: !0,
      tier: 4,
    },
    qr = {
      name: "Czechia",
      isoCode: "CZ",
      iso3Code: "CZE",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 3,
    },
    Zr = {
      name: "Denmark",
      isoCode: "DK",
      iso3Code: "DNK",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 2,
    },
    Kr = {
      name: "Dominican Republic",
      isoCode: "DO",
      iso3Code: "DOM",
      gdprApplicable: !1,
      continent: "North America",
      euMember: !1,
      tier: 4,
    },
    Hr = {
      name: "Ecuador",
      isoCode: "EC",
      iso3Code: "ECU",
      gdprApplicable: !1,
      continent: "South America",
      euMember: !1,
      tier: 4,
    },
    Wr = {
      name: "El Salvador",
      isoCode: "SV",
      iso3Code: "SLV",
      gdprApplicable: !1,
      continent: "North America",
      euMember: !1,
      tier: 4,
    },
    Jr = {
      name: "Estonia",
      isoCode: "EE",
      iso3Code: "EST",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 4,
    },
    Yr = {
      name: "Finland",
      isoCode: "FI",
      iso3Code: "FIN",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 2,
    },
    Qr = {
      name: "France",
      isoCode: "FR",
      iso3Code: "FRA",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 2,
    },
    Xr = {
      name: "Germany",
      isoCode: "DE",
      iso3Code: "DEU",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 2,
    },
    ei = {
      name: "Greece",
      isoCode: "GR",
      iso3Code: "GRC",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 4,
    },
    ti = {
      name: "Guatemala",
      isoCode: "GT",
      iso3Code: "GTM",
      gdprApplicable: !1,
      continent: "North America",
      euMember: !1,
      tier: 4,
    },
    ni = {
      name: "Honduras",
      isoCode: "HN",
      iso3Code: "HND",
      gdprApplicable: !1,
      continent: "North America",
      euMember: !1,
      tier: 4,
    },
    ri = {
      name: "Hungary",
      isoCode: "HU",
      iso3Code: "HUN",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 4,
    },
    ii = {
      name: "Iceland",
      isoCode: "IS",
      iso3Code: "ISL",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !1,
      tier: 4,
    },
    oi = {
      name: "Ireland",
      isoCode: "IE",
      iso3Code: "IRL",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 4,
    },
    si = {
      name: "Italy",
      isoCode: "IT",
      iso3Code: "ITA",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 2,
    },
    ai = {
      name: "Jamaica",
      isoCode: "JM",
      iso3Code: "JAM",
      gdprApplicable: !1,
      continent: "North America",
      euMember: !1,
      tier: 4,
    },
    ci = {
      name: "Latvia",
      isoCode: "LV",
      iso3Code: "LVA",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 4,
    },
    di = {
      name: "Liechtenstein",
      isoCode: "LI",
      iso3Code: "LIE",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !1,
      tier: 4,
    },
    ui = {
      name: "Lithuania",
      isoCode: "LT",
      iso3Code: "LTU",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 4,
    },
    li = {
      name: "Luxembourg",
      isoCode: "LU",
      iso3Code: "LUX",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 2,
    },
    pi = {
      name: "Malta",
      isoCode: "MT",
      iso3Code: "MLT",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 4,
    },
    fi = {
      name: "Mexico",
      isoCode: "MX",
      iso3Code: "MEX",
      gdprApplicable: !1,
      continent: "North America",
      euMember: !1,
      tier: 3,
    },
    hi = {
      name: "Netherlands",
      isoCode: "NL",
      iso3Code: "NLD",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 2,
    },
    mi = {
      name: "New Zealand",
      isoCode: "NZ",
      iso3Code: "NZL",
      gdprApplicable: !1,
      continent: "Oceania",
      euMember: !1,
      tier: 2,
    },
    gi = {
      name: "Nicaragua",
      isoCode: "NI",
      iso3Code: "NIC",
      gdprApplicable: !1,
      continent: "North America",
      euMember: !1,
      tier: 4,
    },
    bi = {
      name: "Norway",
      isoCode: "NO",
      iso3Code: "NOR",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !1,
      tier: 2,
    },
    vi = {
      name: "Panama",
      isoCode: "PA",
      iso3Code: "PAN",
      gdprApplicable: !1,
      continent: "North America",
      euMember: !1,
      tier: 4,
    },
    yi = {
      name: "Paraguay",
      isoCode: "PY",
      iso3Code: "PRY",
      gdprApplicable: !1,
      continent: "South America",
      euMember: !1,
      tier: 4,
    },
    Ai = {
      name: "Peru",
      isoCode: "PE",
      iso3Code: "PER",
      gdprApplicable: !1,
      continent: "South America",
      euMember: !1,
      tier: 4,
    },
    Ci = {
      name: "Poland",
      isoCode: "PL",
      iso3Code: "POL",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 3,
    },
    wi = {
      name: "Portugal",
      isoCode: "PT",
      iso3Code: "PRT",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 4,
    },
    Si = {
      name: "Romania",
      isoCode: "RO",
      iso3Code: "ROU",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 4,
    },
    Ii = {
      name: "Slovakia",
      isoCode: "SK",
      iso3Code: "SVK",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 4,
    },
    _i = {
      name: "Slovenia",
      isoCode: "SI",
      iso3Code: "SVN",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 4,
    },
    ki = {
      name: "Spain",
      isoCode: "ES",
      iso3Code: "ESP",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 2,
    },
    Pi = {
      name: "Sweden",
      isoCode: "SE",
      iso3Code: "SWE",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !0,
      tier: 2,
    },
    Bi = {
      name: "Switzerland",
      isoCode: "CH",
      iso3Code: "CHE",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !1,
      tier: 2,
    },
    Ei = {
      name: "Trinidad and Tobago",
      isoCode: "TT",
      iso3Code: "TTO",
      gdprApplicable: !1,
      continent: "North America",
      euMember: !1,
      tier: 4,
    },
    xi = {
      name: "United Kingdom",
      isoCode: "GB",
      iso3Code: "GBR",
      gdprApplicable: !0,
      continent: "Europe",
      euMember: !1,
      tier: 2,
    },
    Ti = {
      name: "United States",
      isoCode: "US",
      iso3Code: "USA",
      gdprApplicable: !1,
      continent: "North America",
      euMember: !1,
      tier: 1,
    },
    Ri = {
      name: "Uruguay",
      isoCode: "UY",
      iso3Code: "URY",
      gdprApplicable: !1,
      continent: "South America",
      euMember: !1,
      tier: 4,
    },
    zi = {
      name: "Venezuela",
      isoCode: "VE",
      iso3Code: "VEN",
      gdprApplicable: !1,
      continent: "South America",
      euMember: !1,
      tier: 4,
    },
    Mi = [
      {
        name: "Afghanistan",
        isoCode: "AF",
        iso3Code: "AFG",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Åland Islands",
        isoCode: "AX",
        iso3Code: "ALA",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Albania",
        isoCode: "AL",
        iso3Code: "ALB",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Algeria",
        isoCode: "DZ",
        iso3Code: "DZA",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "American Samoa",
        isoCode: "AS",
        iso3Code: "ASM",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Andorra",
        isoCode: "AD",
        iso3Code: "AND",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Angola",
        isoCode: "AO",
        iso3Code: "AGO",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Anguilla",
        isoCode: "AI",
        iso3Code: "AIA",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Antarctica",
        isoCode: "AQ",
        iso3Code: "ATA",
        gdprApplicable: !1,
        continent: "Antarctica",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Antigua and Barbuda",
        isoCode: "AG",
        iso3Code: "ATG",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      xr,
      {
        name: "Armenia",
        isoCode: "AM",
        iso3Code: "ARM",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Aruba",
        isoCode: "AW",
        iso3Code: "ABW",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      Tr,
      Rr,
      {
        name: "Azerbaijan",
        isoCode: "AZ",
        iso3Code: "AZE",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Bahamas",
        isoCode: "BS",
        iso3Code: "BHS",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Bahrain",
        isoCode: "BH",
        iso3Code: "BHR",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Bangladesh",
        isoCode: "BD",
        iso3Code: "BGD",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Barbados",
        isoCode: "BB",
        iso3Code: "BRB",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Belarus",
        isoCode: "BY",
        iso3Code: "BLR",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      zr,
      Mr,
      {
        name: "Benin",
        isoCode: "BJ",
        iso3Code: "BEN",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Bermuda",
        isoCode: "BM",
        iso3Code: "BMU",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Bhutan",
        isoCode: "BT",
        iso3Code: "BTN",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      Or,
      {
        name: "Bonaire, Sint Eustatius and Saba",
        isoCode: "BQ",
        iso3Code: "BES",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Bosnia and Herzegovina",
        isoCode: "BA",
        iso3Code: "BIH",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Botswana",
        isoCode: "BW",
        iso3Code: "BWA",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Bouvet Island",
        isoCode: "BV",
        iso3Code: "BVT",
        gdprApplicable: !1,
        continent: "Antarctica",
        euMember: !1,
        tier: 4,
      },
      Fr,
      {
        name: "British Indian Ocean Territory",
        isoCode: "IO",
        iso3Code: "IOT",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Brunei Darussalam",
        isoCode: "BN",
        iso3Code: "BRN",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      Ur,
      {
        name: "Burkina Faso",
        isoCode: "BF",
        iso3Code: "BFA",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Burundi",
        isoCode: "BI",
        iso3Code: "BDI",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Cabo Verde",
        isoCode: "CV",
        iso3Code: "CPV",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Cambodia",
        isoCode: "KH",
        iso3Code: "KHM",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Cameroon",
        isoCode: "CM",
        iso3Code: "CMR",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      Nr,
      {
        name: "Cayman Islands",
        isoCode: "KY",
        iso3Code: "CYM",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Central African Republic",
        isoCode: "CF",
        iso3Code: "CAF",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Chad",
        isoCode: "TD",
        iso3Code: "TCD",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      Lr,
      {
        name: "China",
        isoCode: "CN",
        iso3Code: "CHN",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Christmas Island",
        isoCode: "CX",
        iso3Code: "CXR",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Cocos (Keeling) Islands",
        isoCode: "CC",
        iso3Code: "CCK",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      jr,
      {
        name: "Comoros",
        isoCode: "KM",
        iso3Code: "COM",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Republic of the Congo",
        isoCode: "CG",
        iso3Code: "COG",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Democratic Republic of the Congo",
        isoCode: "CD",
        iso3Code: "COD",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Cook Islands",
        isoCode: "CK",
        iso3Code: "COK",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      Dr,
      {
        name: 'Cote D"Ivoire',
        isoCode: "CI",
        iso3Code: "CIV",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      Vr,
      Gr,
      {
        name: "Curaçao",
        isoCode: "CW",
        iso3Code: "CUW",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      $r,
      qr,
      Zr,
      {
        name: "Djibouti",
        isoCode: "DJ",
        iso3Code: "DJI",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Dominica",
        isoCode: "DM",
        iso3Code: "DMA",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      Kr,
      Hr,
      {
        name: "Egypt",
        isoCode: "EG",
        iso3Code: "EGY",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      Wr,
      {
        name: "Equatorial Guinea",
        isoCode: "GQ",
        iso3Code: "GNQ",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Eritrea",
        isoCode: "ER",
        iso3Code: "ERI",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      Jr,
      {
        name: "Eswatini",
        isoCode: "SZ",
        iso3Code: "SWZ",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Ethiopia",
        isoCode: "ET",
        iso3Code: "ETH",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Falkland Islands (Malvinas)",
        isoCode: "FK",
        iso3Code: "FLK",
        gdprApplicable: !1,
        continent: "South America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Faroe Islands",
        isoCode: "FO",
        iso3Code: "FRO",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Fiji",
        isoCode: "FJ",
        iso3Code: "FJI",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      Yr,
      Qr,
      {
        name: "French Guiana",
        isoCode: "GF",
        iso3Code: "GUF",
        gdprApplicable: !1,
        continent: "South America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "French Polynesia",
        isoCode: "PF",
        iso3Code: "PYF",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      {
        name: "French Southern Territories",
        isoCode: "TF",
        iso3Code: "ATF",
        gdprApplicable: !1,
        continent: "Antarctica",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Gabon",
        isoCode: "GA",
        iso3Code: "GAB",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Gambia",
        isoCode: "GM",
        iso3Code: "GMB",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Georgia",
        isoCode: "GE",
        iso3Code: "GEO",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      Xr,
      {
        name: "Ghana",
        isoCode: "GH",
        iso3Code: "GHA",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Gibraltar",
        isoCode: "GI",
        iso3Code: "GIB",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      ei,
      {
        name: "Greenland",
        isoCode: "GL",
        iso3Code: "GRL",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Grenada",
        isoCode: "GD",
        iso3Code: "GRD",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Guadeloupe",
        isoCode: "GP",
        iso3Code: "GLP",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Guam",
        isoCode: "GU",
        iso3Code: "GUM",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      ti,
      {
        name: "Guernsey",
        isoCode: "GG",
        iso3Code: "GGY",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Guinea",
        isoCode: "GN",
        iso3Code: "GIN",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Guinea-Bissau",
        isoCode: "GW",
        iso3Code: "GNB",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Guyana",
        isoCode: "GY",
        iso3Code: "GUY",
        gdprApplicable: !1,
        continent: "South America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Haiti",
        isoCode: "HT",
        iso3Code: "HTI",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Heard Island and McDonald Islands",
        isoCode: "HM",
        iso3Code: "HMD",
        gdprApplicable: !1,
        continent: "Antarctica",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Holy See (Vatican City State)",
        isoCode: "VA",
        iso3Code: "VAT",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      ni,
      {
        name: "Hong Kong",
        isoCode: "HK",
        iso3Code: "HKG",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 3,
      },
      ri,
      ii,
      {
        name: "India",
        isoCode: "IN",
        iso3Code: "IND",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 3,
      },
      {
        name: "Indonesia",
        isoCode: "ID",
        iso3Code: "IDN",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 3,
      },
      {
        name: "Iran",
        isoCode: "IR",
        iso3Code: "IRN",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Iraq",
        isoCode: "IQ",
        iso3Code: "IRQ",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      oi,
      {
        name: "Isle of Man",
        isoCode: "IM",
        iso3Code: "IMN",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Israel",
        isoCode: "IL",
        iso3Code: "ISR",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      si,
      ai,
      {
        name: "Japan",
        isoCode: "JP",
        iso3Code: "JPN",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 3,
      },
      {
        name: "Jersey",
        isoCode: "JE",
        iso3Code: "JEY",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Jordan",
        isoCode: "JO",
        iso3Code: "JOR",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Kazakhstan",
        isoCode: "KZ",
        iso3Code: "KAZ",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Kenya",
        isoCode: "KE",
        iso3Code: "KEN",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Kiribati",
        isoCode: "KI",
        iso3Code: "KIR",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Kosovo",
        isoCode: "XK",
        iso3Code: "XKX",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Kuwait",
        isoCode: "KW",
        iso3Code: "KWT",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Kyrgyzstan",
        isoCode: "KG",
        iso3Code: "KGZ",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Lao People's Democratic Republic",
        isoCode: "LA",
        iso3Code: "LAO",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      ci,
      {
        name: "Lebanon",
        isoCode: "LB",
        iso3Code: "LBN",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Lesotho",
        isoCode: "LS",
        iso3Code: "LSO",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Liberia",
        isoCode: "LR",
        iso3Code: "LBR",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Libyan Arab Jamahiriya",
        isoCode: "LY",
        iso3Code: "LBY",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      di,
      ui,
      li,
      {
        name: "Macao",
        isoCode: "MO",
        iso3Code: "MAC",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Madagascar",
        isoCode: "MG",
        iso3Code: "MDG",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Malawi",
        isoCode: "MW",
        iso3Code: "MWI",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Malaysia",
        isoCode: "MY",
        iso3Code: "MYS",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Maldives",
        isoCode: "MV",
        iso3Code: "MDV",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Mali",
        isoCode: "ML",
        iso3Code: "MLI",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      pi,
      {
        name: "Marshall Islands",
        isoCode: "MH",
        iso3Code: "MHL",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Martinique",
        isoCode: "MQ",
        iso3Code: "MTQ",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Mauritania",
        isoCode: "MR",
        iso3Code: "MRT",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Mauritius",
        isoCode: "MU",
        iso3Code: "MUS",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Mayotte",
        isoCode: "YT",
        iso3Code: "MYT",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      fi,
      {
        name: "Micronesia",
        isoCode: "FM",
        iso3Code: "FSM",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Moldova",
        isoCode: "MD",
        iso3Code: "MDA",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Monaco",
        isoCode: "MC",
        iso3Code: "MCO",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Mongolia",
        isoCode: "MN",
        iso3Code: "MNG",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Montenegro",
        isoCode: "ME",
        iso3Code: "MNE",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Montserrat",
        isoCode: "MS",
        iso3Code: "MSR",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Morocco",
        isoCode: "MA",
        iso3Code: "MAR",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Mozambique",
        isoCode: "MZ",
        iso3Code: "MOZ",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Myanmar",
        isoCode: "MM",
        iso3Code: "MMR",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Namibia",
        isoCode: "NA",
        iso3Code: "NAM",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Nauru",
        isoCode: "NR",
        iso3Code: "NRU",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Nepal",
        isoCode: "NP",
        iso3Code: "NPL",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      hi,
      {
        name: "New Caledonia",
        isoCode: "NC",
        iso3Code: "NCL",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      mi,
      gi,
      {
        name: "Niger",
        isoCode: "NE",
        iso3Code: "NER",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Nigeria",
        isoCode: "NG",
        iso3Code: "NGA",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Niue",
        isoCode: "NU",
        iso3Code: "NIU",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Norfolk Island",
        isoCode: "NF",
        iso3Code: "NFK",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      {
        name: "North Korea",
        isoCode: "KP",
        iso3Code: "PRK",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "North Macedonia",
        isoCode: "MK",
        iso3Code: "MKD",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Northern Mariana Islands",
        isoCode: "MP",
        iso3Code: "MNP",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      bi,
      {
        name: "Oman",
        isoCode: "OM",
        iso3Code: "OMN",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Pakistan",
        isoCode: "PK",
        iso3Code: "PAK",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Palau",
        isoCode: "PW",
        iso3Code: "PLW",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Palestinian Territory, Occupied",
        isoCode: "PS",
        iso3Code: "PSE",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      vi,
      {
        name: "Papua New Guinea",
        isoCode: "PG",
        iso3Code: "PNG",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      yi,
      Ai,
      {
        name: "Philippines",
        isoCode: "PH",
        iso3Code: "PHL",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 3,
      },
      {
        name: "Pitcairn",
        isoCode: "PN",
        iso3Code: "PCN",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      Ci,
      wi,
      {
        name: "Puerto Rico",
        isoCode: "PR",
        iso3Code: "PRI",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Qatar",
        isoCode: "QA",
        iso3Code: "QAT",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Reunion",
        isoCode: "RE",
        iso3Code: "REU",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      Si,
      {
        name: "Russian Federation",
        isoCode: "RU",
        iso3Code: "RUS",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Rwanda",
        isoCode: "RW",
        iso3Code: "RWA",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Saint Barthélemy",
        isoCode: "BL",
        iso3Code: "BLM",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Saint Helena",
        isoCode: "SH",
        iso3Code: "SHN",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Saint Kitts and Nevis",
        isoCode: "KN",
        iso3Code: "KNA",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Saint Lucia",
        isoCode: "LC",
        iso3Code: "LCA",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Saint Martin (French part)",
        isoCode: "MF",
        iso3Code: "MAF",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Saint Pierre and Miquelon",
        isoCode: "PM",
        iso3Code: "SPM",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Saint Vincent and the Grenadines",
        isoCode: "VC",
        iso3Code: "VCT",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Samoa",
        isoCode: "WS",
        iso3Code: "WSM",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      {
        name: "San Marino",
        isoCode: "SM",
        iso3Code: "SMR",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Sao Tome and Principe",
        isoCode: "ST",
        iso3Code: "STP",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Saudi Arabia",
        isoCode: "SA",
        iso3Code: "SAU",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 3,
      },
      {
        name: "Senegal",
        isoCode: "SN",
        iso3Code: "SEN",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Serbia",
        isoCode: "RS",
        iso3Code: "SRB",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Seychelles",
        isoCode: "SC",
        iso3Code: "SYC",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Sierra Leone",
        isoCode: "SL",
        iso3Code: "SLE",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Singapore",
        isoCode: "SG",
        iso3Code: "SGP",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 3,
      },
      {
        name: "Sint Maarten (Dutch part)",
        isoCode: "SX",
        iso3Code: "SXM",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      Ii,
      _i,
      {
        name: "Solomon Islands",
        isoCode: "SB",
        iso3Code: "SLB",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Somalia",
        isoCode: "SO",
        iso3Code: "SOM",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "South Africa",
        isoCode: "ZA",
        iso3Code: "ZAF",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 3,
      },
      {
        name: "South Georgia and the South Sandwich Islands",
        isoCode: "GS",
        iso3Code: "SGS",
        gdprApplicable: !1,
        continent: "Antarctica",
        euMember: !1,
        tier: 4,
      },
      {
        name: "South Korea",
        isoCode: "KR",
        iso3Code: "KOR",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 3,
      },
      {
        name: "South Sudan",
        isoCode: "SS",
        iso3Code: "SSD",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      ki,
      {
        name: "Sri Lanka",
        isoCode: "LK",
        iso3Code: "LKA",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Sudan",
        isoCode: "SD",
        iso3Code: "SDN",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Suriname",
        isoCode: "SR",
        iso3Code: "SUR",
        gdprApplicable: !1,
        continent: "South America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Svalbard and Jan Mayen",
        isoCode: "SJ",
        iso3Code: "SJM",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      Pi,
      Bi,
      {
        name: "Syrian Arab Republic",
        isoCode: "SY",
        iso3Code: "SYR",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Taiwan",
        isoCode: "TW",
        iso3Code: "TWN",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Tajikistan",
        isoCode: "TJ",
        iso3Code: "TJK",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Tanzania",
        isoCode: "TZ",
        iso3Code: "TZA",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Thailand",
        isoCode: "TH",
        iso3Code: "THA",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Timor-Leste",
        isoCode: "TL",
        iso3Code: "TLS",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Togo",
        isoCode: "TG",
        iso3Code: "TGO",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Tokelau",
        isoCode: "TK",
        iso3Code: "TKL",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Tonga",
        isoCode: "TO",
        iso3Code: "TON",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      Ei,
      {
        name: "Tunisia",
        isoCode: "TN",
        iso3Code: "TUN",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Türkiye",
        isoCode: "TR",
        iso3Code: "TUR",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Turkmenistan",
        isoCode: "TM",
        iso3Code: "TKM",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Turks and Caicos Islands",
        isoCode: "TC",
        iso3Code: "TCA",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Tuvalu",
        isoCode: "TV",
        iso3Code: "TUV",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Uganda",
        isoCode: "UG",
        iso3Code: "UGA",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Ukraine",
        isoCode: "UA",
        iso3Code: "UKR",
        gdprApplicable: !1,
        continent: "Europe",
        euMember: !1,
        tier: 4,
      },
      {
        name: "United Arab Emirates",
        isoCode: "AE",
        iso3Code: "ARE",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 3,
      },
      xi,
      Ti,
      {
        name: "United States Minor Outlying Islands",
        isoCode: "UM",
        iso3Code: "UMI",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      Ri,
      {
        name: "Uzbekistan",
        isoCode: "UZ",
        iso3Code: "UZB",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Vanuatu",
        isoCode: "VU",
        iso3Code: "VUT",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      zi,
      {
        name: "Vietnam",
        isoCode: "VN",
        iso3Code: "VNM",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 3,
      },
      {
        name: "Virgin Islands, British",
        isoCode: "VG",
        iso3Code: "VGB",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Virgin Islands, U.S.",
        isoCode: "VI",
        iso3Code: "VIR",
        gdprApplicable: !1,
        continent: "North America",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Wallis and Futuna",
        isoCode: "WF",
        iso3Code: "WLF",
        gdprApplicable: !1,
        continent: "Oceania",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Western Sahara",
        isoCode: "EH",
        iso3Code: "ESH",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Yemen",
        isoCode: "YE",
        iso3Code: "YEM",
        gdprApplicable: !1,
        continent: "Asia",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Zambia",
        isoCode: "ZM",
        iso3Code: "ZMB",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
      {
        name: "Zimbabwe",
        isoCode: "ZW",
        iso3Code: "ZWE",
        gdprApplicable: !1,
        continent: "Africa",
        euMember: !1,
        tier: 4,
      },
    ];
  [...Mi].sort((e, t) => e.name.localeCompare(t.name));
  const Oi = (function () {
      const e = "prod";
      switch (e) {
        case void 0:
        case null:
          return "localhost";
        case "dev":
          return "dev";
        case "prod":
          return "prod";
        default:
          return qn.warn("APP_STAGE is misconfigured", e), "prod";
      }
    })(),
    Fi = { configApiUrl: "https://api.dev-crazygames.be/v4/en_US/configv3" },
    Ui = { configApiUrl: "https://api.crazygames.com/v4/en_US/configv3" },
    Ni = { configApiUrl: "https://api.dev-crazygames.be/v4/en_US/configv3" };
  const Li = Ti.isoCode;
  function ji(e) {
    return Rn(e) && "" !== e.trim();
  }
  function Di(e, t) {
    const { country: n, locale: r, browser: i, device: o } = e,
      s = t.country ?? Li,
      a = t.locale,
      c = t.browser,
      d = t.device ?? "desktop";
    return (
      !(Rn(n) && !n.includes(s)) &&
      !(Rn(r) && Rn(a) && !r.includes(a)) &&
      !(Rn(i) && ji(c) && !i.includes(c)) &&
      !(Rn(o) && !o.includes(d))
    );
  }
  class Vi {
    sessionBidderConfig = {};
    sessionNexx360BiddersConfig = {};
    constructor(e, t) {
      Rn(t)
        ? (Zn.warn(
            "Customizing the IncrementalBidderTest in the SessionConfig should only be done during testing"
          ),
          (this.incrementalBidderTest = t))
        : (this.incrementalBidderTest = new Cr(e));
    }
    getBidderConfig(e) {
      return this.sessionBidderConfig[e];
    }
    setBidderConfig(e, t) {
      this.sessionBidderConfig[e] = { ...t };
    }
    getNexx360BidderConfig(e) {
      return this.sessionNexx360BiddersConfig[e];
    }
    setNexx360BidderConfig(e, t) {
      this.sessionNexx360BiddersConfig[e] = { ...t };
    }
    addToIncrementalBidderTest(e) {
      this.incrementalBidderTest.addToActualCandidates(e);
    }
    disabledInIncrementalBidderTest(e) {
      const t = this.incrementalBidderTest.isBidderDisabled(e);
      return t && Zn.debug(`Incremental bidder test disabling ${e}.`), t;
    }
    getIncrementalBidderGamKeys() {
      return this.incrementalBidderTest.getGamKeys();
    }
    getKVs() {
      return [
        ...Object.values(this.sessionBidderConfig),
        ...Object.values(this.sessionNexx360BiddersConfig),
      ]
        .filter((e) => Rn(e.gamKey))
        .reduce((e, t) => {
          let { gamKey: n, enabled: r } = t;
          return { ...e, [n]: `${r}` };
        }, {});
    }
  }
  class Gi {
    config = null;
    nexx360Bidders = null;
    sessionBidderConfig = {};
    setBidderConfigInput(e) {
      (this.config = (function (e) {
        const t = Sr(e);
        return (
          fr.forEach((e) => {
            Rn(t[e]) ||
              (Zn.error(
                `Bidder config for ${e} not found. Disabling for this session.`
              ),
              (t[e] = { rules: [{ enabled: 0, cost: 0, discrepancy: 0 }] }));
          }),
          t
        );
      })(e)),
        (this.nexx360Bidders = (function (e) {
          if (!Rn(e.nexx360Bidders)) return null;
          const t = e.regions ?? {};
          return Object.fromEntries(
            Object.entries(e.nexx360Bidders).map(([e, n]) => [
              e,
              {
                gamValue: n.gamValue,
                rules: n.rules.map((e) => Ir(e, void 0, void 0, t)),
              },
            ])
          );
        })(e));
    }
    getBidderConfig(e) {
      if (!Rn(this.config)) throw new Error("Bidder config not loaded");
      return this.config[e];
    }
    getNexx360BidderConfig(e) {
      if (!Rn(this.nexx360Bidders))
        throw new Error("Nexx360 bidders not configured");
      return this.nexx360Bidders[e];
    }
    isBidderEnabledForSession(e, t) {
      return this.retrieveCachedBidderConfig(e, t).enabled;
    }
    getBidderCostForSession(e, t) {
      return this.retrieveCachedBidderConfig(e, t).cost;
    }
    getBidderDiscrepancyForSession(e, t) {
      return this.retrieveCachedBidderConfig(e, t).discrepancy;
    }
    getEnabledNexx360BiddersForSession(e) {
      return Rn(this.nexx360Bidders)
        ? Object.keys(this.nexx360Bidders).filter(
            (t) => this.retrieveCachedNexx360BidderConfig(t, e).enabled
          )
        : null;
    }
    retrieveCachedBidderConfig(e, t) {
      const n = Br.getInstance().clientInfo,
        r = this.getSessionConfig(t),
        i = r.getBidderConfig(e);
      if (Rn(i)) return i;
      const o = this.calculateBidderConfig(e, r, n, t);
      return r.setBidderConfig(e, o), o;
    }
    calculateBidderConfig(e, t, n, r) {
      const i = this.getBidderConfig(e).rules,
        o = this.getApplicableRule(i, n, r, e),
        { cost: s, discrepancy: a } = o;
      return {
        ...this.calculateEnabledForSession(e, o, t, r),
        cost: s,
        discrepancy: a,
      };
    }
    calculateEnabledForSession(e, t, n, r) {
      const { enabled: i, gamKey: o } = t;
      if (
        (function (e) {
          return new URLSearchParams(window.location.search).has(`${e}${$n}`);
        })(e)
      )
        return (
          Zn.debug(`Force enabling ${e} for this session through query param.`),
          { enabled: !0 }
        );
      if (window.location.search.includes("disable_all_bidders"))
        return (
          Zn.debug(
            `Force disabling ${e} for this session because the query param to disable all bidders is set, and the bidder is not force enabled.`
          ),
          { enabled: !1 }
        );
      let s;
      return (
        1 === i
          ? (n.addToIncrementalBidderTest(e),
            (s = !n.disabledInIncrementalBidderTest(e)))
          : (s = Math.random() < i),
        Zn.debug(
          `${e} is ${
            s ? "enabled" : "disabled"
          } with probability ${i} for ${r}s.`
        ),
        { enabled: s, gamKey: o }
      );
    }
    retrieveCachedNexx360BidderConfig(e, t) {
      const n = this.getSessionConfig(t),
        r = n.getNexx360BidderConfig(e);
      if (Rn(r)) return r;
      const i = Br.getInstance().clientInfo,
        o = this.calculateNexx360BidderConfig(e, n, i, t);
      return n.setNexx360BidderConfig(e, o), o;
    }
    calculateNexx360BidderConfig(e, t, n, r) {
      const { gamValue: i, rules: o } = this.getNexx360BidderConfig(e),
        s = this.getApplicableRule(o, n, r, i);
      return this.calculateEnabledForSession(i, s, t, r);
    }
    getApplicableRule(e, t, n, r) {
      for (const r of e) {
        if (!Rn(r.conditions)) return r;
        if (!Di(r.conditions, t)) continue;
        const { adFormat: e } = r.conditions;
        if (!Rn(e) || e.includes(n)) return r;
      }
      return (
        Zn.error(
          `No rule applies for bidder ${r} with config ${JSON.stringify(
            t
          )} and ad format ${n}. Disabling for safety.`
        ),
        { enabled: 0, cost: 0, discrepancy: 0 }
      );
    }
    getIncrementalBidderGamKeys(e) {
      return this.getSessionConfig(e).getIncrementalBidderGamKeys();
    }
    getSessionKVs(e) {
      return this.getSessionConfig(e).getKVs();
    }
    getSessionConfig(e) {
      return (
        Rn(this.sessionBidderConfig[e]) ||
          (this.sessionBidderConfig[e] = this.createSessionConfigInstance()),
        this.sessionBidderConfig[e]
      );
    }
    createSessionConfigInstance() {
      const e = Object.values(this.nexx360Bidders ?? {}).map((e) => {
        let { gamValue: t } = e;
        return t;
      });
      return new Vi(e);
    }
    resetSessionBidderConfig() {
      Zn.warn(
        "Resetting session bidder config. This should only be used for testing purposes."
      );
      for (const e of Object.getOwnPropertyNames(this.sessionBidderConfig))
        delete this.sessionBidderConfig[e];
    }
  }
  const $i = new Gi();
  $t();
  const qi = [
      ["bidderSettings.*.storageAllowed denied 'accessDevice' for 'bidder."],
      [
        "config not defined, exiting consent manager module",
        "consentManagement",
      ],
      ["TCF2 denied"],
      ["Skipping GZIP compression for ", "as debug mode is enabled"],
      ["was rejected due to floor not met"],
      ["Bid does not meet price floor"],
      [
        "Trying to access cross domain iframe. Continuing without referrer and location",
      ],
      ["No valid bid requests returned for auction"],
      ["User ID - no ID module configured"],
      ["ESP : encryptedSignalSources config not defined under userSync Object"],
      ["Number of user syncs exceeded for"],
    ],
    Zi = [
      ["Server call for", "failed", "Continuing without bids"],
      ["Network error"],
      ["NetworkError"],
      ["ID fetch encountered an error"],
      ['localStorage api disabled"'],
    ];
  function Ki(e, t) {
    for (const n of t) if (n.every((t) => e.includes(t))) return !1;
    return !0;
  }
  class Hi {
    eventQueue = [];
    static getInstance() {
      return Rn(Hi.instance) || (Hi.instance = new Hi()), Hi.instance;
    }
    init(e) {
      Rn(e)
        ? ((this.analyticsEventHandler = e),
          this.eventQueue.length > 0 &&
            (this.eventQueue.forEach((e) => this.analyticsEventHandler(e)),
            (this.eventQueue = [])))
        : Zn.warn("[CrazyAnalyticsService] analyticsEventHandler not set");
    }
    sendAdsConfigLoadFailedEvent(e) {
      this.sendEvent({ type: "adsConfigLoadFailed", reason: e.reason });
    }
    sendInternalAdErrorEvent(e, t, n) {
      const r = {
        type: "adsInternalError",
        severity: e,
        subtype: t,
        reason: n,
      };
      let i = !0;
      "prebid" === r.subtype && (i = this.shouldSendPrebidErrorEvent(r)),
        i && this.sendEvent(r);
    }
    shouldSendPrebidErrorEvent(e) {
      return "warning" === e.severity
        ? Ki(e.reason, qi)
        : "error" !== e.severity ||
            (function (e) {
              return Ki(e, Zi);
            })(e.reason);
    }
    getEventQueue() {
      return this.eventQueue;
    }
    async sendEvent(e) {
      if (!Rn(this.analyticsEventHandler))
        return (
          Zn.warn("[CrazyAnalyticsService] analyticsEventHandler not set"),
          this.eventQueue.length >= 10
            ? void Zn.warn(
                "[CrazyAnalyticsService] event queue is full, dropping event",
                e
              )
            : void this.eventQueue.push(e)
        );
      Zn.debug("[CrazyAnalyticsService] forwarding event", e),
        this.analyticsEventHandler(e);
    }
  }
  const Wi = Hi;
  let Ji;
  function Yi() {
    return Ji || 0.9102494083378846;
  }
  const Qi = "An error occurred";
  function Xi(e, t = {}) {
    if (!e) return Qi;
    let n = "";
    const { includeStack: r = !1 } = t;
    if (e instanceof Error) n = (r && e.stack) || e.message;
    else
      try {
        (n = e.toString()),
          n.startsWith("[object") && n.endsWith("]") && (n = JSON.stringify(e));
      } catch {
        try {
          n = JSON.stringify(e);
        } catch {
          n = Qi;
        }
      }
    if ("string" != typeof n)
      try {
        n = JSON.stringify(n);
      } catch {
        n = Qi;
      }
    return ji(n)
      ? n
      : (function (e) {
          const t = [eo(e), to(e)].filter(ji);
          return t.length > 0 ? t.join(" ") : Qi;
        })(e);
  }
  function eo(e) {
    if (!(e instanceof Error)) return;
    if (ji(e.name) && "Error" !== e.name) return e.name;
    const t = e.constructor?.name;
    return ji(t) && "Error" !== t && "Object" !== t ? t : void 0;
  }
  function to(e) {
    const t = e?.code;
    return ji(t) ? t : "number" == typeof t ? String(t) : void 0;
  }
  const no = {
    bidders: {
      ix: {
        rules: [
          { enabled: 0, conditions: { region: ["blockedCountries"] } },
          {
            enabled: 0,
            conditions: {
              region: ["videoBlockedCountries"],
              adFormat: ["video"],
            },
          },
          { enabled: 0, conditions: { country: ["CN"] } },
          { enabled: 1 },
        ],
        discrepancy: 0.02,
      },
      aps: {
        rules: [
          { enabled: 0, conditions: { region: ["blockedCountries"] } },
          {
            enabled: 0,
            conditions: {
              region: ["videoBlockedCountries"],
              adFormat: ["video"],
            },
          },
          { enabled: 0, conditions: { country: ["NZ"], adFormat: ["video"] } },
          { enabled: 1 },
        ],
        comment:
          "keep rules in sync with the amazon bidder for correct evaluation of the aps_prebid_exp_26",
      },
      ttd: {
        cost: 0.018,
        rules: [
          { enabled: 0, conditions: { region: ["blockedCountries"] } },
          {
            enabled: 0,
            conditions: {
              region: ["videoBlockedCountries"],
              adFormat: ["video"],
            },
          },
          { enabled: 1 },
        ],
        discrepancy: 0.03,
      },
      msft: {
        rules: [
          { enabled: 0, conditions: { region: ["blockedCountries"] } },
          {
            enabled: 0,
            conditions: {
              region: ["videoBlockedCountries"],
              adFormat: ["video"],
            },
          },
          {
            enabled: 1,
            conditions: {
              country: [
                "US",
                "GB",
                "AU",
                "DE",
                "CA",
                "NL",
                "IT",
                "TR",
                "SE",
                "NO",
                "BR",
                "FR",
                "JP",
                "MX",
                "ES",
                "MY",
                "AT",
                "BE",
                "PH",
                "VN",
                "SG",
                "AE",
                "PE",
                "NZ",
                "TW",
                "CH",
                "TH",
                "CO",
                "DK",
                "KR",
                "HK",
                "PL",
                "ZA",
                "FI",
                "CZ",
                "RO",
                "AR",
                "PT",
                "CL",
                "IL",
              ],
            },
          },
          { enabled: 0 },
        ],
        discrepancy: 0,
      },
      kargo: {
        rules: [
          { enabled: 0, conditions: { region: ["blockedCountries"] } },
          {
            enabled: 0,
            conditions: {
              region: ["videoBlockedCountries"],
              adFormat: ["video"],
            },
          },
          { enabled: 1 },
        ],
        discrepancy: 0,
      },
      ozone: {
        rules: [
          { enabled: 0, conditions: { region: ["blockedCountries"] } },
          {
            enabled: 0,
            conditions: {
              region: ["videoBlockedCountries"],
              adFormat: ["video"],
            },
          },
          {
            enabled: 0,
            conditions: { country: ["IN", "VN", "ID", "TR", "PK"] },
          },
          { enabled: 1, conditions: { adFormat: ["banner"] } },
          { enabled: 0 },
        ],
        discrepancy: 0.04,
      },
      amazon: {
        rules: [
          { enabled: 0, conditions: { region: ["blockedCountries"] } },
          {
            enabled: 0,
            conditions: {
              region: ["videoBlockedCountries"],
              adFormat: ["video"],
            },
          },
          { enabled: 0, conditions: { country: ["NZ"], adFormat: ["video"] } },
          { enabled: 1 },
        ],
        comment:
          "Don't change this discrepancy. It must be kept in sync with GAM. See https://crazygames.slack.com/archives/C01CD4SB2UW/p1774337263333709 for details.",
        discrepancy: 0.02,
      },
      google: {
        rules: [
          { enabled: 0, conditions: { region: ["blockedCountries"] } },
          {
            enabled: 0,
            conditions: {
              region: ["videoBlockedCountries"],
              adFormat: ["video"],
            },
          },
          { enabled: 1 },
        ],
      },
      adsense: {
        rules: [
          { enabled: 0, conditions: { region: ["blockedCountries"] } },
          {
            enabled: 0,
            conditions: {
              region: ["videoBlockedCountries"],
              adFormat: ["video"],
            },
          },
          { enabled: 1 },
        ],
      },
      equativ: {
        rules: [
          { enabled: 0, conditions: { region: ["blockedCountries"] } },
          {
            enabled: 0,
            conditions: {
              region: ["videoBlockedCountries"],
              adFormat: ["video"],
            },
          },
          {
            enabled: 1,
            conditions: {
              country: [
                "US",
                "CA",
                "GB",
                "DE",
                "AU",
                "FI",
                "BR",
                "SE",
                "FR",
                "PL",
                "NL",
                "NZ",
                "AE",
                "DK",
                "SG",
                "ES",
                "AT",
                "IT",
                "CZ",
                "MX",
                "BE",
                "KR",
                "NO",
                "JP",
                "CH",
                "SA",
                "BD",
                "TH",
                "RO",
                "IE",
              ],
              adFormat: ["video"],
            },
          },
          {
            enabled: 1,
            conditions: {
              country: [
                "US",
                "CA",
                "GB",
                "DE",
                "AU",
                "FI",
                "BR",
                "SE",
                "FR",
                "PL",
                "NL",
                "NZ",
                "AE",
                "DK",
                "SG",
                "ES",
                "AT",
                "IT",
                "CZ",
                "MX",
                "BE",
                "KR",
                "NO",
                "JP",
                "CH",
                "SA",
                "BD",
                "TH",
                "RO",
                "IE",
              ],
              adFormat: ["banner"],
            },
          },
          { enabled: 0 },
        ],
        discrepancy: 0,
      },
      nexx360: {
        rules: [
          { enabled: 0, conditions: { region: ["blockedCountries"] } },
          {
            enabled: 0,
            conditions: {
              region: ["videoBlockedCountries"],
              adFormat: ["video"],
            },
          },
          { enabled: 1 },
        ],
      },
      rubicon: {
        cost: 0,
        rules: [
          { enabled: 0, conditions: { region: ["blockedCountries"] } },
          {
            enabled: 0,
            conditions: {
              region: ["videoBlockedCountries"],
              adFormat: ["video"],
            },
          },
          {
            enabled: 0,
            conditions: {
              country: ["CU", "IR", "KP", "SY", "UA", "CN", "RU", "BY"],
            },
          },
          { enabled: 1 },
        ],
        discrepancy: 0.04,
      },
      medianet: {
        rules: [
          { enabled: 0, conditions: { region: ["blockedCountries"] } },
          {
            enabled: 0,
            conditions: {
              region: ["videoBlockedCountries"],
              adFormat: ["video"],
            },
          },
          { enabled: 1 },
        ],
      },
      pubmatic: {
        cost: 0,
        rules: [
          { enabled: 0, conditions: { region: ["blockedCountries"] } },
          {
            enabled: 0,
            conditions: {
              region: ["videoBlockedCountries"],
              adFormat: ["video"],
            },
          },
          {
            enabled: 0,
            conditions: {
              country: [
                "AF",
                "AX",
                "AL",
                "DZ",
                "AD",
                "AM",
                "AZ",
                "BD",
                "BY",
                "BO",
                "BA",
                "BG",
                "CN",
                "CR",
                "CD",
                "DO",
                "EC",
                "EG",
                "SV",
                "PF",
                "GA",
                "GR",
                "GP",
                "GT",
                "HN",
                "IQ",
                "KZ",
                "LV",
                "LB",
                "LY",
                "MK",
                "MD",
                "MC",
                "ME",
                "MA",
                "NP",
                "PK",
                "PA",
                "PY",
                "PE",
                "PT",
                "RS",
                "SO",
                "LK",
                "TJ",
                "TT",
                "TR",
                "TM",
                "UA",
                "UY",
                "VE",
                "VN",
                "YE",
                "ZW",
                "IN",
                "HK",
              ],
            },
          },
          { enabled: 1 },
        ],
        discrepancy: 0.02,
      },
    },
    regions: {
      blockedCountries: {
        comment: "In these countries, all ads are blocked",
        countries: ["RU", "VE", "BY", "CU", "IR", "KP", "SY"],
      },
      videoBlockedCountries: {
        comment: "In these countries, all video ads are blocked.",
        countries: ["VN"],
      },
    },
    nexx360Bidders: {
      ix: {
        rules: [
          {
            enabled: 1,
            conditions: {
              country: [
                "AD",
                "AE",
                "AF",
                "AG",
                "AL",
                "AM",
                "AO",
                "AQ",
                "AR",
                "AT",
                "AU",
                "AW",
                "AX",
                "AZ",
                "BA",
                "BB",
                "BD",
                "BE",
                "BF",
                "BG",
                "BH",
                "BI",
                "BJ",
                "BM",
                "BN",
                "BO",
                "BQ",
                "BR",
                "BS",
                "BT",
                "BW",
                "BZ",
                "CA",
                "CD",
                "CG",
                "CH",
                "CI",
                "CK",
                "CL",
                "CM",
                "CO",
                "CR",
                "CV",
                "CW",
                "CY",
                "CZ",
                "DE",
                "DK",
                "DM",
                "DO",
                "EC",
                "EE",
                "ES",
                "ET",
                "FI",
                "FJ",
                "FM",
                "FO",
                "FR",
                "GA",
                "GB",
                "GD",
                "GE",
                "GF",
                "GH",
                "GL",
                "GP",
                "GR",
                "GT",
                "GU",
                "GY",
                "HK",
                "HN",
                "HR",
                "HT",
                "HU",
                "IE",
                "IL",
                "IN",
                "IS",
                "IT",
                "JE",
                "JM",
                "JP",
                "KE",
                "KG",
                "KH",
                "KN",
                "KR",
                "KW",
                "KY",
                "KZ",
                "LA",
                "LC",
                "LI",
                "LK",
                "LS",
                "LT",
                "LU",
                "LV",
                "MC",
                "MD",
                "ME",
                "MF",
                "MG",
                "MH",
                "MK",
                "ML",
                "MM",
                "MN",
                "MO",
                "MP",
                "MQ",
                "MR",
                "MS",
                "MT",
                "MU",
                "MV",
                "MW",
                "MX",
                "MZ",
                "NA",
                "NC",
                "NE",
                "NG",
                "NI",
                "NL",
                "NO",
                "NZ",
                "OM",
                "PA",
                "PE",
                "PF",
                "PL",
                "PR",
                "PT",
                "PW",
                "PY",
                "QA",
                "RE",
                "RO",
                "RS",
                "RW",
                "SA",
                "SC",
                "SD",
                "SE",
                "SG",
                "SI",
                "SK",
                "SM",
                "SN",
                "SO",
                "SR",
                "SV",
                "SX",
                "SZ",
                "TC",
                "TG",
                "TJ",
                "TL",
                "TO",
                "TR",
                "TT",
                "TV",
                "TW",
                "TZ",
                "UA",
                "UG",
                "US",
                "UY",
                "UZ",
                "VA",
                "VC",
                "VG",
                "VI",
                "VU",
                "WS",
                "XK",
                "YE",
                "YT",
                "ZA",
                "ZM",
                "ZW",
              ],
            },
          },
          { enabled: 0 },
        ],
        gamValue: "nx_ix",
      },
      rise: {
        rules: [
          { enabled: 1, conditions: { country: ["US", "CA"] } },
          { enabled: 0 },
        ],
        gamValue: "nx_rise",
      },
      openx: { rules: [{ enabled: 1 }], gamValue: "nx_openx" },
      cadent: {
        rules: [
          { enabled: 1, conditions: { country: ["US", "CA"] } },
          { enabled: 0 },
        ],
        gamValue: "nx_cadent",
      },
      criteo: {
        rules: [
          { enabled: 1, conditions: { country: ["US"] } },
          { enabled: 0 },
        ],
        gamValue: "nx_criteo",
      },
      inmobi: { rules: [{ enabled: 1 }], gamValue: "nx_inmobi" },
      loopme: {
        rules: [
          {
            enabled: 1,
            conditions: {
              country: [
                "AD",
                "AE",
                "AF",
                "AG",
                "AL",
                "AM",
                "AO",
                "AQ",
                "AR",
                "AT",
                "AU",
                "AW",
                "AX",
                "AZ",
                "BA",
                "BB",
                "BD",
                "BE",
                "BF",
                "BG",
                "BH",
                "BI",
                "BJ",
                "BM",
                "BN",
                "BO",
                "BQ",
                "BR",
                "BS",
                "BT",
                "BW",
                "BZ",
                "CA",
                "CD",
                "CG",
                "CH",
                "CI",
                "CK",
                "CL",
                "CM",
                "CO",
                "CR",
                "CV",
                "CW",
                "CY",
                "CZ",
                "DE",
                "DK",
                "DM",
                "DO",
                "EC",
                "EE",
                "ES",
                "ET",
                "FI",
                "FJ",
                "FM",
                "FO",
                "FR",
                "GA",
                "GB",
                "GD",
                "GE",
                "GF",
                "GH",
                "GL",
                "GP",
                "GR",
                "GT",
                "GU",
                "GY",
                "HK",
                "HN",
                "HR",
                "HT",
                "HU",
                "IE",
                "IL",
                "IN",
                "IS",
                "IT",
                "JE",
                "JM",
                "JP",
                "KE",
                "KG",
                "KH",
                "KN",
                "KR",
                "KW",
                "KY",
                "KZ",
                "LA",
                "LC",
                "LI",
                "LK",
                "LS",
                "LT",
                "LU",
                "LV",
                "MC",
                "MD",
                "ME",
                "MF",
                "MG",
                "MH",
                "MK",
                "ML",
                "MM",
                "MN",
                "MO",
                "MP",
                "MQ",
                "MR",
                "MS",
                "MT",
                "MU",
                "MV",
                "MW",
                "MX",
                "MZ",
                "NA",
                "NC",
                "NE",
                "NG",
                "NI",
                "NL",
                "NO",
                "NZ",
                "OM",
                "PA",
                "PE",
                "PF",
                "PL",
                "PR",
                "PT",
                "PW",
                "PY",
                "QA",
                "RE",
                "RO",
                "RS",
                "RW",
                "SA",
                "SC",
                "SD",
                "SE",
                "SG",
                "SI",
                "SK",
                "SM",
                "SN",
                "SO",
                "SR",
                "SV",
                "SX",
                "SZ",
                "TC",
                "TG",
                "TJ",
                "TL",
                "TO",
                "TR",
                "TT",
                "TV",
                "TW",
                "TZ",
                "UA",
                "UG",
                "US",
                "UY",
                "UZ",
                "VA",
                "VC",
                "VG",
                "VI",
                "VU",
                "WS",
                "XK",
                "YE",
                "YT",
                "ZA",
                "ZM",
                "ZW",
              ],
            },
          },
          { enabled: 0 },
        ],
        gamValue: "nx_loopme",
      },
      onetag: { rules: [{ enabled: 1 }], gamValue: "nx_onetag" },
      unruly: {
        rules: [
          {
            enabled: 1,
            conditions: {
              country: [
                "AE",
                "AI",
                "AM",
                "AO",
                "AT",
                "AU",
                "AZ",
                "BA",
                "BE",
                "BF",
                "BG",
                "BH",
                "BM",
                "BO",
                "BW",
                "CA",
                "CG",
                "CH",
                "CV",
                "CY",
                "CZ",
                "DE",
                "DO",
                "EE",
                "ES",
                "FR",
                "GA",
                "GB",
                "GD",
                "GE",
                "GH",
                "GR",
                "GT",
                "HK",
                "HN",
                "IE",
                "IN",
                "IS",
                "IT",
                "JM",
                "KE",
                "KG",
                "KR",
                "KW",
                "LC",
                "LK",
                "LS",
                "LT",
                "LU",
                "LV",
                "ME",
                "MG",
                "MK",
                "MO",
                "MT",
                "MV",
                "NI",
                "NL",
                "NO",
                "NZ",
                "OM",
                "PL",
                "PR",
                "PT",
                "PY",
                "QA",
                "RO",
                "RS",
                "SA",
                "SE",
                "SG",
                "SI",
                "TC",
                "TJ",
                "TT",
                "TW",
                "UG",
                "US",
                "UZ",
                "XK",
                "ZA",
                "ZM",
              ],
            },
          },
          { enabled: 0 },
        ],
        gamValue: "nx_unruly",
      },
      adipolo: {
        rules: [
          { enabled: 1, conditions: { country: ["AU", "US", "CA", "GB"] } },
          { enabled: 0 },
        ],
        gamValue: "nx_adipolo",
      },
      cpmstar: { rules: [{ enabled: 1 }], gamValue: "nx_cpmstar" },
      rubicon: {
        rules: [
          {
            enabled: 1,
            conditions: {
              country: [
                "AE",
                "AF",
                "AL",
                "AM",
                "AO",
                "AQ",
                "AR",
                "AT",
                "AU",
                "AX",
                "AZ",
                "BA",
                "BB",
                "BD",
                "BE",
                "BF",
                "BG",
                "BH",
                "BM",
                "BN",
                "BO",
                "BR",
                "BS",
                "BT",
                "BW",
                "BZ",
                "CA",
                "CD",
                "CG",
                "CH",
                "CI",
                "CL",
                "CM",
                "CO",
                "CR",
                "CW",
                "CY",
                "CZ",
                "DE",
                "DK",
                "DM",
                "DO",
                "EC",
                "EE",
                "ES",
                "ET",
                "FI",
                "FJ",
                "FO",
                "FR",
                "GA",
                "GB",
                "GD",
                "GE",
                "GF",
                "GG",
                "GH",
                "GL",
                "GN",
                "GP",
                "GQ",
                "GR",
                "GT",
                "GU",
                "GY",
                "HK",
                "HN",
                "HR",
                "HT",
                "HU",
                "IE",
                "IL",
                "IN",
                "IS",
                "IT",
                "JE",
                "JM",
                "JP",
                "KE",
                "KG",
                "KH",
                "KN",
                "KR",
                "KW",
                "KY",
                "KZ",
                "LA",
                "LC",
                "LI",
                "LK",
                "LS",
                "LT",
                "LU",
                "LV",
                "MC",
                "MD",
                "ME",
                "MG",
                "MH",
                "MK",
                "ML",
                "MM",
                "MN",
                "MO",
                "MQ",
                "MR",
                "MS",
                "MT",
                "MU",
                "MV",
                "MX",
                "MZ",
                "NA",
                "NC",
                "NE",
                "NG",
                "NI",
                "NL",
                "NO",
                "NU",
                "NZ",
                "OM",
                "PA",
                "PE",
                "PF",
                "PG",
                "PL",
                "PR",
                "PT",
                "PY",
                "QA",
                "RE",
                "RO",
                "RS",
                "RW",
                "SA",
                "SC",
                "SD",
                "SE",
                "SG",
                "SI",
                "SK",
                "SM",
                "SN",
                "SO",
                "SR",
                "SV",
                "SX",
                "SZ",
                "TC",
                "TG",
                "TJ",
                "TL",
                "TR",
                "TT",
                "TW",
                "TZ",
                "UG",
                "US",
                "UY",
                "UZ",
                "VA",
                "VC",
                "VG",
                "VI",
                "XK",
                "YT",
                "ZA",
                "ZM",
                "ZW",
              ],
            },
          },
          { enabled: 0 },
        ],
        gamValue: "nx_rubicon",
      },
      seedtag: { rules: [{ enabled: 1 }], gamValue: "nx_seedtag" },
      appnexus: {
        rules: [
          {
            enabled: 1,
            conditions: {
              country: [
                "AE",
                "AR",
                "AT",
                "AU",
                "BE",
                "BR",
                "CA",
                "CH",
                "CL",
                "CO",
                "CZ",
                "DE",
                "DK",
                "ES",
                "FI",
                "FR",
                "GB",
                "HK",
                "IL",
                "IM",
                "IT",
                "JP",
                "KR",
                "MM",
                "MX",
                "NL",
                "NO",
                "NZ",
                "PE",
                "PL",
                "PT",
                "RO",
                "SE",
                "SG",
                "TR",
                "TW",
                "US",
                "XK",
                "ZA",
              ],
            },
          },
          { enabled: 0 },
        ],
        gamValue: "nx_appnexus",
      },
      goldbach: {
        rules: [
          { enabled: 1, conditions: { country: ["CH"] } },
          { enabled: 0 },
        ],
        comment: "Contractual rule (Goldbach CH), must stay",
        gamValue: "nx_goldbach",
      },
      medianet: { rules: [{ enabled: 1 }], gamValue: "nx_medianet" },
      pubmatic: {
        rules: [
          {
            enabled: 0,
            conditions: {
              country: [
                "AF",
                "AX",
                "AL",
                "DZ",
                "AD",
                "AM",
                "AZ",
                "BD",
                "BY",
                "BO",
                "BG",
                "CN",
                "CR",
                "CD",
                "DO",
                "EC",
                "EG",
                "SV",
                "PF",
                "GA",
                "GR",
                "GP",
                "GT",
                "HN",
                "IQ",
                "KZ",
                "LV",
                "LB",
                "LY",
                "MK",
                "MD",
                "MC",
                "MA",
                "NP",
                "PK",
                "PA",
                "PY",
                "PE",
                "PT",
                "SO",
                "LK",
                "TJ",
                "TT",
                "TR",
                "TM",
                "UA",
                "UY",
                "VE",
                "VN",
                "YE",
                "ZW",
                "IN",
                "HK",
              ],
            },
          },
          { enabled: 1 },
        ],
        gamValue: "nx_pubmatic",
      },
      triplelift: { rules: [{ enabled: 1 }], gamValue: "nx_triplelift" },
      stroeercore: {
        rules: [
          { enabled: 1, conditions: { country: ["DE", "AT", "CH"] } },
          { enabled: 0 },
        ],
        comment: "Contractual rule (Stroeer DACH), must stay",
        gamValue: "nx_stroeercore",
      },
      smartadserver: { rules: [{ enabled: 1 }], gamValue: "nx_smartadserver" },
      advertisingcom: {
        rules: [
          { enabled: 1, conditions: { country: ["CA", "US"] } },
          { enabled: 0 },
        ],
        gamValue: "nx_advertisingcom",
      },
    },
  };
  function ro(e) {
    const t = Object.values(e).filter((e) => "number" == typeof e);
    return Object.entries(e)
      .filter(([e, n]) => -1 === t.indexOf(+e))
      .map(([e, t]) => t);
  }
  function io(e, t = "|") {
    return e.map((e) => Po(e)).join(t);
  }
  function oo(e, t) {
    return "bigint" == typeof t ? t.toString() : t;
  }
  class so {
    constructor(e) {
      (this._getter = e), (this._value = void 0);
    }
    get value() {
      const e = this._getter;
      return (
        void 0 !== e && ((this._value = e()), (this._getter = void 0)),
        this._value
      );
    }
  }
  function ao(e) {
    return new so(e);
  }
  function co(e) {
    const t = e.startsWith("^") ? 1 : 0,
      n = e.endsWith("$") ? e.length - 1 : e.length;
    return e.slice(t, n);
  }
  function uo(e, t, n) {
    Object.defineProperty(e, t, {
      value: n,
      writable: !0,
      enumerable: !0,
      configurable: !0,
    });
  }
  function lo(e) {
    const t = Object.getOwnPropertyDescriptor(e, "shape");
    return t?.get ? t.get.raw : t?.value;
  }
  function po(e) {
    return lo(e._zod.def) ?? e._zod.def.shape;
  }
  function fo(e, t, n) {
    Object.defineProperty(e, t, {
      get() {
        const e = n();
        return uo(this, t, e), e;
      },
      enumerable: !0,
      configurable: !0,
    });
  }
  function ho(e, t, n) {
    t in e ? uo(e, t, n) : (e[t] = n);
  }
  function mo(e, t, n, r) {
    const i = po(t);
    for (const o of n) {
      const n = Object.getOwnPropertyDescriptor(i, o);
      n.enumerable &&
        (n.get
          ? fo(e, o, () => {
              const e = t._zod.def.shape[o];
              return r ? r(e, o) : e;
            })
          : ho(e, o, r ? r(n.value, o) : n.value));
    }
  }
  function go(...e) {
    const t = {};
    for (const n of e) {
      const e = Object.getOwnPropertyDescriptors(n);
      Object.assign(t, e);
    }
    return Object.defineProperties({}, t);
  }
  function bo(e) {
    return JSON.stringify(e);
  }
  const vo =
    "captureStackTrace" in Error ? Error.captureStackTrace : (...e) => {};
  function yo(e) {
    return "object" == typeof e && null !== e && !Array.isArray(e);
  }
  const Ao = ao(() => {
    if (ss.jitless) return !1;
    if (
      "undefined" != typeof navigator &&
      navigator?.userAgent?.includes("Cloudflare")
    )
      return !1;
    try {
      return new Function(""), !0;
    } catch (e) {
      return !1;
    }
  });
  function Co(e) {
    if (!1 === yo(e)) return !1;
    const t = e.constructor;
    if (void 0 === t) return !0;
    if ("function" != typeof t) return !0;
    const n = t.prototype;
    return (
      !1 !== yo(n) &&
      !1 !== Object.prototype.hasOwnProperty.call(n, "isPrototypeOf")
    );
  }
  function wo(e) {
    return Co(e)
      ? { ...e }
      : Array.isArray(e)
      ? [...e]
      : e instanceof Map
      ? new Map(e)
      : e instanceof Set
      ? new Set(e)
      : e;
  }
  const So = new Set(["string", "number", "symbol"]);
  function Io(e) {
    return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
  function _o(e, t, n) {
    const r = new e._zod.constr(t ?? e._zod.def);
    return (t && !n?.parent) || (r._zod.parent = e), r;
  }
  function ko(e) {
    const t = e;
    if (!t) return {};
    if ("string" == typeof t) return { error: () => t };
    if (void 0 !== t?.message) {
      if (void 0 !== t?.error)
        throw new Error("Cannot specify both `message` and `error` params");
      t.error = t.message;
    }
    return (
      delete t.message,
      "string" == typeof t.error ? { ...t, error: () => t.error } : t
    );
  }
  function Po(e) {
    return "bigint" == typeof e
      ? e.toString() + "n"
      : "string" == typeof e
      ? `"${e}"`
      : `${e}`;
  }
  const Bo = (() => ({
      safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
      int32: [-2147483648, 2147483647],
      uint32: [0, 4294967295],
      float32: [-34028234663852886e22, 34028234663852886e22],
      float64: [-Number.MAX_VALUE, Number.MAX_VALUE],
    }))(),
    Eo = {
      int64: [BigInt("-9223372036854775808"), BigInt("9223372036854775807")],
      uint64: [BigInt(0), BigInt("18446744073709551615")],
    };
  function xo(e, t) {
    const n = po(e),
      r = [];
    for (const e of Reflect.ownKeys(t)) {
      if (!Object.getOwnPropertyDescriptor(n, e)?.enumerable)
        throw new Error(`Unrecognized key: "${String(e)}"`);
      t[e] && r.push(e);
    }
    return r;
  }
  function To(e, t) {
    const n = {};
    return (
      mo(n, e, Reflect.ownKeys(po(e))),
      (function (e, t) {
        for (const n of Reflect.ownKeys(t)) {
          const r = Object.getOwnPropertyDescriptor(t, n);
          r.enumerable && (r.get ? fo(e, n, () => t[n]) : ho(e, n, r.value));
        }
      })(n, t),
      n
    );
  }
  function Ro(e, t, n, r = "partial") {
    const i = t._zod.def.checks;
    if (i && i.length > 0)
      throw new Error(
        `.${r}() cannot be used on object schemas containing refinements`
      );
    const o = n ? new Set(xo(t, n)) : void 0,
      s = {};
    return (
      mo(
        s,
        t,
        Reflect.ownKeys(po(t)),
        e &&
          ((t, n) =>
            o && !o.has(n) ? t : new e({ type: "optional", innerType: t }))
      ),
      _o(t, go(t._zod.def, { shape: s, checks: [] }))
    );
  }
  function zo(e, t = 0) {
    if (!0 === e.aborted) return !0;
    for (let n = t; n < e.issues.length; n++)
      if (!0 !== e.issues[n]?.continue) return !0;
    return !1;
  }
  function Mo(e, t = 0) {
    if (!0 === e.aborted) return !0;
    for (let n = t; n < e.issues.length; n++)
      if (!1 === e.issues[n]?.continue) return !0;
    return !1;
  }
  function Oo(e, t) {
    return t.map((t) => {
      var n;
      return (n = t).path ?? (n.path = []), t.path.unshift(e), t;
    });
  }
  function Fo(e) {
    return "string" == typeof e ? e : e?.message;
  }
  function Uo(e) {
    const t = [];
    for (const n of e ?? []) {
      const e = n._zod.def;
      if (!/_(length|size)$|_equals$/.test(e.check)) break;
      const r = e.maximum ?? e.length ?? e.size;
      r >= 0 && t.push([r, n]);
    }
    return t;
  }
  function No(e, t, n) {
    var r;
    for (let i = t; i < e.length; i++) (r = e[i]).schema ?? (r.schema = n);
  }
  function Lo(e, t, n) {
    var r;
    const i = e.inst?._zod?.traits;
    i?.has("$ZodType") &&
      (i.has("$ZodCheck")
        ? (r = e).schema ?? (r.schema = e.inst)
        : (e.schema = e.inst));
    const o = e.schema !== e.inst ? e.schema?._zod.def?.error : void 0,
      s = e.message
        ? e.message
        : Fo(e.inst?._zod.def?.error?.(e)) ??
          Fo(o?.(e)) ??
          Fo(t?.error?.(e)) ??
          Fo(n.customError?.(e)) ??
          Fo(n.localeError?.(e)) ??
          "Invalid input",
      a = {};
    for (const t of Object.keys(e))
      "inst" !== t &&
        "schema" !== t &&
        "continue" !== t &&
        "input" !== t &&
        "__proto__" !== t &&
        (a[t] = e[t]);
    return (
      a.path ?? (a.path = []),
      (a.message = s),
      t?.reportInput && (a.input = e.input),
      a
    );
  }
  const jo = /[\uD800-\uDBFF]/;
  function Do(e) {
    const t = e.length;
    if (!jo.test(e)) return t;
    let n = t;
    for (let r = 0; r < t - 1; r++)
      55296 == (64512 & e.charCodeAt(r)) &&
        56320 == (64512 & e.charCodeAt(r + 1)) &&
        (n--, r++);
    return n;
  }
  function Vo(e) {
    return Array.isArray(e)
      ? "array"
      : "string" == typeof e
      ? "string"
      : "unknown";
  }
  function Go(...e) {
    const [t, n, r] = e;
    return "string" == typeof t
      ? { message: t, code: "custom", input: n, inst: r }
      : { ...t };
  }
  function $o(e, t, n, r = !0) {
    return (
      Object.defineProperty(e, t, {
        configurable: !0,
        writable: !0,
        enumerable: r,
        value: n,
      }),
      n
    );
  }
  function qo(e, t, n) {
    return $o(e, t, n, !1);
  }
  function Zo(e, t) {
    for (const n in e) {
      const r = e[n];
      Object.defineProperty(t, n, {
        configurable: !0,
        enumerable: !0,
        get() {
          return $o(this, n, r(this));
        },
        set(e) {
          $o(this, n, e);
        },
      });
    }
    return t;
  }
  function Ko(e, t, n) {
    Object.defineProperty(e, t, {
      configurable: !0,
      get() {
        return null == this ? n : $o(this, t, n.bind(this));
      },
      set(e) {
        $o(this, t, e);
      },
    });
  }
  let Ho,
    Wo = !1;
  const Jo = {
    configurable: !0,
    get() {
      Wo = !0;
    },
  };
  function Yo(e, t, n) {
    const r = Object.getPrototypeOf(e._zod);
    t in r && Ho !== e._zod
      ? (Ho = void 0)
      : ((Ho = e._zod),
        Object.defineProperty(r, t, {
          configurable: !0,
          get() {
            Object.defineProperty(this, t, Jo);
            const e = Wo;
            Wo = !1;
            try {
              const r = n(this);
              return (
                Wo
                  ? delete this[t]
                  : Object.defineProperty(this, t, {
                      configurable: !0,
                      writable: !0,
                      value: r,
                    }),
                (Wo = Wo || e),
                r
              );
            } catch (n) {
              throw (delete this[t], (Wo = Wo || e), n);
            }
          },
          set(e) {
            Object.defineProperty(this, t, {
              configurable: !0,
              writable: !0,
              value: e,
            });
          },
        }));
  }
  function Qo(e, t, n, r) {
    const i = (function (e, t) {
      const n = Object.getPrototypeOf(e);
      return t in n ? void 0 : n;
    })(e, t);
    i &&
      Object.defineProperty(i, t, {
        configurable: !0,
        get() {
          const e = {
            configurable: !0,
            writable: !0,
            enumerable: r,
            value: void 0,
          };
          return (
            Object.defineProperty(this, t, e),
            (e.value = n(this)),
            Object.defineProperty(this, t, e),
            e.value
          );
        },
        set(e) {
          Object.defineProperty(this, t, {
            configurable: !0,
            writable: !0,
            enumerable: r,
            value: e,
          });
        },
      });
  }
  function Xo(e) {
    const t = () => e;
    return (t["~constantCatch"] = !0), t;
  }
  var es;
  const ts = { value: void 0, enumerable: !1 };
  let ns = "captureStackTrace" in Error ? Error : null;
  function rs(e, t, n, r) {
    function i(e) {
      (this.def = e), (this.constr = u), (this.traits = new Set());
    }
    i.prototype = {};
    const o = n,
      s = o && new WeakSet();
    function a(n, r) {
      if (n._zod) {
        if (n._zod.traits.has(e)) return;
      } else {
        ts.value = new i(r);
        try {
          Object.defineProperty(n, "_zod", ts);
        } finally {
          ts.value = void 0;
        }
      }
      if ((n._zod.traits.add(e), t(n, r), s)) {
        const e = Object.getPrototypeOf(n),
          t = n._zod.constr.prototype;
        let r = e;
        for (; r && r !== t; ) r = Object.getPrototypeOf(r);
        const i = r ?? e;
        s.has(i) ||
          (s.add(i),
          (function (e, t) {
            for (const n in t) {
              const r = Object.getOwnPropertyDescriptor(t, n);
              r.get
                ? Object.defineProperty(e, n, { ...r, enumerable: !1 })
                : Ko(e, n, r.value);
            }
          })(i, o));
      }
      const a = u.prototype;
      for (const e in a)
        Object.prototype.hasOwnProperty.call(a, e) &&
          (e in n || (n[e] = a[e].bind(n)));
    }
    const c = r?.Parent ?? Object;
    class d extends c {}
    function u(e) {
      const t = r?.Parent
        ? (function (e) {
            const t = ns;
            if (t) {
              const n = t.stackTraceLimit;
              if ("number" == typeof n) {
                try {
                  t.stackTraceLimit = 0;
                } catch {
                  return (ns = null), new e();
                }
                try {
                  return new e();
                } finally {
                  t.stackTraceLimit = n;
                }
              }
            }
            return new e();
          })(d)
        : this;
      a(t, e);
      const n = t._zod.deferred;
      if (n) {
        for (const e of n) e();
        t._zod.deferred = void 0;
      }
      const i = globalThis.__zod_globalConfig?.postProcessor;
      return i && i(t), t;
    }
    return (
      Object.defineProperty(d, "name", { value: e }),
      Object.defineProperty(u, "init", { value: a }),
      Object.defineProperty(u, Symbol.hasInstance, {
        value: (t) =>
          !!(r?.Parent && t instanceof r.Parent) || t?._zod?.traits?.has(e),
      }),
      Object.defineProperty(u, "name", { value: e }),
      u
    );
  }
  class is extends Error {
    constructor() {
      super(
        "Encountered Promise during synchronous parse. Use .parseAsync() instead."
      );
    }
  }
  class os extends Error {
    constructor(e) {
      super(`Encountered unidirectional transform during encode: ${e}`),
        (this.name = "ZodEncodeError");
    }
  }
  (es = globalThis).__zod_globalConfig ?? (es.__zod_globalConfig = {});
  const ss = globalThis.__zod_globalConfig;
  function as(e) {
    return e && Object.assign(ss, e), ss;
  }
  class cs extends Error {
    constructor() {
      super("Cannot parse a reference cycle that closes through a transform"),
        (this.name = "ZodCyclicError");
    }
  }
  const ds = "~memo",
    us = [];
  function ls(e) {
    return null !== e && "object" == typeof e;
  }
  function ps(e) {
    return e.map((e) => (e.path ? { ...e, path: e.path.slice() } : { ...e }));
  }
  const fs = new WeakMap();
  function hs(e, t, n) {
    const r = fs.get(e);
    if (void 0 !== r) return r ? 2 : 0;
    if (t.has(e)) return 2;
    t.add(e);
    let i = 0;
    const o = (e) => {
        if (2 !== i && e?._zod) {
          const r = hs(e, t, n);
          r > i && (i = r);
        }
      },
      s = (e) => {
        e > i && (i = e);
      },
      a = e._zod.def,
      c = a.type;
    switch (c) {
      case "object": {
        const e = lo(a);
        s(
          e
            ? ((e, r) => {
                let i = 0;
                for (const o of Reflect.ownKeys(e)) {
                  const s = Object.getOwnPropertyDescriptor(e, o);
                  if (r && !s.enumerable) continue;
                  const a = s.get ? 1 : s.value?._zod ? hs(s.value, t, n) : 0;
                  a > i && (i = a);
                }
                return i;
              })(e, !0)
            : 1
        ),
          o(a.catchall);
        break;
      }
      case "array":
        o(a.element);
        break;
      case "tuple":
        for (const e of a.items) o(e);
        o(a.rest);
        break;
      case "record":
      case "map":
        o(a.keyType), o(a.valueType);
        break;
      case "set":
        o(a.valueType);
        break;
      case "union":
        for (const e of a.options) o(e);
        break;
      case "intersection":
        o(a.left), o(a.right);
        break;
      case "optional":
      case "nullable":
      case "default":
      case "prefault":
      case "catch":
      case "readonly":
      case "nonoptional":
      case "promise":
      case "success":
        o(a.innerType);
        break;
      case "pipe":
        o(a.in), o(a.out);
        break;
      case "function":
        o(a.input), o(a.output);
        break;
      case "lazy": {
        const r = a._cachedInner ?? (n ? e._zod.innerType : void 0);
        s(r ? hs(r, t, !1) : 1);
        break;
      }
      case "template_literal":
      case "string":
      case "number":
      case "int":
      case "boolean":
      case "bigint":
      case "symbol":
      case "undefined":
      case "null":
      case "void":
      case "never":
      case "any":
      case "unknown":
      case "date":
      case "nan":
      case "enum":
      case "literal":
      case "file":
      case "transform":
      case "custom":
        break;
      default:
        for (const e in a) {
          const t = Object.getOwnPropertyDescriptor(a, e);
          if (!t || t.get) continue;
          const n = t.value;
          if (n && "object" == typeof n)
            if (n._zod) o(n);
            else if (Array.isArray(n)) for (const e of n) o(e);
        }
    }
    return (
      t.delete(e),
      (function (e, t) {
        1 !== t && fs.set(e, 2 === t);
        return t;
      })(e, i)
    );
  }
  let ms;
  const gs = [],
    bs = {
      alloc(e, t, n) {
        const r = ms;
        if (!r) return n;
        ms = void 0;
        const i = { value: n, issues: null };
        return r.set(t.value, i), gs.push(i), n;
      },
      guard(e) {
        var t;
        (t = e._zod).deferred ?? (t.deferred = []),
          e._zod.deferred.push(() => {
            const t = e._zod.parse,
              n = (e, n) => {
                if (
                  "backward" !== n.direction &&
                  (function (e, t) {
                    const n = e[ds]?.backEdges;
                    return void 0 !== n && ls(t) && n.has(t);
                  })(n, e.value)
                )
                  throw new cs();
                return t(e, n);
              };
            (e._zod.parse = n), e._zod.run === t && (e._zod.run = n);
          });
      },
      attach(e) {
        var t;
        let n,
          r,
          i,
          o = !1;
        (t = e._zod).deferred ?? (t.deferred = []),
          e._zod.deferred.push(() => {
            const t = e._zod.parse,
              s = (a, c) => {
                if (void 0 === n) {
                  const r = hs(e, new Set(), !1);
                  if (0 === r)
                    return (
                      (e._zod.parse = t),
                      e._zod.run === s && (e._zod.run = t),
                      t(a, c)
                    );
                  2 === r || o ? (n = !0) : (o = !0);
                }
                const d = a.value;
                if (!ls(d)) return t(a, c);
                let u,
                  l = c[ds];
                l ||
                  ((l = { buckets: new WeakMap(), backEdges: void 0 }),
                  (c[ds] = l)),
                  r === c
                    ? (u = i)
                    : ((u = (function (e, t) {
                        let n = e.buckets.get(t);
                        return (
                          n || ((n = new WeakMap()), e.buckets.set(t, n)), n
                        );
                      })(l, e)),
                      (r = c),
                      (i = u));
                const p = u.get(d);
                if (p)
                  return (
                    (a.value = p.value),
                    p.issues
                      ? p.issues.length && a.issues.push(...ps(p.issues))
                      : ((a.memo = !0),
                        l.backEdges ?? (l.backEdges = new WeakSet()),
                        l.backEdges.add(p.value)),
                    a
                  );
                ms = u;
                const f = gs.length,
                  h = t(a, c);
                ms = void 0;
                const m = gs.length > f ? gs.pop() : void 0;
                return h instanceof Promise
                  ? h.then(
                      (e) => (
                        m && (m.issues = e.issues.length ? ps(e.issues) : us), e
                      )
                    )
                  : (m && (m.issues = h.issues.length ? ps(h.issues) : us), h);
              };
            (e._zod.parse = s), e._zod.run === t && (e._zod.run = s);
          });
      },
    };
  const vs = /^[cC][0-9a-z]{6,}$/,
    ys = /^[0-9a-z]+$/,
    As = /^[0-7][0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{25}$/,
    Cs = /^[0-9a-vA-V]{20}$/,
    ws = /^[A-Za-z0-9]{27}$/,
    Ss = /^[a-zA-Z0-9_-]{21}$/;
  const Is =
      /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/,
    _s =
      /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/,
    ks = (e) =>
      e
        ? new RegExp(
            `^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${e}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`
          )
        : /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/,
    Ps =
      /^(?:[A-Za-z0-9_'+\-]+\.)*[A-Za-z0-9_'+\-]*[A-Za-z0-9_+-]@(?:[A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/;
  const Bs =
      /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,
    Es =
      /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/,
    xs =
      /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/,
    Ts =
      /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,
    Rs = /^https?$/,
    zs = /^\+[1-9]\d{6,14}$/,
    Ms =
      "(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))";
  function Os(e) {
    return new RegExp(`^${e}$`);
  }
  const Fs = Os(Ms);
  function Us(e) {
    const t = "(?:[01]\\d|2[0-3]):[0-5]\\d";
    return "number" == typeof e.precision
      ? -1 === e.precision
        ? `${t}`
        : 0 === e.precision
        ? `${t}:[0-5]\\d`
        : `${t}:[0-5]\\d\\.\\d{${e.precision}}`
      : e.seconds
      ? `${t}:[0-5]\\d(?:\\.\\d+)?`
      : `${t}(?::[0-5]\\d(?:\\.\\d+)?)?`;
  }
  const Ns = /^[\s\S]{0,}$/,
    Ls = /^-?\d+$/,
    js = /^-?\d+(?:\.\d+)?$/,
    Ds = /^(?:true|false)$/i,
    Vs = /^[^A-Z]*$/,
    Gs = /^[^a-z]*$/;
  const $s = rs("$ZodCheck", (e, t) => {
      var n;
      e._zod ?? (e._zod = {}),
        (e._zod.def = t),
        (n = e._zod).onattach ?? (n.onattach = []);
    }),
    qs = (e) => {
      const t = e.value;
      return !((n = t), null == n || void 0 === t.length);
      var n;
    },
    Zs = { number: "number", bigint: "bigint", object: "date" },
    Ks = rs("$ZodCheckLessThan", (e, t) => {
      $s.init(e, t);
      const n = Zs[typeof t.value];
      e._zod.check = (r) => {
        (t.inclusive ? r.value <= t.value : r.value < t.value) ||
          r.issues.push({
            origin: Zs[typeof r.value] ?? n,
            code: "too_big",
            maximum: "object" == typeof t.value ? t.value.getTime() : t.value,
            input: r.value,
            inclusive: t.inclusive,
            inst: e,
            continue: !t.abort,
          });
      };
    }),
    Hs = rs("$ZodCheckGreaterThan", (e, t) => {
      $s.init(e, t);
      const n = Zs[typeof t.value];
      e._zod.check = (r) => {
        (t.inclusive ? r.value >= t.value : r.value > t.value) ||
          r.issues.push({
            origin: Zs[typeof r.value] ?? n,
            code: "too_small",
            minimum: "object" == typeof t.value ? t.value.getTime() : t.value,
            input: r.value,
            inclusive: t.inclusive,
            inst: e,
            continue: !t.abort,
          });
      };
    }),
    Ws = rs("$ZodCheckMultipleOf", (e, t) => {
      $s.init(e, t),
        (e._zod.check = (n) => {
          if (typeof n.value != typeof t.value)
            throw new Error(
              "Cannot mix number and bigint in multiple_of check."
            );
          ("bigint" == typeof n.value
            ? t.value !== BigInt(0) && n.value % t.value === BigInt(0)
            : 0 ===
              (function (e, t) {
                const n = e / t,
                  r = Math.round(n),
                  i = 4 * Number.EPSILON * Math.max(Math.abs(n), 1);
                return Math.abs(n - r) < i ? 0 : n - r;
              })(n.value, t.value)) ||
            n.issues.push({
              origin: typeof n.value,
              code: "not_multiple_of",
              divisor: t.value,
              input: n.value,
              inst: e,
              continue: !t.abort,
            });
        });
    }),
    Js = rs("$ZodCheckNumberFormat", (e, t) => {
      $s.init(e, t), (t.format = t.format || "float64");
      const n = t.format?.includes("int"),
        r = n ? "int" : "number",
        [i, o] = Bo[t.format];
      e._zod.check = (s) => {
        const a = s.value;
        if (n) {
          if (!Number.isInteger(a))
            return void s.issues.push({
              expected: r,
              format: t.format,
              code: "invalid_type",
              continue: !1,
              input: a,
              inst: e,
            });
          if (!Number.isSafeInteger(a))
            return void (a > 0
              ? s.issues.push({
                  input: a,
                  code: "too_big",
                  maximum: Number.MAX_SAFE_INTEGER,
                  note: "Integers must be within the safe integer range.",
                  inst: e,
                  origin: r,
                  inclusive: !0,
                  continue: !t.abort,
                })
              : s.issues.push({
                  input: a,
                  code: "too_small",
                  minimum: Number.MIN_SAFE_INTEGER,
                  note: "Integers must be within the safe integer range.",
                  inst: e,
                  origin: r,
                  inclusive: !0,
                  continue: !t.abort,
                }));
        }
        a < i &&
          s.issues.push({
            origin: "number",
            input: a,
            code: "too_small",
            minimum: i,
            inclusive: !0,
            inst: e,
            continue: !t.abort,
          }),
          a > o &&
            s.issues.push({
              origin: "number",
              input: a,
              code: "too_big",
              maximum: o,
              inclusive: !0,
              inst: e,
              continue: !t.abort,
            });
      };
    }),
    Ys = rs("$ZodCheckMaxLength", (e, t) => {
      var n;
      $s.init(e, t),
        (n = e._zod.def).when ?? (n.when = qs),
        (e._zod.check = (n) => {
          const r = n.value,
            i = r.length;
          if (("string" == typeof r && i > t.maximum ? Do(r) : i) <= t.maximum)
            return;
          const o = Vo(r);
          n.issues.push({
            origin: o,
            code: "too_big",
            maximum: t.maximum,
            inclusive: !0,
            input: r,
            inst: e,
            continue: !t.abort,
          });
        });
    }),
    Qs = rs("$ZodCheckMinLength", (e, t) => {
      var n;
      $s.init(e, t),
        (n = e._zod.def).when ?? (n.when = qs),
        (e._zod.check = (n) => {
          const r = n.value,
            i = r.length;
          if (
            ("string" == typeof r && i >= t.minimum && i < 2 * t.minimum
              ? Do(r)
              : i) >= t.minimum
          )
            return;
          const o = Vo(r);
          n.issues.push({
            origin: o,
            code: "too_small",
            minimum: t.minimum,
            inclusive: !0,
            input: r,
            inst: e,
            continue: !t.abort,
          });
        });
    }),
    Xs = rs("$ZodCheckLengthEquals", (e, t) => {
      var n;
      $s.init(e, t),
        (n = e._zod.def).when ?? (n.when = qs),
        (e._zod.check = (n) => {
          const r = n.value,
            i = r.length,
            o =
              "string" == typeof r && i >= t.length && i <= 2 * t.length
                ? Do(r)
                : i;
          if (o === t.length) return;
          const s = Vo(r),
            a = o > t.length;
          n.issues.push({
            origin: s,
            ...(a
              ? { code: "too_big", maximum: t.length }
              : { code: "too_small", minimum: t.length }),
            inclusive: !0,
            exact: !0,
            input: n.value,
            inst: e,
            continue: !t.abort,
          });
        });
    }),
    ea = rs("$ZodCheckStringFormat", (e, t) => {
      var n, r;
      $s.init(e, t),
        t.pattern
          ? (n = e._zod).check ??
            (n.check = (n) => {
              (t.pattern.lastIndex = 0),
                t.pattern.test(n.value) ||
                  n.issues.push({
                    origin: "string",
                    code: "invalid_format",
                    format: t.format,
                    input: n.value,
                    ...(t.pattern ? { pattern: t.pattern.toString() } : {}),
                    inst: e,
                    continue: !t.abort,
                  });
            })
          : (r = e._zod).check ?? (r.check = () => {});
    }),
    ta = rs("$ZodCheckRegex", (e, t) => {
      ea.init(e, t),
        (e._zod.check = (n) => {
          (t.pattern.lastIndex = 0),
            t.pattern.test(n.value) ||
              n.issues.push({
                origin: "string",
                code: "invalid_format",
                format: "regex",
                input: n.value,
                pattern: t.pattern.toString(),
                inst: e,
                continue: !t.abort,
              });
        });
    }),
    na = rs("$ZodCheckLowerCase", (e, t) => {
      t.pattern ?? (t.pattern = Vs), ea.init(e, t);
    }),
    ra = rs("$ZodCheckUpperCase", (e, t) => {
      t.pattern ?? (t.pattern = Gs), ea.init(e, t);
    }),
    ia = rs("$ZodCheckIncludes", (e, t) => {
      $s.init(e, t);
      const n = Io(t.includes),
        r = new RegExp(
          "number" == typeof t.position ? `^.{${t.position},}${n}` : n
        );
      (t.pattern = r),
        (e._zod.check = (n) => {
          n.value.includes(t.includes, t.position) ||
            n.issues.push({
              origin: "string",
              code: "invalid_format",
              format: "includes",
              includes: t.includes,
              input: n.value,
              inst: e,
              continue: !t.abort,
            });
        });
    }),
    oa = rs("$ZodCheckStartsWith", (e, t) => {
      $s.init(e, t);
      const n = new RegExp(`^${Io(t.prefix)}.*`);
      t.pattern ?? (t.pattern = n),
        (e._zod.check = (n) => {
          n.value.startsWith(t.prefix) ||
            n.issues.push({
              origin: "string",
              code: "invalid_format",
              format: "starts_with",
              prefix: t.prefix,
              input: n.value,
              inst: e,
              continue: !t.abort,
            });
        });
    }),
    sa = rs("$ZodCheckEndsWith", (e, t) => {
      $s.init(e, t);
      const n = new RegExp(`.*${Io(t.suffix)}$`);
      t.pattern ?? (t.pattern = n),
        (e._zod.check = (n) => {
          n.value.endsWith(t.suffix) ||
            n.issues.push({
              origin: "string",
              code: "invalid_format",
              format: "ends_with",
              suffix: t.suffix,
              input: n.value,
              inst: e,
              continue: !t.abort,
            });
        });
    });
  const aa = rs("$ZodCheckOverwrite", (e, t) => {
    $s.init(e, t),
      (e._zod.check = (e) => {
        e.value = t.tx(e.value);
      });
  });
  class ca {
    constructor(e = [], t = {}) {
      (this.content = []),
        (this.indent = 0),
        (this.args = e),
        (this.closed = t);
    }
    indented(e) {
      this.indent += 1;
      try {
        e(this);
      } finally {
        this.indent -= 1;
      }
    }
    write(e) {
      if ("function" == typeof e)
        return (
          e(this, { execution: "sync" }), void e(this, { execution: "async" })
        );
      const t = e.split("\n").filter((e) => e),
        n = Math.min(...t.map((e) => e.length - e.trimStart().length)),
        r = t
          .map((e) => e.slice(n))
          .map((e) => " ".repeat(2 * this.indent) + e);
      for (const e of r) this.content.push(e);
    }
    compile() {
      const e = Function,
        t = this?.content ?? [""];
      return new e(
        ...Object.keys(this.closed),
        `return function (${this.args.join(", ")}) {\n${t.join("\n")}\n};`
      )(...Object.values(this.closed));
    }
  }
  const da = { major: 4, minor: 6, patch: 7 };
  const ua = rs(
      "$ZodType",
      (e, t) => {
        var n;
        e ?? (e = {}),
          (e._zod.def = t),
          (e._zod.bag = e._zod.bag || {}),
          (e._zod.version = da);
        const r = e._zod.def.checks,
          i = e._zod.traits.has("$ZodCheck")
            ? [e, ...(r ?? [])]
            : r?.length
            ? [...r]
            : [];
        for (const t of i) for (const n of t._zod.onattach) n(e);
        if (0 === i.length)
          (n = e._zod).deferred ?? (n.deferred = []),
            e._zod.deferred?.push(() => {
              e._zod.run = e._zod.parse;
            });
        else {
          const t = (t, n, r) => {
              if (t.memo) return t;
              let i,
                o = zo(t);
              for (const s of n) {
                if (s._zod.def.when) {
                  if (Mo(t)) continue;
                  if (!s._zod.def.when(t)) continue;
                } else if (o) continue;
                const n = t.issues.length,
                  a = s._zod.check(t);
                if (a instanceof Promise && !1 === r?.async) throw new is();
                if (i || a instanceof Promise)
                  i = (i ?? Promise.resolve()).then(async () => {
                    await a;
                    t.issues.length !== n &&
                      (No(t.issues, n, e), o || (o = zo(t, n)));
                  });
                else {
                  if (t.issues.length === n) continue;
                  No(t.issues, n, e), o || (o = zo(t, n));
                }
              }
              return i ? i.then(() => t) : t;
            },
            n = (n, r, o) => {
              if (zo(n)) return (n.aborted = !0), n;
              const s = t(r, i, o);
              if (s instanceof Promise) {
                if (!1 === o.async) throw new is();
                return s.then((t) => e._zod.parse(t, o));
              }
              return e._zod.parse(s, o);
            };
          e._zod.run = (r, o) => {
            if (o.skipChecks) return e._zod.parse(r, o);
            if ("backward" === o.direction) {
              const t = e._zod.parse(
                { value: r.value, issues: [] },
                { ...o, skipChecks: !0 }
              );
              return t instanceof Promise
                ? t.then((e) => n(e, r, o))
                : n(t, r, o);
            }
            const s = e._zod.parse(r, o);
            if (s instanceof Promise) {
              if (!1 === o.async) throw new is();
              return s.then((e) => t(e, i, o));
            }
            return t(s, i, o);
          };
        }
      },
      {
        get "~standard"() {
          return qo(this, "~standard", pa(this));
        },
        set "~standard"(e) {
          $o(this, "~standard", e);
        },
      }
    ),
    la = (e, t) =>
      e.issues.length
        ? { issues: e.issues.map((e) => Lo(e, t, as())) }
        : { value: e.value };
  function pa(e) {
    return {
      validate: (t) => {
        const n = { async: !1 };
        try {
          const r = e._zod.run({ value: t, issues: [] }, n);
          if (!(r instanceof Promise)) return la(r, n);
        } catch (e) {}
        return (async function (e, t) {
          const n = { async: !0 };
          return la(await e._zod.run({ value: t, issues: [] }, n), n);
        })(e, t);
      },
      vendor: "zod",
      version: 1,
    };
  }
  const fa = rs("$ZodString", (e, t) => {
      ua.init(e, t),
        (e._zod.pattern = t.pattern ?? Ns),
        (e._zod.parse = (n, r) => {
          if (t.coerce)
            try {
              n.value = String(n.value);
            } catch (r) {}
          return (
            "string" == typeof n.value ||
              n.issues.push({
                expected: "string",
                code: "invalid_type",
                input: n.value,
                inst: e,
              }),
            n
          );
        });
    }),
    ha = rs("$ZodStringFormat", (e, t) => {
      ea.init(e, t), fa.init(e, t);
    }),
    ma = rs("$ZodGUID", (e, t) => {
      t.pattern ?? (t.pattern = _s), ha.init(e, t);
    }),
    ga = rs("$ZodUUID", (e, t) => {
      if (t.version) {
        const e = { v1: 1, v2: 2, v3: 3, v4: 4, v5: 5, v6: 6, v7: 7, v8: 8 }[
          t.version
        ];
        if (void 0 === e)
          throw new Error(`Invalid UUID version: "${t.version}"`);
        t.pattern ?? (t.pattern = ks(e));
      } else t.pattern ?? (t.pattern = ks());
      ha.init(e, t);
    }),
    ba = rs("$ZodEmail", (e, t) => {
      t.pattern ?? (t.pattern = Ps), ha.init(e, t);
    });
  function va(e) {
    try {
      return "undefined" != typeof URL && "function" == typeof URL.canParse
        ? URL.canParse(e)
        : (new URL(e), !0);
    } catch {
      return !1;
    }
  }
  function ya(e, t) {
    return "normalize" in t || "hostname" in t || "protocol" in t
      ? (function (e, t) {
          if (
            !t.normalize &&
            t.protocol?.source === Rs.source &&
            !/^https?:\/\//i.test(e)
          )
            return 1;
          try {
            if ("undefined" != typeof URL) {
              const t = URL;
              if ("function" == typeof t.parse) return t.parse(e) ?? 2;
            }
            return new URL(e);
          } catch {
            return 2;
          }
        })(e, t)
      : va(e) || 2;
  }
  const Aa = /[\t\n\r]/g;
  function Ca(e) {
    return e.replace(Aa, "");
  }
  const wa = rs("$ZodURL", (e, t) => {
      ha.init(e, t),
        (e._zod.check = (n) => {
          try {
            const r = n.value.trim(),
              i = ya(r, t);
            return 1 === i
              ? void n.issues.push({
                  code: "invalid_format",
                  format: "url",
                  note: "Invalid URL format",
                  input: n.value,
                  inst: e,
                  continue: !t.abort,
                })
              : 2 === i
              ? void n.issues.push({
                  code: "invalid_format",
                  format: "url",
                  input: n.value,
                  inst: e,
                  continue: !t.abort,
                })
              : !0 === i
              ? void (n.value = Ca(r))
              : (t.hostname &&
                  !(function (e, t) {
                    return (t.lastIndex = 0), t.test(e.hostname);
                  })(i, t.hostname) &&
                  n.issues.push({
                    code: "invalid_format",
                    format: "url",
                    note: "Invalid hostname",
                    pattern: t.hostname.source,
                    input: n.value,
                    inst: e,
                    continue: !t.abort,
                  }),
                t.protocol &&
                  !(function (e, t) {
                    return (
                      (t.lastIndex = 0),
                      t.test(
                        e.protocol.endsWith(":")
                          ? e.protocol.slice(0, -1)
                          : e.protocol
                      )
                    );
                  })(i, t.protocol) &&
                  n.issues.push({
                    code: "invalid_format",
                    format: "url",
                    note: "Invalid protocol",
                    pattern: t.protocol.source,
                    input: n.value,
                    inst: e,
                    continue: !t.abort,
                  }),
                void (n.value = t.normalize ? i.href : Ca(r)));
          } catch (r) {
            n.issues.push({
              code: "invalid_format",
              format: "url",
              input: n.value,
              inst: e,
              continue: !t.abort,
            });
          }
        });
    }),
    Sa = rs("$ZodEmoji", (e, t) => {
      t.pattern ??
        (t.pattern = new RegExp(
          "^(?=[\\s\\S]*[\\p{Extended_Pictographic}\\p{Regional_Indicator}\\u20E3])[\\p{Extended_Pictographic}\\p{Emoji_Component}]+$",
          "u"
        )),
        ha.init(e, t);
    }),
    Ia = rs("$ZodNanoID", (e, t) => {
      if (void 0 !== t.length && (!Number.isInteger(t.length) || t.length < 1))
        throw new Error(`Invalid nanoid length: ${t.length}`);
      var n;
      t.pattern ??
        (t.pattern =
          void 0 === t.length
            ? Ss
            : ((n = t.length), new RegExp(`^[a-zA-Z0-9_-]{${n}}$`))),
        ha.init(e, t);
    }),
    _a = rs("$ZodCUID", (e, t) => {
      t.pattern ?? (t.pattern = vs), ha.init(e, t);
    }),
    ka = rs("$ZodCUID2", (e, t) => {
      t.pattern ?? (t.pattern = ys), ha.init(e, t);
    }),
    Pa = rs("$ZodULID", (e, t) => {
      t.pattern ?? (t.pattern = As), ha.init(e, t);
    }),
    Ba = rs("$ZodXID", (e, t) => {
      t.pattern ?? (t.pattern = Cs), ha.init(e, t);
    }),
    Ea = rs("$ZodKSUID", (e, t) => {
      t.pattern ?? (t.pattern = ws), ha.init(e, t);
    }),
    xa = rs("$ZodISODateTime", (e, t) => {
      t.pattern ??
        (t.pattern = (function (e) {
          const t = ["Z"];
          e.offset && t.push("([+-](?:[01]\\d|2[0-3]):[0-5]\\d)");
          const n = `${Us({ precision: e.precision, seconds: !0 })}(?:${t.join(
              "|"
            )})`,
            r = e.local ? `${n}|${Us({ precision: e.precision })}` : n;
          return new RegExp(`^${Ms}T(?:${r})$`);
        })(t)),
        ha.init(e, t);
    }),
    Ta = rs("$ZodISODate", (e, t) => {
      t.pattern ?? (t.pattern = Fs), ha.init(e, t);
    }),
    Ra = rs("$ZodISOTime", (e, t) => {
      t.pattern ?? (t.pattern = new RegExp(`^${Us(t)}$`)), ha.init(e, t);
    }),
    za = rs("$ZodISODuration", (e, t) => {
      t.pattern ?? (t.pattern = Is), ha.init(e, t);
    }),
    Ma = rs("$ZodIPv4", (e, t) => {
      t.pattern ?? (t.pattern = Bs), ha.init(e, t);
    }),
    Oa = /^[0-9a-fA-F:.]+$/;
  function Fa(e) {
    return !!Oa.test(e) && va(`http://[${e}]`);
  }
  const Ua = rs("$ZodIPv6", (e, t) => {
      t.pattern ?? (t.pattern = Es),
        ha.init(e, t),
        (e._zod.check = (n) => {
          Fa(n.value) ||
            n.issues.push({
              code: "invalid_format",
              format: "ipv6",
              input: n.value,
              inst: e,
              continue: !t.abort,
            });
        });
    }),
    Na = rs("$ZodCIDRv4", (e, t) => {
      t.pattern ?? (t.pattern = xs), ha.init(e, t);
    });
  const La = rs("$ZodCIDRv6", (e, t) => {
    t.pattern ?? (t.pattern = Ts),
      ha.init(e, t),
      (e._zod.check = (n) => {
        (function (e) {
          const t = e.split("/");
          if (2 !== t.length) return !1;
          const [n, r] = t;
          if (!r) return !1;
          const i = Number(r);
          return `${i}` === r && !(i < 0 || i > 128) && Fa(n);
        })(n.value) ||
          n.issues.push({
            code: "invalid_format",
            format: "cidrv6",
            input: n.value,
            inst: e,
            continue: !t.abort,
          });
      });
  });
  function ja(e) {
    if ("" === e) return !0;
    if (/\s/.test(e)) return !1;
    if (e.length % 4 != 0) return !1;
    try {
      return atob(e), !0;
    } catch {
      return !1;
    }
  }
  const Da = /^[0-9a-zA-Z+/]*={0,2}$/,
    Va = rs("$ZodBase64", (e, t) => {
      t.pattern ?? (t.pattern = Da),
        ha.init(e, t),
        (e._zod.check = (n) => {
          ja(n.value) ||
            n.issues.push({
              code: "invalid_format",
              format: "base64",
              input: n.value,
              inst: e,
              continue: !t.abort,
            });
        });
    }),
    Ga = /^[A-Za-z0-9_-]*$/;
  const $a = rs("$ZodBase64URL", (e, t) => {
      t.pattern ?? (t.pattern = Ga),
        ha.init(e, t),
        (e._zod.check = (n) => {
          (function (e) {
            if (!Ga.test(e)) return !1;
            const t = e.replace(/[-_]/g, (e) => ("-" === e ? "+" : "/"));
            return ja(t.padEnd(4 * Math.ceil(t.length / 4), "="));
          })(n.value) ||
            n.issues.push({
              code: "invalid_format",
              format: "base64url",
              input: n.value,
              inst: e,
              continue: !t.abort,
            });
        });
    }),
    qa = rs("$ZodE164", (e, t) => {
      t.pattern ?? (t.pattern = zs), ha.init(e, t);
    });
  const Za = rs("$ZodJWT", (e, t) => {
      ha.init(e, t),
        (e._zod.check = (n) => {
          (function (e, t = null) {
            try {
              const n = e.split(".");
              if (3 !== n.length) return !1;
              const [r] = n;
              if (!r) return !1;
              const i = JSON.parse(atob(r));
              return !(
                ("typ" in i && "JWT" !== i?.typ) ||
                !i.alg ||
                (t && (!("alg" in i) || i.alg !== t))
              );
            } catch {
              return !1;
            }
          })(n.value, t.alg) ||
            n.issues.push({
              code: "invalid_format",
              format: "jwt",
              input: n.value,
              inst: e,
              continue: !t.abort,
            });
        });
    }),
    Ka = rs("$ZodNumber", (e, t) => {
      ua.init(e, t),
        (e._zod.pattern = js),
        (e._zod.parse = (n, r) => {
          if (t.coerce)
            try {
              n.value = Number(n.value);
            } catch (e) {}
          const i = n.value;
          if ("number" == typeof i && !Number.isNaN(i) && Number.isFinite(i))
            return n;
          const o =
            "number" == typeof i
              ? Number.isNaN(i)
                ? "NaN"
                : Number.isFinite(i)
                ? void 0
                : String(i)
              : void 0;
          return (
            n.issues.push({
              expected: "number",
              code: "invalid_type",
              input: i,
              inst: e,
              ...(o ? { received: o } : {}),
            }),
            n
          );
        });
    }),
    Ha = rs("$ZodNumberFormat", (e, t) => {
      Js.init(e, t), Ka.init(e, t);
    }),
    Wa = rs("$ZodBoolean", (e, t) => {
      ua.init(e, t),
        (e._zod.pattern = Ds),
        (e._zod.parse = (n, r) => {
          if (t.coerce)
            try {
              n.value = Boolean(n.value);
            } catch (e) {}
          const i = n.value;
          return (
            "boolean" == typeof i ||
              n.issues.push({
                expected: "boolean",
                code: "invalid_type",
                input: i,
                inst: e,
              }),
            n
          );
        });
    }),
    Ja = rs("$ZodUnknown", (e, t) => {
      ua.init(e, t), (e._zod.parse = (e) => e);
    }),
    Ya = rs("$ZodNever", (e, t) => {
      ua.init(e, t),
        (e._zod.parse = (t, n) => (
          t.issues.push({
            expected: "never",
            code: "invalid_type",
            input: t.value,
            inst: e,
          }),
          t
        ));
    });
  function Qa(e, t) {
    const n = Uo(e._zod.def.checks);
    if (!n.length) return;
    const r = Math.min(...n.map((e) => e[0])),
      i = e._zod.parse;
    e._zod.parse = (n, o) => {
      const s = t(n.value);
      if (s > r && !o?.skipChecks && "backward" !== o?.direction)
        for (const [t, r] of Uo(e._zod.def.checks))
          if (s > t && r._zod.def.when(n)) {
            const t = n.issues.length;
            return (
              r._zod.check(n),
              (n.issues[t].continue = !1),
              No(n.issues, t, e),
              n
            );
          }
      return i(n, o);
    };
  }
  const Xa = (e) => (Array.isArray(e) ? e.length : -1);
  function ec(e, t, n) {
    e.issues.length && t.issues.push(...Oo(n, e.issues)),
      (t.value[n] = e.value);
  }
  const tc = rs("$ZodArray", (e, t) => {
    ua.init(e, t);
    const n = ss.memoizer;
    n?.attach(e),
      (e._zod.parse = (r, i) => {
        const o = r.value;
        if (!Array.isArray(o))
          return (
            r.issues.push({
              expected: "array",
              code: "invalid_type",
              input: o,
              inst: e,
            }),
            r
          );
        r.value = n ? n.alloc(e, r, Array(o.length), i) : Array(o.length);
        const s = [],
          a = i?.abortEarly;
        for (let e = 0; e < o.length; e++) {
          const n = o[e],
            c = t.element._zod.run({ value: n, issues: [] }, i);
          if (c instanceof Promise) s.push(c.then((t) => ec(t, r, e)));
          else if ((ec(c, r, e), a && 0 !== c.issues.length && zo(c))) break;
        }
        return s.length ? Promise.all(s).then(() => r) : r;
      }),
      Qa(e, Xa);
  });
  function nc(e, t, n, r, i, o) {
    const s = n in r,
      a = "optional" === o;
    if (s || !a || "optional" !== i) {
      if (e.issues.length) {
        if (void 0 !== i && a && !s) return;
        t.issues.push(...Oo(n, e.issues));
      }
      s || void 0 !== i
        ? void 0 === e.value
          ? (s || ("defaulted" === i && !a)) && (t.value[n] = void 0)
          : (t.value[n] = e.value)
        : e.issues.length ||
          t.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: void 0,
            path: [n],
          });
    }
  }
  const rc = [];
  function ic(e) {
    const t = Object.keys(e.shape),
      n = Object.getOwnPropertySymbols(e.shape),
      r = n.length ? n : rc,
      i = r.length ? [...t, ...r] : t;
    for (const t of i)
      if (!e.shape?.[t]?._zod?.traits?.has("$ZodType"))
        throw new Error(
          `Invalid element at key "${String(t)}": expected a Zod schema`
        );
    const o =
      ((s = e.shape),
      Object.keys(s).filter(
        (e) => void 0 !== s[e]._zod.optin && "optional" === s[e]._zod.optout
      ));
    var s;
    return {
      ...e,
      allKeys: i,
      symbolKeys: r,
      keySet: new Set(t),
      numKeys: t.length,
      optionalKeys: new Set(o),
    };
  }
  function oc(e, t, n, r, i, o, s) {
    const a = [],
      c = i.keySet,
      d = i.catchall._zod,
      u = d.def.type,
      l = d.optin,
      p = d.optout;
    let f = 0;
    for (const i in t) {
      if (s && n.issues.length !== f) {
        if (zo(n, f)) break;
        f = n.issues.length;
      }
      if (c.has(i)) continue;
      if ("__proto__" === i) {
        "never" === u && a.push(i);
        continue;
      }
      if ("never" === u) {
        a.push(i);
        continue;
      }
      const o = d.run({ value: t[i], issues: [] }, r);
      o instanceof Promise
        ? e.push(o.then((e) => nc(e, n, i, t, l, p)))
        : nc(o, n, i, t, l, p);
    }
    return (
      a.length &&
        n.issues.push({
          code: "unrecognized_keys",
          keys: a,
          input: t,
          inst: o,
          continue: !0,
        }),
      e.length ? Promise.all(e).then(() => n) : n
    );
  }
  const sc = rs("$ZodObject", (e, t) => {
      ua.init(e, t);
      const n = Object.getOwnPropertyDescriptor(t, "shape"),
        r = n?.get ? n.get.raw : t.shape ?? {};
      if (r) {
        const e = () => {
          const n = { ...r };
          return (
            Object.defineProperty(t, "shape", { value: n }), (e.raw = n), n
          );
        };
        (e.raw = r), Object.defineProperty(t, "shape", { get: e });
      }
      const i = ao(() => ic(t));
      Yo(e, "propValues", (e) => {
        const t = e.def.shape,
          n = {};
        for (const e in t) {
          const r = t[e]._zod;
          if (r.values) {
            Object.prototype.hasOwnProperty.call(n, e) || uo(n, e, new Set());
            for (const t of r.values) n[e].add(t);
            void 0 !== r.optin && n[e].add(void 0);
          }
        }
        return n;
      });
      const o = yo,
        s = t.catchall;
      let a;
      const c = ss.memoizer;
      c?.attach(e),
        (e._zod.parse = (t, n) => {
          a ?? (a = i.value);
          const r = t.value;
          if (!o(r))
            return (
              t.issues.push({
                expected: "object",
                code: "invalid_type",
                input: r,
                inst: e,
              }),
              t
            );
          t.value = c ? c.alloc(e, t, {}, n) : {};
          const d = [],
            u = a.shape,
            l = n?.abortEarly;
          let p = t.issues.length;
          for (const e of a.allKeys) {
            if (l && t.issues.length !== p) {
              if (zo(t, p)) break;
              p = t.issues.length;
            }
            if ("__proto__" === e) continue;
            const i = u[e],
              o = i._zod.optin,
              s = i._zod.optout,
              a = i._zod.run({ value: r[e], issues: [] }, n);
            a instanceof Promise
              ? d.push(a.then((n) => nc(n, t, e, r, o, s)))
              : nc(a, t, e, r, o, s);
          }
          return s
            ? oc(d, r, t, n, i.value, e, !0 === l)
            : d.length
            ? Promise.all(d).then(() => t)
            : t;
        });
    }),
    ac = rs("$ZodObjectJIT", (e, t) => {
      sc.init(e, t);
      const n = e._zod.parse,
        r = ao(() => ic(t)),
        i = ss.memoizer;
      let o;
      const s = yo,
        a = !ss.jitless,
        c = a && Ao.value,
        d = t.catchall;
      let u;
      e._zod.parse = (l, p) => {
        u ?? (u = r.value);
        const f = l.value;
        return s(f)
          ? a && c && !1 === p?.async && !0 !== p.jitless
            ? (o ||
                (o = ((t) => {
                  const n = r.value,
                    o = n.symbolKeys,
                    s = new ca(["payload", "ctx"], {
                      shape: t,
                      inst: e,
                      memo: i,
                      syms: o,
                    }),
                    a = (e) =>
                      `shape[${e}]._zod.run({ value: input[${e}], issues: [] }, ctx)`,
                    c = (e, t) =>
                      `\n          let ${e}_ab = false;\n          for (let i = 0; i < ${e}.issues.length; i++) {\n            const iss = ${e}.issues[i];\n            iss.path = iss.path ? [${t}, ...iss.path] : [${t}];\n            payload.issues.push(iss);\n            if (iss.continue !== true) ${e}_ab = true;\n          }\n          if (${e}_ab && ctx && ctx.abortEarly) {\n            payload.value = newResult;\n            return payload;\n          }`;
                  s.write("const input = payload.value;");
                  const d = Object.create(null);
                  let u = 0;
                  for (const e of n.allKeys) d[e] = "key_" + u++;
                  s.write(
                    i
                      ? "const newResult = memo.alloc(inst, payload, {}, ctx);"
                      : "const newResult = {};"
                  );
                  for (const e of n.allKeys) {
                    if ("__proto__" === e) continue;
                    const n = d[e],
                      r =
                        "symbol" == typeof e ? `syms[${o.indexOf(e)}]` : bo(e),
                      i = `${r} in input`,
                      u = t[e],
                      l = u?._zod?.optin,
                      p = void 0 !== l,
                      f = "optional" === u?._zod?.optout;
                    if ((s.write(`const ${n} = ${a(r)};`), p && f)) {
                      const e =
                        "optional" === l
                          ? `${n}_present`
                          : `${n}.value !== undefined || ${n}_present`;
                      s.write(
                        `\n        const ${n}_present = ${i};\n        if (!${n}.issues.length || ${n}_present) {\n          if (${n}.issues.length) {${c(
                          n,
                          r
                        )}\n          }\n\n          if (${e}) {\n            newResult[${r}] = ${n}.value;\n          }\n        }\n\n      `
                      );
                    } else
                      p
                        ? (s.write(
                            `\n        if (${n}.issues.length) {${c(
                              n,
                              r
                            )}\n        }\n      `
                          ),
                          "defaulted" === l
                            ? s.write(`newResult[${r}] = ${n}.value;`)
                            : s.write(
                                `\n        if (${n}.value !== undefined || ${i}) {\n          newResult[${r}] = ${n}.value;\n        }\n      `
                              ))
                        : s.write(
                            `\n        const ${n}_present = ${i};\n        if (${n}.issues.length) {${c(
                              n,
                              r
                            )}\n        }\n        if (!${n}_present && !${n}.issues.length) {\n          payload.issues.push({\n            code: "invalid_type",\n            expected: "nonoptional",\n            input: undefined,\n            path: [${r}]\n          });\n          if (ctx && ctx.abortEarly) {\n            payload.value = newResult;\n            return payload;\n          }\n        }\n\n        if (${n}_present) {\n          newResult[${r}] = ${n}.value;\n        }\n\n      `
                          );
                  }
                  return (
                    s.write("payload.value = newResult;"),
                    s.write("return payload;"),
                    s.compile()
                  );
                })(t.shape)),
              (l = o(l, p)),
              d ? oc([], f, l, p, u, e, !0 === p?.abortEarly) : l)
            : n(l, p)
          : (l.issues.push({
              expected: "object",
              code: "invalid_type",
              input: f,
              inst: e,
            }),
            l);
      };
    });
  function cc(e, t, n, r) {
    for (const n of e) if (0 === n.issues.length) return (t.value = n.value), t;
    const i = e.filter((e) => !zo(e));
    return 1 === i.length
      ? ((t.value = i[0].value), i[0])
      : (t.issues.push({
          code: "invalid_union",
          input: t.value,
          inst: n,
          errors: e.map((e) => e.issues.map((e) => Lo(e, r, as()))),
        }),
        t);
  }
  const dc = rs("$ZodUnion", (e, t) => {
    ua.init(e, t),
      Yo(e, "optin", (e) =>
        e.def.options.some((e) => "defaulted" === e._zod.optin)
          ? "defaulted"
          : e.def.options.some((e) => void 0 !== e._zod.optin)
          ? "optional"
          : void 0
      ),
      Yo(e, "optout", (e) =>
        e.def.options.some((e) => "optional" === e._zod.optout)
          ? "optional"
          : void 0
      ),
      Yo(e, "values", (e) => {
        if (e.def.options.every((e) => e._zod.values))
          return new Set(
            e.def.options.flatMap((e) => Array.from(e._zod.values))
          );
      }),
      Yo(e, "pattern", (e) => {
        if (e.def.options.every((e) => e._zod.pattern)) {
          const t = e.def.options.map((e) => e._zod.pattern);
          return new RegExp(`^(${t.map((e) => co(e.source)).join("|")})$`);
        }
      });
    const n = 1 === t.options.length ? t.options[0]._zod.run : null;
    e._zod.parse = (r, i) => {
      if (n) return n(r, i);
      let o = !1;
      const s = [];
      for (const e of t.options) {
        const t = e._zod.run({ value: r.value, issues: [] }, i);
        if (t instanceof Promise) s.push(t), (o = !0);
        else {
          if (0 === t.issues.length) return t;
          s.push(t);
        }
      }
      return o ? Promise.all(s).then((t) => cc(t, r, e, i)) : cc(s, r, e, i);
    };
  });
  const uc = rs("$ZodIntersection", (e, t) => {
    ua.init(e, t),
      (e._zod.parse = (e, n) => {
        const r = e.value,
          i = t.left._zod.run({ value: r, issues: [] }, n),
          o = t.right._zod.run({ value: r, issues: [] }, n);
        return i instanceof Promise || o instanceof Promise
          ? Promise.all([i, o]).then(([t, n]) => pc(e, t, n))
          : pc(e, i, o);
      });
  });
  function lc(e, t) {
    if (e === t) return { valid: !0, data: e };
    if (e instanceof Date && t instanceof Date && +e === +t)
      return { valid: !0, data: e };
    if (Co(e) && Co(t)) {
      const n = Object.keys(t),
        r = Object.keys(e).filter((e) => -1 !== n.indexOf(e)),
        i = { ...e, ...t };
      Object.prototype.hasOwnProperty.call(i, "__proto__") &&
        delete i.__proto__;
      for (const n of r) {
        if ("__proto__" === n) continue;
        const r = lc(e[n], t[n]);
        if (!r.valid)
          return { valid: !1, mergeErrorPath: [n, ...r.mergeErrorPath] };
        i[n] = r.data;
      }
      return { valid: !0, data: i };
    }
    if (Array.isArray(e) && Array.isArray(t)) {
      if (e.length !== t.length) return { valid: !1, mergeErrorPath: [] };
      const n = [];
      for (let r = 0; r < e.length; r++) {
        const i = lc(e[r], t[r]);
        if (!i.valid)
          return { valid: !1, mergeErrorPath: [r, ...i.mergeErrorPath] };
        n.push(i.data);
      }
      return { valid: !0, data: n };
    }
    return { valid: !1, mergeErrorPath: [] };
  }
  function pc(e, t, n) {
    const r = new Map();
    let i;
    const o = new Map(),
      s = (e, t) => {
        let n;
        if ("unrecognized_keys" !== e.code || e.path?.length) {
          if (
            "invalid_key" !== e.code ||
            "record" !== e.origin ||
            1 !== e.path?.length
          )
            return !1;
          {
            const t = String(e.path[0]);
            o.has(t) || o.set(t, e), (n = [t]);
          }
        } else i ?? (i = e), (n = e.keys);
        for (const e of n) r.has(e) || r.set(e, {}), (r.get(e)[t] = !0);
        return !0;
      };
    for (const n of t.issues) s(n, "l") || e.issues.push(n);
    for (const t of n.issues) s(t, "r") || e.issues.push(t);
    const a = [...r].filter(([, e]) => e.l && e.r).map(([e]) => e);
    if (a.length) {
      const t = i ? a.filter((e) => i.keys.includes(e)) : [];
      t.length && e.issues.push({ ...i, keys: t });
      for (const n of a) !t.includes(n) && o.has(n) && e.issues.push(o.get(n));
    }
    const c = lc(t.value, n.value);
    if (!c.valid) {
      if (zo(e)) return e;
      throw new Error(
        `Unmergable intersection. Error path: ${JSON.stringify(
          c.mergeErrorPath
        )}`
      );
    }
    return (e.value = c.data), e;
  }
  const fc = rs("$ZodRecord", (e, t) => {
    ua.init(e, t);
    const n = ss.memoizer;
    n?.attach(e),
      (e._zod.parse = (r, i) => {
        const o = r.value;
        if (!Co(o))
          return (
            r.issues.push({
              expected: "record",
              code: "invalid_type",
              input: o,
              inst: e,
            }),
            r
          );
        const s = [],
          a = t.keyType._zod.values;
        if (a && !t.partial) {
          r.value = n ? n.alloc(e, r, {}, i) : {};
          const c = new Set();
          for (const n of a)
            if (
              "string" == typeof n ||
              "number" == typeof n ||
              "symbol" == typeof n
            ) {
              if (
                (c.add("number" == typeof n ? n.toString() : n),
                "__proto__" === n)
              )
                continue;
              const a = t.keyType._zod.run({ value: n, issues: [] }, i);
              if (a instanceof Promise)
                throw new Error(
                  "Async schemas not supported in object keys currently"
                );
              if (a.issues.length) {
                r.issues.push({
                  code: "invalid_key",
                  origin: "record",
                  issues: a.issues.map((e) => Lo(e, i, as())),
                  input: n,
                  path: [n],
                  inst: e,
                });
                continue;
              }
              const d = a.value;
              if ("__proto__" === d) continue;
              const u = t.valueType._zod.run({ value: o[n], issues: [] }, i);
              u instanceof Promise
                ? s.push(
                    u.then((e) => {
                      e.issues.length && r.issues.push(...Oo(n, e.issues)),
                        (r.value[d] = e.value);
                    })
                  )
                : (u.issues.length && r.issues.push(...Oo(n, u.issues)),
                  (r.value[d] = u.value));
            }
          let d;
          for (const e in o)
            if (!c.has(e))
              if ("loose" === t.mode) {
                if ("__proto__" === e) continue;
                r.value[e] = o[e];
              } else (d = d ?? []), d.push(e);
          d &&
            d.length > 0 &&
            r.issues.push({
              code: "unrecognized_keys",
              input: o,
              inst: e,
              keys: d,
              continue: !0,
            });
        } else {
          let c;
          r.value = n ? n.alloc(e, r, {}, i) : {};
          for (const n of Reflect.ownKeys(o)) {
            if ("__proto__" === n) continue;
            if (!Object.prototype.propertyIsEnumerable.call(o, n)) continue;
            let d = t.keyType._zod.run({ value: n, issues: [] }, i);
            if (d instanceof Promise)
              throw new Error(
                "Async schemas not supported in object keys currently"
              );
            if ("string" == typeof n && js.test(n) && d.issues.length) {
              const e = t.keyType._zod.run({ value: Number(n), issues: [] }, i);
              if (e instanceof Promise)
                throw new Error(
                  "Async schemas not supported in object keys currently"
                );
              0 === e.issues.length && (d = e);
            }
            if (d.issues.length) {
              "loose" === t.mode
                ? (r.value[n] = o[n])
                : a
                ? ((c = c ?? []), c.push(n))
                : r.issues.push({
                    code: "invalid_key",
                    origin: "record",
                    issues: d.issues.map((e) => Lo(e, i, as())),
                    input: n,
                    path: [n],
                    inst: e,
                  });
              continue;
            }
            const u = d.value;
            if ("__proto__" === u) continue;
            const l = t.valueType._zod.run({ value: o[n], issues: [] }, i);
            l instanceof Promise
              ? s.push(
                  l.then((e) => {
                    e.issues.length && r.issues.push(...Oo(n, e.issues)),
                      (r.value[u] = e.value);
                  })
                )
              : (l.issues.length && r.issues.push(...Oo(n, l.issues)),
                (r.value[u] = l.value));
          }
          c &&
            c.length > 0 &&
            r.issues.push({
              code: "unrecognized_keys",
              input: o,
              inst: e,
              keys: c,
              continue: !0,
            });
        }
        return s.length ? Promise.all(s).then(() => r) : r;
      });
  });
  const hc = rs("$ZodEnum", (e, t) => {
      ua.init(e, t);
      const n = ro(t.entries),
        r = new Set(n);
      (e._zod.values = r),
        Yo(e, "pattern", (e) => {
          const t = ro(e.def.entries).filter((e) => So.has(typeof e));
          return new RegExp(
            t.length
              ? `^(${t.map((e) => Io(e.toString())).join("|")})$`
              : "^[^\\s\\S]$"
          );
        }),
        (e._zod.parse = (t, i) => {
          const o = t.value;
          return (
            r.has(o) ||
              t.issues.push({
                code: "invalid_value",
                values: n,
                input: o,
                inst: e,
              }),
            t
          );
        });
    }),
    mc = rs("$ZodTransform", (e, t) => {
      ua.init(e, t),
        (e._zod.optin = "optional"),
        ss.memoizer?.guard(e),
        (e._zod.parse = (n, r) => {
          if ("backward" === r.direction) throw new os(e.constructor.name);
          const i = t.transform(n.value, n);
          if (r.async) {
            return (i instanceof Promise ? i : Promise.resolve(i)).then(
              (e) => ((n.value = e), n)
            );
          }
          if (i instanceof Promise) throw new is();
          return (n.value = i), n;
        });
    });
  function gc(e, t) {
    return (e.value = t.issues.length ? void 0 : t.value), e;
  }
  const bc = rs("$ZodOptional", (e, t) => {
      ua.init(e, t),
        Yo(e, "optin", (e) =>
          "defaulted" === e.def.innerType._zod.optin ? "defaulted" : "optional"
        ),
        (e._zod.optout = "optional"),
        Yo(e, "values", (e) => {
          const t = e.def.innerType._zod.values;
          return t ? new Set([...t, void 0]) : void 0;
        }),
        Yo(e, "pattern", (e) => {
          const t = e.def.innerType._zod.pattern;
          return t ? new RegExp(`^(${co(t.source)})?$`) : void 0;
        }),
        (e._zod.parse = (e, n) => {
          if (void 0 === e.value) {
            if ("defaulted" !== t.innerType._zod.optin) return e;
            const r = t.innerType._zod.run({ value: e.value, issues: [] }, n);
            return r instanceof Promise ? r.then((t) => gc(e, t)) : gc(e, r);
          }
          return t.innerType._zod.run(e, n);
        });
    }),
    vc = rs("$ZodExactOptional", (e, t) => {
      bc.init(e, t),
        Yo(e, "values", (e) => e.def.innerType._zod.values),
        Yo(e, "pattern", (e) => e.def.innerType._zod.pattern),
        (e._zod.parse = (e, n) => t.innerType._zod.run(e, n));
    }),
    yc = rs("$ZodNullable", (e, t) => {
      ua.init(e, t),
        Yo(e, "optin", (e) => e.def.innerType._zod.optin),
        Yo(e, "optout", (e) => e.def.innerType._zod.optout),
        Yo(e, "pattern", (e) => {
          const t = e.def.innerType._zod.pattern;
          return t ? new RegExp(`^(${co(t.source)}|null)$`) : void 0;
        }),
        Yo(e, "values", (e) =>
          e.def.innerType._zod.values
            ? new Set([...e.def.innerType._zod.values, null])
            : void 0
        ),
        (e._zod.parse = (e, n) =>
          null === e.value ? e : t.innerType._zod.run(e, n));
    }),
    Ac = rs("$ZodDefault", (e, t) => {
      ua.init(e, t),
        (e._zod.optin = "defaulted"),
        Yo(e, "values", (e) => e.def.innerType._zod.values),
        (e._zod.parse = (e, n) => {
          if ("backward" === n.direction) return t.innerType._zod.run(e, n);
          if (void 0 === e.value) return (e.value = t.defaultValue), e;
          const r = t.innerType._zod.run(e, n);
          return r instanceof Promise ? r.then((e) => Cc(e, t)) : Cc(r, t);
        });
    });
  function Cc(e, t) {
    return void 0 === e.value && (e.value = t.defaultValue), e;
  }
  const wc = rs("$ZodPrefault", (e, t) => {
      ua.init(e, t),
        (e._zod.optin = "defaulted"),
        Yo(e, "values", (e) => e.def.innerType._zod.values),
        (e._zod.parse = (e, n) => (
          "backward" === n.direction ||
            (void 0 === e.value && (e.value = t.defaultValue)),
          t.innerType._zod.run(e, n)
        ));
    }),
    Sc = rs("$ZodNonOptional", (e, t) => {
      ua.init(e, t),
        Yo(e, "values", (e) => {
          const t = e.def.innerType._zod.values;
          return t ? new Set([...t].filter((e) => void 0 !== e)) : void 0;
        }),
        (e._zod.parse = (n, r) => {
          const i = t.innerType._zod.run(n, r);
          return i instanceof Promise ? i.then((t) => Ic(t, e)) : Ic(i, e);
        });
    });
  function Ic(e, t) {
    return (
      e.issues.length ||
        void 0 !== e.value ||
        e.issues.push({
          code: "invalid_type",
          expected: "nonoptional",
          input: e.value,
          inst: t,
        }),
      e
    );
  }
  function _c(e, t, n, r) {
    return t.issues.length
      ? ((e.value = n.catchValue({
          ...t,
          value: e.value,
          error: { issues: t.issues.map((e) => Lo(e, r, as())) },
          input: e.value,
        })),
        e)
      : ((e.value = t.value), t.memo && (e.memo = !0), e);
  }
  const kc = rs("$ZodCatch", (e, t) => {
      ua.init(e, t),
        Yo(e, "optin", (e) =>
          "defaulted" === e.def.innerType._zod.optin ? "defaulted" : "optional"
        ),
        Yo(e, "optout", (e) => e.def.innerType._zod.optout),
        Yo(e, "values", (e) => e.def.innerType._zod.values),
        (e._zod.parse = (e, n) => {
          if ("backward" === n.direction) return t.innerType._zod.run(e, n);
          const r = t.innerType._zod.run({ value: e.value, issues: [] }, n);
          return r instanceof Promise
            ? r.then((r) => _c(e, r, t, n))
            : _c(e, r, t, n);
        });
    }),
    Pc = rs("$ZodPipe", (e, t) => {
      ua.init(e, t),
        Yo(e, "values", (e) => e.def.in._zod.values),
        Yo(e, "optin", (e) => e.def.in._zod.optin),
        Yo(e, "optout", (e) => e.def.out._zod.optout),
        Yo(e, "propValues", (e) => e.def.in._zod.propValues),
        (e._zod.parse = (e, n) => {
          if ("backward" === n.direction) {
            const r = t.out._zod.run(e, n);
            return r instanceof Promise
              ? r.then((e) => Bc(e, t.in, n))
              : Bc(r, t.in, n);
          }
          const r = t.in._zod.run(e, n);
          return r instanceof Promise
            ? r.then((e) => Bc(e, t.out, n))
            : Bc(r, t.out, n);
        });
    });
  function Bc(e, t, n) {
    return e.issues.some((e) => "unrecognized_keys" !== e.code)
      ? ((e.aborted = !0), e)
      : t._zod.run({ value: e.value, issues: e.issues }, n);
  }
  const Ec = rs("$ZodReadonly", (e, t) => {
    ua.init(e, t),
      Yo(e, "propValues", (e) => e.def.innerType._zod.propValues),
      Yo(e, "values", (e) => e.def.innerType._zod.values),
      Yo(e, "optin", (e) => e.def.innerType?._zod?.optin),
      Yo(e, "optout", (e) => e.def.innerType?._zod?.optout),
      (e._zod.parse = (e, n) => {
        if ("backward" === n.direction) return t.innerType._zod.run(e, n);
        const r = t.innerType._zod.run(e, n);
        return r instanceof Promise ? r.then(xc) : xc(r);
      });
  });
  function xc(e) {
    return e.memo || (e.value = Object.freeze(e.value)), e;
  }
  const Tc = rs("$ZodCustom", (e, t) => {
    $s.init(e, t),
      ua.init(e, t),
      (e._zod.parse = (e, t) => e),
      (e._zod.check = (n) => {
        const r = n.value,
          i = t.fn(r);
        if (i instanceof Promise) return i.then((t) => Rc(t, n, r, e));
        Rc(i, n, r, e);
      });
  });
  function Rc(e, t, n, r) {
    if (!e) {
      const e = {
        code: "custom",
        input: n,
        inst: r,
        path: [...(r._zod.def.path ?? [])],
        continue: !r._zod.def.abort,
      };
      r._zod.def.params && (e.params = r._zod.def.params), t.issues.push(Go(e));
    }
  }
  var zc;
  class Mc {
    constructor() {
      (this._map = new WeakMap()), (this._idmap = new Map());
    }
    add(e, ...t) {
      const n = t[0];
      return (
        this._map.set(e, n),
        n && "object" == typeof n && "id" in n && this._idmap.set(n.id, e),
        this
      );
    }
    clear() {
      return (this._map = new WeakMap()), (this._idmap = new Map()), this;
    }
    remove(e) {
      const t = this._map.get(e);
      return (
        t && "object" == typeof t && "id" in t && this._idmap.delete(t.id),
        this._map.delete(e),
        this
      );
    }
    get(e) {
      const t = e._zod.parent;
      if (t) {
        const n = { ...(this.get(t) ?? {}) };
        delete n.id;
        const r = { ...n, ...this._map.get(e) };
        return Object.keys(r).length ? r : void 0;
      }
      return this._map.get(e);
    }
    has(e) {
      return this._map.has(e);
    }
  }
  (zc = globalThis).__zod_globalRegistry ??
    (zc.__zod_globalRegistry = new Mc());
  const Oc = globalThis.__zod_globalRegistry;
  function Fc(e) {
    return e.checks && (e.checks = [...e.checks]), e;
  }
  function Uc(e, t) {
    return new Ks({ check: "less_than", ...ko(t), value: e, inclusive: !1 });
  }
  function Nc(e, t) {
    return new Ks({ check: "less_than", ...ko(t), value: e, inclusive: !0 });
  }
  function Lc(e, t) {
    return new Hs({ check: "greater_than", ...ko(t), value: e, inclusive: !1 });
  }
  function jc(e, t) {
    return new Hs({ check: "greater_than", ...ko(t), value: e, inclusive: !0 });
  }
  function Dc(e, t) {
    return new Ws({ check: "multiple_of", ...ko(t), value: e });
  }
  function Vc(e, t) {
    return new Ys({ check: "max_length", ...ko(t), maximum: e });
  }
  function Gc(e, t) {
    return new Qs({ check: "min_length", ...ko(t), minimum: e });
  }
  function $c(e, t) {
    return new Xs({ check: "length_equals", ...ko(t), length: e });
  }
  function qc(e) {
    return new aa({ check: "overwrite", tx: e });
  }
  function Zc(e, t) {
    const n = (function (e, t) {
      const n = new $s({ check: "custom", ...ko(t) });
      return (n._zod.check = e), n;
    })(
      (t) => (
        (t.addIssue = (e) => {
          if ("string" == typeof e) t.issues.push(Go(e, t.value, n._zod.def));
          else {
            const r = e;
            r.fatal && (r.continue = !1),
              r.code ?? (r.code = "custom"),
              "input" in r || (r.input = t.value),
              r.inst ?? (r.inst = n),
              r.continue ?? (r.continue = !n._zod.def.abort),
              t.issues.push(Go(r));
          }
        }),
        e(t.value, t)
      ),
      t
    );
    return n;
  }
  function Kc(e, ...t) {
    for (const n of t)
      for (const t of Reflect.ownKeys(n))
        Object.prototype.propertyIsEnumerable.call(n, t) && uo(e, t, n[t]);
    return e;
  }
  function Hc(e) {
    let t = e?.target ?? "draft-2020-12";
    return (
      "draft-4" === t && (t = "draft-04"),
      "draft-7" === t && (t = "draft-07"),
      {
        processors: e.processors ?? {},
        metadataRegistry: e?.metadata ?? Oc,
        target: t,
        unrepresentable: e?.unrepresentable ?? "throw",
        override: e?.override ?? (() => {}),
        io: e?.io ?? "output",
        counter: 0,
        seen: new Map(),
        sharedDefsExtractedFor: void 0,
        sharedEmitDoneFor: void 0,
        cycles: e?.cycles ?? "ref",
        reused: e?.reused ?? "inline",
        intersections: [],
        deferred: [],
        external: e?.external ?? void 0,
      }
    );
  }
  function Wc(e, t, n, r, i) {
    const o =
      "function" == typeof t.unrepresentable
        ? t.unrepresentable({ zodSchema: e, path: r.path, message: i })
        : t.unrepresentable;
    if ("any" === o) return !1;
    if (void 0 === o || "throw" === o) throw new Error(i);
    return Object.assign(n, o), !0;
  }
  function Jc(e, t, n = { path: [], schemaPath: [] }) {
    var r;
    const i = e._zod.def,
      o = t.seen.get(e);
    if (o) {
      o.count++;
      return n.schemaPath.includes(e) && (o.cycle = n.path), o.schema;
    }
    const s = { schema: {}, count: 1, cycle: void 0, path: n.path };
    t.seen.set(e, s),
      (t.sharedDefsExtractedFor = void 0),
      (t.sharedEmitDoneFor = void 0);
    const a = e._zod.toJSONSchema?.();
    if (a) s.schema = a;
    else {
      const r = { ...n, schemaPath: [...n.schemaPath, e], path: n.path };
      if (e._zod.processJSONSchema) e._zod.processJSONSchema(t, s.schema, r);
      else {
        const n = s.schema,
          o = t.processors[i.type];
        if (!o)
          throw new Error(
            `[toJSONSchema]: Non-representable type encountered: ${i.type}`
          );
        o(e, t, n, r);
      }
      const o = e._zod.parent;
      o && (s.ref || (s.ref = o), Jc(o, t, r), (t.seen.get(o).isParent = !0));
    }
    const c = t.metadataRegistry.get(e);
    c && Kc(s.schema, c),
      "input" === t.io &&
        sd(e) &&
        (delete s.schema.examples, delete s.schema.default),
      "input" === t.io &&
        "_prefault" in s.schema &&
        ((r = s.schema).default ?? (r.default = s.schema._prefault)),
      delete s.schema._prefault;
    return t.seen.get(e).schema;
  }
  function Yc(e) {
    return e.replace(/~/g, "~0").replace(/\//g, "~1");
  }
  function Qc(e, t) {
    const n = e.seen.get(t);
    if (!n) throw new Error("Unprocessed schema. This is a bug in Zod.");
    if (e.external && e.sharedDefsExtractedFor === e.external) return;
    const r = new Map();
    for (const t of e.seen.entries()) {
      const n = e.metadataRegistry.get(t[0])?.id;
      if (n) {
        const e = r.get(n);
        if (e && e !== t[0])
          throw new Error(
            `Duplicate schema id "${n}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`
          );
        r.set(n, t[0]);
      }
    }
    const i = (t) => {
      if (t[1].schema.$ref) return;
      const r = t[1],
        { ref: i, defId: o } = ((t) => {
          const r = "draft-2020-12" === e.target ? "$defs" : "definitions";
          if (e.external) {
            const n = e.external.registry.get(t[0])?.id,
              i = e.external.uri ?? ((e) => e);
            if (n) return { ref: i(n) };
            const o = t[1].defId ?? t[1].schema.id ?? "schema" + e.counter++;
            return (
              (t[1].defId = o),
              { defId: o, ref: `${i("__shared")}#/${r}/${Yc(o)}` }
            );
          }
          const i = `#/${r}/`;
          if (t[1] === n && !t[1].schema.id) return { ref: "#" };
          const o = t[1].schema.id ?? "__schema" + e.counter++;
          return { defId: o, ref: i + Yc(o) };
        })(t);
      (r.def = { ...r.schema }), o && (r.defId = o);
      const s = r.schema;
      for (const e in s) delete s[e];
      s.$ref = i;
    };
    if ("throw" === e.cycles)
      for (const t of e.seen.entries()) {
        const e = t[1];
        if (e.cycle)
          throw new Error(
            `Cycle detected: #/${e.cycle?.join(
              "/"
            )}/<root>\n\nSet the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`
          );
      }
    for (const n of e.seen.entries()) {
      const r = n[1];
      if (t === n[0]) {
        i(n);
        continue;
      }
      if (e.external) {
        const r = e.external.registry.get(n[0])?.id;
        if (t !== n[0] && r) {
          i(n);
          continue;
        }
      }
      const o = e.metadataRegistry.get(n[0])?.id;
      o ? i(n) : (r.cycle || (r.count > 1 && "ref" === e.reused)) && i(n);
    }
    e.external && (e.sharedDefsExtractedFor = e.external);
  }
  function Xc(e) {
    const t = e.anyOf;
    if (!Array.isArray(t) || 0 === t.length || void 0 !== e.type) return;
    const n = [];
    for (const e of t) {
      if (!e || "object" != typeof e) return;
      Xc(e);
      const t = Object.keys(e);
      if (1 !== t.length || "type" !== t[0]) return;
      const r = e.type;
      for (const e of Array.isArray(r) ? r : [r]) {
        if ("string" != typeof e) return;
        n.includes(e) || n.push(e);
      }
    }
    delete e.anyOf, (e.type = 1 === n.length ? n[0] : n);
  }
  const ed = new Set([
      "type",
      "properties",
      "required",
      "additionalProperties",
    ]),
    td = ["oneOf", "anyOf"];
  function nd(e) {
    const t = e.additionalProperties;
    return void 0 === t || !1 === t || "object" != typeof t || null === t
      ? null
      : Object.keys(t).length
      ? t
      : null;
  }
  function rd(e) {
    const t = [];
    for (const n of e) {
      if ("object" != typeof n || "object" !== n.type) return null;
      for (const e in n) if (!ed.has(e)) return null;
      t.push(n);
    }
    const n = {},
      r = new Set();
    for (const e of t) {
      for (const r in e.properties) {
        if (Object.prototype.hasOwnProperty.call(n, r)) continue;
        const e = [];
        for (const n of t) {
          const t = n.properties?.[r] ?? nd(n);
          null != t &&
            (e.some((e) => JSON.stringify(e) === JSON.stringify(t)) ||
              e.push(t));
        }
        uo(n, r, 1 === e.length ? e[0] : rd(e) ?? { allOf: e });
      }
      for (const t of e.required ?? []) r.add(t);
    }
    const i = { type: "object", properties: n };
    if (
      (r.size && (i.required = [...r]),
      t.every((e) => !1 === e.additionalProperties))
    )
      i.additionalProperties = !1;
    else {
      const e = [];
      for (const n of t) {
        const t = nd(n);
        t &&
          !e.some((e) => JSON.stringify(e) === JSON.stringify(t)) &&
          e.push(t);
      }
      1 === e.length
        ? (i.additionalProperties = e[0])
        : e.length > 1 && (i.additionalProperties = { allOf: e });
    }
    return i;
  }
  function id(e) {
    const t = e.allOf;
    if (!Array.isArray(t) || t.length < 2) return;
    for (const t of ed) if (t in e) return;
    const n = t.filter((e) => td.some((t) => Array.isArray(e[t])));
    let r = null;
    if (n.length) {
      const e = n[0],
        i = td.find((t) => Array.isArray(e[t]));
      if (1 !== Object.keys(e).length) return;
      const o = t.filter((t) => t !== e),
        s = e[i].map((e) => rd([...o, e]));
      if (s.some((e) => !e)) return;
      r = { [i]: s };
    } else r = rd(t);
    r && (delete e.allOf, Kc(e, r));
  }
  function od(e, t) {
    const n = e.seen.get(t);
    if (!n) throw new Error("Unprocessed schema. This is a bug in Zod.");
    const r = (t) => {
      const n = e.seen.get(t);
      if (null === n.ref) return;
      const i = n.def ?? n.schema,
        o = { ...i },
        s = n.ref;
      if (((n.ref = null), s)) {
        r(s);
        const n = e.seen.get(s),
          a = n.schema;
        !a.$ref ||
        ("draft-07" !== e.target &&
          "draft-04" !== e.target &&
          "openapi-3.0" !== e.target)
          ? Kc(i, a)
          : ((i.allOf = i.allOf ?? []), i.allOf.push(a)),
          Kc(i, o);
        if (t._zod.parent === s)
          for (const e in i)
            "$ref" !== e && "allOf" !== e && (e in o || delete i[e]);
        if (a.$ref && n.def)
          for (const e in i)
            "$ref" !== e &&
              "allOf" !== e &&
              e in n.def &&
              JSON.stringify(i[e]) === JSON.stringify(n.def[e]) &&
              delete i[e];
      }
      const a = t._zod.parent;
      if (a && a !== s) {
        r(a);
        const t = e.seen.get(a);
        if (t?.schema.$ref && ((i.$ref = t.schema.$ref), t.def))
          for (const e in i)
            "$ref" !== e &&
              "allOf" !== e &&
              e in t.def &&
              JSON.stringify(i[e]) === JSON.stringify(t.def[e]) &&
              delete i[e];
      }
      e.override({ zodSchema: t, jsonSchema: i, path: n.path ?? [] });
    };
    if (!e.external || e.sharedEmitDoneFor !== e.external) {
      for (const t of [...e.seen.entries()].reverse()) r(t[0]);
      if ("openapi-3.0" !== e.target)
        for (const t of e.seen.entries()) Xc(t[1].def ?? t[1].schema);
      for (const t of e.deferred) t();
      if (e.intersections.length) {
        const t = new Map();
        for (const n of e.seen.values())
          for (const e of [n.schema, n.def]) {
            const n = e?.allOf;
            if (!Array.isArray(n)) continue;
            const r = t.get(n);
            r ? r.push(e) : t.set(n, [e]);
          }
        for (const n of e.intersections) for (const e of t.get(n) ?? []) id(e);
      }
    }
    const i = {};
    if (
      ("draft-2020-12" === e.target
        ? (i.$schema = "https://json-schema.org/draft/2020-12/schema")
        : "draft-07" === e.target
        ? (i.$schema = "http://json-schema.org/draft-07/schema#")
        : "draft-04" === e.target
        ? (i.$schema = "http://json-schema.org/draft-04/schema#")
        : e.target,
      e.external?.uri)
    ) {
      const n = e.external.registry.get(t)?.id;
      if (!n) throw new Error("Schema is missing an `id` property");
      i.$id = e.external.uri(n);
    }
    Kc(i, n.defId ? n.schema : n.def ?? n.schema);
    const o = e.metadataRegistry.get(t)?.id;
    void 0 !== o && i.id === o && delete i.id;
    const s = e.external?.defs ?? {};
    if (!e.external || e.sharedEmitDoneFor !== e.external)
      for (const t of e.seen.entries()) {
        const e = t[1];
        e.def &&
          e.defId &&
          (e.def.id === e.defId && delete e.def.id, uo(s, e.defId, e.def));
      }
    e.external && (e.sharedEmitDoneFor = e.external),
      e.external ||
        (Object.keys(s).length > 0 &&
          ("draft-2020-12" === e.target ? (i.$defs = s) : (i.definitions = s)));
    try {
      const n = JSON.parse(JSON.stringify(i));
      return (
        Object.defineProperty(n, "~standard", {
          value: {
            ...t["~standard"],
            jsonSchema: {
              input: ad(t, "input", e.processors),
              output: ad(t, "output", e.processors),
            },
          },
          enumerable: !1,
          writable: !1,
        }),
        n
      );
    } catch (e) {
      throw new Error("Error converting schema to JSON.");
    }
  }
  function sd(e, t) {
    const n = t ?? { seen: new Set() };
    if (n.seen.has(e)) return !1;
    n.seen.add(e);
    const r = e._zod.def;
    if ("transform" === r.type) return !0;
    if ("array" === r.type) return sd(r.element, n);
    if ("set" === r.type) return sd(r.valueType, n);
    if ("lazy" === r.type) return sd(r.getter(), n);
    if (
      "promise" === r.type ||
      "optional" === r.type ||
      "nonoptional" === r.type ||
      "nullable" === r.type ||
      "readonly" === r.type ||
      "default" === r.type ||
      "prefault" === r.type ||
      "catch" === r.type
    )
      return sd(r.innerType, n);
    if ("intersection" === r.type) return sd(r.left, n) || sd(r.right, n);
    if ("record" === r.type || "map" === r.type)
      return sd(r.keyType, n) || sd(r.valueType, n);
    if ("pipe" === r.type)
      return !!e._zod.traits.has("$ZodCodec") || sd(r.in, n) || sd(r.out, n);
    if ("object" === r.type) {
      for (const e in r.shape) if (sd(r.shape[e], n)) return !0;
      return !1;
    }
    if ("union" === r.type) {
      for (const e of r.options) if (sd(e, n)) return !0;
      return !1;
    }
    if ("tuple" === r.type) {
      for (const e of r.items) if (sd(e, n)) return !0;
      return !(!r.rest || !sd(r.rest, n));
    }
    return !1;
  }
  const ad =
    (e, t, n = {}) =>
    (r) => {
      const { libraryOptions: i, target: o } = r ?? {},
        s = Hc({ ...(i ?? {}), target: o, io: t, processors: n });
      return Jc(e, s), Qc(s, e), od(s, e);
    };
  const cd = (e, t, n) => {
      (void 0 === e[t] || n > e[t]) && (e[t] = n);
    },
    dd = (e, t, n) => {
      (void 0 === e[t] || n < e[t]) && (e[t] = n);
    },
    ud = (e, t) => {
      cd(e, "minimum", t), dd(e, "maximum", t);
    },
    ld = (e, t) => {
      e.multipleOf ?? (e.multipleOf = []),
        e.multipleOf.includes(t) || e.multipleOf.push(t);
    },
    pd = (e, t) => {
      e.patterns ?? (e.patterns = new Set()), e.patterns.add(t);
    },
    fd = (e, t) => {
      e.mime = e.mime ? e.mime.filter((e) => t.includes(e)) : [...t];
    },
    hd = (e, t) => {
      (e.format = t), t.includes("int") && (e.isInt = !0);
    },
    md = (e, t) => cd(e, "minimum", t.minimum),
    gd = (e, t) => dd(e, "maximum", t.maximum),
    bd = (e) => (t, n) => {
      hd(t, n.format);
      const [r, i] = e[n.format];
      cd(t, "minimum", r), dd(t, "maximum", i);
    },
    vd = {
      greater_than: (e, t) =>
        cd(e, t.inclusive ? "minimum" : "exclusiveMinimum", t.value),
      less_than: (e, t) =>
        dd(e, t.inclusive ? "maximum" : "exclusiveMaximum", t.value),
      multiple_of: (e, t) => ld(e, t.value),
      number_format: bd(Bo),
      bigint_format: bd(Eo),
      min_length: md,
      max_length: gd,
      length_equals: (e, t) => ud(e, t.length),
      min_size: md,
      max_size: gd,
      size_equals: (e, t) => ud(e, t.size),
      string_format: (e, t) => {
        hd(e, t.format),
          t.pattern && pd(e, t.pattern),
          ("base64" !== t.format && "base64url" !== t.format) ||
            (e.contentEncoding = t.format),
          (t.local || -1 === t.precision) && (e.laxFormat = !0);
      },
      mime_type: (e, t) => fd(e, t.mime),
    };
  function yd(e) {
    const t = {},
      n = e._zod.def,
      r = e._zod.traits.has("$ZodCheck")
        ? [e, ...(n.checks ?? [])]
        : n.checks ?? [];
    for (const e of r) vd[e._zod.def.check]?.(t, e._zod.def);
    const i = e._zod.bag;
    void 0 !== i.minimum && cd(t, "minimum", i.minimum),
      void 0 !== i.exclusiveMinimum &&
        cd(t, "exclusiveMinimum", i.exclusiveMinimum),
      void 0 !== i.maximum && dd(t, "maximum", i.maximum),
      void 0 !== i.exclusiveMaximum &&
        dd(t, "exclusiveMaximum", i.exclusiveMaximum),
      void 0 !== i.multipleOf && ld(t, i.multipleOf),
      void 0 !== i.format &&
        (t.format ?? (t.format = i.format),
        i.format.includes("int") && (t.isInt = !0)),
      i.mime && fd(t, i.mime);
    for (const e of i.patterns ?? []) pd(t, e);
    return t;
  }
  const Ad = {
      guid: "uuid",
      url: "uri",
      datetime: "date-time",
      json_string: "json-string",
      regex: "",
    },
    Cd = new Map([
      [
        Da,
        /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/,
      ],
      [Ga, /^(?:[A-Za-z0-9_-]{4})*(?:[A-Za-z0-9_-]{2,3})?$/],
    ]),
    wd = (e) => Cd.get(e) ?? e,
    Sd = (e, t, n, r) => {
      const i = n;
      i.type = "string";
      const {
        minimum: o,
        maximum: s,
        format: a,
        patterns: c,
        contentEncoding: d,
        laxFormat: u,
      } = yd(e);
      if (
        ("number" == typeof o && (i.minLength = o),
        "number" == typeof s && (i.maxLength = s),
        a &&
          ((i.format = Ad[a] ?? a),
          "" === i.format && delete i.format,
          ("time" === a || u) && delete i.format),
        d && (i.contentEncoding = d),
        c && c.size > 0)
      ) {
        const e = [...c].map(wd);
        1 === e.length
          ? (i.pattern = e[0].source)
          : e.length > 1 &&
            (i.allOf = [
              ...e.map((e) => ({
                ...("draft-07" === t.target ||
                "draft-04" === t.target ||
                "openapi-3.0" === t.target
                  ? { type: "string" }
                  : {}),
                pattern: e.source,
              })),
            ]);
      }
    },
    Id = (e, t, n, r) => {
      const i = n,
        {
          minimum: o,
          maximum: s,
          multipleOf: a,
          exclusiveMaximum: c,
          exclusiveMinimum: d,
          isInt: u,
        } = yd(e);
      i.type = u ? "integer" : "number";
      const l = "number" == typeof d && d >= (o ?? Number.NEGATIVE_INFINITY),
        p = "number" == typeof c && c <= (s ?? Number.POSITIVE_INFINITY),
        f = "draft-04" === t.target || "openapi-3.0" === t.target;
      if (
        (l
          ? f
            ? ((i.minimum = d), (i.exclusiveMinimum = !0))
            : (i.exclusiveMinimum = d)
          : "number" == typeof o && (i.minimum = o),
        p
          ? f
            ? ((i.maximum = c), (i.exclusiveMaximum = !0))
            : (i.exclusiveMaximum = c)
          : "number" == typeof s && (i.maximum = s),
        a)
      ) {
        const n = new Set();
        for (const o of a)
          Number.isFinite(o) && 0 !== o
            ? n.add(Math.abs(o))
            : Wc(
                e,
                t,
                i,
                r,
                `A multipleOf divisor of ${o} cannot be represented in JSON Schema`
              );
        const [o, ...s] = n;
        void 0 !== o && (i.multipleOf = o),
          s.length &&
            (i.allOf = [
              ...(i.allOf ?? []),
              ...s.map((e) => ({ multipleOf: e })),
            ]);
      }
    },
    _d = (e, t, n, r) => {
      n.type = "boolean";
    },
    kd = (e, t, n, r) => {
      n.not = {};
    },
    Pd = (e, t, n, r) => {
      const i = ro(e._zod.def.entries);
      0 !== i.length
        ? (i.every((e) => "number" == typeof e) && (n.type = "number"),
          i.every((e) => "string" == typeof e) && (n.type = "string"),
          (n.enum = i))
        : (n.not = {});
    },
    Bd = (e, t, n, r) => {
      Wc(e, t, n, r, "Custom types cannot be represented in JSON Schema");
    },
    Ed = (e, t, n, r) => {
      Wc(e, t, n, r, "Transforms cannot be represented in JSON Schema");
    },
    xd = (e, t, n, r) => {
      const i = n,
        o = e._zod.def,
        { minimum: s, maximum: a } = yd(e);
      "number" == typeof s && (i.minItems = s),
        "number" == typeof a && (i.maxItems = a),
        (i.type = "array"),
        (i.items = Jc(o.element, t, { ...r, path: [...r.path, "items"] }));
    };
  function Td(e) {
    const t = e._zod.def;
    return "pipe" === t.type && t.in._zod.traits.has("$ZodTransform")
      ? Td(t.out)
      : "catch" === t.type
      ? Td(t.innerType)
      : e._zod.optin;
  }
  const Rd = (e, t, n, r) => {
      const i = n,
        o = e._zod.def,
        s = o.shape;
      if (
        Object.getOwnPropertySymbols(s).length &&
        Wc(e, t, i, r, "Symbol keys cannot be represented in JSON Schema")
      )
        return;
      (i.type = "object"), (i.properties = {});
      for (const e in s)
        uo(
          i.properties,
          e,
          Jc(s[e], t, { ...r, path: [...r.path, "properties", e] })
        );
      const a = [];
      for (const e of Object.keys(s)) {
        const n = o.shape[e];
        ("input" === t.io ? void 0 === Td(n) : void 0 === n._zod.optout) &&
          a.push(e);
      }
      a.length > 0 && (i.required = a),
        "never" === o.catchall?._zod.def.type
          ? (i.additionalProperties = !1)
          : o.catchall
          ? o.catchall &&
            (i.additionalProperties = Jc(o.catchall, t, {
              ...r,
              path: [...r.path, "additionalProperties"],
            }))
          : "output" === t.io && (i.additionalProperties = !1);
    },
    zd = (e, t, n, r) => {
      const i = e._zod.def,
        o = !1 === i.inclusive,
        s = i.options.map((e, n) =>
          Jc(e, t, { ...r, path: [...r.path, o ? "oneOf" : "anyOf", n] })
        );
      o ? (n.oneOf = s) : (n.anyOf = s);
    },
    Md = (e, t, n, r) => {
      const i = e._zod.def,
        o = Jc(i.left, t, { ...r, path: [...r.path, "allOf", 0] }),
        s = Jc(i.right, t, { ...r, path: [...r.path, "allOf", 1] }),
        a = (e) => "allOf" in e && 1 === Object.keys(e).length,
        c = [...(a(o) ? o.allOf : [o]), ...(a(s) ? s.allOf : [s])];
      (n.allOf = c), t.intersections.push(c);
    };
  function Od(e, t, n) {
    if (t.$ref) {
      if (n.has(t)) return t;
      n.add(t);
      const r = e.get(t)?.def;
      if (!r) return t;
      const i = Od(e, r, n);
      return i === r ? t : i;
    }
    for (const r of ["anyOf", "oneOf"]) {
      const i = t[r];
      if (!Array.isArray(i)) continue;
      const o = i.map((t) => Od(e, t, n));
      o.some((e, t) => e !== i[t]) && (t = { ...t, [r]: o });
    }
    const r = Array.isArray(t.type) ? t.type : [t.type],
      i =
        !r.includes("string") &&
        r.some((e) => "number" === e || "integer" === e),
      o = t.enum ?? (void 0 !== t.const ? [t.const] : void 0);
    if (!i && !o?.some((e) => "number" == typeof e)) return t;
    const {
      minimum: s,
      maximum: a,
      exclusiveMinimum: c,
      exclusiveMaximum: d,
      multipleOf: u,
      format: l,
      id: p,
      ...f
    } = t;
    return (
      f.enum
        ? (f.enum = f.enum.map((e) => ("number" == typeof e ? String(e) : e)))
        : "number" == typeof f.const && (f.const = String(f.const)),
      i
        ? ((f.type = "string"),
          o || (f.pattern = (r.includes("number") ? js : Ls).source),
          f)
        : f
    );
  }
  const Fd = new WeakMap();
  const Ud = (e, t, n, r) => {
      const i = n,
        o = e._zod.def;
      i.type = "object";
      const s = o.keyType,
        a = yd(s).patterns;
      if ("loose" === o.mode && a && a.size > 0) {
        const e = Jc(o.valueType, t, {
          ...r,
          path: [...r.path, "patternProperties", "*"],
        });
        i.patternProperties = {};
        for (const t of a) uo(i.patternProperties, wd(t).source, e);
      } else {
        if ("draft-07" === t.target || "draft-2020-12" === t.target) {
          i.propertyNames = Jc(o.keyType, t, {
            ...r,
            path: [...r.path, "propertyNames"],
          });
          let n = Fd.get(t);
          n ||
            ((n = []),
            Fd.set(t, n),
            t.deferred.push(() =>
              (function (e) {
                const t = new Map();
                for (const n of e.seen.values())
                  n.def && !t.has(n.schema) && t.set(n.schema, n);
                const n = new Map();
                for (const r of Fd.get(e) ?? []) {
                  const i = e.seen.get(r),
                    o = (i?.def ?? i?.schema)?.propertyNames;
                  if (!o || !0 === o || n.has(o)) continue;
                  const s = Od(t, o, new Set());
                  s !== o && n.set(o, s);
                }
                if (n.size)
                  for (const t of e.seen.values())
                    for (const e of [t.schema, t.def]) {
                      const t = e && n.get(e.propertyNames);
                      t && (e.propertyNames = t);
                    }
              })(t)
            )),
            n.push(e);
        }
        i.additionalProperties = Jc(o.valueType, t, {
          ...r,
          path: [...r.path, "additionalProperties"],
        });
      }
      const c = s._zod.values,
        d = "input" === t.io && void 0 !== Td(o.valueType);
      if (c && !o.partial && !d) {
        const e = [...c].filter(
          (e) => "string" == typeof e || "number" == typeof e
        );
        e.length > 0 && (i.required = e.map(String));
      }
    },
    Nd = (e, t, n, r) => {
      const i = e._zod.def,
        o = Jc(i.innerType, t, r),
        s = t.seen.get(e);
      "openapi-3.0" === t.target
        ? ((s.ref = i.innerType), (n.nullable = !0))
        : (n.anyOf = [o, { type: "null" }]);
    },
    Ld = (e, t, n, r) => {
      const i = e._zod.def;
      Jc(i.innerType, t, r);
      t.seen.get(e).ref = i.innerType;
    },
    jd = Symbol();
  function Dd(e, t, n, r, i) {
    let o = !1;
    const s = JSON.stringify(e, (e, t) =>
      "bigint" != typeof t ? t : ((o = !0), null)
    );
    return o
      ? (Wc(t, n, r, i, "BigInt defaults cannot be represented in JSON Schema"),
        jd)
      : JSON.parse(s);
  }
  const Vd = (e, t, n, r) => {
      const i = e._zod.def;
      Jc(i.innerType, t, r);
      t.seen.get(e).ref = i.innerType;
      const o = Dd(i.defaultValue, e, t, n, r);
      o !== jd && (n.default = o);
    },
    Gd = (e, t, n, r) => {
      const i = e._zod.def;
      Jc(i.innerType, t, r);
      if (((t.seen.get(e).ref = i.innerType), "input" !== t.io)) return;
      const o = Dd(i.defaultValue, e, t, n, r);
      o !== jd && (n._prefault = o);
    },
    $d = (e, t, n, r) => {
      const i = e._zod.def;
      Jc(i.innerType, t, r);
      let o;
      t.seen.get(e).ref = i.innerType;
      try {
        o = i.catchValue(void 0);
      } catch {
        return void Wc(
          e,
          t,
          n,
          r,
          "Dynamic catch values are not supported in JSON Schema"
        );
      }
      n.default = o;
    },
    qd = (e, t, n, r) => {
      const i = e._zod.def,
        o = i.in._zod.traits.has("$ZodTransform"),
        s = "input" === t.io ? (o ? i.out : i.in) : i.out;
      Jc(s, t, r);
      t.seen.get(e).ref = s;
    },
    Zd = (e, t, n, r) => {
      const i = e._zod.def;
      Jc(i.innerType, t, r);
      (t.seen.get(e).ref = i.innerType), (n.readOnly = !0);
    },
    Kd = (e, t, n, r) => {
      const i = e._zod.def;
      Jc(i.innerType, t, r);
      t.seen.get(e).ref = i.innerType;
    };
  n.dn(Wd);
  const Hd = () => {
    const e = {
      string: { unit: "characters", verb: "to have" },
      file: { unit: "bytes", verb: "to have" },
      array: { unit: "items", verb: "to have" },
      set: { unit: "items", verb: "to have" },
      map: { unit: "entries", verb: "to have" },
    };
    function t(t) {
      return e[t] ?? null;
    }
    const n = {
        regex: "input",
        email: "email address",
        url: "URL",
        emoji: "emoji",
        uuid: "UUID",
        uuidv4: "UUIDv4",
        uuidv6: "UUIDv6",
        nanoid: "nanoid",
        guid: "GUID",
        cuid: "cuid",
        cuid2: "cuid2",
        ulid: "ULID",
        xid: "XID",
        ksuid: "KSUID",
        datetime: "ISO datetime",
        date: "ISO date",
        time: "ISO time",
        duration: "ISO duration",
        ipv4: "IPv4 address",
        ipv6: "IPv6 address",
        mac: "MAC address",
        cidrv4: "IPv4 range",
        cidrv6: "IPv6 range",
        base64: "base64-encoded string",
        base64url: "base64url-encoded string",
        json_string: "JSON string",
        e164: "E.164 number",
        currency_code: "currency code",
        credit_card: "credit card number",
        iban: "IBAN",
        jwt: "JWT",
        template_literal: "input",
      },
      r = { nan: "NaN" };
    function i(e, t) {
      return "number" !== e || "number" != typeof t || Number.isFinite(t)
        ? r[e] ?? e
        : String(t);
    }
    return (e) => {
      switch (e.code) {
        case "invalid_type":
          return `Invalid input: expected ${i(e.expected)}, received ${i(
            (function (e) {
              const t = typeof e;
              switch (t) {
                case "number":
                  return Number.isNaN(e) ? "nan" : "number";
                case "object": {
                  if (null === e) return "null";
                  if (Array.isArray(e)) return "array";
                  const t = e;
                  if (
                    t &&
                    Object.getPrototypeOf(t) !== Object.prototype &&
                    "constructor" in t &&
                    t.constructor
                  )
                    return t.constructor.name;
                }
              }
              return t;
            })(e.input),
            e.input
          )}`;
        case "invalid_value":
          return 1 === e.values.length
            ? `Invalid input: expected ${Po(e.values[0])}`
            : `Invalid option: expected one of ${io(e.values, "|")}`;
        case "too_big": {
          const n = e.exact ? "exactly " : e.inclusive ? "<=" : "<",
            r = t(e.origin);
          return r
            ? `Too big: expected ${
                e.origin ?? "value"
              } to have ${n}${e.maximum.toString()} ${r.unit ?? "elements"}`
            : `Too big: expected ${
                e.origin ?? "value"
              } to be ${n}${e.maximum.toString()}`;
        }
        case "too_small": {
          const n = e.exact ? "exactly " : e.inclusive ? ">=" : ">",
            r = t(e.origin);
          return r
            ? `Too small: expected ${
                e.origin
              } to have ${n}${e.minimum.toString()} ${r.unit}`
            : `Too small: expected ${
                e.origin
              } to be ${n}${e.minimum.toString()}`;
        }
        case "invalid_format": {
          const t = e;
          return "starts_with" === t.format
            ? `Invalid string: must start with "${t.prefix}"`
            : "ends_with" === t.format
            ? `Invalid string: must end with "${t.suffix}"`
            : "includes" === t.format
            ? `Invalid string: must include "${t.includes}"`
            : "regex" === t.format
            ? `Invalid string: must match pattern ${t.pattern}`
            : `Invalid ${n[t.format] ?? e.format}`;
        }
        case "not_multiple_of":
          return `Invalid number: must be a multiple of ${e.divisor}`;
        case "unrecognized_keys":
          return `Unrecognized key${e.keys.length > 1 ? "s" : ""}: ${io(
            e.keys,
            ", "
          )}`;
        case "invalid_key":
          return `Invalid key in ${e.origin}`;
        case "invalid_union":
          if (e.options && Array.isArray(e.options) && e.options.length > 0) {
            return `Invalid discriminator value. Expected ${e.options
              .map((e) => `'${e}'`)
              .join(" | ")}`;
          }
          return !1 === e.inclusive
            ? "Invalid input: more than one option matched"
            : "Invalid input";
        case "invalid_element":
          return `Invalid value in ${e.origin}`;
        default:
          return "Invalid input";
      }
    };
  };
  function Wd() {
    return { localeError: Hd() };
  }
  const Jd = {
      get: function () {
        const e = this._zod;
        return (
          e.message ?? (e.message = JSON.stringify(e.def, oo, 2)), e.message
        );
      },
      set: function (e) {
        this._zod.message = e;
      },
      enumerable: !0,
      configurable: !0,
    },
    Yd = { value: void 0, enumerable: !1 },
    Qd = new WeakSet([Object.prototype, Error.prototype]),
    Xd = (e, t) => {
      (e.name = "$ZodError"),
        (Yd.value = t),
        Object.defineProperty(e, "issues", Yd),
        (Yd.value = void 0),
        Object.defineProperty(e, "message", Jd);
      const n = Object.getPrototypeOf(e);
      Qd.has(n) ||
        (Qd.add(n),
        Object.defineProperty(n, "toString", {
          configurable: !0,
          enumerable: !1,
          get() {
            const e = () => this.message;
            return (
              Object.defineProperty(this, "toString", {
                value: e,
                configurable: !0,
                writable: !0,
              }),
              e
            );
          },
          set(e) {
            Object.defineProperty(this, "toString", {
              value: e,
              configurable: !0,
              writable: !0,
            });
          },
        }));
    },
    eu = rs("$ZodError", Xd);
  rs("$ZodError", Xd, void 0, { Parent: Error });
  function tu(e, t, n) {
    return (
      Object.prototype.hasOwnProperty.call(e, t) ||
        ("__proto__" === t
          ? Object.defineProperty(e, t, {
              value: n(),
              writable: !0,
              enumerable: !0,
              configurable: !0,
            })
          : (e[t] = n())),
      e[t]
    );
  }
  function nu(e, t) {
    return { callee: t?.callee ?? e, Err: t?.Err };
  }
  const ru = (e) => {
      const t = (n, r, i, o) => {
        const s = i ? { ...i, async: !1 } : { async: !1 },
          a = n._zod.run({ value: r, issues: [] }, s);
        if (a instanceof Promise) throw new is();
        if (a.issues.length) {
          const n = new (o?.Err ?? e)(a.issues.map((e) => Lo(e, s, as())));
          throw (vo(n, o?.callee ?? t), n);
        }
        return a.value;
      };
      return t;
    },
    iu = (e) => {
      const t = async (n, r, i, o) => {
        const s = i ? { ...i, async: !0 } : { async: !0 };
        let a = n._zod.run({ value: r, issues: [] }, s);
        if ((a instanceof Promise && (a = await a), a.issues.length)) {
          const n = new (o?.Err ?? e)(a.issues.map((e) => Lo(e, s, as())));
          throw (vo(n, o?.callee ?? t), n);
        }
        return a.value;
      };
      return t;
    },
    ou = (e) => (t, n, r) => {
      const i = r ? { ...r, async: !1 } : { async: !1 },
        o = t._zod.run({ value: n, issues: [] }, i);
      if (o instanceof Promise) throw new is();
      return o.issues.length
        ? su(e, o.issues, i)
        : { success: !0, data: o.value };
    };
  function su(e, t, n) {
    let r;
    return {
      success: !1,
      get error() {
        return (
          r ||
            ((r = new e(t.map((e) => Lo(e, n, as())))),
            (t = void 0),
            (n = void 0)),
          r
        );
      },
      set error(e) {
        (r = e), (t = void 0), (n = void 0);
      },
    };
  }
  const au = (e) => async (t, n, r) => {
      const i = r ? { ...r, async: !0 } : { async: !0 };
      let o = t._zod.run({ value: n, issues: [] }, i);
      return (
        o instanceof Promise && (o = await o),
        o.issues.length ? su(e, o.issues, i) : { success: !0, data: o.value }
      );
    },
    cu = Symbol.for("zod.compile.invalid"),
    du = Symbol.for("zod.compile.fallback"),
    uu = (e, t, n) => {
      const r = e._zod.bag.validator;
      if (void 0 !== r) {
        if (r(t) !== cu) return !0;
        if (!0 === r.definite && void 0 === n) return !1;
      }
      return (function (e, t, n) {
        const r = n
            ? { ...n, async: !1, abortEarly: !0 }
            : { async: !1, abortEarly: !0 },
          i = e._zod.bag.fallbackRun;
        let o;
        i
          ? ((r[du] = !0), (o = i({ value: t, issues: [] }, r)))
          : (o = e._zod.run({ value: t, issues: [] }, r));
        if (o instanceof Promise) throw new is();
        return 0 === o.issues.length;
      })(e, t, n);
    };
  const lu = (e) => {
      const t = ru(e),
        n = (e, r, i, o) => {
          const s = i
            ? { ...i, direction: "backward" }
            : { direction: "backward" };
          return t(e, r, s, nu(n, o));
        };
      return n;
    },
    pu = (e) => {
      const t = ru(e),
        n = (e, r, i, o) => t(e, r, i, nu(n, o));
      return n;
    },
    fu = (e) => {
      const t = iu(e),
        n = async (e, r, i, o) => {
          const s = i
            ? { ...i, direction: "backward" }
            : { direction: "backward" };
          return await t(e, r, s, nu(n, o));
        };
      return n;
    },
    hu = (e) => {
      const t = iu(e),
        n = async (e, r, i, o) => await t(e, r, i, nu(n, o));
      return n;
    },
    mu = (e) => (t, n, r) => {
      const i = r ? { ...r, direction: "backward" } : { direction: "backward" };
      return ou(e)(t, n, i);
    },
    gu = (e) => (t, n, r) => ou(e)(t, n, r),
    bu = (e) => async (t, n, r) => {
      const i = r ? { ...r, direction: "backward" } : { direction: "backward" };
      return au(e)(t, n, i);
    },
    vu = (e) => async (t, n, r) => au(e)(t, n, r);
  const yu = new WeakSet([Object.prototype, Error.prototype]);
  function Au(e, t, n) {
    Object.defineProperty(e, t, {
      configurable: !0,
      enumerable: !1,
      get() {
        const e = n(this);
        return (
          Object.defineProperty(this, t, {
            value: e,
            configurable: !0,
            writable: !0,
          }),
          e
        );
      },
      set(e) {
        Object.defineProperty(this, t, {
          value: e,
          configurable: !0,
          writable: !0,
        });
      },
    });
  }
  const Cu = (e, t) => {
      eu.init(e, t), (e.name = "ZodError");
      const n = Object.getPrototypeOf(e);
      yu.has(n) ||
        (yu.add(n),
        Au(
          n,
          "format",
          (e) => (t) =>
            (function (e, t = (e) => e.message) {
              const n = { _errors: [] },
                r = (e, i = []) => {
                  for (const o of e.issues)
                    if ("invalid_union" === o.code && o.errors.length)
                      o.errors.map((e) => r({ issues: e }, [...i, ...o.path]));
                    else if ("invalid_key" === o.code)
                      r({ issues: o.issues }, [...i, ...o.path]);
                    else if ("invalid_element" === o.code)
                      r({ issues: o.issues }, [...i, ...o.path]);
                    else {
                      const e = [...i, ...o.path];
                      if (0 === e.length) n._errors.push(t(o));
                      else {
                        let r = n,
                          i = 0;
                        for (; i < e.length; ) {
                          const n = e[i],
                            s = i === e.length - 1;
                          if ("_errors" === n) {
                            s && r._errors.push(t(o)), i++;
                            continue;
                          }
                          Object.prototype.hasOwnProperty.call(r, n) ||
                            Object.defineProperty(r, n, {
                              value: { _errors: [] },
                              enumerable: !0,
                              writable: !0,
                              configurable: !0,
                            });
                          const a = r[n];
                          s && a._errors.push(t(o)), (r = a), i++;
                        }
                      }
                    }
                };
              return r(e), n;
            })(e, t)
        ),
        Au(
          n,
          "flatten",
          (e) => (t) =>
            (function (e, t = (e) => e.message) {
              const n = {},
                r = [];
              for (const i of e.issues)
                i.path.length > 0
                  ? tu(n, i.path[0], () => []).push(t(i))
                  : r.push(t(i));
              return { formErrors: r, fieldErrors: n };
            })(e, t)
        ),
        Au(n, "addIssue", (e) => (t) => {
          e.issues.push(t), (e.message = JSON.stringify(e.issues, oo, 2));
        }),
        Au(n, "addIssues", (e) => (t) => {
          e.issues.push(...t), (e.message = JSON.stringify(e.issues, oo, 2));
        }),
        Object.defineProperty(n, "isEmpty", {
          configurable: !0,
          enumerable: !1,
          get() {
            return 0 === this.issues.length;
          },
        }));
    },
    wu = rs("ZodError", Cu, void 0, { Parent: Error }),
    Su = ru(wu),
    Iu = iu(wu),
    _u = ou(wu),
    ku = au(wu),
    Pu = lu(wu),
    Bu = pu(wu),
    Eu = fu(wu),
    xu = hu(wu),
    Tu = mu(wu),
    Ru = gu(wu),
    zu = bu(wu),
    Mu = vu(wu);
  function Ou() {
    ss.memoizer || as({ memoizer: bs });
  }
  const Fu = rs(
      "ZodType",
      (e, t) => (
        ss.localeError || as(Wd()),
        ua.init(e, t),
        (e.def = t),
        (e.type = t.type),
        e
      ),
      {
        check(...e) {
          const t = this.def;
          return this.clone(
            go(t, {
              checks: [
                ...(t.checks ?? []),
                ...e.map((e) =>
                  "function" == typeof e
                    ? {
                        _zod: {
                          check: e,
                          def: { check: "custom" },
                          onattach: [],
                        },
                      }
                    : e
                ),
              ],
            }),
            { parent: !0 }
          );
        },
        with(...e) {
          return this.check(...e);
        },
        clone(e, t) {
          return _o(this, e, t);
        },
        brand() {
          return this;
        },
        register(e, t) {
          return e.add(this, t), this;
        },
        refine(e, t) {
          return this.check(
            (function (e, t = {}) {
              return (function (e, t, n) {
                return new e({
                  type: "custom",
                  check: "custom",
                  fn: t,
                  ...ko(n),
                });
              })(Zl, e, t);
            })(e, t)
          );
        },
        superRefine(e, t) {
          return this.check(
            (function (e, t) {
              return Zc(e, t);
            })(e, t)
          );
        },
        overwrite(e) {
          return this.check(qc(e));
        },
        optional() {
          return Ol(this);
        },
        exactOptional() {
          return new Fl({ type: "optional", innerType: this });
        },
        nullable() {
          return Nl(this);
        },
        nullish() {
          return Ol(Nl(this));
        },
        nonoptional(e) {
          return (function (e, t) {
            return new Dl({ type: "nonoptional", innerType: e, ...ko(t) });
          })(this, e);
        },
        array() {
          return Cl(this);
        },
        or(e) {
          return kl([this, e]);
        },
        and(e) {
          return new Pl({ type: "intersection", left: this, right: e });
        },
        transform(e) {
          return $l(this, zl(e));
        },
        default(e) {
          return (
            (t = e),
            new Ll({
              type: "default",
              innerType: this,
              get defaultValue() {
                return "function" == typeof t ? t() : wo(t);
              },
            })
          );
          var t;
        },
        prefault(e) {
          return (
            (t = e),
            new jl({
              type: "prefault",
              innerType: this,
              get defaultValue() {
                return "function" == typeof t ? t() : wo(t);
              },
            })
          );
          var t;
        },
        catch(e) {
          return new Vl({
            type: "catch",
            innerType: this,
            catchValue: "function" == typeof (t = e) ? t : Xo(t),
          });
          var t;
        },
        pipe(e) {
          return $l(this, e);
        },
        readonly() {
          return new ql({ type: "readonly", innerType: this });
        },
        describe(e) {
          const t = this.clone();
          return Oc.add(t, { description: e }), t;
        },
        meta(...e) {
          if (0 === e.length) return Oc.get(this);
          const t = this.clone();
          return Oc.add(t, e[0]), t;
        },
        isOptional() {
          return this.safeParse(void 0).success;
        },
        isNullable() {
          return this.safeParse(null).success;
        },
        apply(e, ...t) {
          return 0 === t.length ? e(this) : e(this, ...t);
        },
        get "~standard"() {
          return qo(this, "~standard", {
            ...pa(this),
            jsonSchema: {
              input: ad(this, "input"),
              output: ad(this, "output"),
            },
          });
        },
        set "~standard"(e) {
          $o(this, "~standard", e);
        },
        parse: function e(t, n) {
          return Su(this, t, n, { callee: e });
        },
        parseAsync: async function e(t, n) {
          return await Iu(this, t, n, { callee: e });
        },
        safeParse(e, t) {
          return _u(this, e, t);
        },
        async safeParseAsync(e, t) {
          return ku(this, e, t);
        },
        get spa() {
          return this?.safeParseAsync;
        },
        set spa(e) {
          $o(this, "spa", e);
        },
        validate(e, t) {
          return uu(this, e, t);
        },
        validateAsync(e, t) {
          return (async (e, t, n) => {
            const r = n
              ? { ...n, async: !0, abortEarly: !0 }
              : { async: !0, abortEarly: !0 };
            let i = e._zod.run({ value: t, issues: [] }, r);
            return i instanceof Promise && (i = await i), 0 === i.issues.length;
          })(this, e, t);
        },
        encode: function e(t, n) {
          return Pu(this, t, n, { callee: e });
        },
        decode: function e(t, n) {
          return Bu(this, t, n, { callee: e });
        },
        encodeAsync: async function e(t, n) {
          return await Eu(this, t, n, { callee: e });
        },
        decodeAsync: async function e(t, n) {
          return await xu(this, t, n, { callee: e });
        },
        safeEncode(e, t) {
          return Tu(this, e, t);
        },
        safeDecode(e, t) {
          return Ru(this, e, t);
        },
        async safeEncodeAsync(e, t) {
          return zu(this, e, t);
        },
        async safeDecodeAsync(e, t) {
          return Mu(this, e, t);
        },
        toJSONSchema(e) {
          return (
            (e, t = {}) =>
            (n) => {
              const r = Hc({ ...n, processors: t });
              return Jc(e, r), Qc(r, e), od(r, e);
            }
          )(
            this,
            {}
          )(e);
        },
        get description() {
          return Oc.get(this)?.description;
        },
        get _def() {
          return this._zod.def;
        },
      }
    ),
    Uu = rs(
      "_ZodString",
      (e, t) => {
        fa.init(e, t),
          Fu.init(e, t),
          (e._zod.processJSONSchema = (t, n, r) => Sd(e, t, n));
      },
      Zo(
        {
          format: (e) => yd(e).format ?? null,
          minLength: (e) => yd(e).minimum ?? null,
          maxLength: (e) => yd(e).maximum ?? null,
        },
        {
          regex(...e) {
            return this.check(
              (function (e, t) {
                return new ta({
                  check: "string_format",
                  format: "regex",
                  ...ko(t),
                  pattern: e,
                });
              })(...e)
            );
          },
          includes(...e) {
            return this.check(
              (function (e, t) {
                return new ia({
                  check: "string_format",
                  format: "includes",
                  ...ko(t),
                  includes: e,
                });
              })(...e)
            );
          },
          startsWith(...e) {
            return this.check(
              (function (e, t) {
                return new oa({
                  check: "string_format",
                  format: "starts_with",
                  ...ko(t),
                  prefix: e,
                });
              })(...e)
            );
          },
          endsWith(...e) {
            return this.check(
              (function (e, t) {
                return new sa({
                  check: "string_format",
                  format: "ends_with",
                  ...ko(t),
                  suffix: e,
                });
              })(...e)
            );
          },
          min(...e) {
            return this.check(Gc(...e));
          },
          max(...e) {
            return this.check(Vc(...e));
          },
          length(...e) {
            return this.check($c(...e));
          },
          nonempty(...e) {
            return this.check(Gc(1, ...e));
          },
          lowercase(e) {
            return this.check(
              (function (e) {
                return new na({
                  check: "string_format",
                  format: "lowercase",
                  ...ko(e),
                });
              })(e)
            );
          },
          uppercase(e) {
            return this.check(
              (function (e) {
                return new ra({
                  check: "string_format",
                  format: "uppercase",
                  ...ko(e),
                });
              })(e)
            );
          },
          trim() {
            return this.check(qc((e) => e.trim()));
          },
          normalize(...e) {
            return this.check(
              (function (e) {
                return qc((t) => t.normalize(e));
              })(...e)
            );
          },
          toLowerCase() {
            return this.check(qc((e) => e.toLowerCase()));
          },
          toUpperCase() {
            return this.check(qc((e) => e.toUpperCase()));
          },
          slugify() {
            return this.check(
              qc((e) =>
                (function (e) {
                  return e
                    .toLowerCase()
                    .trim()
                    .replace(/[^\w\s-]/g, "")
                    .replace(/[\s_-]+/g, "-")
                    .replace(/^-+|-+$/g, "");
                })(e)
              )
            );
          },
        }
      )
    ),
    Nu = rs(
      "ZodString",
      (e, t) => {
        fa.init(e, t), Uu.init(e, t);
      },
      {
        email(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "email",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(qu, e)
          );
        },
        url(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "url",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(Hu, e)
          );
        },
        jwt(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "jwt",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(dl, e)
          );
        },
        emoji(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "emoji",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(Wu, e)
          );
        },
        guid(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "guid",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(Zu, e)
          );
        },
        uuid(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "uuid",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(Ku, e)
          );
        },
        uuidv4(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "uuid",
                check: "string_format",
                abort: !1,
                version: "v4",
                ...ko(t),
              });
            })(Ku, e)
          );
        },
        uuidv6(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "uuid",
                check: "string_format",
                abort: !1,
                version: "v6",
                ...ko(t),
              });
            })(Ku, e)
          );
        },
        uuidv7(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "uuid",
                check: "string_format",
                abort: !1,
                version: "v7",
                ...ko(t),
              });
            })(Ku, e)
          );
        },
        nanoid(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "nanoid",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(Ju, e)
          );
        },
        cuid(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "cuid",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(Yu, e)
          );
        },
        cuid2(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "cuid2",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(Qu, e)
          );
        },
        ulid(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "ulid",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(Xu, e)
          );
        },
        base64(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "base64",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(sl, e)
          );
        },
        base64url(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "base64url",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(al, e)
          );
        },
        xid(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "xid",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(el, e)
          );
        },
        ksuid(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "ksuid",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(tl, e)
          );
        },
        ipv4(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "ipv4",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(nl, e)
          );
        },
        ipv6(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "ipv6",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(rl, e)
          );
        },
        cidrv4(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "cidrv4",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(il, e)
          );
        },
        cidrv6(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "cidrv6",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(ol, e)
          );
        },
        e164(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "e164",
                check: "string_format",
                abort: !1,
                ...ko(t),
              });
            })(cl, e)
          );
        },
        datetime(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "datetime",
                check: "string_format",
                offset: !1,
                local: !1,
                precision: null,
                ...ko(t),
              });
            })(Du, e)
          );
        },
        date(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "date",
                check: "string_format",
                ...ko(t),
              });
            })(Vu, e)
          );
        },
        time(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "time",
                check: "string_format",
                precision: null,
                ...ko(t),
              });
            })(Gu, e)
          );
        },
        duration(e) {
          return this.check(
            (function (e, t) {
              return new e({
                type: "string",
                format: "duration",
                check: "string_format",
                ...ko(t),
              });
            })($u, e)
          );
        },
      }
    );
  function Lu(e) {
    return (function (e, t) {
      return new e(Fc({ type: "string", ...ko(t) }));
    })(Nu, e);
  }
  const ju = rs("ZodStringFormat", (e, t) => {
      ha.init(e, t), Uu.init(e, t);
    }),
    Du = rs("ZodISODateTime", (e, t) => {
      xa.init(e, t), ju.init(e, t);
    }),
    Vu = rs("ZodISODate", (e, t) => {
      Ta.init(e, t), ju.init(e, t);
    }),
    Gu = rs("ZodISOTime", (e, t) => {
      Ra.init(e, t), ju.init(e, t);
    }),
    $u = rs("ZodISODuration", (e, t) => {
      za.init(e, t), ju.init(e, t);
    }),
    qu = rs("ZodEmail", (e, t) => {
      ba.init(e, t), ju.init(e, t);
    });
  const Zu = rs("ZodGUID", (e, t) => {
    ma.init(e, t), ju.init(e, t);
  });
  const Ku = rs("ZodUUID", (e, t) => {
    ga.init(e, t), ju.init(e, t);
  });
  const Hu = rs("ZodURL", (e, t) => {
    wa.init(e, t), ju.init(e, t);
  });
  const Wu = rs("ZodEmoji", (e, t) => {
    Sa.init(e, t), ju.init(e, t);
  });
  const Ju = rs("ZodNanoID", (e, t) => {
    Ia.init(e, t), ju.init(e, t);
  });
  const Yu = rs("ZodCUID", (e, t) => {
    _a.init(e, t), ju.init(e, t);
  });
  const Qu = rs("ZodCUID2", (e, t) => {
    ka.init(e, t), ju.init(e, t);
  });
  const Xu = rs("ZodULID", (e, t) => {
    Pa.init(e, t), ju.init(e, t);
  });
  const el = rs("ZodXID", (e, t) => {
    Ba.init(e, t), ju.init(e, t);
  });
  const tl = rs("ZodKSUID", (e, t) => {
    Ea.init(e, t), ju.init(e, t);
  });
  const nl = rs("ZodIPv4", (e, t) => {
    Ma.init(e, t), ju.init(e, t);
  });
  const rl = rs("ZodIPv6", (e, t) => {
    Ua.init(e, t), ju.init(e, t);
  });
  const il = rs("ZodCIDRv4", (e, t) => {
    Na.init(e, t), ju.init(e, t);
  });
  const ol = rs("ZodCIDRv6", (e, t) => {
    La.init(e, t), ju.init(e, t);
  });
  const sl = rs("ZodBase64", (e, t) => {
    Va.init(e, t), ju.init(e, t);
  });
  const al = rs("ZodBase64URL", (e, t) => {
    $a.init(e, t), ju.init(e, t);
  });
  const cl = rs("ZodE164", (e, t) => {
    qa.init(e, t), ju.init(e, t);
  });
  const dl = rs("ZodJWT", (e, t) => {
    Za.init(e, t), ju.init(e, t);
  });
  const ul = rs(
    "ZodNumber",
    (e, t) => {
      Ka.init(e, t),
        Fu.init(e, t),
        (e._zod.processJSONSchema = (t, n, r) => Id(e, t, n, r)),
        (e.isFinite = !0);
    },
    Zo(
      {
        minValue: (e) => {
          const { minimum: t, exclusiveMinimum: n } = yd(e);
          return Math.max(
            t ?? Number.NEGATIVE_INFINITY,
            n ?? Number.NEGATIVE_INFINITY
          );
        },
        maxValue: (e) => {
          const { maximum: t, exclusiveMaximum: n } = yd(e);
          return Math.min(
            t ?? Number.POSITIVE_INFINITY,
            n ?? Number.POSITIVE_INFINITY
          );
        },
        isInt: (e) => {
          const { isInt: t, multipleOf: n } = yd(e);
          return !!t || !!n?.some(Number.isSafeInteger);
        },
        format: (e) => yd(e).format ?? null,
      },
      {
        gt(e, t) {
          return this.check(Lc(e, t));
        },
        gte(e, t) {
          return this.check(jc(e, t));
        },
        min(e, t) {
          return this.check(jc(e, t));
        },
        lt(e, t) {
          return this.check(Uc(e, t));
        },
        lte(e, t) {
          return this.check(Nc(e, t));
        },
        max(e, t) {
          return this.check(Nc(e, t));
        },
        int(e) {
          return this.check(fl(e));
        },
        safe(e) {
          return this.check(fl(e));
        },
        positive(e) {
          return this.check(Lc(0, e));
        },
        nonnegative(e) {
          return this.check(jc(0, e));
        },
        negative(e) {
          return this.check(Uc(0, e));
        },
        nonpositive(e) {
          return this.check(Nc(0, e));
        },
        multipleOf(e, t) {
          return this.check(Dc(e, t));
        },
        step(e, t) {
          return this.check(Dc(e, t));
        },
        finite() {
          return this;
        },
      }
    )
  );
  function ll(e) {
    return (function (e, t) {
      return new e(Fc({ type: "number", checks: [], ...ko(t) }));
    })(ul, e);
  }
  const pl = rs("ZodNumberFormat", (e, t) => {
    Ha.init(e, t), ul.init(e, t);
  });
  function fl(e) {
    return (function (e, t) {
      return new e({
        type: "number",
        check: "number_format",
        abort: !1,
        format: "safeint",
        ...ko(t),
      });
    })(pl, e);
  }
  const hl = rs("ZodBoolean", (e, t) => {
    Wa.init(e, t),
      Fu.init(e, t),
      (e._zod.processJSONSchema = (e, t, n) => _d(0, 0, t));
  });
  function ml(e) {
    return (function (e, t) {
      return new e({ type: "boolean", ...ko(t) });
    })(hl, e);
  }
  const gl = rs("ZodUnknown", (e, t) => {
    Ja.init(e, t), Fu.init(e, t), (e._zod.processJSONSchema = (e, t, n) => {});
  });
  function bl() {
    return (function (e) {
      return new e({ type: "unknown" });
    })(gl);
  }
  const vl = rs("ZodNever", (e, t) => {
    Ya.init(e, t),
      Fu.init(e, t),
      (e._zod.processJSONSchema = (e, t, n) => kd(0, 0, t));
  });
  function yl(e) {
    return (function (e, t) {
      return new e({ type: "never", ...ko(t) });
    })(vl, e);
  }
  const Al = rs(
    "ZodArray",
    (e, t) => {
      Ou(),
        tc.init(e, t),
        Fu.init(e, t),
        (e._zod.processJSONSchema = (t, n, r) => xd(e, t, n, r)),
        (e.element = t.element);
    },
    {
      min(e, t) {
        return this.check(Gc(e, t));
      },
      nonempty(e) {
        return this.check(Gc(1, e));
      },
      max(e, t) {
        return this.check(Vc(e, t));
      },
      length(e, t) {
        return this.check($c(e, t));
      },
      unwrap() {
        return this.element;
      },
    }
  );
  function Cl(e, t) {
    return (function (e, t, n) {
      return new e({ type: "array", element: t, ...ko(n) });
    })(Al, e, t);
  }
  const wl = rs(
    "ZodObject",
    (e, t) => {
      Ou(),
        ac.init(e, t),
        Fu.init(e, t),
        (e._zod.processJSONSchema = (t, n, r) => Rd(e, t, n, r)),
        Qo(e, "shape", (e) => e._zod.def.shape, !1);
    },
    {
      keyof() {
        return Tl(Object.keys(this._zod.def.shape));
      },
      catchall(e) {
        return this.clone(go(this._zod.def, { catchall: e }));
      },
      passthrough() {
        return this.clone(go(this._zod.def, { catchall: bl() }));
      },
      loose() {
        return this.clone(go(this._zod.def, { catchall: bl() }));
      },
      strict() {
        return this.clone(go(this._zod.def, { catchall: yl() }));
      },
      strip() {
        return this.clone(go(this._zod.def, { catchall: void 0 }));
      },
      extend(e) {
        return (function (e, t) {
          if (!Co(t))
            throw new Error("Invalid input to extend: expected a plain object");
          const n = e._zod.def.checks;
          if (n && n.length > 0) {
            const n = po(e);
            for (const e of Reflect.ownKeys(t))
              if (void 0 !== Object.getOwnPropertyDescriptor(n, e))
                throw new Error(
                  "Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead."
                );
          }
          return _o(e, go(e._zod.def, { shape: To(e, t) }));
        })(this, e);
      },
      safeExtend(e) {
        return (function (e, t) {
          if (!Co(t))
            throw new Error(
              "Invalid input to safeExtend: expected a plain object"
            );
          return _o(e, go(e._zod.def, { shape: To(e, t) }));
        })(this, e);
      },
      merge(e) {
        return (function (e, t) {
          if (!t?._zod?.def)
            throw new Error(
              "Invalid input to merge: expected an object schema. To merge a plain shape, use `.extend()`."
            );
          if (e._zod.def.checks?.length)
            throw new Error(
              ".merge() cannot be used on object schemas containing refinements. Use .safeExtend() instead."
            );
          const n = {};
          return (
            mo(n, e, Reflect.ownKeys(po(e))),
            mo(n, t, Reflect.ownKeys(po(t))),
            _o(
              e,
              go(e._zod.def, {
                shape: n,
                get catchall() {
                  return t._zod.def.catchall;
                },
                checks: t._zod.def.checks ?? [],
              })
            )
          );
        })(this, e);
      },
      pick(e) {
        return (function (e, t) {
          const n = e._zod.def,
            r = n.checks;
          if (r && r.length > 0)
            throw new Error(
              ".pick() cannot be used on object schemas containing refinements"
            );
          const i = {};
          return mo(i, e, xo(e, t)), _o(e, go(n, { shape: i, checks: [] }));
        })(this, e);
      },
      omit(e) {
        return (function (e, t) {
          const n = e._zod.def,
            r = n.checks;
          if (r && r.length > 0)
            throw new Error(
              ".omit() cannot be used on object schemas containing refinements"
            );
          const i = new Set(xo(e, t)),
            o = {};
          return (
            mo(
              o,
              e,
              Reflect.ownKeys(po(e)).filter((e) => !i.has(e))
            ),
            _o(e, go(n, { shape: o, checks: [] }))
          );
        })(this, e);
      },
      partial(...e) {
        return Ro(Ml, this, e[0]);
      },
      exactPartial(...e) {
        return Ro(Fl, this, e[0], "exactPartial");
      },
      required(...e) {
        return (function (e, t, n) {
          const r = n ? new Set(xo(t, n)) : void 0,
            i = {};
          return (
            mo(i, t, Reflect.ownKeys(po(t)), (t, n) =>
              r && !r.has(n) ? t : new e({ type: "nonoptional", innerType: t })
            ),
            _o(t, go(t._zod.def, { shape: i }))
          );
        })(Dl, this, e[0]);
      },
    }
  );
  function Sl(e, t) {
    const n = { type: "object", shape: e ?? {}, ...ko(t) };
    return new wl(n);
  }
  function Il(e, t) {
    return new wl({ type: "object", shape: e, catchall: yl(), ...ko(t) });
  }
  const _l = rs("ZodUnion", (e, t) => {
    dc.init(e, t),
      Fu.init(e, t),
      (e._zod.processJSONSchema = (t, n, r) => zd(e, t, n, r)),
      (e.options = t.options);
  });
  function kl(e, t) {
    return new _l({ type: "union", options: e, ...ko(t) });
  }
  const Pl = rs("ZodIntersection", (e, t) => {
    uc.init(e, t),
      Fu.init(e, t),
      (e._zod.processJSONSchema = (t, n, r) => Md(e, t, n, r));
  });
  const Bl = rs("ZodRecord", (e, t) => {
    Ou(),
      fc.init(e, t),
      Fu.init(e, t),
      (e._zod.processJSONSchema = (t, n, r) => Ud(e, t, n, r)),
      (e.keyType = t.keyType),
      (e.valueType = t.valueType);
  });
  function El(e, t, n) {
    return t && t._zod
      ? new Bl({ type: "record", keyType: e, valueType: t, ...ko(n) })
      : new Bl({ type: "record", keyType: Lu(), valueType: e, ...ko(t) });
  }
  const xl = rs("ZodEnum", (e, t) => {
    hc.init(e, t),
      Fu.init(e, t),
      (e._zod.processJSONSchema = (t, n, r) => Pd(e, 0, n)),
      (e.enum = t.entries),
      (e.options = [...e._zod.values]);
    const n = new Set(Object.keys(t.entries));
    (e.extract = (e, r) => {
      const i = {};
      for (const r of e) {
        if (!n.has(r)) throw new Error(`Key ${r} not found in enum`);
        i[r] = t.entries[r];
      }
      return new xl({ ...t, checks: [], ...ko(r), entries: i });
    }),
      (e.exclude = (e, r) => {
        const i = { ...t.entries };
        for (const t of e) {
          if (!n.has(t)) throw new Error(`Key ${t} not found in enum`);
          delete i[t];
        }
        return new xl({ ...t, checks: [], ...ko(r), entries: i });
      });
  });
  function Tl(e, t) {
    const n = Array.isArray(e) ? Object.fromEntries(e.map((e) => [e, e])) : e;
    return new xl({ type: "enum", entries: n, ...ko(t) });
  }
  const Rl = rs("ZodTransform", (e, t) => {
    Ou(),
      mc.init(e, t),
      Fu.init(e, t),
      (e._zod.processJSONSchema = (t, n, r) => Ed(e, t, n, r)),
      (e._zod.parse = (n, r) => {
        if ("backward" === r.direction) throw new os(e.constructor.name);
        n.addIssue = (r) => {
          if ("string" == typeof r) n.issues.push(Go(r, n.value, t));
          else {
            const t = r;
            t.fatal && (t.continue = !1),
              t.code ?? (t.code = "custom"),
              "input" in t || (t.input = n.value),
              t.inst ?? (t.inst = e),
              n.issues.push(Go(t));
          }
        };
        const i = t.transform(n.value, n);
        return i instanceof Promise
          ? i.then((e) => ((n.value = e), n))
          : ((n.value = i), n);
      });
  });
  function zl(e) {
    return new Rl({ type: "transform", transform: e });
  }
  const Ml = rs("ZodOptional", (e, t) => {
    bc.init(e, t),
      Fu.init(e, t),
      (e._zod.processJSONSchema = (t, n, r) => Kd(e, t, 0, r)),
      (e.unwrap = () => e._zod.def.innerType);
  });
  function Ol(e) {
    return new Ml({ type: "optional", innerType: e });
  }
  const Fl = rs("ZodExactOptional", (e, t) => {
    vc.init(e, t),
      Fu.init(e, t),
      (e._zod.processJSONSchema = (t, n, r) => Kd(e, t, 0, r)),
      (e.unwrap = () => e._zod.def.innerType);
  });
  const Ul = rs("ZodNullable", (e, t) => {
    yc.init(e, t),
      Fu.init(e, t),
      (e._zod.processJSONSchema = (t, n, r) => Nd(e, t, n, r)),
      (e.unwrap = () => e._zod.def.innerType);
  });
  function Nl(e) {
    return new Ul({ type: "nullable", innerType: e });
  }
  const Ll = rs("ZodDefault", (e, t) => {
    Ac.init(e, t),
      Fu.init(e, t),
      (e._zod.processJSONSchema = (t, n, r) => Vd(e, t, n, r)),
      (e.unwrap = () => e._zod.def.innerType),
      (e.removeDefault = e.unwrap);
  });
  const jl = rs("ZodPrefault", (e, t) => {
    wc.init(e, t),
      Fu.init(e, t),
      (e._zod.processJSONSchema = (t, n, r) => Gd(e, t, n, r)),
      (e.unwrap = () => e._zod.def.innerType);
  });
  const Dl = rs("ZodNonOptional", (e, t) => {
    Sc.init(e, t),
      Fu.init(e, t),
      (e._zod.processJSONSchema = (t, n, r) => Ld(e, t, 0, r)),
      (e.unwrap = () => e._zod.def.innerType);
  });
  const Vl = rs("ZodCatch", (e, t) => {
    kc.init(e, t),
      Fu.init(e, t),
      (e._zod.processJSONSchema = (t, n, r) => $d(e, t, n, r)),
      (e.unwrap = () => e._zod.def.innerType),
      (e.removeCatch = e.unwrap);
  });
  const Gl = rs("ZodPipe", (e, t) => {
    Pc.init(e, t),
      Fu.init(e, t),
      (e._zod.processJSONSchema = (t, n, r) => qd(e, t, 0, r)),
      (e.in = t.in),
      (e.out = t.out);
  });
  function $l(e, t) {
    return new Gl({ type: "pipe", in: e, out: t });
  }
  const ql = rs("ZodReadonly", (e, t) => {
    Ec.init(e, t),
      Fu.init(e, t),
      (e._zod.processJSONSchema = (t, n, r) => Zd(e, t, n, r)),
      (e.unwrap = () => e._zod.def.innerType);
  });
  const Zl = rs("ZodCustom", (e, t) => {
    Tc.init(e, t),
      Fu.init(e, t),
      (e._zod.processJSONSchema = (t, n, r) => Bd(e, t, n, r));
  });
  const Kl = Tl(
      Mi.map((e) => e.isoCode),
      {
        error: (e) =>
          `${JSON.stringify(
            e.input
          )} is not a valid ISO 3166-1 alpha-2 country code (f.e. "US", "BE", "IT")`,
      }
    ),
    Hl = El(Lu(), Il({ countries: Cl(Kl).min(1), comment: Lu().optional() })),
    Wl = Il({
      region: Lu(),
      excluded_countries: Cl(Kl).min(1),
      comment: Lu().optional(),
    }),
    Jl = Il({
      country: Cl(Kl).min(1).optional(),
      region: Cl(Lu()).min(1).optional(),
      partialRegion: Cl(Wl).min(1).optional(),
      locale: Cl(
        Tl([
          "en_US",
          "es_ES",
          "id_ID",
          "it_IT",
          "nl_NL",
          "fr_FR",
          "pt_BR",
          "ru_RU",
          "pl_PL",
          "ro_RO",
          "de_DE",
          "nb_NO",
          "sv_SE",
          "fi_FI",
          "uk_UA",
          "el_GR",
          "da_DK",
          "cs_CZ",
          "hu_HU",
          "tr_TR",
          "ar_SA",
          "vi_VN",
          "th_TH",
          "ko_KR",
          "ja_JP",
        ])
      )
        .min(1)
        .optional(),
      browser: Cl(Lu()).min(1).optional(),
      device: Cl(Tl(["desktop", "mobile", "tablet"]))
        .min(1)
        .optional(),
      comment: Lu().optional(),
    }),
    Yl = [
      ...["preroll", "midroll", "rewarded"],
      "portalBanner",
      "ingameBanner",
    ],
    Ql = Jl.extend({ isLoggedIn: ml().optional(), isNewUser: ml().optional() }),
    Xl = Il({
      value: ll().gt(0),
      probability: ll().min(0).max(1),
      baseline: ml().optional(),
      comment: Lu().optional(),
    }),
    ep = Il({
      name: Lu(),
      factor: Cl(Xl).min(1),
      conditions: Ql.optional(),
      gamKey: Lu().optional(),
      comment: Lu().optional(),
    }),
    tp = Il({ name: Lu(), factors: Cl(Lu()).min(1), comment: Lu().optional() }),
    np = Il({
      floors: Cl(Xl).min(1),
      overrideCorrectionsFactors: Cl(Lu()).optional(),
      conditions: Ql,
      gamKey: Lu().optional(),
      comment: Lu().optional(),
    }),
    rp = Il({
      overrideCorrectionsFactors: Cl(Lu()).optional(),
      defaultFloor: ll().min(0),
      rules: Cl(np).min(1),
      comment: Lu().optional(),
    }),
    ip = Object.fromEntries(Yl.map((e) => [e, rp])),
    op = Sl({
      defaultCorrectionFactors: Cl(Lu()),
      comment: Lu().optional(),
      ...ip,
    });
  Sl({
    correctionFactors: Cl(ep).min(1).optional(),
    correctionFactorGroups: Cl(tp).min(1).optional(),
    regions: Hl.optional(),
    floors: op,
    comment: Lu().optional(),
  });
  function sp(e, t, n) {
    const r = [];
    return (
      e.forEach((e) => {
        const i = [];
        Rn(t[e]) ? i.push(...t[e]) : i.push(e),
          i.forEach((e) => {
            Rn(n[e]) && r.push(n[e]);
          });
      }),
      r
    );
  }
  class ap {
    sessionFloorConfig = null;
    constructor() {}
    getFloor() {
      const e = this.sessionFloorConfig?.selectedFloor;
      if (!Rn(e)) return null;
      return (
        e *
        (this.sessionFloorConfig?.applicableCorrectionFactors.reduce(
          (e, t) => e * t.factor,
          1
        ) ?? 1)
      );
    }
    setFloorConfig(e) {
      this.sessionFloorConfig = { ...e };
    }
    getKeyValue() {
      const e = {};
      return (
        Rn(this.sessionFloorConfig?.floorGamKey) &&
          (e[
            this.sessionFloorConfig.floorGamKey
          ] = `${this.sessionFloorConfig.selectedFloor}`),
        this.sessionFloorConfig?.applicableCorrectionFactors.forEach((t) => {
          Rn(t.gamKey) && (e[t.gamKey] = `${t.factor}`);
        }),
        e
      );
    }
  }
  const cp = new (class {
      config = null;
      sessionFloorConfig = {};
      constructor() {
        Br.getInstance().addEmailListenerAndInvoke(this.onEmailChanged);
      }
      setFloorConfigInput(e) {
        Rn(this.config)
          ? Zn.warn(
              "Setting new floor config, but there is already a config set. This should not happen and will be ignored."
            )
          : (this.config = (function (e) {
              const t = e.regions ?? {},
                n = {};
              e.correctionFactors?.forEach((e) => {
                n[e.name] = e;
              });
              const r = {};
              return (
                e.correctionFactorGroups?.forEach((e) => {
                  r[e.name] = e.factors;
                }),
                Yl.reduce((i, o) => {
                  const {
                      rules: s,
                      defaultFloor: a,
                      overrideCorrectionsFactors: c,
                    } = e.floors[o],
                    d = c ?? e.floors.defaultCorrectionFactors;
                  return (
                    (i[o] = {
                      defaultFloor: a,
                      defaultCorrectionFactors: sp(d, r, n),
                      rules: s.map((e) => {
                        const i = sp(e.overrideCorrectionsFactors ?? d, r, n);
                        return {
                          floors: e.floors,
                          correctionFactors: i,
                          conditions: {
                            isLoggedIn: e.conditions.isLoggedIn,
                            isNewUser: e.conditions.isNewUser,
                            browser: e.conditions.browser,
                            device: e.conditions.device,
                            locale: e.conditions.locale,
                            country: wr(e.conditions, t),
                          },
                          gamKey: e.gamKey,
                        };
                      }),
                    }),
                    i
                  );
                }, {})
              );
            })(e));
      }
      getFloorForSession(e) {
        return this.retrieveCachedFloor(e);
      }
      getApplicableRule(e, t) {
        for (const n of e.rules) if (up(n.conditions, t)) return n;
        return {
          floors: [{ value: e.defaultFloor, probability: 1 }],
          conditions: {},
          correctionFactors: e.defaultCorrectionFactors,
        };
      }
      getSessionKVs(e) {
        return this.getSessionConfig(e).getKeyValue();
      }
      getFloorConfig() {
        if (!Rn(this.config)) throw new Error("Floor config not loaded");
        return this.config;
      }
      retrieveCachedFloor(e) {
        const t = Br.getInstance().clientInfo,
          n = this.getSessionConfig(e),
          r = n.getFloor();
        if (Rn(r)) return r;
        const i = this.calculateFloorConfig(n, t, e);
        n.setFloorConfig(i);
        const o = n.getFloor();
        if (!Rn(o))
          throw new Error("Failed to retrieve floor after setting config");
        return o;
      }
      calculateFloorConfig(e, t, n) {
        const r = this.getFloorConfig(),
          i = this.getApplicableRule(r[n], t);
        let o,
          s = Math.random();
        for (const e of i.floors) {
          const { probability: t, value: n } = e;
          if (s < t) {
            o = n;
            break;
          }
          s -= t;
        }
        Rn(o) ||
          (Zn.error(
            "[FloorConfig] calculateFloorConfig - no floor selected, using default floor",
            r[n].defaultFloor
          ),
          (o = r[n].defaultFloor));
        const a = [];
        for (const e of i.correctionFactors)
          if (up(e.conditions, t)) {
            let t = 1;
            for (const n of e.factor) {
              const { probability: e, value: r } = n;
              if (s < e) {
                t = r;
                break;
              }
              s -= e;
            }
            a.push({ factor: t, gamKey: e.gamKey });
          }
        const c = { selectedFloor: o, applicableCorrectionFactors: a };
        return (
          Rn(i.gamKey) && (c.floorGamKey = i.gamKey),
          e.setFloorConfig(c),
          Zn.debug(`Floor for ${n}s is ${JSON.stringify(c)}`),
          c
        );
      }
      getSessionConfig(e) {
        return (
          Rn(this.sessionFloorConfig[e]) ||
            (this.sessionFloorConfig[e] = new ap()),
          this.sessionFloorConfig[e]
        );
      }
      onEmailChanged = (e, t) => {
        e !== t && this.resetSessionFloorConfig();
      };
      resetSessionFloorConfig() {
        for (const e of Object.getOwnPropertyNames(this.sessionFloorConfig))
          delete this.sessionFloorConfig[e];
      }
    })(),
    dp = cp;
  function up(e, t) {
    if (!Rn(e)) return !0;
    if (!Di(e, t)) return !1;
    const { isNewUser: n, isLoggedIn: r } = e;
    return (
      (!Rn(n) || n === t.isNewUser) &&
      (!Rn(r) || r === Rn(Br.getInstance().email))
    );
  }
  const lp = {
    floors: {
      comment: "Fallback floors config",
      midroll: {
        rules: [
          {
            floors: [{ value: 5.6, probability: 1 }],
            comment: "Midroll floor for US",
            conditions: { country: ["US"] },
          },
          {
            floors: [{ value: 3.66, probability: 1 }],
            comment: "Midroll floor for GB",
            conditions: { country: ["GB"] },
          },
          {
            floors: [{ value: 2.88, probability: 1 }],
            comment: "Midroll floor for AU",
            conditions: { country: ["AU"] },
          },
          {
            floors: [{ value: 2.4, probability: 1 }],
            comment: "Midroll floor for CA",
            conditions: { country: ["CA"] },
          },
          {
            floors: [{ value: 1.92, probability: 1 }],
            comment: "Midroll floor for NZ",
            conditions: { country: ["NZ"] },
          },
          {
            floors: [{ value: 3.78, probability: 1 }],
            comment: "Midroll floor for DE",
            conditions: { country: ["DE"] },
          },
          {
            floors: [{ value: 3.2, probability: 1 }],
            comment: "Midroll floor for CH, IE",
            conditions: { country: ["CH", "IE"] },
          },
          {
            floors: [{ value: 2.24, probability: 1 }],
            comment: "Midroll floor for ES",
            conditions: { country: ["ES"] },
          },
          {
            floors: [{ value: 1.4, probability: 1 }],
            comment: "Midroll floor for FR",
            conditions: { country: ["FR"] },
          },
          {
            floors: [{ value: 1.08, probability: 1 }],
            comment: "Midroll floor for IT",
            conditions: { country: ["IT"] },
          },
          {
            floors: [{ value: 1.9, probability: 1 }],
            comment: "Midroll floor for MX",
            conditions: { country: ["MX"] },
          },
          {
            floors: [{ value: 2, probability: 1 }],
            comment: "Midroll floor for JP",
            conditions: { country: ["JP"] },
          },
          {
            floors: [{ value: 1.5, probability: 1 }],
            comment: "Midroll floor for TW",
            conditions: { country: ["TW"] },
          },
          {
            floors: [{ value: 2, probability: 1 }],
            comment: "Midroll floor for SG",
            conditions: { country: ["SG"] },
          },
          {
            floors: [{ value: 1.1, probability: 1 }],
            comment: "Midroll floor for HK",
            conditions: { country: ["HK"] },
          },
          {
            floors: [{ value: 0.7, probability: 1 }],
            comment: "Midroll floor for BR",
            conditions: { country: ["BR"] },
          },
          {
            floors: [
              { value: 1, baseline: !0, probability: 0.9 },
              { value: 0.2, probability: 0.1 },
            ],
            gamKey: "fc_in_floor_v2_mid",
            comment: "Midroll floor for IN",
            conditions: { country: ["IN"] },
          },
          {
            floors: [{ value: 1.8, probability: 1 }],
            comment: "Midroll floor for all other countries in the EU",
            conditions: { region: ["EU"] },
          },
        ],
        defaultFloor: 1,
        overrideCorrectionsFactors: ["defaultVideo"],
      },
      preroll: {
        rules: [
          {
            floors: [{ value: 50, probability: 1 }],
            comment:
              "Preroll floor for new users. Absolute number, no correction factors applied.",
            conditions: { isNewUser: !0 },
            overrideCorrectionsFactors: ["noCorrection"],
          },
          {
            floors: [{ value: 8.4, probability: 1 }],
            comment: "Preroll floor for US",
            conditions: { country: ["US"] },
          },
          {
            floors: [{ value: 5.3, probability: 1 }],
            comment: "Preroll floor for CH, IE",
            conditions: { country: ["CH", "IE"] },
          },
          {
            floors: [{ value: 4, probability: 1 }],
            comment: "Preroll floor for GB, NL, KR",
            conditions: { country: ["GB", "NL", "KR"] },
          },
          {
            floors: [{ value: 3.84, probability: 1 }],
            comment: "Preroll floor for AU",
            conditions: { country: ["AU"] },
          },
          {
            floors: [{ value: 3.33, probability: 1 }],
            comment: "Preroll floor for MX",
            conditions: { country: ["MX"] },
          },
          {
            floors: [{ value: 3.2, probability: 1 }],
            comment: "Preroll floor for CA",
            conditions: { country: ["CA"] },
          },
          {
            floors: [{ value: 3.18, probability: 1 }],
            comment: "Preroll floor for DE",
            conditions: { country: ["DE"] },
          },
          {
            floors: [{ value: 3, probability: 1 }],
            comment: "Preroll floor for PL, PT, SK",
            conditions: { country: ["PL", "PT", "SK"] },
          },
          {
            floors: [{ value: 2.5, probability: 1 }],
            comment: "Preroll floor for JP, TW, SG",
            conditions: { country: ["JP", "TW", "SG"] },
          },
          {
            floors: [{ value: 2, probability: 1 }],
            comment: "Preroll floor for NZ, FR, ES",
            conditions: { country: ["NZ", "FR", "ES"] },
          },
          {
            floors: [{ value: 1.92, probability: 1 }],
            comment: "Preroll floor for IT",
            conditions: { country: ["IT"] },
          },
          {
            floors: [{ value: 1, probability: 1 }],
            comment: "Preroll floor for BR",
            conditions: { country: ["BR"] },
          },
          {
            floors: [{ value: 0.41, probability: 1 }],
            comment: "Preroll floor for VN, DZ",
            conditions: { country: ["VN", "DZ"] },
          },
          {
            floors: [
              { value: 0.15, probability: 0.1 },
              { value: 0.41, baseline: !0, probability: 0.9 },
            ],
            gamKey: "fc_in_floor_v2_pre",
            comment: "Preroll floor for IN",
            conditions: { country: ["IN"] },
          },
          {
            floors: [{ value: 3.2, probability: 1 }],
            comment: "Preroll floor for all other countries in the EU",
            conditions: { region: ["EU"] },
          },
        ],
        defaultFloor: 2,
        overrideCorrectionsFactors: ["defaultVideo"],
      },
      rewarded: {
        rules: [
          {
            floors: [{ value: 5.04, probability: 1 }],
            comment: "Rewarded floor for US",
            conditions: { country: ["US"] },
          },
          {
            floors: [{ value: 3.66, probability: 1 }],
            comment: "Rewarded floor for GB",
            conditions: { country: ["GB"] },
          },
          {
            floors: [{ value: 2.58, probability: 1 }],
            comment: "Rewarded floor for AU",
            conditions: { country: ["AU"] },
          },
          {
            floors: [{ value: 2.8, probability: 1 }],
            comment: "Rewarded floor for CA",
            conditions: { country: ["CA"] },
          },
          {
            floors: [{ value: 2.4, probability: 1 }],
            comment: "Rewarded floor for NZ",
            conditions: { country: ["NZ"] },
          },
          {
            floors: [{ value: 2.94, probability: 1 }],
            comment: "Rewarded floor for DE",
            conditions: { country: ["DE"] },
          },
          {
            floors: [{ value: 3.2, probability: 1 }],
            comment: "Rewarded floor for CH, IE",
            conditions: { country: ["CH", "IE"] },
          },
          {
            floors: [{ value: 1, probability: 1 }],
            comment: "Rewarded floor for ES",
            conditions: { country: ["ES"] },
          },
          {
            floors: [{ value: 1.4, probability: 1 }],
            comment: "Rewarded floor for FR",
            conditions: { country: ["FR"] },
          },
          {
            floors: [{ value: 1.44, probability: 1 }],
            comment: "Rewarded floor for IT",
            conditions: { country: ["IT"] },
          },
          {
            floors: [{ value: 1.9, probability: 1 }],
            comment: "Rewarded floor for MX",
            conditions: { country: ["MX"] },
          },
          {
            floors: [{ value: 2, probability: 1 }],
            comment: "Rewarded floor for JP",
            conditions: { country: ["JP"] },
          },
          {
            floors: [{ value: 1.5, probability: 1 }],
            comment: "Rewarded floor for TW",
            conditions: { country: ["TW"] },
          },
          {
            floors: [{ value: 2, probability: 1 }],
            comment: "Rewarded floor for SG",
            conditions: { country: ["SG"] },
          },
          {
            floors: [{ value: 1.1, probability: 1 }],
            comment: "Rewarded floor for HK",
            conditions: { country: ["HK"] },
          },
          {
            floors: [{ value: 0.7, probability: 1 }],
            comment: "Rewarded floor for BR",
            conditions: { country: ["BR"] },
          },
          {
            floors: [
              { value: 0.15, probability: 0.1 },
              { value: 1, baseline: !0, probability: 0.9 },
            ],
            gamKey: "fc_in_floor_v2_rew",
            comment: "Rewarded floor for IN",
            conditions: { country: ["IN"] },
          },
          {
            floors: [{ value: 1.8, probability: 1 }],
            comment: "Rewarded floor for all other countries in the EU",
            conditions: { region: ["EU"] },
          },
        ],
        defaultFloor: 1,
        overrideCorrectionsFactors: ["defaultVideo"],
      },
      ingameBanner: {
        rules: [
          {
            floors: [{ value: 0.5, probability: 1 }],
            comment: "Ingame banner floor for US",
            conditions: { country: ["US"] },
          },
          {
            floors: [
              { value: 0.01, probability: 0.5 },
              { value: 0.1, baseline: !0, probability: 0.5 },
            ],
            gamKey: "fc_in_floor_v2_inb",
            comment: "Ingame banner floor for IN",
            conditions: { country: ["IN"] },
          },
          {
            floors: [{ value: 0.2, probability: 1 }],
            comment: "Ingame banner floor for high-value countries",
            conditions: {
              country: ["GB", "AU", "CA", "NZ", "FR", "DE", "NL", "BE"],
            },
          },
        ],
        defaultFloor: 0.1,
        overrideCorrectionsFactors: ["defaultInGameBanner"],
      },
      portalBanner: {
        rules: [
          {
            floors: [{ value: 0.2, probability: 1 }],
            comment: "Portal banner floor for US and GB",
            conditions: { country: ["US", "GB"] },
          },
          {
            floors: [
              { value: 0.01, probability: 0.1 },
              { value: 0.1, baseline: !0, probability: 0.9 },
            ],
            gamKey: "fc_in_floor_v2_pb",
            comment: "Portal banner floor for IN",
            conditions: { country: ["IN"] },
          },
        ],
        defaultFloor: 0.1,
        overrideCorrectionsFactors: ["defaultPortalBanner"],
      },
      defaultCorrectionFactors: [],
    },
    regions: {
      EU: {
        countries: [
          "AT",
          "BE",
          "BG",
          "HR",
          "CY",
          "CZ",
          "DK",
          "EE",
          "FI",
          "FR",
          "DE",
          "GR",
          "HU",
          "IE",
          "IT",
          "LV",
          "LT",
          "LU",
          "MT",
          "NL",
          "PL",
          "PT",
          "RO",
          "SK",
          "SI",
          "ES",
          "SE",
        ],
      },
    },
    correctionFactors: [
      {
        name: "lowValueBrowsers",
        factor: [{ value: 0.6, probability: 1 }],
        conditions: { browser: ["safari", "opera", "firefox"] },
      },
      {
        name: "userLoggedInBanner",
        factor: [{ value: 1.3, probability: 1 }],
        conditions: { isLoggedIn: !0 },
      },
      {
        name: "userLoggedInVideo",
        factor: [{ value: 1.05, probability: 1 }],
        conditions: { isLoggedIn: !0 },
      },
      {
        name: "noCorrection",
        factor: [{ value: 1, probability: 1 }],
        comment:
          "Neutral ×1 factor. Used by rules that must apply no corrections.",
      },
    ],
    correctionFactorGroups: [
      {
        name: "defaultVideo",
        factors: ["lowValueBrowsers", "userLoggedInVideo"],
      },
      { name: "defaultPortalBanner", factors: ["userLoggedInBanner"] },
      {
        name: "defaultInGameBanner",
        factors: ["lowValueBrowsers", "userLoggedInBanner"],
      },
    ],
  };
  function pp() {
    return (function () {
      switch (Oi) {
        case "localhost":
          return Fi;
        case "dev":
          return Ni;
        case "prod":
          return Ui;
      }
    })().configApiUrl;
  }
  const fp = new (class {
      loadingPromise = null;
      async fetchConfig() {
        return (
          Rn(this.loadingPromise) ||
            (this.loadingPromise = this.createLoadingPromise()),
          this.loadingPromise
        );
      }
      async createLoadingPromise() {
        const e = { config: no, dollarRate: Yi(), floors: lp };
        let t = e;
        try {
          const e = pp(),
            n = await fetch(e);
          if (!n.ok)
            throw (
              (Zn.error("[ConfigLoader] fetchConfig - response not ok", n),
              new Error(`Network response was not ok: ${JSON.stringify(n)}`))
            );
          t = await n.json();
        } catch (n) {
          Zn.error(
            "[ConfigLoader] fetchConfig - error fetching config. Using fallback config",
            n
          ),
            Wi.getInstance().sendAdsConfigLoadFailedEvent({ reason: Xi(n) }),
            (t = e);
        } finally {
          this.setConfig(t);
        }
      }
      setConfig(e) {
        var t;
        (t = e.dollarRate),
          (Ji = t),
          $i.setBidderConfigInput(e.config),
          dp.setFloorConfigInput(e.floors);
      }
      reset() {
        Zn.warn(
          "[ConfigLoader] Reset: should only be used for testing purposes"
        ),
          (this.loadingPromise = null);
      }
    })(),
    hp = {
      pauseAfterHouseAds: { numberOfConsecutiveHouseAds: 4, pauseTimeMs: 6e5 },
      maxImpressionsBeforeRemakingSlots: 64,
      amazonBidCacheExpirationMs: 15e4,
    },
    mp = {
      general: {
        auctionTimeoutMs: 2e3,
        auctionFailsafeTimeoutMultiplier: 2,
        vastLoadTimeoutMs: 8e3,
        failsafeTimeoutMs: 9e3,
        adStartedTimeoutMs: 1e4,
        maxVastRedirects: 20,
        progressCheck: {
          startDelayMs: 1e3,
          intervalMs: 2e3,
          minProgressToCountAsFinished: 0.05,
        },
        skip: {
          minimumWatchTimeSeconds: 5,
          footerSkipButtonDelaySeconds: 3,
          bidderSkipAfterSeconds: 5,
        },
        maxDuration: {
          prebidAndAmazon: { skippableSeconds: 120, nonSkippableSeconds: 16 },
          google: { skippableSeconds: 120, nonSkippableSeconds: 16 },
        },
        sizes: {
          prebidAndAmazon: [640, 480],
          google: [
            [640, 480],
            [730, 400],
            [320, 480],
            [640, 360],
          ],
        },
        pauseAfterNoFill: {
          pauseTimeMs: 6e5,
          default: { numberOfConsecutiveNoFills: 3 },
          loweredFloorExperiment: {
            numberOfConsecutiveNoFills: 5,
            lowerFloorAfterConsecutiveNoFills: 3,
            floorMultiplier: 0.75,
          },
        },
        bidderPlaybackErrorsBeforeBlacklist: 1,
        amazonBidCacheExpirationMs: 25e4,
      },
      preroll: { consentWaitBudgetMs: 5e3, defaultMinTimeBetweenAdsMs: 18e4 },
      midroll: {
        defaultMinTimeBetweenAdsMs: 18e4,
        defaultWaitAfterErrorMs: 6e4,
        maxWaitAfterRewardedMs: 6e4,
        hiddenTabTimeToResetTimerMs: 6e4,
        holidayMode: { maxTimeBetweenAdsMs: 12e4, maxNoAdInFirstMinutes: 2 },
      },
      rewarded: { defaultMinTimeBetweenAdsMs: 5e3 },
    },
    gp = {
      amazonExtraTimeoutMs: 100,
      consentManagementTimeoutMs: 1e3,
      bidBasedPriceFloorMinSecondsToLive: 30,
      prebid: {
        maxRequestsPerOrigin: 6,
        minBidCacheTTLSeconds: 60,
        bidTtlBufferMs: 1e3,
        bidLimitPerBidder: 1,
      },
      userSync: { syncDelayMs: 15e3, syncsPerBidder: 1 },
    };
  function bp(e, t = !1) {
    return Ap(e, (e) => e.gdprApplicable, t);
  }
  function vp(e, t = !1) {
    return Ap(e, (e) => e.euMember, t);
  }
  function yp(e) {
    return Ap(
      e,
      (e) =>
        e.isoCode === Ti.isoCode ? "GPP" : e.gdprApplicable ? "TCF" : "None",
      "None"
    );
  }
  function Ap(e, t, n) {
    if (!Rn(e)) return n;
    const r = wp(e);
    return Rn(r) ? t(r) : n;
  }
  let Cp;
  function wp(e) {
    if (!Rn(Cp)) {
      const e = {};
      Mi.forEach((t) => (e[t.isoCode] = t)), (Cp = e);
    }
    return Cp[e];
  }
  async function Sp(e, t = {}) {
    return Ip({ type: "source", src: e, customProps: t });
  }
  function Ip(e) {
    return new Promise((t, n) => {
      const r = document.createElement("script");
      switch (
        ((r.onload = () => t()),
        (r.onerror = (t, r, i, o, s) => {
          let a;
          if ("string" == typeof t) a = t;
          else {
            const e = t.currentTarget;
            a = `type: ${t.type} - target: ${e.tagName}#${e.id || "no-id"}`;
          }
          n(
            new _p(
              `LoadScript error (${(function (e) {
                switch (e.type) {
                  case "source":
                    return `from url ${e.src}`;
                  case "content":
                    return "from content";
                }
              })(e)}): ${a}.`,
              t,
              r,
              i,
              o,
              s
            )
          );
        }),
        (r.async = !0),
        e.type)
      ) {
        case "source":
          r.src = e.src;
          break;
        case "content":
          r.text = e.content;
      }
      Rn(e.customProps) &&
        Object.entries(e.customProps).forEach(([e, t]) => {
          r.setAttribute(e, t);
        }),
        document.head.appendChild(r);
    });
  }
  var _p = class extends Error {
    _event;
    _source;
    _lineNumber;
    _columnNumber;
    _error;
    constructor(e, t, n, r, i, o) {
      super(e),
        (this._event = t),
        (this._source = n),
        (this._lineNumber = r),
        (this._columnNumber = i),
        (this._error = o);
    }
    get event() {
      return this._event;
    }
    get source() {
      return this._source;
    }
    get lineNumber() {
      return this._lineNumber;
    }
    get columnNumber() {
      return this._columnNumber;
    }
    get error() {
      return this._error;
    }
    toString() {
      const e =
        "string" == typeof this.event
          ? this.event
          : `event[${this.event.type}]`;
      return `${super.toString()}: event: ${e} - source: ${
        this.source
      } - lineNumber: ${this.lineNumber} - columnNumber: ${
        this.columnNumber
      } - error: ${this.error} `;
    }
  };
  class kp {
    loaderPromise = null;
    constructor(e) {
      this.scriptName = e;
    }
    async loadIfNeeded() {
      return (arguments.length > 0 &&
        void 0 !== arguments[0] &&
        arguments[0]) ||
        (await this.shouldLoad())
        ? this.load()
        : Promise.resolve();
    }
    load() {
      if (Rn(this.loaderPromise)) return this.loaderPromise;
      const e = this.getScriptLocations();
      return (
        (this.loaderPromise = (async () => {
          try {
            await Promise.all(e.map((e) => Sp(e)));
          } catch (e) {
            throw (
              (Zn.error(
                `[LoadScript] ${this.scriptName} failed to load (${Xi(e)})`,
                e
              ),
              e)
            );
          }
        })()),
        this.loaderPromise
      );
    }
    reset() {
      Zn.warn(
        `[LoadScript] ${this.scriptName} reset: should only be used for testing purposes`
      ),
        (this.loaderPromise = null);
    }
  }
  const Pp = new (class extends kp {
    constructor() {
      super("Adsense");
    }
    getScriptLocations() {
      return ["https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"];
    }
    async shouldLoad() {
      return !0;
    }
  })();
  const Bp = function (e) {
      return e instanceof Function;
    },
    Ep = "https://securepubads.g.doubleclick.net/tag/js/gpt.js";
  const xp = new (class extends kp {
    constructor() {
      super("GoogleTag");
    }
    async shouldLoad() {
      return !this.isGoogleTagDefined();
    }
    getScriptLocations() {
      return [Ep];
    }
    isGoogleTagDefined() {
      const e = Ln();
      return Rn(e) && Bp(e.pubads) && Bp(e.pubads().getSlots);
    }
  })();
  nn(), rn(), on(), sn(), an(), cn(), dn();
  const Tp = "12.39.0";
  let Rp = (function (e) {
    return (
      (e.ios = "iOS"),
      (e.android = "Android"),
      (e.linux = "Linux"),
      (e.chromeos = "Chromium OS"),
      (e.macos = "Mac OS"),
      (e.windows = "Windows"),
      (e.other = "Other"),
      e
    );
  })({});
  const zp = [
    {
      configCatKey: "czyExpClientOptable4",
      gamKey: "optable_exp_4_26",
      defaultValue: { configCatValue: "disabled", gamValue: "false" },
      otherValues: [
        {
          configCatValue: "enabled",
          gamValue: "true",
          customPrebidFileName: "rafvertizing-prebid-optable.js",
        },
      ],
    },
    {
      configCatKey: "czyExpClientAdsDummyAA",
      gamKey: "aa_configcat_exp",
      defaultValue: { configCatValue: "disabled", gamValue: "false" },
      otherValues: [{ configCatValue: "enabled", gamValue: "true" }],
    },
    {
      configCatKey: "czyExpClientAdsDummyAA10",
      gamKey: "aa_cc_10_exp",
      defaultValue: { configCatValue: "disabled", gamValue: "false" },
      otherValues: [{ configCatValue: "enabled", gamValue: "true" }],
    },
    {
      configCatKey: "czyExpClientAdsDummyAA20",
      gamKey: "aa_cc_20_exp",
      defaultValue: { configCatValue: "disabled", gamValue: "false" },
      otherValues: [{ configCatValue: "enabled", gamValue: "true" }],
    },
    {
      configCatKey: "czyExpClientAdsDummyAA50",
      gamKey: "aa_cc_50_exp",
      defaultValue: { configCatValue: "disabled", gamValue: "false" },
      otherValues: [{ configCatValue: "enabled", gamValue: "true" }],
    },
    {
      configCatKey: "czyExpClientLiveIntent",
      gamKey: "li-module-enabled",
      defaultValue: {
        configCatValue: "disabled",
        gamValue: "false",
        chance: 0.05,
      },
      otherValues: [
        { configCatValue: "enabled", gamValue: "true", chance: 0.95 },
      ],
    },
    {
      configCatKey: "czyExpClientAmazonBidRoute_2",
      gamKey: "aps_prebid_exp_26_4",
      defaultValue: { configCatValue: "apstag", gamValue: "apstag" },
      otherValues: [{ configCatValue: "prebid", gamValue: "prebid" }],
    },
    {
      configCatKey: "czyExpClientBidBasedPriceFloor_CZY_21335",
      gamKey: "bid_pf_exp_4_26",
      defaultValue: { configCatValue: "disabled", gamValue: "disabled" },
      otherValues: [
        { configCatValue: "highest", gamValue: "highest" },
        { configCatValue: "second_highest", gamValue: "second_highest" },
      ],
    },
    {
      configCatKey: "czyExpClientVideoNoFillFloor_CZY_18944",
      gamKey: "nofill_pf_exp_10_26",
      defaultValue: { configCatValue: "disabled", gamValue: "disabled" },
      otherValues: [
        { configCatValue: "lowered_floor", gamValue: "lowered_floor" },
      ],
    },
    {
      configCatKey: "czyExpClientAdsHolidayMode_CZY_21360",
      gamKey: "holiday_exp_1_26",
      defaultValue: { configCatValue: "disabled", gamValue: "false" },
      otherValues: [{ configCatValue: "enabled", gamValue: "true" }],
    },
    {
      configCatKey: "czyExpClientAdmiral_2",
      gamKey: "admiral_exp_2_26",
      defaultValue: { configCatValue: "disabled", gamValue: "false" },
      otherValues: [{ configCatValue: "enabled", gamValue: "true" }],
    },
    {
      configCatKey: "czyExpClientAdXFloor_1_CZY_20844",
      gamKey: "adxfloor_1_exp_26",
      defaultValue: { configCatValue: "1", gamValue: "1" },
      otherValues: [
        { configCatValue: "1.1", gamValue: "1.1" },
        { configCatValue: "1.2", gamValue: "1.2" },
        { configCatValue: "1.3", gamValue: "1.3" },
      ],
    },
    {
      configCatKey: "czyExpClientAutoRefreshIngameBanners",
      gamKey: "auto_refresh_exp_26",
      defaultValue: { configCatValue: "disabled", gamValue: "false" },
      otherValues: [{ configCatValue: "enabled", gamValue: "true" }],
    },
    {
      configCatKey: "czyExpClientVerticalVideoSize_CZY_22165",
      gamKey: "vert_video_exp_1_26",
      defaultValue: { configCatValue: "disabled", gamValue: "false" },
      otherValues: [{ configCatValue: "enabled", gamValue: "true" }],
    },
    {
      configCatKey: "czyExpClientMoreInGameBannerSizes_CZY_17692",
      gamKey: "ingame_size_exp_1_26",
      defaultValue: { configCatValue: "disabled", gamValue: "false" },
      otherValues: [{ configCatValue: "enabled", gamValue: "true" }],
    },
    {
      configCatKey: "czyExpClientBannerMinTimeInView_CZY_22047",
      gamKey: "time_in_view_exp_26",
      defaultValue: { configCatValue: "disabled", gamValue: "false" },
      otherValues: [{ configCatValue: "enabled", gamValue: "true" }],
    },
    {
      configCatKey: "czyExpClientGoogleH5Us_CZY_22096",
      gamKey: "goog_h5_us_exp_26",
      defaultValue: { configCatValue: "disabled", gamValue: "false" },
      otherValues: [{ configCatValue: "enabled", gamValue: "true" }],
    },
    {
      configCatKey: "czyExpClientGoogleH5IosSafari_CZY_22096",
      gamKey: "goog_h5_ios_exp_26",
      defaultValue: { configCatValue: "disabled", gamValue: "false" },
      otherValues: [{ configCatValue: "enabled", gamValue: "true" }],
      appliesTo: (e) =>
        e.operatingSystem === Rp.ios &&
        ("Safari" === e.browser || "Mobile Safari" === e.browser),
    },
  ];
  function Mp(e, t) {
    return (function (e, t) {
      return Rn(Op(e, t));
    })(t, e)
      ? t
      : Fp(e).defaultValue.configCatValue;
  }
  function Op(e, t) {
    if (!Rn(e)) return;
    const n = Fp(t);
    return n.defaultValue.configCatValue === e
      ? n.defaultValue
      : n.otherValues.find((t) => t.configCatValue === e);
  }
  function Fp(e) {
    return Up[e];
  }
  const Up = Object.fromEntries(zp.map((e) => [e.configCatKey, e]));
  let Np = {};
  function Lp() {
    return (function (e) {
      const t = [];
      for (const n of zp) {
        const r = Mp(n.configCatKey, e(n.configCatKey)),
          i = [n.defaultValue, ...n.otherValues].find(
            (e) => e.configCatValue === r && Rn(e.customPrebidFileName)
          )?.customPrebidFileName;
        Rn(i) && t.push(i);
      }
      return t;
    })(Dp);
  }
  function jp(e) {
    return Mp(e, Dp(e));
  }
  function Dp(e) {
    return Np[e];
  }
  const Vp = "rafvertizing-prebid.js",
    Gp = "rafvertizing-all-exp-prebid.js";
  const $p = new (class extends kp {
    constructor() {
      super("Prebid");
    }
    getScriptLocations() {
      const e = this.baseDomain(),
        t = [...new Set(Lp().filter(ji))];
      if (0 === t.length) return [`${e}/${Vp}`];
      if (1 === t.length) {
        const n = t[0];
        return (
          Zn.debug(`[PrebidLoader] Loading custom prebid filename: ${n}`),
          [`${e}/${n}`]
        );
      }
      return (
        Zn.debug(
          `[PrebidLoader] Loading custom prebid with all experiments: ${Gp}`
        ),
        [`${e}/${Gp}`]
      );
    }
    async shouldLoad() {
      return !this.isPrebidLoaded();
    }
    isPrebidLoaded() {
      const e = window;
      return e.pbjs && e.pbjs.libLoaded;
    }
    baseDomain() {
      const [e, t] = Tp.split(".");
      switch (Oi) {
        case "dev":
          return `https://rafvertizing.dev-crazygames.be/v${e}`;
        case "localhost":
          return process.env.BASE_URL;
        default:
          return `https://fafvertizing.crazygames.com/v${e}.${t}`;
      }
    }
    reset() {
      super.reset();
    }
  })();
  function qp(e) {
    return Rn(e.adUnit.mediaTypes.banner);
  }
  function Zp(e) {
    return Rn(e.adUnit.mediaTypes.video);
  }
  function Kp(e) {
    return pr.some((t) => e === t);
  }
  function Hp() {
    return [...fr];
  }
  bn();
  class Wp {
    win = (() => window)();
    cmpCallbacks = {};
    eventCallbacks = {};
    constructor(e) {
      let {
        apiName: t,
        apiVersion: n,
        apiArgs: r = ["command", "callback", "version"],
        callbackArgs: i = ["returnValue", "success"],
      } = e;
      (this.apiName = t),
        (this.apiVersion = n),
        (this.apiArgs = r),
        (this.callbackArgs = i),
        (this.callName = `${t}Call`),
        (this.returnName = `${t}Return`);
    }
    installLocator(e) {
      let t =
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
      if (window[this.apiName]) return Promise.resolve();
      return t >= e
        ? Promise.resolve()
        : ((() => {
            const { cmpFrame: e } = this.findLocatorFrame();
            Rn(e) && this.setupCMPWhileInIframe(e);
          })(),
          window[this.apiName]
            ? Promise.resolve()
            : new Promise((n) => {
                window.setTimeout(() => {
                  this.installLocator(e, t + 1)
                    .catch(() => {})
                    .finally(() => n());
                }, 50);
              }));
    }
    findLocatorFrame() {
      let e,
        t = window;
      for (;;) {
        try {
          if (t.frames[`${this.apiName}Locator`]) {
            e = t;
            break;
          }
        } catch {}
        if (t === window.top) break;
        t = t.parent;
      }
      return { cmpFrame: e };
    }
    setupCMPWhileInIframe(e) {
      var t = this;
      (window[this.apiName] = function () {
        for (var n = arguments.length, r = new Array(n), i = 0; i < n; i++)
          r[i] = arguments[i];
        const o = Math.random() + "",
          s = t.apiArgs.reduce((e, t, n) => ((e[t] = r[n]), e), {
            version: t.apiVersion,
            callId: o,
          }),
          a = s.callback,
          c = Object.fromEntries(
            Object.entries(s).filter((e) => {
              let [t, n] = e;
              return "callback" !== t;
            })
          ),
          d = { [t.callName]: c };
        if (void 0 !== a) {
          const n = s.command;
          if ("addEventListener" === n)
            t.cmpCallbacks[o] = {
              callbackFunction: (e, n) => {
                a(e, n);
                const r = e.listenerId;
                t.eventCallbacks[r] = (t.eventCallbacks[r] || []).concat(o);
              },
              deleteOnInvoke: !1,
            };
          else if ("removeEventListener" === n) {
            const e = s.parameter;
            if (Rn(e)) {
              (t.eventCallbacks[e] || []).forEach((e) => {
                delete t.cmpCallbacks[e];
              }),
                delete t.eventCallbacks[o],
                (t.cmpCallbacks[o] = {
                  callbackFunction: a,
                  deleteOnInvoke: !0,
                });
            }
          } else
            t.cmpCallbacks[o] = { callbackFunction: a, deleteOnInvoke: !0 };
          e.postMessage(d, "*");
        }
      }),
        this.win.addEventListener(
          "message",
          (e) => this.readPostMessageResponse(e),
          !1
        );
    }
    readPostMessageResponse(e) {
      const t =
        "string" == typeof e.data && e.data.includes(this.returnName)
          ? JSON.parse(e.data)
          : e.data;
      if (t?.[this.returnName]?.callId) {
        const e = t[this.returnName];
        try {
          if (
            this.cmpCallbacks.hasOwnProperty(e.callId) &&
            void 0 !== this.cmpCallbacks[e.callId]
          ) {
            const t = this.cmpCallbacks[e.callId];
            t.deleteOnInvoke && delete this.cmpCallbacks[e.callId],
              t.callbackFunction(...this.callbackArgs.map((t) => e[t]));
          }
        } catch {}
      }
    }
  }
  function Jp() {
    const e = { resolve: (e) => {}, reject: (e) => {}, promise: null };
    return (
      (e.promise = new Promise((t, n) => {
        (e.resolve = t), (e.reject = n);
      })),
      e
    );
  }
  const Yp = "__gpp";
  class Qp {
    win = (() => window)();
    apiName = (() => Yp)();
    apiVersion = 1;
    apiArgs = ["command", "callback", "parameter", "version"];
    callbackArgs = ["returnValue", "success"];
    callName = (() => `${Yp}Call`)();
    returnName = (() => `${Yp}Return`)();
    cmpCallbacks = {};
    nextListenerId = 1;
    listeners = [];
    latestListenerData = {
      eventName: "listenerRegistered",
      listenerId: 0,
      data: !0,
      pingData: {
        gppVersion: "1.1",
        cmpStatus: "stub",
        cmpDisplayStatus: "hidden",
        signalStatus: "not ready",
        supportedAPIs: [
          "2:tcfeuv2",
          "5:tcfcav1",
          "6:uspv1",
          "7:usnat",
          "8:usca",
          "9:usva",
          "10:usco",
          "11:usut",
          "12:usct",
        ],
        cmpId: 0,
        sectionList: [],
        applicableSections: [-1],
        gppString: "",
        parsedSections: {},
      },
    };
    installLocator(e) {
      let t =
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
      if (window[this.apiName]) return Promise.resolve();
      return t >= e
        ? Promise.resolve()
        : ((() => {
            const { cmpFrame: e } = this.findLocatorFrame();
            Rn(e) && this.setupCMPWhileInIframe(e);
          })(),
          window[this.apiName]
            ? Promise.resolve()
            : new Promise((n) => {
                window.setTimeout(() => {
                  this.installLocator(e, t + 1)
                    .catch(() => {})
                    .finally(() => n());
                }, 50);
              }));
    }
    findLocatorFrame() {
      let e,
        t = window;
      for (;;) {
        try {
          if (t.frames[`${this.apiName}Locator`]) {
            e = t;
            break;
          }
        } catch {}
        if (t === window.top) break;
        t = t.parent;
      }
      return { cmpFrame: e };
    }
    async setupCMPWhileInIframe(e) {
      var t = this;
      const n = "__addInternalListener",
        r = Jp(),
        i = function () {
          for (var r = arguments.length, i = new Array(r), o = 0; o < r; o++)
            i[o] = arguments[o];
          const s = Math.random() + "",
            a = t.apiArgs.reduce((e, t, n) => ((e[t] = i[n]), e), {
              version: t.apiVersion,
              callId: s,
            }),
            c = a.callback,
            d = Object.fromEntries(
              Object.entries(a).filter((e) => {
                let [t, n] = e;
                return "callback" !== t;
              })
            ),
            u = { [t.callName]: d };
          if (void 0 !== c) {
            const r = a.command;
            if (r === n)
              (d.command = "addEventListener"),
                (t.cmpCallbacks[s] = {
                  callbackFunction: c,
                  deleteOnInvoke: !1,
                }),
                e.postMessage(u, "*");
            else {
              if ("addEventListener" === r) {
                const e = t.nextListenerId;
                t.nextListenerId++,
                  t.listeners.push({ listenerId: e, callback: c });
                const n = {
                  ...t.latestListenerData,
                  eventName: "listenerRegistered",
                  listenerId: e,
                  data: !0,
                };
                return c(n, !0), n;
              }
              if ("removeEventListener" === r) {
                const e = a.parameter;
                if (Rn(e)) {
                  const n = t.listeners.findIndex((t) => t.listenerId === e);
                  if (n >= 0) {
                    t.listeners
                      .splice(n, 1)[0]
                      .callback(
                        {
                          ...t.latestListenerData,
                          eventName: "listenerRemoved",
                          listenerId: e,
                          data: !0,
                        },
                        !0
                      );
                  }
                }
              } else
                (t.cmpCallbacks[s] = {
                  callbackFunction: c,
                  deleteOnInvoke: !0,
                }),
                  e.postMessage(u, "*");
            }
          }
        };
      i(n, (e, t) => {
        if (
          ((this.latestListenerData = e),
          r.resolve(),
          "listenerRegistered" !== e.eventName &&
            "listenerRemoved" !== e.eventName)
        )
          for (const n of this.listeners) {
            const r = { ...e, listenerId: n.listenerId };
            n.callback(r, t);
          }
      }),
        this.win.addEventListener(
          "message",
          (e) => this.readPostMessageResponse(e),
          !1
        ),
        await r.promise,
        (window[this.apiName] = i);
    }
    readPostMessageResponse(e) {
      const t =
        "string" == typeof e.data && e.data.includes(this.returnName)
          ? JSON.parse(e.data)
          : e.data;
      if (t?.[this.returnName]?.callId) {
        const e = t[this.returnName];
        try {
          if (
            this.cmpCallbacks.hasOwnProperty(e.callId) &&
            void 0 !== this.cmpCallbacks[e.callId]
          ) {
            const t = this.cmpCallbacks[e.callId];
            t.deleteOnInvoke && delete this.cmpCallbacks[e.callId],
              t.callbackFunction(...this.callbackArgs.map((t) => e[t]));
          }
        } catch {}
      }
    }
  }
  const Xp = async function () {
    const e = Er(),
      t = Rn(e) ? yp(e) : void 0,
      n = !Rn(t) || "TCF" === t,
      r = !Rn(t) || "GPP" === t,
      i = [];
    if (n) {
      const e = new Wp({
        apiName: "__tcfapi",
        apiVersion: 2,
        apiArgs: ["command", "version", "callback", "parameter"],
      });
      i.push(e.installLocator(5));
    }
    if (r) {
      const e = new Qp();
      i.push(e.installLocator(5));
    }
    return Promise.all(i);
  };
  class ef {
    callback = void 0;
    tcfConsentCBInstalled = !1;
    tcfInstalledListenerInstalled = !1;
    constructor() {}
    async init(e) {
      return (this.callback = e), this.installTCFConsentCB();
    }
    async installTCFConsentCB() {
      if (this.tcfConsentCBInstalled) return;
      const e = window;
      Rn(e.__tcfapi) || (await Xp()),
        Rn(e.__tcfapi)
          ? (e.__tcfapi("addEventListener", 2, (e, t) => {
              t && e && Rn(this.callback) && this.callback(e, t);
            }),
            (this.tcfConsentCBInstalled = !0))
          : this.installTCFLoadedListener();
    }
    installTCFLoadedListener = () => {
      this.tcfInstalledListenerInstalled ||
        (window.addEventListener("message", this.tcfLoadedListener),
        (this.tcfInstalledListenerInstalled = !0));
    };
    tcfLoadedListener = (e) => {
      Rn(e.data) &&
        "object" == typeof e.data &&
        e.data.type === lr &&
        (window.removeEventListener("message", this.tcfLoadedListener),
        this.installTCFConsentCB());
    };
  }
  function tf(e) {
    return (
      "tcloaded" === e.eventStatus || "useractioncomplete" === e.eventStatus
    );
  }
  const nf = 11;
  const rf = class {
    tcfData = null;
    tcfSuccess = !1;
    consentListeners = [];
    constructor(e) {
      (Rn(e?.consentInformationRetriever)
        ? e?.consentInformationRetriever
        : new ef()
      )
        .init(this.consentTCFCb)
        .then(() => {
          Rn(e?.onInitialized) && e.onInitialized();
        });
    }
    addTCFConsentListener(e) {
      this.consentListeners.push(e),
        Rn(this.tcfData) &&
          this.callConsentListener(e, this.tcfData, this.tcfSuccess);
    }
    hasTCFConsent() {
      return (
        !(
          !this.tcfSuccess ||
          !Rn(this.tcfData) ||
          !0 !== this.tcfData.gdprApplies
        ) && tf(this.tcfData)
      );
    }
    getConsentInformation(e) {
      if ("TCF" !== yp(e)) return null;
      if (Rn(this.tcfData) && !0 !== this.tcfData.gdprApplies) return null;
      const t = this.tcfData?.purpose?.consents;
      return {
        countryCode: e,
        consentSystem: "TCF",
        applicable: !0,
        consentInformationAvailable: this.hasTCFConsent(),
        state: this.consentState(),
        purposeConsents: Rn(t) ? { ...t } : void 0,
      };
    }
    consentState() {
      return this.hasTCFConsent()
        ? (function (e) {
            const t = Object.values(e?.purpose?.consents ?? {});
            if (0 === t.length)
              return "useractioncomplete" === e?.eventStatus
                ? "none"
                : "pending";
            const n = t.filter((e) => !0 === e).length;
            return 0 === n ? "none" : n === nf ? "all" : "some";
          })(this.tcfData)
        : "pending";
    }
    removeTCConsentListener(e) {
      this.consentListeners = this.consentListeners.filter((t) => t !== e);
    }
    callConsentListener(e, t, n) {
      try {
        e(t, n);
      } catch (e) {
        Zn.error(e);
      }
    }
    consentTCFCb = (e, t) => {
      t &&
        e &&
        ((Rn(this.tcfData) && !tf(e)) ||
          ((this.tcfData = e),
          (this.tcfSuccess = t),
          this.consentListeners.forEach((n) => {
            this.callConsentListener(n, e, t);
          })));
    };
  };
  Kt();
  class of {
    callback = void 0;
    gppConsentCBInstalled = !1;
    cmpInstalledListenerInstalled = !1;
    constructor() {}
    async init(e) {
      return (this.callback = e), this.installGppConsentCB();
    }
    async installGppConsentCB() {
      if (this.gppConsentCBInstalled) return;
      const e = window;
      Rn(e.__gpp) || (await Xp()),
        Rn(e.__gpp)
          ? (e.__gpp("addEventListener", (e, t) => {
              var n;
              t &&
                Rn(this.callback) &&
                this.callback({
                  version: (n = e.pingData).gppVersion,
                  gppString: n.gppString,
                  parsedSections: n.parsedSections,
                  signalStatus: n.signalStatus,
                  cmpDisplayStatus: n.cmpDisplayStatus,
                });
            }),
            (this.gppConsentCBInstalled = !0))
          : this.installCmpLoadedListener();
    }
    installCmpLoadedListener = () => {
      this.cmpInstalledListenerInstalled ||
        (window.addEventListener("message", this.cmpLoadedListener),
        (this.cmpInstalledListenerInstalled = !0));
    };
    cmpLoadedListener = (e) => {
      Rn(e.data) &&
        "object" == typeof e.data &&
        e.data.type === lr &&
        (window.removeEventListener("message", this.cmpLoadedListener),
        this.installGppConsentCB());
    };
  }
  function sf(e) {
    return 1 === e || "Y" === e || (2 !== e && "N" !== e && void 0);
  }
  const af = class {
    gppData = void 0;
    consentListeners = [];
    hasFinalizedGppConsent = !1;
    constructor(e) {
      (Rn(e?.consentInformationRetriever)
        ? e.consentInformationRetriever
        : new of()
      )
        .init(this.consentGPPCb)
        .then(() => {
          Rn(e?.onInitialized) && e.onInitialized();
        });
    }
    addGPPConsentListener(e) {
      this.consentListeners.push(e),
        Rn(this.gppData) && this.callConsentListener(e, this.gppData);
    }
    removeGPPConsentListener(e) {
      this.consentListeners = this.consentListeners.filter((t) => t !== e);
    }
    hasGPPConsent() {
      return Rn(this.gppData) && this.hasFinalizedGppConsent;
    }
    getConsentInformation(e) {
      if ("GPP" !== yp(e)) return null;
      const t = this.hasGPPConsent();
      return {
        countryCode: e,
        consentSystem: "GPP",
        applicable: !0,
        consentInformationAvailable: t,
        state: t ? this.classifyUsOptOut() : "pending",
      };
    }
    classifyUsOptOut() {
      const e = Object.values(this.gppData?.parsedSections ?? {})
        .flat()
        .flatMap((e) => [
          e?.SaleOptOut,
          e?.SharingOptOut,
          e?.TargetedAdvertisingOptOut,
          e?.OptOutSale,
        ])
        .map(sf)
        .filter(Rn);
      return 0 === e.length ? "na" : e.includes(!0) ? "none" : "all";
    }
    getUspConsentString(e) {
      if ("GPP" !== yp(e)) return null;
      if (!Rn(this.gppData)) return null;
      const t = this.gppData.parsedSections;
      if (!Rn(t)) return null;
      if (t.uspv1) {
        const e = t.uspv1;
        return `${e.Version}${e.Notice}${e.OptOutSale}${e.LspaCovered}`;
      }
      let n, r;
      if (
        (Object.values(t).forEach((e) => {
          (Array.isArray(e) ? e : [e]).forEach((e) => {
            const t = e.SaleOptOut,
              i = e.SaleOptOutNotice;
            !Rn(n) && !Rn(r) && Rn(t) && Rn(i) && ((n = t), (r = i));
          });
        }),
        Rn(n) && Rn(r))
      ) {
        const e = 0 === n ? "-" : 1 === n ? "Y" : "N",
          t = 0 === r ? "-" : 1 === r ? "Y" : "N";
        return `1${t}${e}${"-" === e && "-" === t ? "-" : "Y"}`;
      }
      return null;
    }
    callConsentListener(e, t) {
      try {
        e(t);
      } catch (e) {
        Zn.error(e);
      }
    }
    consentGPPCb = (e) => {
      (this.gppData = e),
        !this.hasFinalizedGppConsent &&
          Rn(e) &&
          "ready" === e.signalStatus &&
          "visible" !== e.cmpDisplayStatus &&
          (this.hasFinalizedGppConsent = !0),
        this.hasFinalizedGppConsent &&
          this.consentListeners.forEach((t) => this.callConsentListener(t, e));
    };
  };
  class cf {
    static createTestingInstance(e, t) {
      return new cf({
        tcfConsentManagement: e,
        gppConsentManagement: t,
        skipLocatorFrames: !0,
      });
    }
    static getInstance() {
      return this.Instance || (this.Instance = new cf()), this.Instance;
    }
    consentListeners = [];
    consent = !1;
    constructor(e) {
      (this.tcfConsentManagement = e?.tcfConsentManagement ?? new rf()),
        (this.gppConsentManagement = e?.gppConsentManagement ?? new af()),
        this.init(e?.skipLocatorFrames);
    }
    async init(e) {
      (Rn(e) && e) || (await Xp()),
        this.addTCFConsentListener(this.onTCFConsentChange),
        this.addGPPConsentListener(this.onGppConsentChange);
    }
    addTCFConsentListener(e) {
      this.tcfConsentManagement.addTCFConsentListener(e);
    }
    hasTCFConsent() {
      return this.tcfConsentManagement.hasTCFConsent();
    }
    removeTCConsentListener(e) {
      this.tcfConsentManagement.removeTCConsentListener(e);
    }
    addGPPConsentListener(e) {
      this.gppConsentManagement.addGPPConsentListener(e);
    }
    removeGPPConsentListener(e) {
      this.gppConsentManagement.removeGPPConsentListener(e);
    }
    hasGppConsent() {
      return this.gppConsentManagement.hasGPPConsent();
    }
    addConsentListener(e) {
      this.consentListeners.push(e), this.fireConsentEventToListener(e);
    }
    removeConsentListener(e) {
      this.consentListeners = this.consentListeners.filter((t) => t !== e);
    }
    onTCFConsentChange = (e, t) => {
      this.hasTCFConsent() !== this.consent &&
        ((this.consent = this.hasTCFConsent()),
        this.consentListeners.forEach((e) =>
          this.fireConsentEventToListener(e)
        ));
    };
    onGppConsentChange = (e) => {
      this.hasGppConsent() !== this.consent &&
        ((this.consent = this.hasGppConsent()),
        this.consentListeners.forEach((e) =>
          this.fireConsentEventToListener(e)
        ));
    };
    fireConsentEventToListener(e) {
      try {
        e();
      } catch (e) {
        Zn.error(e);
      }
    }
    getConsentInformation(e) {
      const t = this.tcfConsentManagement.getConsentInformation(e);
      if (Rn(t)) return t;
      const n = this.gppConsentManagement.getConsentInformation(e);
      return Rn(n)
        ? n
        : {
            countryCode: e,
            consentSystem: "None",
            applicable: !1,
            consentInformationAvailable: !1,
            state: "na",
          };
    }
    getLegacyUspConsentInformation(e) {
      return this.gppConsentManagement.getUspConsentString(e) ?? void 0;
    }
  }
  const df = cf,
    uf = ["liveIntentId"],
    lf = mr.filter((e) => !uf.includes(e));
  class pf {
    static instance = null;
    static getInstance() {
      return Rn(this.instance) || (this.instance = new pf()), this.instance;
    }
    static createForTesting(e) {
      return (
        Zn.warn(
          "[IncrementalIdProviderTest] Testing info should only be used for testing purposes"
        ),
        new pf(e)
      );
    }
    actualCandidates = (() => new Set())();
    constructor(e) {
      if (Rn(e))
        (this.candidates = e.candidates),
          (this.disabledProvider = e.disabledProvider);
      else {
        (this.candidates = [...lf, gr]), this.actualCandidates.add(gr);
        const e = 0.005 * this.candidates.length;
        Math.random() < e &&
          (this.disabledProvider =
            this.candidates[
              Math.floor(Math.random() * this.candidates.length)
            ]);
      }
      const t = this.getForcedDisabledProvider(this.candidates);
      Rn(t)
        ? ((this.disabledProvider = t),
          Zn.debug(
            `Incremental id provider test forced disabled provider via search param: ${this.disabledProvider}`
          ))
        : Zn.debug(
            `Incremental id provider test initialized with disabled provider: ${this.disabledProvider}`
          );
    }
    getForcedDisabledProvider(e) {
      const t = new URLSearchParams(window.location.search).get(
        "force_disabled_id_provider"
      );
      return Rn(t) ? e.find((e) => e === t) : void 0;
    }
    isProviderDisabled(e) {
      return this.disabledProvider === e;
    }
    addToActualCandidates(e) {
      this.candidates.includes(e) && this.actualCandidates.add(e);
    }
    getGamKeys() {
      const e = {},
        t = [],
        n = [];
      return (
        this.actualCandidates.forEach((e) => {
          this.isProviderDisabled(e) ? n.push(e) : t.push(e);
        }),
        t.length > 0 && (e[Yn] = t),
        n.length > 0 && (e[Qn] = n),
        e
      );
    }
  }
  const ff = pf;
  const hf = function (e, t) {
      return new Promise((n, r) => {
        window.setTimeout(() => {
          n(t);
        }, e);
      });
    },
    mf = "prebid.js";
  async function gf() {
    try {
      await Sp(
        (function () {
          switch (Oi) {
            case "dev":
              return `https://rafvertizing.dev-crazygames.be/${mf}`;
            case "prod":
              return `https://mafvertizing.crazygames.com/${mf}`;
            case "localhost":
              return `${process.env.BASE_URL}/${mf}`;
            default:
              return (
                Zn.warn("[HasAdblock] Invalid environment", Oi),
                `https://mafvertizing.crazygames.com/${mf}`
              );
          }
        })()
      );
    } catch (e) {
      return (
        Zn.debug('[Adblock] Adblock detected (our "prebid" failed to load)', e),
        !0
      );
    }
    try {
      const e = !Rn(document.getElementById("AZJUSpftxLwH"));
      return e && Zn.debug("[Adblock] Adblock detected (no div)"), e;
    } catch {
      return Zn.debug("[Adblock] Adblock detected"), !0;
    }
  }
  async function bf() {
    try {
      const e = await fetch(Ep, { method: "HEAD" });
      if (e.redirected) {
        const t = e.url;
        if (
          (Zn.debug(
            "[Adblock] Trying to load Googletag results in a redirect to:",
            t
          ),
          t.includes("extension"))
        )
          return (
            Zn.debug(
              "[Adblock] Redirected to an extension, so assume an adblocker is present"
            ),
            !0
          );
      }
      return (
        !e.ok &&
        (Zn.debug(
          `[Adblock] Loading googletag resulted in a status of ${e.status} (ok: ${e.ok}), so we assume there is an adblocker present.`
        ),
        !0)
      );
    } catch (e) {
      return Zn.debug("[Adblock] Fetching Googletag failed", e), !0;
    }
  }
  const vf = ["baitScript", "googleTag"],
    yf = { baitScript: void 0, googleTag: void 0 },
    Af = { baitScript: void 0, googleTag: void 0 };
  function Cf(e) {
    switch (e) {
      case "baitScript":
        return Promise.race([gf(), hf(250, !1)]);
      case "googleTag":
        return Promise.race([bf(), hf(250, !1)]);
    }
  }
  function wf(e) {
    switch (e) {
      case "baitScript":
        return !0;
      case "googleTag":
        const e = Br.getInstance().clientInfo.browser;
        return Rn(e) && !e.toLowerCase().includes("edge");
    }
  }
  const Sf = async function (e) {
    if (!0 === e) for (const e of vf) (yf[e] = void 0), (Af[e] = void 0);
    const t = [];
    for (const e of vf)
      Rn(yf[e]) || (yf[e] = Cf(e).then((t) => ((Af[e] = t), t))),
        wf(e) && t.push(yf[e]);
    await Promise.race(t);
    for (const e of vf.filter(wf)) {
      const t = Af[e];
      if (Rn(t) && t) return !0;
    }
    return !1;
  };
  const If = new (class extends kp {
    constructor() {
      super("blockthrough");
    }
    getScriptLocations() {
      return ["https://btloader.com/tag?o=5635927334453248&upapi=true"];
    }
    async shouldLoad() {
      return Sf();
    }
  })();
  function _f(e) {
    return e;
  }
  const kf = ["EUR", "USD"];
  function Pf(e) {
    return kf.some((t) => t === e);
  }
  class Bf {
    constructor(e, t) {
      let n = arguments.length > 2 && void 0 !== arguments[2] && arguments[2];
      (this._currency = t),
        (this._amountInCents = zf(n, !0)(e)),
        (this._amountInUnits = zf(n, !1)(e));
    }
    get currency() {
      return this._currency;
    }
    asUnits(e) {
      return Rf(this._currency, e)(this._amountInUnits);
    }
    asCents(e) {
      return Rf(this._currency, e)(this._amountInCents);
    }
    compareTo = (e) => {
      const t = this.asCents(this._currency),
        n = e.asCents(this._currency);
      return Math.trunc(1e4 * t) - Math.trunc(1e4 * n);
    };
    isGt = (e) => this.compareTo(e) > 0;
    isGte = (e) => this.compareTo(e) >= 0;
    isLt = (e) => this.compareTo(e) < 0;
    isLte = (e) => this.compareTo(e) <= 0;
    isEq = (e) => 0 === this.compareTo(e);
    isGreaterThanZero = () => this._amountInCents > 0;
    createCopyWithAdjustedAmount = (e) =>
      new Bf(e(this._amountInCents), this._currency, !0);
    convertTo(e) {
      return this.currency === e ? this : new Bf(this.asCents(e), e, !0);
    }
    toString() {
      return `${this._amountInCents}${this._currency}`;
    }
  }
  function Ef(e) {
    return new Bf(0, e ?? "EUR", !1);
  }
  function xf(e, t) {
    if (e.length <= 0) return t;
    if (1 === e.length) return e[0];
    const n = [...e];
    return n.sort(Nf((e) => e, "HIGH_TO_LOW")), n[0];
  }
  function Tf(e) {
    if (0 === e.length) return null;
    const t = e
        .map((e) => e.convertTo("EUR"))
        .sort(Nf((e) => e, "LOW_TO_HIGH")),
      n = Math.floor(t.length / 2);
    if (t.length % 2 == 1) return t[n];
    const r = (t[n - 1].asCents("EUR") + t[n].asCents("EUR")) / 2;
    return new Bf(r, "EUR", !0);
  }
  function Rf(e, t) {
    switch (e) {
      case "EUR":
        switch (t) {
          case "EUR":
            return (e) => e;
          case "USD":
            return Ff;
        }
        break;
      case "USD":
        switch (t) {
          case "EUR":
            return Uf;
          case "USD":
            return (e) => e;
        }
    }
  }
  function zf(e, t) {
    return e === t ? (e) => e : e ? Of : Mf;
  }
  function Mf(e) {
    return 100 * e;
  }
  function Of(e) {
    return e / 100;
  }
  function Ff(e) {
    return e / Yi();
  }
  function Uf(e) {
    return e * Yi();
  }
  function Nf(e, t) {
    let n;
    switch (t) {
      case "LOW_TO_HIGH":
        n = 1;
        break;
      case "HIGH_TO_LOW":
        n = -1;
    }
    return (t, r) => n * e(t).compareTo(e(r));
  }
  const Lf = JSON.parse(
    '{"_":{"z":[{"max":300,"increment":1,"cpms":{"1a5ue4g":1,"sekdmo":2,"1rx4em8":3,"1rncw0":4,"11a7dvk":5,"jixdds":6,"1j1hedc":7,"f33v9c":8,"1elnw8w":9,"wudvr4":10,"1wcxwqo":11,"67gv0g":12,"15q0w00":13,"nyqvi8":14,"1nhawhs":15,"cv7474":16,"1cdr56o":17,"umh4ow":18,"1u515og":19,"3zk3y8":20,"13i44xs":21,"lqu4g0":22,"1l9e5fk":23,"hb0mbk":24,"1gtknb4":25,"z2amtc":26,"1ykunsw":27,"8fdm2o":28,"17xxn28":29,"q6nmkg":30,"1pp7nk0":31,"9jbzls":32,"191w0lc":33,"ram03k":34,"1qt6134":35,"nozcw":36,"10690cg":37,"ieyzuo":38,"1hxj0u8":39,"dz5hq8":40,"1dhpips":41,"vqfi80":42,"1v8zj7k":43,"53ihhc":44,"14m2igw":45,"mushz4":46,"1mdciyo":47,"br8qo0":48,"1b9srnk":49,"tiir5s":50,"1t12s5c":51,"2vlqf4":52,"12e5reo":53,"kmvqww":54,"1k5frwg":55,"g728sg":56,"1fpm9s0":57,"xyc9a8":58,"1xgwa9s":59,"7bf8jk":60,"16tz9j4":61,"p2p91c":62,"1ol9a0w":63,"a3b6dc":64,"19lv7cw":65,"rul6v4":66,"1rd57uo":67,"17o64g":68,"10q8740":69,"iyy6m8":70,"1ihi7ls":71,"ej4ohs":72,"1e1ophc":73,"waeozk":74,"1vsypz4":75,"5nho8w":76,"1561p8g":77,"neroqo":78,"1mxbpq8":79,"cb7xfk":80,"1btryf4":81,"u2hxxc":82,"1tl1yww":83,"3fkx6o":84,"12y4y68":85,"l6uxog":86,"1kpeyo0":87,"gr1fk0":88,"1g9lgjk":89,"yibg1s":90,"1y0vh1c":91,"7vefb4":92,"17dygao":93,"pmofsw":94,"1p58gsg":95,"8zcsu8":96,"18hwtts":97,"qqmtc0":98,"1q96ubk":99,"3pslc":100,"zm9tkw":101,"huzt34":102,"1hdju2o":103,"df6ayo":104,"1cxqby8":105,"v6gbgg":106,"1up0cg0":107,"4jjaps":108,"1423bpc":109,"matb7k":110,"1ltdc74":111,"b79jwg":112,"1aptkw0":113,"syjke8":114,"1sh3lds":115,"2bmjnk":116,"11u6kn4":117,"k2wk5c":118,"1jlgl4w":119,"fn320w":120,"1f5n30g":121,"xed2io":122,"1wwx3i8":123,"6rg1s0":124,"16a02rk":125,"oiq29s":126,"1o1a39c":127,"ax9yio":128,"1aftzi8":129,"sojz0g":130,"1s74000":131,"21my9s":132,"11k6z9c":133,"jswyrk":134,"1jbgzr4":135,"fd3gn4":136,"1evnhmo":137,"x4dh4w":138,"1wmxi4g":139,"6hgge8":140,"1600hds":141,"o8qgw0":142,"1nrahvk":143,"d56pkw":144,"1cnqqkg":145,"uwgq2o":146,"1uf0r28":147,"49jpc0":148,"13s3qbk":149,"m0tpts":150,"1ljdqtc":151,"hl07pc":152,"1h3k8ow":153,"zca874":154,"1yuu96o":155,"8pd7gg":156,"187x8g0":157,"qgn7y8":158,"1pz78xs":159,"9tbkzk":160,"19bvlz4":161,"rkllhc":162,"1r35mgw":163,"xokqo":164,"10g8lq8":165,"ioyl8g":166,"1i7im80":167,"e95340":168,"1drp43k":169,"w0f3ls":170,"1viz4lc":171,"5di2v4":172,"14w23uo":173,"n4s3cw":174,"1mnc4cg":175,"c18c1s":176,"1bjsd1c":177,"tsicjk":178,"1tb2dj4":179,"35lbsw":180,"12o5csg":181,"kwvcao":182,"1kffda8":183,"gh1u68":184,"1fzlv5s":185,"y8buo0":186,"1xqvvnk":187,"7letxc":188,"173yuww":189,"pcouf4":190,"1ov8veo":191,"adarr4":192,"19vusqo":193,"s4ks8w":194,"1rn4t8g":195,"1hnri8":196,"1107shs":197,"j8xs00":198,"1irhszk":199,"et49vk":200,"1eboav4":201,"wkeadc":202,"1w2ybcw":203,"5xh9mo":204,"15g1am8":205,"nora4g":206,"1n7bb40":207,"cl7itc":208,"1c3rjsw":209,"uchjb4":210,"1tv1kao":211,"3pkikg":212,"1384jk0":213,"lguj28":214,"1kzek1s":215,"h110xs":216,"1gjl1xc":217,"ysb1fk":218,"1yav2f4":219,"85e0ow":220,"17ny1og":221,"pwo16o":222,"1pf8268":223,"99ce80":224,"18rwf7k":225,"r0meps":226,"1qj6fpc":227,"dpdz4":228,"zw9eyo":229,"i4zegw":230,"1hnjfgg":231,"dp5wcg":232,"1d7pxc0":233,"vgfwu8":234,"1uyzxts":235,"4tiw3k":236,"14c2x34":237,"mkswlc":238,"1m3cxkw":239,"bh95a8":240,"1azt69s":241,"t8j5s0":242,"1sr36rk":243,"2lm51c":244,"124660w":245,"kcw5j4":246,"1jvg6io":247,"fx2neo":248,"1ffmoe8":249,"xocnwg":250,"1x6wow0":251,"71fn5s":252,"16jzo5c":253,"ospnnk":254,"1ob9on4":255,"asa5ts":256,"1aau6tc":257,"sjk6bk":258,"1s247b4":259,"1wn5kw":260,"11f76kg":261,"jnx62o":262,"1j6h728":263,"f83ny8":264,"1eqnoxs":265,"wzdog0":266,"1whxpfk":267,"6cgnpc":268,"15v0oow":269,"o3qo74":270,"1nmap6o":271,"d06ww0":272,"1ciqxvk":273,"urgxds":274,"1ua0ydc":275,"44jwn4":276,"13n3xmo":277,"lvtx4w":278,"1ledy4g":279,"hg0f0g":280,"1gykg00":281,"z7afi8":282,"1ypughs":283,"8kderk":284,"182xfr4":285,"qbnf9c":286,"1pu7g8w":287,"9obsao":288,"196vta8":289,"rflssg":290,"1qy5ts0":291,"sos1s":292,"10b8t1c":293,"ijysjk":294,"1i2itj4":295,"e45af4":296,"1dmpbeo":297,"vvfaww":298,"1vdzbwg":299,"58ia68":300}},{"max":800,"increment":5,"cpms":{"1beskcg":305,"krvjls":310,"1xlw2yo":315,"a8az28":320,"10v7zsw":325,"wfehog":330,"1n2bif4":335,"3kkpvk":340,"1gel98g":345,"pro8hs":350,"1qe6n0g":355,"dk63nk":360,"14734e8":365,"t3jd34":370,"1jqgdts":375,"6wfugw":380,"1akts74":385,"jxwrgg":390,"1wrxatc":395,"da6i9s":400,"13x3j0g":405,"zha0w0":410,"1q471mo":415,"12odfk":420,"1dwowsg":425,"n9rw1s":430,"1tg2680":435,"gm1mv4":440,"178ynls":445,"s9kkxs":450,"1iwhlog":455,"62h2bk":460,"1c8rchs":465,"llubr4":470,"1yfuv40":475,"9ec6ww":480,"10197nk":485,"vlfpj4":490,"1m8cq9s":495,"2qlxq8":500,"1fkmh34":505,"oxpgcg":510,"1rumi9s":515,"f0lyww":520,"15niznk":525,"ujz8cg":530,"1l6w934":535,"8cvpq8":540,"18ze48w":545,"ich3i8":550,"1v6hmv4":555,"boqubk":560,"12bnv28":565,"xvucxs":570,"1oirdog":575,"1569s0":580,"1dz6t4w":585,"nc9se8":590,"1tik2kg":595,"gojj7k":600,"17bgjy8":605,"qo4wzk":610,"1hb1xq8":615,"4h1edc":620,"1anbojk":625,"k0ensw":630,"1wuf75s":635,"aus268":640,"11hp2ww":645,"x1vksg":650,"1noslj4":655,"471szk":660,"1h12ccg":665,"qe5bls":670,"1r0nq4g":675,"e6n6rk":680,"14tk7i8":685,"tq0g74":690,"1kcxgxs":695,"7iwxkw":700,"19tcwe8":705,"j6fvnk":710,"1w0gf0g":715,"cipmgw":720,"135mn7k":725,"ypt534":730,"1pcq5ts":735,"b7hmo":740,"1d580zk":745,"mib08w":750,"1solaf4":755,"fukr28":760,"16hhrsw":765,"sh29z4":770,"1j3zaps":775,"69yrcw":780,"1cg91j4":785,"ltc0sg":790,"1ynck5c":795,"9ltvy8":800}},{"max":2000,"increment":50,"cpms":{"u4zu9s":850,"244um8":900,"kzd8n4":950,"drnsow":1000,"z3jkzk":1050,"5oqmf4":1100,"ojz0g0":1150,"c2ha80":1200,"r1vcw0":1250,"45sutc":1300,"j56xhc":1350,"ftbsw0":1400,"w6nugw":1450,"8bmrk0":1500,"nxhxc0":1550,"a22874":1600,"sxam80":1650,"wfmkg":1700,"lflkw0":1750,"f6ups0":1800,"y233sw":1850,"4na58g":1900,"qke2gw":1950,"coydc0":2000}},{"max":3500,"increment":100,"cpms":{"2uz9c0":2100,"hkdqm8":2200,"70t62o":2300,"93q4g0":2400,"1m1340":2500,"dw14ao":2600,"6ec2yo":2700,"be4ruo":2800,"3hgcg0":2900,"gix9fk":3000,"8g035s":3100,"axwfls":3200,"ebv28":3300,"eoqy9s":3400,"5j4cn4":3500}}]},"L":{"z":[{"max":2000,"increment":25,"cpms":{"v_1gtknb4":25,"v_tiir5s":50,"v_1vsypz4":75,"v_3pslc":100,"v_16a02rk":125,"v_m0tpts":150,"v_1mnc4cg":175,"v_et49vk":200,"v_18rwf7k":225,"v_xocnwg":250,"v_1ua0ydc":275,"v_58ia68":300,"v_10v7zsw":325,"v_pro8hs":350,"v_1jqgdts":375,"v_da6i9s":400,"v_1dwowsg":425,"v_s9kkxs":450,"v_1yfuv40":475,"v_2qlxq8":500,"v_15niznk":525,"v_ich3i8":550,"v_1oirdog":575,"v_gojj7k":600,"v_1anbojk":625,"v_x1vksg":650,"v_1r0nq4g":675,"v_7iwxkw":700,"v_135mn7k":725,"v_mib08w":750,"v_1j3zaps":775,"v_9ltvy8":800,"v_1fs464g":825,"v_u4zu9s":850,"v_1uri8sg":875,"v_244um8":900,"v_18af4sg":925,"v_kzd8n4":950,"v_1n9t7gg":975,"v_drnsow":1000,"v_1a73cao":1025,"v_z3jkzk":1050,"v_1t2bqbk":1075,"v_5oqmf4":1100,"v_znirr4":1125,"v_ojz0g0":1150,"v_1lkmozk":1175,"v_c2ha80":1200,"v_1ecx91c":1225,"v_r1vcw0":1250,"v_1x85n28":1275,"v_45sutc":1300,"v_14sb9c0":1325,"v_j56xhc":1350,"v_1pbh7nk":1375,"v_ftbsw0":1400,"v_1ctzhfk":1425,"v_w6nugw":1450,"v_1rtdk3k":1475,"v_8bmrk0":1500,"v_12aeww0":1525,"v_nxhxc0":1550,"v_1hwa2o0":1575,"v_a22874":1600,"v_1g8cidc":1625,"v_sxam80":1650,"v_1wlojy8":1675,"v_wfmkg":1700,"v_172pwqo":1725,"v_lflkw0":1750,"v_1m23zeo":1775,"v_f6ups0":1800,"v_195mv40":1825,"v_y233sw":1850,"v_1tostfk":1875,"v_4na58g":1900,"v_11nxts0":1925,"v_qke2gw":1950,"v_1kj67sw":1975,"v_coydc0":2000}},{"max":3000,"increment":50,"cpms":{"v_sdxwjk":2050,"v_2uz9c0":2100,"v_hudc00":2150,"v_hkdqm8":2200,"v_wjrta8":2250,"v_70t62o":2300,"v_mz5tkw":2350,"v_93q4g0":2400,"v_v0u1og":2450,"v_1m1340":2500,"v_kh9h4w":2550,"v_dw14ao":2600,"v_yf72m8":2650,"v_6ec2yo":2700,"v_p9kgzk":2750,"v_be4ruo":2800,"v_rchfcw":2850,"v_3hgcg0":2900,"v_juse0w":2950,"v_gix9fk":3000}},{"max":5000,"increment":100,"cpms":{"v_8g035s":3100,"v_axwfls":3200,"v_ebv28":3300,"v_eoqy9s":3400,"v_5j4cn4":3500,"v_ctboxs":3600,"v_29r4e8":3700,"v_gz5log":3800,"v_7ejlz4":3900,"v_9wfyf4":4000,"v_1rc4cg":4100,"v_dev2f4":4200,"v_5x6134":4300,"v_bvxatc":4400,"v_4e89hc":4500,"v_g1r7k0":4600,"v_7slaf4":4700,"v_aahmv4":4800,"v_pvn5s":4900,"v_ffa4g0":5000}}]}}'
  );
  function jf(e, t, n) {
    const r = e.filter((e) => e.max > 0).sort((e, t) => e.max - t.max),
      i = [];
    for (let e = 0; e < r.length; e++) {
      const o = r[e],
        s = 0 === e ? 0 : r[e - 1].max,
        a = o.max;
      for (let e = s; e < a; ) {
        let r = e + o.increment;
        n || (r = Yf(new Bf(r, t, n)).asUnits(t)),
          i.push({ min: e, max: Math.min(r, a), increment: o.increment }),
          (e = r);
      }
    }
    return { buckets: i, currency: t, cents: n };
  }
  function Df(e, t) {
    for (let n = 0; n < t.buckets.length; n++) {
      const r = t.buckets[n];
      if (e.isLt(new Bf(r.max, t.currency, t.cents))) return r.increment;
    }
    return t.buckets[t.buckets.length - 1].increment;
  }
  function Vf(e, t) {
    const n = new Bf(Df(e, t), t.currency, t.cents).asCents(e.currency),
      r = Math.floor(e.asCents(e.currency));
    return new Bf(r - (r % n), e.currency, !0);
  }
  const Gf = Lf._.z,
    $f = Lf.L.z,
    qf = jf(Gf, "USD", !0),
    Zf = jf($f, "USD", !0);
  function Kf(e) {
    const t = e.amznbid;
    for (const e of Gf) {
      const n = e.cpms[t];
      if (Rn(n)) return new Bf(n, "USD", !0);
    }
    for (const e of $f) {
      const n = e.cpms[t];
      if (Rn(n)) return new Bf(n, "USD", !0);
    }
    return (
      Zn.warn(
        `[apstag] Received an amazon bid with an encoded cpm (${t}) which is unknown. Will pretend the cpm is 0 for the bid`
      ),
      new Bf(0, "USD", !0)
    );
  }
  function Hf(e, t) {
    return Yf(Kf(e).createCopyWithAdjustedAmount((e) => e * (1 - t)));
  }
  function Wf(e, t) {
    return (function (e, t) {
      if (
        ((e =
          e.currency === t.currency
            ? e
            : new Bf(e.asCents(t.currency), t.currency, !0)),
        t.buckets.length > 0)
      ) {
        const n = new Bf(
          t.buckets[t.buckets.length - 1].max,
          t.currency,
          t.cents
        );
        if (e.isGte(n)) return n;
      }
      const n = Vf(e, t);
      if (n.isEq(e)) return e;
      const r = Df(e, t);
      return new Bf(
        (t.cents ? n.asCents(t.currency) : n.asUnits(t.currency)) + r,
        t.currency,
        t.cents
      );
    })(e, t ? Zf : qf);
  }
  function Jf(e) {
    const t = e.amazonAdapted.asCents("USD");
    return { currency: "USD", value: Math.floor(t) };
  }
  function Yf(e) {
    return e.createCopyWithAdjustedAmount((e) => Math.round(e));
  }
  function Qf(e) {
    return (
      "" === e.amzniid &&
      "2" === e.amznbid &&
      "2" === e.amznp &&
      "0x0" === e.amznsz
    );
  }
  const Xf = [
      { max: 10, increment: 0.01 },
      { max: 50, increment: 0.5 },
      { max: 100, increment: 1 },
    ],
    eh = [
      { max: 20, increment: 0.05 },
      { max: 50, increment: 0.1 },
      { max: 100, increment: 1 },
    ];
  const th = jf(Xf, "EUR", !1),
    nh = jf(eh, "EUR", !1);
  function rh(e, t) {
    return (n) => ({
      precision: 2,
      max: new Bf(n.max, e, t).asUnits("EUR"),
      increment: new Bf(n.increment, e, t).asUnits("EUR"),
    });
  }
  const ih = Xf.map(rh(th.currency, th.cents)),
    oh = eh.map(rh(nh.currency, nh.cents));
  function sh(e, t) {
    const n = Hf(e, $i.getBidderDiscrepancyForSession("amazon", t));
    return { cpm: n, lineItemValue: n };
  }
  function ah(e, t) {
    const { cpm: n, currency: r } = e,
      i = new Bf(n, Pf(r) ? r : "USD", !1),
      o = "video" === t ? nh : th,
      s = Vf(i.convertTo(o.currency), o);
    return { cpm: i, lineItemValue: s };
  }
  function ch(e, t) {
    const { cpm: n, currency: r, ...i } = e;
    return { ...i, ...ah(e, t) };
  }
  function dh(e) {
    return new Bf(e, "EUR", !1);
  }
  function uh(e) {
    return e.asUnits("EUR");
  }
  class lh {
    static getInstance() {
      return this.instance || (this.instance = new lh()), this.instance;
    }
    blocklist = null;
    loadingPromise = null;
    constructor() {}
    async filterBidResponses(e, t) {
      await this.loadBlocklist(),
        Rn(this.blocklist) &&
          Rn(t) &&
          Object.entries(t).forEach((t) => {
            let [n, r] = t;
            r.forEach((t) => {
              this.isBidBlocked(t) &&
                (Zn.debug("blocking bid", t),
                e.markWinningBidAsUsed({ adId: t.adId }));
            });
          });
    }
    isDomainBlocked(e) {
      if (!Rn(this.blocklist)) return !1;
      const { names: t, domains: n } = this.blocklist,
        r = e.split(".");
      if (
        n.some((e) => {
          if (r.length < e.length) return !1;
          const t = r.length - e.length;
          return e.every((e, n) => r[n + t] === e);
        })
      )
        return !0;
      return t.some(
        (e) => !(r.length < e.length) && e.every((e, t) => r[t] === e)
      );
    }
    loadBlocklist() {
      return Rn(this.blocklist)
        ? Promise.resolve()
        : (Rn(this.loadingPromise) ||
            (this.loadingPromise = new Promise((e) => {
              n.e(424)
                .then(() => n.t(424, 17))
                .then((t) => {
                  const { names: n, domains: r } = t.default;
                  (this.blocklist = {
                    names: n.map((e) => e.split(".")),
                    domains: r.map((e) => e.split(".")),
                  }),
                    (this.loadingPromise = null),
                    e();
                })
                .catch((t) => {
                  Zn.error("error loading blocklist", t),
                    (this.loadingPromise = null),
                    e();
                });
            })),
          this.loadingPromise);
    }
    isBidBlocked(e) {
      const { advertiserDomains: t } = e.meta || {};
      return !!Rn(t) && t.some((e) => this.isDomainBlocked(e));
    }
  }
  const ph = lh;
  class fh {
    constructor(e) {
      (this.auctioneers = e),
        (this.state = e.reduce(
          (e, t) => Object.assign({}, e, { [t]: null }),
          {}
        ));
    }
    setAuctioneerFinished(e) {
      this.auctioneers.indexOf(e) < 0 &&
        (qn.warn(`[RequestManager] Unexpected auctioneer ${e}`),
        this.auctioneers.push(e)),
        (this.state[e] = Date.now());
    }
    haveBiddersFinished() {
      return this.auctioneers.every((e) => Rn(this.state[e]));
    }
  }
  let hh = (function (e) {
      return (
        (e[(e.VAST1 = 1)] = "VAST1"),
        (e[(e.VAST2 = 2)] = "VAST2"),
        (e[(e.VAST3 = 3)] = "VAST3"),
        (e[(e.VAST1Wrapper = 4)] = "VAST1Wrapper"),
        (e[(e.VAST2Wrapper = 5)] = "VAST2Wrapper"),
        (e[(e.VAST3Wrapper = 6)] = "VAST3Wrapper"),
        (e[(e.VAST4 = 7)] = "VAST4"),
        (e[(e.VAST4Wrapper = 8)] = "VAST4Wrapper"),
        (e[(e.DAAST1 = 9)] = "DAAST1"),
        (e[(e.DAAST1Wrapper = 10)] = "DAAST1Wrapper"),
        (e[(e.VAST4_1 = 11)] = "VAST4_1"),
        (e[(e.VAST4_1Wrapper = 12)] = "VAST4_1Wrapper"),
        (e[(e.VAST4_2 = 13)] = "VAST4_2"),
        (e[(e.VAST4_2Wrapper = 14)] = "VAST4_2Wrapper"),
        e
      );
    })({}),
    mh = (function (e) {
      return (
        (e[(e.VPAID1 = 1)] = "VPAID1"),
        (e[(e.VPAID2 = 2)] = "VPAID2"),
        (e[(e.MRAID1 = 3)] = "MRAID1"),
        (e[(e.ORMAA = 4)] = "ORMAA"),
        (e[(e.MRAID2 = 5)] = "MRAID2"),
        (e[(e.MRAID3 = 6)] = "MRAID3"),
        (e[(e.OMID_1_0 = 7)] = "OMID_1_0"),
        (e[(e.SIMID_1_0 = 8)] = "SIMID_1_0"),
        (e[(e.SIMID_1_1 = 9)] = "SIMID_1_1"),
        e
      );
    })({}),
    gh = (function (e) {
      return (
        (e[(e.INSTREAM = 1)] = "INSTREAM"),
        (e[(e.OUTSTREAM = 2)] = "OUTSTREAM"),
        e
      );
    })({}),
    bh = (function (e) {
      return (
        (e[(e.INSTREAM = 1)] = "INSTREAM"),
        (e[(e.INTERSTITIAL = 5)] = "INTERSTITIAL"),
        e
      );
    })({}),
    vh = (function (e) {
      return (
        (e[(e.INSTREAM = 1)] = "INSTREAM"),
        (e[(e.INTERSTITIAL = 3)] = "INTERSTITIAL"),
        e
      );
    })({}),
    yh = (function (e) {
      return (e[(e.INSTREAM = 1)] = "INSTREAM"), e;
    })({}),
    Ah = (function (e) {
      return (e[(e.CLICK_WITH_SOUND = 3)] = "CLICK_WITH_SOUND"), e;
    })({});
  const Ch = jf(
      [
        { max: 2, increment: 0.01 },
        { max: 10, increment: 0.05 },
        { max: 20, increment: 0.1 },
        { max: 50, increment: 1 },
      ],
      "EUR",
      !1
    ),
    wh = new Bf(Ch.buckets[Ch.buckets.length - 1].max, Ch.currency, Ch.cents);
  function Sh(e) {
    return e.asUnits("EUR").toFixed(2);
  }
  function Ih(e) {
    let t = Vf(e.convertTo(Ch.currency), Ch);
    return t.isGte(wh) && (t = wh), t;
  }
  function _h(e) {
    if (Rn(e.prebidBid)) {
      const t = Ih(
        e.prebidBid.lineItemValue.createCopyWithAdjustedAmount(
          (e) =>
            e *
            (function () {
              switch (jp("czyExpClientAdXFloor_1_CZY_20844")) {
                case "1":
                  return 1;
                case "1.1":
                  return 1.1;
                case "1.2":
                  return 1.2;
                case "1.3":
                  return 1.3;
              }
            })()
        )
      );
      return { floor: t, minimumExpectedPayment: Ph(t, e) };
    }
    const t = Ih(e.configuredFloor);
    return { floor: t, minimumExpectedPayment: Ph(t, e) };
  }
  function kh(e, t) {
    return Wf(
      e.createCopyWithAdjustedAmount(
        (e) => e / (1 - $i.getBidderDiscrepancyForSession("amazon", t))
      ),
      "video" === t
    );
  }
  function Ph(e, t) {
    return {
      google: e,
      amazon: t.amazonBid?.lineItemValue,
      prebid: t.prebidBid?.lineItemValue,
    };
  }
  const Bh = class {
    minimumExpectedPayment = null;
    bidCacheHealth = null;
    apstagSlotIds = [];
    constructor() {
      (this.adsenseIncludedInAuction = !1),
        (this.hasAdsenseRendered = !1),
        (this.requestPriceFloor = null),
        (this.googlePriceFloor = null),
        (this.minimumExpectedPayment = null),
        (this.bidCacheHealth = null),
        (this.prebidBidRequests = []);
    }
    isBanner() {
      return this.unit.isBanner();
    }
    isVideo() {
      return this.unit.isVideo();
    }
    setAdsenseIncludedInAuction() {
      this.adsenseIncludedInAuction = !0;
    }
    isAdsenseIncludedInAuction() {
      return this.adsenseIncludedInAuction;
    }
    setAdsenseRendered() {
      this.hasAdsenseRendered = !0;
    }
    hasAdsenseBidRendered() {
      return this.adsenseIncludedInAuction && this.hasAdsenseRendered;
    }
    resetPriceFloorsAndBids() {
      (this.requestPriceFloor = null),
        (this.googlePriceFloor = null),
        (this.minimumExpectedPayment = null),
        (this.bidCacheHealth = null),
        (this.prebidBidRequests = []),
        this.removeApstagSlots();
    }
    snapshotBidCacheHealth() {
      const e = this.getCachedBidCpmsForPriceFloor();
      (this.bidCacheHealth = {
        bids: e.length,
        highestCpm: e.length > 0 ? xf(e, Ef()) : null,
        medianCpm: Tf(e),
      }),
        Zn.debug(
          `[Bids] ${this.unit.code()} snapshotBidCacheHealth`,
          this.bidCacheHealth
        );
    }
    getBidCacheHealth() {
      return this.bidCacheHealth;
    }
    getBidCacheGamKeyValues() {
      const e = this.bidCacheHealth,
        t = (e) => (Rn(e) ? Sh(Ih(e)) : null);
      return {
        [rr]: t(e?.highestCpm),
        [ir]: t(e?.medianCpm),
        [or]: Rn(e) ? ((n = e.bids), Math.min(n, 64).toString()) : null,
      };
      var n;
    }
    getMinimumExpectedPaymentInformation() {
      return Rn(this.minimumExpectedPayment)
        ? this.minimumExpectedPayment
        : { google: Ef(), prebid: Ef(), amazon: Ef() };
    }
    getMinPricePaidForUnit(e, t, n) {
      if (e || t || !Rn(this.minimumExpectedPayment)) return Ef();
      var r;
      switch (
        Rn((r = n))
          ? r === Ar
            ? "amazon"
            : Object.values(yr).includes(r)
            ? "prebid"
            : "google"
          : "unknown"
      ) {
        case "prebid":
          return this.minimumExpectedPayment.prebid ?? Ef();
        case "amazon":
          return this.minimumExpectedPayment.amazon ?? Ef();
        case "google":
          return this.minimumExpectedPayment.google ?? Ef();
        case "unknown":
          return Ef();
      }
    }
    addPrebidBidRequest(e) {
      this.prebidBidRequests.push(e);
    }
    getBidRequestsForPrebid() {
      return this.prebidBidRequests;
    }
    getPrebidUnits() {
      if (0 === this.prebidBidRequests.length) return [];
      return [this.toPrebidUnit()];
    }
    toPrebidUnit() {
      const e = this.getPrebidPriceFloorObject(this.getRequestPriceFloor()),
        t = this.unit.code(),
        n = { ...this.unit.requestUnit.adUnit, code: t },
        r = { ext: { gpid: this.unit.requestUnit.slotId } };
      Gh(this.unit)
        ? "rewarded" === this.unit.requestUnit.video.videoType && (r.rwdd = 1)
        : (r.banner = { battr: [3, 6, 7] });
      return {
        ...n,
        bids: this.getBidRequestsForPrebid(),
        floors: e,
        ortb2Imp: r,
      };
    }
    currentWinningPrebidBidResponse() {
      const e = this.getHighestPrebidBidResponses();
      return 0 === e.length
        ? null
        : (function (e, t) {
            const n = Nf(e, "HIGH_TO_LOW");
            return t.reduce((e, t) => (n(e, t) < 0 ? e : t));
          })((e) => e.cpm, e);
    }
    getHighestPrebidBidResponses() {
      const e = On();
      return Rn(e)
        ? e
            .getHighestCpmBids(this.unit.code())
            .map((e) => ch(e, this.unit.getAdFormat()))
        : [];
    }
    getCachedPrebidBidResponses(e) {
      const t = On();
      if (!Rn(t)) return [];
      const n = Date.now() + 1e3 * e;
      return this.unit
        .getAllCodes()
        .flatMap((e) => t.getBidResponsesForAdUnitCode(e).bids)
        .filter((e) => !Rn(e.status) || "rendered" !== e.status)
        .filter(
          (e) =>
            Rn(e.responseTimestamp) &&
            Rn(e.ttl) &&
            e.responseTimestamp + 1e3 * e.ttl > n
        )
        .map((e) => ch(e, this.unit.getAdFormat()));
    }
    getRequestPriceFloor() {
      if (Rn(this.requestPriceFloor)) return this.requestPriceFloor;
      const e = this.computeConfiguredPriceFloor(),
        t = this.computeBidBasedPriceFloor();
      let n;
      var r, i;
      return (
        (n = Rn(t) ? xf([e, t], Ef()) : e),
        (this.requestPriceFloor =
          ((r = n),
          (i = this.unit.getAdFormat()),
          { exact: r, prebidAdapted: r, amazonAdapted: kh(r, i) })),
        this.requestPriceFloor
      );
    }
    getPrebidPriceFloorObject(e) {
      const t = e.prebidAdapted,
        n = t.currency,
        r = t.asUnits(n);
      return {
        currency: n,
        default: r,
        schema: { fields: ["mediaType"] },
        values: { [this.isBanner() ? "banner" : "video"]: r },
      };
    }
    processAmazonBidResponse(e) {
      return (function (e, t) {
        return Kf(e).isGte(t);
      })(e, this.getRequestPriceFloor().amazonAdapted)
        ? { ...e, ...sh(e, this.unit.getAdFormat()) }
        : null;
    }
    getGooglePriceFloor() {
      return this.googlePriceFloor;
    }
    calculateAndStoreGooglePriceFloor() {
      if (Rn(this.googlePriceFloor))
        return (
          Zn.error(
            "The Google price floor was already calculated for this ad request. There should be no need to calculate it a second time"
          ),
          this.googlePriceFloor
        );
      const e = {
          prebidBid: this.currentWinningPrebidBidResponse(),
          amazonBid: this.getAmazonBidResponse(),
          configuredFloor: this.computeConfiguredPriceFloor(),
        },
        { floor: t, minimumExpectedPayment: n } = _h(e);
      return (
        (this.googlePriceFloor = t),
        (this.minimumExpectedPayment = n),
        this.googlePriceFloor
      );
    }
    setGooglePriceFloorForTesting(e) {
      throw new Error("This method should only be used during tests");
    }
    calculateAndStoreGooglePriceFloorForTesting() {
      throw new Error("This method should only be used during tests");
    }
    computeBidBasedPriceFloor() {
      const e = jp("czyExpClientBidBasedPriceFloor_CZY_21335");
      if ("disabled" === e) return null;
      const t = Nf((e) => e, "HIGH_TO_LOW"),
        n = this.getCachedBidCpmsForPriceFloor().sort(t),
        r = "highest" === e ? 0 : 1;
      if (n.length <= r)
        return (
          Zn.debug(
            `[Bids] computeBidBasedPriceFloor: ${e} variant, but only ${n.length} cached bids`
          ),
          null
        );
      const i = n[r].createCopyWithAdjustedAmount((e) => e - 1);
      return (
        Zn.debug(
          `[Bids] computeBidBasedPriceFloor: ${e} variant - cached bids & selected floor`,
          n,
          i
        ),
        i
      );
    }
    getCachedBidCpmsForPriceFloor() {
      return [
        ...this.getCachedPrebidBidResponses(
          gp.bidBasedPriceFloorMinSecondsToLive
        ).map((e) => e.cpm),
        ...this.getCachedAmazonBidResponses(
          gp.bidBasedPriceFloorMinSecondsToLive
        ).map((e) => e.cpm),
      ];
    }
    computeConfiguredPriceFloor() {
      const e = this.computeConfiguredPriceFloorWithoutRequestMultiplier(),
        t = this.unit.requestOptions.priceFloorMultiplier;
      return Rn(t) && 1 !== t
        ? (Zn.debug(
            "[Bids] computeConfiguredPriceFloor: applying the price floor multiplier of the request",
            t
          ),
          e.createCopyWithAdjustedAmount((e) => t * e))
        : e;
    }
    computeConfiguredPriceFloorWithoutRequestMultiplier() {
      const e = this.unit.getAdType(),
        t = dh(dp.getFloorForSession(e));
      return (
        Zn.debug(
          "[Bids] computeConfiguredPriceFloor final floor in EUR for adtype using factor",
          e,
          t
        ),
        t
      );
    }
  };
  function Eh(e) {
    return br.includes(e);
  }
  function xh(e) {
    const t = [],
      { video: n, native: r, banner: i } = e.mediaTypes;
    if (
      (Rn(n) &&
        Rn(n.playerSize) &&
        n.playerSize.length > 0 &&
        t.push(...Th(n.playerSize)),
      Rn(r) && Rn(r.image))
    ) {
      const e = r.image.sizes;
      Rn(e) && t.push(...Th(e));
    }
    if (Rn(i)) {
      const e = i.sizes;
      Rn(e) && t.push(...Th(e));
    }
    return t;
  }
  function Th(e) {
    return Rn(e)
      ? (function (e) {
          return "number" == typeof e[0];
        })(e)
        ? [e]
        : e
      : [];
  }
  const Rh = (e) =>
    e.some((e) =>
      (function (e) {
        return vr.some((t) => t === e);
      })(e)
    );
  class zh {
    disabledPrebidBidders = (() => new Map())();
    disabledAmazonPartners = (() => new Map())();
    constructor(e, t, n) {
      (this.allowedErrorsWithoutGettingBlacklisted = n),
        (this.disableFailingPrebidBidders = e),
        (this.disableFailingAmazonPartners = t);
    }
    getAdditionalGAMKeyValuePairs() {
      return {
        [Kn]: this.disableFailingPrebidBidders
          ? `${this.disabledPrebidBidders.size}`
          : void 0,
        [Hn]: this.disableFailingAmazonPartners
          ? `${this.disabledAmazonPartners.size}`
          : void 0,
      };
    }
    isBidderBlacklisted(e) {
      return this._isPrebidBidderCodeBlacklisted(e.code);
    }
    _isPrebidBidderCodeBlacklisted(e) {
      const t = this.disabledPrebidBidders.get(e);
      return this.isBlacklisted(t);
    }
    isAmazonBidBlacklisted(e) {
      const t = this.extractAmazonPartner(e);
      return Rn(t) && this._isAmazonPartnerBlacklisted(t);
    }
    _isAmazonPartnerBlacklisted(e) {
      const t = this.disabledAmazonPartners.get(e);
      return this.isBlacklisted(t);
    }
    isBlacklisted(e) {
      return Rn(e) && e > this.allowedErrorsWithoutGettingBlacklisted;
    }
    asBlacklistedAmazonPartnerFilter() {
      return (e) => !this.disabledAmazonPartners.has(e);
    }
    createOnVideoPlayedCallback(e, t) {
      return (n) => {
        const r = Mh(
          {
            prebid: Rn(e.prebid)
              ? {
                  adId: e.prebid.adId,
                  bidderCode: e.prebid.bidderCode,
                  lineItemValue: e.prebid.lineItemValue,
                }
              : void 0,
            amazon: Rn(e.amazon)
              ? {
                  amzniid: e.amazon.amzniid,
                  amznp: this.extractAmazonPartner(e.amazon),
                  lineItemValue: e.amazon.lineItemValue,
                }
              : void 0,
          },
          { usedCreatives: n.creativeIds, error: n.forceMarkAsUsed ?? !1 }
        );
        this._handleVideoUsageInformation(r, t);
      };
    }
    _handleVideoUsageInformation(e, t) {
      Rn(e.prebid) &&
        (e.prebid.addToBlacklist
          ? this.handlePrebidBidError(e.prebid.adId, e.prebid.bidderCode)
          : e.prebid.used &&
            (this.markPrebidBidAsUsed(e.prebid.adId),
            this.handlePrebidBidSuccess(e.prebid.bidderCode))),
        Rn(e.amazon) &&
          (e.amazon.addToBlacklist
            ? this.handleAmazonBidError(
                t.code,
                e.amazon.amzniid,
                e.amazon.amznp
              )
            : e.amazon.used &&
              (this.markAmazonBidAsUsed(e.amazon.amzniid),
              this.handleAmazonBidSuccess(e.amazon.amznp)));
    }
    markPrebidBidAsUsed(e) {
      try {
        Zn.debug(
          "[CrazyAds] Marking winning Prebid video as used through the ad id ",
          e
        );
        Fn().markWinningBidAsUsed({ adId: e });
      } catch (t) {
        Zn.error(
          t,
          "[CrazyAds] Failed to mark winning video bid as used through the ad id",
          e
        );
      }
    }
    markAmazonBidAsUsed(e) {}
    handlePrebidBidSuccess(e) {
      if (
        this.disableFailingPrebidBidders &&
        this.disabledPrebidBidders.has(e)
      ) {
        this.disabledPrebidBidders.delete(e) &&
          Zn.debug(
            `[CrazyAds] Resetting the error count for prebid bidder ${e} since the bidder served a successful ad`
          );
      }
    }
    handlePrebidBidError(e, t) {
      if (this.disableFailingPrebidBidders) {
        if (
          (Zn.debug(
            `[CrazyAds] Incrementing the error count of prebid bidder ${t} for video ads since the ad threw an error on ad with id ${e}`
          ),
          this.disabledPrebidBidders.set(
            t,
            (this.disabledPrebidBidders.get(t) ?? 0) + 1
          ),
          this._isPrebidBidderCodeBlacklisted(t))
        ) {
          Zn.debug(
            `[CrazyAds] Disabling prebid bidder ${t} for video ads since it threw too many errors`
          );
          const n = Fn(),
            r = n.adUnits
              .filter((e) => Rn(e.mediaTypes?.video))
              .map((e) => e.code);
          for (const i of r) {
            const r = n.getBidResponsesForAdUnitCode(i).bids;
            for (const o of r)
              o.bidderCode === t &&
                (Zn.debug(
                  `[CrazyAds] Marking video bid of bidder ${o.bidderCode} as used on ad unit ${i} because the video failed when running the ad with id ${e}`
                ),
                n.markWinningBidAsUsed({ adId: o.adId }));
          }
        }
      } else this.markPrebidBidAsUsed(e);
    }
    handleAmazonBidSuccess(e) {
      if (Rn(e)) {
        if (
          this.disableFailingAmazonPartners &&
          this.disabledAmazonPartners.has(e)
        ) {
          this.disabledAmazonPartners.delete(e) &&
            Zn.debug(
              `[CrazyAds] Resetting the error count for amazon partner ${e} since the partner served a successful ad`
            );
        }
      } else
        Zn.warn(
          "[CrazyAds] Cannot reset the error count for amazon partner with successful video ad because the amazon partner is unknown"
        );
    }
    handleAmazonBidError(e, t, n) {
      Rn(n)
        ? (this.disableFailingAmazonPartners &&
            (Zn.debug(
              `[CrazyAds] Incrementing the error count of amazon partner ${n} for video ads since the ad ${t} threw an error`
            ),
            this.disabledAmazonPartners.set(
              n,
              (this.disabledAmazonPartners.get(n) ?? 0) + 1
            ),
            this._isAmazonPartnerBlacklisted(n) &&
              Zn.debug(
                `[CrazyAds] Disabling amazon partner ${n} for video ads since it threw too many errors`
              )),
          Zn.debug(
            `[CrazyAds] Marking video bid ${t} of partner ${n} as used because there was an error`
          ),
          this.markAmazonBidAsUsed(t))
        : Zn.warn(
            "[CrazyAds] Cannot disable amazon partner with failing video ad because the amazon partner is unknown"
          );
    }
    reset() {
      this.disabledAmazonPartners.clear(), this.disabledPrebidBidders.clear();
    }
    extractAmazonPartner(e) {
      return e.amznp;
    }
  }
  function Mh(e, t) {
    const n = {
      prebid: Rn(e.prebid)
        ? {
            bidderCode: e.prebid.bidderCode,
            used: !1,
            addToBlacklist: !1,
            adId: e.prebid.adId,
          }
        : void 0,
      amazon: Rn(e.amazon)
        ? {
            amzniid: e.amazon.amzniid,
            amznp: e.amazon.amznp,
            used: !1,
            addToBlacklist: !1,
          }
        : void 0,
    };
    let r;
    let i;
    if (
      (Rn(e.prebid) && t.usedCreatives.some((e) => Eh(e))
        ? ((r = "prebid"), Rn(n.prebid) && (n.prebid.used = !0))
        : Rn(e.amazon) && Rh(t.usedCreatives)
        ? ((r = "amazon"), Rn(n.amazon) && (n.amazon.used = !0))
        : (r = "unknown"),
      Rn(e.prebid) && Rn(e.amazon))
    ) {
      const t = e.prebid.lineItemValue,
        n = e.amazon.lineItemValue;
      i = t.isGt(n) ? "prebid" : n.isGt(t) ? "amazon" : "unknown";
    } else i = Rn(e.prebid) ? "prebid" : Rn(e.amazon) ? "amazon" : "unknown";
    let o = "unknown";
    switch (
      ("unknown" !== i && "unknown" !== r && i !== r
        ? (o = i)
        : t.error && (o = "unknown" !== r ? r : i),
      o)
    ) {
      case "prebid":
        Rn(n.prebid) && (n.prebid.addToBlacklist = !0);
        break;
      case "amazon":
        Rn(n.amazon) && (n.amazon.addToBlacklist = !0);
    }
    return n;
  }
  const Oh = new zh(!0, !1, mp.general.bidderPlaybackErrorsBeforeBlacklist);
  function Fh() {
    const e = {};
    for (var t = arguments.length, n = new Array(t), r = 0; r < t; r++)
      n[r] = arguments[r];
    for (const t of n)
      for (const n in t) {
        const r = t[n];
        Rn(r) && (e[n] = r);
      }
    return e;
  }
  function Uh(e) {
    const t = {};
    for (const n in e) {
      const r = e[n];
      Rn(r) && (t[n] = Array.isArray(r) ? r.join(",") : `${r}`);
    }
    return t;
  }
  const Nh = class extends Bh {
      apstagSlots = [];
      constructor(e) {
        super(),
          (this.unit = e),
          (this.prebidBidRequests = []),
          (this.amazonBidResponse = null);
      }
      resetPriceFloorsAndBids() {
        super.resetPriceFloorsAndBids(), (this.amazonBidResponse = null);
      }
      getPrebidUnits() {
        const { placements: e } = this.unit.requestUnit.video;
        e || Zn.error("[VideoUnit] should have placements");
        const t = [];
        return (
          Object.keys(e).forEach((e) => {
            this.unit.setCurrentPlacement(e);
            const n = this.toPrebidUnit();
            t.push(n);
          }),
          this.unit.setCurrentPlacement(null),
          t
        );
      }
      getBidRequestsForPrebid() {
        return this.prebidBidRequests
          .filter((e) => e.placement === this.unit.getCurrentPlacement())
          .map((e) => {
            let { placement: t, ...n } = e;
            return n;
          });
      }
      getHighestPrebidBidResponses() {
        if (ji(this.unit.getCurrentPlacement()))
          return super.getHighestPrebidBidResponses();
        {
          const { placements: e } = this.unit.requestUnit.video,
            t = Object.keys(e).reduce((e, t) => {
              this.unit.setCurrentPlacement(t);
              const n = super.getHighestPrebidBidResponses();
              return e.concat(n);
            }, []);
          return this.unit.setCurrentPlacement(null), t;
        }
      }
      toPrebidUnit() {
        const e = super.toPrebidUnit(),
          { mediaTypes: t } = e,
          { placements: n } = this.unit.requestUnit.video,
          r = this.unit.openRTB(n[this.unit.getCurrentPlacement()], !1),
          i = t.video,
          o = Object.assign({}, i || {}, r),
          s = Object.assign({}, t, { video: o });
        return { ...e, mediaTypes: s };
      }
      getAmazonBidResponse() {
        return this.amazonBidResponse;
      }
      getCachedAmazonBidResponses(e) {
        return Rn(this.amazonBidResponse) ? [this.amazonBidResponse] : [];
      }
      setAmazonBidResponse(e) {
        const t = e.filter((e) => !Oh.isAmazonBidBlacklisted(e));
        if (0 === t.length) return;
        const n = t.filter((e) => e.cpm.isGreaterThanZero());
        if (0 === n.length) return;
        const r = n.reduce((e, t) => (e.cpm.isGte(t.cpm) ? e : t), n[0]);
        r.cpm.isGreaterThanZero() &&
          ((Rn(this.amazonBidResponse) &&
            !this.amazonBidResponse.cpm.isLt(r.cpm)) ||
            (this.amazonBidResponse = r));
      }
      getApstagSlots() {
        return this.apstagSlots;
      }
      setApstagSlots() {
        this.apstagSlots.forEach((e) => {
          const t = this.getRequestPriceFloor();
          e.floor = Jf(t);
        });
      }
      addApstagSlot(e) {
        this.apstagSlotIds.push(e),
          this.apstagSlots.push({
            slotID: e,
            mediaType: "video",
            sizes: this.unit.getSizes(),
          });
      }
      removeApstagSlots() {
        (this.apstagSlots = []), (this.apstagSlotIds = []);
      }
      getPrebidAmazonBids() {
        const e = this.getCurrentWinningPrebidBids(),
          t = this.getAmazonBidResponse();
        return Rn(t) ? { amazon: t, prebid: e } : { prebid: e };
      }
      getCurrentWinningPrebidBids() {
        try {
          return this.getHighestPrebidBidResponses();
        } catch (e) {
          return Zn.error(e), [];
        }
      }
      setGoogleVideoBidRequest(e, t) {
        const n = t ? "skippableMaxDuration" : "nonSkippableMaxDuration",
          r = this.googleBid?.[n],
          { maxDuration: i, ...o } = e;
        this.googleBid = {
          ...this.googleBid,
          ...o,
          [n]: Rn(r) ? Math.max(r, i) : i,
        };
      }
      async buildGamUrlWithConsent(e, t) {
        let n =
          arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {};
        const r = this.consentParams();
        return this.buildGamUrl(e, t, r, n);
      }
      highestPrebidBid() {
        const { placements: e } = this.unit.requestUnit.video,
          t = Object.keys(e).map((e) => {
            this.unit.setCurrentPlacement(e);
            return {
              bid: this.currentWinningPrebidBidResponse(),
              placement: e,
            };
          }),
          n = t.reduce(
            (e, t) =>
              Rn(t.bid)
                ? Rn(e.bid?.cpm) && e.bid.cpm.isGte(t.bid.cpm)
                  ? e
                  : t
                : e,
            t[0]
          );
        return this.unit.setCurrentPlacement(null), n;
      }
      buildGamUrl(e, t, n) {
        let r =
          arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
        const i = this.calculateBuildVideoUrlParams(e, t, n, r),
          o = e.adServers.gam.buildVideoUrl(i);
        if (!Rn(o)) throw new Error("Could not construct the GAM url.");
        return o;
      }
      calculateAndStoreGooglePriceFloor() {
        const e = this.unit.getCurrentPlacement();
        try {
          return (
            this.unit.setCurrentPlacement(null),
            super.calculateAndStoreGooglePriceFloor()
          );
        } finally {
          this.unit.setCurrentPlacement(e);
        }
      }
      calculateBuildVideoUrlParams(e, t, n) {
        let r =
          arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : {};
        const { placement: i } = this.highestPrebidBid();
        this.unit.setCurrentPlacement(i);
        const o = this.unit.code(),
          s = e.adUnits.filter((e) => e.code === o);
        if (1 !== s.length)
          throw new Error("[VideoUnit] Display video expected single unit");
        Zn.debug(`[VideoUnit] ${o} has highest bid`);
        const a = s[0],
          c = Sh(this.calculateAndStoreGooglePriceFloor()),
          d = { [tr]: Rn(c) ? c : void 0 },
          u = {},
          l = parseFloat(c);
        u[nr] = Math.floor(1e6 * l).toFixed(0);
        const p = Object.fromEntries(
            Object.entries(this.getBidCacheGamKeyValues()).map((e) => {
              let [t, n] = e;
              return [t, n ?? void 0];
            })
          ),
          f = {},
          h = df.getInstance(),
          m = Er();
        if (h.hasGppConsent() && Rn(m) && "GPP" === yp(m)) {
          const e = h.getLegacyUspConsentInformation(m);
          Rn(e) && (f.us_privacy = e);
        }
        const g = {
          iu: this.unit.requestUnit.slotId,
          ad_type: "video",
          tfcd: t.video.tfcd || 0,
          trt: 0,
          vad_type: "linear",
          plcmt: yh.INSTREAM,
          ...f,
          ...n,
          ...this.customVastAdTagParams(),
          cust_params: Uh(Fh(r, d, u, p)),
        };
        Rn(t.video.sz) && (g.sz = t.video.sz),
          Rn(t.video.mridx) && (g.mridx = t.video.mridx),
          Rn(t.video.output) && (g.output = t.video.output),
          Rn(t.video.url) && (g.url = t.video.url),
          Zn.debug(`[VideoUnit] URL Params ${JSON.stringify(g)}`),
          this.unit.setCurrentPlacement(null);
        const b = this.getAmazonBidResponse();
        if (Rn(b)) {
          let e = b.qsParams;
          (e.startsWith("?") || e.startsWith("&")) && (e = e.substring(1));
          new URLSearchParams(e).forEach((e, t) => {
            Rn(g.cust_params) || (g.cust_params = {}), (g.cust_params[t] = e);
          });
        }
        return { adUnit: a, params: g };
      }
      customVastAdTagParams() {
        if (!this.unit.requestUnit.video) return {};
        if (!Rn(this.googleBid))
          return Zn.warn("[VideoUnit] Missing a google bid"), {};
        const e = this.unit.requestUnit.video.videoType,
          {
            skippableMaxDuration: t,
            nonSkippableMaxDuration: n,
            descriptionUrl: r,
          } = this.googleBid,
          i = {};
        return (
          Rn(t) && (i.sdmax = 1e3 * t),
          Rn(n) && (i.max_ad_duration = 1e3 * n),
          Rn(e) && (i.vpos = this.videoTypeParam(e)),
          Rn(r) && (i.description_url = r),
          i
        );
      }
      videoTypeParam(e) {
        switch (e) {
          case "rewarded":
          case "preroll":
            return "preroll";
          case "midroll":
            return "midroll";
          default:
            return (
              Zn.error(`[VideoUnit] Unexpected Video Type ${e}`), "preroll"
            );
        }
      }
      consentParams() {
        return bp(Er(), !0)
          ? df.getInstance().hasTCFConsent()
            ? {}
            : { npa: 1 }
          : { npa: 0 };
      }
      getPrebidPriceBuckets() {
        return nh;
      }
    },
    Lh = [
      "GamesFreak_GamePage",
      "Skyscraper",
      "Skyscraper_Category_Pages",
      "Skyscraper_Home",
      "Leaderboard",
      "JouerJeux_MPU",
      "GiocaGiochi_MPU",
      "test_leaderboard",
      "GamesFreak_PrerollVid",
      "Featured_Game",
      "FrontpageGame",
      "Animix_MPU_Gamepage",
      "GF_racing",
      "AFG",
      "iPhoneGameAd",
      "Large_Video",
      "Leaderboard_Home",
      "Leaderboard_Category_Pages",
      "Leaderboard_Game_Pages",
      "Criteo_MPU",
      "Non_Criteo_MPU",
      "Googlebutton",
      "AFVforLiverail",
      "GamesFreak_GamePageLarge",
      "animix_AFG",
      "Gamesfreak_pixel_siteskin",
      "GamesFreak_pixel_gamepage",
      "GamesFreak_pixel_homepage",
      "GamesFreak_pixel_categorypage",
      "GamesFreak_TrueView_Preloader",
      "Game_TrueView_PreLoader",
      "GamesFreak_Skyscaper_GamePage",
      "Gamepage_Skyscraper_Left",
      "GamesFreak_pixel_searchpage",
      "Horizontal",
      "Test_VAST",
      "Leaderboard_Game_Pages_2",
      "Skyscraper_Search_Page",
      "Floating_Footer",
      "Slider",
      "prebid-test-ad-unit-leaderboard",
      "ROS-300x250-MPU",
      "ROS-336x280-MPU-Below-Game",
      "ROS-300x250-MPU-Below-Game",
      "ROS-300x250-MPU-Below-Walkthrough",
      "ROS-336x280-MPU-Below-Walkthrough",
      "ROS-Preroll",
      "ROS-728x90-Top-Leaderboard",
      "Mobile_Leaderboard",
      "In_between_level_unit_ATF",
      "Category_skyscraper_unit_BTF",
      "Mobile_MPU",
      "ROS Gameframe Video Internal",
      "ROS Gameframe Video External",
      "ROS-970x90-Large-Leaderboard",
      "ROS-300x250-Mobile-Game-MPU",
      "ROS-728x90-Top-Leaderboard-Refresh",
      "Fortnite-Unit",
      "blockthrough",
      "SolitaireParadise-ROS-Indexpage-Leaderboard-728-90",
      "SolitaireParadise-ROS-Gamepage-Right-160-600",
      "SolitaireParadise-ROS-Gamepage-Right-160-600-Refresh",
      "SolitaireParadise-ROS-Gamepage-Right-300-600",
      "SolitaireParadise-ROS-Gamepage-Left-300-600-Refresh",
      "SolitaireParadise-ROS-Gamepage-Right-300-600-Refresh",
      "SolitaireParadise-ROS-Gamepage-Left-160-600-Refresh",
      "SolitaireParadise-ROS-Gamepage-Left-300-600",
      "SolitaireParadise-ROS-Gamepage-Inline-Text-300-250",
      "SolitaireParadise-ROS-Gamepage-Left-160-600",
      "SolitaireParadise-ROS-Gamepage-Top-Leaderboard-728-90",
      "SolitaireParadise-ROS-Gamepage-Top-Leaderboard-728-90-Refresh",
      "SolitaireParadise-ROS-Gamepage-Below-Leaderboard-728-90",
      "ROS-320x50-Mobile_Leaderboard",
      "GAaas Video",
      "GAaas Display",
      "GAaas Fallback Banners",
      "Adsolve Video",
      "AdSolve Display",
      "AdSolve Fallback",
      "House-Video-Catch-All",
    ];
  const jh = ["ROS-Rewarded"];
  const Dh = [
    "DFPAudiencePixel",
    "Ad Exchange Display",
    "ROS-728x90-Leaderboard",
    "ROS-160x600-Skyscraper-Right",
    "ROS-160x600-Skyscraper-Left",
    "Ad Exchange Games",
    "ROS-160x600-Skyscraper-Left-R",
    "ROS-160x600-Skyscraper-Right-R",
    "ROS-300x600-Half-Page-R",
    "ROS-300x600-Half-Page",
    "ROS-300x250-Right-MPU",
    "ROS-300x250-Right-MPU-R",
    "ROS-Video-Rewarded-External",
    "ROS-Video-Midroll-External",
    "ROS-Video-Rewarded-Internal",
    "ROS-Video-Preroll-External",
    "ROS-Video-Midroll-Internal",
    "ROS-Video-Preroll-Internal",
    "ROS-300x600-Half-Page-Below-Game",
    "Ad Exchange Video",
    "ROS-300x600-Half-Page-Left-R",
    "ROS-300x600-Half-Page-Left",
    "ROS-728x90-Leaderboard-Below-R",
    "ROS-320x50-Mobile-Leaderboard",
    "ROS-728x90-Leaderboard-Below-Game-R",
    "ROS-728x90-Leaderboard-Below-Game",
    "ROS-Intermediate-Mobile",
    "ROS-Intermediate-Desktop",
    "ROS-Intermediate-Tablet",
    "ROS-In-Game-728x90-1",
    "ROS-In-Game-300x250-2",
    "ROS-In-Game-320x50-2",
    "ROS-In-Game-300x250-1",
    "ROS-In-Game-160x600-1",
    "ROS-In-Game-160x600-2",
    "ROS-In-Game-728x90-2",
    "ROS-In-Game-320x50-1",
    "ROS-In-Game-320x100-2",
    "ROS-In-Game-468x60-1",
    "ROS-In-Game-320x100-1",
    "ROS-In-Game-468x60-2",
    "ROS-In-Game-Multi-1",
    "ROS-In-Game-Multi-2",
    "ROS-Video-Google-Rewarded-Internal",
    "Kids-Video-Preroll-Internal",
    "Kids-Video-Midroll-Internal",
    "Kids-Video-Rewarded-Internal",
    "ROS-728x90-Leaderboard-Below-Game-R-2",
    "ROS-Google-H5-Rewarded",
    "ROS-Google-H5-Interstitial",
    "Default",
  ];
  const Vh = class {
    constructor(e, t) {
      (this.requestUnit = e),
        (this.requestOptions = t),
        (this.numberOfRequests = 1),
        (this.numberOfImpressions = 0);
    }
    addApstagSlot(e) {
      this.bids.addApstagSlot(e.slotID);
    }
    getApstagSlots() {
      return this.bids.getApstagSlots();
    }
    setApstagSlots() {
      this.bids.setApstagSlots();
    }
    snapshotBidCacheHealth() {
      this.bids.snapshotBidCacheHealth();
    }
    getBidCacheHealth() {
      return this.bids.getBidCacheHealth();
    }
    addPrebidBidRequest(e) {
      this.bids.addPrebidBidRequest(e);
    }
    elementId() {
      return this.code();
    }
    code() {
      return this.requestUnit.adUnit.code;
    }
    getAllCodes() {
      return [this.code()];
    }
    includeEnabledBiddersInAuction(e, t) {
      if (this.bids.isAdsenseIncludedInAuction()) {
        const e = t.map((e) => e.code);
        return void qn.debug(
          `[AdUnit] ${this.code()} ignoring ${e.join(" ")} bids due to adsense`
        );
      }
      t.forEach((t) => this.includeBidderInAuctionIfEnabled(e, t));
    }
    getSizes() {
      return xh(this.requestUnit.adUnit);
    }
    maxSize() {
      const e = this.getSizes(),
        t = e.map((e) => e[0]),
        n = e.map((e) => e[1]);
      return [Math.max(...t), Math.max(...n)];
    }
    isBanner() {
      return !1;
    }
    isVideo() {
      return !1;
    }
    getAdType() {
      return this.requestUnit.adType;
    }
    getAdUnitName() {
      const e = this.requestUnit.slotId;
      return e.slice(9);
    }
    getNumberOfRequests() {
      return this.numberOfRequests;
    }
    getNumberOfImpressions() {
      return this.numberOfImpressions;
    }
  };
  function Gh(e) {
    return Rn(e) && e.isVideo();
  }
  const $h = class extends Vh {
    currentPlacement = null;
    constructor(e, t) {
      super(e, t),
        (this.bids = new Nh(this)),
        (this.requestUnit = e),
        (this.requestOptions = t);
    }
    canRender() {
      return { success: !0 };
    }
    getBids() {
      return this.bids;
    }
    mediaType() {
      return this.requestUnit.adUnit.mediaTypes.video;
    }
    isVideo() {
      return !0;
    }
    getAdFormat() {
      return "video";
    }
    bidRequestParamsForBidder(e, t, n) {
      return e.customVideoBidRequestParams(t, this, n);
    }
    addPrebidBidRequest(e) {
      const t = { ...e, placement: this.currentPlacement };
      super.addPrebidBidRequest(t);
    }
    code() {
      const e = super.code();
      return ji(this.currentPlacement)
        ? this.codeWithPlacement(this.currentPlacement)
        : e;
    }
    getAllCodes() {
      return Object.keys(this.requestUnit.video.placements).map((e) =>
        this.codeWithPlacement(e)
      );
    }
    getCurrentPlacement() {
      return this.currentPlacement;
    }
    setCurrentPlacement(e) {
      this.currentPlacement = e;
    }
    includeBidderInAuctionIfEnabled(e, t) {
      const { placements: n } = this.requestUnit.video;
      n || qn.error("[VideoUnit] should have placements"),
        Object.keys(n).forEach((r) => {
          this.currentPlacement = r;
          const i = n[r],
            o = (i.bidders || []).find((e) => e.bidder === t.code);
          Rn(o)
            ? t.includeBidderInAuctionForAdUnitIfEnabled(
                e,
                this,
                o,
                this.createBidOptions(i, t)
              )
            : t.includeBidderInAuctionForAdUnitIfEnabled(
                e,
                this,
                null,
                this.createBidOptions(i, t)
              );
        }),
        (this.currentPlacement = null);
    }
    createBidOptions(e, t) {
      const n = this.openRTB(e, "google" === t.code);
      return {
        type: "videoBidOptions",
        pageUrl: this.requestOptions.pageUrl,
        openRTB: n,
        dealTargeting: this.requestOptions.dealTargeting,
      };
    }
    checkBidderSettings(e, t) {
      return t.checkVideoSettings(e, this);
    }
    async invokeGamUrlConstructedCallback(e, t) {
      const n = this.bids.getPrebidAmazonBids();
      try {
        const r = this.bids.highestPrebidBid(),
          i = Rn(r.bid) ? r.placement : null,
          o = super.code(),
          s = ji(i) ? this.codeWithPlacement(i) : null,
          a = this.getOnVideoPlayedCallback(
            { prebid: r?.bid ?? void 0, amazon: n.amazon ?? void 0 },
            { code: s ?? o }
          );
        t({
          type: "UnitRendered",
          identifiers: { code: o, placementCode: s },
          gamInfo: this.createGamInfo(e),
          callbacks: { onVideoPlayedCallback: a },
        });
      } catch {
        qn.error(`[VideoUnit] ${this.code()}, err in invoking callback`);
      }
    }
    createGamInfo(e) {
      const t = this.getBids().getMinimumExpectedPaymentInformation(),
        n = this.getBids().highestPrebidBid(),
        r = this.getBids().getAmazonBidResponse(),
        i = Rn(n.bid) && (!Rn(r) || n.bid.lineItemValue.isGte(r.lineItemValue)),
        o = Rn(r) && (!Rn(n.bid) || r.lineItemValue.isGte(n.bid.lineItemValue)),
        s =
          Rn(n.bid) && i
            ? {
                bidderCode: n.bid.bidderCode,
                creativeId: `${n.bid.creativeId}`,
                advertiserDomains: n.bid?.meta?.advertiserDomains ?? [],
              }
            : void 0,
        a = Rn(r) && o ? { amznp: r.amznp, amzniid: r.amzniid } : void 0;
      return {
        url: e,
        minPricePaid: {
          google: uh(t.google),
          prebid: Rn(t.prebid) ? uh(t.prebid) : void 0,
          amazon: Rn(t.amazon) ? uh(t.amazon) : void 0,
        },
        winningPrebidBid: s,
        winningAmazonBid: a,
      };
    }
    openRTB(e, t) {
      const { skippable: n } = e,
        r = t ? e.googleMaxDuration : e.maxDuration,
        i = this.getStartdelay(),
        o = e.context ?? "instream";
      return this.createOpenRTB(i, o, r, n);
    }
    codeWithPlacement(e) {
      return `${super.code()}-${e}`;
    }
    getStartdelay() {
      return 0;
    }
    createOpenRTB(e, t, n, r) {
      return {
        context: "instream",
        protocols: [
          hh.VAST1,
          hh.VAST2,
          hh.VAST3,
          hh.VAST2Wrapper,
          hh.VAST3Wrapper,
          hh.VAST4,
          hh.VAST4Wrapper,
          hh.VAST4_1,
          hh.VAST4_1Wrapper,
          hh.VAST4_2,
          hh.VAST4_2Wrapper,
        ],
        api: [mh.OMID_1_0, mh.SIMID_1_0, mh.VPAID2],
        mimes: [
          "video/mp4",
          "video/webm",
          "video/quicktime",
          "video/ogg",
          "application/javascript",
        ],
        linearity: this.getLinearity(t),
        minbitrate: 10,
        maxbitrate: 1e4,
        placement: this.getPlacement(t),
        plcmt: this.getPlcmt(t),
        playbackmethod: [Ah.CLICK_WITH_SOUND],
        startdelay: e,
        minduration: 1,
        maxduration: n,
        ...(Rn(r) ? { skip: r ? 1 : 0 } : {}),
        ...(!0 === r
          ? { skipafter: mp.general.skip.bidderSkipAfterSeconds }
          : {}),
      };
    }
    getLinearity(e) {
      switch (e) {
        case "instream":
        case "interstitial":
          return gh.INSTREAM;
      }
    }
    getPlacement(e) {
      switch (e) {
        case "instream":
          return bh.INSTREAM;
        case "interstitial":
          return bh.INTERSTITIAL;
      }
    }
    getPlcmt(e) {
      switch (e) {
        case "instream":
          return vh.INSTREAM;
        case "interstitial":
          return vh.INTERSTITIAL;
      }
    }
    getOnVideoPlayedCallback(e, t) {
      return Oh.createOnVideoPlayedCallback(e, t);
    }
  };
  class qh {
    constructor(e, t) {
      this.code = e;
      const { rules: n, ...r } = $i.getBidderConfig(e) || {};
      (this.config = { ...{ cost: 0, discrepancy: 0, ...r }, ...t }),
        this.logConfig(this.config);
    }
    includeBidderInAuctionForAdUnitIfEnabled(e, t, n, r) {
      const i = n || this.defaultConfig(),
        o = this.getBidderSettings(i, t);
      this.isBidderEnabledForUnit(t, o, r)
        ? (Rn(n) ||
            Zn.warn(
              `[${this.code}] missing request unit config, bravely continuing with default config`
            ),
          this.checkSettings(o, t),
          this.addBidRequestToAdUnit(e, t, o, r))
        : Zn.debug(`[${this.code}] disabled for unit ${t.code()}`);
    }
    isPrebidBidder() {
      return !1;
    }
    getConfig() {
      return { ...this.config };
    }
    checkVideoSettings(e, t) {}
    checkBannerSettings(e, t) {}
    checkSettings(e, t) {
      t.checkBidderSettings(e, this);
    }
    getBidderSettings(e, t) {
      return Object.assign({}, this.config, e);
    }
    warn(e) {
      for (
        var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1;
        r < t;
        r++
      )
        n[r - 1] = arguments[r];
      Zn.warn(`[${this.code}Bidder] ${e}`, ...n);
    }
    warnIfNotSet(e, t) {
      (Rn(t) && "" !== t) || this.warnWrongVariable(e, t);
    }
    warnWrongVariable(e, t) {
      this.warn(`${e} incorrectly set`, t);
    }
    isNumber(e) {
      return "number" == typeof e && !isNaN(e);
    }
    isBidderEnabledForUnit(e, t, n) {
      const { enabled: r } = t;
      return !0 === r
        ? $i.isBidderEnabledForSession(
            this.code,
            e.isBanner() ? "banner" : "video"
          )
        : (Zn.debug(
            `bidder ${
              this.code
            } not enabled for unit ${e.code()} because of ads request config`
          ),
          !1);
    }
    defaultConfig() {
      return { bidder: this.code };
    }
    logConfig(e) {
      Zn.debug(`[${this.code}] ${JSON.stringify(e)}`);
    }
  }
  const Zh = class extends qh {
    addBidRequestToAdUnit(e, t, n) {
      this.createBid(t, n);
    }
    createBid(e, t) {
      const { slot: n, client: r } = t;
      if (!ji(n)) return void Zn.warn("[AdSense] missing slot");
      if (!ji(r)) return void Zn.error("[AdSense] missing client id");
      const i = e.code(),
        o = document.getElementById(i);
      if (!Rn(o)) return void Zn.warn(`[AdSense] cannot find element ${i}`);
      const [s, a] = e.maxSize(),
        c = document.createElement("ins");
      c.setAttribute("class", "adsbygoogle"),
        c.setAttribute(
          "style",
          `display:inline-block;width:${s}px;height:${a}px`
        ),
        c.setAttribute("data-ad-client", r),
        c.setAttribute("data-ad-slot", n);
      const d = document.createElement("style");
      (d.textContent =
        'ins.adsbygoogle[data-ad-status="unfilled"] { display: none !important; }'),
        o.appendChild(d),
        o.appendChild(c),
        e.getBids().setAdsenseIncludedInAuction();
    }
  };
  function Kh(e) {
    const t = jp("czyExpClientAmazonBidRoute_2");
    return (
      t === e || ("prebid" === t && "apstag" === e && Math.random() < 0.02)
    );
  }
  class Hh extends qh {
    checkVideoSettings(e, t) {
      super.checkVideoSettings(e, t);
      const { slotID: n } = e;
      this.warnIfNotSet("slotID", n);
    }
    addBidRequestToAdUnit(e, t, n, r) {
      const { pubID: i, adServer: o, slotID: s } = n;
      e.setApstagConfig({ pubID: i, adServer: o });
      const a = t.isVideo() ? s : t.code();
      t.addApstagSlot({ slotID: a || t.code() });
    }
    checkSettings(e, t) {
      super.checkSettings(e, t);
      const { pubID: n, adServer: r } = e;
      this.warnIfNotSet("pubID", n), this.warnIfNotSet("adServer", r);
    }
    isBidderEnabledForUnit(e, t, n) {
      return !!Kh("apstag") && super.isBidderEnabledForUnit(e, t, n);
    }
  }
  class Wh extends qh {
    addBidRequestToAdUnit(e, t, n, r) {
      if (t.isVideo() && "videoBidOptions" === r.type) {
        const e = t.getBids(),
          i = r.openRTB,
          { descriptionUrl: o } = n,
          { maxduration: s } = i,
          a = 1 === i.skip,
          c = { descriptionUrl: o, maxDuration: s };
        e.setGoogleVideoBidRequest(c, a);
      }
    }
    isBidderEnabledForUnit(e, t, n) {
      return !0;
    }
    checkSettings(e, t) {
      if ((super.checkSettings(e, t), t.isVideo())) {
        const { descriptionUrl: t } = e;
        ji(t) || this.warnIfNotSet("descriptionUrl", t);
      }
    }
  }
  class Jh extends qh {
    constructor(e, t) {
      super(e, t), (this.code = e);
    }
    isPrebidBidder() {
      return !0;
    }
    getPrebidBidderSettings(e, t) {
      const n = { bidCpmAdjustment: this.getAdjustment(e, t) };
      return { [this.prebidCode()]: n };
    }
    getAdjustment(e, t) {
      return (n) => this.adjust(n, e, t);
    }
    adjust = (e, t, n) =>
      (function (e, t, n) {
        return e * (1 - t) * (1 - n);
      })(e, t, n);
    prebidCode() {
      return this.code;
    }
    addBidRequestToAdUnit(e, t, n, r) {
      const i = this.toBidRequest(e, n, t, r);
      t.addPrebidBidRequest(i);
    }
    checkSettings(e, t) {
      super.checkSettings(e, t);
    }
    customBidRequestParams(e, t, n) {
      return t.bidRequestParamsForBidder(this, e, n);
    }
    toBidRequest(e, t, n, r) {
      if (this.code !== t.bidder) throw new Error("[Bidder] wrong bidconfig");
      return {
        bidder: this.prebidCode(),
        params: this.bidRequestParams(e, t, n, r),
      };
    }
    bidRequestParams(e, t, n, r) {
      const i = this.customBidRequestParams(t, n, r);
      return Zn.debug(`[${this.code}] Bid Params:`, i), i;
    }
    isBidderEnabledForUnit(e, t, n) {
      const r = super.isBidderEnabledForUnit(e, t, n);
      return r && Gh(e) && Oh.isBidderBlacklisted(this)
        ? (Zn.debug(`bidder ${this.code} is on the blacklist for videos`), !1)
        : r;
    }
  }
  class Yh extends Jh {
    customVideoBidRequestParams(e, t, n) {
      const r = this.customAdUnitParams(e, n),
        { openRTB: i } = n,
        o = i?.minduration ?? 4,
        s = i?.maxduration ?? (Rn(i?.skip) && 0 !== i?.skip ? 60 : 15),
        a = 1 === i?.skip ? 15 : void 0;
      return {
        ...r,
        video: { ...i, minduration: o, maxduration: s, skipmin: a },
      };
    }
    customBannerBidRequestParams(e, t, n) {
      return this.customAdUnitParams(e, n);
    }
    checkVideoSettings(e, t) {
      super.checkVideoSettings(e, t);
    }
    addBidRequestToAdUnit(e, t, n, r) {
      const { sizes: i } = n;
      i.forEach((i) => {
        const o = Object.assign({}, n, { size: i.slice() }),
          s = this.toBidRequest(e, o, t, r);
        t.addPrebidBidRequest(s);
      });
    }
    customAdUnitParams(e, t) {
      const { siteId: n, size: r } = e;
      return (
        this.warnIfNotSet("size", r),
        { siteId: `${n}`, size: r, pageUrl: t.pageUrl }
      );
    }
    checkSettings(e, t) {
      super.checkSettings(e, t);
      const { siteId: n } = e;
      this.warnIfNotSet("siteId", n);
    }
  }
  class Qh extends Jh {
    customVideoBidRequestParams(e) {
      return this.customUnitBidParams(e);
    }
    customBannerBidRequestParams(e) {
      return this.customUnitBidParams(e);
    }
    checkSettings(e, t) {
      super.checkSettings(e, t);
      const { siteId: n, publisherId: r, placementId: i } = e;
      this.warnIfNotSet("siteId", n),
        this.warnIfNotSet("publisherId", r),
        this.warnIfNotSet("placementId", i);
    }
    customUnitBidParams(e) {
      const { siteId: t, publisherId: n, placementId: r } = e;
      return { siteId: t, publisherId: n, placementId: r };
    }
  }
  class Xh extends Jh {
    customBannerBidRequestParams(e, t, n) {
      return this.customUnitBidParams(e, n);
    }
    customVideoBidRequestParams(e, t, n) {
      const { api: r, protocols: i, mimes: o, skip: s, ...a } = n.openRTB;
      return {
        ...this.customUnitBidParams(e, n),
        video: { ...a, skip: s ?? 0 },
      };
    }
    addBidRequestToAdUnit(e, t, n, r) {
      const { adSlot: i, addSizes: o = !0 } = n,
        s = t.getSizes();
      return o && ji(i)
        ? void s.forEach((o) => {
            const [s, a] = o,
              c = `${i}@${s}x${a}`,
              d = Object.assign({}, n, { adSlot: c }),
              u = this.toBidRequest(e, d, t, r);
            t.addPrebidBidRequest(u);
          })
        : super.addBidRequestToAdUnit(e, t, n, r);
    }
    customUnitBidParams(e, t) {
      const { pageUrl: n, dealTargeting: r } = t,
        { publisherId: i, adSlot: o } = e;
      return ji(o)
        ? {
            publisherId: i || "",
            adSlot: o,
            kadpageurl: n,
            dctr: this.dealTargetingToDctr(r),
          }
        : {
            publisherId: i || "",
            kadpageurl: n,
            dctr: this.dealTargetingToDctr(r),
          };
    }
    dealTargetingToDctr(e) {
      if (!Rn(e)) return;
      const t = [];
      for (const [n, r] of Object.entries(e))
        Rn(r) &&
          0 !== r.length &&
          t.push(`${n}:${Array.isArray(r) ? r.join(",") : r}`);
      return 0 !== t.length ? t.join("|") : void 0;
    }
    checkSettings(e, t) {
      super.checkSettings(e, t);
      const { publisherId: n } = e;
      this.warnIfNotSet("publisherId", n);
    }
  }
  class em extends Jh {
    customBannerBidRequestParams(e) {
      return this.customUnitBidParams(e);
    }
    customVideoBidRequestParams(e, t, n) {
      const { language: r } = e;
      return {
        ...this.customUnitBidParams(e),
        video: { ...n.openRTB, language: r || "en" },
      };
    }
    checkVideoSettings(e, t) {
      super.checkVideoSettings(e, t);
      const { language: n } = e;
      this.warnIfNotSet("language", n);
    }
    customUnitBidParams(e) {
      const { accountId: t, siteId: n, position: r, zoneId: i } = e;
      return {
        accountId: t || "",
        siteId: n || "",
        zoneId: i || "",
        ...(r && { position: r }),
      };
    }
    checkSettings(e, t) {
      super.checkSettings(e, t);
      const { siteId: n, zoneId: r, accountId: i } = e;
      this.warnIfNotSet("siteId", n),
        this.warnIfNotSet("zoneId", r),
        this.warnIfNotSet("accountId", i);
    }
  }
  class tm extends Jh {
    customBannerBidRequestParams(e) {
      return this.customUnitBidParams();
    }
    customVideoBidRequestParams(e) {
      return this.customUnitBidParams();
    }
    customUnitBidParams() {
      return {};
    }
    checkSettings(e, t) {
      super.checkSettings(e, t);
    }
    isBidderEnabledForUnit(e, t, n) {
      return !!Kh("prebid") && super.isBidderEnabledForUnit(e, t, n);
    }
  }
  class nm extends Jh {
    customBannerBidRequestParams(e) {
      return this.customUnitBidParams(e);
    }
    customVideoBidRequestParams(e) {
      return this.customUnitBidParams(e);
    }
    customUnitBidParams(e) {
      const { networkId: t } = e;
      return { networkId: t };
    }
    checkSettings(e, t) {
      super.checkSettings(e, t);
      const { networkId: n } = e;
      this.warnIfNotSet("networkId", n);
    }
  }
  class rm extends Jh {
    customBannerBidRequestParams(e, t, n) {
      return this.customBidParamsImpl(e);
    }
    customVideoBidRequestParams(e, t, n) {
      return this.customBidParamsImpl(e);
    }
    customBidParamsImpl(e) {
      const { supplySourceId: t, publisherId: n } = e;
      return { supplySourceId: t, publisherId: n };
    }
    checkSettings(e, t) {
      super.checkSettings(e, t);
      const { supplySourceId: n, publisherId: r } = e;
      this.warnIfNotSet("supplySourceId", n),
        this.warnIfNotSet("publisherId", r);
    }
  }
  class im extends Jh {
    customBannerBidRequestParams(e, t, n) {
      return this.customUnitBidParams(e, "banner");
    }
    customVideoBidRequestParams(e, t, n) {
      return this.customUnitBidParams(e, "video");
    }
    isBidderEnabledForUnit(e, t, n) {
      if (!super.isBidderEnabledForUnit(e, t, n)) return !1;
      const r = $i.getEnabledNexx360BiddersForSession(
        e.isBanner() ? "banner" : "video"
      );
      return (
        0 !== r?.length ||
        (Zn.debug(
          `[${
            this.code
          }] disabled for unit ${e.code()} because none of its bidders are enabled`
        ),
        !1)
      );
    }
    checkSettings(e, t) {
      super.checkSettings(e, t);
      const { tagId: n } = e;
      this.warnIfNotSet("tagId", n);
    }
    customUnitBidParams(e, t) {
      const { tagId: n } = e,
        r = $i.getEnabledNexx360BiddersForSession(t);
      return { tagId: n, ...(Rn(r) && r.length > 0 ? { enabledSsps: r } : {}) };
    }
  }
  class om extends Jh {
    getPrebidBidderSettings(e, t) {
      return {
        [this.prebidCode()]: {
          bidCpmAdjustment: this.getAdjustment(e, t),
          storageAllowed: !0,
        },
      };
    }
    customBannerBidRequestParams(e, t, n) {
      return this.customUnitBidParams(e);
    }
    customVideoBidRequestParams(e, t, n) {
      return this.customUnitBidParams(e);
    }
    checkSettings(e, t) {
      super.checkSettings(e, t);
      const { placementId: n } = e;
      this.warnIfNotSet("placementId", n);
    }
    customUnitBidParams(e) {
      const { placementId: t } = e;
      return { placementId: t };
    }
  }
  class sm extends Jh {
    customBannerBidRequestParams(e, t, n) {
      return this.customUnitBidParams(e);
    }
    customVideoBidRequestParams(e, t, n) {
      return this.customUnitBidParams(e);
    }
    checkSettings(e, t) {
      super.checkSettings(e, t);
      const { cid: n, crid: r } = e;
      this.warnIfNotSet("cid", n), this.warnIfNotSet("crid", r);
    }
    customUnitBidParams(e) {
      const { cid: t, crid: n } = e;
      return { cid: t, crid: n };
    }
  }
  class am extends Jh {
    customVideoBidRequestParams(e, t, n) {
      const r = this.customAdUnitParams(e, t.mediaType()),
        { maxduration: i, minduration: o, skip: s, api: a } = n.openRTB;
      return {
        ...r,
        video: {
          maxduration: i,
          minduration: o,
          skippable: 1 === s,
          frameworks: a,
          context: "pre_roll",
        },
      };
    }
    customBannerBidRequestParams(e, t) {
      const n = t.mediaType();
      return this.customAdUnitParams(e, n);
    }
    checkSettings(e, t) {
      super.checkSettings(e, t);
      const { placement_id: n } = e;
      this.warnIfNotSet("placement_id", n);
    }
    customAdUnitParams(e, t) {
      const { pos: n } = t,
        { placement_id: r } = e;
      return {
        placement_id: r,
        allowSmallerSizes: !0,
        supplyType: "web",
        position: 1 === n ? "above" : void 0,
      };
    }
  }
  class cm {
    static createBidder(e, t, n) {
      const r = (function (e, t) {
          for (const n of t) if (n.bidder === e) return n;
          return null;
        })(e, n || []),
        i = Object.assign({}, t, r);
      switch (e) {
        case "msft":
          return new am(e, i);
        case "google":
          return new Wh(e, i);
        case "ix":
          return new Yh(e, i);
        case "pubmatic":
          return new Xh(e, i);
        case "rubicon":
          return new em(e, i);
        case "equativ":
          return new nm(e, i);
        case "aps":
          return new tm(e, i);
        case "amazon":
          return new Hh(e, i);
        case "adsense":
          return new Zh(e, i);
        case "ozone":
          return new Qh(e, i);
        case "ttd":
          return new rm(e, i);
        case "nexx360":
          return new im(e, i);
        case "kargo":
          return new om(e, i);
        case "medianet":
          return new sm(e, i);
      }
    }
    static createBidders(e, t) {
      const n = Hp().map((n) => {
        const r = e[n],
          i = Object.assign({ code: n, video: { placements: {} } }, r);
        return this.createBidder(n, i, t.bidders);
      });
      let r = null,
        i = null,
        o = null;
      const s = [];
      return (
        n.forEach((e) => {
          switch (e.code) {
            case "google":
              r = e;
              break;
            case "amazon":
              i = e;
              break;
            case "adsense":
              o = e;
              break;
            default:
              return void s.push(e);
          }
        }),
        {
          google: this.checkIfFailedToCreate("google", r),
          amazon: this.checkIfFailedToCreate("amazon", i),
          prebid: s,
          adsense: this.checkIfFailedToCreate("adsense", o),
        }
      );
    }
    static checkIfFailedToCreate(e, t) {
      if (Rn(t)) return t;
      throw new Error(`[BidderFactory] failed to create ${e}`);
    }
  }
  class dm {
    static instance = void 0;
    static getInstance() {
      return Rn(this.instance) || (this.instance = new dm()), this.instance;
    }
    auctionTimeouts = {};
    auctionTimedOutBidders = {};
    auctionInformations = {};
    constructor() {
      Mn().que.push(() => {
        const e = Fn();
        e.onEvent("auctionTimeout", this.onAuctionTimeout),
          e.onEvent("auctionEnd", this.onAuctionEnd),
          e.onEvent("bidTimeout", this.onBidTimeout);
      });
    }
    onAuctionTimeout = (e) => {
      this.auctionTimeouts[e.auctionId] = !0;
    };
    onBidTimeout = (e) => {
      e.forEach((e) => {
        const t = e.auctionId,
          n = this.auctionTimedOutBidders[t] ?? [];
        (this.auctionTimedOutBidders[t] = n),
          n.push({ adUnit: e.adUnitCode, bidder: e.bidder });
      });
    };
    calculateApplicationLogicDisabledPrebidBidders(e, t) {
      return pr
        .filter((t) => !e.includes(t))
        .filter((e) => $i.isBidderEnabledForSession(e, t));
    }
    calculateAdFormat(e) {
      const t = e.mediaTypes;
      if (Rn(t?.banner)) return "banner";
      if (Rn(t?.video)) return "video";
      throw new Error(`Could not determine ad format for ad unit ${e.code}`);
    }
    onAuctionEnd = (e) => {
      const t = e.auctionId,
        n = e.adUnits.map((n) => {
          const r = n.code;
          let i = null;
          Rn(n.floors) &&
            Rn(n.floors.currency) &&
            Pf(n.floors.currency) &&
            Rn(n.floors.default) &&
            (i = uh(new Bf(n.floors.default, n.floors.currency, !1)));
          const o = n.bids
              .map((e) => e.bidder)
              .filter(Rn)
              .filter(Kp),
            s = e.noBids
              .filter((e) => e.adUnitCode === n.code)
              .map((e) => (Rn(e.bidder) && Kp(e.bidder) ? e.bidder : null))
              .filter(Rn);
          return {
            id: r,
            floor: i,
            bidders: o,
            disabledBidders:
              this.calculateApplicationLogicDisabledPrebidBidders(
                o,
                this.calculateAdFormat(n)
              ),
            rejectedBids: e.bidsRejected
              .filter((e) => e.adUnitCode === n.code)
              .map((e) => {
                if (!Rn(e.bidderCode) || !Kp(e.bidderCode)) return null;
                let t = 0;
                return (
                  Rn(e.cpm) &&
                    Rn(e.currency) &&
                    (t = uh(
                      ah(
                        { cpm: e.cpm, currency: e.currency },
                        this.calculateAdFormat(n)
                      ).cpm
                    )),
                  {
                    bidder: e.bidderCode,
                    cpm: t,
                    requestTime: e.requestTimestamp,
                    responseTime: e.responseTimestamp,
                  }
                );
              })
              .filter(Rn),
            bids: e.bidsReceived
              .filter((e) => e.adUnitCode === n.code)
              .map(_f)
              .map((e) => {
                let t = 0;
                return (
                  Rn(e.cpm) &&
                    Rn(e.currency) &&
                    (t = uh(
                      ah(
                        { cpm: e.cpm, currency: e.currency },
                        this.calculateAdFormat(n)
                      ).cpm
                    )),
                  {
                    bidder: e.bidderCode,
                    cpm: t,
                    requestTime: e.requestTimestamp,
                    responseTime: e.responseTimestamp,
                  }
                );
              }),
            noBidsBidders: s,
            timedOutBidders: (this.auctionTimedOutBidders[t] ?? [])
              .filter((e) => e.adUnit === r)
              .map((e) => e.bidder),
          };
        });
      (this.auctionInformations[t] = {
        auctionId: t,
        adUnits: n,
        timedOut: Rn(this.auctionTimeouts[t]),
        duration: e.auctionEnd - e.timestamp,
      }),
        setTimeout(() => {
          delete this.auctionInformations[t],
            delete this.auctionTimeouts[t],
            delete this.auctionTimedOutBidders[t];
        }, 6e4);
    };
    getAuctionInformation(e) {
      return this.auctionInformations[e];
    }
  }
  class um {
    apstagRequestTimeoutHit = !1;
    adRequestResponse = {};
    prebidAuctionInformationTracker = (() => dm.getInstance())();
    prebidAuctionId = void 0;
    amazonAuctionInformation = void 0;
    constructor(e, t) {
      (this.adRequester = e),
        (this.advertisingConfig = t),
        (this.adUnits = []),
        (this.prebidAdUnits = null),
        (this.apstagSlots = null),
        (this.requestManager = new fh(["amazon", "prebid"])),
        (this.requestPromise = null);
    }
    requestAds(e, t) {
      return (
        (this.prebidAuctionId = void 0),
        (this.amazonAuctionInformation = void 0),
        this.requestAdsImpl(e, t).then((e) => {
          let t;
          return (
            Rn(this.prebidAuctionId) &&
              (t = this.prebidAuctionInformationTracker.getAuctionInformation(
                this.prebidAuctionId
              )),
            {
              requestAdsResult: e,
              prebidAuctionInformation: t,
              amazonAuctionInformation: this.amazonAuctionInformation,
              bidCacheInformation: this.createBidCacheInformation(),
            }
          );
        })
      );
    }
    requestAdsImpl(e, t) {
      return (
        (this.requestPromise = Jp()),
        e.forEach((e) => {
          this.adRequestResponse[e.code()] = this.adRequestResponse[
            e.code()
          ] || { bids: [] };
        }),
        0 === e.length
          ? (Zn.debug("[AdRequest] No renderable ad units requested"),
            this.requestPromise.resolve(this.adRequestResponse),
            this.requestPromise.promise)
          : ((this.adUnits = e),
            (this.options = t),
            (this.bidders = cm.createBidders(
              this.advertisingConfig.bidders,
              this.options
            )),
            this.adRequester.loadScripts((e) => {
              Zn.debug(`[AdRequest] ${e} failed to loaded`),
                this.auctioneerRequestFinished(e);
            }, !0 === t.disableBlockthrough),
            this.processAds(),
            this.requestPromise.promise)
      );
    }
    async processAds() {
      this.includeAdsenseInAuctionWhenEnabled(),
        this.adRequester.loadAdsenseIfIncludedInAuction(),
        this.includeEnabledNonGoogleBiddersInAuction(),
        this.adUnits.forEach((e) => e.snapshotBidCacheHealth()),
        this.setupAndRequestApstag(),
        this.setupAndRequestPrebid();
    }
    async auctioneerRequestFinished(e) {
      Zn.debug(`[AdRequest] ${e} finished`),
        this.requestManager.setAuctioneerFinished(e),
        this.requestManager.haveBiddersFinished() &&
          this.requestPromise?.resolve(this.adRequestResponse);
    }
    isAmazonNotIncludedInAuction() {
      return 0 === this.getRequestedApstagSlots().length;
    }
    noPrebidUnitsInAuction() {
      return 0 === this.getRequestedPrebidAdUnits().length;
    }
    noPrebidBidRequestsInAuction() {
      const e = this.getRequestedPrebidAdUnits();
      return (
        0 === e.length ||
        e.every((e) => {
          const t = e.bids;
          return !Rn(t) || 0 === t.length;
        })
      );
    }
    prebidBidders() {
      return this.bidders.prebid;
    }
    includeAdsenseInAuctionWhenEnabled() {
      this.adRequester.includeEnabledBiddersInAuctionForAdUnits(this.adUnits, [
        this.bidders.adsense,
      ]);
    }
    includeEnabledNonGoogleBiddersInAuction() {
      this.adRequester.includeEnabledBiddersInAuctionForAdUnits(this.adUnits, [
        ...this.bidders.prebid,
        this.bidders.amazon,
      ]);
    }
    setAmazonBidResponses(e, t) {
      const n = t.filter((e) => "video" === e.mediaType),
        r = t.filter((e) => "video" !== e.mediaType);
      this.setAmazonVideoBidResponses(n),
        this.setAmazonBannerBidResponses(r),
        (this.amazonAuctionInformation = this.createAmazonAuctionInformation(
          e,
          t
        ));
    }
    createBidCacheInformation() {
      const e = {};
      return (
        this.adUnits.forEach((t) => {
          const n = t.getBidCacheHealth();
          Rn(n) &&
            (e[t.code()] = {
              bids: n.bids,
              highestCpm: Rn(n.highestCpm) ? uh(n.highestCpm) : null,
              medianCpm: Rn(n.medianCpm) ? uh(n.medianCpm) : null,
            });
        }),
        e
      );
    }
    createAmazonAuctionInformation(e, t) {
      return {
        adUnits: e.map((e) => {
          let n = null,
            r = null;
          return (
            Rn(e.floor) &&
              Pf(e.floor.currency) &&
              ((n = new Bf(e.floor.value, e.floor.currency, !0).asUnits("EUR")),
              (r = new Bf(e.floor.value, e.floor.currency, !0).asUnits("USD"))),
            {
              id: e.slotID,
              floor: n,
              floorUsd: r,
              bids: (t ?? [])
                .filter((t) => t.slotID === e.slotID)
                .map((e) => ({
                  cpm: uh(
                    Hf(
                      e,
                      $i.getBidderDiscrepancyForSession(
                        "amazon",
                        "video" === e.mediaType ? "video" : "banner"
                      )
                    )
                  ),
                  amznp: e.amznp,
                })),
            }
          );
        }),
        timedOut: !Rn(t),
        dollarRate: Yi(),
      };
    }
    setAmazonVideoBidResponses(e) {
      const t = this.adUnits.filter(Gh);
      if (t.length > 0) {
        const n = t[0],
          r = e.map((e) => n.getBids().processAmazonBidResponse(e)).filter(Rn),
          i = xf(
            r.map((e) => e.cpm),
            Ef()
          ),
          o = n.code();
        (this.adRequestResponse[o] = this.adRequestResponse[o] || { bids: [] }),
          i.isGreaterThanZero() &&
            this.adRequestResponse[o].bids.push({
              bidder: "amazon",
              cpm: uh(i),
              responseTime: Date.now(),
            }),
          n.getBids().setAmazonBidResponse(r),
          t.length > 1 &&
            Zn.warn("[apstag] got multiple video units, cant deal with those");
      }
    }
    setAmazonBannerBidResponses(e) {
      const t = this.adUnits.filter((e) => e.isBanner());
      e.forEach((e) => {
        const { slotID: n } = e,
          r = t.find((e) => e.code() === n);
        if (!Rn(r)) return void Zn.warn("[apstag] bid without matching unit");
        const i = r.getBids().processAmazonBidResponse(e);
        Rn(i) &&
          ((this.adRequestResponse[n] = this.adRequestResponse[n] || {
            bids: [],
          }),
          i.cpm.isGreaterThanZero() &&
            this.adRequestResponse[n].bids.push({
              bidder: "amazon",
              cpm: uh(i.cpm),
              responseTime: Date.now(),
            }),
          r.getBids().setAmazonBidResponse([i]));
      });
    }
    setupAndRequestPrebid() {
      this.noPrebidUnitsInAuction() || this.adRequester.getPrebidFailedToLoad()
        ? this.auctioneerRequestFinished("prebid")
        : Mn().que.push(() => {
            this.setPrebidBidderSettings(),
              this.prebidAddAdUnits(),
              this.prebidRequestBids();
          });
    }
    getAdFormat() {
      return this.adUnits[0]?.getAdFormat() ?? "banner";
    }
    setPrebidBidderSettings() {
      const e = Fn(),
        t = this.getAdFormat(),
        n = this.prebidBidders().reduce(
          (e, n) => {
            const r = $i.getBidderDiscrepancyForSession(n.code, t),
              i = $i.getBidderCostForSession(n.code, t);
            return Object.assign({}, e, n.getPrebidBidderSettings(i, r));
          },
          { standard: { storageAllowed: !1, suppressEmptyKeys: !0 } }
        );
      e.bidderSettings = n;
    }
    prebidAddAdUnits() {
      const e = Fn(),
        t = this.getRequestedPrebidAdUnits();
      t.forEach((t) => {
        e.removeAdUnit(t.code);
      }),
        e.addAdUnits(t);
    }
    prebidRequestBids() {
      const e = Fn();
      if (this.noPrebidBidRequestsInAuction())
        return void this.auctioneerRequestFinished("prebid");
      const t = this.getRequestedPrebidAdUnits();
      e.requestBids({
        adUnits: t,
        bidsBackHandler: (t, n, r) => {
          if (!Rn(t))
            return (
              Zn.debug("[Prebid] no responses"),
              void this.auctioneerRequestFinished("prebid")
            );
          this.prebidAuctionId = r;
          const i = this.adUnits.filter(Gh)[0] ?? null,
            o = i?.code() ?? null;
          ji(o)
            ? (this.adRequestResponse[o] = this.adRequestResponse[o] || {
                bids: [],
              })
            : this.adUnits.forEach((e) => {
                const t = e.code();
                this.adRequestResponse[t] = this.adRequestResponse[t] || {
                  bids: [],
                };
              }),
            Object.keys(t).forEach((e) => {
              const n = t[e]
                  .map(_f)
                  .map((e) => ({
                    bidder: e.bidderCode,
                    cpm: e.cpm,
                    responseTime: e.responseTimestamp,
                  })),
                r = o ?? e;
              (this.adRequestResponse[r] = this.adRequestResponse[r] || {
                bids: [],
              }),
                this.adRequestResponse[r].bids.push(...n);
            }),
            ph
              .getInstance()
              .filterBidResponses(e, t)
              .catch((e) => Zn.error("[Prebid] filterBidResponses failed", e))
              .finally(() => {
                this.auctioneerRequestFinished("prebid");
              });
        },
        timeout: this.options.timeout,
      });
    }
    getRequestedPrebidAdUnits() {
      return (
        Rn(this.prebidAdUnits) ||
          (this.prebidAdUnits = this.adUnits.flatMap((e) =>
            e.getBids().getPrebidUnits()
          )),
        this.prebidAdUnits
      );
    }
    async setupAndRequestApstag() {
      if (
        this.isAmazonNotIncludedInAuction() ||
        this.adRequester.getApstagFailedToLoad()
      )
        return void this.auctioneerRequestFinished("amazon");
      this.adRequester.loadAmazon(() => {
        !0 !== this.options.disableBlockthrough &&
          If.loadIfNeeded().catch(() => {}),
          this.auctioneerRequestFinished("amazon");
      }),
        await this.adRequester.initializeApstag(this.options),
        await (function () {
          const e = window;
          return e?.scheduler?.yield
            ? e.scheduler.yield()
            : new Promise((e) => {
                setTimeout(e, 100),
                  requestAnimationFrame(() => {
                    setTimeout(e, 0);
                  });
              });
        })();
      let e = null;
      try {
        const t = this.getRequestedApstagSlots(),
          n = { slots: t, timeout: this.options.timeout };
        Zn.debug(`[apstag] ${JSON.stringify(n)}`),
          (this.apstagRequestTimeoutHit = !1),
          (e = window.setTimeout(() => {
            Zn.debug("[apstag] timeout"),
              (this.apstagRequestTimeoutHit = !0),
              (this.amazonAuctionInformation =
                this.createAmazonAuctionInformation(t)),
              this.auctioneerRequestFinished("amazon");
          }, n.timeout + gp.amazonExtraTimeoutMs)),
          Dn().fetchBids(n, (n) => {
            Rn(e) && window.clearTimeout(e),
              this.apstagRequestTimeoutHit ||
                (Zn.debug("[apstag] bids back"),
                n.forEach((e) => {
                  Zn.debug(
                    `[apstag]${
                      Qf(e) ? "(no bids available)" : ""
                    } ${JSON.stringify(e)}`
                  );
                }),
                this.setAmazonBidResponses(
                  t,
                  n.filter((e) => !Qf(e))
                ),
                this.auctioneerRequestFinished("amazon"));
          });
      } catch (t) {
        Zn.error(t),
          Rn(e) && window.clearTimeout(e),
          this.auctioneerRequestFinished("amazon");
      }
    }
    getRequestedApstagSlots() {
      return (
        Rn(this.apstagSlots) ||
          (this.apstagSlots = this.adRequester.getApstagSlotsForUnits(
            this.adUnits
          )),
        this.apstagSlots
      );
    }
  }
  const lm = new (class {
    constructor() {
      this.cache = new Map();
    }
    getHighestBidForSlotIds(e, t) {
      return this.getHighestBid(this.getBidsForSlotIds(e, t));
    }
    getBidsForSlotIds(e, t) {
      let n =
        arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
      const r = [];
      for (const t of e) {
        const e = this.getBidsForSlot(t);
        e.length > 0 && r.push(...e);
      }
      return this.getBidsForSizes(r, t).filter(
        (e) => this.getExpirationTime(e) > Date.now() + n
      );
    }
    cacheBid(e, t) {
      if (!e.cpm.isGreaterThanZero()) return;
      const n = {
          ...e,
          receivedAt: Date.now(),
          used: !1,
          adFormat: t.adFormat,
        },
        r = this.getBidsForSlot(e.slotID) || [];
      this.cache.set(e.slotID, [...r, n]);
    }
    getBidsForSlot(e) {
      const t = this.cache.get(e);
      if (!Rn(t)) return [];
      const n = t.filter((e) => this.isValidBid(e));
      return (
        Zn.debug(
          `[AmazonBidCache] getBidsForSlot(${e})`,
          t,
          `${n.length} valid bids`
        ),
        this.cache.set(e, n),
        n
      );
    }
    markBidAsUsed(e) {
      Zn.debug("[AmazonBidCache] markBidAsUsed", e);
      let t = null;
      return (
        this.cache.forEach((n) => {
          n.forEach((n) => {
            n.amzniid === e &&
              (Zn.debug("[AmazonBidCache] Found bid to mark as used", n),
              (n.used = !0),
              (t = n));
          });
        }),
        t
      );
    }
    reset() {
      this.cache.clear();
    }
    getHighestBid(e) {
      return 0 === e.length
        ? null
        : e.reduce(
            (e, t) =>
              t.cpm.isGt(e.cpm) ||
              (t.cpm.isEq(e.cpm) && t.receivedAt < e.receivedAt)
                ? t
                : e,
            e[0]
          );
    }
    isValidBid(e) {
      return Date.now() < this.getExpirationTime(e) && !e.used;
    }
    getExpirationTime(e) {
      const t =
        "video" === e.adFormat
          ? mp.general.amazonBidCacheExpirationMs
          : hp.amazonBidCacheExpirationMs;
      return e.receivedAt + t;
    }
    getBidsForSizes(e, t) {
      if (0 === t.length) return e;
      const n = t.map((e) => `${e[0]}x${e[1]}`);
      return e.filter((e) => n.includes(e.amznsz));
    }
  })();
  const pm = class extends Bh {
    constructor(e) {
      super(), (this.unit = e);
    }
    resetPriceFloorsAndBids() {
      super.resetPriceFloorsAndBids();
    }
    getAmazonBidResponse() {
      return (
        Zn.debug(
          `[BannerBids] Unit: ${this.unit.code()}. Using Amazon bid cache with slot ids: ${
            this.apstagSlotIds
          }`
        ),
        lm.getHighestBidForSlotIds(this.apstagSlotIds, this.unit.getSizes())
      );
    }
    getCachedAmazonBidResponses(e) {
      return lm.getBidsForSlotIds(
        this.apstagSlotIds,
        this.unit.getSizes(),
        1e3 * e
      );
    }
    setAmazonBidResponse(e) {
      e.length > 1 &&
        Zn.warn(
          `[Bids] ${this.unit.code()} Multiple Amazon bids received for a banner when only one was expected`,
          e
        );
      const t = e[0];
      lm.cacheBid(t, { adFormat: "banner" });
    }
    getApstagSlots() {
      return Rn(this.apstagSlot) ? [this.apstagSlot] : void 0;
    }
    setApstagSlots() {
      if (Rn(this.apstagSlot)) {
        const e = this.getRequestPriceFloor();
        this.apstagSlot.floor = Jf(e);
      }
    }
    addApstagSlot(e) {
      this.apstagSlotIds.push(e);
      const { slotId: t } = this.unit.requestUnit;
      this.apstagSlot = { slotID: e, slotName: t, sizes: this.unit.getSizes() };
    }
    removeApstagSlots() {
      (this.apstagSlot = void 0), (this.apstagSlotIds = []);
    }
    slotId() {
      return Rn(this.slot) ? this.slot.getAdUnitPath() : null;
    }
    getSlot() {
      if (!Rn(this.slot))
        throw new Error(
          `[AdUnit] ${this.unit.code()} expected to have googletag slot`
        );
      return this.slot;
    }
    findSlot(e) {
      if (Rn(this.slot)) return this.slot;
      return jn()
        .pubads()
        .getSlots()
        .find((t) => t.getSlotElementId() === e);
    }
    defineSlot() {
      if (Rn(this.slot)) return;
      const e = jn(),
        t = this.findSlot(this.unit.elementId());
      if (Rn(t))
        return (
          Zn.warn(
            "[BannerBids defineSlot] unexpected existingSlot found for unit",
            this.unit.code(),
            t
          ),
          void (this.slot = t)
        );
      if (
        ((this.slot = e.defineSlot(
          this.unit.requestUnit.slotId,
          this.unit.getSizes(),
          this.unit.elementId()
        )),
        this.slot)
      )
        this.slot.addService(e.pubads());
      else {
        const e = this.findSlot(this.unit.elementId());
        this.slot = e;
      }
      Zn.debug("[BannerBids] Created slot", this.slot);
    }
    markSlotAsDestroyed() {
      this.slot = void 0;
    }
    setSlotTargeting(e) {
      const t = this.getSlot(),
        n = this.calculateAndStoreGooglePriceFloor(),
        r = {
          [er]: e.toString(),
          [tr]: Sh(n),
          ...this.getBidCacheGamKeyValues(),
        };
      return t.setConfig({ targeting: r }), t;
    }
    getPrebidPriceBuckets() {
      return th;
    }
  };
  var fm = class {
    enabled;
    maximumNumberOfConsecutiveProblematicAds;
    waitTimeMs;
    lastAdState = { success: !0 };
    constructor(e, t, n) {
      (this.enabled = e),
        (this.maximumNumberOfConsecutiveProblematicAds = t),
        (this.waitTimeMs = n);
    }
    processAd(e, t = Date.now()) {
      if (this.enabled)
        if ("success" === e) this.lastAdState = { success: !0 };
        else if (this.lastAdState.success)
          this.lastAdState = {
            success: !1,
            successiveFailureCount: 1,
            adTimestamp: t,
          };
        else {
          const e = this.hasTimePassed(this.lastAdState.adTimestamp, t)
            ? 0
            : this.lastAdState.successiveFailureCount;
          this.lastAdState = {
            success: !1,
            successiveFailureCount: e + 1,
            adTimestamp: t,
          };
        }
    }
    areAdsEnabled(e = Date.now()) {
      return (
        !this.enabled ||
        !!this.lastAdState.success ||
        this.lastAdState.successiveFailureCount <
          this.maximumNumberOfConsecutiveProblematicAds ||
        this.hasTimePassed(this.lastAdState.adTimestamp, e)
      );
    }
    getConsecutiveProblematicAdCount(e = Date.now()) {
      return !this.enabled ||
        this.lastAdState.success ||
        this.hasTimePassed(this.lastAdState.adTimestamp, e)
        ? 0
        : this.lastAdState.successiveFailureCount;
    }
    hasTimePassed(e, t) {
      return t >= e + this.waitTimeMs;
    }
  };
  function hm(e) {
    return Rn(e) && e.isBanner();
  }
  const mm = class extends Vh {
    unitHasBeenDisplayed = !1;
    unitIsFilled = !1;
    constructor(e, t) {
      super(e, t),
        (this.requestUnit = e),
        (this.requestOptions = t),
        (this.bids = new pm(this)),
        (this.consecutiveHouseAdsTracker = new fm(
          !0,
          hp.pauseAfterHouseAds.numberOfConsecutiveHouseAds,
          hp.pauseAfterHouseAds.pauseTimeMs
        ));
    }
    getBids() {
      return this.bids;
    }
    mediaType() {
      return this.requestUnit.adUnit.mediaTypes.banner;
    }
    isBanner() {
      return !0;
    }
    getAdFormat() {
      return "banner";
    }
    display() {
      this.unitHasBeenDisplayed ||
        ((this.unitHasBeenDisplayed = !0), jn().display(this.elementId()));
    }
    bidRequestParamsForBidder(e, t, n) {
      return e.customBannerBidRequestParams(t, this, n);
    }
    checkBidderSettings(e, t) {
      return t.checkBannerSettings(e, this);
    }
    canRender() {
      return this.consecutiveHouseAdsTracker.areAdsEnabled()
        ? 0 === this.numberOfImpressions
          ? { success: !0 }
          : this.getBids().hasAdsenseBidRendered()
          ? { success: !1, reason: "Adsense bid has already rendered" }
          : { success: !0 }
        : { success: !1, reason: "Too many consecutive house ads" };
    }
    async resetForNewAdsRequest(e, t) {
      let n = !1;
      if (
        ((function (e, t) {
          return t.some((t) => !e.some((e) => e[0] === t[0] && e[1] === t[1]));
        })(xh(this.requestUnit.adUnit), xh(e.adUnit)) &&
          (qn.debug(
            "[AdRequester] Remaking slots because new unit contains different banner sizes"
          ),
          await this.remakeSlot(),
          (n = !0)),
        this.bids.resetPriceFloorsAndBids(),
        (this.requestUnit = e),
        (this.requestOptions = t),
        !n &&
          this.numberOfImpressions > 0 &&
          this.numberOfImpressions % hp.maxImpressionsBeforeRemakingSlots === 0)
      )
        return (
          qn.debug(
            "[AdRequester] Remaking slots because of max impressions reached"
          ),
          this.remakeSlot()
        );
    }
    findSlot() {
      const { slotId: e } = this.requestUnit;
      return (
        e || qn.error(`[AdUnit] Missing Slotid for ${this.code()}`),
        this.bids.findSlot(this.elementId())
      );
    }
    getSlot() {
      return this.bids.getSlot();
    }
    slotId() {
      return this.bids.slotId();
    }
    defineSlot() {
      const { slotId: e } = this.requestUnit;
      e || qn.error(`[AdUnit] Missing Slotid for ${this.code()}`),
        this.bids.defineSlot();
    }
    markSlotAsDestroyed() {
      this.bids.markSlotAsDestroyed();
    }
    increaseNumberOfImpressions() {
      this.numberOfImpressions += 1;
    }
    increaseNumberOfRequests() {
      this.numberOfRequests += 1;
    }
    getUnitIsFilled() {
      return this.unitIsFilled;
    }
    setUnitIsFilled(e) {
      this.unitIsFilled = e;
    }
    renderedNonHouseAd() {
      qn.debug(`[BannerUnit] ${this.code()} rendered non house ad`),
        this.consecutiveHouseAdsTracker.processAd("success");
    }
    renderedHouseAd() {
      qn.debug(`[BannerUnit] ${this.code()} rendered house ad`),
        this.consecutiveHouseAdsTracker.processAd("problem");
    }
    setSlotTargeting() {
      this.bids.setSlotTargeting(this.numberOfImpressions);
    }
    invokeUnitRenderedCallback(e, t, n, r, i, o) {
      if (
        (qn.debug("[BannerUnit] invoking callback for rendered unit", o), Rn(o))
      )
        try {
          o({
            type: "UnitRendered",
            empty: e,
            size: t,
            code: this.code(),
            slotId: this.bids.slotId(),
            houseAd: n,
            minPrice: uh(this.bids.getMinPricePaidForUnit(n, e, r)),
            impressionCount: this.getNumberOfImpressions(),
            lineItemId: i,
            advertiserId: r,
          });
        } catch (e) {
          qn.error(
            `[BannerUnit] ${this.code()}, err in invoking callback for rendered unit`,
            e
          );
        }
    }
    invokeUnitNotRenderedCallback(e, t) {
      if (
        (qn.debug("[BannerUnit] invoking callback for not rendered unit", t),
        Rn(t))
      )
        try {
          t({
            type: "UnitNotRendered",
            empty: !0,
            size: [],
            code: this.code(),
            slotId: null,
            houseAd: !1,
            minPrice: 0,
            impressionCount: this.getNumberOfImpressions(),
            advertiserId: null,
            lineItemId: null,
            reason: e,
          });
        } catch (e) {
          qn.error(
            `[BannerUnit] ${this.code()}, err in invoking callback for not rendered unit`,
            e
          );
        }
    }
    remakeSlot() {
      return new Promise((e) => {
        Nn().cmd.push(() => {
          const t = jn(),
            n = this.findSlot();
          n &&
            (n.setConfig({ targeting: null }),
            t.destroySlots([n]),
            this.markSlotAsDestroyed(),
            this.defineSlot()),
            e();
        });
      });
    }
    includeBidderInAuctionIfEnabled(e, t) {
      const n = (this.requestUnit.bidders || []).find(
        (e) => e.bidder === t.code
      );
      Rn(n)
        ? t.includeBidderInAuctionForAdUnitIfEnabled(
            e,
            this,
            n,
            this.createBidOptions()
          )
        : t.includeBidderInAuctionForAdUnitIfEnabled(
            e,
            this,
            null,
            this.createBidOptions()
          );
    }
    createBidOptions() {
      return {
        type: "bannerBidOptions",
        pageUrl: this.requestOptions.pageUrl,
        dealTargeting: this.requestOptions.dealTargeting,
      };
    }
  };
  const gm = class {
    static createAdUnit(e, t) {
      const n = Zp(e),
        r = qp(e),
        i = e.adUnit.code;
      return (
        r && n && qn.warn(`[AdUnitFactory] ${i} has multiple formats`),
        r
          ? new mm(e, t)
          : n
          ? new $h(e, t)
          : (qn.error(`[AdUnitFactory] ${i} has no supported formats`), null)
      );
    }
  };
  const bm = new (class {
    listeners = [];
    listenerInstalled = !1;
    removeAllListeners() {
      (this.listeners = []), this.removeListener();
    }
    addListener(e) {
      this.installListener(), this.listeners.push(e);
    }
    installListener() {
      if (this.listenerInstalled) return;
      this.listenerInstalled = !0;
      jn().pubads().addEventListener("slotRenderEnded", this.internalListener);
    }
    removeListener() {
      if (!this.listenerInstalled) return;
      jn()
        .pubads()
        .removeEventListener("slotRenderEnded", this.internalListener),
        (this.listenerInstalled = !1);
    }
    internalListener = (e) => {
      this.listeners.forEach((t) => {
        t(e);
      });
    };
  })();
  function vm(e) {
    return e.nodeType === Node.ELEMENT_NODE;
  }
  const ym = new Set();
  function Am() {
    const e = Array.from(ym);
    if (
      ((function () {
        const e = jn().getConfig("targeting").targeting;
        return Rn(e) ? Object.keys(e) : [];
      })()
        .filter((t) => !e.includes(t))
        .forEach((e) =>
          Zn.debug(
            `[GoogleTagUtil]The following key which we didn't set would have been cleared with our blanket clearing: ${e} which has value ${
              jn().getConfig("targeting").targeting?.[e]
            }`
          )
        ),
      0 === e.length)
    )
      return;
    const t = {};
    e.forEach((e) => {
      (t[e] = null), ym.delete(e);
    }),
      jn().setConfig({ targeting: t });
  }
  const Cm = [
      138449654392, 138233616993, 138233616990, 138233681903, 138233616984,
      138233616981, 138233681900, 138233681897, 138233738059, 138233738062,
      138233681894,
    ],
    wm = [sr, ar, cr, dr, ur],
    Sm = Object.fromEntries(wm.map((e) => [e, null])),
    Im = { [ar]: "2", [dr]: "2" };
  const _m = class {
    renderListener = (() => bm)();
    googleTagEnabled = !1;
    constructor() {}
    render(e, t, n, r, i, o) {
      return (
        this.triggerCallbackForIgnoredUnits(t, i),
        this.renderImpl(e, n, r, i, o)
      );
    }
    triggerCallbackForIgnoredUnits(e, t) {
      0 !== e.length &&
        e.forEach((e) => {
          let { unit: n, reason: r } = e;
          try {
            n.invokeUnitNotRenderedCallback(r, t.banner?.callback);
          } catch (e) {
            qn.error(
              `[BannerRenderer] Error in callback for ignored unit ${n.code()}`,
              e
            );
          }
        });
    }
    renderImpl(e, t, n, r, i) {
      if (0 === e.length) return Promise.resolve();
      const { adsenseUnits: o, amazonAndPrebidUnits: s } =
        this.groupAdunitsByType(e);
      if (
        (o.length > 0 && this.renderAdsense(o, r.banner?.callback),
        0 === s.length)
      )
        return Promise.resolve();
      const a = this.processSlotRenderedEvent(
        e,
        xn.advertiserIds || [],
        r.banner || {}
      );
      return new Promise((e, r) => {
        Nn().cmd.push(() => {
          this.renderListener.removeAllListeners(),
            this.renderListener.addListener(a),
            s.forEach((e) => e.increaseNumberOfImpressions()),
            Am(),
            Mn().que.push(async () => {
              try {
                this.setAmazonTargeting(s, n),
                  this.createGamObjects(s, t),
                  this.setPrebidTargeting(s.flatMap((e) => e.getAllCodes())),
                  await this.showNonAdsenseAds(s, i),
                  e();
              } catch (e) {
                r(e);
              }
            });
        });
      });
    }
    renderAdsense(e, t) {
      qn.debug(
        `[BannerRenderer] Rendering AdSense for units: ${e
          .map((e) => e.code())
          .join(", ")}`
      ),
        e.forEach((e) => {
          e.getBids().setAdsenseRendered(),
            (function (e, t) {
              if (!Rn(t)) return;
              const n = e.code(),
                r = document.getElementById(n);
              if (!Rn(r))
                return void Zn.warn(
                  `[AdSenseRenderListener] cannot find element ${n}, so cannot attach a listener to it`
                );
              const i = r.querySelector("ins");
              if (!Rn(i))
                return void Zn.warn(
                  `[AdSenseRenderListener] cannot find ins element in ${n}, so cannot attach a listener to it`
                );
              const o = new MutationObserver((n) => {
                for (const r of n) {
                  const n = "data-ad-status";
                  if (
                    "attributes" === r.type &&
                    r.attributeName === n &&
                    vm(r.target)
                  ) {
                    const i = r.target.getAttribute(n);
                    return (
                      e.invokeUnitRenderedCallback(
                        "filled" !== i,
                        [],
                        !1,
                        null,
                        null,
                        t
                      ),
                      void o.disconnect()
                    );
                  }
                }
              });
              o.observe(i, { attributes: !0 });
            })(e, t),
            Gn.getInstance().getAdsenseWindow().push({});
        });
    }
    async showNonAdsenseAds(e, t) {
      const n = jn();
      (await Sf()) && !t && (await If.loadIfNeeded().catch(() => {})),
        e.forEach((e) => e.display()),
        e.length > 0 && n.pubads().refresh(e.map((e) => e.getSlot()));
    }
    createGamObjects(e, t) {
      this.enableGoogletag(), this.createGamTargets(e, t);
    }
    enableGoogletag() {
      if (this.googleTagEnabled) return;
      this.googleTagEnabled = !0;
      const e = jn();
      e.setConfig({ singleRequest: !0 }), e.enableServices();
    }
    createGamTargets(e, t) {
      Object.entries(t).forEach((e) => {
        let [t, n] = e;
        ji(t) && this.setGamTarget(t, n);
      }),
        e.forEach((e) => e.setSlotTargeting());
    }
    setGamTarget(e, t) {
      if (!Rn(t) || ("string" == typeof t && !ji(t))) return;
      let n;
      var r;
      qn.debug(`[googletag] Target ${e} ${t}`),
        (n = Array.isArray(t) ? t.map((e) => `${e}`) : `${t}`),
        Rn((r = { [e]: n })) &&
          (Object.keys(r).forEach((e) => ym.add(e)),
          jn().setConfig({ targeting: r }));
    }
    setAmazonTargeting(e, t) {
      e.forEach((e) => e.getSlot().setConfig({ targeting: Sm }));
      0 === t.length ||
        t.forEach((e) => {
          const t = jn()
            .pubads()
            .getSlots()
            .find((t) => t.getSlotElementId() === e.slotID);
          if (Rn(t)) {
            const n = lm.getHighestBidForSlotIds([e.slotID], e.sizes);
            if (Rn(n)) {
              const e = {};
              wm.forEach((t) => {
                const r = n[t];
                ji(r) && (e[t] = r);
              }),
                t.setConfig({ targeting: e });
            } else t.setConfig({ targeting: Im });
          } else
            qn.warn(
              `[BannerRenderer] No googletag slot found for apstag slot with ID ${e.slotID}`
            );
        });
    }
    setPrebidTargeting(e) {
      const t = Fn();
      0 === e.length ||
        (t.setTargetingForGPTAsync(e), t.registerSignalSources());
    }
    processSlotRenderedEvent(e, t, n) {
      return (r) => {
        const { advertiserId: i, slot: o, lineItemId: s } = r,
          a = e.filter((e) => e.slotId() === o.getAdUnitPath());
        if (0 === a.length)
          return void qn.warn(
            `[BannerRenderer] No matching unit for slot ${o.getAdUnitPath()}`
          );
        if (a.length > 1)
          return void qn.warn(
            `[BannerRenderer] Multiple units (${
              a.length
            }) for slot ${o.getAdUnitPath()}`
          );
        const c = a[0];
        c.getBids().isAdsenseIncludedInAuction() &&
          qn.warn(
            `[BannerRenderer] Received a googletag slotRenderEnded event for a unit with an AdSense bid: ${c.code()}`
          ),
          this.updateUnitFillState(
            { unit: c, bannerOptions: n },
            { event: r, slot: o }
          );
        const d = !c.getUnitIsFilled(),
          u = { size: r.size, isEmpty: d },
          l = this.checkIfHouseAd(i, t, c);
        this.updateAmazonState(r),
          c.invokeUnitRenderedCallback(u.isEmpty, u.size, l, i, s, n.callback);
      };
    }
    checkIfHouseAd(e, t, n) {
      const r = !Rn(e) || t.some((t) => t === e);
      return r ? n.renderedHouseAd() : n.renderedNonHouseAd(), r;
    }
    updateUnitFillState(e, t) {
      const { unit: n, bannerOptions: r } = e,
        { event: i, slot: o } = t;
      if (!1 === i.isEmpty) n.setUnitIsFilled(!0);
      else {
        const e = r.unitOptions?.[n.code()]?.clearSlotIfEmpty;
        !0 === e &&
          n.getUnitIsFilled() &&
          (jn().pubads().clear([o]), n.setUnitIsFilled(!1));
      }
    }
    updateAmazonState(e) {
      const t = e.slot.getSlotElementId(),
        n = e.slot.getConfig("targeting").targeting,
        r = Rn(n) ? n.amzniid : void 0,
        i = Array.isArray(r) ? r?.[0] : r;
      if (ji(i)) {
        const n = Dn().debug("getState"),
          r = e.slot.getResponseInformation(),
          o = Rn(r) ? e.slot.getHtml() : "",
          s = !(!o.includes("apstag.renderImp") || !o.includes(i)),
          a = Cm.includes(r?.creativeId ?? 0);
        s !== a &&
          qn.error(
            `[BannerRenderer] isAmazonWin (from the slot html) ${s} is not equal to isAmazonCreative (based on the banner creative ids) ${a}`
          ),
          s && lm.markBidAsUsed(i);
        (n?.slotBids?.[t] || []).forEach((e) => {
          const { bidConfig: t } = e;
          s && t.amzniid === i && (e.bidState = "RENDERED"),
            ((t.amzniid === i && "RENDERED" !== e.bidState) ||
              (t.amzniid !== i && "SET" === e.bidState)) &&
              (e.bidState = "EXPOSED");
        });
      }
    }
    groupAdunitsByType(e) {
      const t = [],
        n = [];
      return (
        e.forEach((e) => {
          e.getBids().isAdsenseIncludedInAuction() ? t.push(e) : n.push(e);
        }),
        { adsenseUnits: t, amazonAndPrebidUnits: n }
      );
    }
  };
  const km = class {
    constructor() {}
    async render(e, t, n, r) {
      t.forEach((e) => {
        n.video.callback({
          type: "UnitNotRendered",
          code: e.unit.code(),
          reason: e.reason,
        });
      }),
        await Promise.all(
          e.map(async (e) => {
            const t = await e.getBids().buildGamUrlWithConsent(Fn(), n, r);
            return (
              qn.debug(`[VideoRenderer] URL generated for ${e.code()}: ${t}`),
              e.invokeGamUrlConstructedCallback(t, n.video.callback)
            );
          })
        );
    }
  };
  const Pm = class {
    constructor() {
      (this.videoRenderer = new km()),
        (this.bannerRenderer = new _m()),
        (this.gamParams = this.defaultGamKeys()),
        (this.videoOptions = null),
        (this.bannerOptions = null);
    }
    async render(e, t, n, r) {
      const { video: i, banner: o } = this.splitUnitsByType(e),
        { video: s, banner: a } = this.splitIgnoredUnitsByType(t);
      (this.gamParams = Object.assign(this.defaultGamKeys(), n.gam)),
        (this.videoOptions = Object.assign(this.videoOptions ?? {}, n)),
        (this.bannerOptions = Object.assign(this.bannerOptions ?? {}, n)),
        await Promise.all([
          this.bannerRenderer.render(
            o,
            a,
            this.gamParams,
            r,
            this.bannerOptions,
            !0 === n.disableBlockthrough
          ),
          this.videoRenderer.render(i, s, this.videoOptions, this.gamParams),
        ]);
    }
    splitUnitsByType(e) {
      const t = { video: [], banner: [] };
      return (
        e.forEach((e) => {
          Gh(e) ? t.video.push(e) : t.banner.push(e);
        }),
        t
      );
    }
    splitIgnoredUnitsByType(e) {
      const t = { video: [], banner: [] };
      return (
        e.forEach((e) => {
          !(function (e) {
            return Gh(e.unit);
          })(e)
            ? t.banner.push(e)
            : t.video.push(e);
        }),
        t
      );
    }
    defaultGamKeys() {
      return Object.assign({}, En.advertising.gam || {});
    }
  };
  const Bm = new (class extends kp {
    constructor() {
      super("Liveramp");
    }
    getScriptLocations() {
      return [
        "https://ats-wrapper.privacymanager.io/ats-modules/f335ec38-f1f6-423b-8091-fe87576411ae/ats.js",
      ];
    }
    async shouldLoad() {
      return !0;
    }
  })();
  class Em {
    static instance = null;
    static getInstance() {
      return Rn(this.instance) || (this.instance = new Em()), this.instance;
    }
    loaderPromise = void 0;
    emailStored = !1;
    envelopeModuleReady = !1;
    constructor() {
      Br.getInstance().addEmailListenerAndInvoke(this.onEmailChange);
    }
    onEmailChange = (e, t) => {
      this.setupLoaderPromise(), e !== t && this.storeEmailOnWindow();
    };
    setupLoaderPromise() {
      this.isEnabled() &&
        !Rn(this.loaderPromise) &&
        (window.addEventListener(
          "envelopeModuleReady",
          this.onEnvelopeModuleReady
        ),
        (this.loaderPromise = Bm.loadIfNeeded()
          .then(() => {
            Mn().que.push(() => {
              Fn().enableAnalytics([
                { provider: "atsAnalytics", options: { pid: "13431" } },
              ]);
            });
          })
          .catch(() => {})));
    }
    storeEmailOnWindow() {
      const e = Br.getInstance().email;
      !this.emailStored &&
        Rn(this.loaderPromise) &&
        Rn(e) &&
        this.envelopeModuleReady &&
        ((this.emailStored = !0),
        this.loaderPromise.then(() => {
          window.ats.setAdditionalData({ type: "email", id: e });
        }));
    }
    onEnvelopeModuleReady = () => {
      (this.envelopeModuleReady = !0),
        this.storeEmailOnWindow(),
        window.removeEventListener(
          "envelopeModuleReady",
          this.onEnvelopeModuleReady
        );
    };
    isEnabled() {
      const e = Er();
      return (
        !Rn(e) ||
        [
          "AE",
          "AT",
          "AU",
          "BE",
          "BR",
          "CA",
          "CH",
          "DE",
          "DK",
          "ES",
          "FR",
          "GB",
          "HK",
          "ID",
          "IE",
          "IT",
          "JP",
          "MX",
          "NL",
          "NO",
          "NZ",
          "PL",
          "RO",
          "SE",
          "SG",
          "TW",
          "US",
        ].includes(e)
      );
    }
  }
  class xm {
    static instance = null;
    static getInstance() {
      return Rn(this.instance) || (this.instance = new xm()), this.instance;
    }
    constructor() {}
    isEnabled() {
      const e = Er(),
        t = Br.getInstance().email;
      return !!Rn(e) && !vp(e) && !("GB" === e) && Rn(t);
    }
  }
  class Tm {
    static instance = null;
    static getInstance() {
      return Rn(this.instance) || (this.instance = new Tm()), this.instance;
    }
    constructor() {}
    isEnabled() {
      const e = Er();
      return !!Rn(e) && (e === Ti.isoCode || e === Nr.isoCode);
    }
  }
  class Rm {
    static instance = null;
    static getInstance() {
      return Rn(this.instance) || (this.instance = new Rm()), this.instance;
    }
    constructor() {}
    isEnabled() {
      const e = Er();
      return (
        !!Rn(e) &&
        (!!vp(e) ||
          e === ii.isoCode ||
          e === di.isoCode ||
          e === bi.isoCode ||
          e === Bi.isoCode ||
          e === xi.isoCode)
      );
    }
  }
  class zm {
    static instance = null;
    static getInstance() {
      return Rn(this.instance) || (this.instance = new zm()), this.instance;
    }
    constructor() {}
    isEnabled() {
      const e = Er(),
        t = Br.getInstance().emailHash;
      return (
        !!Rn(e) &&
        !!Rn(t) &&
        (e === Ti.isoCode ||
          e === xi.isoCode ||
          e === Rr.isoCode ||
          e === zr.isoCode ||
          e === Ur.isoCode ||
          e === Vr.isoCode ||
          e === $r.isoCode ||
          e === qr.isoCode ||
          e === Zr.isoCode ||
          e === Jr.isoCode ||
          e === Yr.isoCode ||
          e === Qr.isoCode ||
          e === Xr.isoCode ||
          e === ei.isoCode ||
          e === ri.isoCode ||
          e === oi.isoCode ||
          e === si.isoCode ||
          e === ci.isoCode ||
          e === ui.isoCode ||
          e === li.isoCode ||
          e === pi.isoCode ||
          e === hi.isoCode ||
          e === Ci.isoCode ||
          e === wi.isoCode ||
          e === Si.isoCode ||
          e === Ii.isoCode ||
          e === _i.isoCode ||
          e === ki.isoCode ||
          e === Pi.isoCode ||
          e === xr.isoCode ||
          e === Mr.isoCode ||
          e === Or.isoCode ||
          e === Fr.isoCode ||
          e === Lr.isoCode ||
          e === jr.isoCode ||
          e === Dr.isoCode ||
          e === Gr.isoCode ||
          e === Kr.isoCode ||
          e === Hr.isoCode ||
          e === Wr.isoCode ||
          e === ti.isoCode ||
          e === ni.isoCode ||
          e === ai.isoCode ||
          e === fi.isoCode ||
          e === gi.isoCode ||
          e === vi.isoCode ||
          e === yi.isoCode ||
          e === Ai.isoCode ||
          e === Ei.isoCode ||
          e === Ri.isoCode ||
          e === zi.isoCode ||
          e === Tr.isoCode ||
          e === mi.isoCode)
      );
    }
  }
  function Mm(e, t) {
    return (e?.email ?? void 0) !== t.email;
  }
  function Om(e, t) {
    return (e?.hashedEmail ?? void 0) !== t.hashedEmail;
  }
  const Fm = !1;
  const Um = {
      criteo: () => ({ shouldRefresh: Fm, value: { name: "criteo" } }),
      unifiedId: () => ({
        shouldRefresh: Fm,
        value: {
          name: "unifiedId",
          params: { partner: "c67xkla" },
          storage: { type: "cookie", name: "pbjs-unifiedid", expires: 60 },
        },
      }),
      id5Id: (e, t) => {
        const n = { 9: t.domain, 12: window.navigator.userAgent };
        return (
          Rn(t.hashedEmail) && (n[1] = t.hashedEmail),
          {
            shouldRefresh: Om(e, t),
            value: {
              name: "id5Id",
              params: {
                partner: 377,
                pd: btoa(new URLSearchParams(n).toString()),
              },
              storage: {
                type: "html5",
                name: "id5id",
                expires: 90,
                refreshInSeconds: 7200,
              },
            },
          }
        );
      },
      sharedId: () => ({
        shouldRefresh: Fm,
        value: {
          name: "sharedId",
          storage: { name: "sharedid", type: "html5", expires: 365 },
          params: {},
        },
      }),
      lotamePanoramaId: () => ({
        shouldRefresh: Fm,
        value: { name: "lotamePanoramaId", params: { clientId: "18200" } },
      }),
      hadronId: () => ({
        shouldRefresh: Fm,
        value: {
          name: "hadronId",
          params: { partnerId: 631 },
          storage: { type: "html5", name: "hadronId" },
        },
      }),
      pubProvidedId: (e, t) => {
        const n = Om(e, t);
        return Rn(t.hashedEmail) && ji(t.hashedEmail)
          ? {
              shouldRefresh: n,
              value: {
                name: "pubProvidedId",
                bidders: ["ozone"],
                params: {
                  eids: [
                    {
                      source: "ozoneproject.com",
                      uids: [
                        {
                          id: t.hashedEmail,
                          atype: 3,
                          ext: { stype: "ppuid" },
                        },
                      ],
                    },
                  ],
                },
              },
            }
          : { shouldRefresh: n, value: null };
      },
      uid2: (e, t) => {
        const n = Mm(e, t);
        return Rn(t.email)
          ? {
              shouldRefresh: n,
              value: {
                name: "uid2",
                params: {
                  email: t.email,
                  ...("prod" === Oi
                    ? {
                        subscriptionId: "riMWtTJCBu",
                        serverPublicKey:
                          "UID2-X-P-MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEjW+JEvJ+KsLeM9aimChBr//9M5kuzJ1Xcl6oC1hQ7K6S6ezNd1odmmLwViFqhyhZaW3OdLk4DaSuacb3jQHQDQ==",
                      }
                    : {
                        subscriptionId: "BqiByygVb1",
                        serverPublicKey:
                          "UID2-X-I-MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEBadWafCpLrydg5Ulc2NprnsZiXv66yiN+UsgSSx1k57SeTRcVvt0Z99gj0eaxiUyaDC830kUUlgU5tXNjCfZPg==",
                        uid2ApiBase: "https://operator-integ.uidapi.com",
                      }),
                },
              },
            }
          : { shouldRefresh: n, value: null };
      },
      liveIntentId: (e, t) => ({
        shouldRefresh: Mm(e, t),
        value: {
          name: "liveIntentId",
          bidders: [...pr],
          params: {
            emailHash: t.email ?? "",
            publisherId: "84896",
            requestedAttributesOverrides: {
              uid2: !0,
              pubmatic: !0,
              magnite: !0,
              index: !0,
              thetradedesk: !0,
              medianet: !0,
            },
          },
          storage: { name: "__tamLIResolveResult", type: "html5", expires: 1 },
        },
      }),
      identityLink: (e, t) => ({
        shouldRefresh: Mm(e, t),
        value: {
          name: "identityLink",
          params: { pid: "13431" },
          storage: {
            type: "cookie",
            name: "idl_env",
            expires: 1,
            refreshInSeconds: 1800,
          },
        },
      }),
      pairId: (e, t) => ({
        shouldRefresh: Mm(e, t),
        value: {
          name: "pairId",
          params: { liveramp: { storageKey: "_lr_pairId" } },
        },
      }),
      "33acrossId": (e, t) => ({
        shouldRefresh: Om(e, t),
        value: {
          name: "33acrossId",
          params: { pid: "001Pg0000087XvoIAE", hem: t.hashedEmail },
          storage: {
            name: "33acrossId",
            type: "cookie&html5",
            expires: 30,
            refreshInSeconds: 28800,
          },
        },
      }),
      euid: (e, t) => {
        const n = Mm(e, t);
        if (!Rn(t.email)) return { shouldRefresh: n, value: null };
        return {
          shouldRefresh: n,
          value: {
            name: "euid",
            params: {
              ...("true" ===
              new URLSearchParams(window.location.search).get("euid_test")
                ? {
                    euidApiBase: "https://integ.euid.eu/",
                    serverPublicKey:
                      "EUID-X-I-MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEYla1YQ6N+surF4Yjaax46mPxCv7ixCR0zd3AYV5D8nhEVbQOuhs+GGxp0rUVpucJGQxNvkINwdSeCTpyzLMtFA==",
                    subscriptionId: "QRtT141htm",
                  }
                : {
                    serverPublicKey:
                      "EUID-X-P-MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEBZ1zxBHi8unR6pBnnj+McmIeg+d6zvO2gsO4sX7j1sipH+RzZ1EpvuJHSd2FCU/EYL21/ryz7sKhTR+WiMlx5w==",
                    subscriptionId: "ofZzS1Fpi3",
                  }),
              email: t.email,
            },
          },
        };
      },
      publinkId: (e, t) => {
        const n = Om(e, t);
        return Rn(t.hashedEmail)
          ? {
              shouldRefresh: n,
              value: {
                name: "publinkId",
                storage: { type: "cookie", name: "pbjs_publink", expires: 30 },
                params: {
                  e: t.hashedEmail,
                  api_key: "30ffe912-3985-41a5-a8b0-58997a53dd8f",
                  site_id: "248574",
                },
              },
            }
          : { shouldRefresh: n, value: null };
      },
    },
    Nm = ["AD_ID", "PRICE_BUCKET", "UUID"],
    Lm = [...Nm];
  let jm;
  class Dm extends kp {
    constructor() {
      super("apsWebClient"), (this.amazonPublisherId = Tn());
    }
    static getInstance() {
      return Rn(jm) || (jm = new Dm()), jm;
    }
    async shouldLoad() {
      return !0;
    }
    getScriptLocations() {
      return [
        `https://config.aps.amazon-adsystem.com/configs/${encodeURIComponent(
          this.amazonPublisherId
        )}`,
        "https://client.aps.amazon-adsystem.com/publisher.js",
      ];
    }
  }
  function Vm() {
    return window.navigator.connection;
  }
  function Gm(e) {
    if (Rn(e)) {
      const t = Number.parseFloat(e);
      if (!isNaN(t)) return t;
    }
  }
  function $m(e) {
    if (Rn(e)) return wp(e)?.iso3Code;
  }
  function qm() {
    const e = window.navigator,
      t = window.screen,
      n = {
        h: t.height,
        w: t.width,
        pxratio: window.devicePixelRatio || 1,
        js: 1,
        geo: Zm(),
      };
    Rn(e.userAgent) && (n.ua = e.userAgent);
    const r = (function () {
      const e = Vm();
      if (!Rn(e)) return;
      const t = e.type,
        n = e.effectiveType;
      if ("wifi" === t) return Hm;
      if ("ethernet" === t) return Km;
      if ("cellular" === t) {
        if (!Rn(n)) return Wm;
        switch (n) {
          case "slow-2g":
          case "2g":
            return Jm;
          case "3g":
            return Ym;
          case "4g":
            return Qm;
        }
      }
      if (!Rn(n)) return;
      const r = Br.getInstance().clientInfo.device ?? "desktop";
      switch (n) {
        case "slow-2g":
        case "2g":
          return Jm;
        case "3g":
          return Ym;
        case "4g":
          return "desktop" === r ? Hm : Qm;
      }
    })();
    return Rn(r) && (n.connectiontype = r), n;
  }
  function Zm() {
    const e = Br.getInstance().clientInfo;
    return {
      country: $m(Er()),
      type: 2,
      lat: Gm(e.geo?.latitude),
      lon: Gm(e.geo?.longitude),
      region: e.geo?.regionCode ?? void 0,
      metro: e.geo?.metroCode ?? void 0,
      zip: e.geo?.postalCode ?? void 0,
      city: e.geo?.unlocode ?? void 0,
    };
  }
  const Km = 1,
    Hm = 2,
    Wm = 3,
    Jm = 4,
    Ym = 5,
    Qm = 6;
  class Xm {
    liverampFunctionality = (() => Em.getInstance())();
    uid2Functionality = (() => xm.getInstance())();
    thirtyThreeAcrossIdFunctionality = (() => Tm.getInstance())();
    euidFunctionality = (() => Rm.getInstance())();
    epsilonPublinkIdFunctionality = (() => zm.getInstance())();
    incrementalIdProviderTest = (() => ff.getInstance())();
    constructor(e) {
      (this.config = e),
        (this.sessionAdUnits = []),
        (this.renderer = new Pm()),
        (this.isApstagInitialized = !1),
        (this.isPrebidInitialized = !1),
        (this.isGoogletagInitialized = !1),
        (this.prebidFailedToLoad = !1),
        (this.apstagFailedToLoad = !1),
        Nn().cmd.push(() => {
          jn().setConfig({
            disableInitialLoad: !0,
            threadYield: "ENABLED_ALL_SLOTS",
          });
        }),
        (this.userInfoTrackerEmailListener = () => {
          if ("enabled" === jp("czyExpClientOptable4")) {
            const e = Br.getInstance().emailHash;
            if (Rn(e)) {
              const t = window;
              (t.optable = t.optable ?? {}),
                (t.optable.cmd = t.optable.cmd ?? []),
                t.optable.cmd.push(() => {
                  Rn(t.optable) &&
                    Rn(t.optable.identifyAndTokenize) &&
                    "function" == typeof t.optable.identifyAndTokenize &&
                    t.optable.identifyAndTokenize(e);
                });
            }
          }
        }),
        Br.getInstance().addEmailListenerAndInvoke(
          this.userInfoTrackerEmailListener
        );
    }
    destroy() {
      Br.getInstance().removeEmailListener(this.userInfoTrackerEmailListener);
    }
    async requestAds(e, t) {
      qn.debug("[AdRequester] Requesting ads", e, "with options", t),
        await Promise.all([
          Br.getInstance().updateEmail(t.user?.email ?? void 0),
          Br.getInstance().updateUserId(t.user?.id ?? void 0),
        ]),
        this.isPrebidInitialized || this.setStaticPrebidConfigurationOptions(),
        this.setDynamicPrebidConfigurationOptions(t);
      const n = [Xp(), fp.fetchConfig()];
      e.units.some((e) => qp(e)) &&
        n.push(
          xp.loadIfNeeded().catch(() => {
            !0 !== t.disableBlockthrough && If.loadIfNeeded().catch(() => {});
          })
        ),
        await Promise.allSettled(n),
        await this.createAndUpdateAdUnits(e, t);
      const r = e.codes ?? e.units.map((e) => e.adUnit.code),
        { unitsToInclude: i, unitsToSkip: o } = this.selectRequestedUnits(r);
      let s = i;
      s.some(hm) &&
        s.some(Gh) &&
        (qn.error(
          "[AdRequester] Mixing banner and video units is not support. Will only handle the banner units"
        ),
        (s = s.filter(hm)));
      const a = new um(this, this.config),
        c = await a.requestAds(s, t);
      return (
        qn.debug("[AdRequester] Finished requesting ads with result", c),
        {
          ...c,
          skippedAdUnits: o.map((e) => ({
            adUnitId: e.unit.code(),
            reason: e.reason,
          })),
        }
      );
    }
    reset() {
      this.sessionAdUnits = [];
      const e = On();
      return (
        Rn(e) && e.removeAdUnit(),
        (this.isPrebidInitialized = !1),
        (this.isGoogletagInitialized = !1),
        Oh.reset(),
        this.destroyGamSlots()
      );
    }
    async createAndUpdateAdUnits(e, t) {
      const n = [];
      e.units.map(async (e) => {
        const r = e.adUnit.code,
          i = this.sessionAdUnits.map((e) => e.code()).indexOf(r);
        if (i > -1) {
          const r = this.sessionAdUnits[i];
          if (hm(r) && qp(e))
            n.push(
              r
                .resetForNewAdsRequest(e, t)
                .then(() => r.increaseNumberOfRequests())
            );
          else {
            const n = gm.createAdUnit(e, t);
            this.sessionAdUnits[i] = n;
          }
        }
      }),
        n.length > 0 && (await Promise.all(n));
      const r = e.units
          .filter(
            (e) =>
              !this.sessionAdUnits.map((e) => e.code()).includes(e.adUnit.code)
          )
          .map((e) => gm.createAdUnit(e, t))
          .filter(Rn),
        i = r.filter((e) => e.isBanner());
      i.length > 0 && (await this.createGamSlots(i)),
        this.sessionAdUnits.push(...r);
    }
    convertToAdUnits(e) {
      return this.sessionAdUnits.filter((t) => e.includes(t.code()));
    }
    includeUnitInRequestWithReason(e) {
      return e.canRender();
    }
    selectRequestedUnits(e) {
      const t = this.convertToAdUnits(e),
        n = this.getAdFormat(t);
      if (!fr.some((e) => $i.isBidderEnabledForSession(e, n)))
        return {
          unitsToInclude: [],
          unitsToSkip: t.map((e) => ({
            unit: e,
            reason: "All bidders are disabled",
          })),
        };
      const r = [],
        i = [];
      for (const e of t) {
        const t = this.includeUnitInRequestWithReason(e);
        t.success ? r.push(e) : i.push({ unit: e, reason: t.reason });
      }
      return (
        qn.debug(
          `[AdRequester] Requesting ${t.length} units, of which ${r.length} can actually be rendered and will be included`,
          r.map((e) => e.code())
        ),
        { unitsToInclude: r, unitsToSkip: i }
      );
    }
    getAdFormat(e) {
      return e.some((e) => e.isVideo()) ? "video" : "banner";
    }
    setApstagConfig(e) {
      this.amazonConfig = e;
    }
    getPrebidFailedToLoad() {
      return this.prebidFailedToLoad;
    }
    getApstagFailedToLoad() {
      return this.apstagFailedToLoad;
    }
    includeEnabledBiddersInAuctionForAdUnits(e, t) {
      e.forEach((e) => {
        try {
          e.includeEnabledBiddersInAuction(this, t),
            t.some((e) => "amazon" === e.code) && e.setApstagSlots();
        } catch (t) {
          qn.error(
            `[AdRequest] ${e.code} error in includeBiddersInAuctionForAdUnits`,
            t
          );
        }
      });
    }
    loadScripts(e, t) {
      $p.loadIfNeeded().catch(() => {
        t ||
          If.loadIfNeeded(!0).catch(() => {
            qn.error("[AdRequester] Failed to load blockthrough");
          }),
          (this.prebidFailedToLoad = !0),
          e("prebid");
      }),
        t ||
          If.loadIfNeeded().catch(() => {
            qn.error("[AdRequester] Failed to load blockthrough");
          });
    }
    loadAdsenseIfIncludedInAuction() {
      this.sessionAdUnits.some((e) =>
        e.getBids().isAdsenseIncludedInAuction()
      ) &&
        Pp.loadIfNeeded().catch(() => {
          qn.error("[AdRequester] failed to load adsense");
        });
    }
    async loadAmazon(e) {
      qn.debug("[AdRequester] loading and initializing amazon");
      try {
        await Dm.getInstance().loadIfNeeded();
      } catch {
        qn.debug("[AdRequester] Apstag failed to load"),
          (this.apstagFailedToLoad = !0),
          e();
      }
    }
    setStaticPrebidConfigurationOptions() {
      (this.isPrebidInitialized = !0),
        Mn().que.push(() => {
          const e = Fn();
          var t;
          Hp()
            .filter(Kp)
            .forEach((t) => {
              const n = eg(t);
              Rn(n) && e.aliasBidder(n.alias, t, { gvlid: n.gvlid });
            }),
            e.setConfig({
              firstPartyData: {
                uaHints: [
                  "architecture",
                  "bitness",
                  "model",
                  "platformVersion",
                  "fullVersionList",
                ],
              },
              maxRequestsPerOrigin: gp.prebid.maxRequestsPerOrigin,
              minBidCacheTTL: gp.prebid.minBidCacheTTLSeconds,
              eventHistoryTTL: 60,
              gptPreAuction: { enabled: !1 },
              enableTIDs: !0,
              rubicon: { singleRequest: !0 },
              enableSendAllBids: !0,
              targetingControls: {
                allBidsCustomTargeting: !1,
                allowTargetingKeys: Lm,
                allowSendAllBidsTargetingKeys: Nm,
              },
              cache: {
                url: "https://doesnotmatter/we/use/a/local/cache",
                useLocal: !0,
              },
              userIdTargeting: { GAM: !0 },
              mediaTypePriceGranularity: {
                video: { buckets: oh },
                banner: { buckets: ih },
              },
              disableAjaxTimeout: !0,
              sendBidsControl: { bidLimit: gp.prebid.bidLimitPerBidder },
              ozone: { enhancedAdserverTargeting: !1 },
              aps: { accountID: "9e9bffbc-66c5-4b5b-89aa-4d839e05ce3a" },
              bidCacheFilterFunction:
                ((t = this.createPrebidBidCacheFilterFunction()),
                (e) => {
                  const n = ch(e, "video" === e.mediaType ? "video" : "banner");
                  return t(n);
                }),
            });
        });
    }
    setDynamicPrebidConfigurationOptions(e) {
      const { pageUrl: t } = e,
        n = this.getConsentConfig(),
        r = this.getRealTimeDataConfig(),
        { userSync: i, providersToRefresh: o } = this.getUserSyncConfig(e),
        s = this.getCurrencyModuleConfig(),
        a = this.createPrebidFloorsConfig();
      Mn().que.push(() => {
        Fn().setConfig({
          pageUrl: t,
          ortb2: this.ortb2Config(e) || void 0,
          useBidCache: !0,
          consentManagement: n,
          realTimeData: r,
          userSync: i,
          currency: s,
          floors: a,
        }),
          o.length > 0 && this.refreshPrebidUserIds(o);
      });
    }
    createPrebidFloorsConfig() {
      return {
        enforcement: {
          bidAdjustment: !0,
          enforceJS: !0,
          floorDeals: !0,
          enforcePBS: !0,
        },
      };
    }
    createPrebidBidCacheFilterFunction() {
      return (e) =>
        ((e) => e.cpm.isGreaterThanZero())(e) &&
        ((e) =>
          e.responseTimestamp + 1e3 * e.ttl + gp.prebid.bidTtlBufferMs >
          new Date().getTime())(e);
    }
    getConsentConfig() {
      const e = Er();
      if (ji(e))
        return bp(e)
          ? {
              gdpr: {
                cmpApi: "iab",
                timeout: gp.consentManagementTimeoutMs,
                defaultGdprScope: !0,
              },
            }
          : (function (e, t = !1) {
              return Ap(e, (e) => e.isoCode === Ti.isoCode, t);
            })(e)
          ? { gpp: { cmpApi: "iab", timeout: gp.consentManagementTimeoutMs } }
          : void 0;
    }
    getRealTimeDataConfig() {
      if ("enabled" === jp("czyExpClientOptable4"))
        return {
          auctionDelay: 50,
          dataProviders: [
            {
              name: "optable",
              waitForIt: !0,
              params: {
                handleRtd: async (e, t, n) => {
                  const r = window;
                  if (
                    Rn(r.optable) &&
                    Rn(r.optable.rtdBridge) &&
                    "function" == typeof r.optable.rtdBridge
                  )
                    return r.optable.rtdBridge(e, t, n);
                },
              },
            },
          ],
        };
    }
    isIdProviderEnabled(e) {
      switch (e) {
        case "uid2":
          return this.uid2Functionality.isEnabled();
        case "liveIntentId":
          return "enabled" === jp("czyExpClientLiveIntent");
        case "identityLink":
        case "pairId":
          return this.liverampFunctionality.isEnabled();
        case "33acrossId":
          return this.thirtyThreeAcrossIdFunctionality.isEnabled();
        case "euid":
          return this.euidFunctionality.isEnabled();
        case "publinkId":
          return this.epsilonPublinkIdFunctionality.isEnabled();
        case "criteo":
        case "unifiedId":
        case "id5Id":
        case "sharedId":
        case "lotamePanoramaId":
        case "hadronId":
        case "pubProvidedId":
          return !0;
      }
    }
    getUserSyncConfig(e) {
      const t = {
          idPriority: { uid2: ["uid2", "liveIntentId"] },
          syncDelay: gp.userSync.syncDelayMs,
          syncsPerBidder: gp.userSync.syncsPerBidder,
          retainConfig: !1,
        },
        n = Br.getInstance().email,
        r = Br.getInstance().emailHash,
        i = this.getPageUrlFromOptions(e),
        o = {
          email: n,
          hashedEmail: r,
          domain: Rn(i) ? new URL(i).hostname : "crazygames.com",
        },
        s = this.contextUsedForIdProviders;
      this.contextUsedForIdProviders = o;
      const a = mr
          .filter((e) => this.isIdProviderEnabled(e))
          .map((e) => ({ name: e, ...Um[e](s, o) })),
        c = a.map((e) => e.value).filter(Rn),
        d = a.filter((e) => e.shouldRefresh).map((e) => e.name);
      t.userIds = this.applyIncrementalIdProviderTest(c);
      const u = "sharedId",
        l = this.getEid(u);
      t.userIds.some((e) => e.name === u)
        ? (t.ppid = l)
        : qn.error(
            `Cannot find the ${u} identity provider, so will also not set the ppid for Google`
          );
      const p = pr.filter((e) => this.includeBidderInIframeUserSync(e));
      return (
        (t.filterSettings = { iframe: { bidders: p, filter: "include" } }),
        { userSync: t, providersToRefresh: d }
      );
    }
    getEid(e) {
      switch (e) {
        case "criteo":
          return "criteo.com";
        case "unifiedId":
          return "adserver.org";
        case "id5Id":
          return "id5-sync.com";
        case "sharedId":
          return "pubcid.org";
        case "lotamePanoramaId":
          return "crwdcntrl.net";
        case "hadronId":
          return "audigent.com";
        case "pubProvidedId":
          return "ozoneproject.com";
        case "uid2":
          return "uidapi.com";
        case "liveIntentId":
          return "liveintent.com";
        case "identityLink":
          return "liveramp.com";
        case "pairId":
          return "google.com";
        case "33acrossId":
          return "33across.com";
        case "euid":
          return "euid.eu";
        case "publinkId":
          return "epsilon.com";
      }
    }
    applyIncrementalIdProviderTest(e) {
      return (
        e.forEach((e) =>
          this.incrementalIdProviderTest.addToActualCandidates(e.name)
        ),
        e.filter(
          (e) => !this.incrementalIdProviderTest.isProviderDisabled(e.name)
        )
      );
    }
    getCurrencyModuleConfig() {
      return { adServerCurrency: "EUR", rates: { USD: { EUR: Yi() } } };
    }
    includeBidderInIframeUserSync(e) {
      switch (e) {
        case "ix":
        case "rubicon":
        case "msft":
        case "ttd":
        case "medianet":
        case "kargo":
          return !1;
        case "pubmatic":
        case "ozone":
        case "nexx360":
        case "equativ":
        case "aps":
          return !0;
      }
    }
    refreshPrebidUserIds(e) {
      const t = On();
      Rn(t) && t.refreshUserIds({ submoduleNames: e });
    }
    getPageUrlFromOptions(e) {
      const { pageUrl: t, ortb2Site: n } = e;
      return t || n?.page;
    }
    ortb2Config(e) {
      const { pageUrl: t, ortb2Site: n } = e,
        r = this.getPageUrlFromOptions(e);
      if (!ji(r)) return null;
      try {
        const e = new URL(r),
          t = n || {};
        if (
          ((t.page = r),
          (t.domain = e.host),
          Rn(t.content) && Rn(t.content.url))
        )
          try {
            const e = new URL(t.content.url);
            (e.search = ""), (t.content.url = e.toString());
          } catch {}
        const i = qm();
        return (
          (i.devicetype = (function () {
            switch (Br.getInstance().clientInfo.device ?? "desktop") {
              case "desktop":
                return 2;
              case "mobile":
                return 4;
              case "tablet":
                return 5;
            }
          })()),
          {
            site: t,
            user: { id: Br.getInstance().userIdHash, geo: Zm() },
            device: i,
          }
        );
      } catch {
        return qn.error(`[AdRequester] Invalid pageUrl ${t}`), null;
      }
    }
    async initializeApstag(e) {
      if (this.isApstagInitialized) return;
      this.isApstagInitialized = !0;
      const { params: t, ...n } = this.amazonConfig,
        r = { ...n, params: { ...t, videoAdServer: "DFP" } };
      qn.debug("[AdRequester] Settings apstag config", r), Dn().init(r);
    }
    createGamSlots(e) {
      return e.length > 0
        ? this.isGoogletagInitialized
          ? new Promise((t) => {
              Nn().cmd.push(() => {
                e.forEach((e) => e.defineSlot()), t();
              });
            })
          : ((this.isGoogletagInitialized = !0),
            new Promise((t) => {
              Nn().cmd.push(() => {
                jn().setConfig({
                  safeFrame: {
                    allowOverlayExpansion: !1,
                    allowPushExpansion: !1,
                    sandbox: !0,
                  },
                }),
                  e.forEach((e) => e.defineSlot()),
                  t();
              });
            }))
        : Promise.resolve();
    }
    destroyGamSlots() {
      const e = this.sessionAdUnits.filter((e) => e.isBanner());
      return 0 === e.length
        ? Promise.resolve()
        : new Promise((t) => {
            Nn().cmd.push(() => {
              const n = jn(),
                r = e.map((e) => e.findSlot()).filter(Rn);
              n.destroySlots(r),
                e.forEach((e) => e.markSlotAsDestroyed()),
                Am(),
                t();
            });
          });
    }
    async renderBids(e, t) {
      const n = this.getAdFormat(this.convertToAdUnits(e)),
        { unitsToInclude: r, unitsToSkip: i } = this.selectRequestedUnits(e),
        o = r,
        s = i;
      qn.debug("[AdRequester] Rendering", e, t),
        qn.debug("[AdRequester] Selected ad units", o),
        qn.debug("[AdRequester] Ignored ad units", s);
      const a = this.config.bidders.google,
        c = t;
      Rn(t.googleBidder) && (c.bidders = [t.googleBidder]);
      const d = cm.createBidder("google", a, t.bidders);
      this.includeEnabledBiddersInAuctionForAdUnits(o, [d]);
      const u = this.getApstagSlotsForUnits(o),
        l = o.length > 0 ? o[0].getAdType() : s[0].unit.getAdType();
      (t.gam = this.getGamKeyValues(t.gam || {}, n, l)),
        qn.debug("[AdRequester] Rendering bids", o, u),
        await this.renderer.render(o, s, t, u);
    }
    async renderBanners(e, t) {
      await this.renderBids(e, t);
    }
    async renderVideos(e, t) {
      await this.renderBids(e, t);
    }
    getApstagSlotsForUnits(e) {
      const t = [];
      return (
        e.forEach((e) => {
          const n = e.getApstagSlots();
          Rn(n) && n.length > 0 && t.push(...n);
        }),
        t
      );
    }
    getGamKeyValues(e, t, n) {
      const r = Oh.getAdditionalGAMKeyValuePairs(),
        i = $i.getIncrementalBidderGamKeys(t),
        o = this.incrementalIdProviderTest.getGamKeys(),
        s = $i.getSessionKVs(t),
        a = dp.getSessionKVs(n),
        c = Er();
      return Fh(e, r, i, o, s, a, {
        [Xn]: Rn(c) ? df.getInstance().getConsentInformation(c).state : void 0,
      });
    }
  }
  function eg(e) {
    switch (e) {
      case "msft":
      case "rubicon":
      case "ix":
      case "pubmatic":
      case "ozone":
      case "ttd":
      case "nexx360":
      case "kargo":
      case "medianet":
      case "equativ":
      case "aps":
        return null;
    }
  }
  const tg = class {
      queue = [];
      _adRequester = null;
      killed = !1;
      queueRequest(e, t) {
        const n = Jp(),
          r = { type: "request", options: t, request: e, deferred: n };
        return this.enqueue(r), n.promise;
      }
      queueReset() {
        const e = Jp(),
          t = { type: "reset", deferred: e };
        return this.enqueue(t), e.promise;
      }
      queueNextPage() {
        this.killed = !0;
        const e = Jp(),
          t = { type: "nextPage", deferred: e };
        return this.enqueue(t), e.promise;
      }
      render(e, t) {
        return this.adRequester.renderBanners(e, t);
      }
      getVideoRenderingInformation(e, t) {
        return this.adRequester.renderVideos(e, t);
      }
      enqueue(e) {
        this.queue.push(e), 1 === this.queue.length && this.processQueue();
      }
      async processQueue() {
        if (this.queue.length <= 0) return;
        const e = this.queue[0];
        try {
          switch (e.type) {
            case "request":
              if (this.killed)
                e.deferred.reject(
                  new Error(
                    "Request queue has been killed. Not executing the ads request."
                  )
                );
              else {
                const t = await this.adRequester.requestAds(
                  e.request,
                  e.options
                );
                e.deferred.resolve(t);
              }
              break;
            case "reset":
              this.killed
                ? e.deferred.reject(
                    new Error(
                      "Request queue has been killed. Not executing the reset."
                    )
                  )
                : (await this.adRequester.reset(), e.deferred.resolve());
              break;
            case "nextPage":
              this.killed = !1;
              try {
                Rn(Ln()) &&
                  (await Promise.race([
                    new Promise((e) => {
                      Nn().cmd.push(function () {
                        jn().destroySlots(), e();
                      });
                    }),
                    hf(500, void 0),
                  ]));
              } catch {}
              this.destroyAdRequester(), e.deferred.resolve();
          }
        } catch (t) {
          Zn.error(t), e.deferred.reject();
        }
        return this.queue.shift(), this.processQueue();
      }
      get adRequester() {
        return (
          Rn(this._adRequester) || (this._adRequester = new Xm(En.advertising)),
          this._adRequester
        );
      }
      destroyAdRequester() {
        Rn(this._adRequester) &&
          (this._adRequester.destroy(), (this._adRequester = null));
      }
    },
    ng = "https://solutions.cdn.optable.co/crazygames/rtd-bridge.js";
  class rg {
    static instance = null;
    source = null;
    static getInstance() {
      return Rn(this.instance) || (this.instance = new rg()), this.instance;
    }
    setSource(e) {
      this.source = e;
    }
    getSource() {
      return this.source;
    }
  }
  let ig,
    og = !1;
  async function sg(e, t) {
    try {
      const n = (function () {
        Rn(ig) || (ig = new tg());
        return ig;
      })();
      return await n.queueRequest(e, t);
    } catch (e) {
      return (
        qn.error(e),
        {
          requestAdsResult: {},
          prebidAuctionInformation: void 0,
          amazonAuctionInformation: void 0,
          skippedAdUnits: [],
        }
      );
    }
  }
  async function ag(e, t) {
    try {
      if (!Rn(ig))
        throw new Error("[CrazyAds] Expected a request before a render");
      await ig.render(e, t);
    } catch (e) {
      qn.error(e);
    }
  }
  qn.debug(`[CrazyGamesAds] Loaded Version ${Tp}`);
  const cg = {
    requestAds: async function (e, t) {
      if (e.units.some((e) => Zp(e)))
        throw new Error("[CrazyAds] Video ads are not supported in requestAds");
      const { banner: n, gam: r, ...i } = t,
        o = { ...i };
      try {
        const t = await sg(e, o),
          i = e.codes || e.units.map((e) => e.adUnit.code);
        return await ag(i, { banner: n || {}, gam: r }), t.requestAdsResult;
      } catch (e) {
        return qn.error(e), {};
      }
    },
    requestOnly: sg,
    reset: async function () {
      try {
        if (!Rn(ig))
          throw new Error("[CrazyAds] Expected a request before a reset");
        await ig.queueReset();
      } catch (e) {
        qn.error(e);
      }
    },
    render: ag,
    getVideoRenderingInformation: async function (e, t) {
      if (!Rn(ig))
        throw new Error("[CrazyAds] Expected a request before a render");
      return ig.getVideoRenderingInformation([e], t);
    },
    nextPage: function () {
      Rn(ig) && ig.queueNextPage().catch(() => {});
    },
    hasAdblock: Sf,
    initAds: function (e) {
      if ((qn.debug("initialising ads", e), og)) return;
      var t;
      (og = !0),
        rg.getInstance().setSource(e.source),
        (t = e.configCatValues ?? {}),
        (Np = t),
        Wi.getInstance().init(e.analyticsEventHandler);
      const n = e.clientInfo ?? { country: Ti.isoCode };
      Br.getInstance().initClientInfo(n),
        fp.fetchConfig().catch(() => {}),
        xp.loadIfNeeded().catch(() => {}),
        Sf().catch(() => {}),
        Xp()
          .catch(() => {})
          .then(() => {
            df.getInstance();
          }),
        "enabled" === jp("czyExpClientOptable4") &&
          (function (e) {
            const t = window;
            return Rn(t.__czyOptableScripts)
              ? t.__czyOptableScripts
              : t.top !== t
              ? ((t.__czyOptableScripts = e(ng)), t.__czyOptableScripts)
              : ((t.optable = t.optable ?? {}),
                (t.optable.cmd = t.optable.cmd ?? []),
                (t.optable.site = "crazygames-sdk"),
                (t.__czyOptableScripts = e(
                  "https://solutions.cdn.optable.co/crazygames/sdk.js"
                ).then(() => e(ng))),
                t.__czyOptableScripts);
          })(Sp).catch(() => {}),
        (window.liModuleEnabled = "enabled" === jp("czyExpClientLiveIntent")),
        $p.loadIfNeeded().catch(() => {}),
        Mn().que.push(() => {
          Fn().onEvent("auctionDebug", (e) => {
            const t = Wi.getInstance(),
              n = "WARNING" === e.type ? "warning" : "error",
              r = Array.from(e.arguments)
                .map((e) => JSON.stringify(e))
                .join(", ");
            t.sendInternalAdErrorEvent(n, "prebid", r);
          });
        });
    },
    getConsentInformation: function (e) {
      return df.getInstance().getConsentInformation(e);
    },
    addConsentChangedListener: function (e) {
      df.getInstance().addConsentListener(e);
    },
    removeConsentChangedListener: function (e) {
      df.getInstance().removeConsentListener(e);
    },
    hasEnabledBidders: async function (e) {
      return (
        await fp.fetchConfig(),
        fr.some((t) => $i.isBidderEnabledForSession(t, e))
      );
    },
    getGoogleBucketedPriceFloor: async function (e, t) {
      await fp.fetchConfig();
      const n = dh(dp.getFloorForSession(e));
      return Sh(Ih(Rn(t) ? n.createCopyWithAdjustedAmount((e) => e * t) : n));
    },
    queueGoogleTagCmd: function (e) {
      Nn().cmd.push(e);
    },
  };
  window.CrazygamesAds = cg;
})();
