(function () {
  "use strict";
  function e(a = document) {
    return a.createElement("img");
  }
  var f = [];
  function g() {
    var a = f;
    f = [];
    for (let b of a)
      try {
        b();
      } catch {}
  }
  function h(a = null) {
    return a && a.getAttribute("data-jc") === "26"
      ? a
      : document.querySelector('[data-jc="26"]');
  }
  var k = document; /* 
 
 Copyright The Closure Library Authors. 
 SPDX-License-Identifier: Apache-2.0 
*/
  function l() {
    var a = k.querySelectorAll(
      "link[data-reload-stylesheet][as=style][rel=preload]"
    );
    for (var b = 0; b < a.length; b++) {
      var c = a[b],
        d = "link",
        m = document;
      d = String(d);
      m.contentType === "application/xhtml+xml" && (d = d.toLowerCase());
      d = m.createElement(d);
      d.setAttribute("rel", "stylesheet");
      d.setAttribute("href", c.getAttribute("href"));
      k.head.appendChild(d);
    }
    if (a.length > 0 && !(Math.random() > 0.01)) {
      a =
        (a = h(document.currentScript)) &&
        a.getAttribute("data-jc-rcd") === "true"
          ? "pagead2.googlesyndication-cn.com"
          : "pagead2.googlesyndication.com";
      b =
        ((b = h(document.currentScript)) &&
          b.getAttribute("data-jc-version")) ||
        "unknown";
      a = `https://${a}/pagead/gen_204?id=jca&jc=26&version=${b}&sample=0.01`;
      b = window;
      if ((c = b.navigator))
        (c = b.navigator.userAgent),
          (c = !(!/Chrome/.test(c) || /Edge/.test(c)));
      c && typeof b.navigator.sendBeacon === "function"
        ? b.navigator.sendBeacon(a)
        : (b.google_image_requests || (b.google_image_requests = []),
          (c = e(b.document)),
          (c.src = a),
          b.google_image_requests.push(c));
    }
  }
  var n = h(document.currentScript);
  if (n == null) throw Error("JSC not found 26");
  var p = n.attributes;
  for (let a = p.length - 1; a >= 0; a--);
  var q = document;
  if (q.readyState === "complete" || q.readyState === "interactive") {
    if ((f.push(l), f.length === 1))
      if (window.Promise) Promise.resolve().then(g);
      else {
        let a = window.setImmediate;
        typeof a === "function" ? a(g) : setTimeout(g, 0);
      }
  } else q.addEventListener("DOMContentLoaded", l);
}.call(this));
