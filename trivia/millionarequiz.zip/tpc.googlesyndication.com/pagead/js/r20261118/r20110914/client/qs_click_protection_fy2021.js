(function () {
  "use strict";
  var aa = Object.defineProperty,
    ba = globalThis;
  function ca(a, b) {
    if (b)
      a: {
        var c = ba;
        a = a.split(".");
        for (var d = 0; d < a.length - 1; d++) {
          var e = a[d];
          if (!(e in c)) break a;
          c = c[e];
        }
        a = a[a.length - 1];
        d = c[a];
        b = b(d);
        b != d &&
          b != null &&
          aa(c, a, { configurable: !0, writable: !0, value: b });
      }
  }
  ca("Symbol.dispose", function (a) {
    return a ? a : Symbol("Symbol.dispose");
  }); /* 
 
 Copyright The Closure Library Authors. 
 SPDX-License-Identifier: Apache-2.0 
*/
  var m = this || self;
  function da(a, b) {
    function c() {}
    c.prototype = b.prototype;
    a.R = b.prototype;
    a.prototype = new c();
    a.prototype.constructor = a;
    a.S = function (d, e, h) {
      for (
        var f = Array(arguments.length - 2), g = 2;
        g < arguments.length;
        g++
      )
        f[g - 2] = arguments[g];
      return b.prototype[e].apply(d, f);
    };
  }
  function ea(a) {
    m.setTimeout(() => {
      throw a;
    }, 0);
  }
  var fa, t;
  a: {
    for (var ha = ["CLOSURE_FLAGS"], u = m, ia = 0; ia < ha.length; ia++)
      if (((u = u[ha[ia]]), u == null)) {
        t = null;
        break a;
      }
    t = u;
  }
  var ja = t && t[748402147];
  fa = ja != null ? ja : !0;
  function v(a, b) {
    Array.prototype.forEach.call(a, b, void 0);
  }
  var ka = void 0;
  function la(a, b = !1) {
    return b && Symbol.for && a
      ? Symbol.for(a)
      : a != null
      ? Symbol(a)
      : Symbol();
  }
  var ma = la(),
    w = la("m_m", !0);
  var x = la("jas", !0),
    na,
    oa = [];
  oa[x] = 7;
  na = Object.freeze(oa);
  var z = {};
  function A(a, b) {
    return b === void 0
      ? a.i !== B && !!(2 & (a.h[x] | 0))
      : !!(2 & b) && a.i !== B;
  }
  var B = {};
  Object.freeze({});
  function C(a) {
    a.T = !0;
    return a;
  }
  var pa = C((a) => typeof a === "number"),
    qa = C((a) => typeof a === "string"),
    ra = C((a) => typeof a === "function");
  var ua = C((a) => a >= sa && a <= ta),
    sa = BigInt(Number.MIN_SAFE_INTEGER),
    ta = BigInt(Number.MAX_SAFE_INTEGER);
  var va = Number.isFinite;
  function wa(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return va(a) ? a | 0 : void 0;
  }
  function xa(a, b, c) {
    if (a != null && a[w] === z) return a;
    if (Array.isArray(a)) {
      var d = a[x] | 0;
      c = d | (c & 32) | (c & 2);
      c !== d && (a[x] = c);
      return new b(a);
    }
  }
  function za(a) {
    return a;
  }
  function Aa(a, b, c, d) {
    var e = d !== void 0;
    d = !!d;
    var h = [],
      f = a.length,
      g = 4294967295,
      k = !1,
      q = !!(b & 64),
      l = q ? (b & 128 ? 0 : -1) : void 0;
    if (!(b & 1)) {
      var p = f && a[f - 1];
      p != null && typeof p === "object" && p.constructor === Object
        ? (f--, (g = f))
        : (p = void 0);
      !q ||
        b & 128 ||
        e ||
        ((k = !0), (g = (Ba ?? za)(g - l, l, a, p, void 0) + l));
    }
    b = void 0;
    for (e = 0; e < f; e++) {
      let n = a[e];
      if (n != null && (n = c(n, d)) != null)
        if (q && e >= g) {
          let r = e - l;
          (b ?? (b = {}))[r] = n;
        } else h[e] = n;
    }
    if (p)
      for (let n in p) {
        a = p[n];
        if (a == null || (a = c(a, d)) == null) continue;
        f = +n;
        let r;
        q && !Number.isNaN(f) && (r = f + l) < g
          ? (h[r] = a)
          : ((b ?? (b = {}))[n] = a);
      }
    b && (k ? h.push(b) : (h[g] = b));
    return h;
  }
  function Ca(a) {
    switch (typeof a) {
      case "number":
        return Number.isFinite(a) ? a : "" + a;
      case "bigint":
        return ua(a) ? Number(a) : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          let b = a[x] | 0;
          return a.length === 0 && b & 1 ? void 0 : Aa(a, b, Ca);
        }
        if (a != null && a[w] === z) return Da(a);
        return;
    }
    return a;
  }
  var Ba;
  function Da(a) {
    a = a.h;
    return Aa(a, a[x] | 0, Ca);
  }
  function Ea(a, b, c, d = 0) {
    if (a == null) {
      var e = 32;
      c ? ((a = [c]), (e |= 128)) : (a = []);
      b && (e = (e & -16760833) | ((b & 1023) << 14));
    } else {
      if (!Array.isArray(a)) throw Error("narr");
      e = a[x] | 0;
      if (fa && 1 & e) throw Error("rfarr");
      2048 & e && !(2 & e) && Fa();
      if (e & 256) throw Error("farr");
      if (e & 64) return (e | d) !== e && (a[x] = e | d), a;
      if (c && ((e |= 128), c !== a[0])) throw Error("mid");
      a: {
        c = a;
        e |= 64;
        var h = c.length;
        if (h) {
          var f = h - 1;
          let k = c[f];
          if (k != null && typeof k === "object" && k.constructor === Object) {
            b = e & 128 ? 0 : -1;
            f -= b;
            if (f >= 1024) throw Error("pvtlmt");
            for (var g in k)
              if (((h = +g), h < f)) (c[h + b] = k[g]), delete k[g];
              else break;
            e = (e & -16760833) | ((f & 1023) << 14);
            break a;
          }
        }
        if (b) {
          g = Math.max(b, h - (e & 128 ? 0 : -1));
          if (g > 1024) throw Error("spvt");
          e = (e & -16760833) | ((g & 1023) << 14);
        }
      }
    }
    a[x] = e | 64 | d;
    return a;
  }
  function Fa() {
    if (fa) throw Error("carr");
    if (ma != null) {
      var a = ka ?? (ka = {});
      var b = a[ma] || 0;
      b >= 5 ||
        ((a[ma] = b + 1),
        (a = Error()),
        a.__closure__error__context__984382 ||
          (a.__closure__error__context__984382 = {}),
        (a.__closure__error__context__984382.severity = "incident"),
        ea(a));
    }
  }
  function Ga(a, b) {
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      var c = a[x] | 0;
      a.length === 0 && c & 1
        ? (a = void 0)
        : c & 2 ||
          (!b || 4096 & c || 16 & c
            ? (a = D(a, c, !1, b && !(c & 16)))
            : ((a[x] |= 34), c & 4 && Object.freeze(a)));
      return a;
    }
    if (a != null && a[w] === z)
      return (
        (b = a.h),
        (c = b[x] | 0),
        A(a, c) ? a : Ha(a, b, c) ? Ia(a, b) : D(b, c)
      );
  }
  function Ia(a, b, c) {
    a = new a.constructor(b);
    c && (a.i = B);
    a.j = B;
    return a;
  }
  function D(a, b, c, d) {
    d ?? (d = !!(34 & b));
    a = Aa(a, b, Ga, d);
    d = 32;
    c && (d |= 2);
    b = (b & 16769217) | d;
    a[x] = b;
    return a;
  }
  function Ja(a) {
    var b = a.h,
      c = b[x] | 0;
    if (A(a, c)) {
      var d;
      Ha(a, b, c) ? (d = Ia(a, b, !0)) : (d = new a.constructor(D(b, c, !1)));
      a = d;
    }
    return a;
  }
  function Ka(a) {
    if (a.i !== B) return !1;
    var b = a.h;
    b = D(b, b[x] | 0);
    b[x] |= 2048;
    a.h = b;
    a.i = void 0;
    a.j = void 0;
    return !0;
  }
  function La(a, b) {
    b === void 0 && (b = a[x] | 0);
    b & 32 && !(b & 4096) && (a[x] = b | 4096);
  }
  function Ha(a, b, c) {
    return c & 2
      ? !0
      : c & 32 && !(c & 4096)
      ? ((b[x] = c | 2), (a.i = B), !0)
      : !1;
  }
  function F(a, b) {
    a = Ma(a.h, b);
    if (a !== null) return a;
  }
  function Na(a, b) {
    return Ma(a, 1, void 0, b);
  }
  function Ma(a, b, c, d) {
    if (b === -1) return null;
    var e = b + (c ? 0 : -1),
      h = a.length - 1;
    if (!(h < 1 + (c ? 0 : -1))) {
      if (e >= h) {
        var f = a[h];
        if (f != null && typeof f === "object" && f.constructor === Object) {
          c = f[b];
          var g = !0;
        } else if (e === h) c = f;
        else return;
      } else c = a[e];
      if (d && c != null) {
        d = d(c);
        if (d == null) return d;
        if (!Object.is(d, c)) return g ? (f[b] = d) : (a[e] = d), d;
      }
      return c;
    }
  }
  function Oa(a, b, c) {
    var d = a.length - 1;
    if (d >= 0 && 0 >= d) {
      let e = a[d];
      if (e != null && typeof e === "object" && e.constructor === Object)
        return (e[1] = c), b;
    }
    if (0 <= d) return (a[0] = c), b;
    c !== void 0 &&
      ((d = ((b ?? (b = a[x] | 0)) >> 14) & 1023 || 536870912),
      1 >= d ? c != null && (a[d + -1] = { [1]: c }) : (a[0] = c));
    return b;
  }
  function Pa(a, b) {
    var c = Qa,
      d = !1,
      e = Na(a, (h) => {
        var f = xa(h, c, b);
        d = f !== h && f != null;
        return f;
      });
    if (e != null) return d && !A(e) && La(a, b), e;
  }
  function Ra(a) {
    var b = a.h,
      c = b[x] | 0,
      d = Pa(b, c);
    if (d == null) return d;
    c = b[x] | 0;
    if (!A(a, c)) {
      let e = Ja(d);
      e !== d &&
        (Ka(a) && ((b = a.h), (c = b[x] | 0)),
        (d = e),
        (c = Oa(b, c, d)),
        La(b, c));
    }
    return d;
  }
  function G(a) {
    a = F(a, 1);
    return a == null || typeof a === "string" ? a : void 0;
  }
  function I(a, b) {
    a = F(a, b);
    return (
      (a == null || typeof a === "boolean"
        ? a
        : typeof a === "number"
        ? !!a
        : void 0) ?? !1
    );
  }
  function J(a, b) {
    return wa(F(a, b)) ?? 0;
  }
  function K(a, b) {
    a = F(a, b);
    return (a == null ? a : va(a) ? a | 0 : void 0) ?? 1;
  }
  var L = class {
    constructor(a) {
      this.h = Ea(a, void 0, void 0, 2048);
    }
    toJSON() {
      return Da(this);
    }
  };
  L.prototype[w] = z;
  L.prototype.toString = function () {
    return this.h.toString();
  };
  var Sa = class extends L {};
  function Ta(a) {
    var b = a.h,
      c = b;
    b = b[x] | 0;
    var d = !(a ? A(a, b) : 2 & b);
    d && a && Ka(a) && ((c = a.h), (b = c[x] | 0));
    a = Ma(c, 1);
    var e = Array.isArray(a) ? a : na,
      h = e === na ? 7 : e[x] | 0;
    a = h;
    2 & b && (a |= 2);
    var f = a | 1;
    if ((a = !(4 & f))) {
      var g = e,
        k = b;
      let q = !!(2 & f);
      q && (k |= 2);
      let l = !q,
        p = !0,
        n = 0,
        r = 0;
      for (; n < g.length; n++) {
        let E = xa(g[n], Sa, k);
        if (E instanceof Sa) {
          if (!q) {
            let H = A(E);
            l && (l = !H);
            p && (p = H);
          }
          g[r++] = E;
        }
      }
      r < n && (g.length = r);
      f |= 4;
      f = p ? f & -4097 : f | 4096;
      f = l ? f | 8 : f & -9;
    }
    f !== h && ((e[x] = f), 2 & f && Object.freeze(e));
    if (d && !(8 & f || (!e.length && (2 & f || (!(16 & f) && 32 & b))))) {
      if ((2 & f && 4 & f) || 256 & f)
        (e = [...e]),
          (d = f),
          (f = d = (2 & b ? d | 2 : d & -3) & -273),
          (b = Oa(c, b, e));
      d = e;
      h = f;
      for (g = 0; g < d.length; g++)
        (f = d[g]), (k = Ja(f)), f !== k && (d[g] = k);
      h |= 8;
      f = h = d.length ? h | 4096 : h & -4097;
      e[x] = f;
    }
    h = d = f;
    (2 & d && 4 & d) ||
      256 & d ||
      (2 & d || (!(16 & d) && 32 & b)
        ? ((d |=
            !e.length || (a && !(4096 & d)) || (32 & b && !(4096 & d || 16 & d))
              ? 2
              : 256),
          d !== h && (e[x] = d),
          Object.freeze(e))
        : ((d |= 16), d !== h && (e[x] = d)));
    2 & d || !(4096 & d || 16 & d) || La(c, b);
    return e;
  }
  var Qa = class extends L {};
  var Ua = class extends L {};
  function Va(a, b) {
    if (a)
      for (let c in a)
        Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a);
  }
  function Wa() {}
  function Xa(a) {
    var b = !1,
      c;
    return function () {
      b || ((c = a()), (b = !0));
      return c;
    };
  } /* 
 
 Copyright Google LLC 
 SPDX-License-Identifier: Apache-2.0 
*/
  var M = class {
      constructor(a) {
        this.h = a;
      }
      toString() {
        return this.h;
      }
    },
    Ya = new M("about:invalid#zClosurez");
  class Za {
    constructor(a) {
      this.P = a;
    }
  }
  function N(a) {
    return new Za((b) => b.substr(0, a.length + 1).toLowerCase() === a + ":");
  }
  var $a = new Za((a) => /^[^:]*([/?#]|$)/.test(a)),
    ab = N("http"),
    bb = N("https"),
    cb = N("ftp"),
    db = N("mailto"),
    eb = [N("data"), ab, bb, db, cb, $a];
  function fb(a = eb) {
    for (let b = 0; b < a.length; ++b) {
      let c = a[b];
      if (c instanceof Za && c.P("#")) return new M("#");
    }
  }
  function gb(a = eb) {
    return fb(a) || Ya;
  }
  var hb = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
  function ib(a = document) {
    return a.createElement("img");
  }
  var jb = [];
  function kb() {
    var a = jb;
    jb = [];
    for (let b of a)
      try {
        b();
      } catch {}
  }
  var lb = { capture: !0 },
    mb = { passive: !0 },
    nb = Xa(() => {
      var a = !1;
      try {
        let b = Object.defineProperty({}, "passive", {
          get() {
            a = !0;
          },
        });
        m.addEventListener("test", null, b);
      } catch (b) {}
      return a;
    });
  function ob(a) {
    return a ? (a.passive && nb() ? a : a.capture || !1) : !1;
  }
  function O(a, b, c, d) {
    typeof a.addEventListener === "function" && a.addEventListener(b, c, ob(d));
  }
  function pb(a) {
    var b = R;
    b.readyState === "complete" || b.readyState === "interactive"
      ? (jb.push(a),
        jb.length === 1 &&
          (window.Promise
            ? Promise.resolve().then(kb)
            : ((a = window.setImmediate), ra(a) ? a(kb) : setTimeout(kb, 0))))
      : b.addEventListener("DOMContentLoaded", a);
  }
  function qb(a, b, c = null, d = !1) {
    rb(a, b, c, d);
  }
  function rb(a, b, c, d) {
    a.google_image_requests || (a.google_image_requests = []);
    var e = ib(a.document);
    if (c || d) {
      let h = (f) => {
        c && c(f);
        if (d) {
          f = a.google_image_requests;
          var g = Array.prototype.indexOf.call(f, e, void 0);
          g >= 0 && Array.prototype.splice.call(f, g, 1);
        }
        typeof e.removeEventListener === "function" &&
          e.removeEventListener("load", h, ob());
        typeof e.removeEventListener === "function" &&
          e.removeEventListener("error", h, ob());
      };
      O(e, "load", h);
      O(e, "error", h);
    }
    e.src = b;
    a.google_image_requests.push(e);
  }
  function sb(a, b) {
    var c;
    if ((c = a.navigator))
      (c = a.navigator.userAgent), (c = !(!/Chrome/.test(c) || /Edge/.test(c)));
    c && typeof a.navigator.sendBeacon === "function"
      ? a.navigator.sendBeacon(b)
      : qb(a, b, void 0, !1);
  }
  function tb({ N: a = !1 } = {}) {
    return a
      ? "connect.pagead2.googlesyndication.com"
      : "pagead2.googlesyndication.com";
  }
  function ub(a = null) {
    return a && a.getAttribute("data-jc") === "23"
      ? a
      : document.querySelector('[data-jc="23"]');
  }
  function vb() {
    if (!(Math.random() > 0.01)) {
      var a = ub(document.currentScript);
      a =
        a && a.getAttribute("data-jc-rcd") === "true"
          ? "pagead2.googlesyndication-cn.com"
          : "pagead2.googlesyndication.com";
      var b =
        ((b = ub(document.currentScript)) &&
          b.getAttribute("data-jc-version")) ||
        "unknown";
      sb(
        window,
        `https://${a}/pagead/gen_204?id=jca&jc=23&version=${b}&sample=0.01`
      );
    }
  }
  var R = document,
    S = window;
  var wb = (a = []) => {
    m.google_logging_queue || (m.google_logging_queue = []);
    m.google_logging_queue.push([12, a]);
  };
  var xb = null;
  function yb() {
    var a = m.performance;
    return a && a.now && a.timing
      ? Math.floor(a.now() + a.timing.navigationStart)
      : Date.now();
  }
  function zb() {
    var a = m.performance;
    return a && a.now ? a.now() : null;
  }
  var Ab = class {
    constructor(a, b) {
      var c = zb() || yb();
      this.label = a;
      this.type = b;
      this.value = c;
      this.duration = 0;
      this.taskId = this.slotId = void 0;
      this.uniqueId = Math.random();
    }
  };
  var T = m.performance,
    Bb = !!(T && T.mark && T.measure && T.clearMarks),
    U = Xa(() => {
      var a;
      if ((a = Bb)) {
        var b;
        a = window;
        if (xb === null) {
          xb = "";
          try {
            let c = "";
            try {
              c = a.top.location.hash;
            } catch (d) {
              c = a.location.hash;
            }
            c && (xb = (b = c.match(/\bdeid=([\d,]+)/)) ? b[1] : "");
          } catch (c) {}
        }
        b = xb;
        a = !!b.indexOf && b.indexOf("1337") >= 0;
      }
      return a;
    });
  function Cb(a) {
    a &&
      T &&
      U() &&
      (T.clearMarks(`goog_${a.label}_${a.uniqueId}_start`),
      T.clearMarks(`goog_${a.label}_${a.uniqueId}_end`));
  }
  function Db(a, b, c, d, e) {
    var h = [];
    Va(a, (f, g) => {
      (f = Eb(f, b, c, d, e)) && h.push(`${encodeURIComponent(g)}=${f}`);
    });
    return h.join(b);
  }
  function Eb(a, b, c, d, e) {
    if (a == null) return "";
    b = b || "&";
    c = c || ",$";
    qa(c) && (c = c.split(""));
    if (a instanceof Array) {
      if ((d || (d = 0), d < c.length)) {
        let h = [];
        for (let f = 0; f < a.length; f++) h.push(Eb(a[f], b, c, d + 1, e));
        return h.join(c[d]);
      }
    } else if (typeof a === "object")
      return (
        e || (e = 0), e < 2 ? encodeURIComponent(Db(a, b, c, d, e + 1)) : "..."
      );
    return encodeURIComponent(String(a));
  }
  function Fb(a) {
    var b = 1;
    for (let c in a.i) c.length > b && (b = c.length);
    return 3997 - b - a.j.length - 1;
  }
  function Gb(a, b) {
    var c = Fb(a) - b.length;
    if (c < 0) return "";
    b = "";
    a.h.sort((h, f) => h - f);
    var d = null,
      e = "";
    for (let h = 0; h < a.h.length; h++) {
      let f = a.h[h],
        g = a.i[f];
      for (let k = 0; k < g.length; k++) {
        if (!c) {
          d = d == null ? f : d;
          break;
        }
        let q = Db(g[k], a.j, ",$");
        if (q) {
          q = e + q;
          if (c >= q.length) {
            c -= q.length;
            b += q;
            e = a.j;
            break;
          }
          d = d == null ? f : d;
        }
      }
    }
    a = "";
    d != null && (a = `${e}trn=${d}`);
    return b + a;
  }
  function Hb(a, b, c, d) {
    return Fb(a) - d.length < 0 ? "" : b + "//" + c + d + Gb(a, d);
  }
  var Ib = class {
    constructor() {
      this.j = "&";
      this.i = {};
      this.m = 0;
      this.h = [];
    }
  };
  function Jb(a, b, c) {
    if (Array.isArray(b))
      for (let d = 0; d < b.length; d++) Jb(a, String(b[d]), c);
    else
      b != null &&
        c.push(a + (b === "" ? "" : "=" + encodeURIComponent(String(b))));
  }
  class Kb {}
  function Lb() {
    var a = Mb,
      b = window.google_srt;
    b >= 0 && b <= 1 && (a.i = b);
  }
  function Nb(a) {
    var b = Mb;
    if (b.i < 1)
      try {
        let c;
        a instanceof Ib
          ? (c = a)
          : ((c = new Ib()),
            Va(a, (e, h) => {
              var f = c,
                g = f.m++,
                k = {};
              k[h] = e;
              e = [k];
              f.h.push(g);
              f.i[g] = e;
            }));
        let d = Hb(c, b.protocol, b.h(), b.path + "fccs&");
        d && (b.j ? sb(m, d) : qb(m, d));
      } catch (c) {}
  }
  var Ob = class {
    constructor(a, b, c, d = !1) {
      this.domain = a;
      this.path = b;
      this.j = d;
      this.protocol = "https:";
      this.i = Math.random();
    }
    h() {
      return this.domain;
    }
  };
  var Pb = [
    ab,
    bb,
    db,
    cb,
    $a,
    N("market"),
    N("itms"),
    N("intent"),
    N("itms-appss"),
  ];
  function Qb() {
    var a = `https://${tb({ N: Rb })}/pagead/gen_204`;
    return (b) => {
      b = { id: "unsafeurl", ctx: 625, url: b };
      var c = [];
      for (d in b) Jb(d, b[d], c);
      var d = c.join("&");
      if (d) {
        b = a.indexOf("#");
        b < 0 && (b = a.length);
        c = a.indexOf("?");
        let e;
        c < 0 || c > b ? ((c = b), (e = "")) : (e = a.substring(c + 1, b));
        b = [a.slice(0, c), e, a.slice(b)];
        c = b[1];
        b[1] = d ? (c ? c + "&" + d : d) : c;
        d = b[0] + (b[1] ? "?" + b[1] : "") + b[2];
      } else d = a;
      navigator.sendBeacon && navigator.sendBeacon(d, "");
    };
  }
  var Mb,
    Rb = !1;
  class Sb extends Ob {
    h() {
      return Rb ? tb({ N: !0 }) : super.h();
    }
  }
  var V = new (class {
    constructor(a, b) {
      this.h = [];
      this.j = b || m;
      var c = null;
      b &&
        ((b.google_js_reporting_queue = b.google_js_reporting_queue || []),
        (this.h = b.google_js_reporting_queue),
        (c = b.google_measure_js_timing));
      this.i = U() || (c != null ? c : Math.random() < a);
    }
    start(a, b) {
      if (!this.i) return null;
      a = new Ab(a, b);
      b = `goog_${a.label}_${a.uniqueId}_start`;
      T && U() && T.mark(b);
      return a;
    }
    end(a) {
      if (this.i && pa(a.value)) {
        a.duration = (zb() || yb()) - a.value;
        var b = `goog_${a.label}_${a.uniqueId}_end`;
        T && U() && T.mark(b);
        !this.i || this.h.length > 2048 || this.h.push(a);
      }
    }
  })(1, window);
  function Tb() {
    window.google_measure_js_timing ||
      ((V.i = !1),
      V.h !== V.j.google_js_reporting_queue &&
        (U() && v(V.h, Cb), (V.h.length = 0)));
  }
  (function (a) {
    Rb = !1;
    Mb =
      a ?? new Sb("pagead2.googlesyndication.com", "/pagead/gen_204?id=", 0.01);
    typeof window.google_srt !== "number" &&
      (window.google_srt = Math.random());
    Lb();
    window.document.readyState === "complete"
      ? Tb()
      : V.i &&
        O(window, "load", () => {
          Tb();
        });
  })();
  var Ub = () => {
      var a = R;
      try {
        return a.querySelectorAll("*[data-ifc]");
      } catch (b) {
        return [];
      }
    },
    Vb = (a, b) => {
      a &&
        Va(b, (c, d) => {
          a.style[d] = c;
        });
    },
    Wb = (a) => {
      var b = R.body,
        c = document.createDocumentFragment(),
        d = a.length;
      for (let e = 0; e < d; ++e) c.appendChild(a[e]);
      b.appendChild(c);
    };
  function Xb(a) {
    O(S, "message", (b) => {
      try {
        var c = JSON.parse(b.data);
      } catch (d) {
        return;
      }
      !c || c.googMsgType !== "ig" || a(c, b);
    });
  }
  function W() {
    this.i = this.i;
    this.j = this.j;
  }
  W.prototype.i = !1;
  W.prototype.dispose = function () {
    this.i || ((this.i = !0), this.m());
  };
  W.prototype[Symbol.dispose] = function () {
    this.dispose();
  };
  W.prototype.m = function () {
    if (this.j) for (; this.j.length; ) this.j.shift()();
  };
  function X(a, b, c) {
    W.call(this);
    this.o = a;
    this.A = b || 0;
    this.u = c;
    this.v = () => {
      this.h = 0;
      this.o && this.o.call(this.u);
    };
  }
  da(X, W);
  X.prototype.h = 0;
  X.prototype.m = function () {
    X.R.m.call(this);
    this.isActive() && m.clearTimeout(this.h);
    this.h = 0;
    delete this.o;
    delete this.u;
  };
  X.prototype.start = function (a) {
    this.isActive() && m.clearTimeout(this.h);
    this.h = 0;
    var b = this.v;
    a = a !== void 0 ? a : this.A;
    if (typeof b !== "function")
      if (b && typeof b.handleEvent == "function") b = b.handleEvent.bind(b);
      else throw Error("Invalid listener argument");
    this.h = Number(a) > 2147483647 ? -1 : m.setTimeout(b, a || 0);
  };
  X.prototype.isActive = function () {
    return this.h != 0;
  };
  var Yb = { display: "inline-block", position: "absolute" },
    Zb = {
      display: "none",
      width: "100%",
      height: "100%",
      top: "0",
      left: "0",
    };
  function Y(a, b) {
    a && (a.style.display = b ? "inline-block" : "none");
  }
  function $b(a, b) {
    if (a) return S.getComputedStyle(a).getPropertyValue(b);
  }
  function ac(
    { width: a, height: b },
    { x: c, y: d, width: e, height: h },
    { top: f, right: g, bottom: k, left: q }
  ) {
    return {
      top: Math.max(0, f - d),
      right: Math.max(0, c + e - (a - g)),
      bottom: Math.max(0, d + h - (b - k)),
      left: Math.max(0, q - c),
    };
  }
  function bc(a = "") {
    var b = { top: 0, right: 0, bottom: 0, left: 0 };
    a &&
      ((a = a.split(",")),
      a.length === 4 &&
        a.reduce((c, d) => c && !isNaN(+d), !0) &&
        ([b.top, b.right, b.bottom, b.left] = a.map((c) => +c)));
    return b;
  }
  function cc(a, b, c = 2147483647) {
    var d = R.createElement("div");
    Vb(d, { ...Yb, "z-index": String(c), ...b });
    I(a.data, 10) && O(d, "click", Wa);
    if (I(a.data, 11)) {
      a = R.createElement("a");
      b = Qb();
      c = gb(Pb);
      c === Ya && b("#");
      b = c;
      if (b instanceof M)
        if (b instanceof M) b = b.h;
        else throw Error("");
      else b = hb.test(b) ? b : void 0;
      b !== void 0 && (a.href = b);
      a.appendChild(d);
      return a;
    }
    return d;
  }
  function dc(a, b) {
    switch (K(b.l, 5)) {
      case 2:
        S.AFMA_Communicator?.addEventListener?.("onshow", () => {
          Z(a, b);
        });
        break;
      case 10:
        O(S, "i-creative-view", () => {
          Z(a, b);
        });
        break;
      case 4:
        O(R, "DOMContentLoaded", () => {
          Z(a, b);
        });
        break;
      case 8:
        Xb((c) => {
          c.rr && Z(a, b);
        });
        break;
      case 9:
        if ("IntersectionObserver" in S) {
          let c = new IntersectionObserver((d) => {
            for (let e of d)
              if (e.intersectionRatio > 0) {
                Z(a, b);
                break;
              }
          });
          c.observe(R.body);
          a.O.push(c);
        }
        break;
      case 11:
        S.AFMA_Communicator?.addEventListener?.("onAdVisibilityChanged", () => {
          Z(a, b);
        });
    }
  }
  function ec(a, b) {
    b = bc(b);
    var c = J(a.data, 9);
    a.o = [
      { width: "100%", height: b.top + c + "px", top: -c + "px", left: "0" },
      { width: b.right + c + "px", height: "100%", top: "0", right: -c + "px" },
      {
        width: "100%",
        height: b.bottom + c + "px",
        bottom: -c + "px",
        left: "0",
      },
      { width: b.left + c + "px", height: "100%", top: "0", left: -c + "px" },
    ].map((d) => cc(a, d, 9019));
  }
  function fc(a) {
    var b = m.oneAfmaInstance;
    b &&
      b.getNativeClickMeta().then((c) => {
        if (c) {
          var d = c.adViewRectangle;
          c = c.mediaViewRectangle;
          if (d && c && ((d = JSON.parse(d)), (c = JSON.parse(c)), d && c)) {
            c = ac(d, c, bc(G(a.l) ?? ""));
            d = a.l;
            c = `${c.top},${c.right},${c.bottom},${c.left}`;
            if (c != null && typeof c !== "string") throw Error();
            if (!Ka(d) && A(d, d.h[x] | 0)) throw Error();
            d = d.h;
            Oa(d, d[x] | 0, c);
          }
        }
      });
  }
  function hc(a) {
    var b = 0;
    for (let d of a.I) {
      let e = d.l,
        h = a.A[K(e, 5)];
      d.B || h === void 0 || (b = Math.max(b, h + J(e, 2)));
    }
    a.u && a.u.dispose();
    b -= Date.now();
    var c = a.i;
    b > 0
      ? (Y(c, !0),
        (a.u = new X(() => {
          Y(c, !1);
        }, b)),
        a.u.start())
      : Y(c, !1);
  }
  function Z(a, b) {
    if (!b.B) {
      var c = K(b.l, 5);
      a.A[c] = Date.now();
      I(b.l, 9) && (a.I.push(b), hc(a));
    }
  }
  function ic(a, b, c, d, e) {
    var [h, f] = [a / d - c.left, b / d - c.top];
    if (isNaN(h) || isNaN(f) || h < 0 || f < 0) return !1;
    a = c.width;
    c = c.height;
    return !(h >= e.left && a - h > e.right && f >= e.top && c - f > e.bottom);
  }
  function jc(a, b, c) {
    if (!a.h || !a.j || b.timeStamp - a.h.timeStamp >= 300) return !1;
    var d = new Map();
    v(a.j.changedTouches, (e) => {
      d.set(e.identifier, { x: e.clientX, y: e.clientY });
    });
    b = J(c.l, 11) || 10;
    for (let e of a.h.changedTouches)
      if (
        ((a = d.get(e.identifier)),
        !a || Math.abs(a.x - e.clientX) > b || Math.abs(a.y - e.clientY) > b)
      )
        return !0;
    return !1;
  }
  var lc = class {
    constructor() {
      var a = kc;
      this.o = [];
      this.u = this.i = null;
      this.I = [];
      this.data = null;
      this.G = [];
      this.m = [];
      this.v = [];
      this.A = {};
      this.O = [];
      this.j = this.h = null;
      this.K = "";
      this.H = this.J = !1;
      this.L = a["send-fccs"] === "true";
      this.K = a.qid || "";
      this.J = a["is-fsn"] === "true";
      this.H = a["d-no-p"] === "true";
    }
    init(a) {
      wb([a]);
      this.data = new Ua(a);
      a = Ra(this.data);
      v(Ta(a), (g) => {
        this.v.push({ D: 0, B: !1, F: 0, l: g, C: -1 });
      });
      this.m = Ub();
      var b = !1;
      a = this.m.length;
      for (let g = 0; g < a; ++g) {
        var c = new Qa(JSON.parse(this.m[g].getAttribute("data-ifc") || "[]"));
        v(Ta(c), (k) => {
          (this.H && K(k, 4) === 1) ||
            (this.v.push({ D: 0, B: !1, F: 0, l: k, C: g }),
            K(k, 4) === 1 && (b = !0));
        });
      }
      var d = (c = a = !1),
        e = I(this.data, 12),
        h = !1;
      for (var f of this.v) {
        let g = f.l;
        J(g, 2) > 0 && K(g, 5) > 0
          ? (!this.i && I(g, 9) && (this.i = cc(this, Zb)), dc(this, f))
          : (G(g) ?? "") && I(g, 9) && ec(this, G(g) ?? "");
        (G(g) ?? "") && ((a = !0), this.J && I(g, 13) && fc(f));
        J(g, 11) > 0 && (c = !0);
        I(g, 12) && (e = !0);
        I(g, 14) && (h = !0);
        K(g, 4) === 3 && (d = !0);
      }
      f = [];
      this.i && f.push(this.i);
      !b && f.push(...this.o);
      R.body && Wb(f);
      I(this.data, 13) &&
        pb(() => {
          var g = R.body.querySelectorAll(".amp-fcp, .amp-bcp");
          for (let k = 0; k < g.length; ++k)
            $b(g[k], "position") === "absolute" && Y(g[k], !1);
        });
      O(
        R,
        "click",
        (g) => {
          if (this.L) {
            var k = {
              cx: g.clientX,
              cy: g.clientY,
              et: Date.now(),
              qid: this.K,
            };
            var q = Kb;
            var l = "M";
            (q.M && q.hasOwnProperty(l)) || ((l = new q()), (q.M = l));
            q = [];
            !k.eid && q.length && (k.eid = q.toString());
            Nb(k);
            this.L = !1;
          }
          k = J(this.data, 15);
          if (
            k > 0 &&
            ((g.isTrusted === !1 && k & 1) ||
              (navigator.userActivation.hasBeenActive === !1 && k & 2) ||
              (navigator.userActivation.isActive === !1 && k & 4))
          )
            g.preventDefault ? g.preventDefault() : (g.returnValue = !1),
              g.stopImmediatePropagation(),
              vb();
          else {
            k = -1;
            q = [];
            for (var p of this.v) {
              l = p.C;
              var n = l !== -1;
              if (J(p.l, 3) <= k || p.B || (n && q[l] === !1)) continue;
              var r = !n || q[l] || this.m[l].contains(g.target);
              n && r && (q[l] = !0);
              if ((l = r))
                if (((l = g), (n = p.l), J(n, 2) > 0 && K(n, 5) > 0))
                  (l = this.A[K(n, 5)]),
                    (l = l !== void 0 && Date.now() < l + J(n, 2));
                else if (G(n) ?? "") {
                  {
                    r = (
                      p.C >= 0 ? this.m[p.C] : R.body
                    ).getBoundingClientRect();
                    let P = Number($b(R.body, "zoom") || "1");
                    n = r.height;
                    if (r.width > 0 && n > 0) {
                      var E = bc(G(p.l) ?? "");
                      n = ic(l.clientX, l.clientY, r, P, E);
                      var H = I(p.l, 12);
                      if (
                        this.h &&
                        (I(this.data, 12) || H) &&
                        l.timeStamp - this.h.timeStamp < 300
                      ) {
                        var Q = this.h.changedTouches[0];
                        Q = ic(Q.clientX, Q.clientY, r, P, E);
                        n = I(this.data, 16) || H ? n || Q : Q;
                      }
                      this.j &&
                        this.h &&
                        H &&
                        I(p.l, 14) &&
                        l.timeStamp - this.h.timeStamp < 300 &&
                        ((l = this.j.changedTouches[0]),
                        (l = ic(l.clientX, l.clientY, r, P, E)),
                        (n = n || l));
                      l = n;
                    } else l = !1;
                  }
                } else l = J(n, 11) > 0 ? jc(this, l, p) : !0;
              if (l) {
                var y = p;
                k = J(p.l, 3);
              }
            }
            if (y)
              switch (((p = y.l), K(p, 4))) {
                case 2:
                case 3:
                  g.preventDefault ? g.preventDefault() : (g.returnValue = !1);
                  k = Date.now();
                  k - y.F > 500 && ((y.F = k), ++y.D);
                  k = y.l;
                  if (J(k, 8) && y.D >= J(k, 8))
                    if (((y.B = !0), this.i && J(k, 2) > 0)) hc(this);
                    else if (this.o.length > 0 && (G(k) ?? ""))
                      for (var ya of this.o) Y(ya, !1);
                  vb();
                  ya = Da(p);
                  p = y = null;
                  this.h &&
                    g.timeStamp - this.h.timeStamp < 300 &&
                    ((y = this.j), (p = this.h));
                  for (let P of this.G) P(g, ya, y, p, this.A);
              }
          }
        },
        lb
      );
      (c || h || d) &&
        O(
          R,
          "touchstart",
          (g) => {
            this.j = g;
          },
          mb
        );
      ((a && e) || c || d) &&
        O(
          R,
          "touchend",
          (g) => {
            this.h = g;
          },
          mb
        );
    }
    registerCallback(a) {
      this.G.push(a);
    }
  };
  var mc = ub(document.currentScript);
  if (mc == null) throw Error("JSC not found 23");
  var kc,
    nc = {},
    oc = mc.attributes;
  for (let a = oc.length - 1; a >= 0; a--) {
    let b = oc[a].name;
    b.indexOf("data-jcp-") === 0 && (nc[b.substring(9)] = oc[a].value);
  }
  kc = nc;
  var pc = window;
  pc.googqscp = new lc();
  kc["init-data"] && pc.googqscp.init(JSON.parse(kc["init-data"]));
}.call(this));
