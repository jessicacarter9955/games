(function () {
  var n,
    aa =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            var b = function () {};
            b.prototype = a;
            return new b();
          },
    da =
      typeof Object.defineProperties == "function"
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          },
    fa = function (a) {
      a = [
        "object" == typeof globalThis && globalThis,
        a,
        "object" == typeof window && window,
        "object" == typeof self && self,
        "object" == typeof global && global,
      ];
      for (var b = 0; b < a.length; ++b) {
        var c = a[b];
        if (c && c.Math == Math) return c;
      }
      throw Error("a");
    },
    ha = fa(this),
    ia =
      "Int8 Uint8 Uint8Clamped Int16 Uint16 Int32 Uint32 Float32 Float64".split(
        " "
      );
  ha.BigInt64Array && (ia.push("BigInt64"), ia.push("BigUint64"));
  var ka = function (a, b) {
      if (b)
        for (var c = 0; c < ia.length; c++)
          ja(ia[c] + "Array.prototype." + a, b);
    },
    u = function (a, b) {
      b && ja(a, b);
    },
    ja = function (a, b) {
      var c = ha;
      a = a.split(".");
      for (var d = 0; d < a.length - 1; d++) {
        var e = a[d];
        if (!(e in c)) return;
        c = c[e];
      }
      a = a[a.length - 1];
      d = c[a];
      b = b(d);
      b != d &&
        b != null &&
        da(c, a, { configurable: !0, writable: !0, value: b });
    },
    ma;
  if (typeof Object.setPrototypeOf == "function") ma = Object.setPrototypeOf;
  else {
    var na;
    a: {
      var oa = { a: !0 },
        pa = {};
      try {
        pa.__proto__ = oa;
        na = pa.a;
        break a;
      } catch (a) {}
      na = !1;
    }
    ma = na
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError("b`" + a);
          return a;
        }
      : null;
  }
  var qa = ma,
    v = function (a, b) {
      a.prototype = aa(b.prototype);
      a.prototype.constructor = a;
      if (qa) qa(a, b);
      else
        for (var c in b)
          if (c != "prototype")
            if (Object.defineProperties) {
              var d = Object.getOwnPropertyDescriptor(b, c);
              d && Object.defineProperty(a, c, d);
            } else a[c] = b[c];
      a.Xh = b.prototype;
    },
    ra = function (a) {
      var b = 0;
      return function () {
        return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
      };
    },
    A = function (a) {
      var b =
        typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
      if (b) return b.call(a);
      if (typeof a.length == "number") return { next: ra(a) };
      throw Error("c`" + String(a));
    },
    sa = function (a) {
      if (!(a instanceof Array)) {
        a = A(a);
        for (var b, c = []; !(b = a.next()).done; ) c.push(b.value);
        a = c;
      }
      return a;
    },
    wa = function (a) {
      return ua(a, a);
    },
    ua = function (a, b) {
      a.raw = b;
      Object.freeze && (Object.freeze(a), Object.freeze(b));
      return a;
    },
    xa = function (a, b) {
      var c;
      b && !b.done && (c = a["return"]) && c.call(a);
    },
    ya = function (a, b) {
      return Object.prototype.hasOwnProperty.call(a, b);
    },
    C =
      typeof Object.assign == "function"
        ? Object.assign
        : function (a, b) {
            if (a == null) throw new TypeError("d");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
              var d = arguments[c];
              if (d) for (var e in d) ya(d, e) && (a[e] = d[e]);
            }
            return a;
          },
    za = function (a) {
      if (!(a instanceof Object)) throw new TypeError("e`" + a);
    },
    E = function () {
      this.yb = !1;
      this.oa = null;
      this.Gb = void 0;
      this.P = 1;
      this.ra = this.La = 0;
      this.Hc = this.T = null;
    };
  E.prototype.Ca = function () {
    if (this.yb) throw new TypeError("f");
    this.yb = !0;
  };
  E.prototype.zb = function (a) {
    this.Gb = a;
  };
  E.prototype.Va = function (a) {
    this.T = { Rd: a, fe: !0 };
    this.P = this.La || this.ra;
  };
  E.prototype.getNextAddressJsc = function () {
    return this.P;
  };
  E.prototype.getYieldResultJsc = function () {
    return this.Gb;
  };
  E.prototype.return = function (a) {
    this.T = { return: a };
    this.P = this.ra;
  };
  E.prototype["return"] = E.prototype.return;
  E.prototype.ug = function (a) {
    this.T = { Aa: a };
    this.ra < a ? ((this.P = a), (this.T = null)) : (this.P = this.ra);
  };
  E.prototype.jumpThroughFinallyBlocks = E.prototype.ug;
  E.prototype.yield = function (a, b) {
    this.P = b;
    return { value: a };
  };
  E.prototype.yield = E.prototype.yield;
  E.prototype.Ci = function (a, b) {
    a = A(a);
    var c = a.next();
    za(c);
    if (c.done) (this.Gb = c.value), (this.P = b);
    else return (this.oa = a), this.yield(c.value, b);
  };
  E.prototype.yieldAll = E.prototype.Ci;
  E.prototype.Aa = function (a) {
    this.P = a;
  };
  E.prototype.jumpTo = E.prototype.Aa;
  E.prototype.ke = function () {
    this.P = 0;
  };
  E.prototype.jumpToEnd = E.prototype.ke;
  E.prototype.Ie = function (a, b) {
    this.La = a;
    b != void 0 && (this.ra = b);
  };
  E.prototype.setCatchFinallyBlocks = E.prototype.Ie;
  E.prototype.Je = function (a) {
    this.La = 0;
    this.ra = a || 0;
  };
  E.prototype.setFinallyBlock = E.prototype.Je;
  E.prototype.vg = function (a, b) {
    this.P = a;
    this.La = b || 0;
  };
  E.prototype.leaveTryBlock = E.prototype.vg;
  E.prototype.Qd = function (a) {
    this.La = a || 0;
    a = this.T.Rd;
    this.T = null;
    return a;
  };
  E.prototype.enterCatchBlock = E.prototype.Qd;
  E.prototype.Gc = function (a, b, c) {
    c ? (this.Hc[c] = this.T) : (this.Hc = [this.T]);
    this.La = a || 0;
    this.ra = b || 0;
    this.T = null;
  };
  E.prototype.enterFinallyBlock = E.prototype.Gc;
  E.prototype.Zc = function (a, b) {
    b = this.Hc.splice(b || 0)[0];
    (b = this.T = this.T || b)
      ? b.fe
        ? (this.P = this.La || this.ra)
        : b.Aa != void 0 && this.ra < b.Aa
        ? ((this.P = b.Aa), (this.T = null))
        : (this.P = this.ra)
      : (this.P = a);
  };
  E.prototype.leaveFinallyBlock = E.prototype.Zc;
  E.prototype.Xf = function (a) {
    return new Aa(a);
  };
  E.prototype.forIn = E.prototype.Xf;
  var Aa = function (a) {
    this.Ug = a;
    this.Yb = [];
    for (var b in a) this.Yb.push(b);
    this.Yb.reverse();
  };
  Aa.prototype.bg = function () {
    for (; this.Yb.length > 0; ) {
      var a = this.Yb.pop();
      if (a in this.Ug) return a;
    }
    return null;
  };
  Aa.prototype.getNext = Aa.prototype.bg;
  var Ba = function (a) {
    this.m = new E();
    this.wh = a;
  };
  Ba.prototype.zb = function (a) {
    this.m.Ca();
    if (this.m.oa) return Ca(this, this.m.oa.next, a, this.m.zb);
    this.m.zb(a);
    return Da(this);
  };
  var Ea = function (a, b) {
    a.m.Ca();
    var c = a.m.oa;
    if (c)
      return Ca(
        a,
        "return" in c
          ? c["return"]
          : function (d) {
              return { value: d, done: !0 };
            },
        b,
        a.m.return
      );
    a.m.return(b);
    return Da(a);
  };
  Ba.prototype.Va = function (a) {
    this.m.Ca();
    if (this.m.oa) {
      var b = this.m.oa["throw"];
      if (b) return Ca(this, b, a, this.m.zb);
      a = this.m.oa;
      this.m.oa = null;
      try {
        if (a["return"]) {
          var c = a["return"]();
          za(c);
        }
        this.m.Va(new TypeError("g"));
      } catch (d) {
        this.m.Va(d);
      }
      return Da(this);
    }
    this.m.Va(a);
    return Da(this);
  };
  var Ca = function (a, b, c, d) {
      try {
        var e = b.call(a.m.oa, c);
        za(e);
        if (!e.done) return (a.m.yb = !1), e;
        var g = e.value;
      } catch (f) {
        return (a.m.oa = null), a.m.Va(f), Da(a);
      }
      a.m.oa = null;
      d.call(a.m, g);
      return Da(a);
    },
    Da = function (a) {
      for (; a.m.P; )
        try {
          var b = a.wh(a.m);
          if (b) return (a.m.yb = !1), { value: b.value, done: !1 };
        } catch (c) {
          (a.m.Gb = void 0), a.m.Va(c);
        }
      a.m.yb = !1;
      if (a.m.T) {
        b = a.m.T;
        a.m.T = null;
        if (b.fe) throw b.Rd;
        return { value: b.return, done: !0 };
      }
      return { value: void 0, done: !0 };
    },
    Fa = function (a) {
      this.next = function (b) {
        return a.zb(b);
      };
      this.throw = function (b) {
        return a.Va(b);
      };
      this.return = function (b) {
        return Ea(a, b);
      };
      this[Symbol.iterator] = function () {
        return this;
      };
    },
    Ga = function (a) {
      function b(d) {
        return a.next(d);
      }
      function c(d) {
        return a.throw(d);
      }
      return new Promise(function (d, e) {
        function g(f) {
          f.done ? d(f.value) : Promise.resolve(f.value).then(b, c).then(g, e);
        }
        g(a.next());
      });
    };
  u("Symbol", function (a) {
    if (a) return a;
    var b = function (g, f) {
      this.Xe = g;
      da(this, "description", { configurable: !0, writable: !0, value: f });
    };
    b.prototype.toString = function () {
      return this.Xe;
    };
    var c = "jscomp_symbol_" + ((Math.random() * 1e9) >>> 0) + "_",
      d = 0,
      e = function (g) {
        if (this instanceof e) throw new TypeError("h");
        return new b(c + (g || "") + "_" + d++, g);
      };
    return e;
  });
  u("Symbol.iterator", function (a) {
    if (a) return a;
    a = Symbol("Symbol.iterator");
    da(Array.prototype, a, {
      configurable: !0,
      writable: !0,
      value: function () {
        return Ia(ra(this));
      },
    });
    return a;
  });
  u("Symbol.asyncIterator", function (a) {
    return a ? a : Symbol("Symbol.asyncIterator");
  });
  u("Symbol.toStringTag", function (a) {
    return a ? a : Symbol("Symbol.toStringTag");
  });
  var Ia = function (a) {
      var b =
          (typeof Iterator != "undefined" &&
          Iterator.prototype &&
          !Iterator.prototype.next
            ? Iterator.prototype
            : null) || Object.prototype,
        c = aa(b);
      c.next = a;
      b[Symbol.iterator] ||
        (c[Symbol.iterator] = function () {
          return this;
        });
      return c;
    },
    Ja = function (a) {
      function b(c) {
        return Promise.resolve(c.value).then(function (d) {
          return { value: d, done: !!c.done };
        });
      }
      this[Symbol.asyncIterator] = function () {
        return this;
      };
      this[Symbol.iterator] = function () {
        return a;
      };
      this.next = function (c) {
        return new Promise(function (d) {
          d(a.next(c));
        }).then(b);
      };
      this["throw"] = function (c) {
        return new Promise(function (d, e) {
          var g = a["throw"];
          g !== void 0
            ? d(g.call(a, c))
            : ((d = a["return"]),
              d !== void 0 && d.call(a),
              e(new TypeError("i")));
        }).then(b);
      };
      a["return"] !== void 0 &&
        (this["return"] = function (c) {
          return new Promise(function (d) {
            d(a["return"](c));
          }).then(b);
        });
    },
    F = function () {
      for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
        b[c - a] = arguments[c];
      return b;
    };
  u("globalThis", function (a) {
    return a || ha;
  });
  u("Reflect.setPrototypeOf", function (a) {
    return a
      ? a
      : qa
      ? function (b, c) {
          try {
            return qa(b, c), !0;
          } catch (d) {
            return !1;
          }
        }
      : null;
  });
  u("Promise", function (a) {
    function b() {
      this.Fa = null;
    }
    function c(f) {
      return f instanceof e
        ? f
        : new e(function (h) {
            h(f);
          });
    }
    if (a) return a;
    b.prototype.Gd = function (f) {
      if (this.Fa == null) {
        this.Fa = [];
        var h = this;
        this.Hd(function () {
          h.Of();
        });
      }
      this.Fa.push(f);
    };
    var d = ha.setTimeout;
    b.prototype.Hd = function (f) {
      d(f, 0);
    };
    b.prototype.Of = function () {
      for (; this.Fa && this.Fa.length; ) {
        var f = this.Fa;
        this.Fa = [];
        for (var h = 0; h < f.length; ++h) {
          var k = f[h];
          f[h] = null;
          try {
            k();
          } catch (l) {
            this.hf(l);
          }
        }
      }
      this.Fa = null;
    };
    b.prototype.hf = function (f) {
      this.Hd(function () {
        throw f;
      });
    };
    var e = function (f) {
      this.ma = 0;
      this.Cb = void 0;
      this.ib = [];
      this.ie = !1;
      var h = this.Bc();
      try {
        f(h.resolve, h.reject);
      } catch (k) {
        h.reject(k);
      }
    };
    e.prototype.Bc = function () {
      function f(l) {
        return function (m) {
          k || ((k = !0), l.call(h, m));
        };
      }
      var h = this,
        k = !1;
      return { resolve: f(this.Ch), reject: f(this.kd) };
    };
    e.prototype.Ch = function (f) {
      if (f === this) this.kd(new TypeError("j"));
      else if (f instanceof e) this.Rh(f);
      else {
        a: switch (typeof f) {
          case "object":
            var h = f != null;
            break a;
          case "function":
            h = !0;
            break a;
          default:
            h = !1;
        }
        h ? this.Bh(f) : this.Vd(f);
      }
    };
    e.prototype.Bh = function (f) {
      var h = void 0;
      try {
        h = f.then;
      } catch (k) {
        this.kd(k);
        return;
      }
      typeof h == "function" ? this.Sh(h, f) : this.Vd(f);
    };
    e.prototype.kd = function (f) {
      this.Ke(2, f);
    };
    e.prototype.Vd = function (f) {
      this.Ke(1, f);
    };
    e.prototype.Ke = function (f, h) {
      if (this.ma != 0) throw Error("k`" + f + "`" + h + "`" + this.ma);
      this.ma = f;
      this.Cb = h;
      this.ma === 2 && this.Gh();
      this.Pf();
    };
    e.prototype.Gh = function () {
      var f = this;
      d(function () {
        if (f.Tg()) {
          var h = ha.console;
          typeof h !== "undefined" && h.error(f.Cb);
        }
      }, 1);
    };
    e.prototype.Tg = function () {
      if (this.ie) return !1;
      var f = ha.CustomEvent,
        h = ha.Event,
        k = ha.dispatchEvent;
      if (typeof k === "undefined") return !0;
      typeof f === "function"
        ? (f = new f("unhandledrejection", { cancelable: !0 }))
        : typeof h === "function"
        ? (f = new h("unhandledrejection", { cancelable: !0 }))
        : ((f = ha.document.createEvent("CustomEvent")),
          f.initCustomEvent("unhandledrejection", !1, !0, f));
      f.promise = this;
      f.reason = this.Cb;
      return k(f);
    };
    e.prototype.Pf = function () {
      if (this.ib != null) {
        for (var f = 0; f < this.ib.length; ++f) g.Gd(this.ib[f]);
        this.ib = null;
      }
    };
    var g = new b();
    e.prototype.Rh = function (f) {
      var h = this.Bc();
      f.Kb(h.resolve, h.reject);
    };
    e.prototype.Sh = function (f, h) {
      var k = this.Bc();
      try {
        f.call(h, k.resolve, k.reject);
      } catch (l) {
        k.reject(l);
      }
    };
    e.prototype.then = function (f, h) {
      function k(t, q) {
        return typeof t == "function"
          ? function (w) {
              try {
                l(t(w));
              } catch (z) {
                m(z);
              }
            }
          : q;
      }
      var l,
        m,
        r = new e(function (t, q) {
          l = t;
          m = q;
        });
      this.Kb(k(f, l), k(h, m));
      return r;
    };
    e.prototype.catch = function (f) {
      return this.then(void 0, f);
    };
    e.prototype.Kb = function (f, h) {
      function k() {
        switch (l.ma) {
          case 1:
            f(l.Cb);
            break;
          case 2:
            h(l.Cb);
            break;
          default:
            throw Error("l`" + l.ma);
        }
      }
      var l = this;
      this.ib == null ? g.Gd(k) : this.ib.push(k);
      this.ie = !0;
    };
    e.resolve = c;
    e.reject = function (f) {
      return new e(function (h, k) {
        k(f);
      });
    };
    e.race = function (f) {
      return new e(function (h, k) {
        for (var l = A(f), m = l.next(); !m.done; m = l.next())
          c(m.value).Kb(h, k);
      });
    };
    e.all = function (f) {
      var h = A(f),
        k = h.next();
      return k.done
        ? c([])
        : new e(function (l, m) {
            function r(w) {
              return function (z) {
                t[w] = z;
                q--;
                q == 0 && l(t);
              };
            }
            var t = [],
              q = 0;
            do
              t.push(void 0),
                q++,
                c(k.value).Kb(r(t.length - 1), m),
                (k = h.next());
            while (!k.done);
          });
    };
    return e;
  });
  u("Object.setPrototypeOf", function (a) {
    return a || qa;
  });
  u("Object.assign", function (a) {
    return a || C;
  });
  u("Symbol.dispose", function (a) {
    return a ? a : Symbol("Symbol.dispose");
  });
  u("Object.values", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) ya(b, d) && c.push(b[d]);
          return c;
        };
  });
  u("Iterator", function (a) {
    var b = Object.getPrototypeOf,
      c =
        typeof Symbol != "undefined" && Symbol.iterator && [][Symbol.iterator]
          ? [][Symbol.iterator]()
          : null;
    b = (c = c && b ? b(c) : null) && b ? b(c) : null;
    b === Object.prototype && (b = null);
    if (a && b && a.prototype === b) return a;
    var d = function () {
      if (!(this instanceof d) || this.constructor === d)
        throw new TypeError("m");
    };
    b && (d.prototype = b);
    da(d.prototype, "constructor", {
      configurable: !0,
      writable: !0,
      value: d,
    });
    d.prototype[Symbol.iterator] ||
      (d.prototype[Symbol.iterator] = function () {
        return this;
      });
    return d;
  });
  var Ka = function (a) {
      if (Object(a) !== a) throw new TypeError("n");
      return a;
    },
    La = function (a) {
      try {
        var b = a["return"];
        typeof b == "function" && b.call(a);
      } catch (c) {}
    },
    Ma = function (a, b) {
      b == null && (b = !0);
      return { value: a, done: b };
    },
    Na = null,
    Oa = function (a, b) {
      var c = Na;
      if (!c) {
        var d = function (e, g) {
          if (!e || e.Ph !== e) throw new TypeError("p");
          var f = e.ma;
          if (f === 3) throw new TypeError("f");
          if (f != 4) {
            e.ma = g && f == 1 ? 4 : 3;
            try {
              if (g) {
                var h = e.je,
                  k = h["return"];
                if (k != null) {
                  if (typeof k != "function") throw new TypeError("o");
                  Ka(k.call(h));
                }
              } else {
                var l = e.Le();
                if (l) return (e.ma = 2), l;
              }
            } finally {
              e.ma != 2 && ((e.ma = 4), (e.Le = e.je = null));
            }
          }
          return Ma();
        };
        c = Na = aa(Iterator.prototype);
        c.next = function () {
          return d(this, !1);
        };
        c.return = function () {
          return d(this, !0);
        };
        c[Symbol.toStringTag] = "Iterator Helper";
      }
      c = aa(c);
      c.Ph = c;
      c.ma = 1;
      c.je = a;
      c.Le = b;
      return c;
    },
    Pa = function (a, b) {
      Ka(a);
      if (typeof b != "function") throw (La(a), new TypeError("q"));
    },
    Qa = function (a, b, c) {
      Pa(a, b);
      b = a.next;
      for (var d = 0, e; !(e = Ka(b.call(a))).done; ) {
        try {
          var g = c(e.value, d++);
        } catch (f) {
          try {
            xa(a, e);
          } catch (h) {}
          throw f;
        }
        if (g) {
          c = a["return"];
          c != null && Ka(c.call(a));
          break;
        }
      }
    };
  u("Iterator.prototype.some", function (a) {
    return (
      a ||
      function (b) {
        var c = !1;
        Qa(this, b, function (d, e) {
          return (c = !!b(d, e));
        });
        return c;
      }
    );
  });
  var Ra = function (a, b) {
    a instanceof String && (a += "");
    var c = 0,
      d = !1;
    return Ia(function () {
      if (!d && c < a.length) {
        var e = c++;
        return { value: b(e, a[e]), done: !1 };
      }
      d = !0;
      return { done: !0, value: void 0 };
    });
  };
  u("Array.prototype.keys", function (a) {
    return a
      ? a
      : function () {
          return Ra(this, function (b) {
            return b;
          });
        };
  });
  var Sa = function (a, b, c) {
    Pa(a, b);
    var d = a.next,
      e = 0;
    return Oa(a, function () {
      for (;;) {
        var g = Ka(d.call(a));
        if (g.done) break;
        g = g.value;
        try {
          var f = b(g, e++);
        } catch (h) {
          throw (La(a), h);
        }
        if (!c || f) return Ma(c ? g : f, !1);
      }
    });
  };
  u("Iterator.prototype.map", function (a) {
    return (
      a ||
      function (b) {
        return Sa(this, b, !1);
      }
    );
  });
  u("Iterator.prototype.filter", function (a) {
    return (
      a ||
      function (b) {
        return Sa(this, b, !0);
      }
    );
  });
  u("Iterator.prototype.every", function (a) {
    return (
      a ||
      function (b) {
        var c = !0;
        Qa(this, b, function (d, e) {
          return !(c = !!b(d, e));
        });
        return c;
      }
    );
  });
  u("Iterator.prototype.forEach", function (a) {
    return (
      a ||
      function (b) {
        Qa(this, b, function (c, d) {
          b(c, d);
        });
      }
    );
  });
  u("WeakMap", function (a) {
    function b() {}
    function c(k) {
      var l = typeof k;
      return (l === "object" && k !== null) || l === "function";
    }
    function d(k) {
      if (!ya(k, g)) {
        var l = new b();
        da(k, g, { value: l });
      }
    }
    function e(k) {
      var l = Object[k];
      l &&
        (Object[k] = function (m) {
          if (m instanceof b) return m;
          Object.isExtensible(m) && d(m);
          return l(m);
        });
    }
    if (
      (function () {
        if (!a || !Object.seal) return !1;
        try {
          var k = Object.seal({}),
            l = Object.seal({}),
            m = new a([
              [k, 2],
              [l, 3],
            ]);
          if (m.get(k) != 2 || m.get(l) != 3) return !1;
          m.delete(k);
          m.set(l, 4);
          return !m.has(k) && m.get(l) == 4;
        } catch (r) {
          return !1;
        }
      })()
    )
      return a;
    var g = "$jscomp_hidden_" + Math.random();
    e("freeze");
    e("preventExtensions");
    e("seal");
    var f = 0,
      h = function (k) {
        this.xb = (f += Math.random() + 1).toString();
        if (k) {
          k = A(k);
          for (var l; !(l = k.next()).done; )
            (l = l.value), this.set(l[0], l[1]);
        }
      };
    h.prototype.set = function (k, l) {
      if (!c(k)) throw Error("r");
      d(k);
      if (!ya(k, g)) throw Error("s`" + k);
      k[g][this.xb] = l;
      return this;
    };
    h.prototype.get = function (k) {
      return c(k) && ya(k, g) ? k[g][this.xb] : void 0;
    };
    h.prototype.has = function (k) {
      return c(k) && ya(k, g) && ya(k[g], this.xb);
    };
    h.prototype.delete = function (k) {
      return c(k) && ya(k, g) && ya(k[g], this.xb) ? delete k[g][this.xb] : !1;
    };
    return h;
  });
  u("Map", function (a) {
    if (
      (function () {
        if (
          !a ||
          typeof a != "function" ||
          !a.prototype.entries ||
          typeof Object.seal != "function"
        )
          return !1;
        try {
          var h = Object.seal({ x: 4 }),
            k = new a(A([[h, "s"]]));
          if (
            k.get(h) != "s" ||
            k.size != 1 ||
            k.get({ x: 4 }) ||
            k.set({ x: 4 }, "t") != k ||
            k.size != 2
          )
            return !1;
          var l = k.entries(),
            m = l.next();
          if (m.done || m.value[0] != h || m.value[1] != "s") return !1;
          m = l.next();
          return !(
            m.done ||
            m.value[0].x != 4 ||
            m.value[1] != "t" ||
            !l.next().done
          );
        } catch (r) {
          return !1;
        }
      })()
    )
      return a;
    var b = new WeakMap(),
      c = function (h) {
        this[0] = {};
        this[1] = g();
        this.size = 0;
        if (h) {
          h = A(h);
          for (var k; !(k = h.next()).done; )
            (k = k.value), this.set(k[0], k[1]);
        }
      };
    c.prototype.set = function (h, k) {
      h = h === 0 ? 0 : h;
      var l = d(this, h);
      l.list || (l.list = this[0][l.id] = []);
      l.entry
        ? (l.entry.value = k)
        : ((l.entry = {
            next: this[1],
            Ba: this[1].Ba,
            head: this[1],
            key: h,
            value: k,
          }),
          l.list.push(l.entry),
          (this[1].Ba.next = l.entry),
          (this[1].Ba = l.entry),
          this.size++);
      return this;
    };
    c.prototype.delete = function (h) {
      h = d(this, h);
      return h.entry && h.list
        ? (h.list.splice(h.index, 1),
          h.list.length || delete this[0][h.id],
          (h.entry.Ba.next = h.entry.next),
          (h.entry.next.Ba = h.entry.Ba),
          (h.entry.head = null),
          this.size--,
          !0)
        : !1;
    };
    c.prototype.clear = function () {
      this[0] = {};
      this[1] = this[1].Ba = g();
      this.size = 0;
    };
    c.prototype.has = function (h) {
      return !!d(this, h).entry;
    };
    c.prototype.get = function (h) {
      return (h = d(this, h).entry) && h.value;
    };
    c.prototype.entries = function () {
      return e(this, function (h) {
        return [h.key, h.value];
      });
    };
    c.prototype.keys = function () {
      return e(this, function (h) {
        return h.key;
      });
    };
    c.prototype.values = function () {
      return e(this, function (h) {
        return h.value;
      });
    };
    c.prototype.forEach = function (h, k) {
      for (var l = this.entries(), m; !(m = l.next()).done; )
        (m = m.value), h.call(k, m[1], m[0], this);
    };
    c.prototype[Symbol.iterator] = c.prototype.entries;
    var d = function (h, k) {
        var l = k && typeof k;
        l == "object" || l == "function"
          ? b.has(k)
            ? (l = b.get(k))
            : ((l = "" + ++f), b.set(k, l))
          : (l = "p_" + k);
        var m = h[0][l];
        if (m && ya(h[0], l))
          for (h = 0; h < m.length; h++) {
            var r = m[h];
            if ((k !== k && r.key !== r.key) || k === r.key)
              return { id: l, list: m, index: h, entry: r };
          }
        return { id: l, list: m, index: -1, entry: void 0 };
      },
      e = function (h, k) {
        var l = h[1];
        return Ia(function () {
          if (l) {
            for (; l.head != h[1]; ) l = l.Ba;
            for (; l.next != l.head; )
              return (l = l.next), { done: !1, value: k(l) };
            l = null;
          }
          return { done: !0, value: void 0 };
        });
      },
      g = function () {
        var h = {};
        return (h.Ba = h.next = h.head = h);
      },
      f = 0;
    return c;
  });
  u("Set", function (a) {
    if (
      (function () {
        if (
          !a ||
          typeof a != "function" ||
          !a.prototype.entries ||
          typeof Object.seal != "function"
        )
          return !1;
        try {
          var c = Object.seal({ x: 4 }),
            d = new a(A([c]));
          if (
            !d.has(c) ||
            d.size != 1 ||
            d.add(c) != d ||
            d.size != 1 ||
            d.add({ x: 4 }) != d ||
            d.size != 2
          )
            return !1;
          var e = d.entries(),
            g = e.next();
          if (g.done || g.value[0] != c || g.value[1] != c) return !1;
          g = e.next();
          return g.done ||
            g.value[0] == c ||
            g.value[0].x != 4 ||
            g.value[1] != g.value[0]
            ? !1
            : e.next().done;
        } catch (f) {
          return !1;
        }
      })()
    )
      return a;
    var b = function (c) {
      this.sa = new Map();
      if (c) {
        c = A(c);
        for (var d; !(d = c.next()).done; ) this.add(d.value);
      }
      this.size = this.sa.size;
    };
    b.prototype.add = function (c) {
      c = c === 0 ? 0 : c;
      this.sa.set(c, c);
      this.size = this.sa.size;
      return this;
    };
    b.prototype.delete = function (c) {
      c = this.sa.delete(c);
      this.size = this.sa.size;
      return c;
    };
    b.prototype.clear = function () {
      this.sa.clear();
      this.size = 0;
    };
    b.prototype.has = function (c) {
      return this.sa.has(c);
    };
    b.prototype.entries = function () {
      return this.sa.entries();
    };
    b.prototype.values = function () {
      return this.sa.values();
    };
    b.prototype.keys = b.prototype.values;
    b.prototype[Symbol.iterator] = b.prototype.values;
    b.prototype.forEach = function (c, d) {
      var e = this;
      this.sa.forEach(function (g) {
        return c.call(d, g, g, e);
      });
    };
    return b;
  });
  u("Array.prototype.entries", function (a) {
    return a
      ? a
      : function () {
          return Ra(this, function (b, c) {
            return [b, c];
          });
        };
  });
  var Ta = function (a, b, c) {
    if (a == null) throw new TypeError("t`" + c);
    if (b instanceof RegExp) throw new TypeError("u`" + c);
    return a + "";
  };
  u("String.prototype.startsWith", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = Ta(this, b, "startsWith");
          b += "";
          var e = d.length,
            g = b.length;
          c = Math.max(0, Math.min(c | 0, d.length));
          for (var f = 0; f < g && c < e; ) if (d[c++] != b[f++]) return !1;
          return f >= g;
        };
  });
  u("Number.isFinite", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b !== "number"
            ? !1
            : !isNaN(b) && b !== Infinity && b !== -Infinity;
        };
  });
  u("String.prototype.repeat", function (a) {
    return a
      ? a
      : function (b) {
          var c = Ta(this, null, "repeat");
          if (b < 0 || b > 1342177279)
            throw new RangeError("Invalid count value");
          b |= 0;
          for (var d = ""; b; ) if ((b & 1 && (d += c), (b >>>= 1))) c += c;
          return d;
        };
  });
  u("Object.is", function (a) {
    return a
      ? a
      : function (b, c) {
          return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c;
        };
  });
  u("Array.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = this;
          d instanceof String && (d = String(d));
          var e = d.length;
          c = c || 0;
          for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
            var g = d[c];
            if (g === b || Object.is(g, b)) return !0;
          }
          return !1;
        };
  });
  u("String.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          return Ta(this, b, "includes").indexOf(b, c || 0) !== -1;
        };
  });
  u("Iterator.prototype.reduce", function (a) {
    return (
      a ||
      function (b) {
        var c = arguments.length > 1,
          d = arguments[1];
        Qa(this, b, function (e, g) {
          c ? (d = b(d, e, g)) : ((c = !0), (d = e));
        });
        if (!c) throw new TypeError("v");
        return d;
      }
    );
  });
  u("Object.entries", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) ya(b, d) && c.push([d, b[d]]);
          return c;
        };
  });
  u("Array.from", function (a) {
    return a
      ? a
      : function (b, c, d) {
          c =
            c != null
              ? c
              : function (h) {
                  return h;
                };
          var e = [],
            g =
              typeof Symbol != "undefined" &&
              Symbol.iterator &&
              b[Symbol.iterator];
          if (typeof g == "function") {
            b = g.call(b);
            for (var f = 0; !(g = b.next()).done; )
              e.push(c.call(d, g.value, f++));
          } else
            for (g = b.length, f = 0; f < g; f++) e.push(c.call(d, b[f], f));
          return e;
        };
  });
  u("Math.trunc", function (a) {
    return a
      ? a
      : function (b) {
          b = Number(b);
          if (isNaN(b) || b === Infinity || b === -Infinity || b === 0)
            return b;
          var c = Math.floor(Math.abs(b));
          return b < 0 ? -c : c;
        };
  });
  u("Array.prototype.findIndex", function (a) {
    return a
      ? a
      : function (b, c) {
          a: {
            var d = this;
            d instanceof String && (d = String(d));
            for (var e = d.length, g = 0; g < e; g++)
              if (b.call(c, d[g], g, d)) {
                b = g;
                break a;
              }
            b = -1;
          }
          return b;
        };
  });
  u("Array.prototype.fill", function (a) {
    return a
      ? a
      : function (b, c, d) {
          var e = this.length || 0;
          c < 0 && (c = Math.max(0, e + c));
          if (d == null || d > e) d = e;
          d = Number(d);
          d < 0 && (d = Math.max(0, e + d));
          for (c = Number(c || 0); c < d; c++) this[c] = b;
          return this;
        };
  });
  ka("fill", function (a) {
    return a ? a : Array.prototype.fill;
  });
  u("String.prototype.padStart", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = Ta(this, null, "padStart");
          b -= d.length;
          c = c !== void 0 ? String(c) : " ";
          return (
            (b > 0 && c
              ? c.repeat(Math.ceil(b / c.length)).substring(0, b)
              : "") + d
          );
        };
  });
  u("Number.MAX_SAFE_INTEGER", function () {
    return 9007199254740991;
  });
  u("Number.MIN_SAFE_INTEGER", function () {
    return -9007199254740991;
  });
  u("Number.isInteger", function (a) {
    return a
      ? a
      : function (b) {
          return Number.isFinite(b) ? b === Math.floor(b) : !1;
        };
  });
  u("Number.isSafeInteger", function (a) {
    return a
      ? a
      : function (b) {
          return Number.isInteger(b) && Math.abs(b) <= Number.MAX_SAFE_INTEGER;
        };
  });
  u("Math.log2", function (a) {
    return a
      ? a
      : function (b) {
          return Math.log(b) / Math.LN2;
        };
  });
  u("Number.isNaN", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b === "number" && isNaN(b);
        };
  });
  u("Array.prototype.values", function (a) {
    return a
      ? a
      : function () {
          return Ra(this, function (b, c) {
            return c;
          });
        };
  }); /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var Va = this || self,
    Wa = function (a) {
      var b = typeof a;
      return b != "object" ? b : a ? (Array.isArray(a) ? "array" : b) : "null";
    },
    Xa = function (a) {
      var b = Wa(a);
      return b == "array" || (b == "object" && typeof a.length == "number");
    },
    Ya = function (a) {
      var b = typeof a;
      return (b == "object" && a != null) || b == "function";
    },
    $a = function (a) {
      return a;
    },
    ab = function (a, b) {
      function c() {}
      c.prototype = b.prototype;
      a.Xh = b.prototype;
      a.prototype = new c();
      a.prototype.constructor = a;
      a.oj = function (d, e, g) {
        for (
          var f = Array(arguments.length - 2), h = 2;
          h < arguments.length;
          h++
        )
          f[h - 2] = arguments[h];
        return b.prototype[e].apply(d, f);
      };
    };
  var bb = function () {
    this.Oe = 0;
  };
  bb.prototype.bi = function (a, b) {
    var c = this;
    return function () {
      var d = F.apply(0, arguments);
      c.Oe = a;
      return b.apply(null, sa(d));
    };
  };
  var cb = function () {
    var a = {};
    this.ua = ((a[3] = []), (a[2] = []), (a[1] = []), a);
    this.Wc = !1;
  };
  ha.Object.defineProperties(cb.prototype, {
    Eh: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return Object.values(this.ua).some(function (a) {
          return a.length > 0;
        });
      },
    },
  });
  var eb = function (a, b, c) {
      var d = db(a, c);
      a.ua[c].push(b);
      d && a.ua[c].length === 1 && a.flush();
    },
    db = function (a, b) {
      return Object.keys(a.ua)
        .map(function (c) {
          return Number(c);
        })
        .filter(function (c) {
          return !isNaN(c) && c > b;
        })
        .every(function (c) {
          return a.ua[c].length === 0;
        });
    };
  cb.prototype.flush = function () {
    if (!this.Wc) {
      this.Wc = !0;
      try {
        for (
          ;
          Object.values(this.ua).some(function (a) {
            return a.length > 0;
          });

        )
          fb(this, 3), fb(this, 2), fb(this, 1);
      } catch (a) {
        throw (
          (Object.values(this.ua).forEach(function (b) {
            return void b.splice(0, b.length);
          }),
          a)
        );
      } finally {
        this.Wc = !1;
      }
    }
  };
  var fb = function (a, b) {
    for (; db(a, b) && a.ua[b].length > 0; ) a.ua[b][0](), a.ua[b].shift();
  }; /*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
  var gb = {};
  var hb = globalThis.trustedTypes,
    ib;
  function jb() {
    var a = null;
    if (!hb) return a;
    try {
      var b = function (c) {
        return c;
      };
      a = hb.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (c) {
      throw c;
    }
    return a;
  }
  var kb = function (a) {
    if (gb !== gb) throw Error("w");
    this.th = a;
  };
  kb.prototype.toString = function () {
    return this.th + "";
  };
  function lb(a) {
    var b;
    ib === void 0 && (ib = jb());
    a = (b = ib) ? b.createScriptURL(a) : a;
    return new kb(a);
  }
  var mb = wa([""]),
    nb = ua(["\x00"], ["\\0"]),
    ob = ua(["\n"], ["\\n"]),
    pb = ua(["\x00"], ["\\u0000"]),
    qb = wa([""]),
    rb = ua(["\x00"], ["\\0"]),
    sb = ua(["\n"], ["\\n"]),
    tb = ua(["\x00"], ["\\u0000"]);
  function ub(a) {
    return Object.isFrozen(a) && Object.isFrozen(a.raw);
  }
  function vb(a) {
    return a.toString().indexOf("`") === -1;
  }
  var wb =
      vb(function (a) {
        return a(mb);
      }) ||
      vb(function (a) {
        return a(nb);
      }) ||
      vb(function (a) {
        return a(ob);
      }) ||
      vb(function (a) {
        return a(pb);
      }),
    xb = ub(qb) && ub(rb) && ub(sb) && ub(tb);
  var yb = function (a) {
    if (gb !== gb) throw Error("w");
    this.uh = a;
  };
  yb.prototype.toString = function () {
    return this.uh;
  };
  new yb("about:blank");
  new yb("about:invalid#zClosurez");
  var zb = [],
    Ab = function (a) {
      console.warn("y`" + a);
    };
  zb.indexOf(Ab) === -1 && zb.push(Ab);
  function Bb(a, b) {
    if (Error.captureStackTrace) Error.captureStackTrace(this, Bb);
    else {
      var c = Error().stack;
      c && (this.stack = c);
    }
    a && (this.message = String(a));
    b !== void 0 && (this.cause = b);
  }
  ab(Bb, Error);
  Bb.prototype.name = "CustomError";
  function Cb(a, b) {
    a = a.split("%s");
    for (var c = "", d = a.length - 1, e = 0; e < d; e++)
      c += a[e] + (e < b.length ? b[e] : "%s");
    Bb.call(this, c + a[d]);
  }
  ab(Cb, Bb);
  Cb.prototype.name = "AssertionError";
  function Eb(a, b, c, d) {
    var e = "Assertion failed";
    if (c) {
      e += ": " + c;
      var g = d;
    } else a && ((e += ": " + a), (g = b));
    throw new Cb("" + e, g || []);
  }
  var H = function (a, b, c) {
      a || Eb("", null, b, Array.prototype.slice.call(arguments, 2));
      return a;
    },
    J = function (a, b, c) {
      a == null &&
        Eb(
          "Expected to exist: %s.",
          [a],
          b,
          Array.prototype.slice.call(arguments, 2)
        );
      return a;
    },
    Fb = function (a, b) {
      throw new Cb(
        "Failure" + (a ? ": " + a : ""),
        Array.prototype.slice.call(arguments, 1)
      );
    },
    Gb = function (a, b, c) {
      typeof a !== "number" &&
        Eb(
          "Expected number but got %s: %s.",
          [Wa(a), a],
          b,
          Array.prototype.slice.call(arguments, 2)
        );
    },
    L = function (a, b, c) {
      Array.isArray(a) ||
        Eb(
          "Expected array but got %s: %s.",
          [Wa(a), a],
          b,
          Array.prototype.slice.call(arguments, 2)
        );
      return a;
    },
    Ib = function (a, b, c, d) {
      a instanceof b ||
        Eb(
          "Expected instanceof %s but got %s.",
          [Hb(b), Hb(a)],
          c,
          Array.prototype.slice.call(arguments, 3)
        );
      return a;
    };
  function Hb(a) {
    return a instanceof Function
      ? a.displayName || a.name || "unknown type name"
      : a instanceof Object
      ? a.constructor.displayName ||
        a.constructor.name ||
        Object.prototype.toString.call(a)
      : a === null
      ? "null"
      : typeof a;
  }
  var Jb = Array.prototype.indexOf
      ? function (a, b) {
          H(a.length != null);
          return Array.prototype.indexOf.call(a, b, void 0);
        }
      : function (a, b) {
          if (typeof a === "string")
            return typeof b !== "string" || b.length != 1
              ? -1
              : a.indexOf(b, 0);
          for (var c = 0; c < a.length; c++) if (c in a && a[c] === b) return c;
          return -1;
        },
    Kb = Array.prototype.filter
      ? function (a, b) {
          H(a.length != null);
          return Array.prototype.filter.call(a, b, void 0);
        }
      : function (a, b) {
          for (
            var c = a.length,
              d = [],
              e = 0,
              g = typeof a === "string" ? a.split("") : a,
              f = 0;
            f < c;
            f++
          )
            if (f in g) {
              var h = g[f];
              b.call(void 0, h, f, a) && (d[e++] = h);
            }
          return d;
        },
    Lb = Array.prototype.map
      ? function (a, b) {
          H(a.length != null);
          return Array.prototype.map.call(a, b, void 0);
        }
      : function (a, b) {
          for (
            var c = a.length,
              d = Array(c),
              e = typeof a === "string" ? a.split("") : a,
              g = 0;
            g < c;
            g++
          )
            g in e && (d[g] = b.call(void 0, e[g], g, a));
          return d;
        };
  function Mb(a, b) {
    for (
      var c = typeof a === "string" ? a.split("") : a, d = a.length - 1;
      d >= 0;
      d--
    )
      if (d in c && b.call(void 0, c[d], d, a)) return d;
    return -1;
  }
  function Nb(a, b, c) {
    if (!Xa(a) || !Xa(b) || a.length != b.length) return !1;
    var d = a.length;
    c = c || Ob;
    for (var e = 0; e < d; e++) if (!c(a[e], b[e])) return !1;
    return !0;
  }
  function Ob(a, b) {
    return a === b;
  }
  var Pb = function (a, b) {
    this.name = a;
    this.value = b;
  };
  Pb.prototype.toString = function () {
    return this.name;
  };
  var Qb = new Pb("OFF", Infinity),
    Rb = new Pb("WARNING", 900),
    Sb = new Pb("INFO", 800),
    Tb = new Pb("CONFIG", 700),
    Ub = function () {
      this.Lb = 0;
      this.clear();
    },
    Vb;
  Ub.prototype.clear = function () {
    this.pb = Array(this.Lb);
    this.Md = -1;
    this.ge = !1;
  };
  var Wb = function (a, b, c) {
    this.reset(a || Qb, b, c, void 0, void 0);
  };
  Wb.prototype.reset = function (a, b, c, d) {
    d || Date.now();
    this.Ng = b;
  };
  Wb.prototype.getMessage = function () {
    return this.Ng;
  };
  var Xb = function (a, b) {
      b = b === void 0 ? null : b;
      this.level = null;
      this.hg = [];
      this.parent = b || null;
      this.children = [];
      this.wg = {
        getName: function () {
          return a;
        },
      };
    },
    Yb = function (a) {
      if (a.level) return a.level;
      if (a.parent) return Yb(a.parent);
      Fb("Root logger has no level set.");
      return Qb;
    },
    Zb = function (a, b) {
      for (; a; )
        a.hg.forEach(function (c) {
          c(b);
        }),
          (a = a.parent);
    },
    $b = function () {
      this.entries = {};
      var a = new Xb("");
      a.level = Tb;
      this.entries[""] = a;
    },
    ac,
    bc = function (a, b, c) {
      var d = a.entries[b];
      if (d) return c !== void 0 && (d.level = c), d;
      d = bc(a, b.slice(0, Math.max(b.lastIndexOf("."), 0)));
      var e = new Xb(b, d);
      a.entries[b] = e;
      d.children.push(e);
      c !== void 0 && (e.level = c);
      return e;
    },
    cc = function () {
      ac || (ac = new $b());
      return ac;
    },
    ec = function (a) {
      var b = dc;
      if (b) {
        var c = a,
          d = Rb;
        if ((a = b))
          if ((a = b && d)) {
            a = d.value;
            var e = b ? Yb(bc(cc(), b.getName())) : Qb;
            a = a >= e.value;
          }
        if (a) {
          d = d || Qb;
          a = bc(cc(), b.getName());
          typeof c === "function" && (c = c());
          Vb || (Vb = new Ub());
          e = Vb;
          b = b.getName();
          if (e.Lb > 0) {
            var g = (e.Md + 1) % e.Lb;
            e.Md = g;
            e.ge
              ? ((e = e.pb[g]), e.reset(d, c, b), (b = e))
              : ((e.ge = g == e.Lb - 1), (b = e.pb[g] = new Wb(d, c, b)));
          } else b = new Wb(d, c, b);
          Zb(a, b);
        }
      }
    };
  var fc = function () {
    this.names = new Map();
  };
  fc.prototype.getName = function (a) {
    var b = this.names.get(a);
    if (b) return b;
    var c;
    b =
      (c = a.description) != null
        ? c
        : Math.floor(Math.random() * 2147483648).toString(36) +
          Math.abs(
            Math.floor(Math.random() * 2147483648) ^ Date.now()
          ).toString(36);
    this.names.set(a, b);
    return b;
  }; /*


 Copyright (c) 2015-2018 Google, Inc., Netflix, Inc., Microsoft Corp. and contributors
 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at
     http://www.apache.org/licenses/LICENSE-2.0
 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
  var hc = function (a) {
    var b = Error.call(
      this,
      a
        ? a.length +
            " errors occurred during unsubscription:\n" +
            a
              .map(function (c, d) {
                return d + 1 + ") " + c.toString();
              })
              .join("\n  ")
        : ""
    );
    this.message = b.message;
    "stack" in b && (this.stack = b.stack);
    this.errors = a;
    Object.setPrototypeOf(this, this.constructor.prototype);
    this.name = "UnsubscriptionError";
  };
  v(hc, Error);
  function ic(a, b) {
    a && ((b = a.indexOf(b)), 0 <= b && a.splice(b, 1));
  }
  function N(a) {
    return typeof a === "function";
  }
  var jc = function (a) {
    this.jg = a;
    this.closed = !1;
    this.ob = this.Xa = null;
  };
  n = jc.prototype;
  n.unsubscribe = function () {
    if (!this.closed) {
      this.closed = !0;
      var a = this.Xa;
      if (Array.isArray(a)) {
        var b = A(a),
          c = b.next();
        try {
          for (; !c.done; c = b.next()) c.value.remove(this);
        } finally {
          xa(b, c);
        }
      } else a == null || a.remove(this);
      b = this.jg;
      if (N(b))
        try {
          b();
        } catch (h) {
          var d = h instanceof hc ? h.errors : [h];
        }
      var e = this.ob;
      if (e) {
        this.ob = null;
        b = A(e);
        c = b.next();
        try {
          for (; !c.done; c = b.next()) {
            var g = c.value;
            try {
              N(g) ? g() : g.unsubscribe();
            } catch (h) {
              var f = void 0;
              d = (f = d) != null ? f : [];
              h instanceof hc
                ? (d = [].concat(sa(d), sa(h.errors)))
                : d.push(h);
            }
          }
        } finally {
          xa(b, c);
        }
      }
      if (d) throw new hc(d);
    }
  };
  n.add = function (a) {
    if (a && a !== this)
      if (this.closed) N(a) ? a() : a.unsubscribe();
      else {
        if (a instanceof jc) {
          if (a.closed || a.Ze(this)) return;
          a.Ye(this);
        }
        var b;
        (this.ob = (b = this.ob) != null ? b : []).push(a);
      }
  };
  n.Ze = function (a) {
    var b = this.Xa;
    return b === a || (Array.isArray(b) && b.includes(a));
  };
  n.Ye = function (a) {
    var b = this.Xa;
    this.Xa = Array.isArray(b) ? (b.push(a), b) : b ? [b, a] : a;
  };
  n.af = function (a) {
    var b = this.Xa;
    b === a ? (this.Xa = null) : Array.isArray(b) && ic(b, a);
  };
  n.remove = function (a) {
    var b = this.ob;
    b && ic(b, a);
    a instanceof jc && a.af(this);
  };
  var kc = new jc();
  kc.closed = !0;
  jc.EMPTY = kc;
  function lc(a) {
    return (
      a instanceof jc ||
      (a && "closed" in a && N(a.remove) && N(a.add) && N(a.unsubscribe))
    );
  }
  var mc = function () {
    setTimeout.apply(null, sa(F.apply(0, arguments)));
  };
  function nc() {}
  function oc(a) {
    mc(function () {
      throw a;
    });
  }
  var pc = function (a) {
    jc.call(this);
    this.L = !1;
    this.destination =
      a instanceof pc
        ? a
        : new qc(!a || N(a) ? { next: a != null ? a : void 0 } : a);
    lc(a) && a.add(this);
  };
  v(pc, jc);
  pc.EMPTY = jc.EMPTY;
  pc.create = function (a, b, c) {
    return new rc(a, b, c);
  };
  n = pc.prototype;
  n.next = function (a) {
    this.L || this.qc(a);
  };
  n.error = function (a) {
    this.L || ((this.L = !0), this.Dd(a));
  };
  n.complete = function () {
    this.L || ((this.L = !0), this.Hb());
  };
  n.unsubscribe = function () {
    this.closed || ((this.L = !0), jc.prototype.unsubscribe.call(this));
  };
  n.qc = function (a) {
    this.destination.next(a);
  };
  n.Dd = function (a) {
    this.destination.error(a);
    this.unsubscribe();
  };
  n.Hb = function () {
    this.destination.complete();
    this.unsubscribe();
  };
  var qc = function (a) {
    this.fd = a;
  };
  qc.prototype.next = function (a) {
    var b = this.fd;
    if (b.next)
      try {
        b.next(a);
      } catch (c) {
        oc(c);
      }
  };
  qc.prototype.error = function (a) {
    var b = this.fd;
    if (b.error)
      try {
        b.error(a);
      } catch (c) {
        oc(c);
      }
    else oc(a);
  };
  qc.prototype.complete = function () {
    var a = this.fd;
    if (a.complete)
      try {
        a.complete();
      } catch (b) {
        oc(b);
      }
  };
  var rc = function (a, b, c) {
    pc.call(this);
    this.destination = new qc(
      N(a) || !a
        ? {
            next: a != null ? a : void 0,
            error: b != null ? b : void 0,
            complete: c != null ? c : void 0,
          }
        : a
    );
  };
  v(rc, pc);
  rc.EMPTY = pc.EMPTY;
  rc.create = pc.create;
  var sc =
    (typeof Symbol === "function" && Symbol.observable) || "@@observable";
  function tc(a) {
    return a;
  }
  function O() {
    return uc(F.apply(0, arguments));
  }
  function uc(a) {
    return a.length === 0
      ? tc
      : a.length === 1
      ? a[0]
      : function (b) {
          return a.reduce(function (c, d) {
            return d(c);
          }, b);
        };
  }
  var P = function (a) {
    a && (this.Ka = a);
  };
  n = P.prototype;
  n.fb = function (a) {
    var b = new P();
    b.source = this;
    b.operator = a;
    return b;
  };
  n.subscribe = function (a, b, c) {
    a =
      (a && a instanceof pc) ||
      (a && N(a.next) && N(a.error) && N(a.complete) && lc(a))
        ? a
        : new rc(a, b, c);
    b = this.operator;
    c = this.source;
    a.add(b ? b.call(a, c) : c ? this.Ka(a) : this.sc(a));
    return a;
  };
  n.sc = function (a) {
    try {
      return this.Ka(a);
    } catch (b) {
      a.error(b);
    }
  };
  n.forEach = function (a, b) {
    var c = this;
    b = vc(b);
    return new b(function (d, e) {
      var g = c.subscribe(
        function (f) {
          try {
            a(f);
          } catch (h) {
            e(h), g == null || g.unsubscribe();
          }
        },
        e,
        d
      );
    });
  };
  n.Ka = function (a) {
    var b;
    return (b = this.source) == null ? void 0 : b.subscribe(a);
  };
  P.prototype[sc] = function () {
    return this;
  };
  P.prototype.i = function () {
    var a = F.apply(0, arguments);
    return a.length ? uc(a)(this) : this;
  };
  P.create = function (a) {
    return new P(a);
  };
  function vc(a) {
    var b;
    return (b = a != null ? a : void 0) != null ? b : Promise;
  }
  var wc = function () {
    var a = Error.call(this, "object unsubscribed");
    this.message = a.message;
    "stack" in a && (this.stack = a.stack);
    Object.setPrototypeOf(this, this.constructor.prototype);
    this.name = "ObjectUnsubscribedError";
  };
  v(wc, Error);
  var xc = function () {
    this.hb = [];
    this.Qc = this.L = this.closed = !1;
    this.Ne = null;
  };
  v(xc, P);
  n = xc.prototype;
  n.fb = function (a) {
    var b = new yc(this, this);
    b.operator = a;
    return b;
  };
  n.Ya = function () {
    if (this.closed) throw new wc();
  };
  n.next = function (a) {
    this.Ya();
    if (!this.L) {
      var b = A(this.hb.slice()),
        c = b.next();
      try {
        for (; !c.done; c = b.next()) c.value.next(a);
      } finally {
        xa(b, c);
      }
    }
  };
  n.error = function (a) {
    this.Ya();
    if (!this.L) {
      this.Qc = this.L = !0;
      this.Ne = a;
      for (var b = this.hb; b.length; ) b.shift().error(a);
    }
  };
  n.complete = function () {
    this.Ya();
    if (!this.L) {
      this.L = !0;
      for (var a = this.hb; a.length; ) a.shift().complete();
    }
  };
  n.unsubscribe = function () {
    this.L = this.closed = !0;
    this.hb = null;
  };
  n.sc = function (a) {
    this.Ya();
    return P.prototype.sc.call(this, a);
  };
  n.Ka = function (a) {
    this.Ya();
    this.Cd(a);
    return this.Fd(a);
  };
  n.Fd = function (a) {
    var b = this,
      c = this.L,
      d = this.hb;
    return this.Qc || c
      ? jc.EMPTY
      : (d.push(a),
        new jc(function () {
          return ic(b.hb, a);
        }));
  };
  n.Cd = function (a) {
    var b = this.Ne,
      c = this.L;
    this.Qc ? a.error(b) : c && a.complete();
  };
  n.Ea = function () {
    var a = new P();
    a.source = this;
    return a;
  };
  xc.create = function (a, b) {
    return new yc(a, b);
  };
  var yc = function (a, b) {
    xc.call(this);
    this.destination = a;
    this.source = b;
  };
  v(yc, xc);
  yc.create = xc.create;
  yc.prototype.next = function (a) {
    var b, c;
    (b = this.destination) == null || (c = b.next) == null || c.call(b, a);
  };
  yc.prototype.error = function (a) {
    var b, c;
    (b = this.destination) == null || (c = b.error) == null || c.call(b, a);
  };
  yc.prototype.complete = function () {
    var a, b;
    (a = this.destination) == null || (b = a.complete) == null || b.call(a);
  };
  yc.prototype.Ka = function (a) {
    var b, c;
    return (c = (b = this.source) == null ? void 0 : b.subscribe(a)) != null
      ? c
      : jc.EMPTY;
  };
  var zc = new P(function (a) {
    return a.complete();
  });
  function Ac(a, b) {
    return new P(function (c) {
      var d = 0;
      return b.u(function () {
        d === a.length ? c.complete() : (c.next(a[d++]), c.closed || this.u());
      });
    });
  }
  function Bc(a, b) {
    if (!a) throw Error("z");
    return new P(function (c) {
      var d = new jc();
      d.add(
        b.u(function () {
          var e = a[Symbol.asyncIterator]();
          d.add(
            b.u(function () {
              var g = this;
              e.next().then(function (f) {
                f.done ? c.complete() : (c.next(f.value), g.u());
              });
            })
          );
        })
      );
      return d;
    });
  }
  var Cc =
    typeof Symbol === "function" && Symbol.iterator
      ? Symbol.iterator
      : "@@iterator";
  function Dc(a, b, c) {
    b = b.u(function () {
      try {
        c.call(this);
      } catch (d) {
        a.error(d);
      }
    }, 0);
    a.add(b);
  }
  function Ec(a, b) {
    return new P(function (c) {
      var d;
      c.add(
        b.u(function () {
          d = a[Cc]();
          Dc(c, b, function () {
            var e = d.next(),
              g = e.value;
            e.done ? c.complete() : (c.next(g), this.u());
          });
        })
      );
      return function () {
        var e;
        return N((e = d) == null ? void 0 : e.return) && d.return();
      };
    });
  }
  function Fc(a, b) {
    return new P(function (c) {
      var d = new jc();
      d.add(
        b.u(function () {
          var e = a[sc]();
          d.add(
            e.subscribe({
              next: function (g) {
                d.add(
                  b.u(function () {
                    return c.next(g);
                  })
                );
              },
              error: function (g) {
                d.add(
                  b.u(function () {
                    return c.error(g);
                  })
                );
              },
              complete: function () {
                d.add(
                  b.u(function () {
                    return c.complete();
                  })
                );
              },
            })
          );
        })
      );
      return d;
    });
  }
  function Gc(a, b) {
    return new P(function (c) {
      return b.u(function () {
        return a.then(
          function (d) {
            c.add(
              b.u(function () {
                c.next(d);
                c.add(
                  b.u(function () {
                    return c.complete();
                  })
                );
              })
            );
          },
          function (d) {
            c.add(
              b.u(function () {
                return c.error(d);
              })
            );
          }
        );
      });
    });
  }
  var Hc = function (a) {
    return a && typeof a.length === "number" && typeof a !== "function";
  };
  function Ic(a) {
    return new TypeError(
      "A`" +
        (a !== null && typeof a === "object"
          ? "an invalid object"
          : "'" + a + "'")
    );
  }
  function Jc(a, b) {
    if (a != null) {
      if (N(a[sc])) return Fc(a, b);
      if (Hc(a)) return Ac(a, b);
      if (N(a == null ? void 0 : a.then)) return Gc(a, b);
      if (
        Symbol.asyncIterator &&
        N(a == null ? void 0 : a[Symbol.asyncIterator])
      )
        return Bc(a, b);
      if (N(a == null ? void 0 : a[Cc])) return Ec(a, b);
    }
    throw Ic(a);
  }
  function Kc(a, b) {
    return b ? Jc(a, b) : Lc(a);
  }
  function Lc(a) {
    if (a instanceof P) return a;
    if (a != null) {
      if (N(a[sc])) return Mc(a);
      if (Hc(a)) return Nc(a);
      if (N(a == null ? void 0 : a.then)) return Oc(a);
      if (
        Symbol.asyncIterator &&
        N(a == null ? void 0 : a[Symbol.asyncIterator])
      )
        return Pc(a);
      if (N(a == null ? void 0 : a[Cc])) return Qc(a);
    }
    throw Ic(a);
  }
  function Mc(a) {
    return new P(function (b) {
      var c = a[sc]();
      if (N(c.subscribe)) return c.subscribe(b);
      throw new TypeError("B");
    });
  }
  function Nc(a) {
    return new P(function (b) {
      for (var c = 0; c < a.length && !b.closed; c++) b.next(a[c]);
      b.complete();
    });
  }
  function Oc(a) {
    return new P(function (b) {
      a.then(
        function (c) {
          b.closed || (b.next(c), b.complete());
        },
        function (c) {
          return b.error(c);
        }
      ).then(null, oc);
    });
  }
  function Qc(a) {
    return new P(function (b) {
      for (var c = a[Cc](); !b.closed; ) {
        var d = c.next(),
          e = d.value;
        d.done ? b.complete() : b.next(e);
      }
      return function () {
        return N(c == null ? void 0 : c.return) && c.return();
      };
    });
  }
  function Pc(a) {
    return new P(function (b) {
      Rc(a, b).catch(function (c) {
        return b.error(c);
      });
    });
  }
  function Rc(a, b) {
    var c, d, e, g, f, h;
    return Ga(
      new Fa(
        new Ba(function (k) {
          switch (k.P) {
            case 1:
              k.Ie(2, 3);
              var l = a[Symbol.asyncIterator];
              g = l !== void 0 ? l.call(a) : new Ja(A(a));
            case 5:
              return (d = void 0), k.yield(g.next(), 8);
            case 8:
              d = k.Gb;
              if (d.done) {
                k.Aa(3);
                break;
              }
              f = d.value;
              b.next(f);
              k.Aa(5);
              break;
            case 3:
              k.Gc();
              k.Je(9);
              if (!d || d.done || !(e = g.return)) {
                k.Aa(9);
                break;
              }
              return k.yield(e.call(g), 9);
            case 9:
              k.Gc(0, 0, 1);
              if (c) throw c.error;
              k.Zc(10, 1);
              break;
            case 10:
              k.Zc(4);
              break;
            case 2:
              h = k.Qd();
              c = { error: h };
              k.Aa(3);
              break;
            case 4:
              b.complete(), k.ke();
          }
        })
      )
    );
  }
  function Sc(a) {
    return N(a[a.length - 1]) ? a.pop() : void 0;
  }
  function Tc(a) {
    var b = a[a.length - 1];
    return b && N(b.u) ? a.pop() : void 0;
  }
  function Uc() {
    var a = F.apply(0, arguments),
      b = Tc(a);
    return b ? Ac(a, b) : Nc(a);
  }
  var Vc = {
    now: function () {
      return (Vc.Gf || Date).now();
    },
    Gf: void 0,
  };
  var Wc = function (a, b, c) {
    a = a === void 0 ? Infinity : a;
    b = b === void 0 ? Infinity : b;
    c = c === void 0 ? Vc : c;
    xc.call(this);
    this.bufferSize = a;
    this.Ve = b;
    this.Pe = c;
    this.buffer = [];
    this.Tc = b === Infinity;
    this.bufferSize = Math.max(1, a);
    this.Ve = Math.max(1, b);
  };
  v(Wc, xc);
  Wc.create = xc.create;
  Wc.prototype.next = function (a) {
    var b = this.buffer,
      c = this.Tc,
      d = this.Pe,
      e = this.Ve;
    this.L || (b.push(a), !c && b.push(d.now() + e));
    Xc(this);
    xc.prototype.next.call(this, a);
  };
  Wc.prototype.Ka = function (a) {
    this.Ya();
    Xc(this);
    for (
      var b = this.Fd(a), c = this.Tc, d = this.buffer.slice(), e = 0;
      e < d.length && !a.closed;
      e += c ? 1 : 2
    )
      a.next(d[e]);
    this.Cd(a);
    return b;
  };
  var Xc = function (a) {
    var b = a.bufferSize,
      c = a.Pe,
      d = a.buffer;
    a = a.Tc;
    var e = (a ? 1 : 2) * b;
    b < Infinity && e < d.length && d.splice(0, d.length - e);
    if (!a) {
      b = c.now();
      c = 0;
      for (a = 1; a < d.length && d[a] <= b; a += 2) c = a;
      c && d.splice(0, c + 1);
    }
  };
  var Zc = function (a, b) {
    b = b === void 0 ? Yc : b;
    this.Hh = a;
    this.now = b;
  };
  Zc.prototype.u = function (a, b, c) {
    b = b === void 0 ? 0 : b;
    return new this.Hh(this, a).u(c, b);
  };
  var Yc = Vc.now;
  var Q = function (a, b, c, d, e) {
    pc.call(this, a);
    this.hh = e;
    b &&
      (this.qc = function (g) {
        try {
          b(g);
        } catch (f) {
          this.destination.error(f);
        }
      });
    c &&
      (this.Dd = function (g) {
        try {
          c(g);
        } catch (f) {
          this.destination.error(f);
        }
        this.unsubscribe();
      });
    d &&
      (this.Hb = function () {
        try {
          d();
        } catch (g) {
          this.destination.error(g);
        }
        this.unsubscribe();
      });
  };
  v(Q, pc);
  Q.EMPTY = pc.EMPTY;
  Q.create = pc.create;
  Q.prototype.unsubscribe = function () {
    var a;
    this.closed || ((a = this.hh) != null && a.call(this));
    pc.prototype.unsubscribe.call(this);
  };
  function $c(a) {
    return function (b) {
      if (N(b == null ? void 0 : b.fb))
        return b.fb(function (c) {
          try {
            return a(c, this);
          } catch (d) {
            this.error(d);
          }
        });
      throw new TypeError("C");
    };
  }
  function ad() {
    return $c(function (a, b) {
      var c = null;
      a.Ib++;
      var d = new Q(b, void 0, void 0, void 0, function () {
        if (!a || a.Ib <= 0 || 0 < --a.Ib) c = null;
        else {
          var e = a.Wa,
            g = c;
          c = null;
          !e || (g && e !== g) || e.unsubscribe();
          b.unsubscribe();
        }
      });
      a.subscribe(d);
      d.closed || (c = a.connect());
    });
  }
  var bd = function (a, b) {
    this.source = a;
    this.Me = b;
    this.Jb = null;
    this.Ib = 0;
    this.Wa = null;
  };
  v(bd, P);
  bd.create = P.create;
  bd.prototype.Ka = function (a) {
    return cd(this).subscribe(a);
  };
  var cd = function (a) {
    var b = a.Jb;
    if (!b || b.L) a.Jb = a.Me();
    return a.Jb;
  };
  bd.prototype.rc = function () {
    this.Ib = 0;
    var a = this.Wa;
    this.Jb = this.Wa = null;
    a == null || a.unsubscribe();
  };
  bd.prototype.connect = function () {
    var a = this,
      b = this.Wa;
    if (!b) {
      b = this.Wa = new jc();
      var c = cd(this);
      b.add(
        this.source.subscribe(
          new Q(
            c,
            void 0,
            function (d) {
              a.rc();
              c.error(d);
            },
            function () {
              a.rc();
              c.complete();
            },
            function () {
              return a.rc();
            }
          )
        )
      );
      b.closed && ((this.Wa = null), (b = jc.EMPTY));
    }
    return b;
  };
  function dd() {
    var a = ed;
    var b = b === void 0 ? 0 : b;
    return $c(function (c, d) {
      d.add(
        a.u(function () {
          return c.subscribe(d);
        }, b)
      );
    });
  }
  function R(a) {
    return $c(function (b, c) {
      var d = 0;
      b.subscribe(
        new Q(c, function (e) {
          c.next(a.call(void 0, e, d++));
        })
      );
    });
  }
  var fd = Array.isArray;
  function gd(a) {
    return R(function (b) {
      return fd(b) ? a.apply(null, sa(b)) : a(b);
    });
  }
  var hd = Array.isArray,
    id = Object,
    jd = id.getPrototypeOf,
    kd = id.prototype,
    ld = id.keys;
  function md(a) {
    if (a.length === 1) {
      var b = a[0];
      if (hd(b)) return { args: b, keys: null };
      if (b && typeof b === "object" && jd(b) === kd)
        return (
          (a = ld(b)),
          {
            args: a.map(function (c) {
              return b[c];
            }),
            keys: a,
          }
        );
    }
    return { args: a, keys: null };
  }
  function nd() {
    var a = F.apply(0, arguments),
      b = Tc(a),
      c = Sc(a);
    a = md(a);
    var d = a.args,
      e = a.keys;
    if (d.length === 0) return Kc([], b);
    b = new P(
      od(
        d,
        b,
        e
          ? function (g) {
              for (var f = {}, h = 0; h < g.length; h++) f[e[h]] = g[h];
              return f;
            }
          : tc
      )
    );
    return c ? b.i(gd(c)) : b;
  }
  var pd = function (a, b, c) {
    pc.call(this, a);
    this.qc = b;
    this.Th = c;
  };
  v(pd, pc);
  pd.EMPTY = pc.EMPTY;
  pd.create = pc.create;
  pd.prototype.Hb = function () {
    this.Th() ? pc.prototype.Hb.call(this) : this.unsubscribe();
  };
  function od(a, b, c) {
    c = c === void 0 ? tc : c;
    return function (d) {
      qd(
        b,
        function () {
          for (
            var e = a.length,
              g = Array(e),
              f = e,
              h = a.map(function () {
                return !1;
              }),
              k = !0,
              l = { Pa: 0 };
            l.Pa < e;
            l = { Pa: l.Pa }, l.Pa++
          )
            qd(
              b,
              (function (m) {
                return function () {
                  Kc(a[m.Pa], b).subscribe(
                    new pd(
                      d,
                      function (r) {
                        g[m.Pa] = r;
                        k && ((h[m.Pa] = !0), (k = !h.every(tc)));
                        k || d.next(c(g.slice()));
                      },
                      function () {
                        return --f === 0;
                      }
                    )
                  );
                };
              })(l),
              d
            );
        },
        d
      );
    };
  }
  function qd(a, b, c) {
    a ? c.add(a.u(b)) : b();
  }
  function rd(a, b, c, d) {
    var e = [],
      g = 0,
      f = 0,
      h = !1,
      k = function (l) {
        g++;
        Lc(c(l, f++)).subscribe(
          new Q(
            b,
            function (m) {
              b.next(m);
            },
            void 0,
            function () {
              g--;
              for (var m = {}; e.length && g < d; m = { Jd: void 0 })
                (m.Jd = e.shift()), k(m.Jd);
              !h || e.length || g || b.complete();
            }
          )
        );
      };
    a.subscribe(
      new Q(
        b,
        function (l) {
          return g < d ? k(l) : e.push(l);
        },
        void 0,
        function () {
          h = !0;
          !h || e.length || g || b.complete();
        }
      )
    );
    return function () {
      e = null;
    };
  }
  function sd(a, b) {
    var c = c === void 0 ? Infinity : c;
    if (N(b))
      return sd(function (d, e) {
        return R(function (g, f) {
          return b(d, g, e, f);
        })(Lc(a(d, e)));
      }, c);
    typeof b === "number" && (c = b);
    return $c(function (d, e) {
      return rd(d, e, a, c);
    });
  }
  function td(a) {
    a = a === void 0 ? Infinity : a;
    return sd(tc, a);
  }
  function ud() {
    var a = F.apply(0, arguments),
      b = td(1),
      c = Tc(a);
    return b(c ? Ac(a, c) : Nc(a));
  }
  var vd = function () {
    jc.call(this);
  };
  v(vd, jc);
  vd.EMPTY = jc.EMPTY;
  vd.prototype.u = function () {
    return this;
  };
  var wd = function (a, b) {
    return setInterval.apply(null, [a, b].concat(sa(F.apply(2, arguments))));
  };
  var xd = function (a, b) {
    jc.call(this);
    this.scheduler = a;
    this.Bd = b;
    this.pending = !1;
  };
  v(xd, vd);
  xd.EMPTY = vd.EMPTY;
  xd.prototype.u = function (a, b) {
    b = b === void 0 ? 0 : b;
    if (this.closed) return this;
    this.state = a;
    a = this.id;
    var c = this.scheduler;
    a != null && (this.id = yd(this, a, b));
    this.pending = !0;
    this.delay = b;
    this.id = this.id || this.ld(c, this.id, b);
    return this;
  };
  xd.prototype.ld = function (a, b, c) {
    return wd(a.flush.bind(a, this), c === void 0 ? 0 : c);
  };
  var yd = function (a, b, c) {
    c = c === void 0 ? 0 : c;
    if (c != null && a.delay === c && a.pending === !1) return b;
    clearInterval(b);
  };
  xd.prototype.execute = function (a, b) {
    if (this.closed) return Error("D");
    this.pending = !1;
    if ((a = this.Ed(a, b))) return a;
    this.pending === !1 &&
      this.id != null &&
      (this.id = yd(this, this.id, null));
  };
  xd.prototype.Ed = function (a) {
    var b = !1;
    try {
      this.Bd(a);
    } catch (d) {
      b = !0;
      var c = (!!d && d) || Error(d);
    }
    if (b) return this.unsubscribe(), c;
  };
  xd.prototype.unsubscribe = function () {
    if (!this.closed) {
      var a = this.id,
        b = this.scheduler.actions;
      this.Bd = this.state = this.scheduler = null;
      this.pending = !1;
      ic(b, this);
      a != null && (this.id = yd(this, a, null));
      this.delay = null;
      vd.prototype.unsubscribe.call(this);
    }
  };
  var zd = function (a, b) {
    b = b === void 0 ? Yc : b;
    Zc.call(this, a, b);
    this.actions = [];
    this.active = !1;
  };
  v(zd, Zc);
  zd.prototype.flush = function (a) {
    var b = this.actions;
    if (this.active) b.push(a);
    else {
      var c;
      this.active = !0;
      do if ((c = a.execute(a.state, a.delay))) break;
      while ((a = b.shift()));
      this.active = !1;
      if (c) {
        for (; (a = b.shift()); ) a.unsubscribe();
        throw c;
      }
    }
  };
  function Ad() {
    var a = F.apply(0, arguments),
      b = Tc(a);
    var c = typeof a[a.length - 1] === "number" ? a.pop() : Infinity;
    return a.length
      ? a.length === 1
        ? Lc(a[0])
        : td(c)(b ? Ac(a, b) : Nc(a))
      : zc;
  }
  var Bd = new P(nc);
  var Cd = Array.isArray;
  function Dd(a) {
    return a.length === 1 && Cd(a[0]) ? a[0] : a;
  }
  function Ed() {
    var a = Dd(F.apply(0, arguments));
    return $c(function (b, c) {
      var d = [b].concat(sa(a)),
        e = function () {
          if (!c.closed)
            if (d.length > 0) {
              try {
                var g = Lc(d.shift());
              } catch (h) {
                e();
                return;
              }
              var f = new Q(c, void 0, nc, nc);
              c.add(g.subscribe(f));
              f.add(e);
            } else c.complete();
        };
      e();
    });
  }
  function S(a) {
    return $c(function (b, c) {
      var d = 0;
      b.subscribe(
        new Q(c, function (e) {
          return a.call(void 0, e, d++) && c.next(e);
        })
      );
    });
  }
  function Fd() {
    var a = F.apply(0, arguments);
    a = Dd(a);
    return a.length === 1 ? Lc(a[0]) : new P(Gd(a));
  }
  function Gd(a) {
    return function (b) {
      for (
        var c = [], d = { bb: 0 };
        c && !b.closed && d.bb < a.length;
        d = { bb: d.bb }, d.bb++
      )
        c.push(
          Lc(a[d.bb]).subscribe(
            new Q(
              b,
              (function (e) {
                return function (g) {
                  if (c) {
                    for (var f = 0; f < c.length; f++)
                      f !== e.bb && c[f].unsubscribe();
                    c = null;
                  }
                  b.next(g);
                };
              })(d)
            )
          )
        );
    };
  }
  function Hd() {
    var a = F.apply(0, arguments),
      b = Sc(a),
      c = Dd(a);
    return c.length
      ? new P(function (d) {
          var e = c.map(function () {
              return [];
            }),
            g = c.map(function () {
              return !1;
            });
          d.add(function () {
            e = g = null;
          });
          for (
            var f = { Ja: 0 };
            !d.closed && f.Ja < c.length;
            f = { Ja: f.Ja }, f.Ja++
          )
            Lc(c[f.Ja]).subscribe(
              new Q(
                d,
                (function (h) {
                  return function (k) {
                    e[h.Ja].push(k);
                    e.every(function (l) {
                      return l.length;
                    }) &&
                      ((k = e.map(function (l) {
                        return l.shift();
                      })),
                      d.next(b ? b.apply(null, sa(k)) : k),
                      e.some(function (l, m) {
                        return !l.length && g[m];
                      }) && d.complete());
                  };
                })(f),
                void 0,
                (function (h) {
                  return function () {
                    g[h.Ja] = !0;
                    !e[h.Ja].length && d.complete();
                  };
                })(f)
              )
            );
          return function () {
            e = g = null;
          };
        })
      : zc;
  }
  var Id = function (a, b) {
    xd.call(this, a, b);
    this.scheduler = a;
    this.Bd = b;
  };
  v(Id, xd);
  Id.EMPTY = xd.EMPTY;
  Id.prototype.u = function (a, b) {
    b = b === void 0 ? 0 : b;
    if (b > 0) return xd.prototype.u.call(this, a, b);
    this.delay = b;
    this.state = a;
    this.scheduler.flush(this);
    return this;
  };
  Id.prototype.execute = function (a, b) {
    return b > 0 || this.closed
      ? xd.prototype.execute.call(this, a, b)
      : this.Ed(a, b);
  };
  Id.prototype.ld = function (a, b, c) {
    c = c === void 0 ? 0 : c;
    return (c != null && c > 0) || (c == null && this.delay > 0)
      ? xd.prototype.ld.call(this, a, b, c)
      : a.flush(this);
  };
  var Jd = function () {
    zd.apply(this, arguments);
  };
  v(Jd, zd);
  var ed = new Jd(Id);
  var Kd = function () {
    this.gd = new bb();
    this.queue = new cb();
    this.qg = Symbol();
    this.Od = new fc();
  };
  ha.Object.defineProperties(Kd.prototype, {
    Db: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.qg;
      },
    },
  });
  function Ld(a) {
    var b, c, d;
    return (
      !!a &&
      typeof a.active === "boolean" &&
      typeof ((b = a.clock) == null ? void 0 : b.now) === "function" &&
      ((c = a.clock) == null ? void 0 : c.timeline) !== void 0 &&
      !((d = a.Ub) == null || !d.timestamp) &&
      typeof a.tj === "function" &&
      typeof a.Td === "function" &&
      typeof a.xj === "function" &&
      typeof a.map === "function" &&
      typeof a.Ij === "function"
    );
  }
  var Md = function (a, b) {
    b = Error.call(this, b ? a + ": " + b : String(a));
    this.message = b.message;
    "stack" in b && (this.stack = b.stack);
    this.code = a;
    this.__proto__ = Md.prototype;
    this.name = String(a);
  };
  v(Md, Error);
  var Nd = function () {
    Md.call(this, 1003);
    this.__proto__ = Nd.prototype;
  };
  v(Nd, Md);
  var Od = function () {
    Md.call(this, 1009);
    this.__proto__ = Od.prototype;
  };
  v(Od, Md);
  var Pd = function () {
    Md.call(this, 1007);
    this.__proto__ = Nd.prototype;
  };
  v(Pd, Md);
  var Qd = function (a) {
    Md.call(this, 1004, String(a));
    this.kg = a;
    this.__proto__ = Qd.prototype;
  };
  v(Qd, Md);
  var Sd = function (a) {
    Md.call(this, 1010, a);
    this.__proto__ = Rd.prototype;
  };
  v(Sd, Md);
  var Rd = function (a) {
    Md.call(this, 1005, a);
    this.__proto__ = Rd.prototype;
  };
  v(Rd, Md);
  var Td = function (a) {
    Md.call(this, 1006, a);
    this.__proto__ = Td.prototype;
  };
  v(Td, Md);
  var Ud = Symbol("date"),
    Vd = function (a, b) {
      this.value = a;
      this.timeline = b;
    },
    Wd = function (a, b) {
      if (b.timeline !== a.timeline) throw new Pd();
    },
    Xd = function (a, b) {
      Wd(a, b);
      return a.value - b.value;
    };
  n = Vd.prototype;
  n.equals = function (a) {
    return Xd(this, a) === 0;
  };
  n.maximum = function (a) {
    Wd(this, a);
    return this.value >= a.value ? this : a;
  };
  n.round = function () {
    return new Vd(Math.round(this.value), this.timeline);
  };
  n.add = function (a) {
    return new Vd(this.value + a, this.timeline);
  };
  n.toString = function () {
    return String(this.value);
  };
  function Yd(a) {
    function b(c) {
      return (
        typeof c === "boolean" ||
        typeof c === "string" ||
        typeof c === "number" ||
        c === void 0 ||
        c === null
      );
    }
    return b(a)
      ? !0
      : Array.isArray(a)
      ? a.every(b)
      : typeof a === "object"
      ? Object.keys(a).every(function (c) {
          return typeof c === "string";
        }) &&
        Object.values(a).every(function (c) {
          return Array.isArray(c) ? c.every(b) : b(c);
        })
      : !1;
  }
  function Zd(a) {
    if (Yd(a)) return a;
    if (Ld(a))
      return {
        Ub: {
          value: Zd(a.Ub.value),
          timestamp: Xd(a.Ub.timestamp, new Vd(0, a.Ub.timestamp.timeline)),
        },
        active: a.active,
      };
    try {
      return JSON.parse(JSON.stringify(a));
    } catch (b) {}
    return String(a);
  }
  var $d = { Di: "app", lj: "web" };
  var ae = ["sessionStart", "sessionError", "sessionFinish"],
    be = function (a, b) {
      this.ha = a;
      this.kc = b;
      this.ready = !1;
      this.Ua = [];
      this.Ge = function () {};
      this.Ue = function () {};
      this.Xd = function () {};
      this.ee = function () {};
      this.ac = function () {};
    },
    ce = function (a, b) {
      a.Ge = b;
    },
    de = function (a, b) {
      a.Ue = b;
    },
    ee = function (a, b) {
      a.Xd = b;
    },
    fe = function (a, b) {
      a.ee = b;
    },
    ge = function (a, b) {
      a.ac = b;
      a.ac(a.Ua.length);
    },
    le = function (a) {
      var b = A(
          "geometryChange impression loaded start firstQuartile midpoint thirdQuartile complete pause resume bufferStart bufferFinish skipped volumeChange playerStateChange adUserInteraction".split(
            " "
          )
        ),
        c = b.next();
      try {
        for (; !c.done; c = b.next())
          a.ha.addEventListener(c.value, function (d) {
            he(a, d);
          });
      } finally {
        xa(b, c);
      }
      ie(
        a.ha,
        function (d) {
          d.type !== "sessionStart" && he(a, d);
        },
        a.kc
      );
      ie(
        a.ha,
        function (d) {
          d.type === "sessionStart" && (he(a, d), je(a), ke(a));
        },
        a.kc
      );
    },
    he = function (a, b) {
      a.Ua.push(b);
      a.ac(a.Ua.length);
      ke(a);
    },
    ke = function (a) {
      if (a.ready)
        for (; a.Ua.length > 0; ) {
          var b = a.Ua.pop();
          b !== void 0 &&
            (b.type === "geometryChange"
              ? a.Xd(b)
              : b.type === "impression"
              ? a.ee(b)
              : ae.includes(b.type)
              ? a.Ge(b)
              : a.Ue(b));
          a.ac(a.Ua.length);
        }
    },
    je = function (a) {
      a.ready ||
        ((a.ready = !0),
        a.Ua.sort(function (b, c) {
          return c.timestamp - b.timestamp;
        }));
    };
  function me(a) {
    return $c(function (b, c) {
      var d = null,
        e = !1,
        g;
      d = b.subscribe(
        new Q(c, void 0, function (f) {
          g = Lc(a(f, me(a)(b)));
          d ? (d.unsubscribe(), (d = null), g.subscribe(c)) : (e = !0);
        })
      );
      e && (d.unsubscribe(), (d = null), g.subscribe(c));
    });
  }
  function ne(a, b, c) {
    return function (d, e) {
      var g = c,
        f = b,
        h = 0;
      d.subscribe(
        new Q(
          e,
          function (k) {
            var l = h++;
            f = g ? a(f, k, l) : ((g = !0), k);
            e.next(f);
          },
          void 0,
          void 0
        )
      );
    };
  }
  function oe() {
    return $c(function (a, b) {
      a.subscribe(new Q(b, nc));
    });
  }
  function pe(a) {
    return $c(function (b, c) {
      b.subscribe(
        new Q(c, function () {
          return c.next(a);
        })
      );
    });
  }
  function qe(a) {
    return a <= 0
      ? function () {
          return zc;
        }
      : $c(function (b, c) {
          var d = 0;
          b.subscribe(
            new Q(c, function (e) {
              ++d <= a && (c.next(e), a <= d && c.complete());
            })
          );
        });
  }
  function T(a) {
    var b = b === void 0 ? tc : b;
    var c;
    a = (c = a) != null ? c : re;
    return $c(function (d, e) {
      var g,
        f = !0;
      d.subscribe(
        new Q(e, function (h) {
          var k = b(h);
          if (f || !a(g, k)) (f = !1), (g = k), e.next(h);
        })
      );
    });
  }
  function re(a, b) {
    return a === b;
  }
  function se() {
    var a = F.apply(0, arguments);
    return function (b) {
      return ud(b, Uc.apply(null, sa(a)));
    };
  }
  function te(a) {
    return $c(function (b, c) {
      var d = 0;
      b.subscribe(
        new Q(
          c,
          function (e) {
            a.call(void 0, e, d++, b) || (c.next(!1), c.complete());
          },
          void 0,
          function () {
            c.next(!0);
            c.complete();
          }
        )
      );
    });
  }
  function ue(a) {
    var b = N(a)
      ? a
      : function () {
          return a;
        };
    return N()
      ? $c(function (c, d) {
          var e = b();
          (void 0)(e).subscribe(d).add(c.subscribe(e));
        })
      : function (c) {
          var d = new bd(c, b);
          N(c == null ? void 0 : c.fb) && (d.fb = c.fb);
          d.source = c;
          d.Me = b;
          return d;
        };
  }
  function ve() {
    return $c(function (a, b) {
      var c,
        d = !1;
      a.subscribe(
        new Q(b, function (e) {
          var g = c;
          c = e;
          d && b.next([g, e]);
          d = !0;
        })
      );
    });
  }
  function we(a) {
    var b = new Wc(a, void 0, void 0);
    return function (c) {
      return ue(function () {
        return b;
      })(c);
    };
  }
  function xe() {
    var a = a === void 0 ? Infinity : a;
    return a <= 0
      ? function () {
          return zc;
        }
      : $c(function (b, c) {
          var d = 0,
            e,
            g = function () {
              var f = !1;
              e = b.subscribe(
                new Q(c, void 0, void 0, function () {
                  ++d < a
                    ? e
                      ? (e.unsubscribe(), (e = null), g())
                      : (f = !0)
                    : c.complete();
                })
              );
              f && (e.unsubscribe(), (e = null), g());
            };
          g();
        });
  }
  function U(a, b) {
    return $c(ne(a, b, arguments.length >= 2));
  }
  function ye(a) {
    return $c(function (b, c) {
      var d = !1,
        e = 0;
      b.subscribe(
        new Q(c, function (g) {
          return (d || (d = !a(g, e++))) && c.next(g);
        })
      );
    });
  }
  function V() {
    var a = F.apply(0, arguments),
      b = Tc(a);
    return $c(function (c, d) {
      (b ? ud(a, c, b) : ud(a, c)).subscribe(d);
    });
  }
  function ze(a) {
    return $c(function (b, c) {
      var d = null,
        e = 0,
        g = !1;
      b.subscribe(
        new Q(
          c,
          function (f) {
            var h;
            (h = d) == null || h.unsubscribe();
            h = e++;
            Lc(a(f, h)).subscribe(
              (d = new Q(
                c,
                function (k) {
                  return c.next(k);
                },
                void 0,
                function () {
                  d = null;
                  g && !d && c.complete();
                }
              ))
            );
          },
          void 0,
          function () {
            ((g = !0), !d) && c.complete();
          }
        )
      );
    });
  }
  function Ae(a) {
    var b = !0;
    b = b === void 0 ? !1 : b;
    return $c(function (c, d) {
      var e = 0;
      c.subscribe(
        new Q(d, function (g) {
          var f = a(g, e++);
          (f || b) && d.next(g);
          !f && d.complete();
        })
      );
    });
  }
  function Be(a, b, c) {
    var d = N(a) || b || c ? { next: a, error: b, complete: c } : a;
    return d
      ? $c(function (e, g) {
          e.subscribe(
            new Q(
              g,
              function (f) {
                var h;
                (h = d.next) == null || h.call(d, f);
                g.next(f);
              },
              function (f) {
                var h;
                (h = d.error) == null || h.call(d, f);
                g.error(f);
              },
              function () {
                var f;
                (f = d.complete) == null || f.call(d);
                g.complete();
              }
            )
          );
        })
      : tc;
  }
  function Ce() {
    var a = F.apply(0, arguments),
      b = Sc(a);
    return $c(function (c, d) {
      for (
        var e = a.length,
          g = Array(e),
          f = a.map(function () {
            return !1;
          }),
          h = !1,
          k = { Ga: 0 };
        k.Ga < e;
        k = { Ga: k.Ga }, k.Ga++
      )
        Lc(a[k.Ga]).subscribe(
          new Q(
            d,
            (function (l) {
              return function (m) {
                g[l.Ga] = m;
                h ||
                  f[l.Ga] ||
                  ((f[l.Ga] = !0), (h = f.every(tc)) && (f = null));
              };
            })(k),
            void 0,
            nc
          )
        );
      c.subscribe(
        new Q(d, function (l) {
          h && ((l = [l].concat(sa(g))), d.next(b ? b.apply(null, sa(l)) : l));
        })
      );
    });
  }
  var De = function (a) {
    this.ha = a;
  };
  De.prototype.Ra = function (a) {
    return (a == null ? 0 : a.mj)
      ? !0
      : (a == null ? void 0 : a.pj) === "POST" ||
        (a == null ? 0 : a.Dc) ||
        (a == null ? 0 : a.sj)
      ? !1
      : this.ha.Ra();
  };
  De.prototype.ping = function () {
    var a = this,
      b = Uc.apply(null, sa(F.apply(0, arguments))).i(
        sd(function (c) {
          return Ee(a, c);
        }),
        te(function (c) {
          return c;
        }),
        we(1)
      );
    b.connect();
    return b;
  };
  var Ee = function (a, b) {
    var c = new Wc(1);
    Fe(
      a.ha,
      b,
      function () {
        c.next(!0);
        c.complete();
      },
      function () {
        c.next(!1);
        c.complete();
      }
    );
    return c;
  };
  De.prototype.ph = function (a, b, c) {
    this.ping.apply(this, sa(F.apply(3, arguments)));
  };
  function Ge(a, b) {
    var c = !1;
    return new P(function (d) {
      var e = a.setTimeout(function () {
        c = !0;
        d.next(!0);
        d.complete();
      }, b);
      return function () {
        c || a.clearTimeout(e);
      };
    });
  }
  var He = function (a) {
    this.ha = a;
    this.timeline = Ud;
  };
  n = He.prototype;
  n.setTimeout = function (a, b) {
    return Number(
      this.ha.setTimeout(function () {
        return a();
      }, b)
    );
  };
  n.clearTimeout = function (a) {
    this.ha.clearTimeout(a);
  };
  n.now = function () {
    return new Vd(Date.now(), this.timeline);
  };
  n.interval = function (a, b) {
    var c = this.Tb(a).subscribe(b);
    return function () {
      return void c.unsubscribe();
    };
  };
  n.Tb = function (a) {
    return Ge(this, a).i(
      xe(),
      U(function (b) {
        return b + 1;
      }, -1)
    );
  };
  var Ie = function (a, b) {
    this.context = a;
    this.jb = b;
  };
  Ie.prototype.Ra = function (a) {
    return this.jb.Ra(a);
  };
  var Ke = function (a, b) {
      if (!a.Ra()) throw new Od();
      return new Je(a.jb, b);
    },
    Je = function (a, b) {
      var c = this;
      this.jb = a;
      this.properties = void 0;
      this.url = b;
      this.Sb = !0;
      this.Dc = new Map();
      this.body = void 0;
      this.method = "GET";
      this.nf = Bd.subscribe(function () {
        c.sendNow();
      });
    };
  Je.prototype.deactivate = function () {
    this.Sb = !1;
  };
  Je.prototype.sendNow = function () {
    if (this.Sb)
      if ((this.nf.unsubscribe(), this.jb.Ra(this.properties)))
        try {
          if (this.Dc.size > 0 || this.body !== void 0) {
            var a, b;
            this.jb.ph(
              (a = this.properties) != null ? a : {},
              this.Dc,
              (b = this.body) != null ? b : "",
              this.url
            );
          } else this.jb.ping(this.url);
          this.Sb = !1;
        } catch (c) {}
      else this.Sb = !1;
  };
  var Me = function (a, b, c, d, e, g) {
      this.mode = a;
      this.o = b;
      this.setTime = c;
      this.Bb = d;
      this.vd = e;
      this.Ac = g;
      this.completed = !1;
      this.id = this.mode === 0 ? Le(this) : 0;
    },
    Le = function (a) {
      return a.o.setTimeout(function () {
        Ne(a);
      }, a.Bb);
    },
    Oe = function (a, b) {
      var c = Xd(b, a.setTime);
      c >= a.Bb ? Ne(a) : ((a.setTime = b), (a.Bb -= c));
    },
    Ne = function (a) {
      try {
        a.vd(a.setTime.add(a.Bb));
      } finally {
        (a.completed = !0), a.Ac();
      }
    };
  Me.prototype.yd = function (a, b) {
    this.completed ||
      (this.mode === 1 && a === 1
        ? Oe(this, b)
        : this.mode === 1 && a === 0
        ? ((this.mode = a),
          Oe(this, this.o.now()),
          this.completed || (this.id = Le(this)))
        : this.mode === 0 &&
          a === 1 &&
          ((this.mode = a), this.clear(), Oe(this, b)));
  };
  Me.prototype.clear = function () {
    this.completed || this.o.clearTimeout(this.id);
  };
  var Pe = function (a) {
    this.Ec = a;
    this.Vc = this.mode = 0;
    this.ga = {};
    this.timeline = a.timeline;
    this.Sa = a.now();
  };
  n = Pe.prototype;
  n.yd = function (a, b) {
    this.mode = a;
    Wd(this.Sa, b);
    this.Sa = b;
    Object.values(this.ga).forEach(function (c) {
      return void c.yd(a, b);
    });
  };
  n.now = function () {
    return this.mode === 1 ? this.Sa : this.Ec.now();
  };
  n.setTimeout = function (a, b) {
    var c = this,
      d = ++this.Vc,
      e = this.mode === 1 ? this.Sa : this.Ec.now();
    this.ga[d] = new Me(
      this.mode,
      this.Ec,
      e,
      b,
      function (g) {
        var f = c.Sa;
        c.mode === 1 && (c.Sa = g);
        a();
        c.Sa = f;
      },
      function () {
        delete c.ga[d];
      }
    );
    return d;
  };
  n.clearTimeout = function (a) {
    this.ga[a] && (this.ga[a].clear(), delete this.ga[a]);
  };
  n.interval = function () {
    throw Error("E");
  };
  n.Tb = function () {
    throw Error("F");
  };
  function Qe(a, b) {
    var c = new Pe(a);
    a = b.subscribe(function (d) {
      c.yd(d.value ? 1 : 0, d.timestamp);
    });
    return { o: c, Oj: a };
  }
  function Re(a) {
    var b = Object.assign({}, a);
    delete b.timestamp;
    return { timestamp: new Vd(a.timestamp, Ud), value: b };
  }
  function Se(a) {
    return (
      a !== void 0 &&
      typeof a.x === "number" &&
      typeof a.y === "number" &&
      typeof a.width === "number" &&
      typeof a.height === "number"
    );
  }
  function Te(a) {
    var b = a.indexOf("//") + 2,
      c = a.indexOf("/", b);
    if (c <= b)
      return "Can't interpolate data in a url's origin, Please make sure to fully specify the origin, terminated with '/'.";
    a = a.substring(b, c);
    if (!/^[0-9a-z.:-]+$/i.test(a))
      return "The origin contains unsupported characters.";
    if (!/^[^:]*(:[0-9]+)?$/i.test(a)) return "Invalid port number.";
    if (!/(^|\.)[a-z][^.]*$/i.test(a))
      return "The top-level domain must start with a letter.";
  }
  function Ue(a) {
    a = a.toLowerCase();
    if (/^data:/.test(a))
      return "Data URLs cannot have expressions in the template literal input.";
    if (/^https:\/\//.test(a) || /^\/\//.test(a)) return Te(a);
    if (/^\//.test(a))
      return (
        (a =
          a === "/" || (a.length > 1 && a[1] !== "/" && a[1] !== "\\")
            ? void 0
            : "The path start in the url is invalid."),
        a
      );
    if (/^about:blank/.test(a))
      return (
        (a =
          a === "about:blank" || /^about:blank#/.test(a)
            ? void 0
            : "The about url is invalid."),
        a
      );
    if (!RegExp("^[^:\\s\\\\/]+/").test(a))
      return "Trying to interpolate expressions in an unsupported url format. The template literal must start with a compile-time static origin (e.g. 'https://example.com/'), absolute path ('/path/'), or relative path ('path/'). See go/ts-dom-sink#trustedresourceurl.";
  }
  function Ve(a) {
    var b = F.apply(1, arguments),
      c = b.length;
    if (
      !Array.isArray(a) ||
      !Array.isArray(a.raw) ||
      a.length !== a.raw.length ||
      (!wb && a === a.raw) ||
      !((wb && !xb) || ub(a)) ||
      c + 1 !== a.length
    )
      throw new TypeError("x");
    if (b.length === 0) return lb(a[0]);
    c = Ue(a[0]);
    if (c !== void 0) throw Error(c);
    c = a[0];
    for (var d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
    return lb(c);
  }
  var Xe = wa([
      "https://www.googleadservices.com/pagead/managed/js/activeview/",
      "/reach_worklet.html",
    ]),
    Ye = wa(["./reach_worklet.js"]),
    Ze = wa(["./reach_worklet.js"]),
    $e = wa(["./reach_worklet.html"]),
    af = wa(["./reach_worklet.js"]),
    bf = wa(["./reach_worklet.js"]);
  function cf() {
    var a = {};
    return (a[0] = Ve(Xe, "current")), (a[1] = Ve(Ye)), (a[2] = Ve(Ze)), a;
  }
  Ve($e);
  Ve(af);
  Ve(bf);
  var ef = function (a, b, c, d) {
    c = c === void 0 ? null : c;
    d = d === void 0 ? cf() : d;
    Kd.call(this);
    this.ha = a;
    this.kc = b;
    this.Nb = c;
    this.Ia = null;
    this.od = new Wc(3);
    this.qd = this.od.i(
      S(function (e) {
        return e.value.type === "sessionStart";
      })
    );
    this.He = this.od.i(
      S(function (e) {
        return e.value.type === "sessionFinish";
      })
    );
    this.Sc = new Wc(1);
    this.zd = new Wc();
    this.Oa = new Wc(10);
    this.Za = new Ie(this, new De(a));
    this.sg = this.ha.Ra();
    this.o = df(this, new He(this.ha));
  };
  v(ef, Kd);
  ha.Object.defineProperties(ef.prototype, {
    global: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return ff;
      },
    },
  });
  ef.prototype.validate = function () {
    return this.sg;
  };
  var df = function (a, b) {
      a.Ia = new be(a.ha, a.kc);
      var c = new Wc();
      ce(a.Ia, function (g) {
        g = Re(g);
        c.next({ timestamp: g.timestamp, value: !0 });
        a.od.next(g);
      });
      ee(a.Ia, function (g) {
        if (g === void 0) var f = !1;
        else {
          f = g.data;
          var h;
          (h = f === void 0) ||
            ((h = f.viewport),
            (h =
              h === void 0 ||
              (h !== void 0 &&
                typeof h.width === "number" &&
                typeof h.height === "number")));
          h
            ? ((f = f.adView),
              (f =
                f !== void 0 &&
                typeof f.percentageInView === "number" &&
                (f.geometry === void 0 || Se(f.geometry)) &&
                (f.onScreenGeometry === void 0 || Se(f.onScreenGeometry))))
            : (f = !1);
        }
        f
          ? ((g = Re(g)),
            c.next({ timestamp: g.timestamp, value: !0 }),
            a.Oa.next(g))
          : 0.01 >= Math.random() &&
            ((g =
              "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&name=invalid_geo&context=1092&msg=" +
              JSON.stringify(g)),
            Ke(a.Za, g).sendNow());
      });
      de(a.Ia, function (g) {
        g = Re(g);
        c.next({ timestamp: g.timestamp, value: !0 });
        a.zd.next(g);
      });
      fe(a.Ia, function (g) {
        g = Re(g);
        c.next({ timestamp: g.timestamp, value: !0 });
        a.Sc.next(g);
      });
      var d = 0;
      ge(a.Ia, function (g) {
        d += g;
        d > 0 && g === 0 && c.next({ timestamp: a.o.now(), value: !1 });
      });
      var e = c.i(
        Ae(function (g) {
          return g.value;
        })
      );
      return Qe(b, e).o;
    },
    ff = {};
  var gf = function (a) {
    var b = b === void 0 ? Symbol() : b;
    this.sessionId = a;
    this.Db = b;
  };
  var hf = O(
    R(function (a) {
      return a.value;
    }),
    S(function (a) {
      return a.type === "sessionStart";
    }),
    R(function (a) {
      return new gf(a.ia);
    })
  );
  function Y(a, b) {
    return function (c) {
      return c.i(jf(a, we(b)));
    };
  }
  function jf(a, b) {
    function c(d) {
      return new P(function (e) {
        return d.subscribe(
          function (g) {
            eb(
              a,
              function () {
                return void e.next(g);
              },
              3
            );
          },
          function (g) {
            eb(
              a,
              function () {
                return void e.error(g);
              },
              3
            );
          },
          function () {
            eb(
              a,
              function () {
                return void e.complete();
              },
              3
            );
          }
        );
      });
    }
    return O(c, dd(), b, ad(), c);
  }
  var kf = function (a) {
    this.value = a;
  };
  kf.prototype.Ea = function (a) {
    return Uc(this.value).i(Y(a, 1));
  };
  var lf = new kf(!1),
    mf = new kf(!0);
  function nf(a, b) {
    return of(a, b, 2);
  }
  function of(a, b, c) {
    return new P(function (d) {
      var e = !1,
        g = Array(b.length);
      g.fill(void 0);
      var f = new Set(),
        h = new Set(),
        k = function (t, q) {
          a.Eh
            ? ((g[q] = t),
              f.add(q),
              e ||
                ((e = !0),
                eb(
                  a,
                  function () {
                    e = !1;
                    var w = d.next;
                    var z = g.length;
                    if (z > 0) {
                      for (var K = Array(z), x = 0; x < z; x++) K[x] = g[x];
                      z = K;
                    } else z = [];
                    w.call(d, z);
                  },
                  c
                )))
            : d.error(new Qd(q));
        },
        l = function (t, q) {
          h.add(q);
          f.add(q);
          eb(
            a,
            function () {
              d.error(t);
            },
            c
          );
        },
        m = function (t) {
          h.add(t);
          eb(
            a,
            function () {
              h.size === b.length && d.complete();
            },
            c
          );
        },
        r = b.map(function (t, q) {
          return t.subscribe(
            function (w) {
              return void k(w, q);
            },
            function (w) {
              return void l(w, q);
            },
            function () {
              return void m(q);
            }
          );
        });
      return function () {
        r.forEach(function (t) {
          return void t.unsubscribe();
        });
      };
    });
  }
  function pf(a, b, c) {
    function d() {
      if (b.Nb) {
        var y = b.Nb,
          B = y.next;
        var M = {
          creativeId: b.Od.getName(c),
          requiredSignals: e,
          signals: Object.assign({}, g),
          hasPrematurelyCompleted: f,
          errorMessage: h,
          erroredSignalKey: k,
        };
        M = {
          specMajor: 2,
          specMinor: 0,
          specPatch: 0,
          timestamp: Xd(b.o.now(), new Vd(0, b.o.timeline)),
          instanceId: b.Od.getName(b.Db),
          creativeState: M,
        };
        B.call(y, M);
      }
    }
    var e = Object.keys(a),
      g = {},
      f = !1,
      h = null,
      k = null,
      l = {},
      m = new Set(),
      r = [],
      t = [],
      q = A(e),
      w = q.next();
    try {
      for (var z = {}; !w.done; z = { la: void 0 }, w = q.next()) {
        z.la = w.value;
        var K = a[z.la];
        if (K instanceof kf)
          (l[z.la] = K.value),
            m.add(z.la),
            b.Nb && (g[String(z.la)] = Zd(K.value));
        else {
          var x = K.i(
            T(function (y, B) {
              return Ld(y) || Ld(B) ? !1 : y === B;
            }),
            R(
              (function (y) {
                return function (B) {
                  b.Nb && ((g[String(y.la)] = Zd(B)), d());
                  var M = {};
                  return (M[y.la] = B), M;
                };
              })(z)
            ),
            me(
              (function (y) {
                return function (B) {
                  if (B instanceof Qd) throw new Sd(String(y.la));
                  throw B;
                };
              })(z)
            ),
            Be(
              (function (y) {
                return function () {
                  m.add(y.la);
                };
              })(z),
              (function (y) {
                return function (B) {
                  k = String(y.la);
                  h = String(B);
                  d();
                };
              })(z),
              (function (y) {
                return function () {
                  m.has(y.la) || ((f = !0), d());
                };
              })(z)
            )
          );
          t.push(z.la);
          r.push(x);
        }
      }
    } finally {
      xa(q, w);
    }
    (a = Object.keys(g).length > 0) && d();
    q = of(b.queue, r, 1).i(
      me(function (y) {
        if (y instanceof Qd) throw new Rd(String(t[y.kg]));
        throw y;
      }),
      R(function (y) {
        return Object.freeze(
          Object.assign.apply(Object, [{}, l].concat(sa(y)))
        );
      })
    );
    return (r = r.length > 0) && a
      ? Ad(Uc(Object.freeze(l)), q)
      : r
      ? q
      : Uc(Object.freeze(l));
  }
  function qf(a, b, c, d) {
    var e = rf();
    return a.gd.bi.bind(a.gd)(733, function () {
      var g = {};
      try {
        return b
          .i(
            me(function (f) {
              d(C({}, g, { error: f }));
              return zc;
            }),
            sd(function (f) {
              try {
                var h = c(a, f);
              } catch (l) {
                return (
                  d(C({}, g, { error: l instanceof Error ? l : String(l) })), zc
                );
              }
              var k = {};
              return pf(h, a, f.Db)
                .i(
                  Be(function (l) {
                    k = l;
                  }),
                  we(1),
                  ad()
                )
                .i(
                  e,
                  me(function (l) {
                    d(C({}, k, { error: l }));
                    return zc;
                  }),
                  se(void 0),
                  R(function () {
                    return !0;
                  })
                );
            })
          )
          .i(
            U(function (f) {
              return f + 1;
            }, 0),
            me(function (f) {
              d(C({}, g, { error: f }));
              return zc;
            })
          );
      } catch (f) {
        return d(C({}, g, { error: f })), zc;
      }
    })();
  }
  function sf(a) {
    var b = new Map();
    if (typeof a !== "object" || a === null) return b;
    Object.values(a).forEach(function (c) {
      c &&
        typeof c.Td === "function" &&
        (b.has(c.clock.timeline) || b.set(c.clock.timeline, c.clock.now()));
    });
    return b;
  }
  function tf(a, b, c) {
    var d = uf,
      e = vf;
    c = c === void 0 ? 0.01 : c;
    return function (g) {
      c > 0 &&
        Math.random() <= c &&
        (a.global.HTMLFencedFrameElement &&
          a.global.fence &&
          typeof a.global.fence.reportEvent === "function" &&
          a.global.fence.reportEvent({
            eventType: "active-view-error",
            eventData: "",
            destination: ["buyer"],
          }),
        (g = C({}, g, {
          errorMessage:
            g.error instanceof Error && g.error.message
              ? g.error.message
              : String(g.error),
          Mf:
            g.error instanceof Error && g.error.stack
              ? String(g.error.stack)
              : null,
          Kf:
            g.error instanceof Error && g.error.name
              ? String(g.error.name)
              : null,
          If: String(a.gd.Oe),
          Jf: g.Nf,
        })),
        d(
          C({}, g, {
            jh: (function () {
              return function (f) {
                try {
                  return e(C({}, f));
                } catch (h) {
                  return {};
                }
              };
            })(),
            hc: [b],
          }),
          sf(g)
        ).forEach(function (f) {
          Ke(a.Za, f).sendNow();
        }));
    };
  }
  var vf = function (a) {
      return Object.assign(
        {},
        {
          v: a.rf,
          bin: a.pf,
          cb: a.uf,
          e: a.event,
          sdk: a.Oh,
          p: a.Ma,
          tm: a.ii,
          tu: a.ji,
          tos: a.dc,
          mtos: a.Ha,
          mcvt: a.yg,
          ps: a.Hf,
          scs: a.Nh,
          bs: a.ui,
          mut: a.Lj,
          a: a.volume,
          ft: a.Wd,
          dft: a.Y,
          at: a.vc,
          dat: a.V,
          amtos: a.me,
          as: a.gf,
          vpt: a.Ad,
          is: a.Qa,
          i0: a.og,
          i1: a.lg,
          i2: a.mg,
          i3: a.ng,
          ic: a.aa,
          cs: a.Cf,
          gmm: a.dg,
          std: a.si,
          nnut: a.Pj,
          nmt: a.Rg,
          pst: a.Rj,
          tcm: a.ai,
          dur: a.duration,
          vmtime: a.Jj,
          dtos: a.ca,
          dtoss: a.ci,
          vmer: a.ek,
          vmmk: a.gk,
          vmiec: a.fk,
          c: a.ka,
          mc: a.zg,
          nc: a.Kg,
          lte: a.ad,
          tth: a.ak,
          femt: a.Aj,
          femvt: a.Bj,
          emc: a.vj,
          emuc: a.wj,
          emb: a.uj,
          mv: a.Dg,
          nv: a.Lg,
          avms: a.Ig,
          qi: a.Tj,
          psv: a.oh,
          psfv: a.mh,
          psa: a.kh,
          psm: a.nh,
          ces: a.Df,
          veid: a.zj,
          ssb: a.Ih,
          omida: a.Wg,
          omidp: a.dh,
          omidpv: a.eh,
          omidor: a.bh,
          omidv: a.gh,
          omids: a.fh,
          omidam: a.Vg,
          omidct: a.Xg,
          omidia: a.se,
          omiddc: a.Yg,
          omidlat: a.ah,
          omiddit: a.Zg,
          sfr: a.Zj,
          nopd: a.ed,
          qid: a.Jf,
        },
        {
          bt: a.qj,
          dvs: a.ea,
          dfvs: a.Z,
          dvpt: a.da,
          context: a.If,
          msg: a.errorMessage,
          stack: a.Mf,
          name: a.Kf,
          rxdbg: a.Fh,
        }
      );
    },
    xf = function (a) {
      var b = {
        p0: a.Af,
        p1: a.xf,
        p2: a.yf,
        p3: a.zf,
        a0: a.Ai,
        a1: a.xi,
        a2: a.yi,
        a3: a.zi,
        c0: a.Uf,
        c1: a.Rf,
        c2: a.Sf,
        c3: a.Tf,
        ss0: a.Mh,
        ss1: a.Jh,
        ss2: a.Kh,
        ss3: a.Lh,
        qmt: a.ye,
        qnc: a.xh,
        qas: a.xe,
        qnv: a.Ae,
        qmv: a.ze,
        mtos1: wf([0, 2, 4], a.Ag, !1),
        mtos2: wf([0, 2, 4], a.Bg, !1),
        mtos3: wf([0, 2, 4], a.Cg, !1),
      };
      return Object.assign({}, vf(a), b);
    },
    yf = function (a) {
      var b = { qmt: a.ye, qnc: a.xh, qas: a.xe, qnv: a.Ae, qmv: a.ze };
      return Object.assign({}, vf(a), b);
    },
    zf = function (a) {
      var b = Object,
        c = b.assign,
        d = vf(a);
      a = {
        atos: a.wc,
        avt: wf([2], a.wc),
        davs: a.X,
        dafvs: a.U,
        dav: a.W,
        ss: a.kb,
      };
      return c.call(b, {}, d, a);
    };
  function wf(a, b, c) {
    if (b)
      return c === void 0 || c
        ? Kb(b, function (d, e) {
            return Jb(a, e) >= 0;
          })
        : Lb(a, function (d, e, g) {
            return b
              .slice(e > 0 ? g[e - 1] + 1 : 0, d + 1)
              .reduce(function (f, h) {
                return f + h;
              }, 0);
          });
  }
  function Af() {
    var a = F.apply(0, arguments);
    return function (b) {
      var c = b.i(we(1), ad());
      b = a.map(function (d) {
        return c.i(d, se(!0));
      });
      return nd(b).i(qe(1), oe());
    };
  }
  function Bf() {
    var a = F.apply(0, arguments);
    return function (b) {
      var c = b.i(we(1), ad());
      b = a.map(function (d) {
        return c.i(d, se(!0));
      });
      return Ad.apply(null, sa(b)).i(qe(1), oe());
    };
  }
  function rf() {
    var a = Af(Cf, Df, Ef, Ff, Gf, Hf, Jf, Kf, Lf, Mf, Nf, Of, Pf),
      b = Bf(Qf, Rf, Sf);
    return function (c) {
      var d = c.i(we(1), ad());
      c = d.i(a, se(!0));
      d = d.i(O(b, we(), ad()), se(!0));
      c = nd([c, d]);
      return Fd(c, d).i(qe(1), oe());
    };
  }
  var Tf = function () {
      this.startTime = Math.floor(Date.now() / 1e3 - 1704067200);
      this.sequenceNumber = 0;
    },
    Uf = function (a) {
      var b = "" + a.startTime + a.sequenceNumber.toString(10).padStart(2, "0");
      a.sequenceNumber < 99 && a.sequenceNumber++;
      return b;
    };
  function Vf(a, b) {
    return typeof a === "string"
      ? encodeURIComponent(a)
      : typeof a === "number"
      ? String(a)
      : Array.isArray(a)
      ? a
          .map(function (c) {
            return Vf(c, b);
          })
          .join(",")
      : a instanceof Vd
      ? a.toString()
      : a && typeof a.Td === "function"
      ? Vf(a.yj(b).value, b)
      : a === !0
      ? "1"
      : a === !1
      ? "0"
      : a === void 0 || a === null
      ? null
      : a instanceof Tf
      ? Uf(a)
      : [a.top, a.left, a.top + a.height, a.left + a.width].join();
  }
  function Wf(a, b) {
    a = Object.entries(a)
      .map(function (c) {
        var d = A(c);
        c = d.next().value;
        d = d.next().value;
        d = Vf(d, b);
        return d === null ? "" : c + "=" + d;
      })
      .filter(function (c) {
        return c !== "";
      });
    return a.length ? a.join("&") : "";
  }
  function uf(a, b) {
    var c = a.jh(a),
      d = Wf(c, b);
    return d
      ? Lb(a.hc, function (e) {
          e = e.indexOf("?") >= 0 ? e : e + "?";
          e = "?&".indexOf(e.slice(-1)) >= 0 ? e : e + "&";
          return e + d;
        })
      : a.hc;
  }
  function Xf(a) {
    var b = [],
      c = 0,
      d;
    for (d in a) b[c++] = d;
    return b;
  }
  var Yf = /(?:\[|%5B)([a-zA-Z0-9_]+)(?:\]|%5D)/g,
    dc = bc(
      cc(),
      "google3.javascript.ads.common.url_macros_substitutor",
      Sb
    ).wg;
  function Zf(a, b) {
    return a.replace(Yf, function (c, d) {
      try {
        var e = b !== null && d in b ? b[d] : void 0;
        if (e == null)
          return ec("No value supplied for unsupported macro: " + d), c;
        if (e.toString() == null)
          return (
            ec("The toString method of value returns null for macro: " + d), c
          );
        e = e.toString();
        if (e == "" || !/^[\s\xa0]*$/.test(e == null ? "" : String(e)))
          return encodeURIComponent(e).replace(/%2C/g, ",");
        ec("Null value supplied for macro: " + d);
      } catch (g) {
        ec("Failed to set macro: " + d);
      }
      return c;
    });
  }
  function $f(a, b) {
    var c = a.B(a),
      d = a.cg(a),
      e = Wf(c, b),
      g = Wf(d, b);
    return Lb(a.hc, function (f) {
      var h = {};
      return Zf(f, ((h.VIEWABILITY = e), (h.GOOGLE_VIEWABILITY = g), h));
    });
  }
  function ag(a, b) {
    return O(
      ze(function (c) {
        var d = a(c),
          e = b(c),
          g = {};
        return d && e && g
          ? new P(function (f) {
              e(d, g, function (h) {
                f.next(C({}, c, { tf: h }));
                f.complete();
              });
              return function () {};
            })
          : Bd;
      }),
      S(function (c) {
        return c.tf;
      })
    );
  }
  function bg(a, b, c) {
    if (c.has(a) && c.get(a).has(b)) return !0;
    if (c.has(a)) c.get(a).add(b);
    else {
      var d = new Set();
      d.add(b);
      c.set(a, d);
    }
    return !1;
  }
  function cg(a, b, c) {
    c = c === void 0 ? new Map() : c;
    return a === b
      ? !0
      : a instanceof Error && b instanceof Error
      ? cg(C({}, a, { stack: null }), C({}, b, { stack: null }), c)
      : Array.isArray(a) && Array.isArray(b)
      ? bg(a, b, c)
        ? !0
        : Nb(a, b, function (d, e) {
            return cg(d, e, c);
          })
      : Ya(a) && Ya(b)
      ? bg(a, b, c)
        ? !0
        : dg(a, b, c)
      : !1;
  }
  function dg(a, b, c) {
    if (a === b) return !0;
    if (Xf(a).length !== Xf(b).length) return !1;
    for (var d in a) if (a.hasOwnProperty(d) && !cg(a[d], b[d], c)) return !1;
    return !0;
  }
  function eg() {
    return O(
      S(function (a) {
        return a !== void 0;
      }),
      R(function (a) {
        return a;
      })
    );
  }
  function fg(a, b) {
    b = Math.pow(10, b);
    return Math.round(a * b) / b;
  }
  function gg(a) {
    return a.length <= 0
      ? zc
      : nd(
          a.map(function (b) {
            var c = 0;
            return b.i(
              R(function (d) {
                return { index: c++, value: d };
              })
            );
          })
        ).i(
          S(function (b) {
            return b.every(function (c) {
              return c.index === b[0].index;
            });
          }),
          R(function (b) {
            return b.map(function (c) {
              return c.value;
            });
          })
        );
  }
  function hg(a, b) {
    a.Nd && (a.hd = a.Nd);
    a.Nd = b;
    a.hd && a.hd.value
      ? ((b = Math.max(0, Xd(b.timestamp, a.hd.timestamp))),
        (a.totalTime += b),
        (a.rb += b))
      : (a.rb = 0);
    return a;
  }
  function ig() {
    return O(
      U(hg, { totalTime: 0, rb: 0 }),
      R(function (a) {
        return a.totalTime;
      })
    );
  }
  function jg() {
    return O(
      U(hg, { totalTime: 0, rb: 0 }),
      R(function (a) {
        return a.rb;
      })
    );
  }
  var kg = R(function (a) {
    return [a.value.Da.width, a.value.Da.height];
  });
  function lg(a, b) {
    return function (c) {
      return gg(
        b.map(function (d) {
          return c.i(a(d));
        })
      );
    };
  }
  function mg() {
    var a;
    return O(
      Be(function (b) {
        return void (a = b.timestamp);
      }),
      jg(),
      R(function (b) {
        return { timestamp: a, value: Math.round(b) };
      })
    );
  }
  function ng(a, b) {
    return b.i(
      S(function (c) {
        return c.value.type === "start";
      }),
      R(function (c) {
        return Number(c.value.data.duration) || 0;
      }),
      R(function (c) {
        return 1e3 * c;
      }),
      Y(a, 1)
    );
  }
  function og(a) {
    return ["backgrounded", "notFound", "hidden", "noOutputDevice"].includes(a);
  }
  function pg(a, b) {
    return a.Oa.i(
      S(function (c) {
        return c.value.ia === b.sessionId;
      }),
      R(function (c) {
        var d = c.value.data.adView.reasons.some(og);
        return { timestamp: c.timestamp, value: d };
      }),
      V({ timestamp: a.o.now(), value: !1 }),
      Y(a.queue, 1)
    );
  }
  function qg(a, b) {
    return a.Oa.i(
      S(function (c) {
        return c.value.ia === b.sessionId;
      }),
      R(function (c) {
        var d = c.value.data.adView.reasons.includes("noOutputDevice");
        return { timestamp: c.timestamp, value: d };
      }),
      Y(a.queue, 1)
    );
  }
  function rg(a, b) {
    var c = pg(a, b);
    b = qg(a, b);
    a = b.i(
      U(function (d, e) {
        return d || e.value;
      }, !1),
      V(!1),
      T(),
      Y(a.queue, 1)
    );
    return {
      Zf: c,
      ed: a,
      ki: b.i(
        R(function (d) {
          return d.value;
        })
      ),
    };
  }
  var sg = { left: 0, top: 0, width: 0, height: 0 };
  function tg(a, b) {
    return (
      a.left === b.left &&
      a.top === b.top &&
      a.width === b.width &&
      a.height === b.height
    );
  }
  function ug(a, b) {
    b = b === void 0 ? new Set() : b;
    if (b.has(a)) return "(Recursive reference)";
    switch (typeof a) {
      case "object":
        if (a) {
          var c = Object.getPrototypeOf(a);
          switch (c) {
            case Map.prototype:
            case Set.prototype:
            case Array.prototype:
              b.add(a);
              var d =
                "[" +
                Array.from(a, function (e) {
                  return ug(e, b);
                }).join(", ") +
                "]";
              b.delete(a);
              c !== Array.prototype && (d = vg(c.constructor) + "(" + d + ")");
              return d;
            case Object.prototype:
              return (
                b.add(a),
                (c =
                  "{" +
                  Object.entries(a)
                    .map(function (e) {
                      var g = A(e);
                      e = g.next().value;
                      g = g.next().value;
                      return e + ": " + ug(g, b);
                    })
                    .join(", ") +
                  "}"),
                b.delete(a),
                c
              );
            default:
              return (
                (d = "Object"),
                c && c.constructor && (d = vg(c.constructor)),
                typeof a.toString === "function" &&
                a.toString !== Object.prototype.toString
                  ? d + "(" + String(a) + ")"
                  : "(object " + d + ")"
              );
          }
        }
        break;
      case "function":
        return "function " + vg(a);
      case "number":
        if (!Number.isFinite(a)) return String(a);
        break;
      case "bigint":
        return a.toString(10) + "n";
      case "symbol":
        return a.toString();
    }
    return JSON.stringify(a);
  }
  function vg(a) {
    var b = a.displayName;
    return (b && typeof b === "string") ||
      ((b = a.name) && typeof b === "string")
      ? b
      : (a = /function\s+([^\(]+)/m.exec(String(a)))
      ? a[1]
      : "(Anonymous)";
  }
  function wg(a, b) {
    var c = xg,
      d = [];
    yg(b, a, d) ||
      zg.apply(
        null,
        [void 0, c, "Guard " + b.Pc().trim() + " failed:"].concat(
          sa(d.reverse())
        )
      );
  }
  function Ag(a, b) {
    wg(a, b);
    return a;
  }
  function Bg(a) {
    var b = xg;
    a || zg("Guard truthy failed:", b || "Expected truthy, got " + ug(a));
  }
  function Cg(a) {
    return Ag(a, Dg);
  }
  function Eg(a, b) {
    a.Fj = !0;
    a.Pc =
      typeof b === "function"
        ? b
        : function () {
            return b;
          };
    return a;
  }
  function yg(a, b, c) {
    var d = a(b, c);
    d ||
      Fg(c, function () {
        var e = "";
        e.length > 0 && (e += ": ");
        return e + "Expected " + a.Pc().trim() + ", got " + ug(b);
      });
    return d;
  }
  function Fg(a, b) {
    a == null || a.push((typeof b === "function" ? b() : b).trim());
  }
  var xg = void 0;
  function Gg(a) {
    return typeof a === "function" ? a() : a;
  }
  function zg() {
    throw Error(
      F.apply(0, arguments)
        .map(Gg)
        .filter(Boolean)
        .join("\n")
        .trim()
        .replace(/:$/, "")
    );
  }
  var Dg = Eg(function (a) {
    return a !== null && a !== void 0;
  }, "exists");
  var Hg = Eg(function (a) {
      return typeof a === "number";
    }, "number"),
    Ig = Eg(function (a) {
      return typeof a === "string";
    }, "string"),
    Jg = Eg(function (a) {
      return typeof a === "boolean";
    }, "boolean"),
    Kg = Eg(function (a) {
      return typeof a === "bigint";
    }, "bigint"),
    Lg = Eg(function (a) {
      return typeof a === "function";
    }, "Function");
  function Mg(a) {
    return Eg(
      function (b) {
        return b instanceof a;
      },
      function () {
        return vg(a);
      }
    );
  }
  function Ng() {
    var a = F.apply(0, arguments);
    return Eg(
      function (b) {
        return a.some(function (c) {
          return c(b);
        });
      },
      function () {
        return (
          "" +
          a
            .map(function (b) {
              return b.Pc().trim();
            })
            .join(" | ")
        );
      }
    );
  }
  function Og(a, b, c) {
    c = c === void 0 ? null : c;
    var d = new xc(),
      e = void 0,
      g = a.Oa,
      f = d.i(
        R(function () {
          return e ? Object.assign({}, e, { timestamp: a.o.now() }) : null;
        }),
        S(function (k) {
          return k !== null;
        }),
        R(function (k) {
          return k;
        })
      );
    b = nd([Ad(g, f), b]);
    var h = c;
    return b.i(
      S(function (k) {
        k = A(k).next().value;
        h === null && (h = k.value.ia);
        return k.value.ia === h;
      }),
      Be(function (k) {
        return void (e = A(k).next().value);
      }),
      R(function (k) {
        var l = A(k);
        k = l.next().value;
        l = l.next().value;
        try {
          var m = k.value.data,
            r = k.timestamp,
            t = m.viewport,
            q,
            w,
            z = C({}, t, {
              width: (q = t == null ? void 0 : t.width) != null ? q : 0,
              height: (w = t == null ? void 0 : t.height) != null ? w : 0,
              x: 0,
              y: 0,
              Qj: t ? t.width * t.height : 0,
            }),
            K = Pg(z),
            x = m.adView,
            y =
              x.measuringElement && x.containerGeometry
                ? Pg(x.containerGeometry)
                : Pg(x.geometry),
            B = Pg(x.geometry),
            M = x.reasons.some(og),
            D = M ? sg : Pg(x.onScreenGeometry),
            G;
          l && (G = x.percentageInView / 100);
          l && M && (G = 0);
          return {
            timestamp: r,
            value: {
              nb: "omid",
              ub: y,
              Da: K,
              ta: d,
              wa: "omid",
              qa: B,
              Fb: { x: y.left, y: y.top },
              za: D,
              Ob: G,
            },
          };
        } catch (I) {
          wg(I, Mg(Error));
          var va, Ha;
          m =
            (Ha = (va = I) == null ? void 0 : va.message) != null
              ? Ha
              : "An unknown error occurred";
          va =
            "Error while processing geometryChange event: " +
            JSON.stringify(k.value) +
            "; " +
            m;
          throw Error(va);
        }
      }),
      we(1),
      ad()
    );
  }
  function Pg(a) {
    var b, c, d, e;
    return {
      left: Math.floor((b = a == null ? void 0 : a.x) != null ? b : 0),
      top: Math.floor((c = a == null ? void 0 : a.y) != null ? c : 0),
      width: Math.floor((d = a == null ? void 0 : a.width) != null ? d : 0),
      height: Math.floor((e = a == null ? void 0 : a.height) != null ? e : 0),
    };
  }
  var Qg = {
    nb: "ns",
    ub: sg,
    Da: sg,
    ta: new xc(),
    wa: "ns",
    qa: sg,
    za: sg,
    Fb: { x: 0, y: 0 },
  };
  function Rg(a, b) {
    return (
      tg(a.Da, b.Da) &&
      tg(a.qa, b.qa) &&
      tg(a.ub, b.ub) &&
      tg(a.za, b.za) &&
      a.wa === b.wa &&
      a.ta === b.ta &&
      a.nb === b.nb &&
      a.Fb.x === b.Fb.x &&
      a.Fb.y === b.Fb.y
    );
  }
  function Sg(a) {
    return function (b) {
      var c;
      return b.i(
        Be(function (d) {
          return void (c = d.timestamp);
        }),
        R(function (d) {
          return d.value;
        }),
        a,
        R(function (d) {
          return { timestamp: c, value: d };
        })
      );
    };
  }
  function Tg(a) {
    return (a.za.width * a.za.height) / (a.qa.width * a.qa.height);
  }
  var Ug = Sg(
      O(
        R(function (a) {
          var b;
          return (b = a.Ob) != null ? b : Tg(a);
        }),
        R(function (a) {
          return isFinite(a) ? a : 0;
        })
      )
    ),
    Vg = Sg(
      O(
        R(function (a) {
          var b;
          return (b = a.Ob) != null ? b : Tg(a);
        }),
        R(function (a) {
          return isFinite(a) ? a : -1;
        })
      )
    );
  var Xg = function (a, b, c, d, e) {
      this.o = b;
      this.Fc = c;
      this.vd = d;
      this.Ac = e;
      this.completed = this.Pb = !1;
      this.setTime = b.now();
      this.id = (this.Pb = a) ? 0 : Wg(this);
    },
    Wg = function (a) {
      return a.o.setTimeout(function () {
        try {
          a.vd();
        } finally {
          (a.completed = !0), a.Ac();
        }
      }, a.Fc);
    };
  Xg.prototype.clear = function () {
    this.completed || this.o.clearTimeout(this.id);
  };
  Xg.prototype.freeze = function (a) {
    this.Pb ||
      this.completed ||
      ((a = Xd(a, this.setTime)),
      (this.Fc = Math.max(0, this.Fc - a)),
      this.o.clearTimeout(this.id),
      (this.Pb = !0));
  };
  var Yg = function (a) {
      this.ve = a;
      this.timeline = Symbol();
      this.tc = 0;
      this.isFrozen = !1;
      this.Vc = 0;
      this.ga = {};
      this.Yc = a.now();
    },
    Zg = function (a, b) {
      Object.values(a.ga).forEach(function (c) {
        return void c.freeze(b);
      });
    },
    $g = function (a) {
      Object.values(a.ga).forEach(function (b) {
        b.Pb && !b.completed && ((b.setTime = b.o.now()), (b.id = Wg(b)));
      });
    };
  Yg.prototype.setTimeout = function (a, b) {
    var c = this,
      d = ++this.Vc;
    this.ga[d] = new Xg(this.isFrozen, this.ve, b, a, function () {
      return void delete c.ga[d];
    });
    return d;
  };
  Yg.prototype.clearTimeout = function (a) {
    this.ga[a] && (this.ga[a].clear(), delete this.ga[a]);
  };
  Yg.prototype.interval = function (a, b) {
    var c = this.Tb(a).subscribe(b);
    return function () {
      return void c.unsubscribe();
    };
  };
  Yg.prototype.Tb = function (a) {
    return Ge(this, a).i(
      xe(),
      U(function (b) {
        return b + 1;
      }, -1)
    );
  };
  var ah = function (a, b) {
    var c = a.isFrozen ? Math.max(0, Xd(b, a.Yc)) : 0;
    b = Xd(b, new Vd(0, b.timeline));
    return new Vd(b - a.tc - c, a.timeline);
  };
  Yg.prototype.now = function () {
    return ah(this, this.ve.now());
  };
  var bh = function (a) {
    return R(function (b) {
      var c = b.timestamp;
      b = b.value;
      return { timestamp: ah(a, c), value: b };
    });
  };
  function ch(a, b) {
    var c = new Yg(a);
    a = b.subscribe(function (d) {
      c.isFrozen && (c.tc += Math.max(0, Xd(d.timestamp, c.Yc)));
      c.Yc = d.timestamp;
      (c.isFrozen = d.value) ? Zg(c, d.timestamp) : $g(c);
    });
    return { o: c, Cj: a };
  }
  function dh(a, b) {
    return a >= 1 ? !0 : a <= 0 ? !1 : a >= b;
  }
  function eh(a) {
    return function (b) {
      return b.i(
        Ce(a),
        R(function (c) {
          var d = A(c);
          c = d.next().value;
          d = d.next().value;
          return { timestamp: c.timestamp, value: dh(c.value, d) };
        })
      );
    };
  }
  var fh = R(function (a) {
    if (a.value.nb === "omid") {
      if (a.value.wa === "nio") return "omio";
      if (a.value.wa === "geo") return "omgeo";
    }
    return a.value.wa === "geo" || a.value.wa === "nio"
      ? a.value.nb
      : a.value.wa;
  });
  function gh() {
    return O(
      S(function (a, b) {
        return b > 0;
      }),
      hh,
      V(-1),
      T()
    );
  }
  var hh = O(
    S(function (a) {
      return !isNaN(a);
    }),
    U(function (a, b) {
      return isNaN(a) ? b : Math.min(a, b);
    }, NaN),
    T()
  );
  var ih = Sg(
    O(
      R(function (a) {
        return (a.za.width * a.za.height) / (a.ub.width * a.ub.height);
      }),
      R(function (a) {
        return isFinite(a) ? Math.min(1, a) : 0;
      })
    )
  );
  function jh(a, b, c) {
    return a
      ? nd([b, c]).i(
          S(function (d) {
            var e = A(d);
            d = e.next().value;
            e = e.next().value;
            return d.timestamp.equals(e.timestamp);
          }),
          R(function (d) {
            var e = A(d);
            d = e.next().value;
            e = e.next().value;
            return d.value > e.value ? d : e;
          })
        )
      : b;
  }
  function kh(a) {
    return function (b) {
      var c = b.i(Ug),
        d = b.i(ih);
      return a instanceof P
        ? a.i(
            ze(function (e) {
              return jh(e, c, d);
            })
          )
        : jh(a.value, c, d);
    };
  }
  var lh = O(
    Sg(
      R(function (a) {
        a = a.Ob
          ? (a.qa.width * a.qa.height * a.Ob) / (a.Da.width * a.Da.height)
          : (a.za.width * a.za.height) / (a.Da.width * a.Da.height);
        return isFinite(a) ? a : 0;
      })
    )
  );
  function mh(a, b, c) {
    c =
      c === void 0
        ? function (d, e) {
            return d === e;
          }
        : c;
    return a.timestamp.equals(b.timestamp) && c(a.value, b.value);
  }
  function nh(a, b, c, d) {
    var e = d.Yd,
      g = d.Sd,
      f = d.Bi,
      h = d.ff,
      k = d.le,
      l = d.Fg,
      m = d.ce;
    d = d.oi;
    b = oh(a, c, b);
    c = ph(a, c);
    d = qh(b, d);
    var r = rh(a, e, l, b),
      t = r.i(
        R(function (D) {
          return D.value;
        }),
        T(),
        Y(a, 1),
        U(function (D, G) {
          return Math.max(D, G);
        }, 0)
      ),
      q = r.i(
        R(function (D) {
          return D.value;
        }),
        gh(),
        Y(a, 1)
      ),
      w = b.i(
        Vg,
        R(function (D) {
          return D.value;
        }),
        qe(2),
        T(),
        Y(a, 1)
      );
    f = sh(a, b, f, h);
    var z = f.i(
      V(!1),
      T(),
      R(function (D) {
        return D ? k : g;
      })
    );
    h = r.i(eh(z), T(), Y(a, 1));
    var K = nd([h, b]).i(
      S(function (D) {
        var G = A(D);
        D = G.next().value;
        G = G.next().value;
        return D.timestamp.equals(G.timestamp);
      }),
      R(function (D) {
        var G = A(D);
        D = G.next().value;
        G = G.next().value;
        return { visible: D.value, geometry: G.value.qa };
      }),
      U(
        function (D, G) {
          return !G.visible && D.visible ? D : G;
        },
        { visible: !1, geometry: sg }
      ),
      R(function (D) {
        return D.geometry;
      }),
      V(sg),
      Y(a, 1),
      T(tg)
    );
    l = l instanceof P ? l.i(T(), pe()) : Bd;
    z = nd([l, z]).i(pe());
    var x = b.i(
        S(function (D) {
          return D.value.nb !== "ns" && D.value.wa !== "ns";
        }),
        U(function (D) {
          return D + 1;
        }, 0),
        V(0),
        Y(a, 1)
      ),
      y = c.i(pe(!0), V(!1), Y(a, 1));
    y = nd([m, y]).i(
      R(function (D) {
        var G = A(D);
        D = G.next().value;
        G = G.next().value;
        return D && !G;
      }),
      Y(a, 1)
    );
    var B = b.i(lh, T()),
      M = B.i(
        R(function (D) {
          return D.value;
        }),
        U(function (D, G) {
          return Math.max(D, G);
        }, 0),
        T(),
        Y(a, 1)
      );
    a = B.i(
      R(function (D) {
        return D.value;
      }),
      gh(),
      Y(a, 1)
    );
    return {
      Uh: l,
      Vh: z,
      ag: {
        Uj: b,
        Ig: b.i(fh),
        Ma: K.i(T(tg)),
        visible: h.i(T(mh)),
        mb: r.i(T(mh)),
        Eg: t,
        Mg: q,
        Id: b.i(kg, T(Nb)),
        wd: B,
        ne: M,
        qe: a,
        Dj: c,
        ta: b.i(
          R(function (D) {
            return D.value.ta;
          })
        ),
        Gj: f,
        Yd: e,
        ce: m,
        Ej: y,
        dk: x,
        ad: w,
        ck: d,
      },
    };
  }
  function ph(a, b) {
    return b.i(
      S(function () {
        return !1;
      }),
      R(function (c) {
        return c;
      }),
      me(function (c) {
        return new kf(c).Ea(a);
      })
    );
  }
  function oh(a, b, c) {
    return b.i(Ed(Bd), Y(a, 1)).i(
      T(function (d, e) {
        return mh(d, e, Rg);
      }),
      V({ timestamp: c.now(), value: Qg }),
      Y(a, 1)
    );
  }
  function rh(a, b, c, d) {
    c = d.i(
      kh(c),
      Sg(
        R(function (e) {
          return fg(e, 2);
        })
      ),
      Y(a, 1)
    );
    return b instanceof kf
      ? c
      : nd([c, b]).i(
          R(function (e) {
            var g = A(e);
            e = g.next().value;
            g = g.next().value;
            return {
              timestamp: g.timestamp.maximum(e.timestamp),
              value: g.value ? 0 : e.value,
            };
          }),
          T(mh),
          Y(a, 1)
        );
  }
  function sh(a, b, c, d) {
    b = [
      b.i(
        R(function (e) {
          return e.value.qa.width * e.value.qa.height >= 242500;
        })
      ),
    ];
    c instanceof P &&
      b.push(
        c.i(
          R(function (e) {
            return !!e;
          })
        )
      );
    c = nd(b);
    return d
      ? c.i(
          R(function (e) {
            return e.some(function (g) {
              return g;
            });
          }),
          V(!1),
          T(),
          Y(a, 1)
        )
      : new kf(!1).Ea(a);
  }
  function qh(a, b) {
    a = nd([a, b]).i(
      R(function (e) {
        var g = A(e);
        e = g.next().value;
        if (g.next().value && e.value.isIntersecting) return e.value.Hj;
      }),
      T()
    );
    var c = a.i(
        R(function (e) {
          return e === void 0 ? !0 : e;
        }),
        U(function (e, g) {
          return e || !g;
        }, !1)
      ),
      d = a.i(
        U(function (e, g) {
          return g === void 0 ? e : g ? !1 : e != null ? e : !0;
        }, void 0),
        R(function (e) {
          return !!e;
        })
      );
    return nd([b, Hd(a, c, d)]).i(
      R(function (e) {
        var g = A(e);
        e = g.next().value;
        var f = A(g.next().value);
        g = f.next().value;
        var h = f.next().value;
        f = f.next().value;
        var k = 0;
        if (!e) return 0;
        if (g === void 0) return 16;
        g && (k |= 1);
        g || (k |= 2);
        h && (k |= 4);
        f && (k |= 8);
        return k;
      })
    );
  }
  function th(a, b, c, d) {
    if (a === 0) return 0;
    var e = [];
    (d === void 0 ? 0 : d)
      ? c.forEach(function (g, f) {
          e[f] = f === 0 ? g : g + e[f - 1];
        })
      : (e = c);
    b = Mb(b, function (g) {
      return g >= a;
    });
    return b === -1 ? 0 : e[b];
  }
  var vh = function (a, b) {
      var c = this;
      this.o = a;
      this.bd = this.Vb = null;
      this.Ah = b.i(T()).subscribe(function (d) {
        uh(c);
        c.bd = d;
      });
    },
    wh = function (a, b) {
      uh(a);
      a.Vb = a.o.setTimeout(function () {
        var c;
        return void ((c = a.bd) == null ? void 0 : c.next());
      }, b);
    },
    uh = function (a) {
      a.Vb !== null && a.o.clearTimeout(a.Vb);
      a.Vb = null;
    };
  vh.prototype.dispose = function () {
    uh(this);
    this.Ah.unsubscribe();
    this.bd = null;
  };
  function xh(a, b, c, d, e, g, f, h, k, l, m, r, t) {
    var q = q === void 0 ? new vh(b, t) : q;
    var w = yh(d, e),
      z = zh(c, d, g, f, h, k, l, m, r);
    return new P(function (K) {
      var x = nd([w, z])
        .i(
          T(Nb),
          R(function (y) {
            var B = A(y);
            y = B.next().value;
            B = B.next().value;
            if (y === void 0 || B === void 0) return !1;
            var M = B >= y;
            M ? uh(q) : wh(q, Math.max(0, y - B));
            return M;
          }),
          U(function (y, B) {
            return B || y;
          }, !1),
          T()
        )
        .subscribe(K);
      return function () {
        q.dispose();
        x.unsubscribe();
      };
    }).i(
      Ae(function (K) {
        return !K;
      }),
      Y(a, 1)
    );
  }
  function yh(a, b) {
    return b.i(
      R(function (c) {
        if (a.td) return a.td;
        if (a.Jc) return a.Jc * c;
      })
    );
  }
  function zh(a, b, c, d, e, g, f, h, k) {
    return nd([c, d, e, g, f, h, k]).i(
      R(function (l) {
        var m = A(l);
        l = m.next().value;
        var r = m.next().value;
        var t = m.next().value;
        var q = m.next().value;
        var w = m.next().value;
        var z = m.next().value;
        m = m.next().value;
        return b.ka !== void 0
          ? b.ud === "mtos"
            ? b.audible
              ? th(b.ka, a, l, !0)
              : th(b.ka, a, w)
            : b.audible
            ? th(b.ka, a, r)
            : th(b.ka, a, z, !0)
          : b.ud === "mtos"
          ? b.audible
            ? t
            : m
          : b.audible
          ? q
          : m;
      })
    );
  }
  function Ah(a, b, c, d, e) {
    var g = g === void 0 ? new vh(b, e) : g;
    return new P(function (f) {
      var h = nd([c, d])
        .i(
          T(Nb),
          R(function (k) {
            var l = A(k);
            k = l.next().value;
            l = l.next().value;
            var m = k >= l;
            m ? uh(g) : wh(g, Math.max(0, l - k));
            return m;
          }),
          U(function (k, l) {
            return l || k;
          }, !1),
          T()
        )
        .subscribe(f);
      return function () {
        g.dispose();
        h.unsubscribe();
      };
    }).i(
      Ae(function (f) {
        return !f;
      }),
      Y(a, 1)
    );
  }
  function Bh(a, b, c, d) {
    var e = Ch.fi;
    var g = g === void 0 ? new vh(b, c) : g;
    return new P(function (f) {
      var h = Bd.i(
        V(void 0),
        ze(function () {
          return Dh(d);
        })
      )
        .i(
          R(function (k) {
            var l = k.value;
            k = k.timestamp;
            var m = l.visible;
            l = l.Mb;
            var r = l >= e;
            r || !m
              ? uh(g)
              : ((k = Math.max(0, Xd(b.now(), k))),
                wh(g, Math.max(0, e - l - k)));
            return r;
          }),
          U(function (k, l) {
            return l || k;
          }, !1),
          T()
        )
        .subscribe(f);
      return function () {
        g.dispose();
        h.unsubscribe();
      };
    }).i(
      Ae(function (f) {
        return !f;
      }),
      Y(a, 1)
    );
  }
  function Dh(a) {
    return gg([a, a.i(mg())]).i(
      R(function (b) {
        var c = A(b);
        b = c.next().value;
        c = c.next().value;
        return {
          timestamp: b.timestamp,
          value: { visible: b.value, Mb: c.value },
        };
      }),
      T(function (b, c) {
        return mh(b, c, function (d, e) {
          return d.Mb === e.Mb && d.visible === e.visible;
        });
      })
    );
  }
  function Eh() {
    return O(
      jg(),
      U(function (a, b) {
        return Math.max(a, b);
      }, 0),
      R(function (a) {
        return Math.round(a);
      })
    );
  }
  function Fh(a) {
    return O(eh(Uc(a)), Eh());
  }
  function Gh(a, b) {
    a = b.i(
      R(function (c) {
        return Xd(c.timestamp, new Vd(0, c.timestamp.timeline));
      }),
      V(0),
      T(),
      Y(a, 2)
    );
    b = a.i(
      ve(),
      R(function (c) {
        return c[1] - c[0];
      }),
      U(function (c, d) {
        return c + (d < 0 ? -d : 0);
      }, 0),
      V(0),
      T()
    );
    return { mediaTime: a, Rg: b };
  }
  var Hh = function () {
    this.Ud = {};
  };
  function Ih(a) {
    var b = new Hh();
    return O(
      R(function (c) {
        if (c === null) return null;
        try {
          var d = JSON.parse(c)[0];
          c = "";
          for (var e = 0; e < d.length; e++)
            c += String.fromCharCode(
              d.charCodeAt(e) ^
                "\u0003\u0007\u0003\u0007\b\u0004\u0004\u0006\u0005\u0003".charCodeAt(
                  e % 10
                )
            );
          b.Ud = JSON.parse(c);
        } catch (g) {}
        return b;
      }),
      Y(a.queue, 1)
    );
  }
  function Jh(a) {
    Va.setTimeout(function () {
      throw a;
    }, 0);
  }
  var Kh, Lh;
  a: {
    for (var Mh = ["CLOSURE_FLAGS"], Nh = Va, Oh = 0; Oh < Mh.length; Oh++)
      if (((Nh = Nh[Mh[Oh]]), Nh == null)) {
        Lh = null;
        break a;
      }
    Lh = Nh;
  }
  var Ph = Lh && Lh[748402147];
  Kh = Ph != null ? Ph : !0;
  function Qh() {
    var a = Va.navigator;
    return a && (a = a.userAgent) ? a : "";
  }
  var Rh = Qh().indexOf("Trident") != -1 || Qh().indexOf("MSIE") != -1;
  var Sh = {},
    Th = null;
  function Uh(a) {
    var b = "";
    Vh(a, function (c) {
      b += String.fromCharCode(c);
    });
    return b;
  }
  function Wh(a) {
    var b = a.length,
      c = (b * 3) / 4;
    c % 3
      ? (c = Math.floor(c))
      : "=.".indexOf(a[b - 1]) != -1 &&
        (c = "=.".indexOf(a[b - 2]) != -1 ? c - 2 : c - 1);
    var d = new Uint8Array(c),
      e = 0;
    Vh(a, function (g) {
      d[e++] = g;
    });
    return e !== c ? d.subarray(0, e) : d;
  }
  function Vh(a, b) {
    function c(k) {
      for (; d < a.length; ) {
        var l = a.charAt(d++),
          m = Th[l];
        if (m != null) return m;
        if (!/^[\s\xa0]*$/.test(l)) throw Error("G`" + l);
      }
      return k;
    }
    Xh();
    for (var d = 0; ; ) {
      var e = c(-1),
        g = c(0),
        f = c(64),
        h = c(64);
      if (h === 64 && e === -1) break;
      b((e << 2) | (g >> 4));
      f != 64 &&
        (b(((g << 4) & 240) | (f >> 2)), h != 64 && b(((f << 6) & 192) | h));
    }
  }
  function Xh() {
    if (!Th) {
      Th = {};
      for (
        var a =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
              ""
            ),
          b = ["+/=", "+/", "-_=", "-_.", "-_"],
          c = 0;
        c < 5;
        c++
      ) {
        var d = a.concat(b[c].split(""));
        Sh[c] = d;
        for (var e = 0; e < d.length; e++) {
          var g = d[e],
            f = Th[g];
          f === void 0 ? (Th[g] = e) : H(f === e);
        }
      }
    }
  }
  function Yh(a) {
    return O(
      R(function (b) {
        if (b.activeview_flags === void 0) return null;
        try {
          return Uh(b.activeview_flags);
        } catch (c) {
          return b.activeview_flags;
        }
      }),
      Ih(a)
    );
  }
  var Zh = {
    cj: "start",
    Ii: "firstquartile",
    Ui: "midpoint",
    ej: "thirdquartile",
    Fi: "complete",
    Ki: "fullscreen",
    Xi: "mute",
    ij: "unmute",
    Zi: "pause",
    aj: "resume",
    jj: "verification_debug",
    Ti: "measurable_impression",
    kj: "viewable_impression",
    Li: "fully_viewable_audible_half_duration_impression",
    bj: "skip",
  };
  function $h(a) {
    if (typeof a !== "object") return !1;
    var b = a.tracking_events;
    if (b !== void 0 && !ai(b)) return !1;
    a = a.custom_metric_configurations;
    return !(
      a !== void 0 &&
      (!Array.isArray(a) ||
        a.some(function (c) {
          return !bi(c);
        }))
    );
  }
  function ai(a) {
    return typeof a !== "object"
      ? !1
      : Object.keys(a).every(function (b) {
          return (
            Array.isArray(a[b]) &&
            a[b].every(function (c) {
              return typeof c === "string";
            })
          );
        });
  }
  function bi(a) {
    return !(
      typeof a !== "object" ||
      (a.id !== void 0 && typeof a.id !== "number") ||
      (a.name !== void 0 && typeof a.name !== "string") ||
      (a.criteria !== void 0 &&
        (!Array.isArray(a.criteria) ||
          a.criteria.some(function (b) {
            return typeof b !== "string";
          })))
    );
  }
  function ci() {
    return O(
      R(function (a) {
        if (a === void 0) throw new Td("undefined");
        var b = JSON.parse(a);
        if (typeof b !== "object") var c = !1;
        else {
          c = b.activeview_metadata;
          var d = b.activeview_flags,
            e = b.ufs_integrator_metadata,
            g = b.tracking_configuration;
          c = !(
            (c !== void 0 && typeof c !== "string") ||
            (e !== void 0 && typeof e !== "string") ||
            (d !== void 0 && typeof d !== "string") ||
            (g !== void 0 && !$h(g))
          );
        }
        if (c) return b;
        throw new Td(a);
      }),
      me(function (a) {
        if (a instanceof Td) throw a;
        throw new Td("json parse failure");
      }),
      S(function (a) {
        return a !== null;
      }),
      R(function (a) {
        return di(a);
      })
    );
  }
  function ei(a) {
    return O(
      R(function (b) {
        return fi(b, a);
      })
    );
  }
  function fi(a, b) {
    var c;
    a = (c = a.tracking_configuration) == null ? void 0 : c.tracking_events;
    if (b === void 0 || a === void 0) return [];
    var d;
    return (d = a[b]) != null ? d : [];
  }
  function di(a) {
    a.activeview_metadata === "%%ACTIVEVIEW_METADATA%%" &&
      (a.activeview_metadata = "");
    a.activeview_flags === "%%ACTIVEVIEW_FLAGS%%" && (a.activeview_flags = "");
    var b,
      c = (b = a.tracking_configuration) == null ? void 0 : b.tracking_events;
    if (c !== void 0) {
      b = Object.keys(c).filter(function (f) {
        return !Object.values(Zh).includes(f);
      });
      b = A(b);
      var d = b.next();
      try {
        for (; !d.done; d = b.next()) {
          var e = d.value;
          e.startsWith("custom_metric_viewable_") || delete c[e];
        }
      } finally {
        xa(b, d);
      }
    }
    var g;
    c =
      (g = a.tracking_configuration) == null
        ? void 0
        : g.custom_metric_configurations;
    c !== void 0 &&
      (a.tracking_configuration.custom_metric_configurations = gi(c));
    return a;
  }
  function gi(a) {
    a = a
      .filter(function (c) {
        return c.id && c.name && c.criteria;
      })
      .map(function (c) {
        return { id: c.id, name: c.name, criteria: c.criteria.sort() };
      })
      .filter(function (c, d, e) {
        return (
          d ===
          e.findIndex(function (g) {
            return cg(g, c);
          })
        );
      });
    var b = a
      .filter(function (c, d, e) {
        return (
          d !==
          e.findIndex(function (g) {
            return g.name === c.name;
          })
        );
      })
      .map(function (c) {
        return c.name;
      });
    return a.filter(function (c) {
      return !b.includes(c.name);
    });
  }
  function hi(a, b, c, d) {
    return nd([b, c, d]).i(
      S(function (e) {
        var g = A(e);
        g.next();
        e = g.next().value;
        g = g.next().value;
        return e !== void 0 && e.length === g.length;
      }),
      R(function (e) {
        var g = A(e);
        var f = g.next().value;
        e = g.next().value;
        var h = g.next().value;
        var k = {};
        e.forEach(function (l, m) {
          k[l.name] = h[m] ? fi(f, l.name) : [];
        });
        return k;
      }),
      Y(a, 1)
    );
  }
  function ii(a, b, c, d) {
    var e = new xc(),
      g = void 0,
      f = e.i(
        R(function () {
          return g ? Object.assign({}, g, { timestamp: a.o.now() }) : null;
        }),
        S(function (t) {
          return t !== null;
        }),
        R(function (t) {
          return t;
        })
      );
    b = Ad(b, f).i(
      S(function (t) {
        return t.value.type === "volumeChange" || t.value.type === "start";
      }),
      Be(function (t) {
        return void (g = t);
      }),
      Sg(
        O(
          Ce(c.i(V(!0))),
          R(function (t) {
            var q = A(t);
            t = q.next().value.data;
            q = q.next().value;
            a: {
              if (t.deviceVolume !== null && t.deviceVolume !== void 0)
                q = t.deviceVolume;
              else {
                if (q) {
                  t = null;
                  break a;
                }
                q = 1;
              }
              if (
                t.mediaPlayerVolume !== null &&
                t.mediaPlayerVolume !== void 0
              )
                t = t.mediaPlayerVolume;
              else if (
                t.videoPlayerVolume !== null &&
                t.videoPlayerVolume !== void 0
              )
                t = t.videoPlayerVolume;
              else {
                t = null;
                break a;
              }
              t = fg(q * t, 3);
            }
            return t;
          }),
          S(function (t) {
            return t !== null;
          }),
          R(function (t) {
            return Math.min(1, Math.max(0, t));
          }),
          R(function (t) {
            return { volume: t, ta: e };
          })
        )
      ),
      d,
      Y(a.queue, 1)
    );
    c = b.i(
      Sg(
        O(
          R(function (t) {
            return t.volume > 0;
          })
        )
      ),
      Y(a.queue, 2)
    );
    d = b.i(
      R(function (t) {
        return t.value.volume;
      }),
      U(function (t, q) {
        return Math.max(t, q);
      }, 0),
      T(),
      Y(a.queue, 1)
    );
    f = b.i(
      R(function (t) {
        return t.value.volume;
      }),
      hh,
      Y(a.queue, 1)
    );
    var h = c.i(
        R(function (t) {
          return t.value;
        }),
        ve(),
        R(function (t) {
          return t[0] && !t[1];
        }),
        T(),
        S(function (t) {
          return t;
        }),
        Y(a.queue, 1)
      ),
      k = c.i(
        R(function (t) {
          return t.value;
        }),
        ve(),
        R(function (t) {
          return !t[0] && t[1];
        }),
        T(),
        S(function (t) {
          return t;
        }),
        Y(a.queue, 1)
      ),
      l = h.i(
        U(function (t) {
          return t + 1;
        }, 0),
        V(0),
        Y(a.queue, 1)
      ),
      m = k.i(
        U(function (t) {
          return t + 1;
        }, 0),
        V(0),
        Y(a.queue, 1)
      ),
      r = c.i(
        U(function (t, q) {
          return t && q.value;
        }, !0),
        V(!1),
        T(),
        Y(a.queue, 1)
      );
    return {
      mf: {
        fc: b,
        Dg: d,
        Lg: f,
        ec: c,
        Og: h,
        li: k,
        re: l,
        Se: m,
        gf: r,
        ta: e,
      },
    };
  }
  var ji = {},
    ki =
      ((ji.sessionStart = 1),
      (ji.sessionError = 2),
      (ji.sessionFinish = 4),
      (ji.impression = 8),
      (ji.loaded = 16),
      (ji.start = 32),
      (ji.firstQuartile = 64),
      (ji.midpoint = 128),
      (ji.thirdQuartile = 256),
      (ji.complete = 512),
      (ji.pause = 1024),
      (ji.resume = 2048),
      (ji.bufferStart = 4096),
      (ji.bufferFinish = 8192),
      (ji.skipped = 16384),
      (ji.volumeChange = 32768),
      (ji.playerStateChange = 65536),
      (ji.adUserInteraction = 131072),
      (ji.geometryChange = 262144),
      ji);
  function li(a, b, c, d, e, g) {
    return Ad(
      a.i(
        R(function (f) {
          return f.timestamp;
        })
      ),
      b.i(
        R(function (f) {
          return f.timestamp;
        })
      ),
      c.i(
        R(function (f) {
          return f.timestamp;
        })
      ),
      e.i(
        R(function (f) {
          return f.timestamp;
        })
      ),
      g.i(
        R(function (f) {
          return f.timestamp;
        })
      ),
      d.i(
        R(function (f) {
          return f.timestamp;
        })
      )
    ).i(eg());
  }
  function mi(a, b, c, d, e, g) {
    return Ad(
      a.i(pe(ki.sessionStart)),
      b.i(pe(ki.sessionFinish)),
      c.i(pe(ki.impression)),
      e.i(pe(ki.geometryChange)),
      g.i(pe(524288)),
      d.i(
        R(function (f) {
          return ki[f.value.type];
        })
      )
    ).i(eg());
  }
  function ni(a, b, c, d, e, g, f) {
    var h = mi(b, c, d, e, g, f),
      k = h.i(
        U(function (l, m) {
          return l | m;
        }, 0)
      );
    b = li(b, c, d, e, g, f);
    return gg([h, k, b]).i(
      R(function (l) {
        var m = A(l);
        l = m.next().value;
        var r = m.next().value;
        m = m.next().value;
        return {
          oe: l,
          oeb: r,
          oet: fg(+m.toString(), -2),
          oept: fg(Date.now(), -2),
        };
      }),
      Y(a.queue, 1)
    );
  }
  function oi(a, b, c, d) {
    var e = b.i(
        R(function (q) {
          var w, z;
          return (w = q.value.data.context) == null
            ? void 0
            : (z = w.app) == null
            ? void 0
            : z.libraryVersion;
        }),
        eg(),
        Y(a.queue, 1)
      ),
      g = b.i(
        R(function (q) {
          var w, z;
          return (w = q.value.data.context) == null
            ? void 0
            : (z = w.app) == null
            ? void 0
            : z.appId;
        }),
        eg(),
        Y(a.queue, 1)
      ),
      f = b.i(
        R(function (q) {
          var w;
          return (w = q.value.data.context) == null ? void 0 : w.adSessionType;
        }),
        R(function (q) {
          return q === "html"
            ? "h"
            : q === "native"
            ? "n"
            : q === "javascript"
            ? "j"
            : "x";
        }),
        S(function (q) {
          return q !== "x";
        }),
        Y(a.queue, 1)
      ),
      h = b.i(
        R(function (q) {
          var w;
          return (w = q.value.data.context) == null ? void 0 : w.accessMode;
        }),
        R(function (q) {
          return q === "full"
            ? "f"
            : q === "domain"
            ? "d"
            : q === "limited"
            ? "l"
            : "x";
        }),
        S(function (q) {
          return q !== "x";
        }),
        Y(a.queue, 1)
      ),
      k = b.i(
        R(function (q) {
          var w;
          return (w = q.value.data.context) == null ? void 0 : w.environment;
        }),
        eg(),
        R(function (q) {
          return q === "app";
        }),
        Y(a.queue, 1)
      ),
      l = b.i(
        R(function (q) {
          var w, z, K, x, y;
          return (y =
            (w = q.value.data.context) == null
              ? void 0
              : (z = w.omidNativeInfo) == null
              ? void 0
              : z.partnerName) != null
            ? y
            : (K = q.value.data.context) == null
            ? void 0
            : (x = K.omidJsInfo) == null
            ? void 0
            : x.partnerName;
        }),
        eg(),
        Y(a.queue, 1)
      ),
      m = b.i(
        R(function (q) {
          var w, z, K, x, y;
          return (y =
            (w = q.value.data.context) == null
              ? void 0
              : (z = w.omidNativeInfo) == null
              ? void 0
              : z.partnerVersion) != null
            ? y
            : (K = q.value.data.context) == null
            ? void 0
            : (x = K.omidJsInfo) == null
            ? void 0
            : x.partnerVersion;
        }),
        eg(),
        Y(a.queue, 1)
      );
    d = d.i(
      S(function (q) {
        return q.value.type === "impression" || q.value.type === "loaded";
      }),
      R(function (q) {
        return q.value.data;
      }),
      Ce(f.i(V("x"))),
      R(function (q) {
        var w = A(q);
        q = w.next().value;
        w = w.next().value;
        if (q.Bf !== void 0) return q.Bf;
        if (q.mediaType !== void 0)
          return q.mediaType === "video"
            ? "video"
            : w === "n"
            ? "nativeDisplay"
            : "htmlDisplay";
      }),
      S(function (q) {
        return q !== void 0;
      }),
      qe(1),
      Y(a.queue, 1)
    );
    var r = b.i(
        R(function (q) {
          var w;
          return (w = q.value.data.context) == null ? void 0 : w.deviceCategory;
        }),
        eg(),
        Y(a.queue, 1)
      ),
      t = b.i(
        R(function (q) {
          var w;
          return (w = q.value.data.lastActivity) == null ? void 0 : w.timestamp;
        }),
        eg(),
        Y(a.queue, 1)
      );
    b = b.i(
      R(function (q) {
        var w;
        if (
          (w = q.value.data.lastActivity) != null &&
          w.timestamp &&
          q.timestamp
        ) {
          var z;
          w = new Vd(
            (z = q.value.data.lastActivity) == null ? void 0 : z.timestamp,
            q.timestamp.timeline
          );
          return Math.round(Xd(q.timestamp, w) / 1e3);
        }
      }),
      eg(),
      Y(a.queue, 1)
    );
    a = c.i(
      R(function (q) {
        var w = 0;
        q = A(q.value.data.adView.reasons);
        var z = q.next();
        try {
          for (; !z.done; z = q.next())
            switch (z.value) {
              case "notFound":
                w |= 1;
                break;
              case "hidden":
                w |= 2;
                break;
              case "backgrounded":
                w |= 4;
                break;
              case "viewport":
                w |= 8;
                break;
              case "obstructed":
                w |= 16;
                break;
              case "clipped":
                w |= 32;
                break;
              case "unmeasurable":
                w |= 64;
                break;
              case "noWindowFocus":
                w |= 128;
                break;
              case "noOutputDevice":
                w |= 256;
            }
        } finally {
          xa(q, z);
        }
        return w;
      }),
      eg(),
      Y(a.queue, 1)
    );
    return {
      gh: e,
      Wg: g,
      fh: f,
      Vg: h,
      se: k,
      dh: l,
      eh: m,
      Xg: d,
      Yg: r,
      ah: t,
      Zg: b,
      bh: a,
    };
  }
  var pi = { Hi: "visible", Ei: "audible", fj: "time", gj: "timetype" };
  function qi(a) {
    try {
      var b = a.toLowerCase().split(",");
      if (
        b.some(function (m) {
          return (
            m &&
            Object.values(pi).every(function (r) {
              return !m.includes(r);
            })
          );
        })
      )
        return null;
      a = { ud: "tos" };
      var c = b.filter(function (m) {
        return m.includes("visible=");
      });
      if (c.length > 1) return null;
      if (c.length === 1) {
        var d = Number(c[0].toLowerCase().split("=")[1]);
        if (
          isNaN(d) ||
          !isFinite(d) ||
          d < 0 ||
          d > 100 ||
          !Number.isInteger(d)
        )
          return null;
        a.ka = d / 100;
      }
      var e = b.filter(function (m) {
        return m.includes("audible=");
      });
      if (e.length > 1) return null;
      if (e.length === 1) {
        var g = e[0].toLowerCase().split("=");
        if (["0", "1"].includes(g[1])) a.audible = g[1] === "1";
        else return null;
      }
      var f = b.filter(function (m) {
        return m.includes("timetype=");
      });
      if (f.length > 1) return null;
      if (f.length === 1) {
        var h = f[0].toLowerCase().split("=");
        if (["mtos", "tos"].includes(h[1])) a.ud = h[1];
        else return null;
      }
      var k = b.filter(function (m) {
        return m.includes("time=");
      });
      if (k.length > 1) return null;
      if (k.length === 1) {
        var l = k[0].toLowerCase().split("=");
        if (/^(100|[0-9]{1,2})%$/.test(l[1]) || /^([0-9])+ms$/.test(l[1]))
          l[1].includes("ms")
            ? (a.td = Math.floor(Number(l[1].split("ms")[0])))
            : (a.Jc = Math.floor(Number(l[1].split("%")[0])) / 100);
        else return null;
      }
      return a.td || a.Jc ? a : null;
    } catch (m) {
      return null;
    }
  }
  function ri(a) {
    return {
      id: a.id,
      name: a.name,
      criteria: a.criteria.map(function (b) {
        return qi(b);
      }),
    };
  }
  function si(a, b, c, d) {
    var e = b.i(
        R(function (f) {
          return Math.floor(f / 1e3);
        }),
        S(function (f) {
          return f <= 32;
        }),
        R(function (f) {
          return 1 << f;
        }),
        U(function (f, h) {
          return f | h;
        }, 0),
        T(),
        Y(a, 1)
      ),
      g = b.i(
        R(function (f) {
          return Math.floor(f / 1e3);
        }),
        S(function (f) {
          return f <= 32;
        }),
        Ce(c),
        R(function (f) {
          var h = A(f);
          f = h.next().value;
          h = h.next().value;
          return [1 << f, dh(h.value, 0.5)];
        }),
        U(function (f, h) {
          var k = A(h);
          h = k.next().value;
          return k.next().value ? f | h : f & ~h;
        }, 0),
        T(),
        Y(a, 1)
      );
    c = b.i(
      R(function (f) {
        return Math.floor(f / 1e3);
      }),
      S(function (f) {
        return f <= 32;
      }),
      Ce(c),
      R(function (f) {
        var h = A(f);
        f = h.next().value;
        h = h.next().value;
        return [1 << f, dh(h.value, 1)];
      }),
      U(function (f, h) {
        var k = A(h);
        h = k.next().value;
        return k.next().value ? f | h : f & ~h;
      }, 0),
      T(),
      Y(a, 1)
    );
    a = nf(a, [b, d]).i(
      S(function (f) {
        var h = A(f);
        f = h.next().value;
        h = h.next().value;
        return f !== void 0 && h !== void 0;
      }),
      T(function (f, h) {
        f = A(f).next().value;
        h = A(h).next().value;
        return f === h;
      }),
      R(function (f) {
        var h = A(f);
        f = h.next().value;
        h = h.next().value;
        return [Math.floor(f / 1e3), h.value];
      }),
      S(function (f) {
        var h = A(f);
        f = h.next().value;
        h.next();
        return f <= 32;
      }),
      R(function (f) {
        var h = A(f);
        f = h.next().value;
        h = h.next().value;
        return [1 << f, h];
      }),
      U(function (f, h) {
        var k = A(h);
        h = k.next().value;
        return k.next().value ? f | h : f & ~h;
      }, 0),
      T(),
      Y(a, 1)
    );
    return { nh: e, oh: g, mh: c, kh: a };
  }
  function ti(a, b) {
    var c = b.i(
        S(function (f) {
          return f.value.type === "pause";
        }),
        R(function (f) {
          return { timestamp: f.timestamp, value: "pause" };
        })
      ),
      d = b.i(
        S(function (f) {
          return f.value.type === "resume";
        }),
        R(function (f) {
          return { timestamp: f.timestamp, value: "resume" };
        })
      ),
      e = b.i(
        S(function (f) {
          return f.value.type === "start";
        }),
        R(function (f) {
          return { timestamp: f.timestamp, value: "start" };
        })
      ),
      g = b.i(
        S(function (f) {
          return f.value.type === "bufferStart";
        }),
        R(function (f) {
          return { timestamp: f.timestamp, value: "bufferStart" };
        })
      );
    b = b.i(
      S(function (f) {
        return f.value.type === "bufferFinish";
      }),
      R(function (f) {
        return { timestamp: f.timestamp, value: "bufferFinish" };
      })
    );
    c = Ad(c, g, e, d, b).i(
      U(
        function (f, h) {
          return {
            timestamp: h.timestamp,
            value:
              f.value === 0
                ? h.value === "start"
                  ? 2
                  : 0
                : h.value === "pause" || h.value === "bufferStart"
                ? 1
                : 2,
          };
        },
        { timestamp: a.o.now(), value: 0 }
      ),
      V({ timestamp: a.o.now(), value: 0 }),
      Y(a.queue, 2)
    );
    d = c.i(
      R(function (f) {
        return f.value;
      }),
      ve(),
      R(function (f) {
        return f[0] !== 1 && f[1] === 1;
      }),
      T(),
      S(function (f) {
        return f;
      }),
      Y(a.queue, 1)
    );
    e = d.i(
      U(function (f) {
        return f + 1;
      }, 0),
      V(0),
      Y(a.queue, 1)
    );
    g = c.i(
      R(function (f) {
        return f.value;
      }),
      ve(),
      R(function (f) {
        return f[0] === 1 && f[1] === 2;
      }),
      T(),
      S(function (f) {
        return f;
      }),
      Y(a.queue, 1)
    );
    a = g.i(
      U(function (f) {
        return f + 1;
      }, 0),
      V(0),
      Y(a.queue, 1)
    );
    return { qh: { we: d, Xb: e, De: g, bc: a, Qe: c } };
  }
  function ui(a, b, c) {
    b = b.i(
      S(function (e) {
        return e.value.type === "playerStateChange";
      }),
      R(function (e) {
        return { timestamp: e.timestamp, value: e.value.data.state };
      }),
      V({ timestamp: a.o.now(), value: "normal" }),
      c,
      Y(a.queue, 2)
    );
    c = b.i(
      Sg(
        O(
          ve(),
          R(function (e) {
            return e[0] !== "fullscreen" && e[1] === "fullscreen";
          }),
          T(),
          S(function (e) {
            return e;
          })
        )
      ),
      Y(a.queue, 1)
    );
    var d = c.i(
      R(function (e) {
        return e.value;
      }),
      Y(a.queue, 1)
    );
    a = d.i(
      U(function (e) {
        return e + 1;
      }, 0),
      V(0),
      Y(a.queue, 1)
    );
    return { rh: { hi: b, Lc: d, Mc: a, gi: c } };
  }
  function vi(a, b, c, d, e) {
    var g = wi,
      f = b.i(
        V(void 0),
        ze(function () {
          return e.i(lg(Fh, g), V([0, 0, 0, 0, 0]), T(Nb));
        }),
        Y(a, 1)
      ),
      h = b.i(
        V(void 0),
        ze(function () {
          return e.i(
            R(function (m) {
              return m.value;
            }),
            U(function (m, r) {
              return Math.max(m, r);
            }, 0),
            V(0),
            T()
          );
        }),
        Y(a, 1)
      ),
      k = b.i(
        V(void 0),
        ze(function () {
          return c.i(
            R(function (m) {
              return m.value;
            }),
            hh,
            V(-1),
            T()
          );
        }),
        Y(a, 1)
      ),
      l = b.i(
        V(void 0),
        ze(function () {
          return c.i(
            R(function (m) {
              return m.value;
            }),
            U(function (m, r) {
              return Math.max(m, r);
            }, 0),
            V(0),
            T()
          );
        }),
        Y(a, 1)
      );
    a = b.i(
      V(void 0),
      ze(function () {
        return d.i(
          U(function (m, r) {
            return m && r.value;
          }, !0),
          V(!1),
          T()
        );
      }),
      Y(a, 1)
    );
    return { ye: f, Sj: h, Ae: k, ze: l, xe: a };
  }
  function xi(a, b, c) {
    return Object.assign.apply(
      Object,
      [{}].concat(
        sa(
          Object.keys(c).map(function (d) {
            var e = c[d];
            if (e instanceof kf) {
              var g = {};
              return (g[d] = yi(a, e.Ea(a), b).i(Y(a, 1))), g;
            }
            g = {};
            return (g[d] = yi(a, e, b).i(Y(a, 1))), g;
          })
        )
      )
    );
  }
  function yi(a, b, c) {
    return nf(a, [c, b]).i(
      S(function (d) {
        var e = A(d);
        d = e.next().value;
        e.next();
        return d !== void 0;
      }),
      T(function (d, e) {
        d = A(d).next().value;
        return A(e).next().value === d;
      }),
      R(function (d) {
        var e = A(d);
        d = e.next().value;
        e = e.next().value;
        var g = {};
        return (g[d] = e), g;
      }),
      U(function (d, e) {
        return C({}, d, e);
      }, {}),
      Y(a, 1)
    );
  }
  var zi;
  zi = ["2026111801"].slice(-1)[0].substring(0, 8);
  function Ai(a, b, c) {
    var d;
    return b.i(
      T(),
      ze(function (e) {
        return c.i(
          R(function () {
            if (!d) {
              d = !0;
              try {
                e.next();
              } finally {
                d = !1;
              }
            }
            return !0;
          })
        );
      }),
      V(!1),
      Y(a.queue, 1)
    );
  }
  function Bi(a) {
    return O(
      Sg(
        R(function (b) {
          return dh(b, a);
        })
      ),
      ig(),
      R(function (b) {
        return Math.round(b);
      })
    );
  }
  function Ci(a, b, c, d, e, g) {
    if (g.length > 1)
      for (var f = 0; f < g.length - 1; f++) if (g[f] < g[f + 1]) throw Error();
    f = e.i(
      V(void 0),
      ze(function () {
        return c.i(mg());
      }),
      T(),
      Y(a, 1)
    );
    e = e.i(
      V(void 0),
      ze(function () {
        return c.i(Eh());
      }),
      T(),
      Y(a, 1)
    );
    return {
      ii: d.i(
        V(void 0),
        ze(function () {
          return b.i(
            R(function (h) {
              return { timestamp: h.timestamp, value: !0 };
            }),
            ig()
          );
        }),
        T(),
        Y(a, 1)
      ),
      ji: d.i(
        V(void 0),
        ze(function () {
          return b.i(
            R(function (h) {
              return { timestamp: h.timestamp, value: h.value === 0 };
            }),
            ig()
          );
        }),
        T(),
        Y(a, 1)
      ),
      Ha: d.i(
        V(void 0),
        ze(function () {
          return b.i(lg(Fh, g));
        }),
        T(Nb),
        Y(a, 1)
      ),
      dc: d.i(
        V(void 0),
        ze(function () {
          return b.i(
            lg(Bi, g),
            R(function (h) {
              return h.map(function (k, l) {
                return l > 0 ? k - h[l - 1] : k;
              });
            })
          );
        }),
        T(Nb),
        Y(a, 1)
      ),
      yg: e,
      Mb: f.i(T(mh), Y(a, 1)),
    };
  }
  function Di(a, b, c, d, e, g, f, h, k, l, m, r, t, q, w, z, K) {
    c = nf(a, [z, b, c, d, e, g, f, h, k, l, m, r, t, q, w]).i(
      S(function (x) {
        return !!A(x).next().value;
      }),
      R(function (x) {
        var y = A(x);
        y.next();
        x = y.next().value;
        var B = y.next().value;
        var M = y.next().value;
        var D = y.next().value;
        var G = y.next().value;
        var va = y.next().value;
        var Ha = y.next().value;
        var I = y.next().value;
        var W = y.next().value;
        var la = y.next().value;
        var Ua = y.next().value;
        var ea = y.next().value;
        var We = y.next().value;
        y = y.next().value;
        var ba = 0,
          ca = 0;
        x && ((ba |= 1), (ca |= 0));
        B && ((ba |= 0), (ca |= 1));
        D !== void 0 &&
          ((ba |= 2),
          (ca |= 2),
          D ? ((ba |= 4), (ca |= 4)) : ((ba |= 33554432), (ca |= 33554432)));
        G && ((ba |= 8), (ca |= 8));
        va !== void 0 && ((ba |= 16), (ca |= 16));
        va && ((ba |= 32), (ca |= 32));
        D && va && ((ba |= 67108864), (ca |= 67108864));
        D && B && ((ba |= 0), (ca |= 64));
        D && x && ((ba |= 64), (ca |= 0));
        M && ((ba |= 256), (ca |= 256));
        Ha && ((ba |= 0), (ca |= 512));
        I === 1 && ((ba |= 0), (ca |= 1024));
        I === 2 && ((ba |= 0), (ca |= 2048));
        W && ((ba |= 0), (ca |= 4096));
        la && ((ba |= 0), (ca |= 8192));
        Ua && ((ba |= 0), (ca |= 32768));
        ea && ((ba |= 0), (ca |= 16384));
        We && ((ba |= 0), (ca |= 16777216));
        y && ((ba |= 134217728), (ca |= 134217728));
        return [ba, ca];
      })
    );
    b = c.i(
      R(function (x) {
        return A(x).next().value;
      }),
      V(0),
      Y(a, 1)
    );
    c = c.i(
      R(function (x) {
        x = A(x);
        x.next();
        return x.next().value;
      }),
      U(function (x, y) {
        return x | y;
      }, 0),
      V(0),
      Y(a, 1)
    );
    d = K.i(
      U(function (x) {
        return x + 1;
      }, 0)
    );
    a = nf(a, [d, K, c]).i(
      S(function (x) {
        var y = A(x);
        x = y.next().value;
        var B = y.next().value;
        y = y.next().value;
        return B !== void 0 && y !== void 0 && x !== void 0;
      }),
      T(function (x, y) {
        x = A(x).next().value;
        return A(y).next().value === x;
      }),
      R(function (x) {
        var y = A(x);
        y.next();
        x = y.next().value;
        y = y.next().value;
        return [x, y];
      }),
      V(["unknown", 0]),
      ve(),
      R(function (x) {
        var y = A(x);
        x = A(y.next().value);
        x.next();
        x = x.next().value;
        var B = A(y.next().value);
        y = B.next().value;
        B = B.next().value;
        var M = {};
        return (M[y] = B ^ x), M;
      }),
      U(function (x, y) {
        return C({}, x, y);
      }, {}),
      Y(a, 1)
    );
    return { Qa: b, Cf: c, ba: a };
  }
  function Ei(a, b, c) {
    return Object.assign.apply(
      Object,
      [{}].concat(
        sa(
          Object.keys(b).map(function (d) {
            var e = {};
            return (e[d] = Fi(a, b[d], c)), e;
          })
        )
      )
    );
  }
  function Fi(a, b, c) {
    var d = 0;
    return nf(a, [c, b]).i(
      S(function (e) {
        var g = A(e);
        e = g.next().value;
        g = g.next().value;
        return e !== void 0 && g !== void 0;
      }),
      T(function (e, g) {
        e = A(e).next().value;
        return A(g).next().value === e;
      }),
      V(["unknown", 0]),
      ve(),
      R(function (e) {
        var g = A(e);
        e = A(g.next().value);
        e.next();
        e = e.next().value;
        var f = A(g.next().value);
        g = f.next().value;
        f = f.next().value;
        var h = {};
        return (h[g] = f - e), (h.Qh = ++d), h;
      }),
      U(function (e, g) {
        return C({}, e, g);
      }, {}),
      Y(a, 1)
    );
  }
  function Mi(a, b, c, d, e, g, f, h, k, l) {
    var m = wi;
    if (m.length > 1)
      for (var r = 0; r < m.length - 1; r++) if (m[r] < m[r + 1]) throw Error();
    if (l.length > 1)
      for (r = 0; r < l.length - 1; r++) if (l[r] < l[r + 1]) throw Error();
    k = Ci(a, c, e, h, k, m);
    d = d.i(lg(Bi, l), T(Nb), Y(a, 1));
    l = k.dc.i(
      R(function (B) {
        return th(0.5, m, B, !0);
      }),
      Y(a, 1)
    );
    r = k.dc.i(
      R(function (B) {
        return th(1, m, B, !0);
      }),
      Y(a, 1)
    );
    var t = g.i(
        ig(),
        R(function (B) {
          return Math.round(B);
        }),
        Y(a, 1)
      ),
      q = e.i(
        ig(),
        R(function (B) {
          return Math.round(B);
        }),
        Y(a, 1)
      );
    f = f.i(
      ig(),
      R(function (B) {
        return Math.round(B);
      }),
      Y(a, 1)
    );
    e = nd([e, g]).i(
      R(function (B) {
        var M = A(B);
        B = M.next().value;
        M = M.next().value;
        return {
          timestamp: B.timestamp.maximum(M.timestamp),
          value: !B.value && M.value,
        };
      }),
      Eh(),
      R(function (B) {
        return Math.round(B);
      }),
      V(0),
      T(),
      Y(a, 1)
    );
    var w = g.i(Eh(), Y(a, 1)),
      z = nd([c, g]).i(
        R(function (B) {
          var M = A(B);
          B = M.next().value;
          M = M.next().value;
          return {
            timestamp: B.timestamp.maximum(M.timestamp),
            value: M.value ? B.value : 0,
          };
        }),
        Y(a, 1)
      );
    g = h.i(
      V(void 0),
      ze(function () {
        return z.i(lg(Bi, m));
      }),
      T(Nb),
      Y(a, 1)
    );
    var K = g.i(
        R(function (B) {
          return th(0.5, m, B);
        }),
        Y(a, 1)
      ),
      x = g.i(
        R(function (B) {
          return th(1, m, B);
        }),
        Y(a, 1)
      ),
      y = z.i(
        Sg(
          R(function (B) {
            return B >= m[2];
          })
        ),
        ig(),
        R(function (B) {
          return Math.round(B);
        }),
        Y(a, 1)
      );
    h = h.i(
      V(void 0),
      ze(function () {
        return z.i(
          lg(Fh, m),
          R(function (B) {
            return B.map(function (M, D) {
              return D > 0 ? M - B[D - 1] : M;
            });
          })
        );
      }),
      T(Nb),
      Y(a, 1)
    );
    a = Ad(c, b).i(
      R(function (B) {
        return { timestamp: B.timestamp, value: !0 };
      }),
      ig(),
      R(function (B) {
        return Math.round(B);
      }),
      V(0),
      T(),
      Y(a, 1)
    );
    return C({}, k, {
      nj: z,
      wc: g,
      me: h,
      xg: w,
      Mj: e,
      vc: t,
      Ad: a,
      Wd: f,
      ei: l,
      di: r,
      kf: K,
      jf: x,
      lf: y,
      wi: q,
      sf: d,
    });
  }
  var Ch = { fi: 2e3, Sd: 0.5, le: 0.3 },
    wi = [1, 0.75, Ch.Sd, Ch.le, 0];
  function Ni(a, b, c, d, e, g, f, h, k, l, m, r, t, q) {
    var w = wi;
    e = Bh(a, c, q, e);
    var z = h.i(
        R(function (I) {
          return I[0];
        })
      ),
      K = m.i(
        R(function (I) {
          return I[0] >= 2e3;
        }),
        V(!1),
        Y(a, 1)
      ),
      x = b.i(
        S(function (I) {
          return I.value.type === "midpoint";
        }),
        pe(!0),
        V(!1),
        Y(a, 1)
      );
    b = nf(a, [x, t]).i(
      S(function (I) {
        return A(I).next().value;
      }),
      R(function (I) {
        I = A(I);
        I.next();
        return I.next().value;
      }),
      V(0),
      Y(a, 1)
    );
    var y = nd([g, b]).i(
      R(function (I) {
        var W = A(I);
        I = W.next().value;
        W = W.next().value;
        return Math.min(I > 0 ? I / 2 : 15e3, W > 0 ? W : 15e3, 15e3);
      }),
      Y(a, 1)
    );
    b = Ah(a, c, z, y, q);
    z = nf(a, [z, y, x]).i(
      R(function (I) {
        var W = A(I);
        I = W.next().value;
        var la = W.next().value;
        W = W.next().value;
        return I === void 0 || la === void 0 || W === void 0
          ? !1
          : I >= la || W;
      }),
      T(),
      Y(a, 1)
    );
    var B = 0,
      M = 0,
      D = 0,
      G = new Wc(1),
      va = new Wc(1),
      Ha = new Wc(1);
    d = d.i(
      S(function (I) {
        return !!I;
      }),
      R(function (I) {
        return I.map(function (W) {
          Ha.next(++D);
          W = W.criteria
            .filter(function (la) {
              return la !== null;
            })
            .map(function (la) {
              return la;
            })
            .map(function (la) {
              return xh(a, c, w, la, g, f, h, k, l, m, r, t, q);
            });
          return Ad.apply(null, sa(W)).i(
            S(function (la) {
              return la;
            }),
            V(!1),
            Be(function (la) {
              la && G.next(++B);
            }),
            T(),
            Be(function (la) {
              la && va.next(++M);
            })
          );
        });
      }),
      ze(function (I) {
        return nd(I);
      }),
      T(),
      Y(a, 1)
    );
    x = nf(a, [G.i(Y(a, 1)), va.i(Y(a, 1)), Ha.i(Y(a, 1))]).i(
      R(function (I) {
        var W = A(I);
        I = W.next().value;
        var la = W.next().value;
        W = W.next().value;
        return { tmcr: I, tmcf: la, tvcf: W };
      }),
      Y(a, 1)
    );
    return { Eb: e, Qb: b, Oc: z, Ff: d, sh: K, Ef: x };
  }
  function Oi(a, b, c) {
    c(!0);
  }
  var Pi = function (a, b) {
      b = b === void 0 ? !1 : b;
      this.key = a;
      this.defaultValue = b;
      this.valueType = "boolean";
    },
    Qi = function (a, b) {
      b = b === void 0 ? 0 : b;
      this.key = a;
      this.defaultValue = b;
      this.valueType = "number";
    };
  var Ri = {
    considerOmidZOrderOcclusions: [new Pi("100006"), !1],
    extraPings: [new Qi("45362137"), 0],
    extrapolators: [new Pi("45377435"), !1],
    rxlidarStatefulBeacons: [new Pi("45372163"), !1],
    shouldIgnoreAdChoicesIcon: [new Pi("45382077"), !1],
    dedicatedViewableAttributionPing: [new Qi("45389692"), 0],
    useReachIntegrationPolyfill: [new Pi("45407239"), !1],
    useReachIntegrationSharedStorage: [new Pi("45407240", !0), !0],
    sendBrowserIdInsteadOfVPID: [new Pi("45407241"), !1],
    waitForImpressionColleague: [new Pi("45430682"), !1],
    rxInNonrx: [new Pi("45642405"), !1],
    addQueryIdToErrorPing: [new Pi("45653435"), !1],
    shouldSendExplicitDisplayMeasurablePing: [new Pi("45658589"), !1],
    reachUseCreateWorklet: [new Pi("45661569"), !1],
    shouldCacheTimeMetricsInLocalStorage: [new Pi("45722991", !0), !0],
    omakaseAdStatsResetVersion: [new Qi("45738539", 2), 2],
  };
  function Si(a) {
    return Object.entries(Ri).reduce(function (b, c) {
      var d = A(c);
      c = d.next().value;
      var e = A(d.next().value);
      d = e.next().value;
      e = e.next().value;
      var g;
      if (a == null) var f = void 0;
      else
        a: {
          var h = a.Ud[d.key];
          if (d.valueType === "proto") {
            try {
              var k = JSON.parse(h);
              if (Array.isArray(k)) {
                f = k;
                break a;
              }
            } catch (l) {}
            f = d.defaultValue;
          } else f = typeof h === typeof d.defaultValue ? h : d.defaultValue;
        }
      b[c] = (g = f) != null ? g : e;
      return b;
    }, {});
  }
  function Ti(a, b) {
    if (a) throw Error("H");
    b.push(65533);
  }
  function Ui(a, b) {
    b = String.fromCharCode.apply(null, b);
    return a == null ? b : a + b;
  }
  var Vi = void 0,
    Wi,
    Xi,
    Yi = typeof TextDecoder !== "undefined";
  var Zi = typeof Uint8Array !== "undefined",
    $i = !Rh && typeof btoa === "function",
    aj = /[-_.]/g,
    bj = { "-": "+", _: "/", ".": "=" };
  function cj(a) {
    return bj[a] || "";
  }
  function dj(a) {
    if (!$i) return Wh(a);
    var b = aj.test(a) ? a.replace(aj, cj) : a;
    try {
      var c = atob(b);
    } catch (d) {
      throw Error("I`" + a + "`" + d);
    }
    a = new Uint8Array(c.length);
    for (b = 0; b < c.length; b++) a[b] = c.charCodeAt(b);
    return a;
  }
  var ej = {};
  var gj = function (a, b) {
      if (b !== ej) throw Error("K");
      this.jc = a;
      if (a != null && a.length === 0) throw Error("J");
      this.dontPassByteStringToStructuredClone = fj;
    },
    hj;
  function fj() {}
  var ij = {};
  function jj(a, b, c) {
    if (a != null) {
      var d;
      var e = (d = ij) != null ? d : (ij = {});
      d = e[a] || 0;
      d >= b ||
        ((e[a] = d + 1),
        (a = Error(c)),
        a.__closure__error__context__984382 ||
          (a.__closure__error__context__984382 = {}),
        (a.__closure__error__context__984382.severity = "incident"),
        Jh(a));
    }
  }
  function kj() {
    return typeof BigInt === "function";
  }
  var lj = typeof Symbol === "function" && typeof Symbol() === "symbol";
  function mj(a, b, c) {
    return typeof Symbol === "function" && typeof Symbol() === "symbol"
      ? (c === void 0 ? 0 : c) && Symbol.for && a
        ? Symbol.for(a)
        : a != null
        ? Symbol(a)
        : Symbol()
      : b;
  }
  var nj = mj("jas", void 0, !0),
    oj = mj("unknownBinaryFields", Symbol()),
    pj = mj("unknownBinaryThrottleKey", "0ub"),
    qj = mj("unknownBinaryThrottleKey", "0ubs"),
    rj = mj("m_m", "Nj", !0),
    sj = mj("validPivotSelector", "vps"),
    tj = mj("knownMessageType", "knownMessageType"),
    uj = mj("destroyedStructure", "destroyedStructure");
  H(
    Math.round(
      Math.log2(
        Math.max.apply(
          Math,
          sa(
            Object.values({
              Ri: 1,
              Qi: 2,
              Pi: 4,
              Yi: 8,
              hj: 16,
              Vi: 32,
              Gi: 64,
              Ni: 128,
              Ji: 256,
              dj: 512,
              Mi: 1024,
              Oi: 2048,
              Wi: 4096,
              Si: 8192,
            })
          )
        )
      )
    ) === 13
  );
  var vj = { pg: { value: 0, configurable: !0, writable: !0, enumerable: !1 } },
    wj = Object.defineProperties,
    Z = lj ? J(nj) : "pg",
    xj,
    yj = [];
  zj(yj, 7);
  xj = Object.freeze(yj);
  function Aj(a) {
    return L(a, "state is only maintained on arrays.")[Z] | 0;
  }
  function Bj(a, b) {
    H((b & 16777215) === b);
    L(a, "state is only maintained on arrays.");
    lj || Z in a || wj(a, vj);
    a[Z] |= b;
  }
  function zj(a, b) {
    H((b & 16777215) === b);
    L(a, "state is only maintained on arrays.");
    lj || Z in a || wj(a, vj);
    a[Z] = b;
  }
  function Cj(a, b, c) {
    (c === void 0 || !c || b & 2048) &&
      H(b & 64, "state for messages must be constructed");
    H(
      (b & 5) === 0,
      "state for messages should not contain repeated field state"
    );
    H(
      (b & 8192) === 0,
      "state for messages should not contain map field state"
    );
    if (b & 64) {
      H(b & 64);
      c = (b >> 14) & 1023 || 536870912;
      var d = a.length;
      H(b & 64);
      H(
        c + (b & 128 ? 0 : -1) >= d - 1,
        "pivot %s is pointing at an index earlier than the last index of the array, length: %s",
        c,
        d
      );
      b & 128 &&
        H(
          typeof a[0] === "string",
          "arrays with a message_id bit must have a string in the first position, got: %s",
          a[0]
        );
    }
  }
  function Dj(a) {
    var b = L(a, "state is only maintained on arrays.")[Z] | 0;
    Cj(a, b);
    return b;
  }
  function Ej(a) {
    var b = L(a, "state is only maintained on arrays.")[Z] | 0;
    Cj(a, b);
    return b;
  }
  function Fj(a, b) {
    Gb(b);
    H(
      (b > 0 && b <= 1023) || 536870912 === b,
      "pivot must be in the range [1, 1024) or NO_PIVOT got %s",
      b
    );
    return (a & -16760833) | ((b & 1023) << 14);
  }
  function Gj(a) {
    H(a & 64);
    return a & 128 ? 0 : -1;
  }
  var Hj = Object.getOwnPropertyDescriptor(Array.prototype, "tg");
  Object.defineProperties(Array.prototype, {
    tg: {
      get: function () {
        var a = Ij(this);
        return Hj ? Hj.get.call(this) + "|" + a : a;
      },
      configurable: !0,
      enumerable: !1,
    },
  });
  function Ij(a) {
    function b(e, g) {
      e & c && d.push(g);
    }
    var c = L(a, "state is only maintained on arrays.")[Z] | 0,
      d = [];
    b(1, "IS_REPEATED_FIELD");
    b(2, "IS_IMMUTABLE_ARRAY");
    b(4, "IS_API_FORMATTED");
    b(512, "STRING_FORMATTED");
    b(1024, "GBIGINT_FORMATTED");
    b(1024, "BINARY");
    b(8, "ONLY_MUTABLE_VALUES");
    b(16, "UNFROZEN_SHARED");
    b(32, "MUTABLE_REFERENCES_ARE_OWNED");
    b(64, "CONSTRUCTED");
    b(128, "HAS_MESSAGE_ID");
    b(256, "FROZEN_ARRAY");
    b(2048, "HAS_WRAPPER");
    b(4096, "MUTABLE_SUBSTRUCTURES");
    b(8192, "KNOWN_MAP_ARRAY");
    c & 64 &&
      (H(c & 64),
      (a = (c >> 14) & 1023 || 536870912),
      a !== 536870912 && d.push("pivot: " + a));
    return d.join(",");
  }
  var Jj = lj && Math.random() < 0.5,
    Kj = Jj ? Symbol() : void 0;
  function Lj(a) {
    H(Mj(a));
    return Jj ? a[J(Kj)] : a.K;
  }
  var Nj,
    Oj = typeof rj === "symbol",
    Pj = {};
  function Mj(a) {
    var b = a[rj],
      c = b === Pj;
    H(!Nj || c === a instanceof Nj);
    if (Oj && b && !c) throw Error("L");
    return c;
  }
  function Qj(a) {
    return a != null && Mj(a);
  }
  function Rj(a, b) {
    Gb(a);
    H(a > 0);
    H(b === 0 || b === -1);
    return a + b;
  }
  function Sj(a, b) {
    H(b === Tj || b === void 0);
    return a + (b ? 0 : -1);
  }
  function Uj(a, b) {
    Gb(a);
    H(a >= 0);
    H(b === 0 || b === -1);
    return a - b;
  }
  function Vj(a, b) {
    if (b === void 0) {
      if ((b = !Wj(a)))
        H(Mj(a)),
          (a = Jj ? a[J(Kj)] : a.K),
          (b = L(a, "state is only maintained on arrays.")[Z] | 0),
          Cj(a, b),
          (b = !!(2 & b));
      return b;
    }
    H(Mj(a));
    var c = Jj ? a[J(Kj)] : a.K;
    var d = L(c, "state is only maintained on arrays.")[Z] | 0;
    Cj(c, d);
    H(b === d);
    return !!(2 & b) && !Wj(a);
  }
  var Xj = {};
  function Wj(a) {
    var b = a.wf,
      c;
    (c = !b) ||
      (H(Mj(a)),
      (a = Jj ? a[J(Kj)] : a.K),
      (c = L(a, "state is only maintained on arrays.")[Z] | 0),
      Cj(a, c),
      (c = !!(2 & c)));
    H(c);
    H(b === void 0 || b === Xj);
    return b === Xj;
  }
  function Yj(a, b) {
    H(Mj(a));
    var c = Jj ? a[J(Kj)] : a.K;
    var d = L(c, "state is only maintained on arrays.")[Z] | 0;
    Cj(c, d);
    H(b === !!(2 & d));
    a.wf = b ? Xj : void 0;
  }
  var Zj = Symbol("exempted jspb subclass"),
    ak =
      typeof Symbol != "undefined" && typeof Symbol.hasInstance != "undefined";
  function bk() {}
  function ck(a) {
    var b = Aj(L(a));
    H(!((b & 2 && b & 4) || b & 256) || Object.isFrozen(a));
    a = Aj(a);
    b = a & 4;
    var c = (512 & a ? 1 : 0) + (1024 & a ? 1 : 0);
    H(
      (b && c <= 1) || (!b && c === 0),
      "Expected at most 1 type-specific formatting bit, but got " +
        c +
        " with state: " +
        a
    );
  }
  Object.freeze({});
  function dk(a, b, c) {
    H(b & 64);
    H(b & 64);
    var d = b & 128 ? 0 : -1;
    var e = a.length,
      g;
    if ((g = !!e))
      (g = a[e - 1]),
        (g =
          g != null &&
          typeof g === "object" &&
          !g[uj] &&
          g.constructor === Object);
    var f = e + (g ? -1 : 0),
      h = a[e - 1];
    H(
      !!g ===
        (h != null &&
          typeof h === "object" &&
          !h[uj] &&
          h.constructor === Object)
    );
    for (b = b & 128 ? 1 : 0; b < f; b++) (h = a[b]), c(Uj(b, d), h);
    if (g) {
      a = a[e - 1];
      for (var k in a) !isNaN(k) && c(+k, a[k]);
    }
  }
  var Tj = {};
  function ek(a, b) {
    a = L(a, "state is only maintained on arrays.")[Z] | 0;
    H(a & 64);
    a & 128 ? H(b === Tj) : H(b === void 0);
  }
  function fk(a) {
    H(a & 64);
    return a & 128 ? Tj : void 0;
  }
  var gk = typeof Va.BigInt === "function" && typeof Va.BigInt(0) === "bigint";
  function hk(a) {
    var b = a;
    if (Ig(b)) {
      if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(b)) throw Error("N`" + b);
    } else if (Hg(b) && !Number.isSafeInteger(b)) throw Error("O`" + b);
    if (gk) {
      Kg(a) || (wg(a, Ng(Ig, Jg, Hg)), (a = BigInt(a)));
      b = a % BigInt(2);
      var c = BigInt;
      Bg(!0);
      var d =
        typeof Window === "function" && globalThis.top instanceof Window
          ? globalThis.top
          : globalThis;
      d.gbigintUseStrInDebugToggleVal == null &&
        Object.defineProperties(d, {
          gbigintUseStrInDebugToggleVal: { value: Math.round(Math.random()) },
        });
      return b === c(d.gbigintUseStrInDebugToggleVal) ? a.toString() : a;
    }
    return (a = Jg(a) ? (a ? "1" : "0") : Ig(a) ? a.trim() || "0" : String(a));
  }
  var nk = Eg(function (a) {
      if (gk)
        return wg(ik, Kg), wg(jk, Kg), (a = BigInt(a)), a >= ik && a <= jk;
      a = Ag(a, Ig);
      return a[0] === "-" ? kk(a, lk) : kk(a, mk);
    }, "isSafeInt52"),
    lk = Number.MIN_SAFE_INTEGER.toString(),
    ik = gk ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
    mk = Number.MAX_SAFE_INTEGER.toString(),
    jk = gk ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;
  function kk(a, b) {
    if (a.length > b.length) return !1;
    if (a.length < b.length || a === b) return !0;
    for (var c = 0; c < a.length; c++) {
      var d = a[c],
        e = b[c];
      if (d > e) return !1;
      if (d < e) return !0;
    }
    c = xg;
    zg(
      "Assertion fail:",
      "isInRange weird case. Value was: " + a + ". Boundary was: " + b + "." ||
        c
    );
  }
  var ok = typeof Uint8Array.prototype.slice === "function",
    pk = 0,
    qk = 0;
  function rk(a) {
    var b = a >>> 0;
    pk = b;
    qk = ((a - b) / 4294967296) >>> 0;
  }
  function sk(a) {
    if (a < 0) {
      rk(0 - a);
      var b = A(tk());
      a = b.next().value;
      b = b.next().value;
      pk = a >>> 0;
      qk = b >>> 0;
    } else rk(a);
  }
  function uk(a, b) {
    b >>>= 0;
    a >>>= 0;
    if (b <= 2097151) var c = "" + (4294967296 * b + a);
    else
      kj()
        ? (c = "" + ((BigInt(b) << BigInt(32)) | BigInt(a)))
        : ((c = ((a >>> 24) | (b << 8)) & 16777215),
          (b = (b >> 16) & 65535),
          (a = (a & 16777215) + c * 6777216 + b * 6710656),
          (c += b * 8147497),
          (b *= 2),
          a >= 1e7 && ((c += (a / 1e7) >>> 0), (a %= 1e7)),
          c >= 1e7 && ((b += (c / 1e7) >>> 0), (c %= 1e7)),
          H(b),
          (c = b + vk(c) + vk(a)));
    return c;
  }
  function vk(a) {
    a = String(a);
    return "0000000".slice(a.length) + a;
  }
  function tk() {
    var a = pk,
      b = qk;
    b = ~b;
    a ? (a = ~a + 1) : (b += 1);
    return [a, b];
  }
  var wk = typeof BigInt === "function" ? BigInt.asUintN : void 0,
    xk = Number.isSafeInteger,
    yk = Number.isFinite,
    zk = Math.trunc,
    Ak = Number.MAX_SAFE_INTEGER;
  function Bk(a) {
    if (a == null || typeof a === "number") return a;
    if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a);
  }
  function Ck(a) {
    if (a == null || typeof a === "boolean") return a;
    if (typeof a === "number") return !!a;
  }
  var Dk = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
  function Ek(a) {
    switch (typeof a) {
      case "bigint":
        return !0;
      case "number":
        return yk(a);
      case "string":
        return Dk.test(a);
      default:
        return !1;
    }
  }
  function Fk(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return yk(a) ? a | 0 : void 0;
  }
  function Gk(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return yk(a) ? a >>> 0 : void 0;
  }
  function Hk(a) {
    if (a == null) return a;
    var b = typeof a;
    if (b === "bigint") return H(typeof a === "bigint"), hk(wk(64, a));
    if (Ek(a)) {
      if (b === "string") {
        H(Ek(a));
        H(!0);
        b = zk(Number(a));
        if (xk(b) && b >= 0) a = String(b);
        else if (
          ((b = a.indexOf(".")),
          b !== -1 && (a = a.substring(0, b)),
          H(a.indexOf(".") === -1),
          a[0] === "-"
            ? (b = !1)
            : ((b = a.length),
              (b = b < 20 ? !0 : b === 20 && a <= "18446744073709551615")),
          !b)
        ) {
          H(a.length > 0);
          if (a.length < 16) sk(Number(a));
          else if (kj())
            (a = BigInt(a)),
              (pk = Number(a & BigInt(4294967295)) >>> 0),
              (qk = Number((a >> BigInt(32)) & BigInt(4294967295)));
          else {
            H(a.length > 0);
            b = +(a[0] === "-");
            qk = pk = 0;
            for (
              var c = a.length, d = 0 + b, e = ((c - b) % 6) + b;
              e <= c;
              d = e, e += 6
            )
              (d = Number(a.slice(d, e))),
                (qk *= 1e6),
                (pk = pk * 1e6 + d),
                pk >= 4294967296 &&
                  ((qk += Math.trunc(pk / 4294967296)),
                  (qk >>>= 0),
                  (pk >>>= 0));
            b &&
              ((b = A(tk())),
              (a = b.next().value),
              (b = b.next().value),
              (pk = a),
              (qk = b));
          }
          a = uk(pk, qk);
        }
        return a;
      }
      if (b === "number")
        return (
          H(Ek(a)),
          H(!0),
          (a = zk(a)),
          (a >= 0 && xk(a)) ||
            (H(a < 0 || a > Ak),
            H(Number.isInteger(a)),
            sk(a),
            (a = pk),
            (b = qk),
            (c = b * 4294967296 + (a >>> 0)),
            (a = Number.isSafeInteger(c) ? c : uk(a, b))),
          a
        );
    }
  }
  function Ik(a) {
    return a == null || typeof a === "string" ? a : void 0;
  }
  function Jk(a) {
    return a;
  }
  Jk[sj] = {};
  function Kk(a) {
    return a;
  }
  var Lk = function () {
    throw Error("P");
  };
  if (ak) {
    var Mk = function () {
        throw Error("Q");
      },
      Nk = {};
    Object.defineProperties(
      Lk,
      ((Nk[Symbol.hasInstance] = {
        value: Mk,
        configurable: !1,
        writable: !1,
        enumerable: !1,
      }),
      Nk)
    );
    H(
      Lk[Symbol.hasInstance] === Mk,
      "defineProperties did not work: was it monkey-patched?"
    );
  }
  function Ok(a) {
    var b = $a(oj);
    return b ? L(a)[b] : void 0;
  }
  var Pk = function () {},
    Qk = function (a, b) {
      for (var c in a) !isNaN(c) && b(a, +c, L(a[c]));
    },
    Rk = function (a) {
      var b = new Pk();
      Qk(a, function (c, d, e) {
        b[d] = Array.prototype.slice.call(e);
      });
      b.Ee = a.Ee;
      return b;
    };
  function Sk(a, b) {
    H(Mj(a));
    H(Mj(a));
    a = Jj ? a[J(Kj)] : a.K;
    L(a);
    var c = $a(oj),
      d;
    lj &&
      c &&
      ((d = a[c]) == null ? void 0 : d[b]) != null &&
      jj(pj, 3, "0ub:" + b);
  }
  function Tk(a, b) {
    b < 100 || jj(qj, 1, "0ubs:" + b);
  }
  function Uk(a, b, c, d, e) {
    var g = d !== void 0;
    d = !!d;
    var f = $a(oj),
      h;
    !g && lj && f && (h = a[f]) && Qk(h, Tk);
    f = [];
    var k = a.length;
    h = 4294967295;
    var l = !1,
      m = !!(b & 64);
    if (m) {
      H(b & 64);
      var r = b & 128 ? 0 : -1;
    } else r = void 0;
    if (!(b & 1)) {
      var t = k && a[k - 1];
      t == null || typeof t !== "object" || t[uj] || t.constructor !== Object
        ? (t = void 0)
        : (k--, (h = k));
      if (m && !(b & 128) && !g) {
        l = !0;
        var q;
        b = (q = Vk) != null ? q : Jk;
        h = Rj(b(Uj(h, J(r)), J(r), a, t, e), J(r));
      }
    }
    e = void 0;
    for (q = 0; q < k; q++)
      if (((b = a[q]), b != null && (b = c(b, d)) != null))
        if (m && q >= h) {
          Wk();
          var w = Uj(q, J(r)),
            z = void 0;
          ((z = e) != null ? z : (e = {}))[w] = b;
        } else f[q] = b;
    if (t)
      for (var K in t)
        (k = t[K]),
          k != null &&
            (k = c(k, d)) != null &&
            ((q = +K),
            (b = void 0),
            m && !Number.isNaN(q) && (b = Rj(q, J(r))) < h
              ? (Wk(), (f[J(b)] = k))
              : ((q = void 0), (((q = e) != null ? q : (e = {}))[K] = k)));
    e && (l ? f.push(e) : (H(h < 4294967295), (f[h] = e)));
    g &&
      (c = $a(oj)) &&
      (L(f),
      L(a),
      H(f[c] === void 0),
      (a = Ok(a)) && a instanceof Pk && (f[c] = Rk(a)));
    return f;
  }
  function Xk(a) {
    J(a);
    switch (typeof a) {
      case "number":
        return Number.isFinite(a) ? a : "" + a;
      case "bigint":
        return nk(a) ? Number(a) : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          ck(a);
          var b = L(a, "state is only maintained on arrays.")[Z] | 0;
          return a.length === 0 && b & 1 ? void 0 : Uk(a, b, Xk);
        }
        if (Qj(a)) return Yk(a);
        if (a instanceof gj) {
          b = a.jc;
          if (b == null) a = "";
          else if (typeof b === "string") a = b;
          else {
            if ($i) {
              for (var c = "", d = 0, e = b.length - 10240; d < e; )
                c += String.fromCharCode.apply(
                  null,
                  b.subarray(d, (d += 10240))
                );
              c += String.fromCharCode.apply(null, d ? b.subarray(d) : b);
              b = btoa(c);
            } else {
              H(Xa(b), "encodeByteArray takes an array as a parameter");
              c === void 0 && (c = 0);
              Xh();
              c = Sh[c];
              d = Array(Math.floor(b.length / 3));
              e = c[64] || "";
              for (var g = 0, f = 0; g < b.length - 2; g += 3) {
                var h = b[g],
                  k = b[g + 1],
                  l = b[g + 2],
                  m = c[h >> 2];
                h = c[((h & 3) << 4) | (k >> 4)];
                k = c[((k & 15) << 2) | (l >> 6)];
                l = c[l & 63];
                d[f++] = "" + m + h + k + l;
              }
              m = 0;
              l = e;
              switch (b.length - g) {
                case 2:
                  (m = b[g + 1]), (l = c[(m & 15) << 2] || e);
                case 1:
                  (b = b[g]),
                    (d[f] =
                      "" + c[b >> 2] + c[((b & 3) << 4) | (m >> 4)] + l + e);
              }
              b = d.join("");
            }
            a = a.jc = b;
          }
          return a;
        }
        H(!(a instanceof Uint8Array));
        return;
    }
    return a;
  }
  var Vk;
  function Zk(a) {
    H(!Vk);
    return Yk(a);
  }
  function Yk(a) {
    H(Mj(a));
    var b = Jj ? a[J(Kj)] : a.K;
    var c = L(b, "state is only maintained on arrays.")[Z] | 0;
    Cj(b, c);
    return Uk(b, c, Xk, void 0, a.constructor);
  }
  function Wk() {
    var a,
      b = (a = Vk) != null ? a : Jk;
    H(b !== Kk);
  }
  typeof Proxy !== "undefined" &&
    new Proxy(
      {},
      {
        getPrototypeOf: $k,
        setPrototypeOf: $k,
        isExtensible: $k,
        preventExtensions: $k,
        getOwnPropertyDescriptor: $k,
        defineProperty: $k,
        has: $k,
        get: $k,
        set: $k,
        deleteProperty: $k,
        apply: $k,
        construct: $k,
      }
    );
  function $k(a, b) {
    if (b === uj) return !0;
    throw Error("V");
  }
  var al, bl;
  function cl(a) {
    switch (typeof a) {
      case "boolean":
        return al || (al = [0, void 0, !0]);
      case "number":
        return a > 0
          ? void 0
          : a === 0
          ? bl || (bl = [0, void 0])
          : [-a, void 0];
      case "string":
        return [0, a];
      case "object":
        return (
          L(a),
          H(a.length === 2 || (a.length === 3 && a[2] === !0)),
          H(a[0] == null || (typeof a[0] === "number" && a[0] >= 0)),
          H(a[1] == null || typeof a[1] === "string"),
          a
        );
    }
  }
  function dl(a, b) {
    L(b);
    return el(a, b[0], b[1]);
  }
  function el(a, b, c, d) {
    d = d === void 0 ? 0 : d;
    if (a != null)
      for (var e = 0; e < a.length; e++) {
        var g = a[e];
        Array.isArray(g) && ck(g);
      }
    if (a == null)
      (e = 32), c ? ((a = [c]), (e |= 128)) : (a = []), b && (e = Fj(e, b));
    else {
      if (!Array.isArray(a))
        throw Error("X`" + JSON.stringify(a) + "`" + Wa(a));
      e = L(a, "state is only maintained on arrays.")[Z] | 0;
      if (Kh && 1 & e) throw Error("Y");
      2048 & e && !(2 & e) && fl();
      if (Object.isFrozen(a) || !Object.isExtensible(a) || Object.isSealed(a))
        throw Error("Z");
      if (e & 256) throw Error("$");
      if (e & 64) return (e | d) !== e && zj(a, (e |= d)), Cj(a, e), a;
      if (c && ((e |= 128), c !== a[0]))
        throw Error("aa`" + c + "`" + JSON.stringify(a[0]) + "`" + Wa(a[0]));
      a: {
        c = a;
        e |= 64;
        var f = c.length;
        if (f) {
          var h = f - 1;
          g = c[h];
          if (
            g != null &&
            typeof g === "object" &&
            !g[uj] &&
            g.constructor === Object
          ) {
            b = Gj(e);
            f = Uj(h, b);
            if (f >= 1024) throw Error("ca`" + f);
            for (var k in g)
              (h = +k),
                h < f &&
                  ((h = Rj(h, b)), H(c[h] == null), (c[h] = g[k]), delete g[k]);
            e = Fj(e, f);
            break a;
          }
        }
        if (b) {
          k = Math.max(b, Uj(f, Gj(e)));
          if (k > 1024) throw Error("da`" + f);
          e = Fj(e, k);
        }
      }
    }
    zj(a, e | 64 | d);
    return a;
  }
  function fl() {
    if (Kh) throw Error("ba");
  }
  function gl(a, b) {
    J(a);
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      ck(a);
      var c = L(a, "state is only maintained on arrays.")[Z] | 0;
      if (a.length === 0 && c & 1) a = void 0;
      else if (!(c & 2)) {
        var d;
        if ((d = b))
          H(!(2 & c)), H(!(2048 & c)), (d = !(4096 & c) && !(16 & c));
        d
          ? (Bj(a, 34), c & 4 && Object.freeze(a))
          : (a = hl(a, c, !1, b && !(c & 16)));
      }
      return a;
    }
    if (Qj(a))
      return (
        H(Qj(a)),
        (b = Lj(a)),
        (c = Ej(b)),
        Vj(a, c) ? a : il(a, b, c) ? jl(a, b) : hl(b, c)
      );
    if (a instanceof gj) return a;
    H(!(a instanceof Uint8Array));
  }
  function jl(a, b, c) {
    a = new a.constructor(b);
    c && Yj(a, !0);
    a.Sg = Xj;
    return a;
  }
  function hl(a, b, c, d) {
    H(b === (L(a, "state is only maintained on arrays.")[Z] | 0));
    d != null || (d = !!(34 & b));
    a = Uk(a, b, gl, d);
    d = 32;
    c && (d |= 2);
    b = (b & 16769217) | d;
    zj(a, b);
    return a;
  }
  function kl(a) {
    if (!Wj(a)) return !1;
    var b;
    H(Mj(a));
    var c = (b = Jj ? a[J(Kj)] : a.K),
      d = L(c, "state is only maintained on arrays.")[Z] | 0;
    Cj(c, d);
    H(d & 2);
    b = hl(b, d);
    Bj(b, 2048);
    H(Mj(a));
    L(b);
    Jj ? (a[J(Kj)] = b) : (a.K = b);
    Yj(a, !1);
    a.Sg = void 0;
    return !0;
  }
  function ll(a, b) {
    if (b === void 0)
      (b = L(a, "state is only maintained on arrays.")[Z] | 0), Cj(a, b, !0);
    else {
      var c = L(a, "state is only maintained on arrays.")[Z] | 0;
      Cj(a, c, !0);
      H(b === c);
    }
    H(!(b & 2));
    b & 32 && !(b & 4096) && zj(a, b | 4096);
  }
  function il(a, b, c) {
    return Zj && a[Zj]
      ? !1
      : c & 2
      ? !0
      : c & 32 && !(c & 4096)
      ? (zj(b, c | 2), Yj(a, !0), !0)
      : !1;
  }
  var nl = function (a, b) {
      H(Object.isExtensible(a));
      H(Mj(a));
      a = Jj ? a[J(Kj)] : a.K;
      b = ml(a, b);
      (a = b !== null) || (a = void 0);
      if (a) return b;
    },
    ol = function (a, b, c) {
      return ml(a, b, void 0, c);
    };
  function ml(a, b, c, d) {
    ek(a, c);
    if (b === -1) return null;
    var e = Sj(b, c);
    H(e === Rj(b, Gj(L(a, "state is only maintained on arrays.")[Z] | 0)));
    H(e >= 0);
    var g = a.length - 1;
    if (!(g < Sj(1, c))) {
      if (e >= g) {
        var f = a[g];
        if (
          f == null ||
          typeof f !== "object" ||
          f[uj] ||
          f.constructor !== Object
        )
          if (e === g) c = f;
          else return;
        else {
          c = f[b];
          var h = !0;
        }
      } else c = a[e];
      if (d && c != null) {
        d = d(c);
        if (d == null) return d;
        if (!Object.is(d, c)) return h ? (f[b] = d) : (a[e] = d), d;
      }
      return c;
    }
  }
  function pl(a, b, c, d, e) {
    ek(a, e);
    var g = Sj(c, e);
    H(g === Rj(c, Gj(L(a, "state is only maintained on arrays.")[Z] | 0)));
    H(g >= 0);
    var f = a.length - 1;
    if (f >= Sj(1, e) && g >= f) {
      var h = a[f];
      if (
        h != null &&
        typeof h === "object" &&
        !h[uj] &&
        h.constructor === Object
      )
        return (h[c] = d), b;
    }
    if (g <= f) return (a[g] = d), b;
    d !== void 0 &&
      ((f = b) == null &&
        ((b = L(a, "state is only maintained on arrays.")[Z] | 0),
        Cj(a, b),
        (f = b)),
      H(f & 64),
      (f = (f >> 14) & 1023 || 536870912),
      c >= f
        ? (H(f !== 536870912),
          d != null && ((g = {}), (a[Sj(f, e)] = ((g[c] = d), g))))
        : (a[g] = d));
    return b;
  }
  var ql = function (a, b, c) {
    H(Mj(a));
    a = Jj ? a[J(Kj)] : a.K;
    b = ml(a, b, c);
    return Qj(b) || Array.isArray(b);
  };
  function rl(a, b) {
    if (!a) return a;
    H((L(b, "state is only maintained on arrays.")[Z] | 0) & 2 ? Vj(a) : !0);
    return a;
  }
  function sl(a, b, c) {
    if (b & 2) throw Error("M");
    var d = fk(b);
    var e = ml(a, c, d);
    e = Array.isArray(e) ? e : xj;
    var g = e === xj ? 7 : L(e, "state is only maintained on arrays.")[Z] | 0;
    var f = g;
    2 & b && (f |= 2);
    f |= 1;
    if (2 & f || (2 & f && 4 & f) || 256 & f || 16 & f)
      f === g || (2 & f && 4 & f) || 256 & f || zj(e, f),
        (e = Array.prototype.slice.call(e)),
        (g = 0),
        (f = (2 & b ? f | 2 : f & -3) & -273),
        J(pl(a, b, c, e, d));
    f &= -13;
    f !== g && zj(e, f);
    return e;
  }
  function tl(a, b, c) {
    var d = L(a, "state is only maintained on arrays.")[Z] | 0;
    Cj(a, d, !0);
    var e = fk(d),
      g = ml(a, c, e);
    if (Qj(g)) {
      if (!Vj(g)) return kl(g), H(Mj(g)), Jj ? g[J(Kj)] : g.K;
      H(Mj(g));
      var f = Jj ? g[J(Kj)] : g.K;
      H((L(f, "state is only maintained on arrays.")[Z] | 0) & 2);
    } else Array.isArray(g) && ((f = g), d & 2 && Bj(f, 34));
    if (f) {
      var h = L(f, "state is only maintained on arrays.")[Z] | 0;
      h & 2 && (f = hl(f, h));
    }
    f = dl(f, b);
    f !== g && pl(a, d, c, f, e);
    return f;
  }
  function ul(a, b, c, d) {
    var e = !1;
    d = ol(a, d, function (g) {
      if (Qj(g)) var f = g;
      else if (Array.isArray(g)) {
        f = L(g, "state is only maintained on arrays.")[Z] | 0;
        var h = f | (b & 32);
        h |= b & 2;
        h !== f && zj(g, h);
        f = new c(g);
      } else f = void 0;
      e = f !== g && f != null;
      return f;
    });
    if (d != null) return e && !Vj(d) && ll(a, b), rl(d, a);
  }
  var vl = function (a, b, c) {
      H(Mj(a));
      var d = Jj ? a[J(Kj)] : a.K;
      var e = L(d, "state is only maintained on arrays.")[Z] | 0;
      Cj(d, e);
      b = ul(d, e, b, c);
      if (b == null) return b;
      e = L(d, "state is only maintained on arrays.")[Z] | 0;
      Cj(d, e);
      if (!Vj(a, e)) {
        var g = b;
        var f = Lj(g),
          h = Ej(f);
        g = Vj(g, h)
          ? il(g, f, h)
            ? jl(g, f, !0)
            : new g.constructor(hl(f, h, !1))
          : g;
        g !== b &&
          (kl(a) &&
            (H(Mj(a)),
            (d = Jj ? a[J(Kj)] : a.K),
            (a = L(d, "state is only maintained on arrays.")[Z] | 0),
            Cj(d, a),
            (e = a)),
          (b = g),
          (e = pl(d, e, c, b)),
          ll(d, e));
      }
      return rl(b, d);
    },
    wl = function (a, b) {
      var c = c === void 0 ? 0 : c;
      a = Fk(nl(a, b));
      return a != null ? a : c;
    };
  function xl() {
    return new SyntaxError("Maximum protobuf recursion depth exceeded");
  }
  var yl = function (a, b, c) {
    this.buffer = a;
    if (c && !b) throw Error("ma");
    this.he = b;
  };
  function zl(a, b) {
    if (typeof a === "string") return new yl(dj(a), b);
    if (Array.isArray(a)) return new yl(new Uint8Array(a), b);
    if (a.constructor === Uint8Array) return new yl(a, !1);
    if (a.constructor === ArrayBuffer)
      return (a = new Uint8Array(a)), new yl(a, !1);
    if (a.constructor === gj) {
      Ib(a, gj);
      if (ej !== ej) throw Error("K");
      b = a.jc;
      b == null ||
        (Zi && b != null && b instanceof Uint8Array) ||
        (typeof b === "string"
          ? (b = dj(b))
          : (Fb("Cannot coerce to Uint8Array: " + Wa(b)), (b = null)));
      b = (b == null ? b : (a.jc = b)) || new Uint8Array(0);
      return new yl(b, !0, a);
    }
    if (a instanceof Uint8Array)
      return (
        (a =
          a.constructor === Uint8Array
            ? a
            : new Uint8Array(a.buffer, a.byteOffset, a.byteLength)),
        new yl(a, !1)
      );
    throw Error("na");
  }
  var Al = function (a, b, c, d) {
    this.pb = this.pa = null;
    this.xc = !1;
    this.H = this.xa = this.Ca = 0;
    this.init(a, b, c, d);
  };
  n = Al.prototype;
  n.init = function (a, b, c, d) {
    var e = d === void 0 ? {} : d;
    d = e.uc;
    e = e.xd;
    e = e === void 0 ? !1 : e;
    this.uc = d === void 0 ? !1 : d;
    this.xd = e;
    a &&
      ((this.pb = a = zl(a, this.xd)),
      (this.pa = a.buffer),
      (this.xc = a.he),
      (this.Ca = b || 0),
      (this.xa = c !== void 0 ? this.Ca + c : this.pa.length),
      (this.H = this.Ca));
  };
  n.Kc = function () {
    this.clear();
    Bl.length < 100 && Bl.push(this);
  };
  n.clear = function () {
    this.pb = this.pa = null;
    this.xc = !1;
    this.H = this.xa = this.Ca = 0;
    this.uc = !1;
  };
  n.setEnd = function (a) {
    this.xa = a;
  };
  n.reset = function () {
    this.H = this.Ca;
  };
  n.fa = function () {
    return this.H;
  };
  n.advance = function (a) {
    Cl(this, this.H + a);
  };
  var Dl = function (a) {
      var b = 0,
        c = 0,
        d = 0,
        e = a.pa,
        g = a.H;
      do {
        var f = e[g++];
        b |= (f & 127) << d;
        d += 7;
      } while (d < 32 && f & 128);
      if (d > 32)
        for (c |= (f & 127) >> 4, d = 3; d < 32 && f & 128; d += 7)
          (f = e[g++]), (c |= (f & 127) << d);
      Cl(a, g);
      if (!(f & 128))
        return (
          (a = b >>> 0),
          (c >>>= 0),
          hk(
            kj()
              ? BigInt.asUintN(
                  64,
                  (BigInt(c >>> 0) << BigInt(32)) + BigInt(a >>> 0)
                )
              : uk(a, c)
          )
        );
      throw Error("ja");
    },
    Cl = function (a, b) {
      a.H = b;
      if (b > a.xa) throw Error("ka`" + b + "`" + a.xa);
    },
    El = function (a) {
      var b = a.pa,
        c = a.H,
        d = b[c++],
        e = d & 127;
      if (
        d & 128 &&
        ((d = b[c++]),
        (e |= (d & 127) << 7),
        d & 128 &&
          ((d = b[c++]),
          (e |= (d & 127) << 14),
          d & 128 &&
            ((d = b[c++]),
            (e |= (d & 127) << 21),
            d & 128 &&
              ((d = b[c++]),
              (e |= d << 28),
              d & 128 &&
                b[c++] & 128 &&
                b[c++] & 128 &&
                b[c++] & 128 &&
                b[c++] & 128 &&
                b[c++] & 128))))
      )
        throw Error("ja");
      Cl(a, c);
      return e;
    },
    Fl = function (a) {
      return El(a) >>> 0;
    },
    Gl = function (a) {
      return Dl(a);
    },
    Hl = function (a) {
      var b = a.pa,
        c = a.H,
        d = b[c + 0],
        e = b[c + 1],
        g = b[c + 2];
      b = b[c + 3];
      a.advance(4);
      return ((d << 0) | (e << 8) | (g << 16) | (b << 24)) >>> 0;
    },
    Il = function (a) {
      for (var b = 0, c = a.H, d = c + 10, e = a.pa; c < d; ) {
        var g = e[c++];
        b |= g;
        if ((g & 128) === 0) return Cl(a, c), !!(b & 127);
      }
      throw Error("ja");
    },
    Jl = function (a) {
      return El(a);
    },
    Kl = function (a, b) {
      if (b < 0) throw Error("la`" + b);
      var c = a.H,
        d = c + b;
      if (d > a.xa) throw Error("ka`" + (a.xa - c) + "`" + b);
      a.H = d;
      return c;
    };
  Al.prototype.Be = function (a, b) {
    var c = Kl(this, a),
      d = H(this.pa);
    if (Yi) {
      var e;
      b
        ? (e = Wi) || (e = Wi = new TextDecoder("utf-8", { fatal: !0 }))
        : (e = Xi) || (e = Xi = new TextDecoder("utf-8", { fatal: !1 }));
      var g = c + a;
      d = c === 0 && g === d.length ? d : d.subarray(c, g);
      try {
        var f = e.decode(d);
      } catch (m) {
        if (b) {
          if (Vi === void 0) {
            try {
              e.decode(new Uint8Array([128]));
            } catch (r) {}
            try {
              e.decode(new Uint8Array([97])), (Vi = !0);
            } catch (r) {
              Vi = !1;
            }
          }
          b = !Vi;
        }
        b && (Wi = void 0);
        throw m;
      }
    } else {
      a = c + a;
      f = [];
      for (var h = null, k, l; c < a; )
        (k = d[c++]),
          k < 128
            ? f.push(k)
            : k < 224
            ? c >= a
              ? Ti(b, f)
              : ((l = d[c++]),
                k < 194 || (l & 192) !== 128
                  ? (c--, Ti(b, f))
                  : ((k = ((k & 31) << 6) | (l & 63)),
                    H(k >= 128 && k <= 2047),
                    f.push(k)))
            : k < 240
            ? c >= a - 1
              ? Ti(b, f)
              : ((l = d[c++]),
                (l & 192) !== 128 ||
                (k === 224 && l < 160) ||
                (k === 237 && l >= 160) ||
                ((e = d[c++]) & 192) !== 128
                  ? (c--, Ti(b, f))
                  : ((k = ((k & 15) << 12) | ((l & 63) << 6) | (e & 63)),
                    H(k >= 2048 && k <= 65535),
                    H(k < 55296 || k > 57343),
                    f.push(k)))
            : k <= 244
            ? c >= a - 2
              ? Ti(b, f)
              : ((l = d[c++]),
                (l & 192) !== 128 ||
                ((k << 28) + (l - 144)) >> 30 !== 0 ||
                ((e = d[c++]) & 192) !== 128 ||
                ((g = d[c++]) & 192) !== 128
                  ? (c--, Ti(b, f))
                  : ((k =
                      ((k & 7) << 18) |
                      ((l & 63) << 12) |
                      ((e & 63) << 6) |
                      (g & 63)),
                    H(k >= 65536 && k <= 1114111),
                    (k -= 65536),
                    f.push(((k >> 10) & 1023) + 55296, (k & 1023) + 56320)))
            : Ti(b, f),
          f.length >= 8192 && ((h = Ui(h, f)), (f.length = 0));
      H(c === a, "expected " + c + " === " + a);
      f = Ui(h, f);
    }
    return f;
  };
  Al.prototype.jd = function (a) {
    if (a == 0) return hj || (hj = new gj(null, ej));
    var b = Kl(this, a);
    if (this.uc && this.xc) b = this.pa.subarray(b, b + a);
    else {
      var c = H(this.pa);
      a = b + a;
      b =
        b === a
          ? new Uint8Array(0)
          : ok
          ? c.slice(b, a)
          : new Uint8Array(c.subarray(b, a));
    }
    Ib(b, Uint8Array);
    return b.length == 0 ? hj || (hj = new gj(null, ej)) : new gj(b, ej);
  };
  var Bl = [];
  H(!0);
  var Ll = 0,
    Nl = function (a, b, c, d) {
      if (Bl.length) {
        var e = Bl.pop();
        e.init(a, b, c, d);
        a = e;
      } else a = new Al(a, b, c, d);
      this.j = a;
      this.Na = this.j.fa();
      this.l = this.Wb = this.gb = -1;
      Ml(this, d);
    },
    Ml = function (a, b) {
      b = (b === void 0 ? {} : b).Pd;
      a.Pd = b === void 0 ? !1 : b;
    },
    Pl = function (a, b, c, d) {
      if (Ol.length) {
        var e = Ol.pop();
        Ml(e, d);
        e.j.init(a, b, c, d);
        return e;
      }
      return new Nl(a, b, c, d);
    };
  Nl.prototype.Kc = function () {
    this.j.clear();
    this.l = this.gb = this.Wb = -1;
    Ol.length < 100 && Ol.push(this);
  };
  Nl.prototype.fa = function () {
    return this.j.fa();
  };
  Nl.prototype.reset = function () {
    this.j.reset();
    this.Na = this.j.fa();
    this.l = this.gb = this.Wb = -1;
  };
  Nl.prototype.advance = function (a) {
    this.j.advance(a);
  };
  var Ql = function (a) {
      var b = a.j;
      if (b.H == b.xa) return !1;
      a.Wb !== -1 &&
        ((b = a.j.fa()),
        (a.j.H = a.Na),
        Fl(a.j),
        a.l === 4 || a.l === 3
          ? H(
              b === a.j.fa(),
              "Expected to not advance the cursor.  Group tags do not have values."
            )
          : H(
              b > a.j.fa(),
              "Expected to read the field, did you forget to call a read or skip method?"
            ),
        (a.j.H = b));
      a.Na = a.j.fa();
      b = Fl(a.j);
      var c = b >>> 3,
        d = b & 7;
      if (!(d >= 0 && d <= 5)) throw Error("fa`" + d + "`" + a.Na);
      if (c < 1) throw Error("ga`" + c + "`" + a.Na);
      a.Wb = b;
      a.gb = c;
      a.l = d;
      return !0;
    },
    Rl = function () {
      if (Ll >= 100) throw xl();
      Ll++;
    },
    Sl = function (a) {
      try {
        switch (a.l) {
          case 0:
            a.l != 0
              ? (Fb("Invalid wire type for skipVarintField"), Sl(a))
              : Il(a.j);
            break;
          case 1:
            H(a.l === 1);
            a.j.advance(8);
            break;
          case 2:
            if (a.l != 2) Fb("Invalid wire type for skipDelimitedField"), Sl(a);
            else {
              var b = Fl(a.j);
              a.j.advance(b);
            }
            break;
          case 5:
            H(a.l === 5);
            a.j.advance(4);
            break;
          case 3:
            Rl();
            var c = a.gb;
            try {
              do {
                if (!Ql(a)) throw Error("ha");
                if (a.l == 4) {
                  if (a.gb != c) throw Error("ia");
                  break;
                }
                Sl(a);
              } while (1);
            } catch (d) {
              if (d instanceof RangeError) throw xl();
              throw d;
            } finally {
              Ll > 0 && Ll--;
            }
            break;
          default:
            throw Error("fa`" + a.l + "`" + a.Na);
        }
      } catch (d) {
        if (d instanceof RangeError) throw xl();
        throw d;
      }
    },
    Tl = function (a, b, c) {
      H(a.l == 2);
      var d = a.j.xa,
        e = Fl(a.j),
        g = a.j.fa() + e,
        f = g - d;
      f <= 0 &&
        (a.j.setEnd(g), c(b, a, void 0, void 0, void 0), (f = g - a.j.fa()));
      if (f) throw Error("ea`" + e + "`" + (e - f));
      a.j.H = g;
      a.j.setEnd(d);
    },
    Ul = function (a) {
      H(a.l == 0);
      return El(a.j);
    },
    Vl = function (a) {
      H(a.l == 0);
      return Fl(a.j);
    },
    Wl = function (a) {
      H(a.l == 0);
      return Dl(a.j);
    },
    Xl = function (a) {
      H(a.l == 0);
      return El(a.j);
    };
  Nl.prototype.Be = function () {
    return Yl(this);
  };
  var Yl = function (a) {
    H(a.l == 2);
    var b = Fl(a.j);
    return a.j.Be(b, !0);
  };
  Nl.prototype.jd = function () {
    H(this.l == 2);
    var a = Fl(this.j);
    return this.j.jd(a);
  };
  var Zl = function (a, b, c) {
      H(a.l == 2);
      var d = Fl(a.j);
      for (d = a.j.fa() + d; a.j.fa() < d; ) c.push(b(a.j));
    },
    Ol = [];
  function $l() {
    var a = function () {
      throw Error("oa");
    };
    Object.setPrototypeOf(a, a.prototype);
    return a;
  }
  var am = $l(),
    bm = $l(),
    cm = $l(),
    dm = $l(),
    em = $l(),
    fm = $l(),
    gm = $l(),
    hm = $l(),
    im = $l(),
    jm = $l();
  var km = function (a, b, c) {
    this.preventPassingToStructuredClone = bk;
    Ib(this, km, "The message constructor should only be used by subclasses");
    H(
      this.constructor !== km,
      "Message is an abstract class and cannot be directly constructed"
    );
    var d = this.constructor,
      e;
    if (a && ((e = a[tj]) != null ? e : (a[tj] = d)) !== d) throw Error("pa");
    a = el(a, b, c, 2048);
    H(Mj(this));
    L(a);
    Jj ? (this[J(Kj)] = a) : (this.K = a);
    H(Mj(this));
    a = Jj ? this[J(Kj)] : this.K;
    b = L(a, "state is only maintained on arrays.")[Z] | 0;
    Cj(a, b);
    H(b & 64);
    H(b & 2048);
  };
  n = km.prototype;
  n.toJSON = function () {
    return Zk(this);
  };
  n.cc = function () {
    return JSON.stringify(Zk(this));
  };
  n.getExtension = function (a) {
    Ib(this, a.Vf);
    var b = Ib(this, km);
    Sk(b, a.ya);
    return a.sb
      ? a.Xc
        ? a.wb(b, a.sb, a.ya, 4, a.ab)
        : a.wb(b, a.sb, a.ya, a.ab)
      : a.Xc
      ? a.wb(b, a.ya, 4, a.ab)
      : a.wb(b, a.ya, a.defaultValue, a.ab);
  };
  n.hasExtension = function (a) {
    H(!a.Xc, "repeated extensions don't support hasExtension");
    var b = Ib(this, km);
    Sk(b, a.ya);
    a.sb
      ? (a = ql(b, a.ya, a.ab))
      : (H(!a.Xc, "repeated extensions don't support getExtensionOrUndefined"),
        Ib(b, a.Vf),
        (b = Ib(b, km)),
        Sk(b, a.ya),
        (a = a.sb ? a.wb(b, a.sb, a.ya, a.ab) : a.wb(b, a.ya, null, a.ab)),
        (a = (a === null ? void 0 : a) !== void 0));
    return a;
  };
  n.clone = function () {
    var a = Ib(this, km);
    H(Qj(a));
    var b = Lj(a),
      c = Ej(b);
    return il(a, b, c) ? jl(a, b, !0) : new a.constructor(hl(b, c, !1));
  };
  n.he = function () {
    return Vj(this);
  };
  Nj = km;
  km.prototype[rj] = Pj;
  km.prototype.toString = function () {
    H(Mj(this));
    return (Jj ? this[J(Kj)] : this.K).toString();
  };
  var lm = function (a, b, c, d) {
    this.oc = a;
    a = $a(bm);
    this.We = (!!a && d === a) || !1;
  };
  function mm(a) {
    var b = nm;
    var c = c === void 0 ? bm : c;
    return new lm(a, b, !1, c);
  }
  function nm(a, b, c, d, e) {
    var g = a.mk;
    b = b instanceof km ? Lj(b) : Array.isArray(b) ? dl(b, d) : void 0;
    g.call(a, c, b, e);
  }
  var om = mm(function (a, b, c, d, e) {
      if (a.l !== 2) return !1;
      Tl(a, tl(b, d, c), e);
      return !0;
    }),
    pm = mm(function (a, b, c, d, e) {
      if (a.l !== 2) return !1;
      Tl(a, tl(b, d, c), e);
      return !0;
    }),
    qm = Symbol(),
    rm = Symbol(),
    sm = Symbol(),
    tm,
    um;
  function vm(a) {
    var b = wm,
      c = xm,
      d = a[qm];
    if (d) return d;
    d = {};
    d.qf = a;
    d.cd = Cg(cl(a[0]));
    var e = a[1],
      g = 1;
    e &&
      e.constructor === Object &&
      ((d.extensions = e),
      (e = a[++g]),
      typeof e === "function" &&
        e.length > 0 &&
        (tm != null && (Bg(tm === e), Bg(um === a[1 + g])),
        (d.rg = !0),
        tm != null || (tm = e),
        um != null || (um = Ag(a[g + 1], Lg)),
        (e = a[(g += 2)])));
    for (
      var f = {};
      e && Array.isArray(e) && e.length && typeof e[0] === "number" && e[0] > 0;

    ) {
      for (var h = 0; h < e.length; h++) f[e[h]] = e;
      e = a[++g];
    }
    for (h = 1; e !== void 0; ) {
      typeof e === "number" && (Bg(e > 0), (h += e), (e = a[++g]));
      var k = void 0;
      if (e instanceof lm) var l = e;
      else (l = om), g--;
      e = void 0;
      if ((e = l) == null ? 0 : e.We) {
        e = a[++g];
        k = a;
        var m = g;
        typeof e === "function" && (Bg(e.length === 0), (e = e()), (k[m] = e));
        ym(e);
        k = e;
      }
      e = a[++g];
      m = h + 1;
      typeof e === "number" && e < 0 && ((m -= e), (e = a[++g]));
      for (; h < m; h++) {
        var r = f[h];
        k ? c(d, h, Cg(l), k, r) : b(d, h, Cg(l), r);
      }
    }
    return (a[qm] = d);
  }
  function ym(a) {
    if (Array.isArray(a) && a.length) {
      var b = a[0];
      var c = cl(b);
      c != null && c !== b && (a[0] = c);
      b = c != null;
    } else b = !1;
    Bg(b);
    return a;
  }
  function zm(a) {
    return Array.isArray(a)
      ? a[0] instanceof lm
        ? (Bg(a.length === 2), ym(a[1]), a)
        : [pm, ym(a)]
      : [Ag(a, Mg(lm)), void 0];
  }
  function Am(a) {
    return vm(a);
  }
  function wm(a, b, c, d) {
    var e = c.oc;
    a[b] = d
      ? function (g, f, h) {
          return e(g, f, h, d);
        }
      : e;
  }
  function xm(a, b, c, d, e) {
    var g = c.oc,
      f,
      h;
    a[b] = function (k, l, m) {
      return g(k, l, m, h || (h = vm(d).cd), f || (f = Bm(d)), e);
    };
  }
  function Bm(a) {
    var b = a[rm];
    if (b != null) return b;
    var c = vm(a);
    b = c.rg
      ? function (d, e) {
          return Cg(tm)(d, e, c);
        }
      : function (d, e) {
          a: {
            Rl();
            try {
              var g = L(d, "state is only maintained on arrays.")[Z] | 0;
              Cj(d, g, !0);
              for (Bg(!(g & 2)); Ql(e) && e.l != 4; ) {
                var f = e.gb,
                  h = c[f];
                if (h == null) {
                  var k = c.extensions;
                  if (k) {
                    var l = k[f];
                    if (l) {
                      var m = Cm(l);
                      m != null && (h = c[f] = m);
                    }
                  }
                }
                if (h == null || !h(e, d, f)) {
                  g = e;
                  var r = g.Na;
                  Sl(g);
                  if (g.Pd) var t = void 0;
                  else {
                    var q = g.j.fa(),
                      w = q - r;
                    g.j.H = r;
                    var z = g.j.jd(w);
                    H(q == g.j.fa());
                    t = z;
                  }
                  var K = (w = g = void 0),
                    x = d,
                    y = f,
                    B = t;
                  L(x);
                  B &&
                    ((g = (w = (K = x[oj]) != null ? K : (x[oj] = new Pk()))[
                      y
                    ]) != null
                      ? g
                      : (w[y] = [])
                    ).push(B);
                }
              }
              var M = Ok(d);
              M && (M.Ee = Cg(c.qf[sm]));
              var D = !0;
              break a;
            } catch (G) {
              if (G instanceof RangeError) throw xl();
              throw Ag(G, Mg(Error));
            } finally {
              Ll > 0 && Ll--;
            }
            D = void 0;
          }
          return D;
        };
    a[rm] = b;
    a[sm] = Dm.bind(a);
    return b;
  }
  function Dm(a, b, c, d) {
    var e = this[qm],
      g = this[rm],
      f = dl(void 0, e.cd),
      h = Ok(a);
    if (h) {
      var k = !1,
        l = e.extensions;
      if (l) {
        e = function (w, z, K) {
          if (K.length !== 0)
            if (l[z]) {
              w = A(K);
              z = w.next();
              try {
                for (; !z.done; z = w.next()) {
                  var x = Pl(z.value);
                  try {
                    (k = !0), g(f, x);
                  } finally {
                    x.Kc();
                  }
                }
              } finally {
                xa(w, z);
              }
            } else d == null || d(a, z, K);
        };
        if (b == null) Qk(h, e);
        else if (h != null) {
          var m = h[b];
          m && e(h, b, m);
        }
        if (k) {
          var r = Dj(a);
          if (r & 2 && r & 2048 && (c == null || !c.Yj)) throw Error("qa");
          var t = fk(r),
            q = function (w, z) {
              if (ml(a, w, t) != null)
                switch (c == null ? void 0 : c.Xj) {
                  case 1:
                    return;
                  default:
                    throw Error("ra`" + w);
                }
              z != null && (r = Cg(pl(a, r, w, z, t)));
              delete h[w];
            };
          b == null
            ? dk(f, Dj(f), function (w, z) {
                q(w, z);
              })
            : q(b, ml(f, b, t));
        }
      }
    }
  }
  function Cm(a) {
    a = zm(a);
    var b = Ag(a[0], Mg(lm)).oc;
    if ((a = a[1])) {
      var c = Bm(ym(a)),
        d = Am(ym(a)).cd;
      return function (e, g, f) {
        return b(e, g, f, d, c);
      };
    }
    return b;
  }
  function Em(a, b, c) {
    if (Array.isArray(b)) {
      var d = L(b, "state is only maintained on arrays.")[Z] | 0;
      if (d & 4) return b;
      for (var e = 0, g = 0; e < b.length; e++) {
        var f = a(b[e]);
        f != null &&
          (H(typeof f !== "object" || f instanceof gj), (b[g++] = f));
      }
      g < e && (b.length = g);
      a = d | 1;
      c && (a = (a | 4) & -1537);
      a !== d && zj(b, a);
      c && a & 2 && Object.freeze(b);
      return b;
    }
  }
  function Fm(a, b, c) {
    return new lm(a, b, !1, c);
  }
  function Gm(a, b, c) {
    return new lm(a, b, am, c);
  }
  function Hm(a, b, c) {
    var d = L(a, "state is only maintained on arrays.")[Z] | 0;
    Cj(a, d, !0);
    pl(a, d, b, c, fk(L(a, "state is only maintained on arrays.")[Z] | 0));
  }
  var Im = Fm(
      function (a, b, c) {
        if (a.l !== 1) return !1;
        H(a.l == 1);
        var d = a.j;
        a = Hl(d);
        var e = Hl(d);
        d = (e >> 31) * 2 + 1;
        var g = (e >>> 20) & 2047;
        a = 4294967296 * (e & 1048575) + a;
        Hm(
          b,
          c,
          g == 2047
            ? a
              ? NaN
              : d * Infinity
            : g == 0
            ? d * 4.9e-324 * a
            : d * Math.pow(2, g - 1075) * (a + 4503599627370496)
        );
        return !0;
      },
      function (a, b, c) {
        a.ik(c, Bk(b));
      },
      im
    ),
    Jm = Fm(
      function (a, b, c) {
        if (a.l !== 5) return !1;
        H(a.l == 5);
        var d = Hl(a.j);
        a = (d >> 31) * 2 + 1;
        var e = (d >>> 23) & 255;
        d &= 8388607;
        Hm(
          b,
          c,
          e == 255
            ? d
              ? NaN
              : a * Infinity
            : e == 0
            ? a * 1.401298464324817e-45 * d
            : a * Math.pow(2, e - 150) * (d + 8388608)
        );
        return !0;
      },
      function (a, b, c) {
        a.kk(c, Bk(b));
      },
      hm
    ),
    Km = Fm(
      function (a, b, c) {
        a.l !== 0 ? (a = !1) : (Hm(b, c, Wl(a)), (a = !0));
        return a;
      },
      function (a, b, c) {
        a.vk(c, Hk(b));
      },
      gm
    ),
    Lm = Gm(
      function (a, b, c) {
        if (a.l !== 0 && a.l !== 2) a = !1;
        else {
          var d = L(b, "state is only maintained on arrays.")[Z] | 0;
          Cj(b, d, !0);
          b = sl(b, d, c);
          a.l == 2 ? Zl(a, Gl, b) : b.push(Wl(a));
          a = !0;
        }
        return a;
      },
      function (a, b, c) {
        a.sk(c, Em(Hk, b, !1));
      },
      gm
    ),
    Mm = Fm(
      function (a, b, c) {
        if (a.l !== 0) return !1;
        Hm(b, c, Ul(a));
        return !0;
      },
      function (a, b, c) {
        a.lk(c, Fk(b));
      },
      em
    ),
    Nm = Gm(
      function (a, b, c) {
        if (a.l !== 0 && a.l !== 2) return !1;
        var d = L(b, "state is only maintained on arrays.")[Z] | 0;
        Cj(b, d, !0);
        b = sl(b, d, c);
        a.l == 2 ? Zl(a, El, b) : b.push(Ul(a));
        return !0;
      },
      function (a, b, c) {
        a.qk(c, Em(Fk, b, !0));
      },
      em
    ),
    Om = Fm(
      function (a, b, c) {
        if (a.l !== 0) return !1;
        H(a.l == 0);
        a = Il(a.j);
        Hm(b, c, a);
        return !0;
      },
      function (a, b, c) {
        a.hk(c, Ck(b));
      },
      cm
    ),
    Pm = Fm(
      function (a, b, c) {
        if (a.l !== 2) return !1;
        Hm(b, c, Yl(a));
        return !0;
      },
      function (a, b, c) {
        a.tk(c, Ik(b));
      },
      dm
    ),
    Qm = Fm(
      function (a, b, c) {
        if (a.l !== 0) return !1;
        Hm(b, c, Vl(a));
        return !0;
      },
      function (a, b, c) {
        a.uk(c, Gk(b));
      },
      fm
    ),
    Rm = Gm(
      function (a, b, c) {
        if (a.l !== 0 && a.l !== 2) return !1;
        var d = L(b, "state is only maintained on arrays.")[Z] | 0;
        Cj(b, d, !0);
        b = sl(b, d, c);
        a.l == 2 ? Zl(a, Fl, b) : b.push(Vl(a));
        return !0;
      },
      function (a, b, c) {
        a.nk(c, Em(Gk, b, !0));
      },
      fm
    ),
    Sm = Fm(
      function (a, b, c) {
        if (a.l !== 0) return !1;
        Hm(b, c, Xl(a));
        return !0;
      },
      function (a, b, c) {
        a.jk(c, Fk(b));
      },
      jm
    ),
    Tm = Gm(
      function (a, b, c) {
        if (a.l !== 0 && a.l !== 2) return !1;
        var d = L(b, "state is only maintained on arrays.")[Z] | 0;
        Cj(b, d, !0);
        b = sl(b, d, c);
        a.l == 2 ? Zl(a, Jl, b) : b.push(Xl(a));
        return !0;
      },
      function (a, b, c) {
        a.pk(c, Em(Fk, b, !0));
      },
      jm
    );
  function Um(a) {
    if (a instanceof km) return a.constructor.Uc;
  }
  (function () {
    var a = Va.jspbGetTypeName;
    Va.jspbGetTypeName = a
      ? function (b) {
          return a(b) || Um(b);
        }
      : Um;
  })();
  var Vm = km;
  var Wm = function (a) {
    Vm.call(this, a);
  };
  v(Wm, Vm);
  Wm.prototype.Zd = function () {
    return wl(this, 6);
  };
  Wm.Uc =
    "ads.branding.measurement.client.serving.integrations.active_view.ActiveViewMetadata";
  var Xm = [0, Pm, -2, Om, -1, Mm, Om];
  var Ym = [0, Mm, -3];
  var Zm = [
    0,
    Pm,
    -1,
    Om,
    [
      0,
      Qm,
      -4,
      Sm,
      Om,
      Mm,
      Jm,
      Qm,
      Jm,
      Qm,
      Mm,
      Qm,
      -1,
      Ym,
      Rm,
      Lm,
      Qm,
      Km,
      -1,
      Mm,
      -1,
      Km,
      Jm,
      [0, Km, Mm, -1, Sm, Jm, Km],
      Im,
      Qm,
      [0, Mm, -9, Om],
      Om,
      Jm,
      [0, Sm, -3],
      Ym,
    ],
    Nm,
    -1,
    Tm,
    Mm,
    Om,
    Mm,
  ];
  var $m = function (a) {
    Vm.call(this, a);
  };
  v($m, Vm);
  $m.prototype.Zd = function () {
    return wl(this, 2);
  };
  $m.Uc =
    "ads.branding.measurement.client.serving.integrations.shared.SharedMetadata";
  var an = [0, Pm, Mm];
  var bn = function (a) {
    Vm.call(this, a);
  };
  v(bn, Vm);
  bn.Uc = "ads.branding.measurement.client.serving.IntegratorMetadata";
  var cn = (function (a, b) {
    return function (c, d) {
      a: {
        var e = { xd: !0 };
        d && Object.assign(e, d);
        c = Pl(c, void 0, void 0, e);
        try {
          var g = new a(),
            f = Lj(g);
          Bm(b)(f, c);
          var h = g;
          break a;
        } catch (k) {
          if (k instanceof RangeError) throw xl();
          throw Ib(k, Error);
        } finally {
          c.Kc();
        }
        h = void 0;
      }
      return h;
    };
  })(bn, [0, Zm, Xm, an]);
  var dn = function () {
    this.Ld = new Map();
  };
  dn.prototype.start = function (a, b, c, d) {
    var e = this;
    if (this.nd === void 0 && a.Ta) {
      a = a.Ta;
      this.Kd = d;
      d = a.qd.i(hf);
      var g = a.qd.i(
        R(function (f) {
          return f.value.data.verificationParameters;
        }),
        ci()
      );
      c = g.i(
        R(function (f) {
          a: {
            if ((f = f.ufs_integrator_metadata))
              try {
                var h = cn(f);
                break a;
              } catch (k) {}
            h = new bn();
          }
          return h;
        })
      );
      g = g.i(Yh(a), R(Si));
      this.nd = Hd(d, c, g).subscribe(function (f) {
        var h = A(f);
        f = h.next().value;
        var k = h.next().value;
        h = h.next().value;
        e.Ld.set(f.Db, f);
        b(f.Db, k, h);
      });
      a.Ia !== null && le(a.Ia);
    }
  };
  dn.prototype.dispose = function () {
    var a, b;
    (a = this.nd) == null || (b = a.unsubscribe) == null || b.call(a);
    this.nd = void 0;
    var c;
    (c = this.Kd) == null || c.call(this);
    this.Kd = void 0;
  };
  var en = O(
      S(function (a) {
        return !!a.na;
      }),
      U(
        function (a, b) {
          var c;
          return { Ce: !!b.ig, state: (c = a.state) != null ? c : b };
        },
        { Ce: !1 }
      ),
      S(function (a) {
        return a.Ce;
      })
    ),
    fn = O(
      S(function (a) {
        return !!a.Za && !!a.Te && !!a.O && !!a.ae && !!a.B && !!a.pi;
      }),
      en,
      ag(
        function (a) {
          return a.state.R;
        },
        function (a) {
          return a.state.tb;
        }
      ),
      Be(function (a) {
        var b = a.state;
        a = sf(b);
        b.Te(C({}, b, { hc: b.O, B: b.B, cg: b.ae }), a).forEach(function (c) {
          Ke(b.Za, c).sendNow();
        });
      }),
      qe(1),
      oe()
    );
  var Qf = O(
    R(function (a) {
      var b, c, d, e, g, f, h, k, l, m, r;
      return C({}, a, {
        na: a.zc,
        O: a.vf,
        event: 4,
        B: a.Yh,
        R: (b = a.S) == null ? void 0 : b.zc,
        aa: (c = a.ba) == null ? void 0 : c.complete,
        Y: (d = a.I) == null ? void 0 : d.complete,
        V: (e = a.D) == null ? void 0 : e.complete,
        W: (g = a.F) == null ? void 0 : g.complete,
        X: (f = a.G) == null ? void 0 : f.complete,
        ca: (h = a.A) == null ? void 0 : h.complete,
        ea: (k = a.N) == null ? void 0 : k.complete,
        Z: (l = a.J) == null ? void 0 : l.complete,
        U: (m = a.C) == null ? void 0 : m.complete,
        da: (r = a.M) == null ? void 0 : r.complete,
      });
    }),
    fn
  );
  var Ff = function (a) {
    var b = new Set(),
      c = [];
    return a.i(
      S(function (d) {
        return d.md !== void 0;
      }),
      Be(function (d) {
        var e = d.md;
        Object.keys(e)
          .filter(function (g) {
            return e[g].length > 0;
          })
          .forEach(function (g) {
            b.has(g) || (b.add(g), c.push(g));
          });
      }),
      sd(function () {
        for (var d = [], e = {}; c.length > 0; e = { Re: void 0 })
          (e.Re = c.pop()),
            d.push(
              a.i(
                R(
                  (function (g) {
                    return function (f) {
                      var h, k, l, m, r, t, q, w, z, K, x;
                      return C({}, f, {
                        na: !0,
                        O: f.md[g.Re],
                        event: 21,
                        B: f.va,
                        R: (h = f.S) == null ? void 0 : h.bf,
                        aa: (k = f.ba) == null ? void 0 : k.custom_viewable,
                        Y: (l = f.I) == null ? void 0 : l.custom_viewable,
                        V: (m = f.D) == null ? void 0 : m.custom_viewable,
                        X: (r = f.G) == null ? void 0 : r.custom_viewable,
                        W: (t = f.F) == null ? void 0 : t.custom_viewable,
                        ca: (q = f.A) == null ? void 0 : q.custom_viewable,
                        ea: (w = f.N) == null ? void 0 : w.custom_viewable,
                        Z: (z = f.J) == null ? void 0 : z.custom_viewable,
                        U: (K = f.C) == null ? void 0 : K.custom_viewable,
                        da: (x = f.M) == null ? void 0 : x.custom_viewable,
                      });
                    };
                  })(e)
                ),
                fn
              )
            );
        return nd(d);
      }),
      oe()
    );
  };
  var Hf = O(
    R(function (a) {
      var b, c, d, e, g, f, h, k, l, m, r;
      return C({}, a, {
        na: a.Ic,
        O: a.Wf,
        event: 1,
        B: a.Zb,
        R: (b = a.S) == null ? void 0 : b.Ic,
        aa: (c = a.ba) == null ? void 0 : c.firstquartile,
        Y: (d = a.I) == null ? void 0 : d.firstquartile,
        V: (e = a.D) == null ? void 0 : e.firstquartile,
        X: (g = a.G) == null ? void 0 : g.firstquartile,
        W: (f = a.F) == null ? void 0 : f.firstquartile,
        ca: (h = a.A) == null ? void 0 : h.firstquartile,
        ea: (k = a.N) == null ? void 0 : k.firstquartile,
        Z: (l = a.J) == null ? void 0 : l.firstquartile,
        U: (m = a.C) == null ? void 0 : m.firstquartile,
        da: (r = a.M) == null ? void 0 : r.firstquartile,
      });
    }),
    fn
  );
  var gn = function (a) {
    return a.i(
      T(function (b, c) {
        return b.ja === c.ja;
      }),
      S(function (b) {
        return !!b.ja && b.ja > 0;
      }),
      sd(function (b) {
        return a.i(
          S(function (c) {
            return !!c.ja && !!b.ja && c.ja >= b.ja;
          }),
          R(function (c) {
            return C({}, { na: !0 }, c);
          }),
          fn
        );
      })
    );
  };
  var Pf = O(
    R(function (a) {
      var b, c, d, e, g, f, h, k, l, m, r;
      return C({}, a, {
        ja: a.Mc,
        O: a.Yf,
        event: 12,
        B: a.va,
        R: (b = a.S) == null ? void 0 : b.Lc,
        aa: (c = a.ba) == null ? void 0 : c.fullscreen,
        Y: (d = a.I) == null ? void 0 : d.fullscreen,
        V: (e = a.D) == null ? void 0 : e.fullscreen,
        X: (g = a.G) == null ? void 0 : g.fullscreen,
        W: (f = a.F) == null ? void 0 : f.fullscreen,
        ca: (h = a.A) == null ? void 0 : h.fullscreen,
        ea: (k = a.N) == null ? void 0 : k.fullscreen,
        Z: (l = a.J) == null ? void 0 : l.fullscreen,
        U: (m = a.C) == null ? void 0 : m.fullscreen,
        da: (r = a.M) == null ? void 0 : r.fullscreen,
      });
    }),
    gn
  );
  var Ef = O(
    R(function (a) {
      var b, c, d, e, g, f, h, k, l, m, r;
      return C({}, a, {
        si: "csm",
        na: a.Qb,
        O: a.eg,
        event: 14,
        B: a.va,
        R: (b = a.S) == null ? void 0 : b.cf,
        aa:
          (c = a.ba) == null
            ? void 0
            : c.fully_viewable_audible_half_duration_impression,
        Y:
          (d = a.I) == null
            ? void 0
            : d.fully_viewable_audible_half_duration_impression,
        V:
          (e = a.D) == null
            ? void 0
            : e.fully_viewable_audible_half_duration_impression,
        X:
          (g = a.G) == null
            ? void 0
            : g.fully_viewable_audible_half_duration_impression,
        W:
          (f = a.F) == null
            ? void 0
            : f.fully_viewable_audible_half_duration_impression,
        ca:
          (h = a.A) == null
            ? void 0
            : h.fully_viewable_audible_half_duration_impression,
        ea:
          (k = a.N) == null
            ? void 0
            : k.fully_viewable_audible_half_duration_impression,
        Z:
          (l = a.J) == null
            ? void 0
            : l.fully_viewable_audible_half_duration_impression,
        U:
          (m = a.C) == null
            ? void 0
            : m.fully_viewable_audible_half_duration_impression,
        da:
          (r = a.M) == null
            ? void 0
            : r.fully_viewable_audible_half_duration_impression,
      });
    }),
    fn
  );
  var Jf = O(
    R(function (a) {
      var b, c, d, e, g, f, h, k, l, m, r;
      return C({}, a, {
        na: a.dd,
        O: a.Jg,
        event: 2,
        B: a.Zb,
        R: (b = a.S) == null ? void 0 : b.dd,
        aa: (c = a.ba) == null ? void 0 : c.midpoint,
        Y: (d = a.I) == null ? void 0 : d.midpoint,
        V: (e = a.D) == null ? void 0 : e.midpoint,
        X: (g = a.G) == null ? void 0 : g.midpoint,
        W: (f = a.F) == null ? void 0 : f.midpoint,
        ca: (h = a.A) == null ? void 0 : h.midpoint,
        ea: (k = a.N) == null ? void 0 : k.midpoint,
        Z: (l = a.J) == null ? void 0 : l.midpoint,
        U: (m = a.C) == null ? void 0 : m.midpoint,
        da: (r = a.M) == null ? void 0 : r.midpoint,
      });
    }),
    fn
  );
  var Lf = O(
    R(function (a) {
      var b, c, d, e, g, f, h, k, l, m, r;
      return C({}, a, {
        ja: a.re,
        O: a.Qg,
        event: 10,
        B: a.va,
        R: (b = a.S) == null ? void 0 : b.Pg,
        aa: (c = a.ba) == null ? void 0 : c.mute,
        Y: (d = a.I) == null ? void 0 : d.mute,
        V: (e = a.D) == null ? void 0 : e.mute,
        X: (g = a.G) == null ? void 0 : g.mute,
        W: (f = a.F) == null ? void 0 : f.mute,
        ca: (h = a.A) == null ? void 0 : h.mute,
        ea: (k = a.N) == null ? void 0 : k.mute,
        Z: (l = a.J) == null ? void 0 : l.mute,
        U: (m = a.C) == null ? void 0 : m.mute,
        da: (r = a.M) == null ? void 0 : r.mute,
      });
    }),
    gn
  );
  var Nf = O(
    R(function (a) {
      var b, c, d, e, g, f, h, k, l, m, r;
      return C({}, a, {
        ja: a.Xb,
        O: a.ih,
        event: 6,
        B: a.va,
        R: (b = a.S) == null ? void 0 : b.we,
        aa: (c = a.ba) == null ? void 0 : c.pause,
        Y: (d = a.I) == null ? void 0 : d.pause,
        V: (e = a.D) == null ? void 0 : e.pause,
        X: (g = a.G) == null ? void 0 : g.pause,
        W: (f = a.F) == null ? void 0 : f.pause,
        ca: (h = a.A) == null ? void 0 : h.pause,
        ea: (k = a.N) == null ? void 0 : k.pause,
        Z: (l = a.J) == null ? void 0 : l.pause,
        U: (m = a.C) == null ? void 0 : m.pause,
        da: (r = a.M) == null ? void 0 : r.pause,
      });
    }),
    gn
  );
  var Of = O(
    R(function (a) {
      var b, c, d, e, g, f, h, k, l, m, r;
      return C({}, a, {
        ja: a.bc,
        O: a.Dh,
        event: 7,
        B: a.va,
        R: (b = a.S) == null ? void 0 : b.De,
        aa: (c = a.ba) == null ? void 0 : c.resume,
        Y: (d = a.I) == null ? void 0 : d.resume,
        V: (e = a.D) == null ? void 0 : e.resume,
        X: (g = a.G) == null ? void 0 : g.resume,
        W: (f = a.F) == null ? void 0 : f.resume,
        ca: (h = a.A) == null ? void 0 : h.resume,
        ea: (k = a.N) == null ? void 0 : k.resume,
        Z: (l = a.J) == null ? void 0 : l.resume,
        U: (m = a.C) == null ? void 0 : m.resume,
        da: (r = a.M) == null ? void 0 : r.resume,
      });
    }),
    gn
  );
  var Sf = O(
    S(function (a) {
      return !!a.pd;
    }),
    ag(
      function (a) {
        var b;
        return (b = a.S) == null ? void 0 : b.pd;
      },
      function (a) {
        return a.tb;
      }
    ),
    qe(1),
    oe()
  );
  var Rf = O(
    R(function (a) {
      var b, c, d, e, g, f, h, k, l, m, r;
      return C({}, a, {
        na: a.rd,
        O: a.Wh,
        event: 8,
        B: a.va,
        R: (b = a.S) == null ? void 0 : b.rd,
        aa: (c = a.ba) == null ? void 0 : c.skip,
        Y: (d = a.I) == null ? void 0 : d.skip,
        V: (e = a.D) == null ? void 0 : e.skip,
        X: (g = a.G) == null ? void 0 : g.skip,
        W: (f = a.F) == null ? void 0 : f.skip,
        ca: (h = a.A) == null ? void 0 : h.skip,
        ea: (k = a.N) == null ? void 0 : k.skip,
        Z: (l = a.J) == null ? void 0 : l.skip,
        U: (m = a.C) == null ? void 0 : m.skip,
        da: (r = a.M) == null ? void 0 : r.skip,
      });
    }),
    O(
      en,
      ag(
        function (a) {
          return a.state.R;
        },
        function (a) {
          return a.state.tb;
        }
      ),
      qe(1),
      oe()
    )
  );
  var Kf = O(
    R(function (a) {
      var b, c, d, e, g, f, h, k, l, m, r;
      return C({}, a, {
        na: a.sd,
        O: a.Zh,
        event: 3,
        B: a.Zb,
        R: (b = a.S) == null ? void 0 : b.sd,
        aa: (c = a.ba) == null ? void 0 : c.thirdquartile,
        Y: (d = a.I) == null ? void 0 : d.thirdquartile,
        V: (e = a.D) == null ? void 0 : e.thirdquartile,
        X: (g = a.G) == null ? void 0 : g.thirdquartile,
        W: (f = a.F) == null ? void 0 : f.thirdquartile,
        ca: (h = a.A) == null ? void 0 : h.thirdquartile,
        ea: (k = a.N) == null ? void 0 : k.thirdquartile,
        Z: (l = a.J) == null ? void 0 : l.thirdquartile,
        U: (m = a.C) == null ? void 0 : m.thirdquartile,
        da: (r = a.M) == null ? void 0 : r.thirdquartile,
      });
    }),
    fn
  );
  var Mf = O(
    R(function (a) {
      var b, c, d, e, g, f, h, k, l, m, r;
      return C({}, a, {
        ja: a.Se,
        O: a.ni,
        event: 11,
        B: a.va,
        R: (b = a.S) == null ? void 0 : b.mi,
        aa: (c = a.ba) == null ? void 0 : c.unmute,
        Y: (d = a.I) == null ? void 0 : d.unmute,
        V: (e = a.D) == null ? void 0 : e.unmute,
        X: (g = a.G) == null ? void 0 : g.unmute,
        W: (f = a.F) == null ? void 0 : f.unmute,
        ca: (h = a.A) == null ? void 0 : h.unmute,
        ea: (k = a.N) == null ? void 0 : k.unmute,
        Z: (l = a.J) == null ? void 0 : l.unmute,
        U: (m = a.C) == null ? void 0 : m.unmute,
        da: (r = a.M) == null ? void 0 : r.unmute,
      });
    }),
    gn
  );
  var Cf = O(
    R(function (a) {
      var b, c, d, e, g, f, h, k, l, m, r;
      return C({}, a, {
        na: a.lc,
        O: a.Gg,
        event: 15,
        B: a.va,
        R: (b = a.S) == null ? void 0 : b.df,
        aa: (c = a.ba) == null ? void 0 : c.measurable_impression,
        Y: (d = a.I) == null ? void 0 : d.measurable_impression,
        V: (e = a.D) == null ? void 0 : e.measurable_impression,
        X: (g = a.G) == null ? void 0 : g.measurable_impression,
        W: (f = a.F) == null ? void 0 : f.measurable_impression,
        ca: (h = a.A) == null ? void 0 : h.measurable_impression,
        ea: (k = a.N) == null ? void 0 : k.measurable_impression,
        Z: (l = a.J) == null ? void 0 : l.measurable_impression,
        U: (m = a.C) == null ? void 0 : m.measurable_impression,
        da: (r = a.M) == null ? void 0 : r.measurable_impression,
      });
    }),
    fn
  );
  var Gf = O(
    R(function (a) {
      var b, c, d, e, g, f, h, k, l, m, r;
      return C({}, a, {
        na: a.lc,
        O: a.ri,
        event: 0,
        B: a.Zb,
        R: (b = a.S) == null ? void 0 : b.lc,
        aa: (c = a.ba) == null ? void 0 : c.start,
        Y: (d = a.I) == null ? void 0 : d.start,
        V: (e = a.D) == null ? void 0 : e.start,
        X: (g = a.G) == null ? void 0 : g.start,
        W: (f = a.F) == null ? void 0 : f.start,
        ca: (h = a.A) == null ? void 0 : h.start,
        ea: (k = a.N) == null ? void 0 : k.start,
        Z: (l = a.J) == null ? void 0 : l.start,
        U: (m = a.C) == null ? void 0 : m.start,
        da: (r = a.M) == null ? void 0 : r.start,
      });
    }),
    fn
  );
  var Df = O(
    R(function (a) {
      var b, c, d, e, g, f, h, k, l, m, r;
      return C({}, a, {
        na: a.Eb,
        O: a.ti,
        event: 9,
        B: a.va,
        R: (b = a.S) == null ? void 0 : b.ef,
        aa: (c = a.ba) == null ? void 0 : c.viewable_impression,
        Y: (d = a.I) == null ? void 0 : d.viewable_impression,
        V: (e = a.D) == null ? void 0 : e.viewable_impression,
        X: (g = a.G) == null ? void 0 : g.viewable_impression,
        W: (f = a.F) == null ? void 0 : f.viewable_impression,
        ca: (h = a.A) == null ? void 0 : h.viewable_impression,
        ea: (k = a.N) == null ? void 0 : k.viewable_impression,
        Z: (l = a.J) == null ? void 0 : l.viewable_impression,
        U: (m = a.C) == null ? void 0 : m.viewable_impression,
        da: (r = a.M) == null ? void 0 : r.viewable_impression,
      });
    }),
    fn
  );
  var hn = function (a, b, c) {
    var d = {
        de: Symbol(),
        df: Symbol(),
        ef: Symbol(),
        cf: Symbol(),
        bf: Symbol(),
        lc: Symbol(),
        Ic: Symbol(),
        dd: Symbol(),
        sd: Symbol(),
        Pg: Symbol(),
        mi: Symbol(),
        we: Symbol(),
        De: Symbol(),
        Lc: Symbol(),
        zc: Symbol(),
        rd: Symbol(),
        pd: Symbol(),
      },
      e = this;
    b = b === void 0 ? 0.01 : b;
    this.provider = a;
    this.Lf = b;
    this.te = d;
    this.ue = c;
    this.name = "omid_video";
    this.pe = new Wc();
    this.Hg = new P(function (g) {
      var f = e.pe.subscribe(g);
      return function () {
        f.unsubscribe();
        e.dispose();
      };
    });
    this.Cc = new Wc();
    this.Rb = new Wc();
    this.controlledEvents = [];
    this.subscribedEvents = [];
    Object.values(this.te).forEach(function (g) {
      e.controlledEvents.push(g);
    });
    Object.values(this.ue).forEach(function (g) {
      e.subscribedEvents.push(g);
    });
  };
  hn.prototype.start = function (a) {
    this.Nc === void 0 &&
      a.Ta &&
      ((a = a.Ta),
      (this.Nc = jn(
        a,
        this.Cc.i(Y(a.queue, 1)),
        this.Rb.i(V(!1), Y(a.queue, 1)),
        this.te,
        this.Lf
      ).subscribe(this.pe)));
  };
  hn.prototype.dispose = function () {
    this.Cc.complete();
    this.Rb.complete();
    var a;
    (a = this.Nc) == null || a.unsubscribe();
    this.Nc = void 0;
  };
  var kn = function (a, b, c, d, e) {
    var g;
    if (!(g = !ql(c, 2))) {
      g = vl(c, Wm, 2);
      var f;
      g = (f = Ck(nl(g, 4))) != null ? f : !0;
    }
    if (g) {
      a.Cc.next(
        C({}, a.provider.Ld.get(b), { metadata: c, Qf: d, bk: b, tb: Oi })
      );
      var h, k;
      e((k = (h = vl(c, Wm, 2)) == null ? void 0 : h.Zd()) != null ? k : -1);
    }
  };
  hn.prototype.handleEvent = function (a, b) {
    b === this.ue.de && (this.Rb.next(!0), this.Rb.complete());
  };
  function jn(a, b, c, d, e) {
    e = e === void 0 ? 0.01 : e;
    var g =
        "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&bin=30&cb=rxov&v=" +
        zi,
      f = [1, 0.9, 0.8, 0.7, 0.6, 0.5, 0.4, 0.3, 0.2, 0.1, 0],
      h = e > 0 && Math.random() <= e,
      k = a.Sc.i(Y(a.queue, 1)),
      l = a.qd.i(Y(a.queue, 1));
    return qf(
      a,
      b,
      function (m, r) {
        var t = l.i(
            S(function (p) {
              return p.value.ia === r.sessionId;
            })
          ),
          q = m.He.i(
            S(function (p) {
              return p.value.ia === r.sessionId;
            }),
            R(function () {
              return !0;
            }),
            Y(m.queue, 1)
          ),
          w = t.i(
            R(function (p) {
              return p.value.data.verificationParameters;
            }),
            ci()
          ),
          z = w.i(
            R(function (p) {
              var ta;
              return p == null
                ? void 0
                : (ta = p.tracking_configuration) == null
                ? void 0
                : ta.custom_metric_configurations;
            }),
            R(function (p) {
              return p == null
                ? void 0
                : p.map(function (ta) {
                    return ri(ta);
                  });
            })
          ),
          K = w.i(Yh(m), R(Si)).i(
            R(function (p) {
              return p.considerOmidZOrderOcclusions;
            })
          ),
          x = m.zd
            ? m.zd.i(
                S(function (p) {
                  return p.value.ia === r.sessionId;
                }),
                Y(m.queue, 10)
              )
            : Bd,
          y = k.i(
            S(function (p) {
              return p.value.ia === r.sessionId;
            })
          ),
          B = ti(m, x).qh,
          M = B.Qe.i(
            R(function (p) {
              return { timestamp: p.timestamp, value: p.value !== 2 };
            })
          ),
          D = ch(m.o, M).o;
        M = Gh(m.queue, x);
        var G = Og(m, K, r.sessionId).i(bh(D), Y(m.queue, 1));
        K = rg(m, r);
        var va = K.Zf.i(bh(D)),
          Ha = m.Oa.i(
            S(function (p) {
              return p.value.ia === r.sessionId;
            })
          );
        Ha = oi(m, t, Ha, Ad(x, y));
        var I = ii(m, x, Ha.se, bh(D)).mf,
          W = ui(m, x, bh(D)).rh,
          la = ng(m.queue, x),
          Ua = nh(
            m.queue,
            D,
            G,
            C({}, Ch, {
              Yd: va,
              Bi: lf.Ea(m.queue),
              ff: !1,
              Fg: lf.Ea(m.queue),
              ce: mf.Ea(m.queue),
              oi: lf.Ea(m.queue),
            })
          );
        G = Ua.ag;
        var ea = Ua.Uh;
        Ua = Ua.Vh;
        ea = Mi(
          m.queue,
          x.i(bh(D)),
          G.mb,
          G.wd,
          G.visible,
          I.ec,
          W.gi,
          ea,
          Ua,
          f
        );
        D = Ni(
          m.queue,
          x,
          D,
          z,
          G.visible,
          la,
          ea.me,
          ea.wc,
          ea.xg,
          ea.vc,
          ea.Ha,
          ea.dc,
          ea.Ad,
          G.ta
        );
        Ua = hi(m.queue, w, z, D.Ff);
        z = z.i(
          S(function (p) {
            return p !== void 0;
          }),
          R(function (p) {
            return p.map(function (ta) {
              return ta.id;
            });
          }),
          Y(m.queue, 1)
        );
        var We = si(m.queue, M.mediaTime, G.mb, I.ec),
          ba = w.i(ei("measurable_impression")),
          ca = w.i(ei("viewable_impression")),
          Kn = w.i(ei("mute")),
          Ln = w.i(ei("unmute")),
          Mn = w.i(ei("start")),
          Nn = w.i(ei("firstquartile")),
          On = w.i(ei("midpoint")),
          Pn = w.i(ei("thirdquartile")),
          Qn = w.i(ei("complete")),
          Rn = w.i(ei("skip")),
          Sn = w.i(ei("pause")),
          Tn = w.i(ei("resume")),
          Un = w.i(ei("fullscreen"));
        w = w.i(ei("fully_viewable_audible_half_duration_impression"));
        var If = x.i(
            S(function (p) {
              return p.value.type === "start";
            }),
            R(function () {
              return !0;
            }),
            Y(m.queue, 1)
          ),
          Gi = x.i(
            S(function (p) {
              return p.value.type === "firstQuartile";
            }),
            R(function () {
              return !0;
            }),
            Y(m.queue, 1)
          ),
          Hi = x.i(
            S(function (p) {
              return p.value.type === "midpoint";
            }),
            R(function () {
              return !0;
            }),
            Y(m.queue, 1)
          ),
          Ii = x.i(
            S(function (p) {
              return p.value.type === "thirdQuartile";
            }),
            R(function () {
              return !0;
            }),
            Y(m.queue, 1)
          ),
          Ji = x.i(
            S(function (p) {
              return p.value.type === "complete";
            }),
            R(function () {
              return !0;
            }),
            Y(m.queue, 1)
          ),
          Ki = x.i(
            S(function (p) {
              return p.value.type === "skipped";
            }),
            R(function () {
              return !0;
            }),
            Y(m.queue, 1)
          ),
          X = Ad(
            If.i(pe("start")),
            Gi.i(pe("firstquartile")),
            Hi.i(pe("midpoint")),
            Ii.i(pe("thirdquartile")),
            Ji.i(pe("complete"))
          ).i(Y(m.queue, 1)),
          Vn = vi(
            m.queue,
            X,
            I.fc.i(
              Sg(
                O(
                  R(function (p) {
                    return p.volume;
                  })
                )
              )
            ),
            I.ec,
            G.mb
          ),
          Db = Ad(
            X,
            I.re.i(
              S(function (p) {
                return p > 0;
              }),
              T(),
              pe("mute")
            ),
            I.Se.i(
              S(function (p) {
                return p > 0;
              }),
              T(),
              pe("unmute")
            ),
            B.Xb.i(
              S(function (p) {
                return p > 0;
              }),
              T(),
              pe("pause")
            ),
            B.bc.i(
              S(function (p) {
                return p > 0;
              }),
              T(),
              pe("resume")
            ),
            If.i(pe("measurable_impression")),
            D.Eb.i(
              S(function (p) {
                return p;
              }),
              pe("viewable_impression")
            ),
            D.Qb.i(
              S(function (p) {
                return p;
              }),
              pe("fully_viewable_audible_half_duration_impression")
            ),
            Ua.i(
              S(function (p) {
                return Object.values(p).some(function (ta) {
                  return ta.length > 0;
                });
              }),
              T(),
              pe("custom_viewable")
            )
          ).i(Y(m.queue, 2)),
          Za = X.i(
            R(function (p) {
              return p !== void 0;
            }),
            V(!1),
            T()
          );
        va = Di(
          m.queue,
          G.visible.i(
            R(function (p) {
              return p.value;
            })
          ),
          D.Eb,
          G.mb.i(
            R(function (p) {
              return p.value > 0;
            })
          ),
          I.ec.i(
            R(function (p) {
              return p.value;
            })
          ),
          W.Lc,
          va.i(
            R(function (p) {
              return p.value;
            })
          ),
          D.Oc,
          B.Qe.i(
            R(function (p) {
              return p.value;
            })
          ),
          I.Og,
          I.li,
          Ki,
          W.hi.i(
            R(function (p) {
              return p.value;
            }),
            ve(),
            R(function (p) {
              var ta = A(p);
              p = ta.next().value;
              ta = ta.next().value;
              return p === "fullscreen" && ta !== "fullscreen";
            })
          ),
          D.sh,
          K.ki,
          Za,
          Db
        );
        Za = Ei(
          m.queue,
          {
            I: ea.Wd,
            D: ea.vc,
            F: ea.lf,
            N: ea.ei,
            J: ea.di,
            G: ea.kf,
            C: ea.jf,
            M: ea.Ad,
          },
          Db
        );
        var Li = Ei(
          m.queue,
          { A: ea.wi },
          Db.i(
            ye(function (p) {
              return p !== "viewable_impression";
            })
          )
        );
        X = xi(m.queue, X, {
          ka: G.mb.i(
            R(function (p) {
              return p.value;
            })
          ),
          volume: I.fc.i(
            R(function (p) {
              return p.value.volume;
            })
          ),
          Ma: G.Ma,
          kb: G.wd.i(
            R(function (p) {
              return p.value;
            })
          ),
          Ha: ea.Ha,
          Qa: va.Qa,
        });
        var Wn = Ai(m, G.ta, Db);
        Db = Ai(
          m,
          I.fc.i(
            R(function (p) {
              return p.value.ta;
            })
          ),
          Db
        );
        t = ni(
          m,
          t,
          m.He.i(
            S(function (p) {
              return p.value.ia === r.sessionId;
            })
          ),
          y,
          x,
          m.Oa.i(
            S(function (p) {
              return p.value.ia === r.sessionId;
            })
          ),
          m.Oa.i(
            S(function (p) {
              return p.value.ia !== r.sessionId;
            })
          )
        );
        t = Ad(D.Ef, t).i(
          U(function (p, ta) {
            return C({}, p, ta);
          }, {}),
          R(function (p) {
            return JSON.stringify(p);
          }),
          R(function (p) {
            return h ? p : null;
          }),
          Y(m.queue, 1)
        );
        x = b.i(
          R(function (p) {
            var ta;
            return p.Qf.addQueryIdToErrorPing
              ? (ta = vl(p.metadata, $m, 3)) == null
                ? void 0
                : Ik(nl(ta, 1))
              : void 0;
          })
        );
        return C({}, G, ea, I, M, va, Ha, Vn, We, {
          Wj: Wn,
          Vj: Db,
          rf: new kf(zi),
          pf: new kf(30),
          uf: new kf("rxov"),
          Oh: new kf("o"),
          Hf: new kf([0, 0]),
          Nh: G.Id,
          ui: G.Id,
          rj: new kf(new Tf()),
          tb: new kf(r.tb),
          S: new kf(d),
          ka: G.mb.i(
            R(function (p) {
              return p.value;
            })
          ),
          zg: G.Eg,
          Kg: G.Mg,
          Uf: X.ka.i(
            R(function (p) {
              return p.start;
            })
          ),
          Rf: X.ka.i(
            R(function (p) {
              return p.firstquartile;
            })
          ),
          Sf: X.ka.i(
            R(function (p) {
              return p.midpoint;
            })
          ),
          Tf: X.ka.i(
            R(function (p) {
              return p.thirdquartile;
            })
          ),
          volume: I.fc.i(
            R(function (p) {
              return p.value.volume;
            })
          ),
          Ai: X.volume.i(
            R(function (p) {
              return p.start;
            })
          ),
          xi: X.volume.i(
            R(function (p) {
              return p.firstquartile;
            })
          ),
          yi: X.volume.i(
            R(function (p) {
              return p.midpoint;
            })
          ),
          zi: X.volume.i(
            R(function (p) {
              return p.thirdquartile;
            })
          ),
          Af: X.Ma.i(
            R(function (p) {
              return p.start;
            })
          ),
          xf: X.Ma.i(
            R(function (p) {
              return p.firstquartile;
            })
          ),
          yf: X.Ma.i(
            R(function (p) {
              return p.midpoint;
            })
          ),
          zf: X.Ma.i(
            R(function (p) {
              return p.thirdquartile;
            })
          ),
          kb: G.wd.i(
            R(function (p) {
              return p.value;
            })
          ),
          ne: G.ne,
          qe: G.qe,
          Mh: X.kb.i(
            R(function (p) {
              return p.start;
            })
          ),
          Jh: X.kb.i(
            R(function (p) {
              return p.firstquartile;
            })
          ),
          Kh: X.kb.i(
            R(function (p) {
              return p.midpoint;
            })
          ),
          Lh: X.kb.i(
            R(function (p) {
              return p.thirdquartile;
            })
          ),
          Kj: X.Ha.i(
            R(function (p) {
              return p.start;
            })
          ),
          Ag: X.Ha.i(
            R(function (p) {
              return p.firstquartile;
            })
          ),
          Bg: X.Ha.i(
            R(function (p) {
              return p.midpoint;
            })
          ),
          Cg: X.Ha.i(
            R(function (p) {
              return p.thirdquartile;
            })
          ),
          og: X.Qa.i(
            R(function (p) {
              return p.start;
            })
          ),
          lg: X.Qa.i(
            R(function (p) {
              return p.firstquartile;
            })
          ),
          mg: X.Qa.i(
            R(function (p) {
              return p.midpoint;
            })
          ),
          ng: X.Qa.i(
            R(function (p) {
              return p.thirdquartile;
            })
          ),
          Eb: D.Eb,
          Qb: D.Qb,
          Oc: D.Oc,
          Xb: B.Xb,
          bc: B.bc,
          Mc: W.Mc,
          pd: q,
          lc: If,
          Ic: Gi,
          dd: Hi,
          sd: Ii,
          zc: Ji,
          rd: Ki,
          pi: new kf("lidarv"),
          Gg: ba,
          ti: ca,
          eg: w,
          Qg: Kn,
          ni: Ln,
          ri: Mn,
          Wf: Nn,
          Jg: On,
          Zh: Pn,
          vf: Qn,
          Wh: Rn,
          ih: Sn,
          Dh: Tn,
          Yf: Un,
          md: Ua,
          Df: z,
          ig: c,
          Za: new kf(m.Za),
          ae: new kf(zf),
          va: new kf(vf),
          Zb: new kf(yf),
          Yh: new kf(xf),
          Te: new kf($f),
          duration: la,
          dg: new kf("4"),
          I: Za.I,
          D: Za.D,
          F: Za.F,
          A: Li.A,
          ci: Li.A.i(
            R(function (p) {
              return p.Qh;
            })
          ),
          N: Za.N,
          G: Za.G,
          J: Za.J,
          C: Za.C,
          M: Za.M,
          Ih: ea.sf,
          ai: new kf(0),
          ad: G.ad,
          ed: K.ed,
          Fh: t,
          Nf: x,
        });
      },
      tf(a, g, e)
    );
  }
  function ln(a, b) {
    if (!b) throw Error("sa`" + a);
    if (typeof b !== "string" && !(b instanceof String)) throw Error("ta`" + a);
    if (b.trim() === "") throw Error("ua`" + a);
  }
  function mn(a) {
    if (!a) throw Error("xa`functionToExecute");
  }
  function nn(a, b) {
    if (b == null) throw Error("va`" + a);
    if (typeof b !== "number" || isNaN(b)) throw Error("wa`" + a);
    if (b < 0) throw Error("ya`" + a);
  }
  function on() {
    return /\d+\.\d+\.\d+(-.*)?/.test("1.6.11-google_20261022");
  }
  function pn() {
    for (var a = ["1", "6", "11"], b = ["1", "0", "3"], c = 0; c < 3; c++) {
      var d = parseInt(a[c], 10),
        e = parseInt(b[c], 10);
      if (d > e) break;
      else if (d < e) return !1;
    }
    return !0;
  }
  var qn = function (a, b, c, d) {
      this.be = a;
      this.method = b;
      this.version = c;
      this.args = d;
    },
    rn = function (a) {
      return (
        !!a &&
        a.omid_message_guid !== void 0 &&
        a.omid_message_method !== void 0 &&
        a.omid_message_version !== void 0 &&
        typeof a.omid_message_guid === "string" &&
        typeof a.omid_message_method === "string" &&
        typeof a.omid_message_version === "string" &&
        (a.omid_message_args === void 0 || a.omid_message_args !== void 0)
      );
    },
    sn = function (a) {
      return new qn(
        a.omid_message_guid,
        a.omid_message_method,
        a.omid_message_version,
        a.omid_message_args
      );
    };
  qn.prototype.cc = function () {
    var a = {};
    a =
      ((a.omid_message_guid = this.be),
      (a.omid_message_method = this.method),
      (a.omid_message_version = this.version),
      a);
    this.args !== void 0 && (a.omid_message_args = this.args);
    return a;
  };
  var tn = function (a) {
    this.to = a;
  };
  tn.prototype.cc = function () {
    return JSON.stringify(void 0);
  };
  function un(a, b) {
    try {
      return a.frames && !!a.frames[b];
    } catch (c) {
      return !1;
    }
  }
  var vn = function (a) {
      return [
        "omid_v1_present",
        "omid_v1_present_web",
        "omid_v1_present_app",
      ].some(function (b) {
        return un(a, b);
      });
    },
    wn = function (a) {
      var b = A(Object.values($d)),
        c = b.next();
      try {
        for (; !c.done; c = b.next()) {
          var d = c.value,
            e = {};
          var g = ((e.app = "omid_v1_present_app"),
          (e.web = "omid_v1_present_web"),
          e)[d];
          if (un(a, g)) return d;
        }
      } finally {
        xa(b, c);
      }
      return null;
    };
  function xn(a, b) {
    return a && (a[b] || (a[b] = {}));
  }
  function yn() {
    return (
      typeof crypto !== "undefined" &&
      typeof crypto.getRandomValues === "function"
    );
  }
  function zn() {
    var a = new Uint8Array(16);
    crypto.getRandomValues(a);
    a[6] = (a[6] & 15) | 64;
    a[8] = (a[8] & 63) | 128;
    for (var b = [], c = 0; c < 16; c++)
      b.push(a[c].toString(16).padStart(2, "0"));
    return (
      b[0] +
      b[1] +
      b[2] +
      b[3] +
      "-" +
      b[4] +
      b[5] +
      "-" +
      b[6] +
      b[7] +
      "-" +
      b[8] +
      b[9] +
      "-" +
      b[10] +
      b[11] +
      b[12] +
      b[13] +
      b[14] +
      b[15]
    );
  }
  function An() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
      /[xy]/g,
      function (a) {
        var b = (Math.random() * 16) | 0;
        return a === "y" ? ((b & 3) | 8).toString(16) : b.toString(16);
      }
    );
  }
  function Bn() {
    var a = F.apply(0, arguments);
    Cn(
      function () {
        throw new (Function.prototype.bind.apply(
          Error,
          [null, "Could not complete the test successfully - "].concat(sa(a))
        ))();
      },
      function () {
        return console.error.apply(console, sa(a));
      }
    );
  }
  function Cn(a, b) {
    typeof jasmine !== "undefined" && jasmine
      ? a()
      : typeof console !== "undefined" && console && console.error && b();
  }
  var Dn = (function () {
    if (typeof omidGlobal !== "undefined" && omidGlobal) return omidGlobal;
    if (typeof global !== "undefined" && global) return global;
    if (typeof window !== "undefined" && window) return window;
    if (typeof globalThis !== "undefined" && globalThis) return globalThis;
    var a = Function("return this")();
    if (a) return a;
    throw Error("za");
  })();
  var En = function (a) {
    this.to = a;
    this.handleExportedMessage = En.prototype.fg.bind(this);
  };
  v(En, tn);
  En.prototype.sendMessage = function (a, b) {
    b = b === void 0 ? this.to : b;
    if (!b) throw Error("Aa");
    b.handleExportedMessage(a.cc(), this);
  };
  En.prototype.fg = function (a, b) {
    if (rn(a) && this.onMessage) this.onMessage(sn(a), b);
  };
  function Fn(a) {
    return a != null && typeof a.top !== "undefined" && a.top != null;
  }
  function Gn(a) {
    if (a === Dn) return !1;
    try {
      if (typeof a.location.hostname === "undefined") return !0;
    } catch (b) {
      return !0;
    }
    return !1;
  }
  function Hn() {
    var a;
    typeof a === "undefined" &&
      typeof window !== "undefined" &&
      window &&
      (a = window);
    return Fn(a) ? a : Dn;
  }
  var In = function (a, b) {
    this.to = b = b === void 0 ? Dn : b;
    var c = this;
    a.addEventListener("message", function (d) {
      if (typeof d.data === "object") {
        var e = d.data;
        if (rn(e) && d.source && c.onMessage) c.onMessage(sn(e), d.source);
      }
    });
  };
  v(In, tn);
  In.prototype.sendMessage = function (a, b) {
    b = b === void 0 ? this.to : b;
    if (!b) throw Error("Aa");
    b.postMessage(a.cc(), "*");
  };
  var Jn = ["omid", "v1_VerificationServiceCommunication"],
    Xn = ["omidVerificationProperties", "serviceWindow"];
  function Yn(a, b) {
    return b.reduce(function (c, d) {
      return c && c[d];
    }, a);
  }
  var Zn = function (a) {
    if (!a) {
      var b = Hn();
      var c = c === void 0 ? vn : c;
      var d = [],
        e = Yn(b, Xn);
      e && d.push(e);
      d.push(Fn(b) ? b.top : Dn);
      a: {
        d = A(d);
        e = d.next();
        try {
          for (; !e.done; e = d.next()) {
            b: {
              var g = b,
                f = e.value,
                h = c;
              if (!Gn(f))
                try {
                  var k = Yn(f, Jn);
                  if (k) {
                    var l = new En(k);
                    break b;
                  }
                } catch (m) {}
              l = h(f) ? new In(g, f) : null;
            }
            if ((g = l)) {
              a = g;
              break a;
            }
          }
        } finally {
          xa(d, e);
        }
        a = null;
      }
    }
    if ((this.qb = a)) this.qb.onMessage = this.gg.bind(this);
    else if (
      (c =
        (c = Dn.omid3p) &&
        typeof c.registerSessionObserver === "function" &&
        typeof c.addEventListener === "function"
          ? c
          : null)
    )
      this.Ab = c;
    this.yh = this.zh = 0;
    this.yc = {};
    this.Rc = [];
    (this.eb = (c = Dn.omidVerificationProperties) ? c.injectionId : void 0) ||
      (yn() ? zn() : An());
  };
  Zn.prototype.Ra = function () {
    var a = Hn();
    var b =
      (b = Dn.omidVerificationProperties) && b.injectionSource
        ? b.injectionSource
        : void 0;
    return (b || wn(a) || wn(Fn(a) ? a.top : Dn)) !== "web" || this.eb
      ? !(!this.qb && !this.Ab)
      : !1;
  };
  var ie = function (a, b, c) {
    mn(b);
    a.Ab
      ? a.Ab.registerSessionObserver(b, c, a.eb)
      : a.lb("addSessionListener", b, c, a.eb);
  };
  Zn.prototype.addEventListener = function (a, b) {
    ln("eventType", a);
    mn(b);
    this.Ab
      ? this.Ab.addEventListener(a, b, this.eb)
      : this.lb("addEventListener", b, a, this.eb);
  };
  var Fe = function (a, b, c, d) {
      ln("url", b);
      Dn.document && Dn.document.createElement
        ? $n(a, b, c, d)
        : a.lb(
            "sendUrl",
            function (e) {
              e && c ? c() : !e && d && d();
            },
            b
          );
    },
    $n = function (a, b, c, d) {
      var e = Dn.document.createElement("img");
      a.Rc.push(e);
      var g = function (f) {
        var h = a.Rc.indexOf(e);
        h >= 0 && a.Rc.splice(h, 1);
        f && f();
      };
      e.addEventListener("load", g.bind(a, c));
      e.addEventListener("error", g.bind(a, d));
      e.src = b;
    };
  Zn.prototype.setTimeout = function (a, b) {
    mn(a);
    nn("timeInMillis", b);
    if (ao()) return Dn.setTimeout(a, b);
    var c = this.zh++;
    this.lb("setTimeout", a, c, b);
    return c;
  };
  Zn.prototype.clearTimeout = function (a) {
    nn("timeoutId", a);
    ao() ? Dn.clearTimeout(a) : this.Fe("clearTimeout", a);
  };
  Zn.prototype.setInterval = function (a, b) {
    mn(a);
    nn("timeInMillis", b);
    if (bo()) return Dn.setInterval(a, b);
    var c = this.yh++;
    this.lb("setInterval", a, c, b);
    return c;
  };
  Zn.prototype.clearInterval = function (a) {
    nn("intervalId", a);
    bo() ? Dn.clearInterval(a) : this.Fe("clearInterval", a);
  };
  var ao = function () {
      return (
        typeof Dn.setTimeout === "function" &&
        typeof Dn.clearTimeout === "function"
      );
    },
    bo = function () {
      return (
        typeof Dn.setInterval === "function" &&
        typeof Dn.clearInterval === "function"
      );
    };
  Zn.prototype.gg = function (a) {
    var b = a.method,
      c = a.be;
    a = a.args;
    if (b === "response" && this.yc[c]) {
      var d =
        on() && pn()
          ? a
            ? a
            : []
          : a && typeof a === "string"
          ? JSON.parse(a)
          : [];
      this.yc[c].apply(this, d);
    }
    b === "error" && window.console && Bn(a);
  };
  Zn.prototype.Fe = function (a) {
    this.lb.apply(this, [a, null].concat(sa(F.apply(1, arguments))));
  };
  Zn.prototype.lb = function (a, b) {
    var c = F.apply(2, arguments);
    if (this.qb) {
      var d = yn() ? zn() : An();
      b && (this.yc[d] = b);
      var e = "VerificationService." + a;
      c = on() && pn() ? c : JSON.stringify(c);
      this.qb.sendMessage(new qn(d, e, "1.6.11-google_20261022", c));
    }
  };
  var co = void 0;
  if (
    (co =
      co === void 0
        ? typeof omidExports === "undefined"
          ? null
          : omidExports
        : co)
  ) {
    var eo = ["OmidVerificationClient"];
    eo.slice(0, eo.length - 1).reduce(xn, co)[eo[eo.length - 1]] = Zn;
  }
  var fo = new Zn();
  (function (a, b) {
    var c = new dn(),
      d = Symbol("impression"),
      e = new hn(c, b === void 0 ? 0.01 : b, { de: d });
    e.start(a);
    var g = [],
      f = function () {};
    c.start(
      a,
      function (h, k, l) {
        kn(e, h, k, l, f);
        var m;
        a.Ta !== null &&
          ((m = a.Ta) == null ? 0 : m.validate()) &&
          g.push(
            a.Ta.Sc.subscribe(function () {
              e.handleEvent(h, d, {});
            })
          );
      },
      function () {},
      function () {
        e.dispose();
        g.forEach(function (h) {
          h.unsubscribe();
        });
      }
    );
    return e.Hg;
  })({ Ta: new ef(fo, "doubleclickbygoogle.com-omid-video") }).subscribe();
}.call(this));
