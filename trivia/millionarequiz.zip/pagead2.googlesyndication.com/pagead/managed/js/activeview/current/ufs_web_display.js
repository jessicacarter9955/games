(function () {
  var n,
    aa =
      typeof Object.create == "function"
        ? Object.create
        : function (a) {
            var b = function () {};
            b.prototype = a;
            return new b();
          },
    ba =
      typeof Object.defineProperties == "function"
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          },
    ca = function (a) {
      a = [
        "object" == typeof globalThis && globalThis,
        a,
        "object" == typeof window && window,
        "object" == typeof self && self,
        "object" == typeof global && global,
      ];
      for (var b = 0; b < a.length; ++b) {
        var c = a[b];
        if (c && c.Math == Math) return c;
      }
      throw Error("a");
    },
    da = ca(this),
    ea =
      "Int8 Uint8 Uint8Clamped Int16 Uint16 Int32 Uint32 Float32 Float64".split(
        " "
      );
  da.BigInt64Array && (ea.push("BigInt64"), ea.push("BigUint64"));
  var ha = function (a, b) {
      if (b)
        for (var c = 0; c < ea.length; c++)
          fa(ea[c] + "Array.prototype." + a, b);
    },
    p = function (a, b) {
      b && fa(a, b);
    },
    fa = function (a, b) {
      var c = da;
      a = a.split(".");
      for (var d = 0; d < a.length - 1; d++) {
        var e = a[d];
        if (!(e in c)) return;
        c = c[e];
      }
      a = a[a.length - 1];
      d = c[a];
      b = b(d);
      b != d &&
        b != null &&
        ba(c, a, { configurable: !0, writable: !0, value: b });
    },
    ia;
  if (typeof Object.setPrototypeOf == "function") ia = Object.setPrototypeOf;
  else {
    var ka;
    a: {
      var la = { a: !0 },
        ma = {};
      try {
        ma.__proto__ = la;
        ka = ma.a;
        break a;
      } catch (a) {}
      ka = !1;
    }
    ia = ka
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError("b`" + a);
          return a;
        }
      : null;
  }
  var na = ia,
    q = function (a, b) {
      a.prototype = aa(b.prototype);
      a.prototype.constructor = a;
      if (na) na(a, b);
      else
        for (var c in b)
          if (c != "prototype")
            if (Object.defineProperties) {
              var d = Object.getOwnPropertyDescriptor(b, c);
              d && Object.defineProperty(a, c, d);
            } else a[c] = b[c];
      a.rj = b.prototype;
    },
    oa = function (a) {
      var b = 0;
      return function () {
        return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
      };
    },
    x = function (a) {
      var b =
        typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
      if (b) return b.call(a);
      if (typeof a.length == "number") return { next: oa(a) };
      throw Error("c`" + String(a));
    },
    y = function (a) {
      if (!(a instanceof Array)) {
        a = x(a);
        for (var b, c = []; !(b = a.next()).done; ) c.push(b.value);
        a = c;
      }
      return a;
    },
    qa = function (a) {
      return pa(a, a);
    },
    pa = function (a, b) {
      a.raw = b;
      Object.freeze && (Object.freeze(a), Object.freeze(b));
      return a;
    },
    ra = function (a, b) {
      var c;
      b && !b.done && (c = a["return"]) && c.call(a);
    },
    sa = function (a, b) {
      return Object.prototype.hasOwnProperty.call(a, b);
    },
    z =
      typeof Object.assign == "function"
        ? Object.assign
        : function (a, b) {
            if (a == null) throw new TypeError("d");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
              var d = arguments[c];
              if (d) for (var e in d) sa(d, e) && (a[e] = d[e]);
            }
            return a;
          },
    ta = function (a) {
      if (!(a instanceof Object)) throw new TypeError("e`" + a);
    },
    E = function () {
      this.Oc = !1;
      this.Ea = null;
      this.V = void 0;
      this.u = 1;
      this.Ha = this.ob = 0;
      this.Ae = this.X = null;
    };
  E.prototype.Va = function () {
    if (this.Oc) throw new TypeError("f");
    this.Oc = !0;
  };
  E.prototype.Xc = function (a) {
    this.V = a;
  };
  E.prototype.Pb = function (a) {
    this.X = { ag: a, xg: !0 };
    this.u = this.ob || this.Ha;
  };
  E.prototype.getNextAddressJsc = function () {
    return this.u;
  };
  E.prototype.getYieldResultJsc = function () {
    return this.V;
  };
  E.prototype.return = function (a) {
    this.X = { return: a };
    this.u = this.Ha;
  };
  E.prototype["return"] = E.prototype.return;
  E.prototype.zi = function (a) {
    this.X = { ba: a };
    this.Ha < a ? ((this.u = a), (this.X = null)) : (this.u = this.Ha);
  };
  E.prototype.jumpThroughFinallyBlocks = E.prototype.zi;
  E.prototype.yield = function (a, b) {
    this.u = b;
    return { value: a };
  };
  E.prototype.yield = E.prototype.yield;
  E.prototype.Cj = function (a, b) {
    a = x(a);
    var c = a.next();
    ta(c);
    if (c.done) (this.V = c.value), (this.u = b);
    else return (this.Ea = a), this.yield(c.value, b);
  };
  E.prototype.yieldAll = E.prototype.Cj;
  E.prototype.ba = function (a) {
    this.u = a;
  };
  E.prototype.jumpTo = E.prototype.ba;
  E.prototype.Db = function () {
    this.u = 0;
  };
  E.prototype.jumpToEnd = E.prototype.Db;
  E.prototype.Kb = function (a, b) {
    this.ob = a;
    b != void 0 && (this.Ha = b);
  };
  E.prototype.setCatchFinallyBlocks = E.prototype.Kb;
  E.prototype.jf = function (a) {
    this.ob = 0;
    this.Ha = a || 0;
  };
  E.prototype.setFinallyBlock = E.prototype.jf;
  E.prototype.Pc = function (a, b) {
    this.u = a;
    this.ob = b || 0;
  };
  E.prototype.leaveTryBlock = E.prototype.Pc;
  E.prototype.rb = function (a) {
    this.ob = a || 0;
    a = this.X.ag;
    this.X = null;
    return a;
  };
  E.prototype.enterCatchBlock = E.prototype.rb;
  E.prototype.zd = function (a, b, c) {
    c ? (this.Ae[c] = this.X) : (this.Ae = [this.X]);
    this.ob = a || 0;
    this.Ha = b || 0;
    this.X = null;
  };
  E.prototype.enterFinallyBlock = E.prototype.zd;
  E.prototype.Ld = function (a, b) {
    b = this.Ae.splice(b || 0)[0];
    (b = this.X = this.X || b)
      ? b.xg
        ? (this.u = this.ob || this.Ha)
        : b.ba != void 0 && this.Ha < b.ba
        ? ((this.u = b.ba), (this.X = null))
        : (this.u = this.Ha)
      : (this.u = a);
  };
  E.prototype.leaveFinallyBlock = E.prototype.Ld;
  E.prototype.forIn = function (a) {
    return new ua(a);
  };
  E.prototype.forIn = E.prototype.forIn;
  var ua = function (a) {
    this.Qi = a;
    this.Rd = [];
    for (var b in a) this.Rd.push(b);
    this.Rd.reverse();
  };
  ua.prototype.ai = function () {
    for (; this.Rd.length > 0; ) {
      var a = this.Rd.pop();
      if (a in this.Qi) return a;
    }
    return null;
  };
  ua.prototype.getNext = ua.prototype.ai;
  var va = function (a) {
    this.A = new E();
    this.Yi = a;
  };
  va.prototype.Xc = function (a) {
    this.A.Va();
    if (this.A.Ea) return wa(this, this.A.Ea.next, a, this.A.Xc);
    this.A.Xc(a);
    return xa(this);
  };
  var ya = function (a, b) {
    a.A.Va();
    var c = a.A.Ea;
    if (c)
      return wa(
        a,
        "return" in c
          ? c["return"]
          : function (d) {
              return { value: d, done: !0 };
            },
        b,
        a.A.return
      );
    a.A.return(b);
    return xa(a);
  };
  va.prototype.Pb = function (a) {
    this.A.Va();
    if (this.A.Ea) {
      var b = this.A.Ea["throw"];
      if (b) return wa(this, b, a, this.A.Xc);
      a = this.A.Ea;
      this.A.Ea = null;
      try {
        if (a["return"]) {
          var c = a["return"]();
          ta(c);
        }
        this.A.Pb(new TypeError("g"));
      } catch (d) {
        this.A.Pb(d);
      }
      return xa(this);
    }
    this.A.Pb(a);
    return xa(this);
  };
  var wa = function (a, b, c, d) {
      try {
        var e = b.call(a.A.Ea, c);
        ta(e);
        if (!e.done) return (a.A.Oc = !1), e;
        var f = e.value;
      } catch (g) {
        return (a.A.Ea = null), a.A.Pb(g), xa(a);
      }
      a.A.Ea = null;
      d.call(a.A, f);
      return xa(a);
    },
    xa = function (a) {
      for (; a.A.u; )
        try {
          var b = a.Yi(a.A);
          if (b) return (a.A.Oc = !1), { value: b.value, done: !1 };
        } catch (c) {
          (a.A.V = void 0), a.A.Pb(c);
        }
      a.A.Oc = !1;
      if (a.A.X) {
        b = a.A.X;
        a.A.X = null;
        if (b.xg) throw b.ag;
        return { value: b.return, done: !0 };
      }
      return { value: void 0, done: !0 };
    },
    za = function (a) {
      this.next = function (b) {
        return a.Xc(b);
      };
      this.throw = function (b) {
        return a.Pb(b);
      };
      this.return = function (b) {
        return ya(a, b);
      };
      this[Symbol.iterator] = function () {
        return this;
      };
    },
    Aa = function (a) {
      function b(d) {
        return a.next(d);
      }
      function c(d) {
        return a.throw(d);
      }
      return new Promise(function (d, e) {
        function f(g) {
          g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e);
        }
        f(a.next());
      });
    },
    Ba = function (a) {
      return Aa(new za(new va(a)));
    };
  p("Symbol", function (a) {
    if (a) return a;
    var b = function (f, g) {
      this.rh = f;
      ba(this, "description", { configurable: !0, writable: !0, value: g });
    };
    b.prototype.toString = function () {
      return this.rh;
    };
    var c = "jscomp_symbol_" + ((Math.random() * 1e9) >>> 0) + "_",
      d = 0,
      e = function (f) {
        if (this instanceof e) throw new TypeError("h");
        return new b(c + (f || "") + "_" + d++, f);
      };
    return e;
  });
  p("Symbol.iterator", function (a) {
    if (a) return a;
    a = Symbol("Symbol.iterator");
    ba(Array.prototype, a, {
      configurable: !0,
      writable: !0,
      value: function () {
        return Ca(oa(this));
      },
    });
    return a;
  });
  p("Symbol.asyncIterator", function (a) {
    return a ? a : Symbol("Symbol.asyncIterator");
  });
  p("Symbol.toStringTag", function (a) {
    return a ? a : Symbol("Symbol.toStringTag");
  });
  var Ca = function (a) {
      var b =
          (typeof Iterator != "undefined" &&
          Iterator.prototype &&
          !Iterator.prototype.next
            ? Iterator.prototype
            : null) || Object.prototype,
        c = aa(b);
      c.next = a;
      b[Symbol.iterator] ||
        (c[Symbol.iterator] = function () {
          return this;
        });
      return c;
    },
    Da = function (a) {
      function b(c) {
        return Promise.resolve(c.value).then(function (d) {
          return { value: d, done: !!c.done };
        });
      }
      this[Symbol.asyncIterator] = function () {
        return this;
      };
      this[Symbol.iterator] = function () {
        return a;
      };
      this.next = function (c) {
        return new Promise(function (d) {
          d(a.next(c));
        }).then(b);
      };
      this["throw"] = function (c) {
        return new Promise(function (d, e) {
          var f = a["throw"];
          f !== void 0
            ? d(f.call(a, c))
            : ((d = a["return"]),
              d !== void 0 && d.call(a),
              e(new TypeError("i")));
        }).then(b);
      };
      a["return"] !== void 0 &&
        (this["return"] = function (c) {
          return new Promise(function (d) {
            d(a["return"](c));
          }).then(b);
        });
    },
    F = function () {
      for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
        b[c - a] = arguments[c];
      return b;
    };
  p("globalThis", function (a) {
    return a || da;
  });
  p("Reflect.setPrototypeOf", function (a) {
    return a
      ? a
      : na
      ? function (b, c) {
          try {
            return na(b, c), !0;
          } catch (d) {
            return !1;
          }
        }
      : null;
  });
  p("Promise", function (a) {
    function b() {
      this.Xa = null;
    }
    function c(g) {
      return g instanceof e
        ? g
        : new e(function (h) {
            h(g);
          });
    }
    if (a) return a;
    b.prototype.Mf = function (g) {
      if (this.Xa == null) {
        this.Xa = [];
        var h = this;
        this.Nf(function () {
          h.Uh();
        });
      }
      this.Xa.push(g);
    };
    var d = da.setTimeout;
    b.prototype.Nf = function (g) {
      d(g, 0);
    };
    b.prototype.Uh = function () {
      for (; this.Xa && this.Xa.length; ) {
        var g = this.Xa;
        this.Xa = [];
        for (var h = 0; h < g.length; ++h) {
          var k = g[h];
          g[h] = null;
          try {
            k();
          } catch (l) {
            this.Ah(l);
          }
        }
      }
      this.Xa = null;
    };
    b.prototype.Ah = function (g) {
      this.Nf(function () {
        throw g;
      });
    };
    var e = function (g) {
      this.ta = 0;
      this.ed = void 0;
      this.oc = [];
      this.Cg = !1;
      var h = this.ue();
      try {
        g(h.resolve, h.reject);
      } catch (k) {
        h.reject(k);
      }
    };
    e.prototype.ue = function () {
      function g(l) {
        return function (m) {
          k || ((k = !0), l.call(h, m));
        };
      }
      var h = this,
        k = !1;
      return { resolve: g(this.gj), reject: g(this.df) };
    };
    e.prototype.gj = function (g) {
      if (g === this) this.df(new TypeError("j"));
      else if (g instanceof e) this.lj(g);
      else {
        a: switch (typeof g) {
          case "object":
            var h = g != null;
            break a;
          case "function":
            h = !0;
            break a;
          default:
            h = !1;
        }
        h ? this.fj(g) : this.dg(g);
      }
    };
    e.prototype.fj = function (g) {
      var h = void 0;
      try {
        h = g.then;
      } catch (k) {
        this.df(k);
        return;
      }
      typeof h == "function" ? this.mj(h, g) : this.dg(g);
    };
    e.prototype.df = function (g) {
      this.Wg(2, g);
    };
    e.prototype.dg = function (g) {
      this.Wg(1, g);
    };
    e.prototype.Wg = function (g, h) {
      if (this.ta != 0) throw Error("k`" + g + "`" + h + "`" + this.ta);
      this.ta = g;
      this.ed = h;
      this.ta === 2 && this.hj();
      this.Vh();
    };
    e.prototype.hj = function () {
      var g = this;
      d(function () {
        if (g.Oi()) {
          var h = da.console;
          typeof h !== "undefined" && h.error(g.ed);
        }
      }, 1);
    };
    e.prototype.Oi = function () {
      if (this.Cg) return !1;
      var g = da.CustomEvent,
        h = da.Event,
        k = da.dispatchEvent;
      if (typeof k === "undefined") return !0;
      typeof g === "function"
        ? (g = new g("unhandledrejection", { cancelable: !0 }))
        : typeof h === "function"
        ? (g = new h("unhandledrejection", { cancelable: !0 }))
        : ((g = da.document.createEvent("CustomEvent")),
          g.initCustomEvent("unhandledrejection", !1, !0, g));
      g.promise = this;
      g.reason = this.ed;
      return k(g);
    };
    e.prototype.Vh = function () {
      if (this.oc != null) {
        for (var g = 0; g < this.oc.length; ++g) f.Mf(this.oc[g]);
        this.oc = null;
      }
    };
    var f = new b();
    e.prototype.lj = function (g) {
      var h = this.ue();
      g.rd(h.resolve, h.reject);
    };
    e.prototype.mj = function (g, h) {
      var k = this.ue();
      try {
        g.call(h, k.resolve, k.reject);
      } catch (l) {
        k.reject(l);
      }
    };
    e.prototype.then = function (g, h) {
      function k(t, r) {
        return typeof t == "function"
          ? function (w) {
              try {
                l(t(w));
              } catch (v) {
                m(v);
              }
            }
          : r;
      }
      var l,
        m,
        u = new e(function (t, r) {
          l = t;
          m = r;
        });
      this.rd(k(g, l), k(h, m));
      return u;
    };
    e.prototype.catch = function (g) {
      return this.then(void 0, g);
    };
    e.prototype.rd = function (g, h) {
      function k() {
        switch (l.ta) {
          case 1:
            g(l.ed);
            break;
          case 2:
            h(l.ed);
            break;
          default:
            throw Error("l`" + l.ta);
        }
      }
      var l = this;
      this.oc == null ? f.Mf(k) : this.oc.push(k);
      this.Cg = !0;
    };
    e.resolve = c;
    e.reject = function (g) {
      return new e(function (h, k) {
        k(g);
      });
    };
    e.race = function (g) {
      return new e(function (h, k) {
        for (var l = x(g), m = l.next(); !m.done; m = l.next())
          c(m.value).rd(h, k);
      });
    };
    e.all = function (g) {
      var h = x(g),
        k = h.next();
      return k.done
        ? c([])
        : new e(function (l, m) {
            function u(w) {
              return function (v) {
                t[w] = v;
                r--;
                r == 0 && l(t);
              };
            }
            var t = [],
              r = 0;
            do
              t.push(void 0),
                r++,
                c(k.value).rd(u(t.length - 1), m),
                (k = h.next());
            while (!k.done);
          });
    };
    return e;
  });
  p("Object.setPrototypeOf", function (a) {
    return a || na;
  });
  p("Object.assign", function (a) {
    return a || z;
  });
  p("Symbol.dispose", function (a) {
    return a ? a : Symbol("Symbol.dispose");
  });
  p("Object.values", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) sa(b, d) && c.push(b[d]);
          return c;
        };
  });
  p("Iterator", function (a) {
    var b = Object.getPrototypeOf,
      c =
        typeof Symbol != "undefined" && Symbol.iterator && [][Symbol.iterator]
          ? [][Symbol.iterator]()
          : null;
    b = (c = c && b ? b(c) : null) && b ? b(c) : null;
    b === Object.prototype && (b = null);
    if (a && b && a.prototype === b) return a;
    var d = function () {
      if (!(this instanceof d) || this.constructor === d)
        throw new TypeError("m");
    };
    b && (d.prototype = b);
    ba(d.prototype, "constructor", {
      configurable: !0,
      writable: !0,
      value: d,
    });
    d.prototype[Symbol.iterator] ||
      (d.prototype[Symbol.iterator] = function () {
        return this;
      });
    return d;
  });
  var Ea = function (a) {
      if (Object(a) !== a) throw new TypeError("n");
      return a;
    },
    Fa = function (a) {
      try {
        var b = a["return"];
        typeof b == "function" && b.call(a);
      } catch (c) {}
    },
    Ga = function (a, b) {
      b == null && (b = !0);
      return { value: a, done: b };
    },
    Ha = null,
    Ia = function (a, b) {
      var c = Ha;
      if (!c) {
        var d = function (e, f) {
          if (!e || e.jj !== e) throw new TypeError("p");
          var g = e.ta;
          if (g === 3) throw new TypeError("f");
          if (g != 4) {
            e.ta = f && g == 1 ? 4 : 3;
            try {
              if (f) {
                var h = e.Eg,
                  k = h["return"];
                if (k != null) {
                  if (typeof k != "function") throw new TypeError("o");
                  Ea(k.call(h));
                }
              } else {
                var l = e.Yg();
                if (l) return (e.ta = 2), l;
              }
            } finally {
              e.ta != 2 && ((e.ta = 4), (e.Yg = e.Eg = null));
            }
          }
          return Ga();
        };
        c = Ha = aa(Iterator.prototype);
        c.next = function () {
          return d(this, !1);
        };
        c.return = function () {
          return d(this, !0);
        };
        c[Symbol.toStringTag] = "Iterator Helper";
      }
      c = aa(c);
      c.jj = c;
      c.ta = 1;
      c.Eg = a;
      c.Yg = b;
      return c;
    },
    Ja = function (a, b) {
      Ea(a);
      if (typeof b != "function") throw (Fa(a), new TypeError("q"));
    },
    Ka = function (a, b, c) {
      Ja(a, b);
      b = a.next;
      for (var d = 0, e; !(e = Ea(b.call(a))).done; ) {
        try {
          var f = c(e.value, d++);
        } catch (g) {
          try {
            ra(a, e);
          } catch (h) {}
          throw g;
        }
        if (f) {
          c = a["return"];
          c != null && Ea(c.call(a));
          break;
        }
      }
    };
  p("Iterator.prototype.some", function (a) {
    return (
      a ||
      function (b) {
        var c = !1;
        Ka(this, b, function (d, e) {
          return (c = !!b(d, e));
        });
        return c;
      }
    );
  });
  var La = function (a, b) {
    a instanceof String && (a += "");
    var c = 0,
      d = !1;
    return Ca(function () {
      if (!d && c < a.length) {
        var e = c++;
        return { value: b(e, a[e]), done: !1 };
      }
      d = !0;
      return { done: !0, value: void 0 };
    });
  };
  p("Array.prototype.keys", function (a) {
    return a
      ? a
      : function () {
          return La(this, function (b) {
            return b;
          });
        };
  });
  var Ma = function (a, b, c) {
    Ja(a, b);
    var d = a.next,
      e = 0;
    return Ia(a, function () {
      for (;;) {
        var f = Ea(d.call(a));
        if (f.done) break;
        f = f.value;
        try {
          var g = b(f, e++);
        } catch (h) {
          throw (Fa(a), h);
        }
        if (!c || g) return Ga(c ? f : g, !1);
      }
    });
  };
  p("Iterator.prototype.map", function (a) {
    return (
      a ||
      function (b) {
        return Ma(this, b, !1);
      }
    );
  });
  p("Iterator.prototype.filter", function (a) {
    return (
      a ||
      function (b) {
        return Ma(this, b, !0);
      }
    );
  });
  p("Iterator.prototype.every", function (a) {
    return (
      a ||
      function (b) {
        var c = !0;
        Ka(this, b, function (d, e) {
          return !(c = !!b(d, e));
        });
        return c;
      }
    );
  });
  p("Iterator.prototype.forEach", function (a) {
    return (
      a ||
      function (b) {
        Ka(this, b, function (c, d) {
          b(c, d);
        });
      }
    );
  });
  p("WeakMap", function (a) {
    function b() {}
    function c(k) {
      var l = typeof k;
      return (l === "object" && k !== null) || l === "function";
    }
    function d(k) {
      if (!sa(k, f)) {
        var l = new b();
        ba(k, f, { value: l });
      }
    }
    function e(k) {
      var l = Object[k];
      l &&
        (Object[k] = function (m) {
          if (m instanceof b) return m;
          Object.isExtensible(m) && d(m);
          return l(m);
        });
    }
    if (
      (function () {
        if (!a || !Object.seal) return !1;
        try {
          var k = Object.seal({}),
            l = Object.seal({}),
            m = new a([
              [k, 2],
              [l, 3],
            ]);
          if (m.get(k) != 2 || m.get(l) != 3) return !1;
          m.delete(k);
          m.set(l, 4);
          return !m.has(k) && m.get(l) == 4;
        } catch (u) {
          return !1;
        }
      })()
    )
      return a;
    var f = "$jscomp_hidden_" + Math.random();
    e("freeze");
    e("preventExtensions");
    e("seal");
    var g = 0,
      h = function (k) {
        this.Nc = (g += Math.random() + 1).toString();
        if (k) {
          k = x(k);
          for (var l; !(l = k.next()).done; )
            (l = l.value), this.set(l[0], l[1]);
        }
      };
    h.prototype.set = function (k, l) {
      if (!c(k)) throw Error("r");
      d(k);
      if (!sa(k, f)) throw Error("s`" + k);
      k[f][this.Nc] = l;
      return this;
    };
    h.prototype.get = function (k) {
      return c(k) && sa(k, f) ? k[f][this.Nc] : void 0;
    };
    h.prototype.has = function (k) {
      return c(k) && sa(k, f) && sa(k[f], this.Nc);
    };
    h.prototype.delete = function (k) {
      return c(k) && sa(k, f) && sa(k[f], this.Nc) ? delete k[f][this.Nc] : !1;
    };
    return h;
  });
  p("Map", function (a) {
    if (
      (function () {
        if (
          !a ||
          typeof a != "function" ||
          !a.prototype.entries ||
          typeof Object.seal != "function"
        )
          return !1;
        try {
          var h = Object.seal({ x: 4 }),
            k = new a(x([[h, "s"]]));
          if (
            k.get(h) != "s" ||
            k.size != 1 ||
            k.get({ x: 4 }) ||
            k.set({ x: 4 }, "t") != k ||
            k.size != 2
          )
            return !1;
          var l = k.entries(),
            m = l.next();
          if (m.done || m.value[0] != h || m.value[1] != "s") return !1;
          m = l.next();
          return !(
            m.done ||
            m.value[0].x != 4 ||
            m.value[1] != "t" ||
            !l.next().done
          );
        } catch (u) {
          return !1;
        }
      })()
    )
      return a;
    var b = new WeakMap(),
      c = function (h) {
        this[0] = {};
        this[1] = f();
        this.size = 0;
        if (h) {
          h = x(h);
          for (var k; !(k = h.next()).done; )
            (k = k.value), this.set(k[0], k[1]);
        }
      };
    c.prototype.set = function (h, k) {
      h = h === 0 ? 0 : h;
      var l = d(this, h);
      l.list || (l.list = this[0][l.id] = []);
      l.entry
        ? (l.entry.value = k)
        : ((l.entry = {
            next: this[1],
            Ua: this[1].Ua,
            head: this[1],
            key: h,
            value: k,
          }),
          l.list.push(l.entry),
          (this[1].Ua.next = l.entry),
          (this[1].Ua = l.entry),
          this.size++);
      return this;
    };
    c.prototype.delete = function (h) {
      h = d(this, h);
      return h.entry && h.list
        ? (h.list.splice(h.index, 1),
          h.list.length || delete this[0][h.id],
          (h.entry.Ua.next = h.entry.next),
          (h.entry.next.Ua = h.entry.Ua),
          (h.entry.head = null),
          this.size--,
          !0)
        : !1;
    };
    c.prototype.clear = function () {
      this[0] = {};
      this[1] = this[1].Ua = f();
      this.size = 0;
    };
    c.prototype.has = function (h) {
      return !!d(this, h).entry;
    };
    c.prototype.get = function (h) {
      return (h = d(this, h).entry) && h.value;
    };
    c.prototype.entries = function () {
      return e(this, function (h) {
        return [h.key, h.value];
      });
    };
    c.prototype.keys = function () {
      return e(this, function (h) {
        return h.key;
      });
    };
    c.prototype.values = function () {
      return e(this, function (h) {
        return h.value;
      });
    };
    c.prototype.forEach = function (h, k) {
      for (var l = this.entries(), m; !(m = l.next()).done; )
        (m = m.value), h.call(k, m[1], m[0], this);
    };
    c.prototype[Symbol.iterator] = c.prototype.entries;
    var d = function (h, k) {
        var l = k && typeof k;
        l == "object" || l == "function"
          ? b.has(k)
            ? (l = b.get(k))
            : ((l = "" + ++g), b.set(k, l))
          : (l = "p_" + k);
        var m = h[0][l];
        if (m && sa(h[0], l))
          for (h = 0; h < m.length; h++) {
            var u = m[h];
            if ((k !== k && u.key !== u.key) || k === u.key)
              return { id: l, list: m, index: h, entry: u };
          }
        return { id: l, list: m, index: -1, entry: void 0 };
      },
      e = function (h, k) {
        var l = h[1];
        return Ca(function () {
          if (l) {
            for (; l.head != h[1]; ) l = l.Ua;
            for (; l.next != l.head; )
              return (l = l.next), { done: !1, value: k(l) };
            l = null;
          }
          return { done: !0, value: void 0 };
        });
      },
      f = function () {
        var h = {};
        return (h.Ua = h.next = h.head = h);
      },
      g = 0;
    return c;
  });
  p("Set", function (a) {
    if (
      (function () {
        if (
          !a ||
          typeof a != "function" ||
          !a.prototype.entries ||
          typeof Object.seal != "function"
        )
          return !1;
        try {
          var c = Object.seal({ x: 4 }),
            d = new a(x([c]));
          if (
            !d.has(c) ||
            d.size != 1 ||
            d.add(c) != d ||
            d.size != 1 ||
            d.add({ x: 4 }) != d ||
            d.size != 2
          )
            return !1;
          var e = d.entries(),
            f = e.next();
          if (f.done || f.value[0] != c || f.value[1] != c) return !1;
          f = e.next();
          return f.done ||
            f.value[0] == c ||
            f.value[0].x != 4 ||
            f.value[1] != f.value[0]
            ? !1
            : e.next().done;
        } catch (g) {
          return !1;
        }
      })()
    )
      return a;
    var b = function (c) {
      this.Ka = new Map();
      if (c) {
        c = x(c);
        for (var d; !(d = c.next()).done; ) this.add(d.value);
      }
      this.size = this.Ka.size;
    };
    b.prototype.add = function (c) {
      c = c === 0 ? 0 : c;
      this.Ka.set(c, c);
      this.size = this.Ka.size;
      return this;
    };
    b.prototype.delete = function (c) {
      c = this.Ka.delete(c);
      this.size = this.Ka.size;
      return c;
    };
    b.prototype.clear = function () {
      this.Ka.clear();
      this.size = 0;
    };
    b.prototype.has = function (c) {
      return this.Ka.has(c);
    };
    b.prototype.entries = function () {
      return this.Ka.entries();
    };
    b.prototype.values = function () {
      return this.Ka.values();
    };
    b.prototype.keys = b.prototype.values;
    b.prototype[Symbol.iterator] = b.prototype.values;
    b.prototype.forEach = function (c, d) {
      var e = this;
      this.Ka.forEach(function (f) {
        return c.call(d, f, f, e);
      });
    };
    return b;
  });
  p("Array.prototype.entries", function (a) {
    return a
      ? a
      : function () {
          return La(this, function (b, c) {
            return [b, c];
          });
        };
  });
  var Na = function (a, b, c) {
    if (a == null) throw new TypeError("t`" + c);
    if (b instanceof RegExp) throw new TypeError("u`" + c);
    return a + "";
  };
  p("String.prototype.startsWith", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = Na(this, b, "startsWith");
          b += "";
          var e = d.length,
            f = b.length;
          c = Math.max(0, Math.min(c | 0, d.length));
          for (var g = 0; g < f && c < e; ) if (d[c++] != b[g++]) return !1;
          return g >= f;
        };
  });
  p("Number.isFinite", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b !== "number"
            ? !1
            : !isNaN(b) && b !== Infinity && b !== -Infinity;
        };
  });
  p("String.prototype.repeat", function (a) {
    return a
      ? a
      : function (b) {
          var c = Na(this, null, "repeat");
          if (b < 0 || b > 1342177279)
            throw new RangeError("Invalid count value");
          b |= 0;
          for (var d = ""; b; ) if ((b & 1 && (d += c), (b >>>= 1))) c += c;
          return d;
        };
  });
  p("Object.is", function (a) {
    return a
      ? a
      : function (b, c) {
          return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c;
        };
  });
  p("Array.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = this;
          d instanceof String && (d = String(d));
          var e = d.length;
          c = c || 0;
          for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
            var f = d[c];
            if (f === b || Object.is(f, b)) return !0;
          }
          return !1;
        };
  });
  p("String.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          return Na(this, b, "includes").indexOf(b, c || 0) !== -1;
        };
  });
  p("Iterator.prototype.reduce", function (a) {
    return (
      a ||
      function (b) {
        var c = arguments.length > 1,
          d = arguments[1];
        Ka(this, b, function (e, f) {
          c ? (d = b(d, e, f)) : ((c = !0), (d = e));
        });
        if (!c) throw new TypeError("v");
        return d;
      }
    );
  });
  p("Object.entries", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) sa(b, d) && c.push([d, b[d]]);
          return c;
        };
  });
  p("Array.from", function (a) {
    return a
      ? a
      : function (b, c, d) {
          c =
            c != null
              ? c
              : function (h) {
                  return h;
                };
          var e = [],
            f =
              typeof Symbol != "undefined" &&
              Symbol.iterator &&
              b[Symbol.iterator];
          if (typeof f == "function") {
            b = f.call(b);
            for (var g = 0; !(f = b.next()).done; )
              e.push(c.call(d, f.value, g++));
          } else
            for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
          return e;
        };
  });
  p("Math.trunc", function (a) {
    return a
      ? a
      : function (b) {
          b = Number(b);
          if (isNaN(b) || b === Infinity || b === -Infinity || b === 0)
            return b;
          var c = Math.floor(Math.abs(b));
          return b < 0 ? -c : c;
        };
  });
  p("Array.prototype.find", function (a) {
    return a
      ? a
      : function (b, c) {
          a: {
            var d = this;
            d instanceof String && (d = String(d));
            for (var e = d.length, f = 0; f < e; f++) {
              var g = d[f];
              if (b.call(c, g, f, d)) {
                b = g;
                break a;
              }
            }
            b = void 0;
          }
          return b;
        };
  });
  p("Iterator.prototype.find", function (a) {
    return (
      a ||
      function (b) {
        var c;
        Ka(this, b, function (d, e) {
          if (b(d, e)) return (c = d), !0;
        });
        return c;
      }
    );
  });
  p("String.prototype.padStart", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = Na(this, null, "padStart");
          b -= d.length;
          c = c !== void 0 ? String(c) : " ";
          return (
            (b > 0 && c
              ? c.repeat(Math.ceil(b / c.length)).substring(0, b)
              : "") + d
          );
        };
  });
  p("Number.MAX_SAFE_INTEGER", function () {
    return 9007199254740991;
  });
  p("Number.MIN_SAFE_INTEGER", function () {
    return -9007199254740991;
  });
  p("Number.isInteger", function (a) {
    return a
      ? a
      : function (b) {
          return Number.isFinite(b) ? b === Math.floor(b) : !1;
        };
  });
  p("Number.isSafeInteger", function (a) {
    return a
      ? a
      : function (b) {
          return Number.isInteger(b) && Math.abs(b) <= Number.MAX_SAFE_INTEGER;
        };
  });
  p("Math.log2", function (a) {
    return a
      ? a
      : function (b) {
          return Math.log(b) / Math.LN2;
        };
  });
  p("Number.isNaN", function (a) {
    return a
      ? a
      : function (b) {
          return typeof b === "number" && isNaN(b);
        };
  });
  p("Array.prototype.values", function (a) {
    return a
      ? a
      : function () {
          return La(this, function (b, c) {
            return c;
          });
        };
  });
  p("Array.prototype.fill", function (a) {
    return a
      ? a
      : function (b, c, d) {
          var e = this.length || 0;
          c < 0 && (c = Math.max(0, e + c));
          if (d == null || d > e) d = e;
          d = Number(d);
          d < 0 && (d = Math.max(0, e + d));
          for (c = Number(c || 0); c < d; c++) this[c] = b;
          return this;
        };
  });
  ha("fill", function (a) {
    return a ? a : Array.prototype.fill;
  });
  p("Array.prototype.flat", function (a) {
    return a
      ? a
      : function (b) {
          b = b === void 0 ? 1 : b;
          var c = [];
          Array.prototype.forEach.call(this, function (d) {
            Array.isArray(d) && b > 0
              ? ((d = Array.prototype.flat.call(d, b - 1)), c.push.apply(c, d))
              : c.push(d);
          });
          return c;
        };
  }); /*

 Copyright The Closure Library Authors.
 SPDX-License-Identifier: Apache-2.0
*/
  var Oa = this || self,
    Pa = function (a, b) {
      a: {
        var c = ["CLOSURE_FLAGS"];
        for (var d = Oa, e = 0; e < c.length; e++)
          if (((d = d[c[e]]), d == null)) {
            c = null;
            break a;
          }
        c = d;
      }
      a = c && c[a];
      return a != null ? a : b;
    },
    Qa = function (a) {
      var b = typeof a;
      return b != "object" ? b : a ? (Array.isArray(a) ? "array" : b) : "null";
    },
    Ra = function (a) {
      var b = Qa(a);
      return b == "array" || (b == "object" && typeof a.length == "number");
    },
    Sa = function (a) {
      var b = typeof a;
      return (b == "object" && a != null) || b == "function";
    },
    Va = function (a) {
      return a;
    },
    Wa = function (a, b) {
      function c() {}
      c.prototype = b.prototype;
      a.rj = b.prototype;
      a.prototype = new c();
      a.prototype.constructor = a;
      a.jk = function (d, e, f) {
        for (
          var g = Array(arguments.length - 2), h = 2;
          h < arguments.length;
          h++
        )
          g[h - 2] = arguments[h];
        return b.prototype[e].apply(d, g);
      };
    };
  var Xa = function () {
    this.rf = 0;
  };
  Xa.prototype.yc = function (a, b) {
    var c = this;
    return function () {
      var d = F.apply(0, arguments);
      c.rf = a;
      return b.apply(null, y(d));
    };
  };
  var Ya = function () {
    var a = {};
    this.Ma = ((a[3] = []), (a[2] = []), (a[1] = []), a);
    this.Re = !1;
  };
  da.Object.defineProperties(Ya.prototype, {
    Pg: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return Object.values(this.Ma).some(function (a) {
          return a.length > 0;
        });
      },
    },
  });
  var ab = function (a, b, c) {
      var d = $a(a, c);
      a.Ma[c].push(b);
      d && a.Ma[c].length === 1 && a.flush();
    },
    $a = function (a, b) {
      return Object.keys(a.Ma)
        .map(function (c) {
          return Number(c);
        })
        .filter(function (c) {
          return !isNaN(c) && c > b;
        })
        .every(function (c) {
          return a.Ma[c].length === 0;
        });
    };
  Ya.prototype.flush = function () {
    if (!this.Re) {
      this.Re = !0;
      try {
        for (
          ;
          Object.values(this.Ma).some(function (a) {
            return a.length > 0;
          });

        )
          bb(this, 3), bb(this, 2), bb(this, 1);
      } catch (a) {
        throw (
          (Object.values(this.Ma).forEach(function (b) {
            return void b.splice(0, b.length);
          }),
          a)
        );
      } finally {
        this.Re = !1;
      }
    }
  };
  var bb = function (a, b) {
    for (; $a(a, b) && a.Ma[b].length > 0; ) a.Ma[b][0](), a.Ma[b].shift();
  };
  function cb(a, b) {
    return a.toLowerCase().indexOf(b.toLowerCase()) != -1;
  } /*

 Copyright Google LLC
 SPDX-License-Identifier: Apache-2.0
*/
  var db = {};
  var gb = globalThis.trustedTypes,
    hb;
  function ib() {
    var a = null;
    if (!gb) return a;
    try {
      var b = function (c) {
        return c;
      };
      a = gb.createPolicy("goog#html", {
        createHTML: b,
        createScript: b,
        createScriptURL: b,
      });
    } catch (c) {
      throw c;
    }
    return a;
  }
  var jb = function (a) {
    if (db !== db) throw Error("w");
    this.Mg = a;
  };
  jb.prototype.toString = function () {
    return this.Mg + "";
  };
  function kb(a) {
    var b;
    hb === void 0 && (hb = ib());
    a = (b = hb) ? b.createScriptURL(a) : a;
    return new jb(a);
  }
  var lb = qa([""]),
    mb = pa(["\x00"], ["\\0"]),
    nb = pa(["\n"], ["\\n"]),
    ob = pa(["\x00"], ["\\u0000"]),
    pb = qa([""]),
    qb = pa(["\x00"], ["\\0"]),
    rb = pa(["\n"], ["\\n"]),
    sb = pa(["\x00"], ["\\u0000"]);
  function tb(a) {
    return Object.isFrozen(a) && Object.isFrozen(a.raw);
  }
  function ub(a) {
    return a.toString().indexOf("`") === -1;
  }
  var vb =
      ub(function (a) {
        return a(lb);
      }) ||
      ub(function (a) {
        return a(mb);
      }) ||
      ub(function (a) {
        return a(nb);
      }) ||
      ub(function (a) {
        return a(ob);
      }),
    wb = tb(pb) && tb(qb) && tb(rb) && tb(sb);
  var xb = function (a) {
    if (db !== db) throw Error("w");
    this.Xi = a;
  };
  xb.prototype.toString = function () {
    return this.Xi;
  };
  new xb("about:blank");
  new xb("about:invalid#zClosurez");
  var yb = [],
    zb = function (a) {
      console.warn("y`" + a);
    };
  yb.indexOf(zb) === -1 && yb.push(zb);
  function Bb(a, b) {
    if (Error.captureStackTrace) Error.captureStackTrace(this, Bb);
    else {
      var c = Error().stack;
      c && (this.stack = c);
    }
    a && (this.message = String(a));
    b !== void 0 && (this.cause = b);
  }
  Wa(Bb, Error);
  Bb.prototype.name = "CustomError";
  var Cb;
  function Db(a, b) {
    var c = Bb.call;
    a = a.split("%s");
    for (var d = "", e = a.length - 1, f = 0; f < e; f++)
      d += a[f] + (f < b.length ? b[f] : "%s");
    c.call(Bb, this, d + a[e]);
  }
  Wa(Db, Bb);
  Db.prototype.name = "AssertionError";
  function Eb(a, b, c, d) {
    var e = "Assertion failed";
    if (c) {
      e += ": " + c;
      var f = d;
    } else a && ((e += ": " + a), (f = b));
    throw new Db("" + e, f || []);
  }
  var H = function (a, b, c) {
      a || Eb("", null, b, Array.prototype.slice.call(arguments, 2));
      return a;
    },
    K = function (a, b, c) {
      a == null &&
        Eb(
          "Expected to exist: %s.",
          [a],
          b,
          Array.prototype.slice.call(arguments, 2)
        );
      return a;
    },
    Fb = function (a, b) {
      throw new Db(
        "Failure" + (a ? ": " + a : ""),
        Array.prototype.slice.call(arguments, 1)
      );
    },
    Gb = function (a, b, c) {
      typeof a !== "number" &&
        Eb(
          "Expected number but got %s: %s.",
          [Qa(a), a],
          b,
          Array.prototype.slice.call(arguments, 2)
        );
      return a;
    },
    Hb = function (a, b, c) {
      typeof a !== "string" &&
        Eb(
          "Expected string but got %s: %s.",
          [Qa(a), a],
          b,
          Array.prototype.slice.call(arguments, 2)
        );
    },
    Ib = function (a, b, c) {
      typeof a !== "function" &&
        Eb(
          "Expected function but got %s: %s.",
          [Qa(a), a],
          b,
          Array.prototype.slice.call(arguments, 2)
        );
    },
    Jb = function (a, b, c) {
      Sa(a) ||
        Eb(
          "Expected object but got %s: %s.",
          [Qa(a), a],
          b,
          Array.prototype.slice.call(arguments, 2)
        );
    },
    L = function (a, b, c) {
      Array.isArray(a) ||
        Eb(
          "Expected array but got %s: %s.",
          [Qa(a), a],
          b,
          Array.prototype.slice.call(arguments, 2)
        );
      return a;
    },
    Lb = function (a, b, c, d) {
      a instanceof b ||
        Eb(
          "Expected instanceof %s but got %s.",
          [Kb(b), Kb(a)],
          c,
          Array.prototype.slice.call(arguments, 3)
        );
      return a;
    };
  function Kb(a) {
    return a instanceof Function
      ? a.displayName || a.name || "unknown type name"
      : a instanceof Object
      ? a.constructor.displayName ||
        a.constructor.name ||
        Object.prototype.toString.call(a)
      : a === null
      ? "null"
      : typeof a;
  }
  var Mb = Array.prototype.forEach
      ? function (a, b) {
          H(a.length != null);
          Array.prototype.forEach.call(a, b, void 0);
        }
      : function (a, b) {
          for (
            var c = a.length,
              d = typeof a === "string" ? a.split("") : a,
              e = 0;
            e < c;
            e++
          )
            e in d && b.call(void 0, d[e], e, a);
        },
    Nb = Array.prototype.map
      ? function (a, b) {
          H(a.length != null);
          return Array.prototype.map.call(a, b, void 0);
        }
      : function (a, b) {
          for (
            var c = a.length,
              d = Array(c),
              e = typeof a === "string" ? a.split("") : a,
              f = 0;
            f < c;
            f++
          )
            f in e && (d[f] = b.call(void 0, e[f], f, a));
          return d;
        },
    Ob = Array.prototype.some
      ? function (a, b) {
          H(a.length != null);
          return Array.prototype.some.call(a, b, void 0);
        }
      : function (a, b) {
          for (
            var c = a.length,
              d = typeof a === "string" ? a.split("") : a,
              e = 0;
            e < c;
            e++
          )
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
          return !1;
        };
  function Pb(a) {
    return Array.prototype.concat.apply([], arguments);
  }
  function Qb(a) {
    var b = a.length;
    if (b > 0) {
      for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
      return c;
    }
    return [];
  }
  function Rb(a, b, c) {
    if (!Ra(a) || !Ra(b) || a.length != b.length) return !1;
    var d = a.length;
    c = c || Sb;
    for (var e = 0; e < d; e++) if (!c(a[e], b[e])) return !1;
    return !0;
  }
  function Sb(a, b) {
    return a === b;
  }
  function Tb(a, b) {
    return Pb.apply([], Nb(a, b));
  }
  function Ub(a, b) {
    a.__closure__error__context__984382 ||
      (a.__closure__error__context__984382 = {});
    a.__closure__error__context__984382.severity = b;
  }
  var Vb = function (a, b) {
    this.name = a;
    this.value = b;
  };
  Vb.prototype.toString = function () {
    return this.name;
  };
  var Wb = new Vb("OFF", Infinity),
    Xb = new Vb("WARNING", 900),
    Yb = new Vb("INFO", 800),
    Zb = new Vb("CONFIG", 700),
    $b = function () {
      this.sd = 0;
      this.clear();
    },
    ac;
  $b.prototype.clear = function () {
    this.I = Array(this.sd);
    this.Uf = -1;
    this.yg = !1;
  };
  var bc = function (a, b, c) {
    this.reset(a || Wb, b, c, void 0, void 0);
  };
  bc.prototype.reset = function (a, b, c, d) {
    d || Date.now();
    this.Mi = b;
  };
  bc.prototype.getMessage = function () {
    return this.Mi;
  };
  var cc = function (a, b) {
      b = b === void 0 ? null : b;
      this.level = null;
      this.ei = [];
      this.parent = b || null;
      this.children = [];
      this.Di = {
        getName: function () {
          return a;
        },
      };
    },
    dc = function (a) {
      if (a.level) return a.level;
      if (a.parent) return dc(a.parent);
      Fb("Root logger has no level set.");
      return Wb;
    },
    ec = function (a, b) {
      for (; a; )
        a.ei.forEach(function (c) {
          c(b);
        }),
          (a = a.parent);
    },
    fc = function () {
      this.entries = {};
      var a = new cc("");
      a.level = Zb;
      this.entries[""] = a;
    },
    hc,
    ic = function (a, b, c) {
      var d = a.entries[b];
      if (d) return c !== void 0 && (d.level = c), d;
      d = b.lastIndexOf(".");
      d = b.slice(0, Math.max(d, 0));
      d = ic(a, d);
      var e = new cc(b, d);
      a.entries[b] = e;
      d.children.push(e);
      c !== void 0 && (e.level = c);
      return e;
    },
    jc = function () {
      hc || (hc = new fc());
      return hc;
    },
    lc = function (a) {
      var b = kc;
      if (b) {
        var c = a,
          d = Xb;
        if ((a = b))
          if ((a = b && d)) {
            a = d.value;
            var e = b ? dc(ic(jc(), b.getName())) : Wb;
            a = a >= e.value;
          }
        if (a) {
          d = d || Wb;
          a = ic(jc(), b.getName());
          typeof c === "function" && (c = c());
          ac || (ac = new $b());
          e = ac;
          b = b.getName();
          if (e.sd > 0) {
            var f = (e.Uf + 1) % e.sd;
            e.Uf = f;
            e.yg
              ? ((e = e.I[f]), e.reset(d, c, b), (b = e))
              : ((e.yg = f == e.sd - 1), (b = e.I[f] = new bc(d, c, b)));
          } else b = new bc(d, c, b);
          ec(a, b);
        }
      }
    };
  var mc = function () {
    this.names = new Map();
  };
  mc.prototype.getName = function (a) {
    var b = this.names.get(a);
    if (b) return b;
    var c;
    b =
      (c = a.description) != null
        ? c
        : Math.floor(Math.random() * 2147483648).toString(36) +
          Math.abs(
            Math.floor(Math.random() * 2147483648) ^ Date.now()
          ).toString(36);
    this.names.set(a, b);
    return b;
  }; /*


 Copyright (c) 2015-2018 Google, Inc., Netflix, Inc., Microsoft Corp. and contributors
 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at
     http://www.apache.org/licenses/LICENSE-2.0
 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.
*/
  var nc = function (a) {
    var b = Error.call(
      this,
      a
        ? a.length +
            " errors occurred during unsubscription:\n" +
            a
              .map(function (c, d) {
                return d + 1 + ") " + c.toString();
              })
              .join("\n  ")
        : ""
    );
    this.message = b.message;
    "stack" in b && (this.stack = b.stack);
    this.errors = a;
    Object.setPrototypeOf(this, this.constructor.prototype);
    this.name = "UnsubscriptionError";
  };
  q(nc, Error);
  function oc(a, b) {
    a && ((b = a.indexOf(b)), 0 <= b && a.splice(b, 1));
  }
  function M(a) {
    return typeof a === "function";
  }
  var qc = function (a) {
    this.ki = a;
    this.closed = !1;
    this.Ac = this.Vb = null;
  };
  n = qc.prototype;
  n.unsubscribe = function () {
    if (!this.closed) {
      this.closed = !0;
      var a = this.Vb;
      if (Array.isArray(a)) {
        var b = x(a),
          c = b.next();
        try {
          for (; !c.done; c = b.next()) c.value.remove(this);
        } finally {
          ra(b, c);
        }
      } else a == null || a.remove(this);
      b = this.ki;
      if (M(b))
        try {
          b();
        } catch (h) {
          var d = h instanceof nc ? h.errors : [h];
        }
      var e = this.Ac;
      if (e) {
        this.Ac = null;
        b = x(e);
        c = b.next();
        try {
          for (; !c.done; c = b.next()) {
            var f = c.value;
            try {
              M(f) ? f() : f.unsubscribe();
            } catch (h) {
              var g = void 0;
              d = (g = d) != null ? g : [];
              h instanceof nc ? (d = [].concat(y(d), y(h.errors))) : d.push(h);
            }
          }
        } finally {
          ra(b, c);
        }
      }
      if (d) throw new nc(d);
    }
  };
  n.add = function (a) {
    if (a && a !== this)
      if (this.closed) M(a) ? a() : a.unsubscribe();
      else {
        if (a instanceof qc) {
          if (a.closed || a.th(this)) return;
          a.sh(this);
        }
        var b;
        (this.Ac = (b = this.Ac) != null ? b : []).push(a);
      }
  };
  n.th = function (a) {
    var b = this.Vb;
    return b === a || (Array.isArray(b) && b.includes(a));
  };
  n.sh = function (a) {
    var b = this.Vb;
    this.Vb = Array.isArray(b) ? (b.push(a), b) : b ? [b, a] : a;
  };
  n.uh = function (a) {
    var b = this.Vb;
    b === a ? (this.Vb = null) : Array.isArray(b) && oc(b, a);
  };
  n.remove = function (a) {
    var b = this.Ac;
    b && oc(b, a);
    a instanceof qc && a.uh(this);
  };
  var rc = new qc();
  rc.closed = !0;
  qc.EMPTY = rc;
  function sc(a) {
    return (
      a instanceof qc ||
      (a && "closed" in a && M(a.remove) && M(a.add) && M(a.unsubscribe))
    );
  }
  var tc = function () {
    setTimeout.apply(null, y(F.apply(0, arguments)));
  };
  function uc() {}
  function vc(a) {
    tc(function () {
      throw a;
    });
  }
  var wc = function (a) {
    qc.call(this);
    this.U = !1;
    this.destination =
      a instanceof wc
        ? a
        : new xc(!a || M(a) ? { next: a != null ? a : void 0 } : a);
    sc(a) && a.add(this);
  };
  q(wc, qc);
  wc.EMPTY = qc.EMPTY;
  wc.create = function (a, b, c) {
    return new yc(a, b, c);
  };
  n = wc.prototype;
  n.next = function (a) {
    this.U || this.fe(a);
  };
  n.error = function (a) {
    this.U || ((this.U = !0), this.Gf(a));
  };
  n.complete = function () {
    this.U || ((this.U = !0), this.md());
  };
  n.unsubscribe = function () {
    this.closed || ((this.U = !0), qc.prototype.unsubscribe.call(this));
  };
  n.fe = function (a) {
    this.destination.next(a);
  };
  n.Gf = function (a) {
    this.destination.error(a);
    this.unsubscribe();
  };
  n.md = function () {
    this.destination.complete();
    this.unsubscribe();
  };
  var xc = function (a) {
    this.Ye = a;
  };
  xc.prototype.next = function (a) {
    var b = this.Ye;
    if (b.next)
      try {
        b.next(a);
      } catch (c) {
        vc(c);
      }
  };
  xc.prototype.error = function (a) {
    var b = this.Ye;
    if (b.error)
      try {
        b.error(a);
      } catch (c) {
        vc(c);
      }
    else vc(a);
  };
  xc.prototype.complete = function () {
    var a = this.Ye;
    if (a.complete)
      try {
        a.complete();
      } catch (b) {
        vc(b);
      }
  };
  var yc = function (a, b, c) {
    wc.call(this);
    this.destination = new xc(
      M(a) || !a
        ? {
            next: a != null ? a : void 0,
            error: b != null ? b : void 0,
            complete: c != null ? c : void 0,
          }
        : a
    );
  };
  q(yc, wc);
  yc.EMPTY = wc.EMPTY;
  yc.create = wc.create;
  var zc =
    (typeof Symbol === "function" && Symbol.observable) || "@@observable";
  function Ac(a) {
    return a;
  }
  function N() {
    return Bc(F.apply(0, arguments));
  }
  function Bc(a) {
    return a.length === 0
      ? Ac
      : a.length === 1
      ? a[0]
      : function (b) {
          return a.reduce(function (c, d) {
            return d(c);
          }, b);
        };
  }
  var O = function (a) {
    a && (this.Oa = a);
  };
  n = O.prototype;
  n.Fb = function (a) {
    var b = new O();
    b.source = this;
    b.operator = a;
    return b;
  };
  n.subscribe = function (a, b, c) {
    a =
      (a && a instanceof wc) ||
      (a && M(a.next) && M(a.error) && M(a.complete) && sc(a))
        ? a
        : new yc(a, b, c);
    b = this.operator;
    c = this.source;
    a.add(b ? b.call(a, c) : c ? this.Oa(a) : this.he(a));
    return a;
  };
  n.he = function (a) {
    try {
      return this.Oa(a);
    } catch (b) {
      a.error(b);
    }
  };
  n.forEach = function (a, b) {
    var c = this;
    b = Cc(b);
    return new b(function (d, e) {
      var f = c.subscribe(
        function (g) {
          try {
            a(g);
          } catch (h) {
            e(h), f == null || f.unsubscribe();
          }
        },
        e,
        d
      );
    });
  };
  n.Oa = function (a) {
    var b;
    return (b = this.source) == null ? void 0 : b.subscribe(a);
  };
  O.prototype[zc] = function () {
    return this;
  };
  O.prototype.i = function () {
    var a = F.apply(0, arguments);
    return a.length ? Bc(a)(this) : this;
  };
  O.create = function (a) {
    return new O(a);
  };
  function Cc(a) {
    var b;
    return (b = a != null ? a : void 0) != null ? b : Promise;
  }
  var Dc = function () {
    var a = Error.call(this, "object unsubscribed");
    this.message = a.message;
    "stack" in a && (this.stack = a.stack);
    Object.setPrototypeOf(this, this.constructor.prototype);
    this.name = "ObjectUnsubscribedError";
  };
  q(Dc, Error);
  var Ec = function () {
    this.nc = [];
    this.Ed = this.U = this.closed = !1;
    this.qf = null;
  };
  q(Ec, O);
  n = Ec.prototype;
  n.Fb = function (a) {
    var b = new Fc(this, this);
    b.operator = a;
    return b;
  };
  n.kb = function () {
    if (this.closed) throw new Dc();
  };
  n.next = function (a) {
    this.kb();
    if (!this.U) {
      var b = this.nc.slice();
      b = x(b);
      var c = b.next();
      try {
        for (; !c.done; c = b.next()) c.value.next(a);
      } finally {
        ra(b, c);
      }
    }
  };
  n.error = function (a) {
    this.kb();
    if (!this.U) {
      this.Ed = this.U = !0;
      this.qf = a;
      for (var b = this.nc; b.length; ) b.shift().error(a);
    }
  };
  n.complete = function () {
    this.kb();
    if (!this.U) {
      this.U = !0;
      for (var a = this.nc; a.length; ) a.shift().complete();
    }
  };
  n.unsubscribe = function () {
    this.U = this.closed = !0;
    this.nc = null;
  };
  n.he = function (a) {
    this.kb();
    return O.prototype.he.call(this, a);
  };
  n.Oa = function (a) {
    this.kb();
    this.Ff(a);
    return this.If(a);
  };
  n.If = function (a) {
    var b = this,
      c = this.U,
      d = this.nc;
    return this.Ed || c
      ? qc.EMPTY
      : (d.push(a),
        new qc(function () {
          return oc(b.nc, a);
        }));
  };
  n.Ff = function (a) {
    var b = this.qf,
      c = this.U;
    this.Ed ? a.error(b) : c && a.complete();
  };
  n.S = function () {
    var a = new O();
    a.source = this;
    return a;
  };
  Ec.create = function (a, b) {
    return new Fc(a, b);
  };
  var Fc = function (a, b) {
    Ec.call(this);
    this.destination = a;
    this.source = b;
  };
  q(Fc, Ec);
  Fc.create = Ec.create;
  Fc.prototype.next = function (a) {
    var b, c;
    (b = this.destination) == null || (c = b.next) == null || c.call(b, a);
  };
  Fc.prototype.error = function (a) {
    var b, c;
    (b = this.destination) == null || (c = b.error) == null || c.call(b, a);
  };
  Fc.prototype.complete = function () {
    var a, b;
    (a = this.destination) == null || (b = a.complete) == null || b.call(a);
  };
  Fc.prototype.Oa = function (a) {
    var b, c;
    return (c = (b = this.source) == null ? void 0 : b.subscribe(a)) != null
      ? c
      : qc.EMPTY;
  };
  var Gc = function (a) {
    Ec.call(this);
    this.ie = a;
  };
  q(Gc, Ec);
  Gc.create = Ec.create;
  da.Object.defineProperties(Gc.prototype, {
    value: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.getValue();
      },
    },
  });
  Gc.prototype.Oa = function (a) {
    var b = Ec.prototype.Oa.call(this, a);
    !b.closed && a.next(this.ie);
    return b;
  };
  Gc.prototype.getValue = function () {
    var a = this.qf,
      b = this.ie;
    if (this.Ed) throw a;
    this.kb();
    return b;
  };
  Gc.prototype.next = function (a) {
    Ec.prototype.next.call(this, (this.ie = a));
  };
  var Hc = new O(function (a) {
    return a.complete();
  });
  function Ic(a, b) {
    return new O(function (c) {
      var d = 0;
      return b.K(function () {
        d === a.length ? c.complete() : (c.next(a[d++]), c.closed || this.K());
      });
    });
  }
  function Jc(a, b) {
    if (!a) throw Error("z");
    return new O(function (c) {
      var d = new qc();
      d.add(
        b.K(function () {
          var e = a[Symbol.asyncIterator]();
          d.add(
            b.K(function () {
              var f = this;
              e.next().then(function (g) {
                g.done ? c.complete() : (c.next(g.value), f.K());
              });
            })
          );
        })
      );
      return d;
    });
  }
  var Kc =
    typeof Symbol === "function" && Symbol.iterator
      ? Symbol.iterator
      : "@@iterator";
  function Lc(a, b, c) {
    b = b.K(function () {
      try {
        c.call(this);
      } catch (d) {
        a.error(d);
      }
    }, 0);
    a.add(b);
  }
  function Mc(a, b) {
    return new O(function (c) {
      var d;
      c.add(
        b.K(function () {
          d = a[Kc]();
          Lc(c, b, function () {
            var e = d.next(),
              f = e.value;
            e.done ? c.complete() : (c.next(f), this.K());
          });
        })
      );
      return function () {
        var e;
        return M((e = d) == null ? void 0 : e.return) && d.return();
      };
    });
  }
  function Nc(a, b) {
    return new O(function (c) {
      var d = new qc();
      d.add(
        b.K(function () {
          var e = a[zc]();
          d.add(
            e.subscribe({
              next: function (f) {
                d.add(
                  b.K(function () {
                    return c.next(f);
                  })
                );
              },
              error: function (f) {
                d.add(
                  b.K(function () {
                    return c.error(f);
                  })
                );
              },
              complete: function () {
                d.add(
                  b.K(function () {
                    return c.complete();
                  })
                );
              },
            })
          );
        })
      );
      return d;
    });
  }
  function Oc(a, b) {
    return new O(function (c) {
      return b.K(function () {
        return a.then(
          function (d) {
            c.add(
              b.K(function () {
                c.next(d);
                c.add(
                  b.K(function () {
                    return c.complete();
                  })
                );
              })
            );
          },
          function (d) {
            c.add(
              b.K(function () {
                return c.error(d);
              })
            );
          }
        );
      });
    });
  }
  var Qc = function (a) {
    return a && typeof a.length === "number" && typeof a !== "function";
  };
  function Rc(a) {
    return new TypeError(
      "A`" +
        (a !== null && typeof a === "object"
          ? "an invalid object"
          : "'" + a + "'")
    );
  }
  function Uc(a, b) {
    if (a != null) {
      if (M(a[zc])) return Nc(a, b);
      if (Qc(a)) return Ic(a, b);
      if (M(a == null ? void 0 : a.then)) return Oc(a, b);
      if (
        Symbol.asyncIterator &&
        M(a == null ? void 0 : a[Symbol.asyncIterator])
      )
        return Jc(a, b);
      if (M(a == null ? void 0 : a[Kc])) return Mc(a, b);
    }
    throw Rc(a);
  }
  function Vc(a, b) {
    return b ? Uc(a, b) : Wc(a);
  }
  function Wc(a) {
    if (a instanceof O) return a;
    if (a != null) {
      if (M(a[zc])) return Xc(a);
      if (Qc(a)) return Yc(a);
      if (M(a == null ? void 0 : a.then)) return Zc(a);
      if (
        Symbol.asyncIterator &&
        M(a == null ? void 0 : a[Symbol.asyncIterator])
      )
        return $c(a);
      if (M(a == null ? void 0 : a[Kc])) return ad(a);
    }
    throw Rc(a);
  }
  function Xc(a) {
    return new O(function (b) {
      var c = a[zc]();
      if (M(c.subscribe)) return c.subscribe(b);
      throw new TypeError("B");
    });
  }
  function Yc(a) {
    return new O(function (b) {
      for (var c = 0; c < a.length && !b.closed; c++) b.next(a[c]);
      b.complete();
    });
  }
  function Zc(a) {
    return new O(function (b) {
      a.then(
        function (c) {
          b.closed || (b.next(c), b.complete());
        },
        function (c) {
          return b.error(c);
        }
      ).then(null, vc);
    });
  }
  function ad(a) {
    return new O(function (b) {
      for (var c = a[Kc](); !b.closed; ) {
        var d = c.next(),
          e = d.value;
        d.done ? b.complete() : b.next(e);
      }
      return function () {
        return M(c == null ? void 0 : c.return) && c.return();
      };
    });
  }
  function $c(a) {
    return new O(function (b) {
      bd(a, b).catch(function (c) {
        return b.error(c);
      });
    });
  }
  function bd(a, b) {
    var c, d, e, f, g, h;
    return Ba(function (k) {
      switch (k.u) {
        case 1:
          k.Kb(2, 3);
          var l = a[Symbol.asyncIterator];
          f = l !== void 0 ? l.call(a) : new Da(x(a));
        case 5:
          return (d = void 0), k.yield(f.next(), 8);
        case 8:
          d = k.V;
          if (d.done) {
            k.ba(3);
            break;
          }
          g = d.value;
          b.next(g);
          k.ba(5);
          break;
        case 3:
          k.zd();
          k.jf(9);
          if (!d || d.done || !(e = f.return)) {
            k.ba(9);
            break;
          }
          return k.yield(e.call(f), 9);
        case 9:
          k.zd(0, 0, 1);
          if (c) throw c.error;
          k.Ld(10, 1);
          break;
        case 10:
          k.Ld(4);
          break;
        case 2:
          h = k.rb();
          c = { error: h };
          k.ba(3);
          break;
        case 4:
          b.complete(), k.Db();
      }
    });
  }
  function cd(a, b) {
    return b ? Ic(a, b) : Yc(a);
  }
  function dd(a) {
    return M(a[a.length - 1]) ? a.pop() : void 0;
  }
  function ed(a) {
    var b = a[a.length - 1];
    return b && M(b.K) ? a.pop() : void 0;
  }
  function fd() {
    var a = F.apply(0, arguments),
      b = ed(a);
    return b ? Ic(a, b) : cd(a);
  }
  function gd(a) {
    var b = M(a)
      ? a
      : function () {
          return a;
        };
    return new O(function (c) {
      return c.error(b());
    });
  }
  var hd = {
    now: function () {
      return (hd.Nh || Date).now();
    },
    Nh: void 0,
  };
  var id = function (a, b, c) {
    a = a === void 0 ? Infinity : a;
    b = b === void 0 ? Infinity : b;
    c = c === void 0 ? hd : c;
    Ec.call(this);
    this.bufferSize = a;
    this.mh = b;
    this.fh = c;
    this.buffer = [];
    this.Le = b === Infinity;
    this.bufferSize = Math.max(1, a);
    this.mh = Math.max(1, b);
  };
  q(id, Ec);
  id.create = Ec.create;
  id.prototype.next = function (a) {
    var b = this.buffer,
      c = this.Le,
      d = this.fh,
      e = this.mh;
    this.U || (b.push(a), !c && b.push(d.now() + e));
    jd(this);
    Ec.prototype.next.call(this, a);
  };
  id.prototype.Oa = function (a) {
    this.kb();
    jd(this);
    for (
      var b = this.If(a), c = this.Le, d = this.buffer.slice(), e = 0;
      e < d.length && !a.closed;
      e += c ? 1 : 2
    )
      a.next(d[e]);
    this.Ff(a);
    return b;
  };
  var jd = function (a) {
    var b = a.bufferSize,
      c = a.fh,
      d = a.buffer;
    a = a.Le;
    var e = (a ? 1 : 2) * b;
    b < Infinity && e < d.length && d.splice(0, d.length - e);
    if (!a) {
      b = c.now();
      c = 0;
      for (a = 1; a < d.length && d[a] <= b; a += 2) c = a;
      c && d.splice(0, c + 1);
    }
  };
  var ld = function (a, b) {
    b = b === void 0 ? kd : b;
    this.ij = a;
    this.now = b;
  };
  ld.prototype.K = function (a, b, c) {
    b = b === void 0 ? 0 : b;
    return new this.ij(this, a).K(c, b);
  };
  var kd = hd.now;
  var md = function () {
    var a = Error.call(this, "no elements in sequence");
    this.message = a.message;
    "stack" in a && (this.stack = a.stack);
    Object.setPrototypeOf(this, this.constructor.prototype);
    this.name = "EmptyError";
  };
  q(md, Error);
  function nd(a) {
    return new Promise(function (b, c) {
      var d = new yc({
        next: function (e) {
          b(e);
          d.unsubscribe();
        },
        error: c,
        complete: function () {
          c(new md());
        },
      });
      a.subscribe(d);
    });
  }
  var P = function (a, b, c, d, e) {
    wc.call(this, a);
    this.Ui = e;
    b &&
      (this.fe = function (f) {
        try {
          b(f);
        } catch (g) {
          this.destination.error(g);
        }
      });
    c &&
      (this.Gf = function (f) {
        try {
          c(f);
        } catch (g) {
          this.destination.error(g);
        }
        this.unsubscribe();
      });
    d &&
      (this.md = function () {
        try {
          d();
        } catch (f) {
          this.destination.error(f);
        }
        this.unsubscribe();
      });
  };
  q(P, wc);
  P.EMPTY = wc.EMPTY;
  P.create = wc.create;
  P.prototype.unsubscribe = function () {
    var a;
    this.closed || ((a = this.Ui) != null && a.call(this));
    wc.prototype.unsubscribe.call(this);
  };
  function od(a) {
    return function (b) {
      if (M(b == null ? void 0 : b.Fb))
        return b.Fb(function (c) {
          try {
            return a(c, this);
          } catch (d) {
            this.error(d);
          }
        });
      throw new TypeError("C");
    };
  }
  function pd() {
    return od(function (a, b) {
      var c = null;
      a.nd++;
      var d = new P(b, void 0, void 0, void 0, function () {
        if (!a || a.nd <= 0 || 0 < --a.nd) c = null;
        else {
          var e = a.Ub,
            f = c;
          c = null;
          !e || (f && e !== f) || e.unsubscribe();
          b.unsubscribe();
        }
      });
      a.subscribe(d);
      d.closed || (c = a.connect());
    });
  }
  var qd = function (a, b) {
    this.source = a;
    this.Zg = b;
    this.od = null;
    this.nd = 0;
    this.Ub = null;
  };
  q(qd, O);
  qd.create = O.create;
  qd.prototype.Oa = function (a) {
    return rd(this).subscribe(a);
  };
  var rd = function (a) {
    var b = a.od;
    if (!b || b.U) a.od = a.Zg();
    return a.od;
  };
  qd.prototype.ge = function () {
    this.nd = 0;
    var a = this.Ub;
    this.od = this.Ub = null;
    a == null || a.unsubscribe();
  };
  qd.prototype.connect = function () {
    var a = this,
      b = this.Ub;
    if (!b) {
      b = this.Ub = new qc();
      var c = rd(this);
      b.add(
        this.source.subscribe(
          new P(
            c,
            void 0,
            function (d) {
              a.ge();
              c.error(d);
            },
            function () {
              a.ge();
              c.complete();
            },
            function () {
              return a.ge();
            }
          )
        )
      );
      b.closed && ((this.Ub = null), (b = qc.EMPTY));
    }
    return b;
  };
  function sd() {
    var a = td;
    var b = b === void 0 ? 0 : b;
    return od(function (c, d) {
      d.add(
        a.K(function () {
          return c.subscribe(d);
        }, b)
      );
    });
  }
  function Q(a) {
    return od(function (b, c) {
      var d = 0;
      b.subscribe(
        new P(c, function (e) {
          c.next(a.call(void 0, e, d++));
        })
      );
    });
  }
  var ud = Array.isArray;
  function vd(a) {
    return Q(function (b) {
      return ud(b) ? a.apply(null, y(b)) : a(b);
    });
  }
  var wd = Array.isArray,
    xd = Object,
    yd = xd.getPrototypeOf,
    zd = xd.prototype,
    Bd = xd.keys;
  function Cd(a) {
    if (a.length === 1) {
      var b = a[0];
      if (wd(b)) return { args: b, keys: null };
      if (b && typeof b === "object" && yd(b) === zd)
        return (
          (a = Bd(b)),
          {
            args: a.map(function (c) {
              return b[c];
            }),
            keys: a,
          }
        );
    }
    return { args: a, keys: null };
  }
  function Dd() {
    var a = F.apply(0, arguments),
      b = ed(a),
      c = dd(a);
    a = Cd(a);
    var d = a.args,
      e = a.keys;
    if (d.length === 0) return Vc([], b);
    b = new O(
      Ed(
        d,
        b,
        e
          ? function (f) {
              for (var g = {}, h = 0; h < f.length; h++) g[e[h]] = f[h];
              return g;
            }
          : Ac
      )
    );
    return c ? b.i(vd(c)) : b;
  }
  var Fd = function (a, b, c) {
    wc.call(this, a);
    this.fe = b;
    this.oj = c;
  };
  q(Fd, wc);
  Fd.EMPTY = wc.EMPTY;
  Fd.create = wc.create;
  Fd.prototype.md = function () {
    this.oj() ? wc.prototype.md.call(this) : this.unsubscribe();
  };
  function Ed(a, b, c) {
    c = c === void 0 ? Ac : c;
    return function (d) {
      Gd(
        b,
        function () {
          for (
            var e = a.length,
              f = Array(e),
              g = e,
              h = a.map(function () {
                return !1;
              }),
              k = !0,
              l = { yb: 0 };
            l.yb < e;
            l = { yb: l.yb }, l.yb++
          )
            Gd(
              b,
              (function (m) {
                return function () {
                  Vc(a[m.yb], b).subscribe(
                    new Fd(
                      d,
                      function (u) {
                        f[m.yb] = u;
                        k && ((h[m.yb] = !0), (k = !h.every(Ac)));
                        k || d.next(c(f.slice()));
                      },
                      function () {
                        return --g === 0;
                      }
                    )
                  );
                };
              })(l),
              d
            );
        },
        d
      );
    };
  }
  function Gd(a, b, c) {
    a ? c.add(a.K(b)) : b();
  }
  function Hd(a, b, c, d) {
    var e = [],
      f = 0,
      g = 0,
      h = !1,
      k = function (l) {
        f++;
        Wc(c(l, g++)).subscribe(
          new P(
            b,
            function (m) {
              b.next(m);
            },
            void 0,
            function () {
              f--;
              for (var m = {}; e.length && f < d; m = { Pf: void 0 })
                (m.Pf = e.shift()), k(m.Pf);
              !h || e.length || f || b.complete();
            }
          )
        );
      };
    a.subscribe(
      new P(
        b,
        function (l) {
          return f < d ? k(l) : e.push(l);
        },
        void 0,
        function () {
          h = !0;
          !h || e.length || f || b.complete();
        }
      )
    );
    return function () {
      e = null;
    };
  }
  function Id(a, b) {
    var c = c === void 0 ? Infinity : c;
    if (M(b))
      return Id(function (d, e) {
        return Q(function (f, g) {
          return b(d, f, e, g);
        })(Wc(a(d, e)));
      }, c);
    typeof b === "number" && (c = b);
    return od(function (d, e) {
      return Hd(d, e, a, c);
    });
  }
  function Jd(a) {
    a = a === void 0 ? Infinity : a;
    return Id(Ac, a);
  }
  function Kd() {
    var a = F.apply(0, arguments);
    return Jd(1)(cd(a, ed(a)));
  }
  function Ld(a) {
    return new O(function (b) {
      Wc(a()).subscribe(b);
    });
  }
  var Md = ["addListener", "removeListener"],
    Nd = ["addEventListener", "removeEventListener"],
    Od = ["on", "off"];
  function Pd(a, b, c) {
    if (M(c)) {
      var d = c;
      c = void 0;
    }
    if (d) return Pd(a, b, c).i(vd(d));
    d = x(
      M(a.addEventListener) && M(a.removeEventListener)
        ? Nd.map(function (g) {
            return function (h) {
              return a[g](b, h, c);
            };
          })
        : M(a.addListener) && M(a.removeListener)
        ? Md.map(Qd(a, b))
        : M(a.Ik) && M(a.vk)
        ? Od.map(Qd(a, b))
        : []
    );
    var e = d.next().value,
      f = d.next().value;
    return !e && Qc(a)
      ? Id(function (g) {
          return Pd(g, b, c);
        })(cd(a))
      : new O(function (g) {
          if (!e) throw new TypeError("D");
          var h = function () {
            var k = F.apply(0, arguments);
            return g.next(1 < k.length ? k : k[0]);
          };
          e(h);
          return function () {
            return f(h);
          };
        });
  }
  function Qd(a, b) {
    return function (c) {
      return function (d) {
        return a[c](b, d);
      };
    };
  }
  var Rd = function () {
    qc.call(this);
  };
  q(Rd, qc);
  Rd.EMPTY = qc.EMPTY;
  Rd.prototype.K = function () {
    return this;
  };
  var Sd = function (a, b) {
    return setInterval.apply(null, [a, b].concat(y(F.apply(2, arguments))));
  };
  var Td = function (a, b) {
    qc.call(this);
    this.scheduler = a;
    this.zf = b;
    this.pending = !1;
  };
  q(Td, Rd);
  Td.EMPTY = Rd.EMPTY;
  Td.prototype.K = function (a, b) {
    b = b === void 0 ? 0 : b;
    if (this.closed) return this;
    this.state = a;
    a = this.id;
    var c = this.scheduler;
    a != null && (this.id = Ud(this, a, b));
    this.pending = !0;
    this.delay = b;
    this.id = this.id || this.ff(c, this.id, b);
    return this;
  };
  Td.prototype.ff = function (a, b, c) {
    c = c === void 0 ? 0 : c;
    return Sd(a.flush.bind(a, this), c);
  };
  var Ud = function (a, b, c) {
    c = c === void 0 ? 0 : c;
    if (c != null && a.delay === c && a.pending === !1) return b;
    clearInterval(b);
  };
  Td.prototype.execute = function (a, b) {
    if (this.closed) return Error("E");
    this.pending = !1;
    if ((a = this.Hf(a, b))) return a;
    this.pending === !1 &&
      this.id != null &&
      (this.id = Ud(this, this.id, null));
  };
  Td.prototype.Hf = function (a) {
    var b = !1;
    try {
      this.zf(a);
    } catch (d) {
      b = !0;
      var c = (!!d && d) || Error(d);
    }
    if (b) return this.unsubscribe(), c;
  };
  Td.prototype.unsubscribe = function () {
    if (!this.closed) {
      var a = this.id,
        b = this.scheduler.actions;
      this.zf = this.state = this.scheduler = null;
      this.pending = !1;
      oc(b, this);
      a != null && (this.id = Ud(this, a, null));
      this.delay = null;
      Rd.prototype.unsubscribe.call(this);
    }
  };
  var Vd = function (a, b) {
    b = b === void 0 ? kd : b;
    ld.call(this, a, b);
    this.actions = [];
    this.active = !1;
  };
  q(Vd, ld);
  Vd.prototype.flush = function (a) {
    var b = this.actions;
    if (this.active) b.push(a);
    else {
      var c;
      this.active = !0;
      do if ((c = a.execute(a.state, a.delay))) break;
      while ((a = b.shift()));
      this.active = !1;
      if (c) {
        for (; (a = b.shift()); ) a.unsubscribe();
        throw c;
      }
    }
  };
  function Wd() {
    var a = F.apply(0, arguments),
      b = ed(a);
    var c = typeof a[a.length - 1] === "number" ? a.pop() : Infinity;
    return a.length ? (a.length === 1 ? Wc(a[0]) : Jd(c)(cd(a, b))) : Hc;
  }
  var Xd = new O(uc);
  var Yd = Array.isArray;
  function Zd(a) {
    return a.length === 1 && Yd(a[0]) ? a[0] : a;
  }
  function $d() {
    var a = Zd(F.apply(0, arguments));
    return od(function (b, c) {
      var d = [b].concat(y(a)),
        e = function () {
          if (!c.closed)
            if (d.length > 0) {
              try {
                var f = Wc(d.shift());
              } catch (h) {
                e();
                return;
              }
              var g = new P(c, void 0, uc, uc);
              c.add(f.subscribe(g));
              g.add(e);
            } else c.complete();
        };
      e();
    });
  }
  function R(a) {
    return od(function (b, c) {
      var d = 0;
      b.subscribe(
        new P(c, function (e) {
          return a.call(void 0, e, d++) && c.next(e);
        })
      );
    });
  }
  function ae() {
    var a = F.apply(0, arguments);
    a = Zd(a);
    return a.length === 1 ? Wc(a[0]) : new O(be(a));
  }
  function be(a) {
    return function (b) {
      for (
        var c = [], d = { ac: 0 };
        c && !b.closed && d.ac < a.length;
        d = { ac: d.ac }, d.ac++
      )
        c.push(
          Wc(a[d.ac]).subscribe(
            new P(
              b,
              (function (e) {
                return function (f) {
                  if (c) {
                    for (var g = 0; g < c.length; g++)
                      g !== e.ac && c[g].unsubscribe();
                    c = null;
                  }
                  b.next(f);
                };
              })(d)
            )
          )
        );
    };
  }
  function ce() {
    var a = F.apply(0, arguments),
      b = dd(a),
      c = Zd(a);
    return c.length
      ? new O(function (d) {
          var e = c.map(function () {
              return [];
            }),
            f = c.map(function () {
              return !1;
            });
          d.add(function () {
            e = f = null;
          });
          for (
            var g = { ib: 0 };
            !d.closed && g.ib < c.length;
            g = { ib: g.ib }, g.ib++
          )
            Wc(c[g.ib]).subscribe(
              new P(
                d,
                (function (h) {
                  return function (k) {
                    e[h.ib].push(k);
                    e.every(function (l) {
                      return l.length;
                    }) &&
                      ((k = e.map(function (l) {
                        return l.shift();
                      })),
                      d.next(b ? b.apply(null, y(k)) : k),
                      e.some(function (l, m) {
                        return !l.length && f[m];
                      }) && d.complete());
                  };
                })(g),
                void 0,
                (function (h) {
                  return function () {
                    f[h.ib] = !0;
                    !e[h.ib].length && d.complete();
                  };
                })(g)
              )
            );
          return function () {
            e = f = null;
          };
        })
      : Hc;
  }
  var de = function (a, b) {
    Td.call(this, a, b);
    this.scheduler = a;
    this.zf = b;
  };
  q(de, Td);
  de.EMPTY = Td.EMPTY;
  de.prototype.K = function (a, b) {
    b = b === void 0 ? 0 : b;
    if (b > 0) return Td.prototype.K.call(this, a, b);
    this.delay = b;
    this.state = a;
    this.scheduler.flush(this);
    return this;
  };
  de.prototype.execute = function (a, b) {
    return b > 0 || this.closed
      ? Td.prototype.execute.call(this, a, b)
      : this.Hf(a, b);
  };
  de.prototype.ff = function (a, b, c) {
    c = c === void 0 ? 0 : c;
    return (c != null && c > 0) || (c == null && this.delay > 0)
      ? Td.prototype.ff.call(this, a, b, c)
      : a.flush(this);
  };
  var ee = function () {
    Vd.apply(this, arguments);
  };
  q(ee, Vd);
  var td = new ee(de);
  var fe = function () {
    this.J = new Xa();
    this.queue = new Ya();
    this.pi = Symbol();
    this.Ic = new mc();
  };
  da.Object.defineProperties(fe.prototype, {
    Ob: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.pi;
      },
    },
  });
  fe.prototype.Ee = function () {
    return Xd;
  };
  var ge = function (a, b) {
      a.Qa !== null && a.Qa.next(b);
    },
    he = function (a) {
      if (
        (typeof a === "bigint" ||
          typeof a === "number" ||
          typeof a === "string") &&
        typeof BigInt === "function"
      )
        return BigInt(a);
    };
  var ie = function (a, b) {
    b = Error.call(this, b ? a + ": " + b : String(a));
    this.message = b.message;
    "stack" in b && (this.stack = b.stack);
    this.code = a;
    this.__proto__ = ie.prototype;
    this.name = String(a);
  };
  q(ie, Error);
  var je = function (a) {
    ie.call(this, 1e3, 'sfr:"' + a + '"');
    this.Hi = a;
    this.__proto__ = je.prototype;
  };
  q(je, ie);
  var ke = function () {
    ie.call(this, 1003);
    this.__proto__ = ke.prototype;
  };
  q(ke, ie);
  var le = function () {
    ie.call(this, 1009);
    this.__proto__ = le.prototype;
  };
  q(le, ie);
  var me = function () {
    ie.call(this, 1011);
    this.__proto__ = me.prototype;
  };
  q(me, ie);
  var ne = function () {
    ie.call(this, 1007);
    this.__proto__ = ke.prototype;
  };
  q(ne, ie);
  var oe = function () {
    ie.call(this, 1008);
    this.__proto__ = ke.prototype;
  };
  q(oe, ie);
  var pe = function () {
    ie.call(this, 1001);
    this.__proto__ = pe.prototype;
  };
  q(pe, ie);
  var qe = function (a) {
    ie.call(this, 1004, String(a));
    this.li = a;
    this.__proto__ = qe.prototype;
  };
  q(qe, ie);
  var se = function (a) {
    ie.call(this, 1010, a);
    this.__proto__ = re.prototype;
  };
  q(se, ie);
  var re = function (a) {
    ie.call(this, 1005, a);
    this.__proto__ = re.prototype;
  };
  q(re, ie);
  var te = function (a) {
    var b = F.apply(1, arguments),
      c = this;
    this.qc = [];
    this.qc.push(a);
    b.forEach(function (d) {
      c.qc.push(d);
    });
  };
  te.prototype.R = function (a) {
    return this.qc.some(function (b) {
      return b.R(a);
    });
  };
  te.prototype.M = function (a, b) {
    for (var c = 0; c < this.qc.length; c++)
      if (this.qc[c].R(b)) return this.qc[c].M(a, b);
    throw new le();
  };
  function ue(a) {
    var b, c, d;
    return (
      !!a &&
      typeof a.active === "boolean" &&
      typeof ((b = a.clock) == null ? void 0 : b.now) === "function" &&
      ((c = a.clock) == null ? void 0 : c.timeline) !== void 0 &&
      !((d = a.G) == null || !d.timestamp) &&
      typeof a.ea === "function" &&
      typeof a.fa === "function" &&
      typeof a.za === "function" &&
      typeof a.map === "function" &&
      typeof a.Ba === "function"
    );
  }
  var ve = Symbol("time-origin"),
    we = Symbol("date"),
    xe = function (a, b) {
      this.value = a;
      this.timeline = b;
    },
    ye = function (a, b) {
      if (b.timeline !== a.timeline) throw new ne();
    },
    ze = function (a, b) {
      ye(a, b);
      return a.value - b.value;
    };
  n = xe.prototype;
  n.equals = function (a) {
    return ze(this, a) === 0;
  };
  n.maximum = function (a) {
    ye(this, a);
    return this.value >= a.value ? this : a;
  };
  n.round = function () {
    return new xe(Math.round(this.value), this.timeline);
  };
  n.add = function (a) {
    return new xe(this.value + a, this.timeline);
  };
  n.toString = function () {
    return String(this.value);
  };
  function Ae(a) {
    function b(c) {
      return (
        typeof c === "boolean" ||
        typeof c === "string" ||
        typeof c === "number" ||
        c === void 0 ||
        c === null
      );
    }
    return b(a)
      ? !0
      : Array.isArray(a)
      ? a.every(b)
      : typeof a === "object"
      ? Object.keys(a).every(function (c) {
          return typeof c === "string";
        }) &&
        Object.values(a).every(function (c) {
          return Array.isArray(c) ? c.every(b) : b(c);
        })
      : !1;
  }
  function Be(a) {
    if (Ae(a)) return a;
    if (ue(a))
      return {
        G: {
          value: Be(a.G.value),
          timestamp: ze(a.G.timestamp, new xe(0, a.G.timestamp.timeline)),
        },
        active: a.active,
      };
    try {
      return JSON.parse(JSON.stringify(a));
    } catch (b) {}
    return String(a);
  }
  var Ce = { Gj: "app", fk: "web" };
  var De = ["sessionStart", "sessionError", "sessionFinish"],
    Ee = function (a, b) {
      this.ka = a;
      this.ae = b;
      this.ready = !1;
      this.Gb = [];
      this.Rg = function () {};
      this.jh = function () {};
      this.eg = function () {};
      this.pg = function () {};
      this.Sd = function () {};
    },
    Fe = function (a, b) {
      a.Rg = b;
    },
    Ge = function (a, b) {
      a.jh = b;
    },
    He = function (a, b) {
      a.eg = b;
    },
    Ie = function (a, b) {
      a.pg = b;
    },
    Je = function (a, b) {
      a.Sd = b;
      a.Sd(a.Gb.length);
    },
    Oe = function (a) {
      var b = x(
          "geometryChange impression loaded start firstQuartile midpoint thirdQuartile complete pause resume bufferStart bufferFinish skipped volumeChange playerStateChange adUserInteraction".split(
            " "
          )
        ),
        c = b.next();
      try {
        for (; !c.done; c = b.next())
          a.ka.addEventListener(c.value, function (d) {
            Ke(a, d);
          });
      } finally {
        ra(b, c);
      }
      Le(
        a.ka,
        function (d) {
          d.type !== "sessionStart" && Ke(a, d);
        },
        a.ae
      );
      Le(
        a.ka,
        function (d) {
          d.type === "sessionStart" && (Ke(a, d), Me(a), Ne(a));
        },
        a.ae
      );
    },
    Ke = function (a, b) {
      a.Gb.push(b);
      a.Sd(a.Gb.length);
      Ne(a);
    },
    Ne = function (a) {
      if (a.ready)
        for (; a.Gb.length > 0; ) {
          var b = a.Gb.pop();
          b !== void 0 &&
            (b.type === "geometryChange"
              ? a.eg(b)
              : b.type === "impression"
              ? a.pg(b)
              : De.includes(b.type)
              ? a.Rg(b)
              : a.jh(b));
          a.Sd(a.Gb.length);
        }
    },
    Me = function (a) {
      a.ready ||
        ((a.ready = !0),
        a.Gb.sort(function (b, c) {
          return c.timestamp - b.timestamp;
        }));
    };
  function Pe(a) {
    return od(function (b, c) {
      var d = null,
        e = !1,
        f;
      d = b.subscribe(
        new P(c, void 0, function (g) {
          f = Wc(a(g, Pe(a)(b)));
          d ? (d.unsubscribe(), (d = null), f.subscribe(c)) : (e = !0);
        })
      );
      e && (d.unsubscribe(), (d = null), f.subscribe(c));
    });
  }
  function Qe(a, b, c) {
    return function (d, e) {
      var f = c,
        g = b,
        h = 0;
      d.subscribe(
        new P(
          e,
          function (k) {
            var l = h++;
            g = f ? a(g, k, l) : ((f = !0), k);
            e.next(g);
          },
          void 0,
          void 0
        )
      );
    };
  }
  function Re() {
    var a = F.apply(0, arguments),
      b = dd(a);
    return b
      ? N(Re.apply(null, y(a)), vd(b))
      : od(function (c, d) {
          Ed([c].concat(y(Zd(a))))(d);
        });
  }
  function Ue() {
    return Re.apply(null, y(F.apply(0, arguments)));
  }
  function Ve(a) {
    a = a === void 0 ? null : a;
    return od(function (b, c) {
      var d = !1;
      b.subscribe(
        new P(
          c,
          function (e) {
            d = !0;
            c.next(e);
          },
          void 0,
          function () {
            d || c.next(a);
            c.complete();
          }
        )
      );
    });
  }
  function We() {
    return od(function (a, b) {
      a.subscribe(new P(b, uc));
    });
  }
  function Xe(a) {
    return od(function (b, c) {
      b.subscribe(
        new P(c, function () {
          return c.next(a);
        })
      );
    });
  }
  function Ye(a) {
    return a <= 0
      ? function () {
          return Hc;
        }
      : od(function (b, c) {
          var d = 0;
          b.subscribe(
            new P(c, function (e) {
              ++d <= a && (c.next(e), a <= d && c.complete());
            })
          );
        });
  }
  function Ze(a) {
    return Id(function (b, c) {
      return a(b, c).i(Ye(1), Xe(b));
    });
  }
  function $e(a) {
    return od(function (b, c) {
      var d = new Set();
      b.subscribe(
        new P(c, function (e) {
          var f = a ? a(e) : e;
          d.has(f) || (d.add(f), c.next(e));
        })
      );
    });
  }
  function S(a) {
    var b = b === void 0 ? Ac : b;
    var c;
    a = (c = a) != null ? c : af;
    return od(function (d, e) {
      var f,
        g = !0;
      d.subscribe(
        new P(e, function (h) {
          var k = b(h);
          if (g || !a(f, k)) (g = !1), (f = k), e.next(h);
        })
      );
    });
  }
  function af(a, b) {
    return a === b;
  }
  function bf(a) {
    a = a === void 0 ? cf : a;
    return od(function (b, c) {
      var d = !1;
      b.subscribe(
        new P(
          c,
          function (e) {
            d = !0;
            c.next(e);
          },
          void 0,
          function () {
            return d ? c.complete() : c.error(a());
          }
        )
      );
    });
  }
  function cf() {
    return new md();
  }
  function df() {
    var a = F.apply(0, arguments);
    return function (b) {
      return Kd(b, fd.apply(null, y(a)));
    };
  }
  function ef(a) {
    return od(function (b, c) {
      var d = 0;
      b.subscribe(
        new P(
          c,
          function (e) {
            a.call(void 0, e, d++, b) || (c.next(!1), c.complete());
          },
          void 0,
          function () {
            c.next(!0);
            c.complete();
          }
        )
      );
    });
  }
  function ff() {
    return od(function (a, b) {
      var c = [];
      a.subscribe(
        new P(
          b,
          function (d) {
            c.push(d);
            1 < c.length && c.shift();
          },
          void 0,
          function () {
            var d = x(c),
              e = d.next();
            try {
              for (; !e.done; e = d.next()) b.next(e.value);
            } finally {
              ra(d, e);
            }
            b.complete();
          },
          function () {
            c = null;
          }
        )
      );
    });
  }
  function gf(a, b) {
    var c = arguments.length >= 2;
    return function (d) {
      return d.i(
        a
          ? R(function (e, f) {
              return a(e, f, d);
            })
          : Ac,
        ff(),
        c
          ? Ve(b)
          : bf(function () {
              return new md();
            })
      );
    };
  }
  function hf(a) {
    var b = M(a)
      ? a
      : function () {
          return a;
        };
    return M()
      ? od(function (c, d) {
          var e = b();
          (void 0)(e).subscribe(d).add(c.subscribe(e));
        })
      : function (c) {
          var d = new qd(c, b);
          M(c == null ? void 0 : c.Fb) && (d.Fb = c.Fb);
          d.source = c;
          d.Zg = b;
          return d;
        };
  }
  function jf() {
    return od(function (a, b) {
      var c,
        d = !1;
      a.subscribe(
        new P(b, function (e) {
          var f = c;
          c = e;
          d && b.next([f, e]);
          d = !0;
        })
      );
    });
  }
  function kf(a) {
    var b = new id(a, void 0, void 0);
    return function (c) {
      return hf(function () {
        return b;
      })(c);
    };
  }
  function lf() {
    var a = a === void 0 ? Infinity : a;
    return a <= 0
      ? function () {
          return Hc;
        }
      : od(function (b, c) {
          var d = 0,
            e,
            f = function () {
              var g = !1;
              e = b.subscribe(
                new P(c, void 0, void 0, function () {
                  ++d < a
                    ? e
                      ? (e.unsubscribe(), (e = null), f())
                      : (g = !0)
                    : c.complete();
                })
              );
              g && (e.unsubscribe(), (e = null), f());
            };
          f();
        });
  }
  function mf(a, b) {
    return od(Qe(a, b, arguments.length >= 2));
  }
  function nf() {
    var a = a || {};
    var b = a.kk,
      c =
        b === void 0
          ? function () {
              return new Ec();
            }
          : b;
    b = a.Nk;
    var d = b === void 0 ? !0 : b;
    b = a.Ok;
    var e = b === void 0 ? !0 : b;
    a = a.Pk;
    var f = a === void 0 ? !0 : a;
    return function (g) {
      var h = null,
        k = null,
        l = 0,
        m = !1,
        u = !1,
        t = function () {
          h = k = null;
          m = u = !1;
        };
      return od(function (r, w) {
        l++;
        var v;
        k = (v = k) != null ? v : c();
        w.add(function () {
          l--;
          if (f && !l && !u && !m) {
            var A = h;
            t();
            A == null || A.unsubscribe();
          }
        });
        k.subscribe(w);
        !h &&
          l > 0 &&
          ((h = new yc({
            next: function (A) {
              return k.next(A);
            },
            error: function (A) {
              u = !0;
              var C = k;
              e && t();
              C.error(A);
            },
            complete: function () {
              m = !0;
              var A = k;
              d && t();
              A.complete();
            },
          })),
          Vc(r).subscribe(h));
      })(g);
    };
  }
  function of(a) {
    return od(function (b, c) {
      var d = !1,
        e = 0;
      b.subscribe(
        new P(c, function (f) {
          return (d || (d = !a(f, e++))) && c.next(f);
        })
      );
    });
  }
  function T() {
    var a = F.apply(0, arguments),
      b = ed(a);
    return od(function (c, d) {
      (b ? Kd(a, c, b) : Kd(a, c)).subscribe(d);
    });
  }
  function U(a) {
    return od(function (b, c) {
      var d = null,
        e = 0,
        f = !1;
      b.subscribe(
        new P(
          c,
          function (g) {
            var h;
            (h = d) == null || h.unsubscribe();
            h = e++;
            Wc(a(g, h)).subscribe(
              (d = new P(
                c,
                function (k) {
                  return c.next(k);
                },
                void 0,
                function () {
                  d = null;
                  f && !d && c.complete();
                }
              ))
            );
          },
          void 0,
          function () {
            ((f = !0), !d) && c.complete();
          }
        )
      );
    });
  }
  function pf(a, b) {
    b = b === void 0 ? !1 : b;
    return od(function (c, d) {
      var e = 0;
      c.subscribe(
        new P(d, function (f) {
          var g = a(f, e++);
          (g || b) && d.next(f);
          !g && d.complete();
        })
      );
    });
  }
  function qf(a, b, c) {
    var d = M(a) || b || c ? { next: a, error: b, complete: c } : a;
    return d
      ? od(function (e, f) {
          e.subscribe(
            new P(
              f,
              function (g) {
                var h;
                (h = d.next) == null || h.call(d, g);
                f.next(g);
              },
              function (g) {
                var h;
                (h = d.error) == null || h.call(d, g);
                f.error(g);
              },
              function () {
                var g;
                (g = d.complete) == null || g.call(d);
                f.complete();
              }
            )
          );
        })
      : Ac;
  }
  function rf() {
    var a = F.apply(0, arguments),
      b = dd(a);
    return od(function (c, d) {
      for (
        var e = a.length,
          f = Array(e),
          g = a.map(function () {
            return !1;
          }),
          h = !1,
          k = { bb: 0 };
        k.bb < e;
        k = { bb: k.bb }, k.bb++
      )
        Wc(a[k.bb]).subscribe(
          new P(
            d,
            (function (l) {
              return function (m) {
                f[l.bb] = m;
                h ||
                  g[l.bb] ||
                  ((g[l.bb] = !0), (h = g.every(Ac)) && (g = null));
              };
            })(k),
            void 0,
            uc
          )
        );
      c.subscribe(
        new P(d, function (l) {
          h && ((l = [l].concat(y(f))), d.next(b ? b.apply(null, y(l)) : l));
        })
      );
    });
  }
  var sf = function (a) {
    this.ka = a;
  };
  sf.prototype.R = function (a) {
    return (a == null ? 0 : a.Bc)
      ? !0
      : (a == null ? void 0 : a.ha) === "POST" ||
        (a == null ? 0 : a.qb) ||
        (a == null ? 0 : a.xd)
      ? !1
      : this.ka.R();
  };
  sf.prototype.ping = function () {
    var a = this,
      b = fd.apply(null, y(F.apply(0, arguments))).i(
        Id(function (c) {
          return tf(a, c);
        }),
        ef(function (c) {
          return c;
        }),
        kf(1)
      );
    b.connect();
    return b;
  };
  var tf = function (a, b) {
    var c = new id(1);
    uf(
      a.ka,
      b,
      function () {
        c.next(!0);
        c.complete();
      },
      function () {
        c.next(!1);
        c.complete();
      }
    );
    return c;
  };
  sf.prototype.Qd = function (a, b, c) {
    this.ping.apply(this, y(F.apply(3, arguments)));
  };
  function vf(a, b) {
    var c = !1;
    return new O(function (d) {
      var e = a.setTimeout(function () {
        c = !0;
        d.next(!0);
        d.complete();
      }, b);
      return function () {
        c || a.clearTimeout(e);
      };
    });
  }
  var wf = function (a) {
    this.ka = a;
    this.timeline = we;
  };
  n = wf.prototype;
  n.setTimeout = function (a, b) {
    return Number(
      this.ka.setTimeout(function () {
        return a();
      }, b)
    );
  };
  n.clearTimeout = function (a) {
    this.ka.clearTimeout(a);
  };
  n.now = function () {
    return new xe(Date.now(), this.timeline);
  };
  n.interval = function (a, b) {
    var c = this.Ja(a).subscribe(b);
    return function () {
      return void c.unsubscribe();
    };
  };
  n.Ja = function (a) {
    return vf(this, a).i(
      lf(),
      mf(function (b) {
        return b + 1;
      }, -1)
    );
  };
  n.na = function () {
    return !0;
  };
  var xf = function (a, b) {
    this.context = a;
    this.rc = b;
  };
  xf.prototype.R = function (a) {
    return this.rc.R(a);
  };
  xf.prototype.M = function (a, b) {
    if (!this.R(b)) throw new le();
    return new yf(this.context, this.rc, b != null ? b : void 0, a);
  };
  var yf = function (a, b, c, d) {
    var e = this;
    this.rc = b;
    this.properties = c;
    this.url = d;
    this.Hd = !0;
    this.qb = new Map();
    this.body = void 0;
    var f;
    this.method = (f = c == null ? void 0 : c.ha) != null ? f : "GET";
    this.Bh = a.Ee().subscribe(function () {
      e.sendNow();
    });
  };
  yf.prototype.deactivate = function () {
    this.Hd = !1;
  };
  yf.prototype.sendNow = function () {
    if (this.Hd)
      if ((this.Bh.unsubscribe(), this.rc.R(this.properties)))
        try {
          if (this.qb.size > 0 || this.body !== void 0) {
            var a, b;
            this.rc.Qd(
              (a = this.properties) != null ? a : {},
              this.qb,
              (b = this.body) != null ? b : "",
              this.url
            );
          } else this.rc.ping(this.url);
          this.Hd = !1;
        } catch (c) {}
      else this.Hd = !1;
  };
  var Af = function (a, b, c, d, e, f) {
      this.mode = a;
      this.l = b;
      this.setTime = c;
      this.dd = d;
      this.uj = e;
      this.Gh = f;
      this.completed = !1;
      this.id = this.mode === 0 ? zf(this) : 0;
    },
    zf = function (a) {
      return a.l.setTimeout(function () {
        Bf(a);
      }, a.dd);
    },
    Cf = function (a, b) {
      var c = ze(b, a.setTime);
      c >= a.dd ? Bf(a) : ((a.setTime = b), (a.dd -= c));
    },
    Bf = function (a) {
      try {
        a.uj(a.setTime.add(a.dd));
      } finally {
        (a.completed = !0), a.Gh();
      }
    };
  Af.prototype.wf = function (a, b) {
    this.completed ||
      (this.mode === 1 && a === 1
        ? Cf(this, b)
        : this.mode === 1 && a === 0
        ? ((this.mode = a),
          Cf(this, this.l.now()),
          this.completed || (this.id = zf(this)))
        : this.mode === 0 &&
          a === 1 &&
          ((this.mode = a), this.clear(), Cf(this, b)));
  };
  Af.prototype.clear = function () {
    this.completed || this.l.clearTimeout(this.id);
  };
  var Df = function (a) {
    this.yd = a;
    this.ni = this.mode = 0;
    this.hc = {};
    this.timeline = a.timeline;
    this.Eb = a.now();
  };
  n = Df.prototype;
  n.wf = function (a, b) {
    this.mode = a;
    ye(this.Eb, b);
    this.Eb = b;
    Object.values(this.hc).forEach(function (c) {
      return void c.wf(a, b);
    });
  };
  n.now = function () {
    return this.mode === 1 ? this.Eb : this.yd.now();
  };
  n.setTimeout = function (a, b) {
    var c = this,
      d = ++this.ni,
      e = this.mode === 1 ? this.Eb : this.yd.now();
    this.hc[d] = new Af(
      this.mode,
      this.yd,
      e,
      b,
      function (f) {
        var g = c.Eb;
        c.mode === 1 && (c.Eb = f);
        a();
        c.Eb = g;
      },
      function () {
        delete c.hc[d];
      }
    );
    return d;
  };
  n.clearTimeout = function (a) {
    this.hc[a] && (this.hc[a].clear(), delete this.hc[a]);
  };
  n.interval = function () {
    throw Error("F");
  };
  n.Ja = function () {
    throw Error("G");
  };
  n.na = function () {
    return this.yd.na();
  };
  function Ef(a, b) {
    var c = new Df(a);
    a = b.subscribe(function (d) {
      c.wf(d.value ? 1 : 0, d.timestamp);
    });
    return { l: c, uk: a };
  }
  function Ff(a) {
    var b = Object.assign({}, a);
    delete b.timestamp;
    return { timestamp: new xe(a.timestamp, we), value: b };
  }
  function Gf(a) {
    return (
      a !== void 0 &&
      typeof a.x === "number" &&
      typeof a.y === "number" &&
      typeof a.width === "number" &&
      typeof a.height === "number"
    );
  }
  "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT"
    .split(" ")
    .concat(["BUTTON", "INPUT"]);
  function Hf(a) {
    var b = a.indexOf("//") + 2,
      c = a.indexOf("/", b);
    if (c <= b)
      return "Can't interpolate data in a url's origin, Please make sure to fully specify the origin, terminated with '/'.";
    a = a.substring(b, c);
    if (!/^[0-9a-z.:-]+$/i.test(a))
      return "The origin contains unsupported characters.";
    if (!/^[^:]*(:[0-9]+)?$/i.test(a)) return "Invalid port number.";
    if (!/(^|\.)[a-z][^.]*$/i.test(a))
      return "The top-level domain must start with a letter.";
  }
  function If(a) {
    a = a.toLowerCase();
    if (/^data:/.test(a))
      return "Data URLs cannot have expressions in the template literal input.";
    if (/^https:\/\//.test(a) || /^\/\//.test(a)) return Hf(a);
    if (/^\//.test(a))
      return (
        (a =
          a === "/" || (a.length > 1 && a[1] !== "/" && a[1] !== "\\")
            ? void 0
            : "The path start in the url is invalid."),
        a
      );
    if (/^about:blank/.test(a))
      return (
        (a =
          a === "about:blank" || /^about:blank#/.test(a)
            ? void 0
            : "The about url is invalid."),
        a
      );
    if (!RegExp("^[^:\\s\\\\/]+/").test(a))
      return "Trying to interpolate expressions in an unsupported url format. The template literal must start with a compile-time static origin (e.g. 'https://example.com/'), absolute path ('/path/'), or relative path ('path/'). See go/ts-dom-sink#trustedresourceurl.";
  }
  function Jf(a) {
    var b = F.apply(1, arguments),
      c = b.length;
    if (
      !Array.isArray(a) ||
      !Array.isArray(a.raw) ||
      a.length !== a.raw.length ||
      (!vb && a === a.raw) ||
      !((vb && !wb) || tb(a)) ||
      c + 1 !== a.length
    )
      throw new TypeError("x");
    if (b.length === 0) return kb(a[0]);
    c = If(a[0]);
    if (c !== void 0) throw Error(c);
    c = a[0];
    for (var d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
    return kb(c);
  }
  var Kf = qa([
      "https://www.googleadservices.com/pagead/managed/js/activeview/",
      "/reach_worklet.html",
    ]),
    Lf = qa(["./reach_worklet.js"]),
    Mf = qa(["./reach_worklet.js"]),
    Nf = qa(["./reach_worklet.html"]),
    Of = qa(["./reach_worklet.js"]),
    Pf = qa(["./reach_worklet.js"]);
  function Qf(a) {
    var b = {};
    return (b[0] = Jf(Kf, a)), (b[1] = Jf(Lf)), (b[2] = Jf(Mf)), b;
  }
  Jf(Nf);
  Jf(Of);
  Jf(Pf);
  var Sf = function (a, b, c, d) {
    c = c === void 0 ? null : c;
    d = d === void 0 ? Qf("current") : d;
    fe.call(this);
    this.ka = a;
    this.ae = b;
    this.Qa = c;
    this.nf = d;
    this.eb = null;
    this.hf = new id(3);
    this.hf.i(
      R(function (e) {
        return e.value.type === "sessionStart";
      })
    );
    this.kj = this.hf.i(
      R(function (e) {
        return e.value.type === "sessionFinish";
      })
    );
    this.qg = new id(1);
    this.yj = new id();
    this.fg = new id(10);
    this.H = new xf(this, new sf(a));
    this.xi = this.ka.R();
    this.l = Rf(this, new wf(this.ka));
  };
  q(Sf, fe);
  var Tf = function (a) {
    a.eb !== null && Oe(a.eb);
  };
  da.Object.defineProperties(Sf.prototype, {
    global: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return Uf;
      },
    },
  });
  Sf.prototype.validate = function () {
    return this.xi;
  };
  var Rf = function (a, b) {
      a.eb = new Ee(a.ka, a.ae);
      var c = new id();
      Fe(a.eb, function (f) {
        f = Ff(f);
        c.next({ timestamp: f.timestamp, value: !0 });
        a.hf.next(f);
      });
      He(a.eb, function (f) {
        if (f === void 0) var g = !1;
        else {
          g = f.data;
          var h;
          (h = g === void 0) ||
            ((h = g.viewport),
            (h =
              h === void 0 ||
              (h !== void 0 &&
                typeof h.width === "number" &&
                typeof h.height === "number")));
          h
            ? ((g = g.adView),
              (g =
                g !== void 0 &&
                typeof g.percentageInView === "number" &&
                (g.geometry === void 0 || Gf(g.geometry)) &&
                (g.onScreenGeometry === void 0 || Gf(g.onScreenGeometry))))
            : (g = !1);
        }
        g
          ? ((f = Ff(f)),
            c.next({ timestamp: f.timestamp, value: !0 }),
            a.fg.next(f))
          : 0.01 >= Math.random() &&
            ((f =
              "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&name=invalid_geo&context=1092&msg=" +
              JSON.stringify(f)),
            a.H.M(f).sendNow());
      });
      Ge(a.eb, function (f) {
        f = Ff(f);
        c.next({ timestamp: f.timestamp, value: !0 });
        a.yj.next(f);
      });
      Ie(a.eb, function (f) {
        f = Ff(f);
        c.next({ timestamp: f.timestamp, value: !0 });
        a.qg.next(f);
      });
      var d = 0;
      Je(a.eb, function (f) {
        d += f;
        d > 0 && f === 0 && c.next({ timestamp: a.l.now(), value: !1 });
      });
      var e = c.i(
        pf(function (f) {
          return f.value;
        }, !0)
      );
      return Ef(b, e).l;
    },
    Uf = {};
  function Vf(a, b) {
    if (!b) throw Error("H`" + a);
    if (typeof b !== "string" && !(b instanceof String)) throw Error("I`" + a);
    if (b.trim() === "") throw Error("J`" + a);
  }
  function Wf(a) {
    if (!a) throw Error("M`functionToExecute");
  }
  function Xf(a, b) {
    if (b == null) throw Error("K`" + a);
    if (typeof b !== "number" || isNaN(b)) throw Error("L`" + a);
    if (b < 0) throw Error("N`" + a);
  }
  function Yf() {
    return /\d+\.\d+\.\d+(-.*)?/.test("1.6.11-google_20261022");
  }
  function Zf() {
    for (var a = ["1", "6", "11"], b = ["1", "0", "3"], c = 0; c < 3; c++) {
      var d = parseInt(a[c], 10),
        e = parseInt(b[c], 10);
      if (d > e) break;
      else if (d < e) return !1;
    }
    return !0;
  }
  var $f = function (a, b, c, d) {
      this.og = a;
      this.method = b;
      this.version = c;
      this.args = d;
    },
    ag = function (a) {
      return (
        !!a &&
        a.omid_message_guid !== void 0 &&
        a.omid_message_method !== void 0 &&
        a.omid_message_version !== void 0 &&
        typeof a.omid_message_guid === "string" &&
        typeof a.omid_message_method === "string" &&
        typeof a.omid_message_version === "string" &&
        (a.omid_message_args === void 0 || a.omid_message_args !== void 0)
      );
    },
    bg = function (a) {
      return new $f(
        a.omid_message_guid,
        a.omid_message_method,
        a.omid_message_version,
        a.omid_message_args
      );
    };
  $f.prototype.hb = function () {
    var a = {};
    a =
      ((a.omid_message_guid = this.og),
      (a.omid_message_method = this.method),
      (a.omid_message_version = this.version),
      a);
    this.args !== void 0 && (a.omid_message_args = this.args);
    return a;
  };
  var cg = function (a) {
    this.to = a;
  };
  cg.prototype.hb = function () {
    return JSON.stringify(void 0);
  };
  function dg(a, b) {
    try {
      return a.frames && !!a.frames[b];
    } catch (c) {
      return !1;
    }
  }
  var eg = function (a) {
      return [
        "omid_v1_present",
        "omid_v1_present_web",
        "omid_v1_present_app",
      ].some(function (b) {
        return dg(a, b);
      });
    },
    fg = function (a) {
      var b = x(Object.values(Ce)),
        c = b.next();
      try {
        for (; !c.done; c = b.next()) {
          var d = c.value,
            e = {};
          var f = ((e.app = "omid_v1_present_app"),
          (e.web = "omid_v1_present_web"),
          e)[d];
          if (dg(a, f)) return d;
        }
      } finally {
        ra(b, c);
      }
      return null;
    };
  function gg(a, b) {
    return a && (a[b] || (a[b] = {}));
  }
  function hg() {
    return (
      typeof crypto !== "undefined" &&
      typeof crypto.getRandomValues === "function"
    );
  }
  function ig() {
    var a = new Uint8Array(16);
    crypto.getRandomValues(a);
    a[6] = (a[6] & 15) | 64;
    a[8] = (a[8] & 63) | 128;
    for (var b = [], c = 0; c < 16; c++)
      b.push(a[c].toString(16).padStart(2, "0"));
    return (
      b[0] +
      b[1] +
      b[2] +
      b[3] +
      "-" +
      b[4] +
      b[5] +
      "-" +
      b[6] +
      b[7] +
      "-" +
      b[8] +
      b[9] +
      "-" +
      b[10] +
      b[11] +
      b[12] +
      b[13] +
      b[14] +
      b[15]
    );
  }
  function jg() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
      /[xy]/g,
      function (a) {
        var b = (Math.random() * 16) | 0;
        return a === "y" ? ((b & 3) | 8).toString(16) : b.toString(16);
      }
    );
  }
  function kg() {
    var a = F.apply(0, arguments);
    lg(
      function () {
        throw new (Function.prototype.bind.apply(
          Error,
          [null, "Could not complete the test successfully - "].concat(y(a))
        ))();
      },
      function () {
        return console.error.apply(console, y(a));
      }
    );
  }
  function lg(a, b) {
    typeof jasmine !== "undefined" && jasmine
      ? a()
      : typeof console !== "undefined" && console && console.error && b();
  }
  var mg = (function () {
    if (typeof omidGlobal !== "undefined" && omidGlobal) return omidGlobal;
    if (typeof global !== "undefined" && global) return global;
    if (typeof window !== "undefined" && window) return window;
    if (typeof globalThis !== "undefined" && globalThis) return globalThis;
    var a = Function("return this")();
    if (a) return a;
    throw Error("O");
  })();
  var ng = function (a) {
    this.to = a;
    this.handleExportedMessage = ng.prototype.ci.bind(this);
  };
  q(ng, cg);
  ng.prototype.sendMessage = function (a, b) {
    b = b === void 0 ? this.to : b;
    if (!b) throw Error("P");
    b.handleExportedMessage(a.hb(), this);
  };
  ng.prototype.ci = function (a, b) {
    if (ag(a) && this.onMessage) this.onMessage(bg(a), b);
  };
  function og(a) {
    return a != null && typeof a.top !== "undefined" && a.top != null;
  }
  function pg(a) {
    if (a === mg) return !1;
    try {
      if (typeof a.location.hostname === "undefined") return !0;
    } catch (b) {
      return !0;
    }
    return !1;
  }
  function qg() {
    var a;
    typeof a === "undefined" &&
      typeof window !== "undefined" &&
      window &&
      (a = window);
    return og(a) ? a : mg;
  }
  var rg = function (a, b) {
    this.to = b = b === void 0 ? mg : b;
    var c = this;
    a.addEventListener("message", function (d) {
      if (typeof d.data === "object") {
        var e = d.data;
        if (ag(e) && d.source && c.onMessage) c.onMessage(bg(e), d.source);
      }
    });
  };
  q(rg, cg);
  rg.prototype.sendMessage = function (a, b) {
    b = b === void 0 ? this.to : b;
    if (!b) throw Error("P");
    b.postMessage(a.hb(), "*");
  };
  var sg = ["omid", "v1_VerificationServiceCommunication"],
    tg = ["omidVerificationProperties", "serviceWindow"];
  function ug(a, b) {
    return b.reduce(function (c, d) {
      return c && c[d];
    }, a);
  }
  var vg = function (a) {
    if (!a) {
      var b = qg();
      var c = c === void 0 ? eg : c;
      var d = [],
        e = ug(b, tg);
      e && d.push(e);
      d.push(og(b) ? b.top : mg);
      a: {
        d = x(d);
        e = d.next();
        try {
          for (; !e.done; e = d.next()) {
            b: {
              var f = b,
                g = e.value,
                h = c;
              if (!pg(g))
                try {
                  var k = ug(g, sg);
                  if (k) {
                    var l = new ng(k);
                    break b;
                  }
                } catch (m) {}
              l = h(g) ? new rg(f, g) : null;
            }
            if ((f = l)) {
              a = f;
              break a;
            }
          }
        } finally {
          ra(d, e);
        }
        a = null;
      }
    }
    if ((this.Fc = a)) this.Fc.onMessage = this.di.bind(this);
    else if (
      (c =
        (c = mg.omid3p) &&
        typeof c.registerSessionObserver === "function" &&
        typeof c.addEventListener === "function"
          ? c
          : null)
    )
      this.Yc = c;
    this.bj = this.cj = 0;
    this.ne = {};
    this.Ie = [];
    (this.fc = (c = mg.omidVerificationProperties) ? c.injectionId : void 0) ||
      (hg() ? ig() : jg());
  };
  vg.prototype.R = function () {
    var a = qg();
    var b =
      (b = mg.omidVerificationProperties) && b.injectionSource
        ? b.injectionSource
        : void 0;
    return (b || fg(a) || fg(og(a) ? a.top : mg)) !== "web" || this.fc
      ? !(!this.Fc && !this.Yc)
      : !1;
  };
  var Le = function (a, b, c) {
    Wf(b);
    a.Yc
      ? a.Yc.registerSessionObserver(b, c, a.fc)
      : a.vc("addSessionListener", b, c, a.fc);
  };
  vg.prototype.addEventListener = function (a, b) {
    Vf("eventType", a);
    Wf(b);
    this.Yc
      ? this.Yc.addEventListener(a, b, this.fc)
      : this.vc("addEventListener", b, a, this.fc);
  };
  var uf = function (a, b, c, d) {
      Vf("url", b);
      mg.document && mg.document.createElement
        ? wg(a, b, c, d)
        : a.vc(
            "sendUrl",
            function (e) {
              e && c ? c() : !e && d && d();
            },
            b
          );
    },
    wg = function (a, b, c, d) {
      var e = mg.document.createElement("img");
      a.Ie.push(e);
      var f = function (g) {
        var h = a.Ie.indexOf(e);
        h >= 0 && a.Ie.splice(h, 1);
        g && g();
      };
      e.addEventListener("load", f.bind(a, c));
      e.addEventListener("error", f.bind(a, d));
      e.src = b;
    };
  vg.prototype.setTimeout = function (a, b) {
    Wf(a);
    Xf("timeInMillis", b);
    if (xg()) return mg.setTimeout(a, b);
    var c = this.cj++;
    this.vc("setTimeout", a, c, b);
    return c;
  };
  vg.prototype.clearTimeout = function (a) {
    Xf("timeoutId", a);
    xg() ? mg.clearTimeout(a) : this.Qg("clearTimeout", a);
  };
  vg.prototype.setInterval = function (a, b) {
    Wf(a);
    Xf("timeInMillis", b);
    if (yg()) return mg.setInterval(a, b);
    var c = this.bj++;
    this.vc("setInterval", a, c, b);
    return c;
  };
  vg.prototype.clearInterval = function (a) {
    Xf("intervalId", a);
    yg() ? mg.clearInterval(a) : this.Qg("clearInterval", a);
  };
  var xg = function () {
      return (
        typeof mg.setTimeout === "function" &&
        typeof mg.clearTimeout === "function"
      );
    },
    yg = function () {
      return (
        typeof mg.setInterval === "function" &&
        typeof mg.clearInterval === "function"
      );
    };
  vg.prototype.di = function (a) {
    var b = a.method,
      c = a.og;
    a = a.args;
    if (b === "response" && this.ne[c]) {
      var d =
        Yf() && Zf()
          ? a
            ? a
            : []
          : a && typeof a === "string"
          ? JSON.parse(a)
          : [];
      this.ne[c].apply(this, d);
    }
    b === "error" && window.console && kg(a);
  };
  vg.prototype.Qg = function (a) {
    this.vc.apply(this, [a, null].concat(y(F.apply(1, arguments))));
  };
  vg.prototype.vc = function (a, b) {
    var c = F.apply(2, arguments);
    if (this.Fc) {
      var d = hg() ? ig() : jg();
      b && (this.ne[d] = b);
      var e = "VerificationService." + a;
      c = Yf() && Zf() ? c : JSON.stringify(c);
      this.Fc.sendMessage(new $f(d, e, "1.6.11-google_20261022", c));
    }
  };
  var zg = void 0;
  if (
    (zg =
      zg === void 0
        ? typeof omidExports === "undefined"
          ? null
          : omidExports
        : zg)
  ) {
    var Ag = ["OmidVerificationClient"];
    Ag.slice(0, Ag.length - 1).reduce(gg, zg)[Ag[Ag.length - 1]] = vg;
  }
  function Bg(a, b) {
    return function (c) {
      return new O(function (d) {
        return c.subscribe(
          function (e) {
            a.yc(b, function () {
              d.next(e);
            })();
          },
          function (e) {
            a.yc(b, function () {
              d.error(e);
            })();
          },
          function () {
            a.yc(b, function () {
              d.complete();
            })();
          }
        );
      });
    };
  }
  var Dg = function () {
    var a = x(F.apply(0, arguments)),
      b = a.next();
    try {
      for (; !b.done; b = a.next()) {
        var c = b.value;
        if (c.na()) {
          this.l = c;
          return;
        }
      }
    } finally {
      ra(a, b);
    }
    this.l = new Cg();
  };
  n = Dg.prototype;
  n.na = function () {
    return this.l.na();
  };
  n.now = function () {
    return this.l.now();
  };
  n.setTimeout = function (a, b) {
    return this.l.setTimeout(a, b);
  };
  n.clearTimeout = function (a) {
    this.l.clearTimeout(a);
  };
  n.interval = function (a, b) {
    var c = this.Ja(a).subscribe(b);
    return function () {
      return void c.unsubscribe();
    };
  };
  n.Ja = function (a) {
    return this.l.Ja(a);
  };
  da.Object.defineProperties(Dg.prototype, {
    timeline: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.l.timeline;
      },
    },
  });
  var Cg = function () {
    this.timeline = Symbol();
  };
  n = Cg.prototype;
  n.na = function () {
    return !1;
  };
  n.now = function () {
    return new xe(0, this.timeline);
  };
  n.setTimeout = function () {
    return 0;
  };
  n.clearTimeout = function () {};
  n.interval = function () {
    return function () {};
  };
  n.Ja = function () {
    return Xd;
  };
  var Eg = function (a, b) {
    this.P = a;
    this.J = b;
  };
  n = Eg.prototype;
  n.setTimeout = function (a, b) {
    return this.P.setTimeout(this.J.yc(734, a), b);
  };
  n.clearTimeout = function (a) {
    this.P.clearTimeout(a);
  };
  n.interval = function (a, b) {
    var c = this.Ja(a).subscribe(b);
    return function () {
      return void c.unsubscribe();
    };
  };
  n.Ja = function (a) {
    var b = this;
    return new O(function (c) {
      var d = 0,
        e = b.P.setInterval(function () {
          c.next(d++);
        }, a);
      return function () {
        b.P.clearInterval(e);
      };
    });
  };
  n.na = function () {
    return (
      !!this.P.clearTimeout &&
      "setTimeout" in this.P &&
      "setInterval" in this.P &&
      !!this.P.clearInterval
    );
  };
  var Fg = function (a, b) {
    Eg.call(this, a, b);
    this.timeline = we;
  };
  q(Fg, Eg);
  Fg.prototype.now = function () {
    return new xe(this.P.Date.now(), this.timeline);
  };
  Fg.prototype.na = function () {
    return !!this.P.Date && !!this.P.Date.now && Eg.prototype.na.call(this);
  };
  var Gg = function (a, b) {
    Eg.call(this, a, b);
    this.timeline = ve;
  };
  q(Gg, Eg);
  Gg.prototype.now = function () {
    return new xe(this.P.performance.now(), this.timeline);
  };
  Gg.prototype.na = function () {
    return (
      !!this.P.performance &&
      !!this.P.performance.now &&
      Eg.prototype.na.call(this)
    );
  };
  function Hg(a) {
    a = a.global;
    if (a.fetchLater) return a.fetchLater.bind(a);
  }
  function Ig(a) {
    var b,
      c,
      d =
        (b = a.global) == null
          ? void 0
          : (c = b.document) == null
          ? void 0
          : c.createElement("meta");
    if (d)
      try {
        return (
          (d.httpEquiv = "origin-trial"),
          (d.content =
            "AxjhRadLCARYRJawRjMjq4U8V8okQvSnrBIJWdMajuEkN3/DfVAcLcFhMVrUWnOXagwlI8dQD84FwJDGj9ohqAYAAABveyJvcmlnaW4iOiJodHRwczovL2dvb2dsZWFkc2VydmljZXMuY29tOjQ0MyIsImZlYXR1cmUiOiJGZXRjaExhdGVyQVBJIiwiZXhwaXJ5IjoxNzI1NDA3OTk5LCJpc1RoaXJkUGFydHkiOnRydWV9"),
          a.global.document.head.append(d),
          d
        );
      } catch (e) {}
  }
  var Kg = function (a) {
      this.context = a;
      Jg === void 0 && (Jg = Ig(a));
    },
    Jg;
  Kg.prototype.R = function (a) {
    return (
      Hg(this.context) !== void 0 &&
      !(a == null || !a.Oh) &&
      !Lg(this.context) &&
      !(a == null ? 0 : a.Bc) &&
      !(a == null ? 0 : a.qb) &&
      !(a == null ? 0 : a.xd)
    );
  };
  Kg.prototype.M = function (a, b) {
    if (!this.R(b)) throw new le();
    return new Pg(this.context, a, b);
  };
  var Pg = function (a, b, c) {
      this.context = a;
      this.properties = c;
      this.Sb = b;
      var d;
      this.ha = (d = c == null ? void 0 : c.ha) != null ? d : "GET";
      a = Hg(this.context);
      if (a === void 0) throw Error();
      this.fetchLater = a;
      Qg(this, this.Sc());
    },
    Qg = function (a, b) {
      (a.Ya && a.Ya.activated) ||
        ((a.Cc = new AbortController()),
        (a.Ya = a.fetchLater(b, {
          method: a.ha,
          cache: "no-cache",
          mode: "no-cors",
          signal: a.Cc.signal,
          activateAfter: 96e4,
        })));
    };
  Pg.prototype.Sc = function () {
    var a = this.Sb;
    return (a.slice(-1)[0] === "&" ? a : a + "&") + "flapi=1";
  };
  Pg.prototype.deactivate = function () {
    this.Ya &&
      !this.Ya.activated &&
      this.Cc &&
      (this.Cc.abort(), (this.Ya = void 0));
  };
  da.Object.defineProperties(Pg.prototype, {
    url: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.Sb;
      },
      set: function (a) {
        this.Sb = a;
        a = this.Sc();
        (this.Ya && this.Ya.activated) ||
          !this.Cc ||
          (this.Cc.abort(), (this.Ya = void 0));
        Qg(this, a);
      },
    },
  });
  Pg.prototype.sendNow = function () {};
  da.Object.defineProperties(Pg.prototype, {
    method: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.ha;
      },
    },
  });
  var Rg = function (a) {
    this.context = a;
  };
  Rg.prototype.R = function () {
    return !Lg(this.context) && !!this.context.global.fetch;
  };
  Rg.prototype.ping = function () {
    var a = this;
    return Wd.apply(
      null,
      y(
        F.apply(0, arguments).map(function (b) {
          return Vc(
            a.context.global.fetch(b, {
              method: "GET",
              cache: "no-cache",
              keepalive: !0,
              mode: "no-cors",
            })
          ).i(
            Q(function (c) {
              return c.status === 200;
            })
          );
        })
      )
    ).i(
      ef(function (b) {
        return b;
      }),
      gf()
    );
  };
  Rg.prototype.Qd = function (a, b, c) {
    var d = F.apply(3, arguments),
      e = this,
      f = new Headers(),
      g = x(b.entries()),
      h = g.next();
    try {
      for (; !h.done; h = g.next()) {
        var k = x(h.value),
          l = k.next().value,
          m = k.next().value;
        f.set(l, m);
      }
    } finally {
      ra(g, h);
    }
    var u,
      t = (u = a.keepAlive) != null ? u : !1;
    Wd.apply(
      null,
      y(
        d.map(function (r) {
          return Vc(
            e.context.global.fetch(
              r,
              z(
                {},
                { method: String(a.ha), cache: "no-cache" },
                t ? { keepalive: !0 } : {},
                { mode: "no-cors", headers: f, body: c }
              )
            )
          ).i(
            Q(function (w) {
              return w.status === 200;
            })
          );
        })
      )
    ).i(
      ef(function (r) {
        return r;
      }),
      gf()
    );
  };
  var Sg = function (a) {
    Sg[" "](a);
    return a;
  };
  Sg[" "] = function () {};
  var Tg = function (a, b) {
    try {
      return Sg(a[b]), !0;
    } catch (c) {}
    return !1;
  };
  function Ug(a) {
    try {
      return !!a && a.location.href != null && Tg(a, "foo");
    } catch (b) {
      return !1;
    }
  }
  function Vg() {
    var a = Oa.navigator;
    return a && (a = a.userAgent) ? a : "";
  }
  function V(a) {
    return Vg().indexOf(a) != -1;
  }
  function Wg() {
    return V("Firefox") || V("FxiOS");
  }
  function Xg() {
    return (
      V("Safari") &&
      !(
        Yg() ||
        V("Coast") ||
        V("Opera") ||
        V("Edge") ||
        V("Edg/") ||
        V("OPR") ||
        Wg() ||
        V("Silk") ||
        V("Android")
      )
    );
  }
  function Yg() {
    return ((V("Chrome") || V("CriOS")) && !V("Edge")) || V("Silk");
  }
  function Zg() {
    return V("Android") && !(Yg() || Wg() || V("Opera") || V("Silk"));
  }
  function $g() {
    return !ah() && (V("iPod") || V("iPhone") || V("Android") || V("IEMobile"));
  }
  function ah() {
    return V("iPad") || (V("Android") && !V("Mobile")) || V("Silk");
  }
  function bh() {
    return V("iPhone") && !V("iPod") && !V("iPad");
  }
  function ch() {
    bh() || V("iPad") || V("iPod");
  }
  V("Opera");
  var dh = V("Trident") || V("MSIE");
  V("Edge");
  var eh =
      V("Gecko") &&
      !(cb(Vg(), "WebKit") && !V("Edge")) &&
      !(V("Trident") || V("MSIE")) &&
      !V("Edge"),
    fh = cb(Vg(), "WebKit") && !V("Edge");
  fh && V("Mobile");
  V("Macintosh");
  V("Windows");
  V("Linux") || V("CrOS");
  V("Android");
  bh();
  V("iPad");
  V("iPod");
  ch();
  cb(Vg(), "KaiOS");
  function gh(a, b) {
    b = b === void 0 ? new Set() : b;
    if (b.has(a)) return "(Recursive reference)";
    switch (typeof a) {
      case "object":
        if (a) {
          var c = Object.getPrototypeOf(a);
          switch (c) {
            case Map.prototype:
            case Set.prototype:
            case Array.prototype:
              b.add(a);
              var d =
                "[" +
                Array.from(a, function (e) {
                  return gh(e, b);
                }).join(", ") +
                "]";
              b.delete(a);
              c !== Array.prototype && (d = hh(c.constructor) + "(" + d + ")");
              return d;
            case Object.prototype:
              return (
                b.add(a),
                (c =
                  "{" +
                  Object.entries(a)
                    .map(function (e) {
                      var f = x(e);
                      e = f.next().value;
                      f = f.next().value;
                      return e + ": " + gh(f, b);
                    })
                    .join(", ") +
                  "}"),
                b.delete(a),
                c
              );
            default:
              return (
                (d = "Object"),
                c && c.constructor && (d = hh(c.constructor)),
                typeof a.toString === "function" &&
                a.toString !== Object.prototype.toString
                  ? d + "(" + String(a) + ")"
                  : "(object " + d + ")"
              );
          }
        }
        break;
      case "function":
        return "function " + hh(a);
      case "number":
        if (!Number.isFinite(a)) return String(a);
        break;
      case "bigint":
        return a.toString(10) + "n";
      case "symbol":
        return a.toString();
    }
    return JSON.stringify(a);
  }
  function hh(a) {
    var b = a.displayName;
    return (b && typeof b === "string") ||
      ((b = a.name) && typeof b === "string")
      ? b
      : (a = /function\s+([^\(]+)/m.exec(String(a)))
      ? a[1]
      : "(Anonymous)";
  }
  function ih(a, b) {
    var c = jh,
      d = [];
    kh(b, a, d) ||
      lh.apply(
        null,
        [void 0, c, "Guard " + b.Ge().trim() + " failed:"].concat(
          y(d.reverse())
        )
      );
  }
  function mh(a, b) {
    ih(a, b);
    return a;
  }
  function nh(a) {
    var b = jh;
    a || lh("Guard truthy failed:", b || "Expected truthy, got " + gh(a));
  }
  function oh(a) {
    return mh(a, ph);
  }
  function qh(a) {
    var b = jh;
    lh("Assertion fail:", a || b);
  }
  function rh(a, b) {
    a.nk = !0;
    a.Ge =
      typeof b === "function"
        ? b
        : function () {
            return b;
          };
    return a;
  }
  function kh(a, b, c) {
    var d = a(b, c);
    d ||
      sh(c, function () {
        var e = "";
        e.length > 0 && (e += ": ");
        return e + "Expected " + a.Ge().trim() + ", got " + gh(b);
      });
    return d;
  }
  function sh(a, b) {
    a == null || a.push((typeof b === "function" ? b() : b).trim());
  }
  var jh = void 0;
  function th(a) {
    return typeof a === "function" ? a() : a;
  }
  function lh() {
    throw Error(
      F.apply(0, arguments)
        .map(th)
        .filter(Boolean)
        .join("\n")
        .trim()
        .replace(/:$/, "")
    );
  }
  var ph = rh(function (a) {
    return a !== null && a !== void 0;
  }, "exists");
  var uh = rh(function (a) {
      return typeof a === "number";
    }, "number"),
    vh = rh(function (a) {
      return typeof a === "string";
    }, "string"),
    wh = rh(function (a) {
      return typeof a === "boolean";
    }, "boolean"),
    xh = rh(function (a) {
      return typeof a === "bigint";
    }, "bigint"),
    yh = rh(function (a) {
      return typeof a === "function";
    }, "Function");
  function zh(a) {
    return rh(
      function (b) {
        return b instanceof a;
      },
      function () {
        return hh(a);
      }
    );
  }
  function Ah() {
    var a = F.apply(0, arguments);
    return rh(
      function (b) {
        return a.some(function (c) {
          return c(b);
        });
      },
      function () {
        return (
          "" +
          a
            .map(function (b) {
              return b.Ge().trim();
            })
            .join(" | ")
        );
      }
    );
  }
  function Bh(a, b) {
    this.x = a !== void 0 ? a : 0;
    this.y = b !== void 0 ? b : 0;
  }
  n = Bh.prototype;
  n.clone = function () {
    return new Bh(this.x, this.y);
  };
  n.toString = function () {
    return "(" + this.x + ", " + this.y + ")";
  };
  n.equals = function (a) {
    return (
      a instanceof Bh &&
      (this == a ? !0 : this && a ? this.x == a.x && this.y == a.y : !1)
    );
  };
  n.ceil = function () {
    this.x = Math.ceil(this.x);
    this.y = Math.ceil(this.y);
    return this;
  };
  n.floor = function () {
    this.x = Math.floor(this.x);
    this.y = Math.floor(this.y);
    return this;
  };
  n.round = function () {
    this.x = Math.round(this.x);
    this.y = Math.round(this.y);
    return this;
  };
  n.translate = function (a, b) {
    a instanceof Bh
      ? ((this.x += a.x), (this.y += a.y))
      : ((this.x += Number(a)), typeof b === "number" && (this.y += b));
    return this;
  };
  n.scale = function (a, b) {
    b = typeof b === "number" ? b : a;
    this.x *= a;
    this.y *= b;
    return this;
  };
  function Ch(a, b) {
    this.width = a;
    this.height = b;
  }
  n = Ch.prototype;
  n.clone = function () {
    return new Ch(this.width, this.height);
  };
  n.toString = function () {
    return "(" + this.width + " x " + this.height + ")";
  };
  n.aspectRatio = function () {
    return this.width / this.height;
  };
  n.isEmpty = function () {
    return !(this.width * this.height);
  };
  n.ceil = function () {
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this;
  };
  n.floor = function () {
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this;
  };
  n.round = function () {
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this;
  };
  n.scale = function (a, b) {
    b = typeof b === "number" ? b : a;
    this.width *= a;
    this.height *= b;
    return this;
  };
  var Fh = function (a) {
      return a ? new Dh(Eh(a)) : Cb || (Cb = new Dh());
    },
    Gh = function (a) {
      var b = a.scrollingElement
        ? a.scrollingElement
        : fh || a.compatMode != "CSS1Compat"
        ? a.body || a.documentElement
        : a.documentElement;
      a = a.defaultView;
      return new Bh(
        (a == null ? void 0 : a.pageXOffset) || b.scrollLeft,
        (a == null ? void 0 : a.pageYOffset) || b.scrollTop
      );
    },
    Hh = function (a, b, c) {
      function d(h) {
        h && b.appendChild(typeof h === "string" ? a.createTextNode(h) : h);
      }
      for (var e = 1; e < c.length; e++) {
        var f = c[e];
        if (!Ra(f) || (Sa(f) && f.nodeType > 0)) d(f);
        else {
          a: {
            if (f && typeof f.length == "number") {
              if (Sa(f)) {
                var g =
                  typeof f.item == "function" || typeof f.item == "string";
                break a;
              }
              if (typeof f === "function") {
                g = typeof f.item == "function";
                break a;
              }
            }
            g = !1;
          }
          Mb(g ? Qb(f) : f, d);
        }
      }
    },
    Eh = function (a) {
      H(a, "Node cannot be null or undefined.");
      return a.nodeType == 9 ? a : a.ownerDocument || a.document;
    },
    Ih = function (a, b) {
      a && (a = a.parentNode);
      for (var c = 0; a; ) {
        H(a.name != "parentNode");
        if (b(a)) return a;
        a = a.parentNode;
        c++;
      }
      return null;
    },
    Dh = function (a) {
      this.Jc = a || Oa.document || document;
    };
  n = Dh.prototype;
  n.getElementsByTagName = function (a, b) {
    return (b || this.Jc).getElementsByTagName(String(a));
  };
  n.createElement = function (a) {
    var b = this.Jc;
    a = String(a);
    b.contentType === "application/xhtml+xml" && (a = a.toLowerCase());
    return b.createElement(a);
  };
  n.createTextNode = function (a) {
    return this.Jc.createTextNode(String(a));
  };
  n.appendChild = function (a, b) {
    H(
      a != null && b != null,
      "goog.dom.appendChild expects non-null arguments"
    );
    a.appendChild(b);
  };
  n.append = function (a, b) {
    Hh(Eh(a), a, arguments);
  };
  n.canHaveChildren = function (a) {
    if (a.nodeType != 1) return !1;
    switch (a.tagName) {
      case "APPLET":
      case "AREA":
      case "BASE":
      case "BR":
      case "COL":
      case "COMMAND":
      case "EMBED":
      case "FRAME":
      case "HR":
      case "IMG":
      case "INPUT":
      case "IFRAME":
      case "ISINDEX":
      case "KEYGEN":
      case "LINK":
      case "NOFRAMES":
      case "NOSCRIPT":
      case "META":
      case "OBJECT":
      case "PARAM":
      case "SCRIPT":
      case "SOURCE":
      case "STYLE":
      case "TRACK":
      case "WBR":
        return !1;
    }
    return !0;
  };
  n.removeNode = function (a) {
    return a && a.parentNode ? a.parentNode.removeChild(a) : null;
  };
  n.isElement = function (a) {
    return Sa(a) && a.nodeType == 1;
  };
  n.contains = function (a, b) {
    if (!a || !b) return !1;
    if (a.contains && b.nodeType == 1) return a == b || a.contains(b);
    if (typeof a.compareDocumentPosition != "undefined")
      return a == b || !!(a.compareDocumentPosition(b) & 16);
    for (; b && a != b; ) b = b.parentNode;
    return b == a;
  };
  function Jh(a, b, c, d) {
    this.top = a;
    this.right = b;
    this.bottom = c;
    this.left = d;
  }
  n = Jh.prototype;
  n.ng = function () {
    return this.right - this.left;
  };
  n.kg = function () {
    return this.bottom - this.top;
  };
  n.clone = function () {
    return new Jh(this.top, this.right, this.bottom, this.left);
  };
  n.toString = function () {
    return (
      "(" +
      this.top +
      "t, " +
      this.right +
      "r, " +
      this.bottom +
      "b, " +
      this.left +
      "l)"
    );
  };
  n.contains = function (a) {
    return this && a
      ? a instanceof Jh
        ? a.left >= this.left &&
          a.right <= this.right &&
          a.top >= this.top &&
          a.bottom <= this.bottom
        : a.x >= this.left &&
          a.x <= this.right &&
          a.y >= this.top &&
          a.y <= this.bottom
      : !1;
  };
  n.expand = function (a, b, c, d) {
    Sa(a)
      ? ((this.top -= a.top),
        (this.right += a.right),
        (this.bottom += a.bottom),
        (this.left -= a.left))
      : ((this.top -= a),
        (this.right += Number(b)),
        (this.bottom += Number(c)),
        (this.left -= Number(d)));
    return this;
  };
  n.ceil = function () {
    this.top = Math.ceil(this.top);
    this.right = Math.ceil(this.right);
    this.bottom = Math.ceil(this.bottom);
    this.left = Math.ceil(this.left);
    return this;
  };
  n.floor = function () {
    this.top = Math.floor(this.top);
    this.right = Math.floor(this.right);
    this.bottom = Math.floor(this.bottom);
    this.left = Math.floor(this.left);
    return this;
  };
  n.round = function () {
    this.top = Math.round(this.top);
    this.right = Math.round(this.right);
    this.bottom = Math.round(this.bottom);
    this.left = Math.round(this.left);
    return this;
  };
  n.translate = function (a, b) {
    a instanceof Bh
      ? ((this.left += a.x),
        (this.right += a.x),
        (this.top += a.y),
        (this.bottom += a.y))
      : (Gb(a),
        (this.left += a),
        (this.right += a),
        typeof b === "number" && ((this.top += b), (this.bottom += b)));
    return this;
  };
  n.scale = function (a, b) {
    b = typeof b === "number" ? b : a;
    this.left *= a;
    this.right *= a;
    this.top *= b;
    this.bottom *= b;
    return this;
  };
  var Kh = function (a) {
    try {
      return a.getBoundingClientRect();
    } catch (b) {
      return { left: 0, top: 0, right: 0, bottom: 0 };
    }
  };
  function Lh(a, b, c) {
    typeof a.addEventListener === "function" && a.addEventListener(b, c, !1);
  }
  var Mh = function (a) {
    this.context = a;
  };
  Mh.prototype.R = function (a) {
    return (a == null ? 0 : a.Bc) ||
      (a == null ? void 0 : a.ha) === "POST" ||
      (a == null ? 0 : a.qb) ||
      (a == null ? 0 : a.xd) ||
      (a == null ? 0 : a.keepAlive)
      ? !1
      : !Lg(this.context);
  };
  Mh.prototype.ping = function () {
    var a = this;
    return fd(
      F.apply(0, arguments)
        .map(function (b) {
          try {
            var c = a.context.global,
              d = !1;
            d = d === void 0 ? !1 : d;
            c.google_image_requests || (c.google_image_requests = []);
            var e = c.document;
            e = e === void 0 ? document : e;
            var f = e.createElement("img");
            d && (f.attributionSrc = "");
            f.src = b;
            c.google_image_requests.push(f);
            return !0;
          } catch (g) {
            return !1;
          }
        })
        .every(function (b) {
          return b;
        })
    );
  };
  Mh.prototype.Qd = function (a, b, c) {
    this.ping.apply(this, y(F.apply(3, arguments)));
  };
  function Nh(a) {
    a = a.global;
    if (a.PendingGetBeacon) return a.PendingGetBeacon;
  }
  var Oh = function (a) {
    this.context = a;
  };
  Oh.prototype.R = function (a) {
    return (
      Ph &&
      !Lg(this.context) &&
      Nh(this.context) !== void 0 &&
      !(a == null ? 0 : a.Bc) &&
      (a == null ? void 0 : a.ha) !== "POST" &&
      !(a == null ? 0 : a.qb) &&
      !(a == null ? 0 : a.xd)
    );
  };
  Oh.prototype.M = function (a, b) {
    if (!this.R(b)) throw new le();
    return new Qh(this.context, a);
  };
  var Ph = !1,
    Qh = function (a, b) {
      this.context = a;
      this.Sb = b;
      a = Nh(this.context);
      if (a === void 0) throw Error();
      this.Af = new a(this.Sc(), {});
    };
  Qh.prototype.Sc = function () {
    var a = this.Sb;
    return (a.slice(-1)[0] === "&" ? a : a + "&") + "pbapi=1";
  };
  Qh.prototype.deactivate = function () {
    this.Af.deactivate();
  };
  da.Object.defineProperties(Qh.prototype, {
    url: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.Sb;
      },
      set: function (a) {
        this.Sb = a;
        this.Af.setURL(this.Sc());
      },
    },
  });
  Qh.prototype.sendNow = function () {
    this.Af.sendNow();
  };
  da.Object.defineProperties(Qh.prototype, {
    method: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return "GET";
      },
      set: function (a) {
        if (a !== "GET") throw new le();
      },
    },
  });
  var Rh = function (a) {
    this.context = a;
  };
  Rh.prototype.R = function (a) {
    if (
      (a == null ? 0 : a.Bc) ||
      (a == null ? void 0 : a.ha) === "GET" ||
      (a == null ? 0 : a.qb) ||
      (a == null ? 0 : a.xd) ||
      (a == null ? 0 : a.keepAlive)
    )
      return !1;
    var b;
    return (
      !Lg(this.context) &&
      ((b = this.context.global.navigator) == null ? void 0 : b.sendBeacon) !==
        void 0
    );
  };
  Rh.prototype.ping = function () {
    var a = this;
    return fd(
      F.apply(0, arguments)
        .map(function (b) {
          var c;
          return (c = a.context.global.navigator) == null
            ? void 0
            : c.sendBeacon(b);
        })
        .every(function (b) {
          return b;
        })
    );
  };
  Rh.prototype.Qd = function (a, b, c) {
    this.ping.apply(this, y(F.apply(3, arguments)));
  };
  function Sh(a) {
    return function (b) {
      return b.i(Th(a, hf(new Ec())));
    };
  }
  function W(a, b) {
    return function (c) {
      return c.i(Th(a, kf(b)));
    };
  }
  function Th(a, b) {
    function c(d) {
      return new O(function (e) {
        return d.subscribe(
          function (f) {
            ab(
              a,
              function () {
                return void e.next(f);
              },
              3
            );
          },
          function (f) {
            ab(
              a,
              function () {
                return void e.error(f);
              },
              3
            );
          },
          function () {
            ab(
              a,
              function () {
                return void e.complete();
              },
              3
            );
          }
        );
      });
    }
    return N(c, sd(), b, pd(), c);
  }
  var X = function (a) {
    this.value = a;
  };
  X.prototype.S = function (a) {
    return fd(this.value).i(W(a, 1));
  };
  var Uh = new X(!1);
  function Vh(a) {
    Oa.setTimeout(function () {
      throw a;
    }, 0);
  }
  var Wh = Pa(1, !0);
  Pa(899588437, !0);
  Pa(772657768, !0);
  Pa(513659523, !0);
  Pa(568333945, !0);
  Pa(651175828, !0);
  Pa(722764542, !0);
  Pa(748402145, !0);
  Pa(748402146, !0);
  var Xh = Pa(748402147, !0);
  Pa(1602613185, !0);
  Pa(861377723, !0);
  Pa(861377724, !0);
  Pa(869336903, !0);
  Pa(882674507, !0);
  Pa(869336904, !0);
  Pa(869336905, !0);
  Pa(386066704, !1);
  Pa(1329341681, !1);
  Pa(283953155, !0);
  Pa(995371348, !0);
  Pa(582785864, !0);
  Pa(408176738, !1);
  Pa(1014124192, !0);
  Pa(262854461, !1);
  Pa(955500419, !0);
  Pa(683749201, !1);
  Pa(1240557993, !0);
  Pa(2147483644, !1);
  Pa(2147483645, !0);
  Pa(2147483646, Wh);
  Pa(2147483647, !0);
  Wg();
  bh() || V("iPod");
  V("iPad");
  Zg();
  Yg();
  Xg() && ch();
  var Yh = {},
    Zh = null,
    $h = eh || fh || typeof Oa.btoa == "function";
  function ai(a) {
    var b;
    H(Ra(a), "encodeByteArray takes an array as a parameter");
    b === void 0 && (b = 0);
    bi();
    b = Yh[b];
    for (
      var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0;
      e < a.length - 2;
      e += 3
    ) {
      var g = a[e],
        h = a[e + 1],
        k = a[e + 2],
        l = b[g >> 2];
      g = b[((g & 3) << 4) | (h >> 4)];
      h = b[((h & 15) << 2) | (k >> 6)];
      k = b[k & 63];
      c[f++] = "" + l + g + h + k;
    }
    l = 0;
    k = d;
    switch (a.length - e) {
      case 2:
        (l = a[e + 1]), (k = b[(l & 15) << 2] || d);
      case 1:
        (a = a[e]),
          (c[f] = "" + b[a >> 2] + b[((a & 3) << 4) | (l >> 4)] + k + d);
    }
    return c.join("");
  }
  function ci(a) {
    var b = a.length,
      c = (b * 3) / 4;
    c % 3
      ? (c = Math.floor(c))
      : "=.".indexOf(a[b - 1]) != -1 &&
        (c = "=.".indexOf(a[b - 2]) != -1 ? c - 2 : c - 1);
    var d = new Uint8Array(c),
      e = 0;
    di(a, function (f) {
      d[e++] = f;
    });
    return e !== c ? d.subarray(0, e) : d;
  }
  function di(a, b) {
    function c(k) {
      for (; d < a.length; ) {
        var l = a.charAt(d++),
          m = Zh[l];
        if (m != null) return m;
        if (!/^[\s\xa0]*$/.test(l)) throw Error("R`" + l);
      }
      return k;
    }
    bi();
    for (var d = 0; ; ) {
      var e = c(-1),
        f = c(0),
        g = c(64),
        h = c(64);
      if (h === 64 && e === -1) break;
      b((e << 2) | (f >> 4));
      g != 64 &&
        (b(((f << 4) & 240) | (g >> 2)), h != 64 && b(((g << 6) & 192) | h));
    }
  }
  function bi() {
    if (!Zh) {
      Zh = {};
      for (
        var a =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(
              ""
            ),
          b = ["+/=", "+/", "-_=", "-_.", "-_"],
          c = 0;
        c < 5;
        c++
      ) {
        var d = a.concat(b[c].split(""));
        Yh[c] = d;
        for (var e = 0; e < d.length; e++) {
          var f = d[e],
            g = Zh[f];
          g === void 0 ? (Zh[f] = e) : H(g === e);
        }
      }
    }
  }
  function ei(a) {
    var b = fi(a);
    return b === null
      ? new X(null)
      : b.i(
          Q(function (c) {
            c = c.hb();
            if ($h) c = Oa.btoa(c);
            else {
              for (var d = [], e = 0, f = 0; f < c.length; f++) {
                var g = c.charCodeAt(f);
                if (g > 255) throw Error("Q");
                d[e++] = g;
              }
              c = ai(d);
            }
            return c;
          }),
          Ye(1),
          W(a.queue, 1)
        );
  }
  function gi(a) {
    var b = b === void 0 ? {} : b;
    if (typeof Event === "function") return new Event(a, b);
    if (typeof document !== "undefined") {
      var c = document.createEvent("CustomEvent");
      c.initCustomEvent(a, b.bubbles || !1, b.cancelable || !1, b.detail);
      return c;
    }
    throw Error();
  }
  var hi = function (a) {
    this.value = a;
    this.ef = new Ec();
  };
  hi.prototype.release = function () {
    this.ef.next();
    this.ef.complete();
    this.value = void 0;
  };
  da.Object.defineProperties(hi.prototype, {
    j: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.value;
      },
    },
    released: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.ef;
      },
    },
  });
  var ii = ["FRAME", "IMG", "IFRAME"],
    ji = /^[01](px)?$/,
    ki = function () {
      this.Ai = this.Kf = this.Lg = this.Tf = !1;
    },
    li = function () {
      var a = new ki();
      a.Tf = !0;
      a.Lg = !0;
      return a;
    };
  function mi(a) {
    return vh(a) ? document.getElementById(a) : a;
  }
  function ni(a, b) {
    b = b === void 0 ? !1 : b;
    if (a.tagName === "IMG") {
      if (a.complete && (!a.naturalWidth || !a.naturalHeight)) return !0;
      var c;
      if (b && ((c = a.style) == null ? void 0 : c.display) === "none")
        return !0;
    }
    var d, e;
    return (
      ji.test((d = a.getAttribute("width")) != null ? d : "") &&
      ji.test((e = a.getAttribute("height")) != null ? e : "")
    );
  }
  function oi(a, b) {
    if (a.tagName === "IMG") return !(!a.naturalWidth || !a.naturalHeight);
    try {
      if (a.readyState) var c = a.readyState;
      else {
        var d, e;
        c =
          (d = a.contentWindow) == null
            ? void 0
            : (e = d.document) == null
            ? void 0
            : e.readyState;
      }
      return c === "complete";
    } catch (f) {
      return b === void 0 ? !1 : b;
    }
  }
  function pi(a) {
    a ||
      (a = function (b, c, d) {
        b.addEventListener(c, d);
      });
    return a;
  }
  function qi(a, b) {
    var c = li();
    c = c === void 0 ? new ki() : c;
    if ((a = mi(a))) {
      var d = pi(d);
      for (
        var e = !1,
          f = function (A) {
            e || ((e = !0), b(A));
          },
          g,
          h = 2,
          k = 0;
        k < ii.length;
        ++k
      )
        if (ii[k] === a.tagName) {
          h = 3;
          g = [a];
          break;
        }
      g || (g = a.querySelectorAll(ii.join(",")));
      var l = 0,
        m = 0,
        u = !c.Kf,
        t = (a = !1);
      k = {};
      for (var r = 0; r < g.length; k = { Id: void 0 }, r++) {
        var w = g[r];
        if (!ni(w, c.Kf))
          if (((k.Id = w.tagName === "IMG"), oi(w, c.Tf)))
            (a = !0), k.Id && (u = !0);
          else {
            l++;
            var v = (function (A) {
              return function (C) {
                l--;
                !l && u && f(h);
                A.Id &&
                  ((C = C && C.type === "error"),
                  m--,
                  C || (u = !0),
                  !m && t && u && f(h));
              };
            })(k);
            d(w, "load", v);
            k.Id && (m++, d(w, "error", v));
          }
      }
      m === 0 && (u = !0);
      g = null;
      g = Oa.document.readyState === "complete";
      if (c.Ai && g) {
        if (m > 0) {
          t = !0;
          return;
        }
        h = 5;
      } else if (l === 0 && !a && g) h = 5;
      else if (l || !a) {
        d(Oa, "load", function () {
          !c.Lg || (!m && u) ? f(4) : (t = !0);
        });
        return;
      }
      f(h);
    }
  }
  function ri(a, b, c) {
    if (a) for (var d = 0; a != null && d < 500 && !c(a); ++d) a = b(a);
  }
  function si(a, b) {
    ri(
      a,
      function (c) {
        try {
          return c === c.parent ? null : c.parent;
        } catch (d) {}
        return null;
      },
      b
    );
  }
  function ti(a, b) {
    if (a.tagName == "IFRAME") b(a);
    else {
      a = a.querySelectorAll("IFRAME");
      for (var c = 0; c < a.length && !b(a[c]); ++c);
    }
  }
  function ui(a) {
    return ((a = a.ownerDocument) && (a.parentWindow || a.defaultView)) || null;
  }
  function vi(a, b, c) {
    try {
      var d = JSON.parse(c.data);
    } catch (g) {}
    if (typeof d === "object" && d && d.type === "creativeLoad") {
      var e = ui(a);
      if (c.source && e) {
        var f;
        si(c.source, function (g) {
          try {
            if (g.parent === e) return (f = g), !0;
          } catch (h) {}
        });
        f &&
          ti(a, function (g) {
            if (g.contentWindow === f) return b(d), !0;
          });
      }
    }
  }
  function wi(a) {
    return typeof a === "string" ? document.getElementById(a) : a;
  }
  var xi = function (a, b) {
    var c = wi(a);
    if (c)
      if (c.onCreativeLoad) c.onCreativeLoad(b);
      else {
        var d = b ? [b] : [],
          e = function (f) {
            for (var g = 0; g < d.length; ++g)
              try {
                d[g](1, f);
              } catch (h) {}
            d = {
              push: function (h) {
                h(1, f);
              },
            };
          };
        c.onCreativeLoad = function (f) {
          d.push(f);
        };
        c.setAttribute("data-creative-load-listener", "");
        c.addEventListener("creativeLoad", function (f) {
          e(f.detail);
        });
        Oa.addEventListener("message", function (f) {
          vi(c, e, f);
        });
      }
  };
  var yi = function (a, b) {
    var c = this;
    this.global = a;
    this.Pd = b;
    this.Vi = this.document
      ? Wd(fd(!0), Pd(this.document, "visibilitychange")).i(
          Bg(this.Pd.J, 748),
          Q(function () {
            return c.document ? c.document.visibilityState : "visible";
          }),
          S()
        )
      : fd("visible");
    this.Si = this.document
      ? Pd(this.document, "DOMContentLoaded").i(Bg(this.Pd.J, 739), Ye(1))
      : fd(gi("DOMContentLoaded"));
  };
  da.Object.defineProperties(yi.prototype, {
    document: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return Tg(this.global, "document")
          ? this.global.document || null
          : null;
      },
    },
  });
  var zi = function (a) {
      return a.document ? a.document.readyState : "complete";
    },
    Ai = function (a) {
      return a.document !== null && a.document.visibilityState !== void 0;
    };
  yi.prototype.querySelector = function (a) {
    return this.document ? this.document.querySelector(a) : null;
  };
  yi.prototype.querySelectorAll = function (a) {
    return this.document ? Qb(this.document.querySelectorAll(a)) : [];
  };
  yi.prototype.elementFromPoint = function (a, b) {
    if (
      !this.document ||
      this.document === null ||
      typeof this.document.elementFromPoint !== "function"
    )
      return null;
    a = this.document.elementFromPoint(a, b);
    return a === null ? null : new hi(a);
  };
  var Bi = function (a, b, c) {
      c = c === void 0 ? !1 : c;
      if (b.j === void 0 || !a.document) return fd(b).i(Bg(a.Pd.J, 749));
      var d = new id(1),
        e = function () {
          d.next(b);
        };
      c || xi(b.j, e);
      qi(b.j, e);
      return d.i(Bg(a.Pd.J, 749), Ye(1));
    },
    Ci = function (a, b) {
      a = a.document;
      if (!a) return fd(!1);
      var c = Wd(
          fd(null),
          Pd(a, "DOMContentLoaded", { once: !0 }),
          Pd(a, "load", { once: !0 })
        ),
        d = new hi({ document: a, element: b });
      return c.i(
        Q(function () {
          if (!d.j) return !1;
          var e = d.j,
            f = e.document;
          e = e.element;
          var g,
            h,
            k = (h = (g = f.body) != null ? g : f.children[0]) != null ? h : f;
          try {
            k.appendChild(e), d.release();
          } catch (l) {}
          return !d.j;
        }),
        R(function (e) {
          return e;
        }),
        Ye(1),
        Ve(!1),
        qf({
          complete: function () {
            return void d.release();
          },
        })
      );
    },
    Di = function (a, b, c) {
      var d, e, f;
      return Ba(function (g) {
        if (g.u == 1) {
          d = a.global.document.createElement("iframe");
          e = new Promise(function (k) {
            d.onload = k;
            d.onerror = k;
          });
          if (b instanceof jb) var h = b.Mg;
          else
            throw Error("Unexpected type when unwrapping TrustedResourceUrl");
          d.src = h.toString();
          return g.yield(nd(Ci(a, d)), 2);
        }
        if (g.u != 3) {
          if (!g.V) return g.return();
          d.style.display = "none";
          return g.yield(e, 3);
        }
        f = d.contentWindow;
        if (!f) return g.return();
        f.postMessage(c, "*");
        return g.return(d);
      });
    };
  var Ei = { left: 0, top: 0, width: 0, height: 0 };
  function Fi(a, b) {
    return (
      a.left === b.left &&
      a.top === b.top &&
      a.width === b.width &&
      a.height === b.height
    );
  }
  function Gi(a, b) {
    return {
      left: Math.max(a.left, b.left),
      top: Math.max(a.top, b.top),
      width: Math.max(
        0,
        Math.min(a.left + a.width, b.left + b.width) - Math.max(a.left, b.left)
      ),
      height: Math.max(
        0,
        Math.min(a.top + a.height, b.top + b.height) - Math.max(a.top, b.top)
      ),
    };
  }
  function Hi(a, b) {
    return {
      left: Math.round(a.left + b.x),
      top: Math.round(a.top + b.y),
      width: a.width,
      height: a.height,
    };
  }
  var Ii = RegExp(
    "^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"
  );
  function Ji(a, b) {
    if (a) {
      a = a.split("&");
      for (var c = 0; c < a.length; c++) {
        var d = a[c].indexOf("="),
          e = null;
        if (d >= 0) {
          var f = a[c].substring(0, d);
          e = a[c].substring(d + 1);
        } else f = a[c];
        b(f, e ? decodeURIComponent(e.replace(/\+/g, " ")) : "");
      }
    }
  }
  function Ki(a, b) {
    var c = ah() || $g();
    try {
      if (a) {
        if (!b.top) return new Jh(-12245933, -12245933, -12245933, -12245933);
        b = b.top;
      }
      a: {
        var d = b;
        if (a && d !== null && d != d.top) {
          if (!d.top) {
            var e = new Ch(-12245933, -12245933);
            break a;
          }
          d = d.top;
        }
        try {
          if (c === void 0 ? 0 : c)
            var f = new Ch(d.innerWidth, d.innerHeight).round();
          else {
            var g = (d || window).document,
              h = g.compatMode == "CSS1Compat" ? g.documentElement : g.body;
            f = new Ch(h.clientWidth, h.clientHeight).round();
          }
          e = f;
        } catch (w) {
          e = new Ch(-12245933, -12245933);
        }
      }
      a = e;
      var k = a.height,
        l = a.width;
      if (l === -12245933) return new Jh(l, l, l, l);
      var m = Fh(b.document);
      var u = Gh(m.Jc);
      var t = u.x,
        r = u.y;
      return new Jh(r, t + l, r + k, t);
    } catch (w) {
      return new Jh(-12245933, -12245933, -12245933, -12245933);
    }
  }
  function Li(a, b) {
    if (a) throw Error("S");
    b.push(65533);
  }
  function Mi(a, b) {
    b = String.fromCharCode.apply(null, b);
    return a == null ? b : a + b;
  }
  var Ni = void 0,
    Oi,
    Pi,
    Qi = typeof TextDecoder !== "undefined",
    Ri,
    Si = typeof String.prototype.isWellFormed === "function",
    Ti = typeof TextEncoder !== "undefined";
  var Ui = typeof Uint8Array !== "undefined",
    Vi = !dh && typeof btoa === "function",
    Wi = /[-_.]/g,
    Xi = { "-": "+", _: "/", ".": "=" };
  function Yi(a) {
    return Xi[a] || "";
  }
  function Zi(a) {
    if (!Vi) return ci(a);
    var b = Wi.test(a) ? a.replace(Wi, Yi) : a;
    try {
      var c = atob(b);
    } catch (d) {
      throw Error("U`" + a + "`" + d);
    }
    a = new Uint8Array(c.length);
    for (b = 0; b < c.length; b++) a[b] = c.charCodeAt(b);
    return a;
  }
  var $i = {};
  var bj = function (a, b) {
    if (b !== $i) throw Error("W");
    this.kd = a;
    if (a != null && a.length === 0) throw Error("V");
    this.dontPassByteStringToStructuredClone = aj;
  };
  bj.prototype.isEmpty = function () {
    return this.kd == null;
  };
  var cj;
  function aj() {}
  function dj() {
    return new SyntaxError("Maximum protobuf recursion depth exceeded");
  }
  function ej(a) {
    Lb(a, bj);
    if ($i !== $i) throw Error("W");
    var b = a.kd;
    b == null ||
      (Ui && b != null && b instanceof Uint8Array) ||
      (typeof b === "string"
        ? (b = Zi(b))
        : (Fb("Cannot coerce to Uint8Array: " + Qa(b)), (b = null)));
    return (b == null ? b : (a.kd = b)) || new Uint8Array(0);
  }
  var gj = function (a, b, c) {
    this.buffer = a;
    if (c && !b) throw Error("ea");
    this.zg = b;
  };
  function hj(a, b) {
    if (typeof a === "string") return new gj(Zi(a), b);
    if (Array.isArray(a)) return new gj(new Uint8Array(a), b);
    if (a.constructor === Uint8Array) return new gj(a, !1);
    if (a.constructor === ArrayBuffer)
      return (a = new Uint8Array(a)), new gj(a, !1);
    if (a.constructor === bj) return (b = ej(a)), new gj(b, !0, a);
    if (a instanceof Uint8Array)
      return (
        (a =
          a.constructor === Uint8Array
            ? a
            : new Uint8Array(a.buffer, a.byteOffset, a.byteLength)),
        new gj(a, !1)
      );
    throw Error("fa");
  }
  function ij() {
    return typeof BigInt === "function";
  }
  var jj = typeof Oa.BigInt === "function" && typeof Oa.BigInt(0) === "bigint";
  function kj(a) {
    var b = a;
    if (vh(b)) {
      if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(b)) throw Error("ga`" + b);
    } else if (uh(b) && !Number.isSafeInteger(b)) throw Error("ha`" + b);
    if (jj) {
      xh(a) || (ih(a, Ah(vh, wh, uh)), (a = BigInt(a)));
      b = a % BigInt(2);
      var c = BigInt;
      nh(!0);
      var d =
        typeof Window === "function" && globalThis.top instanceof Window
          ? globalThis.top
          : globalThis;
      d.gbigintUseStrInDebugToggleVal == null &&
        Object.defineProperties(d, {
          gbigintUseStrInDebugToggleVal: { value: Math.round(Math.random()) },
        });
      return b === c(d.gbigintUseStrInDebugToggleVal) ? a.toString() : a;
    }
    return (a = wh(a) ? (a ? "1" : "0") : vh(a) ? a.trim() || "0" : String(a));
  }
  var qj = rh(function (a) {
      if (jj)
        return ih(lj, xh), ih(mj, xh), (a = BigInt(a)), a >= lj && a <= mj;
      a = mh(a, vh);
      return a[0] === "-" ? nj(a, oj) : nj(a, pj);
    }, "isSafeInt52"),
    oj = Number.MIN_SAFE_INTEGER.toString(),
    lj = jj ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
    pj = Number.MAX_SAFE_INTEGER.toString(),
    mj = jj ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;
  function nj(a, b) {
    if (a.length > b.length) return !1;
    if (a.length < b.length || a === b) return !0;
    for (var c = 0; c < a.length; c++) {
      var d = a[c],
        e = b[c];
      if (d > e) return !1;
      if (d < e) return !0;
    }
    qh("isInRange weird case. Value was: " + a + ". Boundary was: " + b + ".");
  }
  var rj = typeof Uint8Array.prototype.slice === "function",
    sj = 0,
    tj = 0,
    uj;
  function vj(a) {
    var b = a >>> 0;
    sj = b;
    tj = ((a - b) / 4294967296) >>> 0;
  }
  function wj(a) {
    if (a < 0) {
      vj(0 - a);
      var b = x(xj(sj, tj));
      a = b.next().value;
      b = b.next().value;
      sj = a >>> 0;
      tj = b >>> 0;
    } else vj(a);
  }
  function yj(a) {
    H(a <= 8);
    return uj || (uj = new DataView(new ArrayBuffer(8)));
  }
  function zj(a, b) {
    var c = b * 4294967296 + (a >>> 0);
    return Number.isSafeInteger(c) ? c : Aj(a, b);
  }
  function Bj(a, b) {
    return kj(
      ij()
        ? BigInt.asUintN(64, (BigInt(b >>> 0) << BigInt(32)) + BigInt(a >>> 0))
        : Aj(a, b)
    );
  }
  function Cj(a, b) {
    return ij()
      ? kj(
          BigInt.asIntN(
            64,
            (BigInt.asUintN(32, BigInt(b)) << BigInt(32)) +
              BigInt.asUintN(32, BigInt(a))
          )
        )
      : kj(Dj(a, b));
  }
  function Aj(a, b) {
    b >>>= 0;
    a >>>= 0;
    if (b <= 2097151) var c = "" + (4294967296 * b + a);
    else
      ij()
        ? (c = "" + ((BigInt(b) << BigInt(32)) | BigInt(a)))
        : ((c = ((a >>> 24) | (b << 8)) & 16777215),
          (b = (b >> 16) & 65535),
          (a = (a & 16777215) + c * 6777216 + b * 6710656),
          (c += b * 8147497),
          (b *= 2),
          a >= 1e7 && ((c += (a / 1e7) >>> 0), (a %= 1e7)),
          c >= 1e7 && ((b += (c / 1e7) >>> 0), (c %= 1e7)),
          H(b),
          (c = b + Ej(c) + Ej(a)));
    return c;
  }
  function Ej(a) {
    a = String(a);
    return "0000000".slice(a.length) + a;
  }
  function Dj(a, b) {
    b & 2147483648
      ? ij()
        ? (a = "" + ((BigInt(b | 0) << BigInt(32)) | BigInt(a >>> 0)))
        : ((b = x(xj(a, b))),
          (a = b.next().value),
          (b = b.next().value),
          (a = "-" + Aj(a, b)))
      : (a = Aj(a, b));
    return a;
  }
  function Fj(a) {
    H(a.length > 0);
    if (a.length < 16) wj(Number(a));
    else if (ij())
      (a = BigInt(a)),
        (sj = Number(a & BigInt(4294967295)) >>> 0),
        (tj = Number((a >> BigInt(32)) & BigInt(4294967295)));
    else {
      H(a.length > 0);
      var b = +(a[0] === "-");
      tj = sj = 0;
      for (
        var c = a.length, d = 0 + b, e = ((c - b) % 6) + b;
        e <= c;
        d = e, e += 6
      )
        (d = Number(a.slice(d, e))),
          (tj *= 1e6),
          (sj = sj * 1e6 + d),
          sj >= 4294967296 &&
            ((tj += Math.trunc(sj / 4294967296)), (tj >>>= 0), (sj >>>= 0));
      b &&
        ((b = x(xj(sj, tj))),
        (a = b.next().value),
        (b = b.next().value),
        (sj = a),
        (tj = b));
    }
  }
  function xj(a, b) {
    b = ~b;
    a ? (a = ~a + 1) : (b += 1);
    return [a, b];
  }
  var Gj = function (a, b, c, d) {
    this.I = this.Fa = null;
    this.me = !1;
    this.T = this.Sa = this.Va = 0;
    this.init(a, b, c, d);
  };
  n = Gj.prototype;
  n.init = function (a, b, c, d) {
    var e = d === void 0 ? {} : d;
    d = e.je;
    e = e.tf;
    e = e === void 0 ? !1 : e;
    this.je = d === void 0 ? !1 : d;
    this.tf = e;
    a &&
      ((this.I = a = hj(a, this.tf)),
      (this.Fa = a.buffer),
      (this.me = a.zg),
      (this.Va = b || 0),
      (this.Sa = c !== void 0 ? this.Va + c : this.Fa.length),
      (this.T = this.Va));
  };
  n.Be = function () {
    this.clear();
    Hj.length < 100 && Hj.push(this);
  };
  n.clear = function () {
    this.I = this.Fa = null;
    this.me = !1;
    this.T = this.Sa = this.Va = 0;
    this.je = !1;
  };
  n.setEnd = function (a) {
    this.Sa = a;
  };
  n.reset = function () {
    this.T = this.Va;
  };
  n.ga = function () {
    return this.T;
  };
  n.advance = function (a) {
    Ij(this, this.T + a);
  };
  var Jj = function (a, b) {
      var c = 0,
        d = 0,
        e = 0,
        f = a.Fa,
        g = a.T;
      do {
        var h = f[g++];
        c |= (h & 127) << e;
        e += 7;
      } while (e < 32 && h & 128);
      if (e > 32)
        for (d |= (h & 127) >> 4, e = 3; e < 32 && h & 128; e += 7)
          (h = f[g++]), (d |= (h & 127) << e);
      Ij(a, g);
      if (!(h & 128)) return b(c >>> 0, d >>> 0);
      throw Error("ba");
    },
    Ij = function (a, b) {
      a.T = b;
      if (b > a.Sa) throw Error("ca`" + b + "`" + a.Sa);
    },
    Kj = function (a) {
      var b = a.Fa,
        c = a.T,
        d = b[c++],
        e = d & 127;
      if (
        d & 128 &&
        ((d = b[c++]),
        (e |= (d & 127) << 7),
        d & 128 &&
          ((d = b[c++]),
          (e |= (d & 127) << 14),
          d & 128 &&
            ((d = b[c++]),
            (e |= (d & 127) << 21),
            d & 128 &&
              ((d = b[c++]),
              (e |= d << 28),
              d & 128 &&
                b[c++] & 128 &&
                b[c++] & 128 &&
                b[c++] & 128 &&
                b[c++] & 128 &&
                b[c++] & 128))))
      )
        throw Error("ba");
      Ij(a, c);
      return e;
    },
    Lj = function (a) {
      return Kj(a) >>> 0;
    },
    Mj = function (a) {
      return Jj(a, Bj);
    },
    Nj = function (a) {
      var b = a.Fa,
        c = a.T,
        d = b[c + 0],
        e = b[c + 1],
        f = b[c + 2];
      b = b[c + 3];
      a.advance(4);
      return ((d << 0) | (e << 8) | (f << 16) | (b << 24)) >>> 0;
    },
    Oj = function (a) {
      for (var b = 0, c = a.T, d = c + 10, e = a.Fa; c < d; ) {
        var f = e[c++];
        b |= f;
        if ((f & 128) === 0) return Ij(a, c), !!(b & 127);
      }
      throw Error("ba");
    },
    Pj = function (a) {
      return Kj(a);
    },
    Qj = function (a, b) {
      if (b < 0) throw Error("da`" + b);
      var c = a.T,
        d = c + b;
      if (d > a.Sa) throw Error("ca`" + (a.Sa - c) + "`" + b);
      a.T = d;
      return c;
    };
  Gj.prototype.Ng = function (a, b) {
    var c = Qj(this, a),
      d = H(this.Fa);
    if (Qi) {
      var e;
      b
        ? (e = Oi) || (e = Oi = new TextDecoder("utf-8", { fatal: !0 }))
        : (e = Pi) || (e = Pi = new TextDecoder("utf-8", { fatal: !1 }));
      var f = c + a;
      d = c === 0 && f === d.length ? d : d.subarray(c, f);
      try {
        var g = e.decode(d);
      } catch (m) {
        if (b) {
          if (Ni === void 0) {
            try {
              e.decode(new Uint8Array([128]));
            } catch (u) {}
            try {
              e.decode(new Uint8Array([97])), (Ni = !0);
            } catch (u) {
              Ni = !1;
            }
          }
          b = !Ni;
        }
        b && (Oi = void 0);
        throw m;
      }
    } else {
      a = c + a;
      g = [];
      for (var h = null, k, l; c < a; )
        (k = d[c++]),
          k < 128
            ? g.push(k)
            : k < 224
            ? c >= a
              ? Li(b, g)
              : ((l = d[c++]),
                k < 194 || (l & 192) !== 128
                  ? (c--, Li(b, g))
                  : ((k = ((k & 31) << 6) | (l & 63)),
                    H(k >= 128 && k <= 2047),
                    g.push(k)))
            : k < 240
            ? c >= a - 1
              ? Li(b, g)
              : ((l = d[c++]),
                (l & 192) !== 128 ||
                (k === 224 && l < 160) ||
                (k === 237 && l >= 160) ||
                ((e = d[c++]) & 192) !== 128
                  ? (c--, Li(b, g))
                  : ((k = ((k & 15) << 12) | ((l & 63) << 6) | (e & 63)),
                    H(k >= 2048 && k <= 65535),
                    H(k < 55296 || k > 57343),
                    g.push(k)))
            : k <= 244
            ? c >= a - 2
              ? Li(b, g)
              : ((l = d[c++]),
                (l & 192) !== 128 ||
                ((k << 28) + (l - 144)) >> 30 !== 0 ||
                ((e = d[c++]) & 192) !== 128 ||
                ((f = d[c++]) & 192) !== 128
                  ? (c--, Li(b, g))
                  : ((k =
                      ((k & 7) << 18) |
                      ((l & 63) << 12) |
                      ((e & 63) << 6) |
                      (f & 63)),
                    H(k >= 65536 && k <= 1114111),
                    (k -= 65536),
                    g.push(((k >> 10) & 1023) + 55296, (k & 1023) + 56320)))
            : Li(b, g),
          g.length >= 8192 && ((h = Mi(h, g)), (g.length = 0));
      H(c === a, "expected " + c + " === " + a);
      g = Mi(h, g);
    }
    return g;
  };
  Gj.prototype.cf = function (a) {
    if (a == 0) return cj || (cj = new bj(null, $i));
    var b = Qj(this, a);
    if (this.je && this.me) b = this.Fa.subarray(b, b + a);
    else {
      var c = H(this.Fa);
      a = b + a;
      b =
        b === a
          ? new Uint8Array(0)
          : rj
          ? c.slice(b, a)
          : new Uint8Array(c.subarray(b, a));
    }
    Lb(b, Uint8Array);
    return b.length == 0 ? cj || (cj = new bj(null, $i)) : new bj(b, $i);
  };
  var Hj = [];
  H(!0);
  var Rj = 0,
    Tj = function (a, b, c, d) {
      if (Hj.length) {
        var e = Hj.pop();
        e.init(a, b, c, d);
        a = e;
      } else a = new Gj(a, b, c, d);
      this.o = a;
      this.sb = this.o.ga();
      this.m = this.Od = this.lc = -1;
      Sj(this, d);
    },
    Sj = function (a, b) {
      b = (b === void 0 ? {} : b).Wf;
      a.Wf = b === void 0 ? !1 : b;
    },
    Vj = function (a, b, c, d) {
      if (Uj.length) {
        var e = Uj.pop();
        Sj(e, d);
        e.o.init(a, b, c, d);
        return e;
      }
      return new Tj(a, b, c, d);
    };
  Tj.prototype.Be = function () {
    this.o.clear();
    this.m = this.lc = this.Od = -1;
    Uj.length < 100 && Uj.push(this);
  };
  Tj.prototype.ga = function () {
    return this.o.ga();
  };
  Tj.prototype.reset = function () {
    this.o.reset();
    this.sb = this.o.ga();
    this.m = this.lc = this.Od = -1;
  };
  Tj.prototype.advance = function (a) {
    this.o.advance(a);
  };
  var Wj = function (a) {
      var b = a.o;
      if (b.T == b.Sa) return !1;
      a.Od !== -1 &&
        ((b = a.o.ga()),
        (a.o.T = a.sb),
        Lj(a.o),
        a.m === 4 || a.m === 3
          ? H(
              b === a.o.ga(),
              "Expected to not advance the cursor.  Group tags do not have values."
            )
          : H(
              b > a.o.ga(),
              "Expected to read the field, did you forget to call a read or skip method?"
            ),
        (a.o.T = b));
      a.sb = a.o.ga();
      b = Lj(a.o);
      var c = b >>> 3,
        d = b & 7;
      if (!(d >= 0 && d <= 5)) throw Error("Y`" + d + "`" + a.sb);
      if (c < 1) throw Error("Z`" + c + "`" + a.sb);
      a.Od = b;
      a.lc = c;
      a.m = d;
      return !0;
    },
    Xj = function () {
      if (Rj >= 100) throw dj();
      Rj++;
    },
    Yj = function (a) {
      try {
        switch (a.m) {
          case 0:
            a.m != 0
              ? (Fb("Invalid wire type for skipVarintField"), Yj(a))
              : Oj(a.o);
            break;
          case 1:
            H(a.m === 1);
            a.o.advance(8);
            break;
          case 2:
            if (a.m != 2) Fb("Invalid wire type for skipDelimitedField"), Yj(a);
            else {
              var b = Lj(a.o);
              a.o.advance(b);
            }
            break;
          case 5:
            H(a.m === 5);
            a.o.advance(4);
            break;
          case 3:
            Xj();
            var c = a.lc;
            try {
              do {
                if (!Wj(a)) throw Error("$");
                if (a.m == 4) {
                  if (a.lc != c) throw Error("aa");
                  break;
                }
                Yj(a);
              } while (1);
            } catch (d) {
              if (d instanceof RangeError) throw dj();
              throw d;
            } finally {
              Rj > 0 && Rj--;
            }
            break;
          default:
            throw Error("Y`" + a.m + "`" + a.sb);
        }
      } catch (d) {
        if (d instanceof RangeError) throw dj();
        throw d;
      }
    },
    Zj = function (a, b, c) {
      H(a.m == 2);
      var d = a.o.Sa,
        e = Lj(a.o),
        f = a.o.ga() + e,
        g = f - d;
      g <= 0 &&
        (a.o.setEnd(f), c(b, a, void 0, void 0, void 0), (g = f - a.o.ga()));
      if (g) throw Error("X`" + e + "`" + (e - g));
      a.o.T = f;
      a.o.setEnd(d);
    },
    ak = function (a) {
      H(a.m == 0);
      return Kj(a.o);
    },
    bk = function (a) {
      H(a.m == 0);
      return Lj(a.o);
    },
    ck = function (a) {
      H(a.m == 0);
      return Mj(a.o);
    },
    dk = function (a) {
      H(a.m == 0);
      return Kj(a.o);
    };
  Tj.prototype.Ng = function () {
    return ek(this);
  };
  var ek = function (a) {
    H(a.m == 2);
    var b = Lj(a.o);
    return a.o.Ng(b, !0);
  };
  Tj.prototype.cf = function () {
    H(this.m == 2);
    var a = Lj(this.o);
    return this.o.cf(a);
  };
  var fk = function (a, b, c) {
      H(a.m == 2);
      var d = Lj(a.o);
      for (d = a.o.ga() + d; a.o.ga() < d; ) c.push(b(a.o));
    },
    Uj = [];
  var gk = typeof Symbol === "function" && typeof Symbol() === "symbol";
  function hk(a, b, c) {
    return typeof Symbol === "function" && typeof Symbol() === "symbol"
      ? (c === void 0 ? 0 : c) && Symbol.for && a
        ? Symbol.for(a)
        : a != null
        ? Symbol(a)
        : Symbol()
      : b;
  }
  var ik = hk("jas", void 0, !0),
    jk = hk("defaultInstance", "0di"),
    kk = hk("unknownBinaryFields", Symbol()),
    lk = hk("unknownBinaryThrottleKey", "0ub"),
    mk = hk("unknownBinaryThrottleKey", "0ubs"),
    nk = hk("unknownBinarySerializeBinaryThrottleKey", "0ubsb"),
    ok = hk("m_m", "sk", !0),
    pk = hk("validPivotSelector", "vps"),
    qk = hk("knownMessageType", "knownMessageType"),
    rk = hk("destroyedStructure", "destroyedStructure");
  H(
    Math.round(
      Math.log2(
        Math.max.apply(
          Math,
          y(
            Object.values({
              Vj: 1,
              Uj: 2,
              Tj: 4,
              ak: 8,
              dk: 16,
              Yj: 32,
              Hj: 64,
              Rj: 128,
              Lj: 256,
              ck: 512,
              Mj: 1024,
              Sj: 2048,
              Zj: 4096,
              Xj: 8192,
            })
          )
        )
      )
    ) === 13
  );
  var sk = { mi: { value: 0, configurable: !0, writable: !0, enumerable: !1 } },
    tk = Object.defineProperties,
    Z = gk ? K(ik) : "mi",
    uk,
    vk = [];
  wk(vk, 7);
  uk = Object.freeze(vk);
  function xk(a) {
    return L(a, "state is only maintained on arrays.")[Z] | 0;
  }
  function yk(a, b) {
    H((b & 16777215) === b);
    L(a, "state is only maintained on arrays.");
    gk || Z in a || tk(a, sk);
    a[Z] |= b;
  }
  function wk(a, b) {
    H((b & 16777215) === b);
    L(a, "state is only maintained on arrays.");
    gk || Z in a || tk(a, sk);
    a[Z] = b;
  }
  function zk(a, b, c) {
    (c === void 0 || !c || b & 2048) &&
      H(b & 64, "state for messages must be constructed");
    H(
      (b & 5) === 0,
      "state for messages should not contain repeated field state"
    );
    H(
      (b & 8192) === 0,
      "state for messages should not contain map field state"
    );
    if (b & 64) {
      H(b & 64);
      c = (b >> 14) & 1023 || 536870912;
      var d = a.length;
      H(b & 64);
      H(
        c + (b & 128 ? 0 : -1) >= d - 1,
        "pivot %s is pointing at an index earlier than the last index of the array, length: %s",
        c,
        d
      );
      b & 128 &&
        H(
          typeof a[0] === "string",
          "arrays with a message_id bit must have a string in the first position, got: %s",
          a[0]
        );
    }
  }
  function Ak(a) {
    var b = L(a, "state is only maintained on arrays.")[Z] | 0;
    zk(a, b);
    return b;
  }
  function Bk(a) {
    var b = L(a, "state is only maintained on arrays.")[Z] | 0;
    zk(a, b);
    return b;
  }
  function Ck(a) {
    return !!((L(a, "state is only maintained on arrays.")[Z] | 0) & 2);
  }
  function Dk(a, b) {
    Gb(b);
    H(
      (b > 0 && b <= 1023) || 536870912 === b,
      "pivot must be in the range [1, 1024) or NO_PIVOT got %s",
      b
    );
    return (a & -16760833) | ((b & 1023) << 14);
  }
  function Ek(a) {
    H(a & 64);
    return a & 128 ? 0 : -1;
  }
  function Fk(a, b) {
    2 & b && (a |= 2);
    return a | 1;
  }
  var Gk = Object.getOwnPropertyDescriptor(Array.prototype, "yi");
  Object.defineProperties(Array.prototype, {
    yi: {
      get: function () {
        var a = Hk(this);
        return Gk ? Gk.get.call(this) + "|" + a : a;
      },
      configurable: !0,
      enumerable: !1,
    },
  });
  function Hk(a) {
    function b(e, f) {
      e & c && d.push(f);
    }
    var c = L(a, "state is only maintained on arrays.")[Z] | 0,
      d = [];
    b(1, "IS_REPEATED_FIELD");
    b(2, "IS_IMMUTABLE_ARRAY");
    b(4, "IS_API_FORMATTED");
    b(512, "STRING_FORMATTED");
    b(1024, "GBIGINT_FORMATTED");
    b(1024, "BINARY");
    b(8, "ONLY_MUTABLE_VALUES");
    b(16, "UNFROZEN_SHARED");
    b(32, "MUTABLE_REFERENCES_ARE_OWNED");
    b(64, "CONSTRUCTED");
    b(128, "HAS_MESSAGE_ID");
    b(256, "FROZEN_ARRAY");
    b(2048, "HAS_WRAPPER");
    b(4096, "MUTABLE_SUBSTRUCTURES");
    b(8192, "KNOWN_MAP_ARRAY");
    c & 64 &&
      (H(c & 64),
      (a = (c >> 14) & 1023 || 536870912),
      a !== 536870912 && d.push("pivot: " + a));
    return d.join(",");
  }
  var Ik = gk && Math.random() < 0.5,
    Jk = Ik ? Symbol() : void 0;
  function Kk(a) {
    H(Lk(a));
    return Ik ? a[K(Jk)] : a.B;
  }
  var Mk,
    Nk = typeof ok === "symbol",
    Ok = {};
  function Lk(a) {
    var b = a[ok],
      c = b === Ok;
    H(!Mk || c === a instanceof Mk);
    if (Nk && b && !c) throw Error("ia");
    return c;
  }
  function Pk(a) {
    return a != null && Lk(a);
  }
  function Qk(a, b) {
    Gb(a);
    H(a > 0);
    H(b === 0 || b === -1);
    return a + b;
  }
  function Rk(a, b) {
    H(b === Sk || b === void 0);
    return a + (b ? 0 : -1);
  }
  function Tk(a, b) {
    Gb(a);
    H(a >= 0);
    H(b === 0 || b === -1);
    return a - b;
  }
  function Uk(a, b) {
    if (b === void 0) {
      if ((b = !Vk(a)))
        H(Lk(a)),
          (a = Ik ? a[K(Jk)] : a.B),
          (b = L(a, "state is only maintained on arrays.")[Z] | 0),
          zk(a, b),
          (b = !!(2 & b));
      return b;
    }
    H(Lk(a));
    var c = Ik ? a[K(Jk)] : a.B;
    var d = L(c, "state is only maintained on arrays.")[Z] | 0;
    zk(c, d);
    H(b === d);
    return !!(2 & b) && !Vk(a);
  }
  var Wk = {};
  function Vk(a) {
    var b = a.Ih,
      c;
    (c = !b) ||
      (H(Lk(a)),
      (a = Ik ? a[K(Jk)] : a.B),
      (c = L(a, "state is only maintained on arrays.")[Z] | 0),
      zk(a, c),
      (c = !!(2 & c)));
    H(c);
    H(b === void 0 || b === Wk);
    return b === Wk;
  }
  function Xk(a, b) {
    H(Lk(a));
    var c = Ik ? a[K(Jk)] : a.B;
    var d = L(c, "state is only maintained on arrays.")[Z] | 0;
    zk(c, d);
    H(b === !!(2 & d));
    a.Ih = b ? Wk : void 0;
  }
  var Yk = Symbol("exempted jspb subclass"),
    Zk =
      typeof Symbol != "undefined" && typeof Symbol.hasInstance != "undefined";
  function $k() {}
  function al(a, b) {
    var c = xk(L(a));
    b || H(!((c & 2 && c & 4) || c & 256) || Object.isFrozen(a));
    bl(a);
  }
  function bl(a) {
    a = L(a, "state is only maintained on arrays.")[Z] | 0;
    var b = a & 4,
      c = (512 & a ? 1 : 0) + (1024 & a ? 1 : 0);
    H(
      (b && c <= 1) || (!b && c === 0),
      "Expected at most 1 type-specific formatting bit, but got " +
        c +
        " with state: " +
        a
    );
  }
  var cl = Object.freeze({}),
    dl = Symbol("debugExtensions");
  function el(a, b, c) {
    H(b & 64);
    H(b & 64);
    var d = b & 128 ? 0 : -1;
    var e = a.length,
      f;
    if ((f = !!e))
      (f = a[e - 1]),
        (f =
          f != null &&
          typeof f === "object" &&
          !f[rk] &&
          f.constructor === Object);
    var g = e + (f ? -1 : 0),
      h = a[e - 1];
    H(
      !!f ===
        (h != null &&
          typeof h === "object" &&
          !h[rk] &&
          h.constructor === Object)
    );
    for (b = b & 128 ? 1 : 0; b < g; b++) (h = a[b]), c(Tk(b, d), h);
    if (f) {
      a = a[e - 1];
      for (var k in a) !isNaN(k) && c(+k, a[k]);
    }
  }
  var Sk = {};
  function fl(a, b) {
    a = L(a, "state is only maintained on arrays.")[Z] | 0;
    H(a & 64);
    a & 128 ? H(b === Sk) : H(b === void 0);
  }
  function gl(a) {
    H(a & 64);
    return a & 128 ? Sk : void 0;
  }
  var hl = {};
  function il(a) {
    a = Error(a);
    Ub(a, "warning");
    return a;
  }
  function jl(a, b, c) {
    if (a != null) {
      var d;
      var e = (d = hl) != null ? d : (hl = {});
      d = e[a] || 0;
      d >= b || ((e[a] = d + 1), (a = Error(c)), Ub(a, "incident"), Vh(a));
    }
  }
  var kl = typeof BigInt === "function" ? BigInt.asIntN : void 0,
    ll = typeof BigInt === "function" ? BigInt.asUintN : void 0,
    ml = Number.isSafeInteger,
    nl = Number.isFinite,
    ol = Math.trunc,
    pl = Number.MAX_SAFE_INTEGER;
  function ql(a) {
    if (a == null || typeof a === "number") return a;
    if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a);
  }
  function rl(a) {
    return a.displayName || a.name || "unknown type name";
  }
  function sl(a) {
    if (a == null || typeof a === "boolean") return a;
    if (typeof a === "number") return !!a;
  }
  var tl = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
  function ul(a) {
    switch (typeof a) {
      case "bigint":
        return !0;
      case "number":
        return nl(a);
      case "string":
        return tl.test(a);
      default:
        return !1;
    }
  }
  function vl(a) {
    if (!nl(a))
      throw (
        ((a = "Expected enum as finite number but got " + Qa(a) + ": " + a),
        il(a))
      );
    return a | 0;
  }
  function wl(a) {
    return a == null ? a : nl(a) ? a | 0 : void 0;
  }
  function xl(a) {
    return "Expected int32 as finite number but got " + Qa(a) + ": " + a;
  }
  function yl(a) {
    if (typeof a !== "number") throw il(xl(a));
    if (!nl(a)) throw il(xl(a));
    return a | 0;
  }
  function zl(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return nl(a) ? a | 0 : void 0;
  }
  function Al(a) {
    return "Expected uint32 as finite number but got " + Qa(a) + ": " + a;
  }
  function Bl(a) {
    if (a == null) return a;
    if (typeof a === "string" && a) a = +a;
    else if (typeof a !== "number") return;
    return nl(a) ? a >>> 0 : void 0;
  }
  function Cl(a) {
    if (a == null) return a;
    var b = typeof a;
    if (b === "bigint") return H(typeof a === "bigint"), kj(kl(64, a));
    if (ul(a)) {
      if (b === "string")
        return (
          H(ul(a)),
          H(!0),
          (b = ol(Number(a))),
          ml(b)
            ? (a = String(b))
            : ((b = a.indexOf(".")),
              b !== -1 && (a = a.substring(0, b)),
              H(a.indexOf(".") === -1),
              (b = a.length),
              (a[0] === "-"
                ? b < 20 || (b === 20 && a <= "-9223372036854775808")
                : b < 19 || (b === 19 && a <= "9223372036854775807")) ||
                (Fj(a), (a = Dj(sj, tj)))),
          a
        );
      if (b === "number") {
        H(ul(a));
        H(!0);
        a = ol(a);
        if (!ml(a)) {
          H(!ml(a));
          H(Number.isInteger(a));
          wj(a);
          b = sj;
          var c = tj;
          if ((a = c & 2147483648))
            (b = (~b + 1) >>> 0), (c = ~c >>> 0), b == 0 && (c = (c + 1) >>> 0);
          b = zj(b, c);
          a = typeof b === "number" ? (a ? -b : b) : a ? "-" + b : b;
        }
        return a;
      }
    }
  }
  function Dl(a) {
    if (a == null) return a;
    var b = typeof a;
    if (b === "bigint") return H(typeof a === "bigint"), kj(ll(64, a));
    if (ul(a)) {
      if (b === "string")
        return (
          H(ul(a)),
          H(!0),
          (b = ol(Number(a))),
          ml(b) && b >= 0
            ? (a = String(b))
            : ((b = a.indexOf(".")),
              b !== -1 && (a = a.substring(0, b)),
              H(a.indexOf(".") === -1),
              a[0] === "-"
                ? (b = !1)
                : ((b = a.length),
                  (b = b < 20 ? !0 : b === 20 && a <= "18446744073709551615")),
              b || (Fj(a), (a = Aj(sj, tj)))),
          a
        );
      if (b === "number")
        return (
          H(ul(a)),
          H(!0),
          (a = ol(a)),
          (a >= 0 && ml(a)) ||
            (H(a < 0 || a > pl),
            H(Number.isInteger(a)),
            wj(a),
            (a = zj(sj, tj))),
          a
        );
    }
  }
  function El(a) {
    return a == null || typeof a === "string" ? a : void 0;
  }
  function Fl(a, b) {
    if (!(a instanceof b))
      throw Error("na`" + rl(b) + "`" + (a && rl(a.constructor)));
  }
  function Gl(a, b, c) {
    if (Pk(a)) return a;
    if (Array.isArray(a)) {
      var d = xk(a);
      c = d | (c & 32) | (c & 2);
      c !== d && wk(a, c);
      return new b(a);
    }
  }
  var Hl = function (a, b) {
      this.Qc = a >>> 0;
      this.Mc = b >>> 0;
    },
    Jl = function (a) {
      if (!a) return Il || (Il = new Hl(0, 0));
      if (!/^\d+$/.test(a)) return null;
      Fj(a);
      return new Hl(sj, tj);
    },
    Kl = function (a) {
      return new Hl(a & 4294967295, Math.floor(a / 4294967296));
    },
    Il,
    Ll = function (a, b) {
      this.Qc = a >>> 0;
      this.Mc = b >>> 0;
    },
    Nl = function (a) {
      if (!a) return Ml || (Ml = new Ll(0, 0));
      if (!/^-?\d+$/.test(a)) return null;
      Fj(a);
      return new Ll(sj, tj);
    },
    Ol = function (a) {
      return new Ll(a & 4294967295, Math.floor(a / 4294967296));
    },
    Ml,
    Pl,
    Ql,
    Rl,
    Sl,
    Tl,
    Ul,
    Vl;
  function Wl(a, b, c) {
    if (typeof BigInt64Array !== "undefined")
      return (
        Ul ||
          ((Ul = new BigInt64Array(1)),
          (Vl = new Uint32Array(Ul.buffer)),
          (Ul[0] = BigInt(1)),
          (Tl = Vl[0] === 1)),
        (K(Ul)[0] = a),
        (a = Tl ? 0 : 1),
        (c = 1 - a),
        new b(K(Vl)[a], K(Vl)[c])
      );
    Sl ||
      ((Pl = BigInt(Number.MIN_SAFE_INTEGER)),
      (Ql = BigInt(Number.MAX_SAFE_INTEGER)),
      (Rl = BigInt(4294967295)),
      (Sl = BigInt(32)));
    if (a >= Pl && a <= Ql) return c(Number(a));
    a = BigInt.asUintN(64, a);
    return new b(Number(a & Rl), Number(a >> Sl));
  }
  var Xl = function () {
    this.I = [];
  };
  Xl.prototype.length = function () {
    return this.I.length;
  };
  Xl.prototype.end = function () {
    var a = this.I;
    this.I = [];
    return a;
  };
  Xl.prototype.jb = function (a, b) {
    H(a == Math.floor(a));
    H(b == Math.floor(b));
    H(a >= 0 && a < 4294967296);
    for (H(b >= 0 && b < 4294967296); b > 0 || a > 127; )
      this.I.push((a & 127) | 128),
        (a = ((a >>> 7) | (b << 25)) >>> 0),
        (b >>>= 7);
    this.I.push(a);
  };
  Xl.prototype.Ef = function (a, b) {
    H(a == Math.floor(a));
    H(b == Math.floor(b));
    H(a >= 0 && a < 4294967296);
    H(b >= 0 && b < 4294967296);
    this.Na(a);
    this.Na(b);
  };
  var Yl = function (a, b) {
      H(b == Math.floor(b));
      for (H(b >= 0 && b < 4294967296); b > 127; )
        a.I.push((b & 127) | 128), (b >>>= 7);
      a.I.push(b);
    },
    Zl = function (a, b) {
      H(b == Math.floor(b));
      H(b >= -2147483648 && b < 2147483648);
      if (b >= 0) Yl(a, b);
      else {
        for (var c = 0; c < 9; c++) a.I.push((b & 127) | 128), (b >>= 7);
        a.I.push(1);
      }
    };
  n = Xl.prototype;
  n.Na = function (a) {
    H(a == Math.floor(a));
    H(a >= 0 && a < 4294967296);
    this.I.push((a >>> 0) & 255);
    this.I.push((a >>> 8) & 255);
    this.I.push((a >>> 16) & 255);
    this.I.push((a >>> 24) & 255);
  };
  n.ph = function (a) {
    H(a == Math.floor(a));
    H(a >= 0 && a < 1.8446744073709552e19);
    vj(a);
    this.Na(sj);
    this.Na(tj);
  };
  n.nh = function (a) {
    H(a == Math.floor(a));
    H(a >= -2147483648 && a < 2147483648);
    this.I.push((a >>> 0) & 255);
    this.I.push((a >>> 8) & 255);
    this.I.push((a >>> 16) & 255);
    this.I.push((a >>> 24) & 255);
  };
  n.oh = function (a) {
    H(a == Math.floor(a));
    H(a >= -0x7fffffffffffffff && a < 0x7fffffffffffffff);
    wj(a);
    this.Ef(sj, tj);
  };
  n.Df = function (a) {
    H(
      a == Infinity ||
        a == -Infinity ||
        isNaN(a) ||
        (typeof a === "number" &&
          a >= -3.4028234663852886e38 &&
          a <= 3.4028234663852886e38)
    );
    var b = yj(4);
    b.setFloat32(0, +a, !0);
    tj = 0;
    sj = b.getUint32(0, !0);
    this.Na(sj);
  };
  n.Cf = function (a) {
    H(
      typeof a === "number" ||
        a === "Infinity" ||
        a === "-Infinity" ||
        a === "NaN"
    );
    var b = yj(8);
    b.setFloat64(0, +a, !0);
    sj = b.getUint32(0, !0);
    tj = b.getUint32(4, !0);
    this.Na(sj);
    this.Na(tj);
  };
  n.Bf = function (a) {
    H(typeof a === "boolean" || typeof a === "number");
    this.I.push(a ? 1 : 0);
  };
  n.ce = function (a) {
    H(a == Math.floor(a));
    H(a >= -2147483648 && a < 2147483648);
    Zl(this, a);
  };
  var $l = function () {
      this.le = [];
      this.Qb = 0;
      this.F = new Xl();
    },
    am = function (a, b) {
      b.length !== 0 && (a.le.push(b), (a.Qb += b.length));
    },
    cm = function (a, b) {
      bm(a, b, 2);
      b = a.F.end();
      am(a, b);
      b.push(a.Qb);
      return b;
    },
    dm = function (a, b) {
      var c = b.pop();
      c = a.Qb + a.F.length() - c;
      for (H(c >= 0); c > 127; ) b.push((c & 127) | 128), (c >>>= 7), a.Qb++;
      b.push(c);
      a.Qb++;
    },
    bm = function (a, b, c) {
      H(b >= 1 && b == Math.floor(b));
      Yl(a.F, b * 8 + c);
    },
    em = function (a, b, c) {
      if (c != null)
        switch ((bm(a, b, 0), typeof c)) {
          case "number":
            a = a.F;
            H(c == Math.floor(c));
            H(c >= 0 && c < 1.8446744073709552e19);
            wj(c);
            a.jb(sj, tj);
            break;
          case "bigint":
            c = Wl(c, Hl, Kl);
            a.F.jb(c.Qc, c.Mc);
            break;
          default:
            (c = Jl(c)), a.F.jb(c.Qc, c.Mc);
        }
    };
  n = $l.prototype;
  n.nh = function (a, b) {
    b != null &&
      (fm(a, b, b >= -2147483648 && b < 2147483648),
      b != null && (gm(a, b), bm(this, a, 0), Zl(this.F, b)));
  };
  n.oh = function (a, b) {
    if (b != null) {
      switch (typeof b) {
        case "string":
          fm(a, b, Nl(b));
          break;
        case "number":
          fm(a, b, b >= -0x7fffffffffffffff && b < 0x7fffffffffffffff);
          break;
        default:
          fm(
            a,
            b,
            b >= BigInt(-0x7fffffffffffffff) && b < BigInt(0x7fffffffffffffff)
          );
      }
      if (b != null)
        switch ((bm(this, a, 0), typeof b)) {
          case "number":
            a = this.F;
            H(b == Math.floor(b));
            H(b >= -0x7fffffffffffffff && b < 0x7fffffffffffffff);
            wj(b);
            a.jb(sj, tj);
            break;
          case "bigint":
            b = Wl(b, Ll, Ol);
            this.F.jb(b.Qc, b.Mc);
            break;
          default:
            (b = Nl(b)), this.F.jb(b.Qc, b.Mc);
        }
    }
  };
  n.Na = function (a, b) {
    b != null &&
      (fm(a, b, b >= 0 && b < 4294967296),
      b != null && (bm(this, a, 0), Yl(this.F, b)));
  };
  n.ph = function (a, b) {
    if (b != null) {
      switch (typeof b) {
        case "string":
          fm(a, b, Jl(b));
          break;
        case "number":
          fm(a, b, b >= 0 && b < 1.8446744073709552e19);
          break;
        default:
          fm(a, b, b >= BigInt(0) && b < BigInt(1.8446744073709552e19));
      }
      em(this, a, b);
    }
  };
  n.Df = function (a, b) {
    b != null && (bm(this, a, 5), this.F.Df(b));
  };
  n.Cf = function (a, b) {
    b != null && (bm(this, a, 1), this.F.Cf(b));
  };
  n.Bf = function (a, b) {
    b != null &&
      (fm(a, b, typeof b === "boolean" || typeof b === "number"),
      bm(this, a, 0),
      this.F.Bf(b));
  };
  n.ce = function (a, b) {
    b != null &&
      ((b = parseInt(b, 10)), gm(a, b), bm(this, a, 0), Zl(this.F, b));
  };
  n.Ef = function (a, b) {
    bm(this, a, 1);
    this.F.Ef(b);
  };
  n.jb = function (a, b) {
    bm(this, a, 0);
    this.F.jb(b);
  };
  function gm(a, b) {
    fm(a, b, b === Math.floor(b));
    fm(a, b, b >= -2147483648 && b < 2147483648);
  }
  function fm(a, b, c) {
    c || Fb("for [" + b + "] at [" + a + "]");
  }
  function hm() {
    var a = function () {
      throw Error("oa");
    };
    Object.setPrototypeOf(a, a.prototype);
    return a;
  }
  var im = hm(),
    jm = hm(),
    km = hm(),
    lm = hm(),
    mm = hm(),
    nm = hm(),
    om = hm(),
    pm = hm(),
    qm = hm(),
    rm = hm(),
    sm = hm(),
    tm = hm();
  function um(a) {
    return a;
  }
  um[pk] = {};
  function vm(a) {
    return a;
  }
  var wm = function () {
    throw Error("pa");
  };
  if (Zk) {
    var xm = function () {
        throw Error("qa");
      },
      ym = {};
    Object.defineProperties(
      wm,
      ((ym[Symbol.hasInstance] = {
        value: xm,
        configurable: !1,
        writable: !1,
        enumerable: !1,
      }),
      ym)
    );
    H(
      wm[Symbol.hasInstance] === xm,
      "defineProperties did not work: was it monkey-patched?"
    );
  }
  function zm(a) {
    var b = Va(kk);
    return b ? L(a)[b] : void 0;
  }
  var Am = function () {},
    Bm = function (a, b) {
      for (var c in a) !isNaN(c) && b(a, +c, L(a[c]));
    },
    Cm = function (a) {
      var b = new Am();
      Bm(a, function (c, d, e) {
        b[d] = Array.prototype.slice.call(e);
      });
      b.Og = a.Og;
      return b;
    };
  function Dm(a, b) {
    H(Lk(a));
    H(Lk(a));
    a = Ik ? a[K(Jk)] : a.B;
    L(a);
    var c = Va(kk),
      d;
    gk &&
      c &&
      ((d = a[c]) == null ? void 0 : d[b]) != null &&
      jl(lk, 3, "0ub:" + b);
  }
  function Em(a, b) {
    b < 100 || jl(mk, 1, "0ubs:" + b);
  }
  function Fm(a, b, c, d, e) {
    var f = d !== void 0;
    d = !!d;
    var g = Va(kk),
      h;
    !f && gk && g && (h = a[g]) && Bm(h, Em);
    g = [];
    var k = a.length;
    h = 4294967295;
    var l = !1,
      m = !!(b & 64);
    if (m) {
      H(b & 64);
      var u = b & 128 ? 0 : -1;
    } else u = void 0;
    if (!(b & 1)) {
      var t = k && a[k - 1];
      t == null || typeof t !== "object" || t[rk] || t.constructor !== Object
        ? (t = void 0)
        : (k--, (h = k));
      if (m && !(b & 128) && !f) {
        l = !0;
        var r;
        b = (r = Gm) != null ? r : um;
        h = Qk(b(Tk(h, K(u)), K(u), a, t, e), K(u));
      }
    }
    e = void 0;
    for (r = 0; r < k; r++)
      if (((b = a[r]), b != null && (b = c(b, d)) != null))
        if (m && r >= h) {
          Hm();
          var w = Tk(r, K(u)),
            v = void 0;
          ((v = e) != null ? v : (e = {}))[w] = b;
        } else g[r] = b;
    if (t)
      for (var A in t)
        (k = t[A]),
          k != null &&
            (k = c(k, d)) != null &&
            ((r = +A),
            (b = void 0),
            m && !Number.isNaN(r) && (b = Qk(r, K(u))) < h
              ? (Hm(), (g[K(b)] = k))
              : ((r = void 0), (((r = e) != null ? r : (e = {}))[A] = k)));
    e && (l ? g.push(e) : (H(h < 4294967295), (g[h] = e)));
    f &&
      (c = Va(kk)) &&
      (L(g),
      L(a),
      H(g[c] === void 0),
      (a = zm(a)) && a instanceof Am && (g[c] = Cm(a)));
    return g;
  }
  function Im(a) {
    K(a);
    switch (typeof a) {
      case "number":
        return Number.isFinite(a) ? a : "" + a;
      case "bigint":
        return qj(a) ? Number(a) : "" + a;
      case "boolean":
        return a ? 1 : 0;
      case "object":
        if (Array.isArray(a)) {
          al(a);
          var b = L(a, "state is only maintained on arrays.")[Z] | 0;
          return a.length === 0 && b & 1 ? void 0 : Fm(a, b, Im);
        }
        if (Pk(a)) return Jm(a);
        if (a instanceof bj) {
          b = a.kd;
          if (b == null) a = "";
          else if (typeof b === "string") a = b;
          else {
            if (Vi) {
              for (var c = "", d = 0, e = b.length - 10240; d < e; )
                c += String.fromCharCode.apply(
                  null,
                  b.subarray(d, (d += 10240))
                );
              c += String.fromCharCode.apply(null, d ? b.subarray(d) : b);
              b = btoa(c);
            } else b = ai(b);
            a = a.kd = b;
          }
          return a;
        }
        H(!(a instanceof Uint8Array));
        return;
    }
    return a;
  }
  var Gm;
  function Km(a) {
    H(!Gm);
    return Jm(a);
  }
  function Jm(a) {
    H(Lk(a));
    var b = Ik ? a[K(Jk)] : a.B;
    var c = L(b, "state is only maintained on arrays.")[Z] | 0;
    zk(b, c);
    return Fm(b, c, Im, void 0, a.constructor);
  }
  function Hm() {
    var a,
      b = (a = Gm) != null ? a : um;
    H(b !== vm);
  }
  typeof Proxy !== "undefined" &&
    new Proxy(
      {},
      {
        getPrototypeOf: Lm,
        setPrototypeOf: Lm,
        isExtensible: Lm,
        preventExtensions: Lm,
        getOwnPropertyDescriptor: Lm,
        defineProperty: Lm,
        has: Lm,
        get: Lm,
        set: Lm,
        deleteProperty: Lm,
        apply: Lm,
        construct: Lm,
      }
    );
  function Lm(a, b) {
    if (b === rk) return !0;
    throw Error("wa");
  }
  var Mm, Nm;
  function Om(a) {
    switch (typeof a) {
      case "boolean":
        return Mm || (Mm = [0, void 0, !0]);
      case "number":
        return a > 0
          ? void 0
          : a === 0
          ? Nm || (Nm = [0, void 0])
          : [-a, void 0];
      case "string":
        return [0, a];
      case "object":
        return (
          L(a),
          H(a.length === 2 || (a.length === 3 && a[2] === !0)),
          H(a[0] == null || (typeof a[0] === "number" && a[0] >= 0)),
          H(a[1] == null || typeof a[1] === "string"),
          a
        );
    }
  }
  function Pm(a, b) {
    L(b);
    return Qm(a, b[0], b[1]);
  }
  function Qm(a, b, c, d) {
    d = d === void 0 ? 0 : d;
    if (a != null)
      for (var e = 0; e < a.length; e++) {
        var f = a[e];
        Array.isArray(f) && al(f);
      }
    if (a == null)
      (e = 32), c ? ((a = [c]), (e |= 128)) : (a = []), b && (e = Dk(e, b));
    else {
      if (!Array.isArray(a))
        throw Error("ya`" + JSON.stringify(a) + "`" + Qa(a));
      e = L(a, "state is only maintained on arrays.")[Z] | 0;
      if (Xh && 1 & e) throw Error("za");
      2048 & e && !(2 & e) && Rm();
      if (Object.isFrozen(a) || !Object.isExtensible(a) || Object.isSealed(a))
        throw Error("Aa");
      if (e & 256) throw Error("Ba");
      if (e & 64) return (e | d) !== e && wk(a, (e |= d)), zk(a, e), a;
      if (c && ((e |= 128), c !== a[0]))
        throw Error("Ca`" + c + "`" + JSON.stringify(a[0]) + "`" + Qa(a[0]));
      a: {
        c = a;
        e |= 64;
        var g = c.length;
        if (g) {
          var h = g - 1;
          f = c[h];
          if (
            f != null &&
            typeof f === "object" &&
            !f[rk] &&
            f.constructor === Object
          ) {
            b = Ek(e);
            g = Tk(h, b);
            if (g >= 1024) throw Error("Ea`" + g);
            for (var k in f)
              (h = +k),
                h < g &&
                  ((h = Qk(h, b)), H(c[h] == null), (c[h] = f[k]), delete f[k]);
            e = Dk(e, g);
            break a;
          }
        }
        if (b) {
          k = Math.max(b, Tk(g, Ek(e)));
          if (k > 1024) throw Error("Fa`" + g);
          e = Dk(e, k);
        }
      }
    }
    wk(a, e | 64 | d);
    return a;
  }
  function Rm() {
    if (Xh) throw Error("Da");
  }
  function Sm(a) {
    H(!(2 & a));
    H(!(2048 & a));
    return !(4096 & a) && !(16 & a);
  }
  function Tm(a, b) {
    K(a);
    if (typeof a !== "object") return a;
    if (Array.isArray(a)) {
      al(a);
      var c = L(a, "state is only maintained on arrays.")[Z] | 0;
      a.length === 0 && c & 1
        ? (a = void 0)
        : c & 2 ||
          (b && Sm(c)
            ? (yk(a, 34), c & 4 && Object.freeze(a))
            : (a = Um(a, c, !1, b && !(c & 16))));
      return a;
    }
    if (Pk(a))
      return (
        H(Pk(a)),
        (b = Kk(a)),
        (c = Bk(b)),
        Uk(a, c) ? a : Vm(a, b, c) ? Wm(a, b) : Um(b, c)
      );
    if (a instanceof bj) return a;
    H(!(a instanceof Uint8Array));
  }
  function Wm(a, b, c) {
    a = new a.constructor(b);
    c && Xk(a, !0);
    a.Ni = Wk;
    return a;
  }
  function Um(a, b, c, d) {
    H(b === (L(a, "state is only maintained on arrays.")[Z] | 0));
    d != null || (d = !!(34 & b));
    a = Fm(a, b, Tm, d);
    d = 32;
    c && (d |= 2);
    b = (b & 16769217) | d;
    wk(a, b);
    return a;
  }
  function Xm(a) {
    if (!Vk(a)) return !1;
    var b;
    H(Lk(a));
    var c = (b = Ik ? a[K(Jk)] : a.B),
      d = L(c, "state is only maintained on arrays.")[Z] | 0;
    zk(c, d);
    H(d & 2);
    b = Um(b, d);
    yk(b, 2048);
    H(Lk(a));
    L(b);
    Ik ? (a[K(Jk)] = b) : (a.B = b);
    Xk(a, !1);
    a.Ni = void 0;
    return !0;
  }
  function Ym(a) {
    var b;
    if ((b = !Xm(a))) {
      H(Lk(a));
      b = Ik ? a[K(Jk)] : a.B;
      var c = L(b, "state is only maintained on arrays.")[Z] | 0;
      zk(b, c);
      b = Uk(a, c);
    }
    if (b) throw Error("ja");
  }
  function Zm(a, b) {
    if (b === void 0)
      (b = L(a, "state is only maintained on arrays.")[Z] | 0), zk(a, b, !0);
    else {
      var c = L(a, "state is only maintained on arrays.")[Z] | 0;
      zk(a, c, !0);
      H(b === c);
    }
    H(!(b & 2));
    b & 32 && !(b & 4096) && wk(a, b | 4096);
  }
  function Vm(a, b, c) {
    return Yk && a[Yk]
      ? !1
      : c & 2
      ? !0
      : c & 32 && !(c & 4096)
      ? (wk(b, c | 2), Xk(a, !0), !0)
      : !1;
  }
  var an = function (a, b) {
      H(Object.isExtensible(a));
      H(Lk(a));
      a = Ik ? a[K(Jk)] : a.B;
      b = $m(a, b);
      (a = b !== null) || (a = void 0);
      if (a) return b;
    },
    bn = function (a, b, c, d) {
      return $m(a, b, c, d);
    };
  function $m(a, b, c, d) {
    fl(a, c);
    if (b === -1) return null;
    var e = Rk(b, c);
    H(e === Qk(b, Ek(L(a, "state is only maintained on arrays.")[Z] | 0)));
    H(e >= 0);
    var f = a.length - 1;
    if (!(f < Rk(1, c))) {
      if (e >= f) {
        var g = a[f];
        if (
          g == null ||
          typeof g !== "object" ||
          g[rk] ||
          g.constructor !== Object
        )
          if (e === f) c = g;
          else return;
        else {
          c = g[b];
          var h = !0;
        }
      } else c = a[e];
      if (d && c != null) {
        d = d(c);
        if (d == null) return d;
        if (!Object.is(d, c)) return h ? (g[b] = d) : (a[e] = d), d;
      }
      return c;
    }
  }
  var dn = function (a, b, c) {
    Ym(a);
    H(Lk(a));
    var d = Ik ? a[K(Jk)] : a.B;
    var e = L(d, "state is only maintained on arrays.")[Z] | 0;
    zk(d, e);
    cn(d, e, b, c);
    return a;
  };
  function cn(a, b, c, d, e) {
    fl(a, e);
    var f = Rk(c, e);
    H(f === Qk(c, Ek(L(a, "state is only maintained on arrays.")[Z] | 0)));
    H(f >= 0);
    var g = a.length - 1;
    if (g >= Rk(1, e) && f >= g) {
      var h = a[g];
      if (
        h != null &&
        typeof h === "object" &&
        !h[rk] &&
        h.constructor === Object
      )
        return (h[c] = d), b;
    }
    if (f <= g) return (a[f] = d), b;
    d !== void 0 &&
      ((g = b) == null &&
        ((b = L(a, "state is only maintained on arrays.")[Z] | 0),
        zk(a, b),
        (g = b)),
      H(g & 64),
      (g = (g >> 14) & 1023 || 536870912),
      c >= g
        ? (H(g !== 536870912),
          d != null && ((f = {}), (a[Rk(g, e)] = ((f[c] = d), f))))
        : (a[f] = d));
    return b;
  }
  var en = function (a, b, c) {
    H(Lk(a));
    a = Ik ? a[K(Jk)] : a.B;
    b = $m(a, b, c);
    return Pk(b) || Array.isArray(b);
  };
  function fn(a, b) {
    if (!a) return a;
    H(Ck(b) ? Uk(a) : !0);
    return a;
  }
  function gn(a, b, c) {
    c = c === void 0 ? !1 : c;
    al(a, c);
    var d = L(a, "state is only maintained on arrays.")[Z] | 0;
    H(d & 1);
    c || (H(Object.isFrozen(a) || d & 16), H(Ck(b) ? Object.isFrozen(a) : !0));
  }
  function hn(a, b, c, d, e) {
    H(Lk(a));
    var f = Ik ? a[K(Jk)] : a.B;
    var g = L(f, "state is only maintained on arrays.")[Z] | 0;
    zk(f, g);
    var h = g;
    if (d && d !== 4) {
      var k;
      if ((k = d !== 1)) k = a ? Uk(a, h) : !!(2 & h);
      d = k ? 1 : d;
    } else d = 4;
    e = !!e || d === 3;
    d === 2 &&
      Xm(a) &&
      (H(Lk(a)),
      (f = Ik ? a[K(Jk)] : a.B),
      (g = L(f, "state is only maintained on arrays.")[Z] | 0),
      zk(f, g));
    a = jn(f, b);
    h = a === uk ? 7 : L(a, "state is only maintained on arrays.")[Z] | 0;
    var l = Fk(h, g);
    bl(a);
    if ((k = !(4 & l))) {
      for (var m = 0, u = 0; m < a.length; m++) {
        var t = c(a[m]);
        t != null && (a[u++] = t);
      }
      u < m && (a.length = u);
      c = (l | 4) & -513;
      l = c &= -1025;
      l &= -4097;
    }
    l !== h && (wk(a, l), 2 & l && Object.freeze(a));
    a = kn(a, l, f, g, b, d, k, e);
    bl(a);
    e || gn(a, f);
    return a;
  }
  function kn(a, b, c, d, e, f, g, h) {
    var k = b,
      l = ln(b);
    l &&
      f === 2 &&
      ((a = Array.prototype.slice.call(a)),
      (k = 0),
      (b = mn(b, d)),
      (d = K(cn(c, d, e, a))),
      (l = !1));
    l ||
      (f === 1 || (f !== 4 ? 0 : 2 & b || (!(16 & b) && 32 & d))
        ? ((e = !a.length || (g && !(4096 & b)) || (!!(32 & d) && Sm(b))),
          (b |= e ? 2 : 256),
          b !== k && wk(a, b),
          Object.freeze(a))
        : (h || (b |= 16), b !== k && wk(a, b)));
    2 & b || Sm(b) || Zm(c, d);
    return a;
  }
  function jn(a, b, c) {
    a = $m(a, b, c);
    return Array.isArray(a) ? a : uk;
  }
  function ln(a) {
    return (!!(2 & a) && !!(4 & a)) || !!(256 & a);
  }
  function nn(a, b, c) {
    if (b & 2) throw Error("ja");
    var d = gl(b),
      e = jn(a, c, d),
      f = e === uk ? 7 : L(e, "state is only maintained on arrays.")[Z] | 0,
      g = Fk(f, b);
    if (2 & g || ln(g) || 16 & g)
      g === f || ln(g) || wk(e, g),
        (e = Array.prototype.slice.call(e)),
        (f = 0),
        (g = mn(g, b)),
        K(cn(a, b, c, e, d));
    g &= -13;
    g !== f && wk(e, g);
    return e;
  }
  function on(a, b, c) {
    var d = L(a, "state is only maintained on arrays.")[Z] | 0;
    zk(a, d, !0);
    var e = gl(d),
      f = $m(a, c, e);
    if (Pk(f)) {
      if (!Uk(f)) return Xm(f), H(Lk(f)), Ik ? f[K(Jk)] : f.B;
      H(Lk(f));
      var g = Ik ? f[K(Jk)] : f.B;
      H((L(g, "state is only maintained on arrays.")[Z] | 0) & 2);
    } else Array.isArray(f) && ((g = f), d & 2 && yk(g, 34));
    if (g) {
      var h = L(g, "state is only maintained on arrays.")[Z] | 0;
      h & 2 && (g = Um(g, h));
    }
    g = Pm(g, b);
    g !== f && cn(a, d, c, g, e);
    return g;
  }
  function pn(a, b, c, d, e) {
    var f = !1;
    d = bn(a, d, e, function (g) {
      var h = Gl(g, c, b);
      f = h !== g && h != null;
      return h;
    });
    if (d != null) return f && !Uk(d) && Zm(a, b), fn(d, a);
  }
  var rn = function (a) {
      var b = qn;
      H(Lk(a));
      a = Ik ? a[K(Jk)] : a.B;
      var c = L(a, "state is only maintained on arrays.")[Z] | 0;
      zk(a, c);
      (a = pn(a, c, b, 2)) ||
        (a = b[jk]) ||
        ((a = new b()),
        H(Lk(a)),
        (c = Ik ? a[K(Jk)] : a.B),
        yk(c, 34),
        (a = b[jk] = a));
      return a;
    },
    sn = function (a, b, c, d) {
      H(Lk(a));
      var e = Ik ? a[K(Jk)] : a.B;
      var f = L(e, "state is only maintained on arrays.")[Z] | 0;
      zk(e, f);
      b = pn(e, f, b, c, d);
      if (b == null) return b;
      f = L(e, "state is only maintained on arrays.")[Z] | 0;
      zk(e, f);
      if (!Uk(a, f)) {
        var g = b;
        H(Lk(g));
        var h = Ik ? g[K(Jk)] : g.B;
        var k = L(h, "state is only maintained on arrays.")[Z] | 0;
        zk(h, k);
        g = Uk(g, k)
          ? Vm(g, h, k)
            ? Wm(g, h, !0)
            : new g.constructor(Um(h, k, !1))
          : g;
        g !== b &&
          (Xm(a) &&
            (H(Lk(a)),
            (e = Ik ? a[K(Jk)] : a.B),
            (a = L(e, "state is only maintained on arrays.")[Z] | 0),
            zk(e, a),
            (f = a)),
          (b = g),
          (f = cn(e, f, c, b, d)),
          Zm(e, f));
      }
      return fn(b, e);
    },
    un = function (a) {
      var b = tn;
      H(Lk(a));
      a = Ik ? a[K(Jk)] : a.B;
      var c = L(a, "state is only maintained on arrays.")[Z] | 0;
      zk(a, c);
      var d = jn(a, 10),
        e = d === uk ? 7 : L(d, "state is only maintained on arrays.")[Z] | 0,
        f = Fk(e, c),
        g = !(4 & f);
      if (g) {
        var h = d,
          k = c,
          l = !!(2 & f);
        l && (k |= 2);
        for (var m = !l, u = !0, t = 0, r = 0; t < h.length; t++) {
          var w = Gl(h[t], b, k);
          if (w instanceof b) {
            if (!l) {
              var v = Uk(w);
              m && (m = !v);
              u && (u = v);
            }
            h[r++] = w;
          }
        }
        r < t && (h.length = r);
        f |= 4;
        f = u ? f & -4097 : f | 4096;
        f = m ? f | 8 : f & -9;
      }
      f !== e && (wk(d, f), 2 & f && Object.freeze(d));
      b = d = kn(d, f, a, c, 10, 1, g, !1);
      c = !1;
      c = c === void 0 ? !1 : c;
      e = Ck(a);
      g = Ck(b);
      h = Object.isFrozen(b) && g;
      gn(b, a, c);
      if (e || g) c ? H(g) : H(h);
      H(!!((L(b, "state is only maintained on arrays.")[Z] | 0) & 4));
      if (g && b.length) for (c = 0; c < 1; c++) fn(b[c], a);
      return d;
    },
    vn = function (a, b, c, d) {
      d != null ? Fl(d, K(b)) : (d = void 0);
      dn(a, c, d);
      d && !Uk(d) && (H(Lk(a)), (b = Ik ? a[K(Jk)] : a.B), Zm(b));
      return a;
    };
  function mn(a, b) {
    return (a = (2 & b ? a | 2 : a & -3) & -273);
  }
  var wn = function (a, b, c) {
      var d;
      return (d = sl(an(a, b))) != null ? d : c === void 0 ? !1 : c;
    },
    xn = function (a, b) {
      var c = c === void 0 ? 0 : c;
      var d;
      return (d = zl(an(a, b))) != null ? d : c;
    },
    yn = function (a, b) {
      a = El(an(a, b));
      return a != null ? a : "";
    },
    zn = function (a, b, c) {
      if (c != null && typeof c !== "boolean")
        throw Error("la`" + Qa(c) + "`" + c);
      return dn(a, b, c);
    },
    An = function (a, b, c) {
      if (c != null) {
        if (typeof c !== "number") throw il(Al(c));
        if (!nl(c)) throw il(Al(c));
        c >>>= 0;
      }
      return dn(a, b, c);
    },
    Bn = function (a, b, c) {
      if (c != null && typeof c !== "string")
        throw Error("ma`" + c + "`" + Qa(c));
      return dn(a, b, c);
    },
    Cn = function (a, b, c) {
      return dn(a, b, c == null ? c : vl(c));
    },
    Dn = function (a, b, c) {
      Ym(a);
      b = hn(a, b, wl, 2, !0);
      b === uk || L(b, "state is only maintained on arrays.");
      if (Array.isArray(c))
        for (var d = c.length, e = 0; e < d; e++) b.push(vl(c[e]));
      else {
        c = x(c);
        d = c.next();
        try {
          for (; !d.done; d = c.next()) b.push(vl(d.value));
        } finally {
          ra(c, d);
        }
      }
      bl(b);
      return a;
    };
  var En = function (a, b, c) {
    this.preventPassingToStructuredClone = $k;
    Lb(this, En, "The message constructor should only be used by subclasses");
    H(
      this.constructor !== En,
      "Message is an abstract class and cannot be directly constructed"
    );
    var d = this.constructor,
      e;
    if (a && ((e = a[qk]) != null ? e : (a[qk] = d)) !== d) throw Error("Ga");
    a = Qm(a, b, c, 2048);
    H(Lk(this));
    L(a);
    Ik ? (this[K(Jk)] = a) : (this.B = a);
    H(Lk(this));
    a = Ik ? this[K(Jk)] : this.B;
    b = L(a, "state is only maintained on arrays.")[Z] | 0;
    zk(a, b);
    H(b & 64);
    H(b & 2048);
  };
  n = En.prototype;
  n.toJSON = function () {
    return Km(this);
  };
  n.hb = function () {
    return JSON.stringify(Km(this));
  };
  n.getExtension = function (a) {
    Lb(this, a.bg);
    var b = Lb(this, En);
    Dm(b, a.Ga);
    return a.Xb
      ? a.Jd
        ? a.Yb(b, a.Xb, a.Ga, 4, a.xb)
        : a.Yb(b, a.Xb, a.Ga, a.xb)
      : a.Jd
      ? a.Yb(b, a.Ga, 4, a.xb)
      : a.Yb(b, a.Ga, a.defaultValue, a.xb);
  };
  n.hasExtension = function (a) {
    H(!a.Jd, "repeated extensions don't support hasExtension");
    var b = Lb(this, En);
    Dm(b, a.Ga);
    a.Xb
      ? (a = en(b, a.Ga, a.xb))
      : (H(!a.Jd, "repeated extensions don't support getExtensionOrUndefined"),
        Lb(b, a.bg),
        (b = Lb(b, En)),
        Dm(b, a.Ga),
        (a = a.Xb ? a.Yb(b, a.Xb, a.Ga, a.xb) : a.Yb(b, a.Ga, null, a.xb)),
        (a = (a === null ? void 0 : a) !== void 0));
    return a;
  };
  n.clone = function () {
    var a = Lb(this, En);
    H(Pk(a));
    var b = Kk(a),
      c = Bk(b);
    return Vm(a, b, c) ? Wm(a, b, !0) : new a.constructor(Um(b, c, !1));
  };
  n.zg = function () {
    return Uk(this);
  };
  Mk = En;
  En.prototype[ok] = Ok;
  En.prototype.toString = function () {
    H(Lk(this));
    return (Ik ? this[K(Jk)] : this.B).toString();
  };
  var Fn = function (a, b, c, d) {
    this.de = a;
    this.ee = b;
    a = Va(jm);
    this.qh = (!!a && d === a) || !1;
  };
  function Gn(a) {
    var b = Hn;
    var c = c === void 0 ? jm : c;
    return new Fn(a, b, !1, c);
  }
  function Hn(a, b, c, d, e) {
    b = In(b, d);
    b != null && ((c = cm(a, c)), e(b, a), dm(a, c));
  }
  var Jn = Gn(function (a, b, c, d, e) {
      if (a.m !== 2) return !1;
      Zj(a, on(b, d, c), e);
      return !0;
    }),
    Kn = Gn(function (a, b, c, d, e) {
      if (a.m !== 2) return !1;
      Zj(a, on(b, d, c), e);
      return !0;
    }),
    Ln = Symbol(),
    Mn = Symbol(),
    Nn = Symbol(),
    On = Symbol(),
    Pn = Symbol(),
    Qn,
    Rn;
  function Sn(a, b, c, d) {
    var e = d[a];
    if (e) return e;
    e = {};
    e.Ch = d;
    e.Wc = oh(Om(d[0]));
    var f = d[1],
      g = 1;
    f &&
      f.constructor === Object &&
      ((e.extensions = f),
      (f = d[++g]),
      typeof f === "function" &&
        f.length > 0 &&
        (Qn != null && (nh(Qn === f), nh(Rn === d[1 + g])),
        (e.Bg = !0),
        Qn != null || (Qn = f),
        Rn != null || (Rn = mh(d[g + 1], yh)),
        (f = d[(g += 2)])));
    for (var h = {}; f && Tn(f); ) {
      for (var k = 0; k < f.length; k++) h[f[k]] = f;
      f = d[++g];
    }
    for (k = 1; f !== void 0; ) {
      typeof f === "number" && (nh(f > 0), (k += f), (f = d[++g]));
      var l = void 0;
      if (f instanceof Fn) var m = f;
      else (m = Jn), g--;
      f = void 0;
      if ((f = m) == null ? 0 : f.qh) {
        f = d[++g];
        l = d;
        var u = g;
        typeof f === "function" && (nh(f.length === 0), (f = f()), (l[u] = f));
        Un(f);
        l = f;
      }
      f = d[++g];
      u = k + 1;
      typeof f === "number" && f < 0 && ((u -= f), (f = d[++g]));
      for (; k < u; k++) {
        var t = h[k];
        l ? c(e, k, oh(m), l, t) : b(e, k, oh(m), t);
      }
    }
    return (d[a] = e);
  }
  function Tn(a) {
    return (
      Array.isArray(a) && !!a.length && typeof a[0] === "number" && a[0] > 0
    );
  }
  function Un(a) {
    if (Array.isArray(a) && a.length) {
      var b = a[0];
      var c = Om(b);
      c != null && c !== b && (a[0] = c);
      b = c != null;
    } else b = !1;
    nh(b);
    return a;
  }
  function Vn(a) {
    return Array.isArray(a)
      ? a[0] instanceof Fn
        ? (nh(a.length === 2), Un(a[1]), a)
        : [Kn, Un(a)]
      : [mh(a, zh(Fn)), void 0];
  }
  function In(a, b) {
    if (a instanceof En) return H(Lk(a)), Ik ? a[K(Jk)] : a.B;
    if (Array.isArray(a)) return Pm(a, b);
  }
  function Wn(a) {
    return Sn(Mn, $n, ao, a);
  }
  function $n(a, b, c, d) {
    var e = c.de;
    a[b] = d
      ? function (f, g, h) {
          return e(f, g, h, d);
        }
      : e;
  }
  function ao(a, b, c, d, e) {
    var f = c.de,
      g,
      h;
    a[b] = function (k, l, m) {
      return f(k, l, m, h || (h = Wn(d).Wc), g || (g = bo(d)), e);
    };
  }
  function bo(a) {
    var b = a[Nn];
    if (b != null) return b;
    var c = Wn(a);
    b = c.Bg
      ? function (d, e) {
          return oh(Qn)(d, e, c);
        }
      : function (d, e) {
          a: {
            Xj();
            try {
              var f = L(d, "state is only maintained on arrays.")[Z] | 0;
              zk(d, f, !0);
              for (nh(!(f & 2)); Wj(e) && e.m != 4; ) {
                var g = e.lc,
                  h = c[g];
                if (h == null) {
                  var k = c.extensions;
                  if (k) {
                    var l = k[g];
                    if (l) {
                      var m = co(l);
                      m != null && (h = c[g] = m);
                    }
                  }
                }
                if (h == null || !h(e, d, g)) {
                  f = e;
                  var u = f.sb;
                  Yj(f);
                  if (f.Wf) var t = void 0;
                  else {
                    var r = f.o.ga(),
                      w = r - u;
                    f.o.T = u;
                    var v = f.o.cf(w);
                    H(r == f.o.ga());
                    t = v;
                  }
                  var A = (w = f = void 0),
                    C = d,
                    G = g,
                    J = t;
                  L(C);
                  J &&
                    ((f = (w = (A = C[kk]) != null ? A : (C[kk] = new Am()))[
                      G
                    ]) != null
                      ? f
                      : (w[G] = [])
                    ).push(J);
                }
              }
              var Y = zm(d);
              Y && (Y.Og = oh(c.Ch[Pn]));
              var I = !0;
              break a;
            } catch (B) {
              if (B instanceof RangeError) throw dj();
              throw mh(B, zh(Error));
            } finally {
              Rj > 0 && Rj--;
            }
            I = void 0;
          }
          return I;
        };
    a[Nn] = b;
    a[Pn] = eo.bind(a);
    return b;
  }
  function eo(a, b, c, d) {
    var e = this[Mn],
      f = this[Nn],
      g = Pm(void 0, e.Wc),
      h = zm(a);
    if (h) {
      var k = !1,
        l = e.extensions;
      if (l) {
        e = function (w, v, A) {
          if (A.length !== 0)
            if (l[v]) {
              w = x(A);
              v = w.next();
              try {
                for (; !v.done; v = w.next()) {
                  var C = Vj(v.value);
                  try {
                    (k = !0), f(g, C);
                  } finally {
                    C.Be();
                  }
                }
              } finally {
                ra(w, v);
              }
            } else d == null || d(a, v, A);
        };
        if (b == null) Bm(h, e);
        else if (h != null) {
          var m = h[b];
          m && e(h, b, m);
        }
        if (k) {
          var u = Ak(a);
          if (u & 2 && u & 2048 && (c == null || !c.Rk)) throw Error("Ia");
          var t = gl(u),
            r = function (w, v) {
              if ($m(a, w, t) != null)
                switch (c == null ? void 0 : c.Qk) {
                  case 1:
                    return;
                  default:
                    throw Error("Ja`" + w);
                }
              v != null && (u = oh(cn(a, u, w, v, t)));
              delete h[w];
            };
          b == null
            ? el(g, Ak(g), function (w, v) {
                r(w, v);
              })
            : r(b, $m(g, b, t));
        }
      }
    }
  }
  function co(a) {
    a = Vn(a);
    var b = mh(a[0], zh(Fn)).de;
    if ((a = a[1])) {
      var c = bo(Un(a)),
        d = Wn(Un(a)).Wc;
      return function (e, f, g) {
        return b(e, f, g, d, c);
      };
    }
    return b;
  }
  function fo(a, b, c) {
    a[b] = c.ee;
  }
  function go(a, b, c, d) {
    var e,
      f,
      g = c.ee;
    a[b] = function (h, k, l) {
      return g(h, k, l, f || (f = Sn(Ln, fo, go, d).Wc), e || (e = ho(d)));
    };
  }
  function ho(a) {
    var b = a[On];
    if (!b) {
      var c = Sn(Ln, fo, go, a);
      b = function (d, e) {
        return io(d, e, c);
      };
      a[On] = b;
    }
    return b;
  }
  function io(a, b, c) {
    el(a, L(a, "state is only maintained on arrays.")[Z] | 0, function (e, f) {
      if (f != null) {
        var g = jo(c, e);
        g ? g(b, f, e) : (L(a), e < 500 || jl(nk, 3, "0ubsb:" + e));
      }
    });
    var d = zm(a);
    d &&
      Bm(d, function (e, f, g) {
        am(b, b.F.end());
        for (e = 0; e < g.length; e++) am(b, ej(g[e]));
      });
  }
  function jo(a, b) {
    var c = a[b];
    if (c) return c;
    if ((c = a.extensions))
      if ((c = c[b])) {
        c = Vn(c);
        var d = mh(c[0], zh(Fn)).ee;
        if ((c = c[1])) {
          c = Un(c);
          var e = ho(c),
            f = Sn(Ln, fo, go, c).Wc;
          c = a.Bg
            ? oh(Rn)(f, e)
            : function (g, h, k) {
                return d(g, h, k, f, e);
              };
        } else c = d;
        return (a[b] = c);
      }
  }
  function ko(a, b, c) {
    if (Array.isArray(b)) {
      var d = L(b, "state is only maintained on arrays.")[Z] | 0;
      if (d & 4) return b;
      for (var e = 0, f = 0; e < b.length; e++) {
        var g = a(b[e]);
        g != null &&
          (H(typeof g !== "object" || g instanceof bj), (b[f++] = g));
      }
      f < e && (b.length = f);
      a = d | 1;
      c && (a = (a | 4) & -1537);
      a !== d && wk(b, a);
      c && a & 2 && Object.freeze(b);
      return b;
    }
  }
  var lo = function (a, b) {
    var c = new $l();
    io(Kk(Lb(a, En)), c, Sn(Ln, fo, go, b));
    am(c, c.F.end());
    a = new Uint8Array(c.Qb);
    b = c.le;
    for (var d = b.length, e = 0, f = 0; f < d; f++) {
      var g = b[f];
      a.set(g, e);
      e += g.length;
    }
    H(e == a.length);
    c.le = [a];
    return a;
  };
  function mo(a, b, c) {
    return new Fn(a, b, !1, c);
  }
  function no(a, b, c) {
    return new Fn(a, b, im, c);
  }
  function oo(a, b, c) {
    var d = L(a, "state is only maintained on arrays.")[Z] | 0;
    zk(a, d, !0);
    cn(a, d, b, c, gl(L(a, "state is only maintained on arrays.")[Z] | 0));
  }
  function po(a, b, c) {
    if (a.m !== 0 && a.m !== 2) return !1;
    var d = L(b, "state is only maintained on arrays.")[Z] | 0;
    zk(b, d, !0);
    b = nn(b, d, c);
    a.m == 2 ? fk(a, Pj, b) : b.push(dk(a));
    return !0;
  }
  var qo = mo(
      function (a, b, c) {
        if (a.m !== 1) return !1;
        H(a.m == 1);
        var d = a.o;
        a = Nj(d);
        var e = Nj(d);
        d = (e >> 31) * 2 + 1;
        var f = (e >>> 20) & 2047;
        a = 4294967296 * (e & 1048575) + a;
        oo(
          b,
          c,
          f == 2047
            ? a
              ? NaN
              : d * Infinity
            : f == 0
            ? d * 4.9e-324 * a
            : d * Math.pow(2, f - 1075) * (a + 4503599627370496)
        );
        return !0;
      },
      function (a, b, c) {
        a.Cf(c, ql(b));
      },
      sm
    ),
    ro = mo(
      function (a, b, c) {
        if (a.m !== 5) return !1;
        H(a.m == 5);
        var d = Nj(a.o);
        a = (d >> 31) * 2 + 1;
        var e = (d >>> 23) & 255;
        d &= 8388607;
        oo(
          b,
          c,
          e == 255
            ? d
              ? NaN
              : a * Infinity
            : e == 0
            ? a * 1.401298464324817e-45 * d
            : a * Math.pow(2, e - 150) * (d + 8388608)
        );
        return !0;
      },
      function (a, b, c) {
        a.Df(c, ql(b));
      },
      rm
    ),
    so = mo(
      function (a, b, c) {
        a.m !== 0
          ? (b = !1)
          : (H(a.m == 0), (a = Jj(a.o, Cj)), oo(b, c, a), (b = !0));
        return b;
      },
      function (a, b, c) {
        a.oh(c, Cl(b));
      },
      pm
    ),
    to = mo(
      function (a, b, c) {
        a.m !== 0 ? (a = !1) : (oo(b, c, ck(a)), (a = !0));
        return a;
      },
      function (a, b, c) {
        a.ph(c, Dl(b));
      },
      qm
    ),
    uo = no(
      function (a, b, c) {
        if (a.m !== 0 && a.m !== 2) a = !1;
        else {
          var d = L(b, "state is only maintained on arrays.")[Z] | 0;
          zk(b, d, !0);
          b = nn(b, d, c);
          a.m == 2 ? fk(a, Mj, b) : b.push(ck(a));
          a = !0;
        }
        return a;
      },
      function (a, b, c) {
        b = ko(Dl, b, !1);
        if (b != null) for (var d = 0; d < b.length; d++) em(a, c, b[d]);
      },
      qm
    ),
    vo = mo(
      function (a, b, c) {
        if (a.m !== 0) return !1;
        oo(b, c, ak(a));
        return !0;
      },
      function (a, b, c) {
        a.nh(c, zl(b));
      },
      mm
    ),
    wo = no(
      function (a, b, c) {
        if (a.m !== 0 && a.m !== 2) return !1;
        var d = L(b, "state is only maintained on arrays.")[Z] | 0;
        zk(b, d, !0);
        b = nn(b, d, c);
        a.m == 2 ? fk(a, Kj, b) : b.push(ak(a));
        return !0;
      },
      function (a, b, c) {
        b = ko(zl, b, !0);
        if (b != null)
          for (var d = 0; d < b.length; d++) {
            var e = a,
              f = c,
              g = b[d];
            g != null && (gm(f, g), bm(e, f, 0), Zl(e.F, g));
          }
      },
      mm
    ),
    xo = mo(
      function (a, b, c) {
        if (a.m !== 5) return !1;
        H(a.m == 5);
        a = Nj(a.o);
        oo(b, c, a);
        return !0;
      },
      function (a, b, c) {
        b = Bl(b);
        b != null &&
          (fm(c, b, b >= 0 && b < 4294967296), bm(a, c, 5), a.F.Na(b));
      },
      om
    ),
    yo = mo(
      function (a, b, c) {
        if (a.m !== 0) return !1;
        H(a.m == 0);
        a = Oj(a.o);
        oo(b, c, a);
        return !0;
      },
      function (a, b, c) {
        a.Bf(c, sl(b));
      },
      km
    ),
    zo = mo(
      function (a, b, c) {
        if (a.m !== 2) return !1;
        oo(b, c, ek(a));
        return !0;
      },
      function (a, b, c) {
        b = El(b);
        if (b != null) {
          var d = !0;
          d = d === void 0 ? !1 : d;
          Hb(b);
          if (Ti) {
            if (
              d &&
              (Si
                ? !b.isWellFormed()
                : /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(
                    b
                  ))
            )
              throw Error("T");
            b = (Ri || (Ri = new TextEncoder())).encode(b);
          } else {
            for (
              var e = 0, f = new Uint8Array(3 * b.length), g = 0;
              g < b.length;
              g++
            ) {
              var h = b.charCodeAt(g);
              if (h < 128) f[e++] = h;
              else {
                if (h < 2048) f[e++] = (h >> 6) | 192;
                else {
                  H(h < 65536);
                  if (h >= 55296 && h <= 57343) {
                    if (h <= 56319 && g < b.length) {
                      var k = b.charCodeAt(++g);
                      if (k >= 56320 && k <= 57343) {
                        h = (h - 55296) * 1024 + k - 56320 + 65536;
                        f[e++] = (h >> 18) | 240;
                        f[e++] = ((h >> 12) & 63) | 128;
                        f[e++] = ((h >> 6) & 63) | 128;
                        f[e++] = (h & 63) | 128;
                        continue;
                      } else g--;
                    }
                    if (d) throw Error("T");
                    h = 65533;
                  }
                  f[e++] = (h >> 12) | 224;
                  f[e++] = ((h >> 6) & 63) | 128;
                }
                f[e++] = (h & 63) | 128;
              }
            }
            b = e === f.length ? f : f.subarray(0, e);
          }
          bm(a, c, 2);
          Yl(a.F, b.length);
          am(a, a.F.end());
          am(a, b);
        }
      },
      lm
    ),
    Ao,
    Bo = void 0;
  Bo = Bo === void 0 ? jm : Bo;
  Ao = new Fn(
    function (a, b, c, d, e) {
      if (a.m !== 2) return !1;
      d = Pm(void 0, d);
      var f = L(b, "state is only maintained on arrays.")[Z] | 0;
      zk(b, f, !0);
      nn(b, f, c).push(d);
      Zj(a, d, e);
      return !0;
    },
    function (a, b, c, d, e) {
      if (Array.isArray(b)) {
        for (var f = 0; f < b.length; f++) {
          var g = a,
            h = c,
            k = e,
            l = In(b[f], d);
          l != null && ((h = cm(g, h)), k(l, g), dm(g, h));
        }
        a = xk(b);
        a & 1 || wk(b, a | 1);
      }
    },
    im,
    Bo
  );
  var Co = mo(
      function (a, b, c) {
        if (a.m !== 0) return !1;
        oo(b, c, bk(a));
        return !0;
      },
      function (a, b, c) {
        a.Na(c, Bl(b));
      },
      nm
    ),
    Do = no(
      function (a, b, c) {
        if (a.m !== 0 && a.m !== 2) return !1;
        var d = L(b, "state is only maintained on arrays.")[Z] | 0;
        zk(b, d, !0);
        b = nn(b, d, c);
        a.m == 2 ? fk(a, Lj, b) : b.push(bk(a));
        return !0;
      },
      function (a, b, c) {
        b = ko(Bl, b, !0);
        if (b != null && b.length) {
          c = cm(a, c);
          for (var d = 0; d < b.length; d++) Yl(a.F, b[d]);
          dm(a, c);
        }
      },
      nm
    ),
    Eo = mo(
      function (a, b, c) {
        if (a.m !== 0) return !1;
        oo(b, c, dk(a));
        return !0;
      },
      function (a, b, c) {
        a.ce(c, zl(b));
      },
      tm
    ),
    Fo = no(
      po,
      function (a, b, c) {
        b = ko(zl, b, !0);
        if (b != null) for (var d = 0; d < b.length; d++) a.ce(c, b[d]);
      },
      tm
    ),
    Go = no(
      po,
      function (a, b, c) {
        b = ko(zl, b, !0);
        if (b != null && b.length) {
          c = cm(a, c);
          for (var d = 0; d < b.length; d++) a.F.ce(b[d]);
          dm(a, c);
        }
      },
      tm
    );
  var Jo = function () {
    var a = Ho,
      b = Io;
    H(!0);
    this.Ga = 4156379;
    this.bg = a;
    this.Xb = b;
    this.Jd = 0;
    this.Yb = sn;
    this.defaultValue = void 0;
    this.xb = a.qk != null ? Sk : void 0;
    H(
      !0,
      "lazyParse must be undefined or LAZILY_PARSE_LATE_LOADED_EXTENSIONS_SYMBOL"
    );
  };
  Jo.prototype.register = function () {
    Sg(this);
  };
  function Ko(a) {
    if (a instanceof En) return a.constructor.W;
  }
  (function () {
    var a = Oa.jspbGetTypeName;
    Oa.jspbGetTypeName = a
      ? function (b) {
          return a(b) || Ko(b);
        }
      : Ko;
  })();
  var Lo = En;
  function Mo(a, b) {
    return function (c, d) {
      a: {
        var e = { tf: !0 };
        d && Object.assign(e, d);
        c = Vj(c, void 0, void 0, e);
        try {
          var f = new a(),
            g = Kk(f);
          bo(b)(g, c);
          var h = f;
          break a;
        } catch (k) {
          if (k instanceof RangeError) throw dj();
          throw Lb(k, Error);
        } finally {
          c.Be();
        }
        h = void 0;
      }
      return h;
    };
  }
  function No(a) {
    return function () {
      return lo(this, a);
    };
  }
  function Oo(a) {
    return function (b) {
      Ib(a);
      if (b == null || b == "") b = Lb(new a(), En);
      else {
        Hb(b);
        b = JSON.parse(b);
        if (!Array.isArray(b)) throw Error("Ha`" + Qa(b));
        yk(b, 32);
        b = new a(b);
      }
      return b;
    };
  }
  var tn = function (a) {
    Lo.call(this, a);
  };
  q(tn, Lo);
  tn.prototype.mg = function () {
    return yn(this, 2);
  };
  tn.W = "wireless.mdl.UserAgentClientHints.BrandAndVersion";
  var Po = [0, zo, -1];
  tn.prototype.O = No(Po);
  var Qo = function (a) {
    Lo.call(this, a);
  };
  q(Qo, Lo);
  var Ro = function (a, b) {
      return Bn(a, 2, b);
    },
    So = function (a, b) {
      return Bn(a, 3, b);
    },
    To = function (a, b) {
      return Bn(a, 4, b);
    },
    Uo = function (a, b) {
      return Bn(a, 5, b);
    },
    Vo = function (a, b) {
      return Bn(a, 9, b);
    },
    Wo = function (a, b) {
      var c = tn;
      Ym(a);
      H(Lk(a));
      var d = Ik ? a[K(Jk)] : a.B;
      var e = L(d, "state is only maintained on arrays.")[Z] | 0;
      zk(d, e);
      H(!(e & 2));
      if (b == null) cn(d, e, 10);
      else {
        var f = b;
        if (!Array.isArray(f))
          throw ((a = "Expected array but got " + Qa(f) + ": " + f), il(a));
        for (
          var g = (f =
              b === uk
                ? 7
                : L(b, "state is only maintained on arrays.")[Z] | 0),
            h = ln(f),
            k = h || Object.isFrozen(b),
            l = !0,
            m = !0,
            u = 0;
          u < b.length;
          u++
        ) {
          var t = b[u];
          Fl(t, K(c));
          h || ((t = Uk(t)), l && (l = !t), m && (m = t));
        }
        h || ((f = l ? 13 : 5), (f = m ? f & -4097 : f | 4096));
        (k && f === g) ||
          ((b = Array.prototype.slice.call(b)), (g = 0), (f = mn(f, e)));
        f !== g && wk(b, f);
        al(b);
        e = K(cn(d, e, 10, b));
        2 & f || Sm(f) || Zm(d, e);
      }
      return a;
    },
    Xo = function (a, b) {
      return zn(a, 11, b);
    },
    Yo = function (a, b) {
      return Bn(a, 1, b);
    },
    Zo = function (a, b) {
      return zn(a, 7, b);
    };
  Qo.W = "wireless.mdl.UserAgentClientHints";
  Qo.prototype.O = No([0, zo, -4, Ao, Po, yo, Eo, zo, Ao, Po, yo]);
  var $o =
    "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(
      " "
    );
  function ap(a) {
    var b;
    return (b = a.google_tag_data) != null ? b : (a.google_tag_data = {});
  }
  function bp(a) {
    var b, c;
    return (
      typeof ((b = a.navigator) == null
        ? void 0
        : (c = b.userAgentData) == null
        ? void 0
        : c.getHighEntropyValues) === "function"
    );
  }
  function cp(a) {
    if (!bp(a)) return null;
    var b = ap(a);
    if (b.uach_promise) return b.uach_promise;
    a = a.navigator.userAgentData.getHighEntropyValues($o).then(function (c) {
      b.uach != null || (b.uach = c);
      return c;
    });
    return (b.uach_promise = a);
  }
  function dp(a) {
    var b;
    return Xo(
      Wo(
        Uo(
          Ro(
            Yo(
              To(
                Zo(
                  Vo(So(new Qo(), a.architecture || ""), a.bitness || ""),
                  a.mobile || !1
                ),
                a.model || ""
              ),
              a.platform || ""
            ),
            a.platformVersion || ""
          ),
          a.uaFullVersion || ""
        ),
        ((b = a.fullVersionList) == null
          ? void 0
          : b.map(function (c) {
              var d = new tn();
              d = Bn(d, 1, c.brand);
              return Bn(d, 2, c.version);
            })) || []
      ),
      a.wow64 || !1
    );
  }
  function ep(a) {
    var b, c;
    return (c =
      (b = cp(a)) == null
        ? void 0
        : b.then(function (d) {
            return dp(d);
          })) != null
      ? c
      : null;
  }
  var fp = function (a, b, c, d) {
    a = a === void 0 ? window : a;
    b = b === void 0 ? null : b;
    c = c === void 0 ? new Xa() : c;
    d = d === void 0 ? Qf("current") : d;
    fe.call(this);
    var e = this;
    this.global = a;
    this.Qa = b;
    this.J = c;
    this.nf = d;
    this.Kg = Ld(function () {
      return Pd(e.global, "pagehide");
    }).i(Bg(this.J, 941));
    this.Jg = Ld(function () {
      return Pd(e.global, "load");
    }).i(Bg(this.J, 738), Ye(1));
    this.Ti = Ld(function () {
      return Pd(e.global, "resize");
    }).i(Bg(this.J, 741));
    this.onMessage = Ld(function () {
      return Pd(e.global, "message");
    }).i(Bg(this.J, 740));
    this.document = new yi(this.global, this);
    this.l = new Dg(new Gg(this.P, this.J), new Fg(this.P, this.J));
    this.H = new te(
      new Kg(this),
      new Oh(this),
      new xf(this, new Rg(this)),
      new xf(this, new Rh(this)),
      new xf(this, new Mh(this))
    );
  };
  q(fp, fe);
  da.Object.defineProperties(fp.prototype, {
    sharedStorage: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        try {
          return this.global.sharedStorage;
        } catch (a) {}
      },
    },
  });
  var gp = function (a) {
    try {
      return !!a.global.sharedStorage;
    } catch (b) {
      return b;
    }
  };
  da.Object.defineProperties(fp.prototype, {
    localStorage: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        try {
          return this.global.localStorage;
        } catch (a) {}
      },
    },
  });
  var hp = function (a, b) {
    try {
      return !!a.global.localStorage;
    } catch (c) {
      return (b === void 0 ? function () {} : b)(c), !1;
    }
  };
  fp.prototype.Lc = function () {
    var a;
    return !((a = this.global.navigator) == null || !a.locks);
  };
  fp.prototype.gf = function (a, b) {
    var c = this;
    return Ba(function (d) {
      return c.Lc()
        ? d.yield(c.global.navigator.locks.request(a, b), 0)
        : d.return();
    });
  };
  da.Object.defineProperties(fp.prototype, {
    P: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return window;
      },
    },
  });
  var Lg = function (a) {
    var b = a.global;
    return (
      !!a.global.HTMLFencedFrameElement &&
      !!b.fence &&
      typeof b.fence.reportEvent === "function"
    );
  };
  fp.prototype.tc = function (a) {
    Lg(this) && this.global.fence.reportEvent(a);
  };
  fp.prototype.Ee = function () {
    return this.Kg.i(
      Bg(this.J, 942),
      W(this.queue, 1),
      Q(function () {})
    );
  };
  var ip = function (a) {
      var b = new fp(a.global.top, a.Qa);
      b.H = a.H;
      return b;
    },
    jp = function (a, b) {
      b.start();
      return Pd(b, "message").i(Bg(a.J, 740));
    };
  fp.prototype.postMessage = function (a, b, c) {
    c = c === void 0 ? [] : c;
    this.global.postMessage(a, b, c);
  };
  fp.prototype.ng = function () {
    return Ug(this.global) ? this.global.width : 0;
  };
  fp.prototype.kg = function () {
    return Ug(this.global) ? this.global.height : 0;
  };
  var kp = function (a, b) {
    try {
      var c = Ki(b, a.global);
      return { left: c.left, top: c.top, width: c.ng(), height: c.kg() };
    } catch (d) {
      return Ei;
    }
  };
  da.Object.defineProperties(fp.prototype, {
    Bb: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return !Ug(this.global.top);
      },
    },
    Ke: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.Bb || this.global.top !== this.global;
      },
    },
    scrollY: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.global.scrollY;
      },
    },
    MutationObserver: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.P.MutationObserver;
      },
    },
    ResizeObserver: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.P.ResizeObserver;
      },
    },
  });
  fp.prototype.validate = function () {
    var a = this.H.R() || Lg(this);
    return this.global && this.l.na() && a;
  };
  var fi = function (a) {
    return (a = ep(a.global)) ? Vc(a) : null;
  };
  da.Object.defineProperties(fp.prototype, {
    Eh: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return "vu" in this.global || "vv" in this.global;
      },
    },
  });
  var lp = !dh && !Xg();
  function mp(a, b) {
    if (/-[a-z]/.test(b)) return null;
    if (lp && a.dataset) {
      if (Zg() && !(b in a.dataset)) return null;
      a = a.dataset[b];
      return a === void 0 ? null : a;
    }
    return a.getAttribute(
      "data-" +
        String(b)
          .replace(/([A-Z])/g, "-$1")
          .toLowerCase()
    );
  }
  var np = {},
    op =
      ((np["data-google-av-cxn"] = "_avicxn_"),
      (np["data-google-av-cpmav"] = "_cvu_"),
      (np["data-google-av-metadata"] = "_avm_"),
      (np["data-google-av-adk"] = "_adk_"),
      (np["data-google-av-btr"] = void 0),
      (np["data-google-av-override"] = void 0),
      (np["data-google-av-dm"] = void 0),
      (np["data-google-av-immediate"] = void 0),
      (np["data-google-av-aid"] = void 0),
      (np["data-google-av-naid"] = void 0),
      (np["data-google-av-inapp"] = void 0),
      (np["data-google-av-slift"] = void 0),
      (np["data-google-av-itpl"] = void 0),
      (np["data-google-av-ext-cxn"] = void 0),
      (np["data-google-av-rs"] = void 0),
      (np["data-google-av-flags"] = void 0),
      (np["data-google-av-turtlex"] = void 0),
      (np["data-google-av-ufs-integrator-metadata"] = void 0),
      (np["data-google-av-vattr"] = void 0),
      (np["data-google-av-vrus"] = void 0),
      np),
    pp = {},
    qp =
      ((pp["data-google-av-adk"] = "googleAvAdk"),
      (pp["data-google-av-btr"] = "googleAvBtr"),
      (pp["data-google-av-cpmav"] = "googleAvCpmav"),
      (pp["data-google-av-dm"] = "googleAvDm"),
      (pp["data-google-av-ext-cxn"] = "googleAvExtCxn"),
      (pp["data-google-av-immediate"] = "googleAvImmediate"),
      (pp["data-google-av-inapp"] = "googleAvInapp"),
      (pp["data-google-av-itpl"] = "googleAvItpl"),
      (pp["data-google-av-metadata"] = "googleAvMetadata"),
      (pp["data-google-av-naid"] = "googleAvNaid"),
      (pp["data-google-av-override"] = "googleAvOverride"),
      (pp["data-google-av-rs"] = "googleAvRs"),
      (pp["data-google-av-slift"] = "googleAvSlift"),
      (pp["data-google-av-cxn"] = "googleAvCxn"),
      (pp["data-google-av-aid"] = void 0),
      (pp["data-google-av-flags"] = "googleAvFlags"),
      (pp["data-google-av-turtlex"] = "googleAvTurtlex"),
      (pp["data-google-av-ufs-integrator-metadata"] =
        "googleAvUfsIntegratorMetadata"),
      (pp["data-google-av-vattr"] = "googleAvVattr"),
      (pp["data-google-av-vrus"] = "googleAvVurs"),
      pp);
  function rp(a, b) {
    if (a.j === void 0) return null;
    try {
      var c;
      var d = (c = a.j.getAttribute(b)) != null ? c : null;
      if (d !== null) return d;
    } catch (g) {}
    try {
      var e = op[b];
      if (e && ((d = a.j[e]), d !== void 0)) return d;
    } catch (g) {}
    try {
      var f = qp[b];
      if (f) return mp(a.j, f);
    } catch (g) {}
    return null;
  }
  function sp(a) {
    return Q(function (b) {
      return rp(b, a);
    });
  }
  var tp = N(
    (function (a) {
      return Q(function (b) {
        return a.map(function (c) {
          return rp(b, c);
        });
      });
    })(["data-google-av-cxn", "data-google-av-turtlex"]),
    Q(function (a) {
      var b = x(a);
      a = b.next().value;
      b = b.next().value;
      if (!a) {
        if (b !== null) return [];
        throw new pe();
      }
      return a.split("|");
    })
  );
  var up = function () {
    return N(
      Id(function (a) {
        return a.element
          .i(
            tp,
            Pe(function () {
              return fd([""]);
            })
          )
          .i(
            Q(function (b) {
              return { ua: b, vd: a };
            })
          );
      }),
      $e(function (a) {
        return a.ua.sort().join(";");
      }),
      Q(function (a) {
        return a.vd;
      })
    );
  };
  function vp() {
    return Id(function (a) {
      return Vc(wp(a)).i(Sh(a.queue));
    });
  }
  function wp(a) {
    return a.document
      .querySelectorAll(".GoogleActiveViewElement,.GoogleActiveViewClass")
      .map(function (b) {
        return new hi(b);
      });
  }
  function xp(a) {
    var b = a.Jg,
      c = a.document.Si;
    return Wd(fd({}), c, b).i(
      Q(function () {
        return a;
      })
    );
  }
  var zp = Q(yp);
  function yp(a) {
    var b = Number(rp(a, "data-google-av-rs"));
    if (!isNaN(b) && b !== 0) return b;
    var c;
    return (a = (c = a.j) == null ? void 0 : c.id)
      ? a.startsWith("DfaVisibilityIdentifier")
        ? 6
        : a.startsWith("YtKevlarVisibilityIdentifier")
        ? 15
        : a.startsWith("YtSparklesVisibilityIdentifier")
        ? 17
        : a.startsWith("YtKabukiVisibilityIdentifier")
        ? 18
        : 0
      : 0;
  }
  function Ap() {
    return N(
      R(function (a) {
        return a !== void 0;
      }),
      Q(function (a) {
        return a;
      })
    );
  }
  function Bp() {
    return function (a) {
      var b = [];
      return a.i(
        R(function (c) {
          if (
            c.j === void 0 ||
            b.some(function (d) {
              return d.j === c.j;
            })
          )
            return !1;
          b.push(c);
          return !0;
        })
      );
    };
  }
  function Cp(a, b) {
    b = b === void 0 ? Hc : b;
    return Wd(xp(a), b).i(vp(), Bp(), Ap(), W(a.queue, 1));
  }
  function Dp(a, b) {
    return new O(function (c) {
      var d = !1,
        e = Array(b.length);
      e.fill(void 0);
      var f = new Set(),
        g = new Set(),
        h = function (u, t) {
          a.Pg
            ? ((e[t] = u),
              f.add(t),
              d ||
                ((d = !0),
                ab(
                  a,
                  function () {
                    d = !1;
                    c.next(Qb(e));
                  },
                  1
                )))
            : c.error(new qe(t));
        },
        k = function (u, t) {
          g.add(t);
          f.add(t);
          ab(
            a,
            function () {
              c.error(u);
            },
            1
          );
        },
        l = function (u) {
          g.add(u);
          ab(
            a,
            function () {
              g.size === b.length && c.complete();
            },
            1
          );
        },
        m = b.map(function (u, t) {
          return u.subscribe(
            function (r) {
              return void h(r, t);
            },
            function (r) {
              return void k(r, t);
            },
            function () {
              return void l(t);
            }
          );
        });
      return function () {
        m.forEach(function (u) {
          return void u.unsubscribe();
        });
      };
    });
  }
  function Ep(a, b, c) {
    function d() {
      if (b.Qa) {
        var G = b.Qa,
          J = G.next;
        var Y = {
          creativeId: b.Ic.getName(c),
          requiredSignals: e,
          signals: Object.assign({}, f),
          hasPrematurelyCompleted: g,
          errorMessage: h,
          erroredSignalKey: k,
        };
        Y = {
          specMajor: 2,
          specMinor: 0,
          specPatch: 0,
          timestamp: ze(b.l.now(), new xe(0, b.l.timeline)),
          instanceId: b.Ic.getName(b.Ob),
          creativeState: Y,
        };
        J.call(G, Y);
      }
    }
    var e = Object.keys(a),
      f = {},
      g = !1,
      h = null,
      k = null,
      l = {},
      m = new Set(),
      u = [],
      t = [],
      r = x(e),
      w = r.next();
    try {
      for (var v = {}; !w.done; v = { qa: void 0 }, w = r.next()) {
        v.qa = w.value;
        var A = a[v.qa];
        if (A instanceof X)
          (l[v.qa] = A.value),
            m.add(v.qa),
            b.Qa && (f[String(v.qa)] = Be(A.value));
        else {
          var C = A.i(
            S(function (G, J) {
              return ue(G) || ue(J) ? !1 : G === J;
            }),
            Q(
              (function (G) {
                return function (J) {
                  b.Qa && ((f[String(G.qa)] = Be(J)), d());
                  var Y = {};
                  return (Y[G.qa] = J), Y;
                };
              })(v)
            ),
            Pe(
              (function (G) {
                return function (J) {
                  if (J instanceof qe) throw new se(String(G.qa));
                  throw J;
                };
              })(v)
            ),
            qf(
              (function (G) {
                return function () {
                  m.add(G.qa);
                };
              })(v),
              (function (G) {
                return function (J) {
                  k = String(G.qa);
                  h = String(J);
                  d();
                };
              })(v),
              (function (G) {
                return function () {
                  m.has(G.qa) || ((g = !0), d());
                };
              })(v)
            )
          );
          t.push(v.qa);
          u.push(C);
        }
      }
    } finally {
      ra(r, w);
    }
    (a = Object.keys(f).length > 0) && d();
    r = Dp(b.queue, u).i(
      Pe(function (G) {
        if (G instanceof qe) throw new re(String(t[G.li]));
        throw G;
      }),
      Q(function (G) {
        return Object.freeze(Object.assign.apply(Object, [{}, l].concat(y(G))));
      })
    );
    return (u = u.length > 0) && a
      ? Wd(fd(Object.freeze(l)), r)
      : u
      ? r
      : fd(Object.freeze(l));
  }
  function Fp(a, b, c, d, e) {
    return a.J.yc.bind(a.J)(733, function () {
      var f = {};
      try {
        return b
          .i(
            Pe(function (g) {
              d(z({}, f, { error: g }));
              return Hc;
            }),
            Id(function (g) {
              try {
                var h = c(a, g);
              } catch (l) {
                return (
                  d(z({}, f, { error: l instanceof Error ? l : String(l) })), Hc
                );
              }
              var k = {};
              return Ep(h, a, g.Ob)
                .i(
                  qf(function (l) {
                    k = l;
                  }),
                  kf(1),
                  pd()
                )
                .i(
                  e,
                  Pe(function (l) {
                    d(z({}, k, { error: l }));
                    return Hc;
                  }),
                  df(void 0),
                  Q(function () {
                    return !0;
                  })
                );
            })
          )
          .i(
            mf(function (g) {
              return g + 1;
            }, 0),
            Pe(function (g) {
              d(z({}, f, { error: g }));
              return Hc;
            })
          );
      } catch (g) {
        return d(z({}, f, { error: g })), Hc;
      }
    })();
  }
  function Gp(a, b) {
    return N(
      U(function (c) {
        var d = a(c),
          e = b(c),
          f = {};
        return d && e && f
          ? new O(function (g) {
              e(d, f, function (h) {
                g.next(z({}, c, { nb: h }));
                g.complete();
              });
              return function () {};
            })
          : Xd;
      }),
      R(function (c) {
        return c.nb;
      })
    );
  }
  var Hp = N(
    R(function (a) {
      var b = a.H;
      var c = a.Ec;
      var d = a.zc;
      var e = a.tc;
      var f = a.Cb;
      var g = a.ab;
      a = a.Dc;
      return (
        g !== void 0 &&
        a !== void 0 &&
        b !== void 0 &&
        c !== void 0 &&
        d !== void 0 &&
        (!f || e !== void 0)
      );
    }),
    pf(function (a) {
      return !(a.wg === !1 && a.ye !== void 0);
    }, !1),
    R(function (a) {
      var b = a.wg;
      var c = a.Kc;
      var d = a.Aj;
      a = a.Ec;
      return d
        ? !!c && a !== void 0 && (a == null ? void 0 : a.length) > 0
        : !!b;
    }),
    Gp(
      function (a) {
        return a.Dc;
      },
      function (a) {
        return a.ab;
      }
    ),
    Q(function (a) {
      a.Cb ||
        a.zc(a.Ec, a).forEach(function (b) {
          a.H.M(b).sendNow();
        });
    }),
    Ye(1),
    We()
  );
  var Ip = function (a) {
      var b = b === void 0 ? {} : b;
      this.Ca = a;
      this.config = {
        maxAdKeys: b.maxAdKeys || 50,
        maxHourlyEvents: b.maxHourlyEvents || 2,
        maxDailyEvents: b.maxDailyEvents || 2,
        maxWeeklyEvents: b.maxWeeklyEvents || 2,
      };
      this.xa = new Map();
    },
    Jp = function (a) {
      try {
        var b = JSON.stringify(Array.from(a.xa.entries()));
        a.Ca.setItem("adStatsCache", b);
      } catch (c) {
        a.Ca.reportError(c);
      }
    },
    Lp = function (a, b, c) {
      return Ba(function (d) {
        return d.yield(
          a.Ca.performExclusiveLockedOperation("avOmakaseLock", function () {
            a: {
              var e = a.Ca.getItem("adStatsCache");
              if (e)
                try {
                  var f = new Map(JSON.parse(e));
                  break a;
                } catch (h) {
                  a.Ca.reportError(h);
                }
              f = new Map();
            }
            a.xa = f;
            f = a.xa.get(b) || { h: {}, d: {}, w: {} };
            e = f.h;
            var g = new Date();
            g.setMinutes(0, 0, 0);
            Kp(
              e,
              Math.floor(g.getTime() / 1e3).toString(),
              c,
              a.config.maxHourlyEvents
            );
            e = f.d;
            g = new Date();
            g.setHours(0, 0, 0, 0);
            Kp(
              e,
              Math.floor(g.getTime() / 1e3).toString(),
              c,
              a.config.maxDailyEvents
            );
            e = f.w;
            g = new Date();
            g = new Date(g.setDate(g.getDate() - g.getDay()));
            g.setHours(0, 0, 0, 0);
            Kp(
              e,
              Math.floor(g.getTime() / 1e3).toString(),
              c,
              a.config.maxWeeklyEvents
            );
            a.xa.has(b)
              ? a.xa.delete(b)
              : a.xa.size >= a.config.maxAdKeys &&
                a.xa.size >= a.config.maxAdKeys &&
                ((e = a.xa.keys().next().value), a.xa.delete(e));
            f.ts = Date.now();
            a.xa.set(b, f);
            Jp(a);
          }),
          0
        );
      });
    },
    Mp = function (a, b) {
      var c = c === void 0 ? 1 : c;
      return Ba(function (d) {
        return d.yield(Lp(a, b, { c: c, v: 0, cTos: 0 }), 0);
      });
    },
    Np = function (a, b) {
      var c = c === void 0 ? 1 : c;
      return Ba(function (d) {
        return d.yield(Lp(a, b, { c: 0, v: c, cTos: 0 }), 0);
      });
    },
    Op = function (a, b, c) {
      return Ba(function (d) {
        return d.yield(Lp(a, b, { c: 0, v: 0, cTos: c }), 0);
      });
    },
    Kp = function (a, b, c, d) {
      a[b]
        ? ((a[b].c += c.c), (a[b].cTos += c.cTos), (a[b].v += c.v))
        : (a[b] = { c: c.c, cTos: c.cTos, v: c.v });
      b = Object.keys(a);
      b.length > d && delete a[b[0]];
    },
    Pp = function (a, b) {
      if (!a.Ca.hasLocalStorageAccess()) return 4;
      if (Number.isNaN(b) || b <= 0) return 2;
      var c = a.Ca.getItem("adStatsReset");
      if (c == null) return a.Ca.setItem("adStatsReset", b.toString()), 3;
      c = Number(c);
      return Number.isNaN(c) || b > c
        ? (a.Ca.setItem("adStatsReset", b.toString()), a.xa.clear(), Jp(a), 1)
        : 2;
    },
    Qp = function (a, b) {
      var c;
      return Ba(function (d) {
        if (d.u == 1) {
          if (!a.Ca.hasLocalStorageAccess()) return d.return(4);
          c = 0;
          return d.yield(
            a.Ca.performExclusiveLockedOperation("avOmakaseLock", function () {
              c = Pp(a, b);
            }),
            2
          );
        }
        return d.return(c);
      });
    };
  function Rp(a) {
    a = a
      .fa()
      .value.slice(0, 3)
      .reduce(function (b, c) {
        return b + c;
      }, 0);
    return Math.min(a, 61500);
  }
  function Sp(a) {
    var b;
    return function (c) {
      var d = c.i(
        pf(function (g) {
          return g.ye === void 0;
        }),
        of(function (g) {
          return g.lf === void 0;
        }),
        qf(function (g) {
          g.lf && b === void 0 && (b = new Ip(a));
        }),
        pf(function (g) {
          return !!g.lf;
        }),
        kf(1),
        pd()
      );
      c = d.i(
        Q(function (g) {
          return g.ej;
        }),
        R(function (g) {
          return g !== void 0;
        }),
        Ye(1),
        Id(function (g) {
          var h, k;
          return Ba(function (l) {
            if (l.u == 1)
              return l.yield((h = b) == null ? void 0 : Qp(h, g), 2);
            k = l.V;
            var m = { rk: g.toString(), outcome: k.toString() };
            m = m === void 0 ? {} : m;
            var u = a.C;
            m = m === void 0 ? {} : m;
            m = z({}, { reason: "cache_reset_check" }, m);
            var t = new Tp(
              "https://pagead2.googlesyndication.com/pagead/gen_204"
            );
            Up(t, "id", "av-js");
            Up(t, "type", "omakase");
            Up(t, "jp", JSON.stringify(m));
            Up(t, "v", Vp);
            u.H.M(t.toString()).sendNow();
            l.Db();
          });
        })
      );
      var e = d.i(
          R(function (g) {
            return !!g.Kc;
          }),
          Ye(1),
          Id(function (g) {
            var h = g.wa;
            var k;
            return Ba(function (l) {
              return h
                ? l.yield((k = b) == null ? void 0 : Mp(k, h), 0)
                : l.ba(0);
            });
          })
        ),
        f = d.i(
          R(function (g) {
            g = g.be;
            return !!g && g.fa().value;
          }),
          Ye(1),
          Id(function (g) {
            var h = g.wa;
            var k;
            return Ba(function (l) {
              return h
                ? l.yield((k = b) == null ? void 0 : Np(k, h), 0)
                : l.ba(0);
            });
          })
        );
      d = d.i(
        Q(function (g) {
          return g.Ji;
        }),
        S(),
        rf(
          d.i(
            Q(function (g) {
              return { Wa: g.Wa, wa: g.wa };
            })
          )
        ),
        R(function (g) {
          g = x(g);
          g.next();
          return !!g.next().value.Wa;
        }),
        Q(function (g) {
          g = x(g);
          g.next();
          var h = g.next().value;
          g = h.Wa;
          h = h.wa;
          return { xc: Rp(g), wa: h };
        }),
        pf(function (g) {
          return g.xc < 61500;
        }, !0),
        S(function (g, h) {
          return g.xc === h.xc;
        }),
        T({ xc: 0, wa: null }),
        jf(),
        Id(function (g) {
          g = x(g);
          var h = g.next().value.xc;
          g = g.next().value;
          var k = g.xc;
          var l = g.wa;
          var m;
          return Ba(function (u) {
            return l && k
              ? u.yield((m = b) == null ? void 0 : Op(m, l, k - h), 0)
              : u.ba(0);
          });
        })
      );
      return Wd(c, e, f, d).i(We());
    };
  }
  function Wp(a) {
    var b = new Map();
    if (typeof a !== "object" || a === null) return b;
    Object.values(a).forEach(function (c) {
      c &&
        typeof c.fa === "function" &&
        (b.has(c.clock.timeline) || b.set(c.clock.timeline, c.clock.now()));
    });
    return b;
  }
  function Xp(a, b, c) {
    var d = Yp,
      e = Zp;
    c = c === void 0 ? 0.01 : c;
    return function (f) {
      c > 0 &&
        Math.random() <= c &&
        (a.global.HTMLFencedFrameElement &&
          a.global.fence &&
          typeof a.global.fence.reportEvent === "function" &&
          a.global.fence.reportEvent({
            eventType: "active-view-error",
            eventData: "",
            destination: ["buyer"],
          }),
        (f = z({}, f, {
          errorMessage:
            f.error instanceof Error && f.error.message
              ? f.error.message
              : String(f.error),
          Yf:
            f.error instanceof Error && f.error.stack
              ? String(f.error.stack)
              : null,
          Rh:
            f.error instanceof Error && f.error.name
              ? String(f.error.name)
              : null,
          Ph: String(a.J.rf),
          Qh: f.escapedQueryId,
        })),
        d(
          z({}, f, {
            ca: (function () {
              return function (g) {
                try {
                  return e(z({}, g));
                } catch (h) {
                  return {};
                }
              };
            })(),
            ua: [b],
          }),
          Wp(f)
        ).forEach(function (g) {
          a.H.M(g).sendNow();
        }));
    };
  }
  var $p = N(
    Q(function (a) {
      var b = a.H;
      var c = a.Xh;
      if (b === void 0 || c === void 0) return !1;
      if (a.ye !== void 0) return !0;
      if (c === null) return !1;
      for (a = 0; a < c; a++)
        b.M(
          "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=extra&rnd=" +
            Math.floor(Math.random() * 1e7)
        ).sendNow();
      return !0;
    }),
    pf(function (a) {
      return !a;
    }),
    We()
  );
  var aq = N(
    R(function (a) {
      return !!a.Kc;
    }),
    R(function (a) {
      var b = a.shouldSendExplicitDisplayMeasurablePing;
      a = a.zb;
      var c, d;
      return (d =
        b && ((c = a == null ? void 0 : a.length) != null ? c : 0) > 0) != null
        ? d
        : !1;
    }),
    R(function (a) {
      return (
        a.ca !== void 0 &&
        a.zb !== void 0 &&
        a.Rb !== void 0 &&
        a.dc !== void 0 &&
        a.H !== void 0
      );
    }),
    Q(function (a) {
      return z({}, a, { Vd: Wp(a) });
    }),
    Q(function (a) {
      a.Rb(
        z({}, a, { ua: a.zb, ca: a.ca, ad: a.dc, ld: 3, cd: "m" }),
        a.Vd
      ).forEach(function (b) {
        a.H.M(b).sendNow();
      });
      return !0;
    }),
    pf(function (a) {
      return !a;
    }),
    We()
  );
  var Zp = function (a) {
    return {
      id: a.ad,
      mcvt: a.Uc,
      p: a.wd,
      asp: a.gk,
      tm: a.Wd,
      tu: a.Xd,
      mtos: a.Vc,
      tos: a.Wa,
      v: a.Dh,
      bin: a.ke,
      avms: a.Hg,
      bs: a.Of,
      mc: a.Fg,
      if: a.Kh,
      vu: a.Mh,
      app: a.Ab,
      mse: a.We,
      mtop: a.Xe,
      itpl: a.Me,
      adk: a.wa,
      exk: a.ik,
      rs: a.fb,
      la: a.Ag,
      cr: a.Qe,
      uach: a.jd,
      vs: a.ld,
      r: a.cd,
      pay: a.fi,
      co: a.Fh,
      rst: a.xh,
      rpt: a.wh,
      isd: a.ji,
      lsd: a.Ci,
      context: a.Ph,
      msg: a.errorMessage,
      stack: a.Yf,
      name: a.Rh,
      ec: a.gi,
      sfr: a.pf,
      met: a.Gc,
      wmsd: a.yf,
      pv: a.Jk,
      epv: a.lk,
      pbe: a.ug,
      fle: a.hi,
      vae: a.ii,
      spb: a.bh,
      sfl: a.ah,
      ffslot: a.ti,
      reach: a.nj,
      io2: a.Zd,
      rxdbg: a.Sk,
      omida: a.xk,
      omidp: a.Ek,
      omidpv: a.Fk,
      omidor: a.Dk,
      omidv: a.Hk,
      omids: a.Gk,
      omidam: a.wk,
      omidct: a.yk,
      omidia: a.Bk,
      omiddc: a.zk,
      omidlat: a.Ck,
      omiddit: a.Ak,
      qid: a.Qh,
    };
  };
  function bq() {
    var a = F.apply(0, arguments);
    return function (b) {
      var c = b.i(kf(1), pd());
      b = a.map(function (d) {
        return c.i(d, df(!0));
      });
      return Dd(b).i(Ye(1), We());
    };
  }
  function cq() {
    var a = F.apply(0, arguments);
    return function (b) {
      var c = b.i(kf(1), pd());
      b = a.map(function (d) {
        return c.i(d, df(!0));
      });
      return Wd.apply(null, y(b)).i(Ye(1), We());
    };
  }
  function dq() {
    var a = bq(aq, eq),
      b = fq;
    return function (c) {
      var d = c.i(kf(1), pd());
      c = d.i(a, df(!0));
      d = d.i(N(b, kf(), pd()), df(!0));
      c = Dd([c, d]);
      return ae(c, d).i(Ye(1), We());
    };
  }
  var fq = function (a) {
    var b = [];
    return a.i(
      Q(function (c) {
        var d = c.H,
          e = c.Yh,
          f = c.Wa,
          g = c.tj,
          h = c.ca,
          k = c.sj,
          l = c.dh,
          m = c.Rb,
          u = c.be,
          t = c.Kc,
          r = c.ug,
          w = c.bh,
          v = c.ah,
          A = c.vf;
        if (
          !c.gg ||
          !t ||
          c.Vc === void 0 ||
          f === void 0 ||
          g === void 0 ||
          h === void 0 ||
          k === void 0 ||
          m === void 0 ||
          d === void 0
        )
          return !1;
        if (c.Cb) {
          if (l === void 0) return !1;
          g = c.tc;
          if (!g) return !1;
          g({
            eventType: "active-view-time-on-screen",
            eventData: A != null ? A : "",
            destination: ["buyer"],
          });
          return !0;
        }
        if (!(r || v || l)) return !1;
        A = Wp(c);
        var C;
        u = (C = u == null ? void 0 : u.Aa(A).value) != null ? C : !1;
        C = m(
          z({}, c, {
            ad: k,
            ld: u ? 4 : 3,
            cd: l != null ? l : "u",
            ca: h,
            ua: g,
          }),
          A
        );
        if (r) {
          for (; b.length > g.length; )
            (c = void 0), (c = b.shift()) == null || c.deactivate();
          C.forEach(function (J, Y) {
            Y >= b.length ? b.push(d.M(J)) : (b[Y].url = J);
          });
          return w && e && l !== void 0
            ? (C.forEach(function (J) {
                e.M(J).sendNow();
              }),
              !0)
            : l !== void 0;
        }
        if (w && e && l !== void 0)
          return (
            C.forEach(function (J) {
              e.M(J).sendNow();
            }),
            !0
          );
        if (v && e) {
          for (; b.length > g.length; )
            (w = void 0), (w = b.shift()) == null || w.deactivate();
          var G = m(
            z({}, c, {
              ad: k,
              ld: u ? 4 : 3,
              cd: l != null ? l : "u",
              ca: h,
              ua: [
                "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fetch&later&lidartos",
              ],
            }),
            A
          )[0];
          C.forEach(function (J, Y) {
            Y >= b.length ? b.push(d.M(G, { Oh: !0 })) : (b[Y].url = G);
          });
          return l !== void 0
            ? (C.forEach(function (J) {
                e.M(J).sendNow();
              }),
              !0)
            : l !== void 0;
        }
        return l !== void 0
          ? (C.forEach(function (J) {
              d.M(J).sendNow();
            }),
            !0)
          : !1;
      }),
      pf(function (c) {
        return !c;
      }),
      We()
    );
  };
  function gq(a) {
    return function (b) {
      return b.i(
        Q(function (c) {
          a.Pg || qh("Assertion on queued Observable output failed");
          return c;
        })
      );
    };
  }
  function hq(a) {
    return function (b) {
      return new O(function (c) {
        var d = !1,
          e = b.i(gq(a)).subscribe(
            function (f) {
              d = !0;
              c.next(f);
            },
            c.error.bind(c),
            c.complete.bind(c)
          );
        ab(
          a,
          function () {
            d || c.next(null);
          },
          3
        );
        return e;
      });
    };
  }
  function iq(a, b) {
    return function (c) {
      return c.i(
        U(function (d) {
          return new O(function (e) {
            function f() {
              h.disconnect();
              k.unsubscribe();
            }
            var g = a.MutationObserver;
            if (g && d.j !== void 0) {
              var h = new g(function (l) {
                e.next(l);
              });
              h.observe(d.j, b);
              var k = d.released.subscribe(f);
              return f;
            }
          });
        })
      );
    };
  }
  var jq = {
    ek: 0,
    Ij: 1,
    Kj: 2,
    Jj: 3,
    0: "UNKNOWN",
    1: "DEFER_MEASUREMENT",
    2: "DO_NOT_DEFER_MEASUREMENT",
    3: "DEFER_MEASUREMENT_AND_PING",
  };
  function kq(a, b) {
    var c = b.i(iq(a, { attributes: !0 }), W(a.queue, 1));
    return Dd([b, c.i(W(a.queue, 1), hq(a.queue))]).i(
      Q(function (d) {
        return x(d).next().value;
      }),
      sp("data-google-av-dm"),
      Q(lq)
    );
  }
  function lq(a) {
    return a && a in jq ? Number(a) : 2;
  }
  function mq(a) {
    if (a.Gi === 3) return null;
    if (a.dh !== void 0) {
      var b = a.Jh === !1 ? "n" : null;
      if (b !== null) return b;
    }
    return a.Bd instanceof je
      ? "msf"
      : a.re instanceof ke
      ? "c"
      : a.Hh === !1
      ? "pv"
      : a.Bd || a.re
      ? "x"
      : null;
  }
  var nq = N(
    R(function (a) {
      return (
        a.zb !== void 0 &&
        a.ca !== void 0 &&
        a.Rb !== void 0 &&
        a.dc !== void 0 &&
        a.H !== void 0
      );
    }),
    R(function (a) {
      return mq(a) !== null;
    }),
    Gp(
      function (a) {
        return a.pd;
      },
      function (a) {
        return a.ab;
      }
    ),
    Q(function (a) {
      if (a.Cb) {
        var b = a.tc;
        if (b) {
          var c;
          b({
            eventType: "active-view-unmeasurable",
            eventData: (c = a.vf) != null ? c : "",
            destination: ["buyer"],
          });
        }
      } else {
        c = void 0;
        var d = mq(a);
        if (d === "x") {
          var e,
            f = (e = a.Bd) != null ? e : a.re;
          f && ((b = f.stack), (c = f.message));
        }
        a.Rb(
          z({}, a, {
            ua: a.zb,
            ca: a.ca,
            ad: a.dc,
            ld: 2,
            cd: d,
            errorMessage: c,
            Yf: b,
          }),
          Wp(a)
        ).forEach(function (g) {
          a.H.M(g).sendNow();
        });
      }
    }),
    Ye(1),
    We()
  );
  var oq = function () {
      this.startTime = Math.floor(Date.now() / 1e3 - 1704067200);
      this.sequenceNumber = 0;
    },
    pq = function (a) {
      var b = a.sequenceNumber.toString(10).padStart(2, "0");
      b = "" + a.startTime + b;
      a.sequenceNumber < 99 && a.sequenceNumber++;
      return b;
    };
  function qq(a, b) {
    return typeof a === "string"
      ? encodeURIComponent(a)
      : typeof a === "number"
      ? String(a)
      : Array.isArray(a)
      ? a
          .map(function (c) {
            return qq(c, b);
          })
          .join(",")
      : a instanceof xe
      ? a.toString()
      : a && typeof a.fa === "function"
      ? qq(a.Aa(b).value, b)
      : a === !0
      ? "1"
      : a === !1
      ? "0"
      : a === void 0 || a === null
      ? null
      : a instanceof oq
      ? pq(a)
      : [a.top, a.left, a.top + a.height, a.left + a.width].join();
  }
  function rq(a, b) {
    a = Object.entries(a)
      .map(function (c) {
        var d = x(c);
        c = d.next().value;
        d = d.next().value;
        d = qq(d, b);
        return d === null ? "" : c + "=" + d;
      })
      .filter(function (c) {
        return c !== "";
      });
    return a.length ? a.join("&") : "";
  }
  var sq = /(?:\[|%5B)([a-zA-Z0-9_]+)(?:\]|%5D)/g,
    kc = ic(
      jc(),
      "google3.javascript.ads.common.url_macros_substitutor",
      Yb
    ).Di;
  function tq(a, b) {
    return a.replace(sq, function (c, d) {
      try {
        var e = b !== null && d in b ? b[d] : void 0;
        if (e == null)
          return lc("No value supplied for unsupported macro: " + d), c;
        if (e.toString() == null)
          return (
            lc("The toString method of value returns null for macro: " + d), c
          );
        e = e.toString();
        if (e == "" || !/^[\s\xa0]*$/.test(e == null ? "" : String(e)))
          return encodeURIComponent(e).replace(/%2C/g, ",");
        lc("Null value supplied for macro: " + d);
      } catch (f) {
        lc("Failed to set macro: " + d);
      }
      return c;
    });
  }
  function uq(a, b) {
    var c = a.jd,
      d = z({}, a);
    d = (delete d.jd, d);
    d = a.ca(d);
    var e = rq(d, b);
    return Nb(a.ua, function (f) {
      var g = "";
      typeof c === "string" && (g = "&" + rq({ uach: c }, b));
      var h = {};
      return tq(f, ((h.VIEWABILITY = e), h)) + g;
    });
  }
  function Yp(a, b) {
    var c = a.ca(a),
      d = rq(c, b);
    return d
      ? Nb(a.ua, function (e) {
          e = e.indexOf("?") >= 0 ? e : e + "?";
          e = "?&".indexOf(e.slice(-1)) >= 0 ? e : e + "&";
          return e + d;
        })
      : a.ua;
  }
  function vq(a, b) {
    return Nb(a, function (c) {
      if (typeof b.jd === "string") {
        var d = "&" + rq({ uach: b.jd }, new Map());
        return c.substring(c.length - 7) == "&adurl="
          ? c.substring(0, c.length - 7) + d + "&adurl="
          : c + d;
      }
      return c;
    });
  }
  var eq = N(
    R(function (a) {
      return (
        a.ca !== void 0 &&
        a.zb !== void 0 &&
        a.Rb !== void 0 &&
        a.dc !== void 0 &&
        a.H !== void 0
      );
    }),
    Q(function (a) {
      return z({}, a, { Vd: Wp(a) });
    }),
    R(function (a) {
      var b = a.be;
      var c = a.Kc;
      a = a.Vd;
      var d;
      return !!c && ((d = b == null ? void 0 : b.Aa(a).value) != null ? d : !1);
    }),
    Gp(
      function (a) {
        return a.qd;
      },
      function (a) {
        return a.ab;
      }
    ),
    Q(function (a) {
      var b = a.H,
        c = a.vf;
      if (a.Cb) {
        var d = a.tc;
        if (!d) return !1;
        d({
          eventType: "active-view-viewable",
          eventData: c != null ? c : "",
          destination: ["buyer"],
        });
        return !0;
      }
      c = a.Rb(
        z({}, a, { ua: a.zb, ca: a.ca, ad: a.dc, ld: 4, cd: "v" }),
        a.Vd
      );
      (d = a.te) &&
        d.length > 0 &&
        a.zc &&
        a.zc(d, a).forEach(function (e) {
          b.M(e).sendNow();
        });
      (d = a.xf) &&
        d.length > 0 &&
        a.zc &&
        a.zc(d, a).forEach(function (e) {
          b.M(e).sendNow();
        });
      c.forEach(function (e) {
        b.M(e, { Bc: a.Te }).sendNow();
      });
      return !0;
    }),
    pf(function (a) {
      return !a;
    }),
    We()
  );
  function wq(a, b, c, d) {
    var e = Object.keys(c).map(function (h) {
        return h;
      }),
      f = e.filter(function (h) {
        var k = c[h];
        h = d[h];
        return k instanceof X && h instanceof X && k.value === h.value;
      }),
      g = f.reduce(function (h, k) {
        var l = {};
        return z({}, h, ((l[k] = c[k]), l));
      }, {});
    return e.reduce(function (h, k) {
      if (f.indexOf(k) >= 0) return h;
      var l = {};
      return z(
        {},
        h,
        ((l[k] = b.i(
          U(function (m) {
            return (m = m ? c[k] : d[k]) &&
              (m instanceof O || (M(m.Fb) && M(m.subscribe)))
              ? m
              : m.S(a);
          })
        )),
        l)
      );
    }, g);
  }
  function xq(a) {
    return N(
      Q(function () {
        return !0;
      }),
      T(!1),
      W(a, 1)
    );
  }
  function yq(a) {
    return a.length <= 0
      ? Hc
      : Dd(
          a.map(function (b) {
            var c = 0;
            return b.i(
              Q(function (d) {
                return { index: c++, value: d };
              })
            );
          })
        ).i(
          R(function (b) {
            return b.every(function (c) {
              return c.index === b[0].index;
            });
          }),
          Q(function (b) {
            return b.map(function (c) {
              return c.value;
            });
          })
        );
  }
  function zq(a, b) {
    a.Pa && (a.Ib = a.Pa);
    a.Pa = b;
    a.Ib && a.Ib.value
      ? ((b = Math.max(0, ze(b.timestamp, a.Ib.timestamp))),
        (a.totalTime += b),
        (a.ya += b))
      : (a.ya = 0);
    return a;
  }
  function Aq() {
    return N(
      mf(zq, { totalTime: 0, ya: 0 }),
      Q(function (a) {
        return a.totalTime;
      })
    );
  }
  function Bq() {
    return N(
      mf(zq, { totalTime: 0, ya: 0 }),
      Q(function (a) {
        return a.ya;
      })
    );
  }
  function Cq(a, b) {
    return N(
      sp("data-google-av-metadata"),
      Q(function (c) {
        if (c === null) return b(void 0);
        c = c
          .split("&")
          .map(function (d) {
            return d.split("=");
          })
          .filter(function (d) {
            return d[0] === a;
          });
        if (c.length === 0) return b(void 0);
        c = c[0].slice(1).join("=");
        return b(c);
      })
    );
  }
  var Dq = { Ej: "asmreq", Fj: "asmres" };
  var Eq = function (a) {
    Lo.call(this, a);
  };
  q(Eq, Lo);
  Eq.prototype.Sg = function (a) {
    An(this, 1, a);
  };
  Eq.W = "tagging.common.osd.AdSpeedMetricsRequest";
  Eq.prototype.O = No([0, Co]);
  var Fq = function (a) {
    Lo.call(this, a);
  };
  q(Fq, Lo);
  Fq.W = "tagging.common.osd.AdSpeedMetricsResponse.Box";
  var Gq = [0, vo, -3];
  Fq.prototype.O = No(Gq);
  var Hq = function (a) {
    Lo.call(this, a);
  };
  q(Hq, Lo);
  Hq.prototype.Sg = function (a) {
    An(this, 1, a);
  };
  var Iq = Oo(Hq);
  Hq.W = "tagging.common.osd.AdSpeedMetricsResponse";
  Hq.prototype.O = No([0, Co, yo, Gq, vo, -1]);
  function Jq(a, b) {
    var c = c === void 0 ? ip(a) : c;
    var d = new MessageChannel();
    b = b.i(
      Q(function (f) {
        return Number(f);
      }),
      R(function (f) {
        return !isNaN(f) && f !== 0;
      }),
      qf(function (f) {
        var g = new Eq();
        g.Sg(f);
        f = { type: "asmreq", payload: g.hb() };
        c.postMessage(f, "*", [d.port2]);
      }),
      Ye(1)
    );
    var e = jp(a, d.port1).i(
      R(function (f) {
        return typeof f.data === "object";
      }),
      Q(function (f) {
        var g = f.data;
        if (
          !Object.values(Dq).includes(g.type) ||
          !vh(g.payload) ||
          f.data.type !== "asmres"
        )
          return null;
        try {
          return Iq(f.data.payload);
        } catch (h) {
          return null;
        }
      }),
      R(function (f) {
        return f !== null;
      }),
      Q(function (f) {
        return f;
      })
    );
    return b.i(
      U(function (f) {
        return fd(f).i(Ue(e));
      }),
      R(function (f) {
        var g = x(f);
        f = g.next().value;
        g = g.next().value;
        if (Bl(an(g, 1)) != null) {
          var h = h === void 0 ? 0 : h;
          var k;
          g = ((k = Bl(an(g, 1))) != null ? k : h) === f;
        } else g = !1;
        return g;
      }),
      Q(function (f) {
        f = x(f);
        f.next();
        return f.next().value;
      }),
      Sh(a.queue)
    );
  }
  function Kq(a, b, c) {
    var d = b.Rc.i(
      Ye(1),
      U(function () {
        return Jq(a, c);
      }),
      R(function (f) {
        return (
          wn(f, 2) && en(f, 3) && zl(an(f, 4)) != null && zl(an(f, 5)) != null
        );
      }),
      Ye(1),
      Sh(a.queue)
    );
    b = d.i(
      Q(function (f) {
        var g = sn(f, Fq, 3);
        g = xn(g, 2);
        f = sn(f, Fq, 3);
        f = xn(f, 1);
        return { x: g, y: f };
      }),
      S(function (f, g) {
        return f.x === g.x && f.y === g.y;
      }),
      W(a.queue, 1)
    );
    var e = d.i(
      Q(function (f) {
        return xn(f, 4);
      }),
      W(a.queue, 1)
    );
    d = d.i(
      Q(function (f) {
        return xn(f, 5);
      }),
      W(a.queue, 1)
    );
    return { ji: e, zh: b, Ci: d };
  }
  function Lq(a, b) {
    return b.Rc.i(
      Ye(1),
      Q(function () {
        return a.l.now().round();
      })
    );
  }
  var Mq = Q(function (a) {
    return [a.value.da.width, a.value.da.height];
  });
  function Nq(a, b) {
    return function (c) {
      return yq(
        b.map(function (d) {
          return c.i(a(d));
        })
      );
    };
  }
  function Oq() {
    var a;
    return N(
      qf(function (b) {
        return void (a = b.timestamp);
      }),
      Bq(),
      Q(function (b) {
        return { timestamp: a, value: Math.round(b) };
      })
    );
  }
  var Pq = function (a, b) {
      this.Qf = a;
      this.options = b;
      this.Oe = this.Ne = null;
    },
    Qq = function (a, b) {
      b
        ? a.Oe ||
          ((b = z({}, a.options, { delay: 100, trackVisibility: !0 })),
          (a.Oe = new IntersectionObserver(a.Qf, b)))
        : a.Ne || (a.Ne = new IntersectionObserver(a.Qf, a.options));
    },
    Rq = function (a, b) {
      a = b ? a.Oe : a.Ne;
      if (!a) throw new me();
      return a;
    };
  Pq.prototype.observe = function (a, b) {
    Rq(this, a).observe(b);
  };
  Pq.prototype.unobserve = function (a, b) {
    Rq(this, a).unobserve(b);
  };
  Pq.prototype.disconnect = function (a) {
    Rq(this, a).disconnect();
  };
  Pq.prototype.takeRecords = function (a) {
    return Rq(this, a).takeRecords();
  };
  var Sq = {
    ma: "ns",
    oa: Ei,
    da: Ei,
    ja: new Ec(),
    Z: "ns",
    N: Ei,
    aa: Ei,
    va: { x: 0, y: 0 },
  };
  function Tq(a, b) {
    return (
      Fi(a.da, b.da) &&
      Fi(a.N, b.N) &&
      Fi(a.oa, b.oa) &&
      Fi(a.aa, b.aa) &&
      a.Z === b.Z &&
      a.ja === b.ja &&
      a.ma === b.ma &&
      a.va.x === b.va.x &&
      a.va.y === b.va.y
    );
  }
  function Uq(a, b) {
    return function (c) {
      return function (d) {
        var e = d.i(hf(new Ec()), pd());
        d = c.element.i(S());
        e = e.i(
          Q(function (f) {
            return f.value;
          })
        );
        return Dd([d, e, b]).i(
          Q(function (f) {
            var g = x(f);
            f = g.next().value;
            var h = g.next().value;
            g = g.next().value;
            if (f.j === void 0)
              var k = { top: 0, left: 0, width: 0, height: 0 };
            else {
              k = f.j.getBoundingClientRect();
              var l = f.j,
                m = a.global,
                u = new Bh(0, 0);
              var t = (t = Eh(l)) ? t.defaultView : window;
              if (Tg(t, "parent")) {
                do {
                  if (t == m) {
                    var r = l,
                      w = Eh(r);
                    Jb(r, "Parameter is required");
                    var v = new Bh(0, 0);
                    var A = (w ? Eh(w) : document).documentElement;
                    r != A &&
                      ((r = Kh(r)),
                      (w = Fh(w)),
                      (w = Gh(w.Jc)),
                      (v.x = r.left + w.x),
                      (v.y = r.top + w.y));
                  } else (v = H(l)), (v = Kh(v)), (v = new Bh(v.left, v.top));
                  u.x += v.x;
                  u.y += v.y;
                } while (
                  t &&
                  t != m &&
                  t != t.parent &&
                  (l = t.frameElement) &&
                  (t = t.parent)
                );
              }
              m = u;
              k = { top: m.y, left: m.x, width: k.width, height: k.height };
            }
            k = Hi(k, h.va);
            m = Gi(k, h.oa);
            u = a.l.now();
            if (g !== 2 || a.Bb || m.width <= 0 || m.height <= 0) var C = !1;
            else
              try {
                var G = a.document.elementFromPoint(
                  m.left + m.width / 2,
                  m.top + m.height / 2
                );
                C = G ? !Vq(G, f) : !1;
              } catch (J) {
                C = !1;
              }
            return {
              timestamp: u,
              value: z({}, h, { Z: "geo", aa: C ? Sq.aa : m, N: k }),
            };
          }),
          Sh(a.queue)
        );
      };
    };
  }
  function Vq(a, b, c) {
    c = c === void 0 ? 0 : c;
    return a.j === void 0 || b.j === void 0
      ? !1
      : a.j === b.j ||
        Ih(b.j, function (d) {
          return d === a.j;
        })
      ? !0
      : b.j.ownerDocument &&
        b.j.ownerDocument.defaultView &&
        b.j.ownerDocument.defaultView === b.j.ownerDocument.defaultView.top
      ? !1
      : c < 10 &&
        b.j.ownerDocument &&
        b.j.ownerDocument.defaultView &&
        b.j.ownerDocument.defaultView.frameElement
      ? Vq(a, new hi(b.j.ownerDocument.defaultView.frameElement), c + 1)
      : !0;
  }
  function Wq(a) {
    return function (b) {
      return b.i(a.ResizeObserver ? Xq(a) : Yq(a), kf(1), pd());
    };
  }
  function Xq(a) {
    return function (b) {
      return b.i(
        U(function (c) {
          var d = a.ResizeObserver;
          if (!d || c.j === void 0) return fd(Sq.N);
          var e = new O(function (f) {
            function g() {
              c.j !== void 0 && h.unobserve(c.j);
              h.disconnect();
              k.unsubscribe();
            }
            if (c.j === void 0) return f.complete(), function () {};
            var h = new d(function (l) {
              l.forEach(function (m) {
                f.next(m);
              });
            });
            h.observe(c.j);
            var k = c.released.subscribe(g);
            return g;
          }).i(
            Bg(a.J, 736),
            Q(function (f) {
              return f.contentRect;
            })
          );
          return Wd(fd(c.j.getBoundingClientRect()), e);
        }),
        S(Fi)
      );
    };
  }
  function Yq(a) {
    return function (b) {
      var c = b.i(
          iq(a, {
            attributes: !0,
            childList: !0,
            characterData: !0,
            subtree: !0,
          })
        ),
        d = a.Ti;
      c = Wd(
        b.i(
          Q(function () {
            return gi("resize");
          })
        ),
        c,
        d
      );
      return Dd(b, c).i(
        Bg(a.J, 737),
        Q(function (e) {
          e = x(e).next().value;
          return e.j === void 0 ? void 0 : e.j.getBoundingClientRect();
        }),
        Ap(),
        S(Fi)
      );
    };
  }
  function Zq(a, b) {
    var c = $q(a, b).i(kf(1), pd());
    return function (d) {
      return function (e) {
        e = e.i(
          U(function (f) {
            return f.element;
          }),
          S()
        );
        return Dd([c, e]).i(
          U(function (f) {
            var g = x(f);
            f = g.next().value;
            g = g.next().value;
            return ar(a, f.ri, Wq(a), f.Ri, d, f.Zh, g);
          }),
          Sh(a.queue)
        );
      };
    };
  }
  function br(a, b, c) {
    var d = Zq(a, c)(b);
    return function (e) {
      var f = d(fd(e));
      return function (g) {
        return Dd([g, f]).i(
          Q(function (h) {
            var k = x(h);
            h = k.next().value;
            k = k.next().value;
            var l = Hi(k.value.N, h.value.va),
              m = Gi(Hi(k.value.aa, h.value.va), h.value.oa);
            return {
              timestamp: h.timestamp.maximum(k.timestamp),
              value: z({}, h.value, { Z: "nio", aa: m, N: l }),
            };
          })
        );
      };
    };
  }
  function cr(a) {
    return Q(function (b) {
      return b.value.ma !== "nio"
        ? b
        : z({}, b, { value: z({}, b.value, { oa: kp(a, !0), da: kp(a, !0) }) });
    });
  }
  function dr(a, b) {
    return fd(b).i(
      a,
      Q(function () {
        return b;
      })
    );
  }
  function $q(a, b) {
    return a.l.timeline !== ve
      ? gd(new je(2))
      : a.MutationObserver
      ? typeof IntersectionObserver === "undefined"
        ? gd(new je(0))
        : new O(function (c) {
            var d = new Ec(),
              e = new Pq(d.next.bind(d), { threshold: [].concat(y(b)) });
            c.next({
              Ri: d.i(Bg(a.J, 735)),
              ri: e,
              Zh: function (f) {
                f = e.takeRecords(f);
                f.length > 0 && d.next(f);
              },
            });
          }).i(Ye(1), kf(1), pd())
      : gd(new je(1));
  }
  function er(a) {
    return Uc(
      a.sort(function (b, c) {
        return b.time - c.time;
      }),
      td
    );
  }
  function ar(a, b, c, d, e, f, g) {
    return new O(function (h) {
      function k() {
        w ||
          ((w = !0),
          g.j !== void 0 && b.unobserve(e, g.j),
          m.unsubscribe(),
          r.unsubscribe(),
          t.unsubscribe(),
          v.unsubscribe());
      }
      if (g.j !== void 0) {
        Qq(b, e);
        b.observe(e, g.j);
        var l = new Gc({
            timestamp: a.l.now(),
            value: z({}, Sq, { ma: "nio", Z: "nio" }),
          }),
          m = d
            .i(
              Id(function (A) {
                return er(A);
              }),
              R(function (A) {
                return A.target === g.j;
              }),
              Q(function (A) {
                return {
                  timestamp: new xe(A.time, ve),
                  value: {
                    ma: "nio",
                    oa: A.rootBounds || Ei,
                    da: A.rootBounds || kp(a, !0),
                    ja: u,
                    Z: "nio",
                    aa: A.intersectionRect,
                    N: A.boundingClientRect,
                    va: { x: 0, y: 0 },
                    isIntersecting: A.isIntersecting,
                    Dg: A.isVisible,
                  },
                };
              }),
              hf(l),
              pd()
            )
            .subscribe(h),
          u = new Ec(),
          t = u.subscribe(function () {
            f(e);
            h.next({ timestamp: a.l.now(), value: l.value.value });
            g.j !== void 0 && (b.unobserve(e, g.j), b.observe(e, g.j));
          }),
          r = dr(c, g).subscribe(function () {
            u.next();
          }),
          w = !1,
          v = g.released.subscribe(function () {
            return k();
          });
        return k;
      }
    });
  }
  function fr(a, b) {
    var c = a.Ee().i(
      Q(function () {
        return "b";
      })
    );
    return ae(b, c).i(Ye(1), W(a.queue, 1));
  }
  function gr(a) {
    return function (b) {
      var c;
      return b.i(
        qf(function (d) {
          return void (c = d.timestamp);
        }),
        Q(function (d) {
          return d.value;
        }),
        a,
        Q(function (d) {
          return { timestamp: c, value: d };
        })
      );
    };
  }
  function hr(a) {
    return (a.aa.width * a.aa.height) / (a.N.width * a.N.height);
  }
  var ir = gr(
      N(
        Q(function (a) {
          var b;
          return (b = a.Ad) != null ? b : hr(a);
        }),
        Q(function (a) {
          return isFinite(a) ? a : 0;
        })
      )
    ),
    jr = gr(
      N(
        Q(function (a) {
          var b;
          return (b = a.Ad) != null ? b : hr(a);
        }),
        Q(function (a) {
          return isFinite(a) ? a : -1;
        })
      )
    );
  var kr = function (a, b) {
    this.a = a;
    this.b = b;
    if (a.clock.timeline !== b.clock.timeline) throw Error();
  };
  kr.prototype.ea = function (a) {
    return a instanceof kr ? this.a.ea(a.a) && this.b.ea(a.b) : !1;
  };
  da.Object.defineProperties(kr.prototype, {
    active: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.a.active || this.b.active;
      },
    },
    clock: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.a.clock;
      },
    },
    G: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        var a = this.a.G.timestamp.maximum(this.b.G.timestamp),
          b = this.a.G.timestamp.equals(a)
            ? this.a.G.value
            : this.a.za(a).value,
          c = this.b.G.timestamp.equals(a)
            ? this.b.G.value
            : this.b.za(a).value;
        return { timestamp: a, value: [b, c] };
      },
    },
  });
  kr.prototype.za = function (a) {
    var b = this.a.za(a).value,
      c = this.b.za(a).value;
    return { timestamp: a, value: [b, c] };
  };
  var lr = function (a, b) {
    this.input = a;
    this.Md = b;
    this.G = {
      timestamp: this.input.G.timestamp,
      value: this.Md(this.input.G.value),
    };
  };
  da.Object.defineProperties(lr.prototype, {
    active: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.input.active;
      },
    },
  });
  lr.prototype.ea = function (a) {
    return a instanceof lr ? this.input.ea(a.input) && this.Md === a.Md : !1;
  };
  da.Object.defineProperties(lr.prototype, {
    clock: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.input.clock;
      },
    },
  });
  lr.prototype.za = function (a) {
    a = this.input.za(a);
    return { timestamp: a.timestamp, value: this.Md(a.value) };
  };
  function mr(a, b, c) {
    c =
      c === void 0
        ? function (d, e) {
            return d === e;
          }
        : c;
    return a.timestamp.equals(b.timestamp) && c(a.value, b.value);
  }
  var nr = function (a, b, c) {
    this.clock = a;
    this.G = b;
    this.active = c;
  };
  nr.prototype.ea = function (a) {
    return a instanceof nr
      ? this.active === a.active &&
          this.clock.timeline === a.clock.timeline &&
          mr(this.G, a.G)
      : !1;
  };
  nr.prototype.za = function (a) {
    return {
      timestamp: a,
      value:
        this.G.value + (this.active ? Math.max(0, ze(a, this.G.timestamp)) : 0),
    };
  };
  var or = function () {};
  or.prototype.fa = function () {
    return this.za(this.clock.now());
  };
  or.prototype.Aa = function (a) {
    var b = this.clock.timeline,
      c,
      d = (c = a.get(b)) != null ? c : this.clock.now();
    a.set(b, d);
    return this.za(d);
  };
  or.prototype.map = function (a) {
    return new pr(this, a);
  };
  or.prototype.Ba = function (a) {
    return new qr(this, a);
  };
  var qr = function () {
    kr.apply(this, arguments);
    this.map = or.prototype.map;
    this.Ba = or.prototype.Ba;
    this.fa = or.prototype.fa;
    this.Aa = or.prototype.Aa;
  };
  q(qr, kr);
  var rr = function () {
    nr.apply(this, arguments);
    this.map = or.prototype.map;
    this.Ba = or.prototype.Ba;
    this.fa = or.prototype.fa;
    this.Aa = or.prototype.Aa;
  };
  q(rr, nr);
  var pr = function () {
    lr.apply(this, arguments);
    this.map = or.prototype.map;
    this.Ba = or.prototype.Ba;
    this.fa = or.prototype.fa;
    this.Aa = or.prototype.Aa;
  };
  q(pr, lr);
  function sr(a, b) {
    a.Pa && (a.Ib = a.Pa);
    a.Pa = b;
    a.Ib && a.Ib.value
      ? ((b = Math.max(0, ze(b.timestamp, a.Ib.timestamp))),
        (a.totalTime += b),
        (a.ya += b))
      : (a.ya = 0);
    return a;
  }
  function tr(a) {
    return N(
      mf(sr, { totalTime: 0, ya: 0 }),
      Q(function (b) {
        return new rr(
          a,
          { timestamp: b.Pa.timestamp, value: b.totalTime },
          b.Pa.value
        );
      })
    );
  }
  function ur(a) {
    return N(
      mf(sr, { totalTime: 0, ya: 0 }),
      Q(function (b) {
        return new rr(
          a,
          { timestamp: b.Pa.timestamp, value: b.ya },
          b.Pa.value
        );
      })
    );
  }
  function vr(a) {
    return N(
      ur(a),
      Q(function (b) {
        return b.map(function (c) {
          return Math.round(c);
        });
      })
    );
  }
  var wr = function (a, b) {
    this.G = b;
    this.fa = or.prototype.fa;
    this.Aa = or.prototype.Aa;
    this.map = or.prototype.map;
    this.Ba = or.prototype.Ba;
    this.clock = a;
  };
  da.Object.defineProperties(wr.prototype, {
    active: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return !1;
      },
    },
  });
  wr.prototype.ea = function (a) {
    return a.active;
  };
  wr.prototype.za = function () {
    return this.G;
  };
  function xr(a, b) {
    return b.i(
      Q(function (c) {
        return new wr(a.l, { timestamp: a.l.now(), value: c });
      })
    );
  }
  function yr(a, b) {
    return a >= 1 ? !0 : a <= 0 ? !1 : a >= b;
  }
  function zr(a) {
    return function (b) {
      return b.i(
        rf(a),
        Q(function (c) {
          var d = x(c);
          c = d.next().value;
          d = d.next().value;
          return { timestamp: c.timestamp, value: yr(c.value, d) };
        })
      );
    };
  }
  var Ar = Q(function (a) {
    if (a.value.ma === "omid") {
      if (a.value.Z === "nio") return "omio";
      if (a.value.Z === "geo") return "omgeo";
    }
    return a.value.Z === "geo" || a.value.Z === "nio" ? a.value.ma : a.value.Z;
  });
  function Br() {
    return N(
      R(function (a, b) {
        return b > 0;
      }),
      Cr,
      T(-1),
      S()
    );
  }
  var Cr = N(
    R(function (a) {
      return !isNaN(a);
    }),
    mf(function (a, b) {
      return isNaN(a) ? b : Math.min(a, b);
    }, NaN),
    S()
  );
  var Dr = gr(
    N(
      Q(function (a) {
        return (a.aa.width * a.aa.height) / (a.oa.width * a.oa.height);
      }),
      Q(function (a) {
        return isFinite(a) ? Math.min(1, a) : 0;
      })
    )
  );
  function Er(a, b, c) {
    return a
      ? Dd([b, c]).i(
          R(function (d) {
            var e = x(d);
            d = e.next().value;
            e = e.next().value;
            return d.timestamp.equals(e.timestamp);
          }),
          Q(function (d) {
            var e = x(d);
            d = e.next().value;
            e = e.next().value;
            return d.value > e.value ? d : e;
          })
        )
      : b;
  }
  function Fr(a) {
    return function (b) {
      var c = b.i(ir),
        d = b.i(Dr);
      return a instanceof O
        ? a.i(
            U(function (e) {
              return Er(e, c, d);
            })
          )
        : Er(a.value, c, d);
    };
  }
  var Gr = N(
    gr(
      Q(function (a) {
        a = a.Ad
          ? (a.N.width * a.N.height * a.Ad) / (a.da.width * a.da.height)
          : (a.aa.width * a.aa.height) / (a.da.width * a.da.height);
        return isFinite(a) ? a : 0;
      })
    )
  );
  function Hr(a, b, c, d) {
    var e = d.Cd,
      f = d.ze,
      g = d.kh,
      h = d.Lf,
      k = d.Ue,
      l = d.Gg,
      m = d.Fd;
    d = d.hh;
    b = Ir(a, c, b);
    c = Jr(a, c);
    d = Kr(b, d);
    var u = Lr(a, e, l, b),
      t = u.i(
        Q(function (B) {
          return B.value;
        }),
        S(),
        W(a, 1),
        mf(function (B, ja) {
          return Math.max(B, ja);
        }, 0)
      ),
      r = u.i(
        Q(function (B) {
          return B.value;
        }),
        Br(),
        W(a, 1)
      ),
      w = b.i(
        jr,
        Q(function (B) {
          return B.value;
        }),
        Ye(2),
        S(),
        W(a, 1)
      );
    g = Mr(a, b, g, h);
    var v = g.i(
      T(!1),
      S(),
      Q(function (B) {
        return B ? k : f;
      })
    );
    h = u.i(zr(v), S(), W(a, 1));
    var A = Dd([h, b]).i(
      R(function (B) {
        var ja = x(B);
        B = ja.next().value;
        ja = ja.next().value;
        return B.timestamp.equals(ja.timestamp);
      }),
      Q(function (B) {
        var ja = x(B);
        B = ja.next().value;
        ja = ja.next().value;
        return { visible: B.value, geometry: ja.value.N };
      }),
      mf(
        function (B, ja) {
          return !ja.visible && B.visible ? B : ja;
        },
        { visible: !1, geometry: Ei }
      ),
      Q(function (B) {
        return B.geometry;
      }),
      T(Ei),
      W(a, 1),
      S(Fi)
    );
    l = l instanceof O ? l.i(S(), Xe()) : Xd;
    v = Dd([l, v]).i(Xe());
    var C = b.i(
        R(function (B) {
          return B.value.ma !== "ns" && B.value.Z !== "ns";
        }),
        mf(function (B) {
          return B + 1;
        }, 0),
        T(0),
        W(a, 1)
      ),
      G = c.i(Xe(!0), T(!1), W(a, 1));
    G = Dd([m, G]).i(
      Q(function (B) {
        var ja = x(B);
        B = ja.next().value;
        ja = ja.next().value;
        return B && !ja;
      }),
      W(a, 1)
    );
    var J = b.i(Gr, S()),
      Y = J.i(
        Q(function (B) {
          return B.value;
        }),
        mf(function (B, ja) {
          return Math.max(B, ja);
        }, 0),
        S(),
        W(a, 1)
      ),
      I = J.i(
        Q(function (B) {
          return B.value;
        }),
        Br(),
        W(a, 1)
      );
    return {
      mf: l,
      hd: v,
      Ia: {
        Zi: b,
        Hg: b.i(Ar),
        wd: A.i(S(Fi)),
        visible: h.i(S(mr)),
        sf: u.i(S(mr)),
        Fg: t,
        Li: r,
        Of: b.i(Mq, S(Rb)),
        vj: J,
        Ei: Y,
        Ki: I,
        Bd: c,
        ja: new X(new Ec()).S(a),
        Ag: g,
        Cd: e,
        Fd: m,
        gg: G,
        wj: C,
        Bi: w,
        Zd: d,
      },
    };
  }
  function Jr(a, b) {
    return b.i(
      R(function () {
        return !1;
      }),
      Q(function (c) {
        return c;
      }),
      Pe(function (c) {
        return new X(c).S(a);
      })
    );
  }
  function Kr(a, b) {
    a = Dd([a, b]).i(
      Q(function (e) {
        var f = x(e);
        e = f.next().value;
        if (f.next().value && e.value.isIntersecting) return e.value.Dg;
      }),
      S()
    );
    var c = a.i(
        Q(function (e) {
          return e === void 0 ? !0 : e;
        }),
        mf(function (e, f) {
          return e || !f;
        }, !1)
      ),
      d = a.i(
        mf(function (e, f) {
          return f === void 0 ? e : f ? !1 : e != null ? e : !0;
        }, void 0),
        Q(function (e) {
          return !!e;
        })
      );
    return Dd([b, ce(a, c, d)]).i(
      Q(function (e) {
        var f = x(e);
        e = f.next().value;
        var g = x(f.next().value);
        f = g.next().value;
        var h = g.next().value;
        g = g.next().value;
        var k = 0;
        if (!e) return 0;
        if (f === void 0) return 16;
        f && (k |= 1);
        f || (k |= 2);
        h && (k |= 4);
        g && (k |= 8);
        return k;
      })
    );
  }
  function Ir(a, b, c) {
    return b.i($d(Xd), W(a, 1)).i(
      S(function (d, e) {
        return mr(d, e, Tq);
      }),
      T({ timestamp: c.now(), value: Sq }),
      W(a, 1)
    );
  }
  function Lr(a, b, c, d) {
    c = d.i(
      Fr(c),
      gr(
        Q(function (e) {
          return Math.round(e * 100) / 100;
        })
      ),
      W(a, 1)
    );
    return b instanceof X
      ? c
      : Dd([c, b]).i(
          Q(function (e) {
            var f = x(e);
            e = f.next().value;
            f = f.next().value;
            return {
              timestamp: f.timestamp.maximum(e.timestamp),
              value: f.value ? 0 : e.value,
            };
          }),
          S(mr),
          W(a, 10)
        );
  }
  function Mr(a, b, c, d) {
    b = [
      b.i(
        Q(function (e) {
          return e.value.N.width * e.value.N.height >= 242500;
        })
      ),
    ];
    c instanceof O &&
      b.push(
        c.i(
          Q(function (e) {
            return !!e;
          })
        )
      );
    c = Dd(b);
    return d
      ? c.i(
          Q(function (e) {
            return e.some(function (f) {
              return f;
            });
          }),
          T(!1),
          S(),
          W(a, 1)
        )
      : new X(!1).S(a);
  }
  var Nr = function (a) {
      this.l = a;
      this.Ud = null;
      this.timeout = new Ec();
    },
    Pr = function (a, b) {
      Or(a);
      a.Ud = a.l.setTimeout(function () {
        return void a.timeout.next();
      }, b);
    },
    Or = function (a) {
      a.Ud !== null && (a.l.clearTimeout(a.Ud), (a.Ud = null));
    };
  function Qr(a, b, c, d) {
    var e = Rr.eh,
      f = new Nr(b);
    c = c
      .i(
        T(void 0),
        U(function () {
          Or(f);
          return d;
        })
      )
      .i(
        Q(function (g) {
          Or(f);
          var h = g.G,
            k = g.active;
          h.value >= e ||
            !k ||
            ((k = b.now()),
            (k = Math.max(0, ze(k, h.timestamp))),
            Pr(f, Math.max(0, e - h.value - k)));
          return g.map(function (l) {
            return l >= e;
          });
        })
      );
    return Dd([c, Wd(f.timeout, fd(void 0))]).i(
      Q(function (g) {
        return x(g).next().value;
      }),
      pf(function (g) {
        return !g.fa().value;
      }, !0),
      W(a, 1)
    );
  }
  function Sr(a) {
    var b = new rr(a, { timestamp: a.now(), value: 0 }, !1);
    return N(
      ur(a),
      mf(function (c, d) {
        return c.G.value > d.G.value ? new rr(a, c.G, !1) : d;
      }, b),
      Q(function (c) {
        return c.map(function (d) {
          return Math.round(d);
        });
      })
    );
  }
  function Tr(a) {
    return function (b) {
      return N(zr(fd(b)), Sr(a));
    };
  }
  function Ur(a) {
    return function (b) {
      return N(
        gr(
          Q(function (c) {
            return yr(c, b);
          })
        ),
        tr(a),
        Q(function (c) {
          return c.map(function (d) {
            return Math.round(d);
          });
        })
      );
    };
  }
  function Vr(a) {
    return a
      .map(function (b) {
        return b.map(function (c) {
          return [c];
        });
      })
      .reduce(function (b, c) {
        return b.Ba(c).map(function (d) {
          return d.flat();
        });
      });
  }
  function Wr(a, b) {
    return a.Ba(b).map(function (c) {
      var d = x(c);
      c = d.next().value;
      d = d.next().value;
      return c - d;
    });
  }
  function Xr(a, b, c, d, e, f) {
    var g = Yr;
    if (g.length > 1)
      for (var h = 0; h < g.length - 1; h++) if (g[h] < g[h + 1]) throw Error();
    h = f.i(
      T(void 0),
      U(function () {
        return d.i(vr(a));
      }),
      S(function (k, l) {
        return k.ea(l);
      }),
      W(b, 1)
    );
    f = f.i(
      T(void 0),
      U(function () {
        return d.i(Sr(a));
      }),
      S(function (k, l) {
        return k.ea(l);
      }),
      W(b, 1)
    );
    return {
      Wd: e.i(
        T(void 0),
        U(function () {
          return c.i(
            Q(function (k) {
              return { timestamp: k.timestamp, value: !0 };
            }),
            tr(a)
          );
        }),
        S(function (k, l) {
          return k.ea(l);
        }),
        W(b, 1)
      ),
      Xd: e.i(
        T(void 0),
        U(function () {
          return c.i(
            Q(function (k) {
              return { timestamp: k.timestamp, value: k.value === 0 };
            }),
            tr(a)
          );
        }),
        S(function (k, l) {
          return k.ea(l);
        }),
        W(b, 1)
      ),
      Vc: e.i(
        T(void 0),
        U(function () {
          return c.i(Nq(Tr(a), g));
        }),
        Q(Vr),
        S(function (k, l) {
          return k.ea(l);
        }),
        W(b, 1)
      ),
      Wa: e.i(
        T(void 0),
        U(function () {
          return c.i(
            Nq(Ur(a), g),
            Q(function (k) {
              return k.map(function (l, m) {
                return m > 0 ? Wr(l, k[m - 1]) : l;
              });
            })
          );
        }),
        Q(Vr),
        S(function (k, l) {
          return k.ea(l);
        }),
        W(b, 1)
      ),
      Uc: f,
      pb: h.i(
        S(function (k, l) {
          return k.ea(l);
        }),
        W(b, 1)
      ),
    };
  }
  function Zr(a) {
    var b;
    if ((b = $r(a)))
      b =
        !as(a, "abgcp") &&
        !as(a, "abgc") &&
        !(typeof a.id === "string" && a.id === "abgb") &&
        !(typeof a.id === "string" && a.id === "mys-abgc") &&
        !as(a, "cbb");
    return b;
  }
  function as(a, b) {
    return a.classList
      ? a.classList.contains(b)
      : (" " + a.className + " ").indexOf(" " + b + " ") > -1;
  }
  function $r(a) {
    try {
      var b = a.getBoundingClientRect();
      return b && b.height >= 30 && b.width >= 30;
    } catch (c) {
      return !1;
    }
  }
  function bs(a, b) {
    if (a.j === void 0 || !a.j.children) return a;
    for (var c = Qb(a.j.children); c.length; ) {
      var d = b ? c.filter(Zr) : c.filter($r);
      if (d.length === 1) return new hi(d[0]);
      if (d.length > 1) break;
      c = Tb(c, function (e) {
        return Qb(e.children);
      });
    }
    return a;
  }
  function cs(a, b, c, d, e) {
    if (c) return { vd: b, Jb: fd(null) };
    c = b.element.i(
      Q(function (f) {
        a: if (f.j === void 0 || $r(f.j)) f = { Nd: f, Jb: "mue" };
        else {
          var g = bs(f, e);
          if (g.j !== void 0 && $r(g.j)) f = { Nd: g, Jb: "ie" };
          else {
            if (d || a.Ke)
              if (
                (g = a.document.querySelector(
                  ".GoogleActiveViewInnerContainer"
                ))
              ) {
                f = { Nd: new hi(g), Jb: "ce" };
                break a;
              }
            f = { Nd: f, Jb: "mue" };
          }
        }
        return f;
      }),
      nf()
    );
    return {
      vd: {
        Ob: b.Ob,
        element: c.i(
          Q(function (f) {
            return f.Nd;
          })
        ),
      },
      Jb: c.i(
        Q(function (f) {
          return f.Jb;
        })
      ),
    };
  }
  function ds(a, b, c, d) {
    var e = d.Cd,
      f = d.ze,
      g = d.kh,
      h = d.Lf,
      k = d.Ue,
      l = d.Gg,
      m = d.Fd;
    d = d.hh;
    b = es(a, c, b);
    c = fs(a, c);
    d = gs(b, d);
    var u = hs(a, e, l, b),
      t = u.i(
        Q(function (I) {
          return I.value;
        }),
        S(),
        W(a, 1),
        mf(function (I, B) {
          return Math.max(I, B);
        }, 0)
      ),
      r = u.i(
        Q(function (I) {
          return I.value;
        }),
        Br(),
        W(a, 1)
      ),
      w = b.i(
        jr,
        Q(function (I) {
          return I.value;
        }),
        Ye(2),
        S(),
        W(a, 1)
      );
    g = is(a, b, g, h);
    var v = g.i(
      T(!1),
      S(),
      Q(function (I) {
        return I ? k : f;
      })
    );
    h = u.i(zr(v), S(), W(a, 1));
    var A = Dd([h, b]).i(
      R(function (I) {
        var B = x(I);
        I = B.next().value;
        B = B.next().value;
        return I.timestamp.equals(B.timestamp);
      }),
      Q(function (I) {
        var B = x(I);
        I = B.next().value;
        B = B.next().value;
        return { visible: I.value, geometry: B.value.N };
      }),
      mf(
        function (I, B) {
          return !B.visible && I.visible ? I : B;
        },
        { visible: !1, geometry: Ei }
      ),
      Q(function (I) {
        return I.geometry;
      }),
      T(Ei),
      W(a, 1),
      S(Fi)
    );
    l = l instanceof O ? l.i(S(), Xe()) : Xd;
    v = Dd([l, v]).i(Xe());
    var C = b.i(
        R(function (I) {
          return I.value.ma !== "ns" && I.value.Z !== "ns";
        }),
        mf(function (I) {
          return I + 1;
        }, 0),
        T(0),
        W(a, 1)
      ),
      G = c.i(Xe(!0), T(!1), W(a, 1));
    G = Dd([m, G]).i(
      Q(function (I) {
        var B = x(I);
        I = B.next().value;
        B = B.next().value;
        return I && !B;
      }),
      W(a, 1)
    );
    var J = b.i(Gr, S()),
      Y = J.i(
        Q(function (I) {
          return I.value;
        }),
        mf(function (I, B) {
          return Math.max(I, B);
        }, 0),
        S(),
        W(a, 1)
      );
    a = J.i(
      Q(function (I) {
        return I.value;
      }),
      Br(),
      W(a, 1)
    );
    return {
      mf: l,
      hd: v,
      Ia: {
        Zi: b,
        Hg: b.i(Ar),
        wd: A.i(S(Fi)),
        visible: h.i(S(mr)),
        sf: u.i(S(mr)),
        Fg: t,
        Li: r,
        Of: b.i(Mq, S(Rb)),
        vj: J,
        Ei: Y,
        Ki: a,
        Bd: c,
        ja: b.i(
          Q(function (I) {
            return I.value.ja;
          })
        ),
        Ag: g,
        Cd: e,
        Fd: m,
        gg: G,
        wj: C,
        Bi: w,
        Zd: d,
      },
    };
  }
  function fs(a, b) {
    return b.i(
      R(function () {
        return !1;
      }),
      Q(function (c) {
        return c;
      }),
      Pe(function (c) {
        return new X(c).S(a);
      })
    );
  }
  function es(a, b, c) {
    return b.i($d(Xd), W(a, 1)).i(
      S(function (d, e) {
        return mr(d, e, Tq);
      }),
      T({ timestamp: c.now(), value: Sq }),
      W(a, 1)
    );
  }
  function hs(a, b, c, d) {
    c = d.i(
      Fr(c),
      gr(
        Q(function (e) {
          return Math.round(e * 100) / 100;
        })
      ),
      W(a, 1)
    );
    return b instanceof X
      ? c
      : Dd([c, b]).i(
          Q(function (e) {
            var f = x(e);
            e = f.next().value;
            f = f.next().value;
            return {
              timestamp: f.timestamp.maximum(e.timestamp),
              value: f.value ? 0 : e.value,
            };
          }),
          S(mr),
          W(a, 1)
        );
  }
  function is(a, b, c, d) {
    b = [
      b.i(
        Q(function (e) {
          return e.value.N.width * e.value.N.height >= 242500;
        })
      ),
    ];
    c instanceof O &&
      b.push(
        c.i(
          Q(function (e) {
            return !!e;
          })
        )
      );
    c = Dd(b);
    return d
      ? c.i(
          Q(function (e) {
            return e.some(function (f) {
              return f;
            });
          }),
          T(!1),
          S(),
          W(a, 1)
        )
      : new X(!1).S(a);
  }
  function gs(a, b) {
    a = Dd([a, b]).i(
      Q(function (e) {
        var f = x(e);
        e = f.next().value;
        if (f.next().value && e.value.isIntersecting) return e.value.Dg;
      }),
      S()
    );
    var c = a.i(
        Q(function (e) {
          return e === void 0 ? !0 : e;
        }),
        mf(function (e, f) {
          return e || !f;
        }, !1)
      ),
      d = a.i(
        mf(function (e, f) {
          return f === void 0 ? e : f ? !1 : e != null ? e : !0;
        }, void 0),
        Q(function (e) {
          return !!e;
        })
      );
    return Dd([b, ce(a, c, d)]).i(
      Q(function (e) {
        var f = x(e);
        e = f.next().value;
        var g = x(f.next().value);
        f = g.next().value;
        var h = g.next().value;
        g = g.next().value;
        var k = 0;
        if (!e) return 0;
        if (f === void 0) return 16;
        f && (k |= 1);
        f || (k |= 2);
        h && (k |= 4);
        g && (k |= 8);
        return k;
      })
    );
  }
  var js = N(
    sp("data-google-av-itpl"),
    Q(function (a) {
      return Number(a);
    }),
    Q(function (a) {
      return isNaN(a) ? 1 : a;
    })
  );
  var ks = {
      Dj: "addEventListener",
      Nj: "getMaxSize",
      Oj: "getScreenSize",
      Pj: "getState",
      Qj: "getVersion",
      bk: "removeEventListener",
      Wj: "isViewable",
    },
    ls = function (a, b) {
      this.Da = null;
      this.oi = new Ec();
      b = b || this.xj;
      var c = a.Ke,
        d = !a.Bb;
      if (c && d) {
        var e = a.global.top.mraid;
        if (e) {
          this.ud = b(e);
          this.Da = e;
          this.Nb = 3;
          return;
        }
      }
      (a = a.global.mraid)
        ? ((this.ud = b(a)), (this.Da = a), (this.Nb = c ? (d ? 2 : 1) : 0))
        : ((this.Nb = -1), (this.ud = 2));
    };
  da.Object.defineProperties(ls.prototype, {
    Xf: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        if (this.Da) {
          var a = this.Da.AFMA_LIDAR_EXP_1;
          return a === void 0 ? void 0 : !!a;
        }
      },
      set: function (a) {
        this.Da && (this.Da.AFMA_LIDAR_EXP_1 = a);
      },
    },
  });
  ls.prototype.addEventListener = function (a, b) {
    return this.uc("addEventListener", a, b);
  };
  ls.prototype.removeEventListener = function (a, b) {
    return this.uc("removeEventListener", a, b);
  };
  ls.prototype.mg = function () {
    var a = this.uc("getVersion");
    return typeof a === "string" ? a : "";
  };
  ls.prototype.getState = function () {
    var a = this.uc("getState");
    return typeof a === "string" ? a : "";
  };
  var ms = function (a) {
      a = a.uc("isViewable");
      return typeof a === "boolean" ? a : !1;
    },
    ns = function (a) {
      if (a.Da)
        return (a = a.Da.AFMA_LIDAR), typeof a === "string" ? a : void 0;
    };
  ls.prototype.xj = function (a) {
    return a
      ? a.IS_GMA_SDK
        ? Object.values(ks).every(function (b) {
            return typeof a[b] === "function";
          })
          ? 0
          : 1
        : 2
      : 1;
  };
  ls.prototype.uc = function (a) {
    var b = F.apply(1, arguments);
    if (this.Da)
      try {
        return this.Da[a].apply(this.Da, y(b));
      } catch (c) {
        this.oi.next(a);
      }
  };
  function os(a, b) {
    return new ls(a).Nb !== -1
      ? new X(!0).S(a.queue)
      : b.i(
          sp("data-google-av-inapp"),
          Q(function (c) {
            return c !== null;
          }),
          W(a.queue, 1)
        );
  }
  var qs = function (a, b) {
      var c = this;
      this.l = a;
      this.Ve = this.Kd = null;
      this.dj = b.i(S()).subscribe(function (d) {
        ps(c);
        c.Ve = d;
      });
    },
    rs = function (a, b) {
      ps(a);
      a.Kd = a.l.setTimeout(function () {
        var c;
        return void ((c = a.Ve) == null ? void 0 : c.next());
      }, b);
    },
    ps = function (a) {
      a.Kd !== null && a.l.clearTimeout(a.Kd);
      a.Kd = null;
    };
  qs.prototype.dispose = function () {
    ps(this);
    this.dj.unsubscribe();
    this.Ve = null;
  };
  function ss(a, b, c, d, e) {
    var f = Rr.eh;
    var g = g === void 0 ? new qs(b, d) : g;
    return new O(function (h) {
      var k = c
        .i(
          T(void 0),
          U(function () {
            return ts(e);
          })
        )
        .i(
          Q(function (l) {
            var m = l.value;
            l = l.timestamp;
            var u = m.visible;
            m = m.pb;
            var t = m >= f;
            t || !u
              ? ps(g)
              : ((l = Math.max(0, ze(b.now(), l))),
                rs(g, Math.max(0, f - m - l)));
            return t;
          }),
          mf(function (l, m) {
            return m || l;
          }, !1),
          S()
        )
        .subscribe(h);
      return function () {
        g.dispose();
        k.unsubscribe();
      };
    }).i(
      pf(function (h) {
        return !h;
      }, !0),
      W(a, 1)
    );
  }
  function ts(a) {
    return yq([a, a.i(Oq())]).i(
      Q(function (b) {
        var c = x(b);
        b = c.next().value;
        c = c.next().value;
        return {
          timestamp: b.timestamp,
          value: { visible: b.value, pb: c.value },
        };
      }),
      S(function (b, c) {
        return mr(b, c, function (d, e) {
          return d.pb === e.pb && d.visible === e.visible;
        });
      })
    );
  }
  function us(a, b) {
    return {
      wa: b.i(sp("data-google-av-adk")),
      Ec: b.i(
        sp("data-google-av-btr"),
        S(),
        Q(function (c) {
          return c === null
            ? []
            : c.split("|").filter(function (d) {
                return d !== "";
              });
        })
      ),
      te: b.i(
        sp("data-google-av-cpmav"),
        S(),
        Q(function (c) {
          return c === null
            ? []
            : c.split("|").filter(function (d) {
                return d !== "";
              });
        })
      ),
      xf: b.i(
        sp("data-google-av-vrus"),
        S(),
        Q(function (c) {
          return c === null
            ? []
            : c.split("|").filter(function (d) {
                return d !== "";
              });
        })
      ),
      Lh: kq(a, b),
      flags: b.i(sp("data-google-av-flags"), S()),
      Ab: os(a, b),
      Qe: b.i(
        Cq("cr", function (c) {
          return c === "1";
        }),
        S()
      ),
      ui: b.i(
        Cq("omid", function (c) {
          return c === "1";
        }),
        S()
      ),
      Me: b.i(js),
      metadata: b.i(sp("data-google-av-metadata")),
      fb: b.i(zp),
      ua: b.i(tp),
      Bj: b.i(
        Cq("la", function (c) {
          return c === "1";
        }),
        S()
      ),
      Cb: b.i(
        sp("data-google-av-turtlex"),
        Q(function (c) {
          return c !== null;
        }),
        S()
      ),
      Te: b.i(
        sp("data-google-av-vattr"),
        Q(function (c) {
          return c !== null;
        }),
        S()
      ),
    };
  }
  function vs() {
    return N(
      Bq(),
      mf(function (a, b) {
        return Math.max(a, b);
      }, 0),
      Q(function (a) {
        return Math.round(a);
      })
    );
  }
  function ws(a) {
    return N(zr(fd(a)), vs());
  }
  function xs(a, b, c, d, e) {
    c = c.i(
      Q(function () {
        return !1;
      })
    );
    d = Dd([e, d]).i(
      U(function (f) {
        f = x(f).next().value;
        return ys(b, f);
      })
    );
    return Wd(fd(!1), c, d).i(S(), W(a.queue, 1));
  }
  function ys(a, b) {
    return a.i(
      Q(function (c) {
        return b || c === 0 || c === 2;
      })
    );
  }
  var zs = [33, 32],
    As = N(
      js,
      Q(function (a) {
        return zs.indexOf(a) >= 0;
      }),
      S()
    );
  function Bs(a, b, c, d, e, f) {
    var g = c.i(
        Q(function (k) {
          return k === 9;
        })
      ),
      h = b.element.i(As);
    c = e.i(
      R(function (k) {
        return k;
      }),
      U(function () {
        return Dd([g, h]);
      }),
      Q(function (k) {
        var l = x(k);
        k = l.next().value;
        return !l.next().value || k;
      }),
      S()
    );
    f = Dd([c, d.i(S()), f]).i(
      Q(function (k) {
        var l = x(k);
        k = l.next().value;
        var m = l.next().value;
        l = l.next().value;
        return cs(a, b, !k, m, l);
      }),
      kf(1),
      pd()
    );
    d = f.i(
      Q(function (k) {
        return k.vd;
      })
    );
    f = f.i(
      U(function (k) {
        return k.Jb;
      }),
      T(null),
      S(),
      W(a.queue, 1)
    );
    return { cb: d, Gc: f };
  }
  function Cs(a) {
    var b = b === void 0 ? !1 : b;
    return N(
      U(function (c) {
        return Bi(a.document, c, b);
      }),
      W(a.queue, 1)
    );
  }
  var Ds = function (a, b, c, d, e, f) {
    this.Rc = b.element.i(Cs(a), W(a.queue, 1));
    this.Xg = xs(a, c, b.element, this.Rc, d);
    c = Bs(a, b, e, d, this.Xg, f);
    d = c.Gc;
    this.cb = c.cb;
    this.Gc = d;
    this.yf = Wd(
      new X(1).S(a.queue),
      b.element.i(
        Ye(1),
        Q(function () {
          return 2;
        }),
        W(a.queue, 1)
      ),
      this.Rc.i(
        Ye(1),
        Q(function () {
          return 3;
        }),
        W(a.queue, 1)
      ),
      this.Xg.i(
        R(Boolean),
        Ye(1),
        Q(function () {
          return 0;
        }),
        W(a.queue, 1)
      )
    ).i(
      pf(function (g) {
        return g !== 0;
      }, !0),
      W(a.queue, 0)
    );
  };
  function Es(a, b) {
    return a && b === 0 ? 15 : a || b !== 1 ? null : 14;
  }
  function Fs(a, b, c) {
    return b instanceof O
      ? b.i(
          U(function (d) {
            return (d = Es(d, c)) ? gd(new je(d)) : a;
          })
        )
      : (b = Es(b.value, c))
      ? gd(new je(b))
      : a;
  }
  function Gs(a) {
    var b = new je(13);
    if (a.length < 1) return { chain: Hc, pe: Hc };
    var c = new Ec(),
      d = a[0];
    return {
      chain: a
        .slice(1)
        .reduce(function (e, f) {
          return e.i(
            Pe(function (g) {
              c.next(g);
              return f;
            })
          );
        }, d)
        .i(
          Pe(function (e) {
            c.next(e);
            return gd(b);
          }),
          hf(new Ec()),
          pd()
        ),
      pe: c,
    };
  }
  var Hs = function () {};
  var Is = function (a, b) {
    this.context = a;
    this.qj = b;
  };
  q(Is, Hs);
  Is.prototype.mb = function (a, b) {
    var c = this.qj.map(function (f) {
        return f.mb(a, b);
      }),
      d = Gs(
        c.map(function (f) {
          return f.ub;
        })
      ),
      e = d.pe.i(Js());
    return {
      ub: d.chain.i(W(this.context.queue, 1)),
      lb: Object.assign.apply(
        Object,
        [{ pf: e, Uk: d.pe }].concat(
          y(
            c.map(function (f) {
              return f.lb;
            })
          )
        )
      ),
    };
  };
  var Js = function () {
    return mf(function (a, b) {
      b instanceof je ? a.push(b.Hi) : a.push(-1);
      return a;
    }, []);
  };
  function Ks(a, b) {
    var c = a.i(hf(new Ec()), pd());
    return U(function (d) {
      return c.i(b(d));
    });
  }
  function Ls(a, b) {
    if (a.Bb) return gd(new je(6));
    var c = new Ec();
    return Wd(fd({}), b, c).i(
      Q(function () {
        return {
          timestamp: a.l.now(),
          value: {
            ma: "geo",
            oa: Ms(a),
            da: kp(a, !0),
            ja: c,
            va: { x: 0, y: 0 },
          },
        };
      }),
      Sh(a.queue)
    );
  }
  function Ms(a) {
    var b = kp(a, !1);
    if (!a.Ke || !Ug(a.global.parent) || a.global.parent === a.global) return b;
    var c = new fp(a.global.parent, a.Qa);
    c.H = a.H;
    c = Ms(c);
    a = a.global.frameElement.getBoundingClientRect();
    return Gi(Hi(Gi(c, a), { x: b.left - a.left, y: b.top - a.top }), b);
  }
  var Ns = function (a, b) {
    this.context = a;
    this.Hb = b;
  };
  q(Ns, Hs);
  Ns.prototype.mb = function (a, b) {
    var c = Ks(Ls(this.context, this.Hb), Uq(this.context, b.fb));
    return { ub: Fs(a.cb.i(c), b.Ab, 0), lb: {} };
  };
  var Os = function (a, b, c) {
    c = c === void 0 ? Zq(a, b) : c;
    this.context = a;
    this.si = c;
  };
  q(Os, Hs);
  Os.prototype.mb = function (a, b) {
    var c = this.si(b.ih);
    return { ub: Fs(a.cb.i(c, cr(this.context)), b.Ab, 0), lb: {} };
  };
  function Ps(a, b, c, d, e) {
    var f = f === void 0 ? new ls(a) : f;
    var g = g === void 0 ? vf(a.l, 500) : g;
    var h = h === void 0 ? vf(a.l, 100) : h;
    e = fd(f).i(
      Qs(c),
      qf(function (k) {
        d.next(k.Nb);
      }),
      Rs(a, h),
      Ss(a),
      Ts(a, e),
      kf(1),
      pd()
    );
    f = new Ec();
    b = Wd(fd({}), b, f);
    return e.i(Us(a, f, b, g, c), W(a.queue, 1));
  }
  function Ts(a, b) {
    return N(
      function (c) {
        return Dd([c, b]);
      },
      Ze(function (c) {
        var d = x(c);
        c = d.next().value;
        return d.next().value !== 9 || ms(c)
          ? fd(!0)
          : Vs(a, c, "viewableChange").i(
              R(function (e) {
                return x(e).next().value;
              }),
              Ye(1)
            );
      }),
      Q(function (c) {
        return x(c).next().value;
      })
    );
  }
  function Qs(a) {
    return U(function (b) {
      if (b.Nb === -1) return a.next("if"), gd(new je(7));
      if (b.ud !== 0)
        switch (b.ud) {
          case 1:
            return a.next("mm"), gd(new je(18));
          case 2:
            return a.next("ng"), gd(new je(17));
          default:
            return a.next("i"), gd(new je(8));
        }
      return fd(b);
    });
  }
  function Rs(a, b) {
    return Ze(function () {
      var c = a.Jg;
      return zi(a.document) === "complete"
        ? fd(!0)
        : c.i(
            Ze(function () {
              return b;
            })
          );
    });
  }
  function Ss(a) {
    return U(function (b) {
      return b.getState() !== "loading"
        ? fd(b)
        : Vs(a, b, "ready").i(
            Q(function () {
              return b;
            })
          );
    });
  }
  function Us(a, b, c, d, e) {
    return U(function (f) {
      var g = ns(f);
      if (typeof g !== "string") return e.next("nc"), gd(new je(9));
      f.Xf !== void 0 && (f.Xf = !0);
      g = Vs(a, f, g, Ws);
      var h = { version: f.mg(), Nb: f.Nb };
      g = g.i(
        Q(function (l) {
          return Xs.apply(null, [a, b, f, h].concat(y(l)));
        })
      );
      var k = d.i(
        qf(function () {
          e.next("mt");
        }),
        U(function () {
          return gd(new je(10));
        })
      );
      g = ae(g, k);
      return Dd([g, c]).i(
        Q(function (l) {
          l = x(l).next().value;
          return z({}, l, { timestamp: a.l.now() });
        })
      );
    });
  }
  function Ws(a, b) {
    return (
      (b === null || typeof b === "number") &&
      (a === null ||
        (!!a &&
          typeof a.height === "number" &&
          typeof a.width === "number" &&
          typeof a.x === "number" &&
          typeof a.y === "number"))
    );
  }
  function Xs(a, b, c, d, e, f) {
    e = e ? { left: e.x, top: e.y, width: e.width, height: e.height } : Ei;
    c = c.uc("getMaxSize");
    var g =
      c != null && typeof c.width === "number" && typeof c.height === "number"
        ? c
        : { width: 0, height: 0 };
    c = { left: 0, top: 0, width: -1, height: -1 };
    if (g) {
      var h = Number(String(g.width));
      g = Number(String(g.height));
      c = isNaN(h) || isNaN(g) ? c : { left: 0, top: 0, width: h, height: g };
    }
    a = {
      value: { oa: e, da: c, ma: "mraid", ja: b, va: { x: 0, y: 0 } },
      timestamp: a.l.now(),
    };
    return z({}, a, d, { hk: f });
  }
  function Vs(a, b, c, d) {
    d =
      d === void 0
        ? function () {
            return !0;
          }
        : d;
    return new O(function (e) {
      var f = a.J.yc(745, function () {
        e.next(F.apply(0, arguments));
      });
      b.addEventListener(c, f);
      return function () {
        b.removeEventListener(c, f);
      };
    }).i(
      R(function (e) {
        return d.apply(null, y(e));
      })
    );
  }
  var Ys = function (a, b) {
    this.context = a;
    this.Hb = b;
  };
  q(Ys, Hs);
  Ys.prototype.mb = function (a, b) {
    var c = new id(1),
      d = new id(1),
      e = Ks(Ps(this.context, this.Hb, c, d, b.fb), Uq(this.context, b.fb));
    return {
      ub: Fs(a.cb.i(e), b.Ab, 1),
      lb: {
        We: c.i(W(this.context.queue, 1)),
        Xe: d.i(W(this.context.queue, 1)),
      },
    };
  };
  function Zs(a) {
    return ["backgrounded", "notFound", "hidden", "noOutputDevice"].includes(a);
  }
  function $s(a, b) {
    var c = c === void 0 ? null : c;
    var d = new Ec(),
      e = void 0,
      f = a.fg,
      g = d.i(
        Q(function () {
          return e ? Object.assign({}, e, { timestamp: a.l.now() }) : null;
        }),
        R(function (k) {
          return k !== null;
        }),
        Q(function (k) {
          return k;
        })
      );
    b = Dd([Wd(f, g), b]);
    var h = c;
    return b.i(
      R(function (k) {
        k = x(k).next().value;
        h === null && (h = k.value.yh);
        return k.value.yh === h;
      }),
      qf(function (k) {
        return void (e = x(k).next().value);
      }),
      Q(function (k) {
        var l = x(k);
        k = l.next().value;
        l = l.next().value;
        try {
          var m = k.value.data,
            u = k.timestamp,
            t = m.viewport,
            r,
            w,
            v = z({}, t, {
              width: (r = t == null ? void 0 : t.width) != null ? r : 0,
              height: (w = t == null ? void 0 : t.height) != null ? w : 0,
              x: 0,
              y: 0,
              Kk: t ? t.width * t.height : 0,
            }),
            A = at(v),
            C = m.adView,
            G =
              C.measuringElement && C.containerGeometry
                ? at(C.containerGeometry)
                : at(C.geometry),
            J = at(C.geometry),
            Y = C.reasons.some(Zs),
            I = Y ? Ei : at(C.onScreenGeometry),
            B;
          l && (B = C.percentageInView / 100);
          l && Y && (B = 0);
          return {
            timestamp: u,
            value: {
              ma: "omid",
              oa: G,
              da: A,
              ja: d,
              Z: "omid",
              N: J,
              va: { x: G.left, y: G.top },
              aa: I,
              Ad: B,
            },
          };
        } catch (pc) {
          ih(pc, zh(Error));
          var ja, Pc;
          m =
            (Pc = (ja = pc) == null ? void 0 : ja.message) != null
              ? Pc
              : "An unknown error occurred";
          ja =
            "Error while processing geometryChange event: " +
            JSON.stringify(k.value) +
            "; " +
            m;
          throw Error(ja);
        }
      }),
      kf(1),
      pd()
    );
  }
  function at(a) {
    var b, c, d, e;
    return {
      left: Math.floor((b = a == null ? void 0 : a.x) != null ? b : 0),
      top: Math.floor((c = a == null ? void 0 : a.y) != null ? c : 0),
      width: Math.floor((d = a == null ? void 0 : a.width) != null ? d : 0),
      height: Math.floor((e = a == null ? void 0 : a.height) != null ? e : 0),
    };
  }
  function bt(a, b, c, d) {
    c = c === void 0 ? Xd : c;
    var e = a.queue;
    if (b === null) return gd(new je(20));
    if (!b.validate()) return gd(new je(21));
    var f;
    d = ct(e, b, d).i(
      Q(function (g) {
        var h = g.value;
        g = g.timestamp;
        var k = b.l,
          l = a.l;
        if (k.timeline !== g.timeline) throw new oe();
        g = new xe(g.value - k.now().value + l.now().value, l.timeline);
        return (f = { value: h, timestamp: g });
      })
    );
    return Wd(
      d,
      c.i(
        Q(function () {
          return f;
        })
      )
    ).i(
      R(function (g) {
        return g !== void 0;
      }),
      Q(function (g) {
        return g;
      }),
      W(a.queue, 1)
    );
  }
  function ct(a, b, c) {
    return $s(b, c).i(
      W(a, 1),
      Q(function (d) {
        return {
          timestamp: d.timestamp,
          value: {
            va: { x: d.value.N.left, y: d.value.N.top },
            oa: d.value.aa,
            da: d.value.da,
            ma: d.value.Z,
            ja: d.value.ja,
          },
        };
      })
    );
  }
  var dt = function (a, b, c) {
    this.ra = a;
    this.C = b;
    this.Hb = c;
  };
  q(dt, Hs);
  dt.prototype.mb = function (a, b) {
    var c = b.fb;
    b = bt(this.C, this.ra, this.Hb, b.Ig);
    c = Ks(b, Uq(this.C, c));
    return { ub: a.cb.i(c), lb: {} };
  };
  var et = function (a, b, c) {
    this.ra = a;
    this.C = b;
    this.Wh = c;
  };
  q(et, Hs);
  et.prototype.mb = function (a, b) {
    var c = bt(this.C, this.ra, void 0, b.Ig);
    b = br(this.C, b.ih, this.Wh);
    c = Ks(c, b);
    return { ub: a.cb.i(c), lb: {} };
  };
  function ft(a) {
    if (a.prerendering) return 3;
    var b;
    return (b = {
      visible: 1,
      hidden: 2,
      prerender: 3,
      preview: 4,
      unloaded: 5,
      "": 0,
    }[
      a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""
    ]) != null
      ? b
      : 0;
  }
  function gt(a) {
    var b;
    a.visibilityState
      ? (b = "visibilitychange")
      : a.mozVisibilityState
      ? (b = "mozvisibilitychange")
      : a.webkitVisibilityState && (b = "webkitvisibilitychange");
    return b;
  }
  function ht(a) {
    return a.document.Vi.i(
      Q(function (b) {
        return b === "visible";
      }),
      S(),
      W(a.queue, 1)
    );
  }
  var Vp = ["2026111801"].slice(-1)[0].substring(0, 8);
  function jt(a, b, c) {
    var d;
    return b.i(
      S(),
      U(function (e) {
        return c.i(
          Q(function () {
            if (!d) {
              d = !0;
              try {
                e.next();
              } finally {
                d = !1;
              }
            }
            return !0;
          })
        );
      }),
      T(!1),
      W(a.queue, 1)
    );
  }
  function kt(a) {
    return N(
      gr(
        Q(function (b) {
          return yr(b, a);
        })
      ),
      Aq(),
      Q(function (b) {
        return Math.round(b);
      })
    );
  }
  function lt(a, b, c, d, e) {
    var f = Yr;
    if (f.length > 1)
      for (var g = 0; g < f.length - 1; g++) if (f[g] < f[g + 1]) throw Error();
    g = e.i(
      T(void 0),
      U(function () {
        return c.i(Oq());
      }),
      S(),
      W(a, 1)
    );
    e = e.i(
      T(void 0),
      U(function () {
        return c.i(vs());
      }),
      S(),
      W(a, 1)
    );
    return {
      Wd: d.i(
        T(void 0),
        U(function () {
          return b.i(
            Q(function (h) {
              return { timestamp: h.timestamp, value: !0 };
            }),
            Aq()
          );
        }),
        S(),
        W(a, 1)
      ),
      Xd: d.i(
        T(void 0),
        U(function () {
          return b.i(
            Q(function (h) {
              return { timestamp: h.timestamp, value: h.value === 0 };
            }),
            Aq()
          );
        }),
        S(),
        W(a, 1)
      ),
      Vc: d.i(
        T(void 0),
        U(function () {
          return b.i(Nq(ws, f));
        }),
        S(Rb),
        W(a, 1)
      ),
      Wa: d.i(
        T(void 0),
        U(function () {
          return b.i(
            Nq(kt, f),
            Q(function (h) {
              return h.map(function (k, l) {
                return l > 0 ? k - h[l - 1] : k;
              });
            })
          );
        }),
        S(Rb),
        W(a, 1)
      ),
      Uc: e,
      pb: g.i(S(mr), W(a, 1)),
    };
  }
  function mt(a, b, c) {
    var d = c.i(
      Q(function (e) {
        return { value: e, timestamp: a.l.now() };
      }),
      S(mr)
    );
    return b instanceof O
      ? b.i(
          S(),
          U(function (e) {
            return e
              ? new X({ value: !1, timestamp: a.l.now() }).S(a.queue)
              : d;
          })
        )
      : b.value === !1
      ? d
      : new X(!1);
  }
  function nt(a, b, c, d, e, f, g) {
    var h = Rr;
    b = b instanceof O ? b.i(T(!1), S()) : b;
    var k = !(ah() || $g());
    c = mt(a, c, d);
    a = g.cb.i(xq(a.queue));
    return z({}, h, { Cd: c, kh: e, Lf: k, Gg: b, Fd: a, hh: f });
  }
  function ot(a) {
    a = a.global;
    if (typeof a.__google_lidar_ === "undefined")
      return (a.__google_lidar_ = 1), !1;
    a.__google_lidar_ = Number(a.__google_lidar_) + 1;
    var b = a.__google_lidar_adblocks_count_;
    if (
      typeof b === "number" &&
      b > 0 &&
      ((a = a.__google_lidar_radf_), typeof a === "function")
    )
      try {
        a();
      } catch (c) {}
    return !0;
  }
  function pt(a) {
    var b = a.global;
    b.osdlfm = function () {
      return b.__google_lidar_radf_;
    };
    if (b.__google_lidar_radf_ !== void 0) return Hc;
    b.__google_lidar_adblocks_count_ = 1;
    var c = new Ec();
    b.__google_lidar_radf_ = function () {
      return void c.next(a);
    };
    return c.i(Bg(a.J, 743));
  }
  var qt = function (a) {
      var b = this;
      this.Se = !1;
      this.af = [];
      this.Ze = [];
      a(
        function (c) {
          b.Se = !0;
          b.resolution = c;
          b.evaluate();
        },
        function (c) {
          b.aj = c;
          b.evaluate();
        }
      );
    },
    rt = function (a) {
      return new qt(function (b, c) {
        var d = [],
          e = 0;
        a.forEach(function (f, g) {
          f.then(function (h) {
            d[g] = h;
            ++e === a.length && b(d);
          }).catch(function (h) {
            c(h);
          });
        });
      });
    };
  qt.prototype.evaluate = function () {
    var a = this.resolution,
      b = this.aj;
    if (b !== void 0 || this.Se)
      this.Se &&
        this.af.forEach(function (c) {
          return void c(a);
        }),
        b !== void 0 &&
          this.Ze.forEach(function (c) {
            return void c(b);
          }),
        (this.af = []),
        (this.Ze = []);
  };
  qt.prototype.then = function (a) {
    this.af.push(a);
    this.evaluate();
    return this;
  };
  qt.prototype.catch = function (a) {
    this.Ze.push(a);
    this.evaluate();
    return this;
  };
  var st = function (a) {
    this.children = a;
    this.Pe = !1;
    this.qe = [];
  };
  da.Object.defineProperties(st.prototype, {
    completed: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.Pe;
      },
    },
  });
  st.prototype.complete = function () {
    var a = this;
    this.Pe = !0;
    this.qe.forEach(function (b) {
      return void b(a);
    });
    this.qe.splice(0);
  };
  st.prototype.onComplete = function (a) {
    this.Pe ? a(this) : this.qe.push(a);
  };
  st.prototype.nb = function (a) {
    var b = this.children.map(function (c) {
      return c.nb(a);
    });
    return b.find(function (c) {
      return c !== 2;
    }) === void 0
      ? 2
      : this.completed
      ? 0
      : b.some(function (c) {
          return c === 1;
        })
      ? 1
      : 0;
  };
  var tt = function () {
    var a = F.apply(0, arguments);
    st.call(this, a);
    var b = this;
    this.events = a;
    var c = this.events.length;
    this.events.forEach(function (d) {
      d.onComplete(function () {
        --c === 0 && b.complete();
      });
    });
  };
  q(tt, st);
  tt.prototype.clone = function () {
    return new (Function.prototype.bind.apply(
      tt,
      [null].concat(
        y(
          this.events.map(function (a) {
            return a.clone();
          })
        )
      )
    ))();
  };
  tt.prototype.uf = function (a, b) {
    var c = this;
    if (!this.completed) {
      var d = this.events.find(function (e) {
        return e.nb(a) === 1;
      });
      d !== void 0 &&
        d.uf(a, function () {
          c.completed || b();
        });
    }
  };
  var ut = function (a, b) {
    st.call(this, []);
    this.xe = a;
    this.Gd = Symbol(b);
    this.Wi = a;
  };
  q(ut, st);
  da.Object.defineProperties(ut.prototype, {
    event: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.Gd;
      },
    },
  });
  ut.prototype.clone = function () {
    var a = new ut(this.Wi, this.Gd.description);
    a.Gd = this.Gd;
    return a;
  };
  ut.prototype.nb = function (a) {
    return a !== this.event ? 2 : this.completed || this.xe === 0 ? 0 : 1;
  };
  ut.prototype.uf = function (a, b) {
    this.nb(a) === 1 && (this.xe--, b(), this.xe === 0 && this.complete());
  };
  var vt = function (a) {
    ut.call(this, 1, a);
  };
  q(vt, ut);
  var wt = function (a, b, c) {
    var d = F.apply(3, arguments);
    this.Za = a;
    this.Th = b;
    this.ve = c;
    this.Tc = new Set();
    this.kc = d;
    if (this.Za.C) this.context = this.Za.C;
    else if (this.Za.ra) this.context = this.Za.ra;
    else throw Error("Ka");
    var e = d.reduce(function (k, l) {
      l.subscribedEvents.forEach(function (m) {
        return void k.add(m);
      });
      return k;
    }, new Set());
    e = x(e.values());
    var f = e.next();
    try {
      for (var g = {}; !f.done; g = { Zf: void 0 }, f = e.next()) {
        g.Zf = f.value;
        var h = d.filter(
          (function (k) {
            return function (l) {
              return l.controlledEvents.indexOf(k.Zf) >= 0;
            };
          })(g)
        );
        if (h.length === 0) throw Error("La");
        if (h.length > 1) throw Error("Ma");
      }
    } finally {
      ra(e, f);
    }
  };
  wt.prototype.start = function () {
    var a = this;
    this.kc.forEach(function (b) {
      return void b.start(a.Za);
    });
    this.ve.start(
      this.Za,
      this.bi.bind(this),
      this.Zb.bind(this),
      function () {}
    );
  };
  wt.prototype.dispose = function () {
    var a = this;
    this.ve.dispose();
    this.Tc.forEach(function (b) {
      return void a.Zb(b);
    });
    this.kc.forEach(function (b) {
      return void b.dispose();
    });
  };
  var xt = function (a, b) {
      b = {
        measuringCreativeIds: [].concat(y(a.Tc.values())).map(function (c) {
          return a.context.Ic.getName(c);
        }),
        hasCreativeSourceCompleted: !!a.ve.Td,
        colleagues: a.kc.map(function (c) {
          return {
            name: c.name,
            controlledEvents: c.controlledEvents.map(function (d) {
              var e;
              return (e = d.description) != null ? e : "n/a";
            }),
            subscribedEvents: c.subscribedEvents.map(function (d) {
              var e;
              return (e = d.description) != null ? e : "n/a";
            }),
          };
        }),
        ephemeralCreativeStateChanges: b,
      };
      b = {
        specMajor: 2,
        specMinor: 0,
        specPatch: 0,
        instanceId: a.context.Ic.getName(a.context.Ob),
        timestamp: ze(a.context.l.now(), new xe(0, a.context.l.timeline)),
        mediatorState: b,
      };
      ge(a.context, b);
    },
    yt = function (a, b, c, d, e) {
      var f = {};
      xt(
        a,
        ((f[b] = { events: [{ timestamp: c, description: d, status: e }] }), f)
      );
    };
  wt.prototype.bi = function (a, b, c) {
    var d = this;
    if (!this.Tc.has(a)) {
      var e = this.Th.clone();
      this.Tc.add(a);
      xt(this, {});
      var f = !1,
        g = [];
      this.kc.forEach(function (h) {
        var k = function (l, m, u) {
          var t = d.context.Ic.getName(a),
            r = ze(d.context.l.now(), new xe(0, d.context.l.timeline)),
            w,
            v = (w = l.description) != null ? w : "n/a";
          if (h.controlledEvents.indexOf(l) < 0 || e.nb(l) !== 1)
            return (
              u(!1),
              yt(d, t, r, v, 1),
              new qt(function (C) {
                return void C();
              })
            );
          var A = new qt(function (C) {
            e.uf(l, function () {
              d.kc
                .filter(function (G) {
                  return G.subscribedEvents.indexOf(l) >= 0;
                })
                .forEach(function (G) {
                  return void G.handleEvent(a, l, m);
                });
              C();
            });
          });
          return new qt(function (C) {
            A.then(function () {
              u(!0);
              yt(d, t, r, v, 2);
              C();
            });
          });
        };
        h.He(
          a,
          b,
          c,
          function (l, m, u) {
            return f
              ? k(l, m, u)
              : new qt(function (t) {
                  g.push(function () {
                    k(l, m, u).then(function () {
                      t();
                    });
                  });
                });
          },
          function (l) {
            try {
              d.context.H.M(
                "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=colleague-executed&name=" +
                  l,
                { ha: "GET" }
              ).sendNow();
            } catch (m) {}
          }
        );
      });
      f = !0;
      g.forEach(function (h) {
        return void h();
      });
    }
  };
  wt.prototype.Zb = function (a) {
    this.Tc.delete(a);
    this.kc.forEach(function (b) {
      b.Zb(a);
    });
    xt(this, {});
  };
  var zt = function (a, b) {
      b = b === void 0 ? !1 : b;
      this.key = a;
      this.defaultValue = b;
      this.valueType = "boolean";
    },
    At = function (a, b) {
      b = b === void 0 ? 0 : b;
      this.key = a;
      this.defaultValue = b;
      this.valueType = "number";
    };
  var Bt = {
    considerOmidZOrderOcclusions: [new zt("100006"), !1],
    extraPings: [new At("45362137"), 0],
    extrapolators: [new zt("45377435"), !1],
    rxlidarStatefulBeacons: [new zt("45372163"), !1],
    shouldIgnoreAdChoicesIcon: [new zt("45382077"), !1],
    dedicatedViewableAttributionPing: [new At("45389692"), 0],
    useReachIntegrationPolyfill: [new zt("45407239"), !1],
    useReachIntegrationSharedStorage: [new zt("45407240", !0), !0],
    sendBrowserIdInsteadOfVPID: [new zt("45407241"), !1],
    waitForImpressionColleague: [new zt("45430682"), !1],
    rxInNonrx: [new zt("45642405"), !1],
    addQueryIdToErrorPing: [new zt("45653435"), !1],
    shouldSendExplicitDisplayMeasurablePing: [new zt("45658589"), !1],
    reachUseCreateWorklet: [new zt("45661569"), !1],
    shouldCacheTimeMetricsInLocalStorage: [new zt("45722991", !0), !0],
    omakaseAdStatsResetVersion: [new At("45738539", 2), 2],
  };
  function Ct(a) {
    return Object.entries(Bt).reduce(function (b, c) {
      var d = x(c);
      c = d.next().value;
      var e = x(d.next().value);
      d = e.next().value;
      e = e.next().value;
      var f;
      if (a == null) var g = void 0;
      else
        a: {
          var h = a.cg[d.key];
          if (d.valueType === "proto") {
            try {
              var k = JSON.parse(h);
              if (Array.isArray(k)) {
                g = k;
                break a;
              }
            } catch (l) {}
            g = d.defaultValue;
          } else g = typeof h === typeof d.defaultValue ? h : d.defaultValue;
        }
      b[c] = (f = g) != null ? f : e;
      return b;
    }, {});
  }
  var qn = function (a) {
    Lo.call(this, a);
  };
  q(qn, Lo);
  var Dt = function (a) {
    return El(an(a, 3));
  };
  qn.prototype.Ce = function () {
    return wn(this, 4, !0);
  };
  var Et = function (a) {
    return sl(an(a, 5));
  };
  qn.prototype.Dd = function () {
    return xn(this, 6);
  };
  var Ft = function (a) {
    return wn(a, 7);
  };
  qn.W =
    "ads.branding.measurement.client.serving.integrations.active_view.ActiveViewMetadata";
  var Gt = [0, zo, -2, yo, -1, vo, yo];
  qn.prototype.O = No(Gt);
  var Ht = function (a) {
    Lo.call(this, a);
  };
  q(Ht, Lo);
  Ht.prototype.Vg = function (a) {
    return An(this, 5, a);
  };
  Ht.prototype.getType = function () {
    var a = a === void 0 ? 0 : a;
    var b = wl(an(this, 6));
    return b != null ? b : a;
  };
  var It = Oo(Ht);
  Ht.W = "ads.geo.GeoTargetMessage";
  var Jt = function (a) {
    Lo.call(this, a);
  };
  q(Jt, Lo);
  n = Jt.prototype;
  n.hg = function () {
    return yn(this, 2);
  };
  n.ig = function () {
    return El(an(this, 2));
  };
  n.Ce = function () {
    return wn(this, 3, !0);
  };
  n.jg = function () {
    return sn(this, Ht, 4);
  };
  n.Tg = function (a) {
    return vn(this, Ht, 4, a);
  };
  n.lg = function () {
    return hn(this, 7, wl);
  };
  n.Jf = function (a) {
    return Dn(this, 7, a);
  };
  n.Ug = function (a) {
    return zn(this, 9, a);
  };
  n.Dd = function () {
    return xn(this, 10);
  };
  Jt.W =
    "ads.branding.measurement.client.serving.integrations.reach.ReachMetadata";
  var Kt = [0, vo, -3];
  var Lt = [
    0,
    Co,
    -4,
    Eo,
    yo,
    vo,
    ro,
    Co,
    ro,
    Co,
    vo,
    Co,
    -1,
    Kt,
    Do,
    uo,
    Co,
    to,
    -1,
    vo,
    -1,
    to,
    ro,
    [0, to, vo, -1, Eo, ro, to],
    qo,
    Co,
    [0, vo, -9, yo],
    yo,
    ro,
    [0, Eo, -3],
    Kt,
  ];
  Ht.prototype.O = No(Lt);
  var Mt = [0, zo, -1, yo, Lt, wo, -1, Fo, vo, yo, vo];
  Jt.prototype.O = No(Mt);
  var Nt = function (a) {
    Lo.call(this, a);
  };
  q(Nt, Lo);
  Nt.prototype.hg = function () {
    return yn(this, 1);
  };
  Nt.prototype.ig = function () {
    return El(an(this, 1));
  };
  Nt.prototype.Dd = function () {
    return xn(this, 2);
  };
  Nt.W =
    "ads.branding.measurement.client.serving.integrations.shared.SharedMetadata";
  var Ot = [0, zo, vo];
  Nt.prototype.O = No(Ot);
  var Pt = function (a) {
    Lo.call(this, a);
  };
  q(Pt, Lo);
  var Qt = function (a) {
    return sn(a, Jt, 1);
  };
  Pt.W = "ads.branding.measurement.client.serving.IntegratorMetadata";
  var Rt = [0, Mt, Gt, Ot];
  Pt.prototype.O = No(Rt);
  var St = Mo(Pt, Rt);
  var Tt = function () {
    this.cg = {};
  };
  var Ut = function () {
    this.Vf = !1;
    this.Sf = new Map();
  };
  Ut.prototype.start = function (a, b, c, d) {
    var e = this;
    if (this.Td === void 0 && a.C) {
      var f = a.C;
      this.Rf = d;
      c = !this.Vf && ot(f);
      d = this.Vf ? Hc : pt(f);
      d = Cp(f, d);
      this.Td = (
        c
          ? Hc
          : d.i(
              Q(function (g) {
                var h = h === void 0 ? Symbol() : h;
                return Object.freeze({ Ob: h, element: new X(g).S(f.queue) });
              }),
              up()
            )
      ).subscribe(function (g) {
        var h = g.Ob;
        e.Sf.set(h, g);
        g.element.i(Ye(1)).subscribe(function (k) {
          var l = rp(k, "data-google-av-flags"),
            m = new Tt();
          if (l !== null)
            try {
              var u = JSON.parse(l)[0];
              l = "";
              for (var t = 0; t < u.length; t++)
                l += String.fromCharCode(
                  u.charCodeAt(t) ^
                    "\u0003\u0007\u0003\u0007\b\u0004\u0004\u0006\u0005\u0003".charCodeAt(
                      t % 10
                    )
                );
              m.cg = JSON.parse(l);
            } catch (w) {}
          m = Ct(m);
          k = rp(k, "data-google-av-ufs-integrator-metadata");
          a: {
            if (k !== null)
              try {
                var r = St(k);
                break a;
              } catch (w) {}
            r = new Pt();
          }
          b(h, r, m);
        });
      });
      c && this.dispose();
      a.ra && Tf(a.ra);
    }
  };
  Ut.prototype.dispose = function () {
    var a, b;
    (a = this.Td) == null || (b = a.unsubscribe) == null || b.call(a);
    this.Td = void 0;
    var c;
    (c = this.Rf) == null || c.call(this);
    this.Rf = void 0;
  };
  var Vt = function (a) {
    Lo.call(this, a);
  };
  q(Vt, Lo);
  Vt.prototype.Vg = function (a) {
    return Cn(this, 2, a);
  };
  Vt.prototype.Mb = function (a) {
    return Bn(this, 3, a);
  };
  Vt.prototype.Lb = function (a) {
    return Bn(this, 4, a);
  };
  Vt.W =
    "ads.branding.measurement.client.frontend.integrations.active_view.OmakaseStatusMessage";
  var Wt = [0, Eo, -1, zo, -3];
  Vt.prototype.O = No(Wt);
  var Xt = (function (a) {
    return function (b) {
      return lo(b, a);
    };
  })(Wt);
  var Yt = function (a) {
      if (a.wb && typeof a.wb == "function") return a.wb();
      if (
        (typeof Map !== "undefined" && a instanceof Map) ||
        (typeof Set !== "undefined" && a instanceof Set)
      )
        return Array.from(a.values());
      if (typeof a === "string") return a.split("");
      if (Ra(a)) {
        for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
        return b;
      }
      b = [];
      c = 0;
      for (d in a) b[c++] = a[d];
      return b;
    },
    Zt = function (a) {
      if (a.De && typeof a.De == "function") return a.De();
      if (!a.wb || typeof a.wb != "function") {
        if (typeof Map !== "undefined" && a instanceof Map)
          return Array.from(a.keys());
        if (!(typeof Set !== "undefined" && a instanceof Set)) {
          if (Ra(a) || typeof a === "string") {
            var b = [];
            a = a.length;
            for (var c = 0; c < a; c++) b.push(c);
            return b;
          }
          b = [];
          c = 0;
          for (var d in a) b[c++] = d;
          return b;
        }
      }
    },
    $t = function (a, b, c) {
      if (a.forEach && typeof a.forEach == "function") a.forEach(b, c);
      else if (Ra(a) || typeof a === "string")
        Array.prototype.forEach.call(a, b, c);
      else
        for (var d = Zt(a), e = Yt(a), f = e.length, g = 0; g < f; g++)
          b.call(c, e[g], d && d[g], a);
    };
  function Tp(a) {
    this.Ra = this.Tb = this.gb = "";
    this.sc = null;
    this.tb = this.La = "";
    this.pa = this.wi = !1;
    if (a instanceof Tp) {
      this.pa = a.pa;
      au(this, a.gb);
      var b = a.Tb;
      bu(this);
      this.Tb = b;
      b = a.Ra;
      bu(this);
      this.Ra = b;
      cu(this, a.sc);
      b = a.La;
      bu(this);
      this.La = b;
      du(this, a.sa.clone());
      a = a.tb;
      bu(this);
      this.tb = a;
    } else
      a && (b = String(a).match(Ii))
        ? ((this.pa = !1),
          au(this, b[1] || "", !0),
          (a = b[2] || ""),
          bu(this),
          (this.Tb = eu(a)),
          (a = b[3] || ""),
          bu(this),
          (this.Ra = eu(a, !0)),
          cu(this, b[4]),
          (a = b[5] || ""),
          bu(this),
          (this.La = eu(a, !0)),
          du(this, b[6] || "", !0),
          (a = b[7] || ""),
          bu(this),
          (this.tb = eu(a)))
        : ((this.pa = !1), (this.sa = new fu(null, this.pa)));
  }
  Tp.prototype.toString = function () {
    var a = [],
      b = this.gb;
    b && a.push(gu(b, hu, !0), ":");
    var c = this.Ra;
    if (c || b == "file")
      a.push("//"),
        (b = this.Tb) && a.push(gu(b, hu, !0), "@"),
        a.push(
          encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")
        ),
        (c = this.sc),
        c != null && a.push(":", String(c));
    if ((c = this.La))
      this.Ra && c.charAt(0) != "/" && a.push("/"),
        a.push(gu(c, c.charAt(0) == "/" ? iu : ju, !0));
    (c = this.sa.toString()) && a.push("?", c);
    (c = this.tb) && a.push("#", gu(c, ku));
    return a.join("");
  };
  Tp.prototype.resolve = function (a) {
    var b = this.clone(),
      c = !!a.gb;
    c ? au(b, a.gb) : (c = !!a.Tb);
    if (c) {
      var d = a.Tb;
      bu(b);
      b.Tb = d;
    } else c = !!a.Ra;
    c ? ((d = a.Ra), bu(b), (b.Ra = d)) : (c = a.sc != null);
    d = a.La;
    if (c) cu(b, a.sc);
    else if ((c = !!a.La)) {
      if (d.charAt(0) != "/")
        if (this.Ra && !this.La) d = "/" + d;
        else {
          var e = b.La.lastIndexOf("/");
          e != -1 && (d = b.La.slice(0, e + 1) + d);
        }
      e = d;
      if (e == ".." || e == ".") d = "";
      else if (e.indexOf("./") != -1 || e.indexOf("/.") != -1) {
        d = e.lastIndexOf("/", 0) == 0;
        e = e.split("/");
        for (var f = [], g = 0; g < e.length; ) {
          var h = e[g++];
          h == "."
            ? d && g == e.length && f.push("")
            : h == ".."
            ? ((f.length > 1 || (f.length == 1 && f[0] != "")) && f.pop(),
              d && g == e.length && f.push(""))
            : (f.push(h), (d = !0));
        }
        d = f.join("/");
      } else d = e;
    }
    c ? (bu(b), (b.La = d)) : (c = a.sa.toString() !== "");
    c ? du(b, a.sa.clone()) : (c = !!a.tb);
    c && ((a = a.tb), bu(b), (b.tb = a));
    return b;
  };
  Tp.prototype.clone = function () {
    return new Tp(this);
  };
  var au = function (a, b, c) {
      bu(a);
      a.gb = c ? eu(b, !0) : b;
      a.gb && (a.gb = a.gb.replace(/:$/, ""));
    },
    cu = function (a, b) {
      bu(a);
      if (b) {
        b = Number(b);
        if (isNaN(b) || b < 0) throw Error("Na`" + b);
        a.sc = b;
      } else a.sc = null;
    },
    du = function (a, b, c) {
      bu(a);
      b instanceof fu
        ? ((a.sa = b), a.sa.kf(a.pa))
        : (c || (b = gu(b, lu)), (a.sa = new fu(b, a.pa)));
    };
  Tp.prototype.getQuery = function () {
    return this.sa.toString();
  };
  var Up = function (a, b, c) {
    bu(a);
    a.sa.set(b, c);
  };
  Tp.prototype.removeParameter = function (a) {
    bu(this);
    this.sa.remove(a);
    return this;
  };
  var bu = function (a) {
    if (a.wi) throw Error("Oa");
  };
  Tp.prototype.kf = function (a) {
    this.pa = a;
    this.sa && this.sa.kf(a);
  };
  var eu = function (a, b) {
      return a
        ? b
          ? decodeURI(a.replace(/%25/g, "%2525"))
          : decodeURIComponent(a)
        : "";
    },
    gu = function (a, b, c) {
      return typeof a === "string"
        ? ((a = encodeURI(a).replace(b, mu)),
          c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")),
          a)
        : null;
    },
    mu = function (a) {
      a = a.charCodeAt(0);
      return "%" + ((a >> 4) & 15).toString(16) + (a & 15).toString(16);
    },
    hu = /[#\/\?@]/g,
    ju = /[#\?:]/g,
    iu = /[#\?]/g,
    lu = /[#\?@]/g,
    ku = /#/g,
    fu = function (a, b) {
      this.Y = this.L = null;
      this.ia = a || null;
      this.pa = !!b;
    },
    nu = function (a) {
      a.L ||
        ((a.L = new Map()),
        (a.Y = 0),
        a.ia &&
          Ji(a.ia, function (b, c) {
            a.add(decodeURIComponent(b.replace(/\+/g, " ")), c);
          }));
    };
  fu.prototype.add = function (a, b) {
    nu(this);
    this.ia = null;
    a = ou(this, a);
    var c = this.L.get(a);
    c || this.L.set(a, (c = []));
    c.push(b);
    this.Y = Gb(this.Y) + 1;
    return this;
  };
  fu.prototype.remove = function (a) {
    nu(this);
    a = ou(this, a);
    return this.L.has(a)
      ? ((this.ia = null),
        (this.Y = Gb(this.Y) - this.L.get(a).length),
        this.L.delete(a))
      : !1;
  };
  fu.prototype.clear = function () {
    this.L = this.ia = null;
    this.Y = 0;
  };
  fu.prototype.isEmpty = function () {
    nu(this);
    return this.Y == 0;
  };
  var pu = function (a, b) {
    nu(a);
    b = ou(a, b);
    return a.L.has(b);
  };
  n = fu.prototype;
  n.forEach = function (a, b) {
    nu(this);
    this.L.forEach(function (c, d) {
      c.forEach(function (e) {
        a.call(b, e, d, this);
      }, this);
    }, this);
  };
  n.De = function () {
    nu(this);
    for (
      var a = Array.from(this.L.values()),
        b = Array.from(this.L.keys()),
        c = [],
        d = 0;
      d < b.length;
      d++
    )
      for (var e = a[d], f = 0; f < e.length; f++) c.push(b[d]);
    return c;
  };
  n.wb = function (a) {
    nu(this);
    var b = [];
    if (typeof a === "string")
      pu(this, a) && (b = b.concat(this.L.get(ou(this, a))));
    else {
      a = Array.from(this.L.values());
      for (var c = 0; c < a.length; c++) b = b.concat(a[c]);
    }
    return b;
  };
  n.set = function (a, b) {
    nu(this);
    this.ia = null;
    a = ou(this, a);
    pu(this, a) && (this.Y = Gb(this.Y) - this.L.get(a).length);
    this.L.set(a, [b]);
    this.Y = Gb(this.Y) + 1;
    return this;
  };
  n.get = function (a, b) {
    if (!a) return b;
    a = this.wb(a);
    return a.length > 0 ? String(a[0]) : b;
  };
  n.toString = function () {
    if (this.ia) return this.ia;
    if (!this.L) return "";
    for (var a = [], b = Array.from(this.L.keys()), c = 0; c < b.length; c++) {
      var d = b[c],
        e = encodeURIComponent(String(d));
      d = this.wb(d);
      for (var f = 0; f < d.length; f++) {
        var g = e;
        d[f] !== "" && (g += "=" + encodeURIComponent(String(d[f])));
        a.push(g);
      }
    }
    return (this.ia = a.join("&"));
  };
  n.clone = function () {
    var a = new fu();
    a.ia = this.ia;
    this.L && ((a.L = new Map(this.L)), (a.Y = this.Y));
    return a;
  };
  var ou = function (a, b) {
    b = String(b);
    a.pa && (b = b.toLowerCase());
    return b;
  };
  fu.prototype.kf = function (a) {
    a &&
      !this.pa &&
      (nu(this),
      (this.ia = null),
      this.L.forEach(function (b, c) {
        var d = c.toLowerCase();
        c != d &&
          (this.remove(c),
          this.remove(d),
          b.length > 0 &&
            ((this.ia = null),
            this.L.set(ou(this, d), Qb(b)),
            (this.Y = Gb(this.Y) + b.length)));
      }, this));
    this.pa = a;
  };
  fu.prototype.extend = function (a) {
    for (var b = 0; b < arguments.length; b++)
      $t(
        arguments[b],
        function (c, d) {
          this.add(d, c);
        },
        this
      );
  };
  function qu(a, b) {
    var c = new Vt().Mb(b.name).Vg(1).Lb(b.message);
    c = Bn(c, 5, b.stack);
    c = Bn(c, 6, String(a.J.rf));
    switch (b.name) {
      case "SecurityError":
        Cn(c, 1, 2);
        break;
      case "QuotaExceededError":
        Cn(c, 1, 1);
        break;
      case "SyntaxError":
        Cn(c, 1, 3);
        break;
      case "TypeError":
        Cn(c, 1, 4);
        break;
      case "InvalidStateError":
        Cn(c, 1, 7);
        break;
      case "AbortError":
        Cn(c, 1, 6);
        break;
      case "NotSupportedError":
        Cn(c, 1, 8);
        break;
      case "IframeError":
        Cn(c, 1, 5);
        break;
      case "LocksApiUnavailableError":
        Cn(c, 1, 9);
        break;
      default:
        Cn(c, 1, 0);
    }
    b = new Tp("https://pagead2.googlesyndication.com/pagead/gen_204");
    Up(b, "id", "av-js");
    Up(b, "type", "omakase");
    Up(b, "proto", ai(Xt(c)));
    Up(b, "v", Vp);
    a.H.M(b.toString(), { ha: "GET" }).sendNow();
  }
  var ru = function (a) {
    this.C = a;
  };
  n = ru.prototype;
  n.reportError = function (a) {
    qu(this.C, a);
  };
  n.setItem = function (a, b) {
    try {
      this.hasLocalStorageAccess() && this.C.localStorage.setItem(a, b);
    } catch (c) {
      this.reportError(c);
    }
  };
  n.getItem = function (a) {
    try {
      if (this.hasLocalStorageAccess()) return this.C.localStorage.getItem(a);
    } catch (b) {
      this.reportError(b);
    }
    return null;
  };
  n.hasLocalStorageAccess = function () {
    return hp(this.C);
  };
  n.Lc = function () {
    return this.C.Lc();
  };
  n.gf = function (a, b) {
    var c = this;
    return Ba(function (d) {
      return d.yield(c.C.gf(a, b), 0);
    });
  };
  n.performExclusiveLockedOperation = function (a, b) {
    var c = this,
      d;
    return Ba(function (e) {
      if (e.u == 1) {
        if (!c.Lc()) return b(), e.ba(0);
        e.Kb(3);
        return e.yield(c.C.gf(a, b), 5);
      }
      if (e.u != 3) return e.Pc(0);
      d = e.rb();
      c.reportError(d);
      e.Db();
    });
  };
  var su = function (a) {
    Lo.call(this, a);
  };
  q(su, Lo);
  var tu = function (a, b) {
    return Bn(a, 1, b);
  };
  su.W = "contentads.bow.rendering.client.TurtleDoveReportingData";
  su.prototype.O = No([0, zo, vo, zo, -5, Eo, zo, -4]);
  function uu() {
    var a = Vg();
    return a
      ? Ob(
          "AmazonWebAppPlatform;Android TV;Apple TV;AppleTV;BRAVIA;BeyondTV;Freebox;GoogleTV;HbbTV;LongTV;MiBOX;MiTV;NetCast.TV;Netcast;Opera TV;PANASONIC;POV_TV;SMART-TV;SMART_TV;SWTV;Smart TV;SmartTV;TV Store;UnionTV;Version/8.0 Safari/601.1 WPE;WebOS".split(
            ";"
          ),
          function (b) {
            return cb(a, b);
          }
        ) ||
        (cb(a, "OMI/") && !cb(a, "XiaoMi/"))
        ? !0
        : cb(a, "Presto") &&
          cb(a, "Linux") &&
          !cb(a, "X11") &&
          !cb(a, "Android") &&
          !cb(a, "Mobi")
      : !1;
  }
  var Rr = Object.freeze({ eh: 1e3, ze: 0.5, Ue: 0.3 }),
    Yr = Object.freeze([1, 0.75, Rr.ze, Rr.Ue, 0]),
    vu = function (a, b, c, d, e, f, g) {
      this.provider = a;
      this.jc = b;
      this.bc = c;
      this.Dc = d;
      this.pd = e;
      this.qd = f;
      this.ke = g;
      this.name = "rxlidar";
      this.Fi = new id();
      this.controlledEvents = [];
      this.subscribedEvents = [];
      this.we = new id();
      this.Ta = new id();
      this.controlledEvents.push(this.Dc, this.pd, this.qd);
      this.subscribedEvents.push(this.bc);
    };
  n = vu.prototype;
  n.start = function (a) {
    if (this.Fe === void 0 && a.C) {
      var b;
      if ((b = this.jc) != null) var c = b;
      else {
        b = a.C;
        var d = (c = a.ra) != null ? c : null;
        c = {
          Sh: 0.01,
          Ii: vf(b.l, 36e5),
          Hb: b.l.Ja(100).i(W(b.queue, 1)),
          ra: d,
        };
      }
      this.jc = c;
      a = a.C;
      this.Fe = wu(
        a,
        this.we.i(W(a.queue, 1)),
        this.jc.Sh,
        this.jc.Ii,
        this.jc.Hb,
        this.jc.ra,
        this.Ta.i(T(!1), W(a.queue, 1)),
        this.Dc,
        this.pd,
        this.qd,
        this.ke
      ).subscribe(this.Fi);
    }
  };
  n.dispose = function () {
    this.we.complete();
    this.Ta.complete();
    var a;
    (a = this.Fe) == null || a.unsubscribe();
    this.Fe = void 0;
  };
  n.He = function (a, b, c, d, e) {
    if (!en(b, 2) || sn(b, qn, 2).Ce()) {
      this.we.next(
        z({}, this.provider.Sf.get(a), {
          metadata: b,
          experimentState: c,
          Vk: a,
          ab: d,
        })
      );
      var f, g;
      e((g = (f = sn(b, qn, 2)) == null ? void 0 : f.Dd()) != null ? g : -1);
    }
  };
  n.Zb = function () {};
  n.handleEvent = function (a, b) {
    b === this.bc && (this.Ta.next(!0), this.Ta.complete());
  };
  function wu(a, b, c, d, e, f, g, h, k, l, m) {
    var u = ht(a).i(
        Q(function (r) {
          return !r;
        })
      ),
      t = new Is(a, [
        new Os(a, Yr),
        new Ns(a, e),
        new et(f, a, Yr),
        new dt(f, a, e),
        new Ys(a, e),
      ]);
    return Fp(
      a,
      b,
      function (r, w) {
        var v = us(r, w.element),
          A = v.wa,
          C = v.Ec,
          G = v.te,
          J = v.xf,
          Y = v.Lh,
          I = v.Ab,
          B = v.ui,
          ja = v.Me,
          Pc = v.Qe,
          pc = v.fb,
          Ad = v.ua,
          Ta = v.Bj,
          Mg = v.Cb;
        v = v.Te;
        var Ng,
          eb = (Ng = Dt(rn(w.metadata))) != null ? Ng : "",
          fv = Ft(rn(w.metadata));
        Ng = tu(new su(), atob(eb)).hb();
        eb = new X(w.experimentState).S(r.queue);
        var gv = new X(new xf(r, new Rg(r))),
          hv = new X(!1).S(r.queue),
          Se = eb.i(
            Q(function (D) {
              return D.shouldIgnoreAdChoicesIcon;
            })
          ),
          Ua = I.i(
            Ue(B),
            Q(function (D) {
              var Za = x(D);
              D = Za.next().value;
              Za = Za.next().value;
              (D = D || Za) ||
                ((D =
                  (cb(Vg(), "CrKey") &&
                    !(cb(Vg(), "CrKey") && cb(Vg(), "SmartSpeaker"))) ||
                  cb(Vg(), "PlayStation") ||
                  cb(Vg(), "Roku") ||
                  uu() ||
                  cb(Vg(), "Xbox")) ||
                  ((D = Vg()),
                  (D =
                    cb(D, "AppleTV") ||
                    cb(D, "Apple TV") ||
                    cb(D, "CFNetwork") ||
                    cb(D, "tvOS"))),
                D ||
                  ((D = Vg()),
                  (D = cb(D, "sdk_google_atv_x86") || cb(D, "Android TV"))));
              return D;
            })
          );
        B = new Ds(r, w, Y, I, pc, Se);
        Se = eb.i(
          Q(function (D) {
            return D.considerOmidZOrderOcclusions;
          })
        );
        var Sc,
          Ab = (Sc = Et(rn(w.metadata))) != null ? Sc : !1;
        Sc = t.mb(B, { Ab: I, ih: Ab, fb: pc, Ig: Se });
        var fb = Sc.ub,
          Te = Sc.lb;
        Sc = Te.We;
        Se = Te.Xe;
        Te = Te.pf;
        Ab = new X(Ab).S(r.queue);
        var Tc = nt(r, Pc, Ua, u, Ta, Ab, B);
        Ta = ds(r.queue, r.l, fb, Tc);
        Ua = lt(r.queue, Ta.Ia.sf, Ta.Ia.visible, Ta.mf, Ta.hd);
        Ab = ss(r.queue, r.l, Ta.hd, Ta.Ia.ja, Ta.Ia.visible);
        fb = Hr(r.queue, r.l, fb, Tc);
        Tc = Xr(r.l, r.queue, fb.Ia.sf, fb.Ia.visible, fb.mf, fb.hd);
        var Og = { be: Qr(r.queue, r.l, fb.hd, Tc.Uc) },
          fj = eb.i(
            Q(function (D) {
              return D.extrapolators;
            }),
            T(!1)
          );
        fb = wq(
          r.queue,
          fj,
          z({}, fb.Ia, Tc, Og),
          z({}, Ta.Ia, {
            be: xr(r, Ab),
            Vc: xr(r, Ua.Vc),
            Wa: xr(r, Ua.Wa),
            Uc: xr(r, Ua.Uc),
            pb: Ua.pb.i(
              Q(function (D) {
                return new wr(r.l, D);
              })
            ),
            Wd: xr(r, Ua.Wd),
            Xd: xr(r, Ua.Xd),
          })
        );
        Ua = fr(r, d.i(Xe("t")));
        Ab = (f !== null && f.validate() ? f.kj : Xd).i(W(r.queue, 1), Xe("u"));
        Ua = ae(Ua, Ab);
        var Xn = Ua.i(
          R(function (D) {
            return D !== null;
          })
        );
        Ab = eb
          .i(
            Q(function (D) {
              return D.shouldCacheTimeMetricsInLocalStorage && fv;
            }),
            S(),
            W(r.queue, 1)
          )
          .i(
            Q(function (D) {
              D && xu(r);
              return (
                D &&
                hp(r, function (Za) {
                  qu(r, Za);
                }) &&
                !r.Bb
              );
            }),
            S(),
            W(r.queue, 1)
          );
        Tc = eb.i(
          Q(function (D) {
            return D.omakaseAdStatsResetVersion;
          }),
          S(),
          W(r.queue, 1)
        );
        var jv = r.l.Ja(4e3).i(
          Ue(u),
          R(function (D) {
            D = x(D);
            D.next();
            return !D.next().value;
          }),
          Q(function (D) {
            return x(D).next().value;
          }),
          W(r.queue, 1)
        );
        Og = Ab.i(
          U(function (D) {
            return D ? Wd(Xn, jv) : Xn;
          }),
          S(),
          W(r.queue, 1)
        );
        fj = jt(r, fb.ja, Og);
        var Yn = yu(r, B, A),
          mv = zu(r, Ua, w.element),
          nv = Yn.zh.i(T({ x: 0, y: 0 })),
          ov = eb.i(
            Q(function (D) {
              return D.rxlidarStatefulBeacons;
            }),
            T(!1),
            S(),
            qf(function (D) {
              Ph = D;
            }),
            W(r.queue, 1)
          ),
          Zn = ja.i(
            Q(function (D) {
              return D === 40 || D === 41 || D === 42;
            })
          ),
          pv = eb.i(
            Q(function (D) {
              return D.waitForImpressionColleague;
            }),
            T(!1),
            S(),
            W(r.queue, 1)
          ),
          qv = b.i(
            Q(function (D) {
              var Za;
              return D.experimentState.addQueryIdToErrorPing
                ? (Za = sn(D.metadata, Nt, 3)) == null
                  ? void 0
                  : Za.ig()
                : void 0;
            })
          );
        return z(
          {},
          {
            H: new X(r.H),
            dc: new X("lidar2"),
            sj: new X("lidartos"),
            Dh: new X(Vp),
            ke: new X(m),
            re: new X(r.validate() ? null : new ke()),
            Hh: new X(Ai(r.document)),
            ca: new X(Zp),
            ye: Ua,
            dh: Ua,
            Mk: fj,
            Kc: g,
            Aj: pv,
            Ji: Og,
            lf: Ab,
            ej: Tc,
            ab: new X(w.ab),
            Dc: new X(h),
            pd: new X(k),
            qd: new X(l),
            Kh: new X(r.Bb ? 1 : void 0),
            Mh: new X(r.Eh ? 1 : void 0),
            Ab: I,
            Cb: Mg,
            vf: new X(Ng),
            tc: Mg.i(
              R(function (D) {
                return D;
              }),
              Q(function () {
                return r.tc.bind(r);
              })
            ),
            We: Sc.i(W(r.queue, 1)),
            Xe: Se.i(W(r.queue, 1)),
            Xh: eb.i(
              Q(function (D) {
                return D.extraPings;
              })
            ),
            ug: ov,
            hi: new X(!1).S(r.queue),
            ah: hv,
            Te: v,
            ti: Zn,
            ii: eb.i(
              Q(function (D) {
                return D.dedicatedViewableAttributionPing;
              })
            ),
            Yh: gv,
            bh: new X(Ph && new Oh(r).R({ ha: "GET" })),
            nj: new X(
              ((Number(w.experimentState.useReachIntegrationSharedStorage) <<
                (0 + Number(w.experimentState.useReachIntegrationPolyfill))) <<
                (1 + Number(w.experimentState.sendBrowserIdInsteadOfVPID))) <<
                2
            ),
            Jh: w.element.i(
              Q(function (D) {
                return D !== null;
              })
            ),
            zb: Ad,
            tj: Ad,
            te: G.i(T([])),
            xf: J.i(T([])),
            fi: G.i(
              Q(function (D) {
                return D.length > 0 ? !0 : null;
              }),
              T(null),
              S()
            ),
            Ec: C.i(T([]), W(r.queue, 1)),
            pk: eb,
            shouldSendExplicitDisplayMeasurablePing: eb.i(
              Q(function (D) {
                return D.shouldSendExplicitDisplayMeasurablePing;
              })
            ),
            wa: A,
            Gc: B.Gc,
            Me: ja.i(T(0), W(r.queue, 1)),
            Gi: Y,
            fb: pc.i(T(0), W(r.queue, 1)),
            Rb: Zn.i(
              Q(function (D) {
                return D ? uq : Yp;
              })
            ),
            zc: new X(vq),
            Qe: Pc,
            wg: B.Rc.i(xq(r.queue)),
            yf: B.yf,
          },
          fb,
          {
            wd: Dd([fb.wd, nv]).i(
              Q(function (D) {
                var Za = x(D);
                D = Za.next().value;
                Za = Za.next().value;
                return Hi(D, Za);
              }),
              S(Fi)
            ),
          },
          Yn,
          {
            jd: ei(r),
            gi: mv,
            pf: Te,
            Zd: Ta.Ia.Zd,
            Fh: new X(new oq()),
            escapedQueryId: qv,
          }
        );
      },
      Xp(
        a,
        "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=error&bin=" +
          m +
          "&v=" +
          Vp,
        c
      ),
      bq(cq(dq(), nq), Hp, $p, Sp(new ru(a)))
    );
  }
  function yu(a, b, c) {
    var d = d === void 0 ? Oa : d;
    var e, f;
    d =
      ((e = d.performance) == null
        ? void 0
        : (f = e.timing) == null
        ? void 0
        : f.navigationStart) || 0;
    return z({}, { xh: new X(d), wh: Lq(a, b) }, Kq(a, b, c));
  }
  function zu(a, b, c) {
    return b.i(
      R(function (d) {
        return d !== null;
      }),
      U(function () {
        return c;
      }),
      Q(function (d) {
        var e = wp(a);
        return e.length > 0 && e.indexOf(d) >= 0;
      }),
      Q(function (d) {
        return !d;
      })
    );
  }
  function xu(a) {
    if (a.Bb) {
      var b = Error();
      b.name = "IframeError";
      b.message = "Failure: Omakase is running in cross origin context.";
      qu(a, b);
    }
    a.Lc() ||
      ((b = Error()),
      (b.name = "LocksApiUnavailableError"),
      (b.message = "Failure: Web Locks API is not present"),
      qu(a, b));
  }
  var Au = function (a) {
    var b = b === void 0 ? [] : b;
    var c = c === void 0 ? [a] : c;
    this.bc = a;
    this.subscribedEvents = b;
    this.controlledEvents = c;
    this.name = "impression";
    this.Je = new Map();
  };
  n = Au.prototype;
  n.start = function (a) {
    this.Za = a;
  };
  n.dispose = function () {
    this.Je.clear();
  };
  n.He = function (a, b, c, d) {
    if ((b = this.Za)) (c = new Bu(b, c, this.bc, d)), this.Je.set(a, c);
  };
  n.Zb = function (a) {
    this.Je.delete(a);
  };
  n.handleEvent = function () {};
  var Bu = function (a, b, c, d) {
    var e = this;
    this.context = a;
    this.bc = c;
    this.gh = function () {};
    this.tg = [];
    this.rg = "&avradf=1";
    this.sg = rt([]);
    this.Ta = new id();
    c = a.ra;
    var f = c !== null && (c == null ? void 0 : c.validate()),
      g,
      h = (g = a.C) == null ? void 0 : g.queue;
    this.Ta.i(T(!b.waitForImpressionColleague), W(h, 1));
    this.pj = f
      ? c == null
        ? void 0
        : c.qg.i(Ye(1), Xe(!0), T(!1))
      : new X(!0).S(h);
    this.gh = function (k, l) {
      e.Ta.next(!0);
      e.Ta.complete();
      Dd([e.Ta, e.pj]).subscribe(function (m) {
        var u = x(m);
        m = u.next().value;
        u = u.next().value;
        if (!u) return Xd;
        m && u && d(e.bc, k, l);
        return !0;
      });
    };
    this.init(a.C);
  };
  Bu.prototype.init = function (a) {
    var b = this;
    this.Zc = a.global.document;
    this.tg.push(Cu(this));
    var c = {};
    this.sg = rt(this.tg);
    this.sg.then(function () {
      b.rg = "&vis=" + ft(b.Zc) + "&uach=0&ms=0";
      c.paramString = b.rg;
      c.view_type = "DELAYED_IMPRESSION";
      b.gh(c, function () {});
    });
  };
  var Cu = function (a) {
    return new qt(function (b) {
      var c = gt(a.Zc);
      if (c)
        if (ft(a.Zc) === 3) {
          var d = function () {
            var e = a.Zc;
            typeof e.removeEventListener === "function" &&
              e.removeEventListener(c, d, !1);
            b(!0);
          };
          Lh(a.Zc, c, d);
        } else b(!0);
    });
  };
  function Du(a) {
    var b = fi(a);
    return b
      ? b.i(
          Q(function (c) {
            var d;
            c =
              (d = un(c).find(function (f) {
                return El(an(f, 1)) === "Google Chrome";
              })) == null
                ? void 0
                : El(an(d, 2));
            if (!c) return !1;
            var e;
            return (
              ((e = x(
                c.split(".").map(function (f) {
                  return Number(f);
                })
              ).next().value) != null
                ? e
                : 0) >= 121
            );
          })
        )
      : Uh.S(a.queue);
  }
  function Eu(a, b) {
    b =
      "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=reach&proto=" +
      encodeURIComponent(ai(b.O()));
    a.H.M(b, { ha: "GET" }).sendNow();
  }
  function Fu(a) {
    return [
      {
        Wb: 2,
        fd: !1,
        Hc: !0,
        filterIds: Gu(a == null ? void 0 : a.productionFilterIds),
      },
      {
        Wb: 2,
        fd: !0,
        Hc: !0,
        filterIds: Gu(a == null ? void 0 : a.testFilterIds),
      },
      {
        Wb: 2,
        fd: !1,
        Hc: !1,
        filterIds: Gu(a == null ? void 0 : a.testFilterIds),
      },
    ];
  }
  function Gu(a) {
    if (a !== void 0 && typeof BigInt === "function")
      return a.map(function (b) {
        return BigInt(b);
      });
  }
  var Hu = function (a) {
    Lo.call(this, a);
  };
  q(Hu, Lo);
  var Iu = function (a, b) {
    return Cn(a, 1, b);
  };
  n = Hu.prototype;
  n.Mb = function (a) {
    return Bn(this, 2, a);
  };
  n.Lb = function (a) {
    return Bn(this, 3, a);
  };
  n.gd = function (a) {
    return Bn(this, 10, a);
  };
  n.jg = function () {
    return sn(this, Ht, 11);
  };
  n.Tg = function (a) {
    return vn(this, Ht, 11, a);
  };
  Hu.W =
    "ads.branding.measurement.client.frontend.integrations.reach.ReachStatusMessage";
  Hu.prototype.O = No([0, Eo, zo, -1, Eo, -2, zo, -1, vo, zo, Lt, Fo, vo]);
  var Ju = function (a) {
      this.context = a;
      this.points = [];
    },
    Ku = function (a, b) {
      Ba(function (c) {
        if (c.u == 1) return c.jf(2), c.yield(b(), 4);
        if (c.u != 2) return c.return(c.V);
        c.zd();
        a.flush();
        return c.Ld(0);
      });
    };
  Ju.prototype.flush = function () {
    if (!(this.points.length <= 0)) {
      var a = new Hu();
      Iu(a, 9);
      var b = Fu().length;
      dn(a, 13, b == null ? b : yl(b));
      Dn(a, 12, this.points);
      this.points.splice(0);
      Eu(this.context, a);
    }
  };
  function Lu() {
    this.blockSize = -1;
  }
  function Mu(a, b) {
    this.blockSize = -1;
    this.blockSize = 64;
    this.td = Oa.Uint8Array
      ? new Uint8Array(this.blockSize)
      : Array(this.blockSize);
    this.Yd = this.cc = 0;
    this.D = [];
    this.Pi = a;
    this.vg = b;
    this.zj = Oa.Int32Array ? new Int32Array(64) : Array(64);
    Nu === void 0 && (Nu = Oa.Int32Array ? new Int32Array(Ou) : Ou);
    this.reset();
  }
  Wa(Mu, Lu);
  for (var Pu = [], Qu = 0; Qu < 63; Qu++) Pu[Qu] = 0;
  var Ru = [].concat(128, Pu);
  Mu.prototype.reset = function () {
    this.Yd = this.cc = 0;
    this.D = Oa.Int32Array ? new Int32Array(this.vg) : Qb(this.vg);
  };
  var Su = function (a) {
    var b = a.td;
    H(b.length == a.blockSize);
    for (var c = a.zj, d = 0, e = 0; e < b.length; )
      (c[d++] = (b[e] << 24) | (b[e + 1] << 16) | (b[e + 2] << 8) | b[e + 3]),
        (e = d * 4);
    for (b = 16; b < 64; b++)
      (d = c[b - 15] | 0),
        (e = c[b - 2] | 0),
        (c[b] =
          ((((c[b - 16] | 0) +
            (((d >>> 7) | (d << 25)) ^ ((d >>> 18) | (d << 14)) ^ (d >>> 3))) |
            0) +
            (((c[b - 7] | 0) +
              (((e >>> 17) | (e << 15)) ^
                ((e >>> 19) | (e << 13)) ^
                (e >>> 10))) |
              0)) |
          0);
    b = a.D[0] | 0;
    d = a.D[1] | 0;
    e = a.D[2] | 0;
    for (
      var f = a.D[3] | 0,
        g = a.D[4] | 0,
        h = a.D[5] | 0,
        k = a.D[6] | 0,
        l = a.D[7] | 0,
        m = 0;
      m < 64;
      m++
    ) {
      var u =
          ((((b >>> 2) | (b << 30)) ^
            ((b >>> 13) | (b << 19)) ^
            ((b >>> 22) | (b << 10))) +
            ((b & d) ^ (b & e) ^ (d & e))) |
          0,
        t =
          (((l +
            (((g >>> 6) | (g << 26)) ^
              ((g >>> 11) | (g << 21)) ^
              ((g >>> 25) | (g << 7)))) |
            0) +
            ((((((g & h) ^ (~g & k)) + (Nu[m] | 0)) | 0) + (c[m] | 0)) | 0)) |
          0;
      l = k;
      k = h;
      h = g;
      g = (f + t) | 0;
      f = e;
      e = d;
      d = b;
      b = (t + u) | 0;
    }
    a.D[0] = (a.D[0] + b) | 0;
    a.D[1] = (a.D[1] + d) | 0;
    a.D[2] = (a.D[2] + e) | 0;
    a.D[3] = (a.D[3] + f) | 0;
    a.D[4] = (a.D[4] + g) | 0;
    a.D[5] = (a.D[5] + h) | 0;
    a.D[6] = (a.D[6] + k) | 0;
    a.D[7] = (a.D[7] + l) | 0;
  };
  Mu.prototype.update = function (a, b) {
    b === void 0 && (b = a.length);
    var c = 0,
      d = this.cc;
    if (typeof a === "string")
      for (; c < b; )
        (this.td[d++] = a.charCodeAt(c++)),
          d == this.blockSize && (Su(this), (d = 0));
    else if (Ra(a))
      for (; c < b; ) {
        var e = a[c++];
        if (!("number" == typeof e && 0 <= e && 255 >= e && e == (e | 0)))
          throw Error("Pa");
        this.td[d++] = e;
        d == this.blockSize && (Su(this), (d = 0));
      }
    else throw Error("Qa");
    this.cc = d;
    this.Yd += b;
  };
  Mu.prototype.digest = function () {
    var a = [],
      b = this.Yd * 8;
    this.cc < 56
      ? this.update(Ru, 56 - this.cc)
      : this.update(Ru, this.blockSize - (this.cc - 56));
    for (var c = 63; c >= 56; c--) (this.td[c] = b & 255), (b /= 256);
    Su(this);
    for (c = b = 0; c < this.Pi; c++)
      for (var d = 24; d >= 0; d -= 8) a[b++] = (this.D[c] >> d) & 255;
    return a;
  };
  var Ou = [
      1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993,
      2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987,
      1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774,
      264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986,
      2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711,
      113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291,
      1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411,
      3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344,
      430227734, 506948616, 659060556, 883997877, 958139571, 1322822218,
      1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424,
      2428436474, 2756734187, 3204031479, 3329325298,
    ],
    Nu;
  function Tu() {
    Mu.call(this, 8, Uu);
  }
  Wa(Tu, Mu);
  var Uu = [
    1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924,
    528734635, 1541459225,
  ];
  var Io = function (a) {
    Lo.call(this, a);
  };
  q(Io, Lo);
  Io.W = "EventIdMessage";
  var Vu = function (a) {
    Lo.call(this, a);
  };
  q(Vu, Lo);
  Vu.prototype.wc = function (a) {
    return An(this, 4, a);
  };
  Vu.prototype.lg = function () {
    return hn(this, 8, wl);
  };
  Vu.prototype.Jf = function (a) {
    return Dn(this, 8, a);
  };
  Vu.prototype.Ug = function (a) {
    return zn(this, 9, a);
  };
  Vu.W =
    "ads.branding.measurement.client.frontend.integrations.reach.ContextIdMessage";
  var Wu = [0, so, xo, -1];
  Io.prototype.O = No(Wu);
  Vu.prototype.O = No([0, Wu, yo, -1, Co, -3, Go, yo]);
  var Ho = function (a) {
    Lo.call(this, a, 1);
  };
  q(Ho, Lo);
  Ho.W = "proto2.bridge.MessageSet";
  var Xu = {};
  Ho[dl] = Xu;
  var Yu = Mo(Io, Wu);
  Xu[4156379] = { tk: new Jo() };
  var Zu = function () {
    var a;
    this.message = a = a === void 0 ? new Vu() : a;
  };
  Zu.prototype.gd = function (a) {
    var b = this.message;
    a = Yu(ci(a));
    this.message = vn(b, Io, 1, a);
    return this;
  };
  var $u = function (a, b) {
    var c = zn(a.message, 2, b.Wb === 2);
    b = zn(c, 3, !b.fd);
    a.message = b;
    return a;
  };
  Zu.prototype.wc = function (a) {
    this.message = this.message.wc(Math.max(1, a));
    return this;
  };
  var av = function (a, b) {
      a.message = a.message.Jf(b);
      return a;
    },
    bv = function (a) {
      var b = Vp,
        c = b.match(/m\d{12}/g),
        d = b.match(/\d{8}/g);
      if (c && c.length > 0)
        return (
          (b = c[0].slice(1)),
          (c = a.message),
          (d = Number(b.slice(0, 8))),
          (c = An(c, 5, d)),
          (d = Number(b.slice(8, 10))),
          (c = An(c, 6, d)),
          (b = Number(b.slice(10, 12))),
          (b = An(c, 7, b)),
          (a.message = b),
          a
        );
      if (d && d.length > 0)
        return (
          (b = An(a.message, 5, Number(d[0]))),
          (b = dn(b, 6)),
          (b = dn(b, 7)),
          (a.message = b),
          a
        );
      b === "unreleased" &&
        ((b = dn(a.message, 5)),
        (b = An(b, 6, 0)),
        (b = dn(b, 7)),
        (a.message = b));
      return a;
    };
  Zu.prototype.encode = function () {
    var a = this.message,
      b = ai(a.O());
    b.length > 64 && ((a = a.wc(1)), (b = ai(a.O())));
    b.length > 64 && ((a = dn(a, 6)), (b = ai(a.O())));
    b.length > 64 && ((a = dn(a, 7)), (b = ai(a.O())));
    b.length > 64 && ((a = dn(a, 5)), (b = ai(a.O())));
    return b;
  };
  function cv(a, b) {
    if (b === void 0 || b.length === 0)
      return (
        Eu(a, Iu(new Hu(), 7)),
        [he(0)].filter(function (d) {
          return d !== void 0;
        })
      );
    var c = he(-2147483648);
    return c === void 0
      ? []
      : b.map(function (d) {
          var e = d % c;
          d !== e && Eu(a, Iu(new Hu(), 6));
          return e;
        });
  }
  function dv(a, b) {
    var c = c === void 0 ? BigInt(0) : c;
    return { bucket: a, value: b ? 1 : 16384, filteringId: c };
  }
  function ev(a) {
    for (var b = [], c = 0, d = 0; d < a.length; d++) {
      var e = a.charCodeAt(d);
      e < 128
        ? (b[c++] = e)
        : (e < 2048
            ? (b[c++] = (e >> 6) | 192)
            : ((e & 64512) == 55296 &&
              d + 1 < a.length &&
              (a.charCodeAt(d + 1) & 64512) == 56320
                ? ((e =
                    65536 + ((e & 1023) << 10) + (a.charCodeAt(++d) & 1023)),
                  (b[c++] = (e >> 18) | 240),
                  (b[c++] = ((e >> 12) & 63) | 128))
                : (b[c++] = (e >> 12) | 224),
              (b[c++] = ((e >> 6) & 63) | 128)),
          (b[c++] = (e & 63) | 128));
    }
    if (b.length >= 24) throw Error("Ra");
    return [96 | b.length].concat(y(b));
  }
  function iv(a) {
    if (a.length >= 24) throw Error("Sa");
    return [160 | a.length].concat(
      y(
        a
          .sort(kv)
          .map(function (b) {
            return [].concat(y(b[0]), y(b[1]));
          })
          .flat()
      )
    );
  }
  function lv(a) {
    if (a.length >= 24) throw Error("Ta");
    return [128 | a.length].concat(y(a.flat()));
  }
  function rv(a, b) {
    for (var c = []; a > 0; )
      c.push(Number(a % BigInt(255))), (a /= BigInt(255));
    for (; c.length < b; ) c.push(0);
    return c.reverse();
  }
  function kv(a, b) {
    a = a[0];
    b = b[0];
    if (a.length !== b.length) return a.length - b.length;
    for (var c = 0; c < a.length; c++) if (a[c] !== b[c]) return a[c] - b[c];
    return 0;
  }
  function sv(a, b, c, d) {
    var e = dv(BigInt(c), d);
    b = {
      shared_info: JSON.stringify({
        api: "shared-storage",
        report_id: "PRE_WORKLET_ERROR",
        reporting_origin: "https://www.googleadservices.com",
        scheduled_report_time: String(new Date().getUTCSeconds()),
        version: "polyfill",
      }),
      aggregation_service_payloads: [],
      context_id: b,
      aggregation_coordinator_origin:
        "https://publickeyservice.msmt.gcp.privacysandboxservices.com",
    };
    d
      ? ((b.debug_key = "0"),
        b.aggregation_service_payloads.push({
          payload: String(c),
          key_id: "0",
          debug_cleartext_payload: tv([e]),
        }))
      : b.aggregation_service_payloads.push({
          payload: String(c),
          key_id: "0",
        });
    try {
      var f, g;
      (f = a.global) == null ||
        (g = f.fetch) == null ||
        g
          .call(
            f,
            "https://www.googleadservices.com/.well-known/private-aggregation/report-shared-storage",
            {
              method: "POST",
              cache: "no-cache",
              keepalive: !0,
              mode: "no-cors",
              headers: { "content-type": "application/json" },
              body: JSON.stringify(b),
            }
          )
          .catch(function () {});
    } catch (h) {}
  }
  function tv(a) {
    a = iv([
      [
        ev("data"),
        lv(
          a.map(function (b) {
            return iv([
              [ev("value"), [68].concat(y(rv(BigInt(b.value), 4)))],
              [ev("bucket"), [80].concat(y(rv(b.bucket, 16)))],
              [ev("filteringId"), [68].concat(y(rv(b.filteringId, 4)))],
            ]);
          })
        ),
      ],
      [ev("operation"), ev("histogram")],
    ]);
    return btoa(String.fromCharCode.apply(String, y(new Uint8Array(a))));
  }
  var uv = {},
    vv = ((uv[2] = "prod"), (uv[1] = "canary"), uv);
  function wv(a, b, c, d) {
    var e, f, g, h, k, l, m, u;
    return Ba(function (t) {
      switch (t.u) {
        case 1:
          e = Fu(c);
          f = function (r) {
            e.forEach(function (w) {
              var v,
                A = bv(
                  $u(
                    av(
                      new Zu().gd(c.escapedQueryId),
                      (v = c.trafficTypes) != null ? v : [0]
                    ),
                    w
                  )
                )
                  .wc(-1)
                  .encode();
              sv(a, A, r, w.Hc);
            });
          };
          g = gp(a);
          if (g instanceof Error)
            return (
              f(-16),
              (h = Iu(new Hu(), 8).Mb(g.name).Lb(g.message)),
              Eu(a, h),
              t.return()
            );
          d.points.push(7);
          k = xv(a, c, e);
          return t.yield(
            c.experimentState.reachUseCreateWorklet ? yv(a, b, f) : zv(a, b, f),
            2
          );
        case 2:
          return (l = t.V), t.yield(k, 3);
        case 3:
          return (
            (m = t.V),
            d.points.push(8),
            (u = e.map(function (r) {
              var w, v, A;
              return Av(
                a,
                l,
                r,
                m,
                (w = c.deviceType) != null ? w : 1,
                c.escapedQueryId,
                (v = c.trafficTypes) != null ? v : [0],
                (A = c.isProductSplitVpidLogsExperiment) != null ? A : !1,
                function (C) {
                  var G,
                    J = bv(
                      $u(
                        av(
                          new Zu().gd(c.escapedQueryId),
                          (G = c.trafficTypes) != null ? G : [0]
                        ).wc(-1),
                        r
                      )
                    ).encode();
                  sv(a, J, C, r.Hc);
                }
              );
            })),
            t.yield(Promise.all(u), 4)
          );
        case 4:
          d.points.push(9), t.Db();
      }
    });
  }
  function zv(a, b, c) {
    var d, e, f;
    return Ba(function (g) {
      switch (g.u) {
        case 1:
          d = a.sharedStorage;
          if (!d) return g.return(Promise.reject(Error("Ua")));
          g.Kb(2);
          return g.yield(d.worklet.addModule(b), 4);
        case 4:
          g.Pc(3);
          break;
        case 2:
          (e = g.rb()),
            c(-17),
            (f = Iu(new Hu(), 1).Mb(e.name).Lb(e.message)),
            Eu(a, f);
        case 3:
          return g.return(d);
      }
    });
  }
  function yv(a, b, c) {
    var d, e, f;
    return Ba(function (g) {
      if (g.u == 1) {
        d = a.sharedStorage;
        if (!d) return g.return(Promise.reject(Error("Ua")));
        g.Kb(2);
        return g.yield(d.createWorklet(b, { dataOrigin: "script-origin" }), 4);
      }
      if (g.u != 2) return g.return(g.V);
      e = g.rb();
      c(-17);
      f = Iu(new Hu(), 1).Mb(e.name).Lb(e.message);
      Eu(a, f);
      return g.return(Promise.reject(e));
    });
  }
  function xv(a, b, c) {
    var d, e, f;
    return Ba(function (g) {
      if (g.u == 1)
        return (
          (d = [].concat(
            y(
              new Set(
                c.map(function (h) {
                  return h.Wb;
                })
              )
            )
          )),
          (e = d.map(function (h) {
            return Bv(a, b, h);
          })),
          g.yield(Promise.all(e), 2)
        );
      f = g.V;
      return g.return(
        new Map(
          f.map(function (h, k) {
            return [d[k], h];
          })
        )
      );
    });
  }
  function Bv(a, b, c) {
    var d, e, f, g, h, k, l, m, u;
    return Ba(function (t) {
      switch (t.u) {
        case 1:
          return (
            (e =
              (d = b.clientsideModelFilename) != null
                ? d
                : "model_person_country_code_XX_person_region_code_5858.json"),
            (f = void 0),
            (g = 1),
            (h = { method: "GET" }),
            (k = 200),
            (l = b.geoTargetMessage ? It(b.geoTargetMessage) : void 0),
            (m = new Hu().gd(b.escapedQueryId).Tg(l)),
            t.Kb(2),
            t.yield(a.global.fetch(Cv(c, e), h), 4)
          );
        case 4:
          f = t.V;
          k = f.status;
          if (f.ok) {
            t.ba(5);
            break;
          }
          return t.yield(
            a.global.fetch(
              Cv(
                c,
                "model_person_country_code_XX_person_region_code_5858.json"
              ),
              h
            ),
            6
          );
        case 6:
          (f = t.V), (g = 2);
        case 5:
          t.Pc(3);
          break;
        case 2:
          (u = t.rb()),
            (k = -1),
            u instanceof Error && m.Mb(u.name).Lb(u.message);
        case 3:
          var r = Iu(m, 2);
          dn(r, 9, k == null ? k : yl(k));
          if (!f || !f.ok)
            return (
              (r = Cn(m, 4, 4)),
              (r = Bn(r, 8, e)),
              Bn(r, 7, ""),
              Eu(a, m),
              t.return()
            );
          r = Cn(m, 4, g);
          Bn(r, 7, g === 1 ? e : "");
          Eu(a, m);
          return t.yield(f.text(), 7);
        case 7:
          return t.return(t.V);
      }
    });
  }
  function Cv(a, b) {
    return "https://www.googletagservices.com/agrp/" + vv[a] + "/" + b;
  }
  function Av(a, b, c, d, e, f, g, h, k) {
    var l, m, u, t, r, w, v;
    return Ba(function (A) {
      switch (A.u) {
        case 1:
          l = d.get(c.Wb);
          if (l === void 0) return A.return();
          var C = he(-2147483648);
          if (C === void 0) C = -1;
          else {
            var G = Number,
              J = new Tu();
            J.update(l);
            var Y = J.digest();
            J = BigInt(0);
            Y = x(Y);
            var I = Y.next();
            try {
              for (; !I.done; I = Y.next())
                J = (J * BigInt(256) + BigInt(I.value)) % C;
            } finally {
              ra(Y, I);
            }
            C = G(J);
          }
          m = C;
          C = bv($u(av(new Zu().gd(f), g), c).wc(m));
          C.message = C.message.Ug(h);
          u = C.encode();
          t = {
            contextId: u,
            aggregationCoordinatorOrigin:
              "https://publickeyservice.msmt.gcp.privacysandboxservices.com",
            filteringIdMaxBytes: 4,
          };
          r = {
            modelJson: l,
            modelHash: m,
            deviceType: e,
            enableDebugMode: c.Hc,
            reportBrowserIdInsteadOfVPID: c.fd,
            filterIds: cv(a, c.filterIds),
          };
          w = b.run("google_reach", {
            privateAggregationConfig: t,
            data: r,
            keepAlive: !0,
          });
          if (w === void 0) {
            A.ba(2);
            break;
          }
          A.Kb(3);
          return A.yield(w, 5);
        case 5:
          A.Pc(2);
          break;
        case 3:
          (v = A.rb()),
            k(-18),
            (C = v),
            (Y = Iu(new Hu(), 3)
              .Mb((G = C == null ? void 0 : C.name) != null ? G : "unknown")
              .Lb((J = C == null ? void 0 : C.message) != null ? J : "")),
            Eu(a, Y);
        case 2:
          (C = Iu(new Hu(), 5)),
            (C = Cn(C, 5, c.Wb === 1 ? 1 : 2)),
            (C = Cn(C, 6, c.fd ? 1 : 2)),
            Eu(a, C),
            A.Db();
      }
    });
  }
  var Dv = function (a) {
    var b = b === void 0 ? [] : b;
    var c = c === void 0 ? [a] : c;
    this.bf = a;
    this.subscribedEvents = b;
    this.controlledEvents = c;
    this.name = "reach";
    this.bd = new Map();
  };
  n = Dv.prototype;
  n.start = function (a) {
    a.C && (this.context = a.C);
  };
  n.dispose = function () {
    this.bd.forEach(function (a) {
      return void a.dispose();
    });
    this.bd.clear();
  };
  n.He = function (a, b, c, d, e) {
    var f = this,
      g = this.context;
    if (g) {
      var h = new Ju(g);
      Ku(h, function () {
        var k, l, m, u;
        return Ba(function (t) {
          if (t.u == 1) {
            h.points.push(1);
            if (!en(b, 1) || !Qt(b).Ce()) return t.return();
            h.points.push(2);
            return gp(g) ? t.yield(nd(Du(g)), 2) : t.return();
          }
          if (t.u != 3) {
            k = t.V;
            if (!k) return t.return();
            h.points.push(3);
            l = new Ev(g, b, f.bf, c, d, h);
            f.bd.set(a, l);
            return t.yield(l.run(), 3);
          }
          e((u = (m = Qt(b)) == null ? void 0 : m.Dd()) != null ? u : -1);
          t.Db();
        });
      });
    }
  };
  n.Zb = function (a) {
    var b;
    (b = this.bd.get(a)) == null || b.dispose();
    this.bd.delete(a);
  };
  n.handleEvent = function () {};
  var Ev = function (a, b, c, d, e, f) {
    this.context = a;
    this.metadata = b;
    this.bf = c;
    this.experimentState = d;
    this.ab = e;
    this.se = f;
  };
  Ev.prototype.run = function () {
    var a = this,
      b,
      c;
    return Ba(function (d) {
      if (d.u == 1)
        return (
          (b = {}),
          d.yield(
            new Promise(function (e) {
              a.ab(a.bf, b, e);
            }),
            2
          )
        );
      c = d.V;
      if (!c) return d.return();
      a.se.points.push(4);
      return d.yield(Fv(a), 0);
    });
  };
  var Fv = function (a) {
      var b, c, d, e, f, g, h, k, l, m, u, t, r, w, v, A, C, G;
      return Ba(function (J) {
        var Y = a.experimentState,
          I =
            (l = (b = Qt(a.metadata)) == null ? void 0 : b.hg()) != null
              ? l
              : "",
          B =
            (m = (c = Qt(a.metadata)) == null ? void 0 : c.lg()) != null
              ? m
              : void 0,
          ja = (d = Qt(a.metadata)) == null ? void 0 : El(an(d, 1)),
          Pc =
            (u =
              (e = Qt(a.metadata)) == null
                ? void 0
                : (f = e.jg()) == null
                ? void 0
                : f.hb()) != null
              ? u
              : void 0,
          pc =
            (t = (g = Qt(a.metadata)) == null ? void 0 : xn(g, 8)) != null
              ? t
              : void 0,
          Ad = Gv;
        var Ta =
          (h = Qt(a.metadata)) == null
            ? void 0
            : hn(h, 5, zl, cl && (cl && cl === cl ? 2 : 4));
        Ad = Ad(a, (r = Ta) != null ? r : void 0);
        Ta = Gv;
        var Mg =
          (k = Qt(a.metadata)) == null
            ? void 0
            : hn(k, 6, zl, cl && (cl && cl === cl ? 2 : 4));
        v = {
          experimentState: Y,
          escapedQueryId: I,
          trafficTypes: B,
          isProductSplitVpidLogsExperiment: !0,
          clientsideModelFilename: ja,
          geoTargetMessage: Pc,
          deviceType: pc,
          productionFilterIds: Ad,
          testFilterIds: Ta(a, (w = Mg) != null ? w : void 0),
        };
        if (a.experimentState.reachUseCreateWorklet)
          return (
            (G = a.context.nf[2]),
            a.se.points.push(10),
            J.yield(wv(a.context, G, v, a.se), 0)
          );
        A = a.context.nf[0];
        C = btoa(JSON.stringify(v));
        return J.yield(Di(a.context.document, A, C), 0);
      });
    },
    Gv = function (a, b) {
      if (b !== void 0)
        return b.map(function (c) {
          var d;
          return String((d = he(c)) != null ? d : 0);
        });
    };
  Ev.prototype.dispose = function () {};
  var Hv = Qf(
      "m202611180101".match(/^m\d{10}$/g) !== null ? "m202611180101" : "current"
    ),
    Iv;
  a: {
    try {
      var Jv = new vg();
      Iv = new Sf(Jv, "doubleclickbygoogle.com-omid", void 0, Hv);
      break a;
    } catch (a) {}
    Iv = void 0;
  }
  var Kv = Iv,
    Lv = { C: new fp(void 0, void 0, void 0, Hv), ra: Kv };
  (function (a) {
    if (a && Ig(a)) {
      var b = Hg(a);
      if (typeof fetch !== "undefined" && b) {
        a.global.fetch(
          "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-start2",
          { method: "GET", cache: "no-cache", keepalive: !0, mode: "no-cors" }
        );
        try {
          b(
            "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-later2",
            {
              method: "GET",
              cache: "no-cache",
              mode: "no-cors",
              activateAfter: 96e4,
            }
          );
        } catch (c) {
          a.global.fetch(
            "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-fallback2",
            { method: "GET", cache: "no-cache", keepalive: !0, mode: "no-cors" }
          );
        }
        a.Kg.subscribe(function () {
          a.global.fetch(
            "https://pagead2.googlesyndication.com/pagead/gen_204?id=av-js&type=fle-fetch-pagehide2",
            { method: "GET", cache: "no-cache", keepalive: !0, mode: "no-cors" }
          );
        });
      }
    }
  })(Lv.C);
  (function (a, b, c) {
    var d = new vt("impression"),
      e = new vt("begin to render"),
      f = new vt("unmeasurable"),
      g = new vt("viewable"),
      h = new vt("reach vpid"),
      k = new tt(d, h, e, g, f),
      l = new Ut(),
      m = new Au(d.event);
    b = new vu(l, c, d.event, e.event, f.event, g.event, b);
    h = new Dv(h.event);
    var u = new wt(a, k, l, m, b, h);
    u.start();
    return {
      dispose: function () {
        return void u.dispose();
      },
      colleagues: { mk: m, Tk: b, Lk: h },
    };
  })(Lv, 7);
}.call(this));
