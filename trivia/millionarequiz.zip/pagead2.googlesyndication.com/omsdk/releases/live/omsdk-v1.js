(function (omidGlobal) {
  var n;
  function aa(a) {
    var b = 0;
    return function () {
      return b < a.length ? { done: !1, value: a[b++] } : { done: !0 };
    };
  }
  function p(a) {
    var b =
      "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
    if (b) return b.call(a);
    if ("number" == typeof a.length) return { next: aa(a) };
    throw Error(String(a) + " is not an iterable or ArrayLike");
  }
  function q(a) {
    if (!(a instanceof Array)) {
      a = p(a);
      for (var b, c = []; !(b = a.next()).done; ) c.push(b.value);
      a = c;
    }
    return a;
  }
  var ba =
      "function" == typeof Object.create
        ? Object.create
        : function (a) {
            function b() {}
            b.prototype = a;
            return new b();
          },
    t =
      "function" == typeof Object.defineProperties
        ? Object.defineProperty
        : function (a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a;
          };
  function ca(a) {
    a = [
      "object" == typeof globalThis && globalThis,
      a,
      "object" == typeof window && window,
      "object" == typeof self && self,
      "object" == typeof global && global,
    ];
    for (var b = 0; b < a.length; ++b) {
      var c = a[b];
      if (c && c.Math == Math) return c;
    }
    throw Error("Cannot find global object");
  }
  var da = ca(this);
  function u(a, b) {
    if (b)
      a: {
        var c = da;
        a = a.split(".");
        for (var d = 0; d < a.length - 1; d++) {
          var e = a[d];
          if (!(e in c)) break a;
          c = c[e];
        }
        a = a[a.length - 1];
        d = c[a];
        b = b(d);
        b != d &&
          null != b &&
          t(c, a, { configurable: !0, writable: !0, value: b });
      }
  }
  var ea;
  if ("function" == typeof Object.setPrototypeOf) ea = Object.setPrototypeOf;
  else {
    var fa;
    a: {
      var ha = { a: !0 },
        ia = {};
      try {
        ia.__proto__ = ha;
        fa = ia.a;
        break a;
      } catch (a) {}
      fa = !1;
    }
    ea = fa
      ? function (a, b) {
          a.__proto__ = b;
          if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
          return a;
        }
      : null;
  }
  var ja = ea;
  function v(a, b) {
    a.prototype = ba(b.prototype);
    a.prototype.constructor = a;
    if (ja) ja(a, b);
    else
      for (var c in b)
        if ("prototype" != c)
          if (Object.defineProperties) {
            var d = Object.getOwnPropertyDescriptor(b, c);
            d && Object.defineProperty(a, c, d);
          } else a[c] = b[c];
    a.Na = b.prototype;
  }
  function w() {
    for (var a = Number(this), b = [], c = a; c < arguments.length; c++)
      b[c - a] = arguments[c];
    return b;
  }
  function x(a, b) {
    return Object.prototype.hasOwnProperty.call(a, b);
  }
  var ka =
    "function" == typeof Object.assign
      ? Object.assign
      : function (a, b) {
          for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (d) for (var e in d) x(d, e) && (a[e] = d[e]);
          }
          return a;
        };
  u("Object.assign", function (a) {
    return a || ka;
  });
  u("Object.is", function (a) {
    return a
      ? a
      : function (b, c) {
          return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c;
        };
  });
  u("Array.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = this;
          d instanceof String && (d = String(d));
          var e = d.length;
          c = c || 0;
          for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
            var f = d[c];
            if (f === b || Object.is(f, b)) return !0;
          }
          return !1;
        };
  });
  function la(a, b, c) {
    if (null == a)
      throw new TypeError(
        "The 'this' value for String.prototype." +
          c +
          " must not be null or undefined"
      );
    if (b instanceof RegExp)
      throw new TypeError(
        "First argument to String.prototype." +
          c +
          " must not be a regular expression"
      );
    return a + "";
  }
  u("String.prototype.includes", function (a) {
    return a
      ? a
      : function (b, c) {
          return -1 !== la(this, b, "includes").indexOf(b, c || 0);
        };
  });
  u("Symbol", function (a) {
    function b(f) {
      if (this instanceof b) throw new TypeError("Symbol is not a constructor");
      return new c(d + (f || "") + "_" + e++, f);
    }
    function c(f, h) {
      this.g = f;
      t(this, "description", { configurable: !0, writable: !0, value: h });
    }
    if (a) return a;
    c.prototype.toString = function () {
      return this.g;
    };
    var d = "jscomp_symbol_" + ((1e9 * Math.random()) >>> 0) + "_",
      e = 0;
    return b;
  });
  u("Symbol.iterator", function (a) {
    if (a) return a;
    a = Symbol("Symbol.iterator");
    for (
      var b =
          "Array Int8Array Uint8Array Uint8ClampedArray Int16Array Uint16Array Int32Array Uint32Array Float32Array Float64Array".split(
            " "
          ),
        c = 0;
      c < b.length;
      c++
    ) {
      var d = da[b[c]];
      "function" === typeof d &&
        "function" != typeof d.prototype[a] &&
        t(d.prototype, a, {
          configurable: !0,
          writable: !0,
          value: function () {
            return ma(aa(this));
          },
        });
    }
    return a;
  });
  function ma(a) {
    a = { next: a };
    a[Symbol.iterator] = function () {
      return this;
    };
    return a;
  }
  u("WeakMap", function (a) {
    function b(k) {
      this.g = (g += Math.random() + 1).toString();
      if (k) {
        k = p(k);
        for (var l; !(l = k.next()).done; ) (l = l.value), this.set(l[0], l[1]);
      }
    }
    function c() {}
    function d(k) {
      var l = typeof k;
      return ("object" === l && null !== k) || "function" === l;
    }
    function e(k) {
      if (!x(k, h)) {
        var l = new c();
        t(k, h, { value: l });
      }
    }
    function f(k) {
      var l = Object[k];
      l &&
        (Object[k] = function (m) {
          if (m instanceof c) return m;
          Object.isExtensible(m) && e(m);
          return l(m);
        });
    }
    if (
      (function () {
        if (!a || !Object.seal) return !1;
        try {
          var k = Object.seal({}),
            l = Object.seal({}),
            m = new a([
              [k, 2],
              [l, 3],
            ]);
          if (2 != m.get(k) || 3 != m.get(l)) return !1;
          m.delete(k);
          m.set(l, 4);
          return !m.has(k) && 4 == m.get(l);
        } catch (r) {
          return !1;
        }
      })()
    )
      return a;
    var h = "$jscomp_hidden_" + Math.random();
    f("freeze");
    f("preventExtensions");
    f("seal");
    var g = 0;
    b.prototype.set = function (k, l) {
      if (!d(k)) throw Error("Invalid WeakMap key");
      e(k);
      if (!x(k, h)) throw Error("WeakMap key fail: " + k);
      k[h][this.g] = l;
      return this;
    };
    b.prototype.get = function (k) {
      return d(k) && x(k, h) ? k[h][this.g] : void 0;
    };
    b.prototype.has = function (k) {
      return d(k) && x(k, h) && x(k[h], this.g);
    };
    b.prototype.delete = function (k) {
      return d(k) && x(k, h) && x(k[h], this.g) ? delete k[h][this.g] : !1;
    };
    return b;
  });
  u("Map", function (a) {
    function b() {
      var g = {};
      return (g.H = g.next = g.head = g);
    }
    function c(g, k) {
      var l = g.g;
      return ma(function () {
        if (l) {
          for (; l.head != g.g; ) l = l.H;
          for (; l.next != l.head; )
            return (l = l.next), { done: !1, value: k(l) };
          l = null;
        }
        return { done: !0, value: void 0 };
      });
    }
    function d(g, k) {
      var l = k && typeof k;
      "object" == l || "function" == l
        ? f.has(k)
          ? (l = f.get(k))
          : ((l = "" + ++h), f.set(k, l))
        : (l = "p_" + k);
      var m = g.h[l];
      if (m && x(g.h, l))
        for (g = 0; g < m.length; g++) {
          var r = m[g];
          if ((k !== k && r.key !== r.key) || k === r.key)
            return { id: l, list: m, index: g, B: r };
        }
      return { id: l, list: m, index: -1, B: void 0 };
    }
    function e(g) {
      this.h = {};
      this.g = b();
      this.size = 0;
      if (g) {
        g = p(g);
        for (var k; !(k = g.next()).done; ) (k = k.value), this.set(k[0], k[1]);
      }
    }
    if (
      (function () {
        if (
          !a ||
          "function" != typeof a ||
          !a.prototype.entries ||
          "function" != typeof Object.seal
        )
          return !1;
        try {
          var g = Object.seal({ x: 4 }),
            k = new a(p([[g, "s"]]));
          if (
            "s" != k.get(g) ||
            1 != k.size ||
            k.get({ x: 4 }) ||
            k.set({ x: 4 }, "t") != k ||
            2 != k.size
          )
            return !1;
          var l = k.entries(),
            m = l.next();
          if (m.done || m.value[0] != g || "s" != m.value[1]) return !1;
          m = l.next();
          return m.done ||
            4 != m.value[0].x ||
            "t" != m.value[1] ||
            !l.next().done
            ? !1
            : !0;
        } catch (r) {
          return !1;
        }
      })()
    )
      return a;
    var f = new WeakMap();
    e.prototype.set = function (g, k) {
      g = 0 === g ? 0 : g;
      var l = d(this, g);
      l.list || (l.list = this.h[l.id] = []);
      l.B
        ? (l.B.value = k)
        : ((l.B = {
            next: this.g,
            H: this.g.H,
            head: this.g,
            key: g,
            value: k,
          }),
          l.list.push(l.B),
          (this.g.H.next = l.B),
          (this.g.H = l.B),
          this.size++);
      return this;
    };
    e.prototype.delete = function (g) {
      g = d(this, g);
      return g.B && g.list
        ? (g.list.splice(g.index, 1),
          g.list.length || delete this.h[g.id],
          (g.B.H.next = g.B.next),
          (g.B.next.H = g.B.H),
          (g.B.head = null),
          this.size--,
          !0)
        : !1;
    };
    e.prototype.clear = function () {
      this.h = {};
      this.g = this.g.H = b();
      this.size = 0;
    };
    e.prototype.has = function (g) {
      return !!d(this, g).B;
    };
    e.prototype.get = function (g) {
      return (g = d(this, g).B) && g.value;
    };
    e.prototype.entries = function () {
      return c(this, function (g) {
        return [g.key, g.value];
      });
    };
    e.prototype.keys = function () {
      return c(this, function (g) {
        return g.key;
      });
    };
    e.prototype.values = function () {
      return c(this, function (g) {
        return g.value;
      });
    };
    e.prototype.forEach = function (g, k) {
      for (var l = this.entries(), m; !(m = l.next()).done; )
        (m = m.value), g.call(k, m[1], m[0], this);
    };
    e.prototype[Symbol.iterator] = e.prototype.entries;
    var h = 0;
    return e;
  });
  u("Set", function (a) {
    function b(c) {
      this.g = new Map();
      if (c) {
        c = p(c);
        for (var d; !(d = c.next()).done; ) this.add(d.value);
      }
      this.size = this.g.size;
    }
    if (
      (function () {
        if (
          !a ||
          "function" != typeof a ||
          !a.prototype.entries ||
          "function" != typeof Object.seal
        )
          return !1;
        try {
          var c = Object.seal({ x: 4 }),
            d = new a(p([c]));
          if (
            !d.has(c) ||
            1 != d.size ||
            d.add(c) != d ||
            1 != d.size ||
            d.add({ x: 4 }) != d ||
            2 != d.size
          )
            return !1;
          var e = d.entries(),
            f = e.next();
          if (f.done || f.value[0] != c || f.value[1] != c) return !1;
          f = e.next();
          return f.done ||
            f.value[0] == c ||
            4 != f.value[0].x ||
            f.value[1] != f.value[0]
            ? !1
            : e.next().done;
        } catch (h) {
          return !1;
        }
      })()
    )
      return a;
    b.prototype.add = function (c) {
      c = 0 === c ? 0 : c;
      this.g.set(c, c);
      this.size = this.g.size;
      return this;
    };
    b.prototype.delete = function (c) {
      c = this.g.delete(c);
      this.size = this.g.size;
      return c;
    };
    b.prototype.clear = function () {
      this.g.clear();
      this.size = 0;
    };
    b.prototype.has = function (c) {
      return this.g.has(c);
    };
    b.prototype.entries = function () {
      return this.g.entries();
    };
    b.prototype.values = function () {
      return this.g.values();
    };
    b.prototype.keys = b.prototype.values;
    b.prototype[Symbol.iterator] = b.prototype.values;
    b.prototype.forEach = function (c, d) {
      var e = this;
      this.g.forEach(function (f) {
        return c.call(d, f, f, e);
      });
    };
    return b;
  });
  u("Object.values", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) x(b, d) && c.push(b[d]);
          return c;
        };
  });
  function na(a, b) {
    a instanceof String && (a += "");
    var c = 0,
      d = !1,
      e = {
        next: function () {
          if (!d && c < a.length) {
            var f = c++;
            return { value: b(f, a[f]), done: !1 };
          }
          d = !0;
          return { done: !0, value: void 0 };
        },
      };
    e[Symbol.iterator] = function () {
      return e;
    };
    return e;
  }
  u("Array.prototype.keys", function (a) {
    return a
      ? a
      : function () {
          return na(this, function (b) {
            return b;
          });
        };
  });
  u("String.prototype.repeat", function (a) {
    return a
      ? a
      : function (b) {
          var c = la(this, null, "repeat");
          if (0 > b || 1342177279 < b)
            throw new RangeError("Invalid count value");
          b |= 0;
          for (var d = ""; b; ) if ((b & 1 && (d += c), (b >>>= 1))) c += c;
          return d;
        };
  });
  u("String.prototype.padStart", function (a) {
    return a
      ? a
      : function (b, c) {
          var d = la(this, null, "padStart");
          b -= d.length;
          c = void 0 !== c ? String(c) : " ";
          return (
            (0 < b && c
              ? c.repeat(Math.ceil(b / c.length)).substring(0, b)
              : "") + d
          );
        };
  });
  u("Object.entries", function (a) {
    return a
      ? a
      : function (b) {
          var c = [],
            d;
          for (d in b) x(b, d) && c.push([d, b[d]]);
          return c;
        };
  });
  u("Array.prototype.values", function (a) {
    return a
      ? a
      : function () {
          return na(this, function (b, c) {
            return c;
          });
        };
  });
  var y = {
      za: "loaded",
      Ha: "start",
      ta: "firstQuartile",
      Ca: "midpoint",
      Ia: "thirdQuartile",
      ra: "complete",
      Da: "pause",
      Fa: "resume",
      qa: "bufferStart",
      pa: "bufferFinish",
      Ga: "skipped",
      La: "volumeChange",
      Ea: "playerStateChange",
      ma: "adUserInteraction",
    },
    oa = { wa: "generic", Ka: "video", Ba: "media" },
    pa = { da: "native", xa: "html", X: "javascript" },
    qa = { da: "native", X: "javascript", NONE: "none" },
    ra = { va: "full", sa: "domain", ya: "limited" },
    sa = { oa: "backgrounded", ua: "foregrounded" },
    ta = { Aa: "locked", Ja: "unlocked" },
    ua = { na: "app", Ma: "web" };
  function z(a, b) {
    this.x = null != a.x ? a.x : a.left;
    this.y = null != a.y ? a.y : a.top;
    this.width = a.width;
    this.height = a.height;
    this.endX = this.x + this.width;
    this.endY = this.y + this.height;
    this.adSessionId = a.adSessionId || void 0;
    this.isFriendlyObstructionFor = a.isFriendlyObstructionFor || [];
    this.h = a.friendlyObstructionClass || void 0;
    this.i = a.friendlyObstructionPurpose || void 0;
    this.j = a.friendlyObstructionReason || void 0;
    this.clipsToBounds =
      void 0 !== a.clipsToBounds ? !0 === a.clipsToBounds : !0;
    this.m = void 0 !== a.hasWindowFocus ? !0 === a.hasWindowFocus : !0;
    this.notVisibleReason = a.notVisibleReason || void 0;
    this.noOutputDevice = a.noOutputDevice || void 0;
    this.isPipActive = "true" === a.isPipActive || !0 === a.isPipActive || !1;
    this.childViews = a.childViews || [];
    this.isCreative = a.isCreative || !1;
    this.g = b;
  }
  function va(a) {
    var b = {};
    return (b.width = a.width), (b.height = a.height), b;
  }
  function B(a) {
    var b = {};
    return Object.assign({}, va(a), ((b.x = a.x), (b.y = a.y), b));
  }
  function C(a) {
    var b = B(a),
      c = {};
    return Object.assign({}, b, ((c.endX = a.endX), (c.endY = a.endY), c));
  }
  function wa(a, b, c) {
    a.x += b;
    a.y += c;
    a.endX += b;
    a.endY += c;
  }
  z.prototype.O = function (a) {
    if (null == a) return !1;
    a = B(a);
    var b = a.y,
      c = a.width,
      d = a.height;
    return (
      this.x === a.x && this.y === b && this.width === c && this.height === d
    );
  };
  function xa(a) {
    return a.width * a.height;
  }
  function D(a) {
    return 0 === a.width || 0 === a.height;
  }
  function ya(a, b) {
    a = B(a);
    for (var c = [], d = [], e = 0; e < b.length; e++) {
      var f = B(b[e]);
      f = za(a, f);
      Aa(c, f.x);
      Aa(c, f.endX);
      Aa(d, f.y);
      Aa(d, f.endY);
    }
    c = c.sort(function (h, g) {
      return h - g;
    });
    d = d.sort(function (h, g) {
      return h - g;
    });
    return { ka: c, la: d };
  }
  function za(a, b) {
    return {
      x: Math.max(a.x, b.x),
      y: Math.max(a.y, b.y),
      endX: Math.min(a.x + a.width, b.x + b.width),
      endY: Math.min(a.y + a.height, b.y + b.height),
    };
  }
  function Aa(a, b) {
    -1 === a.indexOf(b) && a.push(b);
  }
  function Ba() {
    this.h = this.g = this.D = this.u = this.m = this.s = void 0;
    this.A = 0;
    this.l = [];
    this.v = [];
    this.C = 0;
    this.o = [];
    this.j = [];
    this.i = [];
  }
  Ba.prototype.O = function (a) {
    return null == a ? !1 : JSON.stringify(Ca(this)) === JSON.stringify(Ca(a));
  };
  function Ca(a) {
    var b = [],
      c = [],
      d = {
        viewport: a.s,
        adView: { percentageInView: a.A, pixelsInView: a.C, reasons: a.i },
        declaredFriendlyObstructions: a.l.length,
      };
    if (void 0 !== a.g) {
      d.adView.geometry = B(a.g);
      d.adView.geometry.pixels = xa(a.g);
      d.adView.onScreenGeometry = B(a.h);
      d.adView.onScreenGeometry.pixels = Da(a);
      for (var e = 0; e < a.j.length; e++) b.push(B(a.j[e]));
      for (e = 0; e < a.v.length; e++) {
        var f = a.v[e],
          h = f,
          g = {};
        h.h && (g.obstructionClass = h.h);
        h.i && (g.obstructionPurpose = h.i);
        h.j && (g.obstructionReason = h.j);
        f = za(a.g, f);
        c.push(
          Object.assign(
            {},
            { x: f.x, y: f.y, width: f.endX - f.x, height: f.endY - f.y },
            g
          )
        );
      }
      d.adView.onScreenGeometry.obstructions = b;
      d.adView.onScreenGeometry.friendlyObstructions = c;
      void 0 !== a.u &&
        void 0 !== a.D &&
        ((d.adView.containerGeometry = B(a.u)),
        (d.adView.onScreenContainerGeometry = B(a.D)),
        (d.adView.measuringElement = !0));
    }
    return d;
  }
  function Ea(a, b) {
    b = va(b);
    a.s = {};
    a.s.width = b.width;
    a.s.height = b.height;
    a.m = {};
    a.m.x = 0;
    a.m.y = 0;
    a.m.width = b.width;
    a.m.height = b.height;
    a.m.endX = b.width;
    a.m.endY = b.height;
  }
  function Fa() {
    return { x: 0, y: 0, endX: 0, endY: 0, width: 0, height: 0 };
  }
  function Ga(a, b) {
    var c = {};
    c.x = Math.max(a.x, b.x);
    c.y = Math.max(a.y, b.y);
    c.endX = Math.min(a.endX, b.endX);
    c.endY = Math.min(a.endY, b.endY);
    c.width = Math.max(0, c.endX - c.x);
    c.height = Math.max(0, c.endY - c.y);
    return c;
  }
  function Ha(a, b) {
    return 0.01 < b.width - a.width || 0.01 < b.height - a.height;
  }
  function Ia(a) {
    if (-1 !== a.i.indexOf("backgrounded")) (a.A = 0), (a.C = 0);
    else {
      var b = xa(a.g);
      if (0 !== b) {
        var c = Da(a);
        a.A = Math.round((c / b) * 100);
        a.C = c;
      }
    }
  }
  function Ja(a, b) {
    if (D(b) || !a.h) b = !1;
    else {
      var c = C(a.h),
        d = c.y,
        e = c.endX;
      a = c.endY;
      var f = b.endX;
      c = c.x;
      (f = f < c || 0.01 > Math.abs(f - c)) ||
        ((f = b.x), (f = f > e || 0.01 > Math.abs(f - e)));
      (e = f) || ((e = b.endY), (e = e < d || 0.01 > Math.abs(e - d)));
      (d = e) || ((b = b.y), (d = b > a || 0.01 > Math.abs(b - a)));
      b = !d;
    }
    return b;
  }
  function E(a, b) {
    for (var c = !1, d = 0; d < a.i.length; d++) a.i[d] === b && (c = !0);
    c || a.i.push(b);
  }
  function Da(a) {
    var b = Math,
      c = b.max,
      d = xa(a.h),
      e = a.j,
      f = 0;
    if (0 < e.length) {
      var h = ya(a.h, e);
      a = h.ka;
      h = h.la;
      for (var g = 0; g < a.length - 1; g++)
        for (
          var k = (a[g] + (a[g] + 1)) / 2, l = a[g + 1] - a[g], m = 0;
          m < h.length - 1;
          m++
        ) {
          for (
            var r = (h[m] + (h[m] + 1)) / 2, A = h[m + 1] - h[m], J = !1, I = 0;
            I < e.length;
            I++
          ) {
            var K = B(e[I]);
            if (K.x < k && K.x + K.width > k && K.y < r && K.y + K.height > r) {
              J = !0;
              break;
            }
          }
          J && (f += Math.round(l) * Math.round(A));
        }
    }
    return c.call(b, 0, d - f);
  }
  function Ka() {}
  function La() {}
  function Ma(a, b, c, d, e, f) {
    var h = new Ba();
    b = new z(b, !1);
    Ea(h, b);
    Na(a, b, h, d);
    if (!e)
      return (
        (h.i = ["unmeasurable"]),
        (h.s = void 0),
        (h.A = 0),
        (h.j = []),
        h.g &&
          ((a = h.g),
          (c = {}),
          (a = new z(
            ((c.x = 0),
            (c.y = 0),
            (c.width = a.width),
            (c.height = a.height),
            c),
            a.g
          )),
          (h.g = a)),
        (h.h = Fa()),
        h
      );
    "locked" === f && E(h, "deviceLocked");
    if (b.noOutputDevice) E(h, "backgrounded"), E(h, "noOutputDevice");
    else if ("backgrounded" === c) E(h, "backgrounded");
    else if (void 0 !== h.g) {
      for (a = 0; a < h.l.length; a++) Ja(h, h.l[a]) && h.v.push(h.l[a]);
      for (a = 0; a < h.o.length; a++) {
        if ((c = Ja(h, h.o[a]))) {
          a: {
            c = h.o[a];
            for (d = 0; d < h.j.length; d++)
              if (h.j[d].O(c)) {
                c = !0;
                break a;
              }
            c = !1;
          }
          c = !c;
        }
        c && (E(h, "obstructed"), h.j.push(h.o[a]));
      }
      Ia(h);
    } else E(h, "notFound");
    return h;
  }
  function Na(a, b, c, d) {
    var e = b.isCreative ? !0 : b.adSessionId === d;
    if (e) {
      c.g = b;
      var f = C(c.g);
      a = Ga(c.m, f);
      var h = c.g;
      "notAttached" === h.notVisibleReason ||
      "noWindowFocus" === h.notVisibleReason ||
      "noAdView" === h.notVisibleReason
        ? (E(c, "notFound"), (c.h = new z(Fa(), !1)))
        : ((h = c.g),
          "viewInvisible" === h.notVisibleReason ||
          "viewGone" === h.notVisibleReason ||
          "viewNotVisible" === h.notVisibleReason ||
          "viewAlphaZero" === h.notVisibleReason ||
          "viewHidden" === h.notVisibleReason ||
          void 0 !== c.g.notVisibleReason ||
          D(c.g)
            ? (E(c, "hidden"), (c.h = new z(Fa(), !1)))
            : (c.g.isPipActive && E(c, "pictureInPicture"),
              c.g.m || (E(c, "backgrounded"), E(c, "noWindowFocus")),
              Ha(a, f) && E(c, "clipped"),
              (c.h = new z(a, !1))));
    } else if (
      ((f = !0),
      b.g &&
        (f =
          -1 !== b.isFriendlyObstructionFor.indexOf(d)
            ? !1
            : !1 === b.clipsToBounds),
      f)
    ) {
      h = b.childViews;
      for (var g = 0; g < h.length; g++)
        (f = void 0 !== c.g), Na(a, new z(h[g], f), c, d);
    }
    e ||
      void 0 === c.g ||
      (b.g
        ? -1 !== b.isFriendlyObstructionFor.indexOf(d)
          ? c.l.push(b)
          : c.o.push(b)
        : ((e = C(b)),
          (d = C(c.h)),
          B(c.h),
          !D(c.h) &&
            b.clipsToBounds &&
            ((b = Ga(d, e)),
            Ha(b, d) && (E(c, "clipped"), (c.h = new z(b, !1))))));
  }
  function G() {
    var a = w.apply(0, arguments);
    Oa(
      function () {
        throw new (Function.prototype.bind.apply(
          Error,
          [null, "Could not complete the test successfully - "].concat(q(a))
        ))();
      },
      function () {
        return console.error.apply(console, q(a));
      }
    );
  }
  function Pa() {
    var a = w.apply(0, arguments);
    Oa(
      function () {},
      function () {
        return console.error.apply(console, q(a));
      }
    );
  }
  function Oa(a, b) {
    "undefined" !== typeof jasmine && jasmine
      ? a()
      : "undefined" !== typeof console && console && console.error && b();
  }
  function Qa(a) {
    return a && a.omidNative && "function" === typeof a.omidNative.attest;
  }
  function Ra() {
    var a = H;
    if (!a || !a.navigator) return !1;
    a = a.navigator.userAgent;
    var b = /Safari\/[\d.]*$/.test(a) && !/Chrome|Firefox|Edg|OPR/.test(a),
      c = /(iPhone|iPad|iPod)/.test(a),
      d = /(Macintosh)/.test(a);
    try {
      if (c) {
        var e = /(iPhone OS|iPad OS|CPU OS) (\d+[_.]\d+)/.exec(a);
        return e ? 16 <= parseInt(e[2], 10) : !1;
      }
      if (b && d) {
        var f = /OS X (\d+(?:[_.]\d+)+)/.exec(a);
        if (!f) return !0;
        a: {
          if (f && f[1]) {
            var h = f[0].includes(".") ? "." : "_",
              g = f[1].split(h);
            if (3 === g.length) {
              var k = parseInt(g[1], 10);
              break a;
            }
            if (2 === g.length) {
              k = parseInt(g[0], 10);
              break a;
            }
          }
          k = null;
        }
        return (e = k) ? 13 <= e : void 0;
      }
    } catch (l) {
      G("Error analyzing the user agent. Contact OM SDK with the user agent.");
    }
    return !1;
  }
  function Sa() {
    var a;
    this.g = a = void 0 === a ? omidGlobal : a;
  }
  Sa.prototype.setInterval = function (a, b) {
    return Ta(this, "setInterval")(a, b);
  };
  Sa.prototype.clearInterval = function (a) {
    Ta(this, "clearInterval")(a);
  };
  function Ua(a, b) {
    Ta(a, "clearTimeout")(b);
  }
  function Ta(a, b) {
    return a.g && a.g[b] ? a.g[b] : Va(a, b);
  }
  function Wa(a, b, c, d) {
    if (a.g.document && a.g.document.body) {
      var e = a.g.document.createElement("img");
      e.width = 1;
      e.height = 1;
      e.style.display = "none";
      e.src = b;
      c &&
        e.addEventListener("load", function () {
          return c();
        });
      d &&
        e.addEventListener("error", function () {
          return d();
        });
      a.g.document.body.appendChild(e);
    } else Va(a, "sendUrl")(b, c, d);
  }
  function Xa(a, b, c) {
    if (b)
      try {
        if (Qa(a.g)) a.g.omidNative.attest(b, c);
        else if (a.g.document && a.g.document.body) {
          var d = a.g.document.createElement("img");
          d.width = 1;
          d.height = 1;
          d.style.display = "none";
          d.src = b;
          c &&
            d.addEventListener("load", function () {
              return c();
            });
          a.g.document.body.appendChild(d);
        }
      } catch (e) {}
  }
  function Va(a, b) {
    if (a.g && a.g.omidNative && a.g.omidNative[b])
      return a.g.omidNative[b].bind(a.g.omidNative);
    throw Error('Native interface method "' + b + '" not found.');
  }
  var H = (function () {
    if ("undefined" !== typeof omidGlobal && omidGlobal) return omidGlobal;
    if ("undefined" !== typeof global && global) return global;
    if ("undefined" !== typeof window && window) return window;
    if ("undefined" !== typeof globalThis && globalThis) return globalThis;
    var a = Function("return this")();
    if (a) return a;
    throw Error("Could not determine global object context.");
  })();
  function Ya() {
    this.i = new Map();
    this.h = null;
    this.g = [];
    Qa(H)
      ? this.g.push({
          mechanism: "ApplePAT",
          version: "default",
          executionEnvironment: "native",
        })
      : Ra() &&
        this.g.push({
          mechanism: "ApplePAT",
          version: "default",
          executionEnvironment: "web",
        });
  }
  function L() {
    Za || (Za = new Ya());
    return Za;
  }
  var Za = null;
  function $a() {
    this.h = new Set();
    this.g = 0;
  }
  function ab(a, b) {
    this.y = this.x = 0;
    this.width = a;
    this.height = b;
  }
  function bb() {
    this.adSessionId = null;
    this.m = {
      apiVersion: "1.0",
      accessMode: "limited",
      environment: "app",
      omidJsInfo: {
        omidImplementer: "omsdk",
        serviceVersion: "1.6.11-google36",
      },
    };
    this.D = null;
    this.A = "foregrounded";
    this.N = "unlocked";
    this.u = this.o = "none";
    this.s =
      this.j =
      this.i =
      this.l =
      this.h =
      this.g =
      this.K =
      this.I =
        null;
    this.J = !0;
    this.C = new Map();
    this.v = new $a();
  }
  function cb(a, b) {
    void 0 !== b.contentUrl && ((a.D = b.contentUrl), (b.contentUrl = void 0));
    var c = a.m || {};
    b.omidJsInfo = Object.assign({}, c.omidJsInfo || {}, b.omidJsInfo || {});
    a.m = Object.assign({}, c, b);
  }
  function db(a, b) {
    this.g = a;
    this.h = b;
  }
  da.Object.defineProperties(db.prototype, {
    event: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.g;
      },
    },
    origin: {
      configurable: !0,
      enumerable: !0,
      get: function () {
        return this.h;
      },
    },
  });
  function eb(a) {
    return {
      supportedAttestationMechanisms: a.map(function (b) {
        return { mechanism: b.mechanism, version: b.version };
      }),
    };
  }
  function fb(a) {
    this.g = a;
    this.m = [];
    this.i = [];
    this.j = [];
    this.l = [];
    this.o = {};
  }
  function gb(a, b) {
    if (void 0 !== a.g && a.g.adSessionId && !1 !== hb(a, b)) {
      var c = b.event;
      a.j
        .filter(function (d) {
          return d.type === c.type;
        })
        .forEach(function (d) {
          a.h(d.G, c);
        });
    }
  }
  function ib(a, b) {
    a.m.push(b);
    gb(a, b);
  }
  function jb(a, b, c) {
    void 0 !== a.g &&
      a.g.adSessionId &&
      a.m
        .filter(function (d) {
          return d.event.type === b && hb(a, d);
        })
        .map(function (d) {
          return d.event;
        })
        .forEach(function (d) {
          a.h(c.G, d);
        });
  }
  function hb(a, b) {
    var c = b.event.type,
      d = -1 !== Object.values(y).indexOf(c) && "volumeChange" !== c;
    return "impression" === c || ("loaded" === c && a.g.h)
      ? b.origin === a.g.u
      : d
      ? b.origin === a.g.o
      : !0;
  }
  function kb(a, b, c) {
    Object.keys(y).forEach(function (d) {
      d = y[d];
      var e = { type: d, S: c, G: b };
      a.j.push(e);
      jb(a, d, e);
    });
  }
  function lb(a, b, c, d) {
    var e = { W: c, S: d, G: b };
    a.l.push(e);
    a.i.forEach(function (f) {
      var h = mb(f);
      "sessionStart" === f.event.type && nb(a, h, e);
      a.h(e.G, h);
    });
  }
  function ob(a, b, c) {
    var d = M(a, "sessionError", "native", { errorType: b, message: c });
    a.i.push(d);
    a.l.forEach(function (e) {
      a.h(e.G, d.event);
    });
  }
  function pb(a, b) {
    a.o = Object.assign(a.o, b);
    b = a.g.m;
    if (void 0 !== b) {
      b = Object.assign({}, qb(rb(a, sb(a, { context: b }), !0)), {
        supportsLoadedEvent: !!a.g.h || "video" == a.g.g,
      });
      Object.assign(b, { pageUrl: null, contentUrl: a.g.D });
      tb(b);
      var c = M(a, "sessionStart", "native", b);
      a.i.push(c);
      a.l.forEach(function (d) {
        var e = mb(c);
        nb(a, e, d);
        a.h(d.G, e);
      }, a);
      ub(a);
    }
  }
  function nb(a, b, c) {
    var d = b.data.context;
    c.W && (b.data.verificationParameters = a.o[c.W]);
    c.S &&
      (c = a.g.C.get(c.S)) &&
      ((b.data.verificationParameters = c.verificationParameters),
      (d.accessMode = c.accessMode),
      "full" === c.accessMode &&
        (a.g.j && (d.videoElement = a.g.j), a.g.i && (d.slotElement = a.g.i)));
    !d ||
      d.accessMode ||
      a.g.J ||
      (null != a.g.j
        ? ((d.videoElement = a.g.j), (d.accessMode = "full"))
        : null != a.g.i && ((d.slotElement = a.g.i), (d.accessMode = "full")));
  }
  function vb(a) {
    var b = M(a, "sessionFinish", "native");
    a.i.push(b);
    a.l.forEach(function (c) {
      a.h(c.G, b.event);
    });
  }
  fb.prototype.h = function (a) {
    var b = w.apply(1, arguments);
    try {
      a.apply(null, q(b));
    } catch (c) {
      Pa(c);
    }
  };
  function wb(a, b) {
    var c = (c = a.g.L) ? Ca(c) : null;
    c = rb(a, sb(a, c));
    ib(a, M(a, "impression", b, c));
  }
  function xb(a, b, c) {
    if (a.g.h || "display" != a.g.g)
      (b = M(a, "loaded", b, rb(a, sb(a, void 0 === c ? null : c)))), ib(a, b);
  }
  function yb(a, b, c, d) {
    ("start" !== b && "volumeChange" !== b) ||
      null != (d && d.deviceVolume) ||
      (d.deviceVolume = a.g.I);
    if (d && ("start" === b || "volumeChange" === b)) {
      var e = d.videoPlayerVolume,
        f = d.mediaPlayerVolume;
      null != e
        ? (Object.assign(d, { mediaPlayerVolume: e }), (a.g.K = e))
        : null != f &&
          (Object.assign(d, { videoPlayerVolume: f }), (a.g.K = f));
    }
    ib(a, M(a, b, c, d));
  }
  function ub(a) {
    var b = a.m
        .filter(function (f) {
          return (Object.values(y).includes(f.event.type) &&
            "video" == a.g.g &&
            f.origin === a.g.o) ||
            ("loaded" == f.event.type &&
              "display" == a.g.g &&
              f.origin === a.g.u)
            ? !0
            : !1;
        })
        .map(function (f) {
          return f.event;
        }),
      c = a.g.adSessionId || "",
      d = {};
    b = p(b);
    for (var e = b.next(); !e.done; d = { F: d.F }, e = b.next()) {
      d.F = e.value;
      d.F.adSessionId || (d.F.adSessionId = c);
      if ("loaded" == d.F.type) {
        if (!a.g.h && "display" == a.g.g) continue;
        d.F.data = rb(a, sb(a, d.F.data));
      }
      a.j
        .filter(
          (function (f) {
            return function (h) {
              return h.type === f.F.type;
            };
          })(d)
        )
        .forEach(
          (function (f) {
            return function (h) {
              return h.G(f.F);
            };
          })(d)
        );
    }
  }
  function zb(a, b, c) {
    a: {
      c = new Set(c);
      a = p(a.m.concat(a.i));
      for (var d = a.next(); !d.done; d = a.next())
        if (((d = d.value), c.has(d.event.type) && d.origin != b)) {
          b = !0;
          break a;
        }
      b = !1;
    }
    return b
      ? (G(
          "Event owner cannot be registered after its events have already been published."
        ),
        !1)
      : !0;
  }
  function Ab(a, b) {
    zb(a, b, Object.values(y)) && Bb(a, b) && (a.g.o = b);
  }
  function Cb(a, b) {
    zb(a, b, ["impression"]) && Db(a, b) && (a.g.u = b);
  }
  function Db(a, b) {
    var c = a.g.u;
    return "none" != c && c != b
      ? (G("Impression event is owned by " + (a.g.u + ", not ") + (b + ".")),
        !1)
      : !0;
  }
  function Bb(a, b) {
    var c = a.g.o;
    return "none" != c && c != b
      ? (G("Media events are owned by " + (a.g.o + ", not " + b + ".")), !1)
      : !0;
  }
  function rb(a, b, c) {
    c = void 0 === c ? !1 : c;
    b = Object.assign({}, b);
    a.g.g && Object.assign(b, { mediaType: a.g.g });
    a.g.h &&
      (c || "definedByJavaScript" !== a.g.h) &&
      Object.assign(b, { creativeType: a.g.h });
    return b;
  }
  function qb(a) {
    var b = L().h;
    return b ? Object.assign({}, a, { lastActivity: b }) : a;
  }
  function sb(a, b) {
    return a.g.l ? Object.assign({}, b, { impressionType: a.g.l }) : b;
  }
  function tb(a) {
    var b = L().g;
    Object.assign(a, eb(b));
  }
  function M(a, b, c, d) {
    return new db(
      {
        adSessionId: a.g.adSessionId || "",
        timestamp: new Date().getTime(),
        type: b,
        data: d,
      },
      c
    );
  }
  function mb(a) {
    a = a.event;
    var b = a.data ? Object.assign({}, a.data) : void 0;
    "sessionStart" === a.type && (b.context = Object.assign({}, b.context));
    return {
      adSessionId: a.adSessionId,
      timestamp: a.timestamp,
      type: a.type,
      data: b,
    };
  }
  function Eb(a, b, c) {
    this.h = a;
    this.i = b;
    this.g = c;
  }
  function N(a, b, c) {
    "container" === b &&
      void 0 !== a.g.M &&
      void 0 !== a.g &&
      null != a.g.adSessionId &&
      (a.g.P = Ma(a.i, a.g.M, a.g.A, a.g.adSessionId, !0, a.g.N));
    b = a.g;
    var d = b.P,
      e = b.U;
    if (d)
      if (e) {
        b = new Ba();
        var f = d.s,
          h = d.g,
          g = d.h,
          k = e.g,
          l = e.h;
        f &&
          h &&
          g &&
          k &&
          l &&
          (Ea(b, f),
          (b.u = new z(h, !1)),
          (b.D = new z(g, !1)),
          (b.o = Object.assign([], d.o)),
          (b.j = Object.assign([], d.j)),
          (b.l = Object.assign([], d.l)),
          (b.v = Object.assign([], d.v)),
          (b.i = Object.assign([], e.i, d.i)),
          (d = b.u.x),
          (e = b.u.y),
          (k = new z(k, !1)),
          (l = new z(l, !1)),
          wa(k, d, e),
          wa(l, d, e),
          (b.g = k),
          (b.h = Ga(l, g)),
          Ia(b));
      } else b = d;
    else b = null;
    g = a.g.L;
    !b ||
      (b.O(g) && !c) ||
      ((g = Ca(b)),
      c && (g.adView.reasons = g.adView.reasons || [c]),
      (c = a.h),
      "audio" != c.g.h && ib(c, M(c, "geometryChange", "native", g)),
      (a.g.L = b));
  }
  function O(a) {
    return "object" === typeof a;
  }
  function P(a) {
    return "number" === typeof a && !isNaN(a) && 0 <= a;
  }
  function Q(a) {
    return "string" === typeof a;
  }
  function R(a, b) {
    return Q(a) && -1 !== Object.values(b).indexOf(a);
  }
  function Fb(a) {
    return !(!a || !a.tagName || "iframe" !== a.tagName.toLowerCase());
  }
  function S(a, b, c, d, e) {
    this.j = a;
    this.U = b;
    this.L = c;
    this.i = d;
    this.P = e;
    this.h = null;
    this.g = this.m = this.D = void 0;
    this.N = !0;
    this.J = void 0;
    Gb(this);
  }
  function Gb(a) {
    if (!a.h) {
      var b;
      a: {
        if (
          (b = a.j.document) &&
          b.getElementsByClassName &&
          (b = b.getElementsByClassName("omid-element"))
        ) {
          if (1 == b.length) {
            b = b[0];
            break a;
          }
          1 < b.length &&
            a.N &&
            (ob(
              a.L,
              "generic",
              "More than one element with 'omid-element' class name."
            ),
            (a.N = !1));
        }
        b = null;
      }
      if (b && b.tagName && "video" === b.tagName.toLowerCase()) a.i.j = b;
      else if (b && b.tagName) a.i.i = b;
      else return;
      Hb(a);
    }
  }
  function Hb(a) {
    a.i.j
      ? ((a.h = a.i.j), a.o())
      : a.i.i && ((a.h = a.i.i), Fb(a.h) ? a.i.s && a.o() : a.o());
  }
  function Ib(a) {
    a.g && (Fb(a.h) ? a.i.s && (a.K(), Jb(a)) : (a.K(), Jb(a)));
  }
  S.prototype.A = function () {
    this.J &&
      (this.j.document.removeEventListener("visibilitychange", this.J),
      (this.J = void 0));
  };
  S.prototype.o = function () {};
  function Jb(a) {
    a.D && ((a.i.U = a.D), N(a.U, "creative"));
  }
  function Kb(a) {
    if (a.g && a.i.s) {
      var b = new z(a.i.s, !1);
      wa(b, a.g.x, a.g.y);
      b.clipsToBounds = !0;
      return b;
    }
  }
  function T(a, b, c, d, e, f) {
    S.call(this, a, c, d, e, f);
    this.s = b;
    this.l = void 0;
  }
  v(T, S);
  T.prototype.A = function () {
    void 0 !== this.l && (this.P.clearInterval(this.l), (this.l = void 0));
    S.prototype.A.call(this);
  };
  T.prototype.o = function () {
    var a = this;
    S.prototype.o.call(this);
    null == this.h
      ? (this.l = void 0)
      : void 0 === this.l &&
        ((this.l = this.P.setInterval(function () {
          return Lb(a);
        }, 200)),
        Lb(this));
  };
  T.prototype.K = function () {
    if (this.m) {
      var a = Kb(this);
      if (a) {
        this.g.isCreative = !1;
        a.isCreative = !0;
        for (var b = !1, c = 0; c < this.g.childViews.length; c++)
          if (this.g.childViews[c].isCreative) {
            this.g.childViews[c] = a;
            b = !0;
            break;
          }
        b || this.g.childViews.push(a);
      } else this.g.isCreative = !0;
      this.D = Ma(this.s, this.m, this.i.A, this.i.adSessionId, this.I());
    }
  };
  T.prototype.I = function () {
    return !0;
  };
  function Lb(a) {
    if (void 0 !== a.l) {
      b: {
        try {
          var b = a.j.top;
          var c = 0 <= b.innerHeight && 0 <= b.innerWidth;
          break b;
        } catch (d) {}
        c = !1;
      }
      c
        ? ((c = a.j.top), (c = new z(new ab(c.innerWidth, c.innerHeight), !1)))
        : (c = new z(new ab(0, 0), !1));
      b = a.h.getBoundingClientRect();
      if (null == b.x || isNaN(b.x)) b.x = b.left;
      if (null == b.y || isNaN(b.y)) b.y = b.top;
      b = new z(b, !1);
      (c.O(a.m) && b.O(a.g)) ||
        ((a.g = b),
        (a.g.clipsToBounds = !0),
        (a.m = c),
        a.m.childViews.push(a.g),
        Ib(a));
    }
  }
  function U(a, b, c, d, e, f) {
    S.call(this, a, c, d, e, f);
    this.v = this.s = this.u = this.l = void 0;
    this.M = !1;
    this.C = void 0;
  }
  v(U, S);
  U.prototype.A = function () {
    this.l && this.l.disconnect();
    Mb(this);
    this.v &&
      ((0, this.j.removeEventListener)("resize", this.v), (this.v = void 0));
    S.prototype.A.call(this);
  };
  U.prototype.o = function () {
    S.prototype.o.call(this);
    if (
      this.h &&
      (this.l || (this.l = Nb(this)),
      Ob(this),
      Pb(this),
      Qb(this.h) && Rb(this),
      "backgrounded" === this.i.A)
    ) {
      var a = Sb(new ab(0, 0));
      this.C = this.g = this.m = a;
      Ib(this);
    }
  };
  U.prototype.K = function () {
    if (this.g && this.C) {
      var a = Kb(this);
      if (a) {
        var b = a;
        var c = this.C;
        var d = Math.max(a.x, c.x);
        var e = Math.max(a.y, c.y),
          f = Math.min(a.endX, c.endX);
        a = Math.min(a.endY, c.endY);
        f <= d || a <= e
          ? (d = null)
          : ((c = {}),
            (d = new z(
              ((c.x = d),
              (c.y = e),
              (c.width = Math.abs(f - d)),
              (c.height = Math.abs(a - e)),
              c),
              !1
            )));
        d || (d = new z({ x: 0, y: 0, width: 0, height: 0 }, !1));
      } else (b = this.g), (d = this.C);
      e = new Ba();
      this.m && Ea(e, this.m);
      e.g = b;
      e.h = d;
      Ia(e);
      this.M
        ? D(e.g)
          ? E(e, "hidden")
          : 100 === e.A || E(e, "clipped")
        : E(e, "viewport");
      this.D = e;
    }
  };
  U.prototype.I = function () {
    return !0;
  };
  function Mb(a) {
    a.u && (a.u.disconnect(), (a.u = void 0));
    a.s && (a.s.disconnect(), (a.s = void 0));
  }
  function Ob(a) {
    a.l && a.h && (a.l.unobserve(a.h), a.l.observe(a.h));
  }
  function Qb(a) {
    a = a.getBoundingClientRect();
    return 0 == a.width || 0 == a.height;
  }
  function Nb(a) {
    return new a.j.IntersectionObserver(
      function (b) {
        try {
          if (b.length) {
            for (var c, d = b[0], e = 1; e < b.length; e++)
              b[e].time > d.time && (d = b[e]);
            c = d;
            a.m = Sb(c.rootBounds);
            a.g = Sb(c.boundingClientRect);
            a.C = Sb(c.intersectionRect);
            a.M = !!c.isIntersecting;
            Ib(a);
          }
        } catch (f) {
          a.A(),
            ob(
              a.L,
              "generic",
              "Problem handling IntersectionObserver callback: " + f.message
            );
        }
      },
      {
        root: null,
        rootMargin: "0px",
        threshold: [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1],
      }
    );
  }
  function Rb(a) {
    a.j.ResizeObserver
      ? a.u ||
        ((a.u = Tb(a, function () {
          return Ub(a);
        })),
        a.u.observe(a.h))
      : a.s ||
        ((a.s = new MutationObserver(function () {
          return Ub(a);
        })),
        a.s.observe(a.h, { childList: !1, attributes: !0, subtree: !1 }));
  }
  function Pb(a) {
    a.v ||
      ((a.v = function () {
        Ob(a);
        a.h && !Qb(a.h) && Mb(a);
      }),
      (0, a.j.addEventListener)("resize", a.v));
  }
  function Ub(a) {
    a.h && !Qb(a.h) && (Ob(a), Mb(a));
  }
  function Tb(a, b) {
    return new a.j.ResizeObserver(b);
  }
  function Sb(a) {
    if (
      a &&
      null !== a.x &&
      null !== a.y &&
      null !== a.width &&
      null !== a.height
    )
      return new z(a, !1);
  }
  function Vb(a) {
    if ("object" === typeof a && "object" === typeof a.webOSSystem)
      return a.webOSSystem;
  }
  function Yb(a) {
    if ("object" === typeof a && "object" === typeof a.tizen) return a.tizen;
  }
  function Zb(a) {
    return "object" === typeof Yb(a);
  }
  function $b(a, b) {
    this.h = a;
    this.g = b;
  }
  function ac() {
    return (
      "undefined" !== typeof crypto &&
      "function" === typeof crypto.getRandomValues
    );
  }
  function bc() {
    var a = new Uint8Array(16);
    crypto.getRandomValues(a);
    a[6] = (a[6] & 15) | 64;
    a[8] = (a[8] & 63) | 128;
    for (var b = [], c = 0; 16 > c; c++)
      b.push(a[c].toString(16).padStart(2, "0"));
    return (
      b[0] +
      b[1] +
      b[2] +
      b[3] +
      "-" +
      b[4] +
      b[5] +
      "-" +
      b[6] +
      b[7] +
      "-" +
      b[8] +
      b[9] +
      "-" +
      b[10] +
      b[11] +
      b[12] +
      b[13] +
      b[14] +
      b[15]
    );
  }
  function cc() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
      /[xy]/g,
      function (a) {
        var b = (16 * Math.random()) | 0;
        return "y" === a ? ((b & 3) | 8).toString(16) : b.toString(16);
      }
    );
  }
  function dc(a, b, c) {
    var d = void 0 === d ? H : d;
    var e =
      void 0 === e
        ? function (f) {
            eval(f);
          }
        : e;
    this.j = a;
    this.g = d;
    this.i = b;
    this.l = c;
    this.m = e;
    this.h = [];
  }
  function ec(a) {
    if (!a.g)
      throw Error("OMID Service Script is not running within a window.");
    var b = void 0 !== a.g.document,
      c = void 0;
    if (!b)
      try {
        c = Va(a.l, "downloadJavaScriptResource");
      } catch (e) {}
    if (!b && void 0 === c)
      throw Error(
        "OMID Service Script does not have access to a document or native downloadJavaScriptResource method."
      );
    var d = a.h;
    a.h = [];
    d.forEach(function (e) {
      try {
        var f = ac() ? bc() : cc();
        if (b) {
          var h = a.i.J ? "limited" : "full",
            g = R(e.accessMode, ra) ? e.accessMode : null;
          var k = g
            ? "full" == g && "limited" == h
              ? h
              : "domain" == g
              ? "limited"
              : g
            : h;
          e.accessMode = k;
          a: {
            var l = e.resourceUrl;
            try {
              var m = new URL(l, a.g.location.origin);
              break a;
            } catch (J) {}
            try {
              m = new URL(l);
              break a;
            } catch (J) {}
            m = null;
          }
          (h = m) && fc(a, f, h, k);
        } else gc(a, e, f, c);
        var r = e.vendorKey,
          A = e.verificationParameters;
        r = void 0 === r ? "" : r;
        A = void 0 === A ? "" : A;
        r &&
          "string" === typeof r &&
          "" !== r &&
          A &&
          "string" === typeof A &&
          "" !== A &&
          (a.j.o[r] = A);
        a.i.C.set(f, e);
      } catch (J) {
        Pa(
          "OMID verification script " + e.resourceUrl + " failed to load: " + J
        );
      }
    });
  }
  function gc(a, b, c, d) {
    b.accessMode = "limited";
    d(
      b.resourceUrl,
      function (e) {
        var f = b.resourceUrl;
        try {
          (0, a.m)(
            "this['omidVerificationProperties'] = {\n        'serviceWindow': this,\n        'injectionSource': 'app',\n      };\n      (function(injectionId) {\n        var scopedProps = new Proxy(this.omidVerificationProperties || {},\n          {\n            get: function(target, prop) {\n              if (prop === 'injectionId') {\n                return injectionId;\n              }\n              return Reflect.get(target, prop);\n            }\n          }\n        );\n\n        var scopedGlobal = new Proxy(this, {\n          get: function(target, prop) {\n            if (prop === 'omidVerificationProperties') {\n              return scopedProps;\n            }\n            return Reflect.get(target, prop);\n          }\n        });\n\n        return (function(globalScope, omidVerificationProperties) {\n          " +
              e +
              "\n        }).call(scopedGlobal, scopedGlobal, scopedProps);\n      }).call(this, '" +
              c +
              "');\n      "
          );
        } catch (h) {
          G(
            'Error evaluating the JavaScript resource from "' +
              f +
              '": ' +
              h +
              "."
          );
        }
      },
      function (e) {
        Pa("Failed getting JS resource (" + b.resourceUrl + "): " + e);
      }
    );
  }
  function fc(a, b, c, d) {
    var e = a.g.document,
      f = e.createElement("iframe");
    f.id = "omid-verification-script-frame-" + b;
    f.style.display = "none";
    if ("full" == d) {
      var h = function () {
        var g = f.contentWindow;
        g.omidVerificationProperties = {
          serviceWindow: a.g,
          injectionSource: "app",
          injectionId: b,
        };
        g = g.document;
        var k = g.createElement("script");
        k.src = c.href;
        g.head.appendChild(k);
        f.removeEventListener("load", h);
      };
      f.addEventListener("load", h);
    } else
      "limited" == d &&
        ((f.srcdoc =
          "<html><head>\n<script type=\"text/javascript\">window['omidVerificationProperties'] = {\n'serviceWindow': window.parent,\n'injectionSource': 'app',\n'injectionId': '" +
          (b + '\',\n};\x3c/script>\n<script type="text/javascript" src="') +
          c.href +
          '">\x3c/script>\n</head><body></body></html>'),
        (f.sandbox = "allow-scripts"));
    e.body.appendChild(f);
    L().i.set(b, f);
  }
  function hc(a, b, c, d, e, f) {
    var h = this;
    this.g = a;
    this.h = b;
    this.j = c;
    this.i = d;
    this.l = e;
    this.s = f;
    this.m = !1;
    ic(this, function (g) {
      if ("sessionStart" === g.type) {
        h.m = !0;
        try {
          ec(h.l);
        } catch (k) {
          G(k.message);
        }
      }
      "sessionFinish" === g.type && (h.m = !1);
    });
  }
  function ic(a, b, c, d) {
    lb(a.h, b, c, d);
  }
  n = hc.prototype;
  n.setSlotElement = function (a) {
    a && a.tagName
      ? ((this.g.i = a), this.i && Hb(this.i))
      : G("setSlotElement called with a non-HTMLElement.  It will be ignored.");
  };
  n.setElementBounds = function (a) {
    this.g.s = a;
    this.i && Hb(this.i);
    this.i && Ib(this.i);
  };
  n.error = function (a, b) {
    ob(this.h, a, b);
  };
  n.injectVerificationScriptResources = function (a) {
    var b = this.l;
    b.h.push.apply(b.h, q(a));
    if (this.m)
      try {
        ec(this.l);
      } catch (c) {
        G(c.message);
      }
  };
  n.setCreativeType = function (a, b) {
    b = void 0 === b ? null : b;
    if (!this.g.g || this.g.h)
      (this.g.h = a),
        "video" == a || "audio" == a
          ? (this.g.g = "video")
          : "htmlDisplay" == a || "nativeDisplay" == a
          ? (this.g.g = "display")
          : "definedByJavaScript" == a &&
            b &&
            (this.g.g = "none" == b ? "display" : "video");
  };
  n.setImpressionType = function (a) {
    if (!this.g.g || this.g.h) this.g.l = a;
  };
  n.setClientInfo = function (a, b, c) {
    var d = this.g.m || {};
    d.omidJsInfo = Object.assign({}, d.omidJsInfo, {
      sessionClientVersion: a,
      partnerName: b,
      partnerVersion: c,
    });
    this.g.m = d;
    return this.g.m.omidJsInfo.serviceVersion;
  };
  function jc(a, b) {
    if (!b) return a.g;
    for (var c = p(a.h.values()), d = c.next(); !d.done; d = c.next())
      if (((d = d.value), d.g.C.has(b))) return d;
    return a.g;
  }
  function V(a, b) {
    return null == b ? a.g : a.h.get(b) || a.g;
  }
  function kc(a) {
    var b = new bb(),
      c = new fb(b),
      d = new Ka(),
      e = new La(),
      f = new Eb(c, e, b),
      h = a.i,
      g = omidGlobal;
    d = g
      ? g.IntersectionObserver && (g.MutationObserver || g.ResizeObserver)
        ? new U(g, d, f, c, b, h)
        : new T(g, e, f, c, b, h)
      : null;
    return new hc(b, c, f, d, new dc(c, b, a.i), new $b(c, b));
  }
  function lc(a) {
    return a && O(a)
      ? Object.entries(a).reduce(function (b, c) {
          var d = p(c);
          c = d.next().value;
          d = d.next().value;
          return b && Q(c) && null != d && O(d) && Q(d.resourceUrl);
        }, !0)
      : !1;
  }
  function mc(a) {
    if (!a || !O(a)) return !1;
    a = a.supportedAttestationMechanisms;
    return Array.isArray(a)
      ? a.every(function (b) {
          return (
            O(b) &&
            "mechanism" in b &&
            "version" in b &&
            "executionEnvironment" in b &&
            Q(b.mechanism) &&
            Q(b.version) &&
            Q(b.executionEnvironment)
          );
        })
      : !1;
  }
  function W(a, b, c, d) {
    this.h = a;
    this.method = b;
    this.version = c;
    this.g = d;
  }
  function nc(a) {
    return (
      !!a &&
      void 0 !== a.omid_message_guid &&
      void 0 !== a.omid_message_method &&
      void 0 !== a.omid_message_version &&
      "string" === typeof a.omid_message_guid &&
      "string" === typeof a.omid_message_method &&
      "string" === typeof a.omid_message_version &&
      (void 0 === a.omid_message_args || void 0 !== a.omid_message_args)
    );
  }
  function oc(a) {
    return new W(
      a.omid_message_guid,
      a.omid_message_method,
      a.omid_message_version,
      a.omid_message_args
    );
  }
  function pc(a) {
    var b = {};
    b =
      ((b.omid_message_guid = a.h),
      (b.omid_message_method = a.method),
      (b.omid_message_version = a.version),
      b);
    void 0 !== a.g && (b.omid_message_args = a.g);
    return b;
  }
  function qc(a) {
    this.i = a;
  }
  function X(a) {
    this.i = a;
    this.handleExportedMessage = X.prototype.j.bind(this);
  }
  v(X, qc);
  X.prototype.h = function (a, b) {
    b = void 0 === b ? this.i : b;
    if (!b)
      throw Error(
        "Message destination must be defined at construction time or when sending the message."
      );
    b.handleExportedMessage(pc(a), this);
  };
  X.prototype.j = function (a, b) {
    nc(a) && this.g && this.g(oc(a), b);
  };
  function rc(a) {
    return sc(a, "SessionService.");
  }
  function sc(a, b) {
    return (a = a.match(new RegExp("^" + b + "(.*)"))) && a[1];
  }
  function tc(a, b) {
    this.i = b = void 0 === b ? H : b;
    var c = this;
    a.addEventListener("message", function (d) {
      if ("object" === typeof d.data) {
        var e = d.data;
        nc(e) && d.source && c.g && c.g(oc(e), d.source);
      }
    });
  }
  v(tc, qc);
  tc.prototype.h = function (a, b) {
    b = void 0 === b ? this.i : b;
    if (!b)
      throw Error(
        "Message destination must be defined at construction time or when sending the message."
      );
    b.postMessage(pc(a), "*");
  };
  function uc(a, b) {
    b = void 0 === b ? {} : b;
    var c = vc("omidJsSessionService");
    if (!c) return !1;
    c.postMessage(JSON.stringify({ method: a, data: b }));
    return !0;
  }
  function vc(a) {
    return H.webkit ? H.webkit.messageHandlers[a] : H[a];
  }
  function wc(a) {
    if (H.document) {
      var b = H.document.createElement("iframe");
      b.style.display = "none";
      b.src = a;
      a = function () {
        var c = H.document.body || H.document.documentElement;
        c &&
          (c.appendChild(b),
          setTimeout(function () {
            b.parentNode && b.parentNode.removeChild(b);
          }, 100));
      };
      "loading" === H.document.readyState
        ? H.document.addEventListener("DOMContentLoaded", a)
        : a();
    }
  }
  function xc() {
    this.g = yc;
  }
  n = xc.prototype;
  n.registerSessionObserver = function (a, b) {
    ic(V(this.g, a), b);
  };
  n.setSlotElement = function (a, b) {
    V(this.g, a).setSlotElement(b);
  };
  n.setElementBounds = function (a, b) {
    V(this.g, a).setElementBounds(b);
  };
  function zc(a, b, c, d, e) {
    e = void 0 === e ? null : e;
    a = V(a.g, b);
    var f = a.g.m;
    f.sessionOwner || (f.sessionOwner = d ? "native" : "javascript");
    d
      ? ((b = b || (ac() ? bc() : cc())),
        (a.g.adSessionId = b),
        (c.canMeasureVisibility = a.i.I()),
        cb(a.g, c),
        pb(a.h, e),
        a.i && Gb(a.i))
      : b
      ? (cb(a.g, c),
        uc("startSession", { adSessionId: b }) ||
          G(
            "On App, the native-layer JS Session Service must be initialized before starting an ad session using the JS API."
          ))
      : G("Session client must be updated to start an App session from JS.");
  }
  function Ac(a, b, c) {
    c
      ? ((b = V(a.g, b)),
        (a = a.g),
        (a.g = kc(a)),
        vb(b.h),
        b.i.A(),
        b.o && (b.o.stop(), (b.o = null)))
      : b
      ? uc("finishSession", { adSessionId: b }) ||
        G(
          "On App, the native-layer JS Session Service must be initialized before finishing an ad session using the JS API."
        )
      : G("Session client must be updated to finish an App session from JS.");
  }
  n.error = function (a, b, c) {
    V(this.g, a).error(b, c);
  };
  function Y(a, b, c, d) {
    a = V(a.g, b);
    "impression" == c
      ? Db(a.h, "javascript") && (wb(a.h, "javascript"), a.i && Gb(a.i))
      : ("loaded" == c
          ? ((d = void 0 === d ? null : d),
            Bb(a.h, "javascript") && xb(a.h, "javascript", d))
          : Bb(a.h, "javascript") && yb(a.h, c, "javascript", d),
        ["loaded", "start"].includes(c) && a.i && Gb(a.i));
  }
  n.injectVerificationScriptResources = function (a, b) {
    V(this.g, a).injectVerificationScriptResources(b);
  };
  n.setCreativeType = function (a, b, c) {
    c = void 0 === c ? null : c;
    V(this.g, a).setCreativeType(b, c);
  };
  n.setImpressionType = function (a, b) {
    V(this.g, a).setImpressionType(b);
  };
  n.setClientInfo = function (a, b, c, d) {
    var e = this.g;
    if (null == a) a = e.g;
    else {
      var f = [].concat(q(e.h.values())).includes(e.g) ? kc(e) : e.g;
      e.h.set(a, f);
      a = f;
    }
    return a.setClientInfo(b, c, d);
  };
  function Bc(a) {
    a = a.split("-")[0].split(".");
    for (var b = ["1", "0", "3"], c = 0; 3 > c; c++) {
      var d = parseInt(a[c], 10),
        e = parseInt(b[c], 10);
      if (d > e) break;
      else if (d < e) return !1;
    }
    return !0;
  }
  function Cc(a, b) {
    return /\d+\.\d+\.\d+(-.*)?/.test(a) && Bc(a) ? b : JSON.stringify(b);
  }
  function Dc(a, b) {
    return /\d+\.\d+\.\d+(-.*)?/.test(a) && Bc(a)
      ? b
        ? b
        : []
      : b && "string" === typeof b
      ? JSON.parse(b)
      : [];
  }
  function Ec() {
    var a = Fc;
    var b = void 0 === b ? omidGlobal : b;
    this.g = a;
    this.h = b;
    this.j = new X();
    this.h.omid = this.h.omid || {};
    this.h.omid.v1_SessionServiceCommunication = this.j;
    this.i = b && b.addEventListener && b.postMessage ? new tc(b) : null;
    this.j.g = this.m.bind(this);
    this.i && (this.i.g = this.l.bind(this));
  }
  Ec.prototype.m = function (a, b) {
    null != rc(a.method) && Gc(this, a, b, this.j);
  };
  Ec.prototype.l = function (a, b) {
    null != rc(a.method) && Gc(this, a, b, this.i);
  };
  function Gc(a, b, c, d) {
    function e() {
      var k = new W(f, "response", g, Cc(g, w.apply(0, arguments)));
      d.h(k, c);
    }
    var f = b.h,
      h = b.method,
      g = b.version;
    b = Dc(g, b.g);
    try {
      Hc(a, h, e, b);
    } catch (k) {
      d.h(
        new W(
          f,
          "error",
          g,
          "\n        name: " +
            k.name +
            "\n        message: " +
            k.message +
            "\n        filename: " +
            k.filename +
            "\n        lineNumber: " +
            k.lineNumber +
            "\n        columnNumber: " +
            k.columnNumber +
            "\n        stack: " +
            k.stack +
            "\n        toString(): " +
            k.toString()
        ),
        c
      );
    }
  }
  function Hc(a, b, c, d) {
    if (null != rc(b))
      switch (rc(b)) {
        case "registerAdEvents":
          c = p(d).next().value;
          Cb(V(a.g.g, c).h, "javascript");
          break;
        case "registerMediaEvents":
          c = p(d).next().value;
          Ab(V(a.g.g, c).h, "javascript");
          break;
        case "registerSessionObserver":
          var e = p(d).next().value;
          a.g.registerSessionObserver(e, c);
          break;
        case "setSlotElement":
          e = p(d);
          c = e.next().value;
          e = e.next().value;
          a.g.setSlotElement(e, c);
          break;
        case "setVideoElement":
          e = p(d);
          c = e.next().value;
          e = e.next().value;
          a = V(a.g.g, e);
          c && c.tagName && "video" === c.tagName.toLowerCase()
            ? ((a.g.j = c), a.i && Hb(a.i))
            : G(
                "setVideoElement called with a non-HTMLVideoElement. It will be ignored."
              );
          break;
        case "setElementBounds":
          e = p(d);
          c = e.next().value;
          e = e.next().value;
          a.g.setElementBounds(e, c);
          break;
        case "startSession":
          c = p(d);
          d = c.next().value;
          c = c.next().value;
          b = a.h;
          if (null != d && O(d)) {
            var f = d.customReferenceData,
              h = d.underEvaluation,
              g = d.universalAdId;
            Q(f) || (f = void 0);
            "boolean" === typeof h || (h = !1);
            d = { customReferenceData: f, underEvaluation: h };
            Q(g) && (d.universalAdId = g);
            if ("object" === typeof Vb(b)) {
              var k = Vb(b),
                l;
              "object" === typeof k && (l = k.identifier);
              d.app = { appId: l && "string" === typeof l ? l : void 0 };
              b: if (((k = Vb(b)), "object" === typeof k)) {
                try {
                  e = JSON.parse(k.deviceInfo);
                } catch (A) {
                  e = void 0;
                  break b;
                }
                e = {
                  deviceType: e.modelName || "Unknown",
                  osVersion: e.platformVersion || "Unknown",
                  os: "webOS",
                };
              } else e = void 0;
              d.deviceInfo = e;
              d.deviceCategory = "ctv";
            } else if (Zb(b)) {
              b: {
                if (Zb(b)) {
                  try {
                    var m =
                      Yb(b).application.getCurrentApplication().appInfo.id;
                  } catch (A) {
                    e = void 0;
                    break b;
                  }
                  if ("string" === typeof m) {
                    e = m;
                    break b;
                  }
                }
                e = void 0;
              }
              d.app = { appId: e };
              if (Zb(b)) {
                e = Yb(b).systeminfo;
                if (
                  "object" === typeof e &&
                  "function" === typeof e.getCapability
                ) {
                  k = e.getCapability("http://tizen.org/system/model_name");
                  var r = e.getCapability(
                    "http://tizen.org/feature/platform.version"
                  );
                }
                e = {
                  deviceType: k || "Unknown",
                  osVersion: r || "Unknown",
                  os: "tizen",
                };
              } else e = void 0;
              d.deviceInfo = e;
              Zb(b) &&
                "object" === typeof Yb(b).tvinputdevice &&
                (d.deviceCategory = "ctv");
            }
          } else d = null;
          if (null == d) break;
          zc(a.g, c, d, !1);
          break;
        case "finishSession":
          c = p(d).next().value;
          Ac(a.g, c, !1);
          break;
        case "impressionOccurred":
          c = p(d).next().value;
          Y(a.g, c, "impression");
          break;
        case "loaded":
          e = p(d);
          c = e.next().value;
          e = e.next().value;
          c
            ? ((k = {
                skippable: c.isSkippable,
                autoPlay: c.isAutoPlay,
                position: c.position,
              }),
              c.isSkippable && (k.skipOffset = c.skipOffset),
              Y(a.g, e, "loaded", k))
            : Y(a.g, e, "loaded");
          break;
        case "start":
          k = p(d);
          c = k.next().value;
          e = k.next().value;
          k = k.next().value;
          Y(a.g, k, "start", { duration: c, mediaPlayerVolume: e });
          break;
        case "firstQuartile":
          c = p(d).next().value;
          Y(a.g, c, "firstQuartile");
          break;
        case "midpoint":
          c = p(d).next().value;
          Y(a.g, c, "midpoint");
          break;
        case "thirdQuartile":
          c = p(d).next().value;
          Y(a.g, c, "thirdQuartile");
          break;
        case "complete":
          c = p(d).next().value;
          Y(a.g, c, "complete");
          break;
        case "pause":
          c = p(d).next().value;
          Y(a.g, c, "pause");
          break;
        case "resume":
          c = p(d).next().value;
          Y(a.g, c, "resume");
          break;
        case "bufferStart":
          c = p(d).next().value;
          Y(a.g, c, "bufferStart");
          break;
        case "bufferFinish":
          c = p(d).next().value;
          Y(a.g, c, "bufferFinish");
          break;
        case "skipped":
          c = p(d).next().value;
          Y(a.g, c, "skipped");
          break;
        case "volumeChange":
          e = p(d);
          c = e.next().value;
          e = e.next().value;
          Y(a.g, e, "volumeChange", { mediaPlayerVolume: c });
          break;
        case "playerStateChange":
          e = p(d);
          c = e.next().value;
          e = e.next().value;
          Y(a.g, e, "playerStateChange", { state: c });
          break;
        case "adUserInteraction":
          e = p(d);
          c = e.next().value;
          e = e.next().value;
          Y(a.g, e, "adUserInteraction", { interactionType: c });
          break;
        case "setClientInfo":
          l = p(d);
          e = l.next().value;
          k = l.next().value;
          r = l.next().value;
          l = l.next().value;
          a = a.g.setClientInfo(l, e, k, r);
          c(a);
          break;
        case "injectVerificationScriptResources":
          e = p(d);
          c = e.next().value;
          e = e.next().value;
          a.g.injectVerificationScriptResources(e, c);
          break;
        case "setCreativeType":
          e = p(d);
          c = e.next().value;
          e = e.next().value;
          a.g.setCreativeType(e, c);
          break;
        case "setImpressionType":
          e = p(d);
          c = e.next().value;
          e = e.next().value;
          a.g.setImpressionType(e, c);
          break;
        case "setContentUrl":
          e = p(d);
          c = e.next().value;
          e = e.next().value;
          V(a.g.g, e).g.D = c;
          break;
        case "sessionError":
          (k = p(d)),
            (c = k.next().value),
            (e = k.next().value),
            (k = k.next().value),
            a.g.error(k, c, e);
      }
  }
  function Z() {
    this.g = Fc;
  }
  n = Z.prototype;
  n.ea = function (a, b) {
    if (
      !(
        !(a && O(a) && R(a.impressionOwner, qa)) ||
        ("videoEventsOwner" in a &&
          null != a.videoEventsOwner &&
          !R(a.videoEventsOwner, qa)) ||
        ("mediaEventsOwner" in a &&
          null != a.mediaEventsOwner &&
          !R(a.mediaEventsOwner, qa))
      )
    ) {
      b = V(this.g.g, b);
      if (a.creativeType && a.impressionType) {
        var c = a.mediaEventsOwner;
        null == b.g.h && b.setCreativeType(a.creativeType, c);
        null == b.g.l && (b.g.l = a.impressionType);
        Ab(b.h, c);
      } else
        (c = a.videoEventsOwner),
          (b.g.g = null == c || "none" === c ? "display" : "video"),
          (b.g.h = null),
          (b.g.l = null),
          Ab(b.h, c);
      Cb(b.h, a.impressionOwner);
      a &&
        null != a.isolateVerificationScripts &&
        "boolean" === typeof a.isolateVerificationScripts &&
        (b.g.J = a.isolateVerificationScripts);
    }
  };
  n.ca = function (a, b, c, d) {
    b &&
      "string" === typeof b.adSessionType &&
      (b.adSessionType = b.adSessionType.toLowerCase());
    var e;
    if (O(b)) {
      if ((e = R(b.environment, ua) && R(b.adSessionType, pa)))
        (e = b.omidNativeInfo),
          (e = O(e) ? Q(e.partnerName) && Q(e.partnerVersion) : !1);
      e && ((e = b.app), (e = O(e) ? Q(e.libraryVersion) && Q(e.appId) : !1));
    } else e = !1;
    if (e) {
      if (lc(d)) {
        e = p(Object.values(d));
        for (var f = e.next(); !f.done; f = e.next())
          f.value.accessMode = "limited";
        V(this.g.g, a).g.C = new Map(Object.entries(d));
      }
      zc(this.g, a, b, !0, c);
    } else G("Native ad session context invalid; session not started.");
  };
  n.Y = function (a) {
    Ac(this.g, a, !0);
  };
  n.ba = function (a, b) {
    O(a) &&
      P(a.x) &&
      P(a.y) &&
      P(a.width) &&
      P(a.height) &&
      ((b = V(this.g.g, b)), (b.g.M = a), N(b.j, "container"));
  };
  n.ia = function (a, b) {
    R(a, sa) &&
      ((b = V(this.g.g, b)),
      (b.g.A = a),
      "backgrounded" === a
        ? N(b.j, "container", "backgrounded")
        : N(b.j, "container"));
  };
  n.$ = function (a, b) {
    R(a, ta) &&
      ((b = V(this.g.g, b)),
      (b.g.N = a),
      "locked" === a
        ? N(b.j, "container", "deviceLocked")
        : N(b.j, "container"));
  };
  n.fa = function (a) {
    "impression" === a && this.V();
  };
  n.V = function (a) {
    a = V(this.g.g, a);
    Db(a.h, "native") && wb(a.h, "native");
  };
  n.Z = function (a, b) {
    this.T("loaded", void 0 === a ? null : a, b);
  };
  n.error = function (a, b, c) {
    R(a, oa) && this.g.error(c, a, b);
  };
  n.ga = function (a, b, c) {
    this.T(a, b, c);
  };
  n.T = function (a, b, c) {
    R(a, y) &&
      (void 0 === b || O(b)) &&
      ((c = V(this.g.g, c)),
      Bb(c.h, "native") &&
        ("loaded" == a ? xb(c.h, "native", b) : yb(c.h, a, "native", b)));
  };
  n.aa = function (a, b) {
    b = V(this.g.g, b);
    "none" === b.h.g.o ||
      "number" !== typeof a ||
      isNaN(a) ||
      ((b.g.I = a),
      (a = b.s),
      (b = a.g.K),
      null != b &&
        yb(a.h, "volumeChange", "native", {
          mediaPlayerVolume: b,
          deviceVolume: a.g.I,
        }));
  };
  n.ha = function (a) {
    if (a && O(a) && P(a.timestamp)) {
      var b = L(),
        c = (b.h || {}).timestamp;
      if (!c || c < a.timestamp) b.h = a;
    }
  };
  n.ja = function (a) {
    var b = L();
    mc(a) ? (b.g = a.supportedAttestationMechanisms) : (b.g = []);
  };
  Z.prototype.startSession = Z.prototype.ca;
  Z.prototype.error = Z.prototype.error;
  Z.prototype.finishSession = Z.prototype.Y;
  Z.prototype.publishAdEvent = Z.prototype.fa;
  Z.prototype.publishImpressionEvent = Z.prototype.V;
  Z.prototype.publishVideoEvent = Z.prototype.ga;
  Z.prototype.publishMediaEvent = Z.prototype.T;
  Z.prototype.publishLoadedEvent = Z.prototype.Z;
  Z.prototype.setNativeViewHierarchy = Z.prototype.ba;
  Z.prototype.setState = Z.prototype.ia;
  Z.prototype.setDeviceLockState = Z.prototype.$;
  Z.prototype.setDeviceVolume = Z.prototype.aa;
  Z.prototype.init = Z.prototype.ea;
  Z.prototype.setLastActivity = Z.prototype.ha;
  Z.prototype.setSupportedAttestations = Z.prototype.ja;
  function Ic() {
    var a = yc,
      b = Jc,
      c = this;
    var d = void 0 === d ? H : d;
    this.i = a;
    this.g = b;
    this.l = {};
    this.m = {};
    this.j = new X();
    d.omid = d.omid || {};
    d.omid.v1_VerificationServiceCommunication = this.j;
    this.h = null;
    d && d.addEventListener && d.postMessage && (this.h = new tc(d));
    this.j.g = function (e, f) {
      Kc(c, e, f, c.j);
    };
    this.h &&
      (this.h.g = function (e, f) {
        c.h && Kc(c, e, f, c.h);
      });
  }
  function Lc(a, b, c, d) {
    a = jc(a.i, d).h;
    "media" === b || "video" === b
      ? kb(a, c, d)
      : ((c = { type: b, S: d, G: c }), a.j.push(c), jb(a, b, c));
  }
  function Mc(a, b, c, d) {
    a = jc(a.i, d);
    ic(a, b, c, d);
  }
  function Nc(a, b, c, d, e, f, h) {
    h = jc(a.i, h);
    var g =
      2 <= h.g.v.g
        ? { R: !1, reason: "SESSION_ATTESTATION_LIMIT_EXCEEDED" }
        : h.g.v.h.has(f)
        ? { R: !1, reason: "TOO_MANY_REQUESTS" }
        : 0.5 <= Math.random()
        ? { R: !1, reason: "SAMPLING_REJECTED" }
        : { R: !0, reason: null };
    h.g.v.h.add(f);
    if (g.R)
      if ((h.g.v.g++, (f = h.g.adSessionId), "ApplePAT" === b))
        Xa(a.g, d.Oa, e);
      else
        try {
          a = {};
          for (var k in d) d.hasOwnProperty(k) && (a[k.toLowerCase()] = d[k]);
          var l = vc("omidJsAttestationListener");
          if (l)
            l.postMessage(
              JSON.stringify({
                method: "attest",
                data: {
                  adSessionId: f,
                  mechanism: b,
                  version: c,
                  attestationArgs: a,
                },
              })
            );
          else {
            d = "";
            for (var m in a) a.hasOwnProperty(m) && (d += "&" + m + "=" + a[m]);
            wc(
              "omid-native://?method=attest&adSessionId=" +
                f +
                "&mechanism=" +
                b +
                "&version=" +
                c +
                d
            );
          }
          e(!0, "SUCCESS");
        } catch (r) {
          G("Failed to trigger native-layer attestation method: " + r.message),
            e(!1, "FAILED_TO_TRIGGER_ATTESTATION");
        }
    else e(!1, g.reason);
  }
  function Oc(a, b, c, d) {
    Wa(a.g, b, c, d);
  }
  Ic.prototype.setInterval = function (a, b) {
    return this.g.setInterval(a, b);
  };
  Ic.prototype.clearInterval = function (a) {
    this.g.clearInterval(a);
  };
  function Pc(a, b, c, d) {
    Va(a.g, "downloadJavaScriptResource")(b, c, d);
  }
  function Kc(a, b, c, d) {
    function e() {
      var F = new W(f, "response", g, Cc(g, w.apply(0, arguments)));
      d.h(F, c);
    }
    var f = b.h,
      h = b.method,
      g = b.version;
    b = Dc(g, b.g);
    if (null != sc(h, "VerificationService.")) {
      h = sc(h, "VerificationService.");
      try {
        switch (h) {
          case "addEventListener":
            var k = p(b),
              l = k.next().value,
              m = k.next().value || Qc(c);
            Lc(a, l, e, m);
            break;
          case "addSessionListener":
            var r = p(b),
              A = r.next().value,
              J = r.next().value || Qc(c);
            Mc(a, e, A, J);
            break;
          case "attest":
            var I = p(b),
              K = I.next().value,
              Uc = I.next().value,
              Vc = I.next().value,
              Wc = I.next().value,
              Xc = I.next().value || Qc(c);
            Nc(a, K, Uc, Vc, e, Wc, Xc);
            break;
          case "sendUrl":
            var Yc = p(b).next().value;
            Oc(
              a,
              Yc,
              function () {
                return e(!0);
              },
              function () {
                return e(!1);
              }
            );
            break;
          case "setTimeout":
            var Wb = p(b),
              Zc = Wb.next().value,
              $c = Wb.next().value;
            a.l[Zc] = Ta(a.g, "setTimeout")(e, $c);
            break;
          case "clearTimeout":
            var ad = p(b).next().value;
            Ua(a.g, a.l[ad]);
            break;
          case "setInterval":
            var Xb = p(b),
              bd = Xb.next().value,
              cd = Xb.next().value;
            a.m[bd] = a.setInterval(e, cd);
            break;
          case "clearInterval":
            var dd = p(b).next().value;
            a.clearInterval(a.m[dd]);
            break;
          case "injectJavaScriptResource":
            var ed = p(b).next().value;
            Pc(
              a,
              ed,
              function (F) {
                return e(!0, F);
              },
              function () {
                return e(!1);
              }
            );
            break;
          case "getVersion":
            e("1.6.11-google36");
        }
      } catch (F) {
        d.h(
          new W(
            f,
            "error",
            g,
            "\n              name: " +
              F.name +
              "\n              message: " +
              F.message +
              "\n              filename: " +
              F.filename +
              "\n              lineNumber: " +
              F.lineNumber +
              "\n              columnNumber: " +
              F.columnNumber +
              "\n              stack: " +
              F.stack +
              "\n              toString(): " +
              F.toString() +
              "\n          "
          ),
          c
        );
      }
    }
  }
  function Qc(a) {
    for (var b = L().i, c = p(b.keys()), d = c.next(); !d.done; d = c.next()) {
      d = d.value;
      var e = b.get(d);
      if (e) {
        if (e.contentWindow === a) return d;
        try {
          if (e.contentWindow.Object.prototype.isPrototypeOf(a)) return d;
        } catch (f) {}
      }
    }
  }
  function Rc(a) {
    var b = {};
    return ((b.app = "omid_v1_present_app"),
    (b.web = "omid_v1_present_web"),
    b)[a];
  }
  function Sc(a, b) {
    a.document.write(
      '<iframe style="display:none" id="' +
        (b + '" name="' + b + '" sandbox></iframe>')
    );
  }
  function Tc(a, b) {
    var c = a.document.createElement("iframe");
    c.id = b;
    c.name = b;
    c.style.display = "none";
    c.sandbox = "";
    a.document.body.appendChild(c);
  }
  function fd(a, b) {
    var c = new MutationObserver(function (d) {
      d.forEach(function (e) {
        "BODY" === e.addedNodes[0].nodeName &&
          ((e = Rc(b)), Tc(a, "omid_v1_present"), Tc(a, e), c.disconnect());
      });
    });
    c.observe(a.document.documentElement, { childList: !0 });
  }
  var Jc = new Sa(),
    yc = new (function () {
      this.i = Jc;
      this.h = new Map();
      this.g = kc(this);
    })(),
    Fc = new xc();
  new Ic();
  H.omidBridge = new Z();
  new Ec();
  (function (a, b) {
    a.frames &&
      a.document &&
      !["omid_v1_present", "omid_v1_present_web", "omid_v1_present_app"].some(
        function (c) {
          return !!a.frames[c];
        }
      ) &&
      (null == a.document.body && "MutationObserver" in a
        ? fd(a, b)
        : ((b = Rc(b)),
          a.document.body
            ? (Tc(a, "omid_v1_present"), Tc(a, b))
            : (Sc(a, "omid_v1_present"), Sc(a, b))));
  })(H, "app");
}.call(this, this));
