/**
 * MRC viewability script for sandboxed API iframe.
 * Deploy this to your CDN (e.g. https://cdn-view-abilit.js).
 * Mirrors @supply-ui-ads/viewability-tracker logic: poll every 100ms for creative
 * element; when found, 50% visible for 9 consecutive ticks then __inmobiMrcViewable.
 * If no creative found, keep polling until CREATIVE_POLL_TIMEOUT_MS (no body fallback).
 */
(function () {
  "use strict";

  var MIN_AD_SIZE = 30;
  var MIN_INTERSECTION_AREA = 0.5;
  var POLL_INTERVAL_MS = 100;
  var REQUIRED_CONSECUTIVE_COUNTS = 9; /* 900ms continuous, matches viewability-tracker */
  var CREATIVE_POLL_TIMEOUT_MS = 15000; /* matches viewability-tracker setTimeout */

  function getStyle(el, prop) {
    if (typeof window.getComputedStyle !== "function") return "";
    return window.getComputedStyle(el)[prop] || "";
  }

  /**
   * Same order as findLargeImagesAndIframes: img, video, canvas, iframe, div with bg.
   * Returns element or null if none found (no body fallback).
   */
  function findCreativeElement() {
    var doc = document;
    var images = Array.prototype.slice.call(doc.querySelectorAll("img"), 0);
    var videos = Array.prototype.slice.call(doc.querySelectorAll("video"), 0);
    var canvases = Array.prototype.slice.call(
      doc.querySelectorAll("canvas"),
      0
    );
    var iframes = Array.prototype.slice.call(doc.querySelectorAll("iframe"), 0);
    var divs = Array.prototype.slice.call(doc.querySelectorAll("div"), 0);
    var divsWithBg = divs.filter(function (div) {
      return getStyle(div, "backgroundImage") !== "none";
    });

    function isLarge(el) {
      var w = el.offsetWidth || 0;
      var h = el.offsetHeight || 0;
      return w > MIN_AD_SIZE && h > MIN_AD_SIZE;
    }

    var i;
    for (i = 0; i < images.length; i++) {
      if (isLarge(images[i])) return images[i];
    }
    for (i = 0; i < videos.length; i++) {
      if (isLarge(videos[i])) return videos[i];
    }
    for (i = 0; i < canvases.length; i++) {
      if (isLarge(canvases[i])) return canvases[i];
    }
    for (i = 0; i < iframes.length; i++) {
      if (isLarge(iframes[i])) return iframes[i];
    }
    for (i = 0; i < divsWithBg.length; i++) {
      var rect = divsWithBg[i].getBoundingClientRect();
      if (rect.width > MIN_AD_SIZE && rect.height > MIN_AD_SIZE) {
        return divsWithBg[i];
      }
    }
    return null;
  }

  function checkBannerViewability(target) {
    var isCreativeVisible = false;
    var observer = null;

    if (typeof IntersectionObserver !== "undefined") {
      observer = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            isCreativeVisible = entry.isIntersecting;
          });
        },
        { root: null, threshold: MIN_INTERSECTION_AREA }
      );
      observer.observe(target);
    } else {
      isCreativeVisible = true;
    }

    var count = 0;
    var interval = setInterval(function () {
      var inView;
      if (observer) {
        inView = isCreativeVisible;
      } else {
        var rect = target.getBoundingClientRect();
        var vh = window.innerHeight || document.documentElement.clientHeight;
        var vw = window.innerWidth || document.documentElement.clientWidth;
        var area = rect.width * rect.height;
        if (area <= 0) {
          inView = false;
        } else {
          var ix = Math.max(
            0,
            Math.min(rect.right, vw) - Math.max(rect.left, 0)
          );
          var iy = Math.max(
            0,
            Math.min(rect.bottom, vh) - Math.max(rect.top, 0)
          );
          inView = ix * iy >= MIN_INTERSECTION_AREA * area;
        }
      }

      if (inView) {
        count += 1;
        if (count >= REQUIRED_CONSECUTIVE_COUNTS) {
          clearInterval(interval);
          if (observer && observer.disconnect) observer.disconnect();
          var r = target.getBoundingClientRect();
          try {
            window.__inmobiMrcViewable({
              width: Math.round(r.width || 0),
              height: Math.round(r.height || 0),
            });
          } catch (e) {}
        }
      } else {
        count = 0;
      }
    }, POLL_INTERVAL_MS);

    /* safety: stop viewability check after 2 minutes */
    setTimeout(function () {
      clearInterval(interval);
      if (observer && observer.disconnect) observer.disconnect();
    }, 120000);
  }

  function run() {
    if (typeof window.__inmobiMrcViewable !== "function") return;

    /* Poll for creative element every 100ms; when found, start banner viewability (else keep polling). */
    var intervalId = setInterval(function () {
      var largeElement = findCreativeElement();
      if (largeElement) {
        clearInterval(intervalId);
        checkBannerViewability(largeElement);
      }
    }, POLL_INTERVAL_MS);

    /* Matches viewability-tracker: stop polling if creative never found */
    setTimeout(function () {
      clearInterval(intervalId);
    }, CREATIVE_POLL_TIMEOUT_MS);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", run);
  } else {
    run();
  }
})();
