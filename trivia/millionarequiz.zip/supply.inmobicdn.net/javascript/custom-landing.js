!(function () {
  "use strict";
  var t = !1,
    e = (document.currentScript && document.currentScript.src) || "";
  function n(t, e) {
    try {
      window.parent.postMessage({ eventType: t, eventData: e }, "*");
    } catch (t) {}
  }
  function c(t, e) {
    return null == t || "" === t ? e : "true" === t || "1" === t;
  }
  function r(e, n) {
    if (!t) {
      t = !0;
      var c = "touchstart" === e ? n.touches[0] : n.changedTouches[0];
      if (c)
        !(function (t, e) {
          try {
            var n = window.innerHeight,
              c = (function (t, e, n) {
                try {
                  var c = t[0],
                    r = t[1],
                    i = e[0],
                    o = e[1],
                    a = n[0],
                    u = n[1],
                    d = a;
                  a < c ? (d = c) : a > i && (d = i);
                  var l = u;
                  return u < r ? (l = r) : u > o && (l = o), [d, l];
                } catch (t) {
                  return [100, 10];
                }
              })([20, 10], [window.innerWidth - 20, n - 10], [t, e]),
              r = document.elementFromPoint(c[0], c[1]);
            if (r) {
              var i = new MouseEvent("click", {
                view: window,
                bubbles: !0,
                cancelable: !0,
                clientX: c[0],
                clientY: c[1],
              });
              r.dispatchEvent(i);
            }
          } catch (t) {}
        })(c.clientX, c.clientY);
      else t = !1;
    }
  }
  var i = window.open,
    o = !1;
  function a(t, e) {
    try {
      e.isTouchStartGestureEnabled &&
        t.addEventListener("touchstart", function (t) {
          r("touchstart", t);
        }),
        t.addEventListener("click", function (t) {
          n("iframe-clicked", { clientX: t.clientX, clientY: t.clientY });
        });
      for (var c = t.querySelectorAll("iframe"), i = 0; i < c.length; i++)
        try {
          var o = c[i].contentDocument || c[i].contentWindow.document;
          o && a(o, e);
        } catch (t) {}
    } catch (t) {}
  }
  window.open = function (t, e, c) {
    return o
      ? null
      : ((o = !0),
        setTimeout(function () {
          o = !1;
        }, 200),
        n("creative-window-open", { url: t }),
        i.call(window, t, e || "_blank", c));
  };
  var u = "__inm_click";
  function d(t) {
    try {
      for (var e = t.querySelectorAll("a"), c = 0; c < e.length; c++)
        (function (t) {
          t[u] ||
            ((t[u] = !0),
            t.addEventListener("click", function (e) {
              e.preventDefault(),
                n("creative-anchor-click", { url: t.href }),
                window.open(t.href, "_blank");
            }));
        })(e[c]);
    } catch (t) {}
  }
  function l() {
    var t = (function () {
      var t = { isTouchStartGestureEnabled: !1, isTouchEndGestureEnabled: !1 };
      try {
        var n = e;
        if (!n) {
          var r = document.getElementsByTagName("script");
          r && r.length > 0 && (n = r[r.length - 1].src || "");
        }
        if (!n) return t;
        var i = new URL(n, window.location.href).searchParams;
        return {
          isTouchStartGestureEnabled: c(
            i.get("isTouchStartGestureEnabled"),
            !1
          ),
          isTouchEndGestureEnabled: c(i.get("isTouchEndGestureEnabled"), !1),
        };
      } catch (e) {
        return t;
      }
    })();
    !(function () {
      try {
        var t = window.mraid;
        if (!t || "function" != typeof t.open) return;
        var e = !1;
        t.open = function (t) {
          e ||
            ((e = !0),
            setTimeout(function () {
              e = !1;
            }, 200),
            window.open(t, "_blank"),
            n("creative-mraid-open", { url: t }));
        };
      } catch (t) {}
    })(),
      a(document, t),
      d(document);
  }
  "complete" === document.readyState || "interactive" === document.readyState
    ? l()
    : document.addEventListener("DOMContentLoaded", l),
    window.addEventListener("load", function () {
      d(document);
    });
})();
