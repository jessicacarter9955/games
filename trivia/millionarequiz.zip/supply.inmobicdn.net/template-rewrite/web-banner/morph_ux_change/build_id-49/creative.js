!(function () {
  "use strict";
  const e = "inmobi-banner:custom-beacon";
  function i(i) {
    window.dispatchEvent(new CustomEvent(e, { detail: i, bubbles: !1 }));
  }
  let t = !1,
    n = null,
    r = "";
  const a = [];
  let o = null;
  function s() {
    if (0 === a.length || !n) return;
    const e = a.splice(0, 20),
      i = {
        project: n.project,
        version: n.version,
        metadata: { userAgent: navigator.userAgent },
        vitals: n.vitals,
        log: e,
      };
    try {
      const e = new XMLHttpRequest();
      e.open(
        "POST",
        "https://log-activity.templates.inmobi.com/api/v1/ingest",
        !0
      ),
        e.setRequestHeader("Content-type", "application/json; charset=utf-8"),
        e.send(JSON.stringify({ data: i }));
    } catch (e) {}
  }
  function c(e) {
    (n = e),
      (r = new Date().toISOString()),
      (function () {
        try {
          const e = window.location.hostname;
          return "localhost" === e || "127.0.0.1" === e;
        } catch (e) {
          return !1;
        }
      })()
        ? (t = !1)
        : ((t =
            e.isServerSideLogging ||
            (function (e) {
              const i = Math.random(),
                t = (i, t) => e > i && e <= t;
              return i < 1e-6
                ? t(0, 1e-6)
                : i < 1e-5
                ? t(1e-6, 1e-5)
                : i < 1e-4
                ? t(1e-5, 1e-4)
                : i < 0.001
                ? t(1e-4, 0.001)
                : i < 0.01
                ? t(0.001, 0.01)
                : i < 0.1
                ? t(0.01, 0.1)
                : t(0.1, 1);
            })(e.scale)),
          t && !o && (o = setInterval(s, 1e3)));
  }
  function l(e, i, n, o) {
    if (!t) return;
    const s =
      void 0 !== o
        ? `${n} ${(function (e) {
            if ("string" == typeof e) return e;
            if (e instanceof Error) return e.message || e.toString();
            try {
              return JSON.stringify(e);
            } catch (i) {
              return String(e) || "[unserializable]";
            }
          })(o)}`
        : n;
    a.push({
      scope: { name: e, type: i },
      timestamps: { initializedAt: r, loggedAt: new Date().toISOString() },
      log: s,
    });
  }
  class d {
    static enable() {
      d.enabled = !0;
    }
    static disable() {
      d.enabled = !1;
    }
    static isEnabled() {
      return d.enabled;
    }
    static info(e, i, t) {
      d.enabled && l(e, "INFO", i, t);
    }
    static warn(e, i, t) {
      d.enabled && l(e, "WARNING", i, t);
    }
    static error(e, i, t) {
      d.enabled && l(e, "ERROR", i, t);
    }
    static beacon(e, i, t) {
      d.enabled && l("Lifecycle", "INFO", i);
    }
    static lifecycle(e, i) {
      if (!d.enabled) return;
    }
  }
  function h(e, i) {
    const t = e.filter((e) => e.ns === i);
    return t.length > 0 ? t[0] : null;
  }
  function u(e, i, t) {
    const n = -1 === e.indexOf("?") ? "?" : "&";
    return `${e}${n}${encodeURIComponent(i)}=${encodeURIComponent(t)}`;
  }
  function p(e) {
    return Array.isArray(e) && e.length > 0;
  }
  function m(e) {
    return null !== e && "object" == typeof e && Object.keys(e).length > 0;
  }
  function v(e, i, t) {
    return (
      (function (e) {
        try {
          const i = e.split("?")[1];
          if (!i) return;
          const t = {};
          i.split("&").forEach((e) => {
            const [i, n] = e.split("=");
            i && (t[i] = decodeURIComponent(n || ""));
          }),
            window.BEACONS_FIRED || (window.BEACONS_FIRED = []),
            window.BEACONS_FIRED.push(t);
        } catch (e) {}
      })(e),
      d.beacon("Pixel", "firePixel", e),
      new Promise((n, r) => {
        var a;
        if (t <= 0)
          return void r(new Error("Beacon failed: maximum retry reached"));
        const o = document.createElement("img");
        o.setAttribute("src", e),
          o.setAttribute("height", "0"),
          o.setAttribute("width", "2"),
          o.addEventListener("load", () => n("success")),
          o.addEventListener("error", () => {
            setTimeout(() => {
              v(e, i, t - 1)
                .then(n)
                .catch(r);
            }, i);
          }),
          null === (a = document.body) || void 0 === a || a.appendChild(o);
      })
    );
  }
  function b(e, i, t) {
    return 0 === e.length
      ? Promise.reject(new Error("tracker urls not present"))
      : Promise.all(e.map((e) => v(e, i, t)));
  }
  function g(e) {
    try {
      const i = e || "",
        t = i.indexOf("<adv>") + 5,
        n = i.indexOf("<crid>");
      return t > 4 && n > -1 ? i.substring(t, n) : "";
    } catch (e) {
      return "";
    }
  }
  function f(e, i) {
    const t = window.beaconManager;
    t
      ? t.customInmobiBeacon(e, i).catch(() => {})
      : (function (e, i) {
          try {
            const t = window.templateData;
            if (!t) return;
            const n = t.imaiConfigList;
            if (!Array.isArray(n)) return;
            const r = h(n, t.namespace || ""),
              a = null == r ? void 0 : r.bcu;
            if (!a) return;
            let o = u(a, "m", "99");
            (o = u(o, "action", e)),
              i && (o = u(o, "label", i)),
              v(o, 2e3, 3).catch(() => {});
          } catch (e) {}
        })(e, i);
  }
  function w(e, i) {
    d.info("Beacon", `CUSTOM: action=${e} label=${i}`), f(e, i);
  }
  d.enabled = !0;
  let y = !1;
  y ||
    ((y = !0),
    window.addEventListener(e, (e) => {
      const i = e.detail;
      i &&
        (function (e) {
          switch (e.action) {
            case "init_skipped":
              return void w("init_skipped", e.label);
            case "init_error":
              return void w("init_error", e.label);
            case "creative_iframe_presence":
              return void w("creativeIframePresence", e.label);
            case "direct_flow_browser_version":
              return void w("browserVersion", e.label);
            case "morph_open":
              w("morphOpen", e.label);
          }
        })(i);
    }));
  const I = "inmobi-ad-container";
  var C, E, A, D, T;
  function k(e, i) {
    switch (e) {
      case C.START:
        return "MEDIA_START";
      case C.QUARTILE:
        return (function (e) {
          switch (e) {
            case E.FIRST_QUARTILE:
              return "MEDIA_QUARTILE_1";
            case E.MIDPOINT:
              return "MEDIA_QUARTILE_2";
            case E.THIRD_QUARTILE:
              return "MEDIA_QUARTILE_3";
            default:
              return;
          }
        })((null == i ? void 0 : i.q) || 0);
      case C.COMPLETE:
        return "MEDIA_END";
      case C.CLICK:
        return "CLICK";
      default:
        return;
    }
  }
  !(function (e) {
    (e[(e.NONE = 0)] = "NONE"),
      (e[(e.START = 10)] = "START"),
      (e[(e.LOAD = 120)] = "LOAD"),
      (e[(e.IMPRESSION = 18)] = "IMPRESSION"),
      (e[(e.CLICK = 8)] = "CLICK"),
      (e[(e.QUARTILE = 12)] = "QUARTILE"),
      (e[(e.COMPLETE = 13)] = "COMPLETE"),
      (e[(e.PAUSED = 14)] = "PAUSED"),
      (e[(e.PLAYING = 17)] = "PLAYING"),
      (e[(e.VOLUME_CHANGE = 22)] = "VOLUME_CHANGE"),
      (e[(e.CUSTOM = 99)] = "CUSTOM"),
      (e[(e.VIEWABLE = 29)] = "VIEWABLE"),
      (e[(e.MRC_VIEWABLE = 30)] = "MRC_VIEWABLE"),
      (e[(e.USER_LANDINGS = 34)] = "USER_LANDINGS"),
      (e[(e.USER_LANDINGS_INITIALIZED = 37)] = "USER_LANDINGS_INITIALIZED"),
      (e[(e.COMPANION_RENDERED = 33)] = "COMPANION_RENDERED"),
      (e[(e.INTERACTION = 39)] = "INTERACTION"),
      (e[(e.AD_INITIALIZED = 28)] = "AD_INITIALIZED");
  })(C || (C = {})),
    (function (e) {
      (e[(e.FIRST_QUARTILE = 1)] = "FIRST_QUARTILE"),
        (e[(e.MIDPOINT = 2)] = "MIDPOINT"),
        (e[(e.THIRD_QUARTILE = 3)] = "THIRD_QUARTILE");
    })(E || (E = {}));
  class R {
    constructor(e) {
      var i;
      (this.beaconUrl = e.beaconUrl),
        (this.impressionTrackingUrl = e.impressionTrackingUrl),
        (this.eventTrackerMap =
          null !== (i = e.eventTrackerMap) && void 0 !== i ? i : {}),
        (this.retryDelay = e.retryDelay || 2e3),
        (this.maxRetry = e.maxRetry || 5),
        (this.shouldFireBeacon = !1 !== e.shouldFireBeacon),
        (this.loadBeaconUrl = e.loadBeacon);
    }
    viewableBeacon() {
      return this.fireBeaconInternal(C.VIEWABLE, {});
    }
    mrcViewableBeacon(e = {}) {
      return this.fireBeaconInternal(C.MRC_VIEWABLE, e);
    }
    impressionInmobiBeacon() {
      return this.fireBeaconInternal(C.IMPRESSION, {});
    }
    loadInmobiBeacon() {
      return this.fireBeaconInternal(C.LOAD, {});
    }
    clickInmobiBeacon(e) {
      const i = void 0 !== e ? { type: e } : {};
      return this.fireBeaconInternal(C.CLICK, i);
    }
    customInmobiBeacon(e, i) {
      return this.fireBeaconInternal(C.CUSTOM, { action: e, label: i });
    }
    fireImpressionTrackingUrl() {
      return this.impressionTrackingUrl
        ? ((e = this.impressionTrackingUrl),
          d.beacon(
            "HtmlTracker",
            "fireHtmlTracker",
            e.substring(0, 100) + "..."
          ),
          new Promise((i, t) => {
            try {
              const n = document.createElement("iframe");
              n.setAttribute("seamless", "seamless"),
                n.setAttribute("height", "0"),
                n.setAttribute("width", "2"),
                (n.style.display = "none"),
                document.body.appendChild(n);
              const r = n.contentWindow;
              r
                ? (r.document.write(e), r.document.close(), i("success"))
                : t(new Error("iframe contentWindow not available"));
            } catch (e) {
              t(e);
            }
          }))
        : Promise.reject(new Error("Missing impressionTrackingUrl"));
      var e;
    }
    fireNURLLoadBeacon() {
      return this.loadBeaconUrl
        ? v(this.loadBeaconUrl, this.retryDelay, this.maxRetry)
        : Promise.reject(new Error("NURL beacon missing"));
    }
    clickTrackerMapEvent(e) {
      const i = {};
      return void 0 !== e && (i.type = e), this.recordTrackerMap(C.CLICK, i);
    }
    fireUrlTracker(e) {
      return p(e)
        ? b(e, this.retryDelay, this.maxRetry)
        : Promise.reject(new Error("event tracker map not present"));
    }
    userLandingInitializedBeacon(e = {}) {
      return this.fireBeaconInternal(C.USER_LANDINGS_INITIALIZED, e);
    }
    userLandingBeacon(e = {}) {
      return this.fireBeaconInternal(C.USER_LANDINGS, e);
    }
    interactionBeacon(e = {}) {
      return this.fireBeaconInternal(C.INTERACTION, e);
    }
    buildBeaconUrl(e, i, t) {
      let n = u(t, "m", e.toString());
      if (m(i))
        for (const e in i) {
          const t = i[e];
          void 0 !== t && (n = u(n, e, t));
        }
      return n;
    }
    fireBeaconInternal(e, i) {
      if (!this.shouldFireBeacon)
        return Promise.reject(new Error("Beacon firing is turned off"));
      if (!this.beaconUrl)
        return Promise.reject(new Error("Beacon URL is missing"));
      return v(
        this.buildBeaconUrl(e, i, this.beaconUrl),
        this.retryDelay,
        this.maxRetry
      );
    }
    recordTrackerMap(e, i) {
      const t = k(e, i);
      let n = (t && this.eventTrackerMap[t]) || [];
      return (
        e === C.CLICK &&
          m(i) &&
          (n = n.map((e) =>
            Object.entries(i).reduce(
              (e, [i, t]) => (void 0 !== t ? u(e, i, t) : e),
              e
            )
          )),
        p(n)
          ? b(n, this.retryDelay, this.maxRetry)
          : Promise.reject(new Error("event tracker map not present"))
      );
    }
  }
  !(function (e) {
    (e[(e.NONE = 0)] = "NONE"),
      (e[(e.START = 1)] = "START"),
      (e[(e.LOADED = 2)] = "LOADED"),
      (e[(e.IMPRESSION = 3)] = "IMPRESSION"),
      (e[(e.AD_USER_INTERACTION = 4)] = "AD_USER_INTERACTION"),
      (e[(e.FIRST_QUARTILE = 5)] = "FIRST_QUARTILE"),
      (e[(e.MIDPOINT = 6)] = "MIDPOINT"),
      (e[(e.THIRD_QUARTILE = 7)] = "THIRD_QUARTILE"),
      (e[(e.COMPLETE = 8)] = "COMPLETE"),
      (e[(e.PAUSE = 9)] = "PAUSE"),
      (e[(e.RESUME = 10)] = "RESUME"),
      (e[(e.VOLUME_CHANGE = 11)] = "VOLUME_CHANGE"),
      (e[(e.BUFFER_START = 12)] = "BUFFER_START"),
      (e[(e.BUFFER_FINISH = 13)] = "BUFFER_FINISH"),
      (e[(e.SKIPPED = 14)] = "SKIPPED"),
      (e[(e.PLAYER_STATE_CHANGE = 15)] = "PLAYER_STATE_CHANGE");
  })(A || (A = {})),
    (function (e) {
      (e.OMID_1_2 = "1.2.19-iab1680"),
        (e.OMID_1_3 = "1.3.17-iab2651"),
        (e.OMID_1_3_37 = "1.3.37-iab3566"),
        (e.OMID_1_4 = "1.4.12-iab4299");
    })(D || (D = {})),
    (function (e) {
      (e.CLICK = "CLICK"), (e.INVITATION_ACCEPTED = "INVITATION_ACCEPTED");
    })(T || (T = {}));
  class L {
    constructor(e) {
      (this.impressionFired = !1),
        (this.clickFired = !1),
        (this.pendingClickParams = null),
        (this.adData = e);
      const i = h(e.imaiConfigList, e.namespace),
        t = {
          beaconUrl: (null == i ? void 0 : i.bcu) || "",
          eventTrackerMap: null == i ? void 0 : i.eventTrackerMap,
          impressionTrackingUrl: (null == i ? void 0 : i.tc) || "",
          retryDelay: 2e3,
          maxRetry: 5,
          shouldFireBeacon: !0,
          loadBeacon: null == i ? void 0 : i.loadBeacon,
        };
      (this.manager = new R(t)),
        (window.beaconManager = this.manager),
        d.info("BeaconFacade", "Initialized", { beaconUrl: t.beaconUrl });
    }
    fireImpressionBeacons() {
      var e;
      if (!this.impressionFired) {
        (this.impressionFired = !0),
          d.lifecycle("Beacon", "IMPRESSION fired"),
          window.dispatchEvent(new Event("impression_fired")),
          this.manager.impressionInmobiBeacon().catch(() => {}),
          this.manager.fireImpressionTrackingUrl().catch((e) => {
            d.warn("Beacon", "fireImpressionTrackingUrls failed", e);
          }),
          null === (e = window.omsdkManager) ||
            void 0 === e ||
            e.trackImpressionEvent();
        try {
          const e = window.imraid;
          e &&
            "function" == typeof e.impressionFired &&
            (e.impressionFired(),
            d.lifecycle("Beacon", "imraid.impressionFired() called"));
        } catch (e) {}
        this.publishEvent("RENDER"), this.flushPendingClick();
      }
    }
    isImpressionFired() {
      return this.impressionFired;
    }
    fireClickBeacons(e, i) {
      return (
        !!this.clickFired ||
        (this.impressionFired
          ? ((this.clickFired = !0), this.executeClickBeacons(e, i), !0)
          : (d.info("Beacon", "Click queued — impression not yet fired"),
            (this.pendingClickParams = { clickSource: e, clickPhase: i }),
            !1))
      );
    }
    flushPendingClick() {
      if (!this.pendingClickParams) return;
      if (this.clickFired) return void (this.pendingClickParams = null);
      d.info("Beacon", "Flushing pending click after impression"),
        (this.clickFired = !0);
      const { clickSource: e, clickPhase: i } = this.pendingClickParams;
      (this.pendingClickParams = null), this.executeClickBeacons(e, i);
    }
    executeClickBeacons(e, i) {
      var t;
      d.lifecycle("Beacon", `CLICK fired (source: ${e || "unknown"})`),
        e && this.emitInstrumentDetail({ action: "click_source", source: e });
      const n = 0 === i || 1 === i ? i : void 0;
      this.manager.clickInmobiBeacon(n).catch(() => {}),
        this.manager.clickTrackerMapEvent(n).catch(() => {}),
        null === (t = window.omsdkManager) ||
          void 0 === t ||
          t.trackInteractionEvent({ interaction: T.CLICK }),
        this.publishEvent("CTA"),
        this.emitInstrumentDetail({ action: "ad_click" });
    }
    fireLoadBeacon() {
      var e;
      this.isAdLifecycleEnabled() &&
        (d.lifecycle("Beacon", "LOAD beacon fired (m=120)"),
        (window.INITIATE_LOAD_BEACON = !0),
        this.manager
          .loadInmobiBeacon()
          .then(() => {
            window.LOAD_BEACON_FIRED = !0;
          })
          .catch(() => {}),
        null === (e = window.omsdkManager) ||
          void 0 === e ||
          e.trackLoadEvent(),
        this.publishEvent("LOAD"),
        this.emitInstrumentDetail({ action: "ad_load" }));
    }
    fireNURLBeacon() {
      d.lifecycle("Beacon", "NURL beacon fired"),
        this.manager.fireNURLLoadBeacon().catch((e) => {
          d.error("Beacon", "fireNURLLoadBeacon failed", e);
        });
    }
    fireViewableBeacon() {
      this.isAdLifecycleEnabled() &&
        (d.lifecycle("Beacon", "VIEWABLE beacon fired (m=29)"),
        this.manager.viewableBeacon().catch(() => {}),
        this.publishEvent("VIEWABLE"));
    }
    fireMRCViewableBeacon(e) {
      if (!this.isAdLifecycleEnabled()) return;
      d.lifecycle("Beacon", "MRC_VIEWABLE beacon fired (m=30)");
      const i = void 0 !== e ? { type: e } : {};
      this.manager.mrcViewableBeacon(i).catch(() => {}),
        this.emitInstrumentDetail({ action: "mrc_viewable" }),
        this.publishEvent("MRC_VIEWABLE");
    }
    fireLandingsInitializedBeacon() {
      this.isAdLifecycleEnabled() &&
        (d.lifecycle("Beacon", "LANDING_INITIALIZED beacon fired (m=37)"),
        this.manager.userLandingInitializedBeacon().catch(() => {}));
    }
    fireLandingsBeacon() {
      this.isAdLifecycleEnabled() &&
        (d.lifecycle("Beacon", "LANDING beacon fired (m=34)"),
        this.manager.userLandingBeacon().catch(() => {}));
    }
    fireInteractionBeacon(e, i, t) {
      if (!this.isAdLifecycleEnabled()) return;
      d.lifecycle(
        "Beacon",
        `INTERACTION beacon fired (m=39, label=${e}, type=${i}, t=${t}s)`
      );
      const n = { label: e };
      void 0 !== i && (n.type = i),
        void 0 !== t && (n.t = t),
        this.manager.interactionBeacon(n).catch(() => {});
    }
    creativeLoaded() {
      this.emitInstrumentDetail({ action: "creative_loaded" });
    }
    blankAdDetect(e, i) {
      this.emitInstrumentDetail({
        action: "blank_ad_detect",
        beaconAction: e,
        label: i,
      });
    }
    creativeCentered() {
      this.emitInstrumentDetail({ action: "creative_centered" });
    }
    creativeOutOfViewport() {
      this.emitInstrumentDetail({ action: "creative_out_of_viewport" });
    }
    creativeResizeStatus(e) {
      this.emitInstrumentDetail({ action: "resize", label: e });
    }
    webviewSizeMismatch(e) {
      this.emitInstrumentDetail({ action: "webview_size_mismatch", label: e });
    }
    windowOpen() {
      this.emitInstrumentDetail({ action: "window_open" });
    }
    ctaClickFailure() {
      this.emitInstrumentDetail({ action: "cta_click_failure" });
    }
    jsRuntimeError(e, i) {
      this.emitInstrumentDetail({
        action: "js_runtime_error",
        errorType: e,
        description: i,
      });
    }
    corsError(e, i) {
      this.emitInstrumentDetail({
        action: "cors_error",
        resourceType: e,
        description: i,
      });
    }
    omsdkError(e, i) {
      this.emitInstrumentDetail({
        action: "omsdk_error",
        errorType: e,
        description: i,
      });
    }
    bundleJsError(e, i) {
      this.emitInstrumentDetail({
        action: "bundle_js_error",
        errorType: e,
        description: i,
      });
    }
    promiseRejectionError(e) {
      this.emitInstrumentDetail({
        action: "unhandled_promise_rejection",
        description: e,
      });
    }
    resourceLoadError(e, i) {
      this.emitInstrumentDetail({
        action: "resource_load_error",
        resourceType: e,
        description: i,
      });
    }
    reportAdClicked() {
      this.emitInstrumentDetail({ action: "report_ad_clicked" });
    }
    selectedRating(e) {
      this.emitInstrumentDetail({ action: "selected_rating", rating: e });
    }
    selectedReportingReason(e) {
      this.emitInstrumentDetail({
        action: "selected_reporting_reason",
        reason: e,
      });
    }
    fireMorphAdBeacon() {
      this.emitInstrumentDetail({ action: "morph_ad" });
    }
    fireSdkAdReadyMetric() {
      this.emitInstrumentDetail({ action: "sdk_ad_ready" });
    }
    fireTrueViewBeacon() {
      d.lifecycle("Beacon", "TrueView MRC beacon fired (m=30, type=0)"),
        this.manager.mrcViewableBeacon({ type: 0 }).catch(() => {});
    }
    isAdLifecycleEnabled() {
      var e, i;
      return (
        null !==
          (i =
            null ===
              (e =
                null === window || void 0 === window
                  ? void 0
                  : window.customBeaconConfig) || void 0 === e
              ? void 0
              : e.adLifeCycleBeaconsEnabled) &&
        void 0 !== i &&
        i
      );
    }
    publishEvent(e) {
      var i, t, n;
      try {
        const r =
            null ===
              (t =
                null === (i = window.AD_TECH_UI) || void 0 === i
                  ? void 0
                  : i.Events) || void 0 === t
              ? void 0
              : t.BusinessMetricEvents,
          a =
            null === (n = window.AD_TECH_UI) || void 0 === n
              ? void 0
              : n.EventHub;
        if (a && r) {
          const i = r[e];
          i && a.publish(i);
        }
      } catch (e) {}
    }
  }
  class S extends L {
    emitInstrumentDetail(e) {}
  }
  class B {
    constructor(e) {
      var i, t, n, r, a, o;
      (this.observer = null),
        (this.viewableTimer = null),
        (this.sandboxedMrcTimeoutId = null),
        (this.boundOnMrcMessage = null),
        (this.directCreativePollIntervalId = null),
        (this.directCreativePollTimeoutId = null),
        (this.directCreativeTrackingTimeoutId = null),
        (this.directCreativeTrackingFailed = !1),
        (this.isViewable = !1),
        (this.isMrcViewable = !1),
        (this.onViewable = null),
        (this.onMrcViewable = null),
        (this.containerId =
          (null == e ? void 0 : e.containerId) || "inmobi-ad"),
        (this.creativeInsideIframe =
          null === (i = null == e ? void 0 : e.creativeInsideIframe) ||
          void 0 === i ||
          i),
        (this.useDirectCreativeViewability =
          null !== (t = null == e ? void 0 : e.useDirectCreativeViewability) &&
          void 0 !== t &&
          t),
        (this.thresholdPercent =
          null !== (n = null == e ? void 0 : e.mrcThresholdPercent) &&
          void 0 !== n
            ? n
            : 50),
        (this.thresholdMs =
          null !== (r = null == e ? void 0 : e.mrcThresholdMs) && void 0 !== r
            ? r
            : 1e3),
        (this.useSandboxedIframeViewability =
          null !== (a = null == e ? void 0 : e.useSandboxedIframeViewability) &&
          void 0 !== a &&
          a),
        (this.mrcViewableNonce =
          null !== (o = null == e ? void 0 : e.mrcViewableNonce) && void 0 !== o
            ? o
            : "");
    }
    start(e, i) {
      if (
        ((this.onViewable = e),
        (this.onMrcViewable = i),
        this.useDirectCreativeViewability)
      )
        try {
          this.startDirectCreativeViewability();
        } catch (e) {
          this.failDirectCreativeViewability("initialization", e);
        }
      else
        this.useSandboxedIframeViewability &&
          this.startSandboxedIframeMrcListener(),
          this.isMraidAvailable()
            ? this.startMraidViewability()
            : this.startIntersectionObserverViewability();
    }
    isMraidAvailable() {
      try {
        const e = window.mraid;
        return !!e && "function" == typeof e.isViewable;
      } catch (e) {
        return !1;
      }
    }
    startMraidViewability() {
      var e, i;
      const t = window.mraid;
      try {
        if (null === (e = t.isViewable) || void 0 === e ? void 0 : e.call(t))
          return void this.onBecameViewable();
      } catch (e) {
        return (
          d.warn(
            "Viewability",
            "mraid.isViewable() threw — falling back to IntersectionObserver",
            e
          ),
          void this.startIntersectionObserverViewability()
        );
      }
      try {
        const e = (i) => {
          var n;
          i &&
            !this.isViewable &&
            (null === (n = t.removeEventListener) ||
              void 0 === n ||
              n.call(t, "viewableChange", e),
            this.onBecameViewable());
        };
        null === (i = t.addEventListener) ||
          void 0 === i ||
          i.call(t, "viewableChange", e),
          d.lifecycle("Viewability", "Waiting for mraid viewableChange");
      } catch (e) {
        d.warn(
          "Viewability",
          "mraid.addEventListener threw — falling back to IntersectionObserver",
          e
        ),
          this.startIntersectionObserverViewability();
      }
    }
    onBecameViewable() {
      var e;
      this.isViewable ||
        ((this.isViewable = !0),
        (window._viewable = !0),
        d.lifecycle("Viewability", "Ad viewable (mraid)"),
        null === (e = this.onViewable) || void 0 === e || e.call(this),
        this.useSandboxedIframeViewability || this.startMrcTimer());
    }
    startIntersectionObserverViewability() {
      if ("undefined" == typeof IntersectionObserver)
        return void this.fallbackViewability();
      const e = this.thresholdPercent / 100,
        i = this.useSandboxedIframeViewability ? [0] : [0, e, 1];
      this.observer = new IntersectionObserver(
        (e) => this.handleIntersection(e),
        { threshold: i }
      );
      const t = document.getElementById(this.containerId);
      t ? this.observer.observe(t) : this.waitForElement();
    }
    getIsViewable() {
      return this.isViewable;
    }
    getIsMrcViewable() {
      return this.isMrcViewable;
    }
    destroy() {
      this.observer && (this.observer.disconnect(), (this.observer = null)),
        this.viewableTimer &&
          (clearTimeout(this.viewableTimer), (this.viewableTimer = null)),
        this.sandboxedMrcTimeoutId &&
          (clearTimeout(this.sandboxedMrcTimeoutId),
          (this.sandboxedMrcTimeoutId = null)),
        this.boundOnMrcMessage &&
          (window.removeEventListener("message", this.boundOnMrcMessage),
          (this.boundOnMrcMessage = null)),
        this.stopDirectCreativeTracking();
    }
    startDirectCreativeViewability() {
      const e = () => {
        try {
          const e = this.findDirectCreativeElement();
          return (
            !!e &&
            (this.observeDirectCreativeElement(e),
            this.clearDirectCreativePolling(),
            !0)
          );
        } catch (e) {
          return (
            this.failDirectCreativeViewability("creative discovery", e), !1
          );
        }
      };
      e() ||
        this.directCreativeTrackingFailed ||
        ((this.directCreativePollIntervalId = setInterval(() => {
          !e() &&
            this.directCreativeTrackingFailed &&
            this.clearDirectCreativePolling();
        }, 100)),
        (this.directCreativePollTimeoutId = setTimeout(() => {
          try {
            this.clearDirectCreativePolling(),
              this.safeDirectWarning(
                "Direct creative element was not found before timeout"
              );
          } catch (e) {
            this.failDirectCreativeViewability("creative polling timeout", e);
          }
        }, 15e3)));
    }
    findDirectCreativeElement() {
      try {
        const e = document.getElementById("child");
        if (!e) return null;
        const i = (e) => e.offsetWidth > 30 && e.offsetHeight > 30,
          t = ["img", "video", "canvas", "iframe"];
        for (const n of t) {
          const t = Array.from(e.querySelectorAll(n));
          for (const e of t) if (i(e)) return e;
        }
        const n = Array.from(e.querySelectorAll("div"));
        for (const e of n)
          try {
            if ("none" !== window.getComputedStyle(e).backgroundImage && i(e))
              return e;
          } catch (e) {
            this.safeDirectWarning(
              "Unable to inspect direct creative background style",
              e
            );
          }
        return null;
      } catch (e) {
        throw new Error(
          `Unable to inspect direct creative DOM: ${this.getErrorMessage(e)}`
        );
      }
    }
    observeDirectCreativeElement(e) {
      var i;
      try {
        if (
          (this.safeDirectLifecycle(
            `Observing direct creative element: ${e.tagName.toLowerCase()}`
          ),
          "undefined" == typeof IntersectionObserver)
        )
          throw new Error("IntersectionObserver is unavailable");
        const t = this.thresholdPercent / 100;
        try {
          (this.observer = new IntersectionObserver(
            (e) => {
              try {
                this.handleIntersection(e);
              } catch (e) {
                this.failDirectCreativeViewability(
                  "IntersectionObserver callback",
                  e
                );
              }
            },
            { threshold: [0, t, 1] }
          )),
            this.observer.observe(e);
        } catch (e) {
          try {
            null === (i = this.observer) || void 0 === i || i.disconnect();
          } catch (e) {}
          throw ((this.observer = null), e);
        }
        this.directCreativeTrackingTimeoutId = setTimeout(() => {
          try {
            this.stopDirectCreativeTracking(),
              this.safeDirectWarning(
                "Direct creative viewability tracking timed out"
              );
          } catch (e) {
            this.failDirectCreativeViewability("viewability timeout", e);
          }
        }, 12e4);
      } catch (e) {
        throw new Error(
          `Unable to start direct creative viewability: ${this.getErrorMessage(
            e
          )}`
        );
      }
    }
    clearDirectCreativePolling() {
      this.directCreativePollIntervalId &&
        (clearInterval(this.directCreativePollIntervalId),
        (this.directCreativePollIntervalId = null)),
        this.directCreativePollTimeoutId &&
          (clearTimeout(this.directCreativePollTimeoutId),
          (this.directCreativePollTimeoutId = null));
    }
    stopDirectCreativeTracking() {
      try {
        this.clearDirectCreativePolling();
      } catch (e) {}
      try {
        this.directCreativeTrackingTimeoutId &&
          (clearTimeout(this.directCreativeTrackingTimeoutId),
          (this.directCreativeTrackingTimeoutId = null));
      } catch (e) {
        this.directCreativeTrackingTimeoutId = null;
      }
      try {
        this.useDirectCreativeViewability &&
          this.observer &&
          (this.observer.disconnect(), (this.observer = null));
      } catch (e) {
        this.observer = null;
      }
    }
    failDirectCreativeViewability(e, i) {
      this.directCreativeTrackingFailed = !0;
      try {
        this.clearMrcTimer(), this.stopDirectCreativeTracking();
      } catch (e) {}
      this.safeDirectWarning(
        `Direct creative viewability failed during ${e}`,
        i
      );
    }
    getErrorMessage(e) {
      try {
        return e instanceof Error ? e.message : String(e);
      } catch (e) {
        return "unknown error";
      }
    }
    safeDirectWarning(e, i) {
      try {
        d.warn("Viewability", e, i);
      } catch (e) {}
    }
    safeDirectLifecycle(e) {
      try {
        d.lifecycle("Viewability", e);
      } catch (e) {}
    }
    startSandboxedIframeMrcListener() {
      var e;
      const i = (
        null !== (e = this.mrcViewableNonce) && void 0 !== e ? e : ""
      ).trim();
      if (!i)
        return void d.warn(
          "Viewability",
          "mrcViewableNonce is empty — sandboxed iframe MRC will not work"
        );
      const t = this.containerId;
      (this.boundOnMrcMessage = (e) => {
        var n, r, a, o, s;
        if (!1 === e.isTrusted) return;
        if (
          "mrc-viewable" !==
          (null === (n = null == e ? void 0 : e.data) || void 0 === n
            ? void 0
            : n.eventType)
        )
          return;
        const c = document.getElementById(t);
        if (c) {
          const i =
            null !== (r = null == c ? void 0 : c.contentWindow) && void 0 !== r
              ? r
              : null;
          if (!i || e.source !== i) {
            const i = document.getElementById(I);
            if (!i || e.source !== i.contentWindow) return;
          }
        } else {
          const i = document.getElementById(I);
          if (!i || e.source !== i.contentWindow) return;
        }
        const l =
          null !==
            (o =
              null === (a = e.data) || void 0 === a ? void 0 : a.eventData) &&
          void 0 !== o
            ? o
            : {};
        (null == l ? void 0 : l.mrcNonce) === i &&
          (this.sandboxedMrcTimeoutId &&
            (clearTimeout(this.sandboxedMrcTimeoutId),
            (this.sandboxedMrcTimeoutId = null)),
          window.removeEventListener("message", this.boundOnMrcMessage),
          (this.boundOnMrcMessage = null),
          d.lifecycle(
            "Viewability",
            `MRC viewable via sandboxed iframe postMessage (${l.width}x${l.height})`
          ),
          this.isMrcViewable ||
            ((this.isMrcViewable = !0),
            null === (s = this.onMrcViewable) || void 0 === s || s.call(this)));
      }),
        (this.sandboxedMrcTimeoutId = setTimeout(() => {
          this.boundOnMrcMessage &&
            (window.removeEventListener("message", this.boundOnMrcMessage),
            (this.boundOnMrcMessage = null)),
            d.warn(
              "Viewability",
              "MRC viewable postMessage timeout from sandboxed iframe"
            );
        }, 6e4)),
        window.addEventListener("message", this.boundOnMrcMessage),
        d.lifecycle(
          "Viewability",
          "Listening for sandboxed iframe MRC postMessage"
        );
    }
    handleIntersection(e) {
      for (const i of e) this.handleIntersectionRatio(i.intersectionRatio);
    }
    handleIntersectionRatio(e) {
      var i;
      if (
        (e > 0 &&
          !this.isViewable &&
          ((this.isViewable = !0),
          (window._viewable = !0),
          null === (i = this.onViewable) || void 0 === i || i.call(this)),
        !this.useSandboxedIframeViewability)
      ) {
        const i = this.thresholdPercent / 100;
        e >= i && !this.isMrcViewable
          ? this.startMrcTimer()
          : e < i && this.clearMrcTimer();
      }
    }
    startMrcTimer() {
      this.viewableTimer ||
        (this.viewableTimer = setTimeout(() => {
          var e;
          try {
            (this.viewableTimer = null),
              this.isMrcViewable ||
                ((this.isMrcViewable = !0),
                null === (e = this.onMrcViewable) ||
                  void 0 === e ||
                  e.call(this)),
              this.useDirectCreativeViewability &&
                this.stopDirectCreativeTracking();
          } catch (e) {
            this.useDirectCreativeViewability
              ? this.failDirectCreativeViewability("MRC timer callback", e)
              : d.warn("Viewability", "MRC timer callback failed", e);
          }
        }, this.thresholdMs));
    }
    clearMrcTimer() {
      this.viewableTimer &&
        (clearTimeout(this.viewableTimer), (this.viewableTimer = null));
    }
    waitForElement() {
      const e = setInterval(() => {
        const i = document.getElementById(this.containerId);
        i && this.observer && (this.observer.observe(i), clearInterval(e));
      }, 100);
      setTimeout(() => clearInterval(e), 1e4);
    }
    fallbackViewability() {
      var e;
      (this.isViewable = !0),
        (window._viewable = !0),
        null === (e = this.onViewable) || void 0 === e || e.call(this),
        setTimeout(() => {
          var e;
          (this.isMrcViewable = !0),
            null === (e = this.onMrcViewable) || void 0 === e || e.call(this);
        }, this.thresholdMs);
    }
  }
  const M = {
      backgroundColor: "rgba(0, 0, 0, 0.8)",
      position: "absolute",
      left: "0",
      top: "0",
      width: "100%",
      height: "100%",
      zIndex: "10000000000",
      boxSizing: "border-box",
      border: "1px solid #afbfde",
      overflowY: "auto",
      overflowX: "hidden",
    },
    x = {
      position: "absolute",
      left: "50%",
      top: "50%",
      transform: "translate(-50%, -50%)",
      width: "100%",
      height: "100%",
      boxSizing: "border-box",
    },
    O = {
      background: "rgba(237, 239, 242, 1)",
      width: "100%",
      height: "100%",
      boxSizing: "border-box",
      borderTopLeftRadius: "6px",
      borderTopRightRadius: "6px",
      position: "relative",
    },
    _ = { width: "108px", height: "32px", display: "block", margin: "0 auto" },
    V = { marginTop: "32px" },
    P = { marginTop: "16px", gap: "12px" },
    N = {
      marginTop: "16px",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    },
    F = {
      background: "rgba(237, 239, 242, 1)",
      width: "100%",
      height: "100%",
      padding: "14px",
      boxSizing: "border-box",
      display: "flex",
      flexDirection: "row",
      alignItems: "center",
      gap: "52px",
    },
    U = { width: "75px", height: "22px" },
    z = {
      display: "flex",
      alignItems: "center",
      flexDirection: "row",
      gap: "8px",
    },
    W = {
      width: "1px",
      height: "12px",
      backgroundColor: "rgba(118, 133, 163, 1)",
    },
    $ = {
      background: "rgba(237, 239, 242, 1)",
      height: "100%",
      display: "flex",
      justifyContent: "center",
      flexDirection: "column",
    },
    H = { fontWeight: "500", marginBottom: "2px" },
    G = { marginTop: "2px" },
    j = {
      marginTop: "20px",
      display: "flex",
      justifyContent: "center",
      gap: "12px",
      flexWrap: "wrap",
    },
    K = {
      background: "rgba(237, 239, 242, 1)",
      width: "100%",
      height: "100%",
      paddingLeft: "4px",
      paddingRight: "16px",
      paddingTop: "4px",
      boxSizing: "border-box",
      position: "relative",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
    },
    Q = { fontWeight: "500" },
    Y = {
      display: "flex",
      flexDirection: "row",
      gap: "12px",
      overflowX: "scroll",
      marginTop: "2px",
    },
    q = {
      justifyContent: "center",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
    },
    X = {
      height: "32px",
      width: "32px",
      overflow: "hidden",
      marginBottom: "8px",
      position: "relative",
    },
    Z = { marginTop: "32px", width: "100%" },
    J = {
      background: "rgba(237, 239, 242, 1)",
      width: "100%",
      height: "100%",
      padding: "24px",
      boxSizing: "border-box",
      justifyContent: "center",
      display: "flex",
      flexDirection: "row",
      alignItems: "center",
    },
    ee = {
      height: "16px",
      width: "16px",
      overflow: "hidden",
      marginRight: "8px",
      position: "relative",
      flexShrink: "0",
    },
    ie = {
      height: "100%",
      width: "100%",
      position: "absolute",
      left: "50%",
      top: "50%",
      transform: "translate(-50%, -50%)",
    },
    te = {
      1: "linear-gradient(180deg, #f97769 0%, #ff301a 116.07%)",
      2: "linear-gradient(180deg, #f7b24b 0%, #fe7c1c 100%)",
      3: "linear-gradient(180deg, #ffdd55 0%, #ffc60c 100%)",
      4: "linear-gradient(180deg, #b1f06a 0%, #8ed141 100%)",
      5: "linear-gradient(180deg, #0be200 0%, #09ae00 100%)",
    },
    ne = {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: "24px",
    };
  function re(e, i) {
    const t = "RECTANGLE" === i;
    return {
      width: t ? "48px" : "32px",
      height: t ? "40px" : "28px",
      fontSize: t ? "14px" : "12px",
      lineHeight: t ? "18px" : "14px",
      fontWeight: "600",
      textAlign: "center",
      border: "1px solid rgba(118, 133, 163, 1)",
      borderRadius: "4px",
      backgroundColor: "transparent",
      color: "#fafbfc",
      background: te[e],
      boxShadow: "0px 8px 8px 0px #c6cddb8f",
      cursor: "pointer",
      padding: "0",
    };
  }
  const ae = {
      position: "absolute",
      right: "1px",
      top: "1px",
      height: "16px",
      width: "16px",
      overflow: "hidden",
      zIndex: "2",
      cursor: "pointer",
    },
    oe = {
      position: "absolute",
      right: "12px",
      top: "12px",
      height: "12px",
      width: "12px",
      overflow: "hidden",
      zIndex: "2",
      cursor: "pointer",
    };
  const se = { position: "relative", display: "flex" },
    ce = {
      pointerEvents: "auto",
      height: "16px",
      width: "16px",
      cursor: "pointer",
    },
    le = [
      "Shown too frequently",
      "No ad was shown",
      "Inappropriate or Offensive",
    ],
    de = "Rate this ad on a scale of 1 to 5",
    he = "1 means it needs improvement, while 5 indicates excellence.",
    ue = "What did you not like?",
    pe = "Thank you for your feedback",
    me = "https://supply.inmobicdn.net/lagom-icons/closeIcon.svg",
    ve =
      "https://videoassets41.blob.core.windows.net/lagom-icons/close-icon-dark.svg",
    be =
      "https://videoassets41.blob.core.windows.net/lagom-icons/inmobi-advertising-icon.svg",
    ge =
      "https://videoassets41.blob.core.windows.net/lagom-icons/success-icon.svg";
  class fe {
    constructor(e, i) {
      (this.state = "idle"),
        (this.selectedRating = 0),
        (this.selectedCategory = ""),
        (this.overlay = null),
        (this.hasSubmitted = !1),
        (this.isSmall = !1),
        (this.adData = e),
        (this.beacon = i);
      const t =
          document.getElementById("inmobi-ad") ||
          document.getElementById("morphContainer"),
        n = t ? t.offsetHeight : window.innerHeight;
      this.isSmall = n < 250;
    }
    open() {
      this.hasSubmitted
        ? this.openPrivacyPolicy()
        : this.adData.adQualityUrl
        ? (this.beacon.reportAdClicked(),
          this.transitionTo("moreAboutAd"),
          d.lifecycle("AdReport", "Opened"))
        : this.openPrivacyPolicy();
    }
    transitionTo(e) {
      (this.state = e),
        d.info("AdReport", `State → ${e}`),
        "closed" !== e && "idle" !== e
          ? this.renderCurrentState()
          : this.removeOverlay();
    }
    renderCurrentState() {
      let e;
      switch (
        (this.removeOverlay(),
        (this.overlay = this.createOverlayContainer()),
        this.state)
      ) {
        case "moreAboutAd":
          e = this.isSmall
            ? this.buildMoreAboutAdSmall()
            : this.buildMoreAboutAdRect();
          break;
        case "rateAd":
          e = this.buildRateAdSmall();
          break;
        case "reportAd":
          e = this.isSmall
            ? this.buildReportAdSmall()
            : this.buildReportAdRect();
          break;
        case "success":
          e = this.isSmall ? this.buildSuccessSmall() : this.buildSuccessRect();
          break;
        default:
          return;
      }
      if (this.isSmall) {
        const e = this.createSmallCloseButton();
        this.overlay.appendChild(e);
      }
      this.overlay.appendChild(e);
      (document.getElementById("inmobi-ad") || document.body).appendChild(
        this.overlay
      );
    }
    createOverlayContainer() {
      const e = document.createElement("main");
      return (
        (e.id = "adReportContainer"),
        e.addEventListener("touchend", (e) => e.stopPropagation()),
        this.css(e, M),
        e
      );
    }
    buildMoreAboutAdRect() {
      const e = this.createPositionedOverlay(),
        i = this.createInnerPanel("24px");
      i.appendChild(this.createRectCloseButton());
      const t = document.createElement("img");
      (t.src = be),
        (t.alt = "InMobi Advertising"),
        this.css(t, _),
        i.appendChild(t);
      const n = document.createElement("div");
      this.css(n, V),
        n.appendChild(
          this.createTitle(de, "RECTANGLE", "center", "rgba(31, 36, 46, 1)")
        ),
        n.appendChild(this.createTitle(he, "SMALL", "center")),
        i.appendChild(n);
      const r = this.buildRatingButtons("RECTANGLE");
      this.css(r, P), i.appendChild(r);
      const a = document.createElement("div");
      return (
        this.css(a, N),
        a.appendChild(
          this.createLinkButton(
            "Privacy Policy",
            () => this.openPrivacyPolicy(),
            "RECTANGLE"
          )
        ),
        i.appendChild(a),
        e.appendChild(i),
        e
      );
    }
    buildMoreAboutAdSmall() {
      const e = this.createPositionedOverlay(),
        i = document.createElement("div");
      this.css(i, F);
      const t = document.createElement("img");
      (t.src = be),
        (t.alt = "InMobi Advertising"),
        this.css(t, U),
        i.appendChild(t);
      const n = document.createElement("div");
      this.css(n, z),
        n.appendChild(
          this.createLinkButton(
            "Feedback",
            () => this.transitionTo("rateAd"),
            "SMALL"
          )
        );
      const r = document.createElement("div");
      return (
        this.css(r, W),
        n.appendChild(r),
        n.appendChild(
          this.createLinkButton(
            "Privacy Policy",
            () => this.openPrivacyPolicy(),
            "SMALL"
          )
        ),
        i.appendChild(n),
        e.appendChild(i),
        e
      );
    }
    buildRateAdSmall() {
      const e = this.createPositionedOverlay(),
        i = document.createElement("div");
      this.css(i, $);
      const t = this.createTitle("Rate this ad", "SMALL", "center");
      this.css(t, H), i.appendChild(t);
      const n = this.buildRatingButtons("SMALL");
      return this.css(n, G), i.appendChild(n), e.appendChild(i), e;
    }
    buildReportAdRect() {
      const e = this.createPositionedOverlay(),
        i = this.createInnerPanel("24px 16px");
      i.appendChild(this.createRectCloseButton()),
        i.appendChild(
          this.createTitle(ue, "RECTANGLE", "center", "rgba(31, 36, 46, 1)")
        );
      const t = document.createElement("div");
      return (
        this.css(t, j),
        this.appendReportOptions(t, "RECTANGLE"),
        i.appendChild(t),
        e.appendChild(i),
        e
      );
    }
    buildReportAdSmall() {
      const e = this.createPositionedOverlay(),
        i = document.createElement("div");
      this.css(i, K);
      const t = this.createTitle(ue, "SMALL", "center");
      this.css(t, Q), i.appendChild(t);
      const n = document.createElement("div");
      return (
        this.css(n, Y),
        this.appendReportOptions(n, "SMALL"),
        i.appendChild(n),
        e.appendChild(i),
        e
      );
    }
    buildSuccessRect() {
      const e = this.createPositionedOverlay(),
        i = this.createInnerPanel("24px");
      this.css(i, q), i.appendChild(this.createRectCloseButton());
      const t = document.createElement("div");
      this.css(t, X);
      const n = document.createElement("img");
      (n.src = ge),
        (n.alt = "success"),
        this.css(n, ie),
        t.appendChild(n),
        i.appendChild(t);
      const r = this.adData.adReportSubmitMessage || pe;
      i.appendChild(
        this.createTitle(r, "RECTANGLE", "center", "rgba(31, 36, 46, 1)")
      );
      const a = this.createTertiaryButton(
        "Close",
        () => this.close(),
        "RECTANGLE"
      );
      return this.css(a, Z), i.appendChild(a), e.appendChild(i), e;
    }
    buildSuccessSmall() {
      const e = this.createPositionedOverlay(),
        i = document.createElement("div");
      this.css(i, J);
      const t = document.createElement("div");
      this.css(t, ee);
      const n = document.createElement("img");
      (n.src = ge),
        (n.alt = "success"),
        this.css(n, ie),
        t.appendChild(n),
        i.appendChild(t);
      const r = this.adData.adReportSubmitMessage || pe;
      return (
        i.appendChild(this.createTitle(r, "SMALL", "center")),
        e.appendChild(i),
        e
      );
    }
    buildRatingButtons(e) {
      const i = document.createElement("div");
      this.css(i, ne);
      for (let t = 1; t <= 5; t++) {
        const n = document.createElement("button");
        (n.id = `rating-button-${t}`),
          (n.textContent = String(t)),
          this.css(n, re(t, e)),
          n.addEventListener("click", (e) => {
            e.stopPropagation(), this.onRatingSelected(t);
          }),
          i.appendChild(n);
      }
      return i;
    }
    appendReportOptions(e, i) {
      le.forEach((t) => {
        const n = this.createTertiaryButton(
          t,
          (e) => {
            e.stopPropagation(), this.onSelectReportReason(t);
          },
          i
        );
        (n.style.width = "max-content"), e.appendChild(n);
      });
    }
    onRatingSelected(e) {
      (this.selectedRating = e),
        this.beacon.selectedRating(e),
        d.info("AdReport", `Rating selected: ${e}`),
        e < 4 ? this.transitionTo("reportAd") : this.transitionTo("success");
    }
    onSelectReportReason(e) {
      (this.selectedCategory = e),
        this.beacon.selectedReportingReason(e),
        d.info("AdReport", `Report reason: ${e}`),
        this.transitionTo("success");
    }
    close() {
      this.submitAdReport(),
        this.transitionTo("closed"),
        d.lifecycle("AdReport", "Closed");
    }
    submitAdReport() {
      if (!this.selectedCategory && !this.selectedRating) return;
      this.hasSubmitted = !0;
      const e = {
        adRemark: "ad reported",
        category: this.selectedCategory,
        rating: this.selectedRating,
      };
      d.info("AdReport", "Submitting report", e),
        setTimeout(() => {
          this.postAdReport(e);
        }, 200);
    }
    postAdReport(e) {
      let i = this.adData.adQualityUrl;
      if (i) {
        (i = u(i, "feedbackRating", e.rating > 0 ? String(e.rating) : "null")),
          (i = u(i, "feedbackReason", e.category || "null"));
        try {
          const e = new XMLHttpRequest();
          e.open("POST", i, !0),
            e.send(""),
            d.info("AdReport", "Report submitted");
        } catch (e) {
          d.error("AdReport", "Report submission failed", e);
        }
      }
    }
    openPrivacyPolicy() {
      const e =
        this.adData.optOutUrl || "https://www.inmobi.com/ad-opt-out?i=%7B%7D";
      d.info("AdReport", `Opening privacy policy: ${e}`),
        window.open(e, "_blank");
    }
    createTitle(e, i, t, n) {
      const r = document.createElement("div");
      return (
        (r.textContent = e),
        this.css(
          r,
          (function (e, i, t) {
            let n,
              r,
              a = t || "rgba(241, 241, 241, 1)";
            return (
              "SMALL" === e
                ? ((n = "12px"),
                  (r = "14px"),
                  t || (a = "rgba(86, 100, 127, 1)"))
                : "RECTANGLE" === e
                ? ((n = "16px"), (r = "23px"))
                : ((n = "24px"), (r = "30px")),
              {
                fontSize: n,
                lineHeight: r,
                color: a,
                fontWeight: "600",
                textAlign: i,
              }
            );
          })(i, t, n)
        ),
        r
      );
    }
    createLinkButton(e, i, t) {
      const n = document.createElement("button");
      return (
        (n.textContent = e),
        this.css(
          n,
          (function (e) {
            const i = "RECTANGLE" === e;
            return {
              border: "none",
              backgroundColor: "transparent",
              color: "rgba(12, 85, 228, 1)",
              borderRadius: "100px",
              fontWeight: "600",
              textAlign: "center",
              fontSize: i ? "14px" : "12px",
              lineHeight: i ? "18px" : "14px",
              width: i ? "144px" : "max-content",
              height: i ? "36px" : "max-content",
              cursor: "pointer",
              padding: "0",
            };
          })(t)
        ),
        n.addEventListener("click", (e) => {
          e.stopPropagation(), i();
        }),
        n
      );
    }
    createTertiaryButton(e, i, t) {
      const n = document.createElement("button");
      return (
        (n.textContent = e),
        this.css(
          n,
          (function (e) {
            const i = "RECTANGLE" === e;
            return {
              border: "1px solid rgba(118, 133, 163, 1)",
              borderRadius: "4px",
              backgroundColor: "transparent",
              color: "rgba(31, 36, 46, 1)",
              whiteSpace: "nowrap",
              fontWeight: "600",
              textAlign: "center",
              fontSize: i ? "14px" : "12px",
              lineHeight: i ? "18px" : "14px",
              width: i ? "144px" : "120px",
              height: i ? "36px" : "26px",
              padding: i ? "8px 16px" : "4px 12px",
              boxSizing: "border-box",
              cursor: "pointer",
            };
          })(t)
        ),
        n.addEventListener("click", i),
        n
      );
    }
    createSmallCloseButton() {
      const e = document.createElement("div");
      (e.id = "adReportCloseBtn"), this.css(e, ae);
      const i = document.createElement("img");
      return (
        (i.src = ve),
        (i.alt = "close"),
        this.css(i, ie),
        e.appendChild(i),
        e.addEventListener("click", (e) => {
          e.stopPropagation(), this.close();
        }),
        e
      );
    }
    createRectCloseButton() {
      const e = document.createElement("div");
      (e.id = "adReportCloseBtn"), this.css(e, oe);
      const i = document.createElement("img");
      return (
        (i.src = me),
        (i.alt = "close"),
        this.css(i, ie),
        e.appendChild(i),
        e.addEventListener("click", (e) => {
          e.stopPropagation(), this.close();
        }),
        e
      );
    }
    createPositionedOverlay() {
      const e = document.createElement("div");
      return this.css(e, x), e;
    }
    createInnerPanel(e) {
      const i = document.createElement("div");
      return (
        this.css(i, Object.assign(Object.assign({}, O), { padding: e })), i
      );
    }
    removeOverlay() {
      var e;
      (null === (e = this.overlay) || void 0 === e ? void 0 : e.parentNode) &&
        this.overlay.parentNode.removeChild(this.overlay),
        (this.overlay = null);
    }
    css(e, i) {
      Object.assign(e.style, i);
    }
  }
  class we {
    constructor(e, i) {
      (this.adData = e), (this.onClick = i);
    }
    render() {
      if (this.adData.isAdChoiceIconDisabled)
        return void d.info("AdChoiceIcon", "Disabled via config");
      const e = this.resolvePosition(this.adData.adChoiceIconPosition),
        i = document.createElement("div");
      (i.id = "inmobi_adChoiceContainer"),
        Object.assign(
          i.style,
          (function (e) {
            return Object.assign(
              {
                position: "absolute",
                webkitPerspective: "1000px",
                perspective: "1000px",
                outlineColor: "transparent",
                WebkitTapHighlightColor: "transparent",
                zIndex: "1005",
                display: "flex",
                pointerEvents: "none",
                height: "16px",
                width: "16px",
                backgroundColor: "rgba(255, 255, 255, 0.8)",
              },
              e
            );
          })(e)
        ),
        i.addEventListener("touchend", (e) => e.stopPropagation());
      const t = document.createElement("div");
      Object.assign(t.style, se);
      const n = document.createElement("img");
      (n.id = "inmobi_adChoiceIcon"),
        (n.src = "https://supply.inmobicdn.net/lagom-icons/inmobi-18.svg"),
        (n.alt = ""),
        Object.assign(n.style, ce),
        n.addEventListener("click", (e) => {
          e.stopPropagation(),
            d.lifecycle("AdChoiceIcon", "Clicked"),
            this.onClick();
        }),
        t.appendChild(n),
        i.appendChild(t);
      if (!!document.getElementById("morphContainer"))
        document.body.appendChild(i);
      else {
        (document.getElementById("inmobi-ad") || document.body).appendChild(i);
      }
      d.info("AdChoiceIcon", `Rendered at ${this.adData.adChoiceIconPosition}`);
    }
    resolvePosition(e) {
      switch (e) {
        case "leftTop":
          return { left: "0", top: "0" };
        case "rightTop":
          return { right: "0", top: "0" };
        case "rightBottom":
          return { right: "0", bottom: "0" };
        default:
          return { left: "0", bottom: "0" };
      }
    }
  }
  class ye {
    constructor(e) {
      this.syncUrl =
        e ||
        "https://sync.inmobi.com/sync?redirect=&gdpr=&gdpr_consent=&us_privacy=&gdpr_pd=&source=4";
    }
    setup() {
      this.isIOS()
        ? d.info("CookieSync", "Skipped — iOS device")
        : "http:" !== window.location.protocol
        ? (this.waitForEventsAndSync(),
          d.info("CookieSync", "Waiting for load + impression_fired"))
        : d.info("CookieSync", "Skipped — non-HTTPS");
    }
    waitForEventsAndSync() {
      let e = "complete" === document.readyState,
        i = !1;
      const t = () => {
        e && i && this.attachIframe();
      };
      e ||
        window.addEventListener(
          "load",
          () => {
            (e = !0), t();
          },
          { once: !0 }
        ),
        window.addEventListener(
          "impression_fired",
          () => {
            (i = !0), t();
          },
          { once: !0 }
        ),
        t();
    }
    attachIframe() {
      try {
        const e = document.createElement("iframe");
        (e.width = "0"),
          (e.height = "0"),
          (e.style.visibility = "hidden"),
          (e.style.display = "none"),
          (e.src = this.syncUrl),
          e.sandbox.add("allow-same-origin", "allow-scripts"),
          (e.onerror = () => {
            d.warn("CookieSync", "Iframe load error");
          }),
          document.body.appendChild(e),
          d.lifecycle("CookieSync", "Iframe attached");
      } catch (e) {
        d.error("CookieSync", "Failed to attach iframe", e);
      }
    }
    isIOS() {
      return /iPhone|iPad|iPod/i.test(navigator.userAgent);
    }
  }
  let Ie = null;
  function Ce() {
    return Ie;
  }
  class Ee {
    constructor(e) {
      this.adData = e;
    }
    resize() {
      if (
        this.adData.isDisableCreativeResize ||
        this.adData.disableResizingCompletely
      )
        return void d.info("CreativeResize", "Resize disabled");
      const { creativeWidth: e, creativeHeight: i } = this.adData;
      if (!e || !i)
        return void d.info(
          "CreativeResize",
          "Creative size not provided — skipping"
        );
      const t = this.calculateWebViewSize(),
        n = this.computeScale(e, i, t.width, t.height);
      if (0 === n)
        return void d.warn("CreativeResize", "Scale factor is 0 — skipping");
      if (n < 0.2)
        return void d.warn(
          "CreativeResize",
          `Scale ${n} below minimum 0.2 — skipping`
        );
      const r = document.getElementById(I);
      r
        ? (this.resizeAndCenter(r, n, e, i, this.adData.resizedAdPosition),
          d.lifecycle(
            "CreativeResize",
            `Done — scale=${n.toFixed(4)}, position=${
              this.adData.resizedAdPosition
            }`
          ))
        : d.warn("CreativeResize", `Element #${I} not found`);
    }
    computeScale(e, i, t, n) {
      let r, a;
      e / i > t / n
        ? ((r = t), (a = r / (e / i)))
        : ((a = n), (r = a * (e / i)));
      const o = r / e,
        s = a / i;
      return Math.min(o, s);
    }
    calculateWebViewSize() {
      if (this.adData.isWebSdkIntegration)
        return { width: window.innerWidth, height: window.innerHeight };
      const e = this.adData.webviewWidth || this.adData.adWidth,
        i = this.adData.webviewHeight || this.adData.adHeight,
        t = window,
        n = t._viewable,
        r = t.mraid;
      if (n || !r) {
        const t = window.innerWidth,
          n = window.innerHeight;
        if (
          (Math.abs(t - e) > 10 || Math.abs(n - i) > 10) &&
          t >= 300 &&
          n >= 50
        )
          return { width: t, height: n };
      }
      return { width: e, height: i };
    }
    resizeAndCenter(e, i, t, n, r) {
      if (
        ((e.width = `${t}px !important`),
        (e.height = `${n}px !important`),
        (e.style.margin = "0"),
        "center" === r)
      )
        (e.style.transform = `translate(-50%,-50%) scale(${i})`),
          (e.style.left = "50%"),
          (e.style.top = "50%");
      else {
        const r = Math.floor((t * i - t) / 2),
          a = Math.floor((n * i - n) / 2);
        (e.style.transform = `translate(${r}px,${a}px) scale(${i})`),
          (e.style.left = "0"),
          (e.style.top = "0");
      }
    }
  }
  (Ie = {
    resize(e) {
      new Ee(e).resize();
    },
  }),
    (window.WebBannerLogger = d);
  const Ae = new (class {
    constructor(e, i) {
      (this.adViewableTimestamp = 0),
        (this.hasFiredClickBeacon = !1),
        (this.hasFiredInteractionBeacon = !1),
        (this.hasFiredLandingInitBeacon = !1),
        (this.hasFiredLandingCompleteBeacon = !1),
        (this.useSandboxedIframeViewability = !1),
        (this.hasHandledClick = !1),
        (this.hasReportedDirectCreativeDiagnostics = !1),
        (this.viewabilityStarted = !1),
        (this.experience = e),
        (this.options = null != i ? i : {});
    }
    async initialize() {
      var e, t, n, r;
      try {
        if (
          (d.lifecycle(
            "Initialize",
            `BannerAd starting (experience: ${this.experience})`
          ),
          (this.adData = this.parseAdData()),
          this.initializeServerLogging(),
          d.info("Init", "Template data parsed", {
            isAPI: this.adData.isAPI,
            buildMorphAdMarkup: this.adData.buildMorphAdMarkup,
            adSize: `${this.adData.adWidth}x${this.adData.adHeight}`,
            creativeSize: `${this.adData.creativeWidth}x${this.adData.creativeHeight}`,
            namespace: this.adData.namespace,
            experience: this.experience,
          }),
          !this.adData.isAPI)
        )
          return (
            d.error("Init", "isAPI is false — exiting"),
            void i({ action: "init_skipped", label: "isAPI=false" })
          );
        this.injectGlobalStyles(), this.initializeExperience();
        const a =
          null !== (e = this.options.beaconFacadeFactory) && void 0 !== e
            ? e
            : (e) => new S(e);
        (this.beacon = a(this.adData)),
          d.lifecycle("Initialize", "BeaconFacade ready"),
          "morph" === this.experience && this.beacon.fireMorphAdBeacon(),
          (this.useSandboxedIframeViewability =
            !!this.adData.isAPI &&
            !!this.adData.useIframeForCreativeLoading &&
            !this.adData.buildMorphAdMarkup),
          (this.viewabilityTracker = new B({
            containerId:
              "morph" === this.experience ? "morphContainer" : "inmobi-ad",
            creativeInsideIframe: this.adData.useIframeForCreativeLoading,
            useDirectCreativeViewability:
              "morph" !== this.experience &&
              !this.adData.buildMorphAdMarkup &&
              !this.adData.useIframeForCreativeLoading,
            useSandboxedIframeViewability: this.useSandboxedIframeViewability,
            mrcViewableNonce:
              null !== (t = this.adData.mrcViewableNonce) && void 0 !== t
                ? t
                : "",
          })),
          this.setupClickHandlers(),
          this.setupAdReporting(),
          null ===
            (r =
              null === (n = this.options) || void 0 === n
                ? void 0
                : n.onBeaconReady) ||
            void 0 === r ||
            r.call(n, this.beacon),
          d.lifecycle(
            "Initialize",
            "Click handlers, ad reporting & cookie sync ready"
          ),
          await this.startAdFlow();
      } catch (e) {
        d.error("Init", "BannerAd initialization failed", e),
          i({
            action: "init_error",
            label: ((null == e ? void 0 : e.message) || String(e)).substring(
              0,
              200
            ),
          });
      }
    }
    initializeExperience() {
      if ("morph" === this.experience)
        d.error(
          "Initialize",
          "Morph plugin not registered — cannot render morph ad"
        );
      else {
        d.lifecycle(
          "Initialize",
          "Creative experience — creative rendered by banner.vm"
        );
        const e = Ce();
        e && e.resize(this.adData);
      }
    }
    parseAdData() {
      var e;
      return (function (e) {
        const i = Object.assign({}, e);
        Object.keys(i).forEach((e) => {
          const t = i[e];
          "string" == typeof t && t.startsWith("$") && (i[e] = null);
        });
        const t = (e) => i[e] || "",
          n = (e) => "true" === i[e] || !0 === i[e],
          r = (e) => {
            var t;
            return (
              parseInt(
                String(null !== (t = i[e]) && void 0 !== t ? t : "0"),
                10
              ) || 0
            );
          },
          a = i.logInfo;
        return {
          isAPI: !1 !== i.isAPI && "false" !== i.isAPI,
          adType: "banner",
          namespace: t("namespace"),
          creativeIdentifier: t("creativeIdentifier"),
          adHeight: r("adHeight"),
          adWidth: r("adWidth"),
          creativeWidth: r("creativeWidth"),
          creativeHeight: r("creativeHeight"),
          impOnBodyLoad: n("impOnBodyLoad"),
          isVCPM: n("isVCPM"),
          isDv360AdOnePixelExp: n("isDv360AdOnePixelExp"),
          impDelayInMs: r("impDelayInMs"),
          isTrueViewEnabled: n("isTrueViewEnabled"),
          fireImpressionViaPing: n("fireImpressionViaPing"),
          fireBeaconThroughPingV2: n("fireBeaconThroughPingV2"),
          useIframeForCreativeLoading: !1 !== i.useIframeForCreativeLoading,
          lazyLoadCreative: n("lazyLoadCreative"),
          isDisableCreativeResize: n("isDisableCreativeResize"),
          disableResizingCompletely: !0 === i.disableResizingCompletely,
          isWebSdkIntegration: !0 === i.isWebSdkIntegration,
          omidEnabled: "false" !== i.omidEnabled && !1 !== i.omidEnabled,
          imaiConfigList: Array.isArray(i.imaiConfigList)
            ? i.imaiConfigList
            : [],
          omidConfigList: Array.isArray(i.omidConfigList)
            ? i.omidConfigList
            : [],
          omid13: n("omid13"),
          omidJsSessionClientVersion: t("omidJsSessionClientVersion"),
          logInfo: {
            publisherID: (null == a ? void 0 : a.publisherID) || "",
            placementID: (null == a ? void 0 : a.placementID) || "",
            sdkVersion: (null == a ? void 0 : a.sdkVersion) || "",
            impressionID: (null == a ? void 0 : a.impressionID) || "",
            bundleID: (null == a ? void 0 : a.bundleID) || "",
            integrationType: (null == a ? void 0 : a.integrationType) || "",
            integrationDirect: (null == a ? void 0 : a.integrationDirect) || "",
            templateID: (null == a ? void 0 : a.templateID) || "",
            aBChannel: (null == a ? void 0 : a.aBChannel) || "",
          },
          optOutUrl:
            t("optOutUrl") || "https://www.inmobi.com/ad-opt-out?i=%7B%7D",
          isNewAdChoice: n("isNewAdChoice"),
          adChoiceIconPosition: t("adChoiceIconPosition") || "leftBottom",
          webviewWidth: r("webviewWidth"),
          webviewHeight: r("webviewHeight"),
          dspId: t("dspId"),
          shouldDetectBlankAd: !0 === i.shouldDetectBlankAd,
          detectBlankAdDelay: r("detectBlankAdDelay") || 4e3,
          detectBlankAdLabel:
            t("detectBlankAdLabel") || "blank-space-percentage",
          blankAdGutter: r("blankAdGutter") || 10,
          shouldFireBeaconOnClickFailure:
            !0 === i.shouldFireBeaconOnClickFailure,
          shouldFireBeaconOnCloseFailure:
            !0 === i.shouldFireBeaconOnCloseFailure,
          fireBlankAdDetectionBeacon: !0 === i.fireBlankAdDetectionBeacon,
          fireCreativeResizeBeacon: !0 === i.fireCreativeResizeBeacon,
          fireCreativeCenteredBeacon: !0 === i.fireCreativeCenteredBeacon,
          fireCreativeOutOfViewportBeacon:
            !0 === i.fireCreativeOutOfViewportBeacon,
          centerMarginThreshold: r("centerMarginThreshold") || 20,
          distanceFromViewport: r("distanceFromViewport") || 40,
          resizeDelay: r("resizeDelay"),
          resizedAdPosition: t("resizedAdPosition") || "center",
          isFireM120Beacon: n("isFireM120Beacon"),
          backendLoggingEnabled: n("backendLoggingEnabled"),
          isAdChoiceIconDisabled:
            !0 === i.isAdChoiceIconDisabled || n("isAdChoiceIconDisabled"),
          adQualityUrl: t("adQualityUrl"),
          enableUserAdReportScreenshot:
            "true" === i.enableUserAdReportScreenshot ? "1" : "0",
          adReportSubmitMessage:
            t("adReportSubmitMessage") || "Thank you for your feedback",
          adReportCategories: Array.isArray(i.adReportCategories)
            ? i.adReportCategories
            : [
                "Shown too frequently",
                "No ad was shown",
                "Inappropriate or Offensive",
              ],
          buildMorphAdMarkup: n("buildMorphAdMarkup"),
          openingLandingUrl: t("openingLandingUrl"),
          title: t("title"),
          cta: t("cta"),
          description: t("description"),
          iconUrl: t("iconUrl"),
          mainUrl: t("mainUrl"),
          nativeMorphBgColor: t("nativeMorphBgColor"),
          nativeMorphTextColor: t("nativeMorphTextColor"),
          nativeMorphDescColor: t("nativeMorphDescColor"),
          nativeMorphCtaTextColor: t("nativeMorphCtaTextColor"),
          nativeMorphCtaBgColor: t("nativeMorphCtaBgColor"),
          isTouchEnabledForCTA:
            !0 === i.isTouchEnabledForCTA || n("isTouchEnabledForCTA"),
          isTouchStartGestureEnabled:
            !0 === i.isTouchStartGestureEnabled ||
            n("isTouchStartGestureEnabled"),
          isCTAGoToButtonEnabled:
            !0 === i.isCTAGoToButtonEnabled || n("isCTAGoToButtonEnabled"),
          isMwebRequest: n("isMwebRequest"),
          resolvedOptOut: t("resolvedOptOut"),
          cookieSyncUrl:
            t("cookieSyncUrl") ||
            "https://sync.inmobi.com/sync?redirect=&gdpr=&gdpr_consent=&us_privacy=&gdpr_pd=&source=4",
          mrcViewableNonce:
            "string" == typeof i.mrcViewableNonce ? i.mrcViewableNonce : void 0,
        };
      })(null !== (e = window.templateData) && void 0 !== e ? e : {});
    }
    initializeServerLogging() {
      var e, i, t;
      const n = null !== (e = this.adData.logInfo) && void 0 !== e ? e : {};
      c({
        project: "web-banner",
        version: "1.0.0",
        scale:
          null !==
            (t =
              null === (i = window.loggerConfig) || void 0 === i
                ? void 0
                : i.SCALE) && void 0 !== t
            ? t
            : 0.001,
        isServerSideLogging: this.adData.backendLoggingEnabled,
        vitals: {
          dspID: g(this.adData.creativeIdentifier),
          publisherID: n.publisherID,
          placementID: n.placementID,
          impressionID: n.impressionID,
          bundleID: n.bundleID,
          integrationType: n.integrationType,
          integrationDirect: n.integrationDirect,
          templateID: n.templateID,
          aBChannel: n.aBChannel,
          morph: this.adData.buildMorphAdMarkup,
          isAPI: this.adData.isAPI,
        },
      });
    }
    async startAdFlow() {
      d.lifecycle("AdFlow", "Starting ad flow"),
        this.beacon.fireNURLBeacon(),
        this.checkMraidThenFireImpression();
      try {
        this.startViewabilityTracking();
      } catch (e) {
        d.error("Viewability", "Viewability tracking failed to start", e);
      }
      this.listenForCreativeLoad(),
        this.setupLandingListeners(),
        await this.fireAdReady(),
        d.lifecycle("AdFlow", "All listeners registered");
    }
    fireImpressionFlow() {
      return this.adData.impOnBodyLoad
        ? (d.info("Impression", "impOnBodyLoad — waiting for document load"),
          void new Promise((e) => {
            "complete" === document.readyState
              ? e("loaded")
              : window.addEventListener("load", () => e("loaded"), {
                  once: !0,
                });
          }).then(() => this.handleImpressionAfterGates()))
        : this.adData.isVCPM
        ? (d.info("Impression", "VCPM — delaying 1000ms"),
          void setTimeout(() => this.handleImpressionAfterGates(), 1e3))
        : void this.handleImpressionAfterGates();
    }
    handleImpressionAfterGates() {
      this.fireImpressionWithDelay();
    }
    fireImpressionWithDelay() {
      this.adData.impDelayInMs > 0
        ? (d.info("Impression", `Delayed by ${this.adData.impDelayInMs}ms`),
          setTimeout(
            () => this.beacon.fireImpressionBeacons(),
            this.adData.impDelayInMs
          ))
        : this.beacon.fireImpressionBeacons();
    }
    checkMraidThenFireImpression() {
      var e, i;
      const t = this.getMraid();
      if (t) {
        try {
          if (null === (e = t.isViewable) || void 0 === e ? void 0 : e.call(t))
            return void this.fireImpressionFlow();
        } catch (e) {
          return void this.fireImpressionFlow();
        }
        try {
          const e = (i) => {
            var n;
            i &&
              (null === (n = t.removeEventListener) ||
                void 0 === n ||
                n.call(t, "viewableChange", e),
              this.fireImpressionFlow());
          };
          null === (i = t.addEventListener) ||
            void 0 === i ||
            i.call(t, "viewableChange", e);
        } catch (e) {
          this.fireImpressionFlow();
        }
      } else this.fireImpressionFlow();
    }
    getMraid() {
      try {
        const e = window.mraid;
        if (e && "function" == typeof e.isViewable) return e;
      } catch (e) {}
      return null;
    }
    waitForOnePixelRendered() {
      return new Promise((e) => {
        try {
          const i = window.OmidCustomVerificationClient;
          if (!(null == i ? void 0 : i.addEventListener)) return void e();
          const t = (t) => {
            var n, r, a;
            const o =
              null ===
                (a =
                  null ===
                    (r =
                      null === (n = null == t ? void 0 : t.data) || void 0 === n
                        ? void 0
                        : n.adView) || void 0 === r
                    ? void 0
                    : r.onScreenGeometry) || void 0 === a
                ? void 0
                : a.pixels;
            !isNaN(o) &&
              o > 0 &&
              (i.removeEventListener("geometryChange"), e());
          };
          i.addEventListener("geometryChange", t),
            setTimeout(() => {
              e();
            }, 5e3);
        } catch (i) {
          e();
        }
      });
    }
    startTrueViewTimeout() {
      setTimeout(() => {
        this.beacon.isImpressionFired() ||
          d.warn("TrueView", "TrueView timeout 10s — no viewable");
      }, 1e4);
    }
    startViewabilityTracking() {
      this.viewabilityStarted ||
        ((this.viewabilityStarted = !0),
        d.lifecycle("Viewability", "Starting viewability tracking"),
        this.viewabilityTracker.start(
          () => this.onAdViewable(),
          () => this.onAdMrcViewable()
        ));
    }
    onAdViewable() {
      (this.adViewableTimestamp = Date.now()),
        d.lifecycle("Viewability", "Ad is VIEWABLE (any pixel visible)"),
        this.beacon.fireViewableBeacon(),
        this.adData.lazyLoadCreative &&
          (d.lifecycle(
            "LazyLoad",
            "Ad viewable — dispatching lazy_load_creative"
          ),
          window.dispatchEvent(new Event("lazy_load_creative")));
    }
    onAdMrcViewable() {
      d.lifecycle("Viewability", "Ad is MRC VIEWABLE (50% for 1s)"),
        this.beacon.fireMRCViewableBeacon(0);
    }
    setupAdReporting() {
      this.adReportManager = new fe(this.adData, this.beacon);
      new we(this.adData, () => {
        this.adReportManager.open();
      }).render(),
        d.lifecycle("AdReport", "Ad choice icon & report manager initialized");
    }
    setupCookieSync() {
      if (!this.adData.isMwebRequest) return;
      if ("1" === this.adData.resolvedOptOut)
        return void d.info("CookieSync", "Skipped — user opted out");
      new ye(this.adData.cookieSyncUrl).setup();
    }
    injectGlobalStyles() {
      if (document.getElementById("web-banner-global-styles")) return;
      const e = "morph" === this.experience,
        i = document.createElement("style");
      (i.id = "web-banner-global-styles"),
        (i.textContent = `\n      body {\n        margin: 0;\n        width: 100%;\n        height: 100vh;\n        overflow: hidden;\n        font-family: Helvetica, serif;\n        cursor: pointer;\n        -webkit-tap-highlight-color: transparent;\n      }\n      iframe {\n        border: 0;\n      }\n      #inmobi-ad {\n        position: relative;\n        background: linear-gradient(\n          168.24deg,\n          rgba(236, 242, 255, 0.9) -0.72%,\n          rgba(189, 210, 255, 0.9) 53.58%,\n          rgba(222, 233, 255, 0.9) 101.03%\n        );\n        backdrop-filter: blur(16px);\n      }\n      ${
          e
            ? "\n      #morphContainer {\n        height: 100%;\n        width: 100%;\n        position: absolute;\n        left: 0;\n        top: 0;\n      }"
            : ""
        }\n    `),
        document.head.appendChild(i);
    }
    setupClickHandlers() {
      window.addEventListener("message", (e) => {
        var i, t, n, r;
        const a = null === (i = e.data) || void 0 === i ? void 0 : i.eventType;
        if ("iframe-clicked" === a) {
          const { clientX: i, clientY: t } = e.data.eventData || {};
          d.lifecycle("Click", `iframe-clicked at (${i}, ${t})`),
            this.handleAdClick(i, t, "iframe");
        } else
          "creative-anchor-click" === a
            ? (d.lifecycle(
                "Click",
                `creative-anchor-click: ${
                  null === (t = e.data.eventData) || void 0 === t
                    ? void 0
                    : t.url
                }`
              ),
              this.fireClickBeaconOnce("creative_anchor_click"))
            : "creative-window-open" === a
            ? (d.lifecycle(
                "Click",
                `creative-window-open: ${
                  null === (n = e.data.eventData) || void 0 === n
                    ? void 0
                    : n.url
                }`
              ),
              this.fireClickBeaconOnce("creative_window_open"))
            : "creative-mraid-open" === a &&
              (d.lifecycle(
                "Click",
                `creative-mraid-open: ${
                  null === (r = e.data.eventData) || void 0 === r
                    ? void 0
                    : r.url
                }`
              ),
              this.fireClickBeaconOnce("creative_mraid_open"));
      }),
        window.addEventListener("inmobi-ad-interaction", (e) => {
          const i = e.detail;
          (null == i ? void 0 : i.clickSource) &&
            (d.lifecycle(
              "Click",
              `Synthetic interaction from ${i.clickSource}`
            ),
            this.fireClickBeaconOnce(i.clickSource, i.clickPhase),
            this.fireInteractionBeaconOnce(i.clickPhase),
            "number" == typeof i.clientX &&
              "number" == typeof i.clientY &&
              window.dispatchEvent(
                new CustomEvent("ad_clicked", {
                  detail: { clientX: i.clientX, clientY: i.clientY },
                })
              ));
        }),
        document.addEventListener("click", (e) => {
          const i =
            document.getElementById("inmobi-ad") ||
            document.getElementById("morphContainer");
          (null == i ? void 0 : i.contains(e.target)) &&
            (d.lifecycle(
              "Click",
              `document click at (${e.clientX}, ${e.clientY})`
            ),
            this.handleAdClick(e.clientX, e.clientY, "document"));
        });
    }
    handleAdClick(e, i, t) {
      if (this.hasHandledClick) return;
      const n = this.adData.useIframeForCreativeLoading
        ? this.isClickOnValidElement(e, i)
        : this.isClickOnValidNonIframeElement(e, i);
      "morph" === this.experience || n
        ? ((this.hasHandledClick = !0),
          this.fireClickBeaconOnce(t),
          this.fireInteractionBeaconOnce(),
          window.dispatchEvent(
            new CustomEvent("ad_clicked", {
              detail: { clientX: e, clientY: i },
            })
          ))
        : d.info("Click", "Click on invalid element — ignored");
    }
    fireClickBeaconOnce(e, i) {
      if (this.hasFiredClickBeacon) return;
      d.lifecycle("Click", `Valid click from ${e} — firing click beacons`);
      this.beacon.fireClickBeacons(e, i) && (this.hasFiredClickBeacon = !0);
    }
    isClickOnValidElement(e, i) {
      var t;
      try {
        const n = document.elementFromPoint(e, i);
        if (!n) return !1;
        if ("IFRAME" === n.tagName && n.id === I)
          try {
            const r = n,
              a =
                r.contentDocument ||
                (null === (t = r.contentWindow) || void 0 === t
                  ? void 0
                  : t.document);
            if (!a) return !0;
            const o = a.elementFromPoint(e, i);
            return !o || ("HTML" !== o.tagName && "BODY" !== o.tagName);
          } catch (e) {
            return !0;
          }
        return "HTML" !== n.tagName && "BODY" !== n.tagName;
      } catch (e) {
        return !1;
      }
    }
    isClickOnValidNonIframeElement(e, i) {
      try {
        const t = document.getElementById("inmobi-ad"),
          n = document.elementFromPoint(e, i);
        return (
          !!(t && n && t.contains(n)) &&
          "HTML" !== n.tagName &&
          "BODY" !== n.tagName
        );
      } catch (e) {
        return !1;
      }
    }
    listenForCreativeLoad() {
      const e = () => {
          this.reportDirectCreativeDiagnostics(),
            this.beacon.creativeLoaded(),
            this.adData.isFireM120Beacon &&
              (d.lifecycle("CreativeLoad", "Firing M120 load beacon"),
              this.beacon.fireLoadBeacon()),
            this.viewabilityStarted || this.startViewabilityTracking();
        },
        i = () => {
          d.lifecycle("CreativeLoad", "creative_loaded event received"),
            window.removeEventListener("creative_loaded", i),
            e();
        };
      window.creativeLoaded
        ? (d.lifecycle("CreativeLoad", "Creative already loaded"), e())
        : (d.info("CreativeLoad", "Waiting for creative_loaded event"),
          window.addEventListener("creative_loaded", i));
    }
    reportDirectCreativeDiagnostics() {
      try {
        if (
          this.hasReportedDirectCreativeDiagnostics ||
          "morph" === this.experience ||
          this.adData.buildMorphAdMarkup ||
          this.adData.useIframeForCreativeLoading
        )
          return;
        this.hasReportedDirectCreativeDiagnostics = !0;
        const e = document.getElementById("child"),
          t = !!(null == e ? void 0 : e.querySelector("iframe")),
          n = this.getBrowserVersionLabel(navigator.userAgent);
        d.lifecycle("Creative", `Direct creative contains iframe: ${t}`),
          i({
            action: "creative_iframe_presence",
            label: t ? "true" : "false",
          }),
          d.lifecycle("Creative", `Direct creative browser version: ${n}`),
          i({ action: "direct_flow_browser_version", label: n });
      } catch (e) {
        d.warn("Creative", "Failed to report direct creative diagnostics", e);
      }
    }
    getBrowserVersionLabel(e) {
      const i = [
        ["Edge", /Edg(?:A|iOS)?\/(\d+)/],
        ["Opera", /OPR\/(\d+)/],
        ["SamsungInternet", /SamsungBrowser\/(\d+)/],
        ["Firefox", /(?:Firefox|FxiOS)\/(\d+)/],
        ["Chrome", /(?:Chrome|CriOS)\/(\d+)/],
        ["Safari", /Version\/(\d+)(?:\.\d+)*[^\n]*Safari\//],
      ];
      for (const [t, n] of i) {
        const i = e.match(n);
        if (null == i ? void 0 : i[1]) return `${t}_${i[1]}`;
      }
      return "Unknown_0";
    }
    setupLandingListeners() {
      var e, i;
      try {
        const t = window.imraid;
        if (!t) return;
        null === (e = t.addEventListener) ||
          void 0 === e ||
          e.call(t, "onUserLandingInitialized", () => {
            d.lifecycle("Landing", "User redirected to landing page (SDK)"),
              this.fireClickBeaconOnce("sdk_landing"),
              this.fireInteractionBeaconOnce(),
              this.hasFiredLandingInitBeacon ||
                ((this.hasFiredLandingInitBeacon = !0),
                d.lifecycle(
                  "Landing",
                  "Firing landing initialized beacon (m=37)"
                ),
                this.beacon.fireLandingsInitializedBeacon());
          }),
          null === (i = t.addEventListener) ||
            void 0 === i ||
            i.call(t, "onUserLandingCompleted", () => {
              this.hasFiredLandingCompleteBeacon ||
                ((this.hasFiredLandingCompleteBeacon = !0),
                d.lifecycle(
                  "Landing",
                  "User returned from landing page — firing m=34"
                ),
                this.beacon.fireLandingsBeacon());
            });
      } catch (e) {
        d.warn(
          "Landing",
          "Failed to setup landing listeners — SDK bridge may not be available"
        );
      }
    }
    async waitForSdkReady() {
      try {
        const e = window,
          i = e._im_imai;
        if (!i) return;
        if (/iPhone|iPad|iPod/i.test(navigator.userAgent))
          await Promise.race([
            new Promise((e) => {
              var t;
              try {
                const n = () => {
                  var t;
                  null === (t = i.removeEventListener) ||
                    void 0 === t ||
                    t.call(i, "ready", n),
                    d.lifecycle("SDK", "IMAI ready callback received (iOS)"),
                    e();
                };
                null === (t = i.addEventListener) ||
                  void 0 === t ||
                  t.call(i, "ready", n);
              } catch (i) {
                e();
              }
            }),
            this.waitForMraidReady(),
            new Promise((e) => setTimeout(e, 5e3)),
          ]);
        else {
          if (e.mraid)
            return void d.lifecycle(
              "SDK",
              "mraid present — resolving immediately (Android)"
            );
          await new Promise((e) => setTimeout(e, 5e3));
        }
      } catch (e) {
        d.warn("SDK", "waitForSdkReady failed — continuing", e);
      }
    }
    waitForMraidReady() {
      try {
        const e = window.mraid;
        if (!e) return new Promise((e) => setTimeout(e, 5e3));
        let i;
        try {
          i = "function" == typeof e.getState ? e.getState() : void 0;
        } catch (e) {}
        return i && "loading" !== i
          ? (d.lifecycle("SDK", "MRAID already ready"), Promise.resolve())
          : new Promise((i) => {
              var t;
              try {
                const n = () => {
                  var t;
                  try {
                    null === (t = e.removeEventListener) ||
                      void 0 === t ||
                      t.call(e, "ready", n);
                  } catch (e) {}
                  d.lifecycle("SDK", "MRAID ready callback received"), i();
                };
                null === (t = e.addEventListener) ||
                  void 0 === t ||
                  t.call(e, "ready", n);
              } catch (e) {
                i();
              }
            });
      } catch (e) {
        return Promise.resolve();
      }
    }
    async fireAdReady() {
      var e, i, t;
      try {
        await this.waitForSdkReady();
        const n = window._im_imai;
        n &&
          "function" == typeof n.fireAdReady &&
          (n.fireAdReady(), d.lifecycle("SDK", "fireAdReady called")),
          window.dispatchEvent(new Event("template_ad_ready")),
          null ===
            (t =
              null ===
                (i =
                  null === (e = window.AD_TECH_UI) || void 0 === e
                    ? void 0
                    : e.EventHub) || void 0 === i
                ? void 0
                : i.publish) ||
            void 0 === t ||
            t.call(i, "SDK_AD_READY_FIRED"),
          this.beacon.fireSdkAdReadyMetric();
      } catch (e) {}
    }
    fireInteractionBeaconOnce(e = 0) {
      if (this.hasFiredInteractionBeacon) return;
      this.hasFiredInteractionBeacon = !0;
      const i =
        this.adViewableTimestamp > 0
          ? Math.max(
              0,
              Math.floor((Date.now() - this.adViewableTimestamp) / 1e3)
            )
          : 0;
      this.adViewableTimestamp <= 0 &&
        d.info(
          "Interaction",
          "First interaction happened before viewable; sending m=39 with t=0"
        ),
        d.lifecycle("Interaction", `First interaction — ${i}s since viewable`),
        this.beacon.fireInteractionBeacon(0, e, i);
    }
  })("creative");
  Ae.initialize();
})();
