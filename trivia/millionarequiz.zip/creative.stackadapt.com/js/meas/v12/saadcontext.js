!(function () {
  "use strict";
  let P = document,
    B = window;
  if (void 0 !== P && void 0 !== B) {
    var e = P.currentScript || P.getElementById("sa-ad-context-script");
    if (e) {
      let w = B.setTimeout || setTimeout,
        I = B.setInterval || setInterval,
        E = B.clearTimeout || clearTimeout,
        D = B.clearInterval || clearInterval,
        L = () => {
          var e = B.performance;
          return (e && "function" == typeof e.now ? e : Date).now();
        },
        C = L(),
        S = "sa-content-div-pSdBShew0A",
        H = 0.5,
        W = 0.3,
        O = 242500,
        U = 1e3,
        R = 6,
        x = 5e3,
        A = 32,
        F = 1024,
        M = -1;
      let V = 12e5;
      class z {
        constructor() {
          (this.iframeWidth = null),
            (this.iframeHeight = null),
            (this.screenWidth = null),
            (this.screenHeight = null),
            (this.topOrigin = null),
            (this.visible = null),
            (this.originDepth = null),
            (this.originChain = null),
            (this.bottomOrigin = null);
        }
        hasDifferences(e) {
          var t;
          return (
            !(e && e instanceof z) ||
            (t = (e, t) =>
              !(
                (null === e && null === t) ||
                (null !== e && null !== t && e === t)
              ))(this.iframeWidth, e.iframeWidth) ||
            t(this.iframeHeight, e.iframeHeight) ||
            t(this.topOrigin, e.topOrigin) ||
            t(this.originDepth, e.originDepth)
          );
        }
        toParams() {
          var e = {};
          return (
            null !== this.iframeWidth && (e.w = Math.round(this.iframeWidth)),
            null !== this.iframeHeight && (e.h = Math.round(this.iframeHeight)),
            null !== this.screenWidth && (e.sw = Math.round(this.screenWidth)),
            null !== this.screenHeight &&
              (e.sh = Math.round(this.screenHeight)),
            null !== this.topOrigin && (e.to = this.topOrigin),
            null !== this.visible && (e.vis = this.visible),
            null !== this.originDepth && (e.od = this.originDepth),
            null !== this.originChain && (e.oc = this.originChain),
            null !== this.bottomOrigin &&
              "" !== this.bottomOrigin &&
              (e.bo = this.bottomOrigin),
            e
          );
        }
      }
      let k = new (class {
        constructor(e) {
          (this.purl = e.getAttribute("purl")),
            (this.auctionID = e.getAttribute("aid")),
            (this.impID = e.getAttribute("iid")),
            (this.networkID = e.getAttribute("nid")),
            (this.campaignID = e.getAttribute("cid")),
            (this.advertiserID = e.getAttribute("advid")),
            (this.nativeAdID = e.getAttribute("naid")),
            (this.brDomain = e.getAttribute("br_domain")),
            (this.expectedHeight = e.getAttribute("eh")),
            (this.expectedWidth = e.getAttribute("ew")),
            (this.adElement = null),
            (this.cleanupFns = []),
            (this.currentData = new z());
        }
        getPixelURL() {
          return (
            this.purl +
            "/adcontext/display?aid=" +
            encodeURIComponent(this.auctionID) +
            "&iid=" +
            encodeURIComponent(this.impID) +
            "&nid=" +
            this.networkID +
            "&cid=" +
            this.campaignID +
            "&advid=" +
            this.advertiserID +
            "&naid=" +
            this.nativeAdID +
            "&br_domain=" +
            encodeURIComponent(this.brDomain) +
            "&eh=" +
            this.expectedHeight +
            "&ew=" +
            this.expectedWidth
          );
        }
        getLogErrorPixelURL() {
          return (
            this.purl +
            "/log-error/display?aid=" +
            encodeURIComponent(this.auctionID) +
            "&iid=" +
            encodeURIComponent(this.impID) +
            "&nid=" +
            this.networkID +
            "&cid=" +
            this.campaignID +
            "&advid=" +
            this.advertiserID +
            "&naid=" +
            this.nativeAdID +
            "&br_domain=" +
            encodeURIComponent(this.brDomain) +
            "&eh=" +
            this.expectedHeight +
            "&ew=" +
            this.expectedWidth
          );
        }
        cleanup() {
          var e = this.cleanupFns;
          (this.cleanupFns = []),
            e.forEach((e) => {
              try {
                e();
              } catch (e) {}
            });
        }
      })(e);
      if (k.purl) {
        let r = (e = P) => e.createElement("img"),
          i = (t, i) => {
            var n = () => {
              try {
                t.img_requests || (t.img_requests = []);
                var e = r(t.document);
                (e.src = i), t.img_requests.push(e);
              } catch (e) {}
            };
            if (t.fetch)
              try {
                t.fetch(i, {
                  keepalive: !0,
                  method: "get",
                  mode: "no-cors",
                }).catch(n);
              } catch (e) {
                n();
              }
            else n();
          },
          t = 3,
          n = 0,
          l = (e) => {
            n >= t || (n++, i(B, k.getLogErrorPixelURL() + e));
          },
          d = (e) =>
            function () {
              try {
                return e.apply(this, arguments);
              } catch (e) {
                k.cleanup(), l("&msg=" + encodeURIComponent(e.toString()));
              }
            };
        let u = ((n) => {
            let r = {},
              a = null,
              s = !1,
              h = () => {
                a && (E(a), (a = null));
                var e = r;
                r = {};
                let t;
                try {
                  t = ((t) => {
                    let i = "";
                    var n = Object.keys(t);
                    for (let e = 0; e < n.length; e++) {
                      var r = n[e],
                        a = t[r];
                      if (null != a)
                        if (Array.isArray(a))
                          for (let e = 0; e < a.length; e++)
                            i += "&" + r + "=" + encodeURIComponent(a[e]);
                        else i += "&" + r + "=" + encodeURIComponent(a);
                    }
                    return i;
                  })(e);
                } catch (e) {
                  return void l("&msg=" + encodeURIComponent(e.toString()));
                }
                t && i(B, k.getPixelURL() + t);
              };
            return {
              flush: h,
              report(t, e) {
                var i = Object.keys(t);
                for (let e = 0; e < i.length; e++) r[i[e]] = t[i[e]];
                e || s ? h() : (a = a || w(d(h), n));
              },
              beginUnload() {
                s = !0;
              },
            };
          })(
            (() => {
              try {
                var e = B.navigator || {},
                  t = e.userAgent || "";
                return /iphone|ipad|ipod/i.test(t)
                  ? !0
                  : /macintosh/i.test(t) && 1 < e.maxTouchPoints;
              } catch (e) {
                return !1;
              }
            })()
              ? 1e3
              : 3e3
          ),
          e =
            (k.cleanupFns.push(() => u.flush()),
            d(() => {
              P.hidden && u.flush();
            }));
        try {
          P.addEventListener("visibilitychange", e),
            k.cleanupFns.push(() =>
              P.removeEventListener("visibilitychange", e)
            );
        } catch (e) {}
        let g = (e, t) => (e * t >= O ? W : H),
          p = () => {
            try {
              var e = B.top && B.top.document;
              if (e && "function" == typeof e.hasFocus) return e;
            } catch (e) {}
            return null;
          },
          m = (t) => {
            let i = null,
              n = !1;
            return {
              setInView(e) {
                n ||
                  (e
                    ? (i =
                        i ||
                        w(() => {
                          (i = null), n || ((n = !0), t());
                        }, U))
                    : i && (E(i), (i = null)));
              },
              cancel() {
                i && (E(i), (i = null));
              },
            };
          },
          a = (c) => ({
            name: "web",
            init(e) {
              e();
            },
            getDimensions() {
              var e = P.documentElement,
                t = P.body;
              return {
                iframeWidth:
                  B.innerWidth ||
                  (e && e.clientWidth) ||
                  (t && t.clientWidth) ||
                  0,
                iframeHeight:
                  B.innerHeight ||
                  (e && e.clientHeight) ||
                  (t && t.clientHeight) ||
                  0,
              };
            },
            getScreenSize() {
              var e = B.screen || {};
              return { screenWidth: e.width || 0, screenHeight: e.height || 0 };
            },
            getOrigins() {
              var t = { top: "none", depth: M, chain: [], bottom: "" };
              let i;
              try {
                i = B.location.ancestorOrigins;
              } catch (e) {
                return t;
              }
              if (!i || "number" != typeof i.length) return t;
              if (0 === i.length)
                return { top: "none", depth: 0, chain: [], bottom: "" };
              var n = [];
              let r = 0;
              for (let e = i.length - 1; 0 <= e && n.length < A; e--) {
                var a = String(i[e]);
                if (r + a.length > F) break;
                n.push(a), (r += a.length);
              }
              return {
                top: i[i.length - 1],
                depth: i.length,
                chain: n,
                bottom: i[0],
              };
            },
            getVisible() {
              return P.hidden ? "0" : "1";
            },
            setUpViewability() {
              if (!c) return null;
              if (!("IntersectionObserver" in B)) return null;
              let e,
                t = m(() => {
                  u.report({ view: 1 }, !0);
                  try {
                    e.disconnect();
                  } catch (e) {}
                });
              var i = c.getBoundingClientRect();
              let n = g(i.width, i.height),
                r = p(),
                a = !1,
                s = () => t.setInView(a && !P.hidden && (!r || r.hasFocus())),
                h = !1;
              try {
                (e = new IntersectionObserver(
                  (e) => {
                    e.forEach((e) => {
                      var t;
                      h ||
                        ((t = { viewi: e.intersectionRatio.toFixed(4) }),
                        e.rootBounds &&
                          ((t.vw = Math.round(e.rootBounds.width)),
                          (t.vh = Math.round(e.rootBounds.height))),
                        u.report(t),
                        (h = !0)),
                        (a = e.intersectionRatio >= n);
                    }),
                      s();
                  },
                  { threshold: n }
                )).observe(c);
              } catch (e) {
                return t.cancel(), null;
              }
              let o = d(s),
                l = d(s);
              try {
                P.addEventListener("visibilitychange", o),
                  r &&
                    (B.top.addEventListener("focus", l),
                    B.top.addEventListener("blur", l));
              } catch (e) {}
              return [
                () => t.cancel(),
                () => e.disconnect(),
                () => P.removeEventListener("visibilitychange", o),
                () => {
                  r &&
                    (B.top.removeEventListener("focus", l),
                    B.top.removeEventListener("blur", l));
                },
              ];
            },
          }),
          s = (a) => {
            let s = (e, t, ...i) => {
                try {
                  var n,
                    r = a[e];
                  return "function" != typeof r
                    ? t
                    : void 0 === (n = r.apply(a, i))
                    ? t
                    : n;
                } catch (e) {
                  return t;
                }
              },
              h = (e, t) => {
                try {
                  return (
                    a.addEventListener(e, t),
                    k.cleanupFns.push(() =>
                      s("removeEventListener", null, e, t)
                    ),
                    !0
                  );
                } catch (e) {
                  return !1;
                }
              };
            var e = s("getVersion", "") || "";
            let o = 3 <= parseInt(e, 10);
            return {
              name: "mraid",
              init(n, r) {
                let a = (e, t) => {
                  try {
                    l(
                      "&code=" +
                        R +
                        "&msg=" +
                        encodeURIComponent("mraid: " + (e || ""))
                    );
                  } catch (e) {}
                };
                if ((h("error", a), "loading" !== s("getState", "ready"))) n();
                else {
                  let t = !1,
                    i = (e) => {
                      t || ((t = !0), (e && r ? r : n)());
                    };
                  if (h("ready", () => i(!1)))
                    if (
                      (h("stateChange", (e) => {
                        e && "loading" !== e && i(!1);
                      }),
                      "loading" !== s("getState", "ready"))
                    )
                      i(!1);
                    else {
                      let e = w(() => {
                        t ||
                          (a("SDK did not fire ready within " + x + "ms"),
                          i(!0));
                      }, x);
                      k.cleanupFns.push(() => E(e));
                    }
                  else i(!0);
                }
              },
              getDimensions() {
                let e = s("getCurrentPosition", null);
                return {
                  iframeWidth:
                    ((e =
                      e &&
                      -1 !== e.width &&
                      -1 !== e.height &&
                      (0 !== e.width || 0 !== e.height)
                        ? e
                        : s("getMaxSize", null)) &&
                      e.width) ||
                    0,
                  iframeHeight: (e && e.height) || 0,
                };
              },
              getScreenSize() {
                var e = s("getScreenSize", null) || {};
                return {
                  screenWidth: e.width || 0,
                  screenHeight: e.height || 0,
                };
              },
              getOrigins() {
                let e = "in-app";
                var t;
                return {
                  top: (e = o && (t = s("getAppId", null)) ? t : e),
                  depth: null,
                  chain: [],
                  bottom: "",
                };
              },
              getVisible() {
                return s("isViewable", !1) ? "1" : "0";
              },
              setUpViewability() {
                var e = s("getCurrentPosition", null) || {},
                  t = s("getMaxSize", null) || {},
                  i = s("isViewable", !1) ? 1 : 0;
                u.report({
                  viewi: i.toFixed(4),
                  vw: Math.round(t.width || e.width || 0),
                  vh: Math.round(t.height || e.height || 0),
                });
                let n = m(() => u.report({ view: 1 }, !0)),
                  r = g(e.width || t.width || 0, e.height || t.height || 0);
                return (
                  o
                    ? h(
                        "exposureChange",
                        d((e) => {
                          n.setInView(e >= 100 * r);
                        })
                      ) ||
                      h(
                        "viewableChange",
                        d((e) => {
                          n.setInView(!!e);
                        })
                      )
                    : h(
                        "viewableChange",
                        d((e) => {
                          n.setInView(!!e);
                        })
                      ),
                  n.setInView(1 === i),
                  [() => n.cancel()]
                );
              },
            };
          },
          h = (e) =>
            B.mraid && "function" == typeof B.mraid.getState
              ? s(B.mraid)
              : a(e),
          o = d((e) => {
            var t = k.adElement;
            t &&
              ((t = t.getBoundingClientRect()),
              u.report(
                {
                  clkx: Math.round(e.clientX - t.left),
                  clky: Math.round(e.clientY - t.top),
                },
                !0
              ));
          }),
          c = (t, i, n) => {
            let r = k.adElement;
            if (r) {
              let e = d(() => u.report({ [i]: Math.round(L() - n) }));
              try {
                r.addEventListener(t, e, { once: !0, passive: !0 }),
                  k.cleanupFns.push(() => r.removeEventListener(t, e));
              } catch (e) {}
            }
          },
          v = () => {
            let e = k.adElement;
            if (e)
              try {
                e.addEventListener("click", o, { once: !0 }),
                  k.cleanupFns.push(() => e.removeEventListener("click", o));
              } catch (e) {}
          },
          f = (i) => {
            let t = k.adElement,
              n = !1,
              r = (e, t) => {
                n ||
                  ((n = !0),
                  (e = { ttu: Math.round(L() - i), ttus: e }),
                  t && (e.ttup = 1),
                  u.report(e, !0));
              };
            var e = (t) =>
              d((e) => {
                u.beginUnload(), t(e), u.flush();
              });
            let a = e((e) => r("ph", e && e.persisted ? 1 : 0)),
              s = e(() => r("bu", 0)),
              h = e(() => r("ul", 0));
            try {
              B.addEventListener("pagehide", a),
                B.addEventListener("beforeunload", s),
                B.addEventListener("unload", h),
                k.cleanupFns.push(() => {
                  B.removeEventListener("pagehide", a),
                    B.removeEventListener("beforeunload", s),
                    B.removeEventListener("unload", h);
                });
            } catch (e) {}
            if (t && "MutationObserver" in B)
              try {
                var o = t.parentNode || P.body || P.documentElement || P;
                let e = new MutationObserver(
                  d(() => {
                    if (!P.contains(t)) {
                      r("mo", 0);
                      try {
                        e.disconnect();
                      } catch (e) {}
                    }
                  })
                );
                e.observe(o, { childList: !0, subtree: !0 }),
                  k.cleanupFns.push(() => {
                    try {
                      e.disconnect();
                    } catch (e) {}
                  });
              } catch (e) {}
          },
          b = () => {
            (k.adElement = P.getElementById(S)),
              k.adElement ||
                l("&msg=" + encodeURIComponent("ad element not found"));
            let n = h(k.adElement),
              e =
                (v(),
                c("mouseover", "tth", C),
                c("touchstart", "ttt", C),
                f(C),
                w(
                  d(() => k.cleanup()),
                  V
                )),
              i =
                (k.cleanupFns.push(() => E(e)),
                () => {
                  var e = new z(),
                    t = n.getDimensions(),
                    i = n.getScreenSize(),
                    t =
                      ((e.iframeWidth = t.iframeWidth),
                      (e.iframeHeight = t.iframeHeight),
                      (e.screenWidth = i.screenWidth),
                      (e.screenHeight = i.screenHeight),
                      (e.visible = n.getVisible()),
                      n.getOrigins());
                  (e.topOrigin = t.top),
                    (e.originDepth = t.depth),
                    (e.originChain = t.chain),
                    (e.bottomOrigin = t.bottom),
                    e.hasDifferences(k.currentData) &&
                      (((i = (k.currentData = e).toParams()).env = n.name),
                      u.report(i));
                }),
              t = () => {
                n.init(
                  d(() => {
                    i();
                    let e = I(d(i), 1e3);
                    k.cleanupFns.push(() => D(e));
                    var t = n.setUpViewability() || [];
                    k.cleanupFns.push(...t);
                  }),
                  d(() => {
                    (n = a(k.adElement)), t();
                  })
                );
              };
            t();
          },
          y = () => {
            "complete" === P.readyState
              ? w(d(b), 100)
              : B.addEventListener("load", () => w(d(b), 100));
          };
        if (P.prerendering)
          P.addEventListener(
            "prerenderingchange",
            d(() => {
              (C = L()), y();
            }),
            { once: !0 }
          );
        else if ("prerender" === P.visibilityState) {
          let e = d(() => {
            "prerender" !== P.visibilityState &&
              (P.removeEventListener("visibilitychange", e), (C = L()), y());
          });
          P.addEventListener("visibilitychange", e);
        } else y();
      }
    }
  }
})();
