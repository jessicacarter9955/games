(function () {
  try {
    var touchStartTime = 0;
    var touchStartX = 0;
    var touchStartY = 0;
    var touchEndTime = 0;
    var touchEndX = 0;
    var touchEndY = 0;
    var pointerDistance = 25;
    var pointerDurationMax = 500;
    var pointerDurationMin = 75;
    var doDebug = false;
    var disablePointerChecks = true;
    var pointerOverride = false;
    var addClickTimer = false;

    function handlePointerDown(event) {
      try {
        touchStartTime = new Date().getTime();
        touchStartX = event.clientX || event.touches[0].clientX;
        touchStartY = event.clientY || event.touches[0].clientY;
      } catch (err) {
        console.log(err);
      }
    }

    function handleClick(event) {
      if (addClickTimer && !handlePointerUp(event)) {
        return;
      }

      if (preventClickRepeat || preventPointerRepeat) return;

      preventClickRepeat = true;
      window.open(click_url, "_blank");
      if (doDebug) {
        console.log("param click");
      }
    }

    function handlePointerUp(event) {
      try {
        touchEndTime = new Date().getTime();
        touchEndX = event.clientX || event.changedTouches[0].clientX;
        touchEndY = event.clientY || event.changedTouches[0].clientY;
        var touchDuration = touchEndTime - touchStartTime;
        var touchDistanceX = Math.abs(touchEndX - touchStartX);
        var touchDistanceY = Math.abs(touchEndY - touchStartY);

        if (doDebug) {
          console.log("touch x:" + touchDistanceX);
          console.log("touch y:" + touchDistanceY);
          console.log("touch dur:" + touchDuration);
        }

        if (
          touchStartX == 0 ||
          touchStartY == 0 ||
          touchEndX == 0 ||
          touchEndY == 0 ||
          touchStartTime == 0
        ) {
          if (doDebug) {
            console.log("0 detected");
          }
          return true;
        }

        if (disablePointerChecks) {
          if (doDebug) {
            console.log("pointer checks disabled");
          }
          return true;
        }

        if (
          touchDistanceX > pointerDistance ||
          touchDistanceY > pointerDistance
        ) {
          if (doDebug) {
            console.log("pointer dropped");
          }
          return false;
        }
        if (
          touchDuration > pointerDurationMax ||
          touchDuration < pointerDurationMin
        ) {
          if (doDebug) {
            console.log("pointer dropped");
          }
          return false;
        }
        return true;
      } catch (err) {
        console.log(err);
        return true;
      }
    }

    function getUrlVars() {
      var vars = {};
      var parts = window.location.href.replace(
        /[?&]+([^=&]+)=([^&]*)/gi,
        function (m, key, value) {
          vars[key] = value;
        }
      );
      return vars;
    }

    var get_params = getUrlVars();
    var parameter_args = "";

    var click_macro = get_params["click_args"];
    if (click_macro) {
      sa_clickurl = decodeURIComponent(click_macro);
      var param_args = sa_clickurl.split("?");
      if (param_args.length > 1) {
        parameter_args = param_args[1];
      }
    } else {
      click_macro = get_params["ga_args"];
      if (click_macro) {
        sa_clickurl = decodeURIComponent(click_macro);
        var param_args = sa_clickurl.split("?");
        if (param_args.length > 1) {
          parameter_args = param_args[1];
        }
      }
    }

    var force_clickout = get_params["fclickout"];

    var disable_click = false;
    var dclickout = get_params["dclickout"];
    if (dclickout == "true") {
      disable_click = true;
    }

    try {
      var ignorePointer = get_params["satest2"];
      if (ignorePointer && ignorePointer == "true") {
        disablePointerChecks = false;
      }

      var pointerDistanceStr = get_params["pdis"];
      if (pointerDistanceStr) {
        var pointerDistanceInt = parseInt(pointerDistanceStr);
        if (!isNaN(pointerDistanceInt)) {
          pointerDistance = pointerDistanceInt;
          console.log("pdis " + pointerDistance);
          disablePointerChecks = false;
          pointerOverride = true;
        }
      }

      var pointerDurationStr = get_params["pdur"];
      if (pointerDurationStr) {
        var pointerDurationInt = parseInt(pointerDurationStr);
        if (!isNaN(pointerDurationInt)) {
          pointerDurationMax = pointerDurationInt;
          console.log("pdurmax " + pointerDurationMax);
          disablePointerChecks = false;
          pointerOverride = true;
        }
      }

      pointerDurationStr = get_params["pdurmin"];
      if (pointerDurationStr) {
        var pointerDurationInt = parseInt(pointerDurationStr);
        if (!isNaN(pointerDurationInt)) {
          pointerDurationMin = pointerDurationInt;
          console.log("pdurmin " + pointerDurationMin);
          disablePointerChecks = false;
          pointerOverride = true;
        }
      }
      var disablePointer = get_params["dpointer"];
      if (disablePointer && disablePointer == "true") {
        disablePointerChecks = true;
        pointerOverride = true;
      }

      var doDebugStr = get_params["sadebug"];
      if (doDebugStr && doDebugStr == "true") {
        console.log("param debugging");
        doDebug = true;
      }

      var addClickT = get_params["ctimer"];
      if (addClickT) {
        addClickTimer = true;
      }
    } catch (err) {
      console.log(err);
    }

    for (var key in get_params) {
      if (key.indexOf("text_") == 0) {
        const target = key.substring(5);
        const decodedValue = decodeURIComponent(get_params[key]);

        const elem = document.getElementById(target);
        if (elem) {
          elem.innerText = decodedValue;
        } else {
          document.querySelectorAll(`.${target}`).forEach((el) => {
            el.innerText = decodedValue;
          });
        }
      } else if (key.indexOf("color_") == 0) {
        var elems_color = document.getElementById(key.substring(6, key.length));
        elems_color.style.backgroundColor = decodeURIComponent(get_params[key]);
      } else if (key.indexOf("image_") == 0) {
        var e = document.getElementById(key.substring(6, key.length));
        e.setAttribute("source", decodeURIComponent(get_params[key]));
        console.log("index of image: " + e);
      } else if (key.endsWith("click")) {
        var click_url = decodeURIComponent(get_params[key]);
        console.log("click url value: " + click_url);
        if (parameter_args != "") {
          if (click_url.indexOf("?") > 0) {
            click_url = click_url + "&" + parameter_args;
          } else {
            click_url = click_url + "?" + parameter_args;
          }
        }

        try {
          if (clickTag == "") {
            clickTag = click_url;
            force_clickout = true;
          } else if (clickTag == "{{clickMacro}}") {
            clickTag = click_url;
          } else if (force_clickout) {
            clickTag = click_url;
          }

          if (!clickTag) {
            disable_click = false;
          }
        } catch (err) {
          disable_click = false;
          //console.log(err);
        }

        try {
          if (window.bannerJson && window.bannerURL == "") {
            force_clickout = true;
          }
        } catch (err) {
          //console.log(err);
        }

        if (force_clickout && click_url) {
          force_clickout = true;
        }

        if (window.clickTag && click_url) {
          if (window.clickTag == "{{clickMacro}}" || force_clickout) {
            window.clickTag = click_url;
          }
        }

        try {
          if (click_url && click_url.indexOf("cid=") > 0) {
            var cid = parseInt(click_url.split("cid=").pop().split("&")[0]);
            if (!isNaN(cid) && cid > 1217000) {
              disablePointerChecks = false;
            }
            if (!pointerOverride && !isNaN(cid) && cid > 1357000) {
              pointerDistance = 15;
              pointerDurationMax = 475;
              pointerDurationMin = 80;
            }
          }
          if (click_url && click_url.indexOf("crid=") > 0) {
            var crid = parseInt(click_url.split("crid=").pop().split("&")[0]);
            if (!pointerOverride && !isNaN(crid) && crid > 7215000) {
              disablePointerChecks = false;
              pointerDistance = 15;
              pointerDurationMax = 475;
              pointerDurationMin = 80;
            }
          }
        } catch (err) {
          //console.log(err);
        }

        var preventClickRepeat = false;
        var preventPointerRepeat = false;
        var pointerPending = false;

        if (
          !(
            window.clickTag &&
            typeof window.clickTag != "object" &&
            window.clickTag.includes("http")
          ) ||
          force_clickout
        ) {
          var e = document.getElementsByTagName("gwd-google-ad")[0];
          var e2 = document.querySelectorAll(".dynamicClick");
          if (e && e2.length == 0) {
            if ("ontouchstart" in document.documentElement) {
              e.addEventListener("pointerdown", (event) => {
                handlePointerDown(event);
              });
              e.addEventListener("pointerup", (event) => {
                if (
                  !preventPointerRepeat &&
                  !preventClickRepeat &&
                  !pointerPending
                ) {
                  pointerPending = true;
                  if (handlePointerUp(event)) {
                    if (!preventPointerRepeat && !preventClickRepeat) {
                      preventPointerRepeat = true;
                      window.open(click_url, "_blank");
                    }
                    if (doDebug) {
                      console.log("param pointer");
                    }
                  }
                }
                pointerPending = false;
              });
              e.addEventListener("click", (event) => {
                if (!preventClickRepeat && !preventPointerRepeat) {
                  handleClick(event);
                }
              });
            } else {
              e.addEventListener("click", function () {
                if (!preventClickRepeat && !preventPointerRepeat) {
                  handleClick(event);
                }
              });
            }
          } else if (!disable_click) {
            if (e2.length > 0) {
              e = e2;
            } else {
              e = document.querySelectorAll("*");
            }
            e.forEach((item) => {
              if ("ontouchstart" in document.documentElement) {
                item.addEventListener("pointerdown", (event) => {
                  handlePointerDown(event);
                });
                item.addEventListener("pointerup", (event) => {
                  if (
                    !preventPointerRepeat &&
                    !preventClickRepeat &&
                    !pointerPending
                  ) {
                    pointerPending = true;
                    if (handlePointerUp(event)) {
                      if (!preventPointerRepeat && !preventClickRepeat) {
                        preventPointerRepeat = true;
                      }
                      window.open(click_url, "_blank");
                      if (doDebug) {
                        console.log("param pointer");
                      }
                    }
                  }
                  pointerPending = false;
                });
                item.addEventListener("click", (event) => {
                  if (!preventClickRepeat && !preventPointerRepeat) {
                    handleClick(event);
                  }
                });
              } else {
                item.addEventListener("click", (event) => {
                  if (!preventClickRepeat && !preventPointerRepeat) {
                    handleClick(event);
                  }
                });
              }
            });
          }
        }
      }
    }

    setInterval(function () {
      preventClickRepeat = false;
      preventPointerRepeat = false;
    }, 1000);
  } catch (e) {
    if (window.clickTag == "" && click_url) {
      window.clickTag = click_url;
    } else if (clickTag == "" && click_url) {
      clickTag = click_url;
    }
    console.log(e);
  }
})();
