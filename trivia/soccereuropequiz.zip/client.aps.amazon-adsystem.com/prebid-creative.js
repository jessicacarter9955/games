window.__aps_slice = 1; /*! web-client-bundle - v26.1120.2055 - 2026-11-20 20:55:46 */
!(function () {
  "use strict";
  const t = new Uint8Array([
    42, 94, 79, 102, 182, 87, 18, 39, 206, 243, 126, 191, 4, 63, 77, 59, 162,
    241, 193, 101, 74, 1, 189, 21, 73, 186, 68, 154, 111, 81, 242, 165, 135,
    180, 163, 105, 50, 210, 243, 84, 28, 112, 180, 154, 121, 30, 77, 205, 244,
    40, 170, 162, 232, 228, 11, 227, 246, 206, 15, 66, 249, 209, 155, 230, 40,
    163, 9, 155, 225, 186, 136, 158, 220, 243, 29, 125, 108, 215, 138, 132, 162,
    138, 154, 50, 162, 121, 25, 242, 186, 30, 94, 86, 163, 178, 51, 115, 114,
    236, 70, 144, 3, 28, 80, 147, 126, 214, 189, 247, 91, 89, 174, 197, 197,
    183, 170, 91, 8, 14, 57, 223, 112, 162, 142, 158, 85, 114, 94, 54, 177, 225,
    193, 215, 183, 203, 176, 135, 119, 151, 106, 124, 147, 64, 185, 186, 154,
    65, 115, 229, 149, 248, 103, 83, 0, 185, 239, 180, 180, 9, 121, 175, 91,
    167, 210, 228, 224, 59, 152, 103, 84, 54, 29, 154, 26, 192, 30, 30, 230,
    189, 46, 31, 44, 247, 213, 82, 224, 87, 119, 243, 198, 63, 123, 158, 78, 91,
    6, 158, 34, 159, 215, 185, 65, 197, 90, 186, 113, 79, 40, 200, 209, 165,
    199, 128, 110, 19, 63, 125, 229, 20, 205, 93, 22, 177, 73, 126, 222, 207,
    218, 164, 126, 105, 197, 65, 146, 175, 93, 49, 99, 244, 146, 186, 117, 50,
    116, 237, 57, 73, 29, 194, 250, 216, 125, 160, 101, 201, 143, 48, 173, 154,
    169, 182, 163, 159, 150, 123, 175, 26, 29, 21, 75, 254, 6, 218, 88, 64, 9,
    238, 70, 40, 48, 251, 227, 255, 14, 252, 121, 116, 203, 193, 211, 50, 29,
    13, 120, 107, 88, 124, 129, 92, 214, 187, 203, 14, 234, 59, 113, 251, 68, 2,
    197, 99, 211, 134, 234, 215, 62, 106, 160, 163, 205, 103, 10, 244, 47, 67,
    229, 124, 164, 209, 86, 98, 250, 150, 19, 2, 48, 7, 217, 47, 108, 179, 137,
    29, 118, 253, 240, 198, 209, 169, 123, 234, 193, 55, 151, 183, 196, 133,
    243, 111, 68, 60, 109, 15, 222, 215, 190, 84, 32, 161, 155, 6, 221, 9, 91,
    244, 252, 231, 34, 70, 249, 254, 126, 47, 145, 125, 203, 199, 164, 76, 200,
    255, 242, 96, 213, 54, 245, 80, 152, 219, 38, 38, 88, 107, 171, 167, 140,
    205, 250, 85, 42, 240, 247, 239, 106, 49, 163, 88, 77, 71, 185, 215, 102,
    84, 142, 194, 238, 193, 69, 189, 200, 85, 4, 24, 127, 232, 164, 61, 27, 31,
    192, 160, 81, 62, 75, 2, 248, 252, 158, 31, 229, 142, 61, 109, 149, 222,
    245, 236, 130, 102, 181, 88, 110, 177, 25, 177, 190, 237, 122, 51, 60, 100,
    33, 47, 94, 199, 39, 135, 90, 14, 29, 181, 6, 103, 45, 93, 144, 131, 188,
    184, 179, 103, 222, 216, 182, 143, 162, 221, 15, 201, 102, 140, 100, 227,
    179, 120, 252, 193, 19, 93, 250, 0, 27, 52, 240, 252, 40, 142, 218, 208, 81,
    211, 133, 190, 65, 240, 215, 64, 205, 85, 247, 205, 210, 255, 193, 106, 149,
    155, 120, 62, 145, 81, 139, 227, 62, 75, 159, 37, 244, 102, 106, 117, 36,
    171, 31, 184, 50, 171, 235, 246, 36, 249, 88, 10, 214, 139, 224, 160, 86, 8,
    144, 218, 183, 238, 141, 252, 130, 111, 200, 38, 91, 55, 119, 105, 134, 219,
    12, 149, 106, 45, 35, 72, 102, 65, 91, 187, 244, 8, 73, 110, 250, 22, 186,
    33, 176, 44, 135, 12, 192, 62, 60, 255, 35, 253, 44, 113, 58, 242, 222, 60,
    145, 228, 207, 59, 23, 255, 173, 47, 234, 254, 254, 30, 171, 11, 60, 87, 79,
    218, 109, 175, 23, 255, 197, 111, 134, 83, 200, 250, 202, 117, 111, 156,
    243, 38, 157, 77, 88, 94, 63, 66, 101, 42, 51, 254, 208, 205, 13, 144, 240,
    191, 7, 88, 9, 41, 57, 85, 18, 75, 218, 18, 4, 51, 179, 93, 145, 234, 147,
    82, 72, 229, 77, 72, 78, 154, 75, 122, 93, 231, 240, 183, 141, 143, 122, 82,
    255, 217, 76, 184, 75, 190, 91, 255, 116, 77, 254, 146, 211, 148, 177, 170,
    158, 59, 112, 202, 57, 184, 41, 6, 139, 39, 65, 254, 166, 3, 217, 93, 41, 1,
    215, 16, 112, 238, 62, 246, 183, 159, 46, 115, 207, 175, 144, 241, 71, 60,
    233, 47, 94, 133, 51, 12, 63, 242, 171, 123, 235, 89, 106, 213, 255, 216,
    235, 111, 31, 143, 216, 217, 236, 13, 80, 251, 192, 159, 47, 174, 114, 161,
    77, 165, 139, 192, 238, 112, 134, 180, 106, 154, 56, 179, 162, 98, 57, 28,
    59, 92, 133, 227, 113, 249, 102, 176, 3, 19, 245, 141, 159, 48, 231, 90,
    228, 244, 229, 173, 100, 230, 33, 205, 22, 231, 123, 90, 139, 75, 252, 134,
    220, 243, 170, 7, 32, 136, 69, 9, 234, 125, 27, 204, 31, 251, 163, 218, 1,
    198, 246, 122, 98, 251, 1, 130, 98, 114, 236, 231, 115, 6, 233, 147, 232,
    73, 29, 207, 229, 241, 63, 60, 165, 178, 226, 159, 13, 124, 200, 114, 54,
    198, 102, 213, 255, 38, 213, 225, 4, 23, 105, 69, 166, 215, 113, 134, 2, 14,
    129, 76, 64, 74, 48, 98, 159, 219, 73, 75, 60, 237, 120, 114, 144, 81, 242,
    206, 66, 111, 175, 177, 86, 55, 129, 34, 198, 84, 63, 87, 242, 115, 43, 81,
    149, 49, 107, 213, 179, 233, 105, 210, 134, 53, 61, 248, 11, 73, 195, 244,
    184, 248, 93, 54, 242, 111, 65, 75, 63, 14, 180, 177, 71, 5, 55, 111, 129,
    179, 168, 80, 72, 214, 13, 25, 75, 0, 191, 190, 72, 172, 141, 70, 104, 241,
    169, 158, 104, 131, 130, 14, 249, 12, 42, 179, 87, 98, 173, 42, 195, 111,
    205, 218, 226, 240, 165, 81, 158, 27, 103, 161, 128, 85, 250, 152, 147, 145,
    116, 29, 119, 128, 252, 240, 95, 162, 6, 79, 188, 140, 183, 26, 150, 91,
    184, 180, 8, 27, 7, 3, 74, 93, 70, 57, 169, 210, 36, 82, 24, 116, 234, 217,
    241, 64, 24, 250, 172, 230, 109, 194, 235, 58, 37, 52, 127, 79, 77, 220, 86,
    231, 178, 202, 42, 176, 114, 135, 215, 196, 161, 72, 101, 252, 107, 45, 222,
    73, 102, 37, 205, 56, 177, 142, 100, 77, 183, 27, 245, 90, 2, 100, 38, 127,
    199, 201, 115, 183, 142, 121, 56, 185, 179, 90, 168, 120, 45, 167, 207, 107,
    182, 17, 85, 161, 78, 113, 92, 197, 213, 22, 210, 28, 189, 204, 118, 121,
    163, 88, 52, 27, 19, 242, 41, 82, 180, 81, 186, 185, 166, 161, 253, 230, 93,
    42, 154, 204, 123, 153, 128, 120, 17, 132, 49, 204, 55, 221, 213, 34, 121,
    118, 143, 207, 100, 55, 24, 42, 12, 158, 55, 40, 177, 238, 135, 243, 29,
    166, 26, 75, 99, 108, 190, 214, 17, 198, 250, 4, 14, 184, 180, 250, 160, 90,
    190, 27, 76, 93, 81, 245, 104, 185, 104, 237, 35, 141, 66, 214, 86, 238,
    166, 161, 207, 138, 195, 93, 9, 185, 67, 206, 174, 232, 109, 50, 107, 71,
    114, 64, 208, 88, 81, 162, 242, 139, 120, 24, 41, 124, 172, 154, 159, 83,
    112, 56, 54, 247, 211, 57, 20, 214, 42, 23, 19, 145, 84, 43, 126, 8, 212,
    27, 49, 225, 85, 23, 9, 17, 82, 21, 251, 63, 148, 247, 25, 103, 122, 5, 92,
    185, 231, 86, 161, 74, 83, 79, 88, 192, 168, 80, 110, 92, 183, 152, 96, 154,
    128, 46, 223, 53, 127, 186, 254, 57, 189, 102, 111, 208, 211, 84, 164, 113,
    114, 237, 75, 120, 78, 78, 198, 114, 208, 93, 125, 210, 183, 30, 18, 211,
    237, 6, 191, 143, 86, 209, 162, 47, 231, 19, 70, 162, 23, 120, 237, 205, 49,
    103, 117, 112, 64, 125, 12, 52, 112, 210, 225, 34, 14, 225, 72, 248, 198,
    122, 239, 103, 22, 112, 159, 187, 116, 52, 35, 249, 228, 152, 96, 143, 210,
    143, 75, 0,
  ]);
  function e(t) {
    const e = new TextEncoder().encode(t);
    let n = 2166136261;
    for (let t = 0; t < e.length; ++t)
      (n ^= e[t]), (n = Math.imul(n, 16777619));
    return n >>> 0;
  }
  const n = (t, e) => `${t}_${e}_salt`,
    s = (t, e = 200) => (t.length <= e ? t : `${t.substring(0, e)}...`);
  let o = !1;
  try {
    ((t, e) => {
      const n = new Set(),
        o = [];
      try {
        const e = t.top?.location.hostname;
        e && n.add(e);
      } catch (t) {
        const e = t;
        o.push(s(e.message));
      }
      try {
        n.add(t.location.hostname);
      } catch (t) {
        const e = t;
        o.push(s(e.message));
      }
      try {
        const e = t.location.href;
        n.add(new URL(e).hostname);
      } catch (t) {
        const e = t;
        o.push(s(e.message));
      }
      try {
        const t = e.URL;
        n.add(new URL(t).hostname);
      } catch (t) {
        const e = t;
        o.push(s(e.message));
      }
      if (0 === n.size)
        throw new Error(`Unable to determine hostname: ${JSON.stringify(o)}`);
      return n;
    })(window, document).forEach((s) => {
      o ||
        (o = ((t, s) => {
          for (let o = 0; o < 14; o++) {
            const a = e(n(t, o)) % 11033,
              r = a % 8;
            if (!(s[Math.floor(a / 8)] & (1 << r))) return !1;
          }
          return !0;
        })(s, t));
    });
  } catch (t) {
    const e = t;
    (window._aps_telemetry = window._aps_telemetry || {}),
      (window._aps_telemetry.alarms = window._aps_telemetry.alarms || []),
      window._aps_telemetry.alarms.push({
        hash: "5ba43c",
        context: { message: e?.message },
      });
  }
  if (o) throw new Error("Unauthorized");
  !(function () {
    "use strict";
    var t;
    !(function (t) {
      (t.info = "info"), (t.warn = "warn"), (t.error = "error");
    })(t || (t = {}));
    class e {
      static Instance() {
        return this.t;
      }
      static SessionId() {
        return this.o;
      }
      info(...e) {
        const r = new Date(Date.now()),
          n = t.info;
        return (
          console.log(this.getPrefix(r, n), ...e), { timestamp: r, logLevel: n }
        );
      }
      warn(...e) {
        const r = new Date(Date.now()),
          n = t.warn;
        return (
          console.warn(this.getPrefix(r, n), ...e),
          { timestamp: r, logLevel: n }
        );
      }
      error(...e) {
        const r = new Date(Date.now()),
          n = t.error;
        return (
          console.error(this.getPrefix(r, n), ...e),
          { timestamp: r, logLevel: n }
        );
      }
      getPrefix(t, r) {
        return `${t.toISOString()} | ${e.SessionId()} | [${r.toUpperCase()}]`;
      }
    }
    (e.t = new e()), (e.o = `${Date.now()}`);
    const r = e.Instance(),
      n = "prepend/events",
      o = "populator/ran";
    var i, s, a, c, u;
    !(function (t) {
      (t.ManagedWeb = "mw"), (t.SelfServeWeb = "ssw");
    })(i || (i = {})),
      (function (t) {
        (t.push = "push"),
          (t.listenerSuccess = "listenerSuccess"),
          (t.direct = "direct");
      })(s || (s = {})),
      (function (t) {
        (t.internal = "internal"),
          (t.apstag = "apstag"),
          (t.webpage = "webpage"),
          (t.dtbm = "dtbm");
      })(a || (a = {})),
      (function (t) {
        (t.completed = "completed"),
          (t.waiting = "waiting"),
          (t.cancelled = "cancelled");
      })(c || (c = {})),
      (function (t) {
        (t.started = "started"),
          (t.error = "error"),
          (t.unknown = "unknown"),
          (t.deactivated = "deactivated"),
          (t.analytics = "analytics");
      })(u || (u = {}));
    const l = { ...c, ...u },
      h = { key: "consent/hasPurposeOneConsent", default: !1 };
    class d {
      constructor(t) {
        (this.getItem = (t) => {
          const e = this.globalContext.document.cookie
            .split("; ")
            .reduce((e, r) => {
              const n = r.split("=");
              return n[0] === t ? decodeURIComponent(n.slice(1).join("=")) : e;
            }, "");
          return e.length > 0 ? e : null;
        }),
          (this.removeItem = (t, e = "/") => {
            this.setItem(t, "", 0, e);
          }),
          (this.setItem = (t, e, r, n = "/") => {
            const o = new Date(r);
            if (!this.isValidDate(o))
              throw new Error("Invalid expiration date");
            this.globalContext.document.cookie = `${t}=${e}; expires=${o.toUTCString()}; path=${n};`;
          }),
          (this.globalContext = t);
      }
      isValidDate(t) {
        return t instanceof Date && !isNaN(t);
      }
    }
    const f = (t, e = window) => {
        let r,
          n = e;
        do {
          try {
            const e = n?.location?.hostname;
            if (e && t(e)) return !0;
          } catch (t) {
            if (
              !(
                (t instanceof DOMException && "SecurityError" === t.name) ||
                (t instanceof Error && t.message.includes("cross-origin frame"))
              )
            )
              throw t;
            if (Math.random() < 0.001) throw t;
          }
          if (n === e.top) break;
          (r = n), (n = n.parent);
        } while (r !== n && r !== e.top);
        return !1;
      },
      w = ["scope/objectName", "debugSession/end", n],
      p = ":";
    function m(t) {
      return null === t || "object" != typeof t
        ? t
        : t instanceof Date
        ? new Date(t.getTime())
        : t instanceof Array
        ? t.reduce((t, e) => (t.push(m(e)), t), [])
        : t instanceof Set
        ? Array.from(t.values()).reduce((t, e) => (t.add(m(e)), t), new Set())
        : t instanceof Map
        ? Array.from(t.entries()).reduce(
            (t, e) => (t.set(e[0], m(e[1])), t),
            new Map()
          )
        : t instanceof Object
        ? Object.keys(t).reduce((e, r) => ((e[r] = m(t[r])), e), {})
        : t;
    }
    class y {
      constructor(t, e) {
        const r = e.rootName;
        (this.globalContext = e.globalContext), (this.rootName = r);
        const n = this.globalContext[r].get(t);
        if (null == n)
          throw new Error(`Missing "${t}" account in userspace object`);
        (this.id = t),
          (this.store = n.store),
          (this.queue = n.queue),
          this.store.has("listeners") || this.store.set("listeners", new Map());
      }
      getResolvedHostname() {
        let t = "";
        return f((e) => ((t = e), !0), this.globalContext), t;
      }
      async record(t, e) {
        return await new Promise((r, n) => {
          this.queue.push(
            new CustomEvent(t, {
              detail: { resolve: r, reject: n, source: a.internal, ...e },
            })
          );
        });
      }
      async recordListener(t, e) {
        return await new Promise((r, n) => {
          this.queue.push(
            new CustomEvent(t.name, {
              detail: { resolve: r, reject: n, source: a.internal, ...e },
            })
          );
        });
      }
      recordListenerNonBlocking(t, e) {
        this.recordListener(t, e).catch((t) => {});
      }
      read(t, e) {
        const r = this.store.get(t);
        if (void 0 !== r) return r;
        if (void 0 !== e?.persist && e.persist) {
          const r = this.readLocalStorage(t, {
            usePrefix: !0,
            throwOnDisallowed: e.throwOnDisallowed,
          });
          if (void 0 !== r) return r;
        }
        const n = e?.default?.generators?.get(t);
        return void 0 !== n ? n(...(e?.default?.args ?? [])) : void 0;
      }
      write(t, e, r) {
        this.store.set(t, e),
          void 0 !== r?.persist &&
            r.persist &&
            this.writeLocalStorage(t, e, {
              usePrefix: !0,
              throwOnDisallowed: r.throwOnDisallowed,
            });
      }
      use(t, e) {
        let r;
        const n = this.store.get(t.key);
        if (void 0 !== n) r = n;
        else if (void 0 !== e?.persist && e.persist) {
          const n = this.readLocalStorage(t.key, {
            usePrefix: !0,
            throwOnDisallowed: e.throwOnDisallowed,
          });
          null != n && (r = n);
        }
        const o = r ?? t.default;
        if ("function" == typeof o || !1 === e?.structuredClone) return o;
        try {
          return structuredClone(o);
        } catch (t) {
          try {
            return m(o);
          } catch (t) {
            return (
              dt.logCoreError({
                id: "Core.library.Account.use",
                account: null,
                error: t,
              }),
              o
            );
          }
        }
      }
      useParent(t, e) {
        try {
          const r = this.globalContext.parent,
            n = r[this.rootName];
          if (!n || "function" != typeof n.get) return t.default;
          const o = n.get(e?.accountId ?? this.id);
          if (!o || !o.store) return t.default;
          let i;
          const s = o.store.get(t.key);
          if (void 0 !== s) i = s;
          else if (e?.persist) {
            const n = e?.accountId ?? this.id,
              o = `aps${p}${n}${p}${t.key}`;
            try {
              const t = r.localStorage.getItem(o);
              null != t && (i = t);
            } catch {}
          }
          const a = i ?? t.default;
          if ("function" == typeof a || !1 === e?.structuredClone) return a;
          try {
            return structuredClone(a);
          } catch {
            try {
              return m(a);
            } catch {
              return a;
            }
          }
        } catch {
          return t.default;
        }
      }
      update(t, e, r) {
        let n = e(
          this.use(t, { ...r, throwOnDisallowed: r?.throwOnDisallowed })
        );
        if (
          (void 0 !== t.postProcessor && (n = t.postProcessor(n)),
          this.store.set(t.key, n),
          void 0 !== r?.persist && r.persist)
        ) {
          if ("string" != typeof n)
            throw new Error(
              `${JSON.stringify(
                n
              )} must be a string to be writtable to browser storage`
            );
          this.writeLocalStorage(t.key, n, {
            usePrefix: !0,
            throwOnDisallowed: r.throwOnDisallowed,
          });
        }
      }
      delete(t, e) {
        this.store.delete(t),
          void 0 !== e?.persist &&
            e.persist &&
            this.deleteLocalStorage(t, {
              usePrefix: !0,
              throwOnDisallowed: e.throwOnDisallowed,
            });
      }
      remove(t, e) {
        this.store.delete(t.key),
          void 0 !== e?.persist &&
            e.persist &&
            this.deleteLocalStorage(t.key, {
              usePrefix: !0,
              throwOnDisallowed: e.throwOnDisallowed,
            });
      }
      executeFuncWithConsent(t, e) {
        if (!this.isAllowedToAccessInfoOnDevice())
          throw new Error(
            "Invalid consent. API requires consent before execution."
          );
        return e.apply(t);
      }
      recordErrorEvent(t) {
        dt.logError({ ...t, account: this });
      }
      recordStatusChangeEvent(t) {
        dt.logFeature({
          id: t.id,
          account: this,
          feature: t.status,
          analyticsSampleRateAdjustFactor: t.analyticsSampleRateAdjustFactor,
          libraryVersion: t.libraryVersion,
          props: { ...t.props },
        });
      }
      recordGenericEvent(t) {
        dt.logFeature({
          id: t.id,
          account: this,
          feature: t.id,
          analyticsSampleRateAdjustFactor: t.analyticsSampleRateAdjustFactor,
          libraryVersion: t.libraryVersion,
          props: { ...t.props },
        });
      }
      isAllowedToAccessInfoOnDevice() {
        return this.updateUserConsent(), this.use(h);
      }
      isAPStagAllowedToAccessInfoOnDevice() {
        return !0 === this.globalContext.apstag._atsaaiod();
      }
      updateUserConsent() {
        try {
          const t = this.isAPStagAllowedToAccessInfoOnDevice();
          this.update(h, () => t);
        } catch (t) {}
      }
      getPersistedItemName(t) {
        return `aps${p}${this.id}${p}${t}`;
      }
      isBrowserStorageAllowed(t) {
        let e = !1;
        try {
          e = this.isAllowedToAccessInfoOnDevice();
        } catch {}
        return e || w.includes(t);
      }
      setCookieStorage(t, e, r, n) {
        const o = n?.throwOnDisallowed ?? !0;
        if (!this.isBrowserStorageAllowed(t)) {
          if (o)
            throw new Error(`${t} is not allowed to be set on cookie storage`);
          return;
        }
        const i = n?.usePrefix ? this.getPersistedItemName(t) : t;
        return new d(this.globalContext).setItem(i, e, r, n?.path ?? "/");
      }
      readCookieStorage(t, e) {
        const r = e?.throwOnDisallowed ?? !0;
        if (!this.isBrowserStorageAllowed(t)) {
          if (r)
            throw new Error(
              `${t} is not allowed to be read from cookie storage`
            );
          return;
        }
        const n = e?.usePrefix ? this.getPersistedItemName(t) : t;
        return new d(this.globalContext).getItem(n);
      }
      readLocalStorage(t, e) {
        const r = e?.throwOnDisallowed ?? !0;
        if (!this.isBrowserStorageAllowed(t)) {
          if (r)
            throw new Error(
              `${t} is not allowed to be read from browser storage`
            );
          return;
        }
        const n = e?.usePrefix ? this.getPersistedItemName(t) : t;
        return this.globalContext.localStorage.getItem(n) ?? void 0;
      }
      writeLocalStorage(t, e, r) {
        const n = r?.throwOnDisallowed ?? !0;
        if (!this.isBrowserStorageAllowed(t)) {
          if (n)
            throw new Error(
              `${t} is not allowed to be written to browser storage`
            );
          return;
        }
        if ("string" != typeof e)
          throw new Error(
            `${JSON.stringify(
              e
            )} must be a string to be writtable to browser storage`
          );
        const o = r?.usePrefix ? this.getPersistedItemName(t) : t;
        this.globalContext.localStorage.setItem(o, e);
      }
      deleteLocalStorage(t, e) {
        const r = e?.throwOnDisallowed ?? !0;
        if (!this.isBrowserStorageAllowed(t)) {
          if (r)
            throw new Error(
              `${t} is not allowed to be touched/deleted in browser storage`
            );
          return;
        }
        const n = e?.usePrefix ? this.getPersistedItemName(t) : t;
        this.globalContext.localStorage.removeItem(n);
      }
      readSessionStorage(t, e) {
        const r = e?.throwOnDisallowed ?? !0;
        if (!this.isBrowserStorageAllowed(t)) {
          if (r)
            throw new Error(
              `${t} is not allowed to be read from browser storage`
            );
          return;
        }
        const n = e?.usePrefix ? this.getPersistedItemName(t) : t;
        if (n in this.globalContext.sessionStorage)
          return this.globalContext.sessionStorage.getItem(n);
      }
      writeSessionStorage(t, e, r) {
        const n = r?.throwOnDisallowed ?? !0;
        if (!this.isBrowserStorageAllowed(t)) {
          if (n)
            throw new Error(
              `${t} is not allowed to be written to browser storage`
            );
          return;
        }
        if ("string" != typeof e)
          throw new Error(
            `${JSON.stringify(
              e
            )} must be a string to be writable to browser storage`
          );
        const o = r?.usePrefix ? this.getPersistedItemName(t) : t;
        this.globalContext.sessionStorage.setItem(o, e);
      }
      deleteSessionStorage(t, e) {
        const r = e?.throwOnDisallowed ?? !0;
        if (!this.isBrowserStorageAllowed(t)) {
          if (r)
            throw new Error(
              `${t} is not allowed to be touched/deleted in browser storage`
            );
          return;
        }
        const n = e?.usePrefix ? this.getPersistedItemName(t) : t;
        this.globalContext.sessionStorage.removeItem(n);
      }
    }
    const v = "_system";
    class b extends y {
      constructor(t, e) {
        super(v, { globalContext: t, rootName: e });
      }
    }
    const g = "listeners",
      E = "_internal/history",
      _ = "_internal/externalEventCount";
    class $ {
      constructor(t, e, r) {
        (this.globalContext = t), (this.rootName = e), (this.dispatcher = r);
      }
      getAccounts() {
        return this.globalContext[this.rootName];
      }
      createUserspaceRoot() {
        null == this.getAccounts() &&
          (this.globalContext[this.rootName] = new Map());
      }
      createSystemAccount() {
        !1 === this.getAccounts().has(v) &&
          (this.getAccounts().set(v, { queue: [], store: new Map() }),
          new b(this.globalContext, this.rootName).store.set(
            "_internal/pageLoadID",
            Math.random()
          ));
      }
      observeRootSet() {
        const t = this;
        this.getAccounts().set = function (e, r) {
          Map.prototype.set.apply(this, [e, r]), t.equip();
        };
      }
      observeAccountQueuesPush() {
        const t = this;
        this.getAccounts().forEach((e) => {
          e.queue.push = function (...e) {
            Array.prototype.push.apply(this, e),
              t.dispatcher.i({ reason: { method: s.push, events: e } });
          };
        });
      }
      overwriteAccountStoresGet() {
        this.getAccounts().forEach((t) => {
          t.store.get = function (...t) {
            return Map.prototype.get.apply(this, t);
          };
        });
      }
      defineConvenienceFunctions() {
        const t = (t, e, r) => {
            const n = this.getAccounts().get(t);
            void 0 !== n &&
              n.queue.push(new CustomEvent(e, { detail: r ?? {} }));
          },
          e = this.globalContext[this.rootName];
        (e.triggerFor = t),
          (e.trigger = (e, r) => {
            t(v, e, r);
          }),
          void 0 === e._private && (e._private = {}),
          (e._private.CookieStorage = d);
      }
      equip() {
        try {
          this.createUserspaceRoot(),
            this.createSystemAccount(),
            this.observeRootSet(),
            this.observeAccountQueuesPush(),
            this.overwriteAccountStoresGet(),
            this.defineConvenienceFunctions();
        } catch (t) {
          throw (
            (new b(this.globalContext, this.rootName).recordErrorEvent({
              id: "Core.library.Equiper.equip",
              error: t,
            }),
            t)
          );
        }
      }
    }
    const S = "26.1120.2055",
      x = (t) => void 0 === t || !Array.isArray(t) || f((e) => t.includes(e));
    function C(t) {
      return !(t >= 1 || Number.isNaN(t)) && (t <= 0 || Math.random() >= t);
    }
    function A() {
      try {
        return (
          !!new URLSearchParams(
            window.top?.location.search ?? window.location.search
          ).has("apscoredebug") ||
          (window._aps?.get("_system").store.get("_internal/coreDebugMode") ??
            !1)
        );
      } catch {
        return !1;
      }
    }
    const R = { key: "_internal/eventSources", default: new Map() },
      D = { key: "_internal/processedEventSources", default: new Set() },
      N = { key: "_internal/commonAnalytics", default: {} },
      P = { key: "analytics/sampleRateFactors", default: void 0 },
      I = [l.completed, l.error, l.cancelled, l.analytics];
    class O {
      constructor(t, e) {
        (this.globalContext = t), (this.rootName = e);
      }
      u(t) {
        return t.store.get("_config/events/deactivations") ?? new Set();
      }
      l(t, e) {
        return (
          !0 === this.u(t).has(e.type) ||
          ((t, e) => {
            try {
              const e = t.detail?.restrictions?.allow?.hostnames;
              if (void 0 !== e && !x(e)) return !0;
              const r = t.detail?.restrictions?.block?.hostnames;
              if (void 0 !== r && x(r)) return !0;
            } catch (t) {
              return (
                e.recordErrorEvent({ id: "hostnames", error: new Error(t) }), !1
              );
            }
            return !1;
          })(e, t) ||
          ((t) => {
            const e = t?.detail?.restrictions?.allow?.libraryVersions,
              r = t?.detail?.restrictions?.block?.libraryVersions;
            return (
              !(!Array.isArray(r) || !r.includes(S)) ||
              !(!Array.isArray(e) || e.includes(S))
            );
          })(e) ||
          ((t, e) => {
            const r = t?.detail?.restrictions?.allow?.accounts,
              n = t?.detail?.restrictions?.block?.accounts;
            return (
              !(!Array.isArray(n) || !n.includes(e.id)) ||
              !(!Array.isArray(r) || r.includes(e.id))
            );
          })(e, t) ||
          ((t, e) => {
            const r = ((t) => {
              if (!t) return null;
              const e = Number(t);
              return !Number.isNaN(e) && Number.isInteger(e) && e >= 0
                ? i.ManagedWeb
                : i.SelfServeWeb;
            })(e.id);
            if (null === r) return !1;
            const n = t?.detail?.restrictions?.allow?.accountTypes,
              o = t?.detail?.restrictions?.block?.accountTypes;
            return (
              !(!Array.isArray(o) || !o.includes(r)) ||
              !(!Array.isArray(n) || n.includes(r))
            );
          })(e, t) ||
          ((t) => {
            const e = t?.detail?.restrictions?.allow?.rate ?? 1;
            return !(!C(t?.detail?.restrictions?.block?.rate ?? 1) && !C(e));
          })(e)
        );
      }
      p() {
        return (
          new b(this.globalContext, this.rootName).store.get(g) ?? new Map()
        );
      }
      m(t) {
        return t.store.get("listeners") ?? new Map();
      }
      v(t, e) {
        return this.p().get(e.type) || this.m(t).get(e.type);
      }
      _(t) {
        const e = this.$(_);
        return (
          (void 0 === t.externalEventCount || t.externalEventCount < e) &&
          ((t.externalEventCount = e), !0)
        );
      }
      S(t) {
        if (void 0 === t.status) return !0;
        if (t.status === l.started) return !1;
        if (I.includes(t.status)) return !1;
        if (t.status === l.waiting) return !!this._(t);
        if (t.status === l.unknown) return !1;
        if (t.status === l.deactivated) return !1;
        throw new Error(`Event status not explicitely handled: ${t.status}`);
      }
      C(t, e) {
        void 0 !== e.detail?.timeout &&
          t.push(
            new Promise((t, r) => {
              setTimeout(
                () => r(new Error(`Event "${e.type}" timed out`)),
                e.detail.timeout
              );
            })
          );
      }
      A(t, e) {
        const r = new b(this.globalContext, this.rootName),
          n = r.read(t) ?? 0;
        r.write(t, n + e);
      }
      R(t) {
        new b(this.globalContext, this.rootName).write(t, 0);
      }
      $(t) {
        return new b(this.globalContext, this.rootName).read(t) ?? 0;
      }
      D(t, e, n, o, i) {
        if (!(e in l))
          throw new Error(
            `Listener returned invalid status: ${t.type} returned ${e}`
          );
        if (
          (this.N(t, e, o, i), e !== l.waiting && void 0 !== t.detail?.resolve)
        )
          try {
            t.detail.resolve(n);
          } catch (t) {
            r.error(t);
          }
        e !== l.waiting && this.P(t, o),
          this.i({ reason: { method: s.listenerSuccess, events: [t] } });
      }
      P(t, e) {
        const r = this.v(e, t);
        !0 === r?.shouldFlushAnalytics && dt.flush();
      }
      I(t, e, r) {
        (void 0 !== e && "string" != typeof e) || (e = new Error(e)),
          this.N(t, l.error, r),
          this.O(t, e),
          (e.context = t.type),
          r.recordErrorEvent({
            id: t.type,
            analyticsSampleRateAdjustFactor: this.j(t),
            error: e,
          }),
          this.P(t, r);
      }
      k(t, e, r, n) {
        const o = this.v(r, e);
        if (void 0 === o)
          throw new Error(`No listener found for event: ${e.type}`);
        t.push(
          o({
            customEvent: e,
            account: r,
            systemAccount: n,
            detail: e.detail,
            context: r.globalContext,
          })
        );
      }
      F(t, e, r) {
        Promise.race(t)
          .then((t) => {
            let n, o, i;
            void 0 === t
              ? (n = c.completed)
              : "string" == typeof t
              ? (n = t)
              : "object" == typeof t &&
                ((n = t.status),
                (o = t.value),
                (i = t.analytics),
                !0 === e.detail?.surfaceAnalytics &&
                  (void 0 === o && (o = {}), (o.analytics = i))),
              this.D(e, n, o, r, i);
          })
          .catch((t) => {
            this.I(e, t, r);
          });
      }
      L(t, e, r) {
        const n = [];
        this.k(n, t, e, r), this.C(n, t), this.F(n, t, e);
      }
      M(t, e) {
        if (void 0 !== t.status) return;
        const r = t.detail?.error;
        if (void 0 !== r) {
          t.status = l.error;
          const n = this.T(r),
            o = {
              id: t.type,
              analyticsSampleRateAdjustFactor: this.j(t),
              error: n,
              props: {
                ...t.detail.analytics,
                eventDetailSource: t.detail.source,
              },
            };
          "string" == typeof t.detail.libraryVersion &&
            (o.libraryVersion = t.detail.libraryVersion),
            e.recordErrorEvent(o);
        }
      }
      T(t) {
        let e;
        if (t instanceof Error) e = t;
        else if ("string" == typeof t) e = new Error(t);
        else if ("object" == typeof t && null !== t) {
          let r = "Error object";
          if ("message" in t && "string" == typeof t.message) r = t.message;
          else if ("error" in t && "string" == typeof t.error) r = t.error;
          else
            try {
              (r = JSON.stringify(t)),
                r.length > 500 && (r = r.substring(0, 497) + "...");
            } catch {
              r = `Complex error object of type ${
                t.constructor?.name || "unknown"
              }`;
            }
          (e = new Error(r)), (e.originalError = t);
        } else e = new Error(`Error value: ${String(t)}`);
        return e;
      }
      U(t, e) {
        if (void 0 !== t.status) return;
        const r = t.detail?.analytics;
        if (void 0 !== r) {
          t.status = l.analytics;
          const n = {
            id: t.type,
            status: t.status,
            analyticsSampleRateAdjustFactor: this.j(t),
            props: { ...r },
          };
          "string" == typeof t.detail.libraryVersion &&
            (n.libraryVersion = t.detail.libraryVersion),
            e.recordStatusChangeEvent(n);
        }
      }
      V(t, e) {
        this.l(e, t) && this.N(t, l.deactivated, e);
      }
      K(t, e) {
        void 0 === t.status &&
          void 0 === this.v(e, t) &&
          this.N(t, l.unknown, e);
      }
      O(t, e) {
        if ((A() && r.error(e), void 0 !== t.detail?.reject))
          try {
            t.detail.reject(e);
          } catch (t) {
            r.error(t);
          }
      }
      H(t, e) {
        const r = new Error(`Invalid account ID: "${e.id}"`);
        this.I(t, r, e);
      }
      static J(t) {
        return (
          "string" == typeof t &&
          !["", "undefined", "true", "false"].includes(t.trim())
        );
      }
      q(t, e, n) {
        O.J(e.id)
          ? (this.M(t, e),
            this.U(t, e),
            this.K(t, e),
            this.V(t, e),
            this.S(t) &&
              (this.N(t, l.started, e),
              A() &&
                r.info(
                  `## Execute event: ${t.type} with initial status ${
                    t.status ?? "undefined"
                  }`
                ),
              this.L(t, e, n)))
          : this.H(t, e);
      }
      B(t) {
        const e = new b(this.globalContext, this.rootName).use(R),
          r = t.use(D);
        e.forEach((e, n) => {
          if (r.has(n)) return;
          const o = e.map(([t, e]) => new CustomEvent(t, { detail: e }));
          t.queue.unshift(...o), t.update(D, (t) => t.add(n));
        });
      }
      W(t, e, r) {
        this.B(t), t.queue.forEach((r) => this.q(r, t, e));
      }
      G(t, e) {
        (t.status = e),
          (t.statusEvents = null != t.statusEvents ? t.statusEvents : []),
          t.statusEvents.push(new CustomEvent(e));
      }
      j(t) {
        if (t.detail?.analyticsSampleRateAdjustFactor)
          return t.detail.analyticsSampleRateAdjustFactor;
        const e = new b(this.globalContext, this.rootName).use(P);
        return e?.get(t.type);
      }
      Y(t, e, r, n) {
        const o = new CustomEvent("now").timeStamp,
          i = t.statusEvents?.find((t) => t.type === l.started),
          s = null != i ? o - i.timeStamp : void 0;
        r.recordStatusChangeEvent({
          id: t.type,
          status: e,
          analyticsSampleRateAdjustFactor: this.j(t),
          props: {
            ...r.use(N),
            ...n,
            source: t.detail?.source,
            timers: { sinceCreated: o - t.timeStamp, sinceStarted: s },
          },
        });
      }
      N(t, e, n, o) {
        t.status !== e &&
          (A() &&
            r.info(
              `### Update ${t.type} from ${t.status ?? "undefined"} to ${e}`
            ),
          this.G(t, e),
          this.Y(t, e, n, o));
      }
      Z() {
        const t = new Map();
        return (
          this.globalContext[this.rootName].forEach((e, r) =>
            t.set(
              r,
              new y(r, {
                globalContext: this.globalContext,
                rootName: this.rootName,
              })
            )
          ),
          t
        );
      }
      X(t) {
        if (A()) return;
        const e = t.store.get(E) ?? [];
        if (e.length > 150) {
          const r = e.slice(-100);
          t.store.set(E, r);
        }
      }
      tt(t) {
        const e = t.store.get(E) ?? [];
        e.push(
          ...t.queue.filter((t) => void 0 !== t.status && I.includes(t.status))
        ),
          t.store.set(E, e);
      }
      et(t) {
        t.queue.splice(
          0,
          t.queue.length,
          ...t.queue.filter((t) => void 0 === t.status || !I.includes(t.status))
        );
      }
      rt() {
        this.Z().forEach((t) => {
          this.tt(t), this.X(t), this.et(t);
        });
      }
      nt(t) {
        return t?.filter(
          (t) =>
            t.detail?.source !== a.internal &&
            t.detail?.source !== a.apstag &&
            t.status !== l.waiting
        );
      }
      ot(t) {
        const e = this.nt(t);
        return e?.length ?? 0;
      }
      it(t) {
        const e = this.ot(t);
        this.A(_, e);
      }
      st() {
        const t = "_internal/recentDispatches";
        this.A(t, 1);
        const e = this.$(t);
        if (e > 1e4) throw new Error("Too many dispatches. Aborting");
        e % 100 == 0 &&
          new b(this.globalContext, this.rootName).recordGenericEvent({
            id: "C.l.D.thr",
            props: { recentDispatchesCount: e },
          }),
          setTimeout(() => {
            this.R(t);
          }, 100);
      }
      i({ reason: t }) {
        try {
          this.st(),
            A() &&
              r.info(
                `# Dispatch from method "${t.method}" on event "${
                  t.events?.[0].type ?? "undefined"
                }" with source "${
                  t.events?.[0].detail?.source ?? "undefined"
                }"\n_________________________________________`
              ),
            this.it(t.events);
          const e = new b(this.globalContext, this.rootName);
          this.Z().forEach((r) => this.W(r, e, t)), this.rt();
        } catch (t) {
          throw (
            (new b(this.globalContext, this.rootName).recordErrorEvent({
              id: "C.l.D.dis",
              error: t,
            }),
            t)
          );
        }
      }
    }
    class j {
      constructor(t, e) {
        (this.globalContext = t), (this.rootName = e);
      }
      subscribe(t) {
        try {
          const e = new b(this.globalContext, this.rootName),
            r = null != e.store.get(g) ? e.store.get(g) : new Map();
          e.store.set(g, new Map([...r, ...t]));
        } catch (t) {
          throw (
            (new b(this.globalContext, this.rootName).recordErrorEvent({
              id: "Core.library.Subscriber.subscribe",
              error: t,
            }),
            t)
          );
        }
      }
    }
    class k {
      constructor(t, e) {
        (this.globalContext = t), (this.rootName = e);
      }
      populate() {
        try {
          const t = new b(this.globalContext, this.rootName);
          let e = !1;
          try {
            e = JSON.parse(t.read(o));
          } catch {}
          if (e) return;
          t.write(o, JSON.stringify(!0)), this.populateFromPrependStore();
        } catch (t) {
          new b(this.globalContext, this.rootName).recordErrorEvent({
            id: "Core.library.Populator.populate",
            error: t,
          });
        }
      }
      populateFromPrependStore() {
        this.globalContext[this.rootName].forEach((t, e) => {
          const r = new y(e, {
              globalContext: this.globalContext,
              rootName: this.rootName,
            }),
            o = r.read(n, { persist: !0 }) ?? "[]";
          r.write(n, JSON.stringify([]));
          try {
            const t = JSON.parse(o);
            if (0 === t.length) return;
            r.queue.push(...t.map(F));
          } catch (t) {
            console.error("Error processing prepended events", t);
          }
        });
      }
    }
    const F = (t) =>
        new CustomEvent(t.eventName, { detail: { ...(t.eventDetail ?? {}) } }),
      L = window;
    class M {
      constructor(t, e, r) {
        (this.ID = t),
          (this.rootName = r),
          (this.globalContext = e),
          this.clear();
      }
      clear() {
        new b(this.globalContext, this.rootName).update(
          R,
          (t) => (t.delete(this.ID), t)
        );
      }
      recordListener(t, e) {
        new b(this.globalContext, this.rootName).update(R, (r) => {
          const n = r.get(this.ID);
          return (
            void 0 !== n ? n.push([t.name, e]) : r.set(this.ID, [[t.name, e]]),
            r
          );
        });
      }
    }
    class T {
      constructor(t = L, e = "_aps") {
        (this.dispatcher = new O(t, e)),
          (this.equiper = new $(t, e, this.dispatcher)),
          (this.subscriber = new j(t, e)),
          (this.populator = new k(t, e)),
          (this.globalContext = t),
          (this.rootName = e);
      }
      createAccount(t) {
        if (void 0 === t) throw new Error("accountID must be provided");
        this.globalContext[this.rootName] =
          this.globalContext[this.rootName] ?? new Map();
        const e = this.globalContext[this.rootName],
          r = { store: new Map(), queue: [] };
        return (
          !1 === e.has(t) && e.set(t, r),
          new y(t, {
            globalContext: this.globalContext,
            rootName: this.rootName,
          })
        );
      }
      subscribe(t) {
        this.subscriber.subscribe(t);
      }
      equip() {
        this.equiper.equip();
      }
      dispatch({ reason: t }) {
        this.dispatcher.i({ reason: t });
      }
      populate() {
        this.populator.populate();
      }
      load({ listeners: t }) {
        this.equip(),
          this.subscribe(t),
          this.dispatch({ reason: { method: s.direct } }),
          this.populate();
      }
      registerEventSource(t) {
        return this.equip(), new M(t, this.globalContext, this.rootName);
      }
    }
    var U;
    !(function (t) {
      (t.postulate = "postulate"), (t.genericError = "error");
    })(U || (U = {}));
    const V = "26.1120.2055";
    function K(t, e, r) {
      const n = new URL(
        "https://prod.tahoe-analytics.publishers.advertising.a2z.com/logevent/putRecord"
      );
      let o = t;
      try {
        "web-client-scenarios.aps.amazon.dev" === r?.hostname
          ? (o = t + "-debug-only")
          : window.Cypress && (o = t + "-integration-test");
      } catch (t) {}
      const i = {
        ...r,
        eventSource: "aps_web_client_library",
        eventCategory: o,
        eventName: e,
        libraryVersion: V,
      };
      Object.entries(i).forEach(([t, e]) => {
        n.searchParams.append(t, e);
      }),
        fetch(n.toString(), {
          method: "GET",
          keepalive: !0,
          headers: {
            "x-api-key":
              "79db72eb0b5c7255afa54a253df24fb4a5ac916bf40b51c730df8850aa5665ca",
          },
        }).catch(() => {});
    }
    const H = {
        ct: setInterval,
        ut: function () {
          return window[J]?.[q];
        },
        lt: function (t = window) {
          try {
            return t.top?.location || { href: "unknown", hostname: "unknown" };
          } catch (t) {
            return { href: "unknown", hostname: "unknown" };
          }
        },
        ht: K,
        dt: function (t, e) {
          return {
            eventTime: z(() => `${Date.now()}`),
            accountID: z(() => t?.accountID),
            libraryVersion: V,
            url: z(() => e().href),
            hostname: z(() => e().hostname),
            message: z(() => t?.message),
            condition: z(() => t?.condition),
          };
        },
        ft: function (t, e) {
          try {
            (e ?? K)(U.genericError, "telemetry_core_failure", {
              errorName: t?.name ?? "unknown",
              errorMessage: t?.message ?? "unknown",
            });
          } catch {
            (e ?? K)(U.genericError, "telemetry_core_failure");
          }
        },
      },
      J = "_aps_telemetry",
      q = "alarms";
    function z(t) {
      try {
        return t() ?? "undefined";
      } catch (t) {
        return (function (t) {
          try {
            return t instanceof Error
              ? `Access Error: ${t.name} - ${t.message}`
              : "Access Error: Unknown error type";
          } catch {
            return "Access Error: Unable to provide more information";
          }
        })(t);
      }
    }
    function B(t, e, r) {
      const n = () => !1;
      throw (
        (r ||
          (function (t, e, r) {
            const n = window;
            void 0 === n[J] && (n[J] = {}),
              void 0 === n[J][q] && (n[J][q] = []);
            const o = n[J][q],
              i = e.toString();
            o.push({ hash: t, context: { ...r, condition: i } });
          })(t, n, e),
        new Error(e?.message ?? `Postulate violation: ${t}, ${n}`))
      );
    }
    const W = new WeakMap();
    function G({ debugKey: t, obj: e, validators: r, root: n, separator: o }) {
      (n = n ?? "root"), (o = o ?? ".");
      const i = {
          nonModifiable: {
            set(t, e) {
              throw new Error(
                `Cannot set property "${String(
                  e
                )}": "${n}" is not marked as modifiable.`
              );
            },
            deleteProperty(t, e) {
              throw new Error(
                `Cannot delete property "${String(
                  e
                )}": "${n}" is not marked as modifiable.`
              );
            },
            defineProperty(t, e) {
              throw new Error(
                `Cannot define property "${String(
                  e
                )}": "${n}" is not marked as modifiable.`
              );
            },
            setPrototypeOf(t) {
              throw new Error(
                `Cannot set prototype: "${n}" is not marked as modifiable.`
              );
            },
          },
          modifiable: {
            set(t, e, r, n) {
              try {
                return Reflect.set(t, e, r, n);
              } catch (n) {
                if ("TypeError" === n.name) return (t[e] = r), !0;
                throw n;
              }
            },
          },
          validating: {
            get(e, i, s) {
              if ("raw" === i) return W.get(s) || e;
              if ("symbol" == typeof i) return Reflect.get(e, i, s);
              if (
                ((t) => {
                  if (["asymmetricMatch", "nodeType"].includes(t)) return !0;
                })(i)
              )
                return Reflect.get(e, i, s);
              let a;
              try {
                a = Reflect.get(e, i, s);
              } catch (t) {
                if ("TypeError" !== t.name) throw t;
                a = e[i];
              }
              return G({
                obj: a,
                validators: r,
                root: `${n}${o}${String(i)}`,
                debugKey: t,
              });
            },
            ownKeys: (t) =>
              Reflect.ownKeys(t).filter((t) => {
                const e = `${n}${o}${String(t)}`;
                return void 0 !== r[e];
              }),
          },
          function: {
            apply: (e, o, i) => {
              const s = W.has(o) ? W.get(o) : o;
              return G({
                obj: e.apply(s, i),
                validators: r,
                root: `${n}()`,
                debugKey: t,
              });
            },
            get: (t, e, r) =>
              "raw" === e ? W.get(r) || t : Reflect.get(t, e, r),
          },
        },
        s = (function (o) {
          if (!1 === o.verifiable) return e;
          if (e instanceof Set)
            return (
              e.forEach((e) => {
                G({ obj: e, validators: r, root: `${n}.value`, debugKey: t });
              }),
              e
            );
          if (e instanceof Map)
            return (
              e.forEach((e, o) => {
                G({ obj: o, validators: r, root: `${n}.key`, debugKey: t }),
                  G({ obj: e, validators: r, root: `${n}.value`, debugKey: t });
              }),
              e
            );
          if (Array.isArray(e))
            return e.map((e) =>
              G({ obj: e, validators: r, root: `${n}[]`, debugKey: t })
            );
          if ("function" == typeof e) {
            const t = new Proxy(e, i.function);
            return W.set(t, e), t;
          }
          const s = {
            ...i.validating,
            ...(o?.modifiable ? i.modifiable : i.nonModifiable),
          };
          try {
            const t = new Proxy(e, s);
            return W.set(t, e), t;
          } catch (t) {
            if ("TypeError" === t.name) return e;
            throw t;
          }
        })(
          (function () {
            const o = (t ?? "").length > 0 ? `Location: ${t} - ` : "",
              i = r[n ?? ""];
            if (void 0 === i) {
              const t =
                ".constructor" === (n ?? "").slice(-12) ||
                ".toString" === (n ?? "").slice(-9);
              B(
                "ea3914",
                {
                  message: `${o}Unauthorized usage for "${n}": No validator has been defined`,
                },
                t
              );
            }
            if (null === i) return { verifiable: !1 };
            let s;
            try {
              s = i(e, n);
            } catch (t) {
              let r = "Error, could not convert to string";
              try {
                r =
                  "string" == typeof e
                    ? '"' + e + '"'
                    : null != e && "function" == typeof e.toString
                    ? e.toString()
                    : Object.prototype.toString.call(e);
              } catch (t) {}
              throw new Error(
                `${o}Validation failed for "${n}": ${t.message} - Received: ${r}`
              );
            }
            return s ?? {};
          })()
        );
      return s;
    }
    const Q = (t) => {
        if ("number" != typeof t) throw new Error("must be a number");
      },
      Y = (t) => {
        if ("string" != typeof t) throw new Error("must be a string");
      },
      Z = (t) => {
        if ("object" != typeof t || null === t || Array.isArray(t))
          throw new Error("must be a standard object");
      },
      X = (t) => {
        if (!Array.isArray(t)) throw new Error("must be an array");
      };
    function tt(t) {
      return (e, r) => ({ modifiable: !0, ...t(e, r) });
    }
    function et(t) {
      return (e, r) => {
        if (t === nt) throw new Error("isAny cannot be used within isOptional");
        if (null != e) return t(e, r);
      };
    }
    const rt = (t) => {
        if ("function" != typeof t) throw new Error("must be a function");
      },
      nt = () => {},
      ot = () => ({ verifiable: !1 }),
      it = (t) => {
        if (void 0 !== t) throw new Error("must be undefined");
      };
    class st {
      constructor(t) {
        const {
            scope: e,
            object: r,
            action: n,
            validators: o,
            handler: i,
            shouldFlushAnalytics: s,
          } = t,
          a = `${e}/${r}/${n}`;
        this.throwIfInvalid(e, r, n),
          (this.name = `${e}/${r}/${n}`),
          (this.handler = this.wrapHandler({
            handler: i,
            validators: o,
            debugKey: a,
          })),
          !0 === s && (this.handler.shouldFlushAnalytics = !0);
      }
      wrapHandler({ debugKey: t, handler: e, validators: r }) {
        return async (n) => {
          let o = n;
          return (
            (o = {
              ...o,
              detail: G({
                obj: o.customEvent.detail,
                validators: this.getDetailValidators(r),
                root: "detail",
                debugKey: t,
              }),
              context: G({
                obj: o.account.globalContext,
                validators: this.getContextValidators(r),
                root: "context",
                debugKey: t,
              }),
            }),
            await e(o)
          );
        };
      }
      getDetailValidators(t) {
        return t?.detail && 0 !== Object.keys(t.detail).length
          ? t.detail
          : { detail: nt };
      }
      getContextValidators(t) {
        return t?.context && 0 !== Object.keys(t.context).length
          ? t.context
          : { context: nt };
      }
      throwIfInvalid(t, e, r) {
        if (
          [
            "consent/gppapi/attemptSync",
            "consent/gppapi/didChange",
            "consent/gppapi/syncData",
            "consent/tcfapi/attemptSync",
            "consent/tcfapi/didChange",
            "log/analytics/setInterval",
            "analytics/sampling/set",
            "googletag/pubads/setConfig",
            "googletag/pubads/getConfig",
            "googletag/pubads/clearTargeting",
            "googletag/slot/setConfig",
            "googletag/slot/getConfig",
            "googletag/slot/clearTargeting",
          ].includes(`${t}/${e}/${r}`)
        )
          return;
        const n = /^[a-z0-9][a-zA-Z0-9]*$/;
        if (!n.test(t) || !n.test(e) || !n.test(r))
          throw new Error(
            `scope, object, and action must be alphanumeric and start with a lowercase. Received: ${t}, ${e}, ${r}`
          );
        if (/[A-Z]/.test(r) && !/^(will|did)/i.test(r))
          throw new Error(
            `action must be a single verb (or a single verb prefixed by 'will' or 'did'). Received: ${r}`
          );
      }
    }
    function at(t) {
      if (new Set(t.map((t) => t.name)).size !== t.length)
        throw new Error("Duplicates found");
      return new Map(t.map((t) => [t.name, t.handler]));
    }
    class ct {
      constructor() {
        (this.wt = 300),
          (this.yt =
            "https://prod.tahoe-analytics.publishers.advertising.a2z.com/logevent/putRecords"),
          (this.vt =
            "79db72eb0b5c7255afa54a253df24fb4a5ac916bf40b51c730df8850aa5665ca"),
          (this.bt = 5e3),
          (this.gt = []),
          this.clearAndUpdateEventProcessingInterval(5e3);
      }
      logEvent(t) {
        try {
          const r = `${Date.now()}`,
            n =
              null == (e = t.eventSampleRate) || isNaN(e) || e < 0
                ? 0
                : e >= 0 && e <= 1
                ? e
                : 1,
            o = {
              Data: {
                eventSource: "aps_web_client_library",
                eventTime: r,
                eventCategory: t.eventCategory,
                eventName: t.eventName,
                eventSampleRate: n,
                eventProperties: {
                  ...t.eventProperties,
                  eventSampleRate: `${n}`,
                },
              },
              PartitionKey: r,
            };
          this.gt.push(o);
        } catch (t) {
          B("4daf34", { message: t.message });
        }
        var e;
        this.gt.length > this.bt && this.safelyProcessRecordQueue();
      }
      flush() {
        this.safelyProcessRecordQueue();
      }
      clearAndUpdateEventProcessingInterval(t) {
        "number" != typeof t ||
          t <= 0 ||
          (t !== this.Et &&
            (clearInterval(this._t),
            (this._t = setInterval(() => this.safelyProcessRecordQueue(), t)),
            (this.Et = t)));
      }
      safelyProcessRecordQueue() {
        if (void 0 === this.gt || this.gt.length <= 0) return;
        const t = this.gt.filter(
          (t) => void 0 !== t && t.Data.eventSampleRate >= Math.random()
        );
        (this.gt.length = 0),
          t.length <= 0 ||
            this.batchSendRecords(t).catch((t) => {
              this.logEvent({
                eventCategory: "error",
                eventName: "tahoe/putRecords/didFail",
                eventSampleRate: 1,
                eventProperties: { error: { message: t?.message } },
              });
            });
      }
      batchSendRecords(t) {
        const e = [];
        for (let r = 0; r < t.length; r += this.wt) {
          const n = this.sendRecords(t.slice(r, r + this.wt));
          e.push(n);
        }
        return Promise.all(e);
      }
      sendRecords(t) {
        return fetch(`${this.yt}?encoded=${A() ? "false" : "true"}`, {
          method: "POST",
          headers: { "Content-Type": "application/json", "x-api-key": this.vt },
          body: JSON.stringify({
            Records: A()
              ? t
              : ((t) =>
                  t.map((t) => ({
                    ...t,
                    Data: window.btoa(JSON.stringify(t.Data)),
                  })))(t),
          }),
        });
      }
    }
    const ut = { key: "_config/requestViewer/countryCode", default: "unknown" },
      lt = { key: "video/analytics", default: void 0 },
      ht = (() => {
        try {
          const t = window?.__aps_slice ?? window?.top?.__aps_slice;
          return "number" == typeof t && Number.isInteger(t) && t > 0
            ? t
            : void 0;
        } catch {
          return;
        }
      })(),
      dt = new (class {
        constructor() {
          (this.STACK_MAX_LENGTH = 500),
            (this.$t = 0.001),
            (this.St = 1e-4),
            (this.xt = new ct());
        }
        getVideoPlayerMetadata(t) {
          const e = t.account?.use(lt, { structuredClone: !1 }),
            r = "object" == typeof t.props?.legacyPlayerEventProps;
          return e?.getMetadata && !r
            ? { legacyPlayerEventProps: e.getMetadata() }
            : {};
        }
        fireReferencePixel(t, e) {
          this.logCoreError({
            id: `REFERENCE-${t}`,
            error: new Error(`REFERENCE-${t}`),
            analyticsSampleRateAdjustFactor: e ?? { status: 0.01, error: 0.01 },
            account: null,
          });
        }
        logCoreError(t) {
          this.logError({ ...t, isCore: !0 });
        }
        logCoreFeature(t) {
          this.logFeature({ ...t, isCore: !0 });
        }
        logError(t) {
          if (void 0 === t) return;
          const e = this.getEventSampleRate({
            eventCategory: "error",
            rateFactor: {
              error: t.analyticsSampleRateAdjustFactor?.error,
              status: t.analyticsSampleRateAdjustFactor?.status,
            },
          });
          this.xt.logEvent({
            eventCategory: "error",
            eventName: t.id ?? "unknown",
            eventSampleRate: e,
            eventProperties: {
              ...t.props,
              ...this.getSharedEventProperties(t),
              error: {
                name: this.getErrorName(t.error),
                message: this.getErrorMessage(t.error),
                stack: this.getStackTraceMessage(t.error),
                context: this.getErrorContext(t.error),
              },
            },
          });
        }
        logFeature(t) {
          if (void 0 === t) return;
          const e = this.getEventSampleRate({
            eventCategory: "feat",
            rateFactor: {
              error: t.analyticsSampleRateAdjustFactor?.error,
              status: t.analyticsSampleRateAdjustFactor?.status,
            },
          });
          this.xt.logEvent({
            eventCategory: "feat",
            eventName: t.id ?? "unknown",
            eventSampleRate: e,
            eventProperties: {
              ...t.props,
              ...this.getSharedEventProperties(t),
              status: t.feature,
            },
          });
        }
        flush() {
          this.xt.flush();
        }
        setEventProcessingInterval(t) {
          if ("number" != typeof t)
            throw new Error("Event processing interval must be a number.");
          this.xt.clearAndUpdateEventProcessingInterval(t);
        }
        setEventSamplingRates(t) {
          const e = (t) => (t < 0 ? 0 : t >= 0 && t <= 1 ? t : 1);
          "number" == typeof t?.error && (this.$t = e(t.error)),
            "number" == typeof t?.feature && (this.St = e(t.feature));
        }
        getEventSampleRate(t) {
          let e = 0;
          return (
            (e =
              "error" === t.eventCategory
                ? this.$t * (t.rateFactor?.error ?? 1)
                : this.St * (t.rateFactor?.status ?? 1)),
            Number.isNaN(e) || e < 0 ? 0 : e >= 0 && e <= 1 ? e : 1
          );
        }
        getSharedEventProperties(t) {
          return {
            isCore: t.isCore ?? !1,
            accountID: this.safelyGetAccountID(t.account),
            libraryVersion: t.libraryVersion ?? S,
            url: this.getLocationHref(),
            hostname: this.getLocationHostname(),
            viewerCountryCode: this.getViewerCountryCode(t.account),
            ...(void 0 !== ht && { slice: ht }),
            ...this.getVideoPlayerMetadata(t),
          };
        }
        safelyGetAccountID(t) {
          let e = "unknown";
          try {
            void 0 !== t?.id && (e = t.id);
          } catch (t) {
            try {
              e = `Client Error: ${t.name.toString()} - ${t.message}`;
            } catch {
              e = "Client Error: Unable to provide more information";
            }
          }
          return e;
        }
        getLocationHref() {
          let t = "";
          try {
            t = window.top?.location?.href ?? "";
          } catch (e) {
            try {
              t = `Client Error: ${e.name.toString()} - ${e.message}`;
            } catch {
              t = "Client Error: Unable to provide more information";
            }
          }
          return t;
        }
        getLocationHostname() {
          let t = "";
          try {
            t = window.top?.location?.hostname ?? "";
          } catch (e) {
            try {
              t = `Client Error: ${e.name.toString()} - ${e.message}`;
            } catch {
              t = "Client Error: Unable to provide more information";
            }
          }
          return t;
        }
        getViewerCountryCode(t) {
          let e = "unknown";
          try {
            null !== t && (e = t.use(ut));
          } catch (t) {
            try {
              e = `Client Error: ${t.name.toString()} - ${t.message}`;
            } catch {
              e = "Client Error: Unable to provide more information";
            }
          }
          return e;
        }
        getStackTraceMessage(t) {
          try {
            if ("string" == typeof t) return "NO STACK: ERROR PASSED AS STRING";
            if (void 0 === t.stack) return "NO STACK: error.stack IS UNDEFINED";
            if (t.stack.length > this.STACK_MAX_LENGTH) {
              const e = "[...]";
              return t.stack.substring(0, this.STACK_MAX_LENGTH - e.length) + e;
            }
            return t.stack;
          } catch (t) {
            return "NO STACK: ERROR ON RETRIEVAL";
          }
        }
        getErrorName(t) {
          let e = "unknown";
          try {
            "string" == typeof t ? (e = t) : void 0 !== t.name && (e = t.name);
          } catch (t) {
            try {
              e = `Client Error: ${t.name.toString()} - ${t.message}`;
            } catch {
              e = "Client Error: Unable to provide more information";
            }
          }
          return e;
        }
        getErrorMessage(t) {
          let e = "unknown";
          try {
            "string" == typeof t
              ? (e = t)
              : void 0 !== t.message && (e = t.message);
          } catch (t) {
            try {
              e = `Client Error: ${t.name.toString()} - ${t.message}`;
            } catch {
              e = "Client Error: Unable to provide more information";
            }
          }
          return e;
        }
        getErrorContext(t) {
          let e = "unknown";
          try {
            "string" != typeof t && "context" in t && (e = t.context ?? "");
          } catch (t) {
            try {
              e = `Client Error: ${t.name.toString()} - ${t.message}`;
            } catch {
              e = "Client Error: Unable to provide more information";
            }
          }
          return e;
        }
      })();
    var ft = new st({
        scope: "banner",
        object: "iframe",
        action: "render",
        validators: {
          detail: {
            detail: Z,
            "detail.src": et(Y),
            "detail.srcdoc": et(Y),
            "detail.inheritSize": (t) => {
              if ("boolean" != typeof t) throw new Error("must be a boolean");
            },
            "detail.width": Q,
            "detail.height": Q,
          },
          context: {
            context: Z,
            "context.frameElement": Z,
            "context.frameElement.style": tt(Z),
            "context.frameElement.style.width": Y,
            "context.frameElement.style.height": Y,
            "context.document": Z,
            "context.document.defaultView": et(Z),
            "context.document.defaultView.frameElement": Z,
            "context.document.defaultView.frameElement.style": tt(Z),
            "context.document.defaultView.frameElement.style.width": Y,
            "context.document.defaultView.frameElement.style.height": Y,
            "context.document.readyState": Y,
            "context.document.addEventListener": rt,
            "context.document.addEventListener()": it,
            "context.document.body": Z,
            "context.document.body.appendChild": rt,
            "context.document.body.appendChild()": nt,
            "context.document.createElement": rt,
            "context.document.createElement()": tt(Z),
            "context.document.createElement().style": tt(Z),
            "context.document.createElement().style.border": Y,
            "context.document.createElement().style.margin": Y,
            "context.document.createElement().style.overflow": Y,
            "context.document.createElement().style.width": Y,
            "context.document.createElement().style.height": Y,
            "context.document.createElement().src": Y,
            "context.document.createElement().outerHTML": ot,
            "context.document.createElement().baseURI": ot,
            "context.document.createElement().setAttribute": rt,
            "context.document.createElement().setAttribute()": it,
            "context.document.createElement().addEventListener": rt,
            "context.document.createElement().addEventListener()": it,
            "context.document.createElement().contentWindow": (t) => {
              if (!t || t.window !== t) throw new Error("must be a Window");
              return { verifiable: !1 };
            },
          },
        },
        handler: async ({ context: t, detail: e }) => {
          const r = `amznad${Math.round(1e6 * Math.random())}`,
            n = t.document.createElement("iframe");
          if (
            ((n.id = r),
            (n.scrolling = "no"),
            (n.style.border = "none"),
            (n.style.margin = "0"),
            e.inheritSize
              ? ((n.style.width = "100%"), (n.style.height = "100%"))
              : ((n.style.width = `${e.width}px`),
                (n.style.height = `${e.height}px`)),
            n.setAttribute(
              "sandbox",
              "allow-forms allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts allow-top-navigation-by-user-activation"
            ),
            void 0 !== e.srcdoc)
          )
            n.srcdoc = "<style>body { margin: 0; }</style>" + e.srcdoc;
          else {
            if (void 0 === e.src)
              throw new Error("No creative source provided.");
            n.src = e.src;
          }
          if (
            (((e) => {
              const r = e.raw;
              "loading" === t.document.readyState
                ? t.document.addEventListener(
                    "DOMContentLoaded",
                    () => {
                      t.document.body.appendChild(r);
                    },
                    { once: !0 }
                  )
                : t.document.body.appendChild(r);
            })(n),
            !e.inheritSize)
          ) {
            let r;
            (r =
              t.document.defaultView && t.document.defaultView.frameElement
                ? t.document.defaultView.frameElement
                : t.frameElement),
              (r.style.width = `${e.width}px`),
              (r.style.height = `${e.height}px`);
          }
          return { status: c.completed };
        },
      }),
      wt = new st({
        scope: "banner",
        object: "html",
        action: "fetch",
        validators: {
          detail: { detail: Z, "detail.creativeurl": Y },
          context: { context: Z },
        },
        handler: async ({ detail: t }) => {
          const e = await fetch(t.creativeurl),
            r = await e.json();
          if (!r.html)
            throw new Error(
              `No html property found in JSON response from creative URL: ${t.creativeurl}`
            );
          return { value: { html: r.html }, status: c.completed };
        },
      });
    const pt = {
        response: Z,
        "response.seatbid": X,
        "response.seatbid[]": Z,
        "response.seatbid[].bid": X,
        "response.seatbid[].bid[]": Z,
        "response.seatbid[].bid[].id": Y,
        "response.seatbid[].bid[].price": Q,
        "response.seatbid[].bid[].w": Q,
        "response.seatbid[].bid[].h": Q,
        "response.seatbid[].bid[].ext": Z,
        "response.seatbid[].bid[].ext.creativeurl": Y,
        "response.seatbid[].bid[].ext.tagtype": Y,
      },
      mt = at([
        new st({
          scope: "prebid",
          object: "creative",
          action: "render",
          validators: {
            detail: {
              detail: Z,
              "detail.aaxResponse": Y,
              "detail.seatBidId": Y,
            },
            context: {
              context: Z,
              "context.atob": rt,
              "context.atob()": Y,
              "context.TextDecoder": rt,
              "context.TextDecoder()": Z,
              "context.TextDecoder().decode": rt,
              "context.TextDecoder().decode()": Y,
            },
          },
          handler: async ({ account: t, context: e, detail: r }) => {
            const n = r.aaxResponse,
              o = e.atob.call(e, n),
              i = Uint8Array.from(o, (t) => t.charCodeAt(0)),
              s = new e.TextDecoder("utf-8").decode(i),
              a = G({
                obj: JSON.parse(s),
                validators: pt,
                root: "response",
                debugKey: "prebid/creative/render(custom)",
              }),
              {
                width: u,
                height: l,
                creativeurl: h,
                tagtype: d,
              } = (function (t, e) {
                const r = e.replace(/^['"]|['"]$/g, ""),
                  n = t.seatbid.flatMap((t) => t.bid).find((t) => t.id === r);
                if (n)
                  return {
                    bidValue: n.price,
                    width: n.w,
                    height: n.h,
                    creativeurl: n.ext.creativeurl,
                    tagtype: n.ext.tagtype,
                  };
                throw new Error(`Bid with id "${r}" not found.`);
              })(a, r.seatBidId);
            if ("iframe" === d)
              await t.recordListener(ft, {
                src: h,
                inheritSize: !1,
                width: u,
                height: l,
              });
            else if ("script" === d) {
              const { html: e } = await t.recordListener(wt, {
                creativeurl: h,
              });
              await t.recordListener(ft, {
                srcdoc: e,
                inheritSize: !1,
                width: u,
                height: l,
              });
            } else B("8b5540", { message: `${d} is an unsupported tagtype` });
            return { status: c.completed };
          },
        }),
      ]),
      yt = at([ft, wt]),
      vt = "prebid-creative";
    !(function (t = {}) {
      const { ct: e, ft: r } = { ...H, ...t };
      try {
        e(() => {
          !(function (t = {}) {
            const { ut: e, ht: r, dt: n, ft: o } = { ...H, ...t };
            try {
              const o = e();
              if (void 0 === o || 0 === o.length) return;
              !(function (t, e) {
                if (!e()) {
                  K(U.postulate, t);
                  let r = `Assertion failed: ${e.toString()}`;
                  throw (t && (r += ` - ${t}`), new Error(r));
                }
              })("5c098d", () => Array.isArray(o));
              const i = (function (t) {
                return t.shift();
              })(o);
              if (void 0 === i) return;
              r(U.postulate, i.hash, n(i.context, t.lt || H.lt));
            } catch (t) {
              o(t);
            }
          })({ ...H, ...t });
        }, 3e3);
      } catch (t) {
        r(t);
      }
    })();
    try {
      dt.fireReferencePixel(vt);
      const t = new Map([...mt, ...yt]),
        e = new T();
      e.registerEventSource(vt), e.load({ listeners: t });
    } catch (t) {
      dt.logCoreError({ id: vt, error: t, account: null }), A() && r.error(t);
    }
  })();
})();
