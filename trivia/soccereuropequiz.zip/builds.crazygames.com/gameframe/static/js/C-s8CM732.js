!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "c06688db-8652-5f23-bbbc-cc7875e4823b"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `b9fc6dcf-a081-41b4-ac35-621a07eee23e`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-b9fc6dcf-a081-41b4-ac35-621a07eee23e`));
  } catch {}
})();
import {
  Kt as e,
  Xt as t,
  at as n,
  gn as r,
  lt as i,
  ot as a,
  qt as o,
  rn as s,
  rt as c,
  un as l,
  wn as u,
  yn as d,
} from "../../bundle.js";
import { t as f } from "./Dkw7RdYv.js";
import { t as p } from "./DO-9u6qS.js";
var m = u(d()),
  h = l(),
  g = {
    content: `_content_8ax6z_7`,
    icon: `_icon_8ax6z_13`,
    title: `_title_8ax6z_17`,
    body: `_body_8ax6z_22`,
    button: `_button_8ax6z_29`,
  },
  _ = r(),
  v = () => {
    let e = (0, h.c)(6),
      [r, l] = m.useState(!1),
      u,
      d;
    if (
      (e[0] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((u = () => {
            let e = function (e) {
              bb3: switch (e.data.type) {
                case `unityCrashModalOpen`:
                  l(!0);
                  break bb3;
                case `unityCrashError`: {
                  let { error: n, errorMessage: r, origin: i } = e.data;
                  t
                    .getInstance()
                    .sendEvent({
                      type: `unityCrash`,
                      error: n,
                      errorMessage: r,
                      origin: i,
                    }),
                    t
                      .getInstance()
                      .sendEvent({
                        type: `gameError`,
                        slug: s().gameSlug,
                        errorName: n,
                        errorMessage: r,
                        pageVisitId: o(),
                        context: `unityCrash_${i}`,
                      });
                }
              }
            };
            return (
              window.addEventListener(`message`, e),
              () => {
                window.removeEventListener(`message`, e);
              }
            );
          }),
          (d = []),
          (e[0] = u),
          (e[1] = d))
        : ((u = e[0]), (d = e[1])),
      m.useEffect(u, d),
      !r)
    )
      return null;
    let f;
    e[2] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((f = (0, _.jsx)(p, {
          name: `ziggy-error`,
          width: 93,
          height: 107,
          className: g.icon,
        })),
        (e[2] = f))
      : (f = e[2]);
    let v;
    e[3] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((v = (0, _.jsx)(`h2`, {
          className: g.title,
          children: (0, _.jsx)(n, { id: `error.unity.crashed.title` }),
        })),
        (e[3] = v))
      : (v = e[3]);
    let b;
    e[4] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((b = (0, _.jsx)(`p`, {
          className: g.body,
          children: (0, _.jsx)(n, { id: `error.unity.crashed.text` }),
        })),
        (e[4] = b))
      : (b = e[4]);
    let x;
    return (
      e[5] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((x = (0, _.jsx)(a, {
            hideBackdrop: !0,
            children: (0, _.jsxs)(i, {
              className: g.content,
              children: [
                f,
                v,
                b,
                (0, _.jsx)(c, {
                  variant: `contained`,
                  color: `purple`,
                  className: g.button,
                  height: 45,
                  onClick: y,
                  children: (0, _.jsx)(n, { id: `error.unity.crashed.button` }),
                }),
              ],
            }),
          })),
          (e[5] = x))
        : (x = e[5]),
      x
    );
  };
function y() {
  return e.refreshGamePage();
}
var b = class extends f {
  trackProgress(e) {
    let t = super.trackProgress(e);
    return Math.min(t + 0.1, 1);
  }
};
export { v as n, b as t };
//# debugId=c06688db-8652-5f23-bbbc-cc7875e4823b
