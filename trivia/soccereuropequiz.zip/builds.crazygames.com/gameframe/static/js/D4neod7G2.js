!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "c2c8d6c4-d722-57a5-a720-90c40b743fc8"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `a978cd20-6aeb-437d-8fa1-53e398f0b1e7`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-a978cd20-6aeb-437d-8fa1-53e398f0b1e7`));
  } catch {}
})();
import {
  $t as e,
  D as t,
  E as n,
  Ft as r,
  Ht as i,
  Lt as a,
  Mt as o,
  Qt as s,
  Ut as c,
  Xt as l,
  an as u,
  bn as ee,
  c as d,
  gn as f,
  jt as p,
  ln as m,
  nn as h,
  o as g,
  rn as _,
  tn as v,
  tt as y,
  un as b,
  wn as x,
  yn as S,
} from "../../bundle.js";
import { t as C } from "./kpsB5uDx.js";
import { i as w, r as te, t as ne } from "./DCXju1XY.js";
import { n as re, t as ie } from "./C-s8CM732.js";
var T = x(S()),
  ae = b(),
  E = new d(`unity2020ready`),
  D = [
    `out of memory`,
    `out of executable memory`,
    `could not allocate`,
    `abort("oom")`,
    `aborted(oom)`,
    `abortoncannotgrowmemory`,
    `cannot enlarge memory arrays`,
    `invalid array buffer length`,
    `invalid typed array length`,
    `array buffer allocation failed`,
    `does not support webgl`,
    `does not support graphics api`,
    `does not support webassembly`,
  ];
function oe(e) {
  let t = e.toLowerCase();
  return D.some((e) => t.includes(e));
}
var O = f(),
  k = () => {
    let d = (0, ae.c)(24),
      { isGameDisabled: f } = (0, T.useContext)(p),
      { isIos: b } = (0, T.useContext)(y),
      { onLoadFinished: x } = (0, T.useContext)(o),
      { isFullscreen: S } = (0, T.useContext)(n),
      [D, k] = (0, T.useState)(0),
      [M, N] = (0, T.useState)(`loading`),
      [P, F] = (0, T.useState)(null),
      I = T.useRef(null),
      L = T.useRef(null);
    if (L.current === null) {
      let e;
      d[0] === Symbol.for(`react.memo_cache_sentinel`)
        ? ((e = new ie()), (d[0] = e))
        : (e = d[0]),
        (L.current = e);
    }
    let R;
    d[1] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((R = _()), (d[1] = R))
      : (R = d[1]);
    let z = R,
      B = z.loaderOptions,
      V;
    d[2] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((V = g()), (d[2] = V))
      : (V = d[2]);
    let H = V,
      U,
      W;
    d[3] === f
      ? ((U = d[4]), (W = d[5]))
      : ((U = () => {
          if (f) {
            I.current &&= (I.current.remove(), null);
            return;
          }
          let e = ne(H);
          (I.current = e), r(A), h().appendChild(e);
        }),
        (W = [H, f]),
        (d[3] = f),
        (d[4] = U),
        (d[5] = W)),
      (0, T.useEffect)(U, W);
    let G, K;
    d[6] === b
      ? ((G = d[7]), (K = d[8]))
      : ((G = () => {
          let t = _().loaderOptions,
            { unityConfigOptions: n, unitySaveFileNames: r } = t,
            o = {
              ...n,
              companyName: `CrazyGames`,
              productName: v(),
              productVersion: `1.0`,
            };
          e() && (o.devicePixelRatio = s());
          let l = { gameLink: _().gameLink, userInfo: u() };
          E.sendMessage({
            type: `unity2020config`,
            loaderOptions: t,
            unityConfig: o,
            unitySaveFileNames: r,
            oldSdkInitObject: l,
            isIos: b,
            isOfflineGaming: c(),
          });
          let d = async () => {
              if (!te()) {
                ee.error(`Unity WebGL is not available on this browser`),
                  w(`unity-unavailable`),
                  N(`error`);
                return;
              }
              L.current.trackLoadStarted(),
                await a.Instance.waitForAPS(),
                E.sendMessage({ type: `loadGame` });
            },
            f = j;
          return (
            d(),
            i().addAdFinishedListener(f),
            () => {
              i().removeAdFinishedListener(f);
            }
          );
        }),
        (K = [b]),
        (d[6] = b),
        (d[7] = G),
        (d[8] = K)),
      (0, T.useEffect)(G, K);
    let q, J;
    d[9] !== S || d[10] !== x || d[11] !== M
      ? ((q = () => {
          let e = function (e) {
            bb22: switch (e.data.type) {
              case `loadProgress`:
              case `loadprogress`:
                if (M !== `loading`) return;
                k(L.current.trackProgress(e.data.progress)),
                  e.data.progress === 1 &&
                    (L.current.trackLoadFinished(),
                    z.fullscreen === `REQUIRED` && !m() && !S
                      ? N(`fullscreen`)
                      : (N(`loaded`), x()));
                break bb22;
              case `syncUnityData`:
                a.Instance.autoSyncUnityData();
                break bb22;
              case `unityMemoryUsage`:
                l.getInstance().sendEvent(e.data.usageData);
                break bb22;
              case `unityError`:
                F(e.data), N(`error`), w(`unity-game-load-failed`, e.data);
            }
          };
          return (
            window.addEventListener(`message`, e),
            () => {
              window.removeEventListener(`message`, e);
            }
          );
        }),
        (J = [M, x, z, S]),
        (d[9] = S),
        (d[10] = x),
        (d[11] = M),
        (d[12] = q),
        (d[13] = J))
      : ((q = d[12]), (J = d[13])),
      (0, T.useEffect)(q, J);
    let Y;
    d[14] === x
      ? (Y = d[15])
      : ((Y = async () => {
          N(`loaded`), x();
        }),
        (d[14] = x),
        (d[15] = Y));
    let X = Y,
      Z;
    d[16] !== P || d[17] !== X || d[18] !== D || d[19] !== M
      ? ((Z = (() => {
          switch (M) {
            case `loading`:
              return (0, O.jsx)(t, {
                progress: D,
                showProgress: B.showProgress,
              });
            case `error`:
              return (0, O.jsx)(C, {
                warning:
                  P && !oe(P.errorMessage)
                    ? `unity-load-failed`
                    : `unity-unavailable`,
              });
            case `fullscreen`:
              return (0, O.jsx)(C, { warning: `force-fullscreen`, close: X });
            default:
              return null;
          }
        })()),
        (d[16] = P),
        (d[17] = X),
        (d[18] = D),
        (d[19] = M),
        (d[20] = Z))
      : (Z = d[20]);
    let Q;
    d[21] === Symbol.for(`react.memo_cache_sentinel`)
      ? ((Q = (0, O.jsx)(re, {})), (d[21] = Q))
      : (Q = d[21]);
    let $;
    return (
      d[22] === Z
        ? ($ = d[23])
        : (($ = (0, O.jsxs)(O.Fragment, { children: [Z, Q] })),
          (d[22] = Z),
          (d[23] = $)),
      $
    );
  };
function A() {
  E.sendMessage({ type: `focusGame` });
}
function j() {
  E.sendMessage({ type: `focusGame` });
}
export { k as default };
//# debugId=c2c8d6c4-d722-57a5-a720-90c40b743fc8
