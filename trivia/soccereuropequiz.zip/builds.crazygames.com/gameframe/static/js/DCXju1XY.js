!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "027e7249-1612-5922-ab12-b947b2acf697"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `f057c0ac-3b9b-458a-87d6-300d1f2a91e2`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-f057c0ac-3b9b-458a-87d6-300d1f2a91e2`));
  } catch {}
})();
import {
  Ot as e,
  Xt as t,
  cn as n,
  kt as r,
  qt as i,
  rn as a,
} from "../../bundle.js";
function o() {
  if (n()) return !1;
  try {
    let e = document.createElement(`canvas`);
    return `WebGLRenderingContext` in window && !!e.getContext(`webgl2`);
  } catch {
    return !1;
  }
}
function s() {
  if (n()) return !1;
  try {
    let e = document.createElement(`canvas`);
    return (
      `WebGLRenderingContext` in window &&
      (!!e.getContext(`webgl`) || !!e.getContext(`experimental-webgl`))
    );
  } catch {
    return !1;
  }
}
function c(t) {
  let n = document.createElement(`iframe`);
  return (
    (n.id = `game-iframe`),
    (n.src = t),
    (n.style.border = `0`),
    (n.style.backgroundColor = `var(--neutral-0)`),
    (n.style.width = `10px`),
    (n.style.height = `10px`),
    (n.style.minWidth = `100%`),
    (n.style.minHeight = `100%`),
    n.setAttribute(`allow`, r({ src: t, extra: [`gamepad`] })),
    n.setAttribute(`webkitallowfullscreen`, `true`),
    n.setAttribute(`mozallowfullscreen`, `true`),
    n.setAttribute(`msallowfullscreen`, `true`),
    n.setAttribute(`allowfullscreen`, `true`),
    n.setAttribute(`sandbox`, ``),
    n.sandbox.add(...e),
    n
  );
}
function l(e, n) {
  t.getInstance().sendEvent({
    type: `gameError`,
    slug: a().gameSlug,
    errorName: e,
    errorMessage: n?.errorMessage || `webGL check failed`,
    pageVisitId: i(),
    context: n?.phase || `unity-unavailable-webgl`,
  });
}
export { l as i, o as n, s as r, c as t };
//# debugId=027e7249-1612-5922-ab12-b947b2acf697
