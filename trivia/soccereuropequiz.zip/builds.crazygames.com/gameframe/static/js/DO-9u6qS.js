!(function () {
  try {
    var e =
        "undefined" != typeof window
          ? window
          : "undefined" != typeof global
          ? global
          : "undefined" != typeof globalThis
          ? globalThis
          : "undefined" != typeof self
          ? self
          : {},
      n = new e.Error().stack;
    n &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[n] = "36d3bac8-5069-5cbf-9a6f-985e397509c6"));
  } catch (e) {}
})();
(function () {
  try {
    var e =
      typeof window < `u`
        ? window
        : typeof global < `u`
        ? global
        : typeof globalThis < `u`
        ? globalThis
        : typeof self < `u`
        ? self
        : {};
    (e._sentryModuleMetadata = e._sentryModuleMetadata || {}),
      (e._sentryModuleMetadata[new e.Error().stack] = (function (e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = arguments[t];
          if (n != null) for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r]);
        }
        return e;
      })({}, e._sentryModuleMetadata[new e.Error().stack], {
        "_sentryBundlerPluginAppKey:crazygames-gameframe": !0,
      }));
    var t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = `31e4138c-2ab0-48cb-9dd8-725b123fdce5`),
      (e._sentryDebugIdIdentifier = `sentry-dbid-31e4138c-2ab0-48cb-9dd8-725b123fdce5`));
  } catch {}
})();
import { gn as e, mt as t, un as n, wn as r, yn as i } from "../../bundle.js";
var a = n(),
  o = r(i()),
  s = e(),
  c = o.memo((e) => {
    let n = (0, a.c)(10),
      { name: r, width: i, height: o, className: c, style: l, alt: u } = e,
      d = u === void 0 ? `` : u,
      f;
    n[0] === r ? (f = n[1]) : ((f = t(r)), (n[0] = r), (n[1] = f));
    let p = d ? void 0 : !0,
      m;
    return (
      n[2] !== d ||
      n[3] !== c ||
      n[4] !== o ||
      n[5] !== l ||
      n[6] !== f ||
      n[7] !== p ||
      n[8] !== i
        ? ((m = (0, s.jsx)(`img`, {
            src: f,
            width: i,
            height: o,
            className: c,
            style: l,
            alt: d,
            "aria-hidden": p,
          })),
          (n[2] = d),
          (n[3] = c),
          (n[4] = o),
          (n[5] = l),
          (n[6] = f),
          (n[7] = p),
          (n[8] = i),
          (n[9] = m))
        : (m = n[9]),
      m
    );
  });
c.displayName = `IllustrationIcon`;
export { c as t };
//# debugId=36d3bac8-5069-5cbf-9a6f-985e397509c6
