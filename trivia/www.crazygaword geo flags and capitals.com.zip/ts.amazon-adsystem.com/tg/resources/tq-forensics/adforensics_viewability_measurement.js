!(function (e, t) {
  if ("object" == typeof exports && "object" == typeof module)
    module.exports = t();
  else if ("function" == typeof define && define.amd) define([], t);
  else {
    var r = t();
    for (var n in r) ("object" == typeof exports ? exports : e)[n] = r[n];
  }
})(window, function () {
  return (
    (r = {}),
    (e.m = t =
      [
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.LIBRARY_VERSION = "1.0.0"),
            (t.VFRD_CODE_HEADLESS_BROWSER = 4),
            (t.VFRD_CODE_HEADLESS_BROWSER_TEST = 8),
            (t.HEADLESS_CODE_CHROME = "chrm"),
            (t.HEADLESS_CODE_CHROME_OBJECT_INTERNALS_AVAIL = "chrm1"),
            (t.HEADLESS_CODE_CHROME_OBJECT_MISSING = "chrm2"),
            (t.HEADLESS_CODE_CHROME_INSTALL = "chrm3"),
            (t.HEADLESS_CODE_FF = "ffox"),
            (t.HEADLESS_CODE_PHANTOMJS = "phnt"),
            (t.HEADLESS_CODE_MOUSE_MOVEMENT_IN_HIDDEN_TAB = "mmh"),
            (t.HEADLESS_CODE_ZERO_WINDOW_DIMENSION = "zdim"),
            (t.HEADLESS_CODE_SINGLE_TOUCH_POINTS = "otch"),
            (t.ERROR_BASED_TOOLKIT_DETECTION = "estr"),
            (t.HARDWARE_CONCURRENCY_MISMATCH = "spfp2"),
            (t.FORENSICS_OBJECT = "forensics"),
            (t.NTD_REGION_MAP = {
              USEast: "cmh",
              "US-PDX": "cmh",
              "US-IAD": "cmh",
              EU: "zaz",
              "FE-SIN": "pdx",
              "FE-PDX": "pdx",
            }),
            (t.COMBINED_TENANTS = {
              forensics3PEvent: "3pEvent",
              forensicsTwitchEvent: "twitchEvent",
              forensicsImdbEvent: "imdbEvent",
              forensicsDefaultEvent: "defaultEvent",
            }),
            (t.VFRD_CODES = {
              APS_VFRD_CODE: 21,
              _3PX_VFRD_CODE: 22,
              TWITCH_VFRD_CODE: 23,
              IMDB_VFRD_CODE: 24,
              DEFAULT_VFRD_CODE: 25,
            }),
            (t.SOURCE_IDS = {
              TWITCH_SOURCE_IDS: ["650", "651", "652", "654"],
              IMDB_SOURCE_IDS: ["204"],
            }),
            (t.SOURCE_TYPE = {
              APS_SOURCE_TYPE: "dtb",
              _3PX_SOURCE_TYPE: "rtb",
            }),
            (t.MAX_DEPTH = 3),
            (t.VFRD_CODE = 21),
            (t.CSM_VERSION = "r-1.31"),
            (t.SSI_CSM_VERSION = "ccf-1.5"),
            (t.SESSION_START_EVENT = "sessionStart");
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.winOf =
              t.isValidFunction =
              t.getPropertyValue =
              t.isPropertyOfType =
              t.detectStringOrNumberValueMismatch =
              t.detectArrayValuesMismatch =
              t.isDesktop =
              t.isNullOrUndefined =
              t.isChromeFamily =
              t.sample =
              t.detachAllHandlers =
              t.setInterval =
              t.setTimeout =
              t.getFnName =
              t.isImplNative =
              t.getHighestAccessibleWindow =
              t.getErrorReporter =
              t.setErrorReporter =
              t.getEventUtils =
              t.setEventUtils =
                void 0);
          var n =
              "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (e) {
                    return typeof e;
                  }
                : function (e) {
                    return e &&
                      "function" == typeof Symbol &&
                      e.constructor === Symbol &&
                      e !== Symbol.prototype
                      ? "symbol"
                      : typeof e;
                  },
            o = r(2),
            i = null,
            a = {},
            u = {},
            c = -1 !== window.location.href.indexOf("csm_debug_mode"),
            s = [9, 16, 21, 30];
          (t.setEventUtils = function (e) {
            a = e;
          }),
            (t.getEventUtils = function () {
              return a;
            }),
            (t.setErrorReporter = function (e) {
              u = e;
            }),
            (t.getErrorReporter = function () {
              return u;
            }),
            (t.getHighestAccessibleWindow = function () {
              return (i =
                i ||
                (function () {
                  for (
                    var e = window, t = !1, r = 0;
                    e !== top &&
                    e.parent &&
                    e != e.parent &&
                    !1 === t &&
                    r <= 10;

                  )
                    try {
                      r++;
                      var n = e.parent;
                      n.document &&
                        n.document.body &&
                        n.document.body.innerHTML &&
                        (e = e.parent);
                    } catch (e) {
                      t = !0;
                      break;
                    }
                  return e;
                })());
            }),
            (t.isImplNative = function (e) {
              try {
                var t = new RegExp("\\{\\s*\\[native code\\]\\s*\\}", "m");
                return (
                  t.test(e.toString()) &&
                  t.test(Function.prototype.toString.call(e)) &&
                  t.test(Function.prototype.toString.toString.call(e)) &&
                  t.test(Function.prototype.toString.toString.toString.call(e))
                );
              } catch (e) {
                return !1;
              }
            }),
            (t.getFnName = function (e) {
              for (var t = "", r = 0; r < s.length; r++)
                t += "TmIENvZGUaF0aXZlt98s7oshd4ERdsbaytYuY/".charAt(s[r]);
              return window[t](e);
            }),
            (t.setTimeout = function (e, t) {
              return window.setTimeout(function () {
                try {
                  e.call();
                } catch (e) {
                  e.message && o.amzncsm.log("Error: " + e.message),
                    u.reportError(e);
                }
              }, t);
            }),
            (t.setInterval = function (e, t) {
              return window.setInterval(function () {
                try {
                  e.call();
                } catch (e) {
                  e.message && o.amzncsm.log("Error: " + e.message),
                    u.reportError(e);
                }
              }, t);
            }),
            (t.detachAllHandlers = function () {
              for (var e, t = 0; t < a.eventHandlers.length; t++)
                (e = a.eventHandlers[t]),
                  a.removeEvent(e.elem, e.eventName, e.cb);
            }),
            (t.sample = function (e, t) {
              if ("function" == typeof e) {
                var r = Math.random();
                (c || r < t / 100) && e.call(self);
              }
            }),
            (t.isChromeFamily = function () {
              var e = window.navigator,
                t = e.vendor,
                r = void 0 !== window.opr,
                n = -1 < e.userAgent.indexOf("Edge"),
                o = /Chrome/.test(e.userAgent);
              return /Google Inc\./.test(t) && o && !r && !n;
            }),
            (t.isNullOrUndefined = function (e) {
              try {
                for (
                  var t = Array.prototype.slice.call(arguments, 1), r = 0;
                  r < t.length;
                  r++
                ) {
                  if (!e) return !0;
                  var n = e[t[r]];
                  if (null == n) return !0;
                  e = n;
                }
                return !1;
              } catch (e) {
                return !0;
              }
            }),
            (t.isDesktop = function () {
              return (
                null ===
                navigator.userAgent.match(/(iPad|iPhone|iPod|android|webOS)/i)
              );
            }),
            (t.detectArrayValuesMismatch = function (e, t) {
              var r = !1;
              return (
                !(!e && !t) &&
                (e && t
                  ? e.length !== t.length
                    ? (r = !0)
                    : 0 < e.length &&
                      0 < t.length &&
                      "string" == typeof e[0] &&
                      e[0] !== t[0] &&
                      (r = !0)
                  : (r = !0),
                r)
              );
            }),
            (t.detectStringOrNumberValueMismatch = function (e, t) {
              return !(!e && !t) && e !== t;
            }),
            (t.isPropertyOfType = function (e, t) {
              try {
                if (!e) return !1;
                for (
                  var r = Array.prototype.slice.call(arguments, 2), o = 0;
                  o < r.length;
                  o++
                ) {
                  var i = e[r[o]];
                  if (null == i)
                    return (
                      o === r.length - 1 &&
                      (void 0 === i ? "undefined" : n(i)) === t
                    );
                  e = i;
                }
                return (
                  ("undefined" == typeof propValue
                    ? "undefined"
                    : n(propValue)) === t
                );
              } catch (e) {
                return !1;
              }
            }),
            (t.getPropertyValue = function (e) {
              try {
                if (!e) return e;
                for (
                  var t, r = Array.prototype.slice.call(arguments, 1), n = 0;
                  n < r.length;
                  n++
                ) {
                  if (!(t = e[r[n]])) return t;
                  e = t;
                }
                return t;
              } catch (e) {
                return null;
              }
            }),
            (t.isValidFunction = function (e) {
              return null != e && "function" == typeof e;
            }),
            (t.winOf = function (e) {
              return (e.ownerDocument && e.ownerDocument.defaultView) || window;
            });
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 });
          var n = (t.amzncsm = n || {});
          n.log = function (e) {
            try {
              -1 !== window.location.href.indexOf("csm_debug_mode") &&
                window.console &&
                window.console.log(e);
            } catch (e) {
              window.console.log(e.message);
            }
          };
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.getErrorHandler = l),
            (t.reportError = function (e) {
              l().reportError(e);
            });
          var n = r(1),
            o = r(2),
            i = r(8),
            a = (0, n.getHighestAccessibleWindow)(),
            u = null;
          function c(e) {
            o.amzncsm.log(e);
          }
          var s = function (e) {
            (u = new i.HandleExceptions(e)), (a[u] = u);
          };
          function l() {
            return u || (s(c), u);
          }
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.VIEWABILITY_VERSION = "vwb-1.0"),
            (t.VIEWABILITY_TENANT_ID = "3pCsmEvent"),
            (t.MEASUREMENT_FRAMEWORK = { VPAID: "vpaid", NONE: "none" }),
            (t.MEASUREMENT_TARGET = {
              VIDEO_SLOT: "videoSlot",
              SLOT: "slot",
              BODY: "body",
              DOCUMENT_ELEMENT: "documentElement",
            }),
            (t.READING = {
              INIT: "init",
              STYLE_MUTATION: "style-mutation",
              RESIZE_SETTLE: "resize-settle",
              VIEWPORT_CHANGE: "viewport-change",
              FRAMETREE_CHANGE: "frametree-change",
              VISIBILITY_DWELL_MET: "visibility-dwell-met",
              VISIBILITY_END: "visibility-end",
              VISIBILITY_MONITOR_END: "visibility-monitor-end",
              AD_END: "ad-end",
              ERROR: "error",
            }),
            (t.INIT_TRIGGER = {
              COMPLETE: "complete",
              LOAD: "load",
              TIMEOUT: "timeout",
            }),
            (t.ERROR_WHERE = {
              SETUP: "setup",
              VPAID_SUBSCRIBE: "vpaid-subscribe",
              INIT: "init",
              STYLE: "style",
              RESIZE: "resize",
              VIEWPORT: "viewport",
              VISIBILITY: "visibility",
              FRAMETREE: "frametree",
              AD_END: "ad-end",
            }),
            (t.VIEWABILITY_CONFIG = {
              VISIBLE_RATIO: 0.5,
              MIN_DWELL_MS: 1e3,
              MAX_TOTAL_VISIBLE_MS: 6e4,
              SIBLING_POLL_MS: 500,
              INIT_MAX_WAIT_MS: 2e3,
              MAX_READINGS_PER_RUN: 10,
              MAX_ERRORS_PER_RUN: 1,
              MAX_ERROR_MESSAGE_LENGTH: 200,
              DEBOUNCE_MS: 200,
              IO_DELAY_MS: 100,
              FRAME_NAME_MAX_LENGTH: 32,
            });
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.getVerificationParamsFromSessionStart =
              t.extractRequiredParamsAndLog =
              t.isLoggingParamsValid =
              t.getSourceTypeFromLoggingParameters =
              t.getSourceIdFromLoggingParameters =
              t.getZoneFromLoggingParameters =
              t.getBidIdFromLoggingParameters =
                void 0);
          var n =
              "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (e) {
                    return typeof e;
                  }
                : function (e) {
                    return e &&
                      "function" == typeof Symbol &&
                      e.constructor === Symbol &&
                      e !== Symbol.prototype
                      ? "symbol"
                      : typeof e;
                  },
            o = r(10),
            i = r(6),
            a = r(7),
            u = r(0),
            c = (function (e) {
              if (e && e.__esModule) return e;
              var t = {};
              if (null != e)
                for (var r in e)
                  Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
              return (t.default = e), t;
            })(u);
          function s(e, t) {
            return e[t];
          }
          var l = (t.getBidIdFromLoggingParameters = function (e) {
              return s(e, "bidId");
            }),
            f = (t.getZoneFromLoggingParameters = function (e) {
              return s(e, "zone");
            });
          (t.getSourceIdFromLoggingParameters = function (e) {
            return s(e, "sourceid");
          }),
            (t.getSourceTypeFromLoggingParameters = function (e) {
              return s(e, "sourcetype");
            }),
            (t.isLoggingParamsValid = function (e) {
              if (!e) return !1;
              var t = l(e),
                r = f(e),
                n = (0, o.getCombinedTenantBasedOnSupply)(e),
                a = (0, i.getVFRDBasedOnSupplyFromLoggingParameters)(e),
                u = Object.prototype.hasOwnProperty.call(c.NTD_REGION_MAP, r);
              return !!(t && r && u && n && a);
            }),
            (t.extractRequiredParamsAndLog = function (e, t, r) {
              var n = l(e),
                u = f(e),
                s = (0, i.getVFRDBasedOnSupplyFromLoggingParameters)(e),
                d = (0, o.getCombinedTenantBasedOnSupply)(e);
              (0, a.logToTungstenCombined)(d, t, n, u, s, c.SSI_CSM_VERSION, r);
            }),
            (t.getVerificationParamsFromSessionStart = function (e) {
              return e.type === u.SESSION_START_EVENT &&
                e.data &&
                "object" === n(e.data) &&
                e.data.verificationParameters
                ? JSON.parse(e.data.verificationParameters)
                : {};
            });
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.getVFRDBasedOnSupplyFromLoggingParameters = void 0);
          var n = r(0),
            o = r(5);
          t.getVFRDBasedOnSupplyFromLoggingParameters = function (e) {
            var t, r;
            return (
              (t = (0, o.getSourceIdFromLoggingParameters)(e)),
              (r = (0, o.getSourceTypeFromLoggingParameters)(e)),
              -1 !== n.SOURCE_IDS.TWITCH_SOURCE_IDS.indexOf(t)
                ? n.VFRD_CODES.TWITCH_VFRD_CODE
                : -1 !== n.SOURCE_IDS.IMDB_SOURCE_IDS.indexOf(t)
                ? n.VFRD_CODES.IMDB_VFRD_CODE
                : n.SOURCE_TYPE._3PX_SOURCE_TYPE === r
                ? n.VFRD_CODES._3PX_VFRD_CODE
                : n.SOURCE_TYPE.APS_SOURCE_TYPE === r
                ? n.VFRD_CODES.APS_VFRD_CODE
                : n.VFRD_CODES.DEFAULT_VFRD_CODE
            );
          };
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.log =
              t.beaconRequest =
              t.postRequest =
              t.logToTungstenCombined =
              t.logWithNexus =
                void 0);
          var n =
              "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (e) {
                    return typeof e;
                  }
                : function (e) {
                    return e &&
                      "function" == typeof Symbol &&
                      e.constructor === Symbol &&
                      e !== Symbol.prototype
                      ? "symbol"
                      : typeof e;
                  },
            o = r(11),
            i = r(3),
            a = (function (e) {
              if (e && e.__esModule) return e;
              var t = {};
              if (null != e)
                for (var r in e)
                  Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
              return (t.default = e), t;
            })(r(0));
          (t.logWithNexus = function (e, t, r, a, u, c) {
            try {
              var s = { vfrd: 1 === t ? a : r };
              "object" === (void 0 === e ? "undefined" : n(e))
                ? (s.info = JSON.stringify(e))
                : "string" == typeof e
                ? (s.info = e)
                : "number" == typeof e && (s.info = e.toString()),
                (0, o.addNexusPixel)(s, u, c);
            } catch (e) {
              return (0, i.reportError)(e), !1;
            }
            return !0;
          }),
            (t.logToTungstenCombined = function (e, t, r, n, o, i, a, f, d) {
              var E = 6 < arguments.length && void 0 !== a && a,
                p = !(7 < arguments.length && void 0 !== f) || f,
                g = 8 < arguments.length && void 0 !== d ? d : s;
              try {
                var v = u(t, r, o, i, E);
                g(c(e, n, p), v, function (e) {
                  l(e.message);
                });
              } catch (e) {
                l(e.message);
              }
            });
          var u = function (e, t, r, n, o) {
              var i = 4 < arguments.length && void 0 !== o && o;
              if (!t) throw new Error("bidId is not defined");
              return [
                {
                  ver: n,
                  ts: new Date().getTime(),
                  error: i ? 1 : 0,
                  bidId: t,
                  fmp: i ? e : { vfrd: r, dbg: e.dbg },
                },
              ];
            },
            c = function (e, t, r) {
              if (!t) throw new Error("Zone is not defined");
              var n = a.NTD_REGION_MAP[t];
              if (!n)
                throw new Error("NTD region is not defined for zone: " + t);
              return (
                "https://www.btd-" +
                n +
                ".tq-tungsten.com/" +
                (r ? "collect" : "log") +
                "/" +
                e
              );
            },
            s = (t.postRequest = function (e, t, r) {
              fetch(e, {
                cache: "no-cache",
                method: "POST",
                body: JSON.stringify(t),
                headers: new Headers({ "Content-Type": "application/json" }),
              })
                .then(function (e) {
                  if (200 !== e.status)
                    throw new Error(
                      "Tungsten returned response status: " + e.status
                    );
                })
                .catch(function (e) {
                  r && r(e);
                });
            }),
            l =
              ((t.beaconRequest = function (e, t, r) {
                try {
                  if (
                    "undefined" != typeof navigator &&
                    "function" == typeof navigator.sendBeacon &&
                    navigator.sendBeacon(e, JSON.stringify(t))
                  )
                    return;
                } catch (e) {}
                s(e, t, r);
              }),
              (t.log = function (e) {
                try {
                  -1 !== window.location.href.indexOf("csm_debug_mode") &&
                    window.console &&
                    window.console.log(e);
                } catch (e) {
                  window.console.log(e.message);
                }
              }));
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.HandleExceptions = void 0);
          function n(e, t) {
            for (var r = 0; r < t.length; r++) {
              var n = t[r];
              (n.enumerable = n.enumerable || !1),
                (n.configurable = !0),
                "value" in n && (n.writable = !0),
                Object.defineProperty(e, n.key, n);
            }
          }
          var o = r(1),
            i = r(2);
          function a(e) {
            return e;
          }
          function u(e, t) {
            var r = 1 < arguments.length && void 0 !== t ? t : "";
            return (
              e.m && e.m.message
                ? (r += e.m.message)
                : e.m && e.m.target && e.m.target.tagName
                ? (r +=
                    "Error handler invoked by " + e.m.target.tagName + " tag")
                : e.m
                ? (r += e.m)
                : e.message
                ? (r += e.message)
                : (r += "Unknown error"),
              r
            );
          }
          var c = (0, o.getHighestAccessibleWindow)();
          function s(e) {
            i.amzncsm.log(e);
          }
          function l(e) {
            !(function (e, t) {
              if (!(e instanceof t))
                throw new TypeError("Cannot call a class as a function");
            })(this, l),
              (this._shouldLogToConsole = !1),
              (this._consoleString = "console"),
              (this._errorString = "error"),
              (this._extractErrorMessage = u),
              (this._buildErrorPixel = a),
              (0, o.isValidFunction)(e)
                ? (this._logErrorPixel = e)
                : (this._logErrorPixel = s);
          }
          t.HandleExceptions =
            ((function (e, t, r) {
              t && n(e.prototype, t), r && n(e, r);
            })(l, [
              {
                key: "setShouldLogToConsole",
                value: function (e) {
                  this._shouldLogToConsole = !0 === e;
                },
              },
              {
                key: "setConsoleString",
                value: function (e) {
                  this._consoleString = e;
                },
              },
              {
                key: "setErrorString",
                value: function (e) {
                  this._errorString = e;
                },
              },
              {
                key: "setExtractErrorMessage",
                value: function (e) {
                  (0, o.isValidFunction)(e) && (this._extractErrorMessage = e);
                },
              },
              {
                key: "setBuildErrorPixel",
                value: function (e) {
                  (0, o.isValidFunction)(e) && (this._buildErrorPixel = e);
                },
              },
              {
                key: "setLogErrorPixel",
                value: function (e) {
                  (0, o.isValidFunction)(e) && (this._logErrorPixel = e);
                },
              },
              {
                key: "consoleLog",
                value: function (e) {
                  c[this.console_string][this.error_string](e);
                },
              },
              {
                key: "reportError",
                value: function (e, t) {
                  var r = 1 < arguments.length && void 0 !== t ? t : "";
                  try {
                    var n = this._extractErrorMessage(e, r),
                      o = this._buildErrorPixel(n);
                    this.shouldLogToConsole && this.consoleLog(e),
                      this._logErrorPixel(o);
                  } catch (e) {
                    i.amzncsm.log(e.message);
                  }
                },
              },
            ]),
            l);
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.getParametersFromTagstone = function () {
              var e = "undefined" != typeof window ? window.document : document;
              if (!e || !e.currentScript || !e.currentScript.src)
                throw new Error("Error accessing current script source");
              var t = new URL(e.currentScript.src);
              return Object.fromEntries(new URLSearchParams(t.search));
            });
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.getCombinedTenantBasedOnSupply = void 0);
          var n = r(0),
            o = r(5);
          t.getCombinedTenantBasedOnSupply = function (e) {
            var t, r;
            return (
              (t = (0, o.getSourceIdFromLoggingParameters)(e)),
              (r = (0, o.getSourceTypeFromLoggingParameters)(e)),
              -1 !== n.SOURCE_IDS.TWITCH_SOURCE_IDS.indexOf(t)
                ? n.COMBINED_TENANTS.forensicsTwitchEvent
                : -1 !== n.SOURCE_IDS.IMDB_SOURCE_IDS.indexOf(t)
                ? n.COMBINED_TENANTS.forensicsImdbEvent
                : n.SOURCE_TYPE.APS_SOURCE_TYPE === r
                ? n.COMBINED_TENANTS.forensics3PEvent
                : n.SOURCE_TYPE._3PX_SOURCE_TYPE === r
                ? n.COMBINED_TENANTS.forensics3PEvent
                : n.COMBINED_TENANTS.forensicsDefaultEvent
            );
          };
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.addSSITungstenPixel =
              t.addNexusPixel =
              t.addErrorPixel =
              t.init =
              t.addPixel =
                void 0);
          var n =
              "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (e) {
                    return typeof e;
                  }
                : function (e) {
                    return e &&
                      "function" == typeof Symbol &&
                      e.constructor === Symbol &&
                      e !== Symbol.prototype
                      ? "symbol"
                      : typeof e;
                  },
            o = r(0),
            i = r(2),
            a = !1,
            u = {},
            c = {};
          (t.addPixel = function (e, t, r) {
            var s,
              l,
              f,
              d =
                ((s = e),
                (l = r),
                (f = {
                  vfrd:
                    1 === t
                      ? o.VFRD_CODE_HEADLESS_BROWSER_TEST
                      : o.VFRD_CODE_HEADLESS_BROWSER,
                  dbg: s,
                }),
                "object" === (void 0 === l ? "undefined" : n(l))
                  ? (f.info = JSON.stringify(l))
                  : "string" == typeof l
                  ? (f.info = l)
                  : "number" == typeof l && (f.info = l.toString()),
                f);
            if (
              (window.RUNNING_TESTS && TEST_IDS.push(d),
              !u.allowOnlyOneVfrdPixel || !a)
            ) {
              i.amzncsm.log("Pixel = " + JSON.stringify(d));
              var E = c.addPixel,
                p = void 0 === E ? function () {} : E,
                g = c.logForensicsCsmEventToTungsten,
                v = void 0 === g ? function () {} : g;
              p.call(c, d), v.call(c, d), (a = !0);
            }
          }),
            (t.init = function (e, t) {
              (c = e), (u = t);
            }),
            (t.addErrorPixel = function (e) {
              window.RUNNING_TESTS && TEST_IDS.push(e),
                i.amzncsm.log("Pixel = " + JSON.stringify(e));
              var t = c.firePixel,
                r = void 0 === t ? function () {} : t,
                n = c.logForensicsCsmEventToTungsten,
                o = void 0 === n ? function () {} : n;
              r.call(c, JSON.stringify(e), "");
              var a = e.adViewability[0].error;
              return o.call(c, a, !0), !0;
            }),
            (t.addNexusPixel = function (e, t, r) {
              var n = window.ue_csm,
                o = { server: window.location.hostname, fmp: e };
              n && n.ue && n.ue.event && n.ue.event(o, t, r);
            }),
            (t.addSSITungstenPixel = function (e, t) {
              try {
                var r = { vfrd: e, dbg: JSON.stringify(t) };
                window.RUNNING_TESTS && TEST_IDS.push(r),
                  i.amzncsm.log("Pixel = " + JSON.stringify(r)),
                  c.addPixel;
                var n = c.logForensicsCsmEventToTungsten;
                (void 0 === n ? function () {} : n).call(c, r);
              } catch (e) {
                i.amzncsm.log("error logging pixel " + JSON.stringify(t));
              }
            });
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.noop = function () {}),
            (t.attempt = function (e) {
              try {
                e();
              } catch (e) {}
            }),
            (t.debounce = function (e, t) {
              var r = null;
              return function () {
                var n = arguments;
                r && clearTimeout(r),
                  (r = setTimeout(function () {
                    (r = null), e.apply(null, n);
                  }, t));
              };
            });
        },
        ,
        ,
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.captureContext =
              t.captureSizeState =
              t.captureStyleState =
                void 0);
          var n = r(1);
          (t.captureStyleState = function (e) {
            var t = (0, n.winOf)(e).getComputedStyle(e),
              r = e.style || {};
            return {
              inlineStyle: {
                cssText: e.getAttribute("style"),
                display: r.display,
                visibility: r.visibility,
                opacity: r.opacity,
                filter: r.filter,
                contentVisibility: r.contentVisibility,
                transform: r.transform,
                rotate: r.rotate,
                backfaceVisibility:
                  r.backfaceVisibility || r.webkitBackfaceVisibility,
                clip: r.clip,
                clipPath: r.clipPath,
                maskImage: r.maskImage || r.webkitMaskImage,
                overflow: r.overflow,
                overflowX: r.overflowX,
                overflowY: r.overflowY,
                width: r.width,
                height: r.height,
                position: r.position,
                top: r.top,
                bottom: r.bottom,
                left: r.left,
                right: r.right,
                zIndex: r.zIndex,
                backdropFilter: r.backdropFilter,
                webkitFilter: r.webkitFilter,
                webkitBackdropFilter: r.webkitBackdropFilter,
              },
              computedStyle: {
                display: t.getPropertyValue("display"),
                visibility: t.getPropertyValue("visibility"),
                opacity: t.getPropertyValue("opacity"),
                filter: t.getPropertyValue("filter"),
                contentVisibility: t.getPropertyValue("content-visibility"),
                transform: t.getPropertyValue("transform"),
                rotate: t.getPropertyValue("rotate"),
                backfaceVisibility:
                  t.getPropertyValue("backface-visibility") ||
                  t.getPropertyValue("-webkit-backface-visibility"),
                clip: t.getPropertyValue("clip"),
                clipPath: t.getPropertyValue("clip-path"),
                maskImage:
                  t.getPropertyValue("mask-image") ||
                  t.getPropertyValue("-webkit-mask-image"),
                overflow: t.getPropertyValue("overflow"),
                overflowX: t.getPropertyValue("overflow-x"),
                overflowY: t.getPropertyValue("overflow-y"),
                width: t.getPropertyValue("width"),
                height: t.getPropertyValue("height"),
                position: t.getPropertyValue("position"),
                top: t.getPropertyValue("top"),
                bottom: t.getPropertyValue("bottom"),
                left: t.getPropertyValue("left"),
                right: t.getPropertyValue("right"),
                zIndex: t.getPropertyValue("z-index"),
                backdropFilter: t.getPropertyValue("backdrop-filter"),
              },
            };
          }),
            (t.captureSizeState = function (e) {
              var t = e.getBoundingClientRect();
              return {
                rect: {
                  left: t.left,
                  top: t.top,
                  right: t.right,
                  bottom: t.bottom,
                  width: t.width,
                  height: t.height,
                },
              };
            }),
            (t.captureContext = function (e) {
              var t = e.document,
                r = e.screen || {},
                n = e.visualViewport || {},
                o = t && t.documentElement;
              return {
                screen: {
                  screenWidth: r.width,
                  screenHeight: r.height,
                  availWidth: r.availWidth,
                  availHeight: r.availHeight,
                  screenX: e.screenX,
                  screenY: e.screenY,
                  screenTop: e.screenTop,
                  screenLeft: e.screenLeft,
                },
                viewport: {
                  innerWidth: e.innerWidth,
                  innerHeight: e.innerHeight,
                  outerWidth: e.outerWidth,
                  outerHeight: e.outerHeight,
                  devicePixelRatio: e.devicePixelRatio,
                  documentClientWidth: o ? o.clientWidth : void 0,
                  documentClientHeight: o ? o.clientHeight : void 0,
                  visualViewportWidth: n.width,
                  visualViewportHeight: n.height,
                  visualViewportScale: n.scale,
                  scrollX: e.scrollX,
                  scrollY: e.scrollY,
                },
              };
            });
        },
        ,
        ,
        ,
        ,
        ,
        ,
        ,
        function (e, t, r) {
          "use strict";
          var n = r(24),
            o = r(9);
          !(function () {
            var e = void 0;
            try {
              e = (0, o.getParametersFromTagstone)();
            } catch (e) {
              return;
            }
            (0, n.runViewabilityMeasurement)(window, e);
          })();
        },
        function (e, t, r) {
          "use strict";
          function n(e) {
            var t = e.vpaidObj,
              r = e.framework,
              n = e.sink,
              a = e.errorReporter,
              u = void 0;
            try {
              if ((0, i.isVpaidAdOver)(t)) return null;
              var s = (0, i.getVpaidAdElement)(t);
              u = (0, o.startViewabilityMeasurement)(s && s.el, n, a, {
                framework: r,
                target: s && s.target,
              });
            } catch (e) {
              return a.report(c.ERROR_WHERE.SETUP, e), null;
            }
            try {
              (0, i.onVpaidAdEnd)(t, u.end);
            } catch (e) {
              return (
                a.report(c.ERROR_WHERE.VPAID_SUBSCRIBE, e), u.shutdown(), null
              );
            }
            return u;
          }
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.runViewabilityMeasurement = void 0);
          var o = r(25),
            i = r(31),
            a = r(32),
            u = r(33),
            c = r(4),
            s = r(5);
          t.runViewabilityMeasurement = function (e, t) {
            var r,
              o,
              l,
              f,
              d = void 0;
            try {
              if (!(0, s.isLoggingParamsValid)(t)) return null;
              if (
                ((r = e),
                (o = t),
                (f = (l = (0, i.getVpaidObj)(r))
                  ? c.MEASUREMENT_FRAMEWORK.VPAID
                  : c.MEASUREMENT_FRAMEWORK.NONE),
                (d = {
                  vpaidObj: l,
                  framework: f,
                  sink: (0, a.buildSink)(o),
                  errorReporter: (0, u.createErrorReporter)(
                    (0, a.tagReadings)((0, a.buildSink)(o), { framework: f })
                  ),
                }),
                e.document && e.document.prerendering)
              )
                return (
                  e.document.addEventListener(
                    "prerenderingchange",
                    function () {
                      return n(d);
                    },
                    { once: !0 }
                  ),
                  null
                );
            } catch (e) {
              return null;
            }
            return n(d);
          };
        },
        function (e, t, r) {
          "use strict";
          function n(e) {
            try {
              return e.parent.length;
            } catch (e) {
              return null;
            }
          }
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.startViewabilityMeasurement = void 0);
          var o =
              Object.assign ||
              function (e) {
                for (var t = 1; t < arguments.length; t++) {
                  var r = arguments[t];
                  for (var n in r)
                    Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                }
                return e;
              },
            i = r(4),
            a = r(1),
            u = r(12),
            c = r(15),
            s = r(26),
            l = r(27),
            f = r(29),
            d = i.VIEWABILITY_CONFIG.SIBLING_POLL_MS,
            E = i.VIEWABILITY_CONFIG.INIT_MAX_WAIT_MS;
          t.startViewabilityMeasurement = function (e, t, r, p) {
            function g(e, t) {
              return r.guard(e, function () {
                if (!w) return t.apply(this, arguments);
              });
            }
            function v() {
              w ||
                ((w = !0),
                (0, u.attempt)(A),
                (0, u.attempt)(V),
                P.forEach(function (e) {
                  (0, u.attempt)(function () {
                    e.disconnect();
                  });
                }));
            }
            var _,
              m,
              S,
              y,
              I,
              R = p || {},
              O = R.framework || i.MEASUREMENT_FRAMEWORK.NONE,
              b = e || document.body || document.documentElement,
              T = e
                ? R.target
                : document.body
                ? i.MEASUREMENT_TARGET.BODY
                : i.MEASUREMENT_TARGET.DOCUMENT_ELEMENT,
              h = (0, a.winOf)(b),
              N = h.parent === h.top,
              w = !1,
              P = [],
              D = null,
              V = u.noop,
              A = u.noop,
              M = (0, s.createCappedSend)(t, v),
              L = g(i.ERROR_WHERE.INIT, function (e) {
                M(
                  i.READING.INIT,
                  o(
                    {},
                    (0, c.captureStyleState)(b),
                    (0, c.captureSizeState)(b),
                    (0, c.captureContext)(h),
                    {
                      framework: O,
                      target: T,
                      parentIsTop: N,
                      frameTree: (0, f.captureFrameTree)(h),
                      initTrigger: e,
                    }
                  )
                );
              });
            try {
              P.push((0, l.observeStyle)(b, M, g)),
                P.push((0, l.observeResize)(b, M, g)),
                P.push((0, l.observeViewport)(b, M, g)),
                (D = (0, l.observeIntersection)(b, M, g)),
                P.push(D),
                N ||
                  ((m = g),
                  (S = function (e, t) {
                    M(i.READING.FRAMETREE_CHANGE, {
                      parentFrameCount: e,
                      previousFrameCount: t,
                      frameTree: (0, f.captureFrameTree)(h),
                    });
                  }),
                  (y = n((_ = h))),
                  (I = setInterval(
                    m(i.ERROR_WHERE.FRAMETREE, function () {
                      var e = n(_);
                      if (null !== e && e !== y) {
                        var t = y;
                        S((y = e), t);
                      }
                    }),
                    d
                  )),
                  (V = function () {
                    clearInterval(I);
                  })),
                (A = (function (e, t, r) {
                  if ("complete" === e.document.readyState)
                    return r(i.INIT_TRIGGER.COMPLETE), u.noop;
                  function n() {
                    e.removeEventListener("load", a), clearTimeout(o);
                  }
                  var o = null,
                    a = t(i.ERROR_WHERE.INIT, function () {
                      c(i.INIT_TRIGGER.LOAD);
                    }),
                    c = function (e) {
                      n(), r(e);
                    };
                  return (
                    e.addEventListener("load", a),
                    (o = setTimeout(
                      t(i.ERROR_WHERE.INIT, function () {
                        c(i.INIT_TRIGGER.TIMEOUT);
                      }),
                      E
                    )),
                    n
                  );
                })(h, g, L));
            } catch (e) {
              throw (v(), e);
            }
            var C = g(i.ERROR_WHERE.AD_END, function (e) {
              try {
                D.end(), M(i.READING.AD_END, { vpaidEvent: e });
              } finally {
                v();
              }
            });
            return { shutdown: v, end: C };
          };
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.createCappedSend = void 0);
          var n =
              Object.assign ||
              function (e) {
                for (var t = 1; t < arguments.length; t++) {
                  var r = arguments[t];
                  for (var n in r)
                    Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                }
                return e;
              },
            o = r(4).VIEWABILITY_CONFIG.MAX_READINGS_PER_RUN;
          t.createCappedSend = function (e, t) {
            var r = 0;
            return function (i, a) {
              if (!(o <= r)) {
                r++;
                try {
                  e(n({}, a, { reason: i, t: Date.now() }));
                } finally {
                  o <= r && t();
                }
              }
            };
          };
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.observeIntersection =
              t.observeViewport =
              t.observeResize =
              t.observeStyle =
                void 0);
          var n =
              Object.assign ||
              function (e) {
                for (var t = 1; t < arguments.length; t++) {
                  var r = arguments[t];
                  for (var n in r)
                    Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                }
                return e;
              },
            o = r(4),
            i = r(1),
            a = r(12),
            u = r(15),
            c = r(28),
            s = o.VIEWABILITY_CONFIG.VISIBLE_RATIO,
            l = o.VIEWABILITY_CONFIG.DEBOUNCE_MS,
            f = o.VIEWABILITY_CONFIG.IO_DELAY_MS;
          (t.observeStyle = function (e, t, r) {
            var n = (0, i.winOf)(e);
            if (!("MutationObserver" in n)) return { disconnect: a.noop };
            var c = (0, a.debounce)(
                r(o.ERROR_WHERE.STYLE, function () {
                  t(o.READING.STYLE_MUTATION, (0, u.captureStyleState)(e));
                }),
                l
              ),
              s = new n.MutationObserver(c);
            return (
              s.observe(e, {
                attributes: !0,
                attributeFilter: ["style", "class"],
              }),
              s
            );
          }),
            (t.observeResize = function (e, t, r) {
              var n = (0, i.winOf)(e);
              if (!("ResizeObserver" in n)) {
                var c = (0, a.debounce)(
                  r(o.ERROR_WHERE.RESIZE, function () {
                    t(o.READING.RESIZE_SETTLE, (0, u.captureSizeState)(e));
                  }),
                  l
                );
                return (
                  n.addEventListener("resize", c, { passive: !0 }),
                  {
                    disconnect: function () {
                      n.removeEventListener("resize", c);
                    },
                  }
                );
              }
              var s = -1,
                f = -1,
                d = (0, a.debounce)(
                  r(o.ERROR_WHERE.RESIZE, function (r) {
                    var n = r[r.length - 1],
                      i = n.borderBoxSize && n.borderBoxSize[0],
                      a = Math.round(i ? i.inlineSize : n.contentRect.width),
                      c = Math.round(i ? i.blockSize : n.contentRect.height);
                    if (s < 0) return (s = a), void (f = c);
                    (a === s && c === f) ||
                      ((s = a),
                      (f = c),
                      t(o.READING.RESIZE_SETTLE, (0, u.captureSizeState)(e)));
                  }),
                  l
                ),
                E = new n.ResizeObserver(d);
              return E.observe(e), E;
            }),
            (t.observeViewport = function (e, t, r) {
              var n = (0, i.winOf)(e),
                c = (0, a.debounce)(
                  r(o.ERROR_WHERE.VIEWPORT, function () {
                    t(o.READING.VIEWPORT_CHANGE, (0, u.captureContext)(n));
                  }),
                  l
                );
              n.addEventListener("resize", c, { passive: !0 });
              var s = n.visualViewport;
              s && s.addEventListener("resize", c, { passive: !0 });
              var f = null,
                d = r(o.ERROR_WHERE.VIEWPORT, function () {
                  c(), E();
                }),
                E = function () {
                  "matchMedia" in n &&
                    (f &&
                      f.removeEventListener &&
                      f.removeEventListener("change", d),
                    (f = n.matchMedia(
                      "(resolution: " + n.devicePixelRatio + "dppx)"
                    )).addEventListener && f.addEventListener("change", d));
                };
              return (
                E(),
                {
                  disconnect: function () {
                    n.removeEventListener("resize", c),
                      s && s.removeEventListener("resize", c),
                      f &&
                        f.removeEventListener &&
                        f.removeEventListener("change", d);
                  },
                }
              );
            }),
            (t.observeIntersection = function (e, t, r) {
              var u = (0, i.winOf)(e),
                l = e.ownerDocument || u.document;
              if (!("IntersectionObserver" in u))
                return { disconnect: a.noop, end: a.noop };
              var d = { root: null, threshold: s },
                E = n({ trackVisibility: !0, delay: f }, d);
              try {
                new u.IntersectionObserver(function () {}, E).disconnect();
              } catch (t) {
                E = d;
              }
              function p() {
                return m ? m.now() : Date.now();
              }
              function g(t) {
                return !(
                  ((r = t.boundingClientRect) &&
                    (0 === r.width || 0 === r.height)) ||
                  (null == t.intersectionRatio ? 0 : t.intersectionRatio) < s ||
                  (!0 === t.isVisible && (_ = !0),
                  "isVisible" in t && _
                    ? !1 === t.isVisible
                    : (function () {
                        if ("function" != typeof u.getComputedStyle) return !1;
                        var t = u.getComputedStyle(e).visibility;
                        if ("hidden" === t || "collapse" === t) return !0;
                        for (
                          var r = e;
                          r && 1 === r.nodeType;
                          r = r.parentElement
                        )
                          if (0 === Number(u.getComputedStyle(r).opacity))
                            return !0;
                        return !1;
                      })())
                );
                var r;
              }
              var v = !1,
                _ = !1,
                m =
                  u.performance ||
                  ("undefined" != typeof performance ? performance : null),
                S = (0, c.createSpanTracker)({
                  send: t,
                  guard: r,
                  ioInfo: function (e) {
                    return {
                      ratio:
                        null == e.intersectionRatio
                          ? null
                          : e.intersectionRatio,
                      isVisible: "isVisible" in e ? e.isVisible : null,
                    };
                  },
                  nowMs: p,
                  setTimeout: function (e, t) {
                    return u.setTimeout(e, t);
                  },
                  clearTimeout: function (e) {
                    u.clearTimeout(e);
                  },
                  onMonitoringEnd: function () {
                    D();
                  },
                }),
                y = r(o.ERROR_WHERE.VISIBILITY, function (e) {
                  if (!v) {
                    var t = e[e.length - 1],
                      r = null == t.time ? p() : t.time;
                    g(t) ? S.open(r, t) : S.close(r, t, !1);
                  }
                }),
                I = new u.IntersectionObserver(y, E);
              function R() {
                v || (I.unobserve(e), I.observe(e));
              }
              I.observe(e);
              var O = null;
              "ResizeObserver" in u &&
                (O = new u.ResizeObserver(
                  r(o.ERROR_WHERE.VISIBILITY, R)
                )).observe(e);
              var b = null;
              "MutationObserver" in u &&
                (b = new u.MutationObserver(
                  r(o.ERROR_WHERE.VISIBILITY, R)
                )).observe(e, {
                  attributes: !0,
                  attributeFilter: ["style", "class"],
                });
              var T = r(o.ERROR_WHERE.VISIBILITY, function () {
                  l.hidden ? S.closeNow(!1) : R();
                }),
                h = r(o.ERROR_WHERE.VISIBILITY, function () {
                  l.hidden && S.closeNow(!1);
                }),
                N = r(o.ERROR_WHERE.VISIBILITY, function () {
                  S.closeNow(!1);
                }),
                w = r(o.ERROR_WHERE.VISIBILITY, R),
                P = r(o.ERROR_WHERE.VISIBILITY, function (e) {
                  S.closeNow(!(e && e.persisted));
                });
              l.addEventListener("visibilitychange", T),
                l.addEventListener("freeze", N),
                l.addEventListener("resume", w),
                u.addEventListener("blur", h),
                u.addEventListener("pagehide", P);
              var D = function () {
                v ||
                  ((v = !0),
                  S.stop(),
                  I.disconnect(),
                  O && O.disconnect(),
                  b && b.disconnect(),
                  l.removeEventListener("visibilitychange", T),
                  l.removeEventListener("freeze", N),
                  l.removeEventListener("resume", w),
                  u.removeEventListener("blur", h),
                  u.removeEventListener("pagehide", P));
              };
              return {
                disconnect: D,
                end: function () {
                  if (!v)
                    try {
                      S.closeNow(!0);
                    } finally {
                      D();
                    }
                },
              };
            });
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.createSpanTracker = void 0);
          var n = r(4),
            o = n.VIEWABILITY_CONFIG.MIN_DWELL_MS,
            i = n.VIEWABILITY_CONFIG.MAX_TOTAL_VISIBLE_MS;
          t.createSpanTracker = function (e) {
            function t() {
              e.clearTimeout(E), e.clearTimeout(p), (p = E = null);
            }
            function r() {
              if (!g) {
                g = !0;
                try {
                  c(n.READING.VISIBILITY_MONITOR_END, {
                    totalVisibleMs: Math.round(f),
                  });
                } finally {
                  e.onMonitoringEnd();
                }
              }
            }
            function a(o, a, u) {
              if (null != l) {
                var s = o - l;
                (l = null), t(), (f = Math.min(f + s, i));
                try {
                  c(n.READING.VISIBILITY_END, {
                    dwellMs: Math.round(s),
                    totalVisibleMs: Math.round(f),
                    final: u,
                    io: a ? e.ioInfo(a) : null,
                  });
                } finally {
                  !u && i <= f && r();
                }
              }
            }
            function u(t) {
              null != l && a(e.nowMs(), null, t);
            }
            var c = e.send,
              s = e.guard,
              l = null,
              f = 0,
              d = !1,
              E = null,
              p = null,
              g = !1;
            return {
              open: function (t, a) {
                g ||
                  null != l ||
                  ((l = t),
                  (E = e.setTimeout(
                    s(n.ERROR_WHERE.VISIBILITY, function () {
                      (E = null),
                        d ||
                          ((d = !0),
                          c(n.READING.VISIBILITY_DWELL_MET, {
                            io: e.ioInfo(a),
                          }));
                    }),
                    o
                  )),
                  (p = e.setTimeout(
                    s(n.ERROR_WHERE.VISIBILITY, function () {
                      (p = null),
                        (function () {
                          try {
                            u(!0);
                          } finally {
                            r();
                          }
                        })();
                    }),
                    Math.max(0, i - f)
                  )));
              },
              close: a,
              closeNow: u,
              stop: function () {
                (g = !0), t();
              },
            };
          };
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.captureFrameTree = t.getFrameTree = void 0);
          var n = r(12),
            o = r(30),
            i = r(4).VIEWABILITY_CONFIG.FRAME_NAME_MAX_LENGTH,
            a = (t.getFrameTree = function (e, t) {
              function r(e) {
                return e in u || (u[e] = c++), u[e];
              }
              function a(e, t) {
                var r = {};
                return (
                  t &&
                    Object.defineProperty(r, "parent", {
                      enumerable: !1,
                      value: t,
                    }),
                  (0, n.attempt)(function () {
                    return s(e, r);
                  }),
                  r
                );
              }
              var u = Object.create(null),
                c = 0,
                s = function (e, n) {
                  var u = e.length;
                  u && (n.children = []);
                  for (var c = 0; c < u; c++) n.children.push(a(e[c], n));
                  e === window && (n.self = !0),
                    t && e === t && (n.measured = !0);
                  var s = e.location;
                  if (0 <= Object.getOwnPropertyNames(s).indexOf("host")) {
                    n.origin = r(e.origin || (0, o.getUrlOrigin)(s));
                    var l = e.name;
                    l && (n.name = [l.slice(0, i), l.length]),
                      (n.referrer = r((0, o.getUrlBase)(e.document.referrer))),
                      (n.base = r((0, o.getUrlBase)(s)));
                    var f = s.ancestorOrigins;
                    if (f)
                      for (
                        var d = n, E = 0;
                        E < f.length && (d = d.parent);
                        E++
                      )
                        null == d.origin && (d.origin = r(f[E]));
                  }
                },
                l = a(e || window.top, null);
              return (l.urls = u), l;
            });
          t.captureFrameTree = function (e) {
            return window.top ? a(window.top, e) : null;
          };
        },
        function (e, t, r) {
          "use strict";
          function n(e, t) {
            try {
              if (e)
                return "object" === (void 0 === e ? "undefined" : o(e)) &&
                  t in e
                  ? e[t]
                  : new URL(e)[t];
            } catch (e) {}
          }
          Object.defineProperty(t, "__esModule", { value: !0 });
          var o =
              "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (e) {
                    return typeof e;
                  }
                : function (e) {
                    return e &&
                      "function" == typeof Symbol &&
                      e.constructor === Symbol &&
                      e !== Symbol.prototype
                      ? "symbol"
                      : typeof e;
                  },
            i = (t.getUrlOrigin = function (e) {
              if (!e) return "null";
              var t = n(e, "origin");
              if (t) return t;
              var r = /https?:/.exec(n(e, "protocol")),
                o = n(e, "host");
              if (r && o) return r + "//" + o;
              var i = /^https?:\/\/[a-z0-9:.-]+/i.exec(e + "");
              return i ? i[0] : "null";
            });
          t.getUrlBase = function (e) {
            if (!e) return "null";
            var t = i(e);
            return "null" === t
              ? "null"
              : t +
                  (function (e) {
                    var t = n(e, "pathname");
                    if (t) return "/" === t ? "" : t;
                    var r = /^[a-z0-9.+-]+:(?:\/\/[a-z0-9:.-]*)?([^#?]*)/i.exec(
                      e + ""
                    );
                    return r ? ("/" === r[1] ? "" : r[1]) : "";
                  })(e);
          };
        },
        function (e, t, r) {
          "use strict";
          function n(e) {
            return !(!e || !e.ownerDocument);
          }
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.onVpaidAdEnd =
              t.isVpaidAdOver =
              t.getVpaidAdElement =
              t.getVpaidObj =
              t.VPAID_AD_END_EVENTS =
                void 0);
          var o = r(4),
            i = (t.VPAID_AD_END_EVENTS = [
              "AdStopped",
              "AdSkipped",
              "AdError",
              "AdVideoComplete",
            ]);
          (t.getVpaidObj = function (e) {
            var t = e && e.amzncsm;
            return (t && t.vpaidObj) || null;
          }),
            (t.getVpaidAdElement = function (e) {
              return e
                ? n(e.videoSlot_)
                  ? {
                      el: e.videoSlot_,
                      target: o.MEASUREMENT_TARGET.VIDEO_SLOT,
                    }
                  : n(e.slot_)
                  ? { el: e.slot_, target: o.MEASUREMENT_TARGET.SLOT }
                  : null
                : null;
            }),
            (t.isVpaidAdOver = function (e) {
              var t = e && e.eventStatus;
              return (
                !!t &&
                i.some(function (e) {
                  return t[e];
                })
              );
            }),
            (t.onVpaidAdEnd = function (e, t) {
              if (e && "function" == typeof e.subscribe) {
                var r = !1;
                i.forEach(function (n) {
                  e.subscribe(
                    function () {
                      r || ((r = !0), t(n));
                    },
                    n,
                    e
                  );
                });
              }
            });
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.tagReadings = t.buildSink = void 0);
          var n =
              Object.assign ||
              function (e) {
                for (var t = 1; t < arguments.length; t++) {
                  var r = arguments[t];
                  for (var n in r)
                    Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
                }
                return e;
              },
            o = r(4),
            i = r(7),
            a = r(5),
            u = r(6);
          (t.buildSink = function (e) {
            var t = (0, a.getBidIdFromLoggingParameters)(e),
              r = (0, a.getZoneFromLoggingParameters)(e),
              n = (0, u.getVFRDBasedOnSupplyFromLoggingParameters)(e);
            return function (e) {
              (0, i.logToTungstenCombined)(
                o.VIEWABILITY_TENANT_ID,
                { vfrd: n, dbg: JSON.stringify(e) },
                t,
                r,
                n,
                o.VIEWABILITY_VERSION,
                e.reason === o.READING.ERROR,
                !1,
                i.beaconRequest
              );
            };
          }),
            (t.tagReadings = function (e, t) {
              return function (r) {
                e(n({}, r, t));
              };
            });
        },
        function (e, t, r) {
          "use strict";
          Object.defineProperty(t, "__esModule", { value: !0 }),
            (t.createErrorReporter = t.errorMessage = void 0);
          var n =
              "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (e) {
                    return typeof e;
                  }
                : function (e) {
                    return e &&
                      "function" == typeof Symbol &&
                      e.constructor === Symbol &&
                      e !== Symbol.prototype
                      ? "symbol"
                      : typeof e;
                  },
            o = r(4),
            i = o.VIEWABILITY_CONFIG.MAX_ERRORS_PER_RUN,
            a = o.VIEWABILITY_CONFIG.MAX_ERROR_MESSAGE_LENGTH,
            u = (t.errorMessage = function (e) {
              var t = void 0;
              try {
                t =
                  e &&
                  "object" === (void 0 === e ? "undefined" : n(e)) &&
                  "message" in e
                    ? (e.name ? e.name + ": " : "") + e.message
                    : String(e);
              } catch (e) {
                t = "Unknown error";
              }
              return String(t).slice(0, a);
            });
          t.createErrorReporter = function (e) {
            function t(t, n) {
              if (!(i <= r)) {
                r++;
                try {
                  e({
                    reason: o.READING.ERROR,
                    where: t,
                    m: u(n),
                    t: Date.now(),
                  });
                } catch (t) {}
              }
            }
            var r = 0;
            return {
              report: t,
              guard: function (e, r) {
                return function () {
                  try {
                    return r.apply(this, arguments);
                  } catch (r) {
                    return void t(e, r);
                  }
                };
              },
            };
          };
        },
      ]),
    (e.c = r),
    (e.d = function (t, r, n) {
      e.o(t, r) || Object.defineProperty(t, r, { enumerable: !0, get: n });
    }),
    (e.r = function (e) {
      "undefined" != typeof Symbol &&
        Symbol.toStringTag &&
        Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
        Object.defineProperty(e, "__esModule", { value: !0 });
    }),
    (e.t = function (t, r) {
      if ((1 & r && (t = e(t)), 8 & r)) return t;
      if (4 & r && "object" == typeof t && t && t.__esModule) return t;
      var n = Object.create(null);
      if (
        (e.r(n),
        Object.defineProperty(n, "default", { enumerable: !0, value: t }),
        2 & r && "string" != typeof t)
      )
        for (var o in t)
          e.d(
            n,
            o,
            function (e) {
              return t[e];
            }.bind(null, o)
          );
      return n;
    }),
    (e.n = function (t) {
      var r =
        t && t.__esModule
          ? function () {
              return t.default;
            }
          : function () {
              return t;
            };
      return e.d(r, "a", r), r;
    }),
    (e.o = function (e, t) {
      return Object.prototype.hasOwnProperty.call(e, t);
    }),
    (e.p = ""),
    e((e.s = 23))
  );
  function e(n) {
    if (r[n]) return r[n].exports;
    var o = (r[n] = { i: n, l: !1, exports: {} });
    return t[n].call(o.exports, o, o.exports, e), (o.l = !0), o.exports;
  }
  var t, r;
});
